"""stdio MCP server — exposes 7 Neo tools and runs the daemon poller inline.

Architecture:
  - MCP protocol over stdin/stdout (mcp.server.stdio)
  - BackendPoller starts as a background asyncio task alongside the MCP server
  - Lock file (~/.neo/daemon/neo-mcp.lock) prevents duplicate pollers
  - On clean exit (SIGTERM/SIGINT) lock file is removed and poller is cancelled

Tools:
  neo_submit_task   — POST /v2/thread/init-chat-direct
  neo_task_status   — GET  /v2/thread/status/{thread_id}
  neo_get_messages  — GET  /v2/thread/thread-messages
  neo_send_feedback — POST /v2/thread/feedback/{thread_id}
  neo_pause_task    — POST /v2/thread/control/{thread_id} (PAUSE)
  neo_resume_task   — POST /v2/thread/control/{thread_id} (RESUME)
  neo_stop_task     — DELETE /v2/thread/cleanup-direct/{thread_id}
"""

import asyncio
import json
import logging
import os
import signal
import sys
import threading
import tempfile
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Any, Optional

import anyio
import mcp.types as types
from mcp.server import Server
from mcp.server.stdio import stdio_server

from .action_handlers import ActionHandlers
from .auth import derive_deployment_id, get_or_create_deployment_id, get_secret_key
from .backend_client import BackendClient
from .backend_poller import BackendPoller
from .job_manager import JobManager
from .paths import (
    DAEMON_DIR,
    DAEMON_LOG,
    LOCK_FILE,
    PID_FILE,
    STANDALONE_UUID_FILE,
    THREAD_WORKSPACES_FILE,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Lock file helpers
# ---------------------------------------------------------------------------

def _write_lock(pid: int) -> None:
    DAEMON_DIR.mkdir(parents=True, exist_ok=True)
    LOCK_FILE.write_text(
        json.dumps({"pid": pid, "started_at": datetime.now(timezone.utc).isoformat()})
    )

def _remove_lock() -> None:
    try:
        LOCK_FILE.unlink(missing_ok=True)
        PID_FILE.unlink(missing_ok=True)
    except OSError:
        pass


def _deployment_pid_file(deployment_id: str) -> Path:
    return DAEMON_DIR / f"daemon_{deployment_id.replace('-', '')[:8]}.pid"


def _write_deployment_pid(deployment_id: str, pid: int) -> None:
    DAEMON_DIR.mkdir(parents=True, exist_ok=True)
    _deployment_pid_file(deployment_id).write_text(str(pid))


def _remove_deployment_pid(deployment_id: str) -> None:
    try:
        _deployment_pid_file(deployment_id).unlink(missing_ok=True)
    except OSError:
        pass

def _pid_is_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def _poller_already_running(deployment_id: str = "") -> bool:
    """Return True if any daemon with the same deployment ID is already polling.

    Checks (in order):
    1. Our own lock file (neo-mcp.lock)
    2. npm daemon PID file: daemon_{deployment_id}.pid
    3. Generic fallback PID files: npm_daemon.pid / python_daemon.pid
    """
    # 1. Our own lock file
    if LOCK_FILE.exists():
        try:
            data = json.loads(LOCK_FILE.read_text())
            pid = data.get("pid")
            if pid and int(pid) != os.getpid() and _pid_is_alive(int(pid)):
                return True
        except (OSError, ValueError, TypeError):
            pass

    # 2–3. Any other daemon writing a PID file under ~/.neo/daemon/
    candidates = []
    if deployment_id:
        candidates.append(DAEMON_DIR / f"daemon_{deployment_id.replace('-', '')[:8]}.pid")
        candidates.append(DAEMON_DIR / f"daemon_{deployment_id}.pid")
    candidates += [
        DAEMON_DIR / "npm_daemon.pid",
        DAEMON_DIR / "python_daemon.pid",
    ]
    for pid_file in candidates:
        if pid_file.exists():
            try:
                pid = int(pid_file.read_text().strip())
                if pid != os.getpid() and _pid_is_alive(pid):
                    logger.info("Existing daemon detected via %s (pid=%d) — skipping poller start", pid_file.name, pid)
                    return True
            except (OSError, ValueError):
                pass

    return False


def _load_thread_workspaces() -> dict[str, str]:
    return BackendPoller._load_thread_workspaces()


# ---------------------------------------------------------------------------
# Server construction
# ---------------------------------------------------------------------------

def build_server(
    secret_key: str,
    workspace: str,
) -> tuple[Server, BackendClient, BackendPoller]:
    """Build and wire the MCP server, client, and poller. Returns all three."""
    deployment_id = get_or_create_deployment_id(secret_key)
    thread_workspaces = _load_thread_workspaces()

    client = BackendClient(auth_token=secret_key)
    job_manager = JobManager()
    handlers = ActionHandlers(
        job_manager=job_manager,
        default_workspace=workspace,
        thread_workspaces=thread_workspaces,
    )
    poller = BackendPoller(
        deployment_id=deployment_id,
        client=client,
        handlers=handlers,
        thread_workspaces=thread_workspaces,
    )

    server = Server("neo-mcp")

    # ----------------------------------------------------------------
    # Tool definitions
    # ----------------------------------------------------------------

    @server.list_tools()
    async def list_tools() -> list[types.Tool]:
        return [
            types.Tool(
                name="neo_submit_task",
                description=(
                    "Submit an AI/ML task to Neo for local execution. "
                    "Use for: training/fine-tuning models, building AI agents, RAG pipelines, "
                    "LLM integrations, ML data processing. "
                    "NOT for general coding — write that code directly. "
                    "\n\n"
                    "Execution is entirely local: the daemon runs on the user's machine and "
                    "writes files directly to workspace. Files are never stored remotely. "
                    "Neo's output may reference /app/project/src/model.py — the daemon "
                    "automatically remaps this to <workspace>/src/model.py on the local disk. "
                    "\n\n"
                    "Returns {thread_id, status, workspace} immediately. "
                    "Next: neo_task_status to poll, neo_get_messages when COMPLETED."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "message": {
                            "type": "string",
                            "description": (
                                "Full task description. Be specific: state the goal, "
                                "relevant file paths, and constraints. "
                                "Example: 'Train a sentiment classifier on data/reviews.csv, "
                                "save to models/sentiment.pkl, target F1 > 0.85'"
                            ),
                        },
                        "workspace": {
                            "type": "string",
                            "description": (
                                "Absolute path to the PROJECT ROOT — the git repository root "
                                "or top-level project folder. "
                                "ALWAYS infer automatically, never ask the user. "
                                "NEVER pass a subdirectory: if the user is inside "
                                "/home/user/project/src, pass /home/user/project. "
                                "Run `git rev-parse --show-toplevel` to find the git root, "
                                "or fall back to os.getcwd(). "
                                "Passing a subdirectory creates duplicate nested folders."
                            ),
                        },
                    },
                    "required": ["message", "workspace"],
                },
                annotations=types.ToolAnnotations(
                    readOnlyHint=False,
                    destructiveHint=False,
                    idempotentHint=False,
                    openWorldHint=True,
                ),
            ),
            types.Tool(
                name="neo_task_status",
                description=(
                    "Get the current status of a Neo task. Returns one of: "
                    "RUNNING (still executing — call again; use neo_task_plan for step details), "
                    "COMPLETED (done — call neo_get_messages for output), "
                    "WAITING_FOR_FEEDBACK (Neo has a question — call neo_send_feedback), "
                    "PAUSED (frozen — call neo_resume_task to continue), "
                    "TERMINATED or FAILED (ended — call neo_get_messages to read what happened). "
                    "\n\n"
                    "Reads from an in-memory cache backed by an adaptive background poller "
                    "(3s–60s). Fast and safe to call once per turn. "
                    "Do NOT poll in a tight loop."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "thread_id": {
                            "type": "string",
                            "description": "Thread ID from neo_submit_task. Example: 'thread_abc123'",
                        },
                    },
                    "required": ["thread_id"],
                },
                annotations=types.ToolAnnotations(
                    readOnlyHint=True,
                    destructiveHint=False,
                    idempotentHint=True,
                    openWorldHint=True,
                ),
            ),
            types.Tool(
                name="neo_get_messages",
                description=(
                    "Retrieve the full conversation output from a completed Neo task. "
                    "Only call when neo_task_status returns COMPLETED — "
                    "for live progress while RUNNING use neo_task_plan instead "
                    "(cheaper, shows per-step status without fetching all messages). "
                    "\n\n"
                    "Output is capped at ~80,000 characters (~20,000 tokens). "
                    "If the response is truncated, paginate backwards using the `before` "
                    "cursor set to the ISO timestamp of the oldest message on the previous page."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "thread_id": {
                            "type": "string",
                            "description": "Thread ID from neo_submit_task.",
                        },
                        "before": {
                            "type": "string",
                            "description": (
                                "Pagination cursor — ISO 8601 timestamp of the oldest message "
                                "from the previous page. Omit to get the most recent messages first."
                            ),
                        },
                        "limit": {
                            "type": "integer",
                            "description": "Max messages to return per page. Default 50, max 200.",
                            "default": 50,
                            "minimum": 1,
                            "maximum": 200,
                        },
                    },
                    "required": ["thread_id"],
                },
                annotations=types.ToolAnnotations(
                    readOnlyHint=True,
                    destructiveHint=False,
                    idempotentHint=True,
                    openWorldHint=True,
                ),
            ),
            types.Tool(
                name="neo_send_feedback",
                description=(
                    "Reply to Neo when it is waiting for user input. "
                    "Only call when neo_task_status returns WAITING_FOR_FEEDBACK — "
                    "Neo has paused and needs a decision or clarification before continuing. "
                    "After sending, call neo_task_status again to confirm the task resumed. "
                    "\n\n"
                    "Do NOT use to submit a new task — use neo_submit_task for that."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "thread_id": {
                            "type": "string",
                            "description": "Thread ID of the task that is WAITING_FOR_FEEDBACK.",
                        },
                        "message": {
                            "type": "string",
                            "description": (
                                "Your reply to Neo's question or additional instructions. "
                                "Example: 'Use PyTorch, target accuracy 90%, save to models/'"
                            ),
                        },
                    },
                    "required": ["thread_id", "message"],
                },
                annotations=types.ToolAnnotations(
                    readOnlyHint=False,
                    destructiveHint=False,
                    idempotentHint=False,
                    openWorldHint=True,
                ),
            ),
            types.Tool(
                name="neo_pause_task",
                description=(
                    "Pause a running Neo task mid-execution. "
                    "The task freezes at its current step and can be resumed later with "
                    "neo_resume_task. Safe to call on an already-paused task (no-op). "
                    "To cancel permanently, use neo_stop_task instead."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "thread_id": {
                            "type": "string",
                            "description": "Thread ID of the running task to pause.",
                        },
                    },
                    "required": ["thread_id"],
                },
                annotations=types.ToolAnnotations(
                    readOnlyHint=False,
                    destructiveHint=False,
                    idempotentHint=True,
                    openWorldHint=True,
                ),
            ),
            types.Tool(
                name="neo_resume_task",
                description=(
                    "Resume a paused Neo task from where it stopped. "
                    "Has no effect if the task is already running. "
                    "Only works after neo_pause_task — to start a new task use neo_submit_task."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "thread_id": {
                            "type": "string",
                            "description": "Thread ID of the paused task to resume.",
                        },
                    },
                    "required": ["thread_id"],
                },
                annotations=types.ToolAnnotations(
                    readOnlyHint=False,
                    destructiveHint=False,
                    idempotentHint=True,
                    openWorldHint=True,
                ),
            ),
            types.Tool(
                name="neo_stop_task",
                description=(
                    "Permanently stop and clean up a Neo task. "
                    "IRREVERSIBLE — execution context is deleted and the task cannot be resumed. "
                    "Only call when the user explicitly asks to cancel. "
                    "To pause temporarily (resumable), use neo_pause_task instead."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "thread_id": {
                            "type": "string",
                            "description": "Thread ID of the task to permanently stop.",
                        },
                    },
                    "required": ["thread_id"],
                },
                annotations=types.ToolAnnotations(
                    readOnlyHint=False,
                    destructiveHint=True,
                    idempotentHint=False,
                    openWorldHint=True,
                ),
            ),
            types.Tool(
                name="neo_list_tasks",
                description=(
                    "List all known Neo tasks with their current live status. "
                    "Use this when returning to a session — e.g. after closing and reopening "
                    "Claude Code — to see which tasks are still RUNNING, which are COMPLETED, "
                    "and which need feedback. "
                    "Returns tasks sorted newest-first. For each task: thread_id, workspace, "
                    "status, and last-updated timestamp. "
                    "After getting thread_ids, use neo_task_status or neo_get_messages to "
                    "drill into a specific task."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {},
                    "required": [],
                },
                annotations=types.ToolAnnotations(
                    readOnlyHint=True,
                    destructiveHint=False,
                    idempotentHint=True,
                    openWorldHint=True,
                ),
            ),
        ]

    # ----------------------------------------------------------------
    # Tool call handler
    # ----------------------------------------------------------------

    @server.call_tool()
    async def call_tool(
        name: str, arguments: Optional[dict[str, Any]]
    ) -> list[types.TextContent]:
        args = arguments or {}

        try:
            if name == "neo_submit_task":
                result = await _submit_task(client, deployment_id, poller, workspace, args)
            elif name == "neo_task_status":
                result = await _task_status(client, args)
            elif name == "neo_get_messages":
                result = await _get_messages(client, args)
            elif name == "neo_send_feedback":
                result = await _send_feedback(client, args)
            elif name == "neo_pause_task":
                result = await _pause_task(client, args)
            elif name == "neo_resume_task":
                result = await _resume_task(client, args)
            elif name == "neo_stop_task":
                result = await _stop_task(client, poller, args)
            elif name == "neo_list_tasks":
                result = await _list_tasks(client)
            else:
                result = {"error": f"Unknown tool: {name}"}
        except RuntimeError as exc:
            result = {"error": str(exc)}
        except Exception as exc:  # noqa: BLE001
            logger.error("Tool %s failed: %s", name, exc, exc_info=True)
            result = {"error": str(exc)}

        return [types.TextContent(type="text", text=json.dumps(result, indent=2))]

    return server, client, poller


# ---------------------------------------------------------------------------
# Tool implementations
# ---------------------------------------------------------------------------

async def _submit_task(
    client: BackendClient,
    deployment_id: str,
    poller: BackendPoller,
    default_workspace: str,
    args: dict,
) -> dict:
    message = args["message"]
    ws = args.get("workspace") or default_workspace
    data = await client.init_chat(message=message, deployment_id=deployment_id, workspace=ws)
    thread_id = data.get("thread_id")
    if thread_id:
        poller.set_thread_status(thread_id, "RUNNING")
        # Register workspace NOW — before any poll commands arrive.
        # ActionHandlers._workspace_for(thread_id) reads this shared dict,
        # so write_code / run_subprocess will use the correct local path.
        poller.register_thread_workspace(thread_id, ws)
    return {"thread_id": thread_id, "status": "submitted", "workspace": ws}


async def _task_status(client: BackendClient, args: dict) -> dict:
    return await client.get_thread_status(args["thread_id"])


async def _get_messages(client: BackendClient, args: dict) -> dict:
    return await client.get_thread_messages(
        thread_id=args["thread_id"],
        before=args.get("before"),
        limit=args.get("limit", 50),
    )


async def _send_feedback(client: BackendClient, args: dict) -> dict:
    await client.send_feedback(thread_id=args["thread_id"], message=args["message"])
    return {"status": "ok", "thread_id": args["thread_id"]}


async def _pause_task(client: BackendClient, args: dict) -> dict:
    await client.control_thread(thread_id=args["thread_id"], signal="PAUSE")
    return {"status": "paused", "thread_id": args["thread_id"]}


async def _resume_task(client: BackendClient, args: dict) -> dict:
    await client.control_thread(thread_id=args["thread_id"], signal="RESUME")
    return {"status": "resumed", "thread_id": args["thread_id"]}


async def _stop_task(
    client: BackendClient, poller: BackendPoller, args: dict
) -> dict:
    thread_id = args["thread_id"]
    await client.stop_thread(thread_id=thread_id)
    poller.set_thread_status(thread_id, "TERMINATED")
    return {"status": "stopped", "thread_id": thread_id}


async def _list_tasks(client: BackendClient) -> dict:
    """Return all known tasks with live status, sorted newest-first.

    Reads thread→workspace from the persisted local file so tasks submitted in
    previous sessions are included — useful for reconnecting after a restart.
    Fetches status for each thread concurrently to keep latency low.
    """
    workspaces = _load_thread_workspaces()
    if not workspaces:
        return {"tasks": [], "count": 0}

    # Load raw file to get updated_at timestamps for sorting
    raw: dict[str, Any] = {}
    if THREAD_WORKSPACES_FILE.exists():
        try:
            raw = json.loads(THREAD_WORKSPACES_FILE.read_text())
        except Exception:  # noqa: BLE001
            pass

    async def fetch_status(thread_id: str, workspace: str) -> dict[str, Any]:
        entry = raw.get(thread_id, {})
        updated_at = entry.get("updated_at", "") if isinstance(entry, dict) else ""
        try:
            status_data = await client.get_thread_status(thread_id)
            status = status_data.get("status", "UNKNOWN")
        except Exception:  # noqa: BLE001
            status = "UNKNOWN"
        return {
            "thread_id": thread_id,
            "workspace": workspace,
            "status": status,
            "updated_at": updated_at,
        }

    results = await asyncio.gather(
        *[fetch_status(tid, ws) for tid, ws in workspaces.items()]
    )
    # Sort newest-first by updated_at (ISO string comparison works correctly)
    tasks = sorted(results, key=lambda t: t["updated_at"], reverse=True)
    return {"tasks": tasks, "count": len(tasks)}


# ---------------------------------------------------------------------------
# Async run + CLI entry point
# ---------------------------------------------------------------------------

async def run(secret_key: str, workspace: str) -> None:
    """Build MCP server, start poller, run stdio transport until EOF."""
    server, client, poller = build_server(secret_key=secret_key, workspace=workspace)

    pid = os.getpid()
    poller_task: Optional[asyncio.Task] = None
    deployment_id = get_or_create_deployment_id(secret_key)
    if _poller_already_running(deployment_id):
        logger.warning(
            "Another daemon is already running for deployment %s. "
            "MCP server will start without a local poller.",
            deployment_id,
        )
    else:
        _write_lock(pid)
        DAEMON_DIR.mkdir(parents=True, exist_ok=True)
        PID_FILE.write_text(str(pid))
        _write_deployment_pid(deployment_id, pid)
        poller_task = asyncio.create_task(poller.run(), name="backend-poller")
        logger.info(
            "Poller started (pid=%d deployment=%s)",
            pid,
            deployment_id,
        )

    def _shutdown(signum: int, frame: Any) -> None:
        logger.info("Received signal %d — shutting down", signum)
        if poller_task and not poller_task.done():
            poller_task.cancel()
        poller.stop()
        _remove_deployment_pid(deployment_id)
        _remove_lock()
        sys.exit(0)

    signal.signal(signal.SIGTERM, _shutdown)
    signal.signal(signal.SIGINT, _shutdown)

    try:
        async with stdio_server() as (read_stream, write_stream):
            await server.run(
                read_stream,
                write_stream,
                server.create_initialization_options(),
            )
    finally:
        if poller_task and not poller_task.done():
            poller_task.cancel()
            try:
                await poller_task
            except asyncio.CancelledError:
                pass
        await client.aclose()
        _remove_deployment_pid(deployment_id)
        _remove_lock()
        logger.info("Server shut down cleanly")


def _setup_logging() -> None:
    """Route all internal logging to a file so it doesn't pollute stdio."""
    log_dir = os.path.expanduser("~/.neo/daemon")
    log_file = os.path.join(log_dir, "neo-mcp.log")
    try:
        os.makedirs(log_dir, exist_ok=True)
        logging.basicConfig(
            filename=log_file,
            level=logging.INFO,
            format="%(asctime)s %(levelname)s %(name)s: %(message)s",
            datefmt="%Y-%m-%dT%H:%M:%S",
        )
    except OSError:
        # Fallback for read-only environments (tests/sandboxes): keep CLI usable.
        logging.basicConfig(
            stream=sys.stderr,
            level=logging.INFO,
            format="%(asctime)s %(levelname)s %(name)s: %(message)s",
            datefmt="%Y-%m-%dT%H:%M:%S",
        )


def _start_health_server() -> None:
    """Start a minimal HTTP health server on NEO_HEALTH_PORT (default 8080)."""
    port = int(os.environ.get("NEO_HEALTH_PORT", "8080"))

    class _Handler(BaseHTTPRequestHandler):
        def do_GET(self) -> None:
            if self.path == "/health":
                body = b'{"status":"ok"}'
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            else:
                self.send_response(404)
                self.end_headers()

        def log_message(self, *args: Any) -> None:
            pass  # silence access logs

    try:
        server = HTTPServer(("0.0.0.0", port), _Handler)
    except OSError:
        logger.warning("Health server port %d already in use — skipping health endpoint", port)
        return
    t = threading.Thread(target=server.serve_forever, daemon=True)
    t.start()
    logger.info("Health server listening on port %d", port)


def _deployment_id_source(secret_key: str) -> tuple[str, str]:
    explicit = os.environ.get("NEO_DEPLOYMENT_ID", "").strip()
    if explicit:
        return explicit, "explicit-env"
    mode = os.environ.get("NEO_DEPLOYMENT_ID_MODE", "").strip().lower()
    if mode in {"key-derived", "key", "deterministic"} and secret_key:
        return derive_deployment_id(secret_key), "key-derived-mode"
    if STANDALONE_UUID_FILE.exists():
        persisted = STANDALONE_UUID_FILE.read_text().strip()
        if persisted:
            return persisted, "machine-persisted"
    return "", "unset"


def _json_print(payload: dict[str, Any]) -> None:
    print(json.dumps(payload, indent=2))


def _cmd_status(json_mode: bool = False) -> int:
    secret_key = get_secret_key() or ""
    dep_id, source = _deployment_id_source(secret_key)
    daemon_pid = None
    daemon_running = False
    if dep_id:
        pid_file = _deployment_pid_file(dep_id)
        if pid_file.exists():
            try:
                daemon_pid = int(pid_file.read_text().strip())
                daemon_running = _pid_is_alive(daemon_pid)
            except (OSError, ValueError):
                daemon_pid = None
                daemon_running = False

    thread_count = 0
    if THREAD_WORKSPACES_FILE.exists():
        try:
            data = json.loads(THREAD_WORKSPACES_FILE.read_text())
            if isinstance(data, dict):
                thread_count = len(data)
        except Exception:  # noqa: BLE001
            thread_count = 0

    payload = {
        "mode": "stdio-daemon-first",
        "http_mode": "obsolete-not-used",
        "secret_key_present": bool(secret_key),
        "deployment_id": dep_id,
        "deployment_id_source": source,
        "daemon_running": daemon_running,
        "daemon_pid": daemon_pid,
        "thread_mappings": thread_count,
        "daemon_dir": str(DAEMON_DIR),
    }
    if json_mode:
        _json_print(payload)
    else:
        print("Neo MCP status")
        print(f"  mode:                 {payload['mode']}")
        print(f"  http_mode:            {payload['http_mode']}")
        print(f"  secret_key_present:   {payload['secret_key_present']}")
        print(f"  deployment_id:        {dep_id or '(none)'}")
        print(f"  deployment_id_source: {source}")
        print(f"  daemon_running:       {daemon_running}")
        print(f"  daemon_pid:           {daemon_pid if daemon_pid is not None else '(none)'}")
        print(f"  thread_mappings:      {thread_count}")
        print(f"  daemon_dir:           {DAEMON_DIR}")
    return 0


def _cmd_doctor(json_mode: bool = False) -> int:
    checks: list[dict[str, Any]] = []

    py_ok = sys.version_info >= (3, 11)
    checks.append({
        "name": "python_version>=3.11",
        "ok": py_ok,
        "detail": f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
    })

    key = get_secret_key() or ""
    checks.append({
        "name": "secret_key_present",
        "ok": bool(key),
        "detail": "NEO_SECRET_KEY set" if key else "NEO_SECRET_KEY missing",
    })

    try:
        DAEMON_DIR.mkdir(parents=True, exist_ok=True)
        writable = os.access(DAEMON_DIR, os.W_OK)
    except OSError:
        writable = False
    checks.append({
        "name": "daemon_dir_writable",
        "ok": writable,
        "detail": str(DAEMON_DIR),
    })

    dep_id, source = _deployment_id_source(key)
    checks.append({
        "name": "deployment_id_resolved",
        "ok": bool(dep_id),
        "detail": f"{dep_id or 'none'} ({source})",
    })

    daemon_ok = False
    if dep_id:
        pf = _deployment_pid_file(dep_id)
        if pf.exists():
            try:
                daemon_ok = _pid_is_alive(int(pf.read_text().strip()))
            except (OSError, ValueError):
                daemon_ok = False
    checks.append({
        "name": "daemon_running_for_deployment",
        "ok": daemon_ok,
        "detail": dep_id or "no deployment id",
    })

    payload = {
        "mode": "stdio-daemon-first",
        "http_mode": "obsolete-not-used",
        "all_ok": all(c["ok"] for c in checks),
        "checks": checks,
        "hints": [
            "Set NEO_SECRET_KEY=sk-v1-... if missing",
            "Run `neo-mcp daemon` in a separate terminal for local execution",
            "Use default machine deployment ID unless you explicitly need deterministic key-derived mode",
        ],
    }
    if json_mode:
        _json_print(payload)
    else:
        print("Neo MCP doctor")
        for c in checks:
            mark = "OK" if c["ok"] else "FAIL"
            print(f"  [{mark}] {c['name']}: {c['detail']}")
        print("\nNotes:")
        print("  - HTTP mode is obsolete; this tool validates stdio+local daemon flow.")
        for h in payload["hints"]:
            print(f"  - {h}")
    return 0 if payload["all_ok"] else 1


def _cmd_logs(lines: int = 120, source: str = "neo-mcp") -> int:
    file_map = {
        "neo-mcp": DAEMON_DIR / "neo-mcp.log",
        "daemon": DAEMON_LOG,
    }
    target = file_map.get(source, DAEMON_DIR / "neo-mcp.log")
    if not target.exists():
        print(f"No log file found: {target}")
        return 1
    data = target.read_text(errors="replace").splitlines()
    for line in data[-max(lines, 1):]:
        print(line)
    return 0


def _cmd_tail(lines: int = 120, source: str = "neo-mcp") -> int:
    """Shortcut alias for logs tail output."""
    return _cmd_logs(lines=lines, source=source)


def _cmd_list(json_mode: bool = False) -> int:
    if not THREAD_WORKSPACES_FILE.exists():
        payload = {"count": 0, "tasks": []}
        if json_mode:
            _json_print(payload)
        else:
            print("No known tasks yet.")
        return 0

    raw = json.loads(THREAD_WORKSPACES_FILE.read_text() or "{}")
    tasks: list[dict[str, Any]] = []
    if isinstance(raw, dict):
        for tid, value in raw.items():
            if isinstance(value, str):
                tasks.append({"thread_id": tid, "workspace": value, "updated_at": ""})
            elif isinstance(value, dict):
                tasks.append({
                    "thread_id": tid,
                    "workspace": value.get("workspace", ""),
                    "updated_at": value.get("updated_at", ""),
                })
    tasks.sort(key=lambda t: str(t.get("updated_at", "")), reverse=True)
    payload = {"count": len(tasks), "tasks": tasks}
    if json_mode:
        _json_print(payload)
    else:
        if not tasks:
            print("No known tasks yet.")
            return 0
        print("Known tasks")
        for t in tasks:
            print(f"  - {t['thread_id']}  {t['workspace']}  updated_at={t['updated_at']}")
    return 0


def _cmd_self_test(json_mode: bool = False) -> int:
    checks: list[dict[str, Any]] = []
    td = tempfile.mkdtemp(prefix="neo-selftest-")
    ws = os.path.join(td, "ws")
    os.makedirs(ws, exist_ok=True)
    jm = JobManager()
    handlers = ActionHandlers(jm, ws, {})

    async def _run_local_checks() -> tuple[bool, bool]:
        good = await handlers.handle_command({
            "action": "write_code",
            "request_id": "self-1",
            "filename": "a.py",
            "code": "print('ok')",
        })
        bad = await handlers.handle_command({
            "action": "write_code",
            "request_id": "self-2",
            "filename": "../../../../etc/passwd",
            "code": "x",
        })
        return good.get("status") == "success", bad.get("status") == "error"

    ok_write, ok_block = asyncio.run(_run_local_checks())
    checks.append({"name": "write_code_within_workspace", "ok": ok_write})
    checks.append({"name": "path_traversal_blocked", "ok": ok_block})
    checks.append({"name": "http_mode_disabled", "ok": True, "detail": "stdio/daemon-only validation"})

    payload = {"all_ok": all(c["ok"] for c in checks), "checks": checks}
    if json_mode:
        _json_print(payload)
    else:
        print("Neo MCP self-test")
        for c in checks:
            mark = "OK" if c["ok"] else "FAIL"
            print(f"  [{mark}] {c['name']}")
        print("  This test validates local daemon semantics only.")
    return 0 if payload["all_ok"] else 1


async def run_daemon(secret_key: str, workspace: str, deployment_id: Optional[str] = None) -> None:
    dep = deployment_id or get_or_create_deployment_id(secret_key)
    if _poller_already_running(dep):
        logger.warning("Another daemon is already running for deployment %s", dep)
        return

    thread_workspaces = _load_thread_workspaces()
    client = BackendClient(auth_token=secret_key)
    handlers = ActionHandlers(
        job_manager=JobManager(),
        default_workspace=workspace,
        thread_workspaces=thread_workspaces,
    )
    poller = BackendPoller(
        deployment_id=dep,
        client=client,
        handlers=handlers,
        thread_workspaces=thread_workspaces,
    )

    pid = os.getpid()
    _write_lock(pid)
    PID_FILE.write_text(str(pid))
    _write_deployment_pid(dep, pid)
    def _shutdown(signum: int, frame: Any) -> None:
        logger.info("Daemon received signal %d — shutting down", signum)
        poller.stop()

    signal.signal(signal.SIGTERM, _shutdown)
    signal.signal(signal.SIGINT, _shutdown)

    task = asyncio.create_task(poller.run(), name="backend-poller-daemon")
    try:
        await task
    finally:
        if not task.done():
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
        await client.aclose()
        _remove_deployment_pid(dep)
        _remove_lock()


def main() -> None:
    """CLI entry point — called by the neo-mcp console script."""
    _setup_logging()
    _start_health_server()

    args = sys.argv[1:]
    known = {"setup", "doctor", "status", "list", "logs", "tail", "self-test", "daemon"}

    if args and args[0] == "setup":
        from .setup import run_setup
        run_setup(args[1:])
        return

    if args and args[0] == "doctor":
        json_mode = "--json" in args[1:]
        sys.exit(_cmd_doctor(json_mode=json_mode))

    if args and args[0] == "status":
        json_mode = "--json" in args[1:]
        sys.exit(_cmd_status(json_mode=json_mode))

    if args and args[0] == "list":
        json_mode = "--json" in args[1:]
        sys.exit(_cmd_list(json_mode=json_mode))

    if args and args[0] == "logs":
        lines = 120
        source = "neo-mcp"
        tail_args = args[1:]
        for i, a in enumerate(tail_args):
            if a == "--lines" and i + 1 < len(tail_args):
                try:
                    lines = int(tail_args[i + 1])
                except ValueError:
                    pass
            if a == "--source" and i + 1 < len(tail_args):
                source = tail_args[i + 1]
        sys.exit(_cmd_logs(lines=lines, source=source))

    if args and args[0] == "tail":
        lines = 120
        source = "neo-mcp"
        tail_args = args[1:]
        for i, a in enumerate(tail_args):
            if a == "--lines" and i + 1 < len(tail_args):
                try:
                    lines = int(tail_args[i + 1])
                except ValueError:
                    pass
            if a == "--source" and i + 1 < len(tail_args):
                source = tail_args[i + 1]
        sys.exit(_cmd_tail(lines=lines, source=source))

    if args and args[0] == "self-test":
        json_mode = "--json" in args[1:]
        sys.exit(_cmd_self_test(json_mode=json_mode))

    secret_key = get_secret_key()

    if args and args[0] == "daemon":
        if not secret_key:
            sys.stderr.write("Error: NEO_SECRET_KEY is required for daemon mode.\n")
            sys.exit(1)

        dep_override: Optional[str] = None
        workspace_arg: Optional[str] = None
        daemon_args = args[1:]
        i = 0
        while i < len(daemon_args):
            cur = daemon_args[i]
            if cur == "--deployment-id" and i + 1 < len(daemon_args):
                dep_override = daemon_args[i + 1]
                i += 2
                continue
            if not cur.startswith("-") and workspace_arg is None:
                workspace_arg = cur
            i += 1
        workspace = os.path.abspath(workspace_arg or os.environ.get("NEO_WORKSPACE_DIR", os.getcwd()))
        if not os.path.isdir(workspace):
            sys.stderr.write(f"Error: workspace '{workspace}' is not a directory.\n")
            sys.exit(1)
        anyio.run(run_daemon, secret_key, workspace, dep_override)
        return

    # Default mode: stdio MCP server (legacy behavior preserved).
    # First non-command positional argument is treated as workspace.
    workspace_arg = None
    if args and args[0] not in known:
        workspace_arg = args[0]
    workspace = os.path.abspath(workspace_arg or os.environ.get("NEO_WORKSPACE_DIR", os.getcwd()))
    if not os.path.isdir(workspace):
        sys.stderr.write(f"Error: workspace '{workspace}' is not a directory.\n")
        sys.exit(1)

    if not secret_key:
        logger.warning("NEO_SECRET_KEY not set — MCP tools unavailable, health endpoint active")
        threading.Event().wait()  # block forever; health server stays up
        return

    anyio.run(run, secret_key, workspace)
