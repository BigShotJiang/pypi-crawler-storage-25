"""Tests für scan_rclone_directory + Light-Peek Skip-Check."""

import json
import subprocess
from unittest.mock import patch

from familienfilm_manager.core.remote_scanner import (
    RemoteVideoRef,
    _is_qualified_remote_video,
    is_remote_video_already_published,
    peek_remote_sidecar,
    scan_rclone_directory,
)


# ── _is_qualified_remote_video ──


def test_qualified_remote_video_matches_date_prefix_and_extension():
    assert _is_qualified_remote_video("2026-04-18 Test.mov") is True
    assert _is_qualified_remote_video("2026-04-18 Foo.mp4") is True
    assert _is_qualified_remote_video("2026-04-18 Bar.m4v") is True


def test_unqualified_without_date_prefix():
    assert _is_qualified_remote_video("Test.mov") is False


def test_unqualified_hidden():
    assert _is_qualified_remote_video(".hidden.mov") is False


def test_unqualified_unknown_extension():
    assert _is_qualified_remote_video("2026-04-18 Test.txt") is False


def test_unqualified_no_extension():
    assert _is_qualified_remote_video("2026-04-18 Test") is False


# ── scan_rclone_directory ──


def _mock_lsjson_response(entries: list[dict]):
    def fake(args, **kwargs):
        return subprocess.CompletedProcess(
            args=args, returncode=0, stdout=json.dumps(entries), stderr="",
        )
    return fake


def test_scan_returns_sorted_video_refs():
    entries = [
        {"Name": "2026-04-16 C.mov", "Path": "2026-04-16 C.mov", "Size": 1000, "IsDir": False},
        {"Name": "2026-04-12 A.mov", "Path": "2026-04-12 A.mov", "Size": 2000, "IsDir": False},
        {"Name": "2026-04-14 B.mov", "Path": "2026-04-14 B.mov", "Size": 3000, "IsDir": False},
    ]
    with patch(
        "familienfilm_manager.core._rclone.subprocess.run",
        side_effect=_mock_lsjson_response(entries),
    ):
        result = scan_rclone_directory("nas:/Quelle")

    assert [r.name for r in result] == [
        "2026-04-12 A.mov",
        "2026-04-14 B.mov",
        "2026-04-16 C.mov",
    ]
    assert all(isinstance(r, RemoteVideoRef) for r in result)
    assert result[0].uri == "nas:/Quelle/2026-04-12 A.mov"


def test_scan_ignores_non_qualified_entries():
    entries = [
        {"Name": "2026-04-18 Video.mov", "Path": "2026-04-18 Video.mov", "Size": 1, "IsDir": False},
        {"Name": "Readme.txt", "Path": "Readme.txt", "Size": 1, "IsDir": False},
        {"Name": "Ohne-Datum.mov", "Path": "Ohne-Datum.mov", "Size": 1, "IsDir": False},
        {"Name": "subdir", "Path": "subdir", "Size": -1, "IsDir": True},
    ]
    with patch(
        "familienfilm_manager.core._rclone.subprocess.run",
        side_effect=_mock_lsjson_response(entries),
    ):
        result = scan_rclone_directory("nas:/Quelle")

    names = [r.name for r in result]
    assert names == ["2026-04-18 Video.mov"]


def test_scan_recursive_includes_subdirectory_videos():
    """Mit recursive=True werden auch Videos aus Unterordnern gefunden."""
    entries = [
        {"Name": "2026-04-18 Oben.mov", "Path": "2026-04-18 Oben.mov", "Size": 1, "IsDir": False},
        {"Name": "2026-04-19 Unten.mov", "Path": "sub/2026-04-19 Unten.mov", "Size": 1, "IsDir": False},
    ]
    with patch(
        "familienfilm_manager.core._rclone.subprocess.run",
        side_effect=_mock_lsjson_response(entries),
    ):
        result = scan_rclone_directory("nas:/Quelle", recursive=True)

    uris = [r.uri for r in result]
    assert "nas:/Quelle/2026-04-18 Oben.mov" in uris
    assert "nas:/Quelle/sub/2026-04-19 Unten.mov" in uris


def test_scan_recursive_skips_hidden_subdirectories():
    entries = [
        {"Name": "2026-04-18 Ok.mov", "Path": "2026-04-18 Ok.mov", "Size": 1, "IsDir": False},
        {"Name": "2026-04-10 Trash.mov", "Path": ".Trashes/2026-04-10 Trash.mov", "Size": 1, "IsDir": False},
    ]
    with patch(
        "familienfilm_manager.core._rclone.subprocess.run",
        side_effect=_mock_lsjson_response(entries),
    ):
        result = scan_rclone_directory("nas:/Quelle", recursive=True)

    names = [r.name for r in result]
    assert names == ["2026-04-18 Ok.mov"]


def test_scan_recursive_skips_fcpxmld_package():
    """Videos innerhalb von .fcpxmld-Package-Directories werden ignoriert."""
    entries = [
        {"Name": "2026-04-18 Ok.mov", "Path": "2026-04-18 Ok.mov", "Size": 1, "IsDir": False},
        # Gecachtes Video in einem FCP-XML-Bundle
        {
            "Name": "2026-04-10 Cached.mov",
            "Path": "Videoschnittprojekte/2026-04-16 Projekt.fcpxmld/2026-04-10 Cached.mov",
            "Size": 1, "IsDir": False,
        },
    ]
    with patch(
        "familienfilm_manager.core._rclone.subprocess.run",
        side_effect=_mock_lsjson_response(entries),
    ):
        result = scan_rclone_directory("nas:/Quelle", recursive=True)

    names = [r.name for r in result]
    assert names == ["2026-04-18 Ok.mov"]


def test_scan_recursive_skips_lfpackage():
    """LumaFusion-Projekte (.lfpackage) werden ebenfalls als Package behandelt."""
    entries = [
        {
            "Name": "2026-04-10 Cached.mov",
            "Path": "Archive/Projekt.lfpackage/2026-04-10 Cached.mov",
            "Size": 1, "IsDir": False,
        },
    ]
    with patch(
        "familienfilm_manager.core._rclone.subprocess.run",
        side_effect=_mock_lsjson_response(entries),
    ):
        result = scan_rclone_directory("nas:/Quelle", recursive=True)

    assert result == []


def test_scan_propagates_lsjson_failure():
    """Seit v0.10.0: rclone-Fehler werden propagiert, nicht stillschweigend
    als „Verzeichnis leer" interpretiert.

    Vorher hatte ein flüchtiger NAS-Hiccup („connection refused", Auth-Fail,
    falscher Pfad) zu einem leisen ``return []`` geführt — der Watcher sah
    0/0/0/0 ohne erkennbare Ursache. Jetzt schlägt scan durch, der Watcher
    fängt es im try/except und emittiert ein DEPLOY_FAILED-Event.
    """
    import pytest

    err = subprocess.CalledProcessError(1, ["rclone", "lsjson"])
    err.stderr = "connection refused"

    def fake(args, **kwargs):
        raise err

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake):
        with patch("familienfilm_manager.core._rclone.time.sleep"):
            with pytest.raises(subprocess.CalledProcessError):
                scan_rclone_directory("nas:/Quelle")


# ── peek_remote_sidecar ──


def _mock_rclone_router(responses: dict[str, object]):
    """Erweitert _mock_run: mappt rclone-Subcommand-Arg (z.B. uri) auf antwort."""
    def fake(args, **kwargs):
        cmd = args[1] if len(args) > 1 else ""
        if cmd == "cat":
            uri = args[2]
            response = responses.get(uri)
            if response is None:
                err = subprocess.CalledProcessError(1, args)
                err.stderr = "file not found"
                raise err
            return subprocess.CompletedProcess(args=args, returncode=0, stdout=response, stderr="")
        raise AssertionError(f"Unexpected: {args}")
    return fake


def test_peek_remote_sidecar_returns_none_when_missing():
    with patch(
        "familienfilm_manager.core._rclone.subprocess.run",
        side_effect=_mock_rclone_router({}),
    ):
        with patch("familienfilm_manager.core._rclone.time.sleep"):
            result = peek_remote_sidecar("nas:/Quelle/2026-04-18 Test.mov")
    assert result is None


def test_peek_remote_sidecar_parses_toml():
    toml = '''
[web]
web_id = "abc123456789"
published_at = "2026-04-18T10:00:00"

[source]
size_bytes = 12345
head_sha1 = "deadbeef"
'''
    with patch(
        "familienfilm_manager.core._rclone.subprocess.run",
        side_effect=_mock_rclone_router({
            "nas:/Quelle/2026-04-18 Test.settings.toml": toml,
        }),
    ):
        result = peek_remote_sidecar("nas:/Quelle/2026-04-18 Test.mov")

    assert result is not None
    assert result.web_id == "abc123456789"
    assert result.source_size_bytes == 12345


# ── is_remote_video_already_published ──


def _build_toml(**kwargs) -> str:
    """Hilfsfunktion, die ein Sidecar-TOML erzeugt."""
    web_pub = kwargs.get("web_published_at")
    local_pub = kwargs.get("local_published_at")
    archive_pub = kwargs.get("archive_published_at")
    size = kwargs.get("size_bytes", 12345)

    lines = []
    if web_pub or kwargs.get("web_id"):
        lines.append("[web]")
        if kwargs.get("web_id"):
            lines.append(f'web_id = "{kwargs["web_id"]}"')
        if web_pub:
            lines.append(f'published_at = "{web_pub}"')
    if local_pub:
        lines.append("")
        lines.append("[local]")
        lines.append(f'published_at = "{local_pub}"')
    if archive_pub:
        lines.append("")
        lines.append("[archive]")
        lines.append(f'published_at = "{archive_pub}"')
    lines.append("")
    lines.append("[source]")
    lines.append(f"size_bytes = {size}")
    lines.append('head_sha1 = "dummy"')
    return "\n".join(lines) + "\n"


def test_skip_when_all_channels_present_and_size_matches():
    toml = _build_toml(
        web_published_at="t1", local_published_at="t2", archive_published_at="t3",
        size_bytes=9999,
    )
    with patch(
        "familienfilm_manager.core._rclone.subprocess.run",
        side_effect=_mock_rclone_router({
            "nas:/Quelle/2026-04-18 Test.settings.toml": toml,
        }),
    ):
        skip, ts = is_remote_video_already_published(
            "nas:/Quelle/2026-04-18 Test.mov",
            size_bytes=9999,
        )
    assert skip is True
    assert ts == "t1"


def test_no_skip_when_size_differs():
    toml = _build_toml(
        web_published_at="t", local_published_at="t", archive_published_at="t",
        size_bytes=1000,
    )
    with patch(
        "familienfilm_manager.core._rclone.subprocess.run",
        side_effect=_mock_rclone_router({
            "nas:/Quelle/2026-04-18 Test.settings.toml": toml,
        }),
    ):
        skip, _ = is_remote_video_already_published(
            "nas:/Quelle/2026-04-18 Test.mov",
            size_bytes=2000,
        )
    assert skip is False


def test_no_skip_when_channel_missing():
    toml = _build_toml(
        web_published_at="t", local_published_at="t",
        # archive_published_at fehlt
        size_bytes=1000,
    )
    with patch(
        "familienfilm_manager.core._rclone.subprocess.run",
        side_effect=_mock_rclone_router({
            "nas:/Quelle/2026-04-18 Test.settings.toml": toml,
        }),
    ):
        skip, _ = is_remote_video_already_published(
            "nas:/Quelle/2026-04-18 Test.mov",
            size_bytes=1000,
        )
    assert skip is False


def test_no_skip_for_legacy_sidecar_only_web_channel():
    toml = _build_toml(
        web_published_at="t",
        # local, archive fehlen → Legacy-Sidecar
        size_bytes=1000,
    )
    with patch(
        "familienfilm_manager.core._rclone.subprocess.run",
        side_effect=_mock_rclone_router({
            "nas:/Quelle/2026-04-18 Test.settings.toml": toml,
        }),
    ):
        skip, ts = is_remote_video_already_published(
            "nas:/Quelle/2026-04-18 Test.mov",
            size_bytes=1000,
        )
    assert skip is False
    assert ts == "t"


def test_no_skip_respects_inactive_channels():
    """Wenn requires_archive=False, wird archive_published_at nicht verlangt."""
    toml = _build_toml(
        web_published_at="t", local_published_at="t",
        # archive fehlt
        size_bytes=500,
    )
    with patch(
        "familienfilm_manager.core._rclone.subprocess.run",
        side_effect=_mock_rclone_router({
            "nas:/Quelle/2026-04-18 Test.settings.toml": toml,
        }),
    ):
        skip, _ = is_remote_video_already_published(
            "nas:/Quelle/2026-04-18 Test.mov",
            size_bytes=500,
            requires_archive=False,
        )
    assert skip is True


def test_no_skip_when_no_sidecar():
    with patch(
        "familienfilm_manager.core._rclone.subprocess.run",
        side_effect=_mock_rclone_router({}),
    ):
        with patch("familienfilm_manager.core._rclone.time.sleep"):
            skip, _ = is_remote_video_already_published(
                "nas:/Quelle/2026-04-18 Test.mov",
                size_bytes=1000,
            )
    assert skip is False
