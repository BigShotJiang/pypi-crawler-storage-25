"""Tests für den HTML-Notifier (pending → published/failed, aborted-Migration)."""

from pathlib import Path

from familienfilm_manager.core.notifier import (
    append_pending,
    derive_video_id,
    mark_all_pending_as_aborted,
    replace_entry_failed,
    replace_entry_published,
)


def test_derive_video_id_stable_per_path(tmp_path: Path):
    a = tmp_path / "video.mov"
    b = tmp_path / "video.mov"
    a.touch()
    assert derive_video_id(a) == derive_video_id(b)


def test_derive_video_id_differs_per_path(tmp_path: Path):
    a = tmp_path / "a.mov"; a.touch()
    b = tmp_path / "b.mov"; b.touch()
    assert derive_video_id(a) != derive_video_id(b)


def test_append_pending_creates_file_with_entry(tmp_path: Path):
    path = tmp_path / "notification.html"
    append_pending(path, video_id="abc123", title="Wanderung")

    content = path.read_text()
    assert '<div class="entry pending" data-video-id="abc123">' in content
    assert "Wanderung" in content
    assert "<!-- /entry -->" in content
    assert content.startswith("<!DOCTYPE html>")


def test_append_pending_replaces_existing_entry_with_same_id(tmp_path: Path):
    path = tmp_path / "notification.html"
    append_pending(path, video_id="abc123", title="Alter Titel")
    append_pending(path, video_id="abc123", title="Neuer Titel")

    content = path.read_text()
    # Nur einmal vorhanden (keine Duplikate)
    assert content.count('data-video-id="abc123"') == 1
    assert "Neuer Titel" in content
    assert "Alter Titel" not in content


def test_replace_entry_published_replaces_pending(tmp_path: Path):
    path = tmp_path / "notification.html"
    append_pending(path, video_id="abc123", title="Wanderung")
    replace_entry_published(
        path,
        video_id="abc123",
        title="Wanderung",
        video_url="https://example.com/abc123/",
        category="Familie",
        recording_date="2026-04-18",
    )

    content = path.read_text()
    assert '<div class="entry pending"' not in content
    assert '<div class="entry published" data-video-id="abc123">' in content
    assert 'href="https://example.com/abc123/"' in content
    assert "Familie" in content
    assert "2026-04-18" in content


def test_replace_entry_failed_replaces_pending_with_error(tmp_path: Path):
    path = tmp_path / "notification.html"
    append_pending(path, video_id="abc123", title="Wanderung")
    replace_entry_failed(
        path,
        video_id="abc123",
        title="Wanderung",
        error_message="rclone fehlgeschlagen",
    )

    content = path.read_text()
    assert '<div class="entry failed" data-video-id="abc123">' in content
    assert "rclone fehlgeschlagen" in content


def test_replace_falls_back_to_insert_when_no_pending_exists(tmp_path: Path):
    path = tmp_path / "notification.html"
    replace_entry_published(path, video_id="xyz", title="Neu", video_url="https://e/xyz/")

    content = path.read_text()
    assert '<div class="entry published" data-video-id="xyz">' in content


def test_mark_all_pending_as_aborted(tmp_path: Path):
    path = tmp_path / "notification.html"
    append_pending(path, video_id="a", title="A")
    append_pending(path, video_id="b", title="B")
    # Eines abschliessen → bleibt publiziert, nicht pending
    replace_entry_published(path, video_id="a", title="A", video_url="https://e/a/")

    count = mark_all_pending_as_aborted(path)
    assert count == 1

    content = path.read_text()
    assert '<div class="entry aborted" data-video-id="b">' in content
    assert '<div class="entry published" data-video-id="a">' in content
    # Kein pending mehr
    assert 'class="entry pending"' not in content


def test_mark_all_pending_noop_when_file_missing(tmp_path: Path):
    path = tmp_path / "notification.html"
    assert mark_all_pending_as_aborted(path) == 0
    assert not path.exists()


def test_html_escapes_title_and_url(tmp_path: Path):
    path = tmp_path / "notification.html"
    replace_entry_published(
        path, video_id="x", title='Evil <script>"&',
        video_url='https://e/?q="&x',
    )

    content = path.read_text()
    # Roh-Tag nicht im Entry (HTML-Header enthält keine <script>)
    assert "<script>" not in content
    assert "&lt;script&gt;" in content
    # Quote im href korrekt escaped
    assert 'href="https://e/?q=&quot;&amp;x"' in content


# ── Kanal-Pfade in der HTML-Benachrichtigung (v0.8.0) ──


def test_published_entry_shows_infuse_target(tmp_path: Path):
    """Bei Local-only-Publish (nur Infuse, kein Web) wird der Infuse-Zielpfad angezeigt."""
    path = tmp_path / "notification.html"
    replace_entry_published(
        path, video_id="a", title="Testvideo",
        infuse_target_path="nas:/Familienfilme/Final/2026",
    )
    content = path.read_text()
    assert "Infuse:" in content
    assert "nas:/Familienfilme/Final/2026" in content
    # Kein Web-Block, wenn keine URL
    assert "Web:" not in content


def test_published_entry_shows_all_three_channels(tmp_path: Path):
    """Mit Web-URL + Infuse + Archiv werden alle drei Kanäle angezeigt."""
    path = tmp_path / "notification.html"
    replace_entry_published(
        path, video_id="a", title="Testvideo",
        video_url="https://mediathek.example/xxx/",
        infuse_target_path="nas:/Familienfilme/Final/2026",
        archive_target_path="nas:/Archiv/2026/Videoschnitt",
    )
    content = path.read_text()
    assert "Infuse:" in content
    assert "nas:/Familienfilme/Final/2026" in content
    assert "Web:" in content
    assert "mediathek.example/xxx" in content
    assert "Archiv:" in content
    assert "nas:/Archiv/2026/Videoschnitt" in content
    # Titel bleibt klickbar (grosses Tap-Target auf Mobile)
    assert '<a href="https://mediathek.example/xxx/">Testvideo</a>' in content


def test_published_entry_without_channel_info_has_no_channels_block(tmp_path: Path):
    """Ohne Target-Pfade und ohne Web-URL wird kein .channels-Block gerendert."""
    path = tmp_path / "notification.html"
    replace_entry_published(path, video_id="a", title="Testvideo")
    content = path.read_text()
    assert '<div class="channels">' not in content


def test_channel_target_paths_are_html_escaped(tmp_path: Path):
    """Sonderzeichen in Target-Pfaden werden escaped (kein HTML-Injection)."""
    path = tmp_path / "notification.html"
    replace_entry_published(
        path, video_id="a", title="X",
        infuse_target_path='nas:/"><script>alert(1)</script>',
    )
    content = path.read_text()
    assert "<script>alert" not in content
    assert "&lt;script&gt;" in content


def test_header_upgrade_migrates_stale_css(tmp_path: Path):
    """Eine Bestands-HTML ohne .channels-CSS bekommt beim nächsten Write den
    aktuellen Header (inkl. neuer v0.8.0-Klassen) — Einträge bleiben erhalten."""
    path = tmp_path / "notification.html"
    # Alter Header ohne .channels-Regeln + ein vorhandener Eintrag
    legacy = (
        '<!DOCTYPE html>\n<html><head>'
        '<style>body { background: #fff; }</style>'
        '</head><body>\n'
        '<div class="entry published" data-video-id="old">\n'
        '  <div class="title">Alt</div>\n</div>\n<!-- /entry -->\n'
        '</body></html>\n'
    )
    path.write_text(legacy, encoding="utf-8")

    # Ein neuer Publish triggert den Header-Upgrade
    replace_entry_published(
        path, video_id="neu", title="Neu",
        infuse_target_path="nas:/x",
    )
    content = path.read_text()
    # Neue CSS-Regel ist da
    assert ".channels" in content
    # Alter Eintrag ist noch da
    assert 'data-video-id="old"' in content
    # Neuer Eintrag ist da
    assert 'data-video-id="neu"' in content
