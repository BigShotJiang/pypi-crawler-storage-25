"""Tests für den Archiver (direkter Copy, .archive.toml, Size-Verify)."""

from __future__ import annotations

import os
import subprocess
import tomllib
from pathlib import Path
from unittest.mock import patch

from familienfilm_manager.core.archiver import archive_video


def _make_rclone_mock(
    captured_calls: list[list[str]],
    lsf_output: str,
):
    """Baut einen subprocess.run-Mock für rclone-Aufrufe.

    - Speichert jeden Aufruf in ``captured_calls``.
    - Antwortet auf ``rclone lsf --format sp <target>`` mit ``lsf_output``.
    - Alle anderen Aufrufe (copyto) antworten mit Returncode 0.
    """
    def _fake(*args, **kwargs):
        args_list = args[0]
        captured_calls.append(list(args_list))
        if len(args_list) >= 2 and args_list[1] == "lsf":
            return subprocess.CompletedProcess(
                args=args_list, returncode=0, stdout=lsf_output, stderr="",
            )
        return subprocess.CompletedProcess(args=args_list, returncode=0, stdout="", stderr="")
    return _fake


def test_archive_uses_direct_copy_no_tar(tmp_path: Path):
    """v0.9.0: Die Originaldatei wird direkt per rclone copyto ins Ziel — kein TAR."""
    source = tmp_path / "source-dir"
    source.mkdir()
    video = source / "2026-04-18 Test.mov"
    video.write_bytes(b"video-bytes-12345")
    video_size = video.stat().st_size

    work = tmp_path / "work"
    lsf_output = f"{video_size};2026-04-18-Test.mov\n0;2026-04-18-Test.archive.toml\n"
    calls: list[list[str]] = []

    with patch(
        "familienfilm_manager.core._rclone.subprocess.run",
        side_effect=_make_rclone_mock(calls, lsf_output),
    ):
        result = archive_video(
            source_path=video,
            archive_target="nas:/archive",
            recording_date="2026-04-18",
            title="Test",
            work_dir=work,
        )

    assert result.success is True, result.error_message

    # Kein Aufruf darf auf eine .tar-Datei verweisen
    all_args = [a for call in calls for a in call]
    assert not any(".tar" in str(a) for a in all_args), (
        f"TAR-Referenz gefunden in Aufrufen: {calls}"
    )

    # Es muss mindestens einen copyto des Videos gegeben haben
    copyto_video = [
        c for c in calls
        if len(c) >= 4 and c[1] == "copyto" and str(video) in c[2]
    ]
    assert copyto_video, f"Kein copyto für das Video: {calls}"
    assert copyto_video[0][3] == "nas:/archive/2026-04-18-Test.mov"


def test_archive_toml_is_written_and_uploaded(tmp_path: Path):
    """Die .archive.toml wird erzeugt, hochgeladen und anschliessend lokal entfernt."""
    source = tmp_path / "source-dir"
    source.mkdir()
    video = source / "2026-04-18 Über den Äquätor.mov"
    video.write_bytes(b"x")
    # Stabilen mtime setzen
    mtime_ts = 1713442330.0  # 2024-04-18T...
    os.utime(video, (mtime_ts, mtime_ts))

    work = tmp_path / "work"
    calls: list[list[str]] = []

    # Wir wollen die .archive.toml inspizieren, bevor sie aufgeräumt wird.
    # Lösung: der Mock speichert den copyto-Inhalt.
    uploaded_metadata: dict[str, bytes] = {}

    def fake_run(*args, **kwargs):
        args_list = args[0]
        calls.append(list(args_list))
        if args_list[1] == "copyto" and args_list[3].endswith(".archive.toml"):
            # Lokale Datei einlesen, solange sie noch existiert
            local = Path(args_list[2])
            uploaded_metadata[args_list[3]] = local.read_bytes()
        if args_list[1] == "lsf":
            size = video.stat().st_size
            return subprocess.CompletedProcess(
                args=args_list, returncode=0,
                stdout=(
                    f"{size};2026-04-18-Ueber-den-Aequaetor.mov\n"
                    f"0;2026-04-18-Ueber-den-Aequaetor.archive.toml\n"
                ),
                stderr="",
            )
        return subprocess.CompletedProcess(args=args_list, returncode=0, stdout="", stderr="")

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake_run):
        result = archive_video(
            source_path=video,
            archive_target="nas:/archive",
            recording_date="2026-04-18",
            title="Über den Äquätor",
            description="Mehrzeilig:\nZeile 2 mit Umlaut ä und \"Zitat\".",
            work_dir=work,
        )

    assert result.success is True, result.error_message

    # Die .archive.toml wurde mit dem Slug-Namen hochgeladen
    assert any(
        k.endswith("2026-04-18-Ueber-den-Aequaetor.archive.toml")
        for k in uploaded_metadata
    ), f"Erwartetes .archive.toml-Upload-Ziel nicht gefunden: {list(uploaded_metadata)}"

    payload = next(iter(uploaded_metadata.values()))
    parsed = tomllib.loads(payload.decode("utf-8"))
    assert parsed["original_filename"] == "2026-04-18 Über den Äquätor.mov"
    assert parsed["title"] == "Über den Äquätor"
    assert parsed["description"] == "Mehrzeilig:\nZeile 2 mit Umlaut ä und \"Zitat\"."
    assert parsed["recording_date"].isoformat() == "2026-04-18"
    # original_mtime wird als TOML-Datetime geparst
    assert str(parsed["original_mtime"]).startswith("20")
    assert parsed["schema_version"] == 1

    # Lokale .archive.toml darf nicht zurückbleiben
    assert not any(p.name.endswith(".archive.toml") for p in work.iterdir()), (
        f"Lokale .archive.toml wurde nicht aufgeräumt: {list(work.iterdir())}"
    )


def test_size_mismatch_fails_verification(tmp_path: Path):
    """Wenn die Ziel-Dateigrösse nicht mit der Quelle übereinstimmt, schlägt der Verify fehl."""
    source = tmp_path / "src"
    source.mkdir()
    video = source / "2026-04-18 Test.mov"
    video.write_bytes(b"hundred bytes ...")
    actual_size = video.stat().st_size

    work = tmp_path / "work"
    wrong_size = actual_size - 1  # simulierter Truncation-Fehler

    def fake_run(*args, **kwargs):
        args_list = args[0]
        if args_list[1] == "lsf":
            return subprocess.CompletedProcess(
                args=args_list, returncode=0,
                stdout=(
                    f"{wrong_size};2026-04-18-Test.mov\n"
                    f"100;2026-04-18-Test.archive.toml\n"
                ),
                stderr="",
            )
        return subprocess.CompletedProcess(args=args_list, returncode=0, stdout="", stderr="")

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake_run):
        result = archive_video(
            source_path=video,
            archive_target="nas:/archive",
            recording_date="2026-04-18",
            title="Test",
            work_dir=work,
        )

    assert result.success is False
    assert "Grösse" in (result.error_message or "") or "weicht" in (result.error_message or "")


def test_settings_sidecar_copied_separately(tmp_path: Path):
    """Die ``.settings.toml`` wird unverändert per eigenem copyto daneben kopiert."""
    source = tmp_path / "src"
    source.mkdir()
    video = source / "2026-04-18 Test.mov"
    video.write_bytes(b"v")
    settings = source / "2026-04-18 Test.settings.toml"
    settings.write_text('[web]\nweb_id = "abc"\n', encoding="utf-8")
    size = video.stat().st_size

    work = tmp_path / "work"
    calls: list[list[str]] = []
    lsf = (
        f"{size};2026-04-18-Test.mov\n"
        "100;2026-04-18-Test.settings.toml\n"
        "200;2026-04-18-Test.archive.toml\n"
    )

    with patch(
        "familienfilm_manager.core._rclone.subprocess.run",
        side_effect=_make_rclone_mock(calls, lsf),
    ):
        result = archive_video(
            source_path=video,
            archive_target="nas:/archive",
            recording_date="2026-04-18",
            title="Test",
            work_dir=work,
        )

    assert result.success is True, result.error_message

    # Copyto mit settings.toml-Source und passendem Zielnamen
    assert any(
        c[1] == "copyto"
        and c[2] == str(settings)
        and c[3] == "nas:/archive/2026-04-18-Test.settings.toml"
        for c in calls
    ), f"Kein separater copyto für settings.toml gefunden: {calls}"


def test_no_archive_target_returns_error(tmp_path: Path):
    """Ohne konfiguriertes Archiv-Ziel schlägt der Aufruf sofort mit klarer Meldung fehl."""
    video = tmp_path / "2026-04-18 Test.mov"
    video.write_bytes(b"x")
    result = archive_video(
        source_path=video,
        archive_target="",
        recording_date="2026-04-18",
        title="Test",
    )
    assert result.success is False
    assert "archive" in (result.error_message or "").lower()
