"""Verzeichnis-Publisher: Publiziert alle qualifizierten Videos in einem Verzeichnis sequenziell."""

from __future__ import annotations

import time
from collections.abc import Callable
from pathlib import Path

from familienfilm_manager.api.models import (
    DirectoryPublishResult,
    FamilienfilmEvent,
    FamilienfilmStage,
    PublishRequest,
    PublishResult,
    RuntimeOptions,
    VideoStatus,
    VideoStatusKind,
)
from familienfilm_manager.core.metadata_extractor import _DATE_PREFIX_RE
from familienfilm_manager.core.publisher import run_publish
from familienfilm_manager.core.directory_settings import find_directory_settings
from familienfilm_manager.core.sidecar_manager import (
    compute_source_fingerprint,
    read_sidecar,
)
from familienfilm_manager.core.source_ref import SourceRef


def _to_source_ref(directory: Path | str | SourceRef) -> SourceRef:
    """Normalisiert verschiedene Eingabetypen zu einem SourceRef."""
    if isinstance(directory, SourceRef):
        return directory
    return SourceRef(str(directory))


# Unterstützte Video-Endungen (lowercase Vergleich)
_VIDEO_EXTENSIONS: frozenset[str] = frozenset({
    ".mov", ".mp4", ".m4v", ".mkv",
})

# Macos-/NLE-„Package"-Endungen: filesystem-technisch Directories, aber
# semantisch undurchsichtige Blobs (FCPXML-Bundles, LumaFusion-Projekte etc.).
# Beim rekursiven Scan dürfen wir nicht hineinlaufen — sonst würden darin
# referenzierte oder gecachte Videos fälschlich als eigenständige Kandidaten
# aufgenommen werden. Der Name eines solchen Package-Verzeichnisses endet
# auf einer dieser Endungen.
_PACKAGE_DIR_EXTENSIONS: frozenset[str] = frozenset({
    ".fcpxmld",     # Final Cut Pro XML bundle
    ".lfpackage",   # LumaFusion-Projekt
})


def _is_package_dir_name(name: str) -> bool:
    """True, wenn der Verzeichnisname wie ein Package (FCPXML, LumaFusion) aussieht."""
    for ext in _PACKAGE_DIR_EXTENSIONS:
        if name.lower().endswith(ext):
            return True
    return False


def _format_directory_settings_msg(parent: Path | str, ds) -> str:
    """Menschenlesbare Zusammenfassung der familienfilm.toml-Auflösung für Verbose-Log.

    Zeigt:
    - Welches Verzeichnis
    - Wo die Settings her kommen (source_uri) — oder ob keine gefunden wurde
    - Welche Werte interpretiert wurden (category, web_enabled)
    """
    parent_label = str(parent)
    if ds.source_uri is None:
        return (
            f"familienfilm.toml für {parent_label}: keine gefunden → "
            "Defaults (category=None, web_enabled=false)"
        )
    # web_enabled darstellen: None = nicht gesetzt (→ Default off)
    web_display = (
        "true" if ds.web_enabled is True
        else ("false" if ds.web_enabled is False else "nicht gesetzt")
    )
    cat_display = f"'{ds.category}'" if ds.category else "nicht gesetzt"
    return (
        f"familienfilm.toml für {parent_label}: {ds.source_uri} → "
        f"category={cat_display}, web_enabled={web_display}"
    )


def _is_qualified_video(path: Path) -> bool:
    """Prüft ob die Datei eine qualifizierte Videodatei ist.

    Kriterien:
    - Reguläre Datei (kein Symlink-Verzeichnis, keine Hidden-Datei)
    - Bekannte Video-Endung
    - Stem matcht das Muster ``<YYYY-MM-DD> <titel>``
    """
    if not path.is_file() or path.name.startswith("."):
        return False
    if path.suffix.lower() not in _VIDEO_EXTENSIONS:
        return False
    return bool(_DATE_PREFIX_RE.match(path.stem))


def _date_from_filename(path: Path) -> str:
    """Extrahiert das Datum aus dem Dateinamen (für Sortierung).

    Setzt voraus, dass der Stem das Datum-Präfix-Muster erfüllt.
    """
    match = _DATE_PREFIX_RE.match(path.stem)
    return match.group(1) if match else "0000-00-00"


def _is_already_published(
    video_path: Path,
    *,
    requires_web: bool = True,
    requires_local: bool = True,
    requires_archive: bool = True,
) -> tuple[bool, str | None]:
    """Prüft ob das Video auf **allen aktiven Kanälen** bereits publiziert wurde
    und inhaltlich unverändert ist.

    Skip-Bedingungen (alle müssen erfüllt sein):

    1. Für jeden aktiven Kanal (Web/Local/Archive) existiert ein
       ``published_at``-Zeitstempel im Sidecar.
    2. Der **per-Kanal Fingerprint** (Dateigrösse + SHA1 der ersten 1 MB)
       stimmt mit der aktuellen Quelle überein. Seit v0.8.0 wird pro Kanal
       separat geprüft — fehlt/veraltet der Fingerprint nur eines Kanals,
       wird beim Republish **nur dieser Kanal** nachgeholt. Für Sidecars
       aus ≤ v0.7.0 wird der Legacy-globale ``[source]``-Block als
       Fallback verwendet.

    Bei Teilerfolgen (z.B. Web erfolgreich, Archive fehlgeschlagen) wird
    der Skip-Check nicht bestanden → beim nächsten Lauf wird das Video
    erneut angepackt und der fehlende Kanal nachgeholt. Damit gehen
    Teilerfolge nie still unter.

    Args:
        video_path: Quellvideo.
        requires_web: ``True`` wenn Web-Kanal aktiv ist (sonst wird
            ``web_published_at`` nicht verlangt). Typisch: ``not skip_web``.
        requires_local: dito für Infuse/LAN-Medienserver (``not skip_infuse``).
        requires_archive: dito für Archiv (``not skip_archive``).

    Returns:
        Tuple aus (skip_möglich, published_at_string_oder_none). Das
        zurückgegebene Zeitstempel ist der **älteste** der aktiven Kanäle
        — so sieht der Nutzer im CLI-Summary, seit wann das Video
        vollständig publiziert ist.

    Legacy-Migration:
        Sidecars aus ≤ 0.6.0-RC (mit ``[web].published_at`` aber ohne
        ``[local]`` / ``[archive]``) werden als „nicht publiziert"
        behandelt → einmaliger voller Republish, der alle drei Kanäle
        aktualisiert. Danach ist der Zustand normalisiert und idempotent.
    """
    from familienfilm_manager.core.sidecar_manager import channel_needs_publish

    sidecar = read_sidecar(video_path)

    # Web-Opt-in: Wenn Sidecar ``[web].enabled`` explizit ``false`` ist
    # (oder nicht gesetzt → Default aus) und der Caller Web verlangt,
    # dann zählt Web lokal nicht als aktiver Kanal.
    if sidecar.web_enabled is False:
        requires_web = False

    # Legacy-Sidecar → Republish erzwingen (einmalig)
    if sidecar.is_legacy_pre_channels:
        return False, sidecar.web_published_at

    # Aktuellen Fingerprint einmal berechnen
    try:
        current_fingerprint = compute_source_fingerprint(video_path)
    except OSError:
        # Datei unlesbar → konservativ: kein Skip.
        any_ts = (
            sidecar.web_published_at
            or sidecar.local_published_at
            or sidecar.archive_published_at
        )
        return False, any_ts

    # Per-Kanal Check: wenn irgendein aktiver Kanal republishen muss → kein Skip
    active_flags = {"web": requires_web, "local": requires_local, "archive": requires_archive}
    for channel, active in active_flags.items():
        if channel_needs_publish(
            sidecar, channel,
            active=active,
            current_fingerprint=current_fingerprint,
        ):
            # Ältester vorhandener Timestamp für die CLI-Anzeige
            any_ts = (
                sidecar.web_published_at
                or sidecar.local_published_at
                or sidecar.archive_published_at
            )
            return False, any_ts

    # Alle aktiven Kanäle sind aktuell → Skip
    timestamps = [
        ts for ts, active in [
            (sidecar.web_published_at, requires_web),
            (sidecar.local_published_at, requires_local),
            (sidecar.archive_published_at, requires_archive),
        ]
        if active and ts
    ]
    oldest = min(timestamps) if timestamps else None
    return True, oldest


def _scan_directory(directory: Path, recursive: bool = False) -> list[Path]:
    """Sammelt alle qualifizierten Videos im Verzeichnis.

    Sortiert chronologisch nach Datum im Dateinamen, älteste zuerst.

    Args:
        directory: Zu durchsuchendes Verzeichnis.
        recursive: Wenn True, werden auch Unterverzeichnisse durchsucht
            (``rglob``). Hidden-Verzeichnisse (mit ``.`` am Anfang) werden
            übersprungen, um Mülldirectories wie ``.Trashes`` oder
            ``.Spotlight-V100`` zu vermeiden. Ebenfalls übersprungen:
            NLE-„Package"-Directories wie ``.fcpxmld`` oder ``.lfpackage`` —
            macOS behandelt sie als Bundles, rekursive Scans dürfen nicht
            in sie hineinlaufen (könnten darin gecachte Medien fälschlich
            als eigenständige Videos aufgreifen).
    """
    if recursive:
        candidates: list[Path] = []
        for p in directory.rglob("*"):
            parts = p.relative_to(directory).parts
            # Hidden-Verzeichnisse im Pfad überspringen (macOS/SMB-Mülldirs)
            if any(part.startswith(".") for part in parts[:-1]):
                continue
            # Package-Directories (FCPXML-Bundle, LumaFusion-Projekt) überspringen
            if any(_is_package_dir_name(part) for part in parts[:-1]):
                continue
            if _is_qualified_video(p):
                candidates.append(p)
    else:
        candidates = [p for p in directory.iterdir() if _is_qualified_video(p)]

    candidates.sort(key=lambda p: (_date_from_filename(p), p.name.lower()))
    return candidates


def _filter_stable_videos(
    candidates: list[Path],
    stability_window_seconds: int,
    on_event: Callable[[FamilienfilmEvent], None] | None,
) -> tuple[list[Path], list[Path]]:
    """Bündel-Stabilitätscheck für wachsende Dateien (z.B. laufende Exporte).

    Misst die Dateigrösse aller Kandidaten, wartet ``stability_window_seconds``
    und misst erneut. Gewachsene Dateien werden als „instabil" aussortiert
    und erst beim nächsten Aufruf/Tick erneut geprüft.

    Returns:
        Tuple aus (stabile_videos, instabile_videos).
    """
    if stability_window_seconds <= 0 or not candidates:
        return candidates, []

    before: dict[Path, int] = {}
    for p in candidates:
        try:
            before[p] = p.stat().st_size
        except OSError:
            before[p] = -1

    time.sleep(stability_window_seconds)

    stable: list[Path] = []
    unstable: list[Path] = []
    for p in candidates:
        try:
            current = p.stat().st_size
        except OSError:
            # Datei verschwunden: als unstable behandeln (nächster Tick entscheidet neu)
            unstable.append(p)
            continue
        if before.get(p, -1) == current:
            stable.append(p)
        else:
            unstable.append(p)
            if on_event:
                on_event(FamilienfilmEvent(
                    stage_id=FamilienfilmStage.DIRECTORY_VIDEO_UNSTABLE,
                    message=f"Datei wächst noch, überspringe diesen Durchlauf: {p.name}",
                ))
    return stable, unstable


def _filter_stable_remote_videos(
    candidates: list,  # list[RemoteVideoRef]
    stability_window_seconds: int,
    rclone_path: str,
    on_event: Callable[[FamilienfilmEvent], None] | None,
) -> tuple[list, list]:
    """Stabilitätscheck für rclone-Quellen via zwei ``rclone lsjson``-Snapshots.

    Analog zu ``_filter_stable_videos`` für lokale Pfade, aber ohne
    Filesystem-Zugriff: Die erste Messung kommt aus dem bereits durchgeführten
    ``scan_rclone_directory`` (``RemoteVideoRef.size_bytes``). Nach
    ``stability_window_seconds`` wird pro Parent-Verzeichnis **einmal**
    ``rclone lsjson`` aufgerufen (Bündel-Cache), und für jedes Video werden
    Size + ModTime mit der ersten Messung verglichen.

    Bandbreiten-sparsam: Ein lsjson pro Parent, nicht pro Video.
    """
    if stability_window_seconds <= 0 or not candidates:
        return candidates, []

    from familienfilm_manager.core._rclone import rclone_lsjson
    from familienfilm_manager.core.source_ref import SourceRef

    # Erste Messung (size + modtime): size aus RemoteVideoRef, modtime aus
    # erneutem lsjson-Call oben. Um exakt zu sein, holen wir beide Werte
    # konsistent aus einem frischen Pre-Sleep-Snapshot pro Parent.
    def _snapshot(parent_uri: str) -> dict[str, tuple[int, str]]:
        """Liefert {filename: (size, modtime_str)} für ein Parent-Verzeichnis."""
        try:
            entries = rclone_lsjson(parent_uri, rclone_path=rclone_path)
        except Exception:
            return {}
        result: dict[str, tuple[int, str]] = {}
        for entry in entries:
            if entry.get("IsDir"):
                continue
            name = entry.get("Name", "")
            if not name:
                continue
            size = int(entry.get("Size", -1))
            modtime = str(entry.get("ModTime", ""))
            result[name] = (size, modtime)
        return result

    # Parent-URIs sammeln (pro Kandidat) und vor Sleep snapshotten
    parent_cache_before: dict[str, dict[str, tuple[int, str]]] = {}
    for ref in candidates:
        parent = SourceRef(ref.uri).parent_uri()
        if parent not in parent_cache_before:
            parent_cache_before[parent] = _snapshot(parent)

    time.sleep(stability_window_seconds)

    # Zweiter Snapshot nach Sleep — gleicher Parent-Cache neu aufbauen
    parent_cache_after: dict[str, dict[str, tuple[int, str]]] = {}
    for parent in parent_cache_before:
        parent_cache_after[parent] = _snapshot(parent)

    stable, unstable = [], []
    for ref in candidates:
        parent = SourceRef(ref.uri).parent_uri()
        before = parent_cache_before.get(parent, {}).get(ref.name)
        after = parent_cache_after.get(parent, {}).get(ref.name)
        if before is None or after is None:
            # Datei aus einem der beiden Snapshots verschwunden: als unstable
            # behandeln (nächster Tick entscheidet neu).
            unstable.append(ref)
            if on_event:
                on_event(FamilienfilmEvent(
                    stage_id=FamilienfilmStage.DIRECTORY_VIDEO_UNSTABLE,
                    message=f"Datei im Remote nicht (mehr) vorhanden, überspringe: {ref.name}",
                ))
            continue
        if before == after:
            stable.append(ref)
        else:
            unstable.append(ref)
            if on_event:
                on_event(FamilienfilmEvent(
                    stage_id=FamilienfilmStage.DIRECTORY_VIDEO_UNSTABLE,
                    message=f"Datei wächst noch (rclone), überspringe diesen Durchlauf: {ref.name}",
                ))
    return stable, unstable


def run_publish_directory(
    directory: Path | str,
    runtime: RuntimeOptions | None = None,
    on_event: Callable[[FamilienfilmEvent], None] | None = None,
    skip_infuse: bool = False,
    skip_web: bool = False,
    web_enabled: bool = False,
    skip_archive: bool = False,
    force: bool = False,
    dry_run: bool = False,
    work_dir: Path | None = None,
    stability_window_seconds: int = 0,
    category: str | None = None,
    recursive: bool = False,
    delete_source_after_publish: bool = False,
) -> DirectoryPublishResult:
    """Publiziert alle qualifizierten Videos in einem Verzeichnis sequenziell.

    Akzeptiert ab v0.7.0 auch rclone-URIs (``remote:path``). Bei rclone-Quellen
    wird via ``rclone lsjson`` gescannt und per Light-Peek (nur .settings.toml
    herunterladen) entschieden, ob ein Video schon publiziert ist — bevor
    das Video selbst gestaged wird.

    Sortierung: chronologisch nach Datum im Dateinamen (älteste zuerst).
    Filter: Nur Dateien mit Muster ``<YYYY-MM-DD> <titel>.<ext>`` und
    bekannten Video-Endungen.

    Idempotenz: Videos mit Sidecar-``published_at`` auf allen aktiven Kanälen
    und matchender Quelldatei-Größe werden übersprungen. Mit ``force=True``
    werden alle Videos neu publiziert.

    Args:
        directory: Verzeichnis mit Quell-Videos — lokaler Pfad oder rclone-URI.
        runtime: Technische Laufzeitoptionen.
        on_event: Optionaler Event-Callback (durchgereicht an run_publish).
        skip_infuse/skip_web/skip_archive: Profil-Schalter.
        force: Auch bereits publizierte Videos neu publizieren.
        dry_run: Nur anzeigen welche Videos publiziert würden, nicht ausführen.
        work_dir: Arbeitsverzeichnis für temporäre Dateien (bei rclone-Quellen
            zwingend erforderlich fürs Staging).
        stability_window_seconds: Bei lokalen Quellen aktive Dateigrößen-
            Snapshots zur Erkennung wachsender Dateien. Bei rclone-Quellen
            aktuell nicht unterstützt (Kandidat für v0.8.0).
        category: Default-Kategorie für alle Videos.
        recursive: Unterverzeichnisse miteinbeziehen.

    Returns:
        DirectoryPublishResult mit Liste aller Videos und deren Status.
    """
    directory_ref = _to_source_ref(directory)
    result = DirectoryPublishResult(success=True, directory=directory)

    # Pre-Validation: aktive Profile brauchen konfigurierte Targets.
    # Hinweis: Web-Target wird erst pro Video in ``run_publish`` validiert,
    # weil ein persistent gesetzter ``skip_web`` (``familienfilm.toml`` oder
    # Sidecar) das Target irrelevant macht — und das kann pro Video variieren.
    rt = runtime or RuntimeOptions()
    missing_targets: list[str] = []
    if not skip_infuse and not rt.infuse_target:
        missing_targets.append("targets.infuse (oder --no-infuse zum Überspringen)")
    if not skip_archive and not rt.archive_target:
        missing_targets.append("targets.archive (oder --no-archive zum Überspringen)")
    if missing_targets:
        result.success = False
        result.error_message = (
            "Konfigurations-Fehler: Folgende Targets sind nicht konfiguriert: "
            + ", ".join(missing_targets)
        )
        return result

    # ──────────────────────────────────────────────────────────────
    # Dispatch: lokal vs. rclone
    # ──────────────────────────────────────────────────────────────
    if directory_ref.is_rclone:
        return _run_publish_directory_rclone(
            directory_ref, result, rt, on_event,
            skip_infuse=skip_infuse, skip_web=skip_web,
            web_enabled=web_enabled, skip_archive=skip_archive,
            force=force, dry_run=dry_run, work_dir=work_dir,
            stability_window_seconds=stability_window_seconds,
            category=category, recursive=recursive,
            delete_source_after_publish=delete_source_after_publish,
        )

    # Lokaler Pfad
    local_dir = directory_ref.as_local_path()
    if not local_dir.is_dir():
        result.success = False
        result.error_message = f"Verzeichnis nicht gefunden: {local_dir}"
        return result

    candidates = _scan_directory(local_dir, recursive=recursive)
    if not candidates:
        return result

    # Klassifizieren: was wird publiziert, was übersprungen.
    # Web ist per Default **aus**; aktiv nur wenn irgendwo explizit opt-in:
    #   1. ``--no-web`` (skip_web) → immer aus, gewinnt gegen alles
    #   2. Sidecar ``[web].enabled`` (closest, selbsttragend aus Archiv)
    #   3. Directory-Default ``web_enabled = true`` in ``familienfilm.toml``
    #   4. CLI ``--web`` (web_enabled) als Fallback
    # Per-Parent-Cache verhindert, dass die Directory-Kette pro Video wieder
    # aufsteigend abgelaufen wird.
    dir_web_enabled_cache: dict[Path, bool | None] = {}
    dir_settings_logged: set[Path] = set()

    def _effective_web_enabled_local(video_path: Path) -> bool:
        if skip_web:
            return False
        sidecar = read_sidecar(video_path)
        if sidecar.web_enabled is not None:
            return sidecar.web_enabled
        parent = video_path.parent
        if parent not in dir_web_enabled_cache:
            ds = find_directory_settings(start=parent, stop_at=local_dir)
            dir_web_enabled_cache[parent] = ds.web_enabled
            # Verbose-Log: zeige die aufgelöste familienfilm.toml pro Parent-Dir
            # (einmal pro Dir, nicht pro Video). Gibt Sicherheit, welche Datei
            # wirklich greift und wie sie interpretiert wurde.
            if on_event and parent not in dir_settings_logged:
                dir_settings_logged.add(parent)
                on_event(FamilienfilmEvent(
                    stage_id=FamilienfilmStage.DIRECTORY_SETTINGS_RESOLVED,
                    message=_format_directory_settings_msg(parent, ds),
                ))
        dir_value = dir_web_enabled_cache[parent]
        if dir_value is not None:
            return dir_value
        return web_enabled

    to_publish: list[Path] = []
    for video_path in candidates:
        if force:
            to_publish.append(video_path)
            continue
        effective_web_enabled_for_video = _effective_web_enabled_local(video_path)
        skip, published_at = _is_already_published(
            video_path,
            requires_web=effective_web_enabled_for_video,
            requires_local=not skip_infuse,
            requires_archive=not skip_archive,
        )
        if skip:
            result.videos.append(VideoStatus(
                path=video_path,
                kind=VideoStatusKind.SKIPPED,
                published_at=published_at,
            ))
        else:
            to_publish.append(video_path)

    skipped_count = len(result.videos)
    pending_count = len(to_publish)

    if on_event:
        on_event(FamilienfilmEvent(
            stage_id=FamilienfilmStage.DIRECTORY_SCANNED,
            message=f"{len(candidates)} qualifizierte Videos: {skipped_count} übersprungen, {pending_count} zu publizieren",
        ))

    # Dry-Run: pending Videos nur als PENDING markieren
    if dry_run:
        for video_path in to_publish:
            result.videos.append(VideoStatus(path=video_path, kind=VideoStatusKind.PENDING))
        return result

    # Stabilitätscheck (gegen wachsende Dateien, z.B. laufender LumaFusion-Export).
    # Einzige Wartezeit gilt für alle Kandidaten gemeinsam.
    to_publish, unstable = _filter_stable_videos(
        to_publish, stability_window_seconds, on_event,
    )
    for video_path in unstable:
        result.videos.append(VideoStatus(
            path=video_path,
            kind=VideoStatusKind.UNSTABLE,
        ))
    pending_count = len(to_publish)

    # Sequenziell publizieren
    for index, video_path in enumerate(to_publish, start=1):
        if on_event:
            on_event(FamilienfilmEvent(
                stage_id=FamilienfilmStage.DIRECTORY_VIDEO_STARTED,
                message=f"[{index}/{pending_count}] Publiziere: {video_path.name}",
            ))

        publish_request = PublishRequest(
            source_path=video_path,
            category=category,
            skip_infuse=skip_infuse,
            skip_web=skip_web,
            web_enabled=web_enabled,
            skip_archive=skip_archive,
            force=force,
            work_dir=work_dir,
            scan_root=str(local_dir),
            delete_source_after_publish=delete_source_after_publish,
        )
        publish_result: PublishResult
        try:
            publish_result = run_publish(publish_request, runtime, on_event=on_event)
        except Exception as e:
            publish_result = PublishResult(success=False, error_message=str(e))

        if publish_result.success:
            result.videos.append(VideoStatus(
                path=video_path,
                kind=VideoStatusKind.PUBLISHED,
                publish_result=publish_result,
            ))
        else:
            result.videos.append(VideoStatus(
                path=video_path,
                kind=VideoStatusKind.FAILED,
                error_message=publish_result.error_message,
            ))
            if on_event:
                on_event(FamilienfilmEvent(
                    stage_id=FamilienfilmStage.DEPLOY_FAILED,
                    message=(
                        f"[{index}/{pending_count}] {video_path.name}: "
                        f"{publish_result.error_message or 'unbekannter Fehler'}"
                    ),
                ))

    # Gesamtergebnis: success=False wenn mindestens ein Video fehlschlug
    if any(v.kind == VideoStatusKind.FAILED for v in result.videos):
        result.success = False

    return result


def _run_publish_directory_rclone(
    directory_ref: SourceRef,
    result: DirectoryPublishResult,
    rt: RuntimeOptions,
    on_event: Callable[[FamilienfilmEvent], None] | None,
    *,
    skip_infuse: bool,
    skip_web: bool,
    web_enabled: bool,
    skip_archive: bool,
    force: bool,
    dry_run: bool,
    work_dir: Path | None,
    stability_window_seconds: int,
    category: str | None,
    recursive: bool,
    delete_source_after_publish: bool = False,
) -> DirectoryPublishResult:
    """Rclone-Variante von ``run_publish_directory``.

    Unterschiede zum lokalen Pfad:
    - Scan via ``rclone lsjson`` (remote_scanner)
    - Skip-Check via Light-Peek (nur .settings.toml wird geladen)
    - Pro Video wird ``PublishRequest.source_uri`` gesetzt (nicht source_path)
    - Stability-Check seit v0.8.0 auch für rclone-Quellen aktiv
      (zwei ``rclone lsjson``-Snapshots pro Parent-Verzeichnis).
    """
    from familienfilm_manager.core.remote_scanner import (
        is_remote_video_already_published,
        scan_rclone_directory,
    )

    if work_dir is None:
        result.success = False
        result.error_message = (
            "rclone-Quelle braucht paths.work_dir für das Staging. "
            "Setze config: familienfilm-manager config set paths.work_dir '/pfad/lokal'"
        )
        return result

    candidates = scan_rclone_directory(
        directory_ref.uri,
        recursive=recursive,
        rclone_path=rt.rclone_path,
    )
    if not candidates:
        return result

    # Klassifizieren via Light-Peek.
    # Directory-Level ``skip_web`` per Parent-URI cachen, damit die
    # ``familienfilm.toml``-Kette nicht pro Video neu traversiert wird.
    # Web ist per Default AUS; Sidecar-Override wird in Light-Peek berücksichtigt.
    rclone_dir_web_enabled_cache: dict[str, bool | None] = {}
    rclone_dir_settings_logged: set[str] = set()

    def _effective_web_enabled_remote(video_ref) -> bool:
        if skip_web:
            return False
        parent = SourceRef(video_ref.uri).parent_uri()
        if parent not in rclone_dir_web_enabled_cache:
            ds = find_directory_settings(
                start=parent,
                stop_at=directory_ref.uri,
                rclone_path=rt.rclone_path,
            )
            rclone_dir_web_enabled_cache[parent] = ds.web_enabled
            if on_event and parent not in rclone_dir_settings_logged:
                rclone_dir_settings_logged.add(parent)
                on_event(FamilienfilmEvent(
                    stage_id=FamilienfilmStage.DIRECTORY_SETTINGS_RESOLVED,
                    message=_format_directory_settings_msg(parent, ds),
                ))
        dir_value = rclone_dir_web_enabled_cache[parent]
        if dir_value is not None:
            return dir_value
        return web_enabled

    to_publish = []  # list[RemoteVideoRef]
    for video_ref in candidates:
        if force:
            to_publish.append(video_ref)
            continue
        effective_web_enabled_for_video = _effective_web_enabled_remote(video_ref)
        skip, published_at = is_remote_video_already_published(
            video_ref.uri,
            size_bytes=video_ref.size_bytes,
            requires_web=effective_web_enabled_for_video,
            requires_local=not skip_infuse,
            requires_archive=not skip_archive,
            rclone_path=rt.rclone_path,
        )
        if skip:
            result.videos.append(VideoStatus(
                path=Path(video_ref.uri),   # Pfad-Objekt für einheitliche Schnittstelle;
                                             # bei rclone enthält es den URI-String
                kind=VideoStatusKind.SKIPPED,
                published_at=published_at,
            ))
        else:
            to_publish.append(video_ref)

    skipped_count = len(result.videos)
    pending_count = len(to_publish)

    if on_event:
        on_event(FamilienfilmEvent(
            stage_id=FamilienfilmStage.DIRECTORY_SCANNED,
            message=(
                f"{len(candidates)} qualifizierte Videos (rclone): "
                f"{skipped_count} übersprungen, {pending_count} zu publizieren"
            ),
        ))

    # Dry-Run: pending Videos nur als PENDING markieren
    if dry_run:
        for video_ref in to_publish:
            result.videos.append(VideoStatus(
                path=Path(video_ref.uri),
                kind=VideoStatusKind.PENDING,
            ))
        return result

    # Stabilitätscheck für rclone-Quellen (seit v0.8.0): zwei lsjson-Snapshots
    # pro Parent-Verzeichnis mit Bündel-Sleep. Videos, deren Size oder ModTime
    # sich zwischen den Snapshots ändert (z.B. laufende Upload-Synchronisation),
    # werden als UNSTABLE ausgefiltert und erst beim nächsten Tick erneut geprüft.
    to_publish, unstable_remote = _filter_stable_remote_videos(
        to_publish, stability_window_seconds, rt.rclone_path, on_event,
    )
    for video_ref in unstable_remote:
        result.videos.append(VideoStatus(
            path=Path(video_ref.uri),
            kind=VideoStatusKind.UNSTABLE,
        ))
    pending_count = len(to_publish)

    # Sequenziell publizieren
    for index, video_ref in enumerate(to_publish, start=1):
        if on_event:
            on_event(FamilienfilmEvent(
                stage_id=FamilienfilmStage.DIRECTORY_VIDEO_STARTED,
                message=f"[{index}/{pending_count}] Publiziere (rclone): {video_ref.name}",
            ))

        publish_request = PublishRequest(
            source_uri=video_ref.uri,
            category=category,
            skip_infuse=skip_infuse,
            skip_web=skip_web,
            web_enabled=web_enabled,
            skip_archive=skip_archive,
            force=force,
            work_dir=work_dir,
            scan_root=directory_ref.uri,
            delete_source_after_publish=delete_source_after_publish,
        )
        publish_result: PublishResult
        try:
            publish_result = run_publish(publish_request, rt, on_event=on_event)
        except Exception as e:
            publish_result = PublishResult(success=False, error_message=str(e))

        if publish_result.success:
            result.videos.append(VideoStatus(
                path=Path(video_ref.uri),
                kind=VideoStatusKind.PUBLISHED,
                publish_result=publish_result,
            ))
        else:
            result.videos.append(VideoStatus(
                path=Path(video_ref.uri),
                kind=VideoStatusKind.FAILED,
                error_message=publish_result.error_message,
            ))
            if on_event:
                on_event(FamilienfilmEvent(
                    stage_id=FamilienfilmStage.DEPLOY_FAILED,
                    message=(
                        f"[{index}/{pending_count}] {video_ref.name}: "
                        f"{publish_result.error_message or 'unbekannter Fehler'}"
                    ),
                ))

    if any(v.kind == VideoStatusKind.FAILED for v in result.videos):
        result.success = False

    return result
