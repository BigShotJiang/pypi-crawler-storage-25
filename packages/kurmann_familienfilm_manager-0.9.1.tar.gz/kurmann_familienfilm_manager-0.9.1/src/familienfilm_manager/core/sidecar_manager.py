"""Sidecar-Manager: Lesen/Schreiben von Settings-Dateien neben dem Video."""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from pathlib import Path

import tomllib

# Grösse des Kopf-Samples für den Fingerprint (SHA1 der ersten N Bytes).
# 1 MB ist ein guter Kompromiss: kollisionssicher genug für Identitätsprüfung
# und schnell genug auch auf langsamen Netzwerk-Shares (~100ms bei SMB).
HEAD_HASH_BYTES = 1 * 1024 * 1024


def compute_source_fingerprint(video_path: Path) -> tuple[int, str]:
    """Berechnet (size_bytes, head_sha1_hex) für die Quelldatei.

    Der Fingerprint wird als Identitätsanker verwendet — robuster als mtime,
    die auf SMB/NAS-Shares unzuverlässig ist.
    """
    size = video_path.stat().st_size
    hasher = hashlib.sha1()
    with video_path.open("rb") as f:
        hasher.update(f.read(HEAD_HASH_BYTES))
    return size, hasher.hexdigest()


@dataclass
class SidecarSettings:
    """Persistierte Einstellungen in einer .settings.toml Datei neben dem Video.

    Jeder der drei Deploy-Kanäle (``web``, ``local``, ``archive``) hat einen
    eigenen ``published_at``-Zeitstempel **und** seit v0.8.0 einen eigenen
    Fingerprint (``source_size_bytes`` + ``source_head_sha1``). Beides wird
    nur nach erfolgreichem Deploy dieses Kanals geschrieben. Die Skip-Logik
    bei ``publish-dir`` / ``watch-dir`` verlangt, dass **alle aktiven Kanäle**
    einen Zeitstempel UND einen passenden Fingerprint haben — Teilerfolge
    oder Quelldatei-Änderungen führen zum gezielten Nachholen nur der
    fehlenden/veralteten Kanäle.

    Per-Kanal-Fingerprint (v0.8.0): Wenn sich die Quelldatei ändert aber nur
    ein Kanal hatte zuvor einen Deploy-Fehler, wird nun **nur** dieser
    eine Kanal re-publiziert — nicht alle drei (wie vor v0.8.0).
    """

    # Poster-Einstellungen
    frame_number: int | None = None
    timestamp_seconds: float | None = None
    crop_position: str | None = None

    # Web-Kanal (Hostpoint / öffentlicher Webserver)
    web_id: str | None = None
    max_luminance: int | None = None
    web_published_at: str | None = None
    web_enabled: bool | None = None
    web_source_size_bytes: int | None = None
    web_source_head_sha1: str | None = None

    # Local-Kanal (Infuse / Medienserver im LAN)
    local_published_at: str | None = None
    local_source_size_bytes: int | None = None
    local_source_head_sha1: str | None = None

    # Archive-Kanal (TAR im Langzeit-Archiv)
    archive_published_at: str | None = None
    archive_source_size_bytes: int | None = None
    archive_source_head_sha1: str | None = None

    # Legacy-globaler Fingerprint (≤ v0.7.0). Nur für Read-Fallback —
    # wird beim nächsten Publish durch per-Kanal-Werte ersetzt und ab da
    # nicht mehr geschrieben. Siehe ``fingerprint_for_channel``.
    source_size_bytes: int | None = None
    source_head_sha1: str | None = None

    # Effektive Metadaten (für selbsttragendes Archiv)
    category: str | None = None

    def fingerprint_for_channel(self, channel: str) -> tuple[int | None, str | None]:
        """Liefert (size, head_sha1) für einen Kanal mit Legacy-Fallback.

        Ordnung:
        1. Per-Kanal-Werte (v0.8.0+), wenn beide gesetzt.
        2. Globaler ``[source]``-Block (v0.7.0 und früher).
        3. ``(None, None)`` wenn nichts bekannt.
        """
        per_channel = {
            "web": (self.web_source_size_bytes, self.web_source_head_sha1),
            "local": (self.local_source_size_bytes, self.local_source_head_sha1),
            "archive": (self.archive_source_size_bytes, self.archive_source_head_sha1),
        }.get(channel, (None, None))
        size, head = per_channel
        if size is not None and head is not None:
            return size, head
        return self.source_size_bytes, self.source_head_sha1

    def has_values(self) -> bool:
        """Prüft ob mindestens ein Wert gesetzt ist."""
        return any(v is not None for v in (
            self.frame_number, self.timestamp_seconds, self.crop_position,
            self.web_id, self.max_luminance,
            self.web_published_at, self.web_enabled,
            self.web_source_size_bytes, self.web_source_head_sha1,
            self.local_published_at,
            self.local_source_size_bytes, self.local_source_head_sha1,
            self.archive_published_at,
            self.archive_source_size_bytes, self.archive_source_head_sha1,
            self.source_size_bytes, self.source_head_sha1,
            self.category,
        ))

    @property
    def is_legacy_pre_channels(self) -> bool:
        """Legacy-Sidecar (≤ 0.6.0 RC) mit ``web_published_at`` aber ohne
        ``local_published_at`` oder ``archive_published_at``.

        Semantik des alten ``[web].published_at``: „irgendwas wurde publiziert",
        aber welcher Kanal ist unklar. Konservative Annahme für die Migration:
        behandeln als „noch nicht vollständig publiziert" → nächster Lauf
        republiziert voll und füllt alle drei Zeitstempel.
        """
        return (
            self.web_published_at is not None
            and self.local_published_at is None
            and self.archive_published_at is None
        )


def channel_needs_publish(
    sidecar: SidecarSettings,
    channel: str,
    *,
    active: bool,
    current_fingerprint: tuple[int | None, str | None],
) -> bool:
    """Entscheidet, ob ein Kanal publiziert werden muss.

    Args:
        sidecar: Aktueller Sidecar-Stand.
        channel: ``"web"``, ``"local"`` oder ``"archive"``.
        active: Ob der Kanal für diesen Lauf überhaupt aktiv ist
            (``effective_web_enabled`` / ``not skip_infuse`` / ``not skip_archive``).
        current_fingerprint: ``(size, head_sha1)`` der aktuellen Quelldatei.
            Beim Remote-Light-Peek darf ``head_sha1`` None sein — dann wird
            nur ``size`` verglichen.

    Returns:
        True, wenn der Kanal publiziert/re-publiziert werden muss.
        False, wenn der Kanal inaktiv oder bereits aktuell ist.
    """
    if not active:
        return False

    published_at = {
        "web": sidecar.web_published_at,
        "local": sidecar.local_published_at,
        "archive": sidecar.archive_published_at,
    }.get(channel)

    if not published_at:
        return True

    stored_size, stored_head = sidecar.fingerprint_for_channel(channel)
    current_size, current_head = current_fingerprint

    # Ohne gespeicherten Fingerprint: konservativ republishen (unbekannte Historie).
    if stored_size is None:
        return True

    if current_size is not None and current_size != stored_size:
        return True

    # Head-SHA1 ist bei Remote-Light-Peek nicht verfügbar → nur prüfen wenn beide Seiten da.
    if stored_head is not None and current_head is not None and current_head != stored_head:
        return True

    return False


def sidecar_path_for(video_path: Path) -> Path:
    """Gibt den Pfad zur Sidecar-Datei zurück."""
    return video_path.parent / f"{video_path.stem}.settings.toml"


def read_sidecar(video_path: Path) -> SidecarSettings:
    """Liest die Sidecar-Datei. Gibt leeres SidecarSettings zurück wenn nicht vorhanden."""
    path = sidecar_path_for(video_path)
    if not path.exists():
        return SidecarSettings()

    try:
        data = tomllib.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return SidecarSettings()

    poster = data.get("poster") or {}
    if not isinstance(poster, dict):
        poster = {}

    web = data.get("web") or {}
    if not isinstance(web, dict):
        web = {}

    local = data.get("local") or {}
    if not isinstance(local, dict):
        local = {}

    archive = data.get("archive") or {}
    if not isinstance(archive, dict):
        archive = {}

    source = data.get("source") or {}
    if not isinstance(source, dict):
        source = {}

    metadata = data.get("metadata") or {}
    if not isinstance(metadata, dict):
        metadata = {}

    def _as_int(v):
        return int(v) if v is not None else None

    def _as_float(v):
        return float(v) if v is not None else None

    def _as_str(v):
        return str(v) if v is not None else None

    def _as_bool(v):
        return bool(v) if v is not None else None

    return SidecarSettings(
        frame_number=_as_int(poster.get("frame_number")),
        timestamp_seconds=_as_float(poster.get("timestamp_seconds")),
        crop_position=_as_str(poster.get("crop_position")),
        web_id=_as_str(web.get("web_id")),
        max_luminance=_as_int(web.get("max_luminance")),
        web_published_at=_as_str(web.get("published_at")),
        web_enabled=_as_bool(web.get("enabled")),
        web_source_size_bytes=_as_int(web.get("source_size_bytes")),
        web_source_head_sha1=_as_str(web.get("source_head_sha1")),
        local_published_at=_as_str(local.get("published_at")),
        local_source_size_bytes=_as_int(local.get("source_size_bytes")),
        local_source_head_sha1=_as_str(local.get("source_head_sha1")),
        archive_published_at=_as_str(archive.get("published_at")),
        archive_source_size_bytes=_as_int(archive.get("source_size_bytes")),
        archive_source_head_sha1=_as_str(archive.get("source_head_sha1")),
        source_size_bytes=_as_int(source.get("size_bytes")),
        source_head_sha1=_as_str(source.get("head_sha1")),
        category=_as_str(metadata.get("category")),
    )


def write_sidecar(video_path: Path, settings: SidecarSettings) -> Path:
    """Schreibt die Sidecar-Datei. Nur gesetzte Felder werden geschrieben.

    Returns:
        Pfad zur geschriebenen Datei.
    """
    path = sidecar_path_for(video_path)
    lines: list[str] = []

    def _append_section(name: str, body: list[str]) -> None:
        if not body:
            return
        if lines:
            lines.append("")
        lines.append(f"[{name}]")
        lines.extend(body)

    # [poster]
    poster_lines: list[str] = []
    if settings.frame_number is not None:
        poster_lines.append(f"frame_number = {settings.frame_number}")
    if settings.timestamp_seconds is not None:
        poster_lines.append(f"timestamp_seconds = {settings.timestamp_seconds}")
    if settings.crop_position is not None:
        poster_lines.append(f'crop_position = "{settings.crop_position}"')
    _append_section("poster", poster_lines)

    # [web]
    web_lines: list[str] = []
    if settings.web_id is not None:
        web_lines.append(f'web_id = "{settings.web_id}"')
    if settings.max_luminance is not None:
        web_lines.append(f"max_luminance = {settings.max_luminance}")
    if settings.web_published_at is not None:
        web_lines.append(f'published_at = "{settings.web_published_at}"')
    if settings.web_enabled is not None:
        web_lines.append(f"enabled = {'true' if settings.web_enabled else 'false'}")
    if settings.web_source_size_bytes is not None:
        web_lines.append(f"source_size_bytes = {settings.web_source_size_bytes}")
    if settings.web_source_head_sha1 is not None:
        web_lines.append(f'source_head_sha1 = "{settings.web_source_head_sha1}"')
    _append_section("web", web_lines)

    # [local] (Infuse / LAN-Medienserver)
    local_lines: list[str] = []
    if settings.local_published_at is not None:
        local_lines.append(f'published_at = "{settings.local_published_at}"')
    if settings.local_source_size_bytes is not None:
        local_lines.append(f"source_size_bytes = {settings.local_source_size_bytes}")
    if settings.local_source_head_sha1 is not None:
        local_lines.append(f'source_head_sha1 = "{settings.local_source_head_sha1}"')
    _append_section("local", local_lines)

    # [archive] (TAR-Langzeit-Archiv)
    archive_lines: list[str] = []
    if settings.archive_published_at is not None:
        archive_lines.append(f'published_at = "{settings.archive_published_at}"')
    if settings.archive_source_size_bytes is not None:
        archive_lines.append(f"source_size_bytes = {settings.archive_source_size_bytes}")
    if settings.archive_source_head_sha1 is not None:
        archive_lines.append(f'source_head_sha1 = "{settings.archive_source_head_sha1}"')
    _append_section("archive", archive_lines)

    # Legacy [source] — wird v0.8.0+ nicht mehr geschrieben; Lesen aber weiterhin
    # unterstützt für Migration von Sidecars aus ≤ v0.7.0. Der Fallback greift in
    # ``fingerprint_for_channel()``. Kein Write-Path mehr.

    # [metadata] — effektive Metadaten (für selbsttragendes Archiv)
    metadata_lines: list[str] = []
    if settings.category is not None:
        escaped = settings.category.replace('"', '\\"')
        metadata_lines.append(f'category = "{escaped}"')
    _append_section("metadata", metadata_lines)

    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path
