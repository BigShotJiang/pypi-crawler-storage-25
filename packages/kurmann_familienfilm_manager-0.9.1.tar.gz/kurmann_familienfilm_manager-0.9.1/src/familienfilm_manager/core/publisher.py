"""Hauptorchestrator: Metadaten → Sidecar → Medienset → Deploy → Archiv."""

from __future__ import annotations

import re
import shutil
import tempfile
from datetime import datetime
from pathlib import Path

from mediaset_creator.api import (
    CreateMediasetRequest,
    InfuseProfile,
    MediasetCreatorEvent,
    MediasetCreatorStage,
    PosterSpec,
    RuntimeOptions as MediasetRuntimeOptions,
    WebProfile,
    create_mediaset,
)

from familienfilm_manager.api.models import (
    FamilienfilmEvent,
    FamilienfilmStage,
    PublishRequest,
    PublishResult,
    RuntimeOptions,
)
from familienfilm_manager.core.archiver import archive_video
from familienfilm_manager.core.infuse_deployer import deploy_to_infuse
from familienfilm_manager.core.metadata_extractor import extract_metadata
from familienfilm_manager.core.sidecar_manager import (
    SidecarSettings,
    compute_source_fingerprint,
    read_sidecar,
    sidecar_path_for,
    write_sidecar,
)
from familienfilm_manager.core.source_ref import SourceRef
from familienfilm_manager.core.source_staging import stage_source
from familienfilm_manager.core.web_deployer import deploy_to_web
from familienfilm_manager.services import config_manager

# Gleiche Regex wie in metadata_extractor für Datumspräfix-Erkennung
_DATE_PREFIX_RE = re.compile(r"^(\d{4}-\d{2}-\d{2})\s*[-–]?\s*(.+)$")


def _create_title_symlink(source_path: Path, title: str) -> Path | None:
    """Erstellt einen Symlink ohne Datumspräfix im gleichen Verzeichnis.

    Wenn der Dateiname bereits ein Datumspräfix hat (z.B. "2025-03-24 Wanderung auf den Napf.mov"),
    wird ein Symlink "Wanderung auf den Napf.mov" erstellt. So generiert der mediaset-creator
    saubere Dateinamen im ZIP (ohne doppeltes Datum).

    Returns:
        Pfad zum Symlink oder None wenn kein Symlink nötig war.
    """
    stem = source_path.stem
    match = _DATE_PREFIX_RE.match(stem)
    if not match:
        return None

    link_name = f"{title}{source_path.suffix}"
    link_path = source_path.parent / link_name

    if link_path.exists():
        return None

    try:
        link_path.symlink_to(source_path.resolve())
        return link_path
    except OSError:
        return None


def run_publish(
    request: PublishRequest,
    runtime: RuntimeOptions | None = None,
    on_event=None,
) -> PublishResult:
    """Führt den gesamten Veröffentlichungs-Workflow aus.

    1. Metadaten extrahieren (oder CLI-Werte nutzen)
    2. Sidecar lesen/schreiben (Poster-Einstellungen)
    3. Symlink ohne Datumspräfix erstellen (für saubere Dateinamen)
    4. Medienset via mediaset-creator erstellen (mit Event-basiertem Deployment)
       - INFUSE_READY → sofort Infuse-Deployment via rclone
       - WEB_READY → sofort Web-Deployment via rclone
    5. Optional: Archivierung (immer mit Originaldatei)

    Args:
        request: Fachlicher Publish-Request.
        runtime: Technische Laufzeitoptionen.
        on_event: Optionaler Event-Callback.

    Returns:
        PublishResult mit Gesamtergebnis.
    """
    rt = runtime or RuntimeOptions()

    # --- 0. Pre-Validation (Teil 1): Infuse- und Archive-Targets ---
    # Das Web-Target wird erst nach Auflösung des effektiven ``skip_web``
    # validiert (persistent via ``familienfilm.toml`` oder Sidecar).
    missing_targets: list[str] = []
    if not request.skip_infuse and not rt.infuse_target:
        missing_targets.append("targets.infuse (oder --no-infuse zum Überspringen)")
    if not request.skip_archive and not rt.archive_target:
        missing_targets.append("targets.archive (oder --no-archive zum Überspringen)")

    # --- 1. Staging: für rclone-Quellen wird das Video lokal gestaged ---
    # Für lokale Pfade ist stage_source ein Passthrough (kein Kopieren).
    # Für rclone-URIs wird das Video und alle stem-identischen Sidecars
    # via rclone copyto ins work_dir geholt — der Rest des Publishers läuft
    # unverändert auf dem lokalen Pfad.
    source_ref = request.get_source_ref()
    try:
        staged = stage_source(source_ref, request.work_dir, rt, on_event=on_event)
    except Exception as e:
        return PublishResult(
            success=False,
            error_message=f"Quelle konnte nicht gestaged werden: {e}",
        )

    # ab jetzt arbeiten wir durchgängig mit dem lokalen Pfad — entweder Original
    # (lokale Quelle) oder Staging-Kopie (rclone-Quelle)
    local_source_path: Path = staged.local_video_path

    # --- 2. Metadaten extrahieren ---
    try:
        metadata = extract_metadata(local_source_path, rt.ffprobe_path)
    except ValueError as e:
        if request.recording_date is None:
            staged.cleanup()
            return PublishResult(success=False, error_message=str(e))
        from familienfilm_manager.core.metadata_extractor import VideoMetadata, _parse_filename
        # Fallback: Filename parsen damit Poster-Suffix nicht im Titel landet
        _, fallback_title, fallback_poster_at = _parse_filename(local_source_path.stem)
        metadata = VideoMetadata(
            title=request.title or fallback_title,
            recording_date=request.recording_date,
            description=request.description,
            category=request.category,
            poster_at=fallback_poster_at,
        )

    # Sidecar früh lesen — wird für die Category-Auflösung gebraucht
    # (Sidecar-Metadaten haben Vorrang vor Config-Defaults, damit aus dem Archiv
    # extrahierte Videos ihre ursprüngliche Kategorie behalten).
    sidecar_enabled = (
        not request.no_sidecar
        and config_manager.get_with_default("sidecar.enabled").lower() != "false"
    )
    sidecar = SidecarSettings()
    if sidecar_enabled:
        sidecar = read_sidecar(local_source_path)

    # CLI-Parameter überschreiben extrahierte Werte
    title = request.title or metadata.title
    recording_date = request.recording_date or metadata.recording_date
    description = request.description or metadata.description

    # Verzeichnis-Settings (familienfilm.toml) nach oben suchen — eine in einem
    # höheren Verzeichnis gültige Datei dient als Default für alle Videos darunter.
    # Bei Batch-Läufen (publish-dir/watch-dir) begrenzt scan_root die Suche.
    # Für rclone-Quellen wird die Kette am Original-URI entlang gesucht (via
    # rclone cat), NICHT am lokalen Stage-Pfad.
    from familienfilm_manager.core.directory_settings import find_directory_settings

    directory_settings = find_directory_settings(
        start=source_ref.parent_uri(),
        stop_at=request.scan_root,
        rclone_path=rt.rclone_path,
    )

    # Effektives Web-Opt-in: Web-Veröffentlichung ist **per Default aus**
    # (Safety: versehentliches Publizieren aus dem Archiv ausgeschlossen).
    # Aktiviert wird sie nur explizit — in dieser Priorität:
    #   1. One-Shot-Disable (CLI ``--no-web`` / ``request.skip_web``) gewinnt
    #      gegen alles andere.
    #   2. Sidecar ``[web].enabled`` (persistiert, selbsttragend im Archiv)
    #   3. Directory-Default ``familienfilm.toml`` → ``web_enabled = true``
    #   4. One-Shot-Enable (CLI ``--web`` / ``request.web_enabled``) — für
    #      Ad-hoc-Publishes ohne Config.
    # Nicht gesetzt überall → Web bleibt aus.
    if request.skip_web:
        effective_web_enabled = False
    elif sidecar_enabled and sidecar.web_enabled is not None:
        effective_web_enabled = sidecar.web_enabled
    elif directory_settings.web_enabled is not None:
        effective_web_enabled = directory_settings.web_enabled
    else:
        effective_web_enabled = bool(request.web_enabled)

    # Pre-Validation (Teil 2): Web-Target nur verlangen, wenn Web aktiv.
    if effective_web_enabled and not rt.web_target:
        missing_targets.append("targets.web (oder --no-web / fehlende web_enabled)")
    if missing_targets:
        staged.cleanup()
        return PublishResult(
            success=False,
            error_message=(
                "Konfigurations-Fehler: Folgende Targets sind nicht konfiguriert: "
                + ", ".join(missing_targets)
            ),
        )

    # Category-Auflösungskette:
    #   1. CLI/Request (expliziter Wille)
    #   2. Sidecar-[metadata].category (selbsttragend, Re-Publish aus Archiv)
    #   3. familienfilm.toml (nächstgelegenes Verzeichnis nach oben)
    #   4. defaults.category aus Config (globaler Fallback)
    #   5. ffprobe-Metadata
    category = (
        request.category
        or (sidecar.category if sidecar_enabled else None)
        or directory_settings.category
        or config_manager.get("defaults.category")
        or metadata.category
    )

    if on_event:
        on_event(FamilienfilmEvent(
            stage_id=FamilienfilmStage.METADATA_EXTRACTED,
            message=f"Metadaten: {title} ({recording_date})",
        ))

    # --- Benachrichtigung: Pending-Block schreiben, sobald wir den Titel kennen ---
    # Der Block wird am Ende durch "publiziert" oder "fehlgeschlagen" ersetzt.
    # Bei Prozess-Crashes bleibt er als pending stehen — ein Watch-Start setzt
    # solche Altlasten via mark_all_pending_as_aborted() auf "abgebrochen".
    notification_file = config_manager.get("notification.file")
    video_id: str | None = None
    pending_title = title or local_source_path.stem
    if notification_file:
        from familienfilm_manager.core.notifier import (
            append_pending,
            derive_video_id,
        )

        # video_id basiert auf dem Original-URI (stabil über Staging hinweg)
        video_id = derive_video_id(source_ref.uri)
        append_pending(
            notification_path=Path(notification_file),
            video_id=video_id,
            title=pending_title,
            category=category,
            recording_date=recording_date,
        )

    def _resolve_notification_failed(error_message: str) -> None:
        if notification_file and video_id:
            from familienfilm_manager.core.notifier import replace_entry_failed

            replace_entry_failed(
                notification_path=Path(notification_file),
                video_id=video_id,
                title=pending_title,
                error_message=error_message,
                category=category,
                recording_date=recording_date,
            )

    # --- 2. Poster-/Web-/Luminance-Werte aus Sidecar auflösen, ggf. Sidecar aktualisieren ---
    # (Sidecar wurde bereits oben für die Category-Auflösung gelesen.)

    # Poster-Werte auflösen: CLI > Filename-Suffix > Sidecar
    # poster_at kann zusätzlich aus dem Dateinamen-Suffix " poster-Xmin Y" stammen
    filename_poster_at = metadata.poster_at
    poster_frame = request.poster_frame or sidecar.frame_number
    poster_at = request.poster_at or filename_poster_at or sidecar.timestamp_seconds
    poster_crop = request.poster_crop or sidecar.crop_position

    # Web-ID auflösen: CLI > Sidecar
    web_id = request.web_id or sidecar.web_id

    # max_luminance auflösen: CLI > Sidecar
    max_luminance = request.max_luminance or sidecar.max_luminance

    # Sidecar aktualisieren wenn CLI oder Filename neue Werte liefert
    cli_has_poster = any(v is not None for v in (request.poster_frame, request.poster_at, request.poster_crop))
    filename_has_new_poster_at = (
        filename_poster_at is not None
        and filename_poster_at != sidecar.timestamp_seconds
    )
    cli_has_updates = cli_has_poster or request.max_luminance is not None or filename_has_new_poster_at
    if sidecar_enabled and cli_has_updates:
        updated = SidecarSettings(
            frame_number=poster_frame,
            timestamp_seconds=poster_at,
            crop_position=poster_crop,
            web_id=web_id,
            max_luminance=max_luminance,
        )
        if updated.has_values():
            write_sidecar(local_source_path, updated)

    # --- 3. Symlink ohne Datumspräfix für mediaset-creator ---
    # Bei rclone-Quellen arbeiten wir im Stage-Dir — Symlink dort funktioniert
    # normal. Das saubere Umbenennen kommt im mediaset-creator-Output an.
    title_symlink = _create_title_symlink(local_source_path, title)
    mediaset_source = title_symlink or local_source_path

    # --- 4. Profile und Request aufbauen ---
    # PosterSpec erstellen wenn Poster-Parameter vorhanden
    poster = None
    if any(v is not None for v in (poster_frame, poster_at, poster_crop)):
        poster = PosterSpec(
            frame_number=poster_frame,
            timestamp_seconds=poster_at,
            crop_position=poster_crop,
        )

    # Basisverzeichnis für temporäre Ausgaben: work_dir > lokales Quellverzeichnis.
    # Bei gestageder Quelle ist local_source_path.parent das Stage-Dir — dort landen
    # Infuse-/Web-Tmp-Dirs als Geschwister, was beim Cleanup automatisch mit aufgeräumt wird.
    base_dir = request.work_dir or local_source_path.parent

    # --- Per-Kanal-Fingerprint-Gate (v0.8.0) ---
    # Aktueller Fingerprint der (evtl. gestageden) Quelldatei. Wird gegen
    # gespeicherte per-Kanal-Fingerprints im Sidecar verglichen. Ziel: Kanäle,
    # die bereits aktuell und erfolgreich deployed sind, im Mediaset-Bau
    # überspringen — Bandbreite und Zeit sparen bei Partial-Failure-Nachlauf.
    # ``--force`` umgeht das Gate komplett.
    try:
        current_fingerprint = compute_source_fingerprint(local_source_path)
    except OSError:
        current_fingerprint = (None, None)

    from familienfilm_manager.core.sidecar_manager import channel_needs_publish

    infuse_active = bool(not request.skip_infuse and rt.infuse_target)
    web_active = bool(effective_web_enabled)
    archive_active = bool(not request.skip_archive and rt.archive_target)

    if request.force or not sidecar_enabled:
        needs_web = web_active
        needs_local = infuse_active
        needs_archive = archive_active
    else:
        needs_web = channel_needs_publish(
            sidecar, "web", active=web_active, current_fingerprint=current_fingerprint,
        )
        needs_local = channel_needs_publish(
            sidecar, "local", active=infuse_active, current_fingerprint=current_fingerprint,
        )
        needs_archive = channel_needs_publish(
            sidecar, "archive", active=archive_active, current_fingerprint=current_fingerprint,
        )

    # Infuse-Profil: nur bauen wenn Kanal aktiv UND nicht bereits aktuell
    infuse_tmp_dir: Path | None = None
    infuse_profile: InfuseProfile | None = None
    if needs_local:
        infuse_tmp_dir = Path(tempfile.mkdtemp(prefix="familienfilm-infuse-", dir=base_dir))
        infuse_profile = InfuseProfile(output_dir=infuse_tmp_dir)

    # Web-Profil: Web-ID-Unterverzeichnis wird automatisch erstellt
    # Merken ob Verzeichnis temporär (selbst erstellt) oder explizit (--output-dir) ist —
    # nur temporäre werden nach erfolgreichem Deployment aufgeräumt.
    web_profile: WebProfile | None = None
    web_tmp_dir: Path | None = None
    if needs_web:
        if request.output_dir:
            web_output = request.output_dir
        else:
            web_tmp_dir = Path(tempfile.mkdtemp(prefix="familienfilm-web-", dir=base_dir))
            web_output = web_tmp_dir
        web_profile = WebProfile(
            output_dir=web_output,
            include_zip=True,
            enable_og_tags=bool(rt.branding_base_url),
        )

    # Mindestens ein Profil ODER Archiv-Republish muss zu tun haben
    if infuse_profile is None and web_profile is None and not needs_archive:
        # Nichts zu tun — weder Mediaset noch Archive. Als Erfolg melden
        # (wird vom directory_publisher-Skip-Check ohnehin vorher abgefangen;
        # dieser Zweig greift für Einzel-``publish``-Aufrufe).
        return PublishResult(success=True)

    mediaset_request = CreateMediasetRequest(
        source_path=mediaset_source,
        title=title,
        description=description,
        category=category,
        recording_date=recording_date,
        poster=poster,
        mediaset_title=title,
        work_dir=request.work_dir,
        infuse=infuse_profile,
        web=web_profile,
        web_id=web_id,
        max_luminance=request.max_luminance,
        force=request.force,
    )

    mediaset_runtime = MediasetRuntimeOptions(
        base_url=rt.branding_base_url,
        ffmpeg_path=rt.ffmpeg_path,
        ffprobe_path=rt.ffprobe_path,
    )

    # Result-Objekt, das im Callback befüllt wird
    result = PublishResult(success=True)

    # Per-Kanal Zeitstempel beim jeweils erfolgreichen Deploy — fliesst am Ende
    # ins Sidecar als [web]/[local]/[archive].published_at. Fehlgeschlagene Kanäle
    # bleiben None → beim nächsten Lauf erkennt der Skip-Check den Teilerfolg
    # und holt den fehlenden Kanal nach.
    channel_timestamps: dict[str, str | None] = {
        "web": None,
        "local": None,
        "archive": None,
    }

    def _now_iso() -> str:
        return datetime.now().isoformat(timespec="seconds")

    # Event-Callback mit integriertem Deployment
    # Mutable Flag für den finally-Block: unterscheidet "Deploy nie versucht"
    # (Mediaset-Fehler vor INFUSE_READY → Temp aufräumen) von "Deploy versucht,
    # fehlgeschlagen" (Medienset fertig aufgebaut → erhalten für Nachholen).
    infuse_deploy_attempted = [False]

    def _handle_mediaset_event(event: MediasetCreatorEvent) -> None:
        # Events an den Familienfilm-Manager durchreichen
        if on_event:
            on_event(FamilienfilmEvent(
                stage_id=event.stage_id,
                message=event.message,
                paths=event.paths,
            ))

        # Auf Milestone-Events reagieren → sofort deployen
        if event.stage_id == MediasetCreatorStage.INFUSE_READY and rt.infuse_target:
            infuse_deploy_attempted[0] = True
            deploy_result = deploy_to_infuse(
                source_dir=Path(event.paths["output_dir"]),
                infuse_target=rt.infuse_target,
                rclone_path=rt.rclone_path,
                recording_date=recording_date,
                group_by=rt.infuse_group_by,
                on_event=on_event,
            )
            result.infuse_deployed = deploy_result.success
            if deploy_result.success:
                channel_timestamps["local"] = _now_iso()
            else:
                result.error_message = deploy_result.error_message

        elif event.stage_id == MediasetCreatorStage.WEB_READY and rt.web_target:
            deploy_result = deploy_to_web(
                source_dir=Path(event.paths["output_dir"]),
                web_target=rt.web_target,
                rclone_path=rt.rclone_path,
                on_event=on_event,
            )
            result.web_deployed = deploy_result.success
            if deploy_result.success:
                channel_timestamps["web"] = _now_iso()
            else:
                result.error_message = deploy_result.error_message

    try:
        mediaset_result = create_mediaset(
            mediaset_request,
            mediaset_runtime,
            on_event=_handle_mediaset_event,
        )
    finally:
        # Symlink immer aufräumen
        if title_symlink and title_symlink.is_symlink():
            title_symlink.unlink()
        # Infuse-Temp-Verzeichnis:
        # - Deploy erfolgreich → aufräumen
        # - Deploy versucht und fehlgeschlagen → erhalten, Hinweis ausgeben
        # - Deploy nie versucht (Mediaset-Fehler vor INFUSE_READY) → aufräumen
        if infuse_tmp_dir:
            if result.infuse_deployed or not infuse_deploy_attempted[0]:
                shutil.rmtree(infuse_tmp_dir, ignore_errors=True)
            elif on_event:
                on_event(FamilienfilmEvent(
                    stage_id=FamilienfilmStage.DEPLOY_FAILED,
                    message=(
                        f"Infuse-Medienset erhalten für manuelles Nachdeployment: "
                        f"{infuse_tmp_dir}\n"
                        f"  Retry: familienfilm-manager deploy-infuse '{infuse_tmp_dir}'"
                    ),
                ))

    if not mediaset_result.success:
        msg = f"Medienset-Erstellung fehlgeschlagen: {mediaset_result.error_message}"
        # Wichtig: stderr-Event, sonst geht der eigentliche Grund in watch-dir /
        # publish-dir lautlos verloren (nur „1 fehlgeschlagen" im Tick-Summary).
        if on_event:
            on_event(FamilienfilmEvent(
                stage_id=FamilienfilmStage.DEPLOY_FAILED,
                message=msg,
            ))
        _resolve_notification_failed(msg)
        return PublishResult(success=False, error_message=msg)

    # Result-Felder aus dem Mediaset-Result befüllen
    if mediaset_result.infuse:
        result.infuse_dir = mediaset_result.infuse.output_dir
    if mediaset_result.web:
        result.web_dir = mediaset_result.web.output_dir
        result.web_id = mediaset_result.web.web_id

    if on_event:
        on_event(FamilienfilmEvent(
            stage_id=FamilienfilmStage.MEDIASET_CREATED,
            message=f"Medienset erstellt: {result.web_dir or result.infuse_dir}",
        ))

    # --- 5. Archivierung (immer mit Originaldatei, nicht Symlink) ---
    # Der Archiver packt die lokale Quelldatei (bei rclone-Quelle: Stage-Kopie) +
    # alle stem-identischen Produktions-Sidecars ins TAR. Die .settings.toml geht
    # separat neben das TAR — Zeitstempel dafür wird nach dem finalen
    # Sidecar-Write gesetzt, damit im Archiv die vollständige Sidecar liegt.
    # ``needs_archive`` enthält bereits Aktivität + per-Kanal-Fingerprint-Check.
    if needs_archive:
        archive_result = archive_video(
            source_path=local_source_path,
            archive_target=rt.archive_target,
            rclone_path=rt.rclone_path,
            recording_date=recording_date,
            title=title,
            description=description,
            work_dir=request.work_dir,
            on_event=on_event,
        )
        result.archived = archive_result.success
        if archive_result.success:
            channel_timestamps["archive"] = _now_iso()
        else:
            result.error_message = archive_result.error_message

    # --- 5b. Sidecar finalisieren — per-Kanal Zeitstempel + Fingerprint,
    # ungenutzte Kanäle behalten ihre Werte aus dem alten Sidecar (PR2).
    any_channel_touched = bool(
        mediaset_result.web or mediaset_result.infuse
        or channel_timestamps["archive"]
    )
    if sidecar_enabled and any_channel_touched:
        try:
            source_size, source_head = compute_source_fingerprint(local_source_path)
        except OSError:
            source_size, source_head = None, None

        # Pro Kanal: wenn in diesem Lauf erfolgreich deployed → neuer Fingerprint;
        # sonst → alte Werte (per-Kanal, mit Legacy-Fallback) erhalten.
        def _fingerprint_pair_for(channel: str, just_deployed: bool) -> tuple[int | None, str | None]:
            if just_deployed:
                return source_size, source_head
            return sidecar.fingerprint_for_channel(channel)

        web_fp = _fingerprint_pair_for("web", bool(channel_timestamps["web"]))
        local_fp = _fingerprint_pair_for("local", bool(channel_timestamps["local"]))
        archive_fp = _fingerprint_pair_for("archive", bool(channel_timestamps["archive"]))

        updated = SidecarSettings(
            frame_number=poster_frame,
            timestamp_seconds=poster_at,
            crop_position=poster_crop,
            web_id=result.web_id or sidecar.web_id,
            max_luminance=max_luminance if max_luminance is not None else sidecar.max_luminance,
            # Kanäle: neuer Timestamp wenn in diesem Lauf deployed, sonst alter
            # (so gehen „web ok, local refresh fehlgeschlagen"-Historien nicht verloren).
            web_published_at=channel_timestamps["web"] or sidecar.web_published_at,
            web_enabled=True if effective_web_enabled else sidecar.web_enabled,
            web_source_size_bytes=web_fp[0],
            web_source_head_sha1=web_fp[1],
            local_published_at=channel_timestamps["local"] or sidecar.local_published_at,
            local_source_size_bytes=local_fp[0],
            local_source_head_sha1=local_fp[1],
            archive_published_at=channel_timestamps["archive"] or sidecar.archive_published_at,
            archive_source_size_bytes=archive_fp[0],
            archive_source_head_sha1=archive_fp[1],
            # Legacy-globaler Block wird seit v0.8.0 nicht mehr geschrieben — die
            # per-Kanal-Werte oben ersetzen ihn beim nächsten Write komplett.
            category=category,
        )
        local_sidecar = write_sidecar(local_source_path, updated)

        # Bei rclone-Quelle: aktualisierte Sidecar zurück an die Original-Location.
        # Für lokale Quellen ist sync_sidecar_back ein No-Op (das Sidecar liegt
        # bereits neben dem Original).
        try:
            staged.sync_sidecar_back(local_sidecar, rt, on_event=on_event)
        except Exception as e:
            # Sidecar-Rücksync-Fehler ist nicht tödlich — Publish war erfolgreich.
            # Wir loggen, aber belassen den Erfolgs-Status.
            if on_event:
                on_event(FamilienfilmEvent(
                    stage_id=FamilienfilmStage.DEPLOY_FAILED,
                    message=(
                        f"Sidecar-Rücksync zur Quelle fehlgeschlagen: {e}\n"
                        f"  Lokale Kopie unter {local_sidecar} — manuell sichern wenn gewollt."
                    ),
                ))

    # --- 5c. Optionales Source-Delete (opt-in, v0.9.0+) ---
    # Bedingungen — alle müssen erfüllt sein:
    #   1. ``delete_source_after_publish`` im Request gesetzt.
    #   2. Archiv war aktiv UND erfolgreich (Size-verifiziert — siehe archiver.py).
    #   3. Jeder weitere aktive Kanal (Infuse, Web) erfolgreich deployed.
    # Ohne aktives Archiv wird NIE gelöscht: das Archiv ist der einzige
    # Kanal, der die Originaldatei 1:1 aufbewahrt. Infuse und Web sind
    # transkodierte Ableitungen.
    if request.delete_source_after_publish:
        archive_ok = archive_active and result.archived
        infuse_ok = (not infuse_active) or result.infuse_deployed
        web_ok = (not web_active) or result.web_deployed
        if archive_ok and infuse_ok and web_ok:
            try:
                from familienfilm_manager.core.source_delete import delete_source
                removed = delete_source(source_ref, rclone_path=rt.rclone_path)
                result.source_deleted = True
                if on_event:
                    on_event(FamilienfilmEvent(
                        stage_id=FamilienfilmStage.SOURCE_DELETED,
                        message=f"Quelle gelöscht: {', '.join(removed)}",
                    ))
            except Exception as e:
                if on_event:
                    on_event(FamilienfilmEvent(
                        stage_id=FamilienfilmStage.SOURCE_DELETE_SKIPPED,
                        message=f"Quelle konnte nicht gelöscht werden: {e}",
                    ))
        else:
            reasons: list[str] = []
            if not archive_active:
                reasons.append("Archiv inaktiv (--no-archive)")
            elif not result.archived:
                reasons.append("Archiv fehlgeschlagen oder nicht verifiziert")
            if infuse_active and not result.infuse_deployed:
                reasons.append("Infuse fehlgeschlagen")
            if web_active and not result.web_deployed:
                reasons.append("Web fehlgeschlagen")
            if on_event:
                on_event(FamilienfilmEvent(
                    stage_id=FamilienfilmStage.SOURCE_DELETE_SKIPPED,
                    message=(
                        "Source-Delete übersprungen: "
                        + "; ".join(reasons) + ". Quelle bleibt erhalten."
                    ),
                ))

    # --- 6. Web-URL und Benachrichtigung ---
    if result.web_id and rt.branding_base_url:
        base = rt.branding_base_url.rstrip("/")
        result.web_url = f"{base}/{result.web_id}/"

    # Pending-Eintrag in der Benachrichtigungsdatei durch finales Ergebnis ersetzen.
    if notification_file and video_id:
        from familienfilm_manager.core.notifier import (
            replace_entry_failed,
            replace_entry_published,
        )

        if result.error_message and not result.web_deployed and not result.infuse_deployed:
            replace_entry_failed(
                notification_path=Path(notification_file),
                video_id=video_id,
                title=pending_title,
                error_message=result.error_message,
                category=category,
                recording_date=recording_date,
            )
        else:
            # Deployment-Ziele pro Kanal für die HTML-Benachrichtigung.
            # Seit v0.8.0 zeigt der Bericht auch bei Local-only-Publishes,
            # wohin genau deployed wurde (Infuse-Jahresordner, Archiv-URI).
            infuse_target_display: str | None = None
            if result.infuse_deployed and rt.infuse_target:
                from familienfilm_manager.core.infuse_deployer import (
                    _build_target_subdir,
                )
                infuse_target_display = _build_target_subdir(
                    rt.infuse_target, recording_date, rt.infuse_group_by,
                ) if recording_date else rt.infuse_target

            archive_target_display: str | None = (
                rt.archive_target if result.archived else None
            )

            replace_entry_published(
                notification_path=Path(notification_file),
                video_id=video_id,
                title=pending_title,
                video_url=result.web_url,
                category=category,
                recording_date=recording_date,
                infuse_target_path=infuse_target_display,
                archive_target_path=archive_target_display,
            )
        if on_event:
            on_event(FamilienfilmEvent(
                stage_id=FamilienfilmStage.PUBLISH_COMPLETED,
                message=f"Benachrichtigung aktualisiert: {notification_file}",
            ))

    # --- 7. Web-Arbeitsverzeichnis aufräumen (wenn temporär + Web-Deployment erfolgreich) ---
    cleanup_enabled = config_manager.get_with_default("cleanup.web_workdir").lower() != "false"
    if cleanup_enabled and web_tmp_dir and result.web_deployed:
        shutil.rmtree(web_tmp_dir, ignore_errors=True)
        # web_dir im Result auf None setzen, da das Verzeichnis nicht mehr existiert
        result.web_dir = None
        if on_event:
            on_event(FamilienfilmEvent(
                stage_id=FamilienfilmStage.PUBLISH_COMPLETED,
                message=f"Arbeitsverzeichnis aufgeräumt: {web_tmp_dir}",
            ))

    # Staging-Verzeichnis aufräumen (rclone-Quelle). Für lokale Quellen: No-Op.
    staged.cleanup()

    if on_event:
        if result.web_url:
            on_event(FamilienfilmEvent(
                stage_id=FamilienfilmStage.PUBLISH_COMPLETED,
                message=f"Video erreichbar unter: {result.web_url}",
            ))
        on_event(FamilienfilmEvent(
            stage_id=FamilienfilmStage.PUBLISH_COMPLETED,
            message=f"Veröffentlichung abgeschlossen: {source_ref.name}",
        ))

    return result
