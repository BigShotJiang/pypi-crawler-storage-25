"""Backward-compatibility shim.

LiveKit compat utilities have moved to ``voxgraph.providers.livekit._compat``.
This shim keeps all existing imports working without any changes.

    from voxgraph._compat import check_livekit_version   # still works

Test monkeypatching:
    Tests that patch ``_LIVEKIT_VERSION_CACHE`` / ``_LIVEKIT_VERSION_RESOLVED``
    do so on this module's globals. The ``livekit_has_model_usage_collector``
    function defined here reads from THIS module's globals (not the real module),
    so monkeypatching works correctly.
"""

import sys as _sys

# Re-export public helpers (non-stateful) directly
from voxgraph.providers.livekit._compat import (
    check_livekit_version,
    livekit_version,
)

# Mirror the private state so tests can monkeypatch them on this module.
# These are intentionally separate copies; mutations here do NOT affect the
# real voxgraph.providers.livekit._compat module.
from voxgraph.providers.livekit._compat import (
    _LIVEKIT_VERSION_CACHE,
    _LIVEKIT_VERSION_RESOLVED,
)


def livekit_has_model_usage_collector() -> bool:
    """Return True when livekit-agents >= 1.5.0.

    Reads ``_LIVEKIT_VERSION_CACHE`` from this (shim) module's globals so
    that test monkeypatching via ``import voxgraph._compat as compat;
    monkeypatch.setattr(compat, '_LIVEKIT_VERSION_CACHE', (1, 5, 0))`` takes
    effect correctly.
    """
    _this = _sys.modules[__name__]
    cache = getattr(_this, "_LIVEKIT_VERSION_CACHE", None)
    if cache is None:
        # Fall back to the real module's version detection
        from voxgraph.providers.livekit._compat import livekit_version as _lv
        cache = _lv()
    return cache >= (1, 5, 0)


__all__ = [
    "check_livekit_version",
    "livekit_has_model_usage_collector",
    "livekit_version",
]
