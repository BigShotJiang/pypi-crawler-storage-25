"""Async batched telemetry sender with retry and backoff.

Design principles (from OpenTelemetry SDK spec):
- Non-blocking: uses asyncio.Queue + background drain task
- Batched: accumulates payloads before flushing
- Bounded: drops oldest entries when buffer is full (with warning)
- Retry: exponential backoff with jitter (max 3 retries)
- Graceful: drain() method flushes all data before shutdown
- Connection pooling: single httpx.AsyncClient reused
"""

from __future__ import annotations

import asyncio
import datetime
import logging
import random
from typing import Any

import httpx

from voxgraph._version import __version__
from voxgraph.config import VoxConfig
from voxgraph.models import LogEntry, SessionMeta

__all__ = ["TelemetrySender", "TelemetryCollector"]

logger = logging.getLogger("voxgraph.telemetry")


class TelemetryCollector:
    """Collects telemetry data in-memory, thread-safe via asyncio.Queue.

    Data flows: logs → TelemetryCollector → TelemetrySender → Backend
    Session report is captured separately and sent at session end.
    """

    def __init__(self, max_buffer_size: int = 1000) -> None:
        self._queue: asyncio.Queue[dict[str, Any]] = asyncio.Queue(maxsize=max_buffer_size)
        self._max_buffer_size = max_buffer_size
        self._dropped_count = 0
        self._report: dict[str, Any] | None = None

    def record_log(self, entry: LogEntry) -> None:
        """Record a tagged log entry from the VoxLogHandler."""
        self._enqueue({"type": "log", "data": entry.model_dump()})

    def record_session_meta(self, meta: SessionMeta) -> None:
        """Record SDK-exclusive session metadata (prompt version, tags, cost)."""
        self._enqueue({"type": "session_meta", "data": meta.model_dump()})

    def record_session_report(self, report_dict: dict[str, Any]) -> None:
        """Record the full LiveKit session report (from ctx.make_session_report())."""
        self._report: dict[str, Any] | None = report_dict

    def _enqueue(self, item: dict[str, Any]) -> None:
        """Add an item to the queue. If full, drop oldest and warn."""
        try:
            self._queue.put_nowait(item)
        except asyncio.QueueFull:
            try:
                self._queue.get_nowait()
                self._dropped_count += 1
                if self._dropped_count % 100 == 1:
                    logger.warning(
                        "Voxgraph telemetry buffer full. Dropped %d items total. "
                        "Consider increasing max_buffer_size or reducing telemetry volume.",
                        self._dropped_count,
                    )
            except asyncio.QueueEmpty:
                pass
            try:
                self._queue.put_nowait(item)
            except asyncio.QueueFull:
                pass

    def collect_batch(self, max_items: int = 50) -> list[dict[str, Any]]:
        """Drain up to max_items from the queue. Non-blocking."""
        batch: list[dict[str, Any]] = []
        while len(batch) < max_items:
            try:
                batch.append(self._queue.get_nowait())
            except asyncio.QueueEmpty:
                break
        return batch

    @property
    def pending_count(self) -> int:
        return self._queue.qsize()

    @property
    def dropped_count(self) -> int:
        return self._dropped_count

    @property
    def session_report(self) -> dict[str, Any] | None:
        """The stored session report, if captured."""
        return self._report


class TelemetrySender:
    """Async background task that drains the collector and sends HTTP batches."""

    def __init__(self, config: VoxConfig, collector: TelemetryCollector) -> None:
        self._config = config
        self._collector = collector
        self._session_id: str = ""
        self._conversation_id: str = ""
        self._agent_id: str = config.agent_id
        self._client: httpx.AsyncClient | None = None
        self._task: asyncio.Task[None] | None = None
        self._running = False
        self._fatal_client_error = False  # set on first unrecoverable 4xx; silences all subsequent sends

    def set_session_id(self, session_id: str) -> None:
        """Set the vox_session_id used for logging/debugging."""
        self._session_id = session_id

    def set_conversation_id(self, conversation_id: str) -> None:
        """Set the UUID conversation_id sent in all API payloads."""
        self._conversation_id = conversation_id

    async def start(self) -> None:
        """Start the background drain loop."""
        if self._running:
            return

        self._client = httpx.AsyncClient(
            base_url=self._config.endpoint,
            timeout=self._config.request_timeout_s,
            headers={
                "Authorization": f"Bearer {self._config.api_key}",
                "Content-Type": "application/json",
                "User-Agent": f"voxgraph-sdk/{__version__}",
            },
        )
        self._running = True
        self._task = asyncio.create_task(self._drain_loop(), name="voxgraph-telemetry")

    async def _drain_loop(self) -> None:
        """Background loop: collect batches and send them periodically."""
        while self._running:
            try:
                await asyncio.sleep(self._config.flush_interval_s)
                if self._fatal_client_error:
                    break
                batch = self._collector.collect_batch(self._config.batch_size)
                if batch:
                    await self._send_with_retry(batch)
            except asyncio.CancelledError:
                break
            except Exception:
                logger.exception("Voxgraph telemetry drain loop error")

    async def _send_with_retry(self, batch: list[dict[str, Any]]) -> bool:
        """Send a batch with exponential backoff retry."""
        if not self._client:
            return False

        if self._config.debug:
            logger.info("Voxgraph sending %d items", len(batch))
            for item in batch:
                logger.debug("  → %s: %s", item.get("type"), str(item.get("data", ""))[:200])

        # In debug mode without an API key, just log and return
        if self._config.debug and not self._config.api_key:
            return True

        base_delay = 1.0
        for attempt in range(self._config.max_retries):
            try:
                # Extract only log-type items and transform to backend LogPayload shape
                log_payloads = []
                for item in batch:
                    if item.get("type") != "log":
                        continue
                    data = item.get("data", {})
                    log_payloads.append({
                        "level": data.get("level", "INFO"),
                        "message": data.get("message", ""),
                        "logger_name": data.get("logger_name"),
                        "turn_id": data.get("turn_id"),
                        "log_timestamp": data.get("timestamp", 0),
                        "extra": data.get("extra", {}),
                    })

                if not log_payloads:
                    return True  # batch had no logs (e.g. only metrics), skip

                response = await self._client.post(
                    "/api/v1/sdk-ingestion/telemetry",
                    json={
                        "agent_id": self._agent_id or None,
                        "conversation_id": self._conversation_id,
                        "logs": log_payloads,
                    },
                )
                if response.status_code < 400:
                    return True
                elif response.status_code >= 500:
                    logger.warning(
                        "Voxgraph backend returned %d, retrying (attempt %d/%d)",
                        response.status_code, attempt + 1, self._config.max_retries,
                    )
                else:
                    # Any 4xx is a permanent client-side error — stop the drain
                    # loop immediately to avoid a flood of identical errors.
                    self._fatal_client_error = True
                    self._running = False
                    if response.status_code in (401, 403):
                        logger.error(
                            "Voxgraph authentication failed (HTTP %d). "
                            "Telemetry has been disabled for this session. "
                            "Check that your VOXGRAPH_API_KEY environment variable is set "
                            "to a valid API key (see https://app.voxgraph.ai/settings/api-keys). "
                            "Server response: %s",
                            response.status_code, response.text[:200],
                        )
                    elif response.status_code == 404:
                        logger.error(
                            "Voxgraph backend returned 404 — agent not found. "
                            "Telemetry has been disabled for this session. "
                            "Make sure your VOXGRAPH_AGENT_ID is registered in the dashboard "
                            "(https://app.voxgraph.ai/agents). "
                            "Server response: %s",
                            response.text[:200],
                        )
                    else:
                        logger.error(
                            "Voxgraph backend returned unrecoverable %d. "
                            "Telemetry has been disabled for this session. "
                            "Server response: %s",
                            response.status_code, response.text[:200],
                        )
                    return False
            except (httpx.ConnectError, httpx.TimeoutException) as e:
                logger.warning(
                    "Voxgraph telemetry send failed: %s (attempt %d/%d)",
                    str(e)[:100], attempt + 1, self._config.max_retries,
                )
            except Exception:
                logger.exception("Unexpected error sending telemetry")
                return False

            delay = base_delay * (2 ** attempt) + random.uniform(0, 0.5)
            await asyncio.sleep(delay)

        logger.error(
            "Voxgraph telemetry: exhausted %d retries, dropping %d items",
            self._config.max_retries, len(batch),
        )
        return False

    @staticmethod
    def _ts_to_iso(ts: float | None) -> str | None:
        """Convert a Unix timestamp float to an ISO 8601 string, or None."""
        if ts is None:
            return None
        return datetime.datetime.fromtimestamp(ts, tz=datetime.timezone.utc).isoformat()

    @staticmethod
    def _map_messages(chat_history: dict[str, Any]) -> list[dict[str, Any]]:
        """Map LiveKit chat_history items to backend MessagePayload list.

        Handles all ChatItem types:
          - message          → content_type="message", extra_metadata={transcript_confidence, extra}
          - function_call    → content_type="function_call", extra_metadata={call_id, name, arguments, group_id, extra}
          - function_call_output → content_type="function_call_output", extra_metadata={call_id, name, is_error}
          - agent_handoff    → content_type="agent_handoff", extra_metadata={old_agent_id, new_agent_id}
          - agent_config_update → content_type="agent_config_update", extra_metadata={instructions, tools_added, tools_removed}
        """
        messages = []
        for item in chat_history.get("items", []):
            item_type = item.get("type")

            if item_type == "message":
                # Extract text content (skip ImageContent/AudioContent dicts)
                content_parts = [
                    c for c in (item.get("content") or [])
                    if isinstance(c, str)
                ]
                content_str = "\n".join(content_parts) if content_parts else None
                raw_metrics = item.get("metrics") or {}
                messages.append({
                    "item_id": item.get("id"),
                    "role": item.get("role", "user"),
                    "content": content_str,
                    "content_type": "message",
                    "interrupted": item.get("interrupted", False),
                    "started_at": TelemetrySender._ts_to_iso(raw_metrics.get("started_speaking_at")),
                    "extra_metadata": {
                        "transcript_confidence": item.get("transcript_confidence"),
                        "extra": item.get("extra") or {},
                    },
                    "metrics": {
                        "started_speaking_at": raw_metrics.get("started_speaking_at"),
                        "stopped_speaking_at": raw_metrics.get("stopped_speaking_at"),
                        "transcription_delay": raw_metrics.get("transcription_delay"),
                        "end_of_turn_delay": raw_metrics.get("end_of_turn_delay"),
                        "on_user_turn_completed_delay": raw_metrics.get("on_user_turn_completed_delay"),
                        "llm_node_ttft": raw_metrics.get("llm_node_ttft"),
                        "tts_node_ttfb": raw_metrics.get("tts_node_ttfb"),
                        "e2e_latency": raw_metrics.get("e2e_latency"),
                    } if raw_metrics else None,
                })

            elif item_type == "function_call":
                name = item.get("name", "")
                messages.append({
                    "item_id": item.get("id"),
                    "role": "assistant",
                    "content": f"Called function: {name}",
                    "content_type": "function_call",
                    "interrupted": False,
                    "started_at": TelemetrySender._ts_to_iso(item.get("created_at")),
                    "extra_metadata": {
                        "call_id": item.get("call_id"),
                        "name": name,
                        "arguments": item.get("arguments"),
                        "group_id": item.get("group_id"),
                        "extra": item.get("extra") or {},
                    },
                    "metrics": None,
                })

            elif item_type == "function_call_output":
                name = item.get("name", "")
                messages.append({
                    "item_id": item.get("id"),
                    "role": "assistant",
                    "content": item.get("output"),
                    "content_type": "function_call_output",
                    "interrupted": False,
                    "started_at": TelemetrySender._ts_to_iso(item.get("created_at")),
                    "extra_metadata": {
                        "call_id": item.get("call_id"),
                        "name": name,
                        "is_error": item.get("is_error", False),
                    },
                    "metrics": None,
                })

            elif item_type == "agent_handoff":
                new_agent_id = item.get("new_agent_id", "")
                messages.append({
                    "item_id": item.get("id"),
                    "role": "assistant",
                    "content": f"Handoff to {new_agent_id}",
                    "content_type": "agent_handoff",
                    "interrupted": False,
                    "started_at": TelemetrySender._ts_to_iso(item.get("created_at")),
                    "extra_metadata": {
                        "old_agent_id": item.get("old_agent_id"),
                        "new_agent_id": new_agent_id,
                    },
                    "metrics": None,
                })

            elif item_type == "agent_config_update":
                messages.append({
                    "item_id": item.get("id"),
                    "role": "assistant",
                    "content": "Config updated",
                    "content_type": "agent_config_update",
                    "interrupted": False,
                    "started_at": TelemetrySender._ts_to_iso(item.get("created_at")),
                    "extra_metadata": {
                        "instructions": item.get("instructions"),
                        "tools_added": item.get("tools_added"),
                        "tools_removed": item.get("tools_removed"),
                    },
                    "metrics": None,
                })

            # unknown types are silently skipped

        return messages

    @staticmethod
    def _map_events(events: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Map LiveKit event dicts to backend EventPayload list."""
        mapped = []
        for ev in events:
            mapped.append({
                "event_type": ev.get("type", "unknown"),
                "event_timestamp": ev.get("created_at", 0.0),
                "data": {k: v for k, v in ev.items() if k not in ("type", "created_at")},
            })
        return mapped

    async def _send_report(self, report_dict: dict[str, Any]) -> None:
        """Send the full session report to the Voxgraph backend.

        Transforms LiveKit SessionReport.to_dict() into the flat IngestReportRequest
        shape expected by the backend.
        """
        if not self._client:
            return

        if self._fatal_client_error:
            return

        # LiveKit timestamps are Unix floats. Backend requires ISO 8601.
        started_at_ts: float | None = report_dict.get("started_at")
        ended_at_ts: float | None = report_dict.get("timestamp")  # session report creation time

        # started_at is required by the backend — fall back to ended_at if missing
        started_at_iso = self._ts_to_iso(started_at_ts) or self._ts_to_iso(ended_at_ts) or ""
        ended_at_iso = self._ts_to_iso(ended_at_ts)

        usage: dict[str, Any] = report_dict.get("usage") or {}
        realtime_avg_ttft: float | None = usage.get("_realtime_avg_ttft")

        # ── Realtime model latency injection ─────────────────────────────────
        # For realtime models (no STT/LLM/TTS pipeline), per-turn ChatItem.metrics
        # is not populated with e2e_latency or llm_node_ttft by LiveKit.
        # We inject the session-averaged TTFT from RealtimeModelMetrics events
        # into agent message dicts BEFORE _map_messages() reads them, so the
        # backend's existing per-message metrics aggregation (Avg/P95 Latency,
        # Avg TTFT) works for realtime sessions without any backend changes.
        if realtime_avg_ttft is not None:
            chat_items = (report_dict.get("chat_history") or {}).get("items") or []
            for item in chat_items:
                if item.get("type") == "message" and item.get("role") == "assistant":
                    existing: dict = item.get("metrics") or {}
                    # Only inject if not already populated (don't overwrite real data)
                    if not existing.get("e2e_latency"):
                        existing["e2e_latency"] = realtime_avg_ttft
                        existing["llm_node_ttft"] = realtime_avg_ttft
                        item["metrics"] = existing

        chat_history: dict[str, Any] = report_dict.get("chat_history") or {}
        messages = self._map_messages(chat_history)
        events = self._map_events(report_dict.get("events") or [])

        # Strip private SDK-internal keys before sending to backend
        usage_payload = {k: v for k, v in usage.items() if not k.startswith("_")}

        payload: dict[str, Any] = {
            "agent_id": self._agent_id or None,
            "conversation_id": self._conversation_id,
            "session_id": self._session_id,
            "job_id": report_dict.get("job_id"),
            "room_id": report_dict.get("room_id"),
            "started_at": started_at_iso,
            "ended_at": ended_at_iso,
            "duration_seconds": report_dict.get("duration_seconds"),
            "ended_reason": report_dict.get("ended_reason"),
            "call_type": report_dict.get("call_type"),
            "call_channel": report_dict.get("call_channel"),
            "recording_url": report_dict.get("recording_url"),
            "recording_started_at": report_dict.get("recording_started_at"),
            "environment": report_dict.get("environment"),
            "prompt_version": report_dict.get("prompt_version"),
            "messages": messages,
            "events": events,
            "options": report_dict.get("options"),
            "session_data": report_dict.get("session_data"),
            "usage": usage_payload,
            "tools": report_dict.get("tools"),
            "is_test_call": report_dict.get("is_test_call", False),
        }

        if self._config.debug:
            logger.info(
                "Voxgraph sending session report (job_id=%s, messages=%d)",
                payload.get("job_id", "?"), len(messages),
            )

        if self._config.debug and not self._config.api_key:
            return

        try:
            response = await self._client.post(
                "/api/v1/sdk-ingestion/report",
                json=payload,
                timeout=20.0,  # Session report is larger than log batches; allow more time for backend to respond.
            )
            if response.status_code < 400:
                logger.info("Session report sent successfully")
            else:
                logger.error(
                    "Failed to send session report: %d %s",
                    response.status_code, response.text[:200],
                )
        except Exception:
            logger.exception("Error sending session report")

    async def drain(self) -> None:
        """Flush all remaining buffered data and shut down."""
        self._running = False

        if self._task and not self._task.done():
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass

        # Skip all outbound requests if auth has already failed — they would
        # all return 401 again and produce duplicate error noise.
        if not self._fatal_client_error:
            while self._collector.pending_count > 0:
                batch = self._collector.collect_batch(self._config.batch_size)
                if batch:
                    await self._send_with_retry(batch)
                else:
                    break

            # Send the session report if captured
            report = self._collector.session_report
            if report:
                await self._send_report(report)

        if self._client:
            await self._client.aclose()
            self._client = None

        if self._collector.dropped_count > 0:
            logger.warning(
                "Voxgraph session ended. Total dropped items: %d",
                self._collector.dropped_count,
            )
