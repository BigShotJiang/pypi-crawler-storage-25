"""Voxgraph provider integrations.

Each sub-package contains the platform-specific session wrapper,
version compatibility layer, audio recorder, and event interceptor
for one voice-AI platform.

Current providers:
  - livekit:  LiveKit Agents (livekit-agents >= 1.0)

Planned:
  - pipecat:  Pipecat (future)
"""
