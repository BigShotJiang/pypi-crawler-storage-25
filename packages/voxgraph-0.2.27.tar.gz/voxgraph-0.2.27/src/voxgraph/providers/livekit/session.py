"""VoxSession — the composition-based public API for Voxgraph SDK.

VoxSession **wraps** (not extends) a LiveKit AgentSession. This composition
pattern is more resilient to LiveKit API changes than inheritance.

Lean SDK: Only captures data the session report can't provide:
- Token counts (metrics_collected events)
- Context-tagged developer logs
- Prompt version + tags
- Cost tracking

Transcripts, latency, tool calls, events -> handled by ctx.make_session_report()

Usage:
    from voxgraph import VoxSession
    from livekit.agents import AgentSession

    session = AgentSession(stt=..., llm=..., tts=...)
    vox = VoxSession(
        session,
        api_key="vxg_abc123",
        agent_id="550e8400-e29b-41d4-a716-446655440000",
    )
    await vox.start(agent=MyAgent(), room=ctx.room)
"""

from __future__ import annotations

import dataclasses
import logging
import uuid
from typing import TYPE_CHECKING, Any

from voxgraph.providers.livekit._compat import check_livekit_version, livekit_has_model_usage_collector
from voxgraph.providers.livekit._tools import extract_agent_tool_map, serialize_tool
from voxgraph.providers.livekit._usage import extract_usage, _extract_usage_legacy, _extract_usage_v15
from voxgraph.providers.livekit._prompts import fetch_and_inject_prompt
from voxgraph.providers.livekit.interceptor import attach_listeners, detach_listeners
from voxgraph.providers.livekit.audio_recorder import AudioRecorder
from voxgraph.config import VoxConfig, load_config
from voxgraph.context import TurnContext, _current_turn
from voxgraph.logger import install_vox_log_handler, uninstall_vox_log_handler
from voxgraph.models import SessionMeta
from voxgraph.telemetry import TelemetryCollector, TelemetrySender

if TYPE_CHECKING:
    from livekit.agents import AgentSession, JobContext
    from livekit.agents.voice.events import AgentEvent

__all__ = ["VoxSession"]

logger = logging.getLogger("voxgraph.session")


def _json_safe(obj: Any) -> Any:
    """Recursively coerce a nested dict/list structure to JSON-serializable types.

    Leaves ``str``, ``int``, ``float``, ``bool``, ``None`` untouched.
    Dicts and lists are traversed recursively. Everything else (e.g. an
    ``LLM`` instance inside ``turn_handling.turn_detection``) is converted
    via ``str()``.
    """
    if obj is None or isinstance(obj, (str, int, float, bool)):
        return obj
    if isinstance(obj, dict):
        return {str(k): _json_safe(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_json_safe(v) for v in obj]
    return str(obj)


class VoxSession:
    """Observability wrapper for a LiveKit AgentSession.

    Composition pattern: takes an existing AgentSession and adds Voxgraph
    instrumentation without modifying the session's behavior.

    The SDK automatically detects the LiveKit JobContext and registers shutdown
    hooks, so the session report is always captured regardless of how the call ends.

    Args:
        session: The LiveKit AgentSession to observe.
        api_key: Voxgraph API key. Can also be set via the VOXGRAPH_API_KEY
            environment variable.
        agent_id: UUID of the voice AI agent (from the Voxgraph dashboard).
            Required for prompt fetch and usage attribution. Can also be set
            via VOXGRAPH_AGENT_ID.
        environment: Prompt branch to fetch (default: ``"main"``). Use
            ``"dev"`` or ``"staging"`` to test non-production prompts. Can
            also be set via VOXGRAPH_ENVIRONMENT.
        tags: Optional key-value metadata attached to the session report
            (e.g. ``{"customer_tier": "enterprise", "region": "us-east"}``)
        enable_recording: When ``True``, captures session audio (user mic +
            agent TTS) and uploads it to Voxgraph. The ``recording_url`` is
            included in the session report automatically. Defaults to
            ``False``.
        base_instructions: Optional user-provided base prompt to preserve
            alongside the VoxGraph-fetched prompt. When set, the final
            agent instructions are a merge of the fetched content
            (high-priority) and these base instructions (contextual
            enrichment like org info, business hours, departments).
            If the fetch fails or returns empty, base_instructions are
            still injected so the agent never loses its core context.
    """

    def __init__(
        self,
        session: AgentSession,
        *,
        api_key: str | None = None,
        agent_id: str | None = None,
        environment: str | None = None,
        tags: dict[str, str] | None = None,
        enable_recording: bool = False,
        base_instructions: str = "",
    ) -> None:
        check_livekit_version()

        self._session = session
        self._session_id = f"vox_{uuid.uuid4().hex[:12]}"
        self._conversation_id = str(uuid.uuid4())
        self._ctx: JobContext | None = None
        self._is_started = False
        self._is_shutdown = False
        self._close_listener: Any = None
        self._enable_recording = enable_recording
        self._recorder: AudioRecorder | None = AudioRecorder() if enable_recording else None
        self._prompt_version: str = ""  # Auto-captured from API during prompt fetch
        self._turn_token: Any = None  # ContextVar token for resetting turn context
        self._tool_snapshots: list[dict] = []  # Event-driven tool snapshots
        self._participant_attrs: dict[str, dict] = {}  # identity → attributes snapshot (captured at join time)
        # Speaking-window tracker for realtime model sessions.
        # LiveKit does not populate ChatMessage.metrics.started_speaking_at /
        # stopped_speaking_at on the user turn in the realtime model path (their
        # own TODO in agent_activity.py).  We reconstruct the windows ourselves
        # by listening to user_state_changed events and inject them at shutdown.
        self._speaking_windows: list[tuple[float, float | None]] = []
        self._base_instructions = base_instructions

        # Load configuration (endpoint is always hardcoded to api.voxgraph.io)
        self._config = load_config(
            api_key=api_key,
            agent_id=agent_id,
            environment=environment,
            tags=tags,
        )

        # Initialize telemetry pipeline
        self._collector = TelemetryCollector(max_buffer_size=self._config.max_buffer_size)
        self._sender = TelemetrySender(self._config, self._collector)
        self._sender.set_session_id(self._session_id)
        self._sender.set_conversation_id(self._conversation_id)

        logger.info(
            "VoxSession created (id=%s, debug=%s)",
            self._session_id, self._config.debug,
        )

    @property
    def session(self) -> AgentSession:
        """Access the underlying LiveKit AgentSession."""
        return self._session

    @property
    def session_id(self) -> str:
        """The unique Voxgraph session identifier."""
        return self._session_id

    @property
    def conversation_id(self) -> str:
        """The UUID used to identify this conversation in the Voxgraph backend."""
        return self._conversation_id

    async def start(
        self,
        *,
        agent: Any,
        room: Any,
        room_options: Any | None = None,
        **kwargs: Any,
    ) -> None:
        """Start observability for this session.

        Starts the LiveKit session and attaches metrics + log instrumentation.

        Automatically captures the session report at call end via two layers:
          1. AgentSession 'close' event — fires for ALL termination reasons
             (disconnect, shutdown, error, task_complete).
          2. ctx.add_shutdown_callback — secondary safety net registered via
             get_job_context(), in case the session close event doesn't fire.

        Args:
            agent: The Agent instance to observe.
            room: The LiveKit Room instance.
            room_options: Optional RoomOptions for the session.
        """
        if self._is_started:
            logger.warning("VoxSession.start() called multiple times, ignoring.")
            return

        # 1a. Start the background telemetry sender (initializes the HTTP client
        #     needed by the recorder for S3 presigned URLs)
        await self._sender.start()

        # 1b. Attach audio recorder hook BEFORE session.start() so it intercepts
        #     session.output.audio the instant RoomIO sets it — before the agent
        #     activity (and first greeting) begins.
        if self._recorder is not None:
            try:
                self._recorder.attach(
                    session=self._session,
                    conversation_id=self._conversation_id,
                    http_client=self._sender._client,
                    endpoint=self._config.endpoint,
                    agent_id=self._config.agent_id,
                )
            except Exception:
                logger.exception("AudioRecorder failed to attach — recording disabled for this session")
                self._recorder = None

        # 1c. Attempt to fetch and inject the deployed prompt from Voxgraph.
        #     This runs BEFORE session.start() so instructions are set before the
        #     first user turn. When base_instructions is provided, it is always
        #     preserved — merged with the fetched prompt, or injected alone if
        #     the fetch fails. On failure without base_instructions, the agent
        #     keeps whatever instructions the customer set in their own code.
        self._prompt_version = await fetch_and_inject_prompt(
            self._config, self._sender._client, agent,
            base_instructions=self._base_instructions,
        )

        # 1d. Start the LiveKit session (RoomIO wires audio inside here, which
        #     triggers our recorder hook above to wrap it with RecorderIO immediately)
        start_kwargs: dict[str, Any] = {"agent": agent, "room": room}
        if room_options is not None:
            start_kwargs["room_options"] = room_options
        start_kwargs.update(kwargs)
        await self._session.start(**start_kwargs)

        # 2. Attach interceptor (no-op; kept for interface stability)
        attach_listeners(self._session)

        # 2b. Snapshot existing remote participants and register a listener
        #     for future joins. Captures participant attributes (e.g.
        #     vox.test_call, vox.conversation_id) at connect-time so they are
        #     still available at shutdown — even if the participant has already
        #     left the room.
        #
        #     vox.conversation_id: when the Voxgraph test runner pre-generates
        #     the conversation UUID and stamps it on the test-caller participant,
        #     we adopt it here so the SDK uses the orchestrator's UUID instead of
        #     a self-generated one. This guarantees the Postgres Conversation row
        #     (written by the session report) and the ClickHouse test_result row
        #     (written by the orchestrator) share the same primary key.
        try:
            from livekit.agents import get_job_context as _gjc
            _room = _gjc().room
            for p in _room.remote_participants.values():
                attrs = dict(p.attributes or {})
                # Store participant.kind so _detect_call_classification can
                # classify the call even after the participant disconnects.
                try:
                    attrs["_vox._participant_kind"] = int(p.kind)
                except Exception:
                    pass
                self._participant_attrs[p.identity] = attrs
                self._maybe_adopt_conversation_id(attrs)
            _room.on("participant_connected", self._on_participant_connected)
        except (RuntimeError, ImportError):
            pass  # no job context — fine (unit tests, local dev)

        # 3. Layer 1 (Primary): Register a shutdown callback via JobContext.
        #    LiveKit awaits every shutdown callback to completion before exiting
        #    the job — this guarantees shutdown() runs fully regardless of what
        #    the customer agent code does or how quickly it exits.
        #    Also stores ctx for make_session_report() in shutdown().
        _has_job_context = False
        try:
            from livekit.agents import get_job_context
            ctx = get_job_context()
            self._ctx = ctx
            ctx.add_shutdown_callback(self.shutdown)
            _has_job_context = True
            logger.debug("Auto-registered shutdown callback via get_job_context()")
        except (RuntimeError, ImportError):
            # Not inside a LiveKit job (e.g. unit tests, local dev) — fine.
            logger.debug("No job context found; shutdown callback not auto-registered")

        # 4. Layer 2 (Fallback): Hook the session 'close' event with ensure_future.
        #    Only used when there is NO job context (e.g. tests, local dev).
        #    When a job context IS present, the shutdown callback above is the
        #    authoritative trigger — using ensure_future here would race against
        #    it and could be cancelled by the event loop before drain() completes.
        if not _has_job_context:
            def _on_close(_event: Any) -> None:
                import asyncio
                asyncio.create_task(self.shutdown(), name="voxgraph-shutdown")

            self._session.on("close", _on_close)
            self._close_listener = _on_close
            logger.debug("Registered close-event fallback (no job context)")

        # 5. Install structured log handler
        install_vox_log_handler(self._collector.record_log)

        # 6. Hook conversation_item_added to auto-set vox_turn_context per user turn.
        #    The VoxLogHandler already reads get_current_turn() on every emit, so once
        #    this ContextVar is set, all logs during the turn are automatically tagged
        #    with turn_id — no changes needed in user code.
        #    We only set context for user messages (role == "user") because that is the
        #    meaningful unit of work the logs should be attributed to. The context is
        #    left set until the next user turn begins (it's not cleared at turn end
        #    because agent reply logs during generation should share the same turn_id).
        self._session.on("conversation_item_added", self._on_conversation_item_added)
        self._session.on("user_state_changed", self._on_user_state_changed)

        # 7. Capture initial tool snapshot right after session.start().
        #    This captures the first agent's tools before any handoffs or updates.
        self._snapshot_current_tools(trigger="session_start")

        self._is_started = True
        logger.info(
            "VoxSession started (id=%s, region=%s, environment=%s, prompt_version=%s, recording=%s)",
            self._session_id, self._config.region, self._config.environment, self._prompt_version or "(none)", self._enable_recording,
        )

    async def shutdown(self) -> None:
        """Gracefully shut down the Voxgraph instrumentation.

        Safe to call multiple times — only executes once (guarded by _is_shutdown).

        Steps:
        1. Detach metrics listener
        2. Remove log handler
        3. Capture session report from LiveKit JobContext
        4. Send SDK-exclusive session metadata
        5. Drain all buffered telemetry
        """
        if self._is_shutdown:
            return
        self._is_shutdown = True

        logger.info("VoxSession shutting down (id=%s)", self._session_id)

        # 1. Detach listeners
        try:
            detach_listeners(self._session)
        except Exception:
            logger.exception("Error detaching listeners during shutdown")

        # 2. Remove log handler
        try:
            uninstall_vox_log_handler()
        except Exception:
            logger.exception("Error removing log handler during shutdown")

        # 3. Capture the full session report from LiveKit.
        #    Use stored ctx from start(), or fall back to get_job_context() one last time.
        ctx = self._ctx
        if ctx is None:
            try:
                from livekit.agents import get_job_context
                ctx = get_job_context()
            except (RuntimeError, ImportError):
                pass

        try:
            if ctx is not None:
                try:
                    report = ctx.make_session_report()

                    # Extract usage from the raw report events BEFORE to_dict() strips
                    # metrics_collected events. We use LiveKit's own UsageCollector to
                    # aggregate LLM tokens, STT audio duration, and TTS characters.
                    usage = extract_usage(report.events)

                    # Extract ended_reason from the raw close event BEFORE to_dict().
                    # The 'close' event carries a 'reason' field; to_dict() includes it
                    # in the events list but the backend expects it as a top-level field.
                    ended_reason = self._extract_ended_reason(report.events)

                    # duration is a raw attribute on SessionReport but is NOT included
                    # in to_dict() output — must be read directly from the raw object.
                    # Fallback: compute from started_at and timestamp if duration is
                    # not populated (common in livekit-agents < 1.5).
                    duration_seconds: int | None = None
                    if getattr(report, "duration", None) is not None:
                        duration_seconds = int(report.duration)
                    elif getattr(report, "started_at", None) is not None:
                        duration_seconds = int(report.timestamp - report.started_at)

                    report_dict = report.to_dict()

                    # Inject speaking timestamps into realtime-model user messages.
                    # Must happen after to_dict() (which discards raw objects) and
                    # before record_session_report() queues the dict for sending.
                    self._inject_speaking_timestamps(report_dict, self._speaking_windows)
                    report_dict["usage"] = usage
                    report_dict["ended_reason"] = ended_reason
                    report_dict["duration_seconds"] = duration_seconds

                    # Override the partial options from to_dict() with the full set read
                    # directly from the AgentSession. to_dict() silently drops 6 fields:
                    # false_interruption_timeout, resume_false_interruption,
                    # use_tts_aligned_transcript, tts_text_transforms, ivr_detection,
                    # aec_warmup_duration.
                    report_dict["options"] = self._capture_full_options(self._session)

                    # Capture userdata and current_speech — not available in the report at all.
                    report_dict["session_data"] = self._capture_session_data(self._session)

                    # Auto-detect call classification from room participants.
                    # SIP participant → channel=phone; sip.ruleID non-empty → inbound.
                    # vox.test_call attribute → is_test_call=True.
                    call_type, call_channel, is_test_call, sip_call_id = (
                        self._detect_call_classification(
                            ctx, self._participant_attrs,
                        )
                    )
                    report_dict["call_type"] = call_type
                    report_dict["call_channel"] = call_channel
                    report_dict["is_test_call"] = is_test_call
                    # Include sip_call_id so IngestionService can link
                    # test_result.conversation_id retroactively after a
                    # telephony-tier test call.
                    if sip_call_id:
                        report_dict["sip_call_id"] = sip_call_id

                    # Stamp SDK-owned fields onto the report — the backend's
                    # IngestReportRequest accepts both environment and prompt_version.
                    report_dict["environment"] = self._config.environment
                    report_dict["prompt_version"] = self._prompt_version or None

                    # Build a per-agent tool snapshot map.
                    # Prefers runtime snapshots (captured during the session via
                    # events), falls back to chat history or session.tools.
                    report_dict["tools"] = extract_agent_tool_map(
                        report, self._session, self._tool_snapshots
                    )

                    # ── CRITICAL: queue the report before any await ──────────────
                    # record_session_report() must be called here, before
                    # await self._recorder.stop() below. If the asyncio task is
                    # cancelled at that await (because the job is shutting down),
                    # CancelledError bypasses except-Exception guards. By storing
                    # the report dict in the collector NOW, drain() can always send
                    # it — even if we never return from the recorder await.
                    # report_dict is a plain dict; any mutations made after this
                    # call (recording_url, etc.) are visible to drain() because
                    # Python dicts are passed by reference.
                    self._collector.record_session_report(report_dict)
                    logger.info("Session report captured (job_id=%s)", report_dict.get("job_id", "?"))

                    # Stop audio recorder and enrich the already-queued report.
                    # This await is where CancelledError can strike — that is now
                    # safe because the report is already in the collector.
                    if self._recorder is not None:
                        try:
                            recording_url, recording_started_at = await self._recorder.stop()
                            if recording_url:
                                report_dict["recording_url"] = recording_url
                            if recording_started_at is not None:
                                report_dict["recording_started_at"] = recording_started_at
                        except Exception:
                            logger.exception("AudioRecorder failed to stop — recording_url will be missing")

                except Exception:
                    logger.exception("Error capturing session report during shutdown")
            else:
                logger.warning(
                    "No JobContext available — session report skipped. "
                    "If running in a LiveKit job, this is unexpected."
                )

            # 4. Send SDK-exclusive session metadata
            try:
                meta = SessionMeta(
                    session_id=self._session_id,
                    prompt_version=self._prompt_version,
                    environment=self._config.environment,
                    tags=self._config.tags,
                )
                self._collector.record_session_meta(meta)
            except Exception:
                logger.exception("Error recording session meta during shutdown")

        except BaseException as exc:
            # CancelledError (BaseException in Python 3.8+) and other fatal errors.
            # Log it so the developer can see what interrupted shutdown, then re-raise
            # so asyncio can propagate the cancellation correctly.
            logger.warning(
                "VoxSession shutdown interrupted (%s: %s). "
                "Drain will still run via finally to send the queued session report.",
                type(exc).__name__, exc,
            )
            raise
        finally:
            # 5. Drain telemetry buffer — ALWAYS runs, even if cancelled above.
            # asyncio.shield() creates an independent Task for drain() so it runs
            # to completion even when the outer shutdown() Task is being cancelled.
            import asyncio as _asyncio
            try:
                await _asyncio.shield(self._sender.drain())
            except _asyncio.CancelledError:
                # The outer task was cancelled while we were waiting for the shield.
                # drain() continues running in the background as a detached task and
                # will complete on its own — the session report will still be sent.
                logger.debug("Shutdown task cancelled during drain; drain continues in background.")
            except Exception:
                logger.exception("Error draining telemetry during shutdown")

        logger.info(
            "VoxSession shutdown complete (id=%s, dropped=%d)",
            self._session_id, self._collector.dropped_count,
        )

    def _on_participant_connected(self, participant: Any) -> None:
        """Capture remote participant attributes at connect-time.

        Stores a snapshot of ``participant.attributes`` keyed by identity.
        This is critical for detecting ``vox.test_call`` because the test
        caller typically disconnects before the agent shuts down — at which
        point ``ctx.room.remote_participants`` is empty.

        Also adopts ``vox.conversation_id`` if present so the orchestrator's
        pre-generated UUID is used instead of the SDK's self-generated UUID.
        """
        try:
            identity = participant.identity
            attrs = dict(participant.attributes or {})
            # Store participant.kind alongside the attributes so
            # _detect_call_classification can identify SIP participants even
            # after they have disconnected (e.g. caller hangs up mid-session).
            try:
                attrs["_vox._participant_kind"] = int(participant.kind)
            except Exception:
                pass
            self._participant_attrs[identity] = attrs
            self._maybe_adopt_conversation_id(attrs)
            logger.debug(
                "Captured participant attributes (identity=%s, attrs=%s)",
                identity, attrs,
            )
        except Exception:
            logger.debug("Failed to capture participant attributes", exc_info=True)

    def _maybe_adopt_conversation_id(self, attrs: dict) -> None:
        """Adopt the orchestrator's pre-generated conversation_id if provided.

        When the Voxgraph test runner joins the room it stamps
        ``vox.conversation_id`` as a participant attribute containing the UUID
        it has already written to the ClickHouse ``test_result`` row.  By
        adopting that UUID here (before any telemetry is sent) we guarantee
        the Postgres ``Conversation`` row and the ``test_result`` row share
        the same primary key, with no fuzzy room-name matching required.

        This method is idempotent — it only acts if the attribute is a
        non-empty string that differs from the current conversation_id.
        """
        vox_conv_id = attrs.get("vox.conversation_id", "").strip()
        if vox_conv_id and vox_conv_id != self._conversation_id:
            self._conversation_id = vox_conv_id
            self._sender.set_conversation_id(vox_conv_id)
            # Propagate to the AudioRecorder so the recording uploads
            # under the adopted UUID — not the original self-generated one.
            if self._recorder is not None:
                self._recorder._conversation_id = vox_conv_id
            logger.info(
                "conversation_id adopted from orchestrator (vox.conversation_id=%s)",
                vox_conv_id,
            )

    def _on_user_state_changed(self, event: Any) -> None:
        """Track user speaking windows for realtime model sessions.

        LiveKit emits ``user_state_changed`` whenever the user transitions
        between ``'listening'`` and ``'speaking'``.  We record a
        ``(started_at, None)`` entry when speaking begins and close it with
        ``stopped_at = now`` when listening resumes.

        These windows are later injected into the user ``ChatMessage.metrics``
        dict by :meth:`_inject_speaking_timestamps` at shutdown so the frontend
        can render the "user speaking time range" on the audio timeline.

        Args:
            event: The ``UserStateChangedEvent`` from LiveKit.
        """
        import time as _time
        try:
            new_state = getattr(event, "new_state", None)
            old_state = getattr(event, "old_state", None)
            # Prefer event.created_at — LiveKit sets this via `default_factory=time.time`
            # at the moment `UserStateChangedEvent` is constructed inside `_update_user_state`,
            # which is called synchronously from the VAD callback.  This is more accurate than
            # calling `time.time()` here because by now asyncio dispatch has added latency.
            event_ts = getattr(event, "created_at", None) or _time.time()
            if new_state == "speaking":
                # A new speaking window begins
                self._speaking_windows.append((event_ts, None))
            elif new_state == "listening" and old_state == "speaking":
                # Close the most recent open window
                if self._speaking_windows and self._speaking_windows[-1][1] is None:
                    start = self._speaking_windows[-1][0]
                    self._speaking_windows[-1] = (start, event_ts)
        except Exception:
            logger.debug("Failed to handle user_state_changed", exc_info=True)

    def _on_conversation_item_added(self, event: Any) -> None:
        """Handle conversation item events for turn tracking and tool snapshots.

        Fires on every ``conversation_item_added`` event from the LiveKit AgentSession.

        Responsibilities:
          - **Turn tracking**: Sets the vox_turn_context ContextVar on user messages.
          - **Tool snapshots**: Captures ``session.tools`` when an ``AgentHandoff``
            or ``AgentConfigUpdate`` item is detected, building a per-agent timeline
            of tool availability.

        Args:
            event: The ``ConversationItemAddedEvent`` from LiveKit.
        """
        try:
            item = event.item
            item_type = getattr(item, "type", None)

            # ── Tool snapshot on agent handoff ──
            if item_type == "agent_handoff":
                new_agent_id = getattr(item, "new_agent_id", None) or "unknown"
                self._snapshot_current_tools(
                    trigger="handoff",
                    agent_id=new_agent_id,
                )
                return

            # ── Tool snapshot on config update (dynamic tool changes) ──
            if item_type == "agent_config_update":
                self._snapshot_current_tools(trigger="config_update")
                return

            # ── Turn context tracking (user messages only) ──
            role = getattr(item, "role", None)
            if str(role) != "user":
                return

            item_id: str = getattr(item, "id", None) or uuid.uuid4().hex

            if self._turn_token is not None:
                try:
                    _current_turn.reset(self._turn_token)
                except Exception:
                    pass

            job_id: str = getattr(self._ctx, "job", None)
            if job_id is not None:
                job_id = getattr(job_id, "id", str(job_id))
            else:
                job_id = ""

            ctx = TurnContext(
                turn_id=item_id,
                session_id=self._session_id,
                job_id=job_id,
            )
            self._turn_token = _current_turn.set(ctx)

            logger.debug(
                "Turn context updated (turn_id=%s, session_id=%s)",
                item_id, self._session_id,
            )
        except Exception:
            logger.debug("Failed to handle conversation_item_added", exc_info=True)

    def _snapshot_current_tools(
        self,
        trigger: str,
        agent_id: str | None = None,
    ) -> None:
        """Read ``session.tools`` and store a timestamped snapshot.

        Called at session start, on agent handoffs, and on config updates.
        Each snapshot captures the full set of tools available at that moment.

        Args:
            trigger: Why the snapshot was taken (``session_start``, ``handoff``,
                ``config_update``).
            agent_id: The agent that owns these tools. Defaults to ``"default"``.
        """
        import time as _time

        try:
            from livekit.agents import llm

            # Tools can live in two places depending on how the user code
            # registered them:
            #   1. Agent._tools  → accessed via session.current_agent.tools
            #      (most common: tools passed to Agent() constructor or
            #       decorated with @function_tool on the Agent subclass)
            #   2. AgentSession._tools → accessed via session.tools
            #      (only when tools are passed to AgentSession(tools=...))
            # Try the agent first, then fall back to session-level tools.
            session_tools: list = []
            try:
                agent = getattr(self._session, "current_agent", None)
                if agent is not None:
                    session_tools = getattr(agent, "tools", None) or []
                    if not agent_id:
                        agent_id = getattr(agent, "label", None) or getattr(agent, "id", None)
            except Exception:
                pass  # current_agent may raise if session not fully started

            if not session_tools:
                session_tools = getattr(self._session, "tools", None) or []

            if not session_tools:
                return

            tool_defs: list[dict] = []
            for tool in session_tools:
                try:
                    serialize_tool(tool, tool_defs, llm)
                except Exception:
                    logger.debug("Could not serialize tool %r during snapshot", tool)

            if not tool_defs:
                return

            self._tool_snapshots.append({
                "agent_id": agent_id or "default",
                "trigger": trigger,
                "timestamp": _time.time(),
                "tools": tool_defs,
            })
            logger.info(
                "Tool snapshot captured (trigger=%s, agent=%s, tools=%d, total_snapshots=%d)",
                trigger, agent_id or "default", len(tool_defs), len(self._tool_snapshots),
            )
        except Exception:
            logger.debug("Failed to snapshot tools (trigger=%s)", trigger, exc_info=True)

    @staticmethod
    def _inject_speaking_timestamps(
        report_dict: dict,
        speaking_windows: list[tuple[float, float | None]],
    ) -> None:
        """Inject ``started_speaking_at``/``stopped_speaking_at`` into user messages.

        For realtime-model sessions, LiveKit creates user ``ChatMessage`` items
        in ``_on_input_audio_transcription_completed`` but does **not** set the
        speaking timestamps (their own TODO in ``agent_activity.py``).

        We match each user message to the speaking window that ended closest in
        time before its ``created_at`` (or the session report timestamp as a
        fallback).  We only patch messages that are still missing both fields so
        we never overwrite timestamps that LiveKit populated in the pipeline path.

        Args:
            report_dict: The ``report.to_dict()`` output (mutated in-place).
            speaking_windows: List of ``(started_at, stopped_at | None)`` tuples
                captured during the session.
        """
        if not speaking_windows:
            return

        chat_items = (report_dict.get("chat_history") or {}).get("items") or []
        if not chat_items:
            return

        # Close any windows that were still open at shutdown (edge case: call
        # dropped while user was mid-sentence).
        import time as _time
        now = _time.time()
        closed_windows: list[tuple[float, float]] = [
            (s, e if e is not None else now)
            for s, e in speaking_windows
        ]

        for item in chat_items:
            if item.get("type") != "message" or item.get("role") != "user":
                continue

            raw_metrics = item.get("metrics") or {}
            # Skip if already populated — don't overwrite STT-pipeline data.
            if raw_metrics.get("started_speaking_at") is not None:
                continue

            # Use created_at as the anchor; fall back to session timestamp.
            anchor = item.get("created_at") or report_dict.get("timestamp") or now

            # Find the closed window whose stopped_at is closest to (and ≤) anchor.
            # If no window ended before anchor, pick the one that started closest.
            best_window: tuple[float, float] | None = None
            best_delta = float("inf")
            for s, e in closed_windows:
                if e <= anchor:
                    delta = anchor - e
                else:
                    delta = e - anchor  # window ends after anchor; allow with penalty
                if delta < best_delta:
                    best_delta = delta
                    best_window = (s, e)

            if best_window is None:
                continue

            started, stopped = best_window
            raw_metrics["started_speaking_at"] = started
            raw_metrics["stopped_speaking_at"] = stopped
            item["metrics"] = raw_metrics

    @staticmethod
    def _extract_ended_reason(events: list[Any]) -> str | None:
        """Extract the session end reason from the raw close event.

        The LiveKit 'close' event has a 'reason' field (e.g. 'participant_disconnected',
        'job_shutdown', 'error', 'task_completed', 'user_initiated'). It IS included
        in to_dict() events list, but the backend expects it as a top-level field.

        Args:
            events: The raw list of AgentEvent objects from SessionReport.events.

        Returns:
            The reason string, or None if no close event was found.
        """
        try:
            for event in events:
                if getattr(event, "type", None) == "close":
                    return getattr(event, "reason", None)
        except Exception:
            logger.debug("Could not extract ended_reason from events")
        return None

    @staticmethod
    def _detect_call_classification(
        ctx: Any,
        stored_attrs: dict[str, dict] | None = None,
    ) -> tuple[str | None, str | None, bool, str | None]:
        """Auto-detect call_type, call_channel, is_test_call, and sip_call_id.

        Uses a three-phase lookup to handle the common race condition where the
        SIP participant (caller) has already disconnected before shutdown() runs:

        **Phase 1 — stored attributes (connect-time snapshot)**:
            ``stored_attrs`` is a ``{identity: attrs}`` dict built at
            ``participant_connected`` time.  Each entry also contains the
            synthetic key ``_vox._participant_kind`` (int) so we can determine
            participant kind even after disconnect.  This phase sets
            ``is_test_call``, ``sip_call_id``, and a fallback SIP classification.

        **Phase 2 — live participants**:
            Iterates ``ctx.room.remote_participants`` for any participant still
            in the room.  If a live SIP participant is found it takes priority
            over Phase 1 and the method returns immediately.

        **Phase 1 fallback**:
            If Phase 2 finds no live SIP participant but Phase 1 found a stored
            SIP participant (the caller already hung up), the stored
            ``sip.ruleID`` / ``sip.callID`` are used to return the correct
            ``("inbound"|"outbound", "phone", is_test_call, sip_call_id)`` tuple.

        - If no SIP participant is found in either phase:
            - call_channel = 'web'
            - call_type = None
            - sip_call_id = None

        ``is_test_call`` is True when **any** of the following are detected:

        1. A participant has attribute ``vox.test_call == "true"``
           (set by the VoiceSimulator on the WebRTC test-caller token).
        2. A SIP participant has ``sip.callerIdName == "voxgraphtest-agent"``
           (set by TelephonySimulator's ``display_name`` on the outbound SIP
           dial request — works with zero changes to customer infrastructure).

        ``stored_attrs`` contains participant attributes captured at connect-time
        (via the ``participant_connected`` event).  These survive even after the
        participant disconnects, which is critical for test-call detection.

        Args:
            ctx: The LiveKit JobContext instance.
            stored_attrs: Optional dict of {identity: attributes} captured at
                connect time.

        Returns:
            Tuple of (call_type, call_channel, is_test_call, sip_call_id).
        """
        try:
            from livekit import rtc
            is_test_call = False
            sip_call_id: str | None = None
            # Fallback SIP classification from stored (connect-time) attributes.
            # Used when the SIP participant has already disconnected (e.g. caller
            # hung up) before shutdown() runs and is no longer in remote_participants.
            _stored_sip_call_type: str | None = None
            _stored_sip_found: bool = False

            # ── Phase 1: Check stored (connect-time) attributes ──────────
            # These are available even after the participant has left the room.
            if stored_attrs:
                _sip_kind_int = int(rtc.ParticipantKind.PARTICIPANT_KIND_SIP)
                for attrs in stored_attrs.values():
                    if attrs.get("vox.test_call") == "true":
                        is_test_call = True
                    # Telephony tier: Voxgraph sets display_name="VoxGraph Test"
                    # on the outbound SIP participant, which LiveKit surfaces as
                    # sip.callerIdName. No customer infrastructure change needed.
                    if attrs.get("sip.callerIdName") == "voxgraphtest-agent":
                        is_test_call = True
                    # Capture the SIP Call-ID for retroactive test_result linkage.
                    candidate = attrs.get("sip.callID", "").strip()
                    if candidate:
                        sip_call_id = candidate
                    # If we stored the participant kind at connect-time, use it
                    # to pre-classify the call as phone/inbound|outbound so we
                    # have a fallback if Phase 2 finds no live SIP participant
                    # (the caller already hung up).
                    stored_kind = attrs.get("_vox._participant_kind")
                    if stored_kind is not None and int(stored_kind) == _sip_kind_int:
                        rule_id = attrs.get("sip.ruleID", "")
                        _stored_sip_call_type = "inbound" if rule_id else "outbound"
                        _stored_sip_found = True

            # ── Phase 2: Check live participants for SIP + remaining attrs ─
            for participant in ctx.room.remote_participants.values():
                attrs = participant.attributes or {}
                if attrs.get("vox.test_call") == "true":
                    is_test_call = True
                if attrs.get("sip.callerIdName") == "voxgraphtest-agent":
                    is_test_call = True
                if participant.kind == rtc.ParticipantKind.PARTICIPANT_KIND_SIP:
                    rule_id = attrs.get("sip.ruleID", "")
                    call_type = "inbound" if rule_id else "outbound"
                    # Prefer the live sip.callID over the stored one
                    sip_call_id = attrs.get("sip.callID", "").strip() or sip_call_id
                    return call_type, "phone", is_test_call, sip_call_id

            # ── Phase 1 fallback: caller already disconnected ─────────────
            # Phase 2 found no live SIP participant. If Phase 1 found a stored
            # SIP participant (caller hung up before shutdown), use that data.
            if _stored_sip_found:
                return _stored_sip_call_type, "phone", is_test_call, sip_call_id

            # No SIP participant found — standard web session
            return "web", "web", is_test_call, None
        except Exception:
            logger.debug("Could not detect call classification from participants")
            return None, None, False, None

    @staticmethod
    def _capture_full_options(session: Any) -> dict:
        """Read all AgentSessionOptions fields directly from the AgentSession.

        `to_dict()` only serialises a subset; reading `session.options` gives the
        complete dataclass including the 6 hidden fields.

        In livekit-agents >= 1.5.x, ``AgentSessionOptions`` gained a
        ``turn_handling`` TypedDict whose ``turn_detection`` field may hold a
        live ``LLM`` / ``_TurnDetector`` object.  ``dataclasses.asdict()``
        preserves those raw references, so we run the result through
        ``_json_safe()`` to coerce any non-primitive to ``str()``.

        Args:
            session: The LiveKit AgentSession instance.

        Returns:
            A dict of all option fields, safe for JSON serialisation.
        """
        try:
            opts = session.options  # AgentSessionOptions dataclass
            raw = dataclasses.asdict(opts)
            # tts_text_transforms is a Sequence[str] | None — ensure list[str]
            if raw.get("tts_text_transforms") is not None:
                raw["tts_text_transforms"] = [str(t) for t in raw["tts_text_transforms"]]
            return _json_safe(raw)
        except Exception:
            logger.warning("Could not capture full AgentSessionOptions; falling back to empty dict")
            return {}

    @staticmethod
    def _capture_session_data(session: Any) -> dict:
        """Capture AgentSession-level data not present in the session report.

        Captures:
        - ``userdata``: Arbitrary value set by the agent on session.userdata.
          Must be JSON-safe; non-serialisable values are coerced to ``str()``.

        Args:
            session: The LiveKit AgentSession instance.

        Returns:
            A dict with a ``userdata`` key.
        """
        result: dict = {"userdata": None}

        # --- userdata ---
        try:
            if not hasattr(session, "_userdata"):
                logger.warning(
                    "session._userdata not found — LiveKit API may have changed. "
                    "userdata will be null in the session report."
                )
            else:
                userdata = session._userdata  # read private attr to avoid ValueError guard
                if userdata is not None:
                    import json
                    try:
                        # Validate JSON-serialisability; if it passes, store as-is.
                        json.dumps(userdata)
                        result["userdata"] = userdata
                    except (TypeError, ValueError):
                        # Fall back to string representation for non-JSON-safe objects.
                        result["userdata"] = str(userdata)
        except Exception:
            logger.debug("Could not capture session.userdata")

        return result

    def __repr__(self) -> str:
        status = "started" if self._is_started else "created"
        if self._is_shutdown:
            status = "shutdown"
        return f"<VoxSession id={self._session_id} status={status}>"

    # ── Backward-compatible aliases (tests call these as static methods) ──────
    # These were static methods on VoxSession before the provider split.
    # Kept as class-level aliases so existing test code doesn't need to change.

    _json_safe = staticmethod(_json_safe)
    _extract_agent_tool_map = staticmethod(extract_agent_tool_map)
    _extract_usage_legacy = staticmethod(_extract_usage_legacy)
    _extract_usage_v15 = staticmethod(_extract_usage_v15)

    @staticmethod
    def _extract_usage(events: list) -> dict:
        """Version-gate dispatcher — reads livekit_has_model_usage_collector
        from this module's namespace so tests can monkeypatch it via
        ``voxgraph.session.livekit_has_model_usage_collector``.
        """
        import sys as _sys
        _shim = _sys.modules.get("voxgraph.session")
        _fn = getattr(_shim, "livekit_has_model_usage_collector", None) if _shim else None
        if _fn is None:
            import voxgraph.providers.livekit.session as _self_mod
            _fn = _self_mod.livekit_has_model_usage_collector
        if _fn():
            return VoxSession._extract_usage_v15(events)
        return VoxSession._extract_usage_legacy(events)

