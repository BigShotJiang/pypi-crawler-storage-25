"""Usage aggregation from LiveKit SessionReport events.

Extracted from VoxSession to keep session.py focused on lifecycle management.

Dispatches to the correct collector implementation based on the installed
livekit-agents version:
  - livekit-agents >= 1.5.0 → _extract_usage_v15()  (ModelUsageCollector)
  - livekit-agents <  1.5.0 → _extract_usage_legacy() (UsageCollector)

Must be called BEFORE ``report.to_dict()`` because ``to_dict()`` explicitly
filters out ``metrics_collected`` events.

Public function:
  extract_usage(events)  -- returns a UsagePayload-shaped dict
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from voxgraph.providers.livekit._compat import livekit_has_model_usage_collector

if TYPE_CHECKING:
    from livekit.agents.voice.events import AgentEvent

__all__ = ["extract_usage"]

logger = logging.getLogger("voxgraph.session")


def extract_usage(events: list[AgentEvent]) -> dict:
    """Aggregate usage data from raw SessionReport events.

    Dispatches to the appropriate collector implementation based on the
    installed livekit-agents version:

    - livekit-agents >= 1.5.0 → :func:`_extract_usage_v15` (``ModelUsageCollector``)
    - livekit-agents <  1.5.0 → :func:`_extract_usage_legacy` (``UsageCollector``)

    Args:
        events: The raw list of AgentEvent objects from ``SessionReport.events``.

    Returns:
        A dict matching the backend UsagePayload schema.
    """
    if livekit_has_model_usage_collector():
        return _extract_usage_v15(events)
    return _extract_usage_legacy(events)


def _extract_usage_legacy(events: list[AgentEvent]) -> dict:
    """Aggregate usage via the legacy ``UsageCollector`` (livekit-agents 1.0–1.4.x).

    Uses the (now-deprecated) ``UsageCollector`` class and reads
    ``metrics_collected`` events from the raw SessionReport event list.

    Also handles ``RealtimeModelMetrics`` events when a realtime model is used,
    mirroring the behaviour of :func:`_extract_usage_v15`:

    - ``RealtimeModelMetrics`` is imported defensively — it exists in some
      1.0–1.4.x builds but is not guaranteed, so the import is guarded.
    - Token totals are accumulated directly from the raw event fields because
      the legacy ``UsageCollector`` does not handle realtime models.
    - Realtime TTFT samples are collected and returned as private
      ``_realtime_avg_ttft`` / ``_realtime_p95_ttft`` keys for injection into
      per-turn message metrics by ``_send_report`` in ``telemetry.py``.

    Args:
        events: Raw AgentEvent list from ``SessionReport.events``.

    Returns:
        A dict matching the backend UsagePayload schema.
    """
    try:
        from livekit.agents.metrics import UsageCollector  # deprecated in 1.5.0
        from livekit.agents.metrics.base import (
            LLMMetrics, STTMetrics, TTSMetrics,
        )
    except ImportError:
        logger.warning("livekit.agents.metrics not available; usage will not be populated")
        return {}

    # RealtimeModelMetrics was introduced alongside realtime model plugins.
    # It may not exist in all livekit-agents 1.0–1.4.x builds, so import
    # defensively and treat its absence as "no realtime support in this build".
    try:
        from livekit.agents.metrics.base import RealtimeModelMetrics as _RealtimeModelMetrics
    except ImportError:
        _RealtimeModelMetrics = None  # type: ignore[assignment,misc]

    collector = UsageCollector()
    llm_models: dict[tuple, dict] = {}
    stt_models: dict[tuple, dict] = {}
    tts_models: dict[tuple, dict] = {}
    realtime_ttft_values: list[float] = []

    # Token accumulators for realtime models — the legacy UsageCollector does
    # not know about RealtimeModelMetrics, so we aggregate manually.
    realtime_prompt_tokens: int = 0
    realtime_completion_tokens: int = 0

    for event in events:
        if event.type != "metrics_collected":
            continue
        metrics = event.metrics

        # Only pass non-realtime metrics to UsageCollector — it doesn't handle
        # RealtimeModelMetrics and may raise or silently ignore them.
        is_realtime = (
            _RealtimeModelMetrics is not None
            and isinstance(metrics, _RealtimeModelMetrics)
        )
        if not is_realtime:
            collector.collect(metrics)

        meta = getattr(metrics, "metadata", None)

        if is_realtime:
            # Collect per-response TTFT for downstream injection into message
            # metrics. Skip -1 which is the "no audio token" sentinel.
            ttft = getattr(metrics, "ttft", -1)
            if ttft is not None and ttft >= 0:
                realtime_ttft_values.append(ttft)

            # v15 gets model name/provider via flatten() because ModelUsageCollector
            # maps RealtimeModelMetrics → LLMModelUsage automatically. In legacy
            # UsageCollector has no such mapping, so we capture it inline here.
            if meta is not None:
                key = (meta.model_provider or "", meta.model_name or "")
                llm_models[key] = {"provider": meta.model_provider, "model": meta.model_name}

            # v15 gets token totals via flatten() (LLMModelUsage.input_tokens /
            # output_tokens). In legacy we accumulate manually because
            # UsageCollector never sees these events.
            realtime_prompt_tokens += getattr(metrics, "input_tokens", 0)
            realtime_completion_tokens += getattr(metrics, "output_tokens", 0)

        elif isinstance(metrics, LLMMetrics):
            if meta is not None:
                key = (meta.model_provider or "", meta.model_name or "")
                llm_models[key] = {"provider": meta.model_provider, "model": meta.model_name}

        elif isinstance(metrics, STTMetrics):
            if meta is not None:
                key = (meta.model_provider or "", meta.model_name or "")
                stt_models[key] = {"provider": meta.model_provider, "model": meta.model_name}

        elif isinstance(metrics, TTSMetrics):
            if meta is not None:
                key = (meta.model_provider or "", meta.model_name or "")
                tts_models[key] = {"provider": meta.model_provider, "model": meta.model_name}

    summary = collector.get_summary()

    # For realtime sessions the UsageCollector totals are zero (it never saw
    # those events), so we layer in the manually accumulated values.
    result: dict[str, Any] = {
        "llm_prompt_tokens": summary.llm_prompt_tokens + realtime_prompt_tokens,
        "llm_completion_tokens": summary.llm_completion_tokens + realtime_completion_tokens,
        "stt_audio_duration_seconds": summary.stt_audio_duration,
        "tts_characters_count": summary.tts_characters_count,
        "llm_models": list(llm_models.values()) or None,
        "stt_models": list(stt_models.values()) or None,
        "tts_models": list(tts_models.values()) or None,
    }

    # Return realtime TTFT stats under private (underscore-prefixed) keys.
    # These are consumed by _send_report in telemetry.py to inject e2e_latency
    # and llm_node_ttft into the per-turn message metrics that the backend and
    # frontend already know how to aggregate into Avg/P95 Latency and Avg TTFT.
    # No new fields are required on the backend or frontend.
    if realtime_ttft_values:
        avg = sum(realtime_ttft_values) / len(realtime_ttft_values)
        sorted_ttfts = sorted(realtime_ttft_values)
        p95_idx = int(len(sorted_ttfts) * 0.95)
        p95 = sorted_ttfts[min(p95_idx, len(sorted_ttfts) - 1)]
        result["_realtime_avg_ttft"] = avg
        result["_realtime_p95_ttft"] = p95

    return result


def _extract_usage_v15(events: list[AgentEvent]) -> dict:
    """Aggregate usage via ``ModelUsageCollector`` (livekit-agents >= 1.5.0).

    Uses the new ``ModelUsageCollector`` that provides structured per-model
    and per-provider breakdowns via typed usage classes (``LLMModelUsage``,
    ``STTModelUsage``, ``TTSModelUsage``).

    Also handles realtime models:
    - ``RealtimeModelMetrics`` events are collected into ``LLMModelUsage`` by
      the collector (input_tokens/output_tokens map to prompt/completion).
    - Realtime-specific data (model name, audio token breakdown, TTFT) is
      captured in a separate ``realtime_models`` list.

    Args:
        events: Raw AgentEvent list from ``SessionReport.events``.

    Returns:
        A dict matching the backend UsagePayload schema, identical in shape
        to the legacy path so no backend migration is required.
    """
    try:
        from livekit.agents.metrics import ModelUsageCollector
        from livekit.agents.metrics.base import (
            LLMModelUsage, STTModelUsage, TTSModelUsage,
            LLMMetrics, STTMetrics, TTSMetrics, RealtimeModelMetrics,
        )
    except ImportError:
        logger.warning(
            "livekit.agents.metrics.ModelUsageCollector not available; "
            "falling back to legacy UsageCollector."
        )
        return _extract_usage_legacy(events)

    collector = ModelUsageCollector()
    llm_models: dict[tuple, dict] = {}
    stt_models: dict[tuple, dict] = {}
    tts_models: dict[tuple, dict] = {}
    realtime_ttft_values: list[float] = []

    for event in events:
        # ModelUsageCollector still reads from metrics_collected events —
        # the event itself is not deprecated, only the *listener* API is.
        if event.type != "metrics_collected":
            continue
        metrics = event.metrics
        collector.collect(metrics)

        meta = getattr(metrics, "metadata", None)

        if isinstance(metrics, RealtimeModelMetrics):
            # Collect per-response TTFT for downstream injection into message
            # metrics. Skip -1 which is the "no audio token" sentinel.
            ttft = getattr(metrics, "ttft", -1)
            if ttft is not None and ttft >= 0:
                realtime_ttft_values.append(ttft)

        elif isinstance(metrics, LLMMetrics):
            if meta is not None:
                key = (meta.model_provider or "", meta.model_name or "")
                llm_models[key] = {"provider": meta.model_provider, "model": meta.model_name}

        elif isinstance(metrics, STTMetrics):
            if meta is not None:
                key = (meta.model_provider or "", meta.model_name or "")
                stt_models[key] = {"provider": meta.model_provider, "model": meta.model_name}

        elif isinstance(metrics, TTSMetrics):
            if meta is not None:
                key = (meta.model_provider or "", meta.model_name or "")
                tts_models[key] = {"provider": meta.model_provider, "model": meta.model_name}

    # flatten() returns list[ModelUsage] — one entry per provider/model pair.
    # NOTE: ModelUsageCollector.collect() maps RealtimeModelMetrics → LLMModelUsage,
    # so realtime models appear in flatten() just like pipeline LLMs. No special
    # handling required — realtime model name/provider shows up in llm_models
    # automatically, which is exactly what the backend and frontend already consume.
    all_usage = collector.flatten()

    for model_usage in all_usage:
        key = (
            getattr(model_usage, "provider", None) or "",
            getattr(model_usage, "model", None) or "",
        )
        entry = {
            "provider": getattr(model_usage, "provider", None),
            "model": getattr(model_usage, "model", None),
        }
        if isinstance(model_usage, LLMModelUsage):
            llm_models[key] = entry
        elif isinstance(model_usage, STTModelUsage):
            stt_models[key] = entry
        elif isinstance(model_usage, TTSModelUsage):
            tts_models[key] = entry

    # Aggregate totals across all models for the top-level scalar fields.
    # NOTE: LLMModelUsage uses input_tokens/output_tokens (v15 field names).
    # These are correct for both pipeline LLMs and realtime models — the
    # collector maps RealtimeModelMetrics into LLMModelUsage automatically.
    llm_prompt_tokens = sum(
        getattr(u, "input_tokens", 0)
        for u in all_usage
        if isinstance(u, LLMModelUsage)
    )
    llm_completion_tokens = sum(
        getattr(u, "output_tokens", 0)
        for u in all_usage
        if isinstance(u, LLMModelUsage)
    )
    stt_audio_duration = sum(
        getattr(u, "audio_duration", 0.0)
        for u in all_usage
        if isinstance(u, STTModelUsage)
    )
    tts_characters_count = sum(
        getattr(u, "characters_count", 0)
        for u in all_usage
        if isinstance(u, TTSModelUsage)
    )

    result: dict[str, Any] = {
        "llm_prompt_tokens": llm_prompt_tokens,
        "llm_completion_tokens": llm_completion_tokens,
        "stt_audio_duration_seconds": stt_audio_duration,
        "tts_characters_count": tts_characters_count,
        "llm_models": list(llm_models.values()) or None,
        "stt_models": list(stt_models.values()) or None,
        "tts_models": list(tts_models.values()) or None,
    }

    # Return realtime TTFT stats under private (underscore-prefixed) keys.
    # These are consumed by _send_report in telemetry.py to inject e2e_latency
    # and llm_node_ttft into the per-turn message metrics that the backend and
    # frontend already know how to aggregate into Avg/P95 Latency and Avg TTFT.
    # No new fields are required on the backend or frontend.
    if realtime_ttft_values:
        avg = sum(realtime_ttft_values) / len(realtime_ttft_values)
        sorted_ttfts = sorted(realtime_ttft_values)
        p95_idx = int(len(sorted_ttfts) * 0.95)
        p95 = sorted_ttfts[min(p95_idx, len(sorted_ttfts) - 1)]
        result["_realtime_avg_ttft"] = avg
        result["_realtime_p95_ttft"] = p95

    return result
