"""Prompt fetching and injection for LiveKit agents.

Fetches the HEAD system prompt for a configured branch from the Voxgraph API
and injects it into the agent before the session starts.

Failure policy: on ANY error (network, timeout, 404, missing agent_id) this
function does nothing and returns an empty string. The agent keeps whatever
instructions the customer set in their own code. This guarantees that the
Voxgraph prompt feature is purely additive — it never breaks a live call.

When ``base_instructions`` is provided, it is always preserved — even if the
fetch fails. The merge order is: fetched prompt first (high-priority behavioral
rules), then base instructions (contextual enrichment like org info, business
hours, departments).

Public function:
  fetch_and_inject_prompt(config, http_client, agent, base_instructions) -> str
"""

from __future__ import annotations

import logging
from typing import Any

from voxgraph.config import VoxConfig

__all__ = ["fetch_and_inject_prompt"]

logger = logging.getLogger("voxgraph.session")


def _merge_instructions(fetched: str, base: str) -> str:
    """Merge fetched and base instructions into a single prompt.

    Args:
        fetched: The prompt fetched from the Voxgraph API (may be empty).
        base: The user-provided base instructions (may be empty).

    Returns:
        The merged prompt string. If both are non-empty, they are joined
        with a double newline. If only one is non-empty, it is returned
        as-is. If both are empty, returns an empty string.
    """
    parts = [p for p in (fetched, base) if p]
    return "\n\n".join(parts)


async def fetch_and_inject_prompt(
    config: VoxConfig,
    http_client: Any,
    agent: Any,
    base_instructions: str = "",
) -> str:
    """Fetch the HEAD system prompt and inject it into the agent.

    Called inside ``VoxSession.start()`` before ``session.start()`` so the
    instructions are set before any user turn begins.

    When ``base_instructions`` is provided, the final prompt is always a
    merge of the fetched content and the base — even if the fetch fails
    or returns empty. This guarantees the user's contextual prompt (org
    info, business hours, etc.) is never silently dropped.

    Args:
        config: The ``VoxConfig`` instance (provides ``agent_id``,
            ``environment``).
        http_client: Shared ``httpx.AsyncClient`` from ``TelemetrySender``
            (already base-URL configured).
        agent: The ``Agent`` instance whose instructions will be updated.
        base_instructions: Optional user-provided base prompt to preserve
            alongside (or instead of) the fetched prompt.

    Returns:
        The prompt version string if a prompt was successfully fetched,
        otherwise ``""`` (empty string).
    """
    base = base_instructions.strip() if base_instructions else ""

    if not config.agent_id:
        logger.debug("VoxSession: no agent_id set, skipping prompt fetch")
        if base:
            await agent.update_instructions(base)
            logger.info("VoxSession: base_instructions injected (no agent_id, no fetch)")
        return ""

    if not http_client:
        logger.debug("VoxSession: HTTP client not ready, skipping prompt fetch")
        if base:
            await agent.update_instructions(base)
            logger.info("VoxSession: base_instructions injected (no HTTP client, no fetch)")
        return ""

    try:
        resp = await http_client.get(
            "/api/v1/prompts/head",
            params={
                "agent_id": config.agent_id,
                "environment": config.environment,
                "name": "system_prompt",
            },
            timeout=3.0,
        )

        if resp.status_code == 200:
            data = resp.json()
            content = data.get("content", "")
            if content:
                version_number = data.get("version_number")
                prompt_version = str(version_number) if version_number is not None else ""
                merged = _merge_instructions(content, base)
                await agent.update_instructions(merged)
                logger.info(
                    "VoxSession: prompt injected from Voxgraph (env=%s, version=%s, has_base=%s)",
                    config.environment, prompt_version or "(unknown)", bool(base),
                )
                return prompt_version
            else:
                logger.debug("VoxSession: deployed prompt has empty content, skipping injection")
                if base:
                    await agent.update_instructions(base)
                    logger.info("VoxSession: base_instructions injected (fetched content was empty)")

        elif resp.status_code == 404:
            logger.debug(
                "VoxSession: no prompt deployed for env=%s (404), using agent's own instructions",
                config.environment,
            )
            if base:
                await agent.update_instructions(base)
                logger.info("VoxSession: base_instructions injected (no deployed prompt)")
        else:
            logger.warning(
                "VoxSession: prompt fetch returned unexpected status %d, using agent's own instructions",
                resp.status_code,
            )
            if base:
                await agent.update_instructions(base)
                logger.info("VoxSession: base_instructions injected (unexpected status %d)", resp.status_code)

    except Exception:
        logger.warning(
            "VoxSession: prompt fetch failed, using agent's own instructions (env=%s)",
            config.environment,
        )
        if base:
            await agent.update_instructions(base)
            logger.info("VoxSession: base_instructions injected (fetch failed)")

    return ""
