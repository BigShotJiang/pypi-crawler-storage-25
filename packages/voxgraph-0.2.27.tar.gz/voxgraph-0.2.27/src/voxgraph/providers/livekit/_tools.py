"""Tool serialization and per-agent tool map extraction for LiveKit agents.

Extracted from VoxSession to keep session.py focused on lifecycle management.

Public functions:
  serialize_tool(tool, out, llm)       -- serialize one tool/toolset into a list
  extract_agent_tool_map(...)          -- build the per-agent snapshot list sent
                                         to the backend in the session report
"""

from __future__ import annotations

import logging
from typing import Any

__all__ = ["serialize_tool", "extract_agent_tool_map"]

logger = logging.getLogger("voxgraph.session")


def serialize_tool(tool: Any, out: list[dict], llm: Any) -> None:
    """Serialize a single Tool/Toolset into the ``out`` list.

    Handles ``FunctionTool``, ``RawFunctionTool``, and ``Toolset`` (recursive).

    Args:
        tool: A LiveKit ``FunctionTool``, ``RawFunctionTool``, or ``Toolset``.
        out:  List to append serialized tool dicts into.
        llm:  The ``livekit.agents.llm`` module (passed in to avoid a
              top-level import since this module is provider-internal).
    """
    if isinstance(tool, llm.FunctionTool):
        schema = llm.utils.build_legacy_openai_schema(tool, internally_tagged=True)
        out.append({
            "name": tool.info.name,
            "description": tool.info.description,
            "parameters": schema.get("parameters"),
        })
    elif isinstance(tool, llm.RawFunctionTool):
        raw = tool.info.raw_schema
        out.append({
            "name": tool.info.name,
            "description": raw.get("description"),
            "parameters": raw.get("parameters"),
        })
    elif hasattr(tool, "tools"):
        # Toolset — recurse into sub-tools
        for sub_tool in tool.tools:
            serialize_tool(sub_tool, out, llm)


def extract_agent_tool_map(
    report: Any,
    session: Any = None,
    runtime_snapshots: list[dict] | None = None,
) -> list[dict] | None:
    """Build a per-agent tool snapshot list.

    Uses a three-tier strategy:

    1. **Runtime snapshots** (preferred): Event-driven snapshots collected
       during the session via ``VoxSession._snapshot_current_tools()``. These
       capture tools at session start, on ``AgentHandoff``, and on
       ``AgentConfigUpdate`` events. Works on all LiveKit versions.

    2. **Chat history** (fallback for >= 1.5): Scans ``report.chat_history``
       for ``AgentConfigUpdate`` items that carry ``_tools``.

    3. **Session shutdown** (last resort for 1.4.x): Reads ``session.tools``
       at shutdown time — only captures the final tool state.

    Args:
        report: The raw ``SessionReport`` object.
        session: The LiveKit ``AgentSession`` instance.
        runtime_snapshots: Snapshots collected during the session.

    Returns:
        Ordered list of per-agent tool snapshots, or ``None``.
    """
    try:
        # ── Tier 1: Runtime snapshots (event-driven, version-safe) ──
        if runtime_snapshots:
            result = []
            for seq, snap in enumerate(runtime_snapshots):
                result.append({
                    "agent_id": snap.get("agent_id", "default"),
                    "sequence": seq,
                    "tools": snap["tools"],
                })
            logger.info(
                "agent_tool_map: using %d runtime snapshots",
                len(result),
            )
            return result

        # ── Tier 2 & 3: need livekit.agents.llm ──
        from livekit.agents import llm

        # ── Tier 2: Chat history (AgentConfigUpdate._tools, >= 1.5) ──
        chat_ctx = getattr(report, "chat_history", None)
        raw_items = getattr(chat_ctx, "items", []) if chat_ctx else getattr(report, "items", [])

        if raw_items:
            snapshots: list[dict] = []
            sequence = 0
            for item in raw_items:
                if not isinstance(item, llm.AgentConfigUpdate):
                    continue
                raw_tools: list[Any] | None = getattr(item, "_tools", None)
                if not raw_tools:
                    continue

                agent_id = getattr(item, "agent_id", None) or "unknown"
                tool_defs: list[dict] = []
                for tool in raw_tools:
                    try:
                        serialize_tool(tool, tool_defs, llm)
                    except Exception:
                        logger.debug("Could not serialize tool %r", tool)

                if tool_defs:
                    snapshots.append({
                        "agent_id": agent_id,
                        "sequence": sequence,
                        "tools": tool_defs,
                    })
                    sequence += 1

            if snapshots:
                logger.info(
                    "agent_tool_map: using %d chat history snapshots",
                    len(snapshots),
                )
                return snapshots

        # ── Tier 3: session/agent tools at shutdown (last resort, 1.4.x) ──
        if session is not None:
            session_tools: list = []
            try:
                agent = getattr(session, "current_agent", None)
                if agent is not None:
                    session_tools = getattr(agent, "tools", None) or []
            except Exception:
                pass
            if not session_tools:
                session_tools = getattr(session, "tools", None) or []

            if session_tools:
                tool_defs = []
                for tool in session_tools:
                    try:
                        serialize_tool(tool, tool_defs, llm)
                    except Exception:
                        logger.debug("Could not serialize shutdown tool %r", tool)

                if tool_defs:
                    logger.info(
                        "agent_tool_map: captured %d tools via session/agent.tools (shutdown)",
                        len(tool_defs),
                    )
                    return [{"agent_id": "default", "sequence": 0, "tools": tool_defs}]

        return None

    except Exception:
        logger.exception("Could not build agent tool map")
        return None
