"""Backward-compatibility shim.

``VoxSession`` has moved to ``voxgraph.providers.livekit.session``.
This shim keeps all existing imports working without any changes.

    from voxgraph.session import VoxSession   # still works
    from voxgraph import VoxSession           # still works (canonical)
    from voxgraph.providers.livekit import VoxSession  # new canonical path
"""

from voxgraph.providers.livekit.session import VoxSession
from voxgraph.providers.livekit._compat import livekit_has_model_usage_collector

__all__ = ["VoxSession", "livekit_has_model_usage_collector"]
