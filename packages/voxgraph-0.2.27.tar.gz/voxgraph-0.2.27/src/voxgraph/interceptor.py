"""Backward-compatibility shim.

``attach_listeners`` and ``detach_listeners`` have moved to
``voxgraph.providers.livekit.interceptor``.
This shim keeps all existing imports working without any changes.

    from voxgraph.interceptor import attach_listeners, detach_listeners  # still works
"""

from voxgraph.providers.livekit.interceptor import attach_listeners, detach_listeners

__all__ = ["attach_listeners", "detach_listeners"]
