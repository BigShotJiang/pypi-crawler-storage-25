"""Backward-compatibility shim.

``AudioRecorder`` has moved to ``voxgraph.providers.livekit.audio_recorder``.

This shim registers the real module under the old path in sys.modules so that
``patch("voxgraph.audio_recorder.RecorderIO")`` and similar test patches still
work without changes.

    from voxgraph.audio_recorder import AudioRecorder   # still works
"""

import sys as _sys
import voxgraph.providers.livekit.audio_recorder as _real

# Make "voxgraph.audio_recorder" a true alias for the real module so that
# unittest.mock.patch("voxgraph.audio_recorder.X") finds and patches the right
# module attribute, not a copy.
_sys.modules[__name__] = _real
