"""Tests for fetch_and_inject_prompt() and _merge_instructions()."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from voxgraph.config import VoxConfig, DEFAULT_ENDPOINT
from voxgraph.providers.livekit._prompts import fetch_and_inject_prompt, _merge_instructions


# ---------------------------------------------------------------------------
# _merge_instructions() unit tests
# ---------------------------------------------------------------------------


class TestMergeInstructions:
    """Unit tests for the pure _merge_instructions() helper."""

    def test_both_non_empty(self):
        result = _merge_instructions("fetched prompt", "base prompt")
        assert result == "fetched prompt\n\nbase prompt"

    def test_fetched_only(self):
        result = _merge_instructions("fetched prompt", "")
        assert result == "fetched prompt"

    def test_base_only(self):
        result = _merge_instructions("", "base prompt")
        assert result == "base prompt"

    def test_both_empty(self):
        result = _merge_instructions("", "")
        assert result == ""

    def test_order_is_fetched_first(self):
        result = _merge_instructions("A", "B")
        assert result.index("A") < result.index("B")


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def config() -> VoxConfig:
    """A VoxConfig with agent_id set for prompt fetching."""
    return VoxConfig(
        api_key="test_key",
        endpoint=DEFAULT_ENDPOINT,
        debug=True,
        agent_id="test-agent-uuid",
        environment="main",
    )


@pytest.fixture
def config_no_agent() -> VoxConfig:
    """A VoxConfig without agent_id."""
    return VoxConfig(
        api_key="test_key",
        endpoint=DEFAULT_ENDPOINT,
        debug=True,
    )


@pytest.fixture
def agent() -> AsyncMock:
    """A mock Agent with async update_instructions."""
    return AsyncMock()


def _make_http_client(*, status: int = 200, json_data: dict | None = None) -> MagicMock:
    """Build a mock httpx.AsyncClient returning a canned response."""
    response = MagicMock()
    response.status_code = status
    response.json.return_value = json_data or {}

    client = MagicMock()
    client.get = AsyncMock(return_value=response)
    return client


# ---------------------------------------------------------------------------
# fetch_and_inject_prompt() integration tests
# ---------------------------------------------------------------------------


class TestFetchAndInjectPrompt:
    """Tests for the full fetch_and_inject_prompt() function."""

    async def test_fetched_plus_base_merges(self, config, agent):
        """Fetched content + base_instructions → merged prompt."""
        client = _make_http_client(json_data={
            "content": "You are a helpful assistant.",
            "version_number": 3,
        })

        version = await fetch_and_inject_prompt(
            config, client, agent,
            base_instructions="Org: Acme Corp. Hours: 9-5.",
        )

        assert version == "3"
        agent.update_instructions.assert_awaited_once()
        merged = agent.update_instructions.call_args[0][0]
        assert "You are a helpful assistant." in merged
        assert "Org: Acme Corp. Hours: 9-5." in merged
        # Fetched comes first
        assert merged.index("You are a helpful assistant.") < merged.index("Org: Acme Corp.")

    async def test_fetched_only_no_base(self, config, agent):
        """No base_instructions → behaves exactly as before (no regression)."""
        client = _make_http_client(json_data={
            "content": "You are a bot.",
            "version_number": 1,
        })

        version = await fetch_and_inject_prompt(config, client, agent)

        assert version == "1"
        agent.update_instructions.assert_awaited_once_with("You are a bot.")

    async def test_404_with_base_injects_base(self, config, agent):
        """404 (no deployed prompt) + base → base is still injected."""
        client = _make_http_client(status=404)

        version = await fetch_and_inject_prompt(
            config, client, agent,
            base_instructions="Org context here.",
        )

        assert version == ""
        agent.update_instructions.assert_awaited_once_with("Org context here.")

    async def test_404_without_base_no_injection(self, config, agent):
        """404 without base → agent instructions untouched."""
        client = _make_http_client(status=404)

        version = await fetch_and_inject_prompt(config, client, agent)

        assert version == ""
        agent.update_instructions.assert_not_awaited()

    async def test_network_error_with_base_injects_base(self, config, agent):
        """Network failure + base → base is still injected."""
        client = MagicMock()
        client.get = AsyncMock(side_effect=ConnectionError("timeout"))

        version = await fetch_and_inject_prompt(
            config, client, agent,
            base_instructions="Fallback context.",
        )

        assert version == ""
        agent.update_instructions.assert_awaited_once_with("Fallback context.")

    async def test_network_error_without_base_no_injection(self, config, agent):
        """Network failure without base → agent instructions untouched."""
        client = MagicMock()
        client.get = AsyncMock(side_effect=ConnectionError("timeout"))

        version = await fetch_and_inject_prompt(config, client, agent)

        assert version == ""
        agent.update_instructions.assert_not_awaited()

    async def test_empty_content_with_base_injects_base(self, config, agent):
        """Fetched prompt is empty string + base → base injected."""
        client = _make_http_client(json_data={
            "content": "",
            "version_number": 5,
        })

        version = await fetch_and_inject_prompt(
            config, client, agent,
            base_instructions="Always greet in French.",
        )

        assert version == ""
        agent.update_instructions.assert_awaited_once_with("Always greet in French.")

    async def test_no_agent_id_with_base_injects_base(self, config_no_agent, agent):
        """No agent_id configured + base → base is still injected, no fetch attempted."""
        client = _make_http_client()

        version = await fetch_and_inject_prompt(
            config_no_agent, client, agent,
            base_instructions="Standalone base.",
        )

        assert version == ""
        client.get.assert_not_awaited()  # No HTTP call made
        agent.update_instructions.assert_awaited_once_with("Standalone base.")

    async def test_no_agent_id_no_base_no_op(self, config_no_agent, agent):
        """No agent_id and no base → complete no-op."""
        client = _make_http_client()

        version = await fetch_and_inject_prompt(config_no_agent, client, agent)

        assert version == ""
        client.get.assert_not_awaited()
        agent.update_instructions.assert_not_awaited()

    async def test_no_http_client_with_base_injects_base(self, config, agent):
        """HTTP client not ready + base → base injected."""
        version = await fetch_and_inject_prompt(
            config, None, agent,
            base_instructions="Emergency base.",
        )

        assert version == ""
        agent.update_instructions.assert_awaited_once_with("Emergency base.")

    async def test_unexpected_status_with_base_injects_base(self, config, agent):
        """Unexpected HTTP status (500) + base → base injected."""
        client = _make_http_client(status=500)

        version = await fetch_and_inject_prompt(
            config, client, agent,
            base_instructions="Resilient base.",
        )

        assert version == ""
        agent.update_instructions.assert_awaited_once_with("Resilient base.")

    async def test_whitespace_only_base_treated_as_empty(self, config, agent):
        """Whitespace-only base_instructions → treated as empty (no injection)."""
        client = _make_http_client(status=404)

        version = await fetch_and_inject_prompt(
            config, client, agent,
            base_instructions="   \n\t  ",
        )

        assert version == ""
        agent.update_instructions.assert_not_awaited()
