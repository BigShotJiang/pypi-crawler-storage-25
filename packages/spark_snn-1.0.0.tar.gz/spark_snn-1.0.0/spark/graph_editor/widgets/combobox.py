#################################################################################################################################################
#-----------------------------------------------------------------------------------------------------------------------------------------------#
#################################################################################################################################################

from __future__ import annotations

import numpy as np
import typing as tp
from PySide6 import QtCore, QtWidgets, QtGui
import spark.core.utils as utils
from spark.graph_editor.widgets.base import QInput
from spark.graph_editor.editor_config import GRAPH_EDITOR_CONFIG
from spark.core.registry import REGISTRY
# TODO: QComboBox is functional but a QLineEdit + QListView could be better for a more standardize look.

#################################################################################################################################################
#-----------------------------------------------------------------------------------------------------------------------------------------------#
#################################################################################################################################################

class QComboBoxEdit(QtWidgets.QComboBox):
    """
        A QComboBox widget for selecting a dtype from a predefined list.
    """

    def __init__(
            self, 
            value: tp.Any, 
            options_list: list[tuple[str, tp.Any]], 
            **kwargs,
        ) -> None:
        super().__init__()

        # Populate ComboBox
        if not len(options_list) > 0:
            raise ValueError(
                f'QComboBoxEdit options_list cannot be an empty list.'
            )
        self.options_list = options_list
        for (option_name, option_data) in self.options_list:
            self.addItem(option_name, userData=option_data)
        self.set_value(value)
        # Set style
        self.setFixedHeight(GRAPH_EDITOR_CONFIG.input_field_height)
        self.setSizePolicy(
            QtWidgets.QSizePolicy.Policy.Expanding,
            QtWidgets.QSizePolicy.Policy.Fixed
        )
        # NOTE: Left padding seems to be missing 4px to match standard QLineEdit style.
        self.setStyleSheet(
            f"""
                QComboBox {{
                    background-color: {GRAPH_EDITOR_CONFIG.input_field_bg_color};
                    border-radius: {GRAPH_EDITOR_CONFIG.input_field_border_radius}px;
                    padding-left: {GRAPH_EDITOR_CONFIG.input_field_margin.left()+4}px;
                    padding-top: {GRAPH_EDITOR_CONFIG.input_field_margin.top()}px;
                    padding-right: {GRAPH_EDITOR_CONFIG.input_field_margin.right()}px;
                    padding-bottom: {GRAPH_EDITOR_CONFIG.input_field_margin.bottom()}px;
                }}
                QComboBox::drop-down {{
                    border: 0px;
                    width: 0px;
                }}
                QComboBox::down-arrow {{
                    image: none;
                    width: 0px;
                    height: 0px;
                }}
            """
        )

    def set_value(self, value: tp.Any) -> None:
        """
            Sets the current object selection.
        """
        index = self.findData(value)
        if index != -1:
            self.setCurrentIndex(index)

    def get_value(self) -> tp.Any:
        """
            Returns the currently selected object.
        """
        return self.currentData()

    def setEnabled(self, value: bool) -> None:
        return super().setEnabled(value)

#-----------------------------------------------------------------------------------------------------------------------------------------------#

class QDtype(QInput):
    """
        Custom QWidget used for dtypes fields in the SparkGraphEditor's Inspector.
    """

    def __init__(
            self,
            value: np.dtype,
            value_options: list[np.dtype],
            **kwargs,
        ) -> None:
        super().__init__()
        # Add layout
        layout = QtWidgets.QHBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        options_list = [(utils.to_human_readable(dtype.__name__), dtype) for dtype in value_options]
        self._dtype_edit = QComboBoxEdit(value, options_list)
        # Update callback
        self._dtype_edit.currentIndexChanged.connect(self._on_update)
        # Finalize
        layout.addWidget(self._dtype_edit)
        self.setLayout(layout)

    def get_value(self) -> np.dtype:
        return self._dtype_edit.get_value()
    
    def set_value(self, value: np.dtype) -> None:
        return self._dtype_edit.set_value(value)

#-----------------------------------------------------------------------------------------------------------------------------------------------#

class QBool(QInput):
    """
        Custom QWidget used for bool fields in the SparkGraphEditor's Inspector.
    """

    def __init__(
            self,
            value: bool = True,
            **kwargs,
        ) -> None:
        super().__init__()
        # Add layout
        layout = QtWidgets.QHBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        self._bool_edit = QComboBoxEdit(value, [('True', True), ('False', False)])
        # Update callback
        self._bool_edit.currentIndexChanged.connect(self._on_update)
        # Finalize
        layout.addWidget(self._bool_edit)
        self.setLayout(layout)

    def get_value(self) -> bool:
        return self._bool_edit.get_value()
    
    def set_value(self, value: bool) -> None:
        return self._bool_edit.set_value(value)

#-----------------------------------------------------------------------------------------------------------------------------------------------#

class QGenericComboBox(QInput):
    """
        Custom QWidget used for arbitrary selectable fields fields in the SparkGraphEditor's Inspector.
    """

    def __init__(
            self,
            value: str,
            value_options: dict[str, tp.Any],
            **kwargs,
        ) -> None:
        super().__init__()
        # Add layout
        layout = QtWidgets.QHBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        options_list = [(key, value) for key, value in value_options.items()]
        self._value_edit = QComboBoxEdit(value, options_list)
        # Update callback
        self._value_edit.currentIndexChanged.connect(self._on_update)
        # Finalize
        layout.addWidget(self._value_edit)
        self.setLayout(layout)

    def get_value(self) -> tp.Any:
        return self._value_edit.get_value()
    
    def set_value(self, value: tp.Any) -> None:
        return self._value_edit.set_value(value)

#################################################################################################################################################
#-----------------------------------------------------------------------------------------------------------------------------------------------#
#################################################################################################################################################