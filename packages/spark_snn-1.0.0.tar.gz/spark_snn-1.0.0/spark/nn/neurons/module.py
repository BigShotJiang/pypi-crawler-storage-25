#################################################################################################################################################
#-----------------------------------------------------------------------------------------------------------------------------------------------#
#################################################################################################################################################

from __future__ import annotations

import abc
import typing as tp
import dataclasses as dc
import spark.core.utils as utils
from math import prod
from spark.core.module import SparkModule
from spark.core.payloads import SpikeArray
from spark.core.config import DefaultSparkConfig
from spark.core.config_validation import TypeValidator

# NOTE: Although the Neuron Controller is the ideal way to build new neuronal models, we suspect that
# sometimes it may be necessary to fallback a proper SparkModule, this code serves this purpose.

#################################################################################################################################################
#-----------------------------------------------------------------------------------------------------------------------------------------------#
#################################################################################################################################################

class NeuronOutput(tp.TypedDict):
    """
       Generic Neuron model output spec.
    """
    out_spikes: SpikeArray

#-----------------------------------------------------------------------------------------------------------------------------------------------#

class NeuronModuleConfig(DefaultSparkConfig):
    """
        Abstract Neuron model configuration class.
    """
    units: tuple[int, ...] = dc.field(
        metadata = {
            'validators': [
                TypeValidator,
            ],
            'description': 'Shape of the pool of neurons.',
        })
    
    # TODO: Manual override to synchronize all time integration constants across the controller.
    # This solution is probably good enough but it is not clear that will not clash with other user intentions.
    # A similar situation is present in Neuron.__post_init__
    def __post_init__(self,) -> None:
        super().__post_init__()
        # Synchronize dt's. NOTE: Skip validation, otherwise will fall into an infinite loop.
        self.merge(partial={'_s_dt':self.dt, '_s_units':self.units}, skip_validation=True)

ConfigT = tp.TypeVar("ConfigT", bound=NeuronModuleConfig)

#-----------------------------------------------------------------------------------------------------------------------------------------------#

class NeuronModule(SparkModule, abc.ABC, tp.Generic[ConfigT]):
    """
        Abstract Neuron model.

        This is a convenience class used to synchronize data more easily.
        Can be thought as the equivalent of Sequential in standard ML frameworks.
    """
    config: ConfigT

    def __init__(self, config: ConfigT | None = None, **kwargs):
        # Initialize super.
        super().__init__(config = config, **kwargs)
        # Initialize shapes
        self.units = utils.validate_shape(self.config.units)
        self._units = prod(self.units)
        self._component_names: list[SparkModule] | None = None

    def _build(self, *abc_args, **kwargs):
        super()._build(*abc_args, **kwargs)
        self._build_component_list()
    
    def _build_component_list(self):
        """
            Inspect the object to collect the names of all child of type Component.
        """
        from spark.nn.components.base import Component

        self._component_names = []
        # Get all attribute names
        all_attr_names = []
        if hasattr(self, '__dict__'):
            all_attr_names = list(vars(self).keys())
        # Add attributes from __slots__ if they exist
        if hasattr(self, '__slots__'):
            all_attr_names.extend(self.__slots__)
        # Check the attribute's type
        for name in set(all_attr_names):
            try:
                if isinstance(getattr(self, name), Component):
                    self._component_names.append(name)
            except AttributeError:
                continue

    def reset(self):
        """
            Resets neuron states to their initial values.
        """
        # Build components list. 
        if self._component_names is None:
            self._build_component_list()
        # Reset components.
        for name in self._component_names:
            getattr(self, name).reset()

    @abc.abstractmethod
    def __call__(self, in_spikes: SpikeArray) -> NeuronOutput:
        pass

#################################################################################################################################################
#-----------------------------------------------------------------------------------------------------------------------------------------------#
#################################################################################################################################################