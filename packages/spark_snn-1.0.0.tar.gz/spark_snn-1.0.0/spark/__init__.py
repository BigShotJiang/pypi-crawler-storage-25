version = '0.1'

# Core
from spark.core.variables import Constant, Variable
from spark.core.payloads import SparkPayload, SpikeArray, CurrentArray, PotentialArray, FloatArray, IntegerArray, BooleanMask
from spark.core.specs import PortSpecs, PortMap, ModuleSpecs
from spark.core.decorators import spark_property as property
from spark.core import tracers
from spark.core import config_validation as validation
from spark.core.flax_imports import jit, eval_shape, split, merge
from spark.core.registry import (
    register_module, register_neuron, register_initializer, register_payload, register_config, register_cfg_validator,
    register_neuron_from_config, register_neuron_from_config_file
)

# NN submodule
from spark import nn

# Initialize registry.
from spark.core.registry import REGISTRY
REGISTRY._build()

# Editor
from spark.graph_editor.editor import SparkGraphEditor as GraphEditor

__all__ = [
    'nn', 
    'tracers', 
    'Constant', 'Variable',
    'SparkPayload', 'SpikeArray', 'CurrentArray', 'PotentialArray', 'FloatArray', 'IntegerArray', 'BooleanMask',
    'PortSpecs', 'PortMap', 'ModuleSpecs',
    'property',
    'validation',
    'jit', 'eval_shape', 'split', 'merge',
    'GraphEditor',
    'register_module', 'register_neuron', 'register_initializer', 'register_payload', 'register_config', 'register_cfg_validator',
    'REGISTRY',
]