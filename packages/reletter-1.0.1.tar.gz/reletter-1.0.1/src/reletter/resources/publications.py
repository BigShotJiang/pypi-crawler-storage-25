"""Publication-scoped endpoints: metadata and issues."""

from __future__ import annotations

from typing import Any

from .._base_client import AsyncBaseClient, BaseClient, quote_path


class Publications:
    """Look up a newsletter and all of its related data."""

    def __init__(self, client: BaseClient) -> None:
        self._client = client

    def get(self, publication_id: str) -> dict[str, Any]:
        """Full metadata for a publication: subscribers, engagement, social,
        contributors, recent issues, rankings.

        Raises ``BadRequestError`` if the publication ID is unknown — the API
        currently returns 400, not 404, for missing publications.
        """
        return self._client.get(f"/api/publications/{quote_path(publication_id)}/")


class AsyncPublications:
    """Async counterpart to :class:`Publications`."""

    def __init__(self, client: AsyncBaseClient) -> None:
        self._client = client

    async def get(self, publication_id: str) -> dict[str, Any]:
        return await self._client.get(
            f"/api/publications/{quote_path(publication_id)}/"
        )
