"""Contact endpoints: ``/api/contacts/``."""

from __future__ import annotations

from typing import Any

from .._base_client import AsyncBaseClient, BaseClient


class Contacts:
    """Email and social contact information for newsletters."""

    def __init__(self, client: BaseClient) -> None:
        self._client = client

    def get(self, publication_id: str) -> dict[str, Any]:
        """Email contacts, contact pages, and social accounts for a publication.
        Includes contributors where Reletter has identified them."""
        return self._client.get(
            "/api/contacts/", params=dict(publication_id=publication_id)
        )


class AsyncContacts:
    """Async counterpart to :class:`Contacts`."""

    def __init__(self, client: AsyncBaseClient) -> None:
        self._client = client

    async def get(self, publication_id: str) -> dict[str, Any]:
        return await self._client.get(
            "/api/contacts/", params=dict(publication_id=publication_id)
        )
