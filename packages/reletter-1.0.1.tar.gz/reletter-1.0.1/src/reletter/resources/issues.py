"""Issue endpoints: list and look up."""

from __future__ import annotations

from typing import Any

from .._base_client import AsyncBaseClient, BaseClient, quote_path


class Issues:
    """List and look up newsletter issues."""

    def __init__(self, client: BaseClient) -> None:
        self._client = client

    def list(self, *, publication_id: str) -> dict[str, Any]:
        """Up to 100 most recent issues for a publication, newest first.

        This endpoint does not currently paginate, so only the most recent
        ~100 issues are returned. For older issues, use ``search.issues``
        with a ``publication_id`` filter.
        """
        return self._client.get(
            "/api/issues/",
            params={"publication_id": publication_id},
        )

    def get(self, issue_id: str) -> dict[str, Any]:
        """Full data for a single issue, including the body text and the
        publication it belongs to."""
        return self._client.get(f"/api/issues/{quote_path(issue_id)}/")


class AsyncIssues:
    """Async counterpart to :class:`Issues`."""

    def __init__(self, client: AsyncBaseClient) -> None:
        self._client = client

    async def list(self, *, publication_id: str) -> dict[str, Any]:
        return await self._client.get(
            "/api/issues/",
            params={"publication_id": publication_id},
        )

    async def get(self, issue_id: str) -> dict[str, Any]:
        return await self._client.get(f"/api/issues/{quote_path(issue_id)}/")
