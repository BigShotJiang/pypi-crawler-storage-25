"""Chart endpoints: platform/category index and rankings."""

from __future__ import annotations

from typing import Any, Literal

from .._base_client import AsyncBaseClient, BaseClient, quote_path

ChartPlatform = Literal["substack", "linkedin", "reletter"]


class Charts:
    """Newsletter chart rankings."""

    def __init__(self, client: BaseClient) -> None:
        self._client = client

    def index(self) -> dict[str, Any]:
        """Available chart platforms and categories."""
        return self._client.get("/api/charts/")

    def rankings(
        self,
        platform: ChartPlatform,
        *,
        category: str,
        variant: str | None = None,
    ) -> dict[str, Any]:
        """Latest rankings for a platform / category. Use ``variant`` for
        ``paid``, ``free``, ``rising``, etc. when supported by the platform."""
        params: dict[str, Any] = {}
        if variant is not None:
            params["variant"] = variant
        return self._client.get(
            f"/api/charts/{quote_path(platform)}/{quote_path(category)}/",
            params=params or None,
        )


class AsyncCharts:
    """Async counterpart to :class:`Charts`."""

    def __init__(self, client: AsyncBaseClient) -> None:
        self._client = client

    async def index(self) -> dict[str, Any]:
        return await self._client.get("/api/charts/")

    async def rankings(
        self,
        platform: ChartPlatform,
        *,
        category: str,
        variant: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {}
        if variant is not None:
            params["variant"] = variant
        return await self._client.get(
            f"/api/charts/{quote_path(platform)}/{quote_path(category)}/",
            params=params or None,
        )
