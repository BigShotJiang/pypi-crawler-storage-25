"""Search endpoints: ``/api/search/*``."""

from __future__ import annotations

from typing import Any, AsyncIterator, Iterator, Literal

from .._base_client import AsyncBaseClient, BaseClient
from ..filters import FilterSpec, encode_filters
from ..pagination import aiter_pages, iter_pages

SearchMode = Literal["topics", "titles", "authors"]
AutocompleteMode = Literal["topics", "titles", "authors", "issues"]


def _publication_params(
    query: str | None,
    mode: str | None,
    per_page: int | None,
    page: int | None,
    filters: FilterSpec,
) -> dict[str, Any]:
    return dict(
        query=query,
        mode=mode,
        per_page=per_page,
        page=page,
        filters=encode_filters(filters),
    )


def _issue_params(
    query: str | None,
    per_page: int | None,
    page: int | None,
    filters: FilterSpec,
    highlight: bool | None,
    publication_id: str | None,
    threshold: int | None,
) -> dict[str, Any]:
    return dict(
        query=query,
        per_page=per_page,
        page=page,
        filters=encode_filters(filters),
        highlight=highlight,
        publication_id=publication_id,
        threshold=threshold,
    )


class Search:
    """Search for newsletters and issues, and get autocomplete suggestions."""

    def __init__(self, client: BaseClient) -> None:
        self._client = client

    def publications(
        self,
        *,
        query: str | None = None,
        mode: SearchMode | None = None,
        per_page: int | None = None,
        page: int | None = None,
        filters: FilterSpec = None,
    ) -> dict[str, Any]:
        """Search for newsletters by topic, title, or author.

        Specify either ``query``, ``filters``, or both.
        """
        return self._client.get(
            "/api/search/publications/",
            params=_publication_params(query, mode, per_page, page, filters),
        )

    def iter_publications(
        self,
        *,
        query: str | None = None,
        mode: SearchMode | None = None,
        filters: FilterSpec = None,
        per_page: int = 50,
        limit: int | None = None,
    ) -> Iterator[dict[str, Any]]:
        """Iterate over all matching newsletters, auto-fetching subsequent pages."""

        def fetch(page: int, per_page: int) -> dict[str, Any]:
            return self.publications(
                query=query,
                mode=mode,
                filters=filters,
                per_page=per_page,
                page=page,
            )

        return iter_pages(fetch, items_key="publications", per_page=per_page, limit=limit)

    def issues(
        self,
        *,
        query: str | None = None,
        per_page: int | None = None,
        page: int | None = None,
        filters: FilterSpec = None,
        highlight: bool | None = None,
        publication_id: str | None = None,
        threshold: int | None = None,
    ) -> dict[str, Any]:
        """Full-text search across newsletter issue titles and bodies.

        ``threshold`` restricts results to issues published in the last N
        seconds. Useful for near-realtime monitoring.
        """
        return self._client.get(
            "/api/search/issues/",
            params=_issue_params(
                query, per_page, page, filters, highlight, publication_id, threshold
            ),
        )

    def iter_issues(
        self,
        *,
        query: str | None = None,
        filters: FilterSpec = None,
        highlight: bool | None = None,
        publication_id: str | None = None,
        threshold: int | None = None,
        per_page: int = 50,
        limit: int | None = None,
    ) -> Iterator[dict[str, Any]]:
        """Iterate over all matching issues, auto-fetching subsequent pages."""

        def fetch(page: int, per_page: int) -> dict[str, Any]:
            return self.issues(
                query=query,
                filters=filters,
                highlight=highlight,
                publication_id=publication_id,
                threshold=threshold,
                per_page=per_page,
                page=page,
            )

        return iter_pages(fetch, items_key="issues", per_page=per_page, limit=limit)

    def autocomplete(self, *, mode: AutocompleteMode, query: str) -> dict[str, Any]:
        """Get suggested keywords and matching newsletters for a partial query."""
        return self._client.get(
            "/api/search/autocomplete/", params=dict(mode=mode, query=query)
        )


class AsyncSearch:
    """Async counterpart to :class:`Search`."""

    def __init__(self, client: AsyncBaseClient) -> None:
        self._client = client

    async def publications(
        self,
        *,
        query: str | None = None,
        mode: SearchMode | None = None,
        per_page: int | None = None,
        page: int | None = None,
        filters: FilterSpec = None,
    ) -> dict[str, Any]:
        return await self._client.get(
            "/api/search/publications/",
            params=_publication_params(query, mode, per_page, page, filters),
        )

    def iter_publications(
        self,
        *,
        query: str | None = None,
        mode: SearchMode | None = None,
        filters: FilterSpec = None,
        per_page: int = 50,
        limit: int | None = None,
    ) -> AsyncIterator[dict[str, Any]]:
        async def fetch(page: int, per_page: int) -> dict[str, Any]:
            return await self.publications(
                query=query,
                mode=mode,
                filters=filters,
                per_page=per_page,
                page=page,
            )

        return aiter_pages(fetch, items_key="publications", per_page=per_page, limit=limit)

    async def issues(
        self,
        *,
        query: str | None = None,
        per_page: int | None = None,
        page: int | None = None,
        filters: FilterSpec = None,
        highlight: bool | None = None,
        publication_id: str | None = None,
        threshold: int | None = None,
    ) -> dict[str, Any]:
        return await self._client.get(
            "/api/search/issues/",
            params=_issue_params(
                query, per_page, page, filters, highlight, publication_id, threshold
            ),
        )

    def iter_issues(
        self,
        *,
        query: str | None = None,
        filters: FilterSpec = None,
        highlight: bool | None = None,
        publication_id: str | None = None,
        threshold: int | None = None,
        per_page: int = 50,
        limit: int | None = None,
    ) -> AsyncIterator[dict[str, Any]]:
        async def fetch(page: int, per_page: int) -> dict[str, Any]:
            return await self.issues(
                query=query,
                filters=filters,
                highlight=highlight,
                publication_id=publication_id,
                threshold=threshold,
                per_page=per_page,
                page=page,
            )

        return aiter_pages(fetch, items_key="issues", per_page=per_page, limit=limit)

    async def autocomplete(self, *, mode: AutocompleteMode, query: str) -> dict[str, Any]:
        return await self._client.get(
            "/api/search/autocomplete/", params=dict(mode=mode, query=query)
        )
