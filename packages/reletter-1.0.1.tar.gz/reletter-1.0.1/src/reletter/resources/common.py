"""Reference data endpoints: ``/api/misc/*``.

Reference data (languages, stats) used elsewhere in the API.
"""

from __future__ import annotations

from typing import Any

from .._base_client import AsyncBaseClient, BaseClient


class Common:
    """Reference data used elsewhere in the API."""

    def __init__(self, client: BaseClient) -> None:
        self._client = client

    def languages(self) -> dict[str, Any]:
        """List every language. Codes are used with the ``languages`` filter."""
        return self._client.get("/api/misc/languages/")

    def stats(self) -> dict[str, Any]:
        """Global Reletter index stats (total publications, issues, etc.)."""
        return self._client.get("/api/misc/stats/")


class AsyncCommon:
    """Async counterpart to :class:`Common`."""

    def __init__(self, client: AsyncBaseClient) -> None:
        self._client = client

    async def languages(self) -> dict[str, Any]:
        return await self._client.get("/api/misc/languages/")

    async def stats(self) -> dict[str, Any]:
        return await self._client.get("/api/misc/stats/")
