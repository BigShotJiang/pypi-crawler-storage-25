"""Official Python client for the Reletter newsletter API.

Quick start::

    from reletter import Reletter

    client = Reletter(api_key="...")
    publication = client.publications.get("doomberg")

Or async::

    from reletter import AsyncReletter

    async with AsyncReletter(api_key="...") as client:
        publication = await client.publications.get("doomberg")

See https://reletter.com/developers for the full API reference.
"""

from ._client import AsyncReletter, Reletter
from ._exceptions import (
    APIConnectionError,
    APIStatusError,
    AuthenticationError,
    BadRequestError,
    InternalServerError,
    NotFoundError,
    PermissionDeniedError,
    RateLimitError,
    ReletterError,
)
from ._version import __version__
from .filters import FilterSpec

__all__ = [
    "Reletter",
    "AsyncReletter",
    "FilterSpec",
    "ReletterError",
    "APIConnectionError",
    "APIStatusError",
    "AuthenticationError",
    "BadRequestError",
    "PermissionDeniedError",
    "NotFoundError",
    "RateLimitError",
    "InternalServerError",
    "__version__",
]
