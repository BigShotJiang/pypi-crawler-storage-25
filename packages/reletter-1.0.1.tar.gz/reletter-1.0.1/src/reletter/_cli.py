"""Command-line interface for the Reletter newsletter API.

Entry point: ``reletter`` (installed via ``[project.scripts]``).

Emits JSON on stdout for every command; structured JSON errors on stderr.
Authentication comes from the ``RELETTER_API_KEY`` environment variable.

Exit codes:
    0  success
    1  other error (API, network, client-side)
    2  usage error (bad flags, handled by typer)
    4  authentication error (missing / invalid API key)
    5  server error (Reletter API 5xx)
"""

import json
import sys
from typing import Any, Callable, Dict, Optional, cast

import typer

from ._client import Reletter
from ._exceptions import (
    APIStatusError,
    AuthenticationError,
    InternalServerError,
    ReletterError,
)
from ._version import __version__
from .resources.charts import ChartPlatform
from .resources.search import AutocompleteMode, SearchMode

EXIT_OK = 0
EXIT_ERROR = 1
EXIT_USAGE = 2
EXIT_AUTH = 4
EXIT_SERVER = 5


def _make_typer(help_text: str, epilog: Optional[str] = None) -> typer.Typer:
    return typer.Typer(
        help=help_text,
        epilog=epilog,
        no_args_is_help=True,
        add_completion=False,
        rich_markup_mode=None,
        context_settings=dict(help_option_names=["-h", "--help"]),
    )


ROOT_EPILOG = (
    "Output is JSON on stdout; errors are JSON on stderr. "
    "Pipe through `jq` to extract fields.\n"
    "\n"
    "Auth: set RELETTER_API_KEY in the environment. "
    "Get an API key at https://reletter.com/developers.\n"
    "\n"
    "Exit codes: 0 success, 1 API or network error, 2 usage error, "
    "4 authentication error, 5 server error.\n"
    "\n"
    "Docs: https://reletter.com/developers. "
    "LLM-friendly reference: https://reletter.com/llms-full.txt."
)


app = _make_typer(
    "Reletter newsletter intelligence API from the command line.",
    epilog=ROOT_EPILOG,
)
search_app = _make_typer("Search newsletters and issues.")
publications_app = _make_typer("Look up newsletter metadata.")
issues_app = _make_typer("List and look up newsletter issues.")
contacts_app = _make_typer("Email and social contacts for newsletters.")
charts_app = _make_typer("Newsletter chart rankings.")
common_app = _make_typer("Reference data (languages, stats).")
account_app = _make_typer("Account quota and usage.")

app.add_typer(search_app, name="search")
app.add_typer(publications_app, name="publications")
app.add_typer(issues_app, name="issues")
app.add_typer(contacts_app, name="contacts")
app.add_typer(charts_app, name="charts")
app.add_typer(common_app, name="common")
app.add_typer(account_app, name="account")


def _version_callback(value: bool) -> None:
    if value:
        typer.echo(__version__)
        raise typer.Exit()


@app.callback()
def _root(
    version: Optional[bool] = typer.Option(
        None,
        "--version",
        help="Print version and exit.",
        callback=_version_callback,
        is_eager=True,
    ),
) -> None:
    """Reletter newsletter intelligence API."""


def _make_client() -> Reletter:
    """Instantiate a ``Reletter`` client. Tests can monkey-patch this."""
    return Reletter()


def _emit_json(payload: Any) -> None:
    json.dump(payload, sys.stdout, ensure_ascii=False, indent=2, sort_keys=False)
    sys.stdout.write("\n")


def _emit_error(
    message: str,
    *,
    error_type: str,
    status_code: Optional[int] = None,
    body: Optional[Any] = None,
) -> None:
    payload: Dict[str, Any] = dict(error=dict(type=error_type, message=message))
    if status_code is not None:
        payload["error"]["status_code"] = status_code
    if body is not None:
        payload["error"]["body"] = body
    json.dump(payload, sys.stderr, ensure_ascii=False, indent=2, sort_keys=False)
    sys.stderr.write("\n")


def _parse_filters(raw: Optional[str]) -> Any:
    """Accept a JSON dict, JSON list, or raw DSL string for --filters."""
    if raw is None:
        return None
    stripped = raw.lstrip()
    if stripped.startswith(("{", "[")):
        try:
            return json.loads(raw)
        except json.JSONDecodeError as exc:
            raise typer.BadParameter(f"--filters is not valid JSON: {exc}") from exc
    return raw


def _run(fn: Callable[[Reletter], Any]) -> None:
    """Execute a resource call, emit JSON on success, structured error + exit otherwise."""
    try:
        client = _make_client()
    except ValueError as exc:
        _emit_error(str(exc), error_type="AuthenticationError")
        raise typer.Exit(code=EXIT_AUTH) from None

    try:
        try:
            result = fn(client)
        finally:
            client.close()
    except AuthenticationError as exc:
        _emit_error(
            exc.message,
            error_type=type(exc).__name__,
            status_code=exc.status_code,
            body=exc.body,
        )
        raise typer.Exit(code=EXIT_AUTH) from None
    except InternalServerError as exc:
        _emit_error(
            exc.message,
            error_type=type(exc).__name__,
            status_code=exc.status_code,
            body=exc.body,
        )
        raise typer.Exit(code=EXIT_SERVER) from None
    except APIStatusError as exc:
        _emit_error(
            exc.message,
            error_type=type(exc).__name__,
            status_code=exc.status_code,
            body=exc.body,
        )
        raise typer.Exit(code=EXIT_ERROR) from None
    except ReletterError as exc:
        _emit_error(str(exc), error_type=type(exc).__name__)
        raise typer.Exit(code=EXIT_ERROR) from None

    _emit_json(result)


# --- search --------------------------------------------------------------


@search_app.command("publications")
def search_publications(
    query: Optional[str] = typer.Option(None, "--query", "-q", help="Search query."),
    mode: Optional[str] = typer.Option(
        None, "--mode", help='"topics" (default), "titles", or "authors".'
    ),
    per_page: Optional[int] = typer.Option(None, "--per-page"),
    page: Optional[int] = typer.Option(None, "--page"),
    filters: Optional[str] = typer.Option(
        None,
        "--filters",
        help='Stripe-style JSON dict (\'{"subscribers":{"gte":5000}}\'), '
        "JSON list, or legacy DSL string.",
    ),
) -> None:
    """Search for newsletters by topic, title, or author.

    Example: reletter search publications --query "marketing" --filters '{"subscribers":{"gte":10000},"active":true}'
    """
    parsed = _parse_filters(filters)
    _run(
        lambda c: c.search.publications(
            query=query,
            mode=cast("Optional[SearchMode]", mode),
            per_page=per_page,
            page=page,
            filters=parsed,
        )
    )


@search_app.command("issues")
def search_issues(
    query: Optional[str] = typer.Option(None, "--query", "-q"),
    per_page: Optional[int] = typer.Option(None, "--per-page"),
    page: Optional[int] = typer.Option(None, "--page"),
    filters: Optional[str] = typer.Option(None, "--filters"),
    highlight: Optional[bool] = typer.Option(None, "--highlight/--no-highlight"),
    publication_id: Optional[str] = typer.Option(None, "--publication-id"),
    threshold: Optional[int] = typer.Option(
        None,
        "--threshold",
        help="Restrict to issues published in the last N seconds.",
    ),
) -> None:
    """Full-text search across newsletter issue titles and bodies.

    Example: reletter search issues --query "openai" --threshold 604800
    """
    parsed = _parse_filters(filters)
    _run(
        lambda c: c.search.issues(
            query=query,
            per_page=per_page,
            page=page,
            filters=parsed,
            highlight=highlight,
            publication_id=publication_id,
            threshold=threshold,
        )
    )


@search_app.command("autocomplete")
def search_autocomplete(
    mode: str = typer.Option(
        ..., "--mode", help='"topics", "titles", "authors", or "issues".'
    ),
    query: str = typer.Option(..., "--query", "-q"),
) -> None:
    """Suggest keywords and matching newsletters for a partial query."""
    _run(
        lambda c: c.search.autocomplete(
            mode=cast("AutocompleteMode", mode), query=query
        )
    )


# --- publications --------------------------------------------------------


@publications_app.command("get")
def publications_get(
    publication_id: str = typer.Argument(..., metavar="PUBLICATION_ID"),
) -> None:
    """Full metadata for a publication.

    Example: reletter publications get doomberg
    """
    _run(lambda c: c.publications.get(publication_id))


# --- issues --------------------------------------------------------------


@issues_app.command("list")
def issues_list(
    publication_id: str = typer.Option(..., "--publication-id"),
) -> None:
    """Up to 100 most recent issues for a publication."""
    _run(lambda c: c.issues.list(publication_id=publication_id))


@issues_app.command("get")
def issues_get(
    issue_id: str = typer.Argument(..., metavar="ISSUE_ID"),
) -> None:
    """Full data for a single issue, including body text."""
    _run(lambda c: c.issues.get(issue_id))


# --- contacts ------------------------------------------------------------


@contacts_app.command("get")
def contacts_get(
    publication_id: str = typer.Argument(..., metavar="PUBLICATION_ID"),
) -> None:
    """Email contacts, contact pages, social accounts for a publication."""
    _run(lambda c: c.contacts.get(publication_id))


# --- charts --------------------------------------------------------------


@charts_app.command("index")
def charts_index() -> None:
    """Available chart platforms and categories."""
    _run(lambda c: c.charts.index())


@charts_app.command("rankings")
def charts_rankings(
    platform: str = typer.Argument(..., metavar="PLATFORM"),
    category: str = typer.Option(..., "--category"),
    variant: Optional[str] = typer.Option(None, "--variant"),
) -> None:
    """Latest chart rankings.

    Example: reletter charts rankings substack --category top-50
    """
    _run(
        lambda c: c.charts.rankings(
            cast("ChartPlatform", platform), category=category, variant=variant
        )
    )


# --- common --------------------------------------------------------------


@common_app.command("languages")
def common_languages() -> None:
    """List every language."""
    _run(lambda c: c.common.languages())


@common_app.command("stats")
def common_stats() -> None:
    """Global Reletter index stats."""
    _run(lambda c: c.common.stats())


# --- account -------------------------------------------------------------


@account_app.command("quota")
def account_quota() -> None:
    """API request quota and usage for the current month."""
    _run(lambda c: c.account.quota())


def main() -> None:
    app()


if __name__ == "__main__":
    main()
