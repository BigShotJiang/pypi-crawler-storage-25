"""The top-level :class:`Reletter` and :class:`AsyncReletter` clients."""

from __future__ import annotations

import os
from typing import Any

import httpx

from ._base_client import (
    DEFAULT_BASE_URL,
    DEFAULT_MAX_RETRIES,
    DEFAULT_TIMEOUT,
    AsyncBaseClient,
    BaseClient,
)
from .resources import (
    Account,
    AsyncAccount,
    AsyncCharts,
    AsyncCommon,
    AsyncContacts,
    AsyncIssues,
    AsyncPublications,
    AsyncSearch,
    Charts,
    Common,
    Contacts,
    Issues,
    Publications,
    Search,
)

ENV_API_KEY = "RELETTER_API_KEY"


def _resolve_api_key(api_key: str | None) -> str:
    resolved = api_key or os.environ.get(ENV_API_KEY)
    if not resolved:
        raise ValueError(
            "No API key provided. Pass api_key=... or set the RELETTER_API_KEY "
            "environment variable. Get one at https://reletter.com/developers."
        )
    return resolved


class Reletter:
    """Official Python client for the Reletter newsletter API.

    Get an API key at https://reletter.com/developers.

    Args:
        api_key: Your Reletter API key. Falls back to ``RELETTER_API_KEY`` env.
        base_url: Override the API base URL.
        timeout: Request timeout in seconds.
        max_retries: Retries on connection errors, 429s, and 5xxs (default 2).
        http_client: Bring your own ``httpx.Client`` (for proxies, custom TLS).

    Example::

        from reletter import Reletter

        client = Reletter(api_key="...")
        publication = client.publications.get("doomberg")
    """

    def __init__(
        self,
        api_key: str | None = None,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
        http_client: httpx.Client | None = None,
    ) -> None:
        self._base_client = BaseClient(
            api_key=_resolve_api_key(api_key),
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
            http_client=http_client,
        )

        self.search = Search(self._base_client)
        self.publications = Publications(self._base_client)
        self.issues = Issues(self._base_client)
        self.contacts = Contacts(self._base_client)
        self.charts = Charts(self._base_client)
        self.common = Common(self._base_client)
        self.account = Account(self._base_client)

    def close(self) -> None:
        """Close the underlying HTTP client (if owned by this instance)."""
        self._base_client.close()

    def __enter__(self) -> Reletter:
        return self

    def __exit__(self, *exc_info: Any) -> None:
        self.close()


class AsyncReletter:
    """Asynchronous client for the Reletter newsletter API.

    Same surface as :class:`Reletter`, but every resource method is a
    coroutine. ``iter_*`` methods return async iterators.

    Example::

        from reletter import AsyncReletter

        async with AsyncReletter(api_key="...") as client:
            publication = await client.publications.get("doomberg")
            async for p in client.search.iter_publications(query="ai", limit=100):
                print(p["title"])
    """

    def __init__(
        self,
        api_key: str | None = None,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
        http_client: httpx.AsyncClient | None = None,
    ) -> None:
        self._base_client = AsyncBaseClient(
            api_key=_resolve_api_key(api_key),
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
            http_client=http_client,
        )

        self.search = AsyncSearch(self._base_client)
        self.publications = AsyncPublications(self._base_client)
        self.issues = AsyncIssues(self._base_client)
        self.contacts = AsyncContacts(self._base_client)
        self.charts = AsyncCharts(self._base_client)
        self.common = AsyncCommon(self._base_client)
        self.account = AsyncAccount(self._base_client)

    async def aclose(self) -> None:
        """Close the underlying async HTTP client (if owned by this instance)."""
        await self._base_client.aclose()

    async def __aenter__(self) -> AsyncReletter:
        return self

    async def __aexit__(self, *exc_info: Any) -> None:
        await self.aclose()
