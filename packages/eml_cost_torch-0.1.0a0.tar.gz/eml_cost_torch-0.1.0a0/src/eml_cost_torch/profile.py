"""Per-layer Pfaffian profile of a PyTorch ``nn.Module``.

Maps each activation/layer class to its Pfaffian chain order under the
standard registry. Linear/Conv/Norm layers contribute polynomial cost
(r=0); activations contribute according to their analytical form.

The profile output is informational, intended as a routing input for
architecture search and training-cost prediction. It does NOT execute
the model; it inspects the module graph statically.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    import torch.nn as nn


# ---------------------------------------------------------------------------
# Activation -> (pfaffian_r, eml_depth, is_pfaffian_not_eml, friendly_name)
# Mirrors the cross-domain-2 Session 9 Pareto-frontier mapping.
# ---------------------------------------------------------------------------

ACTIVATION_PROFILE: dict[str, tuple[int, int, bool, str]] = {
    # name                  : (r, depth, non_eml, friendly)
    "Identity":               (0, 1, False, "identity"),
    "ReLU":                   (0, 1, False, "ReLU"),
    "ReLU6":                  (0, 1, False, "ReLU6"),
    "LeakyReLU":              (0, 1, False, "LeakyReLU"),
    "PReLU":                  (0, 1, False, "PReLU"),
    "RReLU":                  (0, 1, False, "RReLU"),
    "Threshold":              (0, 1, False, "Threshold"),
    "Hardtanh":               (0, 1, False, "Hardtanh"),
    "Hardshrink":             (0, 1, False, "Hardshrink"),
    "Softshrink":             (0, 1, False, "Softshrink"),
    # Hyperbolic / sigmoid family (F-family fusion targets)
    "Sigmoid":                (1, 1, False, "sigmoid"),
    "Tanh":                   (1, 1, False, "tanh"),
    "LogSigmoid":             (1, 2, False, "LogSigmoid"),
    "Hardsigmoid":            (0, 1, False, "Hardsigmoid"),
    "Hardswish":              (0, 1, False, "Hardswish"),
    # Exp/log
    "ELU":                    (1, 2, False, "ELU"),
    "CELU":                   (1, 2, False, "CELU"),
    "SELU":                   (1, 2, False, "SELU"),
    "SiLU":                   (1, 2, False, "Swish/SiLU"),
    "Mish":                   (3, 4, False, "Mish"),
    "Softplus":               (1, 1, False, "softplus"),
    "Softsign":               (1, 2, False, "softsign"),
    # Non-EML (uses erf)
    "GELU":                   (0, 0, True,  "GELU (non-EML, erf)"),
    # Softmax-family (parallel chains)
    "Softmax":                (1, 2, False, "softmax (parallel)"),
    "LogSoftmax":             (1, 3, False, "log_softmax"),
    "Softmin":                (1, 2, False, "softmin"),
    "AdaptiveLogSoftmaxWithLoss": (1, 3, False, "adaptive_log_softmax"),
    # Polynomial / linear
    "Linear":                 (0, 1, False, "linear (matmul)"),
    "Conv1d":                 (0, 1, False, "conv1d"),
    "Conv2d":                 (0, 1, False, "conv2d"),
    "Conv3d":                 (0, 1, False, "conv3d"),
    "ConvTranspose1d":        (0, 1, False, "conv_transpose1d"),
    "ConvTranspose2d":        (0, 1, False, "conv_transpose2d"),
    "ConvTranspose3d":        (0, 1, False, "conv_transpose3d"),
    # Norm (sqrt; F-family primitive)
    "BatchNorm1d":            (0, 1, False, "batchnorm1d"),
    "BatchNorm2d":            (0, 1, False, "batchnorm2d"),
    "BatchNorm3d":            (0, 1, False, "batchnorm3d"),
    "LayerNorm":              (0, 1, False, "layernorm"),
    "GroupNorm":              (0, 1, False, "groupnorm"),
    "InstanceNorm1d":         (0, 1, False, "instancenorm1d"),
    "InstanceNorm2d":         (0, 1, False, "instancenorm2d"),
    "RMSNorm":                (0, 1, False, "rmsnorm"),
    # Pool / dropout (no chain)
    "MaxPool1d":              (0, 1, False, "maxpool1d"),
    "MaxPool2d":              (0, 1, False, "maxpool2d"),
    "AvgPool1d":              (0, 1, False, "avgpool1d"),
    "AvgPool2d":              (0, 1, False, "avgpool2d"),
    "AdaptiveAvgPool2d":      (0, 1, False, "adaptive_avgpool"),
    "Dropout":                (0, 0, False, "dropout"),
    "Dropout2d":              (0, 0, False, "dropout2d"),
    # Embedding / lookup
    "Embedding":              (0, 1, False, "embedding"),
    "EmbeddingBag":           (0, 1, False, "embedding_bag"),
    # Attention (parallel chains; counted at MultiheadAttention level)
    "MultiheadAttention":     (1, 2, False, "multihead_attention (parallel)"),
}


@dataclass(frozen=True)
class LayerProfile:
    """Per-layer Pfaffian classification."""

    name: str
    cls_name: str
    activation: str
    pfaffian_r: int
    eml_depth: int
    is_pfaffian_not_eml: bool
    n_params: int


@dataclass(frozen=True)
class ModelProfile:
    """Aggregate Pfaffian profile of a torch model."""

    layers: list[LayerProfile] = field(default_factory=list)
    total_layers: int = 0
    total_pfaffian_depth: int = 0
    total_eml_depth: int = 0
    transcendental_layer_count: int = 0
    non_eml_layer_count: int = 0
    estimated_pfaffian_width: int = 0
    total_params: int = 0


def _count_params(module: "nn.Module") -> int:
    return sum(p.numel() for p in module.parameters(recurse=False))


def _classify(module: "nn.Module") -> tuple[int, int, bool, str]:
    """Look up the (r, depth, non_eml, friendly) tuple for a module."""
    cls_name = type(module).__name__
    return ACTIVATION_PROFILE.get(cls_name, (0, 0, False, cls_name))


def profile(model: "nn.Module") -> ModelProfile:
    """Walk a ``torch.nn.Module`` and return a per-layer Pfaffian profile.

    Iterates over ``named_modules()`` excluding the root container.
    Each layer is classified by its Python class name against the
    ``ACTIVATION_PROFILE`` registry. Unknown layers default to (r=0, d=0).
    """
    layers: list[LayerProfile] = []
    total_r = 0
    total_d = 0
    transc_count = 0
    non_eml_count = 0
    parallel_count = 0
    total_params = 0

    for name, module in model.named_modules():
        if name == "":  # skip the root container
            continue
        # Skip pure containers (nothing to profile)
        cls_name = type(module).__name__
        if cls_name in ("Sequential", "ModuleList", "ModuleDict"):
            continue
        r, d, non_eml, friendly = _classify(module)
        n_params = _count_params(module)
        layers.append(LayerProfile(
            name=name,
            cls_name=cls_name,
            activation=friendly,
            pfaffian_r=r,
            eml_depth=d,
            is_pfaffian_not_eml=non_eml,
            n_params=n_params,
        ))
        total_r += r
        total_d += d
        total_params += n_params
        if r >= 1:
            transc_count += 1
        if non_eml:
            non_eml_count += 1
        if cls_name in ("MultiheadAttention", "Softmax", "LogSoftmax", "Softmin"):
            parallel_count += 1

    return ModelProfile(
        layers=layers,
        total_layers=len(layers),
        total_pfaffian_depth=total_r,
        total_eml_depth=total_d,
        transcendental_layer_count=transc_count,
        non_eml_layer_count=non_eml_count,
        estimated_pfaffian_width=parallel_count,
        total_params=total_params,
    )
