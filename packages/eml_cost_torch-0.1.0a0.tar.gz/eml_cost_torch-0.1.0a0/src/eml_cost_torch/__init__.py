"""eml-cost-torch — Pfaffian profile per PyTorch layer.

Walks a ``torch.nn.Module``, identifies the activation function per layer,
maps to Pfaffian r/depth/width, and returns a layer-by-layer profile
suitable for architecture-search heuristics.

    >>> import torch.nn as nn
    >>> from eml_cost_torch import profile
    >>> model = nn.Sequential(
    ...     nn.Linear(128, 64),
    ...     nn.ReLU(),
    ...     nn.Linear(64, 32),
    ...     nn.GELU(),
    ...     nn.Linear(32, 10),
    ... )
    >>> p = profile(model)
    >>> p.total_pfaffian_depth
    >>> p.transcendental_layer_count
    >>> for layer in p.layers:
    ...     print(layer.name, layer.activation, layer.pfaffian_r)
"""
from __future__ import annotations

from .profile import LayerProfile, ModelProfile, profile

__version__ = "0.1.0a0"

__all__ = [
    "__version__",
    "profile",
    "ModelProfile",
    "LayerProfile",
]
