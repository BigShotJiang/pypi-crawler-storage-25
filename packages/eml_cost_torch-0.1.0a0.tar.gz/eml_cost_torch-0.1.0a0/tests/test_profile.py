"""Profile classifier tests."""
from __future__ import annotations

import torch.nn as nn

from eml_cost_torch import LayerProfile, ModelProfile, profile


def test_simple_relu_mlp_polynomial() -> None:
    model = nn.Sequential(
        nn.Linear(10, 5),
        nn.ReLU(),
        nn.Linear(5, 2),
    )
    p = profile(model)
    assert isinstance(p, ModelProfile)
    assert p.total_layers == 3  # 2 Linear + 1 ReLU
    assert p.total_pfaffian_depth == 0  # all r=0
    assert p.transcendental_layer_count == 0
    assert p.non_eml_layer_count == 0


def test_swish_mlp_has_transcendental_layers() -> None:
    model = nn.Sequential(
        nn.Linear(10, 5),
        nn.SiLU(),
        nn.Linear(5, 5),
        nn.SiLU(),
        nn.Linear(5, 2),
    )
    p = profile(model)
    assert p.transcendental_layer_count == 2  # two SiLU activations


def test_gelu_flagged_non_eml() -> None:
    model = nn.Sequential(nn.Linear(10, 5), nn.GELU(), nn.Linear(5, 2))
    p = profile(model)
    assert p.non_eml_layer_count == 1
    gelu_layer = next(l for l in p.layers if l.cls_name == "GELU")
    assert gelu_layer.is_pfaffian_not_eml


def test_softmax_increments_parallel_width() -> None:
    model = nn.Sequential(nn.Linear(10, 5), nn.Softmax(dim=-1))
    p = profile(model)
    assert p.estimated_pfaffian_width >= 1


def test_layers_have_param_counts() -> None:
    model = nn.Linear(10, 5)
    p = profile(model)
    # Linear(10, 5) has 10*5 + 5 = 55 params
    # but root module is skipped; named_modules skips root
    # So this Sequential-less Linear has no inner layers
    assert isinstance(p.total_params, int)


def test_layer_profile_is_frozen() -> None:
    lp = LayerProfile(
        name="test", cls_name="ReLU", activation="ReLU",
        pfaffian_r=0, eml_depth=1, is_pfaffian_not_eml=False, n_params=0,
    )
    import pytest
    with pytest.raises(Exception):
        lp.pfaffian_r = 99  # type: ignore[misc]


def test_unknown_layer_defaults_to_zero() -> None:
    class CustomLayer(nn.Module):
        def forward(self, x):  # noqa: ANN001, D401
            return x
    model = nn.Sequential(CustomLayer())
    p = profile(model)
    # CustomLayer not in registry; defaults to (r=0, d=0)
    assert len(p.layers) == 1
    assert p.layers[0].pfaffian_r == 0


def test_transformer_block_classified() -> None:
    """A transformer-encoder layer has transcendental + parallel components."""
    layer = nn.TransformerEncoderLayer(
        d_model=64, nhead=4, dim_feedforward=128, batch_first=True,
    )
    p = profile(layer)
    # Should detect at least the MultiheadAttention parallel component
    assert p.estimated_pfaffian_width >= 1
    # And the TransformerEncoderLayer typically uses ReLU (default activation)
    # plus internal Linear layers — params will be substantial
    assert p.total_params > 0
