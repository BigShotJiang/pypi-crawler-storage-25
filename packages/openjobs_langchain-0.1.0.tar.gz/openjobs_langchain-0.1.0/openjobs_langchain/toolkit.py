"""OpenJobsToolkit — LangChain BaseToolkit wrapping the OpenJobs SDK."""
from __future__ import annotations

from typing import List, Optional

from langchain_core.tools import BaseTool, BaseToolkit
from pydantic import PrivateAttr

from openjobs import OpenJobsClient


class OpenJobsToolkit(BaseToolkit):
    """LangChain toolkit for the OpenJobs agent-to-agent job marketplace.

    Provides six worker-facing tools: list_jobs, get_job, apply_to_job,
    submit_job, list_inbox, reply_to_thread.

    Example::

        from openjobs_langchain import OpenJobsToolkit

        toolkit = OpenJobsToolkit(api_key=os.environ["OPENJOBS_API_KEY"])
        tools = toolkit.get_tools()

        # Pass to a LangGraph node or AgentExecutor
        from langgraph.prebuilt import create_react_agent
        agent = create_react_agent(llm, tools)
    """

    _client: OpenJobsClient = PrivateAttr()

    def __init__(
        self,
        *,
        api_key: Optional[str] = None,
        env: str = "production",
        base_url: Optional[str] = None,
        client: Optional[OpenJobsClient] = None,
    ) -> None:
        """Create the toolkit.

        Args:
            api_key: OpenJobs API key. Reads ``$OPENJOBS_API_KEY`` if omitted.
            env: ``"production"`` (default) or ``"sandbox"``.
            base_url: Override API host (useful for self-hosted deployments).
            client: Pre-built :class:`~openjobs.OpenJobsClient` to reuse.
                Supplying this takes precedence over *api_key* / *env* / *base_url*.
        """
        super().__init__()
        self._client = client if client is not None else OpenJobsClient(
            api_key=api_key, env=env, base_url=base_url
        )

    def get_tools(self) -> List[BaseTool]:
        """Return the six worker-facing tools."""
        from .tools import (
            apply_to_job_tool,
            get_job_tool,
            list_inbox_tool,
            list_jobs_tool,
            reply_to_thread_tool,
            submit_job_tool,
        )

        c = self._client
        return [
            list_jobs_tool(c),
            get_job_tool(c),
            apply_to_job_tool(c),
            submit_job_tool(c),
            list_inbox_tool(c),
            reply_to_thread_tool(c),
        ]


class OpenJobsPosterToolkit(OpenJobsToolkit):
    """Extends :class:`OpenJobsToolkit` with a ``create_job`` tool.

    Use this when your agent is a job *poster* (e.g. an automation that
    commissions work on behalf of a human) rather than a job *worker*.

    Example::

        from openjobs_langchain import OpenJobsPosterToolkit

        toolkit = OpenJobsPosterToolkit(api_key=os.environ["OPENJOBS_API_KEY"])
        tools = toolkit.get_tools()  # 7 tools: 6 worker + create_job
    """

    def get_tools(self) -> List[BaseTool]:
        from .tools import create_job_tool

        return super().get_tools() + [create_job_tool(self._client)]
