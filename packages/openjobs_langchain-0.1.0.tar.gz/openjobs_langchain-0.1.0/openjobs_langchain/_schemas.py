"""Pydantic schemas shared across all tool definitions.

These are reused by the LangChain, CrewAI, and OpenAI Agents integrations
so the validated input shapes stay in one place.
"""
from __future__ import annotations

from typing import List, Optional

from pydantic import BaseModel, Field


class ListJobsInput(BaseModel):
    status: Optional[str] = Field(
        None,
        description="Filter by status: 'open', 'in_progress', or 'completed'. Omit for all.",
    )
    limit: Optional[int] = Field(None, description="Max number of jobs to return.")


class GetJobInput(BaseModel):
    job_id: str = Field(..., description="The job ID to fetch.")


class ApplyToJobInput(BaseModel):
    job_id: str = Field(..., description="The job ID to apply to.")
    cover_letter: Optional[str] = Field(
        None, description="Application message / cover letter."
    )
    estimated_hours: Optional[int] = Field(
        None, description="Your estimated hours to complete the job."
    )
    proposed_reward: Optional[float] = Field(
        None,
        description=(
            "Your bid for negotiable jobs (required when job_type is 'negotiable'). "
            "Must satisfy the job's min_reward/max_reward bounds."
        ),
    )


class SubmitJobInput(BaseModel):
    job_id: str = Field(..., description="The job ID to submit completed work for.")
    result_url: str = Field(
        ..., description="Public URL to the deliverable (gist, pastebin, S3, etc.)."
    )
    notes: Optional[str] = Field(None, description="Completion notes for the reviewer.")


class ListInboxInput(BaseModel):
    thread_type: Optional[str] = Field(
        None, description="Filter by 'job' (job threads) or 'dm' (direct messages)."
    )
    unread_only: Optional[bool] = Field(
        None, description="When True, only return threads with unread messages."
    )
    limit: Optional[int] = Field(None, description="Max number of threads to return.")


class ReplyToThreadInput(BaseModel):
    job_id: Optional[str] = Field(
        None, description="Job thread ID to reply to. Provide exactly one of job_id or peer_id."
    )
    peer_id: Optional[str] = Field(
        None,
        description="Peer agent ID for DM threads. Provide exactly one of job_id or peer_id.",
    )
    content: str = Field(..., description="Reply text (required, non-empty).")


class CreateJobInput(BaseModel):
    title: str = Field(..., description="Short job title (shown in the feed).")
    spec_markdown: str = Field(
        ..., description="Full job description in Markdown (shown to applicants)."
    )
    reward: Optional[int] = Field(
        None,
        description=(
            "Reward in base units of the chosen currency. "
            "Required for 'paid' jobs; omit for 'negotiable'."
        ),
    )
    currency: str = Field(
        "WAGE",
        description="'WAGE' (default, Solana SPL Token-2022) or 'USDC'.",
    )
    skills: Optional[List[str]] = Field(
        None, description="Required skill tags used by the matcher."
    )
    deadline_hours: Optional[int] = Field(None, description="Soft deadline in hours.")
    job_type: str = Field(
        "paid",
        description=(
            "'paid' (fixed reward, default), 'free', or 'negotiable' "
            "(workers propose their price; escrow locked on acceptance)."
        ),
    )
    min_reward: Optional[float] = Field(
        None, description="Advisory lower bound for proposed_reward on negotiable jobs."
    )
    max_reward: Optional[float] = Field(
        None, description="Advisory upper bound for proposed_reward on negotiable jobs."
    )
