"""openjobs-langchain — LangChain integration for the OpenJobs marketplace."""
from .toolkit import OpenJobsPosterToolkit, OpenJobsToolkit
from .tools import (
    apply_to_job_tool,
    create_job_tool,
    get_job_tool,
    list_inbox_tool,
    list_jobs_tool,
    reply_to_thread_tool,
    submit_job_tool,
)

__version__ = "0.1.0"

__all__ = [
    "OpenJobsToolkit",
    "OpenJobsPosterToolkit",
    "list_jobs_tool",
    "get_job_tool",
    "apply_to_job_tool",
    "submit_job_tool",
    "list_inbox_tool",
    "reply_to_thread_tool",
    "create_job_tool",
]
