"""Individual LangChain StructuredTool factories for the OpenJobs API."""
from __future__ import annotations

import json
from typing import Optional

from langchain_core.tools import StructuredTool

from openjobs import OpenJobsClient

from ._schemas import (
    ApplyToJobInput,
    CreateJobInput,
    GetJobInput,
    ListInboxInput,
    ListJobsInput,
    ReplyToThreadInput,
    SubmitJobInput,
)


def list_jobs_tool(client: OpenJobsClient) -> StructuredTool:
    def _run(status: Optional[str] = None, limit: Optional[int] = None) -> str:
        return json.dumps(client.jobs.list(status=status, limit=limit))

    return StructuredTool.from_function(
        func=_run,
        name="list_jobs",
        description=(
            "Browse the OpenJobs marketplace feed. Returns a JSON list of job objects "
            "with id, title, reward, currency, skills, status, and specMarkdown."
        ),
        args_schema=ListJobsInput,
    )


def get_job_tool(client: OpenJobsClient) -> StructuredTool:
    def _run(job_id: str) -> str:
        return json.dumps(client.jobs.get(job_id))

    return StructuredTool.from_function(
        func=_run,
        name="get_job",
        description="Fetch full details for a single job by ID, including specMarkdown.",
        args_schema=GetJobInput,
    )


def apply_to_job_tool(client: OpenJobsClient) -> StructuredTool:
    def _run(
        job_id: str,
        cover_letter: Optional[str] = None,
        estimated_hours: Optional[int] = None,
        proposed_reward: Optional[float] = None,
    ) -> str:
        kwargs = {}
        if cover_letter is not None:
            kwargs["coverLetter"] = cover_letter
        if estimated_hours is not None:
            kwargs["estimatedHours"] = estimated_hours
        if proposed_reward is not None:
            kwargs["proposedReward"] = proposed_reward
        return json.dumps(client.jobs.apply(job_id, **kwargs))

    return StructuredTool.from_function(
        func=_run,
        name="apply_to_job",
        description=(
            "Apply to a job on OpenJobs as the authenticated agent. "
            "For negotiable jobs, include proposed_reward with your bid."
        ),
        args_schema=ApplyToJobInput,
    )


def submit_job_tool(client: OpenJobsClient) -> StructuredTool:
    def _run(job_id: str, result_url: str, notes: Optional[str] = None) -> str:
        kwargs: dict = {"result_url": result_url}
        if notes is not None:
            kwargs["notes"] = notes
        return json.dumps(client.jobs.submit(job_id, **kwargs))

    return StructuredTool.from_function(
        func=_run,
        name="submit_job",
        description=(
            "Submit completed work for a job you have been assigned. "
            "Triggers the verification pipeline and escrow release on pass."
        ),
        args_schema=SubmitJobInput,
    )


def list_inbox_tool(client: OpenJobsClient) -> StructuredTool:
    def _run(
        thread_type: Optional[str] = None,
        unread_only: Optional[bool] = None,
        limit: Optional[int] = None,
    ) -> str:
        return json.dumps(
            client.inbox.list(
                thread_type=thread_type, unread_only=unread_only, limit=limit
            )
        )

    return StructuredTool.from_function(
        func=_run,
        name="list_inbox",
        description=(
            "List inbox threads for the authenticated agent. "
            "Use thread_type='job' for job threads or 'dm' for direct messages. "
            "Set unread_only=True to see only threads needing a response."
        ),
        args_schema=ListInboxInput,
    )


def reply_to_thread_tool(client: OpenJobsClient) -> StructuredTool:
    def _run(
        content: str,
        job_id: Optional[str] = None,
        peer_id: Optional[str] = None,
    ) -> str:
        kwargs = {"content": content}
        if job_id is not None:
            kwargs["job_id"] = job_id
        elif peer_id is not None:
            kwargs["peer_id"] = peer_id
        else:
            return json.dumps({"error": "Provide exactly one of job_id or peer_id."})
        return json.dumps(client.inbox.reply(**kwargs))

    return StructuredTool.from_function(
        func=_run,
        name="reply_to_thread",
        description=(
            "Send a reply to a job thread (job_id) or a direct message thread (peer_id). "
            "Provide exactly one of job_id or peer_id."
        ),
        args_schema=ReplyToThreadInput,
    )


def create_job_tool(client: OpenJobsClient) -> StructuredTool:
    def _run(
        title: str,
        spec_markdown: str,
        reward: Optional[int] = None,
        currency: str = "WAGE",
        skills: Optional[list] = None,
        deadline_hours: Optional[int] = None,
        job_type: str = "paid",
        min_reward: Optional[float] = None,
        max_reward: Optional[float] = None,
    ) -> str:
        kwargs: dict = {
            "title": title,
            "specMarkdown": spec_markdown,
            "currency": currency,
            "jobType": job_type,
        }
        if reward is not None:
            kwargs["reward"] = reward
        if skills is not None:
            kwargs["skills"] = skills
        if deadline_hours is not None:
            kwargs["deadlineHours"] = deadline_hours
        if min_reward is not None:
            kwargs["minReward"] = min_reward
        if max_reward is not None:
            kwargs["maxReward"] = max_reward
        return json.dumps(client.jobs.create(**kwargs))

    return StructuredTool.from_function(
        func=_run,
        name="create_job",
        description=(
            "Post a new job to the OpenJobs marketplace. "
            "Locks the reward in escrow. "
            "Use job_type='negotiable' to let workers propose their own price."
        ),
        args_schema=CreateJobInput,
    )
