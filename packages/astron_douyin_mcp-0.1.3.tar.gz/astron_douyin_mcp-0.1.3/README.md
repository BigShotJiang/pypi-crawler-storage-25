# 抖音公开内容 MCP Server

## 概述

`Astron-douyin-mcp` 是一个基于 MCP 协议的抖音工具服务，直接调用抖音游客态公开热榜接口并解析公开页面数据，不依赖额外的 Astron 后端服务。

当前工程形态：
- 使用 `MCP Python SDK`
- 使用单文件 `server.py` 承载工具定义、页面解析和 HTTP 调用
- 通过独立 `pyproject` 打包
- 支持 `uvx` 一键启动
- 通过环境变量配置超时和 User-Agent

当前仅保留 1 个稳定工具：
- `get_hot_list`

## 工具列表

### 获取热榜 `get_hot_list`
- 描述：读取抖音热榜。
- 参数：
  - `limit`：返回条数，默认 `20`
  - `refresh`：是否刷新，默认 `False`

## 稳定性策略

抖音游客态风控在搜索、详情、作者链路上不稳定。当前版本仅对外暴露已验证稳定的热榜能力，
其余高风险工具已从 MCP 注册中移除，避免在生产调用中触发不可控失败。

## 环境变量

这个包默认不需要认证信息。

可选环境变量：

```bash
export DOUYIN_MCP_TIMEOUT_SECONDS="20"
export DOUYIN_MCP_USER_AGENT="Mozilla/5.0 ..."
```

说明：
- `DOUYIN_MCP_TIMEOUT_SECONDS` 控制接口和页面请求超时。
- `DOUYIN_MCP_USER_AGENT` 用于覆盖默认桌面请求头。

## 安装与启动

### 推荐方式：使用 uvx 一键启动

```bash
uvx --from astron-douyin-mcp astron-douyin-mcp
```

如果你还没有安装 `uv` / `uvx`，可先执行：

```bash
curl -fsSL https://install.astral.sh/uv | bash
```

### 使用 pip 安装

```bash
pip install astron-douyin-mcp
douyin-mcp
```

### 本地源码运行

```bash
cd MCP/douyin-mcp
PYTHONPATH=src python3 -m douyin_mcp.server
```

## 客户端配置

### 使用 uvx

```json
{
  "mcpServers": {
    "douyin-mcp": {
      "command": "uvx",
      "args": ["--from", "astron-douyin-mcp", "astron-douyin-mcp"],
      "env": {
        "DOUYIN_MCP_TIMEOUT_SECONDS": "20"
      }
    }
  }
}
```

### 使用本地源码

```json
{
  "mcpServers": {
    "douyin-mcp": {
      "command": "python3",
      "args": ["-m", "douyin_mcp.server"],
      "env": {
        "PYTHONPATH": "/path/to/MCP/douyin-mcp/src",
        "DOUYIN_MCP_TIMEOUT_SECONDS": "20"
      }
    }
  }
}
```

## 平台差异说明

1. 这个 MCP 直接请求抖音公开接口和公开页面，不依赖额外的 Astron 后端服务。
2. 当前仅面向公开内容能力，不包含登录态、私有内容或用户专属数据。
3. 当前版本聚焦稳定优先，仅保留热榜能力。
4. 为保证可安装即用，当前实现不引入 Playwright 等浏览器依赖。

## 发布说明

```bash
cd MCP/douyin-mcp
rm -rf build dist src/*.egg-info
python3 -m build --no-isolation
python3 -m twine check dist/*
python3 -m twine upload dist/*
```
