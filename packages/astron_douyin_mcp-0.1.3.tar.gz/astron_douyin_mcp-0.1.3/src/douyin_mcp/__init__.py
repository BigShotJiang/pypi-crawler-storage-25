"""Astron Douyin MCP package."""

__version__ = "0.1.3"
