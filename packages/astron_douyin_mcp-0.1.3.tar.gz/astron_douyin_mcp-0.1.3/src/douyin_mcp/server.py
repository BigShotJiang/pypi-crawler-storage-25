"""Astron Douyin MCP server."""

from __future__ import annotations

import html as html_lib
import json
import os
import re
from datetime import datetime, timezone
from html.parser import HTMLParser
from typing import Any, Iterator
from urllib.parse import parse_qs, quote, urlparse

import requests
from mcp.server.fastmcp import FastMCP

from douyin_mcp import __version__


BASE_URL = "https://www.douyin.com"
HOME_URL = f"{BASE_URL}/"
HOT_URL = f"{BASE_URL}/hot"
HOT_LIST_API_URL = (
    f"{BASE_URL}/aweme/v1/web/hot/search/list/"
    "?channel=channel_pc_web&detail_list=1&source=6"
)
HOTSPOT_API_URL = f"{BASE_URL}/aweme/v1/web/channel/hotspot"
SEARCH_URL_TEMPLATE = f"{BASE_URL}/search/{{query}}"
VIDEO_URL_TEMPLATE = f"{BASE_URL}/video/{{content_id}}"
AUTHOR_URL_TEMPLATE = f"{BASE_URL}/user/{{author_id}}"

DEFAULT_LIMIT = 20
MAX_LIMIT = 50
COUNT_RE = re.compile(r"[\d,.]+")
ID_RE = re.compile(r"/(?:video|note|user)/([^/?#]+)")

STATE_MARKERS = (
    "window.__INITIAL_STATE__",
    "window.__UNIVERSAL_DATA_FOR_REHYDRATION__",
    "window._ROUTE_DATA_",
    "window.__SOCIAL_DOUYIN__",
    "window.RENDER_DATA",
)

mcp = FastMCP("DOUYIN_MCP")


class _DouyinHTMLCollector(HTMLParser):
    """Collect inline scripts from Douyin pages."""

    def __init__(self) -> None:
        super().__init__()
        self.scripts: list[str] = []
        self._in_script = False
        self._parts: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        del attrs
        if tag == "script":
            self._in_script = True
            self._parts = []

    def handle_data(self, data: str) -> None:
        if self._in_script:
            self._parts.append(data)

    def handle_endtag(self, tag: str) -> None:
        if tag == "script" and self._in_script:
            self.scripts.append("".join(self._parts).strip())
            self._in_script = False
            self._parts = []


def _current_iso() -> str:
    return datetime.now(tz=timezone.utc).astimezone().isoformat()


def get_timeout_seconds() -> float:
    raw = os.getenv("DOUYIN_MCP_TIMEOUT_SECONDS", "20").strip()
    try:
        value = float(raw)
    except ValueError as exc:
        raise RuntimeError("DOUYIN_MCP_TIMEOUT_SECONDS 必须是数字") from exc
    if value <= 0:
        raise RuntimeError("DOUYIN_MCP_TIMEOUT_SECONDS 必须大于 0")
    return value


def get_user_agent() -> str:
    value = os.getenv("DOUYIN_MCP_USER_AGENT", "").strip()
    if value:
        return value
    return (
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36 "
        f"Astron-Douyin-MCP/{__version__}"
    )


def create_session(*, prime_home: bool = True) -> requests.Session:
    session = requests.Session()
    session.headers.update(
        {
            "User-Agent": get_user_agent(),
            "Accept-Language": "zh-CN,zh;q=0.9",
        }
    )
    if prime_home:
        _prime_home(session)
    return session


def _prime_home(session: requests.Session) -> None:
    for url in (HOME_URL, HOT_URL):
        try:
            session.get(url, timeout=get_timeout_seconds())
        except requests.RequestException:
            pass


def _request_json(
    session: requests.Session,
    url: str,
    *,
    params: dict[str, Any] | None = None,
    referer: str = HOME_URL,
) -> dict[str, Any]:
    for attempt in range(2):
        try:
            response = session.get(
                url,
                params=params,
                headers={
                    "Referer": referer,
                    "Accept": "application/json, text/plain, */*",
                    "X-Requested-With": "XMLHttpRequest",
                },
                timeout=get_timeout_seconds(),
            )
        except requests.RequestException as exc:
            raise RuntimeError(f"请求失败: {url}; error={exc}") from exc

        if response.status_code in {403, 418, 429} and attempt == 0:
            _prime_home(session)
            continue
        if response.status_code != 200:
            raise RuntimeError(
                f"调用失败: HTTP {response.status_code}; url={response.url}; body={response.text[:300]}"
            )
        text = response.text.strip()
        if not text:
            if attempt == 0:
                _prime_home(session)
                continue
            raise RuntimeError(f"调用失败: 响应为空; url={response.url}")

        try:
            payload = response.json()
        except ValueError as exc:
            raise RuntimeError(f"调用失败: 响应不是合法 JSON; url={response.url}") from exc

        if not isinstance(payload, dict):
            raise RuntimeError(f"调用失败: 响应不是对象; url={response.url}")
        return payload

    raise RuntimeError(f"调用失败: 访问 {url} 时触发风控，请稍后重试")


def _request_html(
    session: requests.Session,
    url: str,
    *,
    params: dict[str, Any] | None = None,
    referer: str = HOME_URL,
) -> str:
    for attempt in range(2):
        try:
            response = session.get(
                url,
                params=params,
                headers={
                    "Referer": referer,
                    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                },
                timeout=get_timeout_seconds(),
            )
        except requests.RequestException as exc:
            raise RuntimeError(f"请求失败: {url}; error={exc}") from exc

        if response.status_code in {403, 418, 429} and attempt == 0:
            _prime_home(session)
            continue
        if response.status_code != 200:
            raise RuntimeError(
                f"调用失败: HTTP {response.status_code}; url={response.url}; body={response.text[:300]}"
            )
        if not response.text.strip() and attempt == 0:
            _prime_home(session)
            continue
        return response.text

    raise RuntimeError(f"调用失败: 访问 {url} 时触发风控，请稍后重试")


def clean_text(value: Any) -> str:
    text = html_lib.unescape(str(value or ""))
    return " ".join(text.split())


def _normalize_limit(limit: int, *, maximum: int = MAX_LIMIT) -> int:
    value = _to_int(limit)
    if value is None:
        return DEFAULT_LIMIT
    return max(1, min(value, maximum))


def _to_int(value: Any) -> int | None:
    if value in (None, "", [], {}):
        return None
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value)
    text = clean_text(value).replace(",", "")
    if not text:
        return None
    try:
        return int(text)
    except ValueError:
        match = COUNT_RE.search(text)
        if not match:
            return None
        try:
            return int(float(match.group(0).replace(",", "")))
        except ValueError:
            return None


def _build_video_url(content_id: str) -> str:
    text = clean_text(content_id)
    if not text:
        return ""
    if text.startswith(("http://", "https://")):
        return text
    return VIDEO_URL_TEMPLATE.format(content_id=text)


def _build_author_url(author_id: str) -> str:
    text = clean_text(author_id)
    if not text:
        return ""
    if text.startswith(("http://", "https://")):
        return text
    return AUTHOR_URL_TEMPLATE.format(author_id=text)


def _build_search_url(query: str) -> str:
    text = clean_text(query)
    if not text:
        return ""
    return SEARCH_URL_TEMPLATE.format(query=quote(text))


def _extract_identifier(value: str) -> str:
    text = clean_text(value)
    if not text:
        return ""
    if text.isdigit():
        return text
    match = ID_RE.search(text)
    if match:
        return clean_text(match.group(1))
    parsed = urlparse(text if text.startswith(("http://", "https://")) else f"https://x/{text}")
    query = parse_qs(parsed.query)
    for key in ("aweme_id", "group_id", "id", "modal_id", "sec_uid", "uid"):
        candidate = clean_text(query.get(key, [""])[0])
        if candidate:
            return candidate
    fallback = clean_text(parsed.path.rstrip("/").rsplit("/", 1)[-1])
    return fallback


def _unix_to_iso(value: Any) -> str:
    number = _to_int(value)
    if number is None:
        return ""
    if number > 10**12:
        number //= 1000
    try:
        return datetime.fromtimestamp(number, tz=timezone.utc).astimezone().isoformat()
    except (OverflowError, OSError, ValueError):
        return ""


def _pick_cover(entry: dict[str, Any]) -> str:
    for key in ("cover", "origin_cover", "dynamic_cover", "video_cover"):
        value = entry.get(key)
        if isinstance(value, dict):
            urls = value.get("url_list") or value.get("urlList") or []
            if isinstance(urls, list) and urls:
                return str(urls[0])
            url = value.get("url")
            if url:
                return str(url)
        if isinstance(value, str) and value:
            return value
    video = entry.get("video")
    if isinstance(video, dict):
        cover = video.get("cover")
        if isinstance(cover, dict):
            urls = cover.get("url_list") or []
            if urls:
                return str(urls[0])
    return ""


def _pick_avatar(entry: dict[str, Any]) -> str:
    for key in ("avatar_168x168", "avatar", "avatar_larger", "avatar_thumb"):
        value = entry.get(key)
        if isinstance(value, dict):
            urls = value.get("url_list") or value.get("urlList") or []
            if isinstance(urls, list) and urls:
                return str(urls[0])
            url = value.get("url")
            if url:
                return str(url)
        if isinstance(value, str) and value:
            return value
    return ""


def _to_tags(*values: Any) -> list[str]:
    tags: list[str] = []
    for value in values:
        if isinstance(value, str) and clean_text(value):
            tags.append(clean_text(value))
        elif isinstance(value, list):
            for item in value:
                if isinstance(item, str) and clean_text(item):
                    tags.append(clean_text(item))
                elif isinstance(item, dict):
                    text = item.get("name") or item.get("title") or item.get("word")
                    if text:
                        tags.append(clean_text(text))
    return tags


def _coerce_dict(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _extract_json_assignment(text: str, marker: str) -> Any:
    pattern = re.compile(rf"{re.escape(marker)}\s*=\s*", re.DOTALL)
    match = pattern.search(text)
    if not match:
        return None
    index = match.end()
    while index < len(text) and text[index] not in "[{\"":
        index += 1
    if index >= len(text):
        return None

    decoder = json.JSONDecoder()
    try:
        payload, _ = decoder.raw_decode(html_lib.unescape(text[index:]))
        return payload
    except json.JSONDecodeError:
        return None


def extract_state(html: str) -> dict[str, Any]:
    collector = _DouyinHTMLCollector()
    collector.feed(html)

    for script in collector.scripts:
        if not script:
            continue
        for marker in STATE_MARKERS:
            payload = _extract_json_assignment(script, marker)
            if isinstance(payload, dict):
                return payload

    for marker in STATE_MARKERS:
        payload = _extract_json_assignment(html, marker)
        if isinstance(payload, dict):
            return payload

    return {}


def _iter_objects(value: Any) -> Iterator[Any]:
    yield value
    if isinstance(value, dict):
        for nested in value.values():
            yield from _iter_objects(nested)
    elif isinstance(value, list):
        for item in value:
            yield from _iter_objects(item)


def _find_first_scalar(data: Any, keys: tuple[str, ...]) -> Any:
    if isinstance(data, dict):
        for key in keys:
            if key in data and not isinstance(data[key], (dict, list)):
                return data[key]
        for value in data.values():
            found = _find_first_scalar(value, keys)
            if found is not None:
                return found
    elif isinstance(data, list):
        for item in data:
            found = _find_first_scalar(item, keys)
            if found is not None:
                return found
    return None


def _find_first_list_by_keys(data: Any, keys: tuple[str, ...]) -> list[dict[str, Any]]:
    if isinstance(data, dict):
        for key in keys:
            value = data.get(key)
            if isinstance(value, list):
                return [item for item in value if isinstance(item, dict)]
        for value in data.values():
            found = _find_first_list_by_keys(value, keys)
            if found:
                return found
    elif isinstance(data, list):
        for item in data:
            found = _find_first_list_by_keys(item, keys)
            if found:
                return found
    return []


def _find_hot_entries(payload: dict[str, Any]) -> list[dict[str, Any]]:
    data = _coerce_dict(payload.get("data"))
    entries = _find_first_list_by_keys(
        data or payload,
        ("word_list", "trending_list", "hot_list", "aweme_list", "list"),
    )
    return entries


def _find_aweme_list(payload: dict[str, Any]) -> list[dict[str, Any]]:
    return _find_first_list_by_keys(payload, ("aweme_list", "feed_list", "items", "list", "data"))


def _summarize_html_payload(payload: str) -> dict[str, Any]:
    lowered = payload.lower()
    challenge = any(
        marker in lowered
        for marker in (
            "验证码中间页",
            "captcha",
            "verify",
            "challenge",
            "sec-did",
            "security",
            "bot",
        )
    )
    script_count = lowered.count("<script")
    div_count = lowered.count("<div")
    a_count = lowered.count("<a ")
    img_count = lowered.count("<img")
    shell = (
        not challenge
        and script_count >= 5
        and div_count == 0
        and a_count == 0
        and img_count == 0
        and len(payload) >= 50000
    )
    page_kind = "captcha" if challenge else "shell" if shell else "rendered"
    return {
        "type": "html",
        "length": len(payload),
        "contains_script": script_count > 0,
        "script_count": script_count,
        "div_count": div_count,
        "a_count": a_count,
        "img_count": img_count,
        "challenge": challenge,
        "page_kind": page_kind,
    }


def _normalize_hot_item(entry: dict[str, Any], rank: int) -> dict[str, Any]:
    title = clean_text(
        entry.get("word")
        or entry.get("title")
        or entry.get("keyword")
        or entry.get("challenge_name")
        or ""
    )
    url = clean_text(entry.get("url") or entry.get("share_url") or entry.get("link") or "")
    if not url and title:
        url = _build_search_url(title)

    return {
        "id": str(entry.get("group_id") or entry.get("sentence_id") or entry.get("id") or title or rank),
        "title": title,
        "summary": clean_text(entry.get("sentence") or entry.get("desc") or ""),
        "content": clean_text(entry.get("sentence") or entry.get("desc") or title),
        "url": url,
        "cover": _pick_cover(entry),
        "author_name": "",
        "author_id": "",
        "publish_time": "",
        "rank": rank,
        "hot_value": _to_int(entry.get("hot_value") or entry.get("hotValue") or entry.get("heat")),
        "hot_text": clean_text(entry.get("hot_desc") or entry.get("label") or ""),
        "comment_count": None,
        "like_count": None,
        "share_count": None,
        "collect_count": None,
        "view_count": None,
        "source_type": "hot_topic",
        "result_type": "topic",
        "tags": _to_tags(entry.get("tag"), entry.get("tags")),
    }


def _normalize_aweme_item(entry: dict[str, Any], rank: int) -> dict[str, Any]:
    statistics = _coerce_dict(entry.get("statistics")) or _coerce_dict(entry.get("stats"))
    author = _coerce_dict(entry.get("author")) or _coerce_dict(entry.get("author_user_info"))
    item_id = str(entry.get("aweme_id") or entry.get("id") or entry.get("item_id") or rank)
    title = clean_text(entry.get("desc") or entry.get("title") or "")
    author_id = str(author.get("uid") or author.get("sec_uid") or author.get("id") or "")

    return {
        "id": item_id,
        "title": title,
        "summary": clean_text(entry.get("desc") or ""),
        "content": clean_text(entry.get("desc") or ""),
        "url": _build_video_url(item_id),
        "cover": _pick_cover(entry),
        "author_name": clean_text(author.get("nickname") or author.get("name") or ""),
        "author_id": author_id,
        "publish_time": _unix_to_iso(entry.get("create_time") or entry.get("publish_time")),
        "rank": rank,
        "hot_value": _to_int(statistics.get("play_count") or statistics.get("digg_count")),
        "hot_text": "",
        "comment_count": _to_int(statistics.get("comment_count")),
        "like_count": _to_int(statistics.get("digg_count")),
        "share_count": _to_int(statistics.get("share_count")),
        "collect_count": _to_int(statistics.get("collect_count")),
        "view_count": _to_int(statistics.get("play_count")),
        "source_type": "video",
        "result_type": "real",
        "tags": _to_tags(entry.get("tag"), entry.get("tags")),
    }


def _normalize_author_profile(entry: dict[str, Any], *, url: str, author_id: str) -> dict[str, Any]:
    return {
        "id": str(entry.get("uid") or entry.get("sec_uid") or entry.get("id") or author_id or url),
        "name": clean_text(entry.get("nickname") or entry.get("name") or ""),
        "url": url,
        "avatar": _pick_avatar(entry),
        "bio": clean_text(entry.get("signature") or entry.get("bio") or ""),
        "follower_count": _to_int(entry.get("follower_count")),
        "following_count": _to_int(entry.get("following_count")),
        "content_count": _to_int(entry.get("aweme_count") or entry.get("video_count")),
    }


def _build_paging(*, has_more: bool = False, next_cursor: str = "") -> dict[str, Any]:
    return {
        "has_more": bool(has_more),
        "next_cursor": next_cursor if has_more else "",
    }


def _build_list_result(
    capability: str,
    items: list[dict[str, Any]],
    raw: dict[str, Any],
    *,
    has_more: bool = False,
    next_cursor: str = "",
) -> dict[str, Any]:
    if capability == "search":
        items = [
            item
            for item in items
            if (clean_text(str(item.get("result_type", ""))) or "real") == "real"
            and bool(clean_text(str(item.get("content", ""))))
        ]
    item_types = [clean_text(str(item.get("result_type", ""))) or "real" for item in items]
    status = "empty" if not items else ("ok" if any(item_type == "real" for item_type in item_types) else "degraded")
    result_type = ""
    if item_types:
        if any(item_type == "real" for item_type in item_types):
            result_type = "real"
        else:
            result_type = item_types[0] if len(set(item_types)) == 1 else "mixed"
    result = {
        "platform": "douyin",
        "capability": capability,
        "status": status,
        "update_time": _current_iso(),
        "items": items,
        "paging": _build_paging(has_more=has_more, next_cursor=next_cursor),
    }
    if result_type:
        result["result_type"] = result_type
    return result


def _build_detail_result(item: dict[str, Any], raw: dict[str, Any]) -> dict[str, Any]:
    result_type = clean_text(str(item.get("result_type", ""))) or "real" if item else ""
    result = {
        "platform": "douyin",
        "status": "empty" if not item else ("degraded" if result_type != "real" else "ok"),
        "item": item,
    }
    if result_type:
        result["result_type"] = result_type
    return result


def _build_author_result(author: dict[str, Any], raw: dict[str, Any]) -> dict[str, Any]:
    result_type = clean_text(str(author.get("result_type", ""))) or "real" if author else ""
    result = {
        "platform": "douyin",
        "status": "empty" if not author else ("degraded" if result_type != "real" else "ok"),
        "author": author,
    }
    if result_type:
        result["result_type"] = result_type
    return result


def _build_degraded_list_result(
    capability: str,
    *,
    reason: str,
    message: str,
    request_url: str = "",
    page: dict[str, Any] | None = None,
    errors: list[str] | None = None,
    query: str = "",
    state_keys: list[str] | None = None,
) -> dict[str, Any]:
    return {
        "platform": "douyin",
        "capability": capability,
        "status": "empty",
        "update_time": _current_iso(),
        "items": [],
        "paging": _build_paging(has_more=False, next_cursor=""),
        "degraded": True,
        "reason": reason,
        "message": message,
    }


def _build_degraded_detail_result(
    *,
    content_id: str,
    url: str,
    reason: str,
    message: str,
    page: dict[str, Any] | None = None,
    error: str = "",
) -> dict[str, Any]:
    item = {
        "id": content_id,
        "title": "",
        "summary": "",
        "content": "",
        "url": url,
        "cover": "",
        "author_name": "",
        "author_id": "",
        "publish_time": "",
        "rank": 1,
        "hot_value": None,
        "hot_text": "",
        "comment_count": None,
        "like_count": None,
        "share_count": None,
        "collect_count": None,
        "view_count": None,
        "source_type": "video",
        "tags": [],
    }
    return {
        "platform": "douyin",
        "item": item,
        "degraded": True,
        "reason": reason,
        "message": message,
    }


def _build_degraded_author_result(
    *,
    author_id: str,
    url: str,
    reason: str,
    message: str,
    page: dict[str, Any] | None = None,
    error: str = "",
) -> dict[str, Any]:
    author = {
        "id": author_id,
        "name": "",
        "url": url,
        "avatar": "",
        "bio": "",
        "follower_count": None,
        "following_count": None,
        "content_count": None,
    }
    return {
        "platform": "douyin",
        "author": author,
        "degraded": True,
        "reason": reason,
        "message": message,
    }


def _parse_hot_list(payload: dict[str, Any], limit: int) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    entries = _find_hot_entries(payload)
    items = [_normalize_hot_item(entry, idx) for idx, entry in enumerate(entries[:limit], start=1)]
    paging = {
        "has_more": bool(_find_first_scalar(payload, ("has_more", "hasMore", "more"))),
        "next_cursor": str(_find_first_scalar(payload, ("max_cursor", "cursor", "next_cursor")) or ""),
    }
    return items, paging


def _parse_aweme_list(payload: dict[str, Any], limit: int) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    entries = _find_aweme_list(payload)
    items = [_normalize_aweme_item(entry, idx) for idx, entry in enumerate(entries[:limit], start=1)]
    paging = {
        "has_more": bool(_find_first_scalar(payload, ("has_more", "hasMore", "more"))),
        "next_cursor": str(_find_first_scalar(payload, ("max_cursor", "cursor", "next_cursor")) or ""),
    }
    return items, paging


def _find_aweme_entry(payload: dict[str, Any], *, target: str = "") -> dict[str, Any] | None:
    entries = _find_aweme_list(payload)
    if not entries:
        return None
    if not target:
        return entries[0]
    for entry in entries:
        values = (
            entry.get("aweme_id"),
            entry.get("group_id"),
            entry.get("id"),
            entry.get("item_id"),
        )
        if any(clean_text(v) == target for v in values if v not in (None, "")):
            return entry
        share_url = _coerce_dict(entry.get("share_info")).get("share_url")
        if share_url and target in str(share_url):
            return entry
    return None


def _find_author_from_state(state: dict[str, Any], *, target: str = "") -> dict[str, Any] | None:
    aweme_entries = _find_aweme_list(state)
    if target:
        for entry in aweme_entries:
            author = _coerce_dict(entry.get("author")) or _coerce_dict(entry.get("author_user_info"))
            if not author:
                continue
            values = (
                author.get("uid"),
                author.get("sec_uid"),
                author.get("unique_id"),
                author.get("short_id"),
                author.get("nickname"),
            )
            if any(clean_text(v) == target for v in values if v not in (None, "")):
                return author

    for obj in _iter_objects(state):
        if not isinstance(obj, dict):
            continue
        if any(k in obj for k in ("signature", "follower_count", "avatar_168x168", "uid", "sec_uid")):
            if obj.get("nickname") or obj.get("name"):
                return obj

    for entry in aweme_entries:
        author = _coerce_dict(entry.get("author")) or _coerce_dict(entry.get("author_user_info"))
        if author:
            return author
    return None


def _resolve_feed_url(channel: str) -> str:
    normalized = clean_text(channel).lower()
    if not normalized or normalized in {"feed", "discover", "explore", "hot", "hotspot", "trending"}:
        return HOT_URL
    if normalized.startswith(("http://", "https://")):
        return normalized
    return f"{BASE_URL}/{normalized.lstrip('/')}"


def _fetch_hot_list(limit: int) -> dict[str, Any]:
    session = create_session()
    payload = _request_json(session, HOT_LIST_API_URL, referer=HOT_URL)
    items, paging = _parse_hot_list(payload, limit)
    return _build_list_result(
        "hot_list",
        items,
        payload,
        has_more=bool(paging.get("has_more")),
        next_cursor=clean_text(paging.get("next_cursor")),
    )


def _fetch_feed_list(channel: str, cursor: str, limit: int) -> dict[str, Any]:
    session = create_session()
    params = {"channel_id": "99", "count": str(limit)}
    if clean_text(cursor):
        params["cursor"] = clean_text(cursor)

    errors: list[str] = []
    try:
        payload = _request_json(session, HOTSPOT_API_URL, params=params, referer=HOT_URL)
        items, paging = _parse_aweme_list(payload, limit)
        if items:
            return _build_list_result(
                "feed_list",
                items,
                payload,
                has_more=bool(paging.get("has_more")),
                next_cursor=clean_text(paging.get("next_cursor")),
            )
        errors.append("hotspot_json_empty")
    except RuntimeError as exc:
        errors.append(str(exc))

    feed_url = _resolve_feed_url(channel)
    try:
        html = _request_html(session, feed_url, referer=HOME_URL)
    except RuntimeError as exc:
        errors.append(str(exc))
        return _build_degraded_list_result(
            "feed_list",
            reason="request_failed",
            message="请求 feed 页面失败，已返回可判别降级结果",
            request_url=feed_url,
            errors=errors,
        )

    summary = _summarize_html_payload(html)
    state = extract_state(html)
    if state:
        items, paging = _parse_aweme_list(state, limit)
        if items:
            return _build_list_result(
                "feed_list",
                items,
                {
                    "request_url": feed_url,
                    "page": summary,
                    "state_keys": list(state.keys())[:30],
                    "fallback_errors": errors,
                },
                has_more=bool(paging.get("has_more")),
                next_cursor=clean_text(paging.get("next_cursor")),
            )

    return _build_degraded_list_result(
        "feed_list",
        reason=clean_text(summary.get("page_kind")) or "state_not_found",
        message="未解析到可用 feed 数据，已返回可判别降级结果",
        request_url=feed_url,
        page=summary,
        errors=errors,
        state_keys=list(state.keys())[:30] if state else [],
    )


def _fetch_search_content(query: str, limit: int) -> dict[str, Any]:
    normalized_query = clean_text(query)
    if not normalized_query:
        return _build_list_result(
            "search",
            [],
            {"query": "", "reason": "empty_query"},
            has_more=False,
            next_cursor="",
        )

    search_url = _build_search_url(normalized_query)
    session = create_session()
    try:
        html = _request_html(session, search_url, referer=HOME_URL)
    except RuntimeError as exc:
        return _build_degraded_list_result(
            "search",
            reason="request_failed",
            message="请求搜索页面失败，已返回可判别降级结果",
            request_url=search_url,
            errors=[str(exc)],
            query=normalized_query,
        )

    summary = _summarize_html_payload(html)

    if summary.get("page_kind") == "captcha":
        return _build_degraded_list_result(
            "search",
            reason="captcha",
            message="命中验证码页，已返回可判别降级结果",
            request_url=search_url,
            query=normalized_query,
            page=summary,
        )

    state = extract_state(html)
    items, paging = _parse_aweme_list(state, limit) if state else ([], {"has_more": False, "next_cursor": ""})

    if normalized_query:
        lowered = normalized_query.lower()
        filtered = [
            item
            for item in items
            if lowered in clean_text(item.get("title")).lower()
            or lowered in clean_text(item.get("summary")).lower()
        ]
        if filtered:
            items = filtered

    if not items:
        return _build_degraded_list_result(
            "search",
            reason=clean_text(summary.get("page_kind")) or "state_not_found",
            message="未匹配到搜索内容，已返回可判别降级结果",
            request_url=search_url,
            query=normalized_query,
            page=summary,
            state_keys=list(state.keys())[:30] if state else [],
        )

    return _build_list_result(
        "search",
        items[:limit],
        {
            "request_url": search_url,
            "query": normalized_query,
            "page": summary,
            "state_keys": list(state.keys())[:30] if state else [],
            "degraded": False,
            "reason": "",
        },
        has_more=bool(paging.get("has_more")),
        next_cursor=clean_text(paging.get("next_cursor")),
    )


def _fetch_content_detail(content_id: str, url: str) -> dict[str, Any]:
    target_id = clean_text(content_id) or _extract_identifier(url)
    target_url = clean_text(url) or _build_video_url(target_id)
    if not target_url:
        return _build_detail_result({}, {"reason": "empty_input"})

    session = create_session()
    try:
        html = _request_html(session, target_url, referer=HOME_URL)
    except RuntimeError as exc:
        return _build_degraded_detail_result(
            content_id=target_id,
            url=target_url,
            reason="request_failed",
            message="请求内容详情页失败，已返回可判别降级结果",
            error=str(exc),
        )

    summary = _summarize_html_payload(html)
    state = extract_state(html)
    if not state:
        return _build_degraded_detail_result(
            content_id=target_id,
            url=target_url,
            reason=clean_text(summary.get("page_kind")) or "state_not_found",
            message="未找到可解析内容详情，已返回可判别降级结果",
            page=summary,
        )

    entry = _find_aweme_entry(state, target=target_id)
    if entry is None:
        hot_entries = _find_hot_entries(state)
        if hot_entries:
            item = _normalize_hot_item(hot_entries[0], 1)
            item["url"] = target_url
            return _build_detail_result(
                item,
                {
                    "request_url": target_url,
                    "page": summary,
                    "state_keys": list(state.keys())[:30],
                },
            )
        return _build_degraded_detail_result(
            content_id=target_id,
            url=target_url,
            reason=clean_text(summary.get("page_kind")) or "detail_not_found",
            message="未在页面状态中匹配到内容，已返回可判别降级结果",
            page=summary,
        )

    item = _normalize_aweme_item(entry, 1)
    if target_url:
        item["url"] = target_url
    return _build_detail_result(
        item,
        {
            "request_url": target_url,
            "page": summary,
            "state_keys": list(state.keys())[:30],
        },
    )


def _fetch_author_profile(author_id: str, url: str) -> dict[str, Any]:
    target_id = clean_text(author_id) or _extract_identifier(url)
    target_url = clean_text(url) or _build_author_url(target_id)
    if not target_url:
        return _build_author_result({}, {"reason": "empty_input"})

    session = create_session()
    try:
        html = _request_html(session, target_url, referer=HOME_URL)
    except RuntimeError as exc:
        return _build_degraded_author_result(
            author_id=target_id,
            url=target_url,
            reason="request_failed",
            message="请求作者页面失败，已返回可判别降级结果",
            error=str(exc),
        )

    summary = _summarize_html_payload(html)
    state = extract_state(html)
    if not state:
        return _build_degraded_author_result(
            author_id=target_id,
            url=target_url,
            reason=clean_text(summary.get("page_kind")) or "state_not_found",
            message="未找到可解析作者信息，已返回可判别降级结果",
            page=summary,
        )

    author = _find_author_from_state(state, target=target_id)
    if author is None:
        return _build_degraded_author_result(
            author_id=target_id,
            url=target_url,
            reason=clean_text(summary.get("page_kind")) or "author_not_found",
            message="未在页面状态中匹配到作者，已返回可判别降级结果",
            page=summary,
        )

    normalized = _normalize_author_profile(author, url=target_url, author_id=target_id)
    return _build_author_result(
        normalized,
        {
            "request_url": target_url,
            "page": summary,
            "state_keys": list(state.keys())[:30],
        },
    )


def _fetch_author_content_list(author_id: str, url: str, limit: int) -> dict[str, Any]:
    target_id = clean_text(author_id) or _extract_identifier(url)
    target_url = clean_text(url) or _build_author_url(target_id)
    if not target_url:
        return _build_list_result("author_content_list", [], {"reason": "empty_input"}, has_more=False, next_cursor="")

    session = create_session()
    try:
        html = _request_html(session, target_url, referer=HOME_URL)
    except RuntimeError as exc:
        return _build_degraded_list_result(
            "author_content_list",
            reason="request_failed",
            message="请求作者作品页面失败，已返回可判别降级结果",
            request_url=target_url,
            errors=[str(exc)],
        )

    summary = _summarize_html_payload(html)
    state = extract_state(html)
    if not state:
        return _build_degraded_list_result(
            "author_content_list",
            reason=clean_text(summary.get("page_kind")) or "state_not_found",
            message="未找到可解析作者作品列表，已返回可判别降级结果",
            request_url=target_url,
            page=summary,
        )

    items, paging = _parse_aweme_list(state, limit)
    if target_id:
        items = [
            item
            for item in items
            if clean_text(item.get("author_id")) == target_id
            or clean_text(target_id) in clean_text(item.get("url"))
        ] or items

    if not items:
        return _build_degraded_list_result(
            "author_content_list",
            reason=clean_text(summary.get("page_kind")) or "author_content_not_found",
            message="未匹配到作者作品，已返回可判别降级结果",
            request_url=target_url,
            page=summary,
            state_keys=list(state.keys())[:30],
        )

    return _build_list_result(
        "author_content_list",
        items[:limit],
        {
            "request_url": target_url,
            "page": summary,
            "state_keys": list(state.keys())[:30],
            "author_id": target_id,
            "degraded": False,
        },
        has_more=bool(paging.get("has_more")),
        next_cursor=clean_text(paging.get("next_cursor")),
    )


@mcp.tool()
def get_hot_list(limit: int = 20, refresh: bool = False) -> dict[str, Any]:
    """获取抖音热榜。"""
    del refresh
    return _fetch_hot_list(_normalize_limit(limit))


def main() -> None:
    mcp.run()


if __name__ == "__main__":
    main()
