"""
Fahim Auto Commit v2.0.0 - Main CLI Entry Point
================================================
Universal Git Commit Automation CLI Tool
Powered By Programmer Fahim

Commands:
  setup   - Interactive repo setup (init, add, commit, push)
  push    - Smart diff-based commit & push (auto or manual message)
  auto    - Bulk auto-commit generator (legacy v1 feature, updated)
  auth    - GitHub / VS Code authentication check & setup
  help    - Show documentation & command reference
"""

import os
import sys
import random
import time
import argparse
from datetime import datetime

from . import __version__, __docs_url__
from .styles import (
    Colors, banner, success, error, warning, info,
    step, progress_bar, separator, prompt_input,
    prompt_confirm, cyan, bold, dim, green, red, yellow
)
from .git_ops import (
    GitError, git, is_git_repo, has_remote, has_any_changes,
    has_staged_changes, has_unstaged_changes, init_repo, add,
    commit, push, push_force, add_remote, set_branch_name,
    get_current_branch, get_diff, get_changed_files, get_staged_files,
    stage_file, unstage_all, get_diff_for_file, run, is_gh_installed
)
from .auth import check_gh_auth, guide_auth, require_auth
from .diff_analyzer import (
    generate_commit_message, generate_atomic_messages,
    get_change_summary, detect_replacements, parse_diff
)


# =============================================================================
# Command: setup
# =============================================================================

def cmd_setup(args):
    """
    Interactive setup command.
    Guides the user through: auth check → git init → add → commit → push.
    """
    banner("Fahim Auto Commit - Setup", "Initialize and push your project to GitHub")
    total_steps = 6

    # --- Step 1: Check GitHub Authentication ---
    print(f"  {cyan('Step 1: GitHub Authentication')}")
    separator()
    auth = check_gh_auth()
    if not auth["authenticated"]:
        warning("GitHub is not authenticated.")
        print()
        if not prompt_confirm("Do you want to set up GitHub authentication now?", default=True):
            error("GitHub authentication is required for setup. Aborting.")
            print()
            info("Run 'fahim-commit auth' to authenticate first.")
            return
        print()
        if not require_auth():
            error("Authentication failed. Aborting setup.")
            return
        print()
    else:
        success(f"GitHub authenticated as '{auth['username']}'")
    print()

    # --- Step 2: Git Init ---
    print(f"  {cyan('Step 2: Git Repository')}")
    separator()
    if is_git_repo():
        success("Git repository already exists.")
        branch = get_current_branch()
        info(f"Current branch: {branch}")
    else:
        info("Initializing new git repository...")
        try:
            init_repo()
            success("Git repository initialized.")
        except GitError as e:
            error(f"Failed to initialize git repository: {e}")
            return
    print()

    # --- Step 3: Stage Files ---
    print(f"  {cyan('Step 3: Stage Files')}")
    separator()
    try:
        add(".")
        files = get_staged_files()
        if not files and not has_any_changes():
            # Even if no changes, we proceed - the repo might already be committed
            info("No new files to stage (existing repo).")
        else:
            success(f"Staged {len(files)} file(s) for commit.")
            for f in files[:10]:
                print(f"    {dim('>')} {f}")
            if len(files) > 10:
                print(f"    {dim(f'... and {len(files) - 10} more')}")
    except GitError as e:
        error(f"Failed to stage files: {e}")
        return
    print()

    # --- Step 4: Commit ---
    print(f"  {cyan('Step 4: Commit')}")
    separator()
    default_msg = f"Initial commit - {datetime.now().strftime('%Y-%m-%d %H:%M')}"
    commit_msg = prompt_input("Enter commit message", default=default_msg)
    if not commit_msg:
        error("Commit message cannot be empty.")
        return
    try:
        # Check if there's anything to commit
        if has_staged_changes():
            commit(commit_msg)
            success(f"Committed: \"{commit_msg}\"")
        else:
            info("Nothing new to commit (all changes already committed).")
    except GitError as e:
        error(f"Failed to commit: {e}")
        return
    print()

    # --- Step 5: GitHub Repository URL ---
    print(f"  {cyan('Step 5: Connect to GitHub')}")
    separator()
    repo_url = prompt_input("Enter your GitHub repository URL (e.g., https://github.com/user/repo.git)")
    if not repo_url:
        error("Repository URL is required.")
        return
    print()
    try:
        add_remote("origin", repo_url)
        success(f"Remote 'origin' set to: {repo_url}")
    except GitError as e:
        error(f"Failed to set remote: {e}")
        return
    print()

    # --- Step 6: Push ---
    print(f"  {cyan('Step 6: Push to GitHub')}")
    separator()
    branch = get_current_branch() or "main"
    if branch != "main":
        info(f"Current branch is '{branch}'. Renaming to 'main'...")
        set_branch_name("main")
        branch = "main"
        success("Branch renamed to 'main'.")

    info(f"Pushing to {repo_url} (branch: {branch})...")
    print()
    try:
        push("origin", branch)
        success("Code pushed to GitHub successfully!")
    except GitError:
        # Try force push if regular push fails (for new repos)
        warning("Regular push failed. Trying force push (safe for new repos)...")
        try:
            push_force("origin", branch)
            success("Code force-pushed to GitHub successfully!")
        except GitError as e:
            error(f"Push failed: {e}")
            info("Make sure the repository exists on GitHub and you have push access.")
            return
    print()
    banner("Setup Complete!", "Your project is now on GitHub")
    success("Your code has been committed and pushed to GitHub.")
    info(f"Repository: {repo_url}")
    info(f"Branch: {branch}")
    print()
    info("From now on, just make changes and run:")
    print(f"         {bold('fahim-commit push')}")
    print()


# =============================================================================
# Command: push
# =============================================================================

def cmd_push(args):
    """
    Smart push command.
    Detects changes, generates (or uses provided) commit message, commits and pushes.
    """
    banner("Fahim Auto Commit - Push", "Smart commit & push based on code changes")

    # Check git repo
    if not is_git_repo():
        error("Not inside a git repository!")
        info("Run 'fahim-commit setup' to initialize a new project.")
        return

    # Stage all changes
    try:
        add(".")
    except GitError as e:
        error(f"Failed to stage files: {e}")
        return

    # Check if there are any changes
    diff_output = get_diff(staged=True)
    if not diff_output.strip() and not has_staged_changes():
        info("No changes detected. Everything is up to date.")
        return

    # Show change summary
    print(f"  {cyan('Detected Changes:')}")
    separator()
    summary = get_change_summary(diff_output)
    print(f"  {summary}")
    print()

    do_push = not args.no_push

    if args.atomic:
        # Atomic mode: separate commits per file
        _push_atomic(diff_output, args.message, do_push)
    else:
        # Normal mode: single commit
        _push_single(diff_output, args.message, do_push)


def _push_single(diff_output, custom_message=None, do_push=True):
    """Handle single-commit push."""
    # Generate or use custom commit message
    if custom_message:
        commit_msg = custom_message
        info(f"Using custom commit message: \"{commit_msg}\"")
    else:
        commit_msg = generate_commit_message(diff_output)
        info(f"Auto-generated commit message: \"{commit_msg}\"")
    print()

    # Commit
    try:
        commit(commit_msg)
        success(f"Committed: \"{commit_msg}\"")
    except GitError as e:
        error(f"Failed to commit: {e}")
        return

    # Push
    if do_push and has_remote():
        branch = get_current_branch()
        info(f"Pushing to remote ({branch})...")
        try:
            push("origin", branch)
            success("Pushed to GitHub successfully!")
        except GitError as e:
            warning(f"Push failed: {e}")
            info("Your changes are committed locally. Push manually with: git push")
    elif do_push and not has_remote():
        warning("No remote repository configured.")
        info("Your changes are committed locally.")
        info("Run 'fahim-commit setup' to connect to a GitHub repository.")
    else:
        info("Committed locally (push skipped by --no-push flag).")

    print()
    success("Done!")
    print()


def _push_atomic(diff_output, custom_message=None, do_push=True):
    """Handle atomic per-file push."""
    messages = generate_atomic_messages(diff_output)

    if not messages:
        info("No individual changes to commit.")
        return

    info(f"Creating {len(messages)} atomic commit(s)...")
    print()

    # First, unstage everything
    try:
        unstage_all()
    except GitError:
        pass

    success_count = 0
    for i, item in enumerate(messages):
        filepath = item["file"]
        msg = custom_message or item["message"]
        status = item["status"]

        # Stage only this file
        try:
            stage_file(filepath)
        except GitError:
            continue

        # Check if there's actually a diff for this file
        file_diff = get_diff_for_file(filepath, staged=True)
        if not file_diff.strip():
            continue

        # Use per-file auto message unless custom message was provided
        if custom_message:
            per_file_msg = f"{custom_message} [{os.path.basename(filepath)}]"
        else:
            per_file_msg = msg

        try:
            commit(per_file_msg)
            success(f"  [{i+1}/{len(messages)}] {per_file_msg}")
            success_count += 1
        except GitError as e:
            warning(f"  [{i+1}/{len(messages)}] Skipped {filepath}: {e}")

    if success_count > 0:
        print()
        success(f"Created {success_count} atomic commit(s).")

        # Push all at once
        if do_push and has_remote():
            branch = get_current_branch()
            info(f"Pushing {success_count} commit(s) to remote ({branch})...")
            try:
                push("origin", branch)
                success("All atomic commits pushed to GitHub!")
            except GitError as e:
                warning(f"Push failed: {e}")
                info("Commits are saved locally. Push manually with: git push")
        elif do_push and not has_remote():
            warning("No remote repository configured.")
            info("Commits are saved locally.")
    else:
        warning("No commits were created.")
    print()


# =============================================================================
# Command: auto (Updated v1 feature)
# =============================================================================

# Supported file extensions (same as v1)
SUPPORTED_EXTENSIONS = (
    ".py", ".pyw", ".r", ".rb", ".sh", ".bash", ".zsh", ".ps1",
    ".pl", ".lua", ".tcl",
    ".js", ".ts", ".jsx", ".tsx",
    ".html", ".htm", ".css", ".scss", ".sass", ".less",
    ".c", ".h", ".cpp", ".hpp", ".cc", ".cxx",
    ".cs", ".java", ".kt", ".kts", ".swift",
    ".go", ".rs", ".zig",
    ".hs", ".erl", ".ex", ".exs", ".clj",
    ".dart",
    ".sql",
    ".asm", ".s",
    ".yaml", ".yml", ".toml", ".ini", ".cfg",
    ".xml", ".xhtml", ".svg",
    ".php", ".scala", ".groovy", ".m", ".vb",
    ".vbs", ".tex", ".matlab"
)

COMMENT_STYLES = {
    "hash":      ("#", ""),
    "slash":     ("//", ""),
    "dash":      ("--", ""),
    "semicolon": (";", ""),
    "percent":   ("%", ""),
    "html":      ("<!--", "-->"),
    "css":       ("/*", "*/"),
}

EXTENSION_MAP = {
    ".py": "hash", ".rb": "hash", ".sh": "hash",
    ".bash": "hash", ".zsh": "hash", ".r": "hash",
    ".yaml": "hash", ".yml": "hash", ".toml": "hash",
    ".ini": "hash", ".cfg": "hash", ".pl": "hash",

    ".js": "slash", ".ts": "slash", ".jsx": "slash",
    ".tsx": "slash", ".java": "slash", ".c": "slash",
    ".cpp": "slash", ".cs": "slash", ".go": "slash",
    ".rs": "slash", ".kt": "slash", ".swift": "slash",
    ".scala": "slash", ".groovy": "slash", ".dart": "slash",
    ".zig": "slash", ".php": "slash",

    ".sql": "dash", ".lua": "dash", ".hs": "dash",

    ".asm": "semicolon", ".s": "semicolon",

    ".tex": "percent", ".matlab": "percent",

    ".html": "html", ".htm": "html",
    ".xml": "html", ".xhtml": "html",
    ".svg": "html",

    ".css": "css", ".scss": "css",
    ".sass": "css", ".less": "css"
}


def cmd_auto(args):
    """
    Auto commit command (updated v1 feature).
    Generates multiple commits by appending safe comment lines to tracked files.
    """
    repeat = args.count
    min_delay = args.min_delay
    max_delay = args.max_delay
    dry_run = args.dry_run
    message_template = args.message
    auto_push = args.push

    banner("Fahim Auto Commit - Bulk Generator", f"Creating {repeat} automated commit(s)")

    if not is_git_repo():
        error("Not inside a git repository!")
        info("Run 'fahim-commit setup' first to initialize a project.")
        return

    # Get tracked files
    tracked_output = git("ls-files")
    tracked_files = tracked_output.splitlines() if tracked_output else []

    valid_files = [
        f for f in tracked_files
        if f.lower().endswith(SUPPORTED_EXTENSIONS)
    ]

    if not valid_files:
        error("No supported tracked files found in this repository.")
        info(f"Supported extensions: {len(SUPPORTED_EXTENSIONS)} types")
        return

    info(f"Found {len(valid_files)} supported file(s) for auto-commit.")
    info(f"Delay: {min_delay}s - {max_delay}s | Push: {'Yes' if auto_push else 'No'} | Dry-run: {'Yes' if dry_run else 'No'}")
    print()

    try:
        print(f"  {cyan('Generating commits...')}")
        print()
        separator()

        for i in range(1, repeat + 1):
            # Pick a random file
            file_to_edit = random.choice(valid_files)
            ext = os.path.splitext(file_to_edit)[1].lower()
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

            style_key = EXTENSION_MAP.get(ext, "slash")
            start_symbol, end_symbol = COMMENT_STYLES[style_key]

            if end_symbol:
                comment_line = f"{start_symbol} auto-update at {timestamp} {end_symbol}"
            else:
                comment_line = f"{start_symbol} auto-update at {timestamp}"

            commit_message = message_template.format(
                time=timestamp,
                iteration=i,
                file=file_to_edit
            )

            if dry_run:
                print(f"  {yellow('[DRY RUN]')} Would modify: {file_to_edit}")
                print(f"  {yellow('[DRY RUN]')} Commit: \"{commit_message}\"")
            else:
                with open(file_to_edit, "a", encoding="utf-8", errors="ignore") as f:
                    f.write(f"\n{comment_line}\n")

                try:
                    add(".")
                    commit(commit_message)
                    if auto_push and has_remote():
                        branch = get_current_branch()
                        push("origin", branch)
                except GitError as e:
                    warning(f"Commit {i} failed: {e}")

            progress_bar(i, repeat)
            time.sleep(random.uniform(min_delay, max_delay))

        print()
        print()
        if dry_run:
            success(f"Dry run complete! Would create {repeat} commit(s).")
        else:
            success(f"All {repeat} commit(s) completed successfully!")
            if auto_push:
                info("All commits were pushed to remote.")

    except KeyboardInterrupt:
        print()
        print()
        warning("Interrupted safely (Ctrl+C).")
        info(f"Completed {i if 'i' in dir() else 0} of {repeat} commit(s).")

    print()


# =============================================================================
# Command: auth
# =============================================================================

def cmd_auth(args):
    """
    Authentication command.
    Checks GitHub/VS Code auth status and guides setup if needed.
    """
    banner("Fahim Auto Commit - Authentication", "GitHub / VS Code Authorization")

    if args.check:
        # Simple status check
        auth = check_gh_auth()
        if auth["authenticated"]:
            success(f"Authenticated as '{auth['username']}'")
            if auth["scopes"]:
                print(f"  {dim('Scopes:')} {', '.join(auth['scopes'])}")
        else:
            warning("Not authenticated.")
            print(f"  {dim(auth['message'])}")
            if auth.get("fix"):
                print(f"  {dim('Fix:')} {auth['fix']}")
        print()
        return

    # Full interactive auth
    guide_auth()


# =============================================================================
# Command: help
# =============================================================================

def cmd_help(args):
    """
    Help command with full documentation and command reference.
    """
    banner("Fahim Auto Commit v2.0.0", "Command Reference & Documentation")

    print(f"  {cyan('Official Documentation:')} {bold(__docs_url__)}")
    print()

    print(f"  {bold('DESCRIPTION')}")
    print(f"  Universal Git Commit Automation CLI Tool.")
    print(f"  Automates git init, add, commit, and push operations.")
    print(f"  Supports smart diff-based commit message generation.")
    print()

    print(f"  {bold('COMMANDS')}")
    print()
    _print_command("setup", "Interactive project setup (init, add, commit, push to GitHub)")
    _print_command("push", "Smart commit & push based on code changes")
    _print_command("auto", "Bulk auto-commit generator (automated commits)")
    _print_command("auth", "Check or set up GitHub / VS Code authentication")
    _print_command("help", "Show this help message and documentation link")
    print()

    print(f"  {bold('COMMAND DETAILS')}")
    print()

    _print_section("setup", [
        ("fahim-commit setup", "Full interactive setup"),
        ("", "  1. Checks GitHub authentication"),
        ("", "  2. Initializes git repository"),
        ("", "  3. Stages all files (git add .)"),
        ("", "  4. Prompts for commit message"),
        ("", "  5. Prompts for GitHub repo URL"),
        ("", "  6. Commits and pushes automatically"),
    ])

    _print_section("push", [
        ("fahim-commit push", "Auto-generate commit message from diff & push"),
        ("fahim-commit push -m \"message\"", "Use custom commit message"),
        ("fahim-commit push --atomic", "Separate commit per file change"),
        ("fahim-commit push --no-push", "Commit locally without pushing"),
    ])

    _print_section("auto", [
        ("fahim-commit auto --count 5", "Generate 5 auto commits"),
        ("fahim-commit auto --count 10 -m \"msg\"", "Custom commit template"),
        ("fahim-commit auto --count 5 --push", "Auto push after each commit"),
        ("fahim-commit auto --count 3 --dry-run", "Preview without committing"),
        ("fahim-commit auto --count 5 --delay 1 3", "Custom delay (1s-3s)"),
    ])

    _print_section("auth", [
        ("fahim-commit auth", "Interactive auth setup guide"),
        ("fahim-commit auth --check", "Quick auth status check"),
    ])

    _print_section("help", [
        ("fahim-commit help", "Show full documentation"),
    ])

    print()
    print(f"  {bold('FEATURES')}")
    print()
    features = [
        "GitHub OAuth / VS Code authorization check & setup",
        "One-command project setup (init + add + commit + push)",
        "Smart diff-based auto commit message generation",
        "Word-level replacement detection (e.g., rename variables)",
        "Atomic per-file commit mode (--atomic flag)",
        "Bulk auto-commit generation (50+ language support)",
        "Both automation and manual commit systems",
        "Dry-run simulation mode",
        "Custom commit message templates",
        "ASCII real-time progress bar",
        "Safe Ctrl+C interrupt handling",
        "Fully local execution (no external server required)",
        "Cross-platform compatible (Windows, macOS, Linux)",
    ]
    for feature in features:
        print(f"    {green('>>')} {feature}")
    print()

    print(f"  {bold('COMMIT MESSAGE TEMPLATE VARIABLES')}")
    print()
    print("    " + cyan("{time}") + "       - Timestamp (e.g., 2025-01-15 14:30:00)")
    print("    " + cyan("{iteration}") + "  - Current commit number")
    print("    " + cyan("{file}") + "      - File name being modified")
    print()

    print(f"  {bold('LINKS')}")
    print()
    print(f"    {cyan('Documentation:')}  {__docs_url__}")
    print(f"    {cyan('PyPI:')}           https://pypi.org/project/fahim-autocommit/")
    print(f"    {cyan('Report Issues:')}  https://github.com/fahim-autocommit/issues")
    print()

    separator()
    print(f"  {dim('Powered By Programmer Fahim')}")
    print()


def _print_command(name, description):
    """Print a formatted command entry."""
    print(f"    {bold(green(name)):<20} {dim(description)}")


def _print_section(title, entries):
    """Print a formatted command section."""
    print(f"    {bold(cyan(f'[{title.upper()}]'))}")
    for cmd, desc in entries:
        if cmd:
            print(f"      {green(cmd)}")
            print(f"        {dim(desc)}")
        else:
            print(f"        {dim(desc)}")
    print()


# =============================================================================
# Main Entry Point
# =============================================================================

def main():
    """Main CLI entry point."""

    parser = argparse.ArgumentParser(
        prog="fahim-commit",
        description="Fahim Auto Commit v2.0.0 - Universal Git Commit Automation CLI Tool",
        add_help=True,
    )
    parser.add_argument(
        "-v", "--version",
        action="version",
        version=f"%(prog)s v{__version__}"
    )

    subparsers = parser.add_subparsers(
        dest="command",
        title="Available Commands",
        metavar="<command>"
    )

    # ----- setup -----
    p_setup = subparsers.add_parser(
        "setup",
        help="Interactive project setup (init, add, commit, push to GitHub)",
    )

    # ----- push -----
    p_push = subparsers.add_parser(
        "push",
        help="Smart commit & push based on code changes",
    )
    p_push.add_argument(
        "-m", "--message",
        type=str, default=None,
        help="Custom commit message (skip auto-generation)"
    )
    p_push.add_argument(
        "--atomic",
        action="store_true",
        help="Create a separate commit for each file change"
    )
    p_push.add_argument(
        "--no-push",
        action="store_true",
        help="Commit locally without pushing to remote"
    )

    # ----- auto -----
    p_auto = subparsers.add_parser(
        "auto",
        help="Bulk auto-commit generator",
    )
    p_auto.add_argument(
        "--count", "-c",
        type=int, required=True,
        help="Number of commits to generate"
    )
    p_auto.add_argument(
        "--min-delay",
        type=float, default=2,
        help="Minimum delay between commits in seconds (default: 2)"
    )
    p_auto.add_argument(
        "--max-delay",
        type=float, default=4,
        help="Maximum delay between commits in seconds (default: 4)"
    )
    p_auto.add_argument(
        "--message", "-m",
        type=str, default="auto commit at {time}",
        help='Commit message template (use {time}, {iteration}, {file})'
    )
    p_auto.add_argument(
        "--push", "-p",
        action="store_true",
        help="Push to remote after each commit"
    )
    p_auto.add_argument(
        "--dry-run",
        action="store_true",
        help="Simulate without making actual commits"
    )

    # ----- auth -----
    p_auth = subparsers.add_parser(
        "auth",
        help="Check or set up GitHub / VS Code authentication",
    )
    p_auth.add_argument(
        "--check",
        action="store_true",
        help="Quick auth status check (non-interactive)"
    )

    # ----- help -----
    subparsers.add_parser(
        "help",
        help="Show documentation and command reference",
    )

    args = parser.parse_args()

    # Route to command handler
    if args.command == "setup":
        cmd_setup(args)
    elif args.command == "push":
        cmd_push(args)
    elif args.command == "auto":
        cmd_auto(args)
    elif args.command == "auth":
        cmd_auth(args)
    elif args.command == "help":
        cmd_help(args)
    else:
        # No command provided - show help
        parser.print_help()
        print()
        info(f"For full documentation visit: {__docs_url__}")
        print()


if __name__ == "__main__":
    main()
