"""
GitHub authentication module for Fahim Auto Commit.
Handles GitHub CLI (gh) authentication checks and VS Code authorization.
"""

import subprocess
import sys
import os

from .styles import (
    success, error, warning, info, cyan, bold, dim,
    green, red, yellow, banner, separator, prompt_confirm
)
from .git_ops import run, is_gh_installed


def check_gh_auth():
    """
    Check if the GitHub CLI is authenticated.

    Returns:
        dict with keys:
            - authenticated (bool)
            - username (str or None)
            - scopes (list)
            - message (str)
    """
    if not is_gh_installed():
        return {
            "authenticated": False,
            "username": None,
            "scopes": [],
            "message": "GitHub CLI (gh) is not installed.",
            "fix": "Install it from: https://cli.github.com/"
        }

    code, stdout, stderr = run(["gh", "auth", "status"], check=False)
    output = stdout + stderr

    if code != 0:
        return {
            "authenticated": False,
            "username": None,
            "scopes": [],
            "message": "GitHub CLI is installed but not authenticated.",
            "fix": "Run: gh auth login"
        }

    # Parse auth status output
    username = None
    scopes = []
    for line in output.splitlines():
        line = line.strip()
        if "Logged in to" in line:
            # Extract username from line like "Logged in to github.com as USERNAME"
            parts = line.split()
            for i, part in enumerate(parts):
                if part == "as" and i + 1 < len(parts):
                    username = parts[i + 1]
                    break
        if "Token scopes:" in line or "scopes:" in line:
            scope_str = line.split(":", 1)[-1].strip()
            scopes = [s.strip() for s in scope_str.split(",") if s.strip()]

    return {
        "authenticated": True,
        "username": username,
        "scopes": scopes,
        "message": f"Authenticated as {username}" if username else "Authenticated",
        "fix": None
    }


def check_vscode_github():
    """
    Check if VS Code's GitHub integration is likely configured.
    This checks for GitHub CLI auth (which VS Code uses).

    Returns:
        bool: True if GitHub integration should work.
    """
    auth = check_gh_auth()
    return auth["authenticated"]


def guide_auth():
    """
    Interactive guide to help the user set up GitHub authentication.
    """
    banner("GitHub Authentication Setup", "VS Code + GitHub CLI")

    # Step 1: Check if gh is installed
    if not is_gh_installed():
        error("GitHub CLI (gh) is not installed on your system.")
        print()
        info("GitHub CLI is required for authentication.")
        print()
        print(f"  {cyan('Install methods:')}")
        print(f"    {dim('• macOS:')}   brew install gh")
        print(f"    {dim('• Ubuntu:')}  sudo apt install gh")
        print(f"    {dim('• Windows:')} winget install GitHub.cli")
        print(f"    {dim('• Or download from:')} https://cli.github.com/")
        print()
        info("After installing, run 'fahim-commit auth' again.")
        return False

    # Step 2: Check current auth status
    auth = check_gh_auth()
    if auth["authenticated"]:
        success(f"You are already authenticated as {auth['username']}!")
        print()
        info("Your GitHub integration with VS Code should be working.")
        if auth["scopes"]:
            print(f"  {dim('Token scopes:')} {', '.join(auth['scopes'])}")
        print()
        print(f"  {cyan('If you want to re-authenticate:')}")
        print(f"    {dim('1.')} Run: gh auth logout")
        print(f"    {dim('2.')} Run: fahim-commit auth")
        return True

    # Step 3: Guide through login
    warning("GitHub CLI is not authenticated.")
    print()
    info("Follow these steps to authenticate:")
    print()
    print(f"  {cyan('Step 1:')} Run the following command in your terminal:")
    print(f"           {bold(green('gh auth login'))}")
    print()
    print(f"  {cyan('Step 2:')} Choose your preferred authentication method:")
    print(f"           {dim('• GitHub.com or GitHub Enterprise')}")
    print(f"           {dim('• HTTPS or SSH')}")
    print(f"           {dim('• Login with a web browser or paste a token')}")
    print()
    print(f"  {cyan('Step 3:')} For VS Code integration, use:")
    print(f"           {dim('• Login with web browser (recommended)')}")
    print(f"           {dim('• Or use a Personal Access Token (PAT)')}")
    print()
    print(f"  {cyan('Step 4:')} Grant the following scopes when prompted:")
    print(f"           {dim('• repo (full control of private repositories)')}")
    print(f"           {dim('• read:org (read organization membership)')}")
    print(f"           {dim('• workflow (update GitHub Actions workflows)')}")
    print()
    separator()

    # Ask if user wants to start the login now
    if prompt_confirm("Do you want to start GitHub login now?", default=True):
        print()
        info("Launching GitHub CLI login...")
        print()
        try:
            # Run gh auth login interactively
            subprocess.run(["gh", "auth", "login"])
            print()

            # Verify
            auth = check_gh_auth()
            if auth["authenticated"]:
                success(f"Authentication successful! Logged in as {auth['username']}")
                return True
            else:
                error("Authentication did not complete successfully.")
                info("Please try again or check your network connection.")
                return False
        except KeyboardInterrupt:
            print()
            warning("Authentication was cancelled.")
            return False
    else:
        print()
        info("No problem! You can authenticate later by running:")
        print(f"         {bold('gh auth login')}")
        print()
        info("Then verify with:")
        print(f"         {bold('fahim-commit auth')}")
        return False


def require_auth():
    """
    Ensure the user is authenticated. If not, guide them through setup.
    Returns True if authenticated, False otherwise.
    """
    auth = check_gh_auth()
    if auth["authenticated"]:
        return True

    warning("GitHub is not authenticated. Authentication is required for this operation.")
    print()
    result = guide_auth()
    return result
