"""
Fahim Auto Commit v2.0.0
========================
Universal Git Commit Automation CLI Tool
Powered By Programmer Fahim

Features:
  - GitHub OAuth / VS Code authorization check
  - One-command repo setup (init, add, commit, push)
  - Smart diff-based auto commit message generation
  - Atomic per-file commit mode
  - Bulk auto-commit (legacy v1 feature)
  - Both automation and manual systems
"""

__version__ = "2.0.0"
__author__ = "Programmer Fahim"
__license__ = "MIT"
__docs_url__ = "https://autocommit.fahim.website"
