"""
Git operations wrapper for Fahim Auto Commit.
Provides a clean interface to all git commands used by the CLI.
"""

import os
import subprocess
import sys

from .styles import error, info


class GitError(Exception):
    """Raised when a git operation fails."""
    pass


def run(cmd_args, check=True, capture=True, cwd=None):
    """
    Run a shell command and return its output.

    Args:
        cmd_args: List of command arguments.
        check: Whether to raise on non-zero exit code.
        capture: Whether to capture stdout/stderr.
        cwd: Working directory (defaults to current).

    Returns:
        Tuple of (return_code, stdout, stderr) if capture else (return_code, None, None).
    """
    try:
        result = subprocess.run(
            cmd_args,
            capture_output=capture,
            text=True,
            cwd=cwd or os.getcwd(),
        )
        if check and result.returncode != 0:
            raise subprocess.CalledProcessError(
                result.returncode, cmd_args, result.stdout, result.stderr
            )
        return result.returncode, result.stdout.strip(), result.stderr.strip()
    except FileNotFoundError:
        if check:
            error(f"Command not found: {cmd_args[0]}")
            raise GitError(f"Command not found: {cmd_args[0]}")
        return 1, "", f"Command not found: {cmd_args[0]}"


def git(*args, check=True):
    """
    Run a git command.

    Args:
        *args: Git subcommand and arguments.
        check: Raise GitError on failure.

    Returns:
        stdout string if check=False, or True on success.
    """
    cmd = ["git"] + list(args)
    code, stdout, stderr = run(cmd, check=False)
    if check and code != 0:
        error(f"git {' '.join(args)} failed: {stderr or stdout}")
        raise GitError(f"git {' '.join(args)} failed")
    return stdout


def is_git_repo():
    """Check if the current directory is inside a git repository."""
    code, _, _ = run(["git", "rev-parse", "--is-inside-work-tree"], check=False)
    return code == 0


def has_remote():
    """Check if the repo has at least one remote configured."""
    code, _, _ = run(["git", "remote"], check=False)
    return code == 0


def init_repo():
    """Initialize a new git repository in the current directory."""
    return git("init")


def add(path="."):
    """Stage files for commit."""
    return git("add", path)


def commit(message):
    """Create a commit with the given message."""
    return git("commit", "-m", message)


def push(remote="origin", branch="main"):
    """Push commits to a remote branch."""
    return git("push", "-u", remote, branch)


def push_force(remote="origin", branch="main"):
    """Force push to a remote branch."""
    return git("push", "-u", remote, branch, "--force")


def add_remote(name, url):
    """Add a git remote."""
    code, _, stderr = run(["git", "remote", "add", name, url], check=False)
    if code != 0:
        # Remote might already exist
        if "already exists" in stderr:
            info(f"Remote '{name}' already exists. Updating URL...")
            run(["git", "remote", "set-url", name, url], check=False)
        else:
            raise GitError(f"Failed to add remote: {stderr}")
    return True


def set_branch_name(name="main"):
    """Rename the current branch."""
    return git("branch", "-M", name)


def get_current_branch():
    """Get the name of the current branch."""
    return git("branch", "--show-current")


def get_diff(staged=False):
    """
    Get the git diff output.

    Args:
        staged: If True, get staged changes (--cached). Otherwise, unstaged.

    Returns:
        String of diff output.
    """
    if staged:
        return git("diff", "--cached")
    return git("diff")


def get_diff_for_file(filepath, staged=False):
    """Get diff output for a specific file."""
    if staged:
        return git("diff", "--cached", "--", filepath)
    return git("diff", "--", filepath)


def has_unstaged_changes():
    """Check if there are unstaged changes."""
    output = git("status", "--porcelain")
    if not output:
        return False
    # Check for lines with space in column 1 (unstaged changes)
    for line in output.splitlines():
        if len(line) >= 2 and line[1] != ' ' and line[1] != '?':
            return True
        if len(line) >= 1 and line[0] == '?':
            return True
    return bool(output.strip())


def has_staged_changes():
    """Check if there are staged changes."""
    code, output, _ = run(["git", "diff", "--cached", "--quiet"], check=False)
    return code != 0


def has_any_changes():
    """Check if there are any changes (staged or unstaged)."""
    output = git("status", "--porcelain")
    return bool(output.strip())


def get_changed_files():
    """
    Get a list of changed files with their status.

    Returns:
        List of tuples: (status, filepath)
        status: 'M' (modified), 'A' (added), 'D' (deleted), 'R' (renamed), '??' (untracked)
    """
    output = git("status", "--porcelain")
    files = []
    for line in output.splitlines():
        if len(line) < 4:
            continue
        status = line[:2].strip()
        filepath = line[3:]
        # Handle renamed files (R old -> new)
        if "->" in filepath:
            filepath = filepath.split("->")[-1].strip()
        files.append((status, filepath))
    return files


def get_untracked_files():
    """Get a list of untracked files."""
    files = get_changed_files()
    return [f for s, f in files if s == "??" or s == "A"]


def stage_file(filepath):
    """Stage a single file."""
    return git("add", "--", filepath)


def unstage_all():
    """Unstage all files."""
    return git("reset", "HEAD")


def get_staged_files():
    """Get list of currently staged files."""
    output = git("diff", "--cached", "--name-only")
    if not output:
        return []
    return output.splitlines()


def is_gh_installed():
    """Check if GitHub CLI (gh) is installed."""
    try:
        code, _, _ = run(["gh", "--version"], check=False)
        return code == 0
    except Exception:
        return False
