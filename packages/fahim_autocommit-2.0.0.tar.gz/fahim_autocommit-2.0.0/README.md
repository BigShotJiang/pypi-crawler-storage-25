<h1 align="center">Fahim Auto Commit</h1>

<p align="center">
  <strong>Universal Git Commit & Push Automation CLI</strong><br>
  Smart Diff-Based Commits &bull; One-Command Setup &bull; GitHub Auth &bull; v2.0.0
</p>

<p align="center">
  <a href="https://autocommit.fahim.website">
    <img src="https://img.shields.io/badge/Docs-autocommit.fahim.website-blue?style=for-the-badge&logo=data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxNiIgaGVpZ2h0PSIxNiIgdmlld0JveD0iMCAwIDI0IDI0IiBmaWxsPSJub25lIiBzdHJva2U9ImN1cnJlbnRDb2xvciIgc3Ryb2tlLXdpZHRoPSIyIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiPjxwYXRoIGQ9Ik0yIDNoOWE0IDQgMCAwIDEgNCA0djhhMiAyIDAgMCAxLTIgMkg0YTIgMiAwIDAgMS0yLTJWNXoiPjwvcGF0aD48cGF0aCBkPSJNOCAzaDlhNCA0IDAgMCAxIDQgNHY4YTIgMiAwIDAgMS0yIDJoLTlhMiAyIDAgMCAxLTItMlY1eiI+PC9wYXRoPjwvc3ZnPg==">
  </a>
  <a href="https://pypi.org/project/fahim-autocommit/">
    <img src="https://img.shields.io/pypi/v/fahim-autocommit?color=blue&label=PyPI+v2.0.0">
  </a>
  <img src="https://img.shields.io/pypi/pyversions/fahim-autocommit?color=brightgreen">
  <img src="https://img.shields.io/pypi/l/fahim-autocommit?color=orange">
  <img src="https://img.shields.io/pypi/dm/fahim-autocommit?color=purple&label=Downloads">
  <img src="https://img.shields.io/badge/CLI-Global-black">
  <img src="https://img.shields.io/badge/Supports-50%2B%20Languages-success">
</p>

---

## What's New in v2.0.0

Version 2.0.0 is a major rewrite with powerful new features:

| Feature | Description |
|---------|-------------|
| **One-Command Setup** | `fahim-commit setup` - Initialize repo, add files, commit, and push to GitHub in one go |
| **GitHub Auth Integration** | Automatic VS Code / GitHub CLI authentication check and guided setup |
| **Smart Push** | `fahim-commit push` - Auto-detects changes and generates meaningful commit messages |
| **Word Replacement Detection** | Detects text changes like renaming variables (e.g., `Fahim` -> `Hasib`) in commit messages |
| **Atomic Commits** | `--atomic` flag creates a separate commit for each file change |
| **Manual + Auto Modes** | Both manual (custom message) and automatic (AI-generated message) commit systems |
| **Updated Auto Command** | Legacy bulk auto-commit feature refined with new flags (`--push`, `--delay`) |
| **Help with Docs Link** | Built-in help command linking to full documentation |

---

## Official Documentation

**Full Documentation:** [autocommit.fahim.website](https://autocommit.fahim.website)

---

## Installation

```bash
pip install fahim-autocommit
```

> **Requirements:** Python 3.7+ and Git installed on your system. GitHub CLI (`gh`) recommended for authentication features.

---

## Quick Start

### 1. First-Time Setup (New Project)

If you have a project that's not yet connected to GitHub, run the setup command:

```bash
fahim-commit setup
```

This will guide you through:
1. **GitHub Authentication** - Checks if you're logged in; guides you if not
2. **Git Init** - Initializes a new git repository
3. **Stage Files** - Runs `git add .` automatically
4. **Commit** - Prompts you for a commit message
5. **Connect Remote** - Prompts for your GitHub repository URL
6. **Push** - Pushes everything to GitHub automatically

You don't need to type a single `git` command. It's fully automated.

### 2. Smart Push (Day-to-Day Usage)

After setup, just make changes to your code and run:

```bash
fahim-commit push
```

The tool will:
- Automatically detect what changed in your code
- Generate a meaningful commit message (e.g., `update: replace 'Fahim' with 'Hasib' in config.py`)
- Stage, commit, and push everything

**Custom commit message:**
```bash
fahim-commit push -m "fix: resolve login bug"
```

**Atomic commits** (one commit per file):
```bash
fahim-commit push --atomic
```

**Commit locally only** (no push):
```bash
fahim-commit push --no-push
```

### 3. Bulk Auto-Commit (Legacy Feature)

Generate multiple automated commits for repository activity:

```bash
fahim-commit auto --count 10
fahim-commit auto --count 5 --push
fahim-commit auto --count 3 --dry-run
```

---

## Command Reference

### `fahim-commit setup`

Interactive project setup. Connects your local project to GitHub in one command.

```bash
fahim-commit setup
```

| Step | Action |
|------|--------|
| 1 | Check GitHub authentication (prompts login if needed) |
| 2 | Initialize git repository (`git init`) |
| 3 | Stage all files (`git add .`) |
| 4 | Ask for commit message |
| 5 | Ask for GitHub repo URL |
| 6 | Commit and push automatically |

---

### `fahim-commit push`

Smart commit and push based on detected code changes.

```bash
fahim-commit push                   # Auto-generate commit message
fahim-commit push -m "message"      # Custom commit message
fahim-commit push --atomic           # Separate commit per file
fahim-commit push --no-push         # Commit only, don't push
```

| Flag | Description |
|------|-------------|
| `-m, --message` | Provide a custom commit message instead of auto-generation |
| `--atomic` | Create a separate commit for each changed file |
| `--no-push` | Commit locally without pushing to the remote |

**How auto-generated messages work:**

The tool analyzes your `git diff` to create meaningful messages:

| Change Type | Generated Message Example |
|-------------|--------------------------|
| New file added | `feat: add config.py` |
| File deleted | `remove: delete old_script.js` |
| Word replaced | `update: replace 'Fahim' with 'Hasib' in main.py` |
| Import changes | `refactor: update imports in utils.py` |
| Function modified | `update: modify login in auth.py` |
| Config file change | `config: modify settings.yaml (+3/-1)` |
| Multiple files | `update: modify 3 file(s) [main.py, app.py, utils.py] (+12/-3)` |

---

### `fahim-commit auto`

Bulk auto-commit generator. Creates multiple commits by appending safe comment lines to tracked source files.

```bash
fahim-commit auto --count 5                           # 5 auto commits
fahim-commit auto --count 10 --push                   # With auto-push
fahim-commit auto --count 3 --dry-run                 # Preview mode
fahim-commit auto --count 5 --min-delay 1 --max-delay 3  # Custom delay
fahim-commit auto --count 5 -m "update {file} #{iteration}"  # Custom template
```

| Flag | Default | Description |
|------|---------|-------------|
| `--count, -c` | (required) | Number of commits to generate |
| `--min-delay` | 2 | Minimum seconds between commits |
| `--max-delay` | 4 | Maximum seconds between commits |
| `--message, -m` | `auto commit at {time}` | Commit message template |
| `--push, -p` | false | Push to remote after each commit |
| `--dry-run` | false | Simulate without making actual commits |

**Template Variables:**

| Variable | Output Example |
|----------|---------------|
| `{time}` | `2025-01-15 14:30:00` |
| `{iteration}` | `3` |
| `{file}` | `src/main.py` |

---

### `fahim-commit auth`

Check or set up GitHub / VS Code authentication.

```bash
fahim-commit auth            # Interactive setup guide
fahim-commit auth --check    # Quick status check
```

This command checks if the GitHub CLI (`gh`) is authenticated, which is used by VS Code's GitHub integration. If not authenticated, it guides you through the login process step by step.

---

### `fahim-commit help`

Show full documentation and command reference.

```bash
fahim-commit help
```

Displays all available commands, usage examples, and links to the full documentation at [autocommit.fahim.website](https://autocommit.fahim.website).

---

## Supported Languages

The auto-commit feature supports **50+ programming and scripting languages**, including:

| Category | Languages |
|----------|-----------|
| **Web** | JavaScript, TypeScript, JSX, TSX, HTML, CSS, SCSS, SASS, LESS, PHP |
| **Systems** | C, C++, C#, Rust, Go, Zig, Assembly |
| **Scripting** | Python, Ruby, Bash, Zsh, PowerShell, Perl, Lua, Tcl |
| **Mobile** | Swift, Kotlin, Dart |
| **Functional** | Haskell, Erlang, Elixir, Clojure, Scala |
| **Data** | SQL, R, MATLAB |
| **Config** | YAML, TOML, INI, XML, JSON |
| **Other** | Java, Groovy, VBScript, TeX |

---

## How It Works

### Smart Diff Analysis

When you run `fahim-commit push`, the tool:

1. Runs `git add .` to stage all changes
2. Parses the `git diff` output to understand what changed
3. Categorizes changes by file type and content
4. Detects word-level replacements (e.g., variable renames)
5. Generates a descriptive commit message using conventional commit format
6. Creates the commit and pushes to the remote

### Atomic Commit Mode

With `--atomic`, each file's changes become a separate commit with its own auto-generated message. This is useful for creating a clean, granular commit history where each commit represents a single logical change.

### Word Replacement Detection

The diff analyzer can detect when text has been replaced (not just added or removed). For example, if you rename a variable from `Fahim` to `Hasib` throughout your codebase, the tool generates messages like:

```
update: replace 'Fahim' with 'Hasib' in main.py
update: replace 'Fahim' with 'Hasib' in config.py
```

---

## Migration from v1.x to v2.0.0

### Breaking Changes

- The `--count` argument is now only available in the `auto` subcommand
- All commands are now subcommands (use `fahim-commit <command>` instead of `fahim-commit --count 5`)

### Command Mapping

| v1.0.1 | v2.0.0 |
|---------|--------|
| `fahim-commit --count 5` | `fahim-commit auto --count 5` |
| `fahim-commit --count 5 --message "msg"` | `fahim-commit auto --count 5 -m "msg"` |
| `fahim-commit --count 5 --dry-run` | `fahim-commit auto --count 5 --dry-run` |
| *(new)* | `fahim-commit setup` |
| *(new)* | `fahim-commit push` |
| *(new)* | `fahim-commit push -m "msg"` |
| *(new)* | `fahim-commit push --atomic` |
| *(new)* | `fahim-commit auth` |

### New Features

- `fahim-commit setup` - One-command project setup
- `fahim-commit push` - Smart diff-based commit and push
- `fahim-commit push --atomic` - Per-file atomic commits
- `fahim-commit auto --push` - Auto-push flag for bulk commits
- `fahim-commit auth` - GitHub authentication management
- `fahim-commit help` - Built-in documentation

---

## Security & Safety

- **Fully local execution** - No code is sent to any external server
- **No API tokens required** - Uses your existing Git and GitHub CLI configuration
- **Safe commit comments** - Auto-generated comments are clearly marked and non-intrusive
- **Dry-run mode** - Preview commits before making them
- **Ctrl+C safety** - Gracefully handles interrupts at any point
- **MIT Licensed** - Open source and free to use

---

## Platform Compatibility

| Platform | Status |
|----------|--------|
| Windows | Supported |
| macOS | Supported |
| Linux | Supported |

Works with any terminal that supports ANSI colors. Colors are automatically disabled in non-terminal environments.

---

## Requirements

- **Python** 3.7 or higher
- **Git** installed and available in PATH
- **GitHub CLI (`gh`)** - Recommended for authentication features (install from [cli.github.com](https://cli.github.com/))

---

## Links

| Resource | Link |
|----------|------|
| **Documentation** | [autocommit.fahim.website](https://autocommit.fahim.website) |
| **PyPI Package** | [pypi.org/project/fahim-autocommit](https://pypi.org/project/fahim-autocommit/) |
| **GitHub Repository** | [github.com/programmerfahim/fahim-autocommit](https://github.com/programmerfahim/fahim-autocommit) |
| **Bug Reports** | [GitHub Issues](https://github.com/programmerfahim/fahim-autocommit/issues) |
| **GitHub CLI** | [cli.github.com](https://cli.github.com/) |

---

## License

This project is licensed under the MIT License. See the [LICENSE](LICENSE) file for details.

---

<p align="center">
  <strong>Powered By Programmer Fahim</strong>
</p>
