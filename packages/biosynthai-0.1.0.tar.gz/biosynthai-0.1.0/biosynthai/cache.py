"""
SQLite-based cache with TTL for BioSynthAI database clients.

Namespace + key → JSON value, expires after `ttl_hours`.
Thread-safe for single-process use (check_same_thread=False).
"""

from __future__ import annotations

import hashlib
import json
import sqlite3
from datetime import datetime, timedelta
from pathlib import Path


_DEFAULT_DB = Path("biosynth_cache.db")
_DEFAULT_TTL = 48  # hours


class Cache:
    def __init__(self, path: Path = _DEFAULT_DB, ttl_hours: int = _DEFAULT_TTL):
        self.ttl = timedelta(hours=ttl_hours)
        self.conn = sqlite3.connect(str(path), check_same_thread=False)
        self.conn.execute(
            "CREATE TABLE IF NOT EXISTS c(k TEXT PRIMARY KEY, v TEXT, t TEXT)"
        )
        self.conn.commit()

    # ── Internal ──────────────────────────────────────────────────────

    def _key(self, namespace: str, identifier: str) -> str:
        return hashlib.sha256(f"{namespace}:{identifier}".encode()).hexdigest()

    # ── Public API ────────────────────────────────────────────────────

    def get(self, namespace: str, identifier: str) -> dict | list | None:
        row = self.conn.execute(
            "SELECT v, t FROM c WHERE k=?", (self._key(namespace, identifier),)
        ).fetchone()
        if not row:
            return None
        if datetime.now() - datetime.fromisoformat(row[1]) > self.ttl:
            self.conn.execute(
                "DELETE FROM c WHERE k=?", (self._key(namespace, identifier),)
            )
            self.conn.commit()
            return None
        try:
            return json.loads(row[0])
        except Exception:
            return None

    def set(self, namespace: str, identifier: str, value: dict | list) -> None:
        self.conn.execute(
            "INSERT OR REPLACE INTO c VALUES(?, ?, ?)",
            (
                self._key(namespace, identifier),
                json.dumps(value, ensure_ascii=False),
                datetime.now().isoformat(),
            ),
        )
        self.conn.commit()

    def clear(self) -> None:
        self.conn.execute("DELETE FROM c")
        self.conn.commit()

    def stats(self) -> dict:
        count = self.conn.execute("SELECT COUNT(*) FROM c").fetchone()[0]
        return {"entries": count, "db": str(self.conn)}
