"""Allow ``python -m biosynthai``."""
from .main import main

main()
