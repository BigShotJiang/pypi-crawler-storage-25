"""
BioSynthesizer — main orchestration pipeline for BioSynthAI.

Coordinates all database clients and pydantic-ai agents.
Designed to be called from:
  - A CLI (main.py)
  - FastAPI (future integration, same as prisma-review-agent)
  - A Streamlit/Gradio UI

Usage:
    synth = BioSynthesizer(api_key="sk-or-v1-...", ncbi_api_key="...")
    result = await synth.run(BioSearchQuery(question="What does BDNF do in hippocampus?"))
"""

from __future__ import annotations

from pathlib import Path
from typing import Callable

from .agents import (
    AgentDeps,
    run_evidence_extraction,
    run_friendly_profile,
    run_search_plan,
    run_synthesis,
)
from .cache import Cache
from .clients import (
    AllenBrainClient,
    BioRxivClient,
    DANDIClient,
    GeneClient,
    MeSHClient,
    NeuroMorphoClient,
    OpenTargetsClient,
    STRINGClient,
    UniProtClient,
)
from .evidence import EvidenceExtractor
from .models import (
    BioArticle,
    BioSearchQuery,
    BioSearchPlan,
    BioSynthesisResult,
)


class BioSynthesizer:
    """
    Full neuroscience synthesis pipeline.

    Parameters
    ----------
    api_key : str
        OpenRouter API key.
    model_name : str
        OpenRouter model ID (default: anthropic/claude-sonnet-4).
    ncbi_api_key : str
        NCBI API key for higher rate limits (optional).
    cache_path : Path | None
        SQLite cache path. None → no caching.
    related_depth : int
        How many hops of PubMed related-article expansion.
    """

    def __init__(
        self,
        api_key: str,
        model_name: str = "anthropic/claude-sonnet-4",
        ncbi_api_key: str = "",
        cache_path: Path | None = Path("biosynth_cache.db"),
        related_depth: int = 1,
        enable_biorxiv: bool = True,
        enable_full_text: bool = True,
        enable_string: bool = True,
        enable_uniprot: bool = True,
        enable_dandi: bool = True,
        enable_allen: bool = True,
        enable_opentargets: bool = True,
        enable_neuromorpho: bool = True,
    ) -> None:
        self.api_key = api_key
        self.model_name = model_name
        self.related_depth = related_depth

        cache = Cache(cache_path) if cache_path else None

        self.gene_client = GeneClient(api_key=ncbi_api_key, cache=cache)
        self.mesh_client = MeSHClient(cache=cache)
        self.biorxiv_client = BioRxivClient(cache=cache) if enable_biorxiv else None
        self.string_client = STRINGClient(cache=cache) if enable_string else None
        self.uniprot_client = UniProtClient(cache=cache) if enable_uniprot else None
        self.dandi_client = DANDIClient(cache=cache) if enable_dandi else None
        self.allen_client = AllenBrainClient(cache=cache) if enable_allen else None
        self.ot_client = OpenTargetsClient(cache=cache) if enable_opentargets else None
        self.neuromorpho_client = NeuroMorphoClient(cache=cache) if enable_neuromorpho else None
        self._enable_full_text = enable_full_text

    # ── Public entry point ────────────────────────────────────────────

    async def run(
        self,
        query: BioSearchQuery,
        progress_callback: Callable[[str], None] | None = None,
        conversation_history: list[dict] | None = None,
    ) -> BioSynthesisResult:
        """
        Run the full synthesis pipeline.

        Parameters
        ----------
        query : BioSearchQuery
            User query and configuration.
        progress_callback : Callable[[str], None] | None
            Called with status messages during the run.
        conversation_history : list[dict] | None
            Prior [{role, content}] turns for multi-turn support.

        Returns
        -------
        BioSynthesisResult
            Fully populated synthesis result.
        """
        def log(msg: str) -> None:
            if progress_callback:
                progress_callback(msg)

        deps = AgentDeps(
            query=query,
            api_key=self.api_key,
            model_name=self.model_name,
            conversation_history=conversation_history or [],
        )

        seen: set[str] = set()
        articles: list[BioArticle] = []
        related_map: dict[str, list[str]] = {}
        gene_info: dict = {}
        cross_db: dict = {}
        interactions: list[dict] = []
        uniprot: dict = {}
        neuro_data: dict = {}
        dandi_datasets: list[dict] = []

        # ── Step 1: Search plan ───────────────────────────────────────
        log("Planning search strategy...")
        plan = await run_search_plan(deps)
        log(f"Intent: {plan.intent} | Genes: {plan.gene_symbols}")

        primary_gene = plan.gene_symbols[0] if plan.gene_symbols else None

        # ── Step 2: Dynamic MeSH resolution ──────────────────────────
        if plan.mesh_terms:
            log("Resolving MeSH terms...")
            for term in plan.mesh_terms[:5]:
                resolved = self.mesh_client.resolve(term)
                log(f"  MeSH: {term} → {resolved}")

        # ── Step 3: Gene info ─────────────────────────────────────────
        if primary_gene:
            log(f"Gene lookup: {primary_gene}...")
            gene_info = self.gene_client.search_gene(primary_gene)
            if gene_info.get("full_name"):
                log(f"Gene: {gene_info['symbol']} — {gene_info['full_name']}")

            if gene_info.get("gene_id"):
                cv = self.gene_client.get_clinvar_count(gene_info["gene_id"])
                if cv:
                    cross_db["clinvar_count"] = cv
                geo = self.gene_client.get_gene_expression_profiles(gene_info["gene_id"])
                if geo:
                    cross_db["geo_profile_count"] = geo

        # ── Step 4: UniProt ───────────────────────────────────────────
        if primary_gene and self.uniprot_client:
            log(f"UniProt: {primary_gene}...")
            uniprot = self.uniprot_client.get_protein(primary_gene)
            if uniprot.get("accession"):
                log(f"UniProt: {uniprot['accession']} ({uniprot.get('length', 0)} aa)")

        # ── Step 5: STRING ────────────────────────────────────────────
        if primary_gene and self.string_client:
            log(f"STRING: {primary_gene}...")
            interactions = self.string_client.get_interactions(primary_gene)
            if interactions:
                partners = list({i["b"] for i in interactions if i["b"] != primary_gene})[:9]
                log(f"STRING: {len(interactions)} interactions")
                enr = self.string_client.get_enrichment([primary_gene] + partners)
                if enr:
                    cross_db["enrichment"] = enr

        # ── Step 6: Allen Brain Atlas ─────────────────────────────────
        if primary_gene and self.allen_client:
            log(f"Allen Brain Atlas: {primary_gene}...")
            expr = self.allen_client.get_expression(primary_gene)
            if expr.get("regions"):
                neuro_data["brain_expression"] = expr
                log(f"Allen: {len(expr['regions'])} brain regions")

        # ── Step 7: DANDI Archive ─────────────────────────────────────
        if self.dandi_client:
            dandi_terms = (
                plan.dandi_search_terms
                or ([primary_gene] if primary_gene else [query.question.split()[0]])
            )
            for dt in dandi_terms[:2]:
                log(f"DANDI Archive: {dt}...")
                ds = self.dandi_client.search(dt, max_results=5)
                dandi_datasets.extend(ds)
            if dandi_datasets:
                log(f"DANDI: {len(dandi_datasets)} datasets")

        # ── Step 8: Open Targets ──────────────────────────────────────
        if primary_gene and self.ot_client:
            log(f"Open Targets: {primary_gene}...")
            drugs = self.ot_client.get_drugs(primary_gene)
            if drugs:
                neuro_data["opentargets_drugs"] = drugs
                log(f"OpenTargets: {len(drugs)} drug associations")
            diseases = self.ot_client.get_diseases(primary_gene)
            if diseases:
                neuro_data["opentargets_diseases"] = diseases

        # ── Step 9: NeuroMorpho ───────────────────────────────────────
        if primary_gene and self.neuromorpho_client:
            log(f"NeuroMorpho: {primary_gene}...")
            neurons = self.neuromorpho_client.search(cell_type=primary_gene)
            if neurons:
                neuro_data["neuromorpho"] = neurons
                log(f"NeuroMorpho: {len(neurons)} reconstructions")

        # ── Step 10: PubMed search ────────────────────────────────────
        for i, q in enumerate(plan.pubmed_queries):
            log(f"PubMed query {i + 1}/{len(plan.pubmed_queries)}...")
            pmids = self.gene_client.search_pubmed(q, query.max_results_per_query)
            new = [p for p in pmids if p not in seen]
            seen.update(new)
            if new:
                arts = self.gene_client.fetch_articles(new)
                for a in arts:
                    a.source = "pubmed_search"
                articles.extend(arts)
                log(f"Query {i + 1}: {len(arts)} articles")

        # ── Step 11: bioRxiv ──────────────────────────────────────────
        if self.biorxiv_client and (plan.search_biorxiv or plan.biorxiv_queries):
            biorxiv_qs = plan.biorxiv_queries or ([primary_gene] if primary_gene else [])
            for bq in biorxiv_qs[:2]:
                log(f"bioRxiv: {bq}...")
                barts = self.biorxiv_client.search(bq, 5)
                articles.extend(barts)
                if barts:
                    log(f"bioRxiv: {len(barts)} preprints")

        # ── Step 12: Related articles ─────────────────────────────────
        pubmed_articles = [a for a in articles if not a.pmid.startswith("biorxiv_")]
        if pubmed_articles:
            seeds = [a.pmid for a in pubmed_articles[:5]]
            for depth in range(1, self.related_depth + 1):
                log(f"Related articles (depth {depth})...")
                rel = self.gene_client.find_related(seeds, query.max_results_per_query)
                new = [p for p in rel if p not in seen]
                seen.update(new)
                if new:
                    rel_arts = self.gene_client.fetch_articles(new)
                    for a in rel_arts:
                        a.source = f"related_{depth}"
                    articles.extend(rel_arts)
                    for s in seeds:
                        related_map[s] = new[:5]
                    log(f"Depth {depth}: {len(rel_arts)} related articles")
                    seeds = [a.pmid for a in rel_arts[:3]]
                else:
                    break

        # ── Step 13: Cross-DB gene links ──────────────────────────────
        if pubmed_articles:
            linked = self.gene_client.get_gene_links([a.pmid for a in pubmed_articles[:5]])
            if linked:
                cross_db["linked_genes"] = linked

        # ── Step 14: Full text (PMC) ──────────────────────────────────
        if self._enable_full_text:
            pmc_arts = [a for a in articles if a.pmc_id][:3]
            if pmc_arts:
                log(f"Fetching PMC full text ({len(pmc_arts)})...")
                texts = self.gene_client.fetch_full_text([a.pmc_id for a in pmc_arts])
                for a in pmc_arts:
                    if a.pmc_id in texts:
                        a.full_text = texts[a.pmc_id]
                        a.source += "+ft"

        log(f"Total: {len(articles)} articles collected")

        if not articles:
            return BioSynthesisResult(
                query=query.question,
                plan=plan,
                synthesis_text="No articles found for this query.",
            )

        # ── Step 15: Heuristic evidence extraction ────────────────────
        log("Extracting evidence spans (heuristic)...")
        evidence = EvidenceExtractor.extract(
            articles, query.question, plan.gene_symbols
        )
        log(f"Heuristic evidence: {len(evidence)} spans")

        # ── Step 16: Mutation/trial supplementary search ──────────────
        mutation_articles: list[BioArticle] = []
        if primary_gene:
            log(f"Supplementary search: {primary_gene} mutations/trials...")
            try:
                mp = self.gene_client.search_pubmed(
                    f"{primary_gene} mutation inhibitor clinical trial", 5
                )
                new_m = [p for p in mp if p not in seen]
                if new_m:
                    mutation_articles = self.gene_client.fetch_articles(new_m[:5])
                    for a in mutation_articles:
                        a.source = "mutation_search"
                    articles.extend(mutation_articles)
                    seen.update(new_m)
            except Exception:
                pass

        # ── Step 17: Friendly profile ─────────────────────────────────
        friendly_profile = None
        if gene_info or uniprot:
            log("Generating friendly gene profile...")
            try:
                friendly_profile = await run_friendly_profile(
                    gene_info, uniprot, interactions, cross_db,
                    neuro_data, mutation_articles, deps,
                )
                log("Friendly profile done")
            except Exception:
                pass

        # ── Step 18: LLM evidence extraction (agent-based) ────────────
        log("Extracting evidence (agent)...")
        try:
            agent_evidence = await run_evidence_extraction(articles[:15], deps)
            # Merge: prefer agent spans, deduplicate
            combined = agent_evidence + evidence
            evidence = EvidenceExtractor.deduplicate(combined)[:25]
            log(f"Agent evidence: {len(agent_evidence)} spans (total: {len(evidence)})")
        except Exception:
            log("Agent evidence extraction failed; using heuristic spans")

        # ── Step 19: Format evidence for synthesis prompt ─────────────
        ev_text = "\n".join(
            f'  EV(PMID:{e.paper_pmid}, score:{e.relevance_score}, '
            f'sect:{e.section}): "{e.text[:250]}" [{e.claim}]'
            for e in evidence[:15]
        )

        # ── Step 20: Synthesis ────────────────────────────────────────
        log(f"Synthesizing {len(articles)} articles...")
        synthesis_text = await run_synthesis(
            articles=articles,
            evidence_text=ev_text,
            gene_info=gene_info,
            uniprot=uniprot,
            interactions=interactions,
            cross_db=cross_db,
            neuro_data=neuro_data,
            dandi_datasets=dandi_datasets,
            deps=deps,
        )

        log("Synthesis complete")

        return BioSynthesisResult(
            query=query.question,
            plan=plan,
            gene_info=gene_info,
            articles=articles,
            related_map=related_map,
            synthesis_text=synthesis_text,
            interactions=interactions,
            uniprot_data=uniprot,
            cross_db=cross_db,
            evidence=evidence,
            friendly=friendly_profile,
            neuro_data=neuro_data,
            dandi_datasets=dandi_datasets,
        )
