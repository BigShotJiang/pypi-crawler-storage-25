"""
Pydantic AI agents for BioSynthAI.

Three agents with typed structured output via OpenRouter:
  1. search_plan_agent     — BioSearchPlan
  2. synthesis_agent       — str (grounded narrative)
  3. friendly_profile_agent — FriendlyProfile

Each uses defer_model_check=True so the model is injected at runtime
(same pattern as prisma-review-agent), ready for FastAPI integration.
"""

from __future__ import annotations

import json
from dataclasses import dataclass

from pydantic_ai import Agent, RunContext
from pydantic_ai.models.openai import OpenAIChatModel
from pydantic_ai.providers.openrouter import OpenRouterProvider

from .models import (
    BatchEvidenceExtraction,
    FriendlyProfile,
    BioArticle,
    BioSearchPlan,
    BioSearchQuery,
)


# ────────────────────── Shared Dependencies ────────────────────────────

@dataclass
class AgentDeps:
    """Injected into all agents via RunContext."""
    query: BioSearchQuery
    api_key: str = ""
    model_name: str = "anthropic/claude-sonnet-4"
    conversation_history: list[dict] | None = None   # [{role, content}, ...]


def build_model(api_key: str, model_name: str = "anthropic/claude-sonnet-4") -> OpenAIChatModel:
    provider = OpenRouterProvider(api_key=api_key)
    return OpenAIChatModel(model_name, provider=provider)


# ────────────────────── 1. Search Plan Agent ───────────────────────────

search_plan_agent = Agent(
    output_type=BioSearchPlan,
    deps_type=AgentDeps,
    system_prompt="""\
You are a neuroscience & genomics search strategist.

Given a research question, produce a structured search plan that maximises
recall while staying focused on neuroscience.

Rules:
- 1-3 PubMed queries mixing MeSH terms, Boolean operators, field tags
- For gene/protein questions add Review[Publication Type] to one query
- Identify all gene symbols in the question (BDNF, NTRK2, MAPT, SNCA …)
- Identify the primary neurotransmitter system if relevant
  (glutamatergic, GABAergic, dopaminergic, serotonergic, cholinergic …)
- List brain_regions relevant to the question (hippocampus, PFC, amygdala …)
- Set search_biorxiv=true for cutting-edge / recent topics
- Set dandi_search_terms for electrophysiology or calcium imaging questions
- Set is_followup=true if the question is a follow-up to prior context
""",
    retries=2,
    name="search_planner",
    defer_model_check=True,
)


@search_plan_agent.system_prompt
async def _search_plan_context(ctx: RunContext[AgentDeps]) -> str:
    hist = ctx.deps.conversation_history or []
    if hist:
        last = hist[-2:] if len(hist) >= 2 else hist
        ctx_text = "\n".join(f"  [{t['role']}]: {t['content'][:300]}" for t in last)
        return f"\nPrevious conversation context:\n{ctx_text}"
    return ""


# ────────────────────── 2. Synthesis Agent ─────────────────────────────

synthesis_agent = Agent(
    output_type=str,
    deps_type=AgentDeps,
    system_prompt="""\
You are a senior neuroscience research synthesizer. Your synthesis is
comprehensive, evidence-grounded, and cites every claim.

EVIDENCE HIGHLIGHTING — every major claim must include:
> **Evidence** (PMID:XXX, section): "exact quoted text"
> — *Claim: brief label*

Required sections:

## Direct Answer
Brief, precise answer to the research question.

## Key Findings (with evidence quotes)
Thematic synthesis. For each theme:
- State the finding
- Quote supporting evidence (PMID:XXX)
- Note strength and contradictions

## Brain & Neural Context
Brain regions, circuits, neurotransmitter systems involved.
Include DANDI dataset references if relevant.

## Protein Biology
UniProt function, domains, subcellular location.
STRING interactions and pathway enrichment.

## Available Datasets
DANDI neurophysiology datasets and Allen Brain Atlas expression data.

## Cross-Database Insights
ClinVar variants, GEO profiles, linked genes, drug associations.

## Gaps & Future Directions
Unresolved questions, needed research, methodological gaps.

## References
[N] Authors (Year). Title. Journal. DOI: https://doi.org/XXX (PMID: XXX)

NEVER fabricate PMIDs, quotes, or statistics.
""",
    retries=1,
    name="synthesizer",
    defer_model_check=True,
)


@synthesis_agent.system_prompt
async def _synthesis_context(ctx: RunContext[AgentDeps]) -> str:
    q = ctx.deps.query
    return f"\nResearch question: {q.question}"


# ────────────────────── 3. Evidence Extraction Agent ───────────────────

evidence_extraction_agent = Agent(
    output_type=BatchEvidenceExtraction,
    deps_type=AgentDeps,
    system_prompt="""\
You are an evidence extraction specialist for neuroscience research.

Given a batch of articles and a research question, extract the most
relevant evidence spans from each article.

For each article, identify:
- Key claims and findings relevant to the question
- Quantitative results (effect sizes, p-values, sample sizes, CI)
- Mechanistic details (receptor binding, signaling pathways, circuits)
- Any contradictions or limitations from the authors

Rules:
- Quote or closely paraphrase — do NOT fabricate
- Score relevance 0-1 based on direct relevance to the question
- Set is_quantitative=true for numerical results
- Section: abstract | methods | results | discussion | full_text
- 2-5 spans per article, most relevant first
- Skip articles with no relevant evidence (empty evidence list)
""",
    retries=2,
    name="evidence_extractor",
    defer_model_check=True,
)


@evidence_extraction_agent.system_prompt
async def _evidence_context(ctx: RunContext[AgentDeps]) -> str:
    return f"\nResearch question: {ctx.deps.query.question}"


# ────────────────────── 4. Friendly Profile Agent ──────────────────────

friendly_profile_agent = Agent(
    output_type=FriendlyProfile,
    deps_type=AgentDeps,
    system_prompt="""\
Create a human-friendly neuroscience gene/protein profile.

Explain everything for a non-specialist using brain analogies and
plain language. Make the science accessible and engaging.

Guidelines:
- analogy: A vivid, memorable brain analogy (not "This gene is like a key")
- brain_function: What this gene specifically does in the brain
- neurotransmitter_system: Which system (glutamatergic, dopaminergic …)
- brain_regions: Where it is most important and why
- neural_circuits: Circuits it participates in
- behavioral_roles: Concrete behavioral effects (mood, memory, anxiety …)
- clinical_relevance: Diseases and therapeutic implications
- key_mutations: Known variants with clinical significance
- neuro_drugs: Approved or investigational drugs affecting this target
- how_to_use: Tips for researchers working with this target
""",
    retries=2,
    name="friendly_profiler",
    defer_model_check=True,
)


# ────────────────────── Agent Runner Helpers ───────────────────────────

async def run_search_plan(deps: AgentDeps) -> BioSearchPlan:
    """Generate a structured search plan for the query."""
    model = build_model(deps.api_key, deps.model_name)
    result = await search_plan_agent.run(
        deps.query.question,
        deps=deps,
        model=model,
    )
    return result.output


async def run_synthesis(
    articles: list[BioArticle],
    evidence_text: str,
    gene_info: dict,
    uniprot: dict,
    interactions: list[dict],
    cross_db: dict,
    neuro_data: dict,
    dandi_datasets: list[dict],
    deps: AgentDeps,
) -> str:
    """Generate grounded narrative synthesis."""
    article_blocks = [a.to_context_block(i + 1) for i, a in enumerate(articles[:20])]

    gene_ctx = json.dumps(gene_info, indent=1)[:1200] if gene_info else ""
    up_ctx = json.dumps(uniprot, indent=1)[:800] if uniprot else ""
    str_ctx = "\n".join(f"  {i['a']}↔{i['b']}({i['score']})" for i in interactions[:10])
    neuro_ctx = json.dumps(neuro_data, indent=1)[:1500] if neuro_data else ""
    dandi_ctx = json.dumps(dandi_datasets[:5], indent=1)[:800] if dandi_datasets else ""
    xdb_ctx = json.dumps(cross_db, indent=1)[:600] if cross_db else ""

    user_prompt = (
        f"Question: {deps.query.question}\n\n"
        f"=== ARTICLES ({len(articles)}) ===\n"
        + "\n\n".join(article_blocks)
        + f"\n\n== Gene Info ==\n{gene_ctx}"
        + f"\n\n== UniProt ==\n{up_ctx}"
        + f"\n\n== STRING Interactions ==\n{str_ctx}"
        + f"\n\n== Cross-DB ==\n{xdb_ctx}"
        + f"\n\n== Neuro Data (Allen, OpenTargets) ==\n{neuro_ctx}"
        + f"\n\n== DANDI Datasets ==\n{dandi_ctx}"
        + f"\n\n== Evidence Spans ==\n{evidence_text}"
    )

    model = build_model(deps.api_key, deps.model_name)
    result = await synthesis_agent.run(user_prompt, deps=deps, model=model)
    return result.output


async def run_evidence_extraction(
    articles: list[BioArticle],
    deps: AgentDeps,
    batch_size: int = 5,
) -> list:
    """Extract evidence spans from articles using the agent (batched)."""
    from .evidence import EvidenceExtractor  # avoid circular import

    all_spans = []
    model = build_model(deps.api_key, deps.model_name)

    for start in range(0, len(articles), batch_size):
        batch = articles[start : start + batch_size]
        articles_text = "\n\n".join(
            f"=== Article {i} (PMID:{a.pmid}) ===\n"
            f"Title: {a.title}\n"
            f"Authors: {a.authors} ({a.year})\n"
            f"Abstract: {(a.abstract or 'N/A')[:1000]}\n"
            f"Full text excerpt: {(a.full_text or 'N/A')[:2000]}"
            for i, a in enumerate(batch)
        )
        try:
            result = await evidence_extraction_agent.run(
                f"Extract evidence from these {len(batch)} articles:\n\n{articles_text}",
                deps=deps,
                model=model,
            )
            extraction = result.output
            from .models import EvidenceSpan, EvidenceDirection
            for art_ev in extraction.articles:
                art = next((a for a in batch if a.pmid == art_ev.pmid), None)
                for ev in art_ev.evidence:
                    all_spans.append(
                        EvidenceSpan(
                            text=ev.quote,
                            paper_pmid=art_ev.pmid,
                            paper_title=art.title if art else "",
                            section=ev.section,
                            relevance_score=ev.relevance,
                            claim=ev.claim,
                            doi=art.doi if art else "",
                        )
                    )
        except Exception:
            continue

    all_spans.sort(key=lambda x: x.relevance_score, reverse=True)
    return EvidenceExtractor.deduplicate(all_spans)


async def run_friendly_profile(
    gene_info: dict,
    uniprot: dict,
    interactions: list[dict],
    cross_db: dict,
    neuro_data: dict,
    mutation_articles: list[BioArticle],
    deps: AgentDeps,
) -> FriendlyProfile:
    """Generate a human-friendly gene/protein profile."""
    ctx = json.dumps(
        {
            "gene": gene_info,
            "uniprot": uniprot,
            "interactions": interactions[:8],
            "cross_db": cross_db,
            "neuro": neuro_data,
            "mutation_articles": [
                {"title": a.title, "abstract": a.abstract[:400], "doi": a.doi}
                for a in mutation_articles[:5]
            ],
        },
        indent=1,
        default=str,
    )[:6000]

    model = build_model(deps.api_key, deps.model_name)
    result = await friendly_profile_agent.run(
        f"Generate a friendly profile for this gene/protein:\n\n{ctx}",
        deps=deps,
        model=model,
    )
    return result.output
