"""
Live database clients for BioSynthAI.

All data is fetched dynamically — nothing is hardcoded.

Clients:
  PubMedClient    — PubMed / PMC (NCBI E-utilities)
  GeneClient      — NCBI Gene (gene info, GO terms, pathways)
  MeSHClient      — NLM MeSH API (dynamic term resolution)
  BioRxivClient   — bioRxiv preprints
  STRINGClient    — protein interactions + pathway enrichment
  UniProtClient   — protein function, domains, diseases
  OpenTargetsClient — drug-target-disease (GraphQL)
  DANDIClient     — neurophysiology datasets (NWB format)
  AllenBrainClient  — brain region gene expression
  NeuroMorphoClient — neuron morphology reconstructions
"""

from __future__ import annotations

import re
import time
from dataclasses import asdict
from datetime import datetime, timedelta

import requests

from .cache import Cache
from .models import BioArticle

# ── Constants ─────────────────────────────────────────────────────────

_NCBI_BASE   = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils"
_NCBI_TOOL   = "biosynthai"
_NCBI_EMAIL  = "user@example.com"
_RATE_LIMIT  = 0.35   # seconds between NCBI requests (3 req/s without key)


# ────────────────────────── MeSH Client ────────────────────────────────

class MeSHClient:
    """Dynamic MeSH term resolution via NLM Lookup API."""

    _API = "https://id.nlm.nih.gov/mesh/lookup"

    def __init__(self, cache: Cache | None = None) -> None:
        self.session = requests.Session()
        self.cache = cache

    def resolve(self, term: str) -> str:
        """Convert a plain term to its best MeSH search string."""
        if self.cache:
            cached = self.cache.get("mesh", term.lower())
            if cached:
                return cached["mesh"]

        # Primary: NLM Lookup API
        try:
            r = self.session.get(
                f"{self._API}/descriptor",
                params={"label": term, "match": "contains", "limit": 5, "year": "current"},
                timeout=8,
                headers={"Accept": "application/json"},
            )
            if r.status_code == 200 and r.json():
                label = r.json()[0].get("label", term)
                result = f"{label}[MeSH Terms]"
                if self.cache:
                    self.cache.set("mesh", term.lower(), {"mesh": result})
                return result
        except Exception:
            pass

        # Fallback: NCBI E-utilities mesh DB
        try:
            time.sleep(_RATE_LIMIT)
            r = self.session.get(
                f"{_NCBI_BASE}/esearch.fcgi",
                params={"db": "mesh", "term": term, "retmode": "json", "retmax": 1},
                timeout=8,
            )
            if r.status_code == 200:
                ids = r.json().get("esearchresult", {}).get("idlist", [])
                if ids:
                    time.sleep(_RATE_LIMIT)
                    r2 = self.session.get(
                        f"{_NCBI_BASE}/esummary.fcgi",
                        params={"db": "mesh", "id": ids[0], "retmode": "json"},
                        timeout=8,
                    )
                    if r2.status_code == 200:
                        entry = r2.json().get("result", {}).get(ids[0], {})
                        name = (entry.get("ds_meshterms") or [term])[0]
                        result = f"{name}[MeSH Terms]"
                        if self.cache:
                            self.cache.set("mesh", term.lower(), {"mesh": result})
                        return result
        except Exception:
            pass

        return f"{term}[All Fields]"

    def get_tree_context(self, term: str) -> dict:
        """Return MeSH tree hierarchy for a term."""
        try:
            r = self.session.get(
                f"{self._API}/descriptor",
                params={"label": term, "match": "exact", "limit": 1, "year": "current"},
                timeout=8,
                headers={"Accept": "application/json"},
            )
            if r.status_code == 200 and r.json():
                e = r.json()[0]
                return {
                    "descriptor": e.get("label", ""),
                    "scope_note": e.get("scopeNote", ""),
                    "tree_numbers": e.get("treeNumbers", []),
                    "uri": e.get("resource", ""),
                }
        except Exception:
            pass
        return {}


# ────────────────────────── Gene Client ────────────────────────────────

class GeneClient:
    """NCBI Gene + PubMed via E-utilities."""

    def __init__(
        self,
        email: str = _NCBI_EMAIL,
        api_key: str = "",
        cache: Cache | None = None,
    ) -> None:
        self.email = email
        self.api_key = api_key
        self.cache = cache
        self.session = requests.Session()

    # ── Internal helpers ──────────────────────────────────────────────

    def _params(self, **extra) -> dict:
        p = {"tool": _NCBI_TOOL, "email": self.email, "retmode": "json"}
        if self.api_key:
            p["api_key"] = self.api_key
        p.update(extra)
        return p

    def _get(self, endpoint: str, **kw) -> dict:
        time.sleep(_RATE_LIMIT)
        return self.session.get(
            f"{_NCBI_BASE}/{endpoint}", params=self._params(**kw), timeout=30
        ).json()

    def _xml(self, endpoint: str, **kw) -> str:
        time.sleep(_RATE_LIMIT)
        p = {"tool": _NCBI_TOOL, "email": self.email, "retmode": "xml"}
        if self.api_key:
            p["api_key"] = self.api_key
        p.update(kw)
        return self.session.get(
            f"{_NCBI_BASE}/{endpoint}", params=p, timeout=30
        ).text

    # ── Gene lookup ───────────────────────────────────────────────────

    def search_gene(self, symbol: str) -> dict:
        if self.cache:
            c = self.cache.get("gene", symbol)
            if c:
                return c

        d = self._get(
            "esearch.fcgi",
            db="gene",
            term=f"{symbol}[Gene Name] AND human[Organism]",
            retmax=1,
        )
        ids = d.get("esearchresult", {}).get("idlist", [])
        if not ids:
            return {}

        xml = self._xml("efetch.fcgi", db="gene", id=ids[0], rettype="xml")
        info: dict = {"gene_id": ids[0], "symbol": symbol}

        m = re.search(r"<Gene-ref_desc>(.*?)</Gene-ref_desc>", xml)
        if m:
            info["full_name"] = m.group(1)

        m = re.search(r"<Entrezgene_summary>(.*?)</Entrezgene_summary>", xml, re.DOTALL)
        if m:
            info["summary"] = re.sub(r"<[^>]+>", "", m.group(1)).strip()

        go = re.findall(r"<Gene-commentary_text>(GO:.*?)</Gene-commentary_text>", xml)
        if go:
            info["go_terms"] = go[:20]

        m = re.search(r'<Entrezgene_type value="(.*?)"', xml)
        if m:
            info["gene_type"] = m.group(1)

        m = re.search(r"<Gene-ref_maploc>(.*?)</Gene-ref_maploc>", xml)
        if m:
            info["map_location"] = m.group(1)

        refs = re.findall(r"<Gene-commentary_accession>(N[MR]_\d+)</Gene-commentary_accession>", xml)
        if refs:
            info["refseq_ids"] = list(set(refs))[:5]

        if self.cache:
            self.cache.set("gene", symbol, info)
        return info

    def get_clinvar_count(self, gene_id: str) -> int:
        try:
            d = self._get("esearch.fcgi", db="clinvar", term=f"{gene_id}[gene_id]", retmax=0)
            return int(d.get("esearchresult", {}).get("count", 0))
        except Exception:
            return 0

    def get_gene_expression_profiles(self, gene_id: str) -> int:
        try:
            d = self._get("elink.fcgi", dbfrom="gene", db="geoprofiles", id=gene_id)
            count = 0
            for ls in d.get("linksets", []):
                for ldb in ls.get("linksetdbs", []):
                    count += len(ldb.get("links", []))
            return count
        except Exception:
            return 0

    def get_gene_links(self, pmids: list[str]) -> list[str]:
        if not pmids:
            return []
        d = self._get("elink.fcgi", dbfrom="pubmed", db="gene", id=",".join(pmids[:5]))
        gids: list[str] = []
        for ls in d.get("linksets", []):
            for ldb in ls.get("linksetdbs", []):
                for lk in ldb.get("links", [])[:10]:
                    gid = str(lk.get("id", lk)) if isinstance(lk, dict) else str(lk)
                    if gid not in gids:
                        gids.append(gid)
        return gids

    # ── PubMed ────────────────────────────────────────────────────────

    def search_pubmed(self, query: str, max_results: int = 10) -> list[str]:
        if self.cache:
            c = self.cache.get("search", query)
            if c:
                return c["pmids"]
        d = self._get(
            "esearch.fcgi", db="pubmed", term=query, retmax=max_results, sort="relevance"
        )
        pmids = d.get("esearchresult", {}).get("idlist", [])
        if self.cache:
            self.cache.set("search", query, {"pmids": pmids})
        return pmids

    def fetch_articles(self, pmids: list[str]) -> list[BioArticle]:
        if not pmids:
            return []

        articles: list[BioArticle] = []
        uncached: list[str] = []

        if self.cache:
            for p in pmids:
                c = self.cache.get("art", p)
                if c:
                    articles.append(BioArticle(**c))
                else:
                    uncached.append(p)
        else:
            uncached = list(pmids)

        if uncached:
            xml = self._xml("efetch.fcgi", db="pubmed", id=",".join(uncached), rettype="xml")
            for block in re.split(r"<PubmedArticle>", xml)[1:]:
                a = BioArticle(pmid="")

                m = re.search(r"<PMID[^>]*>(\d+)</PMID>", block)
                if m:
                    a.pmid = m.group(1)

                m = re.search(r"<ArticleTitle>(.*?)</ArticleTitle>", block, re.DOTALL)
                if m:
                    a.title = re.sub(r"<[^>]+>", "", m.group(1)).strip()

                a.abstract = " ".join(
                    re.sub(r"<[^>]+>", "", p_).strip()
                    for p_ in re.findall(
                        r"<AbstractText[^>]*>(.*?)</AbstractText>", block, re.DOTALL
                    )
                )

                au = re.findall(r"<LastName>(.*?)</LastName>\s*<ForeName>(.*?)</ForeName>", block)
                if au:
                    names = [f"{l} {f}" for l, f in au[:3]]
                    if len(au) > 3:
                        names.append("et al.")
                    a.authors = ", ".join(names)

                m = re.search(r"<Title>(.*?)</Title>", block)
                if m:
                    a.journal = m.group(1).strip()

                m = re.search(r"<PubDate>\s*<Year>(\d{4})</Year>", block)
                if m:
                    a.year = m.group(1)
                else:
                    m = re.search(r"<MedlineDate>(\d{4})", block)
                    if m:
                        a.year = m.group(1)

                m = re.search(r'<ArticleId IdType="doi">(.*?)</ArticleId>', block)
                if m:
                    a.doi = m.group(1).strip()

                m = re.search(r'<ArticleId IdType="pmc">(PMC\d+)</ArticleId>', block)
                if m:
                    a.pmc_id = m.group(1)

                a.mesh_terms = list(
                    dict.fromkeys(
                        re.findall(r"<DescriptorName[^>]*>(.*?)</DescriptorName>", block)
                    )
                )
                a.keywords = list(
                    dict.fromkeys(re.findall(r"<Keyword[^>]*>(.*?)</Keyword>", block))
                )

                if a.pmid:
                    articles.append(a)
                    if self.cache:
                        self.cache.set("art", a.pmid, a.model_dump())

        return articles

    def find_related(self, pmids: list[str], max_results: int = 8) -> list[str]:
        if not pmids:
            return []
        ck = ",".join(sorted(pmids))
        if self.cache:
            c = self.cache.get("rel", ck)
            if c:
                return c["p"]

        d = self._get(
            "elink.fcgi",
            dbfrom="pubmed",
            db="pubmed",
            id=",".join(pmids),
            cmd="neighbor_score",
        )
        related: list[str] = []
        for ls in d.get("linksets", []):
            for ldb in ls.get("linksetdbs", []):
                if ldb.get("linkname") == "pubmed_pubmed":
                    for lk in ldb.get("links", [])[:max_results]:
                        pid = str(lk.get("id", lk)) if isinstance(lk, dict) else str(lk)
                        if pid not in pmids and pid not in related:
                            related.append(pid)

        result = related[:max_results]
        if self.cache:
            self.cache.set("rel", ck, {"p": result})
        return result

    def fetch_full_text(self, pmc_ids: list[str]) -> dict[str, str]:
        results: dict[str, str] = {}
        for pid in pmc_ids[:3]:
            if self.cache:
                c = self.cache.get("ft", pid)
                if c:
                    results[pid] = c["t"]
                    continue
            try:
                xml = self._xml("efetch.fcgi", db="pmc", id=pid.replace("PMC", ""))
                body = re.findall(r"<body>(.*?)</body>", xml, re.DOTALL)
                if body:
                    text = re.sub(r"<[^>]+>", " ", body[0])
                    text = re.sub(r"\s+", " ", text).strip()[:8000]
                    results[pid] = text
                    if self.cache:
                        self.cache.set("ft", pid, {"t": text})
            except Exception:
                continue
        return results


# ────────────────────────── bioRxiv Client ─────────────────────────────

class BioRxivClient:
    def __init__(self, cache: Cache | None = None) -> None:
        self.session = requests.Session()
        self.cache = cache

    def search(self, query: str, max_results: int = 5) -> list[BioArticle]:
        if self.cache:
            c = self.cache.get("biorxiv", query)
            if c:
                return [BioArticle(**a) for a in c["a"]]

        try:
            today = datetime.now()
            start = (today - timedelta(days=60)).strftime("%Y-%m-%d")
            end = today.strftime("%Y-%m-%d")
            query_words = {w for w in query.lower().split() if len(w) > 3}
            articles: list[BioArticle] = []

            for cursor in range(0, 60, 30):
                r = self.session.get(
                    f"https://api.biorxiv.org/details/biorxiv/{start}/{end}/{cursor}/30",
                    timeout=15,
                )
                if r.status_code != 200:
                    break
                for item in r.json().get("collection", []):
                    combined = (item.get("title", "") + " " + item.get("abstract", "")).lower()
                    if sum(1 for w in query_words if w in combined) >= 2:
                        slug = item.get("doi", "").split("/")[-1]
                        articles.append(
                            BioArticle(
                                pmid=f"biorxiv_{slug}",
                                title=item.get("title", ""),
                                abstract=item.get("abstract", ""),
                                authors=item.get("authors", ""),
                                journal="bioRxiv (Preprint)",
                                year=item.get("date", "")[:4],
                                doi=item.get("doi", ""),
                                source="biorxiv",
                            )
                        )
                if len(articles) >= max_results:
                    break

            result = articles[:max_results]
            if self.cache:
                self.cache.set("biorxiv", query, {"a": [a.model_dump() for a in result]})
            return result
        except Exception:
            return []


# ────────────────────────── STRING Client ──────────────────────────────

class STRINGClient:
    _API = "https://string-db.org/api/json"

    def __init__(self, cache: Cache | None = None) -> None:
        self.session = requests.Session()
        self.cache = cache

    def get_interactions(
        self,
        gene: str,
        species: int = 9606,
        limit: int = 10,
        min_score: int = 700,
    ) -> list[dict]:
        ck = f"{gene}_{species}_{min_score}"
        if self.cache:
            c = self.cache.get("string", ck)
            if c:
                return c["i"]
        try:
            r = self.session.get(
                f"{self._API}/network",
                params={
                    "identifiers": gene,
                    "species": species,
                    "required_score": min_score,
                    "limit": limit,
                },
                timeout=15,
            )
            r.raise_for_status()
            ints = [
                {
                    "a": i.get("preferredName_A", ""),
                    "b": i.get("preferredName_B", ""),
                    "score": i.get("score", 0),
                }
                for i in r.json()
            ]
            if self.cache:
                self.cache.set("string", ck, {"i": ints})
            return ints
        except Exception:
            return []

    def get_enrichment(self, genes: list[str], species: int = 9606) -> list[dict]:
        try:
            r = self.session.get(
                f"{self._API}/enrichment",
                params={"identifiers": "\r".join(genes), "species": species},
                timeout=15,
            )
            r.raise_for_status()
            return [
                {
                    "category": i.get("category", ""),
                    "description": i.get("description", ""),
                    "p_value": i.get("p_value", 1),
                }
                for i in r.json()[:15]
            ]
        except Exception:
            return []


# ────────────────────────── UniProt Client ─────────────────────────────

class UniProtClient:
    _API = "https://rest.uniprot.org/uniprotkb/search"

    def __init__(self, cache: Cache | None = None) -> None:
        self.session = requests.Session()
        self.cache = cache

    def get_protein(self, gene: str) -> dict:
        if self.cache:
            c = self.cache.get("uniprot", gene)
            if c:
                return c
        try:
            r = self.session.get(
                self._API,
                params={
                    "query": f"gene_exact:{gene} AND organism_id:9606 AND reviewed:true",
                    "format": "json",
                    "size": 1,
                    "fields": (
                        "accession,protein_name,cc_function,"
                        "cc_subcellular_location,ft_domain,cc_disease,length"
                    ),
                },
                timeout=15,
            )
            r.raise_for_status()
            results = r.json().get("results", [])
            if not results:
                return {}

            e = results[0]
            up: dict = {
                "accession": e.get("primaryAccession", ""),
                "gene": gene,
                "length": e.get("sequence", {}).get("length", 0),
            }

            pn = e.get("proteinDescription", {}).get("recommendedName", {})
            if pn:
                up["protein_name"] = pn.get("fullName", {}).get("value", "")

            for c in e.get("comments", []):
                ct = c.get("commentType", "")
                if ct == "FUNCTION":
                    texts = c.get("texts", [])
                    if texts:
                        up["function"] = texts[0].get("value", "")
                elif ct == "SUBCELLULAR LOCATION":
                    locs = [
                        sl.get("location", {}).get("value", "")
                        for sl in c.get("subcellularLocations", [])
                        if sl.get("location")
                    ]
                    up["location"] = "; ".join(locs)
                elif ct == "DISEASE":
                    dis = c.get("disease", {})
                    if dis.get("diseaseId"):
                        up.setdefault("diseases", []).append(
                            {"name": dis["diseaseId"], "desc": dis.get("description", "")[:200]}
                        )

            up["domains"] = [
                {
                    "name": f.get("description", ""),
                    "start": f.get("location", {}).get("start", {}).get("value", ""),
                    "end": f.get("location", {}).get("end", {}).get("value", ""),
                }
                for f in e.get("features", [])
                if f.get("type") == "Domain"
            ]

            if self.cache:
                self.cache.set("uniprot", gene, up)
            return up
        except Exception:
            return {}


# ────────────────────────── Open Targets Client ────────────────────────

class OpenTargetsClient:
    _API = "https://api.platform.opentargets.org/api/v4/graphql"

    def __init__(self, cache: Cache | None = None) -> None:
        self.session = requests.Session()
        self.cache = cache

    def _ensembl_id(self, symbol: str) -> str:
        try:
            r = self.session.post(
                self._API,
                json={
                    "query": 'query($q:String!){search(queryString:$q,entityNames:["target"],page:{size:1,index:0}){hits{id}}}',
                    "variables": {"q": symbol},
                },
                timeout=10,
            )
            hits = r.json().get("data", {}).get("search", {}).get("hits", [])
            return hits[0]["id"] if hits else ""
        except Exception:
            return ""

    def get_drugs(self, gene: str, max_results: int = 10) -> list[dict]:
        if self.cache:
            c = self.cache.get("ot_drugs", gene)
            if c:
                return c["d"]

        eid = self._ensembl_id(gene)
        if not eid:
            return []

        try:
            r = self.session.post(
                self._API,
                json={
                    "query": """
                    query($id:String!,$n:Int!){target(ensemblId:$id){knownDrugs(size:$n){
                    rows{drug{name mechanismOfAction isApproved}disease{name}phase status}}}}
                    """,
                    "variables": {"id": eid, "n": max_results},
                },
                timeout=15,
            )
            rows = (
                r.json()
                .get("data", {})
                .get("target", {})
                .get("knownDrugs", {})
                .get("rows", [])
            )
            drugs = [
                {
                    "drug": row.get("drug", {}).get("name", ""),
                    "mechanism": row.get("drug", {}).get("mechanismOfAction", ""),
                    "approved": row.get("drug", {}).get("isApproved", False),
                    "disease": row.get("disease", {}).get("name", ""),
                    "phase": row.get("phase", ""),
                }
                for row in rows
            ]
            if self.cache:
                self.cache.set("ot_drugs", gene, {"d": drugs})
            return drugs
        except Exception:
            return []

    def get_diseases(self, gene: str, max_results: int = 10) -> list[dict]:
        eid = self._ensembl_id(gene)
        if not eid:
            return []
        try:
            r = self.session.post(
                self._API,
                json={
                    "query": """
                    query($id:String!,$n:Int!){target(ensemblId:$id){associatedDiseases(page:{size:$n,index:0}){
                    rows{disease{name}score}}}}
                    """,
                    "variables": {"id": eid, "n": max_results},
                },
                timeout=15,
            )
            rows = (
                r.json()
                .get("data", {})
                .get("target", {})
                .get("associatedDiseases", {})
                .get("rows", [])
            )
            return [{"disease": row["disease"]["name"], "score": row.get("score", 0)} for row in rows]
        except Exception:
            return []


# ────────────────────────── DANDI Client ───────────────────────────────

class DANDIClient:
    """Search DANDI Archive for neurophysiology datasets (NWB format)."""

    _API = "https://api.dandiarchive.org/api"

    def __init__(self, cache: Cache | None = None) -> None:
        self.session = requests.Session()
        self.cache = cache

    def search(self, query: str, max_results: int = 8) -> list[dict]:
        ck = f"dandi_{query}"
        if self.cache:
            c = self.cache.get("dandi", ck)
            if c:
                return c["ds"]

        try:
            r = self.session.get(
                f"{self._API}/dandisets/",
                params={
                    "search": query,
                    "page_size": max_results,
                    "ordering": "-modified",
                    "draft": "false",
                    "empty": "false",
                },
                timeout=15,
            )
            r.raise_for_status()

            datasets: list[dict] = []
            for item in r.json().get("results", []):
                most_recent = (
                    item.get("most_recent_published_version")
                    or item.get("draft_version")
                    or {}
                )
                meta = most_recent.get("metadata") or {}

                ds: dict = {
                    "dandiset_id": item.get("identifier", ""),
                    "title": most_recent.get("name", item.get("identifier", "")),
                    "description": (meta.get("description") or "")[:500],
                    "url": f"https://dandiarchive.org/dandiset/{item.get('identifier', '')}",
                    "num_files": most_recent.get("asset_count", 0),
                    "size_bytes": most_recent.get("size", 0),
                    "modified": item.get("modified", ""),
                    "species": [],
                    "techniques": [],
                }

                for approach in meta.get("approach", []):
                    if approach.get("name"):
                        ds["techniques"].append(approach["name"])
                for species in meta.get("about", []):
                    if species.get("name"):
                        ds["species"].append(species["name"])
                for mt in meta.get("measurementTechnique", []):
                    if mt.get("name") and mt["name"] not in ds["techniques"]:
                        ds["techniques"].append(mt["name"])

                datasets.append(ds)

            if self.cache:
                self.cache.set("dandi", ck, {"ds": datasets})
            return datasets
        except Exception as exc:
            return [{"error": str(exc)}]


# ────────────────────────── Allen Brain Client ─────────────────────────

class AllenBrainClient:
    _API = "https://api.brain-map.org/api/v2"

    def __init__(self, cache: Cache | None = None) -> None:
        self.session = requests.Session()
        self.cache = cache

    def get_expression(self, gene_symbol: str) -> dict:
        if self.cache:
            c = self.cache.get("allen", gene_symbol)
            if c:
                return c

        try:
            r = self.session.get(
                f"{self._API}/data/Gene/query.json",
                params={
                    "criteria": f"[acronym$eq'{gene_symbol}']",
                    "include": "organism",
                    "num_rows": 1,
                },
                timeout=10,
            )
            if r.status_code != 200 or not r.json().get("msg"):
                return {}

            gene_id = r.json()["msg"][0].get("id")
            r2 = self.session.get(
                f"{self._API}/data/StructureUnionize/query.json",
                params={
                    "criteria": f"[section_data_set_id$eq{gene_id}]",
                    "include": "structure",
                    "num_rows": 30,
                    "order": "expression_energy__desc",
                },
                timeout=10,
            )
            if r2.status_code != 200:
                return {}

            regions = [
                {
                    "region": item.get("structure", {}).get("name", ""),
                    "acronym": item.get("structure", {}).get("acronym", ""),
                    "expression_energy": item.get("expression_energy", 0),
                    "expression_density": item.get("expression_density", 0),
                }
                for item in r2.json().get("msg", [])[:20]
            ]

            result = {
                "gene_symbol": gene_symbol,
                "regions": regions,
                "source": "Allen Human Brain Atlas",
            }
            if self.cache:
                self.cache.set("allen", gene_symbol, result)
            return result
        except Exception:
            return {}


# ────────────────────────── NeuroMorpho Client ─────────────────────────

class NeuroMorphoClient:
    """Search NeuroMorpho.Org for neuron reconstructions."""

    _API = "https://neuromorpho.org/api"

    def __init__(self, cache: Cache | None = None) -> None:
        self.session = requests.Session()
        self.cache = cache

    def search(
        self,
        brain_region: str = "",
        cell_type: str = "",
        species: str = "mouse",
        max_results: int = 5,
    ) -> list[dict]:
        ck = f"{brain_region}_{cell_type}_{species}"
        if self.cache:
            c = self.cache.get("neuromorpho", ck)
            if c:
                return c["neurons"]

        try:
            filters: dict = {}
            if brain_region:
                filters["brain_region"] = [brain_region]
            if cell_type:
                filters["cell_type"] = [cell_type]
            if species:
                filters["species"] = [species]

            r = self.session.post(
                f"{self._API}/neuron/select",
                json=filters,
                params={"page": 0, "size": max_results},
                timeout=10,
                headers={"Content-Type": "application/json"},
            )
            if r.status_code != 200:
                return []

            neurons = [
                {
                    "neuron_id": item.get("neuron_id", ""),
                    "neuron_name": item.get("neuron_name", ""),
                    "species": item.get("species", ""),
                    "brain_region": ", ".join(item.get("brain_region", [])),
                    "cell_type": ", ".join(item.get("cell_type", [])),
                    "archive": item.get("archive", ""),
                    "url": f"https://neuromorpho.org/neuron_info.jsp?neuron_name={item.get('neuron_name', '')}",
                }
                for item in r.json().get("_embedded", {}).get("neuronResources", [])
            ]

            if self.cache:
                self.cache.set("neuromorpho", ck, {"neurons": neurons})
            return neurons
        except Exception:
            return []
