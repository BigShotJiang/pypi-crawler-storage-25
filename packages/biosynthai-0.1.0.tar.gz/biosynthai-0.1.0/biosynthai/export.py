"""
Export utilities for BioSynthAI synthesis results.

Formats: markdown, json, bibtex
"""

from __future__ import annotations

import json

from .models import BioSynthesisResult


def to_markdown(result: BioSynthesisResult) -> str:
    """Export synthesis result as a structured Markdown report."""
    lines = [
        f"# BioSynthAI Synthesis Report",
        f"",
        f"**Query:** {result.query}",
        f"",
        f"**Generated:** {result.timestamp}",
        f"",
        f"**Articles analysed:** {len(result.articles)}",
        f"**Evidence spans:** {len(result.evidence)}",
        f"**DANDI datasets:** {len(result.dandi_datasets)}",
        f"",
        f"---",
        f"",
        f"## Synthesis",
        f"",
        result.synthesis_text,
    ]

    if result.gene_info:
        g = result.gene_info
        lines += [
            "", "---", "",
            f"## Gene Information: {g.get('symbol', '')}",
            "",
            f"- **Full name:** {g.get('full_name', 'N/A')}",
            f"- **Gene ID:** {g.get('gene_id', 'N/A')}",
            f"- **Map location:** {g.get('map_location', 'N/A')}",
            f"- **Gene type:** {g.get('gene_type', 'N/A')}",
            "",
        ]
        if g.get("summary"):
            lines += [f"**Summary:** {g['summary']}", ""]
        if g.get("go_terms"):
            lines += ["**GO Terms:**"] + [f"- {t}" for t in g["go_terms"][:10]] + [""]

    if result.uniprot_data:
        u = result.uniprot_data
        lines += [
            "---", "",
            f"## Protein: {u.get('protein_name', '')} ({u.get('accession', '')})",
            "",
            f"- **Length:** {u.get('length', 'N/A')} aa",
            f"- **Location:** {u.get('location', 'N/A')}",
            "",
        ]
        if u.get("function"):
            lines += [f"**Function:** {u['function']}", ""]
        if u.get("domains"):
            lines += ["**Domains:**"] + [
                f"- {d['name']} ({d.get('start', '')}–{d.get('end', '')})"
                for d in u["domains"]
            ] + [""]
        if u.get("diseases"):
            lines += ["**Associated diseases:**"] + [
                f"- {d['name']}: {d.get('desc', '')[:200]}" for d in u["diseases"]
            ] + [""]

    if result.interactions:
        lines += [
            "---", "",
            "## STRING Protein Interactions",
            "",
        ] + [f"- {i['a']} ↔ {i['b']} (score: {i['score']})" for i in result.interactions[:10]] + [""]

    if result.dandi_datasets:
        lines += ["---", "", "## DANDI Neurophysiology Datasets", ""]
        for ds in result.dandi_datasets:
            if ds.get("error"):
                continue
            lines += [
                f"### {ds.get('title', ds.get('dandiset_id', 'Unknown'))}",
                f"- **ID:** {ds.get('dandiset_id', 'N/A')}",
                f"- **URL:** {ds.get('url', 'N/A')}",
                f"- **Files:** {ds.get('num_files', 'N/A')}",
                f"- **Techniques:** {', '.join(ds.get('techniques', [])[:5]) or 'N/A'}",
                f"- **Species:** {', '.join(ds.get('species', [])[:3]) or 'N/A'}",
                "",
            ]

    if result.evidence:
        lines += ["---", "", "## Evidence Spans", ""]
        for i, e in enumerate(result.evidence[:15], 1):
            lines += [
                f"**[{i}]** PMID:{e.paper_pmid} | {e.section} | score:{e.relevance_score}",
                f"> {e.text[:300]}",
                f"*Claim: {e.claim or '—'}*",
                "",
            ]

    lines += ["---", "", "## References", ""]
    for i, a in enumerate(result.articles, 1):
        ref = f"[{i}] {a.citation}"
        if a.pmid and not a.pmid.startswith("biorxiv_"):
            ref += f" PMID:{a.pmid}"
        lines.append(ref)

    return "\n".join(lines)


def to_json(result: BioSynthesisResult) -> str:
    """Export synthesis result as JSON."""
    data = {
        "query": result.query,
        "timestamp": result.timestamp,
        "plan": result.plan.model_dump(),
        "summary": result.summary_dict(),
        "gene_info": result.gene_info,
        "uniprot_data": result.uniprot_data,
        "interactions": result.interactions,
        "cross_db": result.cross_db,
        "neuro_data": result.neuro_data,
        "dandi_datasets": result.dandi_datasets,
        "synthesis_text": result.synthesis_text,
        "articles": [
            {
                "pmid": a.pmid,
                "title": a.title,
                "authors": a.authors,
                "year": a.year,
                "journal": a.journal,
                "doi": a.doi,
                "source": a.source,
                "mesh_terms": a.mesh_terms[:10],
                "abstract": a.abstract[:500],
                "citation": a.citation,
            }
            for a in result.articles
        ],
        "evidence": [
            {
                "text": e.text,
                "paper_pmid": e.paper_pmid,
                "paper_title": e.paper_title,
                "section": e.section,
                "relevance_score": e.relevance_score,
                "claim": e.claim,
                "doi": e.doi,
                "direction": e.direction,
            }
            for e in result.evidence
        ],
        "friendly_profile": result.friendly.model_dump() if result.friendly else None,
    }
    return json.dumps(data, indent=2, ensure_ascii=False, default=str)


def to_bibtex(result: BioSynthesisResult) -> str:
    """Export included articles as BibTeX."""
    entries: list[str] = []
    for a in result.articles:
        first_author = a.authors.split(",")[0].split()[-1] if a.authors else "Unknown"
        year = a.year or "0000"
        key_title = "".join(c for c in a.title[:20] if c.isalnum())
        cite_key = f"{first_author}{year}{key_title}"

        entry_type = "@misc" if a.pmid.startswith("biorxiv_") else "@article"
        lines = [
            f"{entry_type}{{{cite_key},",
            f"  title = {{{a.title}}},",
            f"  author = {{{a.authors}}},",
            f"  year = {{{a.year}}},",
            f"  journal = {{{a.journal}}},",
        ]
        if a.doi:
            lines.append(f"  doi = {{{a.doi}}},")
        if a.pmid and not a.pmid.startswith("biorxiv_"):
            lines.append(f"  pmid = {{{a.pmid}}},")
        lines.append("}")
        entries.append("\n".join(lines))

    return "\n\n".join(entries)
