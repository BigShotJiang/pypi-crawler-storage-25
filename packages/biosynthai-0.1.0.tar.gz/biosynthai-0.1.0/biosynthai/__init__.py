"""
BioSynthAI — Neuroscience Knowledge Synthesizer

A pydantic-ai powered pipeline that synthesizes neuroscience research
from live databases: PubMed, NCBI Gene, MeSH, bioRxiv, STRING,
UniProt, Open Targets, DANDI Archive, Allen Brain Atlas,
NeuroMorpho.Org, and ClinVar.

Designed for FastAPI integration (same pattern as prisma-review-agent).

Quick start:
    from biosynthai import BioSynthesizer, BioSearchQuery

    synth = BioSynthesizer(api_key="sk-or-v1-...")
    result = await synth.run(BioSearchQuery(question="What does BDNF do in hippocampus?"))
    print(result.synthesis_text)
"""

from .pipeline import BioSynthesizer
from .models import (
    BioSearchQuery,
    BioSynthesisResult,
    BioSearchPlan,
    BioArticle,
    EvidenceSpan,
    FriendlyProfile,
    SearchIntent,
)
from .export import to_markdown, to_json, to_bibtex

__version__ = "0.1.0"
__all__ = [
    "BioSynthesizer",
    "BioSearchQuery",
    "BioSynthesisResult",
    "BioSearchPlan",
    "BioArticle",
    "EvidenceSpan",
    "FriendlyProfile",
    "SearchIntent",
    "to_markdown",
    "to_json",
    "to_bibtex",
    "__version__",
]
