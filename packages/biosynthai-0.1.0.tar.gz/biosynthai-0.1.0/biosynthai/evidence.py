"""
Heuristic evidence extractor for BioSynthAI.

Used as a fast first-pass before (or instead of) the LLM evidence agent.
Scores sentences by relevance to the query and deduplicates by overlap.
"""

from __future__ import annotations

import re

from .models import EvidenceDirection, EvidenceSpan, BioArticle


_NEURO_PHRASES = {
    "we found", "results show", "demonstrated", "suggest that",
    "mechanism", "pathway", "receptor", "neuron", "synap",
    "cortex", "hippocam", "dopamin", "serotonin", "glutamat",
    "signaling", "expression", "significant", "inhibit", "activat",
    "circuit", "potentiat", "long-term", "plasticity", "firing",
    "action potential", "voltage-gated", "calcium", "AMPA", "NMDA",
    "GABA", "acetylcholine", "norepinephrine", "enkephalin",
}


class EvidenceExtractor:
    """Heuristic sentence-level evidence extraction."""

    @staticmethod
    def extract(
        articles: list[BioArticle],
        query: str,
        gene_symbols: list[str],
        max_spans: int = 20,
    ) -> list[EvidenceSpan]:
        query_terms = [w for w in query.split() if len(w) > 3]
        spans: list[EvidenceSpan] = []

        for article in articles:
            sections = []
            if article.full_text:
                sections.append(("full_text", article.full_text))
            sections.append(("abstract", article.abstract))

            for section_name, text in sections:
                if not text:
                    continue
                sentences = re.split(r"(?<=[.!?])\s+(?=[A-Z])", re.sub(r"\s+", " ", text))
                for sent in sentences:
                    if len(sent) < 30:
                        continue
                    sl = sent.lower()
                    score = 0.0

                    # Gene hits
                    for g in gene_symbols:
                        if g.lower() in sl:
                            score += 0.3

                    # Query term hits
                    score += sum(0.15 for t in query_terms if t.lower() in sl)

                    # Neuroscience signal phrases
                    for phrase in _NEURO_PHRASES:
                        if phrase in sl:
                            score += 0.05

                    # Word-count penalty
                    wc = len(sent.split())
                    if wc < 10:
                        score *= 0.5
                    elif wc > 60:
                        score *= 0.7

                    if score >= 0.2:
                        # Detect contradiction signals
                        direction = EvidenceDirection.SUPPORTS
                        if any(w in sl for w in ("contradict", "however", "although", "failed to", "no effect")):
                            direction = EvidenceDirection.CONTRADICTS

                        spans.append(
                            EvidenceSpan(
                                text=sent.strip(),
                                paper_pmid=article.pmid,
                                paper_title=article.title,
                                section=section_name,
                                relevance_score=round(min(score, 1.0), 3),
                                doi=article.doi,
                                direction=direction,
                            )
                        )

        spans.sort(key=lambda x: x.relevance_score, reverse=True)
        return EvidenceExtractor.deduplicate(spans)[:max_spans]

    @staticmethod
    def deduplicate(spans: list[EvidenceSpan], threshold: float = 0.7) -> list[EvidenceSpan]:
        """Remove near-duplicate spans using word overlap."""
        kept: list[EvidenceSpan] = []
        for span in spans:
            words = set(span.text.lower().split())
            is_dup = any(
                (
                    len(words & set(k.text.lower().split()))
                    / min(len(words), len(set(k.text.lower().split())))
                    > threshold
                )
                for k in kept
                if words and k.text
            )
            if not is_dup:
                kept.append(span)
        return kept
