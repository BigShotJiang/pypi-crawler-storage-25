"""
BioSynthAI CLI entry point.

After ``pip install biosynthai``:
    biosynthai "What does BDNF do in the hippocampus?"
    biosynthai --version

For local development:
    python -m biosynthai "What does BDNF do in the hippocampus?"
"""

from __future__ import annotations

import argparse
import asyncio
import os
import sys
from datetime import datetime
from pathlib import Path

from dotenv import load_dotenv

from . import BioSynthesizer, BioSearchQuery, to_markdown, to_json, to_bibtex, __version__


def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="biosynthai",
        description="BioSynthAI — Neuroscience & Biomedical Knowledge Synthesizer",
    )
    p.add_argument("question", nargs="?", help="Research question to synthesize")
    p.add_argument("--version", "-V", action="version", version=f"%(prog)s {__version__}")
    p.add_argument(
        "--model", default="anthropic/claude-sonnet-4",
        help="OpenRouter model ID (default: anthropic/claude-sonnet-4)",
    )
    p.add_argument(
        "--max-results", type=int, default=10,
        help="Max PubMed results per query (default: 10)",
    )
    p.add_argument(
        "--depth", type=int, default=1,
        help="Related-article expansion depth (default: 1)",
    )
    p.add_argument("--api-key", default="", help="OpenRouter API key (overrides OPENROUTER_API_KEY env)")
    p.add_argument("--ncbi-key", default="", help="NCBI API key (overrides NCBI_API_KEY env)")
    p.add_argument("--no-biorxiv", action="store_true", help="Skip bioRxiv search")
    p.add_argument("--no-full-text", action="store_true", help="Skip PMC full-text fetch")
    p.add_argument("--no-string", action="store_true", help="Skip STRING interactions")
    p.add_argument("--no-dandi", action="store_true", help="Skip DANDI archive search")
    p.add_argument("--no-allen", action="store_true", help="Skip Allen Brain Atlas")
    p.add_argument("--no-opentargets", action="store_true", help="Skip Open Targets")
    p.add_argument("--no-cache", action="store_true", help="Disable SQLite cache")
    p.add_argument(
        "--output", "-o", default="synthesis_results",
        help="Output directory (default: synthesis_results)",
    )
    p.add_argument(
        "--format", choices=["markdown", "json", "bibtex", "all"], default="all",
        help="Export format (default: all)",
    )
    return p


async def _main(args: argparse.Namespace) -> None:
    load_dotenv()

    api_key = args.api_key or os.environ.get("OPENROUTER_API_KEY", "")
    if not api_key:
        print("Error: OPENROUTER_API_KEY not set. Pass --api-key, add it to .env, or export it.", file=sys.stderr)
        sys.exit(1)

    ncbi_key = args.ncbi_key or os.environ.get("NCBI_API_KEY", "")

    query = BioSearchQuery(
        question=args.question,
        model=args.model,
        max_results_per_query=args.max_results,
        related_depth=args.depth,
        enable_biorxiv=not args.no_biorxiv,
        enable_full_text=not args.no_full_text,
        enable_string=not args.no_string,
        enable_dandi=not args.no_dandi,
        enable_allen=not args.no_allen,
        enable_opentargets=not args.no_opentargets,
        enable_cache=not args.no_cache,
        ncbi_api_key=ncbi_key,
    )

    synth = BioSynthesizer(
        api_key=api_key,
        model_name=args.model,
        ncbi_api_key=ncbi_key,
        cache_path=None if args.no_cache else Path("biosynth_cache.db"),
        related_depth=args.depth,
        enable_biorxiv=not args.no_biorxiv,
        enable_full_text=not args.no_full_text,
        enable_string=not args.no_string,
        enable_dandi=not args.no_dandi,
        enable_allen=not args.no_allen,
        enable_opentargets=not args.no_opentargets,
    )

    result = await synth.run(query, progress_callback=lambda m: print(f"  {m}"))

    out_dir = Path(args.output)
    out_dir.mkdir(parents=True, exist_ok=True)

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")

    if args.format in ("markdown", "all"):
        md_path = out_dir / f"synthesis_{ts}.md"
        md_path.write_text(to_markdown(result), encoding="utf-8")
        print(f"\nMarkdown: {md_path}")

    if args.format in ("json", "all"):
        json_path = out_dir / f"synthesis_{ts}.json"
        json_path.write_text(to_json(result), encoding="utf-8")
        print(f"JSON:     {json_path}")

    if args.format in ("bibtex", "all"):
        bib_path = out_dir / f"synthesis_{ts}.bib"
        bib_path.write_text(to_bibtex(result), encoding="utf-8")
        print(f"BibTeX:   {bib_path}")

    print(f"\nArticles: {len(result.articles)} | Evidence spans: {len(result.evidence)}")
    if result.dandi_datasets:
        print(f"DANDI datasets: {len(result.dandi_datasets)}")

    print("\n" + "=" * 60)
    print(result.synthesis_text[:2000])
    if len(result.synthesis_text) > 2000:
        print(f"\n... (full synthesis saved to {out_dir})")


def main() -> None:
    parser = _build_parser()
    args = parser.parse_args()

    if not args.question:
        parser.print_help()
        sys.exit(1)

    asyncio.run(_main(args))


if __name__ == "__main__":
    main()
