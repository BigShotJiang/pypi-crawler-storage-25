"""
Pydantic models for BioSynthAI — Neuroscience Knowledge Synthesizer.

All data models use Pydantic v2 for validation and structured output
from pydantic-ai agents. Designed for FastAPI integration.
"""

from __future__ import annotations

from datetime import datetime
from typing import Optional
from enum import Enum

from pydantic import BaseModel, Field


# ────────────────────────── Enums ──────────────────────────────────────

class SearchIntent(str, Enum):
    FIND_ARTICLES = "find_articles"
    EXPLAIN_GENE = "explain_gene"
    COMPARE = "compare"
    PATHWAY = "pathway"
    CIRCUIT = "circuit"
    RECEPTOR = "receptor"
    GENERAL = "general"


class EvidenceDirection(str, Enum):
    SUPPORTS = "supports"
    CONTRADICTS = "contradicts"
    NEUTRAL = "neutral"


# ────────────────────────── Input Models ───────────────────────────────

class BioSearchQuery(BaseModel):
    """User-facing input to start a synthesis run."""
    question: str = Field(..., min_length=5, max_length=2000,
                          description="Neuroscience research question")
    model: str = Field(default="anthropic/claude-sonnet-4",
                       description="OpenRouter model to use")
    max_results_per_query: int = Field(default=10, ge=3, le=50)
    related_depth: int = Field(default=1, ge=0, le=3)
    enable_biorxiv: bool = True
    enable_full_text: bool = True
    enable_string: bool = True
    enable_uniprot: bool = True
    enable_dandi: bool = True
    enable_allen: bool = True
    enable_opentargets: bool = True
    enable_neuromorpho: bool = True
    enable_cache: bool = True
    ncbi_api_key: str = ""


# ────────────────────────── Search Plan ────────────────────────────────

class BioSearchPlan(BaseModel):
    """Structured search plan produced by the plan agent."""
    intent: SearchIntent = SearchIntent.GENERAL
    gene_symbols: list[str] = Field(default_factory=list,
                                    description="Gene symbols to look up (e.g. ['BDNF', 'NTRK2'])")
    mesh_terms: list[str] = Field(default_factory=list,
                                  description="Plain terms to resolve via MeSH API")
    pubmed_queries: list[str] = Field(default_factory=list, min_length=1,
                                      description="1-3 PubMed search strings")
    search_biorxiv: bool = Field(default=False)
    biorxiv_queries: list[str] = Field(default_factory=list)
    dandi_search_terms: list[str] = Field(default_factory=list,
                                          description="Terms for DANDI archive search")
    brain_regions: list[str] = Field(default_factory=list,
                                     description="Relevant brain regions")
    neurotransmitter_system: str = Field(default="",
                                         description="Primary neurotransmitter system, if any")
    explanation: str = Field(default="",
                              description="Why this strategy was chosen")
    is_followup: bool = Field(default=False,
                               description="Is this a follow-up to a prior conversation?")

    model_config = {
        "json_schema_extra": {
            "example": {
                "intent": "explain_gene",
                "gene_symbols": ["BDNF"],
                "mesh_terms": ["Brain-Derived Neurotrophic Factor", "Neuroplasticity"],
                "pubmed_queries": [
                    "BDNF[MeSH Terms] AND neuroplasticity[MeSH Terms] AND Review[Publication Type]",
                    "BDNF TrkB signaling hippocampus[All Fields]",
                ],
                "search_biorxiv": True,
                "biorxiv_queries": ["BDNF TrkB"],
                "dandi_search_terms": ["hippocampus electrophysiology"],
                "brain_regions": ["hippocampus", "prefrontal cortex", "amygdala"],
                "neurotransmitter_system": "glutamatergic",
                "explanation": "BDNF is a neurotrophic factor; review articles plus recent preprints",
                "is_followup": False,
            }
        }
    }


# ────────────────────────── Article ────────────────────────────────────

class BioArticle(BaseModel):
    """A single retrieved article/preprint."""
    pmid: str
    title: str = ""
    abstract: str = ""
    authors: str = ""
    journal: str = ""
    year: str = ""
    doi: str = ""
    pmc_id: str = ""
    mesh_terms: list[str] = Field(default_factory=list)
    keywords: list[str] = Field(default_factory=list)
    source: str = ""          # pubmed_search | related_N | biorxiv | mutation_search
    full_text: str = ""

    @property
    def citation(self) -> str:
        base = f"{self.authors} ({self.year}). {self.title}. {self.journal}."
        return f"{base} https://doi.org/{self.doi}" if self.doi else base

    def to_context_block(self, index: int) -> str:
        """Format for LLM context window."""
        block = (
            f"[{index}] PMID:{self.pmid} | {self.source}\n"
            f"Title: {self.title}\n"
            f"Authors: {self.authors} ({self.year}) {self.journal}\n"
            f"DOI: {self.doi}\n"
            f"Abstract: {self.abstract[:800]}\n"
            f"MeSH: {', '.join(self.mesh_terms[:8])}"
        )
        if self.full_text:
            block += f"\nExcerpt: {self.full_text[:400]}"
        return block


# ────────────────────────── Evidence ───────────────────────────────────

class EvidenceSpan(BaseModel):
    """A grounded evidence quote linked to a source article."""
    text: str
    paper_pmid: str
    paper_title: str = ""
    section: str = ""         # abstract | results | discussion | full_text
    relevance_score: float = Field(default=0.0, ge=0.0, le=1.0)
    claim: str = ""           # brief label for the claim this supports
    doi: str = ""
    direction: EvidenceDirection = EvidenceDirection.SUPPORTS


# ── Structured evidence for agent output ───────────────────────────────

class EvidenceItem(BaseModel):
    """Single evidence item extracted by the agent."""
    quote: str = Field(description="Exact or close paraphrase from the article")
    section: str = Field(default="abstract", description="abstract|methods|results|discussion")
    relevance: float = Field(default=0.5, ge=0.0, le=1.0)
    claim: str = Field(default="", description="Brief label for the claim")
    is_quantitative: bool = Field(default=False)


class ArticleEvidence(BaseModel):
    pmid: str
    evidence: list[EvidenceItem] = Field(default_factory=list)


class BatchEvidenceExtraction(BaseModel):
    articles: list[ArticleEvidence] = Field(default_factory=list)


# ────────────────────────── Gene / Protein ─────────────────────────────

class BrainRegionRole(BaseModel):
    region: str
    role: str


class NeuralCircuit(BaseModel):
    circuit: str
    description: str


class KeyMutation(BaseModel):
    name: str = ""
    position: str = ""
    change: str = ""
    frequency: str = ""
    cancer_types: list[str] = Field(default_factory=list)
    drugs: list[str] = Field(default_factory=list)
    clinical_significance: str = ""
    description: str = ""


class ClinicalTrial(BaseModel):
    title: str = ""
    drug: str = ""
    phase: str = ""
    cancer_type: str = ""
    result_summary: str = ""
    doi: str = ""


class BioDrug(BaseModel):
    name: str = ""
    mechanism: str = ""
    approved_for: str = ""


class DomainExplanation(BaseModel):
    name: str
    explanation: str


class DiseaseExplanation(BaseModel):
    name: str
    explanation: str


class FriendlyProfile(BaseModel):
    """Human-friendly gene/protein profile produced by the profile agent."""
    gene_id_explained: str = ""
    symbol_explained: str = ""
    full_name_explained: str = ""
    summary_explained: str = ""
    accession_explained: str = ""
    protein_name_explained: str = ""
    function_explained: str = ""
    domains_explained: list[DomainExplanation] = Field(default_factory=list)
    location_explained: str = ""
    diseases_explained: list[DiseaseExplanation] = Field(default_factory=list)
    analogy: str = ""
    brain_function: str = ""
    neurotransmitter_system: str = ""
    brain_regions: list[BrainRegionRole] = Field(default_factory=list)
    neural_circuits: list[NeuralCircuit] = Field(default_factory=list)
    behavioral_roles: list[str] = Field(default_factory=list)
    clinical_relevance: str = ""
    key_mutations: list[KeyMutation] = Field(default_factory=list)
    clinical_trials: list[ClinicalTrial] = Field(default_factory=list)
    how_to_use: list[str] = Field(default_factory=list)
    neuro_drugs: list[BioDrug] = Field(default_factory=list)


# ────────────────────────── Main Result ────────────────────────────────

class BioSynthesisResult(BaseModel):
    """Full output of a synthesis run."""
    query: str
    plan: BioSearchPlan
    gene_info: dict = Field(default_factory=dict)
    articles: list[BioArticle] = Field(default_factory=list)
    related_map: dict[str, list[str]] = Field(default_factory=dict)
    synthesis_text: str = ""
    timestamp: str = Field(default_factory=lambda: datetime.now().isoformat())
    interactions: list[dict] = Field(default_factory=list)
    uniprot_data: dict = Field(default_factory=dict)
    cross_db: dict = Field(default_factory=dict)
    evidence: list[EvidenceSpan] = Field(default_factory=list)
    friendly: Optional[FriendlyProfile] = None
    neuro_data: dict = Field(default_factory=dict)       # Allen, NeuroMorpho, OpenTargets
    dandi_datasets: list[dict] = Field(default_factory=list)

    @property
    def included_count(self) -> int:
        return len(self.articles)

    @property
    def primary_gene(self) -> str:
        return self.plan.gene_symbols[0] if self.plan.gene_symbols else ""

    def summary_dict(self) -> dict:
        return {
            "query": self.query,
            "timestamp": self.timestamp,
            "article_count": len(self.articles),
            "evidence_spans": len(self.evidence),
            "primary_gene": self.primary_gene,
            "dandi_datasets": len(self.dandi_datasets),
            "has_friendly_profile": self.friendly is not None,
        }
