# BioSynthAI

BioSynthAI is a multi-agent platform for neuroscience and biomedical knowledge synthesis.

It integrates diverse biomedical databases and literature sources to automatically
retrieve, analyze, and synthesize scientific knowledge across domains. BioSynthAI aims to support research, discovery, and hypothesis generation by combining
structured data, publications, and biological knowledge into unified insights.

Key Features:
- Multi-agent architecture for modular and scalable analysis
- Live integration with biomedical databases (PubMed, Gene, UniProt, STRING, and more)
- Automated literature retrieval and synthesis
- Knowledge graph construction and enrichment
- Support for neuroscience and broader biomedical research workflows
- Local caching and conversation-aware memory

**Note:** Still in active development.
## Databases integrated

| Database | What it provides |
|---|---|
| PubMed / PMC | Literature + full text |
| NCBI Gene | Gene info, GO terms, RefSeq |
| NLM MeSH API | Dynamic MeSH term resolution |
| bioRxiv | Recent preprints |
| STRING | Protein interactions + pathway enrichment |
| UniProt | Protein function, domains, diseases |
| Open Targets | Drug-target-disease associations |
| DANDI Archive | Neurophysiology datasets (NWB) |
| Allen Brain Atlas | Brain region gene expression |
| NeuroMorpho.Org | Neuron morphology reconstructions |
| ClinVar | Variant counts |

## Installation

### From PyPI

```bash
pip install biosynthai
```

### From source (development)

```bash
git clone https://github.com/tekrajchhetri/biosynthai.git
cd biosynthai
pip install -e .
```

## Usage

### CLI (after `pip install`)

```bash
biosynthai "What does BDNF do in the hippocampus?"

# Pass API key directly (no .env needed)
biosynthai "BDNF hippocampus" --api-key sk-or-v1-...

# With NCBI key for higher PubMed rate limits
biosynthai "BDNF hippocampus" --api-key sk-or-v1-... --ncbi-key abc123

# Specify model
biosynthai "SNCA in Parkinson's disease" --model google/gemini-2.5-flash

# More results, deeper related-article expansion
biosynthai "hippocampus theta oscillations" --max-results 20 --depth 2

# Skip some databases
biosynthai "MAPT tau aggregation" --no-dandi --no-neuromorpho

# Export specific format
biosynthai "dopamine reward circuits" --format json --output results/

# Version
biosynthai --version
```

You can also run via `python -m biosynthai "..."` or `python main.py "..."` from the repo root.

### Python API

```python
import asyncio
from biosynthai import BioSynthesizer, BioSearchQuery

synth = BioSynthesizer(api_key="sk-or-v1-...")
query = BioSearchQuery(question="What does BDNF do in the hippocampus?")
result = await synth.run(query)

print(result.synthesis_text)
print(f"Articles: {len(result.articles)}")
print(f"DANDI datasets: {len(result.dandi_datasets)}")
```

## Environment variables

| Variable | Required | Description |
|---|---|---|
| `OPENROUTER_API_KEY` | **Yes** | Get one at [openrouter.ai/keys](https://openrouter.ai/keys) |
| `NCBI_API_KEY` | No | Raises PubMed rate limit 3 → 10 req/s |

All keys can also be passed via CLI flags (`--api-key`, `--ncbi-key`), which take priority over environment variables.

## Changing the model

Any model available on OpenRouter works:

```bash
biosynthai "BDNF" --model anthropic/claude-sonnet-4       # default
biosynthai "BDNF" --model anthropic/claude-haiku-4        # faster/cheaper
biosynthai "BDNF" --model google/gemini-2.5-pro
biosynthai "BDNF" --model openai/gpt-4o
biosynthai "BDNF" --model deepseek/deepseek-chat
```

## Package structure

```
biosynthai/
├── __init__.py      # Public API
├── models.py        # Pydantic v2 models
├── agents.py        # pydantic-ai agents (search plan, synthesis, profile)
├── clients.py       # All database clients (PubMed, STRING, DANDI …)
├── pipeline.py      # BioSynthesizer orchestrator
├── evidence.py      # Heuristic evidence extraction
├── export.py        # Markdown / JSON / BibTeX export
├── main.py          # CLI entry point (biosynthai command)
└── __main__.py      # python -m biosynthai support
```

## pydantic-ai agents

| Agent | Output type | Purpose |
|---|---|---|
| `search_plan_agent` | `BioSearchPlan` | Generates structured search strategy |
| `synthesis_agent` | `str` | Grounded narrative synthesis |
| `evidence_extraction_agent` | `BatchEvidenceExtraction` | Extracts evidence spans |
| `friendly_profile_agent` | `FriendlyProfile` | Human-friendly gene profile |

All agents use `defer_model_check=True` so the model is injected at runtime, making FastAPI integration straightforward.

## License

Apache 2.0 — © 2026 Tek Raj Chhetri
