"""Exception hierarchy for the IntelliDoc SDK."""


class IntelliDocError(Exception):
    """Base exception for all SDK errors."""


class AuthenticationError(IntelliDocError):
    """Raised when the API key is invalid or missing (HTTP 401/403)."""


class ValidationError(IntelliDocError):
    """Raised when IntelliDoc rejects the request (HTTP 400/422).

    Also raised by the SDK before any HTTP call when an input to
    ``extract()`` has an unsupported type or a base64 dict is missing
    the ``filename`` or ``data`` field.
    """


class ExtractionError(IntelliDocError):
    """Raised when document extraction fails (FAILURE status)."""


class ExtractionTimeoutError(IntelliDocError):
    """Raised when polling exceeds the configured timeout."""


class ServiceUnavailableError(IntelliDocError):
    """Raised when the IntelliDoc service is unreachable."""
