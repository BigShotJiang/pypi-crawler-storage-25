"""Internal data models for the IntelliDoc SDK.

This module is NOT part of the public API. It holds models used only
within the SDK implementation. Public-facing models live in
:mod:`intellidoc_sdk.entities`.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal


@dataclass
class DocumentInfo:
    """Internal handle for a document submitted to IntelliDoc.

    Attributes:
        id: Unique identifier assigned by IntelliDoc.
        filename: Original filename of the submitted document.
    """

    id: str
    filename: str


@dataclass(frozen=True)
class _NormalizedItem:
    """Normalized representation of an extract() input ready for upload.

    The SDK accepts heterogeneous inputs (paths, ``Path`` objects, base64
    dicts) and converts each one into this canonical form before posting.
    The ``kind`` decides which multipart field carries the payload on the
    wire: ``files`` for disk binaries, ``base64`` for ASCII-encoded text.

    Attributes:
        kind: ``"file"`` for raw bytes, ``"base64"`` for ASCII base64 text.
        filename: Filename to attach in the multipart part header.
        content: Raw bytes (when kind=``file``) or ASCII bytes of the
            base64 string (when kind=``base64``).
    """

    kind: Literal["file", "base64"]
    filename: str
    content: bytes
