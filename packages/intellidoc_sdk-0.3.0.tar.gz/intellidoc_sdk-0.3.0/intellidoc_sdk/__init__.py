"""IntelliDoc SDK."""

from intellidoc_sdk.client import IntelliDocClient
from intellidoc_sdk.entities import DocumentResult, ExtractionMethod, PageResult
from intellidoc_sdk.exceptions import (
    AuthenticationError,
    ExtractionError,
    ExtractionTimeoutError,
    IntelliDocError,
    ServiceUnavailableError,
    ValidationError,
)

__all__ = [
    "IntelliDocClient",
    "DocumentResult",
    "ExtractionMethod",
    "PageResult",
    "AuthenticationError",
    "ExtractionError",
    "ExtractionTimeoutError",
    "IntelliDocError",
    "ServiceUnavailableError",
    "ValidationError",
]
