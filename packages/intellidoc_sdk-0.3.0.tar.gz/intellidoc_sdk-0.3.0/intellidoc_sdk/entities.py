"""Public data models for the IntelliDoc SDK."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from enum import Enum
from typing import Any


class ExtractionMethod(str, Enum):
    """Method used to extract text from a document.

    Mirrors the API server's enum nominally. The SDK does NOT
    import from the server — values are duplicated here so the SDK
    repository stays independent.

    The ``UNKNOWN`` member is a fallback used when the server returns a
    value this SDK version does not recognize (e.g. a new extraction
    method shipped on the server before the SDK was updated). Clients
    can detect this case explicitly::

        if page.extraction_method is ExtractionMethod.UNKNOWN:
            logger.warning("Unknown extraction method — consider upgrading the SDK")
    """

    PDF_NATIVE = "pdf_native"
    OCR_AZURE = "ocr_azure"
    HTML_PARSER = "html_parser"
    XML_PARSER = "xml_parser"
    TEXT_DECODE = "text_decode"
    DOCX_PARSER = "docx_parser"
    SPREADSHEET_PARSER = "spreadsheet_parser"
    UNKNOWN = "unknown"


def _parse_extraction_method(value: str | None) -> ExtractionMethod:
    """Convert a raw API value to ExtractionMethod, falling back to UNKNOWN.

    Args:
        value: String coming from the server response (e.g. ``"pdf_native"``).
            ``None`` is allowed and maps to ``UNKNOWN``.

    Returns:
        The matching ``ExtractionMethod`` member, or ``ExtractionMethod.UNKNOWN``
        if the value is ``None`` or does not match any known method.
    """
    if value is None:
        return ExtractionMethod.UNKNOWN
    try:
        return ExtractionMethod(value)
    except ValueError:
        return ExtractionMethod.UNKNOWN


@dataclass
class PageResult:
    """Single page result inside a DocumentResult.

    The first four fields are always populated when the page comes
    from a successful extraction. The two ``sheet_*`` fields are only
    populated when the page comes from a spreadsheet (XLSX/XLS/ODS) —
    they describe which sheet (tab) the page corresponds to. For
    documents of any other type they remain ``None``.

    Attributes:
        page_number: 1-indexed page number.
        content: Extracted text for this page.
        extraction_method: Method used to extract this page. ``UNKNOWN``
            if the server returned a value this SDK version does not
            recognize.
        quality_score: Quality score in [0.0, 1.0].
        sheet_name: Name of the sheet (spreadsheets only).
        sheet_index: 0-based index of the sheet (spreadsheets only).
    """

    page_number: int
    content: str
    extraction_method: ExtractionMethod
    quality_score: float
    sheet_name: str | None = None
    sheet_index: int | None = None


@dataclass
class DocumentResult:
    """Represents the outcome of an extraction attempt for a single document.

    Three terminal cases:

    1. **Success**: ``full_text`` filled, ``error`` is ``None``,
       ``document_id`` filled. Extraction metadata (``mime_type``,
       ``overall_quality``, ``total_pages``, ``processing_time_ms``,
       ``pages``) is populated when the server returns it.
    2. **Rejected at upload** (extension/size/content invalid):
       ``full_text`` is ``None``, ``error`` filled, ``document_id`` is
       ``None`` (server never assigned an id because the document was
       not accepted).
    3. **Failed during processing** (PDF corrupted, OCR failed, timeout):
       ``full_text`` is ``None``, ``error`` filled, ``document_id`` filled
       (the document was accepted at upload but processing did not
       complete).

    Invariant: ``full_text XOR error`` — exactly one of these fields is
    populated for any terminal result.

    On any failure path (rejection at upload, post-accept failure,
    polling timeout) the five extra metadata fields (``mime_type``,
    ``overall_quality``, ``total_pages``, ``processing_time_ms``,
    ``pages``) stay ``None`` via their defaults.

    Semantic distinction for ``pages``:

    * ``pages is None`` — extraction failed (rejected at upload, polling
      failure, timeout). No page-level information is available.
    * ``pages == []`` — extraction succeeded but the server reported zero
      pages (degenerate but valid case, e.g. an empty document).

    Attributes:
        document_id: Unique identifier of the document, or ``None`` if
            rejected at upload.
        filename: Original filename of the document.
        full_text: Extracted text content, or ``None`` on any failure.
        error: Error message, or ``None`` on success.
        mime_type: Detected MIME type of the document (e.g.
            ``"application/pdf"``), or ``None`` when unavailable.
        overall_quality: Aggregated extraction quality score in the
            ``[0.0, 1.0]`` range, or ``None`` when unavailable.
        total_pages: Number of pages processed in the document, or
            ``None`` when unavailable.
        processing_time_ms: Server-side processing time in milliseconds,
            or ``None`` when unavailable.
        pages: Per-page extraction results, or ``None`` on any failure.
            An empty list means the extraction succeeded but returned no
            pages — that's distinct from ``None`` (which means failure).
    """

    document_id: str | None
    filename: str
    full_text: str | None
    error: str | None
    mime_type: str | None = None
    overall_quality: float | None = None
    total_pages: int | None = None
    processing_time_ms: int | None = None
    pages: list[PageResult] | None = None

    def to_dict(self) -> dict[str, Any]:
        """Return the result as a plain dictionary.

        Returns:
            A dict with keys ``document_id``, ``filename``, ``full_text``,
            ``error``, ``mime_type``, ``overall_quality``, ``total_pages``,
            ``processing_time_ms`` and ``pages``.
        """
        return asdict(self)
