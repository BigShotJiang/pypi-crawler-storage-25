"""Internal polling logic for IntelliDoc document processing.

This module is NOT part of the public API. It is used internally by
:class:`~intellidoc_sdk.aio.client.IntelliDocClient` to wait for documents
to finish processing.
"""

from __future__ import annotations

import asyncio
import time
from typing import Any

import httpx

from intellidoc_sdk.exceptions import (
    AuthenticationError,
    ExtractionError,
    ExtractionTimeoutError,
    ServiceUnavailableError,
)

_TRANSIENT_STATUSES = frozenset({"PENDING", "STARTED", "RETRY"})


async def poll_until_complete(
    client: httpx.AsyncClient,
    base_url: str,
    document_id: str,
    headers: dict[str, str],
    interval: float,
    timeout: float,
) -> dict[str, Any]:
    """Poll IntelliDoc until document processing completes.

    Continuously queries the document status endpoint and returns when
    the document reaches a terminal state.

    Args:
        client: httpx async client instance.
        base_url: IntelliDoc base URL (no trailing slash).
        document_id: Document ID to poll.
        headers: Request headers (must include the API key).
        interval: Seconds to wait between consecutive polls.
        timeout: Maximum total seconds to wait before giving up.

    Returns:
        The ``result`` dict from the successful response.

    Raises:
        AuthenticationError: If the API key is invalid (HTTP 401/403).
        ExtractionError: If processing fails (``FAILURE`` status) or the
            document is not found (HTTP 404).
        ExtractionTimeoutError: If *timeout* seconds elapse without
            reaching a terminal status.
        ServiceUnavailableError: If IntelliDoc is unreachable.
    """
    url = f"{base_url}/documents/{document_id}"
    start = time.monotonic()

    while True:
        elapsed = time.monotonic() - start
        if elapsed >= timeout:
            raise ExtractionTimeoutError(
                f"Polling timed out after {timeout:.0f}s for document {document_id}"
            )

        response = await _fetch_status(client, url, headers)
        status = response.get("status", "")

        if status == "SUCCESS":
            return response["result"]

        if status == "FAILURE":
            raise ExtractionError(response.get("error", "Unknown error"))

        if status not in _TRANSIENT_STATUSES:
            raise ExtractionError(f"Unexpected status: {status}")

        await asyncio.sleep(interval)


async def _fetch_status(
    client: httpx.AsyncClient,
    url: str,
    headers: dict[str, str],
) -> dict[str, Any]:
    """Perform a single GET request to the document status endpoint.

    HTTP 5xx responses are treated as transient -- the caller will retry
    on the next polling cycle.  HTTP 401/403, HTTP 404, and connection
    failures are raised immediately.

    Args:
        client: httpx async client instance.
        url: Full URL to the document status endpoint.
        headers: Request headers.

    Returns:
        Parsed JSON response as a dict.

    Raises:
        AuthenticationError: If the API key is invalid (HTTP 401/403).
        ExtractionError: If the document is not found (HTTP 404).
        ServiceUnavailableError: If IntelliDoc is unreachable.
    """
    try:
        resp = await client.get(url, headers=headers)
    except httpx.ConnectError as exc:
        raise ServiceUnavailableError(f"Failed to connect to IntelliDoc: {exc}") from exc
    except httpx.HTTPError as exc:
        raise ServiceUnavailableError(f"HTTP error contacting IntelliDoc: {exc}") from exc

    if resp.status_code in (401, 403):
        raise AuthenticationError(f"Authentication failed (HTTP {resp.status_code}): {resp.text}")

    if resp.status_code == 404:
        raise ExtractionError("Document not found")

    if resp.status_code >= 500:
        return {"status": "RETRY"}

    resp.raise_for_status()
    return resp.json()
