"""Sync client for the IntelliDoc document extraction service.

The sync client is a thin wrapper over the async implementation in
:mod:`intellidoc_sdk.aio`. It runs the async client on a dedicated
background event loop (managed by :class:`~intellidoc_sdk._bridge._SyncBridge`)
and exposes a synchronous API to the consumer — no ``await``,
``asyncio.run`` or ``async for`` required.

Use this client from sync code (scripts, CLI, ETL, Celery workers,
notebooks). For async code (FastAPI, aiohttp), use
:class:`intellidoc_sdk.aio.IntelliDocClient` instead.
"""

from __future__ import annotations

import contextlib
from collections.abc import Iterator
from typing import TYPE_CHECKING

from intellidoc_sdk._bridge import _SyncBridge
from intellidoc_sdk.aio.client import IntelliDocClient as _AsyncClient
from intellidoc_sdk.entities import DocumentResult

if TYPE_CHECKING:
    from pathlib import Path
    from types import TracebackType


class IntelliDocClient:
    """Sync client for the IntelliDoc document extraction service.

    Usage::

        client = IntelliDocClient(url="...", api_key="...")

        # one document — returns DocumentResult directly:
        r = client.extract("a.pdf")
        print(r.full_text or r.error)

        # many documents — returns an iterator:
        for r in client.extract_batch(["a.pdf", "b.pdf"]):
            print(r.filename, r.full_text or r.error)

        client.close()

    Or as a context manager::

        with IntelliDocClient(url="...", api_key="...") as client:
            r = client.extract("a.pdf")
    """

    def __init__(self, url: str, api_key: str) -> None:
        """Initialize the IntelliDoc client.

        Args:
            url: Base URL of the IntelliDoc service.
            api_key: API key used for authentication.
        """
        self._bridge = _SyncBridge()
        self._async = self._bridge.run(_make_async_client(url, api_key))

    def extract(
        self,
        document: str | Path | dict[str, str | bytes],
    ) -> DocumentResult:
        """Extract one document and return its :class:`DocumentResult`.

        Convenience wrapper over :meth:`extract_batch` for the common
        case of a single document.

        Args:
            document: One of:

                * filesystem path (``str`` or ``Path``) — filename is
                  taken from the basename.
                * dict ``{"filename": str, "content": bytes | str}`` —
                  ``filename`` is mandatory. ``bytes`` is sent as
                  binary; ``str`` is treated as base64.

        Returns:
            A :class:`DocumentResult`. On success, ``full_text`` carries
            the extracted text and ``mime_type``, ``overall_quality``,
            ``total_pages``, ``processing_time_ms`` and ``pages`` carry
            extraction metadata. On failure, ``error`` is populated and
            all extra fields are ``None``.

        Raises:
            ValidationError: Same conditions as ``extract_batch``.
            AuthenticationError: If the API key is invalid (401/403).
            ServiceUnavailableError: If the service is unreachable.
        """
        return self._bridge.run(self._async.extract(document))

    def extract_batch(
        self,
        documents: list[str | Path | dict[str, str | bytes]],
    ) -> Iterator[DocumentResult]:
        """Upload many documents and stream their results.

        Each element may be:

        * a filesystem path (``str`` or ``Path``) — bytes are read from
          disk and the filename is taken from the basename.
        * a dict ``{"filename": str, "content": bytes | str}`` — if
          ``content`` is ``bytes`` it is sent as binary; if ``content``
          is ``str`` it is treated as a base64 string. ``filename`` is
          mandatory.

        Per-document failures are yielded as :class:`DocumentResult` with
        the ``error`` field populated; they do not interrupt iteration.

        Args:
            documents: List of paths and/or input dicts.

        Yields:
            DocumentResult for each document, in completion order. On
            success, each result carries not only ``full_text`` but also
            extraction metadata (``mime_type``, ``overall_quality``,
            ``total_pages``, ``processing_time_ms`` and per-page details
            in ``pages``). On failure, ``error`` is populated and the
            extra fields are ``None``.

        Raises:
            ValidationError: If an input has an unsupported type, a
                dict is missing required fields, or IntelliDoc rejects
                the request (HTTP 400/422).
            AuthenticationError: If the API key is invalid (401/403).
            ServiceUnavailableError: If the service is unreachable.
        """
        return self._bridge.iterate(self._async.extract_batch(documents))

    def close(self) -> None:
        """Close the HTTP client and stop the background event loop.

        Safe to call multiple times.
        """
        if self._async is not None:
            self._bridge.run(self._async.close())
            self._async = None  # type: ignore[assignment]
        self._bridge.close()

    def __enter__(self) -> IntelliDocClient:
        """Enter the context manager."""
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        """Exit the context manager and close the client."""
        self.close()

    def __del__(self) -> None:
        """Best-effort cleanup if the client was not closed explicitly."""
        with contextlib.suppress(Exception):
            self.close()


async def _make_async_client(url: str, api_key: str) -> _AsyncClient:
    """Construct the async client inside the bridge's event loop.

    ``httpx.AsyncClient`` should be created in the loop that will use it,
    which is why this helper exists.
    """
    return _AsyncClient(url=url, api_key=api_key)
