"""Internal sync→async bridge for the IntelliDoc SDK.

This module is NOT part of the public API. It is used internally by the
sync :class:`~intellidoc_sdk.client.IntelliDocClient` to drive the async
implementation transparently.

The bridge owns a background thread that runs a dedicated asyncio event
loop. Sync callers schedule coroutines or async generators on that loop
and receive results synchronously, without ever exposing asyncio to the
consumer of the SDK.
"""

from __future__ import annotations

import asyncio
import contextlib
import queue
import threading
from collections.abc import AsyncIterator, Coroutine, Iterator
from typing import Any, TypeVar

T = TypeVar("T")

_SHUTDOWN = object()


class _SyncBridge:
    """Run async code on a dedicated background event loop.

    Each :class:`_SyncBridge` owns one thread and one ``asyncio`` event
    loop. The loop runs for the lifetime of the bridge and is reused
    across calls. Closing the bridge stops the loop and joins the thread.

    The bridge is *not* re-entrant: do not call :meth:`run` or
    :meth:`iterate` from within a coroutine that is itself running on
    the bridge's loop.
    """

    def __init__(self) -> None:
        """Start the background event loop and wait until it is ready."""
        self._loop: asyncio.AbstractEventLoop = asyncio.new_event_loop()
        ready = threading.Event()
        # Pass the loop and ready flag explicitly so the thread does not
        # keep a strong reference to ``self`` (which would prevent
        # __del__ cleanup via reference counting).
        self._thread = threading.Thread(
            target=_run_loop,
            args=(self._loop, ready),
            name="intellidoc-sdk-bridge",
            daemon=True,
        )
        self._thread.start()
        ready.wait()

    def run(self, coro: Coroutine[Any, Any, T]) -> T:
        """Schedule a coroutine on the loop and block until it finishes.

        Args:
            coro: The coroutine to run on the bridge's event loop.

        Returns:
            The value returned by the coroutine.

        Raises:
            Whatever the coroutine itself raises (re-raised in the
            caller's thread).
        """
        future = asyncio.run_coroutine_threadsafe(coro, self._loop)
        return future.result()

    def iterate(self, async_gen: AsyncIterator[T]) -> Iterator[T]:
        """Bridge an async generator to a synchronous iterator.

        Items produced by *async_gen* are forwarded through a thread-safe
        queue and yielded in the caller's thread. Exceptions raised by
        the generator are re-raised here. If the caller stops consuming
        the iterator early, the underlying async generator is closed.

        Args:
            async_gen: The async generator to drain.

        Yields:
            Items from the async generator, in the order produced.
        """
        items: queue.Queue[Any] = queue.Queue()

        async def _producer() -> None:
            try:
                async for item in async_gen:
                    items.put(("item", item))
            except BaseException as exc:  # noqa: BLE001 - propagate verbatim
                items.put(("error", exc))
            else:
                items.put(("done", None))

        producer = asyncio.run_coroutine_threadsafe(_producer(), self._loop)

        try:
            while True:
                kind, value = items.get()
                if kind == "item":
                    yield value
                elif kind == "done":
                    return
                else:  # "error"
                    raise value
        except GeneratorExit:
            # Caller stopped iterating early — cancel the producer and
            # close the underlying async generator on the loop thread.
            producer.cancel()
            asyncio.run_coroutine_threadsafe(
                async_gen.aclose(), self._loop
            ).result()
            raise

    def close(self) -> None:
        """Stop the event loop and join the background thread.

        Safe to call multiple times.
        """
        if not self._loop.is_closed() and self._loop.is_running():
            self._loop.call_soon_threadsafe(self._loop.stop)
        if self._thread.is_alive():
            self._thread.join()

    def __del__(self) -> None:
        """Best-effort cleanup if the bridge was not closed explicitly."""
        with contextlib.suppress(Exception):
            self.close()


def _run_loop(loop: asyncio.AbstractEventLoop, ready: threading.Event) -> None:
    """Run *loop* forever on the calling thread, signalling *ready* on start."""
    asyncio.set_event_loop(loop)
    loop.call_soon(ready.set)
    try:
        loop.run_forever()
    finally:
        loop.close()
