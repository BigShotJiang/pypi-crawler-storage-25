"""Tests for the sync IntelliDocClient (extracts via background event loop)."""

from __future__ import annotations

from pathlib import Path

import httpx
import pytest
import respx

from intellidoc_sdk.client import IntelliDocClient
from intellidoc_sdk.entities import DocumentResult, ExtractionMethod, PageResult
from intellidoc_sdk.exceptions import (
    AuthenticationError,
    ServiceUnavailableError,
    ValidationError,
)

from .conftest import (
    API_KEY,
    BASE_URL,
    DOC_ID_1,
    DOC_ID_2,
    FAILURE_STATUS_2,
    STATUS_URL_1,
    STATUS_URL_2,
    SUCCESS_STATUS_1,
    SUCCESS_STATUS_2,
    UPLOAD_RESPONSE_SINGLE,
    UPLOAD_URL,
    make_upload_response,
)


def _make_client(
    poll_interval: float = 0.01,
    poll_timeout: float = 5.0,
    max_batch_size: int = 500,
) -> IntelliDocClient:
    """Create a sync client with fast polling for tests."""
    client = IntelliDocClient(url=BASE_URL, api_key=API_KEY)
    client._async._POLL_INTERVAL = poll_interval
    client._async._POLL_TIMEOUT = poll_timeout
    client._async._MAX_BATCH_SIZE = max_batch_size
    return client


def _create_temp_files(tmp_path: Path, filenames: list[str]) -> list[str]:
    """Create temporary files and return their paths as strings."""
    paths = []
    for name in filenames:
        file_path = tmp_path / name
        file_path.write_bytes(b"fake-content")
        paths.append(str(file_path))
    return paths


class TestExtractSingle:
    """Tests for IntelliDocClient.extract (sync, single document)."""

    @respx.mock
    def test_extract_returns_document_result_directly(self, tmp_path):
        """extract(path) returns a DocumentResult, not an iterator."""
        respx.post(UPLOAD_URL).respond(207, json=UPLOAD_RESPONSE_SINGLE)
        respx.get(STATUS_URL_1).respond(200, json=SUCCESS_STATUS_1)
        pdf = tmp_path / "contrato.pdf"
        pdf.write_bytes(b"%PDF-mock")

        with _make_client() as client:
            result = client.extract(str(pdf))

        assert isinstance(result, DocumentResult)
        assert result.document_id == DOC_ID_1
        assert result.filename == "contrato.pdf"
        assert result.full_text is not None
        assert result.error is None

    @respx.mock
    def test_extract_exposes_mime_type_and_quality_metadata(self, tmp_path):
        """Sync extract surfaces mime_type, quality and timing metadata."""
        respx.post(UPLOAD_URL).respond(207, json=UPLOAD_RESPONSE_SINGLE)
        respx.get(STATUS_URL_1).respond(200, json=SUCCESS_STATUS_1)
        pdf = tmp_path / "contrato.pdf"
        pdf.write_bytes(b"%PDF-mock")

        with _make_client() as client:
            result = client.extract(str(pdf))

        assert result.mime_type == "application/pdf"
        assert result.overall_quality == 0.95
        assert result.total_pages == 1
        assert result.processing_time_ms == 1500

    @respx.mock
    def test_extract_exposes_pages_with_extraction_method(self, tmp_path):
        """Sync extract surfaces a list of typed PageResult instances."""
        respx.post(UPLOAD_URL).respond(207, json=UPLOAD_RESPONSE_SINGLE)
        respx.get(STATUS_URL_1).respond(200, json=SUCCESS_STATUS_1)
        pdf = tmp_path / "contrato.pdf"
        pdf.write_bytes(b"%PDF-mock")

        with _make_client() as client:
            result = client.extract(str(pdf))

        assert result.pages is not None
        assert len(result.pages) == 1
        assert isinstance(result.pages[0], PageResult)
        assert result.pages[0].page_number == 1
        assert result.pages[0].content == "Texto extraido"
        assert result.pages[0].extraction_method is ExtractionMethod.PDF_NATIVE
        assert result.pages[0].quality_score == 0.95
        assert result.pages[0].sheet_name is None
        assert result.pages[0].sheet_index is None


class TestExtractBatch:
    """Tests for IntelliDocClient.extract_batch (sync, many documents)."""

    @respx.mock
    def test_extract_single_file(self, tmp_path):
        """extract_batch with 1 file yields 1 successful DocumentResult."""
        respx.post(UPLOAD_URL).respond(207, json=UPLOAD_RESPONSE_SINGLE)
        respx.get(STATUS_URL_1).respond(200, json=SUCCESS_STATUS_1)
        paths = _create_temp_files(tmp_path, ["contrato.pdf"])

        client = _make_client()
        try:
            results = list(client.extract_batch(paths))
        finally:
            client.close()

        assert len(results) == 1
        assert isinstance(results[0], DocumentResult)
        assert results[0].document_id == DOC_ID_1
        assert results[0].filename == "contrato.pdf"
        assert results[0].full_text is not None
        assert results[0].error is None

    @respx.mock
    def test_extract_multiple_files_all_success(self, tmp_path):
        """extract with 2 files yields 2 successful DocumentResult."""
        upload_response = make_upload_response(
            {"filename": "contrato.pdf", "document_id": DOC_ID_1},
            {"filename": "certidao.html", "document_id": DOC_ID_2},
        )
        respx.post(UPLOAD_URL).respond(207, json=upload_response)
        respx.get(STATUS_URL_1).respond(200, json=SUCCESS_STATUS_1)
        respx.get(STATUS_URL_2).respond(200, json=SUCCESS_STATUS_2)
        paths = _create_temp_files(tmp_path, ["contrato.pdf", "certidao.html"])

        client = _make_client()
        try:
            results = list(client.extract_batch(paths))
        finally:
            client.close()

        assert len(results) == 2
        assert {r.document_id for r in results} == {DOC_ID_1, DOC_ID_2}
        assert all(r.full_text is not None for r in results)
        assert all(r.error is None for r in results)

    @respx.mock
    def test_extract_partial_failure(self, tmp_path):
        """extract with 1 success + 1 failure yields both, error preserved."""
        upload_response = make_upload_response(
            {"filename": "contrato.pdf", "document_id": DOC_ID_1},
            {"filename": "certidao.html", "document_id": DOC_ID_2},
        )
        respx.post(UPLOAD_URL).respond(207, json=upload_response)
        respx.get(STATUS_URL_1).respond(200, json=SUCCESS_STATUS_1)
        respx.get(STATUS_URL_2).respond(200, json=FAILURE_STATUS_2)
        paths = _create_temp_files(tmp_path, ["contrato.pdf", "certidao.html"])

        client = _make_client()
        try:
            results = list(client.extract_batch(paths))
        finally:
            client.close()

        assert len(results) == 2

        success = next(r for r in results if r.document_id == DOC_ID_1)
        assert success.full_text is not None
        assert success.error is None

        failure = next(r for r in results if r.document_id == DOC_ID_2)
        assert failure.full_text is None
        assert failure.error == "Unsupported format"

    @respx.mock
    def test_extract_streams_one_at_a_time(self, tmp_path):
        """extract yields results before all docs are processed (streaming)."""
        upload_response = make_upload_response(
            {"filename": "contrato.pdf", "document_id": DOC_ID_1},
            {"filename": "certidao.html", "document_id": DOC_ID_2},
        )
        respx.post(UPLOAD_URL).respond(207, json=upload_response)
        respx.get(STATUS_URL_1).respond(200, json=SUCCESS_STATUS_1)
        respx.get(STATUS_URL_2).respond(200, json=SUCCESS_STATUS_2)
        paths = _create_temp_files(tmp_path, ["contrato.pdf", "certidao.html"])

        client = _make_client()
        try:
            it = client.extract_batch(paths)
            first = next(it)
            assert isinstance(first, DocumentResult)
            second = next(it)
            assert isinstance(second, DocumentResult)
            with pytest.raises(StopIteration):
                next(it)
        finally:
            client.close()

    @respx.mock
    def test_extract_auth_error_raises(self, tmp_path):
        """extract propagates AuthenticationError when upload returns 401."""
        respx.post(UPLOAD_URL).respond(401, text="Unauthorized")
        paths = _create_temp_files(tmp_path, ["contrato.pdf"])

        client = _make_client()
        try:
            with pytest.raises(AuthenticationError):
                list(client.extract_batch(paths))
        finally:
            client.close()

    @respx.mock
    def test_extract_validation_error_raises(self, tmp_path):
        """extract propagates ValidationError when upload returns 400."""
        respx.post(UPLOAD_URL).respond(400, text="Bad Request")
        paths = _create_temp_files(tmp_path, ["contrato.pdf"])

        client = _make_client()
        try:
            with pytest.raises(ValidationError):
                list(client.extract_batch(paths))
        finally:
            client.close()

    @respx.mock
    def test_extract_connection_error_raises(self, tmp_path):
        """extract propagates ServiceUnavailableError on connect failure."""
        respx.post(UPLOAD_URL).mock(
            side_effect=httpx.ConnectError("connection refused")
        )
        paths = _create_temp_files(tmp_path, ["contrato.pdf"])

        client = _make_client()
        try:
            with pytest.raises(ServiceUnavailableError):
                list(client.extract_batch(paths))
        finally:
            client.close()

    @respx.mock
    def test_extract_upload_rejection_yields_first(self, tmp_path):
        """Sync mirror: rejected file yields first, accepted siblings later."""
        upload_response = make_upload_response(
            {"filename": "good.pdf", "document_id": DOC_ID_1},
            {
                "filename": "bad.exe",
                "status": "rejected",
                "error": {
                    "type": "InvalidFileTypeError",
                    "message": "File bad.exe has unsupported extension",
                    "details": {"filename": "bad.exe", "extension": ".exe"},
                },
            },
        )
        respx.post(UPLOAD_URL).respond(207, json=upload_response)
        respx.get(STATUS_URL_1).respond(200, json=SUCCESS_STATUS_1)
        paths = _create_temp_files(tmp_path, ["good.pdf", "bad.exe"])

        client = _make_client()
        try:
            results = list(client.extract_batch(paths))
        finally:
            client.close()

        assert len(results) == 2
        assert results[0].filename == "bad.exe"
        assert results[0].document_id is None
        assert results[0].full_text is None
        assert results[0].error is not None
        assert results[1].document_id == DOC_ID_1
        assert results[1].full_text is not None

    @respx.mock
    def test_extract_all_rejected_at_upload(self, tmp_path):
        """Sync mirror: when every file is rejected, no polling is issued."""
        upload_response = make_upload_response(
            {
                "filename": "bad1.exe",
                "status": "rejected",
                "error": {
                    "type": "InvalidFileTypeError",
                    "message": "bad1.exe rejected",
                    "details": {},
                },
            },
            {
                "filename": "bad2.zip",
                "status": "rejected",
                "error": {
                    "type": "InvalidFileTypeError",
                    "message": "bad2.zip rejected",
                    "details": {},
                },
            },
        )
        respx.post(UPLOAD_URL).respond(207, json=upload_response)
        paths = _create_temp_files(tmp_path, ["bad1.exe", "bad2.zip"])

        client = _make_client()
        try:
            results = list(client.extract_batch(paths))
        finally:
            client.close()

        assert len(results) == 2
        assert all(r.document_id is None for r in results)
        assert all(r.error is not None for r in results)


class TestContextManager:
    """Tests for the sync context manager protocol."""

    @respx.mock
    def test_context_manager(self, tmp_path):
        """`with IntelliDocClient(...)` extracts and closes cleanly."""
        respx.post(UPLOAD_URL).respond(207, json=UPLOAD_RESPONSE_SINGLE)
        respx.get(STATUS_URL_1).respond(200, json=SUCCESS_STATUS_1)
        paths = _create_temp_files(tmp_path, ["contrato.pdf"])

        with _make_client() as client:
            results = list(client.extract_batch(paths))

        assert len(results) == 1
        assert results[0].full_text is not None


class TestExtractInputNormalization:
    """Sync mirrors of the polymorphic ``extract()`` input handling.

    The bridge passes inputs through unchanged to the async client, so
    these tests exercise the same normalization path as the async
    counterparts but via the sync entry point.
    """

    @respx.mock
    def test_extract_accepts_base64_dict_input_sync(self):
        """Base64 input dict works through the sync bridge."""
        respx.post(UPLOAD_URL).respond(207, json=UPLOAD_RESPONSE_SINGLE)
        respx.get(STATUS_URL_1).respond(200, json=SUCCESS_STATUS_1)

        with _make_client() as client:
            results = list(
                client.extract_batch(
                    [{"filename": "contrato.pdf", "content": "JVBERg=="}]
                )
            )

        assert len(results) == 1
        assert results[0].filename == "contrato.pdf"
        assert results[0].full_text is not None

    def test_extract_rejects_unsupported_input_type_sync(self):
        """Pre-HTTP ValidationError surfaces through the sync bridge."""
        with _make_client() as client, pytest.raises(
            ValidationError, match="Tipo não suportado"
        ):
            list(client.extract_batch([42]))  # type: ignore[list-item]
