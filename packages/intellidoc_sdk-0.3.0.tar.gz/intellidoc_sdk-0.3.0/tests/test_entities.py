"""Tests for the public DocumentResult dataclass."""

from __future__ import annotations

from intellidoc_sdk.entities import (
    DocumentResult,
    ExtractionMethod,
    PageResult,
    _parse_extraction_method,
)


class TestDocumentResult:
    """Tests for the DocumentResult dataclass."""

    def test_document_result_success(self):
        """Successful result has full_text filled and error as None."""
        result = DocumentResult(
            document_id="uuid-1",
            filename="contrato.pdf",
            full_text="Texto extraido",
            error=None,
        )

        assert result.document_id == "uuid-1"
        assert result.filename == "contrato.pdf"
        assert result.full_text == "Texto extraido"
        assert result.error is None

    def test_document_result_failure(self):
        """Failed result has full_text as None and error filled."""
        result = DocumentResult(
            document_id="uuid-2",
            filename="certidao.html",
            full_text=None,
            error="Unsupported format",
        )

        assert result.document_id == "uuid-2"
        assert result.filename == "certidao.html"
        assert result.full_text is None
        assert result.error == "Unsupported format"

    def test_to_dict_success(self):
        """to_dict returns all fields including full_text on success."""
        result = DocumentResult(
            document_id="uuid-1",
            filename="contrato.pdf",
            full_text="Texto extraido",
            error=None,
        )

        assert result.to_dict() == {
            "document_id": "uuid-1",
            "filename": "contrato.pdf",
            "full_text": "Texto extraido",
            "error": None,
            "mime_type": None,
            "overall_quality": None,
            "total_pages": None,
            "processing_time_ms": None,
            "pages": None,
        }

    def test_to_dict_failure(self):
        """to_dict returns all fields including error on failure."""
        result = DocumentResult(
            document_id="uuid-2",
            filename="bad.html",
            full_text=None,
            error="Unsupported format",
        )

        assert result.to_dict() == {
            "document_id": "uuid-2",
            "filename": "bad.html",
            "full_text": None,
            "error": "Unsupported format",
            "mime_type": None,
            "overall_quality": None,
            "total_pages": None,
            "processing_time_ms": None,
            "pages": None,
        }

    def test_document_result_includes_extraction_metadata_on_success(self):
        """Success result exposes mime_type, quality, pages and timing."""
        result = DocumentResult(
            document_id="uuid-1",
            filename="contrato.pdf",
            full_text="Texto extraido",
            error=None,
            mime_type="application/pdf",
            overall_quality=0.95,
            total_pages=3,
            processing_time_ms=1500,
        )

        assert result.document_id == "uuid-1"
        assert result.filename == "contrato.pdf"
        assert result.full_text == "Texto extraido"
        assert result.error is None
        assert result.mime_type == "application/pdf"
        assert result.overall_quality == 0.95
        assert result.total_pages == 3
        assert result.processing_time_ms == 1500

    def test_document_result_metadata_defaults_to_none_when_omitted(self):
        """Optional metadata fields default to ``None`` when not provided."""
        result = DocumentResult(
            document_id="uuid-1",
            filename="contrato.pdf",
            full_text="Texto extraido",
            error=None,
        )

        assert result.mime_type is None
        assert result.overall_quality is None
        assert result.total_pages is None
        assert result.processing_time_ms is None

    def test_to_dict_includes_new_fields_on_success(self):
        """to_dict surfaces the four metadata fields on a successful result."""
        result = DocumentResult(
            document_id="uuid-1",
            filename="contrato.pdf",
            full_text="Texto extraido",
            error=None,
            mime_type="application/pdf",
            overall_quality=0.95,
            total_pages=3,
            processing_time_ms=1500,
        )

        assert result.to_dict() == {
            "document_id": "uuid-1",
            "filename": "contrato.pdf",
            "full_text": "Texto extraido",
            "error": None,
            "mime_type": "application/pdf",
            "overall_quality": 0.95,
            "total_pages": 3,
            "processing_time_ms": 1500,
            "pages": None,
        }

    def test_document_result_pages_defaults_to_none_when_omitted(self):
        """``pages`` defaults to ``None`` when not provided at construction."""
        result = DocumentResult(
            document_id="uuid-1",
            filename="contrato.pdf",
            full_text="Texto extraido",
            error=None,
        )

        assert result.pages is None

    def test_document_result_with_pages_list(self):
        """``pages`` accepts a list of :class:`PageResult` instances."""
        page = PageResult(
            page_number=1,
            content="Texto extraido",
            extraction_method=ExtractionMethod.PDF_NATIVE,
            quality_score=0.95,
        )
        result = DocumentResult(
            document_id="uuid-1",
            filename="contrato.pdf",
            full_text="Texto extraido",
            error=None,
            pages=[page],
        )

        assert result.pages == [page]
        assert result.pages[0].page_number == 1


class TestExtractionMethod:
    """Tests for the ExtractionMethod enum and its parsing helper."""

    def test_known_value_parses_to_enum_member(self):
        """Known API string values map to the matching enum member."""
        assert _parse_extraction_method("pdf_native") is ExtractionMethod.PDF_NATIVE
        assert _parse_extraction_method("html_parser") is ExtractionMethod.HTML_PARSER
        assert (
            _parse_extraction_method("spreadsheet_parser")
            is ExtractionMethod.SPREADSHEET_PARSER
        )

    def test_unknown_value_falls_back_to_unknown_member(self):
        """An unrecognized string falls back to ExtractionMethod.UNKNOWN."""
        assert _parse_extraction_method("html_native") is ExtractionMethod.UNKNOWN

    def test_none_input_falls_back_to_unknown_member(self):
        """A ``None`` input falls back to ExtractionMethod.UNKNOWN."""
        assert _parse_extraction_method(None) is ExtractionMethod.UNKNOWN

    def test_extraction_method_is_string_enum(self):
        """ExtractionMethod members compare equal to their raw string value."""
        assert ExtractionMethod.PDF_NATIVE == "pdf_native"

    def test_extraction_method_is_publicly_exported(self):
        """ExtractionMethod is re-exported by the top-level package."""
        from intellidoc_sdk import ExtractionMethod as PublicExtractionMethod

        assert PublicExtractionMethod is ExtractionMethod


class TestPageResult:
    """Tests for the PageResult dataclass."""

    def test_page_result_basic_fields(self):
        """Required fields are stored; sheet fields default to ``None``."""
        page = PageResult(
            page_number=1,
            content="Texto extraido",
            extraction_method=ExtractionMethod.PDF_NATIVE,
            quality_score=0.95,
        )

        assert page.page_number == 1
        assert page.content == "Texto extraido"
        assert page.extraction_method is ExtractionMethod.PDF_NATIVE
        assert page.quality_score == 0.95
        assert page.sheet_name is None
        assert page.sheet_index is None

    def test_page_result_with_sheet_info(self):
        """Sheet metadata is stored when provided (spreadsheet case)."""
        page = PageResult(
            page_number=2,
            content="A1\tB1",
            extraction_method=ExtractionMethod.SPREADSHEET_PARSER,
            quality_score=0.8,
            sheet_name="Vendas",
            sheet_index=0,
        )

        assert page.sheet_name == "Vendas"
        assert page.sheet_index == 0

    def test_page_result_extraction_method_is_enum_instance(self):
        """The ``extraction_method`` field accepts an ExtractionMethod member."""
        page = PageResult(
            page_number=1,
            content="x",
            extraction_method=ExtractionMethod.PDF_NATIVE,
            quality_score=1.0,
        )

        assert isinstance(page.extraction_method, ExtractionMethod)

    def test_page_result_is_publicly_exported(self):
        """PageResult is re-exported by the top-level package."""
        from intellidoc_sdk import PageResult as PublicPageResult

        assert PublicPageResult is PageResult
