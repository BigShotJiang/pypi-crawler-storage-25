"""Tests for the async IntelliDocClient (intellidoc_sdk.aio)."""

from __future__ import annotations

from pathlib import Path

import httpx
import pytest
import respx

from intellidoc_sdk.aio.client import IntelliDocClient
from intellidoc_sdk.entities import DocumentResult, ExtractionMethod, PageResult
from intellidoc_sdk.exceptions import (
    AuthenticationError,
    ServiceUnavailableError,
    ValidationError,
)

from .conftest import (
    API_KEY,
    BASE_URL,
    DOC_ID_1,
    DOC_ID_2,
    DOC_ID_3,
    DOC_ID_4,
    FAILURE_STATUS_2,
    PENDING_STATUS,
    STATUS_URL_1,
    STATUS_URL_2,
    SUCCESS_STATUS_1,
    SUCCESS_STATUS_2,
    UPLOAD_RESPONSE_MIXED_PARTIAL,
    UPLOAD_RESPONSE_SINGLE,
    UPLOAD_URL,
    make_upload_response,
)


def _make_client(
    poll_interval: float = 0.01,
    poll_timeout: float = 5.0,
    max_batch_size: int = 500,
) -> IntelliDocClient:
    """Create a client with fast polling for tests."""
    client = IntelliDocClient(url=BASE_URL, api_key=API_KEY)
    client._POLL_INTERVAL = poll_interval
    client._POLL_TIMEOUT = poll_timeout
    client._MAX_BATCH_SIZE = max_batch_size
    return client


def _create_temp_files(tmp_path: Path, filenames: list[str]) -> list[str]:
    """Create temporary files and return their paths as strings."""
    paths = []
    for name in filenames:
        file_path = tmp_path / name
        file_path.write_bytes(b"fake-content")
        paths.append(str(file_path))
    return paths


class TestExtractSingle:
    """Tests for IntelliDocClient.extract (async, single document)."""

    @respx.mock
    async def test_extract_returns_document_result_directly(self, tmp_path):
        """extract(path) returns a DocumentResult, not an iterator."""
        respx.post(UPLOAD_URL).respond(207, json=UPLOAD_RESPONSE_SINGLE)
        respx.get(STATUS_URL_1).respond(200, json=SUCCESS_STATUS_1)
        pdf = tmp_path / "contrato.pdf"
        pdf.write_bytes(b"%PDF-mock")

        client = _make_client()
        result = await client.extract(str(pdf))
        await client.close()

        assert isinstance(result, DocumentResult)
        assert result.document_id == DOC_ID_1
        assert result.filename == "contrato.pdf"
        assert result.full_text is not None
        assert result.error is None

    @respx.mock
    async def test_extract_with_dict_returns_document_result_directly(self):
        """extract(dict) also returns a DocumentResult directly."""
        respx.post(UPLOAD_URL).respond(207, json=UPLOAD_RESPONSE_SINGLE)
        respx.get(STATUS_URL_1).respond(200, json=SUCCESS_STATUS_1)

        client = _make_client()
        result = await client.extract(
            {"filename": "contrato.pdf", "content": b"%PDF-mock"}
        )
        await client.close()

        assert isinstance(result, DocumentResult)
        assert result.filename == "contrato.pdf"

    @respx.mock
    async def test_extract_exposes_mime_type_and_quality_metadata(
        self, tmp_path
    ):
        """Successful extract surfaces mime_type, quality and timing metadata."""
        respx.post(UPLOAD_URL).respond(207, json=UPLOAD_RESPONSE_SINGLE)
        respx.get(STATUS_URL_1).respond(200, json=SUCCESS_STATUS_1)
        pdf = tmp_path / "contrato.pdf"
        pdf.write_bytes(b"%PDF-mock")

        client = _make_client()
        result = await client.extract(str(pdf))
        await client.close()

        assert result.mime_type == "application/pdf"
        assert result.overall_quality == 0.95
        assert result.total_pages == 1
        assert result.processing_time_ms == 1500

    @respx.mock
    async def test_extract_exposes_pages_with_extraction_method(self, tmp_path):
        """Successful extract surfaces a list of typed PageResult instances."""
        respx.post(UPLOAD_URL).respond(207, json=UPLOAD_RESPONSE_SINGLE)
        respx.get(STATUS_URL_1).respond(200, json=SUCCESS_STATUS_1)
        pdf = tmp_path / "contrato.pdf"
        pdf.write_bytes(b"%PDF-mock")

        client = _make_client()
        result = await client.extract(str(pdf))
        await client.close()

        assert result.pages is not None
        assert len(result.pages) == 1
        assert isinstance(result.pages[0], PageResult)
        assert result.pages[0].page_number == 1
        assert result.pages[0].content == "Texto extraido"
        assert result.pages[0].extraction_method is ExtractionMethod.PDF_NATIVE
        assert result.pages[0].quality_score == 0.95
        assert result.pages[0].sheet_name is None
        assert result.pages[0].sheet_index is None

    @respx.mock
    async def test_extract_unknown_extraction_method_falls_back_to_unknown(
        self, tmp_path
    ):
        """An unrecognized extraction_method maps to ExtractionMethod.UNKNOWN."""
        upload_response = make_upload_response(
            {"filename": "certidao.html", "document_id": DOC_ID_2},
        )
        respx.post(UPLOAD_URL).respond(207, json=upload_response)
        respx.get(STATUS_URL_2).respond(200, json=SUCCESS_STATUS_2)
        html = tmp_path / "certidao.html"
        html.write_bytes(b"<html/>")

        client = _make_client()
        result = await client.extract(str(html))
        await client.close()

        assert result.pages is not None
        assert len(result.pages) == 1
        assert result.pages[0].extraction_method is ExtractionMethod.UNKNOWN

    @respx.mock
    async def test_extract_with_empty_pages_array(self, tmp_path):
        """An empty ``pages`` array yields ``r.pages == []``, not ``None``."""
        status_with_empty_pages = {
            "task_id": DOC_ID_1,
            "status": "SUCCESS",
            "result": {
                "document_id": DOC_ID_1,
                "full_text": "Texto extraido",
                "mime_type": "application/pdf",
                "overall_quality": 0.95,
                "total_pages": 0,
                "processing_time_ms": 1500,
                "pages": [],
                "metadata": {},
            },
        }
        respx.post(UPLOAD_URL).respond(207, json=UPLOAD_RESPONSE_SINGLE)
        respx.get(STATUS_URL_1).respond(200, json=status_with_empty_pages)
        pdf = tmp_path / "contrato.pdf"
        pdf.write_bytes(b"%PDF-mock")

        client = _make_client()
        result = await client.extract(str(pdf))
        await client.close()

        assert result.pages == []
        assert result.pages is not None

    @respx.mock
    async def test_extract_rejected_upload_has_pages_and_metadata_none(
        self, tmp_path
    ):
        """A document rejected at upload has all metadata fields ``None``."""
        upload_response = make_upload_response(
            {
                "filename": "bad.exe",
                "status": "rejected",
                "error": {
                    "type": "InvalidFileTypeError",
                    "message": "File bad.exe has unsupported extension",
                    "details": {"filename": "bad.exe", "extension": ".exe"},
                },
            },
        )
        respx.post(UPLOAD_URL).respond(207, json=upload_response)
        paths = _create_temp_files(tmp_path, ["bad.exe"])

        client = _make_client()
        results = [r async for r in client.extract_batch(paths)]
        await client.close()

        assert len(results) == 1
        r = results[0]
        assert r.document_id is None
        assert r.mime_type is None
        assert r.overall_quality is None
        assert r.total_pages is None
        assert r.processing_time_ms is None
        assert r.pages is None
        assert r.error is not None
        assert r.full_text is None

    @respx.mock
    async def test_extract_polling_failure_has_pages_and_metadata_none(
        self, tmp_path
    ):
        """A document that fails during polling has all metadata fields ``None``."""
        upload_response = make_upload_response(
            {"filename": "certidao.html", "document_id": DOC_ID_2},
        )
        respx.post(UPLOAD_URL).respond(207, json=upload_response)
        respx.get(STATUS_URL_2).respond(200, json=FAILURE_STATUS_2)
        paths = _create_temp_files(tmp_path, ["certidao.html"])

        client = _make_client()
        results = [r async for r in client.extract_batch(paths)]
        await client.close()

        assert len(results) == 1
        r = results[0]
        assert r.mime_type is None
        assert r.overall_quality is None
        assert r.total_pages is None
        assert r.processing_time_ms is None
        assert r.pages is None
        assert r.error is not None
        assert r.full_text is None

    @respx.mock
    async def test_extract_polling_timeout_has_pages_and_metadata_none(
        self, tmp_path
    ):
        """A document stuck in PENDING (timeout) has all metadata fields ``None``."""
        respx.post(UPLOAD_URL).respond(207, json=UPLOAD_RESPONSE_SINGLE)
        respx.get(STATUS_URL_1).respond(200, json=PENDING_STATUS)
        paths = _create_temp_files(tmp_path, ["contrato.pdf"])

        client = _make_client(poll_timeout=0.05)
        results = [r async for r in client.extract_batch(paths)]
        await client.close()

        assert len(results) == 1
        r = results[0]
        assert r.mime_type is None
        assert r.overall_quality is None
        assert r.total_pages is None
        assert r.processing_time_ms is None
        assert r.pages is None
        assert r.error is not None
        assert r.full_text is None


class TestExtractBatch:
    """Tests for IntelliDocClient.extract_batch (async, many documents)."""

    @respx.mock
    async def test_extract_single_file(self, tmp_path):
        """extract_batch with 1 file yields 1 successful DocumentResult."""
        respx.post(UPLOAD_URL).respond(207, json=UPLOAD_RESPONSE_SINGLE)
        respx.get(STATUS_URL_1).respond(200, json=SUCCESS_STATUS_1)
        paths = _create_temp_files(tmp_path, ["contrato.pdf"])

        client = _make_client()
        results = []
        async for result in client.extract_batch(paths):
            results.append(result)
        await client.close()

        assert len(results) == 1
        assert isinstance(results[0], DocumentResult)
        assert results[0].document_id == DOC_ID_1
        assert results[0].filename == "contrato.pdf"
        assert results[0].full_text is not None
        assert results[0].error is None

    @respx.mock
    async def test_extract_multiple_files_all_success(self, tmp_path):
        """extract with 2 files yields 2 successful DocumentResult."""
        upload_response = make_upload_response(
            {"filename": "contrato.pdf", "document_id": DOC_ID_1},
            {"filename": "certidao.html", "document_id": DOC_ID_2},
        )
        respx.post(UPLOAD_URL).respond(207, json=upload_response)
        respx.get(STATUS_URL_1).respond(200, json=SUCCESS_STATUS_1)
        respx.get(STATUS_URL_2).respond(200, json=SUCCESS_STATUS_2)
        paths = _create_temp_files(tmp_path, ["contrato.pdf", "certidao.html"])

        client = _make_client()
        results = []
        async for result in client.extract_batch(paths):
            results.append(result)
        await client.close()

        assert len(results) == 2
        assert {r.document_id for r in results} == {DOC_ID_1, DOC_ID_2}
        assert all(r.full_text is not None for r in results)
        assert all(r.error is None for r in results)

    @respx.mock
    async def test_extract_partial_failure(self, tmp_path):
        """extract with 1 success + 1 failure yields both, error preserved."""
        upload_response = make_upload_response(
            {"filename": "contrato.pdf", "document_id": DOC_ID_1},
            {"filename": "certidao.html", "document_id": DOC_ID_2},
        )
        respx.post(UPLOAD_URL).respond(207, json=upload_response)
        respx.get(STATUS_URL_1).respond(200, json=SUCCESS_STATUS_1)
        respx.get(STATUS_URL_2).respond(200, json=FAILURE_STATUS_2)
        paths = _create_temp_files(tmp_path, ["contrato.pdf", "certidao.html"])

        client = _make_client()
        results = []
        async for result in client.extract_batch(paths):
            results.append(result)
        await client.close()

        assert len(results) == 2

        success = next(r for r in results if r.document_id == DOC_ID_1)
        assert success.full_text is not None
        assert success.error is None

        failure = next(r for r in results if r.document_id == DOC_ID_2)
        assert failure.full_text is None
        assert failure.error == "Unsupported format"

    @respx.mock
    async def test_extract_batch_splitting(self, tmp_path):
        """extract with 1200 files splits into 3 POST calls and yields 1200 results."""
        upload_route = respx.post(UPLOAD_URL)
        batch_responses = []
        for batch_start in (0, 500, 1000):
            batch_size = min(500, 1200 - batch_start)
            payload = make_upload_response(*[
                {
                    "filename": f"f{batch_start + i}.pdf",
                    "document_id": f"id-{batch_start + i}",
                }
                for i in range(batch_size)
            ])
            batch_responses.append(httpx.Response(207, json=payload))
        upload_route.side_effect = batch_responses

        for i in range(1200):
            respx.get(f"{BASE_URL}/documents/id-{i}").respond(
                200,
                json={
                    "task_id": f"id-{i}",
                    "status": "SUCCESS",
                    "result": {
                        "document_id": f"id-{i}",
                        "full_text": f"text-{i}",
                        "mime_type": "application/pdf",
                        "overall_quality": 1.0,
                        "total_pages": 1,
                        "processing_time_ms": 10,
                        "pages": [],
                        "metadata": {},
                    },
                },
            )

        filenames = [f"f{i}.pdf" for i in range(1200)]
        paths = _create_temp_files(tmp_path, filenames)

        client = _make_client(max_batch_size=500)
        results = []
        async for result in client.extract_batch(paths):
            results.append(result)
        await client.close()

        assert upload_route.call_count == 3
        assert len(results) == 1200

    @respx.mock
    async def test_extract_upload_rejection_yields_first(self, tmp_path):
        """File rejected at upload (e.g. .exe) yields immediately as result.error.

        Order matters: the rejected file must be yielded BEFORE the
        accepted siblings, since we know about the rejection right after
        the POST returns and before any polling starts.
        """
        upload_response = make_upload_response(
            {"filename": "good.pdf", "document_id": DOC_ID_1},
            {
                "filename": "bad.exe",
                "status": "rejected",
                "error": {
                    "type": "InvalidFileTypeError",
                    "message": "File bad.exe has unsupported extension",
                    "details": {"filename": "bad.exe", "extension": ".exe"},
                },
            },
        )
        respx.post(UPLOAD_URL).respond(207, json=upload_response)
        respx.get(STATUS_URL_1).respond(200, json=SUCCESS_STATUS_1)
        paths = _create_temp_files(tmp_path, ["good.pdf", "bad.exe"])

        client = _make_client()
        results = []
        async for result in client.extract_batch(paths):
            results.append(result)
        await client.close()

        assert len(results) == 2

        # Rejected comes first (no polling needed)
        assert results[0].filename == "bad.exe"
        assert results[0].document_id is None
        assert results[0].full_text is None
        assert "unsupported extension" in results[0].error

        # Accepted comes after polling
        assert results[1].filename == "good.pdf"
        assert results[1].document_id == DOC_ID_1
        assert results[1].full_text is not None
        assert results[1].error is None

    @respx.mock
    async def test_extract_all_rejected_at_upload_skips_polling(self, tmp_path):
        """When every file is rejected, no polling request is issued."""
        upload_response = make_upload_response(
            {
                "filename": "bad1.exe",
                "status": "rejected",
                "error": {
                    "type": "InvalidFileTypeError",
                    "message": "bad1.exe rejected",
                    "details": {},
                },
            },
            {
                "filename": "bad2.zip",
                "status": "rejected",
                "error": {
                    "type": "InvalidFileTypeError",
                    "message": "bad2.zip rejected",
                    "details": {},
                },
            },
        )
        respx.post(UPLOAD_URL).respond(207, json=upload_response)
        # No status route registered — if extract polls anything, the test fails
        paths = _create_temp_files(tmp_path, ["bad1.exe", "bad2.zip"])

        client = _make_client()
        results = []
        async for result in client.extract_batch(paths):
            results.append(result)
        await client.close()

        assert len(results) == 2
        assert all(r.document_id is None for r in results)
        assert all(r.full_text is None for r in results)
        assert all(r.error is not None for r in results)

    @respx.mock
    async def test_extract_batch_split_with_rejection_in_one_chunk(self, tmp_path):
        """Across multiple batches, rejected items from any batch all flow through."""
        upload_route = respx.post(UPLOAD_URL)
        upload_route.side_effect = [
            httpx.Response(207, json=make_upload_response(
                {"filename": "ok-1.pdf", "document_id": "id-1"},
                {
                    "filename": "bad.exe",
                    "status": "rejected",
                    "error": {
                        "type": "InvalidFileTypeError",
                        "message": "bad.exe rejected",
                        "details": {},
                    },
                },
            )),
            httpx.Response(207, json=make_upload_response(
                {"filename": "ok-2.pdf", "document_id": "id-2"},
            )),
        ]
        respx.get(f"{BASE_URL}/documents/id-1").respond(200, json={
            "task_id": "id-1", "status": "SUCCESS",
            "result": {
                "document_id": "id-1", "full_text": "text-1",
                "mime_type": "application/pdf", "overall_quality": 1.0,
                "total_pages": 1, "processing_time_ms": 1, "pages": [],
                "metadata": {},
            },
        })
        respx.get(f"{BASE_URL}/documents/id-2").respond(200, json={
            "task_id": "id-2", "status": "SUCCESS",
            "result": {
                "document_id": "id-2", "full_text": "text-2",
                "mime_type": "application/pdf", "overall_quality": 1.0,
                "total_pages": 1, "processing_time_ms": 1, "pages": [],
                "metadata": {},
            },
        })

        paths = _create_temp_files(tmp_path, ["ok-1.pdf", "bad.exe", "ok-2.pdf"])

        client = _make_client(max_batch_size=2)
        results = []
        async for result in client.extract_batch(paths):
            results.append(result)
        await client.close()

        assert upload_route.call_count == 2
        assert len(results) == 3
        successes = [r for r in results if r.error is None]
        failures = [r for r in results if r.error is not None]
        assert len(successes) == 2
        assert len(failures) == 1
        assert failures[0].filename == "bad.exe"
        assert failures[0].document_id is None

    @respx.mock
    async def test_extract_polling_timeout(self, tmp_path):
        """A document stuck in PENDING yields a result with a timeout error."""
        respx.post(UPLOAD_URL).respond(207, json=UPLOAD_RESPONSE_SINGLE)
        respx.get(STATUS_URL_1).respond(200, json=PENDING_STATUS)
        paths = _create_temp_files(tmp_path, ["contrato.pdf"])

        client = _make_client(poll_timeout=0.05)
        results = []
        async for result in client.extract_batch(paths):
            results.append(result)
        await client.close()

        assert len(results) == 1
        assert results[0].full_text is None
        assert results[0].error is not None
        assert "timeout" in results[0].error.lower()

    @respx.mock
    async def test_extract_auth_error_raises(self, tmp_path):
        """extract propagates AuthenticationError when upload returns 401."""
        respx.post(UPLOAD_URL).respond(401, text="Unauthorized")
        paths = _create_temp_files(tmp_path, ["contrato.pdf"])

        client = _make_client()
        with pytest.raises(AuthenticationError):
            async for _ in client.extract_batch(paths):
                pass
        await client.close()

    @respx.mock
    async def test_extract_validation_error_raises(self, tmp_path):
        """extract propagates ValidationError when upload returns 400."""
        respx.post(UPLOAD_URL).respond(400, text="Bad Request")
        paths = _create_temp_files(tmp_path, ["contrato.pdf"])

        client = _make_client()
        with pytest.raises(ValidationError):
            async for _ in client.extract_batch(paths):
                pass
        await client.close()

    @respx.mock
    async def test_extract_connection_error_raises(self, tmp_path):
        """extract propagates ServiceUnavailableError on connect failure."""
        respx.post(UPLOAD_URL).mock(
            side_effect=httpx.ConnectError("connection refused")
        )
        paths = _create_temp_files(tmp_path, ["contrato.pdf"])

        client = _make_client()
        with pytest.raises(ServiceUnavailableError):
            async for _ in client.extract_batch(paths):
                pass
        await client.close()

    @respx.mock
    async def test_extract_5xx_raises_service_unavailable(self, tmp_path):
        """A 503 from upload becomes ServiceUnavailableError on the consumer."""
        respx.post(UPLOAD_URL).respond(503, text="Service Unavailable")
        paths = _create_temp_files(tmp_path, ["contrato.pdf"])

        client = _make_client()
        with pytest.raises(ServiceUnavailableError, match="503"):
            async for _ in client.extract_batch(paths):
                pass
        await client.close()

    @respx.mock
    async def test_extract_unexpected_status_raises_extraction_error(
        self, tmp_path
    ):
        """Any non-2xx status outside the mapped set falls back to ExtractionError."""
        from intellidoc_sdk.exceptions import ExtractionError

        respx.post(UPLOAD_URL).respond(418, text="I'm a teapot")
        paths = _create_temp_files(tmp_path, ["contrato.pdf"])

        client = _make_client()
        with pytest.raises(ExtractionError, match="418"):
            async for _ in client.extract_batch(paths):
                pass
        await client.close()


class TestContextManager:
    """Tests for the async context manager protocol."""

    @respx.mock
    async def test_async_context_manager(self):
        """Async context manager opens and closes the client properly."""
        respx.post(UPLOAD_URL).respond(207, json=UPLOAD_RESPONSE_SINGLE)
        respx.get(STATUS_URL_1).respond(200, json=SUCCESS_STATUS_1)

        async with _make_client() as client:
            assert isinstance(client, IntelliDocClient)

        assert client._client.is_closed


class TestExtractInputNormalization:
    """Tests covering the new polymorphic ``extract()`` input handling."""

    @respx.mock
    async def test_extract_accepts_path_string_input(self, tmp_path):
        """A bare ``str`` path is read from disk and routed to ``files``."""
        respx.post(UPLOAD_URL).respond(207, json=UPLOAD_RESPONSE_SINGLE)
        respx.get(STATUS_URL_1).respond(200, json=SUCCESS_STATUS_1)
        pdf = tmp_path / "contrato.pdf"
        pdf.write_bytes(b"%PDF-mock")

        client = _make_client()
        results = [r async for r in client.extract_batch([str(pdf)])]
        await client.close()

        assert len(results) == 1
        assert results[0].filename == "contrato.pdf"
        assert results[0].full_text is not None

    @respx.mock
    async def test_extract_accepts_pathlib_path_input(self, tmp_path):
        """A ``pathlib.Path`` instance is accepted just like a string."""
        respx.post(UPLOAD_URL).respond(207, json=UPLOAD_RESPONSE_SINGLE)
        respx.get(STATUS_URL_1).respond(200, json=SUCCESS_STATUS_1)
        pdf = tmp_path / "contrato.pdf"
        pdf.write_bytes(b"%PDF-mock")

        client = _make_client()
        results = [r async for r in client.extract_batch([pdf])]
        await client.close()

        assert len(results) == 1
        assert results[0].filename == "contrato.pdf"

    @respx.mock
    async def test_extract_accepts_base64_dict_input(self):
        """A base64 dict input is forwarded under the ``base64`` field."""
        respx.post(UPLOAD_URL).respond(207, json=UPLOAD_RESPONSE_SINGLE)
        respx.get(STATUS_URL_1).respond(200, json=SUCCESS_STATUS_1)

        client = _make_client()
        results = [
            r
            async for r in client.extract_batch(
                [{"filename": "contrato.pdf", "content": "JVBERg=="}]
            )
        ]
        await client.close()

        assert len(results) == 1
        assert results[0].filename == "contrato.pdf"

    @respx.mock
    async def test_extract_accepts_mixed_inputs(self, tmp_path):
        """Mixing paths and base64 dicts in one call works end-to-end."""
        upload_response = make_upload_response(
            {"filename": "contrato.pdf", "document_id": DOC_ID_1},
            {"filename": "fila.html", "document_id": DOC_ID_2},
        )
        respx.post(UPLOAD_URL).respond(207, json=upload_response)
        respx.get(STATUS_URL_1).respond(200, json=SUCCESS_STATUS_1)
        respx.get(STATUS_URL_2).respond(200, json=SUCCESS_STATUS_2)
        pdf = tmp_path / "contrato.pdf"
        pdf.write_bytes(b"%PDF-mock")

        client = _make_client()
        results = [
            r
            async for r in client.extract_batch([
                str(pdf),
                {"filename": "fila.html", "content": "ZHVtbXk="},
            ])
        ]
        await client.close()

        assert {r.filename for r in results} == {"contrato.pdf", "fila.html"}
        assert all(r.full_text is not None for r in results)

    async def test_extract_rejects_dict_without_filename(self):
        """A base64 dict missing ``filename`` raises ValidationError pre-HTTP."""
        client = _make_client()
        with pytest.raises(ValidationError, match="filename"):
            async for _ in client.extract_batch([{"content": "JVBERg=="}]):
                pass
        await client.close()

    async def test_extract_rejects_dict_with_empty_filename(self):
        """An empty ``filename`` is rejected with the same error."""
        client = _make_client()
        with pytest.raises(ValidationError, match="filename"):
            async for _ in client.extract_batch(
                [{"filename": "", "content": "JVBERg=="}]
            ):
                pass
        await client.close()

    async def test_extract_rejects_dict_without_content(self):
        """A dict missing ``content`` raises ValidationError pre-HTTP."""
        client = _make_client()
        with pytest.raises(ValidationError, match="content"):
            async for _ in client.extract_batch([{"filename": "x.pdf"}]):
                pass
        await client.close()

    @respx.mock
    async def test_extract_accepts_bytes_content(self):
        """``content`` as bytes is sent as binary on the ``files`` field."""
        respx.post(UPLOAD_URL).respond(207, json=UPLOAD_RESPONSE_SINGLE)
        respx.get(STATUS_URL_1).respond(200, json=SUCCESS_STATUS_1)

        client = _make_client()
        results = [
            r
            async for r in client.extract_batch(
                [{"filename": "contrato.pdf", "content": b"%PDF-mock"}]
            )
        ]
        await client.close()

        assert len(results) == 1
        assert results[0].filename == "contrato.pdf"
        assert results[0].full_text is not None

    async def test_extract_rejects_unsupported_input_type(self):
        """Any input that is not str, Path, or dict is rejected pre-HTTP."""
        client = _make_client()
        with pytest.raises(ValidationError, match="Tipo não suportado"):
            async for _ in client.extract_batch([42]):  # type: ignore[list-item]
                pass
        await client.close()

    async def test_extract_rejects_missing_path_with_validation_error(
        self, tmp_path
    ):
        """A path that does not exist is wrapped as ValidationError pre-HTTP."""
        ghost = tmp_path / "does-not-exist.pdf"
        client = _make_client()
        with pytest.raises(ValidationError, match="não encontrado"):
            async for _ in client.extract_batch([str(ghost)]):
                pass
        await client.close()


class TestExtractMixedPartialSuccess:
    """End-to-end coverage for mixed batches with partial success.

    These exercise the new ``POST /documents`` flow where paths and
    base64 dicts go in the same request and the server returns 207 with
    a mix of accepted/rejected entries.
    """

    @respx.mock
    async def test_extract_partial_success_mixed_input(self, tmp_path):
        """2 paths + 2 base64 with 1 rejected → 3 accepted yields + 1 rejected."""
        respx.post(UPLOAD_URL).respond(
            207, json=UPLOAD_RESPONSE_MIXED_PARTIAL
        )
        for doc_id, full_text in (
            (DOC_ID_1, "contrato"),
            (DOC_ID_3, "fila-1"),
            (DOC_ID_4, "fila-2"),
        ):
            respx.get(f"{BASE_URL}/documents/{doc_id}").respond(
                200,
                json={
                    "task_id": doc_id,
                    "status": "SUCCESS",
                    "result": {
                        "document_id": doc_id,
                        "full_text": full_text,
                        "mime_type": "application/pdf",
                        "overall_quality": 1.0,
                        "total_pages": 1,
                        "processing_time_ms": 10,
                        "pages": [],
                        "metadata": {},
                    },
                },
            )

        contrato = tmp_path / "contrato.pdf"
        contrato.write_bytes(b"%PDF-mock")
        fake = tmp_path / "fake.pdf"
        fake.write_bytes(b"\x00\x00\x00\x18ftypmp42")

        client = _make_client()
        results = [
            r
            async for r in client.extract_batch([
                str(contrato),
                str(fake),
                {"filename": "fila_doc_1.pdf", "content": "ZmlsYS0x"},
                {"filename": "fila_doc_2.html", "content": "ZmlsYS0y"},
            ])
        ]
        await client.close()

        assert len(results) == 4
        rejected = [r for r in results if r.error is not None]
        accepted = [r for r in results if r.error is None]
        assert len(rejected) == 1
        assert rejected[0].filename == "fake.pdf"
        assert rejected[0].document_id is None
        assert "unsupported content type" in rejected[0].error
        assert len(accepted) == 3
        assert {r.filename for r in accepted} == {
            "contrato.pdf",
            "fila_doc_1.pdf",
            "fila_doc_2.html",
        }

    @respx.mock
    async def test_extract_all_rejected_with_mixed_inputs_no_polling(
        self, tmp_path
    ):
        """When every mixed input is rejected, no polling is issued.

        Stronger sentinel than the path-only counterpart: if the SDK ever
        starts polling rejected items (regardless of input source), this
        catches it.
        """
        upload_response = make_upload_response(
            {
                "filename": "bad.pdf",
                "status": "rejected",
                "error": {
                    "type": "InvalidFileTypeError",
                    "message": "bad.pdf rejected",
                    "details": {},
                },
            },
            {
                "filename": "bad_b64.pdf",
                "status": "rejected",
                "error": {
                    "type": "InvalidFileTypeError",
                    "message": "bad_b64.pdf rejected",
                    "details": {},
                },
            },
        )
        respx.post(UPLOAD_URL).respond(207, json=upload_response)

        bad = tmp_path / "bad.pdf"
        bad.write_bytes(b"\x00\x00\x00\x18ftypmp42")

        client = _make_client()
        results = [
            r
            async for r in client.extract_batch([
                str(bad),
                {"filename": "bad_b64.pdf", "content": "YmFkLWJhc2U2NA=="},
            ])
        ]
        await client.close()

        assert len(results) == 2
        assert all(r.document_id is None for r in results)
        assert all(r.error is not None for r in results)

    @respx.mock
    async def test_extract_propagates_422_when_filename_invalid_in_dict(self):
        """Path traversal in a dict ``filename`` reaches the server and 422s.

        The SDK only checks for non-empty filenames locally; full
        validation (path separators, control chars) is the server's job
        and surfaces as HTTP 422 → ``ValidationError``.
        """
        respx.post(UPLOAD_URL).respond(
            422,
            json={
                "detail": [
                    {
                        "loc": ["body", "documents", 0, "filename"],
                        "msg": "Filename cannot contain path separators",
                        "type": "value_error",
                    }
                ]
            },
        )

        client = _make_client()
        with pytest.raises(ValidationError, match="422"):
            async for _ in client.extract_batch(
                [{"filename": "../etc/passwd", "content": "JVBERg=="}]
            ):
                pass
        await client.close()


