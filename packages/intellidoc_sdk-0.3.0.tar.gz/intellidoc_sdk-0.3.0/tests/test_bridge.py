"""Tests for _SyncBridge — runs async code on a background event loop."""

from __future__ import annotations

import asyncio
import gc

import pytest

from intellidoc_sdk._bridge import _SyncBridge


class TestRun:
    """Tests for _SyncBridge.run()."""

    def test_run_returns_coroutine_result(self):
        """run() returns the value produced by the coroutine."""
        bridge = _SyncBridge()
        try:
            async def _coro() -> int:
                return 42

            assert bridge.run(_coro()) == 42
        finally:
            bridge.close()

    def test_run_propagates_exception(self):
        """run() re-raises whatever the coroutine raises."""
        bridge = _SyncBridge()
        try:
            async def _bad() -> None:
                raise ValueError("boom")

            with pytest.raises(ValueError, match="boom"):
                bridge.run(_bad())
        finally:
            bridge.close()

    def test_run_can_await_io(self):
        """run() works with coroutines that await asyncio primitives."""
        bridge = _SyncBridge()
        try:
            async def _sleepy() -> str:
                await asyncio.sleep(0.01)
                return "done"

            assert bridge.run(_sleepy()) == "done"
        finally:
            bridge.close()

    def test_run_reusable_across_calls(self):
        """The same bridge handles multiple sequential run() calls."""
        bridge = _SyncBridge()
        try:
            async def _add(a: int, b: int) -> int:
                return a + b

            assert bridge.run(_add(1, 2)) == 3
            assert bridge.run(_add(10, 20)) == 30
            assert bridge.run(_add(-1, 1)) == 0
        finally:
            bridge.close()


class TestIterate:
    """Tests for _SyncBridge.iterate()."""

    def test_iterate_yields_items_in_order(self):
        """iterate() yields the same items the async generator produced."""
        bridge = _SyncBridge()
        try:
            async def _gen():
                for i in range(3):
                    yield i

            assert list(bridge.iterate(_gen())) == [0, 1, 2]
        finally:
            bridge.close()

    def test_iterate_empty_generator(self):
        """iterate() yields nothing for an empty async generator."""
        bridge = _SyncBridge()
        try:
            async def _empty():
                if False:
                    yield  # pragma: no cover

            assert list(bridge.iterate(_empty())) == []
        finally:
            bridge.close()

    def test_iterate_propagates_exception_from_generator(self):
        """iterate() re-raises an exception raised mid-iteration."""
        bridge = _SyncBridge()
        try:
            async def _gen():
                yield 1
                raise RuntimeError("mid-stream failure")

            it = bridge.iterate(_gen())
            assert next(it) == 1
            with pytest.raises(RuntimeError, match="mid-stream failure"):
                next(it)
        finally:
            bridge.close()

    def test_iterate_caller_stops_early(self):
        """Closing the iterator early stops the async generator cleanly."""
        bridge = _SyncBridge()
        try:
            cleanup = asyncio.Event()

            async def _gen():
                try:
                    for i in range(100):
                        yield i
                finally:
                    cleanup.set()

            it = bridge.iterate(_gen())
            assert next(it) == 0
            it.close()  # caller stops early — should trigger generator cleanup

            # cleanup happens on the bridge's loop; wait for it
            assert bridge.run(_wait_for(cleanup, timeout=1.0))
        finally:
            bridge.close()


async def _wait_for(event: asyncio.Event, timeout: float) -> bool:
    """Wait for *event* to be set, return True if it was, False on timeout."""
    try:
        await asyncio.wait_for(event.wait(), timeout=timeout)
        return True
    except asyncio.TimeoutError:
        return False


class TestClose:
    """Tests for _SyncBridge.close() and lifecycle."""

    def test_close_stops_thread(self):
        """close() stops the worker thread."""
        bridge = _SyncBridge()
        thread = bridge._thread
        bridge.close()
        assert not thread.is_alive()

    def test_close_idempotent(self):
        """Calling close() multiple times is safe."""
        bridge = _SyncBridge()
        bridge.close()
        bridge.close()  # should not raise

    def test_del_closes_bridge(self):
        """Garbage-collecting the bridge stops the worker thread."""
        bridge = _SyncBridge()
        thread = bridge._thread
        del bridge
        gc.collect()
        thread.join(timeout=2.0)
        assert not thread.is_alive()
