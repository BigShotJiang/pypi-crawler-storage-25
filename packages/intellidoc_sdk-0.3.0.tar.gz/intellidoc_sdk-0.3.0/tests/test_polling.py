"""Tests for intellidoc_sdk._polling."""

from __future__ import annotations

import httpx
import pytest
import respx

from intellidoc_sdk._polling import poll_until_complete
from intellidoc_sdk.exceptions import (
    AuthenticationError,
    ExtractionError,
    ExtractionTimeoutError,
    ServiceUnavailableError,
)

BASE_URL = "https://intellidoc.test"
DOC_ID = "uuid-123"
HEADERS = {"X-API-Key": "test-key"}
STATUS_URL = f"{BASE_URL}/documents/{DOC_ID}"

RESULT_PAYLOAD: dict = {
    "document_id": DOC_ID,
    "full_text": "Extracted text content",
    "mime_type": "application/pdf",
    "overall_quality": 0.95,
    "total_pages": 1,
    "processing_time_ms": 1500,
    "pages": [
        {
            "page_number": 1,
            "content": "Extracted text content",
            "extraction_method": "pdf_native",
            "quality_score": 0.95,
            "metadata": None,
        }
    ],
    "metadata": {},
}


@respx.mock
async def test_polling_success_immediate() -> None:
    """First poll returns SUCCESS -- result is returned immediately."""
    respx.get(STATUS_URL).respond(
        200, json={"task_id": DOC_ID, "status": "SUCCESS", "result": RESULT_PAYLOAD}
    )

    async with httpx.AsyncClient() as client:
        result = await poll_until_complete(
            client=client,
            base_url=BASE_URL,
            document_id=DOC_ID,
            headers=HEADERS,
            interval=0.01,
            timeout=5.0,
        )

    assert result["document_id"] == DOC_ID
    assert result["full_text"] == "Extracted text content"


@respx.mock
async def test_polling_pending_then_success() -> None:
    """PENDING -> PENDING -> SUCCESS flow resolves correctly."""
    route = respx.get(STATUS_URL)
    route.side_effect = [
        httpx.Response(200, json={"task_id": DOC_ID, "status": "PENDING"}),
        httpx.Response(200, json={"task_id": DOC_ID, "status": "PENDING"}),
        httpx.Response(
            200,
            json={"task_id": DOC_ID, "status": "SUCCESS", "result": RESULT_PAYLOAD},
        ),
    ]

    async with httpx.AsyncClient() as client:
        result = await poll_until_complete(
            client=client,
            base_url=BASE_URL,
            document_id=DOC_ID,
            headers=HEADERS,
            interval=0.01,
            timeout=5.0,
        )

    assert result["document_id"] == DOC_ID
    assert route.call_count == 3


@respx.mock
async def test_polling_retry_then_success() -> None:
    """RETRY (transient) status is followed by a SUCCESS on the next poll."""
    route = respx.get(STATUS_URL)
    route.side_effect = [
        httpx.Response(200, json={"task_id": DOC_ID, "status": "RETRY"}),
        httpx.Response(
            200,
            json={"task_id": DOC_ID, "status": "SUCCESS", "result": RESULT_PAYLOAD},
        ),
    ]

    async with httpx.AsyncClient() as client:
        result = await poll_until_complete(
            client=client,
            base_url=BASE_URL,
            document_id=DOC_ID,
            headers=HEADERS,
            interval=0.01,
            timeout=5.0,
        )

    assert result["full_text"] == "Extracted text content"
    assert route.call_count == 2


@respx.mock
async def test_polling_failure() -> None:
    """FAILURE status raises ExtractionError with the error message."""
    respx.get(STATUS_URL).respond(
        200,
        json={
            "task_id": DOC_ID,
            "status": "FAILURE",
            "error": "Unsupported document format",
        },
    )

    async with httpx.AsyncClient() as client:
        with pytest.raises(ExtractionError, match="Unsupported document format"):
            await poll_until_complete(
                client=client,
                base_url=BASE_URL,
                document_id=DOC_ID,
                headers=HEADERS,
                interval=0.01,
                timeout=5.0,
            )


@respx.mock
async def test_polling_timeout() -> None:
    """Always PENDING until timeout raises ExtractionTimeoutError."""
    respx.get(STATUS_URL).respond(200, json={"task_id": DOC_ID, "status": "PENDING"})

    async with httpx.AsyncClient() as client:
        with pytest.raises(ExtractionTimeoutError, match="timed out"):
            await poll_until_complete(
                client=client,
                base_url=BASE_URL,
                document_id=DOC_ID,
                headers=HEADERS,
                interval=0.01,
                timeout=0.05,
            )


@respx.mock
async def test_polling_http_error_retries() -> None:
    """HTTP 500 on poll is treated as transient; next poll succeeds."""
    route = respx.get(STATUS_URL)
    route.side_effect = [
        httpx.Response(500, text="Internal Server Error"),
        httpx.Response(
            200,
            json={"task_id": DOC_ID, "status": "SUCCESS", "result": RESULT_PAYLOAD},
        ),
    ]

    async with httpx.AsyncClient() as client:
        result = await poll_until_complete(
            client=client,
            base_url=BASE_URL,
            document_id=DOC_ID,
            headers=HEADERS,
            interval=0.01,
            timeout=5.0,
        )

    assert result["document_id"] == DOC_ID
    assert route.call_count == 2


@respx.mock
async def test_polling_404() -> None:
    """HTTP 404 on poll raises ExtractionError immediately."""
    respx.get(STATUS_URL).respond(404, json={"detail": "Not found"})

    async with httpx.AsyncClient() as client:
        with pytest.raises(ExtractionError, match="Document not found"):
            await poll_until_complete(
                client=client,
                base_url=BASE_URL,
                document_id=DOC_ID,
                headers=HEADERS,
                interval=0.01,
                timeout=5.0,
            )


@respx.mock
async def test_polling_unknown_status() -> None:
    """Unknown status raises ExtractionError immediately."""
    respx.get(STATUS_URL).respond(200, json={"task_id": DOC_ID, "status": "UNKNOWN_STATUS"})

    async with httpx.AsyncClient() as client:
        with pytest.raises(ExtractionError, match="Unexpected status"):
            await poll_until_complete(
                client=client,
                base_url=BASE_URL,
                document_id=DOC_ID,
                headers=HEADERS,
                interval=0.01,
                timeout=5.0,
            )


@respx.mock
async def test_polling_connection_error() -> None:
    """ConnectError during poll raises ServiceUnavailableError."""
    respx.get(STATUS_URL).mock(side_effect=httpx.ConnectError("connection refused"))

    async with httpx.AsyncClient() as client:
        with pytest.raises(ServiceUnavailableError, match="Failed to connect"):
            await poll_until_complete(
                client=client,
                base_url=BASE_URL,
                document_id=DOC_ID,
                headers=HEADERS,
                interval=0.01,
                timeout=5.0,
            )


@respx.mock
async def test_polling_auth_error() -> None:
    """HTTP 401 on poll raises AuthenticationError."""
    respx.get(STATUS_URL).respond(401, text="Unauthorized")

    async with httpx.AsyncClient() as client:
        with pytest.raises(AuthenticationError, match="Authentication failed"):
            await poll_until_complete(
                client=client,
                base_url=BASE_URL,
                document_id=DOC_ID,
                headers=HEADERS,
                interval=0.01,
                timeout=5.0,
            )
