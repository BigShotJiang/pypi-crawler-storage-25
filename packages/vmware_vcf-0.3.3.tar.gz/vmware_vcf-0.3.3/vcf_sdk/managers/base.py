"""Base manager with shared patterns."""

import logging
import time
from typing import Any, Dict

from vcf_sdk.auth import SDDCAuth
from vcf_sdk.base import BaseClient
from vcf_sdk.exceptions import ValidationError, TimeoutError

logger = logging.getLogger(__name__)


class BaseManager:
    """Base class for all SDDC Manager resource managers."""

    def __init__(self, client: BaseClient, auth: SDDCAuth):
        self.client = client
        self.auth = auth

    def _get(self, endpoint: str, **kwargs) -> Dict[str, Any]:
        return self.client.get(endpoint, headers=self.auth.get_auth_headers(), **kwargs)

    def _post(self, endpoint: str, data=None, **kwargs) -> Dict[str, Any]:
        return self.client.post(endpoint, data=data, headers=self.auth.get_auth_headers(), **kwargs)

    def _put(self, endpoint: str, data=None, **kwargs) -> Dict[str, Any]:
        return self.client.put(endpoint, data=data, headers=self.auth.get_auth_headers(), **kwargs)

    def _patch(self, endpoint: str, data=None, **kwargs) -> Dict[str, Any]:
        return self.client.request(
            "PATCH", endpoint, data=data, headers=self.auth.get_auth_headers(), **kwargs
        )

    def _delete(self, endpoint: str, **kwargs) -> Dict[str, Any]:
        return self.client.delete(endpoint, headers=self.auth.get_auth_headers(), **kwargs)

    def _validate_and_wait(
        self,
        validation_endpoint: str,
        spec: Dict[str, Any],
        poll_endpoint_template: str = None,
        timeout: int = 300,
        poll_interval: int = 5,
    ) -> Dict[str, Any]:
        """
        Validate-then-execute pattern from PowerVCF.

        1. POST spec to validation endpoint
        2. Poll until validation completes
        3. Return validation result (caller checks success before proceeding)
        """
        response = self._post(validation_endpoint, data=spec)

        # Check if validation completed immediately in the POST response
        result = response
        validation_id = response.get("id")

        if not validation_id:
            return response

        # If not already completed, poll for completion
        if result.get("executionStatus") != "COMPLETED":
            poll_endpoint = (
                poll_endpoint_template.format(id=validation_id)
                if poll_endpoint_template
                else f"{validation_endpoint}/{validation_id}"
            )

            time.sleep(2)
            start_time = time.time()
            while True:
                try:
                    result = self._get(poll_endpoint)
                except Exception as e:
                    elapsed = time.time() - start_time
                    if elapsed > timeout:
                        raise
                    logger.debug(f"Validation poll error (will retry): {e}")
                    time.sleep(poll_interval)
                    continue

                if result.get("executionStatus") == "COMPLETED":
                    break

                elapsed = time.time() - start_time
                if elapsed > timeout:
                    raise TimeoutError(f"Validation {validation_id} timed out after {timeout}s")

                time.sleep(poll_interval)

        # Check result
        if result.get("resultStatus") != "SUCCEEDED":
            checks = result.get("validationChecks", [])
            errors = []
            for check in checks:
                if check.get("resultStatus") == "FAILED":
                    err = check.get("errorResponse", {})
                    msg = err.get("message", "Unknown error")
                    remediation = err.get("remediationMessage", "")
                    if remediation:
                        msg += f" — {remediation}"
                    errors.append(msg)
            raise ValidationError(
                message="Validation failed:\n  " + "\n  ".join(errors) if errors else "Validation failed",
                status_code=None,
                response_body=str(result),
            )
        return result
