from __future__ import annotations

from dataclasses import fields
from pathlib import Path
from typing import Any
import warnings

import yaml

from timelapsedhrpqct.config.models import (
    AnalysisBinaryReclassificationConfig,
    AnalysisChangeRegionConfig,
    AnalysisConfig,
    AnalysisValidRegionConfig,
    AppConfig,
    DiscoveryConfig,
    FusionConfig,
    FillingConfig,
    ImportConfig,
    InnerContourConfig,
    MaskSegmentationConfig,
    MasksConfig,
    MultistackCorrectionConfig,
    OuterContourConfig,
    TimelapsedRegistrationConfig,
    TransformConfig,
    VisualizationConfig,
    VisualizationLabelMapConfig,
)
from timelapsedhrpqct.config.profiles import read_profile


DEFAULT_CONFIG_PATH = Path(__file__).resolve().parents[1] / "configs" / "defaults.yml"


def _read_yaml(path: Path) -> dict[str, Any]:
    """Helper for read yaml."""
    with path.open("r", encoding="utf-8") as f:
        data = yaml.safe_load(f) or {}
    if not isinstance(data, dict):
        raise ValueError(f"Config file must contain a mapping at top level: {path}")
    return data


def _deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    """Return a recursive merge where override wins."""
    merged = dict(base)
    for key, value in override.items():
        base_value = merged.get(key)
        if isinstance(base_value, dict) and isinstance(value, dict):
            merged[key] = _deep_merge(base_value, value)
        else:
            merged[key] = value
    return merged


def _filter_dataclass_kwargs(cls: type, values: dict[str, Any]) -> dict[str, Any]:
    """Helper for filter dataclass kwargs."""
    allowed = {f.name for f in fields(cls)}
    return {k: v for k, v in values.items() if k in allowed}


def _warn_unknown_keys(
    section: str,
    cls: type,
    values: dict[str, Any],
    excluded: set[str] | None = None,
) -> None:
    """Helper for warn unknown keys."""
    allowed = {f.name for f in fields(cls)}
    ignored = set(excluded or set())
    unknown = sorted(k for k in values.keys() if k not in allowed and k not in ignored)
    if unknown:
        warnings.warn(
            f"Ignoring unknown config key(s) in section '{section}': {', '.join(unknown)}",
            stacklevel=2,
        )


def _normalize_segmentation_aliases(values: dict[str, Any]) -> dict[str, Any]:
    """Translate legacy/Slicer segmentation aliases into canonical config keys."""
    normalized = dict(values)
    if "seg_gauss_threshold" in normalized:
        threshold = normalized["seg_gauss_threshold"]
        normalized["trab_threshold"] = threshold
        normalized["cort_threshold"] = threshold
    if "seg_gauss_sigma" in normalized:
        normalized["gaussian_sigma"] = normalized["seg_gauss_sigma"]
    return normalized


def load_config(path: str | Path | None = None, *, profile: str | None = None) -> AppConfig:
    """Load config."""
    raw = _read_yaml(DEFAULT_CONFIG_PATH) if DEFAULT_CONFIG_PATH.is_file() else {}
    if profile:
        raw = _deep_merge(raw, read_profile(profile))
    if path is not None:
        cfg_path = Path(path)
        try:
            is_default = cfg_path.resolve() == DEFAULT_CONFIG_PATH.resolve()
        except FileNotFoundError:
            is_default = False
        if not is_default:
            raw = _deep_merge(raw, _read_yaml(cfg_path))

    import_raw = raw.get("import", {})
    discovery_raw = raw.get("discovery", {})
    masks_raw = raw.get("masks", {})
    timelapsed_raw = raw.get("timelapsed_registration", {})
    multistack_raw = raw.get("multistack_correction", {})
    transform_raw = raw.get("transform", {})
    fusion_raw = raw.get("fusion", {})
    filling_raw = raw.get("filling", {})
    analysis_raw = raw.get("analysis", {})
    visualization_raw = raw.get("visualization", {})

    masks_outer_raw = masks_raw.get("outer", {})
    masks_inner_raw = masks_raw.get("inner", {})
    masks_seg_raw = _normalize_segmentation_aliases(masks_raw.get("segmentation", {}))
    analysis_change_region_raw = analysis_raw.get("change_region", {})
    analysis_binary_raw = analysis_raw.get("binary_reclassification", {})
    analysis_valid_region_raw = analysis_raw.get("valid_region", {})
    visualization_label_map_raw = visualization_raw.get("label_map", {})

    _warn_unknown_keys("import", ImportConfig, import_raw)
    _warn_unknown_keys("discovery", DiscoveryConfig, discovery_raw)
    _warn_unknown_keys("masks", MasksConfig, masks_raw, excluded={"outer", "inner", "segmentation"})
    _warn_unknown_keys("masks.outer", OuterContourConfig, masks_outer_raw)
    _warn_unknown_keys("masks.inner", InnerContourConfig, masks_inner_raw)
    _warn_unknown_keys(
        "masks.segmentation",
        MaskSegmentationConfig,
        masks_seg_raw,
        excluded={"seg_gauss_threshold", "seg_gauss_sigma"},
    )
    _warn_unknown_keys("timelapsed_registration", TimelapsedRegistrationConfig, timelapsed_raw)
    _warn_unknown_keys("multistack_correction", MultistackCorrectionConfig, multistack_raw)
    _warn_unknown_keys("transform", TransformConfig, transform_raw)
    _warn_unknown_keys("fusion", FusionConfig, fusion_raw)
    _warn_unknown_keys("filling", FillingConfig, filling_raw)
    _warn_unknown_keys(
        "analysis",
        AnalysisConfig,
        analysis_raw,
        excluded={"change_region", "binary_reclassification", "valid_region"},
    )
    _warn_unknown_keys("analysis.change_region", AnalysisChangeRegionConfig, analysis_change_region_raw)
    _warn_unknown_keys(
        "analysis.binary_reclassification",
        AnalysisBinaryReclassificationConfig,
        analysis_binary_raw,
    )
    _warn_unknown_keys("analysis.valid_region", AnalysisValidRegionConfig, analysis_valid_region_raw)
    _warn_unknown_keys("visualization", VisualizationConfig, visualization_raw, excluded={"label_map"})
    _warn_unknown_keys("visualization.label_map", VisualizationLabelMapConfig, visualization_label_map_raw)

    masks_cfg = MasksConfig(
        **_filter_dataclass_kwargs(
            MasksConfig,
            {
                k: v
                for k, v in masks_raw.items()
                if k not in {"outer", "inner", "segmentation"}
            },
        ),
        outer=OuterContourConfig(
            **_filter_dataclass_kwargs(OuterContourConfig, masks_outer_raw)
        ),
        inner=InnerContourConfig(
            **_filter_dataclass_kwargs(InnerContourConfig, masks_inner_raw)
        ),
        segmentation=MaskSegmentationConfig(
            **_filter_dataclass_kwargs(MaskSegmentationConfig, masks_seg_raw)
        ),
    )

    return AppConfig(
        import_=ImportConfig(**_filter_dataclass_kwargs(ImportConfig, import_raw)),
        discovery=DiscoveryConfig(
            **_filter_dataclass_kwargs(DiscoveryConfig, discovery_raw)
        ),
        masks=masks_cfg,
        timelapsed_registration=TimelapsedRegistrationConfig(
            **_filter_dataclass_kwargs(TimelapsedRegistrationConfig, timelapsed_raw)
        ),
        multistack_correction=MultistackCorrectionConfig(
            **_filter_dataclass_kwargs(MultistackCorrectionConfig, multistack_raw)
        ),
        transform=TransformConfig(
            **_filter_dataclass_kwargs(TransformConfig, transform_raw)
        ),
        fusion=FusionConfig(**_filter_dataclass_kwargs(FusionConfig, fusion_raw)),
        filling=FillingConfig(**_filter_dataclass_kwargs(FillingConfig, filling_raw)),
        analysis=AnalysisConfig(
            **_filter_dataclass_kwargs(
                AnalysisConfig,
                {
                    k: v
                    for k, v in analysis_raw.items()
                    if k not in {"change_region", "binary_reclassification", "valid_region"}
                },
            ),
            change_region=AnalysisChangeRegionConfig(
                **_filter_dataclass_kwargs(
                    AnalysisChangeRegionConfig,
                    analysis_change_region_raw,
                )
            ),
            binary_reclassification=AnalysisBinaryReclassificationConfig(
                **_filter_dataclass_kwargs(
                    AnalysisBinaryReclassificationConfig,
                    analysis_binary_raw,
                )
            ),
            valid_region=AnalysisValidRegionConfig(
                **_filter_dataclass_kwargs(
                    AnalysisValidRegionConfig,
                    analysis_valid_region_raw,
                )
            ),
        ),
        visualization=VisualizationConfig(
            **_filter_dataclass_kwargs(
                VisualizationConfig,
                {k: v for k, v in visualization_raw.items() if k != "label_map"},
            ),
            label_map=VisualizationLabelMapConfig(
                **_filter_dataclass_kwargs(
                    VisualizationLabelMapConfig,
                    visualization_label_map_raw,
                )
            ),
        ),
    )
