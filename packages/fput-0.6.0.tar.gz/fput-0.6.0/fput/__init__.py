"""
FPUT - Fermi-Pasta-Ulam-Tsingou Problem Simulator

A Python package for simulating the classic FPUT nonlinear oscillator chain.
"""

__version__ = "0.4.5"
__author__ = "FPUT Project Contributors"

from fput.simulator import FPUTSimulator, FPUTBetaSimulator
from fput.normal_modes import (
    compute_normal_mode_energies,
    compute_normal_mode_coordinates,
    fundamental_period
)
from fput.analysis import (
    compute_participation_ratio,
    compute_energy_sharing,
    find_recurrence_times
)
from fput.gui import FPUTSimulatorGUI

__all__ = [
    # Simulators
    "FPUTSimulator",
    "FPUTBetaSimulator",
    # Normal modes
    "compute_normal_mode_energies",
    "compute_normal_mode_coordinates",
    "fundamental_period",
    # Analysis
    "compute_participation_ratio",
    "compute_energy_sharing",
    "find_recurrence_times",
    # GUI
    "FPUTSimulatorGUI",
]
