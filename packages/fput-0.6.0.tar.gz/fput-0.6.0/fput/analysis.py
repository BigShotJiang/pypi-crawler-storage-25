"""
Statistical Analysis for FPUT Simulations.

This module provides functions for analyzing simulation results,
including energy sharing, recurrence detection, and participation metrics.
"""

import numpy as np
from typing import Dict, Optional, Tuple


def compute_energy_sharing(mode_energies: np.ndarray) -> Dict[str, np.ndarray]:
    """
    Compute statistics about energy sharing among modes.

    Parameters
    ----------
    mode_energies : ndarray
        Mode energies over time, shape (n_time_points, n_modes).

    Returns
    -------
    stats : dict
        Dictionary containing:
        - 'total_energy': Total energy at each time point
        - 'mode1_fraction': Fraction of energy in mode 1
        - 'participation_ratio': Number of modes significantly occupied
        - 'energy_entropy': Shannon entropy of energy distribution
    """
    # Total energy at each time point
    total_energy = np.sum(mode_energies, axis=1)

    # Avoid division by zero
    epsilon = 1e-16
    total_energy_safe = total_energy + epsilon

    # Energy fraction in mode 1
    mode1_fraction = mode_energies[:, 0] / total_energy_safe

    # Participation ratio: 1 / sum(p_i^2) where p_i = E_i / E_total
    p = mode_energies / total_energy_safe[:, np.newaxis]
    participation_ratio = 1.0 / np.sum(p**2, axis=1)

    # Energy entropy (Shannon entropy)
    entropy = -np.sum(p * np.log(p + epsilon), axis=1)

    return {
        'total_energy': total_energy,
        'mode1_fraction': mode1_fraction,
        'participation_ratio': participation_ratio,
        'energy_entropy': entropy
    }


def find_recurrence_times(
    time_points: np.ndarray,
    mode1_energy: np.ndarray,
    initial_energy: float,
    threshold: float = 0.03,
    min_separation: float = 10.0
) -> np.ndarray:
    """
    Find times when energy returns close to the initial mode.

    Parameters
    ----------
    time_points : ndarray
        Time values.
    mode1_energy : ndarray
        Energy of mode 1 over time.
    initial_energy : float
        Initial energy in mode 1.
    threshold : float
        Threshold for considering energy "returned" (fraction of initial).
    min_separation : float
        Minimum time separation between recurrence events.

    Returns
    -------
    recurrence_times : ndarray
        Times when significant recurrence occurs.
    """
    # Find where mode 1 energy is within threshold of initial
    relative_diff = np.abs(mode1_energy - initial_energy) / (initial_energy + 1e-16)
    recurrence_indices = np.where(relative_diff < threshold)[0]

    if len(recurrence_indices) == 0:
        return np.array([])

    # Filter to keep only significant recurrences (separated by min_separation)
    recurrence_times = time_points[recurrence_indices]
    significant = []
    last_t = -1e9

    for t in recurrence_times:
        if t - last_t > min_separation:
            significant.append(t)
            last_t = t

    return np.array(significant)


def compute_participation_ratio(mode_energies: np.ndarray) -> np.ndarray:
    """
    Compute the participation ratio over time.

    The participation ratio measures how many modes are significantly occupied.
    A value of 1 means all energy is in one mode.
    A value of N means energy is equally distributed among N modes.

    Parameters
    ----------
    mode_energies : ndarray
        Mode energies over time, shape (n_time_points, n_modes).

    Returns
    -------
    participation_ratio : ndarray
        Participation ratio at each time point.
    """
    total_energy = np.sum(mode_energies, axis=1, keepdims=True)
    p = mode_energies / (total_energy + 1e-16)
    return 1.0 / np.sum(p**2, axis=1)


def compute_energy_entropy(mode_energies: np.ndarray) -> np.ndarray:
    """
    Compute the Shannon entropy of the energy distribution.

    Parameters
    ----------
    mode_energies : ndarray
        Mode energies over time, shape (n_time_points, n_modes).

    Returns
    -------
    entropy : ndarray
        Energy entropy at each time point.
    """
    total_energy = np.sum(mode_energies, axis=1, keepdims=True)
    p = mode_energies / (total_energy + 1e-16)
    return -np.sum(p * np.log(p + 1e-16), axis=1)


def estimate_recurrence_time(
    time_points: np.ndarray,
    mode_energies: np.ndarray,
    threshold: float = 0.03
) -> Optional[float]:
    """
    Estimate the first recurrence time after the initial transient.

    Parameters
    ----------
    time_points : ndarray
        Time values.
    mode_energies : ndarray
        Mode energies over time, shape (n_time_points, n_modes).
    threshold : float
        Threshold for energy return (fraction of initial).

    Returns
    -------
    recurrence_time : float or None
        First significant recurrence time, or None if not found.
    """
    mode1_energy = mode_energies[:, 0]
    initial_energy = mode1_energy[0]

    # Skip initial transient (first 10 data points)
    skip = min(10, len(mode1_energy) // 10)

    for i in range(skip, len(mode1_energy)):
        relative_diff = np.abs(mode1_energy[i] - initial_energy) / (initial_energy + 1e-16)
        if relative_diff < threshold:
            return time_points[i]

    return None
