"""
FPUT Simulator - Core simulation engine for the Fermi-Pasta-Ulam-Tsingou problem.

Following the original FPUT paper convention:
- N represents the total number of intervals in the chain
- Number of moving particles is N-1 (Q_1 to Q_{N-1})
- Fixed endpoints: Q_0 = 0 and Q_N = 0
- Frequencies: omega_k = 2*sin(k*pi/(2*N))
- Transform: A_l = sqrt(2/N) * sum Q_k * sin(k*l*pi/N)
"""

import numpy as np
from typing import Optional, Tuple, List, Union
from dataclasses import dataclass


@dataclass
class SimulationResult:
    """Container for simulation results."""
    time_points: np.ndarray
    mode_energies: np.ndarray  # Shape: (n_time_points, n_modes)
    coordinates: Optional[np.ndarray] = None  # Shape: (n_time_points, n_particles)
    momenta: Optional[np.ndarray] = None


class FPUTSimulator:
    """
    FPUT system with quadratic (alpha) nonlinearity.

    Following the original FPUT paper convention:
    - N is the total number of intervals (N-1 moving particles)
    - Hamiltonian: H = sum(1/2*P_k^2) + 1/2*sum((Q_{k+1}-Q_k)^2) + alpha/3*sum((Q_{k+1}-Q_k)^3)
    - Fixed boundary conditions: Q_0 = Q_N = 0

    Parameters
    ----------
    N : int
        Total number of intervals (N-1 moving particles).
    alpha : float, optional
        Quadratic nonlinear coupling parameter. Default is 0.25.
    dt : float, optional
        Time step for integration. Default is 0.05.
    """

    def __init__(self, N: int, alpha: float = 0.25, dt: float = 0.05):
        """
        Initialize FPUT simulator.

        Parameters
        ----------
        N : int
            Total number of intervals (N-1 moving particles).
        alpha : float
            Nonlinear coupling parameter.
        dt : float
            Time step.
        """
        self.N = N  # Total intervals
        self.N_moving = N - 1  # Moving particles
        self.alpha = alpha
        self.dt = dt
        # Q and P have N+1 elements: Q[0] and Q[N] are fixed endpoints
        self.Q = np.zeros(N + 1)
        self.P = np.zeros(N + 1)
        self.omega = self._compute_frequencies()

    def _compute_frequencies(self) -> np.ndarray:
        """Compute the normal mode frequencies: omega_k = 2*sin(k*pi/(2*N))."""
        k = np.arange(1, self.N)  # k = 1, 2, ..., N-1
        return 2 * np.sin(k * np.pi / (2 * self.N))

    def set_initial_mode(self, mode: int = 1, amplitude: float = 1.0):
        """
        Set initial conditions exciting only a single normal mode.

        The displacement pattern for mode m is:
        Q_k = A * sin(k * m * pi / N), k = 1, 2, ..., N-1

        Parameters
        ----------
        mode : int
            Mode number to excite (1 to N-1).
        amplitude : float
            Amplitude of the mode. Default is 1.0.
        """
        k = np.arange(1, self.N)  # Particle indices: 1, 2, ..., N-1
        # Initialize moving particles with sine wave pattern
        self.Q[1:self.N] = amplitude * np.sin(k * mode * np.pi / self.N)
        self.P[:] = 0  # Start from rest

    def set_initial_sine_wave(self, amplitude: float = 1.0):
        """
        Set initial conditions as a sine wave (fundamental mode).

        This is the classic FPUT initial condition: Q_k = A * sin(k*pi/N).

        Parameters
        ----------
        amplitude : float
            Amplitude of the sine wave. Default is 1.0.
        """
        self.set_initial_mode(mode=1, amplitude=amplitude)

    def equations_of_motion(self, Q: np.ndarray, P: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """
        Compute the equations of motion for the FPUT-alpha system.

        dQ/dt = P
        dP/dt = acceleration from springs

        Parameters
        ----------
        Q : ndarray
            Coordinates (including endpoints).
        P : ndarray
            Momenta (including endpoints).

        Returns
        -------
        dQdt : ndarray
            Time derivative of coordinates.
        dPdt : ndarray
            Time derivative of momenta (accelerations).
        """
        dQdt = P.copy()

        # Compute accelerations
        dPdt = np.zeros_like(Q)
        # Linear part: Q[k+1] + Q[k-1] - 2*Q[k]
        dPdt[1:self.N] = Q[2:self.N + 1] + Q[0:self.N - 1] - 2 * Q[1:self.N]

        # Nonlinear part (alpha term)
        if self.alpha != 0:
            delta_plus = (Q[2:self.N + 1] - Q[1:self.N])**2
            delta_minus = (Q[1:self.N] - Q[0:self.N - 1])**2
            dPdt[1:self.N] += self.alpha * (delta_plus - delta_minus)

        return dQdt, dPdt

    def step_rk4(self) -> None:
        """Perform a single Runge-Kutta 4th order integration step."""
        Q = self.Q
        P = self.P
        dt = self.dt

        k1_Q, k1_P = self.equations_of_motion(Q, P)

        k2_Q, k2_P = self.equations_of_motion(
            Q + 0.5 * dt * k1_Q,
            P + 0.5 * dt * k1_P
        )

        k3_Q, k3_P = self.equations_of_motion(
            Q + 0.5 * dt * k2_Q,
            P + 0.5 * dt * k2_P
        )

        k4_Q, k4_P = self.equations_of_motion(
            Q + dt * k3_Q,
            P + dt * k3_P
        )

        self.Q += (dt / 6) * (k1_Q + 2 * k2_Q + 2 * k3_Q + k4_Q)
        self.P += (dt / 6) * (k1_P + 2 * k2_P + 2 * k3_P + k4_P)

    def step_dop853(self) -> None:
        """
        Perform a single DOP853 (high-order) integration step.

        DOP853 is an 8th order Runge-Kutta method with adaptive step size.
        This uses scipy's solve_ivp with DOP853 method for high accuracy.
        """
        try:
            from scipy.integrate import solve_ivp
        except ImportError:
            # Fallback to RK4 if scipy not available
            return self.step_rk4()

        def rhs(t, y):
            """Right-hand side for solve_ivp."""
            n = len(self.Q)
            Q_flat = y[:n]
            P_flat = y[n:]

            dQdt = P_flat.copy()
            dPdt = np.zeros_like(Q_flat)

            # Linear part
            dPdt[1:self.N] = Q_flat[2:self.N + 1] + Q_flat[0:self.N - 1] - 2 * Q_flat[1:self.N]

            # Nonlinear part
            if self.alpha != 0:
                delta_plus = (Q_flat[2:self.N + 1] - Q_flat[1:self.N])**2
                delta_minus = (Q_flat[1:self.N] - Q_flat[0:self.N - 1])**2
                dPdt[1:self.N] += self.alpha * (delta_plus - delta_minus)

            return np.concatenate([dQdt, dPdt])

        y0 = np.concatenate([self.Q, self.P])
        t_span = (0, self.dt)

        sol = solve_ivp(
            rhs,
            t_span,
            y0,
            method='DOP853',
            rtol=1e-9,
            atol=1e-11,
            dense_output=True
        )

        y_final = sol.sol(self.dt)
        self.Q = y_final[:len(self.Q)]
        self.P = y_final[len(self.Q):]

    def step_velocity_verlet(self) -> None:
        """
        Perform a single Velocity Verlet integration step (symplectic).

        For FPUT system with H = sum(1/2*P_k^2) + V(Q), the correct order is:
        1. v_{n+1/2} = v_n + dt/2 * a(x_n)
        2. x_{n+1} = x_n + dt * v_{n+1/2}
        3. a(x_{n+1}) = force(x_{n+1})
        4. v_{n+1} = v_{n+1/2} + dt/2 * a(x_{n+1})
        """
        # Get current acceleration
        _, dPdt = self.equations_of_motion(self.Q, self.P)
        acc = np.zeros_like(self.P)
        acc[1:self.N] = dPdt[1:self.N]

        # Half step for momentum (v_n -> v_{n+1/2})
        self.P[1:self.N] += 0.5 * self.dt * acc[1:self.N]

        # Full step for position (x_n -> x_{n+1}) using v_{n+1/2}
        self.Q[1:self.N] += self.dt * self.P[1:self.N]

        # Recompute acceleration at new position (a(x_{n+1}))
        _, dPdt_new = self.equations_of_motion(self.Q, self.P)
        acc_new = np.zeros_like(self.P)
        acc_new[1:self.N] = dPdt_new[1:self.N]

        # Half step for momentum (v_{n+1/2} -> v_{n+1})
        self.P[1:self.N] += 0.5 * self.dt * acc_new[1:self.N]

    def compute_mode_energies(self) -> np.ndarray:
        """
        Compute the energy in each normal mode.

        Returns
        -------
        energies : ndarray
            Energy in each normal mode, shape (N-1,)
        """
        from fput.normal_modes import compute_normal_mode_energies
        return compute_normal_mode_energies(
            self.Q[1:self.N],
            self.P[1:self.N],
            self.N  # Pass N (total intervals)
        )

    def run(
        self,
        total_time: float,
        save_interval: int = 10,
        integrator: str = "rk4"
    ) -> SimulationResult:
        """
        Run the simulation for a specified total time.

        Parameters
        ----------
        total_time : float
            Total simulation time.
        save_interval : int
            Save data every n steps.
        integrator : str
            Integration method: "rk4", "verlet", or "dop853".

        Returns
        -------
        result : SimulationResult
            Container with time points and mode energies.
        """
        n_steps = int(total_time / self.dt)
        n_saves = n_steps // save_interval + 1

        time_points = np.zeros(n_saves)
        mode_energies = np.zeros((n_saves, self.N_moving))

        # Initial state
        mode_energies[0] = self.compute_mode_energies()

        if integrator == "verlet":
            step_func = self.step_velocity_verlet
        elif integrator == "dop853":
            step_func = self.step_dop853
        else:
            step_func = self.step_rk4

        save_idx = 1
        for step in range(1, n_steps + 1):
            step_func()

            if step % save_interval == 0:
                time_points[save_idx] = step * self.dt
                mode_energies[save_idx] = self.compute_mode_energies()
                save_idx += 1
                if save_idx >= n_saves:
                    break

        return SimulationResult(
            time_points=time_points[:save_idx],
            mode_energies=mode_energies[:save_idx]
        )

    def get_total_energy(self) -> float:
        """Compute the total Hamiltonian of the system."""
        # Kinetic energy
        KE = 0.5 * np.sum(self.P[1:self.N]**2)

        # Potential energy - linear
        delta_Q = self.Q[1:self.N + 1] - self.Q[0:self.N]
        PE_linear = 0.5 * np.sum(delta_Q**2)

        # Potential energy - nonlinear (alpha term)
        PE_nonlinear = (self.alpha / 3) * np.sum(delta_Q**3)

        return KE + PE_linear + PE_nonlinear


class FPUTBetaSimulator(FPUTSimulator):
    """
    FPUT system with quartic (beta) nonlinearity.

    Hamiltonian: H = sum(1/2*P_k^2) + 1/2*sum((Q_{k+1}-Q_k)^2) + beta/4*sum((Q_{k+1}-Q_k)^4)

    Parameters
    ----------
    N : int
        Total number of intervals (N-1 moving particles).
    beta : float, optional
        Quartic nonlinear coupling parameter. Default is 1.0.
    dt : float, optional
        Time step for integration. Default is 0.05.
    """

    def __init__(self, N: int, beta: float = 1.0, dt: float = 0.05):
        super().__init__(N, alpha=0, dt=dt)
        self.beta = beta

    def equations_of_motion(self, Q: np.ndarray, P: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """Compute equations of motion for the FPUT-beta system."""
        dQdt = P.copy()

        dPdt = np.zeros_like(Q)
        dPdt[1:self.N] = Q[2:self.N + 1] + Q[0:self.N - 1] - 2 * Q[1:self.N]

        # Nonlinear part (beta term)
        if self.beta != 0:
            delta_plus = (Q[2:self.N + 1] - Q[1:self.N])**3
            delta_minus = (Q[1:self.N] - Q[0:self.N - 1])**3
            dPdt[1:self.N] += self.beta * (delta_plus - delta_minus)

        return dQdt, dPdt

    def get_total_energy(self) -> float:
        """Compute the total Hamiltonian of the system."""
        KE = 0.5 * np.sum(self.P[1:self.N]**2)

        delta_Q = self.Q[1:self.N + 1] - self.Q[0:self.N]
        PE_linear = 0.5 * np.sum(delta_Q**2)
        PE_nonlinear = (self.beta / 4) * np.sum(delta_Q**4)

        return KE + PE_linear + PE_nonlinear
