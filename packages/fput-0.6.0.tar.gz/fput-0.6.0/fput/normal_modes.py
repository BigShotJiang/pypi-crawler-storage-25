"""
Normal Mode Calculations for FPUT System.

This module provides functions for converting between physical coordinates
and normal mode coordinates, as well as computing mode energies.

The FPUT system has N moving particles (Q_1 to Q_N) with fixed endpoints:
Q_0 = 0 and Q_{N+1} = 0.

Following the original FPUT paper convention:
- N represents the total number of intervals in the chain
- Number of moving particles is N-1
- Frequencies: omega_k = 2*sin(k*pi/(2*N))
- Transform: A_l = sqrt(2/N) * sum Q_k * sin(k*l*pi/N)
"""

import numpy as np
from typing import Tuple, Optional


def compute_normal_mode_coordinates(Q: np.ndarray, N_intervals: int) -> np.ndarray:
    """
    Convert physical coordinates to normal mode coordinates.

    Following original FPUT paper convention:
    A_l = sqrt(2/N) * sum_{k=1}^{N-1} Q_k * sin(k*l*pi/N)

    Parameters
    ----------
    Q : ndarray
        Physical coordinates of moving particles, shape (N-1,)
    N_intervals : int
        Total number of intervals N (N-1 moving particles).

    Returns
    -------
    A : ndarray
        Normal mode coordinates, shape (N-1,)
    """
    n_particles = len(Q)
    A = np.zeros(n_particles)
    prefactor = np.sqrt(2 / N_intervals)

    k = np.arange(1, n_particles + 1)  # Particle indices: 1, 2, ..., N-1

    for l in range(1, n_particles + 1):  # Mode indices: 1, 2, ..., N-1
        A[l - 1] = prefactor * np.sum(Q * np.sin(k * l * np.pi / N_intervals))

    return A


def compute_normal_mode_velocities(P: np.ndarray, N_intervals: int) -> np.ndarray:
    """
    Convert physical velocities to normal mode velocities.

    Parameters
    ----------
    P : ndarray
        Physical momenta of moving particles, shape (N-1,)
    N_intervals : int
        Total number of intervals N.

    Returns
    -------
    A_dot : ndarray
        Normal mode velocities, shape (N-1,)
    """
    return compute_normal_mode_coordinates(P, N_intervals)


def compute_normal_mode_energies(Q: np.ndarray, P: np.ndarray, N_intervals: int) -> np.ndarray:
    """
    Compute the energy in each normal mode.

    E_k = 1/2 * (A_dot_k^2 + omega_k^2 * A_k^2)

    where omega_k = 2*sin(k*pi/(2*N))

    Parameters
    ----------
    Q : ndarray
        Physical coordinates of moving particles, shape (N-1,)
    P : ndarray
        Physical momenta of moving particles, shape (N-1,)
    N_intervals : int
        Total number of intervals N.

    Returns
    -------
    energies : ndarray
        Energy in each normal mode, shape (N-1,)
    """
    A = compute_normal_mode_coordinates(Q, N_intervals)
    A_dot = compute_normal_mode_velocities(P, N_intervals)

    # Mode frequencies: omega_k = 2*sin(k*pi/(2*N))
    n_particles = len(Q)
    k = np.arange(1, n_particles + 1)
    omega = 2 * np.sin(k * np.pi / (2 * N_intervals))

    # Mode energies
    energies = 0.5 * (A_dot**2 + omega**2 * A**2)

    return energies


def mode_energy(A: float, A_dot: float, omega: float) -> float:
    """
    Compute energy of a single normal mode.

    Parameters
    ----------
    A : float
        Mode coordinate amplitude.
    A_dot : float
        Mode velocity amplitude.
    omega : float
        Mode frequency.

    Returns
    -------
    energy : float
        Mode energy.
    """
    return 0.5 * (A_dot**2 + omega**2 * A**2)


def frequencies(N_intervals: int, n_modes: Optional[int] = None) -> np.ndarray:
    """
    Compute normal mode frequencies.

    omega_k = 2*sin(k*pi/(2*N))

    Parameters
    ----------
    N_intervals : int
        Total number of intervals N.
    n_modes : int, optional
        Number of frequencies to compute. If None, compute all N-1 modes.

    Returns
    -------
    omega : ndarray
        Mode frequencies.
    """
    if n_modes is None:
        n_modes = N_intervals - 1
    k = np.arange(1, n_modes + 1)
    return 2 * np.sin(k * np.pi / (2 * N_intervals))


def fundamental_period(N_intervals: int) -> float:
    """
    Compute the period of the fundamental (first) mode.

    T_1 = 2*pi / omega_1 where omega_1 = 2*sin(pi/(2*N))

    Parameters
    ----------
    N_intervals : int
        Total number of intervals N.

    Returns
    -------
    period : float
        Period of the fundamental mode.
    """
    omega_1 = 2 * np.sin(np.pi / (2 * N_intervals))
    return 2 * np.pi / omega_1
