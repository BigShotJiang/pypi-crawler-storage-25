"""
Visualization module for FPUT simulations.
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from typing import Optional, List, Tuple
import matplotlib.gridspec as gridspec


class FPUTVisualizer:
    """
    Create visualizations for FPUT simulation results.
    """

    def __init__(self, time_points: np.ndarray, mode_energies: np.ndarray,
                 energy_scale: float = 1.0):
        """
        Initialize the visualizer.

        Parameters
        ----------
        time_points : ndarray
            Time values.
        mode_energies : ndarray
            Mode energies over time, shape (n_time, n_modes).
        energy_scale : float, optional
            Scale factor for energy values. Default is 1.0 (no scaling).
            Use 100 for percentage representation (×100).
            This also affects normalization - energies will be divided
            by initial mode 1 energy before scaling.
        """
        self.time_points = time_points
        self.mode_energies = mode_energies
        self.n_modes = mode_energies.shape[1]
        self.energy_scale = energy_scale
        # Store initial mode 1 energy for normalization
        self.initial_mode1_energy = mode_energies[0, 0] if len(mode_energies) > 0 else 1.0

    def _get_scaled_energies(self, mode_idx: int) -> np.ndarray:
        """
        Get scaled energies for a specific mode.

        Parameters
        ----------
        mode_idx : int
            Zero-based mode index.

        Returns
        -------
        scaled : ndarray
            Scaled energy values.
        """
        raw = self.mode_energies[:, mode_idx]
        if self.energy_scale != 1.0:
            # Normalize by initial mode 1 energy, then apply scale
            return raw * self.energy_scale / self.initial_mode1_energy
        return raw

    def plot_energy_evolution(
        self,
        modes: Optional[List[int]] = None,
        figsize: Tuple[int, int] = (12, 8),
        style: str = "overlay"
    ):
        """
        Plot normal mode energy evolution.

        Parameters
        ----------
        modes : list of int, optional
            Which modes to plot (1-indexed). If None, plot first 6.
        figsize : tuple
            Figure size.
        style : str
            "overlay" for all modes on one plot,
            "stacked" for classic FPUT-style stacked plots,
            "grid" for a grid of subplots.
        """
        if modes is None:
            modes = list(range(1, min(7, self.n_modes + 1)))

        if style == "overlay":
            self._plot_overlay(modes, figsize)
        elif style == "stacked":
            self._plot_stacked(modes, figsize)
        elif style == "grid":
            self._plot_grid(modes, figsize)
        else:
            raise ValueError(f"Unknown style: {style}")

    def _plot_overlay(self, modes: List[int], figsize: Tuple[int, int]):
        fig, ax = plt.subplots(figsize=figsize)

        colors = plt.cm.tab10(np.linspace(0, 1, len(modes)))

        for i, mode in enumerate(modes):
            energies = self._get_scaled_energies(mode - 1)
            ax.plot(self.time_points, energies,
                    label=f'Mode {mode}', color=colors[i], linewidth=1.5)

        # Update label based on scale
        if self.energy_scale == 100:
            ylabel = r'$E_k \times 10^2 / E_1(0)$ (%)'
        elif self.energy_scale == 1:
            ylabel = 'Energy'
        else:
            ylabel = f'Energy (×{self.energy_scale})'

        ax.set_xlabel(r'$\omega_1 t / 2\pi$ (fundamental periods)')
        ax.set_ylabel(ylabel)
        ax.set_title('FPUT Normal Mode Energy Evolution')
        ax.legend(loc='upper right')
        ax.grid(True, alpha=0.3)
        plt.tight_layout()

    def _plot_stacked(self, modes: List[int], figsize: Tuple[int, int]):
        fig, axes = plt.subplots(len(modes), 1, figsize=figsize, sharex=True)

        for i, mode in enumerate(modes):
            ax = axes[i] if len(modes) > 1 else axes
            energies = self._get_scaled_energies(mode - 1)
            ax.plot(self.time_points, energies, 'k-', linewidth=1)
            ax.set_ylabel(f'$E_{mode}$')
            ax.set_ylim(0, np.max(energies) * 1.1)
            ax.grid(True, alpha=0.3)

        axes[-1].set_xlabel(r'$\omega_1 t / 2\pi$ (fundamental periods)')
        fig.suptitle('FPUT Normal Mode Energies', y=0.995)
        plt.tight_layout()

    def _plot_grid(self, modes: List[int], figsize: Tuple[int, int]):
        n_cols = min(3, len(modes))
        n_rows = (len(modes) + n_cols - 1) // n_cols

        fig, axes = plt.subplots(n_rows, n_cols, figsize=figsize)
        axes = axes.flatten() if n_rows * n_cols > 1 else [axes]

        for i, mode in enumerate(modes):
            ax = axes[i]
            energies = self._get_scaled_energies(mode - 1)
            ax.plot(self.time_points, energies, 'b-', linewidth=1)
            ax.set_ylabel(f'$E_{mode}$')
            ax.set_title(f'Mode {mode}')
            ax.grid(True, alpha=0.3)

        for i in range(len(modes), len(axes)):
            axes[i].set_visible(False)

        axes[-1].set_xlabel(r'$\omega_1 t / 2\pi$ (fundamental periods)')
        plt.tight_layout()

    def plot_energy_waterfall(self, modes: Optional[List[int]] = None,
                              figsize: Tuple[int, int] = (12, 8)):
        """
        Create a waterfall plot showing energy distribution over time.

        Parameters
        ----------
        modes : list of int, optional
            Which modes to include.
        figsize : tuple
            Figure size.
        """
        if modes is None:
            modes = list(range(1, min(16, self.n_modes + 1)))

        fig, ax = plt.subplots(figsize=figsize)

        # Create mesh for plotting
        T, M = np.meshgrid(self.time_points, modes)

        # Plot as filled contour with scaled energies
        energies_subset = np.column_stack([self._get_scaled_energies(m-1)
                                           for m in modes])
        cf = ax.contourf(T, M, energies_subset.T, levels=50, cmap='viridis')

        ax.set_xlabel(r'$\omega_1 t / 2\pi$ (fundamental periods)')
        ax.set_ylabel('Mode Number')
        ax.set_title('FPUT Energy Distribution Waterfall')

        # Colorbar label based on scale
        if self.energy_scale == 100:
            label = r'$E_k \times 10^2 / E_1(0)$ (%)'
        elif self.energy_scale == 1:
            label = 'Energy'
        else:
            label = f'Energy (×{self.energy_scale})'
        plt.colorbar(cf, ax=ax, label=label)

        plt.tight_layout()

    def plot_recurrence_analysis(self, figsize: Tuple[int, int] = (12, 6)):
        """
        Plot analysis of energy recurrence to the initial mode.

        Parameters
        ----------
        figsize : tuple
            Figure size.
        """
        fig, axes = plt.subplots(1, 2, figsize=figsize)

        # Left plot: Mode 1 energy (scaled)
        mode1_energies = self._get_scaled_energies(0)
        axes[0].plot(self.time_points, mode1_energies, 'b-', linewidth=1.5)
        initial_scaled = mode1_energies[0]
        axes[0].axhline(y=initial_scaled, color='r', linestyle='--',
                        label=f'Initial: {initial_scaled:.1f}%' if self.energy_scale == 100 else f'Initial: {initial_scaled:.4f}')

        # Y-axis label based on scale
        if self.energy_scale == 100:
            ylabel = r'$E_1 \times 10^2 / E_1(0)$ (%)'
        else:
            ylabel = 'Energy'

        axes[0].set_xlabel(r'$\omega_1 t / 2\pi$ (fundamental periods)')
        axes[0].set_ylabel(ylabel)
        axes[0].set_title('Mode 1 Energy Evolution')
        axes[0].legend()
        axes[0].grid(True, alpha=0.3)

        # Right plot: Energy fraction (unscaled, always shows fraction)
        total_energy = np.sum(self.mode_energies, axis=1)
        mode1_fraction = self.mode_energies[:, 0] / total_energy
        axes[1].plot(self.time_points, mode1_fraction, 'g-', linewidth=1.5)
        axes[1].set_xlabel(r'$\omega_1 t / 2\pi$ (fundamental periods)')
        axes[1].set_ylabel('Fraction of Total Energy')
        axes[1].set_title('Energy Fraction in Mode 1')
        axes[1].grid(True, alpha=0.3)

        plt.tight_layout()

    def create_animation(self, Q_history: np.ndarray, interval: int = 50):
        """
        Create an animation of the particle chain motion.

        Parameters
        ----------
        Q_history : ndarray
            Particle coordinates over time, shape (n_time, N+1).
            Includes fixed endpoints Q[0] and Q[N].
        interval : int
            Animation interval in milliseconds.

        Returns
        -------
        anim : FuncAnimation
            The animation object.
        """
        fig, ax = plt.subplots(figsize=(10, 4))

        N_moving = Q_history.shape[1] - 1  # Number of moving particles (N intervals - 1)
        x = np.arange(1, N_moving + 1)  # Particle indices: 1, 2, ..., N-1

        line, = ax.plot(x, Q_history[0, 1:-1], 'o-', linewidth=2, markersize=8)
        ax.set_ylim(np.min(Q_history) * 1.2, np.max(Q_history) * 1.2)
        ax.set_xlabel('Particle Index')
        ax.set_ylabel('Displacement')
        ax.set_title('FPUT Chain Animation')
        ax.grid(True, alpha=0.3)

        def update(frame):
            line.set_ydata(Q_history[frame, 1:-1])
            return line,

        anim = FuncAnimation(fig, update, frames=len(Q_history),
                             interval=interval, blit=True)

        return anim

    def plot_summary(self, figsize: Tuple[int, int] = (14, 10)):
        """
        Create a comprehensive summary plot.

        Parameters
        ----------
        figsize : tuple
            Figure size.
        """
        fig = plt.figure(figsize=figsize)
        gs = gridspec.GridSpec(3, 2, figure=fig, height_ratios=[2, 1, 1])

        # Y-axis label based on scale
        if self.energy_scale == 100:
            ylabel = r'$E_k \times 10^2 / E_1(0)$ (%)'
        elif self.energy_scale == 1:
            ylabel = 'Energy'
        else:
            ylabel = f'Energy (×{self.energy_scale})'

        # Main energy evolution (top, spans both columns)
        ax_main = fig.add_subplot(gs[0, :])
        for i in range(min(6, self.n_modes)):
            energies = self._get_scaled_energies(i)
            ax_main.plot(self.time_points, energies,
                         label=f'Mode {i+1}', linewidth=1.5)
        ax_main.set_ylabel(ylabel)
        ax_main.set_title('FPUT Normal Mode Energy Evolution')
        ax_main.legend(loc='upper right', ncol=6)
        ax_main.grid(True, alpha=0.3)

        # Energy waterfall (middle left)
        ax_waterfall = fig.add_subplot(gs[1, 0])
        modes_waterfall = list(range(1, min(16, self.n_modes + 1)))
        T, M = np.meshgrid(self.time_points, modes_waterfall)
        energies_subset = np.column_stack([self._get_scaled_energies(m-1)
                                           for m in modes_waterfall])
        cf = ax_waterfall.contourf(T, M, energies_subset.T, levels=50, cmap='viridis')
        ax_waterfall.set_ylabel('Mode Number')
        ax_waterfall.set_title('Energy Distribution')
        plt.colorbar(cf, ax=ax_waterfall, label=ylabel)

        # Participation ratio (middle right) - uses fractions, so unscaled
        ax_part = fig.add_subplot(gs[1, 1])
        total_energy = np.sum(self.mode_energies, axis=1)
        p = self.mode_energies / total_energy[:, np.newaxis]
        participation = 1.0 / np.sum(p**2, axis=1)
        ax_part.plot(self.time_points, participation, 'purple', linewidth=1.5)
        ax_part.set_ylabel('Effective Modes')
        ax_part.set_title('Participation Ratio')
        ax_part.grid(True, alpha=0.3)

        # Mode 1 detail (bottom left)
        ax_mode1 = fig.add_subplot(gs[2, 0])
        mode1_energies = self._get_scaled_energies(0)
        ax_mode1.plot(self.time_points, mode1_energies, 'b-', linewidth=1.5)
        ax_mode1.set_xlabel(r'$\omega_1 t / 2\pi$ (fundamental periods)')
        ax_mode1.set_ylabel(ylabel)
        ax_mode1.set_title('Mode 1 Energy')
        ax_mode1.grid(True, alpha=0.3)

        # Entropy (bottom right) - uses fractions, so unscaled
        ax_entropy = fig.add_subplot(gs[2, 1])
        entropy = -np.sum(p * np.log(p + 1e-16), axis=1)
        ax_entropy.plot(self.time_points, entropy, 'r-', linewidth=1.5)
        ax_entropy.set_xlabel(r'$\omega_1 t / 2\pi$ (fundamental periods)')
        ax_entropy.set_ylabel('Entropy')
        ax_entropy.set_title('Energy Distribution Entropy')
        ax_entropy.grid(True, alpha=0.3)

        plt.tight_layout()
        return fig
