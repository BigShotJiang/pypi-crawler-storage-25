"""
Utility functions for FPUT simulations.

This module contains general-purpose utility functions that don't fit
into other specific modules (simulator, normal_modes, analysis, visualization).
"""

import numpy as np


def validate_parameters(N: int, alpha: float = 0.0, beta: float = 0.0,
                       dt: float = 0.05) -> None:
    """
    Validate simulation parameters.

    Parameters
    ----------
    N : int
        Number of moving particles.
    alpha : float
        Quadratic nonlinear coupling parameter.
    beta : float
        Quartic nonlinear coupling parameter.
    dt : float
        Time step.

    Raises
    ------
    ValueError
        If parameters are invalid.
    """
    if N < 2:
        raise ValueError(f"N must be at least 2, got {N}")

    if dt <= 0:
        raise ValueError(f"dt must be positive, got {dt}")

    if dt > 0.5:
        raise ValueError(f"dt must be <= 0.5 for stability, got {dt}")

    if alpha == 0 and beta == 0:
        raise ValueError("At least one of alpha or beta must be non-zero")


def estimate_time_step(N: int, alpha: float = 0.25, beta: float = 0.0,
                      safety_factor: float = 0.1) -> float:
    """
    Estimate a suitable time step for the simulation.

    Parameters
    ----------
    N : int
        Number of moving particles.
    alpha : float
        Quadratic nonlinear coupling parameter.
    beta : float
        Quartic nonlinear coupling parameter.
    safety_factor : float
        Safety factor for time step (default: 0.1).

    Returns
    -------
    dt : float
        Recommended time step.
    """
    # Maximum frequency
    omega_max = 2 * np.sin(N * np.pi / (2 * (N + 1)))

    # For stability, dt * omega_max should be small
    # For nonlinear systems, we also consider the nonlinearity strength
    nonlinearity = max(abs(alpha), abs(beta))
    dt = safety_factor / (omega_max * (1 + nonlinearity))

    return min(dt, 0.1)  # Cap at 0.1 for practical reasons


def get_default_parameters(preset: str = "classic") -> dict:
    """
    Get default parameter sets for common FPUT simulations.

    Parameters
    ----------
    preset : str
        Preset name: "classic", "weak", "strong", "beta".

    Returns
    -------
    params : dict
        Dictionary of simulation parameters.
    """
    presets = {
        "classic": {
            "N": 32,
            "alpha": 0.25,
            "beta": 0.0,
            "dt": 0.05,
            "mode": 1,
            "amplitude": 4.0,
            "total_time": 160.0
        },
        "weak": {
            "N": 32,
            "alpha": 0.1,
            "beta": 0.0,
            "dt": 0.05,
            "mode": 1,
            "amplitude": 2.0,
            "total_time": 200.0
        },
        "strong": {
            "N": 16,
            "alpha": 1.0,
            "beta": 0.0,
            "dt": 0.05,
            "mode": 1,
            "amplitude": 2.0,
            "total_time": 100.0
        },
        "beta": {
            "N": 32,
            "alpha": 0.0,
            "beta": 1.0,
            "dt": 0.05,
            "mode": 1,
            "amplitude": 4.0,
            "total_time": 160.0
        }
    }

    if preset not in presets:
        available = ", ".join(presets.keys())
        raise ValueError(f"Unknown preset '{preset}'. Available: {available}")

    return presets[preset].copy()
