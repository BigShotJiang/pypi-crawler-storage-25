"""End-to-end proof: data model → JSON → GDS/OAS → read back."""

from pathlib import Path

import gdstk

from lumicron_api import (
    Cell,
    CellRef,
    FlexRoute,
    LayerMap,
    LayerSpec,
    Layout,
    Polygon,
    Port,
    Rect,
    Repetition,
)


WG = LayerSpec(layer=1, datatype=0)
CLAD = LayerSpec(layer=2, datatype=0)
MTL = LayerSpec(layer=10, datatype=0)


class TestEndToEnd:
    """Minimal proof: create → save JSON → write GDS → read back."""

    def test_single_cell_single_rect(self, tmp_path: Path):
        # Build
        c = Cell(name="TOP")
        c.add_element(Rect(corner1=(0, 0), corner2=(100, 50), layer=WG))

        layout = Layout(top_cell="TOP")
        layout.add_cell(c)

        # JSON round-trip
        json_path = tmp_path / "proof.json"
        layout.save(json_path)
        loaded = Layout.load(json_path)
        assert loaded.top_cell == "TOP"
        assert len(loaded.cells["TOP"].elements) == 1

        # GDS write + read back
        gds_path = tmp_path / "proof.gds"
        layout.to_gds(gds_path)
        lib = gdstk.read_gds(str(gds_path))
        assert len(lib.cells) == 1
        assert lib.cells[0].name == "TOP"
        assert len(lib.cells[0].polygons) == 1

        # OAS write + read back
        oas_path = tmp_path / "proof.oas"
        layout.to_oas(oas_path)
        lib2 = gdstk.read_oas(str(oas_path))
        assert len(lib2.cells) == 1

    def test_hierarchical_with_all_elements(self, tmp_path: Path):
        # Child cell with geometry and ports
        child = Cell(name="COUPLER")
        child.add_element(Rect(corner1=(0, 0), corner2=(20, 2), layer=WG))
        child.add_element(Rect(corner1=(0, -3), corner2=(20, -1), layer=WG))
        child.add_element(Polygon(
            vertices=[(0, 0), (5, 0), (5, 5), (0, 5)],
            layer=CLAD,
        ))
        child.add_port(Port(name="in", position=(0, 1), direction=180, width=0.5, layer=WG))
        child.add_port(Port(name="out", position=(20, 1), direction=0, width=0.5, layer=WG))

        # Top cell with references and a route
        top = Cell(name="TOP")
        top.add_element(CellRef(cell_name="COUPLER", origin=(0, 0)))
        top.add_element(CellRef(
            cell_name="COUPLER",
            origin=(0, 100),
            repetition=Repetition(columns=4, rows=1, spacing=(50, 0)),
        ))
        top.add_element(FlexRoute(
            points=[(20, 1), (40, 1), (40, 30)],
            width=0.5,
            layer=WG,
            bend_radius=10,
        ))
        top.add_element(Rect(corner1=(-10, -10), corner2=(250, 150), layer=MTL))

        # Layout with layer map
        layout = Layout(top_cell="TOP")
        layout.add_cell(child)
        layout.add_cell(top)
        layout.layer_map.add("WG_CORE", 1, 0)
        layout.layer_map.add("WG_CLAD", 2, 0)
        layout.layer_map.add("METAL1", 10, 0)

        # JSON round-trip
        json_path = tmp_path / "hier.json"
        layout.save(json_path)
        loaded = Layout.load(json_path)
        assert len(loaded.cells) == 2
        assert "WG_CORE" in loaded.layer_map
        coupler = loaded.cells["COUPLER"]
        assert len(coupler.ports) == 2
        assert coupler.ports["in"].direction == 180

        # GDS write + structural verification
        gds_path = tmp_path / "hier.gds"
        layout.to_gds(gds_path)
        lib = gdstk.read_gds(str(gds_path))
        assert len(lib.cells) == 2

        top_gds = [c for c in lib.cells if c.name == "TOP"][0]
        coupler_gds = [c for c in lib.cells if c.name == "COUPLER"][0]

        # TOP: 2 references + geometry (rect + flexpath, which GDS may
        # store as polygons or paths depending on gdstk version)
        assert len(top_gds.references) == 2
        total_geom = len(top_gds.polygons) + len(top_gds.paths)
        assert total_geom == 2  # 1 rect + 1 route

        # COUPLER: 2 rects + 1 polygon + 2 port markers
        assert len(coupler_gds.polygons) == 5
