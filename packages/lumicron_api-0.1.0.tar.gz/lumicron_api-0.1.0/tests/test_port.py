import pytest
from pydantic import ValidationError

from lumicron_api.models.layer import LayerSpec
from lumicron_api.models.port import Port


WG = LayerSpec(layer=1, datatype=0)


class TestPort:
    def test_create(self):
        p = Port(name="in", position=(10.0, 20.0), direction=90.0, width=0.5, layer=WG)
        assert p.name == "in"
        assert p.position == (10.0, 20.0)
        assert p.direction == 90.0
        assert p.width == 0.5
        assert p.layer == WG

    def test_defaults(self):
        p = Port(name="out", width=1.0, layer=WG)
        assert p.position == (0.0, 0.0)
        assert p.direction == 0.0

    def test_x_y_properties(self):
        p = Port(name="p", position=(3.5, 7.2), width=0.5, layer=WG)
        assert p.x == 3.5
        assert p.y == 7.2

    def test_frozen(self):
        p = Port(name="p", width=0.5, layer=WG)
        with pytest.raises(ValidationError):
            p.name = "q"

    def test_width_must_be_positive(self):
        with pytest.raises(ValidationError):
            Port(name="p", width=0.0, layer=WG)
        with pytest.raises(ValidationError):
            Port(name="p", width=-1.0, layer=WG)

    def test_translated(self):
        p = Port(name="p", position=(10.0, 20.0), direction=180.0, width=0.5, layer=WG)
        p2 = p.translated(5.0, -3.0)
        assert p2.position == (15.0, 17.0)
        assert p2.name == "p"
        assert p2.direction == 180.0
        assert p2.width == 0.5
        assert p2.layer == WG

    def test_translated_does_not_mutate(self):
        p = Port(name="p", position=(10.0, 20.0), width=0.5, layer=WG)
        p.translated(5.0, 5.0)
        assert p.position == (10.0, 20.0)

    def test_json_round_trip(self):
        p = Port(name="opt_out", position=(100.0, -50.0), direction=270.0, width=2.0, layer=WG)
        j = p.model_dump_json()
        p2 = Port.model_validate_json(j)
        assert p2.name == p.name
        assert p2.position == p.position
        assert p2.direction == p.direction
        assert p2.width == p.width
        assert p2.layer == p.layer

    def test_repr(self):
        p = Port(name="out", position=(1.0, 2.0), direction=0.0, width=0.5, layer=WG)
        r = repr(p)
        assert "'out'" in r
        assert "1.0" in r
        assert "2.0" in r
