"""Tests for the native lumicron_api Elyon Demo PDK."""

from lumicron_api.pdks.elyon_demo import LAYER, RPROF
from lumicron_api.pdks.elyon_demo.layers import layer_map, LayerSpec
from lumicron_api.pdks.elyon_demo.route_profiles import styles, RouteProfile
from lumicron_api.pdks.elyon_demo.components import (
    ChipFrame,
    EdgeCouplerSi,
    EdgeCouplerSiN,
    CVIA_comp,
    VIA1_comp,
    VIA2_comp,
    ViaArray,
    Pad,
    Label,
    YSplitter,
    NxM_MMI,
)


# ── Layers ─────────────────────────────────────────────────────

def test_layer_count():
    lm = layer_map()
    assert len(lm.layers) == 17


def test_layer_namespace():
    assert LAYER.OXID == LayerSpec(layer=1, datatype=0)
    assert LAYER.SILC == LayerSpec(layer=9, datatype=0)
    assert LAYER.TSIE == LayerSpec(layer=16, datatype=0)
    assert LAYER.OXOP == LayerSpec(layer=17, datatype=0)


def test_layer_map_matches_namespace():
    lm = layer_map()
    assert lm.layers["OXID"] == LAYER.OXID
    assert lm.layers["SILC"] == LAYER.SILC


# ── Route Profiles ─────────────────────────────────────────────

def test_rprof_namespace():
    assert isinstance(RPROF.siln_strip, RouteProfile)
    assert isinstance(RPROF.silc_strip, RouteProfile)
    assert isinstance(RPROF.silc_rib, RouteProfile)


def test_rprof_properties():
    assert RPROF.siln_strip.layer == LAYER.SILN
    assert RPROF.siln_strip.width == 0.5
    assert RPROF.siln_strip.radius == 10.0
    assert len(RPROF.siln_strip.cladding) == 1
    assert RPROF.siln_strip.cladding[0].layer == LAYER.OXID


def test_rprof_silc_rib():
    assert RPROF.silc_rib.width == 1.5
    assert RPROF.silc_rib.radius == 20.0
    assert RPROF.silc_rib.cladding == []


def test_styles_dict():
    s = styles()
    assert len(s) == 3
    assert "siln_strip" in s
    assert s["siln_strip"] is RPROF.siln_strip


# ── Components ─────────────────────────────────────────────────

def test_chip_frame():
    c = ChipFrame()
    assert len(c._cell.elements) == 4  # Four border bars
    assert len(c._handles) >= 1


def test_chip_frame_custom_params():
    c = ChipFrame(total_width=8000, total_height=5000, border_width=200)
    assert len(c._cell.elements) == 4


def test_edge_coupler_si():
    c = EdgeCouplerSi()
    assert len(c._cell.elements) == 1
    assert len(c._cell.ports) == 2
    assert "o1" in c._cell.ports
    assert "o2" in c._cell.ports
    assert c._cell.ports["o1"].layer == LAYER.SILC


def test_edge_coupler_sin():
    c = EdgeCouplerSiN()
    assert len(c._cell.elements) == 1
    assert len(c._cell.ports) == 2
    assert c._cell.ports["o1"].layer == LAYER.SILN


def test_cvia_comp():
    c = CVIA_comp()
    assert len(c._cell.elements) == 1
    elem = c._cell.elements[0]
    assert elem.layer == LAYER.CVIA


def test_via1_comp():
    c = VIA1_comp()
    assert len(c._cell.elements) == 1
    assert c._cell.elements[0].layer == LAYER.VIA1


def test_via2_comp():
    c = VIA2_comp()
    assert len(c._cell.elements) == 1
    assert c._cell.elements[0].layer == LAYER.VIA2


def test_via_array():
    c = ViaArray()
    # Should use 2D ARRAY: ViaArray → Via
    layout = c.to_layout()
    assert "Via" in layout.cells
    # Via cell should have a single rectangle on CVIA
    via_cell = layout.cells["Via"]
    assert len(via_cell.elements) == 1
    assert via_cell.elements[0].layer == LAYER.CVIA


def test_via_array_custom_layer():
    c = ViaArray(via_layer=LAYER.VIA1)
    layout = c.to_layout()
    via_cell = layout.cells["Via"]
    assert via_cell.elements[0].layer == LAYER.VIA1


def test_pad_basic():
    c = Pad()
    # At minimum: CMTL rect + OXOP rect
    assert len(c._cell.elements) >= 2


def test_pad_down_to_mtl1():
    c = Pad(pad_down_to="MTL1")
    # Should have CMTL, OXOP, MTL1 rects + CVIA ViaArray CellRef
    from lumicron_api.models.elements import Rect, CellRef
    rects = [e for e in c._cell.elements if isinstance(e, Rect)]
    refs = [e for e in c._cell.elements if isinstance(e, CellRef)]
    layers_used = {e.layer for e in rects}
    assert LAYER.CMTL in layers_used
    assert LAYER.OXOP in layers_used
    assert LAYER.MTL1 in layers_used
    assert len(refs) >= 1  # ViaArray reference


def test_label():
    c = Label(text="Hello")
    assert len(c._cell.elements) == 1
    elem = c._cell.elements[0]
    assert elem.layer == LAYER.CMTL


def test_label_custom():
    c = Label(text="Test", height=2.0, layer=LAYER.MTL1)
    elem = c._cell.elements[0]
    assert elem.layer == LAYER.MTL1


# ── Parametric cell metadata ──────────────────────────────────

def test_chip_frame_is_parametric():
    assert hasattr(ChipFrame, "params")
    assert hasattr(ChipFrame, "defaults")
    assert "total_width" in ChipFrame.defaults


def test_edge_coupler_si_params():
    assert "length" in EdgeCouplerSi.defaults
    assert "width_tip" in EdgeCouplerSi.defaults
    assert EdgeCouplerSi.defaults["length"] == 100.0


# ── YSplitter ─────────────────────────────────────────────────

def test_ysplitter_basic():
    c = YSplitter()
    assert len(c._cell.elements) == 3  # input rect + top branch + bottom branch
    assert len(c._cell.ports) == 3
    assert "i1" in c._cell.ports
    assert "o1" in c._cell.ports
    assert "o2" in c._cell.ports


def test_ysplitter_port_directions():
    c = YSplitter()
    assert c._cell.ports["i1"].direction == 180
    assert c._cell.ports["o1"].direction == 0
    assert c._cell.ports["o2"].direction == 0


def test_ysplitter_output_symmetry():
    c = YSplitter()
    o1_y = c._cell.ports["o1"].position[1]
    o2_y = c._cell.ports["o2"].position[1]
    # o1 should be above center, o2 below, symmetric
    assert o1_y > 0
    assert o2_y < 0
    assert abs(o1_y + o2_y) < 0.1  # symmetric about y=0


def test_ysplitter_custom_params():
    c = YSplitter(width=0.8, gap=0.4, layer=LAYER.SILC)
    assert c._cell.ports["i1"].width == 0.8
    assert c._cell.ports["i1"].layer == LAYER.SILC


def test_ysplitter_is_parametric():
    assert hasattr(YSplitter, "params")
    assert "width" in YSplitter.defaults
    assert "gap" in YSplitter.defaults
    assert "bend_radius" in YSplitter.defaults


def test_ysplitter_gds_export():
    c = YSplitter()
    layout = c.to_layout()
    assert "YSplitter" in layout.cells


# ── NxM_MMI ───────────────────────────────────────────────────

def test_nxm_mmi_basic():
    c = NxM_MMI()
    # Default 2x2: body rect + 2 input tapers + 2 output tapers = 5 elements
    assert len(c._cell.elements) == 5
    assert len(c._cell.ports) == 4
    assert "i1" in c._cell.ports
    assert "i2" in c._cell.ports
    assert "o1" in c._cell.ports
    assert "o2" in c._cell.ports


def test_nxm_mmi_port_directions():
    c = NxM_MMI()
    assert c._cell.ports["i1"].direction == 180
    assert c._cell.ports["i2"].direction == 180
    assert c._cell.ports["o1"].direction == 0
    assert c._cell.ports["o2"].direction == 0


def test_nxm_mmi_1x2():
    c = NxM_MMI(n_inputs=1, n_outputs=2)
    assert len(c._cell.ports) == 3
    assert "i1" in c._cell.ports
    assert "o1" in c._cell.ports
    assert "o2" in c._cell.ports


def test_nxm_mmi_2x4():
    c = NxM_MMI(n_inputs=2, n_outputs=4)
    assert len(c._cell.ports) == 6
    for i in range(1, 3):
        assert f"i{i}" in c._cell.ports
    for i in range(1, 5):
        assert f"o{i}" in c._cell.ports


def test_nxm_mmi_custom_layer():
    c = NxM_MMI(layer=LAYER.SILN)
    assert c._cell.ports["i1"].layer == LAYER.SILN


def test_nxm_mmi_is_parametric():
    assert hasattr(NxM_MMI, "params")
    assert "body_x" in NxM_MMI.defaults
    assert "n_inputs" in NxM_MMI.defaults
    assert "n_outputs" in NxM_MMI.defaults


def test_nxm_mmi_gds_export():
    c = NxM_MMI()
    layout = c.to_layout()
    assert "NxM_MMI" in layout.cells
