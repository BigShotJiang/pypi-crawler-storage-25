import tempfile
from pathlib import Path

import gdstk
import pytest
from pydantic import ValidationError

from lumicron_api.models.cell import Cell
from lumicron_api.models.elements import CellRef, FlexRoute, Polygon, Rect, Repetition
from lumicron_api.models.layer import LayerMap, LayerSpec
from lumicron_api.models.layout import Layout, PdkRef
from lumicron_api.models.port import Port


WG = LayerSpec(layer=1, datatype=0)
MTL = LayerSpec(layer=10, datatype=0)


def _simple_layout() -> Layout:
    """A minimal layout with one cell and one rect."""
    c = Cell(name="TOP")
    c.add_element(Rect(corner1=(0, 0), corner2=(100, 50), layer=WG))
    layout = Layout(top_cell="TOP")
    layout.add_cell(c)
    return layout


def _hierarchical_layout() -> Layout:
    """Layout with parent referencing a child cell."""
    child = Cell(name="CHILD")
    child.add_element(Rect(corner1=(0, 0), corner2=(10, 5), layer=WG))
    child.add_port(Port(name="out", position=(10, 2.5), direction=0, width=0.5, layer=WG))

    top = Cell(name="TOP")
    top.add_element(CellRef(cell_name="CHILD", origin=(50, 50)))
    top.add_element(CellRef(
        cell_name="CHILD",
        origin=(0, 0),
        repetition=Repetition(columns=4, rows=2, spacing=(20, 15)),
    ))

    layout = Layout(top_cell="TOP")
    layout.add_cell(child)
    layout.add_cell(top)
    return layout


# ── Creation ─────────────────────────────────────────────────


class TestLayoutCreation:
    def test_minimal(self):
        layout = Layout(top_cell="TOP")
        assert layout.top_cell == "TOP"
        assert layout.cells == {}
        assert layout.unit == 1e-6
        assert layout.precision == 1e-9

    def test_top_cell_required(self):
        with pytest.raises(ValidationError):
            Layout(top_cell="")

    def test_pdk_ref_defaults(self):
        layout = Layout(top_cell="TOP")
        assert layout.pdk.name == ""
        assert layout.pdk.version == ""

    def test_pdk_ref_set(self):
        layout = Layout(top_cell="TOP", pdk=PdkRef(name="SiPho", version="1.0"))
        assert layout.pdk.name == "SiPho"

    def test_add_cell(self):
        layout = Layout(top_cell="TOP")
        c = Cell(name="A")
        layout.add_cell(c)
        assert "A" in layout.cells

    def test_duplicate_cell_raises(self):
        layout = Layout(top_cell="TOP")
        layout.add_cell(Cell(name="A"))
        with pytest.raises(ValueError, match="already exists"):
            layout.add_cell(Cell(name="A"))


# ── JSON save / load ─────────────────────────────────────────


class TestLayoutSerialization:
    def test_simple_round_trip(self, tmp_path: Path):
        layout = _simple_layout()
        path = tmp_path / "design.json"
        layout.save(path)

        loaded = Layout.load(path)
        assert loaded.top_cell == "TOP"
        assert len(loaded.cells) == 1
        assert len(loaded.cells["TOP"].elements) == 1

    def test_hierarchical_round_trip(self, tmp_path: Path):
        layout = _hierarchical_layout()
        path = tmp_path / "design.json"
        layout.save(path)

        loaded = Layout.load(path)
        assert len(loaded.cells) == 2
        assert "CHILD" in loaded.cells
        assert "TOP" in loaded.cells
        top_refs = [e for e in loaded.cells["TOP"].elements if isinstance(e, CellRef)]
        assert len(top_refs) == 2
        assert top_refs[1].repetition is not None
        assert top_refs[1].repetition.columns == 4

    def test_preserves_ports(self, tmp_path: Path):
        layout = _hierarchical_layout()
        path = tmp_path / "design.json"
        layout.save(path)

        loaded = Layout.load(path)
        child = loaded.cells["CHILD"]
        assert "out" in child.ports
        assert child.ports["out"].position == (10, 2.5)

    def test_preserves_layer_map(self, tmp_path: Path):
        layout = _simple_layout()
        layout.layer_map.add("WG_CORE", 1, 0)
        layout.layer_map.add("METAL", 10, 0)
        path = tmp_path / "design.json"
        layout.save(path)

        loaded = Layout.load(path)
        assert "WG_CORE" in loaded.layer_map
        assert loaded.layer_map["METAL"].layer == 10

    def test_preserves_pdk(self, tmp_path: Path):
        layout = _simple_layout()
        layout.pdk = PdkRef(name="MyPDK", version="2.1")
        path = tmp_path / "design.json"
        layout.save(path)

        loaded = Layout.load(path)
        assert loaded.pdk.name == "MyPDK"
        assert loaded.pdk.version == "2.1"

    def test_preserves_units(self, tmp_path: Path):
        layout = Layout(top_cell="TOP", unit=1e-3, precision=1e-6)
        layout.add_cell(Cell(name="TOP"))
        path = tmp_path / "design.json"
        layout.save(path)

        loaded = Layout.load(path)
        assert loaded.unit == 1e-3
        assert loaded.precision == 1e-6


# ── Compile ──────────────────────────────────────────────────


class TestLayoutCompile:
    def test_compile_returns_library(self):
        layout = _simple_layout()
        lib = layout.compile()
        assert isinstance(lib, gdstk.Library)

    def test_compile_cell_count(self):
        layout = _hierarchical_layout()
        lib = layout.compile()
        assert len(lib.cells) == 2

    def test_compile_top_cell_has_geometry(self):
        layout = _simple_layout()
        lib = layout.compile()
        top = [c for c in lib.cells if c.name == "TOP"][0]
        assert len(top.polygons) == 1

    def test_compile_hierarchy_references(self):
        layout = _hierarchical_layout()
        lib = layout.compile()
        top = [c for c in lib.cells if c.name == "TOP"][0]
        assert len(top.references) == 2

    def test_compile_with_all_element_types(self):
        c = Cell(name="ALL")
        c.add_element(Rect(corner1=(0, 0), corner2=(10, 5), layer=WG))
        c.add_element(Polygon(vertices=[(0, 0), (5, 0), (2.5, 4)], layer=WG))
        c.add_element(FlexRoute(points=[(0, 0), (20, 0), (20, 20)], width=0.5, layer=WG, bend_radius=5))

        layout = Layout(top_cell="ALL")
        layout.add_cell(c)
        lib = layout.compile()
        top = [c for c in lib.cells if c.name == "ALL"][0]
        assert len(top.polygons) == 2
        assert len(top.paths) == 1


# ── GDS / OAS write ──────────────────────────────────────────


class TestLayoutWrite:
    def test_write_gds(self, tmp_path: Path):
        layout = _simple_layout()
        path = tmp_path / "out.gds"
        layout.to_gds(path)
        assert path.exists()
        assert path.stat().st_size > 0

    def test_write_oas(self, tmp_path: Path):
        layout = _simple_layout()
        path = tmp_path / "out.oas"
        layout.to_oas(path)
        assert path.exists()
        assert path.stat().st_size > 0

    def test_write_gds_hierarchical(self, tmp_path: Path):
        layout = _hierarchical_layout()
        path = tmp_path / "hier.gds"
        layout.to_gds(path)
        assert path.exists()
        # Read back with gdstk to verify structure
        lib = gdstk.read_gds(str(path))
        assert len(lib.cells) == 2

    def test_write_oas_hierarchical(self, tmp_path: Path):
        layout = _hierarchical_layout()
        path = tmp_path / "hier.oas"
        layout.to_oas(path)
        assert path.exists()
        lib = gdstk.read_oas(str(path))
        assert len(lib.cells) == 2
