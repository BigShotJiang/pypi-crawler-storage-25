"""Tests for gdsfactory PDK importer."""

import sys
import pytest

# Skip all tests if gdsfactory is not installed
gf = pytest.importorskip("gdsfactory")

sys.path.insert(0, ".")

from lumicron_api.compat.gdsfactory import (
    import_component,
    import_route_profile,
    import_route_profiles,
    import_cross_section,
    import_cross_sections,
    import_layer_map,
    import_pdk,
    _resolve_gf_layer,
)
from lumicron_api.models.layer import LayerSpec


# ── _resolve_gf_layer ──────────────────────────────────────────

def test_resolve_tuple():
    assert _resolve_gf_layer((5, 0)) == (5, 0)


def test_resolve_list():
    assert _resolve_gf_layer([9, 0]) == (9, 0)


def test_resolve_bad_raises():
    with pytest.raises(ValueError):
        _resolve_gf_layer("nonexistent")


# ── import_layer_map ───────────────────────────────────────────

def test_import_layer_map_from_elyon():
    from elyon_demo_pdk.tech.tech import LAYER as GF_LAYER

    lm = import_layer_map(GF_LAYER)
    assert len(lm.layers) == 17

    # Spot check known layers
    assert lm.layers["OXID"] == LayerSpec(layer=1, datatype=0)
    assert lm.layers["SILC"] == LayerSpec(layer=9, datatype=0)
    assert lm.layers["TSIE"] == LayerSpec(layer=16, datatype=0)


def test_import_layer_map_classic_tuple_class():
    """Test fallback for classic tuple-attribute LayerMap."""
    class FakeLayers:
        WG = (1, 0)
        SLAB = (2, 0)
        _private = (99, 0)
        some_method = lambda: None

    lm = import_layer_map(FakeLayers)
    assert len(lm.layers) == 2
    assert lm.layers["WG"] == LayerSpec(layer=1, datatype=0)
    assert lm.layers["SLAB"] == LayerSpec(layer=2, datatype=0)


# ── import_route_profiles ────────────────────────────────────

def test_import_route_profiles_from_elyon():
    from elyon_demo_pdk.tech.tech import cross_sections, LAYER as GF_LAYER

    rp = import_route_profiles(cross_sections, GF_LAYER)
    assert "siln_strip" in rp
    assert "silc_strip" in rp
    assert "silc_rib" in rp

    # Verify properties
    siln = rp["siln_strip"]
    assert siln.layer == LayerSpec(layer=5, datatype=0)
    assert siln.width == 0.5
    assert siln.radius == 10.0


# ── import_component ───────────────────────────────────────────

def test_import_taper():
    taper = gf.components.taper(length=10, width1=0.5, width2=1.0)
    cell = import_component(taper)

    assert len(cell._cell.elements) >= 1
    assert len(cell._cell.ports) == 2
    assert "o1" in cell._cell.ports
    assert "o2" in cell._cell.ports

    # Check port properties
    o1 = cell._cell.ports["o1"]
    assert o1.position == (0.0, 0.0)
    assert o1.direction == 180.0
    assert o1.width == 0.5

    o2 = cell._cell.ports["o2"]
    assert o2.position == (10.0, 0.0)
    assert o2.direction == 0.0
    assert o2.width == 1.0


def test_import_component_polygon_vertices():
    taper = gf.components.taper(length=10, width1=0.5, width2=1.0)
    cell = import_component(taper)

    poly = cell._cell.elements[0]
    assert len(poly.vertices) >= 3
    assert poly.layer == LayerSpec(layer=1, datatype=0)

    # Verify float coordinates are reasonable
    xs = [v[0] for v in poly.vertices]
    ys = [v[1] for v in poly.vertices]
    assert min(xs) == pytest.approx(0.0, abs=0.01)
    assert max(xs) == pytest.approx(10.0, abs=0.01)


def test_import_component_has_handle():
    taper = gf.components.taper(length=10, width1=0.5, width2=1.0)
    cell = import_component(taper)
    assert len(cell._handles) >= 1


# ── import_pdk ─────────────────────────────────────────────────

def test_import_pdk_full():
    from elyon_demo_pdk.tech.pdk import PDK

    layers, route_profiles = import_pdk(PDK)
    assert len(layers.layers) == 17
    assert len(route_profiles) == 3


# ── Aliases (backwards compat) ────────────────────────────────

def test_import_cross_section_alias():
    """import_cross_section should be an alias for import_route_profile."""
    assert import_cross_section is import_route_profile


def test_import_cross_sections_alias():
    """import_cross_sections should be an alias for import_route_profiles."""
    assert import_cross_sections is import_route_profiles


# ── _resolve_gf_layer edge cases ──────────────────────────────

def test_resolve_string_with_layer_map():
    class FakeLayers:
        WG = (1, 0)
    assert _resolve_gf_layer("WG", gf_layer_map=FakeLayers) == (1, 0)


def test_resolve_string_without_layer_map_raises():
    with pytest.raises(ValueError):
        _resolve_gf_layer("WG", gf_layer_map=None)


# ── import_route_profiles error handling ──────────────────────

def test_import_route_profiles_skips_failures():
    """Cross sections that fail to convert should be silently skipped."""
    def bad_xs():
        raise RuntimeError("broken")

    def good_xs():
        class FakeXS:
            layer = (1, 0)
            width = 0.5
            radius = 10.0
            radius_min = 0
            cladding_layers = []
            cladding_offsets = []
        return FakeXS()

    result = import_route_profiles({"good": good_xs, "bad": bad_xs})
    assert "good" in result
    assert "bad" not in result


# ── import_component edge cases ───────────────────────────────

def test_import_component_straight():
    """Import a straight waveguide component."""
    straight = gf.components.straight(length=50, cross_section="silc_strip")
    cell = import_component(straight)
    assert len(cell._cell.elements) >= 1
    assert len(cell._cell.ports) == 2


def test_import_component_mmi():
    """Import an MMI component with multiple ports."""
    mmi = gf.components.mmi1x2(cross_section="silc_strip")
    cell = import_component(mmi)
    assert len(cell._cell.ports) >= 3
