"""Tests for @cell_params decorator and TX_LANE integration."""

from pathlib import Path

import gdstk

from lumicron_api import CELL, ARRAY, PORT, LayerSpec, cell_params
from lumicron_api.lang.shapes import Rectangle


WG = LayerSpec(layer=1, datatype=0)


# ── @cell_params decorator ───────────────────────────────────


class TestCellParams:
    def test_introspects_defaults(self):
        @cell_params
        def MY_CELL(width=10, height=20, layer_num=1):
            return CELL("MY_CELL")

        assert MY_CELL.defaults == {"width": 10, "height": 20, "layer_num": 1}

    def test_params_metadata(self):
        @cell_params
        def MY_CELL(width=10, height=20):
            return CELL("MY_CELL")

        assert "width" in MY_CELL.params
        assert MY_CELL.params["width"]["default"] == 10

    def test_call_with_defaults(self):
        @cell_params
        def MY_CELL(size=100):
            c = CELL("MY_CELL")
            c.add(Rectangle(x_dim=size, y_dim=size, layer=WG, centered=False))
            return c

        cell = MY_CELL()
        assert cell.name == "MY_CELL"
        assert cell.bbox == (0, 0, 100, 100)

    def test_call_with_overrides(self):
        @cell_params
        def MY_CELL(size=100):
            c = CELL("MY_CELL")
            c.add(Rectangle(x_dim=size, y_dim=size, layer=WG, centered=False))
            return c

        cell = MY_CELL(size=200)
        assert cell.bbox == (0, 0, 200, 200)

    def test_preserves_function_name(self):
        @cell_params
        def FANCY_CELL(x=1):
            return CELL("FANCY")

        assert FANCY_CELL.__name__ == "FANCY_CELL"

    def test_repr(self):
        @cell_params
        def MY_CELL(a=1, b=2):
            return CELL("X")

        r = repr(MY_CELL)
        assert "MY_CELL" in r
        assert "a=1" in r
        assert "b=2" in r

    def test_no_defaults(self):
        @cell_params
        def MY_CELL(width, height):
            c = CELL("MY_CELL")
            c.add(Rectangle(x_dim=width, y_dim=height, layer=WG, centered=False))
            return c

        assert MY_CELL.defaults == {}
        cell = MY_CELL(width=50, height=30)
        assert cell.bbox == (0, 0, 50, 30)

    def test_type_annotations(self):
        @cell_params
        def MY_CELL(width: float = 10.0, count: int = 4):
            return CELL("MY_CELL")

        assert MY_CELL.params["width"]["type"] is float
        assert MY_CELL.params["count"]["type"] is int

    def test_used_as_array_component(self):
        @cell_params
        def COMP(size=10):
            c = CELL("COMP")
            c.add(Rectangle(x_dim=size, y_dim=size, layer=WG, centered=False))
            c.add(PORT("out", position=(size, size / 2), direction=0, width=0.5, layer=WG))
            return c

        top = CELL("TOP")
        arr = top.add(ARRAY(COMP, count=3, pitch=(20, 0), params=dict(size=15)))
        assert arr[0].port["out"].position == (15, 7.5)


# ── TX_LANE integration ─────────────────────────────────────


def _coupler():
    c = CELL("COUPLER")
    c.add(Rectangle(x_dim=20, y_dim=10, layer=WG, centered=False))
    c.add(PORT("in", position=(0, 5), direction=180, width=0.5, layer=WG))
    c.add(PORT("out", position=(20, 5), direction=0, width=0.5, layer=WG))
    return c


def _modulator(length=1000):
    c = CELL("MODULATOR")
    c.add(Rectangle(x_dim=length, y_dim=8, layer=WG, centered=False))
    c.add(PORT("in", position=(0, 4), direction=180, width=0.5, layer=WG))
    c.add(PORT("out", position=(length, 4), direction=0, width=0.5, layer=WG))
    return c


@cell_params
def TX_LANE(n=16, pitch=127, dx_io=250, dx_mod=650, bend_r=30):
    c = CELL("TX_LANE")
    frame = c.add(Rectangle(x_dim=6000, y_dim=3500, layer=WG, centered=False))
    io = c.add(ARRAY(_coupler, count=n, pitch=(0, pitch)))
    mods = c.add(ARRAY(_modulator, count=n, pitch=(0, pitch), params=dict(length=1000)))

    c.Place(io).at((dx_io, 0)).relative_to(frame.W).aligned_y(frame.C)
    c.Place(mods).at((dx_mod, 0)).relative_to(io.E).aligned_y(io.C)

    for i in range(n):
        c.Route(mods[i].port["out"], io[i].port["in"]) \
         .style(WG) \
         .radius(bend_r)

    return c


class TestTxLane:
    def test_params_exposed(self):
        assert TX_LANE.defaults == {
            "n": 16, "pitch": 127, "dx_io": 250, "dx_mod": 650, "bend_r": 30,
        }

    def test_default_build(self):
        cell = TX_LANE()
        assert cell.name == "TX_LANE"  # no non-default args → base name
        # frame rect + 2 arrays + 16 routes = 19 elements
        assert len(cell._cell.elements) == 19

    def test_override_count(self):
        cell = TX_LANE(n=4)
        # frame rect + 2 arrays + 4 routes = 7 elements
        assert len(cell._cell.elements) == 7

    def test_to_layout(self):
        cell = TX_LANE(n=4)
        layout = cell.to_layout()
        assert layout.top_cell == "TX_LANE_n=4"
        assert "COUPLER" in layout.cells
        assert "MODULATOR" in layout.cells
        assert "TX_LANE_n=4" in layout.cells

    def test_json_round_trip(self, tmp_path: Path):
        cell = TX_LANE(n=4)
        layout = cell.to_layout()
        path = tmp_path / "tx_lane.json"
        layout.save(path)

        from lumicron_api.models.layout import Layout
        loaded = Layout.load(path)
        assert len(loaded.cells) == 3

    def test_write_gds(self, tmp_path: Path):
        cell = TX_LANE(n=4)
        layout = cell.to_layout()
        gds_path = tmp_path / "tx_lane.gds"
        layout.to_gds(gds_path)

        lib = gdstk.read_gds(str(gds_path))
        names = {c.name for c in lib.cells}
        assert names == {"COUPLER", "MODULATOR", "TX_LANE_n=4"}

        tx = [c for c in lib.cells if c.name == "TX_LANE_n=4"][0]
        assert len(tx.references) == 2  # io array + mods array

    def test_write_oas(self, tmp_path: Path):
        cell = TX_LANE(n=4)
        layout = cell.to_layout()
        oas_path = tmp_path / "tx_lane.oas"
        layout.to_oas(oas_path)
        assert oas_path.exists()
        assert oas_path.stat().st_size > 0

    def test_full_16_channel(self, tmp_path: Path):
        """The canonical 16-channel TX_LANE — must always work."""
        cell = TX_LANE()
        layout = cell.to_layout()
        gds_path = tmp_path / "tx_lane_16.gds"
        layout.to_gds(gds_path)

        lib = gdstk.read_gds(str(gds_path))
        tx = [c for c in lib.cells if c.name == "TX_LANE"][0]
        # 1 frame rect + 16 routes (each route may produce multiple polygons
        # depending on bend complexity)
        assert len(tx.polygons) >= 17
        assert len(tx.references) == 2
