"""Tests for features added in 2026-03-29/30 sessions.

Covers: port_type, euler bends, Route kwargs, Waveguide, width_end,
promote_ports, show_ports, bend radius validation, go() dx/dy,
ArrayElementHandle rotation transforms, ArrayHandle bbox rotation,
auto-router straight-line fix, route_profile factory.
"""

import math
import warnings
from io import StringIO

import gdstk
import pytest

from lumicron_api import ARRAY, CELL, PORT, LayerSpec
from lumicron_api.lang.shapes import Rectangle
from lumicron_api.lang.waveguide import Waveguide
from lumicron_api.lang.route_profile_factory import route_profile
from lumicron_api.lang.routing import _auto_route, _validate_bend_radius
from lumicron_api.models.elements import CellRef, FlexRoute, _euler_bend_function
from lumicron_api.models.port import Port
from lumicron_api.models.route_profile import RouteProfile


WG = LayerSpec(layer=1, datatype=0)
MTL = LayerSpec(layer=10, datatype=0)


def make_coupler() -> CELL:
    c = CELL("COUPLER")
    c.add(Rectangle(x_dim=20, y_dim=10, layer=WG, centered=False))
    c.add(PORT("in", position=(0, 5), direction=180, width=0.5, layer=WG))
    c.add(PORT("out", position=(20, 5), direction=0, width=0.5, layer=WG))
    return c


# ── Port Type ───────────────────────────────────────────────


class TestPortType:
    def test_default_optical(self):
        p = Port(name="p", width=0.5, layer=WG)
        assert p.port_type == "optical"

    def test_electrical(self):
        p = Port(name="pad", width=50, layer=MTL, port_type="electrical")
        assert p.port_type == "electrical"

    def test_port_type_in_repr(self):
        p = Port(name="p", width=0.5, layer=WG, port_type="electrical")
        assert "electrical" in repr(p)

    def test_port_lang_default(self):
        c = CELL("T")
        c.add(PORT("in", position=(0, 0), width=0.5, layer=WG))
        assert c._cell.ports["in"].port_type == "optical"

    def test_port_lang_electrical(self):
        c = CELL("T")
        c.add(PORT("pad", position=(0, 0), width=50, layer=MTL, port_type="electrical"))
        assert c._cell.ports["pad"].port_type == "electrical"

    def test_port_type_preserved_in_transform(self):
        p = Port(name="p", position=(10, 0), direction=0, width=0.5, layer=WG, port_type="electrical")
        p2 = p.transformed(origin=(5, 5), rotation=90)
        assert p2.port_type == "electrical"

    def test_port_type_preserved_in_translate(self):
        p = Port(name="p", position=(0, 0), width=0.5, layer=WG, port_type="electrical")
        p2 = p.translated(10, 20)
        assert p2.port_type == "electrical"


# ── Euler Bends ─────────────────────────────────────────────


class TestEulerBend:
    def test_euler_function_returns_points(self):
        # Test with center/start_angle as gdstk would call it
        center = (0.0, 10.0)
        pts = _euler_bend_function(10.0, -math.pi / 2, 0.5, 0.0, center, 10.0)
        assert len(pts) > 2
        # Starts on the circle at start_angle=0
        assert abs(pts[0][0] - 10.0) < 1e-3
        assert abs(pts[0][1] - 10.0) < 1e-3

    def test_euler_function_negative_angle(self):
        center = (0.0, 10.0)
        pts = _euler_bend_function(10.0, -math.pi / 2, 0.3, 0.0, center, 10.0)
        assert len(pts) > 2
        # Negative angle: end should be below start
        assert pts[-1][1] < pts[0][1]

    def test_euler_function_small_angle(self):
        pts = _euler_bend_function(10.0, 1e-12, 0.5, 0.0, (0.0, 0.0), 10.0)
        assert len(pts) == 2

    def test_euler_p_zero_is_circular(self):
        # p=0 should produce exact circular arc
        center = (0.0, 10.0)
        pts = _euler_bend_function(10.0, -math.pi / 2, p=0.0,
                                    start_angle=0.0, center=center, nominal_radius=10.0)
        assert len(pts) > 2
        # End should be at center + (0, -10) = (0, 0)
        assert abs(pts[-1][0]) < 0.1
        assert abs(pts[-1][1]) < 0.1

    def test_euler_p_half_fully_euler(self):
        # p=0.5 endpoints match circular (normalized) but path shape differs
        center = (0.0, 10.0)
        pts_euler = _euler_bend_function(10.0, -math.pi / 2, p=0.5,
                                          start_angle=0.0, center=center, nominal_radius=10.0)
        pts_circ = _euler_bend_function(10.0, -math.pi / 2, p=0.0,
                                         start_angle=0.0, center=center, nominal_radius=10.0)
        # Endpoints match (both normalized to circle)
        assert abs(pts_euler[-1][0] - pts_circ[-1][0]) < 0.1
        # But midpoints differ (euler path deviates from circular)
        mid = len(pts_euler) // 2
        mid_dist = math.hypot(pts_euler[mid][0] - pts_circ[mid][0],
                              pts_euler[mid][1] - pts_circ[mid][1])
        assert mid_dist > 0.01

    def test_flexroute_euler_to_gdstk(self):
        fr = FlexRoute(
            points=[(0, 0), (50, 0), (50, 50)],
            width=0.5, layer=WG, bend_radius=10.0,
            bend_type="euler",
        )
        fp = fr.to_gdstk()
        assert isinstance(fp, gdstk.RobustPath)

    def test_flexroute_euler_with_p(self):
        fr = FlexRoute(
            points=[(0, 0), (50, 0), (50, 50)],
            width=0.5, layer=WG, bend_radius=10.0,
            bend_type="euler", bend_p=0.3,
        )
        fp = fr.to_gdstk()
        assert isinstance(fp, gdstk.RobustPath)

    def test_flexroute_circular_no_bend_function(self):
        fr = FlexRoute(
            points=[(0, 0), (50, 0), (50, 50)],
            width=0.5, layer=WG, bend_radius=10.0,
            bend_type="circular",
        )
        fp = fr.to_gdstk()
        assert isinstance(fp, gdstk.FlexPath)


# ── Route Kwargs ────────────────────────────────────────────


class TestRouteKwargs:
    def _make_cell_with_ports(self):
        c = CELL("T")
        c.add(PORT("a", position=(0, 0), direction=0, width=0.5, layer=WG))
        c.add(PORT("b", position=(100, 50), direction=180, width=0.5, layer=WG))
        return c

    def test_radius_kwarg(self):
        c = self._make_cell_with_ports()
        r = c.Route(c._cell.ports["a"], c._cell.ports["b"], radius=15)
        assert r._route.bend_radius == 15

    def test_bend_kwarg_euler(self):
        c = self._make_cell_with_ports()
        r = c.Route(c._cell.ports["a"], c._cell.ports["b"], radius=10, bend="euler")
        assert r._route.bend_type == "euler"

    def test_p_kwarg(self):
        c = self._make_cell_with_ports()
        r = c.Route(c._cell.ports["a"], c._cell.ports["b"], radius=10, bend="euler", p=0.3)
        assert r._route.bend_p == 0.3

    def test_p_without_bend_warns(self):
        c = self._make_cell_with_ports()
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            r = c.Route(c._cell.ports["a"], c._cell.ports["b"], radius=10, p=0.4)
            assert len(w) == 1
            assert "euler" in str(w[0].message).lower()
        assert r._route.bend_type == "euler"
        assert r._route.bend_p == 0.4

    def test_no_p_no_bend_defaults(self):
        c = self._make_cell_with_ports()
        r = c.Route(c._cell.ports["a"], c._cell.ports["b"], radius=10)
        assert r._route.bend_type == "circular"
        assert r._route.bend_p == 0.5

    def test_profile_kwarg(self):
        c = self._make_cell_with_ports()
        prof = RouteProfile(name="test", layer=MTL, width=2.0, radius=20.0)
        r = c.Route(c._cell.ports["a"], c._cell.ports["b"], profile=prof)
        assert r._route.layer == MTL
        assert r._route.width == 2.0
        assert r._route.bend_radius == 20.0

    def test_radius_overrides_profile(self):
        c = self._make_cell_with_ports()
        prof = RouteProfile(name="test", layer=MTL, width=2.0, radius=20.0)
        r = c.Route(c._cell.ports["a"], c._cell.ports["b"], radius=5, profile=prof)
        assert r._route.bend_radius == 5

    def test_bend_chain_method(self):
        c = self._make_cell_with_ports()
        r = c.Route(c._cell.ports["a"], c._cell.ports["b"], radius=10).bend("euler", p=0.2)
        assert r._route.bend_type == "euler"
        assert r._route.bend_p == 0.2


# ── FlexRoute width_end ─────────────────────────────────────


class TestFlexRouteWidthEnd:
    def test_no_width_end(self):
        fr = FlexRoute(points=[(0, 0), (100, 0)], width=0.5, layer=WG)
        assert fr.width_end is None
        assert fr._compute_widths() == 0.5

    def test_same_width_end(self):
        fr = FlexRoute(points=[(0, 0), (100, 0)], width=0.5, width_end=0.5, layer=WG)
        assert fr._compute_widths() == 0.5

    def test_different_width_end(self):
        fr = FlexRoute(
            points=[(0, 0), (50, 0), (100, 0)],
            width=0.2, width_end=1.0, layer=WG,
        )
        widths = fr._compute_widths()
        assert isinstance(widths, list)
        assert len(widths) == 3
        assert widths[0] == pytest.approx(0.2)
        assert widths[1] == pytest.approx(0.6)
        assert widths[2] == pytest.approx(1.0)

    def test_width_end_to_gdstk(self):
        fr = FlexRoute(
            points=[(0, 0), (50, 0), (100, 0)],
            width=0.2, width_end=1.0, layer=WG,
        )
        fp = fr.to_gdstk()
        assert isinstance(fp, gdstk.FlexPath)


# ── Waveguide ───────────────────────────────────────────────


class TestWaveguide:
    def test_basic(self):
        wg = Waveguide(
            points=[(0, 0), (50, 0), (50, 100)],
            layer=WG, width=0.5, radius=10,
        )
        assert isinstance(wg, CELL)
        assert "i1" in wg._cell.ports
        assert "o1" in wg._cell.ports

    def test_port_directions(self):
        wg = Waveguide(
            points=[(0, 0), (100, 0)],
            layer=WG, width=0.5,
        )
        # Path goes east, so i1 faces west (180°), o1 faces east (0°)
        assert wg._cell.ports["i1"].direction == pytest.approx(180)
        assert wg._cell.ports["o1"].direction == pytest.approx(0)

    def test_port_directions_vertical(self):
        wg = Waveguide(
            points=[(0, 0), (0, 100)],
            layer=WG, width=0.5,
        )
        # Path goes north, so i1 faces south (270°), o1 faces north (90°)
        assert wg._cell.ports["i1"].direction == pytest.approx(270)
        assert wg._cell.ports["o1"].direction == pytest.approx(90)

    def test_port_positions(self):
        wg = Waveguide(
            points=[(10, 20), (50, 20), (50, 80)],
            layer=WG, width=0.5,
        )
        assert wg._cell.ports["i1"].position == (10, 20)
        assert wg._cell.ports["o1"].position == (50, 80)

    def test_width_end(self):
        wg = Waveguide(
            points=[(0, 0), (100, 0)],
            layer=WG, width=0.2, width_end=1.0,
        )
        assert wg._cell.ports["i1"].width == 0.2
        assert wg._cell.ports["o1"].width == 1.0

    def test_euler_bend(self):
        wg = Waveguide(
            points=[(0, 0), (50, 0), (50, 50)],
            layer=WG, width=0.5, radius=10, bend="euler", p=0.3,
        )
        routes = [e for e in wg._cell.elements if isinstance(e, FlexRoute)]
        assert routes[0].bend_type == "euler"
        assert routes[0].bend_p == 0.3

    def test_profile(self):
        prof = RouteProfile(name="test", layer=MTL, width=2.0, radius=15.0)
        wg = Waveguide(points=[(0, 0), (100, 0)], profile=prof)
        routes = [e for e in wg._cell.elements if isinstance(e, FlexRoute)]
        assert routes[0].layer == MTL
        assert routes[0].width == 2.0
        assert routes[0].bend_radius == 15.0

    def test_requires_layer_or_profile(self):
        with pytest.raises(ValueError, match="layer"):
            Waveguide(points=[(0, 0), (100, 0)], width=0.5)

    def test_requires_width_or_profile(self):
        with pytest.raises(ValueError, match="width"):
            Waveguide(points=[(0, 0), (100, 0)], layer=WG)

    def test_requires_min_points(self):
        with pytest.raises(ValueError, match="2 points"):
            Waveguide(points=[(0, 0)], layer=WG, width=0.5)

    def test_unique_names(self):
        wg1 = Waveguide(points=[(0, 0), (100, 0)], layer=WG, width=0.5)
        wg2 = Waveguide(points=[(0, 0), (100, 0)], layer=WG, width=0.5)
        assert wg1.name != wg2.name

    def test_custom_name(self):
        wg = Waveguide(points=[(0, 0), (100, 0)], layer=WG, width=0.5, name="MySpiral")
        assert wg.name == "MySpiral"

    def test_port_type(self):
        wg = Waveguide(
            points=[(0, 0), (100, 0)],
            layer=WG, width=0.5, port_type="electrical",
        )
        assert wg._cell.ports["i1"].port_type == "electrical"
        assert wg._cell.ports["o1"].port_type == "electrical"

    def test_add_and_place(self):
        wg = Waveguide(points=[(0, 0), (50, 0), (50, 50)], layer=WG, width=0.5, radius=10)
        c = CELL("Top")
        ref = c.add(wg)
        c.Place(ref).at((100, 200))
        layout = c.to_layout()
        assert wg.name in layout.cells

    def test_route_to_waveguide_port(self):
        wg = Waveguide(points=[(0, 0), (50, 0), (50, 50)], layer=WG, width=0.5, radius=10)
        c = CELL("Top")
        c.add(PORT("src", position=(0, 0), direction=0, width=0.5, layer=WG))
        ref = c.add(wg)
        c.Place(ref).at((200, 0))
        # Should not raise
        c.Route(c._cell.ports["src"], ref.port["i1"], radius=10)


# ── Promote Ports ───────────────────────────────────────────


class TestPromotePorts:
    def test_promote_from_ref(self):
        child = CELL("Child")
        child.add(PORT("in", position=(0, 0), direction=180, width=0.5, layer=WG))
        child.add(PORT("out", position=(100, 0), direction=0, width=0.5, layer=WG))

        parent = CELL("Parent")
        ref = parent.add(child)
        parent.promote_ports(ref)

        assert "in" in parent._cell.ports
        assert "out" in parent._cell.ports

    def test_promote_with_prefix(self):
        child = CELL("Child")
        child.add(PORT("in", position=(0, 0), direction=180, width=0.5, layer=WG))

        parent = CELL("Parent")
        ref = parent.add(child)
        parent.promote_ports(ref, prefix="ch_")

        assert "ch_in" in parent._cell.ports
        assert "in" not in parent._cell.ports

    def test_promote_selective(self):
        child = CELL("Child")
        child.add(PORT("in", position=(0, 0), direction=180, width=0.5, layer=WG))
        child.add(PORT("out", position=(100, 0), direction=0, width=0.5, layer=WG))

        parent = CELL("Parent")
        ref = parent.add(child)
        parent.promote_ports(ref, ports=["in"])

        assert "in" in parent._cell.ports
        assert "out" not in parent._cell.ports

    def test_promote_from_array_element(self):
        child = make_coupler()
        parent = CELL("Parent")
        arr = parent.add(ARRAY(child, count=3, pitch=(0, 50)))
        parent.Place(arr).at((0, 0))
        parent.promote_ports(arr[0], prefix="c0_")
        parent.promote_ports(arr[1], prefix="c1_")

        assert "c0_in" in parent._cell.ports
        assert "c0_out" in parent._cell.ports
        assert "c1_in" in parent._cell.ports

    def test_promote_transforms_position(self):
        child = CELL("Child")
        child.add(PORT("in", position=(0, 0), direction=180, width=0.5, layer=WG))

        parent = CELL("Parent")
        ref = parent.add(child)
        c = parent
        c.Place(ref).at((500, 300))
        c.promote_ports(ref)

        promoted = parent._cell.ports["in"]
        assert promoted.position[0] == pytest.approx(500)
        assert promoted.position[1] == pytest.approx(300)

    def test_promote_invalid_type(self):
        parent = CELL("Parent")
        shape = parent.add(Rectangle(x_dim=10, y_dim=10, layer=WG))
        with pytest.raises(TypeError):
            parent.promote_ports(shape)


# ── Show Ports ──────────────────────────────────────────────


class TestShowPorts:
    def test_show_ports_empty(self, capsys):
        c = CELL("Empty")
        c.show_ports()
        captured = capsys.readouterr()
        assert "no ports" in captured.out

    def test_show_ports_with_ports(self, capsys):
        c = CELL("T")
        c.add(PORT("in", position=(0, 5), direction=180, width=0.5, layer=WG))
        c.add(PORT("out", position=(20, 5), direction=0, width=0.5, layer=WG, port_type="electrical"))
        c.show_ports()
        captured = capsys.readouterr()
        assert "2 ports" in captured.out
        assert "in" in captured.out
        assert "out" in captured.out
        assert "[optical]" in captured.out
        assert "[electrical]" in captured.out


# ── Bend Radius Validation ──────────────────────────────────


class TestBendRadiusValidation:
    def test_valid_segments(self):
        points = [(0, 0), (50, 0), (50, 50)]
        pa = Port(name="a", position=(0, 0), direction=0, width=0.5, layer=WG)
        pb = Port(name="b", position=(50, 50), direction=90, width=0.5, layer=WG)
        # Should not raise — 50µm segments, 10µm radius
        _validate_bend_radius(points, 10, pa, pb)

    def test_segment_too_short(self):
        points = [(0, 0), (5, 0), (5, 50)]
        pa = Port(name="a", position=(0, 0), direction=0, width=0.5, layer=WG)
        pb = Port(name="b", position=(5, 50), direction=90, width=0.5, layer=WG)
        # First segment is 5µm, but needs 10µm for the bend at the corner
        with pytest.raises(ValueError, match="too short|needs at least"):
            _validate_bend_radius(points, 10, pa, pb)

    def test_no_validation_when_radius_zero(self):
        points = [(0, 0), (1, 0), (1, 1)]
        pa = Port(name="a", position=(0, 0), direction=0, width=0.5, layer=WG)
        pb = Port(name="b", position=(1, 1), direction=90, width=0.5, layer=WG)
        # Should not raise with radius=0
        _validate_bend_radius(points, 0, pa, pb)

    def test_no_validation_for_two_points(self):
        points = [(0, 0), (1, 0)]
        pa = Port(name="a", position=(0, 0), direction=0, width=0.5, layer=WG)
        pb = Port(name="b", position=(1, 0), direction=180, width=0.5, layer=WG)
        _validate_bend_radius(points, 100, pa, pb)

    def test_route_raises_on_short_segment(self):
        c = CELL("T")
        c.add(PORT("a", position=(0, 0), direction=0, width=0.5, layer=WG))
        c.add(PORT("b", position=(5, 5), direction=180, width=0.5, layer=WG))
        # This will create a route with short segments, radius=50 should fail
        with pytest.raises(ValueError):
            c.Route(c._cell.ports["a"], c._cell.ports["b"], radius=50)._raise_if_invalid()


# ── go() dx/dy ──────────────────────────────────────────────


class TestGoDxDy:
    def test_go_dx(self):
        c = CELL("T")
        c.add(PORT("a", position=(0, 0), direction=0, width=0.5, layer=WG))
        c.add(PORT("b", position=(200, 50), direction=180, width=0.5, layer=WG))
        r = c.Route(c._cell.ports["a"], c._cell.ports["b"]) \
            .go("E", by=50, dx=10) \
            .go("N", to=50) \
            .go("E", to=200)
        # First go: 50 + dx=10 = 60 on x axis
        assert r._manual_points[1][0] == pytest.approx(60)

    def test_go_dy(self):
        c = CELL("T")
        c.add(PORT("a", position=(0, 0), direction=0, width=0.5, layer=WG))
        c.add(PORT("b", position=(200, 100), direction=180, width=0.5, layer=WG))
        r = c.Route(c._cell.ports["a"], c._cell.ports["b"]) \
            .go("N", by=50, dy=-10) \
            .go("E", to=200)
        # First go: N by 50, dy=-10 → y=40
        assert r._manual_points[1][1] == pytest.approx(40)

    def test_go_dx_dy_combined(self):
        c = CELL("T")
        c.add(PORT("a", position=(0, 0), direction=0, width=0.5, layer=WG))
        c.add(PORT("b", position=(200, 100), direction=180, width=0.5, layer=WG))
        r = c.Route(c._cell.ports["a"], c._cell.ports["b"]) \
            .go("E", by=50, dx=5, dy=10) \
            .go("N", to=100) \
            .go("E", to=200)
        assert r._manual_points[1][0] == pytest.approx(55)
        assert r._manual_points[1][1] == pytest.approx(10)


# ── ArrayElementHandle Port Transforms ──────────────────────


class TestArrayElementRotation:
    def test_rotated_array_port_direction(self):
        coupler = make_coupler()
        c = CELL("T")
        arr = c.add(ARRAY(coupler, count=2, pitch=(0, 50), rotation=90))
        c.Place(arr).at((0, 0))

        p = arr[0].port["in"]
        # Original "in" port faces 180° (west). With 90° rotation, should face 270° (south)
        assert p.direction == pytest.approx(270)

    def test_rotated_array_port_position(self):
        coupler = make_coupler()
        c = CELL("T")
        arr = c.add(ARRAY(coupler, count=2, pitch=(0, 50), rotation=90))
        c.Place(arr).at((0, 0))

        # Port position includes array centering + rotation transforms
        p = arr[0].port["in"]
        assert p.position[0] == pytest.approx(0, abs=0.1)
        assert p.position[1] == pytest.approx(-35, abs=0.1)

    def test_non_rotated_array_port_unchanged(self):
        coupler = make_coupler()
        c = CELL("T")
        arr = c.add(ARRAY(coupler, count=2, pitch=(0, 50)))
        c.Place(arr).at((0, 0))

        p = arr[0].port["in"]
        assert p.direction == pytest.approx(180)
        # Position includes array centering offset
        assert p.position[0] == pytest.approx(-10, abs=0.1)
        assert p.position[1] == pytest.approx(-25, abs=0.1)


# ── ArrayHandle Bbox with Rotation ──────────────────────────


class TestArrayBboxRotation:
    def test_rotated_array_bbox(self):
        coupler = make_coupler()  # 20x10
        c = CELL("T")
        arr = c.add(ARRAY(coupler, count=2, pitch=(0, 50), rotation=90))
        # After 90° rotation, each 20x10 element becomes 10x20
        # Element bboxes: rotated 20x10 → width=10, height=20
        bbox = arr.local_bbox
        # Width should be ~10 (rotated), height should span 2 elements
        assert bbox[2] - bbox[0] == pytest.approx(10, abs=1)


# ── Auto-Router Straight-Line Fix ───────────────────────────


class TestAutoRouterStraightLine:
    def test_perpendicular_ports_not_straight(self):
        """Two south-facing ports at different x should NOT get a straight horizontal line."""
        pa = Port(name="a", position=(0, 0), direction=270, width=0.5, layer=WG)
        pb = Port(name="b", position=(50, 0), direction=270, width=0.5, layer=WG)
        points = _auto_route(pa, pb)
        # Should not be a simple 2-point straight line
        assert len(points) > 2

    def test_aligned_opposing_ports_straight(self):
        """East-facing port to west-facing port on same y should be straight."""
        pa = Port(name="a", position=(0, 0), direction=0, width=0.5, layer=WG)
        pb = Port(name="b", position=(100, 0), direction=180, width=0.5, layer=WG)
        points = _auto_route(pa, pb)
        assert len(points) == 2
        assert points[0] == (0, 0)
        assert points[1] == (100, 0)

    def test_same_direction_not_straight(self):
        """Two east-facing ports on same y should NOT be straight."""
        pa = Port(name="a", position=(0, 0), direction=0, width=0.5, layer=WG)
        pb = Port(name="b", position=(100, 0), direction=0, width=0.5, layer=WG)
        points = _auto_route(pa, pb)
        assert len(points) > 2

    def test_vertical_straight_line(self):
        """North-facing to south-facing on same x should be straight."""
        pa = Port(name="a", position=(0, 0), direction=90, width=0.5, layer=WG)
        pb = Port(name="b", position=(0, 100), direction=270, width=0.5, layer=WG)
        points = _auto_route(pa, pb)
        assert len(points) == 2


# ── route_profile Factory ──────────────────────────────────


class TestRouteProfileFactory:
    def test_basic(self):
        rp = route_profile(WG, width=0.5, radius=10)
        assert isinstance(rp, RouteProfile)
        assert rp.layer == WG
        assert rp.width == 0.5
        assert rp.radius == 10

    def test_auto_name(self):
        rp = route_profile(WG, width=0.5, radius=10)
        assert "0.5" in rp.name
        assert "10" in rp.name

    def test_custom_name(self):
        rp = route_profile(WG, width=0.5, radius=10, name="my_strip")
        assert rp.name == "my_strip"

    def test_cladding(self):
        rp = route_profile(WG, width=0.5, cladding={MTL: 2.0})
        assert len(rp.cladding) == 1
        assert rp.cladding[0].layer == MTL
        assert rp.cladding[0].offset == 2.0

    def test_radius_min(self):
        rp = route_profile(WG, width=0.5, radius=10, radius_min=5)
        assert rp.radius_min == 5

    def test_radius_min_defaults_to_radius(self):
        rp = route_profile(WG, width=0.5, radius=10)
        assert rp.radius_min == 10


# ── Custom Bend PCell in Routes ──────────────────────────────


def _make_bend_cell(radius=15) -> CELL:
    """Create a simple 90° bend PCell for testing."""
    return Waveguide(
        points=[(0, 0), (radius, 0), (radius, radius)],
        layer=WG,
        width=0.5,
        radius=radius,
        bend="euler",
        p=0.5,
        name="TestBend90",
    )


def _make_src_dst(offset=(100, -100)):
    """Create source and destination cells with ports for routing."""
    src = CELL("Src")
    src.add(PORT("out", position=(0, 0), direction=0, width=0.5, layer=WG))
    dst = CELL("Dst")
    dst.add(PORT("in", position=(0, 0), direction=90, width=0.5, layer=WG))

    c = CELL("T")
    s = c.add(src)
    d = c.add(dst)
    c.Place(s).at((0, 0))
    c.Place(d).at(offset)
    return c, s, d


class TestCustomBendPCell:
    def test_basic_decomposition(self):
        """Route with one corner decomposes into 2 segments + 1 bend."""
        bend = _make_bend_cell()
        c, s, d = _make_src_dst()
        c.Route(s.port["out"], d.port["in"], bend=bend)

        layout = c.to_layout()
        # Count elements: 2 CellRefs (src, dst) + 2 FlexRoutes + 1 CellRef (bend)
        flexroutes = [e for e in c._cell.elements if isinstance(e, FlexRoute)]
        cellrefs = [e for e in c._cell.elements if isinstance(e, CellRef)]
        assert len(flexroutes) == 2
        assert any(cr.cell_name == "TestBend90" for cr in cellrefs)

    def test_straight_route_no_decomposition(self):
        """Straight route (no corners) stays as single FlexRoute."""
        bend = _make_bend_cell()
        src = CELL("Src")
        src.add(PORT("out", position=(0, 0), direction=0, width=0.5, layer=WG))
        dst = CELL("Dst")
        dst.add(PORT("in", position=(0, 0), direction=180, width=0.5, layer=WG))

        c = CELL("T")
        s = c.add(src)
        d = c.add(dst)
        c.Place(s).at((0, 0))
        c.Place(d).at((100, 0))
        c.Route(s.port["out"], d.port["in"], bend=bend)

        layout = c.to_layout()
        flexroutes = [e for e in c._cell.elements if isinstance(e, FlexRoute)]
        bend_refs = [e for e in c._cell.elements
                     if isinstance(e, CellRef) and e.cell_name == "TestBend90"]
        assert len(flexroutes) == 1
        assert len(bend_refs) == 0

    def test_left_turn_no_mirror(self):
        """Left (CCW) turn should have x_reflection=False."""
        bend = _make_bend_cell()
        c, s, d = _make_src_dst()
        c.Route(s.port["out"], d.port["in"], bend=bend)
        c.to_layout()

        bend_refs = [e for e in c._cell.elements
                     if isinstance(e, CellRef) and e.cell_name == "TestBend90"]
        # East→South is a right turn (CW) → x_reflection=True
        # The auto-router from (0,0) East to (100,-100) South goes East then South
        assert len(bend_refs) == 1
        assert bend_refs[0].x_reflection is True  # Right turn

    def test_right_turn_has_mirror(self):
        """Right (CW) turn should have x_reflection=True."""
        bend = _make_bend_cell()
        # src going East, dst above going South → route goes East then North (left turn)
        src = CELL("Src")
        src.add(PORT("out", position=(0, 0), direction=0, width=0.5, layer=WG))
        dst = CELL("Dst")
        dst.add(PORT("in", position=(0, 0), direction=270, width=0.5, layer=WG))

        c = CELL("T")
        s = c.add(src)
        d = c.add(dst)
        c.Place(s).at((0, 0))
        c.Place(d).at((100, 100))
        c.Route(s.port["out"], d.port["in"], bend=bend)
        c.to_layout()

        bend_refs = [e for e in c._cell.elements
                     if isinstance(e, CellRef) and e.cell_name == "TestBend90"]
        assert len(bend_refs) == 1
        assert bend_refs[0].x_reflection is False  # Left turn

    def test_multiple_corners(self):
        """Route with 2 corners decomposes into 3 segments + 2 bends."""
        bend = _make_bend_cell()
        src = CELL("Src")
        src.add(PORT("out", position=(0, 0), direction=0, width=0.5, layer=WG))
        dst = CELL("Dst")
        dst.add(PORT("in", position=(0, 0), direction=0, width=0.5, layer=WG))

        c = CELL("T")
        s = c.add(src)
        d = c.add(dst)
        c.Place(s).at((0, 0))
        c.Place(d).at((0, -200))

        # 4 points = 2 corners: (0,0)→(100,0)→(100,-200)→(0,-200)
        c.Route(s.port["out"], d.port["in"], bend=bend).go("E", by=100).go("S", by=200).go("W", by=100)
        c.to_layout()

        bend_refs = [e for e in c._cell.elements
                     if isinstance(e, CellRef) and e.cell_name == "TestBend90"]
        assert len(bend_refs) == 2

    def test_missing_i1_port_raises(self):
        """Bend PCell without i1 port raises ValueError."""
        bad_bend = CELL("BadBend")
        bad_bend.add(PORT("o1", position=(10, 10), direction=90, width=0.5, layer=WG))

        with pytest.raises(ValueError, match="missing port 'i1'"):
            c, s, d = _make_src_dst()
            c.Route(s.port["out"], d.port["in"], bend=bad_bend)

    def test_missing_o1_port_raises(self):
        """Bend PCell without o1 port raises ValueError."""
        bad_bend = CELL("BadBend2")
        bad_bend.add(PORT("i1", position=(0, 0), direction=180, width=0.5, layer=WG))

        with pytest.raises(ValueError, match="missing port 'o1'"):
            c, s, d = _make_src_dst()
            c.Route(s.port["out"], d.port["in"], bend=bad_bend)

    def test_bend_chain_method(self):
        """Can set custom bend via .bend() chain method."""
        bend = _make_bend_cell()
        c, s, d = _make_src_dst()
        c.Route(s.port["out"], d.port["in"]).bend(bend)
        c.to_layout()

        bend_refs = [e for e in c._cell.elements
                     if isinstance(e, CellRef) and e.cell_name == "TestBend90"]
        assert len(bend_refs) == 1

    def test_gds_export(self):
        """Full GDS export with custom bends doesn't crash."""
        import tempfile, os
        bend = _make_bend_cell()
        c, s, d = _make_src_dst()
        c.Route(s.port["out"], d.port["in"], bend=bend)
        layout = c.to_layout()

        with tempfile.NamedTemporaryFile(suffix=".gds", delete=False) as f:
            path = f.name
        try:
            layout.to_gds(path)
            assert os.path.getsize(path) > 0
        finally:
            os.unlink(path)

    def test_bend_dependency_in_layout(self):
        """Bend cell appears in layout cells."""
        bend = _make_bend_cell()
        c, s, d = _make_src_dst()
        c.Route(s.port["out"], d.port["in"], bend=bend)
        layout = c.to_layout()

        assert "TestBend90" in layout.cells

    def test_go_with_custom_bend(self):
        """Custom bends work with .go() manual routing."""
        bend = _make_bend_cell()
        src = CELL("Src")
        src.add(PORT("out", position=(0, 0), direction=0, width=0.5, layer=WG))
        dst = CELL("Dst")
        dst.add(PORT("in", position=(0, 0), direction=180, width=0.5, layer=WG))

        c = CELL("T")
        s = c.add(src)
        d = c.add(dst)
        c.Place(s).at((0, 0))
        c.Place(d).at((100, 100))

        c.Route(s.port["out"], d.port["in"], bend=bend).go("E", by=50).go("N", by=100).go("E", by=50)
        c.to_layout()

        bend_refs = [e for e in c._cell.elements
                     if isinstance(e, CellRef) and e.cell_name == "TestBend90"]
        assert len(bend_refs) == 2


# ── Positional Taper (at= parameter) ────────────────────────


class TestPositionalTaper:
    """Tests for start_taper(at=...) and end_taper(at=...)."""

    def _straight_route_cell(self, route_width=0.5, port_width=1.0):
        """Create a straight horizontal route 200µm long with width mismatch."""
        src = CELL("PtSrc")
        src.add(PORT("out", position=(0, 0), direction=0, width=port_width, layer=WG))
        dst = CELL("PtDst")
        dst.add(PORT("in", position=(0, 0), direction=180, width=port_width, layer=WG))
        c = CELL("PtTest")
        s = c.add(src)
        d = c.add(dst)
        c.Place(s).at((0, 0))
        c.Place(d).at((200, 0))
        return c, s, d

    def test_start_taper_at_splits_route(self):
        """Taper at=50 should split route into pre (0->50) and post (60->200)."""
        c, s, d = self._straight_route_cell()
        route = c.Route(s.port["out"], d.port["in"])
        route.start_taper(length=10, at=50)
        c.to_layout()

        flex_routes = [e for e in c._cell.elements if isinstance(e, FlexRoute)]
        # Should have 2 FlexRoute segments (pre + post)
        assert len(flex_routes) == 2
        # Should have 1 taper polygon
        from lumicron_api.models.elements import Polygon
        tapers = [e for e in c._cell.elements if isinstance(e, Polygon)]
        assert len(tapers) == 1

    def test_end_taper_at_splits_route(self):
        """end_taper(at=30) measures 30um from port B."""
        c, s, d = self._straight_route_cell()
        route = c.Route(s.port["out"], d.port["in"])
        route.end_taper(length=10, at=30)
        c.to_layout()

        flex_routes = [e for e in c._cell.elements if isinstance(e, FlexRoute)]
        assert len(flex_routes) == 2

    def test_taper_at_on_bend_warns_and_skips(self):
        """Taper overlapping a bend zone should warn and skip."""
        src = CELL("PtBendSrc")
        src.add(PORT("out", position=(0, 0), direction=0, width=1.0, layer=WG))
        dst = CELL("PtBendDst")
        dst.add(PORT("in", position=(0, 0), direction=180, width=1.0, layer=WG))
        c = CELL("PtBendTest")
        s = c.add(src)
        d = c.add(dst)
        c.Place(s).at((0, 0))
        c.Place(d).at((100, 100))

        route = c.Route(s.port["out"], d.port["in"], radius=15)
        # Place taper right where a bend would be
        pts = route._route.points
        # Compute distance to first corner
        cum = 0.0
        for i in range(len(pts) - 1):
            seg = math.hypot(pts[i+1][0] - pts[i][0], pts[i+1][1] - pts[i][1])
            if i == 0:
                corner_dist = seg
            cum += seg

        route.start_taper(length=10, at=corner_dist - 5)

        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            c.to_layout()
            bend_warnings = [x for x in w if "bend" in str(x.message).lower()]
            assert len(bend_warnings) >= 1

    def test_taper_at_exceeds_length_warns(self):
        """Taper at= beyond route length should warn and skip."""
        c, s, d = self._straight_route_cell()
        route = c.Route(s.port["out"], d.port["in"])
        route.start_taper(length=10, at=195)  # 195 + 10 = 205 > 200

        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            c.to_layout()
            length_warnings = [x for x in w if "exceeds" in str(x.message).lower()]
            assert len(length_warnings) >= 1

    def test_taper_at_correct_widths(self):
        """Pre-taper at port_a width (0.45), post-taper at port_b width (0.5)."""
        src = CELL("PtWSrc")
        src.add(PORT("out", position=(0, 0), direction=0, width=0.45, layer=WG))
        dst = CELL("PtWDst")
        dst.add(PORT("in", position=(0, 0), direction=180, width=0.5, layer=WG))
        c = CELL("PtWTest")
        s = c.add(src)
        d = c.add(dst)
        c.Place(s).at((0, 0))
        c.Place(d).at((200, 0))
        route = c.Route(s.port["out"], d.port["in"])
        route.start_taper(length=10, at=50)
        c.to_layout()

        flex_routes = [e for e in c._cell.elements if isinstance(e, FlexRoute)]
        assert len(flex_routes) == 2
        widths = sorted([r.width for r in flex_routes])
        assert abs(widths[0] - 0.45) < 1e-6  # pre-taper: port_a width
        assert abs(widths[1] - 0.5) < 1e-6   # post-taper: port_b width

    def test_taper_at_explicit_width(self):
        """Explicit width= overrides the default target width."""
        c, s, d = self._straight_route_cell()
        route = c.Route(s.port["out"], d.port["in"])
        route.start_taper(length=10, at=50, width=2.0)
        c.to_layout()

        flex_routes = [e for e in c._cell.elements if isinstance(e, FlexRoute)]
        assert len(flex_routes) == 2
        widths = sorted([r.width for r in flex_routes])
        assert abs(widths[0] - 1.0) < 1e-6  # pre-taper: port_a width
        assert abs(widths[1] - 2.0) < 1e-6  # post-taper: explicit width

    def test_taper_at_preserves_positions(self):
        """Taper at=50 on straight 200um route: pre ends at 50, post starts at 60."""
        c, s, d = self._straight_route_cell()
        route = c.Route(s.port["out"], d.port["in"])
        route.start_taper(length=10, at=50)
        c.to_layout()

        flex_routes = [e for e in c._cell.elements if isinstance(e, FlexRoute)]
        assert len(flex_routes) == 2
        all_points = []
        for r in flex_routes:
            all_points.extend(r.points)
        xs = sorted(set(p[0] for p in all_points))
        assert any(abs(x - 50.0) < 1e-3 for x in xs), f"Expected x=50 in {xs}"
        assert any(abs(x - 60.0) < 1e-3 for x in xs), f"Expected x=60 in {xs}"
