import pytest
from pydantic import ValidationError

from lumicron_api.models.cell import Cell
from lumicron_api.models.elements import CellRef, FlexRoute, Polygon, Rect
from lumicron_api.models.layer import LayerSpec
from lumicron_api.models.port import Port


WG = LayerSpec(layer=1, datatype=0)
MTL = LayerSpec(layer=10, datatype=2)


def _port(name: str, x: float = 0, y: float = 0) -> Port:
    return Port(name=name, position=(x, y), direction=0, width=0.5, layer=WG)


# ── Creation ─────────────────────────────────────────────────


class TestCellCreation:
    def test_empty_cell(self):
        c = Cell(name="TOP")
        assert c.name == "TOP"
        assert c.elements == []
        assert c.ports == {}

    def test_name_required(self):
        with pytest.raises(ValidationError):
            Cell(name="")

    def test_repr(self):
        c = Cell(name="X")
        assert "X" in repr(c)
        assert "0 elements" in repr(c)
        assert "0 ports" in repr(c)


# ── Elements ─────────────────────────────────────────────────


class TestCellElements:
    def test_add_rect(self):
        c = Cell(name="C")
        r = Rect(corner1=(0, 0), corner2=(10, 5), layer=WG)
        c.add_element(r)
        assert len(c.elements) == 1
        assert c.elements[0] is r

    def test_add_polygon(self):
        c = Cell(name="C")
        p = Polygon(vertices=[(0, 0), (1, 0), (0.5, 1)], layer=WG)
        c.add_element(p)
        assert len(c.elements) == 1

    def test_add_flexroute(self):
        c = Cell(name="C")
        fr = FlexRoute(points=[(0, 0), (50, 0)], width=0.5, layer=WG)
        c.add_element(fr)
        assert len(c.elements) == 1

    def test_add_cellref(self):
        c = Cell(name="C")
        cr = CellRef(cell_name="CHILD", origin=(100, 200))
        c.add_element(cr)
        assert len(c.elements) == 1

    def test_add_multiple(self):
        c = Cell(name="C")
        c.add_element(Rect(corner1=(0, 0), corner2=(5, 5), layer=WG))
        c.add_element(Rect(corner1=(10, 0), corner2=(15, 5), layer=MTL))
        c.add_element(CellRef(cell_name="X"))
        assert len(c.elements) == 3


# ── Ports ────────────────────────────────────────────────────


class TestCellPorts:
    def test_add_port(self):
        c = Cell(name="C")
        p = _port("in", 0, 2.5)
        c.add_port(p)
        assert "in" in c.ports
        assert c.ports["in"] is p

    def test_add_multiple_ports(self):
        c = Cell(name="C")
        c.add_port(_port("in"))
        c.add_port(_port("out", 10, 0))
        assert len(c.ports) == 2

    def test_duplicate_port_raises(self):
        c = Cell(name="C")
        c.add_port(_port("in"))
        with pytest.raises(ValueError, match="already exists"):
            c.add_port(_port("in", 5, 5))

    def test_port_key_name_mismatch_raises(self):
        with pytest.raises(ValidationError, match="does not match"):
            Cell(
                name="C",
                ports={"wrong_key": _port("actual_name")},
            )


# ── JSON round-trip ──────────────────────────────────────────


class TestCellSerialization:
    def test_empty_round_trip(self):
        c = Cell(name="EMPTY")
        j = c.model_dump_json()
        c2 = Cell.model_validate_json(j)
        assert c2.name == "EMPTY"
        assert c2.elements == []
        assert c2.ports == {}

    def test_full_round_trip(self):
        c = Cell(name="MZI")
        c.add_element(Rect(corner1=(0, 0), corner2=(100, 10), layer=WG))
        c.add_element(Polygon(vertices=[(0, 0), (5, 0), (5, 5), (0, 5)], layer=MTL))
        c.add_element(FlexRoute(
            points=[(0, 0), (20, 0), (20, 30)],
            width=0.5, layer=WG, bend_radius=10,
        ))
        c.add_element(CellRef(cell_name="COUPLER", origin=(50, 0), rotation=90))
        c.add_port(_port("in", 0, 5))
        c.add_port(_port("out", 100, 5))

        j = c.model_dump_json()
        c2 = Cell.model_validate_json(j)

        assert c2.name == "MZI"
        assert len(c2.elements) == 4
        assert [type(e).__name__ for e in c2.elements] == [
            "Rect", "Polygon", "FlexRoute", "CellRef",
        ]
        assert len(c2.ports) == 2
        assert c2.ports["in"].position == (0, 5)
        assert c2.ports["out"].position == (100, 5)

    def test_nested_cellref_round_trip(self):
        c = Cell(name="TOP")
        c.add_element(CellRef(cell_name="A", origin=(0, 0)))
        c.add_element(CellRef(cell_name="B", origin=(100, 0), rotation=45, magnification=2.0))

        j = c.model_dump_json()
        c2 = Cell.model_validate_json(j)

        refs = [e for e in c2.elements if isinstance(e, CellRef)]
        assert len(refs) == 2
        assert refs[0].cell_name == "A"
        assert refs[1].cell_name == "B"
        assert refs[1].rotation == 45
        assert refs[1].magnification == 2.0
