"""Tests for high-level shape constructors."""

import math

import pytest

from lumicron_api.models.elements import Polygon, Rect
from lumicron_api.models.layer import LayerSpec
from lumicron_api.lang.shapes import (
    Arc,
    Circle,
    Oval,
    Parallelogram,
    Rectangle,
    Ring,
    Trapezoid,
    Triangle,
)

L = LayerSpec(layer=1, datatype=0)


# ── Rectangle ──────────────────────────────────────────────────

class TestRectangle:
    def test_centered(self):
        r = Rectangle(10, 6, L)
        assert isinstance(r, Rect)
        assert r.corner1 == (-5, -3)
        assert r.corner2 == (5, 3)

    def test_not_centered(self):
        r = Rectangle(10, 6, L, centered=False)
        assert r.corner1 == (0, 0)
        assert r.corner2 == (10, 6)

    def test_layer(self):
        r = Rectangle(1, 1, L)
        assert r.layer == L


# ── Circle ─────────────────────────────────────────────────────

class TestCircle:
    def test_vertex_count(self):
        c = Circle(5, L, num_points=32)
        assert isinstance(c, Polygon)
        assert len(c.vertices) == 32

    def test_radius(self):
        c = Circle(10, L, num_points=64)
        for x, y in c.vertices:
            dist = math.sqrt(x**2 + y**2)
            assert dist == pytest.approx(10, abs=0.01)

    def test_default_64_points(self):
        c = Circle(5, L)
        assert len(c.vertices) == 64


# ── Ring ───────────────────────────────────────────────────────

class TestRing:
    def test_vertex_count(self):
        r = Ring(10, 2, L, num_points=32)
        assert len(r.vertices) == 64  # 32 outer + 32 inner

    def test_outer_inner_radii(self):
        r = Ring(10, 3, L, num_points=64)
        outer = r.vertices[:64]
        inner = r.vertices[64:]
        for x, y in outer:
            assert math.sqrt(x**2 + y**2) == pytest.approx(10, abs=0.01)
        for x, y in inner:
            assert math.sqrt(x**2 + y**2) == pytest.approx(7, abs=0.01)


# ── Oval ───────────────────────────────────────────────────────

class TestOval:
    def test_vertex_count(self):
        o = Oval(10, 5, L, num_points=48)
        assert len(o.vertices) == 48

    def test_extents(self):
        o = Oval(10, 5, L, num_points=128)
        xs = [v[0] for v in o.vertices]
        ys = [v[1] for v in o.vertices]
        assert max(xs) == pytest.approx(10, abs=0.1)
        assert max(ys) == pytest.approx(5, abs=0.1)


# ── Arc ────────────────────────────────────────────────────────

class TestArc:
    def test_90_degree_arc(self):
        a = Arc(10, 2, 0, 90, L, num_points=32)
        assert isinstance(a, Polygon)
        # 33 outer + 33 inner points
        assert len(a.vertices) == 66

    def test_full_circle_arc(self):
        a = Arc(10, 2, 0, 360, L, num_points=64)
        assert len(a.vertices) == 130  # 65 outer + 65 inner

    def test_arc_stays_in_quadrant(self):
        a = Arc(10, 1, 0, 90, L, num_points=64)
        for x, y in a.vertices:
            assert x >= -0.6  # small tolerance for inner radius
            assert y >= -0.6


# ── Triangle ───────────────────────────────────────────────────

class TestTriangle:
    def test_vertex_count(self):
        t = Triangle(10, 8, L)
        assert len(t.vertices) == 3

    def test_centered_centroid_near_origin(self):
        t = Triangle(10, 9, L, centered=True)
        cx = sum(v[0] for v in t.vertices) / 3
        cy = sum(v[1] for v in t.vertices) / 3
        assert cx == pytest.approx(0, abs=0.01)
        assert cy == pytest.approx(0, abs=0.01)

    def test_not_centered(self):
        t = Triangle(10, 8, L, centered=False)
        assert t.vertices[0] == (0, 0)
        assert t.vertices[1] == (10, 0)


# ── Parallelogram ─────────────────────────────────────────────

class TestParallelogram:
    def test_equal_widths_is_rectangle(self):
        p = Parallelogram(10, 10, 5, L, centered=False)
        xs = [v[0] for v in p.vertices]
        ys = [v[1] for v in p.vertices]
        assert min(xs) == pytest.approx(-5)
        assert max(xs) == pytest.approx(5)
        assert min(ys) == 0
        assert max(ys) == 5

    def test_different_widths(self):
        p = Parallelogram(top_width=6, bot_width=10, y_dim=5, layer=L, centered=False)
        top_verts = [(x, y) for x, y in p.vertices if y == 5]
        top_xs = sorted(v[0] for v in top_verts)
        assert top_xs[0] == pytest.approx(-3, abs=0.01)
        assert top_xs[1] == pytest.approx(3, abs=0.01)

    def test_top_x_offset(self):
        p = Parallelogram(top_width=10, bot_width=10, y_dim=5, layer=L,
                          top_x_offset=3, centered=False)
        top_verts = [(x, y) for x, y in p.vertices if y == 5]
        top_xs = sorted(v[0] for v in top_verts)
        assert top_xs[0] == pytest.approx(-2, abs=0.01)
        assert top_xs[1] == pytest.approx(8, abs=0.01)

    def test_centered(self):
        p = Parallelogram(top_width=6, bot_width=10, y_dim=5, layer=L,
                          top_x_offset=2, centered=True)
        xs = [v[0] for v in p.vertices]
        ys = [v[1] for v in p.vertices]
        cx = (min(xs) + max(xs)) / 2
        cy = (min(ys) + max(ys)) / 2
        assert cx == pytest.approx(0, abs=0.01)
        assert cy == pytest.approx(0, abs=0.01)


# ── Trapezoid ─────────────────────────────────────────────────

class TestTrapezoid:
    def test_symmetric(self):
        t = Trapezoid(6, 10, 5, L, centered=False)
        bottom = [(x, y) for x, y in t.vertices if y == 0]
        top = [(x, y) for x, y in t.vertices if y == 5]
        assert len(bottom) == 2
        assert len(top) == 2
        bw = abs(bottom[1][0] - bottom[0][0])
        tw = abs(top[1][0] - top[0][0])
        assert bw == pytest.approx(10, abs=0.01)
        assert tw == pytest.approx(6, abs=0.01)

    def test_centered(self):
        t = Trapezoid(4, 8, 6, L, centered=True)
        cy = sum(v[1] for v in t.vertices) / 4
        assert cy == pytest.approx(0, abs=0.01)


# ── Integration via lm.* ──────────────────────────────────────

def test_available_via_all():
    import lumicron_api.all as lm
    assert lm.Circle is Circle
    assert lm.Ring is Ring
    assert lm.Rectangle is Rectangle
    assert lm.Arc is Arc
    assert lm.Oval is Oval
    assert lm.Triangle is Triangle
    assert lm.Parallelogram is Parallelogram
    assert lm.Trapezoid is Trapezoid
