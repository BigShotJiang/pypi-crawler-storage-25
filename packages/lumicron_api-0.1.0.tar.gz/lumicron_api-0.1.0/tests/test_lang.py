"""Tests for the language layer: CELL, ARRAY, PORT, Place, Route."""

import tempfile
from pathlib import Path

import gdstk
import pytest

from lumicron_api import ARRAY, CELL, PORT, LayerSpec
from lumicron_api.lang.shapes import Rectangle


WG = LayerSpec(layer=1, datatype=0)
MTL = LayerSpec(layer=10, datatype=0)


# ── Test fixtures ────────────────────────────────────────────


def make_coupler() -> CELL:
    c = CELL("COUPLER")
    c.add(Rectangle(x_dim=20, y_dim=10, layer=WG, centered=False))
    c.add(PORT("in", position=(0, 5), direction=180, width=0.5, layer=WG))
    c.add(PORT("out", position=(20, 5), direction=0, width=0.5, layer=WG))
    return c


def make_modulator(length: float = 500) -> CELL:
    c = CELL("MODULATOR")
    c.add(Rectangle(x_dim=length, y_dim=8, layer=WG, centered=False))
    c.add(PORT("in", position=(0, 4), direction=180, width=0.5, layer=WG))
    c.add(PORT("out", position=(length, 4), direction=0, width=0.5, layer=WG))
    return c


# ── CELL basics ──────────────────────────────────────────────


class TestCELL:
    def test_create(self):
        c = CELL("TEST")
        assert c.name == "TEST"
        assert len(c._cell.elements) == 0

    def test_repr(self):
        c = CELL("X")
        assert "X" in repr(c)

    def test_bbox_empty(self):
        c = CELL("EMPTY")
        assert c.bbox == (0, 0, 0, 0)


# ── PORT ─────────────────────────────────────────────────────


class TestPORT:
    def test_add_port(self):
        c = CELL("T")
        result = c.add(PORT("in", position=(0, 5), direction=180, width=0.5, layer=WG))
        assert result is None
        assert "in" in c._cell.ports
        assert c._cell.ports["in"].position == (0, 5)

    def test_add_multiple_ports(self):
        c = CELL("T")
        c.add(PORT("in", position=(0, 0), width=0.5, layer=WG))
        c.add(PORT("out", position=(10, 0), width=0.5, layer=WG))
        assert len(c._cell.ports) == 2


# ── Shapes as placeable elements ─────────────────────────────


class TestShapeHandle:
    def test_add_rect(self):
        c = CELL("T")
        h = c.add(Rectangle(x_dim=100, y_dim=50, layer=WG, centered=False))
        assert h.C == (50, 25)
        assert h.W == (0, 25)
        assert h.E == (100, 25)
        assert h.N == (50, 50)
        assert h.S == (50, 0)
        assert h.NE == (100, 50)
        assert h.SW == (0, 0)

    def test_shape_updates_bbox(self):
        c = CELL("T")
        c.add(Rectangle(x_dim=200, y_dim=100, layer=WG, centered=False))
        assert c.bbox == (0, 0, 200, 100)

    def test_shape_custom_layer(self):
        c = CELL("T")
        c.add(Rectangle(x_dim=10, y_dim=10, layer=MTL, centered=False))
        assert c._cell.elements[0].layer == MTL


# ── ARRAY ────────────────────────────────────────────────────


class TestARRAY:
    def test_add_array(self):
        COUPLER = make_coupler()
        c = CELL("T")
        arr = c.add(ARRAY(COUPLER, count=4, pitch=(0, 127)))
        assert arr._count == 4

    def test_array_bbox(self):
        COUPLER = make_coupler()
        c = CELL("T")
        arr = c.add(ARRAY(COUPLER, count=4, pitch=(0, 127)))
        # COUPLER is 20x10, 4 elements at y=0,127,254,381
        # bbox: (0, 0, 20, 381+10) = (0, 0, 20, 391)
        assert arr.local_bbox == (0, 0, 20, 391)

    def test_array_indexing(self):
        COUPLER = make_coupler()
        c = CELL("T")
        arr = c.add(ARRAY(COUPLER, count=4, pitch=(0, 127)))
        elem = arr[0]
        assert elem.C == (10, 5)
        elem3 = arr[3]
        assert elem3.C == (10, 381 + 5)

    def test_array_first_last(self):
        COUPLER = make_coupler()
        c = CELL("T")
        arr = c.add(ARRAY(COUPLER, count=4, pitch=(0, 127)))
        assert arr.first().C == arr[0].C
        assert arr.last().C == arr[3].C

    def test_array_index_out_of_range(self):
        COUPLER = make_coupler()
        c = CELL("T")
        arr = c.add(ARRAY(COUPLER, count=4, pitch=(0, 127)))
        with pytest.raises(IndexError):
            arr[4]
        with pytest.raises(IndexError):
            arr[-1]

    def test_array_port_access(self):
        COUPLER = make_coupler()
        c = CELL("T")
        arr = c.add(ARRAY(COUPLER, count=4, pitch=(0, 127)))
        p_in = arr[0].port["in"]
        assert p_in.position == (0, 5)
        p_out = arr[2].port["out"]
        assert p_out.position == (20, 254 + 5)

    def test_array_with_callable(self):
        c = CELL("T")
        arr = c.add(ARRAY(make_modulator, count=2, pitch=(0, 50), params=dict(length=1000)))
        # Should have created a MODULATOR with length=1000
        assert arr._component.bbox == (0, 0, 1000, 8)

    def test_array_horizontal(self):
        COUPLER = make_coupler()
        c = CELL("T")
        arr = c.add(ARRAY(COUPLER, count=3, pitch=(50, 0)))
        assert arr[0].C == (10, 5)
        assert arr[1].C == (60, 5)
        assert arr[2].C == (110, 5)


# ── Single cell reference ────────────────────────────────────


class TestRefHandle:
    def test_add_cell_ref(self):
        COUPLER = make_coupler()
        c = CELL("T")
        ref = c.add(COUPLER)
        assert ref.C == (10, 5)
        assert ref.W == (0, 5)
        assert ref.E == (20, 5)

    def test_ref_port_access(self):
        COUPLER = make_coupler()
        c = CELL("T")
        ref = c.add(COUPLER)
        assert ref.port["in"].position == (0, 5)
        assert ref.port["out"].position == (20, 5)


# ── Place ────────────────────────────────────────────────────


class TestPlace:
    def test_place_at(self):
        c = CELL("T")
        shape = c.add(Rectangle(x_dim=100, y_dim=50, layer=WG, centered=False))
        # Place so center is at (200, 100)
        c.Place(shape).at((200, 100))
        assert shape.C == (200, 100)

    def test_place_using(self):
        c = CELL("T")
        shape = c.add(Rectangle(x_dim=100, y_dim=50, layer=WG, centered=False))
        # Place so SW corner is at (0, 0)
        c.Place(shape).using("SW").at((0, 0))
        assert shape.SW == (0, 0)
        assert shape.C == (50, 25)

    def test_place_relative_to(self):
        c = CELL("T")
        frame = c.add(Rectangle(x_dim=6000, y_dim=3500, layer=WG, centered=False))
        obj = c.add(Rectangle(x_dim=20, y_dim=10, layer=WG, centered=False))
        c.Place(obj).at((250, 0)).relative_to(frame.W)
        # frame.W = (0, 1750), offset = (250, 0) -> target = (250, 1750)
        # anchor is center of obj -> (10, 5), origin = (250-10, 1750-5) = (240, 1745)
        assert obj.C == (250, 1750)

    def test_place_aligned_y(self):
        c = CELL("T")
        frame = c.add(Rectangle(x_dim=6000, y_dim=3500, layer=WG, centered=False))
        obj = c.add(Rectangle(x_dim=20, y_dim=10, layer=WG, centered=False))
        c.Place(obj).at((250, 0)).relative_to(frame.W).aligned_y(frame.C)
        # frame.C = (3000, 1750), aligned_y overrides y to 1750
        # x from frame.W + 250 = 250
        assert obj.C[0] == pytest.approx(250)
        assert obj.C[1] == pytest.approx(1750)

    def test_place_aligned_x(self):
        c = CELL("T")
        frame = c.add(Rectangle(x_dim=6000, y_dim=3500, layer=WG, centered=False))
        obj = c.add(Rectangle(x_dim=20, y_dim=10, layer=WG, centered=False))
        c.Place(obj).at((0, 100)).relative_to(frame.S).aligned_x(frame.C)
        # aligned_x overrides x to frame.C.x = 3000
        assert obj.C[0] == pytest.approx(3000)

    def test_place_array_with_anchors(self):
        COUPLER = make_coupler()
        c = CELL("T")
        frame = c.add(Rectangle(x_dim=6000, y_dim=3500, layer=WG, centered=False))
        io = c.add(ARRAY(COUPLER, count=4, pitch=(0, 127)))
        c.Place(io).at((250, 0)).relative_to(frame.W).aligned_y(frame.C)

        # After placement, io center y should be at frame center y
        assert io.C[1] == pytest.approx(1750)
        # io center x should be at frame.W.x + 250 = 250
        assert io.C[0] == pytest.approx(250)

    def test_place_updates_port_positions(self):
        COUPLER = make_coupler()
        c = CELL("T")
        arr = c.add(ARRAY(COUPLER, count=2, pitch=(0, 100)))
        c.Place(arr).using("SW").at((500, 500))

        # arr[0] is at offset (0, 0) from array origin = (500, 500)
        p_in = arr[0].port["in"]
        assert p_in.position == (500, 505)
        p_out = arr[1].port["out"]
        assert p_out.position == (520, 605)


# ── Route ────────────────────────────────────────────────────


class TestRoute:
    def test_route_straight(self):
        COUPLER = make_coupler()
        c = CELL("T")
        arr = c.add(ARRAY(COUPLER, count=2, pitch=(100, 0)))

        p_out = arr[0].port["out"]
        p_in = arr[1].port["in"]
        c.Route(p_out, p_in).radius(10)

        # Should have added a FlexRoute element
        from lumicron_api.models.elements import FlexRoute
        routes = [e for e in c._cell.elements if isinstance(e, FlexRoute)]
        assert len(routes) == 1
        assert routes[0].bend_radius == 10

    def test_route_z_shape(self):
        COUPLER = make_coupler()
        c = CELL("T")
        arr = c.add(ARRAY(COUPLER, count=2, pitch=(100, 50)))

        p_out = arr[0].port["out"]
        p_in = arr[1].port["in"]
        c.Route(p_out, p_in)

        from lumicron_api.models.elements import FlexRoute
        routes = [e for e in c._cell.elements if isinstance(e, FlexRoute)]
        assert len(routes) == 1
        # Direction-aware route: exit stubs + L/Z connection
        assert len(routes[0].points) >= 4

    def test_route_style_layerspec(self):
        COUPLER = make_coupler()
        c = CELL("T")
        arr = c.add(ARRAY(COUPLER, count=2, pitch=(100, 0)))
        c.Route(arr[0].port["out"], arr[1].port["in"]).style(MTL)

        from lumicron_api.models.elements import FlexRoute
        route = [e for e in c._cell.elements if isinstance(e, FlexRoute)][0]
        assert route.layer == MTL

    def test_route_style_string(self):
        COUPLER = make_coupler()
        c = CELL("T")
        c.styles["wg"] = WG
        arr = c.add(ARRAY(COUPLER, count=2, pitch=(100, 0)))
        c.Route(arr[0].port["out"], arr[1].port["in"]).style("wg")

        from lumicron_api.models.elements import FlexRoute
        route = [e for e in c._cell.elements if isinstance(e, FlexRoute)][0]
        assert route.layer == WG

    def test_route_manual_go(self):
        COUPLER = make_coupler()
        c = CELL("T")
        arr = c.add(ARRAY(COUPLER, count=2, pitch=(0, 100)))
        p_out = arr[0].port["out"]
        p_in = arr[1].port["in"]

        c.Route(p_out, p_in).go("E", by=30).go("N", to=p_in.y).radius(10)

        from lumicron_api.models.elements import FlexRoute
        route = [e for e in c._cell.elements if isinstance(e, FlexRoute)][0]
        # Manual: start + 2 go points + endpoint
        assert len(route.points) == 4
        assert route.bend_radius == 10


# ── to_layout / GDS export ──────────────────────────────────


class TestLayoutExport:
    def test_to_layout(self):
        COUPLER = make_coupler()
        c = CELL("TOP")
        c.add(ARRAY(COUPLER, count=4, pitch=(0, 127)))
        layout = c.to_layout()
        assert "TOP" in layout.cells
        assert "COUPLER" in layout.cells
        assert layout.top_cell == "TOP"

    def test_transitive_dependencies(self):
        inner = CELL("INNER")
        inner.add(Rectangle(x_dim=5, y_dim=5, layer=WG, centered=False))

        mid = CELL("MID")
        mid.add(inner)

        top = CELL("TOP")
        top.add(mid)

        layout = top.to_layout()
        assert len(layout.cells) == 3
        assert "INNER" in layout.cells
        assert "MID" in layout.cells
        assert "TOP" in layout.cells

    def test_write_gds(self, tmp_path: Path):
        COUPLER = make_coupler()
        c = CELL("TOP")
        frame = c.add(Rectangle(x_dim=6000, y_dim=3500, layer=WG, centered=False))
        io = c.add(ARRAY(COUPLER, count=4, pitch=(0, 127)))
        c.Place(io).at((250, 0)).relative_to(frame.W).aligned_y(frame.C)

        for i in range(3):
            c.Route(io[i].port["out"], io[i + 1].port["in"]).radius(10)

        layout = c.to_layout()
        gds_path = tmp_path / "lang_test.gds"
        layout.to_gds(gds_path)

        lib = gdstk.read_gds(str(gds_path))
        assert len(lib.cells) == 2
        top = [cell for cell in lib.cells if cell.name == "TOP"][0]
        assert len(top.references) >= 1

    def test_write_json_round_trip(self, tmp_path: Path):
        COUPLER = make_coupler()
        c = CELL("TOP")
        c.add(ARRAY(COUPLER, count=2, pitch=(0, 50)))

        layout = c.to_layout()
        json_path = tmp_path / "lang_test.json"
        layout.save(json_path)

        from lumicron_api.models.layout import Layout
        loaded = Layout.load(json_path)
        assert "TOP" in loaded.cells
        assert "COUPLER" in loaded.cells
