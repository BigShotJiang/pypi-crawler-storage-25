import math

import gdstk
import pytest
from pydantic import TypeAdapter, ValidationError

from lumicron_api.models.layer import LayerSpec
from lumicron_api.models.elements import (
    CellRef,
    Element,
    FlexRoute,
    Polygon,
    Rect,
    Repetition,
)


WG = LayerSpec(layer=1, datatype=0)
MTL = LayerSpec(layer=10, datatype=2)


# ── Rect ─────────────────────────────────────────────────────


class TestRect:
    def test_create(self):
        r = Rect(corner1=(0, 0), corner2=(10, 5), layer=WG)
        assert r.type == "rect"
        assert r.corner1 == (0, 0)
        assert r.corner2 == (10, 5)
        assert r.layer == WG

    def test_to_gdstk(self):
        r = Rect(corner1=(0, 0), corner2=(10, 5), layer=MTL)
        poly = r.to_gdstk()
        assert isinstance(poly, gdstk.Polygon)
        assert poly.layer == 10
        assert poly.datatype == 2
        assert len(poly.points) == 4

    def test_json_round_trip(self):
        r = Rect(corner1=(1.5, 2.5), corner2=(11.5, 7.5), layer=WG)
        j = r.model_dump_json()
        r2 = Rect.model_validate_json(j)
        assert r2.corner1 == r.corner1
        assert r2.corner2 == r.corner2
        assert r2.layer == r.layer


# ── Polygon ──────────────────────────────────────────────────


class TestPolygon:
    def test_create(self):
        p = Polygon(vertices=[(0, 0), (10, 0), (5, 8)], layer=WG)
        assert p.type == "polygon"
        assert len(p.vertices) == 3

    def test_min_vertices(self):
        with pytest.raises(ValidationError):
            Polygon(vertices=[(0, 0), (1, 0)], layer=WG)

    def test_to_gdstk(self):
        verts = [(0, 0), (10, 0), (10, 10), (0, 10)]
        p = Polygon(vertices=verts, layer=WG)
        gp = p.to_gdstk()
        assert isinstance(gp, gdstk.Polygon)
        assert gp.layer == 1
        assert len(gp.points) == 4

    def test_json_round_trip(self):
        verts = [(0, 0), (3, 0), (3, 4), (0, 4)]
        p = Polygon(vertices=verts, layer=MTL)
        j = p.model_dump_json()
        p2 = Polygon.model_validate_json(j)
        assert p2.vertices == p.vertices
        assert p2.layer == p.layer


# ── FlexRoute ────────────────────────────────────────────────


class TestFlexRoute:
    def test_create(self):
        fr = FlexRoute(points=[(0, 0), (100, 0)], width=0.5, layer=WG)
        assert fr.type == "flexroute"
        assert fr.bend_radius == 0.0

    def test_min_points(self):
        with pytest.raises(ValidationError):
            FlexRoute(points=[(0, 0)], width=0.5, layer=WG)

    def test_width_positive(self):
        with pytest.raises(ValidationError):
            FlexRoute(points=[(0, 0), (1, 0)], width=0, layer=WG)

    def test_bend_radius_non_negative(self):
        with pytest.raises(ValidationError):
            FlexRoute(points=[(0, 0), (1, 0)], width=0.5, layer=WG, bend_radius=-1)

    def test_to_gdstk_straight(self):
        fr = FlexRoute(points=[(0, 0), (100, 0)], width=0.5, layer=WG)
        fp = fr.to_gdstk()
        assert isinstance(fp, gdstk.FlexPath)

    def test_to_gdstk_with_bend(self):
        fr = FlexRoute(
            points=[(0, 0), (50, 0), (50, 50)],
            width=0.5,
            layer=WG,
            bend_radius=10,
        )
        fp = fr.to_gdstk()
        assert isinstance(fp, gdstk.FlexPath)

    def test_json_round_trip(self):
        fr = FlexRoute(
            points=[(0, 0), (50, 0), (50, 50)],
            width=0.5,
            layer=MTL,
            bend_radius=15.0,
        )
        j = fr.model_dump_json()
        fr2 = FlexRoute.model_validate_json(j)
        assert fr2.points == fr.points
        assert fr2.width == fr.width
        assert fr2.bend_radius == fr.bend_radius
        assert fr2.layer == fr.layer


# ── Repetition ───────────────────────────────────────────────


class TestRepetition:
    def test_create(self):
        rep = Repetition(columns=4, rows=2, spacing=(100, 200))
        assert rep.columns == 4
        assert rep.rows == 2

    def test_columns_min(self):
        with pytest.raises(ValidationError):
            Repetition(columns=0, rows=1, spacing=(10, 0))

    def test_to_gdstk(self):
        rep = Repetition(columns=3, rows=5, spacing=(50, 80))
        gr = rep.to_gdstk()
        assert isinstance(gr, gdstk.Repetition)
        assert gr.size == 15

    def test_json_round_trip(self):
        rep = Repetition(columns=4, rows=2, spacing=(100, 200))
        j = rep.model_dump_json()
        rep2 = Repetition.model_validate_json(j)
        assert rep2.columns == rep.columns
        assert rep2.rows == rep.rows
        assert rep2.spacing == rep.spacing


# ── CellRef ──────────────────────────────────────────────────


class TestCellRef:
    def _make_cell_map(self, name: str = "CHILD") -> dict[str, gdstk.Cell]:
        return {name: gdstk.Cell(name)}

    def test_create_defaults(self):
        cr = CellRef(cell_name="CHILD")
        assert cr.type == "cellref"
        assert cr.origin == (0.0, 0.0)
        assert cr.rotation == 0.0
        assert cr.magnification == 1.0
        assert cr.x_reflection is False
        assert cr.repetition is None

    def test_to_gdstk_simple(self):
        cr = CellRef(cell_name="CHILD", origin=(10, 20))
        ref = cr.to_gdstk(self._make_cell_map())
        assert isinstance(ref, gdstk.Reference)
        assert tuple(ref.origin) == (10.0, 20.0)

    def test_to_gdstk_rotation_in_radians(self):
        cr = CellRef(cell_name="CHILD", rotation=90.0)
        ref = cr.to_gdstk(self._make_cell_map())
        assert abs(ref.rotation - math.radians(90)) < 1e-10

    def test_to_gdstk_with_repetition(self):
        rep = Repetition(columns=4, rows=2, spacing=(50, 100))
        cr = CellRef(cell_name="CHILD", repetition=rep)
        ref = cr.to_gdstk(self._make_cell_map())
        assert ref.repetition is not None
        assert ref.repetition.size == 8

    def test_to_gdstk_missing_cell_raises(self):
        cr = CellRef(cell_name="MISSING")
        with pytest.raises(KeyError):
            cr.to_gdstk({})

    def test_to_gdstk_all_transforms(self):
        cr = CellRef(
            cell_name="CHILD",
            origin=(5, 10),
            rotation=45.0,
            magnification=2.0,
            x_reflection=True,
        )
        ref = cr.to_gdstk(self._make_cell_map())
        assert abs(ref.rotation - math.radians(45)) < 1e-10
        assert ref.magnification == 2.0
        assert ref.x_reflection is True

    def test_json_round_trip_simple(self):
        cr = CellRef(cell_name="CHILD", origin=(10, 20), rotation=90)
        j = cr.model_dump_json()
        cr2 = CellRef.model_validate_json(j)
        assert cr2.cell_name == cr.cell_name
        assert cr2.origin == cr.origin
        assert cr2.rotation == cr.rotation

    def test_json_round_trip_with_repetition(self):
        rep = Repetition(columns=3, rows=2, spacing=(100, 50))
        cr = CellRef(cell_name="CHILD", repetition=rep)
        j = cr.model_dump_json()
        cr2 = CellRef.model_validate_json(j)
        assert cr2.repetition is not None
        assert cr2.repetition.columns == 3
        assert cr2.repetition.rows == 2


# ── Discriminated union ──────────────────────────────────────


class TestElementUnion:
    def test_round_trip_mixed_list(self):
        elements: list[Element] = [
            Rect(corner1=(0, 0), corner2=(10, 5), layer=WG),
            Polygon(vertices=[(0, 0), (10, 0), (5, 8)], layer=WG),
            FlexRoute(points=[(0, 0), (50, 0)], width=0.5, layer=MTL),
            CellRef(cell_name="X", origin=(1, 2)),
        ]
        ta = TypeAdapter(list[Element])
        j = ta.dump_json(elements)
        restored = ta.validate_json(j)
        assert [type(e).__name__ for e in restored] == [
            "Rect", "Polygon", "FlexRoute", "CellRef"
        ]

    def test_discriminator_rejects_bad_type(self):
        ta = TypeAdapter(Element)
        with pytest.raises(ValidationError):
            ta.validate_python({"type": "bogus", "layer": {"layer": 1, "datatype": 0}})
