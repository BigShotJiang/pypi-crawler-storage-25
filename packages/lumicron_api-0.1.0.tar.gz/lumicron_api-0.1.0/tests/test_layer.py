import pytest
from pydantic import ValidationError

from lumicron_api.models.layer import LayerSpec, LayerMap


# ── LayerSpec ────────────────────────────────────────────────


class TestLayerSpec:
    def test_create_defaults(self):
        ls = LayerSpec(layer=1)
        assert ls.layer == 1
        assert ls.datatype == 0

    def test_create_explicit(self):
        ls = LayerSpec(layer=10, datatype=5)
        assert ls.layer == 10
        assert ls.datatype == 5

    def test_to_gdstk(self):
        ls = LayerSpec(layer=3, datatype=7)
        assert ls.to_gdstk() == (3, 7)

    def test_frozen(self):
        ls = LayerSpec(layer=1)
        with pytest.raises(ValidationError):
            ls.layer = 2

    def test_hash_equal(self):
        a = LayerSpec(layer=1, datatype=0)
        b = LayerSpec(layer=1, datatype=0)
        assert a == b
        assert hash(a) == hash(b)

    def test_hash_not_equal(self):
        a = LayerSpec(layer=1, datatype=0)
        b = LayerSpec(layer=1, datatype=1)
        assert a != b

    def test_usable_as_dict_key(self):
        a = LayerSpec(layer=1, datatype=0)
        d = {a: "waveguide"}
        assert d[LayerSpec(layer=1, datatype=0)] == "waveguide"

    def test_repr(self):
        ls = LayerSpec(layer=5, datatype=2)
        assert repr(ls) == "LayerSpec(5/2)"

    def test_layer_bounds_low(self):
        with pytest.raises(ValidationError):
            LayerSpec(layer=-1)

    def test_layer_bounds_high(self):
        with pytest.raises(ValidationError):
            LayerSpec(layer=65536)

    def test_datatype_bounds_low(self):
        with pytest.raises(ValidationError):
            LayerSpec(layer=0, datatype=-1)

    def test_datatype_bounds_high(self):
        with pytest.raises(ValidationError):
            LayerSpec(layer=0, datatype=65536)

    def test_edge_values(self):
        ls = LayerSpec(layer=0, datatype=0)
        assert ls.to_gdstk() == (0, 0)
        ls = LayerSpec(layer=65535, datatype=65535)
        assert ls.to_gdstk() == (65535, 65535)

    def test_json_round_trip(self):
        ls = LayerSpec(layer=42, datatype=3)
        j = ls.model_dump_json()
        ls2 = LayerSpec.model_validate_json(j)
        assert ls == ls2


# ── LayerMap ─────────────────────────────────────────────────


class TestLayerMap:
    def test_empty(self):
        lm = LayerMap()
        assert len(lm.layers) == 0

    def test_add_and_get(self):
        lm = LayerMap()
        spec = lm.add("WG_CORE", 1, 0)
        assert spec == LayerSpec(layer=1, datatype=0)
        assert lm.get("WG_CORE") == spec
        assert lm["WG_CORE"] == spec

    def test_contains(self):
        lm = LayerMap()
        lm.add("WG_CORE", 1)
        assert "WG_CORE" in lm
        assert "METAL" not in lm

    def test_duplicate_name_raises(self):
        lm = LayerMap()
        lm.add("WG_CORE", 1)
        with pytest.raises(ValueError, match="already exists"):
            lm.add("WG_CORE", 2)

    def test_duplicate_spec_raises(self):
        lm = LayerMap()
        lm.add("WG_CORE", 1, 0)
        with pytest.raises(ValueError, match="already mapped"):
            lm.add("WG_CLONE", 1, 0)

    def test_different_datatype_ok(self):
        lm = LayerMap()
        lm.add("LAYER_A", 1, 0)
        lm.add("LAYER_B", 1, 1)
        assert lm["LAYER_A"].to_gdstk() == (1, 0)
        assert lm["LAYER_B"].to_gdstk() == (1, 1)

    def test_get_missing_raises(self):
        lm = LayerMap()
        with pytest.raises(KeyError):
            lm.get("NOPE")

    def test_getitem_missing_raises(self):
        lm = LayerMap()
        with pytest.raises(KeyError):
            lm["NOPE"]

    def test_json_round_trip(self):
        lm = LayerMap()
        lm.add("WG_CORE", 1, 0)
        lm.add("WG_CLAD", 2, 0)
        lm.add("METAL1", 10, 3)

        j = lm.model_dump_json()
        lm2 = LayerMap.model_validate_json(j)

        assert lm2["WG_CORE"] == LayerSpec(layer=1, datatype=0)
        assert lm2["WG_CLAD"] == LayerSpec(layer=2, datatype=0)
        assert lm2["METAL1"] == LayerSpec(layer=10, datatype=3)

    def test_construct_with_duplicate_spec_raises(self):
        with pytest.raises(ValidationError):
            LayerMap(layers={
                "A": LayerSpec(layer=1, datatype=0),
                "B": LayerSpec(layer=1, datatype=0),
            })

    def test_repr(self):
        lm = LayerMap()
        lm.add("WG", 1)
        assert "WG=1/0" in repr(lm)
