"""Tests for S-bend routing (.go() with diagonal directions)."""

import math
import sys
import pytest

sys.path.insert(0, ".")

from lumicron_api.lang.cell import CELL
from lumicron_api.lang.port import PORT
from lumicron_api.lang.routing import (
    _compute_sbend_points,
    _transform_sbend_to_world,
)
from lumicron_api.models.layer import LayerSpec


LAYER = LayerSpec(layer=1, datatype=0)


def _make_cell(
    port_a_pos=(0, 0), port_a_dir=0,
    port_b_pos=(200, 100), port_b_dir=180,
    width=0.5,
):
    """Helper: create a CELL with two ports for routing tests."""
    c = CELL("test_cell")
    c.add(PORT("a", position=port_a_pos, direction=port_a_dir,
               width=width, layer=LAYER))
    c.add(PORT("b", position=port_b_pos, direction=port_b_dir,
               width=width, layer=LAYER))
    pa = c._cell.ports["a"]
    pb = c._cell.ports["b"]
    return c, pa, pb


# ── _compute_sbend_points unit tests ─────────────────────────


class TestSBendCurveGeneration:

    def test_straight_line_when_no_lateral(self):
        """No lateral offset → straight line."""
        pts = _compute_sbend_points(forward=50, lateral=0)
        assert len(pts) == 2
        assert pts[0] == pytest.approx((0, 0), abs=1e-6)
        assert pts[1] == pytest.approx((50, 0), abs=1e-6)

    def test_basic_sbend_shape(self):
        """S-bend with positive lateral offset."""
        pts = _compute_sbend_points(forward=100, lateral=50)
        assert len(pts) > 10
        # Starts at origin, ends at (100, 50)
        assert pts[0] == pytest.approx((0, 0), abs=0.1)
        assert pts[-1] == pytest.approx((100, 50), abs=0.1)

    def test_negative_lateral(self):
        """S-bend with negative lateral offset curves downward."""
        pts = _compute_sbend_points(forward=100, lateral=-50)
        assert pts[0] == pytest.approx((0, 0), abs=0.1)
        assert pts[-1] == pytest.approx((100, -50), abs=0.1)
        # All y values should be <= 0
        for x, y in pts:
            assert y <= 0.1

    def test_monotonic_forward(self):
        """X coordinates are monotonically increasing."""
        pts = _compute_sbend_points(forward=100, lateral=50)
        for i in range(len(pts) - 1):
            assert pts[i + 1][0] >= pts[i][0] - 1e-6

    def test_tangent_at_endpoints_is_horizontal(self):
        """S-bend exits and enters horizontally (in local frame)."""
        pts = _compute_sbend_points(forward=100, lateral=50, num_points=200)
        # Check tangent at start: should be ~horizontal
        dx = pts[1][0] - pts[0][0]
        dy = pts[1][1] - pts[0][1]
        angle = abs(math.atan2(dy, dx))
        assert angle < 0.1  # ~horizontal

        # Check tangent at end: should be ~horizontal
        dx = pts[-1][0] - pts[-2][0]
        dy = pts[-1][1] - pts[-2][1]
        angle = abs(math.atan2(dy, dx))
        assert angle < 0.1

    def test_inflection_at_midpoint(self):
        """Curve passes through approximately (forward/2, lateral/2)."""
        pts = _compute_sbend_points(forward=100, lateral=50, num_points=200)
        mid_x = [p[0] for p in pts if abs(p[0] - 50) < 5]
        mid_y = [p[1] for p in pts if abs(p[0] - 50) < 5]
        assert len(mid_y) > 0
        assert min(mid_y) < 30  # near midpoint height

    def test_larger_radius_adds_padding(self):
        """Requesting R > R_natural adds straight padding."""
        # R_natural for forward=100, lateral=50: (100²+50²)/(4*50) = 62.5
        # Use R=100 > R_natural, with forward=200 to allow room for arcs + padding
        pts = _compute_sbend_points(forward=200, lateral=50, radius=100)
        assert pts[-1] == pytest.approx((200, 50), abs=0.1)
        assert pts[0] == pytest.approx((0, 0), abs=0.1)
        # With padding, the (0, 0) is the padding start and the curve
        # starts at (dx_pad, 0). So we should have more points than
        # the arc-only count (padding adds 2 endpoints).
        assert len(pts) > 100  # 101 arc points + 2 padding = 103

    def test_zero_forward_raises(self):
        with pytest.raises(ValueError, match="forward distance must be positive"):
            _compute_sbend_points(forward=0, lateral=50)

    def test_negative_forward_raises(self):
        with pytest.raises(ValueError, match="forward distance must be positive"):
            _compute_sbend_points(forward=-10, lateral=50)

    def test_symmetric_curve(self):
        """S-bend is symmetric about its midpoint."""
        pts = _compute_sbend_points(forward=100, lateral=50, num_points=200)
        n = len(pts)
        mid = n // 2
        # Check a few symmetric pairs
        for i in range(min(5, mid)):
            p1 = pts[i]
            p2 = pts[-(i + 1)]
            # x-symmetry: x1 + x2 ≈ forward
            assert p1[0] + p2[0] == pytest.approx(100, abs=1.0)
            # y-symmetry: y1 + y2 ≈ lateral
            assert p1[1] + p2[1] == pytest.approx(50, abs=1.0)


# ── _transform_sbend_to_world ────────────────────────────────


class TestSBendTransform:

    def test_identity_rotation(self):
        """Angle=0 preserves local coordinates."""
        local = [(0, 0), (50, 25), (100, 50)]
        world = _transform_sbend_to_world(local, (10, 20), 0)
        assert world[0] == pytest.approx((10, 20), abs=1e-6)
        assert world[1] == pytest.approx((60, 45), abs=1e-6)
        assert world[2] == pytest.approx((110, 70), abs=1e-6)

    def test_90_degree_rotation(self):
        """Angle=pi/2 rotates local +x to world +y."""
        local = [(0, 0), (10, 0)]
        world = _transform_sbend_to_world(local, (0, 0), math.pi / 2)
        assert world[0] == pytest.approx((0, 0), abs=1e-6)
        assert world[1] == pytest.approx((0, 10), abs=1e-6)

    def test_with_origin_offset(self):
        local = [(0, 0), (10, 5)]
        world = _transform_sbend_to_world(local, (100, 200), 0)
        assert world[0] == pytest.approx((100, 200), abs=1e-6)
        assert world[1] == pytest.approx((110, 205), abs=1e-6)


# ── RouteChain .go() with diagonal directions ───────────────


class TestSBendRouting:

    def test_go_NE_basic(self):
        """Basic NE S-bend: goes right and up."""
        c, pa, pb = _make_cell(
            port_a_pos=(0, 0), port_a_dir=0,
            port_b_pos=(200, 100), port_b_dir=180,
        )
        route = c.Route(pa, pb, radius=10).go("NE", by=(200, 100))
        assert route._segments is not None
        assert any(s.is_sbend for s in route._segments)

    def test_go_SE_basic(self):
        """SE S-bend: goes right and down."""
        c, pa, pb = _make_cell(
            port_a_pos=(0, 0), port_a_dir=0,
            port_b_pos=(200, -100), port_b_dir=180,
        )
        route = c.Route(pa, pb, radius=10).go("SE", by=(200, 100))
        sbend_segs = [s for s in route._segments if s.is_sbend]
        assert len(sbend_segs) == 1
        # S-bend should end near (200, -100)
        end_pt = sbend_segs[0].points[-1]
        assert end_pt[0] == pytest.approx(200, abs=1)
        assert end_pt[1] == pytest.approx(-100, abs=1)

    def test_go_SW_basic(self):
        """SW S-bend: goes left and down from East-facing port."""
        c = CELL("test")
        c.add(PORT("a", position=(0, 0), direction=180, width=0.5, layer=LAYER))
        c.add(PORT("b", position=(-200, -100), direction=0, width=0.5, layer=LAYER))
        pa = c._cell.ports["a"]
        pb = c._cell.ports["b"]
        # From West-facing port, SW means forward (west) + down
        route = c.Route(pa, pb, radius=10).go("SW", by=(200, 100))
        sbend_segs = [s for s in route._segments if s.is_sbend]
        assert len(sbend_segs) == 1

    def test_sbend_by_tuple(self):
        """by=(dx, dy) with diagonal direction applies correct signs."""
        c, pa, pb = _make_cell(
            port_a_pos=(0, 0), port_a_dir=0,
            port_b_pos=(100, 50), port_b_dir=180,
        )
        route = c.Route(pa, pb, radius=5).go("NE", by=(100, 50))
        sbend_seg = [s for s in route._segments if s.is_sbend][0]
        # Should reach approximately (100, 50)
        assert sbend_seg.points[-1][0] == pytest.approx(100, abs=1)
        assert sbend_seg.points[-1][1] == pytest.approx(50, abs=1)

    def test_sbend_with_to_port(self):
        """S-bend with to=port routes directly to target."""
        c, pa, pb = _make_cell(
            port_a_pos=(0, 0), port_a_dir=0,
            port_b_pos=(150, 75), port_b_dir=180,
        )
        route = c.Route(pa, pb, radius=10).go("NE", to=pb)
        sbend_seg = [s for s in route._segments if s.is_sbend][0]
        end = sbend_seg.points[-1]
        assert end[0] == pytest.approx(150, abs=1)
        assert end[1] == pytest.approx(75, abs=1)

    def test_mixed_manhattan_sbend(self):
        """Manhattan segment followed by S-bend."""
        c, pa, pb = _make_cell(
            port_a_pos=(0, 0), port_a_dir=0,
            port_b_pos=(200, 100), port_b_dir=180,
        )
        route = c.Route(pa, pb, radius=10) \
            .go("E", by=50) \
            .go("NE", by=(100, 100))
        assert route._segments is not None
        # Should have at least 2 segments: manhattan + S-bend
        manhattan_segs = [s for s in route._segments if not s.is_sbend]
        sbend_segs = [s for s in route._segments if s.is_sbend]
        assert len(manhattan_segs) >= 1
        assert len(sbend_segs) == 1
        # Manhattan segment ends at (50, 0)
        assert manhattan_segs[0].points[-1] == pytest.approx((50, 0), abs=1e-6)

    def test_sbend_then_manhattan(self):
        """S-bend followed by manhattan segment."""
        c, pa, pb = _make_cell(
            port_a_pos=(0, 0), port_a_dir=0,
            port_b_pos=(250, 100), port_b_dir=180,
        )
        route = c.Route(pa, pb, radius=10) \
            .go("NE", by=(100, 100)) \
            .go("E", by=50)
        assert route._segments is not None
        # Should have: initial manhattan (just start point), S-bend, new manhattan
        sbend_segs = [s for s in route._segments if s.is_sbend]
        manhattan_segs = [s for s in route._segments if not s.is_sbend]
        assert len(sbend_segs) == 1
        assert len(manhattan_segs) >= 1

    def test_sbend_single_float_by(self):
        """Single float 'by' for diagonal creates symmetric S-bend."""
        c, pa, pb = _make_cell(
            port_a_pos=(0, 0), port_a_dir=0,
            port_b_pos=(200, 200), port_b_dir=180,
        )
        route = c.Route(pa, pb, radius=10).go("NE", by=100)
        assert route._segments is not None
        sbend_segs = [s for s in route._segments if s.is_sbend]
        assert len(sbend_segs) == 1


class TestSBendGDSExport:

    def test_sbend_exports_gds(self, tmp_path):
        """S-bend route compiles to GDS without errors."""
        c, pa, pb = _make_cell(
            port_a_pos=(0, 0), port_a_dir=0,
            port_b_pos=(150, 75), port_b_dir=180,
        )
        c.Route(pa, pb, radius=10).go("NE", to=pb)

        out = tmp_path / "sbend_test.gds"
        c.to_layout().to_gds(str(out))
        assert out.exists()
        assert out.stat().st_size > 0

    def test_mixed_route_exports_gds(self, tmp_path):
        """Mixed manhattan + S-bend route compiles to GDS."""
        c, pa, pb = _make_cell(
            port_a_pos=(0, 0), port_a_dir=0,
            port_b_pos=(300, 100), port_b_dir=180,
        )
        c.Route(pa, pb, radius=10) \
            .go("E", by=50) \
            .go("NE", by=(100, 100)) \
            .go("E", to=pb)

        out = tmp_path / "mixed_route_test.gds"
        c.to_layout().to_gds(str(out))
        assert out.exists()
        assert out.stat().st_size > 0

    def test_pure_sbend_exports_gds(self, tmp_path):
        """Pure S-bend (no manhattan) exports to GDS."""
        c, pa, pb = _make_cell(
            port_a_pos=(0, 0), port_a_dir=0,
            port_b_pos=(100, 50), port_b_dir=180,
        )
        c.Route(pa, pb).go("NE", by=(100, 50))

        out = tmp_path / "pure_sbend_test.gds"
        c.to_layout().to_gds(str(out))
        assert out.exists()

    def test_sbend_from_north_facing_port(self, tmp_path):
        """S-bend from a north-facing port."""
        c = CELL("test")
        c.add(PORT("a", position=(0, 0), direction=90, width=0.5, layer=LAYER))
        c.add(PORT("b", position=(50, 150), direction=270, width=0.5, layer=LAYER))
        pa = c._cell.ports["a"]
        pb = c._cell.ports["b"]
        # NE from north-facing: world dx=+50, dy=+150
        # travel dir is North → forward=150, lateral=-50
        c.Route(pa, pb, radius=10).go("NE", by=(50, 150))

        out = tmp_path / "north_sbend_test.gds"
        c.to_layout().to_gds(str(out))
        assert out.exists()


# ── Euler S-bends ────────────────────────────────────────────


class TestEulerSBend:

    def test_euler_sbend_shape(self):
        """Euler S-bend reaches correct endpoint."""
        pts = _compute_sbend_points(
            forward=100, lateral=50, bend_type="euler", p=0.5,
        )
        assert pts[0] == pytest.approx((0, 0), abs=0.1)
        assert pts[-1] == pytest.approx((100, 50), abs=0.5)

    def test_euler_vs_circular_differ(self):
        """Euler and circular S-bends have different curvature profiles."""
        circ = _compute_sbend_points(
            forward=100, lateral=50, bend_type="circular",
        )
        euler = _compute_sbend_points(
            forward=100, lateral=50, bend_type="euler", p=0.5,
        )
        # Same endpoints
        assert circ[-1] == pytest.approx((100, 50), abs=0.5)
        assert euler[-1] == pytest.approx((100, 50), abs=0.5)
        # But different intermediate points (euler is flatter near endpoints)
        quarter = len(circ) // 4
        assert abs(circ[quarter][1] - euler[quarter][1]) > 0.1

    def test_euler_p0_matches_circular(self):
        """Euler with p=0 should closely match circular."""
        circ = _compute_sbend_points(
            forward=100, lateral=50, bend_type="circular",
        )
        euler_p0 = _compute_sbend_points(
            forward=100, lateral=50, bend_type="euler", p=0.0,
        )
        # Endpoints should match
        assert circ[-1] == pytest.approx(euler_p0[-1], abs=0.5)

    def test_euler_negative_lateral(self):
        """Euler S-bend with negative lateral."""
        pts = _compute_sbend_points(
            forward=100, lateral=-50, bend_type="euler", p=0.5,
        )
        assert pts[-1] == pytest.approx((100, -50), abs=0.5)
        # All y values should be <= 0
        for x, y in pts:
            assert y <= 0.5

    def test_euler_sbend_route(self):
        """Euler S-bend via Route.go()."""
        c, pa, pb = _make_cell(
            port_a_pos=(0, 0), port_a_dir=0,
            port_b_pos=(150, 75), port_b_dir=180,
        )
        route = c.Route(pa, pb, radius=10, bend="euler") \
            .go("NE", to=pb)
        assert route._segments is not None
        assert any(s.is_sbend for s in route._segments)

    def test_euler_sbend_exports_gds(self, tmp_path):
        """Euler S-bend route exports to GDS."""
        c, pa, pb = _make_cell(
            port_a_pos=(0, 0), port_a_dir=0,
            port_b_pos=(150, 75), port_b_dir=180,
        )
        c.Route(pa, pb, radius=10, bend="euler").go("NE", to=pb)
        out = tmp_path / "euler_sbend.gds"
        c.to_layout().to_gds(str(out))
        assert out.exists()


# ── Smart auto-route ─────────────────────────────────────────


class TestSmartAutoRoute:

    def test_cardinal_ports_use_manhattan(self):
        """Both cardinal ports → manhattan auto-route (backward compat)."""
        c, pa, pb = _make_cell(
            port_a_pos=(0, 0), port_a_dir=0,
            port_b_pos=(100, 50), port_b_dir=180,
        )
        route = c.Route(pa, pb, radius=10)
        # Should use manhattan (no S-bend segments)
        assert route._segments is None

    def test_non_cardinal_port_uses_sbend(self):
        """Non-cardinal port direction → auto S-bend."""
        c = CELL("test")
        c.add(PORT("a", position=(0, 0), direction=45, width=0.5, layer=LAYER))
        c.add(PORT("b", position=(100, 100), direction=225, width=0.5, layer=LAYER))
        pa = c._cell.ports["a"]
        pb = c._cell.ports["b"]
        route = c.Route(pa, pb, radius=10)
        # Should auto-select S-bend
        assert route._segments is not None
        assert any(s.is_sbend for s in route._segments)

    def test_non_cardinal_auto_route_exports_gds(self, tmp_path):
        """Non-cardinal auto S-bend exports to GDS."""
        c = CELL("test")
        c.add(PORT("a", position=(0, 0), direction=45, width=0.5, layer=LAYER))
        c.add(PORT("b", position=(100, 100), direction=225, width=0.5, layer=LAYER))
        pa = c._cell.ports["a"]
        pb = c._cell.ports["b"]
        c.Route(pa, pb, radius=10)
        out = tmp_path / "non_cardinal_auto.gds"
        c.to_layout().to_gds(str(out))
        assert out.exists()

    def test_cardinal_straight_line_preserved(self):
        """Axis-aligned cardinal ports → straight line (no S-bend)."""
        c, pa, pb = _make_cell(
            port_a_pos=(0, 0), port_a_dir=0,
            port_b_pos=(100, 0), port_b_dir=180,
        )
        route = c.Route(pa, pb)
        assert route._segments is None
        assert len(route._route.points) == 2


# ── Radius validation / warnings ────────────────────────────


class TestSBendRadiusWarnings:

    def test_radius_too_small_warns(self):
        """Small radius for the geometry triggers a warning."""
        with pytest.warns(UserWarning, match="smaller than the minimum"):
            # R_natural for forward=100, lateral=50 = 62.5
            _compute_sbend_points(
                forward=100, lateral=50, radius=10,
            )

    def test_radius_too_small_euler_warns(self):
        """Euler S-bend also warns on too-small radius."""
        with pytest.warns(UserWarning, match="smaller than the minimum"):
            _compute_sbend_points(
                forward=100, lateral=50, radius=10,
                bend_type="euler", p=0.5,
            )

    def test_adequate_radius_no_warning(self):
        """Adequate radius produces no warning when R >= R_natural."""
        import warnings
        with warnings.catch_warnings():
            warnings.simplefilter("error")
            # Use radius=0 → auto-computes R_natural, never warns
            _compute_sbend_points(forward=100, lateral=50, radius=0)


# ── Errors ───────────────────────────────────────────────────


class TestSBendErrors:

    def test_sbend_missing_by_and_to_raises(self):
        """S-bend without by or to raises ValueError."""
        c, pa, pb = _make_cell()
        with pytest.raises(ValueError, match="requires either 'by' or 'to'"):
            c.Route(pa, pb, radius=10).go("NE")

    def test_sbend_negative_forward_raises(self):
        """S-bend that would go backward raises ValueError."""
        c, pa, pb = _make_cell(
            port_a_pos=(0, 0), port_a_dir=0,
            port_b_pos=(100, 100), port_b_dir=180,
        )
        # NW from East-facing port: world dx=-100 is backward
        with pytest.raises(ValueError, match="forward distance must be positive"):
            c.Route(pa, pb, radius=10).go("NW", by=(100, 100))
