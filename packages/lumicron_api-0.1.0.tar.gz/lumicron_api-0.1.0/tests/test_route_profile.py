"""Tests for RouteProfile model."""

import pytest
from pydantic import ValidationError

from lumicron_api.models.route_profile import CladdingLayer, RouteProfile
from lumicron_api.models.layer import LayerSpec


# ── CladdingLayer ──────────────────────────────────────────────

def test_cladding_layer_basic():
    cl = CladdingLayer(layer=LayerSpec(layer=1, datatype=0), offset=2.0)
    assert cl.layer == LayerSpec(layer=1, datatype=0)
    assert cl.offset == 2.0


def test_cladding_layer_offset_must_be_positive():
    with pytest.raises(ValidationError):
        CladdingLayer(layer=LayerSpec(layer=1, datatype=0), offset=-1.0)


# ── RouteProfile basic ────────────────────────────────────────

def test_route_profile_minimal():
    rp = RouteProfile(name="test", layer=LayerSpec(layer=5, datatype=0), width=0.5)
    assert rp.name == "test"
    assert rp.width == 0.5
    assert rp.radius == 0.0
    assert rp.radius_min == 0.0
    assert rp.cladding == []


def test_route_profile_full():
    rp = RouteProfile(
        name="strip",
        layer=LayerSpec(layer=5, datatype=0),
        width=0.5,
        radius=10.0,
        radius_min=5.0,
        cladding=[CladdingLayer(layer=LayerSpec(layer=1, datatype=0), offset=2.0)],
    )
    assert rp.radius == 10.0
    assert rp.radius_min == 5.0
    assert len(rp.cladding) == 1
    assert rp.cladding[0].offset == 2.0


def test_route_profile_width_must_be_positive():
    with pytest.raises(ValidationError):
        RouteProfile(name="bad", layer=LayerSpec(layer=1, datatype=0), width=0)


def test_route_profile_radius_non_negative():
    with pytest.raises(ValidationError):
        RouteProfile(name="bad", layer=LayerSpec(layer=1, datatype=0), width=0.5, radius=-1)


def test_route_profile_json_round_trip():
    rp = RouteProfile(
        name="test_rp",
        layer=LayerSpec(layer=9, datatype=0),
        width=1.5,
        radius=20.0,
        cladding=[CladdingLayer(layer=LayerSpec(layer=1, datatype=0), offset=3.0)],
    )
    data = rp.model_dump()
    rp2 = RouteProfile.model_validate(data)
    assert rp2 == rp


def test_route_profile_repr():
    rp = RouteProfile(name="strip", layer=LayerSpec(layer=9, datatype=0), width=0.5, radius=10.0)
    r = repr(rp)
    assert "strip" in r
    assert "9/0" in r
    assert "0.5" in r


def test_route_profile_multiple_cladding():
    rp = RouteProfile(
        name="multi_clad",
        layer=LayerSpec(layer=9, datatype=0),
        width=0.5,
        cladding=[
            CladdingLayer(layer=LayerSpec(layer=1, datatype=0), offset=2.0),
            CladdingLayer(layer=LayerSpec(layer=5, datatype=0), offset=3.0),
        ],
    )
    assert len(rp.cladding) == 2
    assert rp.cladding[0].offset == 2.0
    assert rp.cladding[1].offset == 3.0


def test_route_profile_radius_min_non_negative():
    with pytest.raises(ValidationError):
        RouteProfile(name="bad", layer=LayerSpec(layer=1, datatype=0), width=0.5, radius_min=-1)


def test_cladding_layer_zero_offset_rejected():
    with pytest.raises(ValidationError):
        CladdingLayer(layer=LayerSpec(layer=1, datatype=0), offset=0)
