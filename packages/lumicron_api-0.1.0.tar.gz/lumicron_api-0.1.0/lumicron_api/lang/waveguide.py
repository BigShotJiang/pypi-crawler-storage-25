"""Waveguide — standalone path primitive with auto-generated ports."""

from __future__ import annotations

import math

from lumicron_api.models.elements import FlexRoute
from lumicron_api.models.layer import LayerSpec
from lumicron_api.models.port import Port
from lumicron_api.models.route_profile import RouteProfile

_waveguide_counter = 0


def Waveguide(
    points: list[tuple[float, float]],
    layer: LayerSpec | None = None,
    width: float | None = None,
    width_end: float | None = None,
    radius: float = 0.0,
    bend: str | None = None,
    p: float | None = None,
    profile: RouteProfile | None = None,
    name: str | None = None,
    port_type: str = "optical",
):
    """Create a waveguide cell from a list of centerline points.

    Returns a CELL with a FlexRoute along the given points and two
    auto-generated ports (``i1`` at the start, ``o1`` at the end)
    whose directions match the path tangent.

    Args:
        points:    List of (x, y) waypoints defining the path centerline.
        layer:     Route layer. Required if no profile is given.
        width:     Route width at the start (i1 port). Required if no profile.
        width_end: Route width at the end (o1 port). If omitted, same as width.
                   Width is linearly interpolated between points.
        radius:    Bend radius in microns (0 = sharp corners).
        bend:      Bend type — ``"circular"`` (default) or ``"euler"``.
        p:         Euler fraction (0–1). Setting p without bend="euler"
                   auto-selects euler with a warning.
        profile:   Route profile (sets layer, width, radius).
        name:      Cell name (default: ``"Waveguide"``).
        port_type: Port type for generated ports (``"optical"`` or ``"electrical"``).

    Returns:
        A CELL instance with ports ``i1`` (start) and ``o1`` (end).
    """
    import warnings

    from lumicron_api.lang.cell import CELL

    # Resolve bend type
    if p is not None and bend is None:
        warnings.warn(
            f"p={p} was set without bend=\"euler\" — using euler bend "
            f"automatically. If this is intentional, add bend=\"euler\" "
            f"for cleaner code. If not, remove the p parameter.",
            stacklevel=2,
        )
        bend = "euler"
    bend_type = bend or "circular"
    bend_p = p if p is not None else 0.5

    # Resolve layer/width from profile or kwargs
    if profile is not None:
        route_layer = layer or profile.layer
        route_width = width or profile.width
        if radius == 0.0 and profile.radius > 0:
            radius = profile.radius
    else:
        if layer is None:
            raise ValueError("Waveguide requires either 'layer' or 'profile'")
        if width is None:
            raise ValueError("Waveguide requires either 'width' or 'profile'")
        route_layer = layer
        route_width = width

    if len(points) < 2:
        raise ValueError("Waveguide requires at least 2 points")

    # Build the cell
    global _waveguide_counter
    if name is None:
        cell_name = f"Waveguide_{_waveguide_counter}"
        _waveguide_counter += 1
    else:
        cell_name = name
    c = CELL(cell_name)

    # Resolve end width
    route_width_end = width_end if width_end is not None else route_width

    # Add the route
    route = FlexRoute(
        points=points,
        width=route_width,
        width_end=route_width_end if route_width_end != route_width else None,
        layer=route_layer,
        bend_radius=radius,
        bend_type=bend_type,
        bend_p=bend_p,
    )
    c._cell.add_element(route)

    # Compute port directions from path tangent
    # i1: at start, facing INTO the waveguide (opposite of first segment direction)
    dx0 = points[1][0] - points[0][0]
    dy0 = points[1][1] - points[0][1]
    start_angle = math.degrees(math.atan2(dy0, dx0))
    i1_direction = (start_angle + 180) % 360  # faces outward (away from path)

    # o1: at end, facing OUT of the waveguide (along last segment direction)
    dxn = points[-1][0] - points[-2][0]
    dyn = points[-1][1] - points[-2][1]
    o1_direction = math.degrees(math.atan2(dyn, dxn)) % 360

    c._cell.add_port(Port(
        name="i1",
        position=points[0],
        direction=i1_direction,
        width=route_width,
        layer=route_layer,
        port_type=port_type,
    ))
    c._cell.add_port(Port(
        name="o1",
        position=points[-1],
        direction=o1_direction,
        width=route_width_end,
        layer=route_layer,
        port_type=port_type,
    ))

    return c
