"""CELL — the central builder for layout cells."""

from __future__ import annotations

from lumicron_api.models.cell import Cell
from lumicron_api.models.elements import CellRef, Polygon, Rect, Repetition
from lumicron_api.models.layer import LayerSpec
from lumicron_api.models.layout import Layout
from lumicron_api.models.port import Port
from lumicron_api.models.route_profile import RouteProfile

from lumicron_api.lang.array import ARRAY
from lumicron_api.lang.handles import (
    ArrayHandle,
    ElementHandle,
    PlacedHandle,
    RefHandle,
    _bbox_anchor,
)
from lumicron_api.lang.placement import PlacementChain
from lumicron_api.lang.port import PORT
from lumicron_api.lang.routing import RouteChain


class CELL:
    """Cell builder — the primary object users interact with.

    Usage:
        c = CELL("MY_CELL")
        frame = c.add(Rectangle(x_dim=6000, y_dim=3500, layer=my_layer, centered=False))
        arr = c.add(ARRAY(COMPONENT, count=8, pitch=(0, 127)))
        c.Place(arr).at((100, 0)).relative_to(frame.W).aligned_y(frame.C)
        c.Route(arr[0].port["out"], arr[1].port["in"]).style("wg").radius(10)
        return c
    """

    def __init__(self, name: str):
        self._cell = Cell(name=name)
        self._handles: list[PlacedHandle] = []
        self._dependencies: set[CELL] = set()
        self._spec_to_handle: dict[int, PlacedHandle] = {}
        self._routes: list[RouteChain] = []
        self.styles: dict[str, LayerSpec] = {}

    @property
    def name(self) -> str:
        return self._cell.name

    @property
    def cell(self) -> Cell:
        """The underlying data-model Cell."""
        return self._cell

    @property
    def bbox(self) -> tuple[float, float, float, float]:
        """Bounding box computed from all placed handles."""
        if not self._handles:
            return (0.0, 0.0, 0.0, 0.0)
        return (
            min(h.world_bbox[0] for h in self._handles),
            min(h.world_bbox[1] for h in self._handles),
            max(h.world_bbox[2] for h in self._handles),
            max(h.world_bbox[3] for h in self._handles),
        )

    # ── Cardinal anchors ──────────────────────────────────────

    @property
    def C(self) -> tuple[float, float]:
        return _bbox_anchor(self.bbox, "C")

    @property
    def N(self) -> tuple[float, float]:
        return _bbox_anchor(self.bbox, "N")

    @property
    def S(self) -> tuple[float, float]:
        return _bbox_anchor(self.bbox, "S")

    @property
    def E(self) -> tuple[float, float]:
        return _bbox_anchor(self.bbox, "E")

    @property
    def W(self) -> tuple[float, float]:
        return _bbox_anchor(self.bbox, "W")

    @property
    def NE(self) -> tuple[float, float]:
        return _bbox_anchor(self.bbox, "NE")

    @property
    def NW(self) -> tuple[float, float]:
        return _bbox_anchor(self.bbox, "NW")

    @property
    def SE(self) -> tuple[float, float]:
        return _bbox_anchor(self.bbox, "SE")

    @property
    def SW(self) -> tuple[float, float]:
        return _bbox_anchor(self.bbox, "SW")

    # ── Port introspection ─────────────────────────────────────

    def show_ports(self):
        """Print a formatted summary of all ports on this cell."""
        ports = self._cell.ports
        if not ports:
            print(f"{self.name}: no ports")
            return
        print(f"{self.name}: {len(ports)} ports")
        for name, p in ports.items():
            print(f"  {name:30s}  pos=({p.position[0]:.2f}, {p.position[1]:.2f})  "
                  f"dir={p.direction:.0f}°  w={p.width}  [{p.port_type}]")

    # ── add() dispatch ───────────────────────────────────────

    def add(self, spec) -> PlacedHandle | None:
        """Add an object to this cell.

        Accepts ARRAY, CELL, PORT, or shape elements (Rect, Polygon).
        Returns a handle for placement (except PORT, which returns None).
        """
        if isinstance(spec, ARRAY):
            handle = self._add_array(spec)
        elif isinstance(spec, CELL):
            handle = self._add_ref(spec)
        elif isinstance(spec, PORT):
            self._cell.add_port(spec.to_port())
            return None
        elif isinstance(spec, (Rect, Polygon)):
            handle = self._add_element(spec)
        else:
            raise TypeError(f"Cannot add {type(spec).__name__} to cell")
        self._spec_to_handle[id(spec)] = handle
        return handle

    def _add_ref(self, component: CELL) -> RefHandle:
        cellref = CellRef(cell_name=component.name)
        self._cell.add_element(cellref)
        handle = RefHandle(component, cellref)
        self._handles.append(handle)
        self._dependencies.add(component)
        return handle

    def _add_array(self, spec: ARRAY) -> ArrayHandle:
        component = spec.component
        px, py = spec.pitch
        cols, rows = spec.columns, spec.rows
        total = cols * rows

        # Create CellRef with Repetition for the array
        rep = Repetition(
            columns=cols, rows=rows,
            spacing=(abs(px) if px != 0 else 1, abs(py) if py != 0 else 1),
        ) if total > 1 else None

        cellref = CellRef(cell_name=component.name, repetition=rep)
        self._cell.add_element(cellref)

        # Per-element rotation: set on the CellRef itself
        if spec.rotation != 0:
            cellref.rotation = spec.rotation % 360

        is_2d = isinstance(spec.count, tuple)
        handle = ArrayHandle(component, cellref, cols, rows, spec.pitch, is_2d=is_2d)
        handle._parent_cell = self._cell
        handle._parent_builder = self
        self._handles.append(handle)
        self._dependencies.add(component)
        return handle

    def _add_element(self, element: Rect | Polygon) -> ElementHandle:
        # Clone if this element was already added (same object, two placements)
        if element in self._cell.elements:
            element = element.model_copy(deep=True)
        self._cell.add_element(element)
        if isinstance(element, Rect):
            x1, y1 = element.corner1
            x2, y2 = element.corner2
            local_bbox = (min(x1, x2), min(y1, y2), max(x1, x2), max(y1, y2))
        else:  # Polygon
            xs = [v[0] for v in element.vertices]
            ys = [v[1] for v in element.vertices]
            local_bbox = (min(xs), min(ys), max(xs), max(ys))
        handle = ElementHandle(element, local_bbox)
        handle._parent_cell = self._cell
        self._handles.append(handle)
        return handle

    # ── Port promotion ────────────────────────────────────────

    def promote_ports(self, handle, prefix: str = "", ports: list[str] | None = None):
        """Promote child-cell ports to this cell.

        Copies ports from the placed child (transformed to world coords)
        into this cell so they are accessible from the parent level.

        Args:
            handle: A RefHandle or ArrayElementHandle returned by add() or arr[i].
            prefix: Optional prefix for promoted port names (e.g. "mod0_").
            ports:  Optional list of port names to promote. If None, all ports
                    are promoted.
        """
        from lumicron_api.lang.handles import RefHandle, ArrayElementHandle

        if isinstance(handle, RefHandle):
            component = handle._component
        elif isinstance(handle, ArrayElementHandle):
            component = handle._array._component
        else:
            raise TypeError(f"Cannot promote ports from {type(handle).__name__}")

        for name, port_model in component._cell.ports.items():
            if ports is not None and name not in ports:
                continue
            world_port = handle.port[name]
            promoted_name = f"{prefix}{name}"
            self._cell.add_port(Port(
                name=promoted_name,
                position=world_port.position,
                direction=world_port.direction,
                width=world_port.width,
                layer=world_port.layer,
                route_profile=world_port.route_profile,
            ))

    # ── Place / Route ────────────────────────────────────────

    def _resolve(self, spec_or_handle) -> PlacedHandle:
        """Resolve a raw spec or handle to a PlacedHandle."""
        if isinstance(spec_or_handle, PlacedHandle):
            return spec_or_handle
        handle = self._spec_to_handle.get(id(spec_or_handle))
        if handle is not None:
            return handle
        raise ValueError(
            f"{type(spec_or_handle).__name__} was not added to this cell. "
            f"Call c.add(...) first."
        )

    def Place(self, target) -> PlacementChain:
        """Begin a placement chain for a previously added object or handle."""
        handle = self._resolve(target)
        return PlacementChain(handle, resolver=self._resolve)

    def Route(
        self,
        port_a: Port,
        port_b: Port,
        radius: float = 0.0,
        bend: str | None = None,
        p: float | None = None,
        profile: RouteProfile | None = None,
    ) -> RouteChain:
        """Begin a route chain between two ports.

        Args:
            port_a:  Source port.
            port_b:  Destination port.
            radius:  Bend radius in microns (0 = sharp corners).
            bend:    Bend type — "circular" (default) or "euler".
            p:       Euler fraction (0–1). 0 = fully circular, 0.5 = fully
                     euler. Controls how much of the bend is clothoid spiral
                     vs constant-radius arc. Only used when bend="euler".
                     If p is set without bend="euler", euler is used
                     automatically with a warning.
            profile: Route profile (sets layer, width, radius, bend).
        """
        chain = RouteChain(
            self, port_a, port_b,
            radius=radius, bend=bend, p=p, profile=profile,
        )
        self._routes.append(chain)
        return chain

    # ── Layout export ────────────────────────────────────────

    def _all_cells(self) -> list[CELL]:
        """Collect self and all transitive dependencies."""
        visited: dict[str, CELL] = {}
        result: list[CELL] = []

        def walk(cb: CELL):
            existing = visited.get(cb.name)
            if existing is not None:
                if existing is not cb:
                    # Different objects with the same name.  If element or
                    # port counts differ the cells are clearly NOT the same
                    # design — most likely a missing @cell_params decorator.
                    ec = existing._cell
                    nc = cb._cell
                    if (len(ec.elements) != len(nc.elements)
                            or len(ec.ports) != len(nc.ports)):
                        raise ValueError(
                            f"Cell name '{cb.name}' is used by two different "
                            f"cells with different geometry. Use @cell_params "
                            f"to auto-generate unique names, or give each cell "
                            f"a unique name manually."
                        )
                return
            visited[cb.name] = cb
            for dep in cb._dependencies:
                walk(dep)
            result.append(cb)

        walk(self)
        return result

    def to_layout(self) -> Layout:
        """Build a Layout from this cell and all its dependencies."""
        # Validate and materialize tapers for all routes in all cells.
        # Also collect which ports are connected so we can hide their markers.
        all_cells = self._all_cells()
        cell_by_name: dict[str, CELL] = {cb.name: cb for cb in all_cells}
        for cb in all_cells:
            for route in cb._routes:
                route._raise_if_invalid()
                route._materialize_tapers()
                route._decompose_custom_bends()
                route._decompose_sbends()
                # Mark connected ports
                for port in (route._port_a, route._port_b):
                    src = port._source_cell
                    if src and src in cell_by_name:
                        cell_by_name[src]._cell.connected_ports.add(port.name)

        # Collect per-instance port markers with correct transformed directions.
        # The compiler reads cell.port_markers instead of cell.ports for markers.
        for cb in all_cells:
            self._collect_port_markers(cb)

        # Clear markers on child cells whose markers are now drawn by a parent.
        for cb in all_cells:
            if cb._cell.markers_handled_by_parent:
                cb._cell.port_markers.clear()

        layout = Layout(top_cell=self.name)
        for cb in all_cells:
            layout.add_cell(cb._cell)
            # Collect wrapper cells from rotated arrays
            for h in cb._handles:
                if isinstance(h, ArrayHandle) and h._wrapper_cell_model is not None:
                    if h._wrapper_cell_model.name not in layout.cells:
                        layout.add_cell(h._wrapper_cell_model)
        return layout

    @staticmethod
    def _collect_port_markers(cb: CELL) -> None:
        """Populate cell.port_markers with transformed ports from instances.

        Each marker has world-coordinate position and correct direction,
        so labels display the right angle even for rotated/flipped instances.
        """
        markers = cb._cell.port_markers

        for handle in cb._handles:
            if isinstance(handle, RefHandle):
                component = handle._component
                connected = component._cell.connected_ports
                has_ports = False
                for name in component._cell.ports:
                    if name not in connected:
                        markers.append(handle.port[name])
                        has_ports = True
                if has_ports:
                    component._cell.markers_handled_by_parent = True
            elif isinstance(handle, ArrayHandle):
                component = handle._component
                connected = component._cell.connected_ports
                has_ports = False
                for name in component._cell.ports:
                    if name in connected:
                        continue
                    has_ports = True
                    for idx in range(handle._count):
                        elem = handle[idx]
                        markers.append(elem.port[name])
                if has_ports:
                    component._cell.markers_handled_by_parent = True

        # Cell's own ports (not from children)
        for name, port in cb._cell.ports.items():
            if name not in cb._cell.connected_ports:
                markers.append(port)

    def __repr__(self) -> str:
        return (
            f"CELL('{self.name}', "
            f"{len(self._cell.elements)} elements, "
            f"{len(self._cell.ports)} ports)"
        )
