"""PlacementChain — descriptor chain for c.Place()."""

from __future__ import annotations

from lumicron_api.lang.handles import PlacedHandle


def _to_point(value) -> tuple[float, float]:
    """Resolve various anchor/point types to (x, y)."""
    if isinstance(value, tuple) and len(value) == 2:
        return (float(value[0]), float(value[1]))
    raise TypeError(f"Cannot resolve {value!r} to a point")


class PlacementChain:
    """Fluent placement API.

    Usage:
        c.Place(handle).at((dx, dy)).relative_to(ref.W).aligned_y(ref.C)

    Each method updates internal state and recomputes the handle's
    origin, so the final position is correct after the chain completes.
    """

    def __init__(self, handle: PlacedHandle, resolver=None):
        self._handle = handle
        self._resolver = resolver
        self._anchor_key = "C"
        self._offset = (0.0, 0.0)
        self._ref_point = (0.0, 0.0)
        self._align_x: float | None = None
        self._align_y: float | None = None
        self._apply()

    def using(self, anchor: str | tuple[float, float]) -> PlacementChain:
        """Select the anchor point on the object to align.

        Args:
            anchor: Cardinal key ("C", "N", "SW", etc.), port name,
                    or (x, y) coordinate in local space.
        """
        if isinstance(anchor, str):
            self._anchor_key = anchor
        else:
            self._anchor_key = anchor  # tuple — handled in _apply
        self._apply()
        return self

    def at(self, position: tuple[float, float]) -> PlacementChain:
        """Set the offset from the reference point."""
        self._offset = (float(position[0]), float(position[1]))
        self._apply()
        return self

    def relative_to(self, point: tuple[float, float]) -> PlacementChain:
        """Set the reference point (anchor on another object)."""
        self._ref_point = _to_point(point)
        self._apply()
        return self

    def aligned_y(self, point: tuple[float, float]) -> PlacementChain:
        """Override the y-coordinate to match another anchor's y."""
        self._align_y = _to_point(point)[1]
        self._apply()
        return self

    def aligned_x(self, point: tuple[float, float]) -> PlacementChain:
        """Override the x-coordinate to match another anchor's x."""
        self._align_x = _to_point(point)[0]
        self._apply()
        return self

    def _resolve_other(self, other) -> PlacedHandle:
        """Resolve *other* to a PlacedHandle via the cell's resolver."""
        if isinstance(other, PlacedHandle):
            return other
        if self._resolver is not None:
            return self._resolver(other)
        raise TypeError(
            f"Expected a handle, got {type(other).__name__}. "
            f"Use the handle returned by c.add(), or pass the original "
            f"object that was added to the cell."
        )

    def above(self, other) -> PlacementChain:
        """Place this object above *other*.

        Aligns this object's S (bottom) to other's N (top),
        centered on other's x-center.
        """
        other = self._resolve_other(other)
        self._anchor_key = "S"
        ref = other.world_anchor("N")
        self._ref_point = ref
        self._offset = (0.0, 0.0)
        self._align_x = other.world_anchor("C")[0]
        self._apply()
        return self

    def below(self, other) -> PlacementChain:
        """Place this object below *other*.

        Aligns this object's N (top) to other's S (bottom),
        centered on other's x-center.
        """
        other = self._resolve_other(other)
        self._anchor_key = "N"
        ref = other.world_anchor("S")
        self._ref_point = ref
        self._offset = (0.0, 0.0)
        self._align_x = other.world_anchor("C")[0]
        self._apply()
        return self

    def right_of(self, other) -> PlacementChain:
        """Place this object to the right of *other*.

        Aligns this object's W (left) to other's E (right),
        centered on other's y-center.
        """
        other = self._resolve_other(other)
        self._anchor_key = "W"
        ref = other.world_anchor("E")
        self._ref_point = ref
        self._offset = (0.0, 0.0)
        self._align_y = other.world_anchor("C")[1]
        self._apply()
        return self

    def left_of(self, other) -> PlacementChain:
        """Place this object to the left of *other*.

        Aligns this object's E (right) to other's W (left),
        centered on other's y-center.
        """
        other = self._resolve_other(other)
        self._anchor_key = "E"
        ref = other.world_anchor("W")
        self._ref_point = ref
        self._offset = (0.0, 0.0)
        self._align_y = other.world_anchor("C")[1]
        self._apply()
        return self

    def flip_x(self) -> PlacementChain:
        """Mirror the placed object across the x-axis.

        After flipping, re-applies the placement so that positional
        constraints (e.g. right_of, below) hold with the new mirrored bbox.
        """
        self._handle.flip_x()
        self._apply()
        return self

    def flip_y(self) -> PlacementChain:
        """Mirror the placed object across the y-axis.

        Implemented as x-reflection + 180° rotation (GDS only has x_reflection).
        After flipping, re-applies placement constraints.
        """
        self._handle.flip_y()
        self._apply()
        return self

    def rotate_by(self, angle: float) -> PlacementChain:
        """Rotate the placed object by *angle* degrees counter-clockwise
        about its center.

        After rotation, re-applies the placement so that positional
        constraints (e.g. right_of, below) hold with the new rotated bbox.

        Args:
            angle: Rotation in degrees (positive = counter-clockwise).
        """
        self._handle.rotate(angle)
        self._apply()
        return self

    def move_by(self, dx: float = 0, dy: float = 0) -> PlacementChain:
        """Shift the placed object by (dx, dy) microns after any placement.

        Args:
            dx: Horizontal shift (positive = right).
            dy: Vertical shift (positive = up).
        """
        ox, oy = self._handle.origin
        self._handle.set_origin(ox + dx, oy + dy)
        return self

    def _apply(self) -> None:
        # Target position = reference + offset
        tx = self._ref_point[0] + self._offset[0]
        ty = self._ref_point[1] + self._offset[1]

        # Axis alignment overrides
        if self._align_x is not None:
            tx = self._align_x
        if self._align_y is not None:
            ty = self._align_y

        # Resolve anchor in local coordinates
        if isinstance(self._anchor_key, str):
            ax, ay = self._handle.local_anchor(self._anchor_key)
        else:
            ax, ay = float(self._anchor_key[0]), float(self._anchor_key[1])

        # Position the handle so anchor lands at target
        self._handle.set_origin(tx - ax, ty - ay)
