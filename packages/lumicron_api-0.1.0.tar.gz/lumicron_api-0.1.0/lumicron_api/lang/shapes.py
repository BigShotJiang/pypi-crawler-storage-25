"""High-level shape constructors that return Polygon / Rect elements.

One level above raw primitives — each function takes intuitive parameters
and returns a ready-to-use element.

Usage:
    import lumicron_api.all as lm

    ring = lm.Ring(outer_radius=10, width=2, layer=my_layer)
    c._cell.add_element(ring)
"""

from __future__ import annotations

import math

from lumicron_api.models.elements import Polygon, Rect
from lumicron_api.models.layer import LayerSpec


def Rectangle(
    x_dim: float,
    y_dim: float,
    layer: LayerSpec,
    centered: bool = True,
) -> Rect:
    """Axis-aligned rectangle.

    Args:
        x_dim: Width.
        y_dim: Height.
        layer: Target layer.
        centered: If True, center at origin. Otherwise bottom-left at origin.
    """
    if centered:
        return Rect(
            corner1=(-x_dim / 2, -y_dim / 2),
            corner2=(x_dim / 2, y_dim / 2),
            layer=layer,
        )
    return Rect(corner1=(0, 0), corner2=(x_dim, y_dim), layer=layer)


def Circle(
    radius: float,
    layer: LayerSpec,
    num_points: int = 64,
) -> Polygon:
    """Circle approximated as a regular polygon.

    Args:
        radius: Circle radius.
        layer: Target layer.
        num_points: Number of vertices (higher = smoother).
    """
    step = 2 * math.pi / num_points
    vertices = [
        (radius * math.cos(i * step), radius * math.sin(i * step))
        for i in range(num_points)
    ]
    return Polygon(vertices=vertices, layer=layer)


def Ring(
    outer_radius: float,
    width: float,
    layer: LayerSpec,
    num_points: int = 64,
) -> Polygon:
    """Ring (annulus) — outer circle minus inner circle.

    Constructed as a single polygon that traces the outer edge forward
    then the inner edge backward.

    Args:
        outer_radius: Outer radius.
        width: Ring width (outer_radius - inner_radius).
        layer: Target layer.
        num_points: Points per circle (higher = smoother).
    """
    inner_radius = outer_radius - width
    step = 2 * math.pi / num_points

    # Outer edge (counter-clockwise)
    outer = [
        (outer_radius * math.cos(i * step), outer_radius * math.sin(i * step))
        for i in range(num_points)
    ]
    # Inner edge (clockwise = reversed counter-clockwise)
    inner = [
        (inner_radius * math.cos(i * step), inner_radius * math.sin(i * step))
        for i in range(num_points - 1, -1, -1)
    ]
    return Polygon(vertices=outer + inner, layer=layer)


def Oval(
    rx: float,
    ry: float,
    layer: LayerSpec,
    num_points: int = 64,
) -> Polygon:
    """Ellipse (oval) approximated as a polygon.

    Args:
        rx: Radius along x-axis.
        ry: Radius along y-axis.
        layer: Target layer.
        num_points: Number of vertices.
    """
    step = 2 * math.pi / num_points
    vertices = [
        (rx * math.cos(i * step), ry * math.sin(i * step))
        for i in range(num_points)
    ]
    return Polygon(vertices=vertices, layer=layer)


def Arc(
    radius: float,
    width: float,
    start_angle: float,
    end_angle: float,
    layer: LayerSpec,
    num_points: int = 64,
) -> Polygon:
    """Arc segment — a curved band between two angles.

    Args:
        radius: Center-line radius of the arc.
        width: Width of the arc band.
        start_angle: Start angle in degrees.
        end_angle: End angle in degrees.
        layer: Target layer.
        num_points: Points along the arc (higher = smoother).
    """
    r_outer = radius + width / 2
    r_inner = radius - width / 2
    a0 = math.radians(start_angle)
    a1 = math.radians(end_angle)
    step = (a1 - a0) / num_points

    # Outer edge forward
    outer = [
        (r_outer * math.cos(a0 + i * step), r_outer * math.sin(a0 + i * step))
        for i in range(num_points + 1)
    ]
    # Inner edge backward
    inner = [
        (r_inner * math.cos(a0 + i * step), r_inner * math.sin(a0 + i * step))
        for i in range(num_points, -1, -1)
    ]
    return Polygon(vertices=outer + inner, layer=layer)


def Triangle(
    base: float,
    height: float,
    layer: LayerSpec,
    centered: bool = True,
) -> Polygon:
    """Isosceles triangle.

    Args:
        base: Width of the base.
        height: Height from base to apex.
        layer: Target layer.
        centered: If True, centroid at origin. Otherwise base-left at origin.
    """
    if centered:
        cy = height / 3  # centroid is 1/3 up from base
        return Polygon(
            vertices=[
                (-base / 2, -cy),
                (base / 2, -cy),
                (0, height - cy),
            ],
            layer=layer,
        )
    return Polygon(
        vertices=[
            (0, 0),
            (base, 0),
            (base / 2, height),
        ],
        layer=layer,
    )


def Parallelogram(
    top_width: float,
    bot_width: float,
    y_dim: float,
    layer: LayerSpec,
    top_x_offset: float = 0,
    bot_x_offset: float = 0,
    centered: bool = True,
) -> Polygon:
    """Quadrilateral with independent top/bottom widths and x offsets.

    Args:
        top_width: Top edge width.
        bot_width: Bottom edge width.
        y_dim: Vertical height.
        layer: Target layer.
        top_x_offset: X position of the top edge center.
        bot_x_offset: X position of the bottom edge center.
        centered: If True, center the bounding box at origin.
    """
    verts = [
        (bot_x_offset - bot_width / 2, 0),
        (bot_x_offset + bot_width / 2, 0),
        (top_x_offset + top_width / 2, y_dim),
        (top_x_offset - top_width / 2, y_dim),
    ]
    if centered:
        xs = [v[0] for v in verts]
        cx = (min(xs) + max(xs)) / 2
        cy = y_dim / 2
        verts = [(x - cx, y - cy) for x, y in verts]
    return Polygon(vertices=verts, layer=layer)


def Trapezoid(
    top_width: float,
    bottom_width: float,
    height: float,
    layer: LayerSpec,
    centered: bool = True,
) -> Polygon:
    """Symmetric trapezoid.

    Args:
        top_width: Width of the top edge.
        bottom_width: Width of the bottom edge.
        height: Vertical height.
        layer: Target layer.
        centered: If True, center at origin.
    """
    verts = [
        (-bottom_width / 2, 0),
        (bottom_width / 2, 0),
        (top_width / 2, height),
        (-top_width / 2, height),
    ]
    if centered:
        cy = height / 2
        verts = [(x, y - cy) for x, y in verts]
    return Polygon(vertices=verts, layer=layer)
