"""Placed-object handles with bounding-box anchors.

Every object returned by CELL.add() is a handle. Handles track the
object's position and expose cardinal anchors (C, N, S, E, W, etc.)
that the placement and routing systems use as reference points.
"""

from __future__ import annotations

import math
from typing import TYPE_CHECKING

from lumicron_api.models.port import Port

if TYPE_CHECKING:
    from lumicron_api.lang.cell import CELL


def _bbox_anchor(
    bbox: tuple[float, float, float, float], key: str
) -> tuple[float, float]:
    xmin, ymin, xmax, ymax = bbox
    cx = (xmin + xmax) / 2
    cy = (ymin + ymax) / 2
    return {
        "C": (cx, cy),
        "N": (cx, ymax),
        "S": (cx, ymin),
        "E": (xmax, cy),
        "W": (xmin, cy),
        "NE": (xmax, ymax),
        "NW": (xmin, ymax),
        "SE": (xmax, ymin),
        "SW": (xmin, ymin),
    }[key]


class _PortAccessor:
    """Lazy port lookup that transforms ports to world coordinates."""

    def __init__(self, component: CELL, origin_fn, transform_fn=None):
        self._component = component
        self._origin_fn = origin_fn
        self._transform_fn = transform_fn

    def __getitem__(self, name: str) -> Port:
        p = self._component._cell.ports[name]
        if self._transform_fn is not None:
            result = self._transform_fn(p)
        else:
            ox, oy = self._origin_fn()
            result = p.translated(ox, oy)
        result._source_cell = self._component._cell.name
        return result

    def keys(self) -> list[str]:
        """Return all port names."""
        return list(self._component._cell.ports.keys())

    def __repr__(self) -> str:
        return f"Ports({', '.join(self.keys())})"

    def __iter__(self):
        return iter(self.keys())


# ── Base handle ──────────────────────────────────────────────


class PlacedHandle:
    """Base class for placed objects with bounding-box anchors."""

    def __init__(self, local_bbox: tuple[float, float, float, float]):
        self._local_bbox = local_bbox
        self._origin = (0.0, 0.0)

    @property
    def origin(self) -> tuple[float, float]:
        return self._origin

    def set_origin(self, x: float, y: float) -> None:
        self._origin = (x, y)

    def rotate(self, angle: float) -> None:
        """Rotate about the handle's world center by *angle* degrees CCW.

        Subclasses override to apply rotation to their underlying element.
        """
        pass

    def flip_x(self) -> None:
        """Mirror across the x-axis.

        Subclasses override to apply reflection to their underlying element.
        """
        pass

    def flip_y(self) -> None:
        """Mirror across the y-axis.

        Subclasses override to apply reflection to their underlying element.
        """
        pass

    @property
    def local_bbox(self) -> tuple[float, float, float, float]:
        return self._local_bbox

    @property
    def world_bbox(self) -> tuple[float, float, float, float]:
        ox, oy = self._origin
        xmin, ymin, xmax, ymax = self._local_bbox
        return (xmin + ox, ymin + oy, xmax + ox, ymax + oy)

    def local_anchor(self, key: str) -> tuple[float, float]:
        return _bbox_anchor(self._local_bbox, key)

    def world_anchor(self, key: str) -> tuple[float, float]:
        return _bbox_anchor(self.world_bbox, key)

    # Cardinal anchor properties
    @property
    def C(self) -> tuple[float, float]:
        return self.world_anchor("C")

    @property
    def N(self) -> tuple[float, float]:
        return self.world_anchor("N")

    @property
    def S(self) -> tuple[float, float]:
        return self.world_anchor("S")

    @property
    def E(self) -> tuple[float, float]:
        return self.world_anchor("E")

    @property
    def W(self) -> tuple[float, float]:
        return self.world_anchor("W")

    @property
    def NE(self) -> tuple[float, float]:
        return self.world_anchor("NE")

    @property
    def NW(self) -> tuple[float, float]:
        return self.world_anchor("NW")

    @property
    def SE(self) -> tuple[float, float]:
        return self.world_anchor("SE")

    @property
    def SW(self) -> tuple[float, float]:
        return self.world_anchor("SW")


# ── Single cell reference ────────────────────────────────────


class RefHandle(PlacedHandle):
    """Handle for a single cell reference (SRef)."""

    def __init__(self, component: CELL, cellref):
        self._component = component
        self._cellref = cellref
        self._unrotated_bbox = component.bbox
        super().__init__(component.bbox)

    def set_origin(self, x: float, y: float) -> None:
        super().set_origin(x, y)
        self._cellref.origin = (x, y)

    def rotate(self, angle: float) -> None:
        self._cellref.rotation = (self._cellref.rotation + angle) % 360
        self._update_bbox_for_transform()

    def flip_x(self) -> None:
        self._cellref.x_reflection = not self._cellref.x_reflection
        self._update_bbox_for_transform()

    def flip_y(self) -> None:
        self._cellref.x_reflection = not self._cellref.x_reflection
        self._cellref.rotation = (self._cellref.rotation + 180) % 360
        self._update_bbox_for_transform()

    def _update_bbox_for_transform(self) -> None:
        """Recompute local_bbox from the unrotated bbox + reflection + rotation.

        GDS transform order: reflect across x-axis, then rotate — both
        about the CellRef origin (0, 0), NOT about the bbox center.
        """
        xmin, ymin, xmax, ymax = self._unrotated_bbox
        corners = [(xmin, ymin), (xmax, ymin), (xmax, ymax), (xmin, ymax)]

        # Step 1: x_reflection (flip y about origin)
        if self._cellref.x_reflection:
            corners = [(x, -y) for x, y in corners]

        # Step 2: rotation about origin (0, 0)
        total = self._cellref.rotation
        if total != 0:
            rad = math.radians(total)
            cos_a, sin_a = math.cos(rad), math.sin(rad)
            corners = [(x * cos_a - y * sin_a, x * sin_a + y * cos_a)
                       for x, y in corners]

        xs = [c[0] for c in corners]
        ys = [c[1] for c in corners]
        self._local_bbox = (min(xs), min(ys), max(xs), max(ys))

    def _transform_point(self, x: float, y: float) -> tuple[float, float]:
        """Apply the CellRef's reflection + rotation to a local point."""
        if self._cellref.x_reflection:
            y = -y
        total = self._cellref.rotation
        if total != 0:
            rad = math.radians(total)
            cos_a, sin_a = math.cos(rad), math.sin(rad)
            x, y = x * cos_a - y * sin_a, x * sin_a + y * cos_a
        return (x, y)

    def local_anchor(self, key: str) -> tuple[float, float]:
        # Check port names first
        if key in self._component._cell.ports:
            px, py = self._component._cell.ports[key].position
            return self._transform_point(px, py)
        return _bbox_anchor(self._local_bbox, key)

    @property
    def port(self) -> _PortAccessor:
        def _transform_port(p: Port) -> Port:
            return p.transformed(
                origin=self._origin,
                rotation=self._cellref.rotation,
                x_reflection=self._cellref.x_reflection,
            )
        return _PortAccessor(self._component, lambda: self._origin, _transform_port)


# ── Array handle ─────────────────────────────────────────────


class ArrayHandle(PlacedHandle):
    """Handle for an array of cell references (ARef).

    Supports 1-D and 2-D arrays. Indexing (arr[i]) uses row-major
    order for 2-D arrays. Cardinal anchors cover the full array extent.
    """

    def __init__(self, component: CELL, cellref, columns: int, rows: int,
                 pitch: tuple[float, float], is_2d: bool = False):
        self._component = component
        self._cellref = cellref
        self._columns = columns
        self._rows = rows
        self._count = columns * rows
        self._pitch = pitch
        self._parent_cell = None       # set by CELL._add_array
        self._parent_builder = None    # set by CELL._add_array
        self._wrapper_ref = None
        self._wrapper_cell_model = None
        self._center_offset = (0.0, 0.0)  # offset from handle origin to bbox center

        # Pitch vectors: for 1D, the full pitch vector applies along the
        # array axis. For 2D, px is column spacing and py is row spacing.
        px, py = pitch
        if is_2d:
            self._col_pitch = (px, 0.0)
            self._row_pitch = (0.0, py)
        elif rows == 1:
            self._col_pitch = (px, py)
            self._row_pitch = (0.0, 0.0)
        else:
            self._col_pitch = (0.0, 0.0)
            self._row_pitch = (px, py)

        # Compute local bbox: union of corner element bboxes
        eb = component.bbox
        # Account for per-element rotation (GDS rotates about CellRef origin)
        elem_rot = getattr(cellref, 'rotation', 0) or 0
        if elem_rot != 0:
            rad = math.radians(elem_rot)
            cos_a, sin_a = math.cos(rad), math.sin(rad)
            corners = [
                (eb[0], eb[1]), (eb[2], eb[1]),
                (eb[2], eb[3]), (eb[0], eb[3]),
            ]
            rx = [x * cos_a - y * sin_a for x, y in corners]
            ry = [x * sin_a + y * cos_a for x, y in corners]
            eb = (min(rx), min(ry), max(rx), max(ry))
        cpx, cpy = self._col_pitch
        rpx, rpy = self._row_pitch
        last_col_x = (columns - 1) * cpx
        last_col_y = (columns - 1) * cpy
        last_row_x = (rows - 1) * rpx
        last_row_y = (rows - 1) * rpy

        # All four corner offsets: (0,0), last_col, last_row, last_col+last_row
        offsets = [
            (0, 0),
            (last_col_x, last_col_y),
            (last_row_x, last_row_y),
            (last_col_x + last_row_x, last_col_y + last_row_y),
        ]
        all_x = [eb[0] + ox for ox, _ in offsets] + [eb[2] + ox for ox, _ in offsets]
        all_y = [eb[1] + oy for _, oy in offsets] + [eb[3] + oy for _, oy in offsets]

        local_bbox = (min(all_x), min(all_y), max(all_x), max(all_y))
        self._unrotated_bbox = local_bbox
        self._center_offset = (
            (local_bbox[0] + local_bbox[2]) / 2,
            (local_bbox[1] + local_bbox[3]) / 2,
        )
        super().__init__(local_bbox)

    def set_origin(self, x: float, y: float) -> None:
        super().set_origin(x, y)
        if self._wrapper_ref is not None:
            # Wrapper origin is at bbox center so rotation is about center
            cx, cy = self._center_offset
            self._wrapper_ref.origin = (x + cx, y + cy)
        else:
            self._cellref.origin = (x, y)

    def rotate(self, angle: float) -> None:
        """Rotate the entire array as a group.

        On first call, wraps the array in an intermediate cell so the
        GDS rotation applies to the whole group, not each element individually.
        """
        if self._wrapper_ref is None:
            self._wrap_in_cell()
        self._wrapper_ref.rotation = (self._wrapper_ref.rotation + angle) % 360
        self._update_bbox_for_transform()

    def flip_x(self) -> None:
        """Mirror the entire array across the x-axis."""
        if self._wrapper_ref is None:
            self._wrap_in_cell()
        self._wrapper_ref.x_reflection = not self._wrapper_ref.x_reflection
        self._update_bbox_for_transform()

    def flip_y(self) -> None:
        """Mirror the entire array across the y-axis."""
        if self._wrapper_ref is None:
            self._wrap_in_cell()
        self._wrapper_ref.x_reflection = not self._wrapper_ref.x_reflection
        self._wrapper_ref.rotation = (self._wrapper_ref.rotation + 180) % 360
        self._update_bbox_for_transform()

    def _update_bbox_for_transform(self) -> None:
        """Recompute local_bbox from the unrotated bbox + reflection + rotation."""
        xmin, ymin, xmax, ymax = self._unrotated_bbox
        corners = [(xmin, ymin), (xmax, ymin), (xmax, ymax), (xmin, ymax)]

        # Step 1: x_reflection (flip y)
        if self._wrapper_ref.x_reflection:
            corners = [(x, -y) for x, y in corners]

        # Step 2: rotation
        total = self._wrapper_ref.rotation
        if total != 0:
            rad = math.radians(total)
            cos_a, sin_a = math.cos(rad), math.sin(rad)
            cx = sum(c[0] for c in corners) / 4
            cy = sum(c[1] for c in corners) / 4
            rotated = []
            for x, y in corners:
                dx, dy = x - cx, y - cy
                rotated.append((cx + dx * cos_a - dy * sin_a,
                                cy + dx * sin_a + dy * cos_a))
            corners = rotated

        xs = [c[0] for c in corners]
        ys = [c[1] for c in corners]
        self._local_bbox = (min(xs), min(ys), max(xs), max(ys))

    def _wrap_in_cell(self) -> None:
        """Replace the array CellRef with a wrapper cell that contains it.

        Centers the array inside the wrapper so that GDS rotation
        (which rotates about the CellRef origin) rotates about the
        array's bounding-box center, not its corner.
        """
        from lumicron_api.models.cell import Cell
        from lumicron_api.models.elements import CellRef

        cx, cy = self._center_offset
        old_ox, old_oy = self._cellref.origin

        wrapper_name = f"{self._component.name}_array"
        wrapper_cell = Cell(name=wrapper_name)

        # Place the array at (-cx, -cy) inside the wrapper so the
        # array's bbox center sits at the wrapper's (0, 0)
        self._cellref.origin = (-cx, -cy)
        wrapper_cell.add_element(self._cellref)

        # The wrapper ref's origin = old array position + center offset
        # so the array visually stays in the same place
        wrapper_ref = CellRef(cell_name=wrapper_name, origin=(old_ox + cx, old_oy + cy))

        # Swap in parent cell's element list
        if self._parent_cell is not None:
            elems = self._parent_cell.elements
            for i, e in enumerate(elems):
                if e is self._cellref:
                    elems[i] = wrapper_ref
                    break

        # Store wrapper for the dependency chain
        self._wrapper_cell_model = wrapper_cell
        self._wrapper_ref = wrapper_ref

    def __getitem__(self, index) -> ArrayElementHandle:
        """Index into the array.

        For 1-D arrays: arr[i]
        For 2-D arrays: arr[col, row] or arr[i] (row-major flat index)
        """
        if isinstance(index, tuple):
            col, row = index
            if col < 0 or col >= self._columns or row < 0 or row >= self._rows:
                raise IndexError(
                    f"Array index ({col}, {row}) out of range "
                    f"[0, {self._columns}) x [0, {self._rows})"
                )
            return ArrayElementHandle(self, col, row)
        else:
            if index < 0 or index >= self._count:
                raise IndexError(f"Array index {index} out of range [0, {self._count})")
            col = index % self._columns
            row = index // self._columns
            return ArrayElementHandle(self, col, row)

    def first(self) -> ArrayElementHandle:
        return self[0]

    def last(self) -> ArrayElementHandle:
        return self[self._count - 1]


# ── Array element handle ─────────────────────────────────────


class ElementHandle(PlacedHandle):
    """Handle for a raw element (Rect or Polygon) added directly to a cell.

    Tracks the element and its original vertices/corners so placement
    can translate them to world coordinates.
    """

    def __init__(self, element, local_bbox: tuple[float, float, float, float]):
        from lumicron_api.models.elements import Rect, Polygon

        self._element = element
        self._parent_cell = None  # set by CELL._add_element
        self._orig_vertices: list[tuple[float, float]] = []
        self._store_orig(element)
        super().__init__(local_bbox)

    def _store_orig(self, element) -> None:
        from lumicron_api.models.elements import Rect, Polygon
        if isinstance(element, Rect):
            x1, y1 = element.corner1
            x2, y2 = element.corner2
            self._orig_vertices = [(x1, y1), (x2, y1), (x2, y2), (x1, y2)]
        elif isinstance(element, Polygon):
            self._orig_vertices = list(element.vertices)

    def set_origin(self, x: float, y: float) -> None:
        from lumicron_api.models.elements import Rect, Polygon

        super().set_origin(x, y)
        elem = self._element
        if isinstance(elem, Rect):
            c1 = self._orig_vertices[0]
            c2 = self._orig_vertices[2]
            elem.corner1 = (c1[0] + x, c1[1] + y)
            elem.corner2 = (c2[0] + x, c2[1] + y)
        elif isinstance(elem, Polygon):
            elem.vertices = [
                (vx + x, vy + y) for vx, vy in self._orig_vertices
            ]

    def rotate(self, angle: float) -> None:
        """Rotate element about its local center by *angle* degrees CCW.

        Converts Rect to Polygon if needed (rotated rects aren't axis-aligned).
        """
        from lumicron_api.models.elements import Rect, Polygon

        rad = math.radians(angle)
        cos_a, sin_a = math.cos(rad), math.sin(rad)

        # Rotate about local center
        verts = self._orig_vertices
        cx = sum(v[0] for v in verts) / len(verts)
        cy = sum(v[1] for v in verts) / len(verts)
        rotated = []
        for vx, vy in verts:
            dx, dy = vx - cx, vy - cy
            rotated.append((cx + dx * cos_a - dy * sin_a,
                            cy + dx * sin_a + dy * cos_a))

        # If Rect, convert to Polygon (rotated rect isn't axis-aligned)
        if isinstance(self._element, Rect):
            new_poly = Polygon(vertices=rotated, layer=self._element.layer)
            if self._parent_cell is not None:
                elems = self._parent_cell.elements
                for i, e in enumerate(elems):
                    if e is self._element:
                        elems[i] = new_poly
                        break
            self._element = new_poly

        self._orig_vertices = rotated

        # Update local bbox
        xs = [v[0] for v in rotated]
        ys = [v[1] for v in rotated]
        self._local_bbox = (min(xs), min(ys), max(xs), max(ys))

        # Re-apply current translation
        ox, oy = self._origin
        self._element.vertices = [
            (vx + ox, vy + oy) for vx, vy in self._orig_vertices
        ]

    def _flip(self, axis: str) -> None:
        """Mirror vertices about the local center along the given axis."""
        from lumicron_api.models.elements import Rect, Polygon

        verts = self._orig_vertices
        cx = sum(v[0] for v in verts) / len(verts)
        cy = sum(v[1] for v in verts) / len(verts)

        if axis == "x":
            flipped = [(vx, 2 * cy - vy) for vx, vy in verts]
        else:
            flipped = [(2 * cx - vx, vy) for vx, vy in verts]

        if isinstance(self._element, Rect):
            new_poly = Polygon(vertices=flipped, layer=self._element.layer)
            if self._parent_cell is not None:
                elems = self._parent_cell.elements
                for i, e in enumerate(elems):
                    if e is self._element:
                        elems[i] = new_poly
                        break
            self._element = new_poly

        self._orig_vertices = flipped

        xs = [v[0] for v in flipped]
        ys = [v[1] for v in flipped]
        self._local_bbox = (min(xs), min(ys), max(xs), max(ys))

        ox, oy = self._origin
        self._element.vertices = [
            (vx + ox, vy + oy) for vx, vy in self._orig_vertices
        ]

    def flip_x(self) -> None:
        """Mirror element across the x-axis about its local center."""
        self._flip("x")

    def flip_y(self) -> None:
        """Mirror element across the y-axis about its local center."""
        self._flip("y")


class ArrayElementHandle:
    """Handle for one element of an array (arr[col, row] or arr[i]).

    Computes world position lazily from the parent array's current
    origin, so it always reflects the latest placement.
    """

    def __init__(self, array: ArrayHandle, col: int, row: int):
        self._array = array
        self._col = col
        self._row = row

    @property
    def _world_origin(self) -> tuple[float, float]:
        cpx, cpy = self._array._col_pitch
        rpx, rpy = self._array._row_pitch
        return (
            self._array._origin[0] + self._col * cpx + self._row * rpx,
            self._array._origin[1] + self._col * cpy + self._row * rpy,
        )

    @property
    def _elem_rotation(self) -> float:
        return getattr(self._array._cellref, 'rotation', 0) or 0

    @property
    def _elem_x_reflection(self) -> bool:
        return getattr(self._array._cellref, 'x_reflection', False) or False

    @property
    def world_bbox(self) -> tuple[float, float, float, float]:
        ox, oy = self._world_origin
        xmin, ymin, xmax, ymax = self._array._component.bbox
        corners = [(xmin, ymin), (xmax, ymin), (xmax, ymax), (xmin, ymax)]
        rot = self._elem_rotation
        refl = self._elem_x_reflection
        if refl:
            corners = [(x, -y) for x, y in corners]
        if rot != 0:
            rad = math.radians(rot)
            cos_a, sin_a = math.cos(rad), math.sin(rad)
            corners = [(x * cos_a - y * sin_a, x * sin_a + y * cos_a)
                       for x, y in corners]
        xs = [c[0] for c in corners]
        ys = [c[1] for c in corners]
        return (min(xs) + ox, min(ys) + oy, max(xs) + ox, max(ys) + oy)

    @property
    def C(self) -> tuple[float, float]:
        return _bbox_anchor(self.world_bbox, "C")

    @property
    def N(self) -> tuple[float, float]:
        return _bbox_anchor(self.world_bbox, "N")

    @property
    def S(self) -> tuple[float, float]:
        return _bbox_anchor(self.world_bbox, "S")

    @property
    def E(self) -> tuple[float, float]:
        return _bbox_anchor(self.world_bbox, "E")

    @property
    def W(self) -> tuple[float, float]:
        return _bbox_anchor(self.world_bbox, "W")

    @property
    def port(self) -> _PortAccessor:
        def _transform_port(p: Port) -> Port:
            return p.transformed(
                origin=self._world_origin,
                rotation=self._elem_rotation,
                x_reflection=self._elem_x_reflection,
            )
        return _PortAccessor(self._array._component, lambda: self._world_origin, _transform_port)
