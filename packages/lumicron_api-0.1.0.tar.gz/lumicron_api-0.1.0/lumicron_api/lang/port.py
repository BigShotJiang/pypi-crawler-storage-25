"""PORT — port definition primitive."""

from __future__ import annotations

from lumicron_api.models.layer import LayerSpec
from lumicron_api.models.port import Port
from lumicron_api.models.route_profile import RouteProfile


class PORT:
    """Port specification for adding ports to a cell.

    Usage with layer:
        c.add(PORT("in", position=(0, 5), direction=180, width=0.5, layer=wg))

    Usage with route profile (derives layer and width automatically):
        c.add(PORT("in", position=(0, 5), direction=180, route_profile=RPROF.siln_strip))
    """

    def __init__(
        self,
        name: str,
        position: tuple[float, float] = (0.0, 0.0),
        direction: float = 0.0,
        width: float | None = None,
        layer: LayerSpec | None = None,
        route_profile: RouteProfile | None = None,
        port_type: str = "optical",
    ):
        self.name = name
        self.position = position
        self.direction = direction
        self.route_profile = route_profile
        self.port_type = port_type

        if route_profile is not None:
            self.layer = layer or route_profile.layer
            self.width = width or route_profile.width
        else:
            self.layer = layer or LayerSpec(layer=0, datatype=0)
            self.width = width or 0.5

    def to_port(self) -> Port:
        return Port(
            name=self.name,
            position=self.position,
            direction=self.direction,
            width=self.width,
            layer=self.layer,
            route_profile=self.route_profile,
            port_type=self.port_type,
        )
