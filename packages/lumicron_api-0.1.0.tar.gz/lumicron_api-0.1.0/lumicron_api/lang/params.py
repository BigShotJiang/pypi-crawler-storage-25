"""@cell_params — decorator that exposes function arguments to the GUI."""

from __future__ import annotations

import functools
import inspect
from typing import Any


class ParametricCell:
    """A wrapped cell function with inspectable parameters.

    The GUI reads .params to populate editable fields.
    Calling the object creates a CELL with the given overrides.
    """

    def __init__(self, fn):
        functools.update_wrapper(self, fn)
        self._fn = fn
        self._sig = inspect.signature(fn)

        # Extract parameters with their defaults and type annotations
        self.params: dict[str, dict[str, Any]] = {}
        for name, param in self._sig.parameters.items():
            entry: dict[str, Any] = {}
            if param.default is not inspect.Parameter.empty:
                entry["default"] = param.default
            if param.annotation is not inspect.Parameter.empty:
                entry["type"] = param.annotation
            self.params[name] = entry

    @property
    def defaults(self) -> dict[str, Any]:
        """Return a dict of parameter names to their default values."""
        return {
            name: info["default"]
            for name, info in self.params.items()
            if "default" in info
        }

    def _make_name(self, kwargs: dict[str, Any]) -> str:
        """Build a unique cell name from function name + non-default args."""
        parts = [self._fn.__name__]
        defaults = self.defaults
        for name, value in sorted(kwargs.items()):
            if name in defaults and defaults[name] == value:
                continue
            # Compact representation for common types
            if isinstance(value, float) and value == int(value):
                parts.append(f"{name}={int(value)}")
            elif isinstance(value, list):
                inner = ",".join(str(v) for v in value)
                parts.append(f"{name}=[{inner}]")
            else:
                parts.append(f"{name}={value}")
        return "_".join(parts)

    def __call__(self, **kwargs):
        """Create a CELL with the given parameter overrides.

        Automatically renames the returned cell to include non-default
        parameter values, ensuring unique GDS cell names for different
        parameter combinations.
        """
        result = self._fn(**kwargs)
        # Rename the cell to include parameter signature
        new_name = self._make_name(kwargs)
        if hasattr(result, '_cell'):
            result._cell.name = new_name
        return result

    def __repr__(self) -> str:
        param_str = ", ".join(
            f"{name}={info.get('default', '?')}"
            for name, info in self.params.items()
        )
        return f"ParametricCell({self._fn.__name__}({param_str}))"


def cell_params(fn):
    """Decorator that marks a function as a parametric cell.

    Usage:
        @cell_params
        def TX_LANE(n=16, pitch=127, dx_io=250):
            c = CELL("TX_LANE")
            ...
            return c

        # Call with defaults
        cell = TX_LANE()

        # Call with overrides
        cell = TX_LANE(n=32, pitch=250)

        # Inspect parameters (for GUI)
        TX_LANE.params     # {'n': {'default': 16}, 'pitch': {'default': 127}, ...}
        TX_LANE.defaults   # {'n': 16, 'pitch': 127, 'dx_io': 250}
    """
    return ParametricCell(fn)
