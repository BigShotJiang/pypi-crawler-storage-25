"""Open a layout in an external GDS viewer.

Usage:
    import lumicron_api.all as lm

    c = lm.CELL("MyChip")
    # ... build layout ...
    lm.view_layout(c)
"""

from __future__ import annotations

import os
import subprocess
import tempfile
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from lumicron_api.lang.cell import CELL
    from lumicron_api.models.layout import Layout

# Default viewer app name. Set to None to use macOS default for .gds files.
_VIEWER_APP: str | None = "Lumicron"


def set_viewer(app_name: str | None) -> None:
    """Set the viewer application name.

    Args:
        app_name: macOS app name (e.g. "Lumicron"), or None to use
            the system default handler for .gds files.
    """
    global _VIEWER_APP
    _VIEWER_APP = app_name


def view_layout(target: CELL | Layout, keep_file: bool = False) -> str:
    """Write a GDS file and open it in the viewer.

    Args:
        target: A CELL builder or a Layout object.
        keep_file: If True, write to current directory instead of temp.
            The file name will be based on the cell/layout name.

    Returns:
        Path to the written GDS file.
    """
    from lumicron_api.lang.cell import CELL
    from lumicron_api.models.layout import Layout

    if isinstance(target, CELL):
        layout = target.to_layout()
        name = target._cell.name
    elif isinstance(target, Layout):
        layout = target
        name = target.top_cell
    else:
        raise TypeError(f"Expected CELL or Layout, got {type(target).__name__}")

    if keep_file:
        path = f"{name}.gds"
    else:
        fd, path = tempfile.mkstemp(suffix=".gds", prefix=f"{name}_")
        os.close(fd)

    layout.to_gds(path)

    cmd = ["open"]
    if _VIEWER_APP:
        cmd += ["-a", _VIEWER_APP]
    cmd.append(path)

    try:
        subprocess.Popen(cmd)
    except FileNotFoundError:
        # Fallback: open without specifying app
        subprocess.Popen(["open", path])

    return path
