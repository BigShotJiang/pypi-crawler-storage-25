"""ARRAY — structural composition primitive."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from lumicron_api.lang.cell import CELL


class ARRAY:
    """Array specification — creates a 1-D or 2-D array of cell instances.

    Usage:
        # 1D array: count is an int
        io = c.add(ARRAY(COUPLER, count=16, pitch=(0, 127)))

        # 2D array: count is (columns, rows)
        vias = c.add(ARRAY(VIA, count=(10, 5), pitch=(1.5, 1.5)))

    If component is callable and params is provided, calls component(**params)
    to produce the cell. Otherwise component is used directly.
    """

    def __init__(
        self,
        component,
        count: int | tuple[int, int],
        pitch: tuple[float, float],
        params: dict | None = None,
        rotation: float = 0,
    ):
        if callable(component) and not isinstance(component, type):
            self.component: CELL = component(**(params or {}))
        else:
            self.component = component

        # Normalize to (columns, rows)
        if isinstance(count, tuple):
            self.columns, self.rows = count
        else:
            # 1D: infer axis from pitch
            px, py = pitch
            if py == 0 or px != 0:
                self.columns, self.rows = count, 1
            else:
                self.columns, self.rows = 1, count

        self.count = count  # preserve original for back-compat
        self.pitch = pitch
        self.rotation = rotation
