"""route_profile() — convenience factory for creating route profiles."""

from __future__ import annotations

from lumicron_api.models.layer import LayerSpec
from lumicron_api.models.route_profile import CladdingLayer, RouteProfile


def route_profile(
    layer: LayerSpec,
    width: float,
    radius: float = 0.0,
    *,
    radius_min: float | None = None,
    cladding: dict[LayerSpec, float] | None = None,
    port_type: str | None = None,
    name: str | None = None,
) -> RouteProfile:
    """Create a route profile with minimal boilerplate.

    Args:
        layer:      The routing layer.
        width:      Default waveguide/trace width in microns.
        radius:     Default bend radius in microns.
        radius_min: Minimum allowed bend radius (defaults to radius).
        cladding:   Cladding layers as {layer: offset} dict.
                    Example: {pdk.LAYER.OXID: 2.0}
        port_type:  "optical" or "electrical" (stored for future use).
        name:       Profile name (auto-generated from layer if omitted).

    Returns:
        A RouteProfile instance.

    Examples:
        # Simple
        strip = lm.route_profile(pdk.LAYER.SILC, width=0.5, radius=10)

        # With cladding
        strip = lm.route_profile(pdk.LAYER.SILC, width=0.5, radius=10,
                                  cladding={pdk.LAYER.OXID: 2.0})

        # With minimum radius
        rib = lm.route_profile(pdk.LAYER.SILC, width=1.5, radius=20, radius_min=10)
    """
    if name is None:
        name = f"L{layer.layer}_{width}w_{radius}r"

    clad_list: list[CladdingLayer] = []
    if cladding:
        for clad_layer, offset in cladding.items():
            clad_list.append(CladdingLayer(layer=clad_layer, offset=offset))

    return RouteProfile(
        name=name,
        layer=layer,
        width=width,
        radius=radius,
        radius_min=radius_min if radius_min is not None else radius,
        cladding=clad_list,
    )
