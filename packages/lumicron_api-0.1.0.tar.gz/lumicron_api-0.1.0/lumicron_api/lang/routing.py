"""RouteChain — descriptor chain for c.Route()."""

from __future__ import annotations

import math as _math
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from lumicron_api.models.route_profile import RouteProfile
from lumicron_api.models.elements import CellRef, FlexRoute, Polygon
from lumicron_api.models.layer import LayerSpec
from lumicron_api.models.port import Port

if TYPE_CHECKING:
    from lumicron_api.lang.cell import CELL


_DIRECTION_MAP = {
    "E": (1, 0),
    "W": (-1, 0),
    "N": (0, 1),
    "S": (0, -1),
}

# Diagonal directions for S-bends: (sign_x, sign_y)
_DIAGONAL_MAP = {
    "NE": (1, 1),
    "NW": (-1, 1),
    "SE": (1, -1),
    "SW": (-1, -1),
}

_DEFAULT_TAPER_LENGTH = 2.0


def _dir_vec(direction_deg: float) -> tuple[float, float]:
    """Unit vector for a port direction in degrees."""
    rad = _math.radians(direction_deg)
    return (round(_math.cos(rad), 6), round(_math.sin(rad), 6))


def _perp_vec(d: tuple[float, float]) -> tuple[float, float]:
    """90° counter-clockwise perpendicular to a unit vector."""
    return (-d[1], d[0])


@dataclass
class _Segment:
    """One piece of a route — manhattan waypoints or an S-bend curve."""
    points: list[tuple[float, float]] = field(default_factory=list)
    is_sbend: bool = False


def _compute_sbend_points(
    forward: float,
    lateral: float,
    radius: float = 0.0,
    bend_type: str = "circular",
    p: float = 0.5,
    num_points: int = 100,
) -> list[tuple[float, float]]:
    """Compute S-bend curve points in local coordinates.

    Local frame: x = forward (travel direction), y = lateral (perpendicular).
    Returns points from (0, 0) to approximately (forward, lateral).

    The S-bend is two mirrored arcs joined at an inflection point.
    Optional straight segments pad the start/end when the forward distance
    exceeds what the arcs require.

    Args:
        forward: Distance in the travel direction (must be positive).
        lateral: Signed offset perpendicular to travel.
        radius: Bend radius. If 0, computed from geometry (minimum radius).
        bend_type: "circular" or "euler".
        p: Euler fraction (0=circular, 0.5=full euler). Only for "euler".
        num_points: Number of sample points on the curve.

    Returns:
        List of (x, y) points in local coordinates.
    """
    if abs(lateral) < 1e-6:
        # No lateral offset — straight line
        return [(0.0, 0.0), (forward, 0.0)]

    if forward < 1e-6:
        raise ValueError(
            f"S-bend forward distance must be positive, got {forward:.4f}. "
            f"The route must advance in the travel direction."
        )

    if bend_type == "euler":
        return _compute_euler_sbend_points(forward, lateral, radius, p, num_points)

    return _compute_circular_sbend_points(forward, lateral, radius, num_points)


def _compute_circular_sbend_points(
    forward: float,
    lateral: float,
    radius: float = 0.0,
    num_points: int = 100,
) -> list[tuple[float, float]]:
    """Circular S-bend: two mirrored constant-radius arcs."""
    import warnings as _w

    h = abs(lateral)
    sign = 1.0 if lateral > 0 else -1.0

    # Natural radius: the unique R that makes a pure S-bend (no straight padding)
    R_natural = (forward ** 2 + h ** 2) / (4.0 * h)

    if radius > 0:
        if radius < R_natural - 1e-3:
            _w.warn(
                f"S-bend radius {radius:.2f} is smaller than the minimum "
                f"radius {R_natural:.2f} for this geometry "
                f"(forward={forward:.2f}, lateral={lateral:.2f}). "
                f"Using minimum radius {R_natural:.2f}.",
                stacklevel=4,
            )
        R = max(radius, R_natural)
    else:
        R = R_natural

    # Arc angle: alpha = arccos(1 - h/(2R))
    cos_alpha = 1.0 - h / (2.0 * R)
    cos_alpha = max(-1.0, min(1.0, cos_alpha))  # clamp for float precision
    alpha = _math.acos(cos_alpha)

    # Horizontal span of the two arcs
    dx_bend = 2.0 * R * _math.sin(alpha)
    dx_pad = (forward - dx_bend) / 2.0

    if dx_pad < -1e-3:
        raise ValueError(
            f"S-bend radius {R:.2f} is too large for forward distance "
            f"{forward:.2f}. Minimum forward distance for R={R:.2f} "
            f"and lateral={lateral:.2f}: {dx_bend:.2f}."
        )
    dx_pad = max(0.0, dx_pad)

    # Generate points — all computed for positive h, then apply sign
    points: list[tuple[float, float]] = []
    n_half = max(num_points // 2, 10)

    # Arc 1: center at (dx_pad, R), CCW from -pi/2 to -pi/2 + alpha
    cx1, cy1 = dx_pad, R
    theta_start_1 = -_math.pi / 2.0
    theta_end_1 = -_math.pi / 2.0 + alpha

    for i in range(n_half + 1):
        t = i / n_half
        theta = theta_start_1 + t * (theta_end_1 - theta_start_1)
        x = cx1 + R * _math.cos(theta)
        y = cy1 + R * _math.sin(theta)
        points.append((x, sign * y))

    # Arc 2: center at (dx_pad + 2R*sin(alpha), h/2 - R*cos(alpha))
    #   CW sweep from (pi/2 + alpha) down to pi/2
    cx2 = dx_pad + 2.0 * R * _math.sin(alpha)
    cy2 = h / 2.0 - R * _math.cos(alpha)
    theta_start_2 = _math.pi / 2.0 + alpha
    theta_end_2 = _math.pi / 2.0

    for i in range(1, n_half + 1):  # skip i=0, same as last point of arc 1
        t = i / n_half
        theta = theta_start_2 + t * (theta_end_2 - theta_start_2)
        x = cx2 + R * _math.cos(theta)
        y = cy2 + R * _math.sin(theta)
        points.append((x, sign * y))

    # Add straight padding endpoints if needed
    if dx_pad > 1e-6:
        points.insert(0, (0.0, 0.0))
        points.append((forward, lateral))

    return points


def _compute_euler_sbend_points(
    forward: float,
    lateral: float,
    radius: float = 0.0,
    p: float = 0.5,
    num_points: int = 100,
) -> list[tuple[float, float]]:
    """Euler S-bend: two mirrored euler spiral arcs.

    Euler arcs have curvature that ramps linearly from zero at the
    endpoints to a maximum at the arc midpoint. This produces zero
    curvature at the S-bend entry/exit — smoother transitions than
    circular arcs.

    The curvature profile for each half-bend:
    - First p fraction: κ ramps 0 → κ_max
    - Middle (1-2p) fraction: κ = κ_max (circular)
    - Last p fraction: κ ramps κ_max → 0

    With p=0 this degenerates to circular. With p=0.5 it's full euler.
    """
    h = abs(lateral)
    sign = 1.0 if lateral > 0 else -1.0
    p = max(0.0, min(p, 0.5))

    import warnings as _w

    # Use circular geometry to determine the arc angle
    R_natural = (forward ** 2 + h ** 2) / (4.0 * h)
    if radius > 0 and radius < R_natural - 1e-3:
        _w.warn(
            f"S-bend radius {radius:.2f} is smaller than the minimum "
            f"radius {R_natural:.2f} for this geometry "
            f"(forward={forward:.2f}, lateral={lateral:.2f}). "
            f"Using minimum radius {R_natural:.2f}.",
            stacklevel=4,
        )
    R = max(radius, R_natural) if radius > 0 else R_natural

    cos_alpha = max(-1.0, min(1.0, 1.0 - h / (2.0 * R)))
    alpha = _math.acos(cos_alpha)

    # For each half-bend: the total angle turned is alpha
    arc_len = R * alpha
    euler_len = arc_len * p
    circ_len = arc_len * (1.0 - 2.0 * p)
    k_max = 1.0 / (R * (1.0 - p)) if abs(1.0 - p) > 1e-12 else 1.0 / R

    n_half = max(num_points // 2, 20)

    def _euler_half_curve(n_pts: int, turn_sign: float):
        """Generate one half of the S-bend via curvature integration.

        turn_sign: +1 for CCW (first half), -1 for CW (second half).
        Returns points in local frame starting from (0, 0) heading +x.
        """
        pts = [(0.0, 0.0)]
        heading = 0.0
        x, y = 0.0, 0.0
        ds = arc_len / n_pts

        for j in range(n_pts):
            s = (j + 0.5) * ds  # midpoint rule for better accuracy
            # Curvature at this arc-length position
            if euler_len > 1e-12 and s <= euler_len:
                k = k_max * (s / euler_len)
            elif s <= euler_len + circ_len:
                k = k_max
            elif euler_len > 1e-12:
                k = k_max * ((arc_len - s) / euler_len)
            else:
                k = k_max

            heading += k * turn_sign * ds
            x += _math.cos(heading) * ds
            y += _math.sin(heading) * ds
            pts.append((x, y))

        return pts

    # Half 1: CCW turn (heading goes from 0 to +alpha)
    half1 = _euler_half_curve(n_half, +1.0)
    # Half 2: CW turn (heading goes from +alpha to 0)
    half2 = _euler_half_curve(n_half, -1.0)

    # Half 1 raw endpoint and expected endpoint for normalization
    # The S-bend's half should go from (0,0) to (dx_bend/2, h/2) in the local frame
    dx_half = forward / 2.0
    dy_half = h / 2.0

    # Normalize half 1 to land at (dx_half, dy_half)
    raw_end = half1[-1]
    raw_len = _math.hypot(raw_end[0], raw_end[1])
    exp_len = _math.hypot(dx_half, dy_half)

    if raw_len > 1e-12 and exp_len > 1e-12:
        scale = exp_len / raw_len
        raw_angle = _math.atan2(raw_end[1], raw_end[0])
        exp_angle = _math.atan2(dy_half, dx_half)
        rot = exp_angle - raw_angle
        cos_r = _math.cos(rot)
        sin_r = _math.sin(rot)
        norm1 = [
            (scale * (cos_r * px - sin_r * py),
             scale * (sin_r * px + cos_r * py))
            for px, py in half1
        ]
    else:
        norm1 = half1

    # Half 2: mirror of half 1 about the midpoint
    # Start from the inflection point (dx_half, dy_half) and curve to (forward, h)
    raw_end2 = half2[-1]
    raw_len2 = _math.hypot(raw_end2[0], raw_end2[1])

    if raw_len2 > 1e-12 and exp_len > 1e-12:
        scale2 = exp_len / raw_len2
        raw_angle2 = _math.atan2(raw_end2[1], raw_end2[0])
        # Half 2 should go from inflection to (forward, h)
        # In local frame relative to inflection: (+dx_half, +dy_half)... no
        # Actually half 2 goes from inflection to endpoint.
        # The displacement from inflection to endpoint = (dx_half, dy_half) in
        # the original frame — BUT the heading at inflection is +alpha, so the
        # local frame is rotated. The half 2 curve starts heading at angle alpha
        # and turns back to horizontal.
        #
        # We need half 2's displacement to be (dx_half, dy_half) when rotated
        # by the inflection heading (alpha).
        exp_dx2 = dx_half
        exp_dy2 = dy_half
        exp_angle2 = _math.atan2(exp_dy2, exp_dx2)

        # The half2 curve was generated starting at heading=0 (local +x).
        # We need to rotate it to start at heading=alpha (the inflection heading).
        # First normalize in local frame, then rotate by alpha.
        scale2 = exp_len / raw_len2
        raw_angle2 = _math.atan2(raw_end2[1], raw_end2[0])

        # Rotate half2 so its start heading matches the end heading of half1
        inflection_heading = _math.atan2(
            norm1[-1][1] - norm1[-2][1],
            norm1[-1][0] - norm1[-2][0],
        ) if len(norm1) >= 2 else 0.0

        cos_ih = _math.cos(inflection_heading)
        sin_ih = _math.sin(inflection_heading)

        # Rotate half2 points by inflection heading
        rotated2 = [
            (cos_ih * px - sin_ih * py,
             sin_ih * px + cos_ih * py)
            for px, py in half2
        ]

        # Now normalize to hit (dx_half, dy_half) from inflection
        rot2_end = rotated2[-1]
        rot2_len = _math.hypot(rot2_end[0], rot2_end[1])

        if rot2_len > 1e-12:
            s2 = exp_len / rot2_len
            a2_raw = _math.atan2(rot2_end[1], rot2_end[0])
            a2_exp = _math.atan2(exp_dy2, exp_dx2)
            rot2 = a2_exp - a2_raw
            cos_r2 = _math.cos(rot2)
            sin_r2 = _math.sin(rot2)
            norm2 = [
                (s2 * (cos_r2 * px - sin_r2 * py),
                 s2 * (sin_r2 * px + cos_r2 * py))
                for px, py in rotated2
            ]
        else:
            norm2 = rotated2
    else:
        norm2 = half2

    # Translate half 2 to start at inflection point
    inf_x, inf_y = norm1[-1]
    translated2 = [(inf_x + px, inf_y + py) for px, py in norm2]

    # Combine halves (skip first point of half 2 — same as last of half 1)
    points = [(x, sign * y) for x, y in norm1]
    for x, y in translated2[1:]:
        points.append((x, sign * y))

    # Check if padding is needed
    dx_bend = 2.0 * R * _math.sin(alpha)
    dx_pad = (forward - dx_bend) / 2.0
    if dx_pad > 1e-6:
        points.insert(0, (0.0, 0.0))
        points.append((forward, lateral))

    return points


def _transform_sbend_to_world(
    local_points: list[tuple[float, float]],
    origin: tuple[float, float],
    angle_rad: float,
) -> list[tuple[float, float]]:
    """Rotate and translate local S-bend points into world coordinates.

    Args:
        local_points: Points in local frame (x=forward, y=lateral).
        origin: World position of the S-bend start.
        angle_rad: Travel direction angle in radians (0 = +X).
    """
    cos_a = _math.cos(angle_rad)
    sin_a = _math.sin(angle_rad)
    ox, oy = origin
    result = []
    for lx, ly in local_points:
        wx = ox + lx * cos_a - ly * sin_a
        wy = oy + lx * sin_a + ly * cos_a
        result.append((wx, wy))
    return result


@dataclass
class _TaperSpec:
    """Configuration for one end's taper."""
    length: float = _DEFAULT_TAPER_LENGTH
    cell: object | None = None  # CELL instance, or None for linear trapezoid
    disabled: bool = False
    at: float | None = None  # distance from port along route to place taper
    width: float | None = None  # target width after taper (default: other port's width)


def _make_linear_taper(
    port_pos: tuple[float, float],
    direction: tuple[float, float],
    port_width: float,
    route_width: float,
    taper_length: float,
    layer: LayerSpec,
) -> Polygon:
    """Create a trapezoidal taper polygon.

    The taper starts at port_pos (with port_width) and extends along
    the direction vector for taper_length, ending at route_width.
    """
    perp = _perp_vec(direction)
    dx, dy = direction

    # Start edge (at port): two corners offset perpendicular by ±port_width/2
    s0 = (port_pos[0] + perp[0] * port_width / 2,
          port_pos[1] + perp[1] * port_width / 2)
    s1 = (port_pos[0] - perp[0] * port_width / 2,
          port_pos[1] - perp[1] * port_width / 2)

    # End edge (at route): shifted along direction by taper_length
    end_x = port_pos[0] + dx * taper_length
    end_y = port_pos[1] + dy * taper_length
    e0 = (end_x + perp[0] * route_width / 2,
          end_y + perp[1] * route_width / 2)
    e1 = (end_x - perp[0] * route_width / 2,
          end_y - perp[1] * route_width / 2)

    return Polygon(vertices=[s0, e0, e1, s1], layer=layer)


def _validate_route(
    points: list[tuple[float, float]],
    pa: Port,
    pb: Port,
) -> None:
    """Validate that a route respects both port directions.

    Raises ValueError if the first segment exits port A in the wrong
    direction, the last segment enters port B from the wrong direction,
    or the route backtracks on itself.
    """
    if len(points) < 2:
        return

    da = _dir_vec(pa.direction)
    db = _dir_vec(pb.direction)

    # First segment must exit along port A's direction
    s = (points[1][0] - points[0][0], points[1][1] - points[0][1])
    if s[0] * da[0] + s[1] * da[1] < -1e-6:
        raise ValueError(
            f"Route exits port '{pa.name}' (dir={pa.direction}°) in the "
            f"wrong direction. Check port placement and positions."
        )

    # Last segment must enter port B from OUTSIDE — i.e. opposite to port
    # B's facing direction.  If the segment aligns WITH db, the route is
    # approaching from behind the port.
    s = (points[-1][0] - points[-2][0], points[-1][1] - points[-2][1])
    if s[0] * db[0] + s[1] * db[1] > 1e-6:
        raise ValueError(
            f"Route enters port '{pb.name}' (dir={pb.direction}°) from the "
            f"wrong direction. Check port placement and positions."
        )

    # No backtracking: consecutive segments on the same axis must not reverse
    for i in range(len(points) - 2):
        s1 = (points[i + 1][0] - points[i][0],
              points[i + 1][1] - points[i][1])
        s2 = (points[i + 2][0] - points[i + 1][0],
              points[i + 2][1] - points[i + 1][1])
        dot = s1[0] * s2[0] + s1[1] * s2[1]
        cross = abs(s1[0] * s2[1] - s1[1] * s2[0])
        if dot < -1e-6 and cross < 1e-6:
            raise ValueError(
                f"Route between '{pa.name}' (dir={pa.direction}°) and "
                f"'{pb.name}' (dir={pb.direction}°) backtracks. "
                f"Use .go() for manual routing."
            )


def _validate_bend_radius(
    points: list[tuple[float, float]],
    bend_radius: float,
    pa: Port,
    pb: Port,
) -> None:
    """Check that every segment is long enough for the bend radius.

    At each interior vertex (a 90° turn), the bend consumes bend_radius
    worth of length on both adjacent segments. If a segment is shared by
    two bends, it needs 2*bend_radius.

    Raises ValueError if any segment is too short.
    """
    if bend_radius <= 0 or len(points) < 3:
        return

    n = len(points)
    # For each segment, compute how much bend radius it must accommodate
    for i in range(n - 1):
        seg_len = _math.hypot(
            points[i + 1][0] - points[i][0],
            points[i + 1][1] - points[i][1],
        )
        # How much bend eats into this segment from each end
        needed = 0.0
        if i > 0:
            # There's a bend at the start of this segment
            needed += bend_radius
        if i < n - 2:
            # There's a bend at the end of this segment
            needed += bend_radius

        if seg_len < needed - 1e-3:
            raise ValueError(
                f"Route segment {i} between "
                f"({points[i][0]:.2f}, {points[i][1]:.2f}) and "
                f"({points[i+1][0]:.2f}, {points[i+1][1]:.2f}) "
                f"is {seg_len:.2f} µm long but needs at least "
                f"{needed:.2f} µm for bend_radius={bend_radius}. "
                f"Route: '{pa.name}' -> '{pb.name}'."
            )


def _auto_route(pa: Port, pb: Port) -> list[tuple[float, float]]:
    """Generate a manhattan route between two ports, respecting directions.

    Both ports are respected: the first segment exits port A along its
    facing direction, and the last segment enters port B along its facing
    direction (approaching from outside).
    """
    ax, ay = pa.position
    bx, by = pb.position

    # Direction vectors (unit vectors pointing OUT of each port)
    da = _dir_vec(pa.direction)
    db = _dir_vec(pb.direction)

    # Extension length: enough to clear both ports before turning.
    ext = max(abs(bx - ax), abs(by - ay)) / 4
    ext = max(ext, 1.0)  # minimum 1 µm

    # Exit stub from port A along its direction
    a_ext = (ax + da[0] * ext, ay + da[1] * ext)
    # Entry stub into port B — place approach point along port B's facing
    # direction (where the port mouth is), so the final segment enters
    # the port from outside heading inward.
    b_ext = (bx + db[0] * ext, by + db[1] * ext)

    # Check straight-line shortcut only if both port directions are satisfied
    if abs(ay - by) < 1e-6 and abs(ax - bx) > 1e-6:
        seg_dx = bx - ax
        if (seg_dx * da[0] > 1e-6 and -seg_dx * db[0] > 1e-6):
            return [(ax, ay), (bx, by)]
    if abs(ax - bx) < 1e-6 and abs(ay - by) > 1e-6:
        seg_dy = by - ay
        if (seg_dy * da[1] > 1e-6 and -seg_dy * db[1] > 1e-6):
            return [(ax, ay), (bx, by)]

    ex, ey = a_ext
    fx, fy = b_ext

    # Build waypoints between the two extension points
    points = [(ax, ay), a_ext]

    if abs(ex - fx) < 1e-6 and abs(ey - fy) < 1e-6:
        # Extensions meet — done
        pass
    elif abs(ex - fx) < 1e-6 or abs(ey - fy) < 1e-6:
        # Aligned on one axis — check if direct segment backtracks
        seg = (fx - ex, fy - ey)
        if seg[0] * da[0] + seg[1] * da[1] < -1e-6:
            # Direct segment would reverse the exit direction — U-turn needed.
            # Detour perpendicular by the extension length.
            if abs(ey - fy) < 1e-6:
                # Same y: detour via y offset
                detour = ext
                points.append((ex, ey + detour))
                points.append((fx, fy + detour))
            else:
                # Same x: detour via x offset
                detour = ext
                points.append((ex + detour, ey))
                points.append((fx + detour, fy))
            points.append(b_ext)
        else:
            points.append(b_ext)
    else:
        # Try L-bend variant 1: horizontal then vertical
        mid1 = (fx, ey)
        # Try L-bend variant 2: vertical then horizontal
        mid2 = (ex, fy)

        # Check which variant avoids backtracking.
        # A backtrack occurs when the segment from a_ext reverses the
        # exit direction, or the segment into b_ext reverses the entry.
        def _backtracks(mid: tuple[float, float]) -> bool:
            # a_ext → mid: should not reverse da
            s1 = (mid[0] - ex, mid[1] - ey)
            if s1[0] * da[0] + s1[1] * da[1] < -1e-6:
                return True
            # mid → b_ext: should not reverse into db direction
            s2 = (fx - mid[0], fy - mid[1])
            # b_ext → port_b goes opposite to db; mid→b_ext should not
            # go in db's direction on the same axis
            if abs(s2[0]) > 1e-6 and abs(s2[1]) < 1e-6:
                if s2[0] * db[0] > 1e-6:
                    return True
            if abs(s2[1]) > 1e-6 and abs(s2[0]) < 1e-6:
                if s2[1] * db[1] > 1e-6:
                    return True
            return False

        if not _backtracks(mid1):
            points.append(mid1)
            if abs(mid1[0] - fx) > 1e-6 or abs(mid1[1] - fy) > 1e-6:
                points.append(b_ext)
        elif not _backtracks(mid2):
            points.append(mid2)
            if abs(mid2[0] - fx) > 1e-6 or abs(mid2[1] - fy) > 1e-6:
                points.append(b_ext)
        else:
            # Both L-bends backtrack — use Z-bend through midpoint.
            # Go perpendicular from a_ext, cross to b_ext's column/row,
            # then perpendicular into b_ext.
            mid_y = (ey + fy) / 2
            mid_x = (ex + fx) / 2
            # Choose Z orientation based on exit direction
            if abs(da[0]) > abs(da[1]):
                # Exited horizontally → Z goes: vertical, horizontal, vertical
                points.append((ex, mid_y))
                points.append((fx, mid_y))
            else:
                # Exited vertically → Z goes: horizontal, vertical, horizontal
                points.append((mid_x, ey))
                points.append((mid_x, fy))
            points.append(b_ext)

    points.append((bx, by))

    # Deduplicate consecutive identical points
    cleaned: list[tuple[float, float]] = [points[0]]
    for p in points[1:]:
        if abs(p[0] - cleaned[-1][0]) > 1e-6 or abs(p[1] - cleaned[-1][1]) > 1e-6:
            cleaned.append(p)

    return cleaned


def _is_cardinal(direction_deg: float) -> bool:
    """Check if a port direction is cardinal (0, 90, 180, 270)."""
    d = direction_deg % 360
    return any(abs(d - c) < 1e-3 for c in (0, 90, 180, 270))


def _smart_auto_route(
    pa: Port,
    pb: Port,
    radius: float = 0.0,
    bend_type: str = "circular",
    bend_p: float = 0.5,
) -> tuple[list[tuple[float, float]], bool]:
    """Smart auto-route: picks manhattan or S-bend based on port geometry.

    Returns:
        (points, is_sbend) — the route points and whether they form an S-bend.

    Logic:
        1. Both ports cardinal → try manhattan (backward compat)
        2. Either port non-cardinal → S-bend
        3. Manhattan fails → fall back to S-bend
    """
    both_cardinal = _is_cardinal(pa.direction) and _is_cardinal(pb.direction)

    if both_cardinal:
        # Try manhattan first
        try:
            points = _auto_route(pa, pb)
            _validate_route(points, pa, pb)
            return points, False
        except ValueError:
            pass  # Manhattan failed — try S-bend below

    # S-bend auto-route: connect pa to pb with an S-bend curve
    ax, ay = pa.position
    bx, by = pb.position
    world_dx = bx - ax
    world_dy = by - ay

    # Travel direction from port A
    travel_angle = _math.radians(pa.direction)
    cos_a = _math.cos(travel_angle)
    sin_a = _math.sin(travel_angle)

    # Project onto travel direction
    forward = world_dx * cos_a + world_dy * sin_a
    lateral = -world_dx * sin_a + world_dy * cos_a

    if forward < 1e-6:
        if both_cardinal:
            # Can't do S-bend either — fall back to manhattan (will defer error)
            return _auto_route(pa, pb), False
        raise ValueError(
            f"Cannot auto-route from '{pa.name}' to '{pb.name}': "
            f"target is behind port A's facing direction."
        )

    try:
        local_pts = _compute_sbend_points(
            forward=forward,
            lateral=lateral,
            radius=radius,
            bend_type=bend_type,
            p=bend_p,
        )
        world_pts = _transform_sbend_to_world(local_pts, (ax, ay), travel_angle)
        return world_pts, True
    except ValueError:
        if both_cardinal:
            # S-bend failed too — use manhattan (will defer error)
            return _auto_route(pa, pb), False
        raise


class RouteChain:
    """Fluent routing API.

    Usage:
        c.Route(port_a, port_b).style("wg").radius(10)
        c.Route(port_a, port_b).go("E", by=50).go("N", to=100)

    The route is created immediately when c.Route() is called.
    Chain methods modify the FlexRoute element in place.

    Validation runs when the chain is finalized (end of statement).
    If .go() is used, only the manual path is validated — the initial
    auto-route placeholder is discarded.
    """

    def __init__(
        self,
        cell_builder: CELL,
        port_a: Port,
        port_b: Port,
        radius: float = 0.0,
        bend: str | None = None,
        p: float | None = None,
        profile: RouteProfile | None = None,
    ):
        import warnings as _warnings

        self._cell = cell_builder
        self._port_a = port_a
        self._port_b = port_b
        self._manual_points: list[tuple[float, float]] | None = None
        self._segments: list[_Segment] | None = None  # mixed manhattan/sbend
        self._deferred_error: ValueError | None = None

        # Detect custom bend PCell vs string bend type
        from lumicron_api.lang.cell import CELL as _CELL
        if bend is not None and isinstance(bend, _CELL):
            self._bend_cell = bend
            self._bend_type = "custom"
            self._bend_p = 0.5
            self._validate_bend_cell(bend)
            cell_builder._dependencies.add(bend)
        else:
            self._bend_cell = None
            # Resolve bend type and p value
            if p is not None and bend is None:
                _warnings.warn(
                    f"p={p} was set without bend=\"euler\" — using euler bend "
                    f"automatically. If this is intentional, add bend=\"euler\" "
                    f"for cleaner code. If not, remove the p parameter.",
                    stacklevel=3,
                )
                bend = "euler"
            self._bend_type = bend or "circular"
            self._bend_p = p if p is not None else 0.5

        # Taper configuration — materialized at export time
        self._start_taper = _TaperSpec()
        self._end_taper = _TaperSpec()
        self._tapers_materialized = False

        # Resolve route properties from profile, then kwargs
        route_width = port_a.width
        route_layer = port_a.layer
        route_radius = radius

        if profile is not None:
            route_layer = profile.layer
            route_width = profile.width
            if profile.radius > 0 and radius == 0.0:
                route_radius = profile.radius

        # Custom bend PCell: bend_radius=0 (PCell handles corners)
        if self._bend_cell is not None:
            route_radius = 0.0

        # Create the FlexRoute with auto-routed path
        points, auto_sbend = _smart_auto_route(
            port_a, port_b, route_radius,
            bend_type=self._bend_type if self._bend_type != "custom" else "circular",
            bend_p=self._bend_p,
        )
        if auto_sbend:
            # Auto-route chose S-bend — set up segments for decomposition
            self._segments = [_Segment(points=points, is_sbend=True)]
            self._manual_points = [port_a.position, port_b.position]
        self._route = FlexRoute(
            points=points,
            width=route_width,
            layer=route_layer,
            bend_radius=route_radius,
            bend_type=self._bend_type if self._bend_type != "custom" else "circular",
            bend_p=self._bend_p,
        )
        cell_builder._cell.add_element(self._route)

        # Validate bend radius if set (skip for custom bend PCells and S-bends)
        if route_radius > 0 and self._bend_cell is None and not auto_sbend:
            try:
                _validate_bend_radius(points, route_radius, port_a, port_b)
            except ValueError as e:
                self._deferred_error = e

        # Validate the auto-route. If it fails, defer the error — it will
        # be raised when the chain is finalized, unless .go() replaces it.
        # Skip validation for S-bend auto-routes (dense curve points).
        if self._deferred_error is None and not auto_sbend:
            try:
                _validate_route(points, port_a, port_b)
            except ValueError as e:
                self._deferred_error = e

    def _raise_if_invalid(self) -> None:
        """Raise the deferred validation error if present."""
        if self._deferred_error is not None:
            raise self._deferred_error

    # ── Custom bend PCell support ────────────────────────────────

    @staticmethod
    def _validate_bend_cell(bend_cell) -> None:
        """Validate that a CELL is a valid 90° bend PCell."""
        ports = bend_cell._cell.ports
        if "i1" not in ports:
            raise ValueError(
                f"Custom bend cell {bend_cell.name!r} is missing port 'i1'. "
                f"A bend PCell must have ports 'i1' (entry) and 'o1' (exit)."
            )
        if "o1" not in ports:
            raise ValueError(
                f"Custom bend cell {bend_cell.name!r} is missing port 'o1'. "
                f"A bend PCell must have ports 'i1' (entry) and 'o1' (exit)."
            )

    def _decompose_custom_bends(self) -> None:
        """Replace single FlexRoute with straight segments + bend CellRefs.

        Called after _materialize_tapers() in to_layout(). Only runs when
        _bend_cell is set. Removes self._route from cell elements and adds
        straight FlexRoute segments + CellRef for each 90° corner.
        """
        if self._bend_cell is None:
            return

        points = list(self._route.points)
        if len(points) < 3:
            return  # Straight route, no corners to decompose

        bend_cell = self._bend_cell
        i1 = bend_cell._cell.ports["i1"]
        o1 = bend_cell._cell.ports["o1"]

        # Trim amounts from bend PCell port positions (local coords)
        ix, iy = i1.position
        ox, oy = o1.position
        incoming_trim = abs(ox - ix)
        outgoing_trim = abs(oy - iy)

        # Find all 90° corners
        corners = []
        for i in range(1, len(points) - 1):
            dx_in = points[i][0] - points[i - 1][0]
            dy_in = points[i][1] - points[i - 1][1]
            dx_out = points[i + 1][0] - points[i][0]
            dy_out = points[i + 1][1] - points[i][1]

            len_in = _math.hypot(dx_in, dy_in)
            len_out = _math.hypot(dx_out, dy_out)
            if len_in < 1e-9 or len_out < 1e-9:
                continue

            # Normalize
            dx_in /= len_in
            dy_in /= len_in
            dx_out /= len_out
            dy_out /= len_out

            # Cross product determines turn direction
            cross = dx_in * dy_out - dy_in * dx_out
            if abs(cross) < 0.5:
                continue  # Not a 90° turn (collinear or very shallow)

            is_left = cross > 0
            incoming_angle = _math.degrees(_math.atan2(dy_in, dx_in)) % 360
            corners.append((i, is_left, incoming_angle, (dx_in, dy_in), (dx_out, dy_out)))

        if not corners:
            return  # No corners found

        # Build segments and bend placements
        segments = []  # (start_point, end_point)
        bend_refs = []  # CellRef instances
        current_start = points[0]

        for corner_idx, (pt_idx, is_left, inc_angle, in_vec, out_vec) in enumerate(corners):
            corner = points[pt_idx]

            # Incoming segment ends at: corner - incoming_trim * in_vec
            seg_end = (
                corner[0] - incoming_trim * in_vec[0],
                corner[1] - incoming_trim * in_vec[1],
            )

            # Only add segment if it has positive length
            seg_len = _math.hypot(seg_end[0] - current_start[0],
                                  seg_end[1] - current_start[1])
            if seg_len < 1e-6:
                raise ValueError(
                    f"Segment before corner {corner_idx + 1} at {corner} is too "
                    f"short ({seg_len:.3f}) for bend PCell {bend_cell.name!r} "
                    f"(needs {incoming_trim:.3f} incoming clearance)."
                )
            segments.append((current_start, seg_end))

            # CellRef placement
            rotation = inc_angle
            x_reflection = not is_left

            ref = CellRef(
                cell_name=bend_cell.name,
                origin=seg_end,
                rotation=rotation,
                x_reflection=x_reflection,
            )
            bend_refs.append(ref)

            # Compute o1 world position via GDS transform: mirror → rotate → translate
            local_ox, local_oy = ox - ix, oy - iy  # relative to i1
            if x_reflection:
                local_oy = -local_oy
            theta = _math.radians(rotation)
            cos_t = _math.cos(theta)
            sin_t = _math.sin(theta)
            o1_world = (
                seg_end[0] + local_ox * cos_t - local_oy * sin_t,
                seg_end[1] + local_ox * sin_t + local_oy * cos_t,
            )
            current_start = o1_world

        # Final segment from last bend to route end
        final_end = points[-1]
        seg_len = _math.hypot(final_end[0] - current_start[0],
                              final_end[1] - current_start[1])
        if seg_len < 1e-6 and len(corners) > 0:
            raise ValueError(
                f"Final segment after last corner is too short ({seg_len:.3f}) "
                f"for bend PCell {bend_cell.name!r} "
                f"(needs {outgoing_trim:.3f} outgoing clearance)."
            )
        segments.append((current_start, final_end))

        # Remove original FlexRoute from cell elements
        try:
            self._cell._cell.elements.remove(self._route)
        except ValueError:
            pass  # Already removed

        # Add straight segments
        route_width = self._route.width
        route_layer = self._route.layer
        for start, end in segments:
            seg = FlexRoute(
                points=[start, end],
                width=route_width,
                layer=route_layer,
                bend_radius=0,
            )
            self._cell._cell.add_element(seg)

        # Add bend CellRefs
        for ref in bend_refs:
            self._cell._cell.add_element(ref)

    def _decompose_sbends(self) -> None:
        """Replace single FlexRoute with per-segment FlexRoutes.

        Called from to_layout() after _materialize_tapers(). Only runs when
        _segments is set (manual mode with mixed manhattan/S-bend segments).

        Manhattan segments get the route's bend_radius (smooth corners).
        S-bend segments get bend_radius=0 (curvature is in the dense points).
        """
        if self._segments is None:
            return

        # Check if any S-bends exist
        has_sbend = any(s.is_sbend for s in self._segments)
        if not has_sbend:
            return  # All manhattan — the existing FlexRoute handles it fine

        # Finalize: append port_b to the last segment if not already there
        last_seg = self._segments[-1]
        pb = self._port_b.position
        if _math.hypot(last_seg.points[-1][0] - pb[0],
                       last_seg.points[-1][1] - pb[1]) > 1e-6:
            if last_seg.is_sbend:
                # Create a new manhattan segment for the connection to port_b
                self._segments.append(_Segment(points=[last_seg.points[-1], pb]))
            else:
                last_seg.points.append(pb)

        # Remove original FlexRoute
        try:
            self._cell._cell.elements.remove(self._route)
        except ValueError:
            pass

        route_width = self._route.width
        route_layer = self._route.layer
        bend_radius = self._route.bend_radius
        bend_type = self._route.bend_type
        bend_p = self._route.bend_p

        for seg in self._segments:
            if len(seg.points) < 2:
                continue

            fr = FlexRoute(
                points=seg.points,
                width=route_width,
                layer=route_layer,
                bend_radius=0.0 if seg.is_sbend else bend_radius,
                bend_type=bend_type,
                bend_p=bend_p,
            )
            self._cell._cell.add_element(fr)

    def style(self, layer: LayerSpec | RouteProfile | str) -> RouteChain:
        """Set the routing style.

        Args:
            layer: A LayerSpec, a RouteProfile (sets layer + width + radius),
                   or a style name looked up from the cell's styles dict.
        """
        self._raise_if_invalid()
        if isinstance(layer, RouteProfile):
            self._route.layer = layer.layer
            self._route.width = layer.width
            if layer.radius > 0:
                self._route.bend_radius = layer.radius
        elif isinstance(layer, LayerSpec):
            self._route.layer = layer
        elif isinstance(layer, str):
            resolved = self._cell.styles.get(layer)
            if resolved is not None:
                if isinstance(resolved, RouteProfile):
                    self._route.layer = resolved.layer
                    self._route.width = resolved.width
                    if resolved.radius > 0:
                        self._route.bend_radius = resolved.radius
                else:
                    self._route.layer = resolved
        return self

    def radius(self, r: float) -> RouteChain:
        """Set the bend radius."""
        self._raise_if_invalid()
        self._route.bend_radius = r
        _validate_bend_radius(
            self._route.points, r, self._port_a, self._port_b,
        )
        return self

    def bend(self, bend_type, p: float | None = None) -> RouteChain:
        """Set the bend type ("circular", "euler", or a CELL for custom bends).

        Args:
            bend_type: "circular", "euler", or a CELL with i1/o1 ports.
            p:         Euler fraction (0–1). Only used for "euler" bends.
        """
        self._raise_if_invalid()
        from lumicron_api.lang.cell import CELL as _CELL
        if isinstance(bend_type, _CELL):
            self._bend_cell = bend_type
            self._bend_type = "custom"
            self._validate_bend_cell(bend_type)
            self._cell._dependencies.add(bend_type)
            self._route.bend_radius = 0
            return self
        self._bend_type = bend_type
        self._route.bend_type = bend_type
        if p is not None:
            self._bend_p = p
            self._route.bend_p = p
        return self

    def width(self, w: float) -> RouteChain:
        """Override the route width."""
        self._raise_if_invalid()
        self._route.width = w
        return self

    @property
    def length(self) -> float:
        """Total centerline length of the route in microns."""
        return self._route.length

    # ── Taper API ───────────────────────────────────────────────

    def taper(
        self,
        length: float | None = None,
        cell: object | None = None,
        disabled: bool = False,
    ) -> RouteChain:
        """Configure tapers at both ends of the route.

        Args:
            length: Taper length in microns (default 2.0).
            cell:   Custom taper CELL with ports matching port/route widths.
                    If provided, this cell is placed instead of a linear taper.
            disabled: Set True to suppress tapers (same as length=0).
        """
        if disabled or length == 0:
            self._start_taper.disabled = True
            self._end_taper.disabled = True
            return self
        if length is not None:
            self._start_taper.length = length
            self._end_taper.length = length
        if cell is not None:
            self._start_taper.cell = cell
            self._end_taper.cell = cell
        return self

    def start_taper(
        self,
        length: float | None = None,
        cell: object | None = None,
        disabled: bool = False,
        at: float | None = None,
        width: float | None = None,
    ) -> RouteChain:
        """Configure the taper at the start (port A side) of the route.

        Args:
            length: Taper length in microns.
            cell:   Custom taper CELL.
            disabled: Suppress this taper.
            at:     Distance from port A along the route to place the taper.
                    If None, the taper is placed at the port (default behavior).
                    If the taper falls on a bend, a warning is issued and
                    the taper is skipped.
            width:  Target width after the taper. Defaults to port B's width.
        """
        if disabled or length == 0:
            self._start_taper.disabled = True
            return self
        if length is not None:
            self._start_taper.length = length
        if cell is not None:
            self._start_taper.cell = cell
        if at is not None:
            self._start_taper.at = at
        if width is not None:
            self._start_taper.width = width
        return self

    def end_taper(
        self,
        length: float | None = None,
        cell: object | None = None,
        disabled: bool = False,
        at: float | None = None,
        width: float | None = None,
    ) -> RouteChain:
        """Configure the taper at the end (port B side) of the route.

        Args:
            length: Taper length in microns.
            cell:   Custom taper CELL.
            disabled: Suppress this taper.
            at:     Distance from port B along the route to place the taper.
                    If None, the taper is placed at the port (default behavior).
                    If the taper falls on a bend, a warning is issued and
                    the taper is skipped.
            width:  Target width after the taper. Defaults to port A's width.
        """
        if disabled or length == 0:
            self._end_taper.disabled = True
            return self
        if length is not None:
            self._end_taper.length = length
        if cell is not None:
            self._end_taper.cell = cell
        if at is not None:
            self._end_taper.at = at
        if width is not None:
            self._end_taper.width = width
        return self

    # ── Taper materialisation ───────────────────────────────────

    def _needs_start_taper(self) -> bool:
        if self._start_taper.disabled:
            return False
        if self._start_taper.at is not None:
            return True  # Positional taper — always needed (width change is inline)
        return abs(self._port_a.width - self._route.width) > 1e-6

    def _needs_end_taper(self) -> bool:
        if self._end_taper.disabled:
            return False
        if self._end_taper.at is not None:
            return True
        return abs(self._port_b.width - self._route.width) > 1e-6

    @staticmethod
    def _point_at_distance(
        points: list[tuple[float, float]], dist: float,
    ) -> tuple[tuple[float, float], int, tuple[float, float]]:
        """Find (x,y) position at cumulative distance along route.

        Returns:
            (position, segment_index, unit_direction) where segment_index
            is the index of the segment the point falls on (0-based), and
            unit_direction is the travel direction of that segment.

        Raises ValueError if dist exceeds route length.
        """
        cumulative = 0.0
        for i in range(len(points) - 1):
            dx = points[i + 1][0] - points[i][0]
            dy = points[i + 1][1] - points[i][1]
            seg_len = _math.hypot(dx, dy)
            if seg_len < 1e-9:
                continue
            unit = (dx / seg_len, dy / seg_len)
            if cumulative + seg_len >= dist - 1e-6:
                # Point is on this segment
                t = dist - cumulative
                pos = (points[i][0] + unit[0] * t,
                       points[i][1] + unit[1] * t)
                return pos, i, unit
            cumulative += seg_len

        raise ValueError(
            f"Taper at={dist} exceeds route length ({cumulative:.2f})."
        )

    @staticmethod
    def _bend_zones(
        points: list[tuple[float, float]], bend_radius: float,
    ) -> list[tuple[float, float]]:
        """Compute cumulative-distance zones occupied by bends.

        Returns list of (zone_start, zone_end) in cumulative distance
        for each interior corner.
        """
        if bend_radius <= 0 or len(points) < 3:
            return []

        zones = []
        cumulative = 0.0
        for i in range(len(points) - 1):
            seg_len = _math.hypot(
                points[i + 1][0] - points[i][0],
                points[i + 1][1] - points[i][1],
            )
            if i > 0:
                # Corner at points[i] — bend occupies [cum - R, cum + R]
                zones.append((cumulative - bend_radius, cumulative + bend_radius))
            cumulative += seg_len
        return zones

    @staticmethod
    def _overlaps_bend(
        taper_start: float, taper_end: float,
        bend_zones: list[tuple[float, float]],
    ) -> bool:
        """Check if taper range overlaps any bend zone."""
        for zs, ze in bend_zones:
            if taper_start < ze - 1e-6 and taper_end > zs + 1e-6:
                return True
        return False

    def _split_route_at(
        self,
        dist: float,
        taper_length: float,
        near_port_width: float,
        far_port_width: float,
        from_start: bool,
        spec: _TaperSpec,
    ) -> None:
        """Split route at distance and insert taper geometry.

        Creates two FlexRoute segments (before and after taper) and a
        taper polygon/cell between them. Removes the original route.

        Args:
            dist: Cumulative distance from the reference port.
            taper_length: Length of the taper.
            near_port_width: Width on the near side (the port we measure from).
            far_port_width: Width on the far side (the other port / target).
            from_start: True if measured from port A, False if from port B.
            spec: The _TaperSpec for this taper.
        """
        import warnings as _warnings

        points = list(self._route.points)
        layer = self._route.layer
        bend_radius = self._route.bend_radius
        bend_type = self._route.bend_type
        bend_p = self._route.bend_p

        # If measuring from port B, reverse points and distances
        if not from_start:
            points = list(reversed(points))

        total_length = sum(
            _math.hypot(points[i + 1][0] - points[i][0],
                        points[i + 1][1] - points[i][1])
            for i in range(len(points) - 1)
        )

        # Check bounds
        if dist + taper_length > total_length + 1e-6:
            _warnings.warn(
                f"Taper at={dist} with length={taper_length} exceeds route "
                f"length ({total_length:.2f}). Taper skipped.",
                stacklevel=4,
            )
            return

        # Check bend collision
        bend_zones = self._bend_zones(points, bend_radius)
        if self._overlaps_bend(dist, dist + taper_length, bend_zones):
            _warnings.warn(
                f"Taper at={dist} (length={taper_length}) overlaps a bend "
                f"zone. Taper skipped. Adjust the 'at' distance to avoid "
                f"bends.",
                stacklevel=4,
            )
            return

        # Find positions
        taper_pos, seg_idx_start, direction = self._point_at_distance(points, dist)
        taper_end_pos, seg_idx_end, _ = self._point_at_distance(points, dist + taper_length)

        # Build pre-taper points: route start → taper_pos
        pre_points = list(points[:seg_idx_start + 1])
        # Only add taper_pos if it's not essentially the same as the last point
        if _math.hypot(pre_points[-1][0] - taper_pos[0],
                       pre_points[-1][1] - taper_pos[1]) > 1e-6:
            pre_points.append(taper_pos)

        # Build post-taper points: taper_end_pos → route end
        post_points = [taper_end_pos]
        for pt in points[seg_idx_end + 1:]:
            if _math.hypot(post_points[-1][0] - pt[0],
                           post_points[-1][1] - pt[1]) > 1e-6:
                post_points.append(pt)
        # Ensure we include the final point
        if len(post_points) == 1 or _math.hypot(
                post_points[-1][0] - points[-1][0],
                post_points[-1][1] - points[-1][1]) > 1e-6:
            post_points.append(points[-1])

        # Width assignment:
        # Pre-taper segment is on the near-port side → near_port_width
        # Post-taper segment is on the far-port side → far_port_width
        # When reversed (from_start=False), the "pre" in reversed order
        # becomes the far side in real order, and vice versa.
        if not from_start:
            pre_points = list(reversed(pre_points))
            post_points = list(reversed(post_points))
            taper_pos, taper_end_pos = taper_end_pos, taper_pos
            direction = (-direction[0], -direction[1])
            # In real (non-reversed) order: pre_points is port_a side,
            # post_points is port_b side. We measured from port_b, so
            # near_port = port_b (post side), far_port = port_a (pre side).
            pre_width = far_port_width
            post_width = near_port_width
        else:
            # Measured from port_a: pre is port_a side, post is port_b side.
            pre_width = near_port_width
            post_width = far_port_width

        # Remove original route
        try:
            self._cell._cell.elements.remove(self._route)
        except ValueError:
            pass

        # Add pre-taper segment
        if len(pre_points) >= 2:
            pre_route = FlexRoute(
                points=pre_points,
                width=pre_width,
                layer=layer,
                bend_radius=bend_radius,
                bend_type=bend_type,
                bend_p=bend_p,
            )
            self._cell._cell.add_element(pre_route)

        # Add taper geometry
        if spec.cell is not None:
            angle = _math.degrees(_math.atan2(direction[1], direction[0]))
            ref = CellRef(
                cell_name=spec.cell._cell.name if hasattr(spec.cell, '_cell') else spec.cell.name,
                origin=taper_pos,
                rotation=angle,
            )
            self._cell._cell.add_element(ref)
            if hasattr(spec.cell, '_cell'):
                self._cell._dependencies.add(spec.cell)
        else:
            taper = _make_linear_taper(
                port_pos=taper_pos,
                direction=direction,
                port_width=pre_width,
                route_width=post_width,
                taper_length=taper_length,
                layer=layer,
            )
            self._cell._cell.add_element(taper)

        # Add post-taper segment
        if len(post_points) >= 2:
            post_route = FlexRoute(
                points=post_points,
                width=post_width,
                layer=layer,
                bend_radius=bend_radius,
                bend_type=bend_type,
                bend_p=bend_p,
            )
            self._cell._cell.add_element(post_route)

        # Update self._route to the post-taper segment for downstream use
        if len(post_points) >= 2:
            self._route = post_route
        elif len(pre_points) >= 2:
            self._route = pre_route

    def _materialize_tapers(self) -> None:
        """Create taper geometry and shorten the route accordingly.

        Called once from to_layout(). Idempotent.
        """
        if self._tapers_materialized:
            return
        self._tapers_materialized = True

        # ── Positional tapers (at= specified) ────────────────────
        # Handle these first, before port-end tapers modify the points.
        # For start_taper(at=X): pre-taper runs at port_a width,
        #   post-taper runs at target width (default: port_b width).
        # For end_taper(at=X): post-taper (toward port_b) runs at port_b width,
        #   pre-taper (toward port_a) runs at target width (default: port_a width).
        if self._start_taper.at is not None and not self._start_taper.disabled:
            target_width = self._start_taper.width or self._port_b.width
            self._split_route_at(
                dist=self._start_taper.at,
                taper_length=self._start_taper.length,
                near_port_width=self._port_a.width,
                far_port_width=target_width,
                from_start=True,
                spec=self._start_taper,
            )
            return  # Route has been split — skip port-end tapers

        if self._end_taper.at is not None and not self._end_taper.disabled:
            target_width = self._end_taper.width or self._port_a.width
            self._split_route_at(
                dist=self._end_taper.at,
                taper_length=self._end_taper.length,
                near_port_width=self._port_b.width,
                far_port_width=target_width,
                from_start=False,
                spec=self._end_taper,
            )
            return  # Route has been split — skip port-end tapers

        points = list(self._route.points)
        layer = self._route.layer

        # ── Start taper (port A side) ───────────────────────────
        if self._needs_start_taper():
            spec = self._start_taper
            da = _dir_vec(self._port_a.direction)
            tlen = spec.length

            if spec.cell is not None:
                self._place_taper_cell(
                    spec.cell, self._port_a, da, tlen, is_start=True,
                )
            else:
                taper = _make_linear_taper(
                    port_pos=points[0],
                    direction=da,
                    port_width=self._port_a.width,
                    route_width=self._route.width,
                    taper_length=tlen,
                    layer=layer,
                )
                self._cell._cell.add_element(taper)

            # Shorten route: move first point forward by taper_length
            p0 = points[0]
            points[0] = (p0[0] + da[0] * tlen, p0[1] + da[1] * tlen)

        # ── End taper (port B side) ─────────────────────────────
        if self._needs_end_taper():
            spec = self._end_taper
            db = _dir_vec(self._port_b.direction)
            tlen = spec.length

            if spec.cell is not None:
                self._place_taper_cell(
                    spec.cell, self._port_b, db, tlen, is_start=False,
                )
            else:
                # Taper goes from route width INTO port B.
                # Direction: from route toward port = opposite of port direction
                inward = (-db[0], -db[1])
                # Taper starts at (port - inward * tlen) = (port + db * tlen)
                # and ends at port position.
                taper_start = (
                    self._port_b.position[0] + db[0] * tlen,
                    self._port_b.position[1] + db[1] * tlen,
                )
                taper = _make_linear_taper(
                    port_pos=self._port_b.position,
                    direction=db,  # from port outward
                    port_width=self._port_b.width,
                    route_width=self._route.width,
                    taper_length=tlen,
                    layer=layer,
                )
                self._cell._cell.add_element(taper)

            # Shorten route: pull last point back by taper_length
            pn = points[-1]
            # Route approaches port B from outside (opposite of db)
            # Pull back = move last point in db direction (away from port)
            points[-1] = (pn[0] + db[0] * tlen, pn[1] + db[1] * tlen)

        self._route.points = points

    def _place_taper_cell(
        self,
        taper_cell: CELL,
        port: Port,
        direction: tuple[float, float],
        taper_length: float,
        is_start: bool,
    ) -> None:
        """Place a custom taper cell at a port position.

        The taper cell is expected to have two ports. It is placed so
        that its first port aligns with the route port.
        """
        from lumicron_api.models.elements import CellRef

        # Compute rotation: the taper cell's default orientation is
        # along +X.  Rotate so it aligns with the port direction.
        angle = _math.degrees(_math.atan2(direction[1], direction[0]))
        if not is_start:
            # For end taper, the taper should point inward (opposite of port dir)
            angle = (angle + 180) % 360

        ref = CellRef(
            cell_name=taper_cell._cell.name if hasattr(taper_cell, '_cell') else taper_cell.name,
            origin=port.position,
            rotation=angle,
        )
        self._cell._cell.add_element(ref)
        # Register the taper cell as a dependency
        if hasattr(taper_cell, '_cell'):
            self._cell._dependencies.add(taper_cell)

    # ── Manual routing ──────────────────────────────────────────

    @staticmethod
    def _resolve_to(to, direction_dx: float, direction_dy: float) -> float:
        """Extract the relevant axis coordinate from *to*.

        *to* can be a float (used directly), a Port (extract position),
        or a tuple (extract position).  The travel axis determines
        which coordinate (x or y) is returned.
        """
        if isinstance(to, (int, float)):
            return float(to)
        # Port or tuple — extract position
        if isinstance(to, Port):
            pos = to.position
        elif isinstance(to, tuple) and len(to) == 2:
            pos = to
        else:
            raise TypeError(f"Cannot resolve 'to' from {type(to).__name__}")
        # Horizontal travel → use x; vertical travel → use y
        if direction_dx != 0:
            return float(pos[0])
        return float(pos[1])

    def _current_travel_angle(self) -> float:
        """Get the current travel direction in radians.

        Returns the angle of the last segment direction, or port A's
        facing direction if no segments yet.
        """
        if self._segments and len(self._segments) > 0:
            seg = self._segments[-1]
            if len(seg.points) >= 2:
                p1 = seg.points[-2]
                p2 = seg.points[-1]
                return _math.atan2(p2[1] - p1[1], p2[0] - p1[0])
        # Fall back to port A direction
        return _math.radians(self._port_a.direction)

    def _current_position(self) -> tuple[float, float]:
        """Get the current endpoint of the route chain."""
        if self._segments:
            return self._segments[-1].points[-1]
        if self._manual_points:
            return self._manual_points[-1]
        return self._port_a.position

    def go(self, direction: str, *, by=None, to=None,
           dx: float = 0, dy: float = 0) -> RouteChain:
        """Add a manual routing segment.

        First call to .go() switches from auto-route to manual mode,
        starting from port_a's position.

        Args:
            direction: Cardinal ("E", "W", "N", "S") for manhattan segments,
                or diagonal ("NE", "NW", "SE", "SW") for S-bend curves.
            by: For cardinal: distance (float). For diagonal: (dx, dy) tuple
                of positive magnitudes — direction string determines signs.
            to: Absolute coordinate, port, or point to route toward.
                For cardinal: aligns on travel axis.
                For diagonal: computes S-bend to reach the target position.
            dx: Additional x offset applied after resolving the target.
            dy: Additional y offset applied after resolving the target.
        """
        is_diagonal = direction in _DIAGONAL_MAP

        if is_diagonal:
            return self._go_sbend(direction, by=by, to=to, dx=dx, dy=dy)

        ddx, ddy = _DIRECTION_MAP[direction]

        # Manual routing overrides the auto-route — clear any deferred error
        self._deferred_error = None

        if self._manual_points is None:
            # Switch to manual mode — start from port_a
            self._manual_points = [self._port_a.position]

        # Also initialize segments if first go() call
        if self._segments is None:
            self._segments = [_Segment(points=[self._port_a.position])]
        # If last segment was an S-bend, start a new manhattan segment
        elif self._segments[-1].is_sbend:
            last_pt = self._segments[-1].points[-1]
            self._segments.append(_Segment(points=[last_pt]))

        last = self._manual_points[-1]

        if by is not None:
            nx = last[0] + ddx * float(by)
            ny = last[1] + ddy * float(by)
        elif to is not None:
            coord = self._resolve_to(to, ddx, ddy)
            if ddx != 0:
                nx, ny = coord, last[1]
            else:
                nx, ny = last[0], coord
        else:
            raise ValueError("go() requires either 'by' or 'to'")

        nx += dx
        ny += dy

        self._manual_points.append((nx, ny))
        self._segments[-1].points.append((nx, ny))

        # Update the route with manual points + final connection to port_b
        all_points = self._manual_points + [self._port_b.position]
        self._route.points = all_points
        return self

    def _go_sbend(self, direction: str, *, by=None, to=None,
                  dx: float = 0, dy: float = 0) -> RouteChain:
        """Handle a diagonal .go() — generate an S-bend curve segment."""
        sign_x, sign_y = _DIAGONAL_MAP[direction]

        # Manual routing overrides the auto-route
        self._deferred_error = None

        if self._manual_points is None:
            self._manual_points = [self._port_a.position]
        if self._segments is None:
            self._segments = [_Segment(points=[self._port_a.position])]

        last = self._manual_points[-1]

        # Compute world-space target
        if by is not None:
            if isinstance(by, (tuple, list)):
                if len(by) != 2:
                    raise ValueError(
                        f"S-bend 'by' must be a (dx, dy) tuple, got {by!r}"
                    )
                target_dx = sign_x * abs(float(by[0]))
                target_dy = sign_y * abs(float(by[1]))
            else:
                # Single float — use as both dx and dy magnitudes
                target_dx = sign_x * abs(float(by))
                target_dy = sign_y * abs(float(by))
            target = (last[0] + target_dx, last[1] + target_dy)
        elif to is not None:
            if isinstance(to, Port):
                target = to.position
            elif isinstance(to, (tuple, list)) and len(to) == 2:
                target = (float(to[0]), float(to[1]))
            else:
                raise TypeError(
                    f"S-bend 'to' must be a Port or (x, y) tuple, "
                    f"got {type(to).__name__}"
                )
        else:
            raise ValueError("go() requires either 'by' or 'to'")

        target = (target[0] + dx, target[1] + dy)

        # Get current travel direction
        travel_angle = self._current_travel_angle()

        # Project target offset onto travel direction (forward/lateral)
        world_dx = target[0] - last[0]
        world_dy = target[1] - last[1]
        cos_a = _math.cos(travel_angle)
        sin_a = _math.sin(travel_angle)
        forward = world_dx * cos_a + world_dy * sin_a
        lateral = -world_dx * sin_a + world_dy * cos_a

        # Compute S-bend curve in local coordinates
        local_pts = _compute_sbend_points(
            forward=forward,
            lateral=lateral,
            radius=self._route.bend_radius,
            bend_type=self._bend_type if self._bend_type != "custom" else "circular",
            p=self._bend_p,
        )

        # Transform to world coordinates
        world_pts = _transform_sbend_to_world(local_pts, last, travel_angle)

        # Create S-bend segment
        sbend_seg = _Segment(points=world_pts, is_sbend=True)
        self._segments.append(sbend_seg)

        # Update manual points (add only the endpoint for tracking)
        self._manual_points.append(world_pts[-1])

        # Update the route points for intermediate state
        all_points = self._manual_points + [self._port_b.position]
        self._route.points = all_points
        return self
