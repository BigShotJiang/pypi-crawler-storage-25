import math
import lumicron_api.all as lm
import lumicron_api.pdks.elyon_demo.all as pdk


@lm.cell_params
def EulerBend90Custom(
    width: float = 0.5,
    bend_radius: float = 15,
    p: float = 0.5,
    layer: lm.LayerSpec = pdk.LAYER.SILC,
):
    """90-degree bend using lm.Waveguide with euler rounding."""
    # Generate a simple right-angle corner: horizontal then vertical
    points = [(0, 0), (bend_radius, 0), (bend_radius, bend_radius)]

    return lm.Waveguide(
        points=points,
        layer=layer,
        width=width,
        radius=bend_radius,
        bend="euler",
        p=p,
        name="EulerBend90",
    )


if __name__ == "__main__":
    bend = EulerBend90Custom(width=0.5, bend_radius=15, p=0.4)

    chip = lm.CELL("CustomBendDemo")
    b = chip.add(bend)
    chip.Place(b).at((0, 0))

    chip.show_ports()
    layout = chip.to_layout()
    layout.to_gds("custom_bend_demo.gds")
