import lumicron_api.all as lm
import lumicron_api.pdks.elyon_demo.all as pdk
from subcells.electrode import Electrode
from subcells.doping import Doping
from subcells.pad_array import PadArray

@lm.cell_params
def Modulator(
        device_length: float = 250,
        electrode_width: float = 50,
        segment_segment_gap: float = 6.0,
        stalk_segment_overlap: float = 2.0,
        segment_spacing: float = 10.0,
        segment_stalk_length: float = 16.0,
        segment_stalk_width: float = 8.0,
        segment_length: float = 30.0,
        segment_width: float = 8.0,
        wg_width: float = 0.45,
        pad_electrode_spacing: float = 100,
        route_bend_radius: float = 15,
        taper_length: float = 5, 
        splitter_y_spacing: float = 10.0,
        pad_mod_y_spacing: float = 75.0,
        label_text: str = "Modulator"):
    
    c = lm.CELL("Modulator")
    total_device_width = electrode_width*2 + segment_stalk_length*2 + segment_width*2 + segment_segment_gap - stalk_segment_overlap*2

    electrode = Electrode(width=electrode_width, device_length=device_length,
                               segment_length=segment_length, segment_width=segment_width,
                               segment_spacing=segment_spacing,
                               segment_stalk_length=segment_stalk_length,
                               segment_stalk_width=segment_stalk_width)
    
    dopant = Doping(ndop_width=total_device_width, device_length=device_length, wg_width=wg_width)
    pads = PadArray(pad_down_to="MTL1", pad_x=95, pad_y=95, pad_pitch=150, n_pads=3)

    signal_connector = lm.Parallelogram(y_dim=pad_electrode_spacing, top_width=95, bot_width=electrode_width*2, 
                                        bot_x_offset=0, top_x_offset=0, layer=pdk.LAYER.MTL1)
    
    ground_connector = lm.Parallelogram(y_dim=pad_electrode_spacing, top_width=95, bot_width=electrode_width, 
                                        top_x_offset=0, bot_x_offset=25, layer=pdk.LAYER.MTL1)
    
    splitter = pdk.YSplitter(layer=pdk.LAYER.SILC)

    left_ground = c.add(electrode)
    left_signal = c.add(electrode)
    right_ground = c.add(electrode)
    right_signal = c.add(electrode)

    top_pads = c.add(pads)
    bot_pads = c.add(pads)

    left_dopant = c.add(dopant)
    right_dopant = c.add(dopant)

    top_sig = c.add(signal_connector)
    bot_sig = c.add(signal_connector)

    top_left_ground = c.add(ground_connector)
    top_right_ground = c.add(ground_connector)
    bot_left_ground = c.add(ground_connector)
    bot_right_ground = c.add(ground_connector)

    top_splitter = c.add(splitter)
    bot_splitter = c.add(splitter)

    c.Place(left_dopant).using("E").at((0, 0))
    c.Place(right_dopant).right_of(left_dopant)
    c.Place(left_ground).using("W").at(left_dopant.W)
    c.Place(left_signal).using("E").at(left_dopant.E).rotate_by(180)
    c.Place(right_ground).using("E").at(right_dopant.E).rotate_by(180)
    c.Place(right_signal).using("W").at(right_dopant.W)
    c.Place(top_pads).using("S").at(left_dopant.NE).move_by(dy=pad_electrode_spacing)
    c.Place(bot_pads).using("N").at(left_dopant.SE).move_by(dy=-pad_electrode_spacing)
    c.Place(top_sig).below(top_pads)
    c.Place(bot_sig).above(bot_pads).rotate_by(180)
    c.Place(top_left_ground).using("NW").at(top_pads.SW)
    c.Place(top_right_ground).using("NE").at(top_pads.SE).flip_y()
    c.Place(bot_left_ground).using("SW").at(bot_pads.NW).flip_x()
    c.Place(bot_right_ground).using("SE").at(bot_pads.NE).rotate_by(180)

    c.Place(top_splitter).using("i1").at(top_pads.NW).move_by(dy=25)
    c.Place(bot_splitter).using("i1").at(bot_pads.SE).rotate_by(180).move_by(dy=-25)

    left_bot_route = c.Route(left_dopant.port["bot"], bot_splitter.port["o1"]).go("S", to=bot_splitter.port["o1"])\
        .radius(route_bend_radius).start_taper(length=taper_length, at=50)
    right_bot_route = c.Route(right_dopant.port["bot"], bot_splitter.port["o2"]).go("S", to=bot_splitter.port["o2"])\
        .radius(route_bend_radius).start_taper(length=taper_length, at=50)
    left_top_route = c.Route(left_dopant.port["top"], top_splitter.port['o2']).go("N", to=top_splitter.port["o2"])\
        .radius(route_bend_radius).start_taper(length=taper_length, at=50)
    right_top_route = c.Route(right_dopant.port["top"], top_splitter.port["o1"]).go("N", to=top_splitter.port["o1"])\
        .radius(route_bend_radius).start_taper(length=taper_length, at=50)
    

    return c

if __name__ == "__main__":
    modulator = Modulator()
    layout = modulator.to_layout()
    layout.to_gds("modulator.gds")
    
    