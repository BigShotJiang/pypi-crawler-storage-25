import lumicron_api.all as lm
import lumicron_api.pdks.elyon_demo.all as pdk
from .modulator_array import ModArray

@lm.cell_params
def ModDoe(device_lengths: list = [250, 1000],
           n_mods: int = 12,
           array_y_spacing: float = 50):
    
    c = lm.CELL("ModDoe")

    array1 = ModArray(device_length=device_lengths[0], n_mods=n_mods)
    array2 = ModArray(device_length=device_lengths[1], n_mods=n_mods)

    arr1 = c.add(array1)
    arr2 = c.add(array2)

    c.Place(arr1).using("S").at((0, 0)).move_by(dy=array_y_spacing)
    c.Place(arr2).using("N").at((0, 0)).move_by(dy=-array_y_spacing)

    c.promote_ports(arr1, prefix="a1_")
    c.promote_ports(arr2, prefix="a2_")

    return c

if __name__ == "__main__":
    doe = ModDoe()
    layout = doe.to_layout()
    layout.to_gds("moddoe.gds")

