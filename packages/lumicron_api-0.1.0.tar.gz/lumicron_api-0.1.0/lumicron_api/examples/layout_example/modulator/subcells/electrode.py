import lumicron_api.all as lm
import lumicron_api.pdks.elyon_demo.all as pdk
from .segment_array import SegmentArray

@lm.cell_params
def Electrode(width: float = 75,
              device_length: float = 250,
              segment_length: float = 30.0,
              segment_width: float = 8.0,
              segment_spacing: float = 10.0,
              segment_stalk_length: float = 16.0,
              segment_stalk_width: float = 8.0,
              stalk_segment_overlap: float = 2.0):
    
    c = lm.CELL("Electrode")
    electrode = lm.Rectangle(x_dim=width, y_dim=device_length, layer=pdk.LAYER.MTL1)
    segments = SegmentArray(device_length=device_length, segment_length=segment_length, segment_width=segment_width,
                            segment_spacing=segment_spacing, segment_stalk_length=segment_stalk_length,
                            segment_stalk_width=segment_stalk_width, stalk_segment_overlap=stalk_segment_overlap)

    c.add(electrode)
    c.add(segments)

    c.Place(electrode).at((0, 0))
    c.Place(segments).right_of(electrode).rotate_by(-90)

    return c

if __name__ == "__main__":
    electrode = Electrode()
    layout = electrode.to_layout()
    layout.to_gds("electrode.gds")
