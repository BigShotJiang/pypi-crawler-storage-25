import lumicron_api.all as lm
import lumicron_api.pdks.elyon_demo.all as pdk
from .segment import Segment

@lm.cell_params
def SegmentArray(        
        device_length: float = 250,
        segment_spacing: float = 10,
        segment_stalk_length: float = 16.0,
        segment_stalk_width: float = 8.0,
        segment_length: float = 30.0,
        segment_width: float = 8.0,
        stalk_segment_overlap: float = 2.0):
    
    c = lm.CELL("SegmentArray")

    total_segment_x = segment_length + segment_spacing
    n_segments = int(device_length / total_segment_x)

    arr = c.add(lm.ARRAY(Segment, count=n_segments, pitch=(total_segment_x, 0),
                        params=dict(x_segment=segment_length, y_segment=segment_width,
                                    x_stalk=segment_stalk_width, y_stalk=segment_stalk_length, 
                                    stalk_segment_overlap=stalk_segment_overlap)))
    
    c.Place(arr).at((0, 0))

    return c

if __name__ == "__main__":
    segment_array = SegmentArray()
    layout = segment_array.to_layout()
    layout.to_gds("segment_array.gds")