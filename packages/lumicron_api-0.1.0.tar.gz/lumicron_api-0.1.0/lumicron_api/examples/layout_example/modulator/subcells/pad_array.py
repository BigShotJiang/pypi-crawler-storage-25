import lumicron_api.all as lm
import lumicron_api.pdks.elyon_demo.all as pdk

@lm.cell_params
def PadArray(
        n_pads: int = 3,
        pad_x: float = 95,
        pad_y: float = 95,
        pad_pitch: float = 150,
        pad_down_to: str = "MTL2"
):
    c = lm.CELL("PadArray")

    pad = pdk.Pad(pad_x=pad_x, pad_y=pad_y, pad_down_to=pad_down_to)
    array = lm.ARRAY(pad, count = n_pads, pitch=(pad_pitch, 0))

    c.add(array)
    c.Place(array).at((0, 0))

    return c

if __name__ == "__main__":
    array = PadArray()
    layout = array.to_layout()
    layout.to_gds("pad_array.gds")