import lumicron_api.all as lm
import lumicron_api.pdks.elyon_demo.all as pdk

@lm.cell_params
def Segment(x_segment: float = 30.0,
            y_segment: float = 8.0,
            x_stalk: float = 8.0,
            y_stalk: float = 16.0,
            stalk_segment_overlap: float = 2.0):
    
    c = lm.CELL("Segment")
    
    segment = c.add(lm.Rectangle(x_dim=x_segment, y_dim=y_segment, layer=pdk.LAYER.MTL1))
    stalk = c.add(lm.Rectangle(x_dim=x_stalk, y_dim=y_stalk, layer=pdk.LAYER.MTL1))

    c.Place(segment).at((0, 0))
    c.Place(stalk).below(segment).move_by(dy=stalk_segment_overlap)

    return c

if __name__ == "__main__":
    segment = Segment()
    layout = segment.to_layout()
    layout.to_gds("segment.gds")