import lumicron_api.all as lm
import lumicron_api.pdks.elyon_demo.all as pdk

@lm.cell_params
def Doping(
           device_length: float = 250,
           ndop_width: float = 150,
           ndpp_width: float = 75,
           nppp_width: float = 25,
           wg_width: float = 0.5,
           ):
    
    c = lm.CELL("Doping")

    si_wg = lm.Rectangle(x_dim=wg_width, y_dim=device_length, layer=pdk.LAYER.SILC)
    ndop = lm.Rectangle(x_dim=ndop_width, y_dim=device_length, layer=pdk.LAYER.NDOP)
    ndpp = lm.Rectangle(x_dim=ndpp_width, y_dim=device_length, layer=pdk.LAYER.NDPP)
    nppp = lm.Rectangle(x_dim=nppp_width, y_dim=device_length, layer=pdk.LAYER.NPPP)

    top_port = lm.PORT(name="top", position=(0, device_length/2), direction=90, width=wg_width, route_profile=pdk.RPROF.silc_strip)
    bot_port = lm.PORT(name="bot", position=(0, -device_length/2), direction=270, width=wg_width, route_profile=pdk.RPROF.silc_strip)

    c.add(si_wg)
    c.add(ndop)
    c.add(ndpp)
    c.add(nppp)
    c.add(top_port)
    c.add(bot_port)

    c.Place(si_wg).at((0, 0))
    c.Place(ndop).at((0, 0))
    c.Place(ndpp).at((0, 0))
    c.Place(nppp).at((0, 0))

    return c

if __name__ == "__main__":
    doping = Doping()
    layout = doping.to_layout()
    layout.to_gds("doping.gds")