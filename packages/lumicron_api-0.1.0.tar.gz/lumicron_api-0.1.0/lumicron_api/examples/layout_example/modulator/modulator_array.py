import lumicron_api.all as lm
import lumicron_api.pdks.elyon_demo.all as pdk
from .modulator import Modulator

@lm.cell_params
def ModArray(
        n_mods: int = 12,
        mod_mod_spacing: float = 55.0,
        device_length: float = 250.0
):
    
    c = lm.CELL("ModArray")

    mod = Modulator(device_length=device_length)

    array = lm.ARRAY(mod, count=n_mods, pitch=(mod_mod_spacing + 2*150 + 95, 0))
    
    arr = c.add(array)

    c.Place(arr).at((0, 0))

    for i in range(n_mods):
        c.promote_ports(arr[i], prefix=f"mod{i}_")

    return c

if __name__ == "__main__":
    array = ModArray()
    layout = array.to_layout()
    layout.to_gds("modarray.gds")

