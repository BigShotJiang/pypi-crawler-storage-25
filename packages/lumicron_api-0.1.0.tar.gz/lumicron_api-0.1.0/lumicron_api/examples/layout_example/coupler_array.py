import lumicron_api.all as lm
import lumicron_api.pdks.elyon_demo.all as pdk

@lm.cell_params
def CouplerArray(
    n_couplers: int = 6,
    coupler_pitch: float = 127.0
):
    c = lm.CELL("CouplerArray")

    coupler = pdk.EdgeCouplerSi()
    array = lm.ARRAY(coupler, count=n_couplers, pitch=(coupler_pitch, 0), rotation=90)

    arr = c.add(array)
    c.Place(arr).at((0, 0))

    for i in range(n_couplers):
        c.promote_ports(arr[i], prefix=f"c{i}_")

    return c