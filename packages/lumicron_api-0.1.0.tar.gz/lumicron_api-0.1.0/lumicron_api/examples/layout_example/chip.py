import lumicron_api.all as lm
import lumicron_api.pdks.elyon_demo.all as pdk
from modulator.mod_doe import ModDoe
from coupler_array import CouplerArray
from custom_bend import EulerBend90

@lm.cell_params
def Chip(
    n_mods: int = 12,
    device_lengths: list = [250, 1000],
    n_loopbacks: int = 3,
    bend_radius: float = 15
):
    c = lm.CELL("Chip")

    total_n_couplers = (n_mods*2 + (2*n_loopbacks))

    bend = EulerBend90(bend_radius=bend_radius, p=0.8)
    couplers = CouplerArray(n_couplers=total_n_couplers)
    frame = pdk.ChipFrame()

    doe = c.add(ModDoe(n_mods=n_mods, device_lengths=device_lengths))
    top_couplers = c.add(couplers)
    bot_couplers = c.add(couplers)
    c.add(frame)

    c.Place(frame).at((0, 0))
    c.Place(doe).at((15, 0))
    c.Place(top_couplers).using("N").at(frame.N)
    c.Place(bot_couplers).using("S").at(frame.S).rotate_by(180)

    #-----------------------------Top Couplers Loopbacks-----------------------------
    c.Route(top_couplers.port["c0_o1"], top_couplers.port["c1_o1"]).radius(bend_radius)
    c.Route(top_couplers.port[f"c{total_n_couplers-1}_o1"], top_couplers.port[f"c{total_n_couplers-2}_o1"]).radius(bend_radius)
    c.Route(top_couplers.port[f"c{int(total_n_couplers/2-1)}_o1"], top_couplers.port[f"c{int(total_n_couplers/2)}_o1"]).radius(bend_radius)

    #-----------------------------Bot Couplers Loopbacks-----------------------------
    c.Route(bot_couplers.port["c0_o1"], bot_couplers.port["c1_o1"]).radius(bend_radius)
    c.Route(bot_couplers.port[f"c{total_n_couplers-1}_o1"], bot_couplers.port[f"c{total_n_couplers-2}_o1"]).radius(bend_radius)
    c.Route(bot_couplers.port[f"c{int(total_n_couplers/2-1)}_o1"], bot_couplers.port[f"c{int(total_n_couplers/2)}_o1"]).radius(bend_radius)

    #-----------------------------First 6 Mods Top Row Routing-----------------------------
    c.Route(doe.port["a1_mod0_top_i1"], top_couplers.port["c2_o1"]).go("W", by=15).go("N", to=top_couplers.S, dy=-300).go("E", to=top_couplers.port["c2_o1"]).radius(bend_radius)
    c.Route(doe.port["a1_mod0_bot_i1"], top_couplers.port["c3_o1"]).go("E", by=15).go("N", to=top_couplers.S, dy=-310).go("E", to=top_couplers.port["c3_o1"]).radius(bend_radius)
    c.Route(doe.port["a1_mod1_top_i1"], top_couplers.port["c4_o1"]).go("W", by=15).go("N", to=top_couplers.S, dy=-320).go("E", to=top_couplers.port["c4_o1"]).radius(bend_radius)
    c.Route(doe.port["a1_mod1_bot_i1"], top_couplers.port["c5_o1"]).go("E", by=15).go("N", to=top_couplers.S, dy=-330).go("E", to=top_couplers.port["c5_o1"]).radius(bend_radius)
    c.Route(doe.port["a1_mod2_top_i1"], top_couplers.port["c6_o1"]).go("W", by=15).go("N", to=top_couplers.S, dy=-340).go("E", to=top_couplers.port["c6_o1"]).radius(bend_radius)
    c.Route(doe.port["a1_mod2_bot_i1"], top_couplers.port["c7_o1"]).go("E", by=15).go("N", to=top_couplers.S, dy=-350).go("E", to=top_couplers.port["c7_o1"]).radius(bend_radius)
    c.Route(doe.port["a1_mod3_top_i1"], top_couplers.port["c8_o1"]).go("W", by=15).go("N", to=top_couplers.S, dy=-360).go("E", to=top_couplers.port["c8_o1"]).radius(bend_radius)
    c.Route(doe.port["a1_mod3_bot_i1"], top_couplers.port["c9_o1"]).go("E", by=15).go("N", to=top_couplers.S, dy=-370).go("E", to=top_couplers.port["c9_o1"]).radius(bend_radius)
    c.Route(doe.port["a1_mod4_top_i1"], top_couplers.port["c10_o1"]).go("W", by=15).go("N", to=top_couplers.S, dy=-380).go("E", to=top_couplers.port["c10_o1"]).radius(bend_radius)
    c.Route(doe.port["a1_mod4_bot_i1"], top_couplers.port["c11_o1"]).go("E", to=top_couplers.port["c11_o1"]).radius(bend_radius)
    c.Route(doe.port["a1_mod5_top_i1"], top_couplers.port["c12_o1"]).go("W", by=15).go("N", to=top_couplers.S, dy=-400).go("E", to=top_couplers.port["c12_o1"]).radius(bend_radius)
    c.Route(doe.port["a1_mod5_bot_i1"], top_couplers.port["c13_o1"]).go("E", by=15).go("N", to=top_couplers.S, dy=-400).go("E", to=top_couplers.port["c13_o1"]).radius(bend_radius)

    #-----------------------------Last 6 Mods Top Row Routing-----------------------------
    c.Route(doe.port["a1_mod6_top_i1"], top_couplers.port["c16_o1"]).go("W", by=15).go("N", to=top_couplers.S, dy=-400).go("E", to=top_couplers.port["c16_o1"]).radius(bend_radius)
    c.Route(doe.port["a1_mod6_bot_i1"], top_couplers.port["c17_o1"]).go("E", by=15).go("N", to=top_couplers.S, dy=-400).go("W", to=top_couplers.port["c17_o1"]).radius(bend_radius)
    c.Route(doe.port["a1_mod7_top_i1"], top_couplers.port["c18_o1"]).go("W", by=15).go("N", to=top_couplers.S, dy=-390).go("W", to=top_couplers.port["c18_o1"]).radius(bend_radius)
    c.Route(doe.port["a1_mod7_bot_i1"], top_couplers.port["c19_o1"]).go("E", by=15).go("N", to=top_couplers.S, dy=-380).go("W", to=top_couplers.port["c19_o1"]).radius(bend_radius)
    c.Route(doe.port["a1_mod8_top_i1"], top_couplers.port["c20_o1"]).go("W", by=15).go("N", to=top_couplers.S, dy=-370).go("W", to=top_couplers.port["c20_o1"]).radius(bend_radius)
    c.Route(doe.port["a1_mod8_bot_i1"], top_couplers.port["c21_o1"]).go("E", by=15).go("N", to=top_couplers.S, dy=-360).go("W", to=top_couplers.port["c21_o1"]).radius(bend_radius)
    c.Route(doe.port["a1_mod9_top_i1"], top_couplers.port["c22_o1"]).go("W", by=15).go("N", to=top_couplers.S, dy=-350).go("W", to=top_couplers.port["c22_o1"]).radius(bend_radius)
    c.Route(doe.port["a1_mod9_bot_i1"], top_couplers.port["c23_o1"]).go("E", by=15).go("N", to=top_couplers.S, dy=-340).go("W", to=top_couplers.port["c23_o1"]).radius(bend_radius)
    c.Route(doe.port["a1_mod10_top_i1"], top_couplers.port["c24_o1"]).go("W", by=15).go("N", to=top_couplers.S, dy=-330).go("W", to=top_couplers.port["c24_o1"]).radius(bend_radius)
    c.Route(doe.port["a1_mod10_bot_i1"], top_couplers.port["c25_o1"]).go("E", by=15).go("N", to=top_couplers.S, dy=-320).go("W", to=top_couplers.port["c25_o1"]).radius(bend_radius)
    c.Route(doe.port["a1_mod11_top_i1"], top_couplers.port["c26_o1"]).go("W", by=15).go("N", to=top_couplers.S, dy=-310).go("W", to=top_couplers.port["c26_o1"]).radius(bend_radius)
    c.Route(doe.port["a1_mod11_bot_i1"], top_couplers.port["c27_o1"]).go("E", by=15).go("N", to=top_couplers.S, dy=-300).go("W", to=top_couplers.port["c27_o1"]).radius(bend_radius)

    #-----------------------------First 6 Mods Bot Row Routing-----------------------------
    c.Route(doe.port["a2_mod0_top_i1"], bot_couplers.port["c27_o1"], bend=bend)



    return c

if __name__ == "__main__":
    chip = Chip()
    layout = chip.to_layout()
    layout.to_gds("chip.gds")