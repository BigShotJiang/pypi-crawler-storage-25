from __future__ import annotations

import math

import gdstk

from lumicron_api.models.cell import Cell
from lumicron_api.models.elements import CellRef, FlexRoute, Polygon, Rect
from lumicron_api.models.port import Port

# Port markers are drawn on this layer
PORT_LAYER = 1000
PORT_DATATYPE = 0
PORT_MARKER_HEIGHT_RATIO = 0.5  # height = width * this ratio


def _add_port_markers(gc: gdstk.Cell, port: Port) -> None:
    """Add a rectangle marker and text label for a port."""
    px, py = port.position
    w = port.width
    h = w * PORT_MARKER_HEIGHT_RATIO
    rad = math.radians(port.direction)
    cos_a, sin_a = math.cos(rad), math.sin(rad)

    # Rectangle centered on port position
    # width (w) is perpendicular to port direction, height (h) is along it
    hw, hh = w / 2, h / 2
    corners = [(-hh, -hw), (hh, -hw), (hh, hw), (-hh, hw)]
    rotated = [
        (px + x * cos_a - y * sin_a, py + x * sin_a + y * cos_a)
        for x, y in corners
    ]
    gc.add(gdstk.Polygon(rotated, layer=PORT_LAYER, datatype=PORT_DATATYPE))

    # Text label
    rp_name = port.route_profile.name if port.route_profile else ""
    parts = [port.name, f"{port.direction}°"]
    if rp_name:
        parts.append(rp_name)
    label_text = " | ".join(parts)

    gc.add(gdstk.Label(
        label_text,
        (px, py),
        layer=PORT_LAYER,
        texttype=PORT_DATATYPE,
    ))


def compile_layout(
    cells: dict[str, Cell],
    top_cell: str,
    unit: float,
    precision: float,
) -> gdstk.Library:
    """Walk the data model and produce a gdstk.Library.

    Two-pass compilation:
      1. Create all gdstk.Cell objects (handles forward references).
      2. Populate each cell with geometry and references.
    """
    lib = gdstk.Library(name=top_cell, unit=unit, precision=precision)

    # Pass 1: create empty gdstk cells
    cell_map: dict[str, gdstk.Cell] = {}
    for name in cells:
        gc = gdstk.Cell(name)
        lib.add(gc)
        cell_map[name] = gc

    # Pass 2: populate geometry and port markers
    for name, cell in cells.items():
        gc = cell_map[name]
        for element in cell.elements:
            if isinstance(element, (Rect, Polygon)):
                gc.add(element.to_gdstk())
            elif isinstance(element, FlexRoute):
                gc.add(element.to_gdstk())
            elif isinstance(element, CellRef):
                gc.add(element.to_gdstk(cell_map))

        # Port markers — use per-instance markers if populated by the
        # language layer (correct transformed directions), otherwise fall
        # back to the cell's own port definitions (for raw data-model usage).
        if cell.port_markers:
            for port in cell.port_markers:
                _add_port_markers(gc, port)
        elif not cell.markers_handled_by_parent:
            for port in cell.ports.values():
                if port.name not in cell.connected_ports:
                    _add_port_markers(gc, port)

    return lib
