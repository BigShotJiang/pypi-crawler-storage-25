from __future__ import annotations

from pydantic import BaseModel, Field, model_validator

from lumicron_api.models.elements import Element
from lumicron_api.models.port import Port


class Cell(BaseModel):
    """A named cell containing geometric elements and ports.

    This is the pure data model. The language-layer CELL builder
    wraps this and provides Place(), Route(), add(), etc.
    """

    name: str = Field(min_length=1)
    elements: list[Element] = Field(default_factory=list)
    ports: dict[str, Port] = Field(default_factory=dict)
    connected_ports: set[str] = Field(default_factory=set, exclude=True)
    port_markers: list[Port] = Field(default_factory=list, exclude=True)
    markers_handled_by_parent: bool = Field(default=False, exclude=True)

    @model_validator(mode="after")
    def _port_names_match_keys(self) -> Cell:
        for key, port in self.ports.items():
            if key != port.name:
                raise ValueError(
                    f"Port dict key '{key}' does not match port.name '{port.name}'"
                )
        return self

    def add_element(self, element: Element) -> None:
        self.elements.append(element)

    def add_port(self, port: Port) -> None:
        if port.name in self.ports:
            raise ValueError(f"Port '{port.name}' already exists in cell '{self.name}'")
        self.ports[port.name] = port

    def __repr__(self) -> str:
        return (
            f"Cell('{self.name}', "
            f"{len(self.elements)} elements, "
            f"{len(self.ports)} ports)"
        )
