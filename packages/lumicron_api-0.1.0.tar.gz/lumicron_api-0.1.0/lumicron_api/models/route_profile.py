from __future__ import annotations

from pydantic import BaseModel, Field

from lumicron_api.models.layer import LayerSpec


class CladdingLayer(BaseModel):
    """A cladding layer definition for a route profile."""

    layer: LayerSpec
    offset: float = Field(gt=0)


class RouteProfile(BaseModel):
    """Route profile — defines the routing style.

    Carries the main layer, default width, bend radius, and
    optional cladding layers. Used by Route().style() to set
    all routing parameters at once.
    """

    name: str
    layer: LayerSpec
    width: float = Field(gt=0)
    radius: float = Field(default=0.0, ge=0)
    radius_min: float = Field(default=0.0, ge=0)
    cladding: list[CladdingLayer] = Field(default_factory=list)

    def __repr__(self) -> str:
        return (
            f"RouteProfile('{self.name}', "
            f"layer={self.layer.layer}/{self.layer.datatype}, "
            f"w={self.width}, r={self.radius})"
        )
