from __future__ import annotations

import math
from typing import Annotated, Literal, Union

import gdstk
import numpy as np
from pydantic import BaseModel, Field

from lumicron_api.models.layer import LayerSpec


# ── Rect ─────────────────────────────────────────────────────


class Rect(BaseModel):
    """Axis-aligned rectangle defined by two opposite corners."""

    type: Literal["rect"] = "rect"
    corner1: tuple[float, float]
    corner2: tuple[float, float]
    layer: LayerSpec

    def to_gdstk(self) -> gdstk.Polygon:
        ly, dt = self.layer.to_gdstk()
        return gdstk.rectangle(self.corner1, self.corner2, layer=ly, datatype=dt)


# ── Polygon ──────────────────────────────────────────────────


class Polygon(BaseModel):
    """Arbitrary closed polygon defined by a list of vertices."""

    type: Literal["polygon"] = "polygon"
    vertices: list[tuple[float, float]] = Field(min_length=3)
    layer: LayerSpec

    def to_gdstk(self) -> gdstk.Polygon:
        ly, dt = self.layer.to_gdstk()
        return gdstk.Polygon(self.vertices, layer=ly, datatype=dt)


# ── FlexRoute ────────────────────────────────────────────────


class FlexRoute(BaseModel):
    """A routed path between points, compiled to a gdstk FlexPath.

    Produced by the Route() language primitive.
    """

    type: Literal["flexroute"] = "flexroute"
    points: list[tuple[float, float]] = Field(min_length=2)
    width: float = Field(gt=0)
    width_end: float | None = None
    layer: LayerSpec
    bend_radius: float = Field(default=0.0, ge=0)
    bend_type: str = "circular"
    bend_p: float = Field(default=0.5, ge=0, le=1)

    model_config = {"arbitrary_types_allowed": True}

    @property
    def length(self) -> float:
        """Total centerline length of the route in microns."""
        import math
        total = 0.0
        for i in range(len(self.points) - 1):
            dx = self.points[i + 1][0] - self.points[i][0]
            dy = self.points[i + 1][1] - self.points[i][1]
            total += math.hypot(dx, dy)
        return total

    def _compute_widths(self) -> float | list[float]:
        """Return width spec for gdstk: scalar or per-point list."""
        if self.width_end is None or abs(self.width_end - self.width) < 1e-6:
            return self.width
        n = len(self.points)
        if n < 2:
            return self.width
        return [
            self.width + (self.width_end - self.width) * i / (n - 1)
            for i in range(n)
        ]

    def to_gdstk(self) -> gdstk.FlexPath | gdstk.RobustPath:
        """Convert to gdstk geometry.

        Returns a FlexPath for circular bends, or a RobustPath for euler
        bends (FlexPath's bend_function produces polygon outlines that
        self-intersect and corrupt on GDS write; RobustPath's parametric
        segments produce clean output).
        """
        ly, dt = self.layer.to_gdstk()
        if self.bend_radius > 0 and self.bend_type == "euler":
            return _euler_robust_path(
                self.points, self._compute_widths(),
                self.bend_radius, self.bend_p, ly, dt,
            )
        kwargs: dict = dict(
            width=self._compute_widths(),
            layer=ly,
            datatype=dt,
        )
        if self.bend_radius > 0:
            kwargs["bend_radius"] = self.bend_radius
        return gdstk.FlexPath(self.points, **kwargs)


def _euler_robust_path(
    points: list[tuple[float, float]],
    width: float | list[float],
    radius: float,
    p: float,
    layer: int,
    datatype: int,
    num_bend_points: int = 256,
) -> gdstk.RobustPath:
    """Build a RobustPath with euler bends at each corner.

    gdstk's FlexPath bend_function produces self-intersecting polygon
    outlines that corrupt on GDS write. RobustPath's parametric()
    method produces clean GDS output.
    """
    from scipy.interpolate import interp1d

    pts = [np.array(w, dtype=float) for w in points]
    n = len(pts)
    p = max(0.0, min(p, 0.5))

    # Compute segments and their directions
    segments = []
    for i in range(n - 1):
        vec = pts[i + 1] - pts[i]
        length = np.linalg.norm(vec)
        direction = vec / length if length > 1e-12 else np.array([1.0, 0.0])
        segments.append((vec, length, direction))

    # Compute turn angles and trims at each interior vertex
    turns = []  # (turn_angle, trim) for each interior vertex
    for i in range(1, n - 1):
        d_in = segments[i - 1][2]
        d_out = segments[i][2]
        cross = d_in[0] * d_out[1] - d_in[1] * d_out[0]
        dot = d_in[0] * d_out[0] + d_in[1] * d_out[1]
        turn_angle = math.atan2(cross, dot)
        half_angle = abs(turn_angle) / 2
        trim = radius * math.tan(half_angle) if abs(half_angle) > 1e-10 else 0.0
        turns.append((turn_angle, trim))

    # Handle scalar vs per-point width
    if isinstance(width, list):
        w_start = width[0]
    else:
        w_start = width

    rp = gdstk.RobustPath(
        tuple(pts[0]), w_start, layer=layer, datatype=datatype,
    )

    for i in range(n - 1):
        _, seg_len, seg_dir = segments[i]

        # Trim from the start of this segment (corner i, if i > 0)
        trim_start = turns[i - 1][1] if i > 0 else 0.0
        # Trim from the end of this segment (corner i+1, if i+1 < n-1)
        trim_end = turns[i][1] if i < n - 2 else 0.0

        straight_len = seg_len - trim_start - trim_end

        # Width at segment start/end (for tapered paths)
        if isinstance(width, list):
            w_seg_start = width[i]
            w_seg_end = width[i + 1]
            # Interpolate width at trim points
            t_start = trim_start / seg_len if seg_len > 1e-12 else 0
            t_end = 1 - trim_end / seg_len if seg_len > 1e-12 else 1
            w_trim_start = w_seg_start + (w_seg_end - w_seg_start) * t_start
            w_trim_end = w_seg_start + (w_seg_end - w_seg_start) * t_end
        else:
            w_trim_start = width
            w_trim_end = width

        # Add straight segment (trimmed)
        if straight_len > 1e-6:
            end_pt = pts[i] + (trim_start + straight_len) * seg_dir
            rp.segment(tuple(end_pt), w_trim_end)

        # Add euler bend at the corner (end of this segment)
        if i < n - 2:
            turn_angle, trim = turns[i]
            if abs(turn_angle) > 1e-10:
                d_out = segments[i + 1][2]

                # Expected displacement: from bend start to bend end
                # Bend starts at: vertex - trim * d_in
                # Bend ends at:   vertex + trim * d_out
                # Displacement = trim * (d_in + d_out)
                exp_dx = float(trim * (seg_dir[0] + d_out[0]))
                exp_dy = float(trim * (seg_dir[1] + d_out[1]))

                # Generate euler curve in local frame (+x heading)
                abs_angle = abs(turn_angle)
                sign = 1.0 if turn_angle >= 0 else -1.0
                arc_len = radius * abs_angle
                euler_len = arc_len * p
                circ_len = arc_len * (1 - 2 * p)
                k_max = 1.0 / (radius * (1.0 - p)) if abs(1.0 - p) > 1e-12 else 1.0 / radius

                s = np.linspace(0, arc_len, num_bend_points)
                ds = s[1] - s[0]

                k = np.zeros(num_bend_points)
                for j, sj in enumerate(s):
                    if euler_len > 1e-12 and sj <= euler_len:
                        k[j] = k_max * (sj / euler_len)
                    elif sj <= euler_len + circ_len:
                        k[j] = k_max
                    elif euler_len > 1e-12:
                        k[j] = k_max * ((arc_len - sj) / euler_len)
                    else:
                        k[j] = k_max

                heading = np.cumsum(k * sign) * ds
                heading = np.insert(heading[:-1], 0, 0.0)

                lx = np.cumsum(np.cos(heading) * ds)
                ly = np.cumsum(np.sin(heading) * ds)
                lx = np.insert(lx, 0, 0.0)
                ly = np.insert(ly, 0, 0.0)

                # Rotate local curve to match incoming direction
                base_angle = math.atan2(seg_dir[1], seg_dir[0])
                cos_b = math.cos(base_angle)
                sin_b = math.sin(base_angle)
                rx = cos_b * lx - sin_b * ly
                ry = sin_b * lx + cos_b * ly

                # Normalize: scale the rotated curve so its endpoint
                # matches the expected displacement exactly.
                actual_dx = float(rx[-1])
                actual_dy = float(ry[-1])
                actual_len = math.hypot(actual_dx, actual_dy)
                exp_len = math.hypot(exp_dx, exp_dy)

                if actual_len > 1e-12 and exp_len > 1e-12:
                    # Scale + rotate to match expected endpoint
                    scale = exp_len / actual_len
                    a_angle = math.atan2(actual_dy, actual_dx)
                    e_angle = math.atan2(exp_dy, exp_dx)
                    rot = e_angle - a_angle
                    cos_r = math.cos(rot)
                    sin_r = math.sin(rot)
                    nx = scale * (cos_r * rx - sin_r * ry)
                    ny = scale * (sin_r * rx + cos_r * ry)
                else:
                    nx, ny = rx, ry

                # Build parametric function from normalized curve
                u = np.linspace(0, 1, num_bend_points + 1)
                fx = interp1d(u, nx, kind='cubic')
                fy = interp1d(u, ny, kind='cubic')

                def make_bend_func(fx_=fx, fy_=fy):
                    def bend_func(u_val):
                        return (float(fx_(u_val)), float(fy_(u_val)))
                    return bend_func

                rp.parametric(make_bend_func(), relative=True)

    return rp


def _euler_bend_function(
    radius: float, angle: float, p: float = 0.5,
    start_angle: float = 0.0, center: tuple[float, float] = (0.0, 0.0),
    nominal_radius: float | None = None,
):
    """Euler spiral (clothoid) bend for gdstk FlexPath bend_function.

    gdstk calls this per-edge with (radius, angle, start_angle, center).
    The ``radius`` differs per edge (nominal ± width/2). We generate the
    euler centerline at ``nominal_radius``, normalize it to match the
    expected circular-arc endpoints, then offset each point by
    (radius − nominal) along the outward radial to produce a
    constant-width offset curve.

    Args:
        radius:          Edge-specific radius (nominal ± width/2).
        angle:           Bend angle in radians (negative for CW).
        p:               Euler fraction (0–0.5).
        start_angle:     Starting angle in radians (from gdstk).
        center:          Center point of the bend (from gdstk).
        nominal_radius:  The FlexRoute's bend_radius (centerline radius).
    """
    num_points = 128
    abs_angle = abs(angle)
    sign = 1.0 if angle >= 0 else -1.0

    if nominal_radius is None:
        nominal_radius = radius

    if abs_angle < 1e-10:
        t = start_angle
        pt = [center[0] + radius * math.cos(t), center[1] + radius * math.sin(t)]
        return np.array([pt, pt])

    p = max(0.0, min(p, 0.5))

    if p < 1e-10:
        # Fully circular: standard arc
        t = np.linspace(start_angle, start_angle + angle, num_points)
        x = center[0] + radius * np.cos(t)
        y = center[1] + radius * np.sin(t)
        return np.column_stack([x, y])

    # ── Generate euler centerline in local frame ─────────────────
    # Local frame: starts at origin, heading in +x direction.
    R = nominal_radius
    arc_len = R * abs_angle

    euler_len = arc_len * p
    circ_len = arc_len * (1 - 2 * p)

    s = np.linspace(0, arc_len, num_points)
    ds = s[1] - s[0]

    # k_max scaled so total heading integral = abs_angle
    k_max = 1.0 / (R * (1.0 - p))
    k = np.zeros_like(s)
    for i, si in enumerate(s):
        if euler_len > 1e-12 and si <= euler_len:
            k[i] = k_max * (si / euler_len)
        elif si <= euler_len + circ_len:
            k[i] = k_max
        elif euler_len > 1e-12:
            k[i] = k_max * ((arc_len - si) / euler_len)
        else:
            k[i] = k_max

    # Integrate curvature → local heading (0 at start)
    local_heading = np.cumsum(k * sign) * ds
    local_heading = np.insert(local_heading[:-1], 0, 0.0)

    # Integrate heading → local position (starts at origin)
    lx = np.cumsum(np.cos(local_heading) * ds)
    ly = np.cumsum(np.sin(local_heading) * ds)
    lx = np.insert(lx, 0, 0.0)
    ly = np.insert(ly, 0, 0.0)

    # ── Normalize: rotate + scale local path to match expected endpoints ──
    # Expected start: on circle at start_angle
    exp_start = np.array([
        center[0] + R * math.cos(start_angle),
        center[1] + R * math.sin(start_angle),
    ])
    # Expected end: on circle at start_angle + angle
    exp_end = np.array([
        center[0] + R * math.cos(start_angle + angle),
        center[1] + R * math.sin(start_angle + angle),
    ])

    # Actual local start/end
    local_start = np.array([lx[0], ly[0]])
    local_end = np.array([lx[-1], ly[-1]])

    # Vectors from start to end
    exp_vec = exp_end - exp_start
    local_vec = local_end - local_start

    exp_len = np.linalg.norm(exp_vec)
    local_len = np.linalg.norm(local_vec)

    if local_len < 1e-12 or exp_len < 1e-12:
        # Degenerate — fall back to circular
        t = np.linspace(start_angle, start_angle + angle, num_points)
        x = center[0] + radius * np.cos(t)
        y = center[1] + radius * np.sin(t)
        return np.column_stack([x, y])

    # Scale factor
    scale = exp_len / local_len

    # Rotation angle: from local_vec direction to exp_vec direction
    local_angle = math.atan2(local_vec[1], local_vec[0])
    exp_angle_dir = math.atan2(exp_vec[1], exp_vec[0])
    rot = exp_angle_dir - local_angle

    cos_r = math.cos(rot)
    sin_r = math.sin(rot)

    # Transform: translate to origin, scale, rotate, translate to exp_start
    cx = scale * (cos_r * lx - sin_r * ly) + exp_start[0]
    cy = scale * (sin_r * lx + cos_r * ly) + exp_start[1]

    # ── Offset by (radius - nominal) along outward radial ────────
    offset = radius - R
    out_x = cx - center[0]
    out_y = cy - center[1]
    out_len = np.sqrt(out_x**2 + out_y**2)
    out_len = np.where(out_len < 1e-12, 1.0, out_len)
    out_x /= out_len
    out_y /= out_len

    x = cx + offset * out_x
    y = cy + offset * out_y

    return np.column_stack([x, y])


# ── Repetition ───────────────────────────────────────────────


class Repetition(BaseModel):
    """Rectangular grid repetition for CellRef (ARef in GDS terms)."""

    columns: int = Field(ge=1)
    rows: int = Field(ge=1)
    spacing: tuple[float, float]

    def to_gdstk(self) -> gdstk.Repetition:
        return gdstk.Repetition(
            columns=self.columns,
            rows=self.rows,
            spacing=self.spacing,
        )


# ── CellRef ──────────────────────────────────────────────────


class CellRef(BaseModel):
    """A reference (instance) of another cell, placed in the parent.

    Covers both SRef (single) and ARef (array via repetition).
    The compile layer resolves cell_name to the actual gdstk.Cell.
    """

    type: Literal["cellref"] = "cellref"
    cell_name: str
    origin: tuple[float, float] = (0.0, 0.0)
    rotation: float = 0.0
    magnification: float = 1.0
    x_reflection: bool = False
    repetition: Repetition | None = None

    def to_gdstk(self, cell_map: dict[str, gdstk.Cell]) -> gdstk.Reference:
        """Build a gdstk Reference.

        Args:
            cell_map: Mapping of cell names to compiled gdstk.Cell objects.
                      Provided by the compile layer.
        """
        target = cell_map[self.cell_name]
        ref = gdstk.Reference(
            target,
            origin=self.origin,
            rotation=math.radians(self.rotation),
            magnification=self.magnification,
            x_reflection=self.x_reflection,
        )
        if self.repetition is not None:
            ref.repetition = self.repetition.to_gdstk()
        return ref


# ── Discriminated union for serialization ────────────────────

Element = Annotated[
    Union[Rect, Polygon, FlexRoute, CellRef],
    Field(discriminator="type"),
]
