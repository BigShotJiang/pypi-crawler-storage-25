from __future__ import annotations

from pydantic import BaseModel, Field, PrivateAttr

from lumicron_api.models.route_profile import RouteProfile
from lumicron_api.models.layer import LayerSpec


class Port(BaseModel):
    """An optical or electrical port on a cell.

    Attributes:
        name:          Unique identifier within the parent cell.
        position:      (x, y) in microns.
        direction:     Angle in degrees, measured counter-clockwise from +X.
                       0 = East, 90 = North, 180 = West, 270 = South.
        width:         Port width in microns.
        layer:         The layer this port lives on.
        route_profile: Optional route profile for routing style.
        port_type:     "optical" or "electrical" — determines routing behavior.
    """

    name: str
    position: tuple[float, float] = (0.0, 0.0)
    direction: float = 0.0
    width: float = Field(gt=0)
    layer: LayerSpec
    route_profile: RouteProfile | None = None
    port_type: str = "optical"
    _source_cell: str | None = PrivateAttr(default=None)

    model_config = {"frozen": True}

    @property
    def x(self) -> float:
        return self.position[0]

    @property
    def y(self) -> float:
        return self.position[1]

    def translated(self, dx: float, dy: float) -> Port:
        """Return a new Port shifted by (dx, dy)."""
        return self.model_copy(
            update={"position": (self.x + dx, self.y + dy)}
        )

    def transformed(
        self,
        origin: tuple[float, float] = (0.0, 0.0),
        rotation: float = 0.0,
        x_reflection: bool = False,
    ) -> Port:
        """Return a new Port with reflection, rotation, and translation applied.

        GDS transform order: reflect across x-axis, rotate about (0,0),
        then translate by origin.
        """
        import math

        px, py = self.position
        d = self.direction

        # Step 1: x_reflection (flip y and mirror direction)
        if x_reflection:
            py = -py
            d = -d

        # Step 2: rotation about (0, 0)
        if rotation != 0:
            rad = math.radians(rotation)
            cos_a, sin_a = math.cos(rad), math.sin(rad)
            px, py = px * cos_a - py * sin_a, px * sin_a + py * cos_a
            d = d + rotation

        # Step 3: translation
        ox, oy = origin
        px += ox
        py += oy

        return self.model_copy(
            update={"position": (px, py), "direction": d % 360}
        )

    def __repr__(self) -> str:
        return (
            f"Port('{self.name}', pos=({self.x}, {self.y}), "
            f"dir={self.direction}°, w={self.width}, "
            f"layer={self.layer.layer}/{self.layer.datatype}, "
            f"type={self.port_type})"
        )
