from __future__ import annotations

import json
from pathlib import Path

import gdstk
from pydantic import BaseModel, Field

from lumicron_api.models.cell import Cell
from lumicron_api.models.layer import LayerMap


class PdkRef(BaseModel):
    """Reference to a PDK (reserved for future use)."""

    name: str = ""
    version: str = ""


class Layout(BaseModel):
    """Top-level design container.

    Holds all cells, the layer map, and metadata needed to
    write the design file (JSON) or compile to GDS/OASIS.
    """

    top_cell: str = Field(min_length=1)
    cells: dict[str, Cell] = Field(default_factory=dict)
    layer_map: LayerMap = Field(default_factory=LayerMap)
    pdk: PdkRef = Field(default_factory=PdkRef)
    unit: float = Field(default=1e-6)
    precision: float = Field(default=1e-9)

    def add_cell(self, cell: Cell) -> None:
        if cell.name in self.cells:
            raise ValueError(f"Cell '{cell.name}' already exists in layout")
        self.cells[cell.name] = cell

    def compile(self) -> gdstk.Library:
        from lumicron_api.compile.gdstk_backend import compile_layout

        return compile_layout(
            cells=self.cells,
            top_cell=self.top_cell,
            unit=self.unit,
            precision=self.precision,
        )

    def save(self, path: str | Path) -> None:
        """Write the design file as JSON."""
        path = Path(path)
        path.write_text(self.model_dump_json(indent=2))

    @classmethod
    def load(cls, path: str | Path) -> Layout:
        """Read a design file from JSON."""
        path = Path(path)
        return cls.model_validate_json(path.read_text())

    def to_gds(self, path: str | Path, flatten: bool = False) -> None:
        """Compile and write a GDS-II file."""
        lib = self.compile()
        if flatten:
            top = lib.top_level()[0]
            top.flatten()
        lib.write_gds(str(path))

    def to_oas(self, path: str | Path, flatten: bool = False) -> None:
        """Compile and write an OASIS file."""
        lib = self.compile()
        if flatten:
            top = lib.top_level()[0]
            top.flatten()
        lib.write_oas(str(path))
