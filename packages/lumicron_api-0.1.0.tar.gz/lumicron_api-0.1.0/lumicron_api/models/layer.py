from __future__ import annotations

from pydantic import BaseModel, Field, model_validator


class LayerSpec(BaseModel):
    """A GDS-II layer specified by layer number and datatype number."""

    layer: int = Field(ge=0, le=65535)
    datatype: int = Field(default=0, ge=0, le=65535)

    model_config = {"frozen": True}

    def to_gdstk(self) -> tuple[int, int]:
        return (self.layer, self.datatype)

    def __hash__(self) -> int:
        return hash((self.layer, self.datatype))

    def __eq__(self, other: object) -> bool:
        if isinstance(other, LayerSpec):
            return self.layer == other.layer and self.datatype == other.datatype
        return NotImplemented

    def __repr__(self) -> str:
        return f"LayerSpec({self.layer}/{self.datatype})"


class LayerMap(BaseModel):
    """Named mapping of layer names to LayerSpec values.

    Used to define a process stack — e.g. WG_CORE -> (1, 0).
    Serialises to / from the design file JSON.
    """

    layers: dict[str, LayerSpec] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _no_duplicate_specs(self) -> LayerMap:
        seen: dict[tuple[int, int], str] = {}
        for name, spec in self.layers.items():
            key = spec.to_gdstk()
            if key in seen:
                raise ValueError(
                    f"Duplicate layer spec {key}: "
                    f"'{name}' and '{seen[key]}'"
                )
            seen[key] = name
        return self

    def add(self, name: str, layer: int, datatype: int = 0) -> LayerSpec:
        spec = LayerSpec(layer=layer, datatype=datatype)
        if name in self.layers:
            raise ValueError(f"Layer name '{name}' already exists")
        key = spec.to_gdstk()
        for existing_name, existing_spec in self.layers.items():
            if existing_spec.to_gdstk() == key:
                raise ValueError(
                    f"Layer spec {key} already mapped to '{existing_name}'"
                )
        self.layers[name] = spec
        return spec

    def get(self, name: str) -> LayerSpec:
        return self.layers[name]

    def __getitem__(self, name: str) -> LayerSpec:
        return self.layers[name]

    def __contains__(self, name: str) -> bool:
        return name in self.layers

    def __repr__(self) -> str:
        entries = ", ".join(
            f"{name}={spec.layer}/{spec.datatype}"
            for name, spec in self.layers.items()
        )
        return f"LayerMap({entries})"
