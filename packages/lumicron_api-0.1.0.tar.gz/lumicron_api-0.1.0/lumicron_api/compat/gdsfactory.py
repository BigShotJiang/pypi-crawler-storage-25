"""Import gdsfactory PDKs into lumicron_api.

Converts gdsfactory LayerMaps, CrossSections, Components, and full PDKs
into their lumicron_api equivalents. Requires gdsfactory to be installed.

Usage:
    from lumicron_api.compat.gdsfactory import import_pdk, import_component

    # Import a full PDK
    layers, route_profiles = import_pdk(my_gf_pdk)

    # Import a single component
    cell = import_component(my_gf_component)
"""

from __future__ import annotations

from typing import Any

from lumicron_api.lang.cell import CELL
from lumicron_api.lang.port import PORT
from lumicron_api.models.route_profile import CladdingLayer, RouteProfile
from lumicron_api.models.elements import Polygon as LMPolygon
from lumicron_api.models.layer import LayerMap, LayerSpec


def import_layer_map(gf_layer_map) -> LayerMap:
    """Convert a gdsfactory LayerMap class to a lumicron LayerMap.

    Handles both classic gdsfactory LayerMaps (tuple attributes) and
    modern gdsfactory v9+ LayerMaps (IntEnum with indexable members).

    Args:
        gf_layer_map: A gdsfactory LayerMap class (not instance).

    Returns:
        A lumicron LayerMap with all layers.
    """
    lm = LayerMap()

    # Modern gdsfactory: enum with __members__
    if hasattr(gf_layer_map, "__members__"):
        for name, member in gf_layer_map.__members__.items():
            try:
                layer, datatype = int(member[0]), int(member[1])
                lm.add(name, layer, datatype)
            except (ValueError, TypeError, IndexError):
                continue
        return lm

    # Classic gdsfactory: class with tuple attributes
    for name in dir(gf_layer_map):
        if name.startswith("_"):
            continue
        value = getattr(gf_layer_map, name)
        if isinstance(value, (tuple, list)) and len(value) == 2:
            try:
                layer, datatype = int(value[0]), int(value[1])
                lm.add(name, layer, datatype)
            except (ValueError, TypeError):
                continue

    return lm


def import_route_profile(
    name: str,
    gf_xs_func,
    gf_layer_map=None,
) -> RouteProfile:
    """Convert a gdsfactory cross_section function to a lumicron RouteProfile.

    Args:
        name: Name for the route profile (e.g. "siln_strip").
        gf_xs_func: A callable that returns a gdsfactory CrossSection,
            or an already-instantiated CrossSection.
        gf_layer_map: Optional gdsfactory LayerMap for resolving layer names.

    Returns:
        A lumicron RouteProfile.
    """
    xs = gf_xs_func() if callable(gf_xs_func) else gf_xs_func

    # Extract layer — gdsfactory stores as tuple (layer, datatype)
    layer_tuple = _resolve_gf_layer(xs.layer, gf_layer_map)
    layer = LayerSpec(layer=layer_tuple[0], datatype=layer_tuple[1])

    # Extract cladding
    cladding: list[CladdingLayer] = []
    clad_layers = getattr(xs, "cladding_layers", None) or []
    clad_offsets = getattr(xs, "cladding_offsets", None) or []
    for cl, co in zip(clad_layers, clad_offsets):
        cl_tuple = _resolve_gf_layer(cl, gf_layer_map)
        cladding.append(CladdingLayer(
            layer=LayerSpec(layer=cl_tuple[0], datatype=cl_tuple[1]),
            offset=co,
        ))

    return RouteProfile(
        name=name,
        layer=layer,
        width=xs.width,
        radius=getattr(xs, "radius", 0) or 0,
        radius_min=getattr(xs, "radius_min", 0) or 0,
        cladding=cladding,
    )


# Keep old name as alias for backwards compatibility with existing scripts
import_cross_section = import_route_profile


def import_route_profiles(
    gf_cross_sections: dict[str, Any],
    gf_layer_map=None,
) -> dict[str, RouteProfile]:
    """Convert a dict of gdsfactory cross_section functions.

    Args:
        gf_cross_sections: Dict of name → callable/CrossSection.
        gf_layer_map: Optional LayerMap for resolving layer names.

    Returns:
        Dict of name → lumicron RouteProfile.
    """
    result = {}
    for name, xs_func in gf_cross_sections.items():
        try:
            result[name] = import_route_profile(name, xs_func, gf_layer_map)
        except Exception:
            # Skip cross sections that fail to convert
            continue
    return result


# Keep old name as alias for backwards compatibility with existing scripts
import_cross_sections = import_route_profiles


def import_component(gf_component) -> CELL:
    """Convert a gdsfactory Component to a lumicron CELL.

    Extracts polygons and ports from the flattened component.
    Cell references are flattened into polygons.

    Args:
        gf_component: A gdsfactory Component instance.

    Returns:
        A lumicron CELL builder.
    """
    name = gf_component.name
    c = CELL(name)

    # Extract polygons per layer using by="tuple" for tuple keys
    polys = gf_component.get_polygons(by="tuple")
    for layer_tuple, poly_list in polys.items():
        layer_spec = LayerSpec(layer=int(layer_tuple[0]), datatype=int(layer_tuple[1]))
        for klayout_poly in poly_list:
            # KLayout PolygonWithProperties: convert to float coords via to_dtype
            dpoly = klayout_poly.to_dtype(0.001)
            verts = [
                (float(pt.x), float(pt.y))
                for pt in dpoly.each_point_hull()
            ]
            if len(verts) >= 3:
                poly = LMPolygon(vertices=verts, layer=layer_spec)
                c._cell.add_element(poly)

    # Compute bbox for handle (so anchors work)
    if c._cell.elements:
        all_x, all_y = [], []
        for elem in c._cell.elements:
            if isinstance(elem, LMPolygon):
                all_x.extend(v[0] for v in elem.vertices)
                all_y.extend(v[1] for v in elem.vertices)
        if all_x and all_y:
            from lumicron_api.lang.handles import PlacedHandle
            bbox = (min(all_x), min(all_y), max(all_x), max(all_y))
            handle = PlacedHandle(bbox)
            c._handles.append(handle)

    # Extract ports — gdsfactory v9 ports are iterable, not a dict
    for gf_port in gf_component.ports:
        layer_tuple = _resolve_gf_layer(gf_port.layer, gf_layer_map=None)
        layer_int, datatype_int = layer_tuple
        c.add(PORT(
            name=gf_port.name,
            position=(float(gf_port.center[0]), float(gf_port.center[1])),
            direction=float(gf_port.orientation or 0),
            width=float(gf_port.width),
            layer=LayerSpec(layer=layer_int, datatype=datatype_int),
        ))

    return c


def import_pdk(gf_pdk) -> tuple[LayerMap, dict[str, RouteProfile]]:
    """Import a full gdsfactory PDK.

    Args:
        gf_pdk: A gdsfactory Pdk instance.

    Returns:
        Tuple of (LayerMap, dict of RouteProfiles).
    """
    layers = import_layer_map(gf_pdk.layers)
    route_profiles = import_route_profiles(
        gf_pdk.cross_sections,
        gf_layer_map=gf_pdk.layers,
    )
    return layers, route_profiles


def _resolve_gf_layer(layer, gf_layer_map=None) -> tuple[int, int]:
    """Resolve a gdsfactory layer reference to (layer, datatype)."""
    # String name lookup (must come before generic indexable check)
    if isinstance(layer, str):
        if gf_layer_map is not None:
            val = getattr(gf_layer_map, layer, None)
            if val is not None and hasattr(val, "__getitem__"):
                return (int(val[0]), int(val[1]))
        raise ValueError(f"Cannot resolve layer: {layer!r}")
    # Tuple or list
    if isinstance(layer, (tuple, list)) and len(layer) == 2:
        return (int(layer[0]), int(layer[1]))
    # Enum member or other indexable with len == 2 (e.g. aenum IntEnum)
    # Must come before bare int check since aenum members are isinstance(int)
    if hasattr(layer, "__getitem__") and hasattr(layer, "__len__"):
        if len(layer) == 2:
            return (int(layer[0]), int(layer[1]))
    # Bare integer (gdsfactory v9 port layers)
    if isinstance(layer, int):
        return (layer, 0)
    raise ValueError(f"Cannot resolve layer: {layer!r}")
