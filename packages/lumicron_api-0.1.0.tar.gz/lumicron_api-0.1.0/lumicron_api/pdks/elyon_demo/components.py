"""Elyon Demo PDK — component library.

Native lumicron_api translations of the gdsfactory Elyon Demo PDK components.
"""

from __future__ import annotations

import math
from typing import List, Tuple

from lumicron_api.lang.cell import CELL
from lumicron_api.lang.port import PORT
from lumicron_api.lang.array import ARRAY
from lumicron_api.lang.params import cell_params
from lumicron_api.models.elements import Polygon, Rect
from lumicron_api.models.layer import LayerSpec
from lumicron_api.pdks.elyon_demo.layers import LAYER

import lumicron_api.all as lm


# ── Path helpers ─────────────────────────────────────────────


def _branch_centerline(
    radius: float, angle_deg: float, straight_length: float,
    n_per_bend: int = 32,
) -> List[Tuple[float, float]]:
    """Compute centerline for one Y-splitter branch.

    The branch is: euler(+angle) → euler(-angle) → straight.
    Approximated with circular arcs.  Starts at (0, 0) heading east.
    Returns the centerline including the final straight section.
    """
    angle_rad = math.radians(angle_deg)
    arc_length = radius * abs(angle_rad)
    ds = arc_length / n_per_bend if n_per_bend > 0 else 0

    points: List[Tuple[float, float]] = [(0.0, 0.0)]
    x, y = 0.0, 0.0

    # First bend: heading goes from 0 to angle_rad
    for i in range(n_per_bend):
        heading = angle_rad * (i + 0.5) / n_per_bend  # midpoint
        x += ds * math.cos(heading)
        y += ds * math.sin(heading)
        points.append((x, y))

    # Second bend: heading goes from angle_rad back to 0
    for i in range(n_per_bend):
        heading = angle_rad - angle_rad * (i + 0.5) / n_per_bend  # midpoint
        x += ds * math.cos(heading)
        y += ds * math.sin(heading)
        points.append((x, y))

    # Straight section (heading is now 0 = east)
    x += straight_length
    points.append((x, y))

    return points


def _path_to_polygon(
    centerline: List[Tuple[float, float]], width: float, layer: LayerSpec
) -> Polygon:
    """Extrude a centerline path into a polygon with the given width."""
    hw = width / 2
    left: List[Tuple[float, float]] = []
    right: List[Tuple[float, float]] = []
    n = len(centerline)
    for i in range(n):
        if i == 0:
            dx = centerline[1][0] - centerline[0][0]
            dy = centerline[1][1] - centerline[0][1]
        elif i == n - 1:
            dx = centerline[-1][0] - centerline[-2][0]
            dy = centerline[-1][1] - centerline[-2][1]
        else:
            dx = centerline[i + 1][0] - centerline[i - 1][0]
            dy = centerline[i + 1][1] - centerline[i - 1][1]
        seg_len = math.hypot(dx, dy)
        if seg_len < 1e-12:
            nx, ny = 0.0, 1.0
        else:
            nx, ny = -dy / seg_len, dx / seg_len
        px, py = centerline[i]
        left.append((px + nx * hw, py + ny * hw))
        right.append((px - nx * hw, py - ny * hw))
    return Polygon(vertices=left + list(reversed(right)), layer=layer)


# ── Helpers ──────────────────────────────────────────────────


def _rectangle(
    width: float, height: float, layer: LayerSpec, centered: bool = False
) -> Rect:
    if centered:
        return Rect(
            corner1=(-width / 2, -height / 2),
            corner2=(width / 2, height / 2),
            layer=layer,
        )
    return Rect(corner1=(0, 0), corner2=(width, height), layer=layer)


def _taper_polygon(
    length: float,
    width1: float,
    width2: float,
    layer: LayerSpec,
) -> Polygon:
    """A linear taper as a 4-vertex polygon."""
    return Polygon(
        vertices=[
            (0, -width1 / 2),
            (length, -width2 / 2),
            (length, width2 / 2),
            (0, width1 / 2),
        ],
        layer=layer,
    )


# ── Components ───────────────────────────────────────────────


@cell_params
def ChipFrame(
    total_width: float = 6000,
    total_height: float = 4000,
    border_width: float = 100,
):
    """Chip frame — border rectangle on TSIE layer."""
    c = CELL("ChipFrame")

    hw, hh = total_width / 2, total_height / 2
    bw = border_width / 2

    # Outer rectangle as polygon (frame = outer minus inner)
    # Four rectangles forming the border
    # Top bar
    c._cell.add_element(Rect(
        corner1=(-hw, hh - bw), corner2=(hw, hh), layer=LAYER.TSIE,
    ))
    # Bottom bar
    c._cell.add_element(Rect(
        corner1=(-hw, -hh), corner2=(hw, -hh + bw), layer=LAYER.TSIE,
    ))
    # Left bar
    c._cell.add_element(Rect(
        corner1=(-hw, -hh + bw), corner2=(-hw + bw, hh - bw), layer=LAYER.TSIE,
    ))
    # Right bar
    c._cell.add_element(Rect(
        corner1=(hw - bw, -hh + bw), corner2=(hw, hh - bw), layer=LAYER.TSIE,
    ))

    from lumicron_api.lang.handles import PlacedHandle
    c._handles.append(PlacedHandle((-hw, -hh, hw, hh)))

    return c


@cell_params
def EdgeCouplerSi(
    length: float = 100.0,
    width_tip: float = 0.5,
    width_port: float = 0.1,
):
    """Silicon edge coupler — taper from tip to port width."""
    c = CELL("EdgeCouplerSi")
    c._cell.add_element(_taper_polygon(length, width_tip, width_port, LAYER.SILC))
    c.add(PORT("o1", position=(0, 0), direction=180, width=width_tip, layer=LAYER.SILC))
    c.add(PORT("o2", position=(length, 0), direction=0, width=width_port, layer=LAYER.SILC))

    from lumicron_api.lang.handles import PlacedHandle
    c._handles.append(PlacedHandle((0, -width_tip / 2, length, width_tip / 2)))

    return c


@cell_params
def EdgeCouplerSiN(
    length: float = 100.0,
    width_tip: float = 0.5,
    width_port: float = 1.5,
):
    """Silicon nitride edge coupler — taper from tip to port width."""
    c = CELL("EdgeCouplerSiN")
    c._cell.add_element(_taper_polygon(length, width_tip, width_port, LAYER.SILN))
    c.add(PORT("o1", position=(0, 0), direction=180, width=width_tip, layer=LAYER.SILN))
    c.add(PORT("o2", position=(length, 0), direction=0, width=width_port, layer=LAYER.SILN))

    from lumicron_api.lang.handles import PlacedHandle
    w = max(width_tip, width_port)
    c._handles.append(PlacedHandle((0, -w / 2, length, w / 2)))

    return c


@cell_params
def CVIA_comp(x_dim: float = 10, y_dim: float = 10):
    """Contact via rectangle."""
    c = CELL("CVIA")
    c._cell.add_element(_rectangle(x_dim, y_dim, LAYER.CVIA, centered=True))
    from lumicron_api.lang.handles import PlacedHandle
    c._handles.append(PlacedHandle((-x_dim / 2, -y_dim / 2, x_dim / 2, y_dim / 2)))
    return c


@cell_params
def VIA1_comp(x_dim: float = 10, y_dim: float = 10):
    """Via1 layer rectangle."""
    c = CELL("VIA1")
    c._cell.add_element(_rectangle(x_dim, y_dim, LAYER.VIA1, centered=True))
    from lumicron_api.lang.handles import PlacedHandle
    c._handles.append(PlacedHandle((-x_dim / 2, -y_dim / 2, x_dim / 2, y_dim / 2)))
    return c


@cell_params
def VIA2_comp(x_dim: float = 10, y_dim: float = 10):
    """Via2 layer rectangle."""
    c = CELL("VIA2")
    c._cell.add_element(_rectangle(x_dim, y_dim, LAYER.VIA2, centered=True))
    from lumicron_api.lang.handles import PlacedHandle
    c._handles.append(PlacedHandle((-x_dim / 2, -y_dim / 2, x_dim / 2, y_dim / 2)))
    return c


@cell_params
def ViaArray(
    via_layer: LayerSpec = LAYER.CVIA,
    via_x_dim: float = 1,
    via_y_dim: float = 1,
    array_length: float = 30,
    array_width: float = 8,
    via_x_spacing: float = 1.5,
    via_y_spacing: float = 1.5,
):
    """Array of vias centered at origin."""
    c = CELL("ViaArray")

    pitch_x = via_x_dim + via_x_spacing
    pitch_y = via_y_dim + via_y_spacing
    n_x = int(array_length / pitch_x)
    n_y = int(array_width / pitch_y)

    # Single via cell (centered at origin)
    via = CELL("Via")
    via.add(_rectangle(via_x_dim, via_y_dim, via_layer, centered=True))

    # 2D array of vias
    grid = c.add(ARRAY(via, count=(n_x, n_y), pitch=(pitch_x, pitch_y)))

    # Center the grid at origin (default anchor is "C", so at((0,0))
    # places the array's center at the cell origin)
    c.Place(grid).at((0, 0))

    return c


@cell_params
def Pad(
    pad_x: float = 95.0,
    pad_y: float = 95.0,
    opening_border: float = 5.0,
    pad_down_to: str = "CMTL",
):
    """Bond pad with configurable metal stack depth."""
    c = CELL("Pad")

    # Top metal (always present)
    c._cell.add_element(_rectangle(pad_x, pad_y, LAYER.CMTL, centered=True))

    # Opening (always present)
    ox = pad_x - opening_border * 2
    oy = pad_y - opening_border * 2
    c._cell.add_element(_rectangle(ox, oy, LAYER.OXOP, centered=True))

    if pad_down_to in ("MTL1", "MTL2", "ALL"):
        c._cell.add_element(_rectangle(pad_x, pad_y, LAYER.MTL1, centered=True))
        # CVIA array between CMTL and MTL1
        via = ViaArray(via_layer=LAYER.CVIA, array_length=pad_x, array_width=pad_y)
        c.add(via)

    if pad_down_to in ("MTL2", "ALL"):
        c._cell.add_element(_rectangle(pad_x, pad_y, LAYER.MTL2, centered=True))
        # VIA1 array between MTL1 and MTL2
        via1 = ViaArray(via_layer=LAYER.VIA1, array_length=pad_x, array_width=pad_y)
        c.add(via1)

    if pad_down_to == "ALL":
        # VIA2 array
        via2 = ViaArray(via_layer=LAYER.VIA2, array_length=pad_x, array_width=pad_y)
        c.add(via2)

    from lumicron_api.lang.handles import PlacedHandle
    c._handles.append(PlacedHandle((-pad_x / 2, -pad_y / 2, pad_x / 2, pad_y / 2)))

    return c


@cell_params
def Label(
    text: str = "Test",
    height: float = 1.0,
    layer: LayerSpec = LAYER.CMTL,
):
    """Text label (placeholder — renders as a rectangle with text metadata).

    Full text rendering requires the GUI. The script version creates
    a bounding rectangle as a placeholder.
    """
    c = CELL("Label")
    # Approximate: ~0.6 aspect ratio per character
    width = len(text) * height * 0.6
    c._cell.add_element(Rect(
        corner1=(0, 0), corner2=(width, height), layer=layer,
    ))

    from lumicron_api.lang.handles import PlacedHandle
    c._handles.append(PlacedHandle((0, 0, width, height)))

    return c


@cell_params
def YSplitter(
    width: float = 0.5,
    gap: float = 0.2,
    length: float = 10.0,
    angle: float = 15.0,
    bend_radius: float = 10.0,
    layer: LayerSpec = LAYER.SILN,
):
    """1x2 Y-branch splitter.

    Ports:
        i1 — input (left)
        o1 — top output (right)
        o2 — bottom output (right)
    """
    c = CELL("YSplitter")

    # Input straight section
    inp_poly = Rect(
        corner1=(-length, -width / 2),
        corner2=(0, width / 2),
        layer=layer,
    )
    c._cell.add_element(inp_poly)

    # Top branch: euler(+angle) → euler(-angle) → straight
    # Starts at (0, +gap/2), curves up then back to horizontal
    top_cl = _branch_centerline(bend_radius, angle, length)
    top_cl = [(x, y + gap / 2) for x, y in top_cl]
    top_poly = _path_to_polygon(top_cl, width, layer)
    c._cell.add_element(top_poly)

    # Bottom branch: euler(-angle) → euler(+angle) → straight
    # Starts at (0, -gap/2), curves down then back to horizontal
    bot_cl = _branch_centerline(bend_radius, -angle, length)
    bot_cl = [(x, y - gap / 2) for x, y in bot_cl]
    bot_poly = _path_to_polygon(bot_cl, width, layer)
    c._cell.add_element(bot_poly)

    # Ports
    top_end = top_cl[-1]
    bot_end = bot_cl[-1]

    c.add(PORT("i1", position=(-length, 0), direction=180, width=width, layer=layer))
    c.add(PORT("o1", position=top_end, direction=0, width=width, layer=layer))
    c.add(PORT("o2", position=bot_end, direction=0, width=width, layer=layer))

    # Bounding box
    all_x = [top_end[0], bot_end[0], -length]
    all_y = [top_end[1] + width / 2, bot_end[1] - width / 2, -width / 2, width / 2]
    from lumicron_api.lang.handles import PlacedHandle
    c._handles.append(PlacedHandle((
        min(all_x), min(all_y), max(all_x), max(all_y),
    )))

    return c


@cell_params
def NxM_MMI(
    body_x: float = 20.0,
    n_inputs: int = 2,
    n_outputs: int = 2,
    waveguide_spacing: float = 0.2,
    taper_length: float = 5.0,
    taper_tip_width: float = 0.5,
    taper_width: float = 2.0,
    layer: LayerSpec = LAYER.SILC,
):
    """NxM multimode interference coupler.

    Ports:
        i1..iN — input ports (left)
        o1..oM — output ports (right)
    """
    c = CELL("NxM_MMI")

    n_max = max(n_inputs, n_outputs)
    total_mmi_width = (n_max - 1) * waveguide_spacing + n_max * taper_width

    # MMI body (centered at origin)
    c._cell.add_element(Rect(
        corner1=(-body_x / 2, -total_mmi_width / 2),
        corner2=(body_x / 2, total_mmi_width / 2),
        layer=layer,
    ))

    # Input tapers (left side, pointing inward)
    for i in range(n_inputs):
        y_pos = (i - (n_inputs - 1) / 2) * (taper_width + waveguide_spacing)
        # Taper: wide end at MMI body, narrow end at port
        tip_x = -body_x / 2 - taper_length
        body_edge_x = -body_x / 2
        c._cell.add_element(Polygon(
            vertices=[
                (tip_x, y_pos - taper_tip_width / 2),
                (body_edge_x, y_pos - taper_width / 2),
                (body_edge_x, y_pos + taper_width / 2),
                (tip_x, y_pos + taper_tip_width / 2),
            ],
            layer=layer,
        ))
        c.add(PORT(
            f"i{i + 1}",
            position=(tip_x, y_pos),
            direction=180,
            width=taper_tip_width,
            layer=layer,
        ))

    # Output tapers (right side, pointing outward)
    for i in range(n_outputs):
        y_pos = (i - (n_outputs - 1) / 2) * (taper_width + waveguide_spacing)
        tip_x = body_x / 2 + taper_length
        body_edge_x = body_x / 2
        c._cell.add_element(Polygon(
            vertices=[
                (body_edge_x, y_pos - taper_width / 2),
                (tip_x, y_pos - taper_tip_width / 2),
                (tip_x, y_pos + taper_tip_width / 2),
                (body_edge_x, y_pos + taper_width / 2),
            ],
            layer=layer,
        ))
        c.add(PORT(
            f"o{i + 1}",
            position=(tip_x, y_pos),
            direction=0,
            width=taper_tip_width,
            layer=layer,
        ))

    # Bounding box
    total_x = body_x / 2 + taper_length
    from lumicron_api.lang.handles import PlacedHandle
    c._handles.append(PlacedHandle((
        -total_x, -total_mmi_width / 2, total_x, total_mmi_width / 2,
    )))

    return c

