"""Elyon Demo PDK — route profile definitions."""

from lumicron_api.models.route_profile import CladdingLayer, RouteProfile
from lumicron_api.pdks.elyon_demo.layers import LAYER


# ── Route profiles ───────────────────────────────────────────

siln_strip = RouteProfile(
    name="siln_strip",
    layer=LAYER.SILN,
    width=0.5,
    radius=10.0,
    radius_min=5.0,
    cladding=[CladdingLayer(layer=LAYER.OXID, offset=2.0)],
)

silc_strip = RouteProfile(
    name="silc_strip",
    layer=LAYER.SILC,
    width=0.5,
    radius=10.0,
    radius_min=5.0,
    cladding=[CladdingLayer(layer=LAYER.OXID, offset=2.0)],
)

silc_rib = RouteProfile(
    name="silc_rib",
    layer=LAYER.SILC,
    width=1.5,
    radius=20.0,
    radius_min=10.0,
)


# ── Convenience namespace ────────────────────────────────────

class RPROF:
    """All Elyon Demo PDK route profiles as class attributes."""

    siln_strip = siln_strip
    silc_strip = silc_strip
    silc_rib = silc_rib


def styles() -> dict[str, RouteProfile]:
    """Return all route profiles as a styles dict for CELL.styles."""
    return {
        "siln_strip": siln_strip,
        "silc_strip": silc_strip,
        "silc_rib": silc_rib,
    }
