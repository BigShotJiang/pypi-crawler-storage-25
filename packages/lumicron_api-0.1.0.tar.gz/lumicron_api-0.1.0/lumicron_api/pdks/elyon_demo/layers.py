"""Elyon Demo PDK — layer definitions."""

from lumicron_api.models.layer import LayerMap, LayerSpec


# ── Layer specs ──────────────────────────────────────────────

OXID = LayerSpec(layer=1, datatype=0)
CMTL = LayerSpec(layer=2, datatype=0)
CVIA = LayerSpec(layer=3, datatype=0)
MTL1 = LayerSpec(layer=4, datatype=0)
SILN = LayerSpec(layer=5, datatype=0)
VIA1 = LayerSpec(layer=6, datatype=0)
MTL2 = LayerSpec(layer=7, datatype=0)
VIA2 = LayerSpec(layer=8, datatype=0)
SILC = LayerSpec(layer=9, datatype=0)
NDOP = LayerSpec(layer=10, datatype=0)
NDPP = LayerSpec(layer=11, datatype=0)
NPPP = LayerSpec(layer=12, datatype=0)
PDOP = LayerSpec(layer=13, datatype=0)
PDPP = LayerSpec(layer=14, datatype=0)
PPPP = LayerSpec(layer=15, datatype=0)
TSIE = LayerSpec(layer=16, datatype=0)
OXOP = LayerSpec(layer=17, datatype=0)


# ── Convenience namespace ────────────────────────────────────

class LAYER:
    """All Elyon Demo PDK layers as class attributes."""

    OXID = OXID
    CMTL = CMTL
    CVIA = CVIA
    MTL1 = MTL1
    SILN = SILN
    VIA1 = VIA1
    MTL2 = MTL2
    VIA2 = VIA2
    SILC = SILC
    NDOP = NDOP
    NDPP = NDPP
    NPPP = NPPP
    PDOP = PDOP
    PDPP = PDPP
    PPPP = PPPP
    TSIE = TSIE
    OXOP = OXOP


# ── LayerMap for serialization ───────────────────────────────

def layer_map() -> LayerMap:
    """Return the full layer map for design file serialization."""
    lm = LayerMap()
    lm.add("OXID", 1, 0)
    lm.add("CMTL", 2, 0)
    lm.add("CVIA", 3, 0)
    lm.add("MTL1", 4, 0)
    lm.add("SILN", 5, 0)
    lm.add("VIA1", 6, 0)
    lm.add("MTL2", 7, 0)
    lm.add("VIA2", 8, 0)
    lm.add("SILC", 9, 0)
    lm.add("NDOP", 10, 0)
    lm.add("NDPP", 11, 0)
    lm.add("NPPP", 12, 0)
    lm.add("PDOP", 13, 0)
    lm.add("PDPP", 14, 0)
    lm.add("PPPP", 15, 0)
    lm.add("TSIE", 16, 0)
    lm.add("OXOP", 17, 0)
    return lm
