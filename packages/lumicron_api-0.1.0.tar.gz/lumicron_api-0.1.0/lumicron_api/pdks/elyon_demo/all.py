"""Convenience module — import everything from the Elyon Demo PDK.

Usage:
    import lumicron_api.pdks.elyon_demo.all as pdk

    frame = pdk.ChipFrame()
    coupler = pdk.EdgeCouplerSi(length=150)
    rp = pdk.RPROF.siln_strip
    layer = pdk.LAYER.SILC
"""

# Layers
from lumicron_api.pdks.elyon_demo.layers import LAYER

# Route profiles
from lumicron_api.pdks.elyon_demo.route_profiles import RPROF

# Components
from lumicron_api.pdks.elyon_demo.components import (
    ChipFrame,
    EdgeCouplerSi,
    EdgeCouplerSiN,
    CVIA_comp,
    VIA1_comp,
    VIA2_comp,
    ViaArray,
    Pad,
    Label,
    YSplitter,
    NxM_MMI,
)
