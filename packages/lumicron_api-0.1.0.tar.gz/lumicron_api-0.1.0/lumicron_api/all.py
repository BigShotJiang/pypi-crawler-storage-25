"""Convenience module — import everything with a single alias.

Usage:
    import lumicron_api.all as lm

    c = lm.CELL("MY_CELL")
    die = c.add(lm.DIE(size=(100, 50)))
    wg = lm.LayerSpec(layer=1)
"""

from lumicron_api.lang.array import ARRAY
from lumicron_api.lang.cell import CELL
from lumicron_api.lang.params import cell_params
from lumicron_api.lang.port import PORT
from lumicron_api.models.cell import Cell
from lumicron_api.models.route_profile import CladdingLayer, RouteProfile
from lumicron_api.models.elements import CellRef, FlexRoute, Polygon, Rect, Repetition
from lumicron_api.models.layer import LayerMap, LayerSpec
from lumicron_api.models.layout import Layout, PdkRef
from lumicron_api.models.port import Port

# Route profile factory
from lumicron_api.lang.route_profile_factory import route_profile

# Viewer
from lumicron_api.lang.viewer import set_viewer, view_layout

# Waveguide
from lumicron_api.lang.waveguide import Waveguide

# Shapes
from lumicron_api.lang.shapes import (
    Arc,
    Circle,
    Oval,
    Parallelogram,
    Rectangle,
    Ring,
    Trapezoid,
    Triangle,
)
