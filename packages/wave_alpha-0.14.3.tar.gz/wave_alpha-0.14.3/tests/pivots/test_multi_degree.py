from datetime import date, timedelta
from decimal import Decimal

from wave_alpha.domain import Bar, Interval
from wave_alpha.pivots.multi_degree import detect_multi_degree, detect_multi_degree_with_snapshots


def _bar(i: int, c: float) -> Bar:
    cd = Decimal(f"{c:.4f}")
    return Bar(
        timestamp=date(2024, 1, 1) + timedelta(days=i),
        open=cd,
        high=cd + Decimal("0.50"),
        low=cd - Decimal("0.50"),
        close=cd,
        volume=1,
    )


def test_multi_degree_subset_invariant() -> None:
    closes = [
        100,
        102,
        105,
        108,
        105,
        103,
        107,
        110,
        113,
        116,
        113,
        110,
        105,
        100,
        95,
        92,
        95,
        99,
        103,
        107,
        111,
        115,
        119,
        122,
    ]
    bars = [_bar(i, c) for i, c in enumerate(closes)]

    by_degree = detect_multi_degree(
        bars,
        interval=Interval.DAILY,
        thresholds=[Decimal("3"), Decimal("6"), Decimal("12")],
    )
    assert set(by_degree.keys()) == {0, 1, 2}

    for higher, lower in ((1, 0), (2, 1)):
        higher_keys = {(p.timestamp, p.type) for p in by_degree[higher]}
        lower_keys = {(p.timestamp, p.type) for p in by_degree[lower]}
        assert higher_keys.issubset(lower_keys), (
            f"degree {higher} not a subset of degree {lower}: missing {higher_keys - lower_keys}"
        )


def _make_synthetic_bars() -> list[Bar]:
    closes = [
        100,
        102,
        105,
        108,
        105,
        103,
        107,
        110,
        113,
        116,
        113,
        110,
        105,
        100,
        95,
        92,
        95,
        99,
        103,
        107,
        111,
        115,
        119,
        122,
    ]
    return [_bar(i, c) for i, c in enumerate(closes)]


def test_detect_multi_degree_with_snapshots_carries_required_move() -> None:
    bars = _make_synthetic_bars()
    snaps = detect_multi_degree_with_snapshots(
        bars, interval=Interval.DAILY, thresholds=[Decimal("1"), Decimal("2")]
    )
    assert snaps[0].required_move == Decimal("1")
    assert snaps[1].required_move == Decimal("2")
    # atr_at_last_bar is None when thresholds path is used
    assert snaps[0].atr_at_last_bar is None
    assert (
        snaps[0].pivots
        == detect_multi_degree(
            bars, interval=Interval.DAILY, thresholds=[Decimal("1"), Decimal("2")]
        )[0]
    )


def test_detect_multi_degree_with_snapshots_atr_path_populates_atr() -> None:
    bars = _make_synthetic_bars()
    snaps = detect_multi_degree_with_snapshots(
        bars, interval=Interval.DAILY, atr_multiples=[Decimal("0.5"), Decimal("1")]
    )
    # atr_at_last_bar should be a positive Decimal when there's enough history
    for snap in snaps.values():
        if snap.atr_at_last_bar is not None:
            assert snap.atr_at_last_bar > Decimal("0")
        # required_move should be atr * multiple (or 0 if atr missing)
        assert snap.required_move >= Decimal("0")
