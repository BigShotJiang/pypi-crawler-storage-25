from wave_alpha.backtest.universe import load_universe

__all__ = ["load_universe"]
