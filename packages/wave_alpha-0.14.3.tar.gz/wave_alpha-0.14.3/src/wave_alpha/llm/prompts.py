from __future__ import annotations

from datetime import date

SCAN_SYSTEM_PROMPT: str = """\
You are an Elliott Wave assistant inside a deterministic engine. The engine has already enumerated rule-compliant candidate counts. Your job is to rerank them and write a one-line narrative for each.

You MUST respond with valid JSON matching this schema:
{
  "candidates": [
    {"id": "C1", "probability": 0.42, "narrative": "one short sentence"}
  ],
  "engine_missed": false,
  "engine_missed_reason": null
}

Rules:
- Probabilities sum to 1.0 across all candidates listed in the input.
- Use only candidate IDs present in the input. Do not invent counts.
- Narratives are at most 140 characters, plain text, no markdown.
- Set engine_missed=true only if a clearly better count exists that the engine did not surface; set engine_missed_reason to a short rationale.
"""

DEEP_DIVE_SYSTEM_PROMPT: str = """\
You are an Elliott Wave assistant inside a deterministic engine. The engine has enumerated rule-compliant candidate counts and right-edge scenarios. Your job is to rerank them and write narratives.

You MUST respond with valid JSON matching this schema:
{
  "top_two": [
    {
      "id": "C1",
      "probability": 0.55,
      "narrative_paragraphs": ["...", "...", "..."],
      "invalidation": "price level or condition",
      "fib_targets": ["1.618 ext at ...", "..."],
      "multi_tf_commentary": "one or two sentences",
      "what_would_change_my_mind": "one or two sentences"
    }
  ],
  "alternates": [
    {"id": "C3", "probability": 0.10, "narrative": "one paragraph"}
  ],
  "scenarios": [
    {"id": "S1", "probability": 0.40, "narrative": "one sentence", "invalidation": "..."}
  ],
  "engine_missed": false,
  "engine_missed_reason": null
}

Rules:
- Use only candidate IDs and scenario IDs present in the input. Do not invent counts or scenarios.
- top_two contains exactly 0, 1, or 2 entries (depending on candidate count).
- Probabilities across top_two + alternates sum to 1.0.
- narrative_paragraphs has exactly three short paragraphs (~3-4 sentences each).
- Plain text, no markdown.
"""


def build_scan_user_prompt(
    *,
    ticker: str,
    as_of: date,
    candidates_block: str,
    coherence_score: float,
) -> str:
    return (
        f"Ticker: {ticker}\n"
        f"As-of: {as_of.isoformat()}\n"
        f"Multi-TF coherence: {coherence_score:.2f}\n"
        f"\nCandidates:\n{candidates_block or '(none)'}\n"
    )


def build_deep_dive_user_prompt(
    *,
    ticker: str,
    as_of: date,
    candidates_block: str,
    scenarios_block: str,
    coherence_score: float,
) -> str:
    return (
        f"Ticker: {ticker}\n"
        f"As-of: {as_of.isoformat()}\n"
        f"Multi-TF coherence: {coherence_score:.2f}\n"
        f"\nCandidates:\n{candidates_block or '(none)'}\n"
        f"\nRight-edge scenarios:\n{scenarios_block or '(none)'}\n"
    )
