from wave_alpha.scan.models import ScanReport, ScanRow

__all__ = ["ScanReport", "ScanRow"]
