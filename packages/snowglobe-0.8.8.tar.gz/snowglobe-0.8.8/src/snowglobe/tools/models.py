"""
Pydantic models for tool execution requests and responses.
"""

from typing import Any, Dict, List, Optional

from pydantic import BaseModel


class ToolSpec(BaseModel):
    """Tool spec metadata sent with batch tool execution requests."""

    tool_name: str
    description: Optional[str] = None
    input_schema: Dict[str, Any]
    output_schema: Optional[Dict[str, Any]] = None
    examples: Optional[List[Dict[str, Any]]] = None
    schema_source: Optional[str] = None


class ToolCall(BaseModel):
    """Tool call payload for batch execution."""

    tool_name: str
    arguments: Dict[str, Any]


class ToolExecutionsBatchRequest(BaseModel):
    """Request to create tool executions in batch."""

    test_id: str
    tool_calls: List[ToolCall]
    tool_specs: Optional[List[ToolSpec]] = None


class ToolExecutionCreated(BaseModel):
    """Tool execution created response item."""

    id: str
    tool_name: str


class ToolExecutionsBatchResponse(BaseModel):
    """Response from batch tool execution creation."""

    tool_executions: List[ToolExecutionCreated]
    timestamp: str


class ToolExecutionRecord(BaseModel):
    """Tool execution record returned by polling endpoint."""

    id: str
    test_id: str
    experiment_id: str
    tool_name: str
    tool_spec_id: Optional[str] = None
    arguments: Dict[str, Any]
    conversation_id: str
    tool_response: Optional[str] = None
    validation_status: Optional[str] = None
    validation_errors: Optional[List[Dict[str, Any]]] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None
