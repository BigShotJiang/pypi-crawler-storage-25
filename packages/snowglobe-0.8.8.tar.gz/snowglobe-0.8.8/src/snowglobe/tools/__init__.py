"""
Snowglobe Tools - Automatic Tool Mocking for Simulations

This module provides automatic tool mocking capabilities for Snowglobe simulations.
When running via `snowglobe-connect start`, tool calls are automatically mocked
using responses from Snowglobe servers.

Usage:
    from snowglobe.client import CompletionRequest, CompletionFunctionOutputs
    from snowglobe.tools import snowglobe_tool
    from openai import OpenAI
    import os
    import json
    client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

    # Register your tools
    TOOLS = [
        {
            "type": "function",
            "function": {
                "name": "get_weather",
                "parameters": {
                    "type": "object",
                    "description": "Get current weather",
                    "properties": {...},
                }
            }
        }
    ]

    def tool_defs():
        return TOOLS

    # Decorate tool functions
    @snowglobe_tool
    def get_weather(location: str) -> str:
        # This will be mocked when running via snowglobe-connect
        return weather_api.get(location)

    TOOLS_MAP = {
    "get_weather": get_weather,
    ...}

    def completion(request: CompletionRequest) -> CompletionFunctionOutputs:
        conversation_id = request.get_conversation_id()
        # get full conversation history from issues

        # Process the request using the messages. Example using OpenAI:
        messages = request.to_openai_messages(system_prompt="You are an expert customer support agent for Amattos Pizza Restaurant")

        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=messages,
            tools=TOOLS
        )

        while True:
            response = client.chat.completions.create(
                model="gpt-4o-mini",
                messages=messages,
                tools=TOOLS
            )
            message = response.choices[0].message

            if not message.tool_calls:
                return CompletionFunctionOutputs(response=message.content)

            messages.append(message)
            for tool_call in message.tool_calls:
                if tool_call.function.name not in TOOLS_MAP:
                    result = f"Error: Tool {tool_call.function.name} not found"
                else:
                    result = TOOLS_MAP[tool_call.function.name](**json.loads(tool_call.function.arguments))

                messages.append({
                    "role": "tool",
                    "tool_call_id": tool_call.id,
                    "content": str(result)
                })
"""

from .decorator import snowglobe_tool
from .registry import register_tools

__all__ = ["register_tools", "snowglobe_tool"]
