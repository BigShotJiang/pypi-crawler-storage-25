# Set up the scheduler
import asyncio
import datetime
import importlib.util
import json
import logging
import os
import sys
import time
import traceback
from collections import defaultdict, deque
from contextlib import asynccontextmanager
from functools import wraps
from logging import getLogger
from typing import Awaitable, Callable, Dict, Optional, Union
from urllib.parse import quote_plus
import uuid

import httpx
import uvicorn
from apscheduler import AsyncScheduler
from apscheduler.triggers.interval import IntervalTrigger
from fastapi import FastAPI, HTTPException, Request

from .cli_utils import console, info, show_session_summary, shutdown_manager, success
from .config import build_auth_headers, config
from .models import (
    CompletionFunctionOutputs,
    CompletionRequest,
    RiskEvaluationRequest,
    RiskEvaluationOutputs,
    SnowglobeData,
    SnowglobeMessage,
)
from .stats import initialize_stats, track_batch_completion
from .telemetry import trace_completion_fn, trace_risk_evaluation_fn
from .utils import fetch_experiments, fetch_messages
from snowglobe.tools.registry import get_registered_tool_specs, register_tools
from snowglobe.http_retry import (
    HttpRetryPolicy,
    async_request_with_retries,
    build_retry_policy,
)

try:
    import mlflow  # type: ignore
except ImportError:
    mlflow = None

# Configure logging - check DEBUG from environment directly to avoid config initialization
if os.getenv("DEBUG", "false").lower() == "true":
    logging.basicConfig(
        handlers=[logging.StreamHandler()],
        level=os.getenv("LOG_LEVEL", "DEBUG").upper(),
    )
else:
    logging.basicConfig(
        handlers=[logging.StreamHandler()],
    )

LOGGER = getLogger("snowglobe_client")
# Allow LOG_LEVEL environment variable to override default INFO level
LOGGER.setLevel(getattr(logging, os.getenv("LOG_LEVEL", "INFO").upper()))

# In-memory storage for rate limiting per route
route_request_times = defaultdict(lambda: defaultdict(deque))


class ConfigurableRateLimiter:
    def __init__(self):
        self.route_configs = {}

    def configure_route(self, route_key: str, max_requests: int, time_window: int):
        """Configure rate limiting for a specific route"""
        self.route_configs[route_key] = {
            "max_requests": max_requests,
            "time_window": time_window,
        }

    def is_allowed(self, client_id: str, route_key: str) -> bool:
        # Get route configuration or use default
        config = self.route_configs.get(
            route_key, {"max_requests": 1, "time_window": 1}
        )
        max_requests = config["max_requests"]
        time_window = config["time_window"]

        now = time.time()
        client_requests = route_request_times[route_key][client_id]

        # Remove old requests outside the time window
        while client_requests and client_requests[0] <= now - time_window:
            client_requests.popleft()

        # Check if client has exceeded rate limit for this route
        if len(client_requests) >= max_requests:
            return False

        # Add current request time
        client_requests.append(now)
        return True

    def get_route_config(self, route_key: str) -> Dict[str, int]:
        """Get the configuration for a specific route"""
        return self.route_configs.get(route_key, {"max_requests": 1, "time_window": 1})


# Create global rate limiter instance
rate_limiter = ConfigurableRateLimiter()


def rate_limit(route_name: str, max_requests: int = 1, time_window: int = 1):
    """Decorator for per-route rate limiting with configurable limits"""

    def decorator(func):
        # Configure the route when decorator is applied
        rate_limiter.configure_route(route_name, max_requests, time_window)

        @wraps(func)
        async def wrapper(request: Request, *args, **kwargs):
            client_ip = request.client.host

            if not rate_limiter.is_allowed(client_ip, route_name):
                config = rate_limiter.get_route_config(route_name)
                raise HTTPException(
                    status_code=429,
                    detail=f"Rate limit exceeded for route '{route_name}'. Maximum {config['max_requests']} requests per {config['time_window']} seconds.",
                )

            return await func(request, *args, **kwargs)

        return wrapper

    return decorator


queued_tests = {}
queued_evaluations = {}
risks: Dict[
    str,
    Union[
        Callable[[RiskEvaluationRequest], RiskEvaluationOutputs],
        Callable[[RiskEvaluationRequest], Awaitable[RiskEvaluationOutputs]],
    ],
] = {}
apps = {}
selected_agent_uuids = None  # Set by start_client to filter which agents to load
uploaded_tool_specs_experiments = set()

HTTP_RETRY_POLICY: HttpRetryPolicy = build_retry_policy(logger=LOGGER)
HTTP_RETRY_ATTEMPTS = HTTP_RETRY_POLICY.attempts
COMPLETION_DISPATCH_CONCURRENCY = int(
    os.getenv(
        "SNOWGLOBE_COMPLETION_DISPATCH_CONCURRENCY",
        str(config.COMPLETION_BATCH_SIZE),
    )
)
INFLIGHT_TEST_TTL_SECONDS = int(
    os.getenv(
        "SNOWGLOBE_INFLIGHT_TEST_TTL_SECONDS",
        str(max(config.REQUEST_TIMEOUT_SECONDS * 2, 600)),
    )
)


def _mark_test_inflight(test_id: str) -> None:
    queued_tests[test_id] = time.time()


def _clear_test_inflight(test_id: str) -> None:
    queued_tests.pop(test_id, None)


async def _request_with_retries(
    client: httpx.AsyncClient,
    method: str,
    url: str,
    *,
    retry_attempts: int = HTTP_RETRY_ATTEMPTS,
    **kwargs,
) -> httpx.Response:
    return await async_request_with_retries(
        client,
        method,
        url,
        policy=HTTP_RETRY_POLICY.with_attempts(retry_attempts),
        logger=LOGGER,
        **kwargs,
    )


def _is_test_inflight(test_id: str) -> bool:
    started_at = queued_tests.get(test_id)
    if started_at is None:
        return False

    age_seconds = time.time() - started_at
    if age_seconds <= INFLIGHT_TEST_TTL_SECONDS:
        return True

    LOGGER.warning(
        "Clearing stale in-flight test marker for %s after %.1fs (ttl=%ss)",
        test_id,
        age_seconds,
        INFLIGHT_TEST_TTL_SECONDS,
    )
    _clear_test_inflight(test_id)
    return False


async def _dispatch_completion_request(
    client: httpx.AsyncClient,
    test: dict,
    app_id: str,
    simulation_name: str,
) -> bool:
    test_id = test["id"]
    _mark_test_inflight(test_id)
    completion_url = f"{config.SNOWGLOBE_CLIENT_URL}/completion"

    try:
        completion_request = await _request_with_retries(
            client,
            "POST",
            completion_url,
            retry_attempts=1,
            json={
                "test": test,
                "app_id": app_id,
                "simulation_name": simulation_name,
            },
            timeout=config.REQUEST_TIMEOUT_SECONDS,
        )
    except httpx.ConnectError as e:
        # Connection failures likely mean the local endpoint never accepted the request.
        _clear_test_inflight(test_id)
        if shutdown_manager.is_shutdown_requested():
            LOGGER.debug("HTTP error during shutdown (expected): %s", e)
            return False
        raise RuntimeError(
            f"Connection error posting completion for test {test_id}: {e}"
        ) from e
    except httpx.TimeoutException as e:
        # Clear the in-flight marker so this test can be retried promptly.
        _clear_test_inflight(test_id)
        if shutdown_manager.is_shutdown_requested():
            LOGGER.debug("HTTP timeout during shutdown (expected): %s", e)
            return False
        raise RuntimeError(
            "Timed out posting completion for test "
            f"{test_id} after {config.REQUEST_TIMEOUT_SECONDS}s: {e}"
        ) from e
    except Exception as e:
        _clear_test_inflight(test_id)
        raise RuntimeError(
            f"Unexpected completion post error for test {test_id}: {e}"
        ) from e

    if not completion_request.is_success and completion_request.status_code == 429:
        # The request was rejected immediately, so clear in-flight marker.
        _clear_test_inflight(test_id)
        LOGGER.warning(
            "Completion rate limit exceeded for test %s: %s",
            test_id,
            completion_request.text,
        )
        raise HTTPException(
            status_code=429,
            detail=f"Rate limit exceeded for test {test_id}",
        )

    if not completion_request.is_success:
        _clear_test_inflight(test_id)
        raise RuntimeError(
            "Completion request failed for test "
            f"{test_id} with status {completion_request.status_code}: "
            f"{completion_request.text}"
        )

    return True


# --- Queue-based dispatch state ---
# Shared semaphore controlling the number of concurrent dispatch lanes.
# Initialized lazily in poll_for_completions on first use.
_dispatch_semaphore: Optional[asyncio.Semaphore] = None
# Shared httpx client for dispatch tasks. Kept open across poll ticks.
_dispatch_client: Optional[httpx.AsyncClient] = None
# Set of in-flight dispatch tasks for graceful drain on shutdown.
_pending_dispatch_tasks: set = set()

# Time-windowed reporting: accumulate completion counts per experiment
# and emit a summary every REPORT_INTERVAL_TICKS poll ticks.
REPORT_INTERVAL_TICKS = int(os.getenv("SNOWGLOBE_REPORT_INTERVAL_TICKS", "15"))
completion_report_window: Dict[str, int] = {}
poll_tick_counter: int = 0

# Track experiments we've seen as active so we can detect terminal transitions.
_known_active_experiments: Dict[str, str] = {}  # experiment_id -> experiment_name
_terminal_transitions: Dict[str, str] = {}  # experiment_id -> experiment_name


async def _dispatch_completion_with_limit(
    semaphore: asyncio.Semaphore,
    client: httpx.AsyncClient,
    test: dict,
    app_id: str,
    simulation_name: str,
) -> bool:
    async with semaphore:
        return await _dispatch_completion_request(client, test, app_id, simulation_name)


def _record_completion(experiment_name: str) -> None:
    """Record a successful completion in the reporting window."""
    completion_report_window[experiment_name] = (
        completion_report_window.get(experiment_name, 0) + 1
    )


def _maybe_emit_report() -> None:
    """Emit and clear the reporting window if the interval has elapsed."""
    global poll_tick_counter
    poll_tick_counter += 1

    if poll_tick_counter < REPORT_INTERVAL_TICKS:
        return
    poll_tick_counter = 0

    timestamp = datetime.datetime.now().strftime("%H:%M:%S")
    total_completions = sum(completion_report_window.values())
    inflight_count = len(queued_tests)

    # Report experiments that transitioned to a terminal state.
    if _terminal_transitions:
        for exp_id, exp_name in _terminal_transitions.items():
            if LOGGER.level <= logging.INFO:
                LOGGER.info(
                    "Experiment %s (%s) reached terminal state", exp_name, exp_id
                )
            else:
                info(f"[{timestamp}] 🏁 Experiment '{exp_name}' completed")
        _terminal_transitions.clear()

    if total_completions > 0:
        for experiment_name, count in completion_report_window.items():
            if count > 0:
                if LOGGER.level <= logging.INFO:
                    LOGGER.info(
                        "Processed %s completions for experiment %s",
                        count,
                        experiment_name,
                    )
                else:
                    inflight_suffix = (
                        f", {inflight_count} in flight" if inflight_count > 0 else ""
                    )
                    info(
                        f"[{timestamp}] ✓ {count} responses sent ({experiment_name}){inflight_suffix}"
                    )
                    track_batch_completion(experiment_name, count)
        completion_report_window.clear()
    elif inflight_count > 0:
        if LOGGER.level <= logging.INFO:
            LOGGER.info(
                "%s test(s) still in flight",
                inflight_count,
            )
        else:
            info(f"[{timestamp}] ⏳ {inflight_count} test(s) in flight")


async def _fire_and_forget_dispatch(
    semaphore: asyncio.Semaphore,
    client: httpx.AsyncClient,
    test: dict,
    app_id: str,
    simulation_name: str,
) -> None:
    """Dispatch a single test as a fire-and-forget task, gated by the semaphore."""
    try:
        async with semaphore:
            result = await _dispatch_completion_request(
                client, test, app_id, simulation_name
            )
            if result:
                _record_completion(simulation_name)
    except HTTPException as e:
        if e.status_code == 429:
            LOGGER.warning("Rate limited during dispatch for test %s", test["id"])
        else:
            LOGGER.error("HTTP error dispatching test %s: %s", test["id"], e)
    except Exception as e:
        LOGGER.error("Error dispatching completion for test %s: %s", test["id"], e)


async def _upsert_tool_specs_for_experiment(
    client: httpx.AsyncClient, experiment_id: str, app_id: str
) -> None:
    if experiment_id in uploaded_tool_specs_experiments:
        return

    tool_specs = get_registered_tool_specs(app_id)
    if not tool_specs:
        LOGGER.warning(
            "No registered tools for experiment. "
            "Please use register_tools or def tool_defs in your agent.py"
            " to register tools for your application.",
            experiment_id,
        )
        return

    response = await _request_with_retries(
        client,
        "POST",
        f"{config.CONTROL_PLANE_URL}/api/experiments/{experiment_id}/tool-specs",
        json={"tool_specs": tool_specs},
        headers=build_auth_headers(),
    )
    if not response.is_success:
        LOGGER.error(
            "Failed to upsert tool specs for experiment %s: %s",
            experiment_id,
            response.text,
        )
        return

    uploaded_tool_specs_experiments.add(experiment_id)
    LOGGER.info(
        "Upserted %s tool specs for experiment %s",
        len(tool_specs),
        experiment_id,
    )


async def process_application_heartbeat(app_id):
    from snowglobe.client.src.runner import run_completion_fn

    connection_test_payload = {
        "appId": app_id,
    }
    try:
        prompt = "Hello from Snowglobe!"
        heartbeat_conversation_id = str(uuid.uuid4())
        heartbeat_test_id = str(uuid.uuid4())
        simulation_id = str(uuid.uuid4())
        test_request = CompletionRequest(
            messages=[
                SnowglobeMessage(
                    role="user",
                    content=prompt,
                    snowglobe_data=SnowglobeData(
                        conversation_id=heartbeat_conversation_id,
                        test_id=heartbeat_test_id,
                        simulation_id=simulation_id,
                    ),
                )
            ]
        )
        heartbeat_id = uuid.uuid4().hex
        agent = apps.get(app_id, {})
        agent_name = agent.get("name", "")
        completion_fn = agent.get("completion_fn")
        if not completion_fn:
            LOGGER.warning(
                f"No completion function found for application {app_id}. Skipping heartbeat."
            )
            return

        # TODO: Remove in v0.5.0
        disable_mlflow = os.getenv("SNOWGLOBE_DISABLE_MLFLOW_TRACING") or ""
        if (
            mlflow is not None
            and disable_mlflow.lower() != "true"
            and not hasattr(run_completion_fn, "__instrumented_by_mlflow")
        ):
            LOGGER.warning(
                """
Automatic instrumentation for MLflow is deprecated and will be removed in snowglobe 0.5.x. Use the MLflowInstrumentor from snowglobe-telemetry-mlflow if you wish to maintain the same functionality.

```sh
pip install snowglobe-telemetry-mlflow
```
                           
```py                    
from snowglobe.telemetry.mlflow import MLflowInstrumentor
MLflowInstrumentor.instrument()
```
"""
            )
            response = await trace_completion_fn(
                agent_name=agent_name,
                conversation_id=heartbeat_id,
                message_id=heartbeat_id,
                session_id=heartbeat_id,
                simulation_name=f"{agent_name} Heartbeat",
                span_type="snowglobe/heartbeat",
            )(run_completion_fn)(
                completion_fn=completion_fn,
                completion_request=test_request,
                telemetry_context={
                    "agent_name": agent_name,
                    "conversation_id": heartbeat_id,
                    "message_id": heartbeat_id,
                    "session_id": heartbeat_id,
                    "simulation_name": f"{agent_name} Heartbeat",
                    "span_type": "snowglobe/heartbeat",
                },
                enable_tool_mocking=False,
            )
        else:
            response = await run_completion_fn(
                completion_fn=completion_fn,
                completion_request=test_request,
                app_id=app_id,
                telemetry_context={
                    "agent_name": agent_name,
                    "conversation_id": heartbeat_id,
                    "message_id": heartbeat_id,
                    "session_id": heartbeat_id,
                    "simulation_name": f"{agent_name} Heartbeat",
                    "span_type": "snowglobe/heartbeat",
                },
                enable_tool_mocking=False,
            )
        if not isinstance(response, CompletionFunctionOutputs):
            LOGGER.error(
                f"Completion function for application {app_id} did not return a valid response. Expected CompletionFunctionOutputs, got {type(response)}"
            )
            connection_test_payload["status"] = "failed"
            connection_test_payload["error"] = (
                "Completion function did not return a valid response. "
                "Expected CompletionFunctionOutputs, got {type(response)}"
            )

        if not hasattr(response, "response") or not isinstance(response.response, str):
            LOGGER.error(
                f"Completion function for application {app_id} did not return a valid response. Expected a string, got {type(response.response)}"
            )
            connection_test_payload["status"] = "failed"
            connection_test_payload[
                "error"
            ] = "Completion function did not return a valid response. Expected a string, got {type(response.response)}"

        if response.response == "This is a string response from your application":
            LOGGER.error(
                f"Completion function for application {app_id} returned a default response. This indicates the application is not properly connected."
            )
            connection_test_payload["status"] = "failed"
            connection_test_payload[
                "error"
            ] = "Completion function returned a default response. "

        if connection_test_payload.get("status") != "failed":
            connection_test_payload["response"] = response.response
            connection_test_payload["prompt"] = prompt

    except Exception as e:
        connection_test_payload["status"] = "failed"
        connection_test_payload["error"] = f"{str(e)}\n{traceback.format_exc()}"
        connection_test_payload["app_id"] = app_id
        connection_test_payload["applicationId"] = app_id
        LOGGER.error(
            f"Error processing heartbeat for application {app_id}: {connection_test_payload['error']}"
        )
        LOGGER.error(traceback.format_exc())

    connection_test_url = (
        f"{config.CONTROL_PLANE_URL}/api/successful-code-connection-tests"
    )

    if connection_test_payload.get("status") == "failed":
        connection_test_url = (
            f"{config.CONTROL_PLANE_URL}/api/failed-code-connection-tests"
        )

    async with httpx.AsyncClient() as client:
        LOGGER.info(
            f"Posting code connection test for application {app_id} connection_test_payload: {connection_test_payload}"
        )
        connection_test_response = await client.post(
            connection_test_url,
            json=connection_test_payload,
            headers=build_auth_headers(),
        )

    if not connection_test_response.is_success:
        LOGGER.error(
            f"Error posting code connection test for application {app_id}: {connection_test_response.text}"
        )
    return connection_test_response.json()


async def process_risk_evaluation(test, risk_name, simulation_name, agent_name):
    """finds correct risk and calls the risk evaluation function and creates a risk evaluation for the test"""
    from snowglobe.client.src.runner import run_risk_evaluation_fn

    start = time.time()

    messages = await fetch_messages(test=test)

    risk_eval_req = RiskEvaluationRequest(messages=messages)

    risk_eval_fn = risks[risk_name]

    # TODO: Remove in v0.5.0
    disable_mlflow = os.getenv("SNOWGLOBE_DISABLE_MLFLOW_TRACING") or ""
    if (
        mlflow is not None
        and disable_mlflow.lower() != "true"
        and not hasattr(run_risk_evaluation_fn, "__instrumented_by_mlflow")
    ):
        LOGGER.warning(
            """
Automatic instrumentation for MLflow is deprecated and will be removed in snowglobe 0.5.x. Use the MLflowInstrumentor from snowglobe-telemetry-mlflow if you wish to maintain the same functionality.

```sh
pip install snowglobe-telemetry-mlflow
```
                           
```py                    
from snowglobe.telemetry.mlflow import MLflowInstrumentor
MLflowInstrumentor.instrument()
```
"""
        )
        risk_evaluation = await trace_risk_evaluation_fn(
            agent_name=agent_name,
            conversation_id=test["conversation_id"],
            message_id=test["id"],
            session_id=test["conversation_id"],
            simulation_name=simulation_name,
            span_type=f"snowglobe/risk-evaluation/{risk_name}",
            risk_name=risk_name,
        )(run_risk_evaluation_fn)(
            risk_evaluation_fn=risk_eval_fn,
            risk_evaluation_request=risk_eval_req,
            telemetry_context={
                "agent_name": agent_name,
                "conversation_id": test["conversation_id"],
                "message_id": test["id"],
                "session_id": test["conversation_id"],
                "simulation_name": simulation_name,
                "span_type": f"snowglobe/risk-evaluation/{risk_name}",
                "risk_name": risk_name,
            },
        )
    else:
        risk_evaluation = await run_risk_evaluation_fn(
            risk_evaluation_fn=risk_eval_fn,
            risk_evaluation_request=risk_eval_req,
            telemetry_context={
                "agent_name": agent_name,
                "conversation_id": test["conversation_id"],
                "message_id": test["id"],
                "session_id": test["conversation_id"],
                "simulation_name": simulation_name,
                "span_type": f"snowglobe/risk-evaluation/{risk_name}",
                "risk_name": risk_name,
            },
        )
    LOGGER.debug(f"Risk evaluation output: {risk_evaluation}")

    # Extract fields from risk_evaluation object
    severity = getattr(risk_evaluation, "severity", "")
    reason = getattr(risk_evaluation, "reason", "")
    risk_triggered = getattr(risk_evaluation, "triggered", "")

    response_xml = (
        f"<risk>"
        f"<name>{risk_name}</name>"
        f"<severity>{severity}</severity>"
        f"<reason>{reason}</reason>"
        f"<risk_triggered>{risk_triggered}</risk_triggered>"
        f"</risk>"
    )

    # Post a Risk Evaluation (async)
    async with httpx.AsyncClient() as client:
        risk_evaluation_response = await client.post(
            f"{config.CONTROL_PLANE_URL}/api/experiments/{test['experiment_id']}/tests/{test['id']}/evaluations",
            json={
                "test_id": test["id"],
                "judge_prompt": "",  # does this need to be set?
                "judge_response": response_xml,
                "risk_type": risk_name,
                "risk_triggered": risk_evaluation.triggered,
            },
            headers=build_auth_headers(),
        )
    LOGGER.debug(f"Time taken: {time.time() - start} seconds")
    if not risk_evaluation_response.is_success:
        LOGGER.error("Error posting risk evaluation", risk_evaluation_response.text)
        raise Exception("Error posting risk evaluation, task is not healthy")


async def process_test(test, completion_fn, app_id, simulation_name):
    """Processes a test by converting it to OpenAI style messages and calling the completion function"""
    start = time.time()
    from snowglobe.client.src.runner import run_completion_fn

    try:
        if not test["prompt"]:
            LOGGER.info(f"Test {test['id']} has no prompt yet, skipping processing.")
            return
        # convert test to openai style messages
        messages = await fetch_messages(test=test)

        agent = apps.get(app_id, {})
        agent_name = agent.get("name", "")

        completion_req = CompletionRequest(messages=messages)

        # TODO: Remove in v0.5.0
        disable_mlflow = os.getenv("SNOWGLOBE_DISABLE_MLFLOW_TRACING") or ""
        if (
            mlflow is not None
            and disable_mlflow.lower() != "true"
            and not hasattr(run_completion_fn, "__instrumented_by_mlflow")
        ):
            LOGGER.warning(
                """
Automatic instrumentation for MLflow is deprecated and will be removed in snowglobe 0.5.x. Use the MLflowInstrumentor from snowglobe-telemetry-mlflow if you wish to maintain the same functionality.

```sh
pip install snowglobe-telemetry-mlflow
```
                           
```py                    
from snowglobe.telemetry.mlflow import MLflowInstrumentor
MLflowInstrumentor.instrument()
```
"""
            )
            completionOutput = await trace_completion_fn(
                agent_name=agent_name,
                conversation_id=test["conversation_id"],
                message_id=test["id"],
                session_id=test["conversation_id"],
                simulation_name=simulation_name,
                span_type="snowglobe/completion",
            )(run_completion_fn)(
                completion_fn=completion_fn,
                completion_request=completion_req,
                telemetry_context={
                    "agent_name": agent_name,
                    "conversation_id": test["conversation_id"],
                    "message_id": test["id"],
                    "session_id": test["conversation_id"],
                    "simulation_name": simulation_name,
                    "span_type": "snowglobe/completion",
                },
            )
        else:
            completionOutput = await run_completion_fn(
                completion_fn=completion_fn,
                completion_request=completion_req,
                app_id=app_id,
                telemetry_context={
                    "agent_name": agent_name,
                    "conversation_id": test["conversation_id"],
                    "message_id": test["id"],
                    "session_id": test["conversation_id"],
                    "simulation_name": simulation_name,
                    "span_type": "snowglobe/completion",
                },
            )

        LOGGER.debug(f"Completion output: {completionOutput}")
        response_text = completionOutput.response
        if not isinstance(response_text, str) or not response_text.strip():
            raise RuntimeError(
                "Completion output for test "
                f"{test['id']} is empty. Refusing to persist a blank response."
            )

        async with httpx.AsyncClient() as client:
            update_response = await _request_with_retries(
                client,
                "PUT",
                f"{config.CONTROL_PLANE_URL}/api/experiments/{test['experiment_id']}/tests/{test['id']}",
                json={
                    "id": test["id"],
                    "appId": app_id,
                    "prompt": test["prompt"],
                    "response": response_text,
                    "persona": test["persona"],
                },
                headers=build_auth_headers(),
                timeout=config.REQUEST_TIMEOUT_SECONDS,
            )
        if not update_response.is_success:
            raise RuntimeError(
                f"Failed to update test {test['id']} response: "
                f"{update_response.status_code} {update_response.text}"
            )
        LOGGER.debug(f"Time taken: {time.time() - start} seconds")
        return completionOutput
    finally:
        # Always clear in-flight marker even when completion processing fails.
        _clear_test_inflight(test["id"])


# The task to run — acts as a producer that discovers new tests and fires off
# dispatch tasks gated by a shared semaphore.  Does NOT wait for dispatches
# to complete (fire-and-forget), so the next poll tick can start promptly.
async def poll_for_completions():
    global _dispatch_semaphore, _dispatch_client

    # Exit early if shutdown requested
    if await shutdown_manager.is_async_shutdown_requested():
        return

    job_id = "poll_for_completions"

    if len(apps) == 0:
        LOGGER.warning("No applications found. Skipping completions check.")
        return

    # Register this job as active
    shutdown_manager.register_active_job(job_id)

    # Lazily initialise the shared semaphore and httpx client.
    if _dispatch_semaphore is None:
        _dispatch_semaphore = asyncio.Semaphore(max(1, COMPLETION_DISPATCH_CONCURRENCY))
    if _dispatch_client is None:
        _dispatch_client = httpx.AsyncClient()

    try:
        # Fetch experiments for each registered app_id
        experiments = []
        app_ids = list(apps.keys())

        if app_ids:
            # Make serial requests for each app_id
            for app_id in app_ids:
                try:
                    app_experiments = await fetch_experiments(app_id=app_id)
                    experiments.extend(app_experiments)
                except Exception as e:
                    LOGGER.error(f"Error fetching experiments for app_id {app_id}: {e}")
                    # Continue with other app_ids even if one fails
                    continue
        else:
            # Fallback to config.APPLICATION_ID if no apps loaded
            if config.APPLICATION_ID:
                experiments = await fetch_experiments(app_id=config.APPLICATION_ID)
            else:
                # No app_ids specified, fetch all experiments without filtering
                experiments = await fetch_experiments()
    except Exception as e:
        # Handle shutdown-related connection errors gracefully
        if shutdown_manager.is_shutdown_requested():
            LOGGER.debug(f"Connection error during shutdown (expected): {e}")
            return
        else:
            LOGGER.error(f"Error fetching experiments: {e}")
            raise
    finally:
        shutdown_manager.unregister_active_job(job_id)

    try:
        client = _dispatch_client
        LOGGER.info("Polling %s experiments for completions...", len(experiments))

        for experiment in experiments:
            if await shutdown_manager.is_async_shutdown_requested():
                LOGGER.debug("Shutdown requested, stopping completions polling")
                return

            app_id = experiment.get("app_id")
            if app_id not in apps:
                LOGGER.debug(
                    "Skipping experiment as we do not have a completion function for app_id: %s",
                    app_id,
                )
                continue
            experiment_id = experiment["id"]

            try:
                experiment_request = await _request_with_retries(
                    client,
                    "GET",
                    f"{config.CONTROL_PLANE_URL}/api/experiments/{experiment_id}?appId={app_id}",
                    headers=build_auth_headers(),
                )
            except (httpx.ConnectError, httpx.TimeoutException) as e:
                if shutdown_manager.is_shutdown_requested():
                    LOGGER.debug("HTTP error during shutdown (expected): %s", e)
                    return
                LOGGER.error(
                    "Connection error fetching experiment %s: %s",
                    experiment_id,
                    e,
                )
                continue

            if not experiment_request.is_success:
                LOGGER.error(
                    "Error fetching experiment %s: %s",
                    experiment_id,
                    experiment_request.text,
                )
                continue
            experiment = experiment_request.json()

            if experiment.get("state_num", -1) >= 17:
                LOGGER.debug(
                    "Skipping experiment %s as it is already in terminal state",
                    experiment_id,
                )
                # If we previously saw this experiment as active, record the transition.
                if experiment_id in _known_active_experiments:
                    exp_name = _known_active_experiments.pop(experiment_id)
                    _terminal_transitions[experiment_id] = exp_name
                continue

            # Track this experiment as active (so we can detect when it finishes).
            exp_name = experiment.get("name") or experiment_id
            _known_active_experiments[experiment_id] = exp_name

            try:
                source_data = experiment.get("source_data", {})
                experiment_mode = source_data.get("mode", "STANDARD")
                if "USER_AGENT" in experiment_mode:
                    LOGGER.debug(
                        "Experiment %s is in USER_AGENT mode, upserting tool specs",
                        experiment_id,
                    )
                    await _upsert_tool_specs_for_experiment(
                        client, experiment_id, app_id
                    )
                else:
                    LOGGER.debug(
                        "Experiment %s is not in a USER_AGENT mode, skipping tool spec upsert",
                        experiment_id,
                    )
            except Exception as e:
                LOGGER.error(
                    "Error upserting tool specs for experiment %s: %s",
                    experiment_id,
                    e,
                )
                continue

            limit = config.COMPLETION_BATCH_SIZE
            LOGGER.debug("Checking for tests for experiment %s", experiment_id)

            try:
                tests_response = await _request_with_retries(
                    client,
                    "GET",
                    f"{config.CONTROL_PLANE_URL}/api/experiments/{experiment_id}/tests?appId={app_id}&include-risk-evaluations=false&limit={limit}&unprocessed-only=true",
                    headers=build_auth_headers(),
                )
            except (httpx.ConnectError, httpx.TimeoutException) as e:
                if shutdown_manager.is_shutdown_requested():
                    LOGGER.debug("HTTP error during shutdown (expected): %s", e)
                    return
                LOGGER.error("Connection error fetching tests: %s", e)
                continue

            if not tests_response.is_success:
                LOGGER.error("Error fetching tests: %s", tests_response.text)
                continue

            tests = tests_response.json()
            for test in tests:
                if await shutdown_manager.is_async_shutdown_requested():
                    LOGGER.debug("Shutdown requested, stopping test processing")
                    return

                if test.get("response"):
                    continue

                test_id = test["id"]
                if _is_test_inflight(test_id):
                    LOGGER.debug("Skipping in-flight test %s", test_id)
                    continue
                # if test has last error skip it to avoid completion loops
                if test.get("last_error", ""):
                    LOGGER.info(
                        "Skipping test %s with last error: %s",
                        test_id,
                        test.get("last_error", {}).get(
                            "user_message", "Unknown error."
                        ),
                    )
                    continue

                LOGGER.debug(
                    "Dispatching test %s for experiment %s", test_id, experiment_id
                )

                # Fire-and-forget: create a background task gated by the semaphore.
                # The task handles its own errors and records completions for
                # time-windowed reporting.  Tracked so lifespan can drain on shutdown.
                task = asyncio.create_task(
                    _fire_and_forget_dispatch(
                        _dispatch_semaphore,
                        client,
                        test,
                        app_id,
                        experiment.get("name", "unknown"),
                    )
                )
                _pending_dispatch_tasks.add(task)
                task.add_done_callback(_pending_dispatch_tasks.discard)

        # Time-windowed reporting: bump tick counter and maybe emit report.
        _maybe_emit_report()

    except Exception as e:
        # Handle any other errors
        if shutdown_manager.is_shutdown_requested():
            LOGGER.debug(f"Error during shutdown (expected): {e}")
        else:
            LOGGER.error(f"Unexpected error in poll_for_completions: {e}")
            raise


async def process_application_heartbeats():
    # Exit early if shutdown requested
    if await shutdown_manager.is_async_shutdown_requested():
        return

    job_id = "process_application_heartbeats"
    shutdown_manager.register_active_job(job_id)

    try:
        connection_test_count = 0
        LOGGER.info("Processing application heartbeats...")
        async with httpx.AsyncClient() as client:
            for app_id, app_info in apps.items():
                # Check for shutdown between each heartbeat
                if await shutdown_manager.is_async_shutdown_requested():
                    LOGGER.debug("Shutdown requested, stopping heartbeats")
                    return

                try:
                    connection_test_request = await client.post(
                        f"{config.SNOWGLOBE_CLIENT_URL}/heartbeat",
                        json={"app_id": app_id},
                        timeout=30,
                    )
                except (httpx.ConnectError, httpx.TimeoutException) as e:
                    if shutdown_manager.is_shutdown_requested():
                        LOGGER.debug(f"HTTP error during shutdown (expected): {e}")
                        return
                    else:
                        LOGGER.error(
                            f"Connection error sending heartbeat for {app_id}: {e}"
                        )
                        continue

                if not connection_test_request.is_success:
                    LOGGER.error(
                        f"Error sending heartbeat for application {app_id}: {connection_test_request.text}"
                    )
                    continue
                connection_test_count += 1

        LOGGER.info(f"Processed {connection_test_count} heartbeats for applications.")
    finally:
        shutdown_manager.unregister_active_job(job_id)


async def poll_for_risk_evaluations():
    """Poll for risk evaluations and process them."""
    # Exit early if shutdown requested
    if await shutdown_manager.is_async_shutdown_requested():
        return

    job_id = "poll_for_risk_evaluations"
    shutdown_manager.register_active_job(job_id)

    try:
        # Fetch experiments for each registered app_id
        experiments = []
        app_ids = list(apps.keys())

        if app_ids:
            # Make serial requests for each app_id
            for app_id in app_ids:
                try:
                    app_experiments = await fetch_experiments(app_id=app_id)
                    experiments.extend(app_experiments)
                except Exception as e:
                    LOGGER.error(f"Error fetching experiments for app_id {app_id}: {e}")
                    # Continue with other app_ids even if one fails
                    continue
        else:
            # Fallback to config.APPLICATION_ID if no apps loaded
            if config.APPLICATION_ID:
                experiments = await fetch_experiments(app_id=config.APPLICATION_ID)
            else:
                # No app_ids specified, fetch all experiments without filtering
                experiments = await fetch_experiments()
    except Exception as e:
        # Handle shutdown-related connection errors gracefully
        if shutdown_manager.is_shutdown_requested():
            LOGGER.debug(f"Connection error during shutdown (expected): {e}")
            return
        else:
            LOGGER.error(f"Error fetching experiments: {e}")
            raise
    finally:
        shutdown_manager.unregister_active_job(job_id)

    try:
        LOGGER.info("Checking for pending risk evaluations...")
        LOGGER.debug(
            f"Found {len(experiments)} experiments with validation in progress"
        )

        async with httpx.AsyncClient() as client:
            for experiment in experiments:
                # Check for shutdown between experiments
                if await shutdown_manager.is_async_shutdown_requested():
                    LOGGER.debug("Shutdown requested, stopping risk evaluations")
                    return

                try:
                    experiment_request = await client.get(
                        f"{config.CONTROL_PLANE_URL}/api/experiments/{experiment['id']}",
                        headers=build_auth_headers(),
                    )
                except (httpx.ConnectError, httpx.TimeoutException) as e:
                    if shutdown_manager.is_shutdown_requested():
                        LOGGER.debug(f"HTTP error during shutdown (expected): {e}")
                        return
                    else:
                        LOGGER.error(
                            f"Connection error fetching experiment {experiment['id']}: {e}"
                        )
                        continue

                if not experiment_request.is_success:
                    LOGGER.error(
                        f"Error fetching experiment {experiment['id']}: {experiment_request.text}"
                    )
                    continue
                experiment = experiment_request.json()

                try:
                    app_request = await client.get(
                        f"{config.CONTROL_PLANE_URL}/api/applications/{experiment['app_id']}",
                        headers=build_auth_headers(),
                    )
                except (httpx.ConnectError, httpx.TimeoutException) as e:
                    if shutdown_manager.is_shutdown_requested():
                        LOGGER.debug(f"HTTP error during shutdown (expected): {e}")
                        return
                    else:
                        LOGGER.error(
                            f"Connection error fetching application {experiment['app_id']}: {e}"
                        )
                        continue

                app_name = experiment["app_id"]
                if not app_request.is_success:
                    LOGGER.error(
                        f"Error fetching application {experiment['app_id']}: {app_request.text}"
                    )
                else:
                    application = app_request.json()
                    app_name = application["name"]

                risk_eval_count = 0

                for risk_name in risks.keys():
                    # Check for shutdown before processing each risk
                    if await shutdown_manager.is_async_shutdown_requested():
                        LOGGER.debug("Shutdown requested, stopping risk processing")
                        return

                    try:
                        if (
                            risk_name
                            not in experiment.get("source_data", {})
                            .get("evaluation_configuration", {})
                            .keys()
                        ):
                            LOGGER.debug(
                                f"Skipping experiment {experiment['id']} as it does not have risk {risk_name}"
                            )
                            continue
                        LOGGER.debug(
                            f"checking for tests for experiment {experiment['id']}"
                        )

                        try:
                            tests_response = await client.get(
                                f"{config.CONTROL_PLANE_URL}/api/experiments/{experiment['id']}/tests?unevaluated-risk={quote_plus(risk_name)}&include-risk-evaluations=true",
                                headers=build_auth_headers(),
                            )
                        except (httpx.ConnectError, httpx.TimeoutException) as e:
                            if shutdown_manager.is_shutdown_requested():
                                LOGGER.debug(
                                    f"HTTP error during shutdown (expected): {e}"
                                )
                                return
                            else:
                                LOGGER.error(f"Connection error fetching tests: {e}")
                                continue

                        if not tests_response.is_success:
                            message = (
                                tests_response.json().get("message")
                                or tests_response.text
                            )
                            raise ValueError(
                                status_code=tests_response.status_code,
                                message=message,
                            )
                        tests = tests_response.json()

                        for test in tests:
                            # Check for shutdown before processing each test
                            if await shutdown_manager.is_async_shutdown_requested():
                                LOGGER.debug(
                                    "Shutdown requested, stopping test evaluation"
                                )
                                return

                            test_id = test["id"]
                            queue_key = f"{test_id}:{risk_name}"
                            if (
                                queue_key not in queued_evaluations
                                and test.get("response") is not None
                            ):
                                queued_evaluations[queue_key] = True
                                try:
                                    risk_eval_response = await client.post(
                                        f"{config.SNOWGLOBE_CLIENT_URL}/risk-evaluation",
                                        json={
                                            "test": test,
                                            "risk_name": risk_name,
                                            "simulation_name": experiment["name"],
                                            "agent_name": app_name,
                                        },
                                        timeout=config.REQUEST_TIMEOUT_SECONDS,
                                    )
                                except (
                                    httpx.ConnectError,
                                    httpx.TimeoutException,
                                ) as e:
                                    if shutdown_manager.is_shutdown_requested():
                                        LOGGER.debug(
                                            f"HTTP error during shutdown (expected): {e}"
                                        )
                                        return
                                    else:
                                        LOGGER.error(
                                            f"Connection error posting risk evaluation: {e}"
                                        )
                                        continue
                                finally:
                                    queued_evaluations.pop(queue_key, None)

                                # if risk evaltion response is 429 raise and exception and bail on this batch
                                if (
                                    not risk_eval_response.is_success
                                    and risk_eval_response.status_code == 429
                                ):
                                    LOGGER.error(
                                        f"Rate limit exceeded for risk evaluation {test['id']}: {risk_eval_response.text}"
                                    )
                                    raise ValueError(
                                        status_code=429,
                                        detail=f"Rate limit exceeded for risk evaluation {test['id']}",
                                    )
                                risk_eval_count += 1
                    except Exception as e:
                        if shutdown_manager.is_shutdown_requested():
                            LOGGER.debug(f"Error during shutdown (expected): {e}")
                            return
                        else:
                            LOGGER.error(f"Error fetching tests: {e}")

                if risk_eval_count > 0:
                    LOGGER.info(
                        f"Processed {risk_eval_count} risk evaluations for experiment {experiment.get('name', 'unknown')} ({experiment['id']})"
                    )

    except Exception as e:
        # Handle any other errors
        if shutdown_manager.is_shutdown_requested():
            LOGGER.debug(f"Error during shutdown (expected): {e}")
        else:
            LOGGER.error(f"Unexpected error in poll_for_risk_evaluations: {e}")
            raise


# Ensure the scheduler shuts down properly on application exit.
@asynccontextmanager
async def lifespan(app: FastAPI):
    try:
        # Load agents from .snowglobe/agents.json system
        agents_json_path = os.path.join(os.getcwd(), ".snowglobe", "agents.json")
        if os.path.exists(agents_json_path):
            try:
                with open(agents_json_path, "r") as f:
                    agents_data = json.load(f)

                for filename, agent_info in agents_data.items():
                    try:
                        app_id = agent_info["uuid"]
                        app_name = agent_info["name"]

                        # Skip agents not in the selected set (if filtering is active)
                        if (
                            selected_agent_uuids is not None
                            and app_id not in selected_agent_uuids
                        ):
                            LOGGER.info(
                                f"Skipping agent {app_name} ({app_id}) - not selected"
                            )
                            continue
                        agent_file_path = os.path.join(os.getcwd(), filename)

                        if not os.path.exists(agent_file_path):
                            LOGGER.warning(f"Agent file not found: {agent_file_path}")
                            continue

                        spec = importlib.util.spec_from_file_location(
                            "agent_wrapper", agent_file_path
                        )
                        agent_module = importlib.util.module_from_spec(spec)

                        # Add current directory to path
                        sys_path_backup = sys.path.copy()
                        current_dir = os.getcwd()
                        if current_dir not in sys.path:
                            sys.path.insert(0, current_dir)

                        try:
                            spec.loader.exec_module(agent_module)
                        finally:
                            sys.path = sys_path_backup

                        completion_fn = None
                        if hasattr(agent_module, "tool_defs"):
                            tools = agent_module.tool_defs()
                            normalized_tools = register_tools(
                                tools, application_id=app_id
                            )
                            LOGGER.info(
                                f"Registered {len(normalized_tools)} tools for application {app_name} ({app_id})"
                            )
                        if hasattr(agent_module, "completion"):
                            completion_fn = agent_module.completion
                        elif hasattr(agent_module, "acompletion"):
                            completion_fn = agent_module.acompletion
                        # Check for legacy function names
                        elif hasattr(agent_module, "completion_fn"):
                            completion_fn = agent_module.completion_fn
                            LOGGER.warning(
                                f"Agent {filename} uses deprecated function 'completion_fn'. Please rename to 'completion'"
                            )
                        elif hasattr(agent_module, "process_scenario"):
                            completion_fn = agent_module.process_scenario
                            LOGGER.warning(
                                f"Agent {filename} uses deprecated function 'process_scenario'. Please rename to 'completion' or 'acompletion'"
                            )
                        else:
                            LOGGER.warning(
                                f"Agent {filename} does not have a completion or acompletion function"
                            )
                            continue

                        apps[app_id] = {
                            "completion_fn": completion_fn,
                            "name": app_name,
                        }

                    except Exception:
                        LOGGER.error(f"Error loading agent {filename}")
                        raise

            except (json.JSONDecodeError, IOError) as e:
                LOGGER.error(f"Error reading agents.json: {e}")
        else:
            LOGGER.warning(
                "No .snowglobe/agents.json found. Run 'snowglobe-connect init' to set up an agent."
            )

        for app_id, app_info in apps.items():
            LOGGER.info(
                f"Loaded application {app_info['name']} with ID {app_id} for completions."
            )
        if config.APPLICATION_ID:
            if config.APPLICATION_ID not in apps:
                LOGGER.warning(
                    "\n********* START WARNING *********"
                    f"\nLegacy single application detected with ID {config.APPLICATION_ID}. "
                    "\nPlease migrate to the new applications structure."
                    f"\nRun snowglobe-connect init and follow the prompts to set up your application."
                    "\nThis configuration option will be removed in the next major release."
                    "\n********* END WARNING *********"
                )
                # load the legacy applications connect file out of the base of this directory
                legacy_connect_file = os.path.join(os.getcwd(), "snowglobe_connect.py")
                if os.path.exists(legacy_connect_file):
                    spec = importlib.util.spec_from_file_location(
                        "snowglobe_connect", legacy_connect_file
                    )
                    sg_connect = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(sg_connect)
                    if hasattr(sg_connect, "completion"):
                        apps[config.APPLICATION_ID] = {
                            "completion_fn": sg_connect.completion,
                            "name": "Legacy Single Application",
                        }
                        LOGGER.info(
                            f"Loaded legacy application with ID {config.APPLICATION_ID} for completions."
                        )
                    elif hasattr(sg_connect, "acompletion"):
                        apps[config.APPLICATION_ID] = {
                            "completion_fn": sg_connect.acompletion,
                            "name": "Legacy Single Application",
                        }
                        LOGGER.info(
                            f"Loaded legacy application with ID {config.APPLICATION_ID} for completions."
                        )
                    elif hasattr(sg_connect, "completion_fn"):
                        apps[config.APPLICATION_ID] = {
                            "completion_fn": sg_connect.completion_fn,
                            "name": "Legacy Single Application",
                        }
                        LOGGER.warning(
                            f"Legacy application with ID {config.APPLICATION_ID} uses deprecated function 'completion_fn'. Please rename to 'completion'"
                        )
                        LOGGER.info(
                            f"Loaded legacy application with ID {config.APPLICATION_ID} for completions."
                        )
                    elif hasattr(sg_connect, "process_scenario"):
                        apps[config.APPLICATION_ID] = {
                            "completion_fn": sg_connect.process_scenario,
                            "name": "Legacy Single Application",
                        }
                        LOGGER.warning(
                            f"Legacy application with ID {config.APPLICATION_ID} uses deprecated function 'process_scenario'. Please rename to 'completion' or 'acompletion'"
                        )
                        LOGGER.info(
                            f"Loaded legacy application with ID {config.APPLICATION_ID} for completions."
                        )
                    else:
                        LOGGER.error(
                            f"Legacy application with ID {config.APPLICATION_ID} does not have a completion or acompletion function."
                        )
    except Exception as e:
        raise
        LOGGER.error(f"Error loading applications: {e}")

    # attempt to judge risks from custom_risks/
    # each judge name is encoded in the filename with spaces replaced by underscores
    try:
        risks_dir = os.path.join(os.getcwd(), "custom_risks")
        if os.path.exists(risks_dir):
            for judge_file in os.listdir(risks_dir):
                if judge_file.endswith(".py"):
                    judge_name = judge_file[:-3].replace("_", " ")

                    spec = importlib.util.spec_from_file_location(
                        judge_name, os.path.join(risks_dir, judge_file)
                    )
                    judge_module = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(judge_module)
                    if hasattr(judge_module, "risk_evaluation_fn"):
                        risks[judge_name] = judge_module.risk_evaluation_fn
                    else:
                        LOGGER.warning(
                            f"Judge {judge_name} does not have a risk_evaluation_fn. Skipping."
                        )
        LOGGER.info(f"Loaded risks: {list(risks.keys())}")
    except Exception as e:
        LOGGER.error(
            f"Error loading risks from custom_risks: {e}. Custom judging will not be available."
        )

    async with AsyncScheduler() as scheduler:
        await scheduler.add_schedule(poll_for_completions, IntervalTrigger(seconds=2))
        await scheduler.add_schedule(
            poll_for_risk_evaluations, IntervalTrigger(seconds=20)
        )
        await scheduler.add_schedule(
            process_application_heartbeats, IntervalTrigger(minutes=5)
        )
        await scheduler.start_in_background()
        yield

    # --- Shutdown path ---
    # Signal all poll loops to stop so the scheduler doesn't dispatch new work.
    console.print("\n[bold blue]🛑 Shutting down...[/bold blue]")
    shutdown_manager.shutdown_event.set()
    shutdown_manager.shutdown_initiated = True

    # 1. Drain in-flight dispatch tasks so completions finish cleanly.
    if _pending_dispatch_tasks:
        console.print(
            f"[dim]Waiting for {len(_pending_dispatch_tasks)} in-flight task(s) to finish...[/dim]"
        )
        LOGGER.info(
            "Waiting for %s in-flight dispatch task(s) to finish...",
            len(_pending_dispatch_tasks),
        )
        await asyncio.gather(*_pending_dispatch_tasks, return_exceptions=True)

    # 2. Close the shared dispatch HTTP client.
    global _dispatch_client
    if _dispatch_client is not None:
        await _dispatch_client.aclose()
        _dispatch_client = None

    # 3. Notify the control plane that each agent has disconnected.
    for app_id in apps.keys():
        try:
            connection_test_url = (
                f"{config.CONTROL_PLANE_URL}/api/failed-code-connection-tests"
            )
            connection_test_payload = {
                "appId": app_id,
                "status": "failed",
                "error": "snowglobe-connect shut down gracefully",
            }
            async with httpx.AsyncClient() as client:
                LOGGER.info(
                    f"Posting shut down code connection test for application {app_id} connection_test_payload: {connection_test_payload}"
                )
                connection_test_response = await client.post(
                    connection_test_url,
                    json=connection_test_payload,
                    headers=build_auth_headers(config.API_KEY),
                )
            if not connection_test_response.is_success:
                LOGGER.error(
                    f"Error posting shut down code connection test for application {app_id}: {connection_test_response.text}"
                )
            LOGGER.info(
                f"Posted shut down heart beat for application {app_id} successfully."
            )
        except Exception as e:
            LOGGER.error(
                f"Error processing application heartbeat for {app_id}: {e}\n{traceback.format_exc()}"
            )

    # 4. Stop the scheduler.
    await scheduler.stop()
    await scheduler.wait_until_stopped()

    # 5. Show session summary now that everything has drained.
    show_session_summary()
    console.print()
    success("Agent disconnected successfully")


def create_client():
    """Create and configure the FastAPI application."""
    app = FastAPI(lifespan=lifespan)

    @app.get("/")
    def read_root():
        return {"message": "Dashing through the snow..."}

    @app.post("/completion")
    @rate_limit(
        "completion",
        max_requests=config.CONCURRENT_COMPLETIONS_PER_INTERVAL,
        time_window=config.CONCURRENT_COMPLETIONS_INTERVAL_SECONDS,
    )
    async def completion_endpoint(request: Request):
        # request body is test
        completion_body = await request.json()
        test = completion_body.get("test")
        app_id = completion_body.get("app_id")
        simulation_name = completion_body.get("simulation_name")
        # both are required non empty strings
        if not test or not app_id:
            raise HTTPException(
                status_code=400,
                detail="Both 'test' and 'app_id' must be provided in the request body.",
            )
        if app_id not in apps:
            raise HTTPException(
                status_code=404,
                detail=f"Application with ID {app_id} not found.",
            )
        completion_fn = apps.get(app_id, {}).get("completion_fn")
        LOGGER.debug(f"Received test: {test['id']}")
        try:
            await process_test(test, completion_fn, app_id, simulation_name)
        except HTTPException:
            raise
        except Exception as e:
            LOGGER.error(
                "Error processing completion for test %s (app_id=%s): %s",
                test.get("id"),
                app_id,
                e,
                exc_info=True,
            )
            raise HTTPException(
                status_code=502,
                detail=f"Completion processing failed: {e}",
            )
        return {"status": "processed"}

    @app.post("/heartbeat")
    @rate_limit(
        "heartbeat",
        max_requests=config.CONCURRENT_HEARTBEATS_PER_INTERVAL,
        time_window=config.CONCURRENT_HEARTBEATS_INTERVAL_SECONDS,
    )
    async def heartbeat_endpoint(request: Request):
        """Endpoint to check if the client is alive and well."""
        body = await request.json()
        app_id = body.get("app_id")
        if not app_id:
            raise HTTPException(
                status_code=400,
                detail="Application ID must be provided in the request body.",
            )
        if app_id not in apps:
            raise HTTPException(
                status_code=404,
                detail=f"Application with ID {app_id} not found.",
            )
        LOGGER.debug(f"Received heartbeat for application: {app_id}")

        # Simulate processing heartbeat
        await process_application_heartbeat(app_id)
        return {"status": "heartbeat received"}

    @app.post("/risk-evaluation")
    @rate_limit(
        "risk_evaluation",
        max_requests=config.CONCURRENT_RISK_EVALUATIONS,
        time_window=config.CONCURRENT_RISK_EVALUATIONS_INTERVAL_SECONDS,
    )
    async def risk_evaluation_endpoint(request: Request):
        # request body is test
        body = await request.json()
        test = body.get("test")
        risk_name = body.get("risk_name")
        simulation_name = body.get("simulation_name")
        agent_name = body.get("agent_name")
        LOGGER.debug(f"Received risk evaluation for test: {test['id']}")

        # For now, just simulate processing
        await process_risk_evaluation(test, risk_name, simulation_name, agent_name)
        return {"status": "risk evaluation processed"}

    return app


def start_client(verbose=False, agent_uuid_filter=None, very_verbose=False):
    """Start the FastAPI client.

    Args:
        verbose: Show detailed technical logs.
        agent_uuid_filter: Optional set of agent UUIDs to load. If None, all agents are loaded.
    """
    global selected_agent_uuids
    selected_agent_uuids = agent_uuid_filter

    # Configure logging based on verbose flag
    if very_verbose:
        LOGGER.setLevel(logging.DEBUG)
        logging.getLogger("apscheduler").setLevel(logging.DEBUG)
    elif verbose:
        LOGGER.setLevel(logging.INFO)
        logging.getLogger("apscheduler").setLevel(logging.INFO)
    else:
        LOGGER.setLevel(logging.WARNING)
        logging.getLogger("apscheduler").setLevel(logging.ERROR)

    # Initialize stats tracking
    initialize_stats()

    app = create_client()

    port = config.SNOWGLOBE_CLIENT_PORT
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=port,
        log_level="warning",
        timeout_keep_alive=config.REQUEST_TIMEOUT_SECONDS,
    )


if __name__ == "__main__":
    start_client()
