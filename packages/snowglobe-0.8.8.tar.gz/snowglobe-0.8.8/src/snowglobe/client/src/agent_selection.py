"""Agent selection utilities for the start command.

Handles parsing of number ranges (e.g. "1-3,9") and validation of agent IDs.
"""

from typing import Any, Dict, List, Set, Tuple


def parse_number_selection(selection: str, max_number: int) -> List[int]:
    """Parse a comma-separated list of numbers and ranges into a sorted list of unique indices.

    Examples:
        "7" -> [7]
        "1-3,9" -> [1, 2, 3, 9]
        "8,4" -> [4, 8]

    Args:
        selection: User input string with comma-separated numbers/ranges.
        max_number: The maximum valid number (inclusive).

    Returns:
        Sorted list of unique 1-based indices.

    Raises:
        ValueError: If the input contains invalid tokens, out-of-range numbers,
                     or reversed ranges.
    """
    if not selection or not selection.strip():
        raise ValueError("Selection cannot be empty.")

    indices: Set[int] = set()
    parts = selection.split(",")

    for part in parts:
        part = part.strip()
        if not part:
            raise ValueError(f"Invalid selection: empty segment in '{selection}'.")

        if "-" in part:
            bounds = part.split("-")
            if len(bounds) != 2 or not bounds[0].strip() or not bounds[1].strip():
                raise ValueError(f"Invalid range: '{part}'.")
            try:
                start = int(bounds[0].strip())
                end = int(bounds[1].strip())
            except ValueError:
                raise ValueError(f"Invalid range: '{part}'. Must be integers.")

            if start > end:
                raise ValueError(f"Invalid range: '{part}'. Start must be <= end.")
            if start < 1 or end > max_number:
                raise ValueError(
                    f"Numbers must be between 1 and {max_number}. Got range '{part}'."
                )
            indices.update(range(start, end + 1))
        else:
            try:
                num = int(part)
            except ValueError:
                raise ValueError(f"Invalid number: '{part}'.")
            if num < 1 or num > max_number:
                raise ValueError(
                    f"Number {num} is out of range. Must be between 1 and {max_number}."
                )
            indices.add(num)

    return sorted(indices)


def filter_agents_by_indices(
    agents: List[Tuple[str, Dict[str, Any]]], indices: List[int]
) -> List[Tuple[str, Dict[str, Any]]]:
    """Filter agents list by 1-based indices.

    Args:
        agents: List of (filename, agent_info) tuples.
        indices: Sorted list of 1-based indices.

    Returns:
        Filtered list of agents matching the given indices.
    """
    return [agents[i - 1] for i in indices]


def validate_agent_ids(
    agent_ids: List[str], agents: List[Tuple[str, Dict[str, Any]]]
) -> List[Tuple[str, Dict[str, Any]]]:
    """Validate that all provided agent UUIDs exist in the agents list.

    Args:
        agent_ids: List of agent UUID strings.
        agents: List of (filename, agent_info) tuples.

    Returns:
        Filtered list of agents matching the given UUIDs (in UUID input order).

    Raises:
        ValueError: If any UUID is not found in the agents list.
    """
    uuid_to_agent = {info.get("uuid"): (filename, info) for filename, info in agents}

    result = []
    invalid_ids = []
    for aid in agent_ids:
        if aid in uuid_to_agent:
            result.append(uuid_to_agent[aid])
        else:
            invalid_ids.append(aid)

    if invalid_ids:
        valid_uuids = [info.get("uuid") for _, info in agents]
        raise ValueError(
            f"Invalid agent ID(s): {', '.join(invalid_ids)}. "
            f"Valid IDs: {', '.join(valid_uuids)}"
        )

    return result


def get_agent_uuids(agents: List[Tuple[str, Dict[str, Any]]]) -> Set[str]:
    """Extract the set of UUIDs from an agents list."""
    return {info.get("uuid") for _, info in agents}
