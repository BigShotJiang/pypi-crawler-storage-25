import os
import unittest

os.environ["SNOWGLOBE_API_KEY"] = "test"

from snowglobe.client.src.agent_selection import (  # noqa: E402
    filter_agents_by_indices,
    get_agent_uuids,
    parse_number_selection,
    validate_agent_ids,
)

os.environ["SNOWGLOBE_API_KEY"] = ""


def _make_agents(n):
    """Create n fake agents for testing."""
    return [
        (f"agent_{i}.py", {"uuid": f"uuid-{i}", "name": f"Agent {i}"})
        for i in range(1, n + 1)
    ]


class TestParseNumberSelection(unittest.TestCase):
    """Tests for parse_number_selection."""

    def test_single_number(self):
        self.assertEqual(parse_number_selection("7", 10), [7])

    def test_single_number_at_boundary(self):
        self.assertEqual(parse_number_selection("1", 1), [1])

    def test_comma_separated(self):
        self.assertEqual(parse_number_selection("8,4", 10), [4, 8])

    def test_range(self):
        self.assertEqual(parse_number_selection("1-3", 10), [1, 2, 3])

    def test_range_and_number(self):
        self.assertEqual(parse_number_selection("1-3,9", 10), [1, 2, 3, 9])

    def test_multiple_ranges(self):
        self.assertEqual(parse_number_selection("1-3,7-9", 10), [1, 2, 3, 7, 8, 9])

    def test_overlapping_ranges(self):
        self.assertEqual(parse_number_selection("1-5,3-7", 10), [1, 2, 3, 4, 5, 6, 7])

    def test_duplicate_numbers(self):
        self.assertEqual(parse_number_selection("3,3,3", 10), [3])

    def test_whitespace_handling(self):
        self.assertEqual(parse_number_selection(" 1 , 3 - 5 , 8 ", 10), [1, 3, 4, 5, 8])

    def test_single_element_range(self):
        self.assertEqual(parse_number_selection("5-5", 10), [5])

    # --- Error cases ---

    def test_empty_string(self):
        with self.assertRaises(ValueError):
            parse_number_selection("", 10)

    def test_whitespace_only(self):
        with self.assertRaises(ValueError):
            parse_number_selection("   ", 10)

    def test_zero(self):
        with self.assertRaises(ValueError):
            parse_number_selection("0", 10)

    def test_negative_number(self):
        with self.assertRaises(ValueError):
            parse_number_selection("-1", 10)

    def test_exceeds_max(self):
        with self.assertRaises(ValueError):
            parse_number_selection("11", 10)

    def test_range_exceeds_max(self):
        with self.assertRaises(ValueError):
            parse_number_selection("8-12", 10)

    def test_reversed_range(self):
        with self.assertRaises(ValueError):
            parse_number_selection("5-3", 10)

    def test_non_numeric(self):
        with self.assertRaises(ValueError):
            parse_number_selection("abc", 10)

    def test_non_numeric_in_range(self):
        with self.assertRaises(ValueError):
            parse_number_selection("1-abc", 10)

    def test_trailing_comma(self):
        with self.assertRaises(ValueError):
            parse_number_selection("1,2,", 10)

    def test_leading_comma(self):
        with self.assertRaises(ValueError):
            parse_number_selection(",1,2", 10)

    def test_double_comma(self):
        with self.assertRaises(ValueError):
            parse_number_selection("1,,2", 10)

    def test_malformed_range_triple(self):
        with self.assertRaises(ValueError):
            parse_number_selection("1-2-3", 10)


class TestFilterAgentsByIndices(unittest.TestCase):
    """Tests for filter_agents_by_indices."""

    def test_single_index(self):
        agents = _make_agents(5)
        result = filter_agents_by_indices(agents, [3])
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0][1]["uuid"], "uuid-3")

    def test_multiple_indices(self):
        agents = _make_agents(5)
        result = filter_agents_by_indices(agents, [1, 3, 5])
        self.assertEqual(len(result), 3)
        self.assertEqual([r[1]["uuid"] for r in result], ["uuid-1", "uuid-3", "uuid-5"])

    def test_all_indices(self):
        agents = _make_agents(3)
        result = filter_agents_by_indices(agents, [1, 2, 3])
        self.assertEqual(len(result), 3)


class TestValidateAgentIds(unittest.TestCase):
    """Tests for validate_agent_ids."""

    def test_single_valid_id(self):
        agents = _make_agents(5)
        result = validate_agent_ids(["uuid-3"], agents)
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0][1]["uuid"], "uuid-3")

    def test_multiple_valid_ids(self):
        agents = _make_agents(5)
        result = validate_agent_ids(["uuid-5", "uuid-1"], agents)
        self.assertEqual(len(result), 2)
        # Should preserve input order
        self.assertEqual(result[0][1]["uuid"], "uuid-5")
        self.assertEqual(result[1][1]["uuid"], "uuid-1")

    def test_all_valid_ids(self):
        agents = _make_agents(3)
        result = validate_agent_ids(["uuid-1", "uuid-2", "uuid-3"], agents)
        self.assertEqual(len(result), 3)

    def test_single_invalid_id(self):
        agents = _make_agents(3)
        with self.assertRaises(ValueError) as ctx:
            validate_agent_ids(["uuid-999"], agents)
        self.assertIn("uuid-999", str(ctx.exception))

    def test_mix_valid_and_invalid(self):
        agents = _make_agents(3)
        with self.assertRaises(ValueError) as ctx:
            validate_agent_ids(["uuid-1", "bad-id"], agents)
        self.assertIn("bad-id", str(ctx.exception))

    def test_empty_list(self):
        agents = _make_agents(3)
        result = validate_agent_ids([], agents)
        self.assertEqual(result, [])


class TestGetAgentUuids(unittest.TestCase):
    """Tests for get_agent_uuids."""

    def test_extracts_uuids(self):
        agents = _make_agents(3)
        uuids = get_agent_uuids(agents)
        self.assertEqual(uuids, {"uuid-1", "uuid-2", "uuid-3"})

    def test_empty_list(self):
        self.assertEqual(get_agent_uuids([]), set())


if __name__ == "__main__":
    unittest.main()
