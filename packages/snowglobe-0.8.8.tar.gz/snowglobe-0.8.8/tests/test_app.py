import unittest
import os
import httpx
from unittest import mock
from unittest.mock import AsyncMock, MagicMock

# Mock config before importing app
os.environ["SNOWGLOBE_API_KEY"] = "test"
from src.snowglobe.client.src.app import (  # noqa: E402
    ConfigurableRateLimiter,
    rate_limit,
    process_risk_evaluation,
    process_test,
    _dispatch_completion_request,
    poll_for_completions,
    poll_for_risk_evaluations,
    create_client,
    start_client,
    route_request_times,
    queued_tests,
    queued_evaluations,
    risks,
    apps,
)
from src.snowglobe.client.src.models import (  # noqa: E402
    SnowglobeMessage,
    SnowglobeData,
    CompletionFunctionOutputs,
    RiskEvaluationOutputs,
)

from fastapi import HTTPException  # noqa: E402

os.environ["SNOWGLOBE_API_KEY"] = ""


def _reset_global_state():
    import src.snowglobe.client.src.app as app_module

    route_request_times.clear()
    queued_tests.clear()
    queued_evaluations.clear()
    risks.clear()
    apps.clear()
    # Reset queue-based dispatch state
    app_module._dispatch_semaphore = None
    app_module._dispatch_client = None
    app_module.completion_report_window.clear()
    app_module.poll_tick_counter = 0
    app_module._known_active_experiments.clear()
    app_module._terminal_transitions.clear()


class TestConfigurableRateLimiter(unittest.TestCase):
    def setUp(self):
        _reset_global_state()
        self.rate_limiter = ConfigurableRateLimiter()

    def test_init(self):
        limiter = ConfigurableRateLimiter()
        self.assertEqual(limiter.route_configs, {})

    def test_configure_route(self):
        self.rate_limiter.configure_route("test_route", 10, 60)
        expected = {"max_requests": 10, "time_window": 60}
        self.assertEqual(self.rate_limiter.route_configs["test_route"], expected)

    def test_get_route_config_existing(self):
        self.rate_limiter.configure_route("test_route", 5, 30)
        config = self.rate_limiter.get_route_config("test_route")
        self.assertEqual(config, {"max_requests": 5, "time_window": 30})

    def test_get_route_config_default(self):
        config = self.rate_limiter.get_route_config("nonexistent_route")
        self.assertEqual(config, {"max_requests": 1, "time_window": 1})

    def test_is_allowed_first_request(self):
        self.rate_limiter.configure_route("test_route", 2, 60)
        result = self.rate_limiter.is_allowed("client1", "test_route")
        self.assertTrue(result)

    def test_is_allowed_within_limit(self):
        self.rate_limiter.configure_route("test_route", 3, 60)
        self.assertTrue(self.rate_limiter.is_allowed("client1", "test_route"))
        self.assertTrue(self.rate_limiter.is_allowed("client1", "test_route"))
        self.assertTrue(self.rate_limiter.is_allowed("client1", "test_route"))

    def test_is_allowed_exceeds_limit(self):
        self.rate_limiter.configure_route("test_route", 2, 60)
        self.assertTrue(self.rate_limiter.is_allowed("client1", "test_route"))
        self.assertTrue(self.rate_limiter.is_allowed("client1", "test_route"))
        self.assertFalse(self.rate_limiter.is_allowed("client1", "test_route"))

    @mock.patch("time.time")
    def test_is_allowed_time_window_reset(self, mock_time):
        # First request at time 0
        mock_time.return_value = 0
        self.rate_limiter.configure_route("test_route", 1, 2)
        self.assertTrue(self.rate_limiter.is_allowed("client1", "test_route"))

        # Second request still at time 0 - should be rejected
        self.assertFalse(self.rate_limiter.is_allowed("client1", "test_route"))

        # Request after time window - should be allowed
        mock_time.return_value = 3
        self.assertTrue(self.rate_limiter.is_allowed("client1", "test_route"))

    def test_is_allowed_different_clients(self):
        self.rate_limiter.configure_route("test_route", 1, 60)
        self.assertTrue(self.rate_limiter.is_allowed("client1", "test_route"))
        self.assertTrue(self.rate_limiter.is_allowed("client2", "test_route"))

    def test_is_allowed_different_routes(self):
        self.rate_limiter.configure_route("route1", 1, 60)
        self.rate_limiter.configure_route("route2", 1, 60)
        self.assertTrue(self.rate_limiter.is_allowed("client1", "route1"))
        self.assertTrue(self.rate_limiter.is_allowed("client1", "route2"))


class TestRateLimitDecorator(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        _reset_global_state()
        self.mock_request = MagicMock()
        self.mock_request.client.host = "127.0.0.1"

    @mock.patch("src.snowglobe.client.src.app.rate_limiter")
    async def test_rate_limit_decorator_allowed(self, mock_rate_limiter):
        mock_rate_limiter.is_allowed.return_value = True

        @rate_limit("test_route", 5, 60)
        async def test_func(request):
            return {"status": "ok"}

        result = await test_func(self.mock_request)
        self.assertEqual(result, {"status": "ok"})
        mock_rate_limiter.configure_route.assert_called_with("test_route", 5, 60)
        mock_rate_limiter.is_allowed.assert_called_with("127.0.0.1", "test_route")

    @mock.patch("src.snowglobe.client.src.app.rate_limiter")
    async def test_rate_limit_decorator_rejected(self, mock_rate_limiter):
        mock_rate_limiter.is_allowed.return_value = False
        mock_rate_limiter.get_route_config.return_value = {
            "max_requests": 5,
            "time_window": 60,
        }

        @rate_limit("test_route", 5, 60)
        async def test_func(request):
            return {"status": "ok"}

        with self.assertRaises(HTTPException) as cm:
            await test_func(self.mock_request)

        self.assertEqual(cm.exception.status_code, 429)
        self.assertIn("Rate limit exceeded", cm.exception.detail)


class TestProcessRiskEvaluation(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        _reset_global_state()
        self.test_data = {
            "id": "test-123",
            "experiment_id": "exp-456",
            "conversation_id": "conv-789",
            "prompt": "test prompt",
        }
        self.mock_messages = [SnowglobeMessage(role="user", content="test message")]

    @mock.patch("httpx.AsyncClient")
    @mock.patch("src.snowglobe.client.src.app.fetch_messages")
    async def test_process_risk_evaluation_async_function(
        self, mock_fetch_messages, mock_client
    ):
        mock_fetch_messages.return_value = self.mock_messages

        # Mock async risk function
        async def mock_risk_fn(request):
            return RiskEvaluationOutputs(
                triggered=True, severity=3, reason="test reason"
            )

        risks["test_risk"] = mock_risk_fn

        # Mock HTTP response
        mock_response = AsyncMock()
        mock_response.is_success = True
        mock_client.return_value.__aenter__.return_value.post.return_value = (
            mock_response
        )

        await process_risk_evaluation(
            self.test_data,
            "test_risk",
            simulation_name="sim-1",
            agent_name="agent-1",
        )

        mock_fetch_messages.assert_called_once_with(test=self.test_data)

    @mock.patch("httpx.AsyncClient")
    @mock.patch("src.snowglobe.client.src.app.fetch_messages")
    async def test_process_risk_evaluation_sync_function(
        self, mock_fetch_messages, mock_client
    ):
        mock_fetch_messages.return_value = self.mock_messages

        # Mock sync risk function
        def mock_risk_fn(request):
            return RiskEvaluationOutputs(triggered=False, severity=1, reason="no risk")

        risks["test_risk"] = mock_risk_fn

        # Mock HTTP response
        mock_response = AsyncMock()
        mock_response.is_success = True
        mock_client.return_value.__aenter__.return_value.post.return_value = (
            mock_response
        )

        await process_risk_evaluation(
            self.test_data,
            "test_risk",
            simulation_name="sim-1",
            agent_name="agent-1",
        )

        mock_fetch_messages.assert_called_once_with(test=self.test_data)

    @mock.patch("src.snowglobe.client.src.app.LOGGER.error")
    @mock.patch("httpx.AsyncClient")
    @mock.patch("src.snowglobe.client.src.app.fetch_messages")
    async def test_process_risk_evaluation_http_error(
        self, mock_fetch_messages, mock_client, _mock_logger_error
    ):
        mock_fetch_messages.return_value = self.mock_messages

        def mock_risk_fn(request):
            return RiskEvaluationOutputs(triggered=True, severity=2, reason="test")

        risks["test_risk"] = mock_risk_fn

        # Mock HTTP error
        mock_response = AsyncMock()
        mock_response.is_success = False
        mock_response.text = "Server error"
        mock_client.return_value.__aenter__.return_value.post.return_value = (
            mock_response
        )

        with self.assertRaises(Exception) as cm:
            await process_risk_evaluation(
                self.test_data,
                "test_risk",
                simulation_name="sim-1",
                agent_name="agent-1",
            )

        self.assertIn("Error posting risk evaluation", str(cm.exception))


class TestProcessTest(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        _reset_global_state()
        self.test_data = {
            "id": "test-123",
            "experiment_id": "exp-456",
            "conversation_id": "conv-789",
            "prompt": "test prompt",
            "persona": "test persona",
        }
        self.mock_messages = [
            SnowglobeMessage(
                role="user",
                content="test message",
                snowglobe_data=SnowglobeData(
                    conversation_id="conv-789",
                    test_id="test-123",
                    simulation_id="exp-456",
                ),
            )
        ]

    @mock.patch("src.snowglobe.client.src.app._request_with_retries")
    @mock.patch("httpx.AsyncClient")
    @mock.patch("src.snowglobe.client.src.app.fetch_messages")
    async def test_process_test_async_function(
        self, mock_fetch_messages, mock_client, mock_request_with_retries
    ):
        mock_fetch_messages.return_value = self.mock_messages

        # Mock async completion function
        async def mock_completion_fn(request):
            return CompletionFunctionOutputs(response="test response")

        # Mock HTTP response
        mock_response = MagicMock()
        mock_response.is_success = True
        mock_request_with_retries.return_value = mock_response

        # Add test to queue first
        queued_tests["test-123"] = True

        result = await process_test(
            self.test_data,
            mock_completion_fn,
            app_id="app-1",
            simulation_name="sim-1",
        )

        self.assertEqual(result.response, "test response")
        mock_fetch_messages.assert_called_once_with(test=self.test_data)
        # Test should be removed from queue
        self.assertNotIn("test-123", queued_tests)

    @mock.patch("src.snowglobe.client.src.app._request_with_retries")
    @mock.patch("httpx.AsyncClient")
    @mock.patch("src.snowglobe.client.src.app.fetch_messages")
    async def test_process_test_sync_function(
        self, mock_fetch_messages, mock_client, mock_request_with_retries
    ):
        mock_fetch_messages.return_value = self.mock_messages

        # Mock sync completion function
        def mock_completion_fn(request):
            return CompletionFunctionOutputs(response="sync response")

        # Mock HTTP response
        mock_response = MagicMock()
        mock_response.is_success = True
        mock_request_with_retries.return_value = mock_response

        result = await process_test(
            self.test_data,
            mock_completion_fn,
            app_id="app-1",
            simulation_name="sim-1",
        )

        self.assertEqual(result.response, "sync response")
        mock_fetch_messages.assert_called_once_with(test=self.test_data)

    @mock.patch("src.snowglobe.client.src.app._request_with_retries")
    @mock.patch("httpx.AsyncClient")
    @mock.patch("src.snowglobe.client.src.app.fetch_messages")
    async def test_process_test_empty_response_raises(
        self, mock_fetch_messages, mock_client, mock_request_with_retries
    ):
        mock_fetch_messages.return_value = self.mock_messages
        _ = mock_client

        async def mock_completion_fn(request):
            return CompletionFunctionOutputs(response="   ")

        queued_tests["test-123"] = True

        with self.assertRaises(RuntimeError) as cm:
            await process_test(
                self.test_data,
                mock_completion_fn,
                app_id="app-1",
                simulation_name="sim-1",
            )

        self.assertIn("is empty", str(cm.exception))
        mock_request_with_retries.assert_not_called()
        self.assertNotIn("test-123", queued_tests)


class TestDispatchCompletionRequest(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        _reset_global_state()
        self.test_data = {
            "id": "test-123",
            "experiment_id": "exp-456",
            "conversation_id": "conv-789",
            "prompt": "test prompt",
            "persona": "test persona",
        }

    @mock.patch("src.snowglobe.client.src.app._request_with_retries")
    async def test_dispatch_timeout_raises_and_clears_inflight(self, mock_request):
        mock_request.side_effect = httpx.TimeoutException("request timed out")
        client = AsyncMock()

        with self.assertRaises(RuntimeError) as cm:
            await _dispatch_completion_request(
                client,
                self.test_data,
                app_id="app-1",
                simulation_name="sim-1",
            )

        self.assertIn("Timed out posting completion", str(cm.exception))
        self.assertNotIn("test-123", queued_tests)


class TestPollingFunctions(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        _reset_global_state()
        apps["app-1"] = {
            "completion_fn": lambda request: CompletionFunctionOutputs(response="ok")
        }

    @mock.patch("src.snowglobe.client.src.app._dispatch_completion_request")
    @mock.patch("src.snowglobe.client.src.app._request_with_retries")
    @mock.patch("httpx.AsyncClient")
    @mock.patch("src.snowglobe.client.src.app.fetch_experiments")
    async def test_poll_for_completions_success(
        self,
        mock_fetch_experiments,
        mock_client,
        mock_request_with_retries,
        mock_dispatch_completion_request,
    ):
        mock_experiments = [{"id": "exp-1", "app_id": "app-1", "name": "sim-1"}]
        mock_fetch_experiments.return_value = mock_experiments

        mock_tests = [
            {"id": "test-1", "response": None},
            {"id": "test-2", "response": "existing response"},
        ]

        mock_dispatch_completion_request.return_value = True

        mock_experiment_response = MagicMock()
        mock_experiment_response.is_success = True
        mock_experiment_response.json.return_value = {
            "id": "exp-1",
            "app_id": "app-1",
            "name": "sim-1",
        }

        mock_tests_response = MagicMock()
        mock_tests_response.is_success = True
        mock_tests_response.json.return_value = mock_tests
        mock_request_with_retries.side_effect = [
            mock_experiment_response,
            mock_tests_response,
        ]

        mock_client_instance = AsyncMock()
        mock_client.return_value.__aenter__.return_value = mock_client_instance

        import asyncio

        await poll_for_completions()
        await asyncio.sleep(0.05)  # let fire-and-forget tasks run

        # Queue entries are transient and should be cleared after dispatch.
        self.assertNotIn("test-1", queued_tests)
        self.assertNotIn("test-2", queued_tests)

    @mock.patch("src.snowglobe.client.src.app._dispatch_completion_request")
    @mock.patch("src.snowglobe.client.src.app._request_with_retries")
    @mock.patch("httpx.AsyncClient")
    @mock.patch("src.snowglobe.client.src.app.fetch_experiments")
    async def test_poll_for_completions_rate_limit(
        self,
        mock_fetch_experiments,
        mock_client,
        mock_request_with_retries,
        mock_dispatch_completion_request,
    ):
        """Rate-limited dispatches are logged as warnings (fire-and-forget handles the error)."""
        import asyncio

        mock_experiments = [{"id": "exp-1", "app_id": "app-1", "name": "sim-1"}]
        mock_fetch_experiments.return_value = mock_experiments

        mock_tests = [{"id": "test-1", "response": None}]

        mock_experiment_response = MagicMock()
        mock_experiment_response.is_success = True
        mock_experiment_response.json.return_value = {
            "id": "exp-1",
            "app_id": "app-1",
            "name": "sim-1",
        }

        mock_tests_response = MagicMock()
        mock_tests_response.is_success = True
        mock_tests_response.json.return_value = mock_tests
        mock_request_with_retries.side_effect = [
            mock_experiment_response,
            mock_tests_response,
        ]

        mock_dispatch_completion_request.side_effect = HTTPException(
            status_code=429, detail="Rate limit exceeded for test test-1"
        )

        mock_client_instance = AsyncMock()
        mock_client.return_value.__aenter__.return_value = mock_client_instance

        # Should not raise — fire-and-forget catches the 429 and logs a warning
        await poll_for_completions()
        await asyncio.sleep(0.05)  # let fire-and-forget tasks run

        mock_dispatch_completion_request.assert_called_once()

    @mock.patch("httpx.AsyncClient")
    @mock.patch("src.snowglobe.client.src.app.fetch_experiments")
    async def test_poll_for_risk_evaluations(self, mock_fetch_experiments, mock_client):
        mock_experiments = [
            {
                "id": "exp-1",
                "source_data": {
                    "evaluation_configuration": {"test_risk": {"enabled": True}}
                },
            }
        ]
        mock_fetch_experiments.return_value = mock_experiments

        # Add a risk to test
        risks["test_risk"] = lambda x: RiskEvaluationOutputs(triggered=True)

        mock_tests = [{"id": "test-1", "response": "test response"}]

        mock_experiment_response = MagicMock()
        mock_experiment_response.is_success = True
        mock_experiment_response.json.return_value = {
            "id": "exp-1",
            "app_id": "app-1",
            "name": "sim-1",
            "source_data": {
                "evaluation_configuration": {"test_risk": {"enabled": True}}
            },
        }

        mock_app_response = MagicMock()
        mock_app_response.is_success = True
        mock_app_response.json.return_value = {"name": "test-app"}

        mock_tests_response = MagicMock()
        mock_tests_response.is_success = True
        mock_tests_response.json.return_value = mock_tests

        mock_client_instance = AsyncMock()
        mock_client.return_value.__aenter__.return_value = mock_client_instance

        mock_client_instance.get.side_effect = [
            mock_experiment_response,
            mock_app_response,
            mock_tests_response,
        ]

        # Mock risk evaluation response
        mock_risk_response = MagicMock()
        mock_risk_response.is_success = True
        mock_client_instance.post.return_value = mock_risk_response

        await poll_for_risk_evaluations()

        self.assertNotIn("test-1:test_risk", queued_evaluations)


class TestQueueDispatch(unittest.IsolatedAsyncioTestCase):
    """Tests for the queue-based dispatch model in poll_for_completions.

    Verifies that:
    - Tests are dispatched as fire-and-forget tasks gated by a semaphore (no gather)
    - A slow completion does NOT block tests from other experiments
    - Concurrency is bounded by the semaphore (N lanes)
    - Inflight / already-responded / errored tests are skipped
    - Multiple agents' experiments are all processed
    - Time-windowed reporting fires after the configured interval
    - Shutdown drains inflight tasks and reports to the user
    """

    def setUp(self):
        _reset_global_state()
        apps["app-1"] = {
            "completion_fn": lambda request: CompletionFunctionOutputs(response="ok")
        }

    def _make_experiment(self, exp_id, app_id="app-1", name="sim-1"):
        return {"id": exp_id, "app_id": app_id, "name": name}

    def _make_test(self, test_id, response=None, last_error=""):
        return {"id": test_id, "response": response, "last_error": last_error}

    def _mock_request_side_effects(self, experiments_with_tests):
        """Build side_effect list for _request_with_retries.

        Each experiment needs two responses: one for the experiment detail GET,
        one for the tests GET.
        """
        side_effects = []
        for exp, tests in experiments_with_tests:
            exp_response = MagicMock()
            exp_response.is_success = True
            exp_response.json.return_value = exp
            side_effects.append(exp_response)

            tests_response = MagicMock()
            tests_response.is_success = True
            tests_response.json.return_value = tests
            side_effects.append(tests_response)
        return side_effects

    @mock.patch("src.snowglobe.client.src.app._dispatch_completion_request")
    @mock.patch("src.snowglobe.client.src.app._request_with_retries")
    @mock.patch("httpx.AsyncClient")
    @mock.patch("src.snowglobe.client.src.app.fetch_experiments")
    async def test_slow_completion_does_not_block_other_experiments(
        self,
        mock_fetch_experiments,
        mock_client,
        mock_request_with_retries,
        mock_dispatch,
    ):
        """A slow completion in exp-1 must NOT block exp-2's test from starting.
        This is the key behavioral change from batching to queue-based dispatch."""
        import asyncio

        timestamps = []

        async def slow_then_fast(client, test, app_id, simulation_name):
            timestamps.append(
                ("dispatch_start", test["id"], asyncio.get_event_loop().time())
            )
            if test["id"] == "slow-test":
                await asyncio.sleep(0.2)
            timestamps.append(
                ("dispatch_end", test["id"], asyncio.get_event_loop().time())
            )
            return True

        mock_dispatch.side_effect = slow_then_fast

        exp1 = self._make_experiment("exp-1")
        exp2 = self._make_experiment("exp-2")
        mock_fetch_experiments.return_value = [exp1, exp2]

        mock_request_with_retries.side_effect = self._mock_request_side_effects(
            [
                (exp1, [self._make_test("slow-test")]),
                (exp2, [self._make_test("fast-test")]),
            ]
        )

        mock_client_instance = AsyncMock()
        mock_client.return_value.__aenter__.return_value = mock_client_instance

        await poll_for_completions()

        # Wait for all background tasks to complete
        await asyncio.sleep(0.3)

        # fast-test should START before slow-test ENDS (no blocking)
        slow_end = next(
            t
            for label, tid, t in timestamps
            if label == "dispatch_end" and tid == "slow-test"
        )
        fast_start = next(
            t
            for label, tid, t in timestamps
            if label == "dispatch_start" and tid == "fast-test"
        )
        self.assertLess(fast_start, slow_end)

    @mock.patch("src.snowglobe.client.src.app._dispatch_completion_request")
    @mock.patch("src.snowglobe.client.src.app._request_with_retries")
    @mock.patch("httpx.AsyncClient")
    @mock.patch("src.snowglobe.client.src.app.fetch_experiments")
    async def test_concurrency_bounded_by_semaphore(
        self,
        mock_fetch_experiments,
        mock_client,
        mock_request_with_retries,
        mock_dispatch,
    ):
        """The number of concurrent dispatches never exceeds the semaphore limit."""
        import asyncio
        import src.snowglobe.client.src.app as app_module

        original_concurrency = app_module.COMPLETION_DISPATCH_CONCURRENCY
        app_module.COMPLETION_DISPATCH_CONCURRENCY = 3

        try:
            peak_concurrent = 0
            active = 0
            lock = asyncio.Lock()

            async def track_concurrency(client, test, app_id, simulation_name):
                nonlocal active, peak_concurrent
                async with lock:
                    active += 1
                    peak_concurrent = max(peak_concurrent, active)
                await asyncio.sleep(0.05)
                async with lock:
                    active -= 1
                return True

            mock_dispatch.side_effect = track_concurrency

            exp = self._make_experiment("exp-1")
            mock_fetch_experiments.return_value = [exp]

            tests = [self._make_test(f"test-{i}") for i in range(10)]
            mock_request_with_retries.side_effect = self._mock_request_side_effects(
                [(exp, tests)]
            )

            mock_client_instance = AsyncMock()
            mock_client.return_value.__aenter__.return_value = mock_client_instance

            await poll_for_completions()

            # Wait for all tasks to finish
            await asyncio.sleep(0.3)

            self.assertGreater(peak_concurrent, 1)
            self.assertLessEqual(peak_concurrent, 3)
        finally:
            app_module.COMPLETION_DISPATCH_CONCURRENCY = original_concurrency

    @mock.patch("src.snowglobe.client.src.app._dispatch_completion_request")
    @mock.patch("src.snowglobe.client.src.app._request_with_retries")
    @mock.patch("httpx.AsyncClient")
    @mock.patch("src.snowglobe.client.src.app.fetch_experiments")
    async def test_poll_returns_immediately_without_waiting(
        self,
        mock_fetch_experiments,
        mock_client,
        mock_request_with_retries,
        mock_dispatch,
    ):
        """poll_for_completions should return quickly even when dispatches are slow,
        because it fires-and-forgets rather than gathering."""
        import asyncio

        async def slow_dispatch(client, test, app_id, simulation_name):
            await asyncio.sleep(1.0)
            return True

        mock_dispatch.side_effect = slow_dispatch

        exp = self._make_experiment("exp-1")
        mock_fetch_experiments.return_value = [exp]

        mock_request_with_retries.side_effect = self._mock_request_side_effects(
            [(exp, [self._make_test("test-1")])]
        )

        mock_client_instance = AsyncMock()
        mock_client.return_value.__aenter__.return_value = mock_client_instance

        start = asyncio.get_event_loop().time()
        await poll_for_completions()
        elapsed = asyncio.get_event_loop().time() - start

        # Should return in well under 1s (the dispatch sleep time)
        self.assertLess(elapsed, 0.5)

        # Let the background task complete so it doesn't leak
        await asyncio.sleep(1.1)

    @mock.patch("src.snowglobe.client.src.app._dispatch_completion_request")
    @mock.patch("src.snowglobe.client.src.app._request_with_retries")
    @mock.patch("httpx.AsyncClient")
    @mock.patch("src.snowglobe.client.src.app.fetch_experiments")
    async def test_multiple_agents_all_dispatched(
        self,
        mock_fetch_experiments,
        mock_client,
        mock_request_with_retries,
        mock_dispatch,
    ):
        """Tests from multiple agents are all dispatched in a single poll cycle."""
        import asyncio

        apps["app-2"] = {
            "completion_fn": lambda request: CompletionFunctionOutputs(response="ok")
        }

        dispatched_tests = []

        async def record_dispatch(client, test, app_id, simulation_name):
            dispatched_tests.append((test["id"], app_id))
            return True

        mock_dispatch.side_effect = record_dispatch

        exp1 = self._make_experiment("exp-1", app_id="app-1")
        exp2 = self._make_experiment("exp-2", app_id="app-2")
        mock_fetch_experiments.side_effect = [[exp1], [exp2]]

        mock_request_with_retries.side_effect = self._mock_request_side_effects(
            [
                (exp1, [self._make_test("test-from-app1")]),
                (exp2, [self._make_test("test-from-app2")]),
            ]
        )

        mock_client_instance = AsyncMock()
        mock_client.return_value.__aenter__.return_value = mock_client_instance

        await poll_for_completions()
        await asyncio.sleep(0.05)  # let fire-and-forget tasks run

        self.assertEqual(len(dispatched_tests), 2)
        self.assertIn(("test-from-app1", "app-1"), dispatched_tests)
        self.assertIn(("test-from-app2", "app-2"), dispatched_tests)
        self.assertEqual(mock_fetch_experiments.call_count, 2)

    @mock.patch("src.snowglobe.client.src.app._dispatch_completion_request")
    @mock.patch("src.snowglobe.client.src.app._request_with_retries")
    @mock.patch("httpx.AsyncClient")
    @mock.patch("src.snowglobe.client.src.app.fetch_experiments")
    async def test_inflight_tests_skipped(
        self,
        mock_fetch_experiments,
        mock_client,
        mock_request_with_retries,
        mock_dispatch,
    ):
        """Tests already marked in-flight are not dispatched again."""
        import asyncio
        import time as _time

        dispatched_ids = []

        async def record_dispatch(client, test, app_id, simulation_name):
            dispatched_ids.append(test["id"])
            return True

        mock_dispatch.side_effect = record_dispatch

        queued_tests["test-2"] = _time.time()

        exp = self._make_experiment("exp-1")
        mock_fetch_experiments.return_value = [exp]

        mock_request_with_retries.side_effect = self._mock_request_side_effects(
            [
                (
                    exp,
                    [
                        self._make_test("test-1"),
                        self._make_test("test-2"),
                        self._make_test("test-3"),
                    ],
                )
            ]
        )

        mock_client_instance = AsyncMock()
        mock_client.return_value.__aenter__.return_value = mock_client_instance

        await poll_for_completions()
        await asyncio.sleep(0.05)  # let fire-and-forget tasks run

        self.assertIn("test-1", dispatched_ids)
        self.assertNotIn("test-2", dispatched_ids)
        self.assertIn("test-3", dispatched_ids)

    @mock.patch("src.snowglobe.client.src.app._dispatch_completion_request")
    @mock.patch("src.snowglobe.client.src.app._request_with_retries")
    @mock.patch("httpx.AsyncClient")
    @mock.patch("src.snowglobe.client.src.app.fetch_experiments")
    async def test_already_responded_tests_skipped(
        self,
        mock_fetch_experiments,
        mock_client,
        mock_request_with_retries,
        mock_dispatch,
    ):
        """Tests that already have a response are not dispatched."""
        import asyncio

        dispatched_ids = []

        async def record_dispatch(client, test, app_id, simulation_name):
            dispatched_ids.append(test["id"])
            return True

        mock_dispatch.side_effect = record_dispatch

        exp = self._make_experiment("exp-1")
        mock_fetch_experiments.return_value = [exp]

        mock_request_with_retries.side_effect = self._mock_request_side_effects(
            [
                (
                    exp,
                    [
                        self._make_test("test-1"),
                        self._make_test("test-2", response="already done"),
                        self._make_test("test-3"),
                    ],
                )
            ]
        )

        mock_client_instance = AsyncMock()
        mock_client.return_value.__aenter__.return_value = mock_client_instance

        await poll_for_completions()
        await asyncio.sleep(0.05)  # let fire-and-forget tasks run

        self.assertIn("test-1", dispatched_ids)
        self.assertNotIn("test-2", dispatched_ids)
        self.assertIn("test-3", dispatched_ids)


class TestTimeWindowedReporting(unittest.IsolatedAsyncioTestCase):
    """Tests for time-windowed completion reporting.

    The reporter should accumulate completion counts and emit a summary
    every REPORT_INTERVAL_TICKS poll ticks (default 15 = every 30s at 2s ticks),
    rather than after every batch.
    """

    def setUp(self):
        _reset_global_state()
        apps["app-1"] = {
            "completion_fn": lambda request: CompletionFunctionOutputs(response="ok")
        }
        # Reset the reporting state between tests
        import src.snowglobe.client.src.app as app_module

        app_module.completion_report_window.clear()
        app_module.poll_tick_counter = 0

    @mock.patch("src.snowglobe.client.src.app._dispatch_completion_request")
    @mock.patch("src.snowglobe.client.src.app._request_with_retries")
    @mock.patch("httpx.AsyncClient")
    @mock.patch("src.snowglobe.client.src.app.fetch_experiments")
    async def test_completions_accumulated_across_ticks(
        self,
        mock_fetch_experiments,
        mock_client,
        mock_request_with_retries,
        mock_dispatch,
    ):
        """Completions from multiple poll ticks accumulate in the report window."""
        import src.snowglobe.client.src.app as app_module

        async def instant_dispatch(client, test, app_id, simulation_name):
            return True

        mock_dispatch.side_effect = instant_dispatch

        exp = {"id": "exp-1", "app_id": "app-1", "name": "sim-1"}
        mock_fetch_experiments.return_value = [exp]

        def make_side_effects():
            exp_resp = MagicMock()
            exp_resp.is_success = True
            exp_resp.json.return_value = exp
            tests_resp = MagicMock()
            tests_resp.is_success = True
            tests_resp.json.return_value = [
                {
                    "id": f"test-{app_module.poll_tick_counter}",
                    "response": None,
                    "last_error": "",
                }
            ]
            return [exp_resp, tests_resp]

        mock_client_instance = AsyncMock()
        mock_client.return_value.__aenter__.return_value = mock_client_instance

        # Run 3 poll ticks (less than REPORT_INTERVAL_TICKS), each dispatching 1 test
        for i in range(3):
            mock_request_with_retries.side_effect = make_side_effects()
            await poll_for_completions()
            import asyncio

            await asyncio.sleep(0.01)

        # Completions should be accumulating, not reported yet
        self.assertGreater(
            sum(app_module.completion_report_window.values()),
            0,
            "Completions should accumulate in the report window",
        )

    @mock.patch("src.snowglobe.client.src.app.track_batch_completion")
    @mock.patch("src.snowglobe.client.src.app._dispatch_completion_request")
    @mock.patch("src.snowglobe.client.src.app._request_with_retries")
    @mock.patch("httpx.AsyncClient")
    @mock.patch("src.snowglobe.client.src.app.fetch_experiments")
    async def test_report_emitted_at_interval(
        self,
        mock_fetch_experiments,
        mock_client,
        mock_request_with_retries,
        mock_dispatch,
        mock_track_batch,
    ):
        """After REPORT_INTERVAL_TICKS ticks, accumulated completions are reported."""
        import asyncio
        import src.snowglobe.client.src.app as app_module

        report_interval = app_module.REPORT_INTERVAL_TICKS

        async def instant_dispatch(client, test, app_id, simulation_name):
            return True

        mock_dispatch.side_effect = instant_dispatch

        exp = {"id": "exp-1", "app_id": "app-1", "name": "sim-1"}
        mock_fetch_experiments.return_value = [exp]

        mock_client_instance = AsyncMock()
        mock_client.return_value.__aenter__.return_value = mock_client_instance

        # Run (REPORT_INTERVAL_TICKS - 1) ticks dispatching 1 test each,
        # then wait for tasks to finish, then run the final tick which triggers the report.
        for i in range(report_interval - 1):
            exp_resp = MagicMock()
            exp_resp.is_success = True
            exp_resp.json.return_value = exp
            tests_resp = MagicMock()
            tests_resp.is_success = True
            tests_resp.json.return_value = [
                {"id": f"test-{i}", "response": None, "last_error": ""}
            ]
            mock_request_with_retries.side_effect = [exp_resp, tests_resp]
            await poll_for_completions()
            await asyncio.sleep(0.01)

        # Let all fire-and-forget tasks from earlier ticks complete
        await asyncio.sleep(0.05)

        # Final tick triggers the report
        exp_resp = MagicMock()
        exp_resp.is_success = True
        exp_resp.json.return_value = exp
        tests_resp = MagicMock()
        tests_resp.is_success = True
        tests_resp.json.return_value = [
            {"id": f"test-{report_interval - 1}", "response": None, "last_error": ""}
        ]
        mock_request_with_retries.side_effect = [exp_resp, tests_resp]
        await poll_for_completions()

        # Report should have been emitted and window cleared
        self.assertEqual(
            sum(app_module.completion_report_window.values()),
            0,
            "Report window should be cleared after reporting",
        )

    @mock.patch("src.snowglobe.client.src.app._dispatch_completion_request")
    @mock.patch("src.snowglobe.client.src.app._request_with_retries")
    @mock.patch("httpx.AsyncClient")
    @mock.patch("src.snowglobe.client.src.app.fetch_experiments")
    async def test_no_report_when_no_completions(
        self,
        mock_fetch_experiments,
        mock_client,
        mock_request_with_retries,
        mock_dispatch,
    ):
        """No report is emitted when there are zero completions in the window."""
        import asyncio
        import src.snowglobe.client.src.app as app_module

        report_interval = app_module.REPORT_INTERVAL_TICKS

        mock_fetch_experiments.return_value = []

        mock_client_instance = AsyncMock()
        mock_client.return_value.__aenter__.return_value = mock_client_instance

        for _ in range(report_interval):
            await poll_for_completions()
            await asyncio.sleep(0.01)

        # Window should be empty — no completions, no report
        self.assertEqual(sum(app_module.completion_report_window.values()), 0)

    @mock.patch("src.snowglobe.client.src.app.info")
    @mock.patch("src.snowglobe.client.src.app._dispatch_completion_request")
    @mock.patch("src.snowglobe.client.src.app._request_with_retries")
    @mock.patch("httpx.AsyncClient")
    @mock.patch("src.snowglobe.client.src.app.fetch_experiments")
    async def test_inflight_count_shown_when_no_completions(
        self,
        mock_fetch_experiments,
        mock_client,
        mock_request_with_retries,
        mock_dispatch,
        mock_info,
    ):
        """When the report interval fires with no completions but tests are
        in-flight, the inflight count is shown to the user."""
        import asyncio
        import time as _time
        import src.snowglobe.client.src.app as app_module

        report_interval = app_module.REPORT_INTERVAL_TICKS

        mock_fetch_experiments.return_value = []
        mock_client_instance = AsyncMock()
        mock_client.return_value.__aenter__.return_value = mock_client_instance

        # Simulate 2 tests in-flight
        queued_tests["test-a"] = _time.time()
        queued_tests["test-b"] = _time.time()

        for _ in range(report_interval):
            await poll_for_completions()
            await asyncio.sleep(0.01)

        # info() should have been called with the inflight message
        inflight_calls = [
            call for call in mock_info.call_args_list if "in flight" in str(call)
        ]
        self.assertTrue(
            len(inflight_calls) > 0,
            "Expected an inflight status message when no completions but tests are in flight",
        )
        self.assertIn("2", str(inflight_calls[0]))

    @mock.patch("src.snowglobe.client.src.app.info")
    @mock.patch("src.snowglobe.client.src.app._dispatch_completion_request")
    @mock.patch("src.snowglobe.client.src.app._request_with_retries")
    @mock.patch("httpx.AsyncClient")
    @mock.patch("src.snowglobe.client.src.app.fetch_experiments")
    async def test_terminal_experiment_reported(
        self,
        mock_fetch_experiments,
        mock_client,
        mock_request_with_retries,
        mock_dispatch,
        mock_info,
    ):
        """When an experiment transitions to terminal state, it is reported."""
        import asyncio

        import src.snowglobe.client.src.app as app_module

        report_interval = app_module.REPORT_INTERVAL_TICKS

        exp = {"id": "exp-1", "app_id": "app-1", "name": "sim-1"}

        # First tick: experiment is active (state_num < 17).
        active_resp = MagicMock()
        active_resp.is_success = True
        active_resp.json.return_value = {**exp, "state_num": 5}
        tests_resp = MagicMock()
        tests_resp.is_success = True
        tests_resp.json.return_value = []

        mock_fetch_experiments.return_value = [exp]
        mock_request_with_retries.side_effect = [active_resp, tests_resp]

        await poll_for_completions()
        await asyncio.sleep(0.01)

        # Verify experiment is now tracked as active.
        self.assertIn("exp-1", app_module._known_active_experiments)

        # Subsequent ticks: experiment reaches terminal state (state_num >= 17).
        terminal_resp = MagicMock()
        terminal_resp.is_success = True
        terminal_resp.json.return_value = {**exp, "state_num": 17}

        # Run remaining ticks to hit the report interval.
        for i in range(1, report_interval):
            mock_request_with_retries.side_effect = [terminal_resp]
            await poll_for_completions()
            await asyncio.sleep(0.01)

        # info() should have been called with the terminal transition message.
        terminal_calls = [
            call for call in mock_info.call_args_list if "completed" in str(call)
        ]
        self.assertTrue(
            len(terminal_calls) > 0,
            "Expected a terminal transition message for 'sim-1'",
        )
        self.assertIn("sim-1", str(terminal_calls[0]))

        # Experiment should no longer be in the known active set.
        self.assertNotIn("exp-1", app_module._known_active_experiments)

    @mock.patch("src.snowglobe.client.src.app.info")
    @mock.patch("src.snowglobe.client.src.app._dispatch_completion_request")
    @mock.patch("src.snowglobe.client.src.app._request_with_retries")
    @mock.patch("httpx.AsyncClient")
    @mock.patch("src.snowglobe.client.src.app.fetch_experiments")
    async def test_terminal_not_reported_if_never_seen_active(
        self,
        mock_fetch_experiments,
        mock_client,
        mock_request_with_retries,
        mock_dispatch,
        mock_info,
    ):
        """An experiment first seen in terminal state should NOT trigger a transition report."""
        import asyncio

        import src.snowglobe.client.src.app as app_module

        report_interval = app_module.REPORT_INTERVAL_TICKS

        exp = {"id": "exp-2", "app_id": "app-1", "name": "old-sim"}

        terminal_resp = MagicMock()
        terminal_resp.is_success = True
        terminal_resp.json.return_value = {**exp, "state_num": 20}

        mock_fetch_experiments.return_value = [exp]

        for _ in range(report_interval):
            mock_request_with_retries.side_effect = [terminal_resp]
            await poll_for_completions()
            await asyncio.sleep(0.01)

        # No terminal transition should be reported.
        terminal_calls = [
            call for call in mock_info.call_args_list if "completed" in str(call)
        ]
        self.assertEqual(
            len(terminal_calls),
            0,
            "Should not report terminal transition for experiment never seen as active",
        )


class TestShutdownDrain(unittest.IsolatedAsyncioTestCase):
    """Tests for graceful shutdown behavior: inflight tasks drain before exit."""

    def setUp(self):
        _reset_global_state()
        apps["app-1"] = {
            "completion_fn": lambda request: CompletionFunctionOutputs(response="ok")
        }

    @mock.patch("src.snowglobe.client.src.app._dispatch_completion_request")
    @mock.patch("src.snowglobe.client.src.app._request_with_retries")
    @mock.patch("httpx.AsyncClient")
    @mock.patch("src.snowglobe.client.src.app.fetch_experiments")
    async def test_shutdown_skips_new_dispatches(
        self,
        mock_fetch_experiments,
        mock_client,
        mock_request_with_retries,
        mock_dispatch,
    ):
        """When shutdown is requested, poll_for_completions does not dispatch new tests."""
        from src.snowglobe.client.src.cli_utils import shutdown_manager

        dispatched_ids = []

        async def record_dispatch(client, test, app_id, simulation_name):
            dispatched_ids.append(test["id"])
            return True

        mock_dispatch.side_effect = record_dispatch

        # Request shutdown before polling
        shutdown_manager.shutdown_event.set()

        try:
            await poll_for_completions()
            self.assertEqual(
                dispatched_ids, [], "No tests should be dispatched during shutdown"
            )
            mock_fetch_experiments.assert_not_called()
        finally:
            shutdown_manager.shutdown_event.clear()

    @mock.patch("src.snowglobe.client.src.app._dispatch_completion_request")
    @mock.patch("src.snowglobe.client.src.app._request_with_retries")
    @mock.patch("httpx.AsyncClient")
    @mock.patch("src.snowglobe.client.src.app.fetch_experiments")
    async def test_inflight_tasks_complete_before_poll_exits(
        self,
        mock_fetch_experiments,
        mock_client,
        mock_request_with_retries,
        mock_dispatch,
    ):
        """Dispatched tasks that are already in-flight should complete even
        when the next poll detects shutdown."""
        import asyncio

        completed = []

        async def slow_dispatch(client, test, app_id, simulation_name):
            await asyncio.sleep(0.1)
            completed.append(test["id"])
            return True

        mock_dispatch.side_effect = slow_dispatch

        exp = {"id": "exp-1", "app_id": "app-1", "name": "sim-1"}
        mock_fetch_experiments.return_value = [exp]

        exp_resp = MagicMock()
        exp_resp.is_success = True
        exp_resp.json.return_value = exp
        tests_resp = MagicMock()
        tests_resp.is_success = True
        tests_resp.json.return_value = [
            {"id": "inflight-1", "response": None, "last_error": ""},
        ]
        mock_request_with_retries.side_effect = [exp_resp, tests_resp]

        mock_client_instance = AsyncMock()
        mock_client.return_value.__aenter__.return_value = mock_client_instance

        # Dispatch a test (fire-and-forget)
        await poll_for_completions()

        # Task is running in background, let it finish
        await asyncio.sleep(0.2)

        # The task should have completed despite being fire-and-forget
        self.assertIn("inflight-1", completed)


class TestFastAPIApp(unittest.TestCase):
    def setUp(self):
        self.app = create_client()

    def test_create_client_returns_fastapi_app(self):
        from fastapi import FastAPI

        self.assertIsInstance(self.app, FastAPI)

    @mock.patch("uvicorn.run")
    def test_start_client(self, mock_uvicorn_run):
        start_client()
        mock_uvicorn_run.assert_called_once()
        args, kwargs = mock_uvicorn_run.call_args
        self.assertEqual(kwargs["host"], "0.0.0.0")
        self.assertEqual(kwargs["port"], 8000)
        self.assertEqual(kwargs["log_level"], "warning")


if __name__ == "__main__":
    unittest.main()
