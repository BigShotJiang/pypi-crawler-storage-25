# neruva-control

> **Status (v0.10.0+, 2026-05-18):** Maintenance-only. Original role —
> running Neruva Computer and Neruva Code agents on your laptop — was
> retired in the 2026-05-18 substrate-first pivot. The Cockpit chat UI
> moved to neruva.io/cockpit as a hosted [Memory Inspector](https://neruva.io/cockpit).
> For new installs, see [neruva-mcp](https://pypi.org/project/neruva-mcp/) +
> [neruva-record](https://pypi.org/project/neruva-record/).

This daemon used to drive two on-device agents (screen control + code editing)
from the Neruva Cockpit web UI. Both agents were archived to `_attic/` in
this release; the daemon survives as a small loopback service for users who
still want to host a local control plane for custom agent harnesses they
build on the Neruva substrate.

If you don't have a specific need for `neruva-control`, you almost certainly
want one of these instead:

| You want | Install |
|---|---|
| **Persistent memory in Claude Code / Cursor / any MCP agent** | `pip install neruva-mcp` &mdash; or use `@neruva/mcp` on npm |
| **Auto-record every Claude Code session to your Neruva memory** | `pip install neruva-record && neruva-record-install` |
| **Browse / query / replay records in a web UI** | https://neruva.io/cockpit (hosted, no install) |
| **Raw REST against the substrate** | `curl https://api.neruva.io/v1/records/ingest -H "Api-Key: ..."` |

## What's still here

- A FastAPI process bound to `127.0.0.1:7331` with auth-token gating
- A session model + WebSocket stream you can wire your own agent into
- Project / file-tree / wallet endpoints used by `neruva-record`'s hook flow

## What was removed in v0.10.0

- `_agent.py` (Neruva Computer agent loop) &rarr; `_attic/_agent.py`
- `_code_agent.py` (Neruva Code agent loop) &rarr; `_attic/_code_agent.py`
- `_browser.py`, `_axtree.py`, `_ocr.py`, `_skills.py`, `_repo_map.py`,
  `_lsp.py`, `_indexer.py`, `_tool_catalog.py` &rarr; all `_attic/`
- Optional-dep extras `[agent]` (pyautogui / pillow / playwright / pyright /
  pytesseract / pygetwindow / uiautomation) &mdash; no longer needed
- All `agent_type=computer|code` spawning paths in `_sessions.py` &mdash;
  stubbed to raise `RuntimeError`

The full file history lives in `_attic/` if you need to lift anything out.

## Install

```bash
pip install neruva-control
neruva-control-install
```

## Privacy

- Daemon listens on `127.0.0.1` only &mdash; never on a network interface
- Sessions stream over loopback WebSocket; never leave your machine in transit
- Memory writes (via `neruva-record` or your own client) go to your Neruva
  account over HTTPS, with client-side 14-pattern secrets redaction

## License

MIT &mdash; see [LICENSE](./LICENSE).
