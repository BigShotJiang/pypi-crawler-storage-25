"""CLI entry-point for `neruva-control`.

Subcommands:
  start   -- run the daemon in the foreground (blocks). Used by the OS
             service registration. Power users can run it manually.
  stop    -- find a running daemon and SIGTERM it.
  status  -- print health: token present? daemon listening? PID?
  link    -- print the fragment URL again (for re-link or new browser).
  serve   -- alias for start (matches `uvicorn` muscle memory).
"""
from __future__ import annotations

import argparse
import signal
import socket
import sys
import time
from pathlib import Path

from . import __version__
from ._config import (
    config_dir, cockpit_link_url, load_token, token_path,
    load_env_files, env_file_path,
)


PORT = 7331


def _is_listening(host: str = "127.0.0.1", port: int = PORT, timeout: float = 0.5) -> bool:
    """True if something is bound to host:port. Used by `status` and by
    install's "is the service already up" check."""
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(timeout)
    try:
        s.connect((host, port))
        s.close()
        return True
    except OSError:
        return False


def _cmd_start(args: argparse.Namespace) -> int:
    # Auto-load .env from ~/.config/neruva/.env (preferred) and ./.env
    # (dev convenience) BEFORE importing the daemon module. The agent
    # modules read HOLO3_API_KEY / MISTRAL_API_KEY / NERUVA_API_KEY at
    # import time, so env must be set before those imports trigger.
    n_loaded = load_env_files()
    if n_loaded:
        print(f"[neruva-control] loaded {n_loaded} env var(s) from {env_file_path()}",
              file=sys.stderr)
    from .daemon import serve
    host = args.bind or "127.0.0.1"
    port = args.port or PORT
    if host != "127.0.0.1":
        print(
            f"[neruva-control] WARNING: binding on {host}:{port} -- this exposes the daemon\n"
            f"  beyond loopback. The auth token is the only thing protecting the API.\n"
            f"  Recommended for remote access: Tailscale Serve over loopback instead.\n",
            file=sys.stderr,
        )
    serve(host=host, port=port)
    return 0


def _cmd_status(_args: argparse.Namespace) -> int:
    has_token = token_path().exists()
    listening = _is_listening()
    print(f"neruva-control {__version__}")
    print(f"  config dir : {config_dir()}")
    print(f"  token      : {'present' if has_token else 'MISSING (run neruva-control-install)'}")
    print(f"  daemon     : {'listening on 127.0.0.1:' + str(PORT) if listening else 'NOT running'}")
    if has_token:
        try:
            token = load_token()
            print(f"  link URL   : {cockpit_link_url(token)}")
        except Exception:
            pass
    return 0 if (has_token and listening) else 1


def _cmd_link(_args: argparse.Namespace) -> int:
    try:
        token = load_token()
    except FileNotFoundError as e:
        print(str(e), file=sys.stderr)
        return 1
    print()
    print("Open this URL in your browser to link this machine to Cockpit:")
    print()
    print(f"  {cockpit_link_url(token)}")
    print()
    print("(Token will be stashed in your browser's localStorage; the URL")
    print(" fragment is stripped after first load. Same machine, same browser.)")
    return 0


def _cmd_stop(_args: argparse.Namespace) -> int:
    """Best-effort daemon stop. Reads PID from pidfile if present;
    falls back to telling user to kill it themselves on weird OSes."""
    pidfile = config_dir() / "control.pid"
    if not pidfile.exists():
        print("No pidfile -- daemon not started by neruva-control or already stopped.")
        return 0 if not _is_listening() else 1
    try:
        pid = int(pidfile.read_text().strip())
    except Exception:
        print(f"Bad pidfile at {pidfile}; remove it manually.", file=sys.stderr)
        return 1
    try:
        if sys.platform == "win32":
            import ctypes
            PROCESS_TERMINATE = 1
            handle = ctypes.windll.kernel32.OpenProcess(PROCESS_TERMINATE, False, pid)
            if handle:
                ctypes.windll.kernel32.TerminateProcess(handle, 0)
                ctypes.windll.kernel32.CloseHandle(handle)
        else:
            import os as _os
            _os.kill(pid, signal.SIGTERM)
        # Wait briefly for socket to free
        for _ in range(20):
            if not _is_listening():
                break
            time.sleep(0.1)
        try: pidfile.unlink()
        except Exception: pass
        print(f"Stopped daemon (pid {pid}).")
        return 0
    except ProcessLookupError:
        print("Daemon process already gone.")
        try: pidfile.unlink()
        except Exception: pass
        return 0
    except Exception as e:
        print(f"Failed to stop pid {pid}: {e}", file=sys.stderr)
        return 1


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="neruva-control",
        description="Local controller daemon for Neruva Cockpit.",
    )
    parser.add_argument("--version", action="version", version=__version__)
    sub = parser.add_subparsers(dest="cmd", required=True)
    p_start = sub.add_parser("start", help="Run the daemon (foreground; blocks).")
    p_start.add_argument("--bind", default=None,
                         help="Bind address (default 127.0.0.1, loopback only). Pass "
                              "0.0.0.0 to expose on LAN -- only do this if you trust "
                              "your network. For remote access prefer Tailscale Serve.")
    p_start.add_argument("--port", type=int, default=None, help=f"Port (default {PORT})")
    p_serve = sub.add_parser("serve", help="Alias for start.")
    p_serve.add_argument("--bind", default=None)
    p_serve.add_argument("--port", type=int, default=None)
    sub.add_parser("status", help="Show install + daemon status.")
    sub.add_parser("link", help="Print the browser link URL.")
    sub.add_parser("stop", help="Stop the daemon.")
    p_index = sub.add_parser("index",
        help="Index a project for semantic code search (substrate-backed).")
    p_index.add_argument("path", help="Project root directory")
    p_index.add_argument("--namespace", default="code_index")
    p_index.add_argument("--max-files", type=int, default=500)
    p_index.add_argument("--project-tag", default=None)
    p_index.add_argument("--quiet", action="store_true")
    args = parser.parse_args(argv)

    def _cmd_index(args) -> int:
        # Indexer was Code-agent specific; archived to _attic/ in v0.10.0.
        # Kept here as a CLI stub for backwards-compat.
        try:
            from ._attic._indexer import index_project  # noqa: F401
        except ImportError:
            print("ERROR: index command archived in v0.10.0. "
                  "Use api.neruva.io /v1/records/* directly.")
            return 2
        from ._attic._indexer import index_project
        try:
            stats = index_project(
                args.path, namespace=args.namespace,
                max_files=args.max_files, project_tag=args.project_tag,
                verbose=not args.quiet,
            )
            import json as _json
            print(_json.dumps(stats, indent=2))
            return 0
        except Exception as e:
            print(f"index failed: {e}", file=sys.stderr)
            return 1

    handler = {
        "start": _cmd_start,
        "serve": _cmd_start,
        "status": _cmd_status,
        "link": _cmd_link,
        "stop": _cmd_stop,
        "index": _cmd_index,
    }.get(args.cmd)
    if not handler:
        parser.print_help()
        return 2
    return handler(args)


if __name__ == "__main__":
    sys.exit(main())
