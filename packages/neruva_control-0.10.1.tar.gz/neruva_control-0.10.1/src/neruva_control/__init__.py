"""Neruva Control -- the local daemon behind Neruva Cockpit.

The browser at neruva.io/cockpit connects to this daemon over a
loopback WebSocket (localhost:7331) to run Neruva agents on the
user's machine:

- Neruva Computer -- sees your screen, clicks, types, runs apps
- Neruva Code     -- writes code, edits files, runs commands, debugs

Install: ``pip install "neruva-control[agent]" && neruva-control-install``

After install, open https://neruva.io/cockpit -- the installer prints
a one-time URL with your machine's auth token.

Public surface for library users (rare; most users only need the CLI):

    from neruva_control import daemon  # FastAPI app
    from neruva_control._sessions import SessionManager
"""
from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version as _pkg_version

try:
    __version__ = _pkg_version("neruva-control")
except PackageNotFoundError:
    __version__ = "0.0.0+local"

__all__ = ["__version__"]
