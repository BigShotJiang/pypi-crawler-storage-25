"""ViSP base class."""

from abc import ABC

from dkist_processing_common.codecs.basemodel import basemodel_encoder
from dkist_processing_common.models.metric_code import MetricCode
from dkist_processing_common.models.quality import TaskCount
from dkist_processing_common.tasks import WorkflowTaskBase

from dkist_processing_visp.models.constants import VispConstants
from dkist_processing_visp.models.parameters import VispParameters
from dkist_processing_visp.models.tags import VispTag


class VispTaskBase(WorkflowTaskBase, ABC):
    """
    Task class for base ViSP tasks.

    Parameters
    ----------
    recipe_run_id : int
        id of the recipe run used to identify the workflow run this task is part of
    workflow_name : str
        name of the workflow to which this instance of the task belongs
    workflow_version : str
        version of the workflow to which this instance of the task belongs
    """

    # So tab completion shows all the ViSP constants
    constants: VispConstants

    @property
    def constants_model_class(self):
        """Get ViSP pipeline constants."""
        return VispConstants

    def __init__(
        self,
        recipe_run_id: int,
        workflow_name: str,
        workflow_version: str,
    ):
        super().__init__(
            recipe_run_id=recipe_run_id,
            workflow_name=workflow_name,
            workflow_version=workflow_version,
        )
        self.parameters = VispParameters(
            scratch=self.scratch,
            obs_ip_start_time=self.constants.obs_ip_start_time,
            wavelength=self.constants.wavelength,
            arm_id=self.constants.arm_id,
        )

    def quality_write_intermediate_task_type_counts(
        self, task_type: str, total_frames: int, frames_not_used: int = 0
    ):
        """
        Write intermediate task type data.

        Parameters
        ----------
        task_type:
        task type as listed in the headers
        total_frames:
        total number of frames supplied of the given task type
        frames_not_used:
        if some frames aren't used, how many
        """
        task_count = TaskCount(
            task_type=task_type,
            total_frames=total_frames,
            frames_not_used=frames_not_used,
        )
        self.write(
            task_count, tags=VispTag.quality(MetricCode.task_types), encoder=basemodel_encoder
        )
