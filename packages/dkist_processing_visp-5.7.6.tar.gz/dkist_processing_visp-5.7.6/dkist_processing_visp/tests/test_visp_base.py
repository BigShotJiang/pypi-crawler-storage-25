import pytest
from dkist_processing_common.codecs.basemodel import basemodel_decoder
from dkist_processing_common.models.quality import TaskCount

from dkist_processing_visp.tasks.visp_base import VispTaskBase
from dkist_processing_visp.tests.conftest import VispConstantsDb


@pytest.fixture(scope="function")
def visp_base_task(recipe_run_id, init_visp_constants_db):
    class DummyTask(VispTaskBase):
        def run(self):
            pass

    init_visp_constants_db(recipe_run_id, VispConstantsDb())
    task = DummyTask(
        recipe_run_id=recipe_run_id,
        workflow_name="visp_dummy_task",
        workflow_version="VX.Y",
    )

    yield task
    task._purge()


@pytest.mark.parametrize(
    "task_type, total_frames, frames_not_used",
    [
        pytest.param("one", 1, 1, id="simple"),
        pytest.param("two", 2, 0, id="not_used_zero"),
        pytest.param("three", 3, None, id="not_used_none"),
    ],
)
def test_quality_write_intermediate_task_type_counts(
    task_type: str, total_frames: int, frames_not_used: int | None, visp_base_task
):
    """
    Given: Valid intermediate task type count input
    When: Running VispTaskBase quality_write_intermediate_task_type_counts()
    Then: A single TaskCount file gets created
    """
    # Given
    task = visp_base_task

    # When
    if frames_not_used is not None:
        task.quality_write_intermediate_task_type_counts(task_type, total_frames, frames_not_used)
    else:
        task.quality_write_intermediate_task_type_counts(task_type, total_frames)

    # Then
    task_counts: list[TaskCount] = list(
        task.read(tags="QUALITY_TASK_TYPES", decoder=basemodel_decoder, model=TaskCount)
    )
    assert isinstance(task_counts, list)
    assert len(task_counts) == 1
    task_count = task_counts[0]
    assert task_count.task_type == str(task_type).upper()
    assert task_count.total_frames == total_frames
    if frames_not_used is not None:
        assert task_count.frames_not_used == frames_not_used
    else:
        assert task_count.frames_not_used == 0
