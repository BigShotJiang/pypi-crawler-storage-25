# -*- coding: utf-8 -*-
#
# Copyright (C) 2019-2025 CERN.
# Copyright (C) 2019-2022 Northwestern University.
# Copyright (C) 2024-2025 Graz University of Technology.
# Copyright (C) 2025 KTH Royal Institute of Technology.
#
# Invenio App RDM is free software; you can redistribute it and/or modify it
# under the terms of the MIT License; see LICENSE file for more details.

"""Invenio App RDM."""

# Note, that dev versions must have an extra dot compared to alpha/beta/rc
# versions in the version string. Examples:
#
# Correct: "1.0.0.dev0" and "1.0.0a1" and "1.0.0rc1"
# Incorrect: "1.0.0dev0" and "1.0.0.a1" and "1.0.0.rc1"
#
# See PEP 0440 for details - https://www.python.org/dev/peps/pep-0440

__version__ = "13.1.0"

__all__ = ("__version__",)
