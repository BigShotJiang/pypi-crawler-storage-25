from pathlib import Path

import rich_click as click

from . import __version__, srv_main

click.rich_click.MAX_WIDTH = 100

click.rich_click.COMMANDS_PANEL_TITLE = 'commands'
click.rich_click.OPTIONS_PANEL_TITLE = 'options'
click.rich_click.COMMANDS_BEFORE_OPTIONS = True

click.rich_click.STYLE_OPTION = 'bold blue'
click.rich_click.STYLE_ARGUMENT = 'bold blue'
click.rich_click.STYLE_COMMAND = 'bold blue'
click.rich_click.STYLE_SWITCH = 'bold red'
click.rich_click.STYLE_METAVAR = 'bold red'
click.rich_click.STYLE_METAVAR_SEPARATOR = 'dim'
click.rich_click.STYLE_USAGE = 'bold yellow'
click.rich_click.STYLE_USAGE_COMMAND = 'bold'
click.rich_click.STYLE_HELPTEXT_FIRST_LINE = ''
click.rich_click.STYLE_HELPTEXT = 'dim'
click.rich_click.STYLE_OPTION_DEFAULT = 'dim'
click.rich_click.STYLE_REQUIRED_SHORT = 'bold yellow'
click.rich_click.STYLE_REQUIRED_LONG = 'bold yellow'
click.rich_click.STYLE_OPTIONS_PANEL_BORDER = 'dim'
click.rich_click.STYLE_COMMANDS_PANEL_BORDER = 'dim'


@click.command(context_settings=dict(help_option_names=['-h', '--help']), add_help_option=True)
@click.option(
    '--artwork-root',
    default=None,
    type=click.Path(file_okay=False, dir_okay=True, exists=False, path_type=Path),
    help='Root directory for artwork SVGs | envar: AXICTRL_ARTWORKS.',
)
@click.option(
    '--config-dir',
    default=None,
    type=click.Path(file_okay=False, dir_okay=True, exists=False, path_type=Path),
    help='Directory to store config and logs | envar: AXICTRL_CONFIG_DIR.',
)
@click.option(
    '--host',
    default='0.0.0.0',
    show_default=True,
    help='Host to bind the server.',
)
@click.option(
    '--port',
    default=5050,
    type=int,
    show_default=True,
    help='Port to bind the server.',
)
@click.option(
    '--dev',
    is_flag=True,
    help='Skip hardware connection checks for local development',
)
def cli(dev, artwork_root, config_dir, host, port) -> None:
    click.echo(f'axi_control: v{__version__}\n')

    srv_main.main(
        artwork_root=artwork_root,
        config_dir=config_dir,
        host=host,
        port=port,
        dev=dev,
    )


if __name__ == '__main__':
    cli(prog_name='axicontrol-server')
