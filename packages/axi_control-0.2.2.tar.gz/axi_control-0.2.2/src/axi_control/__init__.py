from importlib.metadata import version

__version__ = version('axi_control')


from . import utils as ut
from .axicontroller import AxiController as AxiController
from .routes import control, plotting, status
from .servercontext import ServerContext as ServerContext

__all__ = ['AxiController', 'control', 'status', 'plotting', 'ServerContext', 'ut', '__version__']
