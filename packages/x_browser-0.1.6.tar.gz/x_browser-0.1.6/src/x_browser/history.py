"""Persistent history of processed tweet IDs.

Stores tweet IDs in a simple text file so scripts don't re-process
tweets across runs. Each script/action combo gets its own history file.
"""

from __future__ import annotations

from pathlib import Path

from .config import CONFIG_DIR

HISTORY_DIR = CONFIG_DIR / "history"


class History:
    """Track processed tweet IDs across runs."""

    def __init__(self, name: str) -> None:
        """Create a history tracker.

        Args:
            name: Identifier for this history (e.g. "search-like-comment",
                  "search-and-like"). Each name gets its own file.
        """
        HISTORY_DIR.mkdir(parents=True, exist_ok=True)
        self._path = HISTORY_DIR / f"{name}.txt"
        self._ids: set[str] = set()
        self._load()

    def _load(self) -> None:
        if self._path.exists():
            for line in self._path.read_text().splitlines():
                line = line.strip()
                if line:
                    self._ids.add(line)

    def __contains__(self, tweet_id: str) -> bool:
        return tweet_id in self._ids

    def add(self, tweet_id: str) -> None:
        """Mark a tweet ID as processed and persist immediately."""
        if tweet_id not in self._ids:
            self._ids.add(tweet_id)
            with self._path.open("a") as f:
                f.write(tweet_id + "\n")

    def __len__(self) -> int:
        return len(self._ids)
