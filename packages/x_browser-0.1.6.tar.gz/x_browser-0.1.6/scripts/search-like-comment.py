"""Search for a query on X, like each result in-place, and reply with AI-generated comments.

Uses OpenAI gpt-5-nano to generate respectful, generalist replies that carry
the discussion forward without making strong claims.

Usage:
    uv run --with openai python scripts/search-like-comment.py 'YC W26' --hours 5 --headed
    uv run --with openai python scripts/search-like-comment.py 'AI agents' --hours 3 --dry-run
    uv run --with openai python scripts/search-like-comment.py 'startups' --skip-like --hours 2

Requires OPENAI_API_KEY environment variable or .env file.
"""

from __future__ import annotations

import argparse
import asyncio
import os
import re
import sys
import time
from pathlib import Path

sys.path.insert(0, str(__import__("pathlib").Path(__file__).resolve().parent.parent / "src"))

from openai import OpenAI

from x_browser.browser import XBrowser
from x_browser.config import Config
from x_browser.actions import like_in_place, tweet_reply
from x_browser.history import History

SYSTEM_PROMPT = """\
You are replying to a tweet on X. Write a short reply (1-2 sentences, under 280 characters) that:
- Is respectful and positive in tone
- Carries the discussion forward with a thoughtful observation or question
- Stays generalist — no strong claims, no counter-arguments, no rigid opinions, no counter-facts
- Feels natural and conversational, not corporate or robotic
- Uses at least 2 emojis naturally woven into the reply
- Does not use hashtags

Reply with ONLY the tweet text, nothing else. No quotes, no prefixes, no explanation.
"""


def _load_api_key() -> str | None:
    """Load OpenAI API key: env var → project .env → ~/.config/x-browser/.env"""
    key = os.environ.get("OPENAI_API_KEY")
    if key:
        return key
    for env_path in [
        Path(__file__).resolve().parent.parent / ".env",
        Path.home() / ".config" / "x-browser" / ".env",
    ]:
        if env_path.exists():
            for line in env_path.read_text().splitlines():
                line = line.strip()
                if line.startswith("OPENAI_API_KEY="):
                    return line.split("=", 1)[1].strip().strip("'\"")
    return None


def generate_reply(client: OpenAI, tweet_text: str, author: str) -> str:
    """Generate a reply using OpenAI gpt-5-nano."""
    response = client.chat.completions.create(
        model="gpt-5-nano",
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {
                "role": "user",
                "content": f"Reply to this tweet by @{author}:\n\n{tweet_text}",
            },
        ],
        max_completion_tokens=1000,
    )
    content = response.choices[0].message.content
    return content.strip() if content else ""


async def _extract_articles_with_data(page) -> list[tuple[object, dict]]:
    results = []
    articles = await page.query_selector_all('article[data-testid="tweet"]')
    for article in articles:
        try:
            time_el = await article.query_selector("time")
            if not time_el:
                continue
            parent_a = await time_el.evaluate_handle("el => el.closest('a')")
            if not parent_a:
                continue
            href = await parent_a.get_attribute("href")
            if not href or "/status/" not in href:
                continue
            match = re.search(r"/status/(\d+)", href)
            if not match:
                continue

            tweet_id = match.group(1)
            url = f"https://x.com{href}"
            author = ""
            user_link = await article.query_selector('div[data-testid="User-Name"] a')
            if user_link:
                user_href = await user_link.get_attribute("href") or ""
                author = user_href.strip("/").split("/")[0]
            text = ""
            text_el = await article.query_selector('div[data-testid="tweetText"]')
            if text_el:
                text = (await text_el.inner_text()).strip()

            results.append((article, {"id": tweet_id, "url": url, "author": author, "text": text}))
        except Exception:
            continue
    return results


async def main():
    parser = argparse.ArgumentParser(description="Search, like & comment on X with AI replies")
    parser.add_argument("query", help="Search query (e.g. 'YC W26')")
    parser.add_argument("--hours", type=float, default=5, help="How long to run (default: 5)")
    parser.add_argument("--min-delay", type=float, default=None, help="Min delay between actions")
    parser.add_argument("--max-delay", type=float, default=None, help="Max delay between actions")
    parser.add_argument("--headed", action="store_true", help="Show browser window")
    parser.add_argument("--dry-run", action="store_true", help="Generate replies but don't post or like")
    parser.add_argument("--skip-like", action="store_true", help="Skip liking, only comment")
    args = parser.parse_args()

    api_key = _load_api_key()
    if not api_key:
        print("\u274c OPENAI_API_KEY not found.", file=sys.stderr)
        print("   Set it via:", file=sys.stderr)
        print("   1. export OPENAI_API_KEY='sk-...'", file=sys.stderr)
        print("   2. Add OPENAI_API_KEY=sk-... to x-browser/.env", file=sys.stderr)
        print("   3. Add OPENAI_API_KEY=sk-... to ~/.config/x-browser/.env", file=sys.stderr)
        sys.exit(1)

    client = OpenAI(api_key=api_key)

    config = Config.load()
    if args.min_delay is not None:
        config.min_politeness_delay = args.min_delay
    if args.max_delay is not None:
        config.max_politeness_delay = args.max_delay

    deadline = time.monotonic() + (args.hours * 3600)
    history = History("search-like-comment")
    processed_ids: set[str] = set(history._ids)  # start with persisted history
    stats = {"liked": 0, "commented": 0}
    dry_streak = 0

    print(f"\U0001f50d Searching for: {args.query}", file=sys.stderr)
    print(f"\u23f1\ufe0f  Running for {args.hours} hours", file=sys.stderr)
    print(f"\U0001f916 Model: gpt-5-nano", file=sys.stderr)
    if args.dry_run:
        print(f"\U0001f4cb DRY RUN \u2014 will generate replies but not post", file=sys.stderr)
    print("\u2500" * 50, file=sys.stderr)

    async with XBrowser(headless=not args.headed) as xb:
        page = xb.page

        encoded = args.query.replace(" ", "%20")
        search_url = f"https://x.com/search?q={encoded}&src=typed_query&f=live"
        await page.goto(search_url, wait_until="domcontentloaded")
        await page.wait_for_timeout(4000)

        while time.monotonic() < deadline:
            items = await _extract_articles_with_data(page)
            new_items = [(a, d) for a, d in items if d["id"] not in processed_ids]

            if not new_items:
                dry_streak += 1
                if dry_streak >= 15:
                    print(f"\n\U0001f504 Reloading search...", file=sys.stderr)
                    await page.goto(search_url, wait_until="domcontentloaded")
                    await page.wait_for_timeout(4000)
                    dry_streak = 0
                    continue
                await page.evaluate("window.scrollBy(0, 800)")
                await page.wait_for_timeout(2000)
                continue

            dry_streak = 0

            for article, data in new_items:
                if time.monotonic() >= deadline:
                    print("\n\u23f0 Time's up!", file=sys.stderr)
                    break

                text_preview = (data["text"][:60] + "...") if len(data["text"]) > 60 else data["text"]
                total = stats["liked"] + stats["commented"]
                print(f"\n\U0001f4cc [{total}] @{data['author']}: {text_preview}", file=sys.stderr)

                # Step 1: Like in-place (no navigation)
                if not args.skip_like and not args.dry_run:
                    result = await like_in_place(page, article, config=config)
                    if result.get("already_liked"):
                        print(f"   \u2705 Already liked", file=sys.stderr)
                    elif result.get("liked"):
                        stats["liked"] += 1
                        print(f"   \u2764\ufe0f  Liked", file=sys.stderr)

                # Step 2: Generate reply
                if not data["text"]:
                    print(f"   \u23ed\ufe0f  No text, skipping reply", file=sys.stderr)
                    processed_ids.add(data["id"])
                    history.add(data["id"])
                    continue

                try:
                    reply_text = generate_reply(client, data["text"], data["author"])
                    if not reply_text:
                        print(f"   \u23ed\ufe0f  LLM returned empty reply, skipping", file=sys.stderr)
                        processed_ids.add(data["id"])
                        history.add(data["id"])
                        continue
                    print(f"   \U0001f4ac Generated: {reply_text}", file=sys.stderr)
                except Exception as e:
                    print(f"   \u274c LLM failed: {e}", file=sys.stderr)
                    processed_ids.add(data["id"])
                    history.add(data["id"])
                    continue

                # Step 3: Post reply immediately (navigates to tweet, then back)
                if args.dry_run:
                    print(f"   \U0001f4e4 [DRY RUN] Would reply", file=sys.stderr)
                    stats["commented"] += 1
                else:
                    try:
                        await tweet_reply(page, data["url"], reply_text, config=config)
                        stats["commented"] += 1
                        print(f"   \u2705 Replied!", file=sys.stderr)
                    except Exception as e:
                        print(f"   \u274c Reply failed: {e}", file=sys.stderr)

                    # Navigate back to search
                    await page.goto(search_url, wait_until="domcontentloaded")
                    await page.wait_for_timeout(3000)
                    # Re-extract articles since we navigated — break inner loop
                    # and let outer loop re-query
                    processed_ids.add(data["id"])
                    history.add(data["id"])
                    break

                processed_ids.add(data["id"])

            # Scroll for more
            await page.evaluate("window.scrollBy(0, 800)")
            await page.wait_for_timeout(2000)

    print(f"\n\u2500" * 50, file=sys.stderr)
    print(f"\u2705 Done!", file=sys.stderr)
    print(f"   \u2764\ufe0f  Liked: {stats['liked']}", file=sys.stderr)
    print(f"   \U0001f4ac Commented: {stats['commented']}", file=sys.stderr)


if __name__ == "__main__":
    asyncio.run(main())
