# Import side effects: register all checks (fast, then weekly, then monthly).
from . import security_static_scan  # noqa: F401
from . import workflow_pin_hygiene  # noqa: F401
from . import dependabot_sanity  # noqa: F401
from . import requirements_consistency  # noqa: F401
from . import pycompile_smoke  # noqa: F401
from . import pytest_collect_only  # noqa: F401
from . import duplicate_test_basenames  # noqa: F401
from . import import_smoke  # noqa: F401
from . import outdated_pip_modern  # noqa: F401
from . import pip_audit_modern  # noqa: F401
from . import dependency_drift_report  # noqa: F401
from . import dry_inelegance_hotspots  # noqa: F401

