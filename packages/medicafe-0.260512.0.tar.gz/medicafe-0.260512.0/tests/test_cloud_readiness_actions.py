#!/usr/bin/env python
from __future__ import print_function

import os
import shutil
import tempfile
import unittest

try:
    from unittest.mock import MagicMock, patch
except ImportError:
    from mock import MagicMock, patch


class CloudReadinessActionsTests(unittest.TestCase):

    def _resolve_script(self, repo_root, python_exe, script_name):
        return (
            True,
            '',
            repo_root,
            os.path.join(repo_root, 'scripts', 'unified_model', script_name),
            None,
        )

    def test_phase_d_dat_smoke_launches_tracked_wrapper_with_attempt_metadata(self):
        from MediCafe import cloud_readiness as cr
        from MediCafe import cloud_readiness_actions as actions

        temp_root = tempfile.mkdtemp(prefix='mc_actions_')
        try:
            repo_root = os.path.join(temp_root, 'repo')
            lab_root = os.path.join(temp_root, 'lab')
            smoke_lab = os.path.join(repo_root, 'phase_d_dat_smoke_lab')
            state_path = os.path.join(lab_root, 'phase_d_dat_smoke_state.json')
            os.makedirs(os.path.join(repo_root, 'scripts', 'unified_model'))
            os.makedirs(lab_root)

            proc = MagicMock()
            proc.pid = 4321

            with patch.object(cr, '_resolve_unified_model_script', side_effect=self._resolve_script):
                with patch.object(cr, 'resolve_lab_root', return_value=lab_root):
                    with patch.object(cr, 'is_pipeline_running', return_value=False):
                        with patch.object(cr, 'phase_d_dat_smoke_state_path', return_value=state_path):
                            with patch.object(cr, 'begin_phase_d_dat_smoke_attempt', return_value=True):
                                with patch.object(cr.subprocess, 'Popen', return_value=proc) as popen_mock:
                                    ok, msg, meta = actions.run_phase_d_dat_smoke(
                                        repo_root,
                                        'python.exe',
                                        {'target_folder': 'target', 'source_folder': 'source'},
                                        reference_phase_d_summary_path='reference.json',
                                        recommendation_anchor_run_id='anchor-1',
                                        recommendation_context_run_id='context-1',
                                        recommendation_issue_code='issue-1',
                                    )

            self.assertTrue(ok)
            self.assertEqual(msg, '')
            self.assertTrue(meta.get('async_launch'))
            self.assertEqual(meta.get('pid'), 4321)
            self.assertTrue(meta.get('attempt_id'))
            self.assertTrue(meta.get('attempt_path'))
            self.assertTrue(meta.get('tracked_wrapper_script').endswith('run_tracked_diagnostic.py'))

            popen_mock.assert_called_once()
            cmd = popen_mock.call_args[0][0]
            kwargs = popen_mock.call_args[1]
            self.assertEqual(cmd[0], 'python.exe')
            self.assertTrue(cmd[1].endswith('run_tracked_diagnostic.py'))
            self.assertIn('--kind', cmd)
            self.assertEqual(cmd[cmd.index('--kind') + 1], 'phase_d_dat_smoke')
            self.assertIn('--lab-dir', cmd)
            self.assertEqual(cmd[cmd.index('--lab-dir') + 1], lab_root)
            self.assertIn('--attempt-id', cmd)
            self.assertEqual(cmd[cmd.index('--attempt-id') + 1], meta.get('attempt_id'))
            self.assertIn('--target-anchor-run-id', cmd)
            self.assertEqual(cmd[cmd.index('--target-anchor-run-id') + 1], 'anchor-1')
            self.assertIn('--target-context-run-id', cmd)
            self.assertEqual(cmd[cmd.index('--target-context-run-id') + 1], 'context-1')
            self.assertIn('--issue-code', cmd)
            self.assertEqual(cmd[cmd.index('--issue-code') + 1], 'issue-1')
            self.assertIn('--', cmd)
            child_cmd = cmd[cmd.index('--') + 1:]
            self.assertEqual(child_cmd[0], 'python.exe')
            self.assertTrue(child_cmd[1].endswith('run_phase_d_dat_smoke.py'))
            self.assertIn('--state-path', child_cmd)
            self.assertEqual(child_cmd[child_cmd.index('--state-path') + 1], state_path)
            self.assertIn('--attempt-id', child_cmd)
            self.assertEqual(child_cmd[child_cmd.index('--attempt-id') + 1], meta.get('attempt_id'))
            self.assertEqual(kwargs.get('cwd'), repo_root)
            self.assertEqual(kwargs.get('env').get('MEDICAFE_LAB_DIR'), smoke_lab)
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_phase_b_manual_launches_tracked_wrapper_without_terminal_output(self):
        from MediCafe import cloud_readiness as cr
        from MediCafe import cloud_readiness_actions as actions

        temp_root = tempfile.mkdtemp(prefix='mc_actions_phase_b_')
        try:
            repo_root = os.path.join(temp_root, 'repo')
            lab_root = os.path.join(temp_root, 'lab')
            os.makedirs(os.path.join(repo_root, 'scripts', 'unified_model'))
            os.makedirs(lab_root)

            proc = MagicMock()
            proc.pid = 9876

            with patch.object(cr, '_resolve_unified_model_script', side_effect=self._resolve_script):
                with patch.object(cr, 'resolve_lab_root', return_value=lab_root):
                    with patch.object(cr.subprocess, 'Popen', return_value=proc) as popen_mock:
                        ok, msg, meta = actions.run_phase_b_manual(
                            repo_root,
                            'python.exe',
                            {'target_folder': 'target', 'source_folder': 'source'},
                        )

            self.assertTrue(ok)
            self.assertEqual(msg, '')
            self.assertIsNone(meta)
            popen_mock.assert_called_once()
            cmd = popen_mock.call_args[0][0]
            kwargs = popen_mock.call_args[1]
            self.assertTrue(cmd[1].endswith('run_tracked_diagnostic.py'))
            self.assertIn('--kind', cmd)
            self.assertEqual(cmd[cmd.index('--kind') + 1], 'phase_b_manual')
            self.assertNotIn('--echo-child-output', cmd)
            self.assertIn('--', cmd)
            child_cmd = cmd[cmd.index('--') + 1:]
            self.assertEqual(child_cmd[0], 'python.exe')
            self.assertTrue(child_cmd[1].endswith('discover_artifacts.py'))
            self.assertEqual(kwargs.get('env').get('MEDICAFE_LAB_DIR'), lab_root)
            self.assertEqual(kwargs.get('env').get('target_folder'), 'target')
            self.assertEqual(kwargs.get('env').get('source_folder'), 'source')
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_open_phase_c_summary_uses_simple_phase_spec(self):
        from MediCafe import cloud_readiness as cr
        from MediCafe import cloud_readiness_actions as actions

        with patch.object(cr, 'resolve_lab_root', return_value='C:\\lab'):
            with patch.object(cr, '_find_latest_by_prefix', return_value=('C:\\lab\\reports\\ingest.json', '')) as find_mock:
                ok, msg, path = actions.open_phase_c_summary('C:\\repo')

        self.assertTrue(ok)
        self.assertEqual(msg, '')
        self.assertEqual(path, 'C:\\lab\\reports\\ingest.json')
        find_mock.assert_called_once_with(
            os.path.join('C:\\lab', 'reports'),
            'ingest_write_summary_',
            ('.txt', '.json'),
        )

    def test_send_phase_d_evidence_uses_simple_phase_spec(self):
        from MediCafe import cloud_readiness as cr
        from MediCafe import cloud_readiness_actions as actions

        with patch.object(cr, 'resolve_lab_root', return_value='C:\\lab'):
            with patch.object(cr, '_send_phase_evidence', return_value=(True, '', None)) as send_mock:
                ok, msg, meta = actions.send_phase_d_evidence('C:\\repo')

        self.assertTrue(ok)
        self.assertEqual(msg, '')
        self.assertIsNone(meta)
        send_mock.assert_called_once_with(
            'C:\\lab',
            [('qa_canonical_summary_', None), ('qa_reject_samples_', '.jsonl')],
            'phase_d_evidence',
            'No Phase D summaries or reject samples to attach.',
        )

    def test_run_phase_d_manual_preserves_phase_d_classes_env(self):
        from MediCafe import cloud_readiness as cr
        from MediCafe import cloud_readiness_actions as actions

        temp_root = tempfile.mkdtemp(prefix='mc_actions_phase_d_')
        try:
            repo_root = os.path.join(temp_root, 'repo')
            lab_root = os.path.join(temp_root, 'lab')
            os.makedirs(os.path.join(repo_root, 'scripts', 'unified_model'))
            os.makedirs(lab_root)

            proc = MagicMock()
            proc.pid = 2468

            with patch.object(cr, '_resolve_unified_model_script', side_effect=self._resolve_script):
                with patch.object(cr, 'resolve_lab_root', return_value=lab_root):
                    with patch.object(cr, '_normalize_phase_d_reprocess_classes', return_value=['csv', 'docx']):
                        with patch.object(cr.subprocess, 'Popen', return_value=proc) as popen_mock:
                            ok, msg, meta = actions.run_phase_d_manual(
                                repo_root,
                                'python.exe',
                                {},
                                artifact_classes=['csv', 'docx'],
                            )

            self.assertTrue(ok)
            self.assertEqual(msg, '')
            self.assertIsNone(meta)
            kwargs = popen_mock.call_args[1]
            self.assertEqual(kwargs.get('env').get('MEDICAFE_LAB_DIR'), lab_root)
            self.assertEqual(kwargs.get('env').get('MEDICAFE_PHASE_D_ARTIFACT_CLASSES'), 'csv,docx')
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_run_phase_c_manual_propagates_launch_failure(self):
        from MediCafe import cloud_readiness as cr
        from MediCafe import cloud_readiness_actions as actions

        with patch.object(cr, '_resolve_unified_model_script', return_value=(True, '', 'C:\\repo', 'C:\\repo\\ingest_from_manifest.py', None)):
            with patch.object(cr, 'resolve_lab_root', return_value='C:\\lab'):
                with patch.object(actions, '_launch_tracked_diagnostic_async', return_value=(False, 'launch failed', {})):
                    ok, msg, meta = actions.run_phase_c_manual('C:\\repo', 'python.exe', {})

        self.assertFalse(ok)
        self.assertEqual(msg, 'launch failed')
        self.assertIsNone(meta)


if __name__ == '__main__':
    unittest.main()
