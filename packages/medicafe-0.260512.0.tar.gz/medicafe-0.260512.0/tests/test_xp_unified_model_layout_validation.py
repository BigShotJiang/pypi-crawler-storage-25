# -*- coding: utf-8 -*-
"""
Prebuild / release sanity: unified_model scripts shipped as data files and
historical Phase D helper resolvable by file path (matches PyPI/XP layout expectations).
"""
from __future__ import print_function

import os
import shutil
import tempfile
import unittest
from unittest import mock

try:
    import imp
except ImportError:
    imp = None

_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
_UM = os.path.join(_ROOT, 'scripts', 'unified_model')


class TestXpUnifiedModelLayout(unittest.TestCase):
    def _assert_script_exists_and_nonzero(self, name):
        path = os.path.join(_UM, name)
        self.assertTrue(os.path.isfile(path), 'missing unified_model script {0}'.format(path))
        self.assertGreater(os.path.getsize(path), 0, 'zero-byte unified_model script {0}'.format(path))
        return path

    def _assert_imp_load_has_symbols(self, script_name, module_name, required_symbols):
        if imp is None:
            self.skipTest('imp module unavailable')
        script_path = self._assert_script_exists_and_nonzero(script_name)
        mod = imp.load_source(module_name, script_path)
        for symbol in required_symbols:
            self.assertTrue(callable(getattr(mod, symbol, None)))

    def test_core_scripts_exist_as_plain_files(self):
        required = (
            'dat_payer_resolution.py',
            'discover_artifacts.py',
            'ingest_from_manifest.py',
            'package_shadow_run_report.py',
            'patient_field_mapper.py',
            'phase_b_root_adapter.py',
            'phase_f_common.py',
            'phase_d_historical_reprocess.py',
            'phase_e_auto_report.py',
            'phase_c_auto_report.py',
            'lab_lock.py',
            'layer1_join_debug.py',
            'phase_c_current_attempt.py',
            'run_qa_canonical.py',
            'run_tracked_diagnostic.py',
            'xp_phase_smoke.py',
        )
        for name in required:
            self._assert_script_exists_and_nonzero(name)

    def test_xp_package_integrity_manifest_tracks_core_scripts(self):
        from MediCafe import xp_package_integrity as xpi

        rels = set(xpi.XP_CRITICAL_RELATIVE_FILES)
        required = (
            'scripts/unified_model/ingest_from_manifest.py',
            'scripts/unified_model/lab_lock.py',
            'scripts/unified_model/dat_payer_resolution.py',
            'scripts/unified_model/patient_field_mapper.py',
            'scripts/unified_model/run_shadow_pipeline.py',
            'scripts/unified_model/run_qa_canonical.py',
            'scripts/unified_model/phase_c_common.py',
            'scripts/unified_model/phase_c_current_attempt.py',
            'scripts/unified_model/phase_f_common.py',
            'scripts/unified_model/run_tracked_diagnostic.py',
            'scripts/unified_model/xp_phase_smoke.py',
        )
        for rel_path in required:
            self.assertIn(rel_path, rels)

    def test_xp_package_integrity_manifest_tracks_recommendation_modules(self):
        from MediCafe import xp_package_integrity as xpi

        rels = set(xpi.default_expected_files(_ROOT))
        required = (
            'MediCafe/cloud_readiness_recommendations.py',
            'MediCafe/launcher_cloud_readiness_mixin.py',
            'MediCafe/layer1_runbook_model.py',
            'MediCafe/layer1_readiness_model.py',
            'MediCafe/diagnostic_attempts.py',
            'MediCafe/phase_d_developer_unblock.py',
        )
        for rel_path in required:
            self.assertIn(rel_path, rels)

    def test_phase_d_historical_reprocess_lazy_load_via_imp(self):
        self._assert_imp_load_has_symbols(
            'phase_d_historical_reprocess.py',
            '_medicafe_hist_reprocess_validate',
            ('preview_historical_phase_d_reprocess', 'execute_historical_phase_d_reprocess'),
        )

    def test_ingest_from_manifest_lazy_load_via_imp(self):
        self._assert_imp_load_has_symbols(
            'ingest_from_manifest.py',
            '_medicafe_ingest_from_manifest_validate',
            ('main', 'run_ingest'),
        )

    def test_package_shadow_run_report_lazy_load_via_imp(self):
        self._assert_imp_load_has_symbols(
            'package_shadow_run_report.py',
            '_medicafe_package_shadow_run_report_validate',
            ('main',),
        )

    def test_phase_f_common_lazy_load_via_imp(self):
        self._assert_imp_load_has_symbols(
            'phase_f_common.py',
            '_medicafe_phase_f_common_validate',
            ('build_report_payload', 'serialize_report_json'),
        )

    def test_script_resolution_missing_reports_parent_dir_existence(self):
        from MediCafe import cloud_readiness

        fake_script = '/repo/scripts/unified_model/package_shadow_run_report.py'
        fake_checks = [{
            'script_path': fake_script,
            'script_parent_dir_exists': False,
        }]
        with mock.patch('MediCafe.cloud_readiness.shadow_orchestrator._find_unified_model_script', return_value=('/repo', fake_script, fake_checks)):
            ok, msg, _, _, _ = cloud_readiness._resolve_unified_model_script('/repo', '/py', 'package_shadow_run_report.py')
        self.assertFalse(ok)
        self.assertIn('checked:', msg)
        self.assertIn('parent_dir_exists=False', msg)

    def test_script_resolution_zero_byte_reports_script_zero_bytes(self):
        from MediCafe import cloud_readiness

        temp_root = tempfile.mkdtemp()
        try:
            um_dir = os.path.join(temp_root, 'scripts', 'unified_model')
            os.makedirs(um_dir)
            script_path = os.path.join(um_dir, 'package_shadow_run_report.py')
            with open(script_path, 'w'):
                pass
            fake_checks = [{'script_path': script_path, 'script_parent_dir_exists': True}]
            with mock.patch('MediCafe.cloud_readiness.shadow_orchestrator._find_unified_model_script', return_value=(temp_root, script_path, fake_checks)):
                ok, msg, _, _, _ = cloud_readiness._resolve_unified_model_script(temp_root, '/py', 'package_shadow_run_report.py')
            self.assertFalse(ok)
            self.assertIn('SCRIPT_ZERO_BYTES', msg)
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)


if __name__ == '__main__':
    unittest.main()
