import json
import os
import shutil
import sys
import tempfile
import zipfile


ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TOOLS = os.path.join(ROOT, "tools")
if TOOLS not in sys.path:
    sys.path.insert(0, TOOLS)

import replay_xp_bundle


def _write_json(path, payload):
    parent = os.path.dirname(path)
    if parent and not os.path.isdir(parent):
        os.makedirs(parent)
    with open(path, "w") as handle:
        json.dump(payload, handle, indent=2, sort_keys=True)
        handle.write("\n")


def _write_text(path, text):
    parent = os.path.dirname(path)
    if parent and not os.path.isdir(parent):
        os.makedirs(parent)
    with open(path, "w") as handle:
        handle.write(text)


def _bundle(root, name="medicafe_bundle_anchor", include_txt=True, smoke_mismatch=False):
    bundle_dir = os.path.join(root, name)
    os.makedirs(bundle_dir)
    anchor = "PIPE"
    phase_d = "DRID"
    xp_json = r"C:\Python34\Lib\site-packages\lab\reports\phase_d_invalid_external_id_contract_report_DRID.json"
    xp_txt = r"C:\Python34\Lib\site-packages\lab\reports\phase_d_invalid_external_id_contract_report_DRID.txt"
    _write_json(os.path.join(bundle_dir, "meta.json"), {
        "bundle_kind": "run_evidence_bundle",
        "send_source": "unit_test",
        "app_version": "9.9.9",
        "recommended_action_kind": "resolve_external_patient_id_contract_pressure",
    })
    _write_json(os.path.join(bundle_dir, "evidence_scope.json"), {
        "anchor_run_id": anchor,
        "phase_run_id_map": {"B": "BRID", "C": "CRID", "D": phase_d, "E": "ERID"},
    })
    _write_json(os.path.join(bundle_dir, "diagnostics_state.json"), {
        "last_shadow_pipeline_run_id": anchor,
        "last_phase_d_run_id": phase_d,
        "last_shadow_pipeline_phase_run_ids": {"B": "BRID", "C": "CRID", "D": phase_d, "E": "ERID"},
    })
    _write_json(os.path.join(bundle_dir, "run_cursor.json"), {
        "last_shadow_pipeline_run_id": anchor,
    })
    _write_json(os.path.join(bundle_dir, "shadow_run_report_PIPE.json"), {
        "run_id": anchor,
        "phase_run_ids": {"B": "BRID", "C": "CRID", "D": phase_d, "E": "ERID"},
        "phase_d_dat_selected_count": 3,
        "phase_d_dat_qa_pass_count": 2,
        "phase_d_dat_canonical_record_count": 2,
        "source_summary_paths": {
            "D": r"C:\Python34\Lib\site-packages\lab\reports\qa_canonical_summary_DRID.json"
        },
    })
    _write_json(os.path.join(bundle_dir, "qa_canonical_summary_DRID.json"), {
        "run_id": phase_d,
        "phase_d_data_plane_stage": "data_quality_blocked",
        "phase_d_entity_scope": "v1",
        "dat_telemetry": {
            "dat_selected_count": 3,
            "dat_qa_pass_count": 2,
            "dat_qa_reject_count": 1,
            "dat_canonical_record_count": 2,
        },
        "phase_d_developer_unblock": {
            "schema_version": "phase_d_developer_unblock_v1",
            "recommended_action_kind": "resolve_external_patient_id_contract_pressure",
            "operator_manual_review_required": False,
            "safe_for_bundle": True,
            "contains_pii": False,
            "evidence_reports": [
                {"path": xp_json, "archive_name": os.path.basename(xp_json), "required": True, "contains_pii": False, "safe_for_bundle": True},
                {"path": xp_txt, "archive_name": os.path.basename(xp_txt), "required": True, "contains_pii": False, "safe_for_bundle": True},
            ],
        },
    })
    _write_json(os.path.join(bundle_dir, "phase_d_invalid_external_id_contract_report_DRID.json"), {
        "schema_version": "phase_d_invalid_external_id_contract_report_v1",
        "rows": [{"field_name": "external_patient_id", "count": 2, "safe_examples": ["shape:blank"]}],
    })
    if include_txt:
        _write_text(os.path.join(bundle_dir, "phase_d_invalid_external_id_contract_report_DRID.txt"), "redacted report\n")
    if smoke_mismatch:
        _write_text(os.path.join(bundle_dir, "run_evidence_smoke_anchor_mismatch_PIPE.txt"), "ignored_smoke_mismatch=true\n")
    return bundle_dir


def test_replay_rebases_paths_without_mutating_original_bundle():
    tmp = tempfile.mkdtemp()
    try:
        bundle_dir = _bundle(tmp)
        original_qa = os.path.join(bundle_dir, "qa_canonical_summary_DRID.json")
        original_text = open(original_qa).read()
        out_dir = os.path.join(tmp, "out")
        result = replay_xp_bundle.replay_bundle(bundle_dir, out_dir, keep_labs=True)
        assert result["developer_unblock_status"] == "complete"
        assert result["milestone_verdict"] == "Partially advanced"
        hydrated_qa = result["qa_canonical_summary_path"]
        hydrated = json.load(open(hydrated_qa))
        paths = [row["path"] for row in hydrated["phase_d_developer_unblock"]["evidence_reports"]]
        assert all(path.startswith(result["scratch_lab_dir"]) for path in paths)
        assert open(original_qa).read() == original_text
        assert "C:\\\\Python34\\\\Lib\\\\site-packages\\\\lab\\\\reports" in original_text
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_replay_reports_degraded_developer_unblock_when_required_file_missing():
    tmp = tempfile.mkdtemp()
    try:
        bundle_dir = _bundle(tmp, include_txt=False)
        result = replay_xp_bundle.replay_bundle(bundle_dir, os.path.join(tmp, "out"), keep_labs=False)
        assert result["developer_unblock_status"] == "degraded"
        missing = result["developer_unblock"]["missing_reports"]
        want = "phase_d_invalid_external_id_contract_report_DRID.txt"
        assert any(
            row == want or (isinstance(row, str) and row.replace("\\", "/").endswith(want))
            for row in missing
        )
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_replay_marks_smoke_mismatch_as_ignored():
    tmp = tempfile.mkdtemp()
    try:
        bundle_dir = _bundle(tmp, smoke_mismatch=True)
        result = replay_xp_bundle.replay_bundle(bundle_dir, os.path.join(tmp, "out"), keep_labs=False)
        assert result["smoke"]["verdict"] == "ignored_mismatch"
        assert result["smoke"]["accepted_for_anchor"] is False
        assert result["smoke"]["ignored_smoke_mismatch"] is True
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_main_generates_summary_and_codex_handoff_for_parent_dir():
    tmp = tempfile.mkdtemp()
    try:
        parent = os.path.join(tmp, "bundles")
        os.makedirs(parent)
        _bundle(parent, "medicafe_bundle_one")
        _bundle(parent, "medicafe_bundle_two")
        out_dir = os.path.join(tmp, "reports")
        rc = replay_xp_bundle.main(["--input", parent, "--out-dir", out_dir])
        assert rc == 0
        summary_path = os.path.join(out_dir, "replay_summary.json")
        handoff_path = os.path.join(out_dir, "codex_handoff_prompt.md")
        summary = json.load(open(summary_path))
        handoff = open(handoff_path).read()
        assert len(summary["bundles"]) == 2
        assert "original_bundle_dir" in handoff
        assert "Smoke verdict" in handoff or "smoke_verdict" in handoff
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_zip_input_is_supported():
    tmp = tempfile.mkdtemp()
    try:
        src_parent = os.path.join(tmp, "src")
        os.makedirs(src_parent)
        bundle_dir = _bundle(src_parent, "medicafe_bundle_zip")
        zip_path = os.path.join(tmp, "bundle.zip")
        with zipfile.ZipFile(zip_path, "w") as zf:
            for dirpath, dirnames, filenames in os.walk(bundle_dir):
                for name in filenames:
                    path = os.path.join(dirpath, name)
                    zf.write(path, os.path.relpath(path, src_parent))
        out_dir = os.path.join(tmp, "reports")
        rc = replay_xp_bundle.main(["--input", zip_path, "--out-dir", out_dir])
        assert rc == 0
        summary = json.load(open(os.path.join(out_dir, "replay_summary.json")))
        assert len(summary["bundles"]) == 1
        assert summary["bundles"][0]["bundle_name"] == "medicafe_bundle_zip"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
