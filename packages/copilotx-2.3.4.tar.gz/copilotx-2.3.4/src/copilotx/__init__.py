"""CopilotX — Local GitHub Copilot API proxy."""

__version__ = "2.3.2"
