"""Kubernetes API client wrapper with context and error handling."""

import logging
from typing import Any

from kubernetes import client, config
from kubernetes.client import ApiException

logger = logging.getLogger(__name__)

API_EXCEPTION_NOT_FOUND = 404
API_EXCEPTION_FORBIDDEN = 403


class K8sClientError(Exception):
    """Base exception for K8s client operations."""


class K8sNotFoundError(K8sClientError):
    """Raised when a Kubernetes resource is not found."""


class K8sForbiddenError(K8sClientError):
    """Raised when access to a Kubernetes resource is forbidden."""


class K8sClient:
    """Lazy-initialized Kubernetes API client.

    Wraps the official Python Kubernetes client with:
    - Automatic config loading (in-cluster or kubeconfig)
    - Context switching support
    - Lazy initialization of API group clients
    - Structured error handling
    """

    def __init__(self, context: str | None = None) -> None:
        self._context = context
        self._core_v1: client.CoreV1Api | None = None
        self._apps_v1: client.AppsV1Api | None = None
        self._batch_v1: client.BatchV1Api | None = None
        self._networking_v1: client.NetworkingV1Api | None = None
        self._autoscaling_v2: client.AutoscalingV2Api | None = None
        self._custom_objects: client.CustomObjectsApi | None = None
        self._metrics_api: client.CustomObjectsApi | None = None
        self._config_loaded = False

    def _ensure_config(self) -> None:
        """Load kubeconfig or in-cluster config if not already loaded."""
        if self._config_loaded:
            return

        try:
            config.load_incluster_config()
            logger.debug("Loaded in-cluster config")
        except config.ConfigException:
            try:
                config.load_kube_config(context=self._context)
                logger.debug("Loaded kubeconfig (context=%s)", self._context)
            except config.ConfigException as exc:
                raise RuntimeError(
                    "Could not load Kubernetes config. "
                    "Ensure KUBECONFIG is set or run inside a cluster."
                ) from exc

        self._config_loaded = True

    @property
    def core_v1(self) -> client.CoreV1Api:
        """CoreV1Api client (pods, services, nodes, namespaces, events, logs)."""
        if self._core_v1 is None:
            self._ensure_config()
            self._core_v1 = client.CoreV1Api()
        return self._core_v1

    @property
    def apps_v1(self) -> client.AppsV1Api:
        """AppsV1Api client (deployments, daemonsets, replicasets, statefulsets)."""
        if self._apps_v1 is None:
            self._ensure_config()
            self._apps_v1 = client.AppsV1Api()
        return self._apps_v1

    @property
    def batch_v1(self) -> client.BatchV1Api:
        """BatchV1Api client (jobs, cronjobs)."""
        if self._batch_v1 is None:
            self._ensure_config()
            self._batch_v1 = client.BatchV1Api()
        return self._batch_v1

    @property
    def networking_v1(self) -> client.NetworkingV1Api:
        """NetworkingV1Api client (ingresses, network policies)."""
        if self._networking_v1 is None:
            self._ensure_config()
            self._networking_v1 = client.NetworkingV1Api()
        return self._networking_v1

    @property
    def autoscaling_v2(self) -> client.AutoscalingV2Api:
        """AutoscalingV2Api client (HPAs)."""
        if self._autoscaling_v2 is None:
            self._ensure_config()
            self._autoscaling_v2 = client.AutoscalingV2Api()
        return self._autoscaling_v2

    @property
    def custom_objects(self) -> client.CustomObjectsApi:
        """CustomObjectsApi client for CRDs and metrics API."""
        if self._custom_objects is None:
            self._ensure_config()
            self._custom_objects = client.CustomObjectsApi()
        return self._custom_objects

    def _raise_for_status(self, exc: ApiException, resource: str) -> None:
        """Raise a typed exception based on the K8s API status code."""
        logger.warning("K8s API error for %s: %s %s", resource, exc.status, exc.body)
        if exc.status == API_EXCEPTION_NOT_FOUND:
            raise K8sNotFoundError(f"{resource} not found") from exc
        if exc.status == API_EXCEPTION_FORBIDDEN:
            raise K8sForbiddenError(f"Access forbidden to {resource}") from exc
        raise K8sClientError(f"K8s API error for {resource}: {exc.body}") from exc

    def handle_api_error(self, exc: ApiException, resource: str) -> dict[str, Any]:
        """Convert a Kubernetes API exception into a friendly error dict.

        Non-fatal: returns structured error info instead of raising.
        """
        logger.warning("K8s API error for %s: %s %s", resource, exc.status, exc.body)
        return {
            "error": True,
            "resource": resource,
            "status_code": exc.status,
            "message": exc.reason or str(exc.body),
        }

    # ------------------------------------------------------------------
    # Convenience helpers used by tools
    # ------------------------------------------------------------------

    def get_pod(self, name: str, namespace: str) -> client.V1Pod:
        """Fetch a single pod by name and namespace."""
        try:
            return self.core_v1.read_namespaced_pod(name, namespace)
        except ApiException as exc:
            self._raise_for_status(exc, f"pod/{namespace}/{name}")
            raise  # unreachable  # pragma: no cover, satisfies type checker  # pragma: no cover

    def list_pods(
        self,
        namespace: str | None = None,
        label_selector: str | None = None,
        field_selector: str | None = None,
        limit: int | None = None,
    ) -> client.V1PodList:
        """List pods with optional filters."""
        kwargs: dict[str, Any] = {
            "label_selector": label_selector,
            "field_selector": field_selector,
            "limit": limit,
        }
        kwargs = {k: v for k, v in kwargs.items() if v is not None}
        try:
            if namespace:
                return self.core_v1.list_namespaced_pod(namespace, **kwargs)
            return self.core_v1.list_pod_for_all_namespaces(**kwargs)
        except ApiException as exc:
            self._raise_for_status(exc, "pods")
            raise  # unreachable  # pragma: no cover

    def get_events(
        self,
        namespace: str | None = None,
        involved_name: str | None = None,
        involved_kind: str = "Pod",
    ) -> client.CoreV1EventList:
        """List events filtered by involved object."""
        field_parts = [f"involvedObject.kind={involved_kind}"]
        if involved_name:
            field_parts.append(f"involvedObject.name={involved_name}")
        field_selector = ",".join(field_parts)
        try:
            if namespace:
                return self.core_v1.list_namespaced_event(namespace, field_selector=field_selector)
            return self.core_v1.list_event_for_all_namespaces(field_selector=field_selector)
        except ApiException as exc:
            self._raise_for_status(exc, "events")
            raise  # unreachable  # pragma: no cover

    def get_pod_logs(
        self,
        name: str,
        namespace: str,
        container: str | None = None,
        tail_lines: int = 100,
        previous: bool = False,
    ) -> str:
        """Fetch logs for a pod/container."""
        kwargs: dict[str, Any] = {"tail_lines": tail_lines}
        if container is not None:
            kwargs["container"] = container
        if previous:
            kwargs["previous"] = True
        try:
            return self.core_v1.read_namespaced_pod_log(name, namespace, **kwargs)
        except ApiException as exc:
            self._raise_for_status(exc, f"logs/{namespace}/{name}")
            raise  # unreachable  # pragma: no cover

    def get_deployment(self, name: str, namespace: str) -> client.V1Deployment:
        """Fetch a single deployment."""
        try:
            return self.apps_v1.read_namespaced_deployment(name, namespace)
        except ApiException as exc:
            self._raise_for_status(exc, f"deployment/{namespace}/{name}")
            raise  # unreachable  # pragma: no cover

    def get_node(self, name: str) -> client.V1Node:
        """Fetch a single node."""
        try:
            return self.core_v1.read_node(name)
        except ApiException as exc:
            self._raise_for_status(exc, f"node/{name}")
            raise  # unreachable  # pragma: no cover

    def serialize(self, obj: Any) -> Any:
        """Convert a Kubernetes API object to a plain Python dict/list.

        Uses the official client's serialization helper so datetime objects,
        custom types, etc. are handled automatically.
        """
        return client.ApiClient().sanitize_for_serialization(obj)

    def list_resources(
        self,
        resource_type: str,
        namespace: str | None = None,
        label_selector: str | None = None,
        field_selector: str | None = None,
        limit: int | None = None,
    ) -> dict[str, Any]:
        """List arbitrary Kubernetes resources by type.

        Args:
            resource_type: Lower-case plural name, e.g. 'pods', 'deployments'.
            namespace: Namespace to scope to. Omit for cluster-scoped or all-namespaces.
            label_selector: K8s label selector string.
            field_selector: K8s field selector string.
            limit: Maximum items to return.

        Returns:
            Serialized dict with an 'items' list.
        """
        # Normalize common aliases
        aliases = {
            "pod": "pods",
            "deployment": "deployments",
            "service": "services",
            "configmap": "configmaps",
            "secret": "secrets",
            "node": "nodes",
            "namespace": "namespaces",
            "job": "jobs",
            "cronjob": "cronjobs",
            "daemonset": "daemonsets",
            "statefulset": "statefulsets",
            "replicaset": "replicasets",
            "ingress": "ingresses",
            "persistentvolume": "persistentvolumes",
            "persistentvolumeclaim": "persistentvolumeclaims",
            "horizontalpodautoscaler": "horizontalpodautoscalers",
            "hpa": "horizontalpodautoscalers",
        }
        kind = aliases.get(resource_type, resource_type)

        kwargs: dict[str, Any] = {
            "label_selector": label_selector,
            "field_selector": field_selector,
            "limit": limit,
        }
        kwargs = {k: v for k, v in kwargs.items() if v is not None}

        # Mapping: (api_property, namespaced_method, all_namespaces_method, cluster_method)
        mapping: dict[str, tuple[str, str, str | None, str | None]] = {
            "pods": ("core_v1", "list_namespaced_pod", "list_pod_for_all_namespaces", None),
            "services": (
                "core_v1",
                "list_namespaced_service",
                "list_service_for_all_namespaces",
                None,
            ),
            "configmaps": (
                "core_v1",
                "list_namespaced_config_map",
                "list_config_map_for_all_namespaces",
                None,
            ),
            "secrets": (
                "core_v1",
                "list_namespaced_secret",
                "list_secret_for_all_namespaces",
                None,
            ),
            "nodes": ("core_v1", None, None, "list_node"),
            "namespaces": ("core_v1", None, None, "list_namespace"),
            "deployments": (
                "apps_v1",
                "list_namespaced_deployment",
                "list_deployment_for_all_namespaces",
                None,
            ),
            "daemonsets": (
                "apps_v1",
                "list_namespaced_daemon_set",
                "list_daemon_set_for_all_namespaces",
                None,
            ),
            "statefulsets": (
                "apps_v1",
                "list_namespaced_stateful_set",
                "list_stateful_set_for_all_namespaces",
                None,
            ),
            "replicasets": (
                "apps_v1",
                "list_namespaced_replica_set",
                "list_replica_set_for_all_namespaces",
                None,
            ),
            "jobs": ("batch_v1", "list_namespaced_job", "list_job_for_all_namespaces", None),
            "cronjobs": (
                "batch_v1",
                "list_namespaced_cron_job",
                "list_cron_job_for_all_namespaces",
                None,
            ),
            "ingresses": (
                "networking_v1",
                "list_namespaced_ingress",
                "list_ingress_for_all_namespaces",
                None,
            ),
            "persistentvolumes": ("core_v1", None, None, "list_persistent_volume"),
            "persistentvolumeclaims": (
                "core_v1",
                "list_namespaced_persistent_volume_claim",
                "list_persistent_volume_claim_for_all_namespaces",
                None,
            ),
            "horizontalpodautoscalers": (
                "autoscaling_v2",
                "list_namespaced_horizontal_pod_autoscaler",
                "list_horizontal_pod_autoscaler_for_all_namespaces",
                None,
            ),
        }

        if kind not in mapping:
            raise K8sClientError(f"Unsupported resource type: {resource_type}")

        api_prop, namespaced_method, all_method, cluster_method = mapping[kind]
        api = getattr(self, api_prop)

        try:
            if cluster_method:
                result = getattr(api, cluster_method)(**kwargs)
            elif namespace:
                result = getattr(api, namespaced_method)(namespace, **kwargs)
            else:
                result = getattr(api, all_method)(**kwargs)
            return self.serialize(result)
        except ApiException as exc:
            self._raise_for_status(exc, f"{kind}")
            raise  # unreachable  # pragma: no cover

    def get_resource(
        self,
        resource_type: str,
        name: str,
        namespace: str | None = None,
    ) -> dict[str, Any]:
        """Fetch a single Kubernetes resource by kind and name.

        Args:
            resource_type: Lower-case plural name, e.g. 'pods', 'deployments'.
            name: Resource name.
            namespace: Namespace for namespaced resources.

        Returns:
            Serialized resource dict.
        """
        aliases = {
            "pod": "pods",
            "deployment": "deployments",
            "service": "services",
            "configmap": "configmaps",
            "secret": "secrets",
            "node": "nodes",
            "namespace": "namespaces",
            "job": "jobs",
            "cronjob": "cronjobs",
            "daemonset": "daemonsets",
            "statefulset": "statefulsets",
            "replicaset": "replicasets",
            "ingress": "ingresses",
            "persistentvolume": "persistentvolumes",
            "persistentvolumeclaim": "persistentvolumeclaims",
        }
        kind = aliases.get(resource_type, resource_type)

        # Mapping: (api_property, namespaced_read_method, cluster_read_method)
        mapping: dict[str, tuple[str, str | None, str | None]] = {
            "pods": ("core_v1", "read_namespaced_pod", None),
            "services": ("core_v1", "read_namespaced_service", None),
            "configmaps": ("core_v1", "read_namespaced_config_map", None),
            "secrets": ("core_v1", "read_namespaced_secret", None),
            "nodes": ("core_v1", None, "read_node"),
            "namespaces": ("core_v1", None, "read_namespace"),
            "deployments": ("apps_v1", "read_namespaced_deployment", None),
            "daemonsets": ("apps_v1", "read_namespaced_daemon_set", None),
            "statefulsets": ("apps_v1", "read_namespaced_stateful_set", None),
            "replicasets": ("apps_v1", "read_namespaced_replica_set", None),
            "jobs": ("batch_v1", "read_namespaced_job", None),
            "cronjobs": ("batch_v1", "read_namespaced_cron_job", None),
            "ingresses": ("networking_v1", "read_namespaced_ingress", None),
            "persistentvolumes": ("core_v1", None, "read_persistent_volume"),
            "persistentvolumeclaims": ("core_v1", "read_namespaced_persistent_volume_claim", None),
        }

        if kind not in mapping:
            raise K8sClientError(f"Unsupported resource type: {resource_type}")

        api_prop, namespaced_method, cluster_method = mapping[kind]
        api = getattr(self, api_prop)

        try:
            if cluster_method:
                result = getattr(api, cluster_method)(name)
            elif namespace:
                result = getattr(api, namespaced_method)(name, namespace)
            else:
                raise K8sClientError(f"Namespace required for namespaced resource: {kind}")
            return self.serialize(result)
        except ApiException as exc:
            self._raise_for_status(exc, f"{kind}/{namespace or 'cluster'}/{name}")
            raise  # unreachable  # pragma: no cover

    def get_pod_metrics(self, namespace: str | None = None) -> dict[str, Any]:
        """Fetch pod metrics via the metrics.k8s.io API."""
        try:
            if namespace:
                return self.custom_objects.list_namespaced_custom_object(
                    group="metrics.k8s.io",
                    version="v1beta1",
                    namespace=namespace,
                    plural="pods",
                )
            return self.custom_objects.list_cluster_custom_object(
                group="metrics.k8s.io",
                version="v1beta1",
                plural="pods",
            )
        except ApiException as exc:
            self._raise_for_status(exc, "pod-metrics")
            raise  # unreachable  # pragma: no cover


# Global client instance (created lazily per request in async tools)
_client: K8sClient | None = None


def get_k8s_client(context: str | None = None) -> K8sClient:
    """Get or create the shared K8sClient instance.

    If a context is explicitly provided and differs from the current
    client's context, a new instance is created.
    """
    global _client
    if _client is None or context is not None and _client._context != context:
        _client = K8sClient(context=context)
    return _client
