"""Shared utilities for K8s Lens MCP."""
