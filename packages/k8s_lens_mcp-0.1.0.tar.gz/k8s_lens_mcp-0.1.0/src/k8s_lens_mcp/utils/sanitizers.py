"""Output sanitization utilities for K8s Lens MCP."""

from typing import Any


def sanitize_secret(data: dict[str, Any]) -> dict[str, Any]:
    """Remove sensitive Secret data from a Kubernetes resource dict."""
    if data.get("kind") == "Secret":
        data = dict(data)
        data.pop("data", None)
        data.pop("stringData", None)
    return data


def sanitize_resource_list(resources: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Sanitize a list of resources, stripping secrets."""
    return [sanitize_secret(r) for r in resources]
