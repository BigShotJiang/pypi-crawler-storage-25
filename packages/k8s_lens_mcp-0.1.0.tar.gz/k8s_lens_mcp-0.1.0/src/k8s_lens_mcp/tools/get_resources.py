"""Tool: get_resources — filtered Kubernetes resource queries."""

from datetime import UTC, datetime

from pydantic import BaseModel, Field

from k8s_lens_mcp.utils.k8s_client import get_k8s_client
from k8s_lens_mcp.utils.sanitizers import sanitize_secret


class GetResourcesInput(BaseModel):
    """Input schema for get_resources tool."""

    resource_type: str = Field(
        ...,
        description="Resource type, e.g. 'pods', 'deployments', 'services', 'nodes'",
    )
    namespace: str | None = Field(
        None,
        description="Namespace to query. Omit for all namespaces.",
    )
    status: str | None = Field(
        None,
        description="Filter by status phase, e.g. 'Running', 'Pending', 'CrashLoopBackOff'",
    )
    labels: dict[str, str] | None = Field(
        None,
        description="Label selector as key-value pairs",
    )
    field_selector: str | None = Field(
        None,
        description="Raw field selector string",
    )
    limit: int = Field(100, description="Maximum results to return")
    contexts: list[str] = Field(
        default_factory=list,
        description="Kubernetes contexts to query. If empty, uses the default context.",
    )


def _build_label_selector(labels: dict[str, str] | None) -> str | None:
    """Convert a dict of labels into a Kubernetes label selector string."""
    if not labels:
        return None
    return ",".join(f"{k}={v}" for k, v in labels.items())


def _humanize_age(iso_timestamp: str | None) -> str:
    """Convert an ISO 8601 timestamp to a human-readable age string."""
    if not iso_timestamp:
        return "unknown"
    try:
        dt = datetime.fromisoformat(iso_timestamp.replace("Z", "+00:00"))
    except ValueError:
        return "unknown"
    delta = datetime.now(UTC) - dt
    total_seconds = int(delta.total_seconds())
    if total_seconds < 60:
        return f"{total_seconds}s"
    minutes = total_seconds // 60
    if minutes < 60:
        return f"{minutes}m"
    hours = minutes // 60
    if hours < 24:
        return f"{hours}h"
    days = hours // 24
    if days < 7:
        return f"{days}d"
    weeks = days // 7
    if weeks < 52:
        return f"{weeks}w"
    years = days // 365
    return f"{years}y"


def _extract_pod_summary(item: dict) -> dict:
    """Extract a concise summary from a serialized pod dict."""
    status = item.get("status", {})
    phase = status.get("phase", "Unknown")
    container_statuses = status.get("containerStatuses", []) or []
    ready_count = sum(1 for c in container_statuses if c.get("ready"))
    total_count = len(container_statuses)
    restarts = sum(c.get("restartCount", 0) for c in container_statuses)
    return {
        "name": item.get("metadata", {}).get("name"),
        "namespace": item.get("metadata", {}).get("namespace"),
        "status": phase,
        "age": _humanize_age(item.get("metadata", {}).get("creationTimestamp")),
        "ready": f"{ready_count}/{total_count}" if total_count else "0/0",
        "restarts": restarts,
    }


def _extract_deployment_summary(item: dict) -> dict:
    """Extract a concise summary from a serialized deployment dict."""
    status = item.get("status", {})
    spec = item.get("spec", {})
    ready = status.get("readyReplicas", 0)
    desired = spec.get("replicas", 0)
    return {
        "name": item.get("metadata", {}).get("name"),
        "namespace": item.get("metadata", {}).get("namespace"),
        "status": f"{ready}/{desired} ready" if desired else f"{ready} ready",
        "age": _humanize_age(item.get("metadata", {}).get("creationTimestamp")),
        "ready": f"{ready}/{desired}" if desired else f"{ready}/0",
    }


def _extract_generic_summary(item: dict) -> dict:
    """Extract a concise summary from any serialized resource dict."""
    metadata = item.get("metadata", {})
    status = item.get("status", {})
    # Try to find a sensible status string
    phase = status.get("phase")
    conditions = status.get("conditions", [])
    if not phase and conditions:
        phase = conditions[0].get("type", "Unknown")
    if not phase:
        phase = "N/A"
    return {
        "name": metadata.get("name"),
        "namespace": metadata.get("namespace"),
        "status": phase,
        "age": _humanize_age(metadata.get("creationTimestamp")),
        "ready": "N/A",
    }


def _summarize_item(resource_type: str, item: dict) -> dict:
    """Route to the correct summarizer based on resource type."""
    normalized = resource_type.lower()
    if normalized in ("pod", "pods"):
        return _extract_pod_summary(item)
    if normalized in ("deployment", "deployments"):
        return _extract_deployment_summary(item)
    return _extract_generic_summary(item)


def _matches_status(item: dict, status_filter: str) -> bool:
    """Check if a resource item matches the given status filter (case-insensitive)."""
    status = item.get("status", {})
    # Try common status locations
    candidates = [
        status.get("phase"),
    ]
    conditions = status.get("conditions", [])
    if conditions:
        candidates.append(conditions[0].get("type"))
        candidates.append(conditions[0].get("status"))
    return any(candidate and candidate.lower() == status_filter.lower() for candidate in candidates)


async def get_resources(input: GetResourcesInput) -> dict:
    """Query Kubernetes resources with flexible filters.

    Args:
        input: GetResourcesInput with resource type and filters.

    Returns:
        Dictionary with matched resources or error info.
    """
    label_selector = _build_label_selector(input.labels)

    # For pods, we can push the status filter into the field selector
    field_selector = input.field_selector
    resource_type = input.resource_type.lower()
    if resource_type in ("pod", "pods") and input.status and not field_selector:
        # Kubernetes supports status.phase field selector for pods
        field_selector = f"status.phase={input.status}"
        status_filter = None  # Already handled server-side
    else:
        status_filter = input.status

    contexts = input.contexts or [None]  # None = default context
    all_summaries: list[dict] = []
    errors: list[str] = []

    for ctx in contexts:
        client = get_k8s_client(context=ctx)
        try:
            result = client.list_resources(
                resource_type=resource_type,
                namespace=input.namespace,
                label_selector=label_selector,
                field_selector=field_selector,
                limit=input.limit,
            )
        except Exception as exc:
            errors.append(f"Context '{ctx or 'default'}': {exc}")
            continue

        items = result.get("items", [])

        # Client-side status filtering for non-pod resources
        if status_filter:
            items = [item for item in items if _matches_status(item, status_filter)]

        # Sanitize secrets before summarizing (defense in depth)
        sanitized_items = [sanitize_secret(item) for item in items]
        for item in sanitized_items:
            summary = _summarize_item(resource_type, item)
            summary["context"] = ctx or "default"
            all_summaries.append(summary)

    return {
        "resource_type": resource_type,
        "count": len(all_summaries),
        "namespace": input.namespace or "all",
        "contexts_queried": [c or "default" for c in contexts],
        "errors": errors if errors else None,
        "items": all_summaries,
    }
