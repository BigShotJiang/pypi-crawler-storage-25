"""Tool: analyze_pod — deep root-cause analysis for a pod."""

from pydantic import BaseModel, Field

from k8s_lens_mcp.utils.k8s_client import K8sClientError, get_k8s_client


class AnalyzePodInput(BaseModel):
    """Input schema for analyze_pod tool."""

    pod_name: str = Field(..., description="Name of the pod to analyze")
    namespace: str | None = Field(None, description="Pod namespace")
    container: str | None = Field(None, description="Specific container for multi-container pods")
    tail_lines: int = Field(100, description="Number of log lines to fetch")


def _collect_pod_signals(
    client,
    pod_name: str,
    namespace: str,
    container: str | None,
    tail_lines: int,
) -> dict:
    """Gather all diagnostic signals for a pod."""
    pod = client.serialize(client.get_pod(pod_name, namespace))
    events_raw = client.serialize(client.get_events(namespace=namespace, involved_name=pod_name))

    # Sort events by lastTimestamp (newest first)
    events = sorted(
        events_raw.get("items", []),
        key=lambda e: e.get("lastTimestamp") or "",
        reverse=True,
    )

    # Collect logs
    logs: dict[str, str] = {}
    containers = pod.get("spec", {}).get("containers", [])
    init_containers = pod.get("spec", {}).get("initContainers", [])
    all_container_names = [c["name"] for c in init_containers + containers]

    target_containers = [container] if container else all_container_names

    for cname in target_containers:
        try:
            logs[cname] = client.get_pod_logs(
                pod_name, namespace, container=cname, tail_lines=tail_lines
            )
        except K8sClientError:
            logs[cname] = "(logs unavailable — container may not have started)"

    return {
        "pod": pod,
        "events": events,
        "logs": logs,
    }


def _extract_container_issues(pod: dict) -> list[dict]:
    """Extract issues from container statuses."""
    issues = []
    status = pod.get("status", {})
    container_statuses = status.get("containerStatuses", []) or []
    init_statuses = status.get("initContainerStatuses", []) or []

    for cs in init_statuses + container_statuses:
        name = cs.get("name", "unknown")
        waiting = cs.get("state", {}).get("waiting")
        terminated = cs.get("state", {}).get("terminated")
        restarts = cs.get("restartCount", 0)

        if waiting:
            reason = waiting.get("reason", "Unknown")
            message = waiting.get("message", "")
            issues.append(
                {
                    "container": name,
                    "type": "waiting",
                    "reason": reason,
                    "message": message,
                    "restarts": restarts,
                }
            )
        elif terminated:
            reason = terminated.get("reason", "Unknown")
            exit_code = terminated.get("exitCode", "?")
            message = terminated.get("message", "")
            issues.append(
                {
                    "container": name,
                    "type": "terminated",
                    "reason": reason,
                    "exit_code": exit_code,
                    "message": message,
                    "restarts": restarts,
                }
            )
        elif restarts > 0:
            issues.append(
                {
                    "container": name,
                    "type": "running",
                    "reason": "PreviousRestarts",
                    "message": f"Container is running but has {restarts} previous restarts",
                    "restarts": restarts,
                }
            )

    return issues


def _diagnose(pod: dict, events: list[dict], logs: dict[str, str]) -> dict:
    """Analyze collected signals and produce a diagnosis."""
    spec = pod.get("spec", {})
    status = pod.get("status", {})

    pod_phase = status.get("phase", "Unknown")
    container_issues = _extract_container_issues(pod)
    top_events = []
    suggestions = []
    likely_cause = "No obvious issues detected."

    # Build top events list (max 5)
    for ev in events[:5]:
        top_events.append(
            {
                "type": ev.get("type"),
                "reason": ev.get("reason"),
                "message": ev.get("message"),
                "count": ev.get("count"),
                "from": ev.get("source", {}).get("component"),
            }
        )

    # Determine likely cause and suggestions based on signals
    if container_issues:
        issue = container_issues[0]
        reason = issue["reason"]
        message = issue.get("message", "")

        if reason == "CrashLoopBackOff":
            likely_cause = (
                f"Container '{issue['container']}' is crashing repeatedly "
                f"(restarts: {issue['restarts']})."
            )
            suggestions = [
                "Check container logs for application errors",
                "Verify environment variables and config maps",
                "Check resource limits — the app may be OOM-killed",
                "Review liveness probe settings if they are too aggressive",
            ]
        elif reason == "ImagePullBackOff":
            likely_cause = f"Failed to pull image for container '{issue['container']}'."
            suggestions = [
                "Verify the image name and tag are correct",
                "Check image pull secrets for private registries",
                "Ensure the registry is accessible from the cluster",
            ]
        elif reason == "ErrImagePull":
            likely_cause = f"Image pull failed for container '{issue['container']}': {message}"
            suggestions = [
                "Verify image exists in the registry",
                "Check image pull secrets",
                "Check network connectivity to the registry",
            ]
        elif reason == "ContainerCreating":
            likely_cause = f"Container '{issue['container']}' is stuck creating."
            suggestions = [
                "Check if required volumes are available and mountable",
                "Verify node has sufficient resources",
                "Check for PVC binding issues",
            ]
        elif reason == "OOMKilled":
            likely_cause = f"Container '{issue['container']}' was killed due to out-of-memory."
            suggestions = [
                "Increase memory limits in the pod spec",
                "Optimize the application to use less memory",
                "Check for memory leaks",
            ]
        elif reason == "Error":
            likely_cause = (
                f"Container '{issue['container']}' exited with error "
                f"(exit code: {issue.get('exit_code', '?')})."
            )
            suggestions = [
                "Check container logs for the exact error",
                "Verify the container startup command and args",
            ]
        elif reason == "Completed":
            likely_cause = f"Container '{issue['container']}' has completed its execution."
            suggestions = [
                "If this is a Job, check completion policy",
                "If this should be a long-running service, review the entrypoint",
            ]
        else:
            likely_cause = f"Container '{issue['container']}' in state: {reason}. {message}"
            suggestions = ["Review pod events and logs for more details"]

    elif pod_phase == "Pending":
        likely_cause = "Pod is stuck in Pending state."
        # Look at events for scheduling clues
        scheduling_events = [
            e for e in events if e.get("reason") in ("FailedScheduling", "FailedBinding")
        ]
        if scheduling_events:
            likely_cause += f" Scheduling issue: {scheduling_events[0].get('message', '')}"
            suggestions = [
                "Check if nodes have sufficient CPU/memory resources",
                "Review node selectors and affinity rules",
                "Check for taints that may prevent scheduling",
                "Verify PersistentVolumeClaims are bound",
            ]
        else:
            suggestions = [
                "Check if nodes have sufficient resources",
                "Verify image is being pulled (may be a large image)",
                "Check for init container failures",
            ]

    elif pod_phase == "Failed":
        likely_cause = "Pod has reached Failed state."
        suggestions = [
            "Check container logs for error details",
            "Review pod events for failure reasons",
            "Check resource limits and node conditions",
        ]

    elif pod_phase == "Succeeded":
        likely_cause = "Pod completed successfully."
        suggestions = ["This is expected for Jobs and one-off tasks"]

    elif pod_phase == "Running":
        # Even if Running, there might be restart issues
        # Note: running containers with restarts are captured as container_issues above,
        # so this branch handles pods with no detected container issues.
        total_restarts = sum(i["restarts"] for i in container_issues)
        if total_restarts > 0:  # pragma: no cover
            likely_cause = (
                f"Pod is Running but has {total_restarts} total restarts. It may be unstable."
            )
            suggestions = [
                "Check recent container logs for intermittent failures",
                "Review liveness/readiness probe configuration",
                "Monitor for resource pressure",
            ]
        else:
            likely_cause = "Pod is Running normally with no detected issues."
            suggestions = ["No action needed"]

    # Extract resource info
    resource_info = {}
    for container in spec.get("containers", []):
        resources = container.get("resources", {})
        if resources:
            resource_info[container["name"]] = {
                "requests": resources.get("requests", {}),
                "limits": resources.get("limits", {}),
            }

    return {
        "pod_status": pod_phase,
        "restarts": sum(i["restarts"] for i in container_issues),
        "container_issues": container_issues,
        "top_events": top_events,
        "logs": logs,
        "resource_info": resource_info,
        "likely_cause": likely_cause,
        "suggestions": suggestions,
    }


async def analyze_pod(input: AnalyzePodInput) -> dict:
    """Perform deep root-cause analysis on a pod.

    Correlates pod status, events, logs, resource limits, and node conditions.

    Args:
        input: AnalyzePodInput with pod name and options.

    Returns:
        Structured diagnosis report.
    """
    client = get_k8s_client()
    namespace = input.namespace or "default"

    try:
        signals = _collect_pod_signals(
            client,
            input.pod_name,
            namespace,
            input.container,
            input.tail_lines,
        )
    except K8sClientError as exc:
        return {"error": True, "message": str(exc)}

    diagnosis = _diagnose(signals["pod"], signals["events"], signals["logs"])

    return {
        "pod": input.pod_name,
        "namespace": namespace,
        **diagnosis,
    }
