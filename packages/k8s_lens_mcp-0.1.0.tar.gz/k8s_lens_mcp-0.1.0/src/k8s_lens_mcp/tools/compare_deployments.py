"""Tool: compare_deployments — diff two K8s resources across environments."""

from deepdiff import DeepDiff
from pydantic import BaseModel, Field

from k8s_lens_mcp.utils.k8s_client import K8sClient, K8sClientError
from k8s_lens_mcp.utils.sanitizers import sanitize_secret


class CompareDeploymentsInput(BaseModel):
    """Input schema for compare_deployments tool."""

    resource_kind: str = Field("Deployment", description="Kind of resource to diff")
    name: str = Field(..., description="Name of the resource")
    namespace_a: str = Field(..., description="Namespace of first resource")
    namespace_b: str = Field(..., description="Namespace of second resource")
    context_a: str | None = Field(None, description="Context for first resource")
    context_b: str | None = Field(None, description="Context for second resource")


# Fields that are always volatile / environment-specific
_VOLATILE_METADATA = {
    "uid",
    "resourceVersion",
    "creationTimestamp",
    "generation",
    "managedFields",
    "namespace",
}


def _strip_volatile(data: dict) -> dict:
    """Remove volatile metadata and status from a resource dict."""
    result = dict(data)
    # Strip status entirely
    result.pop("status", None)
    # Strip volatile metadata fields
    metadata = result.get("metadata", {})
    if metadata:
        cleaned_meta = {k: v for k, v in metadata.items() if k not in _VOLATILE_METADATA}
        result["metadata"] = cleaned_meta
    return result


def _normalize_kind(kind: str) -> str:
    """Normalize resource kind to lower-case plural form used by the client."""
    kind = kind.lower()
    # Handle common singular forms
    singular_to_plural = {
        "pod": "pods",
        "deployment": "deployments",
        "service": "services",
        "configmap": "configmaps",
        "secret": "secrets",
        "node": "nodes",
        "namespace": "namespaces",
        "job": "jobs",
        "cronjob": "cronjobs",
        "daemonset": "daemonsets",
        "statefulset": "statefulsets",
        "replicaset": "replicasets",
        "ingress": "ingresses",
        "persistentvolume": "persistentvolumes",
        "persistentvolumeclaim": "persistentvolumeclaims",
    }
    return singular_to_plural.get(kind, kind)


def _summarize_diff(diff: DeepDiff) -> dict:
    """Convert a DeepDiff object into a structured summary."""
    changes: list[dict] = []

    for change_type, items in diff.to_dict().items():
        if change_type in ("dictionary_item_added", "iterable_item_added"):
            for path, value in items.items():
                changes.append(
                    {
                        "type": "added",
                        "path": path,
                        "value": value,
                    }
                )
        elif change_type in ("dictionary_item_removed", "iterable_item_removed"):
            for path, value in items.items():
                changes.append(
                    {
                        "type": "removed",
                        "path": path,
                        "value": value,
                    }
                )
        elif change_type == "values_changed":
            for path, details in items.items():
                changes.append(
                    {
                        "type": "changed",
                        "path": path,
                        "old_value": details.get("old_value"),
                        "new_value": details.get("new_value"),
                    }
                )
        elif change_type == "type_changes":
            for path, details in items.items():
                changes.append(
                    {
                        "type": "type_changed",
                        "path": path,
                        "old_type": str(details.get("old_type")),
                        "new_type": str(details.get("new_type")),
                        "old_value": details.get("old_value"),
                        "new_value": details.get("new_value"),
                    }
                )

    return {
        "total_changes": len(changes),
        "added": len([c for c in changes if c["type"] == "added"]),
        "removed": len([c for c in changes if c["type"] == "removed"]),
        "changed": len([c for c in changes if c["type"] == "changed"]),
        "changes": changes[:20],  # Limit detail to avoid huge outputs
    }


async def compare_deployments(input: CompareDeploymentsInput) -> dict:
    """Diff two Kubernetes resources across namespaces or clusters.

    Args:
        input: CompareDeploymentsInput specifying both sides of the diff.

    Returns:
        Structured diff with added, removed, and changed fields.
    """
    kind = _normalize_kind(input.resource_kind)

    # Fetch resource A
    try:
        client_a = K8sClient(context=input.context_a)
        resource_a = client_a.get_resource(
            resource_type=kind,
            name=input.name,
            namespace=input.namespace_a,
        )
    except K8sClientError as exc:
        return {
            "error": True,
            "message": f"Failed to fetch {kind}/{input.namespace_a}/{input.name}: {exc}",
        }

    # Fetch resource B
    try:
        client_b = K8sClient(context=input.context_b)
        resource_b = client_b.get_resource(
            resource_type=kind,
            name=input.name,
            namespace=input.namespace_b,
        )
    except K8sClientError as exc:
        return {
            "error": True,
            "message": f"Failed to fetch {kind}/{input.namespace_b}/{input.name}: {exc}",
        }

    # Strip volatile fields and sanitize secrets before diffing
    clean_a = sanitize_secret(_strip_volatile(resource_a))
    clean_b = sanitize_secret(_strip_volatile(resource_b))

    # Compute diff
    diff = DeepDiff(clean_a, clean_b, ignore_order=True, verbose_level=2)

    summary = _summarize_diff(diff)

    return {
        "resource_kind": input.resource_kind,
        "name": input.name,
        "side_a": {
            "namespace": input.namespace_a,
            "context": input.context_a,
            "image": _extract_image(clean_a),
        },
        "side_b": {
            "namespace": input.namespace_b,
            "context": input.context_b,
            "image": _extract_image(clean_b),
        },
        **summary,
    }


def _extract_image(resource: dict) -> str | None:
    """Try to extract the container image from a resource dict."""
    containers = resource.get("spec", {}).get("containers", []) or resource.get("spec", {}).get(
        "template", {}
    ).get("spec", {}).get("containers", [])
    if containers:
        return containers[0].get("image")
    return None
