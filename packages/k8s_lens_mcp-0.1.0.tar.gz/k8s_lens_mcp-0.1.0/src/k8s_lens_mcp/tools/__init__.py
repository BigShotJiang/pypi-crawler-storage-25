"""MCP tools for K8s Lens MCP."""
