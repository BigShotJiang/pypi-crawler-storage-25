"""Tool: advise_resources — cluster resource optimization advisor."""

from typing import Any

from pydantic import BaseModel, Field

from k8s_lens_mcp.utils.k8s_client import get_k8s_client


class AdviseResourcesInput(BaseModel):
    """Input schema for advise_resources tool."""

    namespace: str | None = Field(
        None, description="Namespace to scope to. Omit for all namespaces."
    )


async def advise_resources(input: AdviseResourcesInput) -> dict[str, Any]:
    """Scan cluster for optimization opportunities.

    Identifies:
    - Idle pods (near-zero CPU usage)
    - Over-provisioned CPU/memory (requests >> actual usage)
    - Missing HPA on Deployments with fluctuating load
    - Orphaned PVCs (not bound to running workloads)

    Args:
        input: AdviseResourcesInput with optional namespace filter.

    Returns:
        Structured recommendations with estimated savings.
    """
    client = get_k8s_client()
    ns = input.namespace
    recommendations: list[dict[str, Any]] = []

    # ------------------------------------------------------------------
    # 1. Fetch pods + metrics
    # ------------------------------------------------------------------
    try:
        pods = client.list_resources("pods", namespace=ns)
        metrics = client.get_pod_metrics(namespace=ns)
    except Exception as exc:
        return {"error": True, "message": str(exc)}

    pod_items = pods.get("items", [])
    metric_items = {m["metadata"]["name"]: m for m in metrics.get("items", [])}

    # ------------------------------------------------------------------
    # 2. Idle / over-provisioned pods
    # ------------------------------------------------------------------
    idle_threshold_cpu_millicores = 10  # < 10m CPU considered idle
    overprovision_ratio = 5.0  # request > 5x usage

    for pod in pod_items:
        pod_name = pod.get("metadata", {}).get("name", "unknown")
        pod_ns = pod.get("metadata", {}).get("namespace", "unknown")
        spec = pod.get("spec", {})
        containers = spec.get("containers", [])

        # Sum requests
        total_cpu_request = 0.0  # in millicores
        total_mem_request = 0.0  # in Mi
        for c in containers:
            resources = c.get("resources", {}).get("requests", {})
            cpu_str = resources.get("cpu", "0")
            mem_str = resources.get("memory", "0")
            total_cpu_request += _parse_cpu(cpu_str)
            total_mem_request += _parse_memory(mem_str)

        # Get actual usage from metrics
        metric = metric_items.get(pod_name, {})
        containers_usage = metric.get("containers", [])
        total_cpu_usage = sum(
            _parse_cpu(c.get("usage", {}).get("cpu", "0")) for c in containers_usage
        )
        total_mem_usage = sum(
            _parse_memory(c.get("usage", {}).get("memory", "0")) for c in containers_usage
        )

        # Idle pod check
        if total_cpu_request > 0 and total_cpu_usage < idle_threshold_cpu_millicores:
            age = _humanize_age(pod.get("metadata", {}).get("creationTimestamp"))
            recommendations.append(
                {
                    "type": "idle_pod",
                    "severity": "medium",
                    "resource": f"pod/{pod_ns}/{pod_name}",
                    "message": (
                        f"Pod is nearly idle ({total_cpu_usage:.0f}m CPU used vs "
                        f"{total_cpu_request:.0f}m requested)."
                    ),
                    "suggestion": "Consider scaling down or removing if not needed.",
                    "age": age,
                }
            )

        # Over-provisioned CPU check
        if total_cpu_request > 0 and total_cpu_usage > 0:
            ratio = total_cpu_request / max(total_cpu_usage, 1)
            if ratio > overprovision_ratio:
                recommendations.append(
                    {
                        "type": "overprovisioned_cpu",
                        "severity": "low",
                        "resource": f"pod/{pod_ns}/{pod_name}",
                        "message": (
                            f"CPU request ({total_cpu_request:.0f}m) is "
                            f"{ratio:.1f}x actual usage ({total_cpu_usage:.0f}m)."
                        ),
                        "suggestion": "Lower CPU requests to improve bin-packing.",
                    }
                )

        # Over-provisioned memory check
        if total_mem_request > 0 and total_mem_usage > 0:
            mem_ratio = total_mem_request / max(total_mem_usage, 1)
            if mem_ratio > overprovision_ratio:
                recommendations.append(
                    {
                        "type": "overprovisioned_memory",
                        "severity": "low",
                        "resource": f"pod/{pod_ns}/{pod_name}",
                        "message": (
                            f"Memory request ({total_mem_request:.0f}Mi) is "
                            f"{mem_ratio:.1f}x actual usage ({total_mem_usage:.0f}Mi)."
                        ),
                        "suggestion": "Lower memory requests to improve bin-packing.",
                    }
                )

    # ------------------------------------------------------------------
    # 3. Missing HPA on Deployments
    # ------------------------------------------------------------------
    try:
        deployments = client.list_resources("deployments", namespace=ns)
        hpas = client.list_resources("horizontalpodautoscalers", namespace=ns)
    except Exception:
        # metrics-server or HPA API may not be available
        deployments = {"items": []}
        hpas = {"items": []}

    hpa_targets = set()
    for hpa in hpas.get("items", []):
        spec = hpa.get("spec", {})
        scale_target = spec.get("scaleTargetRef", {})
        if scale_target.get("kind") == "Deployment":
            hpa_targets.add(scale_target.get("name"))

    for dep in deployments.get("items", []):
        dep_name = dep.get("metadata", {}).get("name", "unknown")
        dep_ns = dep.get("metadata", {}).get("namespace", "unknown")
        replicas = dep.get("spec", {}).get("replicas", 1)
        if replicas > 1 and dep_name not in hpa_targets:
            recommendations.append(
                {
                    "type": "missing_hpa",
                    "severity": "low",
                    "resource": f"deployment/{dep_ns}/{dep_name}",
                    "message": f"Deployment has {replicas} replicas but no HPA configured.",
                    "suggestion": "Add a HorizontalPodAutoscaler for automatic scaling.",
                }
            )

    # ------------------------------------------------------------------
    # 4. Orphaned PVCs
    # ------------------------------------------------------------------
    try:
        pvcs = client.list_resources("persistentvolumeclaims", namespace=ns)
        pods_with_pvcs = set()
        for pod in pod_items:
            volumes = pod.get("spec", {}).get("volumes", [])
            for vol in volumes:
                if "persistentVolumeClaim" in vol:
                    claim_name = vol["persistentVolumeClaim"].get("claimName")
                    if claim_name:
                        pods_with_pvcs.add(claim_name)

        for pvc in pvcs.get("items", []):
            pvc_name = pvc.get("metadata", {}).get("name", "unknown")
            pvc_ns = pvc.get("metadata", {}).get("namespace", "unknown")
            if pvc_name not in pods_with_pvcs:
                status = pvc.get("status", {}).get("phase", "Unknown")
                recommendations.append(
                    {
                        "type": "orphaned_pvc",
                        "severity": "medium",
                        "resource": f"pvc/{pvc_ns}/{pvc_name}",
                        "message": f"PVC is not referenced by any running pod (status: {status}).",
                        "suggestion": "Review and delete if no longer needed.",
                    }
                )
    except Exception:
        pass

    # ------------------------------------------------------------------
    # Summary
    # ------------------------------------------------------------------
    severity_counts = {"high": 0, "medium": 0, "low": 0}
    for r in recommendations:
        severity_counts[r.get("severity", "low")] += 1

    return {
        "namespace": ns or "all",
        "total_recommendations": len(recommendations),
        "severity_counts": severity_counts,
        "recommendations": sorted(
            recommendations, key=lambda x: ("high", "medium", "low").index(x["severity"])
        ),
    }


def _parse_cpu(value: str) -> float:
    """Parse a Kubernetes CPU string to millicores."""
    if value.endswith("m"):
        return float(value[:-1])
    if value:
        return float(value) * 1000
    return 0.0


def _parse_memory(value: str) -> float:
    """Parse a Kubernetes memory string to MiB."""
    if value.endswith("Ki"):
        return float(value[:-2]) / 1024
    if value.endswith("Mi"):
        return float(value[:-2])
    if value.endswith("Gi"):
        return float(value[:-2]) * 1024
    if value.endswith("Ti"):
        return float(value[:-2]) * 1024 * 1024
    if value.endswith("k"):
        return float(value[:-1]) / (1024 * 1024)
    if value.endswith("M"):
        return float(value[:-1]) / 1.049
    if value.endswith("G"):
        return float(value[:-1]) * 953.7
    if value:
        return float(value) / (1024 * 1024)
    return 0.0


def _humanize_age(iso_timestamp: str | None) -> str:
    """Convert an ISO 8601 timestamp to a human-readable age string."""
    from datetime import UTC, datetime

    if not iso_timestamp:
        return "unknown"
    try:
        dt = datetime.fromisoformat(iso_timestamp.replace("Z", "+00:00"))
    except ValueError:
        return "unknown"
    delta = datetime.now(UTC) - dt
    total_seconds = int(delta.total_seconds())
    if total_seconds < 60:
        return f"{total_seconds}s"
    minutes = total_seconds // 60
    if minutes < 60:
        return f"{minutes}m"
    hours = minutes // 60
    if hours < 24:
        return f"{hours}h"
    days = hours // 24
    if days < 7:
        return f"{days}d"
    weeks = days // 7
    if weeks < 52:
        return f"{weeks}w"
    years = days // 365
    return f"{years}y"
