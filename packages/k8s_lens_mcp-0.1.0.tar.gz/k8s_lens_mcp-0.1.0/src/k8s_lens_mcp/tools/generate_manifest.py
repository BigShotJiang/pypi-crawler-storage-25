"""Tool: generate_manifest — create K8s manifests from natural language."""

import re

import yaml
from pydantic import BaseModel, Field


class GenerateManifestInput(BaseModel):
    """Input schema for generate_manifest tool."""

    description: str = Field(..., description="Natural language description of desired resources")
    kind: str | None = Field(
        None, description="Specific kind: Deployment, Service, Ingress, ConfigMap"
    )
    namespace: str | None = Field(None, description="Target namespace")


# ------------------------------------------------------------------
# Keyword extraction
# ------------------------------------------------------------------


def _extract_replicas(description: str) -> int:
    """Look for a number before 'replica' or 'replicas'."""
    match = re.search(r"(\d+)\s+replicas?", description, re.IGNORECASE)
    return int(match.group(1)) if match else 1


def _extract_ports(description: str) -> list[int]:
    """Look for port numbers in the description."""
    # Patterns: "port 80", "on port 8080", "ports 80 and 443"
    matches = re.findall(r"\bport[s]?\s+(\d+)", description, re.IGNORECASE)
    # Also catch "ports 80 and 443" (multiple ports after 'ports')
    multi_match = re.search(r"\bports\s+(\d+)(?:\s+and\s+(\d+))?", description, re.IGNORECASE)
    if multi_match:
        matches = [multi_match.group(1)]
        if multi_match.group(2):
            matches.append(multi_match.group(2))
    # Also catch "expose on 80" or "listen on 8080"
    matches += re.findall(r"\bon\s+(\d{2,5})\b", description, re.IGNORECASE)
    seen = set()
    ports = []
    for m in matches:
        p = int(m)
        if p not in seen and 1 <= p <= 65535:
            seen.add(p)
            ports.append(p)
    return ports or [80]


def _extract_service_type(description: str) -> str:
    """Detect service type from description."""
    desc_lower = description.lower()
    if "loadbalancer" in desc_lower or "load balancer" in desc_lower:
        return "LoadBalancer"
    if "nodeport" in desc_lower or "node port" in desc_lower:
        return "NodePort"
    return "ClusterIP"


def _extract_app_name(description: str) -> str:
    """Guess the application name from the description."""
    # Common app names
    common = [
        "nginx",
        "redis",
        "postgres",
        "mysql",
        "mongodb",
        "httpd",
        "apache",
        "grafana",
        "prometheus",
        "elasticsearch",
        "kafka",
        "rabbitmq",
    ]
    desc_lower = description.lower()
    for app in common:
        if app in desc_lower:
            return app
    # Fallback: first word that looks like a noun
    words = re.findall(r"[a-zA-Z][a-zA-Z0-9_-]*", description)
    for w in words:
        if w.lower() not in {
            "create",
            "a",
            "an",
            "the",
            "with",
            "and",
            "or",
            "for",
            "in",
            "on",
            "to",
            "from",
            "of",
            "deploy",
            "generate",
            "basic",
            "simple",
        }:
            return w.lower()
    return "app"


def _determine_kind(description: str, explicit_kind: str | None) -> list[str]:
    """Determine which resource kinds to generate."""
    if explicit_kind:
        return [explicit_kind]
    desc_lower = description.lower()
    kinds = []
    if any(w in desc_lower for w in ("deployment", "deploy")):
        kinds.append("Deployment")
    if any(w in desc_lower for w in ("service", "expose")):
        kinds.append("Service")
    if "ingress" in desc_lower:
        kinds.append("Ingress")
    if "configmap" in desc_lower or "config map" in desc_lower:
        kinds.append("ConfigMap")
    # If only Deployment detected, auto-add Service for completeness
    if kinds == ["Deployment"]:
        kinds.append("Service")
    # Default: if no kinds detected, generate Deployment + Service
    if not kinds:
        kinds = ["Deployment", "Service"]
    return kinds


# ------------------------------------------------------------------
# Manifest builders
# ------------------------------------------------------------------


def _build_deployment(
    name: str,
    namespace: str | None,
    image: str,
    replicas: int,
    ports: list[int],
) -> dict:
    """Build a best-practice Deployment manifest."""
    main_port = ports[0] if ports else 80
    labels = {"app": name}

    container = {
        "name": name,
        "image": image,
        "ports": [{"containerPort": p} for p in ports],
        "resources": {
            "requests": {"cpu": "100m", "memory": "128Mi"},
            "limits": {"cpu": "500m", "memory": "512Mi"},
        },
        "livenessProbe": {
            "tcpSocket": {"port": main_port},
            "initialDelaySeconds": 30,
            "periodSeconds": 10,
        },
        "readinessProbe": {
            "tcpSocket": {"port": main_port},
            "initialDelaySeconds": 5,
            "periodSeconds": 5,
        },
        "securityContext": {
            "allowPrivilegeEscalation": False,
            "readOnlyRootFilesystem": True,
            "runAsNonRoot": True,
            "runAsUser": 1000,
            "capabilities": {"drop": ["ALL"]},
        },
    }

    deployment = {
        "apiVersion": "apps/v1",
        "kind": "Deployment",
        "metadata": {
            "name": name,
            "labels": labels,
        },
        "spec": {
            "replicas": replicas,
            "selector": {"matchLabels": labels},
            "template": {
                "metadata": {"labels": labels},
                "spec": {
                    "containers": [container],
                    "securityContext": {
                        "runAsNonRoot": True,
                        "seccompProfile": {"type": "RuntimeDefault"},
                    },
                },
            },
        },
    }

    if namespace:
        deployment["metadata"]["namespace"] = namespace

    return deployment


def _build_service(
    name: str,
    namespace: str | None,
    ports: list[int],
    service_type: str,
) -> dict:
    """Build a Service manifest."""
    labels = {"app": name}

    svc = {
        "apiVersion": "v1",
        "kind": "Service",
        "metadata": {
            "name": name,
            "labels": labels,
        },
        "spec": {
            "type": service_type,
            "selector": labels,
            "ports": [{"port": p, "targetPort": p, "protocol": "TCP"} for p in ports],
        },
    }

    if namespace:
        svc["metadata"]["namespace"] = namespace

    return svc


def _build_ingress(
    name: str,
    namespace: str | None,
    host: str | None,
    ports: list[int],
) -> dict:
    """Build a basic Ingress manifest."""
    main_port = ports[0] if ports else 80
    host = host or f"{name}.example.com"

    ingress = {
        "apiVersion": "networking.k8s.io/v1",
        "kind": "Ingress",
        "metadata": {
            "name": name,
            "annotations": {
                "nginx.ingress.kubernetes.io/rewrite-target": "/",
            },
        },
        "spec": {
            "rules": [
                {
                    "host": host,
                    "http": {
                        "paths": [
                            {
                                "path": "/",
                                "pathType": "Prefix",
                                "backend": {
                                    "service": {
                                        "name": name,
                                        "port": {"number": main_port},
                                    }
                                },
                            }
                        ]
                    },
                }
            ]
        },
    }

    if namespace:
        ingress["metadata"]["namespace"] = namespace

    return ingress


def _build_configmap(
    name: str,
    namespace: str | None,
    data: dict[str, str] | None,
) -> dict:
    """Build a ConfigMap manifest."""
    cm = {
        "apiVersion": "v1",
        "kind": "ConfigMap",
        "metadata": {"name": name},
        "data": data or {"key": "value"},
    }

    if namespace:
        cm["metadata"]["namespace"] = namespace

    return cm


# ------------------------------------------------------------------
# Main tool
# ------------------------------------------------------------------


def _resolve_image(name: str) -> str:
    """Map common app names to default Docker Hub images."""
    mapping = {
        "nginx": "nginx:latest",
        "redis": "redis:7-alpine",
        "postgres": "postgres:16-alpine",
        "mysql": "mysql:8",
        "mongodb": "mongo:7",
        "httpd": "httpd:latest",
        "apache": "httpd:latest",
        "grafana": "grafana/grafana:latest",
        "prometheus": "prom/prometheus:latest",
    }
    return mapping.get(name, f"{name}:latest")


async def generate_manifest(input: GenerateManifestInput) -> dict:
    """Generate best-practice Kubernetes manifests from a description.

    Args:
        input: GenerateManifestInput with description and optional constraints.

    Returns:
        Valid YAML manifest(s) and an explanation.
    """
    description = input.description
    kinds = _determine_kind(description, input.kind)
    name = _extract_app_name(description)
    replicas = _extract_replicas(description)
    ports = _extract_ports(description)
    service_type = _extract_service_type(description)
    namespace = input.namespace
    image = _resolve_image(name)

    manifests: list[dict] = []
    generated_kinds: list[str] = []

    for kind in kinds:
        if kind == "Deployment":
            manifests.append(_build_deployment(name, namespace, image, replicas, ports))
            generated_kinds.append("Deployment")
        elif kind == "Service":
            manifests.append(_build_service(name, namespace, ports, service_type))
            generated_kinds.append(f"{service_type} Service")
        elif kind == "Ingress":
            manifests.append(_build_ingress(name, namespace, None, ports))
            generated_kinds.append("Ingress")
        elif kind == "ConfigMap":
            manifests.append(_build_configmap(name, namespace, None))
            generated_kinds.append("ConfigMap")

    # Join manifests with a document separator
    yaml_docs = [yaml.dump(m, sort_keys=False, default_flow_style=False) for m in manifests]
    combined_yaml = "\n---\n".join(yaml_docs)

    explanation = (
        f"Generated {', '.join(generated_kinds)} for '{name}' "
        f"with {replicas} replica(s), port(s) {ports}, "
        f"image '{image}'."
    )
    if namespace:
        explanation += f" Namespace: {namespace}."

    return {
        "name": name,
        "kinds": kinds,
        "explanation": explanation,
        "yaml": combined_yaml,
        "can_apply": True,
    }
