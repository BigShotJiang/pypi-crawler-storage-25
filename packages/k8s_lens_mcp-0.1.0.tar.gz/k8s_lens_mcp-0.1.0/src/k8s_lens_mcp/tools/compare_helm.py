"""Tool: compare_helm_releases — diff Helm releases across environments."""

import subprocess
from typing import Any

from pydantic import BaseModel, Field


class CompareHelmReleasesInput(BaseModel):
    """Input schema for compare_helm_releases tool."""

    release_name: str = Field(..., description="Name of the Helm release to compare")
    namespace_a: str = Field(..., description="Namespace of first release")
    namespace_b: str = Field(..., description="Namespace of second release")
    context_a: str | None = Field(None, description="Context for first release")
    context_b: str | None = Field(None, description="Context for second release")


def _helm_get_manifest(release: str, namespace: str, context: str | None = None) -> str:
    """Fetch the rendered manifest for a Helm release."""
    cmd = ["helm", "get", "manifest", release, "--namespace", namespace]
    if context:
        cmd += ["--kube-context", context]
    result = subprocess.run(cmd, capture_output=True, text=True, check=False)
    if result.returncode != 0:
        raise RuntimeError(f"helm get manifest failed: {result.stderr}")
    return result.stdout


def _helm_get_values(release: str, namespace: str, context: str | None = None) -> str:
    """Fetch the user-supplied values for a Helm release."""
    cmd = ["helm", "get", "values", release, "--namespace", namespace, "--all"]
    if context:
        cmd += ["--kube-context", context]
    result = subprocess.run(cmd, capture_output=True, text=True, check=False)
    if result.returncode != 0:
        raise RuntimeError(f"helm get values failed: {result.stderr}")
    return result.stdout


def _parse_manifests(manifest_yaml: str) -> dict[str, str]:
    """Split a multi-document YAML into a dict keyed by kind/name."""
    docs: dict[str, str] = {}
    current_lines: list[str] = []
    current_key: str | None = None

    for line in manifest_yaml.splitlines(keepends=True):
        if line.startswith("---") or line.startswith("apiVersion:"):
            if current_key and current_lines:
                docs[current_key] = "".join(current_lines)
            current_lines = [line] if line.startswith("apiVersion:") else []
            current_key = None
        else:
            current_lines.append(line)
            if line.startswith("kind:"):
                kind = line.split(":", 1)[1].strip()
                current_key = kind if not current_key else f"{current_key}/{kind}"
            elif line.startswith("metadata:"):
                pass  # name comes after metadata:
            elif line.startswith("  name:") and current_key:
                name = line.split(":", 1)[1].strip()
                current_key = f"{current_key}/{name}"

    if current_key and current_lines:
        docs[current_key] = "".join(current_lines)

    return docs


def _diff_manifests(a: dict[str, str], b: dict[str, str]) -> dict[str, Any]:
    """Compute structural differences between two manifest sets."""
    keys_a = set(a.keys())
    keys_b = set(b.keys())

    added = sorted(keys_b - keys_a)
    removed = sorted(keys_a - keys_b)
    changed: list[dict[str, Any]] = []

    for key in sorted(keys_a & keys_b):
        if a[key].strip() != b[key].strip():
            changed.append({"resource": key})

    return {
        "added": added,
        "removed": removed,
        "changed": changed,
        "total_changes": len(added) + len(removed) + len(changed),
    }


async def compare_helm_releases(input: CompareHelmReleasesInput) -> dict[str, Any]:
    """Diff two Helm releases across namespaces or clusters.

    Args:
        input: CompareHelmReleasesInput specifying both sides.

    Returns:
        Structured diff of manifests and values.
    """
    try:
        manifest_a = _helm_get_manifest(input.release_name, input.namespace_a, input.context_a)
        manifest_b = _helm_get_manifest(input.release_name, input.namespace_b, input.context_b)
        values_a = _helm_get_values(input.release_name, input.namespace_a, input.context_a)
        values_b = _helm_get_values(input.release_name, input.namespace_b, input.context_b)
    except RuntimeError as exc:
        return {"error": True, "message": str(exc)}

    docs_a = _parse_manifests(manifest_a)
    docs_b = _parse_manifests(manifest_b)
    manifest_diff = _diff_manifests(docs_a, docs_b)

    values_drift = values_a.strip() != values_b.strip()

    return {
        "release_name": input.release_name,
        "side_a": {"namespace": input.namespace_a, "context": input.context_a},
        "side_b": {"namespace": input.namespace_b, "context": input.context_b},
        "manifest_diff": manifest_diff,
        "values_drift": values_drift,
        "total_changes": manifest_diff["total_changes"] + (1 if values_drift else 0),
    }
