"""K8s Lens MCP — Intelligent Kubernetes natural language interface."""

__version__ = "0.1.0"
