"""kubectl plugin wrapper for K8s Lens MCP.

Usage:
    kubectl lens "show all failing pods"
    kubectl lens --namespace staging "why is my api pod crashing"
"""

import argparse
import subprocess
import sys


def main() -> None:
    """Entry point for kubectl-lens plugin."""
    parser = argparse.ArgumentParser(
        description="Natural language kubectl wrapper powered by K8s Lens MCP",
        usage='kubectl lens [options] "<natural language query>"',
    )
    parser.add_argument(
        "--namespace",
        "-n",
        default="default",
        help="Target namespace (default: default)",
    )
    parser.add_argument(
        "--context",
        "-c",
        default=None,
        help="Kubernetes context to use",
    )
    parser.add_argument(
        "query",
        nargs="*",
        help="Natural language query (e.g. 'show failing pods')",
    )
    args = parser.parse_args()

    query = " ".join(args.query) if args.query else ""
    if not query:
        parser.print_help()
        sys.exit(1)

    # Translate common natural language patterns to kubectl commands
    cmd = _translate(query, args.namespace, args.context)
    if cmd:
        print(f"$ {' '.join(cmd)}")
        subprocess.run(cmd, check=False)
    else:
        print(f"No direct kubectl translation for: '{query}'")
        print("Try asking through the MCP server for deeper analysis.")


def _translate(query: str, namespace: str, context: str | None) -> list[str] | None:
    """Attempt to translate a natural language query to a kubectl command."""
    q = query.lower()

    base = ["kubectl"]
    if context:
        base += ["--context", context]
    base += ["-n", namespace]

    if "pod" in q or "pods" in q:
        if "failing" in q or "crash" in q or "error" in q:
            return base + ["get", "pods", "--field-selector=status.phase!=Running"]
        if "all" in q:
            return base + ["get", "pods"]
        return base + ["get", "pods"]

    if "deployment" in q or "deployments" in q:
        return base + ["get", "deployments"]

    if "service" in q or "services" in q:
        return base + ["get", "services"]

    if "node" in q or "nodes" in q:
        return ["kubectl"] + (["--context", context] if context else []) + ["get", "nodes"]

    if "event" in q or "events" in q:
        return base + ["get", "events", "--sort-by=.lastTimestamp"]

    if "log" in q:
        # Extract pod name heuristic: last word before 'log' or last word overall
        return base + ["logs", "--tail=100"]

    return None
