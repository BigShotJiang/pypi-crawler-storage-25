"""Configuration and safety settings for K8s Lens MCP."""

from pydantic import BaseModel, Field, field_validator


class Settings(BaseModel):
    """Server-wide configuration."""

    read_only: bool = Field(
        default=True,
        description="If True, mutation tools are disabled.",
    )
    context: str | None = Field(
        default=None,
        description="Kubernetes context to use.",
    )
    contexts: list[str] = Field(
        default_factory=list,
        description="Multiple Kubernetes contexts for multi-cluster queries.",
    )
    namespace: str = Field(
        default="default",
        description="Default namespace for unqualified queries.",
    )
    verbose: bool = Field(
        default=False,
        description="Enable verbose (debug) logging.",
    )

    @field_validator("namespace")
    @classmethod
    def _strip_namespace(cls, value: str) -> str:
        return value.strip()
