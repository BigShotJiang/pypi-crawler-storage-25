"""MCP server entry point for K8s Lens MCP."""

import argparse
import asyncio
import logging
import os
from typing import Any

from mcp.server import Server
from mcp.server.sse import SseServerTransport
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool
from starlette.applications import Starlette
from starlette.requests import Request
from starlette.routing import Mount, Route

from k8s_lens_mcp.config import Settings
from k8s_lens_mcp.tools.advise_resources import AdviseResourcesInput, advise_resources
from k8s_lens_mcp.tools.analyze_pod import AnalyzePodInput, analyze_pod
from k8s_lens_mcp.tools.compare_deployments import (
    CompareDeploymentsInput,
    compare_deployments,
)
from k8s_lens_mcp.tools.compare_helm import CompareHelmReleasesInput, compare_helm_releases
from k8s_lens_mcp.tools.generate_manifest import GenerateManifestInput, generate_manifest
from k8s_lens_mcp.tools.get_resources import GetResourcesInput, get_resources

# Optional OpenTelemetry tracing
try:  # pragma: no cover
    from opentelemetry import trace
    from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
    from opentelemetry.sdk.resources import Resource as OTelResource
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.trace.export import BatchSpanProcessor

    _otel_available = True
except ImportError:
    _otel_available = False
    trace = None  # type: ignore[misc,assignment]

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("k8s-lens-mcp")

app = Server("k8s-lens-mcp")

# Tools that mutate cluster state (future: apply, delete, scale, etc.)
MUTATION_TOOLS: set[str] = set()

# Server settings set at startup; used by call_tool for read-only enforcement
_settings: Settings | None = None


TOOLS = [
    Tool(
        name="health",
        description=(
            "Check the server health and connectivity to the Kubernetes cluster. "
            "Returns the server status, configured context, and default namespace."
        ),
        inputSchema={"type": "object", "properties": {}},
    ),
    Tool(
        name="get_resources",
        description=(
            "Query Kubernetes resources with flexible filters. Supports pods, "
            "deployments, services, nodes, and more. Filter by namespace, status, "
            "labels, or field selectors. Example prompts: "
            "'Show me all pods with status CrashLoopBackOff in namespace staging', "
            "'List all deployments in the default namespace', "
            "'Get nodes with label zone=us-east-1'."
        ),
        inputSchema=GetResourcesInput.model_json_schema(),
    ),
    Tool(
        name="analyze_pod",
        description=(
            "Perform deep root-cause analysis on a failing or misbehaving pod. "
            "Correlates pod status, recent events, container logs, resource limits, "
            "and node conditions to diagnose the issue. Example prompts: "
            "'Why is my-pod failing?', 'Why does my-pod keep restarting?', "
            "'Diagnose pod my-pod in namespace production'."
        ),
        inputSchema=AnalyzePodInput.model_json_schema(),
    ),
    Tool(
        name="compare_deployments",
        description=(
            "Diff two Kubernetes resources (e.g., Deployments) across namespaces "
            "or clusters. Strips volatile metadata (UIDs, resourceVersions, timestamps) "
            "and returns a structured diff showing added, removed, and changed fields. "
            "Example prompts: 'Diff the nginx deployment between staging and prod', "
            "'Compare the api deployment in dev vs production'."
        ),
        inputSchema=CompareDeploymentsInput.model_json_schema(),
    ),
    Tool(
        name="generate_manifest",
        description=(
            "Generate best-practice Kubernetes YAML manifests from a natural language "
            "description. Supports Deployments, Services, Ingresses, and ConfigMaps. "
            "Returns valid, ready-to-apply YAML with sensible defaults for replicas, "
            "resource requests, probes, and labels. Example prompts: "
            "'Create a basic nginx deployment with 2 replicas and a LoadBalancer service', "
            "'Generate a Redis deployment with a ClusterIP service on port 6379'."
        ),
        inputSchema=GenerateManifestInput.model_json_schema(),
    ),
    Tool(
        name="compare_helm_releases",
        description=(
            "Diff Helm releases across namespaces or clusters. Compares rendered "
            "manifests and values to detect drift. Example prompts: "
            "'Diff the nginx Helm release between staging and prod', "
            "'Compare the api release values in dev vs production'."
        ),
        inputSchema=CompareHelmReleasesInput.model_json_schema(),
    ),
    Tool(
        name="advise_resources",
        description=(
            "Scan the cluster for resource optimization opportunities. Identifies "
            "idle pods, over-provisioned CPU/memory, missing HPAs, and orphaned PVCs. "
            "Example prompts: 'Find waste in the cluster', "
            "'Which pods are over-provisioned?', 'Show me idle resources'."
        ),
        inputSchema=AdviseResourcesInput.model_json_schema(),
    ),
]


@app.list_tools()
async def list_tools() -> list[Tool]:
    """Return the list of available tools."""
    return TOOLS  # pragma: no cover


def _init_tracer() -> Any | None:
    """Initialize OpenTelemetry tracer if OTLP endpoint is configured."""
    if not _otel_available:  # pragma: no cover
        return None  # pragma: no cover
    endpoint = os.getenv("OTEL_EXPORTER_OTLP_ENDPOINT")  # pragma: no cover
    if not endpoint:  # pragma: no cover
        return None
    provider = TracerProvider(  # pragma: no cover
        resource=OTelResource.create({"service.name": "k8s-lens-mcp", "service.version": "0.1.0"})
    )
    exporter = OTLPSpanExporter(endpoint=endpoint, insecure=True)  # pragma: no cover
    provider.add_span_processor(BatchSpanProcessor(exporter))  # pragma: no cover
    trace.set_tracer_provider(provider)  # pragma: no cover
    return trace.get_tracer("k8s-lens-mcp")  # pragma: no cover


_tracer = None


@app.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    """Dispatch tool calls to the appropriate handler."""
    global _tracer
    if _tracer is None:
        _tracer = _init_tracer()

    logger.info("Tool call: %s with args: %s", name, arguments)

    span = None
    if _tracer is not None:
        span = _tracer.start_as_current_span(
            f"tool.{name}",
            attributes={
                "mcp.tool_name": name,
                "mcp.arguments": str(arguments),
            },
        ).__enter__()

    try:
        if _settings and _settings.read_only and name in MUTATION_TOOLS:
            return [
                TextContent(
                    type="text",
                    text=(
                        f"Error: Tool '{name}' is disabled because the server "
                        "is running in read-only mode."
                    ),
                )
            ]

        if name == "health":
            result = {"status": "healthy", "server": "k8s-lens-mcp", "version": "0.1.0"}
        elif name == "get_resources":
            # Inject configured contexts if the user didn't specify any
            if _settings and _settings.contexts and not arguments.get("contexts"):
                arguments = {**arguments, "contexts": _settings.contexts}
            result = await get_resources(GetResourcesInput(**arguments))
        elif name == "analyze_pod":
            result = await analyze_pod(AnalyzePodInput(**arguments))
        elif name == "compare_deployments":
            result = await compare_deployments(CompareDeploymentsInput(**arguments))
        elif name == "generate_manifest":
            result = await generate_manifest(GenerateManifestInput(**arguments))
        elif name == "compare_helm_releases":
            result = await compare_helm_releases(CompareHelmReleasesInput(**arguments))
        elif name == "advise_resources":
            result = await advise_resources(AdviseResourcesInput(**arguments))
        else:
            raise ValueError(f"Unknown tool: {name}")

        if span is not None:
            span.set_attribute("mcp.result_length", len(str(result)))
            span.__exit__(None, None, None)

        return [TextContent(type="text", text=str(result))]
    except Exception as exc:
        logger.exception("Tool %s failed", name)
        if span is not None:
            span.set_attribute("error", True)
            span.set_attribute("error.message", str(exc))
            span.__exit__(type(exc), exc, exc.__traceback__)
        return [TextContent(type="text", text=f"Error: {exc}")]


async def run_stdio_server(settings: Settings) -> None:
    """Run the MCP server over stdio transport."""
    global _settings
    _settings = settings
    logger.info("Starting K8s Lens MCP on stdio (read_only=%s)", settings.read_only)
    async with stdio_server() as (read_stream, write_stream):
        await app.run(
            read_stream,
            write_stream,
            app.create_initialization_options(),
        )


async def run_sse_server(settings: Settings, port: int) -> None:
    """Run the MCP server over SSE transport."""
    global _settings
    _settings = settings
    logger.info("Starting K8s Lens MCP on SSE port %d (read_only=%s)", port, settings.read_only)
    sse = SseServerTransport("/messages/")

    async def handle_sse(request: Request) -> None:  # pragma: no cover
        async with sse.connect_sse(request.scope, request.receive, request._send) as (
            read_stream,
            write_stream,
        ):
            await app.run(
                read_stream,
                write_stream,
                app.create_initialization_options(),
            )

    starlette_app = Starlette(
        debug=settings.verbose,
        routes=[
            Route("/sse", endpoint=handle_sse),
            Mount("/messages/", app=sse.handle_post_message),
        ],
    )

    import uvicorn

    config = uvicorn.Config(starlette_app, host="127.0.0.1", port=port, log_level="info")
    server = uvicorn.Server(config)
    await server.serve()


def main() -> None:
    """CLI entry point."""
    parser = argparse.ArgumentParser(description="K8s Lens MCP Server")
    parser.add_argument(
        "--read-only",
        type=lambda x: x.lower() in ("true", "1", "yes"),
        default=True,
        help="Run in read-only mode (default: true)",
    )
    parser.add_argument(
        "--context",
        type=str,
        default=None,
        help="Kubernetes context to use",
    )
    parser.add_argument(
        "--contexts",
        type=str,
        default=None,
        help="Comma-separated list of contexts for multi-cluster queries",
    )
    parser.add_argument(
        "--namespace",
        type=str,
        default="default",
        help="Default namespace",
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Enable verbose logging",
    )
    parser.add_argument(
        "--transport",
        choices=["stdio", "sse"],
        default="stdio",
        help="Transport protocol (default: stdio)",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=8000,
        help="Port for SSE transport (default: 8000)",
    )
    args = parser.parse_args()

    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)

    contexts = [c.strip() for c in args.contexts.split(",")] if args.contexts else []
    settings = Settings(
        read_only=args.read_only,
        context=args.context,
        contexts=contexts,
        namespace=args.namespace,
        verbose=args.verbose,
    )

    if args.transport == "stdio":
        asyncio.run(run_stdio_server(settings))
    elif args.transport == "sse":
        asyncio.run(run_sse_server(settings, args.port))


if __name__ == "__main__":  # pragma: no cover
    main()
