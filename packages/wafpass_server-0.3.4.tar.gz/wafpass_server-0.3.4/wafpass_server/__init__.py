from importlib.metadata import PackageNotFoundError, version as _pkg_version

try:
    __version__ = _pkg_version("wafpass-server")
except PackageNotFoundError:
    __version__ = "0.3.0-dev"
