"""
This package has been renamed to kanbaroo-mcp.

Install kanbaroo-mcp instead: pip install kanbaroo-mcp
"""

import warnings

warnings.warn(
    "The 'kanberoo-mcp' package has been renamed to 'kanbaroo-mcp'. "
    "Please update your installation: pip install kanbaroo-mcp",
    DeprecationWarning,
    stacklevel=2,
)

__version__ = "0.2.2"
