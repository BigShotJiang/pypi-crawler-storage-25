# `kanberoo-mcp` has been renamed

This package has been renamed to [`kanbaroo-mcp`](https://pypi.org/project/kanbaroo-mcp/). The name is a portmanteau of `kangaroo` + `kanban`; the middle letter should have been `a` from the start.

## What to install

```
pip install kanbaroo-mcp
```

## Compatibility

This `kanberoo-mcp` package remains on PyPI as a version-`0.2.2` compatibility stub that transitively installs `kanbaroo-mcp==0.2.2`. `pip install kanberoo-mcp` still works; the canonical name going forward is `kanbaroo-mcp`. Please update your requirements files and scripts.

## Links

- New package: https://pypi.org/project/kanbaroo-mcp/
- GitHub: https://github.com/areese801/kanbaroo
