########################################################################################################################
# IMPORTS

import logging
from typing import Any, Dict
from urllib.parse import quote_plus

########################################################################################################################
# TYPES / CONSTANTS

logger = logging.getLogger(__name__)

########################################################################################################################
# CLASSES


class ClickHouseInterface:
    def __init__(self, config: Dict[str, Any]) -> None:
        if "clickhouse" in config:
            self.config = config["clickhouse"]

        else:
            logger.warning("no clickhouse section in config")

    def get_conn_str(self) -> str | None:
        """Build the connection string from the configuration **WITHOUT THE DATABASE**

        Returns:
            str: returns the connection string or None
        """
        return (
            f"{self.config['engine']}://"
            f"{self.config['user']}:{quote_plus(self.config['password'])}"
            f"@{self.config['host']}:{self.config['clickhouse_connect_port']}"
        )
