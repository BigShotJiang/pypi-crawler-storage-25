"""Harbormaster — MCP server that routes Q&A across many projects and SSH hosts.

Part of the FleetQ ecosystem. Standalone OSS works fully; FleetQ integration is opt-in.
"""

__version__ = "4.0.0"
__all__ = ["__version__"]
