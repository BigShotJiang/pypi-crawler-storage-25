# Citnega 9+ Independent Scorecard

Generated at: 2026-04-15T02:36:33.218983+00:00
Weighted overall score: 9.80/10
Pass threshold met (>= 9.0): yes
All checks passed: yes
CI gate passed: yes

| Category | Score | Weight | Weighted Contribution | Passed Checks |
|---|---:|---:|---:|---:|
| reliability | 9.80 | 0.25 | 2.45 | 2/2 |
| architecture | 9.80 | 0.20 | 1.96 | 2/2 |
| capability | 9.80 | 0.20 | 1.96 | 3/3 |
| safety | 9.80 | 0.15 | 1.47 | 4/4 |
| ux | 9.80 | 0.10 | 0.98 | 2/2 |
| performance | 9.80 | 0.10 | 0.98 | 2/2 |

## Evidence Checks

### reliability

- `REL-01` PASS (2515 ms): Golden runtime scenarios
  Command: `/Users/prabhat/Library/CloudStorage/GoogleDrive-888prabhat@gmail.com/My Drive/Work/citnega/.venv/bin/python -m pytest tests/integration/test_golden_scenarios.py -q`
- `REL-02` PASS (1708 ms): Core runtime state/stream correctness
  Command: `/Users/prabhat/Library/CloudStorage/GoogleDrive-888prabhat@gmail.com/My Drive/Work/citnega/.venv/bin/python -m pytest tests/integration/runtime/test_core_runtime.py -q`

### architecture

- `ARC-01` PASS (1377 ms): Section 10 integration event/config behavior
  Command: `/Users/prabhat/Library/CloudStorage/GoogleDrive-888prabhat@gmail.com/My Drive/Work/citnega/.venv/bin/python -m pytest tests/integration/test_section10_integration.py -q`
- `ARC-02` PASS (501 ms): Protocol event model contracts
  Command: `/Users/prabhat/Library/CloudStorage/GoogleDrive-888prabhat@gmail.com/My Drive/Work/citnega/.venv/bin/python -m pytest tests/unit/protocol/test_section10_events.py -q`

### capability

- `CAP-01` PASS (677 ms): Multi-tool orchestration golden flows
  Command: `/Users/prabhat/Library/CloudStorage/GoogleDrive-888prabhat@gmail.com/My Drive/Work/citnega/.venv/bin/python -m pytest tests/integration/test_orchestrator_golden.py -q`
- `CAP-02` PASS (647 ms): P2 security/release capability workflow
  Command: `/Users/prabhat/Library/CloudStorage/GoogleDrive-888prabhat@gmail.com/My Drive/Work/citnega/.venv/bin/python -m pytest tests/integration/test_p2_capabilities.py -q`
- `CAP-03` PASS (512 ms): Workspace onboarding flow with provenance/signature gates
  Command: `/Users/prabhat/Library/CloudStorage/GoogleDrive-888prabhat@gmail.com/My Drive/Work/citnega/.venv/bin/python -m pytest tests/integration/workspace/test_onboarding_gate.py -q`

### safety

- `SAFE-01` PASS (702 ms): Runtime policy enforcement tests
  Command: `/Users/prabhat/Library/CloudStorage/GoogleDrive-888prabhat@gmail.com/My Drive/Work/citnega/.venv/bin/python -m pytest tests/unit/runtime/test_policy.py -q`
- `SAFE-02` PASS (2044 ms): Signed run envelope and remote verification
  Command: `/Users/prabhat/Library/CloudStorage/GoogleDrive-888prabhat@gmail.com/My Drive/Work/citnega/.venv/bin/python -m pytest tests/unit/runtime/test_remote_execution.py -q`
- `SAFE-04` PASS (2558 ms): Reference remote worker service allowlist and HTTP roundtrip
  Command: `/Users/prabhat/Library/CloudStorage/GoogleDrive-888prabhat@gmail.com/My Drive/Work/citnega/.venv/bin/python -m pytest tests/unit/runtime/test_remote_service.py -q`
- `SAFE-03` PASS (506 ms): Workspace onboarding manifest/signature validation
  Command: `/Users/prabhat/Library/CloudStorage/GoogleDrive-888prabhat@gmail.com/My Drive/Work/citnega/.venv/bin/python -m pytest tests/unit/workspace/test_onboarding.py -q`

### ux

- `UX-01` PASS (884 ms): CLI integration flows
  Command: `/Users/prabhat/Library/CloudStorage/GoogleDrive-888prabhat@gmail.com/My Drive/Work/citnega/.venv/bin/python -m pytest tests/integration/cli/test_cli.py -q`
- `UX-02` PASS (539 ms): TUI slash command behavior
  Command: `/Users/prabhat/Library/CloudStorage/GoogleDrive-888prabhat@gmail.com/My Drive/Work/citnega/.venv/bin/python -m pytest tests/unit/tui/test_slash_session.py -q`

### performance

- `PERF-01` PASS (1627 ms): Repo/test-matrix cache hit paths
  Command: `/Users/prabhat/Library/CloudStorage/GoogleDrive-888prabhat@gmail.com/My Drive/Work/citnega/.venv/bin/python -m pytest tests/unit/tools/test_p1_tools.py -q`
- `PERF-02` PASS (574 ms): Security-agent cache hit path
  Command: `/Users/prabhat/Library/CloudStorage/GoogleDrive-888prabhat@gmail.com/My Drive/Work/citnega/.venv/bin/python -m pytest tests/unit/agents/test_p2_agents.py::test_security_agent_uses_cache_on_second_static_scan -q`
