# Colab self-contained benchmark with heavy Triton autotune:
#
# old = phase2 backward kernel + separate query-gradient reduction kernel
# new = phase2 backward kernel with fused tiled query-gradient reduction
#
# Runtime -> Change runtime type -> GPU

import sys
import subprocess
from dataclasses import dataclass
import os

os.environ["TRITON_PRINT_AUTOTUNING"] = "1"

import torch

try:
    import triton
    import triton.language as tl
except ModuleNotFoundError:
    subprocess.check_call([sys.executable, "-m", "pip", "install", "-q", "triton"])
    import triton
    import triton.language as tl


# ============================================================
# Config: edit these in Colab
# ============================================================

B = 128
T = 2048 * 4
D = 1024

# T4: use torch.float16.
# A100/L4/H100: try torch.bfloat16 too.
DTYPE = torch.float16

# Use fp32 here for cleaner benchmarking.
# You can try torch.bfloat16 to mirror your memory-saving path.
ACCUM_DTYPE = torch.float32

WARMUP = 25
ITERS = 200

SCALE = 0.5
EPS = torch.finfo(torch.float32).eps
SEED = 0

ATOL = 1e-2
RTOL = 1e-2

RUN_CORRECTNESS = True

# Important:
# First execution includes Triton autotuning/compilation.
# The timed section below uses the selected configs after autotune.


# ============================================================
# Sanity checks
# ============================================================

assert torch.cuda.is_available(), "Colab runtime must have CUDA GPU enabled."
torch.cuda.set_device(0)

def is_power_of_two(x):
    return x > 0 and (x & (x - 1)) == 0

assert is_power_of_two(D), "This benchmark expects D to be a power of two."

BT = B * T

print("GPU:", torch.cuda.get_device_name(0))
print("Torch:", torch.__version__)
print("CUDA:", torch.version.cuda)
print("Triton:", triton.__version__)
print(f"Shape: B={B}, T={T}, BT={BT}, D={D}, dtype={DTYPE}, accum_dtype={ACCUM_DTYPE}")


# ============================================================
# Heavy autotune config lists
# ============================================================

OLD_PHASE2_BWD_CONFIGS = [
    triton.Config({}, num_warps=1, num_stages=1),
    triton.Config({}, num_warps=2, num_stages=1),
    triton.Config({}, num_warps=4, num_stages=1),
    triton.Config({}, num_warps=8, num_stages=1),

    triton.Config({}, num_warps=1, num_stages=2),
    triton.Config({}, num_warps=2, num_stages=2),
    triton.Config({}, num_warps=4, num_stages=2),
    triton.Config({}, num_warps=8, num_stages=2),
]

REDUCE_QUERY_GRAD_CONFIGS = [
    triton.Config({"BLOCK_BATCH_SEQ": 64,  "BLOCK_HIDDEN": 32},  num_warps=4, num_stages=1),
    triton.Config({"BLOCK_BATCH_SEQ": 64,  "BLOCK_HIDDEN": 64},  num_warps=4, num_stages=1),
    triton.Config({"BLOCK_BATCH_SEQ": 64,  "BLOCK_HIDDEN": 128}, num_warps=4, num_stages=1),

    triton.Config({"BLOCK_BATCH_SEQ": 128, "BLOCK_HIDDEN": 32},  num_warps=4, num_stages=1),
    triton.Config({"BLOCK_BATCH_SEQ": 128, "BLOCK_HIDDEN": 64},  num_warps=4, num_stages=1),
    triton.Config({"BLOCK_BATCH_SEQ": 128, "BLOCK_HIDDEN": 128}, num_warps=4, num_stages=1),

    triton.Config({"BLOCK_BATCH_SEQ": 256, "BLOCK_HIDDEN": 32},  num_warps=4, num_stages=1),
    triton.Config({"BLOCK_BATCH_SEQ": 256, "BLOCK_HIDDEN": 64},  num_warps=4, num_stages=1),
    triton.Config({"BLOCK_BATCH_SEQ": 256, "BLOCK_HIDDEN": 128}, num_warps=4, num_stages=1),

    triton.Config({"BLOCK_BATCH_SEQ": 512, "BLOCK_HIDDEN": 32},  num_warps=4, num_stages=1),
    triton.Config({"BLOCK_BATCH_SEQ": 512, "BLOCK_HIDDEN": 64},  num_warps=4, num_stages=1),
    triton.Config({"BLOCK_BATCH_SEQ": 512, "BLOCK_HIDDEN": 128}, num_warps=4, num_stages=1),

    triton.Config({"BLOCK_BATCH_SEQ": 64,  "BLOCK_HIDDEN": 32},  num_warps=8, num_stages=1),
    triton.Config({"BLOCK_BATCH_SEQ": 64,  "BLOCK_HIDDEN": 64},  num_warps=8, num_stages=1),
    triton.Config({"BLOCK_BATCH_SEQ": 64,  "BLOCK_HIDDEN": 128}, num_warps=8, num_stages=1),

    triton.Config({"BLOCK_BATCH_SEQ": 128, "BLOCK_HIDDEN": 32},  num_warps=8, num_stages=1),
    triton.Config({"BLOCK_BATCH_SEQ": 128, "BLOCK_HIDDEN": 64},  num_warps=8, num_stages=1),
    triton.Config({"BLOCK_BATCH_SEQ": 128, "BLOCK_HIDDEN": 128}, num_warps=8, num_stages=1),

    triton.Config({"BLOCK_BATCH_SEQ": 256, "BLOCK_HIDDEN": 32},  num_warps=8, num_stages=1),
    triton.Config({"BLOCK_BATCH_SEQ": 256, "BLOCK_HIDDEN": 64},  num_warps=8, num_stages=1),
    triton.Config({"BLOCK_BATCH_SEQ": 256, "BLOCK_HIDDEN": 128}, num_warps=8, num_stages=1),

    triton.Config({"BLOCK_BATCH_SEQ": 512, "BLOCK_HIDDEN": 32},  num_warps=8, num_stages=1),
    triton.Config({"BLOCK_BATCH_SEQ": 512, "BLOCK_HIDDEN": 64},  num_warps=8, num_stages=1),
    triton.Config({"BLOCK_BATCH_SEQ": 512, "BLOCK_HIDDEN": 128}, num_warps=8, num_stages=1),
]

FUSED_PHASE2_BWD_CONFIGS = [
    triton.Config({"BLOCK_BT": 1},  num_warps=1, num_stages=1),
    triton.Config({"BLOCK_BT": 1},  num_warps=2, num_stages=1),
    triton.Config({"BLOCK_BT": 1},  num_warps=4, num_stages=1),
    triton.Config({"BLOCK_BT": 1},  num_warps=8, num_stages=1),

    triton.Config({"BLOCK_BT": 2},  num_warps=1, num_stages=1),
    triton.Config({"BLOCK_BT": 2},  num_warps=2, num_stages=1),
    triton.Config({"BLOCK_BT": 2},  num_warps=4, num_stages=1),
    triton.Config({"BLOCK_BT": 2},  num_warps=8, num_stages=1),

    triton.Config({"BLOCK_BT": 4},  num_warps=1, num_stages=1),
    triton.Config({"BLOCK_BT": 4},  num_warps=2, num_stages=1),
    triton.Config({"BLOCK_BT": 4},  num_warps=4, num_stages=1),
    triton.Config({"BLOCK_BT": 4},  num_warps=8, num_stages=1),

    triton.Config({"BLOCK_BT": 8},  num_warps=1, num_stages=1),
    triton.Config({"BLOCK_BT": 8},  num_warps=2, num_stages=1),
    triton.Config({"BLOCK_BT": 8},  num_warps=4, num_stages=1),
    triton.Config({"BLOCK_BT": 8},  num_warps=8, num_stages=1),

    # A little heavier. These may or may not win depending on D/GPU.
    triton.Config({"BLOCK_BT": 16}, num_warps=4, num_stages=1),
    triton.Config({"BLOCK_BT": 16}, num_warps=8, num_stages=1),

    # Repeat with num_stages=2.
    triton.Config({"BLOCK_BT": 1},  num_warps=1, num_stages=2),
    triton.Config({"BLOCK_BT": 1},  num_warps=2, num_stages=2),
    triton.Config({"BLOCK_BT": 1},  num_warps=4, num_stages=2),
    triton.Config({"BLOCK_BT": 1},  num_warps=8, num_stages=2),

    triton.Config({"BLOCK_BT": 2},  num_warps=1, num_stages=2),
    triton.Config({"BLOCK_BT": 2},  num_warps=2, num_stages=2),
    triton.Config({"BLOCK_BT": 2},  num_warps=4, num_stages=2),
    triton.Config({"BLOCK_BT": 2},  num_warps=8, num_stages=2),

    triton.Config({"BLOCK_BT": 4},  num_warps=1, num_stages=2),
    triton.Config({"BLOCK_BT": 4},  num_warps=2, num_stages=2),
    triton.Config({"BLOCK_BT": 4},  num_warps=4, num_stages=2),
    triton.Config({"BLOCK_BT": 4},  num_warps=8, num_stages=2),

    triton.Config({"BLOCK_BT": 8},  num_warps=1, num_stages=2),
    triton.Config({"BLOCK_BT": 8},  num_warps=2, num_stages=2),
    triton.Config({"BLOCK_BT": 8},  num_warps=4, num_stages=2),
    triton.Config({"BLOCK_BT": 8},  num_warps=8, num_stages=2),

    triton.Config({"BLOCK_BT": 16}, num_warps=4, num_stages=2),
    triton.Config({"BLOCK_BT": 16}, num_warps=8, num_stages=2),

    triton.Config({"BLOCK_BT": 16}, num_warps=4, num_stages=2),
    triton.Config({"BLOCK_BT": 16}, num_warps=8, num_stages=2),

    triton.Config({"BLOCK_BT": 32}, num_warps=4, num_stages=2),
    triton.Config({"BLOCK_BT": 32}, num_warps=8, num_stages=2),


    triton.Config({"BLOCK_BT": 64}, num_warps=4, num_stages=2),
    triton.Config({"BLOCK_BT": 64}, num_warps=8, num_stages=2),

    triton.Config({"BLOCK_BT": 128}, num_warps=4, num_stages=2),
    triton.Config({"BLOCK_BT": 128}, num_warps=8, num_stages=2),
]


# ============================================================
# Kernels
# ============================================================

@triton.autotune(
    configs=OLD_PHASE2_BWD_CONFIGS,
    key=["HIDDEN_DIM"],
    restore_value=[
        "grad_intrablock_partial_sum_accumulator_ptr",
    ],
)
@triton.jit
def phase2_bwd_old_kernel(
    intrablock_partial_sum_ptr,
    pseudo_query_ptr,
    phase1_interblock_normalized_output_ptr,
    phase1_interblock_logsumexp_ptr,
    grad_merged_attention_output_ptr,
    grad_intrablock_partial_sum_accumulator_ptr,
    grad_pseudo_query_partial_ptr,
    grad_phase1_interblock_normalized_output_ptr,
    grad_phase1_interblock_logsumexp_ptr,
    eps,
    HIDDEN_DIM: tl.constexpr,
):
    batch_seq_idx = tl.program_id(0)
    hidden_dim_range = tl.arange(0, HIDDEN_DIM)

    row_offsets = batch_seq_idx * HIDDEN_DIM + hidden_dim_range

    intrablock_partial_sum = tl.load(
        intrablock_partial_sum_ptr + row_offsets
    ).to(tl.float32)

    pseudo_query = tl.load(
        pseudo_query_ptr + hidden_dim_range,
        eviction_policy="evict_last",
    ).to(tl.float32)

    phase1_interblock_normalized_output = tl.load(
        phase1_interblock_normalized_output_ptr + row_offsets
    ).to(tl.float32)

    phase1_interblock_logsumexp = tl.load(
        phase1_interblock_logsumexp_ptr + batch_seq_idx
    ).to(tl.float32)

    grad_merged_attention_output = tl.load(
        grad_merged_attention_output_ptr + row_offsets
    ).to(tl.float32)

    norm2 = tl.sum(intrablock_partial_sum * intrablock_partial_sum)
    inv_rms = tl.rsqrt(norm2 / float(HIDDEN_DIM) + eps)

    q_dot_x = tl.sum(intrablock_partial_sum * pseudo_query)
    intrablock_logit = q_dot_x * inv_rms

    shift = tl.maximum(phase1_interblock_logsumexp, intrablock_logit)
    w1 = tl.exp(phase1_interblock_logsumexp - shift)
    w2 = tl.exp(intrablock_logit - shift)
    denom = w1 + w2

    p1 = w1 / denom
    p2 = w2 / denom

    grad_phase1_interblock_normalized_output = p1 * grad_merged_attention_output
    grad_intrablock_from_value = p2 * grad_merged_attention_output

    grad_dot = tl.sum(
        grad_merged_attention_output
        * (phase1_interblock_normalized_output - intrablock_partial_sum)
    )

    pp = p1 * p2

    grad_phase1_interblock_logsumexp = pp * grad_dot
    grad_intrablock_logit = -pp * grad_dot

    inv_rms3 = inv_rms * inv_rms * inv_rms

    grad_intrablock_from_logit = grad_intrablock_logit * (
        inv_rms * pseudo_query
        - q_dot_x * inv_rms3 * intrablock_partial_sum / float(HIDDEN_DIM)
    )

    grad_pseudo_query = grad_intrablock_logit * inv_rms * intrablock_partial_sum
    grad_intrablock = grad_intrablock_from_value + grad_intrablock_from_logit

    grad_intrablock_ptr = grad_intrablock_partial_sum_accumulator_ptr + row_offsets

    tl.store(
        grad_intrablock_ptr,
        tl.load(grad_intrablock_ptr).to(tl.float32) + grad_intrablock,
    )

    tl.store(
        grad_pseudo_query_partial_ptr + row_offsets,
        grad_pseudo_query,
    )

    tl.store(
        grad_phase1_interblock_normalized_output_ptr + row_offsets,
        grad_phase1_interblock_normalized_output,
    )

    tl.store(
        grad_phase1_interblock_logsumexp_ptr + batch_seq_idx,
        grad_phase1_interblock_logsumexp,
    )


@triton.autotune(
    configs=REDUCE_QUERY_GRAD_CONFIGS,
    key=["BT", "HIDDEN_DIM"],
    restore_value=[
        "grad_accumulator_ptr",
    ],
)
@triton.jit
def reduce_query_grad_old_kernel(
    grad_partial_ptr,
    grad_accumulator_ptr,
    BT: tl.constexpr,
    HIDDEN_DIM: tl.constexpr,
    BLOCK_BATCH_SEQ: tl.constexpr,
    BLOCK_HIDDEN: tl.constexpr,
):
    batch_seq_block_idx = tl.program_id(0)
    hidden_block_idx = tl.program_id(1)

    batch_offsets = batch_seq_block_idx * BLOCK_BATCH_SEQ + tl.arange(0, BLOCK_BATCH_SEQ)
    hidden_offsets = hidden_block_idx * BLOCK_HIDDEN + tl.arange(0, BLOCK_HIDDEN)

    mask = (
        (batch_offsets[:, None] < BT)
        & (hidden_offsets[None, :] < HIDDEN_DIM)
    )

    grad_tile = tl.load(
        grad_partial_ptr
        + batch_offsets[:, None] * HIDDEN_DIM
        + hidden_offsets[None, :],
        mask=mask,
        other=0.0,
    ).to(tl.float32)

    grad_reduced = tl.sum(grad_tile, axis=0)

    tl.atomic_add(
        grad_accumulator_ptr + hidden_offsets,
        grad_reduced,
        mask=hidden_offsets < HIDDEN_DIM,
        sem="relaxed",
    )


@triton.autotune(
    configs=FUSED_PHASE2_BWD_CONFIGS,
    key=["BT", "HIDDEN_DIM"],
    restore_value=[
        "grad_intrablock_partial_sum_accumulator_ptr",
        "grad_pseudo_query_accumulator_ptr",
    ],
)
@triton.jit
def phase2_bwd_fused_query_grad_kernel(
    intrablock_partial_sum_ptr,
    pseudo_query_ptr,
    phase1_interblock_normalized_output_ptr,
    phase1_interblock_logsumexp_ptr,
    grad_merged_attention_output_ptr,
    grad_intrablock_partial_sum_accumulator_ptr,
    grad_pseudo_query_accumulator_ptr,
    grad_phase1_interblock_normalized_output_ptr,
    grad_phase1_interblock_logsumexp_ptr,
    eps,
    BT: tl.constexpr,
    HIDDEN_DIM: tl.constexpr,
    BLOCK_BT: tl.constexpr,
):
    bt_block_idx = tl.program_id(0)

    bt_offsets = bt_block_idx * BLOCK_BT + tl.arange(0, BLOCK_BT)
    hidden_offsets = tl.arange(0, HIDDEN_DIM)

    valid_bt = bt_offsets < BT
    mask_2d = valid_bt[:, None]

    offsets_2d = bt_offsets[:, None] * HIDDEN_DIM + hidden_offsets[None, :]

    intrablock_partial_sum = tl.load(
        intrablock_partial_sum_ptr + offsets_2d,
        mask=mask_2d,
        other=0.0,
    ).to(tl.float32)

    pseudo_query = tl.load(
        pseudo_query_ptr + hidden_offsets,
        eviction_policy="evict_last",
    ).to(tl.float32)

    phase1_interblock_normalized_output = tl.load(
        phase1_interblock_normalized_output_ptr + offsets_2d,
        mask=mask_2d,
        other=0.0,
    ).to(tl.float32)

    phase1_interblock_logsumexp = tl.load(
        phase1_interblock_logsumexp_ptr + bt_offsets,
        mask=valid_bt,
        other=float("-inf"),
    ).to(tl.float32)

    grad_merged_attention_output = tl.load(
        grad_merged_attention_output_ptr + offsets_2d,
        mask=mask_2d,
        other=0.0,
    ).to(tl.float32)

    norm2 = tl.sum(intrablock_partial_sum * intrablock_partial_sum, axis=1)
    inv_rms = tl.rsqrt(norm2 / float(HIDDEN_DIM) + eps)

    q_dot_x = tl.sum(intrablock_partial_sum * pseudo_query[None, :], axis=1)
    intrablock_logit = q_dot_x * inv_rms

    shift = tl.maximum(phase1_interblock_logsumexp, intrablock_logit)

    w1 = tl.exp(phase1_interblock_logsumexp - shift)
    w2 = tl.exp(intrablock_logit - shift)
    denom = w1 + w2

    p1 = w1 / denom
    p2 = w2 / denom

    grad_phase1_interblock_normalized_output = (
        p1[:, None] * grad_merged_attention_output
    )

    grad_intrablock_from_value = p2[:, None] * grad_merged_attention_output

    grad_dot = tl.sum(
        grad_merged_attention_output
        * (phase1_interblock_normalized_output - intrablock_partial_sum),
        axis=1,
    )

    pp = p1 * p2

    grad_phase1_interblock_logsumexp = pp * grad_dot
    grad_intrablock_logit = -pp * grad_dot

    inv_rms3 = inv_rms * inv_rms * inv_rms

    grad_intrablock_from_logit = grad_intrablock_logit[:, None] * (
        inv_rms[:, None] * pseudo_query[None, :]
        - q_dot_x[:, None]
        * inv_rms3[:, None]
        * intrablock_partial_sum
        / float(HIDDEN_DIM)
    )

    grad_pseudo_query_per_row = (
        grad_intrablock_logit[:, None]
        * inv_rms[:, None]
        * intrablock_partial_sum
    )

    grad_pseudo_query_tile = tl.sum(
        tl.where(mask_2d, grad_pseudo_query_per_row, 0.0),
        axis=0,
    )

    grad_intrablock = grad_intrablock_from_value + grad_intrablock_from_logit

    grad_intrablock_ptr = grad_intrablock_partial_sum_accumulator_ptr + offsets_2d

    prev_grad_intrablock = tl.load(
        grad_intrablock_ptr,
        mask=mask_2d,
        other=0.0,
    ).to(tl.float32)

    tl.store(
        grad_intrablock_ptr,
        prev_grad_intrablock + grad_intrablock,
        mask=mask_2d,
    )

    tl.store(
        grad_phase1_interblock_normalized_output_ptr + offsets_2d,
        grad_phase1_interblock_normalized_output,
        mask=mask_2d,
    )

    tl.store(
        grad_phase1_interblock_logsumexp_ptr + bt_offsets,
        grad_phase1_interblock_logsumexp,
        mask=valid_bt,
    )

    tl.atomic_add(
        grad_pseudo_query_accumulator_ptr + hidden_offsets,
        grad_pseudo_query_tile,
        sem="relaxed",
    )


# ============================================================
# Helpers
# ============================================================

@dataclass
class Inputs:
    intrablock_partial_sum: torch.Tensor
    pseudo_query: torch.Tensor
    phase1_interblock_normalized_output: torch.Tensor
    phase1_interblock_logsumexp: torch.Tensor
    grad_merged_attention_output: torch.Tensor


@dataclass
class Outputs:
    grad_intrablock_partial_sum: torch.Tensor
    grad_pseudo_query: torch.Tensor
    grad_phase1_interblock_normalized_output: torch.Tensor
    grad_phase1_interblock_logsumexp: torch.Tensor
    grad_pseudo_query_partial: torch.Tensor | None = None


def randn(shape, dtype, scale=SCALE):
    return (
        torch.randn(shape, device="cuda", dtype=torch.float32) * scale
    ).to(dtype).contiguous()


def make_inputs():
    torch.manual_seed(SEED)
    torch.cuda.manual_seed_all(SEED)

    return Inputs(
        intrablock_partial_sum=randn((BT, D), DTYPE),
        pseudo_query=randn((D,), DTYPE),
        phase1_interblock_normalized_output=randn((BT, D), DTYPE),
        phase1_interblock_logsumexp=torch.randn(
            BT, device="cuda", dtype=torch.float32
        ).contiguous(),
        grad_merged_attention_output=randn((BT, D), torch.float32),
    )


def alloc_outputs(need_partial):
    return Outputs(
        grad_intrablock_partial_sum=torch.zeros(
            (BT, D), device="cuda", dtype=ACCUM_DTYPE
        ),
        grad_pseudo_query=torch.zeros(
            (D,), device="cuda", dtype=torch.float32
        ),
        grad_phase1_interblock_normalized_output=torch.empty(
            (BT, D), device="cuda", dtype=torch.float32
        ),
        grad_phase1_interblock_logsumexp=torch.empty(
            (BT,), device="cuda", dtype=torch.float32
        ),
        grad_pseudo_query_partial=(
            torch.empty((BT, D), device="cuda", dtype=torch.float32)
            if need_partial
            else None
        ),
    )


def zero_accumulators(out):
    out.grad_intrablock_partial_sum.zero_()
    out.grad_pseudo_query.zero_()


def launch_old(x, out):
    phase2_bwd_old_kernel[(BT,)](
        x.intrablock_partial_sum,
        x.pseudo_query,
        x.phase1_interblock_normalized_output,
        x.phase1_interblock_logsumexp,
        x.grad_merged_attention_output,
        out.grad_intrablock_partial_sum,
        out.grad_pseudo_query_partial,
        out.grad_phase1_interblock_normalized_output,
        out.grad_phase1_interblock_logsumexp,
        EPS,
        HIDDEN_DIM=D,
    )

    grid_reduce = lambda META: (
        triton.cdiv(BT, META["BLOCK_BATCH_SEQ"]),
        triton.cdiv(D, META["BLOCK_HIDDEN"]),
    )

    reduce_query_grad_old_kernel[grid_reduce](
        out.grad_pseudo_query_partial,
        out.grad_pseudo_query,
        BT=BT,
        HIDDEN_DIM=D,
    )


def launch_new(x, out):
    grid = lambda META: (
        triton.cdiv(BT, META["BLOCK_BT"]),
    )

    phase2_bwd_fused_query_grad_kernel[grid](
        x.intrablock_partial_sum,
        x.pseudo_query,
        x.phase1_interblock_normalized_output,
        x.phase1_interblock_logsumexp,
        x.grad_merged_attention_output,
        out.grad_intrablock_partial_sum,
        out.grad_pseudo_query,
        out.grad_phase1_interblock_normalized_output,
        out.grad_phase1_interblock_logsumexp,
        EPS,
        BT=BT,
        HIDDEN_DIM=D,
    )


def max_abs_rel(a, b):
    af = a.float()
    bf = b.float()
    diff = (af - bf).abs()
    return diff.max().item(), (diff / bf.abs().clamp_min(1e-6)).max().item()


def compare_outputs(old, new):
    checks = [
        (
            "grad_intrablock_partial_sum",
            old.grad_intrablock_partial_sum,
            new.grad_intrablock_partial_sum,
        ),
        (
            "grad_pseudo_query",
            old.grad_pseudo_query,
            new.grad_pseudo_query,
        ),
        (
            "grad_phase1_interblock_normalized_output",
            old.grad_phase1_interblock_normalized_output,
            new.grad_phase1_interblock_normalized_output,
        ),
        (
            "grad_phase1_interblock_logsumexp",
            old.grad_phase1_interblock_logsumexp,
            new.grad_phase1_interblock_logsumexp,
        ),
    ]

    print("\nCorrectness vs old")
    all_ok = True

    for name, a, b in checks:
        max_abs, max_rel = max_abs_rel(a, b)
        ok = torch.allclose(a.float(), b.float(), atol=ATOL, rtol=RTOL)
        all_ok = all_ok and ok
        print(
            f"  {name:45s} ok={str(ok):5s} "
            f"max_abs={max_abs:.6g} max_rel={max_rel:.6g}"
        )

    return all_ok


def bench_ms(fn, warmup=WARMUP, iters=ITERS):
    fn()
    torch.cuda.synchronize()

    for _ in range(warmup):
        fn()
    torch.cuda.synchronize()

    start = torch.cuda.Event(enable_timing=True)
    end = torch.cuda.Event(enable_timing=True)

    start.record()
    for _ in range(iters):
        fn()
    end.record()

    torch.cuda.synchronize()
    return start.elapsed_time(end) / iters


# ============================================================
# Run
# ============================================================

x = make_inputs()

# Force autotune and compile once before correctness/timing.
print("\nCompiling/autotuning old path...")
old_compile = alloc_outputs(need_partial=True)
zero_accumulators(old_compile)
launch_old(x, old_compile)
torch.cuda.synchronize()

print("Compiling/autotuning new path...")
new_compile = alloc_outputs(need_partial=False)
zero_accumulators(new_compile)
launch_new(x, new_compile)
torch.cuda.synchronize()

if RUN_CORRECTNESS:
    old_check = alloc_outputs(need_partial=True)
    zero_accumulators(old_check)
    launch_old(x, old_check)
    torch.cuda.synchronize()

    new_check = alloc_outputs(need_partial=False)
    zero_accumulators(new_check)
    launch_new(x, new_check)
    torch.cuda.synchronize()

    ok = compare_outputs(old_check, new_check)
    if not ok:
        print(
            "\nWARNING: correctness check failed. "
            "This can be reduction-order noise for grad_pseudo_query, "
            "but inspect before trusting timings."
        )

old_bench = alloc_outputs(need_partial=True)
zero_accumulators(old_bench)

new_bench = alloc_outputs(need_partial=False)
zero_accumulators(new_bench)

old_ms = bench_ms(lambda: launch_old(x, old_bench))
new_ms = bench_ms(lambda: launch_new(x, new_bench))

print("\nBenchmark")
print(f"  old phase2_bwd + reduce: {old_ms:.4f} ms")
print(f"  new fused autotuned:      {new_ms:.4f} ms")
print(f"  speedup:                  {old_ms / new_ms:.3f}x")

print("\nAutotune cache selected configs internally.")
print("Try changing B/T/D/DTYPE at the top and rerun the cell.")