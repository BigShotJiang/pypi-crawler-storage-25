# IDM Downloader

一个用于调用 Internet Download Manager (IDM) 进行文件下载的 Python 库，支持进度监控和回调。

## 特性

- ✅ 简单易用的 API
- ✅ 实时下载进度监控
- ✅ 支持进度回调
- ✅ 支持暂停/恢复/停止下载
- ✅ 自动检测 IDM 安装路径
- ✅ 解析 IDM 日志获取详细进度信息
- ⚠️ 仅支持 Windows 系统

## 安装

```bash
pip install idm-downloader
```

## 快速开始

### 最简单的使用方式

```python
from idm_downloader import simple_download

result = simple_download(
    url="https://example.com/file.mp4",
    save_path="C:\\Downloads"
)

print(f"下载{'成功' if result else '失败'}")
```

### 使用 IDMDownloader 类（支持回调）

```python
from idm_downloader import IDMDownloader

def progress_callback(progress_info):
    """进度回调函数"""
    print(f"进度: {progress_info['percent']}%")
    print(f"已下载: {progress_info['formatted_downloaded']}")
    print(f"速度: {progress_info['speed']}")
    print(f"剩余时间: {progress_info['remaining_time']}")
    print(f"状态: {progress_info['status']}")
    print("-" * 30)

def status_callback(msg, level):
    """状态回调函数"""
    print(f"[{level.upper()}] {msg}")

# 创建下载器实例
downloader = IDMDownloader(
    progress_callback=progress_callback,
    status_callback=status_callback,
)

# 开始下载
result = downloader.download(
    url="https://example.com/file.zip",
    save_path="C:\\Downloads",
    filename="myfile.zip",  # 可选，指定文件名
    timeout=3600,  # 超时时间，默认3600秒
)

print(f"下载{'成功' if result else '失败'}")
```

### 控制下载

```python
downloader = IDMDownloader()

# 开始下载
result = downloader.download(url, save_path)

# 暂停下载
downloader.pause()

# 恢复下载
downloader.resume()

# 停止下载
downloader.stop()
```

### 命令行使用

```bash
idm-download https://example.com/file.mp4 C:\Downloads
```

## 进度信息字典

`progress_callback` 函数接收的 `progress_info` 字典包含以下信息：

```python
{
    "percent": 50.5,              # 下载百分比
    "downloaded": 102400,         # 已下载字节数
    "total": 204800,              # 总字节数
    "speed": "100 KB/s",          # 下载速度
    "status": "downloading",      # 状态 (downloading/completed/error/rebuilding)
    "remaining_time": "2分钟30秒",# 剩余时间
    "formatted_downloaded": "100 KB",  # 格式化后的已下载大小
    "formatted_total": "200 KB",        # 格式化后的总大小
    "formatted_size": "100 KB / 200 KB" # 格式化的大小显示
}
```

## 独立使用

你也可以在其他项目中直接复制和使用 `idm_downloader.py` 文件，无需安装包。

## 前置要求

- Windows 操作系统
- Internet Download Manager (IDM) 已安装

## 本地安装和开发

```bash
# 克隆代码
git clone https://github.com/yourusername/idm-downloader.git
cd idm-downloader

# 安装依赖和开发工具
pip install -e .[dev]

# 本地安装（开发模式）
pip install -e .
```

## 发布到 PyPI

如果你想将这个包发布到 PyPI，需要：

1. 注册 PyPI 账号：https://pypi.org/account/register/
2. 安装构建工具：
   ```bash
   pip install build twine
   ```
3. 构建包：
   ```bash
   python -m build
   ```
4. 上传到 PyPI：
   ```bash
   twine upload dist/*
   ```

## 许可证

MIT License. 详见 LICENSE 文件。

## 贡献

欢迎提交 Issue 和 Pull Request！
