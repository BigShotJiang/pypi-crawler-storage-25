"""
IDM (Internet Download Manager) 下载库

提供独立的IDM下载功能，可被其他项目直接引用。
只需传入下载地址和文件保存路径即可使用。

Usage:
    from idm_downloader import IDMDownloader

    downloader = IDMDownloader()
    result = downloader.download(url, save_path)
"""

import os
import re
import subprocess
import time
import traceback
from pathlib import Path
from typing import Optional, Dict, Any, Callable, List
from urllib.parse import urlparse


class IDMDownloader:
    """
    IDM下载器类

    提供使用IDM进行下载的功能，支持进度回调和下载状态监控。
    """

    def __init__(
        self,
        progress_callback: Optional[Callable[[Dict[str, Any]], None]] = None,
        status_callback: Optional[Callable[[str, str], None]] = None,
    ):
        """
        初始化IDM下载器

        Args:
            progress_callback: 进度回调函数，接收包含进度信息的字典
            status_callback: 状态回调函数，接收(消息, 级别)元组
        """
        self.progress_callback = progress_callback
        self.status_callback = status_callback
        self._stop_flag = False
        self._paused_flag = False

    def _log(self, msg: str, level: str = "info"):
        """记录日志"""
        if self.status_callback:
            self.status_callback(msg, level)
        else:
            print(f"[{level.upper()}] {msg}")

    def _emit_progress(self, progress_info: Dict[str, Any]):
        """发送进度信息"""
        if self.progress_callback:
            self.progress_callback(progress_info)

    def check_idm(self) -> Optional[str]:
        """
        检查IDM（Internet Download Manager）是否可用

        Returns:
            IDM可执行文件路径，如果不可用返回None
        """
        try:
            import winreg

            idm_reg_paths = [
                r"SOFTWARE\Internet Download Manager",
                r"SOFTWARE\WOW6432Node\Internet Download Manager"
            ]

            for reg_path in idm_reg_paths:
                try:
                    with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, reg_path) as key:
                        install_path, _ = winreg.QueryValueEx(key, "InstallPath")
                        idm_exe = os.path.join(install_path, "IDMan.exe")
                        if os.path.exists(idm_exe):
                            return idm_exe
                except (WindowsError, FileNotFoundError):
                    continue

            common_paths = [
                r"C:\Program Files (x86)\Internet Download Manager\IDMan.exe",
                r"C:\Program Files\Internet Download Manager\IDMan.exe"
            ]
            for path in common_paths:
                if os.path.exists(path):
                    return path
            return None
        except Exception as e:
            self._log(f"检测IDM时发生异常: {str(e)}", "warning")
            return None

    def get_log_path(self, url: str, filename: str) -> Optional[Path]:
        """
        根据URL和文件名查找IDM日志文件路径

        Args:
            url: 下载URL
            filename: 文件名

        Returns:
            日志文件路径，如果找不到返回None
        """
        try:
            import getpass
            username = getpass.getuser()

            base_log_path = Path(os.environ.get("APPDATA", "")) / "IDM" / "DwnlData" / username

            if not base_log_path.exists():
                return None

            parsed_url = urlparse(url)
            hostname = parsed_url.netloc
            hostname_underscore = hostname.replace(".", "_")

            has_params = '?' in url or '&' in url

            file_path = Path(filename)
            file_stem = file_path.stem

            log_dirs = []
            for item in base_log_path.iterdir():
                if item.is_dir():
                    log_dirs.append(item)

            log_dirs.sort(key=lambda x: x.stat().st_mtime, reverse=True)

            if has_params:
                for prefix_len in [10, 15, 20, 25, 30]:
                    hostname_prefix = hostname_underscore[:prefix_len] if len(hostname_underscore) > prefix_len else hostname_underscore

                    for log_dir in log_dirs:
                        dir_name = log_dir.name

                        if dir_name.startswith(hostname_prefix):
                            log_files = list(log_dir.glob("*.log"))
                            if log_files:
                                log_files.sort(key=lambda x: x.stat().st_mtime, reverse=True)
                                return log_files[0]
            else:
                for log_dir in log_dirs:
                    dir_name = log_dir.name

                    if file_stem in dir_name:
                        log_files = list(log_dir.glob("*.log"))
                        if log_files:
                            log_files.sort(key=lambda x: x.stat().st_mtime, reverse=True)
                            return log_files[0]

            for log_dir in log_dirs:
                dir_name = log_dir.name

                if (file_stem in dir_name or
                    hostname_underscore in dir_name or
                    hostname in dir_name or
                    filename in dir_name):
                    log_files = list(log_dir.glob("*.log"))
                    if log_files:
                        log_files.sort(key=lambda x: x.stat().st_mtime, reverse=True)
                        return log_files[0]

            if log_dirs:
                latest_dir = log_dirs[0]
                log_files = list(latest_dir.glob("*.log"))
                if log_files:
                    log_files.sort(key=lambda x: x.stat().st_mtime, reverse=True)
                    return log_files[0]

            return None
        except Exception as e:
            self._log(f"查找IDM日志路径时出错: {traceback.format_exc()}", "error")
            return None

    @staticmethod
    def format_file_size(bytes_num: int) -> str:
        """
        格式化文件大小

        Args:
            bytes_num: 字节数

        Returns:
            格式化后的大小字符串，如 "1.5 MB"、"256 KB"、"1024 B"
        """
        if bytes_num <= 0:
            return "0 B"

        for unit in ["B", "KB", "MB", "GB", "TB"]:
            if bytes_num < 1024.0:
                return f"{bytes_num:.2f} {unit}"
            bytes_num /= 1024.0

        return f"{bytes_num:.2f} PB"

    @staticmethod
    def format_remaining_time(seconds: float) -> str:
        """
        格式化剩余时间

        Args:
            seconds: 剩余秒数

        Returns:
            格式化后的时间字符串，如 "1小时30分25秒"、"30分25秒"、"25秒"
        """
        if seconds <= 0:
            return "--"

        hours = int(seconds // 3600)
        minutes = int((seconds % 3600) // 60)
        secs = int(seconds % 60)

        parts = []
        if hours > 0:
            parts.append(f"{hours}小时")
        if minutes > 0 or hours > 0:
            parts.append(f"{minutes}分")
        parts.append(f"{secs}秒")

        return "".join(parts)

    def parse_log_progress(self, log_path: Path) -> Optional[Dict[str, Any]]:
        """
        解析IDM日志文件获取下载进度

        Args:
            log_path: 日志文件路径

        Returns:
            包含进度信息的字典，格式：
            {
                "percent": 下载百分比,
                "downloaded": 已下载字节数,
                "total": 总字节数,
                "speed": 下载速度,
                "status": 状态 ("downloading", "completed", "error"),
                "remaining_time": 剩余时间（格式化字符串）
            }
        """
        try:
            if not log_path or not log_path.exists():
                return None

            with open(log_path, "r", encoding="utf-8", errors="ignore") as f:
                lines = f.readlines()

            if not lines:
                return None

            result = {
                "percent": 0,
                "downloaded": 0,
                "total": 0,
                "speed": "",
                "status": "downloading",
                "remaining_time": "--",
                "formatted_downloaded": "0 B",
                "formatted_total": "0 B",
                "formatted_size": "0 B / 0 B"
            }

            total_size = 0
            downloaded_size = 0
            speed_value = 0
            has_progress = False

            is_m3u8 = False
            for line in lines:
                if ".m3u8" in line or "m3u8" in line.lower():
                    is_m3u8 = True
                    break

            if not is_m3u8:
                for line in lines:
                    line = line.strip()
                    content_length_match = re.search(r"Content-Length:\s*(\d+)", line, re.I)
                    if content_length_match:
                        total_size = int(content_length_match.group(1))
                        result["total"] = total_size
                        break

            found_completed = False
            found_rebuilding = False
            found_error = False
            found_cancel = False

            for line in reversed(lines):
                line = line.strip()

                if "Rebuilding complete" in line or "重建完成" in line:
                    found_completed = True
                    result["status"] = "completed"
                    result["percent"] = 100.0
                    result["remaining_time"] = "已完成"
                    rebuild_match = re.search(r"(?:Rebuilding complete|重建完成).*?=\s*(\d+)", line, re.I)
                    if rebuild_match:
                        real_size = int(rebuild_match.group(1))
                        result["total"] = real_size
                        result["downloaded"] = real_size
                        result["formatted_downloaded"] = self.format_file_size(real_size)
                        result["formatted_total"] = self.format_file_size(real_size)
                        result["formatted_size"] = f"{result['formatted_downloaded']} / {result['formatted_total']}"
                    break

                if "下载完成，正在整合各下载块为一个文件" in line or "Assembling all downloaded portions" in line:
                    found_rebuilding = True
                    result["status"] = "rebuilding"

                if "下载完成。共下载" in line and not found_completed:
                    if not found_rebuilding:
                        result["status"] = "rebuilding"
                    result["percent"] = 100.0
                    result["remaining_time"] = "整合中"
                    complete_match = re.search(r"下载完成。共下载\s*(\d+)\s*字节", line)
                    if complete_match:
                        total_size = int(complete_match.group(1))
                        result["total"] = total_size
                        result["downloaded"] = total_size
                        result["formatted_downloaded"] = self.format_file_size(total_size)
                        result["formatted_total"] = self.format_file_size(total_size)
                        result["formatted_size"] = f"{result['formatted_downloaded']} / {result['formatted_total']}"
                    continue

                if "Cancel by user" in line:
                    found_cancel = True

                error_match = re.search(r"失败", line, re.I)
                if error_match:
                    found_error = True

                progress_match = re.search(
                    r"time\s+\d+,\s*speed\s+(\d+),\s*downl\s+(\d+)\s*Bytes",
                    line
                )
                if progress_match and not has_progress:
                    has_progress = True
                    speed_value = int(progress_match.group(1))
                    downloaded_size = int(progress_match.group(2))
                    result["downloaded"] = downloaded_size

                    if speed_value >= 1048576:
                        result["speed"] = f"{speed_value / 1048576:.2f} MB/s"
                    elif speed_value >= 1024:
                        result["speed"] = f"{speed_value / 1024:.2f} KB/s"
                    else:
                        result["speed"] = f"{speed_value} B/s"

                    result["formatted_downloaded"] = self.format_file_size(downloaded_size)
                    if total_size > 0:
                        result["formatted_total"] = self.format_file_size(total_size)
                        result["formatted_size"] = f"{result['formatted_downloaded']} / {result['formatted_total']}"
                    else:
                        result["formatted_size"] = result["formatted_downloaded"]

                    if total_size > 0:
                        result["percent"] = round(min(100, (downloaded_size / total_size) * 100), 2)

                        if speed_value > 0:
                            remaining_bytes = total_size - downloaded_size
                            if remaining_bytes > 0:
                                remaining_seconds = remaining_bytes / speed_value
                                result["remaining_time"] = self.format_remaining_time(remaining_seconds)

            if not found_completed:
                if found_error:
                    result["status"] = "error"
                elif found_cancel:
                    result["status"] = "error"
                elif found_rebuilding:
                    pass
                else:
                    result["status"] = "downloading"

            if result["total"] == 0 and result["downloaded"] > 0 and result["status"] == "completed":
                result["total"] = result["downloaded"]

            return result
        except Exception as e:
            self._log(f"解析IDM日志时出错: {traceback.format_exc()}", "error")
            return None

    def stop(self):
        """停止下载"""
        self._stop_flag = True

    def pause(self):
        """暂停下载"""
        self._paused_flag = True

    def resume(self):
        """恢复下载"""
        self._paused_flag = False

    def download(
        self,
        url: str,
        save_path: str,
        filename: Optional[str] = None,
        headers: Optional[Dict[str, str]] = None,
        options: Optional[Dict[str, Any]] = None,
        timeout: int = 3600,
    ) -> bool:
        """
        使用IDM下载文件

        Args:
            url: 下载URL
            save_path: 文件保存路径（目录或完整文件路径）
            filename: 可选，指定文件名
            headers: 可选，请求头
            options: 可选，额外选项
            timeout: 超时时间（秒），默认3600

        Returns:
            是否下载成功
        """
        self._stop_flag = False
        self._paused_flag = False

        save_path_obj = Path(save_path)
        if save_path_obj.is_dir():
            output_path = save_path_obj / (filename or "download")
        else:
            output_path = save_path_obj
            if filename:
                output_path = save_path_obj.parent / filename

        idm_path = self.check_idm()
        if not idm_path:
            self._log("未找到IDM可执行文件", "error")
            return False

        if re.search(r"\.flv", url, re.I) or re.search(r"\.m3u8", url, re.I):
            self._log("IDM不适合处理流媒体，请使用其他下载引擎", "warning")
            return False

        display_name = output_path.stem[:30] + "…" if len(output_path.stem) > 30 else output_path.stem

        cmd = [
            idm_path,
            "/d", url,
            "/p", str(output_path.parent),
            "/f", f"{output_path.name}",
            "/n",
            "/s",
        ]

        if options:
            for key, value in options.items():
                cmd.extend([f"/{key}", str(value)])

        self._log(f"正在使用IDM下载「{display_name}」", "info")

        try:
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                creationflags=subprocess.CREATE_NO_WINDOW,
            )

            time.sleep(3)

            if process.poll() is not None:
                if process.returncode != 0:
                    error_msg = process.stderr.read().decode('gbk', errors='ignore') or process.stdout.read().decode('gbk', errors='ignore')
                    self._log(f"IDM启动失败: {error_msg}", "error")
                    return False

            log_path = None
            log_find_attempts = 0
            max_log_find_attempts = 10

            while log_path is None and log_find_attempts < max_log_find_attempts:
                log_path = self.get_log_path(url, output_path.name)
                if log_path is None:
                    time.sleep(1)
                    log_find_attempts += 1

            if log_path is not None:
                self._log(f"已找到IDM日志文件：{log_path.parent.name}", "info")

            download_complete = False
            last_progress = 0
            start_time = time.time()

            while not download_complete:
                if self._stop_flag:
                    self._log(f"已停止下载：{display_name}", "warning")
                    return False

                while self._paused_flag:
                    time.sleep(1)

                if time.time() - start_time > timeout:
                    self._log(f"下载超时：{display_name}", "error")
                    return False

                if output_path.exists():
                    file_size = output_path.stat().st_size
                    if file_size > 10240:
                        time.sleep(2)
                        if output_path.exists() and output_path.stat().st_size == file_size:
                            download_complete = True
                            break

                if log_path and log_path.exists():
                    progress_info = self.parse_log_progress(log_path)
                    if progress_info:
                        current_progress = progress_info.get("percent", 0)
                        speed = progress_info.get("speed", "")
                        status = progress_info.get("status", "downloading")
                        remaining_time = progress_info.get("remaining_time", "--")
                        formatted_size = progress_info.get("formatted_size", "0 B / 0 B")

                        if current_progress != last_progress:
                            last_progress = current_progress
                            progress_msg = f"「{display_name}」| IDM下载中 | 进度：{current_progress}% | 已下载：{formatted_size}"
                            if speed:
                                progress_msg += f" | 速度：{speed}"
                            if remaining_time and remaining_time != "--" and remaining_time != "已完成":
                                progress_msg += f" | 剩余：{remaining_time}"
                            self._log(progress_msg, "info")
                            self._emit_progress(progress_info)

                        if status == "completed":
                            download_complete = True
                            break
                        elif status == "error":
                            self._log(f"IDM下载出错：{display_name}", "error")
                            return False
                else:
                    if log_find_attempts < max_log_find_attempts + 5:
                        log_path = self.get_log_path(url, output_path.name)
                        log_find_attempts += 1

                time.sleep(1)

            self._log(f"IDM下载完成：{display_name}", "success")
            return True

        except Exception as e:
            self._log(f"使用IDM下载时发生异常: {str(e)}", "error")
            return False


def simple_download(url: str, save_path: str) -> bool:
    """
    简单的IDM下载函数

    这是一个便捷函数，用于最简单的IDM下载场景。
    只需传入下载地址和保存路径即可。

    Args:
        url: 下载URL
        save_path: 文件保存路径

    Returns:
        是否下载成功
    """
    downloader = IDMDownloader()
    return downloader.download(url, save_path)


if __name__ == "__main__":
    import sys

    if len(sys.argv) < 3:
        print("Usage: python idm_downloader.py <url> <save_path>")
        print("Example: python idm_downloader.py https://example.com/file.mp4 C:\\Downloads")
        sys.exit(1)

    url = sys.argv[1]
    save_path = sys.argv[2]

    result = simple_download(url, save_path)
    sys.exit(0 if result else 1)
