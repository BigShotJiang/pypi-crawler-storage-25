"""
IDM (Internet Download Manager) Python Library

A Python library for downloading files using Internet Download Manager (IDM) with progress monitoring.
"""

__version__ = "0.1.1"
__author__ = "Your Name"
__license__ = "MIT"

from .idm_downloader import (
    IDMDownloader,
    simple_download,
)

__all__ = [
    "IDMDownloader",
    "simple_download",
]
