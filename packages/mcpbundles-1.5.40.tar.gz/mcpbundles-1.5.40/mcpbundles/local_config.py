"""Persistent local MCP connection configuration."""

from __future__ import annotations

import hashlib
import json
import shlex
import uuid
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Literal

from mcpbundles.config import CONFIG_DIR

LOCAL_CONNECTIONS_FILE = CONFIG_DIR / "local_connections.json"
RUNTIME_KEY_FILE = CONFIG_DIR / "runtime_key"
LocalTransport = Literal["http", "stdio", "command"]


@dataclass(frozen=True)
class LocalConnection:
    name: str
    display_name: str
    transport: LocalTransport
    command: list[str] | None = None
    url: str | None = None
    server_name: str | None = None
    provider_slug: str | None = None
    bundle_slug: str | None = None
    install_option_id: str | None = None
    package_identifier: str | None = None
    package_registry_type: str | None = None
    package_version: str | None = None
    source_url: str | None = None
    terms_url: str | None = None
    privacy_url: str | None = None
    consent_version: str | None = None
    consent_accepted_at: str | None = None
    command_digest: str | None = None
    auto_update_enabled: bool = True

    @property
    def connection_key(self) -> str:
        return self.name


def _config_path() -> Path:
    return LOCAL_CONNECTIONS_FILE


def get_or_create_runtime_key() -> str:
    path = RUNTIME_KEY_FILE
    if path.exists():
        value = path.read_text().strip()
        if value:
            return value
    path.parent.mkdir(parents=True, exist_ok=True)
    value = f"rt_{uuid.uuid4().hex}"
    path.write_text(value)
    path.chmod(0o600)
    return value


def load_local_connections() -> dict[str, LocalConnection]:
    path = _config_path()
    if not path.exists():
        return {}
    raw = json.loads(path.read_text())
    if not isinstance(raw, dict):
        return {}
    connections: dict[str, LocalConnection] = {}
    for name, value in raw.items():
        if not isinstance(value, dict):
            continue
        connections[name] = LocalConnection(
            name=name,
            display_name=str(value.get("display_name") or name),
            transport=value["transport"],
            command=value.get("command"),
            url=value.get("url"),
            server_name=value.get("server_name"),
            provider_slug=value.get("provider_slug"),
            bundle_slug=value.get("bundle_slug"),
            install_option_id=value.get("install_option_id"),
            package_identifier=value.get("package_identifier"),
            package_registry_type=value.get("package_registry_type"),
            package_version=value.get("package_version"),
            source_url=value.get("source_url"),
            terms_url=value.get("terms_url"),
            privacy_url=value.get("privacy_url"),
            consent_version=value.get("consent_version"),
            consent_accepted_at=value.get("consent_accepted_at"),
            command_digest=value.get("command_digest"),
            auto_update_enabled=bool(value.get("auto_update_enabled", True)),
        )
    return connections


def save_local_connections(connections: dict[str, LocalConnection]) -> None:
    path = _config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        name: {
            key: value
            for key, value in asdict(connection).items()
            if key != "name" and value is not None
        }
        for name, connection in sorted(connections.items())
    }
    path.write_text(json.dumps(payload, indent=2, sort_keys=True))


def parse_command(command: str) -> list[str]:
    parsed = shlex.split(command)
    if not parsed:
        raise ValueError("Command cannot be empty")
    return parsed


def command_digest(command: list[str]) -> str:
    payload = json.dumps(command, separators=(",", ":"), ensure_ascii=True)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def upsert_local_connection(
    *,
    name: str,
    display_name: str | None,
    transport: LocalTransport,
    command: list[str] | None = None,
    url: str | None = None,
    server_name: str | None = None,
    provider_slug: str | None = None,
    bundle_slug: str | None = None,
    install_option_id: str | None = None,
    package_identifier: str | None = None,
    package_registry_type: str | None = None,
    package_version: str | None = None,
    source_url: str | None = None,
    terms_url: str | None = None,
    privacy_url: str | None = None,
    consent_version: str | None = None,
    consent_accepted_at: str | None = None,
    command_digest_value: str | None = None,
    auto_update_enabled: bool = True,
) -> LocalConnection:
    if transport in {"command", "stdio"} and not command:
        raise ValueError(f"{transport} connections require --command")
    if transport == "http" and not url:
        raise ValueError("http connections require --url")
    if command and url:
        raise ValueError("Use either --command or --url, not both")

    connections = load_local_connections()
    connection = LocalConnection(
        name=name,
        display_name=display_name or name,
        transport=transport,
        command=command,
        url=url,
        server_name=server_name,
        provider_slug=provider_slug,
        bundle_slug=bundle_slug,
        install_option_id=install_option_id,
        package_identifier=package_identifier,
        package_registry_type=package_registry_type,
        package_version=package_version,
        source_url=source_url,
        terms_url=terms_url,
        privacy_url=privacy_url,
        consent_version=consent_version,
        consent_accepted_at=consent_accepted_at,
        command_digest=command_digest_value or (command_digest(command) if command else None),
        auto_update_enabled=auto_update_enabled,
    )
    connections[name] = connection
    save_local_connections(connections)
    return connection


def remove_local_connection(name: str) -> bool:
    connections = load_local_connections()
    removed = connections.pop(name, None)
    if removed is None:
        return False
    if connections:
        save_local_connections(connections)
    else:
        _config_path().unlink(missing_ok=True)
    return True


def serialize_connection(connection: LocalConnection) -> dict[str, Any]:
    data = asdict(connection)
    data["connection_key"] = connection.connection_key
    if connection.install_option_id:
        data["consent"] = {
            "accepted": bool(connection.consent_accepted_at),
            "accepted_at": connection.consent_accepted_at,
            "version": connection.consent_version,
            "command_digest": connection.command_digest,
            "source_url": connection.source_url,
            "terms_url": connection.terms_url,
            "privacy_url": connection.privacy_url,
        }
    return data


__all__ = [
    "LocalConnection",
    "LOCAL_CONNECTIONS_FILE",
    "RUNTIME_KEY_FILE",
    "load_local_connections",
    "get_or_create_runtime_key",
    "parse_command",
    "command_digest",
    "remove_local_connection",
    "save_local_connections",
    "serialize_connection",
    "upsert_local_connection",
]
