"""Cross-platform single-instance lock for the proxy daemon.

We had a race where two ``mcpbundles proxy run --desktop-managed``
processes could start within milliseconds of each other and both
register as separate local runtimes with the backend, causing the
backend to randomly load-balance browser/tool calls between them.

This module enforces "at most one proxy daemon per CONFIG_DIR" using a
real OS advisory lock on a dedicated lock file. The lock is held for
the entire lifetime of the daemon process — the kernel releases it
automatically when the process exits (including SIGKILL / crash), so
no stale-PID cleanup is required.
"""

from __future__ import annotations

import os
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Optional


class AlreadyRunning(Exception):
    """Raised when another proxy daemon already holds the lock."""

    def __init__(self, lock_path: Path, holder_pid: Optional[int]) -> None:
        self.lock_path = lock_path
        self.holder_pid = holder_pid
        msg = f"proxy daemon already running (lock={lock_path}"
        if holder_pid is not None:
            msg += f", pid={holder_pid}"
        msg += ")"
        super().__init__(msg)


@dataclass
class _LockState:
    fd: int
    path: Path


# Module-level reference keeps the FD (and therefore the OS lock) alive
# for the whole process lifetime. Closing the FD — explicitly or via
# process exit — releases the lock.
_HELD: Optional[_LockState] = None


def _read_holder_pid(lock_path: Path) -> Optional[int]:
    """Best-effort read of the pid recorded by the current lock holder."""
    try:
        text = lock_path.read_text().strip()
    except OSError:
        return None
    if not text:
        return None
    try:
        return int(text)
    except ValueError:
        return None


def acquire_singleton_lock(lock_path: Path) -> int:
    """Acquire an exclusive non-blocking lock on ``lock_path``.

    Returns the open file descriptor. The caller MUST NOT close it for
    the duration it wants exclusivity; the module also retains a
    reference so the FD stays alive for the process lifetime.

    Raises:
        AlreadyRunning: another process already holds the lock.
    """
    global _HELD

    if _HELD is not None and _HELD.path == lock_path:
        # Idempotent re-acquire from the same process.
        return _HELD.fd

    lock_path.parent.mkdir(parents=True, exist_ok=True)
    fd = os.open(lock_path, os.O_RDWR | os.O_CREAT, 0o600)

    try:
        if sys.platform == "win32":
            import msvcrt

            try:
                msvcrt.locking(fd, msvcrt.LK_NBLCK, 1)
            except OSError as exc:
                os.close(fd)
                raise AlreadyRunning(lock_path, _read_holder_pid(lock_path)) from exc
        else:
            import fcntl

            try:
                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError as exc:
                os.close(fd)
                raise AlreadyRunning(lock_path, _read_holder_pid(lock_path)) from exc
    except AlreadyRunning:
        raise
    except Exception:
        os.close(fd)
        raise

    # Lock held — stamp our pid so future conflicts can surface it.
    try:
        os.ftruncate(fd, 0)
        os.lseek(fd, 0, os.SEEK_SET)
        os.write(fd, f"{os.getpid()}\n".encode("ascii"))
        os.fsync(fd)
    except OSError:
        # Stamping is best-effort; the lock itself is what matters.
        pass

    _HELD = _LockState(fd=fd, path=lock_path)
    return fd


def release_singleton_lock() -> None:
    """Release the lock held by this process, if any.

    Normally unnecessary — process exit releases the lock — but used by
    tests and by the explicit shutdown path so the FD doesn't leak in
    long-lived test processes.
    """
    global _HELD
    if _HELD is None:
        return
    try:
        os.close(_HELD.fd)
    except OSError:
        pass
    try:
        _HELD.path.unlink()
    except OSError:
        pass
    _HELD = None


def try_acquire_then_release(lock_path: Path) -> bool:
    """Pre-flight: True if no other process currently holds the lock.

    Used by ``start_daemon``'s parent before ``fork()`` so the user
    sees a clear "already running" error without spawning a doomed
    child. There is a tiny TOCTOU window before the child re-acquires,
    but the child will fail loudly and exit if it loses that race.
    """
    try:
        acquire_singleton_lock(lock_path)
    except AlreadyRunning:
        return False
    release_singleton_lock()
    return True
