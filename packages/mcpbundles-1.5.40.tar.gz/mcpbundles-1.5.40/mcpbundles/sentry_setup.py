"""Sentry initialization for the mcpbundles CLI and proxy sidecar.

The same module is used by three populations of installs:

1. **PyPI / brew / pipx / uv installs of the CLI** — DSN comes from the
   committed ``_sentry_baked.BAKED_DSN`` which the release workflow
   overwrites before publishing the wheel. Crash reporting is on by
   default so we hear about crashes from real users, matching the
   modern developer-CLI norm (Next.js, Astro, Nuxt, Vercel CLI,
   Homebrew).
2. **Desktop-bundled sidecar** — the Electron supervisor sets
   ``MCPBUNDLES_SENTRY_DSN`` per invocation. This wins over the baked
   value so the desktop telemetry toggle can flip the sidecar off by
   either dropping the env var or setting ``MCPBUNDLES_TELEMETRY_DISABLED=1``.
3. **Editable source installs** (``pip install -e .``) — baked DSN is
   the empty string, so Sentry stays a no-op and our own dev crashes
   never reach production issue queues.

Resolution order (first match wins):

1. ``MCPBUNDLES_TELEMETRY_DISABLED=1`` → never initialize.
2. ``config.yaml`` ``telemetry: false`` → never initialize.
3. DSN = ``MCPBUNDLES_SENTRY_DSN`` if set, else
   ``_sentry_baked.BAKED_DSN`` if non-empty, else empty.
4. Empty DSN → no-op.

Mirrors ``backend/app/sentry/setup.py``: ``send_default_pii=False``,
``before_send`` redacts known credential-shaped keys, traces and
profiles disabled (zero quota burn, zero perf cost).
"""

from __future__ import annotations

import logging
import os
import sys
from typing import Any

from mcpbundles._sentry_baked import BAKED_DSN

logger = logging.getLogger(__name__)

_TELEMETRY_DISABLE_ENV = "MCPBUNDLES_TELEMETRY_DISABLED"
_DSN_ENV = "MCPBUNDLES_SENTRY_DSN"
_RELEASE_ENV = "MCPBUNDLES_SENTRY_RELEASE"
_ENV_ENV = "MCPBUNDLES_SENTRY_ENVIRONMENT"

# Substrings that almost certainly indicate a leaked credential. We do
# not have access to live secrets here, so this list is conservative —
# upstream callers (Electron supervisor, CLI invocation paths) also
# redact known live tokens before log lines reach the sidecar.
_SECRET_KEY_HINTS = (
    "access_token",
    "refresh_token",
    "client_secret",
    "api_key",
    "apikey",
    "authorization",
    "auth_header",
    "sentry_auth_token",
    "csc_key_password",
    "apple_app_specific_password",
    "azure_client_secret",
    "agent_api_key",
    "plaintext",
    "mb_pat_",
)

_REDACTED = "[redacted]"

# Module-level flag so callers (e.g. ``mcpbundles telemetry status``)
# can ask whether Sentry was actually initialised in this process. The
# DSN itself is never exposed.
_initialized: bool = False


def _looks_like_secret_key(key: str) -> bool:
    lowered = key.lower()
    return any(hint in lowered for hint in _SECRET_KEY_HINTS)


def _scrub(value: Any) -> Any:
    if isinstance(value, dict):
        out: dict[str, Any] = {}
        for k, v in value.items():
            if isinstance(k, str) and _looks_like_secret_key(k):
                out[k] = _REDACTED
            else:
                out[k] = _scrub(v)
        return out
    if isinstance(value, list):
        return [_scrub(item) for item in value]
    if isinstance(value, tuple):
        return tuple(_scrub(item) for item in value)
    return value


def _before_send(event: dict[str, Any], hint: dict[str, Any]) -> dict[str, Any] | None:
    # Drop known-noisy startup races the daemon self-recovers from
    # within seconds. Owners can re-enable visibility by removing this
    # branch if they want to count occurrences over time.
    message = event.get("message") or ""
    if "Expose registration failed" in message and "HTTP 409" in message:
        return None
    try:
        return _scrub(event)
    except Exception:
        return event


def _is_frozen() -> bool:
    """True when running inside a PyInstaller-built binary."""
    return bool(getattr(sys, "frozen", False))


def _install_source() -> str:
    """Classify the install for the Sentry ``install_source`` tag.

    - ``pyinstaller`` — frozen sidecar (desktop bundle or standalone).
    - ``wheel`` — pip/brew/pipx/uv install from PyPI; the baked DSN is
      present, so we know this is a published release artifact.
    - ``source`` — editable / source install; baked DSN is empty.
    """
    if _is_frozen():
        return "pyinstaller"
    if BAKED_DSN:
        return "wheel"
    return "source"


def telemetry_enabled_in_config() -> bool:
    """Return False only when ``config.yaml`` explicitly opts out.

    Imported lazily because ``mcpbundles.config`` itself reads from
    disk and we want ``sentry_setup`` to remain safe to import from
    very early in process startup.
    """
    try:
        from mcpbundles.config import load_config

        cfg = load_config()
    except Exception:
        return True
    value = cfg.get("telemetry")
    if value is None:
        return True
    return bool(value)


def telemetry_disabled_by_env() -> bool:
    return (os.getenv(_TELEMETRY_DISABLE_ENV) or "").strip().lower() in {
        "1",
        "true",
        "yes",
        "on",
    }


def resolved_dsn() -> str:
    """Resolve the DSN that init_sentry would use, or empty string."""
    env_dsn = (os.getenv(_DSN_ENV) or "").strip()
    if env_dsn:
        return env_dsn
    return (BAKED_DSN or "").strip()


def init_sentry() -> bool:
    """Initialize Sentry for the CLI / sidecar if telemetry is allowed.

    Idempotent: a second call is a no-op.

    Returns True when Sentry was initialized, False when the user opted
    out or no DSN is available.
    """
    global _initialized
    if _initialized:
        return True

    if telemetry_disabled_by_env():
        return False
    if not telemetry_enabled_in_config():
        return False

    dsn = resolved_dsn()
    if not dsn:
        return False

    try:
        import sentry_sdk
        from sentry_sdk.integrations.logging import LoggingIntegration
    except Exception as error:
        logger.warning("Sentry SDK import failed: %s", error)
        return False

    environment = (os.getenv(_ENV_ENV) or "production").strip() or "production"
    release = (os.getenv(_RELEASE_ENV) or "").strip() or None

    integrations: list[Any] = [
        LoggingIntegration(level=logging.WARNING, event_level=logging.ERROR),
    ]

    sentry_sdk.init(
        dsn=dsn,
        environment=environment,
        release=release,
        send_default_pii=False,
        traces_sample_rate=0.0,
        profiles_sample_rate=0.0,
        max_breadcrumbs=50,
        attach_stacktrace=True,
        integrations=integrations,
        before_send=_before_send,
    )
    sentry_sdk.set_tag("process", "mcpbundles-cli")
    sentry_sdk.set_tag("install_source", _install_source())
    runtime_owner = (os.getenv("MCPBUNDLES_RUNTIME_OWNER") or "").strip()
    if runtime_owner:
        sentry_sdk.set_tag("runtime_owner", runtime_owner)
    connection = (os.getenv("MCPBUNDLES_CONNECTION") or "").strip()
    if connection:
        sentry_sdk.set_tag("connection_name", connection)

    _initialized = True
    logger.info(
        "Sentry initialized for CLI / sidecar (env=%s release=%s install=%s)",
        environment,
        release or "unset",
        _install_source(),
    )
    return True


def is_initialized() -> bool:
    return _initialized
