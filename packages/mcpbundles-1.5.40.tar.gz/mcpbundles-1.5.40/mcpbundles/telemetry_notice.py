"""One-time first-run telemetry banner for the mcpbundles CLI.

Modelled on ``mcpbundles.version_notice``: prints a single Rich panel
the first time the CLI runs after install. "Seen" state is persisted
to ``config.yaml`` via the ``telemetry_notice_shown`` key so the
banner only ever appears once per install per machine.

Suppressed when:

- ``--quiet`` is passed at the CLI root (handled by the caller).
- stderr is not a TTY (CI, redirected output, scripted invocations).
- Sentry was not initialised this process — either the user has
  already opted out, the baked DSN is empty (editable source install),
  or telemetry is disabled in config / env. There is nothing to notify
  about, so the banner stays silent.
- The user has already seen the banner once.
"""

from __future__ import annotations

import logging
import sys

from rich.panel import Panel

from mcpbundles.config import load_config, save_config
from mcpbundles.output import console
from mcpbundles.sentry_setup import is_initialized

logger = logging.getLogger(__name__)

_SEEN_KEY = "telemetry_notice_shown"


def maybe_render_telemetry_notice(*, quiet: bool) -> None:
    if quiet or not sys.stderr.isatty():
        return
    if not is_initialized():
        return

    try:
        cfg = load_config()
    except Exception:
        cfg = {}
    if cfg.get(_SEEN_KEY):
        return

    console.print()
    console.print(
        Panel(
            (
                "[bold]Crash and error reporting is on.[/bold]\n"
                "MCPBundles sends anonymous crash reports to help us fix bugs:\n"
                "  • stack trace, CLI version, OS, command name\n"
                "  • [dim]not sent: tokens, API keys, command arguments, file contents[/dim]\n"
                "Opt out: [cyan]mcpbundles telemetry disable[/cyan]"
                " or set [cyan]MCPBUNDLES_TELEMETRY_DISABLED=1[/cyan]"
            ),
            title="Telemetry",
            border_style="cyan",
            expand=False,
        )
    )
    console.print()

    try:
        cfg[_SEEN_KEY] = True
        save_config(cfg)
    except Exception as error:
        # Failing to persist the seen flag is not fatal; worst case
        # the banner is shown a second time.
        logger.debug("Failed to persist telemetry notice seen flag: %s", error)
