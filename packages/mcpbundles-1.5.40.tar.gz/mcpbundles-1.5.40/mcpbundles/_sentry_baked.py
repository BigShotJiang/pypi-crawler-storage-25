"""Build-time-injected Sentry DSN (overwritten by publish.yml)."""

BAKED_DSN: str = "https://4f7c833da1e6ca2f7587b674a70023ca@o4511410004230144.ingest.de.sentry.io/4511410019369040"
