"""Hidden diagnostics for the frozen sidecar.

Lives under `mcpbundles internal ...` so it does not appear in the user
help surface but is reachable for build-time smoke tests and runtime
self-diagnosis. The most important entry points are `internal browser-check`
and `internal capabilities`, which prove optional features are bundled and
discoverable on this machine.
"""

from __future__ import annotations

import json
import sys

import click

from mcpbundles.capabilities import build_machine_capabilities, probe_playwright


@click.group(name="internal", hidden=True)
def internal_group() -> None:
    """Internal diagnostics. Hidden from the user help surface."""


@internal_group.command(name="capabilities")
@click.option(
    "--json",
    "as_json",
    is_flag=True,
    help="Emit machine-readable JSON instead of human text.",
)
@click.option(
    "--force",
    is_flag=True,
    help="Bypass the in-process cache and re-run all probes.",
)
def capabilities_cmd(as_json: bool, force: bool) -> None:
    """Report optional feature readiness (Local Browser, Claude Code CLI)."""
    report = build_machine_capabilities(force=force)
    if as_json:
        click.echo(json.dumps(report))
        return

    local_browser = report.get("local_browser") or {}
    claude_code = report.get("claude_code") or {}
    click.echo(f"Local Browser: {local_browser.get('status', 'unknown')}")
    remediation = local_browser.get("remediation")
    if remediation:
        click.echo(f"  {remediation}")
    click.echo(f"Claude Code CLI: {claude_code.get('status', 'unknown')}")
    claude_remediation = claude_code.get("remediation")
    if claude_remediation:
        click.echo(f"  {claude_remediation}")


@internal_group.command(name="browser-check")
@click.option(
    "--json",
    "as_json",
    is_flag=True,
    help="Emit machine-readable JSON instead of human text.",
)
def browser_check(as_json: bool) -> None:
    """Verify Playwright is importable and its driver bundle is present.

    The desktop app bundles this binary via PyInstaller. Anything pip
    installs into the user's system Python after the fact is invisible to
    this interpreter, so we need a way to assert at build time (and
    diagnose at runtime) that the [browser] extra is actually inside the
    frozen archive.
    """
    playwright = probe_playwright()
    result: dict[str, object] = {
        "frozen": playwright.get("frozen", bool(getattr(sys, "frozen", False))),
        "executable": sys.executable,
        "playwright_version": playwright.get("playwright_version"),
        "driver_dir": playwright.get("driver_dir"),
        "driver_present": playwright.get("driver_present", playwright.get("status") == "ok"),
        "status": "ok" if playwright.get("status") == "ok" else playwright.get("status"),
    }
    if playwright.get("error"):
        result["error"] = playwright["error"]

    if playwright.get("status") != "ok":
        if as_json:
            click.echo(json.dumps(result))
        else:
            status = playwright.get("status")
            if status == "playwright_missing":
                click.echo("browser-check: FAIL — playwright is not importable", err=True)
            else:
                click.echo(
                    "browser-check: FAIL — playwright imported but its driver "
                    "bundle is missing. PyInstaller likely was not invoked with "
                    "--collect-all playwright.",
                    err=True,
                )
            remediation = playwright.get("remediation")
            if remediation:
                click.echo(f"  {remediation}", err=True)
            if playwright.get("driver_dir"):
                click.echo(f"  expected at: {playwright['driver_dir']}", err=True)
        sys.exit(1)

    if as_json:
        click.echo(json.dumps(result))
    else:
        click.echo(
            f"browser-check: OK — playwright {result['playwright_version']} "
            f"with driver at {result['driver_dir']}"
        )
