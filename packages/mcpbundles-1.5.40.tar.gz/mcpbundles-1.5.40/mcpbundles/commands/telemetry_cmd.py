"""``mcpbundles telemetry`` — inspect and control crash reporting.

Three subcommands matching the Vercel / Astro / Nuxt CLI convention:

- ``mcpbundles telemetry status`` — show the effective state, the DSN
  source (env / baked / disabled), retention, and what is and is not
  collected. Answers a GDPR-curious user's questions in one command.
- ``mcpbundles telemetry enable``  — persist ``telemetry: true`` in
  ``config.yaml``.
- ``mcpbundles telemetry disable`` — persist ``telemetry: false``.

Environment override always wins: ``MCPBUNDLES_TELEMETRY_DISABLED=1``
silences the SDK regardless of stored config, mirroring the env
override Vercel / Next.js use for CI runners.
"""

from __future__ import annotations

import click
from rich.panel import Panel

from mcpbundles.config import load_config, save_config
from mcpbundles.output import render_success, stdout_console
from mcpbundles.sentry_setup import (
    BAKED_DSN,
    resolved_dsn,
    telemetry_disabled_by_env,
    telemetry_enabled_in_config,
)


@click.group("telemetry")
def telemetry_group() -> None:
    """Show or change crash and error reporting."""


def _effective_state() -> tuple[bool, str]:
    """Return (is_enabled, reason) reflecting all gates."""
    if telemetry_disabled_by_env():
        return False, "disabled by MCPBUNDLES_TELEMETRY_DISABLED env var"
    if not telemetry_enabled_in_config():
        return False, "disabled in config.yaml"
    dsn = resolved_dsn()
    if not dsn:
        return False, "no DSN baked into this build (editable / source install)"
    if dsn == BAKED_DSN:
        return True, "enabled (using baked DSN from release build)"
    return True, "enabled (using DSN from MCPBUNDLES_SENTRY_DSN env var)"


@telemetry_group.command("status")
def telemetry_status() -> None:
    """Show current telemetry state and what is collected."""
    enabled, reason = _effective_state()
    status_color = "green" if enabled else "yellow"
    status_label = "ENABLED" if enabled else "DISABLED"
    body = (
        f"[bold {status_color}]{status_label}[/bold {status_color}]  [dim]({reason})[/dim]\n\n"
        "[bold]What's collected[/bold]\n"
        "  • Stack trace and exception message\n"
        "  • CLI version, OS, Python version, install source (wheel / pyinstaller)\n"
        "  • Command name (e.g. 'tools', 'call'), [bold]not[/bold] the arguments\n"
        "  • Workspace identifier and connection name when running under the desktop app\n\n"
        "[bold]What's never collected[/bold]\n"
        "  • API keys, OAuth tokens, refresh tokens, agent API keys\n"
        "  • Command arguments, file contents, request or response bodies\n"
        "  • Your IP address (dropped server-side by the Sentry project)\n\n"
        "[bold]Sub-processor[/bold]\n"
        "  Sentry (EU region, Frankfurt). 90-day retention.\n\n"
        "[bold]Opt out[/bold]\n"
        "  [cyan]mcpbundles telemetry disable[/cyan]\n"
        "  or set [cyan]MCPBUNDLES_TELEMETRY_DISABLED=1[/cyan]"
    )
    stdout_console.print(
        Panel(body, title="MCPBundles telemetry", border_style=status_color, padding=(1, 2))
    )


@telemetry_group.command("enable")
def telemetry_enable() -> None:
    """Enable crash and error reporting (default)."""
    cfg = load_config()
    cfg["telemetry"] = True
    save_config(cfg)
    render_success("Telemetry enabled.")
    if telemetry_disabled_by_env():
        stdout_console.print(
            "  [yellow]Note:[/yellow] MCPBUNDLES_TELEMETRY_DISABLED is set in this shell"
            " and still wins over the config. Unset it to actually enable."
        )


@telemetry_group.command("disable")
def telemetry_disable() -> None:
    """Disable crash and error reporting."""
    cfg = load_config()
    cfg["telemetry"] = False
    save_config(cfg)
    render_success("Telemetry disabled. The next mcpbundles invocation will not initialise Sentry.")
