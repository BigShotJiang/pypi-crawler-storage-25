"""Manage local MCP runtime connections."""

from __future__ import annotations

import asyncio
import json
import shutil
import socket
from datetime import datetime, timezone
from urllib.parse import quote, urlparse

import click
import httpx

from mcpbundles.args import ArgParseError, parse_tool_args
from mcpbundles.auth_resolve import resolve_auth
from mcpbundles.config import CLISettings
from mcpbundles.local_config import (
    get_or_create_runtime_key,
    load_local_connections,
    parse_command,
    remove_local_connection,
    serialize_connection,
    upsert_local_connection,
)
from mcpbundles.output import print_json, render_error, render_success, stdout_console


async def _read_jsonrpc_line(stream: asyncio.StreamReader, timeout_seconds: float) -> dict:
    while True:
        line = await asyncio.wait_for(stream.readline(), timeout=timeout_seconds)
        if not line:
            raise RuntimeError("MCP server closed stdout")
        stripped = line.strip()
        if not stripped:
            continue
        try:
            return json.loads(stripped)
        except json.JSONDecodeError:
            continue


async def _probe_stdio_mcp(command: list[str], timeout_seconds: float) -> dict:
    process = await asyncio.create_subprocess_exec(
        *command,
        stdin=asyncio.subprocess.PIPE,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.DEVNULL,
    )
    assert process.stdin is not None
    assert process.stdout is not None
    try:
        initialize = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "initialize",
            "params": {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "clientInfo": {"name": "mcpbundles-local-doctor", "version": "1.0.0"},
            },
        }
        process.stdin.write((json.dumps(initialize) + "\n").encode())
        await asyncio.wait_for(process.stdin.drain(), timeout=timeout_seconds)
        init_response = await _read_jsonrpc_line(process.stdout, timeout_seconds)
        if "error" in init_response:
            raise RuntimeError(str(init_response["error"]))

        initialized = {"jsonrpc": "2.0", "method": "notifications/initialized"}
        process.stdin.write((json.dumps(initialized) + "\n").encode())
        list_tools = {"jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": {}}
        process.stdin.write((json.dumps(list_tools) + "\n").encode())
        await asyncio.wait_for(process.stdin.drain(), timeout=timeout_seconds)
        tools_response = await _read_jsonrpc_line(process.stdout, timeout_seconds)
        if "error" in tools_response:
            raise RuntimeError(str(tools_response["error"]))
        result = tools_response.get("result") or {}
        tools = result.get("tools") or []
        tool_names = [
            str(tool.get("name"))
            for tool in tools
            if isinstance(tool, dict) and tool.get("name")
        ]
        return {
            "tool_count": len(tool_names),
            "tools": tool_names[:20],
        }
    finally:
        if process.returncode is None:
            process.terminate()
            try:
                await asyncio.wait_for(process.wait(), timeout=2.0)
            except asyncio.TimeoutError:
                process.kill()
                await process.wait()


def _doctor_command(connection: dict) -> dict:
    command = connection.get("command")
    if not command:
        return {
            "ok": False,
            "message": "Missing command",
        }
    executable = command[0]
    resolved = shutil.which(executable)
    if not resolved:
        return {
            "ok": False,
            "message": f"Executable not found: {executable}",
        }
    return {
        "ok": True,
        "message": f"Executable found: {resolved}",
    }


def _doctor_command_deep(connection: dict, timeout_seconds: float) -> dict:
    base = _doctor_command(connection)
    if not base["ok"]:
        return base
    command = connection.get("command")
    if not command:
        return base
    try:
        probe = asyncio.run(_probe_stdio_mcp(command, timeout_seconds))
    except Exception as exc:
        return {
            "ok": False,
            "message": f"MCP stdio handshake failed: {exc}",
        }
    return {
        "ok": True,
        "message": f"MCP stdio handshake ok: {probe['tool_count']} tools",
        "tools": probe["tools"],
        "tool_count": probe["tool_count"],
    }


def _doctor_http(connection: dict) -> dict:
    url = connection.get("url")
    if not url:
        return {
            "ok": False,
            "message": "Missing URL",
        }
    parsed = urlparse(url)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        return {
            "ok": False,
            "message": "URL must be http:// or https:// with a host",
        }
    port = parsed.port or (443 if parsed.scheme == "https" else 80)
    try:
        with socket.create_connection((parsed.hostname, port), timeout=1.5):
            pass
    except OSError as exc:
        return {
            "ok": False,
            "message": f"Cannot reach {parsed.hostname}:{port}: {exc}",
        }
    return {
        "ok": True,
        "message": f"Reachable: {parsed.hostname}:{port}",
    }


def _doctor_connection(connection: dict, *, deep: bool, timeout_seconds: float) -> dict:
    transport = connection["transport"]
    if transport in {"command", "stdio"}:
        check = (
            _doctor_command_deep(connection, timeout_seconds)
            if deep
            else _doctor_command(connection)
        )
    elif transport == "http":
        check = _doctor_http(connection)
    else:
        check = {
            "ok": False,
            "message": f"Unknown transport: {transport}",
        }
    return {
        **connection,
        "ok": check["ok"],
        "message": check["message"],
        **({"tools": check["tools"], "tool_count": check["tool_count"]} if "tools" in check else {}),
    }


@click.group(name="local")
def local_group() -> None:
    """Manage MCP servers that run on this machine."""
    pass


@local_group.command("add")
@click.argument("name")
@click.option("--display-name", default=None, help="Human-readable name")
@click.option(
    "--transport",
    type=click.Choice(["http", "stdio", "command"]),
    default=None,
    help="Local MCP transport",
)
@click.option("--command", "command_text", default=None, help="Command to launch the MCP server")
@click.option("--url", default=None, help="Local HTTP MCP endpoint")
def local_add(
    name: str,
    display_name: str | None,
    transport: str | None,
    command_text: str | None,
    url: str | None,
) -> None:
    """Add or update a local MCP connection."""
    resolved_transport = transport
    if resolved_transport is None:
        resolved_transport = "http" if url else "command"

    command = parse_command(command_text) if command_text else None
    try:
        connection = upsert_local_connection(
            name=name,
            display_name=display_name,
            transport=resolved_transport,
            command=command,
            url=url,
        )
    except ValueError as exc:
        render_error(str(exc))
        raise SystemExit(1) from exc

    render_success(f"Saved local MCP connection '{connection.name}'")


@local_group.command("install")
@click.argument("server_name")
@click.option("--name", default=None, help="Local connection name")
@click.option(
    "--install-option-index",
    "install_option_index",
    default=None,
    type=int,
    help="Install option index to install (0-based)",
)
@click.option(
    "--recipe-index",
    "recipe_index",
    default=None,
    type=int,
    help="Deprecated alias for --install-option-index",
)
@click.option("--as", "conn_name", default=None, help="Named connection to use")
def local_install(
    server_name: str,
    name: str | None,
    install_option_index: int | None,
    recipe_index: int | None,
    conn_name: str | None,
) -> None:
    """Install a catalog-backed local MCP server."""
    if install_option_index is not None and recipe_index is not None and install_option_index != recipe_index:
        render_error("Pass either --install-option-index or --recipe-index, not both")
        raise SystemExit(1)
    selected_index = install_option_index if install_option_index is not None else (recipe_index or 0)

    settings = CLISettings.resolve()
    auth = resolve_auth(settings, conn_name)
    is_api_key = auth.token.startswith("mb_")
    auth_header = f"ApiKey {auth.token}" if is_api_key else f"Bearer {auth.token}"
    response = httpx.get(
        f"{auth.url}/api/local-runtime/install-options/{quote(server_name, safe='')}",
        headers={"Authorization": auth_header},
        timeout=10.0,
    )
    if response.status_code == 404:
        # Older backends only expose the legacy alias.
        response = httpx.get(
            f"{auth.url}/api/local-runtime/install-recipes/{quote(server_name, safe='')}",
            headers={"Authorization": auth_header},
            timeout=10.0,
        )
    if response.status_code != 200:
        detail = response.text[:300]
        try:
            detail = response.json().get("detail", detail)
        except ValueError:
            pass
        render_error(f"Could not load local install options for '{server_name}': {detail}")
        raise SystemExit(1)

    payload = response.json()
    options = payload.get("install_options") or payload.get("recipes") or []
    if selected_index < 0 or selected_index >= len(options):
        render_error(f"Install option index {selected_index} is out of range")
        raise SystemExit(1)
    option = options[selected_index]
    command = option.get("command")
    if not isinstance(command, list) or not all(isinstance(part, str) for part in command):
        render_error("Selected install option does not include a valid command")
        raise SystemExit(1)
    connection_name = name or server_name.replace("/", "-").replace("@", "").strip("-")
    accepted_at = datetime.now(timezone.utc).isoformat()
    connection = upsert_local_connection(
        name=connection_name,
        display_name=option.get("title") or connection_name,
        transport="command",
        command=command,
        server_name=option.get("server_name") or server_name,
        provider_slug=option.get("provider_slug"),
        bundle_slug=option.get("bundle_slug"),
        install_option_id=option.get("id"),
        package_identifier=option.get("identifier"),
        package_registry_type=option.get("registry_type"),
        package_version=option.get("package_version") or option.get("version"),
        source_url=option.get("source_url"),
        terms_url=option.get("terms_url"),
        privacy_url=option.get("privacy_url"),
        consent_version=option.get("consent_version"),
        consent_accepted_at=accepted_at if option.get("consent_required", True) else None,
        command_digest_value=option.get("command_digest"),
        auto_update_enabled=bool(option.get("auto_update_default", True)),
    )
    render_success(f"Installed local MCP connection '{connection.name}' from catalog")
    if option.get("consent_required", True):
        click.echo("Consent accepted for local command execution and workspace tool invocation.")
    if option.get("auto_update_default", True):
        click.echo("Auto-update is ON for this local MCP server.")


@local_group.command("call")
@click.argument("connection_key")
@click.argument("tool_name")
@click.argument("args", nargs=-1)
@click.option("--as", "conn_name", default=None, help="Named connection to use")
@click.option("--timeout", "timeout_seconds", default=30.0, type=float, help="Execution timeout in seconds")
def local_call(
    connection_key: str,
    tool_name: str,
    args: tuple[str, ...],
    conn_name: str | None,
    timeout_seconds: float,
) -> None:
    """Call a tool on a local MCP server through MCPBundles Desktop."""
    if timeout_seconds <= 0 or timeout_seconds > 120:
        render_error("--timeout must be greater than 0 and no more than 120 seconds")
        raise SystemExit(1)
    try:
        arguments = parse_tool_args(args)
    except ArgParseError as exc:
        render_error(str(exc))
        raise SystemExit(1) from exc

    settings = CLISettings.resolve()
    auth = resolve_auth(settings, conn_name)
    is_api_key = auth.token.startswith("mb_")
    auth_header = f"ApiKey {auth.token}" if is_api_key else f"Bearer {auth.token}"
    url = (
        f"{auth.url}/api/local-runtime/connections/"
        f"{quote(connection_key, safe='')}/tools/{quote(tool_name, safe='')}/execute"
    )
    response = httpx.post(
        url,
        json={"arguments": arguments, "timeout_seconds": timeout_seconds},
        headers={"Authorization": auth_header},
        timeout=timeout_seconds + 5.0,
    )
    if response.status_code >= 400:
        detail = response.text[:500]
        try:
            parsed = response.json()
            detail = parsed.get("detail") or parsed.get("error_message") or detail
        except ValueError:
            pass
        render_error(f"Local MCP tool call failed: {detail}")
        raise SystemExit(1)
    print_json(response.json())


@local_group.command("list")
@click.option("--json", "as_json", is_flag=True, help="Output JSON")
def local_list(as_json: bool) -> None:
    """List configured local MCP connections."""
    connections = load_local_connections()
    serialized = [serialize_connection(connection) for connection in connections.values()]
    if as_json:
        print_json(serialized)
        return

    if not serialized:
        stdout_console.print("No local MCP connections configured.")
        return

    for connection in serialized:
        target = " ".join(connection["command"]) if connection.get("command") else connection.get("url")
        stdout_console.print(
            f"{connection['name']}  {connection['transport']}  {target or ''}"
        )


@local_group.command("doctor")
@click.option("--json", "as_json", is_flag=True, help="Output JSON")
@click.option("--deep", is_flag=True, help="Launch command-backed MCP servers and list tools")
@click.option("--timeout", "timeout_seconds", default=20.0, type=float, help="Per-step timeout for --deep")
def local_doctor(as_json: bool, deep: bool, timeout_seconds: float) -> None:
    """Diagnose local MCP runtime configuration."""
    runtime_key = get_or_create_runtime_key()
    connections = [serialize_connection(connection) for connection in load_local_connections().values()]
    results = [
        _doctor_connection(connection, deep=deep, timeout_seconds=timeout_seconds)
        for connection in connections
    ]
    ok = bool(connections) and all(result["ok"] for result in results)
    payload = {
        "ok": ok,
        "runtime_key": runtime_key,
        "connection_count": len(connections),
        "connections": results,
    }
    if as_json:
        print_json(payload)
    else:
        click.echo(f"Runtime key: {runtime_key}")
        if not connections:
            click.echo("No local MCP connections configured.")
        for result in results:
            marker = "OK" if result["ok"] else "FAIL"
            click.echo(f"{marker} {result['name']} ({result['transport']}): {result['message']}")
            if result.get("tools"):
                click.echo(f"  Tools: {', '.join(result['tools'][:10])}")
    if not ok:
        raise SystemExit(1)


@local_group.command("remove")
@click.argument("name")
def local_remove(name: str) -> None:
    """Remove a configured local MCP connection."""
    if not remove_local_connection(name):
        render_error(f"Local MCP connection '{name}' was not found")
        raise SystemExit(1)
    render_success(f"Removed local MCP connection '{name}'")


__all__ = ["local_group"]
