"""Machine readiness probes for optional proxy features.

Used by ``mcpbundles internal capabilities`` (desktop Settings) and
summarised on the local-runtime heartbeat so the backend can see whether
this machine can run Local Browser or Claude Code tunnel services.
"""

from __future__ import annotations

import os
import platform
import shutil
import sys
import time
import importlib.util
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from mcpbundles.services.browser import _missing_playwright_message
from mcpbundles.services.claude_code import find_claude_cli

_CAPABILITIES_CACHE: tuple[float, dict[str, Any]] | None = None
_CAPABILITIES_CACHE_TTL_S = 300.0


def _chrome_candidate_paths() -> list[Path]:
    system = platform.system()
    if system == "Darwin":
        return [
            Path("/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"),
            Path.home() / "Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            Path("/Applications/Google Chrome Canary.app/Contents/MacOS/Google Chrome Canary"),
        ]
    if system == "Windows":
        local_app_data = os.environ.get("LOCALAPPDATA", "")
        program_files = os.environ.get("ProgramFiles", r"C:\Program Files")
        program_files_x86 = os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")
        return [
            Path(program_files) / "Google/Chrome/Application/chrome.exe",
            Path(program_files_x86) / "Google/Chrome/Application/chrome.exe",
            Path(local_app_data) / "Google/Chrome/Application/chrome.exe",
        ]
    return [
        Path("/usr/bin/google-chrome"),
        Path("/usr/bin/google-chrome-stable"),
        Path("/usr/bin/chromium-browser"),
        Path("/usr/bin/chromium"),
    ]


def probe_playwright() -> dict[str, Any]:
    """Return Playwright import + driver bundle status for this interpreter."""
    frozen = bool(getattr(sys, "frozen", False))
    try:
        spec = importlib.util.find_spec("playwright")
    except (ValueError, ModuleNotFoundError):
        spec = None
    if spec is None or not spec.origin:
        return {
            "status": "playwright_missing",
            "frozen": frozen,
            "error": "playwright module not installed",
            "remediation": _missing_playwright_message(),
        }
    try:
        import playwright  # type: ignore

        playwright_version = "unknown"
        try:
            from importlib.metadata import PackageNotFoundError, version as pkg_version

            try:
                playwright_version = pkg_version("playwright")
            except PackageNotFoundError:
                playwright_version = getattr(playwright, "__version__", "unknown")
        except ImportError:
            playwright_version = getattr(playwright, "__version__", "unknown")

        driver_dir = Path(spec.origin).resolve().parent / "driver"
        driver_present = driver_dir.exists()
        if not driver_present:
            remediation = (
                "Update MCPBundles Desktop to the latest release. "
                "This build is missing the bundled browser driver."
                if frozen
                else (
                    "Install browser support with: pip install 'mcpbundles[browser]' "
                    "(or pipx inject mcpbundles 'mcpbundles[browser]')."
                )
            )
            return {
                "status": "driver_missing",
                "frozen": frozen,
                "playwright_version": playwright_version,
                "driver_dir": str(driver_dir),
                "remediation": remediation,
            }
        return {
            "status": "ok",
            "frozen": frozen,
            "playwright_version": playwright_version,
            "driver_dir": str(driver_dir),
            "driver_present": True,
            "remediation": None,
        }
    except ImportError as exc:
        return {
            "status": "playwright_missing",
            "frozen": frozen,
            "error": str(exc),
            "remediation": _missing_playwright_message(),
        }


def probe_chrome() -> dict[str, Any]:
    """Return whether Google Chrome (stable channel) appears installed."""
    for candidate in _chrome_candidate_paths():
        if candidate.exists():
            return {
                "status": "ready",
                "path": str(candidate),
                "remediation": None,
            }

    for command in ("google-chrome", "google-chrome-stable", "chrome", "chromium", "chromium-browser"):
        resolved = shutil.which(command)
        if resolved:
            return {
                "status": "ready",
                "path": resolved,
                "remediation": None,
            }

    system = platform.system()
    if system == "Darwin":
        remediation = (
            "Install Google Chrome, then reopen MCPBundles Desktop. "
            "Local Browser connects to Chrome on this Mac."
        )
    elif system == "Windows":
        remediation = (
            "Install Google Chrome, then reopen MCPBundles Desktop. "
            "Local Browser connects to Chrome on this PC."
        )
    else:
        remediation = (
            "Install Google Chrome or Chromium, then reopen MCPBundles Desktop."
        )
    return {
        "status": "chrome_missing",
        "path": None,
        "remediation": remediation,
    }


def probe_local_browser() -> dict[str, Any]:
    """Aggregate Local Browser readiness (Playwright + Chrome stable)."""
    playwright = probe_playwright()
    if playwright["status"] != "ok":
        return {
            "status": playwright["status"],
            "playwright": playwright,
            "chrome": None,
            "remediation": playwright.get("remediation"),
        }

    chrome = probe_chrome()
    if chrome["status"] != "ready":
        return {
            "status": "chrome_missing",
            "playwright": playwright,
            "chrome": chrome,
            "remediation": chrome.get("remediation"),
        }

    return {
        "status": "ready",
        "playwright": playwright,
        "chrome": chrome,
        "remediation": None,
    }


def probe_claude_code() -> dict[str, Any]:
    """Return Claude Code CLI discovery status."""
    try:
        cli_path = find_claude_cli()
        return {
            "status": "ready",
            "path": cli_path,
            "remediation": None,
        }
    except ValueError:
        return {
            "status": "cli_missing",
            "path": None,
            "remediation": (
                "Install Claude Code CLI: npm install -g @anthropic-ai/claude-cli. "
                "Then open a new terminal so MCPBundles Desktop can find it."
            ),
        }


def _sidecar_version() -> str:
    try:
        from importlib.metadata import version

        return version("mcpbundles")
    except Exception:
        return "unknown"


def build_machine_capabilities(*, force: bool = False) -> dict[str, Any]:
    """Full machine readiness report for desktop Settings and diagnostics."""
    global _CAPABILITIES_CACHE
    now = time.monotonic()
    if (
        not force
        and _CAPABILITIES_CACHE is not None
        and now - _CAPABILITIES_CACHE[0] < _CAPABILITIES_CACHE_TTL_S
    ):
        return _CAPABILITIES_CACHE[1]

    report: dict[str, Any] = {
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "platform": platform.system().lower(),
        "sidecar": {
            "frozen": bool(getattr(sys, "frozen", False)),
            "version": _sidecar_version(),
            "executable": sys.executable,
        },
        "local_browser": probe_local_browser(),
        "claude_code": probe_claude_code(),
    }
    _CAPABILITIES_CACHE = (now, report)
    return report


def build_machine_capabilities_summary(*, force: bool = False) -> dict[str, str]:
    """Compact readiness flags for heartbeat payloads."""
    report = build_machine_capabilities(force=force)
    local_browser = report.get("local_browser") or {}
    claude_code = report.get("claude_code") or {}
    return {
        "local_browser": str(local_browser.get("status") or "unknown"),
        "claude_code": str(claude_code.get("status") or "unknown"),
    }
