"""Tests for machine readiness probes."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

import pytest

from mcpbundles.capabilities import (
    build_machine_capabilities,
    build_machine_capabilities_summary,
    probe_chrome,
    probe_claude_code,
    probe_local_browser,
    probe_playwright,
)


def test_probe_playwright_reports_structure() -> None:
    result = probe_playwright()
    assert result["status"] in {"ok", "playwright_missing", "driver_missing"}
    assert "frozen" in result
    if result["status"] == "ok":
        assert result["driver_present"] is True
        assert result.get("playwright_version")


def test_probe_chrome_missing_when_no_candidates(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(
        "mcpbundles.capabilities._chrome_candidate_paths",
        lambda: [Path("/nonexistent/chrome")],
    )
    monkeypatch.setattr("mcpbundles.capabilities.shutil.which", lambda _name: None)
    result = probe_chrome()
    assert result["status"] == "chrome_missing"
    assert result["remediation"]


def test_probe_chrome_ready_when_candidate_exists(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    chrome = tmp_path / "Google Chrome"
    chrome.mkdir()
    monkeypatch.setattr(
        "mcpbundles.capabilities._chrome_candidate_paths",
        lambda: [chrome],
    )
    result = probe_chrome()
    assert result["status"] == "ready"
    assert result["path"] == str(chrome)


def test_probe_claude_code_missing(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(
        "mcpbundles.capabilities.find_claude_cli",
        lambda: (_ for _ in ()).throw(ValueError("missing")),
    )
    result = probe_claude_code()
    assert result["status"] == "cli_missing"
    assert "npm install" in (result.get("remediation") or "")


def test_probe_claude_code_ready(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(
        "mcpbundles.capabilities.find_claude_cli",
        lambda: "/opt/homebrew/bin/claude",
    )
    result = probe_claude_code()
    assert result["status"] == "ready"
    assert result["path"] == "/opt/homebrew/bin/claude"


def test_probe_local_browser_ready_when_playwright_and_chrome_ok(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(
        "mcpbundles.capabilities.probe_playwright",
        lambda: {"status": "ok", "playwright_version": "1.49.0"},
    )
    monkeypatch.setattr(
        "mcpbundles.capabilities.probe_chrome",
        lambda: {"status": "ready", "path": "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"},
    )
    result = probe_local_browser()
    assert result["status"] == "ready"
    assert result["remediation"] is None


def test_probe_local_browser_chrome_missing_when_playwright_ok(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(
        "mcpbundles.capabilities.probe_playwright",
        lambda: {"status": "ok"},
    )
    monkeypatch.setattr(
        "mcpbundles.capabilities.probe_chrome",
        lambda: {"status": "chrome_missing", "remediation": "Install Chrome"},
    )
    result = probe_local_browser()
    assert result["status"] == "chrome_missing"
    assert result["remediation"] == "Install Chrome"


def test_build_machine_capabilities_has_expected_keys() -> None:
    report = build_machine_capabilities(force=True)
    assert "checked_at" in report
    assert "sidecar" in report
    assert "local_browser" in report
    assert "claude_code" in report
    assert report["local_browser"]["status"] in {
        "ready",
        "playwright_missing",
        "driver_missing",
        "chrome_missing",
    }


def test_build_machine_capabilities_summary() -> None:
    with patch(
        "mcpbundles.capabilities.build_machine_capabilities",
        return_value={
            "local_browser": {"status": "ready"},
            "claude_code": {"status": "cli_missing"},
        },
    ):
        summary = build_machine_capabilities_summary(force=True)
    assert summary == {"local_browser": "ready", "claude_code": "cli_missing"}
