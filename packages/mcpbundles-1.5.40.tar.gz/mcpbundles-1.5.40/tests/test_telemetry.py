"""Tests for CLI telemetry resolution + opt-out gates.

These tests exercise the resolution helpers directly rather than
trying to fake out ``sentry_sdk``. The SDK is installed as a real
dependency and silently swallows bad DSNs, so we use a well-shaped
fake DSN and assert behaviour through the public helpers.
"""

from __future__ import annotations

import importlib

import pytest


_FAKE_DSN_A = "https://aaa111@example-sentry.invalid/1"
_FAKE_DSN_B = "https://bbb222@example-sentry.invalid/2"


def _reload_sentry_setup(monkeypatch, *, baked_dsn: str = ""):
    """Reload mcpbundles.sentry_setup with a controlled baked DSN."""
    import mcpbundles._sentry_baked as baked_mod
    import mcpbundles.sentry_setup as sentry_setup

    monkeypatch.setattr(baked_mod, "BAKED_DSN", baked_dsn, raising=False)
    importlib.reload(sentry_setup)
    return sentry_setup


def test_env_disable_blocks_init(monkeypatch, temp_config_dir):
    monkeypatch.setenv("MCPBUNDLES_TELEMETRY_DISABLED", "1")
    monkeypatch.setenv("MCPBUNDLES_SENTRY_DSN", _FAKE_DSN_A)
    sentry_setup = _reload_sentry_setup(monkeypatch, baked_dsn=_FAKE_DSN_B)

    assert sentry_setup.telemetry_disabled_by_env() is True
    assert sentry_setup.init_sentry() is False
    assert sentry_setup.is_initialized() is False


def test_config_disable_blocks_init(monkeypatch, temp_config_dir):
    from mcpbundles.config import save_config

    save_config({"telemetry": False})
    monkeypatch.delenv("MCPBUNDLES_TELEMETRY_DISABLED", raising=False)
    monkeypatch.setenv("MCPBUNDLES_SENTRY_DSN", _FAKE_DSN_A)

    sentry_setup = _reload_sentry_setup(monkeypatch, baked_dsn=_FAKE_DSN_B)

    assert sentry_setup.telemetry_enabled_in_config() is False
    assert sentry_setup.init_sentry() is False
    assert sentry_setup.is_initialized() is False


def test_env_dsn_wins_over_baked(monkeypatch, temp_config_dir):
    monkeypatch.delenv("MCPBUNDLES_TELEMETRY_DISABLED", raising=False)
    monkeypatch.setenv("MCPBUNDLES_SENTRY_DSN", _FAKE_DSN_A)
    sentry_setup = _reload_sentry_setup(monkeypatch, baked_dsn=_FAKE_DSN_B)

    assert sentry_setup.resolved_dsn() == _FAKE_DSN_A


def test_baked_dsn_used_when_env_missing(monkeypatch, temp_config_dir):
    monkeypatch.delenv("MCPBUNDLES_TELEMETRY_DISABLED", raising=False)
    monkeypatch.delenv("MCPBUNDLES_SENTRY_DSN", raising=False)
    sentry_setup = _reload_sentry_setup(monkeypatch, baked_dsn=_FAKE_DSN_B)

    assert sentry_setup.resolved_dsn() == _FAKE_DSN_B


def test_no_dsn_no_init(monkeypatch, temp_config_dir):
    monkeypatch.delenv("MCPBUNDLES_TELEMETRY_DISABLED", raising=False)
    monkeypatch.delenv("MCPBUNDLES_SENTRY_DSN", raising=False)
    sentry_setup = _reload_sentry_setup(monkeypatch, baked_dsn="")

    assert sentry_setup.resolved_dsn() == ""
    assert sentry_setup.init_sentry() is False
    assert sentry_setup.is_initialized() is False


def test_init_is_idempotent(monkeypatch, temp_config_dir):
    monkeypatch.delenv("MCPBUNDLES_TELEMETRY_DISABLED", raising=False)
    monkeypatch.setenv("MCPBUNDLES_SENTRY_DSN", _FAKE_DSN_A)
    sentry_setup = _reload_sentry_setup(monkeypatch, baked_dsn="")

    first = sentry_setup.init_sentry()
    second = sentry_setup.init_sentry()
    # First may be True or False depending on whether sentry_sdk
    # accepts the fake DSN — the contract we care about is that the
    # second call mirrors the first (idempotent).
    assert first == second
    if first:
        assert sentry_setup.is_initialized() is True


def test_install_source_classification(monkeypatch, temp_config_dir):
    sentry_setup = _reload_sentry_setup(monkeypatch, baked_dsn=_FAKE_DSN_A)

    monkeypatch.setattr(sentry_setup.sys, "frozen", False, raising=False)
    assert sentry_setup._install_source() == "wheel"

    sentry_setup = _reload_sentry_setup(monkeypatch, baked_dsn="")
    monkeypatch.setattr(sentry_setup.sys, "frozen", False, raising=False)
    assert sentry_setup._install_source() == "source"

    sentry_setup = _reload_sentry_setup(monkeypatch, baked_dsn="")
    monkeypatch.setattr(sentry_setup.sys, "frozen", True, raising=False)
    assert sentry_setup._install_source() == "pyinstaller"


def test_telemetry_cmd_disable_persists(monkeypatch, temp_config_dir):
    from click.testing import CliRunner

    from mcpbundles.commands.telemetry_cmd import telemetry_group
    from mcpbundles.config import load_config

    runner = CliRunner()
    result = runner.invoke(telemetry_group, ["disable"])
    assert result.exit_code == 0
    assert load_config()["telemetry"] is False

    result = runner.invoke(telemetry_group, ["enable"])
    assert result.exit_code == 0
    assert load_config()["telemetry"] is True


def test_telemetry_status_runs(monkeypatch, temp_config_dir):
    from click.testing import CliRunner

    from mcpbundles.commands.telemetry_cmd import telemetry_group

    # `stdout_console.print` writes via Rich directly to sys.stdout
    # which click's CliRunner does not buffer into `result.output`.
    # Exit-code zero is sufficient to prove the command rendered
    # without raising.
    runner = CliRunner()
    result = runner.invoke(telemetry_group, ["status"])
    assert result.exit_code == 0, result.exception


def test_before_send_scrubs_secret_keys():
    import mcpbundles.sentry_setup as sentry_setup

    event = {
        "extra": {
            "access_token": "secret-value",
            "request": {"authorization": "Bearer x", "url": "/api"},
            "notes": ["fine"],
        }
    }
    scrubbed = sentry_setup._before_send(event, {})
    assert scrubbed is not None
    assert scrubbed["extra"]["access_token"] == sentry_setup._REDACTED
    assert scrubbed["extra"]["request"]["authorization"] == sentry_setup._REDACTED
    assert scrubbed["extra"]["request"]["url"] == "/api"
    assert scrubbed["extra"]["notes"] == ["fine"]


def test_before_send_drops_known_409_noise():
    import mcpbundles.sentry_setup as sentry_setup

    event = {"message": "Expose registration failed: HTTP 409"}
    assert sentry_setup._before_send(event, {}) is None
