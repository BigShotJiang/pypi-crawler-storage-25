"""Tests for the unsigned sidecar update manifest builder.

Trust integrity now flows through TLS (manifest is fetched from our
own origin) + sha256 (downloader hashes streamed bytes) + OS code
signing on the binary (``codesign`` / ``Get-AuthenticodeSignature``),
so the test surface here is pure metadata: targets resolve to the
right S3 prefix, hashes/sizes match disk, the released_at stamp is
ISO-with-Z, and the JSON encoder is deterministic.
"""

from __future__ import annotations

import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

import pytest

_ROOT = Path(__file__).resolve().parents[1]
if str(_ROOT / "scripts") not in sys.path:
    sys.path.insert(0, str(_ROOT / "scripts"))

import build_sidecar_manifest as _manifest

DEFAULT_FRONTEND_BASE_URL = _manifest.DEFAULT_FRONTEND_BASE_URL
SCHEMA_VERSION = _manifest.SCHEMA_VERSION
SUPPORTED_TARGETS = _manifest.SUPPORTED_TARGETS
TargetInput = _manifest.TargetInput
build_payload = _manifest.build_payload
stable_json = _manifest.stable_json
target_url = _manifest.target_url


@pytest.fixture()
def sidecar_zips(tmp_path: Path) -> list[TargetInput]:
    out: list[TargetInput] = []
    for target in SUPPORTED_TARGETS:
        path = tmp_path / f"mcpbundles-sidecar-{target}.zip"
        path.write_bytes(f"fake-{target}-payload".encode())
        out.append(TargetInput(target=target, path=path))
    return out


def test_target_url_points_at_frontend_proxy_under_new_prefix() -> None:
    url = target_url(DEFAULT_FRONTEND_BASE_URL, "stable", "1.5.36", "win-x64")
    assert url == (
        "https://www.mcpbundles.com/api/sidecar-update/stable/1.5.36/"
        "mcpbundles-sidecar-win-x64.zip"
    )


def test_build_payload_hashes_and_sizes_match_disk(
    sidecar_zips: list[TargetInput],
) -> None:
    released_at = datetime(2026, 5, 22, 15, 0, 0, tzinfo=timezone.utc)
    payload = build_payload(
        version="1.5.36",
        channel="stable",
        min_shell_version="0.1.7-preview",
        protocol_version=3,
        targets=sidecar_zips,
        released_at=released_at,
    )

    assert payload["schema"] == SCHEMA_VERSION
    assert payload["channel"] == "stable"
    assert payload["version"] == "1.5.36"
    assert payload["released_at"] == "2026-05-22T15:00:00Z"
    assert payload["protocol_version"] == 3

    for entry in sidecar_zips:
        block = payload["targets"][entry.target]
        digest = hashlib.sha256(entry.path.read_bytes()).hexdigest()
        assert block["sha256"] == digest
        assert block["size"] == entry.path.stat().st_size
        assert block["url"].startswith(
            f"https://www.mcpbundles.com/api/sidecar-update/stable/1.5.36/"
        )


def test_build_payload_rejects_bad_channel(sidecar_zips: list[TargetInput]) -> None:
    with pytest.raises(ValueError, match="unsupported channel"):
        build_payload(
            version="1.5.36",
            channel="alpha",  # type: ignore[arg-type]
            min_shell_version="0.1.7-preview",
            protocol_version=3,
            targets=sidecar_zips,
        )


def test_target_input_rejects_unknown_target(tmp_path: Path) -> None:
    bogus = tmp_path / "x.zip"
    bogus.write_bytes(b"x")
    with pytest.raises(ValueError, match="Unsupported target"):
        TargetInput(target="linux-arm64", path=bogus)


def test_target_input_rejects_missing_zip(tmp_path: Path) -> None:
    with pytest.raises(FileNotFoundError):
        TargetInput(target="win-x64", path=tmp_path / "missing.zip")


def test_stable_json_is_deterministic(sidecar_zips: list[TargetInput]) -> None:
    released_at = datetime(2026, 5, 22, 15, 0, 0, tzinfo=timezone.utc)
    payload = build_payload(
        version="1.5.36",
        channel="stable",
        min_shell_version="0.1.7-preview",
        protocol_version=3,
        targets=sidecar_zips,
        released_at=released_at,
    )
    a = stable_json(payload)
    b = stable_json(payload)
    assert a == b
    assert json.loads(a) == payload
    # Sorted keys: ``channel`` must appear before ``min_shell_version``.
    assert a.find(b'"channel"') < a.find(b'"min_shell_version"')
