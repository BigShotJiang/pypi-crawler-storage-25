"""Test local MCP runtime CLI commands."""

from click.testing import CliRunner
from unittest.mock import AsyncMock, MagicMock, patch

from mcpbundles.cli import cli


def test_local_add_command_connection(tmp_path, monkeypatch):
    local_file = tmp_path / "local_connections.json"
    monkeypatch.setattr("mcpbundles.local_config.LOCAL_CONNECTIONS_FILE", local_file)

    result = CliRunner().invoke(
        cli,
        [
            "local",
            "add",
            "aws-docs",
            "--display-name",
            "AWS Docs",
            "--command",
            "uvx mcp-proxy-for-aws",
        ],
    )

    assert result.exit_code == 0
    assert "Saved local MCP connection 'aws-docs'" in result.output
    assert local_file.exists()


def test_local_list_json(tmp_path, monkeypatch):
    local_file = tmp_path / "local_connections.json"
    monkeypatch.setattr("mcpbundles.local_config.LOCAL_CONNECTIONS_FILE", local_file)

    runner = CliRunner()
    runner.invoke(cli, ["local", "add", "stripe", "--url", "http://localhost:3001/mcp"])
    result = runner.invoke(cli, ["local", "list", "--json"])

    assert result.exit_code == 0
    assert '"name": "stripe"' in result.output
    assert '"transport": "http"' in result.output


def test_local_add_rejects_command_and_url(tmp_path, monkeypatch):
    local_file = tmp_path / "local_connections.json"
    monkeypatch.setattr("mcpbundles.local_config.LOCAL_CONNECTIONS_FILE", local_file)

    result = CliRunner().invoke(
        cli,
        [
            "local",
            "add",
            "bad",
            "--command",
            "npx server",
            "--url",
            "http://localhost:3001/mcp",
        ],
    )

    assert result.exit_code == 1
    assert "Use either --command or --url, not both" in result.output


def test_local_install_fetches_catalog_install_option(tmp_path, monkeypatch):
    local_file = tmp_path / "local_connections.json"
    monkeypatch.setattr("mcpbundles.local_config.LOCAL_CONNECTIONS_FILE", local_file)
    auth = MagicMock(token="mb_test", url="https://mcp.mcpbundles.com")
    response = MagicMock(status_code=200)
    response.json.return_value = {
        "install_options": [
            {
                "id": "aws-docs:npm",
                "title": "AWS Docs",
                "transport": "command",
                "command": ["uvx", "mcp-proxy-for-aws"],
                "server_name": "aws/docs",
                "provider_slug": "aws-docs",
                "bundle_slug": "aws-docs",
                "registry_type": "npm",
                "identifier": "@aws/docs",
                "source_url": "https://www.npmjs.com/package/@aws/docs",
                "consent_version": "2026-05-10",
                "consent_required": True,
                "auto_update_default": True,
            }
        ]
    }

    with patch("mcpbundles.commands.local_cmd.resolve_auth", return_value=auth), \
         patch("mcpbundles.commands.local_cmd.httpx.get", return_value=response) as mock_get:
        result = CliRunner().invoke(
            cli,
            ["local", "install", "aws/docs", "--name", "aws-docs", "--as", "prod"],
        )

    assert result.exit_code == 0
    assert "Installed local MCP connection 'aws-docs' from catalog" in result.output
    assert "Consent accepted" in result.output
    assert "Auto-update is ON" in result.output
    mock_get.assert_called_once()
    assert local_file.exists()
    assert '"server_name": "aws/docs"' in local_file.read_text()
    assert '"provider_slug": "aws-docs"' in local_file.read_text()
    assert '"install_option_id": "aws-docs:npm"' in local_file.read_text()
    assert '"auto_update_enabled": true' in local_file.read_text()


def test_local_install_reports_backend_detail(tmp_path, monkeypatch):
    local_file = tmp_path / "local_connections.json"
    monkeypatch.setattr("mcpbundles.local_config.LOCAL_CONNECTIONS_FILE", local_file)
    auth = MagicMock(token="mb_test", url="https://mcp.mcpbundles.com")
    response = MagicMock(status_code=404, text='{"detail":"No local install options found"}')
    response.json.return_value = {"detail": "No local install options found"}

    with patch("mcpbundles.commands.local_cmd.resolve_auth", return_value=auth), \
         patch("mcpbundles.commands.local_cmd.httpx.get", return_value=response):
        result = CliRunner().invoke(cli, ["local", "install", "missing/server"])

    assert result.exit_code == 1
    assert "No local install options found" in " ".join(result.output.split())


def test_local_call_posts_to_runtime_execute(monkeypatch):
    auth = MagicMock(token="mb_test", url="http://localhost:8000")
    response = MagicMock(status_code=200)
    response.json.return_value = {"success": True, "content_text": "ok"}

    with patch("mcpbundles.commands.local_cmd.resolve_auth", return_value=auth), \
         patch("mcpbundles.commands.local_cmd.httpx.post", return_value=response) as mock_post:
        result = CliRunner().invoke(
            cli,
            [
                "local",
                "call",
                "smoke-memory",
                "read_graph",
                "--as",
                "local",
            ],
        )

    assert result.exit_code == 0
    mock_post.assert_called_once()
    assert mock_post.call_args.kwargs["json"] == {"arguments": {}, "timeout_seconds": 30.0}
    assert "content_text" in result.output


def test_local_doctor_validates_command_connection(tmp_path, monkeypatch):
    local_file = tmp_path / "local_connections.json"
    runtime_key_file = tmp_path / "runtime_key"
    monkeypatch.setattr("mcpbundles.local_config.LOCAL_CONNECTIONS_FILE", local_file)
    monkeypatch.setattr("mcpbundles.local_config.RUNTIME_KEY_FILE", runtime_key_file)

    runner = CliRunner()
    runner.invoke(cli, ["local", "add", "memory", "--command", "npx -y @modelcontextprotocol/server-memory"])
    with patch("mcpbundles.commands.local_cmd.shutil.which", return_value="/usr/local/bin/npx"):
        result = runner.invoke(cli, ["local", "doctor", "--json"])

    assert result.exit_code == 0
    assert '"ok": true' in result.output
    assert '"connection_count": 1' in result.output
    assert "Executable found: /usr/local/bin/npx" in result.output


def test_local_doctor_deep_lists_mcp_tools(tmp_path, monkeypatch):
    local_file = tmp_path / "local_connections.json"
    runtime_key_file = tmp_path / "runtime_key"
    monkeypatch.setattr("mcpbundles.local_config.LOCAL_CONNECTIONS_FILE", local_file)
    monkeypatch.setattr("mcpbundles.local_config.RUNTIME_KEY_FILE", runtime_key_file)

    runner = CliRunner()
    runner.invoke(cli, ["local", "add", "memory", "--command", "npx -y @modelcontextprotocol/server-memory"])
    with patch("mcpbundles.commands.local_cmd.shutil.which", return_value="/usr/local/bin/npx"), \
         patch(
             "mcpbundles.commands.local_cmd._probe_stdio_mcp",
             new=AsyncMock(return_value={"tool_count": 2, "tools": ["read_graph", "search_nodes"]}),
         ):
        result = runner.invoke(cli, ["local", "doctor", "--deep", "--json"])

    assert result.exit_code == 0
    assert '"tool_count": 2' in result.output
    assert '"read_graph"' in result.output


def test_local_doctor_fails_missing_executable(tmp_path, monkeypatch):
    local_file = tmp_path / "local_connections.json"
    runtime_key_file = tmp_path / "runtime_key"
    monkeypatch.setattr("mcpbundles.local_config.LOCAL_CONNECTIONS_FILE", local_file)
    monkeypatch.setattr("mcpbundles.local_config.RUNTIME_KEY_FILE", runtime_key_file)

    runner = CliRunner()
    runner.invoke(cli, ["local", "add", "bad", "--command", "missing-bin server"])
    with patch("mcpbundles.commands.local_cmd.shutil.which", return_value=None):
        result = runner.invoke(cli, ["local", "doctor"])

    assert result.exit_code == 1
    assert "FAIL bad (command): Executable not found: missing-bin" in result.output


def test_local_doctor_fails_without_connections(tmp_path, monkeypatch):
    monkeypatch.setattr("mcpbundles.local_config.LOCAL_CONNECTIONS_FILE", tmp_path / "local_connections.json")
    monkeypatch.setattr("mcpbundles.local_config.RUNTIME_KEY_FILE", tmp_path / "runtime_key")

    result = CliRunner().invoke(cli, ["local", "doctor"])

    assert result.exit_code == 1
    assert "No local MCP connections configured." in result.output
