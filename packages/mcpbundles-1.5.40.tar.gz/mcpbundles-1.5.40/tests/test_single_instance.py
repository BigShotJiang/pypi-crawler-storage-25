"""Tests for the proxy singleton lock."""

from __future__ import annotations

import multiprocessing as mp
import os
import sys
import time
from pathlib import Path

import pytest

from mcpbundles import single_instance
from mcpbundles.single_instance import (
    AlreadyRunning,
    acquire_singleton_lock,
    release_singleton_lock,
    try_acquire_then_release,
)


@pytest.fixture(autouse=True)
def _reset_module_state():
    """Each test starts with no held lock in this process."""
    release_singleton_lock()
    yield
    release_singleton_lock()


def test_acquire_records_pid(tmp_path: Path) -> None:
    lock_path = tmp_path / "tunnel.lock"
    fd = acquire_singleton_lock(lock_path)
    assert isinstance(fd, int)
    assert lock_path.exists()
    assert lock_path.read_text().strip() == str(os.getpid())


def test_acquire_is_idempotent_in_same_process(tmp_path: Path) -> None:
    lock_path = tmp_path / "tunnel.lock"
    fd_first = acquire_singleton_lock(lock_path)
    fd_second = acquire_singleton_lock(lock_path)
    assert fd_first == fd_second


def test_release_lets_another_process_acquire(tmp_path: Path) -> None:
    lock_path = tmp_path / "tunnel.lock"
    acquire_singleton_lock(lock_path)
    release_singleton_lock()
    # Should be re-acquirable after release.
    acquire_singleton_lock(lock_path)


def test_try_acquire_then_release_when_free(tmp_path: Path) -> None:
    lock_path = tmp_path / "tunnel.lock"
    assert try_acquire_then_release(lock_path) is True
    # Should be free again afterward.
    acquire_singleton_lock(lock_path)


def _hold_lock_then_signal(lock_path_str: str, ready_path_str: str, hold_seconds: float) -> None:
    """Child entry point: acquire the lock, signal readiness, sleep."""
    # Fresh module state in the child process.
    lock_path = Path(lock_path_str)
    acquire_singleton_lock(lock_path)
    Path(ready_path_str).write_text("ready")
    time.sleep(hold_seconds)


@pytest.mark.skipif(sys.platform == "win32", reason="fork-based test is POSIX-only")
def test_second_process_cannot_acquire_while_first_holds(tmp_path: Path) -> None:
    lock_path = tmp_path / "tunnel.lock"
    ready_path = tmp_path / "ready"

    ctx = mp.get_context("fork")
    child = ctx.Process(
        target=_hold_lock_then_signal,
        args=(str(lock_path), str(ready_path), 2.0),
    )
    child.start()
    try:
        # Wait for the child to actually hold the lock.
        deadline = time.time() + 5.0
        while not ready_path.exists() and time.time() < deadline:
            time.sleep(0.02)
        assert ready_path.exists(), "child failed to acquire lock"

        # Our process must not be able to acquire.
        with pytest.raises(AlreadyRunning) as excinfo:
            acquire_singleton_lock(lock_path)
        assert excinfo.value.holder_pid == child.pid

        # And the pre-flight helper must agree.
        assert try_acquire_then_release(lock_path) is False
    finally:
        child.join(timeout=5.0)
        if child.is_alive():
            child.terminate()
            child.join(timeout=2.0)

    # Once the child exits, the OS releases its flock and we can take it.
    acquire_singleton_lock(lock_path)


def test_already_running_message_includes_pid(tmp_path: Path) -> None:
    lock_path = tmp_path / "tunnel.lock"
    exc = AlreadyRunning(lock_path, holder_pid=4242)
    assert "4242" in str(exc)
    assert str(lock_path) in str(exc)
