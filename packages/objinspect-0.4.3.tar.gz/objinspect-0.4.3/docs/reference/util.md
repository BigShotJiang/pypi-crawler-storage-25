::: objinspect.util
