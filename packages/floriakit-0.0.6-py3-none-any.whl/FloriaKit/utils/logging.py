import typing as t
import logging


_logger_level_ann = t.Literal[
    'debug',
    'info',
    'warning',
    'error',
    'critical',
]

_logger_level_map: dict[_logger_level_ann, int] = {
    'debug': logging.DEBUG,
    'info': logging.INFO,
    'warning': logging.WARNING,
    'error': logging.ERROR,
    'critical': logging.CRITICAL,
}


def create(
    name: str,
    level: int | _logger_level_ann,
    terminal_format: logging.Formatter | str | None = None,
) -> logging.Logger:
    level_int = _logger_level_map[level] if isinstance(level, str) else level

    logger = logging.Logger(name, level_int)

    terminal_handler = logging.StreamHandler()
    terminal_handler.setLevel(level_int)
    if terminal_format is not None:
        terminal_handler.setFormatter(
            terminal_format
            if isinstance(terminal_format, logging.Formatter)
            else logging.Formatter(terminal_format)
        )

    logger.addHandler(terminal_handler)

    return logger
