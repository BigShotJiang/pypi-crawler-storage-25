import typing as t
from pyglm import glm
import functools


if t.TYPE_CHECKING:
    from .. import hints, protocols


def lerp[T: 'hints.vec2 | hints.vec3 | hints.vec4'](
    start: T,
    end: T,
    progress: float,
) -> T:
    return glm.lerp(
        start,
        end,
        progress,
    ).to_tuple()  # pyright: ignore[reportReturnType]


def calculate[T: 'hints.number'](
    value: t.Iterable[T],
    *values: t.Iterable[T],
    predicate: t.Callable[[T, T], T],
) -> tuple[T, ...]:
    return tuple(
        functools.reduce(predicate, items)
        for items in zip(
            value,
            *values,
            strict=True,
        )
    )


if t.TYPE_CHECKING:

    @t.overload
    def sum(
        value: 'hints.vec2',
        *values: 'hints.vec2',
        predicate: (
            t.Callable[['hints.number', 'hints.number'], 'hints.number'] | None
        ) = None,
    ) -> 'hints.vec2': ...

    @t.overload
    def sum(
        value: 'hints.vec3',
        *values: 'hints.vec3',
        predicate: (
            t.Callable[['hints.number', 'hints.number'], 'hints.number'] | None
        ) = None,
    ) -> 'hints.vec3': ...

    @t.overload
    def sum(
        value: 'hints.vec4',
        *values: 'hints.vec4',
        predicate: (
            t.Callable[['hints.number', 'hints.number'], 'hints.number'] | None
        ) = None,
    ) -> hints.vec4: ...


def sum(
    value: t.Iterable['hints.number'],
    *values: t.Iterable['hints.number'],
    predicate: (
        t.Callable[['hints.number', 'hints.number'], 'hints.number'] | None
    ) = None,
) -> tuple['hints.number', ...]:
    return calculate(
        value,
        *values,
        predicate=(lambda x, y: x + y) if predicate is None else predicate,
    )


if t.TYPE_CHECKING:

    @t.overload
    def sub(
        value: 'hints.vec2',
        *values: 'hints.vec2',
        predicate: (
            t.Callable[['hints.number', 'hints.number'], 'hints.number'] | None
        ) = None,
    ) -> 'hints.vec2': ...

    @t.overload
    def sub(
        value: 'hints.vec3',
        *values: 'hints.vec3',
        predicate: (
            t.Callable[['hints.number', 'hints.number'], 'hints.number'] | None
        ) = None,
    ) -> 'hints.vec3': ...

    @t.overload
    def sub(
        value: 'hints.vec4',
        *values: 'hints.vec4',
        predicate: (
            t.Callable[['hints.number', 'hints.number'], 'hints.number'] | None
        ) = None,
    ) -> 'hints.vec4': ...


def sub(
    value: t.Iterable['hints.number'],
    *values: t.Iterable['hints.number'],
    predicate: (
        t.Callable[['hints.number', 'hints.number'], 'hints.number'] | None
    ) = None,
) -> tuple['hints.number', ...]:
    return calculate(
        value,
        *values,
        predicate=(lambda x, y: x - y) if predicate is None else predicate,
    )


if t.TYPE_CHECKING:

    @t.overload
    def mul(
        value: 'hints.vec2',
        *values: 'hints.vec2',
        predicate: (
            t.Callable[['hints.number', 'hints.number'], 'hints.number'] | None
        ) = None,
    ) -> 'hints.vec2': ...

    @t.overload
    def mul(
        value: 'hints.vec3',
        *values: 'hints.vec3',
        predicate: (
            t.Callable[['hints.number', 'hints.number'], 'hints.number'] | None
        ) = None,
    ) -> 'hints.vec3': ...

    @t.overload
    def mul(
        value: 'hints.vec4',
        *values: 'hints.vec4',
        predicate: (
            t.Callable[['hints.number', 'hints.number'], 'hints.number'] | None
        ) = None,
    ) -> 'hints.vec4': ...


def mul(
    value: t.Iterable['hints.number'],
    *values: t.Iterable['hints.number'],
    predicate: (
        t.Callable[['hints.number', 'hints.number'], 'hints.number'] | None
    ) = None,
) -> tuple['hints.number', ...]:
    return calculate(
        value,
        *values,
        predicate=(lambda x, y: x * y) if predicate is None else predicate,
    )


if t.TYPE_CHECKING:

    @t.overload
    def div(
        value: 'hints.vec2',
        *values: 'hints.vec2',
        predicate: (
            t.Callable[['hints.number', 'hints.number'], 'hints.number'] | None
        ) = None,
    ) -> 'hints.vec2': ...

    @t.overload
    def div(
        value: 'hints.vec3',
        *values: 'hints.vec3',
        predicate: (
            t.Callable[['hints.number', 'hints.number'], 'hints.number'] | None
        ) = None,
    ) -> 'hints.vec3': ...

    @t.overload
    def div(
        value: 'hints.vec4',
        *values: 'hints.vec4',
        predicate: (
            t.Callable[['hints.number', 'hints.number'], 'hints.number'] | None
        ) = None,
    ) -> 'hints.vec4': ...


def div(
    value: t.Iterable['hints.number'],
    *values: t.Iterable['hints.number'],
    predicate: (
        t.Callable[['hints.number', 'hints.number'], 'hints.number'] | None
    ) = None,
) -> tuple['hints.number', ...]:
    return calculate(
        value,
        *values,
        predicate=(lambda x, y: x / y) if predicate is None else predicate,
    )
