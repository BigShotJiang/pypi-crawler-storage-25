import typing as t
from pyglm import glm

if t.TYPE_CHECKING:
    from .. import hints


def look_at(
    eye: 'hints.pos3f',
    target: 'hints.pos3f',
    up: 'hints.pos3f' = (0, 1, 0),
) -> 'hints.quaternion':
    return glm.inverse(
        glm.quat(glm.lookAt(eye, target, up)),
    ).to_tuple()  # pyright: ignore[reportReturnType]


def slerp(
    start: 'hints.quaternion',
    end: 'hints.quaternion',
    progress: float,
) -> 'hints.quaternion':
    return glm.slerp(
        start,
        end,
        progress,
    ).to_tuple()


def lerp(
    start: 'hints.quaternion',
    end: 'hints.quaternion',
    progress: float,
) -> 'hints.quaternion':
    return glm.lerp(
        start,
        end,
        progress,
    ).to_tuple()


def from_euler(
    angle: 'hints.vec3',
) -> 'hints.quaternion':
    return glm.quat(angle)


def from_axis_angle(
    axis: 'hints.vec3',
    angle: float,
) -> 'hints.quaternion':
    return glm.angleAxis(
        angle,
        axis,
    ).to_tuple()
