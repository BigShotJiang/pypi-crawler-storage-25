import typing as t
from pyglm import glm

if t.TYPE_CHECKING:
    from .. import hints


def model_matrix(
    position: 'hints.pos3f',
    angle: 'hints.quaternion',
    scale: 'hints.scale3f',
) -> 'hints.mat4x4':
    return (
        glm.translate(
            glm.mat4(1),
            glm.vec3(*position),
        )
        * glm.mat4_cast(
            angle,
        )
        * glm.scale(
            glm.mat4(1.0),
            glm.vec3(*scale),
        )
    ).to_tuple()  # pyright: ignore[reportReturnType]


def view_matrix(
    position: 'hints.pos3f',
    angle: 'hints.quaternion',
) -> 'hints.mat4x4':
    return glm.lookAt(
        position,
        glm.vec3(*position) + (rotation_glm := glm.quat(*angle)) * (0.0, 0.0, -1.0),
        rotation_glm * (0.0, 1.0, 0.0),
    ).to_tuple()


def ortho_projection_matrix(
    size: 'hints.size2f',
    near_far: tuple[float, float],
    zoom: float = 1,
) -> 'hints.mat4x4':
    width, height = size

    left = -width / 2 / zoom
    right = width / 2 / zoom
    bottom = -height / 2 / zoom
    top = height / 2 / zoom

    return glm.ortho(
        left,
        right,
        bottom,
        top,
        *near_far,
    ).to_tuple()


def perspecrive_projection_matrix(
    fov: float,
    aspect: float,
    near_far: tuple[float, float],
    zoom: float = 1,
) -> 'hints.mat4x4':
    return glm.perspective(
        glm.radians(fov / zoom),
        aspect,
        *near_far,
    ).to_tuple()
