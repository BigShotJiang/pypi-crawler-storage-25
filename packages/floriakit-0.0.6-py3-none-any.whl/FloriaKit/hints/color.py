import typing as t

from .common import number


type rgb = tuple[number, number, number]
type rgba = tuple[number, number, number, number]

type color = t.Union[
    rgb,
    rgba,
]


def get_rgba(value: color) -> rgba:
    match len(value):
        case 3:
            return (*value, 255)  # pyright: ignore[reportReturnType]

        case 4:
            return value  # pyright: ignore[reportReturnType]

        case _:
            raise


def get_rgb(value: color) -> rgb:
    match len(value):
        case 3:
            return value  # pyright: ignore[reportReturnType]

        case 4:
            return value[:3]

        case _:
            raise
