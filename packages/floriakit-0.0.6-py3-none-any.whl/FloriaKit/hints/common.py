import typing as t


type number = int | float

# vec2

type vec2 = tuple[number, number]
type pos2 = vec2
type size2 = vec2
type scale2 = vec2

type vec2i = tuple[int, int]
type pos2i = vec2i
type size2i = vec2i
type scale2i = vec2i

type vec2f = tuple[float, float]
type pos2f = vec2f
type size2f = vec2f
type scale2f = vec2f

# vec3

type vec3 = tuple[number, number, number]
type pos3 = vec3
type size3 = vec3
type scale3 = vec3

type vec3i = tuple[int, int, int]
type pos3i = vec3i
type size3i = vec3i
type scale3i = vec3i

type vec3f = tuple[float, float, float]
type pos3f = vec3f
type size3f = vec3f
type scale3f = vec3f

# vec4

type vec4 = tuple[number, number, number, number]
type vec4i = tuple[int, int, int, int]
type vec4f = tuple[float, float, float, float]

# one-or-many

type one_or_many[T] = t.Iterable[T] | T
