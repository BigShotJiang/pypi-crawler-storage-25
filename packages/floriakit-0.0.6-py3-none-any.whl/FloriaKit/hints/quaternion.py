import typing as t

from .common import number

type quaternion = tuple[number, number, number, number]
