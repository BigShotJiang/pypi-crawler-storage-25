import typing as t


type ex = Exception | str


if t.TYPE_CHECKING:

    @t.overload
    def get_exception(ex_: ex) -> Exception: ...

    @t.overload
    def get_exception(ex_: ex | None) -> Exception | None: ...


def get_exception(ex_: ex | None):
    if ex_ is None:
        return None
    return ex_ if isinstance(ex_, Exception) else Exception(ex_)
