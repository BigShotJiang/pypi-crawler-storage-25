"""Tests for agent_doctor SDK — context, processor, and overrides."""

import pytest
import wrapt
from unittest.mock import MagicMock, patch, call

from agent_doctor._context import _run_id_var, _overrides_var
from agent_doctor._processor import RunContextSpanProcessor
from agent_doctor._overrides import _get_node_overrides
import agent_doctor


# ── run_context ──────────────────────────────────────────────────────────────


class TestRunContext:
    def test_sets_run_id(self):
        with agent_doctor.run_context(run_id="abc-123"):
            assert _run_id_var.get() == "abc-123"
        assert _run_id_var.get(None) is None

    def test_sets_overrides(self):
        ovr = [{"node_name": "step1", "temperature": 0.1}]
        with agent_doctor.run_context(run_id="r1", overrides=ovr):
            assert _overrides_var.get() == ovr
        assert _overrides_var.get(None) is None

    def test_no_overrides_default(self):
        with agent_doctor.run_context(run_id="r2"):
            assert _overrides_var.get(None) is None

    def test_run_id_cast_to_str(self):
        """UUIDs or ints are coerced to str."""
        with agent_doctor.run_context(run_id=42):
            assert _run_id_var.get() == "42"

    def test_nested_contexts(self):
        with agent_doctor.run_context(run_id="outer"):
            assert _run_id_var.get() == "outer"
            with agent_doctor.run_context(run_id="inner"):
                assert _run_id_var.get() == "inner"
            assert _run_id_var.get() == "outer"
        assert _run_id_var.get(None) is None

    def test_resets_on_exception(self):
        with pytest.raises(ValueError):
            with agent_doctor.run_context(run_id="err"):
                assert _run_id_var.get() == "err"
                raise ValueError("boom")
        assert _run_id_var.get(None) is None


# ── RunContextSpanProcessor ──────────────────────────────────────────────────


class TestSpanProcessor:
    def test_sets_run_id_attribute(self):
        processor = RunContextSpanProcessor()
        span = MagicMock()
        token = _run_id_var.set("run-999")
        try:
            processor.on_start(span)
            span.set_attribute.assert_called_once_with("run_id", "run-999")
        finally:
            _run_id_var.reset(token)

    def test_no_attribute_when_no_context(self):
        processor = RunContextSpanProcessor()
        span = MagicMock()
        processor.on_start(span)
        span.set_attribute.assert_not_called()

    def test_force_flush_returns_true(self):
        assert RunContextSpanProcessor().force_flush() is True


# ── _get_node_overrides ──────────────────────────────────────────────────────


class TestGetNodeOverrides:
    def _mock_span(self, name):
        span = MagicMock()
        span.name = name
        span.is_recording.return_value = True
        return span

    def test_returns_matching_override_list_format(self):
        overrides = [
            {"node_name": "step_a", "temperature": 0.1},
            {"node_name": "step_b", "temperature": 0.9},
        ]
        token = _overrides_var.set(overrides)
        try:
            with patch("agent_doctor._overrides.trace") as mock_trace:
                mock_trace.get_current_span.return_value = self._mock_span("step_b")
                result = _get_node_overrides()
                assert result == {"node_name": "step_b", "temperature": 0.9}
        finally:
            _overrides_var.reset(token)

    def test_returns_matching_override_dict_format(self):
        overrides = {
            "step_a": {"temperature": 0.1},
            "step_b": {"temperature": 0.9},
        }
        token = _overrides_var.set(overrides)
        try:
            with patch("agent_doctor._overrides.trace") as mock_trace:
                mock_trace.get_current_span.return_value = self._mock_span("step_a")
                result = _get_node_overrides()
                assert result == {"temperature": 0.1}
        finally:
            _overrides_var.reset(token)

    def test_returns_none_when_no_match(self):
        overrides = [{"node_name": "step_a", "temperature": 0.1}]
        token = _overrides_var.set(overrides)
        try:
            with patch("agent_doctor._overrides.trace") as mock_trace:
                mock_trace.get_current_span.return_value = self._mock_span("no_match")
                assert _get_node_overrides() is None
        finally:
            _overrides_var.reset(token)

    def test_returns_none_when_no_overrides(self):
        assert _get_node_overrides() is None

    def test_returns_none_when_span_not_recording(self):
        overrides = [{"node_name": "step_a", "temperature": 0.1}]
        token = _overrides_var.set(overrides)
        try:
            with patch("agent_doctor._overrides.trace") as mock_trace:
                span = MagicMock()
                span.is_recording.return_value = False
                mock_trace.get_current_span.return_value = span
                assert _get_node_overrides() is None
        finally:
            _overrides_var.reset(token)


# ── Override wrappers ────────────────────────────────────────────────────────


class TestApplyOverridesOpenAI:
    def _setup_span(self, mock_trace, name):
        span = MagicMock()
        span.name = name
        span.is_recording.return_value = True
        mock_trace.get_current_span.return_value = span

    def test_injects_temperature_and_model(self):
        from agent_doctor._overrides import _apply_overrides_openai

        wrapped = MagicMock(return_value="response")
        overrides = [{"node_name": "classify", "temperature": 0.2, "model": "gpt-4o-mini"}]

        with agent_doctor.run_context(run_id="r1", overrides=overrides):
            with patch("agent_doctor._overrides.trace") as mock_trace:
                self._setup_span(mock_trace, "classify")
                kwargs = {"model": "gpt-4o", "messages": [{"role": "user", "content": "hi"}]}
                _apply_overrides_openai(wrapped, None, (), kwargs)

        wrapped.assert_called_once()
        call_kwargs = wrapped.call_args[1]
        assert call_kwargs["temperature"] == 0.2
        assert call_kwargs["model"] == "gpt-4o-mini"

    def test_replaces_system_message(self):
        from agent_doctor._overrides import _apply_overrides_openai

        wrapped = MagicMock(return_value="response")
        overrides = [{"node_name": "summarize", "prompt": "Be concise."}]

        with agent_doctor.run_context(run_id="r1", overrides=overrides):
            with patch("agent_doctor._overrides.trace") as mock_trace:
                self._setup_span(mock_trace, "summarize")
                kwargs = {
                    "model": "gpt-4o",
                    "messages": [
                        {"role": "system", "content": "Original system prompt"},
                        {"role": "user", "content": "hello"},
                    ],
                }
                _apply_overrides_openai(wrapped, None, (), kwargs)

        call_kwargs = wrapped.call_args[1]
        assert call_kwargs["messages"][0]["content"] == "Be concise."
        assert call_kwargs["messages"][1]["role"] == "user"

    def test_does_not_mutate_original_system_message(self):
        from agent_doctor._overrides import _apply_overrides_openai

        wrapped = MagicMock(return_value="response")
        overrides = [{"node_name": "summarize", "prompt": "New."}]
        original_msg = {"role": "system", "content": "Original."}

        with agent_doctor.run_context(run_id="r1", overrides=overrides):
            with patch("agent_doctor._overrides.trace") as mock_trace:
                self._setup_span(mock_trace, "summarize")
                kwargs = {"model": "gpt-4o", "messages": [original_msg, {"role": "user", "content": "hi"}]}
                _apply_overrides_openai(wrapped, None, (), kwargs)

        assert original_msg["content"] == "Original."  # original dict untouched

    def test_inserts_system_message_when_missing(self):
        from agent_doctor._overrides import _apply_overrides_openai

        wrapped = MagicMock(return_value="response")
        overrides = [{"node_name": "summarize", "prompt": "New system."}]

        with agent_doctor.run_context(run_id="r1", overrides=overrides):
            with patch("agent_doctor._overrides.trace") as mock_trace:
                self._setup_span(mock_trace, "summarize")
                kwargs = {"model": "gpt-4o", "messages": [{"role": "user", "content": "hello"}]}
                _apply_overrides_openai(wrapped, None, (), kwargs)

        call_kwargs = wrapped.call_args[1]
        assert call_kwargs["messages"][0] == {"role": "system", "content": "New system."}
        assert len(call_kwargs["messages"]) == 2

    def test_top_p_and_max_tokens(self):
        from agent_doctor._overrides import _apply_overrides_openai

        wrapped = MagicMock(return_value="response")
        overrides = [{"node_name": "gen", "top_p": 0.8, "max_tokens": 256}]

        with agent_doctor.run_context(run_id="r1", overrides=overrides):
            with patch("agent_doctor._overrides.trace") as mock_trace:
                self._setup_span(mock_trace, "gen")
                kwargs = {"model": "gpt-4o", "messages": []}
                _apply_overrides_openai(wrapped, None, (), kwargs)

        call_kwargs = wrapped.call_args[1]
        assert call_kwargs["top_p"] == 0.8
        assert call_kwargs["max_tokens"] == 256

    def test_partial_override_only_temperature(self):
        from agent_doctor._overrides import _apply_overrides_openai

        wrapped = MagicMock(return_value="response")
        overrides = [{"node_name": "step", "temperature": 0.0}]

        with agent_doctor.run_context(run_id="r1", overrides=overrides):
            with patch("agent_doctor._overrides.trace") as mock_trace:
                self._setup_span(mock_trace, "step")
                kwargs = {
                    "model": "gpt-4o",
                    "messages": [{"role": "system", "content": "Keep me."}],
                    "max_tokens": 100,
                }
                _apply_overrides_openai(wrapped, None, (), kwargs)

        call_kwargs = wrapped.call_args[1]
        assert call_kwargs["temperature"] == 0.0
        assert call_kwargs["model"] == "gpt-4o"  # unchanged
        assert call_kwargs["messages"][0]["content"] == "Keep me."  # unchanged
        assert call_kwargs["max_tokens"] == 100

    def test_no_match_leaves_kwargs_intact(self):
        from agent_doctor._overrides import _apply_overrides_openai

        wrapped = MagicMock(return_value="response")
        overrides = [{"node_name": "other", "temperature": 0.0}]

        with agent_doctor.run_context(run_id="r1", overrides=overrides):
            with patch("agent_doctor._overrides.trace") as mock_trace:
                self._setup_span(mock_trace, "my_node")
                kwargs = {"model": "gpt-4o", "messages": [], "temperature": 0.9}
                _apply_overrides_openai(wrapped, None, (), kwargs)

        assert wrapped.call_args[1]["temperature"] == 0.9

    def test_multiple_overrides_picks_correct_node(self):
        from agent_doctor._overrides import _apply_overrides_openai

        wrapped = MagicMock(return_value="response")
        overrides = [
            {"node_name": "step_a", "temperature": 0.1},
            {"node_name": "step_b", "temperature": 0.9, "model": "gpt-4o-mini"},
            {"node_name": "step_c", "temperature": 0.5},
        ]

        with agent_doctor.run_context(run_id="r1", overrides=overrides):
            with patch("agent_doctor._overrides.trace") as mock_trace:
                self._setup_span(mock_trace, "step_b")
                kwargs = {"model": "gpt-4o", "messages": []}
                _apply_overrides_openai(wrapped, None, (), kwargs)

        call_kwargs = wrapped.call_args[1]
        assert call_kwargs["temperature"] == 0.9
        assert call_kwargs["model"] == "gpt-4o-mini"

    def test_empty_messages_list_with_prompt(self):
        from agent_doctor._overrides import _apply_overrides_openai

        wrapped = MagicMock(return_value="response")
        overrides = [{"node_name": "step", "prompt": "System."}]

        with agent_doctor.run_context(run_id="r1", overrides=overrides):
            with patch("agent_doctor._overrides.trace") as mock_trace:
                self._setup_span(mock_trace, "step")
                kwargs = {"model": "gpt-4o", "messages": []}
                _apply_overrides_openai(wrapped, None, (), kwargs)

        msgs = wrapped.call_args[1]["messages"]
        assert len(msgs) == 1
        assert msgs[0] == {"role": "system", "content": "System."}

    def test_passthrough_when_no_overrides(self):
        from agent_doctor._overrides import _apply_overrides_openai

        wrapped = MagicMock(return_value="response")
        kwargs = {"model": "gpt-4o", "temperature": 0.7}
        _apply_overrides_openai(wrapped, None, (), kwargs)
        call_kwargs = wrapped.call_args[1]
        assert call_kwargs["temperature"] == 0.7


class TestApplyOverridesAnthropic:
    def _setup_span(self, mock_trace, name):
        span = MagicMock()
        span.name = name
        span.is_recording.return_value = True
        mock_trace.get_current_span.return_value = span

    def test_injects_system_prompt_and_params(self):
        from agent_doctor._overrides import _apply_overrides_anthropic

        wrapped = MagicMock(return_value="response")
        overrides = [{"node_name": "explain", "prompt": "Be brief.", "temperature": 0.3, "max_tokens": 100}]

        with agent_doctor.run_context(run_id="r1", overrides=overrides):
            with patch("agent_doctor._overrides.trace") as mock_trace:
                self._setup_span(mock_trace, "explain")
                kwargs = {"model": "claude-sonnet-4-20250514", "messages": [{"role": "user", "content": "hi"}]}
                _apply_overrides_anthropic(wrapped, None, (), kwargs)

        call_kwargs = wrapped.call_args[1]
        assert call_kwargs["system"] == "Be brief."
        assert call_kwargs["temperature"] == 0.3
        assert call_kwargs["max_tokens"] == 100

    def test_overrides_model(self):
        from agent_doctor._overrides import _apply_overrides_anthropic

        wrapped = MagicMock(return_value="response")
        overrides = [{"node_name": "classify", "model": "claude-haiku-4-5-20251001"}]

        with agent_doctor.run_context(run_id="r1", overrides=overrides):
            with patch("agent_doctor._overrides.trace") as mock_trace:
                self._setup_span(mock_trace, "classify")
                kwargs = {"model": "claude-sonnet-4-20250514", "messages": [{"role": "user", "content": "hi"}], "max_tokens": 200}
                _apply_overrides_anthropic(wrapped, None, (), kwargs)

        call_kwargs = wrapped.call_args[1]
        assert call_kwargs["model"] == "claude-haiku-4-5-20251001"
        assert call_kwargs["max_tokens"] == 200  # unchanged

    def test_partial_override_no_prompt(self):
        from agent_doctor._overrides import _apply_overrides_anthropic

        wrapped = MagicMock(return_value="response")
        overrides = [{"node_name": "summarize", "temperature": 0.1, "top_p": 0.8}]

        with agent_doctor.run_context(run_id="r1", overrides=overrides):
            with patch("agent_doctor._overrides.trace") as mock_trace:
                self._setup_span(mock_trace, "summarize")
                kwargs = {"model": "claude-sonnet-4-20250514", "messages": [], "system": "Original.", "max_tokens": 500}
                _apply_overrides_anthropic(wrapped, None, (), kwargs)

        call_kwargs = wrapped.call_args[1]
        assert call_kwargs["temperature"] == 0.1
        assert call_kwargs["top_p"] == 0.8
        assert call_kwargs["system"] == "Original."  # not overridden
        assert call_kwargs["max_tokens"] == 500

    def test_passthrough_when_no_overrides(self):
        from agent_doctor._overrides import _apply_overrides_anthropic

        wrapped = MagicMock(return_value="response")
        kwargs = {"model": "claude-sonnet-4-20250514", "messages": [], "system": "Keep.", "max_tokens": 300}
        _apply_overrides_anthropic(wrapped, None, (), kwargs)

        call_kwargs = wrapped.call_args[1]
        assert call_kwargs["system"] == "Keep."
        assert call_kwargs["model"] == "claude-sonnet-4-20250514"

    def test_no_match_leaves_kwargs_intact(self):
        from agent_doctor._overrides import _apply_overrides_anthropic

        wrapped = MagicMock(return_value="response")
        overrides = [{"node_name": "other_node", "temperature": 0.0}]

        with agent_doctor.run_context(run_id="r1", overrides=overrides):
            with patch("agent_doctor._overrides.trace") as mock_trace:
                self._setup_span(mock_trace, "my_node")
                kwargs = {"model": "claude-sonnet-4-20250514", "messages": [], "temperature": 0.7}
                _apply_overrides_anthropic(wrapped, None, (), kwargs)

        call_kwargs = wrapped.call_args[1]
        assert call_kwargs["temperature"] == 0.7  # unchanged

    def test_overrides_system_replaces_existing(self):
        from agent_doctor._overrides import _apply_overrides_anthropic

        wrapped = MagicMock(return_value="response")
        overrides = [{"node_name": "step", "prompt": "New system."}]

        with agent_doctor.run_context(run_id="r1", overrides=overrides):
            with patch("agent_doctor._overrides.trace") as mock_trace:
                self._setup_span(mock_trace, "step")
                kwargs = {"model": "claude-sonnet-4-20250514", "messages": [], "system": "Old system."}
                _apply_overrides_anthropic(wrapped, None, (), kwargs)

        assert wrapped.call_args[1]["system"] == "New system."

    def test_adds_system_when_absent(self):
        from agent_doctor._overrides import _apply_overrides_anthropic

        wrapped = MagicMock(return_value="response")
        overrides = [{"node_name": "step", "prompt": "Injected."}]

        with agent_doctor.run_context(run_id="r1", overrides=overrides):
            with patch("agent_doctor._overrides.trace") as mock_trace:
                self._setup_span(mock_trace, "step")
                kwargs = {"model": "claude-sonnet-4-20250514", "messages": []}
                _apply_overrides_anthropic(wrapped, None, (), kwargs)

        assert wrapped.call_args[1]["system"] == "Injected."


class TestApplyOverridesGoogle:
    def test_injects_temperature_on_existing_config(self):
        from agent_doctor._overrides import _apply_overrides_google

        wrapped = MagicMock(return_value="response")
        overrides = [{"node_name": "fix_grammar", "temperature": 0.1}]

        mock_config = MagicMock()
        mock_config.temperature = 0.5

        with agent_doctor.run_context(run_id="r1", overrides=overrides):
            with patch("agent_doctor._overrides.trace") as mock_trace:
                span = MagicMock()
                span.name = "fix_grammar"
                span.is_recording.return_value = True
                mock_trace.get_current_span.return_value = span

                kwargs = {"model": "gemini-2.5-flash", "contents": "hello", "config": mock_config}
                _apply_overrides_google(wrapped, None, (), kwargs)

        assert mock_config.temperature == 0.1
        wrapped.assert_called_once()

    def test_creates_config_when_none(self):
        from agent_doctor._overrides import _apply_overrides_google

        wrapped = MagicMock(return_value="response")
        overrides = [{"node_name": "fix_grammar", "prompt": "Fix it.", "temperature": 0.2}]

        mock_cfg = MagicMock()
        mock_types = MagicMock()
        mock_types.GenerateContentConfig.return_value = mock_cfg

        with agent_doctor.run_context(run_id="r1", overrides=overrides):
            with patch("agent_doctor._overrides.trace") as mock_trace:
                span = MagicMock()
                span.name = "fix_grammar"
                span.is_recording.return_value = True
                mock_trace.get_current_span.return_value = span

                mock_genai = MagicMock(types=mock_types)
                with patch.dict("sys.modules", {
                    "google": MagicMock(),
                    "google.genai": mock_genai,
                    "google.genai.types": mock_types,
                }):
                    kwargs = {"model": "gemini-2.5-flash", "contents": "hello"}
                    _apply_overrides_google(wrapped, None, (), kwargs)

        assert kwargs["config"] is mock_cfg
        assert mock_cfg.temperature == 0.2
        assert mock_cfg.system_instruction == "Fix it."


# ── init() ───────────────────────────────────────────────────────────────────


class TestInit:
    @patch("agent_doctor._overrides.install_override_hooks")
    @patch("traceloop.sdk.Traceloop")
    @patch("opentelemetry.exporter.otlp.proto.http.trace_exporter.OTLPSpanExporter")
    def test_init_configures_traceloop(self, mock_exporter_cls, mock_traceloop, mock_hooks):
        agent_doctor.init(api_key="sk-proj-test123", endpoint="https://example.com/v1/traces", app_name="my-app")

        mock_exporter_cls.assert_called_once_with(
            endpoint="https://example.com/v1/traces",
            headers={"Authorization": "Bearer sk-proj-test123"},
        )
        mock_traceloop.init.assert_called_once()
        init_kwargs = mock_traceloop.init.call_args[1]
        assert init_kwargs["app_name"] == "my-app"
        assert init_kwargs["disable_batch"] is True
        mock_hooks.assert_called_once()

        from agent_doctor._config import config
        assert config.api_key == "sk-proj-test123"
        assert config.initialized is True

    @patch("agent_doctor._overrides.install_override_hooks")
    @patch("traceloop.sdk.Traceloop")
    @patch("opentelemetry.exporter.otlp.proto.http.trace_exporter.OTLPSpanExporter")
    def test_init_uses_defaults(self, mock_exporter_cls, mock_traceloop, mock_hooks):
        from agent_doctor._config import config, _DEFAULT_ENDPOINT
        config.endpoint = _DEFAULT_ENDPOINT  # reset from prior test
        agent_doctor.init(api_key="sk-proj-test")

        mock_exporter_cls.assert_called_once_with(
            endpoint=_DEFAULT_ENDPOINT,
            headers={"Authorization": "Bearer sk-proj-test"},
        )


# ── install_override_hooks ───────────────────────────────────────────────────


class TestInstallHooks:
    @patch("agent_doctor._overrides.wrapt")
    def test_installs_all_hooks(self, mock_wrapt):
        from agent_doctor._overrides import install_override_hooks, _HOOKS
        install_override_hooks()
        assert mock_wrapt.wrap_function_wrapper.call_count == len(_HOOKS)

    @patch("agent_doctor._overrides.wrapt")
    def test_skips_missing_providers(self, mock_wrapt):
        mock_wrapt.wrap_function_wrapper.side_effect = ImportError("no module")
        from agent_doctor._overrides import install_override_hooks
        install_override_hooks()  # should not raise


# ── Integration: wrapt wrapping on real SDK classes ──────────────────────────


try:
    import openai  # noqa: F401
    _has_openai = True
except ImportError:
    _has_openai = False


@pytest.mark.skipif(not _has_openai, reason="openai SDK not installed")
class TestWraptIntegrationOpenAI:
    """Verify that wrapt can actually wrap the real openai SDK methods."""

    def test_wrap_openai_completions_create(self):
        import openai.resources.chat.completions as mod

        original = mod.Completions.create
        calls = []

        def spy(wrapped, instance, args, kwargs):
            calls.append(kwargs)
            return {"id": "fake"}  # don't call the real API

        wrapt.wrap_function_wrapper(
            "openai.resources.chat.completions", "Completions.create", spy
        )
        try:
            client = MagicMock()
            # Call through the class — wrapt replaces the descriptor
            mod.Completions.create(client, model="gpt-4o", messages=[])
            assert len(calls) == 1
            assert calls[0]["model"] == "gpt-4o"
        finally:
            mod.Completions.create = original

    def test_override_flows_through_wrapt(self):
        """End-to-end: run_context → wrapt wrapper → overrides applied."""
        import openai.resources.chat.completions as mod
        from agent_doctor._overrides import _apply_overrides_openai

        original = mod.Completions.create
        captured = {}

        def capture_wrapper(wrapped, instance, args, kwargs):
            captured.update(kwargs)
            return {"id": "fake"}

        # Stack: our override wrapper → capture wrapper (simulating real call)
        wrapt.wrap_function_wrapper(
            "openai.resources.chat.completions", "Completions.create", capture_wrapper
        )
        wrapt.wrap_function_wrapper(
            "openai.resources.chat.completions", "Completions.create", _apply_overrides_openai
        )
        try:
            overrides = [{"node_name": "my_task", "temperature": 0.1, "model": "gpt-4o-mini"}]
            with agent_doctor.run_context(run_id="r1", overrides=overrides):
                with patch("agent_doctor._overrides.trace") as mock_trace:
                    span = MagicMock()
                    span.name = "my_task"
                    span.is_recording.return_value = True
                    mock_trace.get_current_span.return_value = span

                    client = MagicMock()
                    mod.Completions.create(client, model="gpt-4o", messages=[], temperature=0.7)

            assert captured["temperature"] == 0.1
            assert captured["model"] == "gpt-4o-mini"
        finally:
            mod.Completions.create = original


class TestWraptIntegrationAnthropic:
    """Verify that wrapt can actually wrap the real anthropic SDK methods."""

    def test_wrap_anthropic_messages_create(self):
        import anthropic.resources.messages as mod

        original = mod.Messages.create
        calls = []

        def spy(wrapped, instance, args, kwargs):
            calls.append(kwargs)
            return MagicMock()

        wrapt.wrap_function_wrapper(
            "anthropic.resources.messages", "Messages.create", spy
        )
        try:
            client = MagicMock()
            mod.Messages.create(
                client, model="claude-sonnet-4-20250514", messages=[{"role": "user", "content": "hi"}], max_tokens=100
            )
            assert len(calls) == 1
            assert calls[0]["model"] == "claude-sonnet-4-20250514"
        finally:
            mod.Messages.create = original

    def test_override_flows_through_wrapt(self):
        """End-to-end: run_context → wrapt wrapper → overrides applied."""
        import anthropic.resources.messages as mod
        from agent_doctor._overrides import _apply_overrides_anthropic

        original = mod.Messages.create
        captured = {}

        def capture_wrapper(wrapped, instance, args, kwargs):
            captured.update(kwargs)
            return MagicMock()

        wrapt.wrap_function_wrapper(
            "anthropic.resources.messages", "Messages.create", capture_wrapper
        )
        wrapt.wrap_function_wrapper(
            "anthropic.resources.messages", "Messages.create", _apply_overrides_anthropic
        )
        try:
            overrides = [{"node_name": "explain", "temperature": 0.2, "prompt": "Be terse.", "model": "claude-haiku-4-5-20251001"}]
            with agent_doctor.run_context(run_id="r1", overrides=overrides):
                with patch("agent_doctor._overrides.trace") as mock_trace:
                    span = MagicMock()
                    span.name = "explain"
                    span.is_recording.return_value = True
                    mock_trace.get_current_span.return_value = span

                    client = MagicMock()
                    mod.Messages.create(
                        client,
                        model="claude-sonnet-4-20250514",
                        messages=[{"role": "user", "content": "hello"}],
                        max_tokens=500,
                    )

            assert captured["temperature"] == 0.2
            assert captured["system"] == "Be terse."
            assert captured["model"] == "claude-haiku-4-5-20251001"
            assert captured["max_tokens"] == 500  # not overridden, stays
        finally:
            mod.Messages.create = original
