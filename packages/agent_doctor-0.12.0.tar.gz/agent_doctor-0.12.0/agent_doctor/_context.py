import contextvars

_run_id_var: contextvars.ContextVar[str | None] = contextvars.ContextVar(
    "_run_id_var", default=None
)
_overrides_var: contextvars.ContextVar[list | None] = contextvars.ContextVar(
    "_overrides_var", default=None
)
