from opentelemetry.sdk.trace import SpanProcessor
from ._context import _run_id_var


class RunContextSpanProcessor(SpanProcessor):
    """Injects run_id from the current context into every span."""

    def on_start(self, span, parent_context=None):
        run_id = _run_id_var.get(None)
        if run_id:
            span.set_attribute("run_id", str(run_id))

    def on_end(self, span):
        pass

    def shutdown(self):
        pass

    def force_flush(self, timeout_millis=None):
        return True
