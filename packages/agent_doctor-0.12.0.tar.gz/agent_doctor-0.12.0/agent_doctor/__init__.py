"""agent-doctor Python SDK — instrument AI agents with one init() call."""

from contextlib import contextmanager

from ._config import config
from ._context import _overrides_var, _run_id_var


def init(api_key, endpoint=None, app_name=None):
    """Initialise tracing. Call once at startup.

    Sets up Traceloop with a custom OTLP exporter pointed at the agent-doctor
    backend, installs the RunContextSpanProcessor, and installs override hooks.
    """
    from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
    from traceloop.sdk import Traceloop

    from ._overrides import install_override_hooks
    from ._processor import RunContextSpanProcessor

    config.api_key = api_key
    if endpoint:
        config.endpoint = endpoint
    if app_name:
        config.app_name = app_name

    exporter = OTLPSpanExporter(
        endpoint=config.endpoint,
        headers={"Authorization": f"Bearer {api_key}"},
    )

    Traceloop.init(
        app_name=config.app_name,
        exporter=exporter,
        disable_batch=True,
    )

    # Add RunContextSpanProcessor after Traceloop init so the export pipeline
    # is already in place — passing processor= to Traceloop.init() replaces the
    # exporter pipeline entirely, which causes no spans to be exported.
    from opentelemetry import trace as _otel_trace
    _otel_trace.get_tracer_provider().add_span_processor(RunContextSpanProcessor())

    install_override_hooks()
    config.initialized = True


@contextmanager
def run_context(run_id, overrides=None):
    """Context manager for a single run.

    Sets run_id (and optional overrides) on contextvars so that:
      - RunContextSpanProcessor tags every span with run_id
      - Override hooks inject per-node overrides into LLM SDK calls
    """
    run_token = _run_id_var.set(str(run_id))
    override_token = _overrides_var.set(overrides)
    try:
        yield
    finally:
        _run_id_var.reset(run_token)
        _overrides_var.reset(override_token)
