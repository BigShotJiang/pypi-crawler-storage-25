_DEFAULT_ENDPOINT = "https://api.agentdoctor.io/v1/traces"


class _Config:
    __slots__ = ("api_key", "endpoint", "app_name", "initialized")

    def __init__(self):
        self.api_key: str = ""
        self.endpoint: str = _DEFAULT_ENDPOINT
        self.app_name: str = "agent-doctor-app"
        self.initialized: bool = False


config = _Config()
