import copy
import logging

import wrapt
from opentelemetry import trace

from ._context import _overrides_var

logger = logging.getLogger(__name__)


_TRACELOOP_SUFFIXES = (".task", ".workflow", ".agent", ".tool")


def _node_name_from_span(span_name: str) -> str:
    """Strip the traceloop kind suffix (e.g. '.task', '.workflow') so that
    callers can match by the name they passed to @task/@workflow."""
    for suffix in _TRACELOOP_SUFFIXES:
        if span_name.endswith(suffix):
            return span_name[: -len(suffix)]
    return span_name


def _get_node_overrides():
    """Match the current OTel span name against overrides stored in the contextvar."""
    all_overrides = _overrides_var.get(None)
    if not all_overrides:
        return None
    span = trace.get_current_span()
    if not span or not span.is_recording():
        return None
    node_name = _node_name_from_span(span.name)
    if isinstance(all_overrides, list):
        return next((o for o in all_overrides if o.get("node_name") == node_name), None)
    if isinstance(all_overrides, dict):
        return all_overrides.get(node_name)
    return None


# ── Google GenAI ─────────────────────────────────────────────────────────────


def _apply_overrides_google(wrapped, instance, args, kwargs):
    overrides = _get_node_overrides()
    if not overrides:
        # Log the baseline config values even when no override is applied.
        config = kwargs.get("config")
        if config is not None:
            span = trace.get_current_span()
            if span.is_recording():
                if getattr(config, "temperature", None) is not None:
                    span.set_attribute("gen_ai.request.temperature", config.temperature)
                if getattr(config, "top_p", None) is not None:
                    span.set_attribute("gen_ai.request.top_p", config.top_p)
                if getattr(config, "max_output_tokens", None) is not None:
                    span.set_attribute("gen_ai.request.max_tokens", config.max_output_tokens)
        return wrapped(*args, **kwargs)

    config = kwargs.get("config")

    # Build a mutable config if one wasn't provided
    if config is None:
        from google.genai import types
        config = types.GenerateContentConfig()
        kwargs["config"] = config

    if "temperature" in overrides:
        config.temperature = overrides["temperature"]
    if "prompt" in overrides:
        config.system_instruction = overrides["prompt"]
    if "top_p" in overrides:
        config.top_p = overrides["top_p"]
    if "max_tokens" in overrides:
        config.max_output_tokens = overrides["max_tokens"]
    if "user_prompt" in overrides:
        kwargs["contents"] = overrides["user_prompt"]
    if "model" in overrides:
        kwargs["model"] = overrides["model"]

    # Log overridden values on the active span — the OTel Google GenAI
    # instrumentation doesn't capture these fields from GenerateContentConfig.
    span = trace.get_current_span()
    if span.is_recording():
        if "temperature" in overrides:
            span.set_attribute("gen_ai.request.temperature", overrides["temperature"])
        if "top_p" in overrides:
            span.set_attribute("gen_ai.request.top_p", overrides["top_p"])
        if "max_tokens" in overrides:
            span.set_attribute("gen_ai.request.max_tokens", overrides["max_tokens"])
        if "model" in overrides:
            span.set_attribute("gen_ai.request.model_override", overrides["model"])
        if "user_prompt" in overrides:
            span.set_attribute("gen_ai.request.user_prompt_override", overrides["user_prompt"])

    return wrapped(*args, **kwargs)


# ── OpenAI ───────────────────────────────────────────────────────────────────


def _log_span_attributes(span, kwargs, override_keys=()):
    """Stamp gen_ai.request.* attributes on the active span.

    Logs the effective value for each field — either the overridden value
    (already applied to kwargs) or the original value passed by the caller.
    """
    if not span.is_recording():
        return
    for attr, kwarg_key in (
        ("gen_ai.request.temperature", "temperature"),
        ("gen_ai.request.top_p", "top_p"),
        ("gen_ai.request.max_tokens", "max_tokens"),
    ):
        value = kwargs.get(kwarg_key)
        if value is not None:
            span.set_attribute(attr, value)
    if "model" in override_keys and kwargs.get("model"):
        span.set_attribute("gen_ai.request.model_override", kwargs["model"])
    if "user_prompt" in override_keys:
        messages = kwargs.get("messages") or []
        last_user = next((m["content"] for m in reversed(messages) if m.get("role") == "user"), None)
        if last_user:
            span.set_attribute("gen_ai.request.user_prompt_override", last_user)


def _apply_overrides_openai(wrapped, instance, args, kwargs):
    overrides = _get_node_overrides()
    span = trace.get_current_span()
    if not overrides:
        _log_span_attributes(span, kwargs)
        return wrapped(*args, **kwargs)

    for key in ("temperature", "top_p", "max_tokens", "model"):
        if key in overrides:
            kwargs[key] = overrides[key]

    if "prompt" in overrides:
        messages = list(kwargs.get("messages") or [])
        if messages and messages[0].get("role") == "system":
            messages[0] = {**messages[0], "content": overrides["prompt"]}
        else:
            messages.insert(0, {"role": "system", "content": overrides["prompt"]})
        kwargs["messages"] = messages

    if "user_prompt" in overrides:
        messages = list(kwargs.get("messages") or [])
        for i in range(len(messages) - 1, -1, -1):
            if messages[i].get("role") == "user":
                messages[i] = {**messages[i], "content": overrides["user_prompt"]}
                break
        else:
            messages.append({"role": "user", "content": overrides["user_prompt"]})
        kwargs["messages"] = messages

    _log_span_attributes(span, kwargs, override_keys=overrides.keys())
    return wrapped(*args, **kwargs)


# ── Anthropic ────────────────────────────────────────────────────────────────


def _apply_overrides_anthropic(wrapped, instance, args, kwargs):
    overrides = _get_node_overrides()
    span = trace.get_current_span()
    if not overrides:
        _log_span_attributes(span, kwargs)
        return wrapped(*args, **kwargs)

    for key in ("temperature", "top_p", "max_tokens", "model"):
        if key in overrides:
            kwargs[key] = overrides[key]

    if "prompt" in overrides:
        kwargs["system"] = overrides["prompt"]

    if "user_prompt" in overrides:
        messages = list(kwargs.get("messages") or [])
        for i in range(len(messages) - 1, -1, -1):
            if messages[i].get("role") == "user":
                messages[i] = {**messages[i], "content": overrides["user_prompt"]}
                break
        else:
            messages.append({"role": "user", "content": overrides["user_prompt"]})
        kwargs["messages"] = messages

    _log_span_attributes(span, kwargs, override_keys=overrides.keys())
    return wrapped(*args, **kwargs)


# ── Install hooks ────────────────────────────────────────────────────────────

_HOOKS = [
    ("google.genai.models", "Models.generate_content", _apply_overrides_google),
    ("openai.resources.chat.completions", "Completions.create", _apply_overrides_openai),
    ("anthropic.resources.messages", "Messages.create", _apply_overrides_anthropic),
]


def install_override_hooks():
    """Wrap LLM SDK methods (after LLMetry has already wrapped them) to inject overrides."""
    for module, method, wrapper in _HOOKS:
        try:
            wrapt.wrap_function_wrapper(module, method, wrapper)
            logger.debug("Override hook installed: %s.%s", module, method)
        except (ImportError, AttributeError):
            logger.debug("Skipping override hook (not installed): %s.%s", module, method)
