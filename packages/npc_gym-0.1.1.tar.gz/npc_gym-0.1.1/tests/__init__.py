"""Tests for npc-gym."""
