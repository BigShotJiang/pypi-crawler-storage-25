import shutil

import numpy as np
import pytest

from seamless import Buffer, Checksum
from seamless_transformer import (
    CompiledObject,
    CompiledTransformer,
    DirectCompiledTransformer,
)
from seamless_transformer.transformation_class import Transformation
from seamless_transformer import delayed as delayed_py


pytestmark = pytest.mark.skipif(not shutil.which("gcc"), reason="gcc required")


HEADER_STRUCTURED_SCALAR = """\
#include <stdint.h>
#include <stdbool.h>

typedef struct {
    int32_t x;
    double y;
} ItemStruct;

typedef struct {
    int32_t x;
    double y;
} ResultStruct;

int transform(
    ItemStruct item,
    ResultStruct *result
);
"""

HEADER_STRUCTURED_ARRAY = """\
#include <stdint.h>
#include <stdbool.h>

typedef struct {
    double xy[2];
    int32_t label;
} PointsStruct;

typedef struct {
    double xy[2];
    int32_t label;
} ShiftedStruct;

int transform(
    unsigned int N,
    const PointsStruct *points,
    ShiftedStruct *shifted
);
"""

HEADER_NESTED_STRUCT = """\
#include <stdint.h>
#include <stdbool.h>

typedef struct {
    int32_t id;
    double scale;
} SamplesMetaStruct;

typedef struct {
    SamplesMetaStruct meta;
    double value;
} SamplesStruct;

int transform(
    unsigned int N,
    const SamplesStruct *samples,
    double *result
);
"""


ADD_SCHEMA = """\
inputs:
  - {name: a, dtype: int32}
  - {name: b, dtype: int32}
outputs:
  - {name: result, dtype: int32}
"""


ADD_C = """\
#include <stdint.h>
int transform(int32_t a, int32_t b, int32_t *result) {
    *result = a + b;
    return 0;
}
"""


def test_c_scalar_python_and_numpy_inputs():
    tf = DirectCompiledTransformer("c")
    tf.schema = ADD_SCHEMA
    tf.code = ADD_C
    assert tf(a=2, b=3) == 5
    assert tf(a=np.int32(4), b=np.int32(7)) == 11


@pytest.mark.skipif(not shutil.which("g++"), reason="g++ required")
def test_cpp_scalar():
    tf = DirectCompiledTransformer("cpp")
    tf.schema = ADD_SCHEMA
    tf.code = """\
#include <stdint.h>
extern "C" int transform(int32_t a, int32_t b, int32_t *result) {
    *result = a + b;
    return 0;
}
"""
    assert tf(a=5, b=6) == 11


@pytest.mark.skipif(not shutil.which("rustc"), reason="rustc required")
def test_rust_scalar_archive_mode():
    tf = DirectCompiledTransformer("rust")
    tf.schema = ADD_SCHEMA
    tf.code = """\
#[no_mangle]
pub unsafe extern "C" fn transform(a: i32, b: i32, result: *mut i32) -> i32 {
    unsafe {
        *result = a + b;
    }
    0
}
"""
    assert tf(a=6, b=7) == 13


def test_delayed_compiled_transformer():
    tf = CompiledTransformer("c")
    tf.schema = ADD_SCHEMA
    tf.code = ADD_C
    result = tf(a=2, b=9)
    assert isinstance(result, Transformation)
    assert result.run() == 11


def test_delayed_compiled_transformer_scratch_run():
    tf = CompiledTransformer("c", scratch=True, local=True)
    tf.schema = ADD_SCHEMA
    tf.code = ADD_C
    result = tf(a=2, b=9)
    assert isinstance(result, Transformation)
    assert result.run() == 11


def test_array_input_output_and_non_contiguous_normalization():
    tf = DirectCompiledTransformer("c")
    tf.schema = """\
inputs:
  - {name: arr, dtype: float64, shape: [N]}
  - {name: factor, dtype: float64}
outputs:
  - {name: result, dtype: float64, shape: [N]}
"""
    tf.code = """\
#include <stdint.h>
int transform(unsigned int N, const double *arr, double factor, double *result) {
    for (unsigned int i = 0; i < N; i++) result[i] = arr[i] * factor;
    return 0;
}
"""
    source = np.arange(8, dtype=np.float64)[::2]
    np.testing.assert_allclose(tf(arr=source, factor=2.5), source * 2.5)


def test_output_only_wildcard_slicing():
    tf = DirectCompiledTransformer("c")
    tf.schema = """\
inputs:
  - {name: arr, dtype: int32, shape: [N]}
outputs:
  - {name: values, dtype: int32, shape: [K]}
"""
    tf.metavars.maxK = 10
    tf.code = """\
#include <stdint.h>
int transform(unsigned int N, unsigned int maxK, const int32_t *arr, unsigned int *K, int32_t *values) {
    unsigned int k = 0;
    for (unsigned int i = 0; i < N && k < maxK; i++) {
        if (arr[i] > 0) values[k++] = arr[i];
    }
    *K = k;
    return 0;
}
"""
    np.testing.assert_array_equal(
        tf(arr=np.array([-1, 4, 0, 5], dtype=np.int32)),
        np.array([4, 5], dtype=np.int32),
    )


def test_structured_scalar_input_output():
    tf = DirectCompiledTransformer("c")
    tf.schema = """\
inputs:
  - name: item
    dtype:
      fields:
        - {name: x, dtype: int32}
        - {name: y, dtype: float64}
outputs:
  - name: result
    dtype:
      fields:
        - {name: x, dtype: int32}
        - {name: y, dtype: float64}
"""
    assert tf.header == HEADER_STRUCTURED_SCALAR
    tf.code = HEADER_STRUCTURED_SCALAR + """\
int transform(ItemStruct item, ResultStruct *result) {
    result->x = item.x + 1;
    result->y = item.y * 2.0;
    return 0;
}
"""
    dtype = np.dtype([("x", "int32"), ("y", "float64")], align=True)
    result = tf(item=np.array((4, 1.5), dtype=dtype)[()])
    assert result.dtype == dtype
    assert result["x"] == 5
    assert result["y"] == 3.0


def test_structured_array_with_fixed_field_shape():
    tf = DirectCompiledTransformer("c")
    tf.schema = """\
inputs:
  - name: points
    dtype:
      fields:
        - {name: xy, dtype: float64, shape: [2]}
        - {name: label, dtype: int32}
    shape: [N]
outputs:
  - name: shifted
    dtype:
      fields:
        - {name: xy, dtype: float64, shape: [2]}
        - {name: label, dtype: int32}
    shape: [N]
"""
    assert tf.header == HEADER_STRUCTURED_ARRAY
    tf.code = HEADER_STRUCTURED_ARRAY + """\
int transform(unsigned int N, const PointsStruct *points, ShiftedStruct *shifted) {
    for (unsigned int i = 0; i < N; i++) {
        shifted[i].xy[0] = points[i].xy[0] + 10.0;
        shifted[i].xy[1] = points[i].xy[1] - 1.0;
        shifted[i].label = points[i].label + 100;
    }
    return 0;
}
"""
    dtype = np.dtype([("xy", "float64", (2,)), ("label", "int32")], align=True)
    points = np.zeros(3, dtype=dtype)
    points["xy"] = [[1.0, 2.0], [3.0, 4.0], [5.0, 6.0]]
    points["label"] = [7, 8, 9]

    result = tf(points=points)
    assert result.dtype == dtype
    np.testing.assert_allclose(
        result["xy"],
        np.array([[11.0, 1.0], [13.0, 3.0], [15.0, 5.0]]),
    )
    np.testing.assert_array_equal(result["label"], np.array([107, 108, 109]))


def test_nested_structured_array_input():
    tf = DirectCompiledTransformer("c")
    tf.schema = """\
inputs:
  - name: samples
    dtype:
      fields:
        - name: meta
          dtype:
            fields:
              - {name: id, dtype: int32}
              - {name: scale, dtype: float64}
        - {name: value, dtype: float64}
    shape: [N]
outputs:
  - {name: result, dtype: float64}
"""
    assert tf.header == HEADER_NESTED_STRUCT
    tf.code = HEADER_NESTED_STRUCT + """\
int transform(unsigned int N, const SamplesStruct *samples, double *result) {
    double total = 0.0;
    for (unsigned int i = 0; i < N; i++) {
        total += samples[i].value * samples[i].meta.scale + samples[i].meta.id;
    }
    *result = total;
    return 0;
}
"""
    meta_dtype = np.dtype([("id", "int32"), ("scale", "float64")], align=True)
    dtype = np.dtype([("meta", meta_dtype), ("value", "float64")], align=True)
    samples = np.zeros(2, dtype=dtype)
    samples["meta"]["id"] = [1, 2]
    samples["meta"]["scale"] = [10.0, 100.0]
    samples["value"] = [3.0, 4.0]

    assert tf(samples=samples) == 433.0


def test_multi_output_mixed_and_deepcell():
    schema = """\
inputs:
  - {name: a, dtype: int32}
  - {name: b, dtype: int32}
outputs:
  - {name: sum, dtype: int32}
  - {name: product, dtype: int32}
"""
    code = """\
#include <stdint.h>
int transform(int32_t a, int32_t b, int32_t *sum, int32_t *product) {
    *sum = a + b;
    *product = a * b;
    return 0;
}
"""
    tf = DirectCompiledTransformer("c")
    tf.schema = schema
    tf.code = code
    assert tf(a=2, b=3) == {"sum": 5, "product": 6}

    delayed = CompiledTransformer("c")
    delayed.schema = schema
    delayed.celltypes.result = "deepcell"
    delayed.code = code
    transformation = delayed(a=2, b=3)
    packed = transformation.run()
    assert set(packed) == {"sum", "product"}
    assert all(Checksum(value) for value in packed.values())

    direct = DirectCompiledTransformer("c")
    direct.schema = schema
    direct.celltypes.result = "deepcell"
    direct.code = code
    assert direct(a=2, b=3) == {"sum": 5, "product": 6}


@pytest.mark.skipif(not shutil.which("gfortran"), reason="gfortran required")
def test_multi_object_c_fortran():
    tf = DirectCompiledTransformer("c")
    tf.schema = ADD_SCHEMA
    tf.code = """\
#include <stdint.h>
extern void add_helper_(int32_t *a, int32_t *b, int32_t *result);
int transform(int32_t a, int32_t b, int32_t *result) {
    add_helper_(&a, &b, result);
    return 0;
}
"""
    obj = CompiledObject(language="fortran")
    obj.code = """\
subroutine add_helper(a,b,result)
use iso_c_binding
integer(c_int), intent(in) :: a,b
integer(c_int), intent(out) :: result
result = a + b
end subroutine
"""
    tf.objects.append(obj)
    assert tf(a=8, b=9) == 17


def test_non_native_endian_array_rejected():
    tf = DirectCompiledTransformer("c")
    tf.schema = """\
inputs:
  - {name: arr, dtype: int32, shape: [N]}
outputs:
  - {name: result, dtype: int32}
"""
    tf.code = """\
#include <stdint.h>
int transform(unsigned int N, const int32_t *arr, int32_t *result) {
    *result = arr[0];
    return 0;
}
"""
    dtype = ">i4" if np.dtype("int32").byteorder in ("<", "=") else "<i4"
    arr = np.array([1, 2], dtype=dtype)
    with pytest.raises(TypeError):
        tf(arr=arr)


def _make_checksum(value, celltype="mixed"):
    buf = Buffer(value, celltype)
    checksum = buf.get_checksum()
    buf.tempref()
    return checksum


def test_compiled_checksum_input_scalar():
    tf = DirectCompiledTransformer("c", local=True)
    tf.schema = ADD_SCHEMA
    tf.code = ADD_C

    cs_a = _make_checksum(np.int32(4))
    cs_b = _make_checksum(np.int32(5))

    assert tf(a=cs_a, b=cs_b) == 9
    assert tf(a=cs_a.hex(), b=cs_b.hex()) == 9


def test_compiled_checksum_input_array():
    tf = DirectCompiledTransformer("c", local=True)
    tf.schema = """\
inputs:
  - {name: arr, dtype: float64, shape: [N]}
  - {name: factor, dtype: float64}
outputs:
  - {name: result, dtype: float64, shape: [N]}
"""
    tf.code = """\
#include <stdint.h>
int transform(unsigned int N, const double *arr, double factor, double *result) {
    for (unsigned int i = 0; i < N; i++) result[i] = arr[i] * factor;
    return 0;
}
"""
    source = np.arange(4, dtype=np.float64)
    cs_arr = _make_checksum(source)
    np.testing.assert_allclose(tf(arr=cs_arr, factor=3.0), source * 3.0)


def test_compiled_transformation_input_scalar():
    @delayed_py
    def make_value(x: int, y: int) -> int:
        return x + y

    make_value.local = True

    tf = DirectCompiledTransformer("c", local=True)
    tf.schema = ADD_SCHEMA
    tf.code = ADD_C

    upstream_a = make_value(2, 3)  # -> 5
    upstream_b = make_value(4, 6)  # -> 10
    assert tf(a=upstream_a, b=upstream_b) == 15


def test_compiled_delayed_transformation_input():
    @delayed_py
    def make_value(x: int) -> int:
        return x * 2

    make_value.local = True

    upstream = make_value(7)  # -> 14

    tf = CompiledTransformer("c", local=True)
    tf.schema = ADD_SCHEMA
    tf.code = ADD_C
    t = tf(a=upstream, b=3)
    assert isinstance(t, Transformation)
    assert t.run() == 17


def test_compiled_deferred_input_dtype_mismatch():
    """Dtype validation must still trigger for deferred inputs — just later."""

    # A checksum carrying a float64 array, where the schema demands int32.
    bad_arr = _make_checksum(np.arange(3, dtype=np.float64))

    tf = CompiledTransformer("c", local=True)
    tf.schema = """\
inputs:
  - {name: arr, dtype: int32, shape: [N]}
outputs:
  - {name: result, dtype: int32}
"""
    tf.code = """\
#include <stdint.h>
int transform(unsigned int N, const int32_t *arr, int32_t *result) {
    *result = arr[0];
    return 0;
}
"""

    # Binding does not raise (validation is deferred).
    t = tf(arr=bad_arr)
    assert isinstance(t, Transformation)

    # Computing the transformation surfaces the dtype error.
    t.compute()
    assert t.exception is not None
    assert "dtype" in t.exception


def test_compiled_concrete_input_dtype_mismatch_immediate():
    """Concrete (non-deferred) inputs must still fail eagerly."""

    tf = DirectCompiledTransformer("c", local=True)
    tf.schema = ADD_SCHEMA
    tf.code = ADD_C
    with pytest.raises(TypeError):
        tf(a=np.float64(1.5), b=np.int32(2))
