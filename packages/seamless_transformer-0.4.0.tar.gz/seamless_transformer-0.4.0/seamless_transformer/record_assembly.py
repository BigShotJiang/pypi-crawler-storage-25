"""Execution-record assembly helpers."""

from __future__ import annotations

from typing import Any, Dict

from datetime import datetime, timezone
from importlib import metadata as importlib_metadata
import itertools
import os
import os as _os
import platform
import re
import shlex
import shutil
import socket
import subprocess
import sys
import tempfile
import threading

from seamless import Buffer, Checksum

from . import record_utils as _record_utils
from .record_utils import (
    _memory_peak_bytes,
    _process_create_time_epoch,
)
from .run import (
    _module_definition_from_payload,
    _resolve_dunder_value,
    get_transformation_inputs_output,
)
from seamless_config.select import (
    check_remote_redundancy,
    get_node,
    get_queue,
    get_remote,
    get_selected_cluster,
)

try:
    from seamless_remote import buffer_remote
except ImportError:
    buffer_remote = None

try:
    _SEAMLESS_VERSION = importlib_metadata.version("seamless")
except Exception:  # pragma: no cover - fallback for editable/source-only installs
    try:
        _SEAMLESS_VERSION = importlib_metadata.version("seamless-transformer")
    except Exception:  # pragma: no cover - last resort
        _SEAMLESS_VERSION = "unknown"

_PROCESS_STARTED_AT = datetime.now(timezone.utc)
_EXECUTION_RECORD_COUNTER = itertools.count(1)
_COMPILATION_CONTEXT_CACHE: dict[str, str] = {}
_VALIDATION_SNAPSHOT_COUNTS: dict[tuple, int] = {}
_COMPILED_VALIDATION_CACHE: dict[str, dict[str, Any]] = {}


def _resolve_remote_target(execution: str) -> str | None:
    return _record_utils._resolve_remote_target(
        execution,
        get_remote=get_remote,
        get_selected_cluster=get_selected_cluster,
        check_remote_redundancy=check_remote_redundancy,
    )


class _GpuMemorySampler:
    def __init__(self, *, pid: int, interval_seconds: float = 0.1):
        self._pid = int(pid)
        self._interval_seconds = interval_seconds
        self._stop_event = threading.Event()
        self._thread: threading.Thread | None = None
        self._peak_bytes: int | None = None

    def start(self) -> None:
        if self._thread is not None:
            return
        self._thread = threading.Thread(
            target=self._run,
            name=f"seamless-gpu-sampler-{self._pid}",
            daemon=True,
        )
        self._thread.start()

    def stop(self) -> int | None:
        self._stop_event.set()
        thread = self._thread
        if thread is not None:
            thread.join(timeout=max(self._interval_seconds * 2.0, 0.2))
        self._cleanup()
        return self._peak_bytes

    def _run(self) -> None:
        self._sample_once()
        while not self._stop_event.wait(self._interval_seconds):
            self._sample_once()
        self._sample_once()

    def _cleanup(self) -> None:
        return

    def _sample_once(self) -> None:
        raise NotImplementedError


class _PynvmlGpuMemorySampler(_GpuMemorySampler):
    def __init__(
        self,
        *,
        pid: int,
        pynvml: Any,
        interval_seconds: float = 0.1,
    ):
        super().__init__(pid=pid, interval_seconds=interval_seconds)
        self._pynvml = pynvml
        self._handles: list[Any] = []
        self._value_not_available = getattr(pynvml, "NVML_VALUE_NOT_AVAILABLE", None)
        pynvml.nvmlInit()
        for index in range(int(pynvml.nvmlDeviceGetCount())):
            self._handles.append(pynvml.nvmlDeviceGetHandleByIndex(index))

    def _cleanup(self) -> None:
        shutdown = getattr(self._pynvml, "nvmlShutdown", None)
        if callable(shutdown):
            try:
                shutdown()
            except Exception:
                pass

    def _iter_processes(self, handle: Any) -> list[Any]:
        processes: list[Any] = []
        for name in (
            "nvmlDeviceGetComputeRunningProcesses_v3",
            "nvmlDeviceGetComputeRunningProcesses_v2",
            "nvmlDeviceGetComputeRunningProcesses",
            "nvmlDeviceGetGraphicsRunningProcesses_v3",
            "nvmlDeviceGetGraphicsRunningProcesses_v2",
            "nvmlDeviceGetGraphicsRunningProcesses",
        ):
            getter = getattr(self._pynvml, name, None)
            if not callable(getter):
                continue
            try:
                items = getter(handle)
            except Exception:
                continue
            if items:
                processes.extend(items)
        return processes

    def _sample_once(self) -> None:
        total_bytes = 0
        matched = False
        for handle in self._handles:
            for process in self._iter_processes(handle):
                pid = getattr(process, "pid", None)
                if pid != self._pid:
                    continue
                used = getattr(process, "usedGpuMemory", None)
                if used is None:
                    continue
                if (
                    self._value_not_available is not None
                    and used == self._value_not_available
                ):
                    continue
                try:
                    used_bytes = int(used)
                except Exception:
                    continue
                if used_bytes < 0:
                    continue
                total_bytes += used_bytes
                matched = True
        if not matched:
            return
        if self._peak_bytes is None or total_bytes > self._peak_bytes:
            self._peak_bytes = total_bytes


def start_gpu_memory_sampler(pid: int | None = None) -> _GpuMemorySampler | None:
    try:
        import pynvml
    except Exception:
        return None
    if pid is None:
        pid = _os.getpid()
    try:
        sampler = _PynvmlGpuMemorySampler(pid=pid, pynvml=pynvml)
    except Exception:
        return None
    sampler.start()
    return sampler


def stop_gpu_memory_sampler(sampler: _GpuMemorySampler | None) -> int | None:
    if sampler is None:
        return None
    return sampler.stop()


def _validation_snapshot_limit() -> int:
    raw = os.environ.get("SEAMLESS_RECORD_VALIDATION_SNAPSHOT_LIMIT", "1")
    try:
        value = int(raw)
    except Exception:
        return 1
    return max(value, 0)


def _stable_digest(value: Any) -> str:
    import hashlib
    import json

    try:
        payload = json.dumps(value, sort_keys=True, default=repr).encode()
    except TypeError:
        payload = repr(value).encode()
    return hashlib.sha256(payload).hexdigest()


def _compiler_version(binary: str) -> str | None:
    try:
        completed = subprocess.run(
            [binary, "--version"],
            check=False,
            capture_output=True,
            text=True,
            timeout=5,
        )
    except Exception:
        return None
    output = (completed.stdout or completed.stderr or "").strip().splitlines()
    if not output:
        return None
    return output[0].strip() or None


async def build_compilation_context_checksum(
    transformation_dict: Dict[str, Any],
    tf_dunder: Dict[str, Any] | None,
) -> str | None:
    if not (
        transformation_dict.get("__compiled__")
        or (isinstance(tf_dunder, dict) and tf_dunder.get("__compiled__"))
    ):
        return None
    if buffer_remote is None or not buffer_remote.has_write_server():
        raise RuntimeError(
            "Compiled execution records require an active hashserver write server"
        )

    from seamless_transformer.compiler.compile import complete

    schema_checksum = transformation_dict.get("__schema__")
    if schema_checksum is None and isinstance(tf_dunder, dict):
        schema_checksum = tf_dunder.get("__schema__")
    header_checksum = transformation_dict.get("__header__")
    if header_checksum is None and isinstance(tf_dunder, dict):
        header_checksum = tf_dunder.get("__header__")
    compilation_checksum = transformation_dict.get("__compilation__")
    if compilation_checksum is None and isinstance(tf_dunder, dict):
        compilation_checksum = tf_dunder.get("__compilation__")

    code_checksum = transformation_dict.get("code", (None, None, None))[2]
    objects_checksum = transformation_dict.get("objects", (None, None, None))[2]
    language = transformation_dict.get("__language__")

    code = await Checksum(code_checksum).resolution("text")
    header = _resolve_dunder_value(transformation_dict, tf_dunder, "__header__", "text")
    compilation = _resolve_dunder_value(
        transformation_dict, tf_dunder, "__compilation__", "plain"
    )
    objects = {}
    if objects_checksum is not None:
        objects = await Checksum(objects_checksum).resolution("plain")
        if not isinstance(objects, dict):
            objects = {}

    module_definition = _module_definition_from_payload(
        language, code, header, objects, compilation
    )
    completed = complete(module_definition)
    compiled_module_digest = _stable_digest(completed)
    cached_checksum = _COMPILATION_CONTEXT_CACHE.get(compiled_module_digest)
    if cached_checksum is not None:
        return cached_checksum

    objects_payload: dict[str, Any] = {}
    for name, obj in sorted(completed["objects"].items()):
        compiler_binary = obj["compiler_binary"]
        compiler_path = shutil.which(compiler_binary) or compiler_binary
        objects_payload[name] = {
            "language": obj["language"],
            "compiler_binary": compiler_binary,
            "compiler_path": compiler_path,
            "compiler_version": _compiler_version(compiler_path),
            "compile_mode": obj.get("compile_mode"),
            "extension": obj.get("extension"),
            "options": list(obj.get("options") or []),
        }

    payload = {
        "schema_version": 1,
        "language": language,
        "target": completed.get("target", "profile"),
        "schema_checksum": str(schema_checksum) if schema_checksum is not None else None,
        "header_checksum": str(header_checksum) if header_checksum is not None else None,
        "code_checksum": str(code_checksum) if code_checksum is not None else None,
        "objects_checksum": (
            str(objects_checksum) if objects_checksum is not None else None
        ),
        "compilation_checksum": (
            str(compilation_checksum) if compilation_checksum is not None else None
        ),
        "object_names": sorted(completed["objects"].keys()),
        "link_options": list(completed.get("link_options", [])),
        "objects": objects_payload,
        "compiled_module_digest": compiled_module_digest,
        "compiled_module_validation_digest": None,
    }
    buffer = Buffer(payload, "plain")
    written = await buffer.write()
    if not written:
        raise RuntimeError("Failed to write compilation context to the hashserver")
    checksum = buffer.get_checksum().hex()
    _COMPILATION_CONTEXT_CACHE[compiled_module_digest] = checksum
    return checksum


def _allowlisted_library_name(name: str) -> bool:
    allowed_prefixes = (
        "ld-linux",
        "libc.so",
        "libm.so",
        "libdl.so",
        "libpthread.so",
        "librt.so",
        "libutil.so",
        "libcuda.so",
        "libnvidia-ml.so",
    )
    return any(name.startswith(prefix) for prefix in allowed_prefixes)


def _system_library_roots() -> tuple[str, ...]:
    roots = {
        "/lib",
        "/lib64",
        "/usr/lib",
        "/usr/lib64",
        "/lib/x86_64-linux-gnu",
        "/usr/lib/x86_64-linux-gnu",
    }
    return tuple(sorted(roots))


def _normalize_path(path: str, *, module_dir: str | None = None) -> str:
    path = path.strip()
    if not path:
        return path
    if module_dir is not None:
        path = path.replace("$ORIGIN", module_dir).replace("${ORIGIN}", module_dir)
    path = os.path.expandvars(path)
    path = os.path.expanduser(path)
    return os.path.realpath(path)


def _path_allowed_for_contract(
    path: str, *, conda_prefix: str | None, allow_system_roots: bool
) -> bool:
    if not path:
        return True
    if conda_prefix and path.startswith(conda_prefix + os.sep):
        return True
    if allow_system_roots:
        for root in _system_library_roots():
            if path == root or path.startswith(root + os.sep):
                return True
    return False


def _normalize_job_validation_payload(payload: Any) -> dict[str, Any]:
    if not isinstance(payload, dict):
        return {
            "job_contract_violations": [],
            "diagnostics": {},
        }
    job_contract_violations = payload.get("job_contract_violations")
    if not isinstance(job_contract_violations, list):
        job_contract_violations = []
    normalized_violations = sorted(
        {
            code
            for code in job_contract_violations
            if isinstance(code, str) and code
        }
    )
    diagnostics = payload.get("diagnostics")
    if not isinstance(diagnostics, dict):
        diagnostics = {}
    return {
        "job_contract_violations": normalized_violations,
        "diagnostics": diagnostics,
    }


def _split_path_like(value: str) -> list[str]:
    return [item for item in value.split(":") if item]


def _split_preload(value: str) -> list[str]:
    items: list[str] = []
    for token in shlex.split(value):
        items.extend(part for part in token.split(":") if part)
    return items


def _selected_env_vars(
    *prefixes: str, names: tuple[str, ...] = ()
) -> dict[str, str]:
    result: dict[str, str] = {}
    for key, value in os.environ.items():
        if key in names or any(key.startswith(prefix) for prefix in prefixes):
            result[key] = value
    return dict(sorted(result.items()))


def _determinant_env_live() -> dict[str, str]:
    return _selected_env_vars(
        "OMP_",
        "GOMP_",
        "KMP_",
        "MKL_",
        "OPENBLAS_",
        names=(
            "PATH",
            "PYTHONPATH",
            "LD_LIBRARY_PATH",
            "LD_PRELOAD",
            "PYTHONHASHSEED",
            "LANG",
            "LC_ALL",
            "LC_CTYPE",
            "TZ",
            "CUBLAS_WORKSPACE_CONFIG",
            "TF_DETERMINISTIC_OPS",
            "TF_CUDNN_DETERMINISTIC",
            "PYTORCH_CUDA_ALLOC_CONF",
            "CUDA_DEVICE_ORDER",
            "CUDA_LAUNCH_BLOCKING",
            "NVIDIA_TF32_OVERRIDE",
        ),
    )


def _canonical_path_entries(value: str | None) -> list[str]:
    if not value:
        return []
    return [_normalize_path(item) for item in _split_path_like(value)]


def _canonical_sys_path() -> list[str]:
    return [_normalize_path(item) for item in sys.path if isinstance(item, str) and item]


def _current_umask() -> int | None:
    try:
        value = os.umask(0)
    except Exception:
        return None
    os.umask(value)
    return value


def _parse_mountinfo() -> list[dict[str, Any]]:
    try:
        with open("/proc/self/mountinfo", "r", encoding="utf-8") as f:
            text = f.read()
    except Exception:
        return []
    result = []
    for line in text.splitlines():
        if " - " not in line:
            continue
        left, right = line.split(" - ", 1)
        left_fields = left.split()
        right_fields = right.split()
        if len(left_fields) < 6 or len(right_fields) < 3:
            continue
        result.append(
            {
                "mount_point": left_fields[4],
                "filesystem_type": right_fields[0],
                "mount_source": right_fields[1],
            }
        )
    return result


def _mount_for_path(path: str, mountinfo: list[dict[str, Any]]) -> dict[str, Any] | None:
    best = None
    best_len = -1
    for entry in mountinfo:
        mount_point = entry.get("mount_point")
        if not isinstance(mount_point, str):
            continue
        if path == mount_point or path.startswith(mount_point.rstrip("/") + "/"):
            if len(mount_point) > best_len:
                best = entry
                best_len = len(mount_point)
    return best


def _filesystem_facts_live() -> dict[str, Any]:
    import sysconfig

    mountinfo = _parse_mountinfo()
    targets = {
        "cwd": os.getcwd(),
        "tempdir": tempfile.gettempdir(),
        "sys_prefix": sys.prefix,
    }
    purelib = sysconfig.get_path("purelib")
    if purelib:
        targets["purelib"] = purelib
    result: dict[str, Any] = {}
    for name, path in targets.items():
        resolved = _normalize_path(path)
        entry = _mount_for_path(resolved, mountinfo)
        if entry is None:
            continue
        result[name] = {
            "path": resolved,
            "mount_point": entry["mount_point"],
            "filesystem_type": entry["filesystem_type"],
            "mount_source": entry["mount_source"],
        }
    return result


def _read_proc_self_maps_paths() -> list[str]:
    try:
        with open("/proc/self/maps", "r", encoding="utf-8") as f:
            lines = f.readlines()
    except Exception:
        return []
    result: list[str] = []
    for line in lines:
        fields = line.strip().split()
        if len(fields) < 6:
            continue
        path = fields[-1]
        if not path.startswith("/"):
            continue
        result.append(_normalize_path(path))
    return sorted(set(result))


def _path_under_any_root(path: str, roots: list[str]) -> bool:
    for root in roots:
        if path == root or path.startswith(root.rstrip(os.sep) + os.sep):
            return True
    return False


def _allowed_map_roots(
    *,
    environment_payload: dict[str, Any] | None,
    node_payload: dict[str, Any] | None,
) -> list[str]:
    roots: list[str] = list(_system_library_roots())
    conda_prefix = os.environ.get("CONDA_PREFIX")
    if conda_prefix:
        roots.append(_normalize_path(conda_prefix))
    if environment_payload:
        validation_views = environment_payload.get("validation_views", {}) or {}
        for path in validation_views.get("sys_path_entries", []) or []:
            if isinstance(path, str) and path:
                roots.append(_normalize_path(path))
        python_payload = environment_payload.get("python", {}) or {}
        prefix = python_payload.get("prefix")
        if isinstance(prefix, str) and prefix:
            roots.append(_normalize_path(prefix))
    if node_payload:
        libraries = node_payload.get("libraries", {}) or {}
        for name in ("glibc", "libm"):
            lib = libraries.get(name)
            if isinstance(lib, dict):
                lib_path = lib.get("path")
                if isinstance(lib_path, str) and lib_path:
                    roots.append(os.path.dirname(_normalize_path(lib_path)))
    return sorted({root for root in roots if isinstance(root, str) and root})


async def _load_bucket_payloads(
    probe_context: dict[str, Any] | None,
) -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    if not isinstance(probe_context, dict):
        return result
    required_bucket_checksums = probe_context.get("required_bucket_checksums", {})
    if not isinstance(required_bucket_checksums, dict):
        return result
    for kind, checksum_hex in required_bucket_checksums.items():
        if not checksum_hex:
            continue
        try:
            payload = await Checksum(checksum_hex).resolution("plain")
        except Exception:
            continue
        if isinstance(payload, dict):
            result[kind] = payload
    return result


def _expected_determinant_env(
    environment_payload: dict[str, Any] | None,
    queue_node_payload: dict[str, Any] | None,
) -> dict[str, str]:
    result: dict[str, str] = {}
    if environment_payload:
        validation_views = environment_payload.get("validation_views", {}) or {}
        env_dict = validation_views.get("determinant_env", {}) or {}
        if isinstance(env_dict, dict):
            for key, value in env_dict.items():
                if isinstance(key, str) and isinstance(value, str):
                    result[key] = value
    if queue_node_payload:
        runtime_env = queue_node_payload.get("environment_variables", {}) or {}
        if isinstance(runtime_env, dict):
            for key, value in runtime_env.items():
                if isinstance(key, str) and isinstance(value, str):
                    result[key] = value
    return dict(sorted(result.items()))


def _gpu_policy_live() -> dict[str, Any]:
    try:
        from seamless_transformer.probe_capture import _visible_gpu_mapping
    except Exception:
        _visible_gpu_mapping = None
    mapping = None
    if callable(_visible_gpu_mapping):
        try:
            mapping = _visible_gpu_mapping()
        except Exception:
            mapping = None
    return {
        "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES"),
        "visible_gpu_mapping": mapping,
    }


def _job_check_payload(expected: Any, actual: Any) -> dict[str, Any]:
    return {
        "expected": expected,
        "actual": actual,
        "expected_hash": _stable_digest(expected),
        "actual_hash": _stable_digest(actual),
        "ok": expected == actual,
    }


def _parse_readelf_dynamic(text: str, *, module_dir: str) -> dict[str, Any]:
    rpath_entries: list[str] = []
    runpath_entries: list[str] = []
    needed: list[str] = []
    pattern = re.compile(r"\((?P<tag>[A-Z_]+)\).*?\[(?P<value>.*)\]")
    for line in text.splitlines():
        match = pattern.search(line)
        if match is None:
            continue
        tag = match.group("tag")
        value = match.group("value")
        if tag == "RPATH":
            rpath_entries.extend(
                _normalize_path(item, module_dir=module_dir)
                for item in _split_path_like(value)
            )
        elif tag == "RUNPATH":
            runpath_entries.extend(
                _normalize_path(item, module_dir=module_dir)
                for item in _split_path_like(value)
            )
        elif tag == "NEEDED":
            needed.append(value)
    return {"rpath": rpath_entries, "runpath": runpath_entries, "needed": needed}


def _resolve_needed_libraries(
    needed: list[str],
    *,
    module_dir: str,
    conda_prefix: str | None,
    runpath_entries: list[str],
) -> dict[str, str | None]:
    search_dirs: list[str] = []
    for entry in runpath_entries:
        if entry and entry not in search_dirs:
            search_dirs.append(entry)
    for env_name in ("LD_LIBRARY_PATH",):
        env_value = os.environ.get(env_name)
        if not env_value:
            continue
        for item in _split_path_like(env_value):
            resolved = _normalize_path(item, module_dir=module_dir)
            if resolved and resolved not in search_dirs:
                search_dirs.append(resolved)
    if conda_prefix:
        conda_lib = os.path.join(conda_prefix, "lib")
        search_dirs.append(conda_lib)
    search_dirs.extend(_system_library_roots())

    resolved: dict[str, str | None] = {}
    for libname in needed:
        path = None
        for directory in search_dirs:
            candidate = os.path.join(directory, libname)
            if os.path.exists(candidate):
                path = os.path.realpath(candidate)
                break
        resolved[libname] = path
    return resolved


async def collect_job_validation(
    transformation_dict: Dict[str, Any],
    tf_dunder: Dict[str, Any] | None,
    *,
    compilation_context: str | None,
    probe_context: dict[str, Any] | None = None,
) -> dict[str, Any]:
    compiled = bool(
        transformation_dict.get("__compiled__")
        or (isinstance(tf_dunder, dict) and tf_dunder.get("__compiled__"))
    )
    bucket_payloads = await _load_bucket_payloads(probe_context)
    environment_payload = bucket_payloads.get("environment")
    node_payload = bucket_payloads.get("node")
    node_env_payload = bucket_payloads.get("node_env")
    queue_node_payload = bucket_payloads.get("queue_node")
    checks: dict[str, Any] = {}

    expected_env = _expected_determinant_env(environment_payload, queue_node_payload)
    live_env = {
        key: value
        for key, value in _determinant_env_live().items()
        if key in expected_env
    }
    if expected_env:
        checks["determinant_env_hash"] = _job_check_payload(expected_env, live_env)

    if environment_payload:
        validation_views = environment_payload.get("validation_views", {}) or {}
        expected_path_entries = validation_views.get("path_entries")
        if isinstance(expected_path_entries, list):
            checks["path_roots"] = _job_check_payload(
                expected_path_entries,
                _canonical_path_entries(os.environ.get("PATH")),
            )
        expected_sys_path_entries = validation_views.get("sys_path_entries")
        if isinstance(expected_sys_path_entries, list):
            checks["sys_path_roots"] = _job_check_payload(
                expected_sys_path_entries,
                _canonical_sys_path(),
            )

    live_filesystems = _filesystem_facts_live()
    if node_payload:
        expected_filesystems = node_payload.get("filesystems")
        if isinstance(expected_filesystems, dict) and expected_filesystems:
            expected_mount_view = {
                key: {
                    "filesystem_type": value.get("filesystem_type"),
                    "mount_source": value.get("mount_source"),
                }
                for key, value in expected_filesystems.items()
                if isinstance(value, dict)
            }
            actual_mount_view = {
                key: {
                    "filesystem_type": value.get("filesystem_type"),
                    "mount_source": value.get("mount_source"),
                }
                for key, value in live_filesystems.items()
            }
            checks["mount_policy"] = _job_check_payload(
                expected_mount_view,
                actual_mount_view,
            )

    temp_env = {
        name: os.environ.get(name)
        for name in ("TMPDIR", "TEMP", "TMP")
        if os.environ.get(name) is not None
    }
    expected_temp_env = {}
    if queue_node_payload:
        runtime_env = queue_node_payload.get("environment_variables", {}) or {}
        if isinstance(runtime_env, dict):
            expected_temp_env = {
                key: value
                for key, value in runtime_env.items()
                if key in ("TMPDIR", "TEMP", "TMP")
            }
    checks["cwd_temp_umask"] = {
        "cwd": os.getcwd(),
        "cwd_exists": os.path.isdir(os.getcwd()),
        "tempdir": tempfile.gettempdir(),
        "temp_environment": _job_check_payload(expected_temp_env, temp_env)
        if expected_temp_env
        else {
            "expected": {},
            "actual": temp_env,
            "expected_hash": _stable_digest({}),
            "actual_hash": _stable_digest(temp_env),
            "ok": True,
        },
        "umask": _current_umask(),
    }
    checks["cwd_temp_umask"]["ok"] = bool(
        checks["cwd_temp_umask"]["cwd_exists"]
        and checks["cwd_temp_umask"]["temp_environment"]["ok"]
        and checks["cwd_temp_umask"]["umask"] is not None
    )

    allowed_roots = _allowed_map_roots(
        environment_payload=environment_payload,
        node_payload=node_payload,
    )
    mapped_paths = _read_proc_self_maps_paths()
    outside_mapped_paths = [
        path for path in mapped_paths if not _path_under_any_root(path, allowed_roots)
    ]
    checks["proc_self_maps"] = {
        "allowed_roots": allowed_roots,
        "outside_paths": outside_mapped_paths[:20],
        "outside_count": len(outside_mapped_paths),
        "ok": len(outside_mapped_paths) == 0,
    }

    expected_gpu_policy = {}
    if node_env_payload:
        expected_gpu_policy = {
            "cuda_visible_devices": node_env_payload.get("cuda_visible_devices"),
            "visible_gpu_mapping": node_env_payload.get("visible_gpu_mapping"),
        }
    if expected_gpu_policy:
        checks["gpu_visible_device_policy"] = _job_check_payload(
            expected_gpu_policy,
            _gpu_policy_live(),
        )

    diagnostics: dict[str, Any] = {
        "compiled": compiled,
        "checks": checks,
    }
    job_contract_violations: set[str] = set()
    if not compiled:
        return {
            "job_contract_violations": [],
            "diagnostics": diagnostics,
        }

    conda_prefix = os.environ.get("CONDA_PREFIX")
    diagnostics["conda_prefix"] = conda_prefix
    if not conda_prefix:
        diagnostics["native_linkage_skipped"] = "no_active_conda_prefix"
        return {
            "job_contract_violations": [],
            "diagnostics": diagnostics,
        }
    conda_prefix = os.path.realpath(conda_prefix)

    from seamless_transformer.compiler import get_compiled_module_info

    code = await Checksum(transformation_dict.get("code")[2]).resolution("text")
    header = _resolve_dunder_value(transformation_dict, tf_dunder, "__header__", "text")
    compilation = _resolve_dunder_value(
        transformation_dict, tf_dunder, "__compilation__", "plain"
    )
    objects = {}
    objects_value = transformation_dict.get("objects")
    if objects_value is not None and objects_value[2] is not None:
        objects = await Checksum(objects_value[2]).resolution("plain")
        if not isinstance(objects, dict):
            objects = {}
    module_definition = _module_definition_from_payload(
        transformation_dict.get("__language__"),
        code,
        header,
        objects,
        compilation,
    )
    module_info = get_compiled_module_info(module_definition)
    digest = module_info["digest"]
    diagnostics["compiled_module_digest"] = digest
    diagnostics["compilation_context"] = compilation_context

    cached = _COMPILED_VALIDATION_CACHE.get(digest)
    if cached is None:
        module_path = module_info.get("path")
        if not module_path:
            cached = {
                "readelf_available": False,
                "readelf_error": "compiled module path unavailable",
                "job_contract_violations": [],
                "dynamic": {},
            }
        else:
            try:
                completed = subprocess.run(
                    ["readelf", "-d", module_path],
                    check=True,
                    capture_output=True,
                    text=True,
                    timeout=5,
                )
                dynamic = _parse_readelf_dynamic(
                    completed.stdout, module_dir=os.path.dirname(module_path)
                )
                resolved_needed = _resolve_needed_libraries(
                    dynamic["needed"],
                    module_dir=os.path.dirname(module_path),
                    conda_prefix=conda_prefix,
                    runpath_entries=dynamic["runpath"] + dynamic["rpath"],
                )
                cached_violations: set[str] = set()
                for entry in dynamic["rpath"]:
                    if not _path_allowed_for_contract(
                        entry, conda_prefix=conda_prefix, allow_system_roots=False
                    ):
                        cached_violations.add("rpath_outside_conda_prefix")
                        break
                for entry in dynamic["runpath"]:
                    if not _path_allowed_for_contract(
                        entry, conda_prefix=conda_prefix, allow_system_roots=False
                    ):
                        cached_violations.add("runpath_outside_conda_prefix")
                        break
                for libname, resolved_path in resolved_needed.items():
                    if resolved_path is None or _allowlisted_library_name(libname):
                        continue
                    if not _path_allowed_for_contract(
                        resolved_path,
                        conda_prefix=conda_prefix,
                        allow_system_roots=False,
                    ):
                        cached_violations.add("native_link_outside_conda_prefix")
                        break
                cached = {
                    "readelf_available": True,
                    "module_path": module_path,
                    "dynamic": dynamic,
                    "resolved_needed": resolved_needed,
                    "job_contract_violations": sorted(cached_violations),
                }
            except Exception as exc:
                cached = {
                    "readelf_available": False,
                    "readelf_error": str(exc),
                    "job_contract_violations": [],
                    "dynamic": {},
                }
        _COMPILED_VALIDATION_CACHE[digest] = cached

    job_contract_violations.update(cached.get("job_contract_violations", []))
    diagnostics["readelf"] = cached

    ld_library_path = os.environ.get("LD_LIBRARY_PATH")
    if ld_library_path:
        diagnostics["ld_library_path_entries"] = [
            _normalize_path(item) for item in _split_path_like(ld_library_path)
        ]
        for entry in diagnostics["ld_library_path_entries"]:
            if not _path_allowed_for_contract(
                entry, conda_prefix=conda_prefix, allow_system_roots=False
            ):
                job_contract_violations.add("ld_library_path_outside_conda_prefix")
                break
    ld_preload = os.environ.get("LD_PRELOAD")
    if ld_preload:
        diagnostics["ld_preload_entries"] = [
            _normalize_path(item) for item in _split_preload(ld_preload)
        ]
        for entry in diagnostics["ld_preload_entries"]:
            libname = os.path.basename(entry)
            if _allowlisted_library_name(libname):
                continue
            if not _path_allowed_for_contract(
                entry, conda_prefix=conda_prefix, allow_system_roots=False
            ):
                job_contract_violations.add("ld_preload_outside_conda_prefix")
                break

    return {
        "job_contract_violations": sorted(job_contract_violations),
        "diagnostics": diagnostics,
    }


async def collect_compilation_runtime_metadata(
    transformation_dict: Dict[str, Any],
    tf_dunder: Dict[str, Any] | None,
) -> dict[str, Any]:
    compiled = bool(
        transformation_dict.get("__compiled__")
        or (isinstance(tf_dunder, dict) and tf_dunder.get("__compiled__"))
    )
    if not compiled:
        return {}

    from seamless_transformer.compiler import get_compiled_module_info

    code = await Checksum(transformation_dict.get("code")[2]).resolution("text")
    header = _resolve_dunder_value(transformation_dict, tf_dunder, "__header__", "text")
    compilation = _resolve_dunder_value(
        transformation_dict, tf_dunder, "__compilation__", "plain"
    )
    objects = {}
    objects_value = transformation_dict.get("objects")
    if objects_value is not None and objects_value[2] is not None:
        objects = await Checksum(objects_value[2]).resolution("plain")
        if not isinstance(objects, dict):
            objects = {}
    module_definition = _module_definition_from_payload(
        transformation_dict.get("__language__"),
        code,
        header,
        objects,
        compilation,
    )
    module_info = get_compiled_module_info(module_definition)
    compilation_time_seconds = module_info.get("compilation_time_seconds")
    if compilation_time_seconds is None:
        return {}
    return {"compilation_time_seconds": compilation_time_seconds}


def _validation_snapshot_key(
    execution: str,
    probe_context: dict[str, Any] | None,
    compilation_context: str | None,
) -> tuple:
    required_bucket_checksums = {}
    if isinstance(probe_context, dict):
        required_bucket_checksums = dict(
            probe_context.get("required_bucket_checksums", {}) or {}
        )
    return (
        execution,
        tuple(sorted(required_bucket_checksums.items())),
        compilation_context,
    )


async def build_validation_snapshot_checksum(
    transformation_dict: Dict[str, Any],
    tf_dunder: Dict[str, Any] | None,
    *,
    execution: str,
    probe_context: dict[str, Any] | None,
    compilation_context: str | None,
    bucket_contract_violations: list[str] | None,
    job_contract_violations: list[str] | None,
    job_validation_diagnostics: dict[str, Any] | None = None,
    runtime_metadata: dict[str, Any] | None = None,
) -> str | None:
    limit = _validation_snapshot_limit()
    if limit <= 0:
        return None
    if buffer_remote is None or not buffer_remote.has_write_server():
        return None

    key = _validation_snapshot_key(execution, probe_context, compilation_context)
    count = _VALIDATION_SNAPSHOT_COUNTS.get(key, 0)
    if count >= limit:
        return None
    runtime_metadata = dict(runtime_metadata or {})
    worker_execution_index = runtime_metadata.get("worker_execution_index")

    payload = {
        "schema_version": 1,
        "execution_mode": execution,
        "remote_target": _resolve_remote_target(execution),
        "language": transformation_dict.get("__language__", "python"),
        "compiled": bool(
            transformation_dict.get("__compiled__")
            or (isinstance(tf_dunder, dict) and tf_dunder.get("__compiled__"))
        ),
        "requested_cluster": get_selected_cluster(),
        "requested_queue": get_queue(get_selected_cluster()),
        "requested_node": get_node(),
        "probe_context": probe_context or {},
        "compilation_context": compilation_context,
        "bucket_contract_violations": sorted(set(bucket_contract_violations or [])),
        "job_contract_violations": sorted(set(job_contract_violations or [])),
        "job_validation_diagnostics": job_validation_diagnostics or {},
        "hostname": socket.gethostname(),
        "pid": _os.getpid(),
        "process_started_at": runtime_metadata.get(
            "process_started_at",
            _PROCESS_STARTED_AT.replace(microsecond=0)
            .isoformat()
            .replace("+00:00", "Z"),
        ),
        "process_create_time_epoch": runtime_metadata.get(
            "process_create_time_epoch", _process_create_time_epoch()
        ),
        "worker_execution_index": worker_execution_index,
        "worker_fresh_process": worker_execution_index == 1
        if worker_execution_index is not None
        else None,
        "cwd": os.getcwd(),
        "tempdir": tempfile.gettempdir(),
        "platform": {
            "python_version": platform.python_version(),
            "python_implementation": platform.python_implementation(),
            "python_executable": sys.executable,
            "system": platform.system(),
            "release": platform.release(),
            "machine": platform.machine(),
        },
        "environment": {
            key: _os.environ.get(key)
            for key in (
                "PATH",
                "PYTHONPATH",
                "LD_LIBRARY_PATH",
                "LD_PRELOAD",
                "CONDA_PREFIX",
                "CONDA_DEFAULT_ENV",
                "CUDA_VISIBLE_DEVICES",
            )
            if _os.environ.get(key) is not None
        },
        "sys_path": list(sys.path),
    }
    buffer = Buffer(payload, "plain")
    written = await buffer.write()
    if not written:
        return None
    _VALIDATION_SNAPSHOT_COUNTS[key] = count + 1
    return buffer.get_checksum().hex()


def build_execution_record(
    transformation_dict: Dict[str, Any],
    *,
    tf_checksum: Checksum,
    result_checksum: Checksum,
    tf_dunder: Dict[str, Any] | None,
    execution: str,
    started_at: str,
    finished_at: str,
    wall_time_seconds: float,
    cpu_user_seconds: float,
    cpu_system_seconds: float,
    probe_context: dict[str, Any] | None = None,
    bucket_contract_violations: list[str] | None = None,
    job_contract_violations: list[str] | None = None,
    compilation_context: str | None = None,
    validation_snapshot: str | None = None,
    runtime_metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    meta = transformation_dict.get("__meta__", {}) or {}
    if not isinstance(meta, dict):
        meta = {}
    env_checksum = transformation_dict.get("__env__")
    if env_checksum is None and isinstance(tf_dunder, dict):
        env_checksum = tf_dunder.get("__env__")
    if isinstance(env_checksum, Checksum):
        env_checksum = env_checksum.hex()
    elif env_checksum is not None:
        env_checksum = str(env_checksum)

    remote_target = _resolve_remote_target(execution)
    requested_cluster = get_selected_cluster()
    requested_queue = get_queue(requested_cluster)
    requested_node = get_node()
    language = transformation_dict.get("__language__", "python")
    if language not in ("python", "bash", "compiled"):
        if transformation_dict.get("__compiled__"):
            language = "compiled"
        else:
            language = "python"

    execution_envelope = {
        "requested_cluster": requested_cluster,
        "requested_queue": requested_queue,
        "requested_node": requested_node,
        "actual_remote_target": remote_target,
        "scratch": bool(meta.get("scratch", False)),
        "allow_input_fingertip": bool(meta.get("allow_input_fingertip", False)),
        "language_kind": language,
        "resolved_env_checksum": env_checksum,
        "active_tf_dunder_keys": sorted((tf_dunder or {}).keys()),
    }
    probe_context = probe_context or {}
    bucket_contract_violations = sorted(set(bucket_contract_violations or []))
    job_contract_violations = sorted(set(job_contract_violations or []))
    contract_violations = sorted(
        set(bucket_contract_violations) | set(job_contract_violations)
    )
    runtime_metadata = dict(runtime_metadata or {})
    required_bucket_checksums = dict(probe_context.get("required_bucket_checksums", {}))
    freshness = {
        "required_bucket_labels": dict(
            probe_context.get("required_bucket_labels", {})
        ),
        "required_bucket_checksums": required_bucket_checksums,
        "live_tokens": dict(probe_context.get("live_tokens", {})),
        "bucket_tokens": dict(probe_context.get("bucket_tokens", {})),
    }

    return {
        "schema_version": 1,
        "checksum_fields": [
            "node",
            "environment",
            "node_env",
            "queue",
            "queue_node",
            "compilation_context",
            "validation_snapshot",
        ],
        "tf_checksum": tf_checksum.hex(),
        "result_checksum": result_checksum.hex(),
        "seamless_version": _SEAMLESS_VERSION,
        "execution_mode": execution,
        "remote_target": remote_target,
        "node": required_bucket_checksums.get("node"),
        "environment": required_bucket_checksums.get("environment"),
        "node_env": required_bucket_checksums.get("node_env"),
        "queue": required_bucket_checksums.get("queue"),
        "queue_node": required_bucket_checksums.get("queue_node"),
        "execution_envelope": execution_envelope,
        "compilation_context": compilation_context,
        "freshness": freshness,
        "bucket_contract_violations": bucket_contract_violations,
        "job_contract_violations": job_contract_violations,
        "contract_violations": contract_violations,
        "validation_snapshot": validation_snapshot,
        "started_at": started_at,
        "finished_at": finished_at,
        "wall_time_seconds": wall_time_seconds,
        "cpu_time_user_seconds": cpu_user_seconds,
        "cpu_time_system_seconds": cpu_system_seconds,
        "memory_peak_bytes": runtime_metadata.get("memory_peak_bytes"),
        "gpu_memory_peak_bytes": runtime_metadata.get("gpu_memory_peak_bytes"),
        "input_total_bytes": None,
        "output_total_bytes": None,
        "compilation_time_seconds": runtime_metadata.get("compilation_time_seconds"),
        "hostname": runtime_metadata.get("hostname", socket.gethostname()),
        "pid": runtime_metadata.get("pid", _os.getpid()),
        "process_started_at": runtime_metadata.get(
            "process_started_at",
            _PROCESS_STARTED_AT.replace(microsecond=0)
            .isoformat()
            .replace("+00:00", "Z"),
        ),
        "process_create_time_epoch": runtime_metadata.get("process_create_time_epoch"),
        "worker_execution_index": runtime_metadata.get(
            "worker_execution_index",
            next(_EXECUTION_RECORD_COUNTER),
        ),
        "retry_count": runtime_metadata.get("retry_count", 0),
    }


def build_minimal_execution_record(
    *,
    tf_checksum: Checksum,
    result_checksum: Checksum,
    execution: str,
    wall_time_seconds: float,
    cpu_user_seconds: float,
    cpu_system_seconds: float,
    runtime_metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    runtime_metadata = dict(runtime_metadata or {})
    return {
        "schema_version": 1,
        "tf_checksum": tf_checksum.hex(),
        "result_checksum": result_checksum.hex(),
        "seamless_version": _SEAMLESS_VERSION,
        "execution_mode": execution,
        "remote_target": _resolve_remote_target(execution),
        "wall_time_seconds": wall_time_seconds,
        "cpu_time_user_seconds": cpu_user_seconds,
        "cpu_time_system_seconds": cpu_system_seconds,
        "memory_peak_bytes": runtime_metadata.get("memory_peak_bytes"),
        "gpu_memory_peak_bytes": runtime_metadata.get("gpu_memory_peak_bytes"),
    }


async def load_bucket_contract_violations(
    probe_context: dict[str, Any] | None,
) -> list[str]:
    if not isinstance(probe_context, dict):
        return []
    required_bucket_checksums = probe_context.get("required_bucket_checksums", {})
    if not isinstance(required_bucket_checksums, dict):
        return []
    violations: set[str] = set()
    for checksum_hex in required_bucket_checksums.values():
        if not checksum_hex:
            continue
        try:
            payload = await Checksum(checksum_hex).resolution("plain")
        except Exception:
            continue
        if not isinstance(payload, dict):
            continue
        contract_violations = payload.get("contract_violations")
        if not isinstance(contract_violations, list):
            continue
        for code in contract_violations:
            if isinstance(code, str) and code:
                violations.add(code)
    return sorted(violations)


async def _checksum_length(checksum_hex: str | None) -> int | None:
    if not checksum_hex:
        return None
    checksum = Checksum(checksum_hex)
    try:
        if buffer_remote is not None:
            lengths = await buffer_remote.get_buffer_lengths([checksum])
            if lengths and lengths[0] is not None:
                return int(lengths[0])
    except Exception:
        pass
    try:
        buffer = await checksum.resolution()
    except Exception:
        return None
    return len(buffer) if buffer is not None else None


async def compute_record_io_bytes(
    transformation_dict: Dict[str, Any], result_checksum: Checksum
) -> tuple[int | None, int | None]:
    input_total_bytes = 0
    seen: set[str] = set()
    inputs, _output_name, _output_celltype, _output_subcelltype = (
        get_transformation_inputs_output(transformation_dict)
    )
    as_ = transformation_dict.get("__as__", {})
    reverse_as = {mapped: original for original, mapped in as_.items()}
    for input_name in inputs:
        pinname = reverse_as.get(input_name, input_name)
        try:
            _celltype, _subcelltype, checksum_hex = transformation_dict[pinname]
        except Exception:
            continue
        if not checksum_hex:
            continue
        checksum_hex = Checksum(checksum_hex).hex()
        if checksum_hex in seen:
            continue
        seen.add(checksum_hex)
        length = await _checksum_length(checksum_hex)
        if length is None:
            input_total_bytes = None
            break
        input_total_bytes += length

    output_total_bytes = await _checksum_length(result_checksum.hex())
    return input_total_bytes, output_total_bytes


__all__ = [
    "_COMPILATION_CONTEXT_CACHE",
    "_COMPILED_VALIDATION_CACHE",
    "_GpuMemorySampler",
    "_PROCESS_STARTED_AT",
    "_VALIDATION_SNAPSHOT_COUNTS",
    "_current_umask",
    "_determinant_env_live",
    "_filesystem_facts_live",
    "_gpu_policy_live",
    "_normalize_job_validation_payload",
    "_canonical_path_entries",
    "_canonical_sys_path",
    "_process_create_time_epoch",
    "_read_proc_self_maps_paths",
    "_system_library_roots",
    "build_compilation_context_checksum",
    "build_execution_record",
    "build_minimal_execution_record",
    "build_validation_snapshot_checksum",
    "collect_compilation_runtime_metadata",
    "collect_job_validation",
    "compute_record_io_bytes",
    "load_bucket_contract_violations",
    "start_gpu_memory_sampler",
    "stop_gpu_memory_sampler",
]
