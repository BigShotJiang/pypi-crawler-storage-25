"""Submodule for handling pyGSTi circuits.

"""
import logging
from typing import List

from qcal.circuit import CircuitSet

logger = logging.getLogger(__name__)


__all__ = ('load_circuits',)


def load_circuits(circuits: List | str) -> CircuitSet:
    """Load pyGSTi circuits from a file.

    Args:
        circuits (List | str): list of pyGSTi circuits. This can also be a text
            file containing all of the circuits.

    Returns:
        CircuitSet: set of pyGSTi circuits.
    """
    from pygsti.io import read_circuit_list

    if isinstance(circuits, str):
        circuits = read_circuit_list(circuits)
        circuit_list = [circ.str for circ in circuits]
    elif isinstance(circuits, list):
        circuit_list = [circ.str for circ in circuits]

    cs = CircuitSet(circuits=circuits)
    cs['pygsti_circuit'] = circuit_list

    return cs

