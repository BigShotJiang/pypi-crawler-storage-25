import cv2
import matplotlib.pyplot as plt
img = cv2.imread(r"C:\Users\PARAS\Downloads\images.jpg")
# ----- Image Attributes -----
print("Size      :", img.size)
print("Dimensions:", img.ndim)
print("Dtype     :", img.dtype)
print("Shape     :", img.shape)

plt.subplot(2, 2, 1)
plt.imshow(img)
rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
plt.subplot(2, 2, 2)
plt.imshow(rgb)
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
plt.subplot(2, 2, 3)
plt.imshow(gray, cmap="gray")
hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
plt.subplot(2, 2, 4)
plt.imshow(hsv)
plt.show()
