import cv2
img1 = cv2.imread(r"")
img2 = cv2.imread(r"")

img2 = cv2.resize(img2, (img1.shape[1], img1.shape[0]))

# Arithmetic Operations
add_img = cv2.add(img1, img2)
sub_img = cv2.subtract(img1, img2)

# Bitwise Operations
or_img = cv2.bitwise_or(img1, img2)
and_img = cv2.bitwise_and(img1, img2)
xor_img = cv2.bitwise_xor(img1, img2)
not_img = cv2.bitwise_not(img1)

cv2.imshow("Original Image 1", img1)
cv2.imshow("Original Image 2", img2)
cv2.imshow("Addition", add_img)
cv2.imshow("Subtraction", sub_img)
cv2.imshow("Bitwise OR", or_img)
cv2.imshow("Bitwise AND", and_img)
cv2.imshow("Bitwise XOR", xor_img)
cv2.imshow("Bitwise NOT", not_img)
cv2.waitKey(0)
cv2.destroyAllWindows()