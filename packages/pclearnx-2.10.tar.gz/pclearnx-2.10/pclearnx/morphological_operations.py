import cv2
import numpy as np
import matplotlib.pyplot as plt

img  = cv2.imread(r"")
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
_, binr = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

#  Kernel 
kernel = np.ones((5, 5), np.uint8)
#  Morphological Operations 
invert          = cv2.bitwise_not(binr)
erosion         = cv2.erode(invert, kernel, iterations=1)
dilation        = cv2.dilate(invert, kernel, iterations=1)
opening         = cv2.morphologyEx(binr,   cv2.MORPH_OPEN,     kernel)
closing         = cv2.morphologyEx(binr,   cv2.MORPH_CLOSE,    kernel)
invert_gradient = cv2.morphologyEx(invert, cv2.MORPH_GRADIENT, kernel)
tophat          = cv2.morphologyEx(binr,   cv2.MORPH_TOPHAT,   kernel)

#  Display Results 
images = [img,     erosion,  dilation, opening,  closing,          invert_gradient, tophat]
titles = ["Orig.", "Erosion","Dilation","Opening","Closing","Inv. Gradient","Tophat"]
cmaps  = [None,    "gray",   "gray",   "gray",   "gray",           "gray",          "gray"]

fig, axs = plt.subplots(2, 4, figsize=(14, 7))

for ax, image, title, cmap in zip(axs.ravel(), images, titles, cmaps):
    display = cv2.cvtColor(image, cv2.COLOR_BGR2RGB) if cmap is None else image
    ax.imshow(display, cmap=cmap)
    ax.set_title(title)
    ax.axis("off")

axs[1, 3].axis("off")   
plt.tight_layout()
plt.show()
