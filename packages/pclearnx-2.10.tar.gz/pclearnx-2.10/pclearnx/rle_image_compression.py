import cv2
import numpy as np

#  Load & Flatten 
img    = cv2.imread(r"")
pixels = img.flatten()

#  RLE Encoding 
def rle_encode(pixels):
    rle = []
    prev, count = pixels[0], 1
    for pixel in pixels[1:]:
        if pixel == prev:
            count += 1
        else:
            rle.append((prev, count))
            prev, count = pixel, 1
    rle.append((prev, count))
    return rle

rle = rle_encode(pixels)

#  Results 
print("RLE Output (first 20 pairs):")
for pair in rle[:20]:
    print(f"  Pixel: {pair[0]:3d}  |  Run Length: {pair[1]}")

original_size   = len(pixels)
compressed_size = len(rle)
ratio           = compressed_size / original_size * 100

print(f"\nOriginal size   : {original_size} values")
print(f"Compressed size : {compressed_size} pairs")
print(f"Compression ratio: {ratio:.2f}%")
