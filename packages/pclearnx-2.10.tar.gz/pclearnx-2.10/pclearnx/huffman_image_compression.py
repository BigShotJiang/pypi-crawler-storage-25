from collections import Counter
import cv2
import heapq

img = cv2.imread(r"D:\Shinchan.png", cv2.IMREAD_GRAYSCALE)
pixels = img.flatten()
freq = Counter(pixels)
# Create Huffman Heap
heap = [[weight, [symbol, ""]] for symbol, weight in freq.items()]
heapq.heapify(heap)
# Build Huffman Tree
while len(heap) > 1:
    left = heapq.heappop(heap)
    right = heapq.heappop(heap)

    for pair in left[1:]:
        pair[1] = '0' + pair[1]

    for pair in right[1:]:
        pair[1] = '1' + pair[1]

    heapq.heappush(heap,
                   [left[0] + right[0]] + left[1:] + right[1:])


huffman_codes = sorted(heap[0][1:], key=lambda x: len(x[1]))

# Store codes in dictionary
code_dict = {symbol: code for symbol, code in huffman_codes}
# Encode image
encoded_image = ''.join(code_dict[pixel] for pixel in pixels)
# Display Results
print("Huffman Codes (First 10):")
for symbol, code in list(code_dict.items())[:10]:
    print(f"{symbol} : {code}")
# Size Comparison
original_size = len(pixels) * 8
compressed_size = len(encoded_image)
print("\nOriginal Size:", original_size, "bits")
print("Compressed Size:", compressed_size, "bits")