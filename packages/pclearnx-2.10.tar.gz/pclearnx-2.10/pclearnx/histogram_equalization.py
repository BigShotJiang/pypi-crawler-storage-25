import cv2
import matplotlib.pyplot as plt

img      = cv2.imread(r"")
gray     = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
equalized = cv2.equalizeHist(gray)

# ----- Display Original vs Equalized Images -----
fig, axs = plt.subplots(1, 2, figsize=(10, 4))

axs[0].imshow(gray,      cmap="gray");  axs[0].set_title("Original Grayscale"); axs[0].axis("off")
axs[1].imshow(equalized, cmap="gray");  axs[1].set_title("Equalized");          axs[1].axis("off")

plt.tight_layout()
plt.show()

# ----- Display Histograms -----
fig, axs = plt.subplots(1, 2, figsize=(10, 4))

axs[0].hist(gray.ravel(),      bins=256, range=[0, 256], color="blue")
axs[0].set_title("Original Histogram")
axs[0].set_xlabel("Pixel Intensity")
axs[0].set_ylabel("Frequency")

axs[1].hist(equalized.ravel(), bins=256, range=[0, 256], color="green")
axs[1].set_title("Equalized Histogram")
axs[1].set_xlabel("Pixel Intensity")
axs[1].set_ylabel("Frequency")

plt.tight_layout()
plt.show()
