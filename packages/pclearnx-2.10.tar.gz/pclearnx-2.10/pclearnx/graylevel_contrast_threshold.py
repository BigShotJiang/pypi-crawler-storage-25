import cv2
import numpy as np
import matplotlib.pyplot as plt

img = cv2.imread(r"", 0)
# Gray Level Slicing
gray_slice = np.where((img >= 100) & (img <= 180), 255, 0)
# Contrast Stretching
contrast = cv2.normalize(img, None, 0, 255, cv2.NORM_MINMAX)
# Thresholding
_, thresh = cv2.threshold(img, 127, 255, cv2.THRESH_BINARY)
# Display Images
titles = ["Original", "Gray Level Slicing",
          "Contrast Stretching", "Thresholding"]

images = [img, gray_slice, contrast, thresh]

for i in range(4):
    plt.subplot(2, 2, i + 1)
    plt.imshow(images[i], cmap='gray')
    plt.title(titles[i])
    plt.axis('off')

plt.tight_layout()
plt.show()