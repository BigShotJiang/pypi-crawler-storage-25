import cv2
import matplotlib.pyplot as plt

img = cv2.imread(r"C:\Users\PARAS\Downloads\picture.png")
img = cv2.resize(img, (500, 450))
blur = cv2.blur(img, (5, 5))
# Convert to grayscale
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
# Edge Detection
laplacian = cv2.Laplacian(gray, cv2.CV_64F)
sobelx = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
sobely = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)
# Display Blur
plt.subplot(1, 2, 1)
plt.imshow(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
plt.title("Original")
plt.axis('off')
plt.subplot(1, 2, 2)
plt.imshow(cv2.cvtColor(blur, cv2.COLOR_BGR2RGB))
plt.title("Blurred")
plt.axis('off')
plt.show()
# Display Edge Detection
titles = ["Laplacian", "Sobel X", "Sobel Y"]
images = [laplacian, sobelx, sobely]

for i in range(3):
    plt.subplot(1, 3, i + 1)
    plt.imshow(images[i], cmap='gray')
    plt.title(titles[i])
    plt.axis('off')

plt.show()