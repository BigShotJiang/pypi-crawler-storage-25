import numpy as np
import matplotlib.pyplot as plt

# ----- 1D, 2D, 3D Arrays -----
a1 = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])

a2 = np.array([[1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
               [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
               [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]])

a3 = np.array([[[1, 2, 3, 4, 5, 6, 7, 8, 9, 10], [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]],
               [[1, 2, 3, 4, 5, 6, 7, 8, 9, 10], [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]],
               [[1, 2, 3, 4, 5, 6, 7, 8, 9, 10], [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]]])

arrays = {"A (1D)": a1, "B (2D)": a2, "C (3D)": a3}

#  Attributes 
for name, arr in arrays.items():
    print(f"\n--- Array {name} ---")
    print(f"  Shape     : {arr.shape}")
    print(f"  Dimensions: {arr.ndim}")
    print(f"  Dtype     : {arr.dtype}")
    print(f"  Length    : {len(arr)}")

# Functions 
for name, arr in arrays.items():
    print(f"\n--- Stats {name} ---")
    print(f"  Sum   : {arr.sum()}")
    print(f"  Mean  : {arr.mean()}")
    print(f"  Argmin: {arr.argmin()}")
    print(f"  Argmax: {arr.argmax()}")

# Reshape examples
print("\nReshape A:", a1.reshape(10))
print("Reshape B:", a2.reshape(1, 30))
print("Reshape C:", a3.reshape(3, 2, 10))

# Special matrices
print("\nZeros:\n",    np.zeros((3, 3)))
print("Ones:\n",      np.ones((3, 3)))
print("Identity:\n",  np.identity(3))

#  Display a sample image 
img = plt.imread(r"")
plt.imshow(img)
plt.title("Original Image")
plt.axis("off")
plt.show()

#  Create a synthetic color-band image 
imgr = np.zeros((900, 900, 3), np.uint8)   # reduced size for speed
imgr[0:300]   = (229, 104,  14)
imgr[300:600] = (245, 220, 215)
imgr[600:900] = (150, 230, 165)

plt.imshow(imgr)
plt.title("Synthetic Color-Band Image")
plt.axis("off")
plt.show()
