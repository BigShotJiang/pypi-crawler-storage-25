# Changelog

## 0.5.0 (2026-04-30)

Full Changelog: [v0.4.0...v0.5.0](https://github.com/chamelaion/chamelaion-python/compare/v0.4.0...v0.5.0)

### Features

* **api:** manual updates ([62146ae](https://github.com/chamelaion/chamelaion-python/commit/62146ae0bfec60718fafd36777a735d6d75a052a))
* **api:** manual updates ([464553e](https://github.com/chamelaion/chamelaion-python/commit/464553ed87d4206936ab8a91509af0916fc54da5))
* support setting headers via env ([5b96dfa](https://github.com/chamelaion/chamelaion-python/commit/5b96dfacdb04a10b195a366ffd4fc6a5d0eaddf7))


### Bug Fixes

* use correct field name format for multipart file arrays ([7574a3f](https://github.com/chamelaion/chamelaion-python/commit/7574a3f9f52ab47a6dd755704d6b72954211a68f))

## 0.4.0 (2026-04-27)

Full Changelog: [v0.3.0...v0.4.0](https://github.com/chamelaion/chamelaion-python/compare/v0.3.0...v0.4.0)

### Features

* **api:** manual updates ([fd23098](https://github.com/chamelaion/chamelaion-python/commit/fd23098e79fec585bcb8c9f39435fa4e665abce3))


### Chores

* **internal:** more robust bootstrap script ([da4745c](https://github.com/chamelaion/chamelaion-python/commit/da4745ca39d7886f637a08c5b5ba6120aeb3e369))

## 0.3.0 (2026-04-20)

Full Changelog: [v0.2.0...v0.3.0](https://github.com/chamelaion/chamelaion-python/compare/v0.2.0...v0.3.0)

### Features

* **api:** manual updates ([532ff0c](https://github.com/chamelaion/chamelaion-python/commit/532ff0c5c71cab787c09cccc28b9dbbe03db2c9b))

## 0.2.0 (2026-04-18)

Full Changelog: [v0.1.2...v0.2.0](https://github.com/chamelaion/chamelaion-python/compare/v0.1.2...v0.2.0)

### Features

* **api:** manual updates ([e46b4a3](https://github.com/chamelaion/chamelaion-python/commit/e46b4a3f3b0cdb7ed16fcc03322813a82ff30863))


### Bug Fixes

* ensure file data are only sent as 1 parameter ([aa37256](https://github.com/chamelaion/chamelaion-python/commit/aa37256c60d57760b0fdd9dfd458d02251acc051))


### Performance Improvements

* **client:** optimize file structure copying in multipart requests ([be0a199](https://github.com/chamelaion/chamelaion-python/commit/be0a1996c5ab65b858b410c26bb388c1c3520e91))

## 0.1.2 (2026-04-08)

Full Changelog: [v0.1.1...v0.1.2](https://github.com/chamelaion/chamelaion-python/compare/v0.1.1...v0.1.2)

### Bug Fixes

* **client:** preserve hardcoded query params when merging with user params ([ae574db](https://github.com/chamelaion/chamelaion-python/commit/ae574db5a14014de1396e5328d84a210d88f490b))

## 0.1.1 (2026-04-02)

Full Changelog: [v0.1.0...v0.1.1](https://github.com/chamelaion/chamelaion-python/compare/v0.1.0...v0.1.1)

### Chores

* update SDK settings ([deb6a3c](https://github.com/chamelaion/chamelaion-python/commit/deb6a3cba95ef5ba01b628a571659cf58864aaa0))

## 0.1.0 (2026-04-02)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/chamelaion/chamelaion-python/compare/v0.0.1...v0.1.0)

### Features

* **api:** manual updates ([75e57de](https://github.com/chamelaion/chamelaion-python/commit/75e57deeecb72e592e20de0d181ef5ce4eee6e55))
* **internal:** implement indices array format for query and form serialization ([3504cf4](https://github.com/chamelaion/chamelaion-python/commit/3504cf4df4861acd47e384555a2c98a9a6867088))


### Chores

* **ci:** skip lint on metadata-only changes ([074bf75](https://github.com/chamelaion/chamelaion-python/commit/074bf752a841aa21f5a2ca1501873718a8650d2e))
* **internal:** update gitignore ([47302fe](https://github.com/chamelaion/chamelaion-python/commit/47302fe543b4933a8cd95a7a4325b3945864221e))
* update SDK settings ([0dc2a77](https://github.com/chamelaion/chamelaion-python/commit/0dc2a77a6780fc47806920b2548bedcc183c9c4c))
* update SDK settings ([62b9694](https://github.com/chamelaion/chamelaion-python/commit/62b969481ab13ff02ff8c1d0c36d8d306df2ee35))
* update SDK settings ([c5cc4b9](https://github.com/chamelaion/chamelaion-python/commit/c5cc4b95a097d263d9a858aab876b68ac38415a1))
* update SDK settings ([abde293](https://github.com/chamelaion/chamelaion-python/commit/abde2931f38426ee844b887bea5cf6852362acee))
* update SDK settings ([7d98646](https://github.com/chamelaion/chamelaion-python/commit/7d98646c510c2eee6898c0c527fb48db8c0857d5))
* update SDK settings ([dbbd35d](https://github.com/chamelaion/chamelaion-python/commit/dbbd35d9759ab9587e5b7bfab8ec9d30b5d449e4))
* update SDK settings ([a458712](https://github.com/chamelaion/chamelaion-python/commit/a458712907f3b85bd8e41190386e8e3896ddca2e))
