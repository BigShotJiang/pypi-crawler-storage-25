# Health

Types:

```python
from chamelaion.types import HealthCheckResponse
```

Methods:

- <code title="get /health">client.health.<a href="./src/chamelaion/resources/health.py">check</a>() -> <a href="./src/chamelaion/types/health_check_response.py">HealthCheckResponse</a></code>

# Users

Types:

```python
from chamelaion.types import UserRetrieveCurrentResponse
```

Methods:

- <code title="get /v1/users/me">client.users.<a href="./src/chamelaion/resources/users.py">retrieve_current</a>() -> <a href="./src/chamelaion/types/user_retrieve_current_response.py">UserRetrieveCurrentResponse</a></code>

# Lipsync

Types:

```python
from chamelaion.types import LipsyncGenerate
```

Methods:

- <code title="post /v1/lipsync/generate">client.lipsync.<a href="./src/chamelaion/resources/lipsync/lipsync.py">generate</a>(\*\*<a href="src/chamelaion/types/lipsync_generate_params.py">params</a>) -> <a href="./src/chamelaion/types/lipsync_generate.py">LipsyncGenerate</a></code>
- <code title="post /v1/lipsync/generate-with-media">client.lipsync.<a href="./src/chamelaion/resources/lipsync/lipsync.py">generate_with_media</a>(\*\*<a href="src/chamelaion/types/lipsync_generate_with_media_params.py">params</a>) -> <a href="./src/chamelaion/types/lipsync_generate.py">LipsyncGenerate</a></code>

## Requests

Types:

```python
from chamelaion.types.lipsync import LipsyncRequest, RequestListResponse
```

Methods:

- <code title="get /v1/lipsync/requests/{id}">client.lipsync.requests.<a href="./src/chamelaion/resources/lipsync/requests.py">retrieve</a>(id) -> <a href="./src/chamelaion/types/lipsync/lipsync_request.py">LipsyncRequest</a></code>
- <code title="get /v1/lipsync/requests">client.lipsync.requests.<a href="./src/chamelaion/resources/lipsync/requests.py">list</a>(\*\*<a href="src/chamelaion/types/lipsync/request_list_params.py">params</a>) -> <a href="./src/chamelaion/types/lipsync/request_list_response.py">RequestListResponse</a></code>
