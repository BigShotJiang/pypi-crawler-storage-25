# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Mapping, Iterable, cast

import httpx

from ...types import lipsync_generate_params, lipsync_generate_with_media_params
from ..._files import deepcopy_with_paths
from ..._types import Body, Omit, Query, Headers, NotGiven, FileTypes, omit, not_given
from ..._utils import extract_files, maybe_transform, async_maybe_transform
from .requests import (
    RequestsResource,
    AsyncRequestsResource,
    RequestsResourceWithRawResponse,
    AsyncRequestsResourceWithRawResponse,
    RequestsResourceWithStreamingResponse,
    AsyncRequestsResourceWithStreamingResponse,
)
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..._base_client import make_request_options
from ...types.lipsync_generate import LipsyncGenerate

__all__ = ["LipsyncResource", "AsyncLipsyncResource"]


class LipsyncResource(SyncAPIResource):
    """Endpoints for creating and retrieving lip sync requests."""

    @cached_property
    def requests(self) -> RequestsResource:
        """Endpoints for creating and retrieving lip sync requests."""
        return RequestsResource(self._client)

    @cached_property
    def with_raw_response(self) -> LipsyncResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/chamelaion/chamelaion-python#accessing-raw-response-data-eg-headers
        """
        return LipsyncResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> LipsyncResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/chamelaion/chamelaion-python#with_streaming_response
        """
        return LipsyncResourceWithStreamingResponse(self)

    def generate(
        self,
        *,
        inputs: Iterable[lipsync_generate_params.Input],
        disable_active_speaker_detection: bool | Omit = omit,
        reference_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> LipsyncGenerate:
        """Starts a lip sync job from exactly one remote video URL and one remote audio
        URL.

        The response includes a request identifier to poll later.

        Args:
          inputs: Exactly one video input and one audio input (order does not matter).

          disable_active_speaker_detection: Disable active speaker detection and use max-face lipsync preprocessing.

          reference_id: Optional client-provided identifier for later retrieval.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/v1/lipsync/generate",
            body=maybe_transform(
                {
                    "inputs": inputs,
                    "disable_active_speaker_detection": disable_active_speaker_detection,
                    "reference_id": reference_id,
                },
                lipsync_generate_params.LipsyncGenerateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=LipsyncGenerate,
        )

    def generate_with_media(
        self,
        *,
        audio: FileTypes,
        video: FileTypes,
        disable_active_speaker_detection: bool | Omit = omit,
        reference_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> LipsyncGenerate:
        """
        Starts a lip sync job by uploading one video file and one audio file as
        multipart form-data.

        Args:
          audio: Target audio file.

          video: Source video file.

          disable_active_speaker_detection: Disable active speaker detection and use max-face lipsync preprocessing.

          reference_id: Optional client-provided identifier for later retrieval.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        body = deepcopy_with_paths(
            {
                "audio": audio,
                "video": video,
                "disable_active_speaker_detection": disable_active_speaker_detection,
                "reference_id": reference_id,
            },
            [["video"], ["audio"]],
        )
        files = extract_files(cast(Mapping[str, object], body), paths=[["video"], ["audio"]])
        # It should be noted that the actual Content-Type header that will be
        # sent to the server will contain a `boundary` parameter, e.g.
        # multipart/form-data; boundary=---abc--
        extra_headers = {"Content-Type": "multipart/form-data", **(extra_headers or {})}
        return self._post(
            "/v1/lipsync/generate-with-media",
            body=maybe_transform(body, lipsync_generate_with_media_params.LipsyncGenerateWithMediaParams),
            files=files,
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=LipsyncGenerate,
        )


class AsyncLipsyncResource(AsyncAPIResource):
    """Endpoints for creating and retrieving lip sync requests."""

    @cached_property
    def requests(self) -> AsyncRequestsResource:
        """Endpoints for creating and retrieving lip sync requests."""
        return AsyncRequestsResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncLipsyncResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/chamelaion/chamelaion-python#accessing-raw-response-data-eg-headers
        """
        return AsyncLipsyncResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncLipsyncResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/chamelaion/chamelaion-python#with_streaming_response
        """
        return AsyncLipsyncResourceWithStreamingResponse(self)

    async def generate(
        self,
        *,
        inputs: Iterable[lipsync_generate_params.Input],
        disable_active_speaker_detection: bool | Omit = omit,
        reference_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> LipsyncGenerate:
        """Starts a lip sync job from exactly one remote video URL and one remote audio
        URL.

        The response includes a request identifier to poll later.

        Args:
          inputs: Exactly one video input and one audio input (order does not matter).

          disable_active_speaker_detection: Disable active speaker detection and use max-face lipsync preprocessing.

          reference_id: Optional client-provided identifier for later retrieval.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/v1/lipsync/generate",
            body=await async_maybe_transform(
                {
                    "inputs": inputs,
                    "disable_active_speaker_detection": disable_active_speaker_detection,
                    "reference_id": reference_id,
                },
                lipsync_generate_params.LipsyncGenerateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=LipsyncGenerate,
        )

    async def generate_with_media(
        self,
        *,
        audio: FileTypes,
        video: FileTypes,
        disable_active_speaker_detection: bool | Omit = omit,
        reference_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> LipsyncGenerate:
        """
        Starts a lip sync job by uploading one video file and one audio file as
        multipart form-data.

        Args:
          audio: Target audio file.

          video: Source video file.

          disable_active_speaker_detection: Disable active speaker detection and use max-face lipsync preprocessing.

          reference_id: Optional client-provided identifier for later retrieval.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        body = deepcopy_with_paths(
            {
                "audio": audio,
                "video": video,
                "disable_active_speaker_detection": disable_active_speaker_detection,
                "reference_id": reference_id,
            },
            [["video"], ["audio"]],
        )
        files = extract_files(cast(Mapping[str, object], body), paths=[["video"], ["audio"]])
        # It should be noted that the actual Content-Type header that will be
        # sent to the server will contain a `boundary` parameter, e.g.
        # multipart/form-data; boundary=---abc--
        extra_headers = {"Content-Type": "multipart/form-data", **(extra_headers or {})}
        return await self._post(
            "/v1/lipsync/generate-with-media",
            body=await async_maybe_transform(body, lipsync_generate_with_media_params.LipsyncGenerateWithMediaParams),
            files=files,
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=LipsyncGenerate,
        )


class LipsyncResourceWithRawResponse:
    def __init__(self, lipsync: LipsyncResource) -> None:
        self._lipsync = lipsync

        self.generate = to_raw_response_wrapper(
            lipsync.generate,
        )
        self.generate_with_media = to_raw_response_wrapper(
            lipsync.generate_with_media,
        )

    @cached_property
    def requests(self) -> RequestsResourceWithRawResponse:
        """Endpoints for creating and retrieving lip sync requests."""
        return RequestsResourceWithRawResponse(self._lipsync.requests)


class AsyncLipsyncResourceWithRawResponse:
    def __init__(self, lipsync: AsyncLipsyncResource) -> None:
        self._lipsync = lipsync

        self.generate = async_to_raw_response_wrapper(
            lipsync.generate,
        )
        self.generate_with_media = async_to_raw_response_wrapper(
            lipsync.generate_with_media,
        )

    @cached_property
    def requests(self) -> AsyncRequestsResourceWithRawResponse:
        """Endpoints for creating and retrieving lip sync requests."""
        return AsyncRequestsResourceWithRawResponse(self._lipsync.requests)


class LipsyncResourceWithStreamingResponse:
    def __init__(self, lipsync: LipsyncResource) -> None:
        self._lipsync = lipsync

        self.generate = to_streamed_response_wrapper(
            lipsync.generate,
        )
        self.generate_with_media = to_streamed_response_wrapper(
            lipsync.generate_with_media,
        )

    @cached_property
    def requests(self) -> RequestsResourceWithStreamingResponse:
        """Endpoints for creating and retrieving lip sync requests."""
        return RequestsResourceWithStreamingResponse(self._lipsync.requests)


class AsyncLipsyncResourceWithStreamingResponse:
    def __init__(self, lipsync: AsyncLipsyncResource) -> None:
        self._lipsync = lipsync

        self.generate = async_to_streamed_response_wrapper(
            lipsync.generate,
        )
        self.generate_with_media = async_to_streamed_response_wrapper(
            lipsync.generate_with_media,
        )

    @cached_property
    def requests(self) -> AsyncRequestsResourceWithStreamingResponse:
        """Endpoints for creating and retrieving lip sync requests."""
        return AsyncRequestsResourceWithStreamingResponse(self._lipsync.requests)
