# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from chamelaion import Chamelaion, AsyncChamelaion
from tests.utils import assert_matches_type
from chamelaion.types.lipsync import LipsyncRequest, RequestListResponse

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestRequests:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_retrieve(self, client: Chamelaion) -> None:
        request = client.lipsync.requests.retrieve(
            "6f82a2d8-a6d4-4e8a-a0fa-e8b09823a2d8",
        )
        assert_matches_type(LipsyncRequest, request, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_retrieve(self, client: Chamelaion) -> None:
        response = client.lipsync.requests.with_raw_response.retrieve(
            "6f82a2d8-a6d4-4e8a-a0fa-e8b09823a2d8",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        request = response.parse()
        assert_matches_type(LipsyncRequest, request, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_retrieve(self, client: Chamelaion) -> None:
        with client.lipsync.requests.with_streaming_response.retrieve(
            "6f82a2d8-a6d4-4e8a-a0fa-e8b09823a2d8",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            request = response.parse()
            assert_matches_type(LipsyncRequest, request, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_retrieve(self, client: Chamelaion) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.lipsync.requests.with_raw_response.retrieve(
                "",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list(self, client: Chamelaion) -> None:
        request = client.lipsync.requests.list()
        assert_matches_type(RequestListResponse, request, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list_with_all_params(self, client: Chamelaion) -> None:
        request = client.lipsync.requests.list(
            limit=20,
            offset=0,
            reference_id="batch-2026-04",
        )
        assert_matches_type(RequestListResponse, request, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_list(self, client: Chamelaion) -> None:
        response = client.lipsync.requests.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        request = response.parse()
        assert_matches_type(RequestListResponse, request, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_list(self, client: Chamelaion) -> None:
        with client.lipsync.requests.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            request = response.parse()
            assert_matches_type(RequestListResponse, request, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncRequests:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_retrieve(self, async_client: AsyncChamelaion) -> None:
        request = await async_client.lipsync.requests.retrieve(
            "6f82a2d8-a6d4-4e8a-a0fa-e8b09823a2d8",
        )
        assert_matches_type(LipsyncRequest, request, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_retrieve(self, async_client: AsyncChamelaion) -> None:
        response = await async_client.lipsync.requests.with_raw_response.retrieve(
            "6f82a2d8-a6d4-4e8a-a0fa-e8b09823a2d8",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        request = await response.parse()
        assert_matches_type(LipsyncRequest, request, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_retrieve(self, async_client: AsyncChamelaion) -> None:
        async with async_client.lipsync.requests.with_streaming_response.retrieve(
            "6f82a2d8-a6d4-4e8a-a0fa-e8b09823a2d8",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            request = await response.parse()
            assert_matches_type(LipsyncRequest, request, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_retrieve(self, async_client: AsyncChamelaion) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.lipsync.requests.with_raw_response.retrieve(
                "",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list(self, async_client: AsyncChamelaion) -> None:
        request = await async_client.lipsync.requests.list()
        assert_matches_type(RequestListResponse, request, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list_with_all_params(self, async_client: AsyncChamelaion) -> None:
        request = await async_client.lipsync.requests.list(
            limit=20,
            offset=0,
            reference_id="batch-2026-04",
        )
        assert_matches_type(RequestListResponse, request, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_list(self, async_client: AsyncChamelaion) -> None:
        response = await async_client.lipsync.requests.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        request = await response.parse()
        assert_matches_type(RequestListResponse, request, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncChamelaion) -> None:
        async with async_client.lipsync.requests.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            request = await response.parse()
            assert_matches_type(RequestListResponse, request, path=["response"])

        assert cast(Any, response.is_closed) is True
