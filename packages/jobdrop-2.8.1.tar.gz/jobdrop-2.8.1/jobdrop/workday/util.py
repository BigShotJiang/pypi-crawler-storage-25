from jobdrop.util import create_logger

log = create_logger("Workday")
