# DIMP - ID Generator

[![License](https://img.shields.io/github/license/dimpart/dimid-py)](https://github.com/dimpart/dimid-py/blob/master/LICENSE)
[![PRs Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen.svg)](https://github.com/dimpart/dimid-py/pulls)
[![Platform](https://img.shields.io/badge/Platform-Python%203-brightgreen.svg)](https://github.com/dimpart/dimid-py/wiki)
[![Issues](https://img.shields.io/github/issues/dimpart/dimid-py)](https://github.com/dimpart/dimid-py/issues)
[![Repo Size](https://img.shields.io/github/repo-size/dimpart/dimid-py)](https://github.com/dimpart/dimid-py/archive/refs/heads/main.zip)
[![Tags](https://img.shields.io/github/tag/dimpart/dimid-py)](https://github.com/dimpart/dimid-py/tags)
[![Version](https://img.shields.io/pypi/v/dimid)](https://pypi.org/project/dimid)

[![Watchers](https://img.shields.io/github/watchers/dimpart/dimid-py)](https://github.com/dimpart/dimid-py/watchers)
[![Forks](https://img.shields.io/github/forks/dimpart/dimid-py)](https://github.com/dimpart/dimid-py/forks)
[![Stars](https://img.shields.io/github/stars/dimpart/dimid-py)](https://github.com/dimpart/dimid-py/stargazers)
[![Followers](https://img.shields.io/github/followers/dimpart)](https://github.com/orgs/dimpart/followers)

## Dependencies

* Latest Versions

| Name | Version | Description |
|------|---------|-------------|
| [Ming Ke Ming (名可名)](https://github.com/dimchat/mkm-py) | [![Version](https://img.shields.io/pypi/v/mkm)](https://pypi.org/project/mkm) | Decentralized User Identity Authentication |
| [Dao Ke Dao (道可道)](https://github.com/dimchat/dkd-py) | [![Version](https://img.shields.io/pypi/v/dkd)](https://pypi.org/project/dkd) | Universal Message Module |
| [DIMP (去中心化通讯协议)](https://github.com/dimchat/core-py) | [![Version](https://img.shields.io/pypi/v/dimp)](https://pypi.org/project/dimp) | Decentralized Instant Messaging Protocol |
| [DIM SDK](https://github.com/dimchat/sdk-py) | [![Version](https://img.shields.io/pypi/v/dimsdk)](https://pypi.org/project/dimsdk) | Software Development Kit |
| [DIM Plugins](https://github.com/dimchat/plugins-py) | [![Version](https://img.shields.io/pypi/v/dimplugins)](https://pypi.org/project/dimplugins) | Cryptography & Account Plugins |

* setup.py

```
    install_requires=[
        'requests',        # 2.21.0

        # 'pycryptodome',  # 3.14.1
        # 'base58',  # 1.0.3
        # 'ecdsa',   # 0.16.1
        'dimplugins>=2.4.1',

        'dimsdk>=2.4.1',
        # 'dimp>=2.4.1',
        # 'dkd>=2.4.1',
        # 'mkm>=2.4.1',

        'startrek>=2.3.1',

        'aiou>=1.1.0',
    ]
```

Copyright &copy; 2026 Albert Moky
[![Followers](https://img.shields.io/github/followers/moky)](https://github.com/moky?tab=followers)
