# 🧙 Wizard.AI Python SDK

The official Python client for the [Wizard.AI API](https://wizardai.dpdns.org). 
Chat with JARVIS, ORACLE, Nerd, Fun, and more!

## ✨ Features

- 🎭 **7+ Personalities** - JARVIS, ORACLE, Nerd, Fun, Sarcastic, Fast, Normal
- 📡 **Streaming Support** - Real-time token-by-token responses
- 🔑 **Simple Authentication** - Just your API key
- 🐍 **Python 3.7+** - Works with all modern Python versions
- ⚡ **Fast & Lightweight** - Only depends on `requests`

## 📦 Installation

```bash
pip install wizard-ai