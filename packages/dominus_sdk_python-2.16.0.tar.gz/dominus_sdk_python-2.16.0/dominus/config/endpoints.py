"""
Dominus SDK Endpoints

Gateway URL for service routing.
JWT URL for authentication (JWT minting).
Logs URL for log ingestion.
Orchestrator URL for service calls (legacy).

Configuration:
    Set DOMINUS_GATEWAY_URL to override the gateway URL.
    Set DOMINUS_JWT_URL to override the JWT minting URL.
    Set DOMINUS_LOGS_URL to override the logs URL.
    Set DOMINUS_BASE_URL to override the orchestrator URL.
    Example: export DOMINUS_BASE_URL=http://localhost:5000

Usage:
    from dominus.config.endpoints import GATEWAY_URL, JWT_URL, LOGS_URL, get_gateway_url, get_jwt_url, get_logs_url
"""
import os

# Default URLs - Cloudflare Workers
_DEFAULT_GATEWAY_URL = "https://gateway.getdominus.app"
_DEFAULT_JWT_URL = "https://jwt.getdominus.app"
_DEFAULT_LOGS_URL = "https://logs.getdominus.app"
_DEFAULT_BASE_URL = "https://dominus-orchestrator-production-775398158805.us-east4.run.app"

# Gateway URL for service routing (can be overridden via DOMINUS_GATEWAY_URL)
GATEWAY_URL = os.environ.get("DOMINUS_GATEWAY_URL", _DEFAULT_GATEWAY_URL)

# JWT URL for authentication (can be overridden via DOMINUS_JWT_URL)
JWT_URL = os.environ.get("DOMINUS_JWT_URL", _DEFAULT_JWT_URL)

# Logs URL for log ingestion (can be overridden via DOMINUS_LOGS_URL)
LOGS_URL = os.environ.get("DOMINUS_LOGS_URL", _DEFAULT_LOGS_URL)

# Base URL for service calls (can be overridden via DOMINUS_BASE_URL environment variable)
BASE_URL = os.environ.get("DOMINUS_BASE_URL", _DEFAULT_BASE_URL)

# Legacy aliases (all point to orchestrator now) - DEPRECATED
SOVEREIGN_URL = BASE_URL  # Deprecated: use BASE_URL or get_gateway_url()
ARCHITECT_URL = BASE_URL
ORCHESTRATOR_URL = BASE_URL
WARDEN_URL = BASE_URL

# Proxy configuration (optional)
# DOMINUS_* variants take precedence over standard HTTP_PROXY/HTTPS_PROXY
HTTP_PROXY = os.environ.get("DOMINUS_HTTP_PROXY") or os.environ.get("HTTP_PROXY")
HTTPS_PROXY = os.environ.get("DOMINUS_HTTPS_PROXY") or os.environ.get("HTTPS_PROXY")


def get_proxy_config() -> str | None:
    """
    Get proxy URL for httpx clients.

    Returns a single proxy URL string for httpx's `proxy` parameter (0.28+),
    or None if no proxy is configured.

    Environment variables (in order of precedence):
        - DOMINUS_HTTPS_PROXY / DOMINUS_HTTP_PROXY (SDK-specific)
        - HTTPS_PROXY / HTTP_PROXY (standard)

    Returns:
        Proxy URL string or None.
    """
    return HTTPS_PROXY or HTTP_PROXY or None


def get_gateway_url() -> str:
    """
    Get the dominus-gateway base URL for service routing.

    Returns the value of DOMINUS_GATEWAY_URL environment variable if set,
    otherwise returns the default Cloudflare Worker URL.
    """
    return os.environ.get("DOMINUS_GATEWAY_URL", _DEFAULT_GATEWAY_URL)


def get_jwt_url() -> str:
    """
    Get the JWT worker URL for authentication (JWT minting/validation).

    Returns the value of DOMINUS_JWT_URL environment variable if set,
    otherwise returns the default Cloudflare Worker URL.
    """
    return os.environ.get("DOMINUS_JWT_URL", _DEFAULT_JWT_URL)


def get_logs_url() -> str:
    """
    Get the logs worker URL for log ingestion.

    Returns the value of DOMINUS_LOGS_URL environment variable if set,
    otherwise returns the default Cloudflare Worker URL.
    """
    return os.environ.get("DOMINUS_LOGS_URL", _DEFAULT_LOGS_URL)


def get_base_url() -> str:
    """
    Get the dominus-orchestrator base URL for service calls.

    Returns the value of DOMINUS_BASE_URL environment variable if set,
    otherwise returns the default production URL.
    """
    return os.environ.get("DOMINUS_BASE_URL", _DEFAULT_BASE_URL)


# DEPRECATED - use get_base_url()
def get_sovereign_url(environment: str = None) -> str:
    """Deprecated: Use get_base_url() instead. 'Sovereign' is the legacy name for the gateway."""
    return BASE_URL


def get_architect_url(environment: str = None) -> str:
    """Deprecated: Use get_base_url() instead."""
    return BASE_URL


def get_service_url(service: str, environment: str = None) -> str:
    """Deprecated: Use get_base_url() instead. All services are now consolidated."""
    return BASE_URL
