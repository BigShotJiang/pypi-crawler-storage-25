"""
Artifacts Namespace - Temporary artifact storage.

Provides auto-tiered artifact storage (Redis < 1MB, B2 >= 1MB)
with TTL-based expiration. Routes through gateway to artifact-worker.

Usage:
    from dominus import dominus

    # Store
    result = await dominus.artifacts.store(data="base64data...", ttl_seconds=7200)

    # Retrieve
    artifact = await dominus.artifacts.retrieve(result["key"])

    # List
    items = await dominus.artifacts.list(category="reports")

    # Delete
    await dominus.artifacts.delete(result["key"])
"""
from typing import Any, Dict, List, Optional, TYPE_CHECKING
from urllib.parse import quote, unquote

if TYPE_CHECKING:
    from ..start import Dominus


def _safe_string(value: Any) -> str:
    return str(value or "").strip()


ARTIFACT_REF_PREFIX = "ar://"
DISPLAY_REF_PREFIX = "art:r:"
ARTIFACT_ENVIRONMENTS = ("development", "staging", "production")


def build_artifact_ref(
    *,
    project_slug: Optional[str] = None,
    environment: str,
    namespace: Optional[str] = None,
    artifact_key: str,
    group: Optional[str] = None,
    owner: Optional[str] = None,
    kind: Optional[str] = None,
) -> Optional[str]:
    if group is not None or owner is not None or kind is not None:
        return build_v2_artifact_ref(
            group=group or "",
            owner=owner or "",
            environment=environment,
            kind=kind or "",
            artifact_key=artifact_key,
        )

    return build_legacy_artifact_ref(
        project_slug=project_slug or "",
        environment=environment,
        namespace=namespace or "",
        artifact_key=artifact_key,
    )


def build_v2_artifact_ref(
    *,
    group: str,
    owner: str,
    environment: str,
    kind: str,
    artifact_key: str,
) -> Optional[str]:
    normalized_group = _safe_string(group)
    normalized_owner = _safe_string(owner)
    normalized_environment = _safe_string(environment)
    normalized_kind = _safe_string(kind)
    normalized_key = _safe_string(artifact_key)
    if not all([normalized_group, normalized_owner, normalized_environment, normalized_kind, normalized_key]):
        return None
    if normalized_environment not in ARTIFACT_ENVIRONMENTS:
        return None

    return (
        f"{ARTIFACT_REF_PREFIX}"
        f"{quote(normalized_group, safe='')}/{quote(normalized_owner, safe='')}/"
        f"{quote(normalized_environment, safe='')}/{quote(normalized_kind, safe='')}/"
        f"{quote(normalized_key, safe='')}"
    )


def build_pinned_artifact_ref(
    *,
    group: str,
    owner: str,
    environment: str,
    kind: str,
    artifact_key: str,
    version: int,
) -> Optional[str]:
    if version < 1:
        return None
    ref = build_v2_artifact_ref(group=group, owner=owner, environment=environment, kind=kind, artifact_key=artifact_key)
    if not ref:
        return None
    return f"{ref}@v{version}"


def build_display_artifact_ref(artifact_key: str) -> Optional[str]:
    normalized_key = _safe_string(artifact_key)
    if not normalized_key:
        return None
    return f"{DISPLAY_REF_PREFIX}{normalized_key}"


def build_legacy_artifact_ref(
    *,
    project_slug: str,
    environment: str,
    namespace: str,
    artifact_key: str,
    version: Optional[int] = None,
) -> Optional[str]:
    normalized_namespace = _safe_string(namespace).lower()
    if normalized_namespace not in {"shared", "company", "conversation", "run"}:
        return None

    project_slug = _safe_string(project_slug)
    environment = _safe_string(environment)
    artifact_key = _safe_string(artifact_key)
    if not project_slug or not environment or not artifact_key:
        return None

    base = (
        f"{ARTIFACT_REF_PREFIX}"
        f"{quote(project_slug, safe='')}/{quote(environment, safe='')}/"
        f"{quote(normalized_namespace, safe='')}/{quote(artifact_key, safe='')}"
    )
    return f"{base}@v{version}" if version and version > 0 else base


def parse_artifact_ref(artifact_ref: str) -> Optional[Dict[str, Any]]:
    normalized = _safe_string(artifact_ref)
    if not normalized:
        return None
    if normalized.startswith(DISPLAY_REF_PREFIX):
        artifact_key = normalized[len(DISPLAY_REF_PREFIX):]
        if not artifact_key:
            return None
        return {
            "format": "display",
            "raw": normalized,
            "artifact_key": artifact_key,
        }
    if not normalized.startswith(ARTIFACT_REF_PREFIX):
        return None

    raw_path = normalized[len(ARTIFACT_REF_PREFIX):]
    path, suffix = _split_version_suffix(raw_path)
    parts = path.split("/")
    version = _parse_version_suffix(suffix)
    if suffix and version is None:
        return None

    if len(parts) == 5:
        group, owner, environment, kind, artifact_key = [unquote(part) for part in parts]
        if not group or not owner or not environment or not kind or not artifact_key:
            return None
        if environment not in ARTIFACT_ENVIRONMENTS:
            return None
        result = {
            "format": "v2",
            "raw": normalized,
            "group": group,
            "owner": owner,
            "environment": environment,
            "kind": kind,
            "artifact_key": artifact_key,
        }
        if version is not None:
            result["version"] = version
        return result

    if len(parts) == 4:
        project_slug, environment, namespace, artifact_key = [unquote(part) for part in parts]
        if namespace not in {"shared", "company", "conversation", "run"}:
            return None
        if not project_slug or not environment or not artifact_key:
            return None
        result = {
            "format": "v1",
            "raw": normalized,
            "project_slug": project_slug,
            "environment": environment,
            "namespace": namespace,
            "artifact_key": artifact_key,
        }
        if version is not None:
            result["version"] = version
        return result

    return None


def validate_artifact_address(address: Dict[str, str]) -> Dict[str, str]:
    group = _safe_string(address.get("group"))
    owner = _safe_string(address.get("owner"))
    environment = _safe_string(address.get("environment"))
    kind = _safe_string(address.get("kind"))
    artifact_key = _safe_string(address.get("artifact_key"))
    if not all([group, owner, environment, kind, artifact_key]):
        raise ValueError("artifact address fields are required")
    if environment not in ARTIFACT_ENVIRONMENTS:
        raise ValueError("environment must be one of development, staging, or production")
    return {
        "group": group,
        "owner": owner,
        "environment": environment,
        "kind": kind,
        "artifact_key": artifact_key,
    }


def try_parse_artifact_ref(artifact_ref: str) -> tuple[bool, Optional[Dict[str, Any]]]:
    parsed = parse_artifact_ref(artifact_ref)
    return parsed is not None, parsed


def is_artifact_ref(artifact_ref: str) -> bool:
    return parse_artifact_ref(artifact_ref) is not None


def is_pinned_artifact_ref(artifact_ref: Dict[str, Any]) -> bool:
    return artifact_ref.get("format") == "v2" and isinstance(artifact_ref.get("version"), int)


def is_head_artifact_ref(artifact_ref: Dict[str, Any]) -> bool:
    return artifact_ref.get("format") == "v2" and not is_pinned_artifact_ref(artifact_ref)


def is_legacy_artifact_ref(artifact_ref: Dict[str, Any]) -> bool:
    return artifact_ref.get("format") == "v1"


def is_display_artifact_ref(artifact_ref: Dict[str, Any]) -> bool:
    return artifact_ref.get("format") == "display"


def _split_version_suffix(value: str) -> tuple[str, Optional[str]]:
    if "@" not in value:
        return value, None
    path, suffix = value.split("@", 1)
    return path, suffix


def _parse_version_suffix(suffix: Optional[str]) -> Optional[int]:
    if not suffix:
        return None
    if not suffix.startswith("v") or not suffix[1:].isdigit():
        return None
    return int(suffix[1:])


class ArtifactsNamespace:
    """
    Artifact storage namespace.

    Auto-tiered: data < 1MB stored in Redis, >= 1MB in Backblaze B2.
    All operations route through gateway to artifact-worker.
    """

    def __init__(self, client: "Dominus"):
        self._client = client

    async def _api(
        self,
        endpoint: str,
        method: str = "POST",
        body: Optional[Dict[str, Any]] = None,
        timeout: float = 30.0,
    ) -> Dict[str, Any]:
        """Make gateway-routed request to artifact-worker."""
        return await self._client._request(
            endpoint=endpoint,
            method=method,
            body=body,
            use_gateway=True,
            timeout=timeout,
        )

    async def list(
        self,
        limit: int = 100,
        category: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        List artifacts for the current project/environment.

        Args:
            limit: Max items to return (default 100, max 500)
            category: Optional category filter

        Returns:
            {artifacts: [...], count: int, total_size_bytes: int}
        """
        body: Dict[str, Any] = {"limit": limit}
        if category:
            body["category"] = category
        return await self._api("/api/artifact/list", body=body)

    async def get_health(self) -> Dict[str, Any]:
        """Check artifact worker health."""
        return await self._api("/api/artifact/health", method="GET")

    async def store(
        self,
        data: str,
        key: Optional[str] = None,
        ttl_seconds: int = 3600,
        category: Optional[str] = None,
        content_type: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Store an artifact.

        Args:
            data: Base64-encoded data
            key: Optional caller-provided key (UUID generated if not provided)
            ttl_seconds: Time-to-live in seconds (default 3600)
            category: Optional category for organization

        Returns:
            {key, ref, storage_type, size_bytes, expires_at}
        """
        body: Dict[str, Any] = {
            "data": data,
            "ttl_seconds": ttl_seconds,
        }
        if key:
            body["key"] = key
        if category:
            body["category"] = category
        if content_type:
            body["content_type"] = content_type
        return await self._api("/api/artifact/store", body=body)

    async def retrieve(self, key: str) -> Dict[str, Any]:
        """
        Retrieve an artifact by key.

        Args:
            key: Artifact key

        Returns:
            {key, data, storage_type, size_bytes, expires_at}
        """
        return await self._api("/api/artifact/retrieve", body={"key": key})

    async def delete(self, key: str) -> Dict[str, Any]:
        """
        Delete an artifact by key.

        Args:
            key: Artifact key

        Returns:
            {deleted: bool, key: str}
        """
        return await self._api("/api/artifact/delete", body={"key": key})

    async def cleanup(
        self,
        force: bool = False,
        limit: int = 100,
    ) -> Dict[str, Any]:
        """
        Cleanup expired artifacts (admin only).

        Args:
            force: Skip throttle check
            limit: Max items to clean (default 100)

        Returns:
            {cleaned: int, skipped: bool}
        """
        body: Dict[str, Any] = {"limit": limit}
        if force:
            body["force"] = True
        return await self._api("/api/artifact/cleanup", body=body)

    def _selector_body(self, options: Dict[str, Any]) -> Dict[str, Any]:
        body: Dict[str, Any] = {}
        for key in ("ref", "bookmark_name", "group", "owner", "environment", "kind"):
            value = options.get(key)
            if value is not None and value != "":
                body[key] = value
        if options.get("artifact_key"):
            body["artifact_key"] = options["artifact_key"]
        if options.get("version") is not None:
            body["version"] = options["version"]
        return body

    async def store_v2(
        self,
        *,
        group: str,
        owner: str,
        environment: str,
        kind: str,
        artifact_key: str,
        data: str,
        ttl_seconds: Optional[int] = None,
        category: Optional[str] = None,
        content_type: Optional[str] = None,
    ) -> Dict[str, Any]:
        body: Dict[str, Any] = {
            "group": group,
            "owner": owner,
            "environment": environment,
            "kind": kind,
            "artifact_key": artifact_key,
            "data": data,
        }
        if ttl_seconds is not None:
            body["ttl_seconds"] = ttl_seconds
        if category:
            body["category"] = category
        if content_type:
            body["content_type"] = content_type
        return await self._api("/api/artifact/v2/store", body=body)

    async def store_addressed(
        self,
        *,
        group: str,
        owner: str,
        environment: str,
        kind: str,
        artifact_key: str,
        data: str,
        ttl_seconds: Optional[int] = None,
        category: Optional[str] = None,
        content_type: Optional[str] = None,
    ) -> Dict[str, Any]:
        return await self.store_v2(
            group=group,
            owner=owner,
            environment=environment,
            kind=kind,
            artifact_key=artifact_key,
            data=data,
            ttl_seconds=ttl_seconds,
            category=category,
            content_type=content_type,
        )

    async def retrieve_v2(self, **selector: Any) -> Dict[str, Any]:
        return await self._api("/api/artifact/v2/retrieve", body=self._selector_body(selector))

    async def head_v2(self, **selector: Any) -> Dict[str, Any]:
        return await self._api("/api/artifact/v2/head", body=self._selector_body(selector))

    async def head(self, **selector: Any) -> Dict[str, Any]:
        return await self.head_v2(**selector)

    async def compare_v2(
        self,
        *,
        left: Dict[str, Any],
        right: Dict[str, Any],
        mode: str,
        request_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        body: Dict[str, Any] = {
            "left": self._selector_body(left),
            "right": self._selector_body(right),
            "mode": mode,
        }
        if request_id:
            body["request_id"] = request_id
        return await self._api("/api/artifact/v2/compare", body=body)

    async def compare(
        self,
        *,
        left: Dict[str, Any],
        right: Dict[str, Any],
        mode: str,
        request_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        return await self.compare_v2(left=left, right=right, mode=mode, request_id=request_id)

    async def compare_complete_v2(self, **body: Any) -> Dict[str, Any]:
        return await self._api("/api/artifact/v2/compare/complete", body=body)

    async def compare_complete(self, **body: Any) -> Dict[str, Any]:
        return await self.compare_complete_v2(**body)

    async def bookmark_set_v2(
        self,
        *,
        bookmark_name: str,
        sticky_retention: bool = False,
        ttl_seconds: Optional[int] = None,
        **selector: Any,
    ) -> Dict[str, Any]:
        body = self._selector_body(selector)
        body["bookmark_name"] = bookmark_name
        if sticky_retention:
            body["sticky_retention"] = True
        if ttl_seconds is not None:
            body["ttl_seconds"] = ttl_seconds
        return await self._api("/api/artifact/v2/bookmark/set", body=body)

    async def bookmark_set(
        self,
        *,
        bookmark_name: str,
        sticky_retention: bool = False,
        ttl_seconds: Optional[int] = None,
        **selector: Any,
    ) -> Dict[str, Any]:
        return await self.bookmark_set_v2(
            bookmark_name=bookmark_name,
            sticky_retention=sticky_retention,
            ttl_seconds=ttl_seconds,
            **selector,
        )

    async def set_bookmark(
        self,
        *,
        bookmark_name: str,
        sticky_retention: bool = False,
        ttl_seconds: Optional[int] = None,
        **selector: Any,
    ) -> Dict[str, Any]:
        return await self.bookmark_set(
            bookmark_name=bookmark_name,
            sticky_retention=sticky_retention,
            ttl_seconds=ttl_seconds,
            **selector,
        )

    async def bookmark_delete_v2(self, *, bookmark_name: str, **selector: Any) -> Dict[str, Any]:
        body = self._selector_body(selector)
        body["bookmark_name"] = bookmark_name
        return await self._api("/api/artifact/v2/bookmark/delete", body=body)

    async def bookmark_delete(self, *, bookmark_name: str, **selector: Any) -> Dict[str, Any]:
        return await self.bookmark_delete_v2(bookmark_name=bookmark_name, **selector)

    async def delete_bookmark(self, *, bookmark_name: str, **selector: Any) -> Dict[str, Any]:
        return await self.bookmark_delete(bookmark_name=bookmark_name, **selector)

    async def watch_v2(
        self,
        *,
        watcher_name: str,
        trigger_rule: str,
        target: str,
        target_payload: Optional[Dict[str, Any]] = None,
        ttl_seconds: Optional[int] = None,
        **selector: Any,
    ) -> Dict[str, Any]:
        body = self._selector_body(selector)
        body["watcher_name"] = watcher_name
        body["trigger_rule"] = trigger_rule
        body["target"] = target
        if target_payload:
            body["target_payload"] = target_payload
        if ttl_seconds is not None:
            body["ttl_seconds"] = ttl_seconds
        return await self._api("/api/artifact/v2/watch", body=body)

    async def watch(
        self,
        *,
        watcher_name: str,
        trigger_rule: str,
        target: str,
        target_payload: Optional[Dict[str, Any]] = None,
        ttl_seconds: Optional[int] = None,
        **selector: Any,
    ) -> Dict[str, Any]:
        return await self.watch_v2(
            watcher_name=watcher_name,
            trigger_rule=trigger_rule,
            target=target,
            target_payload=target_payload,
            ttl_seconds=ttl_seconds,
            **selector,
        )

    async def unwatch_v2(self, *, watcher_name: str, **selector: Any) -> Dict[str, Any]:
        body = self._selector_body(selector)
        body["watcher_name"] = watcher_name
        return await self._api("/api/artifact/v2/unwatch", body=body)

    async def unwatch(self, *, watcher_name: str, **selector: Any) -> Dict[str, Any]:
        return await self.unwatch_v2(watcher_name=watcher_name, **selector)

    async def list_v2(self, limit: int = 100, include_tombstoned: bool = False, **selector: Any) -> Dict[str, Any]:
        body = self._selector_body(selector)
        body["limit"] = limit
        if include_tombstoned:
            body["include_tombstoned"] = True
        return await self._api("/api/artifact/v2/list", body=body)

    async def delete_v2(self, *, tombstone: bool = False, delete_bookmarks: bool = False, **selector: Any) -> Dict[str, Any]:
        body = self._selector_body(selector)
        if tombstone:
            body["tombstone"] = True
        if delete_bookmarks:
            body["delete_bookmarks"] = True
        return await self._api("/api/artifact/v2/delete", body=body)
