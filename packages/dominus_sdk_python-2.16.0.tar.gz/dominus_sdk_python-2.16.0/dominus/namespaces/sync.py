"""
Sync Namespace - KV synchronization operations.

Provides manual trigger for KV sync (token + project metadata)
from database to Cloudflare KV. Routes through gateway to sync-worker.

The sync worker also runs automatically at 4AM UTC via cron.

Usage:
    from dominus import dominus

    # Trigger manual sync (admin only)
    result = await dominus.sync.trigger_sync()
    print(f"Synced {result['tokens_synced']} tokens, {result['projects_synced']} projects")

    # Health check
    health = await dominus.sync.get_health()
"""
from typing import Any, Dict, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from ..start import Dominus


class SyncNamespace:
    """
    KV sync namespace.

    Admin-only operations that synchronize token hashes and project
    metadata from the database into Cloudflare KV. Purges stale
    entries and re-seeds current data.
    """

    def __init__(self, client: "Dominus"):
        self._client = client

    async def _api(
        self,
        endpoint: str,
        method: str = "POST",
        body: Optional[Dict[str, Any]] = None,
        timeout: float = 30.0,
    ) -> Dict[str, Any]:
        """Make gateway-routed request to sync-worker."""
        return await self._client._request(
            endpoint=endpoint,
            method=method,
            body=body,
            use_gateway=True,
            timeout=timeout,
        )

    async def trigger_sync(self) -> Dict[str, Any]:
        """
        Trigger a manual KV sync. Requires admin system level.

        Synchronizes token hashes and project metadata from the database
        into Cloudflare KV. Purges stale entries and re-seeds current data.

        Returns:
            {tokens_synced, projects_synced, tokens_deleted,
             projects_deleted, errors, duration_ms, triggered_at}
        """
        return await self._api(
            "/api/sync/",
            body={},
            timeout=60.0,  # Sync can take up to a minute
        )

    async def get_health(self) -> Dict[str, Any]:
        """Check sync worker health."""
        return await self._api("/api/sync/health", method="GET")
