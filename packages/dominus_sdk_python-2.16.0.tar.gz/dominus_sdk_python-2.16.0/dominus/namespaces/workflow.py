"""
Workflow Namespace - Workflow management operations.

Provides CRUD operations for workflows, pipelines, and templates.
Routes through gateway to dominus-workflow-manager service.

Usage:
    from dominus import dominus

    # Workflow CRUD
    workflow = await dominus.workflow.save(
        name="My Workflow",
        yaml_content="name: My Workflow\nnodes: []",
        description="A test workflow"
    )
    workflows = await dominus.workflow.list()
    workflow = await dominus.workflow.get(workflow_id, include_content=True)
    await dominus.workflow.delete(workflow_id)

    # Pipelines (execution groups)
    pipeline = await dominus.workflow.create_pipeline(
        name="Intake Pipeline",
        description="Patient intake workflow sequence"
    )
    await dominus.workflow.add_to_pipeline(pipeline_id, workflow_id)
    pipelines = await dominus.workflow.list_pipelines()

    # Templates
    templates = await dominus.workflow.list_templates()
    await dominus.workflow.copy_template(template_id)

    # Saved-workflow lifecycle
    run = await dominus.workflow.create_run(workflow_id=workflow_id, context={"key": "value"})
    await dominus.workflow.validate_run(run["run_id"])
    result = await dominus.workflow.start_run(run["run_id"], mode="async")
"""
from typing import Any, Dict, List, Optional, TYPE_CHECKING
from urllib.parse import urlencode

if TYPE_CHECKING:
    from ..start import Dominus


class WorkflowNamespace:
    """
    Workflow management namespace.

    Provides operations for workflow CRUD, pipelines, templates,
    and the saved-workflow run lifecycle via the dominus-workflow-manager service.
    """

    def __init__(self, client: "Dominus"):
        self._client = client

    @staticmethod
    def _is_workflow_ref(value: Optional[str]) -> bool:
        return str(value or "").strip().startswith("wf://")

    @classmethod
    def _workflow_lookup_endpoint(
        cls,
        workflow_id_or_ref: str,
        include_content: bool = False,
    ) -> str:
        if cls._is_workflow_ref(workflow_id_or_ref):
            return "/api/workflow/workflows/by-ref?" + urlencode({
                "workflow_ref": workflow_id_or_ref,
                "include_content": "true" if include_content else "false",
            })

        endpoint = f"/api/workflow/workflows/{workflow_id_or_ref}"
        if include_content:
            endpoint += "?include_content=true"
        return endpoint

    @staticmethod
    def _workflow_identifier_body(
        workflow_id: Optional[str] = None,
        workflow_ref: Optional[str] = None,
    ) -> Dict[str, Any]:
        if workflow_ref and str(workflow_ref).strip():
            return {"workflow_ref": str(workflow_ref).strip()}
        if WorkflowNamespace._is_workflow_ref(workflow_id):
            return {"workflow_ref": str(workflow_id).strip()}
        if workflow_id and str(workflow_id).strip():
            return {"workflow_id": str(workflow_id).strip()}
        raise ValueError("workflow_id or workflow_ref is required")

    async def _api(
        self,
        endpoint: str,
        method: str = "POST",
        body: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """Make gateway-routed API request to workflow-manager."""
        return await self._client._request(
            endpoint=endpoint,
            method=method,
            body=body,
            use_gateway=True
        )

    # ========================================
    # Workflow CRUD
    # ========================================

    async def save(
        self,
        name: str,
        yaml_content: str,
        workflow_id: Optional[str] = None,
        tenant_slug: Optional[str] = None,
        description: Optional[str] = None,
        pipeline_id: Optional[str] = None,
        tags: Optional[List[str]] = None,
        is_template: bool = False,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Save a workflow (create or update).

        Args:
            name: Workflow display name
            yaml_content: YAML workflow definition
            workflow_id: Optional ID for updates (omit for create)
            tenant_slug: Optional tenant scope
            description: Optional description
            pipeline_id: Optional pipeline to assign
            tags: Optional list of tags
            is_template: Whether this is a template
            metadata: Optional builder-owned authoring metadata

        Returns:
            Dict with workflow metadata
        """
        body: Dict[str, Any] = {
            "name": name,
            "yaml_content": yaml_content,
        }
        if workflow_id:
            body["workflow_id"] = workflow_id
        if tenant_slug:
            body["tenant_slug"] = tenant_slug
        if description:
            body["description"] = description
        if pipeline_id:
            body["pipeline_id"] = pipeline_id
        if tags:
            body["tags"] = tags
        if is_template:
            body["is_template"] = is_template
        if metadata:
            body["metadata"] = metadata

        return await self._api(
            endpoint="/api/workflow/workflows",
            body=body
        )

    async def get(
        self,
        workflow_id: str,
        include_content: bool = False
    ) -> Dict[str, Any]:
        """
        Get a workflow by UUID or stable workflow_ref.

        Args:
            workflow_id: Workflow UUID or workflow_ref
            include_content: Whether to include YAML content

        Returns:
            Dict with workflow metadata and optionally content
        """
        endpoint = self._workflow_lookup_endpoint(workflow_id, include_content=include_content)
        return await self._api(endpoint=endpoint, method="GET")

    async def get_by_ref(
        self,
        workflow_ref: str,
        include_content: bool = False,
    ) -> Dict[str, Any]:
        """
        Get a workflow by stable workflow_ref.
        """
        return await self.get(workflow_ref, include_content=include_content)

    async def list(
        self,
        tenant_slug: Optional[str] = None,
        pipeline_id: Optional[str] = None,
        tags: Optional[List[str]] = None,
        is_template: Optional[bool] = None,
        search: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> List[Dict[str, Any]]:
        """
        List workflows.

        Args:
            tenant_slug: Filter by tenant
            pipeline_id: Filter by pipeline
            tags: Filter by tags (any match)
            is_template: Filter by template status
            search: Search in name/description
            limit: Max results
            offset: Pagination offset

        Returns:
            List of workflow metadata dicts
        """
        params = [f"limit={limit}", f"offset={offset}"]
        if tenant_slug:
            params.append(f"tenant_slug={tenant_slug}")
        if pipeline_id:
            params.append(f"pipeline_id={pipeline_id}")
        if is_template is not None:
            params.append(f"is_template={str(is_template).lower()}")
        if search:
            params.append(f"search={search}")

        query = "&".join(params)
        endpoint = f"/api/workflow/workflows?{query}" if query else "/api/workflow/workflows"

        result = await self._api(
            endpoint=endpoint,
            method="GET"
        )
        return result.get("workflows", result) if isinstance(result, dict) else result

    async def delete(self, workflow_id: str) -> Dict[str, Any]:
        """
        Delete a workflow.

        Args:
            workflow_id: Workflow UUID

        Returns:
            Dict with deletion status
        """
        return await self._api(
            endpoint=f"/api/workflow/workflows/{workflow_id}",
            method="DELETE"
        )

    # ========================================
    # Pipelines (Execution Groups)
    # ========================================

    async def create_pipeline(
        self,
        name: str,
        tenant_slug: Optional[str] = None,
        description: Optional[str] = None,
        definition: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Create a pipeline (execution group).

        Args:
            name: Pipeline display name
            tenant_slug: Optional tenant scope
            description: Optional description

        Returns:
            Dict with pipeline metadata
        """
        body: Dict[str, Any] = {"name": name}
        if tenant_slug:
            body["tenant_slug"] = tenant_slug
        if description:
            body["description"] = description
        if definition is not None:
            body["definition"] = definition

        return await self._api(
            endpoint="/api/workflow/pipelines",
            body=body
        )

    async def get_pipeline(
        self,
        pipeline_id: str,
        include_workflows: bool = False
    ) -> Dict[str, Any]:
        """
        Get a pipeline by ID.

        Args:
            pipeline_id: Pipeline UUID
            include_workflows: Whether to include workflow list

        Returns:
            Dict with pipeline metadata and optionally workflows
        """
        endpoint = f"/api/workflow/pipelines/{pipeline_id}"
        if include_workflows:
            endpoint += "?include_workflows=true"
        return await self._api(endpoint=endpoint, method="GET")

    async def list_pipelines(
        self,
        tenant_slug: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> List[Dict[str, Any]]:
        """
        List pipelines.

        Args:
            tenant_slug: Filter by tenant
            limit: Max results
            offset: Pagination offset

        Returns:
            List of pipeline metadata dicts
        """
        params = [f"limit={limit}", f"offset={offset}"]
        if tenant_slug:
            params.append(f"tenant_slug={tenant_slug}")

        query = "&".join(params)
        endpoint = f"/api/workflow/pipelines?{query}" if query else "/api/workflow/pipelines"

        result = await self._api(
            endpoint=endpoint,
            method="GET"
        )
        return result.get("pipelines", result) if isinstance(result, dict) else result

    async def update_pipeline(
        self,
        pipeline_id: str,
        *,
        name: Optional[str] = None,
        description: Optional[str] = None,
        definition: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Update pipeline metadata or graph definition.

        Args:
            pipeline_id: Pipeline UUID
            name: Optional replacement name
            description: Optional replacement description
            definition: Optional graph definition (None clears when explicitly sent)

        Returns:
            Dict with updated pipeline metadata
        """
        body: Dict[str, Any] = {}
        if name is not None:
            body["name"] = name
        if description is not None:
            body["description"] = description
        if definition is not None:
            body["definition"] = definition

        return await self._api(
            endpoint=f"/api/workflow/pipelines/{pipeline_id}",
            method="PUT",
            body=body,
        )

    async def delete_pipeline(self, pipeline_id: str) -> Dict[str, Any]:
        """
        Delete a pipeline.

        Args:
            pipeline_id: Pipeline UUID

        Returns:
            Dict with deletion status
        """
        return await self._api(
            endpoint=f"/api/workflow/pipelines/{pipeline_id}",
            method="DELETE"
        )

    async def add_to_pipeline(
        self,
        pipeline_id: str,
        workflow_id: str,
        position: Optional[int] = None,
    ) -> Dict[str, Any]:
        """
        Add a workflow to a pipeline.

        Args:
            pipeline_id: Pipeline UUID
            workflow_id: Workflow UUID
            position: Optional position in execution order

        Returns:
            Dict with operation status
        """
        body: Dict[str, Any] = {"workflow_id": workflow_id}
        if position is not None:
            body["position"] = position

        return await self._api(
            endpoint=f"/api/workflow/pipelines/{pipeline_id}/workflows",
            body=body
        )

    async def remove_from_pipeline(
        self,
        pipeline_id: str,
        workflow_id: str,
    ) -> Dict[str, Any]:
        """
        Remove a workflow from a pipeline.

        Args:
            pipeline_id: Pipeline UUID
            workflow_id: Workflow UUID

        Returns:
            Dict with operation status
        """
        return await self._api(
            endpoint=f"/api/workflow/pipelines/{pipeline_id}/workflows/{workflow_id}",
            method="DELETE"
        )

    async def reorder_pipeline(
        self,
        pipeline_id: str,
        workflow_order: List[str],
    ) -> Dict[str, Any]:
        """
        Reorder workflows in a pipeline.

        Args:
            pipeline_id: Pipeline UUID
            workflow_order: List of workflow IDs in desired order

        Returns:
            Dict with operation status
        """
        return await self._api(
            endpoint=f"/api/workflow/pipelines/{pipeline_id}/workflows/order",
            method="PUT",
            body={"workflow_order": workflow_order}
        )

    async def execute_pipeline(
        self,
        pipeline_id: str,
        *,
        mode: str = "async",
        context: Optional[Dict[str, Any]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        workflow_overrides: Optional[Dict[str, Any]] = None,
        continue_on_error: Optional[bool] = None,
        poll_interval_ms: Optional[int] = None,
        timeout_seconds: Optional[int] = None,
        save_events: Optional[bool] = None,
        resume_execution_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Execute a pipeline through workflow-manager's native orchestration runner.

        The returned execution_id is monitored with the existing execution-scoped
        helpers: status(), output(), messages(), events(), and cancel().
        """
        config: Dict[str, Any] = {"mode": mode}
        if continue_on_error is not None:
            config["continue_on_error"] = continue_on_error
        if poll_interval_ms is not None:
            config["poll_interval_ms"] = poll_interval_ms
        if timeout_seconds is not None:
            config["timeout_seconds"] = timeout_seconds
        if save_events is not None:
            config["save_events"] = save_events
        if resume_execution_id:
            config["resume_execution_id"] = resume_execution_id

        body: Dict[str, Any] = {"config": config}
        if context:
            body["context"] = context
        if metadata:
            body["metadata"] = metadata
        if workflow_overrides:
            body["workflow_overrides"] = workflow_overrides

        return await self._api(
            endpoint=f"/api/workflow/pipelines/{pipeline_id}/execute",
            body=body,
        )

    # ========================================
    # Templates
    # ========================================

    async def list_templates(
        self,
        limit: int = 100,
        offset: int = 0,
    ) -> List[Dict[str, Any]]:
        """
        List available templates.

        Args:
            limit: Max results
            offset: Pagination offset

        Returns:
            List of template metadata dicts
        """
        result = await self._api(
            endpoint="/api/workflow/templates",
            method="GET"
        )
        return result.get("templates", result) if isinstance(result, dict) else result

    async def get_template(
        self,
        template_id: str,
        include_content: bool = False
    ) -> Dict[str, Any]:
        """
        Get a template by ID.

        Args:
            template_id: Template UUID
            include_content: Whether to include YAML content

        Returns:
            Dict with template metadata and optionally content
        """
        endpoint = f"/api/workflow/templates/{template_id}"
        if include_content:
            endpoint += "?include_content=true"
        return await self._api(endpoint=endpoint, method="GET")

    async def copy_template(
        self,
        template_id: str,
        name: Optional[str] = None,
        tenant_slug: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Copy a template to create a new workflow.

        Args:
            template_id: Template UUID to copy
            name: Optional name for the new workflow
            tenant_slug: Optional tenant scope

        Returns:
            Dict with new workflow metadata
        """
        body: Dict[str, Any] = {}
        if name:
            body["name"] = name
        if tenant_slug:
            body["tenant_slug"] = tenant_slug

        return await self._api(
            endpoint=f"/api/workflow/templates/{template_id}/copy",
            body=body
        )

    @staticmethod
    def _build_start_config(
        *,
        mode: Optional[str] = None,
        timeout_seconds: Optional[int] = None,
        save_events: Optional[bool] = None,
        webhook_url: Optional[str] = None,
    ) -> Dict[str, Any]:
        config: Dict[str, Any] = {}
        if mode:
            config["mode"] = mode
        if timeout_seconds is not None:
            config["timeout_seconds"] = timeout_seconds
        if save_events is not None:
            config["save_events"] = save_events
        if webhook_url:
            config["webhook_url"] = webhook_url
        return config

    async def create_run(
        self,
        workflow_id: Optional[str] = None,
        *,
        workflow_ref: Optional[str] = None,
        run_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        context: Optional[Dict[str, Any]] = None,
        use_shared: Optional[bool] = None,
        shared_project_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Create a saved-workflow run through workflow-manager's lifecycle facade.

        Args:
            workflow_id: Workflow UUID
            workflow_ref: Stable workflow_ref for the saved workflow
        """
        body: Dict[str, Any] = self._workflow_identifier_body(
            workflow_id=workflow_id,
            workflow_ref=workflow_ref,
        )
        if run_id:
            body["run_id"] = run_id
        if metadata:
            body["metadata"] = metadata
        if context:
            body["context"] = context
        if use_shared is not None:
            body["use_shared"] = use_shared
        if shared_project_id:
            body["shared_project_id"] = shared_project_id

        return await self._api(
            endpoint="/api/workflow/runs",
            body=body,
        )

    async def get_run(self, run_id: str) -> Dict[str, Any]:
        """Get a saved-workflow run."""
        return await self._api(
            endpoint=f"/api/workflow/runs/{run_id}",
            method="GET",
        )

    async def get_manifest(self, run_id: str) -> Dict[str, Any]:
        """Get the artifact manifest for a saved-workflow run."""
        return await self._api(
            endpoint=f"/api/workflow/runs/{run_id}/manifest",
            method="GET",
        )

    async def register_artifact(
        self,
        run_id: str,
        artifact_key: str,
        *,
        artifact_id: Optional[str] = None,
        artifact_ref: Optional[str] = None,
        source_artifact_key: Optional[str] = None,
        source_namespace: Optional[str] = None,
        source_conversation_id: Optional[str] = None,
        source_project: Optional[str] = None,
        source_env: Optional[str] = None,
        source_project_id: Optional[str] = None,
        source_tenant: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        metadata_trusted: Optional[bool] = None,
    ) -> Dict[str, Any]:
        """
        Register a source artifact with a saved-workflow run.
        """
        body: Dict[str, Any] = {
            "artifact_key": artifact_key,
        }
        if artifact_id:
            body["artifact_id"] = artifact_id
        if artifact_ref:
            body["artifact_ref"] = artifact_ref
        if source_artifact_key:
            body["source_artifact_key"] = source_artifact_key
        if source_namespace:
            body["source_namespace"] = source_namespace
        if source_conversation_id:
            body["source_conversation_id"] = source_conversation_id
        if source_project:
            body["source_project"] = source_project
        if source_env:
            body["source_env"] = source_env
        if source_project_id:
            body["source_project_id"] = source_project_id
        if source_tenant:
            body["source_tenant"] = source_tenant
        if metadata:
            body["metadata"] = metadata
        if metadata_trusted is not None:
            body["metadata_trusted"] = metadata_trusted

        return await self._api(
            endpoint=f"/api/workflow/runs/{run_id}/artifacts",
            body=body,
        )

    async def validate_run(self, run_id: str) -> Dict[str, Any]:
        """Validate that a saved-workflow run is ready to start."""
        return await self._api(
            endpoint=f"/api/workflow/runs/{run_id}/validate",
            body={},
        )

    async def start_run(
        self,
        run_id: str,
        *,
        mode: str = "blocking",
        timeout_seconds: Optional[int] = None,
        save_events: Optional[bool] = None,
        webhook_url: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Start a saved-workflow run after validation."""
        return await self._api(
            endpoint=f"/api/workflow/runs/{run_id}/start",
            body={
                "config": self._build_start_config(
                    mode=mode,
                    timeout_seconds=timeout_seconds,
                    save_events=save_events,
                    webhook_url=webhook_url,
                )
            },
        )

    async def stream_start_run(
        self,
        run_id: str,
        *,
        timeout_seconds: Optional[int] = None,
        save_events: Optional[bool] = None,
        on_chunk: Optional[Any] = None,
    ):
        """Start a saved-workflow run with SSE streaming."""
        async for chunk in self._client._stream_request(
            endpoint=f"/api/workflow/runs/{run_id}/start",
            body={
                "config": self._build_start_config(
                    mode="streaming",
                    timeout_seconds=timeout_seconds,
                    save_events=save_events,
                )
            },
            on_chunk=on_chunk,
            timeout=float(timeout_seconds or 600),
            use_gateway=True,
        ):
            yield chunk

    async def status(self, execution_id: str) -> Dict[str, Any]:
        """Get saved-workflow execution status."""
        return await self._api(
            endpoint=f"/api/workflow/executions/{execution_id}/status",
            method="GET",
        )

    async def output(self, execution_id: str) -> Dict[str, Any]:
        """Get saved-workflow execution output."""
        return await self._api(
            endpoint=f"/api/workflow/executions/{execution_id}/output",
            method="GET",
        )

    async def messages(
        self,
        execution_id: str,
        *,
        count: int = 50,
    ) -> List[Dict[str, Any]]:
        """Get saved-workflow execution messages."""
        result = await self._api(
            endpoint=f"/api/workflow/executions/{execution_id}/messages?count={count}",
            method="GET",
        )
        return result.get("messages", result) if isinstance(result, dict) else result

    async def events(
        self,
        execution_id: str,
        *,
        from_id: Optional[str] = None,
        count: Optional[int] = None,
    ) -> List[Dict[str, Any]]:
        """Replay saved-workflow execution events."""
        query = []
        if from_id:
            query.append(f"from_id={from_id}")
        if count is not None:
            query.append(f"count={count}")
        endpoint = f"/api/workflow/executions/{execution_id}/events"
        if query:
            endpoint += f"?{'&'.join(query)}"
        result = await self._api(
            endpoint=endpoint,
            method="GET",
        )
        return result.get("events", result) if isinstance(result, dict) else result

    async def cancel(self, execution_id: str) -> Dict[str, Any]:
        """Cancel a saved-workflow execution."""
        return await self._api(
            endpoint=f"/api/workflow/executions/{execution_id}/cancel",
            body={},
        )
