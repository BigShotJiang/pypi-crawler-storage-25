import pytest

from dominus.namespaces.ai import WorkflowSubNamespace
from dominus.namespaces.workflow import WorkflowNamespace


class FakeClient:
    def __init__(self, stream_chunks=None):
        self.calls = []
        self.stream_calls = []
        self.stream_chunks = list(stream_chunks or [{"_event": "workflow_start"}])

    async def _request(
        self,
        endpoint,
        method="POST",
        body=None,
        user_token=None,
        use_gateway=False,
        timeout=30.0,
    ):
        self.calls.append(
            {
                "endpoint": endpoint,
                "method": method,
                "body": body,
                "user_token": user_token,
                "use_gateway": use_gateway,
                "timeout": timeout,
            }
        )
        return {"ok": True}

    async def _stream_request(
        self,
        endpoint,
        body=None,
        on_chunk=None,
        timeout=300.0,
        use_gateway=False,
    ):
        self.stream_calls.append(
            {
                "endpoint": endpoint,
                "body": body,
                "timeout": timeout,
                "use_gateway": use_gateway,
            }
        )
        for chunk in self.stream_chunks:
            if on_chunk:
                on_chunk(chunk)
            yield chunk


@pytest.mark.asyncio
async def test_ai_workflow_create_run_requires_inline_definition():
    namespace = WorkflowSubNamespace(FakeClient())

    with pytest.raises(ValueError, match="does not support saved workflow IDs"):
        await namespace.create_run(workflow_id="wf_saved_only")


@pytest.mark.asyncio
async def test_ai_workflow_execute_uses_truthful_raw_contract():
    client = FakeClient()
    namespace = WorkflowSubNamespace(client)

    await namespace.execute(
        workflow_definition={"workflow": {"name": "raw"}},
        initial_artifacts={"report_snapshot_current": "artifact-1"},
        conversation_id="conv-123",
        mode="async",
        timeout_seconds=45,
        save_events=True,
        environment="production",
        webhook_url="https://example.com/hook",
    )

    assert len(client.calls) == 1
    call = client.calls[0]
    assert call["endpoint"] == "/api/orchestration/execute"
    assert call["method"] == "POST"
    assert call["use_gateway"] is True
    assert call["body"] == {
        "workflow_definition": {"workflow": {"name": "raw"}},
        "initial_artifacts": {"report_snapshot_current": "artifact-1"},
        "conversation_id": "conv-123",
        "webhook_url": "https://example.com/hook",
        "config": {
            "mode": "async",
            "timeout_seconds": 45,
            "save_events": True,
            "environment": "production",
        },
    }


@pytest.mark.asyncio
async def test_ai_workflow_two_phase_lifecycle_routes_match_node_surface():
    client = FakeClient(stream_chunks=[{"_event": "node_start"}, {"_event": "workflow_complete"}])
    namespace = WorkflowSubNamespace(client)

    await namespace.create_run(
        workflow_definition={"workflow": {"name": "raw"}},
        run_id="run-123",
        metadata={"purpose": "processor-smoke"},
        environment="production",
    )
    await namespace.register_artifact(
        "run-123",
        "report_snapshot_current",
        "artifact-123",
        source_conversation_id="run-123",
        metadata={"report_ref": {"report_id": "r-1"}},
        metadata_trusted=True,
    )
    await namespace.validate_run("run-123")
    await namespace.start_run("run-123", mode="blocking", timeout_seconds=30, save_events=False)
    streamed = [chunk async for chunk in namespace.stream_start_run("run-123", timeout_seconds=60)]
    await namespace.messages("exec-123", count=25)
    await namespace.events("exec-123", from_id="evt-1", count=10)
    await namespace.status("exec-123")
    await namespace.output("exec-123")
    await namespace.cancel("exec-123")

    endpoints = [call["endpoint"] for call in client.calls]
    assert endpoints == [
        "/api/orchestration/runs",
        "/api/orchestration/runs/run-123/artifacts",
        "/api/orchestration/runs/run-123/validate",
        "/api/orchestration/runs/run-123/start",
        "/api/orchestration/messages/exec-123?count=25",
        "/api/orchestration/events/exec-123?from_id=evt-1&count=10",
        "/api/orchestration/status/exec-123",
        "/api/orchestration/output/exec-123",
        "/api/orchestration/cancel/exec-123",
    ]
    assert client.stream_calls == [
        {
            "endpoint": "/api/orchestration/runs/run-123/start",
            "body": {
                "config": {
                    "mode": "streaming",
                    "timeout_seconds": 60,
                }
            },
            "timeout": 60.0,
            "use_gateway": True,
        }
    ]
    assert streamed == [{"_event": "node_start"}, {"_event": "workflow_complete"}]


@pytest.mark.asyncio
async def test_saved_workflow_facade_lifecycle_contract_supports_processor_shape():
    client = FakeClient(stream_chunks=[{"_event": "workflow_start"}])
    namespace = WorkflowNamespace(client)

    await namespace.create_run(
        "wf-123",
        run_id="report-run-1",
        context={
            "report_ref": {
                "report_id": "report-1",
                "accession": "acc-1",
                "session_number": "2",
            }
        },
        metadata={"source": "processor"},
        use_shared=True,
        shared_project_id="fdcd5800-c735-4a45-90be-51b621bd4127",
    )
    await namespace.register_artifact(
        "report-run-1",
        "report_snapshot_current",
        artifact_ref="ar://carebridge-summit/production/company/carebridge%2Fcarebridge-summit%2Fproduction%2Freport-workflow%2Freport%2Freport-1%2Freport_snapshot_current.json",
        source_artifact_key="carebridge/carebridge-summit/production/report-workflow/report/report-1/report_snapshot_current.json",
        source_namespace="company",
        source_project="carebridge-summit",
        source_env="production",
        source_project_id="project-123",
        source_tenant="tenant-a",
        metadata={
            "report_ref": {
                "report_id": "report-1",
                "accession": "acc-1",
                "session_number": "2",
            },
            "freshness": {
                "state": "fresh",
                "age_seconds": 12,
            },
        },
        metadata_trusted=True,
    )
    await namespace.validate_run("report-run-1")
    await namespace.start_run("report-run-1", timeout_seconds=120)
    streamed = [chunk async for chunk in namespace.stream_start_run("report-run-1", timeout_seconds=90)]
    await namespace.messages("exec-456", count=15)
    await namespace.events("exec-456", from_id="evt-2", count=20)
    await namespace.status("exec-456")
    await namespace.output("exec-456")
    await namespace.cancel("exec-456")

    create_call = client.calls[0]
    assert create_call["endpoint"] == "/api/workflow/runs"
    assert create_call["body"] == {
        "workflow_id": "wf-123",
        "run_id": "report-run-1",
        "metadata": {"source": "processor"},
        "context": {
            "report_ref": {
                "report_id": "report-1",
                "accession": "acc-1",
                "session_number": "2",
            }
        },
        "use_shared": True,
        "shared_project_id": "fdcd5800-c735-4a45-90be-51b621bd4127",
    }

    register_call = client.calls[1]
    assert register_call["endpoint"] == "/api/workflow/runs/report-run-1/artifacts"
    assert register_call["body"] == {
        "artifact_key": "report_snapshot_current",
        "artifact_ref": "ar://carebridge-summit/production/company/carebridge%2Fcarebridge-summit%2Fproduction%2Freport-workflow%2Freport%2Freport-1%2Freport_snapshot_current.json",
        "source_artifact_key": "carebridge/carebridge-summit/production/report-workflow/report/report-1/report_snapshot_current.json",
        "source_namespace": "company",
        "source_project": "carebridge-summit",
        "source_env": "production",
        "source_project_id": "project-123",
        "source_tenant": "tenant-a",
        "metadata": {
            "report_ref": {
                "report_id": "report-1",
                "accession": "acc-1",
                "session_number": "2",
            },
            "freshness": {
                "state": "fresh",
                "age_seconds": 12,
            },
        },
        "metadata_trusted": True,
    }

    assert client.calls[-5]["endpoint"] == "/api/workflow/executions/exec-456/messages?count=15"
    assert client.calls[-4]["endpoint"] == "/api/workflow/executions/exec-456/events?from_id=evt-2&count=20"
    assert client.calls[-3]["endpoint"] == "/api/workflow/executions/exec-456/status"
    assert client.calls[-2]["endpoint"] == "/api/workflow/executions/exec-456/output"
    assert client.calls[-1]["endpoint"] == "/api/workflow/executions/exec-456/cancel"
    assert streamed == [{"_event": "workflow_start"}]


@pytest.mark.asyncio
async def test_execute_pipeline_routes_to_native_pipeline_runner():
    client = FakeClient()
    namespace = WorkflowNamespace(client)

    await namespace.execute_pipeline(
        "pipe-123",
        mode="async",
        context={"accession": "A-1"},
        workflow_overrides={
            "wf-123": {
                "artifacts": [{"artifact_key": "input", "artifact_id": "art-1"}],
            }
        },
        poll_interval_ms=500,
    )

    call = client.calls[0]
    assert call["endpoint"] == "/api/workflow/pipelines/pipe-123/execute"
    assert call["body"]["config"]["mode"] == "async"
    assert call["body"]["config"]["poll_interval_ms"] == 500
    assert call["body"]["context"] == {"accession": "A-1"}
    assert call["body"]["workflow_overrides"]["wf-123"]["artifacts"] == [
        {"artifact_key": "input", "artifact_id": "art-1"}
    ]


@pytest.mark.asyncio
async def test_update_pipeline_routes_to_put_surface():
    client = FakeClient()
    namespace = WorkflowNamespace(client)

    await namespace.update_pipeline(
        "pipe-123",
        name="Claims Pipeline",
        definition={
            "version": 2,
            "nodes": [{"id": "seed", "type": "deterministic", "operation": "set_value", "value": "ok"}],
        },
    )

    call = client.calls[0]
    assert call["endpoint"] == "/api/workflow/pipelines/pipe-123"
    assert call["method"] == "PUT"
    assert call["body"]["name"] == "Claims Pipeline"
    assert call["body"]["definition"]["version"] == 2


@pytest.mark.asyncio
async def test_execute_pipeline_forwards_resume_execution_id():
    client = FakeClient()
    namespace = WorkflowNamespace(client)

    await namespace.execute_pipeline(
        "pipe-123",
        mode="blocking",
        resume_execution_id="resume-1",
    )

    call = client.calls[0]
    assert call["body"]["config"]["resume_execution_id"] == "resume-1"
