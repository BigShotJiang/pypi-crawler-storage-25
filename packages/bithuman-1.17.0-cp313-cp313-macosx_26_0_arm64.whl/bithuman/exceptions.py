"""bithuman exception hierarchy.

Mirrors `bithuman.exceptions` (legacy v1.11.2) class-for-class so callers
that depend on `bithuman.exceptions.*` can swap import paths and keep the
same `except` chains. Inheritance graph:

    BithumanError
    ├── TokenError
    │   ├── TokenExpiredError
    │   ├── TokenValidationError
    │   ├── TokenRequestError
    │   └── AccountStatusError       (402 / 403)
    ├── ModelError
    │   ├── ModelNotFoundError
    │   ├── ModelLoadError
    │   ├── ModelSecurityError
    │   └── ExpressionModelNotSupported
    └── RuntimeNotReadyError
"""

from __future__ import annotations


class BithumanError(Exception):
    """Base exception for all bitHuman Runtime errors."""


# ---- token / auth ---------------------------------------------------


class TokenError(BithumanError):
    """Base exception for token-related errors."""


class TokenExpiredError(TokenError):
    """Raised when the JWT token has expired."""


class TokenValidationError(TokenError):
    """Raised when token validation fails (invalid signature, claims, etc.)."""


class TokenRequestError(TokenError):
    """Raised when a token request to the auth server fails."""


class AccountStatusError(TokenError):
    """Raised when the account has a billing/access issue (402, 403).

    Legacy `bithuman` makes this a subclass of TokenError (it surfaces
    out of the token-refresh path). We keep that inheritance for parity.
    """


# ---- model ---------------------------------------------------------


class ModelError(BithumanError):
    """Base exception for model-related errors."""


class ModelNotFoundError(ModelError):
    """Raised when the model file cannot be found."""


class ModelLoadError(ModelError):
    """Raised when model loading fails."""


class ModelSecurityError(ModelError):
    """Raised when a security restriction blocks model operations."""


class ExpressionModelNotSupported(ModelError):
    """Raised when an Expression (.imx with ``model_type == "expression"``)
    model is loaded against this Essence-only runtime.

    Expression models run on macOS with Apple Silicon (M3+, M5 recommended)
    via the native Swift SDK. Pure-Essence wrappers like this one reject
    Expression containers up front so callers can dispatch correctly.
    """


# ---- runtime --------------------------------------------------------


class RuntimeNotReadyError(BithumanError):
    """Raised when an operation is attempted before the runtime is ready."""


__all__ = [
    "BithumanError",
    "TokenError",
    "TokenExpiredError",
    "TokenValidationError",
    "TokenRequestError",
    "AccountStatusError",
    "ModelError",
    "ModelNotFoundError",
    "ModelLoadError",
    "ModelSecurityError",
    "ExpressionModelNotSupported",
    "RuntimeNotReadyError",
]
