// Python binding for libessence's C ABI (v0/v1).
//
// Wraps:
//   be_fixture_t   -> bithuman.Fixture
//   be_runtime_t   -> bithuman.Runtime
//
// MVP: macOS arm64. No COREML / NNAPI plumbing — preferred_ep defaults to
// BE_EP_CPU (canonical baseline). Errors translate to ValueError for
// INVALID_ARG and RuntimeError for everything else, with be_last_error_message()
// folded into the .args[0].

#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>
#include <pybind11/stl.h>

#include "bithuman/libessence_v0.h"

#include <stdexcept>
#include <string>

namespace py = pybind11;

namespace {

[[noreturn]] void raise_for_status(be_status s, const char* where) {
  const char* msg = be_last_error_message();
  std::string out = std::string(where) + ": status=" + std::to_string(static_cast<int>(s));
  if (msg && msg[0]) { out += " (\""; out += msg; out += "\")"; }
  if (s == BE_ERR_INVALID_ARG || s == BE_ERR_AUDIO_FORMAT || s == BE_ERR_BUFFER_TOO_SMALL) {
    throw py::value_error(out);
  }
  throw std::runtime_error(out);
}

inline void check(be_status s, const char* where) {
  if (s != BE_OK) raise_for_status(s, where);
}

// Wraps a be_fixture_t* with refcounting tied to the Python object lifetime.
struct Fixture {
  be_fixture_t* h = nullptr;
  be_fixture_info_t info{};

  Fixture(const std::string& path, int preferred_ep, int intra_op_threads) {
    be_fixture_options_t opts{};
    opts.abi_version = BE_ABI_VERSION;
    opts.preferred_ep = static_cast<be_ep>(preferred_ep);
    opts.intra_op_threads = static_cast<uint32_t>(intra_op_threads);
    check(be_fixture_load(path.c_str(), &opts, &h), "be_fixture_load");
    check(be_fixture_get_info(h, &info), "be_fixture_get_info");
  }
  Fixture(const Fixture&) = delete;
  Fixture& operator=(const Fixture&) = delete;
  ~Fixture() {
    if (h) be_fixture_release(h);
  }

  void refresh_info() { (void)be_fixture_get_info(h, &info); }
};

struct Runtime {
  be_runtime_t* h = nullptr;
  std::shared_ptr<Fixture> fixture;  // keep fixture alive
  size_t samples_per_tick = 0;
  size_t frame_bytes = 0;            // 0 until first compose triggers lazy_init_v1
  uint32_t embedding_dim = 0;

  explicit Runtime(std::shared_ptr<Fixture> fx) : fixture(std::move(fx)) {
    be_runtime_options_t ropts{};
    ropts.abi_version = BE_ABI_VERSION;
    check(be_runtime_create(fixture->h, &ropts, &h), "be_runtime_create");
    samples_per_tick = fixture->info.audio_samples_per_tick;
    embedding_dim = fixture->info.embedding_dim;
  }
  Runtime(const Runtime&) = delete;
  Runtime& operator=(const Runtime&) = delete;
  ~Runtime() { if (h) be_runtime_destroy(h); }

  // v0 path: audio → cluster_idx (+ optional embedding fill).
  uint32_t tick(py::array audio_in, py::object embedding_out) {
    auto pcm = py::array_t<float, py::array::c_style | py::array::forcecast>(audio_in);
    if (pcm.size() == 0) {
      throw py::value_error("tick: audio_pcm is empty");
    }

    float* emb_ptr = nullptr;
    size_t emb_cap = 0;
    py::array_t<float> emb_buf;
    if (!embedding_out.is_none()) {
      emb_buf = py::cast<py::array_t<float, py::array::c_style | py::array::forcecast>>(embedding_out);
      if (static_cast<uint32_t>(emb_buf.size()) < embedding_dim) {
        throw py::value_error("embedding_out smaller than embedding_dim");
      }
      emb_ptr = emb_buf.mutable_data();
      emb_cap = static_cast<size_t>(emb_buf.size());
    }

    be_tick_result_t tr{};
    be_status s = be_runtime_tick(h, pcm.data(), pcm.size(),
                                  emb_ptr, emb_cap, &tr);
    check(s, "be_runtime_tick");
    return tr.cluster_idx;
  }

  // v1.5 path: audio → composed BGR frame at a target size (1280x720 default).
  // Uses ABI v4 be_runtime_tick_compose_to_size — aspect-preserving fit
  // with letterbox/pillarbox.
  //
  // If `out` is provided, writes into it in place (zero-alloc hot path) and
  // returns just the cluster_idx (int). If `out` is None, allocates a fresh
  // (H, W, 3) uint8 array and returns (cluster_idx, bgr_frame) tuple.
  py::object tick_compose_to_size(py::array audio_in,
                                  int32_t  frame_idx_hint,
                                  uint32_t target_w,
                                  uint32_t target_h,
                                  py::object out_obj) {
    auto pcm = py::array_t<float, py::array::c_style | py::array::forcecast>(audio_in);
    if (pcm.size() == 0) {
      throw py::value_error("tick_compose_to_size: audio_pcm is empty");
    }
    const size_t cap = static_cast<size_t>(target_w) * target_h * 3;

    uint8_t* out_ptr = nullptr;
    py::array_t<uint8_t> out_arr;   // only populated when allocating
    py::buffer_info caller_buf;     // only valid when out_obj is set
    bool caller_buffer = !out_obj.is_none();

    if (caller_buffer) {
      // Accept any contiguous uint8 buffer big enough; do not enforce shape
      // so callers can use a flat byte buffer if they prefer.
      auto arr = py::cast<py::array_t<uint8_t, py::array::c_style>>(out_obj);
      if (static_cast<size_t>(arr.size()) < cap) {
        throw py::value_error("tick_compose_to_size: out buffer too small "
                              "(need target_w * target_h * 3 bytes)");
      }
      out_ptr = arr.mutable_data();
    } else {
      out_arr = py::array_t<uint8_t>({static_cast<py::ssize_t>(target_h),
                                      static_cast<py::ssize_t>(target_w),
                                      static_cast<py::ssize_t>(3)});
      out_ptr = out_arr.mutable_data();
    }

    be_compose_size_t sz{};
    sz.target_width  = target_w;
    sz.target_height = target_h;
    sz.fill_b = 0; sz.fill_g = 0; sz.fill_r = 0;

    be_compose_result_t cr{};
    be_status s;
    {
      py::gil_scoped_release release;
      s = be_runtime_tick_compose_to_size(h, pcm.data(), pcm.size(),
                                          frame_idx_hint, &sz,
                                          out_ptr, cap, &cr);
    }
    check(s, "be_runtime_tick_compose_to_size");
    if (caller_buffer) {
      return py::int_(cr.cluster_idx);
    }
    return py::make_tuple(cr.cluster_idx, std::move(out_arr));
  }

  // v1 path: audio → composed BGR frame at native source resolution.
  //
  // If `out` is provided, writes into it in place (zero-alloc hot path) and
  // returns just the cluster_idx (int). If `out` is None, allocates a fresh
  // (H, W, 3) uint8 array and returns (cluster_idx, bgr_frame) tuple.
  py::object tick_compose(py::array audio_in,
                          int32_t frame_idx_hint,
                          py::object out_obj) {
    auto pcm = py::array_t<float, py::array::c_style | py::array::forcecast>(audio_in);
    if (pcm.size() == 0) {
      throw py::value_error("tick_compose: audio_pcm is empty");
    }

    bool caller_buffer = !out_obj.is_none();
    bool first_call = (frame_bytes == 0);

    // When caller supplies a buffer we trust the fixture's current info if
    // available (the fixture is shared across runtimes so it's already been
    // populated by a prior compose); otherwise fall back to 1920×1080×3.
    size_t fixture_frame_bytes =
        static_cast<size_t>(fixture->info.frame_width) *
        fixture->info.frame_height * 3;
    size_t cap = frame_bytes ? frame_bytes
                : (fixture_frame_bytes ? fixture_frame_bytes
                                       : (1920ull * 1080 * 3));

    uint8_t* out_ptr = nullptr;
    std::vector<uint8_t> scratch;
    py::array_t<uint8_t> out_arr;     // only populated when allocating
    py::array_t<uint8_t, py::array::c_style> caller_arr;  // when caller-supplied

    if (caller_buffer) {
      caller_arr = py::cast<py::array_t<uint8_t, py::array::c_style>>(out_obj);
      // For the caller-buffer path we accept any buffer >= the *known* frame
      // size. If we don't know the frame size yet we accept >= 1920×1080×3.
      size_t need = fixture_frame_bytes ? fixture_frame_bytes : (1920ull * 1080 * 3);
      if (static_cast<size_t>(caller_arr.size()) < need) {
        throw py::value_error("tick_compose: out buffer too small "
                              "(need frame_width * frame_height * 3 bytes)");
      }
      cap = static_cast<size_t>(caller_arr.size());
      out_ptr = caller_arr.mutable_data();
    } else if (!first_call) {
      out_arr = py::array_t<uint8_t>({static_cast<py::ssize_t>(fixture->info.frame_height),
                                      static_cast<py::ssize_t>(fixture->info.frame_width),
                                      static_cast<py::ssize_t>(3)});
      out_ptr = out_arr.mutable_data();
    } else {
      scratch.resize(cap);
      out_ptr = scratch.data();
    }

    be_compose_result_t cr{};
    be_status s;
    {
      py::gil_scoped_release release;
      s = be_runtime_tick_compose(h, pcm.data(), pcm.size(),
                                  frame_idx_hint, out_ptr, cap, &cr);
    }
    check(s, "be_runtime_tick_compose");

    if (caller_buffer) {
      return py::int_(cr.cluster_idx);
    }
    if (first_call) {
      fixture->refresh_info();
      frame_bytes = static_cast<size_t>(fixture->info.frame_width) *
                    fixture->info.frame_height * 3;
      // copy scratch into a tight (H,W,3) array
      out_arr = py::array_t<uint8_t>({static_cast<py::ssize_t>(fixture->info.frame_height),
                                      static_cast<py::ssize_t>(fixture->info.frame_width),
                                      static_cast<py::ssize_t>(3)});
      std::memcpy(out_arr.mutable_data(), scratch.data(), frame_bytes);
    }
    return py::make_tuple(cr.cluster_idx, std::move(out_arr));
  }
};

}  // namespace

PYBIND11_MODULE(_core, m) {
  m.doc() = "Low-level Python wrapper around libessence (C ABI v2).";
  m.attr("__version__") = py::str(be_library_version());
  m.attr("__abi_version__") = py::int_(be_abi_version());

  // EP enum values (CPU only used in spike, but expose all for caller code).
  m.attr("EP_CPU")    = py::int_(static_cast<int>(BE_EP_CPU));
  m.attr("EP_AUTO")   = py::int_(static_cast<int>(BE_EP_AUTO));
  m.attr("EP_COREML") = py::int_(static_cast<int>(BE_EP_COREML));
  m.attr("EP_NNAPI")  = py::int_(static_cast<int>(BE_EP_NNAPI));
  m.attr("EP_QNN")    = py::int_(static_cast<int>(BE_EP_QNN));

  // ---- Auth / heartbeat -------------------------------------------------
  // Module-level functions wrapping the be_auth_* singleton ABI.
  m.attr("AUTH_UNCONFIGURED")    = py::int_(static_cast<int>(BE_AUTH_UNCONFIGURED));
  m.attr("AUTH_AUTHENTICATING")  = py::int_(static_cast<int>(BE_AUTH_AUTHENTICATING));
  m.attr("AUTH_OK")              = py::int_(static_cast<int>(BE_AUTH_OK));
  m.attr("AUTH_OFFLINE")         = py::int_(static_cast<int>(BE_AUTH_OFFLINE));
  m.attr("AUTH_FATAL_BALANCE")   = py::int_(static_cast<int>(BE_AUTH_FATAL_BALANCE));
  m.attr("AUTH_FATAL_SUSPENDED") = py::int_(static_cast<int>(BE_AUTH_FATAL_SUSPENDED));

  m.def("auth_init",
      [](const std::string& api_secret,
         const std::string& billing_type,
         const std::string& tags,
         const std::string& fingerprint,
         const std::string& endpoint,
         int interval_seconds,
         int offline_grace_seconds) {
        be_auth_config_t cfg{};
        cfg.abi_version          = BE_ABI_VERSION;
        cfg.api_secret           = api_secret.c_str();
        cfg.billing_type         = billing_type.c_str();
        cfg.tags                 = tags.c_str();
        cfg.fingerprint          = fingerprint.empty() ? nullptr : fingerprint.c_str();
        cfg.endpoint_url         = endpoint.empty()    ? nullptr : endpoint.c_str();
        cfg.interval_seconds        = interval_seconds;
        cfg.offline_grace_seconds   = offline_grace_seconds;
        check(be_auth_init(&cfg), "be_auth_init");
      },
      py::arg("api_secret"),
      py::arg("billing_type") = std::string("self-hosted-essence-model"),
      py::arg("tags") = std::string("python-wrapper"),
      py::arg("fingerprint") = std::string(""),
      py::arg("endpoint") = std::string(""),
      py::arg("interval_seconds") = 60,
      py::arg("offline_grace_seconds") = 300,
      "Configure the libessence auth client (singleton). Subsequent calls "
      "replace the config.");

  m.def("auth_authenticate",
      []() {
        be_status s = be_auth_authenticate();
        if (s == BE_ERR_AUTH_FATAL || s == BE_ERR_NO_AUTH) {
          throw std::runtime_error(std::string("auth_authenticate: ") + be_auth_last_error());
        }
        check(s, "be_auth_authenticate");
      },
      "Synchronous first heartbeat. Raises RuntimeError on 402/403 or network failure.");

  m.def("auth_start_heartbeat", []() { check(be_auth_start_heartbeat(), "be_auth_start_heartbeat"); });
  m.def("auth_stop_heartbeat",  []() { be_auth_stop_heartbeat(); });
  m.def("auth_state",           []() { return static_cast<int>(be_auth_get_state()); });
  m.def("auth_last_error",      []() { return std::string(be_auth_last_error()); });
  m.def("auth_shutdown",        []() { be_auth_shutdown(); });

  py::class_<Fixture, std::shared_ptr<Fixture>>(m, "Fixture")
      .def(py::init<const std::string&, int, int>(),
           py::arg("path"),
           py::arg("preferred_ep") = static_cast<int>(BE_EP_CPU),
           py::arg("intra_op_threads") = 1)
      .def_property_readonly("audio_sample_rate",
          [](Fixture& f){ return f.info.audio_sample_rate; })
      .def_property_readonly("audio_samples_per_tick",
          [](Fixture& f){ return f.info.audio_samples_per_tick; })
      .def_property_readonly("mel_bins",
          [](Fixture& f){ return f.info.mel_bins; })
      .def_property_readonly("mel_frames_per_chunk",
          [](Fixture& f){ return f.info.mel_frames_per_chunk; })
      .def_property_readonly("embedding_dim",
          [](Fixture& f){ return f.info.embedding_dim; })
      .def_property_readonly("cluster_count",
          [](Fixture& f){ return f.info.cluster_count; })
      .def_property_readonly("active_ep",
          [](Fixture& f){ return static_cast<int>(f.info.active_ep); })
      .def_property_readonly("frame_width",
          [](Fixture& f){ return f.info.frame_width; })
      .def_property_readonly("frame_height",
          [](Fixture& f){ return f.info.frame_height; })
      .def_property_readonly("source_frame_count",
          [](Fixture& f){ return f.info.source_frame_count; });

  py::class_<Runtime>(m, "Runtime")
      .def(py::init<std::shared_ptr<Fixture>>(), py::arg("fixture"))
      .def("tick", &Runtime::tick,
           py::arg("audio_pcm"), py::arg("embedding_out") = py::none(),
           "v0 path: returns cluster_idx (int). audio_pcm: float32 numpy "
           "array of length fixture.audio_samples_per_tick.")
      .def("tick_compose_to_size", &Runtime::tick_compose_to_size,
           py::arg("audio_pcm"), py::arg("frame_idx_hint") = -1,
           py::arg("target_w") = 1280u, py::arg("target_h") = 720u,
           py::arg("out") = py::none(),
           "v1.5 path (ABI v4+): aspect-preserve-fit composed BGR frame into "
           "(target_w, target_h). Default 1280x720, letterbox/pillarbox black. "
           "If `out` is a uint8 numpy buffer of at least target_w*target_h*3 "
           "bytes, writes into it in place and returns just cluster_idx (int). "
           "Otherwise allocates a fresh (target_h, target_w, 3) array and "
           "returns (cluster_idx, bgr_frame). Zero-alloc hot path: reuse the "
           "same `out` buffer across ticks.")
      .def("tick_compose", &Runtime::tick_compose,
           py::arg("audio_pcm"), py::arg("frame_idx_hint") = -1,
           py::arg("out") = py::none(),
           "v1 path: composed BGR frame at native source resolution. "
           "If `out` is a uint8 numpy buffer of at least frame_w*frame_h*3 "
           "bytes, writes into it in place and returns just cluster_idx (int). "
           "Otherwise allocates a fresh (H, W, 3) array and returns "
           "(cluster_idx, bgr_frame). Zero-alloc hot path: reuse the same "
           "`out` buffer across ticks.");

  // ABI v5: canonical audio decode + one-shot MP4 record.
  m.attr("ENCODER_QUALITY_LOW")    = py::int_(static_cast<int>(BE_QUALITY_LOW));
  m.attr("ENCODER_QUALITY_MEDIUM") = py::int_(static_cast<int>(BE_QUALITY_MEDIUM));
  m.attr("ENCODER_QUALITY_HIGH")   = py::int_(static_cast<int>(BE_QUALITY_HIGH));

  m.def("decode_audio_file",
      [](const std::string& path) -> py::array_t<float> {
        float* pcm = nullptr; size_t n = 0;
        check(be_audio_decode_file(path.c_str(), &pcm, &n), "be_audio_decode_file");
        auto arr = py::array_t<float>(n);
        if (n > 0) std::memcpy(arr.mutable_data(), pcm, n * sizeof(float));
        if (pcm) be_audio_free(pcm);
        return arr;
      },
      py::arg("path"),
      "ABI v5: decode any libavformat-supported audio source (WAV/MP3/AAC/"
      "FLAC/OGG/Opus/MP4) to canonical 16 kHz mono float32 PCM. Replaces "
      "per-binding resamplers — every consumer goes through libessence's "
      "libavformat+libswresample path for bit-identical PCM at the engine "
      "boundary.");

  m.def("decode_audio_bytes",
      [](py::bytes data) -> py::array_t<float> {
        std::string buf = data;
        float* pcm = nullptr; size_t n = 0;
        check(be_audio_decode_bytes(reinterpret_cast<const uint8_t*>(buf.data()),
                                    buf.size(), &pcm, &n),
              "be_audio_decode_bytes");
        auto arr = py::array_t<float>(n);
        if (n > 0) std::memcpy(arr.mutable_data(), pcm, n * sizeof(float));
        if (pcm) be_audio_free(pcm);
        return arr;
      },
      py::arg("data"),
      "Same as decode_audio_file but reads from a bytes buffer. Useful for "
      "streamed network audio without a temp file.");

  // Runtime.record_mp4 — one-shot session record.
  m.def("runtime_record_mp4",
      [](Runtime& rt, const std::string& audio_src,
         py::object target_width, py::object target_height,
         const std::string& out_mp4, int quality) {
        be_compose_size_t size{};
        bool has_size = !target_width.is_none() && !target_height.is_none()
                        && py::cast<int>(target_width) > 0
                        && py::cast<int>(target_height) > 0;
        if (has_size) {
          size.target_width  = py::cast<uint32_t>(target_width);
          size.target_height = py::cast<uint32_t>(target_height);
        }
        be_status s = be_session_record_mp4(
            rt.h,
            audio_src.c_str(),
            has_size ? &size : nullptr,
            out_mp4.c_str(),
            static_cast<be_encoder_quality>(quality));
        check(s, "be_session_record_mp4");
      },
      py::arg("runtime"), py::arg("audio_src"),
      py::arg("target_width") = py::none(),
      py::arg("target_height") = py::none(),
      py::arg("out_mp4"), py::arg("quality") = static_cast<int>(BE_QUALITY_MEDIUM),
      "ABI v5 one-shot render-to-MP4. Decodes the audio file, drives the "
      "compose loop, encodes H.264 + AAC, and muxes into the output .mp4 "
      "via libessence. Encoder dispatch is platform-native (VideoToolbox / "
      "MediaCodec / libx264). Pass target_width/target_height to fit into "
      "a canvas, or leave None for the fixture's native frame size.");
}
