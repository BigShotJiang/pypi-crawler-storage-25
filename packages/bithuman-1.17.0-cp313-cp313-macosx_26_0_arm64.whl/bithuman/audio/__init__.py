"""Back-compat shim for `bithuman.audio` (legacy pre-libessence wheel).

Re-exports `load_audio`, `float32_to_int16`, `int16_to_float32`, and
`write_video_with_audio` so existing downstream code that does:

    from bithuman.audio import load_audio, float32_to_int16

…keeps working against the v1.13.0+ libessence-backed wheel. New code
should prefer `bithuman._core.decode_audio_file` (one canonical libessence
path; bit-identical PCM at the engine boundary across all bindings).

Soft-deprecation: this module emits no warning today. It will start
warning in v1.16.0 and be removed in v2.0.
"""

from __future__ import annotations

import numpy as np

from .._core import decode_audio_file as _libessence_decode

INT16_MAX = 2**15 - 1  # 32767

__all__ = [
    "load_audio",
    "float32_to_int16",
    "int16_to_float32",
    "write_video_with_audio",
]


def load_audio(audio_path, target_sr=None):
    """Load an audio file and resample it to `target_sr` (default 16000).

    Returns `(audio: np.ndarray[float32, mono], sample_rate: int)` to
    match the legacy `bithuman.audio.load_audio` signature.

    Implementation routes through libessence's `be_audio_decode_file`,
    so resample filter quality and edge cases match every other binding
    (Rust/Swift/Kotlin).
    """
    # libessence always emits 16 kHz mono f32. If the caller asks for a
    # different target rate, fall back to soxr for that resample step
    # (rare — 99% of callers pass target_sr=16000 or None).
    pcm = _libessence_decode(str(audio_path))
    sr = 16_000
    if target_sr is not None and target_sr != sr:
        try:
            import soxr
            pcm = soxr.resample(pcm, sr, target_sr)
            sr = target_sr
        except ImportError:
            raise RuntimeError(
                f"bithuman.audio.load_audio: requested target_sr={target_sr}, "
                f"libessence emits {sr}; install `soxr` for non-16k targets "
                "(pip install soxr), or use bithuman._core.decode_audio_file "
                "for 16 kHz output (the engine's native rate)."
            )
    return pcm, sr


def float32_to_int16(x):
    """Convert float32 PCM in [-1, 1] to int16. Legacy signature."""
    return (np.asarray(x, dtype=np.float32) * INT16_MAX).astype(np.int16)


def int16_to_float32(x):
    """Convert int16 PCM to float32 in [-1, 1]. Legacy signature."""
    return np.asarray(x, dtype=np.int16).astype(np.float32) / INT16_MAX


def write_video_with_audio(
    video_path,
    audio_buffer,
    sample_rate,
    output_path,
    *,
    framerate=25,
    audio_codec="aac",
    video_codec="copy",
):
    """Mux a video stream + audio buffer into an output file via ffmpeg.

    Legacy helper from the pre-libessence wheel. Implemented via the
    `ffmpeg` binary subprocess (no new Python dep). For new code, use
    `bithuman._core.runtime_record_mp4` which does encode + mux in one
    libessence call without leaving the engine.
    """
    import subprocess
    import tempfile
    import wave
    from pathlib import Path

    output_path = str(output_path)
    video_path = str(video_path)

    # Write the audio buffer to a temp WAV so ffmpeg can ingest it.
    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
        wav_path = f.name
    try:
        audio = np.asarray(audio_buffer)
        if audio.dtype != np.int16:
            if np.issubdtype(audio.dtype, np.floating):
                audio = float32_to_int16(audio)
            else:
                audio = audio.astype(np.int16)
        with wave.open(wav_path, "wb") as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(int(sample_rate))
            w.writeframes(audio.tobytes())

        # `-c:v copy` assumes the input video is already H.264. If not,
        # the caller passes video_codec="libx264".
        subprocess.run(
            [
                "ffmpeg", "-loglevel", "error", "-y",
                "-r", str(framerate),
                "-i", video_path,
                "-i", wav_path,
                "-map", "0:v", "-map", "1:a",
                "-c:v", video_codec,
                "-c:a", audio_codec,
                "-b:a", "128k",
                "-shortest",
                output_path,
            ],
            check=True,
        )
    finally:
        Path(wav_path).unlink(missing_ok=True)
