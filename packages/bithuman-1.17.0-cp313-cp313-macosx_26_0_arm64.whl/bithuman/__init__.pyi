"""Type stubs for bithuman. Public API only."""

from dataclasses import dataclass
from enum import IntEnum
from pathlib import Path
from typing import Iterator, Optional, Union

import numpy as np

__version__: str
__core_version__: str
__abi_version__: int

# Low-level EP integer constants (one-to-one with the C `be_ep` enum).
EP_CPU: int
EP_AUTO: int
EP_COREML: int
EP_NNAPI: int
EP_QNN: int


# ---------- High-level facade ----------

class EP(IntEnum):
    CPU: int
    AUTO: int
    COREML: int
    NNAPI: int
    QNN: int


@dataclass
class ComposedFrame:
    bgr: np.ndarray
    cluster_idx: int
    frame_idx: int


class Avatar:
    @classmethod
    def load(
        cls,
        model_path: Union[str, Path],
        preferred_ep: EP = ...,
        intra_op_threads: int = 1,
    ) -> "Avatar": ...

    @property
    def frame_width(self) -> int: ...
    @property
    def frame_height(self) -> int: ...
    @property
    def sample_rate(self) -> int: ...
    @property
    def samples_per_tick(self) -> int: ...
    @property
    def fps(self) -> int: ...
    @property
    def cluster_count(self) -> int: ...
    @property
    def source_frame_count(self) -> int: ...
    @property
    def active_ep(self) -> EP: ...

    def compose(
        self,
        audio: Union[np.ndarray, str, Path],
        preallocated_out: Optional[np.ndarray] = None,
    ) -> Iterator[ComposedFrame]: ...

    def close(self) -> None: ...
    def __enter__(self) -> "Avatar": ...
    def __exit__(self, exc_type, exc_val, exc_tb) -> None: ...


# ---------- Low-level bindings (mirror C ABI v0/v1) ----------

class Fixture:
    def __init__(
        self,
        path: str,
        preferred_ep: int = ...,
        intra_op_threads: int = 1,
    ) -> None: ...

    @property
    def audio_sample_rate(self) -> int: ...
    @property
    def audio_samples_per_tick(self) -> int: ...
    @property
    def mel_bins(self) -> int: ...
    @property
    def mel_frames_per_chunk(self) -> int: ...
    @property
    def embedding_dim(self) -> int: ...
    @property
    def cluster_count(self) -> int: ...
    @property
    def active_ep(self) -> int: ...
    @property
    def frame_width(self) -> int: ...
    @property
    def frame_height(self) -> int: ...
    @property
    def source_frame_count(self) -> int: ...


class Runtime:
    def __init__(self, fixture: Fixture) -> None: ...

    def tick(
        self,
        audio_pcm: np.ndarray,
        embedding_out: Optional[np.ndarray] = None,
    ) -> int: ...

    def tick_compose(
        self,
        audio_pcm: np.ndarray,
        frame_idx_hint: int = -1,
        out: Optional[np.ndarray] = None,
    ) -> Union[tuple[int, np.ndarray], int]:
        """If `out` is provided, writes into it in place and returns just
        cluster_idx. Otherwise allocates and returns (cluster_idx, bgr)."""
        ...

    def tick_compose_to_size(
        self,
        audio_pcm: np.ndarray,
        frame_idx_hint: int = -1,
        target_w: int = 1280,
        target_h: int = 720,
        out: Optional[np.ndarray] = None,
    ) -> Union[tuple[int, np.ndarray], int]: ...
