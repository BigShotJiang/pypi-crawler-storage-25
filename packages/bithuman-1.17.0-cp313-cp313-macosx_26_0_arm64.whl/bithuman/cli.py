"""essence-render — minimal CLI for offline avatar video rendering.

Usage:
    essence-render --model PATH.imx --audio PATH.wav --output OUT.mp4 \\
                   [--fps 25] [--quality 80] [--ep cpu|auto|coreml] \\
                   [--threads 1] [--no-audio]

    # stream raw BGR to stdout (e.g. into another ffmpeg pipeline)
    essence-render --model PATH.imx --audio PATH.wav --output -
"""

from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

import numpy as np

from . import Avatar, EP, __version__


_EP_BY_NAME = {
    "cpu": EP.CPU,
    "auto": EP.AUTO,
    "coreml": EP.COREML,
    "nnapi": EP.NNAPI,
    "qnn": EP.QNN,
}


def _parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(
        prog="essence-render",
        description=(
            "Render a bitHuman Essence avatar video from a .imx model + "
            "an audio file. Writes an MP4 (H.264 + AAC) by default. "
            "Pass `--output -` to stream raw BGR frames to stdout."
        ),
    )
    p.add_argument("--model", required=True, help="Path to .imx model.")
    p.add_argument(
        "--audio",
        required=True,
        help="Audio file (WAV/MP3/FLAC/OGG). Decoded + resampled to 16 kHz mono.",
    )
    p.add_argument(
        "--output",
        required=True,
        help="Output MP4 path, or '-' to stream raw BGR24 to stdout.",
    )
    p.add_argument("--fps", type=int, default=25, help="Output FPS (default 25).")
    p.add_argument(
        "--quality",
        type=int,
        default=80,
        help="MP4 quality 1..100 (libx264; higher = better, default 80).",
    )
    p.add_argument(
        "--ep",
        choices=sorted(_EP_BY_NAME),
        default="cpu",
        help="Execution provider hint (default cpu).",
    )
    p.add_argument(
        "--threads",
        type=int,
        default=1,
        help="ORT intra-op thread count (default 1).",
    )
    p.add_argument(
        "--no-audio",
        action="store_true",
        help="Skip muxing the source audio track into the MP4.",
    )
    p.add_argument("--version", action="version", version=f"essence-render {__version__}")
    return p.parse_args(argv)


def _stream_raw_bgr_to_stdout(avatar: Avatar, audio_path: str) -> tuple[int, float]:
    n = 0
    t0 = time.perf_counter()
    stdout = sys.stdout.buffer
    for frame in avatar.compose(audio_path):
        stdout.write(frame.bgr.tobytes())
        n += 1
    stdout.flush()
    return n, time.perf_counter() - t0


def _encode_mp4(
    avatar: Avatar,
    audio_path: str,
    output_path: str,
    fps: int,
    quality: int,
    mux_audio: bool,
) -> tuple[int, float]:
    """Encode composited frames to MP4 (libx264). Mux source audio when asked."""
    try:
        import imageio  # type: ignore
    except ImportError as exc:
        raise SystemExit(
            "essence-render needs imageio + imageio-ffmpeg for MP4 output. "
            "Install with: pip install 'bithuman[cli]'"
        ) from exc

    # When muxing audio, write video to a temp file first, then call ffmpeg
    # to combine. Otherwise write straight to the requested output path.
    if mux_audio:
        tmp_dir = tempfile.mkdtemp(prefix="essence-render-")
        video_path = os.path.join(tmp_dir, "video.mp4")
    else:
        tmp_dir = None
        video_path = output_path

    writer = imageio.get_writer(
        video_path,
        fps=fps,
        codec="libx264",
        quality=quality / 10.0,  # imageio maps 0..10
        pixelformat="yuv420p",
        macro_block_size=1,
        ffmpeg_log_level="error",
    )

    n = 0
    t0 = time.perf_counter()
    try:
        for frame in avatar.compose(audio_path):
            # imageio expects RGB; our buffer is BGR. Flip channels in-place
            # view (numpy stride trick, zero-copy).
            writer.append_data(frame.bgr[..., ::-1])
            n += 1
    finally:
        writer.close()
    elapsed = time.perf_counter() - t0

    if mux_audio:
        _mux_audio(video_path, audio_path, output_path)
        if tmp_dir:
            shutil.rmtree(tmp_dir, ignore_errors=True)

    return n, elapsed


def _mux_audio(video_path: str, audio_path: str, output_path: str) -> None:
    """Mux source audio onto the rendered video using imageio's bundled ffmpeg."""
    try:
        import imageio_ffmpeg  # type: ignore
    except ImportError:
        # Fall back to system ffmpeg if installed.
        ffmpeg_bin = shutil.which("ffmpeg") or ""
        if not ffmpeg_bin:
            print(
                "[essence-render] warning: imageio-ffmpeg / ffmpeg not found; "
                "writing video-only output.",
                file=sys.stderr,
            )
            shutil.copyfile(video_path, output_path)
            return
    else:
        ffmpeg_bin = imageio_ffmpeg.get_ffmpeg_exe()

    cmd = [
        ffmpeg_bin,
        "-y",
        "-loglevel", "error",
        "-i", video_path,
        "-i", audio_path,
        "-map", "0:v:0",
        "-map", "1:a:0",
        "-c:v", "copy",
        "-c:a", "aac",
        "-b:a", "128k",
        "-shortest",
        output_path,
    ]
    proc = subprocess.run(cmd, capture_output=True)
    if proc.returncode != 0:
        sys.stderr.write(proc.stderr.decode("utf-8", "replace"))
        # Best-effort fallback: drop the audio track.
        shutil.copyfile(video_path, output_path)
        print(
            "[essence-render] warning: audio mux failed, wrote video-only output.",
            file=sys.stderr,
        )


def main(argv: list[str] | None = None) -> int:
    args = _parse_args(argv)

    model_path = Path(args.model).expanduser()
    audio_path = Path(args.audio).expanduser()
    if not model_path.exists():
        print(f"essence-render: model not found: {model_path}", file=sys.stderr)
        return 2
    if not audio_path.exists():
        print(f"essence-render: audio not found: {audio_path}", file=sys.stderr)
        return 2

    ep = _EP_BY_NAME[args.ep]
    streaming = args.output == "-"

    if not streaming:
        print(
            f"essence-render {__version__}: model={model_path.name} "
            f"audio={audio_path.name} ep={args.ep} threads={args.threads}",
            file=sys.stderr,
        )

    t_load = time.perf_counter()
    avatar = Avatar.load(model_path, preferred_ep=ep, intra_op_threads=args.threads)
    load_ms = (time.perf_counter() - t_load) * 1000.0
    if not streaming:
        print(
            f"essence-render: loaded fixture in {load_ms:.1f} ms — "
            f"{avatar.frame_width}x{avatar.frame_height} @ {avatar.fps} fps, "
            f"{avatar.cluster_count} clusters, {avatar.source_frame_count} src frames",
            file=sys.stderr,
        )

    try:
        if streaming:
            n_frames, elapsed = _stream_raw_bgr_to_stdout(avatar, str(audio_path))
        else:
            n_frames, elapsed = _encode_mp4(
                avatar,
                str(audio_path),
                str(args.output),
                fps=args.fps,
                quality=args.quality,
                mux_audio=not args.no_audio,
            )
    finally:
        avatar.close()

    if n_frames == 0:
        print("essence-render: produced 0 frames (audio shorter than one tick?).",
              file=sys.stderr)
        return 1

    mean_ms = (elapsed * 1000.0) / n_frames
    fps = n_frames / elapsed if elapsed > 0 else float("inf")
    msg = (
        f"essence-render: composed {n_frames} frames in {elapsed:.2f}s "
        f"({mean_ms:.2f} ms/frame, {fps:.1f} fps)"
    )
    if streaming:
        print(msg, file=sys.stderr)
    else:
        print(msg, file=sys.stderr)
        print(f"essence-render: wrote {args.output}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
