"""AsyncAvatar — legacy-`AsyncBithuman` parity facade on the Essence core.

This is the API production services (essence-avatar, agent-worker) bind
to. It mirrors `bithuman.runtime_async.AsyncBithuman` field-for-field on
the public surface; internally it drives the libessence C ABI via
``Fixture`` / ``Runtime`` plus the singleton ``auth_*`` heartbeat.

Internal architecture
---------------------

Pure asyncio. No threads outside the libessence heartbeat (which
the C++ side manages already). One background asyncio.Task consumes a
``VideoControl`` queue, slices int16 PCM into 640-sample / 40 ms /
16 kHz float32 ticks, calls ``Runtime.tick_compose_to_size``, and
publishes ``VideoFrame`` objects into the output queue.

    push(VideoControl) ──► _in_queue ──► [_producer_task] ──► _out_queue
                                                                  │
                                                       async for ◄┘ run()

End-of-speech handling: when a control arrives with ``end_of_speech=True``
or its ``AudioChunk.last_chunk=True``, the producer drains any remaining
audio (zero-pads the final partial tick) and emits one final VideoFrame
with ``end_of_speech=True``. Subsequent ``push()``-es restart the cycle.

Auth: ``create()`` runs the libessence ``auth_init``/``authenticate``/
``start_heartbeat`` sequence synchronously (in an executor) before
returning. The heartbeat thread is owned by libessence. Setting
``BITHUMAN_UNMETERED=1`` in the env skips the auth path for dev runs.
"""

from __future__ import annotations

import asyncio
import os
from pathlib import Path
from typing import AsyncIterator, Optional, Tuple, Union

import numpy as np

from . import _core
from .exceptions import (
    BithumanError,
    ExpressionModelNotSupported,
    ModelLoadError,
    ModelNotFoundError,
    RuntimeNotReadyError,
)
from .models import INT16_MAX, AudioChunk, VideoControl, VideoFrame


# Essence is locked to 16 kHz mono float32 PCM, 25 fps (640 samples/tick).
_SAMPLE_RATE_HZ = 16_000
_FPS = 25

# Audio-encoder lookback. The Runtime needs at least this many ticks of
# audio *past* the current cursor before each compose call (mel context).
# Empirically: 3 ticks = 120 ms beyond the cursor. The minimum first-call
# buffer is therefore (1 + 3) * spt = 4 ticks worth, but the actual gate
# is `tick_idx_to_emit + 3 < buffer_len // spt`. We pad with zeros on EoS.
_LOOKBACK_TICKS = 3

# Default heartbeat endpoint. Matches the legacy DEFAULT_AUTH_URL.
_DEFAULT_AUTH_URL = "https://api.bithuman.ai/v1/runtime-tokens/request"

# Sentinel placed on _out_queue to signal that the producer task has
# terminated cleanly (caller hit shutdown / ran out of audio in a
# bounded mode). Compared by identity.
_STREAM_END = object()


def _i16_to_f32(arr: np.ndarray) -> np.ndarray:
    """Convert int16 PCM to float32 in [-1, +1)."""
    return arr.astype(np.float32) / float(INT16_MAX)


def _resample_linear(pcm: np.ndarray, src_sr: int, dst_sr: int) -> np.ndarray:
    """Naive linear resample. Good enough for previews; production
    callers should resample upstream and push 16 kHz."""
    if src_sr == dst_sr or pcm.size == 0:
        return pcm
    n_out = int(round(pcm.size * dst_sr / src_sr))
    if n_out <= 0:
        return np.zeros(0, dtype=pcm.dtype)
    xp = np.linspace(0.0, 1.0, num=pcm.size, endpoint=False, dtype=np.float64)
    xq = np.linspace(0.0, 1.0, num=n_out, endpoint=False, dtype=np.float64)
    return np.interp(xq, xp, pcm).astype(pcm.dtype, copy=False)


class AsyncAvatar:
    """Async-first facade over libessence for parity with legacy
    `bithuman.AsyncBithuman`. Construct via ``await AsyncAvatar.create(...)``.

    Lifecycle:

        avatar = await AsyncAvatar.create(model_path=..., api_secret=...)
        await avatar.push_audio(pcm_bytes, sample_rate=16_000, last_chunk=True)
        async for frame in avatar.run():
            ...
        await avatar.shutdown()
    """

    # ---- construction ----------------------------------------------

    def __init__(
        self,
        *,
        input_buffer_size: int = 0,
        output_buffer_size: int = 6,
        output_size: Optional[Tuple[int, int]] = (1280, 720),
        tags: Optional[str] = "bithuman",
        billing_type: str = "self-hosted-essence-model",
        api_secret: Optional[str] = None,
        api_url: str = _DEFAULT_AUTH_URL,
        agent_code: Optional[str] = None,
        num_threads: int = 0,
    ) -> None:
        # Public-ish config, captured for re-auth on agent_code / billing_type changes.
        self._api_secret = api_secret or ""
        self._api_url = api_url
        self._tags = tags or ""
        self._billing_type = billing_type
        self._agent_code = agent_code or ""
        self._num_threads = num_threads

        # Output geometry. None = native source resolution.
        self._output_size = output_size

        # Underlying C handles. Allocated in `create()` after auth.
        self._fixture: Optional[_core.Fixture] = None
        self._runtime: Optional[_core.Runtime] = None
        self._model_path: Optional[str] = None

        # Auth state (we use BITHUMAN_UNMETERED=1 to bypass).
        self._unmetered = os.environ.get("BITHUMAN_UNMETERED", "") == "1"
        self._auth_started = False
        self._token_refresh_started = False

        # asyncio queues. Bounded by buffer-size kwargs; size 0 = unbounded
        # to match legacy `input_buffer_size=0` semantics (a Python queue
        # of `maxsize=0` is unbounded).
        self._in_queue: asyncio.Queue[
            Union[VideoControl, object]
        ] = asyncio.Queue(maxsize=input_buffer_size)
        self._out_queue: asyncio.Queue[
            Union[VideoFrame, BaseException, object]
        ] = asyncio.Queue(maxsize=output_buffer_size)

        # Producer task handle.
        self._producer_task: Optional[asyncio.Task[None]] = None
        self._running = False
        self._stop_event = asyncio.Event()

    @classmethod
    async def create(
        cls,
        *,
        model_path: Optional[str] = None,
        token: Optional[str] = None,
        api_secret: Optional[str] = None,
        api_url: str = _DEFAULT_AUTH_URL,
        tags: Optional[str] = "bithuman",
        insecure: bool = False,
        input_buffer_size: int = 0,
        output_buffer_size: int = 6,
        num_threads: int = 0,
        verbose: Optional[bool] = None,
        batch_workers: int = 1,
        quality: str = "medium",
        identity: Optional[str] = None,
        # New (Essence-specific) — keeps legacy callers source-compatible.
        output_size: Optional[Tuple[int, int]] = (1280, 720),
        billing_type: str = "self-hosted-essence-model",
        agent_code: Optional[str] = None,
        fingerprint: Optional[str] = None,
    ) -> "AsyncAvatar":
        """Build an AsyncAvatar bound to ``model_path``.

        Legacy parity arguments
        -----------------------
        ``token``, ``insecure``, ``verbose``, ``batch_workers``, ``quality``,
        ``identity`` are accepted for source-compat but Essence-irrelevant:

        * ``token`` — legacy passes raw JWTs; libessence resolves
          its own token from ``api_secret``, so we ignore the JWT path
          and rely on the heartbeat. If you NEED to inject a token,
          raise an issue; we can wire a be_auth_set_token() ABI later.
        * ``insecure`` — disables TLS cert verification on the heartbeat
          POST. libessence honors $BITHUMAN_INSECURE for this;
          when ``insecure=True`` we set it in os.environ before init.
        * ``verbose`` — legacy controls JWT-validation logging; the
          libessence heartbeat is silent by default.
        * ``batch_workers`` — legacy uses this for offline batch
          rendering; the async path is realtime-only.
        * ``quality`` / ``identity`` — Expression-only knobs. Essence
          models bake their reference face at pack time; ``identity``
          is a no-op (see ``set_identity``).
        """
        if model_path is None:
            raise ValueError("AsyncAvatar.create: model_path is required")

        path = Path(model_path).expanduser()
        if not path.exists():
            raise ModelNotFoundError(f"Essence model not found: {path}")

        # Early rejection of Expression containers — keep parity with
        # legacy AsyncBithuman, which raises ExpressionModelNotSupported
        # in the same spot.
        _reject_if_expression_model(str(path))

        if insecure:
            os.environ["BITHUMAN_INSECURE"] = "1"

        avatar = cls(
            input_buffer_size=input_buffer_size,
            output_buffer_size=output_buffer_size,
            output_size=output_size,
            tags=tags,
            billing_type=billing_type,
            api_secret=api_secret,
            api_url=api_url,
            agent_code=agent_code,
            num_threads=num_threads,
        )

        # Auth happens off the event loop (sync libessence calls).
        loop = asyncio.get_running_loop()
        await loop.run_in_executor(
            None, avatar._auth_init_blocking, fingerprint
        )

        # Fixture load is heavy (mmap + JPEG transcode init) — run in
        # an executor too so we don't pin the event loop.
        await loop.run_in_executor(None, avatar._load_fixture_blocking, str(path))

        return avatar

    # ---- legacy-parity API -----------------------------------------

    async def set_model(self, model_path: str) -> None:
        """Replace the currently loaded fixture with one at ``model_path``."""
        path = Path(model_path).expanduser()
        if not path.exists():
            raise ModelNotFoundError(f"Essence model not found: {path}")
        _reject_if_expression_model(str(path))
        # Tear down any running producer + runtime first.
        await self.stop()
        loop = asyncio.get_running_loop()
        await loop.run_in_executor(None, self._load_fixture_blocking, str(path))

    async def push_audio(
        self, data: bytes, sample_rate: int, last_chunk: bool = True
    ) -> None:
        """Enqueue raw int16 PCM bytes for the runtime.

        Args:
            data: int16 little-endian PCM bytes.
            sample_rate: input sample rate (resampled to 16 kHz internally).
            last_chunk: end-of-speech marker for this utterance.
        """
        control = VideoControl.from_audio(data, sample_rate, last_chunk)
        await self._in_queue.put(control)

    async def push(self, control: VideoControl) -> None:
        """Enqueue a pre-built VideoControl."""
        await self._in_queue.put(control)

    async def flush(self) -> None:
        """Mark end-of-speech with an empty control."""
        await self._in_queue.put(VideoControl(end_of_speech=True))

    def run(self) -> AsyncIterator[VideoFrame]:
        """Return an async iterator that yields composed VideoFrames.

        Lazily starts the background producer task on first iteration.
        Iteration ends when the producer drains end-of-stream.
        """
        return self._run_iter()

    async def _run_iter(self) -> AsyncIterator[VideoFrame]:
        await self._ensure_running()
        try:
            while True:
                item = await self._out_queue.get()
                if item is _STREAM_END:
                    return
                if isinstance(item, BaseException):
                    raise item
                yield item  # type: ignore[misc]
        except asyncio.CancelledError:
            await self.stop()
            raise

    async def stop(self) -> None:
        """Stop the producer task. Idempotent. Does NOT release auth."""
        if not self._running:
            return
        self._stop_event.set()
        # Wake the producer if it's blocked on _in_queue.get.
        try:
            self._in_queue.put_nowait(VideoControl(end_of_speech=True))
        except asyncio.QueueFull:
            pass

        # Drain the output queue FIRST — the producer may be blocked
        # on `await self._out_queue.put(...)` because the consumer
        # bailed out early. Draining unblocks it so the stop_event
        # check on the next loop iteration can terminate cleanly.
        if self._producer_task is not None:
            drain_task = asyncio.create_task(self._drain_out_queue_until(self._producer_task))
            try:
                await asyncio.wait_for(self._producer_task, timeout=5.0)
            except asyncio.TimeoutError:
                self._producer_task.cancel()
                try:
                    await asyncio.wait_for(self._producer_task, timeout=1.0)
                except (asyncio.TimeoutError, asyncio.CancelledError):
                    pass
            except asyncio.CancelledError:
                pass
            drain_task.cancel()
            try:
                await drain_task
            except (asyncio.CancelledError, Exception):
                pass

        self._producer_task = None
        self._running = False
        # Final drain so a future run() doesn't see stale frames.
        while not self._out_queue.empty():
            try:
                self._out_queue.get_nowait()
            except asyncio.QueueEmpty:
                break

    async def _drain_out_queue_until(self, producer_task: "asyncio.Task[None]") -> None:
        """Continuously drain ``_out_queue`` while ``producer_task`` is
        running. Lets the producer make forward progress past full-queue
        backpressure when the consumer has bailed out."""
        while not producer_task.done():
            try:
                await asyncio.wait_for(self._out_queue.get(), timeout=0.1)
            except asyncio.TimeoutError:
                continue
            except asyncio.CancelledError:
                return

    async def shutdown(self) -> None:
        """Full teardown: stop the producer, release the runtime/fixture,
        stop token refresh, shut down auth."""
        await self.stop()
        self._runtime = None
        self._fixture = None
        if self._auth_started and not self._unmetered:
            try:
                _core.auth_stop_heartbeat()
            except Exception:
                pass
            try:
                _core.auth_shutdown()
            except Exception:
                pass
            self._auth_started = False
            self._token_refresh_started = False

    # ---- billing knobs ---------------------------------------------

    def set_agent_code(self, agent_code: str) -> None:
        """Set the per-agent attribution code for usage reports.

        libessence surfaces ``tags`` to the heartbeat endpoint;
        we encode ``agent_code`` into the tag string as
        ``"<tag>;agent=<agent_code>"`` so it shows up in usage tracking
        without an ABI change. Takes effect on the next heartbeat
        (next ``auth_init`` reconfigure).
        """
        self._agent_code = agent_code or ""
        self._reconfigure_auth()

    def set_billing_type(self, billing_type: str) -> None:
        """Override the billing-type field sent to the heartbeat.

        Defaults to ``"self-hosted-essence-model"``. The agent worker
        sets this to ``"essence-runtime"`` or similar for different
        product lines.
        """
        self._billing_type = billing_type
        self._reconfigure_auth()

    # ---- token refresh delegation ----------------------------------

    def start_token_refresh(self, **kwargs) -> bool:
        """Start the libessence heartbeat thread. Returns True on success.

        Idempotent: calling twice is fine; the second call is a no-op.
        Ignores legacy kwargs (``refresh_interval``, etc.) — libessence
        bakes a 60 s cadence into ``auth_init``.
        """
        if self._unmetered:
            return False
        if self._token_refresh_started:
            return True
        try:
            _core.auth_start_heartbeat()
            self._token_refresh_started = True
            return True
        except Exception:
            return False

    def is_token_refresh_running(self) -> bool:
        if self._unmetered:
            return False
        if not self._token_refresh_started:
            return False
        # Treat any non-Unconfigured state as "running" — covers OK,
        # OFFLINE (within grace), and the FATAL states (we leave the
        # surface flagged "running" so the caller can stop it explicitly).
        return _core.auth_state() != _core.AUTH_UNCONFIGURED

    def stop_token_refresh(self) -> None:
        if self._unmetered:
            return
        if not self._token_refresh_started:
            return
        try:
            _core.auth_stop_heartbeat()
        finally:
            self._token_refresh_started = False

    # ---- Expression-compat stubs -----------------------------------

    def set_identity(self, identity: str) -> None:
        """No-op for Essence runtimes. Expression models bake their
        reference face at pack time."""
        # Intentionally silent; matches the legacy stub contract.
        return None

    # ---- introspection ---------------------------------------------

    @property
    def frame_width(self) -> Optional[int]:
        if self._fixture is None:
            return None
        if self._output_size is not None:
            return int(self._output_size[0])
        return int(self._fixture.frame_width)

    @property
    def frame_height(self) -> Optional[int]:
        if self._fixture is None:
            return None
        if self._output_size is not None:
            return int(self._output_size[1])
        return int(self._fixture.frame_height)

    @property
    def sample_rate(self) -> int:
        return _SAMPLE_RATE_HZ

    @property
    def fps(self) -> int:
        return _FPS

    @property
    def samples_per_tick(self) -> int:
        if self._fixture is None:
            raise RuntimeNotReadyError("Fixture not loaded; await create() first.")
        return int(self._fixture.audio_samples_per_tick)

    # ---- internals -------------------------------------------------

    def _composed_tag(self) -> str:
        """Heartbeat ``tags`` string with the optional agent_code suffix.

        Format: ``"<tag>"`` or ``"<tag>;agent=<code>"``. The agent
        worker greps for the ``agent=`` segment in usage reports.
        """
        if self._agent_code:
            return f"{self._tags};agent={self._agent_code}" if self._tags else f"agent={self._agent_code}"
        return self._tags

    def _auth_init_blocking(self, fingerprint: Optional[str]) -> None:
        """Run auth_init + authenticate + start_heartbeat synchronously."""
        if self._unmetered:
            return
        if not self._api_secret:
            raise BithumanError(
                "AsyncAvatar.create: api_secret is required "
                "(or set BITHUMAN_API_SECRET in env, or BITHUMAN_UNMETERED=1 for dev)."
            )
        _core.auth_init(
            api_secret=self._api_secret,
            billing_type=self._billing_type,
            tags=self._composed_tag(),
            fingerprint=fingerprint or "",
            endpoint=self._api_url or "",
        )
        _core.auth_authenticate()
        _core.auth_start_heartbeat()
        self._auth_started = True
        self._token_refresh_started = True

    def _reconfigure_auth(self) -> None:
        """Apply a config change (agent_code / billing_type) without
        breaking the existing heartbeat thread. Calls ``auth_init``
        again — libessence is documented to reset config but keep
        the running thread alive.
        """
        if self._unmetered or not self._auth_started or not self._api_secret:
            return
        try:
            _core.auth_init(
                api_secret=self._api_secret,
                billing_type=self._billing_type,
                tags=self._composed_tag(),
                fingerprint="",
                endpoint=self._api_url or "",
            )
        except Exception:
            # Reconfigure failures are non-fatal; the running thread
            # keeps using the prior config.
            pass

    def _load_fixture_blocking(self, model_path: str) -> None:
        """Allocate Fixture + Runtime in the calling thread."""
        try:
            fx = _core.Fixture(
                model_path,
                preferred_ep=_core.EP_CPU,
                intra_op_threads=max(1, self._num_threads),
            )
        except Exception as e:
            raise ModelLoadError(f"failed to load .imx: {e}") from e
        self._fixture = fx
        self._runtime = _core.Runtime(fx)
        self._model_path = model_path

    async def _ensure_running(self) -> None:
        """Start the producer task on first ``run()``."""
        if self._fixture is None or self._runtime is None:
            raise RuntimeNotReadyError(
                "AsyncAvatar: no fixture loaded. Call create(model_path=...)."
            )
        if self._running:
            return
        self._stop_event = asyncio.Event()
        self._running = True
        self._producer_task = asyncio.create_task(
            self._produce_frames(), name="bithuman-essence-async-producer"
        )

    async def _produce_frames(self) -> None:
        """Consume _in_queue → emit VideoFrame to _out_queue.

        Internal model (per utterance):

            • ``pcm_buf``: float32 PCM accumulator (16 kHz mono).
            • ``ticks_emitted``: number of ticks already composed.
            • ``tick_i16_history``: int16 slices kept for the per-frame
              ``audio_chunk`` payload (legacy parity).

        The Runtime exposes a cursor that advances ``spt`` samples per
        ``tick_compose_to_size`` call. The buffer passed to each call
        MUST extend at least ``_LOOKBACK_TICKS`` ticks past the cursor
        (mel context), so we only emit when
        ``len(pcm_buf) >= (ticks_emitted + 1 + _LOOKBACK_TICKS) * spt``.

        On end-of-speech, we pad the buffer with zeros until every
        remaining tick can be composed, then emit one final VideoFrame
        with ``end_of_speech=True``.
        """
        assert self._fixture is not None and self._runtime is not None
        fx = self._fixture
        spt = int(fx.audio_samples_per_tick)
        out_size = self._output_size

        # Per-utterance state — reset on each new message_id / terminal.
        rt = self._runtime
        pcm_buf = np.zeros(0, dtype=np.float32)
        ticks_emitted = 0
        current_message_id: Optional[str] = None

        try:
            while not self._stop_event.is_set():
                # Block on input.
                try:
                    control = await asyncio.wait_for(self._in_queue.get(), timeout=1.0)
                except asyncio.TimeoutError:
                    if self._stop_event.is_set():
                        break
                    continue

                if not isinstance(control, VideoControl):
                    continue

                # ---- new utterance? -------------------------------
                # VideoControl.message_id auto-mints a fresh UUID per
                # constructor call. The legacy semantics for "new utterance"
                # were "first audio chunk AFTER an end_of_speech", not
                # "any chunk with a different UUID". Without this nuance we
                # would re-create _core.Runtime on EVERY push_audio chunk —
                # which is what caused the 60-second hang the public
                # quickstart hit (1387 Runtime constructions × ~50 ms each).
                #
                # Reset only when:
                #   1. We've seen at least one chunk for the current
                #      utterance (current_message_id is not None), AND
                #   2. The incoming chunk's UUID differs from the one
                #      we've already locked in for this utterance, AND
                #   3. The previous utterance has actually terminated
                #      (signalled by ticks_emitted being reset to 0 by
                #      the post-EoS path below).
                # On the very first chunk we just adopt its message_id.
                if control.audio is not None:
                    if current_message_id is None:
                        # First chunk after init / after end-of-speech.
                        # Always lock in this UUID; only build a fresh
                        # Runtime if we've already drained one before.
                        if rt is not self._runtime or pcm_buf.size > 0 or ticks_emitted > 0:
                            rt = _core.Runtime(fx)
                            self._runtime = rt
                            pcm_buf = np.zeros(0, dtype=np.float32)
                            ticks_emitted = 0
                        current_message_id = control.message_id
                    # else: middle of an utterance; ignore the UUID drift
                    # caused by VideoControl.from_audio auto-minting.

                # ---- append audio --------------------------------
                if control.audio is not None:
                    chunk = control.audio
                    pcm_i16 = np.ascontiguousarray(chunk.data, dtype=np.int16)
                    if chunk.sample_rate != _SAMPLE_RATE_HZ:
                        # Resample on float32 then re-quantize back to i16
                        # before the f32 conversion so AudioChunk payload
                        # stays canonical 16 kHz int16.
                        tmp_f32 = _i16_to_f32(pcm_i16)
                        tmp_f32 = _resample_linear(tmp_f32, chunk.sample_rate, _SAMPLE_RATE_HZ)
                        pcm_i16 = (tmp_f32 * INT16_MAX).astype(np.int16)
                    pcm_buf = np.concatenate([pcm_buf, _i16_to_f32(pcm_i16)])

                is_terminal = control.end_of_speech or (
                    control.audio is not None and control.audio.last_chunk
                )

                # If pure idle control with no audio in flight, skip.
                if pcm_buf.size == 0 and not is_terminal:
                    continue

                # ---- emit any ticks that have enough lookback ----
                emitted_now = await self._emit_ready_ticks(
                    rt=rt,
                    pcm_buf=pcm_buf,
                    spt=spt,
                    out_size=out_size,
                    ticks_emitted=ticks_emitted,
                    message_id=current_message_id,
                    eos_padding=False,
                )
                ticks_emitted += emitted_now

                # ---- terminal: pad with zeros and drain the tail --
                if is_terminal:
                    total_audio_ticks = pcm_buf.size // spt
                    if pcm_buf.size % spt != 0:
                        total_audio_ticks += 1  # round up — final partial tick
                    remaining = max(0, total_audio_ticks - ticks_emitted)
                    if remaining > 0:
                        # Pad with zeros so the cursor can advance through
                        # the tail. Need (ticks_emitted + remaining + lookback) * spt.
                        target_len = (
                            ticks_emitted + remaining + _LOOKBACK_TICKS
                        ) * spt
                        if pcm_buf.size < target_len:
                            pcm_buf = np.concatenate(
                                [pcm_buf, np.zeros(target_len - pcm_buf.size, dtype=np.float32)]
                            )
                        emitted_now = await self._emit_ready_ticks(
                            rt=rt,
                            pcm_buf=pcm_buf,
                            spt=spt,
                            out_size=out_size,
                            ticks_emitted=ticks_emitted,
                            message_id=current_message_id,
                            eos_padding=True,
                            tail_total=ticks_emitted + remaining,
                        )
                        ticks_emitted += emitted_now

                    # The helper emits the FINAL drained tick with
                    # ``end_of_speech=True`` already. If there were zero
                    # audio ticks (pure flush / silent), surface a
                    # control-only EoS marker so the consumer breaks out.
                    if remaining == 0:
                        eos = VideoFrame(
                            bgr_image=None,
                            audio_chunk=None,
                            frame_index=ticks_emitted,
                            source_message_id=current_message_id,
                            end_of_speech=True,
                        )
                        await self._out_queue.put(eos)

                    # Reset for the next utterance.
                    pcm_buf = np.zeros(0, dtype=np.float32)
                    ticks_emitted = 0
                    current_message_id = None
        except Exception as e:
            try:
                await self._out_queue.put(e)
            except Exception:
                pass
        finally:
            try:
                await self._out_queue.put(_STREAM_END)
            except Exception:
                pass

    async def _emit_ready_ticks(
        self,
        *,
        rt: "_core.Runtime",
        pcm_buf: np.ndarray,
        spt: int,
        out_size: Optional[Tuple[int, int]],
        ticks_emitted: int,
        message_id: Optional[str],
        eos_padding: bool,
        tail_total: Optional[int] = None,
    ) -> int:
        """Pull as many ticks as the current ``pcm_buf`` can serve.

        Returns the number of frames emitted by this call. The Runtime
        advances its cursor internally; we only need to track our
        ``ticks_emitted`` counter to slice the per-frame AudioChunk.
        """
        # How many ticks are ready?
        if eos_padding:
            # Buffer is already padded to `tail_total + _LOOKBACK_TICKS`.
            assert tail_total is not None
            ready_total = tail_total
        else:
            ready_total = max(0, (pcm_buf.size // spt) - _LOOKBACK_TICKS)

        n_to_emit = ready_total - ticks_emitted
        if n_to_emit <= 0:
            return 0

        emitted = 0
        for k in range(n_to_emit):
            if self._stop_event.is_set():
                return emitted
            tick_idx = ticks_emitted + k
            # Per-frame AudioChunk slice (legacy parity).
            start = tick_idx * spt
            end = start + spt
            slice_f32 = pcm_buf[start:end]
            if slice_f32.size < spt:
                slice_f32 = np.concatenate(
                    [slice_f32, np.zeros(spt - slice_f32.size, dtype=np.float32)]
                )
            slice_i16 = (np.clip(slice_f32, -1.0, 1.0) * INT16_MAX).astype(np.int16)

            try:
                if out_size is not None:
                    tw, th = int(out_size[0]), int(out_size[1])
                    _cluster, bgr = rt.tick_compose_to_size(pcm_buf, -1, tw, th)
                else:
                    _cluster, bgr = rt.tick_compose(pcm_buf, -1)
            except ValueError as exc:
                # Trailing-tick EOS: libessence returns BE_ERR_AUDIO_FORMAT
                # (status=6) when the cursor walks past the last full mel
                # window for the supplied PCM buffer. The native message is
                # "compose: tick cursor past end of audio" but _core.cpp's
                # check() only formats `status=N`, so we match both the
                # status code and the legacy text. Treat as clean EOS.
                msg = str(exc)
                if "cursor past end" in msg or "status=6" in msg:
                    return emitted
                raise

            ac = AudioChunk(
                data=slice_i16,
                sample_rate=_SAMPLE_RATE_HZ,
                last_chunk=(eos_padding and tick_idx == (tail_total - 1)),
            )
            vf = VideoFrame(
                bgr_image=bgr,
                audio_chunk=ac,
                frame_index=tick_idx,
                source_message_id=message_id,
                end_of_speech=(eos_padding and tick_idx == (tail_total - 1)),
            )
            await self._out_queue.put(vf)
            emitted += 1
        return emitted


# ---------------------------------------------------------------------
# Expression-rejection helper (legacy parity)
# ---------------------------------------------------------------------


def _reject_if_expression_model(model_path: str) -> None:
    """Raise ``ExpressionModelNotSupported`` when the .imx manifest
    says ``model_type == "expression"``. Falls back to a no-op if the
    legacy reader isn't importable (we're in a pure-Essence install).
    """
    try:
        # Import lazily — most installs won't have the legacy reader.
        from bithuman.engine.video_reader import (  # type: ignore[import-untyped]
            ImxContainer,
            is_imx_file,
        )
    except Exception:
        return
    p = Path(model_path)
    if not p.is_file() or not is_imx_file(model_path):
        return
    try:
        container = ImxContainer(model_path)
    except Exception:
        return
    metadata = container.metadata or {}
    if metadata.get("model_type") == "expression":
        raise ExpressionModelNotSupported(
            f"Model at {model_path!r} is an Expression (.imx with "
            "model_type='expression') model. The bithuman "
            "runtime serves Essence models only."
        )


__all__ = ["AsyncAvatar"]
