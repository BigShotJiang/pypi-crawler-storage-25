"""bithuman — Python bindings for the portable C++ avatar runtime.

Three API tiers:

  * **Async, legacy-`AsyncBithuman` parity** (recommended for services):

        from bithuman import AsyncAvatar, VideoControl, AudioChunk

        avatar = await AsyncAvatar.create(model_path="model.imx",
                                          api_secret="bh-...")
        await avatar.push_audio(pcm_bytes, sample_rate=16_000, last_chunk=True)
        async for frame in avatar.run():
            ...  # frame.bgr_image is (720, 1280, 3) uint8 BGR
        await avatar.shutdown()

  * **Sync, single-shot** (for offline / batch / CLI):

        from bithuman import Avatar
        with Avatar.load("model.imx") as avatar:
            for frame in avatar.compose("speech.wav"):
                ...  # frame.bgr is (H, W, 3) uint8

  * **Low-level** (one-to-one with the C ABI):

        from bithuman import Fixture, Runtime, EP_CPU
        fx = Fixture("model.imx", preferred_ep=EP_CPU)
        rt = Runtime(fx)
        cluster, bgr = rt.tick_compose(audio_640samples_f32, -1)

Coordinates: 16 kHz float32 mono PCM in (int16 also accepted via
``AudioChunk``), BGR uint8 frames out at 25 fps, default 1280x720
with aspect-preserving fit + black letterbox/pillarbox padding.
"""

from ._core import (
    EP_AUTO,
    EP_COREML,
    EP_CPU,
    EP_NNAPI,
    EP_QNN,
    Fixture,
    Runtime,
    __abi_version__,
    __version__ as __core_version__,
)
from .async_avatar import AsyncAvatar
from .avatar import Avatar, ComposedFrame, EP

# Back-compat alias: the pre-libessence wheel exported the async runtime
# as `AsyncBithuman`. v1.13.0 renamed it to `AsyncAvatar` to match the sync
# class name. ~40 downstream files (public Examples + docs + platform
# services + LiveKit plugins) still reference the old name. Alias both
# directions so legacy code keeps importing and pickling cleanly while we
# migrate. The alias will be deprecated with a warning in v1.16.0 and
# removed in v2.0.
AsyncBithuman = AsyncAvatar
from .exceptions import (
    AccountStatusError,
    BithumanError,
    ExpressionModelNotSupported,
    ModelError,
    ModelLoadError,
    ModelNotFoundError,
    ModelSecurityError,
    RuntimeNotReadyError,
    TokenError,
    TokenExpiredError,
    TokenRequestError,
    TokenValidationError,
)
from .models import (
    AudioChunk,
    Emotion,
    EmotionPrediction,
    VideoControl,
    VideoFrame,
)

# Python package version — read at import time from the installed wheel's
# metadata so it always matches the version pip resolved. Falls back to a
# sentinel only if running from a source tree without pip install -e .
try:
    from importlib.metadata import version as _pkg_version, PackageNotFoundError as _PNF
    __version__ = _pkg_version("bithuman")
except _PNF:
    __version__ = "0.0.0+source"
del _pkg_version, _PNF

__all__ = [
    # Async facade
    "AsyncAvatar",
    "AsyncBithuman",  # back-compat alias for AsyncAvatar; soft-deprecated in v1.15.1
    # Sync facade
    "Avatar",
    "ComposedFrame",
    "EP",
    # Data models
    "AudioChunk",
    "VideoControl",
    "VideoFrame",
    "Emotion",
    "EmotionPrediction",
    # Exceptions
    "BithumanError",
    "TokenError",
    "TokenExpiredError",
    "TokenValidationError",
    "TokenRequestError",
    "AccountStatusError",
    "ModelError",
    "ModelNotFoundError",
    "ModelLoadError",
    "ModelSecurityError",
    "ExpressionModelNotSupported",
    "RuntimeNotReadyError",
    # Low-level bindings
    "Fixture",
    "Runtime",
    "EP_CPU",
    "EP_AUTO",
    "EP_COREML",
    "EP_NNAPI",
    "EP_QNN",
    # Versions
    "__version__",
    "__core_version__",
    "__abi_version__",
]
