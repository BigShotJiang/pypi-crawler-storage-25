"""High-level Avatar facade over the low-level Fixture/Runtime bindings.

This is the convenience layer most app developers should reach for. It owns
the C ABI handles, hides the chunking math, and presents a clean iterator
that consumes raw audio and yields composited BGR frames at 25 fps.

Example
-------
    from bithuman import Avatar

    with Avatar.load("model.imx") as avatar:
        for frame in avatar.compose("speech.wav"):
            # frame.bgr is (H, W, 3) uint8 BGR
            cv2.imshow("avatar", frame.bgr)
            cv2.waitKey(40)
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import IntEnum
from pathlib import Path
from typing import Iterator, Optional, Union

import os

import numpy as np

from . import _core


PathLike = Union[str, Path]
AudioInput = Union[np.ndarray, str, Path]


class EP(IntEnum):
    """Execution provider hint. CPU is the canonical baseline; the others
    are mapped opportunistically by the C ABI when available on the host."""
    CPU = _core.EP_CPU
    AUTO = _core.EP_AUTO
    COREML = _core.EP_COREML
    NNAPI = _core.EP_NNAPI
    QNN = _core.EP_QNN


@dataclass
class ComposedFrame:
    """One avatar frame produced by `Avatar.compose`.

    Attributes
    ----------
    bgr:
        (H, W, 3) uint8 numpy array in BGR pixel order. View into a buffer
        that the runtime may overwrite on the next tick; copy it if you
        need to retain the frame across iterations.
    cluster_idx:
        The viseme cluster id chosen for this tick (range [0, cluster_count)).
    frame_idx:
        Zero-based tick index inside the current compose() call.
    """

    bgr: np.ndarray
    cluster_idx: int
    frame_idx: int


# Essence is locked to 16 kHz mono float32 PCM, 25 fps (640 samples/tick).
_SAMPLE_RATE_HZ = 16_000
_FPS = 25


def _decode_audio(audio: AudioInput) -> np.ndarray:
    """Coerce `audio` into a 1-D float32 numpy array at 16 kHz mono.

    Accepts:
      - numpy array (float32 mono, or anything castable to float32 mono)
      - str / Path pointing to a WAV / FLAC / OGG / MP3 (decoded via soundfile)
    """
    if isinstance(audio, np.ndarray):
        if audio.ndim == 2:
            # downmix to mono if needed
            audio = audio.mean(axis=1)
        if audio.dtype != np.float32:
            audio = audio.astype(np.float32, copy=False)
        return np.ascontiguousarray(audio)

    if isinstance(audio, (str, Path)):
        # v1.15.1: route through libessence's be_audio_decode_file via
        # _core.decode_audio_file. Zero new deps (libavformat is already
        # linked into the .so for H.264 base-frame decode), and it
        # produces bit-identical PCM to every other binding. Soundfile
        # is still available as a fallback for tests / environments
        # where users have it preinstalled.
        try:
            from ._core import decode_audio_file as _libessence_decode
        except (ImportError, AttributeError):
            _libessence_decode = None

        if _libessence_decode is not None:
            return np.ascontiguousarray(
                _libessence_decode(str(audio)).astype(np.float32, copy=False)
            )

        # Legacy fallback (kept for ABI v4 _core.so without decode_audio_file).
        try:
            import soundfile as sf  # type: ignore
        except ImportError as exc:  # pragma: no cover - env-dependent
            raise RuntimeError(
                "Reading audio from a file path requires either ABI v5+ "
                "libessence (preferred — bundled in v1.15.1+) or the "
                "`soundfile` package as a legacy fallback. Reinstall with "
                "`pip install --upgrade bithuman` or pass a float32 numpy "
                "array instead."
            ) from exc

        data, sr = sf.read(str(audio), dtype="float32", always_2d=False)
        if data.ndim == 2:
            data = data.mean(axis=1).astype(np.float32, copy=False)
        if sr != _SAMPLE_RATE_HZ:
            n_out = int(round(len(data) * _SAMPLE_RATE_HZ / sr))
            if n_out <= 0:
                return np.zeros(0, dtype=np.float32)
            xp = np.linspace(0.0, 1.0, num=len(data), endpoint=False, dtype=np.float64)
            xq = np.linspace(0.0, 1.0, num=n_out, endpoint=False, dtype=np.float64)
            data = np.interp(xq, xp, data).astype(np.float32, copy=False)
        return np.ascontiguousarray(data)

    raise TypeError(
        f"Unsupported audio input type {type(audio)!r}; expected np.ndarray, "
        f"str, or pathlib.Path."
    )


class Avatar:
    """High-level convenience wrapper around `Fixture` + `Runtime`.

    Load a .imx once, then call `compose(audio)` to stream BGR frames.
    Use as a context manager (or call `.close()`) to release the underlying
    C handles deterministically.
    """

    def __init__(self, fixture: _core.Fixture):
        self._fixture: Optional[_core.Fixture] = fixture
        self._closed = False

    # ------- construction -------

    @classmethod
    def load(
        cls,
        model_path: PathLike,
        api_secret: Optional[str] = None,
        preferred_ep: EP = EP.CPU,
        intra_op_threads: int = 1,
        tags: str = "python-wrapper",
        fingerprint: Optional[str] = None,
        billing_type: str = "self-hosted-essence-model",
    ) -> "Avatar":
        """Load a .imx model fixture from disk.

        Parameters
        ----------
        model_path:
            Path to a `.imx` essence model.
        api_secret:
            Developer API secret (from https://www.bithuman.ai → Developer →
            API Keys). Falls back to the BITHUMAN_API_SECRET env variable
            if not supplied. If neither is set AND BITHUMAN_UNMETERED=1 is
            not in the env, raises RuntimeError — we never run unmetered
            silently in production.
        preferred_ep:
            ONNX execution-provider hint. Defaults to CPU (the canonical,
            deterministic baseline).
        intra_op_threads:
            ORT intra-op thread count. 1 is best for low-latency single-
            stream rendering; bump to 2-4 only for batch / offline use.
        tags:
            Free-form string forwarded to the auth-service for usage
            reporting (e.g. "halo-app", "ci", "my-agent").
        fingerprint:
            Optional 32-char hardware fingerprint. If omitted, libessence
            generates a process-stable random one — fine for dev, but the
            shipped wrapper should derive a real per-machine ID at the
            application layer.
        billing_type:
            Heartbeat billing type. Defaults to self-hosted-essence-model
            (1 credit/minute, matches the Swift SDK Essence rate).
        """
        path = Path(model_path).expanduser()
        if not path.exists():
            raise FileNotFoundError(f"Essence model not found: {path}")

        # Auth path: configure + authenticate + start background heartbeat
        # BEFORE we touch any avatar API. If the wrapper user has set
        # BITHUMAN_UNMETERED=1, we skip entirely (dev / parity-test mode).
        unmetered = os.environ.get("BITHUMAN_UNMETERED", "") == "1"
        secret = api_secret or os.environ.get("BITHUMAN_API_SECRET", "")
        if not unmetered:
            if not secret:
                raise RuntimeError(
                    "bithuman.Avatar.load: api_secret is required "
                    "(or set BITHUMAN_API_SECRET in env, or BITHUMAN_UNMETERED=1 for dev)."
                )
            _core.auth_init(
                api_secret=secret,
                billing_type=billing_type,
                tags=tags,
                fingerprint=fingerprint or "",
            )
            _core.auth_authenticate()
            _core.auth_start_heartbeat()

        fx = _core.Fixture(
            str(path),
            preferred_ep=int(preferred_ep),
            intra_op_threads=int(intra_op_threads),
        )
        return cls(fx)

    # ------- introspection -------

    @property
    def frame_width(self) -> int:
        return self._require_fixture().frame_width

    @property
    def frame_height(self) -> int:
        return self._require_fixture().frame_height

    @property
    def sample_rate(self) -> int:
        """Required audio sample rate, hertz. Always 16000."""
        return _SAMPLE_RATE_HZ

    @property
    def samples_per_tick(self) -> int:
        """Samples consumed per compose tick (640 = 40 ms @ 16 kHz)."""
        return self._require_fixture().audio_samples_per_tick

    @property
    def fps(self) -> int:
        """Output frame rate. Always 25."""
        return _FPS

    @property
    def cluster_count(self) -> int:
        return self._require_fixture().cluster_count

    @property
    def source_frame_count(self) -> int:
        return self._require_fixture().source_frame_count

    @property
    def active_ep(self) -> EP:
        return EP(self._require_fixture().active_ep)

    # ------- core API -------

    def compose(
        self,
        audio: AudioInput,
        preallocated_out: Optional[np.ndarray] = None,
        output_size: Optional[tuple] = (1280, 720),
    ) -> Iterator[ComposedFrame]:
        """Yield one ComposedFrame per 40 ms (25 fps) of input audio.

        Parameters
        ----------
        audio:
            16 kHz float32 mono numpy array, OR a path to a WAV/MP3/FLAC
            file (auto-decoded via soundfile; resampled if needed).
        preallocated_out:
            Optional (H, W, 3) uint8 ndarray. If provided, the BGR pixel
            data for each frame will be copied into this buffer and the
            same buffer reference is reused across yields. This is the
            zero-allocation path for tight render loops. Note: this means
            consumers must finish processing the previous frame before
            advancing the iterator.
        output_size:
            (target_width, target_height) for the composed frame. Default
            (1280, 720) — the Phase 2 standardized contract; aspect-preserving
            fit with letterbox/pillarbox padding to black. Pass None for
            native source resolution (legacy behavior; size depends on the
            .imx). For portrait .imx, pass (720, 1280).

        Yields
        ------
        ComposedFrame: bgr, cluster_idx, frame_idx
        """
        fx = self._require_fixture()
        pcm = _decode_audio(audio)
        spt = fx.audio_samples_per_tick
        if pcm.size < spt:
            return  # nothing to do

        max_ticks = pcm.size // spt + 2  # safety cushion
        rt = _core.Runtime(fx)

        # Hot path: if the caller gave us a preallocated buffer, pass it
        # through to the C ABI via `out=` and avoid both the numpy alloc and
        # the np.copyto on every tick. Shape validation is deferred to the
        # first tick because the source frame dims aren't known until the
        # lazy v1 init runs (Avatar.frame_width / .frame_height return 0
        # before that).
        if output_size is not None:
            tw, th = int(output_size[0]), int(output_size[1])
        else:
            tw = th = None
        prealloc_validated = False

        def _validate_prealloc(buf, w, h):
            expected = (h, w, 3)
            if (buf.dtype != np.uint8
                    or buf.shape != expected
                    or not buf.flags["C_CONTIGUOUS"]):
                raise ValueError(
                    f"preallocated_out must be a C-contiguous uint8 ndarray "
                    f"with shape {expected}, got dtype={buf.dtype} "
                    f"shape={buf.shape}"
                )

        # For output_size=None the shape is unknown pre-init, so we cannot
        # use `out=` on tick 0; fall back to the alloc path for that one
        # tick, copy into the caller's buffer, and switch to `out=` for the
        # remainder. With output_size set the dims are known up front.
        if preallocated_out is not None and output_size is not None:
            _validate_prealloc(preallocated_out, tw, th)
            prealloc_validated = True

        t = 0
        while t < max_ticks:
            try:
                if preallocated_out is not None and prealloc_validated:
                    if output_size is not None:
                        cluster = rt.tick_compose_to_size(
                            pcm, -1, tw, th, out=preallocated_out)
                    else:
                        cluster = rt.tick_compose(pcm, -1, out=preallocated_out)
                    bgr = preallocated_out
                elif preallocated_out is not None:
                    # First tick at native resolution: dims unknown to the
                    # facade. Take the alloc path, copy into prealloc, then
                    # validate + flip to the fast path for subsequent ticks.
                    cluster, fresh = rt.tick_compose(pcm, -1)
                    _validate_prealloc(preallocated_out, fresh.shape[1], fresh.shape[0])
                    prealloc_validated = True
                    tw = fresh.shape[1]
                    th = fresh.shape[0]
                    np.copyto(preallocated_out, fresh)
                    bgr = preallocated_out
                else:
                    if output_size is not None:
                        cluster, bgr = rt.tick_compose_to_size(pcm, -1, tw, th)
                    else:
                        cluster, bgr = rt.tick_compose(pcm, -1)
            except ValueError as exc:
                # Expected at end-of-audio: "tick cursor past end of audio".
                if "cursor past end" in str(exc):
                    return
                raise

            yield ComposedFrame(bgr=bgr, cluster_idx=int(cluster), frame_idx=t)
            t += 1

    # ------- lifecycle -------

    def close(self) -> None:
        """Release the underlying C fixture. Idempotent."""
        if not self._closed:
            self._fixture = None  # drops refcount; pybind11 calls destructor
            self._closed = True

    def __enter__(self) -> "Avatar":
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()

    def __del__(self):
        # best-effort safety net; not a substitute for `with` / .close()
        try:
            self.close()
        except Exception:
            pass

    # ------- internals -------

    def _require_fixture(self) -> _core.Fixture:
        if self._closed or self._fixture is None:
            raise RuntimeError("Avatar is closed; load a new one to continue.")
        return self._fixture


__all__ = ["Avatar", "ComposedFrame", "EP"]
