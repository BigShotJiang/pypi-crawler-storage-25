"""Data models mirroring `bithuman.api` (legacy v1.11.2).

Field-for-field parity with legacy so production services that import
`AudioChunk`, `VideoControl`, `VideoFrame`, `Emotion`, `EmotionPrediction`
from `bithuman` can swap to `bithuman` with only the import
path changing.

Key compatibility notes:

* ``AudioChunk.data`` is stored as **int16** internally (legacy does
  the same — float input is rescaled by INT16_MAX in ``__post_init__``).
  The ``.array`` property is an alias for ``.data``; ``.bytes`` is the
  raw int16 PCM byte view. The ``.from_bytes`` classmethod decodes
  raw int16 bytes back into an ``AudioChunk``.

* ``VideoControl.is_idle`` is True iff every payload slot is empty.
  ``is_speaking`` is True iff ``audio`` is set. Used by the agent
  worker to decide whether to emit idle-loop frames.

* ``VideoFrame.rgb_image`` is a view (``[:, :, ::-1]``) — no copy.
  Consumers that need a stable RGB buffer should ``.copy()`` it.

* ``Emotion`` is a ``str, Enum`` (legacy), not an ``IntEnum`` — the
  string values flow through JSON unchanged. The agent worker prompts
  the LLM with these literal strings; do not switch to IntEnum without
  coordinated downstream changes.

* ``EmotionPrediction`` uses ``score: float`` (legacy field name).
  We accept ``confidence`` as a keyword alias for forward-compat with
  the brief, but ``score`` is canonical.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Hashable, List, Optional, Union

import numpy as np

# Legacy uses int16 PCM end-to-end; float32 input is rescaled by this.
INT16_MAX = 2**15 - 1


# ---------------------------------------------------------------------
# AudioChunk
# ---------------------------------------------------------------------


@dataclass
class AudioChunk:
    """One chunk of audio bound for the avatar runtime.

    Attributes
    ----------
    data:
        Audio samples as a 1-D int16 numpy array. The constructor will
        coerce ``bytes`` / float32 / float64 input to int16 to match
        legacy semantics.
    sample_rate:
        Sample rate in hertz (typically 16000 for the avatar pipeline).
    last_chunk:
        Marks the final chunk of a speech utterance. The runtime uses
        this to flush internal buffers and emit ``end_of_speech`` on
        the final composed frame.
    """

    data: np.ndarray
    sample_rate: int
    last_chunk: bool = True

    def __post_init__(self) -> None:
        if isinstance(self.data, bytes):
            self.data = np.frombuffer(self.data, dtype=np.int16)

        if isinstance(self.data, np.ndarray) and self.data.dtype in (np.float32, np.float64):
            # Legacy: scale [-1, +1] float to int16 range. We do NOT clip;
            # callers that hand us out-of-range floats get wraparound to
            # match legacy verbatim.
            self.data = (self.data * INT16_MAX).astype(np.int16)

        if not isinstance(self.data, np.ndarray) or self.data.dtype != np.int16:
            raise ValueError("data must be in int16 numpy array format")

    # ---- properties ---------------------------------------------

    @property
    def bytes(self) -> bytes:
        """Raw int16 PCM byte view (little-endian on macOS / arm64)."""
        return self.data.tobytes()

    @property
    def array(self) -> np.ndarray:
        """Alias for ``data`` — kept for legacy parity."""
        return self.data

    @property
    def duration(self) -> float:
        """Duration of this chunk in seconds (``len(data) / sample_rate``)."""
        return len(self.data) / self.sample_rate

    # ---- constructors -------------------------------------------

    @classmethod
    def from_bytes(
        cls,
        audio_bytes: bytes,
        sample_rate: int,
        last_chunk: bool = True,
    ) -> "AudioChunk":
        """Build an AudioChunk from raw int16 little-endian PCM bytes."""
        return cls(
            data=np.frombuffer(audio_bytes, dtype=np.int16),
            sample_rate=sample_rate,
            last_chunk=last_chunk,
        )


# ---------------------------------------------------------------------
# Emotion + EmotionPrediction
# ---------------------------------------------------------------------


class Emotion(str, Enum):
    """Emotion label, matches legacy `bithuman.api.Emotion`.

    These are the seven canonical labels the agent worker prompts the
    LLM with. They flow through JSON as their string values.
    """

    ANGER = "anger"
    DISGUST = "disgust"
    FEAR = "fear"
    JOY = "joy"
    NEUTRAL = "neutral"
    SADNESS = "sadness"
    SURPRISE = "surprise"


@dataclass
class EmotionPrediction:
    """Emotion classifier output for one audio segment.

    Legacy uses pydantic BaseModel with fields ``emotion`` + ``score``;
    we use ``dataclass`` to avoid pulling in pydantic for the core
    wrapper, while keeping the field names and serialization shape.
    """

    emotion: Emotion
    score: float

    @classmethod
    def from_dict(cls, data: dict) -> "EmotionPrediction":
        emotion_val = data["emotion"]
        if not isinstance(emotion_val, Emotion):
            emotion_val = Emotion(emotion_val)
        return cls(emotion=emotion_val, score=float(data["score"]))

    def to_dict(self) -> dict:
        return {"emotion": self.emotion.value, "score": self.score}


# ---------------------------------------------------------------------
# VideoControl
# ---------------------------------------------------------------------


@dataclass
class VideoControl:
    """One unit of input to the avatar runtime.

    The runtime consumes a stream of these. Each control is either
    "speaking" (has an ``AudioChunk``), an action / target-video cue,
    an emotion override, or "idle" (everything None) — in which case
    the runtime emits idle-loop frames.
    """

    audio: Optional[AudioChunk] = None
    text: Optional[str] = None
    target_video: Optional[str] = None
    action: Optional[Union[str, List[str]]] = None
    emotion_preds: Optional[List[EmotionPrediction]] = None
    message_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    end_of_speech: bool = False
    force_action: bool = False
    stop_on_user_speech: Optional[bool] = None
    stop_on_agent_speech: Optional[bool] = None

    @property
    def is_idle(self) -> bool:
        """True when this control carries no work (no audio, no action)."""
        return (
            self.audio is None
            and self.target_video is None
            and not self.action
            and not self.emotion_preds
        )

    @property
    def is_speaking(self) -> bool:
        """True when this control carries audio (i.e. speech)."""
        return self.audio is not None

    @classmethod
    def from_audio(
        cls,
        audio: Union[bytes, np.ndarray],
        sample_rate: int,
        last_chunk: bool = True,
    ) -> "VideoControl":
        """Wrap raw audio bytes / numpy in a VideoControl in one call."""
        if isinstance(audio, bytes):
            audio_chunk = AudioChunk.from_bytes(audio, sample_rate, last_chunk)
        elif isinstance(audio, np.ndarray):
            audio_chunk = AudioChunk(
                data=audio, sample_rate=sample_rate, last_chunk=last_chunk
            )
        else:
            raise ValueError("audio must be bytes or numpy array")
        return cls(audio=audio_chunk)


# ---------------------------------------------------------------------
# VideoFrame
# ---------------------------------------------------------------------


@dataclass
class VideoFrame:
    """One composed avatar frame.

    Attributes
    ----------
    bgr_image:
        (H, W, 3) uint8 BGR image, or None for control-only frames
        (e.g. end-of-speech markers without a render attached).
    audio_chunk:
        The audio slice that aligns with this frame, or None if the
        runtime is in idle-loop / no-speech mode.
    frame_index:
        Zero-based tick index inside the current speech utterance,
        reset whenever the runtime transitions speaking → idle.
    source_message_id:
        Echoes the ``message_id`` of the originating VideoControl,
        so consumers can correlate frames back to the request.
    end_of_speech:
        True only on the final composed frame of an utterance.
    """

    bgr_image: Optional[np.ndarray] = None
    audio_chunk: Optional[AudioChunk] = None
    frame_index: Optional[int] = None
    source_message_id: Optional[Hashable] = None
    end_of_speech: bool = False

    @property
    def has_image(self) -> bool:
        return self.bgr_image is not None

    @property
    def rgb_image(self) -> Optional[np.ndarray]:
        """A view of bgr_image with channels reversed. No copy."""
        if self.bgr_image is None:
            return None
        return self.bgr_image[:, :, ::-1]


__all__ = [
    "INT16_MAX",
    "AudioChunk",
    "VideoControl",
    "VideoFrame",
    "Emotion",
    "EmotionPrediction",
]
