# AION — Structural Consistency for Clinical Data

Formal temporal and causal structure for consistent clinical data across systems.

[![Tests](https://img.shields.io/badge/tests-326%20passing-brightgreen)](https://codeberg.org/fm2-project/aion)
[![Python](https://img.shields.io/badge/python-3.10%2B-blue)](https://www.python.org/)
[![License](https://img.shields.io/badge/license-EUPL--1.2-blue)](LICENSE)
[![FHIR R4](https://img.shields.io/badge/FHIR-R4-orange)](https://hl7.org/fhir/R4/)
[![DOI](https://img.shields.io/badge/DOI-10.5281/zenodo.19548857-blue)](https://doi.org/10.5281/zenodo.19548857)

---

Clinical data systems often produce inconsistent results.

Not because of missing interfaces —  
but because **time, semantics and causality are not modelled consistently**.

AION makes clinical data **consistent and verifiable** across systems.

It provides a formal, executable structure to:

- represent clinical events over time  
- define and validate relationships between them  
- ensure consistent interpretation across systems  
- enable reproducible analytics and reliable AI  

Most systems exchange clinical data.

AION ensures that this data is interpreted consistently.

---

## Quick Start

```bash
pip install aion-clinical
```

```python
from aion.core import Interval, classify
import datetime

dt = lambda h: datetime.datetime(2024, 1, 1, h, 0)

anaesthesia = Interval(dt(7), dt(12))
operation   = Interval(dt(8), dt(11))

print(classify(anaesthesia, operation))
# -> AllenRelation.CONTAINS
```

---

## Why AION?

Most systems can exchange clinical data.

The harder problem begins afterwards:

- data is interpreted differently across systems
- temporal relations remain implicit
- causal assumptions are hidden in project-specific logic
- analytics become difficult to compare and reproduce

AION addresses this structural layer directly.

Instead of modelling isolated data points only, AION models:

- **intervals instead of points**
- **relations instead of implicit assumptions**
- **causal structures instead of static data**
- **verifiable consistency instead of hidden transformation logic**

---

## What is AION?

AION is a formal, executable model for clinical information systems.

It generalises earlier formal models (FM-1, FM-2 / CAIRN)  
into a domain-independent structure for clinical data.

---

## Core Capabilities

### Temporal Model
- Complete Allen interval algebra (13 relations)
- Fuzzy intervals with probabilistic reasoning

### Data Model
- Universal clinical event model (6-tuple)
- Type system with hierarchy and schema evolution

### Query & Analytics
- Cohort algebra
- Temporal pattern languages

### Causal Inference
- Causal graphs
- Do-operator
- Structure learning

### AI Integration
- Formal AI component model
- Explainability (Shapley, counterfactuals)

### Privacy
- Differential privacy (Laplace / Gaussian)
- Federated computation

### Interoperability
- FHIR mapping via structural homomorphism

---

### Example: Cohort Query

```python
from aion.query.cohort import query_event_sequence

q = query_event_sequence("Diagnosis", "Procedure")
cohort = q.evaluate(ctx)
```

---

### Example: Causal Analysis

```python
from aion.causal.graph import CausalGraph
from aion.causal.do import DoOperator

g = CausalGraph()
g.add_edge("Diagnosis", "Procedure")

do = DoOperator(g, data)
result = do.intervene("Procedure", "Outcome")
```

---

## Test Suite

```bash
pytest aion/tests/
# 326 tests, ~2s runtime
```

---

## Architecture

```text
aion/
├── core/          Allen algebra (13 relations), type system σ(τ),
│                  event 6-tuple, fuzzy intervals, process DAG
├── abstraction/   Episode formation B_{Φ,Δ}, clinical trajectories
├── query/         Cohort algebra, RTP patterns, TCFG, predicates
├── causal/        Causal graph, do-operator, backdoor adjustment,
│                  PC algorithm, bootstrap structure learning
├── privacy/       ε-DP Laplace/Gaussian, federated model, LDP
├── ai/            AI components A_l = (X,Y,f_θ,L,θ*), Π_l operator,
│                  feature extraction Ψ, risk estimation
├── explain/       Shapley attribution, counterfactual Δ*_cf,
│                  sufficient explanation S*_suf, Π_l^+ gate
├── schema/        Versioned type system, 7 schema change ops,
│                  migration function μ_{v→v'}
└── adapters/
    └── fhir/      Structural homomorphism (h_T, h_σ), Q_map index
```

---

## Key Concepts

### Event 6-Tuple (AION §5)

```python
e = (p, a, τ, [t^B, t^E], α, ρ)
```

- `p` patient, `a` stay, `τ` type, `[t^B,t^E]` interval, `α` attributes, `ρ` references

---

## Positioning

AION is not:

- a data format
- a data warehouse
- a FHIR replacement

AION is:

> **the structural consistency layer beneath clinical data systems**

---

## License & Citation

**EUPL-1.2** — open source. Commercial licence: `licensing@iscad-it.de`

```bibtex
@software{aion2026,
  title  = {AION: Algebraic Interval Ontology for Clinical Networks},
  author = {Matten, Friedhelm},
  year   = {2026},
  url    = {https://codeberg.org/fm2-project/aion},
  doi    = {10.5281/zenodo.19548857}
}
```

© Friedhelm Matten, ISCaD GmbH
