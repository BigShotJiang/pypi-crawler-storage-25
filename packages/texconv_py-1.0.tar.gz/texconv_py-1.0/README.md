# Texconv-Py
A lightweight Python wrapper around Microsoft's Texconv (DirectXTex).

## Features
- Type hints for every setting and flag
- Checks for conflicting options

## Requirements
- `texconv.exe` (Windows) — download from [DirectXTex releases](https://github.com/Microsoft/DirectXTex/releases/latest/download/texconv.exe)

## Installation
```bash
pip install texconv-py
```

## Usage

#### Converting a DXT5 Normal Map
```python
from pathlib import Path
from texconv import Texconv, FileOptions, ImageOptions, NormalMapOptions, FormatOptions, Format

TEXCONV = Path(r"path\to\Texconv.exe")

# Creating the Texconv instance
fix_nmap_dxt5 = Texconv(TEXCONV, 
        FileOptions(
            output=Path(r"path\to\output\folder"),
            overwrite=True),
        ImageOptions(swizzle="ga11"),
        NormalMapOptions(invert_y=True, reconstruct_z=True),
        FormatOptions(format=Format.DXGI_FORMAT_BC1_UNORM)
        )

# Using a list of Path (or strings)
nmaps = [
    Path(r"path\to\tex1_n.dds"),
    Path(r"path\to\tex42_n.dds"),
    Path(r"path\to\tex10_n.dds"),
    Path(r"path\to\test_n.dds")
]

# Running Texconv
fix_nmap_dxt5.run(nmaps)
```
#### Performing various changes to images using a text file for the paths
```python
from pathlib import Path
from texconv import Texconv, FileOptions, ImageOptions, FileType, FormatOptions

TEXCONV = Path(r"path\to\Texconv.exe")

Texconv(TEXCONV, 
    FileOptions(
        output=Path(r"path\to\output\folder"),
        overwrite=True,
        to_lowercase=True,
        prefix='pre_'),
    ImageOptions(horizontal_flip=True),
    FormatOptions(file_type=FileType.PNG)
).run(r"path\to\textures.txt", file_list=True)
```


## License

MIT License — see [LICENSE](LICENSE) for details.
