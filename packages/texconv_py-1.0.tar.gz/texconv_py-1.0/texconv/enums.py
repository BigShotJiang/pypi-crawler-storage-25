from enum import StrEnum



class RecursiveMode(StrEnum):
    """
    - `FLATTEN`: The resulting output directory just includes the files.
    - `KEEP`:    The output directory includes the subdirectory structure of the source tree.
    """
    FLATTEN = "-r:flatten"
    KEEP    = "-r:keep"



class FileType(StrEnum):
    """
    - `BMP`: Windows BMP
    - `JPG`, `JPEG`: Joint Photographic Experts Group
    - `PNG`: Portable Network Graphics
    - `DDS`, `DDX`: DirectDraw Surface (Direct3D texture file format)
    - `TGA`: Truevision Graphics Adapter
    - `HDR`: Radiance RGBE
    - `TIF`, `TIFF`: Tagged Image File Format
    - `WDP`, `HDP`, `JXR`: Windows Media Photo
    - `PPM`, `PFM`: Portable PixMap, Portable FloatMap (Netpbm)
    """
    BMP = 'bmp'
    JPG = 'jpg'
    JPEG = 'jpeg'
    PNG = 'png'
    DDS = 'dds'
    DDX = 'ddx'
    TGA = 'tga'
    HDR = 'hdr'
    TIF = 'tif'
    TIFF = 'tiff'
    WDP = 'wdp'
    HDP = 'hdp'
    JXR = 'jxr'
    PPM = 'ppm'
    PFM = 'pfm'



class Format(StrEnum):
    DXGI_FORMAT_UNKNOWN = 'UNKNOWN'
    DXGI_FORMAT_R32G32B32A32_TYPELESS = 'R32G32B32A32_TYPELESS'
    DXGI_FORMAT_R32G32B32A32_FLOAT = 'R32G32B32A32_FLOAT'
    DXGI_FORMAT_R32G32B32A32_UINT = 'R32G32B32A32_UINT'
    DXGI_FORMAT_R32G32B32A32_SINT = 'R32G32B32A32_SINT'
    DXGI_FORMAT_R32G32B32_TYPELESS = 'R32G32B32_TYPELESS'
    DXGI_FORMAT_R32G32B32_FLOAT = 'R32G32B32_FLOAT'
    DXGI_FORMAT_R32G32B32_UINT = 'R32G32B32_UINT'
    DXGI_FORMAT_R32G32B32_SINT = 'R32G32B32_SINT'
    DXGI_FORMAT_R16G16B16A16_TYPELESS = 'R16G16B16A16_TYPELESS'
    DXGI_FORMAT_R16G16B16A16_FLOAT = 'R16G16B16A16_FLOAT'
    DXGI_FORMAT_R16G16B16A16_UNORM = 'R16G16B16A16_UNORM'
    DXGI_FORMAT_R16G16B16A16_UINT = 'R16G16B16A16_UINT'
    DXGI_FORMAT_R16G16B16A16_SNORM = 'R16G16B16A16_SNORM'
    DXGI_FORMAT_R16G16B16A16_SINT = 'R16G16B16A16_SINT'
    DXGI_FORMAT_R32G32_TYPELESS = 'R32G32_TYPELESS'
    DXGI_FORMAT_R32G32_FLOAT = 'R32G32_FLOAT'
    DXGI_FORMAT_R32G32_UINT = 'R32G32_UINT'
    DXGI_FORMAT_R32G32_SINT = 'R32G32_SINT'
    DXGI_FORMAT_R32G8X24_TYPELESS = 'R32G8X24_TYPELESS'
    DXGI_FORMAT_D32_FLOAT_S8X24_UINT = 'D32_FLOAT_S8X24_UINT'
    DXGI_FORMAT_R32_FLOAT_X8X24_TYPELESS = 'R32_FLOAT_X8X24_TYPELESS'
    DXGI_FORMAT_X32_TYPELESS_G8X24_UINT = 'X32_TYPELESS_G8X24_UINT'
    DXGI_FORMAT_R10G10B10A2_TYPELESS = 'R10G10B10A2_TYPELESS'
    DXGI_FORMAT_R10G10B10A2_UNORM = 'R10G10B10A2_UNORM'
    DXGI_FORMAT_R10G10B10A2_UINT = 'R10G10B10A2_UINT'
    DXGI_FORMAT_R11G11B10_FLOAT = 'R11G11B10_FLOAT'
    DXGI_FORMAT_R8G8B8A8_TYPELESS = 'R8G8B8A8_TYPELESS'
    DXGI_FORMAT_R8G8B8A8_UNORM = 'R8G8B8A8_UNORM'
    DXGI_FORMAT_R8G8B8A8_UNORM_SRGB = 'R8G8B8A8_UNORM_SRGB'
    DXGI_FORMAT_R8G8B8A8_UINT = 'R8G8B8A8_UINT'
    DXGI_FORMAT_R8G8B8A8_SNORM = 'R8G8B8A8_SNORM'
    DXGI_FORMAT_R8G8B8A8_SINT = 'R8G8B8A8_SINT'
    DXGI_FORMAT_R16G16_TYPELESS = 'R16G16_TYPELESS'
    DXGI_FORMAT_R16G16_FLOAT = 'R16G16_FLOAT'
    DXGI_FORMAT_R16G16_UNORM = 'R16G16_UNORM'
    DXGI_FORMAT_R16G16_UINT = 'R16G16_UINT'
    DXGI_FORMAT_R16G16_SNORM = 'R16G16_SNORM'
    DXGI_FORMAT_R16G16_SINT = 'R16G16_SINT'
    DXGI_FORMAT_R32_TYPELESS = 'R32_TYPELESS'
    DXGI_FORMAT_D32_FLOAT = 'D32_FLOAT'
    DXGI_FORMAT_R32_FLOAT = 'R32_FLOAT'
    DXGI_FORMAT_R32_UINT = 'R32_UINT'
    DXGI_FORMAT_R32_SINT = 'R32_SINT'
    DXGI_FORMAT_R24G8_TYPELESS = 'R24G8_TYPELESS'
    DXGI_FORMAT_D24_UNORM_S8_UINT = 'D24_UNORM_S8_UINT'
    DXGI_FORMAT_R24_UNORM_X8_TYPELESS = 'R24_UNORM_X8_TYPELESS'
    DXGI_FORMAT_X24_TYPELESS_G8_UINT = 'X24_TYPELESS_G8_UINT'
    DXGI_FORMAT_R8G8_TYPELESS = 'R8G8_TYPELESS'
    DXGI_FORMAT_R8G8_UNORM = 'R8G8_UNORM'
    DXGI_FORMAT_R8G8_UINT = 'R8G8_UINT'
    DXGI_FORMAT_R8G8_SNORM = 'R8G8_SNORM'
    DXGI_FORMAT_R8G8_SINT = 'R8G8_SINT'
    DXGI_FORMAT_R16_TYPELESS = 'R16_TYPELESS'
    DXGI_FORMAT_R16_FLOAT = 'R16_FLOAT'
    DXGI_FORMAT_D16_UNORM = 'D16_UNORM'
    DXGI_FORMAT_R16_UNORM = 'R16_UNORM'
    DXGI_FORMAT_R16_UINT = 'R16_UINT'
    DXGI_FORMAT_R16_SNORM = 'R16_SNORM'
    DXGI_FORMAT_R16_SINT = 'R16_SINT'
    DXGI_FORMAT_R8_TYPELESS = 'R8_TYPELESS'
    DXGI_FORMAT_R8_UNORM = 'R8_UNORM'
    DXGI_FORMAT_R8_UINT = 'R8_UINT'
    DXGI_FORMAT_R8_SNORM = 'R8_SNORM'
    DXGI_FORMAT_R8_SINT = 'R8_SINT'
    DXGI_FORMAT_A8_UNORM = 'A8_UNORM'
    DXGI_FORMAT_R1_UNORM = 'R1_UNORM'
    DXGI_FORMAT_R9G9B9E5_SHAREDEXP = 'R9G9B9E5_SHAREDEXP'
    DXGI_FORMAT_R8G8_B8G8_UNORM = 'R8G8_B8G8_UNORM'
    DXGI_FORMAT_G8R8_G8B8_UNORM = 'G8R8_G8B8_UNORM'
    DXGI_FORMAT_BC1_TYPELESS = 'BC1_TYPELESS'
    DXGI_FORMAT_BC1_UNORM = 'BC1_UNORM'
    DXGI_FORMAT_BC1_UNORM_SRGB = 'BC1_UNORM_SRGB'
    DXGI_FORMAT_BC2_TYPELESS = 'BC2_TYPELESS'
    DXGI_FORMAT_BC2_UNORM = 'BC2_UNORM'
    DXGI_FORMAT_BC2_UNORM_SRGB = 'BC2_UNORM_SRGB'
    DXGI_FORMAT_BC3_TYPELESS = 'BC3_TYPELESS'
    DXGI_FORMAT_BC3_UNORM = 'BC3_UNORM'
    DXGI_FORMAT_BC3_UNORM_SRGB = 'BC3_UNORM_SRGB'
    DXGI_FORMAT_BC4_TYPELESS = 'BC4_TYPELESS'
    DXGI_FORMAT_BC4_UNORM = 'BC4_UNORM'
    DXGI_FORMAT_BC4_SNORM = 'BC4_SNORM'
    DXGI_FORMAT_BC5_TYPELESS = 'BC5_TYPELESS'
    DXGI_FORMAT_BC5_UNORM = 'BC5_UNORM'
    DXGI_FORMAT_BC5_SNORM = 'BC5_SNORM'
    DXGI_FORMAT_B5G6R5_UNORM = 'B5G6R5_UNORM'
    DXGI_FORMAT_B5G5R5A1_UNORM = 'B5G5R5A1_UNORM'
    DXGI_FORMAT_B8G8R8A8_UNORM = 'B8G8R8A8_UNORM'
    DXGI_FORMAT_B8G8R8X8_UNORM = 'B8G8R8X8_UNORM'
    DXGI_FORMAT_R10G10B10_XR_BIAS_A2_UNORM = 'R10G10B10_XR_BIAS_A2_UNORM'
    DXGI_FORMAT_B8G8R8A8_TYPELESS = 'B8G8R8A8_TYPELESS'
    DXGI_FORMAT_B8G8R8A8_UNORM_SRGB = 'B8G8R8A8_UNORM_SRGB'
    DXGI_FORMAT_B8G8R8X8_TYPELESS = 'B8G8R8X8_TYPELESS'
    DXGI_FORMAT_B8G8R8X8_UNORM_SRGB = 'B8G8R8X8_UNORM_SRGB'
    DXGI_FORMAT_BC6H_TYPELESS = 'BC6H_TYPELESS'
    DXGI_FORMAT_BC6H_UF16 = 'BC6H_UF16'
    DXGI_FORMAT_BC6H_SF16 = 'BC6H_SF16'
    DXGI_FORMAT_BC7_TYPELESS = 'BC7_TYPELESS'
    DXGI_FORMAT_BC7_UNORM = 'BC7_UNORM'
    DXGI_FORMAT_BC7_UNORM_SRGB = 'BC7_UNORM_SRGB'
    DXGI_FORMAT_AYUV = 'AYUV'
    DXGI_FORMAT_Y410 = 'Y410'
    DXGI_FORMAT_Y416 = 'Y416'
    DXGI_FORMAT_NV12 = 'NV12'
    DXGI_FORMAT_P010 = 'P010'
    DXGI_FORMAT_P016 = 'P016'
    DXGI_FORMAT_420_OPAQUE = '420_OPAQUE'
    DXGI_FORMAT_YUY2 = 'YUY2'
    DXGI_FORMAT_Y210 = 'Y210'
    DXGI_FORMAT_Y216 = 'Y216'
    DXGI_FORMAT_NV11 = 'NV11'
    DXGI_FORMAT_AI44 = 'AI44'
    DXGI_FORMAT_IA44 = 'IA44'
    DXGI_FORMAT_P8 = 'P8'
    DXGI_FORMAT_A8P8 = 'A8P8'
    DXGI_FORMAT_B4G4R4A4_UNORM = 'B4G4R4A4_UNORM'
    DXGI_FORMAT_P208 = 'P208'
    DXGI_FORMAT_V208 = 'V208'
    DXGI_FORMAT_V408 = 'V408'
    DXGI_FORMAT_SAMPLER_FEEDBACK_MIN_MIP_OPAQUE = 'SAMPLER_FEEDBACK_MIN_MIP_OPAQUE'
    DXGI_FORMAT_SAMPLER_FEEDBACK_MIP_REGION_USED_OPAQUE = 'SAMPLER_FEEDBACK_MIP_REGION_USED_OPAQUE'
    DXGI_FORMAT_FORCE_UINT = 'FORCE_UINT'



class Filter(StrEnum):
    "Filters with `DITHER` in their name indicate that the 4x4 ordered dither algorithm, while `DITHER_DIFFUSION` is error diffusion dithering."
    POINT = 'POINT'
    LINEAR = 'LINEAR'
    CUBIC = 'CUBIC'
    FANT = 'FANT'
    BOX = 'BOX'
    TRIANGLE = 'TRIANGLE'
    POINT_DITHER = 'POINT_DITHER'
    LINEAR_DITHER = 'LINEAR_DITHER'
    CUBIC_DITHER = 'CUBIC_DITHER'
    FANT_DITHER = 'FANT_DITHER'
    BOX_DITHER = 'BOX_DITHER'
    TRIANGLE_DITHER = 'TRIANGLE_DITHER'
    POINT_DITHER_DIFFUSION = 'POINT_DITHER_DIFFUSION'
    LINEAR_DITHER_DIFFUSION = 'LINEAR_DITHER_DIFFUSION'
    CUBIC_DITHER_DIFFUSION = 'CUBIC_DITHER_DIFFUSION'
    FANT_DITHER_DIFFUSION = 'FANT_DITHER_DIFFUSION'
    BOX_DITHER_DIFFUSION = 'BOX_DITHER_DIFFUSION'
    TRIANGLE_DITHER_DIFFUSION = 'TRIANGLE_DITHER_DIFFUSION'



class Addressing(StrEnum):
    WRAP = '-wrap'
    MIRROR = '-mirror'



class SRGB(StrEnum):
    """
    - Use `BOTH` if both the input and output data are in the sRGB color format (ie. gamma ~2.2)
    - Use `IN` if only the input is in sRGB
    - Use `OUT` if only the output is in sRGB.
    """
    BOTH = '-srgb'
    IN = '--srgb-in'
    OUT = '--srgb-out'



class ColorRotations(StrEnum):
    """
    - `Rec709to2020`: Converts from Rec.709 color primaries to Rec.2020 color primaries.
    - `Rec2020to709`: Converts from Rec.2020 color primaries to Rec.709 color primaries.
    - `Rec709toHDR10`: Converts from Rec.709 color primaries to Rec.2020, normalizing nits, and applying the ST.2084 curve to create an HDR10 signal.
    - `HDR10to709`: Converts an HDR10 signal back to Rec.709 color primaries with linear values.
    - `P3to2020`: Converts from DCI-P3 color primaries to Rec.2020 color primaries.
    - `P3toHDR10`: Converts from DCI-P3 color primaries to Rec.2020, normalizing nits, and applying the ST.2084 curve to create an HDR10 signal.
    - `Rec709toDisplayP3`: Converts from Rec.709 color primaries to Display-P3 (D65 white point)
    - `DisplayP3to709`: Converts from Display-P3 (D65 white point) to Rec.709 color primaries.
    """
    Rec709to2020 =      '709to2020'
    Rec2020to709 =      '2020to709'
    Rec709toHDR10 =     '709toHDR10'
    HDR10to709 =        'HDR10to709'
    P3to2020 =          'P3to2020'
    P3toHDR10 =         'P3toHDR10'
    Rec709toDisplayP3 = '709toDisplayP3'
    DisplayP3to709 =    'DisplayP3to709'



class CompressionFlags(StrEnum):
    """
    - `UNIFORM`: Use uniform weighting rather than perceptual (BC1-BC3)
    - `DITHERING`: Use dithering (BC1-BC3)
    - `MIN_COMPRESSION`: Uses minimal compression (BC7: uses just mode 6)
    - `MAX_COMPRESSION`: Uses maximum compression (BC7: enables mode 0 & 2 usage)
    """
    UNIFORM = 'u'
    DITHERING = 'd'
    MIN_COMPRESSION = 'q'
    MAX_COMPRESSION = 'x'



class NormalMapFlags(StrEnum):
    """
    Indicates conversion from a height-map to a normal-map.
    The flags is a combination of one or more of the following, and must have one of `R`, `G`, `B`, `A`, or `L`:
    - `R`: Use the red channel of the input as the height
    - `G`: Use the green channel of the input as the height
    - `B`: Use the blue channel of the input as the height
    - `A`: Use the alpha channel of the input as the height
    - `L`: Use the luminance computed from red, green, and blue channels of the input as the height
    - `M`: Use mirroring in U & V. Defaults to wrap when doing the central difference computation.
    - `U`: Use mirroring in U. Defaults to wrap when doing the central difference computation.
    - `V`: Use mirroring in V. Defaults to wrap when doing the central difference computation.
    - `I`: Invert sign of the computed normal
    - `O`: Compute a rough occlusion term and encode it into the alpha channel of the output.
    """
    R = 'r'
    G = 'g'
    B = 'b'
    A = 'a'
    L = 'l'
    M = 'm'
    U = 'u'
    V = 'v'
    I = 'i'
    O = 'o'



class TypelessFormat(StrEnum):
    """
    - `UNORM`: DDS files with TYPELESS formats are treated as `UNORM`
    - `FLOAT`: DDS files with TYPELESS formats are treated as `FLOAT`
    """
    UNORM = '--typeless-unorm'
    FLOAT = '--typeless-float'



class FeatureLevel(StrEnum):
    "https://walbourn.github.io/direct3d-feature-levels/"
    v9_1 =  '9.1'
    v9_2 =  '9.2'
    v9_3 =  '9.3'
    v10_0 = '10.0'
    v10_1 = '10.1'
    v11_0 = '11.0'
    v11_1 = '11.1'
    v12_0 = '12.0'
    v12_1 = '12.1'
    v12_2 = '12.2'
