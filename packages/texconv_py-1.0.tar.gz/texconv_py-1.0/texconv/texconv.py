import re
from typing import Sequence, Union, Optional, Tuple, List
from dataclasses import dataclass
from pathlib import Path
import subprocess

from .enums import (
    StrEnum,
    RecursiveMode,
    FileType,
    Format,
    Filter,
    Addressing,
    SRGB,
    ColorRotations,
    CompressionFlags,
    NormalMapFlags,
    TypelessFormat,
    FeatureLevel)


def append_flags(opt: str, flags: tuple[StrEnum, ...], args: list[str]):
    flags_str = ''.join(flag.value for flag in flags)
    if len(flags_str) > 0:
        args.extend([opt, flags_str])


@dataclass
class FileOptions:
    """
    :param recursive:       Input file names can contain wildcard characters (? or *).
                            If this switch is used, subdirectories are also searched. Use :class:`RecursiveMode`.
    :param prefix:          Text string to attach to the front of the resulting texture's name.
    :param suffix:          Text string to attach to the end of the resulting texture's name.
    :param output:          Output directory.
    :param to_lowercase:    Forces the output path & filename to all lower-case.
    :param overwrite:       Overwrite existing output file if any.
    """
    recursive: Optional[RecursiveMode] = None
    prefix: Optional[str] = None
    suffix: Optional[str] = None
    output: Optional[Union[str, Path]] = None
    to_lowercase: bool = False
    overwrite: bool = False

    def to_args(self) -> List[str]:
        args = []
        if self.recursive:      args.extend([self.recursive.value])
        if self.prefix:         args.extend(['--prefix', self.prefix])
        if self.suffix:         args.extend(['--suffix', self.suffix])
        if self.output:         args.extend(['-o', str(self.output)])
        if self.to_lowercase:   args.append('--to-lowercase')
        if self.overwrite:      args.append('--overwrite')
        return args


@dataclass
class FormatOptions:
    """
    :param file_type: A file type for the output texture. Use :class:`FileType`.
    :param format:    Output format. Use :class:`Format`.
    """
    file_type: Optional[FileType] = None
    format: Optional[Format] = None

    def to_args(self) -> List[str]:
        args = []
        if self.file_type:      args.extend(['--file-type', self.file_type.value])
        if self.format:         args.extend(['--format', self.format.value])
        return args


@dataclass
class ResizingOptions:
    """
    :param width:           Width of the output texture in pixels.
    :param height:          Height of the output texture in pixels. If no size is given, the size is taken from the first input image.
    :param mip_levels:      Number of mipmap levels to generate in the output texture.
                            This setting only applies to DDS output, which defaults to 0 which is generate all mipmaps. Use -m 1 to remove mipmaps.
    :param fit_power_of_2:  Fits each texture to a power-of-2 for width & height, minimizing changes to the aspect ratio.
                            The maximum size for a dimension is based on the `Direct3DOptions.feature_level` switch (defaults to 16384).
    """
    width: Optional[int] = None
    height: Optional[int] = None
    mip_levels: Optional[int] = None
    fit_power_of_2: bool = False

    def to_args(self) -> List[str]:
        args = []
        if self.width is not None:      args.extend(['--width', str(self.width)])
        if self.height is not None:     args.extend(['--height', str(self.height)])
        if self.mip_levels is not None: args.extend(['--mip-levels', str(self.mip_levels)])
        if self.fit_power_of_2:         args.append('--fit-power-of-2')
        return args


@dataclass
class FilteringOptions:
    """
    :param image_filter:    Image filter used for resizing the images. Use :class:`Filter`.
    :param addressing:      Sets the texture addressing mode for filtering to wrap or mirror, otherwise defaults to clamp. Use :class:`Addressing`.
    :param nowic:           Forces filtering to use non-WIC-based code paths. This is useful for working around known issues
                            with WIC depending on which operating system you are using.
    """
    image_filter: Optional[Filter] = None
    addressing: Optional[Addressing] = None
    nowic: bool = False

    def to_args(self) -> List[str]:
        args = []
        if self.image_filter:   args.extend(['--image-filter', self.image_filter.value])
        if self.addressing:     args.append(self.addressing.value)
        if self.nowic:          args.append('-nowic')
        return args


@dataclass
class ColorspaceOptions:
    """
    :param srgb:                Use :class:`SRGB`.
    :param rotate_color:        Performs color rotations and/or ST.2084 curves for converting image data to/from HDR10 signals. Use :class:`ColorRotations`.
    :param paper_white_nits:    Provides a paper-white nits value for the HDR10 conversions above with an upper limit of 10000.
    :param tonemap:             Applies a Reinhard tonemap operator based on maximum luminosity to ensure HDR image data is adjusted to an LDR range.
    :param ignore_srgb:         When reading an image from the various WIC formats or `TGA`, this flag indicates that any metadata about
                                color-space in the file should be ignored and the resulting format is never `DXGI_FORMAT_*_SRGB`.
    """
    srgb: Optional[SRGB] = None
    rotate_color: Optional[ColorRotations] = None
    paper_white_nits: Optional[float] = None
    tonemap: bool = False
    ignore_srgb: bool = False

    def to_args(self) -> List[str]:
        args = []
        if self.srgb:                           args.append(self.srgb.value)
        if self.rotate_color:                   args.extend(['--rotate-color', self.rotate_color.value])
        if self.paper_white_nits is not None:   args.extend(['--paper-white-nits', str(self.paper_white_nits)])
        if self.tonemap:                        args.append('--tonemap')
        if self.ignore_srgb:                    args.append('--ignore-srgb')
        return args


@dataclass
class AlphaOptions:
    """
    :param premultiplied_alpha:     Converts the final texture data to use premultiplied alpha.
                                    This sets an alpha mode of `DDS_ALPHA_MODE_PREMULTIPLIED` unless the entire alpha channel is fully opaque.
    :param alpha:                   Converts a premultiplied alpha image to non-premultiplied alpha (a.k.a. straight alpha).
    :param separate_alpha:          Separates alpha channel for resize/mipmap generation. This implies an alpha mode setting of `DDS_ALPHA_MODE_CUSTOM`
                                    as this is typically only used if the alpha channel doesn't contain transparency information.
                                    
                                    *Without this flag, anywhere you have a 0 in the alpha channel, the RGB will be zero because of the fact that WIC
                                        operates with premultiplied-alpha. If the alpha channel is actually transparency, the default behavior works fine.*

    :param alpha_threshold:         Sets the alpha threshold value for 1-bit alpha such as BC1 or RGBA5551. Defaults to 0.5.
    :param keep_coverage:           Preserves alpha coverage in generate mipmaps for alpha test reference value (0 to 1).
    :param color_key:               Provides a colorkey/chromakey value which is used to replace a specific RGB color in hexadecimal (within a tolerance) with alpha 0.0.
                                    Any existing color channel is overwritten. For example, `0000FF` for a blue colorkey, `00FF00` for a green colorkey, `0CFF5D` for the typical 'green-screen' in a video.
    """
    premultiplied_alpha: bool = False
    alpha: bool = False
    separate_alpha: bool = False
    alpha_threshold: Optional[float] = None
    keep_coverage: Optional[float] = None
    color_key: Optional[str] = None

    def to_args(self) -> List[str]:
        args = []
        if self.premultiplied_alpha:            args.append('--premultiplied-alpha')
        if self.alpha:                          args.append('-alpha')
        if self.separate_alpha:                 args.append('--separate-alpha')
        if self.alpha_threshold is not None:    args.extend(['--alpha-threshold', str(self.alpha_threshold)])
        if self.keep_coverage is not None:      args.extend(['--keep-coverage', str(self.keep_coverage)])
        if self.color_key:                      args.extend(['--color-key', self.color_key])
        return args


@dataclass
class CompressionOptions:
    """
    :param single_proc:             If the DirectXTex library and the texconv utility are built with OpenMP enabled, by default the tool will use multi-threading
                                    for CPU-based compression of BC6H and BC7 formats to spread the compression work across multiple cores.
                                    This flag disables this behavior forcing it to remain on a single core.
    :param gpu:                     When compressing BC6H / BC7 content, texconv will use DirectCompute on the GPU at the given index if available.
    :param nogpu:                   When compressing BC6H / BC7 content, texconv will use DirectCompute on the GPU if available. Use of this flag forces texconv to always use the software codec instead.
    :param block_compress:          Sets options for BC compression. The flags is a combination of one or more :class:`CompressionFlags`.
    :param alpha_weight:            Provides an alpha weighting to use with the error metric for the BC7 GPU compressor.
    """
    single_proc: bool = False
    gpu: Optional[int] = None
    nogpu: bool = False
    block_compress: Tuple[CompressionFlags, ...] = ()
    alpha_weight: Optional[float] = None

    def to_args(self) -> List[str]:
        args = []
        if self.single_proc:                args.append('--single-proc')
        if self.gpu is not None:            args.extend(['-gpu', str(self.gpu)])
        if self.nogpu:                      args.append('-nogpu')
        if self.block_compress:             append_flags('--block-compress', self.block_compress, args)
        if self.alpha_weight is not None:   args.extend(['--alpha-weight', str(self.alpha_weight)])
        return args


@dataclass
class NormalMapOptions:
    """
    :param normal_map:              Use :class:`NormalMapFlags`.
    :param normal_map_amplitude:    Indicates an amplitude for the normal map, which defaults to 1.
    :param invert_y:                Inverts the value of the green channel.
                                    This is typically used for normal maps to deal with OpenGL vs. Direct3D conventions for 'push in' vs. 'push out'.
    :param reconstruct_z:           Rebuilds the Z (blue) channel assuming X/Y are normals (primarily for converting from the BC5 format)
    :param x2_bias:                 Enables special `*2 -1` conversion cases for converting unorm <-> float, and positive-only-floats <-> float/snorm.
                                    These are typically used with normal maps.
    """
    normal_map: Tuple[NormalMapFlags, ...] = ()
    normal_map_amplitude: Optional[float] = None
    invert_y: bool = False
    reconstruct_z: bool = False
    x2_bias: bool = False

    def to_args(self) -> List[str]:
        args = []
        if self.normal_map:                         append_flags('--normal-map', self.normal_map, args)
        if self.normal_map_amplitude is not None:   args.extend(['--normal-map-amplitude', str(self.normal_map_amplitude)])
        if self.invert_y:                           args.append('--invert-y')
        if self.reconstruct_z:                      args.append('--reconstruct-z')
        if self.x2_bias:                            args.append('--x2-bias')
        return args


@dataclass
class ImageOptions:
    """
    :param horizontal_flip:     Perform horizontal flip of image.
    :param vertical_flip:       Perform vertical flip of image.
    :param swizzle:             Swizzles image channels using an HLSL-style mask (`rgba`, `rrra`, `r`, `a`, `xy`, etc.). The mask is 1 to 4 characters in length.
                                A `0` indicates setting that channel to zero, a `1` indicates setting that channel to maximum.
    """
    horizontal_flip: bool = False
    vertical_flip: bool = False
    swizzle: Optional[str] = None

    def to_args(self) -> List[str]:
        args = []
        if self.horizontal_flip:    args.append('--horizontal-flip')
        if self.vertical_flip:      args.append('--vertical-flip')
        if self.swizzle:            args.extend(['--swizzle', self.swizzle])
        return args


@dataclass
class WicOptions:
    """
    :param wic_quality:         Provides an image quality setting to use when encoding WIC images ranging from 0.0 to 1.0. Applies to `jpg`, `tif`, `heif`, and `jxr`.
    :param wic_lossless:        Enable lossless encoding when encoding WIC images. Applies to `jxr`. This ignores any value for `wic_quality`.
    :param wic_uncompressed:    Enable uncompressed encoding for WIC images. Applies to `tif` and `heif`. This ignores any value for `wic_quality`.
    :param wic_multiframe:      When encoding WIC images, the use of this flag will encode multiframe images.
                                By default it writes only the first frame like the `hdr` and `tga` writers.
                                Note that only some WIC containers support multiframe images (notably `gif` and `tif`).
    """
    wic_quality: Optional[float] = None
    wic_lossless: bool = False
    wic_uncompressed: bool = False
    wic_multiframe: bool = False

    def to_args(self) -> List[str]:
        args = []
        if self.wic_quality is not None:    args.extend(['--wic-quality', str(self.wic_quality)])
        if self.wic_lossless:               args.append('--wic-lossless')
        if self.wic_uncompressed:           args.append('--wic-uncompressed')
        if self.wic_multiframe:             args.append('--wic-multiframe')
        return args


@dataclass
class DdsOptions:
    """
    :param typeless:            Use :class:`TypelessFormat`
    :param dword_alignment:     For DDS files that use a DWORD alignment instead of BYTE alignment (used for some legacy files typically 24bpp).
    :param bad_tails:           For older DDS files that incorrectly encode the DXTn block compression mipchain surface blocks smaller than 4x4.
                                This switch causes the loader to tolerate the slightly too short file length and to copy the 4x4 blocks to the smaller ones.
                                The result is not identical to re-computing computing the mipchain fully, but does provide non-corrupted data.
    :param permissive:          Allows some malformed and variant header files to be loaded.
    :param ignore_mips:         Loads only the top-level mipmap, which is useful for some malformed files that are missing data.
    :param fix_bc_4x4:          DDS files can contain BC compressed DDS files of arbitrary size,
                                but Direct3D can only create BC resources where the top-level width & height are multiples of 4.
                                This switch will resize the image to the proper size for loading as a texture, but any mipmaps will have to be regenerated.
    :param expand_luminance:    DDS files with L8, A8L8, or L16 formats are expanded to 8:8:8:8 or 16:16:16:16. Without this flag,
                                they are converted to 1-channel (red) or 2-channel (red/green) formats.
    :param dx10:                Forces DDS file output to always use the "DX10" header extension, and allows the writing of alpha mode metadata information.
                                The resulting file may not be compatible with the legacy D3DX10 or D3DX11 libraries or older DDS readers.
    :param dx9:                 Forces DDS file output to always use legacy DX9 headers. This will fail for `BC6`, `BC7`, `UINT`, and `SINT` formats.
                                `SRGB` formats will be written using non-SRGB formats. It will also fail for texture 2D arrays and cubemap arrays.
                                *This is primarily of use with DX9 era DDS texture loaders*.
    """
    typeless: Optional[TypelessFormat] = None
    dword_alignment: bool = False
    bad_tails: bool = False
    permissive: bool = False
    ignore_mips: bool = False
    fix_bc_4x4: bool = False
    expand_luminance: bool = False
    dx10: bool = False
    dx9: bool = False

    def to_args(self) -> List[str]:
        args = []
        if self.typeless:           args.append(self.typeless.value)
        if self.dword_alignment:    args.append('--dword-alignment')
        if self.bad_tails:          args.append('--bad-tails')
        if self.permissive:         args.append('--permissive')
        if self.ignore_mips:        args.append('--ignore-mips')
        if self.fix_bc_4x4:         args.append('--fix-bc-4x4')
        if self.expand_luminance:   args.append('--expand-luminance')
        if self.dx10:               args.append('-dx10')
        if self.dx9:                args.append('-dx9')
        return args


@dataclass
class TgaOptions:
    """
    :param tga20:           Forces TGA file output to include the TGA 2.0 extension area which includes gamma, alpha mode, and a time stamp.
    :param tga_zero_alpha:  By default a TGA file with an alpha channel of all zeros is treated as 'opaque' which results in all ones for the alpha channel if present.
                            With this switch, all zero alpha channels will be returned in their original form instead.
    """
    tga20: bool = False
    tga_zero_alpha: bool = False

    def to_args(self) -> List[str]:
        args = []
        if self.tga20:             args.append('-tga20')
        if self.tga_zero_alpha:    args.append('--tga-zero-alpha')
        return args


@dataclass
class Direct3DOptions:
    """
    :param feature_level:   Sets the target feature level which determines the maximum supported texture size: `9.1`, `9.2`, `9.3`, `10.0`, `10.1`, `11.0`, `11.1`, `12.0`, `12.1`, or `12.2`.
                            Defaults to `11.0` which is 16834, the limit for 11.x and 12.x.
    """
    feature_level: Optional[FeatureLevel] = None

    def to_args(self) -> List[str]:
        args = []
        if self.feature_level:     args.extend(['--feature-level', self.feature_level.value])
        return args


@dataclass
class MiscellaneousOptions:
    """
    :param nologo: Suppress copyright message.
    :param timing: Displays compression timing information
    """ 
    nologo: bool = False
    timing: bool = False

    def to_args(self) -> List[str]:
        args = []
        if self.nologo:   args.append('-nologo')
        if self.timing:   args.append('--timing')
        return args


Options = Union[
    FileOptions,
    FormatOptions,
    ResizingOptions,
    FilteringOptions,
    ColorspaceOptions,
    AlphaOptions,
    CompressionOptions,
    NormalMapOptions,
    ImageOptions,
    WicOptions,
    DdsOptions,
    TgaOptions,
    Direct3DOptions,
    MiscellaneousOptions
]

SWIZZLE_RE = re.compile(r'[rgba01xyzw]{1,4}')

class Texconv:
    executable: Union[str, Path]
    options: list[str]

    def __init__(self, executable: Union[str, Path], *options: Options) -> None:

        # Check Conflicting Options

        # GPU Check
        if any(isinstance(opt, CompressionOptions) and opt.gpu is not None and opt.nogpu for opt in options):
            raise ValueError("CompressionOptions cannot have both gpu and nogpu set")

        # Normal Map Flags Check
        nmap_opts = next((opt for opt in options if isinstance(opt, NormalMapOptions)), None)
        if nmap_opts and nmap_opts.normal_map:
            required = {NormalMapFlags.R, NormalMapFlags.G, NormalMapFlags.B, NormalMapFlags.A, NormalMapFlags.L}
            if not required.intersection(nmap_opts.normal_map):
                raise ValueError("NormalMapOptions.normal_map must include at least one channel flag (R, G, B, A, or L)")
        
        # Swizzle Check
        swizzle = next((opt.swizzle for opt in options if isinstance(opt, ImageOptions) and opt.swizzle is not None), None)
        if swizzle is not None and not re.fullmatch(SWIZZLE_RE, swizzle):
            raise ValueError(f"Invalid swizzle mask '{swizzle}': must be 1-4 chars of r/x, g/y, b/z, a/w, 0, 1")


        self.executable = executable

        args = []
        for opt in options:
            args.extend(opt.to_args())

        self.options = args


    def run(
        self,
        file: Union[str, Path, Sequence[Union[str, Path]]],
        file_list: bool = False
    ) -> subprocess.CompletedProcess:

        cmd = [str(self.executable), *self.options]

        if file_list:
            if isinstance(file, list):
                raise ValueError("If file_list is True, file should be a single path to the list file, not a list of files")
            cmd.extend(['--file-list', str(file)])
        elif isinstance(file, list):
            cmd.extend(str(f) for f in file)
        else:
            cmd.append(str(file))

        result = subprocess.run(
            cmd,
            shell=False,
            capture_output=True,
            text=True
        )

        return result
