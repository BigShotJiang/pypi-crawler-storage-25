# @service_client 装饰器使用指南

> **最后更新**: 2026-04-02
> **引入版本**: v4.2.0

## 概述

`@service_client` 装饰器用于将**独立服务客户端**自动注册为 pytest fixture。

### 与 @api_class 的区别

| 维度 | @api_class | @service_client |
|------|-----------|----------------|
| **适用场景** | 继承 BaseAPI 的后台 API 客户端 | 独立服务客户端（任意类） |
| **基类要求** | 必须继承 `BaseAPI` | 无要求 |
| **HTTP 客户端** | 共享框架的 `http_client` | 自行管理（httpx/requests 等） |
| **base_url** | 从框架配置统一获取 | 通过 `base_url_config` 按路径注入 |
| **认证方式** | 框架中间件统一处理 | 各客户端自行实现 |
| **默认 scope** | `session` | `session` |

**何时用 @service_client**：
- 调用的服务有独立的 base_url（不同于主测试目标）
- 使用不同的认证方式（如独立的 API Key）
- 不需要继承 BaseAPI 的轻量客户端

---

## 快速开始

### 1. 定义服务客户端

```python
# apis/payment_client.py
from df_test_framework import service_client

@service_client("payment_client", base_url_config="business.payment_url")
class PaymentClient:
    def __init__(self, base_url: str, timeout: int = 30):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    def charge(self, order_no: str, amount: float) -> dict:
        import httpx
        with httpx.Client(timeout=self.timeout) as client:
            resp = client.post(
                f"{self.base_url}/charge",
                json={"orderNo": order_no, "amount": amount},
            )
            return resp.json()
```

### 2. 配置 base_url

```yaml
# config/settings.yaml
business:
  payment_url: "https://pay.example.com/api"
```

### 3. 注册 fixtures

```python
# conftest.py
from df_test_framework.testing.decorators import load_service_fixtures

load_service_fixtures(globals(), services_package="my_project.apis")
```

### 4. 在测试中使用

```python
def test_charge(payment_client):
    result = payment_client.charge("ORD001", 99.9)
    assert result["retCode"] == "0"
```

---

## 装饰器参数

```python
@service_client(
    name="fixture_name",           # fixture 名称（可选，默认从类名生成）
    scope="session",               # fixture scope
    base_url_config="a.b.c",       # settings 中的配置路径
    redis_client="redis_client",   # 额外依赖注入
)
```

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `name` | `str \| None` | `None` | fixture 名称，`None` 则从类名自动生成 |
| `scope` | `str` | `"session"` | pytest fixture scope |
| `base_url_config` | `str \| None` | `None` | settings 配置路径（dot notation） |
| `**dependencies` | `Any` | — | 额外依赖映射 |

### 自动命名规则

类名 CamelCase → snake_case：

| 类名 | 自动生成的 fixture 名称 |
|------|------------------------|
| `PaymentClient` | `payment_client` |
| `ApiServiceClient` | `api_service_client` |
| `SmsNotificationService` | `sms_notification_service` |

---

## 依赖注入

### 自动推断

如果 `__init__` 签名中的参数名匹配已知 fixture，框架会自动注入：

```python
@service_client("my_client", base_url_config="business.my_url")
class MyClient:
    def __init__(self, base_url: str, redis_client=None, database=None):
        self.base_url = base_url
        self.redis = redis_client   # 自动注入 redis_client fixture
        self.db = database          # 自动注入 database fixture
```

**可自动推断的 fixture 名称**：
- `settings` / `runtime`
- `database` / `async_database`
- `redis_client` / `async_redis_client`
- `rabbitmq_client` / `kafka_client` / `rocketmq_client`

### 显式指定

通过关键字参数显式指定依赖映射：

```python
@service_client(
    "my_client",
    base_url_config="business.my_url",
    cache="redis_client",  # 参数名 cache → 注入 redis_client fixture
)
class MyClient:
    def __init__(self, base_url: str, cache=None):
        self.cache = cache  # 实际注入的是 redis_client fixture
```

---

## base_url_config 配置路径

`base_url_config` 使用 dot notation 从 settings 对象中解析配置值：

```yaml
# settings.yaml
business:
  payment_url: "https://pay.example.com/api"
  sms_url: "https://sms.example.com/v1"
  user_center:
    url: "https://uc.example.com"
```

```python
@service_client("payment", base_url_config="business.payment_url")
class PaymentClient: ...

@service_client("sms", base_url_config="business.sms_url")
class SmsClient: ...

@service_client("user_center", base_url_config="business.user_center.url")
class UserCenterClient: ...
```

---

## 注册与加载

### 方式1：自动发现（推荐）

```python
# conftest.py
from df_test_framework.testing.decorators import load_service_fixtures

load_service_fixtures(globals(), services_package="my_project.apis")
```

自动导入 `my_project.apis` 包下所有模块，触发 `@service_client` 装饰器注册。

### 方式2：手动导入

```python
# conftest.py
from my_project.apis.payment_client import PaymentClient  # noqa: F401
from my_project.apis.sms_client import SmsClient  # noqa: F401
from df_test_framework.testing.decorators import load_service_fixtures

load_service_fixtures(globals())
```

### 与 load_api_fixtures 共存

可以同时使用 `load_api_fixtures` 和 `load_service_fixtures`：

```python
# conftest.py
from df_test_framework.testing.decorators import (
    load_api_fixtures,
    load_service_fixtures,
)

# BaseAPI 子类（共享 http_client）
load_api_fixtures(globals(), apis_package="my_project.apis")

# 独立服务客户端（各自管理连接）
load_service_fixtures(globals(), services_package="my_project.apis")
```

---

## 查看注册表

```python
from df_test_framework import get_service_registry

registry = get_service_registry()
for name, (cls, scope, config, deps) in registry.items():
    print(f"{name}: {cls.__name__} (scope={scope}, config={config})")
```

---

## 最佳实践

### 1. 按服务拆分文件

```
apis/
├── __init__.py
├── admin_api.py          # @api_class — 后台 API（继承 BaseAPI）
├── payment_client.py     # @service_client — 支付服务
├── sms_client.py         # @service_client — 短信服务
└── user_center_client.py # @service_client — 用户中心
```

### 2. 使用有意义的 fixture 名称

```python
# ✅ 清晰
@service_client("payment_client", base_url_config="business.payment_url")
class PaymentClient: ...

# ❌ 不清晰
@service_client("client1", base_url_config="business.url1")
class Client1: ...
```

### 3. 配合签名工具使用

```python
from df_test_framework import service_client, compute_sign

@service_client("recharge_client", base_url_config="business.recharge_url")
class RechargeClient:
    def __init__(self, base_url: str):
        self.base_url = base_url.rstrip("/")
        self.api_key = "my_api_key"  # 实际应从配置获取

    def recharge(self, params: dict) -> dict:
        import httpx
        params["sign"] = compute_sign(params, secret=self.api_key)
        with httpx.Client() as client:
            return client.post(f"{self.base_url}/recharge", json=params).json()
```

---

## 相关文档

- [装饰器使用指南](decorators_guide.md) - @api_class、@actions_class
- [工具函数使用指南](helpers_guide.md) - 哈希/加密/签名工具
- [配置系统指南](config_guide.md) - settings YAML 配置
- [v4.2.0 发布说明](../releases/v4.2.0.md) - 完整变更日志

---

**完成时间**: 2026-04-02
