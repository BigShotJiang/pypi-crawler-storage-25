# 工具函数使用指南

> **最后更新**: 2026-04-02
> **引入版本**: v4.2.0

## 概述

`infrastructure/helpers` 模块提供测试中常用的工具函数，包括哈希计算、AES 加解密、API 签名和公网 IP 探测。

**设计原则**：
- 哈希/签名/网络工具基于 stdlib，**零额外依赖**
- AES 加解密需安装 `crypto` 可选依赖组（`pycryptodome`）
- 所有函数均为纯函数，无���态，线程安全

---

## 快速开始

```python
from df_test_framework import md5, sha256, hmac_sha256, compute_sign, get_public_ip

# 哈希
md5("hello")           # '5d41402abc4b2a76b9719d911017c592'
sha256("hello")        # '2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824'
hmac_sha256("hello", secret="my_secret")

# API 签名
params = {"userId": "123", "productCode": "P001"}
sign = compute_sign(params, secret="my_api_key")

# 公网 IP
ip = get_public_ip()   # e.g., "113.57.21.67"
```

---

## 哈希函数

基于 Python stdlib `hashlib`，无额外依赖。

### md5

```python
from df_test_framework import md5

md5("hello")
# '5d41402abc4b2a76b9719d911017c592'
```

返回 32 位小写 hex 字符串。

### sha256

```python
from df_test_framework import sha256

sha256("hello")
# '2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824'
```

返回 64 位小写 hex 字符串。

### hmac_sha256

```python
from df_test_framework import hmac_sha256

hmac_sha256("hello", secret="my_secret")
```

返回 64 位小写 hex HMAC-SHA256 签名。

---

## API 参数签名

`compute_sign()` 支持多种签名模式，适配常见的 API 签名算法。

### 基本用法

```python
from df_test_framework import compute_sign

params = {"euserId": "123", "productCode": "P001", "buyNum": "1"}
sign = compute_sign(params, secret="my_api_key")
# 排序: buyNum, euserId, productCode → "1" + "123" + "P001" + "my_api_key" → MD5
```

### 参数说明

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `params` | `dict[str, str]` | 必填 | 参与签名的参数 |
| `secret` | `str` | 必填 | 签名密钥 |
| `algorithm` | `str` | `"md5"` | 哈希算法：`"md5"` / `"sha256"` / `"hmac-sha256"` |
| `concat_mode` | `str` | `"values_only"` | 拼接模式：`"values_only"` / `"key_value"` |
| `separator` | `str` | `""` | 拼接分隔符 |
| `secret_position` | `str` | `"append"` | 密钥位置：`"append"` / `"prepend"` |

### 拼接模式

**values_only**（默认）：按 key 字母序排列后只拼接 value

```python
params = {"b": "2", "a": "1", "c": "3"}
# 排序后: a=1, b=2, c=3 → 拼接 value: "123" + secret → MD5
compute_sign(params, secret="key")
```

**key_value**：按 key 字母序拼接 `key=value` 对

```python
params = {"b": "2", "a": "1"}
compute_sign(params, secret="key", concat_mode="key_value", separator="&")
# 拼接: "a=1&b=2" + secret → MD5
```

### 不同算法

```python
# MD5（默认）
compute_sign(params, secret="key")

# SHA-256
compute_sign(params, secret="key", algorithm="sha256")

# HMAC-SHA256
compute_sign(params, secret="key", algorithm="hmac-sha256")
```

### 密钥位置

```python
# 末尾追加（默认）: value_string + secret
compute_sign(params, secret="key", secret_position="append")

# 开头前置: secret + value_string
compute_sign(params, secret="key", secret_position="prepend")
```

---

## AES 加解密

需要安装 `crypto` 可选依赖：

```bash
pip install df-test-framework[crypto]
# 或
pip install pycryptodome
```

### 基本用法

```python
from df_test_framework import aes_encrypt, aes_decrypt

# AES-CBC 加密（hex 输出）
ciphertext = aes_encrypt("hello", key="0123456789abcdef", iv="abcdef0123456789")

# AES-CBC 解密
plaintext = aes_decrypt(ciphertext, key="0123456789abcdef", iv="abcdef0123456789")
assert plaintext == "hello"
```

### 参数说明

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `plaintext`/`ciphertext` | `str` | 必填 | 明文/密文 |
| `key` | `str \| bytes` | 必填 | 密钥（16/24/32 字节 → AES-128/192/256） |
| `iv` | `str \| bytes \| None` | `None` | 初始向量（CBC 模式必填，16 字节） |
| `mode` | `str` | `"CBC"` | AES 模式：`"CBC"` / `"ECB"` |
| `encoding` | `str` | `"hex"` | 编码格式：`"hex"` / `"base64"` |

### AES-ECB 模式

```python
# ECB 模式不需要 IV
ciphertext = aes_encrypt("hello", key="0123456789abcdef", mode="ECB")
plaintext = aes_decrypt(ciphertext, key="0123456789abcdef", mode="ECB")
```

### Base64 编码

```python
ciphertext = aes_encrypt(
    "hello",
    key="0123456789abcdef",
    iv="abcdef0123456789",
    encoding="base64",
)
plaintext = aes_decrypt(
    ciphertext,
    key="0123456789abcdef",
    iv="abcdef0123456789",
    encoding="base64",
)
```

### 未安装依赖时的行为

如果未安装 `pycryptodome`，导入 `aes_encrypt`/`aes_decrypt` 时会静默跳过（不报错）。调用时会抛出 `ImportError` 并提示安装方式。

---

## 公网 IP 探测

```python
from df_test_framework import get_public_ip

ip = get_public_ip()
print(ip)  # e.g., "113.57.21.67"
```

### 工作原理

依次尝试以下公共服务，任一成功即返回：
1. `httpbin.org/ip`
2. `api.ipify.org`
3. `ifconfig.me/ip`

### 参数

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `timeout` | `int` | `10` | 每个服务的超时时间（秒） |

### 使用场景

- IP 白名单测试：测试前获取当前出口 IP，确认已加入白名单
- 网络环境验证：确认测试机器的网络出口

### 异常处理

所有服务均不可用时抛出 `RuntimeError`：

```python
try:
    ip = get_public_ip(timeout=5)
except RuntimeError as e:
    print(f"无法获取公网 IP: {e}")
```

---

## 实际场景示例

### 场景1：虚拟充值接口签名

```python
from df_test_framework import compute_sign

def test_recharge(api_service_client):
    params = {
        "euserId": "U001",
        "productCode": "PHONE_50",
        "buyNum": "1",
        "orderNo": "ORD20260402001",
    }
    sign = compute_sign(params, secret="my_api_key")
    params["sign"] = sign

    result = api_service_client.recharge(**params)
    assert result["retCode"] == "0"
```

### 场景2：加密敏感参数

```python
from df_test_framework import aes_encrypt

def test_create_order_with_encrypted_phone(order_api):
    encrypted_phone = aes_encrypt(
        "13800138000",
        key="0123456789abcdef",
        iv="abcdef0123456789",
    )
    response = order_api.create_order(phone=encrypted_phone)
    assert response["success"] is True
```

### 场景3：IP 白名单验证

```python
from df_test_framework import get_public_ip

def test_api_ip_whitelist(api_client):
    ip = get_public_ip()
    print(f"当前出口 IP: {ip}")
    # 确认 IP 在白名单中，否则请求会被拒绝
    response = api_client.get("/protected/data")
    assert response.status_code != 403, f"IP {ip} 不在白名单中"
```

---

## 相关文档

- [装饰器使用指南](decorators_guide.md) - @api_class、@actions_class、@service_client
- [HTTP 客户端指南](http_client_guide.md) - HTTP 客户端和中间件
- [v4.2.0 发布说明](../releases/v4.2.0.md) - 完整变更日志

---

**完成时间**: 2026-04-02
