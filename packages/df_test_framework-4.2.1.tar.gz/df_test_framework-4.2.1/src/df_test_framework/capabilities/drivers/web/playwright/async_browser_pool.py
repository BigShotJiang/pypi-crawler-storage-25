"""异步浏览器实例池

管理多个 AsyncBrowserManager 实例，支持并发 UI 测试。

使用示例:
    pool = AsyncBrowserPool(config=web_config, max_browsers=3)
    await pool.start()

    async with pool.acquire() as manager:
        ctx = await manager.new_context()
        page = await ctx.new_page()
        await page.goto("https://example.com")
        await page.close()
        await ctx.close()

    await pool.shutdown()
"""

from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import Any

from .async_browser import AsyncBrowserManager


class _PooledManager:
    """池内代理，强制每次 acquire() 只能创建一个 context

    防止调用方在单次租借内多次调用 new_context() 绕过 max_contexts_per_browser 限制。
    """

    def __init__(self, manager: AsyncBrowserManager) -> None:
        self._manager = manager
        self._context_created = False

    async def new_context(self, **kwargs: Any) -> Any:
        """创建浏览器上下文（每次 acquire 只允许一个）"""
        if self._context_created:
            raise RuntimeError(
                "每次 acquire() 只能创建一个 context，如需更多请再次调用 pool.acquire()"
            )
        self._context_created = True
        return await self._manager.new_context(**kwargs)

    def __getattr__(self, name: str) -> Any:
        """代理其他属性到原始 manager"""
        return getattr(self._manager, name)


class AsyncBrowserPool:
    """异步浏览器实例池

    管理多个 AsyncBrowserManager 实例，支持并发 UI 测试。
    使用 asyncio.Semaphore 控制并发数，按最少 context 数分配浏览器。
    """

    def __init__(
        self,
        config: Any | None = None,
        runtime: Any | None = None,
        max_browsers: int = 3,
        max_contexts_per_browser: int = 10,
    ):
        """初始化浏览器池

        Args:
            config: WebConfig 配置对象
            runtime: RuntimeContext 实例
            max_browsers: 最大浏览器实例数
            max_contexts_per_browser: 每个浏览器的最大 context 数
        """
        self._config = config
        self._runtime = runtime
        self._max_browsers = max_browsers
        self._max_contexts_per_browser = max_contexts_per_browser
        self._managers: list[AsyncBrowserManager] = []
        self._context_counts: list[int] = []
        self._semaphore: asyncio.Semaphore | None = None
        self._lock = asyncio.Lock()
        self._started = False

    async def start(self) -> None:
        """启动所有浏览器实例

        如果启动过程中某个实例失败，会回滚清理已成功启动的实例。
        """
        if self._started:
            raise RuntimeError("浏览器池已经启动")

        # 总并发 = 浏览器数 × 每浏览器最大 context 数
        self._semaphore = asyncio.Semaphore(self._max_browsers * self._max_contexts_per_browser)
        self._managers = []
        self._context_counts = []

        try:
            for _ in range(self._max_browsers):
                manager = AsyncBrowserManager(config=self._config, runtime=self._runtime)
                await manager.start()
                self._managers.append(manager)
                self._context_counts.append(0)
        except Exception:
            # 回滚：关闭已成功启动的实例
            for started_manager in reversed(self._managers):
                try:
                    await started_manager.stop()
                except Exception:
                    pass
            self._managers.clear()
            self._context_counts.clear()
            self._semaphore = None
            raise

        self._started = True

    @asynccontextmanager
    async def acquire(self) -> AsyncIterator[_PooledManager]:
        """获取一个空闲的浏览器管理器代理（信号量控制并发）

        按最少 context 数的策略分配浏览器实例，
        并确保单个浏览器的 context 数不超过 max_contexts_per_browser。
        返回 _PooledManager 代理，每次 acquire 只允许创建一个 context。

        Yields:
            _PooledManager 代理实例
        """
        if not self._started:
            raise RuntimeError("浏览器池未启动，请先调用 start()")

        assert self._semaphore is not None

        await self._semaphore.acquire()
        try:
            async with self._lock:
                # 选择 context 数最少的浏览器
                min_idx = self._context_counts.index(min(self._context_counts))
                if self._context_counts[min_idx] >= self._max_contexts_per_browser:
                    raise RuntimeError(
                        f"所有浏览器 context 已达上限 ({self._max_contexts_per_browser})"
                    )
                self._context_counts[min_idx] += 1

            try:
                yield _PooledManager(self._managers[min_idx])
            finally:
                async with self._lock:
                    self._context_counts[min_idx] -= 1
        finally:
            self._semaphore.release()

    async def shutdown(self) -> None:
        """关闭所有浏览器实例并释放资源"""
        if not self._started:
            return

        # 逆序关闭
        for manager in reversed(self._managers):
            try:
                await manager.stop()
            except Exception:
                pass

        self._managers.clear()
        self._context_counts.clear()
        self._started = False

    @property
    def stats(self) -> dict[str, Any]:
        """返回池状态统计"""
        active = sum(1 for c in self._context_counts if c > 0)
        return {
            "total": len(self._managers),
            "active": active,
            "idle": len(self._managers) - active,
            "context_counts": list(self._context_counts),
            "started": self._started,
        }


__all__ = ["AsyncBrowserPool"]
