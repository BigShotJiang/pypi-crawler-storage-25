"""异步HTTP客户端封装

v3.8.0 新增:
- AsyncHttpClient: 基于 httpx.AsyncClient 的异步HTTP客户端
- 支持并发请求，性能提升10-50倍
- 完整的拦截器支持（异步适配）
- 上下文管理器（async with）

v3.14.0 重构:
- 集成 MiddlewareChain（洋葱模型）
- 支持 middlewares=[] 构造参数
- 支持 .use(middleware) 链式调用
- 集成 EventBus 发布 HTTP 事件
- 保持向后兼容：interceptors 参数仍可用（已废弃）

v3.16.0 重构:
- 完全移除 InterceptorChain，统一使用 MiddlewareChain
- 支持从 HTTPConfig.middlewares 自动加载
- 移除 config.interceptors 兼容代码

v3.17.0 重构:
- 使用新事件系统（带 correlation_id 的事件关联）
- 使用事件工厂方法创建事件

典型使用场景:
- 并发API测试（同时发送多个请求）
- 压力测试（高QPS场景）
- 批量数据处理

示例:
    基础使用::

        async with AsyncHttpClient("https://api.example.com") as client:
            response = await client.get("/users/1")
            assert response.status == 200

    并发请求::

        async with AsyncHttpClient("https://api.example.com") as client:
            # 并发100个请求
            tasks = [client.get(f"/users/{i}") for i in range(100)]
            responses = await asyncio.gather(*tasks)
            assert len(responses) == 100

    使用中间件 (v3.16.0)::

        async with AsyncHttpClient(
            "https://api.example.com",
            middlewares=[
                RetryMiddleware(max_attempts=3),
                SignatureMiddleware(secret="xxx"),
            ]
        ) as client:
            response = await client.post("/users", json={"name": "Alice"})
"""

from __future__ import annotations

import re
import time
from dataclasses import replace
from typing import TYPE_CHECKING, Any

import httpx
from pydantic import BaseModel

from df_test_framework.capabilities.clients.http.core import (
    Request,
    Response,
)
from df_test_framework.capabilities.clients.http.core.request import FilesTypes
from df_test_framework.capabilities.clients.http.middleware import (
    HttpEventPublisherMiddleware,
    MiddlewareFactory,
    PathFilteredMiddleware,
)
from df_test_framework.core.exceptions import HttpError
from df_test_framework.core.middleware import (
    Middleware,
    MiddlewareChain,
)
from df_test_framework.infrastructure.logging import get_logger

logger = get_logger(__name__)

if TYPE_CHECKING:
    from df_test_framework.bootstrap.runtime import RuntimeContext
    from df_test_framework.infrastructure.config.schema import HTTPConfig


def sanitize_url_async(url: str) -> str:
    """
    异步版本的URL脱敏（实际上是同步的，但保持命名一致）

    将敏感参数值替换为****:
    - token, access_token, refresh_token
    - key, api_key, secret, secret_key
    - password
    - authorization

    Args:
        url: 原始URL

    Returns:
        脱敏后的URL
    """
    sensitive_params = [
        "token",
        "access_token",
        "refresh_token",
        "key",
        "api_key",
        "secret",
        "secret_key",
        "password",
        "passwd",
        "authorization",
        "auth",
    ]

    for param in sensitive_params:
        pattern = rf"([?&]{param}=)[^&]*"
        url = re.sub(pattern, r"\1****", url, flags=re.IGNORECASE)

    return url


class AsyncHttpClient:
    """
    异步HTTP客户端封装

    基于 httpx.AsyncClient，提供:
    - 🆕 v3.16.0: 纯中间件系统（完全移除 InterceptorChain）
    - 🆕 v3.16.0: 支持从 HTTPConfig.middlewares 自动加载
    - 🆕 v3.14.0: 统一中间件系统（洋葱模型）
    - 🆕 v3.14.0: 集成 EventBus 发布 HTTP 事件
    - 异步HTTP请求（get/post/put/delete/patch）
    - 上下文管理器
    - 连接池管理
    - HTTP/2 支持

    性能优势:
    - 并发100个请求: 从30秒降至1秒（30倍提升）
    - 非阻塞IO: CPU利用率更高
    - 连接复用: 减少TCP握手开销

    Note:
        异步客户端必须在异步上下文中使用:
        - 使用 async with 确保资源正确释放
        - 所有方法都是 async def，需要 await 调用
    """

    def __init__(
        self,
        base_url: str | None = None,
        timeout: int | None = None,
        headers: dict[str, str] | None = None,
        verify_ssl: bool | None = None,
        max_retries: int = 3,
        max_connections: int | None = None,
        max_keepalive_connections: int | None = None,
        http2: bool = True,  # 默认启用HTTP/2
        config: HTTPConfig | None = None,
        middlewares: list[Middleware[Request, Response]] | None = None,
        runtime: RuntimeContext | None = None,
    ):
        """
        初始化异步HTTP客户端

        配置优先级: 显式参数 > HTTPConfig > 默认值

        Args:
            base_url: API基础URL (优先使用，其次config.base_url)
            timeout: 请求超时时间(秒) (优先使用，其次config.timeout，默认30)
            headers: 默认请求头
            verify_ssl: 是否验证SSL证书 (优先使用，其次config.verify_ssl，默认True)
            max_retries: 最大重试次数 (默认3)
            max_connections: 最大并发连接数 (优先使用，其次config.max_connections，默认100)
            max_keepalive_connections: Keep-Alive连接数 (优先使用，其次config.max_keepalive_connections，默认20)
            http2: 是否启用HTTP/2，默认True
            config: HTTPConfig配置对象（用于自动加载中间件）
            middlewares: 中间件列表（如果为空，从 config.middlewares 加载）
            runtime: RuntimeContext（包含 event_bus 和 scope）
        """
        # 配置优先级: 显式参数 > HTTPConfig > 默认值
        effective_base_url = (
            base_url or (config.base_url if config else None) or "http://localhost:8000"
        )
        effective_timeout = timeout if timeout is not None else (config.timeout if config else 30)
        effective_verify_ssl = (
            verify_ssl if verify_ssl is not None else (config.verify_ssl if config else True)
        )
        effective_max_connections = (
            max_connections
            if max_connections is not None
            else (config.max_connections if config else 100)
        )
        effective_max_keepalive = (
            max_keepalive_connections
            if max_keepalive_connections is not None
            else (config.max_keepalive_connections if config else 20)
        )

        self.base_url = effective_base_url
        self.timeout = effective_timeout
        self.default_headers = headers or {}
        self.verify_ssl = effective_verify_ssl
        self.http2 = http2
        self.max_retries = max_retries
        self._runtime: RuntimeContext | None = runtime

        # v3.16.0: 纯中间件系统
        self._middleware_chain: MiddlewareChain[Request, Response] | None = None
        self._middlewares: list[Middleware[Request, Response]] = []

        # 配置连接限制
        limits = httpx.Limits(
            max_connections=effective_max_connections,
            max_keepalive_connections=effective_max_keepalive,
        )

        # 创建异步客户端
        self.client = httpx.AsyncClient(
            base_url=effective_base_url,
            timeout=effective_timeout,
            headers=self.default_headers,
            limits=limits,
            verify=effective_verify_ssl,
            http2=http2,
            follow_redirects=True,
        )

        logger.debug(
            f"异步HTTP客户端已初始化: base_url={effective_base_url}, "
            f"timeout={effective_timeout}s, max_retries={max_retries}, "
            f"max_connections={effective_max_connections}, http2={http2}"
        )

        # 加载中间件
        if middlewares:
            for mw in middlewares:
                self.use(mw)
        elif config and config.middlewares:
            self._load_middlewares_from_config(config.middlewares)

        # 自动添加重试中间件（当 max_retries > 0 时）
        # max_retries 表示"重试次数"，RetryMiddleware.max_retries 表示"总尝试次数"
        if max_retries > 0:
            from df_test_framework.capabilities.clients.http.middleware import RetryMiddleware

            self.use(RetryMiddleware(max_retries=max_retries + 1))

        # 自动添加事件发布中间件（priority=999，最后执行 before）
        # 确保能记录到所有中间件修改后的完整 headers 和 params
        self.use(HttpEventPublisherMiddleware(runtime=runtime))

    def set_auth_token(self, token: str, token_type: str = "Bearer") -> None:
        """
        设置认证token

        Args:
            token: 认证令牌
            token_type: 令牌类型（Bearer, Basic等）

        Example::

            client.set_auth_token("abc123", "Bearer")
            # 后续请求会自动添加: Authorization: Bearer abc123
        """
        self.client.headers["Authorization"] = f"{token_type} {token}"
        logger.debug(f"已设置认证token: {token_type} {token[:10]}...")

    def use(self, middleware: Middleware[Request, Response]) -> AsyncHttpClient:
        """添加中间件（链式调用）

        Args:
            middleware: 要添加的中间件

        Returns:
            self，支持链式调用

        Example:
            client.use(RetryMiddleware()).use(LoggingMiddleware())
        """
        # 统一的中间件初始化接口
        # 任何需要 http_client 的中间件都应实现 set_http_client 方法
        if hasattr(middleware, "set_http_client"):
            middleware.set_http_client(self)
            logger.debug(f"已为中间件 {middleware.name} 注入 http_client")

        self._middlewares.append(middleware)
        # 重置链，下次执行时重新构建
        self._middleware_chain = None
        logger.debug(f"添加中间件: {middleware.name} (priority={middleware.priority})")
        return self

    # ==================== v3.14.0: 中间件执行 ====================

    def _build_middleware_chain(self) -> MiddlewareChain[Request, Response]:
        """构建中间件链（懒加载）"""
        if self._middleware_chain is not None:
            return self._middleware_chain

        # 创建最终处理器（发送实际 HTTP 请求）
        async def send_request(request: Request) -> Response:
            return await self._send_request_async(request)

        chain = MiddlewareChain[Request, Response](send_request)
        for mw in self._middlewares:
            chain.use(mw)

        self._middleware_chain = chain
        return chain

    async def _send_request_async(self, request: Request) -> Response:
        """异步发送 HTTP 请求（中间件链的最终处理器，与 HttpClient 同步版镜像）"""
        params: dict[str, Any] = {}
        if request.headers:
            params["headers"] = dict(request.headers)
        if request.params:
            params["params"] = dict(request.params)
        if request.json is not None:
            params["json"] = request.json
        if request.data is not None:
            params["data"] = request.data
        # v3.20.0: 支持 files 参数（multipart/form-data）
        if request.files is not None:
            params["files"] = request.files
        # v3.20.0: 支持 content 参数（raw body）
        if request.content is not None:
            params["content"] = request.content
        # v4.1.2: per-request timeout 覆盖客户端默认值
        if "timeout" in request.metadata:
            params["timeout"] = request.metadata["timeout"]

        try:
            start_time = time.monotonic()
            httpx_response = await self.client.request(request.method, request.url, **params)
            elapsed = time.monotonic() - start_time
            response = self._parse_response(httpx_response)
            return replace(response, elapsed=elapsed)
        except httpx.TimeoutException as e:
            raise HttpError(
                message=f"请求超时: {request.method} {request.url}",
                details={"original_error": type(e).__name__, "url": request.url},
            ) from e
        except httpx.ConnectError as e:
            raise HttpError(
                message=f"连接失败: {request.method} {request.url}",
                details={"original_error": type(e).__name__, "url": request.url},
            ) from e
        except httpx.HTTPError as e:
            raise HttpError(
                message=f"HTTP错误: {request.method} {request.url}",
                details={"original_error": type(e).__name__, "url": request.url},
            ) from e

    # ==================== 核心请求方法 ====================

    async def get(self, url: str, **kwargs) -> Response:
        """
        异步GET请求

        Args:
            url: 请求路径
            **kwargs: httpx支持的参数（params, headers等）

        Returns:
            Response对象

        Example::

            response = await client.get("/users")
            response = await client.get("/users/1")
            response = await client.get("/search", params={"q": "python"})
        """
        return await self.request("GET", url, **kwargs)

    async def post(
        self,
        url: str,
        json: dict[str, Any] | BaseModel | None = None,
        data: Any | None = None,
        files: FilesTypes | None = None,
        content: bytes | str | None = None,
        **kwargs,
    ) -> Response:
        """异步POST请求

        ✅ v3.6: 支持 Pydantic 模型自动序列化
        ✅ v3.20.0: 支持 files 和 content 参数
        ✅ v4.1.2: 与同步版 HttpClient.post() 签名对齐

        Example::

            response = await client.post("/users", json={"name": "Alice"})
            response = await client.post("/upload", files={"file": image_bytes})
        """
        return await self.request(
            "POST", url, json=json, data=data, files=files, content=content, **kwargs
        )

    async def put(
        self,
        url: str,
        json: dict[str, Any] | BaseModel | None = None,
        data: Any | None = None,
        files: FilesTypes | None = None,
        content: bytes | str | None = None,
        **kwargs,
    ) -> Response:
        """异步PUT请求

        ✅ v3.6: 支持 Pydantic 模型自动序列化
        ✅ v3.20.0: 支持 files 和 content 参数

        Example::

            response = await client.put("/users/1", json={"name": "Bob"})
        """
        return await self.request(
            "PUT", url, json=json, data=data, files=files, content=content, **kwargs
        )

    async def delete(self, url: str, **kwargs) -> Response:
        """异步DELETE请求

        Example::

            response = await client.delete("/users/1")
        """
        return await self.request("DELETE", url, **kwargs)

    async def patch(
        self,
        url: str,
        json: dict[str, Any] | BaseModel | None = None,
        data: Any | None = None,
        files: FilesTypes | None = None,
        content: bytes | str | None = None,
        **kwargs,
    ) -> Response:
        """异步PATCH请求

        ✅ v3.6: 支持 Pydantic 模型自动序列化
        ✅ v3.20.0: 支持 files 和 content 参数

        Example::

            response = await client.patch("/users/1", json={"age": 30})
        """
        return await self.request(
            "PATCH", url, json=json, data=data, files=files, content=content, **kwargs
        )

    async def request(self, method: str, url: str, **kwargs) -> Response:
        """
        通用异步请求方法

        事件发布和重试由中间件自动处理（HttpEventPublisherMiddleware、RetryMiddleware）。

        Args:
            method: HTTP方法（GET/POST/PUT/DELETE/PATCH）
            url: 请求路径
            **kwargs: httpx支持的参数

        Returns:
            Response对象

        Raises:
            httpx.HTTPError: HTTP请求错误
            Exception: 其他异常
        """
        request_obj = self._prepare_request_object(method, url, **kwargs)
        chain = self._build_middleware_chain()
        return await chain.execute(request_obj)

    # ==================== 辅助方法 ====================

    def _prepare_request_object(self, method: str, url: str, **kwargs) -> Request:
        """准备Request对象（与 HttpClient 同步版镜像）

        ✅ v3.6: 支持 Pydantic 模型自动序列化
        ✅ v3.19.0: 支持 skip_auth 和 token 参数（通过 metadata 传递）
        ✅ v3.20.0: 支持 files 和 content 参数
        ✅ v4.1.2: 支持 per-request timeout（通过 metadata 传递）

        Args:
            method: 请求方法
            url: 请求URL
            **kwargs: 请求参数
                - json: 可以是 Pydantic 模型或字典
                - skip_auth: v3.19.0 跳过认证中间件
                - token: v3.19.0 使用自定义 Token
                - files: v3.20.0 文件上传（multipart/form-data）
                - content: v3.20.0 原始请求体（binary/text）
                - timeout: v4.1.2 per-request 超时（秒）
        """
        # v3.19.0: 提取 metadata 相关参数
        skip_auth = kwargs.pop("skip_auth", None)
        custom_token = kwargs.pop("token", None)

        # v3.20.0: 提取 files 和 content 参数
        files = kwargs.pop("files", None)
        content = kwargs.pop("content", None)

        # v3.6: 自动处理 Pydantic 模型序列化
        json_param = kwargs.get("json")
        if json_param is not None:
            if isinstance(json_param, BaseModel):
                json_str = json_param.model_dump_json()
                kwargs["data"] = json_str
                headers = kwargs.get("headers", {})
                if "Content-Type" not in headers and "content-type" not in headers:
                    headers["Content-Type"] = "application/json"
                    kwargs["headers"] = headers
                kwargs["json"] = None

        # v3.19.0 + v4.1.2: 构建 metadata
        metadata: dict[str, Any] = {}
        if skip_auth:
            metadata["skip_auth"] = True
        if custom_token:
            metadata["custom_token"] = custom_token
        if "timeout" in kwargs:
            metadata["timeout"] = kwargs.pop("timeout")

        return Request(
            method=method,
            url=url,
            headers=kwargs.get("headers", {}),
            params=kwargs.get("params", {}),
            json=kwargs.get("json"),
            data=kwargs.get("data"),
            files=files,
            content=content,
            context={"base_url": self.base_url},
            metadata=metadata,
        )

    def _parse_response(self, httpx_response: httpx.Response) -> Response:
        """
        解析httpx.Response为框架Response对象
        """
        json_data = None
        try:
            # 只有JSON响应才解析
            content_type = (
                httpx_response.headers.get("content-type")
                or httpx_response.headers.get("Content-Type")
                or ""
            )
            if content_type.startswith("application/json"):
                json_data = httpx_response.json()
        except Exception:
            pass

        return Response(
            status_code=httpx_response.status_code,
            headers=dict(httpx_response.headers),
            body=httpx_response.text,
            json_data=json_data,
        )

    def _load_middlewares_from_config(self, middleware_configs: list[Any]) -> None:
        """从配置自动加载中间件（v3.16.0 新增）

        从 HTTPConfig.middlewares 加载中间件配置并创建实例。

        Args:
            middleware_configs: 中间件配置列表（MiddlewareConfig 对象）
        """
        from df_test_framework.infrastructure.config.middleware_schema import MiddlewareConfig

        logger.debug(f"[AsyncHttpClient] 开始加载中间件: count={len(middleware_configs)}")

        # 按优先级排序
        sorted_configs = sorted(middleware_configs, key=lambda c: c.priority)

        for config in sorted_configs:
            try:
                if not isinstance(config, MiddlewareConfig):
                    logger.warning(f"[AsyncHttpClient] 跳过无效配置: {type(config)}")
                    continue

                # 使用 MiddlewareFactory 创建中间件实例
                middleware = MiddlewareFactory.create(config)
                if not middleware:
                    continue

                # 检查是否需要路径过滤
                has_path_rules = (hasattr(config, "include_paths") and config.include_paths) or (
                    hasattr(config, "exclude_paths") and config.exclude_paths
                )

                if has_path_rules:
                    # 包装为路径过滤中间件
                    middleware = PathFilteredMiddleware(
                        middleware=middleware,
                        include_paths=getattr(config, "include_paths", None),
                        exclude_paths=getattr(config, "exclude_paths", None),
                    )
                    logger.debug(
                        f"[AsyncHttpClient] 中间件已包装路径过滤: "
                        f"include={getattr(config, 'include_paths', [])}, "
                        f"exclude={getattr(config, 'exclude_paths', [])}"
                    )

                # 添加到中间件列表
                self.use(middleware)
                logger.debug(
                    f"[AsyncHttpClient] 已加载中间件: "
                    f"type={config.type}, priority={config.priority}, name={middleware.name}"
                )

            except Exception as e:
                logger.error(f"[AsyncHttpClient] 加载中间件失败: type={config.type}, error={e}")
                raise

        logger.debug(f"[AsyncHttpClient] 中间件加载完成: total={len(self._middlewares)}")

    # ==================== 上下文管理器 ====================

    async def __aenter__(self):
        """
        异步上下文管理器入口

        Example::

            async with AsyncHttpClient("https://api.example.com") as client:
                response = await client.get("/users")
        """
        return self

    # ==================== v4.1.2: 与同步版 HttpClient 对齐的方法 ====================

    async def head(self, url: str, **kwargs) -> Response:
        """异步HEAD请求（v3.20.0 新增，v4.1.2 异步版对齐）

        获取资源元信息，不返回响应体。

        Example::

            response = await client.head("/api/files/123")
            file_size = response.headers.get("Content-Length")
        """
        return await self.request("HEAD", url, **kwargs)

    async def options(self, url: str, **kwargs) -> Response:
        """异步OPTIONS请求（v3.20.0 新增，v4.1.2 异步版对齐）

        获取资源支持的 HTTP 方法。

        Example::

            response = await client.options("/api/users")
            allowed = response.headers.get("Allow")
        """
        return await self.request("OPTIONS", url, **kwargs)

    async def request_raw(self, method: str, url: str, **kwargs) -> httpx.Response:
        """异步发送HTTP请求，返回原始 httpx.Response（v4.1.2 异步版对齐）

        供需要原始 httpx.Response 的场景使用。

        Args:
            method: 请求方法
            url: 请求路径
            **kwargs: 请求参数

        Returns:
            httpx.Response 对象
        """
        response = await self.request(method, url, **kwargs)
        request_obj = self._prepare_request_object(method, url, **kwargs)
        return self._convert_to_httpx_response(response, request_obj)

    def _convert_to_httpx_response(self, response: Response, request: Request) -> httpx.Response:
        """将框架Response转换为httpx.Response（v4.1.2 异步版对齐）"""
        # v4.1.2: 绝对 URL 不拼接 base_url，与 httpx 实际行为一致
        url = (
            request.url
            if request.url.startswith(("http://", "https://"))
            else f"{self.base_url}{request.url}"
        )
        httpx_request = httpx.Request(
            method=request.method,
            url=url,
            headers=request.headers,
        )
        clean_headers = dict(response.headers)
        clean_headers.pop("Content-Encoding", None)
        clean_headers.pop("content-encoding", None)
        return httpx.Response(
            status_code=response.status_code,
            headers=clean_headers,
            content=response.body.encode("utf-8") if response.body else b"",
            request=httpx_request,
        )

    # ==================== 认证状态管理（v4.1.2 异步版对齐） ====================

    def clear_auth_cache(self) -> None:
        """清除认证缓存（v3.19.0 同步版，v4.1.2 异步版对齐）

        遍历所有中间件，清除 BearerTokenMiddleware 的 Token 缓存。

        Example::

            await api.logout()
            client.clear_auth_cache()
        """
        from df_test_framework.capabilities.clients.http.middleware import (
            PathFilteredMiddleware,
        )
        from df_test_framework.capabilities.clients.http.middleware.auth import (
            BearerTokenMiddleware,
        )

        cleared = False
        for mw in self._middlewares:
            if isinstance(mw, BearerTokenMiddleware):
                mw.clear_cache()
                cleared = True
            elif isinstance(mw, PathFilteredMiddleware):
                inner_mw = getattr(mw, "_middleware", None)
                if isinstance(inner_mw, BearerTokenMiddleware):
                    inner_mw.clear_cache()
                    cleared = True

        if cleared:
            logger.info("[AsyncHttpClient] 认证缓存已清除")
        else:
            logger.debug("[AsyncHttpClient] 未找到 BearerTokenMiddleware，无缓存可清除")

    def clear_cookies(self) -> None:
        """清除 httpx 客户端的 Cookies（v3.21.0 同步版，v4.1.2 异步版对齐）

        Example::

            await api.logout()
            client.clear_auth_cache()
            client.clear_cookies()
        """
        if hasattr(self.client, "cookies"):
            self.client.cookies.clear()
            logger.info("[AsyncHttpClient] Cookies 已清除")
        else:
            logger.debug("[AsyncHttpClient] httpx 客户端无 cookies 属性")

    def clear_cookie(self, name: str) -> bool:
        """清除指定的 Cookie（v3.25.0 同步版，v4.1.2 异步版对齐）

        Args:
            name: Cookie 名称

        Returns:
            True 如果成功删除，False 如果不存在
        """
        if hasattr(self.client, "cookies") and name in self.client.cookies:
            del self.client.cookies[name]
            logger.info(f"[AsyncHttpClient] Cookie '{name}' 已删除")
            return True
        logger.debug(f"[AsyncHttpClient] Cookie '{name}' 不存在")
        return False

    def get_cookies(self) -> dict[str, str]:
        """获取当前所有 Cookies（v3.25.0 同步版，v4.1.2 异步版对齐）

        Returns:
            Cookie 字典 {name: value}
        """
        if hasattr(self.client, "cookies"):
            return dict(self.client.cookies)
        return {}

    def reset_auth_state(self) -> None:
        """重置认证状态（v3.25.0 同步版，v4.1.2 异步版对齐）

        组合调用 clear_auth_cache() 和 clear_cookies()。

        Example::

            await api.logout()
            client.reset_auth_state()
        """
        self.clear_auth_cache()
        self.clear_cookies()
        logger.info("[AsyncHttpClient] 认证状态已重置")

    def get_auth_info(self) -> dict[str, Any]:
        """获取当前认证信息（v3.25.0 同步版，v4.1.2 异步版对齐）

        Returns:
            认证信息字典
        """
        from df_test_framework.capabilities.clients.http.middleware import (
            PathFilteredMiddleware,
        )
        from df_test_framework.capabilities.clients.http.middleware.auth import (
            BearerTokenMiddleware,
        )

        info: dict[str, Any] = {
            "has_token_cache": False,
            "token_preview": None,
            "middleware_count": 0,
            "cookies_count": 0,
            "cookies": [],
        }

        for mw in self._middlewares:
            bearer_mw = None
            if isinstance(mw, BearerTokenMiddleware):
                bearer_mw = mw
            elif isinstance(mw, PathFilteredMiddleware):
                inner_mw = getattr(mw, "_middleware", None)
                if isinstance(inner_mw, BearerTokenMiddleware):
                    bearer_mw = inner_mw

            if bearer_mw:
                info["middleware_count"] += 1
                provider = getattr(bearer_mw, "_login_token_provider", None)
                if provider:
                    cached_token = getattr(provider, "_cached_token", None)
                    if cached_token:
                        info["has_token_cache"] = True
                        info["token_preview"] = cached_token[:20] + "..."

        if hasattr(self.client, "cookies"):
            cookies = dict(self.client.cookies)
            info["cookies_count"] = len(cookies)
            info["cookies"] = list(cookies.keys())

        return info

    # ==================== 生命周期管理 ====================

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """异步上下文管理器退出，自动关闭客户端"""
        await self.close()

    async def close(self):
        """关闭客户端，释放连接池资源

        Note:
            使用 async with 时会自动调用，无需手动调用
        """
        await self.client.aclose()
        logger.debug("异步HTTP客户端已关闭")


__all__ = ["AsyncHttpClient"]
