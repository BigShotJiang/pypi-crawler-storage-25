# Architecture du projet


- l'organisation du projet (arborescence, fichiers de configuration doit suivre les meilleures pratiques du développement Python:
    - le PyPA packaging guide
    - les recommandations PEP 518/621

- Si tu as besoin d'installer quelque chose, je suis derrière un proxy nommé vip-users.proxy.edf.fr:3131. Passe cet argument aux outils si c'est nécessaire.
