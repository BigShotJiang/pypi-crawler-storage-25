"""Test suite for Artip static utility methods."""

from datetime import date, datetime

import pytest

from artip import Artip
from artip.exceptions import InvalidGranularityError


class TestToDatetime:
    """Tests for to_datetime."""

    def test_to_datetime_with_date(self):
        value = date(2024, 1, 2)
        result = Artip.to_datetime(value)
        assert result == datetime(2024, 1, 2, 0, 0, 0)

    def test_to_datetime_with_datetime(self):
        value = datetime(2024, 1, 2, 3, 4, 5, 6)
        result = Artip.to_datetime(value)
        assert result is value


class TestCalculateDigits:
    """Tests for calculate_digits."""

    @pytest.mark.parametrize("value, expected", [(100, 3), (1, 1), (999, 3), (0, 1), (-12, 1)])
    def test_calculate_digits(self, value, expected):
        assert Artip.calculate_digits(value) == expected


class TestCountTimeUnits:
    """Tests for count_time_units."""

    def test_seconds(self):
        start = datetime(2024, 1, 1, 0, 0, 0)
        end = datetime(2024, 1, 1, 0, 0, 2)
        assert Artip.count_time_units(start, end, "second") == 3

    def test_minutes(self):
        start = datetime(2024, 1, 1, 0, 0, 0)
        end = datetime(2024, 1, 1, 0, 2, 0)
        assert Artip.count_time_units(start, end, "minute") == 3

    def test_hours(self):
        start = datetime(2024, 1, 1, 0, 0, 0)
        end = datetime(2024, 1, 1, 2, 0, 0)
        assert Artip.count_time_units(start, end, "hour") == 3

    def test_days(self):
        start = datetime(2024, 1, 1, 0, 0, 0)
        end = datetime(2024, 1, 3, 0, 0, 0)
        assert Artip.count_time_units(start, end, "day") == 3

    def test_months(self):
        start = datetime(2024, 1, 1, 0, 0, 0)
        end = datetime(2024, 3, 1, 0, 0, 0)
        assert Artip.count_time_units(start, end, "month") == 3

    def test_years(self):
        start = datetime(2022, 1, 1, 0, 0, 0)
        end = datetime(2024, 1, 1, 0, 0, 0)
        assert Artip.count_time_units(start, end, "year") == 3

    def test_unsupported_granularity_raises(self):
        start = datetime(2024, 1, 1, 0, 0, 0)
        end = datetime(2024, 1, 1, 0, 0, 0)
        with pytest.raises(InvalidGranularityError, match="Unsupported granularity"):
            Artip.count_time_units(start, end, "week")
