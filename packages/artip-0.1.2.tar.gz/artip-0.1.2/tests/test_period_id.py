"""Test suite for PeriodId."""

import pytest

from artip import PeriodId


class TestPeriodId:
    """Tests for PeriodId."""

    def test_period_id_creation(self):
        """Test basic PeriodId creation through the internal factory."""
        pid = PeriodId._create(12345)
        assert pid.value == 12345

    def test_period_id_direct_construction_prohibited(self):
        """Test that direct constructor invocation is forbidden."""
        with pytest.raises(TypeError):
            PeriodId(12345, object())

    def test_period_id_equality(self):
        """Test PeriodId equality comparison."""
        pid1 = PeriodId._create(12345)
        pid2 = PeriodId._create(12345)
        pid3 = PeriodId._create(54321)

        assert pid1 == pid2
        assert pid1 != pid3

    def test_period_id_equality_with_other_type(self):
        """Test equality against a non-PeriodId object."""
        pid = PeriodId._create(12345)
        assert (pid == 12345) is False

    def test_period_id_string_representation(self):
        """Test string conversion of PeriodId."""
        pid = PeriodId._create(99999)
        assert str(pid) == "99999"

    def test_period_id_repr(self):
        """Test repr of PeriodId."""
        pid = PeriodId._create(42)
        assert repr(pid) == "PeriodId(value=42)"

    def test_period_id_hashable(self):
        """Test that PeriodId is hashable and can be used in sets/dicts."""
        pid1 = PeriodId._create(100)
        pid2 = PeriodId._create(100)
        pid3 = PeriodId._create(200)

        # Can use in set
        period_set = {pid1, pid2, pid3}
        assert len(period_set) == 2  # pid1 and pid2 are equal

        # Can use as dict key
        period_dict = {pid1: "first", pid3: "second"}
        assert period_dict[pid2] == "first"

    def test_period_id_frozen(self):
        """Test that PeriodId is immutable."""
        pid = PeriodId._create(42)
        with pytest.raises(AttributeError):
            pid._value = 100

    def test_period_id_disallows_unknown_attributes(self):
        """Test that setting unknown attributes is rejected by slots."""
        pid = PeriodId._create(42)
        with pytest.raises(AttributeError):
            pid.other = "x"
