#!/usr/bin/env powershell
<#
.SYNOPSIS
Run the artip test suite with coverage report generation

.DESCRIPTION
Executes the complete test suite for the artip project with pytest-cov
for code coverage analysis. Generates terminal and HTML coverage reports.

.EXAMPLE
.\runtests.ps1
#>

Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "ARTIP Test Suite Execution" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""

# Resolve Python executable: prefer local venv, fallback to python in PATH.
$venvPython = Join-Path $PSScriptRoot ".venv\Scripts\python.exe"
if (Test-Path $venvPython) {
	& $venvPython "tests/runtests.py"
}
else {
	python "tests/runtests.py"
}

$exitCode = $LASTEXITCODE

Write-Host ""
exit $exitCode
