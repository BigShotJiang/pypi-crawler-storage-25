# Conventions du projet

## Documentation
- Chaque fonction doit avoir :
  - une description claire
  - les paramètres typés
  - un exemple d'utilisation
  - le type de retour

## Tests
- Chaque module doit avoir un fichier tests/test_<module>.py
- Utiliser pytest
- Générer des tests en utilisant des petits DataFrames Polars

## Logs et erreurs
- Lever des ValueError pour les mauvais arguments
- Pas d'impression console (print)
- Les erreurs spécifiques doivent être définies dans `exceptions.py` (ex : `InvalidIntervalError`).
- Ne pas utiliser les exceptions génériques (`Exception`).

## Qualité du code
- Toujours proposer une implémentation optimisée pour Polars
- Préférer LazyFrame aux DataFrames classiques
- Préférer des fonctions pures lorsque possible.
- Limiter les effets de bord.

## Organisation des répertoires
L'organisation des répertoires doit être conforme à la structure recommandée par PyPA (Python Packaging Authority). 

## Gestion de configuration
- GIT doit être utilisé
- uv doit être utilisé. Ne jamais utiliser venv ni y faire référence.

## Versioning
- Utiliser SemVer : MAJOR.MINOR.PATCH.
- Documenter les changements significatifs dans un `CHANGELOG.md`.

## README
Le README doit fournir :
- une description du module,
- les cas d’usage principaux,
- des exemples d’usage reproductibles,
- des instructions d’installation.
