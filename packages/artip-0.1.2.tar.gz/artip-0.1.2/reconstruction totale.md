
# Copilot: Génère entièrement le projet Python selon les directives du dépôt

Tu dois créer automatiquement **tous les fichiers Python, dossiers, tests et fichiers de configuration** définis dans :
- `architecture.md`
- `specification.md`
- `copilot-instructions.md`
- `project-guidelines.md`

**ultra important** : Ces instructions ne doivent être exécutées que SI ET SEULEMENT SI TU RECOIS UN ORDRE DIRECT DE LE FAIRE. Par exemple "Exécute les instructions contenues dans le fichier reconstruction totale.md". Dans tout autre cas de figure cela aboutirait à la destruction INVOLONTAIRE complète du projet, ce qu'il ne faut JAMAIS faire.


## Travail demandé à Copilot

### 1. Générer l'arborescence complète du projet :
- respecter exactement la structure décrite dans `architecture.md`
- créer tous les fichiers et sous-dossiers
- inclure `__init__.py` partout où nécessaire

### 2. Générer *tout le code Python* conformément à `specification.md` :
- validations strictes
- exceptions dans `exceptions.py`
- helpers dans `utils.py`
- fonctions module-level
- docstrings complètes
- typing intégral
- couverture complète des cas limites

### 3. Générer les tests Pytest
Créer tous les tests unitaires nécessaires pour les objets dont l'API est publique

### 4. Générer les fichiers de packaging
Créer :
- `pyproject.toml` (format PEP621)
- configuration minimale pour construire le package
- informations de version

### 5. Générer la documentation minimale
Créer :
- un `README.md` avec exemples d’usage
- un `CHANGELOG.md` initial
- compléter `__init__.py` avec exposition de l’API

### 6. Respect strict des règles de style
Selon `copilot-instructions.md` 

## Comportement attendu
Générer tous les éléments du projet de manière autonome, cohérente, complète et immédiatement fonctionnelle.

FIN.