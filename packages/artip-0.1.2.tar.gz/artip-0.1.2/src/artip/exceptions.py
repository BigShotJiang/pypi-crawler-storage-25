"""Exceptions for the artip module."""


class ArtipError(Exception):
    """Base exception for artip module."""

    pass


class InvalidIntervalError(ArtipError):
    """Raised when an interval is invalid or outside bounds."""

    pass


class PeriodTooLargeError(ArtipError):
    """Raised when a period exceeds period_max_size."""

    pass


class InvalidGranularityError(ArtipError):
    """Raised when granularity is not supported."""

    pass
