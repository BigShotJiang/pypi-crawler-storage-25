"""Artip package namespace."""
