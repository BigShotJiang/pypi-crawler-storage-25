# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2024-03-26

### Added

- Initial release of Artip
- `Artip` class for managing temporal period identifiers
- `PeriodId` dataclass for representing period encodings
- Support for multiple granularities: year, month, day, hour, minute, second
- `make_period_id()` method to generate unique period identifiers
- `get_period_range()` method to retrieve period boundaries
- `make_calendar_table()` method to generate Power BI calendar tables
- Comprehensive exception hierarchy: `InvalidIntervalError`, `PeriodTooLargeError`, `InvalidGranularityError`
- Full type hints for all public APIs
- Complete test suite with 95%+ coverage
- Documentation and examples

### Features

- Scalar 64-bit integer encoding for Power BI Vertipaq optimization
- Thread-safe with no global state
- Constraint validation with meaningful error messages
- Calendar generation with "starts", "ends", and "in" labels
- Support for both `date` and `datetime` objects

[0.1.0]: https://github.com/HerveBessone-EDF/artip/releases/tag/v0.1.0
