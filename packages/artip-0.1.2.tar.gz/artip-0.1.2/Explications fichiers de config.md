

# fichier copilot-instructions.md

Fichier principal lu en priorité maximale par GitHub Copilot. Ce sont des directives opérationnelles qui disent comment Copilot doit coder
Ce fichier doit contenir des éléments qui influencent directement la façon dont Copilot écrit le code :
✅ style de code (typing, docstrings, PEP8)
✅ conventions à utiliser (pattern objet vs fonctionnel)
✅ comment réagir à certains cas (lever des exceptions, structure modulaire…)
✅ interdictions (pas de pandas, pas de side effects…)
✅ comportement attendu (proposer automatiquement des fichiers, compléter des classes…)

# fichier specifications.md

Ce fichier est directement utilisable avec GitHub Copilot, lu après copilot-instructions.md et décrit les règles auquelles Copilot ne doit pas déroger. Il est recommander de préciser dans les instructions que les spécifications sont ici.

Contenu recommandé :

✅ noms des classes
✅ signatures exactes des fonctions
✅ règles métier (bornes inclusives/exclusives)
✅ types attendus
✅ cas limites obligatoires
✅ erreurs à lever
✅ exemples d’usage

Copilot suit beaucoup mieux des instructions quand elles sont écrites ainsi.

# fichier architecture.md

Décrit la structure interne du projet pour aider Copilot à générer du code cohérent et modulaire.  Il dit “où” les choses se trouvent, pas “ce qu'elles doivent faire”. Il sert à définir:
✅ la structure des répertoires
✅ les modules du projet
✅ les responsabilités de chaque fichier
✅ comment les composants interagissent
✅ les relations : objets, modules, utilitaires
✅ le découpage logique du code
✅ les patterns architecturaux

# fichier project-guidelines.md

Conventions globales et bonnes pratiques pour guider Copilot sur tout le repo.
Ce fichier sert plus à :
✅ documenter les standards “humains” du projet
✅ donner les règles à suivre pour toi et d’autres développeurs
✅ structurer la manière de travailler
✅ donner des bonnes pratiques globales
Ce fichier est lu par Copilot, mais avec moins de poids.
Il sert plutôt de documentation projet que d’instruction opérationnelle.
👉 Copilot peut s’en inspirer, mais ne l’interprétera pas comme un ordre strict.

J'ajoute un exemple de prompt maitre généré par Copilot. Il sert à partir de zéro.
Je suppose que je relancerai tout d'un coup lorsque je serai sûr de ma spécification, complète et efficace      

# Copilot: Génère entièrement le projet Python selon les directives du dépôt

Tu dois créer automatiquement **tous les fichiers Python, dossiers, tests et fichiers de configuration** définis dans :
- `architecture.md`
- `specification.md`
- `copilot-instructions.md`
- `project-guidelines.md`

## Objectif
Générer un module Python complet nommé `artip`

## Travail demandé à Copilot

### 1. Générer l'arborescence complète du projet :
- respecter exactement la structure décrite dans `architecture.md`
- créer tous les fichiers et sous-dossiers
- inclure `__init__.py` partout où nécessaire

### 2. Générer *tout le code Python* conformément à `specification.md` :
- classe `artip` entièrement implémentée
- validations strictes
- exceptions dans `exceptions.py`
- helpers dans `utils.py`
- fonctions module-level
- docstrings complètes
- typing intégral
- couverture complète des cas limites

### 3. Générer les tests Pytest
Créer tous les tests unitaires nécessaires :
- tests de la classe `artip`

### 4. Générer les fichiers de packaging
Créer :
- `pyproject.toml` (format PEP621)
- configuration minimale pour construire le package
- informations de version

### 5. Générer la documentation minimale
Créer :
- un `README.md` avec exemples d’usage
- un `CHANGELOG.md` initial
- compléter `__init__.py` avec exposition de l’API

### 6. Respect strict des règles de style
Selon `copilot-instructions.md` 

## Comportement attendu
Générer tous les éléments du projet de manière autonome, cohérente, complète et immédiatement fonctionnelle.

FIN.