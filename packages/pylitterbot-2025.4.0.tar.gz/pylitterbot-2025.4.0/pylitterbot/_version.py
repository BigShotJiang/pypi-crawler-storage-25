"""pylitterbot version."""

__version__ = "2025.4.0"
