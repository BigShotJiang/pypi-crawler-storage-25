"""Search broker router."""

import os
from typing import Optional

from argus.broker.budgets import BudgetTracker
from argus.broker.execution import ProviderExecutor, ProviderRoutingPolicy
from argus.broker.health import HealthTracker
from argus.broker.pipeline import SearchResultPipeline
from argus.broker.policies import resolve_routing
from argus.broker.session_flow import SessionSearchService
from argus.config import get_config
from argus.core.cache import TTLCache, search_cache_key
from argus.logging import get_logger
from argus.models import ProviderName, ProviderStatus, SearchQuery, SearchResponse
from argus.persistence.db import SearchPersistenceGateway
from argus.providers.base import BaseProvider

logger = get_logger("broker.router")


class SearchBroker:
    def __init__(
        self,
        providers: dict[ProviderName, BaseProvider],
        cache: Optional[TTLCache] = None,
        health_tracker: Optional[HealthTracker] = None,
        budget_tracker: Optional[BudgetTracker] = None,
        session_store=None,
        executor: Optional[ProviderExecutor] = None,
        result_pipeline: Optional[SearchResultPipeline] = None,
        session_service: Optional[SessionSearchService] = None,
    ):
        self._providers = providers
        self._cache = cache or TTLCache(
            ttl_seconds=168 * 3600,
            key_fn=search_cache_key,
        )
        self._health = health_tracker or HealthTracker()
        self._budgets = budget_tracker or BudgetTracker(
            persist_path=get_config().db_path
        )
        self._config = get_config()
        self._session_store = session_store
        self._executor = executor or ProviderExecutor(
            providers=self._providers,
            health_tracker=self._health,
            budget_tracker=self._budgets,
            routing_policy=ProviderRoutingPolicy(),
        )
        self._pipeline = result_pipeline or SearchResultPipeline(
            cache=self._cache,
            persistence=SearchPersistenceGateway(),
        )
        self._session_service = session_service or SessionSearchService(session_store=session_store)

        budget_map = {
            ProviderName.BRAVE: self._config.brave.monthly_budget_usd,
            ProviderName.SERPER: self._config.serper.monthly_budget_usd,
            ProviderName.TAVILY: self._config.tavily.monthly_budget_usd,
            ProviderName.EXA: self._config.exa.monthly_budget_usd,
        }
        for pname, budget in budget_map.items():
            if budget > 0:
                self._budgets.set_budget(pname, budget)

        # Restore persisted manual provider overrides
        if self._budgets._store:
            try:
                overrides = self._budgets._store.get_provider_overrides()
                for provider_str, info in overrides.items():
                    try:
                        pname = ProviderName(provider_str)
                        self._health.force_disable(pname, info.get("reason", ""))
                        logger.info("Restored manual disable for provider: %s", provider_str)
                    except ValueError:
                        pass
            except Exception as exc:
                logger.warning("Failed to load provider overrides: %s", exc)

    @property
    def cache(self) -> TTLCache:
        return self._cache

    @property
    def health_tracker(self) -> HealthTracker:
        return self._health

    @property
    def budget_tracker(self) -> BudgetTracker:
        return self._budgets

    async def search(self, query: SearchQuery) -> SearchResponse:
        cache_run_id = os.urandom(8).hex()
        cached = self._pipeline.get_cached(query, cache_run_id)
        if cached is not None:
            logger.debug("Cache hit for query: %s (mode=%s)", query.query, query.mode)
            return cached

        provider_order = resolve_routing(query.mode, query.providers)
        outcome = await self._executor.execute(query, provider_order)
        response = self._pipeline.build_response(
            query,
            outcome.provider_results,
            outcome.traces,
        )

        logger.info(
            "Search complete: query=%r mode=%s providers=%d results=%d run=%s",
            query.query,
            query.mode.value,
            outcome.live_providers_used,
            len(response.results),
            response.search_run_id,
        )

        return response

    async def search_with_session(
        self, query: SearchQuery, session_id: Optional[str] = None
    ) -> tuple[SearchResponse, Optional[str]]:
        return await self._session_service.search_with_session(
            query,
            self.search,
            session_id=session_id,
        )

    def get_provider_status(self, provider: ProviderName) -> dict:
        """Get combined status for a provider (config + health + budget)."""
        from datetime import timezone

        provider_obj = self._providers.get(provider)
        base_status = provider_obj.status() if provider_obj else "unknown"

        health_status = self._health.get_status(provider)
        budget_status = self._budgets.check_status(provider)

        effective = base_status
        if health_status:
            effective = health_status.value
        if budget_status:
            effective = budget_status.value

        # Derived diagnostic fields
        missing_key = base_status == ProviderStatus.UNAVAILABLE_MISSING_KEY
        budget_exhausted = budget_status == ProviderStatus.BUDGET_EXHAUSTED

        health_obj = self._health.get_health(provider)
        cooldown_until = None
        if health_obj.is_in_cooldown() and health_obj.disabled_until is not None:
            from datetime import datetime
            cooldown_until = datetime.fromtimestamp(
                health_obj.disabled_until, tz=timezone.utc
            ).isoformat()

        if effective == ProviderStatus.DISABLED_BY_CONFIG:
            reason = "disabled in config"
        elif effective == ProviderStatus.UNAVAILABLE_MISSING_KEY:
            reason = "missing API key"
        elif effective == ProviderStatus.BUDGET_EXHAUSTED:
            reason = "monthly budget exhausted"
        elif effective == ProviderStatus.MANUALLY_DISABLED:
            reason = f"manually disabled" + (
                f": {health_obj.force_disabled_reason}" if health_obj.force_disabled_reason else ""
            )
        elif effective == ProviderStatus.TEMPORARILY_DISABLED:
            reason = (
                f"{health_obj.consecutive_failures} consecutive failures"
                + (f" — in cooldown until {cooldown_until}" if cooldown_until else "")
            )
        elif effective == ProviderStatus.DEGRADED:
            reason = f"degraded — {health_obj.consecutive_failures} consecutive failures"
        else:
            reason = "healthy"

        return {
            "provider": provider.value,
            "config_status": base_status,
            "health": health_obj.__dict__ if provider in self._health._health else None,
            "budget_remaining": self._budgets.get_remaining_budget(provider),
            "effective_status": effective,
            "missing_key": missing_key,
            "budget_exhausted": budget_exhausted,
            "cooldown_until": cooldown_until,
            "reason": reason,
        }


def create_broker() -> SearchBroker:
    """Factory: create a SearchBroker with all configured providers."""
    from argus.providers.brave import BraveProvider
    from argus.providers.exa import ExaProvider
    from argus.providers.searxng import SearXNGProvider
    from argus.providers.serper import SerperProvider
    from argus.providers.tavily import TavilyProvider

    config = get_config()

    providers: dict[ProviderName, BaseProvider] = {
        ProviderName.SEARXNG: SearXNGProvider(config.searxng),
        ProviderName.BRAVE: BraveProvider(config.brave),
        ProviderName.SERPER: SerperProvider(config.serper),
        ProviderName.TAVILY: TavilyProvider(config.tavily),
        ProviderName.EXA: ExaProvider(config.exa),
    }

    from argus.sessions import SessionStore

    session_store = SessionStore()
    return SearchBroker(providers=providers, session_store=session_store)
