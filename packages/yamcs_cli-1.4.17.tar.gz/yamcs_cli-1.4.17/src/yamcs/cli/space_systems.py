import json
from typing import Any, Iterable, List

from google.protobuf.json_format import MessageToJson
from yamcs.client import SpaceSystem, YamcsClient

from yamcs.cli import utils
from yamcs.cli.completers import SpaceSystemCompleter


class SpaceSystemsCommand(utils.Command):
    def __init__(self, parent):
        super(SpaceSystemsCommand, self).__init__(
            parent, "space-systems", "Read space systems"
        )

        subparsers = self.parser.add_subparsers(title="Commands", metavar="COMMAND")
        subparsers.required = True

        subparser = self.create_subparser(subparsers, "list", "List space systems")
        subparser.add_argument(
            "--format",
            dest="format",
            type=str,
            help="Format for printing",
            choices=["table", "json"],
            default="table",
        )
        subparser.set_defaults(func=self.list_)

        subparser = self.create_subparser(
            subparsers, "describe", "Describe a space system"
        )
        subparser.add_argument(
            "space_system", metavar="NAME", type=str, help="name of the space system"
        ).completer = SpaceSystemCompleter
        subparser.set_defaults(func=self.describe)

        subparser = self.create_subparser(
            subparsers, "export", "Export a space system in XTCE format"
        )

        subparser.add_argument(
            "space_system", metavar="NAME", type=str, help="name of the space system"
        ).completer = SpaceSystemCompleter
        subparser.add_argument(
            "--xtce-version",
            type=str,
            help="XTCE version",
            choices=["1.2", "1.3"],
            default="1.2",
        )
        subparser.set_defaults(func=self.export)

    def list_(self, args):
        opts = utils.CommandOptions(args)
        client = YamcsClient(**opts.client_kwargs)
        mdb = client.get_mdb(opts.require_instance())
        iterator = mdb.list_space_systems()
        if args.format == "json":
            self.list_json(iterator)
        else:
            self.list_table(iterator)

    def list_json(self, iterator: Iterable[SpaceSystem]):
        msg_array = [MessageToJson(x._proto, indent=2) for x in iterator]
        json_array = json.loads("[" + ",".join(msg_array) + "]")
        print(json.dumps(json_array, indent=2))

    def list_table(self, iterator: Iterable[SpaceSystem]):
        rows: List[List[Any]] = [["NAME", "DESCRIPTION"]]
        for space_system in iterator:
            rows.append(
                [
                    space_system.qualified_name,
                    space_system.description,
                ]
            )
        utils.print_table(rows)

    def describe(self, args):
        opts = utils.CommandOptions(args)
        client = YamcsClient(**opts.client_kwargs)
        mdb = client.get_mdb(opts.require_instance())
        space_system = mdb.get_space_system(args.space_system)
        print(space_system._proto)

    def export(self, args):
        opts = utils.CommandOptions(args)
        client = YamcsClient(**opts.client_kwargs)
        mdb = client.get_mdb(opts.require_instance())
        xtce = mdb.export_space_system(args.space_system, version=args.xtce_version)
        print(xtce)
