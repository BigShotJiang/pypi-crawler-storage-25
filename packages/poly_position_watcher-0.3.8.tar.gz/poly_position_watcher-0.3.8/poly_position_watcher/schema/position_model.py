# -*- coding = utf-8 -*-
# @Time: 2025/12/1 16:15
# @Author: pinbar
# @Site:
# @File: model.py
# @Software: PyCharm
from datetime import datetime
from typing import List, Optional, Literal

from pydantic import BaseModel, Field, field_validator, model_validator

from poly_position_watcher.common.enums import Side, TradeStatus
from poly_position_watcher.schema.base import PrettyPrintBaseModel


class MakerOrder(BaseModel):
    asset_id: str
    matched_amount: float
    size: float = 0
    order_id: str
    outcome: str
    owner: str
    price: float
    fee_rate_bps: float | str | None = None
    outcome_index: int | None = None
    maker_address: str
    side: Side

    @field_validator( "price", "matched_amount", "size", mode="before")
    @classmethod
    def validate_float(cls, v: str):
        return float(v)

    @model_validator(mode="after")
    def validate_size(self):
        self.size = self.matched_amount
        return self


class TradeMessage(BaseModel):
    type: Literal["TRADE"] = "Trade"
    event_type: Literal["trade"] = "trade"

    asset_id: str
    id: str
    maker_orders: List[MakerOrder]
    transaction_hash: str
    market: str
    maker_address: str
    outcome: str
    owner: str
    price: float
    side: Side
    size: float
    status: TradeStatus | str
    taker_order_id: str
    timestamp: int | None = None
    match_time: int | None = None
    last_update: int | None = None
    trade_owner: Optional[str] = None
    trader_side: Optional[Literal["MAKER", "TAKER"]] = None
    fee_rate_bps: float | str | None = None
    outcome_index: int | None = None
    created_at: datetime | None = None
    market_slug: Optional[str] = ""

    @property
    def event_time(self) -> int:
        return self.match_time or self.last_update or self.timestamp or 0

    @model_validator(mode="after")
    def validate_datetime(self):
        base_ts = self.event_time
        if self.match_time is None:
            self.match_time = base_ts or None
        if self.last_update is None:
            self.last_update = base_ts or None
        if self.timestamp is None:
            self.timestamp = base_ts or None
        if base_ts > 0:
            self.created_at = datetime.fromtimestamp(base_ts)
        return self

    @field_validator("timestamp", "last_update", "match_time", mode="before")
    @classmethod
    def validate_int(cls, v: str):
        if v in (None, ""):
            return None
        return int(v)

    @field_validator( "price", "size", mode="before")
    @classmethod
    def validate_float(cls, v: str):
        return float(v)


class OrderMessage(PrettyPrintBaseModel):
    type: Optional[str] = None  # Literal["PLACEMENT", "UPDATE", "CANCELLATION"]
    event_type: Optional[str] = None  # Literal["order"]

    asset_id: Optional[str] = None
    associate_trades: Optional[List[str]] = None
    id: Optional[str]
    market: Optional[str] = None
    order_owner: Optional[str] = None
    original_size: float | None = None
    outcome: Optional[str] = None
    owner: Optional[str] = None
    price: float
    side: Literal["BUY", "SELL"]
    size_matched: float
    timestamp: float
    filled: bool = False
    status: Optional[str] = None
    created_at: datetime | None = None
    market_slug: Optional[str] = ""

    @field_validator(
        "size_matched", "price", "original_size", "timestamp", mode="before"
    )
    @classmethod
    def validate_float(cls, v: str):
        return float(v)

    @model_validator(mode="after")
    def validate_datetime(self):
        base_ts = self.timestamp
        if base_ts:
            self.created_at = datetime.fromtimestamp(base_ts / 1000)
        return self


class UserPosition(PrettyPrintBaseModel):
    price: float
    size: float
    original_size: float = 0.0
    volume: float
    fee_amount: float = 0.0
    sellable_size: float = 0.0
    token_id: Optional[str] = None
    last_update: float
    market_id: Optional[str] = None
    outcome: Optional[str] = None
    created_at: datetime | None = None
    market_slug: Optional[str] = ""
    has_failed: bool = False
    failed_trades: list[TradeMessage] = Field(default_factory=list)

    @property
    def failed_size(self) -> float:
        return sum(i.size for i in self.failed_trades)

    @property
    def failed_trade_ids(self) -> list[str]:
        return [trade.id for trade in self.failed_trades]

    def __str__(self):
        lines = []
        for name, value in self.__dict__.items():
            if name == "failed_trades":
                value = self.failed_trade_ids
            lines.append(f"{name}: {value!r}")
        return f"{self.__class__.__name__}(\n  " + ",\n  ".join(lines) + "\n)"

    __repr__ = __str__


class WaitOrderFillItem(PrettyPrintBaseModel):
    order_id: str
    token_id: str | None = None
    filled: bool = False
    filled_size: float = 0.0
    target_size: float | None = None
    order_status: str | None = None
    order: OrderMessage | None = None
    position: UserPosition | None = None


class WaitOrdersFillResult(PrettyPrintBaseModel):
    any_filled: bool
    all_filled: bool
    timed_out: bool
    filled_size: float = 0.0
    live_order_ids: list[str] = Field(default_factory=list)
    filled_order_ids: list[str] = Field(default_factory=list)
    live_token_ids: list[str] = Field(default_factory=list)
    filled_token_ids: list[str] = Field(default_factory=list)
    filled_list: list[WaitOrderFillItem] = Field(default_factory=list)
    live_list: list[WaitOrderFillItem] = Field(default_factory=list)
    all_list: list[WaitOrderFillItem] = Field(default_factory=list)
    filled_map: dict[str, WaitOrderFillItem] = Field(default_factory=dict)
    live_map: dict[str, WaitOrderFillItem] = Field(default_factory=dict)
    all_map: dict[str, WaitOrderFillItem] = Field(default_factory=dict)

    def get(self, order_id: str) -> WaitOrderFillItem | None:
        return self.all_map.get(order_id)

    def is_filled(self, order_id: str) -> bool:
        item = self.all_map.get(order_id)
        return bool(item and item.filled)


class PositionDetails(BaseModel):
    """仓位详细信息"""

    buy_events: int
    sell_events: int
    total_trades: int


class PositionResult(PrettyPrintBaseModel):
    """仓位计算结果"""

    size: float
    original_size: float = 0.0
    avg_price: float
    realized_pnl: float
    amount: float
    fee_amount: float = 0.0
    position_value: Optional[float] = None
    unrealized_pnl: Optional[float] = None
    total_pnl: Optional[float] = None
    profit_rate: Optional[float] = None
    is_long: bool
    is_short: bool
    details: PositionDetails
    last_update: float
