# Graph schemas
