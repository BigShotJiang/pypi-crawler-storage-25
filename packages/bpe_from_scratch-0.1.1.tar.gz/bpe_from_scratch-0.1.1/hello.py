def main():
    print("Hello from bpe-from-scratch!")


if __name__ == "__main__":
    main()
