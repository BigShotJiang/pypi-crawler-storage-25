# BPE Implementation Progress

Tracking progress against [minbpe](https://github.com/karpathy/minbpe) (Karpathy's reference implementation).

## Completed ✅

| # | Method | Description | minbpe equivalent |
|---|--------|-------------|-------------------|
| 1 | `encode_to_bytes(text)` | UTF-8 encode input string | `text.encode("utf-8")` |
| 2 | `bytes_to_tokens(byte_data)` | Convert bytes → list of int [0–255] | `list(text_bytes)` |
| 3 | `pair_counting(tokens)` | Count adjacent pairs | `get_stats(ids)` |
| 4 | `most_frequent_pair(counts)` | Greedy max-frequency pair selection | `max(stats, key=stats.get)` |
| 5 | `merge(tokens, pair, new_id)` | Replace all occurrences of pair with new_id | `merge(ids, pair, idx)` |
| 6 | `train_step(tokens)` | Single BPE iteration (count → select → merge → update state) | One iteration inside `train()` |

## TODO 🔴

### 1. `train(text, vocab_size, verbose=False)`
- Full training loop: runs `vocab_size - 256` merge iterations
- Calls `encode_to_bytes` → `bytes_to_tokens` → loops `train_step`
- Should accept raw text, not pre-tokenized input
- `verbose` flag prints each merge step (like minbpe)

### 2. `encode(text)`
- **Inference-time** tokenization (apply learned merges to new text)
- ⚠️ Key difference from training: uses `min(stats, key=lambda p: self.merges.get(p, float("inf")))` — applies merges in the **order they were learned**, NOT by frequency
- Terminates when no more known merge pairs exist in the sequence

### 3. `decode(ids)`
- Convert token IDs back to a string
- `b"".join(self.vocab[idx] for idx in ids).decode("utf-8", errors="replace")`

### 4. `save(file_prefix)` / `load(model_file)`
- Serialize and restore `merges`, `vocab`, and pattern
- minbpe writes two files: `.model` (for loading) and `.vocab` (human-readable)

## Key Design Notes

- **Tie-breaking**: `max(stats, key=stats.get)` matches minbpe exactly — no changes needed
- **`encode` vs `train`**: Training picks the **most frequent** pair. Encoding picks the pair with the **lowest merge index**. This is the most important distinction to get right.
- **`_build_vocab`**: minbpe rebuilds vocab from merges on load. Consider adding this if you implement save/load.
