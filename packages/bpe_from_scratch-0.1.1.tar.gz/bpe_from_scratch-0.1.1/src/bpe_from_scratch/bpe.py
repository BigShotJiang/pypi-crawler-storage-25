from __future__ import annotations

import unicodedata

from typing import Tuple, List
from collections import Counter
import json
from tqdm import tqdm
import regex

# GPT-2 / r50k pre-tokenization pattern (from tiktoken openai_public.py)
# Better suited for small vocabularies (e.g. 1024) than cl100k_base because:
#   - Numbers stay as contiguous runs (` ?\p{N}++`) instead of being split every 3 digits
#   - Simpler whitespace handling wastes fewer merge slots
GPT2_SPLIT_PATTERN = r"""'(?:[sdmt]|ll|ve|re)| ?\p{L}++| ?\p{N}++| ?[^\s\p{L}\p{N}]++|\s++$|\s+(?!\S)|\s"""

class ByteLevelBPE:
    def __init__(self):
        # Base vocabulary: one token per possible byte value (0–255)
        self.vocab: dict[int, bytes] = {i: bytes([i]) for i in range(256)}
        # Learned merge rules: (pair) → new token ID, insertion-ordered
        self.merges: dict[Tuple[int, int], int] = {}
        # Reverse lookup: pair → rank (position in merge order), built once
        self._merge_rank: dict[Tuple[int, int], int] = {}
        self._pat = regex.compile(GPT2_SPLIT_PATTERN)

    def encode_to_bytes(self, text: str, *, normalize: bool = False) -> bytes:
        """
        Encode a Unicode string to its UTF-8 byte sequence.

        Args:
            text:      Raw input string (any Unicode).
            normalize: Apply NFC normalization before encoding (recommended).
            NFC ensures canonical equivalence — e.g. "é" as a single
            codepoint vs. "e" + combining accent → same bytes.

        Returns:
            UTF-8 encoded bytes.

        Raises:
            TypeError:  If `text` is not a str.
            ValueError: If `text` is empty after normalization.
        """
        if not isinstance(text, str):
            raise TypeError(f"Expected str, got {type(text).__name__!r}")

        if normalize:
            text = unicodedata.normalize("NFC", text)

        if not text:
            raise ValueError("Input text is empty (or became empty after normalization)")

        return text.encode("utf-8")

    def bytes_to_tokens(self, byte_data: bytes) -> List[int]:
        """
        Convert a bytes object to a list of integer token IDs.

        Each byte is represented as an integer in the range [0, 255],
        which corresponds directly to its raw byte value.

        Args:
            byte_data: The raw byte sequence to convert.

        Returns:
            A list of integers (one per byte) in the range [0, 255].
            Returns an empty list if ``byte_data`` is empty.

        Raises:
            TypeError: If ``byte_data`` is not a :class:`bytes` object.
        """
        if not isinstance(byte_data, bytes):
            raise TypeError(f"Expected bytes, got {type(byte_data).__name__!r}")
        return list(byte_data)

    def pre_tokenize(self, text: str) -> list[list[int]]:
        """
        Split text into chunks using the GPT-2/r50k regex, then UTF-8 encode
        each chunk into a list of byte token IDs [0..255].

        Returns a list of token-ID lists — one per chunk.
        BPE merges will never cross chunk boundaries.
        """
        chunks = self._pat.findall(text)
        return [list(chunk.encode("utf-8")) for chunk in chunks]

    def pair_counting(self, chunks: list[list[int]]) -> Counter[Tuple[int, int]]:
        """
        Count all adjacent token pairs across all chunks.

        Pairs never span chunk boundaries because each chunk is counted
        independently.

        Args:
            chunks: A list of token-ID lists (one per pre-tokenized chunk).

        Returns:
            A Counter mapping each adjacent pair ``(a, b)`` to the number of times
            it appears across all chunks.
        """
        return Counter(
            pair
            for chunk in chunks
            for pair in zip(chunk, chunk[1:])
        )

    def most_frequent_pair(self, counts: Counter) -> Tuple[int, int]:
        """
        Return the most frequent adjacent pair from a pair-count Counter.

        This is the greedy selection step of BPE: at each iteration the pair
        with the highest count is chosen for merging.

        Args:
            counts: A Counter as returned by ``pair_counting``.

        Returns:
            The ``(a, b)`` pair with the highest count.

        Raises:
            ValueError: If ``counts`` is empty (nothing to merge).
        """
        if not counts:
            raise ValueError("Cannot find most frequent pair in an empty Counter")
        return max(counts, key=counts.get)

    def merge(
        self,
        chunks: list[list[int]],
        pair: Tuple[int, int],
        new_id: int,
    ) -> list[list[int]]:
        """Replace all occurrences of *pair* with *new_id* in every chunk."""
        p0, p1 = pair
        result = []
        for chunk in chunks:
            new_chunk: list[int] = []
            i = 0
            n = len(chunk)
            while i < n - 1:
                if chunk[i] == p0 and chunk[i + 1] == p1:
                    new_chunk.append(new_id)
                    i += 2
                else:
                    new_chunk.append(chunk[i])
                    i += 1
            if i < n:
                new_chunk.append(chunk[i])
            result.append(new_chunk)
        return result

    def _merge_one(self, tokens: list[int], pair: Tuple[int, int], new_id: int) -> list[int]:
        """Single-list merge: replace adjacent *pair* with *new_id* left-to-right."""
        new_ids: List[int] = []
        i: int = 0
        while i < len(tokens) - 1:
            if tokens[i] == pair[0] and tokens[i + 1] == pair[1]:
                new_ids.append(new_id)
                i += 2
            else:
                new_ids.append(tokens[i])
                i += 1
        if i < len(tokens):
            new_ids.append(tokens[i])
        return new_ids

    def train(self, text: str, vocab_size: int, verbose: bool = False) -> list[list[int]]:
        """
        Train the byte-level BPE tokenizer on a text corpus until the vocabulary
        reaches ``vocab_size`` or no more merges are possible.

        Uses GPT-2 style pre-tokenization so that merges never cross word
        boundaries.

        Args:
            text: Raw training text.
            vocab_size: Target total vocabulary size, including the initial
                        256 byte tokens. Must be greater than 256.
            verbose: If True, shows a progress bar with merge stats.

        Returns:
            A list of token-ID lists (one per pre-tokenized chunk).

        Raises:
            TypeError: If ``text`` is not a string or ``verbose`` is not a bool.
            ValueError: If ``vocab_size`` is less than or equal to 256.
        """
        if not isinstance(text, str):
            raise TypeError(f"Expected str, got {type(text).__name__!r}")
        if not text:
            raise ValueError("Input text is empty")
        if vocab_size <= 256:
            raise ValueError(f"vocab_size must be greater than 256, got {vocab_size}")
        if not isinstance(verbose, bool):
            raise TypeError(f"Expected bool, got {type(verbose).__name__!r}")

        # PRE-TOKENIZE — chunks are never merged across boundaries
        chunks = self.pre_tokenize(text)

        num_merges = vocab_size - len(self.vocab)
        if num_merges <= 0:
            return chunks

        pbar = tqdm(range(num_merges), desc="Merging", disable=not verbose)
        for step in pbar:
            counts = self.pair_counting(chunks)
            if not counts:
                break

            pair = self.most_frequent_pair(counts)
            count = counts[pair]
            new_id = len(self.vocab)

            chunks = self.merge(chunks, pair, new_id)
            self.merges[pair] = new_id
            self.vocab[new_id] = self.vocab[pair[0]] + self.vocab[pair[1]]

            if verbose:
                total_tokens = sum(len(c) for c in chunks)
                pbar.set_postfix(pair=pair, count=count, tokens=total_tokens)

        self._merge_rank = {pair: rank for rank, pair in enumerate(self.merges)}
        return chunks

    def encode(self, text_to_encode: str) -> List[int]:
        """
        Encode text using the learned BPE merges.

        Pre-tokenizes the input the same way training did, then applies
        merges to each chunk independently and flattens the result.
        """
        chunks = self.pre_tokenize(text_to_encode)

        result: List[int] = []
        for chunk in chunks:
            tokens = chunk
            while True:
                counts = Counter(zip(tokens, tokens[1:]))
                if not counts:
                    break
                eligible = {p for p in counts if p in self._merge_rank}
                if not eligible:
                    break
                best_pair = min(eligible, key=lambda p: self._merge_rank[p])
                tokens = self._merge_one(tokens, best_pair, self.merges[best_pair])
            result.extend(tokens)

        return result


    def save(self, path: str) -> None:
        data = {
            "merges": {f"{a},{b}": new_id for (a, b), new_id in self.merges.items()},
            "vocab": {str(k): list(v) for k, v in self.vocab.items()},
        }
        with open(path, "w") as f:
            json.dump(data, f)


    # LOAD
    def load(self, path: str) -> None:
        with open(path, "r") as f:
            data = json.load(f)
        self.merges = {
            (int(a), int(b)): new_id
            for key, new_id in data["merges"].items()
            for a, b in [key.split(",")]
        }
        self.vocab = {int(k): bytes(v) for k, v in data["vocab"].items()}
        self._merge_rank = {pair: rank for rank, pair in enumerate(self.merges)}


    def decode(self, tokens: List[int]) -> str:
        raw_bytes = b"".join(self.vocab[token_id] for token_id in tokens)
        return raw_bytes.decode("utf-8", errors="replace")
