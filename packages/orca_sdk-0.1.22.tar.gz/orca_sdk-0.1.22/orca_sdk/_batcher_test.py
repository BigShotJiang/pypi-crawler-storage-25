from __future__ import annotations

import asyncio

import pytest

from ._batcher import PredictionBatcher


@pytest.fixture
def recorded_calls() -> list[dict]:
    return []


@pytest.fixture
def flush_fn(recorded_calls: list[dict]):
    async def _flush(values: list[str], **kwargs) -> list[str]:
        recorded_calls.append({"values": values, **kwargs})
        return [f"result_{v}" for v in values]

    return _flush


@pytest.mark.asyncio
async def test_flush_on_max_batch_size(flush_fn, recorded_calls: list[dict]):
    # Given a batcher with max_batch_size=3 and a long timeout
    batcher = PredictionBatcher(
        flush_fn,
        max_wait_seconds=10.0,
        max_batch_size=3,
        per_item_keys=("expected_labels", "partition_id"),
    )

    async with batcher:
        # When we submit exactly max_batch_size items concurrently
        results = await asyncio.gather(
            batcher.predict("a", tags={"x"}),
            batcher.predict("b", tags={"x"}),
            batcher.predict("c", tags={"x"}),
        )

    # Then they are flushed as a single batch without waiting for the timer
    assert results == ["result_a", "result_b", "result_c"]
    assert len(recorded_calls) == 1
    assert recorded_calls[0]["values"] == ["a", "b", "c"]


@pytest.mark.asyncio
async def test_flush_on_timeout(flush_fn, recorded_calls: list[dict]):
    # Given a batcher with a short timeout and large batch size
    batcher = PredictionBatcher(
        flush_fn,
        max_wait_seconds=0.05,
        max_batch_size=100,
        per_item_keys=("expected_labels",),
    )

    async with batcher:
        # When we submit fewer items than max_batch_size
        results = await asyncio.gather(
            batcher.predict("a"),
            batcher.predict("b"),
        )

    # Then they are flushed after the timeout
    assert results == ["result_a", "result_b"]
    assert len(recorded_calls) == 1
    assert recorded_calls[0]["values"] == ["a", "b"]


@pytest.mark.asyncio
async def test_separate_groups_for_different_params(flush_fn, recorded_calls: list[dict]):
    # Given a batcher
    batcher = PredictionBatcher(
        flush_fn,
        max_wait_seconds=0.05,
        max_batch_size=100,
        per_item_keys=("expected_labels",),
    )

    async with batcher:
        # When we submit items with different shared params
        results = await asyncio.gather(
            batcher.predict("a", tags={"group1"}),
            batcher.predict("b", tags={"group2"}),
            batcher.predict("c", tags={"group1"}),
        )

    # Then items are grouped separately by params
    assert results == ["result_a", "result_b", "result_c"]
    assert len(recorded_calls) == 2
    group1_call = next(c for c in recorded_calls if c["values"] == ["a", "c"])
    group2_call = next(c for c in recorded_calls if c["values"] == ["b"])
    assert group1_call["tags"] == {"group1"}
    assert group2_call["tags"] == {"group2"}


@pytest.mark.asyncio
async def test_context_exit_flushes_remaining(flush_fn, recorded_calls: list[dict]):
    # Given a batcher with a long timeout
    batcher = PredictionBatcher(
        flush_fn,
        max_wait_seconds=10.0,
        max_batch_size=100,
        per_item_keys=("expected_labels",),
    )

    # When we submit items and then exit the context
    async with batcher:
        task = asyncio.create_task(batcher.predict("a"))
        await asyncio.sleep(0.01)

    result = await task

    # Then items are flushed on context exit
    assert result == "result_a"
    assert len(recorded_calls) == 1


@pytest.mark.asyncio
async def test_error_propagates_to_all_callers():
    # Given a flush function that raises
    async def failing_flush(values: list[str], **kwargs) -> list[str]:
        raise RuntimeError("server error")

    batcher = PredictionBatcher(
        failing_flush,
        max_wait_seconds=10.0,
        max_batch_size=2,
        per_item_keys=(),
    )

    async with batcher:
        # When a batch fails
        results = await asyncio.gather(
            batcher.predict("a"),
            batcher.predict("b"),
            return_exceptions=True,
        )

    # Then all callers in that batch receive the exception
    assert all(isinstance(r, RuntimeError) for r in results)
    assert all(str(r) == "server error" for r in results)


@pytest.mark.asyncio
async def test_per_item_keys_forwarded(recorded_calls: list[dict]):
    # Given a flush function that records calls
    async def _flush(values: list[str], **kwargs) -> list[str]:
        recorded_calls.append({"values": values, **kwargs})
        return [f"result_{v}" for v in values]

    batcher = PredictionBatcher(
        _flush,
        max_wait_seconds=10.0,
        max_batch_size=2,
        per_item_keys=("expected_labels", "partition_id"),
    )

    async with batcher:
        # When items have per-item kwargs
        results = await asyncio.gather(
            batcher.predict("a", expected_labels=1, partition_id="p1"),
            batcher.predict("b", expected_labels=0, partition_id="p2"),
        )

    # Then per-item kwargs are collected into lists
    assert results == ["result_a", "result_b"]
    assert len(recorded_calls) == 1
    assert recorded_calls[0]["expected_labels"] == [1, 0]
    assert recorded_calls[0]["partition_id"] == ["p1", "p2"]


@pytest.mark.asyncio
async def test_per_item_keys_none_when_all_none(recorded_calls: list[dict]):
    # Given a flush function that records calls
    async def _flush(values: list[str], **kwargs) -> list[str]:
        recorded_calls.append({"values": values, **kwargs})
        return [f"result_{v}" for v in values]

    batcher = PredictionBatcher(
        _flush,
        max_wait_seconds=10.0,
        max_batch_size=2,
        per_item_keys=("expected_labels", "partition_id"),
    )

    async with batcher:
        # When no per-item kwargs are provided
        results = await asyncio.gather(
            batcher.predict("a"),
            batcher.predict("b"),
        )

    # Then per-item kwargs are passed as None (not a list of Nones)
    assert results == ["result_a", "result_b"]
    assert recorded_calls[0]["expected_labels"] is None
    assert recorded_calls[0]["partition_id"] is None


@pytest.mark.asyncio
async def test_filters_with_list_values_in_grouping_key(recorded_calls: list[dict]):
    # Given a flush function that records calls
    async def _flush(values: list[str], **kwargs) -> list[str]:
        recorded_calls.append({"values": values, **kwargs})
        return [f"result_{v}" for v in values]

    batcher = PredictionBatcher(
        _flush,
        max_wait_seconds=10.0,
        max_batch_size=2,
        per_item_keys=("expected_labels",),
    )

    async with batcher:
        # When filters contain tuples with list values (e.g. "in" operator)
        results = await asyncio.gather(
            batcher.predict("a", filters=[("key", "in", ["x", "y"])]),
            batcher.predict("b", filters=[("key", "in", ["x", "y"])]),
        )

    # Then they are correctly grouped and flushed
    assert results == ["result_a", "result_b"]
    assert len(recorded_calls) == 1
    assert recorded_calls[0]["values"] == ["a", "b"]


@pytest.mark.asyncio
async def test_timer_flush_with_suspending_flush_fn():
    # Given a flush function that yields control (simulating real async I/O like apredict)
    async def suspending_flush(values: list[str], **kwargs) -> list[str]:
        await asyncio.sleep(0)
        return [f"result_{v}" for v in values]

    batcher = PredictionBatcher(
        suspending_flush,
        max_wait_seconds=0.05,
        max_batch_size=100,
        per_item_keys=(),
    )

    async with batcher:
        # When items are flushed via timer (not by reaching max_batch_size)
        results = await asyncio.gather(
            batcher.predict("a"),
            batcher.predict("b"),
        )

    # Then callers receive results without hanging from self-cancellation
    assert results == ["result_a", "result_b"]


@pytest.mark.asyncio
async def test_invalid_config():
    async def noop(values: list[str]) -> list[str]:
        return values

    with pytest.raises(ValueError, match="max_wait_seconds must be positive"):
        PredictionBatcher(noop, max_wait_seconds=0, max_batch_size=10, per_item_keys=())

    with pytest.raises(ValueError, match="max_batch_size must be positive"):
        PredictionBatcher(noop, max_wait_seconds=1.0, max_batch_size=0, per_item_keys=())
