from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Generic, TypeVar

T = TypeVar("T")


def _make_hashable(v: Any) -> Any:
    """Recursively convert a value into a hashable equivalent."""
    if isinstance(v, set):
        return frozenset(v)
    if isinstance(v, (list, tuple)):
        return tuple(_make_hashable(item) for item in v)
    if isinstance(v, dict):
        return tuple(sorted((k, _make_hashable(val)) for k, val in v.items()))
    return v


@dataclass
class _PendingItem(Generic[T]):
    value: str
    per_item_kwargs: dict[str, Any]
    future: asyncio.Future[T]


@dataclass
class _BatchGroup(Generic[T]):
    shared_params: dict[str, Any]
    items: list[_PendingItem[T]] = field(default_factory=list)
    timer_task: asyncio.Task[None] | None = None


class PredictionBatcher(Generic[T]):
    """
    Accumulates individual async prediction requests and flushes them as
    a single batch when either `max_batch_size` items have been collected
    or `max_wait_seconds` has elapsed since the first pending item arrived.

    Attributes:
        max_wait_seconds: Maximum time to wait before flushing a partial batch
        max_batch_size: Maximum number of items to accumulate before flushing
    """

    def __init__(
        self,
        flush_fn: Callable[..., Awaitable[list[T]]],
        *,
        max_wait_seconds: float = 0.5,
        max_batch_size: int = 10,
        per_item_keys: tuple[str, ...],
    ):
        if max_wait_seconds <= 0:
            raise ValueError("max_wait_seconds must be positive")
        if max_batch_size <= 0:
            raise ValueError("max_batch_size must be positive")
        self.max_wait_seconds = max_wait_seconds
        self.max_batch_size = max_batch_size
        self._flush_fn = flush_fn
        self._per_item_keys = per_item_keys
        self._groups: dict[Any, _BatchGroup[T]] = {}

    async def predict(self, value: str, **kwargs: Any) -> T:
        """Submit a single prediction request that will be batched with others.

        Accepts the same keyword arguments as the model's `apredict` for a
        single value. Returns when the batch containing this item is flushed.
        """
        per_item_kwargs = {k: kwargs.pop(k, None) for k in self._per_item_keys}
        key = _make_hashable(kwargs)

        group = self._groups.get(key)
        if group is None:
            group = self._groups[key] = _BatchGroup(shared_params=kwargs)

        future: asyncio.Future[T] = asyncio.get_running_loop().create_future()
        group.items.append(_PendingItem(value=value, per_item_kwargs=per_item_kwargs, future=future))

        if len(group.items) >= self.max_batch_size:
            await self._flush_group(key)
        elif group.timer_task is None:
            group.timer_task = asyncio.create_task(self._timer_flush(key))

        return await future

    async def _timer_flush(self, key: Any) -> None:
        await asyncio.sleep(self.max_wait_seconds)
        if key in self._groups:
            await self._flush_group(key)

    async def _flush_group(self, key: Any) -> None:
        group = self._groups.pop(key, None)
        if group is None:
            return
        if (
            group.timer_task is not None
            and not group.timer_task.done()
            and group.timer_task is not asyncio.current_task()
        ):
            group.timer_task.cancel()

        items = group.items
        call_kwargs: dict[str, Any] = {**group.shared_params}
        for k in self._per_item_keys:
            collected = [item.per_item_kwargs.get(k) for item in items]
            call_kwargs[k] = collected if any(v is not None for v in collected) else None

        try:
            results = await self._flush_fn([item.value for item in items], **call_kwargs)
            for item, result in zip(items, results):
                if not item.future.done():
                    item.future.set_result(result)
        except Exception as exc:
            for item in items:
                if not item.future.done():
                    item.future.set_exception(exc)

    async def flush(self) -> None:
        """Flush all pending groups immediately."""
        for key in list(self._groups):
            await self._flush_group(key)

    async def __aenter__(self) -> PredictionBatcher[T]:
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        await self.flush()
