import csv
import json
import os
import tempfile
from pathlib import Path
from textwrap import dedent
from unittest.mock import patch
from uuid import uuid4

import httpx
import pytest

from .datasource import (
    Datasource,
    _SignedUploadUnavailable,
    _upload_files_multipart,
    _upload_files_to_datasource,
    _upload_files_via_signed_urls,
)


def test_create_datasource(datasource, data):
    assert datasource is not None
    assert datasource.name == "test_datasource"
    assert datasource.length == len(data)


def test_create_datasource_unauthenticated(unauthenticated_client):
    with unauthenticated_client.use():
        with pytest.raises(ValueError, match="Invalid API key"):
            Datasource.from_list("test_datasource", [{"value": "test"}])


def test_create_datasource_already_exists_error(data, datasource):
    with pytest.raises(ValueError):
        Datasource.from_list("test_datasource", data, if_exists="error")


def test_create_datasource_already_exists_return(data, datasource):
    returned_dataset = Datasource.from_list("test_datasource", data, if_exists="open")
    assert returned_dataset is not None
    assert returned_dataset.name == "test_datasource"
    assert returned_dataset.length == len(data)


def test_create_datasource_from_hf_dataset(data):
    datasets = pytest.importorskip("datasets")
    hf_dataset = datasets.Dataset.from_list(data)
    datasource = Datasource.from_hf_dataset(f"test_hf_datasource_{uuid4()}", hf_dataset)
    assert datasource is not None
    assert datasource.length == len(hf_dataset)


def test_open_datasource(datasource):
    fetched_datasource = Datasource.open(datasource.name)
    assert fetched_datasource is not None
    assert fetched_datasource.name == datasource.name
    assert fetched_datasource.length == len(datasource)


def test_open_datasource_unauthenticated(unauthenticated_client, datasource):
    with unauthenticated_client.use():
        with pytest.raises(ValueError, match="Invalid API key"):
            Datasource.open("test_datasource")


def test_open_datasource_invalid_input():
    with pytest.raises(ValueError, match=r"Invalid input:.*"):
        Datasource.open("not valid id")


def test_open_datasource_not_found():
    with pytest.raises(LookupError):
        Datasource.open(str(uuid4()))


def test_open_datasource_unauthorized(unauthorized_client, datasource):
    with unauthorized_client.use():
        with pytest.raises(LookupError):
            Datasource.open(datasource.id)


def test_all_datasources(datasource):
    datasources = Datasource.all()
    assert len(datasources) > 0
    assert any(datasource.name == datasource.name for datasource in datasources)


def test_all_datasources_unauthenticated(unauthenticated_client):
    with unauthenticated_client.use():
        with pytest.raises(ValueError, match="Invalid API key"):
            Datasource.all()


def test_drop_datasource():
    Datasource.from_list("datasource_to_delete", [{"value": "test", "label": 0}])
    assert Datasource.exists("datasource_to_delete")
    Datasource.drop("datasource_to_delete")
    assert not Datasource.exists("datasource_to_delete")


def test_drop_datasource_unauthenticated(datasource, unauthenticated_client):
    with unauthenticated_client.use():
        with pytest.raises(ValueError, match="Invalid API key"):
            Datasource.drop(datasource.id)


def test_drop_datasource_not_found():
    with pytest.raises(LookupError):
        Datasource.drop(str(uuid4()))
    # ignores error if specified
    Datasource.drop(str(uuid4()), if_not_exists="ignore")


def test_drop_datasource_unauthorized(datasource, unauthorized_client):
    with unauthorized_client.use():
        with pytest.raises(LookupError):
            Datasource.drop(datasource.id)


def test_drop_datasource_invalid_input():
    with pytest.raises(ValueError, match=r"Invalid input:.*"):
        Datasource.drop("not valid id")


def test_from_list():
    # Test creating datasource from list of dictionaries
    data = [
        {"column1": 1, "column2": "a"},
        {"column1": 2, "column2": "b"},
        {"column1": 3, "column2": "c"},
    ]
    datasource = Datasource.from_list(f"test_list_{uuid4()}", data)
    assert datasource.name.startswith("test_list_")
    assert datasource.length == 3
    assert "column1" in datasource.columns
    assert "column2" in datasource.columns


def test_from_dict():
    # Test creating datasource from dictionary of columns
    data = {
        "column1": [1, 2, 3],
        "column2": ["a", "b", "c"],
    }
    datasource = Datasource.from_dict(f"test_dict_{uuid4()}", data)
    assert datasource.name.startswith("test_dict_")
    assert datasource.length == 3
    assert "column1" in datasource.columns
    assert "column2" in datasource.columns


def test_from_pandas():
    pd = pytest.importorskip("pandas")

    # Test creating datasource from pandas DataFrame
    df = pd.DataFrame(
        {
            "column1": [1, 2, 3],
            "column2": ["a", "b", "c"],
        }
    )
    datasource = Datasource.from_pandas(f"test_pandas_{uuid4()}", df)
    assert datasource.name.startswith("test_pandas_")
    assert datasource.length == 3
    assert "column1" in datasource.columns
    assert "column2" in datasource.columns


def test_from_arrow():
    pa = pytest.importorskip("pyarrow")

    # Test creating datasource from pyarrow Table
    table = pa.table(
        {
            "column1": [1, 2, 3],
            "column2": ["a", "b", "c"],
        }
    )
    datasource = Datasource.from_arrow(f"test_arrow_{uuid4()}", table)
    assert datasource.name.startswith("test_arrow_")
    assert datasource.length == 3
    assert "column1" in datasource.columns
    assert "column2" in datasource.columns


def test_from_list_already_exists():
    # Test the if_exists parameter with from_list
    data = [{"column1": 1, "column2": "a"}]
    name = f"test_list_exists_{uuid4()}"

    # Create the first datasource
    datasource1 = Datasource.from_list(name, data)
    assert datasource1.length == 1

    # Try to create again with if_exists="error" (should raise)
    with pytest.raises(ValueError):
        Datasource.from_list(name, data, if_exists="error")

    # Try to create again with if_exists="open" (should return existing)
    datasource2 = Datasource.from_list(name, data, if_exists="open")
    assert datasource2.id == datasource1.id
    assert datasource2.name == datasource1.name


def test_from_dict_already_exists():
    # Test the if_exists parameter with from_dict
    data = {"column1": [1], "column2": ["a"]}
    name = f"test_dict_exists_{uuid4()}"

    # Create the first datasource
    datasource1 = Datasource.from_dict(name, data)
    assert datasource1.length == 1

    # Try to create again with if_exists="error" (should raise)
    with pytest.raises(ValueError):
        Datasource.from_dict(name, data, if_exists="error")

    # Try to create again with if_exists="open" (should return existing)
    datasource2 = Datasource.from_dict(name, data, if_exists="open")
    assert datasource2.id == datasource1.id
    assert datasource2.name == datasource1.name


def test_from_pandas_already_exists():
    pd = pytest.importorskip("pandas")

    # Test the if_exists parameter with from_pandas
    df = pd.DataFrame({"column1": [1], "column2": ["a"]})
    name = f"test_pandas_exists_{uuid4()}"

    # Create the first datasource
    datasource1 = Datasource.from_pandas(name, df)
    assert datasource1.length == 1

    # Try to create again with if_exists="error" (should raise)
    with pytest.raises(ValueError):
        Datasource.from_pandas(name, df, if_exists="error")

    # Try to create again with if_exists="open" (should return existing)
    datasource2 = Datasource.from_pandas(name, df, if_exists="open")
    assert datasource2.id == datasource1.id
    assert datasource2.name == datasource1.name


def test_from_arrow_already_exists():
    pa = pytest.importorskip("pyarrow")

    # Test the if_exists parameter with from_arrow
    table = pa.table({"column1": [1], "column2": ["a"]})
    name = f"test_arrow_exists_{uuid4()}"

    # Create the first datasource
    datasource1 = Datasource.from_arrow(name, table)
    assert datasource1.length == 1

    # Try to create again with if_exists="error" (should raise)
    with pytest.raises(ValueError):
        Datasource.from_arrow(name, table, if_exists="error")

    # Try to create again with if_exists="open" (should return existing)
    datasource2 = Datasource.from_arrow(name, table, if_exists="open")
    assert datasource2.id == datasource1.id
    assert datasource2.name == datasource1.name


def test_from_disk_csv():
    # Test creating datasource from CSV file
    with tempfile.NamedTemporaryFile(mode="w", suffix=".csv", delete=False) as f:
        f.write("column1,column2\n1,a\n2,b\n3,c")
        f.flush()

        try:
            datasource = Datasource.from_disk(f"test_csv_{uuid4()}", f.name)
            assert datasource.length == 3
            assert "column1" in datasource.columns
            assert "column2" in datasource.columns
        finally:
            os.unlink(f.name)


def test_from_disk_json():
    # Test creating datasource from JSON file
    import json

    data = [{"column1": 1, "column2": "a"}, {"column1": 2, "column2": "b"}]

    with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
        json.dump(data, f)
        f.flush()

        try:
            datasource = Datasource.from_disk(f"test_json_{uuid4()}", f.name)
            assert datasource.length == 2
            assert "column1" in datasource.columns
            assert "column2" in datasource.columns
        finally:
            os.unlink(f.name)


def test_from_disk_already_exists():
    # Test the if_exists parameter with from_disk
    with tempfile.NamedTemporaryFile(mode="w", suffix=".csv", delete=False) as f:
        f.write("column1,column2\n1,a")
        f.flush()

        try:
            name = f"test_disk_exists_{uuid4()}"

            # Create the first datasource
            datasource1 = Datasource.from_disk(name, f.name)
            assert datasource1.length == 1

            # Try to create again with if_exists="error" (should raise)
            with pytest.raises(ValueError):
                Datasource.from_disk(name, f.name, if_exists="error")

            # Try to create again with if_exists="open" (should return existing)
            datasource2 = Datasource.from_disk(name, f.name, if_exists="open")
            assert datasource2.id == datasource1.id
            assert datasource2.name == datasource1.name
        finally:
            os.unlink(f.name)


def test_query_datasource_rows():
    """Test querying rows from a datasource with pagination and shuffle."""
    # Create a new dataset with 5 entries for testing
    test_data = [{"id": i, "name": f"item_{i}"} for i in range(5)]
    datasource = Datasource.from_list(name="test_query_datasource", data=test_data)

    # Test basic query
    rows = datasource.query(limit=3)
    assert len(rows) == 3
    assert all(isinstance(row, dict) for row in rows)

    # Test offset
    offset_rows = datasource.query(offset=2, limit=2)
    assert len(offset_rows) == 2
    assert offset_rows[0]["id"] == 2

    # Test shuffle with seed
    assert datasource.query(limit=5, shuffle=True, shuffle_seed=42) == datasource.query(
        limit=5, shuffle=True, shuffle_seed=42
    )


def test_query_datasource_with_filters():
    """Test querying datasource rows with various filter operators."""
    # Create a datasource with test data
    test_data = [
        {"name": "Alice", "age": 25, "city": "New York", "score": 85.5},
        {"name": "Bob", "age": 30, "city": "San Francisco", "score": 90.0},
        {"name": "Charlie", "age": 35, "city": "Chicago", "score": 75.5},
        {"name": "Diana", "age": 28, "city": "Boston", "score": 88.0},
        {"name": "Eve", "age": 32, "city": "New York", "score": 92.0},
    ]
    datasource = Datasource.from_list(name=f"test_filter_datasource_{uuid4()}", data=test_data)

    # Test == operator
    rows = datasource.query(filters=[("city", "==", "New York")])
    assert len(rows) == 2
    assert all(row["city"] == "New York" for row in rows)

    # Test > operator
    rows = datasource.query(filters=[("age", ">", 30)])
    assert len(rows) == 2
    assert all(row["age"] > 30 for row in rows)

    # Test >= operator
    rows = datasource.query(filters=[("score", ">=", 88.0)])
    assert len(rows) == 3
    assert all(row["score"] >= 88.0 for row in rows)

    # Test < operator
    rows = datasource.query(filters=[("age", "<", 30)])
    assert len(rows) == 2
    assert all(row["age"] < 30 for row in rows)

    # Test in operator
    rows = datasource.query(filters=[("city", "in", ["New York", "Boston"])])
    assert len(rows) == 3
    assert all(row["city"] in ["New York", "Boston"] for row in rows)

    # Test not in operator
    rows = datasource.query(filters=[("city", "not in", ["New York", "Boston"])])
    assert len(rows) == 2
    assert all(row["city"] not in ["New York", "Boston"] for row in rows)

    # Test like operator
    rows = datasource.query(filters=[("name", "like", "li")])
    assert len(rows) == 2
    assert all("li" in row["name"].lower() for row in rows)

    # Test multiple filters (AND logic)
    rows = datasource.query(filters=[("city", "==", "New York"), ("age", ">", 26)])
    assert len(rows) == 1
    assert rows[0]["name"] == "Eve"

    # Test filter with pagination
    rows = datasource.query(filters=[("age", ">=", 28)], limit=2, offset=1)
    assert len(rows) == 2


def test_query_datasource_with_none_filters():
    """Test filtering for None values."""
    test_data = [
        {"name": "Alice", "age": 25, "label": "A"},
        {"name": "Bob", "age": 30, "label": None},
        {"name": "Charlie", "age": 35, "label": "C"},
        {"name": "Diana", "age": None, "label": "D"},
        {"name": "Eve", "age": 32, "label": None},
    ]
    datasource = Datasource.from_list(name=f"test_none_filter_{uuid4()}", data=test_data)

    # Test == None
    rows = datasource.query(filters=[("label", "==", None)])
    assert len(rows) == 2
    assert all(row["label"] is None for row in rows)

    # Test != None
    rows = datasource.query(filters=[("label", "!=", None)])
    assert len(rows) == 3
    assert all(row["label"] is not None for row in rows)

    # Test that None values are excluded from comparison operators
    rows = datasource.query(filters=[("age", ">", 25)])
    assert len(rows) == 3
    assert all(row["age"] is not None and row["age"] > 25 for row in rows)


def test_query_datasource_filter_invalid_column():
    """Test that querying with an invalid column raises an error."""
    test_data = [{"name": "Alice", "age": 25}]
    datasource = Datasource.from_list(name=f"test_invalid_filter_{uuid4()}", data=test_data)

    with pytest.raises(ValueError):
        datasource.query(filters=[("invalid_column", "==", "test")])


def test_to_list(data, datasource):
    assert datasource.to_list() == data


def test_download_datasource_hf_dataset(data, datasource: Datasource):
    Dataset = pytest.importorskip("datasets").Dataset
    with tempfile.TemporaryDirectory() as temp_dir:
        datasource.download(temp_dir, file_type="hf_dataset")
        downloaded_hf_dataset_dir = f"{temp_dir}/{datasource.name}"
        assert os.path.exists(downloaded_hf_dataset_dir)
        assert os.path.isdir(downloaded_hf_dataset_dir)
        assert not os.path.exists(f"{downloaded_hf_dataset_dir}.zip")
        dataset_from_downloaded_hf_dataset = Dataset.load_from_disk(downloaded_hf_dataset_dir)
        assert set(dataset_from_downloaded_hf_dataset.column_names) == set(data[0].keys())
        assert dataset_from_downloaded_hf_dataset.to_list() == data


def test_download_datasource_json(data, datasource: Datasource):
    with tempfile.TemporaryDirectory() as temp_dir:
        datasource.download(temp_dir, file_type="json")
        downloaded_json_file = f"{temp_dir}/{datasource.name}.json"
        assert os.path.exists(downloaded_json_file)
        with open(downloaded_json_file, "r") as f:
            content = json.load(f)
            assert content == data


def test_download_datasource_csv(data, datasource: Datasource):
    with tempfile.TemporaryDirectory() as temp_dir:
        datasource.download(temp_dir, file_type="csv")
        downloaded_csv_file = f"{temp_dir}/{datasource.name}.csv"
        assert os.path.exists(downloaded_csv_file)
        with open(downloaded_csv_file, "r") as f:
            reader = csv.DictReader(f)
            rows = list(reader)
        assert set(rows[0].keys()) == set(data[0].keys())
        assert len(rows) == len(data)
        # Compare all columns, handling CSV's string representation
        for i, (csv_row, expected_row) in enumerate(zip(rows, data)):
            for col in expected_row.keys():
                csv_val = csv_row[col]
                expected_val = expected_row[col]
                # CSV represents None as empty string
                if expected_val is None:
                    assert csv_val == "", f"Row {i}, column {col}: expected empty string, got {csv_val!r}"
                elif isinstance(expected_val, float):
                    assert float(csv_val) == pytest.approx(expected_val), f"Row {i}, column {col}"
                elif isinstance(expected_val, int):
                    assert int(csv_val) == expected_val, f"Row {i}, column {col}"
                else:
                    assert csv_val == str(expected_val), f"Row {i}, column {col}"


def test_datasource_repr():
    ds = Datasource(
        {  # type: ignore[typeddict-item]
            "id": "ds-id",
            "org_id": "org-id",
            "name": "my_datasource",
            "description": None,
            "storage_path": "",
            "length": 100,
            "columns": [
                {"name": "value", "type": "STRING"},
                {"name": "label", "type": "ENUM", "enum_options": ["soup", "cats"]},
                {"name": "score", "type": "FLOAT"},
            ],
            "created_at": "2025-01-01T00:00:00",
            "updated_at": "2025-01-01T00:00:00",
        }
    )
    assert repr(ds) == dedent(
        """\
        Datasource({
            name: 'my_datasource',
            length: 100,
            columns: ({
                value: str
                label: enum('soup', 'cats')
                score: float
            })
        })"""
    )


# ====== Signed vs Multipart Upload Tests ======


@pytest.fixture()
def csv_file(tmp_path):
    p = tmp_path / "data.csv"
    p.write_text("a,b\n1,x\n2,y\n3,z")
    return [p]


@pytest.fixture()
def json_file(tmp_path):
    p = tmp_path / "data.json"
    p.write_text(json.dumps([{"text": f"item_{i}", "val": i} for i in range(4)]))
    return [p]


def test_signed_upload_csv(csv_file):
    meta = _upload_files_via_signed_urls(f"test_signed_csv_{uuid4()}", csv_file)
    assert meta["length"] == 3
    assert {c["name"] for c in meta["columns"]} == {"a", "b"}


def test_signed_upload_json(json_file):
    meta = _upload_files_via_signed_urls(f"test_signed_json_{uuid4()}", json_file)
    assert meta["length"] == 4


def test_multipart_upload_csv(csv_file):
    meta = _upload_files_multipart(f"test_multipart_csv_{uuid4()}", csv_file)
    assert meta["length"] == 3
    assert {c["name"] for c in meta["columns"]} == {"a", "b"}


def test_multipart_upload_json(json_file):
    meta = _upload_files_multipart(f"test_multipart_json_{uuid4()}", json_file)
    assert meta["length"] == 4


def test_signed_and_multipart_produce_same_schema(csv_file, tmp_path):
    copy = tmp_path / "copy.csv"
    copy.write_text(csv_file[0].read_text())
    m1 = _upload_files_via_signed_urls(f"test_par_s_{uuid4()}", csv_file)
    m2 = _upload_files_multipart(f"test_par_m_{uuid4()}", [copy])
    assert m1["length"] == m2["length"]
    assert {c["name"]: c["type"] for c in m1["columns"]} == {c["name"]: c["type"] for c in m2["columns"]}


def test_fallback_to_multipart_when_signed_unavailable(csv_file):
    # Given signed uploads raise _SignedUploadUnavailable
    with (
        patch(
            "orca_sdk.datasource._upload_files_via_signed_urls",
            side_effect=_SignedUploadUnavailable("mocked"),
        ) as mock_signed,
        patch("orca_sdk.datasource._upload_files_multipart", wraps=_upload_files_multipart) as mock_multi,
    ):
        meta = _upload_files_to_datasource(f"test_fb_{uuid4()}", csv_file)
    # Then signed was attempted and multipart was used as fallback
    mock_signed.assert_called_once()
    mock_multi.assert_called_once()
    assert meta["length"] == 3


def test_no_fallback_on_non_signed_errors(csv_file):
    with patch(
        "orca_sdk.datasource._upload_files_via_signed_urls",
        side_effect=RuntimeError("boom"),
    ):
        with pytest.raises(RuntimeError, match="boom"):
            _upload_files_to_datasource(f"test_nfb_{uuid4()}", csv_file)


def test_from_disk_uses_signed_upload(csv_file):
    with patch(
        "orca_sdk.datasource._upload_files_via_signed_urls",
        wraps=_upload_files_via_signed_urls,
    ) as mock_signed:
        ds = Datasource.from_disk(f"test_disk_signed_{uuid4()}", csv_file[0])
    mock_signed.assert_called_once()
    assert ds.length == 3


def test_falls_back_to_multipart_when_backend_rejects_signed_uploads(csv_file):
    """When the server returns 422 'Signed uploads are not supported', the
    OrcaClient event hook converts it to ValueError before the SDK can inspect
    the status code. The SDK must catch that ValueError and fall back to
    multipart rather than letting it propagate to the user."""
    from .client import OrcaClient

    real_client = OrcaClient._resolve_client()
    original_post = real_client.post

    # Given the init endpoint rejects signed uploads (simulates the event hook
    # raising ValueError for a 422 "Signed uploads are not supported" response)
    def rejecting_init(url, *args, **kwargs):
        if "/datasource/upload/init" in str(url):
            raise ValueError(
                "Invalid input:\n\tfiles: Signed uploads are not supported for the current storage backend"
            )
        return original_post(url, *args, **kwargs)

    # When uploading through the main entry point
    with patch.object(real_client, "post", new=rejecting_init):
        meta = _upload_files_to_datasource(f"test_fb_unsupported_{uuid4()}", csv_file)

    # Then the upload falls back to multipart and succeeds
    assert meta["length"] == 3


def test_falls_back_to_multipart_when_too_many_pending_uploads(csv_file):
    """When the server returns 422 'Too many pending uploads', the OrcaClient
    event hook converts it to ValueError. The SDK must catch that ValueError
    and fall back to multipart — the multipart path has no such limit."""
    from .client import OrcaClient

    real_client = OrcaClient._resolve_client()
    original_post = real_client.post

    # Given the init endpoint rejects with "Too many pending uploads"
    def rejecting_init(url, *args, **kwargs):
        if "/datasource/upload/init" in str(url):
            raise ValueError(
                "Invalid input:\n\tfiles: Too many pending uploads — finalize or wait for existing ones to expire"
            )
        return original_post(url, *args, **kwargs)

    # When uploading through the main entry point
    with patch.object(real_client, "post", new=rejecting_init):
        meta = _upload_files_to_datasource(f"test_fb_pending_{uuid4()}", csv_file)

    # Then the upload falls back to multipart and succeeds
    assert meta["length"] == 3


def test_signed_upload_cleans_up_on_storage_http_error(csv_file):
    """When PUT to storage returns an HTTP error, the pending-upload counter is
    still decremented (via cancel) so that future uploads are not blocked.

    MAX_PENDING_UPLOADS_PER_ORG is 5, so 5 leaked counters would block the org.
    """
    # Given 5 signed uploads where PUT to storage fails with HTTP 500
    error_response = httpx.Response(500, request=httpx.Request("PUT", "http://storage"))
    with patch(
        "orca_sdk.datasource.httpx.put",
        side_effect=httpx.HTTPStatusError("storage error", request=error_response.request, response=error_response),
    ):
        for i in range(5):
            with pytest.raises(httpx.HTTPStatusError):
                _upload_files_via_signed_urls(f"test_cleanup_{i}_{uuid4()}", csv_file)

    # Then the counter was cleaned up after each failure,
    # so a subsequent upload is not blocked by "too many pending uploads"
    meta = _upload_files_via_signed_urls(f"test_after_cleanup_{uuid4()}", csv_file)
    assert meta["length"] == 3


def test_signed_upload_cleanup_calls_cancel_not_finalize(csv_file):
    """When an error occurs during PUT, the cleanup must call /cancel (not
    /finalize) so the server doesn't accidentally create the datasource."""
    from .client import OrcaClient

    real_client = OrcaClient._resolve_client()
    original_post = real_client.post
    cancel_calls: list[dict] = []
    finalize_calls: list[dict] = []

    def tracking_post(url, *args, **kwargs):
        url_str = str(url)
        if "/datasource/upload/cancel" in url_str:
            cancel_calls.append(kwargs.get("json", {}))
        if "/datasource/upload/finalize" in url_str:
            finalize_calls.append(kwargs.get("json", {}))
        return original_post(url, *args, **kwargs)

    # Given a PUT that fails after init succeeds
    error_response = httpx.Response(500, request=httpx.Request("PUT", "http://storage"))
    with (
        patch.object(real_client, "post", new=tracking_post),
        patch(
            "orca_sdk.datasource.httpx.put",
            side_effect=httpx.HTTPStatusError("boom", request=error_response.request, response=error_response),
        ),
    ):
        # When the upload fails
        with pytest.raises(httpx.HTTPStatusError):
            _upload_files_via_signed_urls(f"test_cancel_tracking_{uuid4()}", csv_file)

    # Then /cancel was called (not /finalize)
    assert len(cancel_calls) == 1
    assert "upload_id" in cancel_calls[0]
    assert len(finalize_calls) == 0


def test_signed_upload_cancels_on_finalize_network_error(csv_file):
    """When finalize fails with a network error, the pending upload must be
    cancelled so it doesn't occupy a slot until expiry."""
    from .client import OrcaClient

    real_client = OrcaClient._resolve_client()
    original_post = real_client.post
    cancel_calls: list[dict] = []

    def post_that_fails_on_finalize(url, *args, **kwargs):
        url_str = str(url)
        if "/datasource/upload/cancel" in url_str:
            cancel_calls.append(kwargs.get("json", {}))
            return original_post(url, *args, **kwargs)
        if "/datasource/upload/finalize" in url_str:
            raise httpx.ConnectError("connection refused")
        return original_post(url, *args, **kwargs)

    # Given a finalize that fails with ConnectError after PUT succeeds
    with patch.object(real_client, "post", new=post_that_fails_on_finalize):
        # When the finalize request fails
        with pytest.raises(httpx.ConnectError):
            _upload_files_via_signed_urls(f"test_finalize_cancel_{uuid4()}", csv_file)

    # Then /cancel was called to free the pending upload slot
    assert len(cancel_calls) == 1
    assert "upload_id" in cancel_calls[0]


def test_signed_upload_does_not_cancel_after_finalize_server_error(csv_file):
    """When finalize returns a server error (e.g. 422 'name already exists'),
    the server already claimed the pending upload in its first step. Cancel
    should NOT be called — it's a no-op and semantically wrong."""
    from .client import OrcaClient

    real_client = OrcaClient._resolve_client()
    cancel_calls: list[dict] = []
    upload_id = str(uuid4())

    # Given init succeeds, PUT succeeds, but finalize returns 422 (event hook
    # converts to ValueError — "Datasource with this name already exists")
    def mock_post(url, *args, **kwargs):
        url_str = str(url)
        if "/datasource/upload/init" in url_str:
            mock_resp = httpx.Response(
                200,
                json={
                    "upload_id": upload_id,
                    "signed_urls": {fp.name: f"http://storage/{fp.name}" for fp in csv_file},
                    "expires_at": "2099-01-01T00:00:00Z",
                },
                request=httpx.Request("POST", url_str),
            )
            return mock_resp
        if "/datasource/upload/finalize" in url_str:
            raise ValueError("Invalid input:\n\tname: Datasource with this name already exists")
        if "/datasource/upload/cancel" in url_str:
            cancel_calls.append(kwargs.get("json", {}))
            return httpx.Response(204, request=httpx.Request("POST", url_str))
        return real_client.post(url, *args, **kwargs)

    mock_put_resp = httpx.Response(200, request=httpx.Request("PUT", "http://storage/data.csv"))

    # When finalize raises ValueError from event hook
    with (
        patch.object(real_client, "post", new=mock_post),
        patch("orca_sdk.datasource.httpx.put", return_value=mock_put_resp),
    ):
        with pytest.raises(ValueError, match="already exists"):
            _upload_files_via_signed_urls(f"test_dup_{uuid4()}", csv_file)

    # Then cancel should NOT have been called
    assert len(cancel_calls) == 0, f"cancel was called {len(cancel_calls)} time(s) but should not have been"


def test_from_disk_large_hf_dataset_with_two_arrow_parts():
    datasets = pytest.importorskip("datasets")

    # Small dataset for testing
    size = 10

    # Uncomment for larger dataset
    # size = 5_000_000

    # Use from_list instead of from_generator to avoid dill pickling the closure.
    # In Python 3.14, dill._save_with_postproc calls _batch_setitems without the
    # `obj` argument that Python 3.14's _Pickler now requires, causing a TypeError.
    # from_list bypasses that code path entirely.
    payload = "x" * 1000
    dataset = datasets.Dataset.from_list([{"value": f"{i}_{payload}"} for i in range(size)])

    with tempfile.TemporaryDirectory() as temp_dir:
        dataset_dir = Path(temp_dir) / "large_hf_dataset"
        dataset.save_to_disk(dataset_dir, num_shards=2)

        arrow_parts = list(dataset_dir.glob("*.arrow"))
        total_arrow_size_bytes = sum(arrow_file.stat().st_size for arrow_file in arrow_parts)

        # Then the on-disk Arrow representation has 2 parts and is about 1GB
        assert len(arrow_parts) == 2
        assert total_arrow_size_bytes >= 0.5 * size * 1000
        assert total_arrow_size_bytes <= 1.5 * size * 1000

        # When uploading the dataset directory as a datasource
        datasource = Datasource.from_disk(f"test_large_hf_{uuid4()}", dataset_dir)

    # Then upload succeeds with all rows
    assert datasource.length == size
