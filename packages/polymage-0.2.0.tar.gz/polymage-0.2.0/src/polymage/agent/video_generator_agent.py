import logging
from typing import Any, Optional, List
from pydantic import BaseModel

from .agent import Agent
from ..media.media import Media


logger = logging.getLogger(__name__)
logger.addHandler(logging.NullHandler())

"""
video generator agent
"""

class VideoGeneratorAgent(Agent):

	def __init__(self, **kwargs: Any) -> None:
		super().__init__(**kwargs)


	def run(self, prompt: str, media: Optional[List[Media]] = None, response_model: Optional[BaseModel] = None, **kwargs: Any) -> Any:
		platform=self.platform
		model=self.model
		system_prompt=self.system_prompt

		if media is None:
			return platform.text2video(model=model, prompt=prompt, **kwargs)
		else:
			return platform.image2video(model=model, prompt=prompt, media=media, **kwargs)
