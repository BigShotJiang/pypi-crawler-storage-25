import logging
from urllib.parse import urlparse
from abc import ABC, abstractmethod
from typing import List, Optional, Any
from pydantic import BaseModel

from ..registry import ModelRegistry
from ..model.model import Model
from ..media.image_media import ImageMedia
from ..media.video_media import VideoMedia

logger = logging.getLogger(__name__)
logger.addHandler(logging.NullHandler())


class Platform(ABC):
	"""
	Abstract base class representing a platform for multimodal AI operations.

	This class defines a unified interface for interacting with various AI platforms that support text-to-text, text-to-image, image-to-text, and image-to-image conversions. It handles model resolution via ModelRegistry and delegates platform-specific logic to abstract methods, enabling consistent usage across different providers while allowing custom implementations for each backend.

	The class provides high-level public methods (e.g., text2text, image2image) that resolve models and invoke corresponding protected abstract methods (_text2text, _image2image, etc.). These abstract methods must be implemented by concrete subclasses to support specific AI platforms.

	Each public method invokes ModelRegistry.getModelByName() internally to fetch the appropriate model object for the given platform before calling its private counterpart. This ensures centralized model management and abstraction over platform-specific model representations.

	Concrete implementations are required to define all abstract methods, ensuring complete coverage of the supported modalities and behaviors.

	Concrete subclasses are expected to implement platform-specific behavior while preserving contract guarantees such as returning the correct output types and handling empty media lists (e.g., image2text raises ValueError when media list is empty).

	Methods for structured output (text2text with response_model) delegate to _text2data internally, decoupling structured response handling from plain text flow.
	"""
	def __init__(self, name: str, **kwargs: Any) -> None:
		self._name = name.lower()
		self._host = None


	def platform_name(self) -> str:
		return self._name


	def host_port(self):
		# Prepend 'http://' if missing to make it a valid URL
		s = ""
		if '://' not in self._host:
			s = 'http://' + self._host
		parsed = urlparse(s)
		host = parsed.hostname
		port = parsed.port
		return host, port


	def text2text(self, model: str, prompt: str, response_model: Optional[BaseModel] = None, **kwargs: Any) -> Any:
		"""
        Convert text to text with optional structured output.

        Args:
            model: The model identifier to use
            prompt: The input text prompt
            response_model: Optional Pydantic model for structured output
            **kwargs: Additional platform-specific arguments

        Returns:
            Any: Text response or structured data
        """
		# get the model object for this platform
		platform_model = ModelRegistry.getModelByName(model, self._name)
		if response_model is None:
			return self._text2text(platform_model, prompt, **kwargs)
		# structured data output
		else:
			return self._text2data(platform_model, prompt, response_model=response_model, **kwargs)

	@abstractmethod
	def _text2text(self, model: Model, prompt: str, **kwargs: Any) -> Any:
		"""Platform-specific execution interface for text-to-text conversion"""
		pass

	@abstractmethod
	def _text2data(self, model: Model, prompt: str, response_model: BaseModel, **kwargs: Any) -> Any:
		"""Platform-specific execution interface for text-to-structured data conversion"""
		pass


	def text2image(self, model: str, prompt: str, **kwargs: Any) -> ImageMedia:
		"""
        Convert text to image.

        Args:
            model: The model identifier to use
            prompt: The input text prompt
            **kwargs: Additional platform-specific arguments

        Returns:
            ImageMedia: Generated image media object
        """
		platform_model = ModelRegistry.getModelByName(model, self._name)
		return self._text2image(platform_model, prompt, **kwargs)

	@abstractmethod
	def _text2image(self, model: Model, prompt: str, **kwargs: Any) -> ImageMedia:
		"""Platform-specific execution interface for text-to-image conversion"""
		pass


	def text2video(self, model: str, prompt: str, **kwargs: Any) -> VideoMedia:
		"""
	    Convert text to video.

	    Args:
	        model: The model identifier to use
	        prompt: The input text prompt
	        **kwargs: Additional platform-specific arguments

	    Returns:
	        ImageMedia: Generated image media object
	    """
		platform_model = ModelRegistry.getModelByName(model, self._name)
		return self._text2video(platform_model, prompt, **kwargs)

	@abstractmethod
	def _text2video(self, model: Model, prompt: str, **kwargs: Any) -> VideoMedia:
		"""Platform-specific execution interface for text-to-image conversion"""
		pass


	def image2text(self, model: str, prompt: str, media: List[ImageMedia], response_model: Optional[BaseModel] = None, **kwargs: Any) -> Any:
		"""
        Convert image to text.

        Args:
            model: The model identifier to use
            prompt: The input text prompt guiding the image analysis
            media: List of ImageMedia objects to process
            response_model: Optional Pydantic model for structured output
            **kwargs: Additional platform-specific arguments

        Returns:
            str: Text description or caption of the image(s)

        Raises:
            ValueError: If media list is empty
        """
		platform_model = ModelRegistry.getModelByName(model, self._name)
		if not media:
			raise ValueError("Media list cannot be empty")
		if response_model is None:
			return self._image2text(platform_model, prompt, media, **kwargs)
		# structured data output
		else:
			return self._image2data(platform_model, prompt, media, response_model=response_model, **kwargs)


	@abstractmethod
	def _image2text(self, model: Model, prompt: str, media: List[ImageMedia], **kwargs: Any) -> str:
		"""Platform-specific execution interface for image-to-text conversion"""
		pass

	@abstractmethod
	def _image2data(self, model: Model, prompt: str, media: List[ImageMedia], response_model: BaseModel, **kwargs: Any) -> Any:
		"""Platform-specific execution interface for image-to-text conversion"""
		pass


	def image2image(self, model: str, prompt: str, media: List[ImageMedia], **kwargs: Any) -> ImageMedia:
		"""
        Convert image to image (image editing/transformations).

        Args:
            model: The model identifier to use
            prompt: The input text prompt guiding the transformation
            media: List of ImageMedia objects to process
            **kwargs: Additional platform-specific arguments

        Returns:
            ImageMedia: Transformed image media object
        """
		platform_model = ModelRegistry.getModelByName(model, self._name)
		if not media:
			raise ValueError("Media list cannot be empty")
		return self._image2image(platform_model, prompt, media=media, **kwargs)


	@abstractmethod
	def _image2image(self, model: Model, prompt: str, media: List[ImageMedia], **kwargs: Any) -> ImageMedia:
		"""Platform-specific execution interface for image-to-image conversion"""
		pass


	def image2video(self, model: str, prompt: str, media: List[ImageMedia], **kwargs: Any) -> VideoMedia:
		platform_model = ModelRegistry.getModelByName(model, self._name)
		return self._image2video(platform_model, prompt, media=media, **kwargs)


	@abstractmethod
	def _image2video(self, model: Model, prompt: str, media: List[ImageMedia], **kwargs: Any) -> VideoMedia:
		"""Platform-specific execution interface for image-to-image conversion"""
		pass
