import logging
import requests
from typing import List, Any
from pydantic import BaseModel

from .platform import Platform
from ..model.model import Model
from ..utils.image_utils import aspect_ratio_img_size
from ..media.image_media import ImageMedia
from ..media.video_media import VideoMedia


logger = logging.getLogger(__name__)
logger.addHandler(logging.NullHandler())


class DrawThingsPlatform(Platform):
    """Platform implementation for DrawThings, a text-to-image and image-to-image generation service.

    This class extends the generic Platform interface to provide specific functionality for interacting with the DrawThings API (Stable Diffusion WebUI REST API). It supports converting text prompts into images and transforming existing images based on textual descriptions, leveraging machine learning models hosted via the DrawThings endpoint.

    The platform handles API communication, parameter configuration, error logging, and media conversion between base64-encoded images and ImageMedia objects.
    """
    def __init__(self, host: str = "127.0.0.1:7860", **kwargs: Any) -> None:
        super().__init__('drawthings', **kwargs)
        self._host = host


    def _text2image(self, model: Model, prompt: str, **kwargs: Any) -> ImageMedia:
        payload = model.default_params()
        payload["model"] = model.internal_name()
        payload["prompt"] = prompt
        # manage optional arguments and overide the payload
        if 'steps' in kwargs:
            payload["steps"] = kwargs['steps']
        # aspect ratio as priority to width, height
        if 'ar' in kwargs:
            width, height = aspect_ratio_img_size(kwargs['ar'])
            payload["width"] = width
            payload["height"] = height
        else:
            if 'width' in kwargs:
                payload["width"] = kwargs['width']
            if 'height' in kwargs:
                payload["height"]  = kwargs['height']
        try:
            response = requests.post(f"http://{self._host}/sdapi/v1/txt2img", json=payload)
            response.raise_for_status()
            json_data = response.json()
            base64_string = json_data["images"][0]
            # return the images + save the prompt in the metadata
            return ImageMedia(base64_string, {'Software': f"{self.platform_name()}/{model.name()}", 'Description': prompt})
        except requests.exceptions.HTTPError:
            status = response.status_code
            try:
                error_json = response.json()
                print(f"HTTP {status} error details:", error_json)
            except (ValueError, requests.exceptions.JSONDecodeError):
                print(f"HTTP {status} error (plain text):", response.text)
        except requests.exceptions.RequestException as err:
            print("Request error :", err)
            logging.error("API call failed", exc_info=True)
            raise


    def _text2video(self, model: Model, prompt: str, **kwargs: Any) -> VideoMedia:
        payload = model.default_params()
        payload["model"] = model.internal_name()
        payload["prompt"] = prompt
        # manage optional arguments and overide the payload
        if 'steps' in kwargs:
            payload["steps"] = kwargs['steps']
        if 'num_frames' in kwargs:
            payload["num_frames"] = kwargs['num_frames']
        try:
            response = requests.post(f"http://{self._host}/sdapi/v1/txt2img", json=payload)
            response.raise_for_status()
            json_data = response.json()
            # when using a video model we get a list of base64 frame images
            base64_strings = json_data["images"]
            return base64_strings
        except requests.exceptions.HTTPError:
            status = response.status_code
            try:
                error_json = response.json()
                print(f"HTTP {status} error details:", error_json)
            except (ValueError, requests.exceptions.JSONDecodeError):
                print(f"HTTP {status} error (plain text):", response.text)
        except requests.exceptions.RequestException as err:
            print("Request error :", err)
            logging.error("API call failed", exc_info=True)
            raise


    def _image2image(self, model: Model, prompt: str, media: List[ImageMedia], **kwargs: Any) -> ImageMedia:
        payload = model.default_params()
        payload["model"] = model.internal_name()
        payload["prompt"] = prompt
        # manage optional arguments and overide the payload
        if 'steps' in kwargs:
            payload["steps"] = kwargs['steps']

        first_image = media[0]
        # for image2image it's better to fit the to the nearest 32px size
        first_image.fit_to_nearest_32px()
        # and we need to pass the image size as a parametter
        width, height = first_image.size()
        payload["width"] = width
        payload["height"]  = height

        # encode all images to base64
        base64_image_list = []
        for image in media:
            # convert the image to base64
            base64str = image.to_base64()
            base64_image_list.append(base64str)
        # add the to the payload
        payload["init_images"] = [base64_image_list[0]]
        print(f"Call DT img2img API with {len(base64_image_list)} images")
        try:
            response = requests.post(f"http://{self._host}/sdapi/v1/img2img", json=payload)
            response.raise_for_status()
            json_data = response.json()
            base64_string = json_data["images"][0]
            return ImageMedia(base64_string, {'Software': f"{self.platform_name()}/{model.name()}"})
        except requests.exceptions.HTTPError:
            status = response.status_code
            try:
                error_json = response.json()
                print(f"HTTP {status} error details:", error_json)
            except (ValueError, requests.exceptions.JSONDecodeError):
                print(f"HTTP {status} error (plain text):", response.text)
        except requests.exceptions.RequestException as err:
            print("Request error :", err)
            logging.error("API call failed", exc_info=True)
            raise


    def _image2video(self, model: Model, prompt: str, media: List[ImageMedia], **kwargs: Any):
        """Not implemented yet"""
        pass

    def _text2text(self, model: Model, prompt: str, **kwargs: Any) -> Any:
        """Not supported"""
        pass

    def _text2data(self, model: Model, response_model: BaseModel, prompt: str, **kwargs: Any) -> Any:
        """Not supported"""
        pass

    def _image2text(self, model: Model, prompt: str, image: ImageMedia, **kwargs: Any) -> str:
        """Not supported"""
        pass

    def _image2data(self, model: Model, prompt: str, image: ImageMedia, response_model: BaseModel, **kwargs: Any) -> Any:
        """Not supported"""
        pass
