import logging
from celery import Celery
from typing import List, Any
from pydantic import BaseModel

from .platform import Platform
from ..model.model import Model
from ..utils.image_utils import aspect_ratio_img_size
from ..media.image_media import ImageMedia
from ..media.video_media import VideoMedia


logger = logging.getLogger(__name__)
logger.addHandler(logging.NullHandler())

#
# Experimental Local platform : distributed local workers with Celery and redis
# request are sent to a Redis queue.  First available worker process the request.
#
class LocalPlatform(Platform):

    def __init__(self, host: str = "127.0.0.1:6379", **kwargs: Any) -> None:
        super().__init__('local', **kwargs)
        self._host = host
        self._celery_client = Celery('client_app', broker=f"redis://{host}/0", backend=f"redis://{host}/0")


    def _text2text(self, model: Model, prompt: str, **kwargs: Any) -> str:
        system_prompt = kwargs.get("system_prompt", "")
        result = self._celery_client.send_task('text2text',
                                               args=[model.internal_name(), system_prompt, prompt],
                                               queue='batch_queue')
        output = result.get(timeout=300)

        if output.get('status') == 'success':
            return output.get('answer')
        else:
            print("Error")
            return ""


    def _text2data(self, model: Model, prompt: str, response_model: BaseModel, **kwargs: Any) -> Any:
        system_prompt = kwargs.get("system_prompt", "")
        result = self._celery_client.send_task('text2data',
                                               args=[model.internal_name(), system_prompt, prompt, response_model.model_json_schema()],
                                               queue='batch_queue')
        output = result.get(timeout=300)

        if output.get('status') == 'success':
            return output.get('answer')
        else:
            print("Error")
            return ""


    def _image2text(self, model: Model, prompt: str, media: List[ImageMedia], **kwargs: Any) -> str:
        image = media[0]
        base64_str = image.to_base64()
        result = self._celery_client.send_task('image2text',
                                               args=[model.internal_name(), prompt, base64_str],
                                               queue='batch_queue')
        output = result.get(timeout=300)

        if output.get('status') == 'success':
            return output.get('answer')
        else:
            print("Error")
            return ""


    def _image2data(self, model: Model, prompt: str, media: List[ImageMedia], response_model: BaseModel, **kwargs: Any) -> Any:
        image = media[0]
        base64_str = image.to_base64()
        result = self._celery_client.send_task('image2data',
                                               args=[model.internal_name(), prompt, base64_str, response_model.model_json_schema()],
                                               queue='batch_queue')
        output = result.get(timeout=300)

        if output.get('status') == 'success':
            return output.get('answer')
        else:
            print("Error")
            return ""



    def _text2image(self, model: Model, prompt: str, **kwargs: Any) -> ImageMedia:
        payload = model.default_params()
        steps = payload.get("steps")
        # manage optional arguments and override the payload
        if 'steps' in kwargs:
            payload["steps"] = kwargs['steps']
        # aspect ratio as priority to width, height
        width = 1024
        height = 1024
        if 'ar' in kwargs:
            w, h = aspect_ratio_img_size(kwargs['ar'])
            width = w
            height = h
        else:
            if 'width' in kwargs:
                width = kwargs['width']
            if 'height' in kwargs:
                height  = kwargs['height']

        result = self._celery_client.send_task('text2image',
                                               args=[model.internal_name(), prompt, width, height, steps],
                                               queue='batch_queue')
        try:
            output = result.get(timeout=600)
            if output.get('status') == 'success':
                img = ImageMedia(output.get('image'))
                return img
            else:
                print("Error")
                return None
        except TimeoutError:
            print("Task did not complete within 600 seconds")
            return None

    def _text2video(self, model: Model, prompt: str, **kwargs: Any) -> VideoMedia:
        """Not implemented yet"""
        pass


    def _image2image(self, model: Model, prompt: str, media: List[ImageMedia], **kwargs: Any) -> ImageMedia:
        """Not implemented yet"""
        pass


    def _image2video(self, model: Model, prompt: str, media: List[ImageMedia], **kwargs: Any):
        """Not implemented yet"""
        pass

