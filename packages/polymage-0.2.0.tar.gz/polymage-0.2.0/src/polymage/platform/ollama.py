import json
import logging
import ollama

from pydantic import BaseModel
from typing import Optional, List, Any
from tenacity import retry, stop_after_attempt, retry_if_exception_type

from .platform import Platform
from ..model.model import Model
from ..media.image_media import ImageMedia

logger = logging.getLogger(__name__)
logger.addHandler(logging.NullHandler())


class OllamaPlatform(Platform):
	"""Platform implementation for interacting with Ollama models.

	This class provides concrete implementations of platform methods for text-to-text,
	text-to-data (structured output), and image-to-text operations using the Ollama
	LLM service. It handles client initialization, optional system prompts,
	structured output formatting with retries on JSON parsing failures, and image
	encoding for multimodal inputs. Audio and image generation capabilities are not
	supported and implemented as no-op stubs.
	"""



	def __init__(self, host: str = "127.0.0.1:11434", **kwargs: Any) -> None:
		super().__init__('ollama', **kwargs)
		self._host = host
		self._api_key = "ollama"  # Dummy key (Ollama doesn't require real keys)

	def host(self):
		return self._host



	def _text2text(self, model: Model, prompt: str, **kwargs: Any) -> str:
		print("OllamaPlatform text-to-text")
		system_prompt: Optional[str] = kwargs.get("system_prompt", "")
		client = ollama.Client(host=self._host)
		response = client.chat(
			model=model.internal_name(),
			messages=[
				{"role": "system", "content": system_prompt},
				{"role": "user", "content": prompt}
			],
			options={
				'temperature': kwargs.get('temperature', 0.2),
				# Disable reasoning for models that support thinking (like DeepSeek R1)
				'reasoning_format': 'none',
			}
		)
		return response['message']['content'].strip()

	#
	# using structured data may sometime fail, because the result is not a valid JSON
	# if the JSON is not valid, retry 3 times
	#
	def _text2data(self, model: Model, prompt: str, response_model: BaseModel, **kwargs: Any) -> str:
		print("OllamaPlatform text-to-data")
		system_prompt: Optional[str] = kwargs.get("system_prompt", "")
		client = ollama.Client(host=self._host)

		response = client.chat(
			model=model.internal_name(),
			messages=[
				{"role": "system", "content": system_prompt},
				{"role": "user", "content": prompt}
			],
			format=response_model.model_json_schema(),
			options={
				'temperature': kwargs.get('temperature', 0.2),
			}
		)
		content = response['message']['content'].strip()
		return json.loads(content)


	def _image2text(self, model: Model, prompt: str, media: List[ImageMedia], **kwargs: Any) -> str:
		if len(media) == 0:
			return ""
		else:
			image = media[0]
			base64_image = image.to_base64()

		client = ollama.Client(host=self._host)
		response = client.chat(
			model=model.internal_name(),
			messages=[
				{
					'role': 'user',
					'content': prompt,
					'images': [base64_image],
				}
			],
			options={
				'temperature': kwargs.get('temperature', 0.2),
				# Disable reasoning for models that support thinking (like DeepSeek R1)
				'reasoning_format': 'none',
			}
		)
		return response['message']['content'].strip()


	def _image2data(self, model: Model, prompt: str, media: List[ImageMedia], response_model: BaseModel, **kwargs: Any) -> Any:
		if len(media) == 0:
			return ""
		else:
			image = media[0]
			base64_image = image.to_base64()

		client = ollama.Client(host=self._host)
		response = client.chat(
			model=model.internal_name(),
			messages=[
				{
					'role': 'user',
					'content': prompt,
					'images': [base64_image],
				}
			],
			format=response_model.model_json_schema(),
			options={
				'temperature': kwargs.get('temperature', 0.2),
				# Disable reasoning for models that support thinking (like DeepSeek R1)
				'reasoning_format': 'none',
			}
		)
		content = response['message']['content'].strip()
		return json.loads(content)


	def _text2image(self, model: str, prompt: str, **kwargs: Any) -> ImageMedia:
		"""Not supported"""
		pass


	def _text2video(self, model: Model, prompt: str, **kwargs: Any):
		"""Not supported"""
		pass

	def _image2image(self, model: str, prompt: str, media: List[ImageMedia], **kwargs: Any) -> ImageMedia:
		"""Not supported"""
		pass


	def _image2video(self, model: Model, prompt: str, media: List[ImageMedia], **kwargs: Any):
		"""Not supported"""
		pass
