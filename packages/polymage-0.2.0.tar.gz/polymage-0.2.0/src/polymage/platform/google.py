import logging
from typing import Optional, List, Any, Dict
from pydantic import BaseModel
from google import genai
from google.genai import types

from .platform import Platform
from ..model.model import Model
from ..media.image_media import ImageMedia
from ..media.video_media import VideoMedia

"""
google platform

"""
logger = logging.getLogger(__name__)
logger.addHandler(logging.NullHandler())


class GooglePlatform(Platform):
    """Implementation of the Platform interface for the Google Cloud inference service.

    """

    def __init__(self, api_key: str, **kwargs: Any) -> None:
        super().__init__('google', **kwargs)
        self._api_key = api_key


    def _text2text(self, model: Model, prompt: str, **kwargs: Any) -> str:
        client = genai.Client(api_key=self._api_key)

        response = client.models.generate_content(
            model=model.internal_name(),
            contents=prompt
        )
        return response.text


    def _text2data(self, model: Model, prompt: str, response_model: BaseModel, **kwargs: Any) -> Any:
        """Not implemented yet"""
        pass


    def _image2text(self, model: Model, prompt: str, media: List[ImageMedia], **kwargs: Any) -> str:
        """Not implemented yet"""
        pass


    def _text2image(self, model: Model, prompt: str, **kwargs: Any) -> ImageMedia:
        client = genai.Client(api_key=self._api_key)

        response = client.models.generate_content(
            model=model.internal_name(),
            contents=[prompt],
        )

        for part in response.parts:
            if part.text is not None:
                print(part.text)
            elif part.inline_data is not None:
                image = part.as_image()
                return ImageMedia(image, {'Software': f"{self.platform_name()}/{model.name()}", 'Description': prompt})

    def _text2video(self, model: Model, prompt: str, **kwargs: Any) -> VideoMedia:
        """Not supported"""
        pass


    def _image2image(self, model: Model, prompt: str, media: List[ImageMedia], **kwargs: Any) -> ImageMedia:
        client = genai.Client(api_key=self._api_key)

        image = media[0].to_pil_image()

        response = client.models.generate_content(
            model=model.internal_name(),
            contents=[prompt, image],
        )

        for part in response.parts:
            if part.text is not None:
                print(part.text)
            elif part.inline_data is not None:
                image = part.as_image()
                return ImageMedia(image, {'Software': f"{self.platform_name()}/{model.name()}"})


    def _image2video(self, model: Model, prompt: str, media: List[ImageMedia], **kwargs: Any) -> VideoMedia:
        """Not supported"""
        pass

