# image_media.py
import cv2
import base64
import logging
import numpy as np
from typing import Optional, Dict, Any, Union, List

from .media import Media

logger = logging.getLogger(__name__)
logger.addHandler(logging.NullHandler())


def image_from_base64(base64_string: str):
    decoded_data = base64.b64decode(base64_string)
    # Convert bytes to numpy array
    nparr = np.frombuffer(decoded_data, np.uint8)
    # Decode the image using OpenCV
    img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
    return img


class VideoMedia(Media):

    def __init__(self, metadata: Optional[Dict[str, Any]] = None, **kwargs: Any) -> None:
        self._metadata = metadata


    @classmethod
    def save_to_file(cls, base64_image_list: List[str], fps: int, filepath: str) -> None:
        print(f"Get a list of {len(base64_image_list)} images")
        
        # get the size of the first image
        base64_string = base64_image_list[0]
        img = image_from_base64(base64_string)
        
        # Grab dimensions from the first image
        height, width, layers = img.shape
    
        # Define the codec and create VideoWriter object
        # 'mp4v' is widely supported for .mp4 files
        out = cv2.VideoWriter(filepath, cv2.VideoWriter_fourcc(*'mp4v'), fps, (width, height))

        # loop on the base64 image list
        for base64str in base64_image_list:
            img = image_from_base64(base64str)
            # write image to video file
            out.write(img)

        out.release()
        print(f"Video saved as {filepath}")


