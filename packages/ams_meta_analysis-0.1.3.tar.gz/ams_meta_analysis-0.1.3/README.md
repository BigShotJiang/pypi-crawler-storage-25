# Meta-Analysis Streamlit App

An installable Streamlit GUI for the R-backed Python meta-analysis runners in
`/Volumes/Firecuda-4TB/R-code_to-python`.

The original source directory is treated as read-only. The runner files were
copied into this package under `meta_analysis_streamlit/runners/` so the app can
be installed and launched without editing the source folder.

## What It Runs

- Workbook-level auto routing through the original `main.py`
- Binary pairwise meta-analysis
- Continuous pairwise meta-analysis
- Single-arm proportion and mean meta-analysis
- Diagnostic accuracy meta-analysis
- Frequentist and Bayesian network meta-analysis
- LM Studio model detection, with manual study-characteristic controls when LM
  Studio is not reachable

## Install

From PyPI after the first release:

```bash
python3 -m pip install ams-meta_analysis
ams-meta_analysis
```

From this folder:

```bash
python3 -m pip install -e ".[dev]"
```

For a normal local wheel install:

```bash
python3 -m pip install .
```

Launch the GUI:

```bash
ams-meta_analysis
```

Run the original workbook orchestrator from the installed package:

```bash
meta-analysis-runner "/path/to/workbook.xlsx" --yes
```

Check the local environment:

```bash
meta-analysis-doctor
```

## External Requirements

Python dependencies are installed by `pip`, but the statistical analyses still
need R and the R packages used by the original generated scripts.

Install R, make sure `Rscript` is on `PATH`, then install the common R packages:

```r
install.packages(c(
  "meta",
  "metafor",
  "readxl",
  "dplyr",
  "ggplot2",
  "netmeta",
  "gemtc",
  "rjags",
  "RTSA"
))
```

Bayesian network meta-analysis also needs JAGS installed on the system.

Trial sequential analysis can use the external TSA engine expected by the
original code. If needed, point to it with:

```bash
export TSA_ANALYSIS_PY="/path/to/tsa_analysis.py"
```

## LLM Provider Behavior

By default, the app checks `http://localhost:1234/v1` for LM Studio. If LM
Studio is not available, it can use OpenAI-compatible hosted APIs instead.

Supported GUI options:

- LM Studio: `http://localhost:1234/v1`
- OpenAI: `https://api.openai.com/v1`
- Gemini through Google's OpenAI-compatible endpoint:
  `https://generativelanguage.googleapis.com/v1beta/openai`
- Custom OpenAI-compatible endpoint
- Manual/no LLM

The app auto-selects the first available option in this order: LM Studio,
`OPENAI_API_KEY`, `GEMINI_API_KEY` or `GOOGLE_API_KEY`,
`META_ANALYSIS_LLM_API_KEY`, then manual mode.

For command-line runs, hosted APIs can also be used with the original
`--lmstudio-url` option because the packaged runners now support
OpenAI-compatible authentication headers:

```bash
export META_ANALYSIS_LLM_API_KEY="$OPENAI_API_KEY"
meta-analysis-runner "/path/to/workbook.xlsx" \
  --lmstudio-url "https://api.openai.com/v1" \
  --model "your-model" \
  --yes
```

For Gemini:

```bash
export META_ANALYSIS_LLM_API_KEY="$GEMINI_API_KEY"
meta-analysis-runner "/path/to/workbook.xlsx" \
  --lmstudio-url "https://generativelanguage.googleapis.com/v1beta/openai" \
  --model "your-gemini-model" \
  --yes
```

When no provider is reachable, the GUI still works: it passes `--no-lmstudio`
and asks you to choose basic study characteristics such as analysis route,
binary effect size, single-arm outcome type, diagnostic mode, and network model
settings.

## Output Location

Uploaded workbooks and generated outputs are staged under:

```text
~/.meta_analysis_streamlit/runs/
```

The app writes a run log and offers a zip download for completed outputs.

## Development

Run the tests:

```bash
pytest
```

Build a wheel:

```bash
python3 -m build
python3 -m twine check dist/*
```

See [PUBLISHING.md](PUBLISHING.md) for PyPI release steps, including Trusted
Publishing through GitHub Actions.

The project is ready to commit and push from
`/Volumes/Firecuda-4TB/meta-streamlit-app`.
