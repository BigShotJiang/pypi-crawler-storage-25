from __future__ import annotations

from pathlib import Path

import pandas as pd


def test_runner_scripts_are_packaged() -> None:
    import meta_analysis_streamlit.runner as runner

    runners = runner.runners_dir()
    assert (runners / "main.py").exists()
    assert (runners / "binary_outcome.py").exists()
    assert (runners / "continuous_outcome.py").exists()


def test_lmstudio_url_generation() -> None:
    from meta_analysis_streamlit.app import lmstudio_models_url

    assert lmstudio_models_url("http://localhost:1234/v1") == [
        "http://localhost:1234/v1/models",
        "http://localhost:1234/api/v0/models",
    ]


def test_openai_compatible_url_generation() -> None:
    from meta_analysis_streamlit.app import openai_compatible_models_url
    from meta_analysis_streamlit.runners.binary_outcome import chat_completions_url, models_url

    gemini_base = "https://generativelanguage.googleapis.com/v1beta/openai"
    assert openai_compatible_models_url("https://api.openai.com/v1") == "https://api.openai.com/v1/models"
    assert models_url(gemini_base) == f"{gemini_base}/models"
    assert chat_completions_url(gemini_base) == f"{gemini_base}/chat/completions"


def test_runner_auth_headers(monkeypatch) -> None:
    from meta_analysis_streamlit.runners.binary_outcome import llm_request_headers

    monkeypatch.setenv("META_ANALYSIS_LLM_API_KEY", "secret")
    assert llm_request_headers(include_content_type=True) == {
        "Content-Type": "application/json",
        "Authorization": "Bearer secret",
    }


def test_cli_entrypoint_points_at_app() -> None:
    import meta_analysis_streamlit.cli as cli

    app_path = Path(cli.__file__).with_name("app.py")
    assert app_path.exists()


def test_binary_route_uses_specialized_single_sheet_runner(tmp_path) -> None:
    from meta_analysis_streamlit.app import build_command

    command = build_command(
        input_path=tmp_path / "workbook.xlsx",
        output_root=tmp_path / "outputs",
        route="Binary pairwise",
        selected_sheets=["Outcome A"],
        outcome_name="Outcome A",
        lmstudio_enabled=False,
        lmstudio_url="http://localhost:1234/v1",
        model_id="",
        binary_effect_size="RR",
        network_engine="frequentist",
        network_effect="auto",
        network_model="random",
        single_arm_type="auto",
        diagnostic_mode="single",
        jobs=1,
        dry_run=False,
        install_r_packages=False,
    )

    assert any(part.endswith("binary_outcome.py") for part in command)
    assert "--sheet" in command
    assert "Outcome A" in command
    assert "--sheets" not in command
    assert "--no-lmstudio" in command


def test_auto_route_can_select_all_sheets(tmp_path) -> None:
    from meta_analysis_streamlit.app import build_command

    command = build_command(
        input_path=tmp_path / "workbook.xlsx",
        output_root=tmp_path / "outputs",
        route="Auto route workbook",
        selected_sheets=["Outcome A", "Outcome B"],
        outcome_name="",
        lmstudio_enabled=False,
        lmstudio_url="http://localhost:1234/v1",
        model_id="",
        binary_effect_size="auto",
        network_engine="frequentist",
        network_effect="auto",
        network_model="random",
        single_arm_type="auto",
        diagnostic_mode="single",
        jobs=1,
        dry_run=False,
        install_r_packages=False,
        analyze_all_sheets=True,
    )

    assert any(part.endswith("main.py") for part in command)
    assert "--all-sheets" in command
    assert "--sheets" not in command


def test_auto_group_suggestions_skip_study_identifier() -> None:
    from meta_analysis_streamlit.app import auto_group_columns

    df = pd.DataFrame(
        {
            "Study": ["A", "B", "C", "D"],
            "Etiology": ["Malignant", "Benign", "Malignant", "Benign"],
            "Events": [1, 2, 3, 4],
        }
    )

    assert auto_group_columns(df, list(df.columns)) == ["Etiology"]


def test_auto_route_filters_missing_column_overrides() -> None:
    import argparse
    import sys

    runners = Path(__file__).resolve().parents[1] / "meta_analysis_streamlit" / "runners"
    sys.path.insert(0, str(runners))
    import main as main_runner

    item = main_runner.PlannedAnalysis(
        index=2,
        sheet="Clinical success",
        rows=21,
        columns=["Study", "Etiology", "Control type", "clinical_success_definition_regressor"],
        outcome_name="Clinical success",
        analysis_type="binary_pairwise",
    )
    args = argparse.Namespace(
        yes=True,
        no_lmstudio=True,
        lmstudio_url="http://localhost:1234/v1",
        model="",
        group_column="Study",
        subgroup_columns="Study,Etiology,adverse_event_definition_regressor",
        covariate_columns="clinical_success_definition_regressor,adverse_event_definition_regressor",
        network_engine="frequentist",
        rank_sims=100000,
        install_r_packages=False,
    )

    command = main_runner.runner_command(item, Path("book.xlsx"), Path("outputs"), args)

    assert command is not None
    assert "--subgroup-columns" in command
    assert command[command.index("--subgroup-columns") + 1] == "Study,Etiology"
    assert "--covariate-columns" in command
    assert command[command.index("--covariate-columns") + 1] == "clinical_success_definition_regressor"
    assert "adverse_event_definition_regressor" not in command
