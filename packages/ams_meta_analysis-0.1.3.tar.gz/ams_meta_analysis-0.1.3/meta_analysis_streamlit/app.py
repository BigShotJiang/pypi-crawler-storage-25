"""Streamlit front end for the meta-analysis runner toolkit."""

from __future__ import annotations

import json
import os
import queue
import re
import signal
import shutil
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
import zipfile
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

import pandas as pd
import streamlit as st


APP_HOME = Path.home() / ".meta_analysis_streamlit"
RUNS_HOME = APP_HOME / "runs"
SUPPORTED_INPUTS = {".csv", ".xls", ".xlsx", ".xlsm"}


@dataclass
class LmStudioStatus:
    available: bool
    models: list[str]
    message: str


PROVIDER_DEFAULTS = {
    "LM Studio": {
        "base_url": "http://localhost:1234/v1",
        "key_envs": [],
        "auth_header": "Authorization",
        "auth_prefix": "Bearer",
    },
    "OpenAI": {
        "base_url": "https://api.openai.com/v1",
        "key_envs": ["OPENAI_API_KEY"],
        "auth_header": "Authorization",
        "auth_prefix": "Bearer",
    },
    "Gemini": {
        "base_url": "https://generativelanguage.googleapis.com/v1beta/openai",
        "key_envs": ["GEMINI_API_KEY", "GOOGLE_API_KEY"],
        "auth_header": "Authorization",
        "auth_prefix": "Bearer",
    },
    "Custom OpenAI-compatible": {
        "base_url": os.environ.get("OPENAI_BASE_URL", "https://api.openai.com/v1"),
        "key_envs": ["META_ANALYSIS_LLM_API_KEY", "OPENAI_API_KEY"],
        "auth_header": "Authorization",
        "auth_prefix": "Bearer",
    },
    "Manual/no LLM": {
        "base_url": "",
        "key_envs": [],
        "auth_header": "Authorization",
        "auth_prefix": "Bearer",
    },
}


def runners_dir() -> Path:
    return Path(__file__).resolve().parent / "runners"


def runner_script(name: str) -> Path:
    return runners_dir() / name


def apply_theme() -> None:
    st.markdown(
        """
        <style>
        :root {
            --ma-bg: #f7f8fb;
            --ma-panel: #ffffff;
            --ma-border: #d9dee8;
            --ma-text: #18202f;
            --ma-muted: #5f6b7a;
            --ma-accent: #1677c8;
            --ma-accent-soft: #e8f3fc;
            --ma-good: #167c55;
            --ma-warn: #9a5b00;
            --ma-bad: #b42318;
        }
        .stApp {
            background:
                linear-gradient(180deg, #f7f9fc 0%, #f3f6fa 260px, #f7f8fb 100%);
            color: var(--ma-text);
        }
        .block-container {
            padding-top: 1.8rem;
            padding-bottom: 3rem;
            max-width: 1280px;
        }
        [data-testid="stSidebar"] {
            background: #101827;
        }
        [data-testid="stSidebar"] * {
            color: #edf2f7;
        }
        [data-testid="stSidebar"] .stTextInput input,
        [data-testid="stSidebar"] .stSelectbox div[data-baseweb="select"] > div,
        [data-testid="stSidebar"] textarea {
            background: #172235;
            border-color: #31435f;
            color: #ffffff;
        }
        [data-testid="stSidebar"] code {
            color: #dce8f7;
        }
        [data-testid="stAppViewContainer"] [data-testid="stWidgetLabel"] p,
        [data-testid="stAppViewContainer"] label,
        [data-testid="stAppViewContainer"] .stMarkdown p {
            color: #233044;
        }
        [data-testid="stSidebar"] [data-testid="stWidgetLabel"] p,
        [data-testid="stSidebar"] label,
        [data-testid="stSidebar"] .stMarkdown p {
            color: #edf2f7;
        }
        [data-testid="stAppViewContainer"] div[data-testid="stButton"] button {
            background: #ffffff;
            color: #172235 !important;
            border: 1px solid #b7c2d4;
            border-radius: 7px;
            min-height: 3.2rem;
            font-weight: 700;
            box-shadow: 0 1px 2px rgba(24, 32, 47, 0.08);
        }
        div[data-testid="stButton"] button p,
        div[data-testid="stButton"] button span {
            color: inherit !important;
        }
        [data-testid="stAppViewContainer"] div[data-testid="stButton"] button:hover {
            background: #eef6ff;
            border-color: var(--ma-accent);
            color: #0f4f86 !important;
        }
        [data-testid="stAppViewContainer"] div[data-testid="stButton"] button:disabled,
        [data-testid="stSidebar"] div[data-testid="stButton"] button:disabled {
            background: #e5eaf2 !important;
            color: #536071 !important;
            border-color: #c2cad8 !important;
            opacity: 1 !important;
            box-shadow: none;
        }
        [data-testid="stSidebar"] div[data-testid="stButton"] button {
            background: #f8fafc;
            color: #101827 !important;
            border: 1px solid #c7d2e0;
            border-radius: 7px;
            min-height: 2.8rem;
            font-weight: 700;
        }
        [data-testid="stSidebar"] div[data-testid="stButton"] button:hover {
            background: #e8f3fc;
            color: #0f4f86 !important;
            border-color: #8abce6;
        }
        .ma-hero {
            border: 1px solid var(--ma-border);
            background: rgba(255, 255, 255, 0.92);
            padding: 1.15rem 1.25rem;
            border-radius: 8px;
            box-shadow: 0 10px 30px rgba(24, 32, 47, 0.08);
            margin-bottom: 1.1rem;
        }
        .ma-kicker {
            color: var(--ma-accent);
            font-size: 0.78rem;
            font-weight: 700;
            letter-spacing: 0;
            text-transform: uppercase;
            margin-bottom: 0.2rem;
        }
        .ma-hero h1 {
            font-size: 2rem;
            line-height: 1.15;
            margin: 0;
            letter-spacing: 0;
        }
        .ma-hero p {
            color: var(--ma-muted);
            margin: 0.45rem 0 0;
            max-width: 850px;
        }
        .ma-strip {
            display: grid;
            gap: 0.75rem;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            margin: 0.8rem 0 1.1rem;
        }
        .ma-stat {
            border: 1px solid var(--ma-border);
            background: var(--ma-panel);
            border-radius: 8px;
            padding: 0.8rem 0.9rem;
        }
        .ma-stat span {
            display: block;
            color: var(--ma-muted);
            font-size: 0.78rem;
            margin-bottom: 0.2rem;
        }
        .ma-stat strong {
            display: block;
            font-size: 1rem;
            font-weight: 700;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .ma-badge {
            display: inline-flex;
            align-items: center;
            border-radius: 999px;
            padding: 0.2rem 0.55rem;
            font-size: 0.78rem;
            font-weight: 700;
            border: 1px solid var(--ma-border);
            background: var(--ma-accent-soft);
            color: #115a96;
        }
        .ma-badge.good { background: #e9f8f1; color: var(--ma-good); border-color: #bce6d3; }
        .ma-badge.warn { background: #fff5e5; color: var(--ma-warn); border-color: #f2d199; }
        .ma-badge.bad { background: #fff0ee; color: var(--ma-bad); border-color: #f3b9b3; }
        div[data-testid="stButton"] button[kind="primary"] {
            background: var(--ma-accent);
            border-color: var(--ma-accent);
            color: #ffffff !important;
            border-radius: 7px;
            font-weight: 700;
        }
        div[data-testid="stButton"] button[kind="primary"]:hover {
            background: #0f5f9f;
            border-color: #0f5f9f;
            color: #ffffff !important;
        }
        div[data-testid="stTabs"] button {
            font-weight: 650;
        }
        @media (max-width: 900px) {
            .ma-strip { grid-template-columns: repeat(2, minmax(0, 1fr)); }
            .ma-hero h1 { font-size: 1.55rem; }
        }
        </style>
        """,
        unsafe_allow_html=True,
    )


def render_header() -> None:
    st.markdown(
        """
        <div class="ma-hero">
          <div class="ma-kicker">Evidence synthesis workspace</div>
          <h1>Meta-Analysis Runner</h1>
          <p>Upload a workbook, route outcomes, choose model assistance, and run the packaged R-backed Python pipeline from one focused interface.</p>
        </div>
        """,
        unsafe_allow_html=True,
    )


def badge(label: str, tone: str = "") -> str:
    class_name = f"ma-badge {tone}".strip()
    return f'<span class="{class_name}">{label}</span>'


def render_run_summary(
    *,
    provider: str,
    status: LmStudioStatus,
    rscript: str | None,
    selected_sheets: list[str],
    route: str,
) -> None:
    llm_tone = "good" if status.available else "warn"
    r_tone = "good" if rscript else "bad"
    llm_label = "Available" if status.available else "Manual"
    r_label = "Ready" if rscript else "Missing"
    st.markdown(
        f"""
        <div class="ma-strip">
          <div class="ma-stat"><span>LLM provider</span><strong>{provider}</strong></div>
          <div class="ma-stat"><span>LLM status</span><strong>{badge(llm_label, llm_tone)}</strong></div>
          <div class="ma-stat"><span>R runtime</span><strong>{badge(r_label, r_tone)}</strong></div>
          <div class="ma-stat"><span>Run scope</span><strong>{len(selected_sheets)} sheet(s), {route}</strong></div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_active_job_banner(location: str) -> None:
    job = st.session_state.get("analysis_job")
    if not job:
        return
    poll_background_job(job)
    running = process_running(job)
    elapsed = max(0, int(time.time() - float(job["started_at"])))
    output_root = Path(job["output_root"])
    if running:
        status_col, action_col = st.columns([0.78, 0.22])
        with status_col:
            st.warning(
                f"Analysis is running ({elapsed}s). If it is waiting on LM Studio or another LLM provider, "
                f"use Stop Analysis to terminate the runner. Output folder: {output_root}"
            )
        with action_col:
            if st.button("Stop Analysis", key=f"stop_analysis_{location}", use_container_width=True):
                stop_background_job(job)
                poll_background_job(job)
                st.rerun()
    elif job.get("returncode") == 0 and not job.get("stopped"):
        st.success(f"Last analysis finished. Outputs are in {output_root}")
    else:
        st.error(f"Last analysis stopped or failed with exit code {job.get('returncode')}.")


def lmstudio_models_url(base_url: str) -> list[str]:
    base = base_url.rstrip("/")
    urls: list[str] = []
    if base.endswith("/v1"):
        urls.append(f"{base}/models")
        urls.append(f"{base[:-3].rstrip('/')}/api/v0/models")
    else:
        urls.append(f"{base}/v1/models")
        urls.append(f"{base}/api/v0/models")
    return urls


def api_key_from_env(provider: str) -> str:
    for env_name in PROVIDER_DEFAULTS[provider]["key_envs"]:
        value = os.environ.get(env_name)
        if value:
            return value
    return ""


def request_headers(api_key: str, auth_header: str = "Authorization", auth_prefix: str = "Bearer") -> dict[str, str]:
    if not api_key:
        return {}
    return {auth_header: f"{auth_prefix} {api_key}" if auth_prefix else api_key}


def openai_compatible_models_url(base_url: str) -> str:
    base = base_url.rstrip("/")
    if base.endswith("/models"):
        return base
    return f"{base}/models" if base.endswith("/v1") or base.endswith("/openai") else f"{base}/v1/models"


@st.cache_data(ttl=20, show_spinner=False)
def check_lmstudio(base_url: str) -> LmStudioStatus:
    errors: list[str] = []
    for url in lmstudio_models_url(base_url):
        try:
            request = urllib.request.Request(url, method="GET")
            with urllib.request.urlopen(request, timeout=2) as response:
                payload = json.loads(response.read().decode("utf-8"))
            data = payload.get("data", payload if isinstance(payload, list) else [])
            models = []
            for item in data:
                if isinstance(item, dict):
                    model_id = item.get("id") or item.get("model_key") or item.get("path")
                    if model_id:
                        models.append(str(model_id))
            return LmStudioStatus(True, models, f"Connected to {url}")
        except (urllib.error.URLError, TimeoutError, OSError, json.JSONDecodeError) as exc:
            errors.append(f"{url}: {exc}")
    return LmStudioStatus(False, [], "; ".join(errors) if errors else "No LM Studio response")


def check_openai_compatible(base_url: str, api_key: str, auth_header: str, auth_prefix: str) -> LmStudioStatus:
    url = openai_compatible_models_url(base_url)
    try:
        request = urllib.request.Request(
            url,
            headers=request_headers(api_key, auth_header, auth_prefix),
            method="GET",
        )
        with urllib.request.urlopen(request, timeout=5) as response:
            payload = json.loads(response.read().decode("utf-8"))
        data = payload.get("data", payload if isinstance(payload, list) else [])
        models = []
        for item in data:
            if isinstance(item, dict):
                model_id = item.get("id") or item.get("name") or item.get("model")
                if model_id:
                    models.append(str(model_id))
        return LmStudioStatus(True, models, f"Connected to {url}")
    except (urllib.error.URLError, TimeoutError, OSError, json.JSONDecodeError) as exc:
        return LmStudioStatus(False, [], f"Not reachable at {url}: {exc}")


@st.cache_data(show_spinner=False)
def workbook_overview(path: str) -> dict[str, dict[str, Any]]:
    workbook = Path(path)
    if workbook.suffix.lower() == ".csv":
        df = pd.read_csv(workbook)
        df.columns = [str(col) for col in df.columns]
        return {
            workbook.stem: {
                "rows": int(len(df)),
                "columns": list(df.columns),
                "preview": df.head(25),
            }
        }

    excel = pd.ExcelFile(workbook)
    overview: dict[str, dict[str, Any]] = {}
    for sheet in excel.sheet_names:
        preview = pd.read_excel(workbook, sheet_name=sheet, nrows=25)
        preview.columns = [str(col) for col in preview.columns]
        row_count = int(pd.read_excel(workbook, sheet_name=sheet, usecols=[0]).shape[0])
        overview[sheet] = {
            "rows": row_count,
            "columns": list(preview.columns),
            "preview": preview,
        }
    return overview


def save_upload(uploaded_file: Any) -> Path:
    suffix = Path(uploaded_file.name).suffix.lower()
    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    run_dir = RUNS_HOME / f"{Path(uploaded_file.name).stem}-{timestamp}"
    run_dir.mkdir(parents=True, exist_ok=True)
    destination = run_dir / uploaded_file.name
    destination.write_bytes(uploaded_file.getbuffer())
    return destination


def choose_output_directory(initial_dir: Path) -> str | None:
    """Open a native folder chooser when the app is running locally."""

    initial_dir = initial_dir.expanduser().resolve()
    if sys.platform == "darwin" and shutil.which("osascript"):
        script = (
            'POSIX path of (choose folder with prompt "Choose an output folder" '
            f'default location POSIX file "{initial_dir}/")'
        )
        completed = subprocess.run(
            ["osascript", "-e", script],
            capture_output=True,
            text=True,
            check=False,
        )
        if completed.returncode == 0:
            selected = completed.stdout.strip()
            return selected or None
        return None

    try:
        import tkinter as tk
        from tkinter import filedialog

        root = tk.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        selected = filedialog.askdirectory(
            title="Choose an output folder",
            initialdir=str(initial_dir),
        )
        root.destroy()
        return selected or None
    except Exception:
        return None


def format_command(command: list[str]) -> str:
    return " ".join(f'"{part}"' if " " in part else part for part in command)


def enqueue_output(stream: Any, output_queue: queue.Queue[str]) -> None:
    for line in iter(stream.readline, ""):
        output_queue.put(line)
    stream.close()


def process_running(job: dict[str, Any] | None) -> bool:
    if not job:
        return False
    process = job.get("process")
    return bool(process and process.poll() is None)


def start_background_job(command: list[str], env: dict[str, str], output_root: Path) -> dict[str, Any]:
    output_queue: queue.Queue[str] = queue.Queue()
    process = subprocess.Popen(
        command,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1,
        env=env,
        start_new_session=os.name != "nt",
    )
    assert process.stdout is not None
    thread = threading.Thread(target=enqueue_output, args=(process.stdout, output_queue), daemon=True)
    thread.start()
    return {
        "process": process,
        "thread": thread,
        "queue": output_queue,
        "lines": [],
        "command": command,
        "output_root": output_root,
        "started_at": time.time(),
        "returncode": None,
        "log_written": False,
        "stopped": False,
    }


def poll_background_job(job: dict[str, Any]) -> None:
    output_queue: queue.Queue[str] = job["queue"]
    while not output_queue.empty():
        job["lines"].append(output_queue.get())
    process = job["process"]
    if process.poll() is not None:
        job["returncode"] = int(process.returncode or 0)
        if not job["log_written"]:
            output_root = Path(job["output_root"])
            output_root.mkdir(parents=True, exist_ok=True)
            (output_root / "streamlit-run.log").write_text("".join(job["lines"]), encoding="utf-8")
            job["log_written"] = True


def stop_background_job(job: dict[str, Any]) -> None:
    process = job["process"]
    if process.poll() is not None:
        return
    job["stopped"] = True
    try:
        if os.name != "nt":
            os.killpg(process.pid, signal.SIGTERM)
        else:
            process.terminate()
        process.wait(timeout=3)
    except subprocess.TimeoutExpired:
        if os.name != "nt":
            os.killpg(process.pid, signal.SIGKILL)
        else:
            process.kill()
    except ProcessLookupError:
        pass


def render_job_controls(output_root: Path) -> None:
    job = st.session_state.get("analysis_job")
    if not job:
        return
    poll_background_job(job)
    elapsed = max(0, int(time.time() - float(job["started_at"])))
    running = process_running(job)
    status_label = "Running" if running else "Stopped" if job.get("stopped") else "Finished"
    st.subheader("Run Log")
    st.caption(f"{status_label} for {elapsed}s. Log file: {Path(job['output_root']) / 'streamlit-run.log'}")
    st.code("".join(job["lines"][-250:]) or "Starting analysis...", language="text")
    if running:
        if st.button("Stop Analysis", type="secondary", key="stop_analysis_log"):
            stop_background_job(job)
            poll_background_job(job)
            st.rerun()
        time.sleep(1)
        st.rerun()
    elif job.get("returncode") == 0 and not job.get("stopped"):
        st.success(f"Analysis finished. Outputs are in {job['output_root']}")
        archive = zip_directory(Path(job["output_root"]))
        with archive.open("rb") as handle:
            st.download_button("Download output zip", handle, file_name=archive.name)
        if st.button("Clear Run Log"):
            st.session_state.pop("analysis_job", None)
            st.rerun()
    else:
        st.error(f"Analysis stopped or failed with exit code {job.get('returncode')}.")
        if st.button("Clear Run Log"):
            st.session_state.pop("analysis_job", None)
            st.rerun()


def zip_directory(directory: Path) -> Path:
    archive = directory.with_suffix(".zip")
    if archive.exists():
        archive.unlink()
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as zf:
        for path in directory.rglob("*"):
            if path.is_file() and path != archive:
                zf.write(path, path.relative_to(directory))
    return archive


def default_provider() -> str:
    lmstudio = check_lmstudio(os.environ.get("LMSTUDIO_URL", "http://localhost:1234/v1"))
    if lmstudio.available:
        return "LM Studio"
    if os.environ.get("OPENAI_API_KEY"):
        return "OpenAI"
    if os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY"):
        return "Gemini"
    if os.environ.get("META_ANALYSIS_LLM_API_KEY"):
        return "Custom OpenAI-compatible"
    return "Manual/no LLM"


def normalize_column_name(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", str(value).lower())


def unique_existing(values: list[str], columns: list[str]) -> list[str]:
    selected: list[str] = []
    for value in values:
        if value in columns and value not in selected:
            selected.append(value)
    return selected


def auto_group_columns(df: pd.DataFrame, columns: list[str]) -> list[str]:
    outcome_terms = (
        "event", "events", "total", "sample", "number", "count", "n", "mean", "sd",
        "se", "ci", "lower", "upper", "effect", "risk", "ratio", "or", "rr", "hr",
        "tp", "fp", "tn", "fn", "sensitivity", "specificity", "auc", "pvalue",
    )
    identifier_terms = ("study", "author", "citation", "reference", "trialid", "studyid")
    group_terms = (
        "subgroup", "group", "category", "class", "classification", "type", "arm",
        "treatment", "intervention", "control", "comparator", "etiology", "aetiology",
        "region", "country", "setting", "center", "centre", "design", "severity",
        "stage", "riskstrata", "riskgroup",
    )
    scored: list[tuple[int, str]] = []
    for column in columns:
        norm = normalize_column_name(column)
        if any(term in norm for term in identifier_terms):
            continue
        if any(norm == term or norm.endswith(term) for term in ("n", "sd", "se")):
            continue
        series = df[column] if column in df else pd.Series(dtype=object)
        non_missing = series.dropna()
        unique_count = int(non_missing.nunique(dropna=True))
        if unique_count < 2:
            continue
        numeric = pd.to_numeric(non_missing, errors="coerce")
        numeric_ratio = float(numeric.notna().mean()) if len(non_missing) else 0.0
        low_cardinality = unique_count <= max(8, int(len(non_missing) * 0.55))
        has_group_hint = any(term in norm for term in group_terms)
        has_outcome_hint = any(term in norm for term in outcome_terms)
        if has_group_hint or (low_cardinality and numeric_ratio < 0.65 and not has_outcome_hint):
            score = 0
            if "subgroup" in norm:
                score += 5
            if has_group_hint:
                score += 3
            if not has_outcome_hint:
                score += 2
            if low_cardinality:
                score += 1
            scored.append((score, column))
    return [column for _, column in sorted(scored, key=lambda item: (-item[0], columns.index(item[1])))]


def auto_meta_regressor_columns(df: pd.DataFrame, columns: list[str], subgroup_columns: list[str]) -> list[str]:
    excluded_terms = (
        "event", "events", "total", "count", "mean", "median", "sd", "se", "ci",
        "lower", "upper", "effect", "ratio", "or", "rr", "hr", "tp", "fp", "tn",
        "fn", "sensitivity", "specificity", "auc", "pvalue",
    )
    moderator_terms = (
        "regressor", "covariate", "moderator", "age", "bmi", "year", "followup",
        "follow", "duration", "month", "size", "sample", "male", "female", "sex",
        "percent", "percentage", "proportion", "dose", "baseline", "severity",
        "score", "region", "country", "design", "etiology", "aetiology", "type",
    )
    selected_subgroups = set(subgroup_columns)
    scored: list[tuple[int, str]] = []
    for column in columns:
        if column in selected_subgroups:
            continue
        norm = normalize_column_name(column)
        if any(term in norm for term in excluded_terms) and not any(
            term in norm for term in ("regressor", "covariate", "moderator", "age", "bmi", "year", "followup", "duration")
        ):
            continue
        series = df[column] if column in df else pd.Series(dtype=object)
        non_missing = series.dropna()
        if int(non_missing.nunique(dropna=True)) < 2:
            continue
        numeric = pd.to_numeric(non_missing, errors="coerce")
        numeric_ratio = float(numeric.notna().mean()) if len(non_missing) else 0.0
        has_moderator_hint = any(term in norm for term in moderator_terms)
        if numeric_ratio >= 0.75 or has_moderator_hint:
            score = 0
            if any(term in norm for term in ("regressor", "covariate", "moderator")):
                score += 5
            if has_moderator_hint:
                score += 3
            if numeric_ratio >= 0.75:
                score += 2
            scored.append((score, column))
    return [column for _, column in sorted(scored, key=lambda item: (-item[0], columns.index(item[1])))]


def comma_join(values: list[str]) -> str:
    return ",".join(value for value in values if value)


def append_column_overrides(
    command: list[str],
    *,
    route: str,
    group_column: str,
    subgroup_columns: list[str],
    meta_regressor_columns: list[str],
) -> None:
    supports_subgroups = route in {
        "Auto route workbook",
        "Binary pairwise",
        "Continuous pairwise",
        "Single-arm",
    }
    supports_meta_regression = route in {
        "Auto route workbook",
        "Binary pairwise",
        "Continuous pairwise",
    }
    if supports_subgroups:
        if group_column:
            command += ["--group-column", group_column]
        if subgroup_columns:
            command += ["--subgroup-columns", comma_join(subgroup_columns)]
    if supports_meta_regression and meta_regressor_columns:
        command += ["--covariate-columns", comma_join(meta_regressor_columns)]


def build_command(
    *,
    input_path: Path,
    output_root: Path,
    route: str,
    selected_sheets: list[str],
    outcome_name: str,
    lmstudio_enabled: bool,
    lmstudio_url: str,
    model_id: str,
    binary_effect_size: str,
    network_engine: str,
    network_effect: str,
    network_model: str,
    single_arm_type: str,
    diagnostic_mode: str,
    jobs: int,
    dry_run: bool,
    install_r_packages: bool,
    analyze_all_sheets: bool = False,
    group_column: str = "",
    subgroup_columns: list[str] | None = None,
    meta_regressor_columns: list[str] | None = None,
) -> list[str]:
    subgroup_columns = subgroup_columns or []
    meta_regressor_columns = meta_regressor_columns or []
    common = [str(input_path)]
    sheet_args: list[str] = []
    if analyze_all_sheets:
        sheet_args = ["--all-sheets"]
    elif selected_sheets:
        sheet_args = ["--sheets", ",".join(selected_sheets)]

    if route == "Auto route workbook":
        command = [
            sys.executable,
            str(runner_script("main.py")),
            *common,
            "--output-root",
            str(output_root),
            "--yes",
            "--continue-on-error",
            "--jobs",
            str(jobs),
            "--binary-effect-size",
            binary_effect_size,
            "--network-engine",
            network_engine,
            *sheet_args,
        ]
        if dry_run:
            command.append("--dry-run")
        if install_r_packages:
            command.append("--install-r-packages")
    elif route == "Binary pairwise":
        command = [
            sys.executable,
            str(runner_script("binary_outcome.py")),
            *common,
            "--output-dir",
            str(output_root),
            "--yes",
        ]
        if selected_sheets:
            command += ["--sheet", selected_sheets[0]]
    elif route == "Continuous pairwise":
        command = [
            sys.executable,
            str(runner_script("continuous_outcome.py")),
            *common,
            "--output-dir",
            str(output_root),
            "--yes",
        ]
        if selected_sheets:
            command += ["--sheet", selected_sheets[0]]
    elif route == "Single-arm":
        command = [
            sys.executable,
            str(runner_script("single_arm_meta_analysis.py")),
            *common,
            "--output-dir",
            str(output_root),
            "--yes",
            "--type",
            single_arm_type,
        ]
        if selected_sheets:
            command += ["--sheet", selected_sheets[0]]
    elif route == "Diagnostic accuracy":
        command = [
            sys.executable,
            str(runner_script("diagnostic_meta_analysis.py")),
            *common,
            "--output-dir",
            str(output_root),
            "--yes",
            "--mode",
            diagnostic_mode,
        ]
        if selected_sheets:
            command += ["--sheet", selected_sheets[0]]
    else:
        command = [
            sys.executable,
            str(runner_script("network_meta_analysis.py")),
            *common,
            "--output-dir",
            str(output_root),
            "--yes",
            "--engine",
            network_engine,
            "--effect",
            network_effect,
            "--model",
            network_model,
        ]
        if selected_sheets:
            command += ["--sheet", selected_sheets[0]]
        if install_r_packages:
            command.append("--install-r-packages")

    if outcome_name and route != "Auto route workbook":
        command += ["--outcome", outcome_name]
    append_column_overrides(
        command,
        route=route,
        group_column=group_column,
        subgroup_columns=subgroup_columns,
        meta_regressor_columns=meta_regressor_columns,
    )
    if not lmstudio_enabled and route != "Network meta-analysis":
        command.append("--no-lmstudio")
    elif route != "Network meta-analysis":
        command += ["--lmstudio-url", lmstudio_url]
        if model_id:
            command += ["--model", model_id]
    return command


def main() -> None:
    st.set_page_config(page_title="Meta-Analysis Runner", page_icon=":bar_chart:", layout="wide")
    apply_theme()
    render_header()
    render_active_job_banner("top")

    with st.sidebar:
        st.header("Runtime")
        sidebar_job = st.session_state.get("analysis_job")
        if process_running(sidebar_job):
            st.error("Analysis running")
            if st.button("Stop Analysis", key="stop_analysis_sidebar", use_container_width=True):
                stop_background_job(sidebar_job)
                poll_background_job(sidebar_job)
                st.rerun()
            st.divider()
        providers = list(PROVIDER_DEFAULTS)
        provider = st.selectbox("LLM provider", providers, index=providers.index(default_provider()))
        provider_defaults = PROVIDER_DEFAULTS[provider]
        llm_base_url = st.text_input(
            "API base URL",
            value=os.environ.get("LMSTUDIO_URL", provider_defaults["base_url"]) if provider == "LM Studio" else provider_defaults["base_url"],
            disabled=provider == "Manual/no LLM",
        )
        env_key = api_key_from_env(provider)
        llm_api_key = st.text_input(
            "API key",
            value=env_key,
            type="password",
            disabled=provider in {"LM Studio", "Manual/no LLM"},
            help="OpenAI-compatible providers use an Authorization: Bearer token. Keys are passed only to the child runner process.",
        )
        with st.expander("Advanced API auth"):
            auth_header = st.text_input("Auth header", value=provider_defaults["auth_header"], disabled=provider == "Manual/no LLM")
            auth_prefix = st.text_input("Auth prefix", value=provider_defaults["auth_prefix"], disabled=provider == "Manual/no LLM")

        if provider == "LM Studio":
            status = check_lmstudio(llm_base_url)
        elif provider == "Manual/no LLM":
            status = LmStudioStatus(False, [], "LLM calls disabled; the app will use manual selections and runner heuristics.")
        elif not llm_api_key:
            status = LmStudioStatus(False, [], f"{provider} needs an API key before the runner can use it.")
        else:
            status = check_openai_compatible(llm_base_url, llm_api_key, auth_header, auth_prefix)

        if status.available:
            st.success(status.message)
        elif provider == "Manual/no LLM":
            st.info(status.message)
        else:
            st.warning(f"{status.message} Manual study-characteristic choices are still available below.")

        model_options = [""] + status.models
        selected_model = st.selectbox("Discovered model", model_options, index=0, help="Leave blank to use the custom model field or let local LM Studio choose.")
        custom_model = st.text_input("Model override", value=os.environ.get("META_ANALYSIS_LLM_MODEL", os.environ.get("LMSTUDIO_MODEL", "")))
        model_id = custom_model.strip() or selected_model
        use_llm = provider != "Manual/no LLM" and (status.available or bool(model_id and (provider == "LM Studio" or llm_api_key)))
        st.toggle("Use selected LLM provider", value=use_llm, disabled=True)
        rscript = shutil.which("Rscript")
        if rscript:
            st.success(f"Rscript: {rscript}")
        else:
            st.error("Rscript was not found on PATH. Install R before running full analyses.")
        st.divider()
        st.caption("Install command")
        st.code("pip install ams-meta_analysis\nams-meta_analysis", language="bash")

    uploaded = st.file_uploader("Workbook or CSV", type=sorted(ext.strip(".") for ext in SUPPORTED_INPUTS))
    if uploaded is None:
        st.info("Upload an Excel workbook or CSV to begin.")
        return

    suffix = Path(uploaded.name).suffix.lower()
    if suffix not in SUPPORTED_INPUTS:
        st.error(f"Unsupported file type: {suffix}")
        return

    if "input_path" not in st.session_state or st.session_state.get("uploaded_name") != uploaded.name:
        st.session_state.input_path = save_upload(uploaded)
        st.session_state.uploaded_name = uploaded.name

    input_path = Path(st.session_state.input_path)
    overview = workbook_overview(str(input_path))
    sheet_names = list(overview)

    setup_tab, preview_tab, command_tab = st.tabs(["Configure", "Preview", "Command"])
    with setup_tab:
        left, right = st.columns([1.05, 0.95])
        with left:
            st.subheader("Workbook Scope")
            analyze_all_sheets = st.checkbox(
                "Select all sheets",
                value=False,
                help=(
                    "Use every sheet in the workbook. Auto route will analyze all sheets. "
                    "Specialized routes still run the first selected sheet only."
                ),
            )
            if analyze_all_sheets:
                selected_sheets = list(sheet_names)
                st.multiselect(
                    "Analyze sheets",
                    sheet_names,
                    default=sheet_names,
                    disabled=True,
                    help="All workbook sheets are selected.",
                )
                st.caption(f"All {len(selected_sheets)} sheet(s) selected.")
            else:
                selected_sheets = st.multiselect(
                    "Analyze sheets",
                    sheet_names,
                    default=sheet_names[:1],
                    help="Auto route can analyze multiple sheets. Specialized routes use the first selected sheet.",
                )
            preview_sheet = st.selectbox("Preview sheet", sheet_names)
            meta = overview[preview_sheet]
            st.caption(f"{meta['rows']} rows, {len(meta['columns'])} columns in the selected preview sheet.")
        with right:
            st.subheader("Study Characteristics")
            route = st.selectbox(
                "Analysis route",
                [
                    "Auto route workbook",
                    "Binary pairwise",
                    "Continuous pairwise",
                    "Single-arm",
                    "Diagnostic accuracy",
                    "Network meta-analysis",
                ],
            )
            outcome_name = st.text_input("Outcome label", value=preview_sheet if selected_sheets else "")
            if analyze_all_sheets and route != "Auto route workbook":
                first_sheet = selected_sheets[0] if selected_sheets else "the first selected sheet"
                st.warning(
                    f"Select all sheets is meant for Auto route workbook. {route} will run only '{first_sheet}'."
                )
            col_a, col_b = st.columns(2)
            with col_a:
                binary_effect_size = st.selectbox("Binary effect size", ["auto", "RR", "OR", "RD"], index=0)
                single_arm_type = st.selectbox("Single-arm outcome", ["auto", "proportion", "mean"], index=0)
                diagnostic_mode = st.selectbox("Diagnostic mode", ["single", "comparative"], index=0)
            with col_b:
                network_engine = st.selectbox("Network engine", ["frequentist", "bayesian", "both"], index=0)
                network_effect = st.selectbox("Network effect", ["auto", "RR", "OR", "RD", "MD", "SMD"], index=0)
                network_model = st.selectbox("Network model", ["random", "common", "fixed"], index=0)
            dry_run = st.toggle("Dry run command planning", value=False)
            jobs = st.number_input("Parallel jobs", min_value=1, max_value=8, value=1, step=1)
            install_r_packages = st.toggle("Allow network runner to install missing R packages", value=False)
            default_output_root = input_path.parent / "outputs"
            if (
                "output_root_text" not in st.session_state
                or st.session_state.get("output_for_input") != str(input_path)
            ):
                st.session_state.output_root_text = str(default_output_root)
                st.session_state.output_for_input = str(input_path)

            browse_col, path_col = st.columns([0.22, 0.78], vertical_alignment="bottom")
            with browse_col:
                browse_clicked = st.button(
                    "Browse...",
                    use_container_width=True,
                    help="Open a local folder picker. If your browser blocks native dialogs, type or paste the folder path on the right.",
                )
            with path_col:
                output_root_text = st.text_input(
                    "Output folder",
                    key="output_root_text",
                    help=(
                        "Where generated CSV, R scripts, plots, Word summaries, and run logs are saved. "
                        "You can use the default run folder, choose an existing folder, or type a new folder path."
                    ),
                )
            if browse_clicked:
                selected_folder = choose_output_directory(Path(st.session_state.output_root_text).parent)
                if selected_folder:
                    st.session_state.output_root_text = selected_folder
                    st.rerun()
                st.warning("No folder was selected. You can still type or paste a folder path.")

            with st.expander("What do these options mean?"):
                st.markdown(
                    """
                    - **Auto route workbook**: classify selected sheets and dispatch each to the best runner. Use this for multi-outcome workbooks.
                    - **Select all sheets**: sends every workbook sheet to Auto route. Specialized routes still use the first selected sheet.
                    - **Binary pairwise**: one selected sheet with intervention/control event counts, such as adverse events or clinical success.
                    - **Continuous pairwise**: one selected sheet with means, SDs, and sample sizes.
                    - **Single-arm**: one selected sheet with proportions or means from a single group.
                    - **Diagnostic accuracy**: one selected sheet with TP, FP, TN, and FN columns.
                    - **Network meta-analysis**: one selected long-arm network dataset.
                    - **Dry run**: show the planned command and generated decisions without running the full analysis.
                    - **Parallel jobs**: only applies to auto-routed workbook runs with multiple selected sheets.
                    - **Groups and subgroups**: categorical columns used for subgroup analyses. The primary group is placed first when passed to supported runners.
                    - **Meta-regressors**: numeric or categorical study-level moderators used by binary and continuous pairwise runners.
                    """
                )

        column_meta = overview[preview_sheet]
        preview_df = column_meta["preview"]
        available_columns = list(column_meta["columns"])
        auto_subgroups = auto_group_columns(preview_df, available_columns)
        auto_covariates = auto_meta_regressor_columns(preview_df, available_columns, auto_subgroups)
        supports_subgroups = route in {"Auto route workbook", "Binary pairwise", "Continuous pairwise", "Single-arm"}
        supports_meta_regression = route in {"Auto route workbook", "Binary pairwise", "Continuous pairwise"}

        st.subheader("Groups, Subgroups, and Meta-Regression")
        st.caption(
            "The app suggests columns from the selected preview sheet. If a suggestion is wrong or missing, choose the exact workbook columns here."
        )
        group_col, subgroup_col, regressor_col = st.columns([0.9, 1.1, 1.1])
        with group_col:
            group_default = 1 if auto_subgroups else 0
            group_column_choice = st.selectbox(
                "Primary group",
                ["(none)", *available_columns],
                index=group_default,
                disabled=not supports_subgroups,
                help="Optional main grouping column. It is also included in the subgroup column list for supported analyses.",
            )
            group_column = "" if group_column_choice == "(none)" else group_column_choice
        subgroup_defaults = auto_subgroups if supports_subgroups else []
        with subgroup_col:
            subgroup_columns = st.multiselect(
                "Subgroup columns",
                available_columns,
                default=unique_existing(subgroup_defaults, available_columns),
                disabled=not supports_subgroups,
                help="Categorical columns for subgroup analyses. Add or remove columns when automatic detection is incomplete.",
            )
        if group_column and group_column not in subgroup_columns:
            subgroup_columns = [group_column, *subgroup_columns]
        with regressor_col:
            meta_regressor_columns = st.multiselect(
                "Meta-regressors",
                available_columns,
                default=unique_existing(auto_covariates, available_columns),
                disabled=not supports_meta_regression,
                help="Study-level moderator columns for meta-regression. Supported for binary and continuous pairwise analyses.",
            )
        if not supports_meta_regression:
            meta_regressor_columns = []
            st.info("Meta-regression column overrides are used by auto, binary pairwise, and continuous pairwise routes.")

    render_run_summary(provider=provider, status=status, rscript=rscript, selected_sheets=selected_sheets, route=route)

    with preview_tab:
        meta = overview[preview_sheet]
        st.subheader(preview_sheet)
        col_a, col_b, col_c = st.columns(3)
        col_a.metric("Rows", meta["rows"])
        col_b.metric("Columns", len(meta["columns"]))
        col_c.metric("Selected sheets", len(selected_sheets))
        st.dataframe(meta["preview"], use_container_width=True, height=360)

    output_root = Path(output_root_text).expanduser().resolve()
    command = build_command(
        input_path=input_path,
        output_root=output_root,
        route=route,
        selected_sheets=selected_sheets,
        analyze_all_sheets=analyze_all_sheets and route == "Auto route workbook",
        outcome_name=outcome_name,
        group_column=group_column,
        subgroup_columns=subgroup_columns,
        meta_regressor_columns=meta_regressor_columns,
        lmstudio_enabled=bool(use_llm),
        lmstudio_url=llm_base_url,
        model_id=model_id,
        binary_effect_size=binary_effect_size,
        network_engine=network_engine,
        network_effect=network_effect,
        network_model=network_model,
        single_arm_type=single_arm_type,
        diagnostic_mode=diagnostic_mode,
        jobs=int(jobs),
        dry_run=dry_run,
        install_r_packages=install_r_packages,
    )

    with command_tab:
        st.subheader("Generated Command")
        st.code(format_command(command), language="bash")
        st.caption(f"Outputs will be written under {output_root}")

    run_disabled = not selected_sheets or not rscript
    job_running = process_running(st.session_state.get("analysis_job"))
    run_col, stop_col = st.columns([0.5, 0.5], vertical_alignment="center")
    with run_col:
        run_clicked = st.button("Run Analysis", type="primary", disabled=run_disabled or job_running, use_container_width=True)
    with stop_col:
        stop_clicked = False
        if job_running:
            stop_clicked = st.button("Stop Running Script", type="primary", use_container_width=True)
        else:
            st.button("Stop Running Script", disabled=True, use_container_width=True)
    if stop_clicked:
        job = st.session_state.get("analysis_job")
        stop_background_job(job)
        poll_background_job(job)
        st.rerun()
    if run_clicked:
        output_root.mkdir(parents=True, exist_ok=True)
        env = os.environ.copy()
        env["PYTHONUNBUFFERED"] = "1"
        if use_llm:
            env["LMSTUDIO_URL"] = llm_base_url
            if model_id:
                env["LMSTUDIO_MODEL"] = model_id
                env["META_ANALYSIS_LLM_MODEL"] = model_id
            if llm_api_key:
                env["META_ANALYSIS_LLM_API_KEY"] = llm_api_key
                env["META_ANALYSIS_LLM_AUTH_HEADER"] = auth_header
                env["META_ANALYSIS_LLM_AUTH_PREFIX"] = auth_prefix
        st.session_state.analysis_job = start_background_job(command, env, output_root)
        st.rerun()
    render_job_controls(output_root)


if __name__ == "__main__":
    main()
