"""Console bridge to the original command-line orchestrator."""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path


def runners_dir() -> Path:
    return Path(__file__).resolve().parent / "runners"


def main(argv: list[str] | None = None) -> int:
    """Run the packaged orchestrator with the current Python interpreter."""

    args = list(argv if argv is not None else sys.argv[1:])
    script = runners_dir() / "main.py"
    completed = subprocess.run([sys.executable, str(script), *args], check=False)
    return int(completed.returncode)


if __name__ == "__main__":
    raise SystemExit(main())

