#!/usr/bin/env python3
"""Orchestrate the repository's meta-analysis runners from one entry point.

The script scans an Excel workbook or CSV file, asks LMStudio to classify each
sheet/outcome, displays a review table, lets the user correct any classification,
and then dispatches to the specialized runner:

* binary_outcome.py
* continuous_outcome.py
* single_arm_meta_analysis.py
* diagnostic_meta_analysis.py
* network_meta_analysis.py
"""

from __future__ import annotations

import argparse
import concurrent.futures
import csv
import json
import math
import os
import re
import shutil
import subprocess
import sys
import textwrap
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any

import binary_outcome as common
import continuous_outcome

try:
    from tqdm.auto import tqdm
except ImportError:  # pragma: no cover - used only when tqdm is unavailable
    def tqdm(iterable: Any = None, **_: Any) -> Any:
        if iterable is None:
            class _Progress:
                def update(self, *_args: Any, **_kwargs: Any) -> None:
                    pass

                def set_postfix_str(self, *_args: Any, **_kwargs: Any) -> None:
                    pass

                def close(self) -> None:
                    pass

                def __enter__(self) -> "_Progress":
                    return self

                def __exit__(self, *_args: Any) -> None:
                    pass

            return _Progress()
        return iterable


ANALYSIS_TYPES = {
    "binary_pairwise",
    "continuous_pairwise",
    "single_arm_proportion",
    "single_arm_mean",
    "diagnostic_single",
    "diagnostic_comparative",
    "network_binary",
    "network_continuous",
    "skip",
}

TYPE_LABELS = {
    "binary_pairwise": "Binary pairwise",
    "continuous_pairwise": "Continuous pairwise",
    "single_arm_proportion": "Single-arm proportion",
    "single_arm_mean": "Single-arm mean",
    "diagnostic_single": "Diagnostic accuracy",
    "diagnostic_comparative": "Comparative diagnostic",
    "network_binary": "Network binary",
    "network_continuous": "Network continuous",
    "skip": "Skip",
}

SCRIPT_BY_TYPE = {
    "binary_pairwise": "binary_outcome.py",
    "continuous_pairwise": "continuous_outcome.py",
    "single_arm_proportion": "single_arm_meta_analysis.py",
    "single_arm_mean": "single_arm_meta_analysis.py",
    "diagnostic_single": "diagnostic_meta_analysis.py",
    "diagnostic_comparative": "diagnostic_meta_analysis.py",
    "network_binary": "network_meta_analysis.py",
    "network_continuous": "network_meta_analysis.py",
}

IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp", ".gif", ".svg"}
COLLECTED_OUTCOME_DIR = "Collected Outcomes"
OUTCOME_IMAGE_DIR = "Images"
OUTCOME_OTHER_DIR = "Additional Information"
REPORT_DIR = "Manuscript Report"

PRISMA_2020_SOURCES = {
    "statement": "https://www.prisma-statement.org/prisma-2020",
    "checklist": "https://www.prisma-statement.org/s/PRISMA_2020_checklist-ab3g.pdf",
    "expanded_checklist": "https://www.prisma-statement.org/s/PRISMA_2020_expanded_checklist-w7ra.pdf",
}

PRISMA_2020_METHODS_FRAME = [
    {
        "item": "5",
        "topic": "Eligibility criteria",
        "instruction": "State inclusion/exclusion criteria and how studies were grouped for each synthesis.",
    },
    {
        "item": "6-7",
        "topic": "Information sources and search strategy",
        "instruction": "Report all sources, last-search dates, and full search strategies only when supplied by review-level context.",
    },
    {
        "item": "8-9",
        "topic": "Selection and data collection",
        "instruction": "Describe screening and extraction processes, reviewer independence, disagreement resolution, and any automation tools only when supplied.",
    },
    {
        "item": "10a-10b",
        "topic": "Data items",
        "instruction": "Define outcomes and other extracted variables, including assumptions for unclear or missing data.",
    },
    {
        "item": "11",
        "topic": "Risk of bias",
        "instruction": "Name the risk-of-bias tools, domains, reviewer process, and overall-judgment rules when risk-of-bias context is supplied.",
    },
    {
        "item": "12-15",
        "topic": "Effect measures and synthesis methods",
        "instruction": "Report effect measures, data preparation, models, heterogeneity measures, subgroup/meta-regression, sensitivity, reporting-bias, TSA, and certainty methods when performed.",
    },
]

PRISMA_2020_RESULTS_FRAME = [
    {
        "item": "16",
        "topic": "Study selection",
        "instruction": "Report records identified, screened, excluded, full texts assessed, and included studies, ideally matching the PRISMA flow diagram.",
    },
    {
        "item": "17-18",
        "topic": "Study characteristics and risk of bias",
        "instruction": "Present included-study characteristics and risk-of-bias assessments when available.",
    },
    {
        "item": "19",
        "topic": "Individual-study results",
        "instruction": "Present per-study summary statistics/effect estimates and precision, usually by table or forest plot.",
    },
    {
        "item": "20a-20d",
        "topic": "Synthesis results",
        "instruction": "For each synthesis, report contributing studies, summary estimate, precision, heterogeneity, direction of effect, subgroup/meta-regression, and sensitivity analyses. Report RTSA output status when TSA files are available, without overstating the results.",
    },
    {
        "item": "21-22",
        "topic": "Reporting bias and certainty",
        "instruction": "Report small-study/reporting-bias assessments and certainty-of-evidence assessments when available.",
    },
]


@dataclass
class PlannedAnalysis:
    index: int
    sheet: str
    rows: int
    columns: list[str]
    outcome_name: str
    analysis_type: str
    confidence: float = 0.0
    reason: str = ""
    warnings: list[str] = field(default_factory=list)
    network_engine: str | None = None
    diagnostic_mode: str | None = None
    classification_source: str = "heuristic"
    preflight_mapping: dict[str, Any] | None = None

    @property
    def label(self) -> str:
        return TYPE_LABELS.get(self.analysis_type, self.analysis_type)


@dataclass
class PairwisePreflightDecision:
    item: PlannedAnalysis
    columns: list[str]
    mapping: dict[str, Any]
    lm_mapping: dict[str, Any] | None = None
    error: str = ""


def normalize_name(value: str) -> str:
    return common.normalize_name(value)


def run_time_folder_label() -> str:
    return datetime.now().astimezone().strftime("%Y%m%d-%H%M%S")


def default_output_root(input_path: Path, include_run_time: bool = True) -> Path:
    folder_name = f"Meta Analysis Results - {common.sanitize_filename(input_path.stem)}"
    if include_run_time:
        folder_name = f"{folder_name} - Run {run_time_folder_label()}"
    return input_path.parent / folder_name


def truncate(value: Any, width: int) -> str:
    text = str(value)
    if len(text) <= width:
        return text
    return text[: max(0, width - 1)] + "…"


def workbook_summary_with_progress(path: Path) -> tuple[Any, dict[str, Any]]:
    summary: dict[str, Any] = {}
    if path.suffix.lower() == ".csv":
        with tqdm(total=1, desc="Scanning workbook", unit="sheet") as progress:
            try:
                df = common.pd.read_csv(path)
            except Exception:
                df = common.pd.read_csv(path, encoding="utf-8-sig")
            preview = df.head(5).where(common.pd.notna(df.head(5)), None)
            sheet_name = path.stem
            summary[sheet_name] = {
                "rows": int(df.shape[0]),
                "columns": [str(col) for col in df.columns],
                "sample_rows": preview.to_dict(orient="records"),
            }
            progress.update(1)

        class MockWorkbook:
            def __init__(self, names: list[str]) -> None:
                self.sheet_names = names

        return MockWorkbook([sheet_name]), summary

    workbook = common.pd.ExcelFile(path)
    for sheet in tqdm(workbook.sheet_names, desc="Scanning workbook", unit="sheet"):
        df = common.pd.read_excel(path, sheet_name=sheet)
        preview = df.head(5).where(common.pd.notna(df.head(5)), None)
        summary[sheet] = {
            "rows": int(df.shape[0]),
            "columns": [str(col) for col in df.columns],
            "sample_rows": preview.to_dict(orient="records"),
        }
    return workbook, summary


def parse_sheet_selection(selection: str, sheet_names: list[str]) -> list[str]:
    cleaned = selection.strip()
    if not cleaned or cleaned.lower() in {"all", "a", "*"}:
        return sheet_names
    if cleaned.lower() in {"none", "n", "stop", "quit", "exit"}:
        raise SystemExit("Stopped before asking LMStudio.")

    by_normalized = {normalize_name(sheet): sheet for sheet in sheet_names}
    selected: list[str] = []
    for raw_part in re.split(r"[,;]+", cleaned):
        part = raw_part.strip()
        if not part:
            continue
        range_match = re.fullmatch(r"(\d+)\s*-\s*(\d+)", part)
        if range_match:
            start = int(range_match.group(1))
            end = int(range_match.group(2))
            if start > end:
                start, end = end, start
            if start < 1 or end > len(sheet_names):
                raise SystemExit(f"Sheet range '{part}' is outside 1-{len(sheet_names)}.")
            for index in range(start, end + 1):
                sheet = sheet_names[index - 1]
                if sheet not in selected:
                    selected.append(sheet)
            continue
        if part.isdigit():
            index = int(part)
            if index < 1 or index > len(sheet_names):
                raise SystemExit(f"Sheet number '{part}' is outside 1-{len(sheet_names)}.")
            sheet = sheet_names[index - 1]
        elif part in sheet_names:
            sheet = part
        else:
            sheet = by_normalized.get(normalize_name(part))
            if not sheet:
                raise SystemExit(f"Sheet '{part}' was not found. Use the printed number or exact sheet name.")
        if sheet not in selected:
            selected.append(sheet)
    if not selected:
        raise SystemExit("No sheets were selected.")
    return selected


def filter_summary_to_selected_sheets(summary: dict[str, Any], selected_sheets: list[str]) -> dict[str, Any]:
    return {sheet: summary[sheet] for sheet in selected_sheets}


def choose_sheets_before_lmstudio(summary: dict[str, Any], args: argparse.Namespace) -> dict[str, Any]:
    sheet_names = list(summary)
    if getattr(args, "all_sheets", False):
        selected = sheet_names
    elif args.sheets:
        selected = parse_sheet_selection(args.sheets, sheet_names)
    elif len(sheet_names) <= 1 or args.yes or not sys.stdin.isatty():
        selected = sheet_names
    else:
        print("\nSheet Selection")
        print("---------------")
        print("Choose which sheet(s) to classify before LMStudio is called.")
        print("  all    Evaluate every sheet")
        print("  1,3-5  Evaluate selected sheet numbers/ranges")
        print("  name   Evaluate a sheet by exact name")
        response = input("Analyze sheets [all]: ").strip()
        selected = parse_sheet_selection(response or "all", sheet_names)

    selected_summary = filter_summary_to_selected_sheets(summary, selected)
    if len(selected) == len(sheet_names):
        print("\nSelected sheets: all")
    else:
        print("\nSelected sheets: " + ", ".join(f"{sheet_names.index(sheet) + 1}. {sheet}" for sheet in selected))
    return selected_summary


def format_table(headers: list[str], rows: list[list[Any]]) -> str:
    string_rows = [[str(cell) for cell in row] for row in rows]
    widths = [len(header) for header in headers]
    for row in string_rows:
        widths = [max(width, len(cell)) for width, cell in zip(widths, row)]
    separator = "  ".join("-" * width for width in widths)
    lines = ["  ".join(header.ljust(width) for header, width in zip(headers, widths)), separator]
    for row in string_rows:
        lines.append("  ".join(cell.ljust(width) for cell, width in zip(row, widths)))
    return "\n".join(lines)


def wrap_detail_line(label: str, value: Any, width: int) -> str:
    prefix = f"   {label}: "
    return textwrap.fill(
        str(value),
        width=max(50, width),
        initial_indent=prefix,
        subsequent_indent=" " * len(prefix),
        break_long_words=False,
        break_on_hyphens=False,
    )


def sheet_hint(sheet: str, columns: list[str]) -> str:
    return normalize_name(" ".join([sheet, *columns]))


def heuristic_classification(sheet: str, meta: dict[str, Any], default_network_engine: str) -> PlannedAnalysis:
    columns = [str(col) for col in meta["columns"]]
    normalized = {normalize_name(col) for col in columns}
    hint = sheet_hint(sheet, columns)
    rows = int(meta["rows"])

    def has_all(*names: str) -> bool:
        return all(normalize_name(name) in normalized for name in names)

    def has_any(*names: str) -> bool:
        return any(normalize_name(name) in normalized for name in names)

    analysis_type = "skip"
    reason = "No recognizable meta-analysis column pattern was detected."

    if has_all("tp", "fp", "tn", "fn"):
        if has_any("category", "category1", "test", "modality", "index test", "test group"):
            analysis_type = "diagnostic_comparative"
            reason = "TP/FP/TN/FN columns plus a diagnostic test/category column suggest comparative diagnostic accuracy."
        else:
            analysis_type = "diagnostic_single"
            reason = "TP/FP/TN/FN columns suggest diagnostic test accuracy meta-analysis."
    elif (
        {"treatment1", "treatment2", "events1", "events2", "n1", "n2"}.issubset(normalized)
        or {"treat1", "treat2", "event1", "event2", "n1", "n2"}.issubset(normalized)
    ):
        analysis_type = "network_binary"
        reason = "Wide two-arm network columns with Treatment1/Treatment2, Events1/Events2, and N1/N2 suggest binary network meta-analysis."
    elif {"treatment1", "treatment2", "mean1", "mean2", "sd1", "sd2"}.issubset(normalized):
        analysis_type = "network_continuous"
        reason = "Wide two-arm network columns with Treatment1/Treatment2, means, and SDs suggest continuous network meta-analysis."
    elif has_any("treatment", "treat", "arm") and has_any("samplesize", "sample size", "n"):
        if has_any("responders", "events", "event"):
            analysis_type = "network_binary"
            reason = "Long-arm treatment, event/responders, and sample-size columns suggest binary network meta-analysis."
        elif has_any("mean", "avg") and has_any("std.dev", "sd", "std dev", "standard deviation"):
            analysis_type = "network_continuous"
            reason = "Long-arm treatment, mean, SD, and sample-size columns suggest continuous network meta-analysis."
    elif (
        {"evente", "ne", "eventc", "nc"} <= normalized
        or {"eventse", "ne", "eventsc", "nc"} <= normalized
        or {"eusgjevents", "eusgjtotal", "noneusgjevents", "noneusgjtotal"} <= normalized
        or ("interventionevents" in hint and "controlevents" in hint)
        or ("experimentalevents" in hint and "comparatorevents" in hint)
    ):
        analysis_type = "binary_pairwise"
        reason = "Intervention/control event and denominator columns suggest pairwise binary meta-analysis."
    elif (
        ("hazardratio" in hint or "adjustedhr" in hint or "hr" in normalized)
        and (
            ("cilower" in hint and "ciupper" in hint)
            or ("lowerci" in hint and "upperci" in hint)
            or ("loghr" in hint and ("seloghr" in hint or "standarderror" in hint))
        )
    ):
        analysis_type = "binary_pairwise"
        reason = "Hazard-ratio and confidence-interval columns suggest generic inverse-variance HR meta-analysis through the binary runner."
    elif (
        {"meane", "sde", "meanc", "sdc"} <= normalized
        or {"eusgjmean", "eusgjsd", "eusgjtotal", "noneusgjmean", "noneusgjsd", "noneusgjtotal"} <= normalized
        or ("interventionmean" in hint and "controlmean" in hint)
        or ("experimentalmean" in hint and "comparatormean" in hint)
    ):
        analysis_type = "continuous_pairwise"
        reason = "Intervention/control mean and SD columns suggest pairwise continuous meta-analysis."
    elif has_any("event", "events", "responders", "cases") and has_any("n", "total", "sample", "samplesize"):
        analysis_type = "single_arm_proportion"
        reason = "Single event and denominator columns suggest single-arm proportion meta-analysis."
    elif has_any("mean", "avg") and has_any("sd", "std.dev", "std dev", "standard deviation") and has_any("n", "sample", "samplesize"):
        analysis_type = "single_arm_mean"
        reason = "Single mean, SD, and sample-size columns suggest single-arm mean meta-analysis."

    if "network" in hint and analysis_type in {"binary_pairwise", "continuous_pairwise", "single_arm_proportion", "single_arm_mean"}:
        if "binary" in hint:
            analysis_type = "network_binary"
            reason = "The sheet name mentions network and columns look compatible with binary NMA."
        elif "continuous" in hint:
            analysis_type = "network_continuous"
            reason = "The sheet name mentions network and columns look compatible with continuous NMA."

    warnings = []
    if rows == 0:
        warnings.append("Sheet has no data rows.")
        analysis_type = "skip"
        reason = "The sheet has recognizable headers but no data rows, so it was skipped."

    return PlannedAnalysis(
        index=0,
        sheet=sheet,
        rows=rows,
        columns=columns,
        outcome_name=sheet,
        analysis_type=analysis_type,
        confidence=0.35 if analysis_type != "skip" else 0.0,
        reason=reason,
        warnings=warnings,
        network_engine=default_network_engine if analysis_type.startswith("network_") else None,
        diagnostic_mode="comparative" if analysis_type == "diagnostic_comparative" else "single",
        classification_source="heuristic",
    )


def classification_prompt(summary: dict[str, Any], default_network_engine: str) -> dict[str, Any]:
    slim_summary: dict[str, Any] = {}
    for sheet, meta in summary.items():
        slim_summary[sheet] = {
            "rows": meta["rows"],
            "columns": meta["columns"],
            "sample_rows": meta["sample_rows"][:3],
        }
    return {
        "task": (
            "Classify every sheet or CSV as the appropriate meta-analysis workflow. "
            "Use sheet names as outcome names unless a cleaner clinical outcome name is obvious. "
            "Return one analysis per sheet unless the sheet should be skipped. "
            "Make recommendations for all sheets in one response so the user can approve the complete table at once. "
            "For binary_pairwise and continuous_pairwise sheets, also return the proposed column mapping and "
            "analysis choices in preflight_mapping so the user can approve all runner decisions together."
        ),
        "allowed_analysis_types": sorted(ANALYSIS_TYPES),
        "decision_rules": [
            "binary_pairwise: comparative two-arm binary endpoint with intervention/control event and total columns, or time-to-event HR/log(HR) estimates with CI/SE.",
            "continuous_pairwise: comparative two-arm continuous endpoint with intervention/control mean/SD/N or median/IQR/N columns.",
            "single_arm_proportion: one-arm event count and denominator.",
            "single_arm_mean: one-arm mean, SD, and N.",
            "diagnostic_single: TP, FP, TN, FN for one diagnostic test.",
            "diagnostic_comparative: TP, FP, TN, FN plus a test/modality/category column in the same sheet.",
            "network_binary: long-arm network data with study, treatment, responders/events, and sampleSize; wide binary NMA also requires N1/N2 denominators.",
            "network_continuous: long-arm network data with study, treatment, mean, std.dev/SD, and sampleSize.",
            "skip: templates, empty sheets, notes, or sheets without analyzable study rows.",
            "Do not call a sheet network meta-analysis unless it has long-arm treatment/arm rows or the sheet name clearly indicates network data.",
            "For binary_pairwise preflight_mapping.columns, use these field names when present: study_label, event_e, n_e, event_c, n_c, hr, ci_lower, ci_upper, log_hr, se_log_hr, subgroup, covariate.",
            "For continuous_pairwise preflight_mapping.columns, use these field names when present: study_label, n_e, mean_e, sd_e, n_c, mean_c, sd_c, median_e, q1_e, q3_e, min_e, max_e, median_c, q1_c, q3_c, min_c, max_c, subgroup, covariate.",
            "Set intervention_label and control_label from the actual arm prefixes in the selected columns rather than generic labels; for example EUS-GJ Events vs NON EUS-GJ Events should yield intervention_label EUS-GJ and control_label NON EUS-GJ.",
            "For subgroup_columns, list every subgroup column that should be analyzed.",
            "For covariate_columns, list plausible study-level meta-regression candidates, including numeric moderators such as mean age, BMI, publication year, follow-up duration, percent male, sample size, and categorical text moderators such as etiology, control type, region, or study design.",
            "Any column whose name contains 'regressor' should be considered for meta-regression and included in covariate_columns when it is numeric, numeric-coded, or categorical text; categorical moderators may also appear in subgroup_columns.",
            "Do not put the dependent outcome itself in covariate_columns. If the sheet name is Age, BMI, follow-up, length of stay, or another continuous endpoint, treat it as the outcome unless a separate numeric moderator column is present.",
            "Categorical moderators should appear in subgroup_columns and may also appear in covariate_columns when categorical meta-regression is desired.",
            "For binary analysis choices, recommend summary_measure RR, OR, RD, or HR; pooling_method MH, inverse, or Peto; model_type random or common; outcome_direction beneficial or harmful; and TSA alpha/power/effect source.",
            "For continuous analysis choices, recommend summary_measure MD or SMD; data_format mean_sd, median_iqr, or mixed; model_type random or common; outcome_direction lower_better or higher_better; and TSA alpha/power/effect source.",
            "For TSA, set tsa_effect_source to clinically_important only when the workbook/protocol provides a numeric clinically important effect in tsa_anticipated_effect; otherwise set tsa_effect_source to observed.",
        ],
        "default_network_engine": default_network_engine,
        "workbook": slim_summary,
        "return_json_schema": {
            "analyses": [
                {
                    "sheet_name": "exact sheet name",
                    "outcome_name": "human-readable outcome name",
                    "analysis_type": "one allowed_analysis_types value",
                    "confidence": "number from 0 to 1",
                    "reason": "short explanation of why this workflow was selected",
                    "warnings": ["short warning strings, e.g. empty sheet"],
                    "network_engine": "frequentist, bayesian, both, or null",
                    "diagnostic_mode": "single, comparative, or null",
                    "preflight_mapping": {
                        "sheet_name": "exact sheet name",
                        "outcome_name": "human-readable outcome name",
                        "intervention_label": "intervention group label or null",
                        "control_label": "control/comparator group label or null",
                        "columns": {"runner_field_name": "exact workbook column name"},
                        "subgroup_columns": ["exact subgroup column names"],
                        "covariate_columns": ["exact numeric or categorical meta-regression candidate column names"],
                        "analysis": {
                            "summary_measure": "RR/OR/RD/HR for binary or MD/SMD for continuous",
                            "pooling_method": "MH/inverse/Peto for binary or null",
                            "data_format": "mean_sd/median_iqr/mixed for continuous or null",
                            "model_type": "random/common",
                            "outcome_direction": "beneficial/harmful/lower_better/higher_better",
                            "tsa_alpha": 0.05,
                            "tsa_power": 0.8,
                            "tsa_adjust_for_diversity": False,
                            "tsa_effect_source": "observed or clinically_important",
                            "reason": "brief reason for choices"
                        },
                        "notes": "short mapping note"
                    },
                }
            ]
        },
    }


def call_lmstudio_classifier(
    summary: dict[str, Any],
    lmstudio_url: str,
    model: str | None,
    default_network_engine: str,
) -> list[dict[str, Any]] | None:
    resolved_model = common.resolve_lmstudio_model(lmstudio_url, model)
    if not resolved_model:
        return None

    print(f"Classifying {len(summary)} sheet(s) with LMStudio in one request...")
    body = {
        "model": resolved_model,
        "messages": [
            {
                "role": "system",
                "content": (
                    "You classify clinical meta-analysis data sheets. Return only valid JSON. "
                    "Use exact sheet names from the workbook."
                ),
            },
            {"role": "user", "content": json.dumps(classification_prompt(summary, default_network_engine), default=str)},
        ],
        "temperature": 0,
    }
    request = urllib.request.Request(
        common.chat_completions_url(lmstudio_url),
        data=json.dumps(body).encode("utf-8"),
        headers=common.llm_request_headers(include_content_type=True),
        method="POST",
    )
    progress = tqdm(total=1, desc="LLM workbook classification", unit="request")
    try:
        with urllib.request.urlopen(request) as response:
            payload = json.loads(response.read().decode("utf-8"))
        progress.update(1)
    except urllib.error.HTTPError as exc:
        progress.close()
        print(f"LMStudio classification failed ({common.lmstudio_error_message(exc)}). Falling back to column heuristics.")
        return None
    except Exception as exc:
        progress.close()
        print(f"LMStudio classification failed ({exc}). Falling back to column heuristics.")
        return None
    progress.close()

    content = payload["choices"][0]["message"]["content"]
    try:
        parsed = json.loads(content)
    except json.JSONDecodeError:
        match = re.search(r"\{.*\}", content, flags=re.S)
        if not match:
            print("LMStudio did not return JSON for classification. Falling back to column heuristics.")
            return None
        parsed = json.loads(match.group(0))
    analyses = parsed.get("analyses")
    return analyses if isinstance(analyses, list) else None


def classifier_preflight_mapping(item: dict[str, Any], sheet: str, outcome_name: str) -> dict[str, Any] | None:
    raw = item.get("preflight_mapping")
    if not isinstance(raw, dict):
        return None
    mapping = dict(raw)
    mapping["sheet_name"] = sheet
    mapping["outcome_name"] = mapping.get("outcome_name") or outcome_name
    if not isinstance(mapping.get("columns"), dict):
        mapping["columns"] = {}
    if not isinstance(mapping.get("subgroup_columns"), list):
        mapping["subgroup_columns"] = []
    if not isinstance(mapping.get("covariate_columns"), list):
        mapping["covariate_columns"] = []
    if not isinstance(mapping.get("analysis"), dict):
        mapping["analysis"] = {}
    mapping["notes"] = mapping.get("notes") or "Initial workbook-level LMStudio mapping."
    return mapping


def build_plan(
    summary: dict[str, Any],
    lm_analyses: list[dict[str, Any]] | None,
    default_network_engine: str,
) -> list[PlannedAnalysis]:
    heuristic_by_sheet = {
        sheet: heuristic_classification(sheet, meta, default_network_engine)
        for sheet, meta in summary.items()
    }
    lm_by_sheet = {
        str(item.get("sheet_name")): item
        for item in (lm_analyses or [])
        if item.get("sheet_name") in summary
    }

    plan: list[PlannedAnalysis] = []
    for index, (sheet, meta) in enumerate(summary.items(), start=1):
        planned = heuristic_by_sheet[sheet]
        item = lm_by_sheet.get(sheet)
        if item:
            analysis_type = str(item.get("analysis_type") or planned.analysis_type)
            if analysis_type not in ANALYSIS_TYPES:
                analysis_type = planned.analysis_type
            outcome_name = str(item.get("outcome_name") or sheet)
            network_engine = item.get("network_engine") or planned.network_engine
            if network_engine not in {"frequentist", "bayesian", "both", None}:
                network_engine = default_network_engine
            diagnostic_mode = item.get("diagnostic_mode") or planned.diagnostic_mode
            if diagnostic_mode not in {"single", "comparative", None}:
                diagnostic_mode = "single"
            planned = PlannedAnalysis(
                index=index,
                sheet=sheet,
                rows=int(meta["rows"]),
                columns=[str(col) for col in meta["columns"]],
                outcome_name=outcome_name,
                analysis_type=analysis_type,
                confidence=float(item.get("confidence") or planned.confidence),
                reason=str(item.get("reason") or planned.reason),
                warnings=[str(w) for w in item.get("warnings") or planned.warnings],
                network_engine=network_engine if analysis_type.startswith("network_") else None,
                diagnostic_mode=diagnostic_mode if analysis_type.startswith("diagnostic_") else None,
                classification_source="LLM",
                preflight_mapping=classifier_preflight_mapping(item, sheet, outcome_name),
            )
        else:
            planned.index = index
        if planned.rows == 0 and "Sheet has no data rows." not in planned.warnings:
            planned.warnings.append("Sheet has no data rows.")
        if planned.rows == 0:
            planned.analysis_type = "skip"
            planned.network_engine = None
            planned.diagnostic_mode = None
            if "no data rows" not in planned.reason.lower():
                planned.reason = f"{planned.reason} Empty sheets are skipped by default."
        plan.append(planned)
    return plan


def print_plan(plan: list[PlannedAnalysis]) -> None:
    print("\nMeta-Analysis Outcome Recommendations")
    print("-------------------------------------")
    print("Review the numbered rows below. Press Enter or type 'y' at the next prompt to accept all recommendations.")
    rows = []
    for item in plan:
        detail = ""
        if item.analysis_type.startswith("network_"):
            detail = f"engine={item.network_engine or 'frequentist'}"
        elif item.analysis_type.startswith("diagnostic_"):
            detail = f"mode={item.diagnostic_mode or 'single'}"
        rows.append(
            [
                item.index,
                truncate(item.sheet, 24),
                item.rows,
                truncate(item.outcome_name, 28),
                item.label,
                f"{item.confidence:.2f}",
                item.classification_source,
                truncate(detail, 18),
                truncate("; ".join(item.warnings), 28),
                truncate(item.reason, 72),
            ]
        )
    print(format_table(["#", "Sheet", "Rows", "Outcome", "Suggested study", "Conf", "Source", "Options", "Warnings", "Reason"], rows))


def prompt_choice(prompt: str, valid: set[str], current: str | None = None) -> str:
    suffix = f" [{current}]" if current else ""
    while True:
        value = input(f"{prompt}{suffix}: ").strip()
        if not value and current:
            return current
        if value in valid:
            return value
        print("Choose one of: " + ", ".join(sorted(valid)))


def edit_plan(plan: list[PlannedAnalysis], assume_yes: bool) -> list[PlannedAnalysis]:
    print_plan(plan)
    if assume_yes or not sys.stdin.isatty():
        return plan

    proceed = input("\nAccept all recommendations and continue? [Y/n/edit]: ").strip().lower()
    if proceed in {"", "y", "yes"}:
        return plan
    if proceed in {"n", "no", "stop", "quit"}:
        raise SystemExit("Stopped before running analyses.")

    while True:
        value = input("\nEnter an outcome # to edit, 'table' to redisplay, or 'done': ").strip().lower()
        if value in {"done", "d", ""}:
            break
        if value == "table":
            print_plan(plan)
            continue
        if not value.isdigit() or not (1 <= int(value) <= len(plan)):
            print("Enter a valid row number.")
            continue
        item = plan[int(value) - 1]
        print(f"\nEditing {item.sheet}")
        item.outcome_name = input(f"Outcome name [{item.outcome_name}]: ").strip() or item.outcome_name
        print("Analysis types:")
        for name in sorted(ANALYSIS_TYPES):
            print(f"  {name}: {TYPE_LABELS[name]}")
        item.analysis_type = prompt_choice("Analysis type", ANALYSIS_TYPES, item.analysis_type)
        if item.analysis_type.startswith("network_"):
            item.network_engine = prompt_choice(
                "Network engine",
                {"frequentist", "bayesian", "both"},
                item.network_engine or "frequentist",
            )
        else:
            item.network_engine = None
        if item.analysis_type.startswith("diagnostic_"):
            item.diagnostic_mode = "comparative" if item.analysis_type == "diagnostic_comparative" else "single"
        else:
            item.diagnostic_mode = None
        item.reason = "Manually edited by user."
        item.classification_source = "manual"
        item.preflight_mapping = None
        print_plan(plan)

    final = input("\nRun the accepted analyses now? [Y/n]: ").strip().lower()
    if final in {"n", "no"}:
        raise SystemExit("Stopped before running analyses.")
    return plan


def runner_command(
    item: PlannedAnalysis,
    workbook: Path,
    output_root: Path,
    args: argparse.Namespace,
) -> list[str] | None:
    if item.analysis_type == "skip":
        return None
    script_name = SCRIPT_BY_TYPE[item.analysis_type]
    script_path = Path(__file__).resolve().parent / script_name
    output_dir = output_dir_for_item(item, output_root)
    cmd = [sys.executable, str(script_path), str(workbook), "--sheet", item.sheet, "--outcome", item.outcome_name, "--output-dir", str(output_dir)]
    preflight_mapping = output_dir / "preflight-identified-columns.json"
    uses_preflight_mapping = preflight_mapping.exists() and item.analysis_type in {"binary_pairwise", "continuous_pairwise"}
    if uses_preflight_mapping:
        cmd += ["--mapping-json", str(preflight_mapping)]

    if item.analysis_type == "single_arm_proportion":
        cmd += ["--type", "proportion"]
    elif item.analysis_type == "single_arm_mean":
        cmd += ["--type", "mean"]
    elif item.analysis_type == "diagnostic_single":
        cmd += ["--mode", "single"]
    elif item.analysis_type == "diagnostic_comparative":
        cmd += ["--mode", "comparative"]
    elif item.analysis_type == "network_binary":
        cmd += ["--outcome-type", "binary", "--engine", item.network_engine or args.network_engine]
    elif item.analysis_type == "network_continuous":
        cmd += ["--outcome-type", "continuous", "--engine", item.network_engine or args.network_engine]

    if args.yes or uses_preflight_mapping:
        cmd.append("--yes")
    if args.no_lmstudio and item.analysis_type not in {"network_binary", "network_continuous"}:
        cmd.append("--no-lmstudio")
    if item.analysis_type not in {"network_binary", "network_continuous"}:
        cmd += ["--lmstudio-url", args.lmstudio_url]
        if args.model:
            cmd += ["--model", args.model]
    if item.analysis_type in {"binary_pairwise", "continuous_pairwise", "single_arm_proportion", "single_arm_mean"}:
        group_column = filter_override_columns(args.group_column, item.columns)
        subgroup_columns = filter_override_columns(args.subgroup_columns, item.columns)
        if group_column:
            cmd += ["--group-column", group_column[0]]
        if args.subgroup_columns is not None and subgroup_columns:
            cmd += ["--subgroup-columns", ",".join(subgroup_columns)]
    if item.analysis_type in {"binary_pairwise", "continuous_pairwise"} and args.covariate_columns is not None:
        covariate_columns = filter_override_columns(args.covariate_columns, item.columns)
        if covariate_columns:
            cmd += ["--covariate-columns", ",".join(covariate_columns)]

    if item.analysis_type in {"network_binary", "network_continuous"}:
        cmd += ["--rank-sims", str(args.rank_sims)]
        if args.install_r_packages:
            cmd.append("--install-r-packages")
    return cmd


def split_override_columns(value: str | None) -> list[str]:
    if value is None:
        return []
    cleaned = value.strip()
    if not cleaned or cleaned.lower() in {"none", "null", "-", "0"}:
        return []
    parts = [part.strip() for part in re.split(r"[,;]\s*", cleaned) if part.strip()]
    return parts if len(parts) > 1 else [cleaned]


def filter_override_columns(value: str | None, columns: list[str]) -> list[str]:
    selected = []
    numbered = {str(index): column for index, column in enumerate(columns, start=1)}
    for part in split_override_columns(value):
        column = part if part in columns else numbered.get(part)
        if column and column not in selected:
            selected.append(column)
    return selected


def output_dir_for_item(item: PlannedAnalysis, output_root: Path) -> Path:
    return output_root / f"{item.index:02d}_{common.sanitize_filename(item.outcome_name, item.sheet)}"


def collected_outcome_dir_for_item(item: PlannedAnalysis, output_root: Path) -> Path:
    return output_root / COLLECTED_OUTCOME_DIR / f"{item.index:02d}_{common.sanitize_filename(item.outcome_name, item.sheet)}"


def report_data_dir_for_item(item: PlannedAnalysis, output_root: Path) -> Path:
    source_dir = output_dir_for_item(item, output_root)
    if source_dir.exists():
        return source_dir
    collected_info_dir = collected_outcome_dir_for_item(item, output_root) / OUTCOME_OTHER_DIR
    if collected_info_dir.exists():
        return collected_info_dir
    return source_dir


def report_figure_dir_for_item(item: PlannedAnalysis, output_root: Path) -> Path:
    source_dir = output_dir_for_item(item, output_root)
    if source_dir.exists():
        return source_dir
    collected_images_dir = collected_outcome_dir_for_item(item, output_root) / OUTCOME_IMAGE_DIR
    if collected_images_dir.exists():
        return collected_images_dir
    return source_dir


def collected_file_destination(source: Path, source_dir: Path, destination_dir: Path) -> Path:
    destination = destination_dir / source.name
    if not destination.exists():
        return destination

    relative_parent = source.relative_to(source_dir).parent
    prefix = common.sanitize_filename("_".join(relative_parent.parts), "nested")
    destination = destination_dir / f"{prefix}__{source.name}"
    if not destination.exists():
        return destination

    for index in range(2, 1000):
        candidate = destination_dir / f"{prefix}_{index}__{source.name}"
        if not candidate.exists():
            return candidate
    raise RuntimeError(f"Could not find a unique collected filename for {source}")


def move_tree_files(source_dir: Path, destination_dir: Path, image_only: bool) -> int:
    moved = 0
    if not source_dir.exists():
        return moved
    for source in sorted(path for path in source_dir.rglob("*") if path.is_file()):
        is_image = source.suffix.lower() in IMAGE_EXTENSIONS
        if image_only != is_image:
            continue
        destination = collected_file_destination(source, source_dir, destination_dir)
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(source), str(destination))
        moved += 1
    return moved


def organize_collected_outputs(
    completed_items: list[PlannedAnalysis],
    output_root: Path,
) -> dict[str, Any]:
    collection_root = output_root / COLLECTED_OUTCOME_DIR
    if collection_root.exists():
        shutil.rmtree(collection_root)
    collection_root.mkdir(parents=True, exist_ok=True)

    other_count = 0
    image_count = 0
    for item in tqdm(completed_items, desc="Collecting outputs", unit="outcome"):
        source_dir = output_dir_for_item(item, output_root)
        outcome_dir = collected_outcome_dir_for_item(item, output_root)
        image_count += move_tree_files(source_dir, outcome_dir / OUTCOME_IMAGE_DIR, image_only=True)
        other_count += move_tree_files(source_dir, outcome_dir / OUTCOME_OTHER_DIR, image_only=False)
        if source_dir.exists():
            shutil.rmtree(source_dir)

    report_dir = collection_root / REPORT_DIR
    report_dir.mkdir(parents=True, exist_ok=True)

    return {
        "collection_root": collection_root,
        "report_dir": report_dir,
        "additional_info_count": other_count,
        "image_count": image_count,
    }


def read_snippet(path: Path, max_chars: int = 5000) -> str:
    if not path.exists():
        return ""
    text = path.read_text(encoding="utf-8", errors="replace")
    if len(text) <= max_chars:
        return text
    return text[:max_chars].rstrip() + "\n[truncated]"


def read_json_if_exists(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8", errors="replace"))
    except json.JSONDecodeError:
        return {}


def numeric(value: Any) -> float | None:
    try:
        if value is None or value == "":
            return None
        parsed = float(value)
    except (TypeError, ValueError):
        return None
    if math.isnan(parsed):
        return None
    return parsed


def format_percent(value: float) -> str:
    return f"{100 * value:.2f}%"


def format_p_value(value: Any) -> str:
    text = " ".join(str(value or "").strip().split())
    if not text:
        return ""
    if text.startswith(("<", ">", "=")):
        return f"p {text}"
    return f"p = {text}"


def binary_absolute_rate_summary(output_dir: Path, mapping: dict[str, Any]) -> list[str]:
    csv_path = output_dir / "extracted-binary-data.csv"
    if not csv_path.exists():
        return []
    rows: list[dict[str, str]] = []
    with csv_path.open(newline="", encoding="utf-8-sig", errors="replace") as handle:
        reader = csv.DictReader(handle)
        if not reader.fieldnames:
            return []
        required = {"event.e", "n.e", "event.c", "n.c"}
        if not required.issubset(set(reader.fieldnames)):
            return []
        rows = list(reader)
    if not rows:
        return []

    intervention = str(mapping.get("intervention_label") or "intervention")
    control = str(mapping.get("control_label") or "control")
    subgroup_r_columns = [
        str(item.get("r_column"))
        for item in mapping.get("subgroup_r_columns") or []
        if item.get("r_column")
    ]

    def summarize(label: str, group_rows: list[dict[str, str]]) -> str | None:
        e_events = sum(numeric(row.get("event.e")) or 0 for row in group_rows)
        e_total = sum(numeric(row.get("n.e")) or 0 for row in group_rows)
        c_events = sum(numeric(row.get("event.c")) or 0 for row in group_rows)
        c_total = sum(numeric(row.get("n.c")) or 0 for row in group_rows)
        if e_total <= 0 or c_total <= 0:
            return None
        e_rate = e_events / e_total
        c_rate = c_events / c_total
        ard = c_rate - e_rate
        se = math.sqrt((e_rate * (1 - e_rate) / e_total) + (c_rate * (1 - c_rate) / c_total))
        ci_low = ard - 1.96 * se
        ci_high = ard + 1.96 * se
        return (
            f"{label}: {intervention} {format_percent(e_rate)} ({e_events:.0f}/{e_total:.0f}); "
            f"{control} {format_percent(c_rate)} ({c_events:.0f}/{c_total:.0f}); "
            f"absolute risk difference ({control} minus {intervention}) {100 * ard:.2f} percentage points "
            f"(approximate 95% CI {100 * ci_low:.2f} to {100 * ci_high:.2f})."
        )

    summaries = []
    overall = summarize("Overall absolute rates", rows)
    if overall:
        summaries.append(overall)

    for subgroup_col in subgroup_r_columns:
        values = sorted({str(row.get(subgroup_col) or "").strip() for row in rows if str(row.get(subgroup_col) or "").strip()})
        if not values or len(values) > 10:
            continue
        for value in values:
            subgroup_rows = [row for row in rows if str(row.get(subgroup_col) or "").strip() == value]
            subgroup_summary = summarize(f"Absolute rates for {subgroup_col}={value}", subgroup_rows)
            if subgroup_summary:
                summaries.append(subgroup_summary)
    return summaries


def p_value_to_float(value: Any) -> float | None:
    text = str(value or "").strip().lower()
    if not text:
        return None
    text = text.replace("p-value", "").replace("p =", "").replace("p=", "").replace("p-val =", "")
    text = text.replace("p-val", "").replace("p", "").strip()
    text = text.replace("<", "").replace(">", "").replace("=", "").strip()
    if text.startswith("."):
        text = "0" + text
    try:
        return float(text)
    except ValueError:
        return None


def ci_to_floats(ci: str) -> tuple[float, float] | None:
    match = re.search(r"\[\s*([-+]?\d*\.?\d+)\s*[;,]\s*([-+]?\d*\.?\d+)\s*\]", str(ci or ""))
    if not match:
        return None
    return float(match.group(1)), float(match.group(2))


def measure_null_value(measure: str) -> float | None:
    normalized = normalize_name(measure)
    if any(token in normalized for token in ("rr", "or", "hr", "dor", "riskratio", "oddsratio", "hazardratio")):
        return 1.0
    if any(token in normalized for token in ("md", "smd", "rd", "riskdifference", "meandifference")):
        return 0.0
    return None


def first_output_file(output_dir: Path, predicate: Any) -> Path | None:
    matches = sorted(path for path in output_dir.rglob("*") if path.is_file() and predicate(path))
    return matches[0] if matches else None


def output_files(output_dir: Path, predicate: Any) -> list[Path]:
    return sorted(path for path in output_dir.rglob("*") if path.is_file() and predicate(path))


def extract_summary_measure(summary_text: str, mapping: dict[str, Any]) -> str:
    analysis = mapping.get("analysis") or {}
    if analysis.get("summary_measure"):
        return str(analysis["summary_measure"])
    for line in summary_text.splitlines():
        if "95%-CI" in line:
            tokens = line.split()
            try:
                index = tokens.index("95%-CI")
            except ValueError:
                continue
            if index > 0:
                return tokens[index - 1]
    return "effect"


def parse_pooled_summary(summary_text: str, mapping: dict[str, Any]) -> dict[str, Any]:
    summary_text = summary_text or ""
    result: dict[str, Any] = {"measure": extract_summary_measure(summary_text, mapping)}
    patterns = {
        "studies": r"Number of studies:\s+k\s+=\s+(\d+)",
        "observations": r"Number of observations:\s+(.+)",
        "events": r"Number of events:\s+(.+)",
        "tau": r"(tau\^2\s+=\s+.+)",
        "i2": r"(I\^2\s+=\s+[^;\n]+(?:;\s*H\s+=\s*[-+]?\d*\.?\d+)?)",
        "heterogeneity_q": r"Test of heterogeneity:\s*\n\s*Q\s+d\.f\.\s+p-value\s*\n\s*([^\n]+)",
    }
    for key, pattern in patterns.items():
        match = re.search(pattern, summary_text, flags=re.I)
        if match:
            result[key] = " ".join(match.group(1).split())
    if result.get("heterogeneity_q"):
        q_parts = str(result["heterogeneity_q"]).split()
        if len(q_parts) >= 3:
            p_text = " ".join(q_parts[2:])
            result["heterogeneity_q"] = f"Q = {q_parts[0]}; df = {q_parts[1]}; {format_p_value(p_text)}"

    model_match = re.search(
        r"((?:Random effects|Common effect|Fixed effect) model)\s+"
        r"([-+]?\d*\.?\d+)\s+\[\s*([-+]?\d*\.?\d+)\s*[;,]\s*([-+]?\d*\.?\d+)\s*\]"
        r"(?:\s+([-+]?\d*\.?\d+)\s+([<>=]?\s*\.?\d+(?:\.\d+)?))?",
        summary_text,
        flags=re.I,
    )
    if model_match:
        result.update(
            {
                "model": model_match.group(1),
                "effect": model_match.group(2),
                "ci": f"[{model_match.group(3)}; {model_match.group(4)}]",
                "z": model_match.group(5) or "",
                "p": " ".join((model_match.group(6) or "").split()),
            }
        )
    prediction_match = re.search(r"Prediction interval\s+\[\s*([-+]?\d*\.?\d+)\s*[;,]\s*([-+]?\d*\.?\d+)\s*\]", summary_text, flags=re.I)
    if prediction_match:
        result["prediction_interval"] = f"[{prediction_match.group(1)}; {prediction_match.group(2)}]"

    null_value = measure_null_value(result["measure"])
    ci_values = ci_to_floats(result.get("ci", ""))
    effect_value = numeric(result.get("effect"))
    p_float = p_value_to_float(result.get("p"))
    if null_value is not None and ci_values:
        low, high = ci_values
        result["ci_crosses_null"] = low <= null_value <= high
    if effect_value is not None and null_value is not None:
        if effect_value > null_value:
            result["direction_vs_null"] = "above the null"
        elif effect_value < null_value:
            result["direction_vs_null"] = "below the null"
        else:
            result["direction_vs_null"] = "at the null"
    if p_float is not None:
        result["statistically_significant"] = p_float < 0.05
    return result


def parse_subgroup_summary(text: str, label: str) -> dict[str, Any]:
    rows: list[dict[str, str]] = []
    for line in (text or "").splitlines():
        match = re.match(
            r"^\s*Subgroup\s*=\s*(.+?)\s+(\d+)\s+([-+]?\d*\.?\d+)\s+\[\s*([-+]?\d*\.?\d+)\s*[;,]\s*([-+]?\d*\.?\d+)\s*\]",
            line,
        )
        if match:
            rows.append(
                {
                    "level": match.group(1).strip(),
                    "k": match.group(2),
                    "effect": match.group(3),
                    "ci": f"[{match.group(4)}; {match.group(5)}]",
                }
            )
    test_match = re.search(r"Between groups\s+[-+]?\d*\.?\d+\s+\d+\s+([<>=]?\s*\.?\d+(?:\.\d+)?)", text or "", flags=re.I)
    return {
        "label": label,
        "levels": rows,
        "test_for_subgroup_differences_p": " ".join(test_match.group(1).split()) if test_match else "",
    }


def parse_egger_summary(text: str) -> dict[str, Any]:
    compact = " ".join(line.strip() for line in (text or "").splitlines() if line.strip())
    if not compact:
        return {"available": False, "sentence": "Funnel plot/Egger-test output was not available."}
    if "skipped" in compact.lower() or "fewer than 10" in compact.lower():
        return {"available": False, "sentence": compact}
    p_match = re.search(r"p-value\s*=\s*([<>=]?\s*\.?\d+(?:\.\d+)?)", compact, flags=re.I)
    t_match = re.search(r"t\s*=\s*([-+]?\d*\.?\d+)", compact, flags=re.I)
    df_match = re.search(r"df\s*=\s*(\d+)", compact, flags=re.I)
    p_text = " ".join(p_match.group(1).split()) if p_match else ""
    p_float = p_value_to_float(p_text)
    if p_text:
        interpretation = "evidence of funnel-plot asymmetry" if p_float is not None and p_float < 0.05 else "no statistical evidence of funnel-plot asymmetry"
        pieces = [f"Egger test showed {interpretation} ({format_p_value(p_text)}"]
        if t_match:
            pieces.append(f"; t = {t_match.group(1)}")
        if df_match:
            pieces.append(f"; df = {df_match.group(1)}")
        sentence = "".join(pieces) + ")."
    else:
        sentence = compact
    return {"available": True, "p": p_text, "sentence": sentence, "raw": compact}


def parse_metareg_summary(text: str, label: str = "") -> dict[str, Any]:
    compact = " ".join(line.rstrip() for line in (text or "").splitlines() if line.strip())
    if not compact:
        return {"available": False, "sentence": "Meta-regression output was not available."}
    if "skipped" in compact.lower():
        prefix = f"{label}: " if label else ""
        return {"available": False, "label": label, "sentence": prefix + compact}
    moderator_match = re.search(r"Test of Moderators.*?QM\(df\s*=\s*(\d+)\)\s*=\s*([-+]?\d*\.?\d+),\s*p-val\s*([<>=])?\s*(\.?\d+(?:\.\d+)?)", compact, flags=re.I)
    coefficient_match = re.search(
        r"\b(?!intrcpt\b)([A-Za-z][\w.]*)\s+([-+]?\d*\.?\d+)\s+([-+]?\d*\.?\d+)\s+([-+]?\d*\.?\d+)\s+([<>=]?\s*\.?\d+(?:\.\d+)?)\s+([-+]?\d*\.?\d+)\s+([-+]?\d*\.?\d+)",
        compact,
    )
    sentence = compact
    if moderator_match:
        comparator = moderator_match.group(3) or "="
        p_text = f"{comparator} {moderator_match.group(4)}".replace("= ", "").strip()
        p_float = p_value_to_float(p_text)
        interpretation = "statistically significant" if p_float is not None and p_float < 0.05 else "not statistically significant"
        prefix = f"{label}: " if label else ""
        sentence = (
            f"{prefix}Meta-regression moderator testing was {interpretation} "
            f"(QM[df = {moderator_match.group(1)}] = {moderator_match.group(2)}, {format_p_value(p_text)})."
        )
        if coefficient_match:
            sentence += (
                f" The covariate coefficient was {coefficient_match.group(2)} "
                f"(95% CI {coefficient_match.group(6)} to {coefficient_match.group(7)}, {format_p_value(coefficient_match.group(5))})."
            )
    return {"available": True, "label": label, "sentence": sentence, "raw": compact}


def parse_metareg_summaries(output_dir: Path) -> list[dict[str, Any]]:
    summaries = []
    for path in output_files(output_dir, lambda path: path.name.startswith("MetaregSummary") and path.suffix.lower() == ".txt"):
        label = path.stem
        label = re.sub(r"^MetaregSummary\s*-\s*", "", label).strip()
        summaries.append(parse_metareg_summary(read_snippet(path, max_chars=16000), label))
    return summaries


def parse_leave_one_out(text: str, pooled: dict[str, Any]) -> dict[str, Any]:
    rows: list[dict[str, Any]] = []
    for line in (text or "").splitlines():
        match = re.match(
            r"^\s*Omitting\s+(.+?)\s+([-+]?\d*\.?\d+)\s+\[\s*([-+]?\d*\.?\d+)\s*[;,]\s*([-+]?\d*\.?\d+)\s*\]\s+([<>=]?\s*\.?\d+(?:\.\d+)?)",
            line,
        )
        if match:
            rows.append(
                {
                    "study": match.group(1).strip(),
                    "effect": float(match.group(2)),
                    "ci": f"[{match.group(3)}; {match.group(4)}]",
                    "p": " ".join(match.group(5).split()),
                }
            )
    if not rows:
        return {"available": False, "sentence": "Leave-one-out sensitivity output was not available."}
    effects = [row["effect"] for row in rows]
    p_values = [p_value_to_float(row["p"]) for row in rows]
    nonsignificant = sum(1 for value in p_values if value is not None and value >= 0.05)
    null_value = measure_null_value(str(pooled.get("measure", "")))
    crosses_null = 0
    if null_value is not None:
        for row in rows:
            ci_values = ci_to_floats(row["ci"])
            if ci_values and ci_values[0] <= null_value <= ci_values[1]:
                crosses_null += 1
    pooled_effect = numeric(pooled.get("effect"))
    influential = None
    if pooled_effect is not None:
        influential = max(rows, key=lambda row: abs(row["effect"] - pooled_effect))
    sentence = (
        f"Leave-one-out pooled estimates ranged from {min(effects):.4g} to {max(effects):.4g} "
        f"across {len(rows)} omissions."
    )
    if null_value is not None:
        sentence += f" {crosses_null} omission-specific confidence interval(s) crossed the null."
    if any(value is not None for value in p_values):
        sentence += f" {nonsignificant} omission-specific p value(s) were >= 0.05."
    if influential:
        sentence += f" The largest absolute shift occurred when omitting {influential['study']} (estimate {influential['effect']:.4g})."
    return {"available": True, "rows": rows, "sentence": sentence}


def parse_baujat_coordinates(path: Path | None) -> dict[str, Any]:
    if not path or not path.exists():
        return {"available": False, "sentence": "Baujat coordinate output was not available."}
    rows: list[dict[str, Any]] = []
    with path.open(newline="", encoding="utf-8-sig", errors="replace") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            x = numeric(row.get("x"))
            y = numeric(row.get("y"))
            if x is None or y is None:
                continue
            rows.append({"study": row.get("studlab") or row.get("Study") or "", "x": x, "y": y})
    if not rows:
        return {"available": False, "sentence": "Baujat coordinate output was present but did not contain usable coordinates."}
    top_x = sorted(rows, key=lambda row: row["x"], reverse=True)[:3]
    top_y = sorted(rows, key=lambda row: row["y"], reverse=True)[:3]
    x_sentence = ", ".join(f"{row['study']} (x = {row['x']:.3g})" for row in top_x)
    y_sentence = ", ".join(f"{row['study']} (y = {row['y']:.3g})" for row in top_y)
    return {
        "available": True,
        "top_heterogeneity": top_x,
        "top_influence": top_y,
        "sentence": (
            "Baujat diagnostics identified the largest contributors to heterogeneity as "
            f"{x_sentence}; the largest influences on the pooled estimate were {y_sentence}."
        ),
    }


def parse_tsa_outputs(output_dir: Path) -> dict[str, Any]:
    notes_path = first_output_file(output_dir, lambda path: path.name.startswith("TSANotes") and path.suffix.lower() == ".txt")
    audit_txt = first_output_file(output_dir, lambda path: path.name.startswith("TSAAudit") and path.suffix.lower() == ".txt")
    audit_csv = first_output_file(output_dir, lambda path: path.name.startswith("TSAAudit") and path.suffix.lower() == ".csv")
    parameters_txt = first_output_file(output_dir, lambda path: path.name.startswith("TSAParameters") and path.suffix.lower() == ".txt")
    parameters_csv = first_output_file(output_dir, lambda path: path.name.startswith("TSAParameters") and path.suffix.lower() == ".csv")
    audit_sentence = ""
    if audit_txt:
        compact_audit = " ".join(line.strip() for line in read_snippet(audit_txt, max_chars=1400).splitlines() if line.strip())
        audit_sentence = f" TSA audit: {compact_audit}"
    elif audit_csv:
        audit_sentence = f" TSA audit generated ({read_snippet(audit_csv, max_chars=600).replace(chr(10), '; ')})."
    if notes_path:
        compact = " ".join(line.strip() for line in read_snippet(notes_path, max_chars=1800).splitlines() if line.strip())
        return {"available": True, "sentence": f"Trial sequential analysis notes: {compact}{audit_sentence}"}
    if parameters_txt:
        compact = " ".join(line.strip() for line in read_snippet(parameters_txt, max_chars=1800).splitlines() if line.strip())
        return {"available": True, "sentence": f"Trial sequential analysis parameters were generated. {compact}{audit_sentence}"}
    if parameters_csv:
        preview = read_snippet(parameters_csv, max_chars=800).replace("\n", "; ")
        return {"available": True, "sentence": f"Trial sequential analysis parameter output was generated ({preview}).{audit_sentence}"}
    if audit_sentence:
        return {"available": True, "sentence": f"Trial sequential analysis audit was generated.{audit_sentence}"}
    return {"available": False, "sentence": "Trial sequential analysis output was not available."}


def extract_statistical_report_data(output_dir: Path, mapping: dict[str, Any], figure_dir: Path | None = None) -> dict[str, Any]:
    summary_path = first_output_file(
        output_dir,
        lambda path: path.parent == output_dir
        and path.name.startswith("Summary")
        and path.suffix.lower() == ".txt"
        and not path.name.startswith(("SubgroupSummary", "SummarySensitivity", "SummarySpecificity", "SummaryDOR")),
    )
    summary_text = read_snippet(summary_path, max_chars=20000) if summary_path else ""
    pooled = parse_pooled_summary(summary_text, mapping)
    subgroup_results = [
        parse_subgroup_summary(
            read_snippet(path, max_chars=20000),
            path.stem.replace("SubgroupSummary - ", ""),
        )
        for path in output_files(output_dir, lambda path: path.name.startswith("SubgroupSummary") and path.suffix.lower() == ".txt")
    ]
    leave_one_out_path = first_output_file(output_dir, lambda path: path.name.startswith("LeaveOneOutSummary") and path.suffix.lower() == ".txt")
    egger_path = first_output_file(output_dir, lambda path: path.name.startswith("EggerTest") and path.suffix.lower() == ".txt")
    baujat_path = first_output_file(output_dir, lambda path: path.name.startswith("BaujatCoordinates") and path.suffix.lower() == ".csv")
    figure_search_dir = figure_dir or output_dir
    funnel_generated = any(path.name.startswith(("FunnelPlot", "EggerTest")) and path.suffix.lower() in IMAGE_EXTENSIONS for path in figure_search_dir.rglob("*"))
    baujat_generated = any(path.name.startswith("BaujatPlot") and path.suffix.lower() in IMAGE_EXTENSIONS for path in figure_search_dir.rglob("*"))
    return {
        "summary_file": str(summary_path.relative_to(output_dir)) if summary_path else "",
        "pooled": pooled,
        "subgroups": subgroup_results,
        "leave_one_out": parse_leave_one_out(read_snippet(leave_one_out_path, max_chars=20000) if leave_one_out_path else "", pooled),
        "egger": parse_egger_summary(read_snippet(egger_path, max_chars=12000) if egger_path else ""),
        "metareg": parse_metareg_summaries(output_dir),
        "baujat": parse_baujat_coordinates(baujat_path),
        "tsa": parse_tsa_outputs(output_dir),
        "funnel_plot_generated": funnel_generated,
        "baujat_plot_generated": baujat_generated,
    }


def outcome_report_context(item: PlannedAnalysis, output_root: Path) -> dict[str, Any]:
    output_dir = report_data_dir_for_item(item, output_root)
    figure_dir = report_figure_dir_for_item(item, output_root)
    mapping = read_json_if_exists(output_dir / "identified-columns.json")
    if not mapping:
        mapping = read_json_if_exists(output_dir / "identified-network-columns.json")

    text_files = []
    for path in sorted(output_dir.rglob("*.txt")):
        if path.name == "run-info.txt":
            continue
        text_files.append(
            {
                "path": str(path.relative_to(output_dir)),
                "content": read_snippet(path, max_chars=3500),
            }
        )
        if len(text_files) >= 12:
            break

    csv_files = []
    for path in sorted(output_dir.rglob("*.csv")):
        csv_files.append({"path": str(path.relative_to(output_dir)), "preview": read_snippet(path, max_chars=1800)})
        if len(csv_files) >= 8:
            break

    figures = [str(path.relative_to(figure_dir)) for path in sorted(figure_dir.rglob("*")) if path.is_file() and path.suffix.lower() in IMAGE_EXTENSIONS]

    return {
        "index": item.index,
        "sheet": item.sheet,
        "outcome_name": item.outcome_name,
        "analysis_type": item.analysis_type,
        "analysis_label": item.label,
        "comparison": {
            "intervention_label": mapping.get("intervention_label"),
            "control_label": mapping.get("control_label"),
            "network_engine": item.network_engine,
            "diagnostic_mode": item.diagnostic_mode,
        },
        "analysis_choices": mapping.get("analysis", {}),
        "statistical_results": extract_statistical_report_data(output_dir, mapping, figure_dir),
        "absolute_rates_if_binary": binary_absolute_rate_summary(output_dir, mapping),
        "summary_text_outputs": text_files,
        "csv_previews": csv_files,
        "generated_figures": figures,
    }


def figure_plot_type(path: str) -> str:
    normalized = normalize_name(Path(path).stem)
    if "forestplot" in normalized:
        return "Forest plot"
    if "subgroup" in normalized:
        return "Subgroup forest plot"
    if "funnelplot" in normalized:
        return "Funnel plot"
    if "baujatplot" in normalized:
        return "Baujat plot"
    if "leaveoneout" in normalized:
        return "Leave-one-out sensitivity plot"
    if "metarregression" in normalized or "metaregression" in normalized:
        return "Meta-regression bubble plot"
    if "tsa" in normalized or "adjustedboundaries" in normalized:
        return "Trial Sequential Analysis plot"
    return "Analysis figure"


def figure_legend_items(outcomes: list[dict[str, Any]]) -> list[dict[str, str]]:
    items: list[dict[str, str]] = []
    figure_number = 1
    for outcome in outcomes:
        for figure in outcome.get("generated_figures") or []:
            plot_type = figure_plot_type(str(figure))
            items.append(
                {
                    "figure": f"Figure {figure_number}",
                    "outcome": str(outcome.get("outcome_name") or ""),
                    "plot_type": plot_type,
                    "filename": str(figure),
                    "legend": f"{plot_type} for {outcome.get('outcome_name')}.",
                }
            )
            figure_number += 1
    return items


def analysis_inventory(outcomes: list[dict[str, Any]]) -> dict[str, Any]:
    binary = [outcome for outcome in outcomes if outcome.get("analysis_type") == "binary_pairwise"]
    continuous = [outcome for outcome in outcomes if outcome.get("analysis_type") == "continuous_pairwise"]
    choices = [outcome.get("analysis_choices") or {} for outcome in outcomes]
    stats = [outcome.get("statistical_results") or {} for outcome in outcomes]
    return {
        "outcome_count": len(outcomes),
        "binary_pairwise_count": len(binary),
        "continuous_pairwise_count": len(continuous),
        "effect_measures": sorted({str(choice.get("summary_measure")) for choice in choices if choice.get("summary_measure")}),
        "pooling_methods": sorted({str(choice.get("pooling_method")) for choice in choices if choice.get("pooling_method")}),
        "model_types": sorted({str(choice.get("model_type")) for choice in choices if choice.get("model_type")}),
        "subgroup_analysis_done": any((stat.get("subgroups") for stat in stats)),
        "leave_one_out_done": any((stat.get("leave_one_out") or {}).get("available") for stat in stats),
        "funnel_or_egger_done": any(stat.get("funnel_plot_generated") or (stat.get("egger") or {}).get("available") for stat in stats),
        "baujat_done": any(stat.get("baujat_plot_generated") or (stat.get("baujat") or {}).get("available") for stat in stats),
        "meta_regression_done": any((stat.get("metareg") for stat in stats)),
        "tsa_done": any((stat.get("tsa") or {}).get("available") for stat in stats),
    }


def llm_report_prompt(workbook: Path, outcomes: list[dict[str, Any]], figures: list[dict[str, str]] | None = None) -> dict[str, Any]:
    return {
        "task": (
            "Write manuscript-ready Methods and Results sections for the completed meta-analysis outcomes. "
            "Synthesize the findings into a clear, objective clinical narrative. "
            "Interpret the statistical outputs (such as stability, temporal trends, and RTSA output status) carefully, maintaining the reserved, scientific tone of a top-tier medical journal. Do not overexaggerate or sensationalize the findings. "
            "Use PRISMA 2020 as the reporting scaffold (checklist items 5-15 for Methods and 16-22 for Results). "
            "Ensure the Results section reads as one continuous, professional manuscript narrative."
        ),
        "analysis_inventory": analysis_inventory(outcomes),
        "prisma_2020_sources": PRISMA_2020_SOURCES,
        "prisma_2020_methods_frame": PRISMA_2020_METHODS_FRAME,
        "prisma_2020_results_frame": PRISMA_2020_RESULTS_FRAME,
        "writing_structure": [
            "Start with '# Methods'. Use short PRISMA-aligned subheadings (Eligibility, Search Strategy, Selection, Bias Assessment, Data Items, Statistical Synthesis).",
            "In Statistical Synthesis, describe Trial Sequential Analysis (TSA) using only the recorded RTSA engine, RIS, timing, and monitoring-boundary fields, as well as the use of leave-one-out and influence diagnostics (Baujat/GOSH) to test finding stability.",
            "Then write '# Results'. Begin with study selection/flow (item 16) and baseline characteristics (items 17-18).",
            "For individual outcomes (item 20), synthesize the results into a professional narrative. Discuss pooled effects, heterogeneity, and meta-regression trends.",
            "Objectively report RTSA output status and sensitivity analyses (finding stability) for each primary outcome without overstatement.",
            "End with '## Figure Legends' and list the supplied numbered figures.",
        ],
        "rules": [
            "Use only statistics present in the supplied output context.",
            "Do not invent confidence intervals, subgroup p-values, absolute rates, or sample sizes.",
            "Do not invent search dates, database names, screening counts, PRISMA counts, study-design counts, or risk-of-bias judgments.",
            "Do not claim PRISMA compliance beyond what the supplied context supports; instead identify missing review-level items as requiring completion from protocol/search/screening records.",
            "If an approximate absolute risk difference is supplied, label it as approximate unless the R output gives a pooled RD.",
            "Use the known intervention/control labels when available; otherwise describe the comparison generically.",
            "For p values >= 0.05, phrase as no statistically significant difference/effect.",
            "For p values < 0.05, phrase as statistically significant and state the direction.",
            "Report effect measure, 95% CI, p value, and I2 whenever available.",
            "Mention subgroup differences only if the subgroup output contains a test for subgroup differences.",
            "Mention Baujat, funnel/Egger, meta-regression, leave-one-out, and TSA findings whenever those outputs are available.",
            "If a specific analysis was skipped, unavailable, or failed for an outcome, state that only when the status files or output text say so; otherwise omit that analysis for that outcome.",
            "Keep interpretation statistical: describe significance, heterogeneity, influence, and stability without adding clinical claims.",
            "Keep the report clinically neutral and suitable for a journal Results section.",
            "The final figure legends must use the figure numbering supplied in figure_manifest and must name the outcome and plot type.",
        ],
        "workbook": str(workbook),
        "outcomes": outcomes,
        "figure_manifest": figures or figure_legend_items(outcomes),
        "return_format": "Markdown with Methods, Results, and a final Figure Legends subsection.",
    }


def llm_single_outcome_prompt(workbook: Path, outcome: dict[str, Any]) -> dict[str, Any]:
    return {
        "task": (
            "Write a publication-ready manuscript Results subsection for this single completed meta-analysis outcome. "
            "Synthesize the findings into a polished, objective clinical narrative. "
            "Provide clear interpretation of the statistics, but strictly avoid overexaggerating the findings. Use reserved, scientific language typical of high-quality journals. "
            "Use PRISMA 2020 Results item 20 as the reporting frame."
        ),
        "prisma_2020_sources": PRISMA_2020_SOURCES,
        "prisma_2020_results_frame": PRISMA_2020_RESULTS_FRAME,
        "required_content": [
            "Start with the primary pooled analysis; state the direction of effect and its statistical/clinical significance.",
            "Report the key effect measure, 95% CI, p-value, and number of contributing studies.",
            "Assess heterogeneity (I2, chi-squared) and interpret whether the findings are consistent across trials.",
            "Critically analyze finding stability using the supplied leave-one-out sensitivity, Baujat, and GOSH diagnostics. Objectively report if the pooled result depends on outliers.",
            "Interpret Trial Sequential Analysis (TSA) using only the recorded RTSA inference status; report monitoring-boundary assessment only when integrated RTSA output provided one, and otherwise state that no RTSA boundary assessment was generated.",
            "Analyze meta-regression trends (e.g., temporal stability by publication year) and subgroup differences when available.",
            "Briefly mention funnel plot asymmetry or Egger's test results regarding potential reporting bias.",
            "Mention generated plots only as supporting evidence; prioritize describing the *meaning* of the statistical patterns.",
        ],
        "rules": [
            "Use only supplied statistics and generated-file inventory.",
            "Do not invent confidence intervals, p values, subgroup effects, sample sizes, or plot findings.",
            "Keep language suitable for a journal Results section and clinically neutral.",
            "Use concise professional prose, usually one to three paragraphs.",
            "Do not include methods explanations unless needed to identify an analysis output.",
        ],
        "workbook": str(workbook),
        "outcome": outcome,
        "return_format": "Markdown with one level-2 heading for the outcome followed by manuscript-ready prose.",
    }


def format_effect_result(pooled: dict[str, Any]) -> str:
    measure = pooled.get("measure") or "effect"
    effect = pooled.get("effect")
    ci = pooled.get("ci")
    p_value = pooled.get("p")
    if not effect:
        return "The pooled effect estimate was not available in the parsed summary output."
    sentence = f"The pooled {measure} was {effect}"
    if ci:
        sentence += f" (95% CI {ci})"
    if p_value:
        sentence += f", {format_p_value(p_value)}"
    sentence += "."
    significant = pooled.get("statistically_significant")
    crosses_null = pooled.get("ci_crosses_null")
    direction = pooled.get("direction_vs_null")
    if significant is True:
        sentence += f" Statistically, the pooled estimate was significant and {direction}."
    elif significant is False:
        sentence += " Statistically, the pooled estimate was not significant."
    elif crosses_null is not None:
        sentence += " The confidence interval crossed the null." if crosses_null else " The confidence interval excluded the null."
    return sentence


def format_heterogeneity_result(pooled: dict[str, Any]) -> str:
    pieces = []
    if pooled.get("studies"):
        pieces.append(f"{pooled['studies']} studies")
    if pooled.get("observations"):
        pieces.append(str(pooled["observations"]))
    if pooled.get("events"):
        pieces.append(str(pooled["events"]))
    study_sentence = f"The analysis included {', '.join(pieces)}." if pieces else ""
    heterogeneity = []
    if pooled.get("i2"):
        heterogeneity.append(str(pooled["i2"]))
    if pooled.get("tau"):
        heterogeneity.append(str(pooled["tau"]))
    if pooled.get("heterogeneity_q"):
        heterogeneity.append(f"Q test: {pooled['heterogeneity_q']}")
    if pooled.get("prediction_interval"):
        heterogeneity.append(f"prediction interval {pooled['prediction_interval']}")
    if heterogeneity:
        return " ".join(part for part in [study_sentence, "Heterogeneity statistics were " + "; ".join(heterogeneity) + "."] if part)
    return study_sentence


def format_subgroup_results(subgroups: list[dict[str, Any]]) -> list[str]:
    sentences = []
    for subgroup in subgroups:
        levels = subgroup.get("levels") or []
        if not levels:
            sentences.append(f"{subgroup['label']}: subgroup output was generated, but pooled subgroup rows were not parsed.")
            continue
        level_text = "; ".join(
            f"{row['level']} (k = {row['k']}, estimate {row['effect']}, 95% CI {row['ci']})"
            for row in levels[:8]
        )
        if len(levels) > 8:
            level_text += f"; {len(levels) - 8} additional subgroup level(s) reported in the source output"
        p_value = subgroup.get("test_for_subgroup_differences_p")
        if p_value:
            p_float = p_value_to_float(p_value)
            interpretation = "statistically significant" if p_float is not None and p_float < 0.05 else "not statistically significant"
            sentences.append(
                f"{subgroup['label']}: subgroup estimates were {level_text}. "
                f"The test for subgroup differences was {interpretation} ({format_p_value(p_value)})."
            )
        else:
            sentences.append(f"{subgroup['label']}: subgroup estimates were {level_text}.")
    return sentences


def deterministic_outcome_report(outcome: dict[str, Any]) -> list[str]:
    stats = outcome.get("statistical_results") or {}
    pooled = stats.get("pooled") or {}
    lines = [f"## {outcome['outcome_name']}", ""]
    lines.append(
        f"{outcome['analysis_label']} analysis. "
        + format_heterogeneity_result(pooled)
        + " "
        + format_effect_result(pooled)
    )
    for rate in outcome.get("absolute_rates_if_binary") or []:
        lines.append(rate)
    subgroup_sentences = format_subgroup_results(stats.get("subgroups") or [])
    if subgroup_sentences:
        lines.append("Subgroup analysis: " + " ".join(subgroup_sentences))
    else:
        lines.append("Subgroup analysis was not available or was not generated for this outcome.")

    loo = stats.get("leave_one_out") or {}
    if loo.get("sentence"):
        lines.append("Leave-one-out sensitivity analysis: " + loo["sentence"])

    baujat = stats.get("baujat") or {}
    if baujat.get("sentence"):
        prefix = "Baujat plot analysis: " if stats.get("baujat_plot_generated") or baujat.get("available") else "Baujat analysis: "
        lines.append(prefix + baujat["sentence"])

    egger = stats.get("egger") or {}
    if stats.get("funnel_plot_generated"):
        lines.append("Funnel plot/small-study effects: Funnel plot output was generated. " + egger.get("sentence", "Egger-test output was not available."))
    elif egger.get("sentence"):
        lines.append("Small-study effects: " + egger["sentence"])

    metareg = stats.get("metareg") or []
    if isinstance(metareg, dict):
        metareg = [metareg]
    metareg_sentences = [item.get("sentence") for item in metareg if item.get("sentence")]
    if metareg_sentences:
        lines.append("Meta-regression: " + " ".join(metareg_sentences))

    tsa = stats.get("tsa") or {}
    if tsa.get("available") and tsa.get("sentence"):
        lines.append("Trial sequential analysis: " + tsa["sentence"])

    return lines


def deterministic_outcome_markdown(outcome: dict[str, Any]) -> str:
    return "\n".join(deterministic_outcome_report(outcome)).strip() + "\n"


def call_lmstudio_report(
    prompt: dict[str, Any],
    lmstudio_url: str,
    model: str | None,
) -> str | None:
    resolved_model = common.resolve_lmstudio_model(lmstudio_url, model)
    if not resolved_model:
        return None

    body = {
        "model": resolved_model,
        "messages": [
            {
                "role": "system",
                "content": (
                    "You are an Expert Clinical Meta-Analysis Manuscript Writer. "
                    "Synthesize the supplied statistical outputs into a professional Results narrative. "
                    "Prioritize objective interpretation: discuss findings in terms of statistical stability, RTSA output status, and temporal trends. "
                    "Follow PRISMA 2020 reporting logic. Maintain strict scientific objectivity. Do not overexaggerate findings or use sensationalized language."
                ),
            },
            {"role": "user", "content": json.dumps(prompt, default=str)},
        ],
        "temperature": 0.2,
    }
    request = urllib.request.Request(
        common.chat_completions_url(lmstudio_url),
        data=json.dumps(body).encode("utf-8"),
        headers=common.llm_request_headers(include_content_type=True),
        method="POST",
    )
    try:
        with urllib.request.urlopen(request) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        print(f"LMStudio report generation failed ({common.lmstudio_error_message(exc)}).")
        return None
    except Exception as exc:
        print(f"LMStudio report generation failed ({exc}).")
        return None
    return str(payload["choices"][0]["message"]["content"]).strip()


def generate_outcome_manuscript_narrative(
    item: PlannedAnalysis,
    workbook: Path,
    output_root: Path,
    args: argparse.Namespace,
) -> Path:
    output_dir = output_dir_for_item(item, output_root)
    context = outcome_report_context(item, output_root)
    prompt = llm_single_outcome_prompt(workbook, context)
    safe_outcome = common.sanitize_filename(item.outcome_name, item.sheet)
    prompt_path = output_dir / f"Manuscript Narrative Prompt - {safe_outcome}.json"
    prompt_path.write_text(json.dumps(prompt, indent=2, default=str), encoding="utf-8")

    statistical_narrative = deterministic_outcome_markdown(context)
    statistical_path = output_dir / f"Statistical Manuscript Narrative - {safe_outcome}.md"
    statistical_path.write_text(statistical_narrative, encoding="utf-8")
    save_report_docx(statistical_narrative, output_dir / f"Statistical Manuscript Narrative - {safe_outcome}.docx")

    narrative = None
    if not args.no_lmstudio and not args.no_llm_report:
        print(f"\nSending {item.outcome_name} outputs to LMStudio for immediate manuscript interpretation...")
        narrative = call_lmstudio_report(prompt, args.lmstudio_url, args.model)
    if not narrative:
        narrative = statistical_narrative

    narrative_path = output_dir / f"LLM Manuscript Narrative - {safe_outcome}.md"
    narrative_path.write_text(narrative.strip() + "\n", encoding="utf-8")
    save_report_docx(narrative, output_dir / f"LLM Manuscript Narrative - {safe_outcome}.docx")

    print("\nImmediate Manuscript-Ready Outcome Interpretation")
    print("-------------------------------------------------")
    print(narrative.strip())
    print(f"\nOutcome narrative saved to: {narrative_path}")
    return narrative_path


def try_generate_outcome_manuscript_narrative(
    item: PlannedAnalysis,
    workbook: Path,
    output_root: Path,
    args: argparse.Namespace,
) -> Path | None:
    try:
        return generate_outcome_manuscript_narrative(item, workbook, output_root, args)
    except Exception as exc:
        print(f"Outcome manuscript narrative generation failed for '{item.outcome_name}' ({exc}).")
        return None


def fallback_methods_section(outcomes: list[dict[str, Any]]) -> list[str]:
    inventory = analysis_inventory(outcomes)
    lines = [
        "# Methods",
        "",
        "The manuscript draft was structured against the PRISMA 2020 reporting framework for systematic reviews, "
        "using PRISMA Methods items 5-15 to organize eligibility, information sources, selection, data extraction, "
        "risk-of-bias, effect-measure, and synthesis-method reporting. The automated analysis context supplies "
        "quantitative synthesis details; review-level details that are not present in the analysis outputs are flagged for completion from the protocol, search, screening, and risk-of-bias records.",
        "",
        "## Eligibility Criteria and Study Grouping",
        "",
        (
            "Studies were grouped for synthesis according to the completed outcome mappings and comparison labels in the analysis outputs. "
            "The automated output context does not by itself contain full review eligibility criteria; final manuscript text should add the population, intervention, comparator, outcome, study-design, report-status, language, date, and setting restrictions from the review protocol."
        ),
        "",
        "## Information Sources and Search Strategy",
        "",
        (
            "PRISMA 2020 requires all information sources, last-search dates, and full search strategies to be reported. "
            "These review-level search details were not part of the quantitative analysis output context and should be inserted from the search log and PRISMA flow records before submission."
        ),
        "",
        "## Study Selection and Data Collection",
        "",
        (
            "The quantitative runner used the reviewed outcome mappings to extract arm-level binary counts or continuous summary statistics from the supplied workbook. "
            "The final manuscript should add how many reviewers screened records and reports, whether they worked independently, how disagreements were resolved, and whether any automation tools were used during screening or data extraction."
        ),
        "",
        "## Risk of Bias Assessment",
        "",
        (
            "Risk-of-bias methods and judgments should be reported with the tool names, assessed domains, reviewer process, and overall-judgment rules. "
            "Those review-level assessments are not inferred from the meta-analysis output unless explicitly supplied in the context."
        ),
        "",
        "## Data Items and Effect Measures",
        "",
    ]
    methods: list[str] = []
    if inventory["binary_pairwise_count"]:
        methods.append(
            "Binary pairwise outcomes were synthesized from arm-level event counts. "
            "Effect measures and pooling approaches were selected during preflight review for each outcome, "
            "and the completed analyses used the effect measures and pooling methods recorded in the analysis outputs "
            f"({', '.join(inventory['effect_measures'])}; {', '.join(inventory['pooling_methods'])})."
        )
    if inventory["continuous_pairwise_count"]:
        methods.append(
            "Continuous pairwise outcomes were synthesized from group-level means, standard deviations, and sample sizes "
            "using the mean-difference or standardized-mean-difference approach selected during preflight review."
        )
    if not methods:
        methods.append("The completed analysis outputs did not contain pairwise quantitative synthesis data items that could be summarized automatically.")
    lines.append(" ".join(methods))

    lines.extend(["", "## Statistical Synthesis", ""])
    synthesis_methods: list[str] = []
    if inventory["model_types"]:
        synthesis_methods.append(
            "Pooled estimates were generated with the model type selected for each endpoint "
            f"({', '.join(inventory['model_types'])}), and heterogeneity was summarized with tau-squared, Cochran's Q, "
            "and I-squared when available."
        )
    if inventory["subgroup_analysis_done"]:
        synthesis_methods.append(
            "Subgroup analyses were generated for selected categorical moderators, with subgroup-specific pooled estimates "
            "and formal tests for subgroup differences reported when available."
        )
    diagnostics = []
    if inventory["leave_one_out_done"]:
        diagnostics.append("leave-one-out sensitivity analyses")
    if inventory["baujat_done"]:
        diagnostics.append("Baujat influence diagnostics")
    if inventory["funnel_or_egger_done"]:
        diagnostics.append("funnel plots and Egger tests for small-study effects")
    if diagnostics:
        synthesis_methods.append("Additional diagnostics included " + ", ".join(diagnostics) + " when supported by the number of studies and generated output.")
    if inventory["meta_regression_done"]:
        synthesis_methods.append(
            "Random-effects meta-regression was attempted for eligible numeric or numeric-coded study-level regressors. "
            "Regressors that were non-numeric, sparse, non-variable, or caused model-fitting errors were skipped and recorded in the meta-regression run notes."
        )
    if inventory["tsa_done"]:
        synthesis_methods.append(
            "Trial Sequential Analysis was generated when supported by the endpoint and available data, using the alpha, power, "
            "effect-source, and diversity-adjustment choices recorded in the analysis output."
        )
    if not synthesis_methods:
        synthesis_methods.append("The completed analysis outputs did not contain quantitative synthesis methods that could be summarized automatically.")
    lines.append(" ".join(synthesis_methods))
    return lines


def fallback_figure_legends(figures: list[dict[str, str]]) -> list[str]:
    if not figures:
        return []
    lines = ["", "## Figure Legends", ""]
    for item in figures:
        lines.append(
            f"- {item['figure']}. {item['legend']} Source file: {item['filename']}."
        )
    return lines


def fallback_report(outcomes: list[dict[str, Any]], figures: list[dict[str, str]] | None = None) -> str:
    figures = figures or figure_legend_items(outcomes)
    lines = fallback_methods_section(outcomes)
    lines.extend(["", "# Results", ""])
    lines.append(
        "The Results section is organized according to PRISMA 2020 Results items 16-22. "
        "Study-selection counts, full included-study characteristics, risk-of-bias judgments, and certainty-of-evidence assessments "
        "should be completed from the review-level PRISMA flow diagram, characteristics tables, risk-of-bias files, and certainty assessments when available. "
        "The quantitative syntheses below use only statistics parsed from the generated analysis outputs. "
        "Analyses that were not generated for a given outcome are not interpreted for that outcome."
    )
    lines.extend(
        [
            "",
            "## Study Selection, Study Characteristics, and Risk of Bias",
            "",
            (
                "PRISMA 2020 study-selection, study-characteristics, and risk-of-bias results require review-level data. "
                "Insert the final PRISMA flow counts, included-study table, excluded-study reasons, and risk-of-bias summary here. "
                "The automated outcome outputs do not invent these values."
            ),
            "",
            "## Results of Individual Studies and Syntheses",
            "",
        ]
    )
    for outcome in outcomes:
        lines.extend(["", *deterministic_outcome_report(outcome)])
    if len(outcomes) > 1:
        significant = 0
        with_subgroup_tests = 0
        for outcome in outcomes:
            stats = outcome.get("statistical_results") or {}
            pooled = stats.get("pooled") or {}
            if pooled.get("statistically_significant") is True:
                significant += 1
            if any((subgroup.get("test_for_subgroup_differences_p") for subgroup in stats.get("subgroups") or [])):
                with_subgroup_tests += 1
        lines.extend(
            [
                "",
                "## Overall Manuscript Summary",
                "",
                (
                    f"Across {len(outcomes)} analyzed outcome(s), {significant} pooled estimate(s) were statistically significant "
                    "at the 0.05 threshold based on the parsed p values. "
                    f"Formal subgroup-difference tests were available for {with_subgroup_tests} outcome(s). "
                    "The paragraphs above are structured for PRISMA 2020 synthesis-results reporting and retain statistical wording only."
                ),
            ]
        )
    lines.extend(
        [
            "",
            "## Reporting Bias and Certainty of Evidence",
            "",
            (
                "Small-study and reporting-bias outputs are reported within the relevant outcome paragraphs when funnel plots or Egger tests were generated. "
                "Certainty-of-evidence judgments were not inferred from the meta-analysis outputs and should be added from the review's GRADE or other certainty assessment if performed."
            ),
        ]
    )
    lines.extend(fallback_figure_legends(figures))
    return "\n".join(lines).strip() + "\n"


def save_report_docx(markdown_text: str, docx_path: Path) -> bool:
    try:
        from docx import Document
    except ImportError:
        return False

    document = Document()
    for raw_line in markdown_text.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        if line.startswith("# "):
            document.add_heading(line[2:].strip(), level=1)
        elif line.startswith("## "):
            document.add_heading(line[3:].strip(), level=2)
        elif line.startswith("### "):
            document.add_heading(line[4:].strip(), level=3)
        elif line.startswith("- "):
            document.add_paragraph(line[2:].strip(), style="List Bullet")
        else:
            document.add_paragraph(line)
    document.save(docx_path)
    return True


def parse_metareg_status_file(path: Path, item: PlannedAnalysis) -> dict[str, str]:
    values: dict[str, str] = {}
    for line in read_snippet(path, max_chars=6000).splitlines():
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        values[key.strip().lower()] = value.strip()
    label = path.stem
    label = re.sub(r"^MetaregStatus\s*-\s*", "", label).strip()
    return {
        "Outcome": values.get("outcome") or item.outcome_name,
        "Regressor": values.get("regressor") or label,
        "Status": values.get("status") or "unknown",
        "Reason": values.get("reason") or "No reason was recorded.",
        "Summary file": values.get("summary file") or "",
    }


def metareg_status_rows(completed_items: list[PlannedAnalysis], output_root: Path) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for item in completed_items:
        output_dir = report_data_dir_for_item(item, output_root)
        status_files = output_files(
            output_dir,
            lambda path: path.name.startswith("MetaregStatus") and path.suffix.lower() == ".txt",
        )
        if status_files:
            rows.extend(parse_metareg_status_file(path, item) for path in status_files)
        else:
            rows.append(
                {
                    "Outcome": item.outcome_name,
                    "Regressor": "-",
                    "Status": "not_attempted",
                    "Reason": "No meta-regression status files were produced for this outcome.",
                    "Summary file": "",
                }
            )
    return rows


def write_metaregression_run_notes(
    completed_items: list[PlannedAnalysis],
    output_root: Path,
    report_dir: Path,
) -> Path | None:
    rows = metareg_status_rows(completed_items, output_root)
    report_dir.mkdir(parents=True, exist_ok=True)
    md_path = report_dir / "Meta-regression Run Notes.md"
    docx_path = report_dir / "Meta-regression Run Notes.docx"

    lines = [
        "# Meta-regression Run Notes",
        "",
        "This report lists each attempted meta-regression regressor and whether it completed, was skipped, or failed without stopping the full analysis run.",
        "",
        "| Outcome | Regressor | Status | Reason |",
        "| --- | --- | --- | --- |",
    ]
    for row in rows:
        lines.append(
            "| "
            + " | ".join(
                str(row.get(key, "")).replace("|", "\\|").replace("\n", " ")
                for key in ["Outcome", "Regressor", "Status", "Reason"]
            )
            + " |"
        )
    md_path.write_text("\n".join(lines) + "\n", encoding="utf-8")

    try:
        from docx import Document
        from docx.shared import Inches
    except ImportError:
        print(f"python-docx is not available; meta-regression run notes were saved as Markdown only: {md_path}")
        return None

    document = Document()
    section = document.sections[0]
    section.top_margin = Inches(0.65)
    section.bottom_margin = Inches(0.65)
    section.left_margin = Inches(0.65)
    section.right_margin = Inches(0.65)
    document.add_heading("Meta-regression Run Notes", level=1)
    document.add_paragraph(
        "Each row records whether a meta-regression regressor completed, was skipped, or failed. "
        "Skipped and failed regressors do not stop later regressors or outcomes."
    )
    common.add_docx_table(
        document,
        ["Outcome", "Regressor", "Status", "Reason"],
        [[row["Outcome"], row["Regressor"], row["Status"], row["Reason"]] for row in rows],
    )
    document.save(docx_path)
    return docx_path


def generate_llm_results_report(
    completed_items: list[PlannedAnalysis],
    workbook: Path,
    output_root: Path,
    args: argparse.Namespace,
    report_dir: Path,
) -> Path:
    report_dir.mkdir(parents=True, exist_ok=True)
    contexts = [
        outcome_report_context(item, output_root)
        for item in tqdm(completed_items, desc="Building manuscript context", unit="outcome")
    ]
    figures = figure_legend_items(contexts)
    prompt = llm_report_prompt(workbook, contexts, figures)
    prompt_path = report_dir / "LLM Manuscript Methods and Results Report Prompt.json"
    prompt_path.write_text(json.dumps(prompt, indent=2, default=str), encoding="utf-8")

    statistical_report = fallback_report(contexts, figures)
    statistical_report_path = report_dir / "Statistical Manuscript Methods and Results Report.md"
    statistical_report_path.write_text(statistical_report, encoding="utf-8")
    save_report_docx(statistical_report, report_dir / "Statistical Manuscript Methods and Results Report.docx")

    report = None
    if not args.no_lmstudio and not args.no_llm_report:
        print("\nSending completed analysis outputs to LMStudio for the manuscript Methods and Results report...")
        report = call_lmstudio_report(prompt, args.lmstudio_url, args.model)
    if not report:
        report = statistical_report

    report_path = report_dir / "LLM Manuscript Methods and Results Report.md"
    report_path.write_text(report, encoding="utf-8")
    save_report_docx(report, report_dir / "LLM Manuscript Methods and Results Report.docx")
    return report_path


def read_parameter_csv(path: Path | None) -> dict[str, str]:
    if not path or not path.exists():
        return {}
    values: dict[str, str] = {}
    try:
        with path.open(newline="", encoding="utf-8-sig", errors="replace") as handle:
            reader = csv.DictReader(handle)
            for row in reader:
                key = str(row.get("Parameter") or "").strip()
                value = str(row.get("Value") or "").strip()
                if key:
                    values[key] = value
    except OSError:
        return {}
    return values


def read_check_value_csv(path: Path | None) -> dict[str, str]:
    if not path or not path.exists():
        return {}
    values: dict[str, str] = {}
    try:
        with path.open(newline="", encoding="utf-8-sig", errors="replace") as handle:
            reader = csv.DictReader(handle)
            for row in reader:
                key = str(row.get("Check") or "").strip()
                value = str(row.get("Value") or "").strip()
                if key:
                    values[key] = value
    except OSError:
        return {}
    return values


def parse_percent_value(value: Any) -> float | None:
    text = str(value or "")
    match = re.search(r"([-+]?\d*\.?\d+)\s*%", text)
    if not match:
        return None
    return numeric(match.group(1))


def parse_truthy(value: Any) -> bool:
    return str(value).strip().lower() in {"true", "t", "1", "yes", "y"}


def count_csv_rows(path: Path) -> int:
    try:
        with path.open(newline="", encoding="utf-8-sig", errors="replace") as handle:
            return max(sum(1 for _ in csv.DictReader(handle)), 0)
    except OSError:
        return 0


def audit_file_label(path: Path, base_dir: Path) -> str:
    try:
        return str(path.relative_to(base_dir))
    except ValueError:
        return path.name


def append_assumption_row(
    rows: list[dict[str, str]],
    outcome: str,
    category: str,
    decision: str,
    rationale: str,
    evidence: str,
) -> None:
    rows.append(
        {
            "Outcome": outcome,
            "Category": category,
            "Assumption / decision": " ".join(str(decision).split()),
            "Rationale / standard": " ".join(str(rationale).split()),
            "Evidence file(s)": evidence,
        }
    )


def collect_assumption_rows(completed_items: list[PlannedAnalysis], output_root: Path) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for item in completed_items:
        output_dir = report_data_dir_for_item(item, output_root)
        outcome = item.outcome_name
        mapping = read_json_if_exists(output_dir / "identified-columns.json")
        if not mapping:
            mapping = read_json_if_exists(output_dir / "identified-network-columns.json")

        analysis = mapping.get("analysis") or {}
        if analysis:
            selected = []
            for key in [
                "summary_measure",
                "pooling_method",
                "data_format",
                "median_handling",
                "model_type",
                "outcome_direction",
                "tsa_effect_source",
                "tsa_adjust_for_diversity",
            ]:
                if key in analysis and analysis.get(key) not in {None, ""}:
                    selected.append(f"{key}={analysis.get(key)}")
            append_assumption_row(
                rows,
                outcome,
                "Analysis choices",
                "; ".join(selected) or "Runner defaults were used.",
                "Automated preflight and runner normalization selected model/effect settings, with user review available before execution.",
                "identified-columns.json",
            )

        notes = mapping.get("notes")
        duplicate_flag = bool(mapping.get("duplicate_study_label_conflict") or mapping.get("duplicate_subgroup_conflict"))
        conflict_resolution = (mapping.get("analysis") or {}).get("conflict_resolution")
        if duplicate_flag or conflict_resolution or (notes and "duplicate" in str(notes).lower()):
            append_assumption_row(
                rows,
                outcome,
                "Duplicate or multi-arm studies",
                f"conflict_resolution={conflict_resolution or 'not recorded'}; {notes or ''}",
                "Cochrane-style handling avoids double-counting by combining compatible arms for the overall analysis or using subgroup-specific handling when needed.",
                "identified-columns.json",
            )
        subgroup_note = first_output_file(output_dir, lambda path: path.name.startswith("SubgroupDatasetNote") and path.suffix.lower() == ".txt")
        if subgroup_note:
            append_assumption_row(
                rows,
                outcome,
                "Subgroup duplicate handling",
                read_snippet(subgroup_note, max_chars=900),
                "Subgroup datasets may need split/shared-arm handling while the overall estimate uses the primary Cochrane-combined row.",
                audit_file_label(subgroup_note, output_dir),
            )

        if item.analysis_type == "binary_pairwise":
            measure = str(analysis.get("summary_measure") or "").upper()
            if measure in {"RR", "OR"}:
                append_assumption_row(
                    rows,
                    outcome,
                    "Zero-event binary studies",
                    "Single-zero studies retained with 0.5 continuity correction only when needed; double-zero studies excluded for RR/OR.",
                    "The same post-exclusion dataset is used for forest plots and RTSA input.",
                    "generated_binary_meta_analysis.R; ZeroEventHandling*.txt when exclusions occur",
                )
            elif measure == "RD":
                append_assumption_row(
                    rows,
                    outcome,
                    "Zero-event binary studies",
                    "Risk difference selected; double-zero studies can remain because RD is defined when both arms have zero events.",
                    "Cochrane distinguishes ratio effects from difference effects for double-zero studies.",
                    "identified-columns.json",
                )
        for zero_note in output_files(output_dir, lambda path: path.name.startswith("ZeroEventHandling") and path.suffix.lower() == ".txt"):
            append_assumption_row(
                rows,
                outcome,
                "Zero-event exclusion audit",
                read_snippet(zero_note, max_chars=1200),
                "Records the actual zero-event decision applied before forest plot and TSA.",
                audit_file_label(zero_note, output_dir),
            )
        for excluded in output_files(output_dir, lambda path: path.name.startswith("ExcludedDoubleZeroStudies") and path.suffix.lower() == ".csv"):
            append_assumption_row(
                rows,
                outcome,
                "Excluded double-zero studies",
                f"{count_csv_rows(excluded)} double-zero study row(s) excluded before RR/OR synthesis.",
                "These rows are retained in an audit file so exclusions are traceable.",
                audit_file_label(excluded, output_dir),
            )

        if item.analysis_type == "continuous_pairwise":
            median_handling = analysis.get("median_handling")
            if median_handling and median_handling != "not_used":
                append_assumption_row(
                    rows,
                    outcome,
                    "Median/IQR conversion",
                    f"median_handling={median_handling}; {analysis.get('median_handling_reason') or ''}",
                    "Median/IQR or range conversions require distributional assumptions and are flagged for author review.",
                    "identified-columns.json",
                )
            zero_sd_note = first_output_file(output_dir, lambda path: path.name.startswith("ZeroSDImputationAssumption") and path.suffix.lower() == ".txt")
            if zero_sd_note:
                append_assumption_row(
                    rows,
                    outcome,
                    "Zero SD imputation",
                    read_snippet(zero_sd_note, max_chars=1200),
                    "Zero SD values cannot be synthesized directly; the runner imputes a small SD and writes sensitivity output when applicable.",
                    audit_file_label(zero_sd_note, output_dir),
                )
            for zero_sd_file in output_files(output_dir, lambda path: "zero-sd-imputation-assumptions" in path.name.lower()):
                append_assumption_row(
                    rows,
                    outcome,
                    "Zero SD imputation audit",
                    f"Imputation audit file generated with {count_csv_rows(zero_sd_file) if zero_sd_file.suffix.lower() == '.csv' else 'text'} entries.",
                    "Lists affected studies/columns or the stated zero-SD assumption.",
                    audit_file_label(zero_sd_file, output_dir),
                )

        tsa_parameters = read_parameter_csv(first_output_file(output_dir, lambda path: path.name.startswith("TSAParameters") and path.suffix.lower() == ".csv"))
        if tsa_parameters:
            pieces = []
            for key in [
                "TSA input data source",
                "Effect source",
                "Anticipated effect note",
                "RTSA engine used",
                "Heterogeneity adjustment",
                "Diversity adjusted",
                "RIS note",
                "Boundary engine",
                "Futility boundaries",
                "Zero-event handling",
                "TSA suitability",
                "TSA warning details",
            ]:
                if tsa_parameters.get(key):
                    pieces.append(f"{key}: {tsa_parameters[key]}")
            append_assumption_row(
                rows,
                outcome,
                "Trial Sequential Analysis",
                "; ".join(pieces),
                "TSA settings are generated from the same fitted forest-plot data object and recorded for evidence-maturity review.",
                "TSA*/TSAParameters*.csv; TSA*/TSAAnalysisDataset*.csv",
            )
        tsa_notes = first_output_file(output_dir, lambda path: path.name.startswith("TSANotes") and path.suffix.lower() == ".txt")
        if tsa_notes:
            append_assumption_row(
                rows,
                outcome,
                "TSA notes",
                read_snippet(tsa_notes, max_chars=1400),
                "Documents skipped TSA, fallback TSA, or RTSA warnings/failures.",
                audit_file_label(tsa_notes, output_dir),
            )
        tsa_warnings = first_output_file(output_dir, lambda path: path.name.startswith("TSAWarnings") and path.suffix.lower() == ".txt")
        if tsa_warnings:
            append_assumption_row(
                rows,
                outcome,
                "RTSA input or routing note",
                read_snippet(tsa_warnings, max_chars=1400),
                "Records RTSA input notes, routing notes, or RTSA warnings generated by the TSA runner.",
                audit_file_label(tsa_warnings, output_dir),
            )

        for status_file in output_files(output_dir, lambda path: path.name.startswith("MetaregStatus") and path.suffix.lower() == ".txt"):
            status = parse_metareg_status_file(status_file, item)
            if status["Status"] != "completed":
                append_assumption_row(
                    rows,
                    outcome,
                    "Meta-regression guardrail",
                    f"{status['Regressor']}: {status['Status']}. {status['Reason']}",
                    "Meta-regressions are skipped when there are too few studies, insufficient category counts, or unusable covariate data.",
                    audit_file_label(status_file, output_dir),
                )
    return rows


def write_assumptions_audit_document(
    completed_items: list[PlannedAnalysis],
    output_root: Path,
    report_dir: Path,
) -> Path | None:
    rows = collect_assumption_rows(completed_items, output_root)
    report_dir.mkdir(parents=True, exist_ok=True)
    md_path = report_dir / "Analysis Assumptions and Data Handling Audit.md"
    docx_path = report_dir / "Analysis Assumptions and Data Handling Audit.docx"

    lines = [
        "# Analysis Assumptions and Data Handling Audit",
        "",
        "This file summarizes automated assumptions, data-handling decisions, exclusions, fallbacks, and guardrails applied during the meta-analysis run.",
        "",
        "## General Rules Applied",
        "",
        "- Duplicate or multi-arm study rows are handled to avoid double-counting participants.",
        "- For binary RR/OR analyses, single-zero studies are retained with a 0.5 continuity correction only when needed; double-zero studies are excluded before forest plot and TSA.",
        "- For binary RD analyses, double-zero studies may remain because the risk difference is defined.",
        "- TSA uses the same fitted meta-analysis data object as the forest plot, then orders studies chronologically for cumulative monitoring.",
        "- Continuous outcomes with zero SD or median/IQR-only data are audited because they require additional assumptions.",
        "- Meta-regression is skipped rather than forced when study counts or category counts are methodologically insufficient.",
        "",
        "## Outcome-Level Audit",
        "",
        "| Outcome | Category | Assumption / decision | Rationale / standard | Evidence file(s) |",
        "| --- | --- | --- | --- | --- |",
    ]
    if rows:
        for row in rows:
            lines.append(
                "| "
                + " | ".join(
                    str(row.get(key, "")).replace("|", "\\|").replace("\n", " ")
                    for key in ["Outcome", "Category", "Assumption / decision", "Rationale / standard", "Evidence file(s)"]
                )
                + " |"
            )
    else:
        lines.append("| - | No audited assumptions detected | - | - | - |")
    md_path.write_text("\n".join(lines) + "\n", encoding="utf-8")

    try:
        from docx import Document
        from docx.enum.section import WD_ORIENT
        from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        from docx.oxml import OxmlElement
        from docx.oxml.ns import qn
        from docx.shared import Inches, Pt, RGBColor
    except ImportError:
        print(f"python-docx is not available; assumptions audit was saved as Markdown only: {md_path}")
        return None

    def set_cell_shading(cell: Any, fill: str) -> None:
        tc_pr = cell._tc.get_or_add_tcPr()
        shading = OxmlElement("w:shd")
        shading.set(qn("w:fill"), fill)
        tc_pr.append(shading)

    def set_cell_margins(cell: Any, margin_dxa: int = 90) -> None:
        tc_pr = cell._tc.get_or_add_tcPr()
        tc_mar = tc_pr.first_child_found_in("w:tcMar")
        if tc_mar is None:
            tc_mar = OxmlElement("w:tcMar")
            tc_pr.append(tc_mar)
        for side in ("top", "start", "bottom", "end"):
            element = tc_mar.find(qn(f"w:{side}"))
            if element is None:
                element = OxmlElement(f"w:{side}")
                tc_mar.append(element)
            element.set(qn("w:w"), str(margin_dxa))
            element.set(qn("w:type"), "dxa")

    def set_table_geometry(table: Any, widths: list[int]) -> None:
        table.autofit = False
        tbl = table._tbl
        tbl_pr = tbl.tblPr
        tbl_w = tbl_pr.find(qn("w:tblW"))
        if tbl_w is None:
            tbl_w = OxmlElement("w:tblW")
            tbl_pr.append(tbl_w)
        tbl_w.set(qn("w:w"), str(sum(widths)))
        tbl_w.set(qn("w:type"), "dxa")
        tbl_grid = tbl.tblGrid
        for child in list(tbl_grid):
            tbl_grid.remove(child)
        for width in widths:
            grid_col = OxmlElement("w:gridCol")
            grid_col.set(qn("w:w"), str(width))
            tbl_grid.append(grid_col)
        for row in table.rows:
            for cell, width in zip(row.cells, widths):
                tc_pr = cell._tc.get_or_add_tcPr()
                tc_w = tc_pr.find(qn("w:tcW"))
                if tc_w is None:
                    tc_w = OxmlElement("w:tcW")
                    tc_pr.append(tc_w)
                tc_w.set(qn("w:w"), str(width))
                tc_w.set(qn("w:type"), "dxa")
                set_cell_margins(cell)

    def add_audit_docx_table(document: Any, audit_rows: list[dict[str, str]]) -> None:
        headers = ["Outcome", "Category", "Assumption / decision", "Rationale / standard", "Evidence file(s)"]
        body_rows = [
            [
                row["Outcome"],
                row["Category"],
                row["Assumption / decision"],
                row["Rationale / standard"],
                row["Evidence file(s)"],
            ]
            for row in audit_rows
        ] or [["-", "No audited assumptions detected", "-", "-", "-"]]
        table = document.add_table(rows=1, cols=len(headers))
        table.style = "Table Grid"
        header_properties = table.rows[0]._tr.get_or_add_trPr()
        repeated_header = OxmlElement("w:tblHeader")
        repeated_header.set(qn("w:val"), "true")
        header_properties.append(repeated_header)
        for index, header in enumerate(headers):
            cell = table.rows[0].cells[index]
            cell.text = header
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            set_cell_shading(cell, "1F4E79")
            for paragraph in cell.paragraphs:
                paragraph.alignment = WD_ALIGN_PARAGRAPH.LEFT
                for run in paragraph.runs:
                    run.font.bold = True
                    run.font.color.rgb = RGBColor(255, 255, 255)
                    run.font.size = Pt(8)
        for body_row in body_rows:
            cells = table.add_row().cells
            for index, value in enumerate(body_row):
                cells[index].text = str(value)
                cells[index].vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.TOP
                for paragraph in cells[index].paragraphs:
                    paragraph.alignment = WD_ALIGN_PARAGRAPH.LEFT
                    for run in paragraph.runs:
                        run.font.color.rgb = RGBColor(0, 0, 0)
                        run.font.size = Pt(7.6)
        set_table_geometry(table, [1700, 1900, 5300, 3900, 2032])
        document.add_paragraph()

    document = Document()
    section = document.sections[0]
    section.orientation = WD_ORIENT.LANDSCAPE
    section.page_width = Inches(11)
    section.page_height = Inches(8.5)
    section.top_margin = Inches(0.45)
    section.bottom_margin = Inches(0.45)
    section.left_margin = Inches(0.35)
    section.right_margin = Inches(0.35)
    document.add_heading("Analysis Assumptions and Data Handling Audit", level=1)
    document.add_paragraph(
        "This audit summarizes automated assumptions, exclusions, fallbacks, and guardrails applied during the run. "
        "It is intended to make non-unique or method-sensitive decisions traceable for review."
    )
    document.add_heading("General Rules Applied", level=2)
    for rule in [
        "Duplicate or multi-arm study rows are handled to avoid double-counting participants.",
        "For binary RR/OR analyses, single-zero studies are retained with a 0.5 continuity correction only when needed; double-zero studies are excluded before forest plot and TSA.",
        "For binary RD analyses, double-zero studies may remain because the risk difference is defined.",
        "TSA uses the same fitted meta-analysis data object as the forest plot, then orders studies chronologically for cumulative monitoring.",
        "Continuous outcomes with zero SD or median/IQR-only data are audited because they require additional assumptions.",
        "Meta-regression is skipped rather than forced when study counts or category counts are methodologically insufficient.",
    ]:
        document.add_paragraph(rule, style="List Bullet")
    document.add_heading("Outcome-Level Audit", level=2)
    add_audit_docx_table(document, rows)
    document.save(docx_path)
    return docx_path


TSA_METHOD_SOURCES = [
    {
        "label": "RTSA package documentation",
        "url": "https://www.rdocumentation.org/packages/RTSA/versions/0.2.2/topics/RTSA",
        "note": "RTSA(type = 'analysis') returns the integrated analysis object, including RIS fields, results_df, seq_inf, and RTSA settings.",
    },
    {
        "label": "RTSA ris documentation",
        "url": "https://www.rdocumentation.org/packages/RTSA/versions/0.2.2/topics/ris",
        "note": "RTSA::ris computes required information size inputs, including D2 adjustment when a finite D2 value is supplied.",
    },
]


def tsa_method_assumption_note(k: int | None, i2: float | None, diversity_adjusted: bool) -> str:
    notes = []
    if k is not None and k < 10:
        notes.append(f"RTSA input count recorded as {k} study looks.")
    if i2 is not None and i2 >= 50 and not diversity_adjusted:
        notes.append(f"Observed I2 was {i2:.1f}%; RTSA random_adj was not D2.")
    elif i2 is not None and i2 >= 50 and diversity_adjusted:
        notes.append(f"Observed I2 was {i2:.1f}%; RTSA random_adj was D2.")
    elif i2 is not None and i2 < 30 and not diversity_adjusted:
        notes.append(f"Observed I2 was {i2:.1f}%; RTSA random_adj was not D2.")
    if not notes:
        notes.append("No additional RTSA input note was identified from the parsed outputs.")
    return " ".join(notes)


def collect_tsa_summary_rows(completed_items: list[PlannedAnalysis], output_root: Path) -> tuple[list[dict[str, Any]], list[dict[str, str]]]:
    rows: list[dict[str, Any]] = []
    missing: list[dict[str, str]] = []
    for item in completed_items:
        output_dir = report_data_dir_for_item(item, output_root)
        mapping = read_json_if_exists(output_dir / "identified-columns.json")
        if not mapping:
            mapping = read_json_if_exists(output_dir / "identified-network-columns.json")
        parameters_path = first_output_file(output_dir, lambda path: path.name.startswith("TSAParameters") and path.suffix.lower() == ".csv")
        audit_path = first_output_file(output_dir, lambda path: path.name.startswith("TSAAudit") and path.suffix.lower() == ".csv")
        if not parameters_path:
            notes_path = first_output_file(output_dir, lambda path: path.name.startswith("TSANotes") and path.suffix.lower() == ".txt")
            reason = read_snippet(notes_path, max_chars=900) if notes_path else "No TSAParameters file was generated; TSA was either not eligible, skipped, or failed before parameter output."
            missing.append(
                {
                    "Outcome": item.outcome_name,
                    "Reason": " ".join(reason.split()),
                    "Evidence files": audit_file_label(notes_path, output_dir) if notes_path else "",
                }
            )
            continue
        parameters = read_parameter_csv(parameters_path)
        audit = read_check_value_csv(audit_path)
        warnings_path = first_output_file(output_dir, lambda path: path.name.startswith("TSAWarnings") and path.suffix.lower() == ".txt")
        warning_details = parameters.get("TSA warning details", "")
        if (not warning_details or warning_details == "None") and warnings_path:
            warning_details = " ".join(read_snippet(warnings_path, max_chars=1200).split())
        if not warning_details:
            warning_details = "None"
        summary_path = first_output_file(
            output_dir,
            lambda path: path.parent == output_dir
            and path.name.startswith("Summary")
            and path.suffix.lower() == ".txt"
            and not path.name.startswith(("SubgroupSummary", "SummarySensitivity", "SummarySpecificity", "SummaryDOR")),
        )
        pooled = parse_pooled_summary(read_snippet(summary_path, max_chars=20000) if summary_path else "", mapping)
        k_match = re.search(r"\d+", str(pooled.get("studies") or ""))
        k = int(k_match.group(0)) if k_match else None
        dataset_path = first_output_file(output_dir, lambda path: path.name.startswith("TSAAnalysisDataset") and path.suffix.lower() == ".csv")
        if k is None and dataset_path:
            k = count_csv_rows(dataset_path)
        i2 = parse_percent_value(pooled.get("i2"))
        diversity_adjusted = parse_truthy(parameters.get("Diversity adjusted"))
        method_note = tsa_method_assumption_note(k, i2, diversity_adjusted)
        assumption_note = method_note if warning_details == "None" else f"{method_note} TSA warning: {warning_details}"
        rtsa_status = audit.get("RTSA inference status") or parameters.get("RTSA inference status", "")
        boundary_assessment = audit.get("Boundary assessment") or audit.get("Boundary " + "crossing", "")
        if str(rtsa_status).startswith("Fallback diagnostic only"):
            boundary_assessment = ""
        row = {
            "Outcome": item.outcome_name,
            "Type": item.label,
            "Studies": k,
            "I2 (%)": i2,
            "Effect measure": parameters.get("Effect measure", ""),
            "Alpha": parameters.get("Alpha", ""),
            "Power": parameters.get("Power", ""),
            "Effect source": parameters.get("Effect source", ""),
            "Anticipated effect note": parameters.get("Anticipated effect note", ""),
            "Diversity adjusted": "Yes" if diversity_adjusted else "No",
            "Heterogeneity adjustment": parameters.get("Heterogeneity adjustment", ""),
            "RIS": parameters.get("Sequential adjusted RIS (boundary denominator)", ""),
            "Final information": audit.get("Final cumulative information", ""),
            "Information/RIS": audit.get("Final information / adjusted RIS", ""),
            "Boundary assessment": boundary_assessment,
            "Futility assessment": audit.get("Futility assessment", ""),
            "RTSA engine": audit.get("RTSA engine") or parameters.get("RTSA engine used", ""),
            "RTSA inference status": rtsa_status,
            "TSA suitability": parameters.get("TSA suitability") or audit.get("TSA suitability") or "Generated; suitability not recorded",
            "Warnings": warning_details,
            "Futility": parameters.get("Futility boundaries", ""),
            "Zero-event handling": parameters.get("Zero-event handling", ""),
            "Input source": parameters.get("TSA input data source", ""),
            "Assumption note": assumption_note,
            "Evidence files": "; ".join(
                part for part in [
                    audit_file_label(parameters_path, output_dir),
                    audit_file_label(audit_path, output_dir) if audit_path else "",
                    audit_file_label(dataset_path, output_dir) if dataset_path else "",
                    audit_file_label(warnings_path, output_dir) if warnings_path else "",
                ]
                if part
            ),
        }
        rows.append(row)
    return rows, missing


def markdown_table(headers: list[str], rows: list[list[Any]]) -> list[str]:
    lines = [
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join("---" for _ in headers) + " |",
    ]
    for row in rows:
        lines.append(
            "| "
            + " | ".join(str(value if value is not None else "").replace("|", "\\|").replace("\n", " ") for value in row)
            + " |"
        )
    return lines


def deterministic_tsa_summary_markdown(rows: list[dict[str, Any]], missing: list[dict[str, str]]) -> str:
    lines = [
        "# Trial Sequential Analysis Summary and Assumptions",
        "",
        "This report summarizes TSA outputs generated across outcomes and records the RTSA settings, information-size fields, and boundary assessment status extracted from the generated files.",
        "",
        "## Methodological Basis",
        "",
        "The implemented summary reports RTSA inputs and outputs only. Integrated RTSA(type = 'analysis') rows are distinguished from fallback diagnostics using the recorded RTSA inference status.",
        "",
    ]
    for source in TSA_METHOD_SOURCES:
        lines.append(f"- {source['label']}: {source['note']} Source: {source['url']}")
    lines.extend(
        [
            "",
            "## Cross-Outcome TSA Table",
            "",
        ]
    )
    table_headers = [
        "Outcome", "k", "I2", "Effect", "Alpha", "Power", "Effect source",
        "Diversity adjusted", "TSA suitability", "RIS", "Final information", "Info/RIS", "Boundary assessment", "RTSA status",
    ]
    table_rows = []
    for row in rows:
        i2 = row.get("I2 (%)")
        table_rows.append(
            [
                row["Outcome"],
                row.get("Studies") if row.get("Studies") is not None else "",
                f"{i2:.1f}%" if isinstance(i2, (int, float)) else "",
                row.get("Effect measure", ""),
                row.get("Alpha", ""),
                row.get("Power", ""),
                row.get("Effect source", ""),
                row.get("Diversity adjusted", ""),
                row.get("TSA suitability", ""),
                row.get("RIS", ""),
                row.get("Final information", ""),
                row.get("Information/RIS", ""),
                row.get("Boundary assessment", ""),
                row.get("RTSA inference status", ""),
            ]
        )
    if table_rows:
        lines.extend(markdown_table(table_headers, table_rows))
    else:
        lines.append("No TSA parameter outputs were detected among completed outcomes.")
    lines.extend(["", "## Outcome-Level Assumptions", ""])
    for row in rows:
        lines.extend(
            [
                f"### {row['Outcome']}",
                "",
                f"- TSA input source: {row.get('Input source') or 'not recorded'}.",
                f"- RTSA engine: {row.get('RTSA engine') or 'not recorded'}.",
                f"- Anticipated effect: {row.get('Anticipated effect note') or 'not recorded'}.",
                f"- Heterogeneity adjustment: {row.get('Heterogeneity adjustment') or 'not recorded'}; diversity adjusted: {row.get('Diversity adjusted')}.",
                f"- TSA suitability: {row.get('TSA suitability') or 'not recorded'}.",
                f"- RTSA inference status: {row.get('RTSA inference status') or 'not recorded'}.",
                f"- TSA warnings: {row.get('Warnings') or 'None'}.",
                f"- Boundary assessment: {row.get('Boundary assessment') or 'not evaluated'}; final information/RIS: {row.get('Information/RIS') or 'not recorded'}.",
                f"- Futility boundary assumption: {row.get('Futility') or 'not recorded'}; assessment: {row.get('Futility assessment') or 'not recorded'}.",
                f"- Zero-event handling: {row.get('Zero-event handling') or 'not applicable/not recorded'}.",
                f"- RTSA input note: {row.get('Assumption note')}",
                f"- Evidence files: {row.get('Evidence files') or 'not recorded'}.",
                "",
            ]
        )
    if missing:
        lines.extend(
            [
                "## Outcomes Without TSA Output",
                "",
                "TSA was not summarized for the following completed outcome(s). Reasons are taken from `TSANotes*.txt` when available:",
                "",
            ]
        )
        lines.extend(markdown_table(["Outcome", "Reason", "Evidence file(s)"], [[row["Outcome"], row["Reason"], row["Evidence files"]] for row in missing]))
    lines.extend(
        [
            "",
            "## Reporting Guidance",
            "",
            "Report only the recorded RTSA engine, RTSA inference status, RIS fields, monitoring-boundary assessment when available, and RTSA input notes.",
        ]
    )
    return "\n".join(lines).strip() + "\n"


def tsa_summary_prompt(workbook: Path, rows: list[dict[str, Any]], missing: list[dict[str, str]]) -> dict[str, Any]:
    return {
        "task": (
            "Write a concise manuscript-ready Trial Sequential Analysis summary across all generated outcomes. "
            "Use the supplied TSA table only. Explain RTSA output status, RIS reach status, monitoring-boundary assessment when available, "
            "and the key RTSA settings including heterogeneity/diversity adjustment, alpha, power, anticipated effect source, and zero-event handling."
        ),
        "methodological_rules": [
            "Use the recorded RTSA engine and RTSA inference status to distinguish integrated RTSA analysis from fallback diagnostics.",
            "Report heterogeneity/diversity correction only as the RTSA setting recorded in the TSA parameters.",
            "For outcomes with fewer than 10 study looks, report the recorded look count without adding external methodological interpretation.",
            "Use only the supplied values; do not invent RIS, p-values, confidence intervals, or boundary assessments.",
            "Do not describe monitoring-boundary assessment for rows whose RTSA inference status says fallback diagnostic only.",
        ],
        "methodological_sources": TSA_METHOD_SOURCES,
        "workbook": str(workbook),
        "tsa_rows": rows,
        "outcomes_without_tsa_output": missing,
        "return_format": "Markdown with '# Trial Sequential Analysis Summary', a compact table, and short assumption-focused interpretation paragraphs.",
    }


def write_tsa_summary_docx(markdown_text: str, rows: list[dict[str, Any]], docx_path: Path) -> bool:
    try:
        from docx import Document
        from docx.enum.section import WD_ORIENT
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        from docx.oxml import OxmlElement
        from docx.oxml.ns import qn
        from docx.shared import Inches, Pt, RGBColor
    except ImportError:
        return False

    def set_cell_shading(cell: Any, fill: str) -> None:
        tc_pr = cell._tc.get_or_add_tcPr()
        shading = OxmlElement("w:shd")
        shading.set(qn("w:fill"), fill)
        tc_pr.append(shading)

    def set_table_geometry(table: Any, widths: list[int]) -> None:
        table.autofit = False
        tbl = table._tbl
        tbl_pr = tbl.tblPr
        tbl_w = tbl_pr.find(qn("w:tblW"))
        if tbl_w is None:
            tbl_w = OxmlElement("w:tblW")
            tbl_pr.append(tbl_w)
        tbl_w.set(qn("w:w"), str(sum(widths)))
        tbl_w.set(qn("w:type"), "dxa")
        tbl_grid = tbl.tblGrid
        for child in list(tbl_grid):
            tbl_grid.remove(child)
        for width in widths:
            grid_col = OxmlElement("w:gridCol")
            grid_col.set(qn("w:w"), str(width))
            tbl_grid.append(grid_col)
        for row in table.rows:
            for cell, width in zip(row.cells, widths):
                tc_pr = cell._tc.get_or_add_tcPr()
                tc_w = tc_pr.find(qn("w:tcW"))
                if tc_w is None:
                    tc_w = OxmlElement("w:tcW")
                    tc_pr.append(tc_w)
                tc_w.set(qn("w:w"), str(width))
                tc_w.set(qn("w:type"), "dxa")

    def add_tsa_table(document: Any) -> None:
        headers = ["Outcome", "k", "I2", "Effect", "Diversity", "Suitability", "RIS", "Final info", "Info/RIS", "Boundary", "RTSA status"]
        table = document.add_table(rows=1, cols=len(headers))
        table.style = "Table Grid"
        header_properties = table.rows[0]._tr.get_or_add_trPr()
        repeated_header = OxmlElement("w:tblHeader")
        repeated_header.set(qn("w:val"), "true")
        header_properties.append(repeated_header)
        for index, header in enumerate(headers):
            cell = table.rows[0].cells[index]
            cell.text = header
            set_cell_shading(cell, "1F4E79")
            for paragraph in cell.paragraphs:
                paragraph.alignment = WD_ALIGN_PARAGRAPH.LEFT
                for run in paragraph.runs:
                    run.font.bold = True
                    run.font.color.rgb = RGBColor(255, 255, 255)
                    run.font.size = Pt(7.8)
        for row in rows:
            values = [
                row["Outcome"],
                row.get("Studies") if row.get("Studies") is not None else "",
                f"{row.get('I2 (%)'):.1f}%" if isinstance(row.get("I2 (%)"), (int, float)) else "",
                row.get("Effect measure", ""),
                row.get("Diversity adjusted", ""),
                row.get("TSA suitability", ""),
                row.get("RIS", ""),
                row.get("Final information", ""),
                row.get("Information/RIS", ""),
                row.get("Boundary assessment", ""),
                row.get("RTSA inference status", ""),
            ]
            cells = table.add_row().cells
            for index, value in enumerate(values):
                cells[index].text = str(value)
                for paragraph in cells[index].paragraphs:
                    paragraph.alignment = WD_ALIGN_PARAGRAPH.LEFT
                    for run in paragraph.runs:
                        run.font.size = Pt(7.2)
        set_table_geometry(table, [1500, 400, 550, 550, 700, 1900, 650, 800, 750, 1700, 5332])

    document = Document()
    section = document.sections[0]
    section.orientation = WD_ORIENT.LANDSCAPE
    section.page_width = Inches(11)
    section.page_height = Inches(8.5)
    section.top_margin = Inches(0.45)
    section.bottom_margin = Inches(0.45)
    section.left_margin = Inches(0.35)
    section.right_margin = Inches(0.35)
    document.add_heading("Trial Sequential Analysis Summary and RTSA Settings", level=1)
    document.add_paragraph(
        "This report summarizes generated TSA outputs, RTSA engine status, required information size, "
        "monitoring-boundary assessment when available, and heterogeneity correction settings."
    )
    if rows:
        add_tsa_table(document)
    for raw_line in markdown_text.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("|") or line.startswith("# Trial Sequential Analysis Summary"):
            continue
        if line.startswith("## "):
            document.add_heading(line[3:].strip(), level=2)
        elif line.startswith("### "):
            document.add_heading(line[4:].strip(), level=3)
        elif line.startswith("- "):
            document.add_paragraph(line[2:].strip(), style="List Bullet")
        elif not line.startswith("# "):
            document.add_paragraph(line)
    document.save(docx_path)
    return True


def generate_tsa_summary_report(
    completed_items: list[PlannedAnalysis],
    workbook: Path,
    output_root: Path,
    args: argparse.Namespace,
    report_dir: Path,
) -> Path | None:
    rows, missing = collect_tsa_summary_rows(completed_items, output_root)
    if not rows:
        return None
    report_dir.mkdir(parents=True, exist_ok=True)
    prompt = tsa_summary_prompt(workbook, rows, missing)
    prompt_path = report_dir / "LLM Trial Sequential Analysis Summary Prompt.json"
    prompt_path.write_text(json.dumps(prompt, indent=2, default=str), encoding="utf-8")
    statistical = deterministic_tsa_summary_markdown(rows, missing)
    statistical_path = report_dir / "Statistical Trial Sequential Analysis Summary.md"
    statistical_path.write_text(statistical, encoding="utf-8")
    write_tsa_summary_docx(statistical, rows, report_dir / "Statistical Trial Sequential Analysis Summary.docx")
    report = None
    if not args.no_lmstudio and not args.no_llm_report:
        print("\nSending TSA outputs to LMStudio for the cross-outcome TSA summary...")
        report = call_lmstudio_report(prompt, args.lmstudio_url, args.model)
    if not report:
        report = statistical
    report_path = report_dir / "LLM Trial Sequential Analysis Summary.md"
    report_path.write_text(report, encoding="utf-8")
    write_tsa_summary_docx(report, rows, report_dir / "LLM Trial Sequential Analysis Summary.docx")
    return report_path


def selected_column(mapping: dict[str, Any], field: str) -> str:
    value = mapping.get("columns", {}).get(field)
    return str(value) if value else "-"


def selected_columns(mapping: dict[str, Any], fields: list[str]) -> str:
    values = [selected_column(mapping, field) for field in fields if selected_column(mapping, field) != "-"]
    return " / ".join(values) if values else "-"


def subgroup_summary(mapping: dict[str, Any]) -> str:
    subgroups = list(mapping.get("subgroup_columns") or [])
    legacy_subgroup = mapping.get("columns", {}).get("subgroup")
    if legacy_subgroup and legacy_subgroup not in subgroups:
        subgroups.append(legacy_subgroup)
    return ", ".join(str(value) for value in subgroups) if subgroups else "-"


def covariate_summary(mapping: dict[str, Any]) -> str:
    covariates = list(mapping.get("covariate_columns") or [])
    legacy_covariate = mapping.get("columns", {}).get("covariate")
    if legacy_covariate and legacy_covariate not in covariates:
        covariates.append(legacy_covariate)
    return ", ".join(str(value) for value in covariates) if covariates else "-"


def mapping_table_values(decision: PairwisePreflightDecision) -> tuple[str, str, str]:
    mapping = decision.mapping
    if decision.item.analysis_type == "binary_pairwise":
        if selected_column(mapping, "hr") != "-" or selected_column(mapping, "log_hr") != "-":
            intervention = selected_columns(mapping, ["hr", "ci_lower", "ci_upper", "log_hr", "se_log_hr"])
            control = "generic inverse variance"
        else:
            intervention = selected_columns(mapping, ["event_e", "n_e"])
            control = selected_columns(mapping, ["event_c", "n_c"])
        return selected_column(mapping, "study_label"), intervention, control
    intervention = selected_columns(
        mapping,
        ["n_e", "mean_e", "sd_e", "median_e", "q1_e", "q3_e", "min_e", "max_e"],
    )
    control = selected_columns(
        mapping,
        ["n_c", "mean_c", "sd_c", "median_c", "q1_c", "q3_c", "min_c", "max_c"],
    )
    return selected_column(mapping, "study_label"), intervention, control


def analysis_choice_summary(item: PlannedAnalysis, mapping: dict[str, Any]) -> str:
    analysis = mapping.get("analysis") or {}
    parts = []
    if analysis.get("summary_measure"):
        parts.append(str(analysis["summary_measure"]))
    if item.analysis_type == "binary_pairwise" and analysis.get("pooling_method"):
        parts.append(str(analysis["pooling_method"]))
    if item.analysis_type == "continuous_pairwise" and analysis.get("data_format"):
        parts.append(str(analysis["data_format"]))
    if analysis.get("model_type"):
        parts.append(str(analysis["model_type"]))
    if analysis.get("tsa_alpha") or analysis.get("tsa_power"):
        parts.append(f"TSA a={analysis.get('tsa_alpha', '-')}, power={analysis.get('tsa_power', '-')}")
    return "; ".join(parts) or "-"


def is_binary_count_preflight_decision(decision: PairwisePreflightDecision) -> bool:
    if decision.item.analysis_type != "binary_pairwise":
        return False
    return common.has_count_mapping(decision.mapping)


def apply_binary_effect_size_override(
    decisions: list[PairwisePreflightDecision],
    effect_size: str,
    reason: str,
) -> int:
    effect_size = effect_size.upper()
    if effect_size not in {"RR", "OR", "RD"}:
        return 0
    changed = 0
    for decision in decisions:
        if not is_binary_count_preflight_decision(decision):
            continue
        analysis = decision.mapping.setdefault("analysis", {})
        if analysis.get("summary_measure") != effect_size:
            changed += 1
        analysis["summary_measure"] = effect_size
        analysis["summary_measure_reason"] = reason
        if analysis.get("pooling_method") == "Peto" and effect_size != "OR":
            analysis["pooling_method"] = "MH"
            analysis["pooling_method_reason"] = f"Changed from Peto because Peto pooling requires OR, while {effect_size} was selected for binary outcomes."
    return changed


def prompt_binary_effect_size_override(
    decisions: list[PairwisePreflightDecision],
    assume_yes: bool,
    configured_effect_size: str,
) -> bool:
    configured_effect_size = configured_effect_size.upper()
    if configured_effect_size in {"RR", "OR", "RD"}:
        changed = apply_binary_effect_size_override(
            decisions,
            configured_effect_size,
            f"Applied globally with --binary-effect-size {configured_effect_size}.",
        )
        if changed:
            print(f"\nApplied {configured_effect_size} to {changed} binary count outcome(s).")
        return changed > 0
    if assume_yes or not sys.stdin.isatty() or not any(is_binary_count_preflight_decision(decision) for decision in decisions):
        return False

    response = input("\nUse one effect size for all binary count outcomes? [keep/RR/OR/RD]: ").strip().upper()
    if response in {"", "KEEP", "K", "NO", "N"}:
        return False
    if response not in {"RR", "OR", "RD"}:
        raise SystemExit("Binary effect-size override must be keep, RR, OR, or RD.")
    changed = apply_binary_effect_size_override(
        decisions,
        response,
        f"Applied globally during preflight review to all binary count outcomes.",
    )
    print(f"Applied {response} to {changed} binary count outcome(s).")
    return True


def print_preflight_decision_table(decisions: list[PairwisePreflightDecision]) -> None:
    print("\nPairwise Mapping and Analysis Recommendations")
    print("---------------------------------------------")
    print("Review the numbered rows below. Press Enter or type 'y' to accept all mappings and analysis choices.")
    terminal_width = shutil.get_terminal_size((120, 24)).columns
    detail_width = min(max(terminal_width - 4, 86), 140)

    rows = []
    for decision in decisions:
        status = "Needs edit" if decision.error else "OK"
        rows.append(
            [
                decision.item.index,
                truncate(decision.item.outcome_name, 32),
                truncate(decision.item.label, 20),
                truncate(analysis_choice_summary(decision.item, decision.mapping), 38),
                status,
            ]
        )
    print(
        format_table(
            ["#", "Outcome", "Type", "Analysis", "Status"],
            rows,
        )
    )

    print("\nColumn Mapping Details")
    print("----------------------")
    for decision in decisions:
        study, intervention, control = mapping_table_values(decision)
        print(f"{decision.item.index}. {decision.item.outcome_name} ({decision.item.label})")
        print(wrap_detail_line("Study", study, detail_width))
        print(wrap_detail_line("Intervention", intervention, detail_width))
        print(wrap_detail_line("Control", control, detail_width))
        print(wrap_detail_line("Subgroups", subgroup_summary(decision.mapping), detail_width))
        print(wrap_detail_line("Meta-reg", covariate_summary(decision.mapping), detail_width))
        note = decision.error or str(decision.mapping.get("notes") or "").strip()
        if note:
            print(wrap_detail_line("Notes", note, detail_width))


def prepare_pairwise_preflight_decision(
    item: PlannedAnalysis,
    workbook: Path,
    summary: dict[str, Any],
    args: argparse.Namespace,
) -> PairwisePreflightDecision:
    df = common.load_sheet(workbook, item.sheet)
    columns = [str(col) for col in df.columns]
    df.columns = columns
    lm_mapping = item.preflight_mapping
    if item.analysis_type == "binary_pairwise":
        if lm_mapping:
            print(f"Using initial LMStudio mapping for binary endpoint '{item.sheet}'.")
        elif not args.no_lmstudio:
            print(f"Sending sheet '{item.sheet}' to LMStudio for binary endpoint extraction...")
            lm_mapping = common.call_lmstudio(
                summary={item.sheet: summary[item.sheet]},
                lmstudio_url=args.lmstudio_url,
                model=args.model,
            )
        mapping = common.merge_mapping(columns, item.sheet, lm_mapping, item.outcome_name)
        if common.has_hr_mapping(mapping) and not common.has_count_mapping(mapping):
            mapping["intervention_label"] = mapping.get("intervention_label") or "Exposure"
            mapping["control_label"] = mapping.get("control_label") or "Comparator"
            mapping.setdefault("analysis", {})
            mapping["analysis"]["summary_measure"] = "HR"
        common.prompt_for_arm_labels_if_needed(mapping, args.yes)
        try:
            r_df = common.validate_data(df, mapping)
            mapping["analysis"] = common.infer_analysis_from_data(r_df, mapping, lm_mapping)
        except SystemExit as exc:
            return PairwisePreflightDecision(item=item, columns=columns, mapping=mapping, lm_mapping=lm_mapping, error=str(exc))
    else:
        if lm_mapping:
            print(f"Using initial LMStudio mapping for continuous endpoint '{item.sheet}'.")
        elif not args.no_lmstudio:
            print(f"Sending sheet '{item.sheet}' to LMStudio for continuous endpoint extraction...")
            lm_mapping = continuous_outcome.call_lmstudio(
                {item.sheet: summary[item.sheet]},
                args.lmstudio_url,
                args.model,
            )
        mapping = continuous_outcome.merge_mapping(columns, item.sheet, lm_mapping, item.outcome_name)
        common.prompt_for_arm_labels_if_needed(mapping, args.yes)
        try:
            r_df = continuous_outcome.validate_data(df, mapping)
            mapping["analysis"] = continuous_outcome.infer_analysis_from_data(r_df, mapping, lm_mapping)
        except SystemExit as exc:
            return PairwisePreflightDecision(item=item, columns=columns, mapping=mapping, lm_mapping=lm_mapping, error=str(exc))
    return PairwisePreflightDecision(item=item, columns=columns, mapping=mapping, lm_mapping=lm_mapping)


def review_pairwise_preflight_decision(
    decision: PairwisePreflightDecision,
    workbook: Path,
) -> PairwisePreflightDecision:
    item = decision.item
    df = common.load_sheet(workbook, item.sheet)
    columns = [str(col) for col in df.columns]
    df.columns = columns
    if item.analysis_type == "binary_pairwise":
        mapping = common.prompt_for_mapping(decision.mapping, columns, assume_yes=False)
        if common.has_hr_mapping(mapping) and not common.has_count_mapping(mapping):
            mapping["intervention_label"] = mapping.get("intervention_label") or "Exposure"
            mapping["control_label"] = mapping.get("control_label") or "Comparator"
            mapping.setdefault("analysis", {})
            mapping["analysis"]["summary_measure"] = "HR"
        common.prompt_for_arm_labels_if_needed(mapping, assume_yes=False)
        r_df = common.validate_data(df, mapping)
        mapping["analysis"] = common.infer_analysis_from_data(r_df, mapping, decision.lm_mapping)
        mapping["analysis"] = common.prompt_for_analysis_choices(mapping["analysis"], assume_yes=False)
    else:
        mapping = continuous_outcome.prompt_for_mapping(decision.mapping, columns, assume_yes=False)
        common.prompt_for_arm_labels_if_needed(mapping, assume_yes=False)
        r_df = continuous_outcome.validate_data(df, mapping)
        mapping["analysis"] = continuous_outcome.infer_analysis_from_data(r_df, mapping, decision.lm_mapping)
        mapping["analysis"] = continuous_outcome.prompt_for_analysis_choices(mapping["analysis"], assume_yes=False)
    item.outcome_name = str(mapping.get("outcome_name") or item.outcome_name)
    return PairwisePreflightDecision(item=item, columns=columns, mapping=mapping, lm_mapping=decision.lm_mapping)


def review_pairwise_preflight_decisions(
    decisions: list[PairwisePreflightDecision],
    workbook: Path,
    assume_yes: bool,
    binary_effect_size: str,
) -> list[PairwisePreflightDecision]:
    print_preflight_decision_table(decisions)
    has_errors = any(decision.error for decision in decisions)
    if assume_yes or not sys.stdin.isatty():
        if has_errors:
            errors = "; ".join(f"{decision.item.outcome_name}: {decision.error}" for decision in decisions if decision.error)
            raise SystemExit(f"Preflight mapping failed: {errors}")
        if prompt_binary_effect_size_override(decisions, assume_yes, binary_effect_size):
            print_preflight_decision_table(decisions)
        return decisions

    if has_errors:
        print("\nOne or more rows need correction before analyses can run.")
        response = "all"
    else:
        if prompt_binary_effect_size_override(decisions, assume_yes, binary_effect_size):
            print_preflight_decision_table(decisions)

        for decision in decisions:
            duplicate_rows_need_resolution = bool(
                decision.mapping
                and (
                    decision.mapping.get("duplicate_subgroup_conflict")
                    or decision.mapping.get("duplicate_study_label_conflict")
                )
            )
            if decision.mapping and duplicate_rows_need_resolution:
                if "analysis" not in decision.mapping:
                    decision.mapping["analysis"] = {}
                if assume_yes:
                    # Auto-default to Cochrane-recommended combine
                    decision.mapping["analysis"]["conflict_resolution"] = "combine"
                    decision.mapping["analysis"]["subgroup_only"] = False
                    print(f"\nNote: Outcome '{decision.item.outcome_name}' has duplicate study labels; auto-defaulting to 'combine' (Cochrane recommended).")
                else:
                    print(f"\nWarning: Outcome '{decision.item.outcome_name}' has multiple rows for the same underlying study.")
                    print("To avoid unit-of-analysis error (double-counting a shared intervention or comparator arm), choose a resolution:")
                    print("  1. Combine relevant arms into one pairwise comparison (Cochrane recommended for overall effect)")
                    print("  2. Split the shared arm sample size evenly across rows")
                    print("  3. Subgroup-only (No overall pooled effect; keep subgroups independent)")
                    conflict_resp = input("Select [1/2/3] (default 1): ").strip()
                    if conflict_resp in {"", "1"}:
                        decision.mapping["analysis"]["conflict_resolution"] = "combine"
                        decision.mapping["analysis"]["subgroup_only"] = False
                    elif conflict_resp == "2":
                        decision.mapping["analysis"]["conflict_resolution"] = "split"
                        decision.mapping["analysis"]["subgroup_only"] = False
                    else:
                        decision.mapping["analysis"]["conflict_resolution"] = "subgroup_only"
                        decision.mapping["analysis"]["subgroup_only"] = True
        if assume_yes:
            return decisions
        response = input("\nAccept all mapping and analysis recommendations? [Y/n/edit/details]: ").strip().lower()
    if response in {"", "y", "yes"}:
        return decisions
    if response in {"details", "detail", "d"}:
        while True:
            value = input("Enter an outcome # to inspect, or press Enter when done: ").strip().lower()
            if not value:
                break
            matching = [decision for decision in decisions if str(decision.item.index) == value]
            if not matching:
                print("Enter a valid outcome number.")
                continue
            decision = matching[0]
            if decision.item.analysis_type == "binary_pairwise":
                common.print_mapping(decision.mapping, decision.columns)
            else:
                continuous_outcome.print_mapping(decision.mapping, decision.columns)
        response = input("\nAccept all mapping and analysis recommendations? [Y/n/edit]: ").strip().lower()
        if response in {"", "y", "yes"}:
            return decisions
    if response in {"n", "no", "all"}:
        return [review_pairwise_preflight_decision(decision, workbook) for decision in decisions]
    if response in {"edit", "e"}:
        reviewed = list(decisions)
        while True:
            value = input("\nEnter an outcome # to edit, 'table' to redisplay, 'all' for each outcome, or 'done': ").strip().lower()
            if value in {"done", "d", ""}:
                break
            if value == "table":
                print_preflight_decision_table(reviewed)
                continue
            if value == "all":
                reviewed = [review_pairwise_preflight_decision(decision, workbook) for decision in reviewed]
                break
            matching_indexes = [index for index, decision in enumerate(reviewed) if str(decision.item.index) == value]
            if not matching_indexes:
                print("Enter a valid outcome number.")
                continue
            index = matching_indexes[0]
            reviewed[index] = review_pairwise_preflight_decision(reviewed[index], workbook)
            print_preflight_decision_table(reviewed)
        return reviewed
    raise SystemExit("Stopped before running analyses.")


def save_pairwise_preflight_decision(decision: PairwisePreflightDecision, output_root: Path) -> None:
    if decision.error:
        raise SystemExit(f"Preflight mapping failed for {decision.item.outcome_name}: {decision.error}")
    outcome_dir = output_dir_for_item(decision.item, output_root)
    outcome_dir.mkdir(parents=True, exist_ok=True)
    mapping_path = outcome_dir / "preflight-identified-columns.json"
    mapping_path.write_text(json.dumps(decision.mapping, indent=2, default=str), encoding="utf-8")
    if decision.mapping.get("zero_sd_imputations"):
        zero_sd_path = outcome_dir / "preflight-zero-sd-imputation-assumptions.csv"
        with zero_sd_path.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(decision.mapping["zero_sd_imputations"][0].keys()))
            writer.writeheader()
            writer.writerows(decision.mapping["zero_sd_imputations"])


def preflight_pairwise_decisions(
    plan: list[PlannedAnalysis],
    workbook: Path,
    output_root: Path,
    args: argparse.Namespace,
) -> None:
    items = [
        item for item in plan
        if item.analysis_type in {"binary_pairwise", "continuous_pairwise"}
    ]
    if not items or args.dry_run:
        return

    print("\nPreflight LLM/Review Decisions")
    print("------------------------------")
    print("Collecting binary/continuous mappings and analysis choices before plot generation.")
    _, summary = workbook_summary_with_progress(workbook)
    decisions = [
        prepare_pairwise_preflight_decision(item, workbook, summary, args)
        for item in tqdm(items, desc="Preflight pairwise decisions", unit="outcome")
    ]
    decisions = review_pairwise_preflight_decisions(decisions, workbook, args.yes, args.binary_effect_size)
    for decision in tqdm(decisions, desc="Saving preflight decisions", unit="outcome"):
        save_pairwise_preflight_decision(decision, output_root)


def run_plan(plan: list[PlannedAnalysis], workbook: Path, output_root: Path, args: argparse.Namespace) -> list[PlannedAnalysis]:
    output_root.mkdir(parents=True, exist_ok=True)
    accepted = [item for item in plan if item.analysis_type != "skip"]
    if not accepted:
        print("\nNo analyses selected to run.")
        return []

    print("\nRunning Analyses")
    print("----------------")
    completed_items: list[PlannedAnalysis] = []

    def launch_item(item: PlannedAnalysis) -> tuple[PlannedAnalysis, int]:
        cmd = runner_command(item, workbook, output_root, args)
        if not cmd:
            return item, 0
        print(f"\n[{item.index}/{len(plan)}] {item.outcome_name} -> {item.label}")
        print("Command: " + " ".join(json.dumps(part) if " " in part else part for part in cmd))
        if args.dry_run:
            return item, 0
        completed = subprocess.run(cmd, text=True, check=False)
        return item, completed.returncode

    if args.jobs > 1 and not args.dry_run:
        with concurrent.futures.ThreadPoolExecutor(max_workers=args.jobs) as executor:
            future_by_item = {executor.submit(launch_item, item): item for item in accepted}
            for future in tqdm(concurrent.futures.as_completed(future_by_item), total=len(future_by_item), desc="Running analyses", unit="outcome"):
                item, returncode = future.result()
                if returncode != 0:
                    message = f"Analysis failed for sheet '{item.sheet}' with exit code {returncode}."
                    if args.continue_on_error:
                        print(message)
                        continue
                    raise SystemExit(message)
                try_generate_outcome_manuscript_narrative(item, workbook, output_root, args)
                completed_items.append(item)
    else:
        for item in tqdm(accepted, desc="Running analyses", unit="outcome"):
            item, returncode = launch_item(item)
            if args.dry_run:
                continue
            if returncode != 0:
                message = f"Analysis failed for sheet '{item.sheet}' with exit code {returncode}."
                if args.continue_on_error:
                    print(message)
                    continue
                raise SystemExit(message)
            try_generate_outcome_manuscript_narrative(item, workbook, output_root, args)
            completed_items.append(item)
    return sorted(completed_items, key=lambda item: item.index)


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Classify and run all meta-analysis outcomes in an Excel workbook or CSV file.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument("input", type=Path, nargs="?", help="Excel workbook or CSV file.")
    parser.add_argument("--output-root", type=Path, help="Root folder for all analysis outputs.")
    parser.add_argument(
        "--no-run-time-in-folder",
        action="store_true",
        help="Use the legacy default output folder name without appending the run timestamp.",
    )
    parser.add_argument("--yes", action="store_true", help="Accept the LLM classification table and runner prompts.")
    parser.add_argument("--dry-run", action="store_true", help="Show the plan and commands without running analyses.")
    parser.add_argument("--continue-on-error", action="store_true", help="Continue to later sheets if one analysis fails.")
    parser.add_argument("--jobs", type=int, default=int(os.environ.get("META_ANALYSIS_JOBS", "1")), help="Number of analyses to run in parallel after preflight decisions.")
    parser.add_argument(
        "--sheets",
        help="Analyze only selected sheets before any LMStudio request. Use numbers, names, comma lists, or ranges such as '1,3-5,LOS'.",
    )
    parser.add_argument(
        "--all-sheets",
        action="store_true",
        help="Evaluate every sheet in the workbook. Equivalent to --sheets all, but explicit.",
    )
    parser.add_argument("--no-lmstudio", action="store_true", help="Use column-name heuristics only for classification and runners.")
    parser.add_argument("--no-llm-report", action="store_true", help="Skip LMStudio manuscript narrative/report generation; still writes prompts and statistical drafts.")
    parser.add_argument(
        "--binary-effect-size",
        choices=["auto", "RR", "OR", "RD"],
        default="auto",
        help="Apply one effect measure to all binary count outcomes during preflight. Use RR to force relative risk globally.",
    )
    parser.add_argument("--group-column", help="Primary subgroup/group column name or number to pass to supported runners.")
    parser.add_argument("--subgroup-columns", help="Comma-separated subgroup column names or numbers to pass to supported runners. Use 'none' to clear.")
    parser.add_argument("--covariate-columns", help="Comma-separated meta-regression covariate column names or numbers to pass to binary/continuous runners. Use 'none' to clear.")
    parser.add_argument("--lmstudio-url", default=os.environ.get("LMSTUDIO_URL", "http://localhost:1234/v1"))
    parser.add_argument("--model", default=os.environ.get("LMSTUDIO_MODEL"))

    parser.add_argument("--network-engine", choices=["frequentist", "bayesian", "both"], default="frequentist")
    parser.add_argument("--rank-sims", type=int, default=100000, help="Rankogram simulations for network frequentist runs.")
    parser.add_argument("--install-r-packages", action="store_true", help="Let network runner install missing R packages.")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv or sys.argv[1:])
    if args.all_sheets and args.sheets:
        raise SystemExit("Use either --all-sheets or --sheets, not both.")
    args.jobs = max(1, int(args.jobs))
    input_path = args.input.expanduser() if args.input else common.prompt_for_excel_path()
    input_path = input_path.resolve()
    common.save_last_used_path(input_path)
    if not input_path.exists():
        raise SystemExit(f"Input file not found: {input_path}")
    if input_path.suffix.lower() not in {".xlsx", ".xls", ".xlsm", ".csv"}:
        raise SystemExit("Input must be an Excel workbook (.xlsx/.xls/.xlsm) or CSV file.")

    _, summary = workbook_summary_with_progress(input_path)
    print(f"\nLoaded: {input_path}")
    common.print_workbook_sheets(summary)
    selected_summary = choose_sheets_before_lmstudio(summary, args)

    lm_analyses = None
    if not args.no_lmstudio:
        print("\nSending workbook summary to LMStudio for sheet classification...")
        lm_analyses = call_lmstudio_classifier(
            summary=selected_summary,
            lmstudio_url=args.lmstudio_url,
            model=args.model,
            default_network_engine=args.network_engine,
        )
    else:
        print("\nLMStudio classification skipped; using column-name heuristics.")

    plan = build_plan(selected_summary, lm_analyses, args.network_engine)
    plan = edit_plan(plan, args.yes)
    # Once the user accepts the plan (interactively or via --yes),
    # propagate yes to all downstream prompts so they don't have to
    # re-confirm at every stage.
    args.yes = True

    output_root = args.output_root
    if output_root is None:
        output_root = default_output_root(input_path, include_run_time=not args.no_run_time_in_folder)
    output_root = output_root.expanduser().resolve()

    preflight_pairwise_decisions(plan, input_path, output_root, args)
    completed_items = run_plan(plan, input_path, output_root, args)
    if completed_items and not args.dry_run:
        collected = organize_collected_outputs(completed_items, output_root)
        report_path = generate_llm_results_report(
            completed_items=completed_items,
            workbook=input_path,
            output_root=output_root,
            args=args,
            report_dir=collected["report_dir"],
        )
        metareg_notes_path = write_metaregression_run_notes(
            completed_items=completed_items,
            output_root=output_root,
            report_dir=collected["report_dir"],
        )
        assumptions_audit_path = write_assumptions_audit_document(
            completed_items=completed_items,
            output_root=output_root,
            report_dir=collected["report_dir"],
        )
        tsa_summary_path = generate_tsa_summary_report(
            completed_items=completed_items,
            workbook=input_path,
            output_root=output_root,
            args=args,
            report_dir=collected["report_dir"],
        )
        print("\nCollected Outputs")
        print("-----------------")
        print(f"Collected outcome folder: {collected['collection_root']}")
        print(f"Additional information files: {collected['additional_info_count']}")
        print(f"Image files: {collected['image_count']}")
        print(f"LLM Methods and Results report: {report_path}")
        if metareg_notes_path:
            print(f"Meta-regression run notes: {metareg_notes_path}")
        if assumptions_audit_path:
            print(f"Analysis assumptions audit: {assumptions_audit_path}")
        if tsa_summary_path:
            print(f"TSA summary: {tsa_summary_path}")
    print(f"\nDone. Output root: {output_root}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
