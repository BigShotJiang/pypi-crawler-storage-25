from __future__ import annotations

import re
from datetime import date
from pathlib import Path

from docx import Document
from docx.enum.section import WD_ORIENT
from docx.enum.table import WD_ALIGN_VERTICAL, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor
from PIL import Image


NEW_ROOT = Path(
    "/Users/anuraj_ms/My Drive/EUS guided GJ anastomosis/forestplot_data/"
    "Meta Analysis Results - reverse_engineered_forest_plot_data_subgroup_columns_with_metaregression_variables - Run 20260503-112438"
)
OLD_ROOT = Path("/Users/anuraj_ms/My Drive/EUS guided GJ anastomosis/stats 4")
OUT_DOCX = Path("/Users/anuraj_ms/My Drive/EUS guided GJ anastomosis/Forest plot folder comparison with appendix notes - 20260503.docx")
WORK = Path("/Users/anuraj_ms/Documents/R-code_to-python/forestplot_comparison_assets")
WORK.mkdir(exist_ok=True)


OUTCOMES = [
    {
        "name": "Adverse Events",
        "new_dir": "01_Adverse Events",
        "old_main": "adverse events/ForestplotAdverse Events.tiff",
        "old_k": 19,
        "old_effect": "RR 0.57 [0.42; 0.79]",
        "old_i2": "61.4%",
        "driver": "New run adds Marya 2020 and slightly changes weights; direction and significance are unchanged.",
        "appendix_note": (
            "The newer plot contains 20 studies rather than 19 because Marya 2020 is included. "
            "This adds 348 participants and changes study weights, shifting the pooled RR from 0.57 [0.42; 0.79] "
            "in stats 4 to 0.5497 [0.4039; 0.7481] in the newer run. The interpretation is unchanged: adverse events remain lower with EUS-GJ."
        ),
    },
    {
        "name": "Clinical Success",
        "new_dir": "02_Clinical Success",
        "old_main": "Clinical success/ForestplotClinical success.tiff",
        "old_k": 19,
        "old_effect": "RR 1.11 [1.06; 1.17]",
        "old_i2": "54.5%",
        "driver": "New run adds Marya 2020, increasing total sample size and modestly changing weights.",
        "appendix_note": (
            "The newer plot includes Marya 2020 as an additional study, increasing the analysis from 19 to 20 studies. "
            "The pooled RR changes only slightly, from 1.11 [1.06; 1.17] to 1.1037 [1.0526; 1.1573], with similar statistical significance. "
            "The difference is therefore mainly a study-inclusion and weighting difference, not a change in direction."
        ),
    },
    {
        "name": "Recurrent GOO",
        "new_dir": "03_Recurrent GOO",
        "old_main": "Recurrent GOO/ForestplotRecurrent GOO.tiff",
        "old_k": 6,
        "old_effect": "RR 0.26 [0.10; 0.69]",
        "old_i2": "43.3%",
        "driver": "New run excludes Pawa 2023 as a double-zero study for RR analysis.",
        "appendix_note": (
            "The stats 4 plot includes 6 studies, while the newer run includes 5 because Pawa 2023 is excluded as a double-zero study. "
            "For RR analyses, double-zero studies do not estimate the relative direction or magnitude of effect. "
            "After exclusion, the pooled estimate changes from 0.26 [0.10; 0.69] to 0.2433 [0.0857; 0.6908], with the same overall conclusion."
        ),
    },
    {
        "name": "Reintervention",
        "new_dir": "04_Reintervention",
        "old_main": "Reintervention/ForestplotReintervention.tiff",
        "old_k": 7,
        "old_effect": "RR 0.36 [0.16; 0.80]",
        "old_i2": "50.8%",
        "driver": "New run adds Marya 2020, shifting the pooled estimate lower and increasing heterogeneity.",
        "appendix_note": (
            "The newer run adds Marya 2020, increasing the analysis from 7 to 8 studies and from 698 to 1062 participants. "
            "Because Marya 2020 has a low study-level RR, the pooled estimate shifts from 0.36 [0.16; 0.80] to 0.2900 [0.1330; 0.6323]. "
            "Heterogeneity also increases from I2 50.8% to 58.2%."
        ),
    },
    {
        "name": "Severe Adverse Events",
        "new_dir": "05_Severe Adverse Events",
        "old_main": "severe adverse events/ForestplotSevere Adverse Events.tiff",
        "old_k": 10,
        "old_effect": "RR 0.99 [0.55; 1.80]",
        "old_i2": "0.0%",
        "driver": "New run adds Marya 2020; the pooled result remains non-significant.",
        "appendix_note": (
            "The newer run includes Marya 2020, increasing the study count from 10 to 11 and the sample from 1119 to 1657 participants. "
            "The pooled estimate moves from 0.99 [0.55; 1.80] to 1.0952 [0.6288; 1.9074], but both results are non-significant and heterogeneity remains 0.0%."
        ),
    },
    {
        "name": "Stent Dysfunction",
        "new_dir": "06_Stent Dysfunction",
        "old_main": "stent dysfuntion/ForestplotStent Dysfunction.tiff",
        "old_k": 10,
        "old_effect": "RR 0.28 [0.17; 0.46]",
        "old_i2": "10.3%",
        "driver": "New run excludes Bronswijk 2021 as a double-zero study for RR analysis.",
        "appendix_note": (
            "The stats 4 plot includes 10 studies; the newer run includes 9 because Bronswijk 2021 is excluded as a double-zero study for RR analysis. "
            "This explains the lower sample count in the newer summary and the small shift from 0.28 [0.17; 0.46] to 0.2726 [0.1643; 0.4523]. "
            "The direction and significance remain unchanged."
        ),
    },
    {
        "name": "Technical Success",
        "new_dir": "07_Technical Success",
        "old_main": "technical success/ForestplotTechnical success.tiff",
        "old_k": 18,
        "old_effect": "RR 0.97 [0.95; 0.99]",
        "old_i2": "0.0%",
        "driver": "New run adds Marya 2020; the estimate is essentially unchanged at higher precision.",
        "appendix_note": (
            "The newer run includes Marya 2020, increasing the analysis from 18 to 19 studies and from 1565 to 1929 participants. "
            "The pooled RR remains essentially the same: 0.97 [0.95; 0.99] in stats 4 versus 0.9730 [0.9591; 0.9871] in the newer run. "
            "The main visible difference is the added row and redistributed weights."
        ),
    },
    {
        "name": "30-day Mortality",
        "new_dir": "08_30_day Mortality",
        "old_main": "mortality/Forestplot30dayMortality General.tiff",
        "old_k": 6,
        "old_effect": "RR 1.45 [0.78; 2.70]",
        "old_i2": "0.0%",
        "driver": "No substantive difference in the main pooled estimate.",
        "appendix_note": (
            "The main pooled estimate is effectively unchanged between folders: both show 6 studies and RR approximately 1.45 with a non-significant p value. "
            "Any visible differences are mainly formatting and labeling differences between the exported TIFF and newer PNG."
        ),
    },
    {
        "name": "Length of Stay",
        "new_dir": "09_Length of Stay",
        "old_main": "los/ForestplotLOS.tiff",
        "old_k": 10,
        "old_effect": "MD -2.7 [-4.7; -0.7]",
        "old_i2": "78.6%",
        "driver": "Pooled estimate matches after rounding; heterogeneity differs because the newer summary reports I2 from tau2.",
        "appendix_note": (
            "The pooled mean difference is unchanged after rounding: stats 4 shows MD -2.7 [-4.7; -0.7], while the newer run reports -2.6742 [-4.6734; -0.6750]. "
            "The study count and totals match. The I2 differs modestly, 78.6% versus 84.2%, because the newer summary reports I2 calculated from tau2 rather than the older displayed value."
        ),
    },
    {
        "name": "Procedure Time",
        "new_dir": "10_Procedure Time",
        "old_main": "procedure time/ForestplotProcedure time.tiff",
        "old_k": 4,
        "old_effect": "MD -69.1 [-147.2; 9.0]",
        "old_i2": "99.1%",
        "driver": "No substantive difference in the main pooled estimate.",
        "appendix_note": (
            "The pooled mean difference is effectively the same: stats 4 shows -69.1 [-147.2; 9.0], and the newer run reports -69.0845 [-147.1573; 8.9882]. "
            "The study count and totals match. Differences are visual/export-level rather than analytic."
        ),
    },
    {
        "name": "Time to Oral Intake",
        "new_dir": "11_Time to Oral Intake",
        "old_main": "time to oral/ForestplotTime to oral.tiff",
        "old_k": 4,
        "old_effect": "MD -1.9 [-4.3; 0.4]",
        "old_i2": "95.0%",
        "driver": "Pooled estimate matches after rounding; heterogeneity differs because the newer summary reports I2 from tau2.",
        "appendix_note": (
            "The pooled mean difference is unchanged after rounding: stats 4 shows -1.9 [-4.3; 0.4], while the newer run reports -1.9249 [-4.2601; 0.4102]. "
            "The study count and totals match. The I2 differs, 95.0% versus 99.0%, because the newer summary reports I2 calculated from tau2."
        ),
    },
]


def set_cell_shading(cell, fill: str) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:fill"), fill)
    tc_pr.append(shd)


def set_cell_text(cell, text: str, bold: bool = False, size: int = 8) -> None:
    cell.text = ""
    p = cell.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.LEFT
    run = p.add_run(text)
    run.bold = bold
    run.font.size = Pt(size)
    cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER


def style_table(table, header_fill: str = "E9EEF3") -> None:
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = True
    for row_idx, row in enumerate(table.rows):
        for cell in row.cells:
            tc_pr = cell._tc.get_or_add_tcPr()
            tc_borders = OxmlElement("w:tcBorders")
            for edge in ("top", "left", "bottom", "right"):
                tag = OxmlElement(f"w:{edge}")
                tag.set(qn("w:val"), "single")
                tag.set(qn("w:sz"), "4")
                tag.set(qn("w:space"), "0")
                tag.set(qn("w:color"), "B7C0C8")
                tc_borders.append(tag)
            tc_pr.append(tc_borders)
            if row_idx == 0:
                set_cell_shading(cell, header_fill)


def add_heading(doc: Document, text: str, level: int = 1) -> None:
    p = doc.add_heading(text, level=level)
    p.paragraph_format.keep_with_next = True


def parse_new_summary(outcome: dict) -> dict:
    addl = NEW_ROOT / "Collected Outcomes" / outcome["new_dir"] / "Additional Information"
    files = list(addl.glob("Summary*.txt"))
    if not files:
        return {}
    text = files[0].read_text(errors="replace")
    metric = "RR" if re.search(r"^\s*RR\s+95%-CI", text, re.M) else "MD"
    k = re.search(r"Number of studies: k = (\d+)", text)
    obs = re.search(r"Number of observations: o = ([^\n]+)", text)
    re_model = re.search(r"Random effects model\s+([-+]?\d+(?:\.\d+)?)\s+\[\s*([-+]?\d+(?:\.\d+)?);\s*([-+]?\d+(?:\.\d+)?)\]\s+([-+]?\d+(?:\.\d+)?)\s+(<\s*)?([0-9.]+)", text)
    i2 = re.search(r"I\^2 = ([0-9.]+%)", text)
    tau2 = re.search(r"tau\^2\s*(?:=|<)\s*([0-9.]+)", text)
    q = re.search(r"\n\s*([0-9.]+)\s+(\d+)\s+(<\s*)?([0-9.]+)\n\nDetails", text)
    studies = []
    for line in text.splitlines():
        if re.search(r"\[[^\]]+;[^\]]+\]", line) and not line.strip().startswith("Random effects model"):
            study = re.split(r"\s{2,}", line.strip())[0]
            if study and not study.startswith(("Prediction", "Subgroup", "Random")):
                studies.append(study)
    return {
        "metric": metric,
        "k": k.group(1) if k else "",
        "obs": obs.group(1) if obs else "",
        "effect": f"{metric} {float(re_model.group(1)):.4f} [{float(re_model.group(2)):.4f}; {float(re_model.group(3)):.4f}]" if re_model else "",
        "p": (("< " if re_model and re_model.group(5) else "") + re_model.group(6)) if re_model else "",
        "i2": i2.group(1) if i2 else "",
        "tau2": tau2.group(1) if tau2 else "",
        "q": f"{q.group(1)}, df {q.group(2)}, p {('< ' if q.group(3) else '') + q.group(4)}" if q else "",
        "studies": studies,
    }


def rel_file_count(root: Path, pattern: str = "*") -> int:
    return sum(1 for p in root.rglob(pattern) if p.is_file())


def outcome_files_new(outcome: dict) -> list[str]:
    root = NEW_ROOT / "Collected Outcomes" / outcome["new_dir"]
    return [p.name for p in (root / "Images").glob("*") if p.is_file()]


def old_outcome_root(outcome: dict) -> Path:
    old_main = OLD_ROOT / outcome["old_main"]
    return old_main.parent


def find_old_by_terms(outcome: dict, *terms: str) -> bool:
    root = old_outcome_root(outcome)
    files = [p.name.lower() for p in root.glob("*") if p.is_file()]
    return any(all(t.lower() in f for t in terms) for f in files)


def find_new_by_terms(outcome: dict, *terms: str) -> bool:
    files = [f.lower() for f in outcome_files_new(outcome)]
    return any(all(t.lower() in f for t in terms) for f in files)


def convert_for_doc(src: Path, label: str, max_px: int = 1800) -> Path:
    out = WORK / f"{label}.png"
    im = Image.open(src).convert("RGB")
    im.thumbnail((max_px, max_px), Image.Resampling.LANCZOS)
    bg = Image.new("RGB", im.size, "white")
    bg.paste(im)
    bg.save(out, optimize=True)
    return out


def add_bullet(doc: Document, text: str) -> None:
    p = doc.add_paragraph(style="List Bullet")
    p.paragraph_format.space_after = Pt(3)
    run = p.add_run(text)
    run.font.size = Pt(10)


def configure_document(doc: Document) -> None:
    section = doc.sections[0]
    section.orientation = WD_ORIENT.LANDSCAPE
    section.page_width = Inches(11)
    section.page_height = Inches(8.5)
    section.top_margin = Inches(0.5)
    section.bottom_margin = Inches(0.5)
    section.left_margin = Inches(0.55)
    section.right_margin = Inches(0.55)
    styles = doc.styles
    styles["Normal"].font.name = "Arial"
    styles["Normal"].font.size = Pt(10)
    styles["Title"].font.name = "Arial"
    styles["Title"].font.size = Pt(22)
    styles["Title"].font.bold = True
    for name, size in [("Heading 1", 15), ("Heading 2", 12), ("Heading 3", 10)]:
        styles[name].font.name = "Arial"
        styles[name].font.size = Pt(size)
        styles[name].font.bold = True
        styles[name].font.color.rgb = RGBColor(36, 65, 95)


def add_metadata_table(doc: Document) -> None:
    table = doc.add_table(rows=4, cols=2)
    rows = [
        ("Newer run folder", str(NEW_ROOT)),
        ("Older comparison folder", str(OLD_ROOT)),
        ("Report generated", date.today().isoformat()),
        ("Scope", "Folder and subfolder inventory, main forest plot estimates, plot availability, and visual-format differences."),
    ]
    for row, (label, value) in zip(table.rows, rows):
        set_cell_text(row.cells[0], label, bold=True, size=8)
        set_cell_text(row.cells[1], value, size=8)
    style_table(table, "F3F6F8")


def add_main_comparison_table(doc: Document, parsed: dict[str, dict]) -> None:
    add_heading(doc, "Main Forest Plot Comparison", 1)
    doc.add_paragraph(
        "Older estimates were read from the rendered TIFF forest plots because stats 4 did not contain machine-readable summary tables for these outcomes. "
        "Newer estimates are from the Summary*.txt files in each outcome folder."
    )
    headers = ["Outcome", "stats 4 main result", "new run main result", "k old -> new", "I2 old -> new", "Difference / likely driver"]
    table = doc.add_table(rows=1, cols=len(headers))
    for cell, h in zip(table.rows[0].cells, headers):
        set_cell_text(cell, h, bold=True, size=7)
    for outcome in OUTCOMES:
        new = parsed[outcome["name"]]
        cells = table.add_row().cells
        vals = [
            outcome["name"],
            outcome["old_effect"],
            f"{new.get('effect', '')}; p {new.get('p', '')}",
            f"{outcome['old_k']} -> {new.get('k', '')}",
            f"{outcome['old_i2']} -> {new.get('i2', '')}",
            outcome["driver"],
        ]
        for cell, val in zip(cells, vals):
            set_cell_text(cell, val, size=7)
    style_table(table)


def add_artifact_matrix(doc: Document) -> None:
    add_heading(doc, "Plot And File Availability", 1)
    headers = [
        "Outcome",
        "Main",
        "LOO",
        "Etiology subgroup",
        "Control subgroup",
        "Funnel",
        "Baujat",
        "TSA image",
        "New-only additions",
    ]
    table = doc.add_table(rows=1, cols=len(headers))
    for cell, h in zip(table.rows[0].cells, headers):
        set_cell_text(cell, h, bold=True, size=7)
    for outcome in OUTCOMES:
        cells = table.add_row().cells
        new_meta = any("Metarregression" in f for f in outcome_files_new(outcome))
        vals = [
            outcome["name"],
            "both",
            "both" if find_new_by_terms(outcome, "leave") and find_old_by_terms(outcome, "loo") else "partial",
            "both" if find_new_by_terms(outcome, "etiology") and find_old_by_terms(outcome, "etiology") else "partial",
            "both" if find_new_by_terms(outcome, "control") and find_old_by_terms(outcome, "control") else "partial",
            "both" if find_new_by_terms(outcome, "funnel") else ("old-only" if outcome["name"] in ["Clinical Success"] else "partial"),
            "both" if find_new_by_terms(outcome, "baujat") else "partial",
            "both" if find_new_by_terms(outcome, "adjusted", "boundaries") and (old_outcome_root(outcome) / "TSA").exists() or (old_outcome_root(outcome) / f"TSA {outcome['name']}").exists() else "partial",
            "meta-regression plots; TXT/CSV/R/RDS/docx audit outputs" if new_meta else "TXT/CSV/R/RDS/docx audit outputs",
        ]
        for cell, val in zip(cells, vals):
            set_cell_text(cell, val, size=7)
    style_table(table)


def add_folder_summary(doc: Document) -> None:
    add_heading(doc, "Folder-Level Differences", 1)
    new_collected = NEW_ROOT / "Collected Outcomes"
    summary_rows = [
        ("Outcome organization", "Numbered outcome folders with Images and Additional Information subfolders.", "Outcome folders plus shared Baujat and Funnel Plots folders; one typo: stent dysfuntion."),
        ("Machine-readable results", "Extensive TXT/CSV/JSON/R/RDS outputs per outcome.", "Only one clinical-success TSA CSV pair plus one statistical-analysis DOCX; main forest plot estimates are image-only."),
        ("Image formats", "Mostly PNG, with some TIFF copies for TSA boundary prints.", "Mostly TIFF forest plots, with PNG TSA plots."),
        ("Narrative files", "Per-outcome manuscript narratives and combined manuscript reports.", "One methods/statistical-analysis paragraph DOCX."),
        ("File volume", f"{rel_file_count(NEW_ROOT)} files under the newer run.", f"{rel_file_count(OLD_ROOT)} files under stats 4."),
    ]
    table = doc.add_table(rows=1, cols=3)
    for cell, h in zip(table.rows[0].cells, ["Dimension", "Newer run", "stats 4"]):
        set_cell_text(cell, h, bold=True, size=8)
    for row in summary_rows:
        cells = table.add_row().cells
        for cell, val in zip(cells, row):
            set_cell_text(cell, val, size=8)
    style_table(table)


def add_visual_differences(doc: Document) -> None:
    add_heading(doc, "Visual And Labeling Differences", 1)
    items = [
        "The newer plots use the generic comparator label Control, while stats 4 uses Non EUS-GJ.",
        "The newer forest plot images render the EUS-GJ hyphen as a square placeholder in several plots, suggesting an encoding/font issue.",
        "Several newer plot headers show MH, Random, 95% CI, while the newer text summaries state inverse-variance methods; this labeling/method mismatch should be checked before manuscript use.",
        "The newer folder includes Baujat, funnel, leave-one-out, subgroup, TSA, and meta-regression outputs in a more reproducible structure; stats 4 is more publication-image oriented.",
        "The newer subgroup outputs are sometimes named control_type_regressor / etiology_regressor and sometimes Control type / Etiology, while stats 4 uses simpler control / etiology names.",
    ]
    for item in items:
        add_bullet(doc, item)


def add_appendix_images(doc: Document) -> None:
    add_heading(doc, "Appendix: Representative Main Forest Plots", 1)
    doc.add_paragraph("Each row pairs the stats 4 main forest plot with the newer main forest plot for the same outcome.")
    for idx, outcome in enumerate(OUTCOMES):
        new_image = NEW_ROOT / "Collected Outcomes" / outcome["new_dir"] / "Images" / f"Forestplot{outcome['name'].replace('30-day', '30_day')}.png"
        if outcome["name"] == "30-day Mortality":
            new_image = NEW_ROOT / "Collected Outcomes" / outcome["new_dir"] / "Images" / "Forestplot30_day Mortality.png"
        old_image = OLD_ROOT / outcome["old_main"]
        if not new_image.exists() or not old_image.exists():
            continue
        add_heading(doc, outcome["name"], 2)
        table = doc.add_table(rows=2, cols=2)
        set_cell_text(table.rows[0].cells[0], "stats 4", bold=True, size=8)
        set_cell_text(table.rows[0].cells[1], "newer run", bold=True, size=8)
        old_png = convert_for_doc(old_image, f"old_{idx}")
        new_png = convert_for_doc(new_image, f"new_{idx}")
        for cell, img in [(table.rows[1].cells[0], old_png), (table.rows[1].cells[1], new_png)]:
            p = cell.paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p.add_run().add_picture(str(img), width=Inches(4.65))
            cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
        style_table(table, "F3F6F8")
        p = doc.add_paragraph()
        p.paragraph_format.space_before = Pt(4)
        p.paragraph_format.space_after = Pt(8)
        p.paragraph_format.keep_together = True
        lead = p.add_run("Why this differs: ")
        lead.bold = True
        lead.font.size = Pt(9)
        body = p.add_run(outcome["appendix_note"])
        body.font.size = Pt(9)


def main() -> None:
    parsed = {outcome["name"]: parse_new_summary(outcome) for outcome in OUTCOMES}
    doc = Document()
    configure_document(doc)
    title = doc.add_paragraph(style="Title")
    title.add_run("Forest Plot Folder Comparison")
    subtitle = doc.add_paragraph()
    subtitle.add_run("Reverse-engineered meta-analysis run vs stats 4").italic = True
    add_metadata_table(doc)

    add_heading(doc, "Executive Summary", 1)
    for item in [
        "Both folders cover the same 11 outcome families, but the newer run is much more reproducible because it includes source summaries, audit files, scripts, datasets, and manuscript narratives.",
        "The main pooled estimates are directionally consistent across folders. Differences are usually explainable by study inclusion/handling rather than unexplained statistical drift.",
        "Marya 2020 is included in the newer run for several outcomes and is absent from the corresponding stats 4 main plots, changing k and weights for Adverse Events, Clinical Success, Reintervention, Severe Adverse Events, and Technical Success.",
        "The newer run explicitly excludes double-zero studies for RR analyses: Pawa 2023 in Recurrent GOO and Bronswijk 2021 in Stent Dysfunction.",
        "Continuous outcomes and 30-day Mortality are essentially unchanged in their pooled estimates after rounding, although reported I2 differs for Length of Stay and Time to Oral Intake.",
    ]:
        add_bullet(doc, item)

    add_main_comparison_table(doc, parsed)
    add_folder_summary(doc)
    add_artifact_matrix(doc)
    add_visual_differences(doc)
    add_appendix_images(doc)

    doc.save(OUT_DOCX)
    print(OUT_DOCX)


if __name__ == "__main__":
    main()
