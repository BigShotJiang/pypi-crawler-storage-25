"""Packaged copies of the original command-line runner scripts."""

from __future__ import annotations

import sys
from pathlib import Path

_RUNNERS_DIR = str(Path(__file__).resolve().parent)
if _RUNNERS_DIR not in sys.path:
    sys.path.insert(0, _RUNNERS_DIR)
