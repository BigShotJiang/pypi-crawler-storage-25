# Binary Endpoint Meta-Analysis Runner

This folder contains a Python wrapper for the binary endpoint R Markdown template.
It keeps the statistical work in R through `meta::metabin`, so the output matches
the original R workflow, while Python handles Excel loading, LMStudio column
identification, validation, and output organization.

It also includes `continuous_outcome.py`, a matching runner for continuous
endpoints using `meta::metacont`.

It now also includes `diagnostic_meta_analysis.py`, a runner for diagnostic test
accuracy meta-analysis using study-level `TP`, `FP`, `TN`, and `FN` counts.

It also includes `single_arm_meta_analysis.py`, a runner for single-arm
proportion and single-arm mean meta-analysis using the templates in:

- `/Volumes/Firecuda-4TB/Downloads/Single Proportions`
- `/Volumes/Firecuda-4TB/Downloads/Single Means`

It also includes `network_meta_analysis.py`, a runner for long-arm network
meta-analysis using the frequentist and Bayesian templates in:

- `/Volumes/Firecuda-4TB/Downloads/Frequentis Network Meta analysis`
- `/Volumes/Firecuda-4TB/Downloads/Bayesian Network Meta analysis`

The network runner does not perform trial sequential analysis.

## Usage

To let the orchestrator classify every sheet in an Excel workbook or a CSV file,
review the plan, and run the matching analysis scripts:

```bash
/Users/anurajms_mac_studio/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 main.py "/path/to/workbook.xlsx"
```

After listing workbook sheets, `main.py` asks whether to analyze all sheets or
only selected sheet numbers/names before it sends anything to LMStudio. For
non-interactive runs, select sheets up front:

```bash
/Users/anurajms_mac_studio/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 main.py "/path/to/workbook.xlsx" --sheets "1,3-5,LOS"
```

For a non-interactive dry run that only shows the detected plan and commands:

```bash
/Users/anurajms_mac_studio/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 main.py "/path/to/workbook.xlsx" --yes --dry-run
```

```bash
/Users/anurajms_mac_studio/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 binary_outcome.py "/path/to/data.xlsx"
```

For continuous outcomes:

```bash
/Users/anurajms_mac_studio/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 continuous_outcome.py "/path/to/data.xlsx"
```

For single-arm proportions:

```bash
/Users/anurajms_mac_studio/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 single_arm_meta_analysis.py "/path/to/single-arm.xlsx" --type proportion
```

For single-arm means:

```bash
/Users/anurajms_mac_studio/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 single_arm_meta_analysis.py "/path/to/single-arm.xlsx" --type mean
```

For single-arm diagnostic accuracy:

```bash
/Users/anurajms_mac_studio/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 diagnostic_meta_analysis.py "/path/to/diagnostic.xlsx" --mode single
```

For comparative diagnostic accuracy using a combined sheet with a test/category
column:

```bash
/Users/anurajms_mac_studio/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 diagnostic_meta_analysis.py "/path/to/combined.xlsx" --mode comparative --test-a-label DWI --test-b-label PET
```

For frequentist network meta-analysis:

```bash
/Users/anurajms_mac_studio/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 network_meta_analysis.py "/path/to/nma.xlsx" --outcome-type binary --engine frequentist
```

For Bayesian network meta-analysis:

```bash
/Users/anurajms_mac_studio/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 network_meta_analysis.py "/path/to/nma.xlsx" --outcome-type continuous --engine bayesian
```

To generate both frequentist and Bayesian NMA outputs from the same sheet:

```bash
/Users/anurajms_mac_studio/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 network_meta_analysis.py "/path/to/nma.xlsx" --outcome-type binary --engine both
```

By default, the script:

- lists every workbook sheet and asks which one should be analyzed;
- sends the selected sheet's headers and sample rows to local LMStudio at
  `http://localhost:1234/v1`;
- identifies the study label, intervention event/total, control event/total,
  subgroup, and covariate columns;
- shows the LLM's suggested mapping for confirmation, with numbered columns so
  incorrect fields can be fixed by typing a number;
- asks the LLM to choose RR vs OR and inverse variance vs Mantel-Haenszel vs
  Peto using the PDF rules, then shows the reason and lets you override it;
- asks the LLM to choose random-effects vs common/fixed-effect, explains the
  choice, and lets you override it before R runs;
- asks the LLM whether the outcome is beneficial or harmful and uses that to
  place `Favors ...` labels on the left/right side of the null line; if you
  disagree, choose the change prompt and flip them;
- configures trial sequential analysis settings, including two-sided alpha,
  power, diversity-adjusted required information size, and the anticipated
  effect source;
- extracts and previews the binary-analysis table before running R;
- runs the R `meta` workflow;
- creates a manuscript-oriented Word summary with the pooled analysis,
  subgroup analyses, leave-one-out sensitivity analysis, figure inventory, and
  extracted dataset;
- when multiple outcomes are run through `main.py`, creates a collected
  statistics-only manuscript Results report that incorporates pooled analyses,
  subgroup tests, Baujat diagnostics, funnel/Egger output, meta-regression,
  leave-one-out sensitivity analysis, trial sequential analysis, and available
  generated figures; and
- saves results beside the Excel file in a folder named after the chosen sheet.

## Main Orchestrator

`main.py` reads `.xlsx`, `.xls`, `.xlsm`, and `.csv` files, lists the workbook
sheets, and waits for sheet-selection feedback before any LMStudio request. It
then sends only the selected sheet names, headers, and preview rows to LMStudio
and shows a console table with the suggested study type, outcome name,
confidence, warnings, and the reason for each choice. Each outcome is numbered,
so one Enter/`y` accepts the full table; if a change is needed, type `edit` and
then the outcome number to change the analysis type, outcome name, and network
engine before any R analysis starts.
Progress bars show ETA while scanning sheets, classifying the workbook,
preflighting pairwise decisions, running analyses, collecting outputs, and
building manuscript-report context.
For binary and continuous outcomes, the workbook-level LLM request can also
return the proposed column mapping and statistical-analysis choices. The
preflight step validates those decisions, prints one numbered table, and accepts
all with one Enter/`y`; choose `edit` or `no` only when you want to review
individual outcomes in detail.
At that bulk preflight review, you can also apply one effect measure to every
binary count outcome at once, such as `RR` for relative risk. For non-interactive
runs, use `--binary-effect-size RR`; HR-only time-to-event outcomes are left
unchanged, and Peto pooling is changed to Mantel-Haenszel if RR or RD is forced.
The same review table now shows all numeric meta-regression candidates. The LLM
is asked to distinguish the sheet outcome/dependent variable from numeric
regressors and can return multiple candidates such as age, BMI, follow-up,
publication year, percent male, or sample size.
If `--output-root` is omitted, `main.py` creates a run-specific folder beside the
workbook, for example `Meta Analysis Results - workbook_name - Run
20260430-143015`. Use `--no-run-time-in-folder` only when you need the older
non-timestamped folder name.
After each outcome finishes, `main.py` immediately parses the generated pooled
summary, subgroup outputs, Baujat coordinates, funnel/Egger output,
meta-regression, leave-one-out sensitivity output, TSA files, and generated plot
inventory. It then prints a manuscript-ready outcome interpretation in the
console and saves both statistical and LLM-polished narrative files in that
outcome folder.

Supported routed study types:

- binary pairwise meta-analysis;
- time-to-event hazard-ratio meta-analysis through the binary runner;
- continuous pairwise meta-analysis;
- single-arm proportion meta-analysis;
- single-arm mean meta-analysis;
- diagnostic accuracy meta-analysis;
- comparative diagnostic accuracy when one sheet has TP/FP/TN/FN plus a
  test/category column;
- binary or continuous network meta-analysis.

If you run without `--yes`, each specialized runner still asks its original
column-mapping and analysis-choice questions. If you use `--yes`, the
orchestrator accepts the review table and passes non-interactive mode to the
runner scripts.

For non-interactive runs:

```bash
/Users/anurajms_mac_studio/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 binary_outcome.py "/path/to/data.xlsx" --yes
```

If LMStudio is not running, the script falls back to column-name matching. You can
also skip LMStudio explicitly:

```bash
/Users/anurajms_mac_studio/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 binary_outcome.py "/path/to/data.xlsx" --no-lmstudio --yes
```

Useful options:

- `--sheet "Sheet name"` selects a specific sheet.
- `--outcome "Cardiovascular Mortality"` controls output file names.
- `--output-dir "binary outcome"` controls where files are saved. If omitted,
  outputs go beside the Excel file in a folder named after the chosen sheet.
- `--preview-rows 50` controls how many extracted data rows are printed before
  analysis.
- `--tsa-ris 1068` overrides the calculated trial sequential analysis required
  information size when you need to reproduce a protocol/TSA-software value.
- `--tsa-pc 0.20` and `--tsa-pt 0.10` override the control and intervention
  event proportions used for binary TSA required-information-size calculations.
- `--lmstudio-url "http://localhost:1234/v1"` changes the LMStudio endpoint.
- `--model "your-local-model"` sets the local model id. If omitted, the script
  asks LMStudio for `/v1/models` and uses the first available model.

## Expected Excel Data

The required binary endpoint fields are:

- study label, usually `Author`;
- intervention events, equivalent to R `event.e`;
- intervention total, equivalent to R `n.e`;
- control events, equivalent to R `event.c`;
- control total, equivalent to R `n.c`.

For time-to-event outcomes reported as hazard ratios, the binary runner can
instead use:

- study label, usually `Author`;
- `HR`, `CI lower`, and `CI upper`; or
- `log(HR)` and `SE log(HR)`.

Hazard-ratio analyses are pooled with `meta::metagen` on `log(HR)` using generic
inverse variance (`sm = "HR"`, back-transformed for plots and summaries). Trial
sequential analysis is skipped for HR inputs because the runner does not have
arm-level event risks for required-information-size calculations. Subgroup
analysis and meta-regression are available when categorical subgroup columns or
numeric/categorical covariate columns are mapped.

Optional fields:

- one or more categorical subgroup columns;
- one or more numeric or categorical meta-regression covariates, either in
  `covariate` or as multiple selected covariate columns.

For meta-regression, text moderators such as `Etiology`, `Control type`, or
`Region` are retained as labels and passed to R as factors. The generated
`MetaregSummary...txt` lists the factor level counts and uses the first workbook
level as the reference; multi-class moderators are modeled with the usual
`k - 1` dummy coefficients. Bubble plots are generated for numeric moderators
only, because a categorical factor has no meaningful continuous x-axis.

If one underlying study appears on multiple rows, including labels with trailing
copy markers such as `Study 2020 (1)` and `Study 2020 (2)`, the pairwise runners
group those rows before the overall analysis. By default, compatible arms are
combined into one pairwise comparison to avoid double-counting a shared
intervention or comparator arm; the interactive review also allows shared-arm
splitting or subgroup-only output when that is the intended analysis. When a
combined multi-arm study also contributes to subgroup analyses, the primary
overall forest plot and summary use the combined row, while subgroup analyses use
a separate shared-arm split dataset and write a `SubgroupDatasetNote...txt` audit
note.

Pooling-method rules from the PDF:

- Mantel-Haenszel (`MH`): preferred when events are few/sparse or sample sizes
  are small.
- Inverse variance (`inverse`): standard choice when events are common or
  studies are large.
- Peto (`Peto`): only for very rare events with small effects and balanced
  groups; it can only be used with odds ratios and a common-effect model.

Model-choice rule:

- Random-effects: default for clinical meta-analyses when between-study clinical
  or methodological heterogeneity is plausible.
- Common/fixed-effect: use when one common true effect is defensible, or when
  Peto is selected.

The provided template at
`/Volumes/Firecuda-4TB/Downloads/Binary Endpoint Meta-Analysis Template Table.xlsx`
contains the right headers, but it has no study rows yet. Add data rows before
running the analysis.

## Continuous Outcomes

`continuous_outcome.py` supports both continuous templates:

- mean ± SD data with `Author`, `mean.e`, `sd.e`, `n.e`, `mean.c`, `sd.c`, `n.c`;
- median ± IQR/range data with `median.e`, `q1.e`, `q3.e`, optional `min.e`,
  `max.e`, and matching control-group columns.

The script asks LMStudio to choose:

- `MD` when studies use the same scale/unit;
- `SMD` when studies measure the same construct using different
  scales/instruments;
- whether median/IQR/range values should be converted by `meta::metacont`;
- random-effects vs common/fixed-effect model;
- plot direction labels based on whether lower or higher values are better.

## Single-Arm Proportions and Means

`single_arm_meta_analysis.py` supports both single-arm templates:

- proportions with `Author`, `event`, `n`, optional `subgroup`, and optional
  numeric `covariate`;
- means with `Author`, `n`, `mean`, `sd`, optional `subgroup`, and optional
  numeric `covariate`.

Use `--type auto` (the default) to infer the analysis from the selected sheet, or
set `--type proportion` / `--type mean` explicitly. The runner creates the
overall forest plot, subgroup forest plots, leave-one-out plot, funnel plot,
Egger-test note/output, optional meta-regression output, extracted CSV,
generated R script, and a manuscript-oriented Word summary.

## Diagnostic Accuracy

`diagnostic_meta_analysis.py` supports the diagnostic templates in:

- `/Users/anuraj_ms/Documents/Single Arm Diagnostic Meta analysis`
- `/Users/anuraj_ms/Documents/Comparative Diagnostic Meta analysis`

Required fields:

- study label, usually `Author` or `names`;
- `TP`: true positives;
- `FP`: false positives;
- `TN`: true negatives;
- `FN`: false negatives.

Comparative mode also expects either:

- one combined sheet with a diagnostic test/category column such as `category1`;
  or
- two sheets supplied with `--test-a-sheet` and `--test-b-sheet`.

The diagnostic runner generates pooled sensitivity and specificity forest plots,
diagnostic odds ratio (DOR) analysis, DOR funnel/Deeks output when enough studies
are present, leave-one-out DOR sensitivity analysis, threshold-effect
correlations, SROC output when the R `mada` package is installed, and a Word
results summary.

## Network Meta-Analysis

`network_meta_analysis.py` expects one long-arm row per study arm.

Binary NMA fields:

- `study`
- `treatment`
- `responders`
- `sampleSize`
- optional `year`

Continuous NMA fields:

- `study`
- `treatment`
- `mean`
- `std.dev`
- `sampleSize`
- optional `year`

The script can infer common column names and lets you confirm or override them.
You can also pass exact mappings with options such as `--study-col`,
`--treatment-col`, `--event-col`, `--n-col`, `--mean-col`, and `--sd-col`.

Frequentist outputs use `meta::pairwise` and `netmeta::netmeta`, including the
network graph, heterogeneity/design decomposition text, league table, node
splitting output, ranking, rankogram, and comparison-adjusted funnel plot. The
frequentist workflow uses the R packages `meta`, `netmeta`, and `openxlsx`.

Bayesian outputs use `gemtc::mtc.network`, a random-effects consistency model,
trace/Gelman diagnostics, league table, optional node splitting, rank
probabilities, and SUCRA output. Bayesian analyses require JAGS/rjags in
addition to the R packages.

## Trial Sequential Analysis

The binary and continuous runners create a TSA folder for each outcome, for example
`TSA Clinical success/Adjusted Boundaries Print.png`.

Defaults are:

- two-sided alpha = `0.05`;
- power = `0.80`;
- observed pooled effect as the anticipated effect unless a protocol-defined
  clinically important effect is provided;
- diversity-adjusted required information size when `random_adj = "D2"` is selected;
- RTSA-reported cumulative Z-curve values from the integrated analysis object,
  with study order passed from a numeric `tsa_order`/`order` column when
  available; if no explicit order is provided, TSA runs only when parsed study
  years define an unambiguous sequence with no ties or missing years;
- RTSA-derived required information size and Lan-DeMets O'Brien-Fleming
  alpha-spending monitoring boundaries from the integrated analysis object;
- non-binding beta-spending futility boundaries written to
  `TSAFutilityBoundaries...csv` and drawn on the adjusted-boundaries plot when
  RTSA returns finite coordinates;
- observed and RIS-input control/intervention event proportions written to the
  TSA parameter table for auditability;
- OR/RR anticipated effects passed to RTSA on the natural ratio scale, not the
  log scale;
- binary adjusted-boundaries plots use a documented display sign flip so the
  plotted top/bottom `Favours ...` labels match the selected clinical direction;
  raw `TSAZCurveData...csv` values remain on the extracted engine scale;
- continuous MD TSA passes `sd_mc = NULL` to `RTSA(type = "analysis")`, allowing
  RTSA to compute the MD sample-size SD internally;
- `TSAAudit...csv` includes an RTSA inference status that distinguishes
  integrated `RTSA(type = "analysis")` output from fallback diagnostics, plus
  separate efficacy-boundary and non-binding futility assessment rows.

The adjusted-boundaries figure is generated from the integrated
`RTSA(type = "analysis")` object because that is the R package path intended to
reproduce the original TSA software workflow. If binary integrated RTSA is
skipped or fails, the runner may write a clearly labelled diagnostic fallback
plot using a sequential `meta::metabin` Z-curve with `RTSA::ris` /
`RTSA::boundaries` boundaries. That fallback plot includes an in-figure warning,
and downstream summaries do not report a monitoring-boundary assessment for
fallback diagnostics because the Z-curve and boundaries are not directly
comparable. Continuous TSA does not
create substitute Z-curves or monitoring boundaries when integrated RTSA fails.
If `RTSA` is not installed, the standard meta-analysis still runs and a
`TSANotes...txt` file explains that validated TSA boundaries were not generated.
Binary TSA is skipped for Peto analyses because this runner does not implement a
method-consistent Peto-based sequential Z-curve.

If you answer `no` when reviewing the analysis choices, the scripts let you
change alpha, power, diversity adjustment, anticipated effect source, RIS, and
RIS input event proportions.

## Outputs

When outcomes are run through `main.py`, the final run output is consolidated
under `Collected Outcomes`. Each numbered outcome folder contains:

- `Images/` for all generated plots and image outputs;
- `Additional Information/` for summaries, extracted datasets, generated R
  scripts, JSON prompts/mappings, Word documents, and other supporting files.

The temporary per-outcome runner folders are moved into this collected layout,
so duplicate root-level outcome folders are not retained after collection.

Binary and continuous output folders include:

- `identified-columns.json`
- `extracted-binary-data.csv`
- `generated_binary_meta_analysis.R`
- `Summary<outcome>.txt`
- `Manuscript Results Summary - <outcome>.docx`
- `Forestplot<outcome>.png`
- `Leave-one-out<outcome>.png`
- `FunnelPlot<outcome>.png`
- `BaujatPlot<outcome>.png`
- `BaujatCoordinates<outcome>.csv`
- `MetaregSummary - <covariate> - <outcome>.txt` and `Metarregression -
  <covariate> - <outcome>.png` for each usable numeric meta-regression
  covariate
- `TSA <outcome>/Adjusted Boundaries Print.png` when `RTSA` is installed and
  the RTSA analysis/plot succeeds
- `TSA <outcome>/TSAZCurveData<outcome>.csv`
- `TSA <outcome>/TSABoundaries<outcome>.csv`
- `TSA <outcome>/TSAParameters<outcome>.csv`
- `TSA <outcome>/TSAAudit<outcome>.csv`, including Z-curve completeness, plot
  generation status, RIS reach status, monitoring-boundary assessment when
  available from integrated RTSA, non-binding futility assessment, and RTSA
  engine status
- `TSA <outcome>/TSANotes<outcome>.txt` when validated RTSA boundaries cannot
  be generated
- one subgroup forest plot per selected subgroup column
- Egger test outputs when there are at least 10 studies
- meta-regression outputs for each selected numeric covariate

Diagnostic output folders include:

- `identified-columns.json`
- `extracted-diagnostic-data.csv`
- `generated_diagnostic_meta_analysis.R`
- `Manuscript Results Summary - <outcome>.docx`
- `SummarySensitivity - <test>.txt`
- `SummarySpecificity - <test>.txt`
- `SummaryDOR - <test>.txt`
- `ForestplotSensitivity - <test>.png`
- `ForestplotSpecificity - <test>.png`
- `ForestplotDOR - <test>.png`
- `SROC - <test>.png` when `mada` is installed
- `ThresholdEffect - <test>.csv`
