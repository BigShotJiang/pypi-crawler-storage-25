"""ACP (Agent Communication Protocol) adapter for eximia-agent."""
