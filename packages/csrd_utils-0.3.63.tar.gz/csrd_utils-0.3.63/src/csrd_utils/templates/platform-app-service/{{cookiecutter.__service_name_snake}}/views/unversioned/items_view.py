import uuid
from datetime import UTC, datetime

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from ...dependencies import VerifiedTokenDep

router = APIRouter(prefix="/api", tags=["Items Endpoints"])

_ITEMS: dict[str, dict[str, str]] = {}


class CreateItemRequest(BaseModel):
    name: str


class UpdateItemRequest(BaseModel):
    name: str


class ItemResponse(BaseModel):
    id: str
    name: str
    created_at: str


class ItemListResponse(BaseModel):
    items: list[ItemResponse]


class ItemUpdateResponse(BaseModel):
    id: str
    name: str
    updated: bool


class ItemUpsertResponse(BaseModel):
    id: str
    name: str
    rows_affected: int


class ItemDeleteResponse(BaseModel):
    id: str
    deleted: bool


@router.post("/items", response_model=ItemResponse)
async def create_item(payload: CreateItemRequest, _verified: VerifiedTokenDep) -> ItemResponse:
    item_id = str(uuid.uuid4())
    created_at = datetime.now(UTC).isoformat()
    item = {"id": item_id, "name": payload.name, "created_at": created_at}
    _ITEMS[item_id] = item
    return item


@router.get("/items", response_model=ItemListResponse)
async def list_items(_verified: VerifiedTokenDep) -> ItemListResponse:
    return {"items": list(_ITEMS.values())}


@router.get("/items/{entity_id}", response_model=ItemResponse)
async def get_item(entity_id: str, _verified: VerifiedTokenDep) -> ItemResponse:
    item = _ITEMS.get(entity_id)
    if item is None:
        raise HTTPException(status_code=404, detail="item not found")
    return item


@router.put("/items/{entity_id}", response_model=ItemUpdateResponse)
async def update_item(
    entity_id: str, payload: UpdateItemRequest, _verified: VerifiedTokenDep
) -> ItemUpdateResponse:
    item = _ITEMS.get(entity_id)
    if item is None:
        raise HTTPException(status_code=404, detail="item not found")
    item["name"] = payload.name
    return {"id": entity_id, "name": payload.name, "updated": True}


@router.put("/items/{entity_id}/upsert", response_model=ItemUpsertResponse)
async def upsert_item(
    entity_id: str, payload: UpdateItemRequest, _verified: VerifiedTokenDep
) -> ItemUpsertResponse:
    existing = _ITEMS.get(entity_id)
    if existing is None:
        created_at = datetime.now(UTC).isoformat()
        _ITEMS[entity_id] = {"id": entity_id, "name": payload.name, "created_at": created_at}
    else:
        existing["name"] = payload.name
    return {"id": entity_id, "name": payload.name, "rows_affected": 1}


@router.delete("/items/{entity_id}", response_model=ItemDeleteResponse)
async def delete_item(entity_id: str, _verified: VerifiedTokenDep) -> ItemDeleteResponse:
    rows = 1 if _ITEMS.pop(entity_id, None) is not None else 0
    if rows == 0:
        raise HTTPException(status_code=404, detail="item not found")
    return {"id": entity_id, "deleted": True}
