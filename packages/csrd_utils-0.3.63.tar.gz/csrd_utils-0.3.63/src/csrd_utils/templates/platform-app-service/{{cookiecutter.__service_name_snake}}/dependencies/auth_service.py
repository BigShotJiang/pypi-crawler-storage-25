from typing import Annotated

import httpx
from fastapi import HTTPException, Security
from fastapi.requests import Request

from csrd.auth import CallbackAuthenticator, create_bearer_dependency
from csrd.models.claims import UserClaims
from csrd.versioning import find_token

from ..settings import settings


def _map_claims(payload: dict[str, object]) -> UserClaims:
    claims = payload.get("claims") if isinstance(payload.get("claims"), dict) else payload
    if not isinstance(claims, dict):
        raise HTTPException(status_code=502, detail="invalid auth response")

    authorities = claims.get("authorities") or claims.get("roles") or []
    if isinstance(authorities, str):
        authorities = authorities.split()

    sub = str(claims.get("sub", ""))
    user_name = str(claims.get("user_name") or sub)

    return UserClaims(sub=sub, user_name=user_name, authorities=list(authorities))


async def _remote_verify(_: Request, token: str) -> UserClaims:
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            response = await client.post(
                f"{settings.auth_service_url}/api/verify",
                json={"token": token},
            )
    except httpx.ConnectError as exc:
        raise HTTPException(status_code=503, detail="auth service unavailable") from exc

    if response.status_code != 200:
        raise HTTPException(status_code=401, detail="invalid token")

    payload = response.json()
    if not isinstance(payload, dict):
        raise HTTPException(status_code=502, detail="invalid auth response")
    return _map_claims(payload)


_authenticator = CallbackAuthenticator(callback=_remote_verify)

VerifiedTokenDep = Annotated[
    UserClaims,
    Security(create_bearer_dependency(_authenticator, token_finder=find_token)),
]

__all__ = ("VerifiedTokenDep",)
