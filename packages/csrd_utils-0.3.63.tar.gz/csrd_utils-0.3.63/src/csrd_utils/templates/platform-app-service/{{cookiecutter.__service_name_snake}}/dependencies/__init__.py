from .auth_service import VerifiedTokenDep

__all__ = ("VerifiedTokenDep",)
