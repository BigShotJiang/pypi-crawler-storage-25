"""Bundled prompt templates."""
