"""Bundled LangDeep resources."""
