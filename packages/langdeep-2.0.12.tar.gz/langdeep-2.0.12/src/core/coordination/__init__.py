"""
Process coordination components.
"""