"""
Knowledge Graph Retriever with Personalized PageRank

Hard-coded config:
- normalization: "global"
- turn_segment_agg: "avg"
- entity_segment_agg: "max"
- entity_reset_agg: "max"
- use_synonyms: False
"""

import os
import json
import pickle
from glob import glob
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple
from collections import defaultdict

import numpy as np
import pandas as pd
import networkx as nx
from scipy.special import softmax


class KGRetriever:
    """
    Knowledge Graph Retriever using embedding similarity + Personalized PageRank
    
    Hard-coded settings (not configurable):
    - normalization = "global"
    - turn_segment_agg = "avg"
    - entity_segment_agg = "max"
    - entity_reset_agg = "max"
    - use_synonyms = False
    """

    # === HARD-CODED CONFIG ===
    NORMALIZATION = "global"
    TURN_SEGMENT_AGG = "avg"
    ENTITY_SEGMENT_AGG = "max"
    ENTITY_RESET_AGG = "max"
    USE_SYNONYMS = False

    def __init__(
        self,
        data_path: str,
        embedding_model: str = "facebook/contriever",
        embedding_model_instance = None,
        num_hops: int = 1,
        top_k_node: int = 10,
        top_k_triplet: int = 10,
        top_k_return: int = 10,
        ppr_alpha: float = 0.15,
        use_turn_embeddings: bool = True,
        verbose: bool = False,
    ):
        """
        Initialize KG Retriever

        Args:
            data_path: Path to graph_db directory containing embeddings and graph
            embedding_model: Sentence transformer model name
            embedding_model_instance: Pre-loaded SentenceTransformer (optional)
            num_hops: Number of hops for subgraph expansion
            top_k_node: Top-k nodes from similarity search
            top_k_triplet: Top-k triplets from similarity search
            top_k_return: Top-k nodes to return after PPR
            ppr_alpha: PPR damping factor (restart probability)
            use_turn_embeddings: Whether to use turn embeddings
            verbose: Print progress
        """
        self.data_path = data_path
        self.num_hops = num_hops
        self.top_k_node = top_k_node
        self.top_k_triplet = top_k_triplet
        self.top_k_return = top_k_return
        self.ppr_alpha = ppr_alpha
        self.use_turn_embeddings = use_turn_embeddings
        self.verbose = verbose

        if self.verbose:
            print(f"Initializing KGRetriever...")
            print(f"  Data path: {data_path}")
            print(f"  Embedding model: {embedding_model}")
            print(f"  Config: normalization={self.NORMALIZATION}, "
                  f"turn_seg_agg={self.TURN_SEGMENT_AGG}, "
                  f"entity_seg_agg={self.ENTITY_SEGMENT_AGG}")

        # Load components
        self._load_embeddings()
        self._load_graph()
        
        if embedding_model_instance:
            self.embedding_model = embedding_model_instance
        else:
            from memorai.core.config import settings
            from memorai.core.embedding_backend import create_embedding_model

            if settings.embedding_provider == "cloudflare":
                self.embedding_model = create_embedding_model()
            else:
                self._load_embedding_model(embedding_model)
            
        self._load_mappings()

        if self.verbose:
            print("✓ KGRetriever initialized!")

    def _find_file(self, pattern: str, required: bool = True) -> Optional[str]:
        """Find file matching pattern in data_path"""
        matches = glob(os.path.join(self.data_path, pattern))
        if not matches:
            if required:
                raise FileNotFoundError(
                    f"No file matching '{pattern}' found in {self.data_path}"
                )
            return None
        return matches[0]

    def _find_mapping_json(self, basename: str, glob_prefixed: str) -> Optional[str]:
        """
        Mapping exports use either ``{qid}_turn_id_to_content.json`` or plain
        ``turn_id_to_content.json`` (no prefix). Glob ``*_...`` misses the latter.
        """
        path = self._find_file(glob_prefixed, required=False)
        if path:
            return path
        direct = os.path.join(self.data_path, basename)
        return direct if os.path.isfile(direct) else None

    def _load_embeddings(self):
        """Load all embedding parquet files"""
        if self.verbose:
            print("Loading embeddings...")

        # Summary embeddings (for segment nodes)
        summary_file = self._find_file("*_summaries_embedded.parquet")
        self.summary_df = pd.read_parquet(summary_file)
        self.summary_matrix = np.vstack(self.summary_df["embedding"].values)

        # Entity description embeddings
        entity_file = self._find_file("*_descriptions_embedded.parquet")
        self.entity_df = pd.read_parquet(entity_file)
        self.entity_matrix = np.vstack(self.entity_df["embedding"].values)
        self.entity_df["entity_lower"] = self.entity_df["entity"].str.lower()

        # Triplet embeddings
        triplet_file = self._find_file("*_triplets_embedded.parquet")
        self.triplet_df = pd.read_parquet(triplet_file)
        self.triplet_matrix = np.vstack(self.triplet_df["embedding"].values)
        self.triplet_df["entity1_lower"] = self.triplet_df["entity1"].str.lower()
        self.triplet_df["entity2_lower"] = self.triplet_df["entity2"].str.lower()

        # Turn embeddings (optional)
        turn_file = self._find_file("*_turns_embedded.parquet", required=False)
        if turn_file and self.use_turn_embeddings:
            self.turn_df = pd.read_parquet(turn_file)
            self.turn_matrix = np.vstack(self.turn_df["embedding"].values)
            self.has_turn_embeddings = True
        else:
            self.turn_df = None
            self.turn_matrix = None
            self.has_turn_embeddings = False

        if self.verbose:
            print(f"  Summaries: {len(self.summary_df)}")
            print(f"  Entities: {len(self.entity_df)}")
            print(f"  Triplets: {len(self.triplet_df)}")
            print(f"  Turns: {len(self.turn_df) if self.has_turn_embeddings else 'N/A'}")

    def _load_graph(self):
        """Load knowledge graph"""
        if self.verbose:
            print("Loading knowledge graph...")

        pkl_file = self._find_file("*.pkl", required=False)
        graphml_file = self._find_file("*_knowledge_graph.graphml", required=False)

        if pkl_file:
            with open(pkl_file, "rb") as f:
                self.graph = pickle.load(f)
        elif graphml_file:
            self.graph = nx.read_graphml(graphml_file)
        else:
            raise FileNotFoundError(
                f"No graph file found in {self.data_path} (*.pkl or *.graphml)"
            )

        # Normalize to lowercase
        self.graph = self._normalize_graph_to_lowercase(self.graph)

        self.original_graph_nodes = self.graph.number_of_nodes()
        self.original_graph_edges = self.graph.number_of_edges()

        if self.verbose:
            print(f"  Nodes: {self.original_graph_nodes}")
            print(f"  Edges: {self.original_graph_edges}")

    def _normalize_graph_to_lowercase(self, graph: nx.Graph) -> nx.Graph:
        """Normalize all node IDs to lowercase"""
        node_mapping = {
            node: node.lower() if isinstance(node, str) else node
            for node in graph.nodes()
        }
        new_graph = nx.relabel_nodes(graph, node_mapping)

        # Lowercase edge attributes
        for u, v, data in new_graph.edges(data=True):
            for key in ["relation", "edge_type", "label"]:
                if key in data and isinstance(data[key], str):
                    data[key] = data[key].lower()

        # Lowercase node attributes
        for node, data in new_graph.nodes(data=True):
            for key in ["entity", "name", "label"]:
                if key in data and isinstance(data[key], str):
                    data[key] = data[key].lower()

        return new_graph

    def _load_embedding_model(self, model_name: str):
        """Load sentence transformer model"""
        if self.verbose:
            print(f"Loading embedding model: {model_name}...")

        try:
            from ..core.hf_load import quiet_hf_hub_messages
            from sentence_transformers import SentenceTransformer

            quiet_hf_hub_messages()
            self.embedding_model = SentenceTransformer(model_name)
        except ImportError:
            raise ImportError(
                "sentence-transformers not installed. "
                "Install with: pip install sentence-transformers"
            )

    def _load_mappings(self):
        """Load turn_to_segment and segment_to_chunk mappings"""
        turn_to_seg_path = os.path.join(self.data_path, "turn_to_segment.json")
        if os.path.exists(turn_to_seg_path):
            with open(turn_to_seg_path, "r") as f:
                self.turn_to_segment = json.load(f)
        else:
            self.turn_to_segment = {}

        seg_to_chunk_path = os.path.join(self.data_path, "segment_to_chunk.json")
        if os.path.exists(seg_to_chunk_path):
            with open(seg_to_chunk_path, "r") as f:
                self.segment_to_chunk = json.load(f)
        else:
            self.segment_to_chunk = {}

        # Load content mappings (with or without qid filename prefix)
        turn_content_path = self._find_mapping_json(
            "turn_id_to_content.json", "*_turn_id_to_content.json"
        )
        if turn_content_path:
            with open(turn_content_path, "r") as f:
                self.turn_id_to_content = json.load(f)
        else:
            self.turn_id_to_content = {}

        seg_content_path = self._find_mapping_json(
            "segment_id_to_content.json", "*_segment_id_to_content.json"
        )
        if seg_content_path:
            with open(seg_content_path, "r") as f:
                self.segment_id_to_content = json.load(f)
        else:
            self.segment_id_to_content = {}

    def embed_query(self, query: str) -> np.ndarray:
        """Embed query text"""
        return self.embedding_model.encode(query, convert_to_numpy=True)

    def cosine_similarity_batch(
        self, query_emb: np.ndarray, matrix: np.ndarray
    ) -> np.ndarray:
        """Compute cosine similarity between query and all vectors"""
        query_norm = query_emb / (np.linalg.norm(query_emb) + 1e-9)
        matrix_norm = matrix / (np.linalg.norm(matrix, axis=1, keepdims=True) + 1e-9)
        return np.dot(matrix_norm, query_norm)

    def search_nodes(self, query_emb: np.ndarray) -> Dict:
        """Search for top-k relevant nodes (segments + entities)"""
        node_scores = {}
        turn_scores = {}
        entity_turn_scores = defaultdict(list)
        entity_segment_scores = defaultdict(list)
        turn_segment_scores = defaultdict(list)

        # Score segments
        summary_scores = self.cosine_similarity_batch(query_emb, self.summary_matrix)
        for idx, score in enumerate(summary_scores):
            seg_id = self.summary_df.iloc[idx]["segment_id"]
            node_scores[seg_id] = float(score)

        # Score entities
        entity_scores = self.cosine_similarity_batch(query_emb, self.entity_matrix)
        entity_score_groups = defaultdict(list)

        for idx, score in enumerate(entity_scores):
            row = self.entity_df.iloc[idx]
            entity_lower = row["entity_lower"]
            turn_id = row["turn_id"]
            segment_id = row["segment_id"]
            score_val = float(score)

            entity_score_groups[entity_lower].append(score_val)
            entity_turn_scores[(entity_lower, turn_id)].append(score_val)
            entity_segment_scores[(entity_lower, segment_id)].append(score_val)
            turn_segment_scores[(turn_id, segment_id)].append(score_val)

        # Aggregate entity scores (max)
        for entity_lower, scores in entity_score_groups.items():
            node_scores[entity_lower] = max(scores)

        # Score turns
        if self.has_turn_embeddings:
            turn_node_scores = self.cosine_similarity_batch(query_emb, self.turn_matrix)
            for idx, score in enumerate(turn_node_scores):
                turn_id = self.turn_df.iloc[idx]["turn_id"]
                turn_scores[turn_id] = float(score)

        # Get top-k
        sorted_nodes = sorted(node_scores.items(), key=lambda x: x[1], reverse=True)
        top_node_scores = dict(sorted_nodes[: self.top_k_node])

        return {
            "node_scores": top_node_scores,
            "all_node_scores": node_scores,
            "turn_scores": turn_scores,
            "entity_turn_scores": dict(entity_turn_scores),
            "entity_segment_scores": dict(entity_segment_scores),
            "turn_segment_scores": dict(turn_segment_scores),
        }

    def search_triplets(self, query_emb: np.ndarray) -> Dict:
        """Search for top-k relevant triplets"""
        triplet_scores = self.cosine_similarity_batch(query_emb, self.triplet_matrix)

        entity_entity_scores = defaultdict(list)
        entity_turn_scores = defaultdict(list)
        entity_segment_scores = defaultdict(list)
        turn_segment_scores = defaultdict(list)

        for idx in range(len(self.triplet_df)):
            row = self.triplet_df.iloc[idx]
            score_val = float(triplet_scores[idx])

            e1 = row["entity1_lower"]
            e2 = row["entity2_lower"]
            turn_id = row["turn_id"]
            segment_id = row["segment_id"]

            entity_entity_scores[(e1, e2)].append(score_val)
            entity_entity_scores[(e2, e1)].append(score_val)
            entity_turn_scores[(e1, turn_id)].append(score_val)
            entity_turn_scores[(e2, turn_id)].append(score_val)
            entity_segment_scores[(e1, segment_id)].append(score_val)
            entity_segment_scores[(e2, segment_id)].append(score_val)
            turn_segment_scores[(turn_id, segment_id)].append(score_val)

        # Get top-k triplets
        top_indices = np.argsort(triplet_scores)[::-1][: self.top_k_triplet]
        top_triplets = []
        for idx in top_indices:
            row = self.triplet_df.iloc[idx]
            triplet = row.to_dict()
            triplet["score"] = float(triplet_scores[idx])
            top_triplets.append(triplet)

        return {
            "top_triplets": top_triplets,
            "entity_entity_scores": dict(entity_entity_scores),
            "entity_turn_scores": dict(entity_turn_scores),
            "entity_segment_scores": dict(entity_segment_scores),
            "turn_segment_scores": dict(turn_segment_scores),
        }

    def build_initial_nodes(
        self, top_nodes: Dict[str, float], top_triplets: List[Dict]
    ) -> Set[str]:
        """Build initial node set from top nodes and triplet entities"""
        initial_nodes = set(top_nodes.keys())
        for triplet in top_triplets:
            initial_nodes.add(triplet["entity1_lower"])
            initial_nodes.add(triplet["entity2_lower"])
        return initial_nodes

    def expand_subgraph(self, initial_nodes: Set[str]) -> nx.Graph:
        """Expand to n-hop neighbors"""
        expanded_nodes = set(initial_nodes)
        current_layer = set(initial_nodes)

        for _ in range(self.num_hops):
            next_layer = set()
            for node in current_layer:
                if node in self.graph:
                    next_layer.update(self.graph.neighbors(node))

            new_neighbors = next_layer - expanded_nodes
            if not new_neighbors:
                break

            expanded_nodes.update(new_neighbors)
            current_layer = new_neighbors

        return self.graph.subgraph(expanded_nodes).copy()

    def compute_edge_weights(
        self,
        subgraph: nx.Graph,
        node_search_results: Dict,
        triplet_search_results: Dict,
    ) -> Dict[Tuple[str, str], float]:
        """Compute edge weights using HARD-CODED aggregation methods"""
        edge_weights = {}

        # Entity-Entity edges (from triplets)
        entity_entity_scores = triplet_search_results["entity_entity_scores"]
        for (e1, e2), scores in entity_entity_scores.items():
            edge_weights[(e1, e2)] = max(scores)
            edge_weights[(e2, e1)] = max(scores)

        # Entity-Segment edges (ENTITY_SEGMENT_AGG = "max")
        entity_segment_scores = defaultdict(list)
        for (entity, seg), scores in node_search_results["entity_segment_scores"].items():
            entity_segment_scores[(entity, seg)].extend(scores)
            entity_segment_scores[(seg, entity)].extend(scores)
        for (entity, seg), scores in triplet_search_results["entity_segment_scores"].items():
            entity_segment_scores[(entity, seg)].extend(scores)
            entity_segment_scores[(seg, entity)].extend(scores)

        for edge, scores in entity_segment_scores.items():
            edge_weights[edge] = max(scores)  # HARD-CODED: max

        # Turn-Segment edges (TURN_SEGMENT_AGG = "avg")
        turn_segment_scores = defaultdict(list)
        for (turn, seg), scores in node_search_results["turn_segment_scores"].items():
            turn_segment_scores[(turn, seg)].extend(scores)
            turn_segment_scores[(seg, turn)].extend(scores)
        for (turn, seg), scores in triplet_search_results["turn_segment_scores"].items():
            turn_segment_scores[(turn, seg)].extend(scores)
            turn_segment_scores[(seg, turn)].extend(scores)

        for edge, scores in turn_segment_scores.items():
            edge_weights[edge] = np.mean(scores)  # HARD-CODED: avg

        # Entity-Turn edges
        entity_turn_scores = defaultdict(list)
        for (entity, turn), scores in node_search_results["entity_turn_scores"].items():
            entity_turn_scores[(entity, turn)].extend(scores)
            entity_turn_scores[(turn, entity)].extend(scores)
        for (entity, turn), scores in triplet_search_results["entity_turn_scores"].items():
            entity_turn_scores[(entity, turn)].extend(scores)
            entity_turn_scores[(turn, entity)].extend(scores)

        for edge, scores in entity_turn_scores.items():
            edge_weights[edge] = np.mean(scores)

        # Filter to edges in subgraph
        filtered_weights = {}
        for edge in subgraph.edges():
            if edge in edge_weights:
                filtered_weights[edge] = edge_weights[edge]
            elif (edge[1], edge[0]) in edge_weights:
                filtered_weights[edge] = edge_weights[(edge[1], edge[0])]
            else:
                filtered_weights[edge] = 0.1

        return filtered_weights

    def normalize_weights(
        self,
        subgraph: nx.Graph,
        edge_weights: Dict[Tuple[str, str], float],
    ) -> Dict[Tuple[str, str], float]:
        """Normalize edge weights using HARD-CODED 'global' softmax"""
        edges = list(edge_weights.keys())
        weights = np.array(list(edge_weights.values()))
        normalized = softmax(weights)

        return {edge: float(norm_w) for edge, norm_w in zip(edges, normalized)}

    def build_reset_vector(
        self,
        subgraph: nx.Graph,
        node_scores: Dict[str, float],
        turn_scores: Dict[str, float],
        triplet_search_results: Dict,
    ) -> Dict[str, float]:
        """Build reset vector using HARD-CODED 'max' aggregation for entities"""
        reset_vector = {}

        # Build entity scores lookup
        entity_scores_lookup = defaultdict(list)
        for entity, score in node_scores.items():
            if not entity.startswith("seg-"):
                entity_scores_lookup[entity].append(score)

        for triplet in triplet_search_results["top_triplets"]:
            e1 = triplet["entity1_lower"]
            e2 = triplet["entity2_lower"]
            score = triplet["score"]
            entity_scores_lookup[e1].append(score)
            entity_scores_lookup[e2].append(score)

        # Assign scores to nodes
        for node in subgraph.nodes():
            node_data = subgraph.nodes[node]
            node_type = node_data.get("node_type", "unknown")

            if node_type == "segment" or node.startswith("seg-"):
                reset_vector[node] = node_scores.get(node, 0.0)
            elif node_type == "entity" or node in entity_scores_lookup:
                scores = entity_scores_lookup.get(node, [])
                if scores:
                    reset_vector[node] = max(scores)  # HARD-CODED: max
                else:
                    reset_vector[node] = 0.0
            elif node_type == "turn" or node.startswith("turn-"):
                reset_vector[node] = turn_scores.get(node, 0.0)
            else:
                reset_vector[node] = 0.0

        # Normalize
        total = sum(reset_vector.values())
        if total > 0:
            reset_vector = {k: v / total for k, v in reset_vector.items()}
        else:
            n = len(reset_vector)
            reset_vector = {k: 1.0 / n for k in reset_vector.keys()}

        return reset_vector

    def run_ppr(
        self,
        subgraph: nx.Graph,
        reset_vector: Dict[str, float],
        edge_weights: Dict[Tuple[str, str], float],
    ) -> Dict[str, float]:
        """Run Personalized PageRank"""
        for edge, weight in edge_weights.items():
            if subgraph.has_edge(*edge):
                subgraph[edge[0]][edge[1]]["weight"] = weight

        try:
            ppr_scores = nx.pagerank(
                subgraph,
                alpha=self.ppr_alpha,
                personalization=reset_vector,
                weight="weight",
                max_iter=100,
            )
        except Exception as e:
            if self.verbose:
                print(f"Warning: PPR failed ({e}), using uniform scores")
            ppr_scores = {node: 1.0 / subgraph.number_of_nodes() for node in subgraph.nodes()}

        return ppr_scores

    def filter_and_return(
        self,
        subgraph: nx.Graph,
        ppr_scores: Dict[str, float],
        return_types: List[str] = None,
    ) -> Dict[str, List[Tuple[str, float]]]:
        """Filter PPR results by node type"""
        if return_types is None:
            return_types = ["segment", "turn", "entity"]

        results = {"segment": [], "turn": [], "entity": []}

        for node, score in ppr_scores.items():
            node_data = subgraph.nodes[node]
            node_type = node_data.get("node_type", "unknown")

            if node_type == "unknown":
                if node.startswith("seg-"):
                    node_type = "segment"
                elif node.startswith("turn-"):
                    node_type = "turn"
                else:
                    node_type = "entity"

            if node_type in return_types:
                results[node_type].append((node, score))

        # Sort and limit
        for node_type in results:
            results[node_type].sort(key=lambda x: x[1], reverse=True)
            results[node_type] = results[node_type][: self.top_k_return]

        return results

    def retrieve(
        self,
        query: str,
        return_types: List[str] = None,
    ) -> Dict:
        """
        Main retrieval method

        Args:
            query: Query string
            return_types: Node types to return (default: ["segment", "turn", "entity"])

        Returns:
            Dict with keys:
            - results: {"segment": [...], "turn": [...], "entity": [...]}
            - subgraph_info: Stats about the subgraph
            - triplets: Top triplets found
        """
        if return_types is None:
            return_types = ["segment", "turn", "entity"]

        if self.verbose:
            print(f"\nQuery: {query}")

        # 1. Embed query
        query_emb = self.embed_query(query)

        # 2. Search nodes
        node_results = self.search_nodes(query_emb)
        top_nodes = node_results["node_scores"]

        # 3. Search triplets
        triplet_results = self.search_triplets(query_emb)
        top_triplets = triplet_results["top_triplets"]

        # 4. Build initial nodes
        initial_nodes = self.build_initial_nodes(top_nodes, top_triplets)

        # 5. Expand subgraph
        subgraph = self.expand_subgraph(initial_nodes)

        # 6. Compute edge weights
        edge_weights = self.compute_edge_weights(subgraph, node_results, triplet_results)

        # 7. Normalize weights (global softmax)
        normalized_weights = self.normalize_weights(subgraph, edge_weights)

        # 8. Build reset vector
        turn_scores = node_results.get("turn_scores", {})
        reset_vector = self.build_reset_vector(
            subgraph, top_nodes, turn_scores, triplet_results
        )

        # 9. Run PPR
        ppr_scores = self.run_ppr(subgraph, reset_vector, normalized_weights)

        # 10. Filter and return
        results = self.filter_and_return(subgraph, ppr_scores, return_types)

        subgraph_info = {
            "num_nodes": subgraph.number_of_nodes(),
            "num_edges": subgraph.number_of_edges(),
            "original_nodes": self.original_graph_nodes,
            "original_edges": self.original_graph_edges,
        }

        if self.verbose:
            print(f"✓ Retrieved: {sum(len(v) for v in results.values())} nodes")
            for t, nodes in results.items():
                if nodes:
                    print(f"  {t}: {len(nodes)}")

        return {
            "results": results,
            "subgraph_info": subgraph_info,
            "triplets": top_triplets,
        }

    def get_triplets_for_turns(self, turn_ids: List[str]) -> List[Dict]:
        """Get all triplets associated with given turn IDs"""
        turn_set = set(turn_ids)
        triplets = []

        for _, row in self.triplet_df.iterrows():
            if row["turn_id"] in turn_set:
                triplets.append(row.to_dict())

        return triplets

    def get_turn_content(self, turn_id: str) -> Optional[Dict]:
        """
        Text for a turn. Filtered pipeline only keeps **user** lines in turn parquet /
        ``turn_id_to_content.json``; when triplets link the turn to a segment, we prefer
        ``segment_id_to_content`` so **assistant** replies appear (full exchange).
        """
        content_user_only = ""
        speaker = ""
        timestamp = ""

        if self.turn_df is not None:
            matches = self.turn_df[self.turn_df["turn_id"] == turn_id]
            if not matches.empty:
                row = matches.iloc[0]
                content_user_only = (
                    row["content"] if "content" in row.index else ""
                ) or (row["text"] if "text" in row.index else "")
                speaker = row["speaker"] if "speaker" in row.index else ""
                timestamp = row["timestamp"] if "timestamp" in row.index else ""

        segment_texts: List[str] = []
        if (
            self.triplet_df is not None
            and "segment_id" in self.triplet_df.columns
            and self.segment_id_to_content
        ):
            sub = self.triplet_df[self.triplet_df["turn_id"] == turn_id]
            seen: Set[str] = set()
            for _, row in sub.iterrows():
                sid = row.get("segment_id")
                if sid and sid not in seen:
                    seen.add(sid)
                    blob = self.segment_id_to_content.get(sid)
                    if blob:
                        segment_texts.append(blob)

        if segment_texts:
            display = "\n\n---\n\n".join(segment_texts)
        else:
            display = content_user_only

        if not display:
            return None

        return {
            "turn_id": turn_id,
            "content": display,
            "speaker": speaker,
            "timestamp": timestamp,
            "content_user_only": content_user_only or None,
        }

