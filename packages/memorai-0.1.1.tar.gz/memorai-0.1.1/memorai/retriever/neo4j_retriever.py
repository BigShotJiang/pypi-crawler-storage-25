"""
Pure Neo4j Knowledge Graph Retriever
Replaces the traditional NetworkX PPR approach with native Neo4j Graph queries.
"""
import logging
from typing import Dict, List, Any, Optional
from ..core.neo4j_client import neo4j_client
from ..core import normalize_scope_id


logger = logging.getLogger(__name__)

class Neo4jRetriever:
    """
    Retrieves information using Neo4j Vector Indexes and Graph Traversal.
    """
    
    def __init__(self, embedding_generator=None, top_k=5):
        self.client = neo4j_client
        self.top_k = top_k
        self.embedder = embedding_generator
            
        if not self.embedder:
            from ..core.embeddings import EmbeddingGenerator
            self.embedder = EmbeddingGenerator()

    def retrieve(
        self,
        query: str,
        conversation_id: Optional[str] = None,
        session_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Main retrieve method:
        1. Embed the query.
        2. Hit vector index for Entities and Segments.
        3. Traverse subgraph to get enriched context.
        """
        if not self.client.driver:
            logger.warning("Neo4j client not connected. Cannot retrieve.")
            return {"entities": [], "segments": [], "context": ""}
            
        query_emb = self.embedder.embed(query)
        if hasattr(query_emb, "tolist"):
            query_emb = query_emb.tolist()
            
        scope_id = normalize_scope_id(conversation_id or session_id)

        entities = self._search_entities(query_emb, scope_id)
        segments = self._search_segments(query_emb, scope_id)
        
        # Traverse up to get relations
        context = self._build_context(entities, segments, scope_id)
        
        return {
            "entities": entities,
            "segments": segments,
            "context": context
        }
        
    def _search_entities(self, query_emb: List[float], scope_id: str) -> List[Dict]:
        query = """
        CALL db.index.vector.queryNodes('entity_emb', $top_k * 10, $emb)
        YIELD node, score
        WHERE node.session_id = $scope_id
        RETURN node.name AS entity, node.description AS description, score
        LIMIT $top_k
        """
        results = []
        with self.client.driver.session() as session:
            try:
                res = session.run(query, top_k=self.top_k, emb=query_emb, scope_id=scope_id)
                for record in res:
                    results.append(record.data())
            except Exception as e:
                logger.warning(
                    "Entity search failed (did you run the pipeline to create indexes yet?): %s",
                    e,
                )
        return results

    def _search_segments(self, query_emb: List[float], scope_id: str) -> List[Dict]:
        query = """
        CALL db.index.vector.queryNodes('segment_emb', $top_k * 10, $emb)
        YIELD node, score
        WHERE node.session_id = $scope_id
        RETURN node.id AS id, node.summary AS summary, score
        LIMIT $top_k
        """
        results = []
        with self.client.driver.session() as session:
            try:
                res = session.run(query, top_k=self.top_k, emb=query_emb, scope_id=scope_id)
                for record in res:
                    results.append(record.data())
            except Exception as e:
                logger.warning("Segment search failed: %s", e)
        return results

    def _build_context(self, entities: List[Dict], segments: List[Dict], scope_id: str) -> str:
        """Fetch graph context from Neo4j (relations + node summaries)."""
        if not entities and not segments:
            return ""

        context_parts = []

        ent_names = [e["entity"] for e in entities if e.get("entity")]
        if ent_names:
            q = """
            MATCH (e1:Entity)-[r:RELATION]->(e2:Entity)
            WHERE (e1.name IN $names OR e2.name IN $names)
              AND e1.session_id = $scope_id
              AND e2.session_id = $scope_id
            RETURN e1.name AS e1, type(r) AS rel, e2.name AS e2
            LIMIT 20
            """
            with self.client.driver.session() as session:
                res = session.run(q, names=ent_names, scope_id=scope_id)
                for record in res:
                    context_parts.append(f"{record['e1']} --[{record['rel']}]--> {record['e2']}")

        for e in entities:
            entity = e.get("entity")
            description = e.get("description")
            if entity and description:
                context_parts.append(f"Entity Info: {entity} - {description}")

        for s in segments:
            summary = s.get("summary")
            if summary:
                context_parts.append(f"Conversation Context: {summary}")

        return "\n".join(context_parts)
