"""
Mapping Exporter - Export ID to content mappings
"""

import os
import hashlib
from typing import Dict, List, Any
from tqdm import tqdm

from ..core import load_json, save_json, ensure_dir, path_exists
from ..core.storage import storage


class MappingExporter:
    """
    Export ID → Content mappings for lookup
    
    Creates:
    - segment_id_to_content.json
    - turn_id_to_content.json
    - chunk_id_to_content.json
    - summary_id_to_content.json
    """

    def export_segment_mappings(self, qid: str, qid_dir: str, output_path: str) -> int:
        """Export segment_hash_id → content mapping"""
        segment_map = {}

        # qid_dir is used locally, but in Neo4j we use qid to find the managed file
        file_path = os.path.join(qid_dir, f"{qid}.json")

        try:
            if not path_exists(file_path):
                return 0
            data = load_json(file_path)
            for chunk in data.get("chunks", []):
                timestamp = chunk.get("timestamp", "")

                for segment in chunk.get("segments", []):
                    segment_id = segment["segment_hash_id"]
                    messages = segment.get("messages", [])

                    content_lines = []
                    if timestamp:
                        content_lines.append(timestamp)
                    for msg in messages:
                        content_lines.append(msg["message_content"])

                    segment_map[segment_id] = "\n".join(content_lines)

        except Exception as e:
            print(f"Error processing {file_path}: {e}")

        save_json(output_path, segment_map)
        return len(segment_map)

    def export_turn_mappings(self, qid: str, qid_dir: str, output_path: str) -> int:
        """Export turn_id → full turn content mapping"""
        turn_map = {}

        file_path = os.path.join(qid_dir, f"{qid}_filtered.json")
        try:
            if not path_exists(file_path):
                return 0
            data = load_json(file_path)
            for chunk in data.get("chunks", []):
                timestamp = chunk.get("timestamp", "")

                for segment in chunk.get("segments", []):
                    messages = segment.get("filtered_messages", [])

                    # Sort by message_index_in_segment
                    messages_sorted = sorted(
                        messages,
                        key=lambda x: x["message_index_in_segment"]
                    )

                    # Group into turns
                    turns = {}
                    for msg in messages_sorted:
                        msg_idx = msg["message_index_in_segment"]
                        turn_idx = msg_idx // 2
                        if turn_idx not in turns:
                            turns[turn_idx] = []
                        turns[turn_idx].append(msg)

                    # Build full turn content
                    for turn_idx, turn_messages in turns.items():
                        full_turn_lines = [msg["content"] for msg in turn_messages]
                        full_turn_content = "\n".join(full_turn_lines)

                        for msg in turn_messages:
                            turn_content = msg["content"]
                            turn_hash_input = f"{timestamp}_{turn_content}"
                            hash_obj = hashlib.md5(turn_hash_input.encode())
                            turn_id = f"turn-{hash_obj.hexdigest()}"

                            if timestamp:
                                turn_map[turn_id] = f"{timestamp}\n{full_turn_content}"
                            else:
                                turn_map[turn_id] = full_turn_content

        except Exception as e:
            print(f"Error processing {file_path}: {e}")

        save_json(output_path, turn_map)
        return len(turn_map)

    def export_chunk_mappings(self, qid: str, qid_dir: str, output_path: str) -> int:
        """Export chunk_hash_id → content mapping"""
        chunk_map = {}

        file_path = os.path.join(qid_dir, f"{qid}.json")
        try:
            if not path_exists(file_path):
                return 0
            data = load_json(file_path)
            for chunk in data.get("chunks", []):
                chunk_id = chunk.get("chunk_hash_id")
                if not chunk_id:
                    continue

                timestamp = chunk.get("timestamp", "")
                segments = chunk.get("segments", [])

                content_lines = []
                if timestamp:
                    content_lines.append(f"Timestamp: {timestamp}")

                for seg in segments:
                    for msg in seg.get("messages", []):
                        content_lines.append(msg["message_content"])

                chunk_map[chunk_id] = "\n".join(content_lines)

        except Exception as e:
            print(f"Error processing {file_path}: {e}")

        save_json(output_path, chunk_map)
        return len(chunk_map)

    def export_summary_mappings(self, qid: str, qid_dir: str, output_path: str) -> int:
        """Export segment_id → summary text mapping"""
        summary_map = {}

        file_path = os.path.join(qid_dir, f"{qid}_summaries.json")
        try:
            if not path_exists(file_path):
                return 0
            data = load_json(file_path)
            for chunk in data.get("chunks", []):
                for seg_summary in chunk.get("segment_summaries", []):
                    segment_id = seg_summary["segment_hash_id"]
                    summary_text = seg_summary["summary"]
                    summary_map[segment_id] = summary_text

        except Exception as e:
            print(f"Error processing {file_path}: {e}")

        save_json(output_path, summary_map)
        return len(summary_map)

    def run(
        self,
        segmented_dir: str = None,
        filtered_dir: str = None,
        summaries_dir: str = None,
        output_dir: str = None,
    ) -> Dict[str, int]:
        """
        Export all mappings
        """
        ensure_dir(output_dir)

        base_dir = segmented_dir or filtered_dir or summaries_dir
        if not base_dir:
            raise ValueError("At least one input directory must be provided")

        # Get all qids using storage abstraction
        input_files = storage.scan_input_files(base_dir)
        subdirs = [qid for qid, _ in input_files]

        print(f"Found {len(subdirs)} conversations")
        print("-" * 50)

        total_stats = {
            "segments": 0,
            "turns": 0,
            "chunks": 0,
            "summaries": 0,
        }

        for qid in tqdm(subdirs, desc="Exporting mappings"):
            qid_output_dir = ensure_dir(os.path.join(output_dir, qid))

            # Segment mappings
            if segmented_dir:
                qid_dir = os.path.join(segmented_dir, qid)
                count = self.export_segment_mappings(
                    qid,
                    qid_dir,
                    os.path.join(qid_output_dir, f"{qid}_segment_id_to_content.json"),
                )
                total_stats["segments"] += count

            # Chunk mappings
            if segmented_dir:
                qid_dir = os.path.join(segmented_dir, qid)
                count = self.export_chunk_mappings(
                    qid,
                    qid_dir,
                    os.path.join(qid_output_dir, f"{qid}_chunk_id_to_content.json"),
                )
                total_stats["chunks"] += count

            # Turn mappings
            if filtered_dir:
                qid_dir = os.path.join(filtered_dir, qid)
                count = self.export_turn_mappings(
                    qid,
                    qid_dir,
                    os.path.join(qid_output_dir, f"{qid}_turn_id_to_content.json"),
                )
                total_stats["turns"] += count

            # Summary mappings
            if summaries_dir:
                qid_dir = os.path.join(summaries_dir, qid)
                count = self.export_summary_mappings(
                    qid,
                    qid_dir,
                    os.path.join(qid_output_dir, f"{qid}_summary_id_to_content.json"),
                )
                total_stats["summaries"] += count

        print("-" * 50)
        print(f"Total exported:")
        print(f"  - Segments: {total_stats['segments']}")
        print(f"  - Turns: {total_stats['turns']}")
        print(f"  - Chunks: {total_stats['chunks']}")
        print(f"  - Summaries: {total_stats['summaries']}")

        return total_stats
