"""
Graph Builder - Build knowledge graph from triplets
"""

import os
import json
import glob
import pickle
from typing import Dict, Any, List, Optional

import networkx as nx
from tqdm import tqdm

from ..core import load_json, save_json, ensure_dir, storage, conversation_id_from_stage_path
from ..core.neo4j_client import neo4j_client
from .base import BaseProcessor


class GraphBuilder(BaseProcessor):
    """
    Build knowledge graph from triplets using NetworkX
    
    Graph structure:
    - Nodes: entities (node_type="entity"), turns (node_type="turn"), segments (node_type="segment")
    - Edges: entity-entity (with relation), entity-turn, entity-segment, turn-segment
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.graph = nx.Graph()
        self.stats = {
            "entity_nodes": 0,
            "turn_nodes": 0,
            "segment_nodes": 0,
            "entity_entity_edges": 0,
            "entity_turn_edges": 0,
            "entity_segment_edges": 0,
            "turn_segment_edges": 0,
        }

    def add_entity_node(self, entity: str) -> None:
        """Add entity node to graph"""
        if not self.graph.has_node(entity):
            self.graph.add_node(entity, node_type="entity")
            self.stats["entity_nodes"] += 1

    def add_turn_node(self, turn_id: str) -> None:
        """Add turn node to graph"""
        if not self.graph.has_node(turn_id):
            self.graph.add_node(turn_id, node_type="turn")
            self.stats["turn_nodes"] += 1

    def add_segment_node(self, segment_id: str) -> None:
        """Add segment node to graph"""
        if not self.graph.has_node(segment_id):
            self.graph.add_node(segment_id, node_type="segment")
            self.stats["segment_nodes"] += 1

    def add_entity_entity_edge(
        self,
        entity1: str,
        entity2: str,
        relation: str,
        triplet_id: str,
        turn_id: str,
        segment_id: str,
    ) -> None:
        """Add edge between two entities with relation info"""
        if self.graph.has_edge(entity1, entity2):
            edge_data = self.graph[entity1][entity2]
            if "relations" not in edge_data:
                edge_data["relations"] = []
            edge_data["relations"].append({
                "relation": relation,
                "triplet_id": triplet_id,
                "turn_id": turn_id,
                "segment_id": segment_id,
            })
        else:
            self.graph.add_edge(
                entity1,
                entity2,
                edge_type="entity_entity",
                relations=[{
                    "relation": relation,
                    "triplet_id": triplet_id,
                    "turn_id": turn_id,
                    "segment_id": segment_id,
                }],
            )
            self.stats["entity_entity_edges"] += 1

    def add_entity_turn_edge(self, entity: str, turn_id: str) -> None:
        """Add edge between entity and turn"""
        if not self.graph.has_edge(entity, turn_id):
            self.graph.add_edge(entity, turn_id, edge_type="entity_turn")
            self.stats["entity_turn_edges"] += 1

    def add_entity_segment_edge(self, entity: str, segment_id: str) -> None:
        """Add edge between entity and segment"""
        if not self.graph.has_edge(entity, segment_id):
            self.graph.add_edge(entity, segment_id, edge_type="entity_segment")
            self.stats["entity_segment_edges"] += 1

    def add_turn_segment_edge(self, turn_id: str, segment_id: str) -> None:
        """Add edge between turn and segment"""
        if not self.graph.has_edge(turn_id, segment_id):
            self.graph.add_edge(turn_id, segment_id, edge_type="turn_segment")
            self.stats["turn_segment_edges"] += 1

    def process_triplet(self, triplet: Dict[str, Any]) -> None:
        """Process a single triplet and add to graph"""
        entity1 = triplet["entity1"]
        entity2 = triplet["entity2"]
        relation = triplet["relation"]
        triplet_id = triplet["triplet_id"]
        turn_id = triplet["turn_id"]
        segment_id = triplet["segment_id"]

        # Add nodes
        self.add_entity_node(entity1)
        self.add_entity_node(entity2)
        self.add_turn_node(turn_id)
        self.add_segment_node(segment_id)

        # Add edges
        self.add_entity_entity_edge(entity1, entity2, relation, triplet_id, turn_id, segment_id)
        self.add_entity_turn_edge(entity1, turn_id)
        self.add_entity_turn_edge(entity2, turn_id)
        self.add_entity_segment_edge(entity1, segment_id)
        self.add_entity_segment_edge(entity2, segment_id)
        self.add_turn_segment_edge(turn_id, segment_id)

    def process_single_file(self, qid, input_path, output_dir, skip_existing=False, update=False):
        # GraphBuilder uses a custom run logic that aggregates files, 
        # so we don't use the default parallel processing.
        pass

    def build_from_files(self, triplet_files: List[str], qid: Optional[str] = None, conversation_id: Optional[str] = None) -> int:
        """Build graph from triplet files"""
        total_triplets = 0

        for file_path in triplet_files:
            try:
                data = load_json(file_path)

                if isinstance(data, list):
                    triplets = data
                elif isinstance(data, dict) and "triplets" in data:
                    triplets = data["triplets"]
                else:
                    continue

                for triplet in triplets:
                    self.process_triplet(triplet)
                    total_triplets += 1
                    
                # Push to Neo4j database if enabled
                neo4j_client.merge_triplets(triplets, session_id=conversation_id if conversation_id else qid)

            except Exception as e:
                print(f"Error loading {file_path}: {e}")

        return total_triplets

    def save_graph(self, output_path: str, format: str = "graphml") -> None:
        """
        Save graph to file

        Args:
            output_path: Output file path
            format: Output format (graphml, pickle, json)
        """
        if format == "graphml":
            # Convert lists/dicts to JSON strings for GraphML
            graph_copy = self.graph.copy()
            for u, v, data in graph_copy.edges(data=True):
                for key, value in list(data.items()):
                    if isinstance(value, (list, dict)):
                        data[key] = json.dumps(value)
            for node, data in graph_copy.nodes(data=True):
                for key, value in list(data.items()):
                    if isinstance(value, (list, dict)):
                        data[key] = json.dumps(value)
            nx.write_graphml(graph_copy, output_path)

        elif format == "pickle":
            with open(output_path, "wb") as f:
                pickle.dump(self.graph, f)

        elif format == "json":
            data = nx.node_link_data(self.graph)
            save_json(output_path, data)

        print(f"✓ Saved graph: {output_path}")

    def print_stats(self) -> None:
        """Print graph statistics"""
        print("\n" + "=" * 50)
        print("GRAPH STATISTICS")
        print("=" * 50)
        print(f"Nodes:")
        print(f"  - Entity nodes: {self.stats['entity_nodes']}")
        print(f"  - Turn nodes: {self.stats['turn_nodes']}")
        print(f"  - Segment nodes: {self.stats['segment_nodes']}")
        print(f"  - Total nodes: {self.graph.number_of_nodes()}")
        print(f"\nEdges:")
        print(f"  - Entity-Entity edges: {self.stats['entity_entity_edges']}")
        print(f"  - Entity-Turn edges: {self.stats['entity_turn_edges']}")
        print(f"  - Entity-Segment edges: {self.stats['entity_segment_edges']}")
        print(f"  - Turn-Segment edges: {self.stats['turn_segment_edges']}")
        print(f"  - Total edges: {self.graph.number_of_edges()}")
        print("=" * 50)

    def run(
        self,
        triplet_dir: str,
        output_dir: str,
        output_name: str = "knowledge_graph",
        formats: List[str] = None,
        skip_existing: bool = False,
    ) -> None:
        """
        Build graphs for all conversations

        Args:
            triplet_dir: Directory containing triplet files
            output_dir: Output directory
            output_name: Base name for output files
            formats: List of output formats (graphml, pickle, json)
            skip_existing: Skip if output exists
        """
        if formats is None:
            formats = ["graphml"]

        ensure_dir(output_dir)

        # Scan input files using storage abstraction
        files = self.scan_input_files(triplet_dir, "*_triplets.json")
        print(f"Found {len(files)} triplet files")
        print("-" * 50)

        # Group files by qid
        qid_to_files = {}
        for qid, file_path in files:
            if qid not in qid_to_files:
                qid_to_files[qid] = []
            qid_to_files[qid].append(file_path)

        for qid, triplet_files in tqdm(qid_to_files.items(), desc="Building graphs"):
            qid_output_dir = ensure_dir(os.path.join(output_dir, qid))

            # Check skip
            if skip_existing:
                expected_outputs = []
                for fmt in formats:
                    ext = {"graphml": ".graphml", "pickle": ".pkl", "json": ".json"}[fmt]
                    expected_outputs.append(os.path.join(qid_output_dir, f"{qid}_{output_name}{ext}"))
                if all(os.path.exists(p) for p in expected_outputs):
                    continue

            # Build graph
            builder = GraphBuilder()
            conversation_id = conversation_id_from_stage_path(output_dir)
            builder.build_from_files(triplet_files, qid=qid, conversation_id=conversation_id)

            # Save in requested formats
            for fmt in formats:
                ext = {"graphml": ".graphml", "pickle": ".pkl", "json": ".json"}[fmt]
                output_path = os.path.join(qid_output_dir, f"{qid}_{output_name}{ext}")
                builder.save_graph(output_path, format=fmt)

        print("-" * 50)
        print(f"✓ Graph building completed for {len(qid_to_files)} conversations")

