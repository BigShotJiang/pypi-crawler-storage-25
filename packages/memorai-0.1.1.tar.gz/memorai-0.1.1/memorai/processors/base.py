"""
Base processor class with common functionality
"""

import os
import glob
import logging
from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional, Tuple
from concurrent.futures import ThreadPoolExecutor, as_completed
from tqdm import tqdm

from ..core import LLMClient, EmbeddingGenerator, settings, load_json, save_json, ensure_dir, storage


logger = logging.getLogger(__name__)


class BaseProcessor(ABC):
    """
    Base class for all processors
    
    Provides common functionality:
    - Multi-threaded file processing
    - Progress tracking
    - Directory scanning
    """

    def __init__(
        self,
        llm_client: Optional[LLMClient] = None,
        embedding_generator: Optional[EmbeddingGenerator] = None,
        max_workers: Optional[int] = None,
    ):
        """
        Initialize processor

        Args:
            llm_client: LLM client instance (created if not provided)
            embedding_generator: Embedding generator (created if not provided)
            max_workers: Max parallel workers (defaults to settings.max_workers)
        """
        self.llm = llm_client or LLMClient()
        self.embedder = embedding_generator
        self.max_workers = max_workers or settings.max_workers

    def scan_input_files(
        self,
        input_dir: str,
        pattern: str = "*.json",
    ) -> List[Tuple[str, str]]:
        """
        Scan input directory for files matching pattern

        Args:
            input_dir: Input directory path
            pattern: File pattern to match (default: *.json)

        Returns:
            List of (qid, file_path) tuples
        """
        return storage.scan_input_files(input_dir, pattern)

    def process_files_parallel(
        self,
        files: List[Tuple[str, str]],
        output_dir: str,
        skip_existing: bool = False,
        desc: str = "Processing",
        update: bool = False,
    ) -> List[Dict[str, Any]]:
        """
        Process multiple files in parallel

        Args:
            files: List of (qid, file_path) tuples
            output_dir: Output directory
            skip_existing: Skip if output exists
            desc: Progress bar description

        Returns:
            List of processing results
        """
        ensure_dir(output_dir)
        results = []

        with tqdm(total=len(files), desc=desc) as pbar:
            with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
                futures = {
                    executor.submit(
                        self.process_single_file,
                        qid,
                        file_path,
                        output_dir,
                        skip_existing,
                        update,
                    ): (qid, file_path)
                    for qid, file_path in files
                }

                for future in as_completed(futures):
                    qid, file_path = futures[future]
                    try:
                        result = future.result()
                        if result:
                            results.append(result)
                    except Exception as e:
                        tqdm.write(f"Error processing {file_path}: {e}")
                    pbar.update(1)

        return results

    @abstractmethod
    def process_single_file(
        self,
        qid: str,
        input_path: str,
        output_dir: str,
        skip_existing: bool = False,
        update: bool = False,
    ) -> Optional[Dict[str, Any]]:
        """
        Process a single file (to be implemented by subclasses)

        Args:
            qid: Question/conversation ID
            input_path: Path to input file
            output_dir: Output directory
            skip_existing: Skip if output exists

        Returns:
            Processing result dict or None
        """
        raise NotImplementedError

    def run(
        self,
        input_dir: str,
        output_dir: str,
        file_pattern: str = "*.json",
        skip_existing: bool = False,
        update: bool = False,
    ) -> List[Dict[str, Any]]:
        """
        Run processor on all files in input directory

        Args:
            input_dir: Input directory
            output_dir: Output directory
            file_pattern: File pattern to match
            skip_existing: Skip existing outputs

        Returns:
            List of processing results
        """
        logger.info("Input: %s", input_dir)
        logger.info("Output: %s", output_dir)
        logger.info("Max workers: %s", self.max_workers)
        logger.info("%s", "-" * 50)

        files = self.scan_input_files(input_dir, file_pattern)
        logger.info("Found %s files to process", len(files))

        if not files:
            logger.warning("No files found")
            return []

        results = self.process_files_parallel(
            files=files,
            output_dir=output_dir,
            skip_existing=skip_existing,
            desc=self.__class__.__name__,
            update=update,
        )

        logger.info("%s", "-" * 50)
        logger.info("Completed: %s files processed", len(results))

        return results

