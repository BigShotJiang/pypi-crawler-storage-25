"""
Conversation Segmenter - Split conversations into topical segments
"""

import os
from typing import Dict, Any, List, Optional, Tuple

from .base import BaseProcessor
from ..core import generate_hash_id, load_json, save_json, ensure_dir, path_exists
from ..core.utils import detect_speaker_pair, split_conversation, parse_json_from_response
from ..prompts import build_segment_prompt


class Segmenter(BaseProcessor):
    """
    Segment conversations into topical chunks using LLM
    
    Input: Raw conversation JSON with chunks
    Output: Segmented JSON with segment_hash_id for each segment
    """

    def segment_conversation(
        self,
        conversation_text: str,
        speaker1: str,
        speaker2: str,
    ) -> Tuple[Optional[str], List[Dict[str, Any]]]:
        """
        Segment a single conversation

        Args:
            conversation_text: Full conversation text
            speaker1: First speaker name
            speaker2: Second speaker name

        Returns:
            Tuple of (timestamp, list of segment metadata)
        """
        timestamp, messages = split_conversation(conversation_text, speaker1, speaker2)

        if not messages:
            return timestamp, []

        # Build prompt and call LLM
        prompt = build_segment_prompt(messages)
        response = self.llm.call(prompt, temperature=0.1)

        # Parse indices from response
        try:
            idx_groups = parse_json_from_response(response)
        except Exception:
            idx_groups = []

        if not isinstance(idx_groups, list):
            idx_groups = []

        normalized_groups = []
        for grp in idx_groups:
            if not isinstance(grp, list):
                continue
            valid_indices = [i for i in grp if isinstance(i, int) and 0 <= i < len(messages)]
            if valid_indices:
                normalized_groups.append(valid_indices)

        if not normalized_groups:
            normalized_groups = [list(range(len(messages)))]

        segments_with_metadata = []

        for grp in normalized_groups:
            # Get messages in segment
            seg_messages = [messages[i] for i in grp if 0 <= i < len(messages)]

            # Generate hash_id for segment
            hash_content = (timestamp or "") + "".join(seg_messages)
            segment_hash_id = generate_hash_id(hash_content, prefix="seg-")

            # Build metadata for each message in segment
            messages_with_metadata = []
            for local_idx, msg_idx in enumerate(grp):
                if 0 <= msg_idx < len(messages):
                    messages_with_metadata.append({
                        "message_index": msg_idx,
                        "message_content": messages[msg_idx],
                        "turn_in_segment": local_idx // 2,
                        "role": speaker1 if msg_idx % 2 == 0 else speaker2,
                    })

            segments_with_metadata.append({
                "segment_hash_id": segment_hash_id,
                "messages": messages_with_metadata,
                "total_messages": len(messages_with_metadata),
            })

        return timestamp, segments_with_metadata

    def process_single_file(
        self,
        qid: str,
        input_path: str,
        output_dir: str,
        skip_existing: bool = False,
        update: bool = False,
    ) -> Optional[Dict[str, Any]]:
        """Process a single input file"""
        # Setup output
        qid_output_dir = ensure_dir(os.path.join(output_dir, qid))
        output_path = os.path.join(qid_output_dir, f"{qid}.json")

        existing_data = {}
        if path_exists(output_path):
            if skip_existing and not update:
                return None
            try:
                existing_data = load_json(output_path)
            except Exception:
                pass

        # Load input data
        data = load_json(input_path)
        question_id = data.get("question_id") or data.get("conv_id")
        chunks = data.get("chunks", [])

        existing_chunk_map = {
            c.get("chunk_index"): c
            for c in existing_data.get("chunks", [])
            if isinstance(c, dict) and c.get("chunk_index") is not None
        } if existing_data else {}
        all_chunk_results = existing_data.get("chunks", []) if update and existing_data else []

        for chunk_idx, chunk_text in enumerate(chunks):
            if chunk_idx in existing_chunk_map:
                existing_chunk = existing_chunk_map[chunk_idx]
                has_segments = bool(existing_chunk.get("segments")) and existing_chunk.get("total_segments", 0) > 0

                if skip_existing:
                    continue

                if update and has_segments:
                    continue

                if update:
                    all_chunk_results = [
                        c for c in all_chunk_results
                        if not (isinstance(c, dict) and c.get("chunk_index") == chunk_idx)
                    ]

            # Auto-detect speaker pair
            speaker_pair = detect_speaker_pair(chunk_text)

            if speaker_pair is None:
                print(f"⚠️ No speaker pair detected for {qid} chunk {chunk_idx}")
                all_chunk_results.append((None, []))
                continue

            speaker1, speaker2 = speaker_pair

            try:
                timestamp, segments = self.segment_conversation(
                    chunk_text, speaker1, speaker2
                )

                # Generate chunk hash
                chunk_hash_content = f"{qid}_{chunk_idx}_{timestamp or ''}"
                chunk_hash_id = generate_hash_id(chunk_hash_content, prefix="chunk-")

                all_chunk_results.append({
                    "chunk_index": chunk_idx,
                    "chunk_hash_id": chunk_hash_id,
                    "timestamp": timestamp,
                    "segments": segments,
                    "total_segments": len(segments),
                })

            except Exception as e:
                print(f"Error processing {qid} chunk {chunk_idx}: {e}")
                all_chunk_results.append({
                    "chunk_index": chunk_idx,
                    "chunk_hash_id": None,
                    "timestamp": None,
                    "segments": [],
                    "total_segments": 0,
                })

        # Save output
        output_data = {
            "question_id": question_id,
            "chunks": all_chunk_results,
            "total_chunks": len(all_chunk_results),
        }
        save_json(output_path, output_data)

        return output_data

    def run_from_json(
        self,
        input_json: str,
        output_dir: str,
        skip_existing: bool = False,
        update: bool = False,
    ) -> List[Dict[str, Any]]:
        """
        Run segmentation from a single JSON file containing multiple conversations

        Args:
            input_json: Path to input JSON file
            output_dir: Output directory
            skip_existing: Skip existing outputs

        Returns:
            List of processing results
        """
        print(f"Input JSON: {input_json}")
        print(f"Output: {output_dir}")
        print("-" * 50)

        ensure_dir(output_dir)

        # Load and group by question_id
        data = load_json(input_json)
        items = {}

        for item in data:
            qid = item.get("question_id") or item.get("conv_id")
            chunks = item.get("chunks", [])

            for idx, chunk_text in enumerate(chunks):
                speaker_pair = detect_speaker_pair(chunk_text)
                items.setdefault(qid, []).append((idx, chunk_text, speaker_pair))

        print(f"Found {len(items)} conversations to process")

        results = []
        for qid, chunk_list in items.items():
            output_path = os.path.join(output_dir, qid, f"{qid}.json")

            existing_data = {}
            if path_exists(output_path):
                if skip_existing and not update:
                    continue
                try:
                    existing_data = load_json(output_path)
                except Exception:
                    pass

            ensure_dir(os.path.join(output_dir, qid))
            chunk_list.sort(key=lambda x: x[0])

            existing_chunk_map = {
                c.get("chunk_index"): c
                for c in existing_data.get("chunks", [])
                if isinstance(c, dict) and c.get("chunk_index") is not None
            } if existing_data else {}
            all_chunk_results = existing_data.get("chunks", []) if update and existing_data else []

            for idx, conv, speaker_pair in chunk_list:
                if idx in existing_chunk_map:
                    existing_chunk = existing_chunk_map[idx]
                    has_segments = bool(existing_chunk.get("segments")) and existing_chunk.get("total_segments", 0) > 0

                    if skip_existing:
                        continue

                    if update and has_segments:
                        continue

                    if update:
                        all_chunk_results = [
                            c for c in all_chunk_results
                            if not (isinstance(c, dict) and c.get("chunk_index") == idx)
                        ]

                if speaker_pair is None:
                    all_chunk_results.append({
                        "chunk_index": idx,
                        "chunk_hash_id": None,
                        "timestamp": None,
                        "segments": [],
                        "total_segments": 0,
                    })
                    continue

                speaker1, speaker2 = speaker_pair
                try:
                    timestamp, segments = self.segment_conversation(conv, speaker1, speaker2)
                    chunk_hash_id = generate_hash_id(f"{qid}_{idx}_{timestamp or ''}", prefix="chunk-")

                    all_chunk_results.append({
                        "chunk_index": idx,
                        "chunk_hash_id": chunk_hash_id,
                        "timestamp": timestamp,
                        "segments": segments,
                        "total_segments": len(segments),
                    })
                except Exception as e:
                    print(f"Error: {qid} chunk {idx}: {e}")
                    all_chunk_results.append({
                        "chunk_index": idx,
                        "chunk_hash_id": None,
                        "timestamp": None,
                        "segments": [],
                        "total_segments": 0,
                    })

            output_data = {
                "question_id": qid,
                "chunks": all_chunk_results,
                "total_chunks": len(all_chunk_results),
            }
            save_json(output_path, output_data)
            results.append(output_data)
            print(f"✓ {qid}: {len(all_chunk_results)} chunks")

        print("-" * 50)
        print(f"Completed: {len(results)} conversations processed")

        return results

