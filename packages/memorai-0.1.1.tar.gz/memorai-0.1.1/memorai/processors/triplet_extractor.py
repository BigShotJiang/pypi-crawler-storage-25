"""
Triplet Extractor - Extract knowledge triplets from conversations
"""

import os
from typing import Dict, Any, List, Optional, Tuple
from concurrent.futures import ThreadPoolExecutor, as_completed

import pandas as pd

from .base import BaseProcessor
from ..core import generate_hash_id, load_json, save_json, ensure_dir, path_exists, EmbeddingGenerator
from ..prompts import build_triplet_prompt
from ..prompts.triplet import TRIPLET_SYSTEM_PROMPT


class TripletExtractor(BaseProcessor):
    """
    Extract knowledge triplets (entity1, relation, entity2) from conversations
    
    Input: Filtered JSON from Filter
    Output: Triplets JSON + optional embeddings parquet
    """

    def parse_triplet_line(self, line: str) -> Optional[Dict[str, Any]]:
        """
        Parse a triplet line: "entity1|relation|entity2|0,2"

        Returns:
            Parsed triplet dict or None
        """
        parts = line.strip().split("|")
        if len(parts) != 4:
            return None

        entity1, relation, entity2, indices_str = parts

        try:
            source_indices = [int(x.strip()) for x in indices_str.split(",")]
        except (ValueError, AttributeError):
            return None

        return {
            "entity1": entity1.strip(),
            "relation": relation.strip(),
            "entity2": entity2.strip(),
            "source_indices": source_indices,
        }

    def extract_triplets_from_segment(
        self,
        messages: List[Dict[str, Any]],
        max_retries: int = 3,
    ) -> List[Dict[str, Any]]:
        """
        Extract triplets from segment messages

        Args:
            messages: List of message dicts with 'content' key
            max_retries: Max retries if no triplets found

        Returns:
            List of parsed triplets
        """
        # Format messages
        formatted_lines = [f"Message {i}: {msg['content']}" for i, msg in enumerate(messages)]
        segment_text = "\n".join(formatted_lines)

        prompt = build_triplet_prompt(segment_text)

        for attempt in range(max_retries):
            try:
                response = self.llm.call(
                    prompt,
                    system_prompt=TRIPLET_SYSTEM_PROMPT,
                    temperature=0.1,
                )

                # Parse line by line
                triplets = []
                for line in response.strip().split("\n"):
                    if not line.strip():
                        continue
                    parsed = self.parse_triplet_line(line)
                    if parsed:
                        triplets.append(parsed)

                if triplets:
                    return triplets

            except Exception as e:
                if attempt < max_retries - 1:
                    print(f"Retry triplet extraction ({attempt + 1}/{max_retries}): {e}")

        return []

    def generate_turn_id(self, content: str, timestamp: str) -> str:
        """Generate turn_id from content and timestamp"""
        turn_hash_input = f"{timestamp}_{content}"
        return generate_hash_id(turn_hash_input, prefix="turn-")

    def process_segment(
        self,
        segment_data: Dict[str, Any],
        timestamp: str,
    ) -> List[Dict[str, Any]]:
        """
        Process a single segment and extract triplets

        Args:
            segment_data: Segment data from filter output
            timestamp: Timestamp for turn_id generation

        Returns:
            List of triplet objects
        """
        segment_id = segment_data.get("segment_hash_id")
        messages = segment_data.get("filtered_messages") or []
        if not segment_id or not messages:
            return []

        # Build index map
        index_map = {i: msg for i, msg in enumerate(messages)}

        # Extract triplets
        raw_triplets = self.extract_triplets_from_segment(messages)

        if not raw_triplets:
            return []

        # Expand triplets (one record per source message)
        result = []
        for raw_triplet in raw_triplets:
            entity1 = raw_triplet["entity1"]
            entity2 = raw_triplet["entity2"]
            relation = raw_triplet["relation"]

            for msg_idx in raw_triplet["source_indices"]:
                if msg_idx in index_map:
                    message = index_map[msg_idx]
                    turn_id = self.generate_turn_id(message["content"], timestamp)
                    triplet_id = generate_hash_id(
                        f"{entity1}_{relation}_{entity2}_{turn_id}_{segment_id}",
                        prefix="triplet-",
                    )

                    result.append({
                        "triplet_id": triplet_id,
                        "entity1": entity1,
                        "entity2": entity2,
                        "relation": relation,
                        "turn_id": turn_id,
                        "segment_id": segment_id,
                    })

        return result

    def process_single_file(
        self,
        qid: str,
        input_path: str,
        output_dir: str,
        skip_existing: bool = False,
        update: bool = False,
    ) -> Optional[Dict[str, Any]]:
        """Process a single filtered file"""
        # Setup output
        qid_output_dir = ensure_dir(os.path.join(output_dir, qid))

        # Determine output filename from input
        input_filename = os.path.splitext(os.path.basename(input_path))[0]
        output_path = os.path.join(qid_output_dir, f"{input_filename}_triplets.json")

        existing_data = {}
        if path_exists(output_path):
            if skip_existing and not update:
                return None
            try:
                existing_data = load_json(output_path)
            except Exception:
                pass

        processed_chunks = existing_data.get("processed_chunks", []) if existing_data else []
        all_triplets = existing_data.get("triplets", []) if update and existing_data else []

        # If a prior run produced no triplets, allow update mode to reprocess chunks.
        if update and existing_data:
            total_triplets = existing_data.get("total_triplets", len(existing_data.get("triplets", [])))
            if total_triplets == 0:
                processed_chunks = []
                all_triplets = []

        # Load input
        data = load_json(input_path)
        chunks = data.get("chunks", [])

        for chunk in chunks:
            chunk_idx = chunk.get("chunk_index")
            if (skip_existing or update) and chunk_idx in processed_chunks:
                continue

            timestamp = chunk.get("timestamp", "")
            segments = chunk.get("segments", [])

            futures = {}
            with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
                for segment in segments:
                    segment_id = segment.get("segment_hash_id", "unknown")
                    futures[
                        executor.submit(self.process_segment, segment, timestamp)
                    ] = segment_id

                for future in as_completed(futures):
                    try:
                        triplets = future.result()
                        if triplets:
                            all_triplets.extend(triplets)
                    except Exception as e:
                        print(f"Error triplet extraction for segment {futures[future]}: {e}")

            if chunk_idx is not None and chunk_idx not in processed_chunks:
                processed_chunks.append(chunk_idx)

        # Save JSON output
        output_data = {
            "triplets": all_triplets,
            "total_triplets": len(all_triplets),
            "processed_chunks": processed_chunks,
        }
        save_json(output_path, output_data)

        # Generate embeddings if embedder is available
        if self.embedder and all_triplets:
            self._save_embeddings(all_triplets, qid_output_dir, input_filename)

        return output_data

    def _save_embeddings(
        self,
        triplets: List[Dict[str, Any]],
        output_dir: str,
        filename: str,
    ) -> None:
        """Save triplet embeddings to parquet"""
        df_data = []
        for triplet in triplets:
            content = f"{triplet['entity1']} {triplet['relation']} {triplet['entity2']}"
            df_data.append({
                "triplet_id": triplet["triplet_id"],
                "entity1": triplet["entity1"],
                "entity2": triplet["entity2"],
                "relation": triplet["relation"],
                "content": content,
                "turn_id": triplet["turn_id"],
                "segment_id": triplet["segment_id"],
            })

        df = pd.DataFrame(df_data)

        # Generate embeddings
        print(f"  Generating embeddings for {len(df)} triplets...")
        embeddings = self.embedder.embed_batch(df["content"].tolist())
        df["embedding"] = embeddings

        # Save parquet
        output_path = os.path.join(output_dir, f"{filename}_triplets_embedded.parquet")
        df.to_parquet(output_path, index=False)
        print(f"  ✓ Saved embeddings: {output_path}")

