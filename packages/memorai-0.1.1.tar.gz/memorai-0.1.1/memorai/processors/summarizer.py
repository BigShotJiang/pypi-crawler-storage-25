"""
Summarizer - Generate summaries for conversation segments
"""

import os
from typing import Dict, Any, List, Optional
from concurrent.futures import ThreadPoolExecutor, as_completed

import pandas as pd

from .base import BaseProcessor
from ..core import (
    generate_hash_id,
    load_json,
    save_json,
    ensure_dir,
    path_exists,
    conversation_id_from_stage_path,
)
from ..core.neo4j_client import neo4j_client
from ..prompts import build_summary_prompt
from ..prompts.summary import SUMMARY_SYSTEM_PROMPT


class Summarizer(BaseProcessor):
    """
    Generate summaries for conversation segments
    
    Input: Segmented JSON from Segmenter
    Output: Summaries JSON + optional embeddings parquet
    """

    def summarize_segment(self, messages: List[Dict[str, Any]]) -> str:
        """
        Summarize a segment

        Args:
            messages: List of message dicts

        Returns:
            Summary text
        """
        # Concat messages
        segment_text = "\n".join(msg["message_content"] for msg in messages)

        prompt = build_summary_prompt(segment_text)

        return self.llm.call(
            prompt,
            system_prompt=SUMMARY_SYSTEM_PROMPT,
            temperature=0.3,
        )

    def process_segment(
        self,
        segment_data: Dict[str, Any],
    ) -> Optional[Dict[str, Any]]:
        """
        Process a single segment

        Args:
            segment_data: Segment data with messages

        Returns:
            Summary result dict or None
        """
        try:
            segment_hash_id = segment_data["segment_hash_id"]
            messages = segment_data["messages"]

            # Get summary
            summary = self.summarize_segment(messages)

            # Generate summary hash_id
            summary_hash_id = generate_hash_id(
                f"{segment_hash_id}_{summary}",
                prefix="summary-",
            )

            # Calculate original text length
            original_text = "\n".join(msg["message_content"] for msg in messages)

            return {
                "summary_hash_id": summary_hash_id,
                "segment_hash_id": segment_hash_id,
                "summary": summary,
                "original_message_count": len(messages),
                "original_text_length": len(original_text),
            }

        except Exception as e:
            print(f"Error summarizing segment: {e}")
            return None

    def process_single_file(
        self,
        qid: str,
        input_path: str,
        output_dir: str,
        skip_existing: bool = False,
        update: bool = False,
    ) -> Optional[Dict[str, Any]]:
        """Process a single segmented file"""
        # Setup output
        qid_output_dir = ensure_dir(os.path.join(output_dir, qid))

        # Load input
        data = load_json(input_path)
        question_id = data.get("question_id") or data.get("conv_id")
        chunks = data.get("chunks", [])

        output_path = os.path.join(qid_output_dir, f"{question_id}_summaries.json")

        existing_data = {}
        if path_exists(output_path):
            if skip_existing and not update:
                return None
            try:
                existing_data = load_json(output_path)
            except Exception:
                pass

        existing_chunk_map = {
            c.get("chunk_index"): c
            for c in existing_data.get("chunks", [])
            if isinstance(c, dict) and c.get("chunk_index") is not None
        } if existing_data else {}
        all_results = existing_data.get("chunks", []) if update and existing_data else []
        all_summaries = []

        if update and existing_data:
            # Flatten existing summaries
            for c in all_results:
                all_summaries.extend(c.get("segment_summaries", []))

        for chunk in chunks:
            chunk_hash_id = chunk.get("chunk_hash_id")
            chunk_index = chunk.get("chunk_index")
            if chunk_hash_id is None or chunk_index is None:
                continue
            
            if chunk_index in existing_chunk_map:
                existing_chunk = existing_chunk_map[chunk_index]
                has_summaries = bool(existing_chunk.get("segment_summaries"))

                if skip_existing:
                    continue

                if update and has_summaries:
                    continue

                if update:
                    all_results = [
                        c for c in all_results
                        if not (isinstance(c, dict) and c.get("chunk_index") == chunk_index)
                    ]

            timestamp = chunk.get("timestamp")
            segments = chunk.get("segments") or []

            chunk_result = {
                "chunk_hash_id": chunk_hash_id,
                "chunk_index": chunk_index,
                "timestamp": timestamp,
                "segment_summaries": [],
            }

            futures = {}
            with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
                for segment in segments:
                    segment_id = segment.get("segment_hash_id", "unknown")
                    futures[executor.submit(self.process_segment, segment)] = segment_id

                for future in as_completed(futures):
                    try:
                        summary_result = future.result()
                        if summary_result:
                            chunk_result["segment_summaries"].append(summary_result)
                            all_summaries.append(summary_result)
                    except Exception as e:
                        print(f"Error summarizing segment {futures[future]}: {e}")

            all_results.append(chunk_result)

        # Save JSON
        output_data = {
            "question_id": question_id,
            "chunks": all_results,
            "total_chunks": len(all_results),
            "total_summaries": len(all_summaries),
        }
        save_json(output_path, output_data)

        # Save embeddings if embedder available
        if self.embedder and all_summaries:
            self._save_embeddings(all_summaries, qid_output_dir, question_id)

        return output_data

    def _save_embeddings(
        self,
        summaries: List[Dict[str, Any]],
        output_dir: str,
        question_id: str,
    ) -> None:
        """Save summary embeddings to parquet"""
        df_data = []
        for s in summaries:
            df_data.append({
                "segment_id": s["segment_hash_id"],
                "summary": s["summary"],
            })

        print(f"  Generating embeddings for {len(df_data)} summaries...")
        embeddings = self.embedder.embed_batch([d["summary"] for d in df_data])
        
        for i, emb in enumerate(embeddings):
            df_data[i]["embedding"] = emb.tolist() if hasattr(emb, "tolist") else emb
            
        conversation_id = conversation_id_from_stage_path(output_dir)
        neo4j_client.merge_summaries(df_data, session_id=conversation_id)
        print(f"  ✓ Saved embeddings to Neo4j.")

