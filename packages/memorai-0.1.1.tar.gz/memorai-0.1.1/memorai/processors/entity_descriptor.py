"""
Entity Descriptor - Generate descriptions for entities extracted from triplets
"""

import os
import glob
from typing import Dict, Any, List, Optional, Set
from concurrent.futures import ThreadPoolExecutor, as_completed

import pandas as pd
from tqdm import tqdm

from .base import BaseProcessor
from ..core import (
    generate_hash_id,
    load_json,
    save_json,
    ensure_dir,
    path_exists,
    conversation_id_from_stage_path,
)
from ..core.neo4j_client import neo4j_client
from ..prompts import build_entity_prompt
from ..prompts.entity import ENTITY_SYSTEM_PROMPT


class EntityDescriptor(BaseProcessor):
    """
    Generate descriptions for entities based on conversation context
    
    Input: Triplets JSON + Filtered JSON (for context)
    Output: Entity descriptions JSON + optional embeddings parquet
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Cache for segment/turn content
        self.segment_cache: Dict[str, str] = {}
        self.turn_cache: Dict[str, str] = {}

    def load_context_data(self, filtered_dir: str) -> None:
        """
        Load filtered data to build segment and turn caches

        Args:
            filtered_dir: Directory containing filtered JSON files
        """
        print("Loading context data...")

        files = self.scan_input_files(filtered_dir, "*_filtered.json")
        print(f"Found {len(files)} filtered files for context")

        for qid, file_path in tqdm(files, desc="Loading context"):
            try:
                data = load_json(file_path)

                for chunk in data.get("chunks", []):
                    timestamp = chunk.get("timestamp", "")

                    for segment in chunk.get("segments", []):
                        segment_id = segment["segment_hash_id"]
                        messages = segment.get("filtered_messages", [])

                        # Build segment content
                        segment_lines = [msg["content"] for msg in messages]
                        self.segment_cache[segment_id] = "\n".join(segment_lines)

                        # Build turn content and turn_id
                        for msg in messages:
                            turn_content = msg["content"]
                            turn_hash_input = f"{timestamp}_{turn_content}"
                            turn_id = generate_hash_id(turn_hash_input, prefix="turn-")
                            self.turn_cache[turn_id] = turn_content

            except Exception as e:
                print(f"Error loading {file_path}: {e}")

        print(f"✓ Loaded {len(self.segment_cache)} segments, {len(self.turn_cache)} turns")

    def group_entities_by_turn(
        self,
        triplets: List[Dict[str, Any]],
    ) -> Dict[str, Dict[str, Any]]:
        """
        Group entities by turn_id

        Returns:
            {turn_id: {"segment_id": str, "entities": set}}
        """
        turn_to_entities: Dict[str, Dict[str, Any]] = {}

        for triplet in triplets:
            turn_id = triplet["turn_id"]
            segment_id = triplet["segment_id"]

            if turn_id not in turn_to_entities:
                turn_to_entities[turn_id] = {
                    "segment_id": segment_id,
                    "entities": set(),
                }

            turn_to_entities[turn_id]["entities"].add(triplet["entity1"])
            turn_to_entities[turn_id]["entities"].add(triplet["entity2"])

        # Convert sets to sorted lists
        for turn_id in turn_to_entities:
            turn_to_entities[turn_id]["entities"] = sorted(
                list(turn_to_entities[turn_id]["entities"])
            )

        return turn_to_entities

    def parse_description_line(self, line: str) -> Optional[Dict[str, str]]:
        """Parse: "John|A software engineer at Google" """
        parts = line.strip().split("|", 1)
        if len(parts) != 2:
            return None
        return {"entity": parts[0].strip(), "description": parts[1].strip()}

    def generate_descriptions_for_turn(
        self,
        turn_id: str,
        segment_id: str,
        entities: List[str],
        max_retries: int = 3,
    ) -> List[Dict[str, Any]]:
        """
        Generate descriptions for all entities in a turn

        Returns:
            List of entity description dicts
        """
        segment_content = self.segment_cache.get(segment_id, "[Segment not found]")
        turn_content = self.turn_cache.get(turn_id, "[Turn not found]")

        prompt = build_entity_prompt(segment_content, turn_content, entities)

        for attempt in range(max_retries):
            try:
                response = self.llm.call(
                    prompt,
                    system_prompt=ENTITY_SYSTEM_PROMPT,
                    temperature=0.2,
                )

                descriptions = []
                for line in response.strip().split("\n"):
                    if not line.strip():
                        continue
                    parsed = self.parse_description_line(line)
                    if parsed:
                        entity_desc_id = generate_hash_id(
                            f"{parsed['entity']}_{parsed['description']}",
                            prefix="entdesc-",
                        )
                        descriptions.append({
                            "entity_description_id": entity_desc_id,
                            "entity": parsed["entity"],
                            "description": parsed["description"],
                            "turn_id": turn_id,
                            "segment_id": segment_id,
                        })

                if descriptions:
                    return descriptions

            except Exception as e:
                if attempt < max_retries - 1:
                    print(f"Retry entity description ({attempt + 1}/{max_retries}): {e}")

        return []

    def process_single_file(
        self,
        qid: str,
        input_path: str,
        output_dir: str,
        skip_existing: bool = False,
        update: bool = False,
    ) -> Optional[Dict[str, Any]]:
        """Process a single triplet file"""
        # Setup output
        qid_output_dir = ensure_dir(os.path.join(output_dir, qid))

        input_filename = os.path.splitext(os.path.basename(input_path))[0]
        output_path = os.path.join(qid_output_dir, f"{input_filename}_descriptions.json")

        existing_desc = []
        if path_exists(output_path):
            if skip_existing and not update:
                return None
            try:
                existing_desc = load_json(output_path)
            except Exception:
                pass

        processed_turns = {d["turn_id"] for d in existing_desc} if existing_desc and isinstance(existing_desc, list) else set()
        all_descriptions = existing_desc if update and existing_desc else []

        # Load triplets
        data = load_json(input_path)
        triplets = data.get("triplets", [])

        if not triplets:
            return None

        # Group entities by turn
        turn_entities = self.group_entities_by_turn(triplets)

        # Generate descriptions for each turn
        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            futures = {}
            for turn_id, info in turn_entities.items():
                if (skip_existing or update) and turn_id in processed_turns:
                    continue

                futures[executor.submit(
                    self.generate_descriptions_for_turn,
                    turn_id,
                    info["segment_id"],
                    info["entities"],
                )] = turn_id

            for future in as_completed(futures):
                try:
                    descriptions = future.result()
                    all_descriptions.extend(descriptions)
                except Exception as e:
                    print(f"Error: {e}")

        # Save JSON
        save_json(output_path, all_descriptions)

        # Save embeddings if embedder available
        if self.embedder and all_descriptions:
            self._save_embeddings(all_descriptions, qid_output_dir, input_filename)

        return {"total_descriptions": len(all_descriptions)}

    def _save_embeddings(
        self,
        descriptions: List[Dict[str, Any]],
        output_dir: str,
        filename: str,
    ) -> None:
        """Save entity description embeddings to parquet"""
        df_data = []
        for desc in descriptions:
            content = f"{desc['entity']}: {desc['description']}"
            df_data.append({
                "entity": desc["entity"],
                "description": desc["description"],
                "content": content,
            })

        print(f"  Generating embeddings for {len(df_data)} descriptions...")
        embeddings = self.embedder.embed_batch([d["content"] for d in df_data])
        
        for i, emb in enumerate(embeddings):
            df_data[i]["embedding"] = emb.tolist() if hasattr(emb, "tolist") else emb
            
        conversation_id = conversation_id_from_stage_path(output_dir)
        neo4j_client.merge_entities(df_data, session_id=conversation_id)
        print(f"  ✓ Saved embeddings to Neo4j.")

    def run(
        self,
        triplet_dir: str,
        filtered_dir: str,
        output_dir: str,
        file_pattern: str = "*.json",
        skip_existing: bool = False,
        update: bool = False,
    ) -> List[Dict[str, Any]]:
        """
        Run entity description generation

        Args:
            triplet_dir: Directory containing triplet JSON files
            filtered_dir: Directory containing filtered JSON files (for context)
            output_dir: Output directory
            skip_existing: Skip existing outputs
        """
        print(f"Triplet dir: {triplet_dir}")
        print(f"Filtered dir: {filtered_dir}")
        print(f"Output: {output_dir}")
        print("-" * 50)

        # Load context data first
        self.load_context_data(filtered_dir)

        # Scan triplet files
        files = self.scan_input_files(triplet_dir, file_pattern)
        print(f"Found {len(files)} triplet files")

        if not files:
            return []

        results = self.process_files_parallel(
            files=files,
            output_dir=output_dir,
            skip_existing=skip_existing,
            desc="EntityDescriptor",
            update=update,
        )

        print("-" * 50)
        total = sum(r.get("total_descriptions", 0) for r in results)
        print(f"Total descriptions generated: {total}")

        return results

