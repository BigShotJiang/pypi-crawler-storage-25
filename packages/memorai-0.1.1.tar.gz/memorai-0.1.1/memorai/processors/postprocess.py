#!/usr/bin/env python3
"""
Post-processing utilities:
- Segment to chunk mapping
- Turn ID consolidation
- Graph rebuilding
- Embeddings with timestamps
"""

import os
import json
import glob
import shutil
import hashlib
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from tqdm import tqdm
import pandas as pd

from ..core.utils import load_json, save_json, ensure_dir, generate_hash_id
from ..core.embeddings import EmbeddingGenerator


# =============================================================================
# SEGMENT TO CHUNK MAPPING
# =============================================================================


class SegmentChunkMapper:
    """Export segment_id → chunk_id mapping"""

    def extract_from_file(self, file_path: str) -> Dict[str, str]:
        """Extract segment_id → chunk_id from segmented file"""
        mappings = {}
        try:
            data = load_json(file_path)
            for chunk in data.get("chunks", []):
                chunk_id = chunk.get("chunk_hash_id")
                if not chunk_id:
                    continue
                for segment in chunk.get("segments", []):
                    segment_id = segment.get("segment_hash_id")
                    if segment_id:
                        mappings[segment_id] = chunk_id
        except Exception as e:
            print(f"  ⚠️  Error processing {file_path}: {e}")
        return mappings

    def run(self, segmented_dir: str, output_dir: str, verbose: bool = True):
        """Export segment → chunk mapping for all conversations"""
        if verbose:
            print("=" * 60)
            print("EXPORT SEGMENT → CHUNK MAPPING")
            print("=" * 60)

        subdirs = [
            d
            for d in os.listdir(segmented_dir)
            if os.path.isdir(os.path.join(segmented_dir, d))
        ]

        if not subdirs:
            print(f"❌ No subdirectories found in {segmented_dir}")
            return

        total_mappings = 0
        for conv_id in tqdm(subdirs, desc="Processing", disable=not verbose):
            conv_dir = os.path.join(segmented_dir, conv_id)
            json_file = os.path.join(conv_dir, f"{conv_id}.json")

            if not os.path.exists(json_file):
                continue

            mappings = self.extract_from_file(json_file)
            if not mappings:
                continue

            # Save
            conv_output_dir = os.path.join(output_dir, conv_id)
            ensure_dir(conv_output_dir)
            output_path = os.path.join(conv_output_dir, "segment_to_chunk.json")
            save_json(output_path, mappings)
            total_mappings += len(mappings)

        if verbose:
            print(f"✓ Exported {total_mappings} mappings")


# =============================================================================
# TURN ID CONSOLIDATION
# =============================================================================


class TurnConsolidator:
    """Consolidate duplicate turn_ids across conversations"""

    def __init__(self, max_workers: int = 10):
        self.max_workers = max_workers

    def _generate_new_turn_id(self, full_content: str) -> str:
        """Generate new turn_id from full content"""
        hash_obj = hashlib.md5(full_content.encode())
        return f"turn-{hash_obj.hexdigest()}"

    def _build_mappings(
        self, turn_id_to_content: Dict[str, str]
    ) -> Tuple[Dict[str, str], Dict[str, List[str]], Dict[str, str]]:
        """Build old→new and new→old mappings"""
        content_to_old_ids = defaultdict(list)
        for old_id, content in turn_id_to_content.items():
            content_to_old_ids[content].append(old_id)

        old_to_new = {}
        new_to_old = {}
        new_turn_id_to_content = {}

        for content, old_ids in content_to_old_ids.items():
            new_turn_id = self._generate_new_turn_id(content)
            new_to_old[new_turn_id] = sorted(old_ids)
            new_turn_id_to_content[new_turn_id] = content
            for old_id in old_ids:
                old_to_new[old_id] = new_turn_id

        return old_to_new, new_to_old, new_turn_id_to_content

    def _backup_file(self, file_path: str) -> Optional[str]:
        """Backup file to *_old.* version"""
        if not os.path.exists(file_path):
            return None
        path_obj = Path(file_path)
        suffix = path_obj.suffix
        backup_path = str(path_obj.with_suffix("")) + f"_old{suffix}"
        shutil.copy2(file_path, backup_path)
        return backup_path

    def _update_json_files(
        self, conv_path: str, pattern: str, old_to_new: Dict[str, str]
    ) -> int:
        """Update turn_id in JSON files"""
        files = glob.glob(os.path.join(conv_path, pattern))
        updated = 0

        for file_path in files:
            try:
                self._backup_file(file_path)
                data = load_json(file_path)

                if "triplets" in data:
                    for item in data["triplets"]:
                        if "turn_id" in item and item["turn_id"] in old_to_new:
                            item["turn_id"] = old_to_new[item["turn_id"]]
                elif isinstance(data, list):
                    for item in data:
                        if isinstance(item, dict) and "turn_id" in item:
                            if item["turn_id"] in old_to_new:
                                item["turn_id"] = old_to_new[item["turn_id"]]

                save_json(file_path, data)
                updated += 1
            except Exception as e:
                print(f"  ⚠️  Error updating {file_path}: {e}")

        return updated

    def _update_parquet_files(
        self, conv_path: str, pattern: str, old_to_new: Dict[str, str]
    ) -> int:
        """Update turn_id in parquet files"""
        files = glob.glob(os.path.join(conv_path, pattern))
        updated = 0

        for file_path in files:
            try:
                self._backup_file(file_path)
                df = pd.read_parquet(file_path)
                if "turn_id" in df.columns:
                    df["turn_id"] = df["turn_id"].map(lambda x: old_to_new.get(x, x))
                df.to_parquet(file_path, index=False)
                updated += 1
            except Exception as e:
                print(f"  ⚠️  Error updating {file_path}: {e}")

        return updated

    def _process_single_conv(
        self, conv_path: str, dry_run: bool = False
    ) -> Dict[str, Any]:
        """Process single conversation"""
        conv_id = os.path.basename(conv_path)

        try:
            turn_file = os.path.join(conv_path, "turn_id_to_content.json")
            if not os.path.exists(turn_file):
                return {"conv_id": conv_id, "status": "skip", "reason": "no_turn_file"}

            turn_id_to_content = load_json(turn_file)
            if not turn_id_to_content:
                return {"conv_id": conv_id, "status": "skip", "reason": "empty"}

            old_to_new, new_to_old, new_content = self._build_mappings(turn_id_to_content)

            if len(new_content) == len(turn_id_to_content):
                return {
                    "conv_id": conv_id,
                    "status": "skip",
                    "reason": "no_duplicates",
                    "old_count": len(turn_id_to_content),
                }

            if not dry_run:
                # Backup and update turn_id_to_content.json
                self._backup_file(turn_file)
                save_json(turn_file, new_content)

                # Save mapping
                save_json(os.path.join(conv_path, "turn_id_mapping.json"), new_to_old)

                # Update JSON files
                self._update_json_files(conv_path, "*_triplets.json", old_to_new)
                self._update_json_files(conv_path, "*_descriptions.json", old_to_new)

                # Update parquet files
                self._update_parquet_files(
                    conv_path, "*_triplets_embedded.parquet", old_to_new
                )
                self._update_parquet_files(
                    conv_path, "*_descriptions_embedded.parquet", old_to_new
                )

            old_count = len(turn_id_to_content)
            new_count = len(new_content)
            return {
                "conv_id": conv_id,
                "status": "success",
                "old_count": old_count,
                "new_count": new_count,
                "reduction": f"{(1 - new_count / old_count) * 100:.1f}%",
            }

        except Exception as e:
            return {"conv_id": conv_id, "status": "error", "message": str(e)}

    def run(self, base_dir: str, dry_run: bool = False):
        """Consolidate turn IDs across all conversations"""
        print("=" * 60)
        print("CONSOLIDATE TURN IDS")
        print("=" * 60)

        conv_dirs = [
            d for d in os.listdir(base_dir) if os.path.isdir(os.path.join(base_dir, d))
        ]

        if not conv_dirs:
            print(f"⚠️  No subdirectories in {base_dir}")
            return

        print(f"Found {len(conv_dirs)} conversations")
        print(f"Dry run: {dry_run}")

        results = []
        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            futures = {
                executor.submit(
                    self._process_single_conv, os.path.join(base_dir, d), dry_run
                ): d
                for d in conv_dirs
            }

            for future in tqdm(
                as_completed(futures), total=len(futures), desc="Processing"
            ):
                results.append(future.result())

        # Summary
        success = [r for r in results if r["status"] == "success"]
        if success:
            total_old = sum(r["old_count"] for r in success)
            total_new = sum(r["new_count"] for r in success)
            print(f"\n✓ Consolidated {len(success)} conversations")
            print(f"  Turn IDs: {total_old} → {total_new}")
            print(f"  Reduction: {(1 - total_new / total_old) * 100:.1f}%")


# =============================================================================
# GRAPH REBUILDER
# =============================================================================


class GraphRebuilder:
    """Rebuild graphs after turn ID consolidation"""

    def __init__(self, max_workers: int = 10):
        self.max_workers = max_workers

    def _process_single_conv(
        self,
        conv_path: str,
        output_format: str = "graphml",
        output_name: str = "knowledge_graph",
    ) -> Dict[str, Any]:
        """Rebuild graph for single conversation"""
        from .graph_builder import GraphBuilder

        conv_id = os.path.basename(conv_path)

        try:
            # Find triplet files
            triplet_files = glob.glob(os.path.join(conv_path, "*_triplets.json"))
            triplet_files = [f for f in triplet_files if "_old" not in f]

            if not triplet_files:
                return {"conv_id": conv_id, "status": "skip", "reason": "no_triplets"}

            # Backup existing graphs
            for ext in [".graphml", ".pkl", ".json"]:
                old_files = glob.glob(os.path.join(conv_path, f"*{ext}"))
                for f in old_files:
                    if "_old" not in f:
                        backup = f.replace(ext, f"_old{ext}")
                        if os.path.exists(f):
                            shutil.copy2(f, backup)

            # Rebuild
            builder = GraphBuilder()
            builder.build_from_files(triplet_files)

            # Save
            ext_map = {"graphml": ".graphml", "pickle": ".pkl", "json": ".json"}
            output_path = os.path.join(
                conv_path, f"{conv_id}_{output_name}{ext_map[output_format]}"
            )
            builder.save_graph(output_path, format=output_format)

            return {
                "conv_id": conv_id,
                "status": "success",
                "nodes": builder.graph.number_of_nodes(),
                "edges": builder.graph.number_of_edges(),
            }

        except Exception as e:
            return {"conv_id": conv_id, "status": "error", "message": str(e)}

    def run(
        self,
        base_dir: str,
        output_format: str = "graphml",
        output_name: str = "knowledge_graph",
    ):
        """Rebuild graphs for all conversations"""
        print("=" * 60)
        print("REBUILD GRAPHS")
        print("=" * 60)

        conv_dirs = [
            d for d in os.listdir(base_dir) if os.path.isdir(os.path.join(base_dir, d))
        ]

        if not conv_dirs:
            print(f"⚠️  No subdirectories in {base_dir}")
            return

        print(f"Found {len(conv_dirs)} conversations")
        print(f"Format: {output_format}")

        results = []
        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            futures = {
                executor.submit(
                    self._process_single_conv,
                    os.path.join(base_dir, d),
                    output_format,
                    output_name,
                ): d
                for d in conv_dirs
            }

            for future in tqdm(
                as_completed(futures), total=len(futures), desc="Rebuilding"
            ):
                results.append(future.result())

        success = [r for r in results if r["status"] == "success"]
        if success:
            total_nodes = sum(r["nodes"] for r in success)
            total_edges = sum(r["edges"] for r in success)
            print(f"\n✓ Rebuilt {len(success)} graphs")
            print(f"  Total nodes: {total_nodes}")
            print(f"  Total edges: {total_edges}")


# =============================================================================
# EMBEDDING WITH TIMESTAMP
# =============================================================================


class TimestampEmbedder:
    """Add embeddings with timestamps for various data types"""

    def __init__(
        self,
        embedding_model: str = "sentence-transformers/all-MiniLM-L6-v2",
        batch_size: int = 64,
    ):
        self.embedding_model = embedding_model
        self.batch_size = batch_size
        self.embedder = EmbeddingGenerator(model_name=embedding_model)

    def _build_segment_timestamp_map(self, segmented_dir: str) -> Dict[str, str]:
        """Build segment_id → timestamp mapping"""
        print("Building segment → timestamp mapping...")
        mapping = {}

        subdirs = [
            d
            for d in os.listdir(segmented_dir)
            if os.path.isdir(os.path.join(segmented_dir, d))
        ]

        for qid in tqdm(subdirs, desc="Loading timestamps"):
            seg_file = os.path.join(segmented_dir, qid, f"{qid}.json")
            if not os.path.exists(seg_file):
                continue

            try:
                data = load_json(seg_file)
                for chunk in data.get("chunks", []):
                    timestamp = chunk.get("timestamp", "")
                    for segment in chunk.get("segments", []):
                        mapping[segment["segment_hash_id"]] = timestamp
            except Exception as e:
                print(f"  ⚠️  Error: {e}")

        print(f"✓ Loaded {len(mapping)} timestamps")
        return mapping

    def embed_turns(self, base_dir: str, output_suffix: str = "_turns_embedded.parquet"):
        """Generate embeddings for turns"""
        print("=" * 60)
        print("EMBED TURNS")
        print("=" * 60)

        subdirs = [
            d for d in os.listdir(base_dir) if os.path.isdir(os.path.join(base_dir, d))
        ]

        for qid in tqdm(subdirs, desc="Processing"):
            turn_file = os.path.join(base_dir, qid, "turn_id_to_content.json")
            if not os.path.exists(turn_file):
                continue

            turn_data = load_json(turn_file)
            if not turn_data:
                continue

            df = pd.DataFrame(
                [
                    {"turn_id": tid, "content": content}
                    for tid, content in turn_data.items()
                ]
            )

            embeddings = self.embedder.embed_batch(
                df["content"].tolist(), batch_size=self.batch_size
            )
            df["embedding"] = embeddings

            output_path = os.path.join(base_dir, qid, f"{qid}{output_suffix}")
            df.to_parquet(output_path, index=False)

        print(f"✓ Completed embedding turns for {len(subdirs)} conversations")

    def embed_entities(
        self,
        entity_dir: str,
        segmented_dir: str,
        output_suffix: str = "_descriptions_embedded.parquet",
    ):
        """Generate embeddings with timestamp for entity descriptions"""
        print("=" * 60)
        print("EMBED ENTITIES WITH TIMESTAMP")
        print("=" * 60)

        segment_to_timestamp = self._build_segment_timestamp_map(segmented_dir)

        subdirs = [
            d
            for d in os.listdir(entity_dir)
            if os.path.isdir(os.path.join(entity_dir, d))
        ]

        for qid in tqdm(subdirs, desc="Processing"):
            desc_files = glob.glob(
                os.path.join(entity_dir, qid, "*_descriptions.json")
            )
            if not desc_files:
                continue

            all_descriptions = []
            for f in desc_files:
                try:
                    all_descriptions.extend(load_json(f))
                except:
                    pass

            if not all_descriptions:
                continue

            df_data = []
            for desc in all_descriptions:
                segment_id = desc["segment_id"]
                timestamp = segment_to_timestamp.get(segment_id, "")
                content = (
                    f"{timestamp} {desc['entity']}: {desc['description']}"
                    if timestamp
                    else f"{desc['entity']}: {desc['description']}"
                )
                df_data.append(
                    {
                        "entity_description_id": desc["entity_description_id"],
                        "entity": desc["entity"],
                        "description": desc["description"],
                        "timestamp": timestamp,
                        "content": content,
                        "turn_id": desc["turn_id"],
                        "segment_id": segment_id,
                    }
                )

            df = pd.DataFrame(df_data)
            embeddings = self.embedder.embed_batch(
                df["content"].tolist(), batch_size=self.batch_size
            )
            df["embedding"] = embeddings

            output_path = os.path.join(entity_dir, qid, f"{qid}{output_suffix}")
            df.to_parquet(output_path, index=False)

        print(f"✓ Completed embedding entities for {len(subdirs)} conversations")

    def embed_triplets(
        self,
        triplet_dir: str,
        segmented_dir: str,
        output_suffix: str = "_triplets_embedded.parquet",
    ):
        """Generate embeddings with timestamp for triplets"""
        print("=" * 60)
        print("EMBED TRIPLETS WITH TIMESTAMP")
        print("=" * 60)

        segment_to_timestamp = self._build_segment_timestamp_map(segmented_dir)

        subdirs = [
            d
            for d in os.listdir(triplet_dir)
            if os.path.isdir(os.path.join(triplet_dir, d))
        ]

        for qid in tqdm(subdirs, desc="Processing"):
            triplet_files = glob.glob(
                os.path.join(triplet_dir, qid, "*_triplets.json")
            )
            if not triplet_files:
                continue

            all_triplets = []
            for f in triplet_files:
                try:
                    data = load_json(f)
                    if isinstance(data, dict) and "triplets" in data:
                        all_triplets.extend(data["triplets"])
                    elif isinstance(data, list):
                        all_triplets.extend(data)
                except:
                    pass

            if not all_triplets:
                continue

            df_data = []
            for t in all_triplets:
                segment_id = t["segment_id"]
                timestamp = segment_to_timestamp.get(segment_id, "")
                content_raw = f"{t['entity1']} {t['relation']} {t['entity2']}"
                content = f"{timestamp} {content_raw}" if timestamp else content_raw
                df_data.append(
                    {
                        "triplet_id": t["triplet_id"],
                        "entity1": t["entity1"],
                        "relation": t["relation"],
                        "entity2": t["entity2"],
                        "timestamp": timestamp,
                        "content": content,
                        "turn_id": t["turn_id"],
                        "segment_id": segment_id,
                    }
                )

            df = pd.DataFrame(df_data)
            embeddings = self.embedder.embed_batch(
                df["content"].tolist(), batch_size=self.batch_size
            )
            df["embedding"] = embeddings

            output_path = os.path.join(triplet_dir, qid, f"{qid}{output_suffix}")
            df.to_parquet(output_path, index=False)

        print(f"✓ Completed embedding triplets for {len(subdirs)} conversations")

    def embed_summaries(
        self,
        summary_dir: str,
        output_suffix: str = "_summaries_embedded.parquet",
    ):
        """Generate embeddings for summaries"""
        print("=" * 60)
        print("EMBED SUMMARIES")
        print("=" * 60)

        subdirs = [
            d
            for d in os.listdir(summary_dir)
            if os.path.isdir(os.path.join(summary_dir, d))
        ]

        for qid in tqdm(subdirs, desc="Processing"):
            summary_files = glob.glob(
                os.path.join(summary_dir, qid, "*_summaries.json")
            )
            if not summary_files:
                continue

            all_summaries = []
            for f in summary_files:
                try:
                    data = load_json(f)
                    for chunk in data.get("chunks", []):
                        timestamp = chunk.get("timestamp", "")
                        for s in chunk.get("segment_summaries", []):
                            s["timestamp"] = timestamp
                            all_summaries.append(s)
                except:
                    pass

            if not all_summaries:
                continue

            df_data = []
            for s in all_summaries:
                timestamp = s.get("timestamp", "")
                content = (
                    f"{timestamp} {s['summary']}" if timestamp else s["summary"]
                )
                df_data.append(
                    {
                        "summary_hash_id": s["summary_hash_id"],
                        "segment_hash_id": s["segment_hash_id"],
                        "timestamp": timestamp,
                        "summary": s["summary"],
                        "content": content,
                    }
                )

            df = pd.DataFrame(df_data)
            embeddings = self.embedder.embed_batch(
                df["content"].tolist(), batch_size=self.batch_size
            )
            df["embedding"] = embeddings

            output_path = os.path.join(summary_dir, qid, f"{qid}{output_suffix}")
            df.to_parquet(output_path, index=False)

        print(f"✓ Completed embedding summaries for {len(subdirs)} conversations")

