"""
Message Filter - Selectively filter important messages from conversations
"""

import os
from typing import Dict, Any, List, Optional
from concurrent.futures import ThreadPoolExecutor, as_completed

from .base import BaseProcessor
from ..core import generate_hash_id, load_json, save_json, ensure_dir, path_exists
from ..core.utils import parse_json_from_response
from ..prompts import build_filter_prompt


class Filter(BaseProcessor):
    """
    Filter messages to keep only important ones for user profile building
    
    Input: Segmented JSON from Segmenter
    Output: Filtered JSON with selected messages
    """

    def filter_messages(self, messages: List[Dict[str, Any]]) -> Optional[List[int]]:
        """
        Filter messages using LLM

        Args:
            messages: List of message dicts

        Returns:
            List of indices to keep, or None if failed
        """
        prompt = build_filter_prompt(messages)
        system_prompt = "You are a helpful assistant that filters conversations. Return only a Python list of integers."

        try:
            response = self.llm.call(prompt, system_prompt=system_prompt, temperature=0)
            return parse_json_from_response(response)
        except Exception as e:
            print(f"Filter error: {e}")
            return None

    def process_segment(
        self,
        segment_data: Dict[str, Any],
        segment_hash_id: str,
    ) -> Optional[Dict[str, Any]]:
        """
        Process a single segment

        Args:
            segment_data: Segment data with messages
            segment_hash_id: Segment hash ID

        Returns:
            Filtered segment data or None
        """
        messages = segment_data["messages"]
        filtered_indices = self.filter_messages(messages)

        if not filtered_indices:
            return None

        # Build filtered messages with metadata
        filtered_messages = []
        for local_idx in filtered_indices:
            if local_idx < len(messages):
                msg = messages[local_idx]
                turn_number = msg["message_index"] // 2

                filtered_messages.append({
                    "message_id": generate_hash_id(
                        f"{segment_hash_id}_{msg['message_index']}_{msg['message_content']}",
                        prefix="msg-",
                    ),
                    "segment_hash_id": segment_hash_id,
                    "message_index_in_chunk": msg["message_index"],
                    "message_index_in_segment": local_idx,
                    "turn_in_segment": msg["turn_in_segment"],
                    "turn_in_chunk": turn_number,
                    "role": msg["role"],
                    "content": msg["message_content"],
                })

        return {
            "segment_hash_id": segment_hash_id,
            "filtered_message_count": len(filtered_messages),
            "filtered_messages": filtered_messages,
        }

    def process_single_file(
        self,
        qid: str,
        input_path: str,
        output_dir: str,
        skip_existing: bool = False,
        update: bool = False,
    ) -> Optional[Dict[str, Any]]:
        """Process a single segmented file"""
        # Setup output
        qid_output_dir = ensure_dir(os.path.join(output_dir, qid))

        # Load input
        data = load_json(input_path)
        question_id = data.get("question_id") or data.get("conv_id")
        chunks = data.get("chunks", [])

        output_path = os.path.join(qid_output_dir, f"{question_id}_filtered.json")

        existing_data = {}
        if path_exists(output_path):
            if skip_existing and not update:
                return None
            try:
                existing_data = load_json(output_path)
            except Exception:
                pass

        existing_chunk_map = {
            c.get("chunk_index"): c
            for c in existing_data.get("chunks", [])
            if isinstance(c, dict) and c.get("chunk_index") is not None
        } if existing_data else {}
        all_results = existing_data.get("chunks", []) if update and existing_data else []

        for chunk in chunks:
            chunk_index = chunk.get("chunk_index")
            if chunk_index in existing_chunk_map:
                existing_chunk = existing_chunk_map[chunk_index]
                has_filtered_segments = bool(existing_chunk.get("segments"))

                if skip_existing:
                    continue

                if update and has_filtered_segments:
                    continue

                if update:
                    all_results = [
                        c for c in all_results
                        if not (isinstance(c, dict) and c.get("chunk_index") == chunk_index)
                    ]

            chunk_hash_id = chunk.get("chunk_hash_id")
            timestamp = chunk.get("timestamp")
            segments = chunk.get("segments") or []

            if chunk_hash_id is None:
                continue

            chunk_result = {
                "chunk_hash_id": chunk_hash_id,
                "chunk_index": chunk_index,
                "timestamp": timestamp,
                "segments": [],
            }

            futures = {}
            with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
                for segment in segments:
                    segment_hash_id = segment.get("segment_hash_id")
                    if not segment_hash_id:
                        continue
                    futures[
                        executor.submit(self.process_segment, segment, segment_hash_id)
                    ] = segment_hash_id

                for future in as_completed(futures):
                    try:
                        result = future.result()
                        if result:
                            chunk_result["segments"].append(result)
                    except Exception as e:
                        print(f"Error filtering segment {futures[future]}: {e}")

            all_results.append(chunk_result)

        # Save output
        output_data = {
            "question_id": question_id,
            "chunks": all_results,
            "total_chunks": len(all_results),
        }
        save_json(output_path, output_data)

        return output_data

