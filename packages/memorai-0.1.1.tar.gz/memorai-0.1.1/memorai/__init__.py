"""
Memorai library: build a knowledge graph from conversations and retrieve with KG + embeddings.

The HTTP API lives in ``src.app.backend``; this package is the reusable core (similar in spirit to mem0).
"""

__version__ = "0.1.1"

from memorai.core import (
    EmbeddingGenerator,
    LLMClient,
    configure,
    ensure_dir,
    generate_hash_id,
    load_json,
    save_json,
    settings,
)
from memorai.exporters import MappingExporter, OutputConsolidator
from memorai.generator import AnswerGenerator, ContextBuilder
from memorai.processors import (
    EntityDescriptor,
    Filter,
    GraphBuilder,
    Segmenter,
    Summarizer,
    TripletExtractor,
)
from memorai.quick import create_conversation, index, retrieve, session_graph_path
from memorai.retriever import Neo4jRetriever

__all__ = [
    "AnswerGenerator",
    "ContextBuilder",
    "EmbeddingGenerator",
    "EntityDescriptor",
    "Filter",
    "GraphBuilder",
    "Neo4jRetriever",
    "index",
    "LLMClient",
    "configure",
    "MappingExporter",
    "OutputConsolidator",
    "Segmenter",
    "Summarizer",
    "TripletExtractor",
    "ensure_dir",
    "generate_hash_id",
    "load_json",
    "retrieve",
    "save_json",
    "session_graph_path",
    "create_conversation",
    "settings",
    "__version__",
]
