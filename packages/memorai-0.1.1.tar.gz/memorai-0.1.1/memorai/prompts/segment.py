"""
Prompt template for conversation segmentation
"""

from typing import List


def build_segment_prompt(messages: List[str]) -> str:
    """
    Build prompt for LLM to segment conversation by topic

    Args:
        messages: List of message strings (e.g., ["user: Hi", "assistant: Hello"])

    Returns:
        Formatted prompt string
    """
    numbered_messages = "\n".join(
        f"Message {i}: {msg}" for i, msg in enumerate(messages)
    )

    return f"""You are an expert conversation analyst. Your task is to group numbered messages of a conversation into semantically coherent segments based on their topic.
You must respond ONLY with a JSON list of lists. Each inner list must contain the integer indices of the messages that belong together in one topical segment. Return only a list.

### EXAMPLE
INPUT CONVERSATION:
Message 0: user: Hey, how are you?
Message 1: assistant: I'm good, thanks! Just finishing up some work.
Message 2: user: Speaking of work, did you see the email about the project deadline?
Message 3: assistant: Yeah, it's been moved to next Friday.
Message 4: user: Okay, that gives us more time. I'll update the project plan.
Message 5: assistant: Perfect, thanks.
Message 6: user: On a different note, are you free this weekend? I was thinking of going hiking.
Message 7: assistant: Oh, that sounds great! I'm free on Saturday.

REQUIRED OUTPUT:
[[0, 1, 2, 3, 4, 5], [6, 7]]

TASK
Now, process the following conversation and provide the output in the required JSON format.

INPUT CONVERSATION:
{numbered_messages}

REQUIRED OUTPUT:
"""

