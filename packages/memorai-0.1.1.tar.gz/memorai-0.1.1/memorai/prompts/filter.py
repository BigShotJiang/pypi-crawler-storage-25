"""
Prompt template for selective message filtering
"""

from typing import List, Dict, Any


def build_filter_prompt(messages: List[Dict[str, Any]]) -> str:
    """
    Build prompt for LLM to filter important messages

    Args:
        messages: List of message dicts with 'message_content' key

    Returns:
        Formatted prompt string
    """
    formatted_conv = "\n".join(
        f'Index {i}: "{msg["message_content"]}"' for i, msg in enumerate(messages)
    )

    return f"""CONTEXT
You are an expert Data Curator. Your goal is to filter a conversation to build a comprehensive User Profile (biographical facts, interests, experiences, plans, preferences, and conversational context).

TASK
You will receive a conversation transcript where each line is formatted as: `Index X: "role: content"`.

Analyze and return a JSON list of integers representing the indices of messages to KEEP.

FILTERING RULES

Rule 1: USER MESSAGES
- ALWAYS INCLUDE all messages with role "user"
- Every user statement contains valuable signals about their profile

Rule 2: ASSISTANT MESSAGES - Keep if ANY of these apply:

A. USER-SPECIFIC FACTS (Highest Priority)
   - Assistant mentions/confirms biographical data user stated (name, age, degree, job, location)
   - Assistant references user's possessions, achievements, or experiences user mentioned
   - Assistant acknowledges specific numbers/dates/names user provided
   Examples: "17 skeins", "$250 donation", "Business Administration degree", "met Alex twice"

B. CLARIFYING QUESTIONS
   - Assistant asks specific questions to understand user's situation better
   - Questions that help narrow down user's needs or preferences
   Example: "What's your running style?", "Which project specifically?"

C. PERSONALIZED RECOMMENDATIONS
   - Lists/suggestions that user explicitly requested
   - Advice tailored to user's stated situation or constraints
   - Rationale: If user later says "I liked option 2", we need to know what option 2 was
   Example: Movie recommendations user asked for, restaurant suggestions for their location

D. VALIDATION & ENGAGEMENT
   - Assistant repeats/validates specific details user shared (confirms accuracy)
   - Empathetic responses to user's personal stories that encourage sharing
   Example: "Congratulations on your degree!", "That's impressive you raised $250!"

Rule 3: ASSISTANT MESSAGES - Exclude if ALL of these apply:
- Pure general knowledge with NO connection to user's specific context
- Generic definitions, historical facts, or how-to instructions
- The information could apply to anyone, not specifically this user
- No reference to any detail the user previously mentioned

KEY PRINCIPLE
If an assistant message contains, references, or responds to information THE USER provided about themselves, KEEP IT. We prioritize capturing user context over filtering redundancy.

EXAMPLES

Example 1 - Keep Both (User fact + Validation):
Index 0: "user: I graduated with a degree in Business Administration"
Index 1: "assistant: Congratulations on your degree in Business Administration! Here are some tips..."
Output: [0, 1]
→ User stated their degree; assistant confirms this biographical fact

Example 2 - Keep User Only (Pure general knowledge):
Index 0: "user: What's the capital of France?"
Index 1: "assistant: The capital of France is Paris..."
Output: [0]
→ Generic fact with no user-specific context

Example 3 - Keep Both (User possession + Personalized advice):
Index 0: "user: I have 17 skeins of worsted weight yarn"
Index 1: "assistant: With 17 skeins of worsted weight yarn, you can make..."
Output: [0, 1]
→ Assistant references user's specific possession

Example 4 - Keep Both (User request + Requested list):
Index 0: "user: Recommend some Rom-Com movies"
Index 1: "assistant: Here are 5 Rom-Coms: 1. The Proposal, 2. Coda..."
Output: [0, 1]
→ User asked for list; needed if user later says "I liked #2"

Example 5 - Keep Both (Clarifying question):
Index 0: "user: I need running shoes"
Index 1: "assistant: What's your running style - neutral or pronated? What brand do you currently use?"
Output: [0, 1]
→ Questions help understand user's specific needs

Example 6 - Keep User Only (Generic instructions):
Index 0: "user: How do I bake bread?"
Index 1: "assistant: Here are bread baking steps: 1. Mix flour..."
Output: [0]
→ Generic how-to with no personalization

Example 7 - Keep Both (Tailored Instruction):
Index 0: "user: My [Specific Brand] coffee maker is clogged."
Index 1: "assistant: Since it's a [Specific Brand], you should hold the button for 3 seconds to descale..."
Output: [0, 1]
→ Instruction is tailored to the specific item user owns

YOUR TURN
Analyze the conversation below and return ONLY a Python list of integers.

Input Conversation:
{formatted_conv}

Output:
"""

