"""
Prompt template for entity description generation
"""

from typing import List


def build_entity_prompt(
    segment_content: str,
    turn_content: str,
    entities: List[str],
) -> str:
    """
    Build prompt for LLM to generate entity descriptions

    Args:
        segment_content: Full segment content for context
        turn_content: Specific turn content
        entities: List of entity names to describe

    Returns:
        Formatted prompt string
    """
    entity_list = "\n".join(f"- {e}" for e in entities)

    return f"""You are an expert entity descriptor. Generate concise descriptions for entities based on the conversation context.

CONTEXT HIERARCHY (from general to specific):

1. SEGMENT CONTENT (Overview):
{segment_content}

2. TURN CONTENT (Specific context):
{turn_content}

3. ENTITIES TO DESCRIBE:
{entity_list}

INSTRUCTIONS:
1. Generate ONE description per entity
2. Description should be based on information in the TURN and SEGMENT
3. Keep descriptions concise (1-2 sentences)
4. Focus on what is explicitly mentioned about the entity
5. Output format: entity|description
6. Each entity-description pair on a separate line
7. Use pipe (|) as separator
8. Generate descriptions for ALL entities listed above

OUTPUT FORMAT EXAMPLE:
John|A software engineer who works at Google
Google|A technology company that employs John
Mountain View|The location where Google is based

Now generate descriptions for the entities above. Output only entity|description pairs, one per line:"""


ENTITY_SYSTEM_PROMPT = "You are an expert entity descriptor. Always output descriptions in the exact format: entity|description"

