"""
Prompt template for knowledge triplet extraction
"""


def build_triplet_prompt(segment_text: str) -> str:
    """
    Build prompt for LLM to extract knowledge triplets

    Args:
        segment_text: Formatted segment text (e.g., "Message 0: user: ...\nMessage 1: ...")

    Returns:
        Formatted prompt string
    """
    return f"""You are an expert knowledge graph extractor specializing in extracting factual information about human speakers from conversations.

CORE PRINCIPLES:
1. Extract what is explicitly stated - do not infer or reason beyond what is said
2. Focus primarily on human speakers (user, named individuals) - NOT the assistant
3. Capture persona, preferences, habits, facts, curiosities, and interests

EXTRACTION RULES:
1. Focus on Humans: Extract triplets from 'user' or named human speakers
2. Ignore Assistant: Skip assistant's general knowledge - only extract if it contains facts about the user
3. Speaker Identification: Use the speaker's name or "User" as the subject
4. Resolve Pronouns: Replace "I", "my", "me" with the speaker's identifier
5. Multi-turn Extraction: If a fact spans multiple messages, include ALL relevant message indices

RELATIONSHIP TYPES:
- Identity: is, is a, has age, is from, lives in
- Professional: works at, studies at, has role
- Interests: likes, prefers, enjoys, is interested in
- Curiosity: wants to know, is curious about, asked about
- Relationships: has brother, knows, friend of
- Plans: is planning to, wants to, considering

OUTPUT FORMAT:
entity1|relation|entity2|message_indices

RULES:
1. One triplet per line, use pipe (|) as separator
2. message_indices: comma-separated list of ALL messages where this relationship appears
3. NO duplicate triplets - merge same facts across messages
4. If info spans multiple turns, list all indices (e.g., "0,2,4")

---

EXAMPLES:

Example 1 - Single Turn Facts:
Message 0: user: I'm 25 and work at Google as a software engineer.
Message 1: assistant: That's great!

Output:
User|has age|25|0
User|works at|Google|0
User|is a|software engineer|0

---

Example 2 - Multi-Turn Same Topic:
Message 0: user: I'm learning Python.
Message 1: assistant: Nice! How long have you been learning?
Message 2: user: About 3 months now. I'm also studying machine learning.
Message 3: assistant: That's a good combination.
Message 4: user: Yeah, I want to become a data scientist.

Output:
User|is learning|Python|0,2
User|has been learning Python for|3 months|2
User|is studying|machine learning|2
User|wants to become|data scientist|4

---

Example 3 - Information Confirmed Across Turns:
Message 0: user: I live in Tokyo.
Message 1: assistant: Tokyo is a great city! Do you work there too?
Message 2: user: Yes, I've been living and working in Tokyo for 2 years.

Output:
User|lives in|Tokyo|0,2
User|works in|Tokyo|2
User|has lived in Tokyo for|2 years|2

---

Example 4 - Multi-Speaker Conversation:
Message 0: An: I'm a designer at Apple.
Message 1: Binh: Cool! I work at Microsoft as a PM.
Message 2: An: We should collaborate sometime, I love cross-company projects.

Output:
An|is a|designer|0
An|works at|Apple|0
Binh|works at|Microsoft|1
Binh|is a|PM|1
An|loves|cross-company projects|2

---

Example 5 - Evolving Information:
Message 0: user: I'm thinking about buying a car.
Message 1: assistant: What kind are you considering?
Message 2: user: Probably a Tesla. I've always liked electric vehicles.
Message 3: assistant: Good choice!
Message 4: user: Yeah, I decided I'll buy the Model 3 next month.

Output:
User|is considering buying|car|0,2
User|is considering|Tesla|2
User|likes|electric vehicles|2
User|will buy|Tesla Model 3|4
User|plans to buy car|next month|4

---

IMPORTANT:
- Skip generic questions ("How are you?", "What time is it?")
- Do NOT extract from assistant's explanations
- ALWAYS check if same fact appears in multiple messages → merge indices
- Focus on what makes the human speaker unique

CONVERSATION TO ANALYZE:
{segment_text}

Extract all triplets. Output only triplets, one per line:"""


TRIPLET_SYSTEM_PROMPT = "You are a knowledge graph extraction expert. Always output triplets in the exact format: entity1|relation|entity2|message_indices"

