"""
Prompt templates for LLM tasks
"""

from .segment import build_segment_prompt
from .filter import build_filter_prompt
from .triplet import build_triplet_prompt
from .entity import build_entity_prompt
from .summary import build_summary_prompt

__all__ = [
    "build_segment_prompt",
    "build_filter_prompt",
    "build_triplet_prompt",
    "build_entity_prompt",
    "build_summary_prompt",
]

