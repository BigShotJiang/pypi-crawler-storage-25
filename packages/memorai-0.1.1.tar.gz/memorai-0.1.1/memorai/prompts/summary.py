"""
Prompt template for segment summarization
"""


def build_summary_prompt(segment_text: str) -> str:
    """
    Build prompt for LLM to summarize a conversation segment

    Args:
        segment_text: Full segment text to summarize

    Returns:
        Formatted prompt string
    """
    return f"""You are an expert conversation summarizer. Your task is to create a concise summary of the conversation segment below.

The summary should:
1. Capture the main topics discussed
2. Highlight key points and important information
3. Be clear and concise (4-6 sentences)
4. Maintain the context and flow of the conversation

CONVERSATION SEGMENT:
{segment_text}

Please provide a summary of this conversation segment:"""


SUMMARY_SYSTEM_PROMPT = "You are a helpful assistant that summarizes conversations concisely."

