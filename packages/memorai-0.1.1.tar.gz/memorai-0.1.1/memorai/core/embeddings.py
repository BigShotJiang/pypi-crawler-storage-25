"""
Embedding generation: local SentenceTransformer or Cloudflare Workers AI (bge-m3).
"""

import logging
from typing import List, Optional

from .config import settings
from .embedding_backend import create_embedding_model


logger = logging.getLogger(__name__)


class EmbeddingGenerator:
    """
    Generate embeddings using sentence-transformers
    
    Supports batch processing with progress bar.
    """

    def __init__(self, model_name: Optional[str] = None):
        """
        Initialize Embedding Generator

        Args:
            model_name: Model name (defaults to settings.embedding_model)
        """
        self.model_name = model_name or settings.embedding_model
        self._model = None

    @property
    def model(self):
        """Lazy load the model (local ST or Cloudflare)."""
        if self._model is None:
            self._model = create_embedding_model(
                self.model_name
                if settings.embedding_provider != "cloudflare"
                else None
            )
            label = (
                f"cloudflare/{settings.cloudflare_embedding_model}"
                if settings.embedding_provider == "cloudflare"
                else self.model_name
            )
            logger.info("Loaded embedding backend: %s", label)
        return self._model

    def embed(self, text: str) -> List[float]:
        """
        Generate embedding for single text

        Args:
            text: Text to embed

        Returns:
            Embedding vector as list of floats
        """
        embedding = self.model.encode(text, convert_to_numpy=True)
        return embedding.tolist()

    def embed_batch(
        self,
        texts: List[str],
        batch_size: int = 32,
        show_progress: bool = True,
    ) -> List[List[float]]:
        """
        Generate embeddings for batch of texts

        Args:
            texts: List of texts to embed
            batch_size: Batch size for processing
            show_progress: Show progress bar

        Returns:
            List of embedding vectors
        """
        if not texts:
            return []

        embeddings = self.model.encode(
            texts,
            batch_size=batch_size,
            show_progress_bar=show_progress,
            convert_to_numpy=True,
        )
        return embeddings.tolist()

