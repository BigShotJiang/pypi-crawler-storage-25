"""Hugging Face Hub: less noise when loading models (local or cached)."""

from __future__ import annotations

import logging
import warnings

_applied = False


def quiet_hf_hub_messages() -> None:
    """
    HF Hub logs a warning about unauthenticated requests when no ``HF_TOKEN`` is set.
    For local/offline models this is usually ignorable; this quiets that chatter.
    """
    global _applied
    if _applied:
        return
    _applied = True

    logging.getLogger("huggingface_hub").setLevel(logging.ERROR)
    logging.getLogger("transformers.tokenization_utils_base").setLevel(logging.ERROR)

    warnings.filterwarnings("ignore", message=r".*[Uu]nauthenticated requests.*")
    warnings.filterwarnings("ignore", message=r".*HF_TOKEN.*")
