"""Create local SentenceTransformer or Cloudflare embedding client (shared .encode API)."""

from __future__ import annotations

from typing import Any, Union

from .config import settings


def create_embedding_model(model_name: Union[str, None] = None) -> Any:
    """
    Model with ``.encode(texts, convert_to_numpy=True, batch_size=...)`` like SentenceTransformer.

    When ``EMBEDDING_PROVIDER=cloudflare``, uses Workers AI (no local weights).
    """
    if settings.embedding_provider == "cloudflare":
        if not settings.cloudflare_account_id or not settings.cloudflare_api_token:
            raise ValueError(
                "EMBEDDING_PROVIDER=cloudflare requires CLOUDFLARE_ACCOUNT_ID and "
                "CLOUDFLARE_API_TOKEN (or legacy ACCOUNT_ID / AUTH_TOKEN)"
            )
        from .cloudflare_embeddings import CloudflareEmbeddingModel

        mid = model_name or settings.cloudflare_embedding_model
        return CloudflareEmbeddingModel(
            settings.cloudflare_account_id,
            settings.cloudflare_api_token,
            mid,
        )

    from .hf_load import quiet_hf_hub_messages
    from sentence_transformers import SentenceTransformer

    quiet_hf_hub_messages()
    name = model_name or settings.embedding_model
    return SentenceTransformer(name)
