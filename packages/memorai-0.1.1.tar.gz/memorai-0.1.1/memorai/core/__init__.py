"""
Core modules: config, LLM client, embeddings, utilities
"""

from .config import settings, configure, reload_from_env
from .llm_client import LLMClient
from .embeddings import EmbeddingGenerator
from .utils import generate_hash_id, ensure_dir
from .storage import storage
from .scope import GLOBAL_SCOPE, normalize_scope_id, conversation_id_from_stage_path

load_json = storage.load_json
save_json = storage.save_json
path_exists = storage.exists

__all__ = [
    "settings",
    "configure",
    "reload_from_env",
    "LLMClient",
    "EmbeddingGenerator",
    "generate_hash_id",
    "load_json",
    "save_json",
    "ensure_dir",
    "path_exists",
    "storage",
    "GLOBAL_SCOPE",
    "normalize_scope_id",
    "conversation_id_from_stage_path",
]

