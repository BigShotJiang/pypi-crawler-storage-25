"""Filesystem paths for bundled assets (e.g. offline embedding weights)."""

from __future__ import annotations

import os
from pathlib import Path


def memorai_package_dir() -> Path:
    """Parent of ``memorai.core`` → the ``memorai/`` package directory."""
    return Path(__file__).resolve().parent.parent


def bundled_bge_m3_dir() -> Path:
    return memorai_package_dir() / "models" / "bge-m3"


def is_sentence_transformer_model_dir(path: Path) -> bool:
    """Heuristic: a local ST snapshot has config.json at the root."""
    return path.is_dir() and (path / "config.json").is_file()


def resolve_embedding_model() -> str:
    """
    If ``EMBEDDING_PROVIDER=cloudflare``, return Workers AI model id (metadata only).

    Otherwise (local):
    1. ``EMBEDDING_MODEL`` if set (non-empty).
    2. ``memorai/models/bge-m3`` if present (e.g. after ``download_model.sh``).
    3. ``BAAI/bge-m3`` on Hugging Face (downloads on first use).
    """
    provider = (os.getenv("EMBEDDING_PROVIDER") or "local").strip().lower()
    if provider == "cloudflare":
        mid = (os.getenv("CLOUDFLARE_EMBEDDING_MODEL") or "@cf/baai/bge-m3").strip()
        return mid

    raw = os.getenv("EMBEDDING_MODEL")
    if raw and raw.strip():
        return raw.strip()

    local = bundled_bge_m3_dir()
    if is_sentence_transformer_model_dir(local):
        return str(local.resolve())

    return "BAAI/bge-m3"
