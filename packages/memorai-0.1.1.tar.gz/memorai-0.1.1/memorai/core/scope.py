"""Scope helpers for conversation/session isolation in pipeline and retrieval."""

from __future__ import annotations

from pathlib import Path
from typing import Optional


GLOBAL_SCOPE = "GLOBAL"
_KNOWN_STAGE_DIRS = {
    "segmented",
    "filtered",
    "triplets",
    "entities",
    "summaries",
    "graphs",
    "mappings",
    "graph_db",
}


def normalize_scope_id(scope_id: Optional[str]) -> str:
    """Normalize empty scope IDs to GLOBAL."""
    value = (scope_id or "").strip()
    return value if value else GLOBAL_SCOPE


def conversation_id_from_stage_path(path: str) -> str:
    """
    Resolve conversation_id from pipeline stage paths.

    Expected patterns:
    - output/<conversation_id>/<stage>
    - output/<conversation_id>/<stage>/<qid>
    """
    p = Path(path).resolve()

    if p.name in _KNOWN_STAGE_DIRS:
        return normalize_scope_id(p.parent.name)

    parent = p.parent
    if parent.name in _KNOWN_STAGE_DIRS:
        return normalize_scope_id(parent.parent.name)

    # Fallback to nearest non-empty parent name for resilience.
    return normalize_scope_id(parent.name or p.name)
