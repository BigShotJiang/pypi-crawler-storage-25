import logging
from typing import Dict, Any, List, Optional
from .config import settings
from .scope import normalize_scope_id


logger = logging.getLogger(__name__)

class Neo4jClient:
    """Neo4j Client for pushing triplets and querying graphs."""

    def __init__(self):
        self.driver = None
        self.reconfigure()

    def _connect(self):
        if not self.uri:
            return
        try:
            from neo4j import GraphDatabase

            self.driver = GraphDatabase.driver(
                self.uri,
                auth=(self.user, self.password) if self.user else None,
            )
            self.driver.verify_connectivity()
            logger.info("Connected to Neo4j successfully")
            self._init_vector_indexes()
        except ImportError:
            logger.warning("neo4j driver not installed. Run `pip install neo4j`.")
        except Exception as e:
            logger.warning("Failed to connect to Neo4j: %s", e)

    def reconfigure(self):
        """Re-apply credentials from current settings and reconnect driver."""
        self.close()
        self.uri = settings.neo4j_uri
        self.user = settings.neo4j_user
        self.password = settings.neo4j_password
        self.driver = None
        self._connect()

    def _init_vector_indexes(self):
        """Create vector indexes for Entity and Segment if they don't exist"""
        if not self.driver: return
        dimension = 1024 
        # Using native vector indexes correctly.
        queries = [
            f"CREATE VECTOR INDEX entity_emb IF NOT EXISTS FOR (e:Entity) ON (e.embedding) OPTIONS {{indexConfig: {{`vector.dimensions`: {dimension}, `vector.similarity_function`: 'cosine'}}}}",
            f"CREATE VECTOR INDEX segment_emb IF NOT EXISTS FOR (s:Segment) ON (s.embedding) OPTIONS {{indexConfig: {{`vector.dimensions`: {dimension}, `vector.similarity_function`: 'cosine'}}}}"
        ]
        with self.driver.session() as session:
            for q in queries:
                try:
                    session.run(q)
                except Exception as e:
                    logger.debug("Skipping vector index init query due to error: %s", e)

    def close(self):
        """Close driver connection"""
        if self.driver:
            self.driver.close()
            self.driver = None

    def merge_triplets(self, triplets: List[Dict[str, Any]], session_id: Optional[str] = None) -> None:
        """
        Merge a batch of triplets directly into Neo4j.
        Nodes: Entity, Turn, Segment, Session
        Edges: Entity->Entity, Entity->Turn, Entity->Segment, Turn->Segment, Segment->Session
        """
        if not self.driver:
            logger.warning("Neo4j driver not initialized. Cannot push triplets.")
            return

        scope_id = normalize_scope_id(session_id)

        query = """
        // Create/Merge Session if provided
        WITH $scope_id AS sid, $triplets AS triplets
        MERGE (snode:Session {id: sid})
        
        WITH snode, triplets, sid
        UNWIND triplets AS trip
        
        // Merge Entities with session_id isolated
        MERGE (e1:Entity {name: trip.entity1, session_id: sid})
        MERGE (e2:Entity {name: trip.entity2, session_id: sid})
        
        // Merge Turn and Segment isolated by session_id
        MERGE (t:Turn {id: trip.turn_id, session_id: sid})
        MERGE (s:Segment {id: trip.segment_id, session_id: sid})
        
        // Merge Relationships -> Entity to Entity
        MERGE (e1)-[rel:RELATION {name: trip.relation}]->(e2)
        ON CREATE SET rel.triplet_id = trip.triplet_id
        
        // Connect to Turn & Segment
        MERGE (e1)-[:MENTIONED_IN]->(t)
        MERGE (e2)-[:MENTIONED_IN]->(t)
        MERGE (t)-[:BELONGS_TO]->(s)

        // Connect Segment to Session
        MERGE (s)-[:PART_OF_SESSION]->(snode)
        """

        with self.driver.session() as session:
            try:
                session.run(query, triplets=triplets, scope_id=scope_id)
            except Exception as e:
                logger.exception("Error merging triplets to Neo4j: %s", e)

    def merge_entities(self, entities: List[Dict[str, Any]], session_id: Optional[str] = None) -> None:
        """Merge entity descriptions and embeddings into Neo4j"""
        if not self.driver: return
        scope_id = normalize_scope_id(session_id)
        query = """
        UNWIND $entities AS ent
        MERGE (e:Entity {name: ent.entity, session_id: $scope_id})
        SET e.description = ent.description, e.embedding = ent.embedding
        """
        with self.driver.session() as session:
            try:
                session.run(query, entities=entities, scope_id=scope_id)
            except Exception as e:
                logger.exception("Error merging entities: %s", e)

    def merge_summaries(self, summaries: List[Dict[str, Any]], session_id: Optional[str] = None) -> None:
        """Merge segment summaries and embeddings into Neo4j"""
        if not self.driver: return
        scope_id = normalize_scope_id(session_id)
        query = """
        UNWIND $summaries AS s
        MERGE (seg:Segment {id: s.segment_id, session_id: $scope_id})
        SET seg.summary = s.summary, seg.embedding = s.embedding
        """
        with self.driver.session() as session:
            try:
                session.run(query, summaries=summaries, scope_id=scope_id)
            except Exception as e:
                logger.exception("Error merging summaries: %s", e)

    def test_query(self):
        if not self.driver: return None
        with self.driver.session() as session:
            result = session.run("MATCH (n) RETURN count(n) AS count")
            return result.single()["count"]

# Global Instance
neo4j_client = Neo4jClient()
