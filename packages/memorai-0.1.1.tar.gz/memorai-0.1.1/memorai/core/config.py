"""
Configuration management - Load settings from environment variables (library / pipeline).
"""

import os
import logging
from dataclasses import dataclass
from typing import Any, Dict
from dotenv import load_dotenv

from .paths import resolve_embedding_model

load_dotenv()

logger = logging.getLogger(__name__)

ENV_TO_FIELD = {
    "LLM_API_KEY": "llm_api_key",
    "LLM_BASE_URL": "llm_base_url",
    "LLM_MODEL": "llm_model",
    "LLM_PROVIDER": "llm_provider",
    "EMBEDDING_PROVIDER": "embedding_provider",
    "EMBEDDING_MODEL": "embedding_model",
    "CLOUDFLARE_ACCOUNT_ID": "cloudflare_account_id",
    "ACCOUNT_ID": "cloudflare_account_id",
    "CLOUDFLARE_API_TOKEN": "cloudflare_api_token",
    "AUTH_TOKEN": "cloudflare_api_token",
    "CLOUDFLARE_EMBEDDING_MODEL": "cloudflare_embedding_model",
    "MAX_WORKERS": "max_workers",
    "RPM_LIMIT": "rpm_limit",
    "TIMEOUT": "timeout",
    "NEO4J_URI": "neo4j_uri",
    "NEO4J_USER": "neo4j_user",
    "NEO4J_USERNAME": "neo4j_user",
    "NEO4J_PASSWORD": "neo4j_password",
    "MEMORAI_DATA_DIR": "data_dir",
}

INT_FIELDS = {"max_workers", "rpm_limit", "timeout"}


def _strip_env(name: str, default: str = "") -> str:
    v = os.getenv(name, default) or ""
    return v.strip().strip('"')


def _normalize_overrides(overrides: Dict[str, Any]) -> Dict[str, Any]:
    normalized: Dict[str, Any] = {}
    for key, value in overrides.items():
        if key in ENV_TO_FIELD:
            field = ENV_TO_FIELD[key]
        elif key.lower() in Settings.__annotations__:
            field = key.lower()
        else:
            field = key
        normalized[field] = value
    return normalized


def _coerce_value(field: str, value: Any) -> Any:
    if value is None:
        return value
    if field in INT_FIELDS:
        return int(value)
    if isinstance(value, str):
        return value.strip().strip('"')
    return value


@dataclass
class Settings:
    """Pipeline and LLM settings from environment variables."""

    llm_api_key: str
    llm_base_url: str
    llm_model: str
    llm_provider: str
    embedding_provider: str
    embedding_model: str
    cloudflare_account_id: str
    cloudflare_api_token: str
    cloudflare_embedding_model: str
    max_workers: int
    rpm_limit: int
    timeout: int
    neo4j_uri: str
    neo4j_user: str
    neo4j_password: str
    data_dir: str

    @classmethod
    def from_env(cls) -> "Settings":
        provider = _strip_env("EMBEDDING_PROVIDER", "local").lower() or "local"
        return cls(
            llm_api_key=os.getenv("LLM_API_KEY", ""),
            llm_base_url=os.getenv("LLM_BASE_URL", "https://api.openai.com/v1"),
            llm_model=os.getenv("LLM_MODEL", "gpt-4o-mini"),
            llm_provider=os.getenv("LLM_PROVIDER", "openai"),
            embedding_provider=provider,
            embedding_model=resolve_embedding_model(),
            cloudflare_account_id=_strip_env("CLOUDFLARE_ACCOUNT_ID")
            or _strip_env("ACCOUNT_ID"),
            cloudflare_api_token=_strip_env("CLOUDFLARE_API_TOKEN")
            or _strip_env("AUTH_TOKEN"),
            cloudflare_embedding_model=_strip_env(
                "CLOUDFLARE_EMBEDDING_MODEL", "@cf/baai/bge-m3"
            ),
            max_workers=int(os.getenv("MAX_WORKERS", "10")),
            rpm_limit=int(os.getenv("RPM_LIMIT", "60")),
            timeout=int(os.getenv("TIMEOUT", "60")),
            neo4j_uri=os.getenv("NEO4J_URI", ""),
            neo4j_user=os.getenv("NEO4J_USER", os.getenv("NEO4J_USERNAME", "")),
            neo4j_password=os.getenv("NEO4J_PASSWORD", ""),
            data_dir=os.getenv("MEMORAI_DATA_DIR", ""),
        )

    def validate(self) -> bool:
        if not self.llm_api_key:
            raise ValueError("LLM_API_KEY environment variable is required")
        return True


def _refresh_runtime_components() -> None:
    """
    Refresh singleton-like components so runtime config updates are applied
    without restarting the process.
    """
    try:
        from .neo4j_client import neo4j_client

        neo4j_client.reconfigure()
    except Exception as exc:
        logger.debug("Neo4j client refresh skipped: %s", exc)

    try:
        from .storage import storage

        storage.refresh()
    except Exception as exc:
        logger.debug("Storage refresh skipped: %s", exc)


def configure(**kwargs: Any) -> Settings:
    """
    Configure MemOrai settings at runtime.

    Accepts both dataclass field names (e.g. ``llm_api_key``) and
    env-style names (e.g. ``LLM_API_KEY``).
    """
    normalized = _normalize_overrides(kwargs)
    unknown = [k for k in normalized if k not in Settings.__annotations__]
    if unknown:
        allowed = ", ".join(sorted(Settings.__annotations__.keys()))
        raise ValueError(
            f"Unknown configure keys: {', '.join(sorted(unknown))}. "
            f"Allowed keys: {allowed}"
        )

    for field, value in normalized.items():
        setattr(settings, field, _coerce_value(field, value))

    # Keep provider normalized for downstream checks.
    settings.llm_provider = (settings.llm_provider or "openai").strip().lower()
    settings.embedding_provider = (settings.embedding_provider or "local").strip().lower()

    _refresh_runtime_components()
    return settings


def reload_from_env() -> Settings:
    """Reload settings from environment variables and refresh runtime components."""
    updated = Settings.from_env()
    for field in Settings.__annotations__:
        setattr(settings, field, getattr(updated, field))
    _refresh_runtime_components()
    return settings


settings = Settings.from_env()
