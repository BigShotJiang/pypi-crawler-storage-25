"""
Utility functions for the pipeline
"""

import os
import re
import ast
import json
import hashlib
from typing import Any, Dict, List, Optional, Tuple


PARSE_EXCEPTIONS = (ValueError, SyntaxError, json.JSONDecodeError)


def generate_hash_id(content: str, prefix: str = "") -> str:
    """
    Generate hash ID with optional prefix

    Args:
        content: Content to hash
        prefix: Prefix for the hash ID (e.g., "chunk-", "seg-", "turn-", "triplet-")

    Returns:
        Hash ID string with prefix
    """
    hash_obj = hashlib.md5(content.encode())
    hash_str = hash_obj.hexdigest()

    if prefix:
        return f"{prefix}{hash_str}"
    return hash_str


def load_json(file_path: str) -> Any:
    """Load JSON file"""
    with open(file_path, "r", encoding="utf-8") as f:
        return json.load(f)


def save_json(file_path: str, data: Any, indent: int = 2) -> None:
    """Save data to JSON file"""
    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=indent)


def ensure_dir(dir_path: str) -> str:
    """Ensure directory exists, create if not"""
    os.makedirs(dir_path, exist_ok=True)
    return dir_path


def strip_code_fences(s: str) -> str:
    """Remove markdown code fences from string"""
    s = s.strip()
    if s.startswith("```"):
        s = s.strip("`")
        if "\n" in s:
            s = s.split("\n", 1)[1]
    if s.endswith("```"):
        s = s.rsplit("```", 1)[0]
    return s.strip()


def parse_json_from_response(response_text: str) -> Any:
    """
    Parse JSON from LLM response, handling code fences and various formats

    Args:
        response_text: Raw LLM response

    Returns:
        Parsed JSON data
    """
    # Try direct parse
    try:
        return ast.literal_eval(response_text)
    except PARSE_EXCEPTIONS:
        pass

    # Try after stripping code fences
    try:
        s = strip_code_fences(response_text)
        return ast.literal_eval(s)
    except PARSE_EXCEPTIONS:
        pass

    # Try extracting JSON array
    m = re.search(r"\[[\s\S]*\]", response_text)
    if m:
        try:
            return ast.literal_eval(m.group(0))
        except PARSE_EXCEPTIONS:
            pass

    # Try extracting JSON object
    m = re.search(r"\{[\s\S]*\}", response_text)
    if m:
        try:
            return json.loads(m.group(0))
        except PARSE_EXCEPTIONS:
            pass

    raise ValueError(f"Could not parse JSON from response: {response_text[:200]}...")


# Speaker pairs for auto-detection
SPEAKER_PAIRS = [
    ("user", "assistant"),
    ("Caroline", "Melanie"),
    ("Gina", "Jon"),
    ("Maria", "John"),
    ("Nate", "Joanna"),
    ("John", "Tim"),
    ("Audrey", "Andrew"),
    ("John", "James"),
    ("Deborah", "Jolene"),
    ("Sam", "Evan"),
    ("Calvin", "Dave"),
]


def detect_speaker_pair(conversation_text: str) -> Optional[Tuple[str, str]]:
    """
    Auto-detect which speaker pair is used in the conversation

    Args:
        conversation_text: The conversation text to analyze

    Returns:
        Tuple of (speaker1, speaker2) if found, None otherwise
    """
    text_lower = conversation_text.lower()

    for speaker1, speaker2 in SPEAKER_PAIRS:
        pattern1 = f"{re.escape(speaker1)}:".lower()
        pattern2 = f"{re.escape(speaker2)}:".lower()

        if re.search(pattern1, text_lower) and re.search(pattern2, text_lower):
            return (speaker1, speaker2)

    return None


def split_conversation(
    conversation_text: str, speaker1_name: str, speaker2_name: str
) -> Tuple[Optional[str], List[str]]:
    """
    Split conversation into timestamp and individual messages

    Args:
        conversation_text: Full conversation text
        speaker1_name: First speaker name
        speaker2_name: Second speaker name

    Returns:
        Tuple of (timestamp, list of messages)
    """
    pattern = f"({re.escape(speaker1_name)}:|{re.escape(speaker2_name)}:)"
    parts = re.split(pattern, conversation_text, flags=re.IGNORECASE)
    cleaned_parts = [part.strip() for part in parts if part and not part.isspace()]

    timestamp = None
    start_index = 0
    if cleaned_parts and not cleaned_parts[0].endswith(":"):
        timestamp = cleaned_parts[0]
        start_index = 1

    messages = []
    i = start_index
    while i < len(cleaned_parts):
        if i + 1 < len(cleaned_parts):
            message = f"{cleaned_parts[i]} {cleaned_parts[i + 1]}"
            messages.append(message)
            i += 2
        else:
            i += 1

    return timestamp, messages

