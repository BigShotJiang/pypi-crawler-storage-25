"""Cloudflare Workers AI embeddings (@cf/baai/bge-m3) — no local SentenceTransformer."""

from __future__ import annotations

import json
import time
import urllib.error
import urllib.request
from typing import List, Sequence, Union

import numpy as np

DEFAULT_MODEL = "@cf/baai/bge-m3"


def _parse_vectors(payload: dict) -> List[List[float]]:
    if payload.get("success") is False:
        errs = payload.get("errors") or payload
        raise RuntimeError(f"Cloudflare AI error: {errs}")
    res = payload.get("result")
    if res is None:
        raise ValueError(f"Cloudflare response missing result: {payload.keys()}")
    if isinstance(res, list):
        if res and isinstance(res[0], (int, float)):
            return [list(map(float, res))]
        return [list(map(float, row)) for row in res]
    if isinstance(res, dict):
        data = res.get("data")
        if data is None:
            raise ValueError(f"Unexpected Cloudflare result shape: {res.keys()}")
        if isinstance(data, list) and data and isinstance(data[0], (int, float)):
            return [list(map(float, data))]
        return [list(map(float, row)) for row in data]
    raise ValueError(f"Unexpected Cloudflare result type: {type(res)}")


class CloudflareEmbeddingModel:
    """
    Drop-in for ``SentenceTransformer.encode`` used by KGRetriever / EmbeddingGenerator.

    API: https://developers.cloudflare.com/workers-ai/models/bge-m3/
    """

    def __init__(self, account_id: str, api_token: str, model: str = DEFAULT_MODEL):
        if not account_id or not api_token:
            raise ValueError("Cloudflare account_id and api_token are required")
        self.model_name = model
        self._url = (
            f"https://api.cloudflare.com/client/v4/accounts/{account_id}/ai/run/{model}"
        )
        self._headers = {
            "Authorization": f"Bearer {api_token}",
            "Content-Type": "application/json",
        }

    def encode(
        self,
        sentences: Union[str, Sequence[str]],
        convert_to_numpy: bool = True,
        batch_size: int = 32,
        show_progress_bar: bool = False,
        **kwargs,
    ):
        del show_progress_bar  # API-side batching only
        if isinstance(sentences, str):
            texts = [sentences]
            single = True
        else:
            texts = list(sentences)
            single = False

        if not texts:
            empty = np.zeros((0, 0), dtype=np.float32)
            return empty if convert_to_numpy else []

        all_vecs: List[List[float]] = []
        bs = max(1, min(batch_size, 100))

        for i in range(0, len(texts), bs):
            chunk = texts[i : i + bs]
            body = json.dumps({"text": chunk}).encode("utf-8")
            req = urllib.request.Request(
                self._url, data=body, headers=self._headers, method="POST"
            )
            try:
                with urllib.request.urlopen(req, timeout=120) as resp:
                    payload = json.loads(resp.read().decode("utf-8"))
            except urllib.error.HTTPError as e:
                detail = e.read().decode("utf-8", errors="replace") if e.fp else ""
                raise RuntimeError(
                    f"Cloudflare Workers AI HTTP {e.code}: {detail}"
                ) from e

            vecs = _parse_vectors(payload)
            if len(vecs) != len(chunk):
                raise ValueError(
                    f"Cloudflare returned {len(vecs)} vectors for {len(chunk)} texts"
                )
            all_vecs.extend(vecs)
            if i + bs < len(texts):
                time.sleep(0.05)

        arr = np.asarray(all_vecs, dtype=np.float32)
        if single:
            arr = arr[0]
        if convert_to_numpy:
            return arr
        return arr.tolist() if arr.ndim == 1 else arr.tolist()
