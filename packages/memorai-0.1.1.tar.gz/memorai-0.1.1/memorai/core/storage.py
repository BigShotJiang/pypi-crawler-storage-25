import os
import json
import logging
from typing import Any, List, Optional
from pathlib import Path

from .config import settings
from .utils import load_json, save_json


logger = logging.getLogger(__name__)

class StorageBackend:
    """Unified storage backend for MemOrai (Local Disk OR Neo4j)"""

    def __init__(self):
        self.client = None
        self.use_neo4j = False
        self.refresh()

    def refresh(self):
        """Refresh backend mode based on current runtime settings."""
        self.use_neo4j = bool(settings.neo4j_uri)
        self.client = None

        if self.use_neo4j:
            try:
                from .neo4j_client import neo4j_client

                self.client = neo4j_client
                if not self.client.driver:
                    self.use_neo4j = False
            except Exception as e:
                logger.warning(
                    "Failed to init Neo4j storage (%s). Falling back to local storage.",
                    e,
                )
                self.use_neo4j = False

    def _is_managed(self, file_path: str) -> bool:
        """Check if the path belongs to a managed pipeline step"""
        managed_steps = {"segmented", "filtered", "triplets", "descriptions", "summaries", "consolidated", "mappings"}
        path_obj = Path(file_path)
        # Check if any parent is a managed step
        for part in path_obj.parts:
            if part in managed_steps:
                return True
        return False

    def _parse_path(self, file_path: str) -> tuple[str, str]:
        """Extract collection and document ID from a local filepath"""
        path_obj = Path(file_path)
        qid = path_obj.stem
        if '_' in qid:
            raw_qid = qid.split('_', 1)[0]
        else:
            raw_qid = qid
            
        # Collection is the managed step name
        managed_steps = {"segmented", "filtered", "triplets", "descriptions", "summaries", "consolidated", "mappings"}
        collection = "unknown"
        for part in reversed(path_obj.parts):
            if part in managed_steps:
                collection = part
                break
        
        return collection, raw_qid

    def load_json(self, file_path: str) -> Any:
        """Seamless replacement for load_json"""
        if self.use_neo4j and self._is_managed(file_path):
            collection, qid = self._parse_path(file_path)
            prop_name = f"{collection}_data"
            
            query = f"MATCH (s:MemOraiSession {{id: $qid}}) RETURN s.{prop_name} AS data"
            with self.client.driver.session() as session:
                res = session.run(query, qid=qid)
                record = res.single()
                if record and record["data"]:
                    return json.loads(record["data"])
                    
            raise FileNotFoundError(f"Missing {qid} in {collection} (Neo4j)")
        else:
            return load_json(file_path)

    def save_json(self, file_path: str, data: Any, indent: int = 2) -> None:
        """Seamless replacement for save_json"""
        if self.use_neo4j and self._is_managed(file_path):
            collection, qid = self._parse_path(file_path)
            prop_name = f"{collection}_data"
            json_str = json.dumps(data)
            
            query = f"MERGE (s:MemOraiSession {{id: $qid}}) SET s.{prop_name} = $json_str"
            with self.client.driver.session() as session:
                session.run(query, qid=qid, json_str=json_str)
        else:
            save_json(file_path, data, indent)

    def exists(self, file_path: str) -> bool:
        """Check if file or document exists"""
        if self.use_neo4j and self._is_managed(file_path):
            collection, qid = self._parse_path(file_path)
            prop_name = f"{collection}_data"
            
            query = f"MATCH (s:MemOraiSession {{id: $qid}}) WHERE s.{prop_name} IS NOT NULL RETURN count(s) AS count"
            with self.client.driver.session() as session:
                res = session.run(query, qid=qid)
                return res.single()["count"] > 0
        else:
            return os.path.exists(file_path)

    def scan_input_files(self, input_dir: str, pattern: str = "*.json") -> List[tuple[str, str]]:
        """Seamless replacement for BaseProcessor.scan_input_files"""
        if self.use_neo4j and self._is_managed(input_dir):
            files_to_process = []
            collection = "unknown"
            managed_steps = {"segmented", "filtered", "triplets", "descriptions", "summaries", "consolidated", "mappings"}
            for part in reversed(Path(input_dir).parts):
                if part in managed_steps:
                    collection = part
                    break
            
            prop_name = f"{collection}_data"
            query = f"MATCH (s:MemOraiSession) WHERE s.{prop_name} IS NOT NULL RETURN s.id AS qid"
            with self.client.driver.session() as session:
                res = session.run(query)
                for record in res:
                    qid = record["qid"]
                    fake_path = os.path.join(input_dir, qid, f"{qid}.json")
                    files_to_process.append((qid, fake_path))
            return files_to_process
        else:
            # Standard local scanning
            files_to_process = []
            if not os.path.exists(input_dir):
                return []
            subdirs = [d for d in os.listdir(input_dir) if os.path.isdir(os.path.join(input_dir, d))]
            for qid in subdirs:
                qid_dir = os.path.join(input_dir, qid)
                import glob
                json_files = glob.glob(os.path.join(qid_dir, pattern))
                for json_file in json_files:
                    files_to_process.append((qid, json_file))
        return files_to_process

storage = StorageBackend()
