"""
Answer Generator - Generate answers using LLM with retrieved context
"""

from typing import Dict, List, Optional

from ..core.config import settings
from ..core.llm_client import LLMClient
from .context_builder import ContextBuilder


SYSTEM_PROMPT = """You are a helpful assistant that answers questions based on conversation history.

Your task is to answer the user's question using ONLY the provided context from past conversations.

Rules:
1. Answer based ONLY on the provided context
2. If the context doesn't contain enough information, say "I don't have enough information to answer this question"
3. Be concise and direct
4. Quote relevant parts when helpful
5. If there are multiple relevant pieces of information, synthesize them into a coherent answer"""

USER_PROMPT_TEMPLATE = """Context from conversation history:
{context}

Question: {question}

Please answer the question based on the context above."""


class AnswerGenerator:
    """
    Generate answers using LLM with retrieved context
    
    Uses single API key from Config (no key rotation)
    """

    def __init__(
        self,
        llm_client: Optional[LLMClient] = None,
        context_builder: Optional[ContextBuilder] = None,
        system_prompt: str = SYSTEM_PROMPT,
        max_context_chars: int = 8000,
        temperature: float = 0.1,
    ):
        """
        Initialize Answer Generator

        Args:
            llm_client: LLM client (creates new one if not provided)
            context_builder: Context builder (creates new one if not provided)
            system_prompt: System prompt for LLM
            max_context_chars: Maximum characters in context
            temperature: LLM temperature
        """
        self.llm = llm_client or LLMClient()
        self.context_builder = context_builder or ContextBuilder()
        self.system_prompt = system_prompt
        self.max_context_chars = max_context_chars
        self.temperature = temperature

    def generate(
        self,
        question: str,
        context: str,
        system_prompt: Optional[str] = None,
    ) -> str:
        """
        Generate answer for question given context

        Args:
            question: User question
            context: Context string (from ContextBuilder)
            system_prompt: Optional override for system prompt

        Returns:
            Generated answer
        """
        # Truncate context if too long
        if len(context) > self.max_context_chars:
            context = context[: self.max_context_chars] + "\n... (truncated)"

        # Build user prompt
        user_prompt = USER_PROMPT_TEMPLATE.format(
            context=context,
            question=question,
        )

        # Call LLM with prompt and system_prompt
        answer = self.llm.call(
            prompt=user_prompt,
            system_prompt=system_prompt or self.system_prompt,
            temperature=self.temperature,
        )
        return answer

    def generate_from_retrieval(
        self,
        question: str,
        retrieval_result: Dict,
        triplet_df=None,
        turn_df=None,
    ) -> Dict:
        """
        Generate answer from KGRetriever output

        Args:
            question: User question
            retrieval_result: Output from KGRetriever.retrieve()
            triplet_df: Optional triplet DataFrame
            turn_df: Optional turn DataFrame

        Returns:
            Dict with answer and metadata
        """
        # Build context
        context = self.context_builder.build_from_retrieval(
            retrieval_result,
            triplet_df=triplet_df,
            turn_df=turn_df,
        )

        # Generate answer
        answer = self.generate(question, context)

        return {
            "question": question,
            "answer": answer,
            "context": context,
            "num_turns": len(retrieval_result.get("results", {}).get("turn", [])),
            "num_triplets": len(retrieval_result.get("triplets", [])),
        }

    def generate_batch(
        self,
        questions: List[str],
        contexts: List[str],
        verbose: bool = True,
    ) -> List[Dict]:
        """
        Generate answers for multiple questions

        Args:
            questions: List of questions
            contexts: List of context strings
            verbose: Print progress

        Returns:
            List of result dicts
        """
        results = []

        for i, (question, context) in enumerate(zip(questions, contexts)):
            if verbose:
                print(f"[{i+1}/{len(questions)}] {question[:50]}...")

            try:
                answer = self.generate(question, context)
                results.append({
                    "question": question,
                    "answer": answer,
                    "success": True,
                    "error": None,
                })
            except Exception as e:
                results.append({
                    "question": question,
                    "answer": None,
                    "success": False,
                    "error": str(e),
                })

        return results


class QAPipeline:
    """
    End-to-end QA Pipeline: Query → Retrieve → Generate
    """

    def __init__(
        self,
        retriever,  # KGRetriever
        generator: Optional[AnswerGenerator] = None,
    ):
        """
        Initialize QA Pipeline

        Args:
            retriever: KGRetriever instance
            generator: AnswerGenerator instance (creates new one if not provided)
        """
        self.retriever = retriever
        self.generator = generator or AnswerGenerator()

    def answer(self, question: str, verbose: bool = False) -> Dict:
        """
        Answer question using retrieval + generation

        Args:
            question: User question
            verbose: Print progress

        Returns:
            Dict with answer and metadata
        """
        if verbose:
            print(f"Question: {question}")
            print("Retrieving...")

        # Retrieve
        retrieval_result = self.retriever.retrieve(question)

        if verbose:
            results = retrieval_result["results"]
            print(f"  Found: {len(results.get('turn', []))} turns, "
                  f"{len(results.get('segment', []))} segments")

        # Generate
        if verbose:
            print("Generating answer...")

        result = self.generator.generate_from_retrieval(
            question=question,
            retrieval_result=retrieval_result,
            triplet_df=self.retriever.triplet_df,
            turn_df=self.retriever.turn_df,
        )

        # Add retrieval info
        result["retrieval"] = {
            "turns": retrieval_result["results"].get("turn", []),
            "segments": retrieval_result["results"].get("segment", []),
            "entities": retrieval_result["results"].get("entity", []),
            "subgraph_info": retrieval_result.get("subgraph_info", {}),
        }

        if verbose:
            print(f"Answer: {result['answer'][:200]}...")

        return result

    def answer_batch(
        self,
        questions: List[str],
        verbose: bool = True,
    ) -> List[Dict]:
        """
        Answer multiple questions

        Args:
            questions: List of questions
            verbose: Print progress

        Returns:
            List of result dicts
        """
        results = []

        for i, question in enumerate(questions):
            if verbose:
                print(f"\n[{i+1}/{len(questions)}] {question[:50]}...")

            try:
                result = self.answer(question, verbose=False)
                result["success"] = True
                result["error"] = None
            except Exception as e:
                result = {
                    "question": question,
                    "answer": None,
                    "success": False,
                    "error": str(e),
                }

            results.append(result)

        return results

