"""
Context Builder - Build context from retrieved turns and triplets
"""

from typing import Dict, List, Optional
import pandas as pd


class ContextBuilder:
    """
    Build context string from retrieved turns and their associated triplets
    """

    def __init__(
        self,
        max_turns: int = 10,
        max_triplets_per_turn: int = 20,
        include_timestamps: bool = True,
    ):
        """
        Initialize Context Builder

        Args:
            max_turns: Maximum number of turns to include
            max_triplets_per_turn: Maximum triplets per turn
            include_timestamps: Include timestamp in context
        """
        self.max_turns = max_turns
        self.max_triplets_per_turn = max_triplets_per_turn
        self.include_timestamps = include_timestamps

    def build(
        self,
        turns: List[Dict],
        triplets: List[Dict],
        turn_contents: Optional[Dict[str, Dict]] = None,
    ) -> str:
        """
        Build context from turns and triplets

        Args:
            turns: List of (turn_id, score) tuples or dicts
            triplets: List of triplet dicts with turn_id
            turn_contents: Optional dict mapping turn_id to content dict

        Returns:
            Formatted context string
        """
        # Normalize turns to list of dicts
        normalized_turns = []
        for turn in turns[: self.max_turns]:
            if isinstance(turn, tuple):
                normalized_turns.append({"turn_id": turn[0], "score": turn[1]})
            else:
                normalized_turns.append(turn)

        # Group triplets by turn_id
        triplets_by_turn = {}
        for triplet in triplets:
            turn_id = triplet.get("turn_id", "")
            if turn_id not in triplets_by_turn:
                triplets_by_turn[turn_id] = []
            triplets_by_turn[turn_id].append(triplet)

        # Build context
        context_parts = []

        for i, turn_info in enumerate(normalized_turns, 1):
            turn_id = turn_info["turn_id"]
            score = turn_info.get("score", 0.0)

            # Turn header
            header = f"[Turn {i}: {turn_id}]"
            if score > 0:
                header += f" (relevance: {score:.4f})"

            context_parts.append(header)

            # Turn content
            if turn_contents and turn_id in turn_contents:
                content_info = turn_contents[turn_id]
                speaker = content_info.get("speaker", "")
                content = content_info.get("content", "")
                timestamp = content_info.get("timestamp", "")

                if speaker:
                    context_parts.append(f"Speaker: {speaker}")
                if self.include_timestamps and timestamp:
                    context_parts.append(f"Time: {timestamp}")
                if content:
                    context_parts.append(f"Content: {content}")

            # Triplets for this turn
            turn_triplets = triplets_by_turn.get(turn_id, [])
            if turn_triplets:
                context_parts.append("Knowledge:")
                for triplet in turn_triplets[: self.max_triplets_per_turn]:
                    e1 = triplet.get("entity1", triplet.get("entity1_lower", ""))
                    rel = triplet.get("relation", "")
                    e2 = triplet.get("entity2", triplet.get("entity2_lower", ""))
                    context_parts.append(f"  - ({e1}, {rel}, {e2})")

            context_parts.append("")  # Empty line between turns

        return "\n".join(context_parts)

    def build_simple(self, triplets: List[Dict]) -> str:
        """
        Build simple context from triplets only (no turn structure)

        Args:
            triplets: List of triplet dicts

        Returns:
            Formatted context string
        """
        if not triplets:
            return "No relevant information found."

        lines = ["Relevant Knowledge:"]
        seen = set()

        for triplet in triplets:
            e1 = triplet.get("entity1", triplet.get("entity1_lower", ""))
            rel = triplet.get("relation", "")
            e2 = triplet.get("entity2", triplet.get("entity2_lower", ""))

            key = (e1.lower(), rel.lower(), e2.lower())
            if key not in seen:
                seen.add(key)
                lines.append(f"- ({e1}, {rel}, {e2})")

        return "\n".join(lines)

    def build_from_retrieval(
        self,
        retrieval_result: Dict,
        triplet_df: Optional[pd.DataFrame] = None,
        turn_df: Optional[pd.DataFrame] = None,
    ) -> str:
        """
        Build context directly from KGRetriever output

        Args:
            retrieval_result: Output from KGRetriever.retrieve()
            triplet_df: Optional triplet DataFrame for additional triplets
            turn_df: Optional turn DataFrame for content

        Returns:
            Formatted context string
        """
        results = retrieval_result.get("results", {})
        top_triplets = retrieval_result.get("triplets", [])

        # Get turn IDs
        turns = results.get("turn", [])
        turn_ids = [t[0] if isinstance(t, tuple) else t["turn_id"] for t in turns]

        # Get all triplets for these turns
        if triplet_df is not None and len(turn_ids) > 0:
            turn_set = set(turn_ids)
            additional_triplets = triplet_df[
                triplet_df["turn_id"].isin(turn_set)
            ].to_dict("records")
            all_triplets = top_triplets + additional_triplets
        else:
            all_triplets = top_triplets

        # Get turn contents
        turn_contents = {}
        if turn_df is not None:
            for turn_id in turn_ids:
                matches = turn_df[turn_df["turn_id"] == turn_id]
                if not matches.empty:
                    row = matches.iloc[0]
                    # Use .get() with default for dict-like access on Series
                    content = row["content"] if "content" in row.index else ""
                    if not content and "text" in row.index:
                        content = row["text"]
                    turn_contents[turn_id] = {
                        "content": content,
                        "speaker": row["speaker"] if "speaker" in row.index else "",
                        "timestamp": row["timestamp"] if "timestamp" in row.index else "",
                    }

        return self.build(turns, all_triplets, turn_contents)

