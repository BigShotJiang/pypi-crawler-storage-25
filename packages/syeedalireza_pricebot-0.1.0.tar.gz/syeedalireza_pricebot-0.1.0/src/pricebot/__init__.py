"""PriceBot package"""
