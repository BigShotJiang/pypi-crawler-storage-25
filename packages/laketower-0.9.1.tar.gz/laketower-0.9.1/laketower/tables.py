import enum
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from functools import cached_property
from typing import Any, BinaryIO, Protocol, TextIO

import deltalake
import duckdb
import pyarrow as pa
import pyarrow.compute as pc
import pyarrow.csv as csv
import pyarrow.dataset as padataset
import pydantic
import sqlglot
import sqlglot.dialects.duckdb
import sqlglot.errors
import sqlglot.expressions

from laketower.config import ConfigTable, TableFormats


DEFAULT_LIMIT = 10


class ImportModeEnum(str, enum.Enum):
    append = "append"
    overwrite = "overwrite"


class ImportFileFormatEnum(str, enum.Enum):
    csv = "csv"
    xlsx = "xlsx"


class TableMetadata(pydantic.BaseModel):
    table_format: TableFormats
    name: str | None = None
    description: str | None = None
    uri: str
    id: str
    version: int
    created_at: datetime
    partitions: list[str]
    configuration: dict[str, str]


class TableRevision(pydantic.BaseModel):
    version: int
    timestamp: datetime
    client_version: str | None = None
    operation: str
    operation_parameters: dict[str, Any]
    operation_metrics: dict[str, Any]


class TableHistory(pydantic.BaseModel):
    revisions: list[TableRevision]


class TableProtocol(Protocol):  # pragma: no cover
    @classmethod
    def is_valid(cls, table_config: ConfigTable) -> bool: ...
    def __init__(self, table_config: ConfigTable) -> None: ...
    def metadata(self) -> TableMetadata: ...
    def schema(self) -> pa.Schema: ...
    def history(self) -> TableHistory: ...
    def dataset(self, version: int | str | None = None) -> padataset.Dataset: ...
    @classmethod
    def import_data(
        cls,
        table_config: ConfigTable,
        data: pa.Table,
        mode: ImportModeEnum = ImportModeEnum.overwrite,
    ) -> None: ...


class DeltaTable:
    def __init__(self, table_config: ConfigTable):
        super().__init__()
        self.table_config = table_config
        storage_options = self._generate_storage_options(table_config)
        self._impl = deltalake.DeltaTable(
            table_config.uri, storage_options=storage_options
        )

    @classmethod
    def _generate_storage_options(
        cls, table_config: ConfigTable
    ) -> dict[str, str] | None:
        # documentation from `object-store` Rust crate:
        # - s3: https://docs.rs/object_store/latest/object_store/aws/enum.AmazonS3ConfigKey.html
        # - adls: https://docs.rs/object_store/latest/object_store/azure/enum.AzureConfigKey.html
        storage_options = None
        conn_s3 = (
            table_config.storage_credential.s3
            if table_config.storage_credential and table_config.storage_credential.s3
            else None
        )
        conn_adls = (
            table_config.storage_credential.adls
            if table_config.storage_credential and table_config.storage_credential.adls
            else None
        )
        if conn_s3:
            storage_options = (
                {
                    "aws_access_key_id": conn_s3.access_key_id,
                    "aws_secret_access_key": conn_s3.secret_access_key.get_secret_value(),
                    "aws_allow_http": str(conn_s3.allow_http).lower(),
                }
                | ({"aws_region": conn_s3.region} if conn_s3.region else {})
                | (
                    {"aws_endpoint_url": str(conn_s3.endpoint_url).rstrip("/")}
                    if conn_s3.endpoint_url
                    else {}
                )
            )
        elif conn_adls:
            storage_options = (
                {
                    "azure_storage_account_name": conn_adls.account_name,
                    "azure_use_azure_cli": str(conn_adls.use_azure_cli).lower(),
                }
                | (
                    {
                        "azure_storage_access_key": conn_adls.access_key.get_secret_value()
                    }
                    if conn_adls.access_key
                    else {}
                )
                | (
                    {"azure_storage_sas_key": conn_adls.sas_key.get_secret_value()}
                    if conn_adls.sas_key
                    else {}
                )
                | (
                    {"azure_storage_tenant_id": conn_adls.tenant_id}
                    if conn_adls.tenant_id
                    else {}
                )
                | (
                    {"azure_storage_client_id": conn_adls.client_id}
                    if conn_adls.client_id
                    else {}
                )
                | (
                    {
                        "azure_storage_client_secret": conn_adls.client_secret.get_secret_value()
                    }
                    if conn_adls.client_secret
                    else {}
                )
                | (
                    {"azure_msi_endpoint": str(conn_adls.msi_endpoint).rstrip("/")}
                    if conn_adls.msi_endpoint
                    else {}
                )
            )
        return storage_options

    @classmethod
    def is_valid(cls, table_config: ConfigTable) -> bool:
        storage_options = cls._generate_storage_options(table_config)
        try:
            return deltalake.DeltaTable.is_deltatable(
                table_config.uri, storage_options=storage_options
            )
        except OSError:
            return False

    def metadata(self) -> TableMetadata:
        metadata = self._impl.metadata()
        return TableMetadata(
            table_format=self.table_config.table_format,
            name=metadata.name,
            description=metadata.description,
            uri=self._impl.table_uri,
            id=str(metadata.id),
            version=self._impl.version(),
            created_at=datetime.fromtimestamp(
                metadata.created_time / 1000, tz=timezone.utc
            ),
            partitions=metadata.partition_columns,
            configuration=metadata.configuration,
        )

    def schema(self) -> pa.Schema:
        return pa.schema(self._impl.schema().to_arrow())  # type: ignore[arg-type]

    def history(self) -> TableHistory:
        delta_history = self._impl.history()
        revisions = [
            TableRevision(
                version=event["version"],
                timestamp=datetime.fromtimestamp(
                    event["timestamp"] / 1000, tz=timezone.utc
                ),
                client_version=event.get("clientVersion") or event.get("engineInfo"),
                operation=event["operation"],
                operation_parameters=event["operationParameters"],
                operation_metrics=event.get("operationMetrics") or {},
            )
            for event in delta_history
        ]
        return TableHistory(revisions=revisions)

    def dataset(self, version: int | str | None = None) -> padataset.Dataset:
        if version is not None:
            self._impl.load_as_version(version)
        return self._impl.to_pyarrow_dataset()

    @classmethod
    def import_data(
        cls,
        table_config: ConfigTable,
        data: pa.Table,
        mode: ImportModeEnum = ImportModeEnum.overwrite,
    ) -> None:
        storage_options = cls._generate_storage_options(table_config)
        deltalake.write_deltalake(
            table_config.uri,
            data,
            mode=mode.value,
            schema_mode="merge",
            storage_options=storage_options,
        )


def resolve_table(table_config: ConfigTable) -> type[TableProtocol]:
    return {TableFormats.delta: DeltaTable}[table_config.table_format]


def load_table(table_config: ConfigTable) -> TableProtocol:
    handler_class = resolve_table(table_config)
    if not handler_class.is_valid(table_config):
        raise ValueError(f"Invalid table: {table_config.uri}")
    return handler_class(table_config)


def load_datasets(table_configs: list[ConfigTable]) -> dict[str, padataset.Dataset]:
    tables_dataset = {}
    for table_config in table_configs:
        try:
            tables_dataset[table_config.name] = load_table(table_config).dataset()
        except ValueError:
            pass
    return tables_dataset


def extract_query_parameter_names(sql: str) -> set[str]:
    try:
        parsed_sql = sqlglot.parse(sql, dialect=sqlglot.dialects.duckdb.DuckDB)
    except sqlglot.errors.SqlglotError as e:
        raise ValueError(f"Error: {e}") from e

    return {
        str(node.this)
        for statement in parsed_sql
        if statement is not None
        for node in statement.walk()
        if isinstance(node, sqlglot.expressions.Placeholder)
    }


def generate_table_query(
    table_name: str,
    limit: int | None = None,
    cols: list[str] | None = None,
    sort_asc: str | None = None,
    sort_desc: str | None = None,
) -> str:
    query_expr = (
        sqlglot.select(*([f'"{col}"' for col in cols] if cols else ["*"]))
        .from_(f'"{table_name}"')
        .limit(limit or DEFAULT_LIMIT)
    )
    if sort_asc:
        query_expr = query_expr.order_by(f"{sort_asc} asc")
    elif sort_desc:
        query_expr = query_expr.order_by(f"{sort_desc} desc")
    return query_expr.sql(dialect=sqlglot.dialects.duckdb.DuckDB, identify=True)


def generate_table_statistics_query(table_name: str) -> str:
    summarize_expr = sqlglot.expressions.Summarize(
        this=sqlglot.expressions.Table(this=f'"{table_name}"')
    )
    subquery_expr = sqlglot.expressions.Subquery(this=summarize_expr)
    query_expr = sqlglot.select(
        "column_name", "count", "avg", "std", "min", "max"
    ).from_(subquery_expr)
    return query_expr.sql(dialect=sqlglot.dialects.duckdb.DuckDB, identify=True)


def limit_query(sql_query: str, max_limit: int) -> str:
    try:
        query_ast = sqlglot.parse(sql_query, dialect=sqlglot.dialects.duckdb.DuckDB)
    except sqlglot.errors.SqlglotError as e:
        raise ValueError(f"Error: {e}") from e

    if query_ast and isinstance(query_ast[-1], sqlglot.expressions.Select):
        limit_wrapper = (
            sqlglot.select("*")
            .from_(sqlglot.expressions.Subquery(this=query_ast[-1]))
            .limit(max_limit)
        )
        query_ast[-1] = limit_wrapper

    return "; ".join(
        [
            stmt.sql(dialect=sqlglot.dialects.duckdb.DuckDB, identify=True)
            for stmt in query_ast
            if stmt is not None
        ]
    )


def execute_query(
    tables_datasets: dict[str, padataset.Dataset],
    sql_query: str,
    sql_params: dict[str, str] | None = None,
) -> pa.Table:
    if not sql_query:
        raise ValueError("Error: Cannot execute empty SQL query")

    try:
        conn = duckdb.connect()
        for table_name, table_dataset in tables_datasets.items():
            # ATTACH IF NOT EXISTS ':memory:' AS {catalog.name};
            # CREATE SCHEMA IF NOT EXISTS {catalog.name}.{database.name};
            # USE {catalog.name}.{database.name};
            # CREATE VIEW IF NOT EXISTS {table.name} AS FROM {table.name}_dataset;

            view_name = f"{table_name}_view"
            conn.register(view_name, table_dataset)
            conn.execute(f'create view "{table_name}" as select * from "{view_name}"')  # nosec B608
        normalized_params = {k: v or None for k, v in (sql_params or {}).items()}
        return conn.execute(sql_query, parameters=normalized_params).to_arrow_table()
    except duckdb.Error as e:
        raise ValueError(f"Error: {e}") from e


def compute_totals(results: pa.Table) -> pa.RecordBatch:
    return pa.record_batch(
        [
            pa.array([pc.sum(results.column(i))])
            if pa.types.is_integer(field.type) or pa.types.is_floating(field.type)
            else pa.array([None], type=field.type)
            for i, field in enumerate(results.schema)
        ],
        schema=results.schema,
    )


@dataclass(frozen=True)
class QueryResult:
    data: pa.Table
    execution_time_ms: float
    truncated: bool

    @property
    def num_rows(self) -> int:
        return self.data.num_rows

    @property
    def column_names(self) -> list[str]:
        return self.data.column_names

    @property
    def schema(self) -> pa.Schema:
        return self.data.schema

    @cached_property
    def rows(self) -> list[dict[str, Any]]:
        return self.data.to_pylist()

    @cached_property
    def columns(self) -> dict[str, list[Any]]:
        return self.data.to_pydict()

    @cached_property
    def column_cardinalities(self) -> dict[str, int]:
        return {
            name: pc.count_distinct(self.data.column(name)).as_py()
            for name in self.data.column_names
        }

    @cached_property
    def column_uniques(self) -> dict[str, list[Any]]:
        return {
            name: sorted(
                v
                for v in pc.unique(self.data.column(name)).to_pylist()
                if v is not None
            )
            for name in self.data.column_names
        }

    @cached_property
    def totals(self) -> pa.RecordBatch:
        return compute_totals(self.data)


def run_query(
    tables_datasets: dict[str, padataset.Dataset],
    sql_query: str,
    sql_params: dict[str, str] | None = None,
    max_rows: int = DEFAULT_LIMIT,
) -> QueryResult:
    limited_sql = limit_query(sql_query, max_rows + 1)
    start = time.perf_counter()
    results = execute_query(tables_datasets, limited_sql, sql_params)
    elapsed = (time.perf_counter() - start) * 1000

    truncated = results.num_rows > max_rows
    data = results.slice(0, max_rows) if truncated else results

    return QueryResult(
        data=data,
        execution_time_ms=elapsed,
        truncated=truncated,
    )


def _read_xlsx(data: bytes) -> pa.Table:
    try:
        import fastexcel
    except ImportError:
        raise ImportError(
            "Excel support requires the 'excel' extra. Install laketower[excel]"
        )
    return pa.Table.from_batches([fastexcel.read_excel(data).load_sheet(0).to_arrow()])


def import_file_to_table(
    table_config: ConfigTable,
    file_path: BinaryIO | TextIO,
    mode: ImportModeEnum = ImportModeEnum.overwrite,
    file_format: ImportFileFormatEnum = ImportFileFormatEnum.csv,
    delimiter: str = ",",
    encoding: str = "utf-8",
) -> int:
    file_format_handler = {
        ImportFileFormatEnum.csv: lambda f, d, e: csv.read_csv(
            f,
            read_options=csv.ReadOptions(encoding=e),
            parse_options=csv.ParseOptions(delimiter=d),
            convert_options=csv.ConvertOptions(
                null_values=[], strings_can_be_null=False
            ),
        ),
        ImportFileFormatEnum.xlsx: lambda f, *_: _read_xlsx(f.read()),
    }
    df = file_format_handler[file_format](file_path, delimiter, encoding)
    handler_class = resolve_table(table_config)
    handler_class.import_data(table_config, df, mode)
    return len(df)
