# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.9.1] - 2026-04-29
Patch version with performance improvements for query results dynamic rendering
in Laketower web application.

### Fixed
- web: performance enhancements to render query results

### Changed
- refactor query results as a unified structure with combined metadata and statistics
- demo: add large data predefined query

## [0.9.0] - 2026-04-28
Introduces a lightweight asynchronous query execution mechanism for the raw SQL
editor and predefined SQL queries. As this feature requires JavaScript to be
enabled on client-side, a basic fallback is provided in no-JS environments.

Excel files (XLSX format) are now supported for table data import.

### BREAKING CHANGES
- web: separate predefined query view and execution into distinct routes
- web: separate tables query view and execution into distinct routes
- web: use `htmx` for progressive enhancement when available

### Added
- support for Excel (XLSX) file format as import data source, gated behind the `excel` extra
- web: asynchronous execution for predefined queries when available
- web: asynchronous execution for tables query when available

### Fixed
- preserve empty strings as-is when importing CSV files (previously coerced to `null`)
- preserve empty parameters in parametrized SQL queries

## [0.8.0] - 2026-04-20
Extends YAML configuration with environment variable interpolation, multi-file
includes, and a new `config show` CLI subcommand to inspect the fully resolved
configuration.

### Added
- support for inline interpolation of environment variables in YAML configuration (`${VAR_NAME}`)
- support for `include` directive in YAML configuration to deep-merge external config files
- `config show` CLI subcommand to print the fully resolved configuration as YAML, with optional `--with-env-vars-substitution` flag

### Changed
- update dependencies

## [0.7.0] - 2026-04-17
Introduces a global `storage_credentials` registry to centralise S3/ADLS
credentials and reuse them across tables, replacing per-table `connection`
blocks. Includes breaking changes to credential field naming, the default table
import mode, and adds support for importing data to tables that don't yet exist
in storage.

### BREAKING CHANGES
- `overwrite` is now the default table import mode (previously `append`) for both CLI and web
- replace per-table `connection` block with global `storage_credentials` registry
- strip redundant type prefixes from storage credential fields (`s3_*`, `adls_*`, `azure_*`)

### Added
- top-level `storage_credentials` registry for defining named S3/ADLS credentials
- allow importing data to tables that do not exist yet in storage

### Fixed
- replace `duckdb` connection `fetch_arrow_table` with `to_arrow_table`
- pass storage credentials to `write_deltalake` when importing data to remote tables (S3, ADLS)

### Changed
- replace now deprecated `sqlglot[rs]` with `sqlglot[c]`
- update dependencies
- move Jinja2 templates instance to app state

## [0.6.11] - 2026-02-15
Patch release to improve compatibility with latest `sqlglot` versions.

### Fixed
- compatibility with `sqlglot` >= 28.3.0

### Changed
- use `sqlglot[rs]` with faster Rust SQL parser
- update dependencies
- update js dependencies and vendored static assets

## [0.6.10] - 2025-12-11
Introduce an optional customization of adding a footer totals row to predefined
query results, available in both the Web and CLI applicatons.

### Added
- new `totals_row` query setting in YAML configuration

## [0.6.9] - 2025-11-18
### Added
- support for Python 3.14

### Misc
- update package keywords
- update package classifiers

## [0.6.8] - 2025-11-17
### Fixed
- web: handle sql parameters in csv export

## [0.6.7] - 2025-11-12
### Added
- web: add `--host` and `--port` options for custom network configuration

### Fixed
- cli: display args default values for all sub-parsers
- ensure `laketower` python package is detected as typed

## [0.6.6] - 2025-11-12
### Fixed
- web: sort query parameters by key name

## [0.6.5] - 2025-11-11
Patch release with minor enhancements (interactive SQL query results, enforced
row limits for large tables, query execution time indicator) and many minor fixes.

### Added
- new `settings` section in YAML configuration
- setting `max_query_rows` to limit sql query results
- setting `web.hide_tables` to hide the tables section for the web application
- query execution time indicator

### Changed
- web: use `datatables.js` for interactive query results

### Fixed
- web: table view hide column button link regression
- web: exclude actions from table data view horizontal scrolling
- web: handle sql query parsing errors
- web: do not highlight multiple menu items sharing the same path prefix

## [0.6.4] - 2025-10-20
### Fixed
- add missing `tzdata` dependency from previous `pandas` dependency removal

## [0.6.3] - 2025-10-19
Patch release removing unnecessary `pandas` dependency and updating the displayed
application name in the web application.

### Fixed
- web: update application name
- web: move application details to about modal window

### Misc
- replace usage of `pandas.DataFrame` with `pyarrow.Table`

## [0.6.2] - 2025-09-28
Patch release fixing a bug when registering Arrow Datasets as tables instead of
views with DuckDB query engine, leading to performance degradation on larger tables.

### Fixed
- map arrow datasets as views with DuckDB query engine

## [0.6.1] - 2025-09-11
Patch release with minor enhancements (SQL syntax highlighting, query parameters,
predefined query Markdown description) and quality of life improvements
(hide read-only SQL editor in predefined queries, web app offline usage).

### Added
- web: display app version in sidebar
- web: use CodeMirror SQL query editor
- web: add support for tables query parameters
- web: add support for predefined queries parameters
- web: add optional markdown description for predefined queries
- cli: add support for tables query parameters
- cli: add support for predefined queries parameters

### Changed
- web: hide SQL editor for predefined queries
- demo: add parameters to daily avg temperature query

### Fixed
- handle empty SQL queries

### Misc
- vendor static assets for offline usage

## [0.6.0] - 2025-08-27
Minor release with new features (CSV import/export, S3/ADLS remote tables)
and quality of life improvements (tables lazy loading, quoted SQL identifiers).

### Added
- cli: add csv export option to tables query command
- cli: add tables import command
- web: add csv export to query views
- web: add table import form
- allow environment variable substitution in YAML configuration
- support for remote Delta tables (S3, ADLS)

### Changed
- cli: table uri lazy validation in app configuration
- web: table uri lazy validation in app configuration
- docs: update web application screenshots

### Fixed
- cli: laketower python entrypoint script
- always use quoted SQL identifiers in query builder

## [0.5.1] - 2025-05-30
Patch release with support for `deltalake` version 1.0.0.

### Changes
- deps: upgrade to `deltalake` version 1

## [0.5.0] - 2025-03-19
**Announcement:** Laketower open-source license is switching from AGPLv3 to Apache 2.0.

### Fixed
- deps: avoid dependency jinja2 version 3.1.5

### Changed
- docs: update configuration format
- docs: update web application section with screenshots

## [0.4.1] - 2025-03-02
Minor release with fixes.

### Added
- web: allow editing queries

### Fixed
- web: missing tables query page title
- web: urlencode table view sql query link

## [0.4.0] - 2025-03-01
Introducing new features:
- Display tables statistics
- List and execute pre-defined queries

### Added
- web: add queries view page
- web: add table statistics page with version control
- cli: add queries view command
- cli: add queries list command
- cli: add table statistics command

## [0.3.0] - 2025-02-27
Minor release with fixes and dropped Python 3.9 support.

### BREAKING CHANGES
- deps: drop support for python 3.9

### Fixed
- web: handle invalid tables sql query
- web: truncate long table names in sidebar

## [0.2.0] - 2025-02-25
Introducing the Laketower web application!

### Added
- `web` module
    - List all registered tables
    - Display table overview (metadata and schema)
    - Display table history
    - View a given table with simple query builder
    - Query all registered tables with DuckDB SQL dialect
- CLI: add `tables view --version` argument to time-travel table version

### Fixed
- Delta tables metadata compatibility when name and/or description is missing
- Delta tables history compatibility when created with Spark
- CLI: show default argument values in help

## [0.1.0] - 2025-02-15
Initial release of `laketower`.

### Added
- `cli` module
    - Validate YAML configuration
    - List all registered tables
    - Display a given table metadata
    - Display a given table schema
    - Display a given table history
    - View a given table with simple query builder
    - Query all registered tables with DuckDB SQL dialect

[Unreleased]: https://github.com/datalpia/laketower/compare/0.9.1...HEAD
[0.9.1]: https://github.com/datalpia/laketower/compare/0.9.0...0.9.1
[0.9.0]: https://github.com/datalpia/laketower/compare/0.8.0...0.9.0
[0.8.0]: https://github.com/datalpia/laketower/compare/0.7.0...0.8.0
[0.7.0]: https://github.com/datalpia/laketower/compare/0.6.11...0.7.0
[0.6.11]: https://github.com/datalpia/laketower/compare/0.6.10...0.6.11
[0.6.10]: https://github.com/datalpia/laketower/compare/0.6.9...0.6.10
[0.6.9]: https://github.com/datalpia/laketower/compare/0.6.8...0.6.9
[0.6.8]: https://github.com/datalpia/laketower/compare/0.6.7...0.6.8
[0.6.7]: https://github.com/datalpia/laketower/compare/0.6.6...0.6.7
[0.6.6]: https://github.com/datalpia/laketower/compare/0.6.5...0.6.6
[0.6.5]: https://github.com/datalpia/laketower/compare/0.6.4...0.6.5
[0.6.4]: https://github.com/datalpia/laketower/compare/0.6.3...0.6.4
[0.6.3]: https://github.com/datalpia/laketower/compare/0.6.2...0.6.3
[0.6.2]: https://github.com/datalpia/laketower/compare/0.6.1...0.6.2
[0.6.1]: https://github.com/datalpia/laketower/compare/0.6.0...0.6.1
[0.6.0]: https://github.com/datalpia/laketower/compare/0.5.1...0.6.0
[0.5.1]: https://github.com/datalpia/laketower/compare/0.5.0...0.5.1
[0.5.0]: https://github.com/datalpia/laketower/compare/0.4.1...0.5.0
[0.4.1]: https://github.com/datalpia/laketower/compare/0.4.0...0.4.1
[0.4.0]: https://github.com/datalpia/laketower/compare/0.3.0...0.4.0
[0.3.0]: https://github.com/datalpia/laketower/compare/0.2.0...0.3.0
[0.2.0]: https://github.com/datalpia/laketower/compare/0.1.0...0.2.0
[0.1.0]: https://github.com/datalpia/laketower/releases/tag/0.1.0