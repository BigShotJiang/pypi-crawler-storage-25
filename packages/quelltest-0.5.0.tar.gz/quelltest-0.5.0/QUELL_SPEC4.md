# CLAUDE.md — Quell v0.5.0

> Merged implementation plan for v0.5.0.
> Read QUELL_SPEC.md first — it describes what already exists in v0.4.4.
> This file describes ONLY what to add. Do not change existing modules
> unless explicitly stated in the "Minimal changes to existing files" section.

---

## What Exists — Don't Touch

Everything in QUELL_SPEC.md is stable and working:
- Pipeline: spec readers → coverage checker → synthesizer → verifier → writer
- DocstringReader, TypeReader, BugReader
- RuleEngine, SigInspector, LLMSynthesizer
- Verifier (two-phase), Writer (libcst)
- All CLI commands: check, reproduce, prove, score, ci, init

---

## Critical UX Changes (Apply First — These Answer LinkedIn Objections)

These changes are the most important. Without them, every developer who sees
Quell will ask "does my code get sent to an LLM?" and "why not just write tests
manually?" These changes answer both questions without the developer having to ask.

### Change 1: `[rule-based, no network]` tag on every output line

In `quell/cli.py`, every requirement line in `quell check` output must show
WHERE the result came from and WHETHER any network call happened.

Current output (wrong):
```
├─ amount: Field(gt=0)  → BOUNDARY
```

Required output:
```
├─ amount: Field(gt=0)  → BOUNDARY  [rule-based, no network]
```

Implementation — in the requirements display loop:
```python
def _method_tag(req: Requirement, used_llm: bool = False) -> str:
    """Return a dim tag showing how this requirement was found."""
    if req.source.value == "pyspark":
        return "[dim][pyspark, rule-based, no network][/dim]"
    if used_llm:
        return "[dim][llm][/dim]"
    return "[dim][rule-based, no network][/dim]"

# In the output loop:
tag = _method_tag(req)
console.print(f"  ├─ {req.target_function}: {req.raw_spec_text or req.description}"
              f"  → {req.constraint_kind.value}  {tag}")
```

### Change 2: `"Your code never left your machine."` summary line

At the end of every `quell check --fix` run, add this line IF no LLM was used:

```python
# Track whether any LLM call was made during the run
llm_used = any(
    result.generated_test.generated_by.startswith("llm")
    for result in verification_results
    if result.status.value == "verified"
)

# At the very end of --fix output:
if not llm_used:
    console.print(
        "\n[dim]Your code never left your machine.[/dim]"
    )
else:
    console.print(
        "\n[dim]LLM used for complex cases. "
        "Only function signatures were sent — never business logic.[/dim]"
    )
```

This line is the sales pitch. A developer sees Quell find a gap, generate a
test, prove it works, write it — then reads "Your code never left your machine."
That answers objection #2 permanently.

### Change 3: `--no-llm` flag on `quell check`

Add to the `check` command in `quell/cli.py`:

```python
no_llm: bool = typer.Option(
    False, "--no-llm",
    help="Disable all LLM calls. Rule-based only. No network. Default for CI."
)
```

When `--no-llm` is passed:
- Skip `LLMSynthesizer` entirely — do not instantiate it
- Skip `BugReader` entirely
- Skip any `CUSTOM` constraint kinds (mark as `skipped`)
- Only `RuleEngine` and `PySparkRuleEngine` run
- Never import `anthropic`, `openai`, or `httpx` for LLM calls
- Every output line shows `[rule-based, no network]`

### Change 4: Zero-config first run

`quell check src/` must work with ZERO configuration. No pyproject.toml.
No API key. No `quell init`. No LLM setup.

The rule engine handles BOUNDARY, MUST_RAISE, ENUM_VALID, MUST_RETURN
with zero network calls. This covers 80% of real cases.

In `quell/cli.py`, the `_load_config()` function must return a valid
`QuellConfig` with safe defaults when no config file exists:

```python
def _load_config(project_root: Path) -> QuellConfig:
    """Load config — returns safe defaults if no config found."""
    try:
        pyproject = project_root / "pyproject.toml"
        if pyproject.exists():
            import tomllib
            data = tomllib.loads(pyproject.read_text())
            quell_cfg = data.get("tool", {}).get("quell", {})
            if quell_cfg:
                return QuellConfig(**quell_cfg)
    except Exception:
        pass
    # Safe defaults — works without any config
    return QuellConfig(
        llm_provider="none",    # no LLM by default
        enable_docstring=True,
        enable_types=True,
        enable_mutations=False,
        enable_pyspark=False,
    )
```

Add `"none"` as a valid `llm_provider` value — when set, skip all LLM
initialization silently.

### Change 5: OAuth Browser Auth + Single-Session Enforcement

Replace the simple `quell auth set <key>` with proper OAuth 2.0 PKCE flow.
This is the same pattern used by GitHub CLI, ggshield, and Vercel CLI.

**The user experience:**
```bash
quell auth login
# → Opens browser to quell.buildsbyshashank.tech/auth/login
# → User registers/logs in on website  
# → Website redirects back to localhost:7642/callback
# → Token saved automatically to ~/.quell/credentials.json
# ✓ Logged in as shashank@example.com (Free plan)

quell auth status
# ✓ Logged in as shashank@example.com
#   Plan: Free | LLM checks: 87/100 remaining this month
#   Session: active (this device only)

quell auth logout
# ✓ Logged out. Token revoked on server.
```

**Single-session enforcement:** Each login generates a new token and
invalidates all previous tokens for that account. If someone shares their
token and a second machine tries to use it simultaneously, the server
detects the collision and revokes both, requiring re-login. One account =
one active session at a time.

#### New File: `quell/auth/oauth.py`

```python
"""
OAuth 2.0 PKCE flow for Quell CLI.

Flow:
1. Generate PKCE code_verifier + code_challenge
2. Start local HTTP server on localhost:7642
3. Open browser to quell.buildsbyshashank.tech/auth/login
4. Browser redirects back to localhost:7642/callback?code=...&state=...
5. Exchange auth_code for access_token + refresh_token
6. Save tokens to ~/.quell/credentials.json (chmod 600)
7. Server records session_id — single concurrent session enforced

Single-session enforcement (server-side):
- Each access_token contains a session_id
- Server stores: user_id → active_session_id
- New login → new session_id → old tokens become invalid
- Two simultaneous requests with same token → server detects,
  revokes token, requires re-login
"""
from __future__ import annotations
import base64
import hashlib
import json
import os
import secrets
import stat
import threading
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlencode, urlparse

import httpx

QUELL_API_BASE = "https://quell.buildsbyshashank.tech/api"
QUELL_AUTH_BASE = "https://quell.buildsbyshashank.tech/auth"
CREDENTIALS_PATH = Path.home() / ".quell" / "credentials.json"
CALLBACK_PORT = 7642
CLIENT_ID = "quell-cli"  # public client — no client_secret for PKCE


def _pkce_pair() -> tuple[str, str]:
    """Generate PKCE code_verifier and code_challenge (S256)."""
    verifier = base64.urlsafe_b64encode(secrets.token_bytes(32)).rstrip(b"=").decode()
    digest = hashlib.sha256(verifier.encode()).digest()
    challenge = base64.urlsafe_b64encode(digest).rstrip(b"=").decode()
    return verifier, challenge


def login() -> dict:
    """
    Full OAuth PKCE browser login flow.
    
    Returns credentials dict on success.
    Raises RuntimeError on failure or timeout.
    """
    verifier, challenge = _pkce_pair()
    state = secrets.token_urlsafe(16)

    # Build authorization URL
    params = {
        "client_id": CLIENT_ID,
        "redirect_uri": f"http://localhost:{CALLBACK_PORT}/callback",
        "response_type": "code",
        "scope": "quell:read quell:write",
        "state": state,
        "code_challenge": challenge,
        "code_challenge_method": "S256",
    }
    auth_url = f"{QUELL_AUTH_BASE}/login?" + urlencode(params)

    # Shared state between main thread and callback server
    result: dict = {}
    error: list[str] = []

    class CallbackHandler(BaseHTTPRequestHandler):
        def do_GET(self):
            parsed = urlparse(self.path)
            if parsed.path != "/callback":
                self.send_response(404)
                self.end_headers()
                return

            qs = parse_qs(parsed.query)
            code = qs.get("code", [None])[0]
            returned_state = qs.get("state", [None])[0]
            err = qs.get("error", [None])[0]

            if err:
                error.append(err)
                self._respond("Authentication failed. You can close this tab.")
                return

            if returned_state != state:
                error.append("State mismatch — possible CSRF attack")
                self._respond("Authentication failed. You can close this tab.")
                return

            if code:
                result["code"] = code
                self._respond(
                    "✓ Quell authenticated successfully! "
                    "You can close this tab and return to your terminal."
                )

        def _respond(self, message: str):
            html = f"""<!DOCTYPE html>
<html><body style="font-family:sans-serif;padding:40px;text-align:center">
<h2>{message}</h2>
</body></html>"""
            self.send_response(200)
            self.send_header("Content-Type", "text/html")
            self.end_headers()
            self.wfile.write(html.encode())

        def log_message(self, *args):
            pass  # suppress server logs

    # Start local server in background thread
    server = HTTPServer(("localhost", CALLBACK_PORT), CallbackHandler)
    thread = threading.Thread(target=server.serve_forever)
    thread.daemon = True
    thread.start()

    # Open browser
    print(f"\nOpening browser for login...")
    print(f"If browser doesn't open: {auth_url}\n")
    webbrowser.open(auth_url)

    # Wait for callback (max 120 seconds)
    deadline = time.time() + 120
    while time.time() < deadline:
        if result.get("code") or error:
            break
        time.sleep(0.5)
    server.shutdown()

    if error:
        raise RuntimeError(f"Authentication failed: {error[0]}")
    if not result.get("code"):
        raise RuntimeError("Authentication timed out. Please try again.")

    # Exchange auth code for tokens
    token_resp = httpx.post(
        f"{QUELL_AUTH_BASE}/token",
        data={
            "grant_type": "authorization_code",
            "code": result["code"],
            "redirect_uri": f"http://localhost:{CALLBACK_PORT}/callback",
            "client_id": CLIENT_ID,
            "code_verifier": verifier,
        },
        timeout=15.0,
    )
    token_resp.raise_for_status()
    tokens = token_resp.json()

    # Save credentials
    credentials = {
        "access_token": tokens["access_token"],
        "refresh_token": tokens.get("refresh_token"),
        "expires_at": time.time() + tokens.get("expires_in", 3600),
        "email": tokens.get("email", ""),
        "plan": tokens.get("plan", "free"),
        "session_id": tokens.get("session_id", ""),
    }
    _save_credentials(credentials)
    return credentials


def logout() -> None:
    """Revoke token on server and delete local credentials."""
    creds = load_credentials()
    if creds and creds.get("access_token"):
        try:
            httpx.post(
                f"{QUELL_AUTH_BASE}/logout",
                headers={"Authorization": f"Bearer {creds['access_token']}"},
                timeout=5.0,
            )
        except Exception:
            pass  # best effort — always delete local creds
    if CREDENTIALS_PATH.exists():
        CREDENTIALS_PATH.unlink()


def load_credentials() -> dict | None:
    """Load saved credentials. Returns None if not logged in."""
    # Env var override (for CI)
    env_token = os.environ.get("QUELL_API_KEY")
    if env_token:
        return {"access_token": env_token, "email": "ci", "plan": "ci"}

    if not CREDENTIALS_PATH.exists():
        return None
    try:
        return json.loads(CREDENTIALS_PATH.read_text())
    except Exception:
        return None


def get_valid_token() -> str | None:
    """
    Return a valid access token, refreshing if expired.
    Returns None if not logged in.
    """
    creds = load_credentials()
    if not creds:
        return None

    # Check if token is expired (with 60s buffer)
    expires_at = creds.get("expires_at", 0)
    if expires_at and time.time() > expires_at - 60:
        refreshed = _refresh_token(creds.get("refresh_token"))
        if refreshed:
            return refreshed.get("access_token")
        return None  # refresh failed — needs re-login

    return creds.get("access_token")


def verify_token(token: str) -> dict:
    """
    Verify token with server. Returns user info or raises.
    
    Server enforces single-session: if this token's session_id
    doesn't match the current active session, returns 401.
    """
    r = httpx.get(
        f"{QUELL_API_BASE}/me",
        headers={"Authorization": f"Bearer {token}"},
        timeout=5.0,
    )
    if r.status_code == 401:
        raise RuntimeError(
            "Session expired or used from another device. "
            "Run: quell auth login"
        )
    r.raise_for_status()
    return r.json()


def _refresh_token(refresh_token: str | None) -> dict | None:
    if not refresh_token:
        return None
    try:
        r = httpx.post(
            f"{QUELL_AUTH_BASE}/token",
            data={
                "grant_type": "refresh_token",
                "refresh_token": refresh_token,
                "client_id": CLIENT_ID,
            },
            timeout=10.0,
        )
        if r.status_code == 200:
            tokens = r.json()
            creds = load_credentials() or {}
            creds.update({
                "access_token": tokens["access_token"],
                "refresh_token": tokens.get("refresh_token", refresh_token),
                "expires_at": time.time() + tokens.get("expires_in", 3600),
            })
            _save_credentials(creds)
            return creds
    except Exception:
        pass
    return None


def _save_credentials(credentials: dict) -> None:
    """Save credentials to ~/.quell/credentials.json with chmod 600."""
    CREDENTIALS_PATH.parent.mkdir(parents=True, exist_ok=True)
    CREDENTIALS_PATH.write_text(json.dumps(credentials, indent=2))
    CREDENTIALS_PATH.chmod(stat.S_IRUSR | stat.S_IWUSR)  # owner read/write only
```

#### New File: `quell/auth/__init__.py`

```python
"""Quell authentication."""
```

#### Updated CLI Commands for Auth

Replace the old `quell auth set` command with these in `quell/cli.py`:

```python
auth_app = typer.Typer(help="Manage Quell authentication")
app.add_typer(auth_app, name="auth")


@auth_app.command("login")
def auth_login():
    """
    Log in to quell.buildsbyshashank.tech via browser.

    Opens your browser for secure OAuth login.
    One active session per account — logging in here
    invalidates any other active sessions.

    For CI/CD: set QUELL_API_KEY environment variable instead.
    """
    from quell.auth.oauth import login, verify_token

    try:
        with console.status("Waiting for browser login..."):
            credentials = login()

        email = credentials.get("email", "unknown")
        plan = credentials.get("plan", "free").capitalize()

        console.print(f"\n[green]✓ Logged in as {email}[/green]")
        console.print(f"  Plan: {plan}")
        console.print(f"  Session: active on this device")
        console.print(f"\n  Rule-based checks: unlimited, always free")
        console.print(f"  LLM checks: use --llm flag (rate limited by plan)")
        console.print(f"\n  [dim]Previous sessions on other devices have been revoked.[/dim]")

    except RuntimeError as e:
        console.print(f"[red]Login failed: {e}[/red]")
        raise typer.Exit(1)
    except Exception as e:
        console.print(f"[red]Unexpected error: {e}[/red]")
        console.print("Try again or report at: github.com/shashank7109/quell/issues")
        raise typer.Exit(1)


@auth_app.command("logout")
def auth_logout():
    """Log out and revoke your session token."""
    from quell.auth.oauth import logout, load_credentials

    creds = load_credentials()
    if not creds:
        console.print("[yellow]Not logged in.[/yellow]")
        return

    with console.status("Revoking session..."):
        logout()

    console.print("[green]✓ Logged out. Token revoked on server.[/green]")
    console.print("  Run [bold]quell auth login[/bold] to log in again.")


@auth_app.command("status")
def auth_status():
    """Show current authentication status."""
    from quell.auth.oauth import load_credentials, get_valid_token, verify_token
    import os

    # CI mode check
    if os.environ.get("QUELL_API_KEY"):
        console.print("[green]✓ Authenticated via QUELL_API_KEY env var[/green]")
        console.print("  (CI/CD mode — no session tracking)")
        return

    token = get_valid_token()
    if not token:
        console.print("[yellow]Not logged in.[/yellow]")
        console.print("  Rule-based checks work without login.")
        console.print("  To enable LLM features: [bold]quell auth login[/bold]")
        return

    try:
        with console.status("Checking session..."):
            user_info = verify_token(token)

        console.print(f"[green]✓ Logged in as {user_info.get('email', 'unknown')}[/green]")
        console.print(f"  Plan: {user_info.get('plan', 'free').capitalize()}")
        console.print(f"  LLM checks: {user_info.get('checks_remaining', '?')}"
                      f"/{user_info.get('checks_limit', '?')} remaining this month")
        console.print(f"  Session: active on this device")

    except RuntimeError as e:
        console.print(f"[red]Session invalid: {e}[/red]")
        console.print("  Run: [bold]quell auth login[/bold]")
```

#### How Single-Session Enforcement Works

This must be implemented on the `quell.buildsbyshashank.tech` backend.
Document here so the backend developer knows what to build:

```
Database table: user_sessions
  user_id        TEXT
  session_id     TEXT (UUID, changes on every login)
  access_token   TEXT (hashed)
  created_at     TIMESTAMP
  last_used_at   TIMESTAMP

On login:
  1. Generate new session_id
  2. Set user_sessions.session_id = new_session_id
     (this invalidates any existing session_id)
  3. Return access_token with session_id embedded in JWT payload

On every API request (GET /api/me, POST /api/verify, etc.):
  1. Decode JWT → extract user_id + session_id
  2. Query: SELECT session_id FROM user_sessions WHERE user_id = ?
  3. If stored session_id != token's session_id → return 401
     {"error": "session_revoked", 
      "message": "This session was revoked. Run: quell auth login"}
  4. If match → process request, update last_used_at

On logout:
  1. Generate a new random session_id (invalidates the current token)
  2. Update user_sessions.session_id = new_random_value
  3. Return 200

This means:
  - User logs in on MacBook → session_id = "abc"
  - User logs in on Linux server → session_id = "xyz", "abc" now invalid
  - MacBook tries to use old token → 401 session_revoked
  - MacBook must run quell auth login again
```

#### CI/CD — No Browser Needed

For GitHub Actions and other CI environments, OAuth browser flow doesn't work.
Use environment variable instead (never requires login):

```yaml
env:
  QUELL_API_KEY: ${{ secrets.QUELL_API_KEY }}
```

When `QUELL_API_KEY` is set, `get_valid_token()` returns it directly
and skips all session checking. CI tokens are long-lived API keys generated
from the dashboard at quell.buildsbyshashank.tech (separate from OAuth sessions).

#### New Dependencies to Add

```toml
# pyproject.toml — add to dependencies:
"httpx>=0.27.0",   # already present

# Add to dev dependencies:
"pytest-httpx>=0.30.0",   # for mocking HTTP in tests
```

No new dependencies needed — `httpx` is already in the project,
`webbrowser` and `http.server` are Python stdlib.

#### New Files to Create

```
quell/auth/__init__.py     ← empty init
quell/auth/oauth.py        ← full OAuth PKCE implementation above
```

#### Modified Files

```
quell/cli.py
  - Remove old: @app.command("auth") with action="set"/"status"
  + Add: auth_app = typer.Typer()
  + Add: app.add_typer(auth_app, name="auth")
  + Add: auth_login(), auth_logout(), auth_status() commands
```

#### Test File: `tests/test_auth.py`

```python
"""Tests for OAuth flow — uses httpx mocking."""
import json
import stat
from pathlib import Path
from unittest.mock import patch, MagicMock
import pytest
from quell.auth.oauth import (
    _pkce_pair, _save_credentials, load_credentials,
    get_valid_token, CREDENTIALS_PATH,
)


def test_pkce_pair_generates_distinct_values():
    v1, c1 = _pkce_pair()
    v2, c2 = _pkce_pair()
    assert v1 != v2
    assert c1 != c2
    assert len(v1) > 20
    assert len(c1) > 20


def test_pkce_challenge_is_base64url():
    verifier, challenge = _pkce_pair()
    # Should not contain + or / (URL-safe base64)
    assert "+" not in challenge
    assert "/" not in challenge


def test_save_credentials_sets_chmod_600(tmp_path):
    creds_path = tmp_path / ".quell" / "credentials.json"
    with patch("quell.auth.oauth.CREDENTIALS_PATH", creds_path):
        _save_credentials({"access_token": "test", "email": "a@b.com"})

    mode = oct(creds_path.stat().st_mode)[-3:]
    assert mode == "600"


def test_load_credentials_returns_none_when_missing(tmp_path):
    with patch("quell.auth.oauth.CREDENTIALS_PATH", tmp_path / "missing.json"):
        assert load_credentials() is None


def test_load_credentials_from_env(monkeypatch):
    monkeypatch.setenv("QUELL_API_KEY", "qll_test_key")
    creds = load_credentials()
    assert creds["access_token"] == "qll_test_key"


def test_get_valid_token_returns_none_when_not_logged_in(tmp_path):
    with patch("quell.auth.oauth.CREDENTIALS_PATH", tmp_path / "missing.json"):
        assert get_valid_token() is None


def test_get_valid_token_refreshes_expired_token(tmp_path):
    import time
    expired_creds = {
        "access_token": "old_token",
        "refresh_token": "refresh_me",
        "expires_at": time.time() - 100,  # expired 100s ago
        "email": "test@test.com",
    }
    creds_file = tmp_path / "credentials.json"
    creds_file.write_text(json.dumps(expired_creds))

    with patch("quell.auth.oauth.CREDENTIALS_PATH", creds_file):
        with patch("quell.auth.oauth._refresh_token") as mock_refresh:
            mock_refresh.return_value = {"access_token": "new_token"}
            token = get_valid_token()
            assert token == "new_token"
            mock_refresh.assert_called_once_with("refresh_me")
```

### Change 6: First-run experience

When `quell check` runs for the first time on a project with no API key:

```
Quell v0.5.0  •  quell.buildsbyshashank.tech
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Scanning src/payments.py...

  PaymentRequest
  ├─ amount: Field(gt=0)          → BOUNDARY    [rule-based, no network]
  ├─ currency: Literal[USD,EUR]   → ENUM_VALID  [rule-based, no network]

  process_payment()
  ├─ raises ValueError            → MUST_RAISE  [rule-based, no network]

Found 3 requirements. 0 already tested.

Run: quell check src/ --fix  to generate verified tests.

[dim]No API key needed for rule-based checks.
For LLM-powered features: quell auth set <key>
Get a free key: quell.buildsbyshashank.tech[/dim]
```

The key nudge is at the BOTTOM, after showing value. Not a blocker.
Never show a "please configure LLM" error for rule-based runs.

### Honest Limitations — Add to README

These go in the README under a "Limitations" section. Being honest about
limitations builds trust. Developers respect tools that don't oversell.

```markdown
## Limitations

- **Vague docstrings produce weak requirements.**
  If your docstring says "processes the input" instead of
  "raises ValueError if amount <= 0", Quell can't extract a useful requirement.
  The fix: write specific docstrings. Quell rewards precision.

- **Already well-tested code benefits less.**
  Quell finds gaps. If your tests are already comprehensive,
  Quell adds less value. That's fine — it means your tests are good.

- **Quell prevents bugs in new code, not existing ones.**
  It doesn't find bugs already in your codebase.
  It ensures new code matches its specification as you write it.

The pitch is simple: your docstrings and types are already a spec.
Quell makes sure your tests actually prove the code matches them,
and keeps it that way on every commit.
```

---

## Three Additions in This Version

1. **PySpark Feature** — optional reader + rule generator (opt-in flag)
2. **`quell pr <PR_ID>`** — maintainer triggers Quell on any PR by ID
3. **Quell's own CI** — Quell checks itself on every push/PR

---

## Addition 1: PySpark Feature (Opt-in)

### One flag controls everything

```toml
[tool.quell]
enable_pyspark = true   # off by default — zero overhead when off
```

When off: no PySpark imports, no scanning, nothing.
When on: scans for `StructType` schemas, extracts nullable/type requirements, generates verified tests.

### Why it matters

```python
schema = StructType([
    StructField("amount",      FloatType(),  nullable=False),  # MUST NOT be null
    StructField("currency",    StringType(), nullable=False),  # MUST NOT be null
    StructField("customer_id", LongType(),   nullable=True),   # can be null
])
```

`nullable=False` is a testable requirement. Data pipelines break silently when
null values sneak into non-nullable columns. Nobody auto-generates tests for this.
Quell reads the schema with AST only — never imports pyspark, never runs Spark.

### New File: `quell/spec/pyspark_reader.py`

```python
"""
PySpark schema reader.
Reads StructType definitions via AST — no PySpark imports, no SparkSession.
Returns [] on any error — never raises.

Detects:
  schema = StructType([StructField("col", FloatType(), nullable=False)])
  return StructType([...])  inside a function
  self.schema = StructType([...])

Produces two Requirement kinds per field:
  NOT_NULL   → when nullable=False
  TYPE_CHECK → always (column must match declared type)
"""
from __future__ import annotations
import ast
import uuid
from pathlib import Path
from quell.core.models import Requirement, ConstraintKind, SpecSource


class PySparkReader:

    def read(self, file_path: Path) -> list[Requirement]:
        try:
            source = file_path.read_text(encoding="utf-8")
            if "StructType" not in source:
                return []  # fast exit
            tree = ast.parse(source)
        except Exception:
            return []

        reqs = []
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign):
                if self._is_struct_type(node.value):
                    fields = self._parse_fields(node.value)
                    ctx = self._enclosing_function(node, tree) or "module_schema"
                    reqs.extend(self._to_requirements(fields, ctx, file_path))

            if isinstance(node, ast.Return) and node.value:
                if self._is_struct_type(node.value):
                    fields = self._parse_fields(node.value)
                    ctx = self._enclosing_function(node, tree) or "schema"
                    reqs.extend(self._to_requirements(fields, ctx, file_path))

        return reqs

    def _is_struct_type(self, node) -> bool:
        if not isinstance(node, ast.Call):
            return False
        f = node.func
        return (
            (isinstance(f, ast.Name) and f.id == "StructType") or
            (isinstance(f, ast.Attribute) and f.attr == "StructType")
        )

    def _parse_fields(self, struct_node: ast.Call) -> list[dict]:
        fields = []
        if not struct_node.args:
            return fields
        first = struct_node.args[0]
        if not isinstance(first, ast.List):
            return fields

        for elt in first.elts:
            if not isinstance(elt, ast.Call):
                continue
            f = elt.func
            is_sf = (
                (isinstance(f, ast.Name) and f.id == "StructField") or
                (isinstance(f, ast.Attribute) and f.attr == "StructField")
            )
            if not is_sf or len(elt.args) < 2:
                continue
            name_node = elt.args[0]
            if not isinstance(name_node, ast.Constant) or not isinstance(name_node.value, str):
                continue

            name = name_node.value
            type_name = self._type_name(elt.args[1])
            nullable = True

            if len(elt.args) >= 3 and isinstance(elt.args[2], ast.Constant):
                nullable = bool(elt.args[2].value)
            for kw in elt.keywords:
                if kw.arg == "nullable" and isinstance(kw.value, ast.Constant):
                    nullable = bool(kw.value.value)

            fields.append({"name": name, "type": type_name, "nullable": nullable})

        return fields

    def _type_name(self, node) -> str:
        if isinstance(node, ast.Call):
            f = node.func
            if isinstance(f, ast.Name): return f.id
            if isinstance(f, ast.Attribute): return f.attr
        if isinstance(node, ast.Name): return node.id
        return "UnknownType"

    def _to_requirements(self, fields, context, file_path):
        reqs = []
        for f in fields:
            name, type_name, nullable = f["name"], f["type"], f["nullable"]
            if not nullable:
                reqs.append(Requirement(
                    id=str(uuid.uuid4())[:8],
                    description=f"column '{name}' must not be null (nullable=False)",
                    constraint_kind=ConstraintKind.NOT_NULL,
                    source=SpecSource.PYSPARK,
                    target_function=context,
                    target_file=file_path,
                    raw_spec_text=f"StructField('{name}', {type_name}(), nullable=False)",
                    violation_input={"column": name, "type": type_name},
                ))
            reqs.append(Requirement(
                id=str(uuid.uuid4())[:8],
                description=f"column '{name}' must be {type_name}",
                constraint_kind=ConstraintKind.TYPE_CHECK,
                source=SpecSource.PYSPARK,
                target_function=context,
                target_file=file_path,
                raw_spec_text=f"StructField('{name}', {type_name}())",
                violation_input={"column": name, "type": type_name},
            ))
        return reqs

    def _enclosing_function(self, target, tree) -> str | None:
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                for child in ast.walk(node):
                    if child is target:
                        return node.name
        return None

    @property
    def source_name(self) -> str:
        return "pyspark"
```

### New File: `quell/synthesis/pyspark_rule_engine.py`

```python
"""
Generates PySpark tests for NOT_NULL and TYPE_CHECK requirements.
Pure rule-based. No LLM. No network.

Generated tests use a shared SparkSession fixture from conftest.py.
Quell auto-generates conftest.py if not present.
"""
from __future__ import annotations
import re
from pathlib import Path
from quell.core.models import Requirement, GeneratedTest, ConstraintKind

VALID_VALUES = {
    "IntegerType": "1",       "LongType":    "1",
    "FloatType":   "1.0",     "DoubleType":  "1.0",
    "StringType":  '"test"',  "BooleanType": "True",
    "ArrayType":   "[]",      "MapType":     "{}",
}

PYSPARK_CONFTEST = '''"""SparkSession fixture — generated by Quell."""
import pytest
from pyspark.sql import SparkSession


@pytest.fixture(scope="session")
def spark():
    """Shared SparkSession. Session-scoped: created once, reused across all tests."""
    spark = (
        SparkSession.builder
        .master("local[*]")
        .appName("quell-pyspark-tests")
        .config("spark.sql.shuffle.partitions", "1")
        .config("spark.ui.enabled", "false")
        .getOrCreate()
    )
    spark.sparkContext.setLogLevel("ERROR")
    yield spark
    spark.stop()
'''


class PySparkRuleEngine:

    def can_handle(self, req: Requirement) -> bool:
        return req.constraint_kind in {
            ConstraintKind.NOT_NULL,
            ConstraintKind.TYPE_CHECK,
        }

    def generate(self, req: Requirement) -> GeneratedTest | None:
        if req.constraint_kind == ConstraintKind.NOT_NULL:
            return self._not_null(req)
        if req.constraint_kind == ConstraintKind.TYPE_CHECK:
            return self._type_check(req)
        return None

    def ensure_conftest(self, test_dir: Path) -> None:
        """Auto-generate conftest.py with spark fixture if not present."""
        conftest = test_dir / "conftest.py"
        if conftest.exists():
            if "def spark" in conftest.read_text():
                return
            conftest.write_text(conftest.read_text() + "\n" + PYSPARK_CONFTEST)
        else:
            conftest.parent.mkdir(parents=True, exist_ok=True)
            conftest.write_text(PYSPARK_CONFTEST)

    def _name(self, req: Requirement) -> str:
        func = re.sub(r"[^a-z0-9_]", "_", req.target_function.lower())
        col = (req.violation_input or {}).get("column", "col")
        return f"test_quell_{func}_{req.constraint_kind.value}_{col}_{req.id[:6]}"

    def _test_file(self, req: Requirement) -> Path:
        return (
            req.target_file.parent.parent / "tests" /
            f"test_{req.target_file.stem}.py"
        )

    def _not_null(self, req: Requirement) -> GeneratedTest:
        col = (req.violation_input or {}).get("column", "col")
        type_name = (req.violation_input or {}).get("type", "StringType")
        valid = VALID_VALUES.get(type_name, '"test"')
        name = self._name(req)
        code = f'''def {name}(spark):
    """Quell PySpark: column '{col}' must not be null — {req.raw_spec_text}"""
    import pytest
    from pyspark.sql import Row
    from pyspark.sql.utils import AnalysisException

    with pytest.raises((AnalysisException, Exception)):
        df = spark.createDataFrame([Row(**{{"{col}": None}})])
        df.show()  # triggers schema enforcement
'''
        return GeneratedTest(
            requirement_id=req.id,
            test_function_name=name,
            test_code=code,
            test_file_path=self._test_file(req),
            explanation=f"PySpark: '{col}' nullable=False — null must be rejected",
            generated_by="pyspark_rule_engine",
        )

    def _type_check(self, req: Requirement) -> GeneratedTest:
        col = (req.violation_input or {}).get("column", "col")
        type_name = (req.violation_input or {}).get("type", "StringType")
        valid = VALID_VALUES.get(type_name, '"test"')
        name = self._name(req)
        code = f'''def {name}(spark):
    """Quell PySpark: column '{col}' must be {type_name} — {req.raw_spec_text}"""
    from pyspark.testing import assertSchemaEqual
    from pyspark.sql import Row
    from pyspark.sql.types import StructType, StructField, {type_name}

    df = spark.createDataFrame([Row(**{{"{col}": {valid}}})])
    expected = StructType([StructField("{col}", {type_name}())])
    assertSchemaEqual(df.select("{col}").schema, expected)
'''
        return GeneratedTest(
            requirement_id=req.id,
            test_function_name=name,
            test_code=code,
            test_file_path=self._test_file(req),
            explanation=f"PySpark: '{col}' must be {type_name}",
            generated_by="pyspark_rule_engine",
        )
```

### Minimal changes to existing files for PySpark

**`quell/core/models.py`** — add to enums only:
```python
# SpecSource enum: add
PYSPARK = "pyspark"

# ConstraintKind enum: add
NOT_NULL   = "not_null"
TYPE_CHECK = "type_check"

# QuellConfig: add
enable_pyspark: bool = False
```

**`quell/cli.py`** — in check command, after existing readers:
```python
if config.enable_pyspark:
    from quell.spec.pyspark_reader import PySparkReader
    all_requirements.extend(PySparkReader().read(py_file))
```

**synthesis loop** — after RuleEngine, before LLMSynthesizer:
```python
from quell.synthesis.pyspark_rule_engine import PySparkRuleEngine
pyspark_engine = PySparkRuleEngine()
if pyspark_engine.can_handle(req):
    generated = pyspark_engine.generate(req)
    if generated:
        pyspark_engine.ensure_conftest(generated.test_file_path.parent)
```

**`pyproject.toml`**:
```toml
[project.optional-dependencies]
pyspark = ["pyspark>=3.4.0"]
```

Install with: `pip install quelltest[pyspark]`

---

## Addition 2: `quell pr <PR_ID>` — Maintainer PR Trigger

### What This Is

A maintainer can run Quell on any GitHub PR by ID from their terminal:

```bash
quell pr 42
quell pr 42 --repo owner/reponame
quell pr 42 --fix    # generate + write tests locally
quell pr 42 --comment  # post result as PR comment
```

This is different from the GitHub Action (which runs automatically in CI).
This lets a maintainer:
- Review requirement gaps for a PR before approving it
- Generate the missing tests and open a follow-up PR
- Post a Quell report as a PR comment manually

### New File: `quell/github/pr_runner.py`

```python
"""
Fetches PR diff from GitHub and runs Quell on changed files.

Authentication:
  Reads GITHUB_TOKEN from environment (standard GitHub Actions token).
  Also accepts --token flag for local use with a personal access token.
  
  Get a personal token at: github.com/settings/tokens
  Needs: repo (read) + pull_requests (read) + issues (write for comments)

Usage:
  quell pr 42                         # show gaps for PR #42
  quell pr 42 --fix                   # generate tests locally
  quell pr 42 --comment               # post result as PR comment
  quell pr 42 --repo owner/repo       # specify repo (auto-detects from git remote)
"""
from __future__ import annotations
import json
import os
import subprocess
import tempfile
from pathlib import Path
import httpx


class GitHubPRRunner:
    """
    Fetches a PR's changed Python files and runs Quell on them.
    """

    def __init__(
        self,
        pr_number: int,
        repo: str | None = None,
        token: str | None = None,
        project_root: Path = Path("."),
    ):
        self.pr_number = pr_number
        self.repo = repo or self._detect_repo()
        self.token = token or os.environ.get("GITHUB_TOKEN") or os.environ.get("QUELL_GITHUB_TOKEN")
        self.project_root = project_root
        self.api_base = f"https://api.github.com/repos/{self.repo}"

    def _detect_repo(self) -> str:
        """Auto-detect repo from git remote origin."""
        try:
            result = subprocess.run(
                ["git", "remote", "get-url", "origin"],
                capture_output=True, text=True, check=True,
            )
            url = result.stdout.strip()
            # Handle both HTTPS and SSH:
            # https://github.com/owner/repo.git
            # git@github.com:owner/repo.git
            if "github.com/" in url:
                repo = url.split("github.com/")[-1].replace(".git", "")
            elif "github.com:" in url:
                repo = url.split("github.com:")[-1].replace(".git", "")
            else:
                raise ValueError(f"Cannot parse GitHub repo from remote: {url}")
            return repo
        except Exception as e:
            raise RuntimeError(
                f"Cannot auto-detect GitHub repo. Use --repo owner/reponame\n{e}"
            )

    def _headers(self) -> dict:
        headers = {"Accept": "application/vnd.github+json"}
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        return headers

    def get_pr_info(self) -> dict:
        """Fetch PR metadata: title, author, base branch, head branch."""
        r = httpx.get(
            f"{self.api_base}/pulls/{self.pr_number}",
            headers=self._headers(),
            timeout=10.0,
        )
        r.raise_for_status()
        return r.json()

    def get_changed_python_files(self) -> list[str]:
        """
        Return list of Python file paths changed in this PR.
        Filters to .py files, excludes test files and migrations.
        """
        r = httpx.get(
            f"{self.api_base}/pulls/{self.pr_number}/files",
            headers=self._headers(),
            params={"per_page": 100},
            timeout=10.0,
        )
        r.raise_for_status()
        files = r.json()
        return [
            f["filename"] for f in files
            if f["filename"].endswith(".py")
            and "test" not in f["filename"]
            and f["status"] in ("added", "modified")
        ]

    def get_file_content(self, file_path: str, ref: str) -> str:
        """Fetch file content at a specific git ref."""
        r = httpx.get(
            f"{self.api_base}/contents/{file_path}",
            headers=self._headers(),
            params={"ref": ref},
            timeout=10.0,
        )
        r.raise_for_status()
        import base64
        return base64.b64decode(r.json()["content"]).decode("utf-8")

    def run_quell_on_pr(self, config) -> dict:
        """
        Main entry point.
        1. Fetch PR info and changed files
        2. Write changed files to a temp directory
        3. Run Quell spec readers on them
        4. Return structured report
        """
        from quell.spec.docstring_reader import DocstringReader
        from quell.spec.type_reader import TypeReader
        from quell.coverage.checker import CoverageChecker

        pr_info = self.get_pr_info()
        head_sha = pr_info["head"]["sha"]
        changed_files = self.get_changed_python_files()

        if not changed_files:
            return {
                "pr_number": self.pr_number,
                "pr_title": pr_info["title"],
                "changed_files": [],
                "total_requirements": 0,
                "gaps": [],
                "score": 1.0,
            }

        all_requirements = []

        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_root = Path(tmpdir)

            # Write each changed file to temp dir
            for file_path in changed_files:
                try:
                    content = self.get_file_content(file_path, head_sha)
                    tmp_file = tmp_root / file_path
                    tmp_file.parent.mkdir(parents=True, exist_ok=True)
                    tmp_file.write_text(content)

                    # Run readers on temp file
                    if config.enable_docstring:
                        all_requirements.extend(DocstringReader().read(tmp_file))
                    if config.enable_types:
                        all_requirements.extend(TypeReader().read(tmp_file))
                    if config.enable_pyspark:
                        from quell.spec.pyspark_reader import PySparkReader
                        all_requirements.extend(PySparkReader().read(tmp_file))
                except Exception:
                    continue  # skip files that fail to fetch

        # Check coverage against the actual project's test files
        checker = CoverageChecker(self.project_root)
        all_requirements = checker.check(all_requirements)

        gaps = [r for r in all_requirements if not r.is_covered]
        total = len(all_requirements)
        covered = total - len(gaps)

        return {
            "pr_number": self.pr_number,
            "pr_title": pr_info["title"],
            "pr_author": pr_info["user"]["login"],
            "pr_url": pr_info["html_url"],
            "changed_files": changed_files,
            "total_requirements": total,
            "covered_requirements": covered,
            "gaps": [
                {
                    "file": r.target_file.name,
                    "function": r.target_function,
                    "description": r.description,
                    "kind": r.constraint_kind.value,
                    "source": r.source.value,
                }
                for r in gaps
            ],
            "score": covered / total if total else 1.0,
        }

    def post_comment(self, report: dict) -> None:
        """Post Quell report as a comment on the PR."""
        if not self.token:
            raise RuntimeError(
                "GitHub token required for posting comments.\n"
                "Set GITHUB_TOKEN env var or use --token flag."
            )

        body = self._format_comment(report)

        # Check for existing Quell comment to update
        r = httpx.get(
            f"{self.api_base}/issues/{self.pr_number}/comments",
            headers=self._headers(),
            timeout=10.0,
        )
        r.raise_for_status()
        comments = r.json()
        existing = next(
            (c for c in comments if "Quell Report" in c.get("body", "")),
            None,
        )

        if existing:
            httpx.patch(
                f"{self.api_base}/issues/comments/{existing['id']}",
                headers=self._headers(),
                json={"body": body},
                timeout=10.0,
            ).raise_for_status()
        else:
            httpx.post(
                f"{self.api_base}/issues/{self.pr_number}/comments",
                headers=self._headers(),
                json={"body": body},
                timeout=10.0,
            ).raise_for_status()

    def _format_comment(self, report: dict) -> str:
        """Format the PR comment markdown."""
        score = report["score"]
        emoji = "🟢" if score >= 0.8 else "🟡" if score >= 0.5 else "🔴"
        gaps = report["gaps"]
        total = report["total_requirements"]

        lines = [f"## {emoji} Quell Report — PR #{report['pr_number']}\n"]
        lines.append(f"**{report['pr_title']}**\n")

        if total == 0:
            lines.append("No type or docstring requirements found in changed files.\n")
        elif not gaps:
            lines.append(f"✅ **All {total} requirements in changed files are tested.**\n")
        else:
            pct = int(score * 100)
            lines.append(f"Requirement coverage: **{pct}%** ({total - len(gaps)}/{total} covered)\n")
            lines.append(f"\nFound **{len(gaps)} untested requirement{'s' if len(gaps) > 1 else ''}:**\n")
            lines.append("| File | Function | Requirement | Type |")
            lines.append("|------|----------|-------------|------|")
            for g in gaps[:10]:
                lines.append(
                    f"| `{g['file']}` | `{g['function']}` | {g['description']} | {g['kind']} |"
                )
            if len(gaps) > 10:
                lines.append(f"\n_...and {len(gaps) - 10} more._")
            lines.append(f"\n**Fix locally:** `quell check src/ --fix`")

        from quell import __version__
        lines.append(
            f"\n<sub>Quell v{__version__} • "
            f"rule-based, no code sent anywhere • "
            f"[quell.buildsbyshashank.tech](https://quell.buildsbyshashank.tech)</sub>"
        )
        return "\n".join(lines)
```

### New CLI Command: `quell pr <PR_NUMBER>`

Add to `quell/cli.py`:

```python
@app.command("pr")
def pr_command(
    pr_number: int = typer.Argument(..., help="Pull request number to analyze"),
    repo: str = typer.Option("", "--repo", "-r", help="owner/repo (auto-detected from git remote)"),
    token: str = typer.Option("", "--token", "-t", help="GitHub token (or set GITHUB_TOKEN env var)"),
    fix: bool = typer.Option(False, "--fix", help="Generate + write missing tests locally"),
    comment: bool = typer.Option(False, "--comment", "-c", help="Post result as PR comment"),
    fmt: str = typer.Option("console", "--format", "-f", help="console or json"),
    project_root: Path = typer.Option(Path("."), "--root"),
):
    """
    Analyze requirement coverage for a GitHub Pull Request.

    Examples:
      quell pr 42                     # show gaps for PR #42
      quell pr 42 --comment           # post report as PR comment  
      quell pr 42 --fix               # generate missing tests locally
      quell pr 42 --repo owner/repo   # specify repo explicitly
      quell pr 42 --format json       # JSON output (for CI)

    Authentication:
      Set GITHUB_TOKEN environment variable, or use --token flag.
      Get token: github.com/settings/tokens (needs repo + pull_requests scope)
    """
    from quell.github.pr_runner import GitHubPRRunner

    config = _load_config(project_root)

    runner = GitHubPRRunner(
        pr_number=pr_number,
        repo=repo or None,
        token=token or None,
        project_root=project_root,
    )

    with console.status(f"Fetching PR #{pr_number} from GitHub..."):
        try:
            report = runner.run_quell_on_pr(config)
        except Exception as e:
            console.print(f"[red]Error fetching PR: {e}[/red]")
            console.print("\nTroubleshooting:")
            console.print("  • Set GITHUB_TOKEN env var (needs repo read access)")
            console.print("  • Use --repo owner/reponame to specify the repo")
            console.print("  • Get a token: github.com/settings/tokens")
            raise typer.Exit(1)

    if fmt == "json":
        import json
        print(json.dumps(report, indent=2))
        return

    # Console output
    score = report["score"]
    emoji = "🟢" if score >= 0.8 else "🟡" if score >= 0.5 else "🔴"

    console.print(Panel.fit(
        f"{emoji} [bold]PR #{report['pr_number']}[/bold]: {report['pr_title']}\n"
        f"Author: @{report.get('pr_author', 'unknown')}\n"
        f"Changed files: {len(report['changed_files'])}\n"
        f"Requirements: {report['total_requirements']} found, "
        f"{len(report['gaps'])} untested",
        title="Quell PR Analysis",
    ))

    if not report["gaps"]:
        console.print("[green]✅ All requirements in changed files are tested.[/green]")
    else:
        from rich.table import Table
        table = Table(title=f"{len(report['gaps'])} Untested Requirements")
        table.add_column("File", style="blue")
        table.add_column("Function", style="cyan")
        table.add_column("Requirement", style="white")
        table.add_column("Type", style="magenta")

        for g in report["gaps"]:
            table.add_row(g["file"], g["function"], g["description"], g["kind"])

        console.print(table)
        console.print("\n[yellow]Fix locally:[/yellow] quell check src/ --fix")

    if comment:
        with console.status("Posting comment to PR..."):
            try:
                runner.post_comment(report)
                console.print(f"[green]✓ Comment posted to PR #{pr_number}[/green]")
                console.print(f"  {report['pr_url']}")
            except Exception as e:
                console.print(f"[red]Failed to post comment: {e}[/red]")
                raise typer.Exit(1)

    if fix and report["gaps"]:
        console.print("\n[yellow]Generating tests for gaps...[/yellow]")
        # Re-use existing check --fix logic scoped to changed files
        asyncio.run(_fix_gaps(report["gaps"], config, project_root))
```

### New File to Create: `quell/github/__init__.py`

```python
"""GitHub integration for Quell."""
```

### New File to Create: `quell/github/pr_runner.py`

(Full implementation above — create this file with that exact content.)

---

## Addition 3: Quell's Own CI Workflow

### Purpose

Quell checks itself. Two workflows:

1. **`ci.yml`** — runs on every push + PR to test the library itself
2. **`quell.yml`** — Quell's PR report workflow (Quell dog-fooding itself)

This is powerful marketing: "Quell uses Quell to maintain itself."

### File: `.github/workflows/ci.yml` (Quell's own test suite)

```yaml
name: Quell CI

on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main]

jobs:
  test:
    name: Test Python ${{ matrix.python-version }}
    runs-on: ubuntu-latest
    strategy:
      matrix:
        python-version: ["3.11", "3.12"]
      fail-fast: false

    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Install uv
        uses: astral-sh/setup-uv@v4

      - name: Set up Python ${{ matrix.python-version }}
        run: uv python install ${{ matrix.python-version }}

      - name: Install dependencies
        run: uv sync --all-extras --dev

      - name: Lint with ruff
        run: uv run ruff check quell/ --output-format=github

      - name: Type check with mypy
        run: uv run mypy quell/ --ignore-missing-imports

      - name: Run tests
        run: uv run pytest tests/ -v --tb=short --cov=quell --cov-report=xml

      - name: Upload coverage
        uses: codecov/codecov-action@v4
        with:
          file: coverage.xml
          fail_ci_if_error: false

  quell-self-check:
    name: Quell self-check (rule-based)
    runs-on: ubuntu-latest
    needs: test   # only run if tests pass

    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Install uv
        uses: astral-sh/setup-uv@v4

      - name: Install Quell
        run: uv sync

      - name: Run Quell on itself
        run: |
          uv run quell check quell/ --no-llm --format json > quell_self_report.json || true

      - name: Show Quell self-report
        run: |
          echo "=== Quell Self-Check Report ==="
          cat quell_self_report.json | python3 -c "
          import json, sys
          r = json.load(sys.stdin)
          print(f'Total requirements: {r[\"total_requirements\"]}')
          print(f'Gaps: {len(r[\"gaps\"])}')
          print(f'Score: {r[\"score\"]:.0%}')
          "

      - name: Upload self-report
        uses: actions/upload-artifact@v4
        with:
          name: quell-self-report
          path: quell_self_report.json

  release-check:
    name: Check package builds
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: astral-sh/setup-uv@v4
      - run: uv build
      - run: uv run twine check dist/*
```

### File: `.github/workflows/quell-pr.yml` (Quell's own PR reports)

This is the workflow that runs Quell on PRs to the Quell repository itself.
Dog-fooding: Quell reviews its own PRs.

```yaml
name: Quell PR Report

on:
  pull_request:
    types: [opened, synchronize, reopened]
    paths:
      - "quell/**/*.py"

permissions:
  contents: read
  pull-requests: write

jobs:
  quell-report:
    name: Quell requirement coverage
    runs-on: ubuntu-latest

    steps:
      - name: Checkout
        uses: actions/checkout@v4
        with:
          fetch-depth: 0

      - name: Install uv
        uses: astral-sh/setup-uv@v4

      - name: Install Quell
        run: uv sync

      - name: Run Quell on changed files
        id: quell
        env:
          QUELL_API_KEY: ${{ secrets.QUELL_API_KEY }}
        run: |
          uv run quell check --diff-only --no-llm --format json > quell_report.json || true
          echo "done=true" >> $GITHUB_OUTPUT

      - name: Post PR comment
        if: steps.quell.outputs.done == 'true'
        uses: actions/github-script@v7
        with:
          script: |
            const fs = require('fs');
            let report;
            try {
              report = JSON.parse(fs.readFileSync('quell_report.json', 'utf8'));
            } catch(e) {
              console.log('No report generated');
              return;
            }

            const total = report.total_requirements || 0;
            if (total === 0) return;  // no noise if nothing found

            const gaps = report.gaps || [];
            const score = report.score || 0;
            const scoreEmoji = score >= 0.8 ? '🟢' : score >= 0.5 ? '🟡' : '🔴';
            const pct = Math.round(score * 100);

            let body = `## ${scoreEmoji} Quell Report\n\n`;
            body += `**Requirement coverage for changed files: ${pct}%**\n\n`;

            if (gaps.length === 0) {
              body += `✅ All ${total} requirements in changed files are tested.\n\n`;
            } else {
              body += `Found **${gaps.length} untested requirement${gaps.length > 1 ? 's' : ''}:**\n\n`;
              body += `| File | Function | Requirement | Type |\n`;
              body += `|------|----------|-------------|------|\n`;
              for (const g of gaps.slice(0, 10)) {
                body += `| \`${g.file}\` | \`${g.function}\` | ${g.description} | ${g.kind} |\n`;
              }
              if (gaps.length > 10) {
                body += `\n_...and ${gaps.length - 10} more. Run \`quell check --fix\` locally._\n`;
              }
              body += `\n**Fix locally:** \`quell check quell/ --fix\`\n`;
            }

            body += `\n<sub>Quell v${report.quell_version || 'dev'} • `;
            body += `rule-based, no code sent anywhere • `;
            body += `[quell.buildsbyshashank.tech](https://quell.buildsbyshashank.tech)</sub>`;

            // Update existing comment instead of spamming
            const { data: comments } = await github.rest.issues.listComments({
              owner: context.repo.owner,
              repo: context.repo.repo,
              issue_number: context.issue.number,
            });

            const existing = comments.find(c => c.body.includes('Quell Report'));

            if (existing) {
              await github.rest.issues.updateComment({
                owner: context.repo.owner,
                repo: context.repo.repo,
                comment_id: existing.id,
                body,
              });
            } else {
              await github.rest.issues.createComment({
                owner: context.repo.owner,
                repo: context.repo.repo,
                issue_number: context.issue.number,
                body,
              });
            }
```

### File: `.github/workflows/quell-user.yml` (Template for users)

This is what `quell install --pr` writes to the USER's repo.
Store as a constant in `quell/cli.py`:

```python
GITHUB_ACTION_YAML = """name: Quell — Requirement Coverage

on:
  pull_request:
    types: [opened, synchronize, reopened]
    paths:
      - "**.py"

permissions:
  contents: read
  pull-requests: write

jobs:
  quell:
    name: Quell requirement coverage
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 0

      - uses: actions/setup-python@v5
        with:
          python-version: "3.11"

      - name: Install Quell
        run: pip install quelltest

      - name: Run Quell
        id: quell
        env:
          QUELL_API_KEY: ${{ secrets.QUELL_API_KEY }}
        run: |
          quell check --diff-only --no-llm --format json > quell_report.json || true
          echo "done=true" >> $GITHUB_OUTPUT

      - name: Post PR comment
        if: steps.quell.outputs.done == 'true'
        uses: actions/github-script@v7
        with:
          script: |
            const fs = require('fs');
            let report;
            try {
              report = JSON.parse(fs.readFileSync('quell_report.json', 'utf8'));
            } catch(e) { return; }
            
            const total = report.total_requirements || 0;
            if (total === 0) return;
            
            const gaps = report.gaps || [];
            const score = report.score || 0;
            const emoji = score >= 0.8 ? '🟢' : score >= 0.5 ? '🟡' : '🔴';
            
            let body = `## ${emoji} Quell Report\\n\\n`;
            body += `**Coverage: ${Math.round(score * 100)}%** (${total - gaps.length}/${total} requirements tested)\\n\\n`;
            
            if (gaps.length === 0) {
              body += `✅ All requirements in changed files are tested.\\n`;
            } else {
              body += `**${gaps.length} untested requirement${gaps.length > 1 ? 's' : ''}:**\\n\\n`;
              body += `| File | Function | Requirement | Type |\\n`;
              body += `|------|----------|-------------|------|\\n`;
              for (const g of gaps.slice(0, 10)) {
                body += `| \\`${g.file}\\` | \\`${g.function}\\` | ${g.description} | ${g.kind} |\\n`;
              }
              if (gaps.length > 10) {
                body += `\\n_...and ${gaps.length - 10} more. Run \\`quell check --fix\\` locally._\\n`;
              }
              body += `\\n**Fix locally:** \\`quell check src/ --fix\\`\\n`;
            }
            body += `\\n<sub>Quell • no code sent anywhere • [quell.buildsbyshashank.tech](https://quell.buildsbyshashank.tech)</sub>`;
            
            const { data: comments } = await github.rest.issues.listComments({
              owner: context.repo.owner, repo: context.repo.repo,
              issue_number: context.issue.number,
            });
            const existing = comments.find(c => c.body.includes('Quell Report'));
            if (existing) {
              await github.rest.issues.updateComment({
                owner: context.repo.owner, repo: context.repo.repo,
                comment_id: existing.id, body,
              });
            } else {
              await github.rest.issues.createComment({
                owner: context.repo.owner, repo: context.repo.repo,
                issue_number: context.issue.number, body,
              });
            }
"""
```

---

## `quell install --pr` — Generates User's Workflow

Add this to `quell/cli.py`:

```python
@app.command("install")
def install(
    project_root: Path = typer.Option(Path("."), "--root"),
    hook: bool = typer.Option(False, "--hook", help="Add pre-commit hook"),
    pr: bool = typer.Option(False, "--pr", help="Add GitHub Actions PR workflow"),
):
    """
    Set up Quell in your project.
    
    quell install          → adds both pre-commit hook and GitHub Action
    quell install --hook   → pre-commit hook only
    quell install --pr     → GitHub Action only
    """
    if not hook and not pr:
        hook = True
        pr = True

    if hook:
        _install_precommit_hook(project_root)

    if pr:
        _install_github_action(project_root)


def _install_precommit_hook(project_root: Path) -> None:
    config_file = project_root / ".pre-commit-config.yaml"
    hook_entry = """
  - repo: local
    hooks:
      - id: quell
        name: Quell — verify requirements
        entry: quell check --diff-only --no-llm --auto
        language: system
        types: [python]
        pass_filenames: false
"""
    if config_file.exists():
        if "id: quell" in config_file.read_text():
            console.print("[yellow]Quell hook already in .pre-commit-config.yaml[/yellow]")
            return
        config_file.write_text(config_file.read_text() + hook_entry)
    else:
        config_file.write_text(f"repos:{hook_entry}")

    console.print("[green]✓ Added Quell to .pre-commit-config.yaml[/green]")
    console.print("  Runs on every git commit (changed files only, < 3 seconds)")


def _install_github_action(project_root: Path) -> None:
    workflows_dir = project_root / ".github" / "workflows"
    workflows_dir.mkdir(parents=True, exist_ok=True)
    action_file = workflows_dir / "quell.yml"

    if action_file.exists():
        console.print("[yellow]quell.yml already in .github/workflows/[/yellow]")
        return

    action_file.write_text(GITHUB_ACTION_YAML)
    console.print("[green]✓ Created .github/workflows/quell.yml[/green]")
    console.print("\nNext steps:")
    console.print("  1. Add QUELL_API_KEY to GitHub repo secrets")
    console.print("     github.com → Settings → Secrets → Actions")
    console.print("     Get key: quell.buildsbyshashank.tech")
    console.print("\n  2. git add .github/workflows/quell.yml && git commit")
    console.print("\n  Quell will comment on every PR automatically.")
```

---

## Complete File Map — Everything to Create or Modify

### New files:
```
quell/github/__init__.py               ← empty init
quell/github/pr_runner.py              ← GitHubPRRunner class
quell/spec/pyspark_reader.py           ← PySparkReader
quell/synthesis/pyspark_rule_engine.py ← PySparkRuleEngine

.github/workflows/ci.yml               ← Quell's own test CI
.github/workflows/quell-pr.yml         ← Quell checking itself on PRs
```

### Modified files (minimal, additive only):
```
quell/core/models.py
  + SpecSource.PYSPARK
  + ConstraintKind.NOT_NULL, TYPE_CHECK
  + QuellConfig.enable_pyspark = False

quell/cli.py
  + quell pr command
  + quell install command (updated with --hook, --pr flags)
  + _install_precommit_hook()
  + _install_github_action()
  + GITHUB_ACTION_YAML constant
  + --format json flag on check command
  + PySpark reader wiring (guarded by enable_pyspark)

quell/synthesis/ (orchestration point)
  + PySparkRuleEngine wiring

pyproject.toml
  + pyspark optional dependency
```

---

## Implementation Order

1. `quell/core/models.py` — add NOT_NULL, TYPE_CHECK, PYSPARK, enable_pyspark
2. `quell/github/__init__.py` — empty file
3. `quell/github/pr_runner.py` — full GitHubPRRunner implementation
4. `quell/spec/pyspark_reader.py` — full PySparkReader
5. `quell/synthesis/pyspark_rule_engine.py` — full PySparkRuleEngine
6. `quell/cli.py` — add `pr` command, update `install` command, add GITHUB_ACTION_YAML
7. Wire PySpark into check command (guarded by config.enable_pyspark)
8. Wire PySparkRuleEngine into synthesis loop
9. Add --format json to check command
10. `.github/workflows/ci.yml` — Quell's own CI
11. `.github/workflows/quell-pr.yml` — Quell dog-fooding
12. Tests:
    - `tests/test_pr_runner.py` — mock GitHub API calls with httpx
    - `tests/test_pyspark_reader.py` — test schema parsing
    - `tests/test_install.py` — test file generation
13. `uv run pytest tests/ -v`
14. `quell pr --help` — verify command is registered
15. `quell install --pr` on tmp dir — verify YAML is created correctly

---

## Verification Tests

### `tests/test_pr_runner.py`
```python
"""Tests for GitHubPRRunner — uses mock HTTP responses."""
import pytest
from unittest.mock import patch, MagicMock
from quell.github.pr_runner import GitHubPRRunner

def test_detect_repo_from_https_remote():
    runner = GitHubPRRunner.__new__(GitHubPRRunner)
    with patch("subprocess.run") as mock_run:
        mock_run.return_value.stdout = "https://github.com/owner/myrepo.git\n"
        mock_run.return_value.returncode = 0
        assert runner._detect_repo() == "owner/myrepo"

def test_detect_repo_from_ssh_remote():
    runner = GitHubPRRunner.__new__(GitHubPRRunner)
    with patch("subprocess.run") as mock_run:
        mock_run.return_value.stdout = "git@github.com:owner/myrepo.git\n"
        mock_run.return_value.returncode = 0
        assert runner._detect_repo() == "owner/myrepo"

def test_format_comment_no_gaps():
    runner = GitHubPRRunner(pr_number=1, repo="a/b", token="fake")
    report = {
        "pr_number": 1,
        "pr_title": "Test PR",
        "pr_author": "dev",
        "pr_url": "https://github.com/a/b/pull/1",
        "changed_files": ["payments.py"],
        "total_requirements": 3,
        "covered_requirements": 3,
        "gaps": [],
        "score": 1.0,
    }
    comment = runner._format_comment(report)
    assert "🟢" in comment
    assert "All 3 requirements" in comment

def test_format_comment_with_gaps():
    runner = GitHubPRRunner(pr_number=1, repo="a/b", token="fake")
    report = {
        "pr_number": 1, "pr_title": "Test", "pr_author": "dev",
        "pr_url": "https://github.com/a/b/pull/1",
        "changed_files": ["payments.py"],
        "total_requirements": 3, "covered_requirements": 1,
        "gaps": [
            {"file": "payments.py", "function": "pay",
             "description": "amount must be > 0", "kind": "boundary", "source": "type"},
        ],
        "score": 0.33,
    }
    comment = runner._format_comment(report)
    assert "🔴" in comment
    assert "amount must be > 0" in comment
```

### `tests/test_pyspark_reader.py`
```python
"""Tests for PySparkReader AST parsing."""
import tempfile
from pathlib import Path
from quell.spec.pyspark_reader import PySparkReader
from quell.core.models import ConstraintKind, SpecSource

SAMPLE = '''
from pyspark.sql.types import StructType, StructField, FloatType, StringType

payment_schema = StructType([
    StructField("amount",   FloatType(),  nullable=False),
    StructField("currency", StringType(), nullable=True),
])
'''

def test_reads_not_null_requirement():
    reader = PySparkReader()
    with tempfile.NamedTemporaryFile(suffix=".py", mode="w", delete=False) as f:
        f.write(SAMPLE)
        path = Path(f.name)
    
    reqs = reader.read(path)
    not_null = [r for r in reqs if r.constraint_kind == ConstraintKind.NOT_NULL]
    assert len(not_null) == 1
    assert "amount" in not_null[0].description
    assert not_null[0].source == SpecSource.PYSPARK

def test_reads_type_check_for_all_fields():
    reader = PySparkReader()
    with tempfile.NamedTemporaryFile(suffix=".py", mode="w", delete=False) as f:
        f.write(SAMPLE)
        path = Path(f.name)
    
    reqs = reader.read(path)
    type_checks = [r for r in reqs if r.constraint_kind == ConstraintKind.TYPE_CHECK]
    assert len(type_checks) == 2  # both fields

def test_returns_empty_for_non_pyspark_file():
    reader = PySparkReader()
    with tempfile.NamedTemporaryFile(suffix=".py", mode="w", delete=False) as f:
        f.write("def foo(): pass\n")
        path = Path(f.name)
    
    assert reader.read(path) == []

def test_never_raises():
    reader = PySparkReader()
    # Broken file — should return []
    assert reader.read(Path("/nonexistent/file.py")) == []
```