# CLAUDE.md — Quell

> Read this entire file before touching any code.
> This is the single source of truth for architecture, positioning, and implementation.

---

## What Quell Is — Locked Positioning

**Tagline:** "Your docstrings say what your code should do. Quell proves it."

**One paragraph:** Quell reads specifications that already exist in your codebase — docstrings, Pydantic models, TypeScript types, bug reports — extracts every testable requirement from them, checks which ones have no test, generates a test for each gap, proves the test actually catches violations (not just achieves coverage), then writes it to disk using AST-safe injection. Every test is verified before it touches your files.

**What makes Quell different from every competitor:**

| Tool | Spec source | Verified? | Notes |
|------|------------|-----------|-------|
| Qodo Gen | reads implementation | ❌ | generates tests from what code *does*, not what it *should* do |
| GitHub Copilot | chat prompt | ❌ | no verification step |
| Diffblue Cover | bytecode (RL) | ❌ | Java only, $2500/dev/yr |
| Hypothesis | you write it manually | ❌ | powerful but requires manual spec writing |
| Schemathesis | OpenAPI spec | ❌ | API-level only, needs running server |
| **Quell** | reads existing specs | ✅ | proves every test catches violations |

The critical insight: **Qodo reads your implementation to guess tests. If your code has a bug, Qodo generates tests that bless the bug. Quell reads your specification (docstring says "must raise ValueError") and generates a test that proves the requirement — catching the bug.**

---

## The Core Problem Quell Solves

Developers already write specifications. They just aren't being used as tests.

```python
def process_payment(amount: float, currency: str) -> Transaction:
    """
    Process a payment.
    
    Args:
        amount: Must be positive (> 0).
        currency: Must be one of: USD, EUR, GBP.
    
    Raises:
        ValueError: If amount <= 0 or currency is invalid.
    """
```

```python
class PaymentRequest(BaseModel):
    amount: float = Field(gt=0)
    currency: Literal["USD", "EUR", "GBP"]
```

Three requirements are written right there. Every day, developers write these specs and no tool reads them to generate tests. Quell is the first tool that does — and proves every generated test actually catches violations before writing it.

---

## Architecture — The Unified Pipeline

ALL features share ONE core pipeline. Different inputs, same output.

```
INPUT READERS (spec/*)
  docstring_reader.py   → reads Python docstrings
  type_reader.py        → reads Pydantic models + type annotations
  bug_reader.py         → reads natural language bug descriptions
  mutation_reader.py    → reads mutmut 3.x / Stryker results (optional)
         │
         ▼
  list[Requirement]     ← single unified model for everything
         │
         ▼
COVERAGE CHECKER (coverage/checker.py)
  AST-scans test files
  marks each Requirement: covered / uncovered
         │
         ▼
TEST SYNTHESIZER (synthesis/)
  rule_engine.py        → fast deterministic rules per ConstraintKind
  llm_engine.py         → LLM fallback for complex cases only
         │
         ▼
VERIFICATION ENGINE (core/verifier.py)  ← THE MOAT
  1. Run test on original code    → MUST PASS
  2. Inject violation into source → breaks the requirement
  3. Run test on violated code    → MUST FAIL
  4. ALWAYS restore in finally    → no side effects
  Only VERIFIED tests continue
         │
         ▼
WRITER (core/writer.py)
  libcst injection — never string concatenation
  backup before write, validate CST, restore on failure
  append audit log entry
```

---

## Project Structure

Generate ALL files. No merging, no shortcuts.

```
quell/
├── pyproject.toml
├── README.md
├── CLAUDE.md
├── .github/
│   └── workflows/
│       ├── ci.yml
│       └── release.yml
│
├── quell/
│   ├── __init__.py
│   ├── cli.py
│   ├── sdk.py
│   │
│   ├── core/
│   │   ├── __init__.py
│   │   ├── models.py
│   │   ├── verifier.py       ← THE MOAT — never simplify
│   │   └── writer.py
│   │
│   ├── spec/
│   │   ├── __init__.py
│   │   ├── base.py
│   │   ├── docstring_reader.py
│   │   ├── type_reader.py
│   │   ├── bug_reader.py
│   │   └── mutation_reader.py
│   │
│   ├── coverage/
│   │   ├── __init__.py
│   │   └── checker.py
│   │
│   ├── synthesis/
│   │   ├── __init__.py
│   │   ├── rule_engine.py
│   │   └── llm_engine.py
│   │
│   ├── score/
│   │   ├── __init__.py
│   │   ├── calculator.py
│   │   └── badge.py
│   │
│   ├── ci/
│   │   ├── __init__.py
│   │   ├── runner.py
│   │   ├── diff_parser.py
│   │   └── reporter.py
│   │
│   ├── llm/
│   │   ├── __init__.py
│   │   ├── client.py
│   │   ├── prompts.py
│   │   └── providers/
│   │       ├── __init__.py
│   │       ├── anthropic_provider.py
│   │       ├── openai_provider.py
│   │       └── ollama_provider.py
│   │
│   └── ui/
│       ├── __init__.py
│       ├── console.py
│       └── diff.py
│
└── tests/
    ├── conftest.py
    ├── fixtures/
    │   └── sample_project/
    │       ├── src/
    │       │   └── payments.py
    │       └── tests/
    │           └── test_payments.py
    ├── unit/
    │   ├── test_docstring_reader.py
    │   ├── test_type_reader.py
    │   ├── test_bug_reader.py
    │   ├── test_coverage_checker.py
    │   ├── test_rule_engine.py
    │   ├── test_verifier.py
    │   └── test_writer.py
    └── integration/
        └── test_end_to_end.py
```

---

## pyproject.toml

```toml
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "quell"
version = "0.1.0"
description = "Your docstrings say what your code should do. Quell proves it."
readme = "README.md"
requires-python = ">=3.11"
license = { text = "MIT" }
authors = [{ name = "Shashank Bindal", email = "bindalshashank.89@gmail.com" }]
keywords = [
    "testing", "test-generation", "docstring", "pydantic",
    "verified-tests", "tdd", "pytest", "specification-testing"
]
classifiers = [
    "Development Status :: 3 - Alpha",
    "Intended Audience :: Developers",
    "License :: OSI Approved :: MIT License",
    "Programming Language :: Python :: 3.11",
    "Programming Language :: Python :: 3.12",
    "Topic :: Software Development :: Testing",
]
dependencies = [
    "typer>=0.12.0",
    "rich>=13.7.0",
    "pydantic>=2.6.0",
    "libcst>=1.8.0",
    "anthropic>=0.40.0",
    "openai>=1.50.0",
    "httpx>=0.27.0",
    "gitpython>=3.1.0",
]

[project.optional-dependencies]
mcp = ["mcp>=1.0.0"]
dev = [
    "pytest>=8.0.0",
    "pytest-cov>=5.0.0",
    "pytest-asyncio>=0.23.0",
    "ruff>=0.8.0",
    "mypy>=1.10.0",
]

[project.scripts]
quell = "quell.cli:app"

[project.urls]
Homepage = "https://github.com/shashank7109/quell"
Repository = "https://github.com/shashank7109/quell"

[tool.ruff]
target-version = "py311"
line-length = 88

[tool.ruff.lint]
select = ["E", "F", "I", "N", "W", "UP"]

[tool.mypy]
python_version = "3.11"
strict = true

[tool.pytest.ini_options]
testpaths = ["tests"]
asyncio_mode = "auto"

[tool.quell]
llm_provider = "anthropic"
llm_model = "claude-sonnet-4-5"
max_verification_attempts = 3
verification_timeout_seconds = 30
auto_write = false
enable_docstring = true
enable_types = true
enable_mutations = false
score_threshold = 0.0
```

---

## quell/core/models.py

```python
"""All domain models. Every pipeline stage uses these."""
from __future__ import annotations
from enum import Enum
from pathlib import Path
from typing import Optional, Any
from pydantic import BaseModel, Field
import datetime


class SpecSource(str, Enum):
    DOCSTRING  = "docstring"
    TYPE       = "type"
    BUG_REPORT = "bug_report"
    MUTATION   = "mutation"


class ConstraintKind(str, Enum):
    """The kind of requirement extracted from any spec."""
    MUST_RAISE   = "must_raise"    # raises ExceptionType under condition
    MUST_RETURN  = "must_return"   # returns specific value/type
    BOUNDARY     = "boundary"      # value > / >= / < / <= threshold
    ENUM_VALID   = "enum_valid"    # value must be one of [X, Y, Z]
    ENUM_INVALID = "enum_invalid"  # invalid value must be rejected
    NOT_NONE     = "not_none"      # return must not be None
    MUTATION     = "mutation"      # survived mutant
    BUG_REPRO    = "bug_repro"     # reproduce reported bug
    CUSTOM       = "custom"        # LLM handles free-form


class Requirement(BaseModel):
    """
    One testable requirement from any specification source.
    
    Examples:
      - from docstring "amount must be positive":
          ConstraintKind.BOUNDARY, target_function="process_payment"
      - from Pydantic Field(gt=0):
          ConstraintKind.BOUNDARY, target_function="PaymentRequest"
      - from bug "accepts zero amount silently":
          ConstraintKind.BUG_REPRO, target_function="process_payment"
    """
    id: str
    description: str
    constraint_kind: ConstraintKind
    source: SpecSource
    target_function: str
    target_file: Path
    violation_input: Optional[dict[str, Any]] = None
    expected_behavior: Optional[str] = None
    raw_spec_text: Optional[str] = None
    is_covered: bool = False
    covering_tests: list[str] = Field(default_factory=list)


class GeneratedTest(BaseModel):
    """A candidate test generated for a Requirement."""
    requirement_id: str
    test_function_name: str
    test_code: str
    test_file_path: Path
    explanation: str
    generated_by: str  # "rule_engine" | "llm:model-name"


class VerificationStatus(str, Enum):
    VERIFIED               = "verified"
    FAILS_ON_CORRECT       = "fails_on_correct"
    DOESNT_CATCH_VIOLATION = "doesnt_catch_violation"
    SYNTAX_ERROR           = "syntax_error"
    TIMEOUT                = "timeout"
    ERROR                  = "error"


class VerificationResult(BaseModel):
    requirement_id: str
    generated_test: GeneratedTest
    status: VerificationStatus
    attempts: int = 1
    error_message: Optional[str] = None
    duration_ms: int = 0


class FileScore(BaseModel):
    file_path: Path
    total_requirements: int
    covered_requirements: int
    quell_score: float  # 0.0–1.0

    @property
    def percentage(self) -> int:
        return int(self.quell_score * 100)

    @property
    def grade(self) -> str:
        if self.quell_score >= 0.80: return "A"
        if self.quell_score >= 0.60: return "B"
        if self.quell_score >= 0.40: return "C"
        return "F"


class ProjectScore(BaseModel):
    files: list[FileScore] = Field(default_factory=list)
    generated_at: datetime.datetime = Field(
        default_factory=datetime.datetime.utcnow
    )

    @property
    def total_score(self) -> float:
        total = sum(f.total_requirements for f in self.files)
        if total == 0: return 0.0
        return sum(f.covered_requirements for f in self.files) / total

    @property
    def percentage(self) -> int:
        return int(self.total_score * 100)


class AuditEntry(BaseModel):
    timestamp: datetime.datetime = Field(
        default_factory=datetime.datetime.utcnow
    )
    requirement_id: str
    action: str
    file_path: Optional[Path] = None
    test_function_name: Optional[str] = None
    verification_status: Optional[VerificationStatus] = None


class QuellConfig(BaseModel):
    llm_provider: str = "anthropic"
    llm_model: str = "claude-sonnet-4-5"
    ollama_base_url: str = "http://localhost:11434"
    max_verification_attempts: int = 3
    verification_timeout_seconds: int = 30
    auto_write: bool = False
    audit_log_path: Path = Path(".quell/audit.jsonl")
    backup_dir: Path = Path(".quell/backups")
    enable_docstring: bool = True
    enable_types: bool = True
    enable_mutations: bool = False  # off by default — mutmut not required
    score_threshold: float = 0.0
    diff_only: bool = False
```

---

## quell/spec/docstring_reader.py

```python
"""
Reads Python docstrings and extracts testable Requirements.

Direction: docstring → Requirements.
This is the OPPOSITE of every existing docstring tool (code → docs).

Supported styles: Google, NumPy, RST, plain English (LLM fallback).

Key extractions:
  "Raises: ValueError: if amount <= 0"  → MUST_RAISE requirement
  "amount: Must be positive (> 0)"      → BOUNDARY requirement  
  "currency: one of USD, EUR, GBP"      → ENUM_VALID requirement
  "Returns: Transaction with status"    → MUST_RETURN requirement
"""
from __future__ import annotations
import ast, re, uuid
from pathlib import Path
from quell.core.models import Requirement, ConstraintKind, SpecSource


class DocstringReader:
    """
    Extracts testable requirements from Python docstrings.
    
    Strategy:
    1. Parse file with ast module — get every function's docstring
    2. Run structured parsers (Google/NumPy/RST style)
    3. LLM fallback for unstructured prose
    
    Returns [] on any error — never raises.
    """

    def __init__(self, llm_client=None):
        self.llm = llm_client

    def read(self, file_path: Path) -> list[Requirement]:
        try:
            source = file_path.read_text(encoding="utf-8")
            tree = ast.parse(source)
        except Exception:
            return []

        requirements = []
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                doc = ast.get_docstring(node)
                if doc:
                    requirements.extend(
                        self._parse(doc, node.name, file_path)
                    )
        return requirements

    def _parse(self, doc: str, func: str, path: Path) -> list[Requirement]:
        reqs: list[Requirement] = []
        reqs.extend(self._raises(doc, func, path))
        reqs.extend(self._boundaries(doc, func, path))
        reqs.extend(self._enums(doc, func, path))
        reqs.extend(self._returns(doc, func, path))
        if not reqs and self.llm:
            reqs.extend(self._llm_fallback(doc, func, path))
        return reqs

    def _raises(self, doc: str, func: str, path: Path) -> list[Requirement]:
        reqs = []
        # Match Google "Raises:\n    ExceptionType: condition" blocks
        for block in re.finditer(
            r'Raises?:\s*\n((?:[ \t]+\w[\w.]*[^\n]*\n?)*)', doc, re.MULTILINE
        ):
            for line in block.group(1).strip().splitlines():
                line = line.strip()
                if ':' not in line:
                    continue
                exc, _, cond = line.partition(':')
                reqs.append(Requirement(
                    id=str(uuid.uuid4())[:8],
                    description=f"raises {exc.strip()} when {cond.strip()}",
                    constraint_kind=ConstraintKind.MUST_RAISE,
                    source=SpecSource.DOCSTRING,
                    target_function=func,
                    target_file=path,
                    expected_behavior=f"raises {exc.strip()}",
                    raw_spec_text=line,
                ))
        return reqs

    def _boundaries(self, doc: str, func: str, path: Path) -> list[Requirement]:
        reqs = []
        patterns = [
            r'must be\s+positive',
            r'must be\s*>\s*0',
            r'must be\s*>=\s*\d+',
            r'must be\s*<\s*\d+',
            r'must be\s+negative',
            r'must be\s+between\s+[\d.]+\s+and\s+[\d.]+',
        ]
        for p in patterns:
            for m in re.finditer(p, doc, re.IGNORECASE):
                reqs.append(Requirement(
                    id=str(uuid.uuid4())[:8],
                    description=m.group(0),
                    constraint_kind=ConstraintKind.BOUNDARY,
                    source=SpecSource.DOCSTRING,
                    target_function=func,
                    target_file=path,
                    raw_spec_text=m.group(0),
                ))
        return reqs

    def _enums(self, doc: str, func: str, path: Path) -> list[Requirement]:
        reqs = []
        for m in re.finditer(
            r'(?:must be one of|one of|valid values?)[:\s]+([A-Z][A-Z,\s"\']+)',
            doc, re.IGNORECASE
        ):
            values = [
                v.strip().strip("\"'")
                for v in re.split(r'[,|]', m.group(1))
                if v.strip()
            ]
            if len(values) >= 2:
                reqs.append(Requirement(
                    id=str(uuid.uuid4())[:8],
                    description=f"must be one of {values}",
                    constraint_kind=ConstraintKind.ENUM_VALID,
                    source=SpecSource.DOCSTRING,
                    target_function=func,
                    target_file=path,
                    raw_spec_text=m.group(0),
                ))
        return reqs

    def _returns(self, doc: str, func: str, path: Path) -> list[Requirement]:
        reqs = []
        for m in re.finditer(r'Returns?:\s*\n\s*(.+)', doc, re.MULTILINE):
            desc = m.group(1).strip()
            if desc:
                reqs.append(Requirement(
                    id=str(uuid.uuid4())[:8],
                    description=f"returns {desc}",
                    constraint_kind=ConstraintKind.MUST_RETURN,
                    source=SpecSource.DOCSTRING,
                    target_function=func,
                    target_file=path,
                    raw_spec_text=desc,
                ))
        return reqs

    def _llm_fallback(self, doc: str, func: str, path: Path) -> list[Requirement]:
        # Implement with LLMClient when structured parsing finds nothing
        return []

    @property
    def source_name(self) -> str:
        return "docstring"
```

---

## quell/spec/type_reader.py

```python
"""
Reads Pydantic models and type annotations → extracts constraint Requirements.

Every type constraint is a testable requirement.
Quell reads what already exists — you wrote these types, not Quell.

Handled:
  Field(gt=0)                  → BOUNDARY: test value=0 raises ValidationError
  Literal["USD","EUR","GBP"]   → ENUM_VALID: test "JPY" raises ValidationError
  Field(min_length=1)          → BOUNDARY: test [] raises ValidationError
  Annotated[int, Field(ge=18)] → BOUNDARY: test 17 raises error

Why this matters vs Qodo/Copilot:
  They read your implementation and generate tests from what your code DOES.
  We read your types and generate tests from what your code SHOULD DO.
  If your code has a bug (missing validation), we still generate the right test.
"""
from __future__ import annotations
import ast, uuid
from pathlib import Path
from quell.core.models import Requirement, ConstraintKind, SpecSource

FIELD_VALIDATORS = {
    "gt", "ge", "lt", "le",
    "min_length", "max_length",
    "min_items", "max_items",
}


class TypeReader:
    def read(self, file_path: Path) -> list[Requirement]:
        try:
            tree = ast.parse(file_path.read_text(encoding="utf-8"))
        except Exception:
            return []

        reqs: list[Requirement] = []
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef) and self._is_pydantic(node):
                reqs.extend(self._from_model(node, file_path))
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                reqs.extend(self._from_function(node, file_path))
        return reqs

    def _is_pydantic(self, node: ast.ClassDef) -> bool:
        for base in node.bases:
            if isinstance(base, ast.Name) and base.id == "BaseModel":
                return True
            if isinstance(base, ast.Attribute) and base.attr == "BaseModel":
                return True
        return False

    def _from_model(self, cls: ast.ClassDef, path: Path) -> list[Requirement]:
        reqs: list[Requirement] = []
        for stmt in cls.body:
            if not isinstance(stmt, ast.AnnAssign):
                continue
            name = self._name(stmt.target)
            # Literal type → ENUM_VALID
            if self._is_literal(stmt.annotation):
                values = self._literal_values(stmt.annotation)
                if values:
                    reqs.append(Requirement(
                        id=str(uuid.uuid4())[:8],
                        description=f"{cls.name}.{name} must be one of {values}",
                        constraint_kind=ConstraintKind.ENUM_VALID,
                        source=SpecSource.TYPE,
                        target_function=cls.name,
                        target_file=path,
                        raw_spec_text=f"{name}: Literal{values}",
                    ))
            # Field validators → BOUNDARY
            if isinstance(stmt.value, ast.Call):
                for kw in stmt.value.keywords:
                    if kw.arg in FIELD_VALIDATORS:
                        val = (
                            ast.literal_eval(kw.value)
                            if isinstance(kw.value, ast.Constant)
                            else "?"
                        )
                        reqs.append(Requirement(
                            id=str(uuid.uuid4())[:8],
                            description=f"{cls.name}.{name} must satisfy {kw.arg}={val}",
                            constraint_kind=ConstraintKind.BOUNDARY,
                            source=SpecSource.TYPE,
                            target_function=cls.name,
                            target_file=path,
                            raw_spec_text=f"Field({kw.arg}={val})",
                        ))
        return reqs

    def _from_function(
        self, func: ast.FunctionDef, path: Path
    ) -> list[Requirement]:
        reqs: list[Requirement] = []
        for arg in func.args.args:
            if arg.annotation and self._is_literal(arg.annotation):
                values = self._literal_values(arg.annotation)
                if values:
                    reqs.append(Requirement(
                        id=str(uuid.uuid4())[:8],
                        description=f"param {arg.arg} must be one of {values}",
                        constraint_kind=ConstraintKind.ENUM_VALID,
                        source=SpecSource.TYPE,
                        target_function=func.name,
                        target_file=path,
                        raw_spec_text=f"{arg.arg}: Literal{values}",
                    ))
        return reqs

    def _is_literal(self, node: ast.expr) -> bool:
        if isinstance(node, ast.Subscript):
            v = node.value
            return (
                (isinstance(v, ast.Name) and v.id == "Literal") or
                (isinstance(v, ast.Attribute) and v.attr == "Literal")
            )
        return False

    def _literal_values(self, node: ast.Subscript) -> list:
        s = node.slice
        if isinstance(s, ast.Tuple):
            return [
                ast.literal_eval(e) for e in s.elts
                if isinstance(e, ast.Constant)
            ]
        if isinstance(s, ast.Constant):
            return [s.value]
        return []

    def _name(self, node: ast.expr) -> str:
        return node.id if isinstance(node, ast.Name) else "field"  # type: ignore

    @property
    def source_name(self) -> str:
        return "type"
```

---

## quell/spec/bug_reader.py

```python
"""
Reads natural language bug descriptions → BUG_REPRO Requirements.

This is "quell reproduce" — TDD from a bug report.

Flow:
1. LLM parses description → function hint + triggering inputs + expected behavior
2. Search codebase for matching function
3. Return BUG_REPRO Requirement

Verification engine then:
- Generates failing test (reproduces bug on current broken code)
- Verifies test FAILS now (bug confirmed)
- After dev fixes code: test PASSES (fix confirmed)

This is the ONLY tool that automates the full TDD bug-fixing loop.
"""
from __future__ import annotations
import ast, json, uuid
from pathlib import Path
from quell.core.models import Requirement, ConstraintKind, SpecSource


class BugReader:
    def __init__(self, llm_client, project_root: Path = Path(".")):
        self.llm = llm_client
        self.project_root = project_root

    def read_from_description(
        self,
        description: str,
        target_file: Path | None = None,
    ) -> list[Requirement]:
        """
        Parse a bug description and return BUG_REPRO Requirements.
        Called by: quell reproduce "bug description"
        """
        import asyncio
        bug_info = asyncio.run(self._extract(description))
        hint = bug_info.get("function_hint", "")

        if target_file:
            func, path = self._find_in_file(hint, target_file)
        else:
            func, path = self._search_codebase(hint)

        return [Requirement(
            id=str(uuid.uuid4())[:8],
            description=description,
            constraint_kind=ConstraintKind.BUG_REPRO,
            source=SpecSource.BUG_REPORT,
            target_function=func or hint or "unknown",
            target_file=path or target_file or self.project_root / "src" / "unknown.py",
            violation_input=bug_info.get("triggering_inputs"),
            expected_behavior=bug_info.get("expected_behavior"),
            raw_spec_text=description,
        )]

    def read(self, file_path: Path) -> list[Requirement]:
        return []  # protocol compliance — use read_from_description instead

    async def _extract(self, description: str) -> dict:
        prompt = f"""Parse this bug report. Return ONLY valid JSON, no other text.

Bug: "{description}"

{{"function_hint": "function name likely involved",
  "triggering_inputs": {{"param": value_or_null}},
  "symptom": "what goes wrong",
  "expected_behavior": "what should happen instead"}}"""
        try:
            response = await self.llm.generate(prompt)
            return json.loads(response)
        except Exception:
            return {}

    def _find_in_file(
        self, hint: str, path: Path
    ) -> tuple[str | None, Path | None]:
        try:
            tree = ast.parse(path.read_text())
            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    if hint.lower() in node.name.lower():
                        return node.name, path
        except Exception:
            pass
        return None, None

    def _search_codebase(
        self, hint: str
    ) -> tuple[str | None, Path | None]:
        for py in self.project_root.rglob("*.py"):
            if "test" in py.name or ".venv" in str(py):
                continue
            n, p = self._find_in_file(hint, py)
            if n:
                return n, p
        return None, None

    @property
    def source_name(self) -> str:
        return "bug_report"
```

---

## quell/spec/mutation_reader.py

```python
"""
Reads mutation testing results → MUTATION Requirements.

This is OPTIONAL. Quell works without mutmut or Stryker.
Enable with: enable_mutations = true in [tool.quell]

mutmut 3.x IMPORTANT NOTES:
- Version 3.5.0+ (Feb 2026), completely different from 2.x
- Requires Linux/Mac (NOT Windows — WSL only)
- Stores results in .mutmut-cache (SQLite)
- ALWAYS inspect schema at runtime: sqlite3 .mutmut-cache ".schema"
- Do NOT hardcode column names — they vary between versions
- mutmut-mcp (wdm0006/mutmut-mcp) already exists as MCP server for
  running mutation tests. Quell is DOWNSTREAM — we fix what mutmut finds.

Stryker: stable JSON schema, safe to parse directly.
"""
from __future__ import annotations
import sqlite3, json, uuid
from pathlib import Path
from quell.core.models import Requirement, ConstraintKind, SpecSource


class MutmutReader:
    """
    Reads mutmut 3.x survivors from .mutmut-cache SQLite.
    Windows users: mutmut requires WSL. Recommend using docstring/type
    readers instead which work natively on all platforms.
    """

    def __init__(self, project_root: Path = Path(".")):
        self.project_root = project_root
        self.db_path = project_root / ".mutmut-cache"

    def read(self, file_path: Path) -> list[Requirement]:
        return [
            r for r in self.read_all()
            if r.target_file == file_path.resolve()
        ]

    def read_all(self) -> list[Requirement]:
        if not self.db_path.exists():
            return []
        try:
            conn = sqlite3.connect(self.db_path)

            # Inspect schema at runtime — never hardcode
            tables = [
                t[0] for t in conn.execute(
                    "SELECT name FROM sqlite_master WHERE type='table'"
                ).fetchall()
            ]
            table = next(
                (t for t in ["MutantStatus", "mutants", "Mutant"] if t in tables),
                None,
            )
            if not table:
                conn.close()
                return []

            cols = [
                c[1] for c in
                conn.execute(f"PRAGMA table_info({table})").fetchall()
            ]
            rows = conn.execute(f"SELECT * FROM {table}").fetchall()
            conn.close()

            reqs = []
            for row in rows:
                d = dict(zip(cols, row))
                if "survived" not in str(d.get("status", "")).lower():
                    continue
                file_str = (
                    d.get("source_path") or d.get("file") or
                    d.get("filename") or "unknown"
                )
                reqs.append(Requirement(
                    id=str(d.get("id", uuid.uuid4()))[:8],
                    description=f"mutation survived: {d.get('mutation', '')}",
                    constraint_kind=ConstraintKind.MUTATION,
                    source=SpecSource.MUTATION,
                    target_function=str(d.get("function", "unknown")),
                    target_file=Path(file_str),
                    raw_spec_text=str(d.get("mutation", "")),
                ))
            return reqs
        except Exception:
            return []

    @property
    def source_name(self) -> str:
        return "mutation"


class StrykerReader:
    """Reads Stryker mutation-report.json. Schema is stable."""

    def __init__(
        self,
        report_path: Path = Path("reports/mutation/mutation.json"),
    ):
        self.report_path = report_path

    def read(self, file_path: Path) -> list[Requirement]:
        if not self.report_path.exists():
            return []
        try:
            data = json.loads(self.report_path.read_text())
            reqs = []
            for fp_str, fd in data.get("files", {}).items():
                if Path(fp_str).resolve() != file_path.resolve():
                    continue
                for m in fd.get("mutants", []):
                    if m.get("status") != "Survived":
                        continue
                    reqs.append(Requirement(
                        id=str(m["id"])[:8],
                        description=f"mutation survived: {m.get('mutatorName', '')}",
                        constraint_kind=ConstraintKind.MUTATION,
                        source=SpecSource.MUTATION,
                        target_function="unknown",
                        target_file=file_path.resolve(),
                        raw_spec_text=m.get("replacement", ""),
                    ))
            return reqs
        except Exception:
            return []

    @property
    def source_name(self) -> str:
        return "stryker"
```

---

## quell/core/verifier.py — THE MOAT

```python
"""
Verification Engine — the core technical moat.

This is what separates Quell from every competitor:
  Qodo generates tests. Quell PROVES them.
  Copilot suggests tests. Quell VERIFIES them.

Algorithm:
  1. Write candidate test to TEMP file (not real test file)
  2. Run test on ORIGINAL source → MUST PASS
     (if it fails, the test is wrong — bad test, reject)
  3. Inject VIOLATION into source (break the requirement)
  4. Run test on VIOLATED source → MUST FAIL
     (if it passes, test doesn't catch the bug — weak test, reject)
  5. ALWAYS restore source in finally block
  6. Return VerificationResult

Violation injection per ConstraintKind:
  MUST_RAISE:   comment out the raise statement
  BOUNDARY:     weaken threshold (> 0 → > -9999)
  ENUM_VALID:   remove the enum validation guard
  MUST_RETURN:  change return value to None
  BUG_REPRO:    no injection needed — source is already broken
  MUTATION:     use mutmut apply or direct line replacement

ABSOLUTE RULES — never violate:
- ALWAYS restore source in finally block
- ALWAYS use subprocess for pytest — never in-process (module cache)
- NEVER skip verification for performance — optimize test speed instead
- NEVER add --skip-verification flag
"""
from __future__ import annotations
import subprocess, shutil, time, re
from pathlib import Path
from quell.core.models import (
    Requirement, GeneratedTest, VerificationResult,
    VerificationStatus, ConstraintKind, QuellConfig,
)


class Verifier:
    def __init__(self, config: QuellConfig):
        self.config = config
        self.backup_dir = config.backup_dir
        self.backup_dir.mkdir(parents=True, exist_ok=True)

    def verify(
        self, req: Requirement, test: GeneratedTest
    ) -> VerificationResult:
        start = time.time()
        temp = self._write_temp(test)
        bak = self._backup(req.target_file)

        try:
            # Step 1: test must PASS on correct code
            orig = self._pytest(temp, req.target_file)
            if not orig["passed"]:
                return VerificationResult(
                    requirement_id=req.id, generated_test=test,
                    status=VerificationStatus.FAILS_ON_CORRECT,
                    error_message=orig.get("stderr", ""),
                    duration_ms=self._ms(start),
                )

            # Step 2: inject violation
            self._violate(req)

            # Step 3: test must FAIL on violated code
            viol = self._pytest(temp, req.target_file)
            status = (
                VerificationStatus.VERIFIED if not viol["passed"]
                else VerificationStatus.DOESNT_CATCH_VIOLATION
            )
            return VerificationResult(
                requirement_id=req.id, generated_test=test,
                status=status,
                duration_ms=self._ms(start),
            )

        except TimeoutError:
            return VerificationResult(
                requirement_id=req.id, generated_test=test,
                status=VerificationStatus.TIMEOUT,
                duration_ms=self.config.verification_timeout_seconds * 1000,
            )
        except Exception as e:
            return VerificationResult(
                requirement_id=req.id, generated_test=test,
                status=VerificationStatus.ERROR,
                error_message=str(e),
                duration_ms=self._ms(start),
            )
        finally:
            # ALWAYS restore — no exceptions to this rule
            self._restore(req.target_file, bak)
            temp.unlink(missing_ok=True)

    def _write_temp(self, test: GeneratedTest) -> Path:
        d = self.backup_dir / "temp"
        d.mkdir(parents=True, exist_ok=True)
        f = d / f"quell_{test.requirement_id}.py"
        f.write_text(test.test_code)
        return f

    def _backup(self, src: Path) -> Path:
        bak = self.backup_dir / f"{src.stem}_{int(time.time())}.bak"
        shutil.copy2(src, bak)
        return bak

    def _restore(self, src: Path, bak: Path) -> None:
        if bak.exists():
            shutil.copy2(bak, src)
            bak.unlink()

    def _violate(self, req: Requirement) -> None:
        """Modify source to break the requirement so a good test will fail."""
        if req.constraint_kind == ConstraintKind.BUG_REPRO:
            return  # already broken

        src = req.target_file.read_text()

        if req.constraint_kind == ConstraintKind.MUST_RAISE:
            modified = re.sub(
                r'(\s+)(raise \w+)', r'\1# QUELL_VIOLATION \2', src, count=1
            )
        elif req.constraint_kind == ConstraintKind.BOUNDARY:
            modified = re.sub(
                r'((?:>|>=|<|<=)\s*)(\d+)',
                lambda m: m.group(1) + "-9999",
                src, count=1,
            )
        elif req.constraint_kind == ConstraintKind.MUST_RETURN:
            modified = re.sub(
                r'return (?!None)', 'return None  # QUELL_VIOLATION ', src, count=1
            )
        elif req.constraint_kind == ConstraintKind.MUTATION:
            try:
                subprocess.run(
                    ["mutmut", "apply", req.id],
                    capture_output=True, timeout=10,
                    cwd=req.target_file.parent,
                )
            except Exception:
                pass
            return
        else:
            return  # CUSTOM — LLM handles injection in llm_engine

        req.target_file.write_text(modified)

    def _pytest(self, test_file: Path, src: Path) -> dict:
        try:
            r = subprocess.run(
                ["python", "-m", "pytest", str(test_file),
                 "-v", "--tb=short", "-q", "--no-header"],
                capture_output=True, text=True,
                timeout=self.config.verification_timeout_seconds,
                cwd=src.parent.parent,
            )
            return {
                "passed": r.returncode == 0,
                "stdout": r.stdout,
                "stderr": r.stderr,
            }
        except subprocess.TimeoutExpired:
            raise TimeoutError()

    def _ms(self, start: float) -> int:
        return int((time.time() - start) * 1000)
```

---

## quell/core/writer.py

```python
"""
Writes verified tests via libcst. Never string concatenation.
Always backs up. Always restores on failure. Always validates CST.
"""
from __future__ import annotations
import shutil, time
import libcst as cst
from pathlib import Path
from quell.core.models import (
    GeneratedTest, QuellConfig, AuditEntry, VerificationStatus
)


class Writer:
    def __init__(self, config: QuellConfig):
        self.config = config
        config.audit_log_path.parent.mkdir(parents=True, exist_ok=True)

    def write(self, test: GeneratedTest, req_id: str) -> bool:
        f = test.test_file_path
        if not f.exists():
            f.parent.mkdir(parents=True, exist_ok=True)
            f.write_text("# Generated by Quell\nimport pytest\n\n")

        bak = f.with_suffix(f".{int(time.time())}.bak")
        shutil.copy2(f, bak)

        try:
            new_src = self._inject(f.read_text(), test.test_code)
            cst.parse_module(new_src)  # validate before writing
            f.write_text(new_src)
            bak.unlink()
            self._log(AuditEntry(
                requirement_id=req_id, action="test_written",
                file_path=f,
                test_function_name=test.test_function_name,
                verification_status=VerificationStatus.VERIFIED,
            ))
            return True
        except Exception:
            if bak.exists():
                shutil.copy2(bak, f)
                bak.unlink()
            self._log(AuditEntry(
                requirement_id=req_id, action="write_failed", file_path=f,
            ))
            return False

    def _inject(self, existing: str, new_code: str) -> str:
        module = cst.parse_module(existing)
        new_stmts = cst.parse_module(new_code).body
        return module.with_changes(
            body=list(module.body) + list(new_stmts)
        ).code

    def _log(self, entry: AuditEntry) -> None:
        with self.config.audit_log_path.open("a") as f:
            f.write(entry.model_dump_json() + "\n")
```

---

## quell/coverage/checker.py

```python
"""
Checks which Requirements already have tests in the test suite.
Uses AST — no test execution required.

Conservative: marks as uncovered when uncertain.
Better to generate a duplicate test than miss a real gap.
"""
from __future__ import annotations
import ast
from pathlib import Path
from quell.core.models import Requirement, ConstraintKind


class CoverageChecker:
    def __init__(self, project_root: Path = Path(".")):
        self.project_root = project_root
        self._cache: dict[Path, list[ast.FunctionDef]] = {}

    def check(self, requirements: list[Requirement]) -> list[Requirement]:
        """Mark each Requirement is_covered=True/False. Returns same list."""
        for req in requirements:
            test_file = self._test_file(req.target_file)
            if test_file:
                funcs = self._get_tests(test_file)
                covering = self._find_covering(req, funcs)
                req.is_covered = len(covering) > 0
                req.covering_tests = covering
            else:
                req.is_covered = False
                req.covering_tests = []
        return requirements

    def _test_file(self, src: Path) -> Path | None:
        stem = src.stem
        for candidate in [
            self.project_root / "tests" / f"test_{stem}.py",
            self.project_root / "tests" / f"{stem}_test.py",
            src.parent / f"test_{stem}.py",
        ]:
            if candidate.exists():
                return candidate
        return None

    def _get_tests(self, f: Path) -> list[ast.FunctionDef]:
        if f in self._cache:
            return self._cache[f]
        try:
            tree = ast.parse(f.read_text())
            funcs = [
                n for n in ast.walk(tree)
                if isinstance(n, ast.FunctionDef) and n.name.startswith("test_")
            ]
            self._cache[f] = funcs
            return funcs
        except Exception:
            return []

    def _find_covering(
        self, req: Requirement, funcs: list[ast.FunctionDef]
    ) -> list[str]:
        covering = []
        for func in funcs:
            # Must mention the target function
            if req.target_function.lower() not in func.name.lower():
                doc = ast.get_docstring(func) or ""
                if req.target_function.lower() not in doc.lower():
                    continue
            # BUG_REPRO: never mark as covered (always regenerate)
            if req.constraint_kind == ConstraintKind.BUG_REPRO:
                continue
            # MUST_RAISE: check for pytest.raises
            if req.constraint_kind == ConstraintKind.MUST_RAISE:
                if self._has_raises(func):
                    covering.append(func.name)
            # BOUNDARY: check for boundary values
            elif req.constraint_kind == ConstraintKind.BOUNDARY:
                if self._has_boundary(func):
                    covering.append(func.name)
            else:
                covering.append(func.name)  # conservative: assume covered
        return covering

    def _has_raises(self, func: ast.FunctionDef) -> bool:
        for node in ast.walk(func):
            if isinstance(node, ast.With):
                for item in node.items:
                    call = item.context_expr
                    if isinstance(call, ast.Call):
                        name = (
                            getattr(call.func, "id", None) or
                            getattr(call.func, "attr", None)
                        )
                        if name == "raises":
                            return True
        return False

    def _has_boundary(self, func: ast.FunctionDef) -> bool:
        for node in ast.walk(func):
            if isinstance(node, ast.Constant):
                if node.value in (0, -1, 1, 0.0, -1.0, 1.0):
                    return True
        return False
```

---

## quell/synthesis/rule_engine.py

```python
"""
Rule-based test generation. Fast, deterministic, no LLM.
Handles the majority of common cases.

Rule per ConstraintKind:
  MUST_RAISE   → pytest.raises() test with violating input
  BOUNDARY     → test with boundary value (0, -1, etc.)
  ENUM_VALID   → test with invalid enum value
  MUST_RETURN  → test with exact value assertion (not just 'is not None')
  BUG_REPRO    → test that should currently FAIL (bug exists)
  MUTATION     → boundary/comparison test

LLM engine handles: CUSTOM, complex MUTATION, anything rule can't generate.
"""
from __future__ import annotations
import re
from pathlib import Path
from quell.core.models import (
    Requirement, GeneratedTest, ConstraintKind
)


class RuleEngine:
    def can_handle(self, req: Requirement) -> bool:
        return req.constraint_kind in {
            ConstraintKind.MUST_RAISE,
            ConstraintKind.BOUNDARY,
            ConstraintKind.ENUM_VALID,
            ConstraintKind.MUST_RETURN,
            ConstraintKind.BUG_REPRO,
        }

    def generate(self, req: Requirement) -> GeneratedTest | None:
        if req.constraint_kind == ConstraintKind.MUST_RAISE:
            return self._must_raise(req)
        if req.constraint_kind == ConstraintKind.BOUNDARY:
            return self._boundary(req)
        if req.constraint_kind == ConstraintKind.ENUM_VALID:
            return self._enum(req)
        if req.constraint_kind == ConstraintKind.MUST_RETURN:
            return self._must_return(req)
        if req.constraint_kind == ConstraintKind.BUG_REPRO:
            return self._bug_repro(req)
        return None

    def _test_file(self, req: Requirement) -> Path:
        return (
            req.target_file.parent.parent / "tests" /
            f"test_{req.target_file.stem}.py"
        )

    def _name(self, req: Requirement) -> str:
        func = re.sub(r'[^a-z0-9_]', '_', req.target_function.lower())
        return f"test_quell_{func}_{req.id}"

    def _must_raise(self, req: Requirement) -> GeneratedTest:
        exc = "Exception"
        if req.expected_behavior:
            m = re.search(r'raises (\w+)', req.expected_behavior)
            if m:
                exc = m.group(1)

        name = self._name(req)
        code = f'''def {name}():
    """
    Quell: {req.description}
    Source: {req.source.value} — {req.raw_spec_text or ""}
    """
    import pytest
    # TODO: call {req.target_function} with input that violates: {req.description}
    # Example: with pytest.raises({exc}):
    #     {req.target_function}(<violating_input>)
    raise NotImplementedError(
        "Complete: call {req.target_function} with invalid input, "
        "assert it raises {exc}"
    )
'''
        return GeneratedTest(
            requirement_id=req.id,
            test_function_name=name,
            test_code=code,
            test_file_path=self._test_file(req),
            explanation=f"pytest.raises({exc}) test for: {req.description}",
            generated_by="rule_engine",
        )

    def _boundary(self, req: Requirement) -> GeneratedTest:
        name = self._name(req)
        # Infer boundary value from description
        boundary_val = "0"
        if "positive" in req.description.lower() or "> 0" in req.description:
            boundary_val = "0"
        elif ">= 1" in req.description or "at least 1" in req.description.lower():
            boundary_val = "0"
        elif "between 0 and 100" in req.description.lower():
            boundary_val = "-1"

        code = f'''def {name}():
    """
    Quell: {req.description}
    Source: {req.source.value} — {req.raw_spec_text or ""}
    
    Boundary test: the violation is passing value={boundary_val}
    """
    import pytest
    # TODO: call {req.target_function} with boundary value {boundary_val}
    # This should raise an error or return a different result than valid input
    raise NotImplementedError(
        "Complete: call {req.target_function}(<input with {boundary_val} "
        "for the constrained param>), assert it's rejected"
    )
'''
        return GeneratedTest(
            requirement_id=req.id,
            test_function_name=name,
            test_code=code,
            test_file_path=self._test_file(req),
            explanation=f"Boundary test at value={boundary_val}: {req.description}",
            generated_by="rule_engine",
        )

    def _enum(self, req: Requirement) -> GeneratedTest:
        name = self._name(req)
        # Extract valid values from description to suggest an invalid one
        invalid = "INVALID_VALUE"

        code = f'''def {name}():
    """
    Quell: {req.description}
    Source: {req.source.value} — {req.raw_spec_text or ""}
    
    Enum test: passing a value NOT in the allowed set should be rejected.
    """
    import pytest
    # TODO: call {req.target_function} with an invalid enum value
    # Example: with pytest.raises((ValueError, ValidationError)):
    #     {req.target_function}(<param>="{invalid}")
    raise NotImplementedError(
        "Complete: pass an invalid value for the enum parameter, "
        "assert it's rejected with an error"
    )
'''
        return GeneratedTest(
            requirement_id=req.id,
            test_function_name=name,
            test_code=code,
            test_file_path=self._test_file(req),
            explanation=f"Enum violation test: {req.description}",
            generated_by="rule_engine",
        )

    def _must_return(self, req: Requirement) -> GeneratedTest:
        name = self._name(req)
        code = f'''def {name}():
    """
    Quell: {req.description}
    Source: {req.source.value} — {req.raw_spec_text or ""}
    
    Return value test: assert EXACT return value, not just "is not None".
    """
    # TODO: call {req.target_function} with valid inputs
    # result = {req.target_function}(...)
    # assert result is not None
    # assert <specific field or value check>  ← be precise here
    raise NotImplementedError(
        "Complete: call {req.target_function}, assert exact return value"
    )
'''
        return GeneratedTest(
            requirement_id=req.id,
            test_function_name=name,
            test_code=code,
            test_file_path=self._test_file(req),
            explanation=f"Return value test: {req.description}",
            generated_by="rule_engine",
        )

    def _bug_repro(self, req: Requirement) -> GeneratedTest:
        name = self._name(req)
        inputs_hint = str(req.violation_input) if req.violation_input else "<triggering_input>"
        expected = req.expected_behavior or "raise an error or return correct value"

        code = f'''def {name}():
    """
    Quell bug reproduction: {req.description}
    
    This test should FAIL on current code (bug exists).
    After fixing the bug, this test should PASS.
    Inputs that trigger the bug: {inputs_hint}
    Expected behavior: {expected}
    """
    import pytest
    # TODO: call {req.target_function} with: {inputs_hint}
    # Assert the CORRECT behavior (what SHOULD happen, not what currently happens)
    raise NotImplementedError(
        "Complete: reproduce the bug — call {req.target_function} "
        "with {inputs_hint}, assert {expected}"
    )
'''
        return GeneratedTest(
            requirement_id=req.id,
            test_function_name=name,
            test_code=code,
            test_file_path=self._test_file(req),
            explanation=f"Bug reproduction: {req.description}",
            generated_by="rule_engine",
        )
```

---

## quell/synthesis/llm_engine.py

```python
"""
LLM-based test generation. Used when rule engine cannot handle the case.

Called for: CUSTOM constraints, complex mutations, unstructured specs,
and to complete/improve rule-engine scaffolding into real test code.

Key principle: the LLM generates the test code, but the VERIFIER
proves it works before it's accepted. LLM hallucinations are caught
by verification — not a blocker, just a retry trigger.
"""
from __future__ import annotations
import re
from quell.core.models import Requirement, GeneratedTest, QuellConfig
from quell.llm.client import LLMClient
from quell.llm.prompts import build_prompt


class LLMSynthesizer:
    def __init__(self, client: LLMClient, config: QuellConfig):
        self.client = client
        self.config = config

    async def synthesize(self, req: Requirement) -> GeneratedTest:
        prompt = build_prompt(req)
        response = await self.client.generate(prompt)
        code = self._extract_code(response)
        name = self._extract_name(code) or f"test_quell_{req.target_function}_{req.id}"

        return GeneratedTest(
            requirement_id=req.id,
            test_function_name=name,
            test_code=code,
            test_file_path=(
                req.target_file.parent.parent / "tests" /
                f"test_{req.target_file.stem}.py"
            ),
            explanation=f"LLM-generated test for: {req.description}",
            generated_by=f"llm:{self.config.llm_model}",
        )

    def _extract_code(self, response: str) -> str:
        m = re.search(r'```python\n(.*?)```', response, re.DOTALL)
        return m.group(1).strip() if m else response.strip()

    def _extract_name(self, code: str) -> str | None:
        m = re.search(r'^def\s+(test_\w+)', code, re.MULTILINE)
        return m.group(1) if m else None
```

---

## quell/llm/prompts.py

```python
"""All prompt templates for LLM-based test generation."""
from quell.core.models import Requirement, ConstraintKind


def build_prompt(req: Requirement) -> str:
    return f"""You are an expert Python test engineer. Write a pytest test function that PROVES a specific requirement holds.

REQUIREMENT:
  Description: {req.description}
  Type: {req.constraint_kind.value}
  Function: {req.target_function}
  File: {req.target_file.name}
  Source spec: {req.raw_spec_text or "not available"}
  Violation input: {req.violation_input or "infer from description"}
  Expected behavior: {req.expected_behavior or "infer from description"}

RULES FOR YOUR TEST:
1. Function name MUST start with test_quell_
2. Must PASS on correct code that satisfies the requirement
3. Must FAIL when the requirement is violated
4. Use SPECIFIC assertions — never "assert result is not None" alone
5. For raises requirements: use pytest.raises(ExceptionType)
6. Add a docstring explaining what requirement this proves

Output ONLY a Python code block. No explanation outside the block.

```python
def test_quell_{req.target_function}_{req.id}():
    \"\"\"Proves: {req.description}\"\"\"
    # your test here
```"""
```

---

## quell/llm/client.py

```python
"""Abstract LLM client + factory."""
from __future__ import annotations
from abc import ABC, abstractmethod
from quell.core.models import QuellConfig


class LLMClient(ABC):
    @abstractmethod
    async def generate(self, prompt: str) -> str: ...

    @classmethod
    def from_config(cls, config: QuellConfig) -> "LLMClient":
        from quell.llm.providers.anthropic_provider import AnthropicProvider
        from quell.llm.providers.openai_provider import OpenAIProvider
        from quell.llm.providers.ollama_provider import OllamaProvider
        return {
            "anthropic": AnthropicProvider,
            "openai": OpenAIProvider,
            "ollama": OllamaProvider,
        }[config.llm_provider](config)
```

---

## quell/llm/providers/anthropic_provider.py

```python
from quell.llm.client import LLMClient
from quell.core.models import QuellConfig
import anthropic


class AnthropicProvider(LLMClient):
    def __init__(self, config: QuellConfig):
        self.client = anthropic.Anthropic()  # reads ANTHROPIC_API_KEY
        self.model = config.llm_model

    async def generate(self, prompt: str) -> str:
        msg = self.client.messages.create(
            model=self.model, max_tokens=1024,
            messages=[{"role": "user", "content": prompt}],
        )
        return msg.content[0].text
```

---

## quell/llm/providers/ollama_provider.py

```python
"""Local LLM — zero API key, privacy-first. Works offline."""
import httpx
from quell.llm.client import LLMClient
from quell.core.models import QuellConfig


class OllamaProvider(LLMClient):
    def __init__(self, config: QuellConfig):
        self.base_url = config.ollama_base_url
        self.model = config.llm_model  # e.g. "codellama", "deepseek-coder"

    async def generate(self, prompt: str) -> str:
        async with httpx.AsyncClient(timeout=60.0) as c:
            r = await c.post(
                f"{self.base_url}/api/generate",
                json={"model": self.model, "prompt": prompt, "stream": False},
            )
            r.raise_for_status()
            return r.json()["response"]
```

---

## quell/llm/providers/openai_provider.py

```python
from openai import AsyncOpenAI
from quell.llm.client import LLMClient
from quell.core.models import QuellConfig


class OpenAIProvider(LLMClient):
    def __init__(self, config: QuellConfig):
        self.client = AsyncOpenAI()  # reads OPENAI_API_KEY
        self.model = config.llm_model

    async def generate(self, prompt: str) -> str:
        r = await self.client.chat.completions.create(
            model=self.model, max_tokens=1024,
            messages=[{"role": "user", "content": prompt}],
        )
        return r.choices[0].message.content or ""
```

---

## quell/score/calculator.py

```python
"""
Calculates Quell Score — requirement coverage per file/project.

Quell Score = covered_requirements / total_requirements

Stronger than coverage% because it measures whether your tests
prove the code meets its specification, not just that lines ran.
"""
from __future__ import annotations
from pathlib import Path
from quell.core.models import ProjectScore, FileScore
from quell.spec.docstring_reader import DocstringReader
from quell.spec.type_reader import TypeReader
from quell.coverage.checker import CoverageChecker


def calculate_score(project_root: Path = Path(".")) -> ProjectScore:
    """Scan all source files and calculate requirement coverage."""
    src_dirs = [
        project_root / "src",
        project_root / "app",
        project_root,
    ]
    py_files = []
    for d in src_dirs:
        if d.exists():
            py_files.extend([
                f for f in d.rglob("*.py")
                if "test" not in f.name and ".venv" not in str(f)
                and "CLAUDE" not in f.name
            ])
    if not py_files:
        return ProjectScore()

    checker = CoverageChecker(project_root)
    file_scores = []

    for f in py_files:
        reqs = []
        reqs.extend(DocstringReader().read(f))
        reqs.extend(TypeReader().read(f))
        if not reqs:
            continue
        reqs = checker.check(reqs)
        total = len(reqs)
        covered = sum(1 for r in reqs if r.is_covered)
        file_scores.append(FileScore(
            file_path=f,
            total_requirements=total,
            covered_requirements=covered,
            quell_score=covered / total if total else 0.0,
        ))

    return ProjectScore(files=sorted(file_scores, key=lambda x: x.quell_score))
```

---

## quell/score/badge.py

```python
"""Generates shields.io-style SVG badge for README embedding."""


def generate_badge(score: float) -> str:
    pct = int(score * 100)
    color = "#4c1" if score >= 0.80 else "#dfb317" if score >= 0.60 else "#e05d44"
    label, value = "quell score", f"{pct}%"
    lw = len(label) * 6 + 10
    vw = len(value) * 6 + 10
    tw = lw + vw
    return f'''<svg xmlns="http://www.w3.org/2000/svg" width="{tw}" height="20">
  <linearGradient id="s" x2="0" y2="100%">
    <stop offset="0" stop-color="#bbb" stop-opacity=".1"/>
    <stop offset="1" stop-opacity=".1"/>
  </linearGradient>
  <clipPath id="r"><rect width="{tw}" height="20" rx="3" fill="#fff"/></clipPath>
  <g clip-path="url(#r)">
    <rect width="{lw}" height="20" fill="#555"/>
    <rect x="{lw}" width="{vw}" height="20" fill="{color}"/>
    <rect width="{tw}" height="20" fill="url(#s)"/>
  </g>
  <g fill="#fff" text-anchor="middle"
     font-family="DejaVu Sans,Verdana,Geneva,sans-serif" font-size="11">
    <text x="{lw//2}" y="14" fill="#010101" fill-opacity=".3">{label}</text>
    <text x="{lw//2}" y="13">{label}</text>
    <text x="{lw + vw//2}" y="14" fill="#010101" fill-opacity=".3">{value}</text>
    <text x="{lw + vw//2}" y="13">{value}</text>
  </g>
</svg>'''
```

---

## quell/sdk.py

```python
"""
Programmatic API. Use in CI scripts, MCP servers, other tools.

from quell import Quell
q = Quell()
q.check("src/")                    # find gaps
q.check("src/", fix=True)          # find + fix
q.reproduce("zero amount accepted") # bug → test
q.prove("src/payments.py")         # confidence score
q.score()                           # project score
"""
from __future__ import annotations
import asyncio
from dataclasses import dataclass
from pathlib import Path
from quell.core.models import Requirement, ProjectScore, QuellConfig


@dataclass
class CheckResult:
    requirements: list[Requirement]
    score: float

    @property
    def uncovered(self) -> list[Requirement]:
        return [r for r in self.requirements if not r.is_covered]

    @property
    def covered(self) -> list[Requirement]:
        return [r for r in self.requirements if r.is_covered]


class Quell:
    def __init__(
        self,
        llm: str = "anthropic",
        model: str | None = None,
        project_root: str | Path = ".",
    ):
        self.config = QuellConfig(llm_provider=llm)
        if model:
            self.config = self.config.model_copy(update={"llm_model": model})
        self.root = Path(project_root)

    def check(
        self,
        target: str | Path,
        sources: list[str] | None = None,
        fix: bool = False,
    ) -> CheckResult:
        return asyncio.run(
            self._check(Path(target), sources or ["docstring", "type"], fix)
        )

    def reproduce(self, description: str, file: str | Path | None = None) -> bool:
        return asyncio.run(
            self._reproduce(description, Path(file) if file else None)
        )

    def prove(self, file: str | Path, function: str | None = None) -> float:
        result = self.check(file)
        reqs = (
            [r for r in result.requirements if r.target_function == function]
            if function else result.requirements
        )
        total = len(reqs)
        return sum(1 for r in reqs if r.is_covered) / total if total else 0.0

    def score(self) -> ProjectScore:
        from quell.score.calculator import calculate_score
        return calculate_score(self.root)

    async def _check(
        self, target: Path, sources: list[str], fix: bool
    ) -> CheckResult:
        from quell.spec.docstring_reader import DocstringReader
        from quell.spec.type_reader import TypeReader
        from quell.coverage.checker import CoverageChecker
        from quell.llm.client import LLMClient

        llm = LLMClient.from_config(self.config)
        files = (
            [
                f for f in target.rglob("*.py")
                if "test" not in f.name and ".venv" not in str(f)
            ]
            if target.is_dir() else [target]
        )
        reqs: list[Requirement] = []
        for f in files:
            if "docstring" in sources:
                reqs.extend(DocstringReader(llm).read(f))
            if "type" in sources:
                reqs.extend(TypeReader().read(f))

        reqs = CoverageChecker(self.root).check(reqs)
        total = len(reqs)
        covered = sum(1 for r in reqs if r.is_covered)
        return CheckResult(
            requirements=reqs,
            score=covered / total if total else 0.0,
        )

    async def _reproduce(
        self, description: str, target_file: Path | None
    ) -> bool:
        from quell.spec.bug_reader import BugReader
        from quell.synthesis.llm_engine import LLMSynthesizer
        from quell.core.verifier import Verifier
        from quell.core.writer import Writer
        from quell.core.models import VerificationStatus
        from quell.llm.client import LLMClient

        llm = LLMClient.from_config(self.config)
        reqs = BugReader(llm, self.root).read_from_description(
            description, target_file
        )
        if not reqs:
            return False
        req = reqs[0]
        test = await LLMSynthesizer(llm, self.config).synthesize(req)
        result = Verifier(self.config).verify(req, test)
        if result.status == VerificationStatus.VERIFIED:
            Writer(self.config).write(test, req.id)
            return True
        return False
```

---

## quell/__init__.py

```python
"""
Quell — Your docstrings say what your code should do. Quell proves it.

Quick start:
    from quell import Quell
    q = Quell()
    result = q.check("src/")
    print(f"Score: {result.score:.0%} | Gaps: {len(result.uncovered)}")
"""
__version__ = "0.1.0"
__author__ = "Shashank Bindal"

from quell.sdk import Quell, CheckResult
from quell.core.models import (
    Requirement, ConstraintKind, SpecSource,
    GeneratedTest, VerificationResult, VerificationStatus,
    QuellConfig, ProjectScore, FileScore,
)

__all__ = [
    "Quell", "CheckResult",
    "Requirement", "ConstraintKind", "SpecSource",
    "GeneratedTest", "VerificationResult", "VerificationStatus",
    "QuellConfig", "ProjectScore", "FileScore",
]
```

---

## CLI Commands (quell/cli.py) — Summary

Implement these Typer commands:

```python
@app.command("check")    # scan specs, find gaps, optionally fix
@app.command("reproduce") # bug description → failing test
@app.command("prove")    # confidence score for a function/file
@app.command("score")    # project-wide Quell Score + --badge
@app.command("ci")       # CI mode: check + threshold + exit code
@app.command("init")     # add [tool.quell] to pyproject.toml
```

Each command uses Rich panels, progress bars, colored diffs.
See the architecture above for what each command does internally.
The CI command must: exit 0 if score >= threshold, exit 1 if below.

---

## Sample Fixture: tests/fixtures/sample_project/src/payments.py

```python
"""
Sample project for Quell integration tests.
Rich docstrings + Pydantic model — exercises all readers.
"""
from typing import Literal
from pydantic import BaseModel, Field


class PaymentRequest(BaseModel):
    """Pydantic model — TypeReader extracts 3 requirements from this."""
    amount: float = Field(gt=0)
    currency: Literal["USD", "EUR", "GBP"]
    description: str = Field(min_length=1, max_length=500)


def process_payment(request: PaymentRequest) -> dict:
    """
    Process a payment transaction.

    Args:
        request: PaymentRequest. Amount must be greater than 0.
                 Currency must be one of: USD, EUR, GBP.

    Returns:
        dict with transaction_id (str), status ("completed"), amount (float).

    Raises:
        ValueError: If amount is zero or negative.
        ValueError: If currency is not supported.
    """
    if request.amount <= 0:
        raise ValueError(f"Amount must be positive, got {request.amount}")
    return {
        "transaction_id": "txn_12345",
        "status": "completed",
        "amount": request.amount,
    }


def apply_discount(price: float, percentage: float) -> float:
    """
    Apply percentage discount to price.

    Args:
        price: Must be positive.
        percentage: Must be between 0 and 100 inclusive.

    Returns:
        Discounted price as float.

    Raises:
        ValueError: If percentage not between 0 and 100.
        ValueError: If price is negative.
    """
    if not 0 <= percentage <= 100:
        raise ValueError(f"Percentage must be 0-100, got {percentage}")
    if price < 0:
        raise ValueError(f"Price cannot be negative")
    return price * (1 - percentage / 100)
```

---

## Architecture Rules — Absolute, Never Violate

| Rule | Reason |
|------|--------|
| `verifier.py` always restores source in `finally` | User codebase is sacred |
| `writer.py` always backs up, validates CST, restores on failure | Writes must be reversible |
| All file writes via libcst — never string replace | Preserves comments, formatting |
| pytest always in subprocess — never in-process | Module cache breaks mutation testing |
| Every spec reader returns `[]` on error | One bad file must not break the run |
| Coverage checker marks uncertain as uncovered | Prefer duplicate test over missed gap |
| LLM called only when rule engine fails | Speed + cost + determinism |
| Ollama works with zero API keys | Security-conscious teams need local option |
| `enable_mutations = false` by default | mutmut not required — Windows users unblocked |

---

## What Quell Does NOT Do (Non-Goals)

- Does NOT generate tests from scratch for uncovered lines (that's Qodo/Copilot)
- Does NOT replace pytest, Hypothesis, or mutation testing tools
- Does NOT do E2E or integration testing — unit/function level only
- Does NOT require mutmut or Stryker — they're optional bonus features
- Does NOT send code to external servers unless user configures LLM provider

---

## Running the Project

```bash
pip install uv
uv sync --dev

uv run quell --help
uv run quell check tests/fixtures/sample_project/src/
uv run quell reproduce "payment accepts zero amount"
uv run quell prove tests/fixtures/sample_project/src/payments.py
uv run quell score --badge

uv run pytest tests/ -v
uv run ruff check . --fix
uv run mypy quell/
```

---

## Marketing Angles (Reference When Writing Docs/README)

**Against Qodo:** "Qodo reads your implementation and generates tests for what your code does. If your code has a bug, Qodo generates tests that bless it. Quell reads your specification and generates tests for what your code should do — catching the bug."

**Against Copilot:** "Copilot generates a test. You don't know if it's actually verifying the right thing. Quell proves every test it writes actually catches violations before touching your files."

**Against Hypothesis:** "Hypothesis is powerful, but you have to write the spec manually. Your docstring already says 'amount must be positive'. Quell reads that and writes the test automatically."

**The one thing nobody else does:** Prove a test catches violations before writing it to disk.