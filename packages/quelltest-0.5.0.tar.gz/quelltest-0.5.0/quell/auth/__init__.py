"""Quell authentication."""
