# ADR 0002: Anchoring stack — Sigstore Rekor + RFC 3161 TSAs

**Status:** Accepted, 2026-04-21.
**Decider:** Mark Hallam.

## Context

Envelopes must be publicly verifiable after issuance, including against
attempts by the issuer to rewrite history. A public transparency log plus
independent timestamping gives us that property without a central trust root.

Two alternatives were considered:
1. OpenTimestamps (Bitcoin-anchored).
2. A single CT-style operator log.

## Decision

Primary transparency anchor: **Sigstore Rekor** (public instance
`rekor.sigstore.dev`, operated by Linux Foundation / OpenSSF).
Secondary: **two independent RFC 3161 Time-Stamp Authorities** (FreeTSA +
DigiCert) for redundant, ISO-standard, court-admissible timestamps.

## Consequences

- No cryptocurrency, no token, no blockchain surface area, no brand drag.
- Rekor already hosts production traffic for PyPI, npm, Kubernetes — risk is
  not novel.
- RFC 3161 TSRs are accepted as evidence in courts globally; banks use them.
- Dual TSA means a single outage cannot block envelope issuance.
- Phase 2 may add a federation-run Trillian log; that is out of scope for
  Phase 1 and revisited only after federation has more than one operator.
