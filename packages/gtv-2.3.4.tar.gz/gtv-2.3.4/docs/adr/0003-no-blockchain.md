# ADR 0003: No blockchain, no cryptocurrency

**Status:** Accepted, 2026-04-21.
**Decider:** Mark Hallam.

## Context

Public transparency and tamper-evidence can be achieved with transparency
logs and independent timestamping (see ADR 0002). They can also be achieved
by anchoring Merkle roots to a public blockchain (OpenTimestamps → Bitcoin,
or an Ethereum contract, etc.). The technical outcome is similar.

## Decision

The project will not depend on, integrate with, or optionally support any
blockchain or cryptocurrency for the purposes of transparency anchoring,
custody, governance, or funding.

## Rationale

- **Perception risk.** The target market (research tooling, publishers,
  national labs) is hostile or indifferent to anything "crypto-adjacent".
- **Regulatory exposure.** Anti-crypto regulatory posture in key jurisdictions
  (EU MiCA, US state-level actions) creates procurement friction.
- **Neutrality optics.** Governance via tokenholder vote is incompatible with
  the design principle that neutrality must not flow from money.

## Consequences

- Transparency log stack is Rekor + RFC 3161 (ADR 0002).
- Funding model is commercial pilots + grants; no token issuance, no ICO,
  no treasury DAO.
- Any future federation governance uses membership, not on-chain voting.
