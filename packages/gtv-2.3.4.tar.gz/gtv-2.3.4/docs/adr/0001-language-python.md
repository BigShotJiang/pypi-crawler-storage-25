# ADR 0001: Phase-1 language is Python 3.12

**Status:** Accepted, 2026-04-21.
**Decider:** Mark Hallam.

## Context

The core product is a verifier that fans out to a handful of scholarly APIs,
runs a deterministic rule engine, signs a payload, and ships it. We need:
- First-class Sigstore client.
- LaTeX-aware text handling for physics claims.
- Async HTTP fan-out.
- A typed model layer.

## Decision

Python 3.12. FastAPI for the HTTP surface.

## Consequences

- Sigstore's Python client is production-grade; no Rust or Go bindings needed.
- `pylatexenc` handles LaTeX normalisation without reinventing a parser.
- If any code path shows as a performance bottleneck under pilot load, we
  rewrite that path in Rust and expose via `maturin` — not the whole service.
