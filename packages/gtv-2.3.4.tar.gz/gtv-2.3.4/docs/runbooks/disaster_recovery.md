# Disaster Recovery Runbook

On-call runbook for recovering from data loss, federation compromise, and key compromise.
Target operator: any engineer with SSH access and `.venv/bin/python` installed.

**Last updated:** 2026-04-22

---

## Scope & SLOs

This runbook covers restoration from:

1. **Scenario A** — Primary verdict database lost (files deleted, DB corruption, filesystem failure)
2. **Scenario B** — Federation peer compromised (peer keys leaked, malicious issuer in federation)
3. **Scenario C** — Audit log corruption (Merkle chain broken, records unverifiable)
4. **Scenario D** — Signing key compromise (Ed25519 private key or Sigstore key exposed)

### RTO & RPO Justification

**RTO (Recovery Time Objective): 4 hours**
- Backup recovery and peer key rotation dominate: ~30 min for data restore, ~1 hr for federation peer re-sync, ~1.5 hr for messaging operators and client-side cache invalidation.
- Does NOT include client-side rollout or user notification.

**RPO (Recovery Point Objective): 15 minutes**
- Audit log is append-only and hash-chained; we snapshot it every 15 min to object store (S3, GCS, etc.).
- Verdict cache can be rebuilt from audit log; no data loss if audit log is intact.
- If backup is older than 15 min at time of incident, last 15 min of verdicts may be re-computed from audit log on restore.

---

## Pre-requisites

Before attempting any restore, verify:

- [ ] Backups exist at `GTV_BACKUP_BUCKET` (S3 or GCS). Test one restore in the week prior to going live.
- [ ] KMS keys (if Sigstore/Rekor signing is enabled) are accessible and not compromised.
  - Command: `.venv/bin/python -m gtv.cli.sign --check-kms-access`
- [ ] DNS is working and you can resolve GTV federation peer domains (if federation is enabled).
  - Command: `nslookup $(echo $GTV_FEDERATION_ROOT_DID | cut -d: -f3)`
- [ ] Network access to object store (S3, GCS) is open from restore host.
- [ ] You have `aws s3` or `gsutil` CLI installed and authenticated (if using S3/GCS).
- [ ] Local state directories exist and are writable:
  - `~/.gtv/` (verdict DB, audit DB, federation store)
  - Permissions: `chmod 700 ~/.gtv/`
- [ ] Python 3.12+: `.venv/bin/python --version`
- [ ] Repository clone of gtv available at working directory or `$GTV_REPO_PATH`.

---

## Scenario A — Primary Verdict Database Lost

**Trigger signals:**
- Alert: `gtv_verdict_db_open_error` (cannot open verdict.db)
- Error logs: `OSError: cannot open database file`
- Operator observation: `ls -la ~/.gtv/verdict.db` returns no such file, or file size is 0

**Impact:**
- Verdict cache is inaccessible; queries return errors.
- Federation peers continue to send/request verdicts (will fail until restore).
- Audit log is unaffected (separate database).
- Time to restore: ~15 min (backup download + schema init + optional replication from peers).

**Steps:**

1. **Confirm the failure** (on affected host)
   ```bash
   ls -la ~/.gtv/verdict.db || echo "MISSING"
   ```

2. **Check audit log is intact**
   ```bash
   .venv/bin/python -m gtv.cli.audit tail --limit 5
   ```
   If audit log is also gone, switch to **Scenario C** (Audit Log Corruption).

3. **Stop all gtv services** (if running as systemd, k8s, or docker)
   ```bash
   sudo systemctl stop gtv  # or: docker stop gtv-*; kubectl delete pod -l app=gtv
   ```

4. **List available backups**
   ```bash
   # If using S3:
   aws s3 ls s3://${GTV_BACKUP_BUCKET}/verdict-backups/ | tail -10
   
   # If using GCS:
   gsutil ls gs://${GTV_BACKUP_BUCKET}/verdict-backups/ | tail -10
   ```

5. **Download latest backup**
   ```bash
   BACKUP_KEY="verdict-backups/$(aws s3 ls s3://${GTV_BACKUP_BUCKET}/verdict-backups/ | tail -1 | awk '{print $4}')"
   aws s3 cp "s3://${GTV_BACKUP_BUCKET}/${BACKUP_KEY}" /tmp/verdict-backup.tar.gz
   
   # Verify integrity
   aws s3 cp "s3://${GTV_BACKUP_BUCKET}/${BACKUP_KEY}.sha256" /tmp/verdict-backup.sha256
   sha256sum -c /tmp/verdict-backup.sha256
   ```

6. **Restore from backup**
   ```bash
   .venv/bin/python scripts/dr_drill.py restore \
     --tarball /tmp/verdict-backup.tar.gz \
     --state-dir ~/.gtv
   ```

7. **Verify verdict database integrity**
   ```bash
   .venv/bin/python scripts/dr_drill.py verify --state-dir ~/.gtv
   ```
   Expected output: `✓ Audit log Merkle chain verified.` and `✓ At least one verdict signature verifies.`

8. **Restart gtv service**
   ```bash
   sudo systemctl start gtv
   ```

9. **Wait for federation re-sync** (if federation is enabled)
   ```bash
   # Monitor federation status; expect ~5 min for consensus re-sync
   .venv/bin/python -m gtv.cli.federation peers health <peer-did> --interval 10
   ```

10. **Validation** — see "Validation / Post-restore checks" section below.

**Rollback:**
If verification fails (step 7), restore the database again from an older backup or use `gtv-replay` to rebuild from audit log:

```bash
.venv/bin/python -m gtv.cli.replay \
  --audit-db ~/.gtv/audit.db \
  --output-db ~/.gtv/verdict.db
```

Then re-run step 7.

---

## Scenario B — Federation Peer Compromised

**Trigger signals:**
- Alert: `federation_peer_signature_invalid` (peer issued verdicts with an invalid signature)
- Alert: `federation_consensus_threshold_breach` (fewer than N/2 peers agreed on a verdict)
- Operator observation: `.venv/bin/python -m gtv.cli.federation peers health <peer-did>` shows connection refused or signature errors
- Manual discovery: peer operator reports key compromise

**Impact:**
- Affected peer's verdicts are unreliable; clients may have cached corrupted verdicts.
- Federation consensus is broken until peer is revoked and re-keyed.
- RTO: ~1 hr (revoke peer, rotate its keys, re-establish trust).

**Steps:**

1. **Revoke the compromised peer locally**
   ```bash
   .venv/bin/python -m gtv.cli.federation peers revoke <peer-did>
   ```
   This adds the peer DID to `~/.gtv/revoked_peers.json`.

2. **Stop accepting verdicts from revoked peer**
   - Verify the peer is in the revoked list:
     ```bash
     cat ~/.gtv/revoked_peers.json | jq '.revoked_dids[] | select(. == "<peer-did>")'
     ```

3. **Rotate the peer's signing key** (if peer is accessible and under your control)
   - Contact peer operator to:
     - Generate new Ed25519 signing key: `openssl genpkey -algorithm ed25519 -out new_key.pem`
     - Update `GTV_SIGNING_KEY_PATH` to point to new key
     - Publish new public key to DID document (if DID-based discovery is used)
     - Restart peer service with new key

4. **Request peer to re-issue recent verdicts** with the new key
   - Ask peer operator to re-sync federation verdicts to your instance:
     ```bash
     # On peer host:
     .venv/bin/python -m gtv.cli.fed consensus --sync-all
     ```

5. **Re-establish trust with peer**
   - If peer is a new identity (new DID):
     ```bash
     # On your host:
     .venv/bin/python -m gtv.cli.federation peers discover
     ```
   - If peer kept the same DID but rotated the key:
     ```bash
     # Delete local trust cache for this peer
     rm ~/.gtv/peer_trust_${PEER_DID}.json
     
     # Force re-fetch peer public key from DID document:
     .venv/bin/python -m gtv.cli.federation peers health <peer-did> --refresh-keys
     ```

6. **Validate federation consensus**
   ```bash
   .venv/bin/python -m gtv.cli.federation peers list --json | jq '.[] | select(.did == "<peer-did>")'
   ```
   Expected: `"status": "healthy"` and `"revoked_at": null`

7. **Validation** — see "Validation / Post-restore checks" section below.

**Rollback:**
If after re-keying the peer's verdicts are still invalid, mark the peer as permanently revoked:

```bash
# Edit ~/.gtv/revoked_peers.json and remove the peer DID entry to un-revoke (if needed)
cat ~/.gtv/revoked_peers.json | jq 'del(.revoked_dids[] | select(. == "<peer-did>"))' > /tmp/revoked.json
mv /tmp/revoked.json ~/.gtv/revoked_peers.json
```

---

## Scenario C — Audit Log Corruption Detected

**Trigger signals:**
- Alert: `audit_merkle_chain_broken` (hash chain verification fails)
- Operator observation: `.venv/bin/python -m gtv.cli.audit verify` returns non-zero exit code
- Error: `prev_hash mismatch: expected X, got Y`

**Impact:**
- Audit log is unreliable; cannot trust record ordering or integrity.
- Verdict database can still be queried, but cannot be re-computed from audit log.
- RTO: ~30 min (restore audit log from signed snapshot, optionally rebuild verdicts).

**Steps:**

1. **Confirm audit log is corrupted**
   ```bash
   .venv/bin/python -m gtv.cli.audit verify
   ```
   Expected on failure: exit code 1 and error message with corrupted sequence number.

2. **Check for signed audit log snapshots** (if Rekor/Sigstore is enabled)
   ```bash
   # List audit snapshots in Rekor log
   .venv/bin/python -m gtv.cli.audit export --out /tmp/audit-snapshot.json
   
   # Check if snapshot is signed and trusted
   .venv/bin/python -m gtv.cli.verify /tmp/audit-snapshot.json --offline
   ```

3. **Restore audit log from backup**
   ```bash
   BACKUP_KEY="audit-backups/$(aws s3 ls s3://${GTV_BACKUP_BUCKET}/audit-backups/ | tail -1 | awk '{print $4}')"
   aws s3 cp "s3://${GTV_BACKUP_BUCKET}/${BACKUP_KEY}" /tmp/audit-backup.tar.gz
   
   .venv/bin/python scripts/dr_drill.py restore \
     --tarball /tmp/audit-backup.tar.gz \
     --state-dir ~/.gtv
   ```

4. **Verify restored audit log**
   ```bash
   .venv/bin/python -m gtv.cli.audit verify
   ```
   Expected: exit code 0 and `Audit log integrity OK`.

5. **Optionally rebuild verdict database** from audit log
   ```bash
   rm ~/.gtv/verdict.db
   .venv/bin/python -m gtv.cli.replay \
     --audit-db ~/.gtv/audit.db \
     --output-db ~/.gtv/verdict.db
   ```

6. **Validation** — see "Validation / Post-restore checks" section below.

**Rollback:**
If audit log snapshot is also corrupted and backups are unavailable, escalate to gtv-maintainers (below).

---

## Scenario D — Signing Key Compromise

**Trigger signals:**
- Alert: signing key file is world-readable: `ls -la ~/.gtv/signing_key.pem`
- Manual report: key was accidentally committed to git, leaked to operator
- Alert: `sigstore_signing_error` with authentication failure (Sigstore creds compromised)

**Impact:**
- All new verdicts signed with the key are unreliable (attacker could forge signatures).
- Historic verdicts remain valid if they were signed with the old key.
- RTO: ~2 hr (rotate key, publish revocation, re-sign critical verdicts).

**Steps:**

1. **Immediately revoke the compromised key** (if using Sigstore)
   ```bash
   # Request revocation via Rekor:
   .venv/bin/python -m gtv.cli.revoke \
     --key-id <compromised-key-id> \
     --reason "key-compromise"
   ```
   This will block new verdicts signed by this key at federation peers.

2. **Generate new Ed25519 signing key**
   ```bash
   openssl genpkey -algorithm ed25519 -out ~/.gtv/signing_key_new.pem
   chmod 600 ~/.gtv/signing_key_new.pem
   ```

3. **Rotate key in environment**
   ```bash
   # Update GTV_SIGNING_KEY_PATH to point to new key
   export GTV_SIGNING_KEY_PATH=~/.gtv/signing_key_new.pem
   
   # Publish new key identity (if using DID-based discovery)
   # Update your DID document to point to the new public key
   # Command (if applicable): .venv/bin/python -m gtv.cli.admin-keys publish
   ```

4. **Securely dispose of compromised key**
   ```bash
   shred -vfz ~/.gtv/signing_key.pem
   
   # If key was in git, purge from history:
   git filter-branch --tree-filter 'rm -f ~/.gtv/signing_key.pem' HEAD
   ```

5. **Re-sign critical recent verdicts** with new key
   ```bash
   # List verdicts signed by old key in past 24 hours:
   .venv/bin/python -m gtv.cli.audit tail --limit 100 --format json | \
     jq '.[] | select(.action == "verdict.create" and .timestamp > now - 86400)'
   
   # Re-sign each verdict:
   for VERDICT_ID in <list>; do
     .venv/bin/python -m gtv.cli.sign --envelope $VERDICT_ID --key-path ~/.gtv/signing_key_new.pem
   done
   ```

6. **Notify federation peers** of key rotation
   ```bash
   # Publish updated issuer metadata:
   .venv/bin/python -m gtv.cli.federation peers discover --refresh-all
   ```

7. **Validation** — see "Validation / Post-restore checks" section below.

**Rollback:**
If old key is still needed for legacy verification, keep it but mark as revoked. Do not use for new signatures.

---

## Validation / Post-restore Checks

Run these after ANY restore to confirm the system is healthy:

### 1. Audit log integrity
```bash
.venv/bin/python -m gtv.cli.audit verify
echo "Exit code: $?"  # Expect 0
```

### 2. Verdict database integrity
```bash
.venv/bin/python scripts/dr_drill.py verify --state-dir ~/.gtv
echo "Exit code: $?"  # Expect 0
```

### 3. Signature verification (sample)
```bash
# Export a recent verdict and verify it offline
.venv/bin/python -m gtv.cli.audit tail --limit 1 --format json | \
  jq '.[] | {envelope_id, issuer_did}' > /tmp/sample_verdict.json

.venv/bin/python -m gtv.cli.verify /tmp/sample_verdict.json --offline --trust-issuer
echo "Exit code: $?"  # Expect 0
```

### 4. Federation peer health (if enabled)
```bash
.venv/bin/python -m gtv.cli.federation peers health <peer-did> --json | \
  jq '.[] | {did, status, last_contact}'
# Expect: "status": "healthy" and recent "last_contact"
```

### 5. Service is accepting new verdicts
```bash
# If using HTTP API:
curl -s http://localhost:8000/health | jq '.status'  # Expect "ok"

# If using MCP:
.venv/bin/python -c "from gtv.mcp.server import app; print('✓ MCP server imported')"
```

### 6. File permissions are correct
```bash
ls -la ~/.gtv/ | grep -E '600|700'
# All files should be rw------- (600) or rwx------ (700)
# If not: chmod 600 ~/.gtv/*.db ~/.gtv/*.pem; chmod 700 ~/.gtv/
```

---

## Escalation

Contact **gtv-maintainers** (Slack: #gtv-oncall) if:

- [ ] Backup does not exist or is corrupted (`dr_drill restore` fails with SHA256 mismatch)
- [ ] Audit log and verdict DB are both lost (RTO > 4 hours)
- [ ] Federation peer operator is unresponsive (cannot re-key)
- [ ] Signing key was leaked and re-keying will break client contracts (may require policy exception)
- [ ] Merkle chain is corrupted beyond recovery (cannot restore from backup)

**On-call rotation:** Check #gtv-oncall Slack for current primary and backup on-call.

---

## Testing This Runbook

Every operator should test at least one scenario before going on-call.

```bash
# Full automated drill (recommended for initial training)
.venv/bin/python scripts/dr_drill.py full-drill

# Or step-by-step manual test
mkdir -p /tmp/test_restore_state
.venv/bin/python scripts/dr_drill.py backup --state-dir /tmp/test_restore_state
.venv/bin/python scripts/dr_drill.py restore \
  --tarball /tmp/test_restore_state/backup.tar.gz \
  --state-dir /tmp/test_restore_state_restored
.venv/bin/python scripts/dr_drill.py verify --state-dir /tmp/test_restore_state_restored
```

Expected output on success: `full-drill: OK (exit 0)`

---

## References

- **Architecture:** `docs/architecture.md` (federation, audit log, verdict cache)
- **Deployment:** `docs/deployment.md` (KMS, backup bucket setup)
- **Security:** `docs/security.md` (key management, revocation policy)
- **CLI Reference:** `src/gtv/cli/*.py` (all available commands)

---

End of runbook. Test before relying on it.
