# Unwired-modules audit — v2.2.0

_Generated 2026-04-22. Re-run with `.venv/bin/python /tmp/audit_deps.py`._

## Summary

158 source modules. After walking the import graph from every application
entry point (`gtv.mcp.server`, `gtv.mcp.stdio`, `gtv.mcp.grpc_server`, and
all 18 `gtv-*` console scripts), **44 modules were unreachable from any
production request path**.

This audit classifies all 44. 7 were wired into the main app as part of
this pass; 8 are legitimate SDK surfaces with no src importer; 5 are
stale duplicates; 24 remain test-only and need a decision per module.

## 1. Wired this pass (7)

Shipped features that had code but no mount point. Wired in
`src/gtv/mcp/server.py`:

- `gtv.managed.api.router` — `/managed/tenants*` CRUD + quota/usage endpoints,
  gated on `X-Admin-Key` header (`GTV_MANAGED_ADMIN_KEY`). `app.include_router`.
- `gtv.federation.backpressure.backpressure_header_middleware` — injects
  `X-Federation-Backpressure` on `/federation/*` responses.
- `gtv.federation.dos_protection.federation_rate_limit_middleware` —
  per-peer token-bucket on `/federation/*` with 429 + `Retry-After`.

Transitively reachable: `gtv.managed.quotas`, `gtv.managed.tenants`,
`gtv.managed.usage`.

## 2. Legitimate SDK surfaces (8)

Customer-facing library code. No src importer is expected; consumers
`import gtv.bindings.openai_tools` from their own agents.

- `gtv.bindings.{client,openai_tools,anthropic_tools,langchain,llamaindex}`
- `gtv.adapters.sdk` — base class + conformance harness for third-party adapter authors
- `gtv.adapters.conformance` — shared conformance tests

## 3. Stale duplicates — delete or consolidate (5)

- `gtv.cli.fed` — superseded by `gtv.cli.federation`. `pyproject.toml`
  binds both `gtv-fed` and `gtv-federation` to `gtv.cli.federation:main`.
  The `cli/fed.py` subcommands (`verdicts replicate`, `revocations pull`)
  are not reachable from the console script. **Action**: either fold
  the two missing subcommands into `cli/federation.py` or delete
  `cli/fed.py` and its test.
- `gtv.obs.{otel,structlog,trace_context}` — older OTEL shims
  superseded by the `gtv.telemetry` package (installed via
  `install_telemetry(app)` in server.py). **Action**: verify no external
  consumers and delete.
- `gtv.claim_cache` — superseded by `gtv.cache.claim`. **Action**:
  same — verify and delete.

## 4. Test-only — decide per module (24)

These have tests but no production call site. Each one is either:
(a) a feature that should be wired in, (b) an internal lib kept for
future work, or (c) dead code.

Federation subsystems (W63–W92 work):
- `gtv.federation.peer_quarantine` — peer circuit breaker
- `gtv.federation.peer_trust` — tier-weighted trust
- `gtv.federation.partition_recovery` — split-brain recovery
- `gtv.federation.split_brain` — split-brain detection
- `gtv.federation.audit_verifier` — third-party audit tool
- `gtv.federation.region_router` — regional routing
- `gtv.federation.domain_bundle` — domain cert bundle
- `gtv.federation.replication` — peer replication
- `gtv.federation.replicator` — peer replicator
- `gtv.federation.revocation_gossip` — gossip protocol
- `gtv.federation.store` — federation state store
- `gtv.federation.updates` — update stream
- `gtv.federation.verdict_consensus` — alt consensus impl

Adapters:
- `gtv.adapters.sharding` — registry sharding
- `gtv.adapters.ratelimit` — rate-limited adapter wrapper

Misc:
- `gtv.verdict.ranker` — LearnedRanker; expected to be called from
  the verdict engine but isn't.
- `gtv.mcp.grpc_client` — gRPC client
- `gtv.retrieve.{cluster,dedup}` — retrieval clustering + dedup
- `gtv.claim_thread` — claim threading
- `gtv.attachments` — attachments
- `gtv.region` — region metadata
- `gtv.auth.oidc` — OIDC JWT issuer (federation auth)
- `gtv.anchor.tsa_certs` — cert data package (only `__init__.py`)

## Next steps

The 24 test-only modules need case-by-case decisions. Most are
plausibly "wire in on the federation pipeline once it's real" (not just
test-simulated), rather than outright dead code — but that's a
follow-on project, not a v2.2.0 release item. Flagging them here so
the next audit has a baseline.
