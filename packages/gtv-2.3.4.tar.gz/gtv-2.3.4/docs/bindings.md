# Agent framework bindings

`gtv` ships with drop-in bindings for the three most common ways agents
call external tools today. All three share one thin async HTTP client
([`GtvClient`](#shared-client)) so auth, retries, and request shape live
in one place.

| Framework | Module | Tool spec |
|---|---|---|
| OpenAI function calling | `gtv.bindings.openai_tools` | `type=function` nested |
| Anthropic tool use | `gtv.bindings.anthropic_tools` | flat `name/description/input_schema` |
| LangChain | `gtv.bindings.langchain` | `StructuredTool` factory |
| Anthropic MCP | `gtv.mcp.stdio` (existing) | JSON-RPC stdio |

The tool specs advertise two endpoints: `verify_claim` (single claim →
signed envelope) and `retrieve_facts` (free-text query → multi-fact
envelope).

## Shared client

```python
from gtv.bindings import GtvClient

async with GtvClient("http://localhost:8000", api_key="...") as c:
    env = await c.verify_claim("The Higgs boson mass is 125 GeV.",
                               domain="physics", max_sources=3)
    facts = await c.retrieve_facts("black hole thermodynamics",
                                   domain="physics")
```

The client is framework-agnostic; every binding below calls the same
methods. `api_key` is optional — omit it if the verifier runs in
open-by-default mode.

## OpenAI function calling

```python
from openai import AsyncOpenAI
from gtv.bindings.client import GtvClient
from gtv.bindings.openai_tools import TOOLS, dispatch

llm = AsyncOpenAI()
async with GtvClient("http://localhost:8000") as gtv:
    resp = await llm.chat.completions.create(
        model="gpt-4o", tools=TOOLS,
        messages=[{"role": "user", "content": "Verify: ..."}],
    )
    for call in resp.choices[0].message.tool_calls or []:
        result = await dispatch(gtv, call.function.name, call.function.arguments)
```

See `examples/openai_agent.py` for a complete loop.

## Anthropic tool use

```python
from anthropic import AsyncAnthropic
from gtv.bindings.client import GtvClient
from gtv.bindings.anthropic_tools import TOOLS, dispatch

llm = AsyncAnthropic()
async with GtvClient("http://localhost:8000") as gtv:
    msg = await llm.messages.create(
        model="claude-3-5-sonnet-latest", max_tokens=1024,
        tools=TOOLS,
        messages=[{"role": "user", "content": "Verify: ..."}],
    )
    for block in msg.content:
        if block.type == "tool_use":
            result = await dispatch(gtv, block.name, block.input)
```

See `examples/anthropic_agent.py` for a complete loop.

## LangChain

```python
from gtv.bindings.langchain import make_verify_claim_tool, make_retrieve_facts_tool

tools = [
    make_verify_claim_tool(base_url="http://localhost:8000"),
    make_retrieve_facts_tool(base_url="http://localhost:8000"),
]
# pass `tools` to create_tool_calling_agent / AgentExecutor
```

`langchain-core` is imported lazily, so the package installs cleanly
without it. See `examples/langchain_agent.py` for a complete agent.

## Anthropic MCP (stdio)

Already available as the `gtv-mcp` console script — see
[Getting Started](getting-started.md). Point Claude Desktop at:

```json
{
  "mcpServers": {
    "gtv": { "command": "gtv-mcp" }
  }
}
```

No extra bindings are needed for MCP — the stdio server exposes
`verify_claim` and `retrieve_facts` as native MCP tools.
