# Retrospective: [VERSION] ([DATE_RANGE])

**Participants:** [NAMES]  
**Date:** [YYYY-MM-DD]

## What Shipped

Hard data from this release cycle:

| Metric | Value |
|--------|-------|
| Version tagged | `[VERSION]` |
| Tests added | [COUNT] |
| Adapters added | [COUNT] |
| Python files | [COUNT] (delta: [+/-N] from prior) |
| Reference implementations | [LIST] |

See `release/manifest-[VERSION].json` for the complete manifest.

## What Went Well

- **[Item 1]**: One-sentence description of the win.
- **[Item 2]**: One-sentence description of the win.
- **[Item 3]**: One-sentence description of the win.
- **[Item 4]**: One-sentence description of the win.
- **[Item 5]**: One-sentence description of the win.

## What Went Wrong

- **[Item 1]**: Blunt description. Root cause: [if known].
- **[Item 2]**: Blunt description. Root cause: [if known].
- **[Item 3]**: Blunt description. Root cause: [if known].
- **[Item 4]**: Blunt description. Root cause: [if known].
- **[Item 5]**: Blunt description. Root cause: [if known].

## What We Learned

- **[Lesson 1]**: Distilled insight. Next cycle action: [concrete change].
- **[Lesson 2]**: Distilled insight. Next cycle action: [concrete change].
- **[Lesson 3]**: Distilled insight. Next cycle action: [concrete change].
- **[Lesson 4]**: Distilled insight. Next cycle action: [concrete change].
- **[Lesson 5]**: Distilled insight. Next cycle action: [concrete change].

## Action Items

| Action | Owner | Due | Status |
|--------|-------|-----|--------|
| [Bounded action 1] | [Person/team name] | [YYYY-MM-DD] | [pending/in_progress/completed] |
| [Bounded action 2] | [Person/team name] | [YYYY-MM-DD] | [pending/in_progress/completed] |
| [Bounded action 3] | [Person/team name] | [YYYY-MM-DD] | [pending/in_progress/completed] |
| [Bounded action 4] | [Person/team name] | [YYYY-MM-DD] | [pending/in_progress/completed] |
| [Bounded action 5] | [Person/team name] | [YYYY-MM-DD] | [pending/in_progress/completed] |
| [Bounded action 6] | [Person/team name] | [YYYY-MM-DD] | [pending/in_progress/completed] |

## Metrics Snapshot

| Metric | Value | Source |
|--------|-------|--------|
| CI test count | [VALUE] | `.venv/bin/python -m pytest tests/ --collect-only -q` |
| Uncovered lines % | [VALUE] | `coverage report` |
| Open CVEs | [VALUE] | `pip-audit` |
| p99 verify latency (ms) | [VALUE] or `[TBD: wire to prometheus query]` | |
| Active tenant count | [VALUE] or `[TBD: wire to tenant store]` | |

## Sign-off

**Date:** [YYYY-MM-DD]  
**Signed by:** [Name], [Name], [Name]
