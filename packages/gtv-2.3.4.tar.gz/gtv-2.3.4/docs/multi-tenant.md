# Multi-tenant operation

One gtv process can host multiple independent tenants. Each tenant
signs verdicts under a distinct issuer DID, which transparently gives
them isolated verdict caches and isolated lifecycle DAGs — no
per-tenant database, no per-tenant process.

## The one invariant

**Each tenant signs under its own issuer DID.** Every cross-request
data store — the verdict cache, the lifecycle index, the audit log —
is already keyed by issuer DID. Give two tenants distinct DIDs and
they are isolated, full stop.

The auth middleware attaches a `gtv.tenant.Tenant(tenant_id, issuer_did)`
to `request.state.tenant`. MCP handlers resolve it through
`resolve_tenant(request)` and pass `issuer_did` into every code path
that seals an envelope, reads the cache, or walks the lifecycle DAG.

## Provisioning a tenant

API keys now carry two extra columns:

- `tenant_id` — free-form label used for metrics and audit logs. It
  never appears in envelopes and never affects routing or signing.
- `issuer_did_override` — the DID this key's envelopes are signed
  under. Blank means "fall through to `GTV_ISSUER_DID`" (the server
  default).

Create a tenant-scoped key with `gtv-admin-keys`:

```bash
gtv-admin-keys create \
  --label "Alice Research Ltd." \
  --scopes verify,consensus \
  --tenant alice \
  --issuer-did did:web:alice.example \
  --rate-limit 300
```

The command prints the raw key once; store it in the tenant's secrets
vault. `gtv-admin-keys list` shows the tenant and override columns.

To run several tenants under the **same** DID (for example, to track
usage per team while still sharing a cache), omit `--issuer-did` and
only set `--tenant`. The tenant label still appears in metrics, but
all their verdicts share a signature identity.

## Cross-tenant behavior

- **Verdict cache.** Cache keys include the issuer DID. Tenant B's
  cache miss on a claim tenant A has already verified is expected and
  correct — they're different issuers with different signing
  identities and, in general, different policy configuration.
- **Lifecycle DAG.** `supersede_claim` across tenants is blocked with
  HTTP 403. `claims_latest` defaults to the caller's DID; passing an
  explicit `issuer_did=` still works for operators who need to inspect
  another tenant's chain.
- **Rate limits.** Each API key already gets its own sliding-window
  counter. A noisy tenant can only DOS itself.

## Observability

A dedicated counter keeps tenant-level cardinality out of the core
metrics:

```
gtv_tenant_requests_total{tenant_id, tool, verdict}
```

Unattributed traffic (auth disabled, env-var key fallback) is labelled
`tenant_id="_default"`. Existing metrics
(`gtv_verdicts_total`, `gtv_verify_duration_seconds`,
`gtv_cache_hits_total`, etc.) are deliberately **not** labelled with
`tenant_id` — that keeps Grafana dashboards simple and keeps
per-tenant cardinality from multiplying every existing panel.

Example PromQL:

```
# Top-5 tenants by request volume in the last 10 minutes
topk(5, sum by (tenant_id) (rate(gtv_tenant_requests_total[10m])))

# Per-tenant verdict mix
sum by (tenant_id, verdict) (rate(gtv_tenant_requests_total[5m]))
```

## Legacy keystore migration

Existing `api_keys.db` files pre-W31 are upgraded in place the first
time `APIKeyStore` opens them. The migration is two idempotent
`ALTER TABLE ADD COLUMN` statements and is safe to run repeatedly.
No downtime; no backup step required (but take one anyway).

## Security notes

- The override DID must match a public DID document the verifier's
  clients can resolve, otherwise downstream signature verification
  will fail. Operators are responsible for publishing per-tenant DID
  documents.
- The tenant label is not a trust boundary. Two keys with different
  `tenant_id` but the same `issuer_did_override` sign under the same
  identity and share a cache — that's by design, but don't rely on
  `tenant_id` alone for isolation.
- Revoking a tenant's key does **not** retroactively invalidate
  envelopes it signed. Use `GTV_REVOCATION_LIST` + issue a new
  revocation entry if a tenant's signing key is compromised.

## Operational checklist

1. Decide whether a tenant needs its own DID (hard isolation) or just
   its own label (shared identity, separate billing/metrics).
2. Publish the DID document at the hard-isolation tenant's
   `did:web:` location.
3. `gtv-admin-keys create --tenant <id> --issuer-did <did> …`.
4. Hand the raw key to the tenant; confirm their first call shows up
   under the correct `tenant_id` in
   `gtv_tenant_requests_total`.
5. Never reuse an `issuer_did_override` across tenants that are
   supposed to be independent.
