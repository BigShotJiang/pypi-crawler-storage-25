# HTTP / MCP API

The MCP server exposes three tool endpoints plus operational endpoints.

## `POST /tools/verify_claim`

Verifies a single claim against the registered evidence adapters.

**Request:**

```json
{
  "claim": "The Higgs boson mass is 125 GeV.",
  "domain": "physics",
  "max_sources": 3
}
```

`domain` ∈ `physics`, `math`, `cs`, `astronomy`, `materials`, `general`.

**Response:**

```json
{
  "envelope": {
    "verdict": "VERIFIED",
    "confidence": 0.87,
    "evidence": [...],
    "rationale": "...",
    "issuer_did": "did:web:verify.example.org",
    "signature": "...",
    "rekor_uuid": "...",
    "rekor_log_index": 0,
    "tsa_token": "...",
    "prov_graph": "...",
    "anchor_proof": {
      "rekor_inclusion_proof": "...",
      "tsa_tsr_primary": "..."
    }
  }
}
```

Verdicts: `VERIFIED`, `DISPUTED`, `REFUTED`, `INSUFFICIENT_EVIDENCE`, `OUT_OF_DOMAIN`.

## `POST /tools/verify_claim/stream`

Streaming variant of `verify_claim`. Emits Server-Sent Events as each
phase of the verification pipeline completes, so callers see progress
without waiting for the sealed envelope.

**Request:** identical body to `/tools/verify_claim`.

**Response:** `Content-Type: text/event-stream`. One event per phase:

| Event             | Emitted when                                             | Payload fields                                                |
|-------------------|----------------------------------------------------------|---------------------------------------------------------------|
| `claim_accepted`  | Request admitted; classification known.                  | `claim_id`, `classification`, `issuer_did`                    |
| `evidence`        | An adapter returned (one event per adapter, completion order). | `source_did`, `status` (`ok`/`timeout`/`error`), `elapsed_ms`, `items` |
| `verdict`         | Verdict engine decided, before signing.                  | `verdict`, `confidence`, `rationale`, `evidence_count`        |
| `envelope`        | Sealed envelope ready. **Terminal — stream closes.**     | `envelope` (full `Envelope` object)                           |
| `error`           | Non-recoverable failure mid-stream. **Terminal.**        | `detail`                                                      |

Wire format per event (standard SSE):

```
event: <phase>
data: {"phase":"<phase>", ...}
\n
```

Example:

```bash
curl -N -X POST http://localhost:8080/tools/verify_claim/stream \
  -H 'content-type: application/json' \
  -d '{"claim":"Pi starts with 3.14.","domain":"math"}'
```

**Behavioural notes:**

- **Cache hits collapse the stream** to two events: `claim_accepted` (so
  the caller knows the request was admitted) and `envelope`. Adapters
  are not re-queried — there are no phases to observe from cache.
- **Pre-stream gates fire as HTTP errors.** PII in the claim returns
  `400`; no adapters registered returns `503`. Both happen *before*
  the stream opens, so callers can distinguish "request rejected" from
  "stream errored mid-way".
- **Non-FACTUAL claims short-circuit.** OPINION/CREATIVE/OUT_OF_SCOPE
  claims skip the adapter fan-out, so no `evidence` events are
  emitted — only `claim_accepted` → `verdict` → `envelope`.
- **Cache is shared with `/tools/verify_claim`.** A cold streaming call
  populates the verdict cache, so a follow-up JSON call for the same
  claim hits cache and vice versa. Streaming and JSON paths share
  exactly the same pipeline (`_verify_one_events`).
- **Revocation is enforced mid-stream.** If the sealed envelope (or its
  issuer) is revoked, an `error` event is emitted instead of the
  `envelope` event and the cached entry is evicted.
- **Headers:** `Cache-Control: no-cache`, `X-Accel-Buffering: no` —
  required so reverse proxies don't buffer the whole stream.

## `POST /tools/retrieve_facts`

Returns raw evidence from the adapter fleet without computing a verdict. Useful for agents that want to do their own reasoning.

## `POST /consensus`

Aggregates multiple envelopes (typically from federated verifiers) into a signed `AggregateEnvelope` using tier-weighted voting.

**Request:**

```json
{"envelopes": [<envelope>, <envelope>, ...]}
```

**Response:**

```json
{
  "verdict": "VERIFIED",
  "confidence": 0.91,
  "aggregate": {
    "aggregate_id": "...",
    "consensus_verdict": "VERIFIED",
    "consensus_confidence": 0.91,
    "input_refs": [
      {"envelope_id": "...", "issuer_did": "...", "weight_applied": 3.0, ...}
    ],
    "aggregate_canonical_hash": "<64 hex chars>"
  }
}
```

Weights come from the federation registry: `T1=3.0`, `T2=2.0`, `T3=1.0`, unknown issuers `0.1`.

## Operational

- `GET /health` — 200 OK when ready. No auth.
- `GET /metrics` — Prometheus text format. No auth.

## Authentication

If `GTV_API_KEY_DB` or `GTV_API_KEYS` is set, every endpoint except `/health` and `/metrics` requires `Authorization: Bearer <key>`.

Rate limit: 60 req/min/key by default (`GTV_RATE_LIMIT_PER_MINUTE`), per-key override available in the DB-backed keystore.

## Machine-readable schemas

The public contract is frozen in two forms, both regenerated from the
code and checked for drift on every PR:

- `spec/openapi.gen.json` — OpenAPI 3.1 document for every endpoint.
- `spec/schemas/<Model>.gen.json` — JSON Schema (Draft 2020-12) for
  every public Pydantic model: `Envelope`, `Evidence`, `AnchorProof`,
  `RetrieveFactsEnvelope`, `FactItem`, `VerifyClaimRequest`,
  `RetrieveFactsRequest`, `Claim`, `VerdictRecord`, `HealthStatus`.

Regenerate after changing a model or route:

```bash
gtv-export-schemas write
```

The `schema-drift` CI job runs `gtv-export-schemas check` on every PR
and fails if the committed artifacts don't match what the exporter
would produce. Breaking contract changes require an ADR and a major
version bump.

The curated hand-written files under `spec/schemas/` (`envelope.json`,
`verify_claim.json`, `retrieve_facts.json`) describe the MCP
tool-advertisement contract separately and are intentionally left in
place.
