# Deployment

gtv ships as a distroless Docker image and a PyPI package. Both support the same configuration surface via environment variables.

## Docker (recommended)

```bash
docker pull ghcr.io/groundtruth/gtv:v0.1.0
docker run --rm -p 8080:8080 \
  -e GTV_ISSUER_DID=did:web:verify.example.com \
  -e GTV_SIGSTORE_ENABLED=1 \
  -e GTV_TSA_ENABLED=1 \
  ghcr.io/groundtruth/gtv:v0.1.0
```

The image is multi-arch (amd64/arm64), distroless, Cosign-signed with Sigstore keyless OIDC, and ships with an SBOM attached.

### Verify the image signature

```bash
cosign verify \
  --certificate-identity-regexp 'https://github.com/groundtruth/gtv/.*' \
  --certificate-oidc-issuer https://token.actions.githubusercontent.com \
  ghcr.io/groundtruth/gtv:v0.1.0
```

### Docker Compose

```yaml
services:
  gtv:
    image: ghcr.io/groundtruth/gtv:v0.1.0
    ports:
      - "8080:8080"
    environment:
      GTV_ISSUER_DID: did:web:verify.example.com
      GTV_SIGSTORE_ENABLED: "1"
      GTV_TSA_ENABLED: "1"
      GTV_API_KEY_DB: /data/api_keys.db
      GTV_FEDERATION_DB: /data/federation.db
      GTV_AUDIT_DB: /data/audit.db
    volumes:
      - gtv-data:/data
    restart: unless-stopped

volumes:
  gtv-data:
```

## PyPI

```bash
pip install gtv
uvicorn gtv.mcp.server:app --host 0.0.0.0 --port 8080
```

Requires Python 3.12+.

## Environment variables

### Identity and signing

| Variable | Default | Purpose |
|---|---|---|
| `GTV_ISSUER_DID` | `did:web:verify.groundtruth.example` | DID that appears as `issuer_did` on every envelope. Required in production. |
| `GTV_SIGSTORE_ENABLED` | `0` | Set to `1` to enable Sigstore keyless OIDC signing. When off, envelopes carry `stub://` signatures. |
| `GTV_SIGSTORE_PROD` | `0` | Set to `1` for the public production Sigstore instance. `0` = staging. |
| `GTV_TSA_ENABLED` | `0` | Set to `1` to call the RFC 3161 timestamping authorities. |
| `GTV_TSA_PRIMARY_URL` | `https://freetsa.org/tsr` | Primary TSA. Fail-hard. |
| `GTV_TSA_SECONDARY_URL` | `http://timestamp.digicert.com` | Secondary TSA. Best-effort. |
| `GTV_REKOR_URL` | `https://rekor.sigstore.dev` | Rekor transparency log. |

### Authentication and rate limiting

| Variable | Default | Purpose |
|---|---|---|
| `GTV_API_KEY_DB` | unset | Path to SQLite DB managed by `gtv-admin-keys`. Recommended for production. |
| `GTV_API_KEYS` | unset | Comma-separated static keys. Dev only. |
| `GTV_RATE_LIMIT_PER_MINUTE` | `60` | Default per-key rate limit. Per-key overrides live in the DB. |

If neither `GTV_API_KEY_DB` nor `GTV_API_KEYS` is set, the verify/retrieve/consensus endpoints run **unauthenticated**. Never deploy that way.

### Federation, revocation, audit

| Variable | Default | Purpose |
|---|---|---|
| `GTV_FEDERATION_DB` | unset | Persistent federation trust registry. Managed via `gtv-federation`. |
| `GTV_REVOCATION_DIR` | unset | Directory of signed revocation lists. Loaded at startup. |
| `GTV_AUDIT_DB` | unset | Hash-chained admin audit log. Managed via `gtv-audit`. |
| `GTV_AUDIT_SIGNING_KEY` | unset | PEM Ed25519 private key that signs each audit record. Recommended for production. |

### Webhooks and adapters

| Variable | Default | Purpose |
|---|---|---|
| `GTV_WEBHOOK_SIGNING_KEY` | unset | Ed25519 private key PEM used to sign outgoing webhook payloads. |
| `GTV_OPENALEX_EMAIL` | `gtv-polite@example.invalid` | Polite-pool email for OpenAlex. |
| `GTV_S2_API_KEY` | unset | Semantic Scholar API key. |
| `GTV_PUBMED_API_KEY` | unset | PubMed API key (raises the rate limit from 3 to 10 req/s). |
| `GTV_DISABLE_DEFAULT_ADAPTERS` | unset | Comma-separated adapter names to disable. |

### Observability

| Variable | Default | Purpose |
|---|---|---|
| `GTV_LOG_LEVEL` | `INFO` | Telemetry log level. |
| `GTV_OTEL_ENDPOINT` | unset | OTLP endpoint for distributed tracing. |

### Verdict cache

Signed, zero-trust in-process cache for `verify_claim`. Every read
re-verifies the cached envelope's signature against a freshly-computed
canonical hash; tampered or corrupt entries are evicted and the request
falls through to a fresh verification. Keys are NFKC-normalized and
scoped by `(claim, domain, max_sources, issuer_did)`.

| Variable | Default | Purpose |
|---|---|---|
| `GTV_CACHE_ENABLED` | `1` | Set to `0` to disable caching entirely. |
| `GTV_CACHE_REDIS_URL` | unset | Redis URL for a shared cache across instances. In-process dict if unset. |
| `GTV_CACHE_TTL_S` | `300` | Default TTL for envelopes with no evidence (OPINION / CREATIVE / OUT_OF_SCOPE). |
| `GTV_CACHE_TTL_MIN_S` | `1` | Lower clamp on evidence-derived TTLs. |
| `GTV_CACHE_TTL_MAX_S` | `3600` | Upper clamp on evidence-derived TTLs. |

Evidence-backed envelopes get `TTL = clamp(min(adapter freshness_sla_s
for evidence))`, so freshness inherits the tightest source SLA on the
envelope. Prometheus metrics: `gtv_cache_hits_total`,
`gtv_cache_misses_total`, `gtv_cache_invalidations_total{reason}`
(`signature_mismatch`, `deserialize_error`, `revoked`, `superseded`).

### PII redaction

Signed envelopes are public and in practice unrevokable, so PII in
them is a permanent liability. The redactor scrubs rationale and
evidence excerpts BEFORE the envelope is sealed, so the canonical
hash covers the already-redacted text. Claims submitted by callers
that themselves contain PII are 400'd at ingress — silently redacting
the claim would break caching and mislead the caller.

| Variable | Default | Purpose |
|---|---|---|
| `GTV_REDACT_ENABLED` | `1` | Set to `0` to disable output-side redaction. Dev-only; input-side rejection stays on regardless. |
| `GTV_REDACT_EXTRA_PATTERNS` | unset | Semicolon-separated `KIND=regex` pairs for site-specific rules. |

Built-in rules cover email, US SSN, Luhn-validated credit card, IPv4,
E.164 / NANP phone, IBAN, AWS access-key IDs, GitHub PATs, Slack
tokens, JWT, and `Bearer` headers. Prometheus metrics:
`gtv_redactions_total{kind}` and `gtv_redactions_rejected_total`.

### Consensus policy

The verdict engine's thresholds and confidence formula live in a YAML
policy, not in code. Point `GTV_POLICY_PATH` at your file; unset =
built-in default (legacy constants). The server loads the policy at
startup and refuses to boot with an invalid file — there's no silent
fall-through. See `docs/policy.md` for the full schema.

| Variable | Default | Purpose |
|---|---|---|
| `GTV_POLICY_PATH` | unset | YAML file declaring verdict thresholds, tier weights, confidence formula, and per-domain overrides. |

### Claim lifecycle

Append-only DAG tracking which envelopes supersede which, used by
`supersede_claim`, `/claims/{id}/history`, and `/claims/latest`. In-memory
by default (lost on restart); point `GTV_LIFECYCLE_DB` at a SQLite file
for persistence. The index enforces same-issuer continuity, rejects
self-supersede / unknown parents / cycles, and on supersede emits
`gtv_cache_invalidations_total{reason="superseded"}` while evicting the
parent's verdict cache entry.

| Variable | Default | Purpose |
|---|---|---|
| `GTV_LIFECYCLE_DB` | unset | SQLite path backing the supersede DAG. Unset = in-memory only. |

## Multi-tenant

One process can host multiple tenants, each signing under its own issuer DID. The verdict cache and lifecycle DAG are already keyed by issuer DID, so tenant isolation reduces to "give each tenant a distinct DID." Full walkthrough in `docs/multi-tenant.md`.

Quick provisioning:

```bash
gtv-admin-keys create \
  --label "Alice Research Ltd." \
  --scopes verify,consensus \
  --tenant alice \
  --issuer-did did:web:alice.example \
  --rate-limit 300
```

Per-tenant usage is exported as `gtv_tenant_requests_total{tenant_id, tool, verdict}`. The counter is intentionally separate from the core verdict/cache metrics so tenant cardinality does not multiply across every Grafana panel.

## Health, metrics, and probes

- `GET /health` — 200 when the server is ready. No auth.
- `GET /metrics` — Prometheus text format. No auth. Scrape at 15–60s.

For Kubernetes, use both as liveness and readiness probes.

## Performance targets

The pilot SLOs below are what the project treats as "green." Numbers are for a single uvicorn worker on a modern amd64/arm64 host with stub Sigstore/TSA. Real-anchor latency is dominated by the external services and is tracked separately.

| Operation | p50 | p99 |
|---|---:|---:|
| RFC 8785 canonical hash of a 5-evidence envelope | < 100 µs | < 500 µs |
| Verdict engine `decide` (5 evidence items) | < 50 µs | < 250 µs |
| `POST /tools/verify_claim` (stub mode) | < 25 ms | < 100 ms |

Run the in-tree regression guards with `GTV_PERF=1 pytest -m perf`. A sustained-load harness ships at `scripts/load_harness.py`:

```bash
python scripts/load_harness.py \
  --url http://localhost:8080 \
  --concurrency 20 \
  --duration 30 \
  --api-key $GTV_TEST_KEY
```

It reports throughput, p50/p95/p99 latency, and a status-code breakdown, and exits non-zero if the error rate exceeds 1% (configurable with `--max-error-rate`).

## Registry

- PyPI: `gtv`
- GHCR: `ghcr.io/groundtruth/gtv`
- Source: `https://github.com/groundtruth/gtv`

Images are published on tagged releases (`v*.*.*`) and signed with Cosign keyless OIDC. SBOMs are attached as Sigstore attestations.
