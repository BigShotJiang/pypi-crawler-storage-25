# Adapter SDK

The SDK lets you ship a **source adapter** as an independent PyPI
package instead of PR'ing it upstream. Install your package next to
`gtv` and the server picks it up at startup via Python entry points.

## The contract

Every adapter implements `gtv.adapters.sdk.SourceAdapter` — four async
methods plus four class attributes:

```python
from gtv.adapters.sdk import (
    SourceAdapter, RawSnapshot, HealthStatus, TrustTier,
    Stance, Claim, Evidence,
)


class MyAdapter(SourceAdapter):
    source_did = "did:web:my-source.example"
    name = "MySource"
    trust_tier = TrustTier.TIER_2
    freshness_sla_s = 3600

    async def query(self, claim: Claim, max_items: int = 5) -> list[Evidence]:
        ...

    async def snapshot(self, url: str) -> RawSnapshot:
        ...

    async def health(self) -> HealthStatus:
        ...

    async def close(self) -> None:
        ...
```

The rules:

- **Never fabricate evidence.** On any failure — network error,
  upstream 5xx, parse error — return `[]` and let `health()` report
  `state="DEGRADED"`.
- **Respect upstream rate limits.** Use per-adapter `httpx.AsyncClient`s
  with exponential backoff + jitter.
- **Emit stable hashes.** Every `Evidence` you return must carry the
  exact `raw_hash` (sha256) of the source document it came from.
- **`close()` must be idempotent** — callers may invoke it multiple times.
- **Async only.** Never block.

## Register via entry points

Declare your adapter in the `gtv.adapters` entry point group:

```toml
# pyproject.toml
[project.entry-points."gtv.adapters"]
my-source = "my_package:MyAdapter"
```

The key (`my-source`) is the plugin's human-readable name; the value
(`my_package:MyAdapter`) is the `module:class` path. gtv imports the
module, calls the class with no args, and registers the instance.

`pip install my-adapter` next to `gtv` — that's it. The server discovers
and registers your adapter at startup. Plugins that fail to load (import
error, instantiation crash, not actually a `SourceAdapter`) are logged
at `WARNING` and **skipped**, never crashed the server.

## The conformance suite

Before registering, prove your adapter meets the contract:

```python
# tests/test_my_adapter.py
import pytest
from gtv.adapters.conformance import run_adapter_conformance
from my_package import MyAdapter


@pytest.mark.asyncio
async def test_conforms() -> None:
    adapter = MyAdapter()
    try:
        await run_adapter_conformance(adapter)
    finally:
        await adapter.close()
```

The suite asserts:

1. Static fields are well-typed (DID starts with `did:`, `trust_tier`
   is a real enum value, `freshness_sla_s` is a positive int).
2. `health()` returns a `HealthStatus` without raising.
3. `query()` returns a `list[Evidence]` — not `None`, not a string.
4. `query()` swallows transient failures (doesn't raise).
5. Each `Evidence` carries the claim's `claim_id` and the adapter's
   `source_did` (no spoofing).
6. Each `Evidence` has a 64-char hex `raw_hash`.
7. `close()` is idempotent.

Passing the suite doesn't prove correctness — that's upstream-specific —
but it proves the adapter is **safe to register**. The gtv CI gate
runs this against every built-in adapter; out-of-tree adapters should
run it in their own CI.

## Operator controls

Operators can gate plugin loading:

| Env var                         | Effect                                          |
|---------------------------------|-------------------------------------------------|
| `GTV_DISABLE_PLUGIN_ADAPTERS=1` | Skip entry-point discovery entirely             |
| `GTV_PLUGIN_ADAPTER_ALLOWLIST`  | Comma-separated entry-point names to accept     |
| `GTV_DISABLE_DEFAULT_ADAPTERS`  | Start with no in-tree adapters (test deploys)   |

`GTV_PLUGIN_ADAPTER_ALLOWLIST=my-source,other-source` is the
lock-down-prod mode: only these exact plugins are accepted.

## Example

A minimal working example lives at `examples/adapters/example_external/`.
It's an "echo" adapter that returns the claim text back as a single
`NEUTRAL` evidence item — useful as a starting skeleton, not for real
verification.

## Version stability

Anything you import from `gtv.adapters.sdk` is frozen across minor
releases within a major. Internal imports (`gtv.adapters.base`,
`gtv.models`, adapter sibling modules) may change in any minor release —
don't depend on them.
