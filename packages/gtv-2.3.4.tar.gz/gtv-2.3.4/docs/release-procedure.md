# Release procedure

This is the operator checklist for cutting a new tagged release. The
release CI pipeline (`.github/workflows/release.yml`) does the heavy
lifting — builds sdist+wheel, publishes to PyPI via trusted publisher,
and creates a GitHub Release with the extracted CHANGELOG section —
but a few steps must happen on the main branch *before* the tag.

## Prerequisites

- `main` is green: `ci.yml`, `security.yml`, `docker.yml`, `nightly.yml`.
- `schema-drift` CI job is passing. If not: run `gtv-export-schemas
  write`, commit the diff, re-run.
- You've decided on the target version under semver (patch / minor /
  major).

## Step-by-step

### 1. Update version parity

Three files carry the version; they must match the tag you're about
to push:

- `pyproject.toml` → `[project] version = "X.Y.Z"`
- `src/gtv/__init__.py` → `__version__ = "X.Y.Z"`
- `CHANGELOG.md` → section header `## [X.Y.Z] - YYYY-MM-DD`

The `test_version_parity` test enforces this at pre-merge time, so
forgetting one will fail CI.

### 2. Promote `[Unreleased]` in CHANGELOG

```markdown
## [Unreleased]

_No changes yet._

## [X.Y.Z] - 2026-MM-DD

Short preamble. What's the theme of this release?

### Added / Changed / Fixed / Removed / Security

- (existing unreleased entries, moved down)
```

### 3. Regenerate schema artifacts

Even if nothing user-visible changed, re-run to be safe:

```bash
gtv-export-schemas write
git diff spec/
```

Commit any drift. The `schema-drift` CI job will block the tag
otherwise.

### 4. Write the migration guide (for major / minor)

For major versions, add `docs/migrations/<prev>-to-<new>.md`
covering: wire/signing compat, new endpoints, new env vars, new
CLIs, behavioural changes. For minor versions, a CHANGELOG
section is usually enough.

### 5. Land the release PR

```
chore(release): cut vX.Y.Z
```

Squash-merge once green.

### 6. Tag on main

```bash
git checkout main
git pull
git tag -a vX.Y.Z -m "vX.Y.Z"
git push origin vX.Y.Z
```

The tag push triggers `.github/workflows/release.yml`:

1. `build` — sdist + wheel, verifies `pyproject` version == tag.
2. `pypi-publish` — publishes via OIDC trusted publisher.
3. `github-release` — extracts the `[X.Y.Z]` section from CHANGELOG
   and creates a GitHub Release with sdist + wheel attached.

### 7. Verify artifacts

- PyPI: `pip install gtv==X.Y.Z` in a clean venv and run `gtv-verify
  --help`.
- GitHub Release page: CHANGELOG extract renders correctly, sdist +
  wheel attached.
- `ghcr.io/<org>/gtv:X.Y.Z` is published (via `docker.yml`, which
  reacts to the same tag).
- SBOMs (SPDX + CycloneDX) attached and Cosign-signed — they're
  uploaded as separate CI artifacts by `security.yml`.

### 8. Announce

- Post a release note to the project channels.
- If this is a major version, link to the migration guide.

## Rollback

PyPI is append-only — you can't overwrite a published version. If a
release is broken:

1. Yank the release on PyPI (`pip install gtv` continues to work for
   existing users; new installs see the next lower version).
2. Cut a patch release with the fix.
3. Delete the broken tag locally: `git tag -d vX.Y.Z`; the remote
   tag stays but the PyPI yank + patch release is the effective
   rollback.

Never force-push over a published tag — downstream pinning depends
on tag immutability.
