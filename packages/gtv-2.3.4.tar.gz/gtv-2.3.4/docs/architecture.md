# Architecture: Ground Truth Verification System

This document describes the system design, data flow, cryptographic anchoring, and verification workflow for gtv Phase 1.

**Audience:** Systems engineers, security reviewers, and researchers evaluating integration or trust.

## Goals and Non-Goals

### What gtv Does

1. **Accepts factual claims** via HTTP API, MCP stdio, or CLI.
2. **Queries federated sources** (arXiv, Crossref, INSPIRE-HEP, OpenAlex, Semantic Scholar) in parallel.
3. **Classifies claims** before adapter fan-out (opinion, creative, out-of-scope short-circuit).
4. **Decides a verdict** (VERIFIED, UNVERIFIED, CONTESTED, OPINION, CREATIVE, OUT_OF_SCOPE) with confidence.
5. **Seals the response** in a cryptographically anchored envelope.

### What gtv Is NOT

- **Not an oracle.** Sources can be wrong; gtv aggregates their evidence and applies rule-based logic, not consensus.
- **Not blockchain-backed.** No cryptocurrency, no PoW, no token incentives. Transparency is achieved via Rekor (an immutable append-only log with publicly verifiable proofs).
- **Not a fine-tuned LLM.** The verdict engine is deterministic, rule-based, and hand-tuned. Machine learning is Phase 2 scope.
- **Not centralized.** Federation registry is local-only in Phase 1; distributed consensus deferred to Phase 2.
- **Not a universal fact checker.** Scope is limited to physics, math, CS, astronomy, materials science; other domains are OUT_OF_SCOPE.

## End-to-End Request Flow

### verify_claim(claim, domain, max_sources)

```
┌────────────────────────────────────────────────────────────────────┐
│ 1. INTAKE: Parse request                                          │
│    - claim text (1–2000 chars)                                     │
│    - domain (physics, math, cs, astronomy, materials, general)     │
│    - max_sources (1–20, default 5)                                 │
└────────────────────────────────────────────────────────────────────┘
                              ↓
┌────────────────────────────────────────────────────────────────────┐
│ 2. CLASSIFY: Short-circuit if opinion/creative/out-of-scope        │
│    - Regex + lexicon (no LLM)                                      │
│    - Return early: verdict + rationale, no adapter calls           │
│    - Evidence list is empty; confidence is predefined (0.8–0.99)   │
└────────────────────────────────────────────────────────────────────┘
                              ↓
┌────────────────────────────────────────────────────────────────────┐
│ 3. ADAPTER FAN-OUT: Query 5 adapters in parallel                  │
│    - Each adapter calls its source API (arXiv, Crossref, etc.)     │
│    - Returns Evidence list: [source_did, excerpt, stance, URL, …]  │
│    - Timeouts/errors return [] (not fabricated results)            │
│    - Record per-adapter metrics (latency, status)                  │
└────────────────────────────────────────────────────────────────────┘
                              ↓
┌────────────────────────────────────────────────────────────────────┐
│ 4. VERDICT ENGINE: Rule-based decision                             │
│    - Count SUPPORTS vs REFUTES evidence                            │
│    - Apply trust-tier weighting (TIER_1=1.0, TIER_2=0.7, etc.)     │
│    - Age-adjust confidence (older evidence = lower confidence)     │
│    - Output: VerdictRecord (decision, confidence, rationale)       │
└────────────────────────────────────────────────────────────────────┘
                              ↓
┌────────────────────────────────────────────────────────────────────┐
│ 5. PROV-O GRAPH: Build evidence trail (W3C PROV-O JSON-LD)        │
│    - Entities: claim, evidence, verdict, sources                   │
│    - Relations: wasGeneratedBy, wasDerivedFrom, wasAttributedTo     │
│    - Serialize to JSON-LD string                                   │
└────────────────────────────────────────────────────────────────────┘
                              ↓
┌────────────────────────────────────────────────────────────────────┐
│ 6. CANONICALIZE: RFC 8785 JSON canonicalization                    │
│    - Field order, Unicode normalization, no whitespace             │
│    - Compute SHA-256 hash (hex)                                    │
│    - Payload includes: claim, verdict, evidence, rationale, DID    │
│    - Excluded: signature, Rekor proof, TSA tokens, timestamps      │
└────────────────────────────────────────────────────────────────────┘
                              ↓
┌────────────────────────────────────────────────────────────────────┐
│ 7. SIGN: Sigstore keyless ECDSA-P256 (if GTV_SIGSTORE_ENABLED)    │
│    - Detect ambient OIDC token (GitHub Actions, K8s, etc.)         │
│    - Request certificate from Fulcio (CA)                          │
│    - Sign canonical hash with ephemeral P-256 private key          │
│    - Submit to Rekor (automatic, inside sigstore library)          │
│    - Extract: signature (base64), certificate (PEM), Rekor entry   │
│    - If disabled: emit stub (stub://xxxx, clearly marked)          │
└────────────────────────────────────────────────────────────────────┘
                              ↓
┌────────────────────────────────────────────────────────────────────┐
│ 8. TIMESTAMP (RFC 3161 Dual TSA):                                  │
│    - Primary: FreeTSA (required, fail-hard)                        │
│    - Secondary: DigiCert (best-effort, silent fail)                │
│    - Both: RFC 3161 TimeStampRequest/Response over HTTP(S)         │
│    - Output: tsr_b64 (base64-encoded TSR)                          │
│    - If disabled: emit stub (clearly marked)                       │
└────────────────────────────────────────────────────────────────────┘
                              ↓
┌────────────────────────────────────────────────────────────────────┐
│ 9. SEAL ENVELOPE: Construct and return                             │
│    - verdict: VERIFIED | UNVERIFIED | CONTESTED | …                │
│    - confidence: float (0.0–1.0)                                   │
│    - evidence: [Evidence, …]                                       │
│    - signature: base64                                             │
│    - rekor_uuid, rekor_log_index                                   │
│    - tsa_token: primary TSR (base64)                               │
│    - anchor_proof: {inclusion_proof, tsr_primary, tsr_secondary}   │
│    - prov_graph: PROV-O JSON-LD string                             │
│    - issuer_did: (from GTV_ISSUER_DID env)                         │
└────────────────────────────────────────────────────────────────────┘
```

### retrieve_facts(query, domain, max_results)

Similar to verify_claim, but:
1. Extract multiple sub-claims from free text (heuristic).
2. Verify each sub-claim concurrently (call _verify_one for each).
3. Gather results into a RetrieveFactsEnvelope with FactItem list.
4. Sign and seal the envelope (same as verify_claim).

## Envelope Schema

Every response is a signed, timestamped, anchored Envelope.

| Field | Type | Purpose |
|-------|------|---------|
| `envelope_id` | UUIDv4 | Unique identifier for this response |
| `verdict` | Verdict enum | Decision: VERIFIED, UNVERIFIED, CONTESTED, OPINION, CREATIVE, OUT_OF_SCOPE |
| `confidence` | float [0, 1] | Confidence in the verdict (0.5 if no evidence, up to 0.99) |
| `evidence` | Evidence[] | List of sources: {source_did, excerpt, stance, url, retrieved_at, raw_hash, …} |
| `rationale` | string | Human-readable explanation (≤1500 chars) |
| `issuer_did` | string | DID of the verifier issuing this envelope |
| `issued_at` | ISO 8601 datetime | When the envelope was created (UTC) |
| `signature` | base64 string | ECDSA-P256 signature over canonical hash (or stub://) |
| `rekor_uuid` | string | Rekor transparency log entry UUID |
| `rekor_log_index` | integer | Position in Rekor's merkle tree |
| `tsa_token` | base64 string | RFC 3161 TimestampToken from primary TSA |
| `prov_graph` | string | PROV-O JSON-LD provenance graph |
| `anchor_proof` | AnchorProof | Cryptographic proofs (see below) |

### AnchorProof (nested)

| Field | Type | Purpose |
|-------|------|---------|
| `rekor_inclusion_proof` | JSON string | RFC 6962 merkle tree proof + checkpoint (or stub://) |
| `tsa_tsr_primary` | base64 string | RFC 3161 TimeStampResponse from primary TSA |
| `tsa_tsr_secondary` | base64 string \| null | RFC 3161 TSR from secondary TSA (optional) |

## Canonicalization (RFC 8785 JCS)

Before signing, the envelope is canonicalized per RFC 8785 (JSON Canonicalization Scheme):

1. **Field order:** Alphabetical, deterministic.
2. **Number representation:** No scientific notation; integers have no decimals.
3. **Unicode:** NFC normalization.
4. **Whitespace:** None (compact form).
5. **Excluded fields:** signature, rekor_uuid, rekor_log_index, tsa_token, anchor_proof, issued_at (mutable).

The canonical form is hashed with SHA-256, producing a 64-character hex string.

**Why this matters:** Different serializers (Python, Go, JS) must produce identical hashes for the same content. RFC 8785 ensures this. Verification recomputes the canonical hash and checks it against the signature.

## Signing (Sigstore Keyless OIDC)

When `GTV_SIGSTORE_ENABLED=1`:

1. **Ambient credential detection:** Check for OIDC token in environment.
   - GitHub Actions: `ACTIONS_RUNTIME_TOKEN` + `ACTIONS_ID_TOKEN_REQUEST_URL`
   - Kubernetes: `/var/run/secrets/kubernetes.io/serviceaccount/token`
   - GCP Workload Identity: metadata service
   - Others: Sigstore's credential chain

2. **Fulcio request:** Exchange OIDC token for an ephemeral X.509 certificate (valid ~4 min).
   - Certificate binds identity (e.g., `github-actions@github.com`) to a public key (P-256).

3. **Sign the canonical hash:** Use the ephemeral private key to sign SHA-256 hash.
   - Algorithm: ECDSA with SHA-256 over P-256 curve.

4. **Rekor submission:** Automatic inside sigstore library.
   - Submits Hashed Rekord entry (the canonical hash + metadata).
   - Returns UUID and merkle tree inclusion proof.

5. **Stub path** (when disabled): Emit `stub://{hash}` signature for local dev/testing.
   - Clearly marked; offline verifier rejects unless `--allow-stub` is set.

**Staging vs Production:**
- Staging: Fulcio staging URL, Rekor staging instance.
- Production: Public Fulcio, public Rekor (https://rekor.sigstore.dev).
- Phase 1 default: Production (Sigstore public infrastructure).

## Transparency Log (Rekor)

Rekor is an append-only, tamper-evident log of software signatures. gtv uses it to prove that a signature was issued at a specific point in time and has not been forged retroactively.

### Submission (Automatic)

The sigstore library submits to Rekor during signing. The submission includes:
- **Entry type:** Hashed Rekord (raw hash + metadata).
- **Canonical hash:** The RFC 8785-canonicalized envelope hash.
- **Certificate:** Sigstore certificate (Fulcio-issued).

### Inclusion Proof (RFC 6962)

Rekor returns:
- **UUID:** Unique identifier for this log entry.
- **Log index:** Position in the log (0-based).
- **Tree size:** Total number of entries at submission time.
- **Root hash:** The merkle tree root at that tree size.
- **Proof hashes:** Sibling hashes needed to reconstruct the root from the leaf.
- **Checkpoint:** Signed statement of the log root (signed by Rekor's private key).

The verifier (offline) recomputes the root hash using the leaf hash and proof hashes, then verifies the checkpoint signature against Rekor's public key (loaded from the environment or hard-coded).

### Log Root Trust

The checkpoint signature proves that Rekor committed to this tree size at this root hash. Without the checkpoint signature, the proof is meaningless (anyone could fabricate a merkle tree).

**In Phase 1:** Rekor's public key is loaded from the environment. In production, it should be fetched from a well-known endpoint and cached with a short TTL.

## Time-Stamping (RFC 3161 Dual TSA)

Timestamps prove the "clock reading" at the time of signing, independent of the signer's local clock.

### Primary TSA: FreeTSA

- **URL:** https://freetsa.org/tsr
- **Authority:** Publicly trusted (DigiCert-issued certificate chain).
- **Response:** RFC 3161 TimeStampResponse (DER-encoded).
- **Fail semantics:** Hard fail. If primary TSA is down, the endpoint returns an error.

### Secondary TSA: DigiCert

- **URL:** http://timestamp.digicert.com
- **Authority:** Industry standard.
- **Response:** RFC 3161 TimeStampResponse.
- **Fail semantics:** Best-effort. If secondary fails, log a warning and proceed with just the primary.

### Verification

An offline verifier decodes the TSR, extracts the timestamp, and verifies that the TSR is:
1. Signed by the TSA (signature verification against TSA certificate chain).
2. The digest inside the TSR matches the canonical hash (same hash, same algorithm).
3. The timestamp is recent (not forged to an old date).

**W4 (Week 4) limitation:** RFC 3161 verification is not yet implemented in gtv-verify. Timestamps are logged but not cryptographically verified offline. This is marked clearly in the CLI output.

## Verification Flow (gtv-verify CLI)

```
gtv-verify [--allow-stub] [--allow-unrooted] [--trust-issuer] [--allow-unlisted] envelope.json
```

### Step 1: Load and Parse

- Read JSON file.
- Validate against Envelope schema.
- Print canonical-hash (recomputed from contents).

### Step 2: Detect Stubs

- If signature starts with `stub://`, alert and return 2 (unless `--allow-stub`).
- If inclusion_proof starts with `stub://`, alert and return 2 (unless `--allow-stub`).

### Step 3: Verify Signature

- Decode signature (base64).
- Extract certificate from inclusion_proof JSON.
- Load certificate (X.509 PEM).
- Verify ECDSA-P256 signature against canonical hash.
- **Exit 3** if verification fails.

### Step 4: Verify Rekor Proof

- Parse inclusion_proof JSON.
- Extract log_index, tree_size, root_hash, hashes (proof), checkpoint.
- Recompute merkle tree root using leaf hash and proof hashes (RFC 6962).
- Check computed root against claimed root.
- Verify checkpoint signature against Rekor public key (unless `--allow-unrooted`).
- **Exit 4** if proof is invalid or root doesn't match.
- **Exit 6** if Rekor public key is missing or untrusted.

### Step 5: Verify Issuer Identity

(Skipped if `--trust-issuer` is set)

- Look up issuer_did in federation registry (unless `--allow-unlisted`).
- Resolve issuer_did via DID document (did:web only in Phase 1).
- Extract expected identity from DID doc (email, OIDC issuer URL).
- Extract certificate from inclusion_proof.
- Verify certificate's identity matches expected identity.
- **Exit 7** if identity does not match.

### Step 6: TSA Verification

(W4 — not yet implemented)

- Log "INFO: TSA verification pending (W4)."
- Actual cryptographic verification of RFC 3161 TSR is deferred.

### Exit Codes

| Code | Condition |
|------|-----------|
| 0 | Envelope fully verified |
| 2 | Stub signature or proof detected; return 0 only if `--allow-stub` |
| 3 | Signature verification failed (ECDSA check) |
| 4 | Rekor merkle tree proof is invalid or root hash mismatch |
| 5 | Schema validation or JSON parse error |
| 6 | Rekor log-root key missing or signature verification failed |
| 7 | Issuer identity verification failed (certificate doesn't match DID) |
| 64 | Usage error (missing envelope path, invalid flags) |

## Federation

The federation is a registry of trusted issuers. In Phase 1, it is a local JSON file.

### TrustedIssuer Model

```python
class TrustedIssuer:
    did: str                           # e.g., "did:web:verify.groundtruth.example"
    trust_tier: TrustTier             # TIER_1, TIER_2, or TIER_3
    display_name: str                 # Human-readable name
    expected_fulcio_oidc: str | None  # OIDC issuer URL expected in cert
    expected_issuer_email: str | None # Email identity expected in cert
    notes: str | None                 # Metadata / comments
```

### IssuerRegistry

In-memory, thread-unsafe (Phase 1 only).

```python
class IssuerRegistry:
    def add(issuer: TrustedIssuer) -> None        # Register issuer
    def get(did: str) -> TrustedIssuer | None    # Lookup by DID
    def remove(did: str) -> None                  # Unregister issuer
```

### Loading

```python
registry = load_registry_from_json("issuers.json")
registry = load_registry_from_env("GTV_FEDERATION_REGISTRY")  # Fallback to default
```

### Default Registry

If `GTV_FEDERATION_REGISTRY` is not set, the verifier loads a minimal default registry (self-signed stub for local testing).

### Phase 2 Scope

- Distributed registry (IPFS, blockchain, OIDC federation).
- Public registry (published by a trusted root).
- Trust on first use (TOFU) with revocation.

## Observability

### Prometheus Metrics

All paths record:

```
gtv_verdict_total{verdict="VERIFIED|...",confidence_band="high|medium|low"} = count
gtv_adapter_call_duration_seconds{source_did="...",status="ok|timeout|error"} = histogram
gtv_adapter_call_status_total{source_did="...",status="ok|timeout|error"} = count
```

### OpenTelemetry Tracing

FastAPI instrumentation is enabled by default. Export via:

```bash
export OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:4318
export OTEL_TRACES_EXPORTER=otlp_proto_http
```

Traces include:
- Request duration (end-to-end).
- Per-adapter latency.
- Classification latency.
- Verdict engine latency.
- Signing latency.
- TSA latency.

## Testing Tiers

### Default (Stubs Only)

```bash
pytest -q
```

All cryptographic operations use stubs. Signatures are marked `stub://`. No network calls. Fast (~10–30 sec).

### GTV_LIVE=1 (Live Adapters)

```bash
GTV_LIVE=1 pytest tests/adapters/
```

Hit live arXiv, Crossref, INSPIRE-HEP, OpenAlex, Semantic Scholar APIs. No rate-limit abuse (use low max_results). Network required. ~1–2 min.

### GTV_SIGSTORE_ENABLED=1 (Real Signing)

```bash
GTV_SIGSTORE_ENABLED=1 pytest tests/test_anchor_sigstore.py
```

Real OIDC token detection, Fulcio certificate request, Rekor submission. Requires ambient OIDC token (GitHub Actions runner, K8s pod, etc.). ~30–60 sec per test.

### GTV_TSA_ENABLED=1 (Real Timestamping)

```bash
GTV_TSA_ENABLED=1 pytest tests/test_anchor_tsa.py -m live
```

Real RFC 3161 requests to FreeTSA + DigiCert. Network required. ~5–10 sec per test (TSAs have rate limits).

### GTV_DOCKER=1 (Docker Smoke)

```bash
GTV_DOCKER=1 pytest tests/test_docker_smoke.py
```

Build and run Dockerfile, verify HTTP server starts and responds. Docker required. ~1–2 min.

### GTV_E2E_LIVE=1 (Full End-to-End)

```bash
GTV_E2E_LIVE=1 GTV_SIGSTORE_ENABLED=1 GTV_TSA_ENABLED=1 pytest tests/test_e2e_integration.py
```

Full round-trip: claim → verify → sign (real) → timestamp (real) → seal → verify offline. All services required. ~2–5 min.

### GTV_STDIO_SMOKE=1 (MCP Stdio)

```bash
GTV_STDIO_SMOKE=1 pytest tests/test_stdio_smoke.py
```

MCP JSON-RPC over stdio. Verify list_tools, call verify_claim, check response shape. ~10 sec.

## CI Layout

### ci.yml (Every PR)

1. **test:** ruff check, mypy strict, pytest (stubs only). ~3 min.
2. **schema-validate:** Validate envelope JSON against schema. ~1 min.
3. **sbom:** Generate SPDX SBOM, sign with Cosign (keyless). ~2 min.

### nightly.yml (Daily at 0700 UTC)

1. **live-adapters:** GTV_LIVE=1, hit all adapters. ~5 min.
2. **live-sigstore:** GTV_SIGSTORE_ENABLED=1, real Sigstore. ~5 min.
3. **live-tsa:** GTV_TSA_ENABLED=1, real RFC 3161. ~10 min.
4. **docker-smoke:** Build image, run health check. ~10 min.
5. **live-e2e:** Full end-to-end with all services. ~10 min.

### docker.yml (On tag v*)

1. **build:** Build multi-arch image (amd64, arm64), push to GHCR. ~10 min.
2. **scan:** Grype vulnerability scan. ~5 min.
3. **sign:** Cosign sign image (keyless). ~2 min.

## Known Limitations and Open Work

### DID Resolution

- **Current:** `did:web` only (HTTP fetch + JSON parsing).
- **Limitation:** No caching, no rate limiting, no fallback.
- **Next:** Add caching, support `did:key` and `did:github`.

### Rekor Keys

- **Current:** Public key loaded from env or hardcoded (staging/prod variants available).
- **Limitation:** No automatic key rotation, no key discovery protocol.
- **Next:** Fetch from Rekor's well-known endpoint with TTL caching.

### RFC 3161 Verification

- **Current:** Timestamps are collected and stored but not cryptographically verified offline (W4).
- **Next:** Implement TSR parsing, signature verification, time validation.

### Federation Registry

- **Current:** Local JSON file only.
- **Limitation:** No distribution, no consensus, no revocation.
- **Next:** Distributed registry (IPFS, blockchain, or OIDC federation).

### Claim Classification

- **Current:** Regex + lexicon (regex-based detection of opinion/creative/out-of-scope).
- **Limitation:** No semantic understanding; false positives possible.
- **Next:** Fine-tuned classifier or learned embeddings (Phase 2).

### Verdict Engine Confidence

- **Current:** Hand-tuned formula: `0.5 + 0.15*count + 0.05*tier_bonus - 0.1*age_norm`.
- **Limitation:** Not calibrated against ground truth; no confidence intervals.
- **Next:** Calibrated ranker with learned weights (Phase 2).

### Adapter Timeouts

- **Current:** Default 10 sec per adapter, hard-coded.
- **Limitation:** No per-adapter tuning, no circuit breaker.
- **Next:** Adaptive timeout, circuit breaker, fallback sources.

### Scope Coverage

- **Current:** physics, math, CS, astronomy, materials science.
- **Limitation:** Other domains are OUT_OF_SCOPE.
- **Next:** Expand adapters for history, biology, social sciences (Phase 2+).
