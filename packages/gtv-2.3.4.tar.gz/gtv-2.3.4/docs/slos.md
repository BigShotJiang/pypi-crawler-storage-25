# Service Level Objectives

gtv's SLOs are the operator contract: if we stay inside these budgets,
callers can treat verdicts as on-time and adapter coverage as
sufficient. The SLIs are defined as recording rules in
[`deploy/observability/prometheus/recording-rules.yml`](https://github.com/mark-hallam/gtv/blob/main/deploy/observability/prometheus/recording-rules.yml)
and the alerts that fire when we breach them live in
[`alerting-rules.yml`](https://github.com/mark-hallam/gtv/blob/main/deploy/observability/prometheus/alerting-rules.yml).

The dashboard that renders all of this is
[`grafana/dashboards/gtv-overview.json`](https://github.com/mark-hallam/gtv/blob/main/deploy/observability/grafana/dashboards/gtv-overview.json).

## Summary

| SLO | Target | Window | Severity | Recording rule |
|-----|--------|--------|----------|----------------|
| Adapter availability | ≥ 99.5% | 30 days | warning | `gtv:adapter_availability:ratio_rate30d` |
| `verify_claim` latency | ≥ 95% under 5s | any 5m window | warning | `gtv:verify_latency:ratio_under_budget_rate5m` |
| Signature integrity | 0 mismatches | trailing 5m | **critical** | raw `gtv_cache_invalidations_total{reason="signature_mismatch"}` |

Anything not listed here is informational: cache hit ratio, per-tenant
verdict mix, redaction counts by kind. These drive decisions but don't
page.

## Why these three

We picked each SLO from ground-up: what does "working gtv" mean?

1. **Answers arrive.** If verify_claim has 90% availability and 10% of
   requests error, the service is broken — regardless of how fast the
   other 90% are.
2. **Answers arrive quickly enough.** Agents composing gtv into chains
   can't tolerate unbounded tail latency. 5s is roughly the limit
   where a user-facing agent stays conversational.
3. **Answers can be trusted.** Every envelope is signed; the signed
   verdict cache re-verifies on read. If that invariant ever fails
   we've lost the core security property — and the whole product
   goes with it.

Everything else (cache hit ratio, adapter p95, non-VERIFIED share) is
diagnostic detail for debugging *why* one of these three budgets is
burning.

## SLI definitions

### Adapter availability

```promql
sum(rate(gtv_adapter_latency_seconds_count{outcome="ok"}[30d]))
  /
sum(rate(gtv_adapter_latency_seconds_count[30d]))
```

Read directly off the histogram's `_count` series, split by
`outcome` — "ok" is the numerator, everything (including "error" and
"timeout") is the denominator. The 5m recording rule powers the
panel; the 30d rule powers the SLO stat and alert.

### verify_claim latency

```promql
sum(rate(gtv_verify_duration_seconds_bucket{le="5.0"}[5m]))
  /
sum(rate(gtv_verify_duration_seconds_count[5m]))
```

Bucket-ratio rather than quantile, because quantile-over-5m-rate is
too noisy for a per-window alert. We ask: **what fraction finished
under the budget?** — and alert when that fraction drops below 95%.

### Signature integrity

```promql
increase(gtv_cache_invalidations_total{reason="signature_mismatch"}[5m]) > 0
```

Not a ratio, not a budget — a hard tripwire. One mismatch in five
minutes fires the alert.

## Error budgets

Over a 30-day window, a 99.5% availability SLO allows 3h 36m of
adapter-outcome degradation. We don't automate budget-exhaustion
deploy freezes yet — W35 ships the measurement, W36 adds the policy
loop.

## Runbooks

### `GtvSignatureMismatch`

**P0 — treat as either a key-rotation bug or a cache-tampering
incident.** A signed envelope pulled from the verdict cache failed
its own signature check. The server already evicted the cached
entry, but the incident itself needs attention.

1. Check whether an issuer DID was recently rotated
   (`grep issuer_did src/gtv/auth/*.py`) — if so, the old entries
   should have been flushed, and the rotation runbook is incomplete.
2. Inspect the cache backend directly (Redis `KEYS verdict:*`, or
   SQLite table `verdict_cache`). Any entry still present that
   references the rotated key is a known-bad blob to remove.
3. If no rotation happened: the cache storage layer was tampered
   with. Take the service out of rotation, rotate the cache backing
   store, and file a security incident.

### `GtvAdapterAvailabilityBelowSLO`

Most commonly one adapter is timing out and dragging the fleet
ratio. Open **Adapters → Adapter error rate** on the dashboard,
identify the offender, and either:

- Short-term: disable the adapter via its env var
  (`GTV_ARXIV_DISABLE=1` etc.) to stop bleeding budget.
- Long-term: raise its `freshness_sla_s` if the adapter is slow but
  correct, or investigate the upstream if it's actually down.

#### Automated mitigation: circuit breaker

Enable with `GTV_CB_ENABLED=1`. Every registered adapter is then
wrapped in a rolling-window failure tracker. When the failure ratio
over the last `GTV_CB_WINDOW` calls exceeds `GTV_CB_FAILURE_RATIO`,
the breaker trips OPEN: `query()` returns `[]` instantly and
`snapshot()` raises `CircuitOpenError` until `GTV_CB_COOLDOWN_S`
elapses. The next call is a probe — one success closes the breaker,
one failure re-opens it with a fresh timer. This keeps a single sick
adapter from dominating p95 and typically buys back latency budget
until the root cause is fixed.

| Env var | Default | Meaning |
|---|---|---|
| `GTV_CB_ENABLED` | `0` | Master switch |
| `GTV_CB_WINDOW` | `20` | Sample size |
| `GTV_CB_MIN_SAMPLES` | `5` | Calls required before evaluating |
| `GTV_CB_FAILURE_RATIO` | `0.5` | Trip threshold |
| `GTV_CB_COOLDOWN_S` | `30` | OPEN → HALF_OPEN delay |

State is exported as `gtv_circuit_state{adapter="..."}` (0=CLOSED,
1=HALF_OPEN, 2=OPEN). Alert on `gtv_circuit_state == 2` for >5m to
page on an adapter that isn't recovering on its own.

### `GtvVerifyLatencySLOBreach`

Usually one of:

1. An adapter with a long p95 tail is fanning out into every
   request. Adapter p95 panel identifies it.
2. The verdict cache hit ratio has collapsed (cache restart,
   schema migration). Cache ratio panel confirms.
3. An upstream LLM / classifier is slow. Check
   `gtv_adapter_latency_seconds{adapter="classifier"}` or equivalent.

The fastest mitigation is usually to raise `timeout_s` on the slow
adapter so it fails fast rather than hanging near the budget.
