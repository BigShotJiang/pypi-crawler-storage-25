# Ground Truth Verification (gtv) — Pilot Deployment Guide

Deploy gtv in 15 minutes using Docker Compose. No database, no Kubernetes. Minimal, production-ready.

## Prerequisites

- Docker (20.10+) and Docker Compose (2.0+)
- `curl` or any HTTP client
- (Optional) OIDC identity provider for Sigstore keyless signing (GitHub, Google, etc.)

## Quick Start

### 1. Clone and copy environment

```bash
git clone https://github.com/your-org/gtv.git
cd gtv
cp .env.example .env
```

Edit `.env` only if you need to customize issuer DID, enable signing/timestamping, or add adapter API keys.

### 2. Start the service

```bash
docker compose up -d
```

The service builds and starts in ~30 seconds. Check logs:

```bash
docker compose logs -f gtv
```

### 3. Verify health

```bash
curl http://localhost:8080/health
# Response: {"status": "healthy"}
```

### 4. Verify your first claim

```bash
curl -X POST http://localhost:8080/tools/verify_claim \
  -H 'Content-Type: application/json' \
  -d '{
    "claim": "Water is H2O",
    "domain": "chemistry",
    "max_sources": 3
  }' | jq .
```

Expected response (excerpt):

```json
{
  "envelope": {
    "verdict": "VERIFIED",
    "confidence": 0.87,
    "evidence": [
      {
        "source_did": "did:web:arxiv.org",
        "stance": "SUPPORTS",
        "url": "https://arxiv.org/abs/..."
      }
    ],
    "signature": "<base64>",
    "rekor_uuid": null,
    "tsa_token": null
  }
}
```

The signature and Rekor UUID are stubbed by default (GTV_SIGSTORE_ENABLED=0, GTV_TSA_ENABLED=0).

## Trust Model & Federation

Every envelope is evidence-backed. Add your issuer DID to the federation registry:

Create `federation-registry.json`:

```json
[
  {
    "did": "did:web:verify.your-org.example",
    "trust_tier": "TIER_1",
    "display_name": "Your Org Verifier",
    "expected_fulcio_oidc": "https://token.actions.githubusercontent.com",
    "expected_issuer_email": "github-actions@github.com",
    "notes": "GitHub Actions–based verifier for pilot."
  }
]
```

Then:

```bash
export GTV_FEDERATION_REGISTRY=/path/to/federation-registry.json
export GTV_ISSUER_DID=did:web:verify.your-org.example
docker compose restart gtv
```

For DID resolution: use `did:web` (resolves via HTTPS to `.well-known/did.json`) or `did:key` (self-contained).

To use `did:web:verify.your-org.example`, serve a DID document at:

```
https://verify.your-org.example/.well-known/did.json
```

For development, the default `did:web:verify.groundtruth.example` is sufficient for testing.

## Enable Signing & Anchoring

By default, gtv emits stub signatures. To enable real signing:

### Sigstore (ECDSA-P256 Keyless)

```bash
export GTV_SIGSTORE_ENABLED=1
export GTV_SIGSTORE_PROD=0  # Use staging first; set to 1 for production
docker compose restart gtv
```

Requires OIDC provider authentication (GitHub Actions, Google, etc.).

### RFC 3161 Timestamping

```bash
export GTV_TSA_ENABLED=1
export GTV_TSA_PRIMARY_URL=https://freetsa.org/tsr
export GTV_TSA_SECONDARY_URL=http://timestamp.digicert.com
docker compose restart gtv
```

## Observability

### Prometheus Metrics

Metrics available at `/metrics`:

```bash
curl http://localhost:8080/metrics | grep gtv_verdict_total
```

Exposed metrics:
- `gtv_verdict_total` (counter): verdicts by class and confidence band.
- `gtv_adapter_call_duration_seconds` (histogram): per-adapter latency.
- `gtv_adapter_call_status_total` (counter): per-adapter success/timeout/error.

### OTLP Tracing (Optional)

```bash
export GTV_OTEL_ENDPOINT=http://localhost:4317
docker compose restart gtv
```

## API Authentication

By default, `/verify_claim`, `/retrieve_facts`, and `/consensus` endpoints are **unauthenticated** for local development. To enable authentication:

### Enable API Keys

Set `GTV_API_KEYS` in `.env`:

```bash
export GTV_API_KEYS=pilot-key-001,pilot-key-002
docker compose restart gtv
```

Then all public endpoints require `Authorization: Bearer <key>` header:

```bash
curl -X POST http://localhost:8080/tools/verify_claim \
  -H 'Authorization: Bearer pilot-key-001' \
  -H 'Content-Type: application/json' \
  -d '{
    "claim": "Water is H2O",
    "domain": "chemistry",
    "max_sources": 3
  }' | jq .
```

Missing or invalid keys return 401 Unauthorized.

### Rate Limiting

Each key is limited to 60 requests per minute by default (sliding window). Configure via:

```bash
export GTV_RATE_LIMIT_PER_MINUTE=100
docker compose restart gtv
```

Excess requests return 429 Too Many Requests with a `Retry-After: 60` header.

### Unauthenticated Endpoints

`/health` and `/metrics` remain **always unauthenticated**, even with `GTV_API_KEYS` set.

## Operating Model

### View logs

```bash
docker compose logs -f gtv
```

### Health check

```bash
curl http://localhost:8080/health
```

Docker Compose checks every 30 seconds; after 3 failures, marks unhealthy.

### Rolling restart (zero downtime)

```bash
docker compose build gtv
docker compose up -d --no-deps gtv
```

### Stop the service

```bash
docker compose down -v
```

### Troubleshooting

```bash
docker compose logs gtv
docker compose build --no-cache gtv
docker compose up -d gtv
```

If adapter calls time out, see `src/gtv/adapters/base.py` for tuning.

## Support

- Email: markhallam@curble.com
- GitHub Issues: [submit an issue](https://github.com/your-org/gtv/issues)

For production deployments, see [`docs/architecture.md`](architecture.md) for design details and threat model.
