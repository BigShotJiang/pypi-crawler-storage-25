# Getting started

## Install

=== "PyPI (v0.1.0 pilot)"

    ```bash
    pip install gtv
    ```

=== "Editable (for development)"

    ```bash
    git clone https://github.com/groundtruth/gtv
    cd gtv
    pip install -e '.[dev]'
    ```

=== "Docker"

    ```bash
    docker pull ghcr.io/groundtruth/gtv:v0.1.0
    docker run --rm -p 8080:8080 ghcr.io/groundtruth/gtv:v0.1.0
    ```

    The image is distroless, multi-arch (amd64/arm64), Cosign-signed.

Requires Python 3.12+.

## Verify a claim from the CLI

```bash
gtv-demo "The Higgs boson mass is 125 GeV"
```

That runs the full stub pipeline: retrieve evidence from the built-in adapters, compute a verdict, canonicalize, sign (stubbed unless `GTV_SIGSTORE_ENABLED=1`), anchor (stubbed unless `GTV_TSA_ENABLED=1`), and print the resulting envelope.

## Verify a claim from an agent

gtv speaks MCP — use the tool from any MCP-aware client. Over HTTP:

```bash
curl -X POST http://localhost:8080/tools/verify_claim \
  -H 'content-type: application/json' \
  -d '{
    "claim": "The speed of light in vacuum is 299,792,458 m/s.",
    "domain": "physics",
    "max_sources": 3
  }'
```

The response contains a fully-formed `Envelope` (see [API: HTTP / MCP](api-http.md)).

## Verify an envelope offline

Save the `envelope` field from the response to a file, then:

```bash
gtv-verify envelope.json
```

`gtv-verify` has zero external dependencies at verification time. It checks:

1. Canonical JSON hash matches the signed-over payload.
2. Sigstore signature verifies against the canonical hash.
3. Rekor inclusion proof matches the claimed log index.
4. Issuer identity from the DID document matches the Sigstore certificate.
5. At least one RFC 3161 TSR verifies over the canonical hash.

Exit code `0` means fully verified. Any other exit code is an audit failure — see `gtv-verify --help` for the codes.

## Run against live services

For real Sigstore / Rekor / TSA anchoring:

```bash
export GTV_SIGSTORE_ENABLED=1
export GTV_TSA_ENABLED=1
uvicorn gtv.mcp.server:app --host 0.0.0.0 --port 8080
```

See [Deployment](deployment.md) for the full list of environment variables.
