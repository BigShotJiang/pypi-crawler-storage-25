# Ground Truth Verification

> Cryptographically-provable fact-checking for LLM agents.

**gtv** is a federated, MCP-native verifier that AI agents call as a tool. Every verdict comes back as a signed `Envelope` — a canonical JSON structure committed to the public Rekor transparency log, timestamped by two independent RFC 3161 TSAs, and traceable back through a PROV-O graph to the evidence it was built from.

## Why this exists

LLM outputs are unaudited. Enterprise buyers in regulated domains — legal, clinical, financial, scientific — can't accept agent decisions without independently verifiable proof of the evidence those decisions were built on. Human fact-checking doesn't scale with agent throughput. gtv closes that gap: one MCP call, one cryptographically-anchored verdict.

## What it gives you

- **Signed verdicts.** Sigstore keyless OIDC, optionally BYOK Ed25519 / P-256 / secp256k1.
- **Public anchoring.** Rekor transparency log inclusion proof on every envelope.
- **Independent timestamps.** RFC 3161 dual-TSA (primary + fallback).
- **Tier-weighted federation.** Signed consensus across multiple independent verifiers.
- **Revocation & audit.** Signed revocation lists, hash-chained Ed25519-signed audit log.
- **Eight evidence adapters.** arXiv, INSPIRE-HEP, Crossref, OpenAlex, Semantic Scholar, PubMed, NIST, Retraction Watch.
- **MCP-native.** HTTP and JSON-RPC stdio. Drop into any MCP-aware agent framework.
- **Distroless Docker image.** Multi-arch, Cosign-signed, SBOM attached.

## 30-second tour

```bash
pip install gtv
gtv-demo "The Higgs boson mass is 125 GeV"
```

That prints a verdict, then a full signed envelope you can verify offline with `gtv-verify`.

## Where to go next

- **[Getting started](getting-started.md)** — install, run the demo, verify an envelope.
- **[Architecture](architecture.md)** — system design, threat model, data flow.
- **[API: HTTP / MCP](api-http.md)** — `/verify_claim`, `/retrieve_facts`, `/consensus`.
- **[Deployment](deployment.md)** — Docker, env vars, GHCR.
- **[Federation](federation.md)** — persistent trust registry, tier weights, signed updates.
- **[Security](security.md)** — threat model, incident response.
- **[Pilot onboarding](pilot-onboarding.md)** — 15-minute path from `docker run` to signed verdicts.
