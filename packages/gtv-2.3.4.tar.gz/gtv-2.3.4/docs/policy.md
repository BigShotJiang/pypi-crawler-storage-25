# Consensus policy (operator guide)

The verdict engine's thresholds and confidence formula are declared in
a YAML file, not hardcoded. This lets you tighten or loosen
verification rules without recompiling the server.

## Loading

Point `GTV_POLICY_PATH` at your YAML file. If unset, gtv uses the
built-in default policy, which exactly matches the legacy hardcoded
constants.

```bash
export GTV_POLICY_PATH=/etc/gtv/policy.yaml
```

Malformed files fail fast at startup — gtv will not boot with an
invalid policy. Unknown `domains.*` keys are rejected (no silent typos).

## Full schema

```yaml
# Minimum distinct sources that must SUPPORT a claim for VERIFIED.
min_supports_for_verified: 2     # int >= 1, default 2

# Minimum distinct sources that must REFUTE a claim for "verified negation."
min_refutes_for_negation: 2      # int >= 1, default 2

# Per-tier weight in the confidence bonus term. Values in [0, 1].
tier_weights:
  tier_1: 1.0
  tier_2: 0.7
  tier_3: 0.4

# Linear confidence model:
#   clamp(base + per_source * N + per_tier_bonus * W - age_penalty * age_norm, 0, 0.99)
# where N = distinct source count, W = tier_bonus, age_norm = min(1, oldest_months / age_horizon_months).
confidence:
  base: 0.5
  per_source: 0.15
  per_tier_bonus: 0.05
  age_penalty: 0.1
  age_horizon_months: 60.0       # > 0

# Per-domain overrides. Any field left unset falls through to the
# globals. Unknown domain keys are rejected at load time.
domains:
  physics:
    min_supports_for_verified: 1   # allow a single TIER_1 source
  math:
    min_supports_for_verified: 1
    confidence:
      base: 0.7
      per_source: 0.1
      per_tier_bonus: 0.05
      age_penalty: 0.05
      age_horizon_months: 120.0
```

## Common tweaks

- **Loosen for a single high-trust source**: `min_supports_for_verified: 1`
  under a specific domain.
- **Tighten for safety-critical domains**: `min_supports_for_verified: 3`
  + higher `per_source` so confidence climbs only with more corroboration.
- **Emphasize tier weight**: raise `per_tier_bonus` (e.g. 0.1) to push
  TIER_1-backed envelopes above TIER_3-backed ones.
- **Treat old sources as still fresh**: raise `age_horizon_months`
  (e.g. 180) for domains where ground truth rarely shifts.

## v2 primitives (W39)

Three levers cover the failure modes the confidence formula alone
cannot catch: stale-but-numerous sources, archived echo-chambers, and
single-tier monocultures.

```yaml
# Drop evidence older than this window BEFORE counting supports/refutes.
# Use for fast-moving truth (security advisories, medical guidance).
max_evidence_age_days: 90        # int >= 1, default null (not enforced)

# Even if N historical sources support the claim, require ≥1 of them
# to be within this window. Guards against "everyone cited the same
# 2018 blog post."
require_recent_support_days: 14  # int >= 1, default null

# Supports must span ≥ N distinct TrustTiers (not just N DIDs). Stops
# ten tier-3 aggregators agreeing from counting as corroboration.
min_distinct_tiers_for_verified: 2   # int in [1, 3], default null
```

All three are also per-domain overridable. An unset field inherits
the global value; a global of `null` means "not enforced at all",
which is the v1-compatible default.

Example — tight rules for fast-moving domains, relaxed globals:

```yaml
max_evidence_age_days: 730         # 2-year global floor
domains:
  cs:
    max_evidence_age_days: 180     # 6-month cap for software claims
    require_recent_support_days: 30
  math:                            # theorems don't age — no cap
    max_evidence_age_days: null
```

### Migrating from v1

A v1 policy file is a valid v2 policy file — no changes required.
The three new fields all default to `null` (not enforced). Upgrade by
adding them one at a time and re-running your replay suite between
each change.

## How it flows through the engine

`decide(inputs, policy)` is a pure function. On request:
1. `server.py` loads the policy once at startup via
   `load_policy_from_env()`.
2. For each claim, the engine calls `policy.for_domain(claim.domain)`
   to produce a `ResolvedPolicy` (globals + overrides flattened).
3. Thresholds and the confidence formula read from the
   `ResolvedPolicy` — there is no path through the engine that can
   reach a hardcoded threshold.

This guarantees that the signed envelope's verdict + rationale are
traceable back to exactly one YAML document. Archive the policy
alongside your envelope audit log if you need to reproduce verdicts
later.
