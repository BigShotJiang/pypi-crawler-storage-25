# Security and threat model

gtv is designed so that a signed envelope is useful even if the verifier that produced it is later compromised. This page summarises the threat model, the invariants the system guarantees, and the incident-response workflow.

## What a signed envelope proves

For any envelope that `gtv-verify` accepts without `--allow-stub`:

1. The envelope is a verbatim, canonical-JSON-stable representation of what the signer signed. Any field mutation breaks the hash.
2. The signature was produced by the key bound to `issuer_did`. For Sigstore envelopes, the binding is the Fulcio-issued certificate. For BYOK envelopes, it is the `did:key` multicodec public key.
3. The signature is committed to the public Rekor transparency log. A verifier with only the envelope can independently confirm it was published at a specific point in the log.
4. The canonical hash was timestamped by at least one RFC 3161 TSA. Retroactive forgery of the `issued_at` time would require compromising the TSA private key.

## What a signed envelope does not prove

- That the underlying claim is true. Evidence adapters can be wrong or stale.
- That the issuer's trust tier was accurate at the time of issuance. Tier is a local operator policy.
- That the evidence sources cited were not themselves compromised upstream (e.g. a poisoned preprint).

## Threat model

### In scope

- **Signature forgery.** Mitigated by Sigstore keyless OIDC (Fulcio-issued short-lived certs) or BYOK Ed25519/P-256/secp256k1 with explicit key material.
- **Log tampering.** Mitigated by Rekor inclusion proofs. `gtv-verify` checks the proof against the log root.
- **Backdated envelopes.** Mitigated by dual RFC 3161 TSAs. Both must verify over the canonical hash.
- **Compromised verifier issuing new envelopes.** Mitigated by revocation lists (signed, published, and consumed at verification time) and by federation tier demotion.
- **Registry drift.** Mitigated by the Ed25519-signed, hash-chained audit log of admin-CLI actions.

### Out of scope (Phase 1)

- **Compromise of the evidence source APIs.** gtv records the fetched payload hash but does not currently cross-sign the upstream API's response.
- **Side-channel attacks on the host.** Running gtv on a shared, untrusted host is out of scope.
- **LLM prompt-injection inside the claim text.** gtv's classifier rejects opinion/creative content, but does not attempt to detect adversarial prompts crafted to bias the adapter fan-out.
- **Network-level denial of service.** Use a standard reverse proxy.

## Key management

- **Sigstore keyless:** No long-lived keys. Short-lived certificates are issued per signing event and logged to Rekor.
- **BYOK:** Operator-generated Ed25519, P-256, or secp256k1 keys. Public key lives in the DID document; private key is held by the operator.
- **Audit log signing:** Optional Ed25519 key loaded from `GTV_AUDIT_SIGNING_KEY`. Recommended for production.
- **Webhook signing:** Optional Ed25519 key loaded from `GTV_WEBHOOK_SIGNING_KEY`. Payloads are delivered as `{"payload": ..., "signature": "byok-ed25519:...", "issuer_did": "did:key:z..."}`.

Rotate keys by:

1. Issuing new envelopes under the new key.
2. Publishing a signed revocation list entry for the old key's affected envelope scope if necessary.
3. Retaining the old public key in DID history so historical envelopes remain verifiable.

## Revocation

`gtv-revoke` produces signed revocation records that `gtv-verify` consumes offline:

```bash
gtv-revoke create --issuer-did did:web:issuer --key ed25519.pem --envelope-id <id> --out revocation.json
gtv-revoke verify revocation.json
gtv-revoke check envelope.json revocation.json
```

A revocation list is itself a canonical, signed object. Verifiers that honour a revocation must themselves have trusted the issuing DID.

## Detecting Rekor log forks

Inclusion proofs (checked by `gtv-verify`) prove a specific envelope is in the Rekor log at a given checkpoint. A *consistency* proof goes further: it proves the log wasn't forked or rewritten between two checkpoints. If a log operator silently rebuilt the tree to drop an envelope, any verifier holding a prior checkpoint would detect it on the next consistency check.

Operators should pin Rekor checkpoints periodically and verify consistency against the current state:

```bash
# Pin today's Rekor head.
gtv-rekor-check pin --url https://rekor.sigstore.dev --out pinned-$(date +%F).json

# At any later point, prove the log still extends that pin.
gtv-rekor-check verify --pinned pinned-2026-04-21.json --url https://rekor.sigstore.dev
```

Typical recommended cadence: pin daily, verify daily. Store the pinned JSON under version control alongside the audit log. A failing consistency check is an integrity incident — treat every envelope anchored between the two checkpoints as suspect and trigger the incident-response workflow below.

For air-gapped or staged environments, use `gtv-rekor-check verify-offline` with pre-fetched checkpoint and proof files.

## Audit log

`gtv-audit` is an append-only, hash-chained, optionally Ed25519-signed log of every administrative action: API-key create/revoke, federation add/update-tier/revoke, manual admin interventions. Each record carries `prev_hash` and `record_hash`; `gtv-audit verify` walks the chain and exits non-zero on any break.

## Incident response

1. **Detection.** A compromised key, a failed `gtv-audit verify`, or a peer tier-1 issuing suspect verdicts.
2. **Containment.** Rotate API keys (`gtv-admin-keys revoke`), revoke peer DIDs (`gtv-federation revoke`), and issue a revocation list covering the suspect envelope set.
3. **Disclosure.** Publish the revocation list to the same surface peers poll. Notify direct consumers.
4. **Post-incident.** Export the audit log (`gtv-audit export`) and walk the chain. The log is append-only; any break is itself evidence.

Report a vulnerability: **security@groundtruth.example** (GPG key on the release page). Please do not open public issues for live vulnerabilities.
