# Federation

gtv is designed so multiple independent verifiers can sign the same claim and have their verdicts composed into a single tier-weighted consensus. This page explains the trust registry, tier model, and operator workflow.

## Trust registry

Each operator maintains a local trust registry: a SQLite database of issuer DIDs, their tier, and metadata. The registry is managed by the `gtv-federation` CLI and selected by `GTV_FEDERATION_DB`.

A registry entry is:

| Field | Purpose |
|---|---|
| `issuer_did` | DID of the peer verifier (e.g. `did:web:peer.example.com`). |
| `tier` | `TIER_1`, `TIER_2`, or `TIER_3`. |
| `name` | Human-readable label. |
| `added_at` | First-added timestamp. |
| `updated_at` | Last tier update. |
| `revoked` | Boolean. Revoked entries count as unknown for consensus weighting. |

## Tier weights

When `/consensus` aggregates envelopes, each envelope contributes its verdict with a weight derived from the voter's tier:

| Tier | Weight | Intended semantics |
|---|---|---|
| `TIER_1` | 3.0 | Operator-vetted, long-running, audited. |
| `TIER_2` | 2.0 | Known peer with a stable track record. |
| `TIER_3` | 1.0 | New or experimental peer. |
| unknown issuer | 0.1 | Not in the registry. Counted but cannot sway outcomes. |

A consensus verdict is the verdict whose summed weight exceeds `consensus_confidence ≥ 0.5 * total_weight`. Ties resolve to `INSUFFICIENT_EVIDENCE`.

## Registering peers

```bash
gtv-federation add did:web:peer.example.com --name "Peer" --tier TIER_1
gtv-federation update-tier did:web:peer.example.com --tier TIER_2
gtv-federation revoke did:web:peer.example.com
gtv-federation get did:web:peer.example.com
gtv-federation list --all
```

All mutations are recorded in the audit log (`gtv-audit`) when both CLIs point at the same database-backed keystore.

## Running consensus

Two endpoints, depending on whether the caller has already collected the envelopes:

### `POST /consensus` — caller-assembled envelopes

```bash
curl -X POST http://localhost:8080/consensus \
  -H 'content-type: application/json' \
  -d '{"envelopes": [<envelope_1>, <envelope_2>, <envelope_3>]}'
```

Use this when you already have signed envelopes from multiple verifiers (e.g., you fanned out yourself or stored them from a prior batch).

### `POST /federation/consensus` — server-driven fan-out

```bash
curl -X POST http://localhost:8080/federation/consensus \
  -H 'content-type: application/json' \
  -d '{"claim": "Pi starts with 3.14.", "domain": "math"}'
```

The server queries every peer in `GTV_FEDERATION_PEERS`, optionally includes its own local verdict (`include_local`, default true), and returns the tier-weighted aggregate in one round-trip. Peer failures are non-fatal — the response lists surviving `contributing_dids` and failed ones in `failed_dids` so operators can alert on partial outages.

`GTV_FEDERATION_PEERS` format: `<did>|<url>|<api_key>` per entry, comma-separated. Example:

```
did:web:bob.example|https://bob.example:8080|bob-api-key,did:web:carol.example|https://carol.example:8080|carol-api-key
```

The reference two-instance deployment (`deploy/federation/`) demonstrates this end-to-end; see `deploy/federation/README.md`.

### Response shape (either endpoint)

- `verdict` — the aggregate verdict.
- `confidence` — aggregate confidence (weighted mean of contributing envelopes).
- `aggregate.aggregate_canonical_hash` — RFC 8785-canonicalized hash over the aggregate, stable across implementations.
- `aggregate.input_refs` — per-envelope contribution with the weight that was applied.
- `/federation/consensus` additionally returns `contributing_dids` and `failed_dids`.

## Operator workflow

1. Provision the federation DB on first boot: `gtv-federation add ... --tier TIER_1` for every peer you already trust.
2. Rotate trust deliberately. Demote before you revoke. Consensus tolerates one TIER_1 going quiet far better than a silent registry mutation.
3. Surface `/consensus` calls in the audit log so tier drift is auditable after the fact.
4. Version the registry. Back it up with the same cadence as the API-key DB — they share the same operational risk profile.

## Phase 2 direction

Phase 1 federation is local-trust: each operator independently decides who counts. Phase 2 adds signed, versioned registry updates exchanged between peers so trust mutations can themselves be anchored and audited.
