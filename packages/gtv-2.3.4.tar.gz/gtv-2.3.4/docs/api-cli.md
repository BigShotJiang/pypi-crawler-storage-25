# CLI reference

Nine CLIs ship with v0.1.0. All are installed as console scripts by `pip install gtv`.

| Command | Purpose |
|---|---|
| `gtv-verify` | Offline envelope verifier. Zero external services. Exit code encodes the failure class. |
| `gtv-mcp` | Launch the MCP JSON-RPC stdio transport. |
| `gtv-demo` | One-shot claim → envelope → pretty-print, using stubbed signing. |
| `gtv-sign-byok` | Sign a canonical envelope with a BYOK Ed25519 / P-256 / secp256k1 key. |
| `gtv-subscribe` | Manage webhook subscriptions (SQLite-backed). |
| `gtv-admin-keys` | Create, list, revoke API keys in the DB-backed keystore. |
| `gtv-revoke` | Build, sign, verify, and check revocation lists. |
| `gtv-federation` | Manage the persistent federation trust registry. |
| `gtv-audit` | Tail, verify, export the append-only signed audit log. |

## gtv-verify

```bash
gtv-verify envelope.json           # full verification
gtv-verify --allow-unrooted env.json  # skip Rekor root trust (staging)
gtv-verify --trust-issuer env.json    # skip DID resolution
gtv-verify --allow-stub env.json      # accept stub signatures (dev only)
```

Exit codes: `0` verified, `2` stub detected, `3` signature mismatch, `4` Rekor proof mismatch, `5` schema error, `6` log-root untrusted, `7` issuer mismatch.

## gtv-admin-keys

```bash
gtv-admin-keys create --label "production" --scope verify,consensus
gtv-admin-keys list
gtv-admin-keys revoke <key_id>
```

`GTV_API_KEY_DB` selects the database file (default `~/.gtv/api_keys.db`).

## gtv-federation

```bash
gtv-federation add did:web:peer.example.com --name "Peer" --tier TIER_1
gtv-federation update-tier did:web:peer.example.com --tier TIER_2
gtv-federation revoke did:web:peer.example.com
gtv-federation get did:web:peer.example.com
gtv-federation list --all
```

`GTV_FEDERATION_DB` selects the database file.

## gtv-audit

```bash
gtv-audit tail --limit 20
gtv-audit verify                # walks the hash chain; exit 1 on break
gtv-audit get 42                # one record by seq
gtv-audit export --out audit.jsonl
gtv-audit append --actor admin --action apikey.create --target kid-abc --details '{"label":"pilot"}'
```

## gtv-revoke

```bash
gtv-revoke create --issuer-did did:web:issuer --key ed25519.pem --envelope-id <id> --out revocation.json
gtv-revoke verify revocation.json
gtv-revoke check envelope.json revocation.json
```
