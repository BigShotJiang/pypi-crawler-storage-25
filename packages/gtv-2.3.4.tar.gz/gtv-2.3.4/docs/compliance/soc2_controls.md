# SOC2 Trust Services Criteria Controls Mapping

This document maps each SOC2 Trust Services Criteria control claimed by the gtv project to concrete implementations in code, configuration, or operational processes.

## Common Criteria (CC)

### CC1 — Control Environment

| Control ID | Criterion | Implementation | Evidence | Owner |
|---|---|---|---|---|
| CC1.1 | Board oversight of effectiveness of controls | `docs/security.md`, `SECURITY.md`, `CODEOWNERS` | Security policy includes vulnerability reporting SLA and disclosure procedures; CODEOWNERS enforces required security team review on sensitive changes | gtv-maintainers |
| CC1.2 | Management establishes structures, reporting lines, authority | `CODEOWNERS`, `src/gtv/auth/oidc.py` | CODEOWNERS file defines approval authority; OIDC SSO enables enterprise identity hierarchy | gtv-maintainers |

### CC2 — Communication & Responsibility

| Control ID | Criterion | Implementation | Evidence | Owner |
|---|---|---|---|---|
| CC2.1 | Internal and external communication of responsibilities | `CONTRIBUTING.md`, `.pre-commit-config.yaml` | CONTRIBUTING.md documents development practices; pre-commit hooks enforce local scanning | gtv-maintainers |
| CC2.2 | Responsibility for achieving objectives | `CHANGELOG.md`, `.github/workflows/ci.yml` | CHANGELOG documents releases and changes; CI enforces all security gates before merge | gtv-maintainers |
| CC2.3 | Communication of authority and responsibility | `CODEOWNERS`, `src/gtv/mcp/auth.py` | CODEOWNERS assigns code ownership; auth.py enforces MCP-level authentication | gtv-maintainers |

### CC3 — Risk Assessment

| Control ID | Criterion | Implementation | Evidence | Owner |
|---|---|---|---|---|
| CC3.1 | Risk assessment at least annually | TODO | Scheduled risk assessment process to be documented | gtv-maintainers |
| CC3.2 | Risks prioritized and address major risks | `SECURITY.md` | Security policy defines scope (in/out of scope risks), disclosure SLA, and remediation process | gtv-maintainers |

### CC4 — Monitoring & Evaluation

| Control ID | Criterion | Implementation | Evidence | Owner |
|---|---|---|---|---|
| CC4.1 | Selective use of indicators to monitor effectiveness | `src/gtv/telemetry/metrics.py`, `src/gtv/telemetry/logs.py`, `deploy/observability/` | OpenTelemetry integration exports metrics and structured logs; Prometheus endpoints provide system monitoring; Grafana dashboards track SLOs | gtv-maintainers |
| CC4.2 | Monitoring of system transactions and events | `src/gtv/telemetry/middleware.py`, `src/gtv/obs/tracing.py`, `src/gtv/audit/store.py` | OpenTelemetry captures HTTP and async operation traces; audit store logs all verification events | gtv-maintainers |

### CC5 — Control Activities

| Control ID | Criterion | Implementation | Evidence | Owner |
|---|---|---|---|---|
| CC5.1 | Control activities designed and implemented to address identified risks | `src/gtv/verdict/engine.py`, `src/gtv/anchor/`, `src/gtv/revocation/` | Verdict engine implements deterministic rules; signing uses Sigstore keyless (no long-lived keys); revocation checks implemented | gtv-maintainers |
| CC5.2 | Controls over system configuration, change, and operations | `.github/workflows/ci.yml`, `SECURITY.md`, `CHANGELOG.md` | CI enforces security gates on every PR; SECURITY.md documents change management policy; releases tracked in CHANGELOG | gtv-maintainers |
| CC5.3 | Control activities on sensitive transactions | `src/gtv/audit/store.py`, `src/gtv/sign/byok.py`, `src/gtv/anchor/sign.py` | Audit logging on all claims and verdicts; signing requires explicit envelope and cryptographic commitment | gtv-maintainers |

### CC6 — Logical & Physical Access Controls

| Control ID | Criterion | Implementation | Evidence | Owner |
|---|---|---|---|---|
| CC6.1 | Logical access — user ID and authentication | `src/gtv/auth/oidc.py`, `src/gtv/mcp/auth.py` | OIDC SSO integration supports enterprise IdP (Okta, Auth0, Azure AD); JWT bearer token validation with JWKS caching | gtv-maintainers |
| CC6.2 | Prior to issuing new user IDs, identity is confirmed | `src/gtv/auth/oidc.py` | OIDC principal extraction validates subject (sub) claim, email, and tenant_id from upstream IdP | gtv-maintainers |
| CC6.3 | Authentication policies require appropriate complexity and change frequency | `src/gtv/auth/keystore.py` | Keystore module manages key lifecycle; OIDC defers password policy to upstream provider | gtv-maintainers |
| CC6.4 | Access rights are granted, modified, removed based on role | `src/gtv/auth/oidc.py`, `CODEOWNERS` | OIDC principal includes scope claims for role-based access; CODEOWNERS enforces code-level RBAC | gtv-maintainers |
| CC6.5 | Invalid access attempts are logged and monitored | `src/gtv/telemetry/logs.py`, `src/gtv/mcp/auth.py` | Authentication failures are logged via structlog; audit store captures access events | gtv-maintainers |
| CC6.6 | Physical access to facilities is restricted | TODO | Physical security controlled by cloud provider or facilities team | gtv-maintainers |
| CC6.7 | Physical access to equipment is restricted | TODO | Physical security controlled by cloud provider | gtv-maintainers |
| CC6.8 | Network access is managed | `Dockerfile`, `deploy/`, `.github/workflows/ci.yml` | Docker image runs minimal attack surface; deploy configs define network policies; CI verifies container scan passes | gtv-maintainers |

### CC7 — System Operations & Incident Management

| Control ID | Criterion | Implementation | Evidence | Owner |
|---|---|---|---|---|
| CC7.1 | Operations personnel are identified and responsibilities assigned | `CODEOWNERS`, `SECURITY.md` | CODEOWNERS identifies on-call reviewers; SECURITY.md documents incident response SLA (48 hours acknowledgement, 4 hours for CVE fixes) | gtv-maintainers |
| CC7.2 | Responsibilities and procedures for incident response are documented | `SECURITY.md` | Security policy specifies scope, reproduction steps required, and post-mortem commitment for production incidents | gtv-maintainers |
| CC7.3 | Incident response procedures are periodically tested | TODO | Incident simulation exercises to be scheduled | gtv-maintainers |
| CC7.4 | Backup data consistent with objectives | TODO | Backup and restore procedure documented in disaster recovery runbook (reference `docs/runbooks/disaster_recovery.md`) | gtv-maintainers |
| CC7.5 | Protection against unauthorized or malicious removal or corruption of data | `src/gtv/audit/store.py`, `src/gtv/anchor/rekor.py` | Audit log is append-only (database constraint); Rekor provides immutable ledger integration | gtv-maintainers |

### CC8 — Change Management

| Control ID | Criterion | Implementation | Evidence | Owner |
|---|---|---|---|---|
| CC8.1 | Changes are authorized, approved, and implemented | `.github/workflows/ci.yml`, `SECURITY.md`, `CHANGELOG.md` | GitHub PR workflow requires approval from CODEOWNERS; SECURITY.md specifies review requirements for sensitive modules; CHANGELOG documents all releases | gtv-maintainers |
| CC8.2 | Change impact is assessed for security and quality | `.github/workflows/ci.yml`, `SECURITY.md` | CI gates all PRs on: pip-audit, gitleaks, trivy fs, trivy image, ruff (SAST), mypy --strict; security team reviews signing, auth, revocation, audit, Dockerfile changes | gtv-maintainers |
| CC8.3 | Configuration management tracks authorized vs. actual | `pyproject.toml`, `.github/workflows/release.yml`, `deploy/` | pyproject.toml locks dependency versions; release workflow produces reproducible Docker digest; deployment configs version-controlled | gtv-maintainers |
| CC8.4 | Changes are documented | `CHANGELOG.md`, `.github/workflows/release.yml` | CHANGELOG documents every release with features/fixes/security notes; release notes include reproducible build info (SBOM, digest) | gtv-maintainers |

### CC9 — Risk Mitigation & Vendor Management

| Control ID | Criterion | Implementation | Evidence | Owner |
|---|---|---|---|---|
| CC9.1 | Risks from potential business disruptions are identified and addressed | `SECURITY.md`, TODO | SECURITY.md specifies disclosure SLA; disaster recovery runbook and business continuity plan to be documented | gtv-maintainers |
| CC9.2 | Service provider risk is assessed and managed | `pyproject.toml`, `SECURITY.md`, `.github/workflows/security.yml` | Dependencies scanned weekly for CVEs via pip-audit; secret scanning via gitleaks; trivy scans for known vulnerabilities; dependabot for security advisories | gtv-maintainers |

## Availability (A)

### A1 — Availability & Performance

| Control ID | Criterion | Implementation | Evidence | Owner |
|---|---|---|---|---|
| A1.1 | System capacity is monitored to support processing objectives | `src/gtv/obs/metrics.py`, `deploy/observability/`, `docs/slos.md` | Prometheus metrics on verdict latency, adapter throughput, cache hit ratio; Grafana dashboards with capacity thresholds; SLO targets documented | gtv-maintainers |
| A1.2 | Availability objectives are achieved through recovery procedures | TODO | Disaster recovery and business continuity procedures to be documented in `docs/runbooks/disaster_recovery.md` | gtv-maintainers |
| A1.3 | Environmental and operational factors affecting system availability are managed | `Dockerfile`, `docker-compose.yml`, `deploy/`, `SECURITY.md` | Docker image includes health checks; docker-compose defines resource limits; deploy configs specify redundancy; security scanning prevents vulnerable OS packages | gtv-maintainers |

## Confidentiality (C)

### C1 — Confidentiality

| Control ID | Criterion | Implementation | Evidence | Owner |
|---|---|---|---|---|
| C1.1 | Confidentiality of sensitive information is protected | `src/gtv/redact/redactor.py`, `src/gtv/auth/oidc.py` | PII redaction module masks sensitive user data; OIDC stores tokens in memory only (not persisted); audit log excludes PII | gtv-maintainers |
| C1.2 | Information systems are protected against unauthorized disclosure | `src/gtv/mcp/auth.py`, `Dockerfile`, `SECURITY.md` | MCP server enforces authentication before tool execution; minimal Docker image reduces attack surface; HTTPS enforced in FastAPI config | gtv-maintainers |

## Processing Integrity (PI)

### PI1 — Processing Integrity

| Control ID | Criterion | Implementation | Evidence | Owner |
|---|---|---|---|---|
| PI1.1 | Objectives of system processing are defined to enable achievement of organizational objectives | `src/gtv/verdict/engine.py`, `docs/policy.md` | Verdict engine implements deterministic, rule-based decisions; consensus policy DSL allows configuration of decision criteria; policy schema validates allowed rules | gtv-maintainers |
| PI1.4 | Completeness and accuracy of inputs is ensured | `src/gtv/adapters/conformance.py`, `src/gtv/verdict/engine.py`, `tests/` | Adapter conformance suite validates source adapter outputs; verdict engine performs deterministic classification; comprehensive test suite (unit + integration + adversarial) validates correctness | gtv-maintainers |
| PI1.5 | Processing outputs are complete, accurate, and authorize | `src/gtv/verdict/engine.py`, `src/gtv/anchor/sign.py`, `src/gtv/anchor/tsa.py` | Verdicts are cryptographically signed (Sigstore keyless); timestamps from RFC 3161 dual-TSA (Digicert + GlobalSign) provide non-repudiation; signed verdicts cached for audit trail | gtv-maintainers |

---

## Notes

- **TODO rows** indicate controls not yet fully documented or operationalized. These are tracked for future SOC2 audit preparation.
- **Owner** is always `gtv-maintainers` as defined in CODEOWNERS.
- **Evidence** columns point to testable artifacts: test files can be executed to verify implementation; file paths can be inspected in the repository; environment variables and CLI flags are documented in `README.md` or help text.
- For **Physical security** (CC6.6, CC6.7), gtv assumes deployment on cloud infrastructure or co-located facilities with separately audited SOC2 compliance (AWS, GCP, Azure).
- **Disaster recovery** (A1.2, CC9.1) and **incident simulation** (CC7.3) are referenced to a companion runbook at `docs/runbooks/disaster_recovery.md` (managed by separate work stream).
