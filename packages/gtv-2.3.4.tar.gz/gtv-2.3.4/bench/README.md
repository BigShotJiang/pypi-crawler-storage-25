# Benchmark corpus

Ships by Milestone 3 (Week 9).

- 1,000 physics claims.
- Labels: VERIFIED / UNVERIFIED / CONTESTED / OPINION.
- Stratified across mechanics, E&M, quantum, thermo, astro, particle,
  condensed matter.
- License: CC-BY-4.0 for the labels; source excerpts carry their upstream
  license.

Layout (TBD Week 9):

```
bench/
  claims.jsonl        — one record per line: {id, text, domain, label, notes}
  splits/
    train.txt         — claim ids (70%)
    val.txt           — claim ids (15%)
    test.txt          — claim ids (15%)
  sources.csv         — upstream citations per claim
  labels.md           — labeler guide
```
