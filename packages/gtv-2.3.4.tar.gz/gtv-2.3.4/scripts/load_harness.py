#!/usr/bin/env python3
"""Async load harness for the gtv MCP HTTP surface.

Usage:
    python scripts/load_harness.py --url http://localhost:8080 --concurrency 20 --duration 30

Fires sustained load at /tools/verify_claim for a fixed duration with a
configurable concurrency level, and reports throughput, error counts, and
p50/p95/p99 response latency.

This is a pragmatic, dependency-light alternative to locust / k6 — it uses
only httpx + stdlib. Good enough to catch regressions on the stub path and
to validate SLOs in staging. For multi-machine / distributed load, switch
to a dedicated tool.

Exit code is 0 on success, 1 if error rate exceeds the configured threshold.
"""
from __future__ import annotations

import argparse
import asyncio
import statistics
import sys
import time
from collections.abc import Iterable
from dataclasses import dataclass, field

import httpx

DEFAULT_CLAIM = {
    "claim": "The speed of light in vacuum is 299,792,458 m/s.",
    "domain": "physics",
    "max_sources": 3,
}


@dataclass
class Result:
    latencies: list[float] = field(default_factory=list)
    ok: int = 0
    errors: int = 0
    status_counts: dict[int, int] = field(default_factory=dict)

    def record(self, status: int, latency: float) -> None:
        self.latencies.append(latency)
        self.status_counts[status] = self.status_counts.get(status, 0) + 1
        if 200 <= status < 300:
            self.ok += 1
        else:
            self.errors += 1


async def _worker(
    client: httpx.AsyncClient,
    url: str,
    headers: dict[str, str],
    deadline: float,
    result: Result,
) -> None:
    body = DEFAULT_CLAIM
    while time.perf_counter() < deadline:
        t0 = time.perf_counter()
        try:
            resp = await client.post(f"{url}/tools/verify_claim", json=body, headers=headers)
            result.record(resp.status_code, time.perf_counter() - t0)
        except Exception:
            result.record(-1, time.perf_counter() - t0)


def _pct(sorted_samples: list[float], q: float) -> float:
    if not sorted_samples:
        return 0.0
    idx = min(len(sorted_samples) - 1, int(q * len(sorted_samples)))
    return sorted_samples[idx]


def _report(result: Result, elapsed: float) -> None:
    total = result.ok + result.errors
    throughput = total / elapsed if elapsed > 0 else 0.0
    sorted_lat = sorted(result.latencies)

    print()
    print(f"Total requests : {total}")
    print(f"Duration       : {elapsed:.2f}s")
    print(f"Throughput     : {throughput:,.1f} req/s")
    print(f"Successful     : {result.ok}")
    print(f"Errors         : {result.errors}")
    if sorted_lat:
        print(
            f"Latency (ms)   : "
            f"p50={_pct(sorted_lat, 0.50) * 1000:.2f}  "
            f"p95={_pct(sorted_lat, 0.95) * 1000:.2f}  "
            f"p99={_pct(sorted_lat, 0.99) * 1000:.2f}  "
            f"mean={statistics.fmean(sorted_lat) * 1000:.2f}"
        )
    if result.status_counts:
        breakdown = ", ".join(
            f"{code}={n}" for code, n in sorted(result.status_counts.items())
        )
        print(f"Status codes   : {breakdown}")


async def run(
    *,
    url: str,
    concurrency: int,
    duration: float,
    api_key: str | None,
    timeout: float,
) -> Result:
    headers = {"Authorization": f"Bearer {api_key}"} if api_key else {}
    result = Result()
    async with httpx.AsyncClient(timeout=timeout) as client:
        deadline = time.perf_counter() + duration
        workers: Iterable[asyncio.Task[None]] = [
            asyncio.create_task(_worker(client, url, headers, deadline, result))
            for _ in range(concurrency)
        ]
        await asyncio.gather(*workers, return_exceptions=True)
    return result


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description="gtv load harness")
    p.add_argument("--url", default="http://localhost:8080", help="Base URL of the gtv server")
    p.add_argument("--concurrency", type=int, default=10, help="Number of concurrent workers")
    p.add_argument("--duration", type=float, default=30.0, help="Run duration in seconds")
    p.add_argument("--api-key", default=None, help="API key for Bearer auth (optional)")
    p.add_argument("--timeout", type=float, default=10.0, help="Per-request timeout (seconds)")
    p.add_argument(
        "--max-error-rate",
        type=float,
        default=0.01,
        help="Exit non-zero if error rate exceeds this fraction (default: 0.01 = 1%%)",
    )
    args = p.parse_args(argv)

    print(
        f"Target={args.url}  concurrency={args.concurrency}  duration={args.duration}s"
    )
    start = time.perf_counter()
    result = asyncio.run(
        run(
            url=args.url,
            concurrency=args.concurrency,
            duration=args.duration,
            api_key=args.api_key,
            timeout=args.timeout,
        )
    )
    elapsed = time.perf_counter() - start
    _report(result, elapsed)

    total = result.ok + result.errors
    if total == 0:
        print("FAIL: no requests completed", file=sys.stderr)
        return 1
    err_rate = result.errors / total
    if err_rate > args.max_error_rate:
        print(
            f"FAIL: error rate {err_rate:.2%} exceeds threshold "
            f"{args.max_error_rate:.2%}",
            file=sys.stderr,
        )
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
