#!/usr/bin/env python3
"""
Generate a signed release manifest for a given version.

Usage:
    python scripts/release_manifest.py <version>

Outputs:
    release/manifest-<version>.json

The manifest contains:
    - version
    - released_at (UTC ISO 8601)
    - python_package (name, version from pyproject.toml)
    - files_included (list of .py files with sha256 hashes)
    - tests_passing (count from pytest output)
    - changelog_section (raw text of the version section)
"""

import hashlib
import json
import re
import subprocess
import sys
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

# Project root
ROOT = Path(__file__).parent.parent
SRC = ROOT / "src"
CHANGELOG = ROOT / "CHANGELOG.md"
PYPROJECT = ROOT / "pyproject.toml"
RELEASE_DIR = ROOT / "release"


def sha256_file(path: Path) -> str:
    """Compute SHA256 hash of a file."""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while chunk := f.read(8192):
            h.update(chunk)
    return h.hexdigest()


def get_python_version() -> tuple[str, str]:
    """Extract package name and version from pyproject.toml."""
    with open(PYPROJECT) as f:
        content = f.read()

    # Simple regex extraction
    name_match = re.search(r'name\s*=\s*["\']([^"\']+)["\']', content)
    version_match = re.search(r'version\s*=\s*["\']([^"\']+)["\']', content)

    if not name_match or not version_match:
        raise ValueError("Could not extract name/version from pyproject.toml")

    return name_match.group(1), version_match.group(1)


def list_python_files() -> list[Path]:
    """List all .py files under src/."""
    return sorted(SRC.rglob("*.py"))


def get_changelog_section(version: str) -> str:
    """Extract the section for a given version from CHANGELOG.md."""
    with open(CHANGELOG) as f:
        content = f.read()

    # Find ## [version] section
    pattern = rf"## \[{re.escape(version)}\].*?(?=## \[|$)"
    match = re.search(pattern, content, re.DOTALL)

    if not match:
        return ""

    section = match.group(0).strip()
    return section


def count_passing_tests() -> int:
    """Run pytest and extract the passing test count."""
    try:
        result = subprocess.run(
            [
                str(ROOT / ".venv" / "bin" / "python"),
                "-m",
                "pytest",
                "tests/",
                "--ignore=tests/notebooks",
                "--ignore=tests/test_notebook.py",
                "-q"
            ],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=300
        )

        # Parse the last line for "X passed"
        output = result.stdout + result.stderr
        for line in output.strip().split('\n')[-5:]:
            match = re.search(r'(\d+)\s+passed', line)
            if match:
                return int(match.group(1))

        return 0
    except Exception as e:  # noqa: BLE001, RUF100
        import sys as _sys
        _sys.stderr.write(f"Warning: Could not run pytest: {e}\n")
        return 0


def generate_manifest(version: str) -> dict[str, Any]:
    """Generate a release manifest."""

    # Verify version exists in CHANGELOG
    changelog_section = get_changelog_section(version)
    if not changelog_section:
        sys.stderr.write(f"ERROR: Version {version} not found in CHANGELOG.md\n")
        sys.exit(2)

    # Get package info
    pkg_name, pkg_version = get_python_version()

    # List and hash all .py files
    py_files = list_python_files()
    files_included = [
        {
            "path": str(f.relative_to(ROOT)),
            "sha256": sha256_file(f)
        }
        for f in py_files
    ]

    # Run tests
    tests_passing = count_passing_tests()

    # Build manifest
    manifest = {
        "version": version,
        "released_at": datetime.now(UTC).isoformat(),
        "python_package": {
            "name": pkg_name,
            "version": pkg_version
        },
        "files_included": files_included,
        "tests_passing": tests_passing,
        "changelog_section": changelog_section
    }

    return manifest


def main() -> None:
    """Generate and write a release manifest."""
    if len(sys.argv) < 2:
        sys.stderr.write("Usage: python scripts/release_manifest.py <version>\n")
        sys.exit(1)

    version = sys.argv[1]

    # Create release directory if it doesn't exist
    RELEASE_DIR.mkdir(parents=True, exist_ok=True)

    # Generate manifest
    manifest = generate_manifest(version)

    # Write manifest
    output_path = RELEASE_DIR / f"manifest-{version}.json"
    with open(output_path, "w") as f:
        json.dump(manifest, f, indent=2)

    sys.stdout.write(f"Manifest written to {output_path}\n")
    sys.stdout.write(f"Version: {version}\n")
    sys.stdout.write(f"Files included: {len(manifest['files_included'])}\n")
    sys.stdout.write(f"Tests passing: {manifest['tests_passing']}\n")


if __name__ == "__main__":
    main()
