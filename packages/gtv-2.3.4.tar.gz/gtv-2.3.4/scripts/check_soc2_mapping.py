#!/usr/bin/env python3
"""SOC2 controls mapping validator.

Parses docs/compliance/soc2_controls.md and verifies that all Implementation
cells reference actual files/paths in the repository.

Exits 0 if all mappings are valid, 1 if any referenced files are missing.
"""

import re
import sys
from pathlib import Path


def parse_markdown_table(md_path: Path) -> list[dict[str, str]]:
    """Parse markdown table rows from a file.

    Returns a list of dicts with keys: Control ID, Criterion, Implementation,
    Evidence, Owner.
    """
    with open(md_path) as f:
        content = f.read()

    rows = []
    lines = content.split("\n")

    in_table = False

    for line in lines:
        # Detect table header separator (|---|---|...|)
        if "---|---" in line:
            in_table = True
            continue

        # Skip non-table lines
        if not line.strip().startswith("|"):
            in_table = False
            continue

        # Process table data rows (skip header row which is right before separator)
        if in_table:
            cells = [c.strip() for c in line.split("|")[1:-1]]
            if len(cells) >= 5 and cells[0]:  # non-empty first col
                # Skip header row (contains "Control ID" or similar)
                if cells[0] == "Control ID":
                    continue
                rows.append({
                    "Control ID": cells[0],
                    "Criterion": cells[1],
                    "Implementation": cells[2],
                    "Evidence": cells[3],
                    "Owner": cells[4],
                })

    return rows


def extract_paths(impl_cell: str) -> list[str]:
    """Extract file paths from implementation cell.

    Handles inline code (backticks), comma-separated paths, references.
    """
    if "TODO" in impl_cell:
        return []

    # Extract backtick-quoted paths: `src/gtv/auth/oidc.py`
    paths = re.findall(r"`([^`]+)`", impl_cell)
    return [p for p in paths if p]


def validate_paths(repo_root: Path, rows: list[dict[str, str]]) -> tuple[int, int, list[str]]:
    """Check that all referenced paths exist.

    Returns (total_controls, todo_count, missing_paths).
    """
    missing = []
    todo_count = 0

    for row in rows:
        impl = row["Implementation"]

        # Skip TODO rows
        if "TODO" in impl:
            todo_count += 1
            continue

        paths = extract_paths(impl)
        for path in paths:
            full_path = repo_root / path
            if not full_path.exists():
                missing.append(f"  {row['Control ID']:6s}: {path}")

    return len(rows), todo_count, missing


def main():
    """Main entry point."""
    repo_root = Path(__file__).parent.parent
    doc_path = repo_root / "docs/compliance/soc2_controls.md"

    if not doc_path.exists():
        print(f"ERROR: {doc_path} not found", file=sys.stderr)  # noqa: T201
        sys.exit(1)

    rows = parse_markdown_table(doc_path)
    total, todo, missing = validate_paths(repo_root, rows)

    # Print summary
    implemented = total - todo
    print(f"{implemented} controls mapped, {todo} TODO, {len(missing)} missing-file errors")  # noqa: T201

    if missing:
        print("\nMissing files:", file=sys.stderr)  # noqa: T201
        for msg in missing:
            print(msg, file=sys.stderr)  # noqa: T201
        sys.exit(1)

    sys.exit(0)


if __name__ == "__main__":
    main()
