#!/usr/bin/env bash
# Local security gate — mirrors the security CI workflow so you can catch
# issues before pushing. Exits non-zero on any finding.
#
# Usage:
#   scripts/security_gate.sh           # run every check
#   scripts/security_gate.sh pip-audit # run just one check
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

run_pip_audit() {
    echo "==> pip-audit"
    python -m pip install --quiet pip-audit
    python -m pip_audit --strict --skip-editable --progress-spinner off
}

run_gitleaks() {
    echo "==> gitleaks"
    if ! command -v gitleaks >/dev/null 2>&1; then
        echo "   gitleaks not installed — install from https://github.com/gitleaks/gitleaks"
        return 1
    fi
    gitleaks detect --source . --redact --verbose --no-git
}

run_trivy_fs() {
    echo "==> trivy filesystem scan"
    if ! command -v trivy >/dev/null 2>&1; then
        echo "   trivy not installed — install from https://aquasecurity.github.io/trivy"
        return 1
    fi
    trivy fs --ignore-unfixed --severity HIGH,CRITICAL --exit-code 1 .
}

run_bandit() {
    echo "==> bandit (Python static analysis)"
    python -m pip install --quiet bandit
    python -m bandit -q -r src -x tests
}

run_cyclonedx() {
    echo "==> cyclonedx SBOM"
    python -m pip install --quiet cyclonedx-bom
    python -m cyclonedx_py environment --output-format JSON --outfile sbom.cyclonedx.json
    echo "   wrote sbom.cyclonedx.json"
}

case "${1:-all}" in
    pip-audit)  run_pip_audit ;;
    gitleaks)   run_gitleaks ;;
    trivy)      run_trivy_fs ;;
    bandit)     run_bandit ;;
    cyclonedx)  run_cyclonedx ;;
    all)
        run_pip_audit
        run_bandit
        # gitleaks and trivy optional locally — they require external binaries.
        if command -v gitleaks >/dev/null 2>&1; then run_gitleaks; fi
        if command -v trivy >/dev/null 2>&1; then run_trivy_fs; fi
        echo
        echo "Security gate: PASS"
        ;;
    *)
        echo "Unknown target: $1" >&2
        echo "Usage: $0 [pip-audit|gitleaks|trivy|bandit|cyclonedx|all]" >&2
        exit 2
        ;;
esac
