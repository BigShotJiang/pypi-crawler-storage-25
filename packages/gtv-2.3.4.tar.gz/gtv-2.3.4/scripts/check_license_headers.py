#!/usr/bin/env python
"""Check and fix SPDX license headers in source files.

This script ensures all .py files in src/gtv/ carry the required dual-license header:
  # SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial

Modes:
  --check (default): Exit 0 if all files have header, 1 otherwise
  --fix: Prepend header to files that lack it
"""

import sys
from pathlib import Path

REQUIRED_HEADER = "# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial"
SRC_DIR = Path(__file__).parent.parent / "src" / "gtv"


def get_all_py_files():
    """Return list of all .py files in src/gtv/, sorted."""
    files = sorted(SRC_DIR.rglob("*.py"))
    return files


def has_license_header(file_path):
    """Check if file has the required SPDX header in first ~10 lines."""
    try:
        with open(file_path, encoding="utf-8") as f:
            lines = f.readlines()[:10]
            for line in lines:
                if REQUIRED_HEADER in line:
                    return True
    except Exception:
        pass
    return False


def get_header_position(file_path):
    """
    Determine where to insert the header.

    Returns the line number after which to insert the header:
    - 0: insert at beginning
    - N: insert after line N (for shebang or coding declarations)
    """
    try:
        with open(file_path, encoding="utf-8") as f:
            lines = f.readlines()
    except Exception:
        return 0

    if not lines:
        return 0

    insert_after = 0

    # Check for shebang on line 0
    if lines[0].startswith("#!"):
        insert_after = 1

    # Check for coding declaration (may be on line 0 or 1)
    check_line = insert_after if insert_after < len(lines) else 0
    if check_line < len(lines) and ("coding:" in lines[check_line] or "encoding:" in lines[check_line]):
        insert_after = check_line + 1

    return insert_after


def add_header_to_file(file_path):
    """Add license header to file if missing. Preserve shebang and coding declarations."""
    if has_license_header(file_path):
        return False  # Already has header

    # Read for line-based processing
    try:
        with open(file_path, encoding="utf-8") as f:
            lines = f.readlines()
    except Exception as e:
        sys.stderr.write(f"Error reading {file_path}: {e}\n")
        return False

    insert_after = get_header_position(file_path)

    # Build new content
    new_lines = lines[:insert_after]
    new_lines.append(REQUIRED_HEADER + "\n")
    new_lines.extend(lines[insert_after:])

    # Write back
    try:
        with open(file_path, "w", encoding="utf-8") as f:
            f.writelines(new_lines)
        return True
    except Exception as e:
        sys.stderr.write(f"Error writing {file_path}: {e}\n")
        return False


def check_headers(fix=False):
    """
    Check all .py files for license headers.

    Args:
        fix: If True, add missing headers. If False, just report.

    Returns:
        int: 0 if all files have headers, 1 otherwise
    """
    files = get_all_py_files()

    if not files:
        sys.stderr.write(f"No .py files found in {SRC_DIR}\n")
        return 0

    missing = []
    fixed = []

    for file_path in files:
        if not has_license_header(file_path):
            # Skip empty files
            try:
                with open(file_path, encoding="utf-8") as f:
                    content = f.read().strip()
                    if not content:
                        continue
            except Exception:
                pass

            missing.append(file_path)

            if fix and add_header_to_file(file_path):
                fixed.append(file_path)

    if fix:
        if fixed:
            sys.stderr.write(f"Added license header to {len(fixed)} file(s):\n")
            for f in fixed:
                sys.stderr.write(f"  {f.relative_to(SRC_DIR.parent)}\n")
        return 0
    else:
        if missing:
            sys.stderr.write(f"Missing license headers in {len(missing)} file(s):\n")
            for f in missing:
                sys.stderr.write(f"  {f.relative_to(SRC_DIR.parent)}\n")
            return 1
        else:
            sys.stderr.write(f"All {len(files)} files have license headers.\n")
            return 0


def main():
    mode = "--fix" if "--fix" in sys.argv else "--check"
    exit_code = check_headers(fix=(mode == "--fix"))
    sys.exit(exit_code)


if __name__ == "__main__":
    main()
