# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Probe every registered adapter with a domain-appropriate claim.

Prints: adapter DID, #evidence, stance of first, URL or error.
Gives an honest hit-rate matrix — the demo path swallows adapter errors.
"""
from __future__ import annotations

import asyncio
import traceback

from gtv.adapters import REGISTRY
from gtv.models import Claim

# did → claim text tailored to that adapter's domain.
PROBE_BY_DID: dict[str, str] = {
    "did:web:arxiv.org": "attention is all you need transformer architecture",
    "did:web:inspirehep.net": "higgs boson discovery 125 gev",
    "did:web:crossref.org": "10.1038/nature14539",
    "did:web:api.openalex.org": "climate change carbon capture",
    "did:web:api.semanticscholar.org": "neural machine translation attention",
    "did:web:pubmed.ncbi.nlm.nih.gov": "paracetamol hepatotoxicity",
    "did:web:nist.gov": "speed of light",
    "did:web:retractionwatch.com": "retracted COVID-19 hydroxychloroquine",
    "did:web:dailymed.nlm.nih.gov": "acetaminophen",
    "did:web:github.com": "CVE-2021-44228 log4j",
    "did:web:open.fda.gov": "ibuprofen adverse events",
    "did:web:core.ac.uk": "open access repository",
    "did:web:europepmc.org": "SARS-CoV-2 spike protein",
    "did:web:who.int": "malaria mortality",
    "did:web:wikidata.org": "Albert Einstein",
    "did:web:ourworldindata.org": "CO2 emissions",
}


async def probe_one(did: str, adapter, claim_text: str) -> dict:
    claim = Claim(text=claim_text)
    row: dict = {"did": did}
    try:
        result = await asyncio.wait_for(adapter.query(claim, max_items=3), timeout=25.0)
        row["count"] = len(result)
        row["first_url"] = str(result[0].url) if result else None
        row["first_stance"] = result[0].stance.value if result else None
        row["error"] = None
    except Exception as e:
        row["count"] = 0
        row["first_url"] = None
        row["first_stance"] = None
        row["error"] = f"{type(e).__name__}: {str(e)[:180]}"
    finally:
        try:
            await adapter.close()
        except Exception:
            pass
    return row


async def main() -> int:
    print(f"Registered adapters: {len(REGISTRY)}")
    print()
    print(f"{'did':<38} {'count':>5}  {'stance':<10}  first_url_or_error")
    print("-" * 130)

    hits = 0
    errors = 0
    empty = 0
    for did, adapter in REGISTRY.items():
        claim_text = PROBE_BY_DID.get(did, "test query")
        row = await probe_one(did, adapter, claim_text)
        if row["error"]:
            errors += 1
            print(f"{did:<38} {0:>5}  {'ERR':<10}  {row['error']}")
        elif row["count"] == 0:
            empty += 1
            print(f"{did:<38} {0:>5}  {'-':<10}  (0 results)")
        else:
            hits += 1
            print(
                f"{did:<38} {row['count']:>5}  {row['first_stance']:<10}  {row['first_url']}"
            )

    print("-" * 130)
    print(f"Total: {len(REGISTRY)}   Hits: {hits}   Empty: {empty}   Errors: {errors}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(asyncio.run(main()))
    except Exception:
        traceback.print_exc()
        raise SystemExit(2)
