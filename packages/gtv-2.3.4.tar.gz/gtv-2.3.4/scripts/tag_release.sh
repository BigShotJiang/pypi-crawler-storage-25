#!/bin/bash
# Tag a release by version.
#
# Usage:
#     ./scripts/tag_release.sh <version>
#
# This script:
#     1. Runs release_manifest.py to generate/validate the manifest
#     2. Validates the manifest JSON
#     3. Prints (but does NOT execute) the git tag command
#
# The operator should review the output and manually run the git tag command.

set -e

if [ $# -ne 1 ]; then
    echo "Usage: $0 <version>" >&2
    exit 1
fi

VERSION="$1"
MANIFEST_FILE="release/manifest-${VERSION}.json"

# Change to project root
cd "$(dirname "$0")/.."

echo "[*] Generating manifest for version ${VERSION}..." >&2
.venv/bin/python scripts/release_manifest.py "${VERSION}"

# Validate manifest JSON
echo "[*] Validating manifest JSON..." >&2
if ! python3 -m json.tool "${MANIFEST_FILE}" > /dev/null 2>&1; then
    echo "[ERROR] Invalid JSON in ${MANIFEST_FILE}" >&2
    exit 1
fi

# Extract metadata from manifest
echo "[*] Manifest validated successfully." >&2

# Print the git tag command
cat <<EOF

# Git tag command (operator must run this manually):
git tag -a "v${VERSION}" -m "Release v${VERSION}" -s

# To push (operator must run this manually):
git push origin "v${VERSION}"

# Manifest location: ${MANIFEST_FILE}

EOF
