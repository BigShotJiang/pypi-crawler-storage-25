# Contributing

Apache 2.0. No CLA.

## Doctrine

1. Question every requirement before you code it.
2. Delete before you add.
3. Working code is the only measure of progress.
4. Report blockers within 24 hours; never silently work around.
5. Idiot index: solution complexity / problem complexity → minimise.

## Workflow

- Fork → branch → PR → one reviewer → CI green → merge.
- Every architectural change lands as an ADR in `docs/adr/NNNN-slug.md`.
- Every PR must pass `make ci`: ruff, mypy, pytest, schema validation.
- Schemas in `spec/schemas/` are frozen; changes require an ADR.

## Commit style

`<area>: <imperative>` — e.g. `adapters: add arxiv`, `anchor: implement rfc3161 fallback`.

## Security

Report vulnerabilities via `SECURITY.md` — do not open public issues.
