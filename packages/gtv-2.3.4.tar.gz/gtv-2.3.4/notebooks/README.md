# gtv tutorial notebooks

Runnable tutorials. Each notebook is self-contained and runs fully in-process
(no external Sigstore, no live TSA, no network calls) so it's safe to execute
in CI or offline.

| Notebook | What it covers |
|---|---|
| `getting_started.ipynb` | Register a stub adapter, post a claim to the in-process verifier, inspect the signed envelope, verify it offline with `gtv-verify`, and see the OpenAI / Anthropic / LangChain tool specs. |

## Run locally

```bash
pip install -e '.[dev]'
pip install jupyter
jupyter notebook notebooks/getting_started.ipynb
```

## Run headless (CI)

The tutorial notebook is executed end-to-end by `tests/test_notebook.py`,
which uses `nbclient` with a 60 s per-cell timeout. That test is the
guardrail that keeps the notebook from bitrotting as the API evolves.
