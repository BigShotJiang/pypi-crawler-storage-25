# Reference federation deployment

A minimal two-instance gtv federation. Use this to:

* Verify the `/federation/consensus` endpoint end-to-end against real
  containers — not just in-process mocks.
* Demo the federation story to a prospective pilot in under a minute.
* Serve as the baseline for a 3+ instance production deployment.

## Topology

```
client ──► alice  (localhost:18080)
              │
              └─► bob   (internal: http://bob:8080)

client ──► bob    (localhost:18081)
              │
              └─► alice (internal: http://alice:8080)
```

* **Alice** signs under `did:web:alice.local`.
* **Bob** signs under `did:web:bob.local`.
* Both load `trust-registry.json` so consensus knows to weight each
  other at TIER_1.
* Each points at the other via `GTV_FEDERATION_PEERS` (DID | URL | key).
* Sigstore / TSA anchoring is **disabled** in this reference — real
  deployments must flip those on.

## Run

```bash
cd deploy/federation
docker compose up -d --wait
```

Smoke the consensus endpoint:

```bash
curl -s http://localhost:18080/federation/consensus \
     -H 'content-type: application/json' \
     -d '{"claim": "Pi starts with 3.14.", "domain": "math"}' | jq .
```

Expected (field shown, values abridged):

```json
{
  "verdict": "VERIFIED",
  "confidence": 0.xx,
  "contributing_dids": ["did:web:alice.local", "did:web:bob.local"],
  "failed_dids": [],
  "aggregate": { ... }
}
```

## Teardown

```bash
docker compose down -v
```

## Production checklist

The defaults here are tuned for demos, not production:

1. **Turn on anchors.** Set `GTV_SIGSTORE_ENABLED=1` and
   `GTV_TSA_ENABLED=1` so envelopes carry real Rekor + RFC 3161 proofs.
2. **Publish each DID document.** `did:web:alice.example` must resolve
   to a real DID document clients can fetch; the reference uses
   `.local` names that only work inside the compose network.
3. **Use API keys between peers.** Replace the trailing `|` in
   `GTV_FEDERATION_PEERS` with a real Bearer token provisioned via
   `gtv-admin-keys create`.
4. **Rotate the registry via IaC.** Mount `trust-registry.json` from a
   config volume managed by your provisioning system; do not bake it
   into the image.
5. **Tune `peer_timeout_s`.** The default 10s is conservative; drop it
   once you know your p99 peer latency.
6. **Alert on `failed_dids`.** Any non-empty `failed_dids` array on
   the consensus response means a peer is unreachable or returning
   malformed envelopes — page on that.

## Automated smoke test

`tests/test_federation_e2e.py::test_federation_docker_compose_smoke`
runs this compose and asserts both DIDs appear in a consensus response.
It's gated behind `GTV_FEDERATION_E2E=1` so CI doesn't take the Docker
hit on every PR:

```bash
GTV_FEDERATION_E2E=1 pytest tests/test_federation_e2e.py::test_federation_docker_compose_smoke
```
