# Observability — reference Prometheus + Grafana stack

This folder is the operator-facing bundle for SLIs, SLOs, and
dashboards. A single `docker compose up` brings up Prometheus scraping
`gtv:8080/metrics`, loaded with our SLO recording and alerting rules,
and a Grafana pre-provisioned with the main dashboard.

## What's in the box

```
deploy/observability/
├── docker-compose.yml                  # reference stack
├── prometheus/
│   ├── prometheus.yml                  # scrape config, rule imports
│   ├── recording-rules.yml             # SLI definitions (gtv:*)
│   └── alerting-rules.yml              # SLO alert rules
└── grafana/
    ├── dashboards/gtv-overview.json    # the dashboard
    └── provisioning/
        ├── dashboards/dashboards.yml   # auto-load dashboards
        └── datasources/datasource.yml  # auto-wire Prometheus DS
```

See [`docs/slos.md`](../../docs/slos.md) for the SLO policy behind the
alert thresholds.

## Running it

From this directory:

```bash
docker compose up -d
```

Then point a `gtv` server at the compose network so Prometheus can
reach it:

```bash
docker run --rm -p 8080:8080 \
  --network observability_default \
  --name gtv \
  ghcr.io/your-org/gtv:latest
```

- Prometheus UI: <http://localhost:9090>
- Grafana UI: <http://localhost:3000> (admin/admin — rotate on first login)

The dashboard is auto-provisioned; look for **gtv → gtv — overview**
in the left-hand nav.

## Importing the dashboard into an existing Grafana

If you already operate Grafana and just want the dashboard:

1. Dashboards → New → Import.
2. Upload `grafana/dashboards/gtv-overview.json`.
3. Select your Prometheus datasource when prompted (the template
   variable `DS_PROMETHEUS` handles the rebind).

## Importing the rules into an existing Prometheus

Copy `prometheus/recording-rules.yml` and
`prometheus/alerting-rules.yml` into your Prometheus config dir and
add them to `rule_files:` in your main `prometheus.yml`. Reload with
`curl -X POST http://localhost:9090/-/reload` (requires
`--web.enable-lifecycle`).

## SLI definitions

The recording rules produce four time series your dashboards and
alerts build on:

| Series                                        | What it measures                                     |
|-----------------------------------------------|------------------------------------------------------|
| `gtv:adapter_availability:ratio_rate5m`       | % adapter calls with `outcome="ok"` (5m)             |
| `gtv:adapter_availability:ratio_rate30d`      | Same over 30d — the SLO stat                          |
| `gtv:verify_latency:ratio_under_budget_rate5m`| % requests ≤ 5s budget (5m)                           |
| `gtv:cache:hit_ratio_rate5m`                  | Verdict cache hit ratio (informational)               |

Everything else on the dashboard is a direct PromQL expression against
the raw `gtv_*` metrics in `src/gtv/obs/metrics.py`, so you can read
the expressions in the JSON and audit them against source.
