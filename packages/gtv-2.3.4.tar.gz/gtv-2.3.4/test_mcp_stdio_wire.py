"""Wire protocol smoke test for MCP stdio server.

This test spawns gtv-mcp as a subprocess and exercises the real JSON-RPC 2.0
stdio transport: initialize, tools/list, and tools/call with round-trip
verification.

Gate: GTV_STDIO_SMOKE=1 (opt-in, not in default test suite)
The subprocess disables network adapters to avoid dependencies and uses
the classifier's short-circuit for OPINION/CREATIVE claims.
"""
from __future__ import annotations

import json
import os
import select
import subprocess
import sys
from typing import Any

import pytest

# Gate: skip unless explicitly opted in
pytestmark = pytest.mark.skipif(
    os.getenv("GTV_STDIO_SMOKE") != "1",
    reason="GTV_STDIO_SMOKE not set; opt-in via env var",
)


def _send_and_read(
    proc: subprocess.Popen[str],
    msg: dict[str, Any],
    timeout: float = 5.0,
) -> dict[str, Any]:
    """Send JSON-RPC message to subprocess and read response line.

    Args:
        proc: Popen handle with text mode stdio.
        msg: JSON-RPC message dict.
        timeout: Read timeout in seconds.

    Returns:
        Parsed JSON response from stdout.

    Raises:
        RuntimeError: on timeout or malformed JSON.
        EOFError: if process closed stdout unexpectedly.
    """
    # Send request with newline
    request_line = json.dumps(msg) + "\n"
    proc.stdin.write(request_line)
    proc.stdin.flush()

    # Read response with timeout using select
    if proc.stdout is None:
        raise RuntimeError("stdout is None")

    ready, _, _ = select.select([proc.stdout], [], [], timeout)
    if not ready:
        raise RuntimeError(f"No response within {timeout}s (timeout)")

    response_line = proc.stdout.readline()
    if not response_line:
        raise EOFError("Process closed stdout (EOF)")

    try:
        return json.loads(response_line)
    except json.JSONDecodeError as e:
        raise RuntimeError(
            f"Malformed JSON from server: {response_line!r}"
        ) from e


class TestStdioToolsListRoundtrip:
    """Test tools/list request over stdio transport."""

    def test_stdio_tools_list_roundtrip(self) -> None:
        """Launch server, send handshake, list tools, assert both in response."""
        env = os.environ.copy()
        env["GTV_DISABLE_DEFAULT_ADAPTERS"] = "1"

        proc = subprocess.Popen(
            [sys.executable, "-m", "gtv.mcp.stdio"],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            cwd="/tmp/gtv-run",
            env=env,
        )

        try:
            # Send initialize
            init_msg = {
                "jsonrpc": "2.0",
                "id": 1,
                "method": "initialize",
                "params": {
                    "protocolVersion": "2024-11-05",
                    "capabilities": {},
                    "clientInfo": {
                        "name": "smoke",
                        "version": "0.1",
                    },
                },
            }
            resp = _send_and_read(proc, init_msg, timeout=10.0)
            assert resp.get("id") == 1
            assert "result" in resp or "error" in resp

            # Send initialized notification (no response expected)
            init_notif = {
                "jsonrpc": "2.0",
                "method": "notifications/initialized",
            }
            proc.stdin.write(json.dumps(init_notif) + "\n")
            proc.stdin.flush()

            # Send tools/list request
            list_msg = {
                "jsonrpc": "2.0",
                "id": 2,
                "method": "tools/list",
                "params": {},
            }
            resp = _send_and_read(proc, list_msg, timeout=10.0)

            # Verify response structure
            assert resp.get("id") == 2
            assert "result" in resp
            result = resp["result"]
            assert "tools" in result
            tools = result["tools"]
            assert isinstance(tools, list)
            assert len(tools) == 2

            # Check tool names and schemas
            tool_names = {t["name"] for t in tools}
            assert tool_names == {"verify_claim", "retrieve_facts"}

            # Verify verify_claim schema
            verify_tool = next(t for t in tools if t["name"] == "verify_claim")
            assert "inputSchema" in verify_tool
            schema = verify_tool["inputSchema"]
            assert "properties" in schema
            assert "claim" in schema["properties"]
            assert "domain" in schema["properties"]
            assert "max_sources" in schema["properties"]

            # Verify retrieve_facts schema
            retrieve_tool = next(t for t in tools if t["name"] == "retrieve_facts")
            assert "inputSchema" in retrieve_tool
            schema = retrieve_tool["inputSchema"]
            assert "properties" in schema
            assert "text" in schema["properties"]
            assert "domain" in schema["properties"]
            assert "max_claims" in schema["properties"]

        finally:
            # Cleanup: send SIGTERM and wait
            proc.terminate()
            try:
                proc.wait(timeout=2.0)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait(timeout=1.0)


class TestStdioToolsCallVerifyClaimRoundtrip:
    """Test tools/call verify_claim over stdio transport."""

    def test_stdio_tools_call_verify_claim_opinion_roundtrip(self) -> None:
        """Call verify_claim with OPINION claim; expect short-circuit via classifier."""
        env = os.environ.copy()
        env["GTV_DISABLE_DEFAULT_ADAPTERS"] = "1"

        proc = subprocess.Popen(
            [sys.executable, "-m", "gtv.mcp.stdio"],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            cwd="/tmp/gtv-run",
            env=env,
        )

        try:
            # Send initialize and initialized
            init_msg = {
                "jsonrpc": "2.0",
                "id": 1,
                "method": "initialize",
                "params": {
                    "protocolVersion": "2024-11-05",
                    "capabilities": {},
                    "clientInfo": {
                        "name": "smoke",
                        "version": "0.1",
                    },
                },
            }
            resp = _send_and_read(proc, init_msg, timeout=10.0)
            assert resp.get("id") == 1

            init_notif = {
                "jsonrpc": "2.0",
                "method": "notifications/initialized",
            }
            proc.stdin.write(json.dumps(init_notif) + "\n")
            proc.stdin.flush()

            # Send tools/call verify_claim with OPINION claim
            # Trigger OPINION classifier by using first-person/modal language
            call_msg = {
                "jsonrpc": "2.0",
                "id": 2,
                "method": "tools/call",
                "params": {
                    "name": "verify_claim",
                    "arguments": {
                        "claim": "I think pineapple belongs on pizza",
                    },
                },
            }
            resp = _send_and_read(proc, call_msg, timeout=10.0)

            # Verify response structure
            assert resp.get("id") == 2
            assert "result" in resp
            result = resp["result"]
            assert isinstance(result, dict)
            assert "content" in result
            content_list = result["content"]
            assert isinstance(content_list, list)
            assert len(content_list) > 0

            # First item should be TextContent with JSON envelope
            content = content_list[0]
            assert content.get("type") == "text"
            assert "text" in content

            # Parse envelope JSON
            envelope_json = json.loads(content["text"])
            assert "verdict" in envelope_json
            # OPINION claims should short-circuit to verdict=opinion (uppercase)
            assert envelope_json["verdict"] == "OPINION"

        finally:
            proc.terminate()
            try:
                proc.wait(timeout=2.0)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait(timeout=1.0)

    def test_stdio_tools_call_verify_claim_creative_roundtrip(self) -> None:
        """Call verify_claim with CREATIVE claim; expect short-circuit via classifier."""
        env = os.environ.copy()
        env["GTV_DISABLE_DEFAULT_ADAPTERS"] = "1"

        proc = subprocess.Popen(
            [sys.executable, "-m", "gtv.mcp.stdio"],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            cwd="/tmp/gtv-run",
            env=env,
        )

        try:
            # Send initialize and initialized
            init_msg = {
                "jsonrpc": "2.0",
                "id": 1,
                "method": "initialize",
                "params": {
                    "protocolVersion": "2024-11-05",
                    "capabilities": {},
                    "clientInfo": {
                        "name": "smoke",
                        "version": "0.1",
                    },
                },
            }
            resp = _send_and_read(proc, init_msg, timeout=10.0)
            assert resp.get("id") == 1

            init_notif = {
                "jsonrpc": "2.0",
                "method": "notifications/initialized",
            }
            proc.stdin.write(json.dumps(init_notif) + "\n")
            proc.stdin.flush()

            # Send tools/call verify_claim with CREATIVE claim
            call_msg = {
                "jsonrpc": "2.0",
                "id": 2,
                "method": "tools/call",
                "params": {
                    "name": "verify_claim",
                    "arguments": {
                        "claim": "Write a poem about dragons breathing fire",
                    },
                },
            }
            resp = _send_and_read(proc, call_msg, timeout=10.0)

            # Verify response structure
            assert resp.get("id") == 2
            assert "result" in resp
            result = resp["result"]
            assert isinstance(result, dict)
            assert "content" in result
            content_list = result["content"]
            assert isinstance(content_list, list)
            assert len(content_list) > 0

            # First item should be TextContent with JSON envelope
            content = content_list[0]
            assert content.get("type") == "text"
            assert "text" in content

            # Parse envelope JSON
            envelope_json = json.loads(content["text"])
            assert "verdict" in envelope_json
            # CREATIVE claims should short-circuit to verdict=creative (uppercase)
            assert envelope_json["verdict"] == "CREATIVE"

        finally:
            proc.terminate()
            try:
                proc.wait(timeout=2.0)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait(timeout=1.0)
