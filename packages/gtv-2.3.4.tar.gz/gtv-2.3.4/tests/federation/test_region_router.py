"""Tests for region-aware routing with health probing."""
from __future__ import annotations

import httpx
import pytest
import respx

from gtv.federation.region_router import RegionEndpoint, RegionHealth, RegionRouter


@pytest.fixture
def mock_respx():
    """Provide a respx mock router."""
    with respx.mock as respx_mock:
        yield respx_mock


@pytest.fixture
def endpoints() -> list[RegionEndpoint]:
    """Three regional endpoints."""
    return [
        RegionEndpoint(region="us-east-1", url="https://us-east.example.com"),
        RegionEndpoint(region="eu-west-1", url="https://eu-west.example.com"),
        RegionEndpoint(region="ap-southeast-1", url="https://ap-southeast.example.com"),
    ]


@pytest.fixture
async def router(endpoints: list[RegionEndpoint]) -> RegionRouter:
    """Create a router for testing."""
    router = RegionRouter(endpoints)
    yield router
    await router.close()


@pytest.mark.asyncio
async def test_pick_preferred_region_when_healthy(router: RegionRouter, mock_respx):
    """Test that pick() returns preferred_region when it's healthy."""
    router.preferred_region = "us-east-1"

    # Mark all as healthy
    mock_respx.get("https://us-east.example.com/healthz").mock(return_value=httpx.Response(200))
    mock_respx.get("https://eu-west.example.com/healthz").mock(return_value=httpx.Response(200))
    mock_respx.get("https://ap-southeast.example.com/healthz").mock(return_value=httpx.Response(200))

    await router.probe_all()
    picked = await router.pick()
    assert picked.region == "us-east-1"


@pytest.mark.asyncio
async def test_pick_falls_back_to_lowest_latency(router: RegionRouter, mock_respx):
    """Test that pick() falls back to lowest-latency when preferred is down."""
    router.preferred_region = "us-east-1"

    # us-east down 3+ times, eu-west and ap-southeast healthy
    mock_respx.get("https://us-east.example.com/healthz").mock(
        return_value=httpx.Response(500)
    )
    mock_respx.get("https://eu-west.example.com/healthz").mock(
        return_value=httpx.Response(200)
    )
    mock_respx.get("https://ap-southeast.example.com/healthz").mock(
        return_value=httpx.Response(200)
    )

    # Probe 3 times to mark us-east unhealthy
    await router.probe_all()
    await router.probe_all()
    await router.probe_all()

    picked = await router.pick()

    # Should pick eu-west or ap-southeast (whichever has lower latency from probe)
    # Both have latency data from probe, so pick lowest
    assert picked.region in ["eu-west-1", "ap-southeast-1"]


@pytest.mark.asyncio
async def test_unhealthy_threshold_not_immediate(router: RegionRouter, mock_respx):
    """Test that one failure doesn't immediately demote an endpoint."""
    # First probe: single failure (failures=1, threshold=3)
    mock_respx.get("https://us-east.example.com/healthz").mock(
        return_value=httpx.Response(500)
    )
    mock_respx.get("https://eu-west.example.com/healthz").mock(
        return_value=httpx.Response(200)
    )
    mock_respx.get("https://ap-southeast.example.com/healthz").mock(
        return_value=httpx.Response(200)
    )

    await router.probe_all()

    # us-east should still be marked healthy (failures=1 < threshold=3)
    status = router.status()
    us_east_status = next(s for s in status if s.region == "us-east-1")
    assert us_east_status.healthy is True
    assert us_east_status.consecutive_failures == 1


@pytest.mark.asyncio
async def test_recovery_resets_failure_counter(router: RegionRouter, mock_respx):
    """Test that a single success resets the failure counter."""
    # Simulate 2 failures then 1 success
    mock_respx.get("https://us-east.example.com/healthz").mock(
        return_value=httpx.Response(500)
    )

    await router.probe_all()  # failures=1
    assert router.status()[0].consecutive_failures == 1

    await router.probe_all()  # failures=2
    assert router.status()[0].consecutive_failures == 2

    # Now success
    mock_respx.get("https://us-east.example.com/healthz").mock(
        return_value=httpx.Response(200)
    )
    await router.probe_all()  # Reset to 0

    status = router.status()
    us_east_status = next(s for s in status if s.region == "us-east-1")
    assert us_east_status.healthy is True
    assert us_east_status.consecutive_failures == 0


@pytest.mark.asyncio
async def test_probe_all_returns_one_health_per_endpoint(router: RegionRouter, mock_respx):
    """Test that probe_all returns RegionHealth for each endpoint."""
    mock_respx.get("https://us-east.example.com/healthz").mock(return_value=httpx.Response(200))
    mock_respx.get("https://eu-west.example.com/healthz").mock(return_value=httpx.Response(200))
    mock_respx.get("https://ap-southeast.example.com/healthz").mock(return_value=httpx.Response(200))

    result = await router.probe_all()

    assert len(result) == 3
    assert all(isinstance(h, RegionHealth) for h in result)
    regions = {h.region for h in result}
    assert regions == {"us-east-1", "eu-west-1", "ap-southeast-1"}


@pytest.mark.asyncio
async def test_empty_endpoints_raises_valueerror():
    """Test that empty endpoints list raises ValueError."""
    with pytest.raises(ValueError, match="At least one endpoint"):
        RegionRouter([])


@pytest.mark.asyncio
async def test_all_endpoints_down_still_returns_something(router: RegionRouter, mock_respx):
    """Test that pick() returns an endpoint even when all are down."""
    # All fail 3+ times
    mock_respx.get("https://us-east.example.com/healthz").mock(
        return_value=httpx.Response(500)
    )
    mock_respx.get("https://eu-west.example.com/healthz").mock(
        return_value=httpx.Response(500)
    )
    mock_respx.get("https://ap-southeast.example.com/healthz").mock(
        return_value=httpx.Response(500)
    )

    # Probe until all unhealthy (failures >= 3)
    await router.probe_all()
    await router.probe_all()
    await router.probe_all()

    # Verify all unhealthy
    status = router.status()
    assert all(not s.healthy for s in status)

    # pick() should still return something (last resort)
    picked = await router.pick()
    assert picked is not None
    assert picked.region in [e.region for e in router.endpoints.values()]


@pytest.mark.asyncio
async def test_status_reflects_latest_probe_results(router: RegionRouter, mock_respx):
    """Test that status() returns the latest probe results."""
    mock_respx.get("https://us-east.example.com/healthz").mock(return_value=httpx.Response(200))
    mock_respx.get("https://eu-west.example.com/healthz").mock(return_value=httpx.Response(500))
    mock_respx.get("https://ap-southeast.example.com/healthz").mock(return_value=httpx.Response(200))

    await router.probe_all()

    status = router.status()
    eu_status = next(s for s in status if s.region == "eu-west-1")
    # After 1 failure, should still be marked healthy (1 < threshold of 3)
    assert eu_status.healthy is True
    assert eu_status.consecutive_failures == 1

    # Change eu-west to healthy
    mock_respx.get("https://eu-west.example.com/healthz").mock(return_value=httpx.Response(200))
    await router.probe_all()

    status = router.status()
    eu_status = next(s for s in status if s.region == "eu-west-1")
    assert eu_status.healthy is True
    assert eu_status.consecutive_failures == 0


@pytest.mark.asyncio
async def test_close_closes_client(endpoints: list[RegionEndpoint]):
    """Test that close() closes the internal HTTP client."""
    router = RegionRouter(endpoints)
    assert not router._client.is_closed
    await router.close()
    assert router._client.is_closed


@pytest.mark.asyncio
async def test_provided_client_not_closed(endpoints: list[RegionEndpoint]):
    """Test that close() doesn't close a client that was provided by caller."""
    client = httpx.AsyncClient()
    router = RegionRouter(endpoints, client=client)
    await router.close()
    # Client should still be open (we didn't close it)
    assert not client.is_closed
    await client.aclose()


@pytest.mark.asyncio
async def test_timeout_is_respected(router: RegionRouter, mock_respx):
    """Test that health probes timeout after 2 seconds."""
    mock_respx.get("https://us-east.example.com/healthz").mock(
        side_effect=httpx.TimeoutException("timeout")
    )
    mock_respx.get("https://eu-west.example.com/healthz").mock(return_value=httpx.Response(200))
    mock_respx.get("https://ap-southeast.example.com/healthz").mock(return_value=httpx.Response(200))

    await router.probe_all()

    status = router.status()
    us_east_status = next(s for s in status if s.region == "us-east-1")
    # Timeout should be treated as failure
    assert us_east_status.healthy is True  # 1 failure < 3
    assert us_east_status.consecutive_failures == 1


@pytest.mark.asyncio
async def test_latency_tracked_in_health(router: RegionRouter, mock_respx):
    """Test that latency_ms is recorded in health status."""
    mock_respx.get("https://us-east.example.com/healthz").mock(return_value=httpx.Response(200))
    mock_respx.get("https://eu-west.example.com/healthz").mock(return_value=httpx.Response(200))
    mock_respx.get("https://ap-southeast.example.com/healthz").mock(return_value=httpx.Response(200))

    await router.probe_all()

    status = router.status()
    for s in status:
        assert s.latency_ms is not None
        assert s.latency_ms >= 0


@pytest.mark.asyncio
async def test_last_probed_iso_8601(router: RegionRouter, mock_respx):
    """Test that last_probed is ISO 8601 UTC."""
    mock_respx.get("https://us-east.example.com/healthz").mock(return_value=httpx.Response(200))
    mock_respx.get("https://eu-west.example.com/healthz").mock(return_value=httpx.Response(200))
    mock_respx.get("https://ap-southeast.example.com/healthz").mock(return_value=httpx.Response(200))

    await router.probe_all()

    status = router.status()
    for s in status:
        # Should be valid ISO 8601 and contain 'T' and 'Z' or offset
        assert "T" in s.last_probed
        assert "+" in s.last_probed or "Z" in s.last_probed or s.last_probed.endswith("+00:00")


@pytest.mark.asyncio
async def test_weighted_random_among_healthy(router: RegionRouter, mock_respx):
    """Test that weighted random selection works when all healthy."""
    # All healthy - should pick any of them
    mock_respx.get("https://us-east.example.com/healthz").mock(return_value=httpx.Response(200))
    mock_respx.get("https://eu-west.example.com/healthz").mock(return_value=httpx.Response(200))
    mock_respx.get("https://ap-southeast.example.com/healthz").mock(return_value=httpx.Response(200))

    await router.probe_all()
    picked = await router.pick()

    # Should pick one of the healthy endpoints
    assert picked.region in ["us-east-1", "eu-west-1", "ap-southeast-1"]


@pytest.mark.asyncio
async def test_non_2xx_status_marks_unhealthy(router: RegionRouter, mock_respx):
    """Test that non-2xx status codes mark endpoint unhealthy after threshold."""
    mock_respx.get("https://us-east.example.com/healthz").mock(
        return_value=httpx.Response(503)
    )
    mock_respx.get("https://eu-west.example.com/healthz").mock(return_value=httpx.Response(200))
    mock_respx.get("https://ap-southeast.example.com/healthz").mock(return_value=httpx.Response(200))

    # First failure
    await router.probe_all()
    status = router.status()
    us_status = next(s for s in status if s.region == "us-east-1")
    assert us_status.healthy is True
    assert us_status.consecutive_failures == 1

    # Second failure
    await router.probe_all()
    status = router.status()
    us_status = next(s for s in status if s.region == "us-east-1")
    assert us_status.healthy is True
    assert us_status.consecutive_failures == 2

    # Third failure - should now be unhealthy
    await router.probe_all()
    status = router.status()
    us_status = next(s for s in status if s.region == "us-east-1")
    assert us_status.healthy is False
    assert us_status.consecutive_failures == 3
