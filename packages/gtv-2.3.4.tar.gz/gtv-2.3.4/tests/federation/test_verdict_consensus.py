"""Tests for federated verdict consensus."""
from __future__ import annotations

import pytest  # noqa: F401

from gtv.federation.verdict_consensus import (
    PeerVerdict,
    merge_peer_verdicts,
)


def test_all_agree() -> None:
    """All peers agree on same status -> dissenters empty."""
    verdicts = [
        PeerVerdict("peer_a", "VERIFIED", 0.9, "2026-01-01T00:00:00Z"),
        PeerVerdict("peer_b", "VERIFIED", 0.85, "2026-01-01T00:00:00Z"),
        PeerVerdict("peer_c", "VERIFIED", 0.8, "2026-01-01T00:00:00Z"),
    ]
    result = merge_peer_verdicts(verdicts)
    assert result.status == "VERIFIED"
    assert result.dissenters == []
    assert result.quorum_size == 3


def test_majority_rule_with_dissenter() -> None:
    """2 agree, 1 disagree -> winning status with 1 dissenter."""
    verdicts = [
        PeerVerdict("peer_a", "VERIFIED", 0.9, "2026-01-01T00:00:00Z"),
        PeerVerdict("peer_b", "VERIFIED", 0.85, "2026-01-01T00:00:00Z"),
        PeerVerdict("peer_c", "REFUTED", 0.8, "2026-01-01T00:00:00Z"),
    ]
    result = merge_peer_verdicts(verdicts)
    assert result.status == "VERIFIED"
    assert result.quorum_size == 3
    assert "peer_c" in result.dissenters
    assert "peer_a" not in result.dissenters
    assert "peer_b" not in result.dissenters


def test_trust_weighted_override() -> None:
    """High-trust peer beats multiple low-trust peers."""
    verdicts = [
        PeerVerdict("peer_high", "REFUTED", 0.9, "2026-01-01T00:00:00Z"),
        PeerVerdict("peer_low1", "VERIFIED", 0.8, "2026-01-01T00:00:00Z"),
        PeerVerdict("peer_low2", "VERIFIED", 0.8, "2026-01-01T00:00:00Z"),
    ]
    trust_scores = {"peer_high": 0.9, "peer_low1": 0.1, "peer_low2": 0.1}

    result = merge_peer_verdicts(verdicts, trust_scores=trust_scores)

    # High-trust REFUTED should win: 0.9*0.9 = 0.81
    # vs two low-trust VERIFIED: (0.1*0.8) + (0.1*0.8) = 0.16
    assert result.status == "REFUTED"
    assert "peer_low1" in result.dissenters
    assert "peer_low2" in result.dissenters


def test_sub_quorum() -> None:
    """Fewer than min_quorum peers -> INSUFFICIENT."""
    verdicts = [
        PeerVerdict("peer_a", "VERIFIED", 0.9, "2026-01-01T00:00:00Z"),
    ]
    result = merge_peer_verdicts(verdicts, min_quorum=2)
    assert result.status == "INSUFFICIENT"
    assert result.confidence == 0.0
    assert result.quorum_size == 1


def test_empty_list() -> None:
    """Empty verdict list -> INSUFFICIENT."""
    result = merge_peer_verdicts([])
    assert result.status == "INSUFFICIENT"
    assert result.confidence == 0.0
    assert result.quorum_size == 0
    assert result.dissenters == []


def test_missing_trust_defaults_to_one() -> None:
    """Peers not in trust_scores dict default to trust score 1.0."""
    verdicts = [
        PeerVerdict("peer_a", "VERIFIED", 0.5, "2026-01-01T00:00:00Z"),
        PeerVerdict("peer_b", "VERIFIED", 0.3, "2026-01-01T00:00:00Z"),
        PeerVerdict("peer_c", "REFUTED", 0.9, "2026-01-01T00:00:00Z"),
    ]
    # Only provide trust for peer_a and peer_b
    trust_scores = {"peer_a": 0.5, "peer_b": 0.5}

    result = merge_peer_verdicts(verdicts, trust_scores=trust_scores)

    # peer_a: 0.5*0.5 = 0.25
    # peer_b: 0.5*0.3 = 0.15
    # peer_c: 1.0*0.9 = 0.90 (defaults to 1.0)
    # peer_c (REFUTED) wins
    assert result.status == "REFUTED"


def test_confidence_is_weighted_mean() -> None:
    """Merged confidence = mean of confidences for winning-status peers."""
    verdicts = [
        PeerVerdict("peer_a", "VERIFIED", 0.9, "2026-01-01T00:00:00Z"),
        PeerVerdict("peer_b", "VERIFIED", 0.6, "2026-01-01T00:00:00Z"),
        PeerVerdict("peer_c", "REFUTED", 0.8, "2026-01-01T00:00:00Z"),
    ]
    result = merge_peer_verdicts(verdicts)
    # VERIFIED wins (both >= REFUTED in trust-default scenario)
    # Confidence of VERIFIED peers: (0.9 + 0.6) / 2 = 0.75
    assert result.status == "VERIFIED"
    assert abs(result.confidence - 0.75) < 0.01


def test_three_way_tie_equal_weight() -> None:
    """All three statuses at equal weight -> INSUFFICIENT."""
    verdicts = [
        PeerVerdict("peer_a", "VERIFIED", 1.0, "2026-01-01T00:00:00Z"),
        PeerVerdict("peer_b", "REFUTED", 1.0, "2026-01-01T00:00:00Z"),
        PeerVerdict("peer_c", "INSUFFICIENT", 1.0, "2026-01-01T00:00:00Z"),
    ]
    result = merge_peer_verdicts(verdicts)
    # All have equal weight (1.0*1.0 = 1.0 each)
    # Three-way tie should return INSUFFICIENT
    assert result.status == "INSUFFICIENT"
    assert result.confidence == 0.0


def test_quorum_exactly_met() -> None:
    """Exactly min_quorum peers should be accepted."""
    verdicts = [
        PeerVerdict("peer_a", "VERIFIED", 0.9, "2026-01-01T00:00:00Z"),
        PeerVerdict("peer_b", "VERIFIED", 0.8, "2026-01-01T00:00:00Z"),
    ]
    result = merge_peer_verdicts(verdicts, min_quorum=2)
    assert result.status == "VERIFIED"
    assert result.quorum_size == 2


def test_two_status_tie_picks_first() -> None:
    """Two-way tie picks the first winning status (deterministic)."""
    verdicts = [
        PeerVerdict("peer_a", "VERIFIED", 0.9, "2026-01-01T00:00:00Z"),
        PeerVerdict("peer_b", "REFUTED", 0.9, "2026-01-01T00:00:00Z"),
    ]
    result = merge_peer_verdicts(verdicts)
    # Two-way tie: pick first
    assert result.status in ("VERIFIED", "REFUTED")
    # Dissenters should contain the other one
    assert len(result.dissenters) == 1


def test_confidence_zero_with_insufficient() -> None:
    """INSUFFICIENT status should always have confidence 0."""
    verdicts = [
        PeerVerdict("peer_a", "VERIFIED", 0.5, "2026-01-01T00:00:00Z"),
    ]
    result = merge_peer_verdicts(verdicts, min_quorum=2)
    assert result.status == "INSUFFICIENT"
    assert result.confidence == 0.0


def test_all_low_confidence() -> None:
    """Even with low individual confidences, merge should work."""
    verdicts = [
        PeerVerdict("peer_a", "VERIFIED", 0.1, "2026-01-01T00:00:00Z"),
        PeerVerdict("peer_b", "VERIFIED", 0.2, "2026-01-01T00:00:00Z"),
        PeerVerdict("peer_c", "REFUTED", 0.05, "2026-01-01T00:00:00Z"),
    ]
    result = merge_peer_verdicts(verdicts)
    # VERIFIED wins with confidence (0.1 + 0.2) / 2 = 0.15
    assert result.status == "VERIFIED"
    assert abs(result.confidence - 0.15) < 0.01
    assert result.dissenters == ["peer_c"]
