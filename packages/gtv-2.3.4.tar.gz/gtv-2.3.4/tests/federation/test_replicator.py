"""Tests for verdict replication service."""
from __future__ import annotations

import asyncio

import httpx
import pytest
import respx

from gtv.federation.discovery import DiscoveredPeer
from gtv.federation.replicator import VerdictReplicator


@pytest.mark.asyncio
async def test_replicate_to_two_peers() -> None:
    """Replicate to 2 peers should return 2 results."""
    peers = [
        DiscoveredPeer(
            did="did:web:peer1.example",
            endpoint_url="https://peer1.example",
            discovered_via="seed",
            discovered_at="2026-04-22T00:00:00Z",
        ),
        DiscoveredPeer(
            did="did:web:peer2.example",
            endpoint_url="https://peer2.example",
            discovered_via="seed",
            discovered_at="2026-04-22T00:00:00Z",
        ),
    ]

    with respx.mock:
        respx.post("https://peer1.example/federation/verdicts").mock(
            return_value=httpx.Response(200)
        )
        respx.post("https://peer2.example/federation/verdicts").mock(
            return_value=httpx.Response(200)
        )

        replicator = VerdictReplicator()
        verdict = {"claim": "test", "verdict": "true"}
        results = await replicator.replicate(verdict, peers)

        assert len(results) == 2
        assert all(r.status_code == 200 for r in results)


@pytest.mark.asyncio
async def test_replicate_200_response() -> None:
    """200 response should be captured in status_code."""
    peers = [
        DiscoveredPeer(
            did="did:web:peer.example",
            endpoint_url="https://peer.example",
            discovered_via="seed",
            discovered_at="2026-04-22T00:00:00Z",
        )
    ]

    with respx.mock:
        respx.post("https://peer.example/federation/verdicts").mock(
            return_value=httpx.Response(200, json={"result": "ok"})
        )

        replicator = VerdictReplicator()
        verdict = {"claim": "test"}
        results = await replicator.replicate(verdict, peers)

        assert len(results) == 1
        assert results[0].status_code == 200
        assert results[0].error is None


@pytest.mark.asyncio
async def test_replicate_4xx_captured() -> None:
    """4xx response should be captured in status_code without raising."""
    peers = [
        DiscoveredPeer(
            did="did:web:peer.example",
            endpoint_url="https://peer.example",
            discovered_via="seed",
            discovered_at="2026-04-22T00:00:00Z",
        )
    ]

    with respx.mock:
        respx.post("https://peer.example/federation/verdicts").mock(
            return_value=httpx.Response(400)
        )

        replicator = VerdictReplicator()
        verdict = {"claim": "test"}
        results = await replicator.replicate(verdict, peers)

        assert len(results) == 1
        assert results[0].status_code == 400
        assert results[0].error is None


@pytest.mark.asyncio
async def test_network_error_captured() -> None:
    """Network error should be captured in error field, not raised."""
    peers = [
        DiscoveredPeer(
            did="did:web:peer.example",
            endpoint_url="https://peer.example",
            discovered_via="seed",
            discovered_at="2026-04-22T00:00:00Z",
        )
    ]

    with respx.mock:
        respx.post("https://peer.example/federation/verdicts").mock(
            side_effect=httpx.ConnectError("Connection failed")
        )

        replicator = VerdictReplicator()
        verdict = {"claim": "test"}
        results = await replicator.replicate(verdict, peers)

        assert len(results) == 1
        assert results[0].status_code is None
        assert results[0].error is not None
        assert "Connection" in results[0].error


@pytest.mark.asyncio
async def test_empty_peer_list() -> None:
    """Empty peer list should return empty results."""
    replicator = VerdictReplicator()
    verdict = {"claim": "test"}
    results = await replicator.replicate(verdict, [])

    assert results == []


@pytest.mark.asyncio
async def test_timeout_captured() -> None:
    """Timeout should be captured in error field."""
    peers = [
        DiscoveredPeer(
            did="did:web:peer.example",
            endpoint_url="https://peer.example",
            discovered_via="seed",
            discovered_at="2026-04-22T00:00:00Z",
        )
    ]

    async def slow_handler(request):
        await asyncio.sleep(10)  # Will timeout at 0.1s
        return httpx.Response(200)

    with respx.mock:
        respx.post("https://peer.example/federation/verdicts").mock(
            side_effect=TimeoutError("Timeout")
        )

        replicator = VerdictReplicator(timeout=0.1)
        verdict = {"claim": "test"}
        results = await replicator.replicate(verdict, peers)

        assert len(results) == 1
        assert results[0].status_code is None
        assert results[0].error is not None
        assert "Timeout" in results[0].error


@pytest.mark.asyncio
async def test_replicate_headers() -> None:
    """POST should include Content-Type header."""
    peers = [
        DiscoveredPeer(
            did="did:web:peer.example",
            endpoint_url="https://peer.example",
            discovered_via="seed",
            discovered_at="2026-04-22T00:00:00Z",
        )
    ]

    captured_headers = {}

    def capture_headers(request):
        captured_headers.update(request.headers)
        return httpx.Response(200)

    with respx.mock:
        respx.post("https://peer.example/federation/verdicts").mock(
            side_effect=capture_headers
        )

        replicator = VerdictReplicator()
        verdict = {"claim": "test"}
        await replicator.replicate(verdict, peers)

        assert captured_headers.get("content-type") == "application/json"
