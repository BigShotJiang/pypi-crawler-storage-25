"""Tests for federation DoS protection (rate limiting + circuit breaker)."""
from __future__ import annotations

import asyncio

import pytest

from gtv.federation.dos_protection import PeerRateLimiter


class ManualClock:
    """Manual clock for deterministic testing (not wall-clock time)."""

    def __init__(self, start: float = 0.0):
        self.current_time = start

    def advance(self, seconds: float) -> None:
        """Advance the clock."""
        self.current_time += seconds

    def now(self) -> float:
        """Get current time."""
        return self.current_time


@pytest.fixture
def clock():
    """Provide a manual clock for tests."""
    return ManualClock()


@pytest.fixture
def limiter(clock):
    """Provide a rate limiter with a mocked clock."""
    limiter = PeerRateLimiter(
        tokens_per_sec=10.0,
        bucket_capacity=100,
        lockout_threshold=50,
        lockout_duration_s=300,
        clock=clock.now,
    )
    return limiter


@pytest.mark.asyncio
async def test_token_bucket_refills_over_time(limiter, clock):
    """Token bucket should refill at the configured rate."""
    # Peer starts with full bucket (100 tokens at 10/s = 10 seconds worth)
    assert await limiter.try_acquire("alice", 1) is True
    assert limiter.peers["alice"].tokens == 99.0

    # Advance 1 second: 10 more tokens refilled, then acquire 1
    # 99 + 10 - 1 = 99 (no net change but tokens were refilled)
    clock.advance(1.0)
    assert await limiter.try_acquire("alice", 1) is True
    assert limiter.peers["alice"].tokens == 99.0

    # Drain significantly, then advance and see refill
    alice_state = limiter.peers["alice"]
    alice_state.tokens = 20.0
    clock.advance(1.0)  # 10 more tokens
    # Before acquire: 20 + 10 = 30, after 1 acquire: 29
    result = await limiter.try_acquire("alice", 1)
    assert result is True
    assert alice_state.tokens == 29.0


@pytest.mark.asyncio
async def test_try_acquire_denies_when_bucket_empty(limiter, clock):
    """try_acquire should return False when bucket is empty."""
    # Drain the bucket
    alice_state = limiter.peers.get("alice")
    if alice_state:
        alice_state.tokens = 0.0
    else:
        # First request initializes with full bucket
        await limiter.try_acquire("alice", 101)
        limiter.peers["alice"].tokens = 0.0

    # Try to acquire when empty
    assert await limiter.try_acquire("alice", 1) is False
    assert limiter.peers["alice"].tokens == 0.0


@pytest.mark.asyncio
async def test_different_peers_have_independent_buckets(limiter, clock):
    """Different peers should have independent rate limit buckets."""
    # Alice and Bob start with independent 100-token buckets
    assert await limiter.try_acquire("alice", 50) is True
    assert limiter.peers["alice"].tokens == 50.0

    assert await limiter.try_acquire("bob", 60) is True
    assert limiter.peers["bob"].tokens == 40.0

    # Draining alice doesn't affect bob
    assert await limiter.try_acquire("alice", 50) is True
    assert limiter.peers["alice"].tokens == 0.0
    assert limiter.peers["bob"].tokens == 40.0


@pytest.mark.asyncio
async def test_lockout_trips_at_threshold(limiter, clock):
    """Lockout should trigger when denial count exceeds threshold in 60s."""
    alice_state = limiter.peers.get("alice")
    if alice_state is None:
        await limiter.try_acquire("alice", 1)
        alice_state = limiter.peers["alice"]

    # Drain the bucket to force denials
    alice_state.tokens = 0.0

    # Generate > 50 denials within 60 seconds
    for _ in range(51):
        result = await limiter.try_acquire("alice", 1)
        assert result is False

    # Alice should now be locked out
    assert limiter.is_locked_out("alice") is True
    assert alice_state.locked_out_until > clock.current_time


@pytest.mark.asyncio
async def test_lockout_auto_releases_after_window(limiter, clock):
    """Lockout should auto-release after the lockout window expires."""
    alice_state = limiter.peers.get("alice")
    if alice_state is None:
        await limiter.try_acquire("alice", 1)
        alice_state = limiter.peers["alice"]

    alice_state.tokens = 0.0

    # Trigger lockout
    for _ in range(51):
        await limiter.try_acquire("alice", 1)

    assert limiter.is_locked_out("alice") is True

    # Advance past lockout window (300 seconds default)
    clock.advance(301.0)

    # Should no longer be locked out
    # (would need to re-check with a new attempt to clear denial counter)
    assert limiter.is_locked_out("alice") is False


@pytest.mark.asyncio
async def test_is_locked_out_returns_false_for_unknown_peer(limiter):
    """is_locked_out should return False for peers not yet seen."""
    assert limiter.is_locked_out("unknown_peer") is False


@pytest.mark.asyncio
async def test_concurrent_acquires_same_peer_serialized(limiter, clock):
    """Concurrent try_acquire on same peer should be serialized."""
    # This tests that the per-peer asyncio.Lock works correctly
    peer = "alice"

    # Pre-initialize with some tokens
    alice_state = limiter.peers.get(peer)
    if alice_state is None:
        await limiter.try_acquire(peer, 1)
        alice_state = limiter.peers[peer]

    alice_state.tokens = 50.0

    # Launch 20 concurrent acquire attempts
    results = await asyncio.gather(
        *(limiter.try_acquire(peer, 1) for _ in range(20))
    )

    # Exactly 50 should succeed (we had 50 tokens)
    successes = sum(1 for r in results if r)
    assert successes == 20
    assert alice_state.tokens == 30.0


@pytest.mark.asyncio
async def test_denial_window_resets(limiter, clock):
    """Denial window should reset after 60 seconds."""
    alice_state = limiter.peers.get("alice")
    if alice_state is None:
        await limiter.try_acquire("alice", 1)
        alice_state = limiter.peers["alice"]

    alice_state.tokens = 0.0

    # Generate 25 denials in window 1
    for _ in range(25):
        await limiter.try_acquire("alice", 1)

    denial_count_1 = alice_state.denial_count
    assert denial_count_1 == 25

    # Advance past 60 seconds and reset tokens to force denial
    clock.advance(61.0)

    # This try_acquire will refill tokens due to elapsed time, but we'll
    # immediately set tokens back to 0 to force a denial in the new window
    await limiter.try_acquire("alice", 1)
    alice_state.tokens = 0.0

    # Now try acquire, it should deny and reset the counter
    await limiter.try_acquire("alice", 1)
    assert alice_state.denial_count == 1


@pytest.mark.asyncio
async def test_allows_request_when_sufficient_tokens(limiter, clock):
    """Middleware allows request through when tokens available."""
    # Peer starts with full bucket; first request should succeed
    assert await limiter.try_acquire("bob", 1) is True
    assert limiter.peers["bob"].tokens == 99.0


@pytest.mark.asyncio
async def test_multiple_tokens_per_request(limiter, clock):
    """try_acquire should support requesting multiple tokens."""
    alice_state = limiter.peers.get("alice")
    if alice_state is None:
        await limiter.try_acquire("alice", 1)
        alice_state = limiter.peers["alice"]

    alice_state.tokens = 50.0

    # Request 30 tokens
    assert await limiter.try_acquire("alice", 30) is True
    assert alice_state.tokens == 20.0

    # Request 30 more (only 20 available)
    assert await limiter.try_acquire("alice", 30) is False
    assert alice_state.tokens == 20.0


@pytest.mark.asyncio
async def test_denial_count_doesnt_increment_on_success(limiter, clock):
    """Denial count should not increment when request succeeds."""
    alice_state = limiter.peers.get("alice")
    if alice_state is None:
        await limiter.try_acquire("alice", 1)
        alice_state = limiter.peers["alice"]

    alice_state.tokens = 100.0
    alice_state.denial_count = 0

    # Successful request
    assert await limiter.try_acquire("alice", 1) is True

    # Denial count should stay at 0
    assert alice_state.denial_count == 0
