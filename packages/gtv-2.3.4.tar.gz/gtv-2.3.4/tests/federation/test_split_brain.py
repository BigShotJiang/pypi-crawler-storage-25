"""Tests for split-brain detection and recovery."""
from __future__ import annotations

import pytest

from gtv.federation.split_brain import (
    ClaimLineage,
    DivergenceReport,
    detect_divergence,
    propose_merge,
)

# ============================================================================
# detect_divergence tests
# ============================================================================


def test_all_peers_agree() -> None:
    """All peers agree on same head_hash -> divergent=False."""
    lineages = [
        ClaimLineage(
            claim_id="claim_123",
            peer_did="peer_a",
            head_hash="hash_3",
            head_timestamp="2026-04-22T12:00:00Z",
            chain_hashes=["hash_1", "hash_2", "hash_3"],
        ),
        ClaimLineage(
            claim_id="claim_123",
            peer_did="peer_b",
            head_hash="hash_3",
            head_timestamp="2026-04-22T12:00:00Z",
            chain_hashes=["hash_1", "hash_2", "hash_3"],
        ),
        ClaimLineage(
            claim_id="claim_123",
            peer_did="peer_c",
            head_hash="hash_3",
            head_timestamp="2026-04-22T12:00:00Z",
            chain_hashes=["hash_1", "hash_2", "hash_3"],
        ),
    ]
    report = detect_divergence(lineages)
    assert report.divergent is False
    assert report.common_ancestor_hash == "hash_3"
    assert all(len(report.branches[p]) == 0 for p in ["peer_a", "peer_b", "peer_c"])
    assert report.branch_leaders == {
        "peer_a": "hash_3",
        "peer_b": "hash_3",
        "peer_c": "hash_3",
    }


def test_two_way_split_with_divergence() -> None:
    """Two peers diverge after a common ancestor."""
    lineages = [
        ClaimLineage(
            claim_id="claim_123",
            peer_did="peer_a",
            head_hash="hash_4",
            head_timestamp="2026-04-22T12:00:00Z",
            chain_hashes=["hash_1", "hash_2", "hash_3", "hash_4"],
        ),
        ClaimLineage(
            claim_id="claim_123",
            peer_did="peer_b",
            head_hash="hash_3b",
            head_timestamp="2026-04-22T12:05:00Z",
            chain_hashes=["hash_1", "hash_2", "hash_3b"],
        ),
    ]
    report = detect_divergence(lineages)
    assert report.divergent is True
    assert report.common_ancestor_hash == "hash_2"
    assert report.branches["peer_a"] == ["hash_3", "hash_4"]
    assert report.branches["peer_b"] == ["hash_3b"]
    assert report.branch_leaders == {"peer_a": "hash_4", "peer_b": "hash_3b"}


def test_common_ancestor_identified_correctly() -> None:
    """Longest common prefix is correctly identified as common ancestor."""
    lineages = [
        ClaimLineage(
            claim_id="claim_123",
            peer_did="peer_a",
            head_hash="hash_5",
            head_timestamp="2026-04-22T12:00:00Z",
            chain_hashes=["hash_1", "hash_2", "hash_3", "hash_4", "hash_5"],
        ),
        ClaimLineage(
            claim_id="claim_123",
            peer_did="peer_b",
            head_hash="hash_3_alt",
            head_timestamp="2026-04-22T11:50:00Z",
            chain_hashes=["hash_1", "hash_2", "hash_3_alt"],
        ),
    ]
    report = detect_divergence(lineages)
    assert report.common_ancestor_hash == "hash_2"
    assert report.branches["peer_a"] == ["hash_3", "hash_4", "hash_5"]
    assert report.branches["peer_b"] == ["hash_3_alt"]


def test_disjoint_histories_no_common_ancestor() -> None:
    """Peers with completely disjoint histories -> common_ancestor_hash = None."""
    lineages = [
        ClaimLineage(
            claim_id="claim_123",
            peer_did="peer_a",
            head_hash="hash_a2",
            head_timestamp="2026-04-22T12:00:00Z",
            chain_hashes=["hash_a1", "hash_a2"],
        ),
        ClaimLineage(
            claim_id="claim_123",
            peer_did="peer_b",
            head_hash="hash_b2",
            head_timestamp="2026-04-22T12:00:00Z",
            chain_hashes=["hash_b1", "hash_b2"],
        ),
    ]
    report = detect_divergence(lineages)
    assert report.divergent is True
    assert report.common_ancestor_hash is None
    assert report.branches["peer_a"] == ["hash_a1", "hash_a2"]
    assert report.branches["peer_b"] == ["hash_b1", "hash_b2"]


def test_single_peer_not_divergent() -> None:
    """Single peer input -> divergent=False, branches empty."""
    lineages = [
        ClaimLineage(
            claim_id="claim_123",
            peer_did="peer_a",
            head_hash="hash_3",
            head_timestamp="2026-04-22T12:00:00Z",
            chain_hashes=["hash_1", "hash_2", "hash_3"],
        ),
    ]
    report = detect_divergence(lineages)
    assert report.divergent is False
    assert report.common_ancestor_hash == "hash_3"
    assert report.branches["peer_a"] == []
    assert report.branch_leaders["peer_a"] == "hash_3"


def test_three_way_split() -> None:
    """Three peers each with different head_hash -> divergent=True."""
    lineages = [
        ClaimLineage(
            claim_id="claim_123",
            peer_did="peer_a",
            head_hash="hash_4a",
            head_timestamp="2026-04-22T12:00:00Z",
            chain_hashes=["hash_1", "hash_2", "hash_4a"],
        ),
        ClaimLineage(
            claim_id="claim_123",
            peer_did="peer_b",
            head_hash="hash_4b",
            head_timestamp="2026-04-22T12:00:00Z",
            chain_hashes=["hash_1", "hash_2", "hash_4b"],
        ),
        ClaimLineage(
            claim_id="claim_123",
            peer_did="peer_c",
            head_hash="hash_4c",
            head_timestamp="2026-04-22T12:00:00Z",
            chain_hashes=["hash_1", "hash_2", "hash_4c"],
        ),
    ]
    report = detect_divergence(lineages)
    assert report.divergent is True
    assert report.common_ancestor_hash == "hash_2"
    assert report.branches["peer_a"] == ["hash_4a"]
    assert report.branches["peer_b"] == ["hash_4b"]
    assert report.branches["peer_c"] == ["hash_4c"]


def test_mismatched_claim_ids_raises_error() -> None:
    """Mismatched claim_ids across lineages -> ValueError."""
    lineages = [
        ClaimLineage(
            claim_id="claim_123",
            peer_did="peer_a",
            head_hash="hash_1",
            head_timestamp="2026-04-22T12:00:00Z",
            chain_hashes=["hash_1"],
        ),
        ClaimLineage(
            claim_id="claim_456",
            peer_did="peer_b",
            head_hash="hash_1",
            head_timestamp="2026-04-22T12:00:00Z",
            chain_hashes=["hash_1"],
        ),
    ]
    with pytest.raises(ValueError, match="Mismatched claim_ids"):
        detect_divergence(lineages)


def test_empty_lineages_list() -> None:
    """Empty lineages list -> return default divergence report."""
    report = detect_divergence([])
    assert report.claim_id == ""
    assert report.divergent is False
    assert report.common_ancestor_hash is None
    assert report.branches == {}
    assert report.branch_leaders == {}


def test_peer_with_empty_chain_hashes() -> None:
    """Peer with empty chain_hashes is handled gracefully."""
    lineages = [
        ClaimLineage(
            claim_id="claim_123",
            peer_did="peer_a",
            head_hash="hash_1",
            head_timestamp="2026-04-22T12:00:00Z",
            chain_hashes=[],
        ),
        ClaimLineage(
            claim_id="claim_123",
            peer_did="peer_b",
            head_hash="hash_1",
            head_timestamp="2026-04-22T12:00:00Z",
            chain_hashes=["hash_1"],
        ),
    ]
    report = detect_divergence(lineages)
    # No common prefix (peer_a has empty chain)
    assert report.common_ancestor_hash is None


# ============================================================================
# propose_merge tests
# ============================================================================


def test_propose_merge_supermajority_agreement() -> None:
    """2 of 3 peers agree on a head_hash -> prefer_supermajority strategy."""
    lineages = [
        ClaimLineage(
            claim_id="claim_123",
            peer_did="peer_a",
            head_hash="hash_4",
            head_timestamp="2026-04-22T12:00:00Z",
            chain_hashes=["hash_1", "hash_2", "hash_3", "hash_4"],
        ),
        ClaimLineage(
            claim_id="claim_123",
            peer_did="peer_b",
            head_hash="hash_4",
            head_timestamp="2026-04-22T12:00:00Z",
            chain_hashes=["hash_1", "hash_2", "hash_3", "hash_4"],
        ),
        ClaimLineage(
            claim_id="claim_123",
            peer_did="peer_c",
            head_hash="hash_3b",
            head_timestamp="2026-04-22T11:50:00Z",
            chain_hashes=["hash_1", "hash_2", "hash_3b"],
        ),
    ]
    report = detect_divergence(lineages)
    proposal = propose_merge(report, lineages, supermajority=0.66)
    assert proposal.strategy == "prefer_supermajority"
    assert proposal.winner_head_hash == "hash_4"
    assert proposal.winner_peer_did in ["peer_a", "peer_b"]
    assert "peer_c" in proposal.losers
    assert len(proposal.losers) == 1


def test_propose_merge_prefer_latest() -> None:
    """No supermajority, but latest timestamp wins."""
    lineages = [
        ClaimLineage(
            claim_id="claim_123",
            peer_did="peer_a",
            head_hash="hash_4a",
            head_timestamp="2026-04-22T12:00:00Z",
            chain_hashes=["hash_1", "hash_2", "hash_4a"],
        ),
        ClaimLineage(
            claim_id="claim_123",
            peer_did="peer_b",
            head_hash="hash_4b",
            head_timestamp="2026-04-22T12:05:00Z",
            chain_hashes=["hash_1", "hash_2", "hash_4b"],
        ),
    ]
    report = detect_divergence(lineages)
    proposal = propose_merge(report, lineages, supermajority=0.66)
    assert proposal.strategy == "prefer_latest"
    assert proposal.winner_head_hash == "hash_4b"
    assert proposal.winner_peer_did == "peer_b"
    assert proposal.losers == ["peer_a"]


def test_propose_merge_manual_review_all_timestamps_tied() -> None:
    """All peers have same timestamp -> manual_review strategy."""
    lineages = [
        ClaimLineage(
            claim_id="claim_123",
            peer_did="peer_a",
            head_hash="hash_4a",
            head_timestamp="2026-04-22T12:00:00Z",
            chain_hashes=["hash_1", "hash_2", "hash_4a"],
        ),
        ClaimLineage(
            claim_id="claim_123",
            peer_did="peer_b",
            head_hash="hash_4b",
            head_timestamp="2026-04-22T12:00:00Z",
            chain_hashes=["hash_1", "hash_2", "hash_4b"],
        ),
    ]
    report = detect_divergence(lineages)
    proposal = propose_merge(report, lineages, supermajority=0.66)
    assert proposal.strategy == "manual_review"
    assert proposal.winner_head_hash is None
    assert proposal.winner_peer_did is None
    assert proposal.losers == []


def test_propose_merge_even_split() -> None:
    """Even 2-2 split with no supermajority -> prefer_latest or manual_review."""
    lineages = [
        ClaimLineage(
            claim_id="claim_123",
            peer_did="peer_a",
            head_hash="hash_4a",
            head_timestamp="2026-04-22T12:00:00Z",
            chain_hashes=["hash_1", "hash_2", "hash_4a"],
        ),
        ClaimLineage(
            claim_id="claim_123",
            peer_did="peer_b",
            head_hash="hash_4a",
            head_timestamp="2026-04-22T12:00:00Z",
            chain_hashes=["hash_1", "hash_2", "hash_4a"],
        ),
        ClaimLineage(
            claim_id="claim_123",
            peer_did="peer_c",
            head_hash="hash_4b",
            head_timestamp="2026-04-22T12:00:00Z",
            chain_hashes=["hash_1", "hash_2", "hash_4b"],
        ),
        ClaimLineage(
            claim_id="claim_123",
            peer_did="peer_d",
            head_hash="hash_4b",
            head_timestamp="2026-04-22T12:00:00Z",
            chain_hashes=["hash_1", "hash_2", "hash_4b"],
        ),
    ]
    report = detect_divergence(lineages)
    # 2/4 is exactly 50%, below 66% supermajority
    proposal = propose_merge(report, lineages, supermajority=0.66)
    # No supermajority, all timestamps tied -> manual_review
    assert proposal.strategy == "manual_review"


def test_propose_merge_three_way_split_no_majority() -> None:
    """Three-way split, no supermajority, latest timestamp wins."""
    lineages = [
        ClaimLineage(
            claim_id="claim_123",
            peer_did="peer_a",
            head_hash="hash_4a",
            head_timestamp="2026-04-22T12:00:00Z",
            chain_hashes=["hash_1", "hash_2", "hash_4a"],
        ),
        ClaimLineage(
            claim_id="claim_123",
            peer_did="peer_b",
            head_hash="hash_4b",
            head_timestamp="2026-04-22T12:05:00Z",
            chain_hashes=["hash_1", "hash_2", "hash_4b"],
        ),
        ClaimLineage(
            claim_id="claim_123",
            peer_did="peer_c",
            head_hash="hash_4c",
            head_timestamp="2026-04-22T12:01:00Z",
            chain_hashes=["hash_1", "hash_2", "hash_4c"],
        ),
    ]
    report = detect_divergence(lineages)
    proposal = propose_merge(report, lineages, supermajority=0.66)
    # No peer has 66% agreement, but peer_b has latest timestamp
    assert proposal.strategy == "prefer_latest"
    assert proposal.winner_head_hash == "hash_4b"
    assert proposal.winner_peer_did == "peer_b"


def test_propose_merge_three_way_tied_timestamps() -> None:
    """Three-way split with all timestamps tied -> manual_review."""
    lineages = [
        ClaimLineage(
            claim_id="claim_123",
            peer_did="peer_a",
            head_hash="hash_4a",
            head_timestamp="2026-04-22T12:00:00Z",
            chain_hashes=["hash_1", "hash_2", "hash_4a"],
        ),
        ClaimLineage(
            claim_id="claim_123",
            peer_did="peer_b",
            head_hash="hash_4b",
            head_timestamp="2026-04-22T12:00:00Z",
            chain_hashes=["hash_1", "hash_2", "hash_4b"],
        ),
        ClaimLineage(
            claim_id="claim_123",
            peer_did="peer_c",
            head_hash="hash_4c",
            head_timestamp="2026-04-22T12:00:00Z",
            chain_hashes=["hash_1", "hash_2", "hash_4c"],
        ),
    ]
    report = detect_divergence(lineages)
    proposal = propose_merge(report, lineages, supermajority=0.66)
    # No supermajority, all timestamps tied
    assert proposal.strategy == "manual_review"
    assert proposal.winner_head_hash is None


def test_propose_merge_empty_lineages() -> None:
    """Empty lineages list -> manual_review with no winner."""
    report = DivergenceReport(
        claim_id="claim_123",
        divergent=False,
        common_ancestor_hash=None,
        branches={},
        branch_leaders={},
    )
    proposal = propose_merge(report, [])
    assert proposal.strategy == "manual_review"
    assert proposal.winner_head_hash is None
    assert proposal.winner_peer_did is None


def test_propose_merge_losers_excludes_winner() -> None:
    """Losers list never includes the winner."""
    lineages = [
        ClaimLineage(
            claim_id="claim_123",
            peer_did="peer_a",
            head_hash="hash_4",
            head_timestamp="2026-04-22T12:00:00Z",
            chain_hashes=["hash_1", "hash_2", "hash_3", "hash_4"],
        ),
        ClaimLineage(
            claim_id="claim_123",
            peer_did="peer_b",
            head_hash="hash_3b",
            head_timestamp="2026-04-22T11:50:00Z",
            chain_hashes=["hash_1", "hash_2", "hash_3b"],
        ),
    ]
    report = detect_divergence(lineages)
    proposal = propose_merge(report, lineages, supermajority=0.5)
    # peer_a has 50% agreement, meets 0.5 supermajority
    if proposal.strategy == "prefer_supermajority":
        assert proposal.winner_peer_did == "peer_a"
        assert "peer_a" not in proposal.losers
        assert "peer_b" in proposal.losers


def test_propose_merge_consult_lineages_for_timestamps() -> None:
    """propose_merge uses timestamps from lineages, not report."""
    lineages = [
        ClaimLineage(
            claim_id="claim_123",
            peer_did="peer_a",
            head_hash="hash_a",
            head_timestamp="2026-04-22T10:00:00Z",
            chain_hashes=["hash_a"],
        ),
        ClaimLineage(
            claim_id="claim_123",
            peer_did="peer_b",
            head_hash="hash_b",
            head_timestamp="2026-04-22T11:00:00Z",
            chain_hashes=["hash_b"],
        ),
    ]
    report = detect_divergence(lineages)
    proposal = propose_merge(report, lineages)
    # peer_b has later timestamp
    assert proposal.winner_head_hash == "hash_b"
    assert proposal.winner_peer_did == "peer_b"
    assert proposal.strategy == "prefer_latest"
