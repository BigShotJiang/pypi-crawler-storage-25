"""Tests for network partition recovery and verdict catch-up."""
from __future__ import annotations

from datetime import datetime

import httpx
import pytest
import respx

from gtv.federation.partition_recovery import (
    CatchUpReport,
    InMemoryVerdictLog,
    PartitionRecovery,
    VerdictLogEntry,
    make_verdicts_since_handler,
)


class TestInMemoryVerdictLog:
    """Tests for InMemoryVerdictLog."""

    def test_inmemory_log_monotonic(self) -> None:
        """Log should reject regressions in sequence number."""
        log = InMemoryVerdictLog()

        entry1 = VerdictLogEntry(
            seq=1,
            verdict_id="v1",
            tenant_id="tenant1",
            emitted_at=datetime.fromisoformat("2026-04-22T10:00:00"),
            peer_did="did:web:peer1",
        )
        log.append(entry1)
        assert log.latest_seq() == 1

        # Attempt to add entry with seq <= latest should raise
        entry2_bad = VerdictLogEntry(
            seq=1,  # Same as latest
            verdict_id="v2",
            tenant_id="tenant1",
            emitted_at=datetime.fromisoformat("2026-04-22T10:01:00"),
            peer_did="did:web:peer1",
        )
        with pytest.raises(ValueError, match="Sequence regression"):
            log.append(entry2_bad)

        # Regression (lower seq) should also raise
        entry3_bad = VerdictLogEntry(
            seq=0,
            verdict_id="v3",
            tenant_id="tenant1",
            emitted_at=datetime.fromisoformat("2026-04-22T10:02:00"),
            peer_did="did:web:peer1",
        )
        with pytest.raises(ValueError, match="Sequence regression"):
            log.append(entry3_bad)

    def test_inmemory_log_accepts_strictly_increasing(self) -> None:
        """Log should accept strictly increasing sequence numbers."""
        log = InMemoryVerdictLog()

        for i in range(1, 6):
            entry = VerdictLogEntry(
                seq=i,
                verdict_id=f"v{i}",
                tenant_id="tenant1",
                emitted_at=datetime.fromisoformat("2026-04-22T10:00:00"),
                peer_did="did:web:peer1",
            )
            log.append(entry)

        assert log.latest_seq() == 5

    def test_inmemory_log_since_returns_correct_range(self) -> None:
        """Log.since(seq) should return entries with seq > given value."""
        log = InMemoryVerdictLog()

        for i in range(1, 11):
            entry = VerdictLogEntry(
                seq=i,
                verdict_id=f"v{i}",
                tenant_id="tenant1",
                emitted_at=datetime.fromisoformat("2026-04-22T10:00:00"),
                peer_did="did:web:peer1",
            )
            log.append(entry)

        # Get entries with seq > 5
        result = log.since(5)
        assert len(result) == 5
        assert result[0].seq == 6
        assert result[-1].seq == 10

    def test_inmemory_log_since_respects_limit(self) -> None:
        """Log.since(seq, limit) should respect the limit."""
        log = InMemoryVerdictLog()

        for i in range(1, 101):
            entry = VerdictLogEntry(
                seq=i,
                verdict_id=f"v{i}",
                tenant_id="tenant1",
                emitted_at=datetime.fromisoformat("2026-04-22T10:00:00"),
                peer_did="did:web:peer1",
            )
            log.append(entry)

        # Fetch with limit
        result = log.since(0, limit=10)
        assert len(result) == 10
        assert result[0].seq == 1
        assert result[-1].seq == 10

        # Fetch with limit from middle
        result = log.since(50, limit=20)
        assert len(result) == 20
        assert result[0].seq == 51
        assert result[-1].seq == 70

    def test_inmemory_log_since_empty_log_returns_zero_seq(self) -> None:
        """Calling latest_seq on empty log should return 0."""
        log = InMemoryVerdictLog()
        assert log.latest_seq() == 0

        # since(0) on empty log should return empty
        result = log.since(0)
        assert result == []


class TestCatchUp:
    """Tests for PartitionRecovery catch-up logic."""

    @pytest.mark.asyncio
    async def test_catch_up_happy_path(self) -> None:
        """Single peer ahead by 50 entries; all should be applied."""
        local_log = InMemoryVerdictLog()
        peers = [
            {
                "did": "did:web:peer1",
                "endpoint_url": "https://peer1.example",
            }
        ]

        # Pre-populate local log with 50 entries
        for i in range(1, 51):
            entry = VerdictLogEntry(
                seq=i,
                verdict_id=f"v{i}",
                tenant_id="tenant1",
                emitted_at=datetime.fromisoformat("2026-04-22T10:00:00"),
                peer_did="did:web:peer1",
            )
            local_log.append(entry)

        # Peer has 100 entries total (1-100)
        peer_entries = [
            {
                "seq": i,
                "verdict_id": f"v{i}",
                "tenant_id": "tenant1",
                "emitted_at": "2026-04-22T10:00:00",
                "peer_did": "did:web:peer1",
            }
            for i in range(1, 101)
        ]

        with respx.mock:
            respx.get("https://peer1.example/federation/verdicts_since").mock(
                return_value=httpx.Response(200, json={"entries": peer_entries})
            )

            recovery = PartitionRecovery(local_log, peers=peers)
            report = await recovery.catch_up()

            assert report.peers_reached == 1
            assert report.peers_unreachable == 0
            assert report.entries_applied == 50  # seq 51-100
            assert report.conflicts == []
            assert report.new_latest_seq == 100

    @pytest.mark.asyncio
    async def test_catch_up_multiple_peers_dedup(self) -> None:
        """Two peers with overlapping entries; no duplicates applied."""
        local_log = InMemoryVerdictLog()
        peers = [
            {"did": "did:web:peer1", "endpoint_url": "https://peer1.example"},
            {"did": "did:web:peer2", "endpoint_url": "https://peer2.example"},
        ]

        # Peer 1 has verdicts 1-50
        peer1_entries = [
            {
                "seq": i,
                "verdict_id": f"v{i}",
                "tenant_id": "tenant1",
                "emitted_at": "2026-04-22T10:00:00",
                "peer_did": "did:web:peer1",
            }
            for i in range(1, 51)
        ]

        # Peer 2 has verdicts 25-75 (overlapping with peer1)
        peer2_entries = [
            {
                "seq": i,
                "verdict_id": f"v{i}",
                "tenant_id": "tenant1",
                "emitted_at": "2026-04-22T10:00:00",
                "peer_did": "did:web:peer2",
            }
            for i in range(25, 76)
        ]

        with respx.mock:
            respx.get("https://peer1.example/federation/verdicts_since").mock(
                return_value=httpx.Response(200, json={"entries": peer1_entries})
            )
            respx.get("https://peer2.example/federation/verdicts_since").mock(
                return_value=httpx.Response(200, json={"entries": peer2_entries})
            )

            recovery = PartitionRecovery(local_log, peers=peers)
            report = await recovery.catch_up()

            # Should apply 75 unique verdicts (1-75)
            assert report.peers_reached == 2
            assert report.peers_unreachable == 0
            assert report.entries_applied == 75
            # Verdicts 25-50 appear in both peers; mark as conflicts
            assert len(report.conflicts) == 26  # v25 through v50
            assert report.new_latest_seq == 75

    @pytest.mark.asyncio
    async def test_catch_up_unreachable_peer_skipped(self) -> None:
        """One unreachable peer (500 error) and one good peer; report reflects both."""
        local_log = InMemoryVerdictLog()
        peers = [
            {"did": "did:web:peer1", "endpoint_url": "https://peer1.example"},
            {"did": "did:web:peer2", "endpoint_url": "https://peer2.example"},
        ]

        # Peer 2 has good data
        peer2_entries = [
            {
                "seq": i,
                "verdict_id": f"v{i}",
                "tenant_id": "tenant1",
                "emitted_at": "2026-04-22T10:00:00",
                "peer_did": "did:web:peer2",
            }
            for i in range(1, 26)
        ]

        with respx.mock:
            # Peer 1 returns 500
            respx.get("https://peer1.example/federation/verdicts_since").mock(
                return_value=httpx.Response(500, text="Internal Server Error")
            )
            # Peer 2 works fine
            respx.get("https://peer2.example/federation/verdicts_since").mock(
                return_value=httpx.Response(200, json={"entries": peer2_entries})
            )

            recovery = PartitionRecovery(local_log, peers=peers)
            report = await recovery.catch_up()

            assert report.peers_reached == 1
            assert report.peers_unreachable == 1
            assert report.entries_applied == 25
            assert report.new_latest_seq == 25

    @pytest.mark.asyncio
    async def test_catch_up_paginates(self) -> None:
        """Peer has 1200 entries, batch_size=500; should make 3 calls."""
        local_log = InMemoryVerdictLog()
        peers = [
            {"did": "did:web:peer1", "endpoint_url": "https://peer1.example"},
        ]

        # Generate 1200 entries split across 3 batches
        batch1 = [
            {
                "seq": i,
                "verdict_id": f"v{i}",
                "tenant_id": "tenant1",
                "emitted_at": "2026-04-22T10:00:00",
                "peer_did": "did:web:peer1",
            }
            for i in range(1, 501)
        ]
        batch2 = [
            {
                "seq": i,
                "verdict_id": f"v{i}",
                "tenant_id": "tenant1",
                "emitted_at": "2026-04-22T10:00:00",
                "peer_did": "did:web:peer1",
            }
            for i in range(501, 1001)
        ]
        batch3 = [
            {
                "seq": i,
                "verdict_id": f"v{i}",
                "tenant_id": "tenant1",
                "emitted_at": "2026-04-22T10:00:00",
                "peer_did": "did:web:peer1",
            }
            for i in range(1001, 1201)
        ]

        call_count = 0

        def batch_handler(request):
            nonlocal call_count
            call_count += 1
            seq_param = int(request.url.params.get("seq", 0))

            # First call: seq=0, return batch1
            if seq_param == 0:
                return httpx.Response(200, json={"entries": batch1})
            # Second call: seq=500, return batch2
            elif seq_param == 500:
                return httpx.Response(200, json={"entries": batch2})
            # Third call: seq=1000, return batch3
            elif seq_param == 1000:
                return httpx.Response(200, json={"entries": batch3})
            else:
                return httpx.Response(200, json={"entries": []})

        with respx.mock:
            respx.get("https://peer1.example/federation/verdicts_since").mock(
                side_effect=batch_handler
            )

            recovery = PartitionRecovery(local_log, peers=peers, batch_size=500)
            report = await recovery.catch_up()

            assert call_count == 3
            assert report.entries_applied == 1200
            assert report.new_latest_seq == 1200

    @pytest.mark.asyncio
    async def test_catch_up_empty_log_handles_zero_seq(self) -> None:
        """Empty local log (seq=0) should fetch from seq=0."""
        local_log = InMemoryVerdictLog()
        assert local_log.latest_seq() == 0

        peers = [
            {"did": "did:web:peer1", "endpoint_url": "https://peer1.example"},
        ]

        entries = [
            {
                "seq": i,
                "verdict_id": f"v{i}",
                "tenant_id": "tenant1",
                "emitted_at": "2026-04-22T10:00:00",
                "peer_did": "did:web:peer1",
            }
            for i in range(1, 11)
        ]

        with respx.mock:
            respx.get("https://peer1.example/federation/verdicts_since").mock(
                return_value=httpx.Response(200, json={"entries": entries})
            )

            recovery = PartitionRecovery(local_log, peers=peers)
            report = await recovery.catch_up()

            assert report.entries_applied == 10
            assert report.new_latest_seq == 10

    @pytest.mark.asyncio
    async def test_catch_up_no_peers_returns_empty_report(self) -> None:
        """Empty peer list should return minimal report."""
        local_log = InMemoryVerdictLog()

        recovery = PartitionRecovery(local_log, peers=[])
        report = await recovery.catch_up()

        assert report.peers_reached == 0
        assert report.peers_unreachable == 0
        assert report.entries_applied == 0
        assert report.conflicts == []
        assert report.new_latest_seq == 0

    @pytest.mark.asyncio
    async def test_catch_up_handles_malformed_peer_response(self) -> None:
        """Malformed response (missing 'entries' key) should be logged and skipped."""
        local_log = InMemoryVerdictLog()
        peers = [
            {"did": "did:web:peer1", "endpoint_url": "https://peer1.example"},
        ]

        with respx.mock:
            # Return JSON missing 'entries' key
            respx.get("https://peer1.example/federation/verdicts_since").mock(
                return_value=httpx.Response(200, json={"data": []})
            )

            recovery = PartitionRecovery(local_log, peers=peers)
            report = await recovery.catch_up()

            # Should be marked as unreachable due to malformed response
            assert report.peers_unreachable == 1
            assert report.entries_applied == 0


class TestMakeVerdictsSinceHandler:
    """Tests for the FastAPI handler factory."""

    def test_handler_returns_entries_dict(self) -> None:
        """Handler should return dict with 'entries' key."""
        log = InMemoryVerdictLog()

        for i in range(1, 6):
            entry = VerdictLogEntry(
                seq=i,
                verdict_id=f"v{i}",
                tenant_id="tenant1",
                emitted_at=datetime.fromisoformat("2026-04-22T10:00:00"),
                peer_did="did:web:peer1",
            )
            log.append(entry)

        handler = make_verdicts_since_handler(log)

        # Call handler with seq=0, limit=10
        import asyncio

        result = asyncio.run(handler(seq=0, limit=10))
        assert isinstance(result, dict)
        assert "entries" in result
        assert len(result["entries"]) == 5  # Only 5 entries exist

    def test_handler_respects_seq_parameter(self) -> None:
        """Handler should only return entries with seq > given parameter."""
        log = InMemoryVerdictLog()

        for i in range(1, 11):
            entry = VerdictLogEntry(
                seq=i,
                verdict_id=f"v{i}",
                tenant_id="tenant1",
                emitted_at=datetime.fromisoformat("2026-04-22T10:00:00"),
                peer_did="did:web:peer1",
            )
            log.append(entry)

        handler = make_verdicts_since_handler(log)

        import asyncio

        result = asyncio.run(handler(seq=5, limit=100))
        assert len(result["entries"]) == 5
        assert result["entries"][0]["seq"] == 6
        assert result["entries"][-1]["seq"] == 10

    def test_handler_respects_limit_parameter(self) -> None:
        """Handler should respect the limit parameter."""
        log = InMemoryVerdictLog()

        for i in range(1, 101):
            entry = VerdictLogEntry(
                seq=i,
                verdict_id=f"v{i}",
                tenant_id="tenant1",
                emitted_at=datetime.fromisoformat("2026-04-22T10:00:00"),
                peer_did="did:web:peer1",
            )
            log.append(entry)

        handler = make_verdicts_since_handler(log)

        import asyncio

        result = asyncio.run(handler(seq=0, limit=25))
        assert len(result["entries"]) == 25

    def test_handler_entry_serialization(self) -> None:
        """Handler should serialize entries with all required fields."""
        log = InMemoryVerdictLog()

        entry = VerdictLogEntry(
            seq=1,
            verdict_id="v1",
            tenant_id="tenant1",
            emitted_at=datetime.fromisoformat("2026-04-22T10:00:00"),
            peer_did="did:web:peer1",
        )
        log.append(entry)

        handler = make_verdicts_since_handler(log)

        import asyncio

        result = asyncio.run(handler(seq=0, limit=10))
        entries = result["entries"]
        assert len(entries) == 1
        entry_dict = entries[0]

        assert entry_dict["seq"] == 1
        assert entry_dict["verdict_id"] == "v1"
        assert entry_dict["tenant_id"] == "tenant1"
        assert entry_dict["emitted_at"] == "2026-04-22T10:00:00"
        assert entry_dict["peer_did"] == "did:web:peer1"


class TestCatchUpReportDataclass:
    """Tests for CatchUpReport dataclass."""

    def test_report_default_values(self) -> None:
        """CatchUpReport should have sensible defaults."""
        report = CatchUpReport()
        assert report.peers_reached == 0
        assert report.peers_unreachable == 0
        assert report.entries_applied == 0
        assert report.conflicts == []
        assert report.new_latest_seq == 0

    def test_report_custom_values(self) -> None:
        """CatchUpReport should accept custom values."""
        report = CatchUpReport(
            peers_reached=5,
            peers_unreachable=2,
            entries_applied=100,
            conflicts=["v1", "v2"],
            new_latest_seq=100,
        )
        assert report.peers_reached == 5
        assert report.peers_unreachable == 2
        assert report.entries_applied == 100
        assert report.conflicts == ["v1", "v2"]
        assert report.new_latest_seq == 100
