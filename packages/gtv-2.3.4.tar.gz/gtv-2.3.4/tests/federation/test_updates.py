"""Tests for signed registry updates."""
from __future__ import annotations

import json
import tempfile
from pathlib import Path

import pytest
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ed25519

from gtv.federation.updates import (
    RegistryUpdate,
    UpdateLog,
    build_registry_update,
    verify_registry_update,
)


@pytest.fixture
def ed25519_keypair(tmp_path: Path) -> tuple[Path, str]:
    """Generate an Ed25519 keypair and save to PEM.

    Returns:
        (path_to_pem, actor_did)
    """
    private_key = ed25519.Ed25519PrivateKey.generate()
    pem_bytes = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )

    pem_path = tmp_path / "test_key.pem"
    pem_path.write_bytes(pem_bytes)

    # Derive actor_did for verification
    from gtv.sign.byok import _derive_did_key_from_public_key

    public_key_obj = private_key.public_key()
    raw_public_key_bytes = public_key_obj.public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    actor_did = _derive_did_key_from_public_key("Ed25519", raw_public_key_bytes)

    return pem_path, actor_did


def test_build_registry_update_add(ed25519_keypair: tuple[Path, str]) -> None:
    """Test building a registry update for 'add' operation."""
    pem_path, actor_did = ed25519_keypair
    issuer_did = "did:key:z6MkePhZ7zuWS1PrS6z6SAUFhqkwvczrxqSomx7mW8yCZhR8"

    update = build_registry_update(
        operation="add",
        issuer_did=issuer_did,
        old_tier=None,
        new_tier="TIER_1",
        actor_private_key_pem_path=pem_path,
    )

    assert update.operation == "add"
    assert update.issuer_did == issuer_did
    assert update.old_tier is None
    assert update.new_tier == "TIER_1"
    assert update.actor_did == actor_did
    assert update.signature.startswith("byok-ed25519:")
    assert len(update.canonical_hash) == 64
    assert all(c in "0123456789abcdef" for c in update.canonical_hash)


def test_build_registry_update_update_tier(
    ed25519_keypair: tuple[Path, str],
) -> None:
    """Test building a registry update for 'update_tier' operation."""
    pem_path, actor_did = ed25519_keypair
    issuer_did = "did:key:z6MkePhZ7zuWS1PrS6z6SAUFhqkwvczrxqSomx7mW8yCZhR8"

    update = build_registry_update(
        operation="update_tier",
        issuer_did=issuer_did,
        old_tier="TIER_2",
        new_tier="TIER_1",
        actor_private_key_pem_path=pem_path,
    )

    assert update.operation == "update_tier"
    assert update.old_tier == "TIER_2"
    assert update.new_tier == "TIER_1"
    assert update.actor_did == actor_did


def test_build_registry_update_revoke(ed25519_keypair: tuple[Path, str]) -> None:
    """Test building a registry update for 'revoke' operation."""
    pem_path, _ = ed25519_keypair
    issuer_did = "did:key:z6MkePhZ7zuWS1PrS6z6SAUFhqkwvczrxqSomx7mW8yCZhR8"

    update = build_registry_update(
        operation="revoke",
        issuer_did=issuer_did,
        old_tier="TIER_1",
        new_tier=None,
        actor_private_key_pem_path=pem_path,
    )

    assert update.operation == "revoke"
    assert update.old_tier == "TIER_1"
    assert update.new_tier is None


def test_verify_registry_update_valid(ed25519_keypair: tuple[Path, str]) -> None:
    """Test verifying a valid registry update."""
    pem_path, _ = ed25519_keypair
    issuer_did = "did:key:z6MkePhZ7zuWS1PrS6z6SAUFhqkwvczrxqSomx7mW8yCZhR8"

    update = build_registry_update(
        operation="add",
        issuer_did=issuer_did,
        old_tier=None,
        new_tier="TIER_1",
        actor_private_key_pem_path=pem_path,
    )

    assert verify_registry_update(update) is True


def test_verify_registry_update_tampered_operation(
    ed25519_keypair: tuple[Path, str],
) -> None:
    """Test that verification fails when operation is tampered."""
    pem_path, _ = ed25519_keypair
    issuer_did = "did:key:z6MkePhZ7zuWS1PrS6z6SAUFhqkwvczrxqSomx7mW8yCZhR8"

    update = build_registry_update(
        operation="add",
        issuer_did=issuer_did,
        old_tier=None,
        new_tier="TIER_1",
        actor_private_key_pem_path=pem_path,
    )

    # Tamper with operation (create a new instance with modified operation)
    tampered = update.model_copy(update={"operation": "revoke"})

    assert verify_registry_update(tampered) is False


def test_verify_registry_update_tampered_issuer_did(
    ed25519_keypair: tuple[Path, str],
) -> None:
    """Test that verification fails when issuer_did is tampered."""
    pem_path, _ = ed25519_keypair
    issuer_did = "did:key:z6MkePhZ7zuWS1PrS6z6SAUFhqkwvczrxqSomx7mW8yCZhR8"

    update = build_registry_update(
        operation="add",
        issuer_did=issuer_did,
        old_tier=None,
        new_tier="TIER_1",
        actor_private_key_pem_path=pem_path,
    )

    # Tamper with issuer_did
    tampered = update.model_copy(
        update={"issuer_did": "did:key:z6MkePhZ7zuWS1PrS6z6SAUFhqkwvczrxqSomx7mW8yCZhR9"}
    )

    assert verify_registry_update(tampered) is False


def test_verify_registry_update_tampered_new_tier(
    ed25519_keypair: tuple[Path, str],
) -> None:
    """Test that verification fails when new_tier is tampered."""
    pem_path, _ = ed25519_keypair
    issuer_did = "did:key:z6MkePhZ7zuWS1PrS6z6SAUFhqkwvczrxqSomx7mW8yCZhR8"

    update = build_registry_update(
        operation="add",
        issuer_did=issuer_did,
        old_tier=None,
        new_tier="TIER_1",
        actor_private_key_pem_path=pem_path,
    )

    # Tamper with new_tier
    tampered = update.model_copy(update={"new_tier": "TIER_3"})

    assert verify_registry_update(tampered) is False


def test_verify_registry_update_tampered_actor_did(
    ed25519_keypair: tuple[Path, str],
) -> None:
    """Test that verification fails when actor_did is tampered."""
    pem_path, _ = ed25519_keypair
    issuer_did = "did:key:z6MkePhZ7zuWS1PrS6z6SAUFhqkwvczrxqSomx7mW8yCZhR8"

    update = build_registry_update(
        operation="add",
        issuer_did=issuer_did,
        old_tier=None,
        new_tier="TIER_1",
        actor_private_key_pem_path=pem_path,
    )

    # Tamper with actor_did (mismatched key)
    tampered = update.model_copy(
        update={"actor_did": "did:key:z6MkePhZ7zuWS1PrS6z6SAUFhqkwvczrxqSomx7mW8yCZhR9"}
    )

    assert verify_registry_update(tampered) is False


def test_update_log_append_and_verify(
    tmp_path: Path, ed25519_keypair: tuple[Path, str]
) -> None:
    """Test UpdateLog append and verify_all with mixed valid/invalid entries."""
    pem_path, _ = ed25519_keypair
    log_path = tmp_path / "test_log.jsonl"
    issuer_did = "did:key:z6MkePhZ7zuWS1PrS6z6SAUFhqkwvczrxqSomx7mW8yCZhR8"

    log = UpdateLog(log_path)

    # Create 3 valid updates
    valid_updates = [
        build_registry_update(
            operation="add",
            issuer_did=f"{issuer_did}{i}",
            old_tier=None,
            new_tier="TIER_1",
            actor_private_key_pem_path=pem_path,
        )
        for i in range(3)
    ]

    for update in valid_updates:
        log.append(update)

    # Create 1 tampered update and append
    tampered_update = valid_updates[0].model_copy(update={"operation": "revoke"})
    log.append(tampered_update)

    # Verify: should have 3 valid, 1 invalid
    valid_count, invalid_count = log.verify_all()
    assert valid_count == 3
    assert invalid_count == 1


def test_update_log_verify_all_empty() -> None:
    """Test verify_all on non-existent log returns (0, 0)."""
    with tempfile.TemporaryDirectory() as tmpdir:
        log_path = Path(tmpdir) / "nonexistent.jsonl"
        log = UpdateLog(log_path)

        valid_count, invalid_count = log.verify_all()
        assert valid_count == 0
        assert invalid_count == 0


def test_canonical_hash_format(ed25519_keypair: tuple[Path, str]) -> None:
    """Test that canonical_hash is 64-char lowercase hex."""
    pem_path, _ = ed25519_keypair
    issuer_did = "did:key:z6MkePhZ7zuWS1PrS6z6SAUFhqkwvczrxqSomx7mW8yCZhR8"

    update = build_registry_update(
        operation="add",
        issuer_did=issuer_did,
        old_tier=None,
        new_tier="TIER_1",
        actor_private_key_pem_path=pem_path,
    )

    assert len(update.canonical_hash) == 64
    assert update.canonical_hash == update.canonical_hash.lower()
    assert all(c in "0123456789abcdef" for c in update.canonical_hash)


def test_registry_update_frozen(ed25519_keypair: tuple[Path, str]) -> None:
    """Test that RegistryUpdate is frozen (immutable)."""
    from pydantic import ValidationError

    pem_path, _ = ed25519_keypair
    issuer_did = "did:key:z6MkePhZ7zuWS1PrS6z6SAUFhqkwvczrxqSomx7mW8yCZhR8"

    update = build_registry_update(
        operation="add",
        issuer_did=issuer_did,
        old_tier=None,
        new_tier="TIER_1",
        actor_private_key_pem_path=pem_path,
    )

    with pytest.raises(ValidationError):
        update.operation = "revoke"  # type: ignore


def test_registry_update_json_serialization(ed25519_keypair: tuple[Path, str]) -> None:
    """Test RegistryUpdate can be serialized and deserialized as JSON."""
    pem_path, _ = ed25519_keypair
    issuer_did = "did:key:z6MkePhZ7zuWS1PrS6z6SAUFhqkwvczrxqSomx7mW8yCZhR8"

    update = build_registry_update(
        operation="add",
        issuer_did=issuer_did,
        old_tier=None,
        new_tier="TIER_1",
        actor_private_key_pem_path=pem_path,
    )

    # Serialize to JSON
    json_str = update.model_dump_json()
    json_obj = json.loads(json_str)

    # Verify all fields are present
    assert "update_id" in json_obj
    assert "operation" in json_obj
    assert "issuer_did" in json_obj
    assert "old_tier" in json_obj
    assert "new_tier" in json_obj
    assert "actor_did" in json_obj
    assert "issued_at" in json_obj
    assert "signature" in json_obj
    assert "canonical_hash" in json_obj

    # Deserialize and verify
    deserialized = RegistryUpdate.model_validate_json(json_str)
    assert verify_registry_update(deserialized) is True
