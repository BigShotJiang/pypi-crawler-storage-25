"""Tests for signed domain bundles (W53)."""
from __future__ import annotations

import time
from datetime import UTC, datetime, timedelta

import pytest
from cryptography.hazmat.primitives.asymmetric import ed25519

from gtv.federation.domain_bundle import (
    DomainBundle,
    InvalidBundleError,
    sign_bundle,
    verify_bundle,
)


@pytest.fixture
def ed25519_keypair() -> tuple[bytes, bytes]:
    """Generate a test Ed25519 keypair."""
    private_key_obj = ed25519.Ed25519PrivateKey.generate()
    private_key = private_key_obj.private_bytes_raw()
    public_key = private_key_obj.public_key().public_bytes_raw()
    return private_key, public_key


@pytest.fixture
def test_bundle() -> DomainBundle:
    """Create a test domain bundle."""
    return DomainBundle(
        issuer_did="did:key:z1234",
        domain_map={
            "physics": ["did:key:zpeer1", "did:key:zpeer2"],
            "cs": ["did:key:zpeer3"],
            "biomed": ["did:key:zpeer1", "did:key:zpeer4"],
        },
        min_tier_per_domain={
            "physics": "TIER_1",
            "cs": "TIER_2",
            "biomed": "TIER_1",
        },
        issued_at=datetime.now(UTC).isoformat(),
        ttl_s=3600,
    )


def test_sign_and_verify_roundtrip(test_bundle, ed25519_keypair):
    """Test sign + verify roundtrip."""
    private_key, public_key = ed25519_keypair

    jws = sign_bundle(test_bundle, private_key)
    assert isinstance(jws, str)
    assert jws.count(".") == 2  # header.payload.signature

    # Verify and decode
    decoded = verify_bundle(jws, public_key)
    assert decoded.issuer_did == test_bundle.issuer_did
    assert decoded.domain_map == test_bundle.domain_map
    assert decoded.min_tier_per_domain == test_bundle.min_tier_per_domain
    assert decoded.issued_at == test_bundle.issued_at
    assert decoded.ttl_s == test_bundle.ttl_s


def test_detect_tampered_payload(test_bundle, ed25519_keypair):
    """Test that tampered payload is detected."""
    private_key, public_key = ed25519_keypair

    jws = sign_bundle(test_bundle, private_key)
    # Tamper with the payload (middle part)
    parts = jws.split(".")
    tampered_payload = parts[1][:-5] + "xxxxx"
    tampered_jws = parts[0] + "." + tampered_payload + "." + parts[2]

    with pytest.raises(InvalidBundleError, match="Signature verification failed"):
        verify_bundle(tampered_jws, public_key)


def test_detect_wrong_key(test_bundle, ed25519_keypair):
    """Test that wrong public key is detected."""
    private_key, _public_key = ed25519_keypair

    jws = sign_bundle(test_bundle, private_key)

    # Generate a different keypair
    wrong_key_obj = ed25519.Ed25519PrivateKey.generate()
    wrong_public_key = wrong_key_obj.public_key().public_bytes_raw()

    with pytest.raises(InvalidBundleError, match="Signature verification failed"):
        verify_bundle(jws, wrong_public_key)


def test_expired_bundle_rejected(ed25519_keypair):
    """Test that expired bundle is rejected."""
    private_key, public_key = ed25519_keypair

    # Create a bundle that expired 1 second ago
    past_time = datetime.now(UTC) - timedelta(seconds=2)
    expired_bundle = DomainBundle(
        issuer_did="did:key:z1234",
        domain_map={"physics": ["did:key:zpeer1"]},
        min_tier_per_domain={"physics": "TIER_1"},
        issued_at=past_time.isoformat(),
        ttl_s=1,  # Expired 1 second ago
    )

    jws = sign_bundle(expired_bundle, private_key)
    time.sleep(0.1)  # Ensure time passes

    with pytest.raises(InvalidBundleError, match="expired"):
        verify_bundle(jws, public_key)


def test_malformed_json_rejected(ed25519_keypair):
    """Test that malformed JSON is rejected."""
    _private_key, public_key = ed25519_keypair

    # Create a JWS with invalid JSON payload
    import base64
    header_b64 = base64.urlsafe_b64encode(b'{"alg":"EdDSA"}').rstrip(b"=").decode("ascii")
    bad_payload_b64 = base64.urlsafe_b64encode(b"not valid json").rstrip(b"=").decode("ascii")
    bad_sig_b64 = base64.urlsafe_b64encode(b"fakesig").rstrip(b"=").decode("ascii")
    jws = f"{header_b64}.{bad_payload_b64}.{bad_sig_b64}"

    with pytest.raises(InvalidBundleError, match=r"Signature verification failed|Invalid JSON"):
        verify_bundle(jws, public_key)


def test_domain_map_validation():
    """Test that domain_map and min_tier_per_domain must be consistent."""
    bundle = DomainBundle(
        issuer_did="did:key:z1234",
        domain_map={"physics": ["did:key:zpeer1"]},
        min_tier_per_domain={"physics": "TIER_1", "cs": "TIER_2"},  # cs not in domain_map
        issued_at=datetime.now(UTC).isoformat(),
        ttl_s=3600,
    )

    with pytest.raises(InvalidBundleError, match="not in domain_map"):
        bundle.validate()


def test_invalid_tier_rejected():
    """Test that invalid tier values are rejected."""
    bundle = DomainBundle(
        issuer_did="did:key:z1234",
        domain_map={"physics": ["did:key:zpeer1"]},
        min_tier_per_domain={"physics": "TIER_X"},  # Invalid tier
        issued_at=datetime.now(UTC).isoformat(),
        ttl_s=3600,
    )

    with pytest.raises(InvalidBundleError, match="Invalid tier"):
        bundle.validate()


def test_invalid_private_key():
    """Test that invalid private key is rejected."""
    test_bundle = DomainBundle(
        issuer_did="did:key:z1234",
        domain_map={"physics": ["did:key:zpeer1"]},
        min_tier_per_domain={"physics": "TIER_1"},
        issued_at=datetime.now(UTC).isoformat(),
        ttl_s=3600,
    )

    with pytest.raises(ValueError, match="Invalid Ed25519 private key"):
        sign_bundle(test_bundle, b"invalid_key")


def test_jws_format_validation(ed25519_keypair):
    """Test that malformed JWS format is rejected."""
    _private_key, public_key = ed25519_keypair

    # JWS with wrong number of parts
    with pytest.raises(InvalidBundleError, match="Invalid JWS format"):
        verify_bundle("header.payload", public_key)

    # JWS with empty parts
    with pytest.raises(InvalidBundleError):
        verify_bundle("", public_key)
