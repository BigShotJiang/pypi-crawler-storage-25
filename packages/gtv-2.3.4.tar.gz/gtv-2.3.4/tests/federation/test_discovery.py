"""Tests for DID-based federation peer discovery."""
from __future__ import annotations

import httpx
import pytest
import respx

from gtv.federation.discovery import (
    DiscoveredPeer,
    discover_peers_from_did,
    load_discovery_config_from_env,
    merge_discovered_with_env,
)
from gtv.federation.peer import FederationPeer


@pytest.mark.asyncio
async def test_discover_happy_path() -> None:
    """Happy path: root DID → doc with 2 peers → both discovered."""
    root_did = "did:web:federation.example"
    did_url = "https://federation.example/.well-known/did.json"

    did_doc = {
        "id": root_did,
        "service": [
            {
                "id": "#peer1",
                "type": "GtvFederationPeer",
                "serviceEndpoint": "https://verify1.example.com",
            },
            {
                "id": "#peer2",
                "type": "GtvFederationPeer",
                "serviceEndpoint": "https://verify2.example.com",
            },
        ],
    }

    with respx.mock:
        respx.get(did_url).mock(return_value=httpx.Response(200, json=did_doc))

        peers = await discover_peers_from_did(root_did)

        assert len(peers) == 2
        assert peers[0].did == "#peer1"
        assert peers[0].url == "https://verify1.example.com"
        assert peers[0].api_key is None
        assert peers[0].verified is True

        assert peers[1].did == "#peer2"
        assert peers[1].url == "https://verify2.example.com"
        assert peers[1].api_key is None
        assert peers[1].verified is True


@pytest.mark.asyncio
async def test_discover_malformed_endpoint_skipped() -> None:
    """Peer with malformed serviceEndpoint skipped, not crashed."""
    root_did = "did:web:federation.example"
    did_url = "https://federation.example/.well-known/did.json"

    did_doc = {
        "id": root_did,
        "service": [
            {
                "id": "#peer-good",
                "type": "GtvFederationPeer",
                "serviceEndpoint": "https://verify.example.com",
            },
            {
                "id": "#peer-bad",
                "type": "GtvFederationPeer",
                # Missing serviceEndpoint
            },
            {
                "id": "#peer-bad2",
                "type": "GtvFederationPeer",
                "serviceEndpoint": None,  # Invalid
            },
        ],
    }

    with respx.mock:
        respx.get(did_url).mock(return_value=httpx.Response(200, json=did_doc))

        peers = await discover_peers_from_did(root_did)

        # Only the good peer should be discovered
        assert len(peers) == 1
        assert peers[0].did == "#peer-good"


@pytest.mark.asyncio
async def test_discover_non_federation_type_skipped() -> None:
    """Peer with non-GtvFederationPeer type skipped."""
    root_did = "did:web:federation.example"
    did_url = "https://federation.example/.well-known/did.json"

    did_doc = {
        "id": root_did,
        "service": [
            {
                "id": "#peer1",
                "type": "GtvFederationPeer",
                "serviceEndpoint": "https://verify.example.com",
            },
            {
                "id": "#other-service",
                "type": "OtherServiceType",
                "serviceEndpoint": "https://other.example.com",
            },
            {
                "id": "#peer2",
                "type": "GtvFederationPeer",
                "serviceEndpoint": "https://verify2.example.com",
            },
        ],
    }

    with respx.mock:
        respx.get(did_url).mock(return_value=httpx.Response(200, json=did_doc))

        peers = await discover_peers_from_did(root_did)

        # Only GtvFederationPeer services should be discovered
        assert len(peers) == 2
        dids = {p.did for p in peers}
        assert "#peer1" in dids
        assert "#peer2" in dids
        assert "#other-service" not in dids


@pytest.mark.asyncio
async def test_discover_unresolvable_returns_empty() -> None:
    """Unresolvable root DID returns [] (no exception)."""
    root_did = "did:web:nonexistent.example"
    did_url = "https://nonexistent.example/.well-known/did.json"

    with respx.mock:
        respx.get(did_url).mock(return_value=httpx.Response(404))

        peers = await discover_peers_from_did(root_did)

        assert peers == []


@pytest.mark.asyncio
async def test_discover_endpoint_as_string_and_object() -> None:
    """serviceEndpoint as string vs object both parse correctly."""
    root_did = "did:web:federation.example"
    did_url = "https://federation.example/.well-known/did.json"

    did_doc = {
        "id": root_did,
        "service": [
            {
                "id": "#peer1",
                "type": "GtvFederationPeer",
                "serviceEndpoint": "https://verify1.example.com",  # String
            },
            {
                "id": "#peer2",
                "type": "GtvFederationPeer",
                "serviceEndpoint": {
                    "url": "https://verify2.example.com",
                    "apiKey": "secret-key-123",
                },  # Object
            },
        ],
    }

    with respx.mock:
        respx.get(did_url).mock(return_value=httpx.Response(200, json=did_doc))

        peers = await discover_peers_from_did(root_did)

        assert len(peers) == 2

        # String endpoint
        peer1 = next(p for p in peers if p.did == "#peer1")
        assert peer1.url == "https://verify1.example.com"
        assert peer1.api_key is None

        # Object endpoint
        peer2 = next(p for p in peers if p.did == "#peer2")
        assert peer2.url == "https://verify2.example.com"
        assert peer2.api_key == "secret-key-123"


@pytest.mark.asyncio
async def test_merge_env_wins_on_collision() -> None:
    """merge: env peer wins on DID collision."""
    env_peers = [
        FederationPeer(did="did:web:peer1", url="https://env-url.com", api_key="env-key"),
    ]
    discovered = [
        DiscoveredPeer(did="did:web:peer1", endpoint_url="https://discovered-url.com", api_key=None, verified=True),
        DiscoveredPeer(did="did:web:peer2", endpoint_url="https://peer2.com", api_key=None, verified=True),
    ]

    result = merge_discovered_with_env(env_peers, discovered)

    # Should have both peers
    assert len(result) == 2

    # Env peer should have env values
    peer1 = next(p for p in result if p.did == "did:web:peer1")
    assert peer1.url == "https://env-url.com"
    assert peer1.api_key == "env-key"

    # Discovered peer2 should be included
    peer2 = next(p for p in result if p.did == "did:web:peer2")
    assert peer2.url == "https://peer2.com"


@pytest.mark.asyncio
async def test_merge_disjoint_sets_union() -> None:
    """merge: disjoint sets union correctly."""
    env_peers = [
        FederationPeer(did="did:web:peer1", url="https://peer1.com", api_key=""),
    ]
    discovered = [
        DiscoveredPeer(did="did:web:peer2", endpoint_url="https://peer2.com", api_key=None, verified=True),
        DiscoveredPeer(did="did:web:peer3", endpoint_url="https://peer3.com", api_key="key3", verified=True),
    ]

    result = merge_discovered_with_env(env_peers, discovered)

    assert len(result) == 3
    dids = {p.did for p in result}
    assert "did:web:peer1" in dids
    assert "did:web:peer2" in dids
    assert "did:web:peer3" in dids


@pytest.mark.asyncio
async def test_load_discovery_config_from_env(monkeypatch: pytest.MonkeyPatch) -> None:
    """load_discovery_config_from_env reads env."""
    # Test reading a set value
    monkeypatch.setenv("GTV_FEDERATION_ROOT_DID", "did:web:root.example")
    root_did = load_discovery_config_from_env()
    assert root_did == "did:web:root.example"

    # Test reading an unset value
    monkeypatch.delenv("GTV_FEDERATION_ROOT_DID", raising=False)
    root_did = load_discovery_config_from_env()
    assert root_did is None

    # Test with custom env var
    monkeypatch.setenv("MY_CUSTOM_DID", "did:web:custom.example")
    root_did = load_discovery_config_from_env("MY_CUSTOM_DID")
    assert root_did == "did:web:custom.example"
