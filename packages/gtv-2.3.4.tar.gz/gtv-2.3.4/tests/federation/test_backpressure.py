"""Tests for federation backpressure signaling."""
from __future__ import annotations

import json

from gtv.federation.backpressure import BackpressureMonitor, BackpressureSignal


class TestBackpressureSignal:
    """Test BackpressureSignal serialization."""

    def test_to_json_serializes_correctly(self):
        """BackpressureSignal should serialize to JSON."""
        signal = BackpressureSignal(
            status="slow",
            queue_depth=200,
            target_queue_depth=100,
            suggested_retry_after_s=5,
        )
        json_str = signal.to_json()
        data = json.loads(json_str)

        assert data["status"] == "slow"
        assert data["queue_depth"] == 200
        assert data["target_queue_depth"] == 100
        assert data["suggested_retry_after_s"] == 5
        assert "timestamp" in data

    def test_to_json_includes_timestamp(self):
        """BackpressureSignal JSON should include an ISO 8601 timestamp."""
        signal = BackpressureSignal(
            status="ok",
            queue_depth=0,
            target_queue_depth=100,
            suggested_retry_after_s=0,
        )
        json_str = signal.to_json()
        data = json.loads(json_str)

        # Should be a valid ISO 8601 timestamp
        assert "timestamp" in data
        assert "T" in data["timestamp"]  # ISO format


class TestBackpressureMonitor:
    """Test BackpressureMonitor."""

    def test_initial_state_ok(self):
        """Monitor should start in 'ok' state with depth 0."""
        monitor = BackpressureMonitor(target_queue_depth=100)
        signal = monitor.compute_signal()

        assert signal.status == "ok"
        assert signal.queue_depth == 0
        assert signal.suggested_retry_after_s == 0

    def test_signal_ok_when_below_target(self):
        """Signal should be 'ok' when queue_depth < target."""
        monitor = BackpressureMonitor(target_queue_depth=100)
        monitor.set_queue_depth(50)

        signal = monitor.compute_signal()

        assert signal.status == "ok"
        assert signal.suggested_retry_after_s == 0

    def test_signal_slow_between_target_and_critical(self):
        """Signal should be 'slow' when target <= depth < critical."""
        monitor = BackpressureMonitor(
            target_queue_depth=100,
            critical_queue_depth=500,
        )
        monitor.set_queue_depth(250)

        signal = monitor.compute_signal()

        assert signal.status == "slow"
        assert signal.suggested_retry_after_s == 5

    def test_signal_overloaded_at_critical(self):
        """Signal should be 'overloaded' when depth >= critical."""
        monitor = BackpressureMonitor(
            target_queue_depth=100,
            critical_queue_depth=500,
        )
        monitor.set_queue_depth(500)

        signal = monitor.compute_signal()

        assert signal.status == "overloaded"
        assert signal.suggested_retry_after_s == 30

    def test_signal_overloaded_above_critical(self):
        """Signal should be 'overloaded' when depth > critical."""
        monitor = BackpressureMonitor(
            target_queue_depth=100,
            critical_queue_depth=500,
        )
        monitor.set_queue_depth(600)

        signal = monitor.compute_signal()

        assert signal.status == "overloaded"
        assert signal.suggested_retry_after_s == 30

    def test_boundary_at_target(self):
        """Depth == target should be 'slow', not 'ok'."""
        monitor = BackpressureMonitor(
            target_queue_depth=100,
            critical_queue_depth=500,
        )
        monitor.set_queue_depth(100)

        signal = monitor.compute_signal()

        assert signal.status == "slow"
        assert signal.suggested_retry_after_s == 5

    def test_boundary_at_critical(self):
        """Depth == critical should be 'overloaded'."""
        monitor = BackpressureMonitor(
            target_queue_depth=100,
            critical_queue_depth=500,
        )
        monitor.set_queue_depth(500)

        signal = monitor.compute_signal()

        assert signal.status == "overloaded"

    def test_override_target_threshold(self):
        """compute_signal should accept override target."""
        monitor = BackpressureMonitor(target_queue_depth=100)
        monitor.set_queue_depth(75)

        # With instance target=100, depth=75 is 'ok'
        signal_default = monitor.compute_signal()
        assert signal_default.status == "ok"

        # With override target=50, depth=75 is 'slow'
        signal_override = monitor.compute_signal(target=50)
        assert signal_override.status == "slow"

    def test_override_critical_threshold(self):
        """compute_signal should accept override critical."""
        monitor = BackpressureMonitor(
            target_queue_depth=100,
            critical_queue_depth=500,
        )
        monitor.set_queue_depth(400)

        # With instance critical=500, depth=400 is 'slow'
        signal_default = monitor.compute_signal()
        assert signal_default.status == "slow"

        # With override critical=300, depth=400 is 'overloaded'
        signal_override = monitor.compute_signal(critical=300)
        assert signal_override.status == "overloaded"

    def test_transitions_up(self):
        """Transitions from ok -> slow -> overloaded should work."""
        monitor = BackpressureMonitor(
            target_queue_depth=100,
            critical_queue_depth=500,
        )

        # Start at 'ok'
        monitor.set_queue_depth(50)
        assert monitor.compute_signal().status == "ok"

        # Transition to 'slow'
        monitor.set_queue_depth(200)
        assert monitor.compute_signal().status == "slow"

        # Transition to 'overloaded'
        monitor.set_queue_depth(600)
        assert monitor.compute_signal().status == "overloaded"

    def test_transitions_down(self):
        """Transitions from overloaded -> slow -> ok should work."""
        monitor = BackpressureMonitor(
            target_queue_depth=100,
            critical_queue_depth=500,
        )

        # Start at 'overloaded'
        monitor.set_queue_depth(600)
        assert monitor.compute_signal().status == "overloaded"

        # Transition to 'slow'
        monitor.set_queue_depth(200)
        assert monitor.compute_signal().status == "slow"

        # Transition to 'ok'
        monitor.set_queue_depth(50)
        assert monitor.compute_signal().status == "ok"

    def test_signal_includes_queue_depth(self):
        """Signal should report actual queue_depth."""
        monitor = BackpressureMonitor()
        monitor.set_queue_depth(123)

        signal = monitor.compute_signal()

        assert signal.queue_depth == 123

    def test_signal_includes_target_depth(self):
        """Signal should report target_queue_depth."""
        monitor = BackpressureMonitor(target_queue_depth=42)
        monitor.set_queue_depth(10)

        signal = monitor.compute_signal()

        assert signal.target_queue_depth == 42

    def test_set_queue_depth_updates_state(self):
        """set_queue_depth should update the monitored depth."""
        monitor = BackpressureMonitor()

        monitor.set_queue_depth(0)
        assert monitor.queue_depth == 0

        monitor.set_queue_depth(123)
        assert monitor.queue_depth == 123

        monitor.set_queue_depth(999)
        assert monitor.queue_depth == 999

    def test_negative_queue_depth_allowed(self):
        """Negative queue depths should not crash (defensive)."""
        monitor = BackpressureMonitor(target_queue_depth=100)
        monitor.set_queue_depth(-10)

        signal = monitor.compute_signal()
        # Negative depth is < target, so 'ok'
        assert signal.status == "ok"

    def test_custom_thresholds(self):
        """Custom thresholds should be respected."""
        monitor = BackpressureMonitor(
            target_queue_depth=50,
            critical_queue_depth=200,
        )

        monitor.set_queue_depth(25)
        assert monitor.compute_signal().status == "ok"

        monitor.set_queue_depth(50)
        assert monitor.compute_signal().status == "slow"

        monitor.set_queue_depth(200)
        assert monitor.compute_signal().status == "overloaded"
