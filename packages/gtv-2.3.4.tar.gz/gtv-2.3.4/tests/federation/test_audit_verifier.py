"""Tests for cross-federation audit chain consistency verifier."""

from gtv.federation.audit_verifier import (
    AuditEntry,
    verify_chain_consistency,
)


# Helper to create audit entries
def make_entry(
    entry_id: str,
    claim_id: str,
    prev_entry_id: str | None,
    payload_hash: str,
    peer_did: str,
    issued_at: str = "2026-04-22T00:00:00Z",
) -> AuditEntry:
    """Create an AuditEntry for testing."""
    return AuditEntry(
        entry_id=entry_id,
        claim_id=claim_id,
        prev_entry_id=prev_entry_id,
        payload_hash=payload_hash,
        peer_did=peer_did,
        issued_at=issued_at,
    )


class TestSinglePeerValidChain:
    """Test: Single peer with a valid chain."""

    def test_single_peer_valid_chain(self):
        """Single peer, valid chain → consistent."""
        chain = [
            make_entry("a1", "claim_1", None, "p1", "peer_1"),
            make_entry("a2", "claim_1", "a1", "p2", "peer_1"),
            make_entry("a3", "claim_1", "a2", "p3", "peer_1"),
        ]

        report = verify_chain_consistency({"peer_1": chain})

        assert report.consistent is True
        assert report.divergence_index is None
        assert report.shared_prefix_length == 3
        assert report.peer_heads == {"peer_1": "a3"}
        assert report.errors == []
        assert report.claim_id == "claim_1"


class TestTwoPeersIdenticalChains:
    """Test: Two peers with identical chains."""

    def test_two_peers_identical_chains(self):
        """Two peers identical chains → consistent."""
        chain = [
            make_entry("a1", "claim_1", None, "p1", "peer_1"),
            make_entry("a2", "claim_1", "a1", "p2", "peer_1"),
            make_entry("a3", "claim_1", "a2", "p3", "peer_1"),
        ]

        report = verify_chain_consistency(
            {
                "peer_1": chain,
                "peer_2": chain,
            }
        )

        assert report.consistent is True
        assert report.divergence_index is None
        assert report.shared_prefix_length == 3
        assert report.peer_heads == {"peer_1": "a3", "peer_2": "a3"}
        assert report.errors == []


class TestTwoPeersPrefix:
    """Test: One peer's chain is a prefix of another's."""

    def test_two_peers_one_is_strict_prefix(self):
        """Two peers, one is strict prefix of the other → consistent."""
        chain_short = [
            make_entry("a1", "claim_1", None, "p1", "peer_1"),
            make_entry("a2", "claim_1", "a1", "p2", "peer_1"),
        ]
        chain_long = [
            make_entry("a1", "claim_1", None, "p1", "peer_1"),
            make_entry("a2", "claim_1", "a1", "p2", "peer_1"),
            make_entry("a3", "claim_1", "a2", "p3", "peer_1"),
        ]

        report = verify_chain_consistency(
            {
                "peer_1": chain_short,
                "peer_2": chain_long,
            }
        )

        assert report.consistent is True
        assert report.divergence_index is None
        assert report.shared_prefix_length == 2
        assert report.peer_heads == {"peer_1": "a2", "peer_2": "a3"}
        assert report.errors == []


class TestTwoPeersDivergence:
    """Test: Two peers diverge at a specific index."""

    def test_two_peers_diverge_at_index_2(self):
        """Two peers diverge at index 2 → consistent=False, divergence_index=2."""
        chain_1 = [
            make_entry("a1", "claim_1", None, "p1", "peer_1"),
            make_entry("a2", "claim_1", "a1", "p2", "peer_1"),
            make_entry("a3", "claim_1", "a2", "p3", "peer_1"),
            make_entry("a4", "claim_1", "a3", "p4", "peer_1"),
        ]
        chain_2 = [
            make_entry("a1", "claim_1", None, "p1", "peer_1"),
            make_entry("a2", "claim_1", "a1", "p2", "peer_1"),
            make_entry("b3", "claim_1", "a2", "p3_alt", "peer_1"),  # Different entry
            make_entry("b4", "claim_1", "b3", "p4_alt", "peer_1"),
        ]

        report = verify_chain_consistency(
            {
                "peer_1": chain_1,
                "peer_2": chain_2,
            }
        )

        assert report.consistent is False
        assert report.divergence_index == 2
        assert report.shared_prefix_length == 2
        assert report.peer_heads == {"peer_1": "a4", "peer_2": "b4"}
        assert report.errors == []


class TestBrokenLinkInChain:
    """Test: One peer has a broken link in its chain."""

    def test_broken_link_inside_chain(self):
        """Broken link inside one peer's chain → error + consistent=False."""
        chain_good = [
            make_entry("a1", "claim_1", None, "p1", "peer_1"),
            make_entry("a2", "claim_1", "a1", "p2", "peer_1"),
        ]
        chain_bad = [
            make_entry("a1", "claim_1", None, "p1", "peer_1"),
            make_entry("a2", "claim_1", "wrong_prev", "p2", "peer_2"),  # Wrong prev
        ]

        report = verify_chain_consistency(
            {
                "peer_1": chain_good,
                "peer_2": chain_bad,
            }
        )

        assert report.consistent is False
        assert report.divergence_index is None
        assert len(report.errors) > 0
        assert any("broken link" in e for e in report.errors)
        assert any("peer_2" in e for e in report.errors)


class TestEmptyChain:
    """Test: One peer has an empty chain."""

    def test_empty_chain_for_one_peer(self):
        """Empty chain for one peer → error + consistent=False."""
        chain = [
            make_entry("a1", "claim_1", None, "p1", "peer_1"),
        ]

        report = verify_chain_consistency(
            {
                "peer_1": chain,
                "peer_2": [],
            }
        )

        assert report.consistent is False
        assert len(report.errors) > 0
        assert any("empty chain" in e for e in report.errors)
        assert any("peer_2" in e for e in report.errors)


class TestClaimIdMismatch:
    """Test: Mismatched claim_id inside a peer's chain."""

    def test_claim_id_mismatch(self):
        """Mismatched claim_id inside a peer's chain → error."""
        chain = [
            make_entry("a1", "claim_1", None, "p1", "peer_1"),
            make_entry("a2", "claim_2", "a1", "p2", "peer_1"),  # Wrong claim_id
        ]

        report = verify_chain_consistency({"peer_1": chain})

        assert report.consistent is False
        assert len(report.errors) > 0
        assert any("claim_id mismatch" in e for e in report.errors)


class TestThreePeersIdentical:
    """Test: Three peers all with identical chains."""

    def test_three_peers_all_identical(self):
        """Three peers all identical → consistent."""
        chain = [
            make_entry("a1", "claim_1", None, "p1", "peer_1"),
            make_entry("a2", "claim_1", "a1", "p2", "peer_1"),
        ]

        report = verify_chain_consistency(
            {
                "peer_1": chain,
                "peer_2": chain,
                "peer_3": chain,
            }
        )

        assert report.consistent is True
        assert report.divergence_index is None
        assert report.shared_prefix_length == 2
        assert len(report.peer_heads) == 3
        assert report.errors == []


class TestComplexDivergence:
    """Test: Three peers with different lengths and divergent tails."""

    def test_peer_chains_different_lengths_divergent_tails(self):
        """Three peers with different lengths + divergent tails → correctly reports divergence_index."""
        # Divergence at index 2: chain_1 and chain_2 diverge from chain_3
        chain_1 = [
            make_entry("a1", "claim_1", None, "p1", "peer_1"),
            make_entry("a2", "claim_1", "a1", "p2", "peer_1"),
            make_entry("a3", "claim_1", "a2", "p3", "peer_1"),
            make_entry("a4", "claim_1", "a3", "p4", "peer_1"),
        ]
        chain_2 = [
            make_entry("a1", "claim_1", None, "p1", "peer_1"),
            make_entry("a2", "claim_1", "a1", "p2", "peer_1"),
            make_entry("b3", "claim_1", "a2", "p3_alt", "peer_1"),
            make_entry("b4", "claim_1", "b3", "p4_alt", "peer_1"),
        ]
        chain_3 = [
            make_entry("a1", "claim_1", None, "p1", "peer_1"),
            make_entry("a2", "claim_1", "a1", "p2", "peer_1"),
            make_entry("c3", "claim_1", "a2", "p3_other", "peer_1"),
        ]

        report = verify_chain_consistency(
            {
                "peer_1": chain_1,
                "peer_2": chain_2,
                "peer_3": chain_3,
            }
        )

        assert report.consistent is False
        assert report.divergence_index == 2
        assert report.shared_prefix_length == 2
        assert report.peer_heads == {"peer_1": "a4", "peer_2": "b4", "peer_3": "c3"}
        assert report.errors == []


class TestEmptyPeerChains:
    """Test: Empty peer_chains dict."""

    def test_empty_peer_chains(self):
        """Empty peer_chains dict → consistent with 0 shared prefix."""
        report = verify_chain_consistency({})

        assert report.consistent is True
        assert report.divergence_index is None
        assert report.shared_prefix_length == 0
        assert report.peer_heads == {}
        assert report.errors == []


class TestFirstEntryWithNonNullPrevId:
    """Test: First entry has a non-None prev_entry_id."""

    def test_first_entry_non_null_prev_id(self):
        """First entry with non-None prev_entry_id → error."""
        chain = [
            make_entry("a1", "claim_1", "wrong_prev", "p1", "peer_1"),
        ]

        report = verify_chain_consistency({"peer_1": chain})

        assert report.consistent is False
        assert len(report.errors) > 0
        assert any("broken link" in e for e in report.errors)
