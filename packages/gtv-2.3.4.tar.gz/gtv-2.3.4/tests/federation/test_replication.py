"""Tests for cross-federation claim replication publisher."""
from __future__ import annotations

import base64
import hashlib
import hmac
import os
import time

import httpx
import pytest
import respx

from gtv.federation.replication import (
    ReplicationPublisher,
    ReplicationTarget,
    load_replication_targets_from_env,
    verify_replication_signature,
)


@pytest.fixture
def hmac_secret() -> bytes:
    """Test HMAC secret key."""
    return b"test-secret-key-12345"


@pytest.fixture
def target_a(hmac_secret: bytes) -> ReplicationTarget:
    """Test replication target A."""
    return ReplicationTarget(
        did="did:web:peer-a.example.com",
        url="https://peer-a.example.com",
        api_key="key-a-token",
        hmac_secret=hmac_secret,
    )


@pytest.fixture
def target_b(hmac_secret: bytes) -> ReplicationTarget:
    """Test replication target B."""
    return ReplicationTarget(
        did="did:web:peer-b.example.com",
        url="https://peer-b.example.com",
        api_key=None,
        hmac_secret=hmac_secret,
    )


@pytest.fixture
def publisher(target_a: ReplicationTarget, target_b: ReplicationTarget) -> ReplicationPublisher:
    """Test replication publisher with two targets."""
    return ReplicationPublisher(targets=[target_a, target_b], timeout=5.0)


# ----------- Single Target Tests -----------


@pytest.mark.asyncio
async def test_publish_single_target_200_success(target_a: ReplicationTarget) -> None:
    """Publish to single target returning 200 should set accepted=True."""
    publisher = ReplicationPublisher(targets=[target_a], timeout=5.0)

    payload = {
        "verdict_id": "v-123",
        "claim_id": "c-456",
        "decision": "VERIFIED",
        "confidence": 0.95,
    }

    with respx.mock:
        route = respx.post("https://peer-a.example.com/federation/replicate").mock(
            return_value=httpx.Response(200)
        )

        results = await publisher.publish(payload)

    assert len(results) == 1
    result = results[0]
    assert result.target_did == "did:web:peer-a.example.com"
    assert result.accepted is True
    assert result.status_code == 200
    assert result.error is None
    assert route.called


# ----------- Multiple Target Tests -----------


@pytest.mark.asyncio
async def test_publish_multiple_targets_concurrent(
    target_a: ReplicationTarget, target_b: ReplicationTarget
) -> None:
    """Publish to multiple targets should fan out concurrently."""
    publisher = ReplicationPublisher(targets=[target_a, target_b], timeout=5.0)

    payload = {"verdict_id": "v-123", "decision": "VERIFIED"}

    with respx.mock:
        route_a = respx.post("https://peer-a.example.com/federation/replicate").mock(
            return_value=httpx.Response(200)
        )
        route_b = respx.post("https://peer-b.example.com/federation/replicate").mock(
            return_value=httpx.Response(200)
        )

        results = await publisher.publish(payload)

    assert len(results) == 2
    assert all(r.accepted for r in results)
    assert route_a.called
    assert route_b.called


# ----------- Error Handling Tests -----------


@pytest.mark.asyncio
async def test_publish_5xx_error_sets_accepted_false(target_a: ReplicationTarget) -> None:
    """5xx response should set accepted=False with error."""
    publisher = ReplicationPublisher(targets=[target_a], timeout=5.0)

    payload = {"verdict_id": "v-123", "decision": "VERIFIED"}

    with respx.mock:
        respx.post("https://peer-a.example.com/federation/replicate").mock(
            return_value=httpx.Response(503)
        )

        results = await publisher.publish(payload)

    assert len(results) == 1
    result = results[0]
    assert result.accepted is False
    assert result.status_code == 503
    assert result.error == "HTTP 503"


@pytest.mark.asyncio
async def test_publish_4xx_error_sets_accepted_false(target_a: ReplicationTarget) -> None:
    """4xx response should set accepted=False with error."""
    publisher = ReplicationPublisher(targets=[target_a], timeout=5.0)

    payload = {"verdict_id": "v-123", "decision": "VERIFIED"}

    with respx.mock:
        respx.post("https://peer-a.example.com/federation/replicate").mock(
            return_value=httpx.Response(401)
        )

        results = await publisher.publish(payload)

    assert len(results) == 1
    result = results[0]
    assert result.accepted is False
    assert result.status_code == 401
    assert result.error == "HTTP 401"


@pytest.mark.asyncio
async def test_publish_network_error_captured(target_a: ReplicationTarget) -> None:
    """Network error should set accepted=False and capture error message."""
    publisher = ReplicationPublisher(targets=[target_a], timeout=5.0)

    payload = {"verdict_id": "v-123", "decision": "VERIFIED"}

    with respx.mock:
        respx.post("https://peer-a.example.com/federation/replicate").mock(
            side_effect=httpx.ConnectError("Connection refused")
        )

        results = await publisher.publish(payload)

    assert len(results) == 1
    result = results[0]
    assert result.accepted is False
    assert result.status_code is None
    assert "Connection refused" in (result.error or "")


# ----------- Signature Tests -----------


@pytest.mark.asyncio
async def test_hmac_signature_header_matches_body(
    target_a: ReplicationTarget, hmac_secret: bytes
) -> None:
    """X-GTV-Replication-Signature header should match HMAC-SHA256 of body."""
    publisher = ReplicationPublisher(targets=[target_a], timeout=5.0)

    payload = {"verdict_id": "v-123", "decision": "VERIFIED"}

    captured_request = None

    def capture_request(request: httpx.Request) -> httpx.Response:
        nonlocal captured_request
        captured_request = request
        return httpx.Response(200)

    with respx.mock:
        respx.post("https://peer-a.example.com/federation/replicate").mock(
            side_effect=capture_request
        )

        await publisher.publish(payload)

    assert captured_request is not None
    assert "x-gtv-replication-signature" in captured_request.headers
    sig_header = captured_request.headers["x-gtv-replication-signature"]
    assert sig_header.startswith("sha256=")

    # Verify the signature matches our payload
    body_bytes = captured_request.content
    expected_sig = hmac.new(hmac_secret, body_bytes, hashlib.sha256).hexdigest()
    assert sig_header == f"sha256={expected_sig}"


@pytest.mark.asyncio
async def test_timestamp_header_present_and_recent(
    target_a: ReplicationTarget,
) -> None:
    """X-GTV-Replication-Timestamp header should be present and recent."""
    publisher = ReplicationPublisher(targets=[target_a], timeout=5.0)

    payload = {"verdict_id": "v-123", "decision": "VERIFIED"}

    captured_request = None

    def capture_request(request: httpx.Request) -> httpx.Response:
        nonlocal captured_request
        captured_request = request
        return httpx.Response(200)

    with respx.mock:
        respx.post("https://peer-a.example.com/federation/replicate").mock(
            side_effect=capture_request
        )

        before_time = int(time.time())
        await publisher.publish(payload)
        after_time = int(time.time())

    assert captured_request is not None
    assert "x-gtv-replication-timestamp" in captured_request.headers
    timestamp_str = captured_request.headers["x-gtv-replication-timestamp"]
    timestamp = int(timestamp_str)

    # Timestamp should be recent (within request window)
    assert before_time <= timestamp <= after_time + 1


# ----------- Authorization Header Tests -----------


@pytest.mark.asyncio
async def test_authorization_header_set_when_api_key_present(
    target_a: ReplicationTarget,
) -> None:
    """Authorization header should be set when api_key is present."""
    publisher = ReplicationPublisher(targets=[target_a], timeout=5.0)

    payload = {"verdict_id": "v-123", "decision": "VERIFIED"}

    captured_request = None

    def capture_request(request: httpx.Request) -> httpx.Response:
        nonlocal captured_request
        captured_request = request
        return httpx.Response(200)

    with respx.mock:
        respx.post("https://peer-a.example.com/federation/replicate").mock(
            side_effect=capture_request
        )

        await publisher.publish(payload)

    assert captured_request is not None
    assert "authorization" in captured_request.headers
    assert captured_request.headers["authorization"] == "Bearer key-a-token"


@pytest.mark.asyncio
async def test_authorization_header_absent_when_api_key_none(
    target_b: ReplicationTarget,
) -> None:
    """Authorization header should be absent when api_key is None."""
    publisher = ReplicationPublisher(targets=[target_b], timeout=5.0)

    payload = {"verdict_id": "v-123", "decision": "VERIFIED"}

    captured_request = None

    def capture_request(request: httpx.Request) -> httpx.Response:
        nonlocal captured_request
        captured_request = request
        return httpx.Response(200)

    with respx.mock:
        respx.post("https://peer-b.example.com/federation/replicate").mock(
            side_effect=capture_request
        )

        await publisher.publish(payload)

    assert captured_request is not None
    assert "authorization" not in captured_request.headers


# ----------- Signature Verification Tests -----------


def test_verify_replication_signature_valid_sig_fresh_timestamp(
    hmac_secret: bytes,
) -> None:
    """verify_replication_signature: valid sig + fresh timestamp → True."""
    body = b'{"verdict_id": "v-123", "decision": "VERIFIED"}'
    timestamp = str(int(time.time()))
    signature = hmac.new(hmac_secret, body, hashlib.sha256).hexdigest()
    sig_header = f"sha256={signature}"

    result = verify_replication_signature(
        body=body,
        signature_header=sig_header,
        hmac_secret=hmac_secret,
        max_age_s=300,
        timestamp_header=timestamp,
    )

    assert result is True


def test_verify_replication_signature_tampered_body(hmac_secret: bytes) -> None:
    """verify_replication_signature: tampered body → False."""
    body = b'{"verdict_id": "v-123", "decision": "VERIFIED"}'
    tampered_body = b'{"verdict_id": "v-123", "decision": "UNVERIFIED"}'
    timestamp = str(int(time.time()))
    signature = hmac.new(hmac_secret, body, hashlib.sha256).hexdigest()
    sig_header = f"sha256={signature}"

    result = verify_replication_signature(
        body=tampered_body,
        signature_header=sig_header,
        hmac_secret=hmac_secret,
        max_age_s=300,
        timestamp_header=timestamp,
    )

    assert result is False


def test_verify_replication_signature_stale_timestamp(hmac_secret: bytes) -> None:
    """verify_replication_signature: stale timestamp (>max_age_s) → False."""
    body = b'{"verdict_id": "v-123", "decision": "VERIFIED"}'
    stale_timestamp = str(int(time.time()) - 600)  # 10 minutes ago
    signature = hmac.new(hmac_secret, body, hashlib.sha256).hexdigest()
    sig_header = f"sha256={signature}"

    result = verify_replication_signature(
        body=body,
        signature_header=sig_header,
        hmac_secret=hmac_secret,
        max_age_s=300,
        timestamp_header=stale_timestamp,
    )

    assert result is False


# ----------- Environment Loader Tests -----------


def test_load_replication_targets_from_env_valid_list(monkeypatch: pytest.MonkeyPatch) -> None:
    """load_replication_targets_from_env parses valid list."""
    hmac_secret_b64 = base64.b64encode(b"secret-key-123").decode("ascii")
    env_value = (
        f"did:web:a.com|https://a.example.com|key-a|{hmac_secret_b64},"
        f"did:web:b.com|https://b.example.com||{hmac_secret_b64}"
    )

    monkeypatch.setenv("GTV_REPLICATION_TARGETS", env_value)

    targets = load_replication_targets_from_env()

    assert len(targets) == 2
    assert targets[0].did == "did:web:a.com"
    assert targets[0].url == "https://a.example.com"
    assert targets[0].api_key == "key-a"
    assert targets[0].hmac_secret == b"secret-key-123"

    assert targets[1].did == "did:web:b.com"
    assert targets[1].url == "https://b.example.com"
    assert targets[1].api_key is None
    assert targets[1].hmac_secret == b"secret-key-123"


def test_load_replication_targets_from_env_skips_malformed(
    monkeypatch: pytest.MonkeyPatch, caplog: pytest.LogCaptureFixture
) -> None:
    """load_replication_targets_from_env skips malformed entries."""
    hmac_secret_b64 = base64.b64encode(b"secret-key-123").decode("ascii")
    env_value = (
        f"did:web:a.com|https://a.example.com|key-a|{hmac_secret_b64},"
        "malformed-no-pipes,"
        f"did:web:c.com|https://c.example.com||{hmac_secret_b64}"
    )

    monkeypatch.setenv("GTV_REPLICATION_TARGETS", env_value)

    targets = load_replication_targets_from_env()

    assert len(targets) == 2
    assert targets[0].did == "did:web:a.com"
    assert targets[1].did == "did:web:c.com"
    assert "Skipping malformed" in caplog.text


def test_load_replication_targets_from_env_empty() -> None:
    """load_replication_targets_from_env empty/unset returns []."""
    # Clear the env var
    os.environ.pop("GTV_REPLICATION_TARGETS", None)

    targets = load_replication_targets_from_env()

    assert targets == []
