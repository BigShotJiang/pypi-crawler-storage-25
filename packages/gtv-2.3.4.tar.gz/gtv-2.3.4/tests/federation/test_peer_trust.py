"""Tests for EigenTrust peer reputation scoring."""
from __future__ import annotations

import pytest

from gtv.federation.peer_trust import TrustMatrix, compute_global_trust


def test_trust_matrix_validation_row_count() -> None:
    """TrustMatrix should reject mismatched row count."""
    with pytest.raises(ValueError, match="row count"):
        TrustMatrix(
            peers=["a", "b"],
            local_trust=[[1.0, 0.0], [0.0, 1.0], [0.5, 0.5]],
        )


def test_trust_matrix_validation_col_count() -> None:
    """TrustMatrix should reject mismatched column count."""
    with pytest.raises(ValueError, match="cols"):
        TrustMatrix(
            peers=["a", "b"],
            local_trust=[[1.0, 0.0, 0.5], [0.0, 1.0]],
        )


def test_returns_dict_with_all_peers() -> None:
    """Should return dict with all peer DIDs."""
    matrix = TrustMatrix(
        peers=["alice", "bob", "charlie"],
        local_trust=[
            [0.0, 1.0, 0.0],
            [0.5, 0.0, 0.5],
            [0.0, 0.0, 1.0],
        ],
    )
    result = compute_global_trust(matrix)
    assert set(result.keys()) == {"alice", "bob", "charlie"}
    assert all(isinstance(v, float) for v in result.values())


def test_scores_sum_to_one() -> None:
    """Trust scores should sum to ~1.0 (within floating point error)."""
    matrix = TrustMatrix(
        peers=["a", "b", "c"],
        local_trust=[
            [0.5, 0.5, 0.0],
            [0.0, 0.0, 1.0],
            [1.0, 0.0, 0.0],
        ],
    )
    result = compute_global_trust(matrix)
    total = sum(result.values())
    assert abs(total - 1.0) < 1e-6


def test_pre_trusted_peers_get_higher_scores() -> None:
    """Pre-trusted peers should get higher scores when matrix is neutral."""
    # All peers have uniform trust in each other (no signal)
    matrix = TrustMatrix(
        peers=["alice", "bob", "charlie"],
        local_trust=[
            [0.33, 0.33, 0.34],
            [0.33, 0.33, 0.34],
            [0.33, 0.33, 0.34],
        ],
    )
    # Teleport to alice only
    result = compute_global_trust(matrix, pre_trusted=["alice"])
    # alice should have highest score due to teleportation
    assert result["alice"] > result["bob"]
    assert result["alice"] > result["charlie"]


def test_trusted_peer_high_score() -> None:
    """A peer trusted by many should get high score."""
    matrix = TrustMatrix(
        peers=["alice", "bob", "charlie"],
        local_trust=[
            [0.0, 1.0, 0.0],  # alice trusts bob
            [0.0, 0.0, 1.0],  # bob trusts charlie
            [1.0, 0.0, 0.0],  # charlie trusts alice
        ],
    )
    result = compute_global_trust(matrix)
    # All have some score
    assert all(s > 0 for s in result.values())
    # All sum to 1
    assert abs(sum(result.values()) - 1.0) < 1e-6


def test_peer_trusting_nobody_gets_teleport_weight() -> None:
    """Peer that trusts nobody should still get some score from teleport."""
    matrix = TrustMatrix(
        peers=["a", "b"],
        local_trust=[
            [0.0, 0.0],  # 'a' trusts nobody
            [1.0, 0.0],  # 'b' trusts 'a'
        ],
    )
    result = compute_global_trust(matrix)
    # Both should have non-zero scores
    assert result["a"] > 0
    assert result["b"] > 0


def test_convergence_in_max_iters() -> None:
    """Should converge in max_iters on a simple matrix."""
    matrix = TrustMatrix(
        peers=["a", "b", "c"],
        local_trust=[
            [0.0, 1.0, 0.0],
            [0.0, 0.0, 1.0],
            [1.0, 0.0, 0.0],
        ],
    )
    # With a small max_iters, should still compute something
    result = compute_global_trust(matrix, max_iters=5)
    assert set(result.keys()) == {"a", "b", "c"}
    assert abs(sum(result.values()) - 1.0) < 1e-3


def test_tolerance_respected() -> None:
    """Larger tolerance should converge faster (within fewer iterations)."""
    matrix = TrustMatrix(
        peers=["a", "b", "c"],
        local_trust=[
            [0.0, 0.5, 0.5],
            [0.5, 0.0, 0.5],
            [0.5, 0.5, 0.0],
        ],
    )
    # With tight tolerance, may take more iterations
    result_tight = compute_global_trust(matrix, tol=1e-9, max_iters=1000)
    # With loose tolerance, should converge quickly
    result_loose = compute_global_trust(matrix, tol=1e-2, max_iters=1000)

    # Both should sum to 1
    assert abs(sum(result_tight.values()) - 1.0) < 1e-6
    assert abs(sum(result_loose.values()) - 1.0) < 1e-6


def test_pre_trusted_validates_peer_existence() -> None:
    """Should raise if pre_trusted contains unknown peer."""
    matrix = TrustMatrix(
        peers=["a", "b"],
        local_trust=[[1.0, 0.0], [0.0, 1.0]],
    )
    with pytest.raises(ValueError, match="not in matrix"):
        compute_global_trust(matrix, pre_trusted=["unknown"])


def test_uniform_matrix_uniform_scores() -> None:
    """Uniform trust matrix should yield (approximately) uniform scores."""
    n = 4
    uniform_row = [1.0 / n] * n
    matrix = TrustMatrix(
        peers=[f"peer_{i}" for i in range(n)],
        local_trust=[uniform_row] * n,
    )
    result = compute_global_trust(matrix)
    # All scores should be approximately 1/n
    for score in result.values():
        assert abs(score - 1.0 / n) < 0.01


def test_cycle_graph() -> None:
    """Cycle: 0->1->2->0 should distribute reputation evenly."""
    matrix = TrustMatrix(
        peers=["a", "b", "c"],
        local_trust=[
            [0.0, 1.0, 0.0],  # a trusts b
            [0.0, 0.0, 1.0],  # b trusts c
            [1.0, 0.0, 0.0],  # c trusts a
        ],
    )
    result = compute_global_trust(matrix)
    # Scores should be roughly equal (cycle is symmetric)
    scores = [result[f] for f in ["a", "b", "c"]]
    avg = sum(scores) / 3
    for score in scores:
        assert abs(score - avg) < 0.05
