"""Tests for cross-peer revocation gossip protocol."""
from __future__ import annotations

from datetime import datetime

import httpx
import pytest
import respx

from gtv.federation.revocation_gossip import RevocationGossip, RevocationRecord


class FakeStore:
    """Fake in-memory revocation store for testing."""

    def __init__(self) -> None:
        self._records: dict[str, RevocationRecord] = {}

    def list_since(self, timestamp: str) -> list[RevocationRecord]:
        """Return all records issued after the timestamp."""
        since_dt = datetime.fromisoformat(timestamp.replace("Z", "+00:00"))
        result = []
        for record in self._records.values():
            issued_dt = datetime.fromisoformat(
                record.issued_at.replace("Z", "+00:00")
            )
            if issued_dt > since_dt:
                result.append(record)
        return result

    def upsert(self, record: RevocationRecord) -> bool:
        """Insert or update. Return True if new, False if already exists."""
        if record.revocation_id in self._records:
            return False
        self._records[record.revocation_id] = record
        return True

    def get_all(self) -> dict[str, RevocationRecord]:
        """Return all records."""
        return self._records.copy()


@pytest.mark.asyncio
async def test_pull_from_parses_records():
    """pull_from should parse and return RevocationRecord objects from peer."""
    store = FakeStore()
    gossip = RevocationGossip(store)

    peer_data = [
        {
            "revocation_id": "rev1",
            "target_id": "claim1",
            "reason": "retracted",
            "issuer_did": "did:key:issuer1",
            "issued_at": "2026-04-22T10:00:00Z",
            "signature": "sig1",
        }
    ]

    async with respx.mock:
        respx.get("https://peer.example.com/federation/revocations").mock(
            return_value=httpx.Response(200, json=peer_data)
        )

        records = await gossip.pull_from(
            "did:key:peer1", "https://peer.example.com"
        )

    assert len(records) == 1
    assert records[0].revocation_id == "rev1"
    assert records[0].target_id == "claim1"
    assert records[0].reason == "retracted"
    assert records[0].issuer_did == "did:key:issuer1"
    assert records[0].issued_at == "2026-04-22T10:00:00Z"
    assert records[0].signature == "sig1"

    await gossip.close()


@pytest.mark.asyncio
async def test_pull_from_with_since_filter():
    """pull_from with since parameter should add it to the query string."""
    store = FakeStore()
    gossip = RevocationGossip(store)

    peer_data = []

    async with respx.mock:
        route = respx.get(
            "https://peer.example.com/federation/revocations",
            params={"since": "2026-04-20T00:00:00Z"},
        ).mock(return_value=httpx.Response(200, json=peer_data))

        await gossip.pull_from(
            "did:key:peer1",
            "https://peer.example.com",
            since="2026-04-20T00:00:00Z",
        )

        assert route.called

    await gossip.close()


@pytest.mark.asyncio
async def test_gossip_round_calls_all_peers_concurrently():
    """gossip_round should make concurrent requests to all peers."""
    store = FakeStore()
    gossip = RevocationGossip(store)

    peer1_data = [
        {
            "revocation_id": "rev1",
            "target_id": "claim1",
            "reason": "retracted",
            "issuer_did": "did:key:issuer1",
            "issued_at": "2026-04-22T10:00:00Z",
            "signature": "sig1",
        }
    ]

    peer2_data = [
        {
            "revocation_id": "rev2",
            "target_id": "claim2",
            "reason": "rescinded",
            "issuer_did": "did:key:issuer2",
            "issued_at": "2026-04-22T11:00:00Z",
            "signature": "sig2",
        }
    ]

    async with respx.mock:
        respx.get("https://peer1.example.com/federation/revocations").mock(
            return_value=httpx.Response(200, json=peer1_data)
        )
        respx.get("https://peer2.example.com/federation/revocations").mock(
            return_value=httpx.Response(200, json=peer2_data)
        )

        peers = [
            ("did:key:peer1", "https://peer1.example.com"),
            ("did:key:peer2", "https://peer2.example.com"),
        ]
        results = await gossip.gossip_round(peers)

    assert results["did:key:peer1"] == 1
    assert results["did:key:peer2"] == 1

    await gossip.close()


@pytest.mark.asyncio
async def test_new_records_get_upserted():
    """New records from peers should be inserted into the local store."""
    store = FakeStore()
    gossip = RevocationGossip(store)

    peer_data = [
        {
            "revocation_id": "rev1",
            "target_id": "claim1",
            "reason": "retracted",
            "issuer_did": "did:key:issuer1",
            "issued_at": "2026-04-22T10:00:00Z",
            "signature": "sig1",
        }
    ]

    async with respx.mock:
        respx.get("https://peer.example.com/federation/revocations").mock(
            return_value=httpx.Response(200, json=peer_data)
        )

        peers = [("did:key:peer1", "https://peer.example.com")]
        results = await gossip.gossip_round(peers)

    assert results["did:key:peer1"] == 1
    all_records = store.get_all()
    assert len(all_records) == 1
    assert "rev1" in all_records

    await gossip.close()


@pytest.mark.asyncio
async def test_duplicate_records_not_upserted():
    """Duplicate records should not be re-upserted."""
    store = FakeStore()
    record = RevocationRecord(
        revocation_id="rev1",
        target_id="claim1",
        reason="retracted",
        issuer_did="did:key:issuer1",
        issued_at="2026-04-22T10:00:00Z",
        signature="sig1",
    )
    store.upsert(record)

    gossip = RevocationGossip(store)

    peer_data = [
        {
            "revocation_id": "rev1",
            "target_id": "claim1",
            "reason": "retracted",
            "issuer_did": "did:key:issuer1",
            "issued_at": "2026-04-22T10:00:00Z",
            "signature": "sig1",
        }
    ]

    async with respx.mock:
        respx.get("https://peer.example.com/federation/revocations").mock(
            return_value=httpx.Response(200, json=peer_data)
        )

        peers = [("did:key:peer1", "https://peer.example.com")]
        results = await gossip.gossip_round(peers)

    # Duplicate should not be counted as adopted
    assert results["did:key:peer1"] == 0

    await gossip.close()


@pytest.mark.asyncio
async def test_one_peer_error_doesnt_stop_others():
    """If one peer errors, others should still complete."""
    store = FakeStore()
    gossip = RevocationGossip(store)

    peer2_data = [
        {
            "revocation_id": "rev2",
            "target_id": "claim2",
            "reason": "rescinded",
            "issuer_did": "did:key:issuer2",
            "issued_at": "2026-04-22T11:00:00Z",
            "signature": "sig2",
        }
    ]

    async with respx.mock:
        respx.get("https://peer1.example.com/federation/revocations").mock(
            side_effect=httpx.RequestError("Connection failed")
        )
        respx.get("https://peer2.example.com/federation/revocations").mock(
            return_value=httpx.Response(200, json=peer2_data)
        )

        peers = [
            ("did:key:peer1", "https://peer1.example.com"),
            ("did:key:peer2", "https://peer2.example.com"),
        ]
        results = await gossip.gossip_round(peers)

    # Peer1 should have count 0 due to error
    assert results["did:key:peer1"] == 0
    # Peer2 should still have processed
    assert results["did:key:peer2"] == 1
    # Error should be stashed
    assert gossip.last_error is not None
    assert "did:key:peer1" in gossip.last_error

    await gossip.close()


@pytest.mark.asyncio
async def test_malformed_record_skipped():
    """Records with empty target_id or revocation_id should be skipped silently."""
    store = FakeStore()
    gossip = RevocationGossip(store)

    peer_data = [
        # Missing target_id
        {
            "revocation_id": "rev1",
            "target_id": "",
            "reason": "retracted",
            "issuer_did": "did:key:issuer1",
            "issued_at": "2026-04-22T10:00:00Z",
            "signature": "sig1",
        },
        # Missing revocation_id
        {
            "revocation_id": "",
            "target_id": "claim2",
            "reason": "rescinded",
            "issuer_did": "did:key:issuer2",
            "issued_at": "2026-04-22T11:00:00Z",
            "signature": "sig2",
        },
        # Valid record
        {
            "revocation_id": "rev3",
            "target_id": "claim3",
            "reason": "retracted",
            "issuer_did": "did:key:issuer3",
            "issued_at": "2026-04-22T12:00:00Z",
            "signature": "sig3",
        },
    ]

    async with respx.mock:
        respx.get("https://peer.example.com/federation/revocations").mock(
            return_value=httpx.Response(200, json=peer_data)
        )

        peers = [("did:key:peer1", "https://peer.example.com")]
        results = await gossip.gossip_round(peers)

    # Only the valid record should be adopted
    assert results["did:key:peer1"] == 1
    all_records = store.get_all()
    assert len(all_records) == 1
    assert "rev3" in all_records

    await gossip.close()


@pytest.mark.asyncio
async def test_close_closes_owned_client():
    """close() should close the client if owned by the instance."""
    store = FakeStore()
    gossip = RevocationGossip(store)  # No client provided, so owned

    # Close should not raise
    await gossip.close()

    # Client should be closed (attempting to use it should fail)
    with pytest.raises(RuntimeError):
        await gossip.client.get("https://example.com")


@pytest.mark.asyncio
async def test_close_does_not_close_provided_client():
    """close() should not close a client provided by the caller."""
    store = FakeStore()
    client = httpx.AsyncClient()

    gossip = RevocationGossip(store, client=client)
    await gossip.close()

    # Client should still be usable
    assert not client.is_closed

    await client.aclose()
