"""Tests for the SQLite-backed issuer store.

Comprehensive test suite covering basic operations, persistence, threading,
schema roundtrips, and edge cases.
"""
from __future__ import annotations

import threading
from pathlib import Path

import pytest

from gtv.federation.store import IssuerStore, StoredIssuer
from gtv.models import TrustTier


class TestIssuerStoreBasics:
    """Basic add, get, list operations."""

    def test_add_and_get_roundtrip(self, tmp_path: Path) -> None:
        """Test add() and get() round-trip for a single issuer."""
        store = IssuerStore(tmp_path / "test.db")

        store.add(
            "did:web:example.com",
            "Example Issuer",
            TrustTier.TIER_1,
            "Test notes",
        )

        issuer = store.get("did:web:example.com")
        assert issuer is not None
        assert issuer.issuer_did == "did:web:example.com"
        assert issuer.name == "Example Issuer"
        assert issuer.trust_tier == TrustTier.TIER_1
        assert issuer.notes == "Test notes"
        assert issuer.revoked_at is None
        assert issuer.is_active()

        store.close()

    def test_add_idempotent(self, tmp_path: Path) -> None:
        """Test that adding the same issuer twice updates it (upsert)."""
        store = IssuerStore(tmp_path / "test.db")

        # Add initial issuer
        store.add(
            "did:web:example.com",
            "Initial Name",
            TrustTier.TIER_1,
            "Initial notes",
        )
        issuer_v1 = store.get("did:web:example.com")
        assert issuer_v1 is not None
        added_at_v1 = issuer_v1.added_at
        updated_at_v1 = issuer_v1.updated_at

        # Add same issuer again with different details
        store.add(
            "did:web:example.com",
            "Updated Name",
            TrustTier.TIER_2,
            "Updated notes",
        )
        issuer_v2 = store.get("did:web:example.com")
        assert issuer_v2 is not None
        assert issuer_v2.name == "Updated Name"
        assert issuer_v2.trust_tier == TrustTier.TIER_2
        assert issuer_v2.notes == "Updated notes"

        # Verify added_at is preserved, updated_at is refreshed
        assert issuer_v2.added_at == added_at_v1
        assert issuer_v2.updated_at >= updated_at_v1

        # Verify only one row in database
        all_issuers = store.list_all()
        assert len(all_issuers) == 1

        store.close()

    def test_get_nonexistent(self, tmp_path: Path) -> None:
        """Test get() returns None for missing issuer."""
        store = IssuerStore(tmp_path / "test.db")
        assert store.get("did:web:nonexistent.com") is None
        store.close()

    def test_get_tier_convenience(self, tmp_path: Path) -> None:
        """Test get_tier() convenience method."""
        store = IssuerStore(tmp_path / "test.db")

        store.add("did:web:example.com", "Example", TrustTier.TIER_2)
        assert store.get_tier("did:web:example.com") == TrustTier.TIER_2
        assert store.get_tier("did:web:nonexistent.com") is None

        store.close()


class TestIssuerStoreTierUpdates:
    """Tests for update_tier() method."""

    def test_update_tier_changes_tier(self, tmp_path: Path) -> None:
        """Test that update_tier() changes the tier."""
        store = IssuerStore(tmp_path / "test.db")

        store.add("did:web:example.com", "Example", TrustTier.TIER_1)
        issuer_before = store.get("did:web:example.com")
        assert issuer_before is not None
        added_at = issuer_before.added_at

        # Update tier
        result = store.update_tier("did:web:example.com", TrustTier.TIER_3)
        assert result is True

        issuer_after = store.get("did:web:example.com")
        assert issuer_after is not None
        assert issuer_after.trust_tier == TrustTier.TIER_3
        assert issuer_after.added_at == added_at
        assert issuer_after.updated_at >= issuer_before.updated_at

        store.close()

    def test_update_tier_nonexistent(self, tmp_path: Path) -> None:
        """Test that update_tier() returns False for missing issuer."""
        store = IssuerStore(tmp_path / "test.db")
        result = store.update_tier("did:web:nonexistent.com", TrustTier.TIER_1)
        assert result is False
        store.close()


class TestIssuerStoreRevocation:
    """Tests for revoke() method and soft-delete behavior."""

    def test_revoke_sets_revoked_at(self, tmp_path: Path) -> None:
        """Test that revoke() sets revoked_at timestamp."""
        store = IssuerStore(tmp_path / "test.db")

        store.add("did:web:example.com", "Example", TrustTier.TIER_1)
        issuer_before = store.get("did:web:example.com")
        assert issuer_before is not None
        assert issuer_before.revoked_at is None

        # Revoke
        result = store.revoke("did:web:example.com")
        assert result is True

        issuer_after = store.get("did:web:example.com")
        assert issuer_after is None

        store.close()

    def test_get_returns_none_for_revoked(self, tmp_path: Path) -> None:
        """Test that get() returns None for revoked issuers."""
        store = IssuerStore(tmp_path / "test.db")

        store.add("did:web:example.com", "Example", TrustTier.TIER_1)
        store.revoke("did:web:example.com")

        assert store.get("did:web:example.com") is None

        store.close()

    def test_get_raw_returns_revoked(self, tmp_path: Path) -> None:
        """Test that get_raw() returns revoked issuers for audit."""
        store = IssuerStore(tmp_path / "test.db")

        store.add("did:web:example.com", "Example", TrustTier.TIER_1)
        store.revoke("did:web:example.com")

        issuer = store.get_raw("did:web:example.com")
        assert issuer is not None
        assert issuer.issuer_did == "did:web:example.com"
        assert issuer.revoked_at is not None
        assert not issuer.is_active()

        store.close()

    def test_revoke_nonexistent(self, tmp_path: Path) -> None:
        """Test that revoke() returns False for missing issuer."""
        store = IssuerStore(tmp_path / "test.db")
        result = store.revoke("did:web:nonexistent.com")
        assert result is False
        store.close()

    def test_list_active_excludes_revoked(self, tmp_path: Path) -> None:
        """Test that list_active() excludes revoked issuers."""
        store = IssuerStore(tmp_path / "test.db")

        store.add("did:web:active1.com", "Active 1", TrustTier.TIER_1)
        store.add("did:web:active2.com", "Active 2", TrustTier.TIER_2)
        store.add("did:web:revoked.com", "Revoked", TrustTier.TIER_3)
        store.revoke("did:web:revoked.com")

        active = store.list_active()
        assert len(active) == 2
        assert all(issuer.is_active() for issuer in active)
        dids = {issuer.issuer_did for issuer in active}
        assert "did:web:active1.com" in dids
        assert "did:web:active2.com" in dids
        assert "did:web:revoked.com" not in dids

        store.close()

    def test_list_all_includes_revoked(self, tmp_path: Path) -> None:
        """Test that list_all() includes revoked issuers."""
        store = IssuerStore(tmp_path / "test.db")

        store.add("did:web:active.com", "Active", TrustTier.TIER_1)
        store.add("did:web:revoked.com", "Revoked", TrustTier.TIER_3)
        store.revoke("did:web:revoked.com")

        all_issuers = store.list_all()
        assert len(all_issuers) == 2
        revoked = [i for i in all_issuers if not i.is_active()]
        assert len(revoked) == 1
        assert revoked[0].issuer_did == "did:web:revoked.com"

        store.close()


class TestIssuerStorePersistence:
    """Tests for schema roundtrip and persistence across opens."""

    def test_persistence_roundtrip(self, tmp_path: Path) -> None:
        """Test that data persists across database open/close cycles."""
        db_path = tmp_path / "persistent.db"

        # Write data
        store1 = IssuerStore(db_path)
        store1.add("did:web:example1.com", "Example 1", TrustTier.TIER_1, "Notes 1")
        store1.add("did:web:example2.com", "Example 2", TrustTier.TIER_2, "Notes 2")
        store1.revoke("did:web:example2.com")
        store1.close()

        # Read data in fresh store instance
        store2 = IssuerStore(db_path)
        issuer1 = store2.get("did:web:example1.com")
        assert issuer1 is not None
        assert issuer1.name == "Example 1"
        assert issuer1.trust_tier == TrustTier.TIER_1
        assert issuer1.notes == "Notes 1"

        issuer2 = store2.get("did:web:example2.com")
        assert issuer2 is None  # Revoked, get() excludes it

        issuer2_raw = store2.get_raw("did:web:example2.com")
        assert issuer2_raw is not None
        assert issuer2_raw.revoked_at is not None

        store2.close()

    def test_multiple_operations_persist(self, tmp_path: Path) -> None:
        """Test that multiple operations (add, update, revoke) persist."""
        db_path = tmp_path / "multi_op.db"

        # Session 1: add and update
        store1 = IssuerStore(db_path)
        store1.add("did:web:test.com", "Initial", TrustTier.TIER_1)
        store1.update_tier("did:web:test.com", TrustTier.TIER_2)
        store1.close()

        # Session 2: verify update persisted, then revoke
        store2 = IssuerStore(db_path)
        issuer = store2.get("did:web:test.com")
        assert issuer is not None
        assert issuer.trust_tier == TrustTier.TIER_2
        store2.revoke("did:web:test.com")
        store2.close()

        # Session 3: verify revocation persisted
        store3 = IssuerStore(db_path)
        assert store3.get("did:web:test.com") is None
        raw = store3.get_raw("did:web:test.com")
        assert raw is not None
        assert raw.revoked_at is not None
        store3.close()


class TestIssuerStoreConcurrency:
    """Tests for thread-safe concurrent access."""

    def test_concurrent_adds(self, tmp_path: Path) -> None:
        """Test that 5 concurrent threads can add distinct issuers."""
        store = IssuerStore(tmp_path / "concurrent.db")
        errors: list[Exception] = []

        def add_issuer(n: int) -> None:
            try:
                store.add(
                    f"did:web:issuer{n}.com",
                    f"Issuer {n}",
                    TrustTier.TIER_1,
                    f"Notes {n}",
                )
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=add_issuer, args=(i,)) for i in range(5)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert not errors, f"Concurrent add failed: {errors}"

        # Verify all 5 issuers are present
        all_issuers = store.list_all()
        assert len(all_issuers) == 5
        dids = {i.issuer_did for i in all_issuers}
        for n in range(5):
            assert f"did:web:issuer{n}.com" in dids

        store.close()

    def test_concurrent_mixed_operations(self, tmp_path: Path) -> None:
        """Test concurrent adds, updates, and revocations."""
        store = IssuerStore(tmp_path / "mixed.db")

        # Pre-populate
        for i in range(10):
            store.add(
                f"did:web:issuer{i}.com",
                f"Issuer {i}",
                TrustTier.TIER_1,
            )

        errors: list[Exception] = []

        def worker(worker_id: int) -> None:
            try:
                if worker_id % 3 == 0:
                    # Update tier
                    store.update_tier(
                        f"did:web:issuer{worker_id}.com",
                        TrustTier.TIER_2,
                    )
                elif worker_id % 3 == 1:
                    # Revoke
                    store.revoke(f"did:web:issuer{worker_id}.com")
                else:
                    # Add new
                    store.add(
                        f"did:web:new{worker_id}.com",
                        f"New Issuer {worker_id}",
                        TrustTier.TIER_3,
                    )
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=worker, args=(i,)) for i in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert not errors, f"Concurrent mixed operations failed: {errors}"

        # Verify final state is consistent
        all_issuers = store.list_all()
        assert len(all_issuers) >= 10  # At least original 10

        store.close()


class TestStoredIssuer:
    """Tests for StoredIssuer dataclass."""

    def test_stored_issuer_is_frozen(self) -> None:
        """Test that StoredIssuer is immutable."""
        issuer = StoredIssuer(
            issuer_did="did:web:example.com",
            name="Example",
            trust_tier=TrustTier.TIER_1,
            added_at="2025-01-01T00:00:00+00:00",
            updated_at="2025-01-01T00:00:00+00:00",
            revoked_at=None,
            notes="test",
        )

        with pytest.raises(AttributeError):
            issuer.name = "Modified"  # type: ignore

    def test_is_active_active(self) -> None:
        """Test is_active() returns True for active issuers."""
        issuer = StoredIssuer(
            issuer_did="did:web:example.com",
            name="Example",
            trust_tier=TrustTier.TIER_1,
            added_at="2025-01-01T00:00:00+00:00",
            updated_at="2025-01-01T00:00:00+00:00",
            revoked_at=None,
            notes="test",
        )
        assert issuer.is_active()

    def test_is_active_revoked(self) -> None:
        """Test is_active() returns False for revoked issuers."""
        issuer = StoredIssuer(
            issuer_did="did:web:example.com",
            name="Example",
            trust_tier=TrustTier.TIER_1,
            added_at="2025-01-01T00:00:00+00:00",
            updated_at="2025-01-01T00:00:00+00:00",
            revoked_at="2025-01-02T00:00:00+00:00",
            notes="test",
        )
        assert not issuer.is_active()


class TestDefaultPathCreation:
    """Tests for default path creation and parent directory handling."""

    def test_default_path_creates_parent_dir(self, tmp_path: Path, monkeypatch) -> None:
        """Test that default path ~/.gtv/federation.db creates parent dirs."""
        # Create a fake home directory
        fake_home = tmp_path / "fake_home"
        fake_home.mkdir()
        monkeypatch.setenv("HOME", str(fake_home))

        store = IssuerStore()  # Uses default path
        assert store.path.parent.exists()

        store.add("did:web:test.com", "Test", TrustTier.TIER_1)
        store.close()

        # Verify database file was created
        assert store.path.exists()
