"""Tests for gtv-verify --offline flag.

Covers:
1. Happy path: stub envelope + --offline --allow-stub exits 0.
2. Missing cert in inclusion_proof + --offline errors loudly.
3. Tampered signature + --offline exits 3.
4. Tampered merkle proof + --offline exits 4.
5. Network disabled via monkeypatch: proves "offline" means no httpx calls.
"""
from __future__ import annotations

import base64
import hashlib
import json
from datetime import UTC, datetime
from pathlib import Path
from unittest import mock

import pytest
from cryptography import x509
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.x509.oid import NameOID

from gtv.cli.verify import verify_file
from gtv.models import AnchorProof, Envelope, Verdict


def _make_test_ecdsa_key() -> tuple[bytes, bytes]:
    """Generate a test ECDSA P-256 key pair and self-signed cert.

    Returns:
        (private_key_pem, certificate_pem) as bytes.
    """
    private_key = ec.generate_private_key(ec.SECP256R1(), default_backend())
    subject = issuer = x509.Name(
        [x509.NameAttribute(NameOID.COMMON_NAME, "test-cert")]
    )

    cert = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(issuer)
        .public_key(private_key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(datetime.now(UTC))
        .not_valid_after(datetime.now(UTC))
        .sign(private_key, hashes.SHA256(), default_backend())
    )

    private_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )

    cert_pem = cert.public_bytes(serialization.Encoding.PEM)

    return private_pem, cert_pem


def _sign_canonical_hash(canonical_hash_hex: str, private_key_pem: bytes) -> str:
    """Sign a canonical hash with an ECDSA private key.

    Args:
        canonical_hash_hex: Hex-encoded SHA-256 hash.
        private_key_pem: ECDSA P-256 private key in PEM format.

    Returns:
        Base64-encoded signature.
    """
    private_key = serialization.load_pem_private_key(
        private_key_pem, password=None, backend=default_backend()
    )

    canonical_hash_bytes = bytes.fromhex(canonical_hash_hex)
    sig_bytes = private_key.sign(canonical_hash_bytes, ec.ECDSA(hashes.SHA256()))

    return base64.b64encode(sig_bytes).decode("ascii")


def _make_test_envelope_and_sign(
    cert_pem: str | None = None,
    rekor_proof: str | None = None,
    private_key_pem: bytes | None = None,
) -> dict:
    """Create a properly signed test envelope.

    Creates the envelope first, computes its canonical hash, signs it with the key,
    then embeds the signature and certificate in the result.

    Args:
        cert_pem: Certificate PEM (defaults to generated test cert).
        rekor_proof: Rekor inclusion proof JSON (defaults to stub).
        private_key_pem: Private key to sign with (defaults to generated key).

    Returns:
        Envelope as dict (signed and ready to verify).
    """
    if cert_pem is None or private_key_pem is None:
        private_key_pem, cert_pem_bytes = _make_test_ecdsa_key()
        cert_pem = cert_pem_bytes.decode("utf-8")

    base_env = Envelope(
        verdict=Verdict.VERIFIED,
        confidence=0.95,
        evidence=[],
        rationale="test rationale",
        issuer_did="did:web:test",
        signature="stub://placeholder",  # Will be replaced with real signature
        rekor_uuid="test-uuid",
        rekor_log_index=0,
        tsa_token="stub://test-tsa",
        prov_graph="{}",
        anchor_proof=AnchorProof(
            rekor_inclusion_proof=rekor_proof or "stub://proof",
            tsa_tsr_primary="stub://tsa",
        ),
    )

    # Compute canonical hash
    from gtv.anchor.canonicalize import envelope_canonical_sha256
    canonical_hash_hex = envelope_canonical_sha256(base_env)

    # Sign it
    sig = _sign_canonical_hash(canonical_hash_hex, private_key_pem)

    # Create the final envelope dict
    env_dict = base_env.model_dump(mode="json")
    env_dict["signature"] = sig

    # Add certificate to inclusion proof
    if rekor_proof:
        proof = json.loads(rekor_proof)
        proof["certificate_pem"] = cert_pem
        env_dict["anchor_proof"]["rekor_inclusion_proof"] = json.dumps(
            proof, sort_keys=True
        )
    else:
        # Create minimal proof with cert
        proof = {"certificate_pem": cert_pem}
        env_dict["anchor_proof"]["rekor_inclusion_proof"] = json.dumps(proof)

    return env_dict


@pytest.fixture
def test_ecdsa_key() -> tuple[bytes, bytes]:
    """Fixture: ECDSA P-256 key pair (private_pem, cert_pem)."""
    return _make_test_ecdsa_key()


def test_offline_stub_signature_with_allow_stub_exits_0(tmp_path: Path) -> None:
    """Stub signature + --offline --allow-stub should exit 0."""
    from gtv.models import AnchorProof, Envelope, Verdict

    base_env = Envelope(
        verdict=Verdict.VERIFIED,
        confidence=0.95,
        evidence=[],
        rationale="test rationale",
        issuer_did="did:web:test",
        signature="stub://test",
        rekor_uuid="test-uuid",
        rekor_log_index=0,
        tsa_token="stub://test-tsa",
        prov_graph="{}",
        anchor_proof=AnchorProof(
            rekor_inclusion_proof="stub://proof",
            tsa_tsr_primary="stub://tsa",
        ),
    )

    env = base_env.model_dump(mode="json")
    envelope_file = tmp_path / "envelope.json"
    envelope_file.write_text(json.dumps(env))

    exit_code = verify_file(envelope_file, allow_stub=True, offline=True)
    assert exit_code == 0


def test_offline_missing_cert_in_proof_exits_3(tmp_path: Path) -> None:
    """Offline verify with missing cert in inclusion_proof should error (exit 3)."""
    private_key_pem, cert_pem_bytes = _make_test_ecdsa_key()

    # Create envelope with cert, then remove it to test missing cert handling
    env = _make_test_envelope_and_sign(
        cert_pem=cert_pem_bytes.decode("utf-8"),
        private_key_pem=private_key_pem,
        rekor_proof='{"log_index": 0, "tree_size": 1, "root_hash": "deadbeef", "hashes": []}',
    )

    # Remove cert from proof JSON to trigger error
    env["anchor_proof"]["rekor_inclusion_proof"] = json.dumps({
        "log_index": 0,
        "tree_size": 1,
        "root_hash": "deadbeef",
        "hashes": [],
    })

    envelope_file = tmp_path / "envelope.json"
    envelope_file.write_text(json.dumps(env))

    # Should fail with signature verification error (cert not found)
    exit_code = verify_file(envelope_file, offline=True, allow_unrooted=True)
    assert exit_code == 3  # Signature verification requires cert


def test_offline_tampered_signature_exits_3(tmp_path: Path, test_ecdsa_key: tuple[bytes, bytes]) -> None:
    """Offline verify with tampered signature should exit 3."""
    private_key_pem, cert_pem_bytes = test_ecdsa_key
    cert_pem = cert_pem_bytes.decode("utf-8")

    # Create a properly signed envelope
    env = _make_test_envelope_and_sign(
        cert_pem=cert_pem,
        private_key_pem=private_key_pem,
        rekor_proof='{"log_index": 0, "tree_size": 1, "root_hash": "deadbeef", "hashes": []}',
    )

    # Tamper with the signature
    sig = env["signature"]
    sig_bytes = base64.b64decode(sig)
    tampered_sig_bytes = bytes([(b + 1) % 256 for b in sig_bytes])
    tampered_sig = base64.b64encode(tampered_sig_bytes).decode("ascii")
    env["signature"] = tampered_sig

    envelope_file = tmp_path / "envelope.json"
    envelope_file.write_text(json.dumps(env))

    exit_code = verify_file(envelope_file, offline=True, allow_unrooted=True)
    assert exit_code == 3  # Signature mismatch


def test_offline_tampered_merkle_proof_exits_4(tmp_path: Path, test_ecdsa_key: tuple[bytes, bytes]) -> None:
    """Offline verify with tampered merkle proof should exit 4."""
    private_key_pem, cert_pem_bytes = test_ecdsa_key
    cert_pem = cert_pem_bytes.decode("utf-8")

    # Create a properly signed envelope with a valid proof first
    env = _make_test_envelope_and_sign(
        cert_pem=cert_pem,
        private_key_pem=private_key_pem,
        rekor_proof='{"log_index": 0, "tree_size": 1, "root_hash": "deadbeefdeadbeefdeadbeefdeadbeefdeadbeefdeadbeefdeadbeefdeadbeef", "hashes": []}',
    )

    # Tamper with the root hash in the proof
    proof = json.loads(env["anchor_proof"]["rekor_inclusion_proof"])
    proof["root_hash"] = "badbadbabadbadbabadbadbabadbadbabadbadbabadbadbabadbadbadbadba"
    env["anchor_proof"]["rekor_inclusion_proof"] = json.dumps(proof)

    envelope_file = tmp_path / "envelope.json"
    envelope_file.write_text(json.dumps(env))

    exit_code = verify_file(envelope_file, offline=True, allow_unrooted=True)
    assert exit_code == 4  # Rekor proof mismatch


def test_offline_no_network_calls(tmp_path: Path, test_ecdsa_key: tuple[bytes, bytes]) -> None:
    """Prove that --offline never calls httpx.AsyncClient.get."""
    import httpx

    private_key_pem, cert_pem_bytes = test_ecdsa_key
    cert_pem = cert_pem_bytes.decode("utf-8")

    # Create base envelope first
    base_env = Envelope(
        verdict=Verdict.VERIFIED,
        confidence=0.95,
        evidence=[],
        rationale="test rationale",
        issuer_did="did:web:test",
        signature="stub://placeholder",
        rekor_uuid="test-uuid",
        rekor_log_index=0,
        tsa_token="stub://test-tsa",
        prov_graph="{}",
        anchor_proof=AnchorProof(
            rekor_inclusion_proof="stub://placeholder",
            tsa_tsr_primary="stub://tsa",
        ),
    )

    from gtv.anchor.canonicalize import envelope_canonical_sha256
    from gtv.anchor.rekor import hashedrekord_leaf_hash
    canonical_hash_hex = envelope_canonical_sha256(base_env)

    # Sign the canonical hash, then compute the real Rekor leaf from the
    # hashedrekord body (needs sig + cert).
    sig = _sign_canonical_hash(canonical_hash_hex, private_key_pem)
    expected_root = hashedrekord_leaf_hash(canonical_hash_hex, sig, cert_pem)

    proof = {
        "log_index": 0,
        "tree_size": 1,
        "root_hash": expected_root.hex(),
        "hashes": [],
        "certificate_pem": cert_pem,
    }

    # Create final envelope
    env_dict = base_env.model_dump(mode="json")
    env_dict["signature"] = sig
    env_dict["anchor_proof"]["rekor_inclusion_proof"] = json.dumps(proof)

    envelope_file = tmp_path / "envelope.json"
    envelope_file.write_text(json.dumps(env_dict))

    # Monkeypatch to track if httpx.AsyncClient.get is called
    with mock.patch.object(httpx.AsyncClient, "get") as mock_get:
        mock_get.side_effect = RuntimeError("Network call attempted in offline mode!")
        exit_code = verify_file(
            envelope_file,
            offline=True,
            allow_unrooted=True,
        )

    # Should succeed without calling get
    assert exit_code == 0
    mock_get.assert_not_called()


def test_offline_skips_issuer_check_when_offline(tmp_path: Path, test_ecdsa_key: tuple[bytes, bytes]) -> None:
    """Verify that --offline skips issuer identity check."""
    private_key_pem, cert_pem_bytes = test_ecdsa_key
    cert_pem = cert_pem_bytes.decode("utf-8")

    # Create base envelope first
    base_env = Envelope(
        verdict=Verdict.VERIFIED,
        confidence=0.95,
        evidence=[],
        rationale="test rationale",
        issuer_did="did:web:test",
        signature="stub://placeholder",
        rekor_uuid="test-uuid",
        rekor_log_index=0,
        tsa_token="stub://test-tsa",
        prov_graph="{}",
        anchor_proof=AnchorProof(
            rekor_inclusion_proof="stub://placeholder",
            tsa_tsr_primary="stub://tsa",
        ),
    )

    from gtv.anchor.canonicalize import envelope_canonical_sha256
    from gtv.anchor.rekor import hashedrekord_leaf_hash
    canonical_hash_hex = envelope_canonical_sha256(base_env)

    # Sign the canonical hash, then compute the real Rekor leaf from the
    # hashedrekord body (needs sig + cert).
    sig = _sign_canonical_hash(canonical_hash_hex, private_key_pem)
    expected_root = hashedrekord_leaf_hash(canonical_hash_hex, sig, cert_pem)

    proof = {
        "log_index": 0,
        "tree_size": 1,
        "root_hash": expected_root.hex(),
        "hashes": [],
        "certificate_pem": cert_pem,
    }

    # Create final envelope
    env_dict = base_env.model_dump(mode="json")
    env_dict["signature"] = sig
    env_dict["anchor_proof"]["rekor_inclusion_proof"] = json.dumps(proof)

    envelope_file = tmp_path / "envelope.json"
    envelope_file.write_text(json.dumps(env_dict))

    # Monkeypatch resolve_did_web to fail if called
    with mock.patch("gtv.cli.verify.resolve_did_web") as mock_resolve:
        mock_resolve.side_effect = RuntimeError("DID resolution attempted in offline mode!")
        exit_code = verify_file(
            envelope_file,
            offline=True,
            allow_unrooted=True,
        )

    # Should succeed without calling resolve_did_web
    assert exit_code == 0
    mock_resolve.assert_not_called()


def test_offline_with_valid_merkle_proof_exits_0(tmp_path: Path, test_ecdsa_key: tuple[bytes, bytes]) -> None:
    """Test complete offline verification with valid signature and merkle proof."""
    private_key_pem, cert_pem_bytes = test_ecdsa_key
    cert_pem = cert_pem_bytes.decode("utf-8")

    # Create a base envelope without signature/proof to compute canonical hash
    base_env = Envelope(
        verdict=Verdict.VERIFIED,
        confidence=0.95,
        evidence=[],
        rationale="test rationale",
        issuer_did="did:web:test",
        signature="stub://placeholder",
        rekor_uuid="test-uuid",
        rekor_log_index=0,
        tsa_token="stub://test-tsa",
        prov_graph="{}",
        anchor_proof=AnchorProof(
            rekor_inclusion_proof="stub://placeholder",
            tsa_tsr_primary="stub://tsa",
        ),
    )

    # Compute canonical hash for this envelope structure
    from gtv.anchor.canonicalize import envelope_canonical_sha256
    from gtv.anchor.rekor import hashedrekord_leaf_hash
    canonical_hash_hex = envelope_canonical_sha256(base_env)

    # Sign now so the hashedrekord leaf hash can be computed.
    sig = _sign_canonical_hash(canonical_hash_hex, private_key_pem)
    expected_root = hashedrekord_leaf_hash(canonical_hash_hex, sig, cert_pem)

    proof = {
        "log_index": 0,
        "tree_size": 1,
        "root_hash": expected_root.hex(),
        "hashes": [],
        "certificate_pem": cert_pem,
    }

    # Create final envelope
    env_dict = base_env.model_dump(mode="json")
    env_dict["signature"] = sig
    env_dict["anchor_proof"]["rekor_inclusion_proof"] = json.dumps(proof)

    envelope_file = tmp_path / "envelope.json"
    envelope_file.write_text(json.dumps(env_dict))

    exit_code = verify_file(envelope_file, offline=True, allow_unrooted=True)
    assert exit_code == 0


def test_offline_integration_happy_path(tmp_path: Path, test_ecdsa_key: tuple[bytes, bytes]) -> None:
    """Integration test: full offline verification stack with real keys and proofs."""
    private_key_pem, cert_pem_bytes = test_ecdsa_key
    cert_pem = cert_pem_bytes.decode("utf-8")

    # Create base envelope
    base_env = Envelope(
        verdict=Verdict.VERIFIED,
        confidence=0.95,
        evidence=[],
        rationale="test rationale",
        issuer_did="did:web:test",
        signature="stub://placeholder",
        rekor_uuid="test-uuid",
        rekor_log_index=0,
        tsa_token="stub://test-tsa",
        prov_graph="{}",
        anchor_proof=AnchorProof(
            rekor_inclusion_proof="stub://placeholder",
            tsa_tsr_primary="stub://tsa",
        ),
    )

    # Compute canonical hash for this envelope
    from gtv.anchor.canonicalize import envelope_canonical_sha256
    from gtv.anchor.rekor import hashedrekord_leaf_hash
    canonical_hash_hex = envelope_canonical_sha256(base_env)

    # Sign now so the hashedrekord leaf hash can be computed from (hash, sig, cert).
    sig = _sign_canonical_hash(canonical_hash_hex, private_key_pem)
    leaf_hash = hashedrekord_leaf_hash(canonical_hash_hex, sig, cert_pem)

    # Sibling is on the left (32-byte hash)
    sibling_hash = hashlib.sha256(b"sibling leaf").digest()
    sibling_hash_hex = sibling_hash.hex()

    # Merkle root = sha256(0x01 || sibling || leaf)
    root_input = bytes([0x01]) + sibling_hash + leaf_hash
    expected_root = hashlib.sha256(root_input).digest()

    proof = {
        "log_index": 1,
        "tree_size": 2,
        "root_hash": expected_root.hex(),
        "hashes": [sibling_hash_hex],
        "certificate_pem": cert_pem,
    }

    # Create final envelope
    env_dict = base_env.model_dump(mode="json")
    env_dict["signature"] = sig
    env_dict["anchor_proof"]["rekor_inclusion_proof"] = json.dumps(proof)

    envelope_file = tmp_path / "envelope.json"
    envelope_file.write_text(json.dumps(env_dict))

    exit_code = verify_file(envelope_file, offline=True, allow_unrooted=True)
    assert exit_code == 0
