"""Unit tests for the PII redactor.

Covers every built-in rule, the Luhn and IPv4 post-filters,
environment-driven extra patterns, and the `GTV_REDACT_ENABLED` toggle.
"""
from __future__ import annotations

import pytest

from gtv.redact import contains_pii, redact_envelope_fields, redact_text
from gtv.redact.redactor import Redactor, reset_default_redactor_for_tests


@pytest.fixture(autouse=True)
def _reset_singleton() -> None:
    """The module-level redactor caches env at first use; drop it so
    each test observes its own env. Must run before AND after — a test
    that sets an env and uses the default redactor would otherwise leak
    its singleton into the next test."""
    reset_default_redactor_for_tests()
    yield
    reset_default_redactor_for_tests()


# ---------------------------------------------------------------------
# Built-in rules
# ---------------------------------------------------------------------


def test_email_redacted() -> None:
    r = Redactor()
    out = r.redact("Contact alice.smith+gtv@example.co.uk for details.")
    assert "[REDACTED:EMAIL]" in out.text
    assert "alice.smith+gtv@example.co.uk" not in out.text
    assert out.counts == {"EMAIL": 1}


def test_ssn_redacted() -> None:
    r = Redactor()
    out = r.redact("SSN 123-45-6789 was leaked.")
    assert "[REDACTED:SSN]" in out.text
    assert "123-45-6789" not in out.text


def test_ssn_ignores_obvious_non_ssns() -> None:
    """ISBN-like 3-2-4 hyphenated groups that are obvious non-SSNs
    (000 area, 666 area, 900+ area) must NOT match."""
    r = Redactor()
    assert r.redact("000-12-3456 is not an SSN").counts == {}
    assert r.redact("666-12-3456 is not an SSN").counts == {}
    assert r.redact("987-12-3456 is not an SSN").counts == {}


def test_cc_requires_luhn() -> None:
    r = Redactor()
    # Valid Visa test number (Luhn-clean)
    out = r.redact("Card: 4111 1111 1111 1111 expires soon.")
    assert "[REDACTED:CC]" in out.text
    assert out.counts == {"CC": 1}
    # Not Luhn-clean → not redacted.
    out2 = r.redact("Card: 4111 1111 1111 1112 fails luhn.")
    assert "4111 1111 1111 1112" in out2.text
    assert out2.counts == {}


def test_ipv4_requires_valid_octets() -> None:
    r = Redactor()
    out = r.redact("Src ip 192.168.1.1 hit the firewall.")
    assert "[REDACTED:IPV4]" in out.text
    # Four numeric segments but octet > 255 → not an IP.
    out2 = r.redact("Version string 999.999.999.999 is not an IP.")
    assert "999.999.999.999" in out2.text
    assert out2.counts == {}


def test_phone_formats() -> None:
    r = Redactor()
    for phone in ("+1 415 555 1212", "(415) 555-1212", "1-415-555-1212"):
        out = r.redact(f"Call {phone} for details.")
        assert "[REDACTED:PHONE]" in out.text
        assert phone not in out.text


def test_phone_ignores_bare_ten_digit_numbers() -> None:
    """Adapters return chemistry / physics numbers all the time; a
    bare ten-digit sequence without +/1-/() should NOT be treated as
    a phone number."""
    r = Redactor()
    out = r.redact("The constant is 6022141290 x 10^23.")
    # Might still match CC rule if Luhn-clean — but shouldn't match PHONE.
    assert "PHONE" not in out.counts


def test_iban_redacted() -> None:
    r = Redactor()
    out = r.redact("Wire to GB82WEST12345698765432 immediately.")
    assert "[REDACTED:IBAN]" in out.text
    assert out.counts == {"IBAN": 1}


def test_api_keys_redacted() -> None:
    r = Redactor()
    aws = "AKIAIOSFODNN7EXAMPLE"
    gh = "ghp_" + "A" * 36
    slack = "xoxb-1234567890-abcdef12345"
    jwt = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjMifQ.abcdefghijklmno"
    bearer = "Bearer " + "A" * 30
    text = f"keys: {aws} {gh} {slack} {jwt} {bearer}"
    out = r.redact(text)
    for secret in (aws, gh, slack, jwt):
        assert secret not in out.text
    assert out.counts.get("AWS_AKID", 0) == 1
    assert out.counts.get("GH_PAT", 0) == 1
    assert out.counts.get("SLACK", 0) == 1
    assert out.counts.get("JWT", 0) == 1
    assert out.counts.get("BEARER", 0) == 1


def test_multiple_matches_counted() -> None:
    r = Redactor()
    out = r.redact("emails: a@b.co, c@d.io, e@f.org")
    assert out.counts == {"EMAIL": 3}
    assert out.text.count("[REDACTED:EMAIL]") == 3


def test_scientific_claim_is_not_redacted() -> None:
    """Regression guard: the archetypal STEM claim must pass through
    clean. No false positives on physics constants."""
    r = Redactor()
    out = r.redact("The speed of light is 299,792,458 m/s in vacuum.")
    assert out.counts == {}
    assert out.text == "The speed of light is 299,792,458 m/s in vacuum."


def test_empty_string_is_safe() -> None:
    r = Redactor()
    out = r.redact("")
    assert out.text == ""
    assert out.counts == {}


def test_redaction_result_helpers() -> None:
    r = Redactor()
    out = r.redact("a@b.co and c@d.io")
    assert out.any_redacted is True
    assert out.total == 2

    clean = r.redact("just some text")
    assert clean.any_redacted is False
    assert clean.total == 0


# ---------------------------------------------------------------------
# Extra patterns via env
# ---------------------------------------------------------------------


def test_extra_patterns_from_env(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("GTV_REDACT_EXTRA_PATTERNS", r"EMP_ID=EMP-\d{6}")
    reset_default_redactor_for_tests()
    out = redact_text("User EMP-123456 logged in.")
    assert "[REDACTED:EMP_ID]" in out.text
    assert out.counts == {"EMP_ID": 1}


def test_extra_patterns_malformed_are_ignored(monkeypatch: pytest.MonkeyPatch) -> None:
    # `[` is an invalid regex; the malformed rule should be skipped and
    # the redactor should still work for built-ins.
    monkeypatch.setenv(
        "GTV_REDACT_EXTRA_PATTERNS",
        r"BROKEN=[;;=;EMP_ID=EMP-\d{6}",
    )
    reset_default_redactor_for_tests()
    out = redact_text("User EMP-123456 a@b.co logged in.")
    # Built-in email still works.
    assert out.counts.get("EMAIL") == 1
    # Valid custom rule still works.
    assert out.counts.get("EMP_ID") == 1


# ---------------------------------------------------------------------
# Env toggle
# ---------------------------------------------------------------------


def test_disabled_flag_passes_through(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("GTV_REDACT_ENABLED", "0")
    reset_default_redactor_for_tests()
    out = redact_text("leak alice@example.com now")
    assert out.text == "leak alice@example.com now"
    assert out.counts == {}


def test_contains_pii_always_runs(monkeypatch: pytest.MonkeyPatch) -> None:
    """Input-side guard is security-critical; it must NOT be affected
    by GTV_REDACT_ENABLED=0 (which is a dev-only convenience)."""
    monkeypatch.setenv("GTV_REDACT_ENABLED", "0")
    reset_default_redactor_for_tests()
    assert contains_pii("email a@b.co") is True
    assert contains_pii("speed of light 299792458 m/s") is False


# ---------------------------------------------------------------------
# Envelope-field helper
# ---------------------------------------------------------------------


def test_redact_envelope_fields_merges_counts() -> None:
    rationale = "Per alice@example.com, the mass is 2.5 kg."
    excerpts = [
        "SSN on file: 123-45-6789",
        "Nothing sensitive in this excerpt.",
        "Call 1-415-555-1212 for a source.",
    ]
    r_out, ex_out, counts = redact_envelope_fields(
        rationale=rationale, evidence_excerpts=excerpts
    )
    assert "alice@example.com" not in r_out
    assert "123-45-6789" not in ex_out[0]
    assert ex_out[1] == "Nothing sensitive in this excerpt."
    assert "1-415-555-1212" not in ex_out[2]
    assert counts["EMAIL"] == 1
    assert counts["SSN"] == 1
    assert counts["PHONE"] == 1


def test_redact_envelope_fields_disabled(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("GTV_REDACT_ENABLED", "0")
    reset_default_redactor_for_tests()
    r_out, ex_out, counts = redact_envelope_fields(
        rationale="email a@b.co", evidence_excerpts=["SSN 123-45-6789"]
    )
    assert r_out == "email a@b.co"
    assert ex_out == ["SSN 123-45-6789"]
    assert counts == {}
