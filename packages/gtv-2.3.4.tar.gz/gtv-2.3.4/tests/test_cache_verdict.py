"""Unit tests for the signed verdict cache.

Exercises: hit/miss bookkeeping, TTL expiry, signature-mismatch eviction,
deserialize-error eviction, and the env-based factory.
"""
from __future__ import annotations

import asyncio
import json
import os
import time
from unittest.mock import patch

import pytest

from gtv.anchor.canonicalize import envelope_canonical_sha256
from gtv.cache import (
    CacheKey,
    InMemoryCacheStore,
    NullCacheStore,
    VerdictCache,
    build_key,
    make_cache_from_env,
)
from gtv.models import AnchorProof, Envelope, Verdict


def _fresh_envelope(rationale: str = "test", evidence: list | None = None) -> Envelope:
    """Build a valid stub-signed envelope for tests.

    Mirrors the server's `_seal_envelope` shape: build a partial, compute
    the canonical hash, sign it via the same stub signer, and return a
    fully populated envelope.
    """
    from gtv.anchor.sign import sign_hash

    evidence_list = evidence or []
    partial = Envelope.model_construct(
        verdict=Verdict.VERIFIED,
        confidence=0.9,
        evidence=evidence_list,
        rationale=rationale,
        issuer_did="did:web:test.example",
        signature="",
        rekor_uuid="",
        rekor_log_index=0,
        tsa_token="stub://dev",
        prov_graph="{}",
        anchor_proof=AnchorProof(
            rekor_inclusion_proof="stub://pending",
            tsa_tsr_primary="stub://dev",
            tsa_tsr_secondary=None,
        ),
    )
    canonical_hex = envelope_canonical_sha256(partial)
    signed = sign_hash(canonical_hex)
    return Envelope(
        verdict=Verdict.VERIFIED,
        confidence=0.9,
        evidence=evidence_list,
        rationale=rationale,
        issuer_did="did:web:test.example",
        signature=signed.signature_bundle.signature_b64,
        rekor_uuid=signed.rekor_entry.uuid,
        rekor_log_index=signed.rekor_entry.log_index,
        tsa_token="stub://dev",
        prov_graph="{}",
        anchor_proof=AnchorProof(
            rekor_inclusion_proof=signed.rekor_entry.inclusion_proof,
            tsa_tsr_primary="stub://dev",
            tsa_tsr_secondary=None,
        ),
    )


def _key() -> CacheKey:
    return build_key(
        claim_text="The sky is blue.",
        domain="physics",
        max_sources=3,
        issuer_did="did:web:test.example",
    )


@pytest.mark.asyncio
async def test_miss_then_set_then_hit() -> None:
    cache = VerdictCache(InMemoryCacheStore())
    key = _key()
    env = _fresh_envelope()

    assert await cache.get(key) is None
    assert cache.stats.misses == 1
    assert cache.stats.hits == 0

    await cache.set(key, env)
    got = await cache.get(key)
    assert got is not None
    assert got.verdict == env.verdict
    assert cache.stats.hits == 1


@pytest.mark.asyncio
async def test_invalidate_drops_entry() -> None:
    cache = VerdictCache(InMemoryCacheStore())
    key = _key()
    await cache.set(key, _fresh_envelope())
    assert await cache.get(key) is not None

    await cache.invalidate(key)
    assert await cache.get(key) is None


@pytest.mark.asyncio
async def test_clear_drops_everything() -> None:
    cache = VerdictCache(InMemoryCacheStore())
    await cache.set(_key(), _fresh_envelope())
    await cache.clear()
    assert await cache.get(_key()) is None


@pytest.mark.asyncio
async def test_tampered_envelope_is_evicted() -> None:
    """Flip a byte in the cached payload → re-validation fails → miss."""
    store = InMemoryCacheStore()
    cache = VerdictCache(store)
    key = _key()
    env = _fresh_envelope()
    await cache.set(key, env)

    # Tamper: mutate the rationale directly in the stored bytes, which
    # will change the canonical hash and invalidate the stub signature.
    raw = await store.get(key.digest)
    assert raw is not None
    tampered = raw.replace(b'"rationale":"test"', b'"rationale":"hack"')
    assert tampered != raw
    await store.set(key.digest, tampered, ttl_s=60)

    result = await cache.get(key)
    assert result is None
    assert cache.stats.signature_rejections == 1
    # Entry should have been evicted on the failed read.
    assert await store.get(key.digest) is None


@pytest.mark.asyncio
async def test_corrupt_bytes_are_evicted() -> None:
    store = InMemoryCacheStore()
    cache = VerdictCache(store)
    key = _key()
    await store.set(key.digest, b"not-json", ttl_s=60)

    assert await cache.get(key) is None
    assert cache.stats.deserialize_errors == 1
    assert await store.get(key.digest) is None


@pytest.mark.asyncio
async def test_ttl_expiry_causes_miss() -> None:
    store = InMemoryCacheStore()
    # Override TTL range so default_ttl clamp is tight — 1s.
    cache = VerdictCache(store, default_ttl_s=1, ttl_min_s=1, ttl_max_s=1)
    key = _key()
    await cache.set(key, _fresh_envelope())

    # Monkeypatch time.monotonic to jump forward past the TTL.
    original = time.monotonic
    with patch("gtv.cache.store.time.monotonic", return_value=original() + 10):
        assert await cache.get(key) is None
    assert cache.stats.misses == 1


@pytest.mark.asyncio
async def test_null_store_always_misses() -> None:
    cache = VerdictCache(NullCacheStore())
    await cache.set(_key(), _fresh_envelope())
    assert await cache.get(_key()) is None


def test_make_cache_from_env_default() -> None:
    os.environ.pop("GTV_CACHE_ENABLED", None)
    os.environ.pop("GTV_CACHE_REDIS_URL", None)
    cache = make_cache_from_env()
    assert isinstance(cache, VerdictCache)


def test_make_cache_from_env_disabled() -> None:
    with patch.dict(os.environ, {"GTV_CACHE_ENABLED": "0"}, clear=False):
        cache = make_cache_from_env()
        # Null store → set+get always returns None.

        async def roundtrip() -> Envelope | None:
            await cache.set(_key(), _fresh_envelope())
            return await cache.get(_key())

        assert asyncio.run(roundtrip()) is None


def test_make_cache_from_env_ttl_override() -> None:
    with patch.dict(
        os.environ,
        {"GTV_CACHE_TTL_S": "42", "GTV_CACHE_TTL_MIN_S": "2", "GTV_CACHE_TTL_MAX_S": "600"},
        clear=False,
    ):
        cache = make_cache_from_env()
        # Poke private fields to confirm env parsing worked.
        assert cache._default_ttl_s == 42
        assert cache._ttl_min_s == 2
        assert cache._ttl_max_s == 600


@pytest.mark.asyncio
async def test_ttl_clamps_default_when_no_evidence() -> None:
    cache = VerdictCache(InMemoryCacheStore(), default_ttl_s=7, ttl_min_s=1, ttl_max_s=60)
    env = _fresh_envelope()  # no evidence
    ttl = cache._compute_ttl(env)
    assert ttl == 7


@pytest.mark.asyncio
async def test_ttl_honors_evidence_sla() -> None:
    """Evidence from a registered adapter → TTL = min(adapter SLAs) clamped."""
    from datetime import UTC, datetime

    from pydantic import HttpUrl

    from gtv.adapters import REGISTRY
    from gtv.adapters.base import HealthStatus, RawSnapshot, SourceAdapter
    from gtv.models import Claim, Evidence, SourceType, Stance, TrustTier

    class _SlowAdapter(SourceAdapter):
        source_did = "did:web:slow.example"
        name = "slow"
        source_type = SourceType.REFERENCE_DATA
        trust_tier = TrustTier.TIER_1
        freshness_sla_s = 10

        async def query(self, claim: Claim, max_items: int = 5) -> list[Evidence]:
            return []

        async def snapshot(self, url: str) -> RawSnapshot:
            return RawSnapshot(url=url, content=b"", retrieved_at_iso="")

        async def health(self) -> HealthStatus:
            return HealthStatus(state="HEALTHY", detail="")

        async def close(self) -> None:
            return None

    adapter = _SlowAdapter()
    REGISTRY[adapter.source_did] = adapter
    try:
        evidence = Evidence(
            claim_id="test-claim-id",
            source_did=adapter.source_did,
            source_version="v1",
            stance=Stance.SUPPORTS,
            excerpt="e",
            url=HttpUrl("https://slow.example/x"),
            retrieved_at=datetime.now(tz=UTC),
            raw_hash="0" * 64,
        )
        env = _fresh_envelope(rationale="r", evidence=[evidence])
        cache = VerdictCache(
            InMemoryCacheStore(), default_ttl_s=600, ttl_min_s=1, ttl_max_s=3600
        )
        assert cache._compute_ttl(env) == 10
    finally:
        REGISTRY.pop(adapter.source_did, None)


@pytest.mark.asyncio
async def test_deserialize_path_handles_truncated_json() -> None:
    store = InMemoryCacheStore()
    cache = VerdictCache(store)
    key = _key()
    env = _fresh_envelope()
    await cache.set(key, env)

    # Truncate the bytes to force a JSON parse error.
    raw = await store.get(key.digest)
    assert raw is not None
    await store.set(key.digest, raw[:20], ttl_s=60)

    assert await cache.get(key) is None
    assert cache.stats.deserialize_errors == 1


@pytest.mark.asyncio
async def test_round_trip_preserves_all_fields() -> None:
    cache = VerdictCache(InMemoryCacheStore())
    key = _key()
    env = _fresh_envelope()
    await cache.set(key, env)
    got = await cache.get(key)
    assert got is not None
    # Full-envelope equality via canonical JSON — easiest sanity check.
    assert json.loads(got.model_dump_json()) == json.loads(env.model_dump_json())
