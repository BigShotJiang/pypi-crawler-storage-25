"""Tests for the ``gtv.verdict.decide`` dispatcher.

Covers both branches of the dispatcher: the default rule-based path and
the ``GTV_USE_LEARNED_RANKER=1`` opt-in that swaps to the learned ranker.
"""
from __future__ import annotations

from datetime import UTC, datetime
from unittest.mock import patch

import pytest

from gtv.models import Claim, Domain, Evidence, Stance, TrustTier, Verdict
from gtv.verdict import decide
from gtv.verdict.engine import VerdictInputs


@pytest.fixture
def supported_claim_inputs() -> VerdictInputs:
    """Inputs that should resolve to VERIFIED under either engine."""
    claim = Claim(
        claim_id="test-claim",
        text="The Earth orbits the Sun.",
        domain=Domain.GENERAL,
        submitted_at=datetime.now(tz=UTC),
    )
    evidence = [
        Evidence(
            evidence_id=f"ev-{i}",
            claim_id="test-claim",
            source_did=f"did:web:source-{i}",
            source_version="v1",
            stance=Stance.SUPPORTS,
            excerpt="Heliocentric.",
            url=f"https://example.com/{i}",
            retrieved_at=datetime.now(tz=UTC),
            raw_hash="0" * 64,
        )
        for i in range(3)
    ]
    tier_of = {e.source_did: TrustTier.TIER_1 for e in evidence}
    return VerdictInputs(claim=claim, evidence=evidence, tier_of=tier_of)


def test_decide_defaults_to_rule_based(supported_claim_inputs: VerdictInputs) -> None:
    """Without the env flag, decide() routes to the rule-based engine."""
    with patch.dict("os.environ", {}, clear=False):
        import os

        os.environ.pop("GTV_USE_LEARNED_RANKER", None)
        record = decide(supported_claim_inputs)
    assert record.decision == Verdict.VERIFIED
    # Rule-based rationale mentions distinct sources; learned mentions confidence %.
    assert "independent sources" in record.rationale


def test_decide_routes_to_learned_ranker_when_flag_set(
    supported_claim_inputs: VerdictInputs,
) -> None:
    """With GTV_USE_LEARNED_RANKER=1, decide() invokes the learned ranker."""
    with patch.dict("os.environ", {"GTV_USE_LEARNED_RANKER": "1"}):
        record = decide(supported_claim_inputs)
    assert record.decision == Verdict.VERIFIED
    assert "Learned ranker" in record.rationale


def test_decide_flag_unset_equals_zero_equals_rule_based(
    supported_claim_inputs: VerdictInputs,
) -> None:
    """Only the exact string '1' enables the learned ranker — other values fall back."""
    for val in ("", "0", "false", "yes", "true"):
        with patch.dict("os.environ", {"GTV_USE_LEARNED_RANKER": val}):
            record = decide(supported_claim_inputs)
        assert record.decision == Verdict.VERIFIED
        assert "independent sources" in record.rationale, (
            f"Value {val!r} incorrectly routed to learned ranker"
        )
