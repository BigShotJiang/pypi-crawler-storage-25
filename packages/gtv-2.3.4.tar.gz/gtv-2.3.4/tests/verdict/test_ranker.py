"""Tests for the learned verdict ranker."""
from __future__ import annotations

from datetime import UTC, datetime

import pytest

from gtv.models import Claim, Domain, Evidence, Stance, TrustTier, Verdict
from gtv.verdict.engine import VerdictInputs
from gtv.verdict.ranker import LearnedRanker


@pytest.fixture
def ranker() -> LearnedRanker:
    """Instantiate a default ranker."""
    return LearnedRanker()


@pytest.fixture
def simple_claim() -> Claim:
    """A simple test claim."""
    return Claim(
        claim_id="test-claim-1",
        text="The Earth is round.",
        domain=Domain.GENERAL,
        submitted_at=datetime.now(tz=UTC),
    )


@pytest.fixture
def tier1_support_evidence() -> Evidence:
    """TIER_1 supporting evidence."""
    return Evidence(
        evidence_id="ev-1",
        claim_id="test-claim-1",
        source_did="source-tier1",
        source_version="v1.0",
        stance=Stance.SUPPORTS,
        excerpt="The Earth is spherical.",
        url="https://example.com/sphere",
        retrieved_at=datetime.now(tz=UTC),
        raw_hash="a" * 64,
    )


@pytest.fixture
def tier2_support_evidence() -> Evidence:
    """TIER_2 supporting evidence."""
    return Evidence(
        evidence_id="ev-2",
        claim_id="test-claim-1",
        source_did="source-tier2",
        source_version="v1.0",
        stance=Stance.SUPPORTS,
        excerpt="Evidence of roundness.",
        url="https://example.com/evidence",
        retrieved_at=datetime.now(tz=UTC),
        raw_hash="b" * 64,
    )


@pytest.fixture
def tier1_refute_evidence() -> Evidence:
    """TIER_1 refuting evidence."""
    return Evidence(
        evidence_id="ev-3",
        claim_id="test-claim-1",
        source_did="source-refute",
        source_version="v1.0",
        stance=Stance.REFUTES,
        excerpt="The Earth is flat.",
        url="https://example.com/flat",
        retrieved_at=datetime.now(tz=UTC),
        raw_hash="c" * 64,
    )


class TestScoreReturnsFloat:
    """test_score_returns_float"""

    def test_score_returns_float_for_fresh_evidence(
        self, ranker: LearnedRanker, simple_claim: Claim, tier1_support_evidence: Evidence
    ) -> None:
        """score() returns a float."""
        inputs = VerdictInputs(
            claim=simple_claim,
            evidence=[tier1_support_evidence],
            is_opinion=False,
            is_creative=False,
            tier_of={"source-tier1": TrustTier.TIER_1},
        )
        score = ranker.score(inputs)
        assert isinstance(score, float)

    def test_score_returns_float_for_empty_evidence(
        self, ranker: LearnedRanker, simple_claim: Claim
    ) -> None:
        """score() returns float even with no evidence."""
        inputs = VerdictInputs(
            claim=simple_claim,
            evidence=[],
            is_opinion=False,
            is_creative=False,
            tier_of=None,
        )
        score = ranker.score(inputs)
        assert isinstance(score, float)


class TestPredictProbaInZeroOne:
    """test_predict_proba_in_zero_one"""

    def test_predict_proba_in_zero_one_strong_support(
        self, ranker: LearnedRanker, simple_claim: Claim, tier1_support_evidence: Evidence
    ) -> None:
        """predict_proba() returns value in [0, 1]."""
        inputs = VerdictInputs(
            claim=simple_claim,
            evidence=[tier1_support_evidence],
            is_opinion=False,
            is_creative=False,
            tier_of={"source-tier1": TrustTier.TIER_1},
        )
        proba = ranker.predict_proba(inputs)
        assert 0.0 <= proba <= 1.0

    def test_predict_proba_in_zero_one_no_evidence(
        self, ranker: LearnedRanker, simple_claim: Claim
    ) -> None:
        """predict_proba() stays in [0, 1] with no evidence."""
        inputs = VerdictInputs(
            claim=simple_claim,
            evidence=[],
            is_opinion=False,
            is_creative=False,
            tier_of=None,
        )
        proba = ranker.predict_proba(inputs)
        assert 0.0 <= proba <= 1.0

    def test_predict_proba_in_zero_one_creative(
        self, ranker: LearnedRanker, simple_claim: Claim
    ) -> None:
        """predict_proba() handles is_creative=True."""
        inputs = VerdictInputs(
            claim=simple_claim,
            evidence=[],
            is_opinion=False,
            is_creative=True,
            tier_of=None,
        )
        proba = ranker.predict_proba(inputs)
        assert 0.0 <= proba <= 1.0


class TestDecideVerifiedOnStrongTier1Support:
    """test_decide_verified_on_strong_tier1_support"""

    def test_decide_verified_on_strong_tier1_support(
        self, ranker: LearnedRanker, simple_claim: Claim, tier1_support_evidence: Evidence
    ) -> None:
        """decide() returns VERIFIED when strong TIER_1 support present."""
        inputs = VerdictInputs(
            claim=simple_claim,
            evidence=[tier1_support_evidence],
            is_opinion=False,
            is_creative=False,
            tier_of={"source-tier1": TrustTier.TIER_1},
        )
        record = ranker.decide(inputs, threshold=0.4)
        assert record.decision == Verdict.VERIFIED
        assert 0.0 <= record.confidence <= 1.0


class TestDecideUnverifiedOnWeakEvidence:
    """test_decide_unverified_on_weak_evidence"""

    def test_decide_unverified_on_weak_evidence(
        self, ranker: LearnedRanker, simple_claim: Claim
    ) -> None:
        """decide() returns UNVERIFIED with no evidence."""
        inputs = VerdictInputs(
            claim=simple_claim,
            evidence=[],
            is_opinion=False,
            is_creative=False,
            tier_of=None,
        )
        record = ranker.decide(inputs, threshold=0.6)
        assert record.decision == Verdict.UNVERIFIED
        assert 0.0 <= record.confidence <= 1.0


class TestDecideContestedOnMixedStances:
    """test_decide_contested_on_mixed_stances"""

    def test_decide_returns_unverified_on_mixed_stances(
        self,
        ranker: LearnedRanker,
        simple_claim: Claim,
        tier1_support_evidence: Evidence,
        tier1_refute_evidence: Evidence,
    ) -> None:
        """decide() handles mixed support/refute (returns neutral logit=0)."""
        inputs = VerdictInputs(
            claim=simple_claim,
            evidence=[tier1_support_evidence, tier1_refute_evidence],
            is_opinion=False,
            is_creative=False,
            tier_of={
                "source-tier1": TrustTier.TIER_1,
                "source-refute": TrustTier.TIER_1,
            },
        )
        record = ranker.decide(inputs, threshold=0.6)
        # Mixed stances yield logit=0, so proba=0.5, below threshold=0.6
        assert record.decision == Verdict.UNVERIFIED


class TestFitPushesWeightsTowardLabels:
    """test_fit_pushes_weights_toward_labels"""

    def test_fit_with_labeled_examples(
        self, simple_claim: Claim, tier1_support_evidence: Evidence
    ) -> None:
        """fit() nudges weights to match majority vote on labels."""
        ranker = LearnedRanker()
        intercept_before = ranker.weights["intercept"]

        positive_inputs = VerdictInputs(
            claim=simple_claim,
            evidence=[tier1_support_evidence],
            is_opinion=False,
            is_creative=False,
            tier_of={"source-tier1": TrustTier.TIER_1},
        )

        # Fit with 3 positive + 1 negative example
        examples = [
            (positive_inputs, Verdict.VERIFIED),
            (positive_inputs, Verdict.VERIFIED),
            (positive_inputs, Verdict.VERIFIED),
            (
                VerdictInputs(
                    claim=simple_claim,
                    evidence=[],
                    is_opinion=False,
                    is_creative=False,
                    tier_of=None,
                ),
                Verdict.UNVERIFIED,
            ),
        ]

        ranker.fit(examples)

        # After fit, intercept should have moved (3 positive nudges - 1 negative)
        # Net effect: +2 * learning_rate
        intercept_after = ranker.weights["intercept"]
        assert intercept_after > intercept_before

    def test_fit_improves_confidence_on_positive_examples(
        self, simple_claim: Claim, tier1_support_evidence: Evidence
    ) -> None:
        """Fit increases confidence for positive examples."""
        ranker = LearnedRanker()

        positive_inputs = VerdictInputs(
            claim=simple_claim,
            evidence=[tier1_support_evidence],
            is_opinion=False,
            is_creative=False,
            tier_of={"source-tier1": TrustTier.TIER_1},
        )

        proba_before = ranker.predict_proba(positive_inputs)

        examples = [(positive_inputs, Verdict.VERIFIED) for _ in range(3)]
        ranker.fit(examples)

        proba_after = ranker.predict_proba(positive_inputs)
        # After fit on positive examples, proba should increase or stay same
        assert proba_after >= proba_before * 0.99  # Allow tiny tolerance


class TestDecideHandlesOpinionAndCreative:
    """Test that opinion and creative flags are respected."""

    def test_decide_returns_opinion_when_flagged(
        self, ranker: LearnedRanker, simple_claim: Claim, tier1_support_evidence: Evidence
    ) -> None:
        """decide() returns OPINION when is_opinion=True."""
        inputs = VerdictInputs(
            claim=simple_claim,
            evidence=[tier1_support_evidence],
            is_opinion=True,
            is_creative=False,
            tier_of={"source-tier1": TrustTier.TIER_1},
        )
        record = ranker.decide(inputs)
        assert record.decision == Verdict.OPINION

    def test_decide_returns_creative_when_flagged(
        self, ranker: LearnedRanker, simple_claim: Claim, tier1_support_evidence: Evidence
    ) -> None:
        """decide() returns CREATIVE when is_creative=True."""
        inputs = VerdictInputs(
            claim=simple_claim,
            evidence=[tier1_support_evidence],
            is_opinion=False,
            is_creative=True,
            tier_of={"source-tier1": TrustTier.TIER_1},
        )
        record = ranker.decide(inputs)
        assert record.decision == Verdict.CREATIVE


class TestScoreIncreaseWithMoreTier1Support:
    """Sanity check: more TIER_1 support → higher score."""

    def test_more_tier1_evidence_increases_score(
        self, ranker: LearnedRanker, simple_claim: Claim, tier1_support_evidence: Evidence
    ) -> None:
        """Score increases with additional TIER_1 support."""
        inputs_one_ev = VerdictInputs(
            claim=simple_claim,
            evidence=[tier1_support_evidence],
            is_opinion=False,
            is_creative=False,
            tier_of={"source-tier1": TrustTier.TIER_1},
        )

        # Create a second TIER_1 source with different DID
        tier1_support_evidence_2 = Evidence(
            evidence_id="ev-4",
            claim_id="test-claim-1",
            source_did="source-tier1-2",
            source_version="v1.0",
            stance=Stance.SUPPORTS,
            excerpt="More evidence of roundness.",
            url="https://example.com/more",
            retrieved_at=datetime.now(tz=UTC),
            raw_hash="d" * 64,
        )

        inputs_two_ev = VerdictInputs(
            claim=simple_claim,
            evidence=[tier1_support_evidence, tier1_support_evidence_2],
            is_opinion=False,
            is_creative=False,
            tier_of={
                "source-tier1": TrustTier.TIER_1,
                "source-tier1-2": TrustTier.TIER_1,
            },
        )

        score_one = ranker.score(inputs_one_ev)
        score_two = ranker.score(inputs_two_ev)
        assert score_two > score_one
