"""Tests for gRPC transport (W59).

Tests verify:
1. Proto file exists with correct structure
2. Import errors are clear when grpc is not installed
3. Graceful skipping in test suite when grpc unavailable
"""
from __future__ import annotations

import pytest


def test_proto_file_exists():
    """Test that gtv.proto file exists."""
    import pathlib
    proto_path = pathlib.Path(__file__).parent.parent.parent / "proto" / "gtv.proto"
    assert proto_path.exists(), f"proto file not found at {proto_path}"


def test_proto_file_structure():
    """Test that proto file has required service and messages."""
    import pathlib
    proto_path = pathlib.Path(__file__).parent.parent.parent / "proto" / "gtv.proto"
    content = proto_path.read_text()

    # Check required service and RPC
    assert "service GtvVerify" in content, "Missing GtvVerify service"
    assert "rpc Verify" in content, "Missing Verify RPC"

    # Check required messages
    required_messages = [
        "message VerifyRequest",
        "message VerifyResponse",
        "message Verdict",
        "message Evidence",
    ]
    for msg in required_messages:
        assert msg in content, f"Missing {msg}"

    # Check required fields in VerifyRequest
    assert "string claim_text" in content
    assert "string domain" in content
    assert "int32 max_items" in content


def test_grpc_import_error_when_not_available():
    """Test that clear import errors occur when grpc is not installed."""
    pytest.importorskip("grpc")  # Skip if grpc IS installed


def test_grpc_server_module_importable():
    """Test that grpc_server module can be imported without grpc."""
    try:
        from gtv.mcp import grpc_server
        assert hasattr(grpc_server, "serve_grpc")
        assert hasattr(grpc_server, "GtvVerifyServicer")
    except ImportError as e:
        if "grpcio" in str(e):
            pytest.skip(f"grpc not installed: {e}")
        raise


def test_grpc_client_module_importable():
    """Test that grpc_client module can be imported without grpc."""
    try:
        from gtv.mcp import grpc_client
        assert hasattr(grpc_client, "GtvVerifyClient")
    except ImportError as e:
        if "grpcio" in str(e):
            pytest.skip(f"grpc not installed: {e}")
        raise


@pytest.mark.skipif(
    pytest.importorskip("grpc", minversion=None) is None,
    reason="grpc not installed",
)
def test_grpc_available_servicer_wired():
    """Test that when grpc IS installed, servicer is properly typed."""
    grpc = pytest.importorskip("grpc")
    from gtv.mcp.grpc_server import GtvVerifyServicer

    assert issubclass(GtvVerifyServicer, grpc.aio.Servicer)


@pytest.mark.skipif(
    pytest.importorskip("grpc", minversion=None) is None,
    reason="grpc not installed",
)
def test_grpc_available_client_wired():
    """Test that when grpc IS installed, client is properly initialized."""
    pytest.importorskip("grpc")
    from gtv.mcp.grpc_client import GtvVerifyClient

    # Should be able to create instance without ImportError
    client = GtvVerifyClient("localhost:50051")
    assert client.target == "localhost:50051"
