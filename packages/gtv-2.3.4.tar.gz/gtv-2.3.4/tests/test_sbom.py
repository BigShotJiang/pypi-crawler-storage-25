"""Tests for SBOM generation and vulnerability scanning."""
from __future__ import annotations

import json
import tempfile
from pathlib import Path

import pytest

from gtv.sbom import SBOM, Component, collect_components, render_cyclonedx, scan_vulns


class TestComponent:
    """Tests for Component dataclass."""

    def test_component_constructs_valid_purl(self) -> None:
        """Component constructs valid PURL."""
        comp = Component(
            name="requests",
            version="2.28.0",
            purl="pkg:pypi/requests@2.28.0",
        )
        assert comp.purl == "pkg:pypi/requests@2.28.0"
        assert comp.name == "requests"
        assert comp.version == "2.28.0"

    def test_component_with_sha256(self) -> None:
        """Component can store sha256."""
        comp = Component(
            name="requests",
            version="2.28.0",
            purl="pkg:pypi/requests@2.28.0",
            sha256="abc123def456",
        )
        assert comp.sha256 == "abc123def456"

    def test_component_with_license(self) -> None:
        """Component can store license."""
        comp = Component(
            name="requests",
            version="2.28.0",
            purl="pkg:pypi/requests@2.28.0",
            license="Apache-2.0",
        )
        assert comp.license == "Apache-2.0"


class TestCollectComponents:
    """Tests for collect_components function."""

    def test_collect_components_returns_list(self) -> None:
        """collect_components returns non-empty list in current env."""
        components = collect_components()
        assert isinstance(components, list)
        assert len(components) > 0
        # Check that we have at least pytest (used for testing)
        names = {c.name.lower() for c in components}
        assert "pytest" in names


class TestSBOM:
    """Tests for SBOM dataclass."""

    def test_sbom_serial_number_is_urn_uuid(self) -> None:
        """SBOM serial_number is a urn:uuid:*."""
        serial = "urn:uuid:12345678-1234-5678-1234-567812345678"
        sbom = SBOM(
            serial_number=serial,
            components=[],
            generated_at="2024-01-01T00:00:00Z",
        )
        assert sbom.serial_number == serial
        assert sbom.serial_number.startswith("urn:uuid:")

    def test_sbom_serial_number_validation(self) -> None:
        """SBOM raises ValueError if serial_number doesn't start with urn:uuid:."""
        with pytest.raises(ValueError, match="must start with 'urn:uuid:'"):
            SBOM(
                serial_number="invalid",
                components=[],
                generated_at="2024-01-01T00:00:00Z",
            )

    def test_sbom_defaults(self) -> None:
        """SBOM has correct defaults."""
        sbom = SBOM(
            serial_number="urn:uuid:12345678-1234-5678-1234-567812345678",
            components=[],
            generated_at="2024-01-01T00:00:00Z",
        )
        assert sbom.bom_format == "CycloneDX"
        assert sbom.spec_version == "1.5"


class TestRenderCycloneDX:
    """Tests for render_cyclonedx function."""

    def test_render_cyclonedx_has_required_fields(self) -> None:
        """render_cyclonedx has required CycloneDX fields."""
        comp = Component(
            name="test",
            version="1.0.0",
            purl="pkg:pypi/test@1.0.0",
        )
        sbom = SBOM(
            serial_number="urn:uuid:12345678-1234-5678-1234-567812345678",
            components=[comp],
            generated_at="2024-01-01T00:00:00Z",
        )
        result = render_cyclonedx(sbom)

        assert result["bomFormat"] == "CycloneDX"
        assert result["specVersion"] == "1.5"
        assert result["serialNumber"] == "urn:uuid:12345678-1234-5678-1234-567812345678"
        assert "components" in result

    def test_render_cyclonedx_serializes_component(self) -> None:
        """render_cyclonedx serializes one component correctly."""
        comp = Component(
            name="requests",
            version="2.28.0",
            purl="pkg:pypi/requests@2.28.0",
            sha256="abc123",
            license="Apache-2.0",
        )
        sbom = SBOM(
            serial_number="urn:uuid:12345678-1234-5678-1234-567812345678",
            components=[comp],
            generated_at="2024-01-01T00:00:00Z",
        )
        result = render_cyclonedx(sbom)

        assert len(result["components"]) == 1
        comp_dict = result["components"][0]
        assert comp_dict["name"] == "requests"
        assert comp_dict["version"] == "2.28.0"
        assert comp_dict["purl"] == "pkg:pypi/requests@2.28.0"
        assert comp_dict["type"] == "library"
        assert comp_dict["hashes"][0]["alg"] == "SHA-256"
        assert comp_dict["hashes"][0]["content"] == "abc123"
        assert comp_dict["licenses"][0]["license"]["name"] == "Apache-2.0"


class TestScanVulns:
    """Tests for scan_vulns function."""

    def test_scan_vulns_exact_version_match(self) -> None:
        """scan_vulns: exact version match hits."""
        comp = Component(
            name="requests",
            version="2.25.0",
            purl="pkg:pypi/requests@2.25.0",
        )
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            json.dump(
                [
                    {
                        "name": "requests",
                        "version_spec": "==2.25.0",
                        "severity": "high",
                        "id": "CVE-2021-1234",
                    }
                ],
                f,
            )
            f.flush()
            advisory_file = f.name

        try:
            hits = scan_vulns([comp], advisory_file)
            assert len(hits) == 1
            assert hits[0]["component"] == "requests"
            assert hits[0]["version"] == "2.25.0"
            assert hits[0]["severity"] == "high"
            assert hits[0]["id"] == "CVE-2021-1234"
        finally:
            Path(advisory_file).unlink()

    def test_scan_vulns_less_than_version(self) -> None:
        """scan_vulns: '<' version hits older."""
        comp = Component(
            name="requests",
            version="2.24.0",
            purl="pkg:pypi/requests@2.24.0",
        )
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            json.dump(
                [
                    {
                        "name": "requests",
                        "version_spec": "<2.25.0",
                        "severity": "critical",
                        "id": "CVE-2021-5678",
                    }
                ],
                f,
            )
            f.flush()
            advisory_file = f.name

        try:
            hits = scan_vulns([comp], advisory_file)
            assert len(hits) == 1
            assert hits[0]["version"] == "2.24.0"
        finally:
            Path(advisory_file).unlink()

    def test_scan_vulns_less_than_misses_newer(self) -> None:
        """scan_vulns: '<' version misses newer."""
        comp = Component(
            name="requests",
            version="2.26.0",
            purl="pkg:pypi/requests@2.26.0",
        )
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            json.dump(
                [
                    {
                        "name": "requests",
                        "version_spec": "<2.25.0",
                        "severity": "critical",
                        "id": "CVE-2021-5678",
                    }
                ],
                f,
            )
            f.flush()
            advisory_file = f.name

        try:
            hits = scan_vulns([comp], advisory_file)
            assert len(hits) == 0
        finally:
            Path(advisory_file).unlink()

    def test_scan_vulns_no_hits_returns_empty_list(self) -> None:
        """scan_vulns: no hits → []."""
        comp = Component(
            name="requests",
            version="2.28.0",
            purl="pkg:pypi/requests@2.28.0",
        )
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            json.dump(
                [
                    {
                        "name": "numpy",
                        "version_spec": "==1.20.0",
                        "severity": "high",
                        "id": "CVE-2021-0000",
                    }
                ],
                f,
            )
            f.flush()
            advisory_file = f.name

        try:
            hits = scan_vulns([comp], advisory_file)
            assert hits == []
        finally:
            Path(advisory_file).unlink()

    def test_scan_vulns_unknown_operator_raises_error(self) -> None:
        """scan_vulns: unknown operator raises ValueError."""
        comp = Component(
            name="requests",
            version="2.28.0",
            purl="pkg:pypi/requests@2.28.0",
        )
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            json.dump(
                [
                    {
                        "name": "requests",
                        "version_spec": ">>2.25.0",
                        "severity": "high",
                        "id": "CVE-2021-1234",
                    }
                ],
                f,
            )
            f.flush()
            advisory_file = f.name

        try:
            with pytest.raises(ValueError, match="Unknown operator"):
                scan_vulns([comp], advisory_file)
        finally:
            Path(advisory_file).unlink()

    def test_scan_vulns_less_equal_version(self) -> None:
        """scan_vulns: '<=' version operator."""
        comp = Component(
            name="requests",
            version="2.25.0",
            purl="pkg:pypi/requests@2.25.0",
        )
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            json.dump(
                [
                    {
                        "name": "requests",
                        "version_spec": "<=2.25.0",
                        "severity": "medium",
                        "id": "CVE-2021-9999",
                    }
                ],
                f,
            )
            f.flush()
            advisory_file = f.name

        try:
            hits = scan_vulns([comp], advisory_file)
            assert len(hits) == 1
        finally:
            Path(advisory_file).unlink()


class TestCLI:
    """Tests for CLI commands."""

    def test_cli_generate_writes_valid_json(self, tmp_path: Path) -> None:
        """CLI generate writes a valid JSON file."""
        from gtv.cli.sbom import generate_sbom

        output_file = tmp_path / "sbom.json"
        exit_code = generate_sbom(output=str(output_file))

        assert exit_code == 0
        assert output_file.exists()

        with open(output_file) as f:
            sbom_dict = json.load(f)

        assert sbom_dict["bomFormat"] == "CycloneDX"
        assert sbom_dict["specVersion"] == "1.5"
        assert "components" in sbom_dict
        assert isinstance(sbom_dict["components"], list)

    def test_cli_scan_exits_zero_on_no_match(self, tmp_path: Path) -> None:
        """CLI scan exits 0 on no-match."""
        from gtv.cli.sbom import scan_sbom

        # Create SBOM with a test component
        sbom_file = tmp_path / "sbom.json"
        sbom_dict = {
            "bomFormat": "CycloneDX",
            "specVersion": "1.5",
            "serialNumber": "urn:uuid:test",
            "components": [
                {
                    "type": "library",
                    "name": "requests",
                    "version": "2.28.0",
                    "purl": "pkg:pypi/requests@2.28.0",
                }
            ],
        }
        with open(sbom_file, "w") as f:
            json.dump(sbom_dict, f)

        # Create empty advisory file
        advisory_file = tmp_path / "advisories.json"
        with open(advisory_file, "w") as f:
            json.dump([], f)

        exit_code = scan_sbom(str(sbom_file), str(advisory_file))
        assert exit_code == 0

    def test_cli_scan_exits_nonzero_on_match_with_fail_on(self, tmp_path: Path) -> None:
        """CLI scan exits non-zero on match with --fail-on."""
        from gtv.cli.sbom import scan_sbom

        # Create SBOM with a test component
        sbom_file = tmp_path / "sbom.json"
        sbom_dict = {
            "bomFormat": "CycloneDX",
            "specVersion": "1.5",
            "serialNumber": "urn:uuid:test",
            "components": [
                {
                    "type": "library",
                    "name": "requests",
                    "version": "2.25.0",
                    "purl": "pkg:pypi/requests@2.25.0",
                }
            ],
        }
        with open(sbom_file, "w") as f:
            json.dump(sbom_dict, f)

        # Create advisory file with a match
        advisory_file = tmp_path / "advisories.json"
        advisories = [
            {
                "name": "requests",
                "version_spec": "==2.25.0",
                "severity": "critical",
                "id": "CVE-2021-1234",
            }
        ]
        with open(advisory_file, "w") as f:
            json.dump(advisories, f)

        exit_code = scan_sbom(str(sbom_file), str(advisory_file), fail_on="critical")
        assert exit_code == 1
