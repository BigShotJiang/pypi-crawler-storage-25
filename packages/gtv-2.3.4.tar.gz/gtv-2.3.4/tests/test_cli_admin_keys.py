"""Tests for the gtv-admin-keys CLI."""
from __future__ import annotations

import tempfile
from pathlib import Path

from gtv.auth.keystore import APIKeyStore
from gtv.cli.admin_keys import cmd_create, cmd_list, cmd_revoke


def test_cmd_create_basic(capsys) -> None:
    """Test the create command with basic options."""
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = Path(tmpdir) / "test.db"
        cmd_create("test-label", "verify,consensus", rate_limit=None, db_path=db_path)

        captured = capsys.readouterr()
        assert "Created API key:" in captured.out
        assert "Raw key (SAVE THIS NOW" in captured.out
        assert "gtv_" in captured.out
        assert "WARNING: DO NOT LOSE THIS KEY" in captured.out

        # Verify it was actually created
        store = APIKeyStore(db_path)
        keys = store.list_keys()
        store.close()

        assert len(keys) == 1
        assert keys[0].label == "test-label"
        assert keys[0].scopes == ["verify", "consensus"]


def test_cmd_create_with_rate_limit(capsys) -> None:
    """Test the create command with rate limit."""
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = Path(tmpdir) / "test.db"
        cmd_create("test-label", "verify", rate_limit=50, db_path=db_path)

        captured = capsys.readouterr()
        assert "Rate limit:     50 req/min" in captured.out

        # Verify it was created with rate limit
        store = APIKeyStore(db_path)
        keys = store.list_keys()
        store.close()

        assert len(keys) == 1
        assert keys[0].rate_limit_per_minute == 50


def test_cmd_create_with_single_scope(capsys) -> None:
    """Test the create command with a single scope."""
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = Path(tmpdir) / "test.db"
        cmd_create("test-label", "verify", rate_limit=None, db_path=db_path)

        captured = capsys.readouterr()
        assert "Scopes:         verify" in captured.out


def test_cmd_list_empty(capsys) -> None:
    """Test the list command with no keys."""
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = Path(tmpdir) / "test.db"
        cmd_list(db_path=db_path)

        captured = capsys.readouterr()
        assert "No API keys." in captured.out


def test_cmd_list_with_keys(capsys) -> None:
    """Test the list command with keys."""
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = Path(tmpdir) / "test.db"

        # Create some keys
        store = APIKeyStore(db_path)
        _, _ = store.create_key("label-1", ["verify"], rate_limit_per_minute=100)
        _, _ = store.create_key("label-2", ["consensus", "retrieve"])
        store.close()

        # List them
        cmd_list(db_path=db_path)

        captured = capsys.readouterr()
        assert "Key ID" in captured.out
        assert "Label" in captured.out
        assert "Scopes" in captured.out
        assert "Status" in captured.out
        assert "Rate Limit" in captured.out
        assert "label-1" in captured.out
        assert "label-2" in captured.out
        assert "verify" in captured.out
        assert "consensus,retrieve" in captured.out
        assert "100" in captured.out


def test_cmd_list_shows_status(capsys) -> None:
    """Test that list shows active/revoked status."""
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = Path(tmpdir) / "test.db"

        store = APIKeyStore(db_path)
        _, _ = store.create_key("active-key", ["verify"])
        key_id_2, _ = store.create_key("revoked-key", ["verify"])
        store.revoke_key(key_id_2)
        store.close()

        # List them
        cmd_list(db_path=db_path)

        captured = capsys.readouterr()
        assert "active" in captured.out
        assert "revoked" in captured.out


def test_cmd_revoke_success(capsys) -> None:
    """Test the revoke command on an existing key."""
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = Path(tmpdir) / "test.db"

        # Create a key
        store = APIKeyStore(db_path)
        key_id, _ = store.create_key("test-label", ["verify"])
        store.close()

        # Revoke it
        cmd_revoke(key_id, db_path=db_path)

        captured = capsys.readouterr()
        assert f"Revoked API key {key_id}" in captured.out

        # Verify it's revoked
        store = APIKeyStore(db_path)
        keys = store.list_keys()
        store.close()

        assert len(keys) == 1
        assert not keys[0].is_active()


def test_cmd_revoke_nonexistent(capsys) -> None:
    """Test the revoke command on a nonexistent key."""
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = Path(tmpdir) / "test.db"

        # Try to revoke a nonexistent key
        try:
            cmd_revoke("key_nonexistent", db_path=db_path)
            raise AssertionError("Should have exited")
        except SystemExit as e:
            assert e.code == 1

        captured = capsys.readouterr()
        assert "not found" in captured.out
