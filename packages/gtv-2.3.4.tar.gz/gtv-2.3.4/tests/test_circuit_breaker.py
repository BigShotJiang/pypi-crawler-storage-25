"""Tests for the adapter circuit breaker (W40).

What must hold:
 1. A clean adapter is invisible — no state transitions, calls pass
    through.
 2. A failing adapter trips to OPEN after ``failure_ratio`` is met.
 3. An OPEN breaker short-circuits ``query()`` (returns []) and raises
    ``CircuitOpenError`` from ``snapshot()``.
 4. After ``cooldown_s``, the breaker moves to HALF_OPEN. One probe
    decides whether we re-close or re-open.
 5. ``health()`` reflects the breaker state, not just upstream.
 6. Env-var config parses correctly.
"""
from __future__ import annotations

from datetime import UTC, datetime

import pytest
from pydantic import HttpUrl

from gtv.adapters.base import RawSnapshot, SourceAdapter
from gtv.models import (
    Claim,
    Domain,
    Evidence,
    HealthStatus,
    Stance,
    TrustTier,
)
from gtv.obs import circuit as cb_mod
from gtv.obs.circuit import (
    AdapterCircuitBreaker,
    CircuitConfig,
    CircuitOpenError,
    CircuitState,
    load_circuit_config_from_env,
)

# ---------------------------------------------------------------------
# Test fixtures
# ---------------------------------------------------------------------


class ProgrammableAdapter(SourceAdapter):
    """Adapter that succeeds or fails according to a caller-provided
    schedule. Each call pops the next flag; flags run out → default True."""

    source_did = "did:web:cb-test.example"
    name = "CBTest"
    trust_tier = TrustTier.TIER_2
    freshness_sla_s = 600

    def __init__(self, schedule: list[bool]) -> None:
        self._schedule = list(schedule)
        self.calls = 0
        self.closed = False

    def _next(self) -> bool:
        self.calls += 1
        if self._schedule:
            return self._schedule.pop(0)
        return True

    async def query(self, claim: Claim, max_items: int = 5) -> list[Evidence]:
        if not self._next():
            raise RuntimeError("upstream 500")
        return [
            Evidence(
                claim_id=claim.claim_id,
                source_did=self.source_did,
                source_version="v1",
                stance=Stance.SUPPORTS,
                excerpt="ok",
                url=HttpUrl("https://x.example/e"),
                retrieved_at=datetime.now(tz=UTC),
                raw_hash="0" * 64,
            )
        ]

    async def snapshot(self, url: str) -> RawSnapshot:
        if not self._next():
            raise RuntimeError("snapshot failed")
        return RawSnapshot(url=url, content=b"hi", retrieved_at_iso="2026-04-21T00:00:00Z")

    async def health(self) -> HealthStatus:
        return HealthStatus(state="HEALTHY")

    async def close(self) -> None:
        self.closed = True


def _claim() -> Claim:
    return Claim(text="The sky is blue", domain=Domain.PHYSICS)


# ---------------------------------------------------------------------
# 1. Transparent passthrough in steady state
# ---------------------------------------------------------------------


async def test_clean_adapter_stays_closed() -> None:
    inner = ProgrammableAdapter(schedule=[True] * 10)
    cb = AdapterCircuitBreaker(inner, CircuitConfig(window=5, min_samples=3))

    for _ in range(10):
        result = await cb.query(_claim())
        assert len(result) == 1

    assert cb.state is CircuitState.CLOSED
    assert inner.calls == 10  # every call reached upstream


# ---------------------------------------------------------------------
# 2. Trips to OPEN after threshold
# ---------------------------------------------------------------------


async def test_trips_open_after_failure_ratio_hit() -> None:
    inner = ProgrammableAdapter(schedule=[False] * 10)
    cb = AdapterCircuitBreaker(
        inner,
        CircuitConfig(window=5, min_samples=3, failure_ratio=0.5),
    )

    # Fail 3 times — min_samples met, ratio 3/3 >= 0.5 -> OPEN.
    for _ in range(3):
        with pytest.raises(RuntimeError, match="upstream 500"):
            await cb.query(_claim())

    assert cb.state is CircuitState.OPEN


async def test_below_min_samples_never_trips() -> None:
    """Even 100% failures must not trip before we have min_samples."""
    inner = ProgrammableAdapter(schedule=[False, False])
    cb = AdapterCircuitBreaker(
        inner,
        CircuitConfig(window=10, min_samples=5, failure_ratio=0.5),
    )
    for _ in range(2):
        with pytest.raises(RuntimeError):
            await cb.query(_claim())
    assert cb.state is CircuitState.CLOSED


# ---------------------------------------------------------------------
# 3. OPEN short-circuits
# ---------------------------------------------------------------------


async def test_open_breaker_short_circuits_query(monkeypatch: pytest.MonkeyPatch) -> None:
    clock = {"t": 0.0}
    monkeypatch.setattr(cb_mod, "_now", lambda: clock["t"])

    inner = ProgrammableAdapter(schedule=[False, False, False])
    cb = AdapterCircuitBreaker(
        inner,
        CircuitConfig(window=3, min_samples=3, failure_ratio=0.5, cooldown_s=30),
    )

    for _ in range(3):
        with pytest.raises(RuntimeError):
            await cb.query(_claim())
    assert cb.state is CircuitState.OPEN

    # Now call again while OPEN. Upstream call count must NOT increase,
    # and query() must return [] (soft-fail contract).
    inner_calls_before = inner.calls
    result = await cb.query(_claim())
    assert result == []
    assert inner.calls == inner_calls_before


async def test_open_breaker_raises_for_snapshot(monkeypatch: pytest.MonkeyPatch) -> None:
    clock = {"t": 0.0}
    monkeypatch.setattr(cb_mod, "_now", lambda: clock["t"])

    inner = ProgrammableAdapter(schedule=[False, False, False])
    cb = AdapterCircuitBreaker(
        inner, CircuitConfig(window=3, min_samples=3, cooldown_s=30)
    )
    for _ in range(3):
        with pytest.raises(RuntimeError):
            await cb.query(_claim())
    assert cb.state is CircuitState.OPEN

    with pytest.raises(CircuitOpenError):
        await cb.snapshot("https://x.example/doc")


# ---------------------------------------------------------------------
# 4. HALF_OPEN probe
# ---------------------------------------------------------------------


async def test_half_open_probe_success_closes_breaker(monkeypatch: pytest.MonkeyPatch) -> None:
    clock = {"t": 0.0}
    monkeypatch.setattr(cb_mod, "_now", lambda: clock["t"])

    # Schedule: 3 failures to open, then a success that closes.
    inner = ProgrammableAdapter(schedule=[False, False, False, True])
    cb = AdapterCircuitBreaker(
        inner,
        CircuitConfig(window=3, min_samples=3, failure_ratio=0.5, cooldown_s=30),
    )
    for _ in range(3):
        with pytest.raises(RuntimeError):
            await cb.query(_claim())
    assert cb.state is CircuitState.OPEN

    # Advance past cooldown.
    clock["t"] = 31.0
    result = await cb.query(_claim())  # probe
    assert len(result) == 1
    assert cb.state is CircuitState.CLOSED


async def test_half_open_probe_failure_reopens_with_fresh_timer(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    clock = {"t": 0.0}
    monkeypatch.setattr(cb_mod, "_now", lambda: clock["t"])

    inner = ProgrammableAdapter(schedule=[False] * 10)
    cb = AdapterCircuitBreaker(
        inner,
        CircuitConfig(window=3, min_samples=3, failure_ratio=0.5, cooldown_s=30),
    )
    for _ in range(3):
        with pytest.raises(RuntimeError):
            await cb.query(_claim())
    assert cb.state is CircuitState.OPEN

    clock["t"] = 31.0  # cooldown elapsed
    # The probe goes through, fails, re-opens.
    with pytest.raises(RuntimeError):
        await cb.query(_claim())
    assert cb.state is CircuitState.OPEN

    # Timer reset: at t=35 (only 4s since re-open), still OPEN,
    # short-circuits.
    clock["t"] = 35.0
    calls_before = inner.calls
    result = await cb.query(_claim())
    assert result == []
    assert inner.calls == calls_before


# ---------------------------------------------------------------------
# 5. health() reflects breaker state
# ---------------------------------------------------------------------


async def test_health_reports_degraded_when_open(monkeypatch: pytest.MonkeyPatch) -> None:
    clock = {"t": 0.0}
    monkeypatch.setattr(cb_mod, "_now", lambda: clock["t"])

    inner = ProgrammableAdapter(schedule=[False] * 3)
    cb = AdapterCircuitBreaker(
        inner, CircuitConfig(window=3, min_samples=3, cooldown_s=30)
    )
    for _ in range(3):
        with pytest.raises(RuntimeError):
            await cb.query(_claim())
    assert cb.state is CircuitState.OPEN

    h = await cb.health()
    assert h.state == "DEGRADED"
    assert "circuit OPEN" in h.detail


async def test_health_passes_through_when_closed() -> None:
    inner = ProgrammableAdapter(schedule=[True] * 3)
    cb = AdapterCircuitBreaker(inner)
    h = await cb.health()
    assert h.state == "HEALTHY"


# ---------------------------------------------------------------------
# 6. Config
# ---------------------------------------------------------------------


def test_load_circuit_config_from_env(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("GTV_CB_WINDOW", "50")
    monkeypatch.setenv("GTV_CB_MIN_SAMPLES", "10")
    monkeypatch.setenv("GTV_CB_FAILURE_RATIO", "0.25")
    monkeypatch.setenv("GTV_CB_COOLDOWN_S", "15")
    cfg = load_circuit_config_from_env()
    assert cfg.window == 50
    assert cfg.min_samples == 10
    assert cfg.failure_ratio == 0.25
    assert cfg.cooldown_s == 15.0


def test_config_rejects_out_of_range_ratio() -> None:
    with pytest.raises(ValueError):
        CircuitConfig(failure_ratio=1.5)


def test_config_rejects_negative_cooldown() -> None:
    with pytest.raises(ValueError):
        CircuitConfig(cooldown_s=-1)


# ---------------------------------------------------------------------
# 7. Pass-through of adapter identity
# ---------------------------------------------------------------------


def test_breaker_mirrors_inner_identity() -> None:
    inner = ProgrammableAdapter(schedule=[])
    cb = AdapterCircuitBreaker(inner)
    assert cb.source_did == inner.source_did
    assert cb.name == inner.name
    assert cb.trust_tier == inner.trust_tier
    assert cb.freshness_sla_s == inner.freshness_sla_s


async def test_close_delegates() -> None:
    inner = ProgrammableAdapter(schedule=[])
    cb = AdapterCircuitBreaker(inner)
    await cb.close()
    assert inner.closed is True
