"""Unit tests for MCP stdio server (gtv.mcp.stdio).

Tests the tool handlers directly without exercising full stdio transport
(which is brittle and integration-y). Uses monkeypatch to mock underlying
logic so tests don't require network/adapters.

Each test:
1. Mocks _verify_one and related functions
2. Calls the handler directly
3. Asserts JSON structure of TextContent response
"""
from __future__ import annotations

import json
from typing import Any

import pytest

from gtv.mcp.stdio import (
    _build_tools,
    _handle_retrieve_facts,
    _handle_verify_claim,
)
from gtv.models import (
    AnchorProof,
    Claim,
    Domain,
    Envelope,
    Verdict,
)


class TestListTools:
    """Test tool registration and schema."""

    def test_tool_list_contains_two_tools(self) -> None:
        """verify_claim and retrieve_facts are registered."""
        tools = _build_tools()
        assert len(tools) == 2

        tool_names = {t.name for t in tools}
        assert tool_names == {"verify_claim", "retrieve_facts"}

    def test_verify_claim_tool_schema(self) -> None:
        """verify_claim has correct input schema."""
        tools = _build_tools()
        tool = next(t for t in tools if t.name == "verify_claim")

        schema = tool.inputSchema
        assert "properties" in schema
        assert "claim" in schema["properties"]
        assert "domain" in schema["properties"]
        assert "max_sources" in schema["properties"]

        # claim is required
        assert schema["required"] == ["claim"]

        # domain has default
        assert schema["properties"]["domain"]["default"] == "general"

        # max_sources has default
        assert schema["properties"]["max_sources"]["default"] == 5

    def test_retrieve_facts_tool_schema(self) -> None:
        """retrieve_facts has correct input schema."""
        tools = _build_tools()
        tool = next(t for t in tools if t.name == "retrieve_facts")

        schema = tool.inputSchema
        assert "properties" in schema
        assert "text" in schema["properties"]
        assert "domain" in schema["properties"]
        assert "max_claims" in schema["properties"]

        # text is required
        assert schema["required"] == ["text"]

        # domain has default
        assert schema["properties"]["domain"]["default"] == "general"

        # max_claims has default
        assert schema["properties"]["max_claims"]["default"] == 5


class TestVerifyClaimHandler:
    """Test _handle_verify_claim."""

    @pytest.mark.asyncio
    async def test_verify_claim_basic(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Call verify_claim with claim and domain, get JSON response."""
        # Mock _verify_one to return a minimal envelope
        mock_envelope = Envelope(
            verdict=Verdict.VERIFIED,
            confidence=0.95,
            evidence=[],
            rationale="Test verification",
            issuer_did="did:web:test",
            signature="sig_test",
            rekor_uuid="uuid_test",
            rekor_log_index=42,
            tsa_token="tsa_test",
            prov_graph="{}",
            anchor_proof=AnchorProof(
                rekor_inclusion_proof="proof_test",
                tsa_tsr_primary="tsr_test",
                tsa_tsr_secondary=None,
            ),
        )

        async def mock_verify_one(claim: Claim, max_sources: int, *, issuer_did: str = "") -> Envelope:
            return mock_envelope

        monkeypatch.setattr("gtv.mcp.stdio._verify_one", mock_verify_one)

        # Call handler
        arguments = {
            "claim": "The Earth is round",
            "domain": "general",
            "max_sources": 5,
        }
        result = await _handle_verify_claim(arguments)

        # Verify result is a list with one TextContent
        assert len(result) == 1
        content = result[0]
        assert content.type == "text"

        # Parse JSON from response
        data = json.loads(content.text)
        assert data["verdict"] == "VERIFIED"
        assert data["confidence"] == 0.95
        assert data["rationale"] == "Test verification"

    @pytest.mark.asyncio
    async def test_verify_claim_with_defaults(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Verify defaults are used when domain and max_sources are omitted."""
        called_with = {}

        async def mock_verify_one(claim: Claim, max_sources: int, *, issuer_did: str = "") -> Envelope:
            called_with["claim_domain"] = str(claim.domain)
            called_with["max_sources"] = max_sources
            return Envelope(
                verdict=Verdict.UNVERIFIED,
                confidence=0.5,
                evidence=[],
                rationale="",
                issuer_did="did:web:test",
                signature="",
                rekor_uuid="",
                rekor_log_index=0,
                tsa_token="",
                prov_graph="{}",
                anchor_proof=AnchorProof(
                    rekor_inclusion_proof="",
                    tsa_tsr_primary="",
                    tsa_tsr_secondary=None,
                ),
            )

        monkeypatch.setattr("gtv.mcp.stdio._verify_one", mock_verify_one)

        arguments = {"claim": "Test claim"}
        await _handle_verify_claim(arguments)

        # Verify defaults were used
        assert called_with["claim_domain"] == str(Domain.GENERAL)
        assert called_with["max_sources"] == 5

    @pytest.mark.asyncio
    async def test_verify_claim_invalid_claim_text(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Empty claim text raises ValidationError."""
        async def mock_verify_one(claim: Claim, max_sources: int, *, issuer_did: str = "") -> Envelope:
            return Envelope(
                verdict=Verdict.VERIFIED,
                confidence=1.0,
                evidence=[],
                rationale="",
                issuer_did="did:web:test",
                signature="",
                rekor_uuid="",
                rekor_log_index=0,
                tsa_token="",
                prov_graph="{}",
                anchor_proof=AnchorProof(
                    rekor_inclusion_proof="",
                    tsa_tsr_primary="",
                    tsa_tsr_secondary=None,
                ),
            )

        monkeypatch.setattr("gtv.mcp.stdio._verify_one", mock_verify_one)

        # VerifyClaimRequest validates min_length=1
        with pytest.raises(ValueError):
            arguments = {"claim": ""}
            await _handle_verify_claim(arguments)


class TestRetrieveFactsHandler:
    """Test _handle_retrieve_facts."""

    @pytest.mark.asyncio
    async def test_retrieve_facts_no_claims(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """retrieve_facts with no extractable claims returns empty envelope."""
        # Mock extract_subclaims to return empty list
        def mock_extract_subclaims(
            text: str, max_subclaims: int
        ) -> list[str]:
            return []

        monkeypatch.setattr(
            "gtv.mcp.stdio.extract_subclaims",
            mock_extract_subclaims,
        )

        # Mock _seal_retrieve_envelope
        async def mock_seal_retrieve_envelope(facts: Any, *, issuer_did: str = "") -> Any:
            return {
                "envelope_id": "test_id",
                "facts": [],
                "issuer_did": "did:web:test",
                "signature": "",
                "rekor_uuid": "",
                "rekor_log_index": 0,
                "tsa_token": "",
                "anchor_proof": {
                    "rekor_inclusion_proof": "",
                    "tsa_tsr_primary": "",
                    "tsa_tsr_secondary": None,
                },
            }

        monkeypatch.setattr(
            "gtv.mcp.stdio._seal_retrieve_envelope",
            mock_seal_retrieve_envelope,
        )

        arguments = {"text": "Some text with no facts"}
        result = await _handle_retrieve_facts(arguments)

        assert len(result) == 1
        content = result[0]
        data = json.loads(content.text)
        assert data["facts"] == []

    @pytest.mark.asyncio
    async def test_retrieve_facts_with_claims(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """retrieve_facts extracts and verifies sub-claims."""
        # Mock extract_subclaims
        def mock_extract_subclaims(
            text: str, max_subclaims: int
        ) -> list[str]:
            return ["Claim 1", "Claim 2"]

        monkeypatch.setattr(
            "gtv.mcp.stdio.extract_subclaims",
            mock_extract_subclaims,
        )

        # Mock _verify_one
        async def mock_verify_one(claim: Claim, max_sources: int, *, issuer_did: str = "") -> Envelope:
            return Envelope(
                verdict=Verdict.VERIFIED,
                confidence=0.9,
                evidence=[],
                rationale="Test",
                issuer_did="did:web:test",
                signature="",
                rekor_uuid="",
                rekor_log_index=0,
                tsa_token="",
                prov_graph="{}",
                anchor_proof=AnchorProof(
                    rekor_inclusion_proof="",
                    tsa_tsr_primary="",
                    tsa_tsr_secondary=None,
                ),
            )

        monkeypatch.setattr("gtv.mcp.stdio._verify_one", mock_verify_one)

        # Mock _seal_retrieve_envelope
        async def mock_seal_retrieve_envelope(facts: Any, *, issuer_did: str = "") -> Any:
            # Serialize facts to JSON-compatible form
            serialized_facts = [
                f.model_dump(mode="json") if hasattr(f, "model_dump") else f
                for f in facts
            ]
            return {
                "envelope_id": "test_id",
                "facts": serialized_facts,
                "issuer_did": "did:web:test",
                "signature": "",
                "rekor_uuid": "",
                "rekor_log_index": 0,
                "tsa_token": "",
                "anchor_proof": {
                    "rekor_inclusion_proof": "",
                    "tsa_tsr_primary": "",
                    "tsa_tsr_secondary": None,
                },
            }

        monkeypatch.setattr(
            "gtv.mcp.stdio._seal_retrieve_envelope",
            mock_seal_retrieve_envelope,
        )

        arguments = {"text": "Claim 1 and Claim 2"}
        result = await _handle_retrieve_facts(arguments)

        assert len(result) == 1
        content = result[0]
        data = json.loads(content.text)
        # Facts should be populated (though empty evidence since we mocked)
        assert "facts" in data
        # We extracted 2 claims, so facts should have entries
        assert len(data["facts"]) == 2

    @pytest.mark.asyncio
    async def test_retrieve_facts_with_defaults(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Verify defaults for domain and max_claims."""
        captured_requests = {}

        def mock_extract_subclaims(
            text: str, max_subclaims: int
        ) -> list[str]:
            captured_requests["max_subclaims"] = max_subclaims
            return []

        monkeypatch.setattr(
            "gtv.mcp.stdio.extract_subclaims",
            mock_extract_subclaims,
        )

        async def mock_seal_retrieve_envelope(facts: Any, *, issuer_did: str = "") -> Any:
            return {
                "envelope_id": "test_id",
                "facts": [],
                "issuer_did": "did:web:test",
                "signature": "",
                "rekor_uuid": "",
                "rekor_log_index": 0,
                "tsa_token": "",
                "anchor_proof": {
                    "rekor_inclusion_proof": "",
                    "tsa_tsr_primary": "",
                    "tsa_tsr_secondary": None,
                },
            }

        monkeypatch.setattr(
            "gtv.mcp.stdio._seal_retrieve_envelope",
            mock_seal_retrieve_envelope,
        )

        arguments = {"text": "Some text"}
        await _handle_retrieve_facts(arguments)

        # max_claims should default to 5
        assert captured_requests.get("max_subclaims") == 5
