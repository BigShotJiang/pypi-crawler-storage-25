"""Tests for APIKeyStore."""
from __future__ import annotations

import tempfile
from datetime import datetime
from pathlib import Path

from gtv.auth.keystore import APIKeyStore


def test_create_key() -> None:
    """Test creating a new API key."""
    with tempfile.TemporaryDirectory() as tmpdir:
        store = APIKeyStore(Path(tmpdir) / "test.db")
        key_id, raw_key = store.create_key("test-label", ["verify", "consensus"])
        store.close()

        assert key_id.startswith("key_")
        assert raw_key.startswith("gtv_")


def test_verify_key_valid() -> None:
    """Test verifying a valid key."""
    with tempfile.TemporaryDirectory() as tmpdir:
        store = APIKeyStore(Path(tmpdir) / "test.db")
        key_id, raw_key = store.create_key("test-label", ["verify", "consensus"])

        api_key = store.verify_key(raw_key)
        store.close()

        assert api_key is not None
        assert api_key.key_id == key_id
        assert api_key.label == "test-label"
        assert api_key.scopes == ["verify", "consensus"]
        assert api_key.is_active()


def test_verify_key_invalid() -> None:
    """Test verifying an invalid key returns None."""
    with tempfile.TemporaryDirectory() as tmpdir:
        store = APIKeyStore(Path(tmpdir) / "test.db")
        api_key = store.verify_key("gtv_invalid_key")
        store.close()

        assert api_key is None


def test_verify_key_updates_last_used() -> None:
    """Test that verifying a key updates last_used_at."""
    with tempfile.TemporaryDirectory() as tmpdir:
        store = APIKeyStore(Path(tmpdir) / "test.db")
        _, raw_key = store.create_key("test-label", ["verify"])

        before_time = datetime.utcnow()
        api_key = store.verify_key(raw_key)
        after_time = datetime.utcnow()

        store.close()

        assert api_key is not None
        assert api_key.last_used_at is not None
        assert before_time <= api_key.last_used_at <= after_time


def test_revoke_key() -> None:
    """Test revoking a key."""
    with tempfile.TemporaryDirectory() as tmpdir:
        store = APIKeyStore(Path(tmpdir) / "test.db")
        key_id, raw_key = store.create_key("test-label", ["verify"])

        # Verify it's active
        api_key = store.verify_key(raw_key)
        assert api_key is not None
        assert api_key.is_active()

        # Revoke it
        found = store.revoke_key(key_id)
        assert found

        # Verify it's now revoked
        api_key = store.verify_key(raw_key)
        store.close()

        assert api_key is not None
        assert not api_key.is_active()
        assert api_key.revoked_at is not None


def test_revoke_nonexistent_key() -> None:
    """Test revoking a nonexistent key returns False."""
    with tempfile.TemporaryDirectory() as tmpdir:
        store = APIKeyStore(Path(tmpdir) / "test.db")
        found = store.revoke_key("key_nonexistent")
        store.close()

        assert not found


def test_list_keys() -> None:
    """Test listing all keys."""
    with tempfile.TemporaryDirectory() as tmpdir:
        store = APIKeyStore(Path(tmpdir) / "test.db")
        key_id_1, _ = store.create_key("label-1", ["verify"])
        key_id_2, _ = store.create_key("label-2", ["consensus"])

        keys = store.list_keys()
        store.close()

        assert len(keys) == 2
        assert keys[0].key_id == key_id_2  # Most recent first
        assert keys[1].key_id == key_id_1
        assert keys[0].label == "label-2"
        assert keys[1].label == "label-1"


def test_list_keys_does_not_return_raw_keys() -> None:
    """Test that list_keys returns metadata only, no raw keys."""
    with tempfile.TemporaryDirectory() as tmpdir:
        store = APIKeyStore(Path(tmpdir) / "test.db")
        _, raw_key = store.create_key("test-label", ["verify"])

        keys = store.list_keys()
        store.close()

        # Verify the raw key is not in the response
        for key in keys:
            assert raw_key not in str(key)


def test_scopes_list_to_string() -> None:
    """Test that scopes are properly stored and retrieved as a list."""
    with tempfile.TemporaryDirectory() as tmpdir:
        store = APIKeyStore(Path(tmpdir) / "test.db")
        _, raw_key = store.create_key("test-label", ["verify", "consensus", "retrieve"])

        api_key = store.verify_key(raw_key)
        store.close()

        assert api_key is not None
        assert isinstance(api_key.scopes, list)
        assert api_key.scopes == ["verify", "consensus", "retrieve"]


def test_has_scope() -> None:
    """Test the has_scope method."""
    with tempfile.TemporaryDirectory() as tmpdir:
        store = APIKeyStore(Path(tmpdir) / "test.db")
        _, raw_key = store.create_key("test-label", ["verify", "consensus"])

        api_key = store.verify_key(raw_key)
        store.close()

        assert api_key is not None
        assert api_key.has_scope("verify")
        assert api_key.has_scope("consensus")
        assert not api_key.has_scope("retrieve")


def test_rate_limit_none() -> None:
    """Test creating a key with no rate limit."""
    with tempfile.TemporaryDirectory() as tmpdir:
        store = APIKeyStore(Path(tmpdir) / "test.db")
        _, raw_key = store.create_key("test-label", ["verify"], rate_limit_per_minute=None)

        api_key = store.verify_key(raw_key)
        store.close()

        assert api_key is not None
        assert api_key.rate_limit_per_minute is None


def test_rate_limit_set() -> None:
    """Test creating a key with a rate limit."""
    with tempfile.TemporaryDirectory() as tmpdir:
        store = APIKeyStore(Path(tmpdir) / "test.db")
        _, raw_key = store.create_key("test-label", ["verify"], rate_limit_per_minute=100)

        api_key = store.verify_key(raw_key)
        store.close()

        assert api_key is not None
        assert api_key.rate_limit_per_minute == 100


def test_empty_scopes() -> None:
    """Test creating a key with empty scopes list."""
    with tempfile.TemporaryDirectory() as tmpdir:
        store = APIKeyStore(Path(tmpdir) / "test.db")
        _, raw_key = store.create_key("test-label", [])

        api_key = store.verify_key(raw_key)
        store.close()

        assert api_key is not None
        assert api_key.scopes == []
        assert not api_key.has_scope("verify")


def test_created_at_timestamp() -> None:
    """Test that created_at is set correctly."""
    with tempfile.TemporaryDirectory() as tmpdir:
        store = APIKeyStore(Path(tmpdir) / "test.db")
        before_time = datetime.utcnow()
        _, raw_key = store.create_key("test-label", ["verify"])
        after_time = datetime.utcnow()

        api_key = store.verify_key(raw_key)
        store.close()

        assert api_key is not None
        assert before_time <= api_key.created_at <= after_time


def test_revoked_key_cannot_verify() -> None:
    """Test that a revoked key fails verification."""
    with tempfile.TemporaryDirectory() as tmpdir:
        store = APIKeyStore(Path(tmpdir) / "test.db")
        key_id, raw_key = store.create_key("test-label", ["verify"])

        # Revoke the key
        store.revoke_key(key_id)

        # Key should still verify but be marked as revoked
        api_key = store.verify_key(raw_key)
        store.close()

        assert api_key is not None
        assert not api_key.is_active()


def test_touch_last_used() -> None:
    """Test updating last_used_at via touch_last_used."""
    import hashlib

    with tempfile.TemporaryDirectory() as tmpdir:
        store = APIKeyStore(Path(tmpdir) / "test.db")
        _, raw_key = store.create_key("test-label", ["verify"])

        # Get the key hash
        key_hash = hashlib.sha256(raw_key.encode()).hexdigest()

        # Initially no last_used_at
        api_key = store.verify_key(raw_key)
        assert api_key is not None

        # Touch it
        store.touch_last_used(key_hash)

        # Check that the database was updated by querying directly
        cursor = store._conn.execute(
            "SELECT last_used_at FROM api_keys WHERE key_hash = ?", (key_hash,)
        )
        row = cursor.fetchone()
        assert row is not None
        assert row[0] is not None

        store.close()
