"""Multi-tenant isolation tests (W31).

The whole multi-tenant story reduces to one invariant: each tenant
signs under its own issuer DID, and every cross-request data store
(verdict cache, lifecycle DAG) is already keyed by issuer DID. These
tests prove that invariant holds end-to-end by exercising two tenants
against the same process and asserting that neither can read the
other's cache entries or supersede chains.

We also cover the keystore migration path and the CLI plumbing.
"""
from __future__ import annotations

import sqlite3
from collections.abc import Generator
from datetime import UTC, datetime
from pathlib import Path

import pytest
from fastapi.testclient import TestClient
from pydantic import HttpUrl

from gtv.adapters import REGISTRY
from gtv.adapters.base import HealthStatus, RawSnapshot, SourceAdapter
from gtv.auth.keystore import APIKeyStore
from gtv.cache import InMemoryCacheStore, VerdictCache
from gtv.lifecycle import LifecycleIndex
from gtv.mcp.auth import APIKeyAuthMiddleware, RateLimiter
from gtv.models import Claim, Evidence, SourceType, Stance, TrustTier
from gtv.obs.metrics import TENANT_REQUESTS
from gtv.redact.redactor import reset_default_redactor_for_tests
from gtv.tenant import (
    DEFAULT_ISSUER_DID_FALLBACK,
    Tenant,
    default_tenant,
    resolve_tenant,
    tenant_from_api_key,
)

# ---------------------------------------------------------------------------
# Keystore migration + tenant columns
# ---------------------------------------------------------------------------


def test_keystore_migrates_legacy_schema(tmp_path: Path) -> None:
    """An old DB without tenant columns must be upgraded in place."""
    db_path = tmp_path / "legacy.db"
    # Create a legacy schema matching the pre-W31 shape.
    con = sqlite3.connect(db_path)
    con.execute(
        """
        CREATE TABLE api_keys (
            key_hash TEXT PRIMARY KEY,
            key_id TEXT UNIQUE NOT NULL,
            label TEXT,
            scopes TEXT,
            rate_limit_per_minute INTEGER,
            created_at TEXT NOT NULL,
            revoked_at TEXT,
            last_used_at TEXT
        )
        """
    )
    con.commit()
    con.close()

    # Opening the keystore must auto-migrate without error.
    store = APIKeyStore(str(db_path))
    cols = {
        row[1]
        for row in store._conn.execute("PRAGMA table_info(api_keys)").fetchall()
    }
    store.close()

    assert "tenant_id" in cols
    assert "issuer_did_override" in cols


def test_keystore_create_and_verify_tenant_fields(tmp_path: Path) -> None:
    store = APIKeyStore(str(tmp_path / "k.db"))
    try:
        _, raw = store.create_key(
            "alice-key",
            ["verify"],
            rate_limit_per_minute=5,
            tenant_id="alice",
            issuer_did_override="did:web:alice.example",
        )
        api = store.verify_key(raw)
        assert api is not None
        assert api.tenant_id == "alice"
        assert api.issuer_did_override == "did:web:alice.example"

        # Default tenant: blank tenant_id + no override
        _, raw2 = store.create_key("noname", ["verify"])
        api2 = store.verify_key(raw2)
        assert api2 is not None
        assert api2.tenant_id == ""
        assert api2.issuer_did_override is None
    finally:
        store.close()


# ---------------------------------------------------------------------------
# Tenant resolution
# ---------------------------------------------------------------------------


def test_tenant_from_api_key_with_override() -> None:
    t = tenant_from_api_key("alice", "did:web:alice.example")
    assert t == Tenant(tenant_id="alice", issuer_did="did:web:alice.example")
    assert not t.is_default


def test_tenant_from_api_key_falls_back_to_server_default(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("GTV_ISSUER_DID", "did:web:server.example")
    t = tenant_from_api_key("bob", None)
    # Named tenant without an override still inherits the server DID.
    assert t.issuer_did == "did:web:server.example"
    assert t.tenant_id == "bob"


def test_default_tenant_reads_env(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("GTV_ISSUER_DID", "did:web:env-case.example")
    t = default_tenant()
    assert t.is_default
    assert t.issuer_did == "did:web:env-case.example"


def test_default_tenant_uses_fallback(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("GTV_ISSUER_DID", raising=False)
    t = default_tenant()
    assert t.issuer_did == DEFAULT_ISSUER_DID_FALLBACK


def test_resolve_tenant_without_state() -> None:
    """Callers that don't carry request.state (tests, internal helpers)
    still get a valid tenant rather than a crash."""

    class _Bare:
        pass

    assert resolve_tenant(_Bare()) == default_tenant()


def test_resolve_tenant_reads_request_state() -> None:
    class _State:
        pass

    class _Req:
        def __init__(self) -> None:
            self.state = _State()

    req = _Req()
    req.state.tenant = Tenant(tenant_id="x", issuer_did="did:web:x.example")
    assert resolve_tenant(req).tenant_id == "x"


# ---------------------------------------------------------------------------
# End-to-end HTTP isolation: two tenants, one process
# ---------------------------------------------------------------------------


class _StaticAdapter(SourceAdapter):
    """Deterministic TIER_1 source so two verify calls yield the same
    envelope bytes modulo the issuer DID, making cache-key tests clean."""

    source_did = "did:web:static.example"
    name = "static"
    source_type = SourceType.REFERENCE_DATA
    trust_tier = TrustTier.TIER_1
    freshness_sla_s = 60

    async def query(self, claim: Claim, max_items: int = 5) -> list[Evidence]:
        return [
            Evidence(
                claim_id=claim.claim_id,
                source_did=self.source_did,
                source_version="v1",
                stance=Stance.SUPPORTS,
                excerpt="Static evidence.",
                url=HttpUrl("https://static.example/e/1"),
                retrieved_at=datetime(2026, 1, 1, tzinfo=UTC),
                raw_hash="0" * 64,
            )
        ]

    async def snapshot(self, url: str) -> RawSnapshot:
        return RawSnapshot(url=url, content=b"", retrieved_at_iso="")

    async def health(self) -> HealthStatus:
        return HealthStatus(state="HEALTHY", detail="")

    async def close(self) -> None:
        return None


@pytest.fixture
def two_tenant_server(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> Generator[tuple[TestClient, str, str, str, str], None, None]:
    """Spin up the server with a DB-backed keystore holding two tenants.

    Yields the TestClient plus ``(raw_key_a, raw_key_b, did_a, did_b)``.
    """
    import gtv.mcp.server as server_mod

    # Isolated keystore for this test only.
    db_path = tmp_path / "api_keys.db"
    store = APIKeyStore(str(db_path))
    _, raw_a = store.create_key(
        "alice",
        ["verify"],
        tenant_id="alice",
        issuer_did_override="did:web:alice.example",
    )
    _, raw_b = store.create_key(
        "bob",
        ["verify"],
        tenant_id="bob",
        issuer_did_override="did:web:bob.example",
    )
    store.close()

    # Swap registry / cache / lifecycle to clean in-memory stores.
    saved_registry = dict(REGISTRY)
    saved_cache = server_mod._VERDICT_CACHE
    saved_lifecycle = server_mod._LIFECYCLE
    REGISTRY.clear()
    REGISTRY[_StaticAdapter.source_did] = _StaticAdapter()
    server_mod._VERDICT_CACHE = VerdictCache(InMemoryCacheStore())
    server_mod._LIFECYCLE = LifecycleIndex()
    reset_default_redactor_for_tests()

    # Patch auth to use our scratch keystore. ``install_auth`` ran at
    # import time with no DB configured, so the bundled middleware is
    # inert. We walk ``user_middleware`` and mutate that instance's
    # ``keystore`` field so the existing stack picks it up without
    # rebuilding anything.
    ks = APIKeyStore(str(db_path))
    saved_overrides: list[tuple[object, dict[str, object]]] = []
    for mw in server_mod.app.user_middleware:
        if mw.cls is APIKeyAuthMiddleware:
            # Stash the previous kwargs so we can restore them on teardown.
            saved_overrides.append((mw, dict(mw.kwargs)))
            mw.kwargs["keystore"] = ks
            mw.kwargs["rate_limiter"] = RateLimiter(limit_per_minute=1000)
            mw.kwargs["api_keys"] = set()
    # Force FastAPI to rebuild the stack on the next request with our
    # override. Safe because TestClient hasn't dispatched yet.
    server_mod.app.middleware_stack = None

    client = TestClient(server_mod.app)
    try:
        yield client, raw_a, raw_b, "did:web:alice.example", "did:web:bob.example"
    finally:
        ks.close()
        REGISTRY.clear()
        REGISTRY.update(saved_registry)
        server_mod._VERDICT_CACHE = saved_cache
        server_mod._LIFECYCLE = saved_lifecycle
        # Restore the original middleware kwargs so neighbouring tests
        # don't inherit our test keystore.
        for mw, original in saved_overrides:
            mw.kwargs = original  # type: ignore[attr-defined]
        server_mod.app.middleware_stack = None
        reset_default_redactor_for_tests()


def test_two_tenants_sign_with_distinct_dids(
    two_tenant_server: tuple[TestClient, str, str, str, str],
) -> None:
    client, raw_a, raw_b, did_a, did_b = two_tenant_server
    body = {"claim": "The sky is blue.", "domain": "physics", "max_sources": 3}

    r_a = client.post("/tools/verify_claim", json=body, headers={"Authorization": f"Bearer {raw_a}"})
    r_b = client.post("/tools/verify_claim", json=body, headers={"Authorization": f"Bearer {raw_b}"})
    assert r_a.status_code == 200, r_a.text
    assert r_b.status_code == 200, r_b.text

    env_a = r_a.json()["envelope"]
    env_b = r_b.json()["envelope"]
    assert env_a["issuer_did"] == did_a
    assert env_b["issuer_did"] == did_b


def test_tenant_cache_does_not_leak(
    two_tenant_server: tuple[TestClient, str, str, str, str],
) -> None:
    """A cache hit for tenant A must not return to tenant B. Because the
    verdict cache key includes issuer_did, we assert this by comparing
    cache miss counters between two back-to-back posts with different
    keys for the same claim."""
    import gtv.mcp.server as server_mod

    client, raw_a, raw_b, _, _ = two_tenant_server
    body = {"claim": "Water boils at 100C at 1atm.", "domain": "physics", "max_sources": 3}

    miss_before = server_mod._VERDICT_CACHE.stats.misses
    # Tenant A: expect a miss.
    client.post("/tools/verify_claim", json=body, headers={"Authorization": f"Bearer {raw_a}"})
    miss_after_a = server_mod._VERDICT_CACHE.stats.misses
    # Tenant A again: expect a hit (no new miss).
    client.post("/tools/verify_claim", json=body, headers={"Authorization": f"Bearer {raw_a}"})
    miss_after_a2 = server_mod._VERDICT_CACHE.stats.misses
    # Tenant B same claim: MUST miss because the cache key embeds their DID.
    client.post("/tools/verify_claim", json=body, headers={"Authorization": f"Bearer {raw_b}"})
    miss_after_b = server_mod._VERDICT_CACHE.stats.misses

    assert miss_after_a == miss_before + 1, "Tenant A's first call should miss"
    assert miss_after_a2 == miss_after_a, "Tenant A's second call should hit"
    assert miss_after_b == miss_after_a2 + 1, "Tenant B must not read A's cache"


def test_tenant_cannot_supersede_other_tenants_envelope(
    two_tenant_server: tuple[TestClient, str, str, str, str],
) -> None:
    client, raw_a, raw_b, _, _ = two_tenant_server
    # Tenant A creates an envelope.
    r_a = client.post(
        "/tools/verify_claim",
        json={"claim": "Zeta Puppis is a blue supergiant.", "domain": "astronomy", "max_sources": 3},
        headers={"Authorization": f"Bearer {raw_a}"},
    )
    assert r_a.status_code == 200, r_a.text
    env_a = r_a.json()["envelope"]
    parent_id = env_a["envelope_id"]

    # Tenant B tries to supersede it. The parent is not B's to modify.
    r_b = client.post(
        "/tools/supersede_claim",
        json={
            "parent_envelope_id": parent_id,
            "claim": "Zeta Puppis is a blue supergiant.",
            "domain": "astronomy",
            "reason": "AMEND",
        },
        headers={"Authorization": f"Bearer {raw_b}"},
    )
    assert r_b.status_code == 403, r_b.text
    assert "issued by" in r_b.json()["detail"]


def test_tenant_requests_counter_labels_present(
    two_tenant_server: tuple[TestClient, str, str, str, str],
) -> None:
    client, raw_a, _, _, _ = two_tenant_server

    def _alice_total() -> float:
        return sum(
            s.value
            for metric in TENANT_REQUESTS.collect()
            for s in metric.samples
            if s.labels.get("tenant_id") == "alice"
        )

    before = _alice_total()
    client.post(
        "/tools/verify_claim",
        json={"claim": "Pi is approximately 3.14159.", "domain": "math", "max_sources": 3},
        headers={"Authorization": f"Bearer {raw_a}"},
    )
    after = _alice_total()
    # Don't assert the exact verdict — the classifier may return
    # OUT_OF_SCOPE on simple math — just assert an alice-labelled
    # counter moved.
    assert after > before


def test_claims_latest_scoped_to_caller_tenant(
    two_tenant_server: tuple[TestClient, str, str, str, str],
) -> None:
    """Tenant B must not see tenant A's lifecycle head for the same
    logical claim unless they explicitly target A's issuer DID."""
    client, raw_a, raw_b, did_a, _ = two_tenant_server
    body = {"claim": "Mercury is the innermost planet.", "domain": "astronomy", "max_sources": 3}

    # A publishes an envelope (registers it in the lifecycle index).
    r_a = client.post("/tools/verify_claim", json=body, headers={"Authorization": f"Bearer {raw_a}"})
    assert r_a.status_code == 200

    # B asks /claims/latest with the same text — scoped to B's DID, must 404.
    r_b = client.get(
        "/claims/latest",
        params={"claim": body["claim"], "domain": body["domain"]},
        headers={"Authorization": f"Bearer {raw_b}"},
    )
    assert r_b.status_code == 404, r_b.text

    # B can still query A's chain explicitly by passing issuer_did=A.
    r_b_explicit = client.get(
        "/claims/latest",
        params={"claim": body["claim"], "domain": body["domain"], "issuer_did": did_a},
        headers={"Authorization": f"Bearer {raw_b}"},
    )
    assert r_b_explicit.status_code == 200, r_b_explicit.text
    assert r_b_explicit.json()["envelope"]["issuer_did"] == did_a
