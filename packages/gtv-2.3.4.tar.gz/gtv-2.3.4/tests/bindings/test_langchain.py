"""Tests for gtv.bindings.langchain — the GtvVerifyTool BaseTool binding."""
from __future__ import annotations

import json
from typing import Any

import httpx
import pytest
import respx

from gtv.bindings.langchain import GtvVerifyTool

_FAKE_ENVELOPE: dict[str, Any] = {
    "envelope_id": "env-1",
    "verdict": "VERIFIED",
    "confidence": 0.95,
    "evidence": [],
    "rationale": "The claim is well-supported by peer-reviewed sources.",
    "issuer_did": "did:web:test",
    "signature": "sig",
    "rekor_uuid": "uuid",
    "rekor_log_index": 0,
    "tsa_token": "tok",
    "prov_graph": "{}",
    "anchor_proof": {
        "rekor_inclusion_proof": "pf",
        "tsa_tsr_primary": "tsr",
    },
}


def test_tool_has_correct_name() -> None:
    """GtvVerifyTool.name should be 'gtv_verify'."""
    tool = GtvVerifyTool()
    assert tool.name == "gtv_verify"


def test_tool_has_description() -> None:
    """GtvVerifyTool.description should be non-empty."""
    tool = GtvVerifyTool()
    assert tool.description
    assert "Verify" in tool.description
    assert "claim" in tool.description.lower()


def test_run_calls_verify_endpoint() -> None:
    """_run should POST to /tools/verify_claim."""
    with respx.mock(base_url="http://localhost:8000") as r:
        route = r.post("/tools/verify_claim").mock(
            return_value=httpx.Response(200, json={"envelope": _FAKE_ENVELOPE})
        )
        tool = GtvVerifyTool(base_url="http://localhost:8000")
        tool._run("The Earth is round")
        assert route.called
        # Verify request body
        req = route.calls.last.request
        body = json.loads(req.content)
        assert body["claim"] == "The Earth is round"
        assert body["domain"] == "general"


def test_run_returns_string_summary() -> None:
    """_run should return a string summary of verdict + rationale."""
    with respx.mock(base_url="http://localhost:8000") as r:
        r.post("/tools/verify_claim").mock(
            return_value=httpx.Response(200, json={"envelope": _FAKE_ENVELOPE})
        )
        tool = GtvVerifyTool(base_url="http://localhost:8000")
        result = tool._run("test claim")
        assert isinstance(result, str)
        assert "VERIFIED" in result
        assert "Verdict:" in result
        assert "confidence:" in result


def test_run_respects_domain_parameter() -> None:
    """_run should pass the domain parameter to the API."""
    with respx.mock(base_url="http://localhost:8000") as r:
        route = r.post("/tools/verify_claim").mock(
            return_value=httpx.Response(200, json={"envelope": _FAKE_ENVELOPE})
        )
        tool = GtvVerifyTool(base_url="http://localhost:8000")
        tool._run("test", domain="physics")
        req = route.calls.last.request
        body = json.loads(req.content)
        assert body["domain"] == "physics"


@pytest.mark.asyncio
async def test_arun_calls_verify_endpoint() -> None:
    """_arun should async POST to /tools/verify_claim."""
    async with respx.mock(base_url="http://localhost:8000") as r:
        route = r.post("/tools/verify_claim").mock(
            return_value=httpx.Response(200, json={"envelope": _FAKE_ENVELOPE})
        )
        tool = GtvVerifyTool(base_url="http://localhost:8000")
        await tool._arun("The Sun is a star")
        assert route.called
        req = route.calls.last.request
        body = json.loads(req.content)
        assert body["claim"] == "The Sun is a star"


@pytest.mark.asyncio
async def test_arun_returns_string_summary() -> None:
    """_arun should return a string summary like _run."""
    async with respx.mock(base_url="http://localhost:8000") as r:
        r.post("/tools/verify_claim").mock(
            return_value=httpx.Response(200, json={"envelope": _FAKE_ENVELOPE})
        )
        tool = GtvVerifyTool(base_url="http://localhost:8000")
        result = await tool._arun("test claim")
        assert isinstance(result, str)
        assert "VERIFIED" in result


def test_constructor_picks_up_env_vars(monkeypatch: pytest.MonkeyPatch) -> None:
    """Constructor should read GTV_BASE_URL and GTV_API_KEY from environment."""
    monkeypatch.setenv("GTV_BASE_URL", "http://custom:9000")
    monkeypatch.setenv("GTV_API_KEY", "secret-key")
    tool = GtvVerifyTool()
    assert tool.base_url == "http://custom:9000"
    assert tool.api_key == "secret-key"


def test_constructor_explicit_args_override_env(monkeypatch: pytest.MonkeyPatch) -> None:
    """Explicit constructor args should override environment variables."""
    monkeypatch.setenv("GTV_BASE_URL", "http://env:8000")
    monkeypatch.setenv("GTV_API_KEY", "env-key")
    tool = GtvVerifyTool(
        base_url="http://explicit:9000", api_key="explicit-key"
    )
    assert tool.base_url == "http://explicit:9000"
    assert tool.api_key == "explicit-key"


def test_respects_api_key_header() -> None:
    """_run should include Authorization header when api_key is set."""
    with respx.mock(base_url="http://localhost:8000") as r:
        route = r.post("/tools/verify_claim").mock(
            return_value=httpx.Response(200, json={"envelope": _FAKE_ENVELOPE})
        )
        tool = GtvVerifyTool(base_url="http://localhost:8000", api_key="test-key")
        tool._run("test")
        auth = route.calls.last.request.headers.get("Authorization")
        assert auth == "Bearer test-key"


def test_omits_api_key_header_when_none() -> None:
    """_run should omit Authorization header when api_key is None."""
    with respx.mock(base_url="http://localhost:8000") as r:
        route = r.post("/tools/verify_claim").mock(
            return_value=httpx.Response(200, json={"envelope": _FAKE_ENVELOPE})
        )
        tool = GtvVerifyTool(base_url="http://localhost:8000", api_key=None)
        tool._run("test")
        assert "Authorization" not in route.calls.last.request.headers


def test_run_handles_http_error() -> None:
    """_run should return error string on HTTP error."""
    with respx.mock(base_url="http://localhost:8000") as r:
        r.post("/tools/verify_claim").mock(
            return_value=httpx.Response(503, text="Service unavailable")
        )
        tool = GtvVerifyTool(base_url="http://localhost:8000")
        result = tool._run("test")
        assert isinstance(result, str)
        assert "Error 503" in result


@pytest.mark.asyncio
async def test_arun_handles_http_error() -> None:
    """_arun should return error string on HTTP error."""
    async with respx.mock(base_url="http://localhost:8000") as r:
        r.post("/tools/verify_claim").mock(
            return_value=httpx.Response(503, text="Service unavailable")
        )
        tool = GtvVerifyTool(base_url="http://localhost:8000")
        result = await tool._arun("test")
        assert isinstance(result, str)
        assert "Error 503" in result


def test_respects_custom_timeout() -> None:
    """Constructor should accept and store custom timeout."""
    tool = GtvVerifyTool(
        base_url="http://localhost:8000",
        timeout=60.0
    )
    assert tool.timeout == 60.0
