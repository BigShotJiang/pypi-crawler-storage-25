"""Tests for gtv.bindings.llamaindex — the GtvFunctionTool binding."""
from __future__ import annotations

import json
from typing import Any

import httpx
import pytest
import respx

from gtv.bindings.llamaindex import GtvFunctionTool, verify_claim

_FAKE_ENVELOPE: dict[str, Any] = {
    "envelope_id": "env-1",
    "verdict": "VERIFIED",
    "confidence": 0.9,
    "evidence": [],
    "rationale": "Multiple peer-reviewed sources confirm this.",
    "issuer_did": "did:web:test",
    "signature": "sig",
    "rekor_uuid": "uuid",
    "rekor_log_index": 0,
    "tsa_token": "tok",
    "prov_graph": "{}",
    "anchor_proof": {
        "rekor_inclusion_proof": "pf",
        "tsa_tsr_primary": "tsr",
    },
}


def test_function_tool_metadata() -> None:
    """GtvFunctionTool should have LlamaIndex-compatible metadata."""
    tool = GtvFunctionTool()
    assert hasattr(tool, "metadata")
    assert tool.metadata.name == "verify_claim"
    assert tool.metadata.description
    assert "Verify" in tool.metadata.description
    assert "claim" in tool.metadata.description.lower()


def test_function_tool_has_fn_attribute() -> None:
    """GtvFunctionTool should expose a callable fn attribute."""
    tool = GtvFunctionTool()
    assert hasattr(tool, "fn")
    assert callable(tool.fn)


def test_verify_claim_happy_path() -> None:
    """verify_claim function should POST to /tools/verify_claim and return envelope."""
    with respx.mock(base_url="http://localhost:8000") as r:
        route = r.post("/tools/verify_claim").mock(
            return_value=httpx.Response(200, json={"envelope": _FAKE_ENVELOPE})
        )
        result = verify_claim("The Earth orbits the Sun")
        assert route.called
        req = route.calls.last.request
        body = json.loads(req.content)
        assert body["claim"] == "The Earth orbits the Sun"
        assert body["domain"] == "general"
        assert result == _FAKE_ENVELOPE


def test_verify_claim_respects_domain(monkeypatch: pytest.MonkeyPatch) -> None:
    """verify_claim should pass the domain parameter."""
    monkeypatch.setenv("GTV_BASE_URL", "http://localhost:8000")
    with respx.mock(base_url="http://localhost:8000") as r:
        route = r.post("/tools/verify_claim").mock(
            return_value=httpx.Response(200, json={"envelope": _FAKE_ENVELOPE})
        )
        verify_claim("E=mc²", domain="physics")
        req = route.calls.last.request
        body = json.loads(req.content)
        assert body["domain"] == "physics"


def test_verify_claim_uses_env_vars(monkeypatch: pytest.MonkeyPatch) -> None:
    """verify_claim should read GTV_BASE_URL and GTV_API_KEY from env."""
    monkeypatch.setenv("GTV_BASE_URL", "http://custom:9000")
    monkeypatch.setenv("GTV_API_KEY", "env-secret")
    with respx.mock(base_url="http://custom:9000") as r:
        route = r.post("/tools/verify_claim").mock(
            return_value=httpx.Response(200, json={"envelope": _FAKE_ENVELOPE})
        )
        verify_claim("test")
        req = route.calls.last.request
        assert req.headers.get("Authorization") == "Bearer env-secret"


def test_function_tool_factory() -> None:
    """GtvFunctionTool.from_defaults should create a tool instance."""
    tool = GtvFunctionTool.from_defaults(
        base_url="http://custom:8000",
        api_key="factory-key"
    )
    assert tool.base_url == "http://custom:8000"
    assert tool.api_key == "factory-key"
    assert tool.metadata.name == "verify_claim"


def test_function_tool_fn_respects_config() -> None:
    """tool.fn should use the tool's configured base_url and api_key."""
    with respx.mock(base_url="http://custom:9000") as r:
        route = r.post("/tools/verify_claim").mock(
            return_value=httpx.Response(200, json={"envelope": _FAKE_ENVELOPE})
        )
        tool = GtvFunctionTool(
            base_url="http://custom:9000",
            api_key="tool-key"
        )
        tool.fn("test claim")
        req = route.calls.last.request
        assert req.headers.get("Authorization") == "Bearer tool-key"


def test_handles_http_error_gracefully() -> None:
    """verify_claim should raise on HTTP error."""
    with respx.mock(base_url="http://localhost:8000") as r:
        r.post("/tools/verify_claim").mock(
            return_value=httpx.Response(503, text="Service down")
        )
        with pytest.raises(httpx.HTTPError, match="HTTP 503"):
            verify_claim("test")


def test_function_tool_handles_malformed_response() -> None:
    """GtvFunctionTool.fn should raise on missing/invalid envelope."""
    with respx.mock(base_url="http://localhost:8000") as r:
        r.post("/tools/verify_claim").mock(
            return_value=httpx.Response(200, json={"no_envelope": "here"})
        )
        tool = GtvFunctionTool(base_url="http://localhost:8000")
        with pytest.raises(ValueError, match="expected envelope dict"):
            tool.fn("test")


def test_respects_custom_timeout(monkeypatch: pytest.MonkeyPatch) -> None:
    """GtvFunctionTool should respect custom timeout."""
    monkeypatch.setenv("GTV_BASE_URL", "http://localhost:8000")
    tool = GtvFunctionTool(timeout=60.0)
    assert tool.timeout == 60.0


def test_verify_claim_reads_timeout_from_env(monkeypatch: pytest.MonkeyPatch) -> None:
    """verify_claim should read GTV_TIMEOUT from environment."""
    monkeypatch.setenv("GTV_BASE_URL", "http://localhost:8000")
    monkeypatch.setenv("GTV_TIMEOUT", "45.0")
    with respx.mock(base_url="http://localhost:8000") as r:
        r.post("/tools/verify_claim").mock(
            return_value=httpx.Response(200, json={"envelope": _FAKE_ENVELOPE})
        )
        # Just verify it doesn't crash with the env timeout
        verify_claim("test")


def test_function_tool_from_defaults_with_env_vars(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """from_defaults should use env vars as fallback."""
    monkeypatch.setenv("GTV_BASE_URL", "http://env:8000")
    monkeypatch.setenv("GTV_API_KEY", "env-key")
    tool = GtvFunctionTool.from_defaults()
    assert tool.base_url == "http://env:8000"
    assert tool.api_key == "env-key"


def test_function_tool_explicit_overrides_env(monkeypatch: pytest.MonkeyPatch) -> None:
    """from_defaults explicit args should override env vars."""
    monkeypatch.setenv("GTV_BASE_URL", "http://env:8000")
    monkeypatch.setenv("GTV_API_KEY", "env-key")
    tool = GtvFunctionTool.from_defaults(
        base_url="http://override:9000",
        api_key="override-key"
    )
    assert tool.base_url == "http://override:9000"
    assert tool.api_key == "override-key"
