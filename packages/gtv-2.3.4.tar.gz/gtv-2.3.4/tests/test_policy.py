"""Unit tests for the consensus policy DSL.

Covers: default equivalence (legacy parity), per-domain overrides,
YAML loading / error paths, env integration, and the verdict engine
honoring custom thresholds.
"""
from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path

import pytest
from pydantic import HttpUrl

from gtv.models import (
    Claim,
    Domain,
    Evidence,
    Stance,
    TrustTier,
    Verdict,
)
from gtv.policy import (
    DEFAULT_POLICY,
    ConfidenceFormula,
    DomainPolicy,
    Policy,
    PolicyError,
    TierWeights,
    load_policy,
    load_policy_from_env,
)
from gtv.verdict.engine import VerdictInputs, decide


def _ev(source_did: str, stance: Stance = Stance.SUPPORTS) -> Evidence:
    return Evidence(
        claim_id="c",
        source_did=source_did,
        source_version="v1",
        stance=stance,
        excerpt="e",
        url=HttpUrl("https://x.example/e"),
        retrieved_at=datetime.now(tz=UTC),
        raw_hash="0" * 64,
    )


def _claim(domain: Domain = Domain.PHYSICS) -> Claim:
    return Claim(text="The sky is blue", domain=domain)


# ---------------------------------------------------------------------
# Default policy = legacy parity
# ---------------------------------------------------------------------


def test_default_policy_values_match_legacy_constants() -> None:
    """Regression guard: the default policy must match the old
    hardcoded constants, otherwise we silently change verdicts for
    every existing caller."""
    r = DEFAULT_POLICY.for_domain(Domain.PHYSICS)
    assert r.min_supports_for_verified == 2
    assert r.min_refutes_for_negation == 2
    assert r.tier_weights.tier_1 == 1.0
    assert r.tier_weights.tier_2 == 0.7
    assert r.tier_weights.tier_3 == 0.4
    assert r.confidence.base == 0.5
    assert r.confidence.per_source == 0.15
    assert r.confidence.per_tier_bonus == 0.05
    assert r.confidence.age_penalty == 0.1
    assert r.confidence.age_horizon_months == 60.0


def test_decide_without_policy_matches_decide_with_default() -> None:
    inputs = VerdictInputs(
        claim=_claim(),
        evidence=[_ev("did:web:a"), _ev("did:web:b")],
        tier_of={"did:web:a": TrustTier.TIER_1, "did:web:b": TrustTier.TIER_1},
    )
    r1 = decide(inputs)
    r2 = decide(inputs, DEFAULT_POLICY)
    # Rationales must match exactly; confidence may drift by < 1e-9
    # because of datetime.now() between the two calls.
    assert r1.decision == r2.decision == Verdict.VERIFIED
    assert r1.rationale == r2.rationale
    assert abs(r1.confidence - r2.confidence) < 1e-6


# ---------------------------------------------------------------------
# Policy actually changes behavior
# ---------------------------------------------------------------------


def test_stricter_policy_rejects_single_source() -> None:
    """If min_supports_for_verified is 3, two sources should NOT
    flip to VERIFIED."""
    strict = Policy(min_supports_for_verified=3)
    inputs = VerdictInputs(
        claim=_claim(),
        evidence=[_ev("did:web:a"), _ev("did:web:b")],
        tier_of={
            "did:web:a": TrustTier.TIER_1,
            "did:web:b": TrustTier.TIER_1,
        },
    )
    r = decide(inputs, strict)
    assert r.decision == Verdict.UNVERIFIED


def test_looser_per_domain_policy() -> None:
    """Global threshold = 3 but physics override = 1. A single physics
    source should now verify."""
    policy = Policy(
        min_supports_for_verified=3,
        domains={"physics": DomainPolicy(min_supports_for_verified=1)},
    )
    inputs = VerdictInputs(
        claim=_claim(Domain.PHYSICS),
        evidence=[_ev("did:web:a")],
        tier_of={"did:web:a": TrustTier.TIER_1},
    )
    r = decide(inputs, policy)
    assert r.decision == Verdict.VERIFIED


def test_per_domain_does_not_bleed_across_domains() -> None:
    """Physics override must not affect biology."""
    policy = Policy(
        min_supports_for_verified=3,
        domains={"physics": DomainPolicy(min_supports_for_verified=1)},
    )
    inputs = VerdictInputs(
        claim=_claim(Domain.MATH),
        evidence=[_ev("did:web:a")],
        tier_of={"did:web:a": TrustTier.TIER_1},
    )
    r = decide(inputs, policy)
    assert r.decision != Verdict.VERIFIED


def test_confidence_formula_override_changes_output() -> None:
    """A higher base must raise the confidence number."""
    bumped = Policy(confidence=ConfidenceFormula(base=0.9))
    inputs = VerdictInputs(
        claim=_claim(),
        evidence=[_ev("did:web:a"), _ev("did:web:b")],
        tier_of={"did:web:a": TrustTier.TIER_1, "did:web:b": TrustTier.TIER_1},
    )
    r_default = decide(inputs, DEFAULT_POLICY)
    r_bumped = decide(inputs, bumped)
    assert r_bumped.confidence > r_default.confidence


def test_tier_weights_override_changes_confidence() -> None:
    """Zeroing out tier weights should strictly lower the confidence."""
    zeroed = Policy(tier_weights=TierWeights(tier_1=0.0, tier_2=0.0, tier_3=0.0))
    inputs = VerdictInputs(
        claim=_claim(),
        evidence=[_ev("did:web:a"), _ev("did:web:b")],
        tier_of={"did:web:a": TrustTier.TIER_1, "did:web:b": TrustTier.TIER_1},
    )
    r_default = decide(inputs, DEFAULT_POLICY)
    r_zeroed = decide(inputs, zeroed)
    assert r_zeroed.confidence < r_default.confidence


# ---------------------------------------------------------------------
# YAML loading
# ---------------------------------------------------------------------


def test_load_policy_happy_path(tmp_path: Path) -> None:
    p = tmp_path / "policy.yaml"
    p.write_text(
        """\
min_supports_for_verified: 3
tier_weights:
  tier_1: 0.9
confidence:
  base: 0.6
domains:
  physics:
    min_supports_for_verified: 1
""",
        encoding="utf-8",
    )
    policy = load_policy(p)
    assert policy.min_supports_for_verified == 3
    assert policy.tier_weights.tier_1 == 0.9
    assert policy.confidence.base == 0.6
    assert policy.domains["physics"].min_supports_for_verified == 1


def test_load_policy_empty_file_is_default(tmp_path: Path) -> None:
    p = tmp_path / "policy.yaml"
    p.write_text("", encoding="utf-8")
    policy = load_policy(p)
    assert policy == DEFAULT_POLICY


def test_load_policy_missing_file_raises(tmp_path: Path) -> None:
    with pytest.raises(PolicyError, match="not found"):
        load_policy(tmp_path / "does-not-exist.yaml")


def test_load_policy_malformed_yaml_raises(tmp_path: Path) -> None:
    p = tmp_path / "bad.yaml"
    p.write_text(": : :", encoding="utf-8")
    with pytest.raises(PolicyError, match="Malformed YAML"):
        load_policy(p)


def test_load_policy_rejects_unknown_domain_key(tmp_path: Path) -> None:
    p = tmp_path / "policy.yaml"
    p.write_text(
        """\
domains:
  nonsense_domain:
    min_supports_for_verified: 1
""",
        encoding="utf-8",
    )
    with pytest.raises(PolicyError, match="Unknown domain"):
        load_policy(p)


def test_load_policy_rejects_negative_threshold(tmp_path: Path) -> None:
    p = tmp_path / "policy.yaml"
    p.write_text("min_supports_for_verified: 0\n", encoding="utf-8")
    with pytest.raises(PolicyError):
        load_policy(p)


def test_load_policy_rejects_out_of_range_tier_weight(tmp_path: Path) -> None:
    p = tmp_path / "policy.yaml"
    p.write_text(
        """\
tier_weights:
  tier_1: 1.5
""",
        encoding="utf-8",
    )
    with pytest.raises(PolicyError):
        load_policy(p)


def test_load_policy_rejects_non_mapping_toplevel(tmp_path: Path) -> None:
    p = tmp_path / "policy.yaml"
    p.write_text("- just\n- a\n- list\n", encoding="utf-8")
    with pytest.raises(PolicyError, match="mapping at the top level"):
        load_policy(p)


# ---------------------------------------------------------------------
# Env integration
# ---------------------------------------------------------------------


def test_load_from_env_unset_returns_default(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("GTV_POLICY_PATH", raising=False)
    assert load_policy_from_env() == DEFAULT_POLICY


def test_load_from_env_set_but_missing_raises(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    monkeypatch.setenv("GTV_POLICY_PATH", str(tmp_path / "nope.yaml"))
    with pytest.raises(PolicyError):
        load_policy_from_env()


def test_load_from_env_set_and_valid(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    p = tmp_path / "policy.yaml"
    p.write_text("min_supports_for_verified: 5\n", encoding="utf-8")
    monkeypatch.setenv("GTV_POLICY_PATH", str(p))
    policy = load_policy_from_env()
    assert policy.min_supports_for_verified == 5
