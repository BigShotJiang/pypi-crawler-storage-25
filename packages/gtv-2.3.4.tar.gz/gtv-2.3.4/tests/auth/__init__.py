"""Tests for gtv.auth module."""
