"""Tests for OIDC SSO verifier."""
from __future__ import annotations

import os
import time
from datetime import UTC, datetime, timedelta
from typing import Any

import httpx
import jwt
import pytest
import respx
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ec, rsa

from gtv.auth.oidc import (
    OidcAuthError,
    OidcConfig,
    OidcVerifier,
    load_oidc_config_from_env,
)

# ============================================================================
# Fixtures: Generate test keys and tokens
# ============================================================================


@pytest.fixture
def rsa_key_pair() -> tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey]:
    """Generate an RSA key pair for testing."""
    private_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=2048,
        backend=default_backend()
    )
    public_key = private_key.public_key()
    return private_key, public_key


@pytest.fixture
def ec_key_pair() -> tuple[ec.EllipticCurvePrivateKey, ec.EllipticCurvePublicKey]:
    """Generate an EC key pair for testing (P-256)."""
    private_key = ec.generate_private_key(ec.SECP256R1(), default_backend())
    public_key = private_key.public_key()
    return private_key, public_key


def jwk_from_rsa_public_key(public_key: rsa.RSAPublicKey, kid: str) -> dict[str, Any]:
    """Convert RSA public key to JWK."""
    public_numbers = public_key.public_numbers()
    import base64

    def int_to_base64url(n: int, length: int) -> str:
        return base64.urlsafe_b64encode(
            n.to_bytes(length, "big")
        ).rstrip(b"=").decode("ascii")

    return {
        "kty": "RSA",
        "kid": kid,
        "alg": "RS256",
        "use": "sig",
        "n": int_to_base64url(public_numbers.n, 256),
        "e": int_to_base64url(public_numbers.e, 3),
    }


def jwk_from_ec_public_key(public_key: ec.EllipticCurvePublicKey, kid: str) -> dict[str, Any]:
    """Convert EC public key to JWK."""
    public_numbers = public_key.public_numbers()
    import base64

    def int_to_base64url(n: int, length: int) -> str:
        return base64.urlsafe_b64encode(
            n.to_bytes(length, "big")
        ).rstrip(b"=").decode("ascii")

    return {
        "kty": "EC",
        "kid": kid,
        "alg": "ES256",
        "crv": "P-256",
        "use": "sig",
        "x": int_to_base64url(public_numbers.x, 32),
        "y": int_to_base64url(public_numbers.y, 32),
    }


def create_jwt_rs256(
    private_key: rsa.RSAPrivateKey,
    kid: str,
    claims: dict[str, Any],
) -> str:
    """Create a JWT signed with RS256."""
    pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    return jwt.encode(claims, pem, algorithm="RS256", headers={"kid": kid})


def create_jwt_es256(
    private_key: ec.EllipticCurvePrivateKey,
    kid: str,
    claims: dict[str, Any],
) -> str:
    """Create a JWT signed with ES256."""
    pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    return jwt.encode(claims, pem, algorithm="ES256", headers={"kid": kid})


@pytest.fixture
def oidc_config() -> OidcConfig:
    """OIDC configuration for testing."""
    return OidcConfig(
        issuer="https://example.okta.com",
        audience="test-audience",
        jwks_url="https://example.okta.com/.well-known/jwks.json",
    )


# ============================================================================
# Tests
# ============================================================================


@pytest.mark.asyncio
async def test_verify_rs256_valid(
    rsa_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    oidc_config: OidcConfig,
) -> None:
    """Test verifying a valid RS256 token."""
    private_key, public_key = rsa_key_pair
    kid = "test-key-rsa"

    # Create token with valid claims
    now = datetime.now(UTC)  # type: ignore[attr-defined]
    claims = {
        "sub": "user123",
        "email": "user@example.com",
        "tenant_id": "tenant-abc",
        "scope": "openid profile email",
        "iss": oidc_config.issuer,
        "aud": oidc_config.audience,
        "exp": (now + timedelta(hours=1)).timestamp(),
        "iat": now.timestamp(),
    }
    token = create_jwt_rs256(private_key, kid, claims)

    # Mock JWKS endpoint
    jwk = jwk_from_rsa_public_key(public_key, kid)
    with respx.mock:
        respx.get(oidc_config.jwks_url).mock(
            return_value=httpx.Response(200, json={"keys": [jwk]})
        )

        verifier = OidcVerifier(oidc_config)
        try:
            principal = await verifier.verify(token)
            assert principal.sub == "user123"
            assert principal.email == "user@example.com"
            assert principal.tenant_id == "tenant-abc"
            assert principal.scopes == ["openid", "profile", "email"]
        finally:
            await verifier.close()


@pytest.mark.asyncio
async def test_verify_es256_valid(
    ec_key_pair: tuple[ec.EllipticCurvePrivateKey, ec.EllipticCurvePublicKey],
    oidc_config: OidcConfig,
) -> None:
    """Test verifying a valid ES256 token."""
    private_key, public_key = ec_key_pair
    kid = "test-key-ec"

    # Create token with valid claims
    now = datetime.now(UTC)
    claims = {
        "sub": "user456",
        "email": "user456@example.com",
        "iss": oidc_config.issuer,
        "aud": oidc_config.audience,
        "exp": (now + timedelta(hours=1)).timestamp(),
        "iat": now.timestamp(),
    }
    token = create_jwt_es256(private_key, kid, claims)

    # Mock JWKS endpoint
    jwk = jwk_from_ec_public_key(public_key, kid)
    with respx.mock:
        respx.get(oidc_config.jwks_url).mock(
            return_value=httpx.Response(200, json={"keys": [jwk]})
        )

        verifier = OidcVerifier(oidc_config)
        try:
            principal = await verifier.verify(token)
            assert principal.sub == "user456"
            assert principal.email == "user456@example.com"
            assert principal.tenant_id is None
        finally:
            await verifier.close()


@pytest.mark.asyncio
async def test_verify_expired_token(
    rsa_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    oidc_config: OidcConfig,
) -> None:
    """Test that expired tokens are rejected."""
    private_key, public_key = rsa_key_pair
    kid = "test-key-rsa"

    # Create expired token
    now = datetime.now(UTC)
    claims = {
        "sub": "user123",
        "iss": oidc_config.issuer,
        "aud": oidc_config.audience,
        "exp": (now - timedelta(hours=1)).timestamp(),
        "iat": (now - timedelta(hours=2)).timestamp(),
    }
    token = create_jwt_rs256(private_key, kid, claims)

    # Mock JWKS endpoint
    jwk = jwk_from_rsa_public_key(public_key, kid)
    with respx.mock:
        respx.get(oidc_config.jwks_url).mock(
            return_value=httpx.Response(200, json={"keys": [jwk]})
        )

        verifier = OidcVerifier(oidc_config)
        try:
            with pytest.raises(OidcAuthError, match="Token expired"):
                await verifier.verify(token)
        finally:
            await verifier.close()


@pytest.mark.asyncio
async def test_verify_wrong_audience(
    rsa_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    oidc_config: OidcConfig,
) -> None:
    """Test that wrong audience is rejected."""
    private_key, public_key = rsa_key_pair
    kid = "test-key-rsa"

    # Create token with wrong audience
    now = datetime.now(UTC)
    claims = {
        "sub": "user123",
        "iss": oidc_config.issuer,
        "aud": "wrong-audience",
        "exp": (now + timedelta(hours=1)).timestamp(),
        "iat": now.timestamp(),
    }
    token = create_jwt_rs256(private_key, kid, claims)

    # Mock JWKS endpoint
    jwk = jwk_from_rsa_public_key(public_key, kid)
    with respx.mock:
        respx.get(oidc_config.jwks_url).mock(
            return_value=httpx.Response(200, json={"keys": [jwk]})
        )

        verifier = OidcVerifier(oidc_config)
        try:
            with pytest.raises(OidcAuthError, match="Invalid audience"):
                await verifier.verify(token)
        finally:
            await verifier.close()


@pytest.mark.asyncio
async def test_verify_wrong_issuer(
    rsa_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    oidc_config: OidcConfig,
) -> None:
    """Test that wrong issuer is rejected."""
    private_key, public_key = rsa_key_pair
    kid = "test-key-rsa"

    # Create token with wrong issuer
    now = datetime.now(UTC)
    claims = {
        "sub": "user123",
        "iss": "https://wrong-issuer.com",
        "aud": oidc_config.audience,
        "exp": (now + timedelta(hours=1)).timestamp(),
        "iat": now.timestamp(),
    }
    token = create_jwt_rs256(private_key, kid, claims)

    # Mock JWKS endpoint
    jwk = jwk_from_rsa_public_key(public_key, kid)
    with respx.mock:
        respx.get(oidc_config.jwks_url).mock(
            return_value=httpx.Response(200, json={"keys": [jwk]})
        )

        verifier = OidcVerifier(oidc_config)
        try:
            with pytest.raises(OidcAuthError, match="Invalid issuer"):
                await verifier.verify(token)
        finally:
            await verifier.close()


@pytest.mark.asyncio
async def test_verify_no_kid_in_header(
    rsa_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    oidc_config: OidcConfig,
) -> None:
    """Test that tokens without kid in header are rejected."""
    private_key, _public_key = rsa_key_pair

    # Create token without kid
    now = datetime.now(UTC)
    claims = {
        "sub": "user123",
        "iss": oidc_config.issuer,
        "aud": oidc_config.audience,
        "exp": (now + timedelta(hours=1)).timestamp(),
        "iat": now.timestamp(),
    }
    pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    token = jwt.encode(claims, pem, algorithm="RS256")  # No kid header

    with respx.mock:
        respx.get(oidc_config.jwks_url).mock(
            return_value=httpx.Response(200, json={"keys": []})
        )

        verifier = OidcVerifier(oidc_config)
        try:
            with pytest.raises(OidcAuthError, match="Missing 'kid'"):
                await verifier.verify(token)
        finally:
            await verifier.close()


@pytest.mark.asyncio
async def test_verify_kid_not_in_jwks(
    rsa_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    oidc_config: OidcConfig,
) -> None:
    """Test that kid not in JWKS triggers a refetch then fails."""
    private_key, _public_key = rsa_key_pair
    kid = "nonexistent-key"

    # Create token with valid signature but kid not in JWKS
    now = datetime.now(UTC)
    claims = {
        "sub": "user123",
        "iss": oidc_config.issuer,
        "aud": oidc_config.audience,
        "exp": (now + timedelta(hours=1)).timestamp(),
        "iat": now.timestamp(),
    }
    token = create_jwt_rs256(private_key, kid, claims)

    with respx.mock:
        # First call returns empty JWKS, second call also returns empty
        respx.get(oidc_config.jwks_url).mock(
            return_value=httpx.Response(200, json={"keys": []})
        )

        verifier = OidcVerifier(oidc_config)
        try:
            with pytest.raises(OidcAuthError, match=r"Key with kid .* not found in JWKS"):
                await verifier.verify(token)
        finally:
            await verifier.close()


@pytest.mark.asyncio
async def test_verify_jwks_unreachable(
    rsa_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    oidc_config: OidcConfig,
) -> None:
    """Test that unreachable JWKS endpoint is handled."""
    private_key, _public_key = rsa_key_pair
    kid = "test-key-rsa"

    # Create a valid token
    now = datetime.now(UTC)
    claims = {
        "sub": "user123",
        "iss": oidc_config.issuer,
        "aud": oidc_config.audience,
        "exp": (now + timedelta(hours=1)).timestamp(),
        "iat": now.timestamp(),
    }
    token = create_jwt_rs256(private_key, kid, claims)

    with respx.mock:
        # JWKS endpoint is unreachable
        respx.get(oidc_config.jwks_url).mock(
            side_effect=httpx.ConnectError("Connection refused")
        )

        verifier = OidcVerifier(oidc_config)
        try:
            with pytest.raises(OidcAuthError, match="Failed to fetch JWKS"):
                await verifier.verify(token)
        finally:
            await verifier.close()


@pytest.mark.asyncio
async def test_verify_unsigned_token(oidc_config: OidcConfig) -> None:
    """Test that HS256 tokens (unsupported algorithm) are rejected."""
    # Create an HS256-signed token (not RS256/ES256)
    now = datetime.now(UTC)
    claims = {
        "sub": "user123",
        "iss": oidc_config.issuer,
        "aud": oidc_config.audience,
        "exp": (now + timedelta(hours=1)).timestamp(),
        "iat": now.timestamp(),
    }

    # Add kid to header so we get past that check
    token = jwt.encode(claims, "secret-key", algorithm="HS256", headers={"kid": "test"})

    with respx.mock:
        respx.get(oidc_config.jwks_url).mock(
            return_value=httpx.Response(200, json={"keys": []})
        )

        verifier = OidcVerifier(oidc_config)
        try:
            with pytest.raises(OidcAuthError, match="Unsupported algorithm"):
                await verifier.verify(token)
        finally:
            await verifier.close()


@pytest.mark.asyncio
async def test_jwks_cache_ttl(
    rsa_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    oidc_config: OidcConfig,
) -> None:
    """Test that JWKS is cached and refetched after TTL expires."""
    private_key, public_key = rsa_key_pair
    kid = "test-key-rsa"

    # Create two tokens
    now = datetime.now(UTC)
    claims = {
        "sub": "user123",
        "iss": oidc_config.issuer,
        "aud": oidc_config.audience,
        "exp": (now + timedelta(hours=1)).timestamp(),
        "iat": now.timestamp(),
    }
    token1 = create_jwt_rs256(private_key, kid, claims)
    token2 = create_jwt_rs256(private_key, kid, claims)

    # Mock JWKS endpoint
    jwk = jwk_from_rsa_public_key(public_key, kid)

    # Use a short TTL
    short_ttl_config = OidcConfig(
        issuer=oidc_config.issuer,
        audience=oidc_config.audience,
        jwks_url=oidc_config.jwks_url,
        jwks_cache_ttl_s=1,
    )

    with respx.mock:
        route = respx.get(oidc_config.jwks_url).mock(
            return_value=httpx.Response(200, json={"keys": [jwk]})
        )

        verifier = OidcVerifier(short_ttl_config)
        try:
            # First verify — should fetch JWKS
            await verifier.verify(token1)
            assert route.called
            call_count_1 = route.call_count

            # Second verify immediately — should use cache
            await verifier.verify(token2)
            call_count_2 = route.call_count
            assert call_count_2 == call_count_1, "JWKS should be cached"

            # Wait for TTL to expire
            await verifier.close()
            time.sleep(1.1)

            # Create new verifier and verify again — should refetch JWKS
            verifier = OidcVerifier(short_ttl_config)
            await verifier.verify(token1)
            call_count_3 = route.call_count
            assert call_count_3 > call_count_2, "JWKS cache should have expired"
        finally:
            await verifier.close()


def test_load_oidc_config_from_env(monkeypatch: pytest.MonkeyPatch) -> None:
    """Test loading OIDC config from environment variables."""
    monkeypatch.setenv("GTV_OIDC_ISSUER", "https://example.okta.com")
    monkeypatch.setenv("GTV_OIDC_AUDIENCE", "test-audience")
    monkeypatch.setenv("GTV_OIDC_JWKS_URL", "https://example.okta.com/.well-known/jwks.json")
    monkeypatch.setenv("GTV_OIDC_JWKS_CACHE_TTL_S", "7200")

    config = load_oidc_config_from_env()
    assert config is not None
    assert config.issuer == "https://example.okta.com"
    assert config.audience == "test-audience"
    assert config.jwks_url == "https://example.okta.com/.well-known/jwks.json"
    assert config.jwks_cache_ttl_s == 7200


def test_load_oidc_config_from_env_not_set() -> None:
    """Test that load_oidc_config_from_env returns None if issuer unset."""
    # Make sure env var is not set
    os.environ.pop("GTV_OIDC_ISSUER", None)
    config = load_oidc_config_from_env()
    assert config is None


def test_load_oidc_config_from_env_missing_audience(monkeypatch: pytest.MonkeyPatch) -> None:
    """Test that missing audience raises ValueError."""
    monkeypatch.setenv("GTV_OIDC_ISSUER", "https://example.okta.com")
    monkeypatch.delenv("GTV_OIDC_AUDIENCE", raising=False)

    with pytest.raises(ValueError, match="GTV_OIDC_AUDIENCE"):
        load_oidc_config_from_env()


@pytest.mark.asyncio
async def test_tenant_claim_configurable(
    rsa_key_pair: tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey],
    oidc_config: OidcConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Test that tenant claim is configurable via GTV_OIDC_TENANT_CLAIM."""
    private_key, public_key = rsa_key_pair
    kid = "test-key-rsa"

    monkeypatch.setenv("GTV_OIDC_TENANT_CLAIM", "custom_tenant")

    # Create token with custom tenant claim
    now = datetime.now(UTC)
    claims = {
        "sub": "user123",
        "iss": oidc_config.issuer,
        "aud": oidc_config.audience,
        "custom_tenant": "custom-tenant-123",
        "exp": (now + timedelta(hours=1)).timestamp(),
        "iat": now.timestamp(),
    }
    token = create_jwt_rs256(private_key, kid, claims)

    # Mock JWKS endpoint
    jwk = jwk_from_rsa_public_key(public_key, kid)
    with respx.mock:
        respx.get(oidc_config.jwks_url).mock(
            return_value=httpx.Response(200, json={"keys": [jwk]})
        )

        verifier = OidcVerifier(oidc_config)
        try:
            principal = await verifier.verify(token)
            assert principal.tenant_id == "custom-tenant-123"
        finally:
            await verifier.close()
