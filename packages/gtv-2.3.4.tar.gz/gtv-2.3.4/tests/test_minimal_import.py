"""Import smoke test for the Week 15 audit module.

Replaced an earlier agent scratchpad; kept as a real (minimal) test so the
filename stays stable for git history.
"""
from __future__ import annotations


def test_audit_module_importable() -> None:
    """gtv.audit and gtv.audit.store must import cleanly."""
    import gtv.audit
    from gtv.audit import AuditRecord, AuditStore

    assert gtv.audit is not None
    assert AuditStore is not None
    assert AuditRecord is not None
