"""Property-based tests for the verdict engine decision logic.

These tests use Hypothesis to verify invariants that must hold for all evidence combinations:
- Confidence bounds: always in [0.0, 0.99]
- Monotonicity in evidence: more evidence doesn't decrease confidence
- Monotonicity in tier: higher tier doesn't decrease confidence
- Verdict stability: same inputs always produce identical VerdictRecord
- Empty-evidence invariant: zero evidence returns UNVERIFIED with confidence < 0.5

These properties catch edge cases in the confidence formula, tier weighting,
and decision logic that unit tests alone wouldn't reveal.
"""
from __future__ import annotations

from datetime import UTC, datetime, timedelta

from hypothesis import given
from hypothesis import strategies as st

from gtv.models import Claim, Evidence, Stance, TrustTier, Verdict
from gtv.verdict.engine import VerdictInputs, decide


# Helper to create Evidence at a specific age
def make_evidence(
    source_did: str,
    stance: Stance,
    claim_id: str,
    age_months: int = 0,
) -> Evidence:
    """Create Evidence with a specific age in months."""
    retrieved_at = datetime.now(tz=UTC) - timedelta(days=max(0, age_months * 30))
    return Evidence(
        claim_id=claim_id,
        source_did=source_did,
        source_version="v1",
        stance=stance,
        excerpt="test evidence",
        url="https://example.org/test",
        retrieved_at=retrieved_at,
        raw_hash="a" * 64,
    )


# Strategies for generating Claims and Evidence
claim_strategy = st.builds(
    Claim,
    # Exclude null bytes (blocked by Claim.text validator) and other C0 controls
    # that serialize poorly in JSON/logs. Printable BMP is plenty for property tests.
    text=st.text(
        alphabet=st.characters(blacklist_categories=("Cs",), blacklist_characters="\x00"),
        min_size=1,
        max_size=100,
    ),
)

trust_tier_strategy = st.sampled_from([TrustTier.TIER_1, TrustTier.TIER_2, TrustTier.TIER_3])

# Helper to generate DID strings
did_names = st.text(
    min_size=8,
    max_size=20,
    alphabet="abcdefghijklmnopqrstuvwxyz0123456789.-",
)
did_strategy_fn = did_names.map(lambda name: f"did:web:{name}")


# Generate a list of distinct sources with their tiers
source_tier_map_strategy = st.dictionaries(
    did_strategy_fn,
    trust_tier_strategy,
    min_size=0,
    max_size=5,
)


@given(
    claim_strategy,
    st.lists(
        st.builds(
            make_evidence,
            source_did=did_strategy_fn,
            stance=st.sampled_from([Stance.SUPPORTS, Stance.REFUTES]),
            claim_id=st.just(""),  # will be overridden below
            age_months=st.integers(min_value=0, max_value=120),
        ),
        max_size=10,
    ),
    source_tier_map_strategy,
)
def test_confidence_bounds(
    claim: Claim,
    evidence_raw: list[Evidence],
    tier_of: dict[str, TrustTier],
) -> None:
    """Property: confidence is always in [0.0, 0.99] for any valid VerdictInputs.

    The confidence formula must clamp to this range by design.
    """
    # Fix claim_id in evidence
    evidence = [
        Evidence(
            claim_id=claim.claim_id,
            source_did=e.source_did,
            source_version=e.source_version,
            stance=e.stance,
            excerpt=e.excerpt,
            url=e.url,
            retrieved_at=e.retrieved_at,
            raw_hash=e.raw_hash,
        )
        for e in evidence_raw
    ]

    inputs = VerdictInputs(
        claim=claim,
        evidence=evidence,
        tier_of=tier_of if tier_of else None,
    )

    result = decide(inputs)

    assert 0.0 <= result.confidence <= 0.99, (
        f"Confidence out of bounds: {result.confidence} (inputs: claim={claim.claim_id}, "
        f"evidence_count={len(evidence)}, decision={result.decision})"
    )


@given(
    claim_strategy,
    st.data(),
)
def test_monotonicity_in_evidence_count(claim: Claim, data: st.DataObject) -> None:
    """Property: holding tier + age fixed, more evidence doesn't decrease confidence.

    Additional corroboration should increase or maintain confidence.
    """
    # Generate 1-3 supports with same tier and age
    base_age = data.draw(st.integers(min_value=0, max_value=24))
    tier = data.draw(trust_tier_strategy)

    source_count = data.draw(st.integers(min_value=1, max_value=3))
    sources_base = [f"did:web:source{i}" for i in range(source_count)]

    evidence_base = [
        make_evidence(s, Stance.SUPPORTS, claim.claim_id, age_months=base_age)
        for s in sources_base
    ]

    tier_map = dict.fromkeys(sources_base, tier)

    # Confidence with base evidence
    result_base = decide(
        VerdictInputs(claim=claim, evidence=evidence_base, tier_of=tier_map)
    )

    # Add one more independent support source
    extra_source = "did:web:extra"
    extra_evidence = make_evidence(extra_source, Stance.SUPPORTS, claim.claim_id, age_months=base_age)
    evidence_more = [*evidence_base, extra_evidence]
    tier_map_more = {**tier_map, extra_source: tier}

    result_more = decide(
        VerdictInputs(claim=claim, evidence=evidence_more, tier_of=tier_map_more)
    )

    assert result_more.confidence >= result_base.confidence - 1e-9, (
        f"Confidence decreased with more evidence: "
        f"base={result_base.confidence:.4f}, more={result_more.confidence:.4f}, "
        f"sources_base={len(sources_base)}, sources_more={len(evidence_more)}"
    )


@given(
    claim_strategy,
    st.data(),
)
def test_monotonicity_in_tier(claim: Claim, data: st.DataObject) -> None:
    """Property: holding count + age fixed, higher tier doesn't decrease confidence.

    Upgrading source tiers should increase or maintain confidence.
    """
    age = data.draw(st.integers(min_value=0, max_value=24))
    count = data.draw(st.integers(min_value=2, max_value=3))

    sources = [f"did:web:source{i}" for i in range(count)]

    evidence = [
        make_evidence(s, Stance.SUPPORTS, claim.claim_id, age_months=age)
        for s in sources
    ]

    # Confidence with TIER_3
    tier_map_low = dict.fromkeys(sources, TrustTier.TIER_3)
    result_low = decide(
        VerdictInputs(claim=claim, evidence=evidence, tier_of=tier_map_low)
    )

    # Confidence with TIER_1
    tier_map_high = dict.fromkeys(sources, TrustTier.TIER_1)
    result_high = decide(
        VerdictInputs(claim=claim, evidence=evidence, tier_of=tier_map_high)
    )

    assert result_high.confidence >= result_low.confidence - 1e-9, (
        f"Higher tier decreased confidence: "
        f"TIER_3={result_low.confidence:.4f}, TIER_1={result_high.confidence:.4f}"
    )


@given(
    claim_strategy,
    st.lists(
        st.builds(
            make_evidence,
            source_did=did_strategy_fn,
            stance=st.sampled_from([Stance.SUPPORTS, Stance.REFUTES]),
            claim_id=st.just(""),
            age_months=st.integers(min_value=0, max_value=120),
        ),
        max_size=10,
    ),
    source_tier_map_strategy,
    st.booleans(),
    st.booleans(),
)
def test_verdict_stability(
    claim: Claim,
    evidence_raw: list[Evidence],
    tier_of: dict[str, TrustTier],
    is_opinion: bool,
    is_creative: bool,
) -> None:
    """Property: running decide on same inputs twice produces identical VerdictRecord.

    The function must be deterministic and idempotent.
    """
    evidence = [
        Evidence(
            claim_id=claim.claim_id,
            source_did=e.source_did,
            source_version=e.source_version,
            stance=e.stance,
            excerpt=e.excerpt,
            url=e.url,
            retrieved_at=e.retrieved_at,
            raw_hash=e.raw_hash,
        )
        for e in evidence_raw
    ]

    inputs = VerdictInputs(
        claim=claim,
        evidence=evidence,
        is_opinion=is_opinion,
        is_creative=is_creative,
        tier_of=tier_of if tier_of else None,
    )

    result1 = decide(inputs)
    result2 = decide(inputs)

    # All fields should match (except verdict_id and evidence_refs order might differ)
    assert result1.claim_id == result2.claim_id
    assert result1.decision == result2.decision
    assert result1.confidence == result2.confidence
    assert result1.rationale == result2.rationale
    assert set(result1.evidence_refs) == set(result2.evidence_refs), (
        f"Evidence refs changed between runs: {result1.evidence_refs} vs {result2.evidence_refs}"
    )


@given(claim_strategy)
def test_empty_evidence_invariant(claim: Claim) -> None:
    """Property: with evidence=[], decide returns UNVERIFIED with confidence < 0.5.

    Empty evidence is the baseline for unknown claims.
    """
    inputs = VerdictInputs(claim=claim, evidence=[])
    result = decide(inputs)

    assert result.decision == Verdict.UNVERIFIED, (
        f"Empty evidence should be UNVERIFIED, got {result.decision}"
    )
    assert result.confidence < 0.5, (
        f"Empty evidence confidence should be < 0.5, got {result.confidence}"
    )


@given(claim_strategy)
def test_creative_overrides_all(claim: Claim) -> None:
    """Property: is_creative=True always returns CREATIVE regardless of evidence.

    Creative flag is a short-circuit that overrides all logic.
    """
    # Even with supporting evidence, creative should override
    evidence = [
        make_evidence("did:web:source1", Stance.SUPPORTS, claim.claim_id),
        make_evidence("did:web:source2", Stance.SUPPORTS, claim.claim_id),
    ]

    inputs = VerdictInputs(
        claim=claim,
        evidence=evidence,
        is_creative=True,
    )

    result = decide(inputs)

    assert result.decision == Verdict.CREATIVE
    assert result.confidence == 0.99


@given(claim_strategy)
def test_opinion_overrides_all(claim: Claim) -> None:
    """Property: is_opinion=True always returns OPINION regardless of evidence.

    Opinion flag is a short-circuit that overrides all logic.
    """
    # Even with refuting evidence, opinion should override
    evidence = [
        make_evidence("did:web:source1", Stance.REFUTES, claim.claim_id),
        make_evidence("did:web:source2", Stance.REFUTES, claim.claim_id),
    ]

    inputs = VerdictInputs(
        claim=claim,
        evidence=evidence,
        is_opinion=True,
    )

    result = decide(inputs)

    assert result.decision == Verdict.OPINION
    assert result.confidence == 0.9


@given(
    claim_strategy,
    st.integers(min_value=2, max_value=5),
    source_tier_map_strategy,
)
def test_two_supports_verified(
    claim: Claim,
    extra_count: int,
    tier_of: dict[str, TrustTier],
) -> None:
    """Property: 2+ independent supports with 0 refutes → VERIFIED.

    This is the core success path of the verdict engine.
    """
    sources = [f"did:web:source{i}" for i in range(2)]
    evidence = [
        make_evidence(s, Stance.SUPPORTS, claim.claim_id)
        for s in sources
    ]

    # Ensure tier_of covers these sources
    tier_map = dict.fromkeys(sources, TrustTier.TIER_1)

    inputs = VerdictInputs(claim=claim, evidence=evidence, tier_of=tier_map)
    result = decide(inputs)

    assert result.decision == Verdict.VERIFIED


@given(
    claim_strategy,
    st.integers(min_value=2, max_value=5),
    source_tier_map_strategy,
)
def test_two_refutes_verified_negated(
    claim: Claim,
    extra_count: int,
    tier_of: dict[str, TrustTier],
) -> None:
    """Property: 2+ independent refutes with 0 supports → VERIFIED (negated).

    Refutation is equally valid as support.
    """
    sources = [f"did:web:source{i}" for i in range(2)]
    evidence = [
        make_evidence(s, Stance.REFUTES, claim.claim_id)
        for s in sources
    ]

    tier_map = dict.fromkeys(sources, TrustTier.TIER_1)

    inputs = VerdictInputs(claim=claim, evidence=evidence, tier_of=tier_map)
    result = decide(inputs)

    assert result.decision == Verdict.VERIFIED


@given(
    claim_strategy,
    st.integers(min_value=1, max_value=3),
    st.integers(min_value=1, max_value=3),
)
def test_mixed_support_refute_contested(
    claim: Claim,
    support_count: int,
    refute_count: int,
) -> None:
    """Property: mixing supports and refutes → CONTESTED (unless one dominates).

    Equal or close evidence counts produce contested verdicts.
    """
    support_sources = [f"did:web:support{i}" for i in range(support_count)]
    refute_sources = [f"did:web:refute{i}" for i in range(refute_count)]

    evidence = (
        [make_evidence(s, Stance.SUPPORTS, claim.claim_id) for s in support_sources]
        + [make_evidence(s, Stance.REFUTES, claim.claim_id) for s in refute_sources]
    )

    inputs = VerdictInputs(claim=claim, evidence=evidence)
    result = decide(inputs)

    # If both >= 1, should be contested
    assert result.decision == Verdict.CONTESTED


@given(claim_strategy)
def test_single_support_unverified(claim: Claim) -> None:
    """Property: single support with 0 refutes → UNVERIFIED.

    Need 2+ independent sources for verification.
    """
    evidence = [make_evidence("did:web:source1", Stance.SUPPORTS, claim.claim_id)]

    inputs = VerdictInputs(claim=claim, evidence=evidence)
    result = decide(inputs)

    assert result.decision == Verdict.UNVERIFIED


@given(claim_strategy)
def test_single_refute_unverified(claim: Claim) -> None:
    """Property: single refute with 0 supports → UNVERIFIED.

    Need 2+ independent sources for verification.
    """
    evidence = [make_evidence("did:web:source1", Stance.REFUTES, claim.claim_id)]

    inputs = VerdictInputs(claim=claim, evidence=evidence)
    result = decide(inputs)

    assert result.decision == Verdict.UNVERIFIED
