"""End-to-end integration test: sign with Sigstore, fetch DID, verify with Rekor + TSA.

This test exercises the full pipeline:
1. Submit a claim via FastAPI (verify_claim)
2. Get back an envelope with real Sigstore signature, Rekor UUID, and dual TSA tokens
3. Write to a temp file
4. Run gtv-verify subprocess with offline verification
5. Assert exit code 0 or 7 (7 if DID doc not published yet)

Gated by GTV_E2E_LIVE=1 for live Sigstore/Rekor, and GTV_E2E_STUB=1 for stub mode.
"""
from __future__ import annotations

import contextlib
import json
import os
import subprocess
import tempfile
from pathlib import Path

import pytest

# Skip entire module unless GTV_E2E_LIVE is set (for live) or GTV_E2E_STUB is set (for stub)
pytestmark = pytest.mark.skipif(
    os.getenv("GTV_E2E_LIVE") != "1" and os.getenv("GTV_E2E_STUB") != "1",
    reason="GTV_E2E_LIVE=1 or GTV_E2E_STUB=1 required",
)


# ============================================================================
# Live E2E Test (real Sigstore staging, real Rekor, real TSA, real DID resolve)
# ============================================================================


@pytest.mark.skipif(
    os.getenv("GTV_E2E_LIVE") != "1",
    reason="GTV_E2E_LIVE=1 required for live test",
)
def test_e2e_live_full_pipeline() -> None:
    """Full end-to-end test: claim -> sign -> verify (live services).

    Requires:
    - GTV_E2E_LIVE=1
    - GTV_SIGSTORE_ENABLED=1
    - GTV_TSA_ENABLED=1
    - GTV_LIVE=1 (for adapters; optional, adapters may be stubbed)

    Workflow:
    1. Submit claim via FastAPI /tools/verify_claim
    2. Verify response has non-stub fields (signature, rekor_uuid, tsa_token)
    3. Write envelope to temp file
    4. Run gtv-verify with --rekor-staging (validate checkpoint against staging Rekor key)
    5. Assert exit code 0 or 7 (7 = issuer DID not published)
    6. If 7, retry with --trust-issuer and assert 0
    """
    # Ensure live flags are set
    if os.getenv("GTV_SIGSTORE_ENABLED") != "1":
        pytest.skip("GTV_SIGSTORE_ENABLED=1 required; skipping")
    if os.getenv("GTV_TSA_ENABLED") != "1":
        pytest.skip("GTV_TSA_ENABLED=1 required; skipping")

    # Import here to ensure environment is set before module load
    from fastapi.testclient import TestClient

    from gtv.mcp.server import app

    client = TestClient(app)

    # Submit a simple claim
    claim_text = "The Moon orbits the Earth."
    response = client.post(
        "/tools/verify_claim",
        json={"claim": claim_text, "domain": "general", "max_sources": 3},
    )

    assert response.status_code == 200, f"verify_claim failed: {response.text}"
    envelope_data = response.json()["envelope"]

    # Validate non-stub fields are present
    signature = envelope_data.get("signature", "")
    rekor_uuid = envelope_data.get("rekor_uuid", "")
    tsa_token = envelope_data.get("tsa_token", "")

    assert signature, "signature is empty"
    assert rekor_uuid, "rekor_uuid is empty"
    assert not rekor_uuid.startswith("stub-"), f"rekor_uuid is stub: {rekor_uuid}"
    assert tsa_token, "tsa_token is empty"
    assert not signature.startswith("stub://"), f"signature is stub: {signature}"

    # Write envelope to temp file
    with tempfile.NamedTemporaryFile(
        mode="w",
        suffix=".json",
        delete=False,
        dir="/tmp/gtv-run",
    ) as f:
        json.dump(envelope_data, f)
        temp_path = f.name

    try:
        # Run gtv-verify with --rekor-staging: validate the inclusion-proof checkpoint
        # against the staging Rekor public key (the envelope was signed against staging,
        # because the release-live-sigstore workflow sets GTV_SIGSTORE_PROD=0).
        gtv_verify_bin = Path("/tmp/gtvenv/bin/python")
        cmd = [
            str(gtv_verify_bin),
            "-m",
            "gtv.cli.verify",
            "--rekor-staging",
            temp_path,
        ]

        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            cwd="/tmp/gtv-run",
        )

        print(f"gtv-verify stdout:\n{result.stdout}")  # noqa: T201
        print(f"gtv-verify stderr:\n{result.stderr}")  # noqa: T201

        # Exit code 0 = fully verified
        # Exit code 7 = issuer DID doc not published yet (acceptable, retry with --trust-issuer)
        if result.returncode == 0:
            print("SUCCESS: Envelope verified (exit 0)")  # noqa: T201
        elif result.returncode == 7:
            print(  # noqa: T201
                "Issuer DID doc not published (exit 7); retrying with --trust-issuer"
            )
            # Retry with --trust-issuer to skip DID resolution
            cmd_trust = [
                str(gtv_verify_bin),
                "-m",
                "gtv.cli.verify",
                "--rekor-staging",
                "--trust-issuer",
                temp_path,
            ]
            result_trust = subprocess.run(
                cmd_trust,
                capture_output=True,
                text=True,
                cwd="/tmp/gtv-run",
            )
            print(f"gtv-verify --trust-issuer stdout:\n{result_trust.stdout}")  # noqa: T201
            print(f"gtv-verify --trust-issuer stderr:\n{result_trust.stderr}")  # noqa: T201
            assert result_trust.returncode == 0, (
                f"gtv-verify --trust-issuer failed with exit {result_trust.returncode}: "
                f"{result_trust.stderr}"
            )
            print("SUCCESS: Envelope verified with --trust-issuer (exit 0)")  # noqa: T201
        else:
            pytest.fail(
                f"gtv-verify failed with exit code {result.returncode}\n"
                f"stdout: {result.stdout}\n"
                f"stderr: {result.stderr}"
            )

    finally:
        # Intentionally DO NOT unlink temp_path: release-live-sigstore.yml
        # uploads /tmp/gtv-run/*.json as a workflow artifact after this job,
        # and we want the envelope preserved on both success (gate-a evidence)
        # and failure (triage payload). See #46.
        pass


# ============================================================================
# Stub E2E Test (all stubs, no external services)
# ============================================================================


@pytest.mark.skipif(
    os.getenv("GTV_E2E_STUB") != "1",
    reason="GTV_E2E_STUB=1 required for stub test",
)
def test_e2e_stub_full_pipeline() -> None:
    """Full end-to-end test with all stubs (no external services).

    Requires:
    - GTV_E2E_STUB=1
    - GTV_SIGSTORE_ENABLED must NOT be set (or =0)
    - GTV_TSA_ENABLED must NOT be set (or =0)
    - GTV_LIVE must NOT be set (or =0) so adapters are stubbed

    Workflow:
    1. Clear live-service env vars to force stub mode
    2. Submit claim via FastAPI
    3. Verify response has STUB fields (signature starts with stub://, etc.)
    4. Write envelope to temp file
    5. Run gtv-verify with --allow-stub
    6. Assert exit code 0 or 2 (0 if --allow-stub; 2 if stubs detected)
    7. This proves the full pipeline works end-to-end in stub mode
    """
    # Force stub mode by unsetting live flags
    saved_env = {}
    for key in ["GTV_SIGSTORE_ENABLED", "GTV_TSA_ENABLED", "GTV_LIVE"]:
        saved_env[key] = os.environ.pop(key, None)

    try:
        # Import here to ensure environment is clean
        from fastapi.testclient import TestClient

        from gtv.mcp.server import app

        client = TestClient(app)

        # Submit a simple claim
        claim_text = "Stub test claim: the sky is blue."
        response = client.post(
            "/tools/verify_claim",
            json={"claim": claim_text, "domain": "general", "max_sources": 3},
        )

        assert response.status_code == 200, f"verify_claim failed: {response.text}"
        envelope_data = response.json()["envelope"]

        # Validate STUB fields are present
        signature = envelope_data.get("signature", "")
        rekor_uuid = envelope_data.get("rekor_uuid", "")
        tsa_token = envelope_data.get("tsa_token", "")

        assert signature.startswith("stub://"), f"signature is not stub: {signature}"
        assert rekor_uuid.startswith("stub-"), f"rekor_uuid is not stub: {rekor_uuid}"
        # TSA token is base64-encoded stub, not a stub:// URL
        assert tsa_token, "tsa_token is empty"

        # Verify inclusion proof is also stub
        anchor_proof = envelope_data.get("anchor_proof", {})
        rekor_proof = anchor_proof.get("rekor_inclusion_proof", "")
        assert rekor_proof.startswith(
            "stub://"
        ), f"rekor_inclusion_proof is not stub: {rekor_proof}"

        # Write envelope to temp file
        with tempfile.NamedTemporaryFile(
            mode="w",
            suffix=".json",
            delete=False,
            dir="/tmp/gtv-run",
        ) as f:
            json.dump(envelope_data, f)
            temp_path = f.name

        try:
            # Run gtv-verify with --allow-stub (allow stub signatures to pass)
            gtv_verify_bin = Path("/tmp/gtvenv/bin/python")
            cmd = [
                str(gtv_verify_bin),
                "-m",
                "gtv.cli.verify",
                "--allow-stub",
                temp_path,
            ]

            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                cwd="/tmp/gtv-run",
            )

            print(f"gtv-verify --allow-stub stdout:\n{result.stdout}")  # noqa: T201
            print(f"gtv-verify --allow-stub stderr:\n{result.stderr}")  # noqa: T201

            # With --allow-stub, we expect exit 0 (stubs accepted)
            # Exit 2 without --allow-stub means stub detected (is a regression)
            # Exit 0 with --allow-stub means stub accepted
            assert result.returncode == 0, (
                f"gtv-verify --allow-stub failed with exit {result.returncode}\n"
                f"stdout: {result.stdout}\n"
                f"stderr: {result.stderr}"
            )
            print("SUCCESS: Stub pipeline verified with --allow-stub (exit 0)")  # noqa: T201

            # Verify that without --allow-stub, we get exit 2 (stub detected)
            cmd_no_stub = [
                str(gtv_verify_bin),
                "-m",
                "gtv.cli.verify",
                temp_path,  # NOT --allow-stub
            ]
            result_no_stub = subprocess.run(
                cmd_no_stub,
                capture_output=True,
                text=True,
                cwd="/tmp/gtv-run",
            )
            print(f"gtv-verify (no --allow-stub) stdout:\n{result_no_stub.stdout}")  # noqa: T201
            assert result_no_stub.returncode == 2, (
                f"Expected exit 2 (stub detected) without --allow-stub, got {result_no_stub.returncode}"
            )
            print("SUCCESS: Stubs correctly rejected without --allow-stub (exit 2)")  # noqa: T201

        finally:
            # Clean up temp file
            with contextlib.suppress(OSError):
                Path(temp_path).unlink()

    finally:
        # Restore environment
        for key, val in saved_env.items():
            if val is not None:
                os.environ[key] = val
