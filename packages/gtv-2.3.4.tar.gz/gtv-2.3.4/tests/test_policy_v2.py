"""Tests for the v2 consensus policy primitives (W39).

Covers the three new levers added to the policy DSL:
 1. ``max_evidence_age_days`` — stale evidence is filtered before counting.
 2. ``require_recent_support_days`` — verdict needs ≥1 recent support.
 3. ``min_distinct_tiers_for_verified`` — supports must span ≥ N tiers.

Each test demonstrates an input that v1 would have VERIFIED but v2
rejects (or vice versa). A v1 policy (all v2 fields None) must still
reproduce v1 behavior byte-for-byte.
"""
from __future__ import annotations

from datetime import UTC, datetime, timedelta
from pathlib import Path

import pytest
from pydantic import HttpUrl

from gtv.models import (
    Claim,
    Domain,
    Evidence,
    Stance,
    TrustTier,
    Verdict,
)
from gtv.policy import (
    DEFAULT_POLICY,
    DomainPolicy,
    Policy,
    PolicyError,
    load_policy,
)
from gtv.verdict.engine import VerdictInputs, decide


def _ev(
    source_did: str,
    stance: Stance = Stance.SUPPORTS,
    days_ago: int = 0,
) -> Evidence:
    return Evidence(
        claim_id="c",
        source_did=source_did,
        source_version="v1",
        stance=stance,
        excerpt="e",
        url=HttpUrl("https://x.example/e"),
        retrieved_at=datetime.now(tz=UTC) - timedelta(days=days_ago),
        raw_hash="0" * 64,
    )


def _claim(domain: Domain = Domain.PHYSICS) -> Claim:
    return Claim(text="The sky is blue", domain=domain)


# ---------------------------------------------------------------------
# v1 regression guard
# ---------------------------------------------------------------------


def test_default_policy_exposes_no_v2_fields() -> None:
    """The default policy must leave every v2 knob unset, otherwise
    shipped deployments silently change behaviour on upgrade."""
    r = DEFAULT_POLICY.for_domain(Domain.PHYSICS)
    assert r.max_evidence_age_days is None
    assert r.require_recent_support_days is None
    assert r.min_distinct_tiers_for_verified is None


# ---------------------------------------------------------------------
# max_evidence_age_days — drop stale evidence before counting
# ---------------------------------------------------------------------


def test_stale_evidence_is_filtered_and_blocks_verified() -> None:
    """Two supports, but both are 400 days old. With
    max_evidence_age_days=90 the engine sees zero evidence and
    returns UNVERIFIED with an explicit 'all stale' rationale."""
    policy = Policy(max_evidence_age_days=90)
    inputs = VerdictInputs(
        claim=_claim(),
        evidence=[
            _ev("did:web:a", days_ago=400),
            _ev("did:web:b", days_ago=400),
        ],
        tier_of={
            "did:web:a": TrustTier.TIER_1,
            "did:web:b": TrustTier.TIER_1,
        },
    )
    r = decide(inputs, policy)
    assert r.decision == Verdict.UNVERIFIED
    assert "older than" in r.rationale


def test_fresh_evidence_still_verifies_under_age_cap() -> None:
    policy = Policy(max_evidence_age_days=90)
    inputs = VerdictInputs(
        claim=_claim(),
        evidence=[
            _ev("did:web:a", days_ago=5),
            _ev("did:web:b", days_ago=5),
        ],
        tier_of={
            "did:web:a": TrustTier.TIER_1,
            "did:web:b": TrustTier.TIER_1,
        },
    )
    r = decide(inputs, policy)
    assert r.decision == Verdict.VERIFIED


def test_mixed_age_counts_only_fresh() -> None:
    """Three supports total; two are stale, one is fresh. With
    min_supports=2 this should fail — the fresh one counts, the
    stale ones do not."""
    policy = Policy(
        min_supports_for_verified=2,
        max_evidence_age_days=30,
    )
    inputs = VerdictInputs(
        claim=_claim(),
        evidence=[
            _ev("did:web:a", days_ago=2),      # fresh
            _ev("did:web:b", days_ago=90),     # stale
            _ev("did:web:c", days_ago=200),    # stale
        ],
    )
    r = decide(inputs, policy)
    assert r.decision == Verdict.UNVERIFIED


# ---------------------------------------------------------------------
# require_recent_support_days — at least one must be recent
# ---------------------------------------------------------------------


def test_require_recent_support_rejects_all_historical() -> None:
    """Two supports, meet min_supports=2, but both are 60 days old
    and policy requires one within 14 days."""
    policy = Policy(require_recent_support_days=14)
    inputs = VerdictInputs(
        claim=_claim(),
        evidence=[
            _ev("did:web:a", days_ago=60),
            _ev("did:web:b", days_ago=60),
        ],
        tier_of={
            "did:web:a": TrustTier.TIER_1,
            "did:web:b": TrustTier.TIER_1,
        },
    )
    r = decide(inputs, policy)
    assert r.decision == Verdict.UNVERIFIED
    assert "recent" in r.rationale.lower()


def test_require_recent_support_accepts_if_one_is_recent() -> None:
    policy = Policy(require_recent_support_days=14)
    inputs = VerdictInputs(
        claim=_claim(),
        evidence=[
            _ev("did:web:a", days_ago=60),
            _ev("did:web:b", days_ago=3),  # recent
        ],
        tier_of={
            "did:web:a": TrustTier.TIER_1,
            "did:web:b": TrustTier.TIER_1,
        },
    )
    r = decide(inputs, policy)
    assert r.decision == Verdict.VERIFIED


# ---------------------------------------------------------------------
# min_distinct_tiers_for_verified — cross-tier diversity
# ---------------------------------------------------------------------


def test_min_distinct_tiers_rejects_single_tier_monoculture() -> None:
    """Three TIER_3 blogs all agree. Policy requires two tiers —
    this must NOT flip to VERIFIED."""
    policy = Policy(min_distinct_tiers_for_verified=2)
    inputs = VerdictInputs(
        claim=_claim(),
        evidence=[
            _ev("did:web:a"),
            _ev("did:web:b"),
            _ev("did:web:c"),
        ],
        tier_of={
            "did:web:a": TrustTier.TIER_3,
            "did:web:b": TrustTier.TIER_3,
            "did:web:c": TrustTier.TIER_3,
        },
    )
    r = decide(inputs, policy)
    assert r.decision == Verdict.UNVERIFIED
    assert "tier" in r.rationale.lower()


def test_min_distinct_tiers_accepts_mixed_tiers() -> None:
    policy = Policy(min_distinct_tiers_for_verified=2)
    inputs = VerdictInputs(
        claim=_claim(),
        evidence=[_ev("did:web:a"), _ev("did:web:b")],
        tier_of={
            "did:web:a": TrustTier.TIER_1,
            "did:web:b": TrustTier.TIER_3,
        },
    )
    r = decide(inputs, policy)
    assert r.decision == Verdict.VERIFIED


def test_distinct_tiers_missing_mapping_defaults_to_tier_3() -> None:
    """If an operator forgets to map a source, the engine treats it
    as TIER_3. That means two unmapped sources look like a
    single-tier monoculture."""
    policy = Policy(min_distinct_tiers_for_verified=2)
    inputs = VerdictInputs(
        claim=_claim(),
        evidence=[_ev("did:web:a"), _ev("did:web:b")],
        tier_of={},  # neither source classified
    )
    r = decide(inputs, policy)
    assert r.decision == Verdict.UNVERIFIED


# ---------------------------------------------------------------------
# Per-domain overrides for v2 fields
# ---------------------------------------------------------------------


def test_v2_fields_resolve_per_domain() -> None:
    policy = Policy(
        max_evidence_age_days=365,
        domains={
            "math": DomainPolicy(max_evidence_age_days=30),
        },
    )
    mth = policy.for_domain(Domain.MATH)
    phys = policy.for_domain(Domain.PHYSICS)
    assert mth.max_evidence_age_days == 30
    assert phys.max_evidence_age_days == 365


def test_v2_per_domain_override_filters_aggressively() -> None:
    """Physics leaves it unset (inherits 365d global cap). Math drops
    it to 30. A 60-day-old math claim must fail; same evidence under
    physics verifies."""
    policy = Policy(
        max_evidence_age_days=365,
        domains={"math": DomainPolicy(max_evidence_age_days=30)},
    )
    ev = [_ev("did:web:a", days_ago=60), _ev("did:web:b", days_ago=60)]
    tiers = {
        "did:web:a": TrustTier.TIER_1,
        "did:web:b": TrustTier.TIER_1,
    }

    math_r = decide(
        VerdictInputs(claim=_claim(Domain.MATH), evidence=ev, tier_of=tiers),
        policy,
    )
    phys_r = decide(
        VerdictInputs(claim=_claim(Domain.PHYSICS), evidence=ev, tier_of=tiers),
        policy,
    )
    assert math_r.decision == Verdict.UNVERIFIED
    assert phys_r.decision == Verdict.VERIFIED


# ---------------------------------------------------------------------
# YAML loading of v2 fields
# ---------------------------------------------------------------------


def test_load_policy_accepts_v2_fields(tmp_path: Path) -> None:
    p = tmp_path / "policy.yaml"
    p.write_text(
        """\
max_evidence_age_days: 90
require_recent_support_days: 14
min_distinct_tiers_for_verified: 2
domains:
  math:
    max_evidence_age_days: 30
    require_recent_support_days: 7
""",
        encoding="utf-8",
    )
    policy = load_policy(p)
    assert policy.max_evidence_age_days == 90
    assert policy.require_recent_support_days == 14
    assert policy.min_distinct_tiers_for_verified == 2

    mth = policy.for_domain(Domain.MATH)
    assert mth.max_evidence_age_days == 30
    assert mth.require_recent_support_days == 7
    # Unset in the override — inherits global.
    assert mth.min_distinct_tiers_for_verified == 2


def test_load_policy_rejects_zero_v2_values(tmp_path: Path) -> None:
    p = tmp_path / "policy.yaml"
    p.write_text("max_evidence_age_days: 0\n", encoding="utf-8")
    with pytest.raises(PolicyError):
        load_policy(p)


def test_load_policy_rejects_too_many_tiers(tmp_path: Path) -> None:
    """Only three TrustTiers exist; anything above 3 is nonsense."""
    p = tmp_path / "policy.yaml"
    p.write_text("min_distinct_tiers_for_verified: 4\n", encoding="utf-8")
    with pytest.raises(PolicyError):
        load_policy(p)
