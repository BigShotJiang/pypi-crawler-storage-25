"""Tests for ``gtv.billing.store`` — SQLite daily usage aggregator.

Covers the pure storage layer plus the ``record_usage`` convenience
hook. Server integration (record_usage fires from verify_claim, etc.)
lives in ``test_billing_integration.py``.
"""

from __future__ import annotations

from datetime import UTC, date, datetime

import pytest

from gtv.billing import (
    UsageRow,
    UsageStore,
    make_store_from_env,
    record_usage,
    reset_default_store,
)

# ---------------------------------------------------------------------------
# Store unit tests
# ---------------------------------------------------------------------------


@pytest.fixture
def store() -> UsageStore:
    return UsageStore(":memory:")


def test_record_creates_row(store: UsageStore) -> None:
    store.record(tenant_id="acme", issuer_did="did:web:a", tool="verify")
    rows = store.query()
    assert len(rows) == 1
    assert rows[0].tenant_id == "acme"
    assert rows[0].issuer_did == "did:web:a"
    assert rows[0].tool == "verify"
    assert rows[0].count == 1


def test_record_upserts_on_duplicate_day(store: UsageStore) -> None:
    """Second call for the same (tenant, issuer, tool, day) bumps count."""
    when = datetime(2026, 4, 21, 12, 0, tzinfo=UTC)
    store.record(tenant_id="acme", issuer_did="did:web:a", tool="verify", when=when)
    store.record(tenant_id="acme", issuer_did="did:web:a", tool="verify", when=when)
    store.record(tenant_id="acme", issuer_did="did:web:a", tool="verify", when=when)
    rows = store.query()
    assert len(rows) == 1
    assert rows[0].count == 3


def test_record_different_days_creates_separate_rows(store: UsageStore) -> None:
    d1 = datetime(2026, 4, 20, 12, 0, tzinfo=UTC)
    d2 = datetime(2026, 4, 21, 12, 0, tzinfo=UTC)
    store.record(tenant_id="acme", issuer_did="did:web:a", tool="verify", when=d1)
    store.record(tenant_id="acme", issuer_did="did:web:a", tool="verify", when=d2)
    rows = store.query(tenant_id="acme")
    assert len(rows) == 2
    # Ordered most recent first
    assert rows[0].day == "2026-04-21"
    assert rows[1].day == "2026-04-20"


def test_record_converts_local_time_to_utc(store: UsageStore) -> None:
    """A non-UTC ``when`` is normalised to its UTC calendar day."""
    from datetime import timedelta, timezone

    # 23:30 in UTC-08:00 → 07:30 next day in UTC
    tz = timezone(timedelta(hours=-8))
    local = datetime(2026, 4, 20, 23, 30, tzinfo=tz)
    store.record(tenant_id="acme", issuer_did="did:web:a", tool="verify", when=local)
    rows = store.query()
    assert rows[0].day == "2026-04-21"


def test_record_zero_count_is_noop(store: UsageStore) -> None:
    store.record(tenant_id="acme", issuer_did="did:web:a", tool="verify", count=0)
    store.record(tenant_id="acme", issuer_did="did:web:a", tool="verify", count=-5)
    assert store.query() == []


def test_record_count_argument_increments_by_n(store: UsageStore) -> None:
    store.record(tenant_id="acme", issuer_did="did:web:a", tool="verify", count=7)
    rows = store.query()
    assert rows[0].count == 7


def test_query_filters_compose_with_and(store: UsageStore) -> None:
    d = datetime(2026, 4, 21, 12, 0, tzinfo=UTC)
    store.record(tenant_id="acme", issuer_did="did:web:a", tool="verify", when=d)
    store.record(tenant_id="acme", issuer_did="did:web:a", tool="retrieve", when=d)
    store.record(tenant_id="globex", issuer_did="did:web:b", tool="verify", when=d)

    assert len(store.query(tenant_id="acme")) == 2
    assert len(store.query(tool="verify")) == 2
    assert len(store.query(tenant_id="acme", tool="verify")) == 1
    assert len(store.query(issuer_did="did:web:b")) == 1
    assert store.query(tenant_id="acme", tool="verify")[0].tenant_id == "acme"


def test_query_since_until_inclusive(store: UsageStore) -> None:
    for d in (datetime(2026, 4, 19, tzinfo=UTC),
              datetime(2026, 4, 20, tzinfo=UTC),
              datetime(2026, 4, 21, tzinfo=UTC)):
        store.record(tenant_id="acme", issuer_did="did:web:a", tool="verify", when=d)

    rows = store.query(since=date(2026, 4, 20), until=date(2026, 4, 21))
    days = {r.day for r in rows}
    assert days == {"2026-04-20", "2026-04-21"}

    rows = store.query(since=date(2026, 4, 21))
    assert [r.day for r in rows] == ["2026-04-21"]


def test_query_ordering_is_deterministic(store: UsageStore) -> None:
    """Most recent day first, then tenant ASC, then tool ASC."""
    d1 = datetime(2026, 4, 20, tzinfo=UTC)
    d2 = datetime(2026, 4, 21, tzinfo=UTC)
    # Insert in mixed order to prove the sort
    store.record(tenant_id="zeta", issuer_did="did:x", tool="verify", when=d2)
    store.record(tenant_id="alpha", issuer_did="did:x", tool="retrieve", when=d1)
    store.record(tenant_id="alpha", issuer_did="did:x", tool="verify", when=d2)
    store.record(tenant_id="alpha", issuer_did="did:x", tool="retrieve", when=d2)

    rows = store.query()
    keys = [(r.day, r.tenant_id, r.tool) for r in rows]
    assert keys == [
        ("2026-04-21", "alpha", "retrieve"),
        ("2026-04-21", "alpha", "verify"),
        ("2026-04-21", "zeta", "verify"),
        ("2026-04-20", "alpha", "retrieve"),
    ]


def test_totals_by_tenant(store: UsageStore) -> None:
    d = datetime(2026, 4, 21, tzinfo=UTC)
    store.record(tenant_id="acme", issuer_did="did:a", tool="verify", when=d, count=3)
    store.record(tenant_id="acme", issuer_did="did:a", tool="retrieve", when=d, count=2)
    store.record(tenant_id="globex", issuer_did="did:b", tool="verify", when=d, count=7)
    store.record(tenant_id="initech", issuer_did="did:c", tool="verify", when=d, count=1)

    totals = store.totals_by_tenant()
    assert totals == {"globex": 7, "acme": 5, "initech": 1}
    # Check descending by total
    assert list(totals.keys()) == ["globex", "acme", "initech"]


def test_totals_by_tenant_respects_window(store: UsageStore) -> None:
    d1 = datetime(2026, 4, 19, tzinfo=UTC)
    d2 = datetime(2026, 4, 21, tzinfo=UTC)
    store.record(tenant_id="acme", issuer_did="did:a", tool="verify", when=d1, count=10)
    store.record(tenant_id="acme", issuer_did="did:a", tool="verify", when=d2, count=3)

    totals = store.totals_by_tenant(since=date(2026, 4, 20))
    assert totals == {"acme": 3}


def test_usagerow_is_immutable() -> None:
    r = UsageRow(tenant_id="t", issuer_did="d", tool="v", day="2026-04-21", count=1)
    with pytest.raises(AttributeError):
        r.count = 2  # type: ignore[misc]


# ---------------------------------------------------------------------------
# Process-default store + record_usage hook
# ---------------------------------------------------------------------------


@pytest.fixture
def reset_default():
    """Ensure the process-default store is clean around each test."""
    reset_default_store()
    yield
    reset_default_store()


def test_make_store_from_env_defaults_to_memory(
    monkeypatch: pytest.MonkeyPatch, reset_default: None
) -> None:
    monkeypatch.delenv("GTV_BILLING_DB", raising=False)
    store = make_store_from_env()
    assert store.db_path == ":memory:"


def test_make_store_from_env_honours_env_var(
    tmp_path, monkeypatch: pytest.MonkeyPatch, reset_default: None
) -> None:
    db = tmp_path / "usage.sqlite"
    monkeypatch.setenv("GTV_BILLING_DB", str(db))
    store = make_store_from_env()
    assert store.db_path == str(db)


def test_make_store_from_env_is_cached(
    monkeypatch: pytest.MonkeyPatch, reset_default: None
) -> None:
    monkeypatch.delenv("GTV_BILLING_DB", raising=False)
    a = make_store_from_env()
    b = make_store_from_env()
    assert a is b


def test_record_usage_writes_via_default_store(
    monkeypatch: pytest.MonkeyPatch, reset_default: None
) -> None:
    monkeypatch.delenv("GTV_BILLING_DB", raising=False)
    record_usage(tenant_id="acme", issuer_did="did:x", tool="verify")
    record_usage(tenant_id="acme", issuer_did="did:x", tool="verify")
    rows = make_store_from_env().query()
    assert len(rows) == 1
    assert rows[0].count == 2


def test_record_usage_swallows_exceptions(
    monkeypatch: pytest.MonkeyPatch, reset_default: None, caplog
) -> None:
    """Billing failures MUST NOT break the request handler."""
    import gtv.billing.store as mod

    def _boom(**_kw) -> mod.UsageStore:
        raise RuntimeError("db gone")

    monkeypatch.setattr(mod, "make_store_from_env", _boom)
    # Must not raise
    record_usage(tenant_id="acme", issuer_did="did:x", tool="verify")
    assert any("record_usage failed" in r.message for r in caplog.records)
