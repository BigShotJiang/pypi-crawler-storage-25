"""Tests for TSA certificate bundles.

Verifies that real TSA certificates are present, non-expired, and valid.
"""
from __future__ import annotations

from datetime import UTC, datetime

import pytest

from gtv.anchor.tsa_certs import load_chain


class TestTSACerts:
    """Verify TSA certificate chains are valid and non-expired."""

    @pytest.mark.parametrize("name", ["freetsa", "digicert"])
    def test_load_chain(self, name: str) -> None:
        """Test that certificate chains can be loaded and parsed."""
        certs = load_chain(name)
        assert certs, f"No certificates loaded for {name}"
        assert len(certs) > 0

    @pytest.mark.parametrize("name", ["freetsa", "digicert"])
    def test_certs_not_expired(self, name: str) -> None:
        """Test that at least one certificate in each chain is not expired."""
        certs = load_chain(name)
        now = datetime.now(UTC)

        # At least one cert in the chain should not be expired
        valid_certs = [
            cert for cert in certs
            if cert.not_valid_before_utc <= now <= cert.not_valid_after_utc
        ]
        assert valid_certs, (
            f"No non-expired certificates found in {name} chain. "
            f"Certs valid: {[(c.not_valid_before_utc, c.not_valid_after_utc) for c in certs]}"
        )

    def test_freetsa_chain_issuer(self) -> None:
        """Test FreeTSA certificate chain has expected issuer."""
        certs = load_chain("freetsa")
        # Should have at least 2 certs: TSA cert + root CA
        assert len(certs) >= 1

        # Check that at least one cert mentions FreeTSA
        found_freetsa = False
        for cert in certs:
            subject_str = cert.subject.rfc4514_string()
            if "Free TSA" in subject_str or "freetsa" in subject_str.lower():
                found_freetsa = True
                break

        assert found_freetsa, f"No FreeTSA certificate found. Subjects: {[c.subject.rfc4514_string() for c in certs]}"

    def test_digicert_chain_issuer(self) -> None:
        """Test DigiCert certificate chain has expected issuer."""
        certs = load_chain("digicert")
        # Should have at least 2 certs: TSA intermediate + root
        assert len(certs) >= 1

        # Check that at least one cert mentions DigiCert
        found_digicert = False
        for cert in certs:
            subject_str = cert.subject.rfc4514_string()
            issuer_str = cert.issuer.rfc4514_string()
            if "DigiCert" in subject_str or "DigiCert" in issuer_str:
                found_digicert = True
                break

        assert found_digicert, f"No DigiCert certificate found. Subjects: {[c.subject.rfc4514_string() for c in certs]}"
