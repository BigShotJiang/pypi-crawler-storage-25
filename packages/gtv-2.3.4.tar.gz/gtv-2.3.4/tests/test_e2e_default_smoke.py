"""Default-CI end-to-end smoke.

Runs on every `pytest -q` (no env-var gate). Validates that the MCP HTTP
surface produces a well-formed stub envelope that round-trips through
canonical-hash validation. This is the credibility gate: if default CI is
green, the happy-path pipeline works end-to-end.

Does NOT touch Sigstore, Rekor, TSA, or any external service. The live
counterpart lives in tests/test_e2e_integration.py (GTV_E2E_LIVE=1).
"""
from __future__ import annotations

import hashlib
import os

import pytest
from fastapi.testclient import TestClient

from gtv.anchor.canonicalize import envelope_canonical_sha256
from gtv.models import Envelope


@pytest.fixture
def client(monkeypatch: pytest.MonkeyPatch) -> TestClient:
    """Force stub mode so no external services are hit."""
    for var in ("GTV_SIGSTORE_ENABLED", "GTV_TSA_ENABLED", "GTV_LIVE"):
        monkeypatch.delenv(var, raising=False)
    # Rebuild the app module to pick up the clean env
    import importlib

    import gtv.mcp.server as server_mod
    importlib.reload(server_mod)
    return TestClient(server_mod.app)


def test_health_probe_responds(client: TestClient) -> None:
    """/health must return 200 without any auth."""
    resp = client.get("/health")
    assert resp.status_code == 200
    assert resp.json().get("status") in ("ok", "healthy")


def test_verify_claim_round_trip(client: TestClient) -> None:
    """verify_claim produces a well-formed envelope that validates + canonicalizes."""
    resp = client.post(
        "/tools/verify_claim",
        json={
            "claim": "The speed of light in vacuum is 299,792,458 m/s.",
            "domain": "physics",
            "max_sources": 3,
        },
    )
    assert resp.status_code == 200, resp.text

    body = resp.json()
    assert "envelope" in body
    env_data = body["envelope"]

    # Full Pydantic validation — catches schema drift
    envelope = Envelope.model_validate(env_data)

    # Every required anchor field is populated (even if stubbed)
    assert envelope.signature, "signature missing"
    assert envelope.rekor_uuid, "rekor_uuid missing"
    assert envelope.tsa_token, "tsa_token missing"
    assert envelope.issuer_did, "issuer_did missing"
    assert envelope.anchor_proof is not None
    assert envelope.anchor_proof.rekor_inclusion_proof, "rekor inclusion proof missing"

    # Canonical hash is deterministic and well-formed
    h = envelope_canonical_sha256(envelope)
    assert len(h) == 64
    int(h, 16)  # raises if not hex


def test_canonical_hash_stable(client: TestClient) -> None:
    """Same envelope → same canonical hash across repeated canonicalizations."""
    resp = client.post(
        "/tools/verify_claim",
        json={"claim": "Water freezes at 0°C.", "domain": "materials", "max_sources": 2},
    )
    envelope = Envelope.model_validate(resp.json()["envelope"])

    h1 = envelope_canonical_sha256(envelope)
    h2 = envelope_canonical_sha256(envelope)
    h3 = hashlib.sha256(
        envelope.model_dump_json(by_alias=True).encode()
    ).hexdigest()
    assert h1 == h2
    # h3 is NOT the canonical hash (different serializer), but it must still be 64 hex.
    assert len(h3) == 64


def test_consensus_happy_path(client: TestClient) -> None:
    """Two stub envelopes aggregate into a signed AggregateEnvelope."""
    # Build the envelopes by verify_claim, then POST them to /consensus.
    env1 = client.post(
        "/tools/verify_claim",
        json={"claim": "Pi is irrational.", "domain": "math", "max_sources": 2},
    ).json()["envelope"]
    env2 = client.post(
        "/tools/verify_claim",
        json={"claim": "Pi is irrational.", "domain": "math", "max_sources": 2},
    ).json()["envelope"]

    # Override issuer DIDs so the aggregator doesn't reject them as duplicates.
    env2["issuer_did"] = "did:test:consensus-peer"

    r = client.post("/consensus", json={"envelopes": [env1, env2]})
    assert r.status_code == 200, r.text
    agg = r.json().get("aggregate")
    assert agg is not None
    assert len(agg["input_refs"]) == 2
    assert len(agg["aggregate_canonical_hash"]) == 64


def test_metrics_endpoint_scrapeable(client: TestClient) -> None:
    """/metrics returns Prometheus text format — required for any deploy target."""
    # Warm the counters by hitting /health a few times.
    for _ in range(3):
        client.get("/health")
    resp = client.get("/metrics")
    assert resp.status_code == 200
    body = resp.text
    # Prometheus exposition format markers
    assert "# HELP" in body
    assert "# TYPE" in body


def test_no_live_env_vars_leaked() -> None:
    """Guard: live env vars must not be set by the test harness itself.

    If CI accidentally exports GTV_SIGSTORE_ENABLED=1 or similar outside the
    nightly job, the default smoke suite would silently try to hit live
    services. This test fails loudly so the misconfig is caught.
    """
    for var in ("GTV_SIGSTORE_ENABLED", "GTV_TSA_ENABLED", "GTV_E2E_LIVE"):
        val = os.environ.get(var, "")
        assert val in ("", "0"), (
            f"{var}={val!r} is set in the default-CI environment; "
            "live env vars must only be set in the nightly workflow."
        )
