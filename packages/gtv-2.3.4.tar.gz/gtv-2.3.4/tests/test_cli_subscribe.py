"""Tests for gtv-subscribe CLI: add/list/remove against SQLite store."""
from __future__ import annotations

from pathlib import Path

import pytest

from gtv.cli.subscribe import cmd_add, cmd_list, cmd_remove
from gtv.subscribe import Subscription
from gtv.subscribe.store import SubscriptionStore


@pytest.fixture
def tmp_db(tmp_path: Path) -> Path:
    """Return a temp DB path."""
    return tmp_path / "subscriptions.db"


def test_cmd_add(tmp_db: Path, capsys) -> None:
    """Test cmd_add writes to SQLite."""
    cmd_add("The sky is blue", "https://example.com/webhook", interval_s=600, db_path=tmp_db)

    captured = capsys.readouterr()
    assert "Added subscription" in captured.out

    # Load and verify
    store = SubscriptionStore(tmp_db)
    subs = store.list_all()
    store.close()

    assert len(subs) == 1
    sub = subs[0]
    assert sub.claim == "The sky is blue"
    assert sub.webhook_url == "https://example.com/webhook"
    assert sub.interval_s == 600


def test_cmd_list_empty(tmp_db: Path, capsys) -> None:
    """Test cmd_list with no subscriptions."""
    cmd_list(db_path=tmp_db)
    captured = capsys.readouterr()
    assert "No subscriptions" in captured.out


def test_cmd_list_with_subs(tmp_db: Path, capsys) -> None:
    """Test cmd_list displays subscriptions."""
    store = SubscriptionStore(tmp_db)
    sub = Subscription(id="id1", claim="The sky is blue", webhook_url="url1", interval_s=600)
    store.add(sub)
    store.close()

    cmd_list(db_path=tmp_db)
    captured = capsys.readouterr()
    assert "id1" in captured.out
    assert "The sky is blue" in captured.out
    assert "pending" in captured.out
    assert "600s" in captured.out


def test_cmd_list_with_verdict(tmp_db: Path, capsys) -> None:
    """Test cmd_list displays verdict."""
    store = SubscriptionStore(tmp_db)
    sub = Subscription(
        id="id1",
        claim="The sky is blue",
        webhook_url="url1",
        interval_s=600,
        last_verdict="VERIFIED",
    )
    store.add(sub)
    store.close()

    cmd_list(db_path=tmp_db)
    captured = capsys.readouterr()
    assert "VERIFIED" in captured.out


def test_cmd_remove(tmp_db: Path, capsys) -> None:
    """Test cmd_remove deletes subscription."""
    store = SubscriptionStore(tmp_db)
    sub = Subscription(id="id1", claim="claim", webhook_url="url", interval_s=600)
    store.add(sub)
    store.close()

    cmd_remove("id1", db_path=tmp_db)
    captured = capsys.readouterr()
    assert "Removed subscription id1" in captured.out

    # Verify deleted
    store2 = SubscriptionStore(tmp_db)
    subs = store2.list_all()
    store2.close()
    assert len(subs) == 0


def test_cmd_remove_nonexistent(tmp_db: Path, capsys) -> None:
    """Test cmd_remove with nonexistent id."""
    with pytest.raises(SystemExit):
        cmd_remove("nonexistent", db_path=tmp_db)
    captured = capsys.readouterr()
    assert "not found" in captured.out
