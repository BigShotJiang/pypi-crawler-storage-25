"""Tests for multi-region replica routing and residency enforcement."""
from __future__ import annotations

import os
import re

import pytest

from gtv.region import (
    RegionalEndpoint,
    RegionConfig,
    is_residency_compliant,
    load_region_config_from_env,
    rank_endpoints,
)


class TestRankEndpoints:
    """Tests for endpoint ranking logic."""

    def test_empty_input_returns_empty(self) -> None:
        """Empty endpoint list should return empty list."""
        cfg = RegionConfig(
            local_region="us-east-1",
            allowed_regions=frozenset(["us-east-1", "eu-west-1"]),
            preferred_regions=["eu-west-1"],
        )
        result = rank_endpoints([], cfg)
        assert result == []

    def test_local_region_endpoint_sorts_first(self) -> None:
        """Local-region endpoints should rank before all others."""
        cfg = RegionConfig(
            local_region="us-east-1",
            allowed_regions=frozenset(["us-east-1", "eu-west-1", "ap-southeast-1"]),
            preferred_regions=["eu-west-1", "ap-southeast-1"],
        )
        endpoints = [
            RegionalEndpoint(url="http://eu.example.com", region="eu-west-1", priority=0),
            RegionalEndpoint(url="http://local.example.com", region="us-east-1", priority=0),
            RegionalEndpoint(url="http://ap.example.com", region="ap-southeast-1", priority=0),
        ]
        result = rank_endpoints(endpoints, cfg)
        assert result[0].region == "us-east-1"

    def test_endpoint_outside_allowed_regions_is_dropped(self) -> None:
        """Endpoints outside allowed_regions must be dropped entirely."""
        cfg = RegionConfig(
            local_region="us-east-1",
            allowed_regions=frozenset(["us-east-1", "eu-west-1"]),
            preferred_regions=[],
        )
        endpoints = [
            RegionalEndpoint(url="http://local.example.com", region="us-east-1", priority=0),
            RegionalEndpoint(url="http://ap.example.com", region="ap-southeast-1", priority=0),
        ]
        result = rank_endpoints(endpoints, cfg)
        assert len(result) == 1
        assert result[0].region == "us-east-1"

    def test_preferred_order_honored_for_non_local_endpoints(self) -> None:
        """Non-local endpoints should rank by preferred_regions order."""
        cfg = RegionConfig(
            local_region="us-east-1",
            allowed_regions=frozenset(["us-east-1", "eu-west-1", "ap-southeast-1"]),
            preferred_regions=["ap-southeast-1", "eu-west-1"],
        )
        endpoints = [
            RegionalEndpoint(url="http://eu.example.com", region="eu-west-1", priority=0),
            RegionalEndpoint(url="http://ap.example.com", region="ap-southeast-1", priority=0),
        ]
        result = rank_endpoints(endpoints, cfg)
        # ap-southeast-1 is first in preferred list, so should rank higher
        assert result[0].region == "ap-southeast-1"
        assert result[1].region == "eu-west-1"

    def test_priority_breaks_ties_within_same_region(self) -> None:
        """Within same region/tier, lower priority value ranks first."""
        cfg = RegionConfig(
            local_region="us-east-1",
            allowed_regions=frozenset(["eu-west-1"]),
            preferred_regions=[],
        )
        endpoints = [
            RegionalEndpoint(url="http://eu-2.example.com", region="eu-west-1", priority=10),
            RegionalEndpoint(url="http://eu-1.example.com", region="eu-west-1", priority=5),
        ]
        result = rank_endpoints(endpoints, cfg)
        assert result[0].priority == 5
        assert result[1].priority == 10

    def test_stable_sort_preserves_input_order_for_ties(self) -> None:
        """Endpoints with identical tier, priority should keep input order."""
        cfg = RegionConfig(
            local_region="us-east-1",
            allowed_regions=frozenset(["eu-west-1"]),
            preferred_regions=[],
        )
        endpoints = [
            RegionalEndpoint(url="http://eu-first.example.com", region="eu-west-1", priority=5),
            RegionalEndpoint(url="http://eu-second.example.com", region="eu-west-1", priority=5),
        ]
        result = rank_endpoints(endpoints, cfg)
        assert result[0].url == "http://eu-first.example.com"
        assert result[1].url == "http://eu-second.example.com"

    def test_allowed_regions_empty_allows_anything(self) -> None:
        """Empty allowed_regions should not filter any endpoints."""
        cfg = RegionConfig(
            local_region="us-east-1",
            allowed_regions=frozenset(),
            preferred_regions=[],
        )
        endpoints = [
            RegionalEndpoint(url="http://eu.example.com", region="eu-west-1", priority=0),
            RegionalEndpoint(url="http://ap.example.com", region="ap-southeast-1", priority=0),
            RegionalEndpoint(url="http://local.example.com", region="us-east-1", priority=0),
        ]
        result = rank_endpoints(endpoints, cfg)
        assert len(result) == 3

    def test_local_region_global_disables_local_first_bonus(self) -> None:
        """When local_region='global', no local-first preference should apply."""
        cfg = RegionConfig(
            local_region="global",
            allowed_regions=frozenset(["us-east-1", "eu-west-1"]),
            preferred_regions=["eu-west-1"],
        )
        endpoints = [
            RegionalEndpoint(url="http://local.example.com", region="us-east-1", priority=0),
            RegionalEndpoint(url="http://eu.example.com", region="eu-west-1", priority=0),
        ]
        result = rank_endpoints(endpoints, cfg)
        # eu-west-1 is preferred, should rank first
        assert result[0].region == "eu-west-1"
        assert result[1].region == "us-east-1"

    def test_complex_scenario_all_tiers(self) -> None:
        """Complex scenario with local, preferred, and other allowed regions."""
        cfg = RegionConfig(
            local_region="us-east-1",
            allowed_regions=frozenset(
                ["us-east-1", "eu-west-1", "ap-southeast-1", "us-west-2"]
            ),
            preferred_regions=["ap-southeast-1", "eu-west-1"],
        )
        endpoints = [
            RegionalEndpoint(url="http://usw2.example.com", region="us-west-2", priority=0),
            RegionalEndpoint(url="http://eu-high-p.example.com", region="eu-west-1", priority=10),
            RegionalEndpoint(url="http://ap-low-p.example.com", region="ap-southeast-1", priority=5),
            RegionalEndpoint(url="http://local-high-p.example.com", region="us-east-1", priority=10),
            RegionalEndpoint(url="http://local-low-p.example.com", region="us-east-1", priority=5),
        ]
        result = rank_endpoints(endpoints, cfg)
        # Expected order:
        # 1. local (us-east-1) with priority 5
        # 2. local (us-east-1) with priority 10
        # 3. preferred ap-southeast-1 with priority 5
        # 4. preferred eu-west-1 with priority 10
        # 5. other allowed us-west-2 with priority 0
        assert result[0].region == "us-east-1" and result[0].priority == 5
        assert result[1].region == "us-east-1" and result[1].priority == 10
        assert result[2].region == "ap-southeast-1"
        assert result[3].region == "eu-west-1"
        assert result[4].region == "us-west-2"


class TestIsResidencyCompliant:
    """Tests for residency compliance checking."""

    def test_is_residency_compliant_returns_true_for_allowed_region(self) -> None:
        """should return True when evidence_region is in allowed_regions."""
        cfg = RegionConfig(
            local_region="us-east-1",
            allowed_regions=frozenset(["us-east-1", "eu-west-1"]),
            preferred_regions=[],
        )
        assert is_residency_compliant("us-east-1", cfg) is True
        assert is_residency_compliant("eu-west-1", cfg) is True

    def test_is_residency_compliant_returns_false_for_disallowed_region(self) -> None:
        """should return False when evidence_region is outside allowed_regions."""
        cfg = RegionConfig(
            local_region="us-east-1",
            allowed_regions=frozenset(["us-east-1", "eu-west-1"]),
            preferred_regions=[],
        )
        assert is_residency_compliant("ap-southeast-1", cfg) is False

    def test_is_residency_compliant_returns_true_for_empty_allowed_regions(self) -> None:
        """should return True when allowed_regions is empty (no restriction)."""
        cfg = RegionConfig(
            local_region="us-east-1",
            allowed_regions=frozenset(),
            preferred_regions=[],
        )
        assert is_residency_compliant("us-east-1", cfg) is True
        assert is_residency_compliant("eu-west-1", cfg) is True
        assert is_residency_compliant("ap-southeast-1", cfg) is True


class TestLoadRegionConfigFromEnv:
    """Tests for environment variable loading."""

    def test_load_region_config_from_env_defaults(self) -> None:
        """Default values when env vars are unset."""
        # Clear any existing env vars
        for key in ["GTV_REGION", "GTV_ALLOWED_REGIONS", "GTV_PREFERRED_REGIONS"]:
            os.environ.pop(key, None)

        cfg = load_region_config_from_env()
        assert cfg.local_region == "global"
        assert cfg.allowed_regions == frozenset()
        assert cfg.preferred_regions == []

    def test_load_region_config_from_env_parses_all_vars(self, monkeypatch: object) -> None:
        """Parses all three environment variables correctly."""
        assert isinstance(monkeypatch, pytest.MonkeyPatch)
        monkeypatch.setenv("GTV_REGION", "us-east-1")
        monkeypatch.setenv("GTV_ALLOWED_REGIONS", "us-east-1,eu-west-1,ap-southeast-1")
        monkeypatch.setenv("GTV_PREFERRED_REGIONS", "eu-west-1,ap-southeast-1")

        cfg = load_region_config_from_env()
        assert cfg.local_region == "us-east-1"
        assert cfg.allowed_regions == frozenset(["us-east-1", "eu-west-1", "ap-southeast-1"])
        assert cfg.preferred_regions == ["eu-west-1", "ap-southeast-1"]

    def test_load_region_config_from_env_strips_whitespace(
        self, monkeypatch: object
    ) -> None:
        """Handles whitespace in comma-separated lists."""
        assert isinstance(monkeypatch, pytest.MonkeyPatch)
        monkeypatch.setenv("GTV_ALLOWED_REGIONS", " us-east-1 , eu-west-1 , ap-southeast-1 ")
        monkeypatch.setenv("GTV_PREFERRED_REGIONS", " eu-west-1 , ap-southeast-1 ")

        cfg = load_region_config_from_env()
        assert cfg.allowed_regions == frozenset(["us-east-1", "eu-west-1", "ap-southeast-1"])
        assert cfg.preferred_regions == ["eu-west-1", "ap-southeast-1"]

    def test_load_region_config_from_env_empty_strings(self, monkeypatch: object) -> None:
        """Empty strings treated as no regions specified."""
        assert isinstance(monkeypatch, pytest.MonkeyPatch)
        monkeypatch.setenv("GTV_ALLOWED_REGIONS", "")
        monkeypatch.setenv("GTV_PREFERRED_REGIONS", "")

        cfg = load_region_config_from_env()
        assert cfg.allowed_regions == frozenset()
        assert cfg.preferred_regions == []


class TestRegionConfigValidation:
    """Tests for RegionConfig validation."""

    def test_region_config_valid_construction(self) -> None:
        """Valid RegionConfig should construct without error."""
        cfg = RegionConfig(
            local_region="us-east-1",
            allowed_regions=frozenset(["us-east-1", "eu-west-1"]),
            preferred_regions=["eu-west-1"],
        )
        assert cfg.local_region == "us-east-1"

    def test_region_config_raises_on_preferred_outside_allowed(self) -> None:
        """Should raise ValueError if preferred_region not in allowed_regions."""
        with pytest.raises(
            ValueError, match=re.escape("preferred_region ") + r".*" + re.escape(" not in allowed_regions")
        ):
            RegionConfig(
                local_region="us-east-1",
                allowed_regions=frozenset(["us-east-1", "eu-west-1"]),
                preferred_regions=["ap-southeast-1"],
            )
