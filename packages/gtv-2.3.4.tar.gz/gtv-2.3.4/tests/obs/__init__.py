"""Tests for gtv.obs modules."""
