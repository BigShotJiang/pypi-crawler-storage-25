"""Tests for webhook dispatcher with signing, filtering, and retry logic."""
from __future__ import annotations

import hashlib
import hmac
import time

import httpx
import pytest
import respx

from gtv.subscribe.webhook import WebhookDispatcher, WebhookSubscription


@pytest.fixture
def secret_key() -> bytes:
    """Test HMAC secret key."""
    return b"test-secret-key-12345"


@pytest.fixture
def subscription_123(secret_key: bytes) -> WebhookSubscription:
    """Test subscription with ID 123."""
    return WebhookSubscription(
        subscription_id="sub-123",
        url="https://example.com/webhook",
        domains=None,
        status_filter=None,
        secret=secret_key,
    )


@pytest.fixture
def subscription_domain_filtered(secret_key: bytes) -> WebhookSubscription:
    """Test subscription that only matches 'health' domain."""
    return WebhookSubscription(
        subscription_id="sub-domain",
        url="https://example.com/health-webhook",
        domains=["health"],
        status_filter=None,
        secret=secret_key,
    )


@pytest.fixture
def subscription_status_filtered(secret_key: bytes) -> WebhookSubscription:
    """Test subscription that only matches REFUTED status."""
    return WebhookSubscription(
        subscription_id="sub-status",
        url="https://example.com/refuted-webhook",
        domains=None,
        status_filter=["REFUTED"],
        secret=secret_key,
    )


@pytest.fixture
async def dispatcher() -> WebhookDispatcher:
    """Test webhook dispatcher."""
    return WebhookDispatcher(timeout=5.0, max_retries=3)


# ----------- Register and Basic Dispatch Tests -----------


@pytest.mark.asyncio
async def test_register_and_dispatch_delivers_200(
    dispatcher: WebhookDispatcher, subscription_123: WebhookSubscription
) -> None:
    """Register a subscription and dispatch a verdict successfully."""
    await dispatcher.register(subscription_123)

    payload = {"domain": "general", "status": "VERIFIED", "claim_id": "claim-1"}

    with respx.mock:
        route = respx.post("https://example.com/webhook").mock(return_value=httpx.Response(200))

        results = await dispatcher.dispatch(payload)

    assert len(results) == 1
    result = results[0]
    assert result.subscription_id == "sub-123"
    assert result.status_code == 200
    assert result.error is None
    assert result.attempts == 1
    assert route.called


@pytest.mark.asyncio
async def test_signature_header_present_and_correct(
    dispatcher: WebhookDispatcher, subscription_123: WebhookSubscription, secret_key: bytes
) -> None:
    """Verify X-GTV-Signature header is present and matches HMAC-SHA256."""
    await dispatcher.register(subscription_123)

    payload = {"domain": "general", "status": "VERIFIED"}

    captured_request = None

    def capture_request(request: httpx.Request) -> httpx.Response:
        nonlocal captured_request
        captured_request = request
        return httpx.Response(200)

    with respx.mock:
        respx.post("https://example.com/webhook").mock(side_effect=capture_request)

        await dispatcher.dispatch(payload)

    assert captured_request is not None
    assert "x-gtv-signature" in captured_request.headers
    sig_header = captured_request.headers["x-gtv-signature"]
    assert sig_header.startswith("sha256=")

    # Verify the signature matches our payload
    body_bytes = captured_request.content
    expected_sig = hmac.new(secret_key, body_bytes, hashlib.sha256).hexdigest()
    assert sig_header == f"sha256={expected_sig}"


@pytest.mark.asyncio
async def test_timestamp_header_present_and_recent(
    dispatcher: WebhookDispatcher, subscription_123: WebhookSubscription
) -> None:
    """Verify X-GTV-Timestamp header is present and recent."""
    await dispatcher.register(subscription_123)

    payload = {"domain": "general", "status": "VERIFIED"}

    captured_request = None

    def capture_request(request: httpx.Request) -> httpx.Response:
        nonlocal captured_request
        captured_request = request
        return httpx.Response(200)

    with respx.mock:
        respx.post("https://example.com/webhook").mock(side_effect=capture_request)

        before_time = int(time.time())
        await dispatcher.dispatch(payload)
        after_time = int(time.time())

    assert captured_request is not None
    assert "x-gtv-timestamp" in captured_request.headers
    timestamp_str = captured_request.headers["x-gtv-timestamp"]
    timestamp = int(timestamp_str)

    # Timestamp should be recent (within a few seconds)
    assert before_time <= timestamp <= after_time + 1


# ----------- Domain Filter Tests -----------


@pytest.mark.asyncio
async def test_domain_filter_includes_matching_verdict(
    dispatcher: WebhookDispatcher, subscription_domain_filtered: WebhookSubscription
) -> None:
    """Subscription with domain filter should match verdicts in that domain."""
    await dispatcher.register(subscription_domain_filtered)

    payload = {"domain": "health", "status": "VERIFIED"}

    with respx.mock:
        route = respx.post("https://example.com/health-webhook").mock(
            return_value=httpx.Response(200)
        )

        results = await dispatcher.dispatch(payload)

    assert len(results) == 1
    assert route.called


@pytest.mark.asyncio
async def test_domain_filter_excludes_non_matching_verdict(
    dispatcher: WebhookDispatcher, subscription_domain_filtered: WebhookSubscription
) -> None:
    """Subscription with domain filter should exclude verdicts from other domains."""
    await dispatcher.register(subscription_domain_filtered)

    payload = {"domain": "politics", "status": "VERIFIED"}

    with respx.mock:
        route = respx.post("https://example.com/health-webhook").mock(
            return_value=httpx.Response(200)
        )

        results = await dispatcher.dispatch(payload)

    assert len(results) == 0
    assert not route.called


# ----------- Status Filter Tests -----------


@pytest.mark.asyncio
async def test_status_filter_includes_matching_verdict(
    dispatcher: WebhookDispatcher, subscription_status_filtered: WebhookSubscription
) -> None:
    """Subscription with status filter should match verdicts with that status."""
    await dispatcher.register(subscription_status_filtered)

    payload = {"domain": "general", "status": "REFUTED"}

    with respx.mock:
        route = respx.post("https://example.com/refuted-webhook").mock(
            return_value=httpx.Response(200)
        )

        results = await dispatcher.dispatch(payload)

    assert len(results) == 1
    assert route.called


@pytest.mark.asyncio
async def test_status_filter_excludes_non_matching_verdict(
    dispatcher: WebhookDispatcher, subscription_status_filtered: WebhookSubscription
) -> None:
    """Subscription with status filter should exclude verdicts with other statuses."""
    await dispatcher.register(subscription_status_filtered)

    payload = {"domain": "general", "status": "VERIFIED"}

    with respx.mock:
        route = respx.post("https://example.com/refuted-webhook").mock(
            return_value=httpx.Response(200)
        )

        results = await dispatcher.dispatch(payload)

    assert len(results) == 0
    assert not route.called


# ----------- Unregister Tests -----------


@pytest.mark.asyncio
async def test_unregister_removes_subscription(
    dispatcher: WebhookDispatcher, subscription_123: WebhookSubscription
) -> None:
    """Unregistering a subscription should remove it from dispatch."""
    await dispatcher.register(subscription_123)

    payload = {"domain": "general", "status": "VERIFIED"}

    # Before unregister, should dispatch
    with respx.mock:
        route = respx.post("https://example.com/webhook").mock(return_value=httpx.Response(200))
        results = await dispatcher.dispatch(payload)

    assert len(results) == 1
    assert route.called

    # Unregister
    await dispatcher.unregister("sub-123")

    # After unregister, should not dispatch
    with respx.mock:
        route = respx.post("https://example.com/webhook").mock(return_value=httpx.Response(200))
        results = await dispatcher.dispatch(payload)

    assert len(results) == 0
    assert not route.called


# ----------- Retry Tests -----------


@pytest.mark.asyncio
async def test_5xx_triggers_retry_up_to_max_retries(
    dispatcher: WebhookDispatcher, subscription_123: WebhookSubscription
) -> None:
    """5xx responses should trigger retries up to max_retries."""
    await dispatcher.register(subscription_123)

    payload = {"domain": "general", "status": "VERIFIED"}

    with respx.mock:
        # First 2 attempts return 503, third returns 200
        route = respx.post("https://example.com/webhook").mock(
            side_effect=[
                httpx.Response(503),
                httpx.Response(503),
                httpx.Response(200),
            ]
        )

        results = await dispatcher.dispatch(payload)

    assert len(results) == 1
    result = results[0]
    assert result.status_code == 200
    assert result.attempts == 3
    assert result.error is None
    assert route.call_count == 3


@pytest.mark.asyncio
async def test_4xx_does_not_retry(
    dispatcher: WebhookDispatcher, subscription_123: WebhookSubscription
) -> None:
    """4xx responses should not retry (terminal failure)."""
    await dispatcher.register(subscription_123)

    payload = {"domain": "general", "status": "VERIFIED"}

    with respx.mock:
        route = respx.post("https://example.com/webhook").mock(return_value=httpx.Response(400))

        results = await dispatcher.dispatch(payload)

    assert len(results) == 1
    result = results[0]
    assert result.status_code == 400
    assert result.attempts == 1
    assert "400" in result.error
    assert route.call_count == 1


@pytest.mark.asyncio
async def test_network_error_triggers_retry(
    dispatcher: WebhookDispatcher, subscription_123: WebhookSubscription
) -> None:
    """Network errors should trigger retries."""
    await dispatcher.register(subscription_123)

    payload = {"domain": "general", "status": "VERIFIED"}

    with respx.mock:
        # First attempt fails with network error, second succeeds
        route = respx.post("https://example.com/webhook").mock(
            side_effect=[
                httpx.ConnectError("Connection failed"),
                httpx.Response(200),
            ]
        )

        results = await dispatcher.dispatch(payload)

    assert len(results) == 1
    result = results[0]
    assert result.status_code == 200
    assert result.attempts == 2
    assert result.error is None
    assert route.call_count == 2


# ----------- Multiple Subscriptions (Fan-out) Tests -----------


@pytest.mark.asyncio
async def test_multiple_subscriptions_fan_out_returns_results_for_all(
    dispatcher: WebhookDispatcher, secret_key: bytes
) -> None:
    """Dispatch to multiple subscriptions should return results for all."""
    sub1 = WebhookSubscription(
        subscription_id="sub-1",
        url="https://example.com/hook1",
        domains=None,
        status_filter=None,
        secret=secret_key,
    )
    sub2 = WebhookSubscription(
        subscription_id="sub-2",
        url="https://example.com/hook2",
        domains=None,
        status_filter=None,
        secret=secret_key,
    )
    sub3 = WebhookSubscription(
        subscription_id="sub-3",
        url="https://example.com/hook3",
        domains=None,
        status_filter=None,
        secret=secret_key,
    )

    await dispatcher.register(sub1)
    await dispatcher.register(sub2)
    await dispatcher.register(sub3)

    payload = {"domain": "general", "status": "VERIFIED"}

    with respx.mock:
        route1 = respx.post("https://example.com/hook1").mock(return_value=httpx.Response(200))
        route2 = respx.post("https://example.com/hook2").mock(return_value=httpx.Response(500))
        route3 = respx.post("https://example.com/hook3").mock(return_value=httpx.Response(200))

        results = await dispatcher.dispatch(payload)

    # Should have 3 results, one for each subscription
    assert len(results) == 3

    # Sort by subscription_id for consistent assertion
    results_by_id = {r.subscription_id: r for r in results}

    assert results_by_id["sub-1"].status_code == 200
    assert results_by_id["sub-2"].status_code is None or results_by_id["sub-2"].attempts > 1
    assert results_by_id["sub-3"].status_code == 200

    assert route1.called
    assert route2.called
    assert route3.called
