"""Pin version parity across the files the release pipeline reads.

The release workflow (`.github/workflows/release.yml`) verifies at tag
time that `pyproject.toml`'s version matches the git tag. That check
fires *after* you've pushed the tag. This test fires on every PR,
catching the mismatch before it gets anywhere near a release.

Three sources of truth:
 * `pyproject.toml[project][version]`
 * `src/gtv/__init__.py::__version__`
 * Top non-Unreleased section in `CHANGELOG.md` (`## [X.Y.Z] - YYYY-MM-DD`)

All three must agree.
"""

from __future__ import annotations

import re
import sys
import tomllib
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PYPROJECT = ROOT / "pyproject.toml"
INIT = ROOT / "src" / "gtv" / "__init__.py"
CHANGELOG = ROOT / "CHANGELOG.md"

_SEMVER = re.compile(r"^\d+\.\d+\.\d+(?:[.\-+][A-Za-z0-9.\-]+)?$")


def _pyproject_version() -> str:
    with PYPROJECT.open("rb") as f:
        meta = tomllib.load(f)
    return str(meta["project"]["version"])


def _init_version() -> str:
    m = re.search(r'__version__\s*=\s*"([^"]+)"', INIT.read_text())
    assert m, "__version__ missing from src/gtv/__init__.py"
    return m.group(1)


def _top_changelog_version() -> str:
    """Return the first non-Unreleased version header in CHANGELOG."""
    text = CHANGELOG.read_text()
    # Find all "## [X.Y.Z]" section headers in order.
    for m in re.finditer(r"^## \[([^\]]+)\]", text, flags=re.MULTILINE):
        label = m.group(1)
        if label.lower() == "unreleased":
            continue
        return label
    raise AssertionError("No released section found in CHANGELOG.md")


def test_pyproject_and_init_versions_agree() -> None:
    assert _pyproject_version() == _init_version(), (
        f"pyproject.toml ({_pyproject_version()}) vs __init__.py "
        f"({_init_version()}) disagree — update both before releasing"
    )


def test_current_version_has_changelog_entry() -> None:
    """The version we're shipping must have a corresponding CHANGELOG
    section. If this fails, move [Unreleased] → [X.Y.Z] and refill
    [Unreleased] with `_No changes yet._`."""
    version = _pyproject_version()
    assert version == _top_changelog_version(), (
        f"pyproject version {version} is missing from CHANGELOG.md "
        f"(top released section is {_top_changelog_version()})"
    )


def test_version_is_valid_semver() -> None:
    v = _pyproject_version()
    assert _SEMVER.match(v), f"{v!r} is not a valid semver string"


def test_unreleased_section_exists() -> None:
    """Every release should leave an empty `[Unreleased]` section at the
    top so the next PR has an obvious place to add its entry."""
    text = CHANGELOG.read_text()
    assert re.search(r"^## \[Unreleased\]", text, flags=re.MULTILINE), (
        "CHANGELOG must keep a `## [Unreleased]` section at the top"
    )


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"PASS {name}")  # noqa: T201
            except AssertionError as e:
                print(f"FAIL {name}: {e}", file=sys.stderr)  # noqa: T201
                sys.exit(1)
