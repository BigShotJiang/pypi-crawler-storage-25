"""Tests for RFC 3161 Time-Stamp Authority clients.

These tests cover:
1. Stub path: deterministic output when GTV_TSA_ENABLED is unset.
2. Secondary-down graceful degradation: primary succeeds, secondary fails.
3. Primary-down error path: primary fails when flag is on.
4. Live path: real TSA requests when GTV_TSA_ENABLED=1 (gated by @pytest.mark.live).
"""
from __future__ import annotations

import base64
import os

import httpx
import pytest
import respx

from gtv.anchor.tsa import RFC3161Client, TimestampToken


@pytest.mark.asyncio
async def test_timestamp_stub_when_disabled() -> None:
    """Verify deterministic stub output when GTV_TSA_ENABLED is not set.

    This is the default path for most tests and local dev. The stub produces
    clearly-marked stub:// tokens so regressions are visible, not silent.
    """
    # Ensure flag is not set
    os.environ.pop("GTV_TSA_ENABLED", None)

    client = RFC3161Client()
    test_data = b"hello world"

    primary, secondary = await client.timestamp(test_data)

    # Verify primary is a stub (stub is base64-encoded "stub-primary:{hash}")
    stub_primary_decoded = base64.b64decode(primary.tsr_b64).decode("utf-8")
    assert stub_primary_decoded.startswith("stub-primary:")
    assert primary.authority == "https://freetsa.org/tsr"
    assert primary.issued_at is not None

    # Verify secondary is a stub (stub is base64-encoded "stub-secondary:{hash}")
    assert secondary is not None
    stub_secondary_decoded = base64.b64decode(secondary.tsr_b64).decode("utf-8")
    assert stub_secondary_decoded.startswith("stub-secondary:")
    assert secondary.authority == "http://timestamp.digicert.com"
    assert secondary.issued_at is not None


@pytest.mark.asyncio
async def test_timestamp_stub_is_deterministic() -> None:
    """Verify that stub timestamping produces deterministic output."""
    os.environ.pop("GTV_TSA_ENABLED", None)

    client = RFC3161Client()
    test_data = b"consistent input"

    primary1, secondary1 = await client.timestamp(test_data)
    primary2, secondary2 = await client.timestamp(test_data)

    # Primary and secondary should match on both runs
    assert primary1.tsr_b64 == primary2.tsr_b64
    assert secondary1.tsr_b64 == secondary2.tsr_b64


@pytest.mark.asyncio
async def test_timestamp_stub_different_for_different_data() -> None:
    """Verify that different data produces different stubs."""
    os.environ.pop("GTV_TSA_ENABLED", None)

    client = RFC3161Client()

    primary1, _ = await client.timestamp(b"data1")
    primary2, _ = await client.timestamp(b"data2")

    assert primary1.tsr_b64 != primary2.tsr_b64


@pytest.mark.asyncio
async def test_timestamp_secondary_down_returns_primary_only(real_tsa_response: bytes) -> None:
    """Verify graceful degradation when secondary TSA is down.

    Primary should succeed, secondary should fail silently, and we return
    (primary, None). This is the core feature: do not let a secondary
    outage block envelope issuance.
    """
    os.environ["GTV_TSA_ENABLED"] = "1"

    client = RFC3161Client()
    test_data = b"test payload"

    with respx.mock:
        # Match POST to primary, return a real TSR response
        respx.post("https://freetsa.org/tsr").mock(
            return_value=httpx.Response(200, content=real_tsa_response)
        )

        # Match POST to secondary, fail with 503
        respx.post("http://timestamp.digicert.com").mock(
            return_value=httpx.Response(503, text="Service Unavailable")
        )

        primary, secondary = await client.timestamp(test_data)

        # Primary should succeed
        assert primary.tsr_b64
        assert base64.b64decode(primary.tsr_b64)  # Should be valid base64
        assert primary.authority == "https://freetsa.org/tsr"

        # Secondary should be None due to 503
        assert secondary is None

    os.environ.pop("GTV_TSA_ENABLED", None)


@pytest.mark.asyncio
async def test_timestamp_primary_down_raises() -> None:
    """Verify that primary TSA failure raises RuntimeError loudly.

    When GTV_TSA_ENABLED=1, a primary TSA failure is fatal and should
    not silently fall back to stubs.
    """
    os.environ["GTV_TSA_ENABLED"] = "1"

    client = RFC3161Client()
    test_data = b"test payload"

    with respx.mock:
        # Make primary fail
        respx.post("https://freetsa.org/tsr").mock(
            return_value=httpx.Response(500, text="Internal Server Error")
        )

        with pytest.raises(RuntimeError, match="TSA request failed"):
            await client.timestamp(test_data)

    os.environ.pop("GTV_TSA_ENABLED", None)


@pytest.mark.live
@pytest.mark.asyncio
async def test_timestamp_live_freetsa() -> None:
    """Real FreeTSA timestamp test (requires GTV_TSA_ENABLED=1).

    This test only runs when explicitly enabled. It:
    - Builds a TimeStampRequest with SHA256
    - Submits to real FreeTSA
    - Verifies TSR is valid base64
    - Verifies TSR decodes to valid ASN.1 (TimeStampResponse)
    """
    if os.environ.get("GTV_TSA_ENABLED") != "1":
        pytest.skip("GTV_TSA_ENABLED not set; skipping live TSA test")

    client = RFC3161Client()
    test_data = b"Ground Truth Verification System"

    primary, secondary = await client.timestamp(test_data)

    # Verify primary is non-empty base64
    assert primary.tsr_b64
    tsr_bytes = base64.b64decode(primary.tsr_b64)
    assert len(tsr_bytes) > 0

    # Verify it decodes to a valid TimeStampResponse
    from rfc3161_client import decode_timestamp_response

    ts_resp = decode_timestamp_response(tsr_bytes)
    assert ts_resp is not None
    assert ts_resp.time_stamp_token()  # Should not raise

    # Secondary may be None or may succeed; both are acceptable
    if secondary is not None:
        assert secondary.tsr_b64
        secondary_bytes = base64.b64decode(secondary.tsr_b64)
        assert len(secondary_bytes) > 0


@pytest.mark.live
@pytest.mark.asyncio
async def test_timestamp_live_digicert() -> None:
    """Real DigiCert timestamp test (requires GTV_TSA_ENABLED=1).

    This test verifies that secondary TSA (DigiCert) works if available.
    It's marked as @pytest.mark.live because DigiCert may have stricter
    rate limits or availability SLAs.
    """
    if os.environ.get("GTV_TSA_ENABLED") != "1":
        pytest.skip("GTV_TSA_ENABLED not set; skipping live TSA test")

    test_data = b"Secondary TSA test"

    from rfc3161_client import HashAlgorithm, TimestampRequestBuilder

    ts_req = TimestampRequestBuilder(data=test_data, hash_algorithm=HashAlgorithm.SHA256).build()

    try:
        async with httpx.AsyncClient(timeout=5.0) as http_client:
            resp = await http_client.post(
                "http://timestamp.digicert.com",
                content=ts_req.as_bytes(),
                headers={"Content-Type": "application/timestamp-query"},
            )
            resp.raise_for_status()

            from rfc3161_client import decode_timestamp_response

            ts_resp = decode_timestamp_response(resp.content)
            assert ts_resp.time_stamp_token()
    except Exception as e:
        # DigiCert may not be available; this is OK
        pytest.skip(f"DigiCert TSA not available: {e}")


def test_timestamp_token_dataclass() -> None:
    """Verify TimestampToken dataclass structure."""
    from datetime import UTC, datetime

    now = datetime.now(tz=UTC)
    token = TimestampToken(
        tsr_b64="YWJjZGVm",
        authority="https://example.com/tsa",
        issued_at=now,
    )

    assert token.tsr_b64 == "YWJjZGVm"
    assert token.authority == "https://example.com/tsa"
    assert token.issued_at == now

    # Verify frozen
    with pytest.raises(AttributeError):
        token.tsr_b64 = "new"  # type: ignore


@pytest.mark.asyncio
async def test_timestamp_custom_urls(real_tsa_response: bytes) -> None:
    """Verify RFC3161Client respects custom TSA URLs."""
    os.environ["GTV_TSA_ENABLED"] = "1"

    custom_primary = "https://custom-primary.example.com/tsa"
    custom_secondary = "https://custom-secondary.example.com/tsa"

    client = RFC3161Client(
        primary_url=custom_primary,
        secondary_url=custom_secondary,
        timeout=5.0,
    )

    with respx.mock:
        respx.post(custom_primary).mock(return_value=httpx.Response(200, content=real_tsa_response))
        respx.post(custom_secondary).mock(return_value=httpx.Response(200, content=real_tsa_response))

        primary, secondary = await client.timestamp(b"test")

        assert primary.authority == custom_primary
        assert secondary is not None
        assert secondary.authority == custom_secondary

    os.environ.pop("GTV_TSA_ENABLED", None)
