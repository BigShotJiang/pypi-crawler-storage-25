"""Tests for POST /consensus HTTP endpoint."""
from __future__ import annotations

from datetime import UTC, datetime

import pytest
from fastapi.testclient import TestClient

from gtv.mcp.server import app
from gtv.models import AnchorProof, Envelope, Evidence, Stance, Verdict


@pytest.fixture
def client() -> TestClient:
    """FastAPI test client."""
    return TestClient(app)


def _make_envelope(
    verdict: Verdict,
    issuer_did: str,
    claim_id: str = "test-claim-id",
) -> dict:
    """Helper to construct a minimal test Envelope as dict."""
    envelope = Envelope(
        verdict=verdict,
        confidence=0.9,
        evidence=[
            Evidence(
                claim_id=claim_id,
                source_did="did:source",
                source_version="1.0",
                stance=Stance.SUPPORTS,
                excerpt="test excerpt",
                url="https://example.com",
                retrieved_at=datetime.now(tz=UTC),
                raw_hash="0" * 64,
            )
        ],
        rationale="test",
        issuer_did=issuer_did,
        signature="stub://sig",
        rekor_uuid="test-uuid",
        rekor_log_index=0,
        tsa_token="stub://tsa",
        prov_graph="{}",
        anchor_proof=AnchorProof(
            rekor_inclusion_proof="stub://proof",
            tsa_tsr_primary="stub://tsa",
        ),
    )
    return envelope.model_dump(mode="json")


class TestConsensusEndpoint:
    """Tests for POST /consensus endpoint."""

    def test_consensus_happy_path(self, client: TestClient) -> None:
        """POST /consensus with two verified envelopes → 200 + result."""
        env1 = _make_envelope(Verdict.VERIFIED, "did:test:issuer1")
        env2 = _make_envelope(Verdict.VERIFIED, "did:test:issuer2")

        resp = client.post("/consensus", json={"envelopes": [env1, env2]})
        assert resp.status_code == 200

        data = resp.json()
        assert data["verdict"] == "VERIFIED"
        assert isinstance(data["confidence"], float)
        assert len(data["tally"]) >= 1
        assert isinstance(data["unknown_dids"], list)

    def test_consensus_single_envelope(self, client: TestClient) -> None:
        """Single VERIFIED envelope → 200."""
        env = _make_envelope(Verdict.VERIFIED, "did:test:issuer1")

        resp = client.post("/consensus", json={"envelopes": [env]})
        assert resp.status_code == 200

        data = resp.json()
        assert data["verdict"] == "VERIFIED"
        assert data["confidence"] == 1.0

    def test_consensus_empty_envelopes_400(self, client: TestClient) -> None:
        """Empty envelopes list → 400."""
        resp = client.post("/consensus", json={"envelopes": []})
        assert resp.status_code == 400

        data = resp.json()
        assert "empty" in data["detail"].lower()

    def test_consensus_invalid_json_400(self, client: TestClient) -> None:
        """Malformed envelope → 400."""
        resp = client.post("/consensus", json={"envelopes": [{"invalid": "envelope"}]})
        assert resp.status_code == 400

        data = resp.json()
        assert "Invalid" in data["detail"] or "invalid" in data["detail"].lower()

    def test_consensus_mismatched_claims_400(self, client: TestClient) -> None:
        """Envelopes with different claim_ids → 400."""
        env1 = _make_envelope(Verdict.VERIFIED, "did:test:issuer1", claim_id="claim-1")
        env2 = _make_envelope(Verdict.VERIFIED, "did:test:issuer2", claim_id="claim-2")

        resp = client.post("/consensus", json={"envelopes": [env1, env2]})
        assert resp.status_code == 400

        data = resp.json()
        assert "claim" in data["detail"].lower()

    def test_consensus_unknown_dids(self, client: TestClient) -> None:
        """Unknown DIDs should appear in unknown_dids field."""
        env = _make_envelope(Verdict.VERIFIED, "did:unknown:issuer")

        resp = client.post("/consensus", json={"envelopes": [env]})
        assert resp.status_code == 200

        data = resp.json()
        assert "did:unknown:issuer" in data["unknown_dids"]

    def test_consensus_contested(self, client: TestClient) -> None:
        """VERIFIED + UNVERIFIED → CONTESTED."""
        env1 = _make_envelope(Verdict.VERIFIED, "did:test:issuer1")
        env2 = _make_envelope(Verdict.UNVERIFIED, "did:test:issuer2")

        resp = client.post("/consensus", json={"envelopes": [env1, env2]})
        assert resp.status_code == 200

        data = resp.json()
        assert data["verdict"] == "CONTESTED"

    def test_consensus_tally_structure(self, client: TestClient) -> None:
        """Tally should have correct structure."""
        env1 = _make_envelope(Verdict.VERIFIED, "did:test:issuer1")
        env2 = _make_envelope(Verdict.VERIFIED, "did:test:issuer2")

        resp = client.post("/consensus", json={"envelopes": [env1, env2]})
        assert resp.status_code == 200

        data = resp.json()
        for tally_item in data["tally"]:
            assert "verdict" in tally_item
            assert "weighted_votes" in tally_item
            assert "envelope_count" in tally_item
            assert isinstance(tally_item["weighted_votes"], float)
            assert isinstance(tally_item["envelope_count"], int)

    def test_consensus_missing_envelopes_field_400(self, client: TestClient) -> None:
        """Missing envelopes field → validation error."""
        resp = client.post("/consensus", json={})
        assert resp.status_code == 422  # Pydantic validation error

    def test_consensus_null_envelopes_400(self, client: TestClient) -> None:
        """null envelopes value → validation error."""
        resp = client.post("/consensus", json={"envelopes": None})
        assert resp.status_code == 422  # Pydantic validation error
