"""Unit tests for the claim lifecycle index.

Covers registration, self-supersede rejection, cycle detection,
cross-issuer rejection, history/descendants/latest walks, and the
SQLite-backed persistence round-trip.
"""
from __future__ import annotations

from pathlib import Path

import pytest

from gtv.lifecycle import (
    LifecycleError,
    LifecycleIndex,
    normalize_claim_for_lifecycle,
)
from gtv.lifecycle.index import SQLiteLifecycleIndex
from gtv.models import (
    AnchorProof,
    Envelope,
    SupersedeReason,
    Verdict,
)


def _envelope(
    *,
    envelope_id: str,
    issuer_did: str = "did:web:example.test",
    supersedes: list[str] | None = None,
    supersede_reason: SupersedeReason | None = None,
    verdict: Verdict = Verdict.VERIFIED,
) -> Envelope:
    """Build a minimal, valid envelope for lifecycle tests.

    Signature validity is not checked by the lifecycle layer — it only
    cares about the declared fields — so we pass a placeholder.
    """
    return Envelope(
        envelope_id=envelope_id,
        verdict=verdict,
        confidence=0.9,
        evidence=[],
        rationale="test",
        issuer_did=issuer_did,
        signature="stub://test",
        rekor_uuid="stub-uuid",
        rekor_log_index=0,
        tsa_token="stub://dev",
        prov_graph="{}",
        anchor_proof=AnchorProof(
            rekor_inclusion_proof="stub://pending",
            tsa_tsr_primary="stub://dev",
            tsa_tsr_secondary=None,
        ),
        supersedes=supersedes or [],
        supersede_reason=supersede_reason,
    )


def test_normalize_claim_collapses_and_casefolds() -> None:
    assert normalize_claim_for_lifecycle("Hello  World") == "hello world"
    assert normalize_claim_for_lifecycle("\tpi\t is 3.14 ") == "pi is 3.14"


def test_register_new_envelope_as_root() -> None:
    idx = LifecycleIndex()
    env = _envelope(envelope_id="e1")
    entry = idx.register(env, claim_text="The sky is blue.", domain="physics")
    assert entry.envelope_id == "e1"
    assert entry.parents == ()
    assert idx.get("e1") is entry
    # Payload round-trips back to an Envelope.
    got = idx.get_envelope("e1")
    assert got is not None
    assert got.envelope_id == "e1"


def test_register_rejects_duplicate() -> None:
    idx = LifecycleIndex()
    env = _envelope(envelope_id="e1")
    idx.register(env, claim_text="c", domain="physics")
    with pytest.raises(LifecycleError) as exc:
        idx.register(env, claim_text="c", domain="physics")
    assert exc.value.code == "duplicate"


def test_register_rejects_self_supersede() -> None:
    idx = LifecycleIndex()
    env = _envelope(envelope_id="e1", supersedes=["e1"])
    with pytest.raises(LifecycleError) as exc:
        idx.register(env, claim_text="c", domain="physics")
    assert exc.value.code == "self_supersede"


def test_register_rejects_unknown_parent() -> None:
    idx = LifecycleIndex()
    env = _envelope(envelope_id="e1", supersedes=["nope"])
    with pytest.raises(LifecycleError) as exc:
        idx.register(env, claim_text="c", domain="physics")
    assert exc.value.code == "unknown_parent"


def test_register_rejects_cross_issuer() -> None:
    idx = LifecycleIndex()
    parent = _envelope(envelope_id="e1", issuer_did="did:web:alice")
    idx.register(parent, claim_text="c", domain="physics")
    child = _envelope(
        envelope_id="e2",
        issuer_did="did:web:bob",
        supersedes=["e1"],
        supersede_reason=SupersedeReason.SUPERSEDE,
    )
    with pytest.raises(LifecycleError) as exc:
        idx.register(child, claim_text="c", domain="physics")
    assert exc.value.code == "cross_issuer"


def test_history_walks_parents() -> None:
    idx = LifecycleIndex()
    a = _envelope(envelope_id="a")
    b = _envelope(envelope_id="b", supersedes=["a"], supersede_reason=SupersedeReason.AMEND)
    c = _envelope(envelope_id="c", supersedes=["b"], supersede_reason=SupersedeReason.SUPERSEDE)
    idx.register(a, claim_text="c", domain="physics")
    idx.register(b, claim_text="c", domain="physics")
    idx.register(c, claim_text="c", domain="physics")

    hist = idx.history("c")
    assert [e.envelope_id for e in hist] == ["c", "b", "a"]
    assert hist[0].supersede_reason == SupersedeReason.SUPERSEDE
    assert hist[2].supersede_reason is None  # root


def test_descendants_walks_children() -> None:
    idx = LifecycleIndex()
    a = _envelope(envelope_id="a")
    b = _envelope(envelope_id="b", supersedes=["a"], supersede_reason=SupersedeReason.AMEND)
    c = _envelope(envelope_id="c", supersedes=["b"], supersede_reason=SupersedeReason.SUPERSEDE)
    idx.register(a, claim_text="c", domain="physics")
    idx.register(b, claim_text="c", domain="physics")
    idx.register(c, claim_text="c", domain="physics")

    desc = idx.descendants("a")
    assert [e.envelope_id for e in desc] == ["b", "c"]


def test_latest_returns_head() -> None:
    idx = LifecycleIndex()
    a = _envelope(envelope_id="a")
    b = _envelope(envelope_id="b", supersedes=["a"], supersede_reason=SupersedeReason.SUPERSEDE)
    idx.register(a, claim_text="The sky is blue.", domain="physics")
    idx.register(b, claim_text="The sky is blue.", domain="physics")

    head = idx.latest(
        claim_text="the  sky is BLUE.",  # normalization must match
        domain="physics",
        issuer_did="did:web:example.test",
    )
    assert head is not None
    assert head.envelope_id == "b"


def test_latest_returns_none_for_unknown_claim() -> None:
    idx = LifecycleIndex()
    assert (
        idx.latest(claim_text="no such claim", domain="physics", issuer_did="did:web:x")
        is None
    )


def test_latest_picks_longest_branch_on_fork() -> None:
    """If two heads exist (fork), pick the one with the longer ancestry."""
    idx = LifecycleIndex()
    a = _envelope(envelope_id="a")
    b1 = _envelope(envelope_id="b1", supersedes=["a"], supersede_reason=SupersedeReason.AMEND)
    b2 = _envelope(envelope_id="b2", supersedes=["a"], supersede_reason=SupersedeReason.AMEND)
    c1 = _envelope(
        envelope_id="c1", supersedes=["b1"], supersede_reason=SupersedeReason.SUPERSEDE
    )
    for e in (a, b1, b2, c1):
        idx.register(e, claim_text="claim", domain="physics")

    head = idx.latest(
        claim_text="claim", domain="physics", issuer_did="did:web:example.test"
    )
    # Both c1 and b2 are heads; c1 has deeper ancestry.
    assert head is not None
    assert head.envelope_id == "c1"


def test_sqlite_index_round_trip(tmp_path: Path) -> None:
    """Persist → drop the object → reopen → queries still work."""
    db_path = tmp_path / "lifecycle.db"
    idx1 = SQLiteLifecycleIndex(path=db_path)
    a = _envelope(envelope_id="root")
    b = _envelope(
        envelope_id="child", supersedes=["root"], supersede_reason=SupersedeReason.SUPERSEDE
    )
    idx1.register(a, claim_text="The sky is blue.", domain="physics")
    idx1.register(b, claim_text="The sky is blue.", domain="physics")
    idx1.close()

    idx2 = SQLiteLifecycleIndex(path=db_path)
    try:
        assert len(idx2) == 2
        hist = idx2.history("child")
        assert [e.envelope_id for e in hist] == ["child", "root"]
        # Payload preserved — get_envelope rebuilds the full Envelope.
        got = idx2.get_envelope("root")
        assert got is not None
        assert got.envelope_id == "root"
    finally:
        idx2.close()
