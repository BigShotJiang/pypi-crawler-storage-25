"""End-to-end server test: adversarial-no-adapter + canonical-hash stability."""
from __future__ import annotations

from fastapi.testclient import TestClient

from gtv.adapters import REGISTRY
from gtv.mcp.server import app


def test_health_endpoint() -> None:
    client = TestClient(app)
    r = client.get("/health")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"


def test_verify_claim_without_adapters_returns_503() -> None:
    """Test that 503 is returned when no adapters are registered.

    We temporarily clear the REGISTRY to test this edge case.
    """
    # Save current adapters.
    saved_registry = dict(REGISTRY)
    try:
        # Clear the registry.
        REGISTRY.clear()

        client = TestClient(app)
        r = client.post("/tools/verify_claim", json={"claim": "x"})
        assert r.status_code == 503
    finally:
        # Restore adapters.
        REGISTRY.update(saved_registry)


