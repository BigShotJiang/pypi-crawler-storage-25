"""Smoke tests for gtv-sign-byok CLI.

Covers:
1. Happy path: sign a draft envelope, output is valid JSON
2. Missing --key argument: exits with code 2
3. Missing --envelope argument: exits with code 2
4. Missing --out argument: exits with code 2
5. Nonexistent key file: exits with code 3
6. Nonexistent envelope file: exits with code 3
7. Invalid JSON in envelope file: exits with code 4
8. Invalid envelope schema: exits with code 4
9. Invalid PEM key: exits with code 5 (or 6)
10. Output file is valid Envelope JSON
"""
from __future__ import annotations

import json
import tempfile
from datetime import UTC, datetime
from pathlib import Path

import pytest
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ed25519

from gtv.cli.sign import main
from gtv.models import Envelope


@pytest.fixture
def ed25519_key_pem() -> bytes:
    """Generate a test Ed25519 private key."""
    private_key = ed25519.Ed25519PrivateKey.generate()
    return private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )


@pytest.fixture
def draft_envelope_json() -> dict:
    """Create a minimal draft envelope as a dict."""
    return {
        "envelope_id": "test-draft-001",
        "verdict": "VERIFIED",
        "confidence": 0.95,
        "evidence": [],
        "rationale": "Test envelope",
        "issuer_did": "did:web:example.com",
        "issued_at": datetime.now(tz=UTC).isoformat(),
        "signature": "",
        "rekor_uuid": "test-uuid",
        "rekor_log_index": 0,
        "tsa_token": "stub://",
        "prov_graph": "{}",
        "anchor_proof": {
            "rekor_inclusion_proof": "{}",
            "tsa_tsr_primary": "stub://",
            "tsa_tsr_secondary": None,
        },
    }


class TestCLIHappyPath:
    """Tests for successful signing via CLI."""

    def test_sign_and_write_to_output_file(
        self,
        ed25519_key_pem: bytes,
        draft_envelope_json: dict,
    ) -> None:
        """Happy path: sign a draft envelope and write to output file."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir_path = Path(tmpdir)

            # Write key file
            key_file = tmpdir_path / "key.pem"
            key_file.write_bytes(ed25519_key_pem)

            # Write envelope file
            env_file = tmpdir_path / "draft.json"
            env_file.write_text(json.dumps(draft_envelope_json))

            # Output file
            out_file = tmpdir_path / "signed.json"

            # Run CLI
            exit_code = main([
                "--key", str(key_file),
                "--envelope", str(env_file),
                "--out", str(out_file),
            ])

            assert exit_code == 0
            assert out_file.exists()

            # Verify output is valid Envelope JSON
            signed_data = json.loads(out_file.read_text())
            signed_env = Envelope.model_validate(signed_data)

            # Verify signature and issuer_did were populated
            assert signed_env.signature.startswith("byok-ed25519:")
            assert signed_env.issuer_did.startswith("did:key:z")

    def test_signed_envelope_is_verifiable(
        self,
        ed25519_key_pem: bytes,
        draft_envelope_json: dict,
    ) -> None:
        """The CLI-signed envelope can be verified."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir_path = Path(tmpdir)

            key_file = tmpdir_path / "key.pem"
            key_file.write_bytes(ed25519_key_pem)

            env_file = tmpdir_path / "draft.json"
            env_file.write_text(json.dumps(draft_envelope_json))

            out_file = tmpdir_path / "signed.json"

            exit_code = main([
                "--key", str(key_file),
                "--envelope", str(env_file),
                "--out", str(out_file),
            ])

            assert exit_code == 0

            # Verify the signed envelope
            signed_data = json.loads(out_file.read_text())
            signed_env = Envelope.model_validate(signed_data)

            from gtv.sign import verify_envelope_byok
            # Should not raise
            verify_envelope_byok(signed_env)


class TestCLIMissingArguments:
    """Tests for missing required CLI arguments."""

    def test_missing_key_argument(
        self,
        draft_envelope_json: dict,
    ) -> None:
        """Missing --key exits with code 2."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir_path = Path(tmpdir)

            env_file = tmpdir_path / "draft.json"
            env_file.write_text(json.dumps(draft_envelope_json))

            out_file = tmpdir_path / "signed.json"

            exit_code = main([
                "--envelope", str(env_file),
                "--out", str(out_file),
            ])

            assert exit_code == 2

    def test_missing_envelope_argument(
        self,
        ed25519_key_pem: bytes,
    ) -> None:
        """Missing --envelope exits with code 2."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir_path = Path(tmpdir)

            key_file = tmpdir_path / "key.pem"
            key_file.write_bytes(ed25519_key_pem)

            out_file = tmpdir_path / "signed.json"

            exit_code = main([
                "--key", str(key_file),
                "--out", str(out_file),
            ])

            assert exit_code == 2

    def test_missing_out_argument(
        self,
        ed25519_key_pem: bytes,
        draft_envelope_json: dict,
    ) -> None:
        """Missing --out exits with code 2."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir_path = Path(tmpdir)

            key_file = tmpdir_path / "key.pem"
            key_file.write_bytes(ed25519_key_pem)

            env_file = tmpdir_path / "draft.json"
            env_file.write_text(json.dumps(draft_envelope_json))

            exit_code = main([
                "--key", str(key_file),
                "--envelope", str(env_file),
            ])

            assert exit_code == 2


class TestCLIFileErrors:
    """Tests for file I/O errors."""

    def test_nonexistent_key_file(
        self,
        draft_envelope_json: dict,
    ) -> None:
        """Nonexistent key file exits with code 3."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir_path = Path(tmpdir)

            key_file = tmpdir_path / "nonexistent.pem"
            env_file = tmpdir_path / "draft.json"
            env_file.write_text(json.dumps(draft_envelope_json))
            out_file = tmpdir_path / "signed.json"

            exit_code = main([
                "--key", str(key_file),
                "--envelope", str(env_file),
                "--out", str(out_file),
            ])

            assert exit_code == 3

    def test_nonexistent_envelope_file(
        self,
        ed25519_key_pem: bytes,
    ) -> None:
        """Nonexistent envelope file exits with code 3."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir_path = Path(tmpdir)

            key_file = tmpdir_path / "key.pem"
            key_file.write_bytes(ed25519_key_pem)

            env_file = tmpdir_path / "nonexistent.json"
            out_file = tmpdir_path / "signed.json"

            exit_code = main([
                "--key", str(key_file),
                "--envelope", str(env_file),
                "--out", str(out_file),
            ])

            assert exit_code == 3

    def test_invalid_json_in_envelope_file(
        self,
        ed25519_key_pem: bytes,
    ) -> None:
        """Invalid JSON in envelope file exits with code 4."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir_path = Path(tmpdir)

            key_file = tmpdir_path / "key.pem"
            key_file.write_bytes(ed25519_key_pem)

            env_file = tmpdir_path / "draft.json"
            env_file.write_text("{ invalid json }")

            out_file = tmpdir_path / "signed.json"

            exit_code = main([
                "--key", str(key_file),
                "--envelope", str(env_file),
                "--out", str(out_file),
            ])

            assert exit_code == 4

    def test_invalid_envelope_schema(
        self,
        ed25519_key_pem: bytes,
    ) -> None:
        """Invalid envelope schema exits with code 4."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir_path = Path(tmpdir)

            key_file = tmpdir_path / "key.pem"
            key_file.write_bytes(ed25519_key_pem)

            # Envelope with missing required fields
            env_file = tmpdir_path / "draft.json"
            env_file.write_text(json.dumps({"verdict": "VERIFIED"}))

            out_file = tmpdir_path / "signed.json"

            exit_code = main([
                "--key", str(key_file),
                "--envelope", str(env_file),
                "--out", str(out_file),
            ])

            assert exit_code == 4


class TestCLIInvalidPEM:
    """Tests for invalid PEM key errors."""

    def test_invalid_pem_key(
        self,
        draft_envelope_json: dict,
    ) -> None:
        """Invalid PEM key file exits with code 6."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir_path = Path(tmpdir)

            key_file = tmpdir_path / "key.pem"
            key_file.write_text("not a valid pem")

            env_file = tmpdir_path / "draft.json"
            env_file.write_text(json.dumps(draft_envelope_json))

            out_file = tmpdir_path / "signed.json"

            exit_code = main([
                "--key", str(key_file),
                "--envelope", str(env_file),
                "--out", str(out_file),
            ])

            # Should fail during signing
            assert exit_code in (5, 6)
