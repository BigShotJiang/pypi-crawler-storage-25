"""Tests for W3C PROV-O JSON-LD graph building."""
from __future__ import annotations

import json
from datetime import UTC, datetime

from gtv.models import Claim, Domain, Evidence, Stance, Verdict, VerdictRecord
from gtv.prov import build_prov_graph


def test_minimal_graph_has_activity_claim_verdict() -> None:
    """Build a graph with zero evidence; assert three core nodes exist."""
    claim = Claim(text="Test claim", domain=Domain.PHYSICS)
    verdict_record = VerdictRecord(
        claim_id=claim.claim_id,
        decision=Verdict.VERIFIED,
        confidence=0.95,
        evidence_refs=[],
        rationale="Test verdict.",
    )
    issued_at = datetime(2026, 4, 21, 12, 0, 0, tzinfo=UTC)

    graph_json = build_prov_graph(
        claim=claim,
        evidence=[],
        verdict_record=verdict_record,
        issuer_did="did:web:test",
        issued_at=issued_at,
    )

    # Parse the returned JSON.
    doc = json.loads(graph_json)

    # Check structure.
    assert "@context" in doc
    assert "@graph" in doc
    assert isinstance(doc["@graph"], list)

    # Extract nodes by @id.
    nodes_by_id = {node["@id"]: node for node in doc["@graph"]}

    # Verify three core nodes exist.
    assert f"gtv:verify-{verdict_record.verdict_id}" in nodes_by_id
    assert f"gtv:claim-{claim.claim_id}" in nodes_by_id
    assert f"gtv:verdict-{verdict_record.verdict_id}" in nodes_by_id

    # Verify node types.
    activity = nodes_by_id[f"gtv:verify-{verdict_record.verdict_id}"]
    claim_node = nodes_by_id[f"gtv:claim-{claim.claim_id}"]
    verdict_node = nodes_by_id[f"gtv:verdict-{verdict_record.verdict_id}"]

    assert activity["@type"] == "prov:Activity"
    assert claim_node["@type"] == "prov:Entity"
    assert verdict_node["@type"] == "prov:Entity"


def test_graph_includes_every_evidence() -> None:
    """3 evidence items => 3 gtv:evidence-* entities; each in prov:used and prov:wasDerivedFrom."""
    claim = Claim(text="Test claim", domain=Domain.CS)
    evidence_list = [
        Evidence(
            claim_id=claim.claim_id,
            source_did="did:web:source1",
            source_version="1.0",
            stance=Stance.SUPPORTS,
            excerpt="Supporting excerpt 1",
            url="https://example.com/1",
            retrieved_at=datetime(2026, 4, 20, tzinfo=UTC),
            raw_hash="a" * 64,
        ),
        Evidence(
            claim_id=claim.claim_id,
            source_did="did:web:source2",
            source_version="1.0",
            stance=Stance.SUPPORTS,
            excerpt="Supporting excerpt 2",
            url="https://example.com/2",
            retrieved_at=datetime(2026, 4, 20, tzinfo=UTC),
            raw_hash="b" * 64,
        ),
        Evidence(
            claim_id=claim.claim_id,
            source_did="did:web:source3",
            source_version="1.0",
            stance=Stance.REFUTES,
            excerpt="Refuting excerpt",
            url="https://example.com/3",
            retrieved_at=datetime(2026, 4, 20, tzinfo=UTC),
            raw_hash="c" * 64,
        ),
    ]

    verdict_record = VerdictRecord(
        claim_id=claim.claim_id,
        decision=Verdict.CONTESTED,
        confidence=0.65,
        evidence_refs=[e.evidence_id for e in evidence_list],
        rationale="Multiple sources with conflicting stances.",
    )
    issued_at = datetime(2026, 4, 21, 12, 0, 0, tzinfo=UTC)

    graph_json = build_prov_graph(
        claim=claim,
        evidence=evidence_list,
        verdict_record=verdict_record,
        issuer_did="did:web:test",
        issued_at=issued_at,
    )

    doc = json.loads(graph_json)
    nodes_by_id = {node["@id"]: node for node in doc["@graph"]}

    # Extract evidence node IDs.
    evidence_ids = {f"gtv:evidence-{ev.evidence_id}" for ev in evidence_list}

    # All three evidence entities must exist.
    for ev_id in evidence_ids:
        assert ev_id in nodes_by_id, f"Evidence node {ev_id} not found in graph"

    # Activity node must use all evidence.
    activity_id = f"gtv:verify-{verdict_record.verdict_id}"
    activity = nodes_by_id[activity_id]
    activity_used = set(activity.get("prov:used", []))
    assert activity_used == evidence_ids, f"Activity prov:used mismatch: {activity_used} != {evidence_ids}"

    # Verdict node must derive from all evidence.
    verdict_id = f"gtv:verdict-{verdict_record.verdict_id}"
    verdict = nodes_by_id[verdict_id]
    verdict_derived = set(verdict.get("prov:wasDerivedFrom", []))
    assert verdict_derived == evidence_ids, f"Verdict prov:wasDerivedFrom mismatch: {verdict_derived} != {evidence_ids}"


def test_graph_is_deterministic() -> None:
    """Build the same graph twice; assert string equality (requires sort_keys)."""
    claim = Claim(text="Determinism test", domain=Domain.MATH)
    evidence_list = [
        Evidence(
            claim_id=claim.claim_id,
            source_did="did:web:source",
            source_version="1.0",
            stance=Stance.SUPPORTS,
            excerpt="Test excerpt",
            url="https://example.com/test",
            retrieved_at=datetime(2026, 4, 20, tzinfo=UTC),
            raw_hash="d" * 64,
        ),
    ]

    verdict_record = VerdictRecord(
        claim_id=claim.claim_id,
        decision=Verdict.VERIFIED,
        confidence=0.85,
        evidence_refs=[e.evidence_id for e in evidence_list],
        rationale="Deterministic test verdict.",
    )
    issued_at = datetime(2026, 4, 21, 12, 0, 0, tzinfo=UTC)

    # Build graph twice with identical inputs.
    graph1 = build_prov_graph(
        claim=claim,
        evidence=evidence_list,
        verdict_record=verdict_record,
        issuer_did="did:web:test",
        issued_at=issued_at,
    )
    graph2 = build_prov_graph(
        claim=claim,
        evidence=evidence_list,
        verdict_record=verdict_record,
        issuer_did="did:web:test",
        issued_at=issued_at,
    )

    # Graphs must be byte-identical.
    assert graph1 == graph2, "Graph output is not deterministic"


def test_graph_is_valid_json_ld() -> None:
    """Assert the result parses as JSON, has @context and @graph."""
    claim = Claim(text="JSON-LD test", domain=Domain.GENERAL)
    verdict_record = VerdictRecord(
        claim_id=claim.claim_id,
        decision=Verdict.UNVERIFIED,
        confidence=0.1,
        evidence_refs=[],
        rationale="No evidence.",
    )
    issued_at = datetime(2026, 4, 21, 12, 0, 0, tzinfo=UTC)

    graph_json = build_prov_graph(
        claim=claim,
        evidence=[],
        verdict_record=verdict_record,
        issuer_did="did:web:test",
        issued_at=issued_at,
    )

    # Must parse as valid JSON.
    doc = json.loads(graph_json)

    # Must have @context with prov and gtv prefixes.
    assert "@context" in doc
    context = doc["@context"]
    assert "prov" in context
    assert "gtv" in context
    assert context["prov"] == "https://www.w3.org/ns/prov#"
    assert context["gtv"] == "https://groundtruth.example/vocab/"

    # Must have @graph list.
    assert "@graph" in doc
    assert isinstance(doc["@graph"], list)
    assert len(doc["@graph"]) >= 3  # Activity, claim, verdict.
