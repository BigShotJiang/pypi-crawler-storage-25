"""Tests for API key authentication and rate limiting middleware."""
from __future__ import annotations

from fastapi import FastAPI
from fastapi.testclient import TestClient

from gtv.mcp.auth import APIKeyAuthMiddleware, RateLimiter, install_auth


class TestRateLimiter:
    """Test the sliding-window rate limiter."""

    def test_rate_limiter_allows_up_to_limit(self) -> None:
        """Test that requests up to limit are allowed."""
        limiter = RateLimiter(limit_per_minute=3)

        # First 3 requests should be allowed
        assert limiter.check("key1")[0] is True
        assert limiter.check("key1")[0] is True
        assert limiter.check("key1")[0] is True

    def test_rate_limiter_blocks_over_limit(self) -> None:
        """Test that requests over limit are blocked."""
        limiter = RateLimiter(limit_per_minute=2)

        allowed1, _ = limiter.check("key1")
        allowed2, _ = limiter.check("key1")
        allowed3, _ = limiter.check("key1")

        assert allowed1 is True
        assert allowed2 is True
        assert allowed3 is False

    def test_rate_limiter_tracks_remaining(self) -> None:
        """Test that remaining count is accurate."""
        limiter = RateLimiter(limit_per_minute=3)

        _, remaining = limiter.check("key1")
        assert remaining == 2

        _, remaining = limiter.check("key1")
        assert remaining == 1

        _, remaining = limiter.check("key1")
        assert remaining == 0

    def test_rate_limiter_per_key_isolation(self) -> None:
        """Test that different keys have independent limits."""
        limiter = RateLimiter(limit_per_minute=2)

        # Exhaust key1
        limiter.check("key1")
        limiter.check("key1")
        allowed_k1, _ = limiter.check("key1")
        assert allowed_k1 is False

        # key2 should still be allowed
        allowed_k2, _ = limiter.check("key2")
        assert allowed_k2 is True

    def test_rate_limiter_window_resets_after_60s(self) -> None:
        """Test that the sliding window resets old entries."""
        limiter = RateLimiter(limit_per_minute=2)

        # Fill the window
        limiter.check("key1")
        limiter.check("key1")

        # Next request is blocked
        allowed, _ = limiter.check("key1")
        assert allowed is False

        # Manually advance time by modifying the deque
        # We'll mock time to avoid actual sleep
        if "key1" in limiter.counters:
            # Remove the first timestamp (make it "old")
            old_deque = limiter.counters["key1"]
            if old_deque:
                # Replace first entry with time far in the past
                first_ts = old_deque[0]
                old_deque[0] = first_ts - 70  # 70 seconds ago

        # Now next request should be allowed
        allowed, _ = limiter.check("key1")
        assert allowed is True


class TestAPIKeyAuthMiddleware:
    """Test the API key auth middleware."""

    def test_auth_disabled_when_no_keys(self) -> None:
        """Test that requests pass through when auth is disabled."""
        app = FastAPI()

        @app.post("/test")
        async def test_endpoint() -> dict[str, str]:
            return {"status": "ok"}

        # Add middleware with no keys (auth disabled)
        app.add_middleware(APIKeyAuthMiddleware, api_keys=set())

        client = TestClient(app)
        response = client.post("/test")

        assert response.status_code == 200
        assert response.json()["status"] == "ok"

    def test_health_endpoint_always_unauthenticated(self) -> None:
        """Test that /health is never auth-gated."""
        app = FastAPI()

        @app.get("/health")
        async def health() -> dict[str, str]:
            return {"status": "ok"}

        # Add middleware with keys (auth enabled)
        app.add_middleware(APIKeyAuthMiddleware, api_keys={"valid-key"})

        client = TestClient(app)
        response = client.get("/health")

        assert response.status_code == 200
        assert response.json()["status"] == "ok"

    def test_metrics_endpoint_always_unauthenticated(self) -> None:
        """Test that /metrics is never auth-gated."""
        app = FastAPI()

        @app.get("/metrics")
        async def metrics() -> dict[str, str]:
            return {"metrics": "ok"}

        # Add middleware with keys (auth enabled)
        app.add_middleware(APIKeyAuthMiddleware, api_keys={"valid-key"})

        client = TestClient(app)
        response = client.get("/metrics")

        assert response.status_code == 200

    def test_missing_auth_header_returns_401(self) -> None:
        """Test that missing Authorization header returns 401."""
        app = FastAPI()

        @app.post("/protected")
        async def protected() -> dict[str, str]:
            return {"status": "ok"}

        app.add_middleware(APIKeyAuthMiddleware, api_keys={"valid-key"})

        client = TestClient(app)
        response = client.post("/protected")

        assert response.status_code == 401
        assert "Authorization" in response.headers.get("www-authenticate", "")

    def test_invalid_auth_header_format_returns_401(self) -> None:
        """Test that malformed Authorization header returns 401."""
        app = FastAPI()

        @app.post("/protected")
        async def protected() -> dict[str, str]:
            return {"status": "ok"}

        app.add_middleware(APIKeyAuthMiddleware, api_keys={"valid-key"})

        client = TestClient(app)
        response = client.post("/protected", headers={"Authorization": "Basic xyz"})

        assert response.status_code == 401

    def test_invalid_api_key_returns_401(self) -> None:
        """Test that invalid API key returns 401."""
        app = FastAPI()

        @app.post("/protected")
        async def protected() -> dict[str, str]:
            return {"status": "ok"}

        app.add_middleware(APIKeyAuthMiddleware, api_keys={"valid-key"})

        client = TestClient(app)
        response = client.post("/protected", headers={"Authorization": "Bearer invalid-key"})

        assert response.status_code == 401

    def test_valid_api_key_returns_200(self) -> None:
        """Test that valid API key allows request."""
        app = FastAPI()

        @app.post("/protected")
        async def protected() -> dict[str, str]:
            return {"status": "ok"}

        app.add_middleware(APIKeyAuthMiddleware, api_keys={"valid-key"})

        client = TestClient(app)
        response = client.post("/protected", headers={"Authorization": "Bearer valid-key"})

        assert response.status_code == 200
        assert response.json()["status"] == "ok"

    def test_rate_limit_exceeded_returns_429(self) -> None:
        """Test that rate limit exceeded returns 429 with Retry-After."""
        app = FastAPI()

        @app.post("/protected")
        async def protected() -> dict[str, str]:
            return {"status": "ok"}

        limiter = RateLimiter(limit_per_minute=2)
        app.add_middleware(APIKeyAuthMiddleware, api_keys={"valid-key"}, rate_limiter=limiter)

        client = TestClient(app)

        # First two requests should succeed
        response1 = client.post("/protected", headers={"Authorization": "Bearer valid-key"})
        assert response1.status_code == 200

        response2 = client.post("/protected", headers={"Authorization": "Bearer valid-key"})
        assert response2.status_code == 200

        # Third request should be rate-limited
        response3 = client.post("/protected", headers={"Authorization": "Bearer valid-key"})
        assert response3.status_code == 429
        assert "Retry-After" in response3.headers
        assert response3.headers["Retry-After"] == "60"

    def test_rate_limit_isolation_per_key(self) -> None:
        """Test that rate limits are isolated per key."""
        app = FastAPI()

        @app.post("/protected")
        async def protected() -> dict[str, str]:
            return {"status": "ok"}

        limiter = RateLimiter(limit_per_minute=1)
        app.add_middleware(
            APIKeyAuthMiddleware,
            api_keys={"key1", "key2"},
            rate_limiter=limiter,
        )

        client = TestClient(app)

        # Exhaust key1
        response1 = client.post("/protected", headers={"Authorization": "Bearer key1"})
        assert response1.status_code == 200

        response2 = client.post("/protected", headers={"Authorization": "Bearer key1"})
        assert response2.status_code == 429

        # key2 should still have allowance
        response3 = client.post("/protected", headers={"Authorization": "Bearer key2"})
        assert response3.status_code == 200

    def test_rate_limit_headers_present(self) -> None:
        """Test that rate limit headers are included in responses."""
        app = FastAPI()

        @app.post("/protected")
        async def protected() -> dict[str, str]:
            return {"status": "ok"}

        limiter = RateLimiter(limit_per_minute=5)
        app.add_middleware(APIKeyAuthMiddleware, api_keys={"valid-key"}, rate_limiter=limiter)

        client = TestClient(app)
        response = client.post("/protected", headers={"Authorization": "Bearer valid-key"})

        assert response.status_code == 200
        assert "X-RateLimit-Remaining" in response.headers
        assert "X-RateLimit-Limit" in response.headers
        assert response.headers["X-RateLimit-Limit"] == "5"


class TestInstallAuthFunction:
    """Test the install_auth setup function."""

    def test_install_auth_with_env_vars(self, monkeypatch) -> None:
        """Test that install_auth reads env vars correctly."""
        monkeypatch.setenv("GTV_API_KEYS", "key1,key2,key3")
        monkeypatch.setenv("GTV_RATE_LIMIT_PER_MINUTE", "100")

        app = FastAPI()

        @app.post("/protected")
        async def protected() -> dict[str, str]:
            return {"status": "ok"}

        install_auth(app)

        client = TestClient(app)

        # Valid key should work
        response = client.post("/protected", headers={"Authorization": "Bearer key1"})
        assert response.status_code == 200

        # Invalid key should fail
        response = client.post("/protected", headers={"Authorization": "Bearer invalid"})
        assert response.status_code == 401

    def test_install_auth_disabled_when_unset(self, monkeypatch) -> None:
        """Test that auth is disabled when GTV_API_KEYS is unset."""
        monkeypatch.delenv("GTV_API_KEYS", raising=False)

        app = FastAPI()

        @app.post("/protected")
        async def protected() -> dict[str, str]:
            return {"status": "ok"}

        install_auth(app)

        client = TestClient(app)

        # Request without auth should succeed
        response = client.post("/protected")
        assert response.status_code == 200

    def test_install_auth_default_rate_limit(self, monkeypatch) -> None:
        """Test that default rate limit is 60 when not set."""
        monkeypatch.setenv("GTV_API_KEYS", "key1")
        monkeypatch.delenv("GTV_RATE_LIMIT_PER_MINUTE", raising=False)

        app = FastAPI()

        @app.post("/protected")
        async def protected() -> dict[str, str]:
            return {"status": "ok"}

        install_auth(app)

        client = TestClient(app)

        # The default should be 60; we'll make 61 requests and the 61st should fail.
        # For this test, we'll just verify the middleware was added correctly
        response = client.post("/protected", headers={"Authorization": "Bearer key1"})
        assert response.status_code == 200
        assert "X-RateLimit-Limit" in response.headers
        assert response.headers["X-RateLimit-Limit"] == "60"
