"""Tests for SQLite-backed subscription store."""
from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path

import pytest

from gtv.subscribe import Subscription
from gtv.subscribe.store import SubscriptionStore


@pytest.fixture
def tmp_db(tmp_path: Path) -> Path:
    """Return a temp DB path."""
    return tmp_path / "subscriptions.db"


def test_add_subscription(tmp_db: Path) -> None:
    """Test adding a subscription to the store."""
    store = SubscriptionStore(tmp_db)
    sub = Subscription(
        id="id1",
        claim="The sky is blue",
        webhook_url="https://example.com/webhook",
        interval_s=600,
    )
    store.add(sub)
    store.close()

    # Reopen and verify
    store2 = SubscriptionStore(tmp_db)
    retrieved = store2.get("id1")
    store2.close()

    assert retrieved is not None
    assert retrieved.id == "id1"
    assert retrieved.claim == "The sky is blue"
    assert retrieved.webhook_url == "https://example.com/webhook"
    assert retrieved.interval_s == 600


def test_persistence_across_reopen(tmp_db: Path) -> None:
    """Test that subscriptions persist across store re-opens."""
    # Create and add
    store1 = SubscriptionStore(tmp_db)
    sub = Subscription(
        id="persistent_id",
        claim="A persistent claim",
        webhook_url="https://example.com/hook",
        interval_s=1800,
    )
    store1.add(sub)
    store1.close()

    # Reopen and verify
    store2 = SubscriptionStore(tmp_db)
    all_subs = store2.list_all()
    store2.close()

    assert len(all_subs) == 1
    assert all_subs[0].id == "persistent_id"
    assert all_subs[0].claim == "A persistent claim"


def test_remove_subscription(tmp_db: Path) -> None:
    """Test removing a subscription."""
    store = SubscriptionStore(tmp_db)
    sub = Subscription(id="to_remove", claim="claim", webhook_url="url", interval_s=600)
    store.add(sub)

    # Remove
    found = store.remove("to_remove")
    assert found is True

    # Verify gone
    retrieved = store.get("to_remove")
    assert retrieved is None
    store.close()


def test_remove_nonexistent(tmp_db: Path) -> None:
    """Test removing a nonexistent subscription returns False."""
    store = SubscriptionStore(tmp_db)
    found = store.remove("nonexistent")
    assert found is False
    store.close()


def test_list_all_empty(tmp_db: Path) -> None:
    """Test listing from an empty store."""
    store = SubscriptionStore(tmp_db)
    subs = store.list_all()
    store.close()
    assert subs == []


def test_list_all_multiple(tmp_db: Path) -> None:
    """Test listing multiple subscriptions."""
    store = SubscriptionStore(tmp_db)
    sub1 = Subscription(id="id1", claim="claim1", webhook_url="url1", interval_s=600)
    sub2 = Subscription(id="id2", claim="claim2", webhook_url="url2", interval_s=3600)
    store.add(sub1)
    store.add(sub2)

    subs = store.list_all()
    store.close()

    assert len(subs) == 2
    assert any(s.id == "id1" for s in subs)
    assert any(s.id == "id2" for s in subs)


def test_update_verdict(tmp_db: Path) -> None:
    """Test updating verdict and last_checked_at."""
    store = SubscriptionStore(tmp_db)
    sub = Subscription(id="id1", claim="claim", webhook_url="url", interval_s=600)
    store.add(sub)

    # Update verdict
    now_iso = datetime.now(UTC).isoformat()
    found = store.update_verdict("id1", "VERIFIED", now_iso)
    assert found is True

    # Retrieve and verify
    retrieved = store.get("id1")
    assert retrieved is not None
    assert retrieved.last_verdict == "VERIFIED"
    assert retrieved.last_checked_at is not None
    store.close()


def test_update_verdict_nonexistent(tmp_db: Path) -> None:
    """Test updating verdict for nonexistent subscription returns False."""
    store = SubscriptionStore(tmp_db)
    found = store.update_verdict("nonexistent", "VERIFIED", "2024-01-01T00:00:00+00:00")
    assert found is False
    store.close()


def test_add_updates_existing(tmp_db: Path) -> None:
    """Test that add with same id updates the subscription."""
    store = SubscriptionStore(tmp_db)
    sub1 = Subscription(id="id1", claim="original", webhook_url="url1", interval_s=600)
    store.add(sub1)

    # Update with same id
    sub2 = Subscription(id="id1", claim="updated", webhook_url="url2", interval_s=1200)
    store.add(sub2)

    # Verify updated
    retrieved = store.get("id1")
    assert retrieved is not None
    assert retrieved.claim == "updated"
    assert retrieved.webhook_url == "url2"
    assert retrieved.interval_s == 1200
    store.close()


def test_verdict_with_datetime_roundtrip(tmp_db: Path) -> None:
    """Test that datetime is properly serialized and deserialized."""
    store = SubscriptionStore(tmp_db)
    now = datetime.now(UTC)
    sub = Subscription(
        id="id1",
        claim="claim",
        webhook_url="url",
        interval_s=600,
        last_verdict="VERIFIED",
        last_checked_at=now,
    )
    store.add(sub)

    retrieved = store.get("id1")
    store.close()

    assert retrieved is not None
    assert retrieved.last_checked_at is not None
    # Compare with tolerance for ISO round-trip precision
    time_diff = abs((retrieved.last_checked_at - now).total_seconds())
    assert time_diff < 1.0  # Less than 1 second difference
