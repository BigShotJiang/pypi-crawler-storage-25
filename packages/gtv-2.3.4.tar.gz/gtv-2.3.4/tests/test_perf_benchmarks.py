"""Performance benchmarks for hot paths.

Opt-in: runs only when `GTV_PERF=1` is set in the environment.

Measures microsecond-to-millisecond latency on the paths that dominate
envelope issuance throughput: canonicalization, verdict engine, and the
end-to-end stub-mode HTTP verify.

This file uses plain `time.perf_counter()` instead of `pytest-benchmark`
to keep the dev-dep surface tight — no new third-party package, no CI
config drift. The trade-off is coarser statistics; for a proper A/B
you'd add pytest-benchmark, but that's a separate decision.

Targets (stub mode, single worker, CPython 3.12, modern x86_64/arm64):

| Operation                         | p50 target | p99 target |
|-----------------------------------|-----------:|-----------:|
| envelope_canonical_sha256         |   <  100µs |   <  500µs |
| verdict.decide (5 evidence items) |   <   50µs |   <  250µs |
| POST /tools/verify_claim (stub)   |   <   25ms |   <  100ms |

Targets are documented in docs/deployment.md alongside the SLOs.
"""
from __future__ import annotations

import hashlib
import importlib
import os
import statistics
import time
from collections.abc import Callable
from datetime import UTC, datetime

import pytest
from fastapi.testclient import TestClient
from pydantic import HttpUrl

from gtv.adapters.base import HealthStatus, RawSnapshot, SourceAdapter
from gtv.anchor.canonicalize import envelope_canonical_sha256
from gtv.models import (
    AnchorProof,
    Claim,
    Domain,
    Envelope,
    Evidence,
    SourceType,
    Stance,
    TrustTier,
    Verdict,
)
from gtv.verdict.engine import VerdictInputs, decide

pytestmark = [
    pytest.mark.perf,
    pytest.mark.skipif(
        os.environ.get("GTV_PERF") != "1",
        reason="Perf suite is opt-in. Set GTV_PERF=1 to run.",
    ),
]


# ---------------------------------------------------------------------------
# Measurement helper
# ---------------------------------------------------------------------------

def _bench(fn: Callable[[], None], *, iters: int = 1_000, warmup: int = 50) -> dict[str, float]:
    """Time `fn` `iters` times after `warmup` iterations. Return p50/p95/p99 (seconds)."""
    for _ in range(warmup):
        fn()
    samples: list[float] = []
    for _ in range(iters):
        t0 = time.perf_counter()
        fn()
        samples.append(time.perf_counter() - t0)
    samples.sort()
    return {
        "p50": statistics.median(samples),
        "p95": samples[int(0.95 * iters)],
        "p99": samples[int(0.99 * iters)],
        "mean": statistics.fmean(samples),
        "min": samples[0],
        "max": samples[-1],
    }


def _fmt_us(secs: float) -> str:
    return f"{secs * 1e6:,.1f}µs"


def _fmt_ms(secs: float) -> str:
    return f"{secs * 1e3:,.2f}ms"


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

def _evidence(i: int) -> Evidence:
    return Evidence(
        claim_id="11111111-1111-1111-1111-111111111111",
        source_did=f"did:web:src{i}.example",
        source_version="v1",
        stance=Stance.SUPPORTS,
        excerpt="A measured result from a controlled experiment.",
        url=HttpUrl(f"https://example.invalid/paper{i}"),
        retrieved_at=datetime.now(tz=UTC),
        raw_hash=hashlib.sha256(f"paper{i}".encode()).hexdigest(),
    )


def _envelope(n_evidence: int = 5) -> Envelope:
    return Envelope(
        verdict=Verdict.VERIFIED,
        confidence=0.9,
        evidence=[_evidence(i) for i in range(n_evidence)],
        rationale="perf-bench",
        issuer_did="did:web:perf.example",
        signature="AAAA",
        rekor_uuid="rekor-perf",
        rekor_log_index=0,
        tsa_token="AAAA",
        prov_graph="",
        anchor_proof=AnchorProof(
            rekor_inclusion_proof="{}",
            tsa_tsr_primary="AAAA",
        ),
    )


# ---------------------------------------------------------------------------
# Benchmarks
# ---------------------------------------------------------------------------

def test_perf_canonical_hash() -> None:
    """RFC 8785 JCS canonicalization + SHA-256 of a 5-evidence envelope."""
    env = _envelope(n_evidence=5)
    stats = _bench(lambda: envelope_canonical_sha256(env))
    print(
        f"\n[perf] canonical_hash(5 evidence): "
        f"p50={_fmt_us(stats['p50'])} p95={_fmt_us(stats['p95'])} "
        f"p99={_fmt_us(stats['p99'])} mean={_fmt_us(stats['mean'])}"
    )
    # Regression guard — allow 2 ms p99 to tolerate slow CI VMs.
    assert stats["p99"] < 2e-3, f"p99 {_fmt_us(stats['p99'])} exceeds 2ms budget"


def test_perf_verdict_decide() -> None:
    """Deterministic verdict engine — should be pure-Python arithmetic."""
    claim = Claim(text="A physics claim.", domain=Domain.PHYSICS)
    evidence = [_evidence(i) for i in range(5)]
    tier_of = {e.source_did: TrustTier.TIER_1 for e in evidence}
    inputs = VerdictInputs(claim=claim, evidence=evidence, tier_of=tier_of)

    stats = _bench(lambda: decide(inputs))
    print(
        f"\n[perf] verdict.decide(5 evidence): "
        f"p50={_fmt_us(stats['p50'])} p95={_fmt_us(stats['p95'])} "
        f"p99={_fmt_us(stats['p99'])} mean={_fmt_us(stats['mean'])}"
    )
    # Regression guard
    assert stats["p99"] < 1e-3, f"p99 {_fmt_us(stats['p99'])} exceeds 1ms budget"


class _PerfStubAdapter(SourceAdapter):
    """In-process, zero-latency adapter used by the endpoint benchmark.

    Default adapters hit real HTTP (arxiv, crossref, NIST, ...). That makes
    the bench measure upstream network latency instead of our pipeline.
    This stub returns one deterministic evidence item synchronously so the
    benchmark isolates FastAPI routing + pydantic + canonicalize + seal.
    """

    def __init__(self) -> None:
        self.source_did = "did:web:perf-stub.example"
        self.name = "PerfStub"
        self.type = SourceType.REFERENCE_DATA
        self.trust_tier = TrustTier.TIER_1
        self.freshness_sla_s = 86400
        self.last_audit = datetime.now(tz=UTC)

    async def query(self, claim: Claim, max_items: int = 5) -> list[Evidence]:
        return [
            Evidence(
                claim_id=claim.claim_id,
                source_did=self.source_did,
                source_version="v1",
                stance=Stance.SUPPORTS,
                excerpt="Deterministic stub evidence for perf benchmark.",
                url=HttpUrl("https://example.invalid/perf-stub"),
                retrieved_at=datetime.now(tz=UTC),
                raw_hash=hashlib.sha256(b"perf-stub").hexdigest(),
            )
        ]

    async def snapshot(self, url: str) -> RawSnapshot:
        return RawSnapshot(
            url=url,
            mime_type="text/plain",
            size_bytes=8,
            body=b"stubbody",
            sha256_hex=hashlib.sha256(b"stubbody").hexdigest(),
        )

    async def health(self) -> HealthStatus:
        return HealthStatus.HEALTHY

    async def close(self) -> None:
        return None


def test_perf_verify_claim_endpoint_stub(monkeypatch: pytest.MonkeyPatch) -> None:
    """End-to-end POST /tools/verify_claim in stub mode.

    Stub mode short-circuits Sigstore/Rekor/TSA, so this measures the
    pipeline overhead: adapter fan-out (one in-process stub), verdict
    engine, canonicalization, envelope sealing. Crucially, no real HTTP.
    """
    for var in ("GTV_SIGSTORE_ENABLED", "GTV_TSA_ENABLED", "GTV_LIVE"):
        monkeypatch.delenv(var, raising=False)
    # Prevent default adapters from loading when we reload the adapters pkg.
    monkeypatch.setenv("GTV_DISABLE_DEFAULT_ADAPTERS", "1")

    import gtv.adapters as adapters_mod
    importlib.reload(adapters_mod)
    import gtv.mcp.server as server_mod
    importlib.reload(server_mod)
    # Register our stub after reload so REGISTRY has exactly one adapter.
    adapters_mod.register(_PerfStubAdapter())

    client = TestClient(server_mod.app)

    body = {
        "claim": "The speed of light in vacuum is 299,792,458 m/s.",
        "domain": "physics",
        "max_sources": 3,
    }

    def _call() -> None:
        resp = client.post("/tools/verify_claim", json=body)
        assert resp.status_code == 200

    try:
        # Fewer iters — each call does real FastAPI routing + pydantic validation.
        stats = _bench(_call, iters=100, warmup=10)
    finally:
        adapters_mod.REGISTRY.clear()

    print(
        f"\n[perf] POST /tools/verify_claim (stub): "
        f"p50={_fmt_ms(stats['p50'])} p95={_fmt_ms(stats['p95'])} "
        f"p99={_fmt_ms(stats['p99'])} mean={_fmt_ms(stats['mean'])}"
    )
    # Regression guard — 500ms p99 tolerates slow CI runners.
    assert stats["p99"] < 0.5, f"p99 {_fmt_ms(stats['p99'])} exceeds 500ms budget"
