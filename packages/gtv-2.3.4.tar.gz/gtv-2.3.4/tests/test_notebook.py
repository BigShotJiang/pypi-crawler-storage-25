"""Guardrail test: execute the getting-started notebook end-to-end.

Runs every cell of ``notebooks/getting_started.ipynb`` via ``nbclient``.
If any cell raises, the test fails. This is the only thing standing
between an API change and a bitrotted tutorial.

The test is gated on ``nbclient`` and ``nbformat`` being importable. Both
are listed under the ``dev`` extra, so they're present in CI but we skip
cleanly if a contributor is running a leaner install.
"""
from __future__ import annotations

from pathlib import Path

import pytest

nbformat = pytest.importorskip("nbformat")
nbclient_mod = pytest.importorskip("nbclient")

NOTEBOOK_PATH = Path(__file__).resolve().parent.parent / "notebooks" / "getting_started.ipynb"


def test_notebook_exists_and_is_valid_ipynb() -> None:
    """Fast fail if the file is missing or not a valid v4 notebook."""
    assert NOTEBOOK_PATH.exists(), f"missing notebook: {NOTEBOOK_PATH}"
    nb = nbformat.read(str(NOTEBOOK_PATH), as_version=4)
    nbformat.validate(nb)


def test_every_code_cell_compiles() -> None:
    """Syntax-check every code cell. Catches typos without executing."""
    nb = nbformat.read(str(NOTEBOOK_PATH), as_version=4)
    for i, cell in enumerate(nb.cells):
        if cell.cell_type != "code":
            continue
        src = cell.source
        try:
            compile(src, f"notebook-cell-{i}", "exec")
        except SyntaxError as e:
            pytest.fail(f"cell {i} has a syntax error: {e}\n--- source ---\n{src}")


def test_notebook_executes_end_to_end(tmp_path: Path) -> None:
    """Run the notebook top to bottom. Any cell raising = test fails.

    A per-cell 60 s timeout keeps a hang from stalling CI.
    """
    from nbclient import NotebookClient

    nb = nbformat.read(str(NOTEBOOK_PATH), as_version=4)
    client = NotebookClient(
        nb,
        timeout=60,
        kernel_name="python3",
        resources={"metadata": {"path": str(tmp_path)}},
        allow_errors=False,
    )
    client.execute()
