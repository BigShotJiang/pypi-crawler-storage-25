"""Tests for attachment store backends."""

from __future__ import annotations

from pathlib import Path
from typing import Any
from unittest.mock import MagicMock

import pytest

from gtv.attachments import (
    LocalFileAttachmentStore,
    S3AttachmentStore,
    compute_digest,
    make_attachment_store_from_env,
)


class FakeS3Client:
    """Mock S3 client for testing without boto3."""

    def __init__(self) -> None:
        self._objects: dict[str, bytes] = {}

    def put_object(
        self,
        Bucket: str,  # noqa: N803
        Key: str,  # noqa: N803
        Body: bytes,  # noqa: N803
        ContentType: str | None = None,  # noqa: N803
    ) -> None:
        self._objects[Key] = Body

    def get_object(
        self, Bucket: str, Key: str  # noqa: N803
    ) -> dict[str, Any]:
        if Key not in self._objects:
            raise Exception("NoSuchKey: key not found")
        # Return a dict with a 'Body' object that has a read() method
        body = MagicMock()
        body.read = lambda: self._objects[Key]
        return {"Body": body}

    def head_object(
        self, Bucket: str, Key: str  # noqa: N803
    ) -> dict[str, Any]:
        if Key not in self._objects:
            raise Exception("NotFound: 404")
        return {"ContentLength": len(self._objects[Key])}

    def delete_object(
        self, Bucket: str, Key: str  # noqa: N803
    ) -> None:
        self._objects.pop(Key, None)

    def generate_presigned_url(
        self,
        method: str,
        Params: dict[str, str],  # noqa: N803
        ExpiresIn: int,  # noqa: N803
    ) -> str:
        return f"https://s3.amazonaws.com/{Params['Bucket']}/{Params['Key']}?expires={ExpiresIn}"


# ============================================================================
# Tests for compute_digest
# ============================================================================


def test_compute_digest_sha256_hex() -> None:
    """compute_digest returns sha256 hex."""
    content = b"hello world"
    digest = compute_digest(content)
    assert digest == "b94d27b9934d3e08a52e52d7da7dabfac484efe37a5380ee9088f7ace2efcde9"
    assert len(digest) == 64
    assert all(c in "0123456789abcdef" for c in digest)


def test_compute_digest_empty() -> None:
    """compute_digest handles empty bytes."""
    digest = compute_digest(b"")
    assert len(digest) == 64
    # sha256 of empty string
    assert (
        digest
        == "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    )


def test_compute_digest_deterministic() -> None:
    """compute_digest is deterministic."""
    content = b"test content"
    assert compute_digest(content) == compute_digest(content)


# ============================================================================
# Tests for LocalFileAttachmentStore
# ============================================================================


@pytest.mark.asyncio
async def test_local_put_stores_and_returns_digest(tmp_path: Path) -> None:
    """LocalFileAttachmentStore.put stores content and returns digest."""
    store = LocalFileAttachmentStore(str(tmp_path))
    content = b"test content"

    digest = await store.put(content, "text/plain")

    assert digest == compute_digest(content)
    assert len(digest) == 64


@pytest.mark.asyncio
async def test_local_put_creates_directory_structure(tmp_path: Path) -> None:
    """LocalFileAttachmentStore.put creates <first-2>/<rest> structure."""
    store = LocalFileAttachmentStore(str(tmp_path))
    content = b"test"
    digest = await store.put(content, "text/plain")

    expected_path = tmp_path / digest[:2] / digest[2:]
    assert expected_path.exists()
    assert expected_path.read_bytes() == content


@pytest.mark.asyncio
async def test_local_get_returns_content(tmp_path: Path) -> None:
    """LocalFileAttachmentStore.get returns stored content."""
    store = LocalFileAttachmentStore(str(tmp_path))
    content = b"test content"
    digest = await store.put(content, "text/plain")

    retrieved = await store.get(digest)
    assert retrieved == content


@pytest.mark.asyncio
async def test_local_get_missing_raises_keyerror(tmp_path: Path) -> None:
    """LocalFileAttachmentStore.get raises KeyError for missing digest."""
    store = LocalFileAttachmentStore(str(tmp_path))
    fake_digest = "a" * 64

    with pytest.raises(KeyError, match="a" * 64):
        await store.get(fake_digest)


@pytest.mark.asyncio
async def test_local_exists_true(tmp_path: Path) -> None:
    """LocalFileAttachmentStore.exists returns True for stored digest."""
    store = LocalFileAttachmentStore(str(tmp_path))
    content = b"test"
    digest = await store.put(content, "text/plain")

    assert await store.exists(digest) is True


@pytest.mark.asyncio
async def test_local_exists_false(tmp_path: Path) -> None:
    """LocalFileAttachmentStore.exists returns False for missing digest."""
    store = LocalFileAttachmentStore(str(tmp_path))
    fake_digest = "b" * 64

    assert await store.exists(fake_digest) is False


@pytest.mark.asyncio
async def test_local_delete_removes_file(tmp_path: Path) -> None:
    """LocalFileAttachmentStore.delete removes stored file."""
    store = LocalFileAttachmentStore(str(tmp_path))
    content = b"test"
    digest = await store.put(content, "text/plain")

    await store.delete(digest)

    assert await store.exists(digest) is False


@pytest.mark.asyncio
async def test_local_delete_missing_does_not_raise(tmp_path: Path) -> None:
    """LocalFileAttachmentStore.delete handles missing digest gracefully."""
    store = LocalFileAttachmentStore(str(tmp_path))
    fake_digest = "c" * 64

    # Should not raise
    await store.delete(fake_digest)


@pytest.mark.asyncio
async def test_local_url_for_returns_file_uri(tmp_path: Path) -> None:
    """LocalFileAttachmentStore.url_for returns file:// URL."""
    store = LocalFileAttachmentStore(str(tmp_path))
    content = b"test"
    digest = await store.put(content, "text/plain")

    url = await store.url_for(digest)

    assert url.startswith("file://")
    assert digest[:2] in url
    assert digest[2:] in url


@pytest.mark.asyncio
async def test_local_close_is_noop(tmp_path: Path) -> None:
    """LocalFileAttachmentStore.close is a no-op."""
    store = LocalFileAttachmentStore(str(tmp_path))

    # Should not raise
    await store.close()


# ============================================================================
# Tests for S3AttachmentStore
# ============================================================================


def test_s3_init_with_client_injection() -> None:
    """S3AttachmentStore accepts injected client."""
    fake_client = FakeS3Client()
    store = S3AttachmentStore(bucket="test-bucket", client=fake_client)

    assert store._client is fake_client


def test_s3_init_without_boto3_raises() -> None:
    """S3AttachmentStore raises if boto3 not installed and no client provided."""
    # Simulate boto3 not being available
    import sys

    boto3_module = sys.modules.pop("boto3", None)
    try:
        with pytest.raises(RuntimeError, match="pip install gtv\\[s3\\]"):
            S3AttachmentStore(bucket="test-bucket", client=None)
    finally:
        # Restore boto3 if it was there
        if boto3_module is not None:
            sys.modules["boto3"] = boto3_module


@pytest.mark.asyncio
async def test_s3_put_calls_put_object_and_returns_digest() -> None:
    """S3AttachmentStore.put calls put_object with correct key."""
    fake_client = FakeS3Client()
    store = S3AttachmentStore(bucket="test-bucket", client=fake_client)
    content = b"test content"

    digest = await store.put(content, "text/plain")

    assert digest == compute_digest(content)
    # Verify object was stored
    key = f"attachments/{digest[:2]}/{digest[2:]}"
    assert fake_client._objects[key] == content


@pytest.mark.asyncio
async def test_s3_put_uses_custom_prefix() -> None:
    """S3AttachmentStore.put respects custom prefix."""
    fake_client = FakeS3Client()
    store = S3AttachmentStore(
        bucket="test-bucket", client=fake_client, prefix="custom/"
    )
    content = b"test"

    digest = await store.put(content, "text/plain")

    key = f"custom/{digest[:2]}/{digest[2:]}"
    assert key in fake_client._objects


@pytest.mark.asyncio
async def test_s3_get_returns_content() -> None:
    """S3AttachmentStore.get retrieves content from S3."""
    fake_client = FakeS3Client()
    store = S3AttachmentStore(bucket="test-bucket", client=fake_client)
    content = b"test content"
    digest = await store.put(content, "text/plain")

    retrieved = await store.get(digest)

    assert retrieved == content


@pytest.mark.asyncio
async def test_s3_get_missing_raises_keyerror() -> None:
    """S3AttachmentStore.get raises KeyError for missing digest."""
    fake_client = FakeS3Client()
    store = S3AttachmentStore(bucket="test-bucket", client=fake_client)
    fake_digest = "a" * 64

    with pytest.raises(KeyError):
        await store.get(fake_digest)


@pytest.mark.asyncio
async def test_s3_exists_true() -> None:
    """S3AttachmentStore.exists returns True for stored digest."""
    fake_client = FakeS3Client()
    store = S3AttachmentStore(bucket="test-bucket", client=fake_client)
    content = b"test"
    digest = await store.put(content, "text/plain")

    assert await store.exists(digest) is True


@pytest.mark.asyncio
async def test_s3_exists_false() -> None:
    """S3AttachmentStore.exists returns False for missing digest."""
    fake_client = FakeS3Client()
    store = S3AttachmentStore(bucket="test-bucket", client=fake_client)
    fake_digest = "b" * 64

    assert await store.exists(fake_digest) is False


@pytest.mark.asyncio
async def test_s3_delete_removes_object() -> None:
    """S3AttachmentStore.delete removes object from S3."""
    fake_client = FakeS3Client()
    store = S3AttachmentStore(bucket="test-bucket", client=fake_client)
    content = b"test"
    digest = await store.put(content, "text/plain")

    await store.delete(digest)

    assert await store.exists(digest) is False


@pytest.mark.asyncio
async def test_s3_url_for_calls_generate_presigned_url() -> None:
    """S3AttachmentStore.url_for calls generate_presigned_url."""
    fake_client = FakeS3Client()
    store = S3AttachmentStore(bucket="test-bucket", client=fake_client)
    content = b"test"
    digest = await store.put(content, "text/plain")

    url = await store.url_for(digest, expires_in_s=7200)

    assert "test-bucket" in url
    assert digest[:2] in url
    assert digest[2:] in url
    assert "7200" in url


@pytest.mark.asyncio
async def test_s3_close_is_noop() -> None:
    """S3AttachmentStore.close is a no-op if client has no close."""
    fake_client = FakeS3Client()
    store = S3AttachmentStore(bucket="test-bucket", client=fake_client)

    # Should not raise
    await store.close()


# ============================================================================
# Tests for make_attachment_store_from_env
# ============================================================================


def test_make_from_env_unset_returns_none(monkeypatch: pytest.MonkeyPatch) -> None:
    """make_attachment_store_from_env returns None when GTV_ATTACHMENT_BACKEND unset."""
    monkeypatch.delenv("GTV_ATTACHMENT_BACKEND", raising=False)

    store = make_attachment_store_from_env()

    assert store is None


def test_make_from_env_local_backend(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """make_attachment_store_from_env creates LocalFileAttachmentStore."""
    monkeypatch.setenv("GTV_ATTACHMENT_BACKEND", "local")
    monkeypatch.setenv("GTV_ATTACHMENT_ROOT", str(tmp_path))

    store = make_attachment_store_from_env()

    assert isinstance(store, LocalFileAttachmentStore)


def test_make_from_env_local_missing_root_raises(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """make_attachment_store_from_env raises if local backend missing GTV_ATTACHMENT_ROOT."""
    monkeypatch.setenv("GTV_ATTACHMENT_BACKEND", "local")
    monkeypatch.delenv("GTV_ATTACHMENT_ROOT", raising=False)

    with pytest.raises(ValueError, match="GTV_ATTACHMENT_ROOT"):
        make_attachment_store_from_env()


def test_make_from_env_s3_backend(monkeypatch: pytest.MonkeyPatch) -> None:
    """make_attachment_store_from_env creates S3AttachmentStore."""
    monkeypatch.setenv("GTV_ATTACHMENT_BACKEND", "s3")
    monkeypatch.setenv("GTV_ATTACHMENT_BUCKET", "my-bucket")
    monkeypatch.setenv("GTV_ATTACHMENT_REGION", "eu-west-1")
    monkeypatch.setenv("GTV_ATTACHMENT_PREFIX", "data/")

    # Mock boto3 to avoid import error
    import sys

    mock_boto3 = MagicMock()
    sys.modules["boto3"] = mock_boto3

    try:
        store = make_attachment_store_from_env()
        assert isinstance(store, S3AttachmentStore)
        assert store._bucket == "my-bucket"
        assert store._region == "eu-west-1"
        assert store._prefix == "data/"
    finally:
        sys.modules.pop("boto3", None)


def test_make_from_env_s3_missing_bucket_raises(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """make_attachment_store_from_env raises if S3 backend missing GTV_ATTACHMENT_BUCKET."""
    monkeypatch.setenv("GTV_ATTACHMENT_BACKEND", "s3")
    monkeypatch.delenv("GTV_ATTACHMENT_BUCKET", raising=False)

    with pytest.raises(ValueError, match="GTV_ATTACHMENT_BUCKET"):
        make_attachment_store_from_env()


def test_make_from_env_s3_default_region(monkeypatch: pytest.MonkeyPatch) -> None:
    """make_attachment_store_from_env uses default region for S3."""
    monkeypatch.setenv("GTV_ATTACHMENT_BACKEND", "s3")
    monkeypatch.setenv("GTV_ATTACHMENT_BUCKET", "my-bucket")
    monkeypatch.delenv("GTV_ATTACHMENT_REGION", raising=False)

    import sys

    mock_boto3 = MagicMock()
    sys.modules["boto3"] = mock_boto3

    try:
        store = make_attachment_store_from_env()
        assert isinstance(store, S3AttachmentStore)
        assert store._region == "us-east-1"
    finally:
        sys.modules.pop("boto3", None)


def test_make_from_env_s3_default_prefix(monkeypatch: pytest.MonkeyPatch) -> None:
    """make_attachment_store_from_env uses default prefix for S3."""
    monkeypatch.setenv("GTV_ATTACHMENT_BACKEND", "s3")
    monkeypatch.setenv("GTV_ATTACHMENT_BUCKET", "my-bucket")
    monkeypatch.delenv("GTV_ATTACHMENT_PREFIX", raising=False)

    import sys

    mock_boto3 = MagicMock()
    sys.modules["boto3"] = mock_boto3

    try:
        store = make_attachment_store_from_env()
        assert isinstance(store, S3AttachmentStore)
        assert store._prefix == "attachments/"
    finally:
        sys.modules.pop("boto3", None)


def test_make_from_env_unknown_backend_raises(monkeypatch: pytest.MonkeyPatch) -> None:
    """make_attachment_store_from_env raises for unknown backend."""
    monkeypatch.setenv("GTV_ATTACHMENT_BACKEND", "unknown")

    with pytest.raises(ValueError, match="Unknown GTV_ATTACHMENT_BACKEND"):
        make_attachment_store_from_env()
