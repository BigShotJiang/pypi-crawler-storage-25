"""Tests for the claim canonicalization and caching layer."""
from __future__ import annotations

from gtv.claim_cache import ClaimCache, canonicalize_claim, claim_id_for


class TestCanonicalizeClaimBasic:
    """Test basic canonicalization behavior."""

    def test_same_content_different_phrasing_same_output(self) -> None:
        """Same content with different phrasing should produce same canonical form."""
        text1 = "Aspirin treats headaches"
        text2 = "treats headaches, aspirin does"
        domain = "health"
        # Both should normalize to sorted tokens regardless of original order
        canonical1 = canonicalize_claim(text1, domain)
        canonical2 = canonicalize_claim(text2, domain)
        assert canonical1 == canonical2

    def test_different_domain_different_output(self) -> None:
        """Same text in different domains should produce different canonical forms."""
        text = "Aspirin treats headaches"
        domain1 = "health"
        domain2 = "politics"
        canonical1 = canonicalize_claim(text, domain1)
        canonical2 = canonicalize_claim(text, domain2)
        assert canonical1 != canonical2
        assert canonical1.startswith("health:")
        assert canonical2.startswith("politics:")

    def test_punctuation_normalized(self) -> None:
        """Punctuation should be stripped and replaced with spaces."""
        text1 = "Aspirin, treats headaches!"
        text2 = "Aspirin treats headaches"
        domain = "health"
        canonical1 = canonicalize_claim(text1, domain)
        canonical2 = canonicalize_claim(text2, domain)
        assert canonical1 == canonical2

    def test_stopwords_removed(self) -> None:
        """Common stopwords should be removed."""
        text1 = "The aspirin treats the headaches and pain"
        text2 = "aspirin treats headaches pain"
        domain = "health"
        canonical1 = canonicalize_claim(text1, domain)
        canonical2 = canonicalize_claim(text2, domain)
        assert canonical1 == canonical2

    def test_word_order_doesnt_matter(self) -> None:
        """Different word order should produce same canonical form."""
        text1 = "aspirin treats headaches"
        text2 = "headaches treats aspirin"  # Nonsensical but tests ordering
        domain = "health"
        canonical1 = canonicalize_claim(text1, domain)
        canonical2 = canonicalize_claim(text2, domain)
        assert canonical1 == canonical2

    def test_case_insensitive(self) -> None:
        """Case should not affect canonical form."""
        text1 = "ASPIRIN TREATS HEADACHES"
        text2 = "aspirin treats headaches"
        domain = "health"
        canonical1 = canonicalize_claim(text1, domain)
        canonical2 = canonicalize_claim(text2, domain)
        assert canonical1 == canonical2

    def test_whitespace_collapsed(self) -> None:
        """Multiple spaces should be collapsed to single space."""
        text1 = "aspirin   treats   headaches"
        text2 = "aspirin treats headaches"
        domain = "health"
        canonical1 = canonicalize_claim(text1, domain)
        canonical2 = canonicalize_claim(text2, domain)
        assert canonical1 == canonical2


class TestClaimIdFor:
    """Test claim ID generation."""

    def test_claim_id_is_16_char_hex(self) -> None:
        """Claim ID should be exactly 16 hex characters."""
        text = "Aspirin treats headaches"
        domain = "health"
        claim_id = claim_id_for(text, domain)
        assert len(claim_id) == 16
        assert all(c in "0123456789abcdef" for c in claim_id)

    def test_claim_id_deterministic(self) -> None:
        """Same text and domain should produce same claim ID."""
        text = "Aspirin treats headaches"
        domain = "health"
        id1 = claim_id_for(text, domain)
        id2 = claim_id_for(text, domain)
        assert id1 == id2

    def test_claim_id_same_content_different_phrasing(self) -> None:
        """Same content with different phrasing should produce same ID."""
        text1 = "Aspirin treats headaches"
        text2 = "treats headaches, aspirin does"
        domain = "health"
        id1 = claim_id_for(text1, domain)
        id2 = claim_id_for(text2, domain)
        assert id1 == id2


class TestClaimCacheBasic:
    """Test basic cache operations."""

    def test_get_miss_returns_none(self) -> None:
        """get() should return None on cache miss."""
        cache = ClaimCache()
        result = cache.get("Aspirin treats headaches", "health")
        assert result is None

    def test_put_returns_id(self) -> None:
        """put() should return a claim ID."""
        cache = ClaimCache()
        claim_id = cache.put("Aspirin treats headaches", "health")
        assert claim_id is not None
        assert len(claim_id) == 16

    def test_put_second_call_returns_same_id(self) -> None:
        """Putting the same canonical form twice should return the same ID."""
        cache = ClaimCache()
        id1 = cache.put("Aspirin treats headaches", "health")
        id2 = cache.put("Aspirin treats headaches", "health")
        assert id1 == id2

    def test_get_after_put_returns_id(self) -> None:
        """get() after put() should return the cached ID."""
        cache = ClaimCache()
        put_id = cache.put("Aspirin treats headaches", "health")
        get_id = cache.get("Aspirin treats headaches", "health")
        assert get_id == put_id

    def test_get_after_put_different_phrasing(self) -> None:
        """get() should find a cached ID even with different phrasing."""
        cache = ClaimCache()
        id1 = cache.put("Aspirin treats headaches", "health")
        id2 = cache.get("treats headaches, aspirin does", "health")
        assert id2 == id1


class TestClaimCacheLRUEviction:
    """Test LRU eviction behavior."""

    def test_lru_eviction_at_max_entries(self) -> None:
        """Cache should evict oldest entry when max_entries is exceeded."""
        cache = ClaimCache(max_entries=3)

        # Insert 3 entries
        cache.put("claim one", "health")
        cache.put("claim two", "health")
        cache.put("claim three", "health")

        # Verify all are in cache
        assert cache.stats()["entries"] == 3

        # Insert 4th entry, which should evict the oldest (first)
        cache.put("claim four", "health")
        assert cache.stats()["entries"] == 3

        # First entry should be evicted
        assert cache.get("claim one", "health") is None
        # Others should still be there
        assert cache.get("claim two", "health") is not None
        assert cache.get("claim three", "health") is not None
        assert cache.get("claim four", "health") is not None

    def test_lru_eviction_respects_access_order(self) -> None:
        """get() should refresh LRU order, preventing premature eviction."""
        cache = ClaimCache(max_entries=3)

        # Insert 3 entries
        cache.put("claim one", "health")
        cache.put("claim two", "health")
        cache.put("claim three", "health")

        # Access the first entry (moves it to end of LRU)
        cache.get("claim one", "health")

        # Insert 4th entry, which should evict the second (not refreshed)
        cache.put("claim four", "health")

        # First should still be there (was accessed)
        assert cache.get("claim one", "health") is not None
        # Second should be evicted
        assert cache.get("claim two", "health") is None
        # Others should still be there
        assert cache.get("claim three", "health") is not None
        assert cache.get("claim four", "health") is not None


class TestClaimCacheStats:
    """Test statistics tracking."""

    def test_stats_tracks_entries(self) -> None:
        """stats() should report correct number of entries."""
        cache = ClaimCache()
        assert cache.stats()["entries"] == 0

        cache.put("claim one", "health")
        assert cache.stats()["entries"] == 1

        cache.put("claim two", "health")
        assert cache.stats()["entries"] == 2

        # Duplicate canonical form should not increase entry count
        cache.put("claim one", "health")
        assert cache.stats()["entries"] == 2

    def test_stats_tracks_hits_and_misses(self) -> None:
        """stats() should track cache hits and misses."""
        cache = ClaimCache()

        # Miss on first get()
        cache.get("claim one", "health")
        assert cache.stats()["misses"] == 1
        assert cache.stats()["hits"] == 0

        # put() does not affect hit/miss counts
        cache.put("claim one", "health")

        # Hit on second get()
        cache.get("claim one", "health")
        assert cache.stats()["hits"] == 1
        assert cache.stats()["misses"] == 1

        # Another miss
        cache.get("claim two", "health")
        assert cache.stats()["hits"] == 1
        assert cache.stats()["misses"] == 2

    def test_stats_returns_dict(self) -> None:
        """stats() should return a dict with expected keys."""
        cache = ClaimCache()
        stats = cache.stats()
        assert isinstance(stats, dict)
        assert "entries" in stats
        assert "hits" in stats
        assert "misses" in stats
