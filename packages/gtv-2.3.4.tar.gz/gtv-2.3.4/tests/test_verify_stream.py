"""End-to-end tests for /tools/verify_claim/stream (W33).

The streaming endpoint must:
 * emit ``claim_accepted`` first, ``envelope`` last
 * emit one ``evidence`` event per registered adapter (FACTUAL claims)
 * skip evidence/verdict events when the claim is non-FACTUAL but
   still produce ``claim_accepted`` + ``verdict`` + ``envelope``
 * collapse a cache hit to ``claim_accepted`` + ``envelope``
 * reject input with PII/missing adapters BEFORE opening the stream
   (so callers can distinguish input errors from mid-stream errors)
 * produce a sealed envelope identical to /tools/verify_claim's
"""

from __future__ import annotations

import json
from datetime import UTC, datetime

import pytest
from fastapi.testclient import TestClient

from gtv.adapters import REGISTRY
from gtv.adapters.base import HealthStatus, RawSnapshot, SourceAdapter
from gtv.cache import build_key
from gtv.mcp.server import _VERDICT_CACHE, app
from gtv.models import Claim, Domain, Evidence, SourceType, Stance, TrustTier


class _SupportingAdapter(SourceAdapter):
    """In-process adapter that always supports the claim."""

    source_did = "did:web:supporter.example"

    def __init__(self) -> None:
        self.name = "Supporter"
        self.type = SourceType.REFERENCE_DATA
        self.trust_tier = TrustTier.TIER_1
        self.freshness_sla_s = 86400
        self.last_audit = datetime.now(tz=UTC)

    async def query(
        self, claim: Claim, max_items: int = 5
    ) -> list[Evidence]:
        return [
            Evidence(
                claim_id=claim.claim_id,
                source_did=self.source_did,
                source_version="1.0",
                stance=Stance.SUPPORTS,
                excerpt="Direct supporting evidence.",
                url="https://example.com/a",
                retrieved_at=datetime.now(tz=UTC),
                raw_hash="0" * 64,
            )
        ]

    async def snapshot(self, url: str) -> RawSnapshot:
        return RawSnapshot(
            url=url,
            mime_type="text/plain",
            size_bytes=4,
            body=b"body",
            sha256_hex="0" * 64,
        )

    async def health(self) -> HealthStatus:
        return HealthStatus.HEALTHY

    async def close(self) -> None:  # pragma: no cover - no resources
        return None


class _FailingAdapter(SourceAdapter):
    """Always raises — used to verify error events still arrive."""

    source_did = "did:web:failer.example"

    def __init__(self) -> None:
        self.name = "Failer"
        self.type = SourceType.REFERENCE_DATA
        self.trust_tier = TrustTier.TIER_2
        self.freshness_sla_s = 86400
        self.last_audit = datetime.now(tz=UTC)

    async def query(
        self, claim: Claim, max_items: int = 5
    ) -> list[Evidence]:
        raise RuntimeError("adapter exploded")

    async def snapshot(self, url: str) -> RawSnapshot:  # pragma: no cover
        raise RuntimeError("never called")

    async def health(self) -> HealthStatus:
        return HealthStatus.HEALTHY

    async def close(self) -> None:  # pragma: no cover - no resources
        return None


@pytest.fixture
def sse_client(monkeypatch: pytest.MonkeyPatch):
    """Test client with two registered adapters (one good, one failing).

    Two adapters lets us assert as_completed ordering doesn't drop
    events, and that adapter-side failures surface as evidence events
    with ``status="error"`` rather than killing the stream.
    """
    monkeypatch.setenv("GTV_DISABLE_DEFAULT_ADAPTERS", "1")

    # Mutate the REGISTRY dict directly (don't go through register()).
    # test_metrics.py reloads gtv.adapters mid-run; after the reload
    # gtv.adapters.register() writes to the *new* dict while the
    # server's REGISTRY reference is still bound to the *old* dict.
    # Direct assignment via the dict object my module captured at
    # import time keeps both views consistent.
    saved_registry = dict(REGISTRY)
    REGISTRY.clear()
    REGISTRY[_SupportingAdapter.source_did] = _SupportingAdapter()
    REGISTRY[_FailingAdapter.source_did] = _FailingAdapter()

    # Drop the verdict cache so each test starts cold.
    saved_cache_get = _VERDICT_CACHE.get  # noqa: F841 — for symmetry
    yield TestClient(app)

    REGISTRY.clear()
    REGISTRY.update(saved_registry)


def _parse_sse(raw: str) -> list[tuple[str, dict]]:
    """Parse an SSE stream body into [(event_name, payload_dict), ...]."""
    out: list[tuple[str, dict]] = []
    current_event: str | None = None
    current_data: list[str] = []
    for line in raw.splitlines():
        if line.startswith("event:"):
            current_event = line[len("event:") :].strip()
        elif line.startswith("data:"):
            current_data.append(line[len("data:") :].strip())
        elif line == "" and current_event is not None:
            payload = json.loads("\n".join(current_data))
            out.append((current_event, payload))
            current_event = None
            current_data = []
    # Trailing event without final blank line (shouldn't happen, but
    # be tolerant).
    if current_event is not None and current_data:
        payload = json.loads("\n".join(current_data))
        out.append((current_event, payload))
    return out


def test_stream_emits_phases_in_order(sse_client: TestClient) -> None:
    """A FACTUAL claim emits claim_accepted → evidence(*) → verdict → envelope."""
    resp = sse_client.post(
        "/tools/verify_claim/stream",
        json={"claim": "Pi starts with 3.14.", "domain": "math"},
    )
    assert resp.status_code == 200
    assert "text/event-stream" in resp.headers["content-type"]
    assert resp.headers.get("cache-control") == "no-cache"

    events = _parse_sse(resp.text)
    phases = [name for name, _ in events]

    # claim_accepted is first
    assert phases[0] == "claim_accepted"
    # envelope is last
    assert phases[-1] == "envelope"
    # verdict precedes envelope
    assert phases.index("verdict") < phases.index("envelope")
    # one evidence event per registered adapter (we have 2)
    assert phases.count("evidence") == 2

    # Per-adapter status: one ok, one error
    evidence_events = [p for n, p in events if n == "evidence"]
    statuses = {e["source_did"]: e["status"] for e in evidence_events}
    assert statuses[_SupportingAdapter.source_did] == "ok"
    assert statuses[_FailingAdapter.source_did] == "error"

    # Final envelope payload is well-formed
    envelope_payload = events[-1][1]["envelope"]
    # Pulled from Verdict StrEnum; smoke-check it's a known value.
    from gtv.models import Verdict

    assert envelope_payload["verdict"] in {v.value for v in Verdict}
    # Evidence count on the verdict event matches the envelope
    verdict_event = next(p for n, p in events if n == "verdict")
    assert verdict_event["evidence_count"] == len(envelope_payload["evidence"])


def test_stream_short_circuits_for_non_factual(sse_client: TestClient) -> None:
    """An OPINION claim skips evidence events but still emits verdict + envelope."""
    resp = sse_client.post(
        "/tools/verify_claim/stream",
        json={
            "claim": "I think pineapple on pizza is delicious.",
            "domain": "general",
        },
    )
    assert resp.status_code == 200

    events = _parse_sse(resp.text)
    phases = [name for name, _ in events]

    assert phases[0] == "claim_accepted"
    assert phases[-1] == "envelope"
    # No adapter fan-out for OPINION.
    assert "evidence" not in phases
    # Verdict still emitted.
    assert "verdict" in phases

    # claim_accepted carries the classification so callers can branch
    # without waiting for the verdict event.
    accepted = events[0][1]
    assert accepted["classification"].lower() == "opinion"


def test_stream_cache_hit_is_two_events(sse_client: TestClient) -> None:
    """Second call hits the cache: stream collapses to claim_accepted + envelope."""
    body = {"claim": "Pi starts with 3.14.", "domain": "math"}

    # Prime the cache via the streaming endpoint itself.
    first = sse_client.post("/tools/verify_claim/stream", json=body)
    assert first.status_code == 200

    second = sse_client.post("/tools/verify_claim/stream", json=body)
    assert second.status_code == 200
    events = _parse_sse(second.text)
    phases = [name for name, _ in events]
    assert phases == ["claim_accepted", "envelope"], (
        f"cache hit should collapse to 2 events, got: {phases}"
    )

    # The two streams should produce the same envelope (cache is the
    # source of truth on a hit).
    first_envelope = next(p for n, p in _parse_sse(first.text) if n == "envelope")
    second_envelope = events[-1][1]
    assert (
        first_envelope["envelope"]["signature"]
        == second_envelope["envelope"]["signature"]
    )


def test_stream_rejects_pii_before_opening(sse_client: TestClient) -> None:
    """PII gate fires as a 400 — never opens the stream."""
    resp = sse_client.post(
        "/tools/verify_claim/stream",
        json={
            "claim": "My SSN is 123-45-6789 and email is x@y.com.",
            "domain": "general",
        },
    )
    assert resp.status_code == 400
    assert "personally identifiable" in resp.json()["detail"]
    # Body must be JSON, NOT an event-stream.
    assert "text/event-stream" not in resp.headers.get("content-type", "")


def test_stream_503_when_no_adapters(monkeypatch: pytest.MonkeyPatch) -> None:
    """No adapters registered → 503 before stream opens."""
    monkeypatch.setenv("GTV_DISABLE_DEFAULT_ADAPTERS", "1")
    saved = dict(REGISTRY)
    REGISTRY.clear()
    try:
        client = TestClient(app)
        resp = client.post(
            "/tools/verify_claim/stream",
            json={"claim": "x", "domain": "general"},
        )
        assert resp.status_code == 503
    finally:
        REGISTRY.update(saved)


def test_stream_envelope_matches_nonstream_endpoint(
    sse_client: TestClient,
) -> None:
    """Streaming and non-streaming endpoints produce equivalent envelopes.

    Both paths share _verify_one_events, so a cold call to either
    should produce the same verdict/confidence for the same claim.
    Signatures will differ (different timestamp inside the envelope),
    but the verdict + evidence count should be identical.
    """
    body = {"claim": "Pi starts with 3.14.", "domain": "math"}

    # Cold streaming call.
    stream_resp = sse_client.post("/tools/verify_claim/stream", json=body)
    stream_events = _parse_sse(stream_resp.text)
    stream_envelope = stream_events[-1][1]["envelope"]

    # Cold non-streaming call (different cache key — different claim
    # text — to avoid serving the streaming envelope from cache).
    body2 = {"claim": "Pi starts with 3.14159.", "domain": "math"}
    json_resp = sse_client.post("/tools/verify_claim", json=body2)
    json_envelope = json_resp.json()["envelope"]

    assert stream_envelope["verdict"] == json_envelope["verdict"]
    # Both envelopes should be sealed (have signatures).
    assert stream_envelope["signature"]
    assert json_envelope["signature"]


def test_stream_caches_envelope_for_nonstream_endpoint(
    sse_client: TestClient,
) -> None:
    """A cold streaming call populates the verdict cache.

    Following non-streaming call for the same claim should hit the
    cache and serve the identical envelope. Without this the two
    endpoints would maintain separate caches and operators would see
    cache-miss spikes whenever traffic shifted between them.
    """
    body = {"claim": "Two plus two equals four.", "domain": "math"}

    stream_resp = sse_client.post("/tools/verify_claim/stream", json=body)
    stream_events = _parse_sse(stream_resp.text)
    stream_envelope = stream_events[-1][1]["envelope"]

    json_resp = sse_client.post("/tools/verify_claim", json=body)
    cached_envelope = json_resp.json()["envelope"]

    # Same signature ⇒ same envelope ⇒ served from cache.
    assert stream_envelope["signature"] == cached_envelope["signature"]


def test_cache_key_independent_of_endpoint(sse_client: TestClient) -> None:
    """Sanity: cache key derivation does not include endpoint name.

    Defends the previous test against silent regression — if someone
    adds an endpoint dimension to build_key, the streaming/non-
    streaming cache sharing breaks.
    """
    k_a = build_key(
        claim_text="hello",
        domain=Domain.GENERAL,
        max_sources=5,
        issuer_did="did:web:test",
    )
    k_b = build_key(
        claim_text="hello",
        domain=Domain.GENERAL,
        max_sources=5,
        issuer_did="did:web:test",
    )
    assert k_a == k_b
