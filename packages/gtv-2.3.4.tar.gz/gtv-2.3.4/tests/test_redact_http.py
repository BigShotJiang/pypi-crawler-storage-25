"""HTTP integration tests for the W29 redaction layer.

Asserts two contracts end-to-end:
  1. PII in the *submitted claim text* => 400 (never silently redacted,
     since redacting the claim would break caching and mislead callers).
  2. PII in *adapter-returned evidence excerpts* => scrubbed from the
     signed envelope before it is sealed. The envelope's canonical hash
     therefore covers the REDACTED text, not the raw PII.
"""
from __future__ import annotations

from datetime import UTC, datetime

import pytest
from fastapi.testclient import TestClient
from pydantic import HttpUrl

from gtv.adapters import REGISTRY
from gtv.adapters.base import HealthStatus, RawSnapshot, SourceAdapter
from gtv.cache import InMemoryCacheStore, VerdictCache
from gtv.lifecycle import LifecycleIndex
from gtv.models import (
    Claim,
    Evidence,
    SourceType,
    Stance,
    TrustTier,
)
from gtv.redact.redactor import reset_default_redactor_for_tests


class _LeakyAdapter(SourceAdapter):
    """Returns an evidence excerpt that DELIBERATELY contains PII
    (an email and a US phone number). The redactor must strip both
    before the envelope is sealed, otherwise the PII ends up in the
    signed canonical form — a permanent leak."""

    source_did = "did:web:leaky.example"
    name = "leaky"
    source_type = SourceType.REFERENCE_DATA
    trust_tier = TrustTier.TIER_1
    freshness_sla_s = 60

    async def query(self, claim: Claim, max_items: int = 5) -> list[Evidence]:
        return [
            Evidence(
                claim_id=claim.claim_id,
                source_did=self.source_did,
                source_version="v1",
                stance=Stance.SUPPORTS,
                excerpt=(
                    "Per reviewer alice@example.com, confirmed at "
                    "(415) 555-1212. Raw SSN 123-45-6789 was in the "
                    "original record."
                ),
                url=HttpUrl("https://leaky.example/e/1"),
                retrieved_at=datetime.now(tz=UTC),
                raw_hash="0" * 64,
            )
        ]

    async def snapshot(self, url: str) -> RawSnapshot:
        return RawSnapshot(url=url, content=b"", retrieved_at_iso="")

    async def health(self) -> HealthStatus:
        return HealthStatus(state="HEALTHY", detail="")

    async def close(self) -> None:
        return None


@pytest.fixture
def redact_server() -> tuple[TestClient, _LeakyAdapter]:
    import gtv.mcp.server as server_mod

    saved_registry = dict(REGISTRY)
    saved_cache = server_mod._VERDICT_CACHE
    saved_lifecycle = server_mod._LIFECYCLE

    REGISTRY.clear()
    adapter = _LeakyAdapter()
    REGISTRY[adapter.source_did] = adapter
    server_mod._VERDICT_CACHE = VerdictCache(InMemoryCacheStore())
    server_mod._LIFECYCLE = LifecycleIndex()
    reset_default_redactor_for_tests()

    client = TestClient(server_mod.app)
    try:
        yield client, adapter
    finally:
        REGISTRY.clear()
        REGISTRY.update(saved_registry)
        server_mod._VERDICT_CACHE = saved_cache
        server_mod._LIFECYCLE = saved_lifecycle
        reset_default_redactor_for_tests()


def test_pii_in_claim_text_is_400(
    redact_server: tuple[TestClient, _LeakyAdapter],
) -> None:
    client, _ = redact_server
    r = client.post(
        "/tools/verify_claim",
        json={
            "claim": "Contact me at mark@example.com for details.",
            "domain": "physics",
            "max_sources": 3,
        },
    )
    assert r.status_code == 400
    assert "personally identifiable" in r.json()["detail"].lower()


def test_pii_in_evidence_is_stripped_from_envelope(
    redact_server: tuple[TestClient, _LeakyAdapter],
) -> None:
    client, _ = redact_server
    r = client.post(
        "/tools/verify_claim",
        json={"claim": "The sky is blue.", "domain": "physics", "max_sources": 3},
    )
    assert r.status_code == 200
    env = r.json()["envelope"]
    assert len(env["evidence"]) == 1
    excerpt = env["evidence"][0]["excerpt"]
    assert "alice@example.com" not in excerpt
    assert "(415) 555-1212" not in excerpt
    assert "123-45-6789" not in excerpt
    assert "[REDACTED:EMAIL]" in excerpt
    assert "[REDACTED:PHONE]" in excerpt
    assert "[REDACTED:SSN]" in excerpt


def test_redacted_envelope_signature_still_verifies(
    redact_server: tuple[TestClient, _LeakyAdapter],
) -> None:
    """The signed canonical hash is computed over the REDACTED text.
    Recomputing it must still yield the stub signature — proves we
    redact BEFORE sealing, not after."""
    import hashlib as _hashlib

    from gtv.anchor.canonicalize import envelope_canonical_sha256
    from gtv.models import Envelope as EnvelopeModel

    client, _ = redact_server
    r = client.post(
        "/tools/verify_claim",
        json={"claim": "The sky is blue.", "domain": "physics", "max_sources": 3},
    )
    env = EnvelopeModel.model_validate(r.json()["envelope"])
    canonical_hex = envelope_canonical_sha256(env)
    expected = _hashlib.sha256(canonical_hex.encode("utf-8")).hexdigest()
    assert env.signature == f"stub://{expected}"


def test_supersede_also_rejects_pii_claim(
    redact_server: tuple[TestClient, _LeakyAdapter],
) -> None:
    client, _ = redact_server
    # Seed a parent first.
    r1 = client.post(
        "/tools/verify_claim",
        json={"claim": "parent claim", "domain": "physics", "max_sources": 3},
    )
    parent_id = r1.json()["envelope"]["envelope_id"]
    r2 = client.post(
        "/tools/supersede_claim",
        json={
            "parent_envelope_id": parent_id,
            "claim": "contact alice@example.com",
            "domain": "physics",
            "reason": "AMEND",
            "max_sources": 3,
        },
    )
    assert r2.status_code == 400


def test_redact_disabled_flag_passes_through(
    redact_server: tuple[TestClient, _LeakyAdapter],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """GTV_REDACT_ENABLED=0 is a dev-only escape hatch. With it set,
    rationale/excerpt redaction is skipped — BUT input-side PII rejection
    stays on."""
    monkeypatch.setenv("GTV_REDACT_ENABLED", "0")
    reset_default_redactor_for_tests()
    client, _ = redact_server

    r = client.post(
        "/tools/verify_claim",
        json={"claim": "The sky is blue.", "domain": "physics", "max_sources": 3},
    )
    assert r.status_code == 200
    excerpt = r.json()["envelope"]["evidence"][0]["excerpt"]
    # Raw PII IS present because redaction is disabled.
    assert "alice@example.com" in excerpt

    # Input-side rejection still works — not affected by the flag.
    r2 = client.post(
        "/tools/verify_claim",
        json={"claim": "email a@b.co", "domain": "physics", "max_sources": 3},
    )
    assert r2.status_code == 400
