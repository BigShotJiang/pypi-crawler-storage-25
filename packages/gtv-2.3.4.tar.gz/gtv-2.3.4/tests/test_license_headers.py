# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Tests for license header checking and fixing."""

import subprocess
import sys
import tempfile
from pathlib import Path

REQUIRED_HEADER = "# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial"
SCRIPT_PATH = Path(__file__).parent.parent / "scripts" / "check_license_headers.py"
SRC_DIR = Path(__file__).parent.parent / "src" / "gtv"


def run_script(args):
    """Run the license header script with given args. Returns (exit_code, stdout, stderr)."""
    result = subprocess.run(
        [sys.executable, str(SCRIPT_PATH), *args],
        capture_output=True,
        text=True,
    )
    return result.returncode, result.stdout, result.stderr


class TestCheckMode:
    """Tests for --check mode."""

    def test_check_passes_on_current_tree(self):
        """After migration, --check should exit 0 on the actual source tree."""
        exit_code, _, stderr = run_script(["--check"])
        assert exit_code == 0, f"--check failed on actual tree:\n{stderr}"
        assert "All" in stderr and "files have license headers" in stderr

    def test_check_fails_on_file_without_header(self):
        """--check should exit 1 when a file lacks the header."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            test_file = tmpdir / "test_no_header.py"
            test_file.write_text('"""Module without header."""\n\nprint("hello")\n')

            # Create a temporary copy of the script that uses the tmpdir
            script_copy = tmpdir / "check_script.py"
            script_copy.write_text(
                SCRIPT_PATH.read_text().replace(
                    'SRC_DIR = Path(__file__).parent.parent / "src" / "gtv"',
                    f'SRC_DIR = Path("{tmpdir}")',
                )
            )

            result = subprocess.run(
                [sys.executable, str(script_copy), "--check"],
                capture_output=True,
                text=True,
            )
            assert result.returncode == 1
            assert "Missing license headers" in result.stderr


class TestFixMode:
    """Tests for --fix mode."""

    def test_fix_adds_header_to_missing_file(self):
        """--fix should add header to a file that lacks it."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            test_file = tmpdir / "test_fix.py"
            original_content = '"""Module docstring."""\n\nprint("hello")\n'
            test_file.write_text(original_content)

            # Create a temporary copy of the script
            script_copy = tmpdir / "check_script.py"
            script_copy.write_text(
                SCRIPT_PATH.read_text().replace(
                    'SRC_DIR = Path(__file__).parent.parent / "src" / "gtv"',
                    f'SRC_DIR = Path("{tmpdir}")',
                )
            )

            result = subprocess.run(
                [sys.executable, str(script_copy), "--fix"],
                capture_output=True,
                text=True,
            )
            assert result.returncode == 0

            # Check that the header was added
            fixed_content = test_file.read_text()
            assert REQUIRED_HEADER in fixed_content
            assert original_content in fixed_content  # Original content preserved

    def test_fix_is_idempotent(self):
        """Running --fix twice should not duplicate the header."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            test_file = tmpdir / "test_idempotent.py"
            original_content = '"""Test module."""\nprint("test")\n'
            test_file.write_text(original_content)

            script_copy = tmpdir / "check_script.py"
            script_copy.write_text(
                SCRIPT_PATH.read_text().replace(
                    'SRC_DIR = Path(__file__).parent.parent / "src" / "gtv"',
                    f'SRC_DIR = Path("{tmpdir}")',
                )
            )

            # Run --fix first time
            subprocess.run(
                [sys.executable, str(script_copy), "--fix"],
                capture_output=True,
                text=True,
            )
            after_first_fix = test_file.read_text()

            # Run --fix second time
            subprocess.run(
                [sys.executable, str(script_copy), "--fix"],
                capture_output=True,
                text=True,
            )
            after_second_fix = test_file.read_text()

            # Should be identical
            assert after_first_fix == after_second_fix
            # Should contain header exactly once
            assert after_first_fix.count(REQUIRED_HEADER) == 1

    def test_check_ignores_empty_files(self):
        """--check should gracefully handle empty files."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            empty_file = tmpdir / "empty.py"
            empty_file.write_text("")

            script_copy = tmpdir / "check_script.py"
            script_copy.write_text(
                SCRIPT_PATH.read_text().replace(
                    'SRC_DIR = Path(__file__).parent.parent / "src" / "gtv"',
                    f'SRC_DIR = Path("{tmpdir}")',
                )
            )

            result = subprocess.run(
                [sys.executable, str(script_copy), "--check"],
                capture_output=True,
                text=True,
            )
            # Empty files should not be flagged as missing headers
            assert result.returncode == 0

    def test_check_handles_shebang_lines(self):
        """--fix should preserve shebang lines and place header after them."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            test_file = tmpdir / "test_shebang.py"
            original_content = '#!/usr/bin/env python3\n"""Module with shebang."""\nprint("test")\n'
            test_file.write_text(original_content)

            script_copy = tmpdir / "check_script.py"
            script_copy.write_text(
                SCRIPT_PATH.read_text().replace(
                    'SRC_DIR = Path(__file__).parent.parent / "src" / "gtv"',
                    f'SRC_DIR = Path("{tmpdir}")',
                )
            )

            result = subprocess.run(
                [sys.executable, str(script_copy), "--fix"],
                capture_output=True,
                text=True,
            )
            assert result.returncode == 0

            fixed_content = test_file.read_text()
            lines = fixed_content.split("\n")

            # Shebang must be on line 0
            assert lines[0].startswith("#!/usr/bin/env python3")

            # Header must be after shebang
            assert REQUIRED_HEADER in lines[1]

    def test_fix_preserves_coding_declaration(self):
        """--fix should preserve coding declarations and place header appropriately."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            test_file = tmpdir / "test_coding.py"
            original_content = (
                "# -*- coding: utf-8 -*-\n"
                '"""Module with coding declaration."""\n'
                "print('test')\n"
            )
            test_file.write_text(original_content)

            script_copy = tmpdir / "check_script.py"
            script_copy.write_text(
                SCRIPT_PATH.read_text().replace(
                    'SRC_DIR = Path(__file__).parent.parent / "src" / "gtv"',
                    f'SRC_DIR = Path("{tmpdir}")',
                )
            )

            result = subprocess.run(
                [sys.executable, str(script_copy), "--fix"],
                capture_output=True,
                text=True,
            )
            assert result.returncode == 0

            fixed_content = test_file.read_text()
            lines = fixed_content.split("\n")

            # Coding declaration should be preserved at top
            assert "coding:" in lines[0]

            # Header should be after coding declaration
            assert REQUIRED_HEADER in lines[1]


class TestIntegration:
    """Integration tests with the actual source tree."""

    def test_all_files_in_src_have_headers(self):
        """Verify all .py files in src/gtv/ have the required header."""
        py_files = list(SRC_DIR.rglob("*.py"))
        assert len(py_files) > 0, f"No .py files found in {SRC_DIR}"

        files_without_header = []
        for file_path in py_files:
            with open(file_path, encoding="utf-8") as f:
                content = f.read()
                # Skip empty files
                if content.strip() and REQUIRED_HEADER not in content[:500]:
                    files_without_header.append(file_path)

        assert (
            len(files_without_header) == 0
        ), f"Files missing header: {files_without_header}"
