"""Week 13 revocation enforcement integration tests.

Verifies that:
1. Revocation lists are loaded from GTV_REVOCATION_DIR
2. Bad signatures are skipped
3. Empty env var returns empty list
4. /tools/verify_claim checks revocation and returns 410 Gone if revoked
5. No regression when revocation is not enabled
"""
from __future__ import annotations

import importlib
import os
from datetime import UTC, datetime

import pytest
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ed25519

from gtv.models import AnchorProof, Envelope, Evidence, Stance, Verdict
from gtv.revocation.check import is_revoked
from gtv.revocation.list import build_revocation_list
from gtv.revocation.loader import (
    load_revocation_lists_from_dir,
    load_revocation_lists_from_env,
)
from gtv.sign.byok import _derive_did_key_from_public_key


@pytest.fixture
def ed25519_private_key_pem(tmp_path):
    """Generate a test Ed25519 private key in PEM format."""
    private_key = ed25519.Ed25519PrivateKey.generate()
    pem_bytes = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    pem_file = tmp_path / "test_key.pem"
    pem_file.write_bytes(pem_bytes)
    return pem_file


@pytest.fixture
def issuer_did(ed25519_private_key_pem):
    """Derive the issuer_did from the test key."""
    pem_bytes = ed25519_private_key_pem.read_bytes()
    private_key = serialization.load_pem_private_key(pem_bytes, password=None)
    public_key = private_key.public_key()
    raw_bytes = public_key.public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    return _derive_did_key_from_public_key("Ed25519", raw_bytes)


def _make_envelope(
    verdict: Verdict,
    issuer_did: str,
    envelope_id: str = "test-envelope-id",
    rekor_log_index: int = 0,
) -> Envelope:
    """Create a minimal test envelope."""
    return Envelope(
        envelope_id=envelope_id,
        verdict=verdict,
        confidence=0.9,
        evidence=[
            Evidence(
                claim_id="test-claim-id",
                source_did="did:source",
                source_version="1.0",
                stance=Stance.SUPPORTS,
                excerpt="test excerpt",
                url="https://example.com",
                retrieved_at=datetime.now(tz=UTC),
                raw_hash="0" * 64,
            )
        ],
        rationale="test",
        issuer_did=issuer_did,
        issued_at=datetime.now(tz=UTC),
        signature="stub://sig",
        rekor_uuid="test-uuid",
        rekor_log_index=rekor_log_index,
        tsa_token="stub://tsa",
        prov_graph="{}",
        anchor_proof=AnchorProof(
            rekor_inclusion_proof="stub://proof",
            tsa_tsr_primary="stub://tsa",
        ),
    )


class TestRevocationLoader:
    """Test RevocationList loading from directory."""

    def test_loader_reads_directory(self, tmp_path, ed25519_private_key_pem, issuer_did):
        """Test that loader reads all *.json files from directory."""
        # Create two revocation lists
        rl1 = build_revocation_list(
            issuer_did=issuer_did,
            envelope_ids=["env-1"],
            private_key_path=ed25519_private_key_pem,
        )
        rl2 = build_revocation_list(
            issuer_did=issuer_did,
            envelope_ids=["env-2"],
            private_key_path=ed25519_private_key_pem,
        )

        # Write them to JSON files
        rev_dir = tmp_path / "revocation"
        rev_dir.mkdir()
        (rev_dir / "list1.json").write_text(rl1.model_dump_json())
        (rev_dir / "list2.json").write_text(rl2.model_dump_json())

        # Load them
        loaded = load_revocation_lists_from_dir(rev_dir)

        assert len(loaded) == 2
        assert {item.list_id for item in loaded} == {rl1.list_id, rl2.list_id}

    def test_loader_skips_bad_signatures(self, tmp_path, ed25519_private_key_pem, issuer_did):
        """Test that loader skips lists with bad signatures."""
        # Create one valid list
        rl1 = build_revocation_list(
            issuer_did=issuer_did,
            envelope_ids=["env-1"],
            private_key_path=ed25519_private_key_pem,
        )

        # Create a second list and tamper with it
        rl2 = build_revocation_list(
            issuer_did=issuer_did,
            envelope_ids=["env-2"],
            private_key_path=ed25519_private_key_pem,
        )
        rl2_tampered = rl2.model_copy(update={"signature": "byok-ed25519:invalid"})

        rev_dir = tmp_path / "revocation"
        rev_dir.mkdir()
        (rev_dir / "list1.json").write_text(rl1.model_dump_json())
        (rev_dir / "list2.json").write_text(rl2_tampered.model_dump_json())

        loaded = load_revocation_lists_from_dir(rev_dir)

        # Should only load the valid one
        assert len(loaded) == 1
        assert loaded[0].list_id == rl1.list_id

    def test_loader_returns_empty_list_for_missing_directory(self):
        """Test that loader returns empty list for missing directory."""
        loaded = load_revocation_lists_from_dir("/nonexistent/path")
        assert loaded == []

    def test_loader_from_env_unset(self):
        """Test that loader returns empty list when env var is unset."""
        # Ensure env var is not set
        old_val = os.environ.pop("GTV_REVOCATION_DIR", None)
        try:
            loaded = load_revocation_lists_from_env()
            assert loaded == []
        finally:
            if old_val is not None:
                os.environ["GTV_REVOCATION_DIR"] = old_val

    def test_loader_from_env_set(self, tmp_path, ed25519_private_key_pem, issuer_did):
        """Test that loader reads from GTV_REVOCATION_DIR env var."""
        rev_dir = tmp_path / "revocation"
        rev_dir.mkdir()

        rl = build_revocation_list(
            issuer_did=issuer_did,
            envelope_ids=["env-1"],
            private_key_path=ed25519_private_key_pem,
        )
        (rev_dir / "list.json").write_text(rl.model_dump_json())

        old_val = os.environ.get("GTV_REVOCATION_DIR")
        try:
            os.environ["GTV_REVOCATION_DIR"] = str(rev_dir)
            loaded = load_revocation_lists_from_env()
            assert len(loaded) == 1
            assert loaded[0].list_id == rl.list_id
        finally:
            if old_val is not None:
                os.environ["GTV_REVOCATION_DIR"] = old_val
            else:
                os.environ.pop("GTV_REVOCATION_DIR", None)


class TestVerifyClaimRevocationEnforcement:
    """Integration tests: revocation checking on /tools/verify_claim."""

    def test_no_revocation_dir_returns_200(self):
        """Test that /tools/verify_claim returns 200 when no revocation dir is set."""
        # Ensure no revocation dir
        old_val = os.environ.pop("GTV_REVOCATION_DIR", None)
        try:
            # Reload server module to pick up empty revocation lists
            import gtv.mcp.server as server_mod
            importlib.reload(server_mod)

            # Verify that the _REVOCATION_LISTS is empty
            assert server_mod._REVOCATION_LISTS == []
        finally:
            if old_val is not None:
                os.environ["GTV_REVOCATION_DIR"] = old_val

    def test_revoked_issuer_returns_410(
        self, tmp_path, ed25519_private_key_pem, issuer_did
    ):
        """Test that /tools/verify_claim returns 410 when issuer is revoked."""

        rev_dir = tmp_path / "revocation"
        rev_dir.mkdir()

        # Create a revocation list that revokes the issuer
        rl = build_revocation_list(
            issuer_did=issuer_did,
            issuer_dids=[issuer_did],
            private_key_path=ed25519_private_key_pem,
        )
        (rev_dir / "list.json").write_text(rl.model_dump_json())

        # Load and verify lists are loaded
        loaded = load_revocation_lists_from_dir(rev_dir)
        assert len(loaded) == 1

        # Create an envelope from that issuer
        envelope = _make_envelope(Verdict.VERIFIED, issuer_did)

        # Check that it's revoked
        status = is_revoked(envelope, loaded)
        assert status.revoked is True
        assert "issuer" in (status.reason or "").lower()

    def test_revoked_envelope_id_returns_410(
        self, tmp_path, ed25519_private_key_pem, issuer_did
    ):
        """Test that /tools/verify_claim returns 410 when envelope_id is revoked."""

        rev_dir = tmp_path / "revocation"
        rev_dir.mkdir()

        envelope_id = "specific-revoked-envelope"

        # Create a revocation list that revokes this envelope
        rl = build_revocation_list(
            issuer_did=issuer_did,
            envelope_ids=[envelope_id],
            private_key_path=ed25519_private_key_pem,
        )
        (rev_dir / "list.json").write_text(rl.model_dump_json())

        loaded = load_revocation_lists_from_dir(rev_dir)
        assert len(loaded) == 1

        # Create an envelope with the revoked ID
        envelope = _make_envelope(
            Verdict.VERIFIED, issuer_did, envelope_id=envelope_id
        )

        # Check that it's revoked
        status = is_revoked(envelope, loaded)
        assert status.revoked is True
        assert "envelope_id" in (status.reason or "").lower()

    def test_non_revoked_envelope_passes(
        self, tmp_path, ed25519_private_key_pem, issuer_did
    ):
        """Test that non-revoked envelopes pass the check."""

        rev_dir = tmp_path / "revocation"
        rev_dir.mkdir()

        # Create a revocation list that revokes a different envelope
        rl = build_revocation_list(
            issuer_did=issuer_did,
            envelope_ids=["different-envelope"],
            private_key_path=ed25519_private_key_pem,
        )
        (rev_dir / "list.json").write_text(rl.model_dump_json())

        loaded = load_revocation_lists_from_dir(rev_dir)
        assert len(loaded) == 1

        # Create an envelope that's not revoked
        envelope = _make_envelope(
            Verdict.VERIFIED, issuer_did, envelope_id="my-envelope"
        )

        # Check that it's NOT revoked
        status = is_revoked(envelope, loaded)
        assert status.revoked is False
        assert status.reason is None

    def test_revoked_rekor_index_returns_410(
        self, tmp_path, ed25519_private_key_pem, issuer_did
    ):
        """Test that /tools/verify_claim returns 410 when rekor_log_index is revoked."""

        rev_dir = tmp_path / "revocation"
        rev_dir.mkdir()

        rekor_index = 12345

        # Create a revocation list that revokes this rekor index
        rl = build_revocation_list(
            issuer_did=issuer_did,
            rekor_indices=[rekor_index],
            private_key_path=ed25519_private_key_pem,
        )
        (rev_dir / "list.json").write_text(rl.model_dump_json())

        loaded = load_revocation_lists_from_dir(rev_dir)
        assert len(loaded) == 1

        # Create an envelope with the revoked rekor index
        envelope = _make_envelope(
            Verdict.VERIFIED, issuer_did, rekor_log_index=rekor_index
        )

        # Check that it's revoked
        status = is_revoked(envelope, loaded)
        assert status.revoked is True
        assert "rekor" in (status.reason or "").lower()
