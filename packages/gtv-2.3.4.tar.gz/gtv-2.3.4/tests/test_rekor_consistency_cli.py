"""CLI integration tests for `gtv-rekor-check`.

Uses respx to intercept httpx calls — no live Rekor. Exercises the full
argparse → HTTP → verify → stdout path for each subcommand.
"""
from __future__ import annotations

import json
from pathlib import Path

import httpx
import pytest
import respx

from gtv.anchor.consistency import generate_consistency_proof, leaf_hash, merkle_root
from gtv.cli.rekor_consistency import main

_BASE = "https://rekor.example"


def _state_for(n: int) -> tuple[list[bytes], bytes]:
    """Deterministic Merkle state for `n` leaves."""
    leaves = [leaf_hash(f"entry-{i}".encode()) for i in range(n)]
    return leaves, merkle_root(leaves)


@respx.mock
def test_pin_writes_checkpoint(tmp_path: Path) -> None:
    leaves, root = _state_for(42)
    respx.get(f"{_BASE}/api/v1/log").mock(
        return_value=httpx.Response(
            200, json={"treeSize": len(leaves), "rootHash": root.hex(), "treeID": "abc"}
        )
    )
    out = tmp_path / "pinned.json"
    rc = main(["pin", "--url", _BASE, "--out", str(out)])
    assert rc == 0
    data = json.loads(out.read_text())
    assert data["tree_size"] == 42
    assert data["root_hash"] == root.hex()
    assert data["url"] == _BASE
    assert data["tree_id"] == "abc"


@respx.mock
def test_verify_happy_path(tmp_path: Path) -> None:
    old_leaves, old_root = _state_for(5)
    all_leaves, new_root = _state_for(12)
    proof_bytes = generate_consistency_proof(all_leaves, 5)
    proof_hex = [h.hex() for h in proof_bytes]

    pinned = tmp_path / "pinned.json"
    pinned.write_text(
        json.dumps(
            {"url": _BASE, "tree_size": 5, "root_hash": old_root.hex(), "tree_id": None}
        )
    )

    respx.get(f"{_BASE}/api/v1/log").mock(
        return_value=httpx.Response(
            200, json={"treeSize": 12, "rootHash": new_root.hex()}
        )
    )
    respx.get(f"{_BASE}/api/v1/log/proof").mock(
        return_value=httpx.Response(200, json={"hashes": proof_hex})
    )

    rc = main(["verify", "--pinned", str(pinned), "--url", _BASE])
    assert rc == 0
    # The old_leaves reference is only used to derive old_root; keep the linter happy.
    _ = old_leaves


@respx.mock
def test_verify_detects_rewrite_at_same_size(tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
    _old_leaves, old_root = _state_for(5)
    # Pretend Rekor reports the same size but a different root.
    bogus_root = bytes(32).hex()
    pinned = tmp_path / "pinned.json"
    pinned.write_text(
        json.dumps(
            {"url": _BASE, "tree_size": 5, "root_hash": old_root.hex(), "tree_id": None}
        )
    )
    respx.get(f"{_BASE}/api/v1/log").mock(
        return_value=httpx.Response(200, json={"treeSize": 5, "rootHash": bogus_root})
    )

    rc = main(["verify", "--pinned", str(pinned), "--url", _BASE])
    assert rc == 1
    err = capsys.readouterr().err
    assert "log rewritten" in err


@respx.mock
def test_verify_detects_truncation(tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
    _old_leaves, old_root = _state_for(10)
    pinned = tmp_path / "pinned.json"
    pinned.write_text(
        json.dumps(
            {"url": _BASE, "tree_size": 10, "root_hash": old_root.hex(), "tree_id": None}
        )
    )
    respx.get(f"{_BASE}/api/v1/log").mock(
        return_value=httpx.Response(
            200, json={"treeSize": 3, "rootHash": bytes(32).hex()}
        )
    )

    rc = main(["verify", "--pinned", str(pinned), "--url", _BASE])
    assert rc == 1
    assert "truncated" in capsys.readouterr().err


@respx.mock
def test_verify_detects_fork(tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
    _old_leaves, old_root = _state_for(5)
    # Build a FORKED second tree of size 12 that diverges WITHIN the pinned
    # prefix — i.e. the operator tried to quietly edit one of the first 5
    # entries. A consistency proof cannot paper this over.
    forked = [leaf_hash(f"FORK-{i}".encode()) for i in range(5)] + [
        leaf_hash(f"entry-{i}".encode()) for i in range(5, 12)
    ]
    forked_root = merkle_root(forked)
    # Their proof is (dishonestly) generated against the forked tree — verifier
    # should reject it when matched against the honest pinned first root.
    forked_proof = [h.hex() for h in generate_consistency_proof(forked, 5)]

    pinned = tmp_path / "pinned.json"
    pinned.write_text(
        json.dumps(
            {"url": _BASE, "tree_size": 5, "root_hash": old_root.hex(), "tree_id": None}
        )
    )
    respx.get(f"{_BASE}/api/v1/log").mock(
        return_value=httpx.Response(
            200, json={"treeSize": 12, "rootHash": forked_root.hex()}
        )
    )
    respx.get(f"{_BASE}/api/v1/log/proof").mock(
        return_value=httpx.Response(200, json={"hashes": forked_proof})
    )

    rc = main(["verify", "--pinned", str(pinned), "--url", _BASE])
    assert rc == 1
    assert "consistency proof failed" in capsys.readouterr().err


def test_verify_offline_happy_path(tmp_path: Path) -> None:
    _old_leaves, old_root = _state_for(7)
    all_leaves, new_root = _state_for(20)
    proof_hex = [h.hex() for h in generate_consistency_proof(all_leaves, 7)]

    first = tmp_path / "first.json"
    first.write_text(json.dumps({"tree_size": 7, "root_hash": old_root.hex()}))
    second = tmp_path / "second.json"
    second.write_text(json.dumps({"tree_size": 20, "root_hash": new_root.hex()}))
    proof = tmp_path / "proof.json"
    proof.write_text(json.dumps({"hashes": proof_hex}))

    rc = main(
        [
            "verify-offline",
            "--first",
            str(first),
            "--second",
            str(second),
            "--proof",
            str(proof),
        ]
    )
    assert rc == 0


def test_verify_offline_rejects_forged(tmp_path: Path) -> None:
    """Offline verifier rejects a tampered proof."""
    _old_leaves, old_root = _state_for(7)
    all_leaves, new_root = _state_for(20)
    proof_bytes = generate_consistency_proof(all_leaves, 7)
    # Flip a byte in the first hash.
    flipped = bytearray(proof_bytes[0])
    flipped[0] ^= 0xFF
    proof_hex = [bytes(flipped).hex(), *[h.hex() for h in proof_bytes[1:]]]

    first = tmp_path / "first.json"
    first.write_text(json.dumps({"tree_size": 7, "root_hash": old_root.hex()}))
    second = tmp_path / "second.json"
    second.write_text(json.dumps({"tree_size": 20, "root_hash": new_root.hex()}))
    proof = tmp_path / "proof.json"
    proof.write_text(json.dumps({"hashes": proof_hex}))

    rc = main(
        [
            "verify-offline",
            "--first",
            str(first),
            "--second",
            str(second),
            "--proof",
            str(proof),
        ]
    )
    assert rc == 1


@respx.mock
def test_verify_network_error_returns_2(tmp_path: Path) -> None:
    pinned = tmp_path / "pinned.json"
    pinned.write_text(
        json.dumps(
            {"url": _BASE, "tree_size": 5, "root_hash": bytes(32).hex(), "tree_id": None}
        )
    )
    respx.get(f"{_BASE}/api/v1/log").mock(return_value=httpx.Response(500))
    rc = main(["verify", "--pinned", str(pinned), "--url", _BASE])
    assert rc == 2
