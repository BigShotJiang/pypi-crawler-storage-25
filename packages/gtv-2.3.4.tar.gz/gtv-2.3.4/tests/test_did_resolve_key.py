"""Tests for did:key DID parsing.

Covers:
1. Valid did:key DIDs (Ed25519, secp256k1).
2. Invalid base58btc encoding.
3. Unknown multicodec prefixes.
4. Malformed DIDs.
"""
from __future__ import annotations

import pytest

from gtv.did.resolve import DIDResolutionError, resolve_did
from gtv.did.resolve_key import ParsedDIDKey, parse_did_key


class TestParseDIDKey:
    """Unit tests for parse_did_key."""

    def test_parse_ed25519_canonical_example(self) -> None:
        """Parse canonical Ed25519 did:key from W3C spec."""
        did = "did:key:z6MkpTHR8VNsBxYAAWHut2Geadd9jSwuBV8xRoAnwWsdvktH"
        result = parse_did_key(did)

        assert isinstance(result, ParsedDIDKey)
        assert result.key_type == "Ed25519"
        assert len(result.public_key_bytes) == 32
        # Verify it's actually bytes, not str
        assert isinstance(result.public_key_bytes, bytes)

    def test_parse_ed25519_multiple_keys(self) -> None:
        """Ed25519 parsing is stable and reproducible."""
        did = "did:key:z6MkpTHR8VNsBxYAAWHut2Geadd9jSwuBV8xRoAnwWsdvktH"
        result1 = parse_did_key(did)
        result2 = parse_did_key(did)

        assert result1.key_type == result2.key_type == "Ed25519"
        assert result1.public_key_bytes == result2.public_key_bytes
        assert len(result1.public_key_bytes) == 32

    def test_parse_secp256k1_valid_did(self) -> None:
        """Parse valid secp256k1 did:key."""
        # secp256k1 multicodec: 0xe7 0x01 + 33-byte compressed point
        # Using a known secp256k1 did:key from W3C spec
        did = "did:key:zQ3shbgnTGcgL6CEJrvS3hoGUcMXBAKWfqHDQV2nrtBKt9hF4"
        result = parse_did_key(did)

        assert result.key_type == "secp256k1"
        assert len(result.public_key_bytes) == 33

    def test_parse_non_did_key_raises_error(self) -> None:
        """Reject non-did:key DIDs."""
        with pytest.raises(ValueError, match="Invalid did:key format"):
            parse_did_key("did:web:example.com")

    def test_parse_did_key_wrong_prefix_raises_error(self) -> None:
        """Reject did:key without 'z' multibase prefix."""
        with pytest.raises(ValueError, match="Invalid did:key format"):
            parse_did_key("did:key:u6MkpTHR8VNsBxYAAWHut2Geadd9jSwuBV8xRoAnwWsdvktH")

    def test_parse_did_key_empty_key_material_raises_error(self) -> None:
        """Reject did:key:z with no key material."""
        with pytest.raises(ValueError, match="no key material"):
            parse_did_key("did:key:z")

    def test_parse_did_key_invalid_base58_raises_error(self) -> None:
        """Reject invalid base58btc characters."""
        with pytest.raises(ValueError, match="Invalid base58btc"):
            # 'O', 'I', 'l', '0' are not in base58btc alphabet
            parse_did_key("did:key:zOIl0")

    def test_parse_did_key_unknown_multicodec_raises_error(self) -> None:
        """Reject unknown multicodec prefix."""
        # Generate a valid base58btc string that decodes to an unknown multicodec
        with pytest.raises(ValueError, match="Unknown multicodec"):
            # This will decode to bytes starting with unknown prefix
            parse_did_key("did:key:z11")  # 0x11 is not a valid multicodec we support

    def test_parse_did_key_too_short_decoded_bytes_raises_error(self) -> None:
        """Reject decoded material shorter than multicodec prefix."""
        with pytest.raises(ValueError, match="too short"):
            # Single byte after decode, cannot be multicodec
            parse_did_key("did:key:zz")

    def test_parse_non_string_raises_error(self) -> None:
        """Reject non-string DID input."""
        with pytest.raises(ValueError, match="must be a string"):
            parse_did_key(123)  # type: ignore


class TestResolveDIDDispatcher:
    """Test resolve_did dispatcher routing."""

    def test_resolve_did_routes_to_did_web(self) -> None:
        """resolve_did routes did:web to parse_did_web."""
        result = resolve_did("did:web:example.com")
        assert "url" in result
        assert result["url"] == "https://example.com/.well-known/did.json"

    def test_resolve_did_routes_to_did_key(self) -> None:
        """resolve_did routes did:key to parse_did_key."""
        result = resolve_did("did:key:z6MkpTHR8VNsBxYAAWHut2Geadd9jSwuBV8xRoAnwWsdvktH")
        assert "key_type" in result
        assert "public_key_bytes" in result
        assert result["key_type"] == "Ed25519"
        assert len(result["public_key_bytes"]) == 32

    def test_resolve_did_rejects_unsupported_method(self) -> None:
        """resolve_did rejects unsupported DID methods."""
        with pytest.raises(DIDResolutionError, match="Unsupported DID method: ethr"):
            resolve_did("did:ethr:0x123456")

    def test_resolve_did_rejects_malformed_did(self) -> None:
        """resolve_did rejects malformed DIDs."""
        with pytest.raises(DIDResolutionError, match="Unsupported DID method"):
            resolve_did("not-a-did")

    def test_resolve_did_rejects_non_string(self) -> None:
        """resolve_did rejects non-string input."""
        with pytest.raises(DIDResolutionError, match="must be a string"):
            resolve_did(123)  # type: ignore

    def test_resolve_did_key_parsing_error_wrapped(self) -> None:
        """resolve_did wraps did:key parsing errors as DIDResolutionError."""
        with pytest.raises(DIDResolutionError, match="Failed to parse did:key"):
            resolve_did("did:key:zInvalidBase58!")
