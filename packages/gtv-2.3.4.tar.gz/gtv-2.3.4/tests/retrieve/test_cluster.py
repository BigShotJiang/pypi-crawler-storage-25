"""Tests for evidence clustering."""
from __future__ import annotations

from datetime import UTC, datetime

from pydantic import HttpUrl

from gtv.models import Evidence, Stance
from gtv.retrieve.cluster import cluster


def _make_evidence(
    evidence_id: str = "test-id",
    source_did: str = "did:web:arxiv.org",
    source_version: str = "v1",
    excerpt: str = "Test excerpt",
    url: str = "https://arxiv.org/abs/1234.5678",
    stance: Stance = Stance.SUPPORTS,
) -> Evidence:
    """Create a test Evidence instance."""
    return Evidence(
        evidence_id=evidence_id,
        claim_id="test-claim",
        source_did=source_did,
        source_version=source_version,
        stance=stance,
        excerpt=excerpt,
        url=HttpUrl(url),
        retrieved_at=datetime(2026, 4, 22, 12, 0, 0, tzinfo=UTC),
        raw_hash="0" * 64,
    )


def test_cluster_empty_list():
    """Empty input returns empty output."""
    result = cluster([])
    assert result == []


def test_cluster_single_element():
    """Single element gets its own cluster."""
    e = _make_evidence(evidence_id="e1")
    result = cluster([e])
    assert len(result) == 1
    assert len(result[0]) == 1
    assert result[0][0].evidence_id == "e1"


def test_cluster_identical_excerpts():
    """Identical excerpts cluster together."""
    e1 = _make_evidence(evidence_id="e1", excerpt="The quick brown fox jumps over the lazy dog")
    e2 = _make_evidence(evidence_id="e2", excerpt="The quick brown fox jumps over the lazy dog")

    result = cluster([e1, e2])
    assert len(result) == 1
    assert len(result[0]) == 2
    assert {e.evidence_id for e in result[0]} == {"e1", "e2"}


def test_cluster_disjoint_excerpts_dont_cluster():
    """Disjoint excerpts don't cluster together."""
    e1 = _make_evidence(evidence_id="e1", excerpt="The quick brown fox")
    e2 = _make_evidence(evidence_id="e2", excerpt="Machine learning algorithms")

    result = cluster([e1, e2])
    assert len(result) == 2
    assert all(len(c) == 1 for c in result)


def test_cluster_similarity_threshold():
    """Jaccard similarity >= 0.5 clusters together."""
    # These excerpts should have ~50% overlap (5 unique in first, 5 unique in second, 4 shared)
    # Overlap: "the", "quick", "brown", "fox" (4 shared) vs 10 unique each
    # Similarity = 4 / (6 + 6 + 4) = 4/8 = 0.5 (approximately)
    e1 = _make_evidence(evidence_id="e1", excerpt="The quick brown fox")
    e2 = _make_evidence(evidence_id="e2", excerpt="The quick brown dog")

    result = cluster([e1, e2])
    # Should cluster (similarity >= 0.5)
    assert len(result) == 1
    assert len(result[0]) == 2


def test_cluster_low_similarity_no_cluster():
    """Low Jaccard similarity (< 0.5) doesn't cluster."""
    # These have minimal overlap
    e1 = _make_evidence(evidence_id="e1", excerpt="The quick brown fox jumps")
    e2 = _make_evidence(evidence_id="e2", excerpt="Computer science machine learning")

    result = cluster([e1, e2])
    assert len(result) == 2
    assert all(len(c) == 1 for c in result)


def test_cluster_sorted_by_size_descending():
    """Clusters are sorted by size descending."""
    # Create 3 clusters: size 3, 2, 1
    e1 = _make_evidence(evidence_id="e1", excerpt="The quick brown fox")
    e2 = _make_evidence(evidence_id="e2", excerpt="The quick brown fox")
    e3 = _make_evidence(evidence_id="e3", excerpt="The quick brown fox")
    e4 = _make_evidence(evidence_id="e4", excerpt="Machine learning algorithms")
    e5 = _make_evidence(evidence_id="e5", excerpt="Machine learning algorithms")
    e6 = _make_evidence(evidence_id="e6", excerpt="Completely different text")

    result = cluster([e1, e2, e3, e4, e5, e6])
    assert len(result) == 3
    # Check sizes are descending
    assert len(result[0]) >= len(result[1]) >= len(result[2])
    # Specifically: [3, 2, 1]
    assert len(result[0]) == 3
    assert len(result[1]) == 2
    assert len(result[2]) == 1


def test_cluster_preserves_evidence_objects():
    """Clustering preserves the original Evidence objects."""
    e1 = _make_evidence(evidence_id="e1", excerpt="Test text")
    e2 = _make_evidence(evidence_id="e2", excerpt="Test text")

    result = cluster([e1, e2])
    assert len(result) == 1
    # Check that the actual objects are present
    assert e1 in result[0]
    assert e2 in result[0]


def test_cluster_stopword_handling():
    """Stopwords are removed during tokenization."""
    # "the", "and", "of" are stopwords — should be ignored
    e1 = _make_evidence(evidence_id="e1", excerpt="The dog and the cat of the house")
    e2 = _make_evidence(evidence_id="e2", excerpt="dog cat house")

    result = cluster([e1, e2])
    # Should cluster because after removing stopwords they're identical
    assert len(result) == 1
    assert len(result[0]) == 2


def test_cluster_case_insensitive():
    """Clustering is case-insensitive."""
    e1 = _make_evidence(evidence_id="e1", excerpt="The Quick Brown Fox")
    e2 = _make_evidence(evidence_id="e2", excerpt="the quick brown fox")

    result = cluster([e1, e2])
    assert len(result) == 1
    assert len(result[0]) == 2


def test_cluster_transitive_clustering():
    """Transitive clustering via single-link (A~B and B~C means A~C)."""
    # e1 and e2 are very similar
    e1 = _make_evidence(evidence_id="e1", excerpt="The quick brown fox jumps over the lazy dog")
    e2 = _make_evidence(evidence_id="e2", excerpt="The quick brown fox jumps over the lazy cat")
    # e2 and e3 are very similar
    e3 = _make_evidence(evidence_id="e3", excerpt="The quick brown fox jumps over the lazy bird")

    result = cluster([e1, e2, e3])
    # All should be in the same cluster via transitive linking
    assert len(result) == 1
    assert len(result[0]) == 3
