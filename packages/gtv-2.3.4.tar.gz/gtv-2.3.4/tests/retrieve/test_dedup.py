"""Tests for evidence deduplication."""
from __future__ import annotations

from datetime import UTC, datetime
from unittest.mock import Mock, patch

from pydantic import HttpUrl

from gtv.models import Evidence, Stance, TrustTier
from gtv.retrieve.dedup import deduplicate


def _make_evidence(
    evidence_id: str = "test-id",
    source_did: str = "did:web:arxiv.org",
    source_version: str = "v1",
    excerpt: str = "Test excerpt",
    url: str = "https://arxiv.org/abs/1234.5678",
    retrieved_at: datetime | None = None,
    stance: Stance = Stance.SUPPORTS,
) -> Evidence:
    """Create a test Evidence instance."""
    if retrieved_at is None:
        retrieved_at = datetime(2026, 4, 22, 12, 0, 0, tzinfo=UTC)

    return Evidence(
        evidence_id=evidence_id,
        claim_id="test-claim",
        source_did=source_did,
        source_version=source_version,
        stance=stance,
        excerpt=excerpt,
        url=HttpUrl(url),
        retrieved_at=retrieved_at,
        raw_hash="0" * 64,
    )


def test_dedup_empty_list():
    """Empty input returns empty output."""
    result = deduplicate([])
    assert result == []


def test_dedup_single_element():
    """Single element input returns that element."""
    e = _make_evidence(evidence_id="e1")
    result = deduplicate([e])
    assert len(result) == 1
    assert result[0].evidence_id == "e1"


def test_dedup_exact_duplicate_excerpts():
    """Exact-duplicate excerpts collapse to one (higher trust_tier wins)."""
    e1 = _make_evidence(
        evidence_id="e1",
        source_did="did:web:arxiv.org",  # TIER_2
        excerpt="The quick brown fox jumps over the lazy dog",
    )
    e2 = _make_evidence(
        evidence_id="e2",
        source_did="did:web:crossref.org",  # TIER_2 (assume same)
        excerpt="The quick brown fox jumps over the lazy dog",
    )

    with patch("gtv.retrieve.dedup.REGISTRY") as mock_registry:
        mock_arxiv = Mock()
        mock_arxiv.trust_tier = TrustTier.TIER_1
        mock_crossref = Mock()
        mock_crossref.trust_tier = TrustTier.TIER_2

        mock_registry.__contains__.side_effect = lambda x: x in ("did:web:arxiv.org", "did:web:crossref.org")
        mock_registry.__getitem__.side_effect = lambda x: (
            mock_arxiv if x == "did:web:arxiv.org" else mock_crossref
        )

        result = deduplicate([e1, e2])
        assert len(result) == 1
        assert result[0].evidence_id == "e1"  # TIER_1 wins


def test_dedup_doi_sharing_evidences():
    """Evidences sharing a DOI collapse to one."""
    e1 = _make_evidence(
        evidence_id="e1",
        source_did="did:web:arxiv.org",
        excerpt="Paper about machine learning",
        url="https://arxiv.org/abs/1234.5678?10.1038/nature12373",
    )
    e2 = _make_evidence(
        evidence_id="e2",
        source_did="did:web:crossref.org",
        excerpt="Different text but same paper",
        url="https://doi.org/10.1038/nature12373",
    )

    with patch("gtv.retrieve.dedup.REGISTRY") as mock_registry:
        mock_arxiv = Mock()
        mock_arxiv.trust_tier = TrustTier.TIER_2
        mock_crossref = Mock()
        mock_crossref.trust_tier = TrustTier.TIER_1

        mock_registry.__contains__.side_effect = lambda x: x in ("did:web:arxiv.org", "did:web:crossref.org")
        mock_registry.__getitem__.side_effect = lambda x: (
            mock_arxiv if x == "did:web:arxiv.org" else mock_crossref
        )

        result = deduplicate([e1, e2])
        assert len(result) == 1
        assert result[0].evidence_id == "e2"  # TIER_1 wins


def test_dedup_unrelated_evidences_dont_collapse():
    """Unrelated evidences with different content and URLs don't collapse."""
    e1 = _make_evidence(
        evidence_id="e1",
        source_did="did:web:arxiv.org",
        excerpt="The quick brown fox",
        url="https://arxiv.org/abs/1111.1111",
    )
    e2 = _make_evidence(
        evidence_id="e2",
        source_did="did:web:crossref.org",
        excerpt="The lazy dog sleeps",
        url="https://arxiv.org/abs/2222.2222",
    )

    with patch("gtv.retrieve.dedup.REGISTRY") as mock_registry:
        mock_arxiv = Mock()
        mock_arxiv.trust_tier = TrustTier.TIER_2
        mock_crossref = Mock()
        mock_crossref.trust_tier = TrustTier.TIER_2

        mock_registry.__contains__.side_effect = lambda x: x in ("did:web:arxiv.org", "did:web:crossref.org")
        mock_registry.__getitem__.side_effect = lambda x: (
            mock_arxiv if x == "did:web:arxiv.org" else mock_crossref
        )

        result = deduplicate([e1, e2])
        assert len(result) == 2
        # Check original order preserved
        assert result[0].evidence_id == "e1"
        assert result[1].evidence_id == "e2"


def test_dedup_trust_tier_tiebreak():
    """When excerpts match but trust_tier is same, use retrieved_at for tiebreak."""
    earlier = datetime(2026, 4, 20, 12, 0, 0, tzinfo=UTC)
    later = datetime(2026, 4, 22, 12, 0, 0, tzinfo=UTC)

    e1 = _make_evidence(
        evidence_id="e1",
        source_did="did:web:arxiv.org",
        excerpt="The quick brown fox",
        retrieved_at=earlier,
    )
    e2 = _make_evidence(
        evidence_id="e2",
        source_did="did:web:crossref.org",
        excerpt="The quick brown fox",
        retrieved_at=later,
    )

    with patch("gtv.retrieve.dedup.REGISTRY") as mock_registry:
        mock_arxiv = Mock()
        mock_arxiv.trust_tier = TrustTier.TIER_2
        mock_crossref = Mock()
        mock_crossref.trust_tier = TrustTier.TIER_2

        mock_registry.__contains__.side_effect = lambda x: x in ("did:web:arxiv.org", "did:web:crossref.org")
        mock_registry.__getitem__.side_effect = lambda x: (
            mock_arxiv if x == "did:web:arxiv.org" else mock_crossref
        )

        result = deduplicate([e1, e2])
        assert len(result) == 1
        assert result[0].evidence_id == "e2"  # More recent wins


def test_dedup_preserves_original_order():
    """Kept evidences maintain original order."""
    e1 = _make_evidence(evidence_id="e1", source_did="did:web:arxiv.org", excerpt="Unique text 1", url="https://arxiv.org/abs/1111.1111")
    e2 = _make_evidence(evidence_id="e2", source_did="did:web:crossref.org", excerpt="Unique text 2", url="https://arxiv.org/abs/2222.2222")
    e3 = _make_evidence(evidence_id="e3", source_did="did:web:pubmed.org", excerpt="Unique text 3", url="https://arxiv.org/abs/3333.3333")

    with patch("gtv.retrieve.dedup.REGISTRY") as mock_registry:
        mock_arxiv = Mock()
        mock_arxiv.trust_tier = TrustTier.TIER_2
        mock_crossref = Mock()
        mock_crossref.trust_tier = TrustTier.TIER_2
        mock_pubmed = Mock()
        mock_pubmed.trust_tier = TrustTier.TIER_2

        mock_registry.__contains__.side_effect = lambda x: x in ("did:web:arxiv.org", "did:web:crossref.org", "did:web:pubmed.org")
        mock_registry.__getitem__.side_effect = lambda x: {
            "did:web:arxiv.org": mock_arxiv,
            "did:web:crossref.org": mock_crossref,
            "did:web:pubmed.org": mock_pubmed,
        }.get(x)

        result = deduplicate([e1, e2, e3])
        assert len(result) == 3
        assert [e.evidence_id for e in result] == ["e1", "e2", "e3"]


def test_dedup_pmid_matching():
    """Evidences sharing a PMID are duplicates."""
    e1 = _make_evidence(
        evidence_id="e1",
        source_did="did:web:pubmed.org",
        excerpt="PubMed article",
        url="https://pubmed.ncbi.nlm.nih.gov/12345678",
    )
    e2 = _make_evidence(
        evidence_id="e2",
        source_did="did:web:europepmc.org",
        excerpt="Different wording same article",
        url="https://europepmc.org/article/12345678",
    )

    with patch("gtv.retrieve.dedup.REGISTRY") as mock_registry:
        mock_pubmed = Mock()
        mock_pubmed.trust_tier = TrustTier.TIER_2
        mock_europepmc = Mock()
        mock_europepmc.trust_tier = TrustTier.TIER_2

        mock_registry.__contains__.side_effect = lambda x: x in ("did:web:pubmed.org", "did:web:europepmc.org")
        mock_registry.__getitem__.side_effect = lambda x: (
            mock_pubmed if x == "did:web:pubmed.org" else mock_europepmc
        )

        result = deduplicate([e1, e2])
        assert len(result) == 1
