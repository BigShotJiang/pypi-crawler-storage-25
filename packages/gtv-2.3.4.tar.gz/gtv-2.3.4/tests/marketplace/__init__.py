"""Tests for the plugin marketplace."""
