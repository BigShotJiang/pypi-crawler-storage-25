"""Tests for PluginManifest schema and JSON Schema export.

Covers:
- Valid manifest creation
- Field validation (slug, version, DID, license, entry_point, description)
- JSON Schema export with expected keys
"""
from __future__ import annotations

import pytest
from pydantic import ValidationError

from gtv.marketplace.manifest import PluginManifest


class TestManifestValidation:
    """Test PluginManifest field validation."""

    @pytest.fixture
    def valid_manifest_data(self) -> dict:
        """Base valid manifest data."""
        return {
            "name": "my-adapter",
            "version": "1.0.0",
            "author": "John Doe",
            "description": "A simple test adapter",
            "homepage": "https://example.com/my-adapter",
            "entry_point": "my_pkg.adapter:MyAdapter",
            "source_did": "did:web:example.com",
            "trust_tier_claim": "tier_1",
            "license": "MIT",
        }

    def test_accepts_valid_manifest(self, valid_manifest_data: dict) -> None:
        """Valid manifest should be accepted."""
        manifest = PluginManifest.model_validate(valid_manifest_data)
        assert manifest.name == "my-adapter"
        assert manifest.version == "1.0.0"
        assert manifest.signed_sha256 is None
        assert manifest.published_at is None

    def test_rejects_invalid_slug(self, valid_manifest_data: dict) -> None:
        """Reject name with uppercase, underscores, or other invalid chars."""
        invalid_names = [
            "MyAdapter",  # uppercase
            "my_adapter",  # underscore
            "my adapter",  # space
            "my.adapter",  # dot
            "-my-adapter",  # leading dash
            "my-adapter-",  # trailing dash
        ]
        for invalid_name in invalid_names:
            data = valid_manifest_data.copy()
            data["name"] = invalid_name
            with pytest.raises(ValidationError) as exc_info:
                PluginManifest.model_validate(data)
            assert "slug" in str(exc_info.value).lower() or "lowercase" in str(exc_info.value).lower()

    def test_accepts_valid_slug(self, valid_manifest_data: dict) -> None:
        """Accept valid slug forms."""
        valid_names = [
            "adapter",
            "my-adapter",
            "my-adapter-v1",
            "adapter123",
        ]
        for valid_name in valid_names:
            data = valid_manifest_data.copy()
            data["name"] = valid_name
            manifest = PluginManifest.model_validate(data)
            assert manifest.name == valid_name

    def test_rejects_invalid_version(self, valid_manifest_data: dict) -> None:
        """Reject non-PEP440 versions."""
        invalid_versions = [
            "not-a-version",  # clearly invalid
            "version_1_0_0",  # invalid format
        ]
        for invalid_version in invalid_versions:
            data = valid_manifest_data.copy()
            data["version"] = invalid_version
            with pytest.raises(ValidationError) as exc_info:
                PluginManifest.model_validate(data)
            assert "version" in str(exc_info.value).lower()

    def test_accepts_valid_version(self, valid_manifest_data: dict) -> None:
        """Accept PEP440 compliant versions."""
        valid_versions = [
            "1.0.0",
            "1.0.0a1",
            "1.0.0rc1",
            "2.1.3.post1",
        ]
        for valid_version in valid_versions:
            data = valid_manifest_data.copy()
            data["version"] = valid_version
            manifest = PluginManifest.model_validate(data)
            assert manifest.version == valid_version

    def test_rejects_invalid_entry_point(self, valid_manifest_data: dict) -> None:
        """Reject malformed entry_point."""
        invalid_eps = [
            "MyAdapter",  # missing colon
            "my_pkg.adapter:",  # missing class
            ":MyAdapter",  # missing module
            "my pkg.adapter:MyAdapter",  # space in module
            "my-pkg.adapter:MyAdapter",  # dash in module
        ]
        for invalid_ep in invalid_eps:
            data = valid_manifest_data.copy()
            data["entry_point"] = invalid_ep
            with pytest.raises(ValidationError) as exc_info:
                PluginManifest.model_validate(data)
            assert "entry_point" in str(exc_info.value).lower()

    def test_accepts_valid_entry_point(self, valid_manifest_data: dict) -> None:
        """Accept valid entry_point formats."""
        valid_eps = [
            "my_pkg.adapter:MyAdapter",
            "foo.bar.baz:Adapter",
            "a:B",
            "foo.bar.baz.qux:MyClass123",
        ]
        for valid_ep in valid_eps:
            data = valid_manifest_data.copy()
            data["entry_point"] = valid_ep
            manifest = PluginManifest.model_validate(data)
            assert manifest.entry_point == valid_ep

    def test_rejects_invalid_did(self, valid_manifest_data: dict) -> None:
        """Reject DID not starting with did:web: or did:key:."""
        invalid_dids = [
            "did:jwk:...",
            "example.com",
            "https://example.com",
        ]
        for invalid_did in invalid_dids:
            data = valid_manifest_data.copy()
            data["source_did"] = invalid_did
            with pytest.raises(ValidationError) as exc_info:
                PluginManifest.model_validate(data)
            assert "did" in str(exc_info.value).lower()

    def test_accepts_valid_did(self, valid_manifest_data: dict) -> None:
        """Accept did:web: and did:key: formats."""
        valid_dids = [
            "did:web:example.com",
            "did:web:example.com:path",
            "did:key:z6MkhaXgBZDvotzL8V6N7uRLYtCQZWWVJ8n617efa98Gd2qK",
        ]
        for valid_did in valid_dids:
            data = valid_manifest_data.copy()
            data["source_did"] = valid_did
            manifest = PluginManifest.model_validate(data)
            assert manifest.source_did == valid_did

    def test_rejects_unlicensed(self, valid_manifest_data: dict) -> None:
        """Reject license not in allowlist."""
        data = valid_manifest_data.copy()
        data["license"] = "GPL-3.0"
        with pytest.raises(ValidationError) as exc_info:
            PluginManifest.model_validate(data)
        assert "license" in str(exc_info.value).lower()

    def test_accepts_allowed_licenses(self, valid_manifest_data: dict) -> None:
        """Accept licenses from the allowlist."""
        allowed = ["MIT", "Apache-2.0", "BSD-3-Clause", "MPL-2.0"]
        for lic in allowed:
            data = valid_manifest_data.copy()
            data["license"] = lic
            manifest = PluginManifest.model_validate(data)
            assert manifest.license == lic

    def test_rejects_oversized_description(self, valid_manifest_data: dict) -> None:
        """Reject description > 500 chars."""
        data = valid_manifest_data.copy()
        data["description"] = "x" * 501
        with pytest.raises(ValidationError) as exc_info:
            PluginManifest.model_validate(data)
        assert "description" in str(exc_info.value).lower()

    def test_accepts_max_length_description(self, valid_manifest_data: dict) -> None:
        """Accept description at exactly 500 chars."""
        data = valid_manifest_data.copy()
        data["description"] = "x" * 500
        manifest = PluginManifest.model_validate(data)
        assert len(manifest.description) == 500

    def test_rejects_invalid_sha256(self, valid_manifest_data: dict) -> None:
        """Reject malformed signed_sha256."""
        data = valid_manifest_data.copy()
        data["signed_sha256"] = "not-hex"
        with pytest.raises(ValidationError) as exc_info:
            PluginManifest.model_validate(data)
        assert "signed_sha256" in str(exc_info.value).lower()

    def test_accepts_valid_sha256(self, valid_manifest_data: dict) -> None:
        """Accept valid SHA256 hex strings (case-insensitive)."""
        data = valid_manifest_data.copy()
        data["signed_sha256"] = "a" * 64
        manifest = PluginManifest.model_validate(data)
        assert manifest.signed_sha256 == "a" * 64

        data["signed_sha256"] = "A" * 64
        manifest = PluginManifest.model_validate(data)
        assert manifest.signed_sha256 == "a" * 64  # normalized to lowercase

    def test_accepts_none_optional_fields(self, valid_manifest_data: dict) -> None:
        """Accept None for signed_sha256 and published_at."""
        manifest = PluginManifest.model_validate(valid_manifest_data)
        assert manifest.signed_sha256 is None
        assert manifest.published_at is None


class TestJSONSchema:
    """Test JSON Schema export."""

    def test_json_schema_export(self) -> None:
        """JSON Schema should export with expected keys."""
        schema = PluginManifest.model_json_schema(by_alias=True, ref_template='{model}.json#/$defs/{model}')

        # Check top-level structure
        assert "properties" in schema
        assert "required" in schema
        assert "type" in schema
        assert schema["type"] == "object"

        # Check required fields
        required = schema["required"]
        assert "name" in required
        assert "version" in required
        assert "author" in required
        assert "description" in required
        assert "homepage" in required
        assert "entry_point" in required
        assert "source_did" in required
        assert "trust_tier_claim" in required
        assert "license" in required

        # Check optional fields (not in required)
        assert "signed_sha256" not in required
        assert "published_at" not in required

        # Check that all required fields have property definitions
        props = schema["properties"]
        for field in required:
            assert field in props

    def test_json_schema_has_descriptions(self) -> None:
        """JSON Schema properties should have descriptions."""
        schema = PluginManifest.model_json_schema(by_alias=True, ref_template='{model}.json#/$defs/{model}')
        props = schema["properties"]

        # Spot-check a few properties for descriptions
        assert "description" in props["name"]
        assert "description" in props["version"]
        assert "description" in props["entry_point"]
