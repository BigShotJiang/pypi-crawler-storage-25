"""Tests for the gtv-marketplace CLI.

Covers:
- publish: happy path, missing wheel, duplicate rejection
- list: filter by name, empty registry
- show: found/not-found
- validate: good and bad manifests
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from gtv.cli import marketplace as cli
from gtv.marketplace.manifest import PluginManifest


@pytest.fixture
def tmp_registry(tmp_path: Path) -> Path:
    """Temporary registry file path."""
    registry_file = tmp_path / "marketplace.jsonl"
    return registry_file


@pytest.fixture
def valid_manifest_toml(tmp_path: Path) -> Path:
    """Create a valid manifest TOML file."""
    toml_content = """
[plugin]
name = "test-adapter"
version = "1.0.0"
author = "Test Author"
description = "A test adapter"
homepage = "https://example.com"
entry_point = "test_pkg.adapter:TestAdapter"
source_did = "did:web:example.com"
trust_tier_claim = "tier_1"
license = "MIT"
"""
    toml_file = tmp_path / "manifest.toml"
    toml_file.write_text(toml_content)
    return toml_file


@pytest.fixture
def valid_wheel_file(tmp_path: Path) -> Path:
    """Create a dummy wheel file."""
    wheel_file = tmp_path / "test_adapter-1.0.0-py3-none-any.whl"
    wheel_file.write_bytes(b"fake wheel content")
    return wheel_file


class TestPublishCommand:
    """Test gtv-marketplace publish."""

    def test_publish_happy_path(
        self, tmp_registry: Path, valid_manifest_toml: Path, valid_wheel_file: Path
    ) -> None:
        """Publish a valid manifest with wheel."""
        argv = [
            "publish",
            str(valid_manifest_toml),
            "--wheel",
            str(valid_wheel_file),
            "--registry",
            str(tmp_registry),
        ]
        rc = cli.main(argv)
        assert rc == 0

        # Verify manifest was written to registry
        assert tmp_registry.exists()
        manifests = []
        with open(tmp_registry, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    manifests.append(json.loads(line))
        assert len(manifests) == 1
        assert manifests[0]["name"] == "test-adapter"
        assert manifests[0]["version"] == "1.0.0"
        assert manifests[0]["signed_sha256"] is not None
        assert manifests[0]["published_at"] is not None

    def test_publish_without_wheel(
        self, tmp_registry: Path, valid_manifest_toml: Path
    ) -> None:
        """Publish without specifying wheel (signed_sha256 should be None)."""
        argv = [
            "publish",
            str(valid_manifest_toml),
            "--registry",
            str(tmp_registry),
        ]
        rc = cli.main(argv)
        assert rc == 0

        manifests = []
        with open(tmp_registry, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    manifests.append(json.loads(line))
        assert len(manifests) == 1
        assert manifests[0]["signed_sha256"] is None

    def test_publish_missing_wheel(
        self, tmp_registry: Path, valid_manifest_toml: Path
    ) -> None:
        """Reject publish if specified wheel file does not exist."""
        argv = [
            "publish",
            str(valid_manifest_toml),
            "--wheel",
            "/nonexistent/wheel.whl",
            "--registry",
            str(tmp_registry),
        ]
        rc = cli.main(argv)
        assert rc == 3  # File not found

    def test_publish_duplicate_rejection(
        self, tmp_registry: Path, valid_manifest_toml: Path, valid_wheel_file: Path
    ) -> None:
        """Reject duplicate publish (same name + version)."""
        argv = [
            "publish",
            str(valid_manifest_toml),
            "--wheel",
            str(valid_wheel_file),
            "--registry",
            str(tmp_registry),
        ]
        rc = cli.main(argv)
        assert rc == 0

        # Try to publish again
        rc = cli.main(argv)
        assert rc == 1  # Duplicate error

    def test_publish_missing_manifest_file(self, tmp_registry: Path) -> None:
        """Reject publish if manifest file does not exist."""
        argv = [
            "publish",
            "/nonexistent/manifest.toml",
            "--registry",
            str(tmp_registry),
        ]
        rc = cli.main(argv)
        assert rc == 3

    def test_publish_no_arguments(self) -> None:
        """Reject publish with no manifest argument."""
        argv = ["publish"]
        rc = cli.main(argv)
        assert rc == 2

    def test_publish_invalid_toml(self, tmp_path: Path, tmp_registry: Path) -> None:
        """Reject publish with malformed TOML."""
        bad_toml = tmp_path / "bad.toml"
        bad_toml.write_text("this is not valid toml {{{")
        argv = [
            "publish",
            str(bad_toml),
            "--registry",
            str(tmp_registry),
        ]
        rc = cli.main(argv)
        assert rc == 4  # TOML parse error

    def test_publish_missing_manifest_section(
        self, tmp_path: Path, tmp_registry: Path
    ) -> None:
        """Reject TOML without [plugin] or [marketplace] section."""
        bad_toml = tmp_path / "nometa.toml"
        bad_toml.write_text("[other]\nkey = 'value'")
        argv = [
            "publish",
            str(bad_toml),
            "--registry",
            str(tmp_registry),
        ]
        rc = cli.main(argv)
        assert rc == 1

    def test_publish_invalid_manifest_schema(
        self, tmp_path: Path, tmp_registry: Path
    ) -> None:
        """Reject TOML with invalid manifest schema."""
        bad_toml = tmp_path / "badschema.toml"
        bad_toml.write_text(
            """
[plugin]
name = "INVALID"  # uppercase not allowed
version = "1.0.0"
author = "Test"
description = "Test"
homepage = "https://example.com"
entry_point = "test:Test"
source_did = "did:web:example.com"
trust_tier_claim = "tier_1"
license = "MIT"
"""
        )
        argv = [
            "publish",
            str(bad_toml),
            "--registry",
            str(tmp_registry),
        ]
        rc = cli.main(argv)
        assert rc == 1


class TestListCommand:
    """Test gtv-marketplace list."""

    def test_list_empty_registry(self, tmp_registry: Path) -> None:
        """List from non-existent registry should show 'no plugins'."""
        argv = ["list", "--registry", str(tmp_registry)]
        rc = cli.main(argv)
        assert rc == 0

    def test_list_single_plugin(
        self, tmp_registry: Path, valid_manifest_toml: Path
    ) -> None:
        """List should show a single published plugin."""
        publish_argv = [
            "publish",
            str(valid_manifest_toml),
            "--registry",
            str(tmp_registry),
        ]
        cli.main(publish_argv)

        argv = ["list", "--registry", str(tmp_registry)]
        rc = cli.main(argv)
        assert rc == 0

    def test_list_with_name_filter(
        self, tmp_registry: Path, valid_manifest_toml: Path
    ) -> None:
        """List with --name filter should match by prefix."""
        publish_argv = [
            "publish",
            str(valid_manifest_toml),
            "--registry",
            str(tmp_registry),
        ]
        cli.main(publish_argv)

        # Filter matches
        argv = ["list", "--name", "test", "--registry", str(tmp_registry)]
        rc = cli.main(argv)
        assert rc == 0

        # Filter does not match
        argv = ["list", "--name", "other", "--registry", str(tmp_registry)]
        rc = cli.main(argv)
        assert rc == 0  # Still succeeds, just shows no matches

    def test_list_multiple_versions(
        self, tmp_registry: Path, tmp_path: Path
    ) -> None:
        """List should show latest version of each plugin."""
        # Create two versions of the same plugin
        toml_v1 = tmp_path / "manifest_v1.toml"
        toml_v1.write_text(
            """
[plugin]
name = "my-adapter"
version = "1.0.0"
author = "Test"
description = "Adapter v1"
homepage = "https://example.com"
entry_point = "pkg:Adapter"
source_did = "did:web:example.com"
trust_tier_claim = "tier_1"
license = "MIT"
"""
        )

        toml_v2 = tmp_path / "manifest_v2.toml"
        toml_v2.write_text(
            """
[plugin]
name = "my-adapter"
version = "2.0.0"
author = "Test"
description = "Adapter v2"
homepage = "https://example.com"
entry_point = "pkg:Adapter"
source_did = "did:web:example.com"
trust_tier_claim = "tier_1"
license = "MIT"
"""
        )

        # Publish both
        cli.main(["publish", str(toml_v1), "--registry", str(tmp_registry)])
        cli.main(["publish", str(toml_v2), "--registry", str(tmp_registry)])

        # List should show both (or latest if filtering)
        argv = ["list", "--registry", str(tmp_registry)]
        rc = cli.main(argv)
        assert rc == 0


class TestShowCommand:
    """Test gtv-marketplace show."""

    def test_show_found(
        self, tmp_registry: Path, valid_manifest_toml: Path
    ) -> None:
        """Show should return full manifest JSON for found plugin."""
        publish_argv = [
            "publish",
            str(valid_manifest_toml),
            "--registry",
            str(tmp_registry),
        ]
        cli.main(publish_argv)

        argv = ["show", "test-adapter", "--registry", str(tmp_registry)]
        rc = cli.main(argv)
        assert rc == 0

    def test_show_not_found(self, tmp_registry: Path) -> None:
        """Show should return error if plugin not found."""
        argv = ["show", "nonexistent", "--registry", str(tmp_registry)]
        rc = cli.main(argv)
        assert rc == 1

    def test_show_latest_version(self, tmp_registry: Path, tmp_path: Path) -> None:
        """Show should return latest version if multiple exist."""
        toml_v1 = tmp_path / "manifest_v1.toml"
        toml_v1.write_text(
            """
[plugin]
name = "my-plugin"
version = "1.0.0"
author = "Test"
description = "Version 1"
homepage = "https://example.com"
entry_point = "pkg:Plugin"
source_did = "did:web:example.com"
trust_tier_claim = "tier_1"
license = "MIT"
"""
        )

        toml_v2 = tmp_path / "manifest_v2.toml"
        toml_v2.write_text(
            """
[plugin]
name = "my-plugin"
version = "2.0.0"
author = "Test"
description = "Version 2"
homepage = "https://example.com"
entry_point = "pkg:Plugin"
source_did = "did:web:example.com"
trust_tier_claim = "tier_1"
license = "MIT"
"""
        )

        cli.main(["publish", str(toml_v1), "--registry", str(tmp_registry)])
        cli.main(["publish", str(toml_v2), "--registry", str(tmp_registry)])

        argv = ["show", "my-plugin", "--registry", str(tmp_registry)]
        rc = cli.main(argv)
        assert rc == 0

    def test_show_no_arguments(self) -> None:
        """Show should return usage error without plugin name."""
        argv = ["show"]
        rc = cli.main(argv)
        assert rc == 2


class TestValidateCommand:
    """Test gtv-marketplace validate."""

    def test_validate_good_manifest(self, valid_manifest_toml: Path) -> None:
        """Validate should return success for valid manifest."""
        argv = ["validate", str(valid_manifest_toml)]
        rc = cli.main(argv)
        assert rc == 0

    def test_validate_bad_manifest(self, tmp_path: Path) -> None:
        """Validate should return error for invalid manifest."""
        bad_toml = tmp_path / "bad.toml"
        bad_toml.write_text(
            """
[plugin]
name = "BadName"  # uppercase
version = "1.0.0"
author = "Test"
description = "Test"
homepage = "https://example.com"
entry_point = "pkg:Plugin"
source_did = "did:web:example.com"
trust_tier_claim = "tier_1"
license = "MIT"
"""
        )
        argv = ["validate", str(bad_toml)]
        rc = cli.main(argv)
        assert rc == 1

    def test_validate_missing_file(self) -> None:
        """Validate should return error if manifest file not found."""
        argv = ["validate", "/nonexistent/manifest.toml"]
        rc = cli.main(argv)
        assert rc == 3

    def test_validate_no_arguments(self) -> None:
        """Validate should return usage error without manifest."""
        argv = ["validate"]
        rc = cli.main(argv)
        assert rc == 2


class TestRegistryIntegration:
    """Test registry functions underlying the CLI."""

    def test_registry_load_save_find(self, tmp_registry: Path) -> None:
        """Test round-trip: create, save, load, find."""
        from gtv.marketplace import registry

        # Create manifests
        m1 = PluginManifest(
            name="adapter-1",
            version="1.0.0",
            author="Author A",
            description="First adapter",
            homepage="https://example.com/a",
            entry_point="pkg_a:Adapter",
            source_did="did:web:example.com",
            trust_tier_claim="tier_1",
            license="MIT",
        )

        m2 = PluginManifest(
            name="adapter-1",
            version="2.0.0",
            author="Author A",
            description="Second version",
            homepage="https://example.com/a",
            entry_point="pkg_a:Adapter",
            source_did="did:web:example.com",
            trust_tier_claim="tier_1",
            license="MIT",
        )

        # Add to registry
        registry.add_manifest(tmp_registry, m1)
        registry.add_manifest(tmp_registry, m2)

        # Load and check
        loaded = registry.load_registry(tmp_registry)
        assert len(loaded) == 2

        # Find by name
        matches = registry.find_by_name(tmp_registry, "adapter-1")
        assert len(matches) == 2
        # Should be sorted newest first
        assert matches[0].version == "2.0.0"
        assert matches[1].version == "1.0.0"

        # Get latest
        latest_m = registry.latest(tmp_registry, "adapter-1")
        assert latest_m is not None
        assert latest_m.version == "2.0.0"

    def test_registry_duplicate_rejection(self, tmp_registry: Path) -> None:
        """Test that registry rejects duplicates."""
        from gtv.marketplace import registry

        m = PluginManifest(
            name="dup-test",
            version="1.0.0",
            author="Test",
            description="Test",
            homepage="https://example.com",
            entry_point="pkg:Adapter",
            source_did="did:web:example.com",
            trust_tier_claim="tier_1",
            license="MIT",
        )

        registry.add_manifest(tmp_registry, m)

        # Try to add the same manifest again
        with pytest.raises(ValueError) as exc_info:
            registry.add_manifest(tmp_registry, m)
        assert "Duplicate" in str(exc_info.value)
