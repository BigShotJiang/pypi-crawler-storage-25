"""Property-based tests for RFC 8785 JSON canonicalization.

These tests use Hypothesis to verify invariants that must hold for all inputs:
- Determinism: same input always produces same output
- Key-order invariance: permutations of dict keys produce identical results
- SHA256 determinism: hashing canonical form is stable
- Nested equivalence: deeply nested structures with same content are canonical-equivalent
- NaN/Inf rejection: any non-finite float raises ValueError
- Finite-float determinism: same float canonicalizes identically across runs
- Integer-float coercion: integer-valued floats coerce to int

These properties catch platform-dependent repr bugs, key handling issues, and
numeric serialization errors that unit tests alone wouldn't reveal.
"""
from __future__ import annotations

import math
from typing import Any

from hypothesis import given
from hypothesis import strategies as st

from gtv.anchor.canonicalize import canonicalize, sha256

# Recursive JSON-like value strategy: null, bool, int, finite float, str, list, dict
# NOTE: Excludes surrogate characters (\\ud800-\\udfff) due to DEFECT in canonicalize.
# The canonicalize() function does not validate strings and will fail with
# UnicodeEncodeError on surrogates. This is a known issue that needs fixing.
json_value = st.deferred(
    lambda: st.one_of(
        st.none(),
        st.booleans(),
        st.integers(min_value=-(2**31), max_value=2**31 - 1),  # typical JSON int range
        st.floats(allow_nan=False, allow_infinity=False, min_value=-1e100, max_value=1e100),
        st.text(
            min_size=0,
            max_size=20,
            alphabet=st.characters(blacklist_categories=("Cs",)),  # Cs = surrogates
        ),
        st.lists(json_value, max_size=5),
        st.dictionaries(
            st.text(
                min_size=1,
                max_size=10,
                alphabet=st.characters(blacklist_categories=("Cs",)),
            ),
            json_value,
            max_size=5,
        ),
    )
)


@given(json_value)
def test_canonicalize_determinism(obj: Any) -> None:
    """Property: canonicalize(obj) == canonicalize(obj) always.

    Ensures that the same input always produces identical bytes.
    Catches any hidden state or non-deterministic behavior.

    KNOWN DEFECT: canonicalize does not validate input strings for surrogate
    characters (\\ud800-\\udfff). These cannot be encoded to UTF-8, causing
    UnicodeEncodeError at the .encode("utf-8") call in canonicalize().
    RFC 8785 requires string validation. This property will fail on surrogate inputs.
    See: https://github.com/gtv/issues/XXX (surrogate character validation)
    """
    out1 = canonicalize(obj)
    out2 = canonicalize(obj)
    assert out1 == out2, (
        f"Canonicalization non-deterministic: obj={obj!r}, "
        f"out1={out1!r}, out2={out2!r}"
    )
    assert isinstance(out1, bytes), f"Expected bytes, got {type(out1)}"


@given(st.dictionaries(
    st.text(
        min_size=1,
        max_size=10,
        alphabet=st.characters(blacklist_categories=("Cs",)),
    ),
    st.integers() | st.text() | st.booleans() | st.none(),
    min_size=1,
    max_size=5,
))
def test_key_order_invariance(d: dict[str, Any]) -> None:
    """Property: dict with shuffled keys produces identical canonical output.

    RFC 8785 mandates lexicographic key sorting. Verify that any permutation
    of keys produces the same canonical form.
    """
    keys = list(d.keys())
    # Test against the first permutation (canonical order)
    canonical_out = canonicalize(d)

    # Generate a few random permutations and verify they all match
    for _ in range(min(3, math.factorial(len(keys)))):
        shuffled_keys = keys[:]
        # Rotate keys to create a permutation
        if len(shuffled_keys) > 1:
            shuffled_keys = shuffled_keys[1:] + shuffled_keys[:1]
        shuffled_d = {k: d[k] for k in shuffled_keys}
        assert canonicalize(shuffled_d) == canonical_out, (
            f"Key order changed canonical output: keys={keys}, "
            f"shuffled={shuffled_keys}, orig={d}"
        )


@given(json_value)
def test_sha256_round_trip(obj: Any) -> None:
    """Property: sha256(canonicalize(obj)) is a valid 64-char hex string.

    Ensures the hash output is well-formed and deterministic.
    """
    canonical = canonicalize(obj)
    hashed = sha256(canonical)

    # Should be 64 hex chars (256 bits)
    assert len(hashed) == 64, f"Expected 64-char hex hash, got {len(hashed)} chars: {hashed!r}"
    assert all(c in "0123456789abcdef" for c in hashed), (
        f"Hash contains non-hex characters: {hashed!r}"
    )

    # Hashing twice should yield the same result
    assert sha256(canonical) == hashed, (
        f"Hash non-deterministic for obj={obj!r}"
    )


@given(st.recursive(
    st.just({}),
    lambda children: st.dictionaries(
        st.text(
            min_size=1,
            max_size=10,
            alphabet=st.characters(blacklist_categories=("Cs",)),
        ),
        st.one_of(
            st.integers(),
            st.text(),
            st.booleans(),
            st.none(),
            children,
        ),
        max_size=3,
    ),
    max_leaves=4,
))
def test_nested_equivalence(nested_dict: Any) -> None:
    """Property: deeply nested dicts with same contents in any key order produce identical output.

    Tests that sorting is applied recursively at all nesting levels.
    """
    def canonicalize_and_compare(d: Any, desc: str) -> bytes:
        """Helper to canonicalize and check for errors."""
        try:
            return canonicalize(d)
        except (ValueError, TypeError):
            # Skip inputs with NaN, Inf, or unsupported types
            return b""

    out1 = canonicalize_and_compare(nested_dict, "original")

    # Try to create a permutation by permuting top-level keys
    if isinstance(nested_dict, dict) and len(nested_dict) > 1:
        keys = list(nested_dict.keys())
        # Reverse the key order (simple permutation)
        permuted = {k: nested_dict[k] for k in reversed(keys)}
        out2 = canonicalize_and_compare(permuted, "permuted")
        if out1 and out2:
            assert out1 == out2, (
                f"Permuted nested dict produced different output: "
                f"original={nested_dict}, permuted={permuted}"
            )


@given(st.floats(allow_nan=True, allow_infinity=True))
def test_nan_inf_rejection(f: float) -> None:
    """Property: any input containing NaN or ±Inf raises ValueError.

    RFC 8785 forbids non-finite floats in JSON. Verify strict rejection.
    """
    if not math.isfinite(f):
        try:
            canonicalize({"n": f})
            raise AssertionError(
                f"Expected ValueError for non-finite float {f}, but canonicalize succeeded"
            )
        except ValueError as e:
            assert "NaN" in str(e) or "Infinity" in str(e), (
                f"ValueError message should mention NaN/Infinity, got: {e}"
            )
    else:
        # Finite floats should not raise
        canonicalize({"n": f})


@given(st.floats(allow_nan=False, allow_infinity=False, min_value=-1e100, max_value=1e100))
def test_finite_float_determinism(f: float) -> None:
    """Property: any finite float, canonicalized twice, produces identical bytes.

    Catches platform-dependent repr bugs (e.g., float to string conversion).
    """
    out1 = canonicalize({"c": f})
    out2 = canonicalize({"c": f})
    assert out1 == out2, (
        f"Finite float {f} canonicalized non-deterministically: "
        f"out1={out1!r}, out2={out2!r}"
    )


@given(
    st.floats(allow_nan=False, allow_infinity=False, min_value=-1e6, max_value=1e6)
    .filter(lambda x: x.is_integer())
)
def test_integer_float_coercion(f: float) -> None:
    """Property: integer-valued floats (n.0) coerce to int.

    RFC 8785 ES6 ToString: integer-valued floats should serialize as ints.
    E.g., 2.0 should serialize as '2', not '2.0'.
    """
    as_float = canonicalize({"n": f})
    as_int = canonicalize({"n": int(f)})

    assert as_float == as_int, (
        f"Integer-valued float {f} didn't coerce to int: "
        f"as_float={as_float!r}, as_int={as_int!r}"
    )

    # Verify the output doesn't contain ".0"
    assert b".0" not in as_float, (
        f"Integer-valued float {f} serialized with .0: {as_float!r}"
    )


@given(st.lists(json_value, max_size=5))
def test_array_order_preserved(arr: list[Any]) -> None:
    """Property: array element order is preserved (not sorted).

    Unlike object keys, array order is semantically significant.
    """
    out = canonicalize(arr)
    out_again = canonicalize(arr)
    assert out == out_again

    # Verify if there's a reverse, it produces different output
    if len(arr) > 1:
        reversed_arr = list(reversed(arr))
        try:
            out_reversed = canonicalize(reversed_arr)
            # If both canonicalize successfully, reversed should differ
            # (unless all elements are identical, which is unlikely)
            if out != out_reversed:
                # Good, order matters
                pass
        except (ValueError, TypeError):
            # Skip if reversal hits NaN/Inf or unsupported types
            pass


def test_surrogate_character_rejected() -> None:
    """Verify: canonicalize rejects strings with UTF-16 surrogate code points.

    RFC 8785 §3.4 requires that JSON strings be valid UTF-8 after canonicalization.
    Surrogate code points (U+D800 through U+DFFF) are invalid UTF-8 and cannot
    be encoded. canonicalize() must reject them at validation time with ValueError.

    This test verifies the fix for the defect where surrogates were accepted
    but then crashed with UnicodeEncodeError downstream.
    """
    # Test surrogate in a dictionary key
    obj_with_surrogate_key = {"\ud800": "value"}
    try:
        canonicalize(obj_with_surrogate_key)
        raise AssertionError(
            "canonicalize should reject surrogate characters in keys, "
            "but it did not raise ValueError"
        )
    except ValueError as e:
        assert "surrogate" in str(e).lower(), (
            f"ValueError message should mention surrogate, got: {e}"
        )

    # Test surrogate in a string value
    obj_with_surrogate_value = {"key": "value\udbff"}
    try:
        canonicalize(obj_with_surrogate_value)
        raise AssertionError(
            "canonicalize should reject surrogate characters in values, "
            "but it did not raise ValueError"
        )
    except ValueError as e:
        assert "surrogate" in str(e).lower(), (
            f"ValueError message should mention surrogate, got: {e}"
        )

    # Test surrogate in nested structure
    obj_with_nested_surrogate = {"outer": {"inner": "text\ud801more"}}
    try:
        canonicalize(obj_with_nested_surrogate)
        raise AssertionError(
            "canonicalize should reject surrogate characters in nested values, "
            "but it did not raise ValueError"
        )
    except ValueError as e:
        assert "surrogate" in str(e).lower(), (
            f"ValueError message should mention surrogate, got: {e}"
        )
