"""Tests for OpenTelemetry tracing initialization."""
from __future__ import annotations

import os

import pytest
from fastapi import FastAPI
from opentelemetry import trace

from gtv.obs.tracing import init_tracing


def test_init_tracing_idempotent():
    """Test that init_tracing is idempotent."""
    app = FastAPI()

    # Call init_tracing twice
    init_tracing(app)
    init_tracing(app)

    # Both calls should succeed without error
    assert app is not None


def test_init_tracing_no_env_var_doesnt_raise():
    """Test that init_tracing works when GTV_OTEL_ENDPOINT is not set."""
    # Ensure the env var is not set
    if "GTV_OTEL_ENDPOINT" in os.environ:
        del os.environ["GTV_OTEL_ENDPOINT"]

    app = FastAPI()

    # Should not raise
    try:
        init_tracing(app)
    except Exception as e:
        pytest.fail(f"init_tracing raised {type(e).__name__}: {e}")


def test_init_tracing_with_endpoint():
    """Test that init_tracing works with GTV_OTEL_ENDPOINT set."""
    app = FastAPI()

    # Set a dummy endpoint
    os.environ["GTV_OTEL_ENDPOINT"] = "http://localhost:4318"

    try:
        init_tracing(app)
    except Exception as e:
        pytest.fail(f"init_tracing raised {type(e).__name__}: {e}")
    finally:
        # Clean up
        if "GTV_OTEL_ENDPOINT" in os.environ:
            del os.environ["GTV_OTEL_ENDPOINT"]


def test_tracer_provider_is_set():
    """Test that after init_tracing, a tracer provider is set."""
    app = FastAPI()
    init_tracing(app)

    # Get the tracer provider
    provider = trace.get_tracer_provider()
    assert provider is not None
