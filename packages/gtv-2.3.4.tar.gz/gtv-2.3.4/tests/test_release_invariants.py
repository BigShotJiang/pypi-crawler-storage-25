"""Release invariants — run every CI.

Guards that the release pipeline assumes to be true. If any of these fail,
the release workflow will break at build or publish time.
"""
from __future__ import annotations

import re
import tomllib
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent
PYPROJECT = REPO / "pyproject.toml"
CHANGELOG = REPO / "CHANGELOG.md"


def _load_pyproject() -> dict:
    with PYPROJECT.open("rb") as f:
        return tomllib.load(f)


def test_pyproject_version_is_valid_semver() -> None:
    version = _load_pyproject()["project"]["version"]
    # MAJOR.MINOR.PATCH[-prerelease]
    assert re.fullmatch(
        r"\d+\.\d+\.\d+(?:[-.][0-9A-Za-z.-]+)?", version
    ), f"{version!r} is not a valid semver"


def test_changelog_has_matching_entry() -> None:
    """CHANGELOG.md must contain a `## [<version>]` section for pyproject version.

    The release workflow extracts release notes from this section.
    """
    version = _load_pyproject()["project"]["version"]
    body = CHANGELOG.read_text()
    pattern = rf"^## \[{re.escape(version)}\]"
    assert re.search(pattern, body, re.MULTILINE), (
        f"CHANGELOG.md is missing `## [{version}]` section. "
        "Add a changelog entry before tagging a release."
    )


def test_all_console_scripts_import() -> None:
    """Every declared console_script must point to a callable that imports cleanly.

    Catches renames, typos, and missing-module bugs before they ship.
    """
    scripts = _load_pyproject()["project"]["scripts"]
    failures = []
    for name, target in scripts.items():
        module_path, _, attr = target.partition(":")
        try:
            module = __import__(module_path, fromlist=[attr])
        except Exception as exc:  # pragma: no cover - diagnostic path
            failures.append(f"{name} ({target}): import failed — {exc}")
            continue
        fn = getattr(module, attr, None)
        if fn is None:
            failures.append(f"{name} ({target}): attr {attr!r} missing")
        elif not callable(fn):
            failures.append(f"{name} ({target}): {attr!r} is not callable")
    assert not failures, "Broken console scripts:\n  " + "\n  ".join(failures)


def test_expected_console_scripts_present() -> None:
    """All v0.1.0 CLIs must be declared. Prevents accidental regression."""
    required = {
        "gtv-verify",
        "gtv-mcp",
        "gtv-demo",
        "gtv-sign-byok",
        "gtv-subscribe",
        "gtv-admin-keys",
        "gtv-revoke",
        "gtv-federation",
        "gtv-audit",
    }
    declared = set(_load_pyproject()["project"]["scripts"].keys())
    missing = required - declared
    assert not missing, f"Missing console scripts: {missing}"


def test_dockerfile_exists_and_uses_distroless() -> None:
    """Release pipeline publishes this image; guard the base image choice."""
    dockerfile = REPO / "Dockerfile"
    assert dockerfile.exists()
    body = dockerfile.read_text()
    assert "distroless" in body.lower(), (
        "Dockerfile must use a distroless base for the runtime stage."
    )


def test_no_root_level_metrics_module() -> None:
    """The stale root-level metrics.py must not exist.

    Historically a placeholder that raised ImportError on import existed at
    the repo root because the Cowork workspace disallowed deletion. With
    the repo under real git control, the file is gone — guard that it
    stays gone so a future copy-paste doesn't silently double-register
    the gtv_verdicts_total counter.
    """
    assert not (REPO / "metrics.py").exists(), (
        "Root-level metrics.py was removed as part of the GitHub migration. "
        "Do not re-add it — Prometheus metrics live in src/gtv/obs/metrics.py "
        "and src/gtv/telemetry/metrics.py."
    )


def test_no_root_level_tracing_module() -> None:
    """The stale root-level tracing.py must not exist.

    Symmetric guard to test_no_root_level_metrics_module. Real tracing
    code lives in src/gtv/obs/tracing.py.
    """
    assert not (REPO / "tracing.py").exists(), (
        "Root-level tracing.py was removed as part of the GitHub migration. "
        "Do not re-add it — tracing code lives in src/gtv/obs/tracing.py."
    )
