"""Model invariants — frozen, validated, no silent coercion."""
from __future__ import annotations

from datetime import UTC, datetime

import pytest
from pydantic import ValidationError

from gtv.models import Claim, Evidence, Stance, Verdict, VerdictRecord


def test_claim_rejects_empty_text() -> None:
    with pytest.raises(ValidationError):
        Claim(text="")


def test_claim_rejects_oversize_text() -> None:
    with pytest.raises(ValidationError):
        Claim(text="x" * 2001)


def test_evidence_requires_sha256_hash() -> None:
    base = {
        "claim_id": "abc",
        "source_did": "did:web:example.org",
        "source_version": "v1",
        "stance": Stance.SUPPORTS,
        "excerpt": "x",
        "url": "https://example.org/p",
        "retrieved_at": datetime.now(tz=UTC),
    }
    with pytest.raises(ValidationError):
        Evidence(**base, raw_hash="not-a-hash")
    Evidence(**base, raw_hash="a" * 64)  # ok


def test_verdict_record_confidence_bounds() -> None:
    with pytest.raises(ValidationError):
        VerdictRecord(
            claim_id="c", decision=Verdict.VERIFIED, confidence=1.5,
            evidence_refs=[], rationale="",
        )
