"""Tests for Sigstore signing and Rekor integration.

These tests cover:
1. Stub path: deterministic output when GTV_SIGSTORE_ENABLED is unset.
2. Real path: actual Sigstore signing when enabled (gated by @pytest.mark.live).
3. Error path: proper error handling when OIDC token is unavailable.
"""
from __future__ import annotations

import base64
import json
import os

import pytest
from cryptography import x509
from cryptography.hazmat.backends import default_backend

from gtv.anchor.sign import sign_hash


def test_sign_hash_stub_when_disabled() -> None:
    """Verify deterministic stub output when GTV_SIGSTORE_ENABLED is not set.

    This is the default path for most tests and local dev. The stub produces
    clearly-marked stub:// signatures so regressions are visible, not silent.
    """
    # Ensure flag is not set
    os.environ.pop("GTV_SIGSTORE_ENABLED", None)

    canonical_hash_hex = "0123456789abcdef" * 4  # 64 hex chars = 32 bytes

    result = sign_hash(canonical_hash_hex)

    # Verify stub structure
    assert result.signature_bundle.signature_b64.startswith("stub://")
    assert result.signature_bundle.certificate_pem == "stub://dev-cert"
    assert result.signature_bundle.signing_algorithm == "STUB"
    assert result.signature_bundle.bundle_format == "stub-v0"

    # Verify Rekor entry is also stubbed
    assert result.rekor_entry is not None
    assert result.rekor_entry.uuid.startswith("stub-")
    assert result.rekor_entry.log_index == 0
    assert result.rekor_entry.inclusion_proof.startswith("stub://")


def test_sign_hash_stub_is_deterministic() -> None:
    """Verify that stub signing produces deterministic output."""
    os.environ.pop("GTV_SIGSTORE_ENABLED", None)

    canonical_hash_hex = "cafebabe" * 8

    result1 = sign_hash(canonical_hash_hex)
    result2 = sign_hash(canonical_hash_hex)

    # Both results should be identical
    assert result1.signature_bundle.signature_b64 == result2.signature_bundle.signature_b64
    assert result1.signature_bundle.certificate_pem == result2.signature_bundle.certificate_pem
    assert result1.rekor_entry == result2.rekor_entry


def test_sign_hash_raises_when_enabled_but_no_token() -> None:
    """Verify that real signing fails loudly when enabled but no OIDC token available.

    This test ensures we don't silently fall back to stubs when the flag is on.
    """
    os.environ["GTV_SIGSTORE_ENABLED"] = "1"
    os.environ.pop("GTV_SIGSTORE_INTERACTIVE", None)
    # Ensure no ambient OIDC token would be detected
    # (In a real test environment, this would check the absence of CI env vars)

    canonical_hash_hex = "deadbeef" * 8

    # Should raise RuntimeError about missing OIDC token, not silently stub
    with pytest.raises(RuntimeError, match="No ambient OIDC token found"):
        sign_hash(canonical_hash_hex)

    os.environ.pop("GTV_SIGSTORE_ENABLED", None)


@pytest.mark.live
def test_sign_hash_with_staging_sigstore() -> None:
    """Real Sigstore signing test against staging instance.

    This test only runs when explicitly enabled with environment flags.
    It requires:
    - GTV_SIGSTORE_ENABLED=1
    - GTV_SIGSTORE_STAGING=1 or ambient staging (default)
    - An ambient OIDC token (GitHub Actions, Workload Identity, etc.)

    On success, verifies:
    - Signature is valid base64
    - Certificate is valid X.509 PEM
    - Rekor entry has non-empty uuid and positive log_index
    - Inclusion proof is valid JSON with expected fields
    """
    if os.environ.get("GTV_SIGSTORE_ENABLED") != "1":
        pytest.skip("GTV_SIGSTORE_ENABLED not set; skipping live Sigstore test")

    canonical_hash_hex = "0123456789abcdef" * 4

    result = sign_hash(canonical_hash_hex)

    # Verify signature is valid base64
    sig_bytes = base64.b64decode(result.signature_bundle.signature_b64)
    assert len(sig_bytes) > 0, "Signature should not be empty"

    # Verify certificate is valid X.509 PEM
    cert_pem = result.signature_bundle.certificate_pem
    assert cert_pem.startswith("-----BEGIN CERTIFICATE-----"), "Certificate should be PEM format"
    cert = x509.load_pem_x509_certificate(
        cert_pem.encode("utf-8"),
        backend=default_backend(),
    )
    assert cert.public_key() is not None, "Certificate should have a public key"

    # Verify Rekor entry metadata
    assert result.rekor_entry is not None
    assert result.rekor_entry.uuid != "", "Rekor UUID should not be empty"
    assert result.rekor_entry.log_index > 0, "Rekor log_index should be positive"

    # Verify inclusion proof is valid JSON with expected fields
    proof = json.loads(result.rekor_entry.inclusion_proof)
    assert "log_index" in proof, "Inclusion proof should have log_index"
    assert "tree_size" in proof, "Inclusion proof should have tree_size"
    assert "root_hash" in proof, "Inclusion proof should have root_hash"
    assert "hashes" in proof, "Inclusion proof should have hashes"


def test_sign_hash_respects_prod_flag() -> None:
    """Verify that GTV_SIGSTORE_PROD=1 routes to production (when enabled).

    This is a non-live test that verifies the environment flag is read.
    Real submission to production is gated by requiring explicit flag.
    """
    # We can't easily test actual production submission without hitting the real service,
    # but we can verify the code path reads the flag.
    os.environ.pop("GTV_SIGSTORE_ENABLED", None)
    os.environ["GTV_SIGSTORE_PROD"] = "1"

    # With GTV_SIGSTORE_ENABLED=0 (default), we still get stub (flag is just ignored).
    result = sign_hash("deadbeef" * 8)
    assert result.signature_bundle.signature_b64.startswith("stub://")

    os.environ.pop("GTV_SIGSTORE_PROD", None)
