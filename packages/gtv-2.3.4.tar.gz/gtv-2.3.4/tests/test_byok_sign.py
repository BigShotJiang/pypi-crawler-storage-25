"""Unit tests for BYOK (bring-your-own-key) signing and verification.

Covers:
1. Ed25519 sign/verify round-trip
2. Signature tampering detection (invalid signature fails)
3. Payload tampering detection (modified envelope fails)
4. Signature format parsing (byok-ed25519:... format)
5. DID key derivation and round-trip with parse_did_key
6. Multiple key types (Ed25519, P-256, secp256k1) if available
"""
from __future__ import annotations

import base64
from datetime import UTC, datetime

import pytest
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ec, ed25519

from gtv.anchor.canonicalize import envelope_canonical_sha256
from gtv.did.resolve_key import parse_did_key
from gtv.models import AnchorProof, Envelope, Verdict
from gtv.sign import sign_envelope_byok, verify_envelope_byok


@pytest.fixture
def ed25519_private_key_pem() -> bytes:
    """Generate a test Ed25519 private key in PEM format."""
    private_key = ed25519.Ed25519PrivateKey.generate()
    return private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )


@pytest.fixture
def p256_private_key_pem() -> bytes:
    """Generate a test NIST P-256 private key in PEM format."""
    private_key = ec.generate_private_key(ec.SECP256R1())
    return private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )


@pytest.fixture
def secp256k1_private_key_pem() -> bytes:
    """Generate a test secp256k1 private key in PEM format."""
    private_key = ec.generate_private_key(ec.SECP256K1())
    return private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )


@pytest.fixture
def draft_envelope() -> Envelope:
    """Create a minimal draft envelope for testing."""
    return Envelope(
        envelope_id="test-env-001",
        verdict=Verdict.VERIFIED,
        confidence=0.95,
        evidence=[],
        rationale="Test envelope",
        issuer_did="did:web:example.com",  # Will be replaced by signing
        issued_at=datetime.now(tz=UTC),
        signature="",  # Will be replaced by signing
        rekor_uuid="test-uuid",
        rekor_log_index=0,
        tsa_token="stub://",
        prov_graph="{}",
        anchor_proof=AnchorProof(
            rekor_inclusion_proof="{}",
            tsa_tsr_primary="stub://",
            tsa_tsr_secondary=None,
        ),
    )


class TestEd25519SignVerify:
    """Tests for Ed25519 signing and verification."""

    def test_ed25519_sign_produces_valid_signature(
        self,
        draft_envelope: Envelope,
        ed25519_private_key_pem: bytes,
    ) -> None:
        """Signing with Ed25519 produces a valid signature field."""
        signed = sign_envelope_byok(draft_envelope, ed25519_private_key_pem)

        # Check signature format
        assert signed.signature.startswith("byok-ed25519:")
        sig_b64 = signed.signature.split(":", 1)[1]
        sig_bytes = base64.b64decode(sig_b64)
        assert len(sig_bytes) == 64  # Ed25519 signature is 64 bytes

    def test_ed25519_issuer_did_is_did_key(
        self,
        draft_envelope: Envelope,
        ed25519_private_key_pem: bytes,
    ) -> None:
        """Signing sets issuer_did to a valid did:key:z..."""
        signed = sign_envelope_byok(draft_envelope, ed25519_private_key_pem)

        assert signed.issuer_did.startswith("did:key:z")
        # Verify it can be parsed
        parsed = parse_did_key(signed.issuer_did)
        assert parsed.key_type == "Ed25519"
        assert len(parsed.public_key_bytes) == 32

    def test_ed25519_round_trip_verify_passes(
        self,
        draft_envelope: Envelope,
        ed25519_private_key_pem: bytes,
    ) -> None:
        """Sign and immediately verify: should pass."""
        signed = sign_envelope_byok(draft_envelope, ed25519_private_key_pem)
        # Should not raise
        verify_envelope_byok(signed)

    def test_ed25519_verify_with_tampered_signature_fails(
        self,
        draft_envelope: Envelope,
        ed25519_private_key_pem: bytes,
    ) -> None:
        """Verify fails if signature is tampered with."""
        signed = sign_envelope_byok(draft_envelope, ed25519_private_key_pem)

        # Tamper with signature (flip one bit)
        sig_b64 = signed.signature.split(":", 1)[1]
        sig_bytes = bytearray(base64.b64decode(sig_b64))
        sig_bytes[0] ^= 0x01  # Flip one bit
        tampered_sig = f"byok-ed25519:{base64.b64encode(sig_bytes).decode()}"

        tampered_env = signed.model_copy(update={"signature": tampered_sig})

        with pytest.raises(ValueError, match="verification failed"):
            verify_envelope_byok(tampered_env)

    def test_ed25519_verify_with_tampered_payload_fails(
        self,
        draft_envelope: Envelope,
        ed25519_private_key_pem: bytes,
    ) -> None:
        """Verify fails if envelope payload is tampered with."""
        signed = sign_envelope_byok(draft_envelope, ed25519_private_key_pem)

        # Tamper with payload
        tampered_env = signed.model_copy(
            update={"confidence": 0.50}  # Was 0.95
        )

        with pytest.raises(ValueError, match="verification failed"):
            verify_envelope_byok(tampered_env)

    def test_ed25519_verify_rejects_non_byok_signature(
        self,
        draft_envelope: Envelope,
        ed25519_private_key_pem: bytes,
    ) -> None:
        """Verify rejects envelopes with non-byok signatures."""
        signed = sign_envelope_byok(draft_envelope, ed25519_private_key_pem)

        # Replace with a non-byok signature
        invalid_env = signed.model_copy(update={"signature": "sigstore:somedata"})

        with pytest.raises(ValueError, match="byok"):
            verify_envelope_byok(invalid_env)

    def test_ed25519_verify_rejects_wrong_signature_type(
        self,
        draft_envelope: Envelope,
        ed25519_private_key_pem: bytes,
    ) -> None:
        """Verify rejects byok signatures with mismatched key type."""
        signed = sign_envelope_byok(draft_envelope, ed25519_private_key_pem)

        # Change signature type to p256 (but keep same signature bytes)
        sig_b64 = signed.signature.split(":", 1)[1]
        wrong_env = signed.model_copy(
            update={"signature": f"byok-p256:{sig_b64}"}
        )

        with pytest.raises(ValueError, match="Signature type mismatch"):
            verify_envelope_byok(wrong_env)

    def test_ed25519_verify_rejects_non_did_key_issuer(
        self,
        draft_envelope: Envelope,
        ed25519_private_key_pem: bytes,
    ) -> None:
        """Verify rejects envelopes without did:key issuer."""
        signed = sign_envelope_byok(draft_envelope, ed25519_private_key_pem)

        # Change issuer to did:web
        invalid_env = signed.model_copy(
            update={"issuer_did": "did:web:example.com"}
        )

        with pytest.raises(ValueError, match="must be a did:key"):
            verify_envelope_byok(invalid_env)


class TestP256SignVerify:
    """Tests for NIST P-256 signing and verification."""

    def test_p256_sign_produces_valid_signature(
        self,
        draft_envelope: Envelope,
        p256_private_key_pem: bytes,
    ) -> None:
        """Signing with P-256 produces a valid signature field."""
        signed = sign_envelope_byok(draft_envelope, p256_private_key_pem)

        # Check signature format
        assert signed.signature.startswith("byok-nistp256:")
        sig_b64 = signed.signature.split(":", 1)[1]
        sig_bytes = base64.b64decode(sig_b64)
        assert len(sig_bytes) == 64  # P-256 signature is r||s, 32 bytes each

    def test_p256_issuer_did_is_did_key(
        self,
        draft_envelope: Envelope,
        p256_private_key_pem: bytes,
    ) -> None:
        """Signing with P-256 sets issuer_did to a valid did:key:z..."""
        signed = sign_envelope_byok(draft_envelope, p256_private_key_pem)

        assert signed.issuer_did.startswith("did:key:z")
        # Verify it can be parsed
        parsed = parse_did_key(signed.issuer_did)
        assert parsed.key_type == "NIST P-256"
        assert len(parsed.public_key_bytes) == 33  # Compressed point

    def test_p256_round_trip_verify_passes(
        self,
        draft_envelope: Envelope,
        p256_private_key_pem: bytes,
    ) -> None:
        """Sign and immediately verify: should pass."""
        signed = sign_envelope_byok(draft_envelope, p256_private_key_pem)
        # Should not raise
        verify_envelope_byok(signed)

    def test_p256_verify_with_tampered_signature_fails(
        self,
        draft_envelope: Envelope,
        p256_private_key_pem: bytes,
    ) -> None:
        """Verify fails if signature is tampered with."""
        signed = sign_envelope_byok(draft_envelope, p256_private_key_pem)

        # Tamper with signature (flip one bit)
        sig_b64 = signed.signature.split(":", 1)[1]
        sig_bytes = bytearray(base64.b64decode(sig_b64))
        sig_bytes[0] ^= 0x01  # Flip one bit
        tampered_sig = f"byok-nistp256:{base64.b64encode(sig_bytes).decode()}"  # Note: no dash

        tampered_env = signed.model_copy(update={"signature": tampered_sig})

        with pytest.raises(ValueError, match="verification failed"):
            verify_envelope_byok(tampered_env)


class TestSecp256k1SignVerify:
    """Tests for secp256k1 signing and verification."""

    def test_secp256k1_sign_produces_valid_signature(
        self,
        draft_envelope: Envelope,
        secp256k1_private_key_pem: bytes,
    ) -> None:
        """Signing with secp256k1 produces a valid signature field."""
        signed = sign_envelope_byok(draft_envelope, secp256k1_private_key_pem)

        # Check signature format
        assert signed.signature.startswith("byok-secp256k1:")
        sig_b64 = signed.signature.split(":", 1)[1]
        sig_bytes = base64.b64decode(sig_b64)
        assert len(sig_bytes) == 64  # secp256k1 signature is r||s, 32 bytes each

    def test_secp256k1_round_trip_verify_passes(
        self,
        draft_envelope: Envelope,
        secp256k1_private_key_pem: bytes,
    ) -> None:
        """Sign and immediately verify: should pass."""
        signed = sign_envelope_byok(draft_envelope, secp256k1_private_key_pem)
        # Should not raise
        verify_envelope_byok(signed)


class TestSignatureFormatAndDIDDerivation:
    """Tests for signature format parsing and DID derivation."""

    def test_signature_format_roundtrip(
        self,
        draft_envelope: Envelope,
        ed25519_private_key_pem: bytes,
    ) -> None:
        """Signature format can be parsed and used to verify."""
        signed = sign_envelope_byok(draft_envelope, ed25519_private_key_pem)

        # Parse signature format
        parts = signed.signature.split(":", 1)
        assert len(parts) == 2
        sig_type, sig_b64 = parts
        assert sig_type == "byok-ed25519"
        sig_bytes = base64.b64decode(sig_b64)
        assert isinstance(sig_bytes, bytes)
        assert len(sig_bytes) == 64

    def test_did_key_derivation_matches_parser(
        self,
        draft_envelope: Envelope,
        ed25519_private_key_pem: bytes,
    ) -> None:
        """Derived DID key can be parsed back correctly."""
        signed = sign_envelope_byok(draft_envelope, ed25519_private_key_pem)

        # Parse the derived DID
        parsed = parse_did_key(signed.issuer_did)
        assert parsed.key_type == "Ed25519"
        assert len(parsed.public_key_bytes) == 32

        # Re-derive DID from parsed key should give same DID
        from gtv.sign.byok import _derive_did_key_from_public_key
        redrive_did = _derive_did_key_from_public_key("Ed25519", parsed.public_key_bytes)
        assert redrive_did == signed.issuer_did


class TestCanonicalFormExclusions:
    """Tests verifying that the canonical form excludes the right fields."""

    def test_signature_field_excluded_from_canonical_form(
        self,
        draft_envelope: Envelope,
        ed25519_private_key_pem: bytes,
    ) -> None:
        """Changing signature field alone doesn't affect canonical form."""
        signed1 = sign_envelope_byok(draft_envelope, ed25519_private_key_pem)

        # Compute canonical form (should exclude signature)
        canonical_hash_1 = envelope_canonical_sha256(signed1)

        # Create a new envelope with same payload but different signature
        tampered = signed1.model_copy(update={"signature": "stub://something"})
        canonical_hash_2 = envelope_canonical_sha256(tampered)

        # Canonical hashes should be the same (signature excluded)
        assert canonical_hash_1 == canonical_hash_2

    def test_issuer_did_is_excluded_for_byok(
        self,
        draft_envelope: Envelope,
        ed25519_private_key_pem: bytes,
    ) -> None:
        """For BYOK signing, issuer_did is excluded from canonical form (it's derived from key)."""
        signed = sign_envelope_byok(draft_envelope, ed25519_private_key_pem)

        # Change issuer_did to something else
        tampered = signed.model_copy(
            update={"issuer_did": "did:key:z9999"}
        )

        # The verification should still fail because issuer_did changed,
        # but NOT because of canonical form mismatch — rather because
        # we're trying to extract the public key from a different DID.
        with pytest.raises(ValueError):
            verify_envelope_byok(tampered)
