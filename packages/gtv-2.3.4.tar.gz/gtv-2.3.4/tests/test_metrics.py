"""Tests for Prometheus metrics endpoint and recording."""
from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

from gtv.adapters.base import SourceAdapter
from gtv.mcp.server import app
from gtv.models import Claim, Domain, Evidence, SourceType, Stance, TrustTier
from gtv.obs.metrics import VERDICTS_TOTAL, record_verdict


class DummyAdapter(SourceAdapter):
    """In-process test adapter."""

    def __init__(self):
        from datetime import UTC, datetime

        self.source_did = "did:web:dummy.example"
        self.name = "Dummy"
        self.type = SourceType.REFERENCE_DATA
        self.trust_tier = TrustTier.TIER_1
        self.freshness_sla_s = 86400
        self.last_audit = datetime.now(tz=UTC)

    async def query(self, claim: Claim, max_items: int = 5) -> list[Evidence]:
        """Return one dummy evidence item."""
        return [
            Evidence(
                claim_id=claim.claim_id,
                source_did=self.source_did,
                source_version="1.0",
                stance=Stance.SUPPORTS,
                excerpt="Dummy evidence supporting the claim.",
                url="https://example.com",
            )
        ]

    async def snapshot(self, url: str):
        """Return a dummy snapshot."""
        from gtv.adapters.base import RawSnapshot

        return RawSnapshot(
            url=url,
            mime_type="text/html",
            size_bytes=100,
            body=b"dummy content",
            sha256_hex="dummy_hash",
        )

    async def health(self):
        """Return healthy status."""
        from gtv.adapters.base import HealthStatus

        return HealthStatus.HEALTHY

    async def close(self):
        """Close resources."""
        pass


@pytest.fixture
def test_client():
    """Create a FastAPI TestClient with GTV_DISABLE_DEFAULT_ADAPTERS set."""
    with pytest.MonkeyPatch.context() as monkeypatch:
        # Disable default adapters
        monkeypatch.setenv("GTV_DISABLE_DEFAULT_ADAPTERS", "1")

        # Import fresh to get the empty REGISTRY
        from importlib import reload

        import gtv.adapters

        reload(gtv.adapters)

        # Register the dummy adapter
        from gtv.adapters import REGISTRY, register

        dummy = DummyAdapter()
        register(dummy)

        yield TestClient(app)

        # Cleanup
        REGISTRY.clear()


def test_metrics_endpoint_returns_200(test_client):
    """Assert /metrics endpoint returns 200."""
    response = test_client.get("/metrics")
    assert response.status_code == 200
    assert "text/plain" in response.headers["content-type"]


def test_verdicts_total_metric_in_metrics(test_client):
    """Assert gtv_verdicts_total metric appears in /metrics output."""
    response = test_client.get("/metrics")
    assert "gtv_verdicts_total" in response.text


def test_verify_claim_records_verdict(test_client):
    """Verify that a successful verify_claim call increments the verdict counter."""
    from gtv.models import VerifyClaimRequest

    # Make a verify_claim call
    request = VerifyClaimRequest(
        claim="The Earth is round.",
        domain=Domain.GENERAL,
        max_sources=5,
    )
    response = test_client.post("/tools/verify_claim", json=request.model_dump())
    assert response.status_code == 200

    # Check metrics endpoint
    metrics_response = test_client.get("/metrics")
    assert response.status_code == 200
    # The counter should have been incremented
    assert "gtv_verdicts_total" in metrics_response.text


def test_record_verdict_increments_counter():
    """Test the record_verdict helper directly."""
    from gtv.models import Verdict

    # Record a verdict
    record_verdict(Verdict.VERIFIED, 1.5, 3)

    # Check that the counter was incremented
    samples = list(VERDICTS_TOTAL.collect()[0].samples)
    assert len(samples) > 0
    # Should have a sample with verdict="VERIFIED"
    verdict_samples = [s for s in samples if s.name == "gtv_verdicts_total"]
    assert len(verdict_samples) > 0


def test_verify_duration_histogram_recorded():
    """Test that verify_duration histogram records samples."""
    from gtv.models import Verdict
    from gtv.obs.metrics import VERIFY_DURATION

    # Record a verdict with timing
    record_verdict(Verdict.UNVERIFIED, 0.5, 2)

    # Check histogram
    histogram = VERIFY_DURATION.collect()[0]
    assert histogram.name == "gtv_verify_duration_seconds"
    # Should have at least a count sample
    assert len(list(histogram.samples)) > 0


def test_evidence_count_histogram_recorded():
    """Test that evidence_count histogram records samples."""
    from gtv.models import Verdict
    from gtv.obs.metrics import EVIDENCE_COUNT

    # Record a verdict with evidence count
    record_verdict(Verdict.VERIFIED, 1.0, 5)

    # Check histogram
    histogram = EVIDENCE_COUNT.collect()[0]
    assert histogram.name == "gtv_evidence_count"
    assert len(list(histogram.samples)) > 0
