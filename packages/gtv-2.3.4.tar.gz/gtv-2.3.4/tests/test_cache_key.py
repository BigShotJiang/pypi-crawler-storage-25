"""Unit tests for cache key derivation."""
from __future__ import annotations

from gtv.cache.key import CacheKey, build_key, normalize_claim


def test_normalize_claim_collapses_whitespace() -> None:
    assert normalize_claim("The  speed\tof\nlight") == "the speed of light"


def test_normalize_claim_casefold() -> None:
    assert normalize_claim("Hello World") == "hello world"
    # Casefold is more aggressive than lower — "ß" → "ss".
    assert normalize_claim("STRAßE") == "strasse"


def test_normalize_claim_nfkc() -> None:
    # Full-width FULLWIDTH FULL STOP (U+FF0E) normalizes to ASCII full stop.
    fullwidth_dot = "\uff0e"
    assert normalize_claim("pi is 3.14") == normalize_claim(f"pi is 3{fullwidth_dot}14")


def test_build_key_is_deterministic() -> None:
    a = build_key(claim_text="A  B", domain="physics", max_sources=3, issuer_did="did:web:a")
    b = build_key(claim_text="a b", domain="Physics", max_sources=3, issuer_did="did:web:a")
    assert a.digest == b.digest
    assert isinstance(a, CacheKey)
    assert len(a.digest) == 64


def test_build_key_changes_on_max_sources() -> None:
    a = build_key(claim_text="x", domain="y", max_sources=3, issuer_did="did:z")
    b = build_key(claim_text="x", domain="y", max_sources=4, issuer_did="did:z")
    assert a.digest != b.digest


def test_build_key_changes_on_issuer_did() -> None:
    a = build_key(claim_text="x", domain="y", max_sources=3, issuer_did="did:z1")
    b = build_key(claim_text="x", domain="y", max_sources=3, issuer_did="did:z2")
    assert a.digest != b.digest


def test_build_key_changes_on_domain() -> None:
    a = build_key(claim_text="x", domain="physics", max_sources=3, issuer_did="did:z")
    b = build_key(claim_text="x", domain="biology", max_sources=3, issuer_did="did:z")
    assert a.digest != b.digest
