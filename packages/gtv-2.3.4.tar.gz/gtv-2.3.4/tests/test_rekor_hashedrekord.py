"""Tests for gtv.anchor.rekor.hashedrekord_leaf_hash.

Gold-standard: cross-check against sigstore-python's own
`_hashedrekord_from_parts` → canonical JSON → sha256(0x00 || body).
If those bytes disagree with ours, the merkle-tree verification will
disagree with Rekor's.
"""
from __future__ import annotations

import base64
import hashlib
import json
from datetime import UTC, datetime, timedelta

from cryptography import x509
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes as cryptohashes
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.x509.oid import NameOID

from gtv.anchor.rekor import hashedrekord_leaf_hash


def _self_signed_cert_pem() -> tuple[bytes, str]:
    """Generate a test ECDSA P-256 certificate as PEM bytes + PEM string."""
    key = ec.generate_private_key(ec.SECP256R1(), default_backend())
    cn = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "gtv-test")])
    cert = (
        x509.CertificateBuilder()
        .subject_name(cn)
        .issuer_name(cn)
        .public_key(key.public_key())
        .serial_number(1)
        .not_valid_before(datetime.now(UTC))
        .not_valid_after(datetime.now(UTC) + timedelta(days=1))
        .sign(key, cryptohashes.SHA256(), default_backend())
    )
    pem_bytes = cert.public_bytes(serialization.Encoding.PEM)
    return pem_bytes, pem_bytes.decode("ascii")


def test_leaf_hash_is_deterministic() -> None:
    """Same inputs produce the same leaf hash — no hidden nondeterminism."""
    _, cert_pem = _self_signed_cert_pem()
    canonical_hash = "a" * 64
    sig = base64.b64encode(b"\x30\x44" + b"\x00" * 68).decode()

    h1 = hashedrekord_leaf_hash(canonical_hash, sig, cert_pem)
    h2 = hashedrekord_leaf_hash(canonical_hash, sig, cert_pem)
    assert h1 == h2
    assert len(h1) == 32


def test_leaf_hash_matches_sigstore_reference() -> None:
    """Cross-check: our leaf bytes equal sigstore's own hashedrekord serialization.

    Rekor computes the merkle leaf over its canonicalized hashedrekord body.
    If our canonicalization differs from sigstore's, the merkle walk won't
    match what Rekor actually recorded and we'll fail to verify real proofs.
    This test is the definition-of-done for #40.
    """
    from sigstore._internal.rekor import _hashedrekord_from_parts
    from sigstore.hashes import HashAlgorithm, Hashed

    pem_bytes, cert_pem = _self_signed_cert_pem()
    cert = x509.load_pem_x509_certificate(pem_bytes, default_backend())
    canonical_hash = "deadbeef" * 8  # 64 hex chars = 32-byte digest
    sig_raw = b"\x30\x44" + b"\x01" * 68  # plausible DER-ish bytes
    sig_b64 = base64.b64encode(sig_raw).decode()

    # gtv's implementation
    gtv_leaf = hashedrekord_leaf_hash(canonical_hash, sig_b64, cert_pem)

    # sigstore's own hashedrekord body → canonical JSON → sha256(0x00 || body)
    h_body = _hashedrekord_from_parts(
        cert,
        sig_raw,
        Hashed(algorithm=HashAlgorithm.SHA2_256, digest=bytes.fromhex(canonical_hash)),
    )
    sigstore_json = h_body.model_dump_json(by_alias=True, exclude_none=True)
    sigstore_canonical = json.dumps(
        json.loads(sigstore_json), separators=(",", ":"), sort_keys=True
    )
    sigstore_leaf = hashlib.sha256(b"\x00" + sigstore_canonical.encode("utf-8")).digest()

    assert gtv_leaf == sigstore_leaf, (
        f"gtv leaf {gtv_leaf.hex()} != sigstore leaf {sigstore_leaf.hex()}\n"
        f"This means gtv's canonicalization diverges from sigstore's, "
        f"and Rekor inclusion-proof verification will fail against real logs."
    )


def test_leaf_hash_rejects_bad_cert_pem() -> None:
    """A malformed certificate PEM must raise ValueError, not silently proceed."""
    import pytest

    with pytest.raises(ValueError, match="certificate PEM is not valid"):
        hashedrekord_leaf_hash(
            canonical_hash_hex="a" * 64,
            signature_b64="AAAA",
            certificate_pem="not a certificate",
        )


def test_leaf_hash_changes_when_any_input_changes() -> None:
    """Sanity: different canonical hash / sig / cert produce different leaves."""
    _, cert_a = _self_signed_cert_pem()
    _, cert_b = _self_signed_cert_pem()  # fresh key → different pubkey

    base = hashedrekord_leaf_hash("a" * 64, "QUFBQQ==", cert_a)
    diff_hash = hashedrekord_leaf_hash("b" * 64, "QUFBQQ==", cert_a)
    diff_sig = hashedrekord_leaf_hash("a" * 64, "QkJCQg==", cert_a)
    diff_cert = hashedrekord_leaf_hash("a" * 64, "QUFBQQ==", cert_b)

    assert base != diff_hash
    assert base != diff_sig
    assert base != diff_cert
