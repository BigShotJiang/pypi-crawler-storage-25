"""Tests for the ``gtv-usage`` CLI (``gtv.cli.usage``).

End-to-end: we populate a real SQLite DB on disk, invoke ``main([...])``
with ``--db-path`` pointed at it, and capture stdout. This covers the
argparse wiring, the ``_open_store`` resolution, and each output format.
"""

from __future__ import annotations

import csv
import io
import json
from datetime import UTC, datetime
from pathlib import Path

import pytest

from gtv.billing import UsageStore
from gtv.cli import usage as usage_cli


@pytest.fixture
def populated_db(tmp_path: Path) -> Path:
    """Build a DB with two tenants, two tools, two days of usage."""
    db = tmp_path / "usage.sqlite"
    store = UsageStore(str(db))
    d1 = datetime(2026, 4, 20, tzinfo=UTC)
    d2 = datetime(2026, 4, 21, tzinfo=UTC)
    store.record(tenant_id="acme", issuer_did="did:a", tool="verify", when=d1, count=5)
    store.record(tenant_id="acme", issuer_did="did:a", tool="verify", when=d2, count=2)
    store.record(tenant_id="acme", issuer_did="did:a", tool="retrieve", when=d2, count=1)
    store.record(tenant_id="globex", issuer_did="did:b", tool="verify", when=d2, count=7)
    store.close()
    return db


# ---------------------------------------------------------------------------
# No-DB-configured path
# ---------------------------------------------------------------------------


def test_report_no_db_configured_exits_clean(
    monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    monkeypatch.delenv("GTV_BILLING_DB", raising=False)
    rc = usage_cli.main(["report"])
    assert rc == 0
    assert "No usage recorded" in capsys.readouterr().out


def test_totals_no_db_configured_exits_clean(
    monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    monkeypatch.delenv("GTV_BILLING_DB", raising=False)
    rc = usage_cli.main(["totals"])
    assert rc == 0
    assert "No usage recorded" in capsys.readouterr().out


def test_env_var_pointing_at_missing_file_exits_clean(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    """GTV_BILLING_DB set but the path doesn't exist → still clean exit,
    not an auto-created empty DB."""
    monkeypatch.setenv("GTV_BILLING_DB", str(tmp_path / "nope.sqlite"))
    rc = usage_cli.main(["report"])
    assert rc == 0
    assert "No usage recorded" in capsys.readouterr().out


# ---------------------------------------------------------------------------
# report subcommand
# ---------------------------------------------------------------------------


def test_report_table_default(
    populated_db: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    rc = usage_cli.main(["--db-path", str(populated_db), "report"])
    assert rc == 0
    out = capsys.readouterr().out
    # Header + separator + 4 data rows
    assert "day" in out and "tenant_id" in out and "tool" in out
    assert "acme" in out
    assert "globex" in out
    assert "verify" in out
    assert "retrieve" in out


def test_report_csv_format(
    populated_db: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    rc = usage_cli.main(["--db-path", str(populated_db), "report", "--format", "csv"])
    assert rc == 0
    out = capsys.readouterr().out
    reader = csv.reader(io.StringIO(out))
    rows = list(reader)
    assert rows[0] == ["day", "tenant_id", "issuer_did", "tool", "count"]
    assert len(rows) == 5  # header + 4 data
    # Check a known row is present
    data_rows = rows[1:]
    totals = {(r[0], r[1], r[3]): int(r[4]) for r in data_rows}
    assert totals[("2026-04-20", "acme", "verify")] == 5
    assert totals[("2026-04-21", "globex", "verify")] == 7


def test_report_json_format(
    populated_db: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    rc = usage_cli.main(["--db-path", str(populated_db), "report", "--format", "json"])
    assert rc == 0
    payload = json.loads(capsys.readouterr().out)
    assert isinstance(payload, list)
    assert len(payload) == 4
    assert {r["tenant_id"] for r in payload} == {"acme", "globex"}
    assert all(set(r.keys()) == {"day", "tenant_id", "issuer_did", "tool", "count"} for r in payload)


def test_report_filter_by_tenant(
    populated_db: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    rc = usage_cli.main(
        ["--db-path", str(populated_db), "report", "--tenant", "acme", "--format", "json"]
    )
    assert rc == 0
    payload = json.loads(capsys.readouterr().out)
    assert {r["tenant_id"] for r in payload} == {"acme"}
    assert len(payload) == 3


def test_report_filter_by_tool(
    populated_db: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    rc = usage_cli.main(
        ["--db-path", str(populated_db), "report", "--tool", "retrieve", "--format", "json"]
    )
    assert rc == 0
    payload = json.loads(capsys.readouterr().out)
    assert len(payload) == 1
    assert payload[0]["tool"] == "retrieve"


def test_report_filter_by_date_window(
    populated_db: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    rc = usage_cli.main(
        [
            "--db-path",
            str(populated_db),
            "report",
            "--since",
            "2026-04-21",
            "--format",
            "json",
        ]
    )
    assert rc == 0
    payload = json.loads(capsys.readouterr().out)
    assert {r["day"] for r in payload} == {"2026-04-21"}


def test_report_empty_db_prints_no_usage(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    db = tmp_path / "empty.sqlite"
    UsageStore(str(db)).close()
    rc = usage_cli.main(["--db-path", str(db), "report"])
    assert rc == 0
    assert "No usage recorded" in capsys.readouterr().out


# ---------------------------------------------------------------------------
# totals subcommand
# ---------------------------------------------------------------------------


def test_totals_prints_per_tenant(
    populated_db: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    rc = usage_cli.main(["--db-path", str(populated_db), "totals"])
    assert rc == 0
    out = capsys.readouterr().out
    assert "tenant_id" in out
    assert "total_calls" in out
    # acme = 5+2+1 = 8, globex = 7
    assert "acme" in out and "8" in out
    assert "globex" in out and "7" in out


def test_totals_respects_window(
    populated_db: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    rc = usage_cli.main(
        ["--db-path", str(populated_db), "totals", "--since", "2026-04-21"]
    )
    assert rc == 0
    out = capsys.readouterr().out
    # Only day 2026-04-21: acme=3, globex=7
    lines = out.strip().splitlines()
    # header + separator + 2 tenant rows
    assert len(lines) == 4
    # globex is larger → listed first
    assert lines[2].strip().startswith("globex")
    assert lines[3].strip().startswith("acme")


def test_totals_empty_window_prints_notice(
    populated_db: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    rc = usage_cli.main(
        ["--db-path", str(populated_db), "totals", "--since", "2099-01-01"]
    )
    assert rc == 0
    assert "No usage recorded in window" in capsys.readouterr().out


# ---------------------------------------------------------------------------
# argparse plumbing
# ---------------------------------------------------------------------------


def test_missing_subcommand_errors(capsys: pytest.CaptureFixture[str]) -> None:
    with pytest.raises(SystemExit) as excinfo:
        usage_cli.main([])
    assert excinfo.value.code == 2  # argparse usage error


def test_invalid_format_errors() -> None:
    with pytest.raises(SystemExit):
        usage_cli.main(["report", "--format", "xml"])
