"""Tests for the replay CLI."""
from __future__ import annotations

import json
import tempfile
from datetime import UTC, datetime
from pathlib import Path

import pytest
import yaml

from gtv.models import (
    AnchorProof,
    Claim,
    Domain,
    Envelope,
    Evidence,
    Stance,
    Verdict,
)
from gtv.policy import DEFAULT_POLICY


@pytest.fixture
def test_claim() -> Claim:
    """A simple test claim."""
    return Claim(
        claim_id="test-claim-1",
        text="The Earth is round.",
        domain=Domain.GENERAL,
        submitted_at=datetime.now(tz=UTC),
    )


@pytest.fixture
def test_evidence_list(test_claim: Claim) -> list[Evidence]:
    """Supporting evidence records (2 sources for VERIFIED threshold)."""
    return [
        Evidence(
            evidence_id="ev-1",
            claim_id=test_claim.claim_id,
            source_did="source-1",
            source_version="v1.0",
            stance=Stance.SUPPORTS,
            excerpt="The Earth is spherical.",
            url="https://example.com/round",
            retrieved_at=datetime.now(tz=UTC),
            raw_hash="a" * 64,
        ),
        Evidence(
            evidence_id="ev-2",
            claim_id=test_claim.claim_id,
            source_did="source-2",
            source_version="v1.0",
            stance=Stance.SUPPORTS,
            excerpt="Evidence of roundness.",
            url="https://example.com/evidence",
            retrieved_at=datetime.now(tz=UTC),
            raw_hash="b" * 64,
        ),
    ]


@pytest.fixture
def test_envelope(test_claim: Claim, test_evidence_list: list[Evidence]) -> Envelope:
    """A test envelope."""
    return Envelope(
        envelope_id="env-1",
        verdict=Verdict.VERIFIED,
        confidence=0.8,
        evidence=test_evidence_list,
        rationale="Test envelope.",
        issuer_did="issuer-1",
        issued_at=datetime.now(tz=UTC),
        signature="sig-stub",
        rekor_uuid="rekor-1",
        rekor_log_index=0,
        tsa_token="tsa-1",
        prov_graph="{}",
        anchor_proof=AnchorProof(
            rekor_inclusion_proof="proof-1",
            tsa_tsr_primary="tsr-1",
        ),
    )


class TestReplayReproducesMatchingVerdict:
    """test_replay_reproduces_matching_verdict"""

    def test_replay_reproduces_matching_verdict(
        self, test_claim: Claim, test_evidence_list: list[Evidence], test_envelope: Envelope
    ) -> None:
        """replay() reproduces a matching verdict."""
        from gtv.cli.replay import replay

        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir_path = Path(tmpdir)

            # Write envelope
            env_path = tmpdir_path / "envelope.json"
            env_path.write_text(test_envelope.model_dump_json(indent=2))

            # Write evidence
            ev_path = tmpdir_path / "evidence.json"
            ev_data = [json.loads(e.model_dump_json()) for e in test_evidence_list]
            ev_path.write_text(json.dumps(ev_data, indent=2))

            # Write default policy
            policy_path = tmpdir_path / "policy.yaml"
            policy_dict = DEFAULT_POLICY.model_dump(exclude_none=True)
            policy_yaml = yaml.dump(policy_dict, default_flow_style=False)
            policy_path.write_text(policy_yaml)

            # Replay
            reproduced_verdict, matches = replay(
                str(env_path),
                str(ev_path),
                str(policy_path),
            )

            # The rule-based engine should return VERIFIED with 1 supporting source
            assert reproduced_verdict == Verdict.VERIFIED
            assert matches is True


class TestReplayDetectsDivergence:
    """test_replay_detects_divergence"""

    def test_replay_detects_divergence_when_evidence_changed(
        self, test_claim: Claim, test_evidence_list: list[Evidence], test_envelope: Envelope
    ) -> None:
        """replay() detects when evidence diverges."""
        from gtv.cli.replay import replay

        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir_path = Path(tmpdir)

            # Write envelope with VERIFIED verdict
            env_path = tmpdir_path / "envelope.json"
            env_path.write_text(test_envelope.model_dump_json(indent=2))

            # Write EMPTY evidence (different from what's in envelope)
            ev_path = tmpdir_path / "evidence.json"
            ev_path.write_text("[]")

            # Write default policy
            policy_path = tmpdir_path / "policy.yaml"
            policy_dict = DEFAULT_POLICY.model_dump(exclude_none=True)
            policy_yaml = yaml.dump(policy_dict, default_flow_style=False)
            policy_path.write_text(policy_yaml)

            # Replay
            reproduced_verdict, matches = replay(
                str(env_path),
                str(ev_path),
                str(policy_path),
            )

            # With no evidence, engine returns UNVERIFIED
            assert reproduced_verdict == Verdict.UNVERIFIED
            # Original envelope says VERIFIED, so mismatch
            assert matches is False


class TestCliEntryPoint:
    """test_cli_entry_point"""

    def test_cli_help_succeeds(self) -> None:
        """gtv-replay --help exits 0."""
        from gtv.cli.replay import main

        result = main(["--help"])
        assert result == 0

    def test_cli_missing_args_fails(self) -> None:
        """gtv-replay with missing args exits 2."""
        from gtv.cli.replay import main

        result = main([])
        # argparse exits with 2 on missing required args
        assert result == 2

    def test_cli_full_run_matches(
        self, test_claim: Claim, test_evidence_list: list[Evidence], test_envelope: Envelope,
        capsys,
    ) -> None:
        """Full CLI run with matching verdict exits 0."""
        from gtv.cli.replay import main

        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir_path = Path(tmpdir)

            # Write files
            env_path = tmpdir_path / "envelope.json"
            env_path.write_text(test_envelope.model_dump_json(indent=2))

            ev_path = tmpdir_path / "evidence.json"
            ev_data = [json.loads(e.model_dump_json()) for e in test_evidence_list]
            ev_path.write_text(json.dumps(ev_data, indent=2))

            policy_path = tmpdir_path / "policy.yaml"
            policy_dict = DEFAULT_POLICY.model_dump(exclude_none=True)
            policy_yaml = yaml.dump(policy_dict, default_flow_style=False)
            policy_path.write_text(policy_yaml)

            # Run CLI
            result = main(
                [
                    "--envelope",
                    str(env_path),
                    "--evidence",
                    str(ev_path),
                    "--policy",
                    str(policy_path),
                ]
            )

            captured = capsys.readouterr()
            assert result == 0
            assert "VERIFIED" in captured.out
            assert "Matches original: True" in captured.out

    def test_cli_full_run_diverged(
        self, test_claim: Claim, test_evidence_list: list[Evidence], test_envelope: Envelope,
        capsys,
    ) -> None:
        """Full CLI run with diverged verdict exits 2."""
        from gtv.cli.replay import main

        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir_path = Path(tmpdir)

            # Write files
            env_path = tmpdir_path / "envelope.json"
            env_path.write_text(test_envelope.model_dump_json(indent=2))

            # Empty evidence causes divergence
            ev_path = tmpdir_path / "evidence.json"
            ev_path.write_text("[]")

            policy_path = tmpdir_path / "policy.yaml"
            policy_dict = DEFAULT_POLICY.model_dump(exclude_none=True)
            policy_yaml = yaml.dump(policy_dict, default_flow_style=False)
            policy_path.write_text(policy_yaml)

            # Run CLI
            result = main(
                [
                    "--envelope",
                    str(env_path),
                    "--evidence",
                    str(ev_path),
                    "--policy",
                    str(policy_path),
                ]
            )

            captured = capsys.readouterr()
            assert result == 2
            assert "UNVERIFIED" in captured.out
            assert "Matches original: False" in captured.out

    def test_cli_json_output_format(
        self, test_claim: Claim, test_evidence_list: list[Evidence], test_envelope: Envelope,
        capsys,
    ) -> None:
        """CLI --json flag emits valid JSON."""
        from gtv.cli.replay import main

        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir_path = Path(tmpdir)

            env_path = tmpdir_path / "envelope.json"
            env_path.write_text(test_envelope.model_dump_json(indent=2))

            ev_path = tmpdir_path / "evidence.json"
            ev_data = [json.loads(e.model_dump_json()) for e in test_evidence_list]
            ev_path.write_text(json.dumps(ev_data, indent=2))

            policy_path = tmpdir_path / "policy.yaml"
            policy_dict = DEFAULT_POLICY.model_dump(exclude_none=True)
            policy_yaml = yaml.dump(policy_dict, default_flow_style=False)
            policy_path.write_text(policy_yaml)

            result = main(
                [
                    "--envelope",
                    str(env_path),
                    "--evidence",
                    str(ev_path),
                    "--policy",
                    str(policy_path),
                    "--json",
                ]
            )

            captured = capsys.readouterr()
            assert result == 0
            output = json.loads(captured.out)
            assert "reproduced_verdict" in output
            assert "matches_original" in output
            assert output["reproduced_verdict"] == "VERIFIED"
            assert output["matches_original"] is True


class TestReplayErrorHandling:
    """Error handling in replay()."""

    def test_replay_missing_envelope_file(self) -> None:
        """replay() raises FileNotFoundError for missing envelope."""
        from gtv.cli.replay import replay

        with pytest.raises(FileNotFoundError):
            replay(
                "/nonexistent/envelope.json",
                "/nonexistent/evidence.json",
                "/nonexistent/policy.yaml",
            )

    def test_replay_invalid_envelope_json(self) -> None:
        """replay() raises ValueError for invalid envelope JSON."""
        from gtv.cli.replay import replay

        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir_path = Path(tmpdir)

            env_path = tmpdir_path / "envelope.json"
            env_path.write_text("{invalid json")

            ev_path = tmpdir_path / "evidence.json"
            ev_path.write_text("[]")

            policy_path = tmpdir_path / "policy.yaml"
            policy_path.write_text("")

            with pytest.raises(ValueError, match="Invalid JSON in envelope"):
                replay(
                    str(env_path),
                    str(ev_path),
                    str(policy_path),
                )

    def test_replay_evidence_not_array(self) -> None:
        """replay() raises ValueError if evidence is not an array."""
        from gtv.cli.replay import replay

        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir_path = Path(tmpdir)

            # Create a valid envelope first
            test_envelope = Envelope(
                envelope_id="env-1",
                verdict=Verdict.VERIFIED,
                confidence=0.8,
                evidence=[],
                rationale="Test.",
                issuer_did="issuer-1",
                issued_at=datetime.now(tz=UTC),
                signature="sig-stub",
                rekor_uuid="rekor-1",
                rekor_log_index=0,
                tsa_token="tsa-1",
                prov_graph="{}",
                anchor_proof=AnchorProof(
                    rekor_inclusion_proof="proof-1",
                    tsa_tsr_primary="tsr-1",
                ),
            )

            env_path = tmpdir_path / "envelope.json"
            env_path.write_text(test_envelope.model_dump_json(indent=2))

            ev_path = tmpdir_path / "evidence.json"
            ev_path.write_text('{"not": "array"}')

            policy_path = tmpdir_path / "policy.yaml"
            policy_path.write_text("")

            with pytest.raises(ValueError, match="Evidence must be a JSON array"):
                replay(
                    str(env_path),
                    str(ev_path),
                    str(policy_path),
                )
