"""Tests for the ``gtv-lifecycle`` CLI (``gtv.cli.lifecycle``).

Two layers:

1. **Unit tests** — respx-mocked HTTP. Fast, covers all command surfaces
   and error branches (network error, 404, 403, missing API key).
2. **Integration test** — real FastAPI ``TestClient`` with an in-process
   static adapter. Proves the wire-up end-to-end: history → supersede
   → latest round-trip against the actual server.
"""

from __future__ import annotations

import asyncio
import io
import json
from contextlib import redirect_stderr, redirect_stdout
from datetime import UTC, datetime
from typing import Any

import httpx
import pytest
import respx

from gtv.adapters import REGISTRY
from gtv.adapters.base import HealthStatus, RawSnapshot, SourceAdapter
from gtv.cli import lifecycle as lifecycle_cli
from gtv.mcp.server import _LIFECYCLE, _VERDICT_CACHE, app
from gtv.models import Claim, Evidence, SourceType, Stance, TrustTier

BASE = "http://gtv.example"


def _run(argv: list[str]) -> tuple[int, str, str]:
    """Run the CLI entry point, capture stdout/stderr."""
    out, err = io.StringIO(), io.StringIO()
    with redirect_stdout(out), redirect_stderr(err):
        rc = lifecycle_cli.main(argv)
    return rc, out.getvalue(), err.getvalue()


# ---------------------------------------------------------------------------
# Unit tests — history
# ---------------------------------------------------------------------------


@respx.mock
def test_history_text_output_renders_chain() -> None:
    respx.get(f"{BASE}/claims/env-xyz/history").mock(
        return_value=httpx.Response(
            200,
            json={
                "entries": [
                    {
                        "envelope_id": "env-head",
                        "issuer_did": "did:web:a",
                        "domain": "physics",
                        "verdict": "VERIFIED",
                        "parents": ["env-mid"],
                        "supersede_reason": "SUPERSEDE",
                    },
                    {
                        "envelope_id": "env-mid",
                        "issuer_did": "did:web:a",
                        "domain": "physics",
                        "verdict": "VERIFIED",
                        "parents": ["env-root"],
                        "supersede_reason": "AMEND",
                    },
                    {
                        "envelope_id": "env-root",
                        "issuer_did": "did:web:a",
                        "domain": "physics",
                        "verdict": "VERIFIED",
                        "parents": [],
                        "supersede_reason": None,
                    },
                ]
            },
        )
    )

    rc, out, err = _run(["--base-url", BASE, "history", "env-xyz"])
    assert rc == 0, err
    assert "[HEAD] env-head" in out
    assert "env-mid" in out and "env-root" in out
    assert "SUPERSEDE" in out and "AMEND" in out


@respx.mock
def test_history_json_output_is_raw_payload() -> None:
    payload = {"entries": [{"envelope_id": "e1", "issuer_did": "x",
                            "domain": "general", "verdict": "VERIFIED",
                            "parents": [], "supersede_reason": None}]}
    respx.get(f"{BASE}/claims/e1/history").mock(return_value=httpx.Response(200, json=payload))

    rc, out, err = _run(["--base-url", BASE, "--json", "history", "e1"])
    assert rc == 0, err
    assert json.loads(out) == payload


@respx.mock
def test_history_404_returns_1_and_prints_detail() -> None:
    respx.get(f"{BASE}/claims/missing/history").mock(
        return_value=httpx.Response(404, json={"detail": "not registered"})
    )
    rc, _out, err = _run(["--base-url", BASE, "history", "missing"])
    assert rc == 1
    assert "not registered" in err


@respx.mock
def test_history_network_error_returns_2() -> None:
    respx.get(f"{BASE}/claims/anything/history").mock(side_effect=httpx.ConnectError("boom"))
    rc, _out, err = _run(["--base-url", BASE, "history", "anything"])
    assert rc == 2
    assert "boom" in err


# ---------------------------------------------------------------------------
# Unit tests — latest
# ---------------------------------------------------------------------------


@respx.mock
def test_latest_happy_path_renders_envelope() -> None:
    respx.get(f"{BASE}/claims/latest").mock(
        return_value=httpx.Response(
            200,
            json={
                "envelope": {
                    "envelope_id": "env-head",
                    "claim_id": "c1",
                    "verdict": "VERIFIED",
                    "confidence": 0.9,
                    "issuer_did": "did:web:a",
                    "issued_at": "2026-04-21T00:00:00Z",
                    "supersedes": ["env-prev"],
                    "supersede_reason": "SUPERSEDE",
                    "evidence": [{}, {}],
                }
            },
        )
    )
    rc, out, err = _run([
        "--base-url", BASE, "latest", "Water boils at 100C.",
        "--domain", "physics", "--issuer-did", "did:web:a",
    ])
    assert rc == 0, err
    assert "env-head" in out
    assert "env-prev" in out
    assert "2 item(s)" in out


@respx.mock
def test_latest_passes_query_params() -> None:
    route = respx.get(f"{BASE}/claims/latest").mock(
        return_value=httpx.Response(
            200, json={"envelope": {"envelope_id": "e", "supersedes": []}}
        )
    )
    rc, _, err = _run([
        "--base-url", BASE, "latest", "My claim",
        "--domain", "math", "--issuer-did", "did:web:x",
    ])
    assert rc == 0, err
    called = route.calls.last.request
    assert called.url.params["claim"] == "My claim"
    assert called.url.params["domain"] == "math"
    assert called.url.params["issuer_did"] == "did:web:x"


@respx.mock
def test_latest_404_returns_1() -> None:
    respx.get(f"{BASE}/claims/latest").mock(
        return_value=httpx.Response(404, json={"detail": "No envelope."})
    )
    rc, _, err = _run(["--base-url", BASE, "latest", "Nothing here."])
    assert rc == 1
    assert "No envelope" in err


# ---------------------------------------------------------------------------
# Unit tests — supersede
# ---------------------------------------------------------------------------


def test_supersede_without_api_key_returns_2() -> None:
    # Force GTV_API_KEY absent via explicit empty string handling — we
    # rely on not setting --api-key and the env var not being in pytest's
    # environment. Use monkeypatch-equivalent via direct main() call.
    import os

    prev = os.environ.pop("GTV_API_KEY", None)
    try:
        rc, _, err = _run([
            "--base-url", BASE, "supersede", "env-parent",
            "--claim", "New claim.",
        ])
    finally:
        if prev is not None:
            os.environ["GTV_API_KEY"] = prev

    assert rc == 2
    assert "requires authentication" in err


@respx.mock
def test_supersede_sends_auth_header_and_body() -> None:
    route = respx.post(f"{BASE}/tools/supersede_claim").mock(
        return_value=httpx.Response(
            200,
            json={
                "envelope": {
                    "envelope_id": "env-new",
                    "supersedes": ["env-parent"],
                    "supersede_reason": "WITHDRAW",
                }
            },
        )
    )
    rc, out, err = _run([
        "--base-url", BASE, "--api-key", "tok-abc",
        "supersede", "env-parent",
        "--claim", "I retract.", "--reason", "WITHDRAW",
        "--domain", "general", "--max-sources", "3",
    ])
    assert rc == 0, err
    sent = route.calls.last.request
    assert sent.headers["authorization"] == "Bearer tok-abc"
    body = json.loads(sent.content)
    assert body == {
        "parent_envelope_id": "env-parent",
        "claim": "I retract.",
        "domain": "general",
        "reason": "WITHDRAW",
        "max_sources": 3,
    }
    assert "env-new" in out
    assert "Superseded env-parent" in out


@respx.mock
def test_supersede_403_returns_1() -> None:
    respx.post(f"{BASE}/tools/supersede_claim").mock(
        return_value=httpx.Response(403, json={"detail": "Cannot supersede."})
    )
    rc, _, err = _run([
        "--base-url", BASE, "--api-key", "tok",
        "supersede", "env-x", "--claim", "Whatever.",
    ])
    assert rc == 1
    assert "Cannot supersede" in err


# ---------------------------------------------------------------------------
# Argparse / wiring
# ---------------------------------------------------------------------------


def test_invalid_reason_is_rejected() -> None:
    rc, _, err = _run([
        "--base-url", BASE, "--api-key", "t",
        "supersede", "env-p", "--claim", "x", "--reason", "BOGUS",
    ])
    assert rc == 2
    assert "invalid choice" in err.lower() or "BOGUS" in err


def test_missing_subcommand_returns_nonzero() -> None:
    rc, _, _ = _run([])
    assert rc != 0


def test_env_var_base_url(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("GTV_BASE_URL", BASE)
    with respx.mock:
        respx.get(f"{BASE}/claims/e/history").mock(
            return_value=httpx.Response(200, json={"entries": []})
        )
        rc, out, _ = _run(["history", "e"])
        assert rc == 0
        assert "(empty chain)" in out


# ---------------------------------------------------------------------------
# Integration — real FastAPI server through TestClient-shaped httpx
# ---------------------------------------------------------------------------


class _StaticAdapter(SourceAdapter):
    source_did = "did:web:lifecycle-fixture.example"

    def __init__(self) -> None:
        self.name = "LifecycleFixture"
        self.type = SourceType.REFERENCE_DATA
        self.trust_tier = TrustTier.TIER_1
        self.freshness_sla_s = 86400
        self.last_audit = datetime.now(tz=UTC)

    async def query(self, claim: Claim, max_items: int = 5) -> list[Evidence]:
        return [
            Evidence(
                claim_id=claim.claim_id,
                source_did=self.source_did,
                source_version="1.0",
                stance=Stance.SUPPORTS,
                excerpt="Evidence for integration test.",
                url="https://example.com/ref",
                retrieved_at=datetime.now(tz=UTC),
                raw_hash="0" * 64,
            )
        ]

    async def snapshot(self, url: str) -> RawSnapshot:
        return RawSnapshot(
            url=url, mime_type="text/plain", size_bytes=0, body=b"", sha256_hex="0" * 64
        )

    async def health(self) -> HealthStatus:
        return HealthStatus.HEALTHY

    async def close(self) -> None:
        return None


@pytest.fixture
def live_server(monkeypatch: pytest.MonkeyPatch):
    """Patch the CLI's httpx.get/post to talk to an in-process FastAPI app.

    Leaves every other test isolated: we swap the httpx module-level
    functions only inside the CLI module, and restore the registry /
    lifecycle index on teardown.
    """
    from fastapi.testclient import TestClient

    monkeypatch.setenv("GTV_DISABLE_DEFAULT_ADAPTERS", "1")
    saved_registry = dict(REGISTRY)
    REGISTRY.clear()
    REGISTRY[_StaticAdapter.source_did] = _StaticAdapter()
    asyncio.run(_VERDICT_CACHE.clear())
    # Clear lifecycle index so envelope IDs are fresh per-test.
    if hasattr(_LIFECYCLE, "_entries"):
        _LIFECYCLE._entries.clear()
    if hasattr(_LIFECYCLE, "_envelopes"):
        _LIFECYCLE._envelopes.clear()

    client = TestClient(app)

    def fake_get(url: str, **kw: Any) -> httpx.Response:
        # Strip the scheme/host so TestClient gets just the path+query.
        path = url.replace("http://localhost:8000", "")
        return client.get(path, params=kw.get("params"), headers=kw.get("headers") or {})

    def fake_post(url: str, **kw: Any) -> httpx.Response:
        path = url.replace("http://localhost:8000", "")
        return client.post(path, content=kw.get("content"), headers=kw.get("headers") or {})

    monkeypatch.setattr(lifecycle_cli.httpx, "get", fake_get)
    monkeypatch.setattr(lifecycle_cli.httpx, "post", fake_post)

    try:
        yield client
    finally:
        REGISTRY.clear()
        REGISTRY.update(saved_registry)


def test_integration_history_on_unknown_envelope_returns_1(live_server) -> None:
    rc, _, err = _run(["history", "env-never-registered"])
    assert rc == 1
    assert "lifecycle" in err.lower() or "not registered" in err.lower()


def test_integration_verify_then_history_walks_chain(live_server) -> None:
    # 1. Post a verify_claim to populate the lifecycle index with a root.
    r = live_server.post(
        "/tools/verify_claim",
        json={"claim": "Integration root claim.", "domain": "general", "max_sources": 3},
    )
    assert r.status_code == 200, r.text
    root_env_id = r.json()["envelope"]["envelope_id"]

    # 2. Call `gtv-lifecycle history` against it.
    rc, out, err = _run(["history", root_env_id])
    assert rc == 0, err
    assert root_env_id in out
    assert "HEAD" in out
