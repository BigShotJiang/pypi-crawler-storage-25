"""Tests for the gtv-fed CLI (gtv.cli.federation).

Unit tests covering all peer subcommands with text and JSON output,
revocation persistence, and error handling. Uses respx for HTTP mocking.
"""

from __future__ import annotations

import io
import json
import tempfile
from contextlib import redirect_stderr, redirect_stdout
from pathlib import Path
from unittest.mock import MagicMock, patch

from gtv.cli.federation import main
from gtv.federation.discovery import DiscoveredPeer
from gtv.federation.peer import FederationPeer


def _run(argv: list[str]) -> tuple[int, str, str]:
    """Run the CLI entry point, capture stdout/stderr."""
    out, err = io.StringIO(), io.StringIO()
    with redirect_stdout(out), redirect_stderr(err):
        rc = main(argv)
    return rc, out.getvalue(), err.getvalue()


# ---------------------------------------------------------------------------
# Test: peers list
# ---------------------------------------------------------------------------


def test_peers_list_empty() -> None:
    """Test peers list with no configured or discovered peers."""
    with patch("gtv.cli.federation.load_peers_from_env", return_value=[]), patch(
        "gtv.cli.federation._discover_peers_async",
        return_value=[],
    ):
        rc, out, _err = _run(["peers", "list"])
        assert rc == 0
        assert "(no peers)" in out


def test_peers_list_shows_env_peers() -> None:
    """Test peers list includes env-configured peers."""
    env_peers = [
        FederationPeer(did="did:web:peer1.example", url="https://peer1.example", api_key="key1"),
        FederationPeer(did="did:web:peer2.example", url="https://peer2.example", api_key=""),
    ]
    with patch("gtv.cli.federation.load_peers_from_env", return_value=env_peers), patch(
        "gtv.cli.federation._discover_peers_async",
        return_value=[],
    ):
        rc, out, _err = _run(["peers", "list"])
        assert rc == 0
        assert "did:web:peer1.example" in out
        assert "did:web:peer2.example" in out
        assert "env" in out


def test_peers_list_shows_discovered_peers() -> None:
    """Test peers list includes discovered peers."""
    discovered = [
        DiscoveredPeer(
            did="did:web:discovered1.example",
            endpoint_url="https://discovered1.example",
            discovered_via="did",
            verified=True,
        ),
    ]
    with patch("gtv.cli.federation.load_peers_from_env", return_value=[]), patch(
        "gtv.cli.federation._discover_peers_async",
        return_value=discovered,
    ):
        rc, out, _err = _run(["peers", "list"])
        assert rc == 0
        assert "did:web:discovered1.example" in out
        assert "did" in out


def test_peers_list_json_output() -> None:
    """Test peers list with --json flag."""
    env_peers = [
        FederationPeer(did="did:web:peer1.example", url="https://peer1.example"),
    ]
    with patch("gtv.cli.federation.load_peers_from_env", return_value=env_peers), patch(
        "gtv.cli.federation._discover_peers_async",
        return_value=[],
    ):
        rc, out, _err = _run(["--json", "peers", "list"])
        assert rc == 0
        data = json.loads(out)
        assert isinstance(data, list)
        assert len(data) == 1
        assert data[0]["did"] == "did:web:peer1.example"
        assert "endpoint_url" in data[0]


def test_peers_list_excludes_revoked_by_default() -> None:
    """Test peers list excludes revoked peers by default."""
    env_peers = [
        FederationPeer(did="did:web:peer1.example", url="https://peer1.example"),
        FederationPeer(did="did:web:peer2.example", url="https://peer2.example"),
    ]
    with patch("gtv.cli.federation.load_peers_from_env", return_value=env_peers), patch(
        "gtv.cli.federation._discover_peers_async",
        return_value=[],
    ), patch("gtv.cli.federation._load_revoked_peers", return_value={"did:web:peer1.example"}):
        rc, out, _err = _run(["peers", "list"])
        assert rc == 0
        assert "did:web:peer1.example" not in out
        assert "did:web:peer2.example" in out


def test_peers_list_shows_revoked_with_all_flag() -> None:
    """Test peers list shows revoked peers with --all flag."""
    env_peers = [
        FederationPeer(did="did:web:peer1.example", url="https://peer1.example"),
    ]
    with patch("gtv.cli.federation.load_peers_from_env", return_value=env_peers), patch(
        "gtv.cli.federation._discover_peers_async",
        return_value=[],
    ), patch("gtv.cli.federation._load_revoked_peers", return_value={"did:web:peer1.example"}):
        rc, out, _err = _run(["peers", "list", "--all"])
        assert rc == 0
        assert "did:web:peer1.example" in out


# ---------------------------------------------------------------------------
# Test: peers discover
# ---------------------------------------------------------------------------


def test_peers_discover_requires_root_did() -> None:
    """Test peers discover fails without GTV_FEDERATION_ROOT_DID."""
    with patch("gtv.cli.federation.load_discovery_config_from_env", return_value=None):
        rc, _out, err = _run(["peers", "discover"])
        assert rc == 1
        assert "GTV_FEDERATION_ROOT_DID not set" in err


def test_peers_discover_returns_discovered_peers() -> None:
    """Test peers discover returns discovered peers."""
    discovered = [
        DiscoveredPeer(
            did="did:web:peer1.example",
            endpoint_url="https://peer1.example",
            discovered_via="did",
            verified=True,
        ),
    ]
    with patch("gtv.cli.federation.load_discovery_config_from_env", return_value="did:web:root"), patch(
        "gtv.cli.federation._discover_peers_async",
        return_value=discovered,
    ):
        rc, out, _err = _run(["peers", "discover"])
        assert rc == 0
        assert "Discovered 1 peer" in out
        assert "did:web:peer1.example" in out


def test_peers_discover_json_output() -> None:
    """Test peers discover with --json flag."""
    discovered = [
        DiscoveredPeer(
            did="did:web:peer1.example",
            endpoint_url="https://peer1.example",
            discovered_via="did",
            verified=True,
            api_key="secret",
        ),
    ]
    with patch("gtv.cli.federation.load_discovery_config_from_env", return_value="did:web:root"), patch(
        "gtv.cli.federation._discover_peers_async",
        return_value=discovered,
    ):
        rc, out, _err = _run(["--json", "peers", "discover"])
        assert rc == 0
        data = json.loads(out)
        assert isinstance(data, list)
        assert len(data) == 1
        assert data[0]["did"] == "did:web:peer1.example"
        assert data[0]["verified"] is True


def test_peers_discover_empty() -> None:
    """Test peers discover with no discovered peers."""
    with patch("gtv.cli.federation.load_discovery_config_from_env", return_value="did:web:root"), patch(
        "gtv.cli.federation._discover_peers_async",
        return_value=[],
    ):
        rc, out, _err = _run(["peers", "discover"])
        assert rc == 0
        assert "No peers discovered" in out


# ---------------------------------------------------------------------------
# Test: peers health
# ---------------------------------------------------------------------------


def test_peers_health_peer_not_found() -> None:
    """Test peers health with non-existent peer."""
    with patch("gtv.cli.federation.load_peers_from_env", return_value=[]), patch(
        "gtv.cli.federation._discover_peers_async",
        return_value=[],
    ):
        rc, _out, err = _run(["peers", "health", "did:web:nonexistent.example"])
        assert rc == 1
        assert "Peer not found" in err


@patch("gtv.cli.federation._health_probe_async")
def test_peers_health_success(mock_probe: MagicMock) -> None:
    """Test peers health with successful probe."""
    mock_probe.return_value = (200, 0.05)
    env_peers = [
        FederationPeer(did="did:web:peer1.example", url="https://peer1.example"),
    ]
    with patch("gtv.cli.federation.load_peers_from_env", return_value=env_peers), patch(
        "gtv.cli.federation._discover_peers_async",
        return_value=[],
    ):
        rc, out, _err = _run(["peers", "health", "did:web:peer1.example"])
        assert rc == 0
        assert "Health check" in out
        assert "200" in out
        assert "50.00ms" in out


@patch("gtv.cli.federation._health_probe_async")
def test_peers_health_probe_failure(mock_probe: MagicMock) -> None:
    """Test peers health with probe failure."""
    mock_probe.return_value = (None, 3.0)
    env_peers = [
        FederationPeer(did="did:web:peer1.example", url="https://peer1.example"),
    ]
    with patch("gtv.cli.federation.load_peers_from_env", return_value=env_peers), patch(
        "gtv.cli.federation._discover_peers_async",
        return_value=[],
    ):
        rc, out, _err = _run(["peers", "health", "did:web:peer1.example"])
        assert rc == 2
        assert "failed" in out.lower()


@patch("gtv.cli.federation._health_probe_async")
def test_peers_health_json_output(mock_probe: MagicMock) -> None:
    """Test peers health with --json flag."""
    mock_probe.return_value = (200, 0.05)
    env_peers = [
        FederationPeer(did="did:web:peer1.example", url="https://peer1.example"),
    ]
    with patch("gtv.cli.federation.load_peers_from_env", return_value=env_peers), patch(
        "gtv.cli.federation._discover_peers_async",
        return_value=[],
    ):
        rc, out, _err = _run(["--json", "peers", "health", "did:web:peer1.example"])
        assert rc == 0
        data = json.loads(out)
        assert data["status_code"] == 200
        assert data["latency_ms"] == 50.0


# ---------------------------------------------------------------------------
# Test: peers revoke
# ---------------------------------------------------------------------------


def test_peers_revoke_peer_not_found() -> None:
    """Test peers revoke with non-existent peer."""
    with patch("gtv.cli.federation.load_peers_from_env", return_value=[]), patch(
        "gtv.cli.federation._discover_peers_async",
        return_value=[],
    ):
        rc, _out, err = _run(["peers", "revoke", "did:web:nonexistent.example"])
        assert rc == 1
        assert "Peer not found" in err


def test_peers_revoke_persists_locally() -> None:
    """Test peers revoke persists revocation to local storage."""
    env_peers = [
        FederationPeer(did="did:web:peer1.example", url="https://peer1.example"),
    ]
    with tempfile.TemporaryDirectory() as tmpdir:
        revoked_path = Path(tmpdir) / "revoked.json"
        with patch("gtv.cli.federation.load_peers_from_env", return_value=env_peers), patch(
            "gtv.cli.federation._discover_peers_async",
            return_value=[],
        ), patch("gtv.cli.federation._revoked_peers_path", return_value=revoked_path), patch(
            "gtv.cli.federation._load_revoked_peers",
            return_value=set(),
        ):
            # Mock _save_revoked_peers to capture what would be saved
            saved = {}

            def capture_save(revoked: set[str]) -> None:
                saved["revoked"] = revoked

            with patch("gtv.cli.federation._save_revoked_peers", side_effect=capture_save):
                rc, out, _err = _run(["peers", "revoke", "did:web:peer1.example"])
                assert rc == 0
                assert "Revoked peer" in out
                assert "did:web:peer1.example" in saved.get("revoked", set())


def test_peers_revoke_already_revoked() -> None:
    """Test peers revoke when peer already revoked."""
    env_peers = [
        FederationPeer(did="did:web:peer1.example", url="https://peer1.example"),
    ]
    with patch("gtv.cli.federation.load_peers_from_env", return_value=env_peers), patch(
        "gtv.cli.federation._discover_peers_async",
        return_value=[],
    ), patch("gtv.cli.federation._load_revoked_peers", return_value={"did:web:peer1.example"}), patch(
        "gtv.cli.federation._save_revoked_peers",
    ):
        rc, out, _err = _run(["peers", "revoke", "did:web:peer1.example"])
        assert rc == 0
        assert "already revoked" in out


def test_peers_revoke_json_output() -> None:
    """Test peers revoke with --json flag."""
    env_peers = [
        FederationPeer(did="did:web:peer1.example", url="https://peer1.example"),
    ]
    with patch("gtv.cli.federation.load_peers_from_env", return_value=env_peers), patch(
        "gtv.cli.federation._discover_peers_async",
        return_value=[],
    ), patch("gtv.cli.federation._load_revoked_peers", return_value=set()), patch(
        "gtv.cli.federation._save_revoked_peers",
    ):
        rc, out, _err = _run(["--json", "peers", "revoke", "did:web:peer1.example"])
        assert rc == 0
        data = json.loads(out)
        assert data["did"] == "did:web:peer1.example"
        assert data["status"] == "revoked"


# ---------------------------------------------------------------------------
# Test: invalid commands and help
# ---------------------------------------------------------------------------


def test_invalid_peers_subcommand() -> None:
    """Test invalid peers subcommand returns 2."""
    rc, _out, _err = _run(["peers", "invalid"])
    assert rc == 2


def test_peers_without_subcommand() -> None:
    """Test peers without subcommand returns 2."""
    rc, _out, _err = _run(["peers"])
    assert rc == 2


def test_help_flag() -> None:
    """Test --help returns 0."""
    rc, out, _err = _run(["--help"])
    assert rc == 0
    assert "gtv-fed" in out.lower() or "usage:" in out.lower()


def test_peers_health_help() -> None:
    """Test peers health --help."""
    rc, out, _err = _run(["peers", "health", "--help"])
    assert rc == 0
    assert "health" in out.lower() or "probe" in out.lower()


# ---------------------------------------------------------------------------
# Test: revocation persistence across calls
# ---------------------------------------------------------------------------


def test_revoke_persists_and_is_read_on_next_list() -> None:
    """Test that revocation persists and affects subsequent list calls."""
    peer1 = FederationPeer(did="did:web:peer1.example", url="https://peer1.example")
    peer2 = FederationPeer(did="did:web:peer2.example", url="https://peer2.example")
    env_peers = [peer1, peer2]

    with tempfile.TemporaryDirectory() as tmpdir:
        revoked_path = Path(tmpdir) / "revoked.json"

        # Revoke peer1
        saved_revoked = set()

        def capture_save(revoked: set[str]) -> None:
            nonlocal saved_revoked
            saved_revoked = revoked
            revoked_path.parent.mkdir(parents=True, exist_ok=True)
            revoked_path.write_text(json.dumps({"revoked_dids": sorted(revoked)}))

        with patch("gtv.cli.federation.load_peers_from_env", return_value=env_peers), patch(
            "gtv.cli.federation._discover_peers_async",
            return_value=[],
        ), patch("gtv.cli.federation._revoked_peers_path", return_value=revoked_path), patch(
            "gtv.cli.federation._load_revoked_peers",
            side_effect=lambda: set(json.loads(revoked_path.read_text()).get("revoked_dids", [])) if revoked_path.exists() else set(),
        ), patch("gtv.cli.federation._save_revoked_peers", side_effect=capture_save):
            # Revoke peer1
            rc, out, _err = _run(["peers", "revoke", "did:web:peer1.example"])
            assert rc == 0

            # List peers again (should not show peer1)
            rc, out, _err = _run(["peers", "list"])
            assert rc == 0
            assert "did:web:peer2.example" in out
            # peer1 should be filtered out
