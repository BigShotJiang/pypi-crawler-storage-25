"""Integration tests for gtv-revoke CLI."""
from __future__ import annotations

import json
from datetime import UTC, datetime

import pytest
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ed25519

from gtv.cli.revoke import main
from gtv.models import AnchorProof, Envelope
from gtv.revocation.list import build_revocation_list


@pytest.fixture
def ed25519_private_key_pem(tmp_path):
    """Generate a test Ed25519 private key in PEM format."""
    private_key = ed25519.Ed25519PrivateKey.generate()
    pem_bytes = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    pem_file = tmp_path / "test_key.pem"
    pem_file.write_bytes(pem_bytes)
    return pem_file


@pytest.fixture
def issuer_did(ed25519_private_key_pem):
    """Derive the issuer_did from the test key."""
    pem_bytes = ed25519_private_key_pem.read_bytes()
    private_key = serialization.load_pem_private_key(pem_bytes, password=None)
    public_key = private_key.public_key()
    raw_bytes = public_key.public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    from gtv.sign.byok import _derive_did_key_from_public_key
    return _derive_did_key_from_public_key("Ed25519", raw_bytes)


@pytest.fixture
def test_envelope(tmp_path) -> Envelope:
    """Create and save a test envelope."""
    envelope = Envelope(
        envelope_id="test-envelope-1",
        verdict="VERIFIED",
        confidence=0.95,
        evidence=[],
        issuer_did="did:key:ztest_issuer",
        issued_at=datetime.now(tz=UTC),
        signature="byok-ed25519:fake",
        rekor_uuid="test-uuid",
        rekor_log_index=42,
        tsa_token="fake-tsa",
        prov_graph="{}",
        anchor_proof=AnchorProof(
            rekor_inclusion_proof="fake",
            tsa_tsr_primary="fake",
        ),
    )
    env_file = tmp_path / "envelope.json"
    env_file.write_text(envelope.model_dump_json(), encoding="utf-8")
    return envelope


class TestCreateCommand:
    """Test gtv-revoke create."""

    def test_create_basic(self, tmp_path, issuer_did, ed25519_private_key_pem):
        """Test basic create command."""
        out_file = tmp_path / "list.json"
        argv = [
            "create",
            "--issuer-did", issuer_did,
            "--key", str(ed25519_private_key_pem),
            "--envelope-id", "env-1",
            "--out", str(out_file),
        ]

        exit_code = main(argv)
        assert exit_code == 0
        assert out_file.exists()

        data = json.loads(out_file.read_text())
        assert data["issuer_did"] == issuer_did
        assert "env-1" in data["revoked_envelope_ids"]

    def test_create_with_issuer_dids(self, tmp_path, issuer_did, ed25519_private_key_pem):
        """Test create with issuer_dids."""
        out_file = tmp_path / "list.json"
        argv = [
            "create",
            "--issuer-did", issuer_did,
            "--key", str(ed25519_private_key_pem),
            "--issuer-did-revoke", "did:key:zcompromised",
            "--out", str(out_file),
        ]

        exit_code = main(argv)
        assert exit_code == 0
        assert out_file.exists()

        data = json.loads(out_file.read_text())
        assert "did:key:zcompromised" in data["revoked_issuer_dids"]

    def test_create_with_rekor_indices(self, tmp_path, issuer_did, ed25519_private_key_pem):
        """Test create with rekor_indices."""
        out_file = tmp_path / "list.json"
        argv = [
            "create",
            "--issuer-did", issuer_did,
            "--key", str(ed25519_private_key_pem),
            "--rekor-index", "42",
            "--rekor-index", "100",
            "--out", str(out_file),
        ]

        exit_code = main(argv)
        assert exit_code == 0

        data = json.loads(out_file.read_text())
        assert 42 in data["revoked_rekor_log_indices"]
        assert 100 in data["revoked_rekor_log_indices"]

    def test_create_missing_issuer_did(self, tmp_path, ed25519_private_key_pem):
        """Test create fails without issuer_did."""
        out_file = tmp_path / "list.json"
        argv = [
            "create",
            "--key", str(ed25519_private_key_pem),
            "--out", str(out_file),
        ]

        exit_code = main(argv)
        assert exit_code == 2

    def test_create_missing_key(self, tmp_path, issuer_did):
        """Test create fails without key."""
        out_file = tmp_path / "list.json"
        argv = [
            "create",
            "--issuer-did", issuer_did,
            "--out", str(out_file),
        ]

        exit_code = main(argv)
        assert exit_code == 2

    def test_create_missing_out(self, tmp_path, issuer_did, ed25519_private_key_pem):
        """Test create fails without output file."""
        argv = [
            "create",
            "--issuer-did", issuer_did,
            "--key", str(ed25519_private_key_pem),
        ]

        exit_code = main(argv)
        assert exit_code == 2

    def test_create_key_not_found(self, tmp_path, issuer_did):
        """Test create fails if key file doesn't exist."""
        out_file = tmp_path / "list.json"
        argv = [
            "create",
            "--issuer-did", issuer_did,
            "--key", "/nonexistent/key.pem",
            "--out", str(out_file),
        ]

        exit_code = main(argv)
        assert exit_code == 3

    def test_create_invalid_rekor_index(self, tmp_path, issuer_did, ed25519_private_key_pem):
        """Test create fails with invalid rekor_index."""
        out_file = tmp_path / "list.json"
        argv = [
            "create",
            "--issuer-did", issuer_did,
            "--key", str(ed25519_private_key_pem),
            "--rekor-index", "not-an-int",
            "--out", str(out_file),
        ]

        exit_code = main(argv)
        assert exit_code == 6


class TestVerifyCommand:
    """Test gtv-revoke verify."""

    def test_verify_valid_list(self, tmp_path, issuer_did, ed25519_private_key_pem, capsys):
        """Test verify with valid list."""
        list_file = tmp_path / "list.json"
        rl = build_revocation_list(
            issuer_did=issuer_did,
            envelope_ids=["env-1"],
            private_key_path=ed25519_private_key_pem,
        )
        list_file.write_text(rl.model_dump_json())

        argv = ["verify", str(list_file)]
        exit_code = main(argv)

        assert exit_code == 0
        captured = capsys.readouterr()
        assert "valid" in captured.out

    def test_verify_invalid_list(self, tmp_path, capsys):
        """Test verify with invalid list."""
        list_file = tmp_path / "bad_list.json"
        list_file.write_text('{"invalid": "data"}')

        argv = ["verify", str(list_file)]
        exit_code = main(argv)

        assert exit_code == 4

    def test_verify_tampered_signature(self, tmp_path, issuer_did, ed25519_private_key_pem, capsys):
        """Test verify detects tampered signature."""
        list_file = tmp_path / "list.json"
        rl = build_revocation_list(
            issuer_did=issuer_did,
            envelope_ids=["env-1"],
            private_key_path=ed25519_private_key_pem,
        )
        bad_rl = rl.model_copy(update={"signature": "byok-ed25519:invalid"})
        list_file.write_text(bad_rl.model_dump_json())

        argv = ["verify", str(list_file)]
        exit_code = main(argv)

        assert exit_code == 1
        captured = capsys.readouterr()
        assert "invalid" in captured.out

    def test_verify_file_not_found(self, capsys):
        """Test verify with missing file."""
        argv = ["verify", "/nonexistent/file.json"]
        exit_code = main(argv)

        assert exit_code == 3

    def test_verify_missing_file_arg(self, capsys):
        """Test verify without file argument."""
        argv = ["verify"]
        exit_code = main(argv)

        assert exit_code == 2


class TestCheckCommand:
    """Test gtv-revoke check."""

    def test_check_revoked_envelope(self, tmp_path, issuer_did, ed25519_private_key_pem, capsys):
        """Test check detects revoked envelope."""
        envelope = Envelope(
            envelope_id="revoked-env",
            verdict="VERIFIED",
            confidence=0.95,
            evidence=[],
            issuer_did="did:key:ztest",
            issued_at=datetime.now(tz=UTC),
            signature="byok-ed25519:fake",
            rekor_uuid="uuid",
            rekor_log_index=10,
            tsa_token="tsa",
            prov_graph="{}",
            anchor_proof=AnchorProof(
                rekor_inclusion_proof="proof",
                tsa_tsr_primary="tsr",
            ),
        )
        env_file = tmp_path / "envelope.json"
        env_file.write_text(envelope.model_dump_json())

        rl = build_revocation_list(
            issuer_did=issuer_did,
            envelope_ids=["revoked-env"],
            private_key_path=ed25519_private_key_pem,
        )
        list_file = tmp_path / "list.json"
        list_file.write_text(rl.model_dump_json())

        argv = [
            "check",
            "--envelope", str(env_file),
            "--list", str(list_file),
        ]
        exit_code = main(argv)

        assert exit_code == 1
        captured = capsys.readouterr()
        assert "revoked" in captured.out.lower()

    def test_check_not_revoked(self, tmp_path, issuer_did, ed25519_private_key_pem, capsys):
        """Test check detects not revoked envelope."""
        envelope = Envelope(
            envelope_id="safe-env",
            verdict="VERIFIED",
            confidence=0.95,
            evidence=[],
            issuer_did="did:key:ztest",
            issued_at=datetime.now(tz=UTC),
            signature="byok-ed25519:fake",
            rekor_uuid="uuid",
            rekor_log_index=10,
            tsa_token="tsa",
            prov_graph="{}",
            anchor_proof=AnchorProof(
                rekor_inclusion_proof="proof",
                tsa_tsr_primary="tsr",
            ),
        )
        env_file = tmp_path / "envelope.json"
        env_file.write_text(envelope.model_dump_json())

        rl = build_revocation_list(
            issuer_did=issuer_did,
            envelope_ids=["other-env"],
            private_key_path=ed25519_private_key_pem,
        )
        list_file = tmp_path / "list.json"
        list_file.write_text(rl.model_dump_json())

        argv = [
            "check",
            "--envelope", str(env_file),
            "--list", str(list_file),
        ]
        exit_code = main(argv)

        assert exit_code == 0
        captured = capsys.readouterr()
        assert "not_revoked" in captured.out

    def test_check_missing_envelope(self, tmp_path, issuer_did, ed25519_private_key_pem):
        """Test check fails without envelope."""
        rl = build_revocation_list(
            issuer_did=issuer_did,
            private_key_path=ed25519_private_key_pem,
        )
        list_file = tmp_path / "list.json"
        list_file.write_text(rl.model_dump_json())

        argv = [
            "check",
            "--list", str(list_file),
        ]
        exit_code = main(argv)

        assert exit_code == 2

    def test_check_missing_list(self, tmp_path, issuer_did, ed25519_private_key_pem):
        """Test check fails without list."""
        envelope = Envelope(
            envelope_id="env",
            verdict="VERIFIED",
            confidence=0.95,
            evidence=[],
            issuer_did="did:key:ztest",
            issued_at=datetime.now(tz=UTC),
            signature="byok-ed25519:fake",
            rekor_uuid="uuid",
            rekor_log_index=10,
            tsa_token="tsa",
            prov_graph="{}",
            anchor_proof=AnchorProof(
                rekor_inclusion_proof="proof",
                tsa_tsr_primary="tsr",
            ),
        )
        env_file = tmp_path / "envelope.json"
        env_file.write_text(envelope.model_dump_json())

        argv = [
            "check",
            "--envelope", str(env_file),
        ]
        exit_code = main(argv)

        assert exit_code == 2

    def test_check_envelope_file_not_found(self, tmp_path, issuer_did, ed25519_private_key_pem):
        """Test check with missing envelope file."""
        rl = build_revocation_list(
            issuer_did=issuer_did,
            private_key_path=ed25519_private_key_pem,
        )
        list_file = tmp_path / "list.json"
        list_file.write_text(rl.model_dump_json())

        argv = [
            "check",
            "--envelope", "/nonexistent/env.json",
            "--list", str(list_file),
        ]
        exit_code = main(argv)

        assert exit_code == 3

    def test_check_list_file_not_found(self, tmp_path):
        """Test check with missing list file."""
        envelope = Envelope(
            envelope_id="env",
            verdict="VERIFIED",
            confidence=0.95,
            evidence=[],
            issuer_did="did:key:ztest",
            issued_at=datetime.now(tz=UTC),
            signature="byok-ed25519:fake",
            rekor_uuid="uuid",
            rekor_log_index=10,
            tsa_token="tsa",
            prov_graph="{}",
            anchor_proof=AnchorProof(
                rekor_inclusion_proof="proof",
                tsa_tsr_primary="tsr",
            ),
        )
        env_file = tmp_path / "envelope.json"
        env_file.write_text(envelope.model_dump_json())

        argv = [
            "check",
            "--envelope", str(env_file),
            "--list", "/nonexistent/list.json",
        ]
        exit_code = main(argv)

        assert exit_code == 3

    def test_check_multiple_lists(self, tmp_path, issuer_did, ed25519_private_key_pem, capsys):
        """Test check with multiple lists."""
        envelope = Envelope(
            envelope_id="env",
            verdict="VERIFIED",
            confidence=0.95,
            evidence=[],
            issuer_did="did:key:ztest",
            issued_at=datetime.now(tz=UTC),
            signature="byok-ed25519:fake",
            rekor_uuid="uuid",
            rekor_log_index=10,
            tsa_token="tsa",
            prov_graph="{}",
            anchor_proof=AnchorProof(
                rekor_inclusion_proof="proof",
                tsa_tsr_primary="tsr",
            ),
        )
        env_file = tmp_path / "envelope.json"
        env_file.write_text(envelope.model_dump_json())

        # First list doesn't revoke it
        rl1 = build_revocation_list(
            issuer_did=issuer_did,
            envelope_ids=["other-env"],
            private_key_path=ed25519_private_key_pem,
        )
        list1_file = tmp_path / "list1.json"
        list1_file.write_text(rl1.model_dump_json())

        # Second list does revoke it
        rl2 = build_revocation_list(
            issuer_did=issuer_did,
            envelope_ids=["env"],
            private_key_path=ed25519_private_key_pem,
        )
        list2_file = tmp_path / "list2.json"
        list2_file.write_text(rl2.model_dump_json())

        argv = [
            "check",
            "--envelope", str(env_file),
            "--list", str(list1_file),
            "--list", str(list2_file),
        ]
        exit_code = main(argv)

        assert exit_code == 1
        captured = capsys.readouterr()
        assert "revoked" in captured.out.lower()


class TestMainDispatch:
    """Test main command dispatching."""

    def test_invalid_command(self):
        """Test invalid command."""
        argv = ["invalid_command"]
        exit_code = main(argv)
        assert exit_code == 2

    def test_no_command(self):
        """Test with no command."""
        argv = []
        exit_code = main(argv)
        assert exit_code == 2
