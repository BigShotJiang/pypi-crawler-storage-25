"""Tests for the gtv-onboard CLI (gtv.cli.onboard).

Covers all three subcommands:
1. init — generates config files with correct permissions
2. doctor — checks environment and returns correct exit codes
3. sample — runs a sample verify
"""

from __future__ import annotations

import io
import tomllib
from contextlib import redirect_stderr, redirect_stdout
from pathlib import Path
from unittest.mock import patch

from gtv.cli.onboard import cmd_doctor, cmd_init, cmd_sample, main


def _run(argv: list[str]) -> tuple[int, str, str]:
    """Run the CLI entry point, capture stdout/stderr."""
    out, err = io.StringIO(), io.StringIO()
    with redirect_stdout(out), redirect_stderr(err):
        try:
            rc = main(argv)
        except SystemExit as e:
            rc = e.code if isinstance(e.code, int) else (0 if e.code is None else 1)
    return rc, out.getvalue(), err.getvalue()


# ---------------------------------------------------------------------------
# Test: init subcommand
# ---------------------------------------------------------------------------


def test_init_interactive_non_interactive_requires_tenant_id(tmp_path: Path) -> None:
    """Test that --non-interactive without --tenant-id fails."""
    with patch("pathlib.Path.cwd", return_value=tmp_path):
        rc = cmd_init(
            tenant_id=None,
            adapters=None,
            force=False,
            non_interactive=True,
        )
    assert rc == 1


def test_init_non_interactive_generates_files(tmp_path: Path) -> None:
    """Test --non-interactive generates config files with correct content."""
    with patch("pathlib.Path.cwd", return_value=tmp_path), patch(
        "pathlib.Path.home", return_value=tmp_path / "home"
    ):
        rc = cmd_init(
            tenant_id="test-tenant",
            adapters=["did:web:arxiv.org", "did:web:crossref.org"],
            force=False,
            non_interactive=True,
        )

    assert rc == 0

    # Check gtv.toml exists and has correct content
    config_path = tmp_path / "gtv.toml"
    assert config_path.exists()

    with open(config_path, "rb") as f:
        config = tomllib.load(f)

    assert config["tenant"]["id"] == "test-tenant"
    assert "did:web:arxiv.org" in config["adapters"]["enabled"]
    assert "did:web:crossref.org" in config["adapters"]["enabled"]

    # Check .env exists
    env_path = tmp_path / ".env"
    assert env_path.exists()
    env_content = env_path.read_text()
    assert "GTV_TENANT_ID=test-tenant" in env_content

    # Check keypair generated with correct permissions
    private_key_path = tmp_path / "home" / ".gtv" / "keys" / "operator.pem"
    public_key_path = tmp_path / "home" / ".gtv" / "keys" / "operator.pub"

    assert private_key_path.exists()
    assert public_key_path.exists()

    # Check private key has 0600 permissions
    private_perms = oct(private_key_path.stat().st_mode)[-3:]
    assert private_perms == "600"


def test_init_refuses_overwrite_without_force(tmp_path: Path) -> None:
    """Test that init refuses to overwrite existing config without --force."""
    # Create an existing config file
    config_path = tmp_path / "gtv.toml"
    config_path.write_text("[tenant]\nid = 'existing'\n")

    with patch("pathlib.Path.cwd", return_value=tmp_path), patch(
        "pathlib.Path.home", return_value=tmp_path / "home"
    ):
        rc = cmd_init(
            tenant_id="new-tenant",
            adapters=["did:web:arxiv.org"],
            force=False,
            non_interactive=True,
        )

    assert rc == 1

    # Config should still have old content
    with open(config_path, "rb") as f:
        config = tomllib.load(f)
    assert config["tenant"]["id"] == "existing"


def test_init_force_overwrites_existing(tmp_path: Path) -> None:
    """Test that --force overwrites existing config."""
    # Create an existing config file
    config_path = tmp_path / "gtv.toml"
    config_path.write_text("[tenant]\nid = 'existing'\n")

    with patch("pathlib.Path.cwd", return_value=tmp_path), patch(
        "pathlib.Path.home", return_value=tmp_path / "home"
    ):
        rc = cmd_init(
            tenant_id="new-tenant",
            adapters=["did:web:arxiv.org"],
            force=True,
            non_interactive=True,
        )

    assert rc == 0

    # Config should have new content
    with open(config_path, "rb") as f:
        config = tomllib.load(f)
    assert config["tenant"]["id"] == "new-tenant"


def test_init_empty_adapters_list(tmp_path: Path) -> None:
    """Test init with no adapters specified."""
    with patch("pathlib.Path.cwd", return_value=tmp_path), patch(
        "pathlib.Path.home", return_value=tmp_path / "home"
    ):
        rc = cmd_init(
            tenant_id="test-tenant",
            adapters=[],
            force=False,
            non_interactive=True,
        )

    assert rc == 0

    config_path = tmp_path / "gtv.toml"
    with open(config_path, "rb") as f:
        config = tomllib.load(f)

    assert config["adapters"]["enabled"] == []


def test_init_via_cli_non_interactive(tmp_path: Path) -> None:
    """Test init via CLI with --non-interactive."""
    with patch("pathlib.Path.cwd", return_value=tmp_path), patch(
        "pathlib.Path.home", return_value=tmp_path / "home"
    ):
        rc, out, _err = _run(
            [
                "init",
                "--non-interactive",
                "--tenant-id",
                "cli-test",
                "--adapters",
                "did:web:arxiv.org",
            ]
        )

    assert rc == 0
    assert "SUCCESS" in out
    config_path = tmp_path / "gtv.toml"
    assert config_path.exists()


def test_init_help_text(tmp_path: Path) -> None:
    """Test that help text includes init subcommand."""
    with patch("pathlib.Path.cwd", return_value=tmp_path):
        rc, out, _err = _run(["--help"])
    assert rc == 0
    assert "init" in out


# ---------------------------------------------------------------------------
# Test: doctor subcommand
# ---------------------------------------------------------------------------


def test_doctor_all_checks_pass(tmp_path: Path) -> None:
    """Test doctor returns 0 when all checks pass."""
    # Create a valid config
    config_path = tmp_path / "gtv.toml"
    config_path.write_text(
        "[adapters]\nenabled = ['did:web:arxiv.org']\n"
    )

    # Create a valid key
    keys_dir = tmp_path / "home" / ".gtv" / "keys"
    keys_dir.mkdir(parents=True, exist_ok=True)
    key_path = keys_dir / "operator.pem"
    key_path.write_text("fake key")
    key_path.chmod(0o600)

    with patch("pathlib.Path.cwd", return_value=tmp_path), patch(
        "pathlib.Path.home", return_value=tmp_path / "home"
    ), patch("sys.version_info", (3, 12, 0)):
        rc = cmd_doctor(net=False)

    assert rc == 0


def test_doctor_missing_config(tmp_path: Path) -> None:
    """Test doctor returns 1 when config is missing."""
    # Create a valid key
    keys_dir = tmp_path / "home" / ".gtv" / "keys"
    keys_dir.mkdir(parents=True, exist_ok=True)
    key_path = keys_dir / "operator.pem"
    key_path.write_text("fake key")

    with patch("pathlib.Path.cwd", return_value=tmp_path), patch(
        "pathlib.Path.home", return_value=tmp_path / "home"
    ), patch("sys.version_info", (3, 12, 0)):
        rc = cmd_doctor(net=False)

    assert rc == 1


def test_doctor_missing_key(tmp_path: Path) -> None:
    """Test doctor returns 1 when signing key is missing."""
    # Create a valid config
    config_path = tmp_path / "gtv.toml"
    config_path.write_text(
        "[adapters]\nenabled = ['did:web:arxiv.org']\n"
    )

    with patch("pathlib.Path.cwd", return_value=tmp_path), patch(
        "pathlib.Path.home", return_value=tmp_path / "home"
    ), patch("sys.version_info", (3, 12, 0)):
        rc = cmd_doctor(net=False)

    assert rc == 1


def test_doctor_no_adapters_enabled(tmp_path: Path) -> None:
    """Test doctor returns 1 when no adapters are enabled."""
    # Create a config with no adapters
    config_path = tmp_path / "gtv.toml"
    config_path.write_text("[adapters]\nenabled = []\n")

    # Create a valid key
    keys_dir = tmp_path / "home" / ".gtv" / "keys"
    keys_dir.mkdir(parents=True, exist_ok=True)
    key_path = keys_dir / "operator.pem"
    key_path.write_text("fake key")

    with patch("pathlib.Path.cwd", return_value=tmp_path), patch(
        "pathlib.Path.home", return_value=tmp_path / "home"
    ), patch("sys.version_info", (3, 12, 0)):
        rc = cmd_doctor(net=False)

    assert rc == 1


def test_doctor_via_cli(tmp_path: Path) -> None:
    """Test doctor via CLI."""
    # Create a valid config
    config_path = tmp_path / "gtv.toml"
    config_path.write_text(
        "[adapters]\nenabled = ['did:web:arxiv.org']\n"
    )

    # Create a valid key
    keys_dir = tmp_path / "home" / ".gtv" / "keys"
    keys_dir.mkdir(parents=True, exist_ok=True)
    key_path = keys_dir / "operator.pem"
    key_path.write_text("fake key")

    with patch("pathlib.Path.cwd", return_value=tmp_path), patch(
        "pathlib.Path.home", return_value=tmp_path / "home"
    ), patch("sys.version_info", (3, 12, 0)):
        rc, out, _err = _run(["doctor"])

    assert rc == 0
    assert "✓" in out or "All checks passed" in out


def test_doctor_help_text() -> None:
    """Test that help text includes doctor subcommand."""
    rc, out, _err = _run(["--help"])
    assert rc == 0
    assert "doctor" in out


# ---------------------------------------------------------------------------
# Test: sample subcommand
# ---------------------------------------------------------------------------


def test_sample_runs_successfully() -> None:
    """Test sample verify runs without error."""
    rc = cmd_sample()
    assert rc == 0


def test_sample_via_cli() -> None:
    """Test sample via CLI."""
    rc, _out, _err = _run(["sample"])
    assert rc == 0


def test_sample_help_text() -> None:
    """Test that help text includes sample subcommand."""
    rc, out, _err = _run(["--help"])
    assert rc == 0
    assert "sample" in out


# ---------------------------------------------------------------------------
# Test: CLI entry point and error handling
# ---------------------------------------------------------------------------


def test_cli_bad_subcommand() -> None:
    """Test CLI returns 2 for bad subcommand."""
    rc, _out, _err = _run(["invalid-subcommand"])
    assert rc == 2


def test_cli_no_args_shows_help() -> None:
    """Test CLI with no args shows help."""
    rc, _out, _err = _run([])
    assert rc == 2


def test_cli_help_shows_all_subcommands() -> None:
    """Test --help shows all three subcommands."""
    rc, out, _err = _run(["--help"])
    assert rc == 0
    assert "init" in out
    assert "doctor" in out
    assert "sample" in out
