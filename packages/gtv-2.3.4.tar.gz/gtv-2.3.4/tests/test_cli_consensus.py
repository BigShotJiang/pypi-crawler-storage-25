"""Tests for gtv-verify --consensus CLI."""
from __future__ import annotations

import json
import tempfile
from datetime import UTC, datetime
from pathlib import Path

from gtv.cli.verify import main
from gtv.models import AnchorProof, Envelope, Evidence, Stance, Verdict


def _make_envelope(
    verdict: Verdict,
    issuer_did: str,
    claim_id: str = "test-claim-id",
) -> Envelope:
    """Helper to construct a minimal test Envelope."""
    return Envelope(
        verdict=verdict,
        confidence=0.9,
        evidence=[
            Evidence(
                claim_id=claim_id,
                source_did="did:source",
                source_version="1.0",
                stance=Stance.SUPPORTS,
                excerpt="test excerpt",
                url="https://example.com",
                retrieved_at=datetime.now(tz=UTC),
                raw_hash="0" * 64,
            )
        ],
        rationale="test",
        issuer_did=issuer_did,
        signature="stub://sig",
        rekor_uuid="test-uuid",
        rekor_log_index=0,
        tsa_token="stub://tsa",
        prov_graph="{}",
        anchor_proof=AnchorProof(
            rekor_inclusion_proof="stub://proof",
            tsa_tsr_primary="stub://tsa",
        ),
    )


class TestConsensusMode:
    """Tests for gtv-verify --consensus mode."""

    def test_consensus_no_args_exit_2(self, capsys) -> None:
        """No envelope paths after --consensus should exit 2."""
        result = main(["--consensus"])
        assert result == 2
        captured = capsys.readouterr()
        assert "usage:" in captured.err

    def test_consensus_empty_list_exit_2(self, capsys) -> None:
        """Empty list of envelopes should exit 2."""
        result = main(["--consensus", "--some-flag"])
        assert result == 2

    def test_consensus_single_envelope_verified(self, capsys) -> None:
        """Single VERIFIED envelope → exit 0 + JSON output."""
        with tempfile.TemporaryDirectory() as tmpdir:
            env = _make_envelope(Verdict.VERIFIED, "did:test:issuer1")
            env_path = Path(tmpdir) / "env1.json"
            env_path.write_text(env.model_dump_json())

            result = main(["--consensus", str(env_path)])
            assert result == 0

            captured = capsys.readouterr()
            output = json.loads(captured.out)
            assert output["verdict"] == "VERIFIED"
            assert output["confidence"] == 1.0
            assert len(output["tally"]) == 1
            # Unknown DIDs should include the issuer since it's not in the default registry
            assert "did:test:issuer1" in output["unknown_dids"]

    def test_consensus_two_verified_envelopes(self, capsys) -> None:
        """Two VERIFIED envelopes → VERIFIED verdict."""
        with tempfile.TemporaryDirectory() as tmpdir:
            env1 = _make_envelope(Verdict.VERIFIED, "did:test:issuer1")
            env2 = _make_envelope(Verdict.VERIFIED, "did:test:issuer2")

            path1 = Path(tmpdir) / "env1.json"
            path2 = Path(tmpdir) / "env2.json"
            path1.write_text(env1.model_dump_json())
            path2.write_text(env2.model_dump_json())

            result = main(["--consensus", str(path1), str(path2)])
            assert result == 0

            captured = capsys.readouterr()
            output = json.loads(captured.out)
            assert output["verdict"] == "VERIFIED"
            assert output["confidence"] >= 0.0  # May be lower if they're unknown DIDs

    def test_consensus_mismatched_claim_ids_exit_1(self, capsys) -> None:
        """Envelopes with different claim_ids should exit 1."""
        with tempfile.TemporaryDirectory() as tmpdir:
            env1 = _make_envelope(Verdict.VERIFIED, "did:test:issuer1", claim_id="claim-1")
            env2 = _make_envelope(Verdict.VERIFIED, "did:test:issuer2", claim_id="claim-2")

            path1 = Path(tmpdir) / "env1.json"
            path2 = Path(tmpdir) / "env2.json"
            path1.write_text(env1.model_dump_json())
            path2.write_text(env2.model_dump_json())

            result = main(["--consensus", str(path1), str(path2)])
            assert result == 1

            captured = capsys.readouterr()
            assert "claim" in captured.err.lower()

    def test_consensus_invalid_json_exit_5(self, capsys) -> None:
        """Invalid JSON file should exit 5."""
        with tempfile.TemporaryDirectory() as tmpdir:
            bad_path = Path(tmpdir) / "bad.json"
            bad_path.write_text("{invalid json")

            result = main(["--consensus", str(bad_path)])
            assert result == 5

            captured = capsys.readouterr()
            assert "ERROR" in captured.err

    def test_consensus_missing_file_exit_5(self, capsys) -> None:
        """Missing file should exit 5."""
        result = main(["--consensus", "/nonexistent/file.json"])
        assert result == 5

    def test_consensus_schema_error_exit_5(self, capsys) -> None:
        """Schema validation error should exit 5."""
        with tempfile.TemporaryDirectory() as tmpdir:
            bad_path = Path(tmpdir) / "bad.json"
            bad_path.write_text('{"verdict": "INVALID_VERDICT"}')

            result = main(["--consensus", str(bad_path)])
            assert result == 5

    def test_consensus_unknown_dids_included(self, capsys) -> None:
        """Unknown DIDs should appear in unknown_dids field."""
        with tempfile.TemporaryDirectory() as tmpdir:
            env = _make_envelope(Verdict.VERIFIED, "did:unknown:issuer")
            env_path = Path(tmpdir) / "env1.json"
            env_path.write_text(env.model_dump_json())

            result = main(["--consensus", str(env_path)])
            assert result == 0

            captured = capsys.readouterr()
            output = json.loads(captured.out)
            assert "did:unknown:issuer" in output["unknown_dids"]

    def test_consensus_contested_verdict(self, capsys) -> None:
        """VERIFIED + UNVERIFIED should produce CONTESTED."""
        with tempfile.TemporaryDirectory() as tmpdir:
            env1 = _make_envelope(Verdict.VERIFIED, "did:test:issuer1")
            env2 = _make_envelope(Verdict.UNVERIFIED, "did:test:issuer2")

            path1 = Path(tmpdir) / "env1.json"
            path2 = Path(tmpdir) / "env2.json"
            path1.write_text(env1.model_dump_json())
            path2.write_text(env2.model_dump_json())

            result = main(["--consensus", str(path1), str(path2)])
            assert result == 0

            captured = capsys.readouterr()
            output = json.loads(captured.out)
            assert output["verdict"] == "CONTESTED"
