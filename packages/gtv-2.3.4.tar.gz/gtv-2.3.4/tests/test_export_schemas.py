"""Tests for the public schema exporter.

This file pulls double-duty: it validates the exporter itself AND acts
as the CI drift guard — if someone changes a public pydantic model or
FastAPI route without running ``gtv-export-schemas write``, the
drift-guard test will fail.
"""
from __future__ import annotations

import dataclasses
import json
from pathlib import Path

import pytest

from gtv.cli.export_schemas import (
    Artifact,
    build_artifacts,
    check_artifacts,
    main,
    write_artifacts,
)

REPO_ROOT = Path(__file__).resolve().parent.parent


def test_build_artifacts_includes_openapi_and_every_public_model() -> None:
    """The artifact list must contain OpenAPI + one schema per public model."""
    artifacts = build_artifacts()

    paths = [a.relative_path.as_posix() for a in artifacts]
    assert "spec/openapi.gen.json" in paths

    # A small, load-bearing set — if any of these disappear, the public
    # contract has been quietly narrowed and the test should fail loudly.
    required = {
        "spec/schemas/Envelope.gen.json",
        "spec/schemas/Evidence.gen.json",
        "spec/schemas/VerifyClaimRequest.gen.json",
        "spec/schemas/RetrieveFactsRequest.gen.json",
        "spec/schemas/RetrieveFactsEnvelope.gen.json",
        "spec/schemas/AnchorProof.gen.json",
    }
    assert required.issubset(set(paths))


def test_openapi_document_has_core_endpoints() -> None:
    """OpenAPI must advertise the three MCP endpoints plus /health."""
    artifacts = build_artifacts()
    openapi = next(a for a in artifacts if a.relative_path.name == "openapi.gen.json")
    paths = openapi.content.get("paths", {})
    assert "/tools/verify_claim" in paths
    assert "/tools/retrieve_facts" in paths
    assert "/consensus" in paths
    assert "/health" in paths


def test_envelope_schema_matches_model_contract() -> None:
    """The exported Envelope schema must include all required fields."""
    artifacts = build_artifacts()
    envelope = next(a for a in artifacts if a.relative_path.name == "Envelope.gen.json")

    required = set(envelope.content.get("required", []))
    properties = set(envelope.content.get("properties", {}).keys())

    # Fields WITHOUT a model-level default must be listed as required in
    # the JSON schema. These are the externally-guaranteed contract: if
    # one disappears, that's a breaking change.
    for field in (
        "verdict",
        "confidence",
        "evidence",
        "issuer_did",
        "signature",
        "rekor_uuid",
        "rekor_log_index",
        "tsa_token",
        "prov_graph",
        "anchor_proof",
    ):
        assert field in required, f"Envelope lost required field: {field}"

    # Fields WITH defaults must still exist in the schema so clients can
    # type-check against them, even though the schema marks them optional.
    for field in ("envelope_id", "issued_at", "rationale"):
        assert field in properties, f"Envelope lost optional field: {field}"


def test_write_then_check_is_clean(tmp_path: Path) -> None:
    """Round-trip: writing artifacts then checking must report zero drift."""
    artifacts = build_artifacts()
    write_artifacts(tmp_path, artifacts)
    drifted = check_artifacts(tmp_path, artifacts)
    assert drifted == []


def test_check_reports_drift_when_file_edited(tmp_path: Path) -> None:
    """Hand-edit an exported file; check_artifacts must flag it."""
    artifacts = build_artifacts()
    write_artifacts(tmp_path, artifacts)

    victim = tmp_path / "spec" / "schemas" / "Envelope.gen.json"
    data = json.loads(victim.read_text())
    data["__injected_drift__"] = True
    victim.write_text(json.dumps(data, sort_keys=True, indent=2) + "\n")

    drifted = check_artifacts(tmp_path, artifacts)
    assert victim in drifted


def test_check_reports_drift_when_file_missing(tmp_path: Path) -> None:
    """Deleting an exported file must also count as drift."""
    artifacts = build_artifacts()
    write_artifacts(tmp_path, artifacts)

    victim = tmp_path / "spec" / "schemas" / "Evidence.gen.json"
    victim.unlink()

    drifted = check_artifacts(tmp_path, artifacts)
    assert victim in drifted


def test_canonical_json_is_deterministic() -> None:
    """Running build_artifacts twice must yield byte-identical content."""
    a = build_artifacts()
    b = build_artifacts()

    for art_a, art_b in zip(a, b, strict=True):
        assert art_a.relative_path == art_b.relative_path
        assert json.dumps(art_a.content, sort_keys=True) == json.dumps(
            art_b.content, sort_keys=True
        )


def test_cli_write_then_check(tmp_path: Path) -> None:
    """Exercise the CLI end-to-end: write to tmp, then check reports OK."""
    rc_write = main(["write", "--root", str(tmp_path)])
    assert rc_write == 0
    rc_check = main(["check", "--root", str(tmp_path)])
    assert rc_check == 0


def test_cli_check_detects_drift(tmp_path: Path) -> None:
    """Write; corrupt one file; CLI check must exit non-zero."""
    assert main(["write", "--root", str(tmp_path)]) == 0
    victim = tmp_path / "spec" / "openapi.gen.json"
    victim.write_text("{}\n")
    assert main(["check", "--root", str(tmp_path)]) == 1


def test_cli_check_missing_tree_exits_nonzero(tmp_path: Path) -> None:
    """Running check against an empty dir must report drift."""
    assert main(["check", "--root", str(tmp_path)]) == 1


# --- Drift guard --------------------------------------------------------
#
# This is the test that anchors the public contract to the repo. Any
# change to a public pydantic model or a FastAPI endpoint without a
# corresponding `gtv-export-schemas write` will fail this test.


def test_exported_artifacts_in_sync_with_repo() -> None:
    """The committed spec/ files must match what the exporter would produce.

    If this fails, run: ``gtv-export-schemas write``.
    """
    artifacts = build_artifacts()

    # Skip cleanly if artifacts haven't been generated yet — that's
    # expected on first-run and the test for a clean tree will cover
    # the round-trip. Only fail on genuine drift.
    openapi_path = REPO_ROOT / "spec" / "openapi.gen.json"
    if not openapi_path.exists():
        pytest.skip("spec/openapi.gen.json not generated yet; run gtv-export-schemas write")

    drifted = check_artifacts(REPO_ROOT, artifacts)
    assert drifted == [], (
        "Schema drift detected. Run `gtv-export-schemas write` and commit the diff. "
        f"Drifted files: {[p.as_posix() for p in drifted]}"
    )


def test_artifact_dataclass_immutability() -> None:
    """Artifact must be hashable/frozen so callers can dedup safely."""
    art = Artifact(relative_path=Path("x.json"), content={"a": 1})
    with pytest.raises(dataclasses.FrozenInstanceError):
        art.content = {"a": 2}  # type: ignore[misc]
