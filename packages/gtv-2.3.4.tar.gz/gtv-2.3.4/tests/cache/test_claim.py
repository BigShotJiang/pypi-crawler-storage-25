"""Tests for the per-claim cache layer."""
from __future__ import annotations

import time

from gtv.cache.claim import ClaimCache, ParsedClaim
from gtv.models import Claim, Domain


class TestClaimCacheBasic:
    """Test basic get_or_parse behavior."""

    def test_first_call_parses_and_caches(self) -> None:
        """First call to get_or_parse should parse and cache the result."""
        cache = ClaimCache()
        claim = Claim(claim_id="c1", text="Hello World", domain=Domain.GENERAL)

        result = cache.get_or_parse(claim)

        assert isinstance(result, ParsedClaim)
        assert result.claim_id == "c1"
        assert result.normalized_text == "hello world"
        assert result.tokens == ("hello", "world")
        assert result.domain == "general"

    def test_second_call_hits_cache(self) -> None:
        """Second call with same claim should be a cache hit."""
        cache = ClaimCache()
        claim = Claim(claim_id="c1", text="Hello World", domain=Domain.GENERAL)

        result1 = cache.get_or_parse(claim)
        result2 = cache.get_or_parse(claim)

        assert result1 is result2
        assert cache.stats()["hits"] == 1
        assert cache.stats()["misses"] == 1

    def test_same_text_different_claim_id_hits_cache(self) -> None:
        """Two claims with same text but different claim_id should share cache."""
        cache = ClaimCache()
        claim1 = Claim(claim_id="c1", text="Hello World", domain=Domain.GENERAL)
        claim2 = Claim(claim_id="c2", text="Hello World", domain=Domain.GENERAL)

        result1 = cache.get_or_parse(claim1)
        result2 = cache.get_or_parse(claim2)

        # Same cache entry (because text and domain match).
        assert result1 is result2
        # But the result retains the claim_id from the first call.
        assert result1.claim_id == "c1"
        assert cache.stats()["misses"] == 1
        assert cache.stats()["hits"] == 1

    def test_different_text_misses_cache(self) -> None:
        """Different claim text should be a cache miss."""
        cache = ClaimCache()
        claim1 = Claim(claim_id="c1", text="Hello World", domain=Domain.GENERAL)
        claim2 = Claim(claim_id="c2", text="Goodbye World", domain=Domain.GENERAL)

        result1 = cache.get_or_parse(claim1)
        result2 = cache.get_or_parse(claim2)

        assert result1 is not result2
        assert cache.stats()["misses"] == 2
        assert cache.stats()["hits"] == 0

    def test_different_domain_misses_cache(self) -> None:
        """Same text but different domain should be a cache miss."""
        cache = ClaimCache()
        claim1 = Claim(claim_id="c1", text="Hello World", domain=Domain.GENERAL)
        claim2 = Claim(claim_id="c2", text="Hello World", domain=Domain.PHYSICS)

        result1 = cache.get_or_parse(claim1)
        result2 = cache.get_or_parse(claim2)

        assert result1 is not result2
        assert cache.stats()["misses"] == 2
        assert cache.stats()["hits"] == 0


class TestClaimCacheTTL:
    """Test TTL expiry behavior."""

    def test_ttl_expiry_causes_reparse(self) -> None:
        """After TTL expiry, cache.get_or_parse should re-parse."""
        cache = ClaimCache(ttl_s=0.1)  # 100ms TTL.
        claim = Claim(claim_id="c1", text="Test", domain=Domain.GENERAL)

        result1 = cache.get_or_parse(claim)
        time.sleep(0.15)  # Wait for TTL to expire.
        result2 = cache.get_or_parse(claim)

        # Different objects (re-parsed).
        assert result1 is not result2
        assert result1.normalized_text == result2.normalized_text
        # One hit (from before expiry), one miss, one hit (after reparse).
        assert cache.stats()["misses"] == 2

    def test_ttl_zero_disables_ttl(self) -> None:
        """TTL of 0 should disable TTL checking."""
        cache = ClaimCache(ttl_s=0)
        claim = Claim(claim_id="c1", text="Test", domain=Domain.GENERAL)

        result1 = cache.get_or_parse(claim)
        time.sleep(0.1)
        result2 = cache.get_or_parse(claim)

        assert result1 is result2
        assert cache.stats()["hits"] == 1


class TestClaimCacheLRU:
    """Test LRU eviction."""

    def test_lru_eviction_at_max_entries(self) -> None:
        """Exceeding max_entries should evict the oldest entry."""
        cache = ClaimCache(max_entries=3)

        claims = [
            Claim(claim_id=f"c{i}", text=f"Text{i}", domain=Domain.GENERAL)
            for i in range(5)
        ]

        for claim in claims:
            cache.get_or_parse(claim)

        # Cache should only have 3 entries; first 2 were evicted.
        assert cache.stats()["entries"] == 3
        assert cache.stats()["evictions"] == 2


class TestClaimCacheIdentifiers:
    """Test identifier extraction."""

    def test_extract_cve(self) -> None:
        """Should extract CVE identifiers (uppercase)."""
        cache = ClaimCache()
        claim = Claim(
            claim_id="c1",
            text="The vulnerability CVE-2021-1234 was patched.",
            domain=Domain.GENERAL,
        )

        result = cache.get_or_parse(claim)

        assert "CVE-2021-1234" in result.identifiers["cve"]

    def test_extract_doi(self) -> None:
        """Should extract DOI identifiers."""
        cache = ClaimCache()
        claim = Claim(
            claim_id="c1",
            text="See paper at 10.1234/example.doi for details.",
            domain=Domain.GENERAL,
        )

        result = cache.get_or_parse(claim)

        assert "10.1234/example.doi" in result.identifiers["doi"]

    def test_extract_arxiv(self) -> None:
        """Should extract arXiv identifiers."""
        cache = ClaimCache()
        claim = Claim(
            claim_id="c1",
            text="Check paper 2301.12345 or 2301.12345v2 on arXiv.",
            domain=Domain.GENERAL,
        )

        result = cache.get_or_parse(claim)

        assert "2301.12345" in result.identifiers["arxiv"]
        assert "2301.12345v2" in result.identifiers["arxiv"]

    def test_extract_pmid(self) -> None:
        """Should extract PMID identifiers from both label and URL."""
        cache = ClaimCache()
        claim = Claim(
            claim_id="c1",
            text=(
                "Study PMID: 12345678 and also "
                "https://pubmed.ncbi.nlm.nih.gov/87654321"
            ),
            domain=Domain.GENERAL,
        )

        result = cache.get_or_parse(claim)

        assert "12345678" in result.identifiers["pmid"]
        assert "87654321" in result.identifiers["pmid"]

    def test_extract_multiple_identifiers(self) -> None:
        """Should extract all identifier types from the same text."""
        cache = ClaimCache()
        claim = Claim(
            claim_id="c1",
            text=(
                "CVE-2023-9999 was found in the arXiv preprint 2401.54321 "
                "with DOI 10.9876/test and PMID 11111111."
            ),
            domain=Domain.GENERAL,
        )

        result = cache.get_or_parse(claim)

        assert len(result.identifiers["cve"]) >= 1
        assert len(result.identifiers["arxiv"]) >= 1
        assert len(result.identifiers["doi"]) >= 1
        assert len(result.identifiers["pmid"]) >= 1


class TestClaimCacheStats:
    """Test statistics tracking."""

    def test_stats_increments_on_hit(self) -> None:
        """stats() should show increment on cache hit."""
        cache = ClaimCache()
        claim = Claim(claim_id="c1", text="Test", domain=Domain.GENERAL)

        cache.get_or_parse(claim)
        cache.get_or_parse(claim)

        stats = cache.stats()
        assert stats["hits"] == 1
        assert stats["misses"] == 1
        assert stats["entries"] == 1
        assert stats["evictions"] == 0

    def test_stats_increments_on_eviction(self) -> None:
        """stats() should show increment on eviction."""
        cache = ClaimCache(max_entries=1)
        claim1 = Claim(claim_id="c1", text="Text1", domain=Domain.GENERAL)
        claim2 = Claim(claim_id="c2", text="Text2", domain=Domain.GENERAL)

        cache.get_or_parse(claim1)
        cache.get_or_parse(claim2)

        stats = cache.stats()
        assert stats["evictions"] == 1
        assert stats["entries"] == 1


class TestClaimCacheClear:
    """Test clear operation."""

    def test_clear_resets_cache_and_stats(self) -> None:
        """clear() should reset cache and all statistics."""
        cache = ClaimCache()
        claim = Claim(claim_id="c1", text="Test", domain=Domain.GENERAL)

        cache.get_or_parse(claim)
        cache.get_or_parse(claim)
        assert cache.stats()["entries"] == 1
        assert cache.stats()["hits"] == 1

        cache.clear()

        assert cache.stats()["entries"] == 0
        assert cache.stats()["hits"] == 0
        assert cache.stats()["misses"] == 0
        assert cache.stats()["evictions"] == 0

        # Next call should be a miss (cache was cleared).
        cache.get_or_parse(claim)
        assert cache.stats()["misses"] == 1
        assert cache.stats()["hits"] == 0


class TestClaimCacheNormalization:
    """Test text normalization."""

    def test_normalization_whitespace_collapse(self) -> None:
        """Whitespace should collapse to single space."""
        cache = ClaimCache()
        claim = Claim(
            claim_id="c1", text="Hello   \n\t  World", domain=Domain.GENERAL
        )

        result = cache.get_or_parse(claim)

        assert result.normalized_text == "hello world"

    def test_normalization_punctuation_strip(self) -> None:
        """Leading/trailing punctuation should be stripped."""
        cache = ClaimCache()
        claim = Claim(
            claim_id="c1",
            text="'\"Hello, World!?\"'",
            domain=Domain.GENERAL,
        )

        result = cache.get_or_parse(claim)

        # Punctuation stripped from start/end.
        assert "hello" in result.normalized_text.lower()
        assert "world" in result.normalized_text.lower()

    def test_tokenization_splits_on_non_alphanumeric(self) -> None:
        """Tokens should split on non-word characters (hyphens, spaces, etc.)."""
        cache = ClaimCache()
        claim = Claim(
            claim_id="c1",
            text="hello-world test 123",
            domain=Domain.GENERAL,
        )

        result = cache.get_or_parse(claim)

        # Should split on hyphens and spaces, not underscores.
        assert "hello" in result.tokens
        assert "world" in result.tokens
        assert "test" in result.tokens
        assert "123" in result.tokens
