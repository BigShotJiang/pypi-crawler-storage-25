"""HTTP integration tests for the W28 claim-lifecycle surface.

Covers the full round-trip: verify_claim registers a root envelope,
supersede_claim mints a linked successor, /claims/{id}/history walks
the chain, /claims/latest resolves the head, and the parent's
cache entry is invalidated on supersede.
"""
from __future__ import annotations

from datetime import UTC, datetime

import pytest
from fastapi.testclient import TestClient
from pydantic import HttpUrl

from gtv.adapters import REGISTRY
from gtv.adapters.base import HealthStatus, RawSnapshot, SourceAdapter
from gtv.cache import InMemoryCacheStore, VerdictCache
from gtv.lifecycle import LifecycleIndex
from gtv.models import (
    Claim,
    Evidence,
    SourceType,
    Stance,
    SupersedeReason,
    TrustTier,
)


class _TrivialAdapter(SourceAdapter):
    """Adapter that always returns one matching evidence — good enough to
    satisfy REGISTRY and produce a VERIFIED verdict without hitting the
    network. Call count is tracked so we can assert cache invalidations."""

    source_did = "did:web:trivial.example"
    name = "trivial"
    source_type = SourceType.REFERENCE_DATA
    trust_tier = TrustTier.TIER_1
    freshness_sla_s = 60

    def __init__(self) -> None:
        self.call_count = 0

    async def query(self, claim: Claim, max_items: int = 5) -> list[Evidence]:
        self.call_count += 1
        return [
            Evidence(
                claim_id=claim.claim_id,
                source_did=self.source_did,
                source_version="v1",
                stance=Stance.SUPPORTS,
                excerpt="evidence",
                url=HttpUrl("https://trivial.example/e/1"),
                retrieved_at=datetime.now(tz=UTC),
                raw_hash="0" * 64,
            )
        ]

    async def snapshot(self, url: str) -> RawSnapshot:
        return RawSnapshot(url=url, content=b"", retrieved_at_iso="")

    async def health(self) -> HealthStatus:
        return HealthStatus(state="HEALTHY", detail="")

    async def close(self) -> None:
        return None


@pytest.fixture
def lifecycle_server() -> tuple[TestClient, _TrivialAdapter]:
    """Swap in a trivial adapter, fresh cache, and fresh lifecycle index.

    Same swap-in-place pattern as tests/test_cache_integration.py — no
    module reloads, so other tests that imported REGISTRY at module load
    time keep working.
    """
    import gtv.mcp.server as server_mod

    saved_registry = dict(REGISTRY)
    saved_cache = server_mod._VERDICT_CACHE
    saved_lifecycle = server_mod._LIFECYCLE
    REGISTRY.clear()
    adapter = _TrivialAdapter()
    REGISTRY[adapter.source_did] = adapter
    server_mod._VERDICT_CACHE = VerdictCache(InMemoryCacheStore())
    server_mod._LIFECYCLE = LifecycleIndex()

    client = TestClient(server_mod.app)
    try:
        yield client, adapter
    finally:
        REGISTRY.clear()
        REGISTRY.update(saved_registry)
        server_mod._VERDICT_CACHE = saved_cache
        server_mod._LIFECYCLE = saved_lifecycle


def test_verify_claim_registers_root_in_lifecycle(
    lifecycle_server: tuple[TestClient, _TrivialAdapter],
) -> None:
    client, _ = lifecycle_server

    r = client.post(
        "/tools/verify_claim",
        json={"claim": "The sky is blue.", "domain": "physics", "max_sources": 3},
    )
    assert r.status_code == 200
    env = r.json()["envelope"]
    assert env["supersedes"] == []
    assert env["supersede_reason"] is None

    # /claims/{id}/history returns the single-entry chain for a root.
    hist = client.get(f"/claims/{env['envelope_id']}/history").json()
    assert len(hist["entries"]) == 1
    assert hist["entries"][0]["parents"] == []


def test_supersede_claim_links_to_parent(
    lifecycle_server: tuple[TestClient, _TrivialAdapter],
) -> None:
    client, adapter = lifecycle_server

    r1 = client.post(
        "/tools/verify_claim",
        json={"claim": "pi is 3.14", "domain": "math", "max_sources": 3},
    )
    assert r1.status_code == 200
    parent_id = r1.json()["envelope"]["envelope_id"]

    r2 = client.post(
        "/tools/supersede_claim",
        json={
            "parent_envelope_id": parent_id,
            "claim": "pi is approximately 3.14159",
            "domain": "math",
            "reason": "AMEND",
            "max_sources": 3,
        },
    )
    assert r2.status_code == 200
    new_env = r2.json()["envelope"]
    assert new_env["supersedes"] == [parent_id]
    assert new_env["supersede_reason"] == SupersedeReason.AMEND.value
    assert new_env["envelope_id"] != parent_id

    # The signed canonical hash includes the supersede fields — verify
    # by recomputing it and confirming the stub signature matches.
    from gtv.anchor.canonicalize import envelope_canonical_sha256
    from gtv.models import Envelope as EnvelopeModel

    env_obj = EnvelopeModel.model_validate(new_env)
    canonical_hex = envelope_canonical_sha256(env_obj)
    import hashlib as _hashlib

    expected = _hashlib.sha256(canonical_hex.encode("utf-8")).hexdigest()
    assert env_obj.signature == f"stub://{expected}"

    # History walks back to the parent.
    hist = client.get(f"/claims/{new_env['envelope_id']}/history").json()
    assert [e["envelope_id"] for e in hist["entries"]] == [
        new_env["envelope_id"],
        parent_id,
    ]

    # Adapter should have been called twice — once per verified claim.
    assert adapter.call_count == 2


def test_supersede_claim_404_on_unknown_parent(
    lifecycle_server: tuple[TestClient, _TrivialAdapter],
) -> None:
    client, _ = lifecycle_server
    r = client.post(
        "/tools/supersede_claim",
        json={
            "parent_envelope_id": "00000000-0000-0000-0000-000000000000",
            "claim": "x",
            "domain": "physics",
            "reason": "SUPERSEDE",
            "max_sources": 3,
        },
    )
    assert r.status_code == 404


def test_supersede_claim_invalidates_parent_cache(
    lifecycle_server: tuple[TestClient, _TrivialAdapter],
) -> None:
    """After supersede_claim, the parent's cache entry is gone, so the
    next verify_claim with the same inputs hits the adapter again."""
    client, adapter = lifecycle_server

    r1 = client.post(
        "/tools/verify_claim",
        json={"claim": "c1", "domain": "physics", "max_sources": 3},
    )
    parent_id = r1.json()["envelope"]["envelope_id"]
    assert adapter.call_count == 1

    # Cache hit — adapter not re-queried.
    client.post(
        "/tools/verify_claim",
        json={"claim": "c1", "domain": "physics", "max_sources": 3},
    )
    assert adapter.call_count == 1

    # Supersede. Cache entry for ("c1", physics, max=3, issuer) gets nuked.
    # (adapter is called +1 inside supersede_claim to mint the new envelope.)
    r_super = client.post(
        "/tools/supersede_claim",
        json={
            "parent_envelope_id": parent_id,
            "claim": "c1",
            "domain": "physics",
            "reason": "SUPERSEDE",
            "max_sources": 3,
        },
    )
    assert r_super.status_code == 200
    assert adapter.call_count == 2

    # Next verify_claim for the same inputs must hit the adapter again
    # (parent cache entry was invalidated).
    client.post(
        "/tools/verify_claim",
        json={"claim": "c1", "domain": "physics", "max_sources": 3},
    )
    assert adapter.call_count == 3


def test_claims_latest_returns_head(
    lifecycle_server: tuple[TestClient, _TrivialAdapter],
) -> None:
    client, _ = lifecycle_server

    r1 = client.post(
        "/tools/verify_claim",
        json={"claim": "The sky is blue.", "domain": "physics", "max_sources": 3},
    )
    parent_id = r1.json()["envelope"]["envelope_id"]
    r2 = client.post(
        "/tools/supersede_claim",
        json={
            "parent_envelope_id": parent_id,
            "claim": "The sky is blue.",
            "domain": "physics",
            "reason": "SUPERSEDE",
            "max_sources": 3,
        },
    )
    child_id = r2.json()["envelope"]["envelope_id"]

    # /claims/latest should find the child (head) regardless of casing
    # and whitespace — normalization is applied.
    r = client.get(
        "/claims/latest",
        params={"claim": "the  SKY is blue.", "domain": "physics"},
    )
    assert r.status_code == 200
    assert r.json()["envelope"]["envelope_id"] == child_id


def test_claims_latest_404_when_no_entry(
    lifecycle_server: tuple[TestClient, _TrivialAdapter],
) -> None:
    client, _ = lifecycle_server
    r = client.get(
        "/claims/latest",
        params={"claim": "never verified", "domain": "physics"},
    )
    assert r.status_code == 404


def test_history_404_for_unknown_envelope(
    lifecycle_server: tuple[TestClient, _TrivialAdapter],
) -> None:
    client, _ = lifecycle_server
    r = client.get("/claims/00000000-0000-0000-0000-000000000000/history")
    assert r.status_code == 404


def test_superseding_without_any_adapter_is_503(
    lifecycle_server: tuple[TestClient, _TrivialAdapter],
) -> None:
    """No adapters registered → 503, same behavior as verify_claim."""
    client, _ = lifecycle_server
    REGISTRY.clear()
    r = client.post(
        "/tools/supersede_claim",
        json={
            "parent_envelope_id": "doesnt-matter",
            "claim": "x",
            "domain": "physics",
            "reason": "SUPERSEDE",
            "max_sources": 3,
        },
    )
    assert r.status_code == 503


def test_backward_compat_envelope_without_supersedes_hashes_identically() -> None:
    """Pre-W28 envelopes (no supersedes / supersede_reason) must hash the
    same as post-W28 envelopes where those fields are at their defaults.
    This is the contract that keeps v0.1.0-signed envelopes valid."""
    from gtv.anchor.canonicalize import canonicalize, sha256
    from gtv.models import AnchorProof

    # Build an envelope with explicit default lifecycle values.
    env = {
        "envelope_id": "ignored",
        "verdict": "VERIFIED",
        "confidence": 0.9,
        "evidence": [],
        "rationale": "",
        "issuer_did": "did:web:x",
        "issued_at": "ignored",
        "signature": "",
        "rekor_uuid": "",
        "rekor_log_index": 0,
        "tsa_token": "",
        "prov_graph": "{}",
        "anchor_proof": AnchorProof(
            rekor_inclusion_proof="",
            tsa_tsr_primary="",
            tsa_tsr_secondary=None,
        ).model_dump(mode="json"),
        "supersedes": [],
        "supersede_reason": None,
    }
    # Strip the same fields envelope_canonical_sha256 strips.
    for stripped in (
        "signature",
        "rekor_uuid",
        "rekor_log_index",
        "tsa_token",
        "anchor_proof",
        "envelope_id",
        "issued_at",
    ):
        env.pop(stripped, None)
    # Also strip defaults — matches the W28 backward-compat rule.
    env.pop("supersedes", None)
    env.pop("supersede_reason", None)
    hash_with_defaults_stripped = sha256(canonicalize(env))

    # Recompute without ever adding the lifecycle fields (simulates a
    # pre-W28 dump).
    hash_pre_w28 = sha256(canonicalize(env))
    assert hash_with_defaults_stripped == hash_pre_w28
