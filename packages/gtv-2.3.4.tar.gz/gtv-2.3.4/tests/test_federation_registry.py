"""Tests for the federation issuer registry."""
from __future__ import annotations

import json
import tempfile
from pathlib import Path

import pytest

from gtv.federation.loader import load_registry_from_env, load_registry_from_json
from gtv.federation.registry import DEFAULT_REGISTRY, IssuerRegistry, TrustedIssuer
from gtv.models import TrustTier


class TestTrustedIssuer:
    """Tests for TrustedIssuer model."""

    def test_construct_minimal(self) -> None:
        """Test construction with required fields only."""
        issuer = TrustedIssuer(
            did="did:web:example.com",
            trust_tier=TrustTier.TIER_1,
            display_name="Example Issuer",
        )
        assert issuer.did == "did:web:example.com"
        assert issuer.trust_tier == TrustTier.TIER_1
        assert issuer.display_name == "Example Issuer"
        assert issuer.expected_fulcio_oidc is None
        assert issuer.expected_issuer_email is None
        assert issuer.notes is None

    def test_construct_full(self) -> None:
        """Test construction with all fields."""
        issuer = TrustedIssuer(
            did="did:web:example.com",
            trust_tier=TrustTier.TIER_2,
            display_name="Full Example",
            expected_fulcio_oidc="https://oauth.sigstore.dev",
            expected_issuer_email="signer@example.com",
            notes="Development issuer",
        )
        assert issuer.did == "did:web:example.com"
        assert issuer.trust_tier == TrustTier.TIER_2
        assert issuer.display_name == "Full Example"
        assert issuer.expected_fulcio_oidc == "https://oauth.sigstore.dev"
        assert issuer.expected_issuer_email == "signer@example.com"
        assert issuer.notes == "Development issuer"

    def test_trust_tier_enum_validation(self) -> None:
        """Test that trust_tier validates as TrustTier enum."""
        issuer = TrustedIssuer(
            did="did:web:example.com",
            trust_tier="TIER_3",  # String is coerced by Pydantic
            display_name="Tier 3",
        )
        assert issuer.trust_tier == TrustTier.TIER_3

    def test_invalid_trust_tier(self) -> None:
        """Test that invalid trust_tier raises."""
        with pytest.raises(ValueError):
            TrustedIssuer(
                did="did:web:example.com",
                trust_tier="INVALID_TIER",  # type: ignore
                display_name="Bad Tier",
            )

    def test_missing_required_fields(self) -> None:
        """Test that missing required fields raise."""
        with pytest.raises(ValueError):
            TrustedIssuer(
                did="did:web:example.com",
                trust_tier=TrustTier.TIER_1,
                # missing display_name
            )


class TestIssuerRegistry:
    """Tests for IssuerRegistry."""

    def test_add_and_get(self) -> None:
        """Test adding and retrieving an issuer."""
        registry = IssuerRegistry()
        issuer = TrustedIssuer(
            did="did:web:example.com",
            trust_tier=TrustTier.TIER_1,
            display_name="Example",
        )
        registry.add(issuer)

        retrieved = registry.get("did:web:example.com")
        assert retrieved == issuer

    def test_get_nonexistent(self) -> None:
        """Test getting a nonexistent issuer returns None."""
        registry = IssuerRegistry()
        result = registry.get("did:web:nonexistent.com")
        assert result is None

    def test_add_duplicate_raises(self) -> None:
        """Test that adding a duplicate DID raises."""
        registry = IssuerRegistry()
        issuer1 = TrustedIssuer(
            did="did:web:example.com",
            trust_tier=TrustTier.TIER_1,
            display_name="First",
        )
        issuer2 = TrustedIssuer(
            did="did:web:example.com",
            trust_tier=TrustTier.TIER_2,
            display_name="Second",
        )
        registry.add(issuer1)

        with pytest.raises(ValueError, match="already registered"):
            registry.add(issuer2)

    def test_remove_and_verify_gone(self) -> None:
        """Test removing an issuer."""
        registry = IssuerRegistry()
        issuer = TrustedIssuer(
            did="did:web:example.com",
            trust_tier=TrustTier.TIER_1,
            display_name="Example",
        )
        registry.add(issuer)
        assert registry.get("did:web:example.com") is not None

        registry.remove("did:web:example.com")
        assert registry.get("did:web:example.com") is None

    def test_remove_nonexistent_raises(self) -> None:
        """Test that removing a nonexistent issuer raises."""
        registry = IssuerRegistry()
        with pytest.raises(ValueError, match="not found"):
            registry.remove("did:web:nonexistent.com")

    def test_list_all(self) -> None:
        """Test listing all issuers."""
        registry = IssuerRegistry()
        issuer1 = TrustedIssuer(
            did="did:web:example1.com",
            trust_tier=TrustTier.TIER_1,
            display_name="First",
        )
        issuer2 = TrustedIssuer(
            did="did:web:example2.com",
            trust_tier=TrustTier.TIER_2,
            display_name="Second",
        )
        registry.add(issuer1)
        registry.add(issuer2)

        all_issuers = registry.list_all()
        assert len(all_issuers) == 2
        assert issuer1 in all_issuers
        assert issuer2 in all_issuers

    def test_list_all_empty(self) -> None:
        """Test listing from an empty registry."""
        registry = IssuerRegistry()
        assert registry.list_all() == []

    def test_filter_by_tier(self) -> None:
        """Test filtering by trust tier."""
        registry = IssuerRegistry()
        tier1_a = TrustedIssuer(
            did="did:web:tier1a.com",
            trust_tier=TrustTier.TIER_1,
            display_name="Tier 1A",
        )
        tier1_b = TrustedIssuer(
            did="did:web:tier1b.com",
            trust_tier=TrustTier.TIER_1,
            display_name="Tier 1B",
        )
        tier2 = TrustedIssuer(
            did="did:web:tier2.com",
            trust_tier=TrustTier.TIER_2,
            display_name="Tier 2",
        )
        registry.add(tier1_a)
        registry.add(tier1_b)
        registry.add(tier2)

        tier1_results = registry.filter_by_tier(TrustTier.TIER_1)
        assert len(tier1_results) == 2
        assert tier1_a in tier1_results
        assert tier1_b in tier1_results

        tier2_results = registry.filter_by_tier(TrustTier.TIER_2)
        assert len(tier2_results) == 1
        assert tier2 in tier2_results

        tier3_results = registry.filter_by_tier(TrustTier.TIER_3)
        assert len(tier3_results) == 0

    def test_filter_by_tier_empty(self) -> None:
        """Test filtering from an empty registry."""
        registry = IssuerRegistry()
        result = registry.filter_by_tier(TrustTier.TIER_1)
        assert result == []


class TestDefaultRegistry:
    """Tests for the module-level DEFAULT_REGISTRY."""

    def test_default_registry_contains_reference_entry(self) -> None:
        """Test that DEFAULT_REGISTRY has the expected reference entry."""
        all_issuers = DEFAULT_REGISTRY.list_all()
        assert len(all_issuers) == 1

        issuer = all_issuers[0]
        assert issuer.did == "did:web:verify.groundtruth.example"
        assert issuer.trust_tier == TrustTier.TIER_1
        assert issuer.display_name == "GTV Reference Implementation"
        assert issuer.notes == "Local/stub issuer for development."

    def test_default_registry_get(self) -> None:
        """Test retrieving from DEFAULT_REGISTRY."""
        issuer = DEFAULT_REGISTRY.get("did:web:verify.groundtruth.example")
        assert issuer is not None
        assert issuer.trust_tier == TrustTier.TIER_1


class TestLoadRegistryFromJson:
    """Tests for load_registry_from_json."""

    def test_load_empty_list(self) -> None:
        """Test loading an empty JSON list."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            json.dump([], f)
            path = f.name

        try:
            registry = load_registry_from_json(path)
            assert registry.list_all() == []
        finally:
            Path(path).unlink()

    def test_load_single_issuer(self) -> None:
        """Test loading a single issuer."""
        data = [
            {
                "did": "did:web:example.com",
                "trust_tier": "TIER_1",
                "display_name": "Example",
                "notes": "Test issuer",
            }
        ]
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            json.dump(data, f)
            path = f.name

        try:
            registry = load_registry_from_json(path)
            issuers = registry.list_all()
            assert len(issuers) == 1
            assert issuers[0].did == "did:web:example.com"
            assert issuers[0].display_name == "Example"
        finally:
            Path(path).unlink()

    def test_load_multiple_issuers(self) -> None:
        """Test loading multiple issuers."""
        data = [
            {
                "did": "did:web:example1.com",
                "trust_tier": "TIER_1",
                "display_name": "Example 1",
            },
            {
                "did": "did:web:example2.com",
                "trust_tier": "TIER_2",
                "display_name": "Example 2",
                "expected_fulcio_oidc": "https://oauth.sigstore.dev",
            },
        ]
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            json.dump(data, f)
            path = f.name

        try:
            registry = load_registry_from_json(path)
            issuers = registry.list_all()
            assert len(issuers) == 2
            assert issuers[0].did == "did:web:example1.com"
            assert issuers[1].expected_fulcio_oidc == "https://oauth.sigstore.dev"
        finally:
            Path(path).unlink()

    def test_load_nonexistent_file_raises(self) -> None:
        """Test that loading a nonexistent file raises."""
        with pytest.raises(FileNotFoundError):
            load_registry_from_json("/nonexistent/path/to/registry.json")

    def test_load_invalid_json_raises(self) -> None:
        """Test that invalid JSON raises."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            f.write("{invalid json}")
            path = f.name

        try:
            with pytest.raises(json.JSONDecodeError):
                load_registry_from_json(path)
        finally:
            Path(path).unlink()

    def test_load_non_list_raises(self) -> None:
        """Test that non-list JSON raises."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            json.dump({"not": "a list"}, f)
            path = f.name

        try:
            with pytest.raises(ValueError, match="must be a list"):
                load_registry_from_json(path)
        finally:
            Path(path).unlink()

    def test_load_invalid_issuer_raises(self) -> None:
        """Test that invalid issuer data raises."""
        data = [
            {
                "did": "did:web:example.com",
                # missing trust_tier and display_name
            }
        ]
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            json.dump(data, f)
            path = f.name

        try:
            with pytest.raises(ValueError):
                load_registry_from_json(path)
        finally:
            Path(path).unlink()

    def test_roundtrip(self) -> None:
        """Test writing and loading a registry."""
        # Create a registry and add an issuer
        registry1 = IssuerRegistry()
        issuer = TrustedIssuer(
            did="did:web:roundtrip.com",
            trust_tier=TrustTier.TIER_1,
            display_name="Roundtrip Test",
            expected_issuer_email="test@example.com",
            notes="Testing roundtrip",
        )
        registry1.add(issuer)

        # Export to JSON
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            data = [
                {
                    "did": i.did,
                    "trust_tier": i.trust_tier,
                    "display_name": i.display_name,
                    "expected_fulcio_oidc": i.expected_fulcio_oidc,
                    "expected_issuer_email": i.expected_issuer_email,
                    "notes": i.notes,
                }
                for i in registry1.list_all()
            ]
            json.dump(data, f)
            path = f.name

        try:
            # Load back
            registry2 = load_registry_from_json(path)
            issuers = registry2.list_all()
            assert len(issuers) == 1
            loaded = issuers[0]
            assert loaded.did == issuer.did
            assert loaded.trust_tier == issuer.trust_tier
            assert loaded.display_name == issuer.display_name
            assert loaded.expected_issuer_email == issuer.expected_issuer_email
            assert loaded.notes == issuer.notes
        finally:
            Path(path).unlink()


class TestLoadRegistryFromEnv:
    """Tests for load_registry_from_env."""

    def test_unset_env_returns_none(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test that unset env var returns None."""
        monkeypatch.delenv("GTV_FEDERATION_REGISTRY", raising=False)
        result = load_registry_from_env("GTV_FEDERATION_REGISTRY")
        assert result is None

    def test_missing_file_returns_none_with_warning(
        self, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """Test that missing file returns None and logs warning."""
        monkeypatch.setenv("GTV_FEDERATION_REGISTRY", "/nonexistent/registry.json")
        result = load_registry_from_env("GTV_FEDERATION_REGISTRY")
        assert result is None

        captured = capsys.readouterr()
        assert "does not exist" in captured.err

    def test_valid_file_loads_registry(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test that valid file loads successfully."""
        data = [
            {
                "did": "did:web:env.example.com",
                "trust_tier": "TIER_1",
                "display_name": "Env Test",
            }
        ]
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            json.dump(data, f)
            path = f.name

        try:
            monkeypatch.setenv("GTV_FEDERATION_REGISTRY", path)
            registry = load_registry_from_env("GTV_FEDERATION_REGISTRY")
            assert registry is not None
            issuers = registry.list_all()
            assert len(issuers) == 1
            assert issuers[0].did == "did:web:env.example.com"
        finally:
            Path(path).unlink()

    def test_custom_env_var_name(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test using a custom environment variable name."""
        data = [
            {
                "did": "did:web:custom.example.com",
                "trust_tier": "TIER_2",
                "display_name": "Custom Env",
            }
        ]
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            json.dump(data, f)
            path = f.name

        try:
            monkeypatch.setenv("MY_CUSTOM_REGISTRY", path)
            registry = load_registry_from_env("MY_CUSTOM_REGISTRY")
            assert registry is not None
            issuers = registry.list_all()
            assert len(issuers) == 1
            assert issuers[0].did == "did:web:custom.example.com"
        finally:
            Path(path).unlink()
