"""Tests for retrieve_facts MCP tool and extract_subclaims.

Unit tests for extract_subclaims (no network).
Integration tests for /tools/retrieve_facts endpoint via httpx.AsyncClient.
"""
from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

from gtv.adapters import REGISTRY
from gtv.mcp.server import app
from gtv.retrieve.extract import extract_subclaims

# ============================================================================
# Unit tests for extract_subclaims (stdlib only, no network)
# ============================================================================

class TestExtractSubclaims:
    """Test the subclaim extraction heuristic."""

    def test_extract_single_sentence(self) -> None:
        """Single sentence should be extracted."""
        text = "The Higgs boson has mass 125 GeV."
        result = extract_subclaims(text, max_subclaims=5)
        assert len(result) == 1
        assert result[0] == "The Higgs boson has mass 125 GeV"

    def test_extract_multiple_sentences(self) -> None:
        """Multiple sentences split on period, exclamation, question mark."""
        text = "The Sun is a star. It has mass 2e30 kg!"
        result = extract_subclaims(text, max_subclaims=5)
        assert len(result) == 2
        assert result[0] == "The Sun is a star"
        assert result[1] == "It has mass 2e30 kg"

    def test_filter_questions(self) -> None:
        """Sentences that are questions should be filtered."""
        text = "The Higgs boson exists. What is its mass? It is 125 GeV."
        result = extract_subclaims(text, max_subclaims=5)
        # "What is its mass?" should be filtered
        assert len(result) == 2
        assert "What" not in result[0]
        assert "125 GeV" in result[1]

    def test_filter_imperatives(self) -> None:
        """Imperative sentences (commands) should be filtered."""
        text = "Water boils at 100C. Try heating it. Mercury boils at 357C."
        result = extract_subclaims(text, max_subclaims=5)
        # "Try heating it" should be filtered
        assert len(result) == 2
        assert "Water boils" in result[0]
        assert "Mercury boils" in result[1]

    def test_max_subclaims_cap(self) -> None:
        """Should not exceed max_subclaims."""
        text = "Fact one. Fact two. Fact three. Fact four. Fact five. Fact six."
        result = extract_subclaims(text, max_subclaims=3)
        assert len(result) == 3
        assert result[0] == "Fact one"
        assert result[2] == "Fact three"

    def test_empty_input(self) -> None:
        """Empty or whitespace-only input should return empty list."""
        assert extract_subclaims("") == []
        assert extract_subclaims("   ") == []

    def test_newline_splitting(self) -> None:
        """Sentences separated by newlines should be extracted."""
        text = "First sentence\nSecond sentence\nThird sentence"
        result = extract_subclaims(text, max_subclaims=5)
        assert len(result) == 3
        assert result[0] == "First sentence"
        assert result[1] == "Second sentence"

    def test_order_preserved(self) -> None:
        """Extracted claims should preserve input order."""
        text = "Alpha. Beta. Gamma. Delta."
        result = extract_subclaims(text, max_subclaims=4)
        assert result[0] == "Alpha"
        assert result[1] == "Beta"
        assert result[2] == "Gamma"
        assert result[3] == "Delta"

    def test_strip_whitespace(self) -> None:
        """Leading/trailing whitespace around sentences should be stripped."""
        text = "  First sentence  .  Second sentence  ."
        result = extract_subclaims(text, max_subclaims=5)
        assert result[0] == "First sentence"
        assert result[1] == "Second sentence"

    def test_mixed_punctuation(self) -> None:
        """Should handle mixed punctuation (. ! ?) correctly."""
        text = "Question? Exclamation! Statement."
        result = extract_subclaims(text, max_subclaims=5)
        # Question should be filtered, but exclamation and statement should remain
        assert len(result) == 2
        assert "Exclamation" in result[0]

    def test_complex_text(self) -> None:
        """Test a realistic multi-sentence text."""
        text = (
            "The Higgs boson has mass 125 GeV. "
            "What is its spin? "
            "Electrons orbit atoms. "
            "Find the mass of a proton. "
            "The speed of light is 3e8 m/s."
        )
        result = extract_subclaims(text, max_subclaims=5)
        # Questions and imperatives filtered; max_subclaims=5 should be respected
        assert len(result) <= 5
        assert "Higgs boson" in result[0]
        assert len(result) >= 3  # At least 3 facts should be extracted


# ============================================================================
# Integration tests for /tools/retrieve_facts endpoint
# ============================================================================

class TestRetrieveFactsEndpoint:
    """Test the /tools/retrieve_facts HTTP endpoint."""

    def test_retrieve_facts_without_adapters_returns_503(self) -> None:
        """Should return 503 when no adapters are registered."""
        saved_registry = dict(REGISTRY)
        try:
            REGISTRY.clear()
            client = TestClient(app)
            response = client.post(
                "/tools/retrieve_facts",
                json={"query": "test", "max_results": 2},
            )
            assert response.status_code == 503
        finally:
            REGISTRY.update(saved_registry)

    def test_retrieve_facts_with_adapters_returns_200(self) -> None:
        """Should return 200 when adapters are registered."""
        if not REGISTRY:
            pytest.skip("No adapters registered in test environment")

        client = TestClient(app)
        response = client.post(
            "/tools/retrieve_facts",
            json={
                "query": "The Higgs boson has mass 125 GeV. The Sun is a star.",
                "max_results": 2,
            },
        )
        assert response.status_code == 200

    def test_retrieve_facts_response_structure(self) -> None:
        """Response should have required RetrieveFactsEnvelope fields."""
        if not REGISTRY:
            pytest.skip("No adapters registered in test environment")

        client = TestClient(app)
        response = client.post(
            "/tools/retrieve_facts",
            json={
                "query": "The Higgs boson has mass 125 GeV.",
                "max_results": 1,
            },
        )
        assert response.status_code == 200
        data = response.json()

        # Check envelope fields
        assert "envelope_id" in data
        assert "facts" in data
        assert isinstance(data["facts"], list)
        assert "issuer_did" in data
        assert "issued_at" in data
        assert "signature" in data
        assert "rekor_uuid" in data
        assert "rekor_log_index" in data
        assert "tsa_token" in data
        assert "anchor_proof" in data

    def test_retrieve_facts_with_max_results(self) -> None:
        """Should respect max_results parameter."""
        if not REGISTRY:
            pytest.skip("No adapters registered in test environment")

        client = TestClient(app)
        response = client.post(
            "/tools/retrieve_facts",
            json={
                "query": (
                    "Fact one. Fact two. Fact three. Fact four. Fact five. Fact six."
                ),
                "max_results": 2,
            },
        )
        assert response.status_code == 200
        data = response.json()
        # Should have at most 2 facts (max_results)
        assert len(data["facts"]) <= 2

    def test_retrieve_facts_validates_query_length(self) -> None:
        """Should reject queries exceeding max length (500 chars)."""
        client = TestClient(app)
        long_query = "a" * 501
        response = client.post(
            "/tools/retrieve_facts",
            json={"query": long_query, "max_results": 2},
        )
        assert response.status_code == 422  # validation error

    def test_retrieve_facts_with_domain(self) -> None:
        """Should accept domain parameter."""
        if not REGISTRY:
            pytest.skip("No adapters registered in test environment")

        client = TestClient(app)
        response = client.post(
            "/tools/retrieve_facts",
            json={
                "query": "The Higgs boson has mass 125 GeV.",
                "domain": "physics",
                "max_results": 1,
            },
        )
        assert response.status_code == 200

    def test_retrieve_facts_empty_query_after_extraction(self) -> None:
        """Should handle cases where no extractable claims are found."""
        if not REGISTRY:
            pytest.skip("No adapters registered in test environment")

        client = TestClient(app)
        # Only questions and imperatives - should extract nothing
        response = client.post(
            "/tools/retrieve_facts",
            json={
                "query": "What is this? Try that.",
                "max_results": 5,
            },
        )
        assert response.status_code == 200
        data = response.json()
        # Should have empty facts list
        assert data["facts"] == []

    def test_retrieve_facts_fact_items_have_verdict(self) -> None:
        """Each fact item should have a verdict field."""
        if not REGISTRY:
            pytest.skip("No adapters registered in test environment")

        client = TestClient(app)
        response = client.post(
            "/tools/retrieve_facts",
            json={
                "query": "The Higgs boson has mass 125 GeV.",
                "max_results": 1,
            },
        )
        assert response.status_code == 200
        data = response.json()
        if data["facts"]:
            fact = data["facts"][0]
            assert "verdict" in fact
            assert fact["verdict"] in [
                "VERIFIED", "UNVERIFIED", "CONTESTED", "OPINION",
                "CREATIVE", "OUT_OF_SCOPE"
            ]

    def test_retrieve_facts_fact_items_have_confidence(self) -> None:
        """Each fact item should have a confidence field (0-1)."""
        if not REGISTRY:
            pytest.skip("No adapters registered in test environment")

        client = TestClient(app)
        response = client.post(
            "/tools/retrieve_facts",
            json={
                "query": "The Higgs boson has mass 125 GeV.",
                "max_results": 1,
            },
        )
        assert response.status_code == 200
        data = response.json()
        if data["facts"]:
            fact = data["facts"][0]
            assert "confidence" in fact
            assert isinstance(fact["confidence"], (int, float))
            assert 0.0 <= fact["confidence"] <= 1.0


# ============================================================================
# Smoke test: validate the full workflow
# ============================================================================

def test_retrieve_facts_smoke() -> None:
    """Smoke test: /tools/retrieve_facts with two facts in query."""
    if not REGISTRY:
        pytest.skip("No adapters registered in test environment")

    client = TestClient(app)
    response = client.post(
        "/tools/retrieve_facts",
        json={
            "query": "The Higgs boson has mass 125 GeV. The Sun is a star.",
            "max_results": 2,
        },
    )

    assert response.status_code == 200
    data = response.json()

    # Check that we got an envelope
    assert "envelope_id" in data
    assert "signature" in data
    assert len(data["signature"]) > 0  # Should be populated with real signature

    # Check that we got facts
    assert "facts" in data
    assert isinstance(data["facts"], list)
    # Should extract 2 sub-claims
    assert len(data["facts"]) <= 2
    # Each fact should have a verdict
    for fact in data["facts"]:
        assert fact["verdict"] in [
            "VERIFIED", "UNVERIFIED", "CONTESTED", "OPINION",
            "CREATIVE", "OUT_OF_SCOPE"
        ]
