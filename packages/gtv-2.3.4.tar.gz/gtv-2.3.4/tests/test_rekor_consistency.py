"""Tests for RFC 6962 / RFC 9162 consistency-proof verification.

Strategy:
  1. Build a synthetic Merkle tree of N leaves.
  2. For every m < n, generate the consistency proof and confirm it verifies.
  3. Adversarial: tamper with proof, roots, sizes — expect ConsistencyProofError.

Round-tripping against our own generator catches implementation bugs without
requiring a live Rekor instance. A separate live smoke (opt-in, gated on
GTV_LIVE) would additionally validate against real Rekor — left for the
integration suite rather than a unit test.
"""
from __future__ import annotations

import hashlib
import itertools

import pytest

from gtv.anchor.consistency import (
    ConsistencyProofError,
    generate_consistency_proof,
    leaf_hash,
    merkle_root,
    verify_consistency_proof,
)


def _leaves(n: int) -> list[bytes]:
    """Build `n` deterministic leaf hashes."""
    return [leaf_hash(f"entry-{i}".encode()) for i in range(n)]


# ---------------------------------------------------------------------------
# Round-trip
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("n", [1, 2, 3, 4, 7, 8, 15, 16, 31, 33, 64, 100])
def test_roundtrip_all_prefixes(n: int) -> None:
    """For every (m, n) with 0 <= m <= n, generator + verifier agree."""
    leaves = _leaves(n)
    full_root = merkle_root(leaves)

    for m in range(n + 1):
        first_leaves = leaves[:m]
        first_root = merkle_root(first_leaves) if m > 0 else hashlib.sha256(b"").digest()
        proof = generate_consistency_proof(leaves, m)
        # Should not raise.
        verify_consistency_proof(
            first_size=m,
            second_size=n,
            first_root=first_root,
            second_root=full_root,
            proof=proof,
        )


def test_m_equals_n_requires_empty_proof_and_equal_roots() -> None:
    leaves = _leaves(5)
    root = merkle_root(leaves)

    verify_consistency_proof(
        first_size=5,
        second_size=5,
        first_root=root,
        second_root=root,
        proof=[],
    )

    with pytest.raises(ConsistencyProofError, match="Proof must be empty"):
        verify_consistency_proof(
            first_size=5,
            second_size=5,
            first_root=root,
            second_root=root,
            proof=[b"\x00" * 32],
        )


def test_m_zero_accepts_empty_proof() -> None:
    leaves = _leaves(7)
    root = merkle_root(leaves)
    empty_root = hashlib.sha256(b"").digest()

    verify_consistency_proof(
        first_size=0,
        second_size=7,
        first_root=empty_root,
        second_root=root,
        proof=[],
    )


# ---------------------------------------------------------------------------
# Adversarial: tamper with proof or roots
# ---------------------------------------------------------------------------

def test_wrong_first_root_rejected() -> None:
    leaves = _leaves(9)
    m = 3
    proof = generate_consistency_proof(leaves, m)
    bogus = b"\xff" * 32
    with pytest.raises(ConsistencyProofError, match="first root"):
        verify_consistency_proof(
            first_size=m,
            second_size=9,
            first_root=bogus,
            second_root=merkle_root(leaves),
            proof=proof,
        )


def test_wrong_second_root_rejected() -> None:
    leaves = _leaves(9)
    m = 3
    proof = generate_consistency_proof(leaves, m)
    bogus = b"\xff" * 32
    with pytest.raises(ConsistencyProofError):
        verify_consistency_proof(
            first_size=m,
            second_size=9,
            first_root=merkle_root(leaves[:m]),
            second_root=bogus,
            proof=proof,
        )


def test_tampered_proof_hash_rejected() -> None:
    leaves = _leaves(11)
    m = 4
    proof = generate_consistency_proof(leaves, m)
    assert proof  # sanity

    # Flip one byte in proof[0].
    flipped = bytearray(proof[0])
    flipped[0] ^= 0x01
    tampered = [bytes(flipped), *proof[1:]]

    with pytest.raises(ConsistencyProofError):
        verify_consistency_proof(
            first_size=m,
            second_size=11,
            first_root=merkle_root(leaves[:m]),
            second_root=merkle_root(leaves),
            proof=tampered,
        )


def test_truncated_proof_rejected() -> None:
    leaves = _leaves(11)
    m = 4
    proof = generate_consistency_proof(leaves, m)
    assert len(proof) > 1

    with pytest.raises(ConsistencyProofError, match="truncated"):
        verify_consistency_proof(
            first_size=m,
            second_size=11,
            first_root=merkle_root(leaves[:m]),
            second_root=merkle_root(leaves),
            proof=proof[:-1],
        )


def test_extended_proof_rejected() -> None:
    leaves = _leaves(11)
    m = 4
    proof = generate_consistency_proof(leaves, m)

    with pytest.raises(ConsistencyProofError, match="unused hashes"):
        verify_consistency_proof(
            first_size=m,
            second_size=11,
            first_root=merkle_root(leaves[:m]),
            second_root=merkle_root(leaves),
            proof=[*proof, b"\x42" * 32],
        )


def test_first_size_greater_than_second_rejected() -> None:
    leaves = _leaves(11)
    with pytest.raises(ConsistencyProofError, match="second_size"):
        verify_consistency_proof(
            first_size=11,
            second_size=5,
            first_root=merkle_root(leaves),
            second_root=merkle_root(leaves[:5]),
            proof=[],
        )


def test_malformed_hash_length_rejected() -> None:
    with pytest.raises(ConsistencyProofError, match="32 bytes"):
        verify_consistency_proof(
            first_size=3,
            second_size=7,
            first_root=b"\x00" * 31,  # too short
            second_root=b"\x00" * 32,
            proof=[],
        )


def test_forked_log_detected() -> None:
    """Full-system: two trees that share a prefix but diverge.

    Simulates an operator that silently swaps in a different entry at
    position m+1. Any consistency proof they generate against the original
    first_root (or the forked one) must fail when the verifier insists on
    the honest first_root and the honest second_root.
    """
    honest = _leaves(12)
    forked = [*honest[:5], leaf_hash(b"TAMPERED"), *honest[6:]]  # divergence at idx 5
    m = 4
    honest_first_root = merkle_root(honest[:m])
    honest_second_root = merkle_root(honest)
    forked_second_root = merkle_root(forked)

    # Proof generated against the honest tree must not verify against the
    # forked tree's root.
    honest_proof = generate_consistency_proof(honest, m)
    with pytest.raises(ConsistencyProofError):
        verify_consistency_proof(
            first_size=m,
            second_size=len(honest),
            first_root=honest_first_root,
            second_root=forked_second_root,
            proof=honest_proof,
        )

    # Symmetric: forked proof against honest root also fails.
    forked_proof = generate_consistency_proof(forked, m)
    with pytest.raises(ConsistencyProofError):
        verify_consistency_proof(
            first_size=m,
            second_size=len(honest),
            first_root=honest_first_root,
            second_root=honest_second_root,
            proof=forked_proof,
        )


def test_swapped_size_params_detected() -> None:
    """Swapping first_size and second_size shouldn't let a forged proof slide by."""
    leaves = _leaves(10)
    proof = generate_consistency_proof(leaves, 4)
    with pytest.raises(ConsistencyProofError):
        verify_consistency_proof(
            first_size=10,  # swapped with second_size=4
            second_size=4,
            first_root=merkle_root(leaves),
            second_root=merkle_root(leaves[:4]),
            proof=proof,
        )


# ---------------------------------------------------------------------------
# Matrix: every (m, n) pair for small n — pedantic but cheap.
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("n", [4, 5, 8, 16])
def test_all_pairs_for_small_n(n: int) -> None:
    leaves = _leaves(n)
    root = merkle_root(leaves)
    for m in range(n + 1):
        first_root = (
            merkle_root(leaves[:m]) if m > 0 else hashlib.sha256(b"").digest()
        )
        proof = generate_consistency_proof(leaves, m)
        verify_consistency_proof(
            first_size=m,
            second_size=n,
            first_root=first_root,
            second_root=root,
            proof=proof,
        )


def test_generator_produces_compact_proof() -> None:
    """RFC 6962 proofs are O(log n) — sanity check we're not over-producing."""
    # Tree with 1024 leaves — consistency from 1 to 1024 needs log2(1024)=10 hashes.
    n = 1024
    leaves = _leaves(n)
    # Pick a non-trivial m so proof is non-empty but compact.
    for m in (1, 2, 3, 7, 500, 1023):
        proof = generate_consistency_proof(leaves, m)
        # Upper bound: 2 * ceil(log2(n)) per RFC 6962.
        assert len(proof) <= 2 * n.bit_length(), (
            f"proof for m={m}, n={n} has {len(proof)} hashes — too large"
        )


# Keep the import-unused linter happy.
_ = itertools
