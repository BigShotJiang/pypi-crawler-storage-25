"""Tests for disaster recovery drill (scripts/dr_drill.py).

Tests cover:
- Backup creation and manifest generation
- Restore with SHA256 verification
- Corruption detection
- End-to-end full-drill
- CLI argument parsing and error handling
"""
from __future__ import annotations

import json
import subprocess
import sys
import tempfile
from pathlib import Path

import pytest

# Fixtures


@pytest.fixture
def temp_state_dir() -> Path:
    """Create a temp state dir with minimal gtv files."""
    with tempfile.TemporaryDirectory() as tmpdir:
        state_dir = Path(tmpdir)

        # Create minimal state files
        (state_dir / "audit.db").write_text("test_audit_log_content")
        (state_dir / "verdict.db").write_text("test_verdict_cache_content")
        (state_dir / "federation.db").write_text("test_federation_store_content")
        (state_dir / "revoked_peers.json").write_text('{"revoked_dids": []}')

        yield state_dir


@pytest.fixture
def dr_script() -> Path:
    """Path to dr_drill.py."""
    return Path(__file__).parent.parent / "scripts" / "dr_drill.py"


def _run_dr_drill(dr_script: Path, args: list[str]) -> tuple[int, str, str]:
    """Run dr_drill.py with args, return (exit_code, stdout, stderr)."""
    cmd = [sys.executable, str(dr_script), *args]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
    return result.returncode, result.stdout, result.stderr


# Tests


def test_backup_produces_deterministic_manifest(temp_state_dir: Path, dr_script: Path) -> None:
    """Test that backup creates identical manifest on repeated runs."""
    backup1 = temp_state_dir.parent / "backup1.tar.gz"
    backup2 = temp_state_dir.parent / "backup2.tar.gz"

    # First backup
    rc1, _, _ = _run_dr_drill(
        dr_script,
        ["backup", "--state-dir", str(temp_state_dir), "--output", str(backup1)],
    )
    assert rc1 == 0, "First backup failed"

    # Second backup (same source)
    rc2, _, _ = _run_dr_drill(
        dr_script,
        ["backup", "--state-dir", str(temp_state_dir), "--output", str(backup2)],
    )
    assert rc2 == 0, "Second backup failed"

    # Compare manifests (should be identical for deterministic content)
    manifest1_path = backup1.parent / f"{backup1.name}.manifest.json"
    manifest2_path = backup2.parent / f"{backup2.name}.manifest.json"

    with open(manifest1_path) as f:
        manifest1 = json.load(f)
    with open(manifest2_path) as f:
        manifest2 = json.load(f)

    assert manifest1 == manifest2, "Manifests differ (non-deterministic)"


def test_restore_rejects_tampered_tarball(temp_state_dir: Path, dr_script: Path) -> None:
    """Test that restore detects SHA256 mismatch on tampered tarball."""
    backup = temp_state_dir.parent / "backup.tar.gz"
    restore_dir = temp_state_dir.parent / "restored"

    # Create valid backup
    rc, _, _ = _run_dr_drill(
        dr_script,
        ["backup", "--state-dir", str(temp_state_dir), "--output", str(backup)],
    )
    assert rc == 0, "Backup failed"

    # Tamper with tarball
    with open(backup, "r+b") as f:
        f.seek(100)
        f.write(b"CORRUPTED")

    # Attempt restore (should fail)
    rc, _stdout, stderr = _run_dr_drill(
        dr_script,
        ["restore", "--tarball", str(backup), "--state-dir", str(restore_dir)],
    )
    assert rc != 0, "Restore accepted tampered tarball"
    assert "mismatch" in stderr.lower() or "error" in stderr.lower(), "No error message"


def test_restore_round_trips_correctly(temp_state_dir: Path, dr_script: Path) -> None:
    """Test that backup → restore → verify round-trips successfully."""
    backup = temp_state_dir.parent / "backup.tar.gz"
    restore_dir = temp_state_dir.parent / "restored"

    # Backup
    rc, _, _ = _run_dr_drill(
        dr_script,
        ["backup", "--state-dir", str(temp_state_dir), "--output", str(backup)],
    )
    assert rc == 0, "Backup failed"

    # Restore
    rc, _, _ = _run_dr_drill(
        dr_script,
        ["restore", "--tarball", str(backup), "--state-dir", str(restore_dir)],
    )
    assert rc == 0, "Restore failed"

    # Verify files exist and match
    assert (restore_dir / "audit.db").exists()
    assert (restore_dir / "verdict.db").exists()
    assert (restore_dir / "federation.db").exists()

    # Check content matches
    assert (restore_dir / "audit.db").read_text() == (
        temp_state_dir / "audit.db"
    ).read_text()
    assert (restore_dir / "verdict.db").read_text() == (
        temp_state_dir / "verdict.db"
    ).read_text()


def test_full_drill_happy_path(dr_script: Path) -> None:
    """Test full-drill succeeds on happy path."""
    rc, stdout, stderr = _run_dr_drill(dr_script, ["full-drill"])
    assert rc == 0, f"full-drill failed: {stderr}"
    assert "OK" in stdout, "Success message missing"


def test_full_drill_detects_corruption(dr_script: Path) -> None:
    """Test full-drill can simulate and detect corruption."""
    with tempfile.TemporaryDirectory() as tmpdir:
        state_dir = Path(tmpdir)
        (state_dir / "audit.db").write_text("initial_audit_log")
        (state_dir / "verdict.db").write_text("initial_verdict_cache")

        _rc, stdout, _stderr = _run_dr_drill(dr_script, ["full-drill", "--state-dir", str(state_dir)])

        # The drill should succeed because it backs up before corrupting
        # But we verify the logic works
        assert "Backup" in stdout or "OK" in stdout


def test_cli_exits_2_on_bad_args(dr_script: Path) -> None:
    """Test CLI exits with 2 on invalid arguments."""
    rc, _, _ = _run_dr_drill(dr_script, ["invalid-command"])
    assert rc == 2, f"Expected exit 2 for invalid command, got {rc}"

    # Missing required arg for restore
    rc, _, _ = _run_dr_drill(dr_script, ["restore"])
    assert rc == 2, f"Expected exit 2 for missing --tarball, got {rc}"


def test_backup_missing_state_dir(dr_script: Path) -> None:
    """Test backup fails gracefully if state dir does not exist."""
    rc, _stdout, stderr = _run_dr_drill(dr_script, ["backup", "--state-dir", "/nonexistent"])
    assert rc != 0, "Backup should fail for nonexistent dir"
    assert "ERROR" in stderr or "does not exist" in stderr


def test_restore_missing_tarball(dr_script: Path) -> None:
    """Test restore fails gracefully if tarball does not exist."""
    rc, _stdout, stderr = _run_dr_drill(dr_script, ["restore", "--tarball", "/nonexistent.tar.gz"])
    assert rc != 0, "Restore should fail for nonexistent tarball"
    assert "ERROR" in stderr or "does not exist" in stderr


def test_verify_missing_audit_db(dr_script: Path) -> None:
    """Test verify fails if audit.db is missing."""
    with tempfile.TemporaryDirectory() as tmpdir:
        state_dir = Path(tmpdir)
        (state_dir / "verdict.db").write_text("dummy")
        # audit.db is missing

        rc, _stdout, stderr = _run_dr_drill(dr_script, ["verify", "--state-dir", str(state_dir)])
        assert rc != 0, "Verify should fail if audit.db missing"
        assert "ERROR" in stderr or "audit.db" in stderr
