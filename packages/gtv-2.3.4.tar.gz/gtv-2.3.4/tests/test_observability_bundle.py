"""Validate the Grafana + Prometheus observability bundle (W35).

The bundle lives under ``deploy/observability/``. If a panel references
a metric or recording rule that doesn't exist in ``gtv.obs.metrics``
the operator hits a blank panel at 3am. These tests catch drift at
build time.

Scope:
 * Dashboard JSON is parseable and structurally sane.
 * Prometheus rule YAML is parseable and every expression references
   a metric or recording rule we actually emit.
 * docker-compose.yml is parseable and mounts the expected files.
"""

from __future__ import annotations

import json
import re
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parent.parent
BUNDLE = ROOT / "deploy" / "observability"
DASHBOARD = BUNDLE / "grafana" / "dashboards" / "gtv-overview.json"
RECORDING = BUNDLE / "prometheus" / "recording-rules.yml"
ALERTING = BUNDLE / "prometheus" / "alerting-rules.yml"
PROM_CONFIG = BUNDLE / "prometheus" / "prometheus.yml"
COMPOSE = BUNDLE / "docker-compose.yml"


# ---------------------------------------------------------------------------
# Metric surface — discover from source so tests pin to real names
# ---------------------------------------------------------------------------


def _known_metrics() -> set[str]:
    """Grep ``src/gtv/obs/metrics.py`` for the base metric names.

    A Counter declared as ``Counter("gtv_verdicts_total", ...)`` surfaces
    as ``gtv_verdicts_total`` plus the histogram-derived suffixes
    (``_bucket``, ``_count``, ``_sum``) for Histograms.
    """
    source = (ROOT / "src" / "gtv" / "obs" / "metrics.py").read_text()
    base = set(re.findall(r'"(gtv_[a-z0-9_]+)"', source))
    # Histogram children aren't explicitly declared; extend the set with
    # the canonical suffixes so references like
    # gtv_verify_duration_seconds_bucket resolve.
    histogram_names = {
        m for m in base
        if re.search(
            rf'{m}.*\n\s*"[^"]*",\n\s*\[',
            source,
        )
    } | {
        m for m in base
        if m.endswith("_seconds") or m == "gtv_evidence_count"
    }
    extended = set(base)
    for m in histogram_names:
        extended.add(f"{m}_bucket")
        extended.add(f"{m}_count")
        extended.add(f"{m}_sum")
    return extended


KNOWN_METRICS = _known_metrics()


# Recording rules the alert expressions may reference.
RECORDING_RULE_NAMES = {
    "gtv:adapter_availability:ratio_rate5m",
    "gtv:adapter_availability:ratio_rate30d",
    "gtv:verify_latency:ratio_under_budget_rate5m",
    "gtv:cache:hit_ratio_rate5m",
    "gtv:verify:rate5m",
}


def _extract_metric_refs(expr: str) -> set[str]:
    """Pull gtv_* and gtv:* identifiers out of a PromQL expression."""
    # Raw metric names are [a-zA-Z_][a-zA-Z0-9_]*; recording rule names
    # include ":" separators.
    raw = re.findall(r"\b(gtv_[a-zA-Z0-9_]+)\b", expr)
    rules = re.findall(r"\b(gtv:[a-zA-Z0-9_:]+)\b", expr)
    return set(raw) | set(rules)


# ---------------------------------------------------------------------------
# Dashboard
# ---------------------------------------------------------------------------


def test_dashboard_is_valid_json() -> None:
    dashboard = json.loads(DASHBOARD.read_text())
    assert dashboard["title"] == "gtv — overview"
    assert dashboard["uid"] == "gtv-overview"


def test_dashboard_panels_reference_known_metrics() -> None:
    dashboard = json.loads(DASHBOARD.read_text())
    for panel in dashboard["panels"]:
        if panel.get("type") == "row":
            continue  # Rows are purely structural, no targets.
        for target in panel.get("targets", []):
            expr = target.get("expr", "")
            if not expr:
                continue
            refs = _extract_metric_refs(expr)
            assert refs, f"Panel {panel['id']} has an expr with no gtv_* ref: {expr}"
            unknown = refs - KNOWN_METRICS - RECORDING_RULE_NAMES
            assert not unknown, (
                f"Panel {panel['id']} ({panel.get('title')!r}) references "
                f"unknown metrics/rules: {sorted(unknown)}"
            )


def test_dashboard_datasource_is_templated() -> None:
    """All panel targets must use ${DS_PROMETHEUS} so the JSON imports
    cleanly into any Grafana — not just one hardcoded datasource uid."""
    dashboard = json.loads(DASHBOARD.read_text())
    for panel in dashboard["panels"]:
        if panel.get("type") == "row":
            continue
        for target in panel.get("targets", []):
            ds = target.get("datasource") or {}
            assert ds.get("uid") == "${DS_PROMETHEUS}", (
                f"Panel {panel['id']} target {target.get('refId')} "
                f"hardcodes datasource: {ds}"
            )


def test_dashboard_has_all_expected_rows() -> None:
    dashboard = json.loads(DASHBOARD.read_text())
    rows = {p["title"] for p in dashboard["panels"] if p.get("type") == "row"}
    assert rows == {"Top-line SLIs", "Adapters", "Tenants", "Redaction / PII"}


# ---------------------------------------------------------------------------
# Prometheus rule files
# ---------------------------------------------------------------------------


def test_recording_rules_reference_known_metrics() -> None:
    doc = yaml.safe_load(RECORDING.read_text())
    for group in doc["groups"]:
        for rule in group["rules"]:
            refs = _extract_metric_refs(rule["expr"])
            unknown = refs - KNOWN_METRICS - RECORDING_RULE_NAMES
            assert not unknown, (
                f"Recording rule {rule['record']} references unknown: {sorted(unknown)}"
            )


def test_recording_rule_names_match_fixture() -> None:
    """Pin the set of recording rules we publish so alerting rules that
    reference them fail tests if a rule is renamed without its callers."""
    doc = yaml.safe_load(RECORDING.read_text())
    published = {
        rule["record"] for group in doc["groups"] for rule in group["rules"]
    }
    assert published == RECORDING_RULE_NAMES


def test_alerting_rules_reference_known_metrics_or_rules() -> None:
    doc = yaml.safe_load(ALERTING.read_text())
    for group in doc["groups"]:
        for rule in group["rules"]:
            refs = _extract_metric_refs(rule["expr"])
            unknown = refs - KNOWN_METRICS - RECORDING_RULE_NAMES
            assert not unknown, (
                f"Alert {rule['alert']} references unknown: {sorted(unknown)}"
            )


def test_alerting_rules_have_severity_and_runbook() -> None:
    """Every alert must carry a severity label and a runbook link — an
    unannotated page at 3am is worse than no page."""
    doc = yaml.safe_load(ALERTING.read_text())
    for group in doc["groups"]:
        for rule in group["rules"]:
            labels = rule.get("labels") or {}
            annotations = rule.get("annotations") or {}
            assert labels.get("severity") in {"critical", "warning", "info"}, rule["alert"]
            assert "runbook" in annotations or "summary" in annotations, rule["alert"]
            assert "description" in annotations, rule["alert"]


def test_alerts_cover_three_slos() -> None:
    """Spec: we promise three SLO alerts (integrity, availability,
    latency). Rename here if the SLO doc moves."""
    doc = yaml.safe_load(ALERTING.read_text())
    slos = {
        rule["labels"]["slo"]
        for group in doc["groups"]
        for rule in group["rules"]
        if rule.get("labels", {}).get("slo")
    }
    assert {"integrity", "availability", "latency"}.issubset(slos)


def test_prometheus_config_loads_both_rule_files() -> None:
    doc = yaml.safe_load(PROM_CONFIG.read_text())
    assert doc["rule_files"] == ["recording-rules.yml", "alerting-rules.yml"]
    # One scrape job named "gtv" pointed at /metrics
    jobs = {j["job_name"]: j for j in doc["scrape_configs"]}
    assert "gtv" in jobs
    assert jobs["gtv"]["metrics_path"] == "/metrics"


# ---------------------------------------------------------------------------
# docker-compose
# ---------------------------------------------------------------------------


def test_compose_file_mounts_rules_and_dashboard() -> None:
    doc = yaml.safe_load(COMPOSE.read_text())
    assert "prometheus" in doc["services"]
    assert "grafana" in doc["services"]

    prom = doc["services"]["prometheus"]
    mounts = " ".join(prom["volumes"])
    assert "prometheus.yml" in mounts
    assert "recording-rules.yml" in mounts
    assert "alerting-rules.yml" in mounts

    graf = doc["services"]["grafana"]
    mounts = " ".join(graf["volumes"])
    assert "provisioning" in mounts
    assert "dashboards" in mounts
