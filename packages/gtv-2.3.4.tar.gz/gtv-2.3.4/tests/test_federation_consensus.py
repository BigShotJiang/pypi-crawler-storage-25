"""Tests for multi-verifier consensus voting.

Tests the federated-verifier quorum mechanism: tier-weighted majority voting
over multiple signed envelopes for the same claim.
"""
from __future__ import annotations

from datetime import UTC, datetime

import pytest

from gtv.federation.consensus import Tally, compute_consensus
from gtv.federation.registry import IssuerRegistry, TrustedIssuer
from gtv.models import AnchorProof, Envelope, Evidence, Stance, TrustTier, Verdict


def _make_envelope(
    verdict: Verdict,
    issuer_did: str,
    confidence: float = 0.9,
    claim_id: str = "test-claim-id",
) -> Envelope:
    """Helper to construct a minimal test Envelope."""
    return Envelope(
        verdict=verdict,
        confidence=confidence,
        evidence=[
            Evidence(
                claim_id=claim_id,
                source_did="did:source",
                source_version="1.0",
                stance=Stance.SUPPORTS,
                excerpt="test excerpt",
                url="https://example.com",
                retrieved_at=datetime.now(tz=UTC),
                raw_hash="0" * 64,
            )
        ],
        rationale="test",
        issuer_did=issuer_did,
        signature="stub://sig",
        rekor_uuid="test-uuid",
        rekor_log_index=0,
        tsa_token="stub://tsa",
        prov_graph="{}",
        anchor_proof=AnchorProof(
            rekor_inclusion_proof="stub://proof",
            tsa_tsr_primary="stub://tsa",
        ),
    )


class TestComputeConsensus:
    """Tests for compute_consensus function."""

    def test_empty_envelopes_raises(self) -> None:
        """Empty input should raise ValueError."""
        with pytest.raises(ValueError, match="empty"):
            compute_consensus([])

    def test_single_envelope_verified(self) -> None:
        """Single VERIFIED envelope → VERIFIED verdict, confidence 1.0."""
        registry = IssuerRegistry()
        registry.add(
            TrustedIssuer(
                did="did:tier1",
                trust_tier=TrustTier.TIER_1,
                display_name="Tier 1",
            )
        )

        env = _make_envelope(Verdict.VERIFIED, "did:tier1")
        result = compute_consensus([env], registry=registry)

        assert result.verdict == Verdict.VERIFIED
        assert result.confidence == 1.0
        assert len(result.tally) == 1
        assert result.tally[0].verdict == Verdict.VERIFIED
        assert result.tally[0].weighted_votes == 3.0
        assert result.tally[0].envelope_count == 1
        assert result.unknown_dids == []

    def test_two_tier1_both_verified(self) -> None:
        """Two TIER_1 VERIFIED envelopes → VERIFIED, confidence 1.0."""
        registry = IssuerRegistry()
        registry.add(
            TrustedIssuer(
                did="did:tier1a",
                trust_tier=TrustTier.TIER_1,
                display_name="Tier 1 A",
            )
        )
        registry.add(
            TrustedIssuer(
                did="did:tier1b",
                trust_tier=TrustTier.TIER_1,
                display_name="Tier 1 B",
            )
        )

        env1 = _make_envelope(Verdict.VERIFIED, "did:tier1a")
        env2 = _make_envelope(Verdict.VERIFIED, "did:tier1b")
        result = compute_consensus([env1, env2], registry=registry)

        assert result.verdict == Verdict.VERIFIED
        assert result.confidence == 1.0
        # Total weight = 3.0 + 3.0 = 6.0, VERIFIED gets all 6.0
        assert result.tally[0].weighted_votes == 6.0
        assert result.tally[0].envelope_count == 2

    def test_tier1_vs_tier3_conflict_tier1_wins(self) -> None:
        """TIER_1 VERIFIED + TIER_3 UNVERIFIED → VERIFIED (3.0 > 1.0)."""
        registry = IssuerRegistry()
        registry.add(
            TrustedIssuer(
                did="did:tier1",
                trust_tier=TrustTier.TIER_1,
                display_name="Tier 1",
            )
        )
        registry.add(
            TrustedIssuer(
                did="did:tier3",
                trust_tier=TrustTier.TIER_3,
                display_name="Tier 3",
            )
        )

        env_verified = _make_envelope(Verdict.VERIFIED, "did:tier1")
        env_unverified = _make_envelope(Verdict.UNVERIFIED, "did:tier3")
        result = compute_consensus([env_verified, env_unverified], registry=registry)

        assert result.verdict == Verdict.VERIFIED
        assert result.confidence == pytest.approx(3.0 / 4.0, abs=0.01)
        # Tally: VERIFIED (3.0), UNVERIFIED (1.0)
        assert result.tally[0].verdict == Verdict.VERIFIED
        assert result.tally[0].weighted_votes == 3.0
        assert result.tally[1].verdict == Verdict.UNVERIFIED
        assert result.tally[1].weighted_votes == 1.0

    def test_equal_weight_tie_becomes_contested(self) -> None:
        """TIER_1 VERIFIED + TIER_1 UNVERIFIED → CONTESTED (both 3.0)."""
        registry = IssuerRegistry()
        registry.add(
            TrustedIssuer(
                did="did:tier1a",
                trust_tier=TrustTier.TIER_1,
                display_name="Tier 1 A",
            )
        )
        registry.add(
            TrustedIssuer(
                did="did:tier1b",
                trust_tier=TrustTier.TIER_1,
                display_name="Tier 1 B",
            )
        )

        env_verified = _make_envelope(Verdict.VERIFIED, "did:tier1a")
        env_unverified = _make_envelope(Verdict.UNVERIFIED, "did:tier1b")
        result = compute_consensus([env_verified, env_unverified], registry=registry)

        assert result.verdict == Verdict.CONTESTED
        # In a tie, both have 3.0, so confidence is max(3.0) / total(6.0)
        assert result.confidence == pytest.approx(0.5, abs=0.01)

    def test_unknown_issuer_gets_minimum_weight(self) -> None:
        """Unknown issuer DID gets 0.1 weight and is recorded."""
        registry = IssuerRegistry()
        registry.add(
            TrustedIssuer(
                did="did:tier1",
                trust_tier=TrustTier.TIER_1,
                display_name="Tier 1",
            )
        )

        env_known = _make_envelope(Verdict.VERIFIED, "did:tier1")
        env_unknown = _make_envelope(Verdict.UNVERIFIED, "did:unknown")
        result = compute_consensus([env_known, env_unknown], registry=registry)

        # VERIFIED: 3.0, UNVERIFIED: 0.1 → VERIFIED wins
        assert result.verdict == Verdict.VERIFIED
        assert result.confidence == pytest.approx(3.0 / 3.1, abs=0.01)
        assert result.unknown_dids == ["did:unknown"]

    def test_mismatched_claim_ids_raises(self) -> None:
        """Different claim_ids → raises ValueError."""
        registry = IssuerRegistry()
        registry.add(
            TrustedIssuer(
                did="did:tier1a",
                trust_tier=TrustTier.TIER_1,
                display_name="Tier 1 A",
            )
        )
        registry.add(
            TrustedIssuer(
                did="did:tier1b",
                trust_tier=TrustTier.TIER_1,
                display_name="Tier 1 B",
            )
        )

        env1 = _make_envelope(Verdict.VERIFIED, "did:tier1a", claim_id="claim-1")
        env2 = _make_envelope(Verdict.VERIFIED, "did:tier1b", claim_id="claim-2")

        with pytest.raises(ValueError, match="Not all envelopes have the same claim"):
            compute_consensus([env1, env2], registry=registry)

    def test_default_registry_used_when_none_provided(self) -> None:
        """compute_consensus uses DEFAULT_REGISTRY if registry=None."""
        env = _make_envelope(Verdict.VERIFIED, "did:web:verify.groundtruth.example")
        result = compute_consensus([env])

        assert result.verdict == Verdict.VERIFIED
        assert result.confidence == 1.0
        assert result.unknown_dids == []

    def test_tally_sorted_by_weight_descending(self) -> None:
        """Tally is sorted by weighted_votes descending."""
        registry = IssuerRegistry()
        registry.add(
            TrustedIssuer(
                did="did:tier1",
                trust_tier=TrustTier.TIER_1,
                display_name="Tier 1",
            )
        )
        registry.add(
            TrustedIssuer(
                did="did:tier2",
                trust_tier=TrustTier.TIER_2,
                display_name="Tier 2",
            )
        )
        registry.add(
            TrustedIssuer(
                did="did:tier3",
                trust_tier=TrustTier.TIER_3,
                display_name="Tier 3",
            )
        )

        env1 = _make_envelope(Verdict.VERIFIED, "did:tier1")
        env2 = _make_envelope(Verdict.UNVERIFIED, "did:tier2")
        env3 = _make_envelope(Verdict.OPINION, "did:tier3")
        result = compute_consensus([env1, env2, env3], registry=registry)

        # Weights: VERIFIED=3.0, UNVERIFIED=2.0, OPINION=1.0
        assert result.tally[0].verdict == Verdict.VERIFIED
        assert result.tally[0].weighted_votes == 3.0
        assert result.tally[1].verdict == Verdict.UNVERIFIED
        assert result.tally[1].weighted_votes == 2.0
        assert result.tally[2].verdict == Verdict.OPINION
        assert result.tally[2].weighted_votes == 1.0

    def test_three_way_voting(self) -> None:
        """Test with three different verdicts."""
        registry = IssuerRegistry()
        for i in range(3):
            registry.add(
                TrustedIssuer(
                    did=f"did:tier1-{i}",
                    trust_tier=TrustTier.TIER_1,
                    display_name=f"Tier 1 {i}",
                )
            )

        env1 = _make_envelope(Verdict.VERIFIED, "did:tier1-0")
        env2 = _make_envelope(Verdict.UNVERIFIED, "did:tier1-1")
        env3 = _make_envelope(Verdict.CONTESTED, "did:tier1-2")
        result = compute_consensus([env1, env2, env3], registry=registry)

        # All tied at 3.0, so result is CONTESTED
        assert result.verdict == Verdict.CONTESTED
        assert result.confidence == pytest.approx(3.0 / 9.0, abs=0.01)

    def test_confidence_clamping(self) -> None:
        """Confidence is clamped to [0.0, 1.0]."""
        registry = IssuerRegistry()
        registry.add(
            TrustedIssuer(
                did="did:tier1",
                trust_tier=TrustTier.TIER_1,
                display_name="Tier 1",
            )
        )

        env = _make_envelope(Verdict.VERIFIED, "did:tier1")
        result = compute_consensus([env], registry=registry)

        assert 0.0 <= result.confidence <= 1.0
        assert result.confidence == 1.0

    def test_multiple_unknowns_all_recorded(self) -> None:
        """Multiple unknown issuers are all recorded in unknown_dids."""
        registry = IssuerRegistry()
        registry.add(
            TrustedIssuer(
                did="did:tier1",
                trust_tier=TrustTier.TIER_1,
                display_name="Tier 1",
            )
        )

        env1 = _make_envelope(Verdict.VERIFIED, "did:unknown1")
        env2 = _make_envelope(Verdict.VERIFIED, "did:unknown2")
        env3 = _make_envelope(Verdict.VERIFIED, "did:tier1")
        result = compute_consensus([env1, env2, env3], registry=registry)

        # All three VERIFIED: weight = 0.1 + 0.1 + 3.0 = 3.2
        # Confidence = 3.2 / 3.2 = 1.0
        assert result.verdict == Verdict.VERIFIED
        assert result.confidence == 1.0
        assert set(result.unknown_dids) == {"did:unknown1", "did:unknown2"}

    def test_consensus_result_immutable(self) -> None:
        """ConsensusResult is a frozen dataclass."""
        registry = IssuerRegistry()
        registry.add(
            TrustedIssuer(
                did="did:tier1",
                trust_tier=TrustTier.TIER_1,
                display_name="Tier 1",
            )
        )

        env = _make_envelope(Verdict.VERIFIED, "did:tier1")
        result = compute_consensus([env], registry=registry)

        # Should not be able to mutate.
        with pytest.raises(AttributeError):
            result.verdict = Verdict.UNVERIFIED  # type: ignore

    def test_tally_is_named_tuple(self) -> None:
        """Tally elements have verdict, weighted_votes, envelope_count."""
        registry = IssuerRegistry()
        registry.add(
            TrustedIssuer(
                did="did:tier1",
                trust_tier=TrustTier.TIER_1,
                display_name="Tier 1",
            )
        )

        env = _make_envelope(Verdict.VERIFIED, "did:tier1")
        result = compute_consensus([env], registry=registry)

        tally_item = result.tally[0]
        assert isinstance(tally_item, Tally)
        assert tally_item.verdict == Verdict.VERIFIED
        assert tally_item.weighted_votes == 3.0
        assert tally_item.envelope_count == 1
