"""Smoke test for Docker image build and runtime.

This test is gated on GTV_DOCKER=1 and is intended to run in release/nightly CI,
not in the standard PR test suite. It verifies that:
  - docker build succeeds
  - docker run boots the container
  - /health endpoint returns 200 with status=ok
"""
from __future__ import annotations

import json
import os
import subprocess
import time
from typing import Any

import pytest

pytestmark = pytest.mark.skipif(
    os.getenv("GTV_DOCKER") != "1",
    reason="Docker smoke test requires GTV_DOCKER=1 (release/nightly CI only)",
)


@pytest.fixture
def docker_image() -> str:
    """Build Docker image and return its tag."""
    image_tag = "gtv:smoke-test"
    result = subprocess.run(
        ["docker", "build", "-t", image_tag, "."],
        cwd=".",
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, f"docker build failed: {result.stderr}"
    return image_tag


def test_docker_build_succeeds(docker_image: str) -> None:
    """Verify docker build succeeded."""
    result = subprocess.run(
        ["docker", "image", "ls", docker_image],
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, f"docker image not found: {docker_image}"


def test_docker_run_and_health(docker_image: str) -> None:
    """Verify docker run boots and /health returns 200 with status=ok."""
    # Start container in background
    container_result = subprocess.run(
        [
            "docker",
            "run",
            "--rm",
            "-d",
            "-p",
            "18080:8080",
            docker_image,
        ],
        capture_output=True,
        text=True,
    )
    assert container_result.returncode == 0, f"docker run failed: {container_result.stderr}"
    container_id = container_result.stdout.strip()

    try:
        # Wait for container to be ready
        max_retries = 30
        for _attempt in range(max_retries):
            result = subprocess.run(
                ["curl", "-sf", "http://localhost:18080/health"],
                capture_output=True,
                text=True,
            )
            if result.returncode == 0:
                # Parse JSON response
                response: dict[str, Any] = json.loads(result.stdout)
                assert response.get("status") == "ok", f"Unexpected status: {response}"
                return
            time.sleep(0.5)

        pytest.fail(f"Health check failed after {max_retries} retries")
    finally:
        # Stop container
        subprocess.run(
            ["docker", "stop", container_id],
            capture_output=True,
        )
