"""Tests for the agent-framework bindings.

Two kinds of tests live here:

1. Static shape tests — assert the tool specs match what each
   framework expects. No network, no external SDKs.
2. Dispatch tests — exercise the HTTP client against a ``respx``-mocked
   server to prove the OpenAI/Anthropic ``dispatch`` helpers correctly
   route tool calls to the gtv endpoints.

LangChain is optional (not a test dep) so we only import-check it.
"""
from __future__ import annotations

import json
from typing import Any

import httpx
import pytest
import respx

from gtv.bindings import GtvClient, GtvHttpError, anthropic_tools, openai_tools

# ---------------------------------------------------------------------
# Static tool-spec shape
# ---------------------------------------------------------------------


def test_openai_tool_spec_is_function_calling_shape() -> None:
    """OpenAI tool spec: top-level type=function, nested function dict."""
    for tool in openai_tools.TOOLS:
        assert tool["type"] == "function"
        assert "function" in tool
        fn = tool["function"]
        assert "name" in fn
        assert "description" in fn
        assert fn["parameters"]["type"] == "object"
        assert "properties" in fn["parameters"]
        assert "required" in fn["parameters"]


def test_openai_tools_include_both_endpoints() -> None:
    """Both verify_claim and retrieve_facts must be advertised."""
    names = {t["function"]["name"] for t in openai_tools.TOOLS}
    assert names == {"verify_claim", "retrieve_facts"}


def test_anthropic_tool_spec_is_flat_shape() -> None:
    """Anthropic tool spec: flat with name/description/input_schema."""
    for tool in anthropic_tools.TOOLS:
        assert "name" in tool
        assert "description" in tool
        assert "input_schema" in tool
        assert tool["input_schema"]["type"] == "object"
        assert "properties" in tool["input_schema"]
        assert "required" in tool["input_schema"]


def test_anthropic_tools_include_both_endpoints() -> None:
    names = {t["name"] for t in anthropic_tools.TOOLS}
    assert names == {"verify_claim", "retrieve_facts"}


def test_openai_and_anthropic_agree_on_required_fields() -> None:
    """Both bindings must require 'claim' for verify and 'query' for facts."""
    for tool in openai_tools.TOOLS:
        fn = tool["function"]
        if fn["name"] == "verify_claim":
            assert "claim" in fn["parameters"]["required"]
        if fn["name"] == "retrieve_facts":
            assert "query" in fn["parameters"]["required"]
    for tool in anthropic_tools.TOOLS:
        if tool["name"] == "verify_claim":
            assert "claim" in tool["input_schema"]["required"]
        if tool["name"] == "retrieve_facts":
            assert "query" in tool["input_schema"]["required"]


# ---------------------------------------------------------------------
# GtvClient smoke
# ---------------------------------------------------------------------


_FAKE_ENVELOPE: dict[str, Any] = {
    "envelope_id": "env-1",
    "verdict": "VERIFIED",
    "confidence": 0.9,
    "evidence": [],
    "issuer_did": "did:web:test",
    "signature": "sig",
    "rekor_uuid": "uuid",
    "rekor_log_index": 0,
    "tsa_token": "tok",
    "prov_graph": "{}",
    "anchor_proof": {
        "rekor_inclusion_proof": "pf",
        "tsa_tsr_primary": "tsr",
    },
}


@pytest.mark.asyncio
async def test_client_verify_claim_posts_expected_body() -> None:
    async with respx.mock(base_url="http://gtv") as r:
        route = r.post("/tools/verify_claim").mock(
            return_value=httpx.Response(200, json={"envelope": _FAKE_ENVELOPE})
        )
        async with GtvClient("http://gtv") as c:
            env = await c.verify_claim("the sky is blue", domain="general")
        assert env == _FAKE_ENVELOPE
        assert route.called
        req = route.calls.last.request
        body = json.loads(req.content)
        assert body["claim"] == "the sky is blue"
        assert body["domain"] == "general"
        # Defaults come through
        assert body["max_sources"] == 5


@pytest.mark.asyncio
async def test_client_sends_bearer_token_when_api_key_set() -> None:
    async with respx.mock(base_url="http://gtv") as r:
        route = r.post("/tools/verify_claim").mock(
            return_value=httpx.Response(200, json={"envelope": _FAKE_ENVELOPE})
        )
        async with GtvClient("http://gtv", api_key="secret") as c:
            await c.verify_claim("x")
        auth = route.calls.last.request.headers.get("authorization")
        assert auth == "Bearer secret"


@pytest.mark.asyncio
async def test_client_omits_bearer_when_api_key_none() -> None:
    async with respx.mock(base_url="http://gtv") as r:
        route = r.post("/tools/verify_claim").mock(
            return_value=httpx.Response(200, json={"envelope": _FAKE_ENVELOPE})
        )
        async with GtvClient("http://gtv") as c:
            await c.verify_claim("x")
        assert "authorization" not in {k.lower() for k in route.calls.last.request.headers}


@pytest.mark.asyncio
async def test_client_raises_on_http_error() -> None:
    async with respx.mock(base_url="http://gtv") as r:
        r.post("/tools/verify_claim").mock(
            return_value=httpx.Response(503, text="no adapters")
        )
        async with GtvClient("http://gtv") as c:
            with pytest.raises(GtvHttpError) as excinfo:
                await c.verify_claim("x")
        assert excinfo.value.status == 503
        assert "no adapters" in excinfo.value.body


@pytest.mark.asyncio
async def test_client_retrieve_facts_and_consensus() -> None:
    async with respx.mock(base_url="http://gtv") as r:
        r.post("/tools/retrieve_facts").mock(
            return_value=httpx.Response(200, json={"facts": []})
        )
        r.post("/consensus").mock(
            return_value=httpx.Response(200, json={"verdict": "VERIFIED"})
        )
        async with GtvClient("http://gtv") as c:
            facts = await c.retrieve_facts("higgs boson")
            cons = await c.consensus([])
        assert facts == {"facts": []}
        assert cons == {"verdict": "VERIFIED"}


# ---------------------------------------------------------------------
# OpenAI / Anthropic dispatch
# ---------------------------------------------------------------------


@pytest.mark.asyncio
async def test_openai_dispatch_routes_verify_claim() -> None:
    async with respx.mock(base_url="http://gtv") as r:
        r.post("/tools/verify_claim").mock(
            return_value=httpx.Response(200, json={"envelope": _FAKE_ENVELOPE})
        )
        async with GtvClient("http://gtv") as c:
            # OpenAI passes arguments as a JSON string
            result = await openai_tools.dispatch(
                c, "verify_claim", json.dumps({"claim": "x"})
            )
        assert result == _FAKE_ENVELOPE


@pytest.mark.asyncio
async def test_openai_dispatch_accepts_dict_arguments() -> None:
    async with respx.mock(base_url="http://gtv") as r:
        r.post("/tools/verify_claim").mock(
            return_value=httpx.Response(200, json={"envelope": _FAKE_ENVELOPE})
        )
        async with GtvClient("http://gtv") as c:
            result = await openai_tools.dispatch(c, "verify_claim", {"claim": "x"})
        assert result == _FAKE_ENVELOPE


@pytest.mark.asyncio
async def test_openai_dispatch_rejects_unknown_tool() -> None:
    async with GtvClient("http://gtv") as c:
        with pytest.raises(ValueError, match="unknown gtv tool"):
            await openai_tools.dispatch(c, "launch_nuke", "{}")


@pytest.mark.asyncio
async def test_openai_dispatch_rejects_invalid_json() -> None:
    async with GtvClient("http://gtv") as c:
        with pytest.raises(ValueError, match="invalid tool arguments"):
            await openai_tools.dispatch(c, "verify_claim", "{not json")


@pytest.mark.asyncio
async def test_anthropic_dispatch_routes_verify_claim() -> None:
    async with respx.mock(base_url="http://gtv") as r:
        r.post("/tools/verify_claim").mock(
            return_value=httpx.Response(200, json={"envelope": _FAKE_ENVELOPE})
        )
        async with GtvClient("http://gtv") as c:
            result = await anthropic_tools.dispatch(c, "verify_claim", {"claim": "x"})
        assert result == _FAKE_ENVELOPE


@pytest.mark.asyncio
async def test_anthropic_dispatch_rejects_unknown_tool() -> None:
    async with GtvClient("http://gtv") as c:
        with pytest.raises(ValueError, match="unknown gtv tool"):
            await anthropic_tools.dispatch(c, "launch_nuke", {})


# ---------------------------------------------------------------------
# LangChain binding (optional dep)
# ---------------------------------------------------------------------


def test_langchain_raises_clear_error_when_langchain_not_installed() -> None:
    """If langchain_core isn't installed, the factory must raise ImportError."""
    # Both states are acceptable: either langchain_core is installed (binding
    # works) or it isn't (must raise with a helpful message). Test covers the
    # second path by mocking the import.
    import sys
    import types

    from gtv.bindings import langchain as gtv_lc

    saved = sys.modules.pop("langchain_core", None)
    saved_tools = sys.modules.pop("langchain_core.tools", None)
    # Poison the import so `import langchain_core.tools` fails.
    blocker = types.ModuleType("langchain_core")
    sys.modules["langchain_core"] = blocker  # has no `tools` attr
    try:
        with pytest.raises(ImportError, match="langchain_core is required"):
            gtv_lc.make_verify_claim_tool()
    finally:
        # Restore real state
        if saved is not None:
            sys.modules["langchain_core"] = saved
        else:
            sys.modules.pop("langchain_core", None)
        if saved_tools is not None:
            sys.modules["langchain_core.tools"] = saved_tools
