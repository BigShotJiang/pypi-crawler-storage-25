"""RFC 8785 canonical JSON — bit-exact reproducibility is a hard requirement."""
from __future__ import annotations

import pytest

from gtv.anchor.canonicalize import canonicalize, sha256


def test_key_order_is_lexicographic() -> None:
    a = {"b": 1, "a": 2}
    b = {"a": 2, "b": 1}
    assert canonicalize(a) == canonicalize(b)
    assert canonicalize(a) == b'{"a":2,"b":1}'


def test_nested_structures_are_stable() -> None:
    payload = {"z": [3, 1, 2], "a": {"y": 1, "x": 2}}
    out = canonicalize(payload)
    assert out == b'{"a":{"x":2,"y":1},"z":[3,1,2]}'


def test_unicode_preserved_not_escaped() -> None:
    out = canonicalize({"name": "µ-meson"})
    assert out == '{"name":"µ-meson"}'.encode()


def test_nan_and_inf_rejected() -> None:
    import math
    with pytest.raises(ValueError):
        canonicalize({"p": math.nan})
    with pytest.raises(ValueError):
        canonicalize({"p": math.inf})


def test_integer_floats_coerced_to_int() -> None:
    assert canonicalize({"n": 2.0}) == b'{"n":2}'


def test_finite_floats_serialise_deterministically() -> None:
    # Python's shortest round-trip repr is stable across CPython 3.12+.
    # Canonicalising the same float twice must produce identical bytes.
    assert canonicalize({"c": 0.9}) == canonicalize({"c": 0.9})
    assert canonicalize({"c": 0.9}) == b'{"c":0.9}'


def test_sha256_deterministic() -> None:
    payload = {"hello": "world"}
    assert sha256(canonicalize(payload)) == sha256(canonicalize({"hello": "world"}))
