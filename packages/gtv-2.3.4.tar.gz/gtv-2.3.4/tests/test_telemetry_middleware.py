"""Tests for TelemetryMiddleware."""
from __future__ import annotations

import pytest
from fastapi import FastAPI
from starlette.testclient import TestClient

from gtv.telemetry.metrics import (
    gtv_errors_total,
    gtv_request_duration_seconds,
    gtv_requests_total,
)
from gtv.telemetry.middleware import TelemetryMiddleware


@pytest.fixture
def app():
    """Create a test FastAPI app with TelemetryMiddleware."""
    test_app = FastAPI()
    test_app.add_middleware(TelemetryMiddleware)

    @test_app.get("/test")
    async def test_endpoint():
        return {"status": "ok"}

    @test_app.get("/error")
    async def error_endpoint():
        raise RuntimeError("Test error")

    @test_app.get("/server-error")
    async def server_error_endpoint():
        from fastapi import Response
        return Response(status_code=500)

    return test_app


def test_middleware_logs_request(app: FastAPI):
    """Test that middleware logs requests."""
    client = TestClient(app)

    # Make a request
    response = client.get("/test")
    assert response.status_code == 200


def test_middleware_increments_request_counter(app: FastAPI):
    """Test that successful request increments gtv_requests_total."""
    client = TestClient(app)

    # Get initial count
    initial = gtv_requests_total.labels(endpoint="/test", status="200")._value.get()

    # Make request
    response = client.get("/test")
    assert response.status_code == 200

    # Verify counter incremented
    after = gtv_requests_total.labels(endpoint="/test", status="200")._value.get()
    assert after > initial


def test_middleware_increments_error_counter(app: FastAPI):
    """Test that 5xx response increments gtv_errors_total."""
    client = TestClient(app)

    initial = gtv_errors_total.labels(endpoint="/server-error", error_type="server_error")._value.get()

    response = client.get("/server-error")
    assert response.status_code == 500

    after = gtv_errors_total.labels(endpoint="/server-error", error_type="server_error")._value.get()
    assert after > initial


def test_middleware_observes_duration_histogram(app: FastAPI):
    """Test that middleware observes request duration in histogram."""
    client = TestClient(app)

    initial_sum = gtv_request_duration_seconds.labels(endpoint="/test")._sum.get()

    response = client.get("/test")
    assert response.status_code == 200

    after_sum = gtv_request_duration_seconds.labels(endpoint="/test")._sum.get()
    assert after_sum > initial_sum


def test_middleware_handles_exception(app: FastAPI):
    """Test that middleware records error on exception."""
    client = TestClient(app)

    initial = gtv_errors_total.labels(endpoint="/error", error_type="RuntimeError")._value.get()

    # This should raise an error (TestClient doesn't swallow them)
    with pytest.raises(RuntimeError):
        client.get("/error")

    after = gtv_errors_total.labels(endpoint="/error", error_type="RuntimeError")._value.get()
    assert after > initial


def test_middleware_request_and_error_both_recorded(app: FastAPI):
    """Test that both request counter and error counter are incremented on 5xx."""
    client = TestClient(app)

    req_initial = gtv_requests_total.labels(endpoint="/server-error", status="500")._value.get()
    err_initial = gtv_errors_total.labels(endpoint="/server-error", error_type="server_error")._value.get()

    response = client.get("/server-error")
    assert response.status_code == 500

    req_after = gtv_requests_total.labels(endpoint="/server-error", status="500")._value.get()
    err_after = gtv_errors_total.labels(endpoint="/server-error", error_type="server_error")._value.get()

    assert req_after > req_initial
    assert err_after > err_initial


def test_middleware_duration_non_negative(app: FastAPI):
    """Test that observed duration is non-negative."""
    client = TestClient(app)

    # Make request; duration should be >= 0
    response = client.get("/test")
    assert response.status_code == 200

    # Histogram sum should be non-negative (always true)
    histogram_sum = gtv_request_duration_seconds.labels(endpoint="/test")._sum.get()
    assert histogram_sum >= 0
