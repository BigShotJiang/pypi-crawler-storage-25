"""RFC 6962 merkle tree verification tests."""
from __future__ import annotations

import hashlib

import pytest

from gtv.cli.verify import _merkle_hash, _verify_inclusion


def _leaf_hash(data: bytes) -> bytes:
    """Compute RFC 6962 leaf hash: sha256(0x00 || data)."""
    return hashlib.sha256(b"\x00" + data).digest()


def _parent_hash(left: bytes, right: bytes) -> bytes:
    """Compute RFC 6962 parent hash: sha256(0x01 || left || right)."""
    return _merkle_hash(left, right)


def test_single_leaf() -> None:
    """Single leaf tree: leaf 0 at index 0, tree_size=1."""
    leaf = _leaf_hash(b"a")
    root = _verify_inclusion(leaf, 0, 1, [])
    assert root == leaf


def test_two_leaves_index_0() -> None:
    """Two leaf tree: proving leaf 0."""
    l0 = _leaf_hash(b"a")
    l1 = _leaf_hash(b"b")
    expected_root = _parent_hash(l0, l1)
    computed_root = _verify_inclusion(l0, 0, 2, [l1.hex()])
    assert computed_root == expected_root


def test_two_leaves_index_1() -> None:
    """Two leaf tree: proving leaf 1."""
    l0 = _leaf_hash(b"a")
    l1 = _leaf_hash(b"b")
    expected_root = _parent_hash(l0, l1)
    computed_root = _verify_inclusion(l1, 1, 2, [l0.hex()])
    assert computed_root == expected_root


def test_four_leaves_index_0() -> None:
    """Four leaf tree (full binary): proving leaf 0."""
    l0 = _leaf_hash(b"a")
    l1 = _leaf_hash(b"b")
    l2 = _leaf_hash(b"c")
    l3 = _leaf_hash(b"d")
    p0_1 = _parent_hash(l0, l1)
    p2_3 = _parent_hash(l2, l3)
    expected_root = _parent_hash(p0_1, p2_3)
    computed_root = _verify_inclusion(l0, 0, 4, [l1.hex(), p2_3.hex()])
    assert computed_root == expected_root


def test_four_leaves_index_2() -> None:
    """Four leaf tree (full binary): proving leaf 2."""
    l0 = _leaf_hash(b"a")
    l1 = _leaf_hash(b"b")
    l2 = _leaf_hash(b"c")
    l3 = _leaf_hash(b"d")
    p0_1 = _parent_hash(l0, l1)
    p2_3 = _parent_hash(l2, l3)
    expected_root = _parent_hash(p0_1, p2_3)
    computed_root = _verify_inclusion(l2, 2, 4, [l3.hex(), p0_1.hex()])
    assert computed_root == expected_root


def test_merkle_invalid_proof_hex() -> None:
    """Invalid hex in proof hashes should raise ValueError.

    After routing through sigstore's Trillian impl, the error surfaces from
    `bytes.fromhex` rather than from a custom "Invalid hex" message — either
    way it's a ValueError and fails closed.
    """
    l0 = _leaf_hash(b"a")
    with pytest.raises(ValueError, match=r"non-hexadecimal|Invalid hex"):
        _verify_inclusion(l0, 0, 2, ["not_valid_hex"])


def test_merkle_proof_wrong_hash_length() -> None:
    """Proof hash with incorrect length yields a root mismatch downstream.

    The old naive walk rejected non-32-byte hashes explicitly. The Trillian
    impl doesn't validate hash length — it produces a bogus root that fails
    the caller's `computed_root != expected_root` check. Test the end-to-end
    behaviour: wrong-length hash produces a root that doesn't match the real
    one.
    """
    l0 = _leaf_hash(b"a")
    # Tree of 2 leaves, log_index 0: proof should be [sibling(32 bytes)]. A
    # 4-byte hash produces a wildly different "root".
    short_hash = "deadbeef"
    result = _verify_inclusion(l0, 0, 2, [short_hash])
    # Whatever came out, it's NOT a valid root for this tree. 32 bytes of
    # sha256 output from garbage input.
    assert len(result) == 32
    # And it won't match a legitimate root built from a real 32-byte sibling.
    proper_sibling = _leaf_hash(b"b")
    proper_root = _verify_inclusion(l0, 0, 2, [proper_sibling.hex()])
    assert result != proper_root


def test_merkle_proof_index_out_of_range() -> None:
    """Index >= tree_size should raise ValueError."""
    leaf = _leaf_hash(b"a")
    with pytest.raises(ValueError, match="out of range"):
        _verify_inclusion(leaf, 5, 3, [])
