"""Federation deployment tests (W32).

Covers the new plumbing:
  * ``load_peers_from_env`` env-var parsing (good + malformed).
  * ``fetch_peer_envelope`` over an httpx.MockTransport mimicking a peer.
  * ``POST /federation/consensus`` fan-out, including partial failure
    and the "all legs failed" path.

There is also a docker-compose smoke test guarded by ``GTV_FEDERATION_E2E=1``
— see ``deploy/federation/README.md``. It spins two real containers
and is opt-in for release/nightly CI; it would take CI from 36s to
a few minutes otherwise.
"""
from __future__ import annotations

import os
from collections.abc import Generator
from datetime import UTC, datetime
from typing import Any

import httpx
import pytest
from fastapi.testclient import TestClient
from pydantic import HttpUrl

from gtv.adapters import REGISTRY
from gtv.adapters.base import HealthStatus, RawSnapshot, SourceAdapter
from gtv.cache import InMemoryCacheStore, VerdictCache
from gtv.federation.peer import (
    FederationPeer,
    fetch_peer_envelope,
    load_peers_from_env,
)
from gtv.lifecycle import LifecycleIndex
from gtv.models import (
    AnchorProof,
    Claim,
    Envelope,
    Evidence,
    SourceType,
    Stance,
    TrustTier,
    Verdict,
)

# ---------------------------------------------------------------------------
# load_peers_from_env
# ---------------------------------------------------------------------------


def test_load_peers_unset_returns_empty(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("GTV_FEDERATION_PEERS", raising=False)
    assert load_peers_from_env() == []


def test_load_peers_parses_did_url_key(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv(
        "GTV_FEDERATION_PEERS",
        "did:web:alice.example|http://alice:8080|key-a,"
        "did:web:bob.example|http://bob:8080|key-b",
    )
    peers = load_peers_from_env()
    assert peers == [
        FederationPeer("did:web:alice.example", "http://alice:8080", "key-a"),
        FederationPeer("did:web:bob.example", "http://bob:8080", "key-b"),
    ]


def test_load_peers_strips_trailing_slash(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv(
        "GTV_FEDERATION_PEERS", "did:web:x|http://x:8080/|"
    )
    peers = load_peers_from_env()
    assert peers[0].url == "http://x:8080"
    # Empty api_key allowed.
    assert peers[0].api_key == ""


def test_load_peers_skips_malformed(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv(
        "GTV_FEDERATION_PEERS",
        "did:web:good|http://good:8080,garbage-no-pipe,did:web:still-good|http://ok:8080",
    )
    peers = load_peers_from_env()
    # The malformed middle entry is dropped; surrounding good ones survive.
    assert [p.did for p in peers] == ["did:web:good", "did:web:still-good"]


# ---------------------------------------------------------------------------
# fetch_peer_envelope against a MockTransport that mimics a peer
# ---------------------------------------------------------------------------


def _make_envelope(verdict: Verdict, issuer_did: str) -> dict[str, Any]:
    env = Envelope(
        verdict=verdict,
        confidence=0.9,
        evidence=[
            Evidence(
                claim_id="cid-1",
                source_did="did:source",
                source_version="1.0",
                stance=Stance.SUPPORTS,
                excerpt="stub evidence",
                url=HttpUrl("https://example.com/e/1"),
                retrieved_at=datetime.now(tz=UTC),
                raw_hash="0" * 64,
            )
        ],
        rationale="stub",
        issuer_did=issuer_did,
        signature="stub://sig",
        rekor_uuid="uuid-stub",
        rekor_log_index=0,
        tsa_token="stub://tsa",
        prov_graph="{}",
        anchor_proof=AnchorProof(
            rekor_inclusion_proof="stub://proof",
            tsa_tsr_primary="stub://tsa",
        ),
    )
    return env.model_dump(mode="json")


@pytest.mark.asyncio
async def test_fetch_peer_envelope_happy_path() -> None:
    peer = FederationPeer(
        did="did:web:bob.example", url="http://bob:8080", api_key="bob-key"
    )

    captured: dict[str, Any] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["url"] = str(request.url)
        captured["auth"] = request.headers.get("authorization")
        captured["json"] = dict(request.url.params) or request.content
        return httpx.Response(
            200, json=_make_envelope(Verdict.VERIFIED, "did:web:bob.example")
        )

    async with httpx.AsyncClient(
        transport=httpx.MockTransport(handler)
    ) as client:
        env = await fetch_peer_envelope(
            peer, "The sky is blue.", client=client
        )

    assert env.issuer_did == "did:web:bob.example"
    assert env.verdict == Verdict.VERIFIED
    assert captured["url"].endswith("/tools/verify_claim")
    assert captured["auth"] == "Bearer bob-key"


@pytest.mark.asyncio
async def test_fetch_peer_envelope_raises_on_http_error() -> None:
    peer = FederationPeer(did="x", url="http://x:8080")

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(503, json={"detail": "maintenance"})

    async with httpx.AsyncClient(
        transport=httpx.MockTransport(handler)
    ) as client:
        with pytest.raises(httpx.HTTPStatusError):
            await fetch_peer_envelope(peer, "claim", client=client)


@pytest.mark.asyncio
async def test_fetch_peer_envelope_no_auth_header_when_key_blank() -> None:
    peer = FederationPeer(did="x", url="http://x:8080", api_key="")
    captured: dict[str, Any] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["auth"] = request.headers.get("authorization")
        return httpx.Response(
            200, json=_make_envelope(Verdict.VERIFIED, "x")
        )

    async with httpx.AsyncClient(
        transport=httpx.MockTransport(handler)
    ) as client:
        await fetch_peer_envelope(peer, "claim", client=client)

    # No Authorization header = auth-disabled peer, expected behavior.
    assert captured["auth"] is None


# ---------------------------------------------------------------------------
# /federation/consensus end-to-end (single process, fan-out mocked)
# ---------------------------------------------------------------------------


class _StaticAdapter(SourceAdapter):
    """Deterministic TIER_1 adapter — every call returns one SUPPORTS item."""

    source_did = "did:web:static.example"
    name = "static"
    source_type = SourceType.REFERENCE_DATA
    trust_tier = TrustTier.TIER_1
    freshness_sla_s = 60

    async def query(self, claim: Claim, max_items: int = 5) -> list[Evidence]:
        return [
            Evidence(
                claim_id=claim.claim_id,
                source_did=self.source_did,
                source_version="v1",
                stance=Stance.SUPPORTS,
                excerpt="Static evidence.",
                url=HttpUrl("https://static.example/e/1"),
                retrieved_at=datetime(2026, 1, 1, tzinfo=UTC),
                raw_hash="0" * 64,
            )
        ]

    async def snapshot(self, url: str) -> RawSnapshot:
        return RawSnapshot(url=url, content=b"", retrieved_at_iso="")

    async def health(self) -> HealthStatus:
        return HealthStatus(state="HEALTHY", detail="")

    async def close(self) -> None:
        return None


@pytest.fixture
def fed_client(
    monkeypatch: pytest.MonkeyPatch,
) -> Generator[TestClient, None, None]:
    """A single-instance gtv with one static TIER_1 adapter + in-memory state."""
    import gtv.mcp.server as server_mod

    saved_registry = dict(REGISTRY)
    REGISTRY.clear()
    REGISTRY[_StaticAdapter.source_did] = _StaticAdapter()

    saved_cache = server_mod._VERDICT_CACHE
    saved_life = server_mod._LIFECYCLE
    server_mod._VERDICT_CACHE = VerdictCache(InMemoryCacheStore())
    server_mod._LIFECYCLE = LifecycleIndex()

    # Make the local leg sign under a known DID so we can assert it in the tally.
    monkeypatch.setenv("GTV_ISSUER_DID", "did:web:local.example")

    try:
        yield TestClient(server_mod.app)
    finally:
        REGISTRY.clear()
        REGISTRY.update(saved_registry)
        server_mod._VERDICT_CACHE = saved_cache
        server_mod._LIFECYCLE = saved_life


def _patch_peers(
    monkeypatch: pytest.MonkeyPatch,
    peers: list[FederationPeer],
    responses: dict[str, Envelope | Exception],
) -> None:
    """Force the endpoint to see `peers` and return `responses[did]`.

    `responses[did]` may be an Envelope (returned) or an Exception
    (raised by fetch_peer_envelope).
    """
    monkeypatch.setattr(
        "gtv.mcp.server.load_peers_from_env", lambda: peers
    )

    async def fake_fetch(
        peer: FederationPeer, claim: str, **kwargs: Any
    ) -> Envelope:
        result = responses[peer.did]
        if isinstance(result, Exception):
            raise result
        return result

    monkeypatch.setattr("gtv.mcp.server.fetch_peer_envelope", fake_fetch)


def _fake_envelope(did: str, verdict: Verdict = Verdict.VERIFIED) -> Envelope:
    return Envelope.model_validate(_make_envelope(verdict, did))


def test_federation_consensus_fans_out_and_aggregates(
    fed_client: TestClient, monkeypatch: pytest.MonkeyPatch
) -> None:
    peers = [
        FederationPeer("did:web:bob.example", "http://bob:8080", "k"),
        FederationPeer("did:web:carol.example", "http://carol:8080", "k"),
    ]
    responses: dict[str, Envelope | Exception] = {
        "did:web:bob.example": _fake_envelope("did:web:bob.example"),
        "did:web:carol.example": _fake_envelope("did:web:carol.example"),
    }
    _patch_peers(monkeypatch, peers, responses)

    r = fed_client.post(
        "/federation/consensus",
        json={"claim": "Pi starts with 3.14.", "domain": "math"},
    )
    assert r.status_code == 200, r.text
    body = r.json()
    # Local + two peers → 3 contributing DIDs.
    assert set(body["contributing_dids"]) == {
        "did:web:local.example",
        "did:web:bob.example",
        "did:web:carol.example",
    }
    assert body["failed_dids"] == []
    assert body["aggregate"] is not None
    # Verdict is derived from compute_consensus; just check the key shape.
    assert body["verdict"]
    assert 0.0 <= body["confidence"] <= 1.0


def test_federation_consensus_tolerates_partial_peer_failure(
    fed_client: TestClient, monkeypatch: pytest.MonkeyPatch
) -> None:
    peers = [
        FederationPeer("did:web:bob.example", "http://bob:8080"),
        FederationPeer("did:web:dead.example", "http://dead:8080"),
    ]
    responses: dict[str, Envelope | Exception] = {
        "did:web:bob.example": _fake_envelope("did:web:bob.example"),
        "did:web:dead.example": httpx.ConnectError("peer unreachable"),
    }
    _patch_peers(monkeypatch, peers, responses)

    r = fed_client.post(
        "/federation/consensus",
        json={"claim": "Water boils at 100C at sea level.", "domain": "physics"},
    )
    assert r.status_code == 200, r.text
    body = r.json()
    assert "did:web:dead.example" in body["failed_dids"]
    assert "did:web:local.example" in body["contributing_dids"]
    assert "did:web:bob.example" in body["contributing_dids"]


def test_federation_consensus_all_remote_fail_but_local_succeeds(
    fed_client: TestClient, monkeypatch: pytest.MonkeyPatch
) -> None:
    peers = [FederationPeer("did:web:dead.example", "http://dead:8080")]
    responses: dict[str, Envelope | Exception] = {
        "did:web:dead.example": httpx.ConnectError("boom"),
    }
    _patch_peers(monkeypatch, peers, responses)

    r = fed_client.post(
        "/federation/consensus",
        json={"claim": "Two plus two is four.", "domain": "math"},
    )
    # Local leg succeeded alone — consensus over 1 envelope is still a consensus.
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["contributing_dids"] == ["did:web:local.example"]
    assert body["failed_dids"] == ["did:web:dead.example"]


def test_federation_consensus_all_fail_returns_502(
    fed_client: TestClient, monkeypatch: pytest.MonkeyPatch
) -> None:
    peers = [FederationPeer("did:web:dead.example", "http://dead:8080")]
    responses: dict[str, Envelope | Exception] = {
        "did:web:dead.example": httpx.ConnectError("boom"),
    }
    _patch_peers(monkeypatch, peers, responses)

    r = fed_client.post(
        "/federation/consensus",
        json={
            "claim": "Water boils at 100C at sea level.",
            "domain": "physics",
            "include_local": False,
        },
    )
    assert r.status_code == 502, r.text
    assert "did:web:dead.example" in r.json()["detail"]


def test_federation_consensus_no_peers_no_local_returns_503(
    fed_client: TestClient, monkeypatch: pytest.MonkeyPatch
) -> None:
    _patch_peers(monkeypatch, peers=[], responses={})

    r = fed_client.post(
        "/federation/consensus",
        json={
            "claim": "Trivially true.",
            "domain": "general",
            "include_local": False,
        },
    )
    assert r.status_code == 503, r.text


# ---------------------------------------------------------------------------
# Full-stack Docker smoke test (opt-in, release/nightly only)
# ---------------------------------------------------------------------------


@pytest.mark.skipif(
    os.environ.get("GTV_FEDERATION_E2E") != "1",
    reason="Set GTV_FEDERATION_E2E=1 to run the docker-compose federation smoke.",
)
def test_federation_docker_compose_smoke() -> None:  # pragma: no cover
    """Brings up two gtv containers and runs a consensus call across them.

    Reads ``deploy/federation/docker-compose.yml``. Requires Docker,
    ``docker compose``, and outbound network access to pull the image.
    """
    import subprocess

    compose = ["docker", "compose", "-f", "deploy/federation/docker-compose.yml"]
    subprocess.run([*compose, "up", "-d", "--wait"], check=True)
    try:
        # Alice's federation/consensus endpoint fans out to Bob.
        r = httpx.post(
            "http://localhost:18080/federation/consensus",
            json={"claim": "Pi starts with 3.14.", "domain": "math"},
            timeout=30.0,
        )
        assert r.status_code == 200, r.text
        body = r.json()
        assert {"did:web:alice.local", "did:web:bob.local"}.issubset(
            set(body["contributing_dids"])
        )
    finally:
        subprocess.run([*compose, "down", "-v"], check=False)
