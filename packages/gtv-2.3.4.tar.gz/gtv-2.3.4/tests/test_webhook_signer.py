"""Unit tests for webhook signing and verification.

Covers:
1. Round-trip: sign → verify succeeds
2. Tamper detection: flip one bit in signature → verify fails
3. Tamper detection: flip one bit in payload → verify fails
4. DID derivation: issuer_did is valid did:key:z... format
5. Determinism: same input always produces same signature
6. Signature format: matches byok-ed25519:... convention
"""
from __future__ import annotations

import base64
from tempfile import NamedTemporaryFile

import pytest
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ed25519

from gtv.did.resolve_key import parse_did_key
from gtv.subscribe.webhook_signer import sign_webhook_payload, verify_webhook_payload


@pytest.fixture
def ed25519_key_file() -> str:
    """Create a temporary Ed25519 PEM file for testing."""
    private_key = ed25519.Ed25519PrivateKey.generate()
    pem_bytes = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    with NamedTemporaryFile(mode="wb", delete=False, suffix=".pem") as f:
        f.write(pem_bytes)
        return f.name


@pytest.fixture
def sample_payload() -> dict:
    """Create a sample webhook payload."""
    return {
        "verdict": "VERIFIED",
        "confidence": 0.95,
        "artifact_hash": "sha256:abc123",
    }


def test_sign_webhook_round_trip(ed25519_key_file: str, sample_payload: dict) -> None:
    """Test that sign → verify round-trip succeeds."""
    signed = sign_webhook_payload(sample_payload, ed25519_key_file)
    assert "payload" in signed
    assert "signature" in signed
    assert "issuer_did" in signed
    verified_payload = verify_webhook_payload(signed)
    assert verified_payload == sample_payload


def test_signature_format(ed25519_key_file: str, sample_payload: dict) -> None:
    """Test that signature matches byok-ed25519:... format."""
    signed = sign_webhook_payload(sample_payload, ed25519_key_file)
    signature = signed["signature"]
    assert signature.startswith("byok-ed25519:")
    sig_b64 = signature[13:]  # Strip prefix
    sig_bytes = base64.b64decode(sig_b64)
    assert len(sig_bytes) == 64  # Ed25519 signature size


def test_issuer_did_format(ed25519_key_file: str, sample_payload: dict) -> None:
    """Test that issuer_did is a valid did:key:z... format."""
    signed = sign_webhook_payload(sample_payload, ed25519_key_file)
    issuer_did = signed["issuer_did"]
    assert issuer_did.startswith("did:key:z")
    parsed = parse_did_key(issuer_did)
    assert parsed.key_type == "Ed25519"
    assert len(parsed.public_key_bytes) == 32  # Ed25519 public key size


def test_determinism(ed25519_key_file: str, sample_payload: dict) -> None:
    """Test that signing the same payload produces the same signature."""
    signed1 = sign_webhook_payload(sample_payload, ed25519_key_file)
    signed2 = sign_webhook_payload(sample_payload, ed25519_key_file)
    assert signed1["signature"] == signed2["signature"]
    assert signed1["issuer_did"] == signed2["issuer_did"]


def test_signature_tampering_detection(
    ed25519_key_file: str, sample_payload: dict
) -> None:
    """Test that tampering with the signature is detected."""
    signed = sign_webhook_payload(sample_payload, ed25519_key_file)
    sig_b64 = signed["signature"][13:]  # Strip "byok-ed25519:"
    sig_bytes = bytearray(base64.b64decode(sig_b64))
    sig_bytes[0] ^= 0x01  # Flip first bit
    tampered_sig_b64 = base64.b64encode(sig_bytes).decode("ascii")
    signed["signature"] = f"byok-ed25519:{tampered_sig_b64}"
    with pytest.raises(ValueError, match="verification failed"):
        verify_webhook_payload(signed)


def test_payload_tampering_detection(
    ed25519_key_file: str, sample_payload: dict
) -> None:
    """Test that tampering with the payload is detected."""
    signed = sign_webhook_payload(sample_payload, ed25519_key_file)
    signed["payload"] = dict(sample_payload)
    signed["payload"]["confidence"] = 0.50
    with pytest.raises(ValueError, match="verification failed"):
        verify_webhook_payload(signed)
