"""Tests for AuditStore."""
from __future__ import annotations

import base64
import sqlite3
import tempfile
import threading
from pathlib import Path

import pytest

from gtv.audit import AuditRecord, AuditStore

# Try to import cryptography for signing tests
try:
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric import ed25519

    HAS_CRYPTOGRAPHY = True
except ImportError:
    HAS_CRYPTOGRAPHY = False


@pytest.fixture
def temp_db_path() -> Path:
    """Create a temporary database path."""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield Path(tmpdir) / "test.db"


@pytest.fixture
def signing_key_path() -> Path | None:
    """Generate a test Ed25519 key pair, return path to private key."""
    if not HAS_CRYPTOGRAPHY:
        return None

    with tempfile.TemporaryDirectory() as tmpdir:
        key = ed25519.Ed25519PrivateKey.generate()
        pem = key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption(),
        )
        key_path = Path(tmpdir) / "test_key.pem"
        key_path.write_bytes(pem)
        yield key_path


class TestAuditRecordCreation:
    """Test basic AuditRecord creation and immutability."""

    def test_record_is_frozen(self) -> None:
        """Verify AuditRecord is frozen (immutable)."""
        from pydantic import ValidationError

        record = AuditRecord(
            seq=1,
            timestamp="2026-01-01T00:00:00+00:00",
            actor="admin",
            action="test.action",
            target="target123",
            details={},
            prev_hash="0" * 64,
            record_hash="a" * 64,
            signature="unsigned",
        )
        with pytest.raises((ValidationError, AttributeError, TypeError)):
            record.seq = 2  # type: ignore

    def test_record_with_details_dict(self) -> None:
        """Test AuditRecord with nested details dictionary."""
        details = {
            "key1": "value1",
            "nested": {"key2": "value2", "key3": 123},
            "list": [1, 2, 3],
        }
        record = AuditRecord(
            seq=1,
            timestamp="2026-01-01T00:00:00+00:00",
            actor="system",
            action="config.update",
            target="config_id",
            details=details,
            prev_hash="0" * 64,
            record_hash="b" * 64,
            signature="unsigned",
        )
        assert record.details == details
        assert record.details["nested"]["key2"] == "value2"


class TestAuditStoreBasic:
    """Test basic AuditStore operations."""

    def test_append_first_record(self, temp_db_path: Path) -> None:
        """Test appending the first record with prev_hash='0'*64."""
        store = AuditStore(temp_db_path)
        record = store.append("admin", "apikey.create", "key123", {"test": True})
        store.close()

        assert record.seq == 1
        assert record.actor == "admin"
        assert record.action == "apikey.create"
        assert record.target == "key123"
        assert record.details == {"test": True}
        assert record.prev_hash == "0" * 64
        assert len(record.record_hash) == 64
        assert record.signature == "unsigned"

    def test_append_second_record_chains(self, temp_db_path: Path) -> None:
        """Test appending a second record with chained prev_hash."""
        store = AuditStore(temp_db_path)
        record1 = store.append("admin", "apikey.create", "key123", {})
        record2 = store.append("admin", "apikey.revoke", "key123", {})
        store.close()

        assert record2.seq == 2
        assert record2.prev_hash == record1.record_hash
        assert record1.record_hash != record2.record_hash

    def test_get_record_by_seq(self, temp_db_path: Path) -> None:
        """Test retrieving a record by sequence number."""
        store = AuditStore(temp_db_path)
        appended = store.append("admin", "test.action", "target1", {"key": "val"})
        retrieved = store.get(appended.seq)
        store.close()

        assert retrieved is not None
        assert retrieved.seq == appended.seq
        assert retrieved.actor == appended.actor
        assert retrieved.action == appended.action
        assert retrieved.target == appended.target
        assert retrieved.details == appended.details
        assert retrieved.record_hash == appended.record_hash

    def test_get_nonexistent_record(self, temp_db_path: Path) -> None:
        """Test getting a nonexistent record returns None."""
        store = AuditStore(temp_db_path)
        store.append("admin", "test", "target", {})
        result = store.get(999)
        store.close()

        assert result is None

    def test_tail_empty_store(self, temp_db_path: Path) -> None:
        """Test tail() on an empty store."""
        store = AuditStore(temp_db_path)
        records = store.tail(10)
        store.close()

        assert records == []

    def test_tail_single_record(self, temp_db_path: Path) -> None:
        """Test tail() with a single record."""
        store = AuditStore(temp_db_path)
        record = store.append("admin", "test", "target", {})
        result = store.tail(10)
        store.close()

        assert len(result) == 1
        assert result[0].seq == record.seq

    def test_tail_multiple_records_newest_first(self, temp_db_path: Path) -> None:
        """Test tail() returns records newest first."""
        store = AuditStore(temp_db_path)
        for i in range(5):
            store.append("admin", f"action{i}", f"target{i}", {})
        result = store.tail(10)
        store.close()

        assert len(result) == 5
        # tail() returns newest first
        assert result[0].seq == 5
        assert result[1].seq == 4
        assert result[2].seq == 3
        assert result[3].seq == 2
        assert result[4].seq == 1

    def test_tail_limit(self, temp_db_path: Path) -> None:
        """Test tail() respects the limit parameter."""
        store = AuditStore(temp_db_path)
        for i in range(10):
            store.append("admin", f"action{i}", f"target{i}", {})
        result = store.tail(3)
        store.close()

        assert len(result) == 3
        assert result[0].seq == 10
        assert result[1].seq == 9
        assert result[2].seq == 8


class TestAuditStoreChainVerification:
    """Test chain verification logic."""

    def test_verify_chain_empty_store(self, temp_db_path: Path) -> None:
        """Test verify_chain() on empty store returns success."""
        store = AuditStore(temp_db_path)
        is_valid, bad_seq = store.verify_chain()
        store.close()

        assert is_valid is True
        assert bad_seq is None

    def test_verify_chain_single_record(self, temp_db_path: Path) -> None:
        """Test verify_chain() with single valid record."""
        store = AuditStore(temp_db_path)
        store.append("admin", "test", "target", {})
        is_valid, bad_seq = store.verify_chain()
        store.close()

        assert is_valid is True
        assert bad_seq is None

    def test_verify_chain_multiple_valid_records(self, temp_db_path: Path) -> None:
        """Test verify_chain() with multiple valid records."""
        store = AuditStore(temp_db_path)
        for i in range(10):
            store.append("admin", f"action{i}", f"target{i}", {})
        is_valid, bad_seq = store.verify_chain()
        store.close()

        assert is_valid is True
        assert bad_seq is None

    def test_verify_chain_detects_tampered_record_hash(self, temp_db_path: Path) -> None:
        """Test verify_chain() detects tampered record_hash."""
        store = AuditStore(temp_db_path)
        store.append("admin", "action1", "target1", {})
        store.append("admin", "action2", "target2", {})
        store.close()

        # Tamper with the first record's record_hash
        conn = sqlite3.connect(str(temp_db_path))
        conn.execute(
            "UPDATE audit_log SET record_hash = ? WHERE seq = ?",
            ("b" * 64, 1),
        )
        conn.commit()
        conn.close()

        store = AuditStore(temp_db_path)
        is_valid, bad_seq = store.verify_chain()
        store.close()

        assert is_valid is False
        assert bad_seq == 1

    def test_verify_chain_detects_broken_prev_hash_link(self, temp_db_path: Path) -> None:
        """Test verify_chain() detects broken prev_hash chain."""
        store = AuditStore(temp_db_path)
        store.append("admin", "action1", "target1", {})
        store.append("admin", "action2", "target2", {})
        store.close()

        # Break the prev_hash link in second record
        conn = sqlite3.connect(str(temp_db_path))
        conn.execute(
            "UPDATE audit_log SET prev_hash = ? WHERE seq = ?",
            ("c" * 64, 2),
        )
        conn.commit()
        conn.close()

        store = AuditStore(temp_db_path)
        is_valid, bad_seq = store.verify_chain()
        store.close()

        assert is_valid is False
        assert bad_seq == 2

    def test_verify_chain_detects_out_of_order_seq(self, temp_db_path: Path) -> None:
        """Test verify_chain() detects out-of-order sequence numbers."""
        store = AuditStore(temp_db_path)
        store.append("admin", "action1", "target1", {})
        store.append("admin", "action2", "target2", {})
        store.append("admin", "action3", "target3", {})
        store.close()

        # Manually mess with sequence
        conn = sqlite3.connect(str(temp_db_path))
        conn.execute("UPDATE audit_log SET seq = 5 WHERE seq = 2")
        conn.commit()
        conn.close()

        store = AuditStore(temp_db_path)
        is_valid, _bad_seq = store.verify_chain()
        store.close()

        assert is_valid is False


class TestAuditStoreDetails:
    """Test details dict serialization."""

    def test_details_with_unicode(self, temp_db_path: Path) -> None:
        """Test details dict with Unicode characters."""
        store = AuditStore(temp_db_path)
        details = {"msg": "Hello, 世界! 🌍"}
        record = store.append("admin", "test", "target", details)
        retrieved = store.get(record.seq)
        store.close()

        assert retrieved is not None
        assert retrieved.details["msg"] == "Hello, 世界! 🌍"

    def test_details_with_nested_structures(self, temp_db_path: Path) -> None:
        """Test details dict with nested dicts and lists."""
        store = AuditStore(temp_db_path)
        details = {
            "level1": {
                "level2": {
                    "values": [1, "two", 3.0, None, True],
                }
            }
        }
        record = store.append("admin", "test", "target", details)
        retrieved = store.get(record.seq)
        store.close()

        assert retrieved is not None
        assert retrieved.details == details

    def test_details_empty_dict(self, temp_db_path: Path) -> None:
        """Test details as empty dict."""
        store = AuditStore(temp_db_path)
        record = store.append("admin", "test", "target", {})
        retrieved = store.get(record.seq)
        store.close()

        assert retrieved is not None
        assert retrieved.details == {}


class TestAuditStoreSignature:
    """Test Ed25519 signing (if available)."""

    @pytest.mark.skipif(not HAS_CRYPTOGRAPHY, reason="cryptography not available")
    def test_append_with_signing_key(self, temp_db_path: Path) -> None:
        """Test appending records with Ed25519 signing key."""
        with tempfile.TemporaryDirectory() as tmpdir:
            key_path = Path(tmpdir) / "test_key.pem"
            key = ed25519.Ed25519PrivateKey.generate()
            pem = key.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.PKCS8,
                encryption_algorithm=serialization.NoEncryption(),
            )
            key_path.write_bytes(pem)

            store = AuditStore(temp_db_path, signing_key_path=str(key_path))
            record = store.append("admin", "test", "target", {"data": "value"})
            store.close()

            assert record.signature.startswith("ed25519:")
            # Extract and verify the base64 signature can be decoded
            sig_b64 = record.signature.split(":", 1)[1]
            sig_bytes = base64.b64decode(sig_b64)
            assert len(sig_bytes) == 64  # Ed25519 signature is 64 bytes

    @pytest.mark.skipif(not HAS_CRYPTOGRAPHY, reason="cryptography not available")
    def test_verify_chain_with_valid_signatures(self, temp_db_path: Path) -> None:
        """Test verify_chain() passes with valid Ed25519 signatures."""
        with tempfile.TemporaryDirectory() as tmpdir:
            key_path = Path(tmpdir) / "test_key.pem"
            key = ed25519.Ed25519PrivateKey.generate()
            pem = key.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.PKCS8,
                encryption_algorithm=serialization.NoEncryption(),
            )
            key_path.write_bytes(pem)

            store = AuditStore(temp_db_path, signing_key_path=str(key_path))
            for i in range(5):
                store.append("admin", f"action{i}", f"target{i}", {})
            is_valid, bad_seq = store.verify_chain()
            store.close()

            assert is_valid is True
            assert bad_seq is None

    def test_unsigned_records_verify_without_key(self, temp_db_path: Path) -> None:
        """Test that unsigned records verify successfully."""
        store = AuditStore(temp_db_path)
        for i in range(5):
            store.append("admin", f"action{i}", f"target{i}", {})
        is_valid, bad_seq = store.verify_chain()
        store.close()

        assert is_valid is True
        assert bad_seq is None


class TestAuditStoreThreadSafety:
    """Test thread safety of AuditStore."""

    def test_concurrent_appends(self, temp_db_path: Path) -> None:
        """Test that 10 concurrent appends succeed with monotonic seq."""
        store = AuditStore(temp_db_path)
        appended_seqs = []
        lock = threading.Lock()

        def append_record(idx: int) -> None:
            record = store.append("thread", f"action{idx}", f"target{idx}", {})
            with lock:
                appended_seqs.append(record.seq)

        threads = [threading.Thread(target=append_record, args=(i,)) for i in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        store.close()

        # Check that all seq values are unique and in range [1, 10]
        assert sorted(appended_seqs) == list(range(1, 11))

    def test_concurrent_reads_and_writes(self, temp_db_path: Path) -> None:
        """Test concurrent reads and writes to store."""
        store = AuditStore(temp_db_path)
        results = {"errors": []}
        lock = threading.Lock()

        def writer(idx: int) -> None:
            try:
                store.append("thread", f"action{idx}", f"target{idx}", {})
            except Exception as e:
                with lock:
                    results["errors"].append(str(e))

        def reader() -> None:
            try:
                store.tail(5)
                store.get(1)
            except Exception as e:
                with lock:
                    results["errors"].append(str(e))

        threads = (
            [threading.Thread(target=writer, args=(i,)) for i in range(5)]
            + [threading.Thread(target=reader) for _ in range(5)]
        )
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        store.close()

        # Should not have any errors from thread safety violations
        assert results["errors"] == []


class TestAuditStoreEdgeCases:
    """Test edge cases and special inputs."""

    def test_long_action_string(self, temp_db_path: Path) -> None:
        """Test with a very long action string."""
        store = AuditStore(temp_db_path)
        long_action = "action." + "x" * 1000
        record = store.append("admin", long_action, "target", {})
        retrieved = store.get(record.seq)
        store.close()

        assert retrieved is not None
        assert retrieved.action == long_action

    def test_special_characters_in_target(self, temp_db_path: Path) -> None:
        """Test with special characters in target."""
        store = AuditStore(temp_db_path)
        target = "target:with:colons/and/slashes?and=query&stuff"
        record = store.append("admin", "action", target, {})
        retrieved = store.get(record.seq)
        store.close()

        assert retrieved is not None
        assert retrieved.target == target

    def test_actor_as_did(self, temp_db_path: Path) -> None:
        """Test actor field with a DID format."""
        store = AuditStore(temp_db_path)
        actor = "did:web:example.com:actor#key1"
        record = store.append(actor, "action", "target", {})
        retrieved = store.get(record.seq)
        store.close()

        assert retrieved is not None
        assert retrieved.actor == actor

    def test_large_details_dict(self, temp_db_path: Path) -> None:
        """Test with a large details dictionary."""
        store = AuditStore(temp_db_path)
        details = {f"key{i}": f"value{i}" * 10 for i in range(100)}
        record = store.append("admin", "action", "target", details)
        retrieved = store.get(record.seq)
        store.close()

        assert retrieved is not None
        assert len(retrieved.details) == 100
        assert retrieved.details == details
