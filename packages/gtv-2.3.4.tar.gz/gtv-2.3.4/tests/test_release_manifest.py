"""
Tests for the release manifest generator.
"""

import json
import re
import sys
from pathlib import Path

import pytest


class TestReleaseManifest:
    """Test release manifest generation."""

    @pytest.fixture(autouse=True)
    def ensure_manifest_exists(self):
        """Ensure the 2.1.0 manifest exists before tests run."""
        root = Path(__file__).parent.parent
        manifest_path = root / "release" / "manifest-2.1.0.json"

        if not manifest_path.exists():
            # Generate it using the script functions directly
            sys.path.insert(0, str(root / "scripts"))
            try:
                import release_manifest as rm
                manifest = rm.generate_manifest("2.1.0")
                manifest_path.parent.mkdir(parents=True, exist_ok=True)
                with open(manifest_path, "w") as f:
                    json.dump(manifest, f, indent=2)
            finally:
                sys.path.pop(0)

    def test_manifest_for_known_version(self):
        """Verify manifest structure for a known version."""
        root = Path(__file__).parent.parent
        manifest_path = root / "release" / "manifest-2.1.0.json"

        assert manifest_path.exists(), f"Manifest not found at {manifest_path}"

        with open(manifest_path) as f:
            manifest = json.load(f)

        # Verify expected keys
        assert "version" in manifest
        assert "released_at" in manifest
        assert "python_package" in manifest
        assert "files_included" in manifest
        assert "tests_passing" in manifest
        assert "changelog_section" in manifest

        # Verify values
        assert manifest["version"] == "2.1.0"
        assert manifest["python_package"]["name"] == "gtv"
        assert len(manifest["files_included"]) >= 50

    def test_manifest_fails_for_unknown_version(self):
        """Manifest generation should fail for unknown versions."""
        root = Path(__file__).parent.parent
        sys.path.insert(0, str(root / "scripts"))

        try:
            import release_manifest as rm
            with pytest.raises(SystemExit) as exc_info:
                rm.generate_manifest("99.99.99")
            assert exc_info.value.code == 2
        finally:
            sys.path.pop(0)

    def test_manifest_file_hashes_are_sha256(self):
        """All file hashes should be valid SHA256 hex strings."""
        root = Path(__file__).parent.parent
        manifest_path = root / "release" / "manifest-2.1.0.json"

        with open(manifest_path) as f:
            manifest = json.load(f)

        # Verify all file hashes
        sha256_pattern = re.compile(r"^[a-f0-9]{64}$")
        for file_entry in manifest["files_included"]:
            assert "sha256" in file_entry
            sha256 = file_entry["sha256"]
            assert sha256_pattern.match(sha256), \
                f"Invalid SHA256 hash: {sha256} for file {file_entry.get('path', 'unknown')}"

    def test_changelog_section_contains_version_heading(self):
        """Changelog section should contain the version heading."""
        root = Path(__file__).parent.parent
        manifest_path = root / "release" / "manifest-2.1.0.json"

        with open(manifest_path) as f:
            manifest = json.load(f)

        changelog_section = manifest["changelog_section"]
        assert "## [2.1.0]" in changelog_section
        assert "2026-04-22" in changelog_section  # Expected date

    def test_manifest_has_tests_passing_count(self):
        """Manifest should have a tests_passing count."""
        root = Path(__file__).parent.parent
        manifest_path = root / "release" / "manifest-2.1.0.json"

        with open(manifest_path) as f:
            manifest = json.load(f)

        assert "tests_passing" in manifest
        assert isinstance(manifest["tests_passing"], int)
        assert manifest["tests_passing"] > 0

    def test_manifest_files_included_have_required_fields(self):
        """Each file in files_included should have path and sha256."""
        root = Path(__file__).parent.parent
        manifest_path = root / "release" / "manifest-2.1.0.json"

        with open(manifest_path) as f:
            manifest = json.load(f)

        for file_entry in manifest["files_included"]:
            assert "path" in file_entry
            assert "sha256" in file_entry
            assert isinstance(file_entry["path"], str)
            assert isinstance(file_entry["sha256"], str)
            assert file_entry["path"].endswith(".py")

    def test_manifest_released_at_is_iso8601(self):
        """released_at should be a valid ISO 8601 timestamp."""
        root = Path(__file__).parent.parent
        manifest_path = root / "release" / "manifest-2.1.0.json"

        with open(manifest_path) as f:
            manifest = json.load(f)

        released_at = manifest["released_at"]
        # Should be ISO 8601 format with timezone info
        iso8601_pattern = re.compile(
            r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}[\.\d]*[\+\-]\d{2}:\d{2}$"
        )
        assert iso8601_pattern.match(released_at), \
            f"Invalid ISO 8601 timestamp: {released_at}"

    def test_manifest_python_package_has_name_and_version(self):
        """python_package should have name and version."""
        root = Path(__file__).parent.parent
        manifest_path = root / "release" / "manifest-2.1.0.json"

        with open(manifest_path) as f:
            manifest = json.load(f)

        pkg = manifest["python_package"]
        assert "name" in pkg
        assert "version" in pkg
        assert pkg["name"] == "gtv"
        # Version should match semantic versioning
        assert re.match(r"^\d+\.\d+\.\d+", pkg["version"])
