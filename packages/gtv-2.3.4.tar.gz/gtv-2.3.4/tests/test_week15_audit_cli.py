"""Tests for the gtv-audit CLI."""
from __future__ import annotations

import json

from gtv.audit.store import AuditStore
from gtv.cli.audit import cmd_append, cmd_export, cmd_get, cmd_tail, cmd_verify, main


class TestTailCommand:
    """Test gtv-audit tail."""

    def test_tail_empty_db(self, tmp_path, capsys):
        """Test tail on empty DB returns 0 records, exit 0."""
        db_path = tmp_path / "audit.db"
        exit_code = cmd_tail(limit=20, db=str(db_path), format="text")
        assert exit_code == 0

        captured = capsys.readouterr()
        assert "0 records" in captured.out

    def test_tail_default_limit(self, tmp_path, capsys):
        """Test tail with default limit of 20."""
        db_path = tmp_path / "audit.db"

        # Append 5 records
        store = AuditStore(str(db_path))
        for i in range(5):
            store.append(f"actor{i}", "action", f"target{i}", {})
        store.close()

        exit_code = cmd_tail(limit=20, db=str(db_path), format="text")
        assert exit_code == 0

        captured = capsys.readouterr()
        for i in range(5):
            assert f"actor{i}" in captured.out

    def test_tail_limit_respected(self, tmp_path, capsys):
        """Test tail --limit 2 returns exactly 2 newest."""
        db_path = tmp_path / "audit.db"

        # Append 5 records
        store = AuditStore(str(db_path))
        for i in range(5):
            store.append(f"actor{i}", "action", f"target{i}", {})
        store.close()

        exit_code = cmd_tail(limit=2, db=str(db_path), format="text")
        assert exit_code == 0

        captured = capsys.readouterr()
        # Should have records for actor3 and actor4 (newest first)
        lines = [line for line in captured.out.split("\n") if line.strip() and "[" in line]
        assert len(lines) == 2

    def test_tail_text_format(self, tmp_path, capsys):
        """Test tail text format output."""
        db_path = tmp_path / "audit.db"

        store = AuditStore(str(db_path))
        store.append("testactor", "testaction", "testtarget", {})
        store.close()

        exit_code = cmd_tail(limit=20, db=str(db_path), format="text")
        assert exit_code == 0

        captured = capsys.readouterr()
        assert "[1]" in captured.out
        assert "testactor" in captured.out
        assert "testaction" in captured.out
        assert "testtarget" in captured.out
        assert "signature:" in captured.out

    def test_tail_json_format(self, tmp_path, capsys):
        """Test tail JSON format output."""
        db_path = tmp_path / "audit.db"

        store = AuditStore(str(db_path))
        store.append("testactor", "testaction", "testtarget", {})
        store.close()

        exit_code = cmd_tail(limit=20, db=str(db_path), format="json")
        assert exit_code == 0

        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert isinstance(data, list)
        assert len(data) == 1
        assert data[0]["actor"] == "testactor"


class TestVerifyCommand:
    """Test gtv-audit verify."""

    def test_verify_clean_chain_empty_db(self, tmp_path, capsys):
        """Test verify on clean empty chain."""
        db_path = tmp_path / "audit.db"

        # Create empty DB
        store = AuditStore(str(db_path))
        store.close()

        exit_code = cmd_verify(db=str(db_path))
        assert exit_code == 0

        captured = capsys.readouterr()
        assert "Chain intact:" in captured.out

    def test_verify_clean_chain_with_records(self, tmp_path, capsys):
        """Test verify on clean chain with records."""
        db_path = tmp_path / "audit.db"

        store = AuditStore(str(db_path))
        for i in range(3):
            store.append(f"actor{i}", "action", f"target{i}", {})
        store.close()

        exit_code = cmd_verify(db=str(db_path))
        assert exit_code == 0

        captured = capsys.readouterr()
        assert "Chain intact: 3 records" in captured.out

    def test_verify_broken_chain(self, tmp_path, capsys):
        """Test verify on tampered chain."""
        db_path = tmp_path / "audit.db"

        # Create a chain
        store = AuditStore(str(db_path))
        store.append("actor1", "action", "target1", {})
        store.append("actor2", "action", "target2", {})
        store.close()

        # Tamper with the database
        import sqlite3

        conn = sqlite3.connect(str(db_path))
        cursor = conn.cursor()
        # Change the actor of seq=1 record
        cursor.execute("UPDATE audit_log SET actor = ? WHERE seq = 1", ("tampered_actor",))
        conn.commit()
        conn.close()

        exit_code = cmd_verify(db=str(db_path))
        assert exit_code == 1

        captured = capsys.readouterr()
        assert "CHAIN BROKEN at seq=" in captured.out


class TestGetCommand:
    """Test gtv-audit get."""

    def test_get_existing_record(self, tmp_path, capsys):
        """Test get for existing record."""
        db_path = tmp_path / "audit.db"

        store = AuditStore(str(db_path))
        store.append("actor1", "action1", "target1", {"key": "value"})
        store.close()

        exit_code = cmd_get(1, db=str(db_path), format="text")
        assert exit_code == 0

        captured = capsys.readouterr()
        assert "seq:       1" in captured.out
        assert "actor:     actor1" in captured.out
        assert "action:    action1" in captured.out
        assert "target:    target1" in captured.out
        assert "details:" in captured.out

    def test_get_missing_seq(self, tmp_path, capsys):
        """Test get for missing seq returns exit 1."""
        db_path = tmp_path / "audit.db"

        store = AuditStore(str(db_path))
        store.append("actor1", "action1", "target1", {})
        store.close()

        exit_code = cmd_get(999, db=str(db_path), format="text")
        assert exit_code == 1

        captured = capsys.readouterr()
        assert "not found" in captured.err.lower()

    def test_get_json_format(self, tmp_path, capsys):
        """Test get with JSON format."""
        db_path = tmp_path / "audit.db"

        store = AuditStore(str(db_path))
        store.append("actor1", "action1", "target1", {"key": "value"})
        store.close()

        exit_code = cmd_get(1, db=str(db_path), format="json")
        assert exit_code == 0

        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert data["seq"] == 1
        assert data["actor"] == "actor1"
        assert data["action"] == "action1"


class TestAppendCommand:
    """Test gtv-audit append."""

    def test_append_one_record(self, tmp_path, capsys):
        """Test append one record via CLI."""
        db_path = tmp_path / "audit.db"

        exit_code = cmd_append(
            actor="testactor",
            action="testaction",
            target="testtarget",
            details=None,
            db=str(db_path),
        )
        assert exit_code == 0

        captured = capsys.readouterr()
        assert "1" in captured.out  # seq should be printed

    def test_append_with_details_json(self, tmp_path, capsys):
        """Test append with JSON details."""
        db_path = tmp_path / "audit.db"

        exit_code = cmd_append(
            actor="actor1",
            action="action1",
            target="target1",
            details='{"key": "value", "number": 42}',
            db=str(db_path),
        )
        assert exit_code == 0

        # Verify it was recorded
        store = AuditStore(str(db_path))
        record = store.get(1)
        store.close()

        assert record.details == {"key": "value", "number": 42}

    def test_append_invalid_json_details(self, tmp_path, capsys):
        """Test append with invalid JSON details."""
        db_path = tmp_path / "audit.db"

        exit_code = cmd_append(
            actor="actor1",
            action="action1",
            target="target1",
            details="not valid json {",
            db=str(db_path),
        )
        assert exit_code == 1

        captured = capsys.readouterr()
        assert "Invalid JSON" in captured.err

    def test_append_then_tail(self, tmp_path, capsys):
        """Test append one record then tail shows it."""
        db_path = tmp_path / "audit.db"

        # Append
        cmd_append(
            actor="actor1",
            action="action1",
            target="target1",
            details=None,
            db=str(db_path),
        )

        capsys.readouterr()

        # Tail
        exit_code = cmd_tail(limit=20, db=str(db_path), format="text")
        assert exit_code == 0

        captured = capsys.readouterr()
        assert "actor1" in captured.out
        assert "action1" in captured.out
        assert "target1" in captured.out


class TestExportCommand:
    """Test gtv-audit export."""

    def test_export_to_stdout(self, tmp_path, capsys):
        """Test export writes one JSON line per record to stdout."""
        db_path = tmp_path / "audit.db"

        store = AuditStore(str(db_path))
        store.append("actor1", "action1", "target1", {})
        store.append("actor2", "action2", "target2", {})
        store.close()

        exit_code = cmd_export(db=str(db_path), out=None)
        assert exit_code == 0

        captured = capsys.readouterr()
        lines = [line for line in captured.out.split("\n") if line.strip()]
        assert len(lines) == 2

        # Each line should be valid JSON
        for line in lines:
            data = json.loads(line)
            assert "seq" in data
            assert "actor" in data

    def test_export_to_file(self, tmp_path):
        """Test export with --out writes to file."""
        db_path = tmp_path / "audit.db"
        out_path = tmp_path / "export.jsonl"

        store = AuditStore(str(db_path))
        store.append("actor1", "action1", "target1", {})
        store.append("actor2", "action2", "target2", {})
        store.close()

        exit_code = cmd_export(db=str(db_path), out=str(out_path))
        assert exit_code == 0

        assert out_path.exists()
        with open(out_path) as f:
            lines = f.readlines()
        assert len(lines) == 2

        # Each line should be valid JSON
        for line in lines:
            data = json.loads(line)
            assert "seq" in data

    def test_export_empty_db(self, tmp_path, capsys):
        """Test export on empty DB."""
        db_path = tmp_path / "audit.db"

        store = AuditStore(str(db_path))
        store.close()

        exit_code = cmd_export(db=str(db_path), out=None)
        assert exit_code == 0

        captured = capsys.readouterr()
        # Should have no output or empty output
        assert captured.out == "" or captured.out == "\n"


class TestEnvVarSupport:
    """Test GTV_AUDIT_DB environment variable."""

    def test_env_var_respected(self, tmp_path, monkeypatch, capsys):
        """Test that GTV_AUDIT_DB env var is used."""
        db_path = tmp_path / "from_env.db"
        monkeypatch.setenv("GTV_AUDIT_DB", str(db_path))

        argv = ["append", "--actor", "testactor", "--action", "action", "--target", "target"]

        exit_code = main(argv)
        assert exit_code == 0
        assert db_path.exists()

    def test_cli_flag_wins_over_env_var(self, tmp_path, monkeypatch):
        """Test that --db flag takes precedence over env var."""
        db_from_env = tmp_path / "from_env.db"
        db_from_cli = tmp_path / "from_cli.db"

        monkeypatch.setenv("GTV_AUDIT_DB", str(db_from_env))

        argv = [
            "append",
            "--actor",
            "testactor",
            "--action",
            "action",
            "--target",
            "target",
            "--db",
            str(db_from_cli),
        ]

        exit_code = main(argv)
        assert exit_code == 0
        assert db_from_cli.exists()
        assert not db_from_env.exists()


class TestMainIntegration:
    """Integration tests using main()."""

    def test_main_tail_via_argv(self, tmp_path, capsys):
        """Test tail via main() with argv."""
        db_path = tmp_path / "audit.db"

        store = AuditStore(str(db_path))
        store.append("actor1", "action1", "target1", {})
        store.close()

        argv = ["tail", "--db", str(db_path)]
        exit_code = main(argv)
        assert exit_code == 0

        captured = capsys.readouterr()
        assert "actor1" in captured.out

    def test_main_append_via_argv(self, tmp_path, capsys):
        """Test append via main() with argv."""
        db_path = tmp_path / "audit.db"

        argv = [
            "append",
            "--actor",
            "testactor",
            "--action",
            "testaction",
            "--target",
            "testtarget",
            "--db",
            str(db_path),
        ]

        exit_code = main(argv)
        assert exit_code == 0

        captured = capsys.readouterr()
        assert "1" in captured.out  # seq

    def test_main_verify_via_argv(self, tmp_path, capsys):
        """Test verify via main() with argv."""
        db_path = tmp_path / "audit.db"

        store = AuditStore(str(db_path))
        store.append("actor1", "action1", "target1", {})
        store.close()

        argv = ["verify", "--db", str(db_path)]
        exit_code = main(argv)
        assert exit_code == 0

        captured = capsys.readouterr()
        assert "Chain intact:" in captured.out

    def test_main_get_via_argv(self, tmp_path, capsys):
        """Test get via main() with argv."""
        db_path = tmp_path / "audit.db"

        store = AuditStore(str(db_path))
        store.append("actor1", "action1", "target1", {})
        store.close()

        argv = ["get", "1", "--db", str(db_path)]
        exit_code = main(argv)
        assert exit_code == 0

        captured = capsys.readouterr()
        assert "actor1" in captured.out

    def test_main_export_via_argv(self, tmp_path, capsys):
        """Test export via main() with argv."""
        db_path = tmp_path / "audit.db"

        store = AuditStore(str(db_path))
        store.append("actor1", "action1", "target1", {})
        store.close()

        argv = ["export", "--db", str(db_path)]
        exit_code = main(argv)
        assert exit_code == 0

        captured = capsys.readouterr()
        # Export returns JSON lines (one per line)
        lines = [line for line in captured.out.strip().split("\n") if line]
        assert len(lines) == 1
        data = json.loads(lines[0])
        assert data["actor"] == "actor1"


class TestJsonFormatOutput:
    """Test JSON format output is valid."""

    def test_tail_json_is_valid(self, tmp_path, capsys):
        """Test that tail JSON format output is valid JSON."""
        db_path = tmp_path / "audit.db"

        store = AuditStore(str(db_path))
        store.append("actor1", "action1", "target1", {"key": "value"})
        store.close()

        exit_code = cmd_tail(limit=20, db=str(db_path), format="json")
        assert exit_code == 0

        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert isinstance(data, list)
        assert len(data) == 1

    def test_get_json_is_valid(self, tmp_path, capsys):
        """Test that get JSON format output is valid JSON."""
        db_path = tmp_path / "audit.db"

        store = AuditStore(str(db_path))
        store.append("actor1", "action1", "target1", {})
        store.close()

        exit_code = cmd_get(1, db=str(db_path), format="json")
        assert exit_code == 0

        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert data["seq"] == 1
