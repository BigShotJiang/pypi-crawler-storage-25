"""Pytest configuration and fixtures for gtv tests."""
from __future__ import annotations

import asyncio
import base64

import httpx
import pytest
from rfc3161_client import HashAlgorithm, TimestampRequestBuilder, decode_timestamp_response


@pytest.fixture
def real_tsa_response() -> bytes:
    """Get a real TimeStampResponse from FreeTSA for use in mocked tests.

    This is fetched once and cached for the test session.
    """
    # Check if we have a cached version
    try:
        cached = base64.b64decode(
            "MIISIDADAgEAMIISFwYJKoZIhvcNAQcCoIISCDCCEgQCAQMxDzANBglghkgBZQMEAgMFADCCAZAGCyqG"
            "SIb3DQEJEAEEoIIBfwSC+wSCAZgCgZcCAQEGBCoDBAExEDANBglghkgBZQMEAgMFADAxBglghkgBZQME"
            "AgE="
        )
        # Try to parse it
        try:
            ts_resp = decode_timestamp_response(cached)
            ts_resp.time_stamp_token()
            return cached
        except Exception:
            pass
    except Exception:
        pass

    # Fetch a fresh one from FreeTSA
    async def fetch_real_tsr() -> bytes:
        data = b"pytest fixture test data"
        ts_req = TimestampRequestBuilder(data=data, hash_algorithm=HashAlgorithm.SHA256).build()

        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.post(
                "https://freetsa.org/tsr",
                content=ts_req.as_bytes(),
                headers={"Content-Type": "application/timestamp-query"},
            )
            resp.raise_for_status()

            # Verify it's valid
            ts_resp = decode_timestamp_response(resp.content)
            ts_resp.time_stamp_token()

            return resp.content

    try:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        tsr = loop.run_until_complete(fetch_real_tsr())
        loop.close()
        return tsr
    except Exception:
        # If we can't get a real TSR, return a placeholder that will cause
        # parsing errors in tests (which is OK for secondary failure tests)
        return b"\x30\x03\x02\x01\x00"
