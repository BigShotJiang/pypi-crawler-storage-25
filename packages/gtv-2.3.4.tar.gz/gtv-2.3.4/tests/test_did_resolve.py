"""Tests for DID resolution (did:web).

Covers:
1. DID parsing (correct URL construction, error cases).
2. DID document fetching (HTTP success, failures, JSON validation).
3. Identity extraction from DID documents.
"""
from __future__ import annotations

import httpx
import pytest
import respx

from gtv.did.resolve import (
    DIDResolutionError,
    extract_expected_identity,
    parse_did_web,
    resolve_did_web,
)


class TestParseDIDWeb:
    """Unit tests for parse_did_web."""

    def test_parse_simple_did_web(self) -> None:
        """Parse did:web:example.com to correct URL."""
        url = parse_did_web("did:web:example.com")
        assert url == "https://example.com/.well-known/did.json"

    def test_parse_did_web_with_path(self) -> None:
        """Parse did:web:example.com:path:to:resource to correct URL."""
        url = parse_did_web("did:web:example.com:path:to:resource")
        assert url == "https://example.com/path/to/resource/did.json"

    def test_parse_did_web_with_single_path_component(self) -> None:
        """Parse did:web:example.com:resource."""
        url = parse_did_web("did:web:example.com:resource")
        assert url == "https://example.com/resource/did.json"

    def test_parse_non_did_web_raises_error(self) -> None:
        """Reject non-did:web DIDs."""
        with pytest.raises(DIDResolutionError, match="Not a did:web DID"):
            parse_did_web("did:key:z6MkhaXgBZDvotDkL5257faWxcqACaFMbjNzBLMxQYVm4b")

    def test_parse_did_web_with_empty_authority_raises_error(self) -> None:
        """Reject did:web: with empty authority."""
        with pytest.raises(DIDResolutionError, match="did:web with no authority"):
            parse_did_web("did:web:")

    def test_parse_did_web_with_malformed_authority_raises_error(self) -> None:
        """Reject did:web with invalid authority characters."""
        with pytest.raises(DIDResolutionError, match="Invalid authority"):
            parse_did_web("did:web:bad_authority!@#")


class TestResolveDIDWeb:
    """Integration tests for resolve_did_web using respx mocks."""

    @respx.mock
    async def test_resolve_did_web_success(self) -> None:
        """Successful DID document resolution."""
        did = "did:web:example.com"
        url = "https://example.com/.well-known/did.json"
        did_doc = {
            "id": "did:web:example.com",
            "verificationMethod": [
                {
                    "id": "#key-1",
                    "type": "SigstoreIdentity2024",
                    "issuer_email": "test@example.com",
                }
            ],
        }

        respx.get(url).mock(return_value=httpx.Response(200, json=did_doc))

        result = await resolve_did_web(did)
        assert result == did_doc

    @respx.mock
    async def test_resolve_did_web_with_path(self) -> None:
        """Resolve did:web with path components."""
        did = "did:web:example.com:issuer:prod"
        url = "https://example.com/issuer/prod/did.json"
        did_doc = {
            "id": "did:web:example.com:issuer:prod",
            "verificationMethod": [],
        }

        respx.get(url).mock(return_value=httpx.Response(200, json=did_doc))

        result = await resolve_did_web(did)
        assert result == did_doc

    @respx.mock
    async def test_resolve_did_web_404(self) -> None:
        """Handle 404 response."""
        did = "did:web:example.com"
        url = "https://example.com/.well-known/did.json"

        respx.get(url).mock(return_value=httpx.Response(404))

        with pytest.raises(DIDResolutionError, match="status 404"):
            await resolve_did_web(did)

    @respx.mock
    async def test_resolve_did_web_invalid_json(self) -> None:
        """Handle invalid JSON response."""
        did = "did:web:example.com"
        url = "https://example.com/.well-known/did.json"

        respx.get(url).mock(return_value=httpx.Response(200, text="not json"))

        with pytest.raises(DIDResolutionError, match="Failed to parse"):
            await resolve_did_web(did)

    @respx.mock
    async def test_resolve_did_web_missing_id_field(self) -> None:
        """Reject DID doc missing 'id' field."""
        did = "did:web:example.com"
        url = "https://example.com/.well-known/did.json"
        did_doc = {"verificationMethod": []}

        respx.get(url).mock(return_value=httpx.Response(200, json=did_doc))

        with pytest.raises(DIDResolutionError, match="missing required 'id'"):
            await resolve_did_web(did)

    @respx.mock
    async def test_resolve_did_web_id_mismatch(self) -> None:
        """Reject DID doc with mismatched 'id'."""
        did = "did:web:example.com"
        url = "https://example.com/.well-known/did.json"
        did_doc = {"id": "did:web:other.com"}

        respx.get(url).mock(return_value=httpx.Response(200, json=did_doc))

        with pytest.raises(DIDResolutionError, match="DID mismatch"):
            await resolve_did_web(did)

    @respx.mock
    async def test_resolve_did_web_not_json_object(self) -> None:
        """Reject non-object JSON response."""
        did = "did:web:example.com"
        url = "https://example.com/.well-known/did.json"

        respx.get(url).mock(return_value=httpx.Response(200, json=["not", "an", "object"]))

        with pytest.raises(DIDResolutionError, match="not a JSON object"):
            await resolve_did_web(did)


class TestExtractExpectedIdentity:
    """Tests for extract_expected_identity."""

    def test_extract_identity_with_sigstore_identity_2024(self) -> None:
        """Extract identity from verificationMethod with SigstoreIdentity2024 type."""
        did_doc = {
            "id": "did:web:example.com",
            "verificationMethod": [
                {
                    "id": "#key-1",
                    "type": "SigstoreIdentity2024",
                    "issuer_email": "test@example.com",
                    "issuer_uri": "https://example.com/issuer",
                    "fulcio_oidc": "https://oidc.example.com",
                }
            ],
        }

        identity = extract_expected_identity(did_doc)
        assert identity["issuer_email"] == "test@example.com"
        assert identity["issuer_uri"] == "https://example.com/issuer"
        assert identity["issuer_san"] is None
        assert identity["fulcio_oidc"] == "https://oidc.example.com"

    def test_extract_identity_multiple_verification_methods(self) -> None:
        """Extract from first matching SigstoreIdentity2024."""
        did_doc = {
            "id": "did:web:example.com",
            "verificationMethod": [
                {
                    "id": "#key-1",
                    "type": "Other",
                    "issuer_email": "wrong@example.com",
                },
                {
                    "id": "#key-2",
                    "type": "SigstoreIdentity2024",
                    "issuer_email": "correct@example.com",
                },
            ],
        }

        identity = extract_expected_identity(did_doc)
        assert identity["issuer_email"] == "correct@example.com"

    def test_extract_identity_no_matching_type(self) -> None:
        """Return all None when no SigstoreIdentity2024 found."""
        did_doc = {
            "id": "did:web:example.com",
            "verificationMethod": [
                {
                    "id": "#key-1",
                    "type": "Other",
                    "issuer_email": "test@example.com",
                }
            ],
        }

        identity = extract_expected_identity(did_doc)
        assert identity["issuer_email"] is None
        assert identity["issuer_san"] is None
        assert identity["issuer_uri"] is None
        assert identity["fulcio_oidc"] is None

    def test_extract_identity_no_verification_method(self) -> None:
        """Return all None when no verificationMethod exists."""
        did_doc = {"id": "did:web:example.com"}

        identity = extract_expected_identity(did_doc)
        assert identity["issuer_email"] is None
        assert identity["issuer_san"] is None
        assert identity["issuer_uri"] is None
        assert identity["fulcio_oidc"] is None

    def test_extract_identity_empty_verification_method(self) -> None:
        """Return all None when verificationMethod is empty."""
        did_doc = {
            "id": "did:web:example.com",
            "verificationMethod": [],
        }

        identity = extract_expected_identity(did_doc)
        assert identity["issuer_email"] is None
        assert identity["issuer_san"] is None
        assert identity["issuer_uri"] is None
        assert identity["fulcio_oidc"] is None

    def test_extract_identity_partial_fields(self) -> None:
        """Handle partial field specification."""
        did_doc = {
            "id": "did:web:example.com",
            "verificationMethod": [
                {
                    "id": "#key-1",
                    "type": "SigstoreIdentity2024",
                    "issuer_email": "test@example.com",
                    # other fields omitted
                }
            ],
        }

        identity = extract_expected_identity(did_doc)
        assert identity["issuer_email"] == "test@example.com"
        assert identity["issuer_uri"] is None
        assert identity["issuer_san"] is None
        assert identity["fulcio_oidc"] is None
