"""Tests for claim_to_query parsing."""
from __future__ import annotations

from gtv.adapters.parse import claim_to_query


def test_simple_claim() -> None:
    """Extract query from a simple physics claim."""
    text = "Gravitational waves have been detected from colliding neutron stars."
    query = claim_to_query(text)
    assert "gravitational" in query.lower()
    assert "waves" in query.lower()
    assert "detected" in query.lower()
    assert len(query) <= 200


def test_claim_with_stopwords() -> None:
    """Stopwords should be removed."""
    text = "the quick brown fox jumps over the lazy dog"
    query = claim_to_query(text)
    # "the" is a stopword, should be removed.
    assert "the" not in query.lower()
    # "quick", "brown", "fox" should remain.
    assert "quick" in query.lower()
    assert "brown" in query.lower()
    assert "fox" in query.lower()


def test_claim_with_punctuation() -> None:
    """Punctuation should be stripped but hyphens preserved in words."""
    text = "Are X-ray bursts caused by neutron stars? Yes, they are!"
    query = claim_to_query(text)
    assert len(query) <= 200
    assert "ray" in query.lower() or "burst" in query.lower()


def test_empty_claim() -> None:
    """Empty or whitespace-only claims should return empty string."""
    assert claim_to_query("") == ""
    assert claim_to_query("   ") == ""


def test_claim_all_stopwords() -> None:
    """A claim with only stopwords returns empty string."""
    text = "the a is of in to"
    query = claim_to_query(text)
    assert query == ""


def test_max_length_truncation() -> None:
    """Query is truncated to 200 chars max."""
    text = " ".join(["physics"] * 100)
    query = claim_to_query(text)
    assert len(query) <= 200
    assert query  # but non-empty


def test_case_insensitive() -> None:
    """Lowercasing is applied."""
    text = "GRAVITATIONAL WAVES ARE COOL"
    query = claim_to_query(text)
    # "are" is a stopword, should be removed; others are kept.
    assert "gravitational" in query.lower()
    assert "waves" in query.lower()
    assert "cool" in query.lower()
    assert "are" not in query.lower()


def test_numbers_preserved() -> None:
    """Numbers should be preserved if they're not pure punctuation."""
    text = "The 2024 gravitational wave event was significant."
    query = claim_to_query(text)
    # "2024" should be filtered (too short or recognized as number).
    assert "gravitational" in query.lower()
    assert "wave" in query.lower()
