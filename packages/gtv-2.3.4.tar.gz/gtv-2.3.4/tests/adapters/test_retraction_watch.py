"""Tests for RetractionWatchAdapter — mocked and live."""
from __future__ import annotations

import hashlib
import os

import httpx
import pytest
import respx

from gtv.adapters.retraction_watch import RetractionWatchAdapter
from gtv.models import Claim, Domain, Evidence, Stance

# ============================================================================
# Fixtures
# ============================================================================


@pytest.fixture
def canned_retracted_response() -> dict:
    """A minimal Retraction Watch API response for a retracted DOI."""
    return {
        "doi": "10.1038/nature12373",
        "retracted": True,
        "status": "retracted",
        "retraction_date": "2020-01-15",
        "reason": "Concerns regarding data integrity",
    }


@pytest.fixture
def canned_not_retracted_response() -> dict:
    """A response for a valid, non-retracted DOI."""
    return {
        "doi": "10.1038/nature99999",
        "retracted": False,
        "status": "valid",
    }


@pytest.fixture
async def adapter() -> RetractionWatchAdapter:
    """Create a RetractionWatchAdapter instance for testing."""
    adapter = RetractionWatchAdapter()
    yield adapter
    await adapter.close()


# ============================================================================
# Unit Tests (Mocked)
# ============================================================================


@pytest.mark.asyncio
async def test_query_retracted_doi(
    adapter: RetractionWatchAdapter, canned_retracted_response: dict
) -> None:
    """Test query for retracted DOI returns REFUTES evidence."""
    with respx.mock:
        respx.get(
            "https://api.labs.crossref.org/retraction-watch/query"
        ).mock(return_value=httpx.Response(200, json=canned_retracted_response))

        claim = Claim(
            text="According to the paper 10.1038/nature12373, this finding is important.",
            domain=Domain.GENERAL,
        )

        evidence = await adapter.query(claim)

        assert len(evidence) > 0
        assert evidence[0].stance == Stance.REFUTES
        assert evidence[0].source_did == "did:web:retractionwatch.com"
        assert "retracted" in evidence[0].excerpt.lower()
        assert "10.1038/nature12373" in evidence[0].excerpt
        assert len(evidence[0].raw_hash) == 64


@pytest.mark.asyncio
async def test_query_valid_doi(
    adapter: RetractionWatchAdapter, canned_not_retracted_response: dict
) -> None:
    """Test query for valid (non-retracted) DOI returns empty list."""
    with respx.mock:
        respx.get(
            "https://api.labs.crossref.org/retraction-watch/query"
        ).mock(return_value=httpx.Response(200, json=canned_not_retracted_response))

        claim = Claim(
            text="According to 10.1038/nature99999, this is valid.",
            domain=Domain.GENERAL,
        )

        evidence = await adapter.query(claim)

        # Should return empty list (absence of retraction is not support)
        assert len(evidence) == 0


@pytest.mark.asyncio
async def test_query_no_doi_in_claim(adapter: RetractionWatchAdapter) -> None:
    """Test query with no DOI in claim returns empty list."""
    claim = Claim(
        text="This is a claim without any DOI reference.",
        domain=Domain.GENERAL,
    )

    evidence = await adapter.query(claim)
    assert len(evidence) == 0


@pytest.mark.asyncio
async def test_evidence_structure(
    adapter: RetractionWatchAdapter, canned_retracted_response: dict
) -> None:
    """Test that evidence has proper structure and fields."""
    with respx.mock:
        respx.get(
            "https://api.labs.crossref.org/retraction-watch/query"
        ).mock(return_value=httpx.Response(200, json=canned_retracted_response))

        claim = Claim(text="Reference to 10.1038/nature12373", domain=Domain.GENERAL)

        evidence = await adapter.query(claim)
        if evidence:
            ev = evidence[0]
            assert isinstance(ev, Evidence)
            assert ev.claim_id == claim.claim_id
            assert ev.source_did == "did:web:retractionwatch.com"
            assert ev.source_version == "retraction-watch-v1"
            assert ev.stance == Stance.REFUTES
            assert len(ev.excerpt) <= 1200
            assert str(ev.url).startswith("https://retractionwatch.com")
            assert len(ev.raw_hash) == 64
            assert isinstance(ev.raw_hash, str)
            assert all(c in "0123456789abcdef" for c in ev.raw_hash)
            assert ev.retrieved_at.tzinfo is not None


@pytest.mark.asyncio
async def test_network_error_handling(adapter: RetractionWatchAdapter) -> None:
    """Test graceful handling of network errors."""
    with respx.mock:
        respx.get(
            "https://api.labs.crossref.org/retraction-watch/query"
        ).mock(side_effect=httpx.NetworkError("Connection failed"))

        claim = Claim(text="Reference to 10.1038/test", domain=Domain.GENERAL)

        # Should return empty list on network error, not raise
        evidence = await adapter.query(claim)
        assert isinstance(evidence, list)
        assert len(evidence) == 0


@pytest.mark.asyncio
async def test_malformed_json_response(adapter: RetractionWatchAdapter) -> None:
    """Test graceful handling of malformed JSON response."""
    with respx.mock:
        respx.get(
            "https://api.labs.crossref.org/retraction-watch/query"
        ).mock(return_value=httpx.Response(200, text="not valid json"))

        claim = Claim(text="Reference to 10.1038/test", domain=Domain.GENERAL)

        evidence = await adapter.query(claim)
        assert isinstance(evidence, list)
        assert len(evidence) == 0


@pytest.mark.asyncio
async def test_health_check_success(adapter: RetractionWatchAdapter) -> None:
    """Test health check returns HEALTHY on success."""
    with respx.mock:
        respx.get("https://api.labs.crossref.org/retraction-watch/query").mock(
            return_value=httpx.Response(200)
        )

        health = await adapter.health()
        assert health.state == "HEALTHY"
        assert health.checked_at.tzinfo is not None


@pytest.mark.asyncio
async def test_health_check_network_error(adapter: RetractionWatchAdapter) -> None:
    """Test health check returns DOWN on network error."""
    with respx.mock:
        respx.get("https://api.labs.crossref.org/retraction-watch/query").mock(
            side_effect=httpx.NetworkError("Connection failed")
        )

        health = await adapter.health()
        assert health.state == "DOWN"
        assert "Network error" in health.detail


@pytest.mark.asyncio
async def test_snapshot_basic(adapter: RetractionWatchAdapter) -> None:
    """Test snapshot fetches and hashes content."""
    with respx.mock:
        test_content = b"Retraction Watch Article"
        respx.get("https://retractionwatch.com/retracted/?doi=10.1038/test").mock(
            return_value=httpx.Response(200, content=test_content)
        )

        snapshot = await adapter.snapshot("https://retractionwatch.com/retracted/?doi=10.1038/test")
        assert snapshot.url == "https://retractionwatch.com/retracted/?doi=10.1038/test"
        assert snapshot.content == test_content
        assert snapshot.raw_hash == hashlib.sha256(test_content).hexdigest()


@pytest.mark.asyncio
async def test_extract_dois() -> None:
    """Test DOI extraction from claim text."""
    adapter = RetractionWatchAdapter()
    try:
        # Test single DOI
        dois = await adapter._extract_dois("Reference to 10.1038/nature12373 is important")
        assert "10.1038/nature12373" in dois

        # Test multiple DOIs
        dois = await adapter._extract_dois(
            "Papers 10.1038/nature12373 and 10.1126/science.abc1234 were cited"
        )
        assert len(dois) >= 1

        # Test with punctuation
        dois = await adapter._extract_dois("See 10.1038/test123.")
        assert "10.1038/test123" in dois

        # Test no DOI
        dois = await adapter._extract_dois("This claim has no DOI reference")
        assert len(dois) == 0
    finally:
        await adapter.close()


# ============================================================================
# Live Tests (skipped unless GTV_LIVE=1)
# ============================================================================


@pytest.mark.skipif(not os.environ.get("GTV_LIVE"), reason="GTV_LIVE not set")
@pytest.mark.asyncio
async def test_live_retraction_watch_query() -> None:
    """Live test: query actual Retraction Watch API."""
    adapter = RetractionWatchAdapter()
    try:
        # Use a known retracted DOI if possible, or skip
        claim = Claim(
            text="Reference to 10.1038/nature12373 for testing",
            domain=Domain.GENERAL,
        )
        evidence = await adapter.query(claim)

        # Should return empty or evidence (both acceptable in live context)
        assert isinstance(evidence, list)
        if evidence:
            assert evidence[0].source_did == "did:web:retractionwatch.com"
            assert len(evidence[0].raw_hash) == 64
    finally:
        await adapter.close()


@pytest.mark.skipif(not os.environ.get("GTV_LIVE"), reason="GTV_LIVE not set")
@pytest.mark.asyncio
async def test_live_retraction_watch_health() -> None:
    """Live test: check actual Retraction Watch health endpoint."""
    adapter = RetractionWatchAdapter()
    try:
        health = await adapter.health()
        assert health.state in ["HEALTHY", "DEGRADED", "DOWN"]
    finally:
        await adapter.close()
