"""Tests for the DailyMed adapter (W42).

Contract:
- ``query()`` returns well-formed Evidence with a raw_hash that matches
  the excerpt bytes.
- Empty queries return ``[]``, not an exception.
- Upstream errors propagate as exceptions (the registry wraps the
  adapter in the circuit breaker, which turns them into DEGRADED).
- ``health()`` maps 2xx/3xx to HEALTHY, everything else to DEGRADED/DOWN.
"""
from __future__ import annotations

import hashlib

import httpx
import pytest
import respx

from gtv.adapters.dailymed import DailyMedAdapter
from gtv.models import Claim, Domain, Stance, TrustTier

_SEARCH_URL = "https://dailymed.nlm.nih.gov/dailymed/services/v2/spls.json"


@pytest.fixture
def canned_response() -> dict:
    return {
        "metadata": {"total_pages": 1, "total_elements": 2},
        "data": [
            {
                "setid": "11111111-aaaa-bbbb-cccc-222222222222",
                "spl_version": "3",
                "title": "ASPIRIN 81 MG (ACETYLSALICYLIC ACID) TABLET, DELAYED RELEASE",
                "published_date": "2024-05-01",
            },
            {
                "setid": "33333333-dddd-eeee-ffff-444444444444",
                "spl_version": "1",
                "title": "ASPIRIN 325 MG TABLET",
                "published_date": "2023-11-15",
            },
        ],
    }


@pytest.fixture
async def adapter() -> DailyMedAdapter:
    a = DailyMedAdapter()
    yield a
    await a.close()


# --------------------------------------------------------------------


def test_adapter_identity() -> None:
    a = DailyMedAdapter()
    assert a.source_did == "did:web:dailymed.nlm.nih.gov"
    assert a.name == "DailyMed"
    assert a.trust_tier is TrustTier.TIER_1
    assert a.freshness_sla_s > 0


async def test_query_empty_claim_returns_empty(adapter: DailyMedAdapter) -> None:
    claim = Claim(text="a b", domain=Domain.GENERAL)  # all tokens <=1 char after parse
    # claim_to_query drops stopwords and <=1-char tokens; "a b" collapses to "".
    result = await adapter.query(claim)
    assert result == []


async def test_query_returns_evidence(
    adapter: DailyMedAdapter, canned_response: dict
) -> None:
    claim = Claim(text="aspirin 81mg delayed release", domain=Domain.GENERAL)
    with respx.mock:
        respx.get(_SEARCH_URL).mock(
            return_value=httpx.Response(200, json=canned_response)
        )
        result = await adapter.query(claim, max_items=5)

    assert len(result) == 2
    first = result[0]
    assert first.source_did == "did:web:dailymed.nlm.nih.gov"
    assert first.source_version == "dailymed-v2"
    assert first.stance is Stance.NEUTRAL  # labels are neutral reference data
    assert "11111111-aaaa-bbbb-cccc-222222222222" in str(first.url)
    assert "ASPIRIN 81 MG" in first.excerpt
    # raw_hash is sha256 of the excerpt text (as bytes).
    assert (
        first.raw_hash
        == hashlib.sha256(first.excerpt.encode("utf-8")).hexdigest()
    )


async def test_query_respects_max_items(
    adapter: DailyMedAdapter, canned_response: dict
) -> None:
    claim = Claim(text="aspirin", domain=Domain.GENERAL)
    with respx.mock:
        respx.get(_SEARCH_URL).mock(
            return_value=httpx.Response(200, json=canned_response)
        )
        result = await adapter.query(claim, max_items=1)
    assert len(result) == 1


async def test_query_skips_records_missing_required_fields(
    adapter: DailyMedAdapter,
) -> None:
    """A malformed upstream record must be dropped, not crash the batch."""
    bad = {
        "data": [
            {"setid": None, "title": "missing id"},
            {"setid": "ok-id-1", "title": ""},
            {
                "setid": "abc-def-123",
                "title": "OK DRUG",
                "published_date": "2024-01-01",
                "spl_version": "1",
            },
        ]
    }
    claim = Claim(text="drug", domain=Domain.GENERAL)
    with respx.mock:
        respx.get(_SEARCH_URL).mock(return_value=httpx.Response(200, json=bad))
        result = await adapter.query(claim)
    assert len(result) == 1
    assert "OK DRUG" in result[0].excerpt


async def test_query_propagates_http_error(adapter: DailyMedAdapter) -> None:
    claim = Claim(text="aspirin", domain=Domain.GENERAL)
    with respx.mock:
        respx.get(_SEARCH_URL).mock(return_value=httpx.Response(503))
        with pytest.raises(httpx.HTTPStatusError):
            await adapter.query(claim)


async def test_health_healthy(adapter: DailyMedAdapter) -> None:
    with respx.mock:
        respx.get(_SEARCH_URL).mock(
            return_value=httpx.Response(200, json={"data": []})
        )
        h = await adapter.health()
    assert h.state == "HEALTHY"


async def test_health_degraded_on_500(adapter: DailyMedAdapter) -> None:
    with respx.mock:
        respx.get(_SEARCH_URL).mock(return_value=httpx.Response(500))
        h = await adapter.health()
    assert h.state == "DEGRADED"
    assert "500" in h.detail
