"""Adapter tests."""
