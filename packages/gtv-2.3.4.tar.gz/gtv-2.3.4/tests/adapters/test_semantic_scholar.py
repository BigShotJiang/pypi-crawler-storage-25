"""Tests for SemanticScholarAdapter — mocked and live."""
from __future__ import annotations

import hashlib
import os

import httpx
import pytest
import respx

from gtv.adapters.semantic_scholar import SemanticScholarAdapter
from gtv.models import Claim, Domain, SourceType, Stance, TrustTier

# ============================================================================
# Fixtures
# ============================================================================


@pytest.fixture
def canned_semantic_scholar_response() -> str:
    """A minimal JSON response from Semantic Scholar API with 2 papers."""
    return """{
  "data": [
    {
      "title": "Gravitational Waves from Merging Neutron Stars",
      "abstract": "We present observations of gravitational waves from the merger of two neutron stars. The detection was made using advanced LIGO and Virgo detectors. The signal shows clear evidence of mass transfer and ejecta formation.",
      "year": 2024,
      "authors": [
        {"name": "Smith, John"},
        {"name": "Johnson, Alice"}
      ],
      "externalIds": {
        "CorpusId": 12345678,
        "DOI": "10.1234/example.doi"
      }
    },
    {
      "title": "Black Hole Formation in Gravitational Collapse",
      "abstract": "We study the formation of black holes through gravitational collapse. Our numerical simulations use state-of-the-art adaptive mesh refinement techniques.",
      "year": 2023,
      "authors": [
        {"name": "Brown, Charles"}
      ],
      "externalIds": {
        "CorpusId": 12345679
      }
    }
  ]
}
"""


@pytest.fixture
async def adapter() -> SemanticScholarAdapter:
    """Create a SemanticScholarAdapter instance for testing."""
    adapter = SemanticScholarAdapter()
    yield adapter
    await adapter.close()


# ============================================================================
# Unit Tests (Mocked)
# ============================================================================


@pytest.mark.asyncio
async def test_query_returns_evidence(
    adapter: SemanticScholarAdapter, canned_semantic_scholar_response: str
) -> None:
    """Query should return list of Evidence records with valid fields."""
    claim = Claim(text="gravitational waves neutron stars", domain=Domain.PHYSICS)

    with respx.mock:
        respx.get(
            "https://api.semanticscholar.org/graph/v1/paper/search",
            params={
                "query": "gravitational waves neutron stars",
                "limit": 5,
                "fields": "title,abstract,year,authors,externalIds",
            },
        ).mock(
            return_value=httpx.Response(200, text=canned_semantic_scholar_response)
        )

        results = await adapter.query(claim, max_items=5)

    assert len(results) == 2
    for evidence in results:
        # Check all required fields.
        assert evidence.claim_id == claim.claim_id
        assert evidence.source_did == "did:web:api.semanticscholar.org"
        assert evidence.source_version == "s2-api-v1"
        assert evidence.stance == Stance.NEUTRAL
        assert "semanticscholar.org" in str(evidence.url)
        assert len(evidence.raw_hash) == 64
        assert all(c in "0123456789abcdef" for c in evidence.raw_hash)
        assert evidence.retrieved_at.tzinfo is not None


@pytest.mark.asyncio
async def test_query_uses_abstract(
    adapter: SemanticScholarAdapter, canned_semantic_scholar_response: str
) -> None:
    """Excerpt should use abstract field."""
    claim = Claim(text="gravitational waves", domain=Domain.PHYSICS)

    with respx.mock:
        respx.get(
            "https://api.semanticscholar.org/graph/v1/paper/search",
            params={
                "query": "gravitational waves",
                "limit": 5,
                "fields": "title,abstract,year,authors,externalIds",
            },
        ).mock(
            return_value=httpx.Response(200, text=canned_semantic_scholar_response)
        )

        results = await adapter.query(claim, max_items=5)

    # First entry should have abstract as excerpt.
    expected_excerpt = (
        "We present observations of gravitational waves from the merger of two "
        "neutron stars. The detection was made using advanced LIGO and Virgo detectors. "
        "The signal shows clear evidence of mass transfer and ejecta formation."
    )
    assert results[0].excerpt == expected_excerpt


@pytest.mark.asyncio
async def test_query_fallback_to_title_when_no_abstract(
    adapter: SemanticScholarAdapter,
) -> None:
    """If abstract is missing, excerpt should use title."""
    response = """{
  "data": [
    {
      "title": "A Study of Quantum Mechanics",
      "year": 2024,
      "externalIds": {
        "CorpusId": 99999999
      }
    }
  ]
}
"""
    claim = Claim(text="quantum mechanics", domain=Domain.PHYSICS)

    with respx.mock:
        respx.get(
            "https://api.semanticscholar.org/graph/v1/paper/search",
            params={
                "query": "quantum mechanics",
                "limit": 5,
                "fields": "title,abstract,year,authors,externalIds",
            },
        ).mock(return_value=httpx.Response(200, text=response))

        results = await adapter.query(claim, max_items=5)

    assert len(results) == 1
    assert results[0].excerpt == "A Study of Quantum Mechanics"


@pytest.mark.asyncio
async def test_query_raw_hash_matches_excerpt(
    adapter: SemanticScholarAdapter, canned_semantic_scholar_response: str
) -> None:
    """raw_hash should match sha256 of the excerpt bytes."""
    claim = Claim(text="gravitational waves", domain=Domain.PHYSICS)

    with respx.mock:
        respx.get(
            "https://api.semanticscholar.org/graph/v1/paper/search",
            params={
                "query": "gravitational waves",
                "limit": 5,
                "fields": "title,abstract,year,authors,externalIds",
            },
        ).mock(
            return_value=httpx.Response(200, text=canned_semantic_scholar_response)
        )

        results = await adapter.query(claim, max_items=5)

    # Compute expected hash.
    first_excerpt = results[0].excerpt
    expected_hash = hashlib.sha256(first_excerpt.encode("utf-8")).hexdigest()
    assert results[0].raw_hash == expected_hash


@pytest.mark.asyncio
async def test_query_timeout_propagates(adapter: SemanticScholarAdapter) -> None:
    """Timeout exceptions should be raised, not swallowed."""
    claim = Claim(text="test", domain=Domain.PHYSICS)

    with respx.mock:
        respx.get(
            "https://api.semanticscholar.org/graph/v1/paper/search",
            params={
                "query": "test",
                "limit": 5,
                "fields": "title,abstract,year,authors,externalIds",
            },
        ).mock(side_effect=httpx.TimeoutException("Timeout"))

        with pytest.raises(httpx.TimeoutException):
            await adapter.query(claim, max_items=5)


@pytest.mark.asyncio
async def test_query_429_rate_limit_propagates(
    adapter: SemanticScholarAdapter,
) -> None:
    """429 rate limit responses should be raised, not swallowed."""
    claim = Claim(text="test", domain=Domain.PHYSICS)

    with respx.mock:
        respx.get(
            "https://api.semanticscholar.org/graph/v1/paper/search",
            params={
                "query": "test",
                "limit": 5,
                "fields": "title,abstract,year,authors,externalIds",
            },
        ).mock(return_value=httpx.Response(429))

        with pytest.raises(httpx.HTTPStatusError):
            await adapter.query(claim, max_items=5)


@pytest.mark.asyncio
async def test_query_empty_results() -> None:
    """Query with no matching results should return empty list."""
    response = '{"data": []}'
    adapter = SemanticScholarAdapter()
    try:
        claim = Claim(text="xyzabc123nonexistent", domain=Domain.PHYSICS)

        with respx.mock:
            respx.get(
                "https://api.semanticscholar.org/graph/v1/paper/search",
                params={
                    "query": "xyzabc123nonexistent",
                    "limit": 5,
                    "fields": "title,abstract,year,authors,externalIds",
                },
            ).mock(return_value=httpx.Response(200, text=response))

            results = await adapter.query(claim, max_items=5)

        assert results == []
    finally:
        await adapter.close()


@pytest.mark.asyncio
async def test_query_corpus_id_url_pattern(
    adapter: SemanticScholarAdapter,
) -> None:
    """URLs should be built from CorpusId using S2 pattern."""
    response = """{
  "data": [
    {
      "title": "Test Paper",
      "abstract": "Test abstract",
      "externalIds": {
        "CorpusId": 87654321
      }
    }
  ]
}
"""
    claim = Claim(text="test", domain=Domain.PHYSICS)

    with respx.mock:
        respx.get(
            "https://api.semanticscholar.org/graph/v1/paper/search",
            params={
                "query": "test",
                "limit": 5,
                "fields": "title,abstract,year,authors,externalIds",
            },
        ).mock(return_value=httpx.Response(200, text=response))

        results = await adapter.query(claim, max_items=5)

    assert len(results) == 1
    assert "87654321" in str(results[0].url)


@pytest.mark.asyncio
async def test_query_doi_url_pattern(
    adapter: SemanticScholarAdapter,
) -> None:
    """URLs should use doi.org pattern when only DOI is available."""
    response = """{
  "data": [
    {
      "title": "Test Paper",
      "abstract": "Test abstract",
      "externalIds": {
        "DOI": "10.1234/example"
      }
    }
  ]
}
"""
    claim = Claim(text="test", domain=Domain.PHYSICS)

    with respx.mock:
        respx.get(
            "https://api.semanticscholar.org/graph/v1/paper/search",
            params={
                "query": "test",
                "limit": 5,
                "fields": "title,abstract,year,authors,externalIds",
            },
        ).mock(return_value=httpx.Response(200, text=response))

        results = await adapter.query(claim, max_items=5)

    assert len(results) == 1
    assert "doi.org/10.1234/example" in str(results[0].url)


@pytest.mark.asyncio
async def test_health_check_healthy(adapter: SemanticScholarAdapter) -> None:
    """Health check should return HEALTHY on 200."""
    with respx.mock:
        respx.get(
            "https://api.semanticscholar.org/graph/v1/paper/search",
            params={
                "query": "test",
                "limit": "1",
            },
        ).mock(return_value=httpx.Response(200))

        health = await adapter.health()

    assert health.state == "HEALTHY"


@pytest.mark.asyncio
async def test_health_check_degraded_on_error(adapter: SemanticScholarAdapter) -> None:
    """Health check should return DEGRADED on non-2xx status."""
    with respx.mock:
        respx.get(
            "https://api.semanticscholar.org/graph/v1/paper/search",
            params={
                "query": "test",
                "limit": "1",
            },
        ).mock(return_value=httpx.Response(503))

        health = await adapter.health()

    assert health.state == "DEGRADED"
    assert "503" in health.detail


@pytest.mark.asyncio
async def test_health_check_down_on_timeout(adapter: SemanticScholarAdapter) -> None:
    """Health check should return DOWN on timeout."""
    with respx.mock:
        respx.get(
            "https://api.semanticscholar.org/graph/v1/paper/search",
            params={
                "query": "test",
                "limit": "1",
            },
        ).mock(side_effect=httpx.TimeoutException("Timeout"))

        health = await adapter.health()

    assert health.state == "DOWN"
    assert "timeout" in health.detail.lower()


@pytest.mark.asyncio
async def test_adapter_metadata() -> None:
    """Adapter should expose correct metadata."""
    adapter = SemanticScholarAdapter()
    try:
        assert adapter.source_did == "did:web:api.semanticscholar.org"
        assert adapter.name == "Semantic Scholar"
        assert adapter.source_type == SourceType.REFERENCE_DATA
        assert adapter.trust_tier == TrustTier.TIER_2
        assert adapter.freshness_sla_s == 5
    finally:
        await adapter.close()


@pytest.mark.asyncio
async def test_close_releases_client() -> None:
    """Calling close() should release the owned client."""
    adapter = SemanticScholarAdapter()
    assert adapter._owns_client is True
    await adapter.close()
    # After close, client should be closed (httpx tracks this).
    assert adapter._client.is_closed is True


@pytest.mark.asyncio
async def test_external_client_not_closed() -> None:
    """If an external client is provided, close() should not close it."""
    external_client = httpx.AsyncClient()
    adapter = SemanticScholarAdapter(client=external_client)
    assert adapter._owns_client is False
    await adapter.close()
    # External client should not be closed by adapter.
    assert not external_client.is_closed


@pytest.mark.asyncio
async def test_api_key_optional() -> None:
    """API key should be optional (can be None)."""
    adapter = SemanticScholarAdapter()
    try:
        # Without setting GTV_S2_API_KEY, _api_key should be None.
        assert adapter._api_key is None or isinstance(adapter._api_key, str)
    finally:
        await adapter.close()


# ============================================================================
# Integration Test (Live)
# ============================================================================


@pytest.mark.asyncio
async def test_semantic_scholar_live_query() -> None:
    """Live integration test: query real Semantic Scholar API.

    Only runs if GTV_LIVE=1 is set.
    """
    if not os.getenv("GTV_LIVE"):
        pytest.skip("GTV_LIVE not set; skipping live test")

    adapter = SemanticScholarAdapter()
    try:
        # Query with a simple physics claim.
        claim = Claim(
            text="black hole thermodynamics entropy",
            domain=Domain.PHYSICS,
        )
        results = await adapter.query(claim, max_items=3)

        # We should get at least one result.
        assert len(results) >= 1

        # Each result should be valid.
        for evidence in results:
            assert evidence.claim_id == claim.claim_id
            assert evidence.source_did == "did:web:api.semanticscholar.org"
            assert evidence.source_version == "s2-api-v1"
            assert evidence.stance == Stance.NEUTRAL
            assert evidence.url
            assert len(evidence.raw_hash) == 64
            assert evidence.retrieved_at.tzinfo is not None
            assert 0 < len(evidence.excerpt) <= 1200

    finally:
        await adapter.close()
