"""Tests for the Wikidata adapter.

Contract:
- ``query()`` returns well-formed Evidence with a raw_hash that matches
  the excerpt bytes.
- Empty queries return ``[]``, not an exception.
- Upstream errors propagate as exceptions (the registry wraps the
  adapter in the circuit breaker, which turns them into DEGRADED).
- ``health()`` maps 2xx/3xx to HEALTHY, everything else to DEGRADED/DOWN.
"""
from __future__ import annotations

import hashlib

import httpx
import pytest
import respx

from gtv.adapters.wikidata import WikidataAdapter
from gtv.models import Claim, Domain, Stance, TrustTier

_ENDPOINT = "https://query.wikidata.org/sparql"


@pytest.fixture
def canned_response() -> dict:
    return {
        "results": {
            "bindings": [
                {
                    "item": {"value": "http://www.wikidata.org/entity/Q5"},
                    "itemLabel": {"value": "human"},
                    "itemDescription": {
                        "value": "common name of species of animal, Homo sapiens"
                    },
                },
                {
                    "item": {"value": "http://www.wikidata.org/entity/Q6581097"},
                    "itemLabel": {"value": "female human"},
                    "itemDescription": {"value": "woman; girls of any age; a female human"},
                },
            ]
        }
    }


@pytest.fixture
async def adapter() -> WikidataAdapter:
    a = WikidataAdapter()
    yield a
    await a.close()


# --------------------------------------------------------------------


def test_adapter_identity() -> None:
    a = WikidataAdapter()
    assert a.source_did == "did:web:wikidata.org"
    assert a.name == "Wikidata"
    assert a.source_type == "ENCYCLOPEDIA"
    assert a.trust_tier is TrustTier.TIER_2
    assert a.freshness_sla_s > 0


async def test_query_empty_claim_returns_empty(adapter: WikidataAdapter) -> None:
    claim = Claim(text="a b", domain=Domain.GENERAL)  # all tokens <=1 char
    result = await adapter.query(claim)
    assert result == []


async def test_query_returns_evidence(
    adapter: WikidataAdapter, canned_response: dict
) -> None:
    claim = Claim(text="what is a human", domain=Domain.GENERAL)
    with respx.mock:
        respx.get(_ENDPOINT).mock(
            return_value=httpx.Response(200, json=canned_response)
        )
        result = await adapter.query(claim, max_items=5)

    assert len(result) == 2
    first = result[0]
    assert first.source_did == "did:web:wikidata.org"
    assert first.source_version == "wikidata-sparql"
    assert first.stance is Stance.NEUTRAL
    assert "http://www.wikidata.org/entity/Q5" in str(first.url)
    assert "human" in first.excerpt
    assert (
        first.raw_hash
        == hashlib.sha256(first.excerpt.encode("utf-8")).hexdigest()
    )


async def test_query_respects_max_items(
    adapter: WikidataAdapter, canned_response: dict
) -> None:
    claim = Claim(text="human", domain=Domain.GENERAL)
    with respx.mock:
        respx.get(_ENDPOINT).mock(
            return_value=httpx.Response(200, json=canned_response)
        )
        result = await adapter.query(claim, max_items=1)
    assert len(result) == 1


async def test_query_skips_records_missing_label(adapter: WikidataAdapter) -> None:
    """Records without itemLabel must be skipped."""
    bad = {
        "results": {
            "bindings": [
                {
                    "item": {"value": "http://www.wikidata.org/entity/Q123"},
                    "itemLabel": {"value": ""},  # empty label
                    "itemDescription": {"value": "some description"},
                },
                {
                    "item": {"value": "http://www.wikidata.org/entity/Q456"},
                    "itemLabel": {"value": "good label"},
                    "itemDescription": {"value": "good description"},
                },
            ]
        }
    }
    claim = Claim(text="something", domain=Domain.GENERAL)
    with respx.mock:
        respx.get(_ENDPOINT).mock(return_value=httpx.Response(200, json=bad))
        result = await adapter.query(claim)
    assert len(result) == 1
    assert "good label" in result[0].excerpt


async def test_query_propagates_http_error(adapter: WikidataAdapter) -> None:
    claim = Claim(text="query", domain=Domain.GENERAL)
    with respx.mock:
        respx.get(_ENDPOINT).mock(return_value=httpx.Response(503))
        with pytest.raises(httpx.HTTPStatusError):
            await adapter.query(claim)


async def test_health_healthy(adapter: WikidataAdapter) -> None:
    with respx.mock:
        respx.get(_ENDPOINT).mock(
            return_value=httpx.Response(200, json={"results": {"bindings": []}})
        )
        h = await adapter.health()
    assert h.state == "HEALTHY"
    assert "responsive" in h.detail.lower()


async def test_health_degraded_on_error(adapter: WikidataAdapter) -> None:
    with respx.mock:
        respx.get(_ENDPOINT).mock(return_value=httpx.Response(500))
        h = await adapter.health()
    assert h.state == "DEGRADED"
    assert "500" in h.detail
