"""Tests for adapter horizontal sharding (ShardConfig, shard_for_claim, ShardedAdapter)."""
from __future__ import annotations

from collections import Counter

import httpx
import pytest
import respx

from gtv.adapters.base import RawSnapshot, SourceAdapter
from gtv.adapters.sharding import (
    ShardConfig,
    ShardedAdapter,
    _forward_to_shard,
    _parse_shard_peers,
    load_shard_config_from_env,
    owns,
    shard_for_claim,
)
from gtv.models import Claim, Evidence, HealthStatus, Stance, TrustTier


class FakeAdapter(SourceAdapter):
    """A fake adapter for testing ShardedAdapter."""

    def __init__(self, name: str = "fake") -> None:
        self.source_did = "did:web:fake.example"
        self.name = name
        self.trust_tier = TrustTier.TIER_1
        self.freshness_sla_s = 300
        self.source_type = "web"
        self.query_call_count = 0
        self.close_call_count = 0

    async def query(self, claim: Claim, max_items: int = 5) -> list[Evidence]:
        """Count calls and return fake evidence."""
        self.query_call_count += 1
        return [
            Evidence(
                evidence_id=f"ev-local-{self.query_call_count}",
                claim_id=claim.claim_id,
                source_did=self.source_did,
                source_version="1.0",
                stance=Stance.SUPPORTS,
                excerpt="Local evidence",
                url="https://fake.example/doc",
                retrieved_at=claim.submitted_at,
                raw_hash="a" * 64,
            ),
        ]

    async def snapshot(self, url: str) -> RawSnapshot:
        """Return fake snapshot."""
        return RawSnapshot(
            url=url,
            content=b"fake content",
            retrieved_at_iso="2026-04-22T00:00:00Z",
        )

    async def health(self) -> HealthStatus:
        """Return healthy status."""
        return HealthStatus(state="HEALTHY", detail="fake is alive")

    async def close(self) -> None:
        """Count calls."""
        self.close_call_count += 1


# ============================================================================
# ShardConfig tests
# ============================================================================


def test_shard_config_valid() -> None:
    """Valid ShardConfig construction succeeds."""
    cfg = ShardConfig(total_shards=4, my_shard_id=2)
    assert cfg.total_shards == 4
    assert cfg.my_shard_id == 2


def test_shard_config_validation_my_shard_id_out_of_range() -> None:
    """my_shard_id >= total_shards raises ValueError."""
    with pytest.raises(ValueError, match=r"my_shard_id.*must be <"):
        ShardConfig(total_shards=4, my_shard_id=4)

    with pytest.raises(ValueError, match=r"my_shard_id.*must be <"):
        ShardConfig(total_shards=4, my_shard_id=10)


# ============================================================================
# load_shard_config_from_env tests
# ============================================================================


def test_load_shard_config_unset_returns_none(monkeypatch: pytest.MonkeyPatch) -> None:
    """load_shard_config_from_env returns None if either env var unset."""
    monkeypatch.delenv("GTV_TOTAL_SHARDS", raising=False)
    monkeypatch.delenv("GTV_SHARD_ID", raising=False)
    assert load_shard_config_from_env() is None


def test_load_shard_config_partial_unset_returns_none(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """load_shard_config_from_env returns None if only one env var set."""
    monkeypatch.setenv("GTV_TOTAL_SHARDS", "4")
    monkeypatch.delenv("GTV_SHARD_ID", raising=False)
    assert load_shard_config_from_env() is None

    monkeypatch.delenv("GTV_TOTAL_SHARDS")
    monkeypatch.setenv("GTV_SHARD_ID", "2")
    assert load_shard_config_from_env() is None


def test_load_shard_config_both_set(monkeypatch: pytest.MonkeyPatch) -> None:
    """load_shard_config_from_env builds config when both vars set."""
    monkeypatch.setenv("GTV_TOTAL_SHARDS", "4")
    monkeypatch.setenv("GTV_SHARD_ID", "2")
    cfg = load_shard_config_from_env()
    assert cfg is not None
    assert cfg.total_shards == 4
    assert cfg.my_shard_id == 2


def test_load_shard_config_validation(monkeypatch: pytest.MonkeyPatch) -> None:
    """load_shard_config_from_env validates config."""
    monkeypatch.setenv("GTV_TOTAL_SHARDS", "4")
    monkeypatch.setenv("GTV_SHARD_ID", "5")
    with pytest.raises(ValueError, match=r"my_shard_id.*must be <"):
        load_shard_config_from_env()


# ============================================================================
# shard_for_claim tests
# ============================================================================


def test_shard_for_claim_deterministic() -> None:
    """shard_for_claim is deterministic — same inputs always yield same shard."""
    claim_id = "claim-123"
    source_did = "did:web:example"
    total_shards = 8

    results = [
        shard_for_claim(claim_id, source_did, total_shards) for _ in range(10)
    ]
    assert len(set(results)) == 1, "Result should be identical across calls"


def test_shard_for_claim_uniform_distribution() -> None:
    """shard_for_claim distributes roughly uniformly across shards."""
    total_shards = 4
    source_did = "did:web:example"

    # Generate 1000 claims and count shard assignments
    counts = Counter()
    for i in range(1000):
        claim_id = f"claim-{i}"
        shard = shard_for_claim(claim_id, source_did, total_shards)
        counts[shard] += 1

    # Each shard should get roughly 250 items (1000/4)
    # Allow ±20% variance per the spec
    expected_per_shard = 1000 / total_shards
    tolerance = expected_per_shard * 0.2

    for shard in range(total_shards):
        count = counts[shard]
        assert (
            abs(count - expected_per_shard) <= tolerance
        ), f"Shard {shard} got {count}, expected ~{expected_per_shard} ± {tolerance}"


def test_shard_for_claim_respects_total_shards() -> None:
    """shard_for_claim returns shard in [0, total_shards)."""
    for total_shards in [1, 4, 16, 100]:
        for i in range(100):
            shard = shard_for_claim(f"claim-{i}", "did:web:example", total_shards)
            assert 0 <= shard < total_shards


# ============================================================================
# owns tests
# ============================================================================


def test_owns_returns_true_for_owned_claim() -> None:
    """owns returns True when this shard owns the claim."""
    cfg = ShardConfig(total_shards=4, my_shard_id=1)

    # Find a claim_id that hashes to shard 1
    for i in range(1000):
        claim_id = f"claim-{i}"
        source_did = "did:web:example"
        if shard_for_claim(claim_id, source_did, cfg.total_shards) == cfg.my_shard_id:
            assert owns(claim_id, source_did, cfg) is True
            break
    else:
        pytest.fail("Could not find a claim hashing to shard 1")


def test_owns_returns_false_for_unowned_claim() -> None:
    """owns returns False when another shard owns the claim."""
    cfg = ShardConfig(total_shards=4, my_shard_id=1)

    # Find a claim_id that hashes to a different shard
    for i in range(1000):
        claim_id = f"claim-{i}"
        source_did = "did:web:example"
        shard = shard_for_claim(claim_id, source_did, cfg.total_shards)
        if shard != cfg.my_shard_id:
            assert owns(claim_id, source_did, cfg) is False
            break
    else:
        pytest.fail("Could not find a claim not hashing to shard 1")


# ============================================================================
# _parse_shard_peers tests
# ============================================================================


def test_parse_shard_peers_empty_env(monkeypatch: pytest.MonkeyPatch) -> None:
    """_parse_shard_peers returns empty dict if GTV_SHARD_PEERS unset."""
    monkeypatch.delenv("GTV_SHARD_PEERS", raising=False)
    peers = _parse_shard_peers()
    assert peers == {}


def test_parse_shard_peers_valid_format(monkeypatch: pytest.MonkeyPatch) -> None:
    """_parse_shard_peers parses GTV_SHARD_PEERS correctly."""
    monkeypatch.setenv("GTV_SHARD_PEERS", "0=http://w0:8080,1=http://w1:8080")
    peers = _parse_shard_peers()
    assert peers == {0: "http://w0:8080", 1: "http://w1:8080"}


def test_parse_shard_peers_ignores_malformed(monkeypatch: pytest.MonkeyPatch) -> None:
    """_parse_shard_peers ignores malformed entries with warning."""
    monkeypatch.setenv(
        "GTV_SHARD_PEERS", "0=http://w0:8080,bad,1=http://w1:8080"
    )
    peers = _parse_shard_peers()
    # Should parse the valid ones and ignore 'bad'
    assert peers == {0: "http://w0:8080", 1: "http://w1:8080"}


# ============================================================================
# _forward_to_shard tests
# ============================================================================


@pytest.mark.asyncio
async def test_forward_to_shard_success() -> None:
    """_forward_to_shard makes HTTP request and parses response."""
    async with httpx.AsyncClient() as client:
        with respx.mock:
            # Mock the endpoint
            route = respx.post("http://peer:8080/internal/adapter/did:web:fake/query")
            route.mock(
                return_value=httpx.Response(
                    200,
                    json=[
                        {
                            "evidence_id": "ev-1",
                            "claim_id": "claim-1",
                            "source_did": "did:web:fake",
                            "source_version": "1.0",
                            "stance": "SUPPORTS",
                            "excerpt": "Remote evidence",
                            "url": "https://example.com",
                            "retrieved_at": "2026-04-22T00:00:00Z",
                            "raw_hash": "a" * 64,
                        }
                    ],
                )
            )

            result = await _forward_to_shard(
                "http://peer:8080",
                client,
                "claim-1",
                "test claim",
                "physics",
                "did:web:fake",
                5,
            )

            assert len(result) == 1
            assert result[0].evidence_id == "ev-1"
            assert route.called


@pytest.mark.asyncio
async def test_forward_to_shard_http_error_returns_empty() -> None:
    """_forward_to_shard returns [] on HTTP error."""
    async with httpx.AsyncClient() as client:
        with respx.mock:
            route = respx.post("http://peer:8080/internal/adapter/did:web:fake/query")
            route.mock(return_value=httpx.Response(500))

            result = await _forward_to_shard(
                "http://peer:8080",
                client,
                "claim-1",
                "test claim",
                "physics",
                "did:web:fake",
                5,
            )

            assert result == []


# ============================================================================
# ShardedAdapter tests
# ============================================================================


@pytest.mark.asyncio
async def test_sharded_adapter_local_owned_path() -> None:
    """ShardedAdapter calls inner.query for owned claims."""
    inner = FakeAdapter()
    cfg = ShardConfig(total_shards=4, my_shard_id=0)
    adapter = ShardedAdapter(inner, cfg)

    # Create a claim that hashes to shard 0
    for i in range(1000):
        claim_id = f"claim-{i}"
        if shard_for_claim(claim_id, inner.source_did, cfg.total_shards) == 0:
            claim = Claim(claim_id=claim_id, text="test")
            result = await adapter.query(claim, max_items=5)
            assert len(result) == 1
            assert inner.query_call_count == 1
            break
    else:
        pytest.fail("Could not find owned claim")

    await adapter.close()


@pytest.mark.asyncio
async def test_sharded_adapter_forward_success() -> None:
    """ShardedAdapter forwards unowned claims via HTTP."""
    inner = FakeAdapter()
    cfg = ShardConfig(total_shards=4, my_shard_id=0)

    async with httpx.AsyncClient() as client:
        adapter = ShardedAdapter(inner, cfg, client=client)
        # Manually set peer URLs for testing
        adapter._peer_urls = {1: "http://w1:8080"}

        # Find a claim that hashes to shard 1
        claim_id_to_use = None
        for i in range(1000):
            claim_id = f"claim-{i}"
            if shard_for_claim(claim_id, inner.source_did, cfg.total_shards) == 1:
                claim_id_to_use = claim_id
                break

        if claim_id_to_use is None:
            pytest.fail("Could not find claim for shard 1")

        with respx.mock:
            route = respx.post(
                f"http://w1:8080/internal/adapter/{inner.source_did}/query"
            )
            route.mock(
                return_value=httpx.Response(
                    200,
                    json=[
                        {
                            "evidence_id": "ev-remote",
                            "claim_id": claim_id_to_use,
                            "source_did": inner.source_did,
                            "source_version": "1.0",
                            "stance": "SUPPORTS",
                            "excerpt": "Remote evidence",
                            "url": "https://example.com",
                            "retrieved_at": "2026-04-22T00:00:00Z",
                            "raw_hash": "b" * 64,
                        }
                    ],
                )
            )

            claim = Claim(claim_id=claim_id_to_use, text="test")
            result = await adapter.query(claim, max_items=5)

            # Should get remote evidence
            assert len(result) == 1
            assert result[0].evidence_id == "ev-remote"
            # Inner should not be called
            assert inner.query_call_count == 0

        await adapter.close()


@pytest.mark.asyncio
async def test_sharded_adapter_forward_fallback_on_error() -> None:
    """ShardedAdapter falls back to local on forward failure."""
    inner = FakeAdapter()
    cfg = ShardConfig(total_shards=4, my_shard_id=0)

    async with httpx.AsyncClient() as client:
        adapter = ShardedAdapter(inner, cfg, client=client)
        adapter._peer_urls = {1: "http://w1:8080"}

        # Find a claim for shard 1
        claim_id_to_use = None
        for i in range(1000):
            claim_id = f"claim-{i}"
            if shard_for_claim(claim_id, inner.source_did, cfg.total_shards) == 1:
                claim_id_to_use = claim_id
                break

        if claim_id_to_use is None:
            pytest.fail("Could not find claim for shard 1")

        with respx.mock:
            route = respx.post(
                f"http://w1:8080/internal/adapter/{inner.source_did}/query"
            )
            route.mock(return_value=httpx.Response(500))

            claim = Claim(claim_id=claim_id_to_use, text="test")
            result = await adapter.query(claim, max_items=5)

            # Should fall back to local
            assert len(result) == 1
            assert result[0].evidence_id == "ev-local-1"
            assert inner.query_call_count == 1

        await adapter.close()


@pytest.mark.asyncio
async def test_sharded_adapter_fallback_missing_peer_url() -> None:
    """ShardedAdapter falls back to local if peer URL missing."""
    inner = FakeAdapter()
    cfg = ShardConfig(total_shards=4, my_shard_id=0)

    async with httpx.AsyncClient() as client:
        adapter = ShardedAdapter(inner, cfg, client=client)
        adapter._peer_urls = {}  # No peers configured

        # Find a claim for shard 1 (which won't be in peer_urls)
        claim_id_to_use = None
        for i in range(1000):
            claim_id = f"claim-{i}"
            if shard_for_claim(claim_id, inner.source_did, cfg.total_shards) == 1:
                claim_id_to_use = claim_id
                break

        if claim_id_to_use is None:
            pytest.fail("Could not find claim for shard 1")

        claim = Claim(claim_id=claim_id_to_use, text="test")
        result = await adapter.query(claim, max_items=5)

        # Should fall back to local
        assert len(result) == 1
        assert result[0].evidence_id == "ev-local-1"
        assert inner.query_call_count == 1

        await adapter.close()


@pytest.mark.asyncio
async def test_sharded_adapter_delegates_snapshot() -> None:
    """ShardedAdapter.snapshot delegates to inner."""
    inner = FakeAdapter()
    cfg = ShardConfig(total_shards=4, my_shard_id=0)

    async with httpx.AsyncClient() as client:
        adapter = ShardedAdapter(inner, cfg, client=client)
        snapshot = await adapter.snapshot("https://example.com/doc")
        assert snapshot.url == "https://example.com/doc"
        assert snapshot.content == b"fake content"
        await adapter.close()


@pytest.mark.asyncio
async def test_sharded_adapter_delegates_health() -> None:
    """ShardedAdapter.health delegates to inner."""
    inner = FakeAdapter()
    cfg = ShardConfig(total_shards=4, my_shard_id=0)

    async with httpx.AsyncClient() as client:
        adapter = ShardedAdapter(inner, cfg, client=client)
        health = await adapter.health()
        assert health.state == "HEALTHY"
        await adapter.close()


@pytest.mark.asyncio
async def test_sharded_adapter_close() -> None:
    """ShardedAdapter.close calls inner.close."""
    inner = FakeAdapter()
    cfg = ShardConfig(total_shards=4, my_shard_id=0)

    async with httpx.AsyncClient() as client:
        adapter = ShardedAdapter(inner, cfg, client=client)
        await adapter.close()
        assert inner.close_call_count == 1


@pytest.mark.asyncio
async def test_sharded_adapter_mirrors_inner_attrs() -> None:
    """ShardedAdapter mirrors inner adapter attributes."""
    inner = FakeAdapter(name="MyFake")
    cfg = ShardConfig(total_shards=4, my_shard_id=0)

    async with httpx.AsyncClient() as client:
        adapter = ShardedAdapter(inner, cfg, client=client)
        assert adapter.source_did == inner.source_did
        assert adapter.name == inner.name
        assert adapter.trust_tier == inner.trust_tier
        assert adapter.freshness_sla_s == inner.freshness_sla_s
        await adapter.close()
