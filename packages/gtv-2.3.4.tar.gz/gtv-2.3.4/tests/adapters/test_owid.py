"""Tests for the Our World in Data adapter.

Contract:
- ``query()`` returns well-formed Evidence with a raw_hash that matches
  the excerpt bytes.
- Empty queries return ``[]``, not an exception.
- Catalog unavailable → graceful fallback to [], not exception.
- Upstream errors propagate as exceptions (the registry wraps the
  adapter in the circuit breaker, which turns them into DEGRADED).
- ``health()`` maps 2xx/3xx to HEALTHY, everything else to DEGRADED/DOWN.
"""
from __future__ import annotations

import hashlib

import httpx
import pytest
import respx

from gtv.adapters.owid import OwidAdapter
from gtv.models import Claim, Domain, Stance, TrustTier

_CHARTS_CATALOG = "https://ourworldindata.org/charts.json"


@pytest.fixture
def canned_catalog() -> dict:
    return {
        "life-expectancy": {
            "title": "Life expectancy at birth",
            "subtitle": "Global estimates",
        },
        "co2-emissions": {
            "title": "Annual CO2 emissions",
            "subtitle": "by country",
        },
        "child-mortality": {
            "title": "Child mortality rate",
            "subtitle": "deaths per 1000 live births",
        },
    }


@pytest.fixture
def canned_metadata() -> dict:
    return {
        "title": "Life expectancy at birth",
        "subtitle": "Global estimates",
        "source": {
            "name": "World Bank",
            "link": "https://data.worldbank.org/",
        },
    }


@pytest.fixture
async def adapter() -> OwidAdapter:
    a = OwidAdapter()
    yield a
    await a.close()


# --------------------------------------------------------------------


def test_adapter_identity() -> None:
    a = OwidAdapter()
    assert a.source_did == "did:web:ourworldindata.org"
    assert a.name == "Our World in Data"
    assert a.source_type == "GOVT_OPEN_DATA"
    assert a.trust_tier is TrustTier.TIER_1
    assert a.freshness_sla_s > 0


async def test_query_empty_claim_returns_empty(adapter: OwidAdapter) -> None:
    claim = Claim(text="a b", domain=Domain.GENERAL)
    result = await adapter.query(claim)
    assert result == []


async def test_query_returns_evidence(
    adapter: OwidAdapter,
    canned_catalog: dict,
    canned_metadata: dict,
) -> None:
    claim = Claim(text="life expectancy global", domain=Domain.GENERAL)
    with respx.mock:
        # Mock catalog fetch
        respx.get(_CHARTS_CATALOG).mock(
            return_value=httpx.Response(200, json=canned_catalog)
        )
        # Mock metadata fetch for matching chart
        respx.get("https://ourworldindata.org/grapher/life-expectancy.metadata.json").mock(
            return_value=httpx.Response(200, json=canned_metadata)
        )
        result = await adapter.query(claim, max_items=5)

    assert len(result) >= 1
    first = result[0]
    assert first.source_did == "did:web:ourworldindata.org"
    assert first.source_version == "owid-chart-metadata"
    assert first.stance is Stance.NEUTRAL
    assert "life-expectancy" in str(first.url)
    assert "Life expectancy" in first.excerpt
    assert (
        first.raw_hash
        == hashlib.sha256(first.excerpt.encode("utf-8")).hexdigest()
    )


async def test_query_respects_max_items(
    adapter: OwidAdapter,
    canned_catalog: dict,
    canned_metadata: dict,
) -> None:
    claim = Claim(text="mortality life", domain=Domain.GENERAL)
    with respx.mock:
        respx.get(_CHARTS_CATALOG).mock(
            return_value=httpx.Response(200, json=canned_catalog)
        )
        # Mock metadata for both charts, but only 1 should be returned
        respx.get(
            "https://ourworldindata.org/grapher/life-expectancy.metadata.json"
        ).mock(return_value=httpx.Response(200, json=canned_metadata))
        child_meta = {
            "title": "Child mortality rate",
            "subtitle": "per 1000",
            "source": {"name": "UNICEF"},
        }
        respx.get(
            "https://ourworldindata.org/grapher/child-mortality.metadata.json"
        ).mock(return_value=httpx.Response(200, json=child_meta))

        result = await adapter.query(claim, max_items=1)
    assert len(result) == 1


async def test_query_graceful_fallback_on_catalog_error(
    adapter: OwidAdapter,
) -> None:
    """Catalog fetch error → return [] (fail open, not crash)."""
    claim = Claim(text="mortality", domain=Domain.GENERAL)
    with respx.mock:
        respx.get(_CHARTS_CATALOG).mock(return_value=httpx.Response(500))
        result = await adapter.query(claim)
    assert result == []


async def test_query_skips_charts_with_failed_metadata(
    adapter: OwidAdapter, canned_catalog: dict
) -> None:
    """A chart whose metadata fetch fails should be skipped gracefully."""
    claim = Claim(text="emissions life", domain=Domain.GENERAL)
    with respx.mock:
        respx.get(_CHARTS_CATALOG).mock(
            return_value=httpx.Response(200, json=canned_catalog)
        )
        # life-expectancy succeeds
        life_meta = {
            "title": "Life expectancy at birth",
            "subtitle": "estimates",
            "source": {"name": "World Bank"},
        }
        respx.get(
            "https://ourworldindata.org/grapher/life-expectancy.metadata.json"
        ).mock(return_value=httpx.Response(200, json=life_meta))
        # co2-emissions fails
        respx.get(
            "https://ourworldindata.org/grapher/co2-emissions.metadata.json"
        ).mock(return_value=httpx.Response(503))

        result = await adapter.query(claim)
    # Should return only the successful one
    assert len(result) >= 1
    assert any("Life expectancy" in ev.excerpt for ev in result)


async def test_health_healthy(adapter: OwidAdapter) -> None:
    with respx.mock:
        respx.get(_CHARTS_CATALOG).mock(
            return_value=httpx.Response(200, json={"some": "chart"})
        )
        h = await adapter.health()
    assert h.state == "HEALTHY"
    assert "responsive" in h.detail.lower()


async def test_health_degraded_on_error(adapter: OwidAdapter) -> None:
    with respx.mock:
        respx.get(_CHARTS_CATALOG).mock(return_value=httpx.Response(500))
        h = await adapter.health()
    assert h.state == "DEGRADED"
    assert "500" in h.detail
