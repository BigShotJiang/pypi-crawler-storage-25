"""Tests for the adapter-level result cache (CachingAdapter)."""
from __future__ import annotations

import asyncio

import pytest

from gtv.adapters.base import RawSnapshot, SourceAdapter
from gtv.adapters.cache import CachingAdapter
from gtv.models import Claim, Domain, Evidence, HealthStatus, Stance, TrustTier


class FakeAdapter(SourceAdapter):
    """A fake adapter that counts calls and returns deterministic evidence."""

    def __init__(self, name: str = "fake") -> None:
        self.source_did = "did:web:fake.example"
        self.name = name
        self.trust_tier = TrustTier.TIER_1
        self.freshness_sla_s = 300
        self.source_type = "web"
        self.query_call_count = 0
        self.snapshot_call_count = 0
        self.health_call_count = 0
        self.close_call_count = 0

    async def query(self, claim: Claim, max_items: int = 5) -> list[Evidence]:
        """Count calls and return fake evidence."""
        self.query_call_count += 1
        return [
            Evidence(
                evidence_id=f"ev-{self.query_call_count}-1",
                claim_id=claim.claim_id,
                source_did=self.source_did,
                source_version="1.0",
                stance=Stance.SUPPORTS,
                excerpt=f"Fake evidence for: {claim.text}",
                url="https://fake.example/doc",
                retrieved_at=claim.submitted_at,
                raw_hash="a" * 64,
            ),
        ]

    async def snapshot(self, url: str) -> RawSnapshot:
        """Count calls and return fake snapshot."""
        self.snapshot_call_count += 1
        return RawSnapshot(
            url=url,
            content=b"fake content",
            retrieved_at_iso="2026-04-22T00:00:00Z",
        )

    async def health(self) -> HealthStatus:
        """Count calls and return healthy status."""
        self.health_call_count += 1
        return HealthStatus(state="HEALTHY", detail="fake is alive")

    async def close(self) -> None:
        """Count calls."""
        self.close_call_count += 1


# ============================================================================
# Tests
# ============================================================================


@pytest.mark.asyncio
async def test_cache_hit_reuses_result() -> None:
    """Cache hit reuses result; inner.query called only once."""
    inner = FakeAdapter()
    cached = CachingAdapter(inner, ttl_s=300.0, max_entries=10)

    claim = Claim(text="gravitational waves", domain=Domain.PHYSICS)
    result1 = await cached.query(claim, max_items=5)
    result2 = await cached.query(claim, max_items=5)

    # Same result object (reused from cache)
    assert result1 == result2
    # But inner.query called only once
    assert inner.query_call_count == 1
    # Stats reflect one hit
    stats = cached.stats()
    assert stats["hits"] == 1
    assert stats["misses"] == 1  # First call is a miss

    await cached.close()


@pytest.mark.asyncio
async def test_different_claim_text_cache_miss() -> None:
    """Different claim text triggers cache miss."""
    inner = FakeAdapter()
    cached = CachingAdapter(inner, ttl_s=300.0, max_entries=10)

    claim1 = Claim(text="gravitational waves", domain=Domain.PHYSICS)
    claim2 = Claim(text="black holes", domain=Domain.PHYSICS)

    await cached.query(claim1, max_items=5)
    await cached.query(claim2, max_items=5)

    assert inner.query_call_count == 2
    stats = cached.stats()
    assert stats["hits"] == 0
    assert stats["misses"] == 2

    await cached.close()


@pytest.mark.asyncio
async def test_ttl_expiry_triggers_refetch() -> None:
    """Expired cache entry is fetched again."""
    inner = FakeAdapter()
    cached = CachingAdapter(inner, ttl_s=0.1, max_entries=10)

    claim = Claim(text="gravitational waves", domain=Domain.PHYSICS)
    await cached.query(claim, max_items=5)
    assert inner.query_call_count == 1

    # Wait for TTL to expire
    await asyncio.sleep(0.15)

    await cached.query(claim, max_items=5)
    assert inner.query_call_count == 2
    stats = cached.stats()
    assert stats["misses"] == 2  # Initial miss + post-expiry miss

    await cached.close()


@pytest.mark.asyncio
async def test_lru_eviction_at_max_entries() -> None:
    """LRU evicts oldest entry when max_entries is exceeded."""
    inner = FakeAdapter()
    cached = CachingAdapter(inner, ttl_s=300.0, max_entries=3)

    claims = [
        Claim(text=f"claim {i}", domain=Domain.GENERAL)
        for i in range(5)
    ]

    # Fill cache with 3 claims
    for claim in claims[:3]:
        await cached.query(claim, max_items=5)

    stats = cached.stats()
    assert stats["entries"] == 3
    assert stats["evictions"] == 0

    # Add two more (should evict oldest two)
    await cached.query(claims[3], max_items=5)
    await cached.query(claims[4], max_items=5)

    stats = cached.stats()
    assert stats["entries"] == 3
    assert stats["evictions"] == 2

    # Re-query claim 0 should miss (it was evicted)
    await cached.query(claims[0], max_items=5)
    stats = cached.stats()
    assert stats["misses"] >= 1

    await cached.close()


@pytest.mark.asyncio
async def test_different_max_items_cache_separately() -> None:
    """Different max_items values create separate cache entries."""
    inner = FakeAdapter()
    cached = CachingAdapter(inner, ttl_s=300.0, max_entries=10)

    claim = Claim(text="gravitational waves", domain=Domain.PHYSICS)
    await cached.query(claim, max_items=5)
    await cached.query(claim, max_items=10)

    # Two separate calls to inner
    assert inner.query_call_count == 2
    stats = cached.stats()
    assert stats["hits"] == 0
    assert stats["misses"] == 2
    assert stats["entries"] == 2

    await cached.close()


@pytest.mark.asyncio
async def test_health_passes_through() -> None:
    """health() delegates to inner."""
    inner = FakeAdapter()
    cached = CachingAdapter(inner)

    health = await cached.health()
    assert health.state == "HEALTHY"
    assert inner.health_call_count == 1

    await cached.close()


@pytest.mark.asyncio
async def test_snapshot_passes_through() -> None:
    """snapshot() delegates to inner."""
    inner = FakeAdapter()
    cached = CachingAdapter(inner)

    url = "https://example.com/doc"
    snapshot = await cached.snapshot(url)
    assert snapshot.url == url
    assert inner.snapshot_call_count == 1

    await cached.close()


@pytest.mark.asyncio
async def test_close_closes_inner() -> None:
    """close() calls inner.close()."""
    inner = FakeAdapter()
    cached = CachingAdapter(inner)

    await cached.close()
    assert inner.close_call_count == 1


@pytest.mark.asyncio
async def test_stats_increment_correctly() -> None:
    """Stats are updated correctly for hits, misses, and evictions."""
    inner = FakeAdapter()
    cached = CachingAdapter(inner, ttl_s=300.0, max_entries=2)

    claim1 = Claim(text="claim 1", domain=Domain.GENERAL)
    claim2 = Claim(text="claim 2", domain=Domain.GENERAL)
    claim3 = Claim(text="claim 3", domain=Domain.GENERAL)

    # First query: miss, add to cache
    await cached.query(claim1, max_items=5)
    stats = cached.stats()
    assert stats["hits"] == 0
    assert stats["misses"] == 1
    assert stats["entries"] == 1

    # Repeat claim1: hit
    await cached.query(claim1, max_items=5)
    stats = cached.stats()
    assert stats["hits"] == 1
    assert stats["misses"] == 1
    assert stats["entries"] == 1

    # Add claim2: miss, add to cache
    await cached.query(claim2, max_items=5)
    stats = cached.stats()
    assert stats["hits"] == 1
    assert stats["misses"] == 2
    assert stats["entries"] == 2

    # Add claim3: miss, triggers eviction of claim1
    await cached.query(claim3, max_items=5)
    stats = cached.stats()
    assert stats["hits"] == 1
    assert stats["misses"] == 3
    assert stats["evictions"] == 1
    assert stats["entries"] == 2

    # Re-query claim1: should miss (was evicted), then added to cache, evicting claim2
    await cached.query(claim1, max_items=5)
    stats = cached.stats()
    assert stats["hits"] == 1
    assert stats["misses"] == 4
    assert stats["evictions"] == 2
    assert stats["entries"] == 2

    await cached.close()


@pytest.mark.asyncio
async def test_attribute_proxy() -> None:
    """Adapter attributes are proxied from inner."""
    inner = FakeAdapter(name="test-adapter")
    cached = CachingAdapter(inner)

    assert cached.source_did == inner.source_did
    assert cached.name == "test-adapter"
    assert cached.trust_tier == TrustTier.TIER_1
    assert cached.freshness_sla_s == 300
    assert cached.source_type == "web"

    await cached.close()


@pytest.mark.asyncio
async def test_cache_key_stability() -> None:
    """Same claim text always produces same cache key."""
    inner = FakeAdapter()
    cached = CachingAdapter(inner, ttl_s=300.0, max_entries=10)

    claim1 = Claim(text="test claim", domain=Domain.GENERAL)
    claim2 = Claim(text="test claim", domain=Domain.GENERAL)

    # Different claim IDs but same text
    assert claim1.claim_id != claim2.claim_id
    # Both should hit the same cache entry
    await cached.query(claim1, max_items=5)
    await cached.query(claim2, max_items=5)

    assert inner.query_call_count == 1
    stats = cached.stats()
    assert stats["hits"] == 1

    await cached.close()
