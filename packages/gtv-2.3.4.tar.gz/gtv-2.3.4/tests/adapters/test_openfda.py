"""Tests for the OpenFDA adapter (W43).

Contract:
- ``query()`` returns well-formed Evidence with a raw_hash that matches
  the excerpt bytes.
- Empty queries return ``[]``, not an exception.
- Upstream errors propagate as exceptions (the registry wraps the
  adapter in the circuit breaker, which turns them into DEGRADED).
- ``health()`` maps 2xx/3xx to HEALTHY, everything else to DEGRADED/DOWN.
"""
from __future__ import annotations

import hashlib

import httpx
import pytest
import respx

from gtv.adapters.openfda import OpenFDAAdapter
from gtv.models import Claim, Domain, Stance, TrustTier

_BASE_URL = "https://api.fda.gov/drug/label.json"


@pytest.fixture
def canned_response() -> dict:
    return {
        "meta": {"total": 2, "limit": 5},
        "results": [
            {
                "id": "11111111-aaaa-bbbb-cccc-222222222222",
                "openfda": {
                    "brand_name": ["ASPIRIN 81 MG"],
                    "generic_name": ["acetylsalicylic acid"],
                },
                "indications_and_usage": [
                    "For reduction of cardiovascular events in patients at risk."
                ],
                "warnings": ["Do not use if allergic to salicylates."],
                "effective_time": "20240501",
            },
            {
                "id": "33333333-dddd-eeee-ffff-444444444444",
                "openfda": {
                    "brand_name": ["ASPIRIN 325 MG"],
                    "generic_name": ["acetylsalicylic acid"],
                },
                "indications_and_usage": [
                    "For temporary relief of minor aches and pains."
                ],
                "warnings": ["May cause stomach upset."],
                "effective_time": "20231115",
            },
        ],
    }


@pytest.fixture
async def adapter() -> OpenFDAAdapter:
    a = OpenFDAAdapter()
    yield a
    await a.close()


# -----------------------------------------------------------------------


def test_adapter_identity() -> None:
    a = OpenFDAAdapter()
    assert a.source_did == "did:web:open.fda.gov"
    assert a.name == "OpenFDA"
    assert a.trust_tier is TrustTier.TIER_1
    assert a.freshness_sla_s > 0


async def test_query_empty_claim_returns_empty(adapter: OpenFDAAdapter) -> None:
    claim = Claim(text="a b", domain=Domain.GENERAL)
    # claim_to_query drops stopwords and <=1-char tokens; "a b" collapses to "".
    result = await adapter.query(claim)
    assert result == []


async def test_query_returns_evidence(
    adapter: OpenFDAAdapter, canned_response: dict
) -> None:
    claim = Claim(text="aspirin dosage indication", domain=Domain.GENERAL)
    with respx.mock:
        respx.get(_BASE_URL).mock(
            return_value=httpx.Response(200, json=canned_response)
        )
        result = await adapter.query(claim, max_items=5)

    assert len(result) == 2
    first = result[0]
    assert first.source_did == "did:web:open.fda.gov"
    assert first.source_version == "openfda-v1"
    assert first.stance is Stance.NEUTRAL  # labels are neutral reference data
    assert "11111111-aaaa-bbbb-cccc-222222222222" in str(first.url)
    assert "ASPIRIN 81 MG" in first.excerpt
    # raw_hash is sha256 of the excerpt text (as bytes).
    assert (
        first.raw_hash
        == hashlib.sha256(first.excerpt.encode("utf-8")).hexdigest()
    )


async def test_query_respects_max_items(
    adapter: OpenFDAAdapter, canned_response: dict
) -> None:
    claim = Claim(text="aspirin", domain=Domain.GENERAL)
    with respx.mock:
        respx.get(_BASE_URL).mock(
            return_value=httpx.Response(200, json=canned_response)
        )
        result = await adapter.query(claim, max_items=1)
    assert len(result) == 1


async def test_query_skips_malformed_records(
    adapter: OpenFDAAdapter,
) -> None:
    """A malformed upstream record must be dropped, not crash the batch."""
    bad = {
        "results": [
            {
                "id": None,
                "openfda": {"brand_name": ["NO_ID"]},
                "indications_and_usage": ["x"],
            },
            {
                "id": "ok-id-1",
                "openfda": {"brand_name": [], "generic_name": []},
                "indications_and_usage": ["no title"],
            },
            {
                "id": "abc-def-123",
                "openfda": {
                    "brand_name": ["OK DRUG"],
                    "generic_name": ["test"],
                },
                "indications_and_usage": ["For testing"],
                "effective_time": "20240101",
            },
        ]
    }
    claim = Claim(text="drug", domain=Domain.GENERAL)
    with respx.mock:
        respx.get(_BASE_URL).mock(return_value=httpx.Response(200, json=bad))
        result = await adapter.query(claim)
    assert len(result) == 1
    assert "OK DRUG" in result[0].excerpt


async def test_query_propagates_http_error(adapter: OpenFDAAdapter) -> None:
    claim = Claim(text="aspirin", domain=Domain.GENERAL)
    with respx.mock:
        respx.get(_BASE_URL).mock(return_value=httpx.Response(404))
        with pytest.raises(httpx.HTTPStatusError):
            await adapter.query(claim)


async def test_health_healthy(adapter: OpenFDAAdapter) -> None:
    with respx.mock:
        respx.get(_BASE_URL).mock(
            return_value=httpx.Response(200, json={"results": []})
        )
        h = await adapter.health()
    assert h.state == "HEALTHY"


async def test_health_degraded_on_500(adapter: OpenFDAAdapter) -> None:
    with respx.mock:
        respx.get(_BASE_URL).mock(return_value=httpx.Response(500))
        h = await adapter.health()
    assert h.state == "DEGRADED"
    assert "500" in h.detail
