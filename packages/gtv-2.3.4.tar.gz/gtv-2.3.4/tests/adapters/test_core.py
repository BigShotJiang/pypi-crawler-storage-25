"""Tests for the CORE research aggregator adapter (W43).

Contract:
- ``query()`` returns well-formed Evidence with a raw_hash that matches
  the excerpt bytes.
- Empty queries return ``[]``, not an exception.
- Upstream errors propagate as exceptions (the registry wraps the
  adapter in the circuit breaker, which turns them into DEGRADED).
- ``health()`` maps 2xx/3xx to HEALTHY, everything else to DEGRADED/DOWN.
- Without CORE_API_KEY env var, query() returns [] and health() is DEGRADED.
"""
from __future__ import annotations

import hashlib
import os

import httpx
import pytest
import respx

from gtv.adapters.core import CoreAdapter
from gtv.models import Claim, Domain, TrustTier

_BASE_URL = "https://api.core.ac.uk/v3/search/works"


@pytest.fixture
def canned_response() -> dict:
    return {
        "results": [
            {
                "id": 123456,
                "title": "Machine Learning in COVID-19 Detection",
                "abstract": (
                    "We present a novel approach using deep learning to detect "
                    "COVID-19 from chest X-rays with 95% accuracy."
                ),
                "authors": [
                    {"name": "John Doe"},
                    {"name": "Jane Smith"},
                ],
                "publishedDate": "2024-05-15",
                "doi": "10.5555/12345678",
                "downloadUrl": "https://example.com/paper1.pdf",
                "urls": ["https://example.com/paper1"],
            },
            {
                "id": 789012,
                "title": "Contrary Evidence in Medical Research",
                "abstract": (
                    "Our results show no significant correlation between the "
                    "proposed treatment and patient outcomes."
                ),
                "authors": [{"name": "Bob Johnson"}],
                "publishedDate": "2024-04-20",
                "doi": "10.5555/87654321",
                "downloadUrl": None,
                "urls": ["https://example.com/paper2"],
            },
        ],
        "totalHits": 2,
    }


@pytest.fixture
async def adapter() -> CoreAdapter:
    a = CoreAdapter()
    yield a
    await a.close()


# -----------------------------------------------------------------------


def test_adapter_identity() -> None:
    a = CoreAdapter()
    assert a.source_did == "did:web:core.ac.uk"
    assert a.name == "CORE"
    assert a.trust_tier is TrustTier.TIER_2


async def test_query_empty_claim_returns_empty(adapter: CoreAdapter) -> None:
    if os.getenv("CORE_API_KEY"):
        os.environ.pop("CORE_API_KEY")
    claim = Claim(text="a b", domain=Domain.GENERAL)
    # claim_to_query drops stopwords and <=1-char tokens; "a b" collapses to "".
    result = await adapter.query(claim)
    assert result == []


async def test_query_returns_empty_without_api_key(monkeypatch) -> None:
    """Without CORE_API_KEY, query() returns [] without hitting the API."""
    monkeypatch.delenv("CORE_API_KEY", raising=False)
    adapter = CoreAdapter()
    try:
        claim = Claim(text="covid machine learning", domain=Domain.GENERAL)
        result = await adapter.query(claim)
        assert result == []
    finally:
        await adapter.close()


async def test_query_returns_evidence(
    adapter: CoreAdapter, canned_response: dict, monkeypatch
) -> None:
    monkeypatch.setenv("CORE_API_KEY", "test-api-key")
    # Recreate adapter with env var set
    a = CoreAdapter()
    try:
        claim = Claim(text="machine learning covid detection", domain=Domain.GENERAL)
        with respx.mock:
            respx.get(_BASE_URL).mock(
                return_value=httpx.Response(200, json=canned_response)
            )
            result = await a.query(claim, max_items=5)

        assert len(result) == 2
        first = result[0]
        assert first.source_did == "did:web:core.ac.uk"
        assert first.source_version == "core-v3"
        assert "Machine Learning in COVID-19 Detection" in first.excerpt
        # raw_hash is sha256 of the excerpt text (as bytes).
        assert (
            first.raw_hash
            == hashlib.sha256(first.excerpt.encode("utf-8")).hexdigest()
        )
    finally:
        await a.close()


async def test_query_respects_max_items(
    adapter: CoreAdapter, canned_response: dict, monkeypatch
) -> None:
    monkeypatch.setenv("CORE_API_KEY", "test-api-key")
    a = CoreAdapter()
    try:
        claim = Claim(text="research", domain=Domain.GENERAL)
        with respx.mock:
            respx.get(_BASE_URL).mock(
                return_value=httpx.Response(200, json=canned_response)
            )
            result = await a.query(claim, max_items=1)
        assert len(result) == 1
    finally:
        await a.close()


async def test_query_skips_malformed_records(
    adapter: CoreAdapter, monkeypatch
) -> None:
    """A malformed upstream record must be dropped, not crash the batch."""
    monkeypatch.setenv("CORE_API_KEY", "test-api-key")
    a = CoreAdapter()
    try:
        bad = {
            "results": [
                {
                    "id": None,
                    "title": "Missing ID",
                    "abstract": "Test",
                },
                {
                    "id": 123,
                    "title": "",
                    "abstract": "No title",
                },
                {
                    "id": 456,
                    "title": "Good Paper",
                    "abstract": "Valid abstract",
                    "downloadUrl": "https://example.com/good.pdf",
                },
            ]
        }
        claim = Claim(text="paper", domain=Domain.GENERAL)
        with respx.mock:
            respx.get(_BASE_URL).mock(return_value=httpx.Response(200, json=bad))
            result = await a.query(claim)
        assert len(result) == 1
        assert "Good Paper" in result[0].excerpt
    finally:
        await a.close()


async def test_query_propagates_http_error(
    adapter: CoreAdapter, monkeypatch
) -> None:
    monkeypatch.setenv("CORE_API_KEY", "test-api-key")
    a = CoreAdapter()
    try:
        claim = Claim(text="research", domain=Domain.GENERAL)
        with respx.mock:
            respx.get(_BASE_URL).mock(return_value=httpx.Response(500))
            with pytest.raises(httpx.HTTPStatusError):
                await a.query(claim)
    finally:
        await a.close()


async def test_query_sends_auth_header(
    canned_response: dict, monkeypatch
) -> None:
    """Verify the Bearer auth header is sent when CORE_API_KEY is set."""
    monkeypatch.setenv("CORE_API_KEY", "test-api-key-12345")
    adapter = CoreAdapter()
    try:
        claim = Claim(text="research", domain=Domain.GENERAL)
        with respx.mock:
            route = respx.get(_BASE_URL).mock(
                return_value=httpx.Response(200, json=canned_response)
            )
            result = await adapter.query(claim)

        assert route.called
        call = route.calls[0]
        auth_header = call.request.headers.get("Authorization")
        assert auth_header == "Bearer test-api-key-12345"
        assert len(result) == 2
    finally:
        await adapter.close()


async def test_health_healthy(adapter: CoreAdapter, monkeypatch) -> None:
    monkeypatch.setenv("CORE_API_KEY", "test-key")
    a = CoreAdapter()
    try:
        with respx.mock:
            respx.get(_BASE_URL).mock(
                return_value=httpx.Response(200, json={"results": []})
            )
            h = await a.health()
        assert h.state == "HEALTHY"
    finally:
        await a.close()


async def test_health_degraded_without_api_key(monkeypatch) -> None:
    """Without CORE_API_KEY, health() should return DEGRADED."""
    monkeypatch.delenv("CORE_API_KEY", raising=False)
    adapter = CoreAdapter()
    try:
        h = await adapter.health()
        assert h.state == "DEGRADED"
        assert "CORE_API_KEY not set" in h.detail
    finally:
        await adapter.close()


async def test_health_degraded_on_500(adapter: CoreAdapter, monkeypatch) -> None:
    monkeypatch.setenv("CORE_API_KEY", "test-key")
    a = CoreAdapter()
    try:
        with respx.mock:
            respx.get(_BASE_URL).mock(return_value=httpx.Response(500))
            h = await a.health()
        assert h.state == "DEGRADED"
        assert "500" in h.detail
    finally:
        await a.close()


async def test_detect_stance_supports() -> None:
    """Stance detection: supports keyword."""
    text = "This work demonstrates strong evidence supporting the hypothesis"
    stance = CoreAdapter._detect_stance(text)
    assert stance.value == "SUPPORTS"


async def test_detect_stance_refutes() -> None:
    """Stance detection: refutation keyword."""
    text = "Our findings show no significant association between the variables"
    stance = CoreAdapter._detect_stance(text)
    assert stance.value == "REFUTES"


async def test_detect_stance_neutral() -> None:
    """Stance detection: neutral (no clear keyword)."""
    text = "A study on the topic"
    stance = CoreAdapter._detect_stance(text)
    assert stance.value == "NEUTRAL"
