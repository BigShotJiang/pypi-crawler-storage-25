"""Tests for the GitHub Security Advisories adapter (W42)."""
from __future__ import annotations

import hashlib

import httpx
import pytest
import respx

from gtv.adapters.ghsa import GhsaAdapter
from gtv.models import Claim, Domain, Stance, TrustTier

_ENDPOINT = "https://api.github.com/advisories"


@pytest.fixture
def canned_list() -> list[dict]:
    return [
        {
            "ghsa_id": "GHSA-xxxx-yyyy-zzzz",
            "cve_id": "CVE-2024-12345",
            "summary": "Remote code execution in libfoo when parsing crafted JSON.",
            "severity": "critical",
            "published_at": "2024-09-12T00:00:00Z",
            "html_url": "https://github.com/advisories/GHSA-xxxx-yyyy-zzzz",
        },
        {
            "ghsa_id": "GHSA-aaaa-bbbb-cccc",
            "cve_id": None,
            "summary": "Prototype pollution in libbar.",
            "severity": "high",
            "published_at": "2024-08-01T00:00:00Z",
            "html_url": "https://github.com/advisories/GHSA-aaaa-bbbb-cccc",
        },
    ]


@pytest.fixture
async def adapter() -> GhsaAdapter:
    a = GhsaAdapter()
    yield a
    await a.close()


# --------------------------------------------------------------------


def test_adapter_identity() -> None:
    a = GhsaAdapter()
    assert a.source_did == "did:web:github.com"
    assert a.trust_tier is TrustTier.TIER_1


def test_extract_cve() -> None:
    assert (
        GhsaAdapter._extract_cve("affected by CVE-2024-12345 please patch")
        == "CVE-2024-12345"
    )
    assert GhsaAdapter._extract_cve("no cve here") is None
    # Case insensitive, normalised to upper.
    assert GhsaAdapter._extract_cve("cve-2023-7") is None  # too-short suffix
    assert GhsaAdapter._extract_cve("cve-2023-0001") == "CVE-2023-0001"


def test_extract_ghsa() -> None:
    assert (
        GhsaAdapter._extract_ghsa("GHSA-xxxx-yyyy-zzzz is critical")
        == "GHSA-XXXX-YYYY-ZZZZ"
    )
    assert GhsaAdapter._extract_ghsa("nothing to see") is None


async def test_query_by_cve_uses_cve_filter(
    adapter: GhsaAdapter, canned_list: list[dict]
) -> None:
    claim = Claim(text="CVE-2024-12345 is an RCE", domain=Domain.CS)
    with respx.mock:
        route = respx.get(_ENDPOINT).mock(
            return_value=httpx.Response(200, json=canned_list[:1])
        )
        result = await adapter.query(claim)

    assert route.called
    call = route.calls[0]
    assert "cve_id=CVE-2024-12345" in str(call.request.url)
    assert len(result) == 1
    ev = result[0]
    assert ev.source_did == "did:web:github.com"
    assert ev.stance is Stance.SUPPORTS
    assert "CVE-2024-12345" in ev.excerpt
    assert "critical" in ev.excerpt
    assert ev.raw_hash == hashlib.sha256(ev.excerpt.encode("utf-8")).hexdigest()


async def test_query_by_ghsa_id(adapter: GhsaAdapter, canned_list: list[dict]) -> None:
    claim = Claim(text="GHSA-xxxx-yyyy-zzzz affects prod", domain=Domain.CS)
    with respx.mock:
        route = respx.get(_ENDPOINT).mock(
            return_value=httpx.Response(200, json=canned_list[:1])
        )
        result = await adapter.query(claim)
    assert route.called
    assert "ghsa_id=GHSA-XXXX-YYYY-ZZZZ" in str(route.calls[0].request.url)
    assert len(result) == 1


async def test_query_falls_back_to_affects(
    adapter: GhsaAdapter, canned_list: list[dict]
) -> None:
    claim = Claim(text="libfoo vulnerability RCE", domain=Domain.CS)
    with respx.mock:
        route = respx.get(_ENDPOINT).mock(
            return_value=httpx.Response(200, json=canned_list)
        )
        result = await adapter.query(claim, max_items=2)
    assert route.called
    # The first non-stopword token should appear as ``affects=...``
    url_str = str(route.calls[0].request.url)
    assert "affects=libfoo" in url_str
    assert len(result) == 2


async def test_query_empty_returns_empty(adapter: GhsaAdapter) -> None:
    claim = Claim(text="the and of", domain=Domain.CS)
    # All stopwords → claim_to_query returns "" → no request, []
    result = await adapter.query(claim)
    assert result == []


async def test_query_drops_malformed_records(adapter: GhsaAdapter) -> None:
    bad = [
        {"ghsa_id": None, "summary": "x", "html_url": "https://x"},
        {"ghsa_id": "GHSA-ok", "summary": "", "html_url": "https://x"},
        {
            "ghsa_id": "GHSA-good",
            "summary": "OK summary here.",
            "severity": "moderate",
            "published_at": "2024-01-01T00:00:00Z",
            "html_url": "https://github.com/advisories/GHSA-good",
        },
    ]
    with respx.mock:
        respx.get(_ENDPOINT).mock(return_value=httpx.Response(200, json=bad))
        result = await adapter.query(Claim(text="libfoo", domain=Domain.CS))
    assert len(result) == 1
    assert "GHSA-good" in result[0].excerpt


async def test_query_propagates_rate_limit(adapter: GhsaAdapter) -> None:
    with respx.mock:
        respx.get(_ENDPOINT).mock(
            return_value=httpx.Response(
                403, json={"message": "API rate limit exceeded"}
            )
        )
        with pytest.raises(httpx.HTTPStatusError):
            await adapter.query(Claim(text="libfoo", domain=Domain.CS))


async def test_health_healthy(adapter: GhsaAdapter) -> None:
    with respx.mock:
        respx.get(_ENDPOINT).mock(return_value=httpx.Response(200, json=[]))
        h = await adapter.health()
    assert h.state == "HEALTHY"


async def test_health_rate_limited(adapter: GhsaAdapter) -> None:
    with respx.mock:
        respx.get(_ENDPOINT).mock(return_value=httpx.Response(429))
        h = await adapter.health()
    assert h.state == "DEGRADED"
    assert "rate-limited" in h.detail
