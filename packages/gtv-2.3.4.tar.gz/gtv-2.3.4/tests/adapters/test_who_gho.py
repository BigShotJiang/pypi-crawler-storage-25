"""Tests for the WHO GHO adapter (W45).

Contract:
- ``query()`` returns well-formed Evidence with NEUTRAL stance (reference data).
- Empty queries return ``[]``, not an exception.
- Upstream errors propagate as exceptions.
- ``health()`` maps 2xx/3xx to HEALTHY, everything else to DEGRADED/DOWN.
- Indicator cache is populated on first call and reused on subsequent calls.
- Respects the GTV_WHO_GHO_DISABLE environment variable.
"""
from __future__ import annotations

import hashlib
import os

import httpx
import pytest
import respx

from gtv.adapters.who_gho import WHOGHOAdapter
from gtv.models import Claim, Domain, Stance, TrustTier

_INDICATOR_URL = "https://ghoapi.azureedge.net/api/Indicator"


@pytest.fixture
def canned_indicator_response() -> dict:
    return {
        "value": [
            {
                "IndicatorCode": "HALE",
                "IndicatorName": "Health-Adjusted Life Expectancy",
            },
            {
                "IndicatorCode": "IMR",
                "IndicatorName": "Infant Mortality Rate",
            },
            {
                "IndicatorCode": "DIABETES",
                "IndicatorName": "Prevalence of Diabetes",
            },
        ]
    }


@pytest.fixture
async def adapter() -> WHOGHOAdapter:
    a = WHOGHOAdapter()
    yield a
    await a.close()


# Tests

def test_adapter_identity() -> None:
    a = WHOGHOAdapter()
    assert a.source_did == "did:web:who.int"
    assert a.name == "WHO GHO"
    assert a.trust_tier is TrustTier.TIER_1
    assert a.freshness_sla_s > 0


async def test_query_empty_claim_returns_empty(adapter: WHOGHOAdapter) -> None:
    claim = Claim(text="a b", domain=Domain.GENERAL)
    with respx.mock:
        respx.get(_INDICATOR_URL).mock(
            return_value=httpx.Response(200, json={"value": []})
        )
        result = await adapter.query(claim)

    assert result == []


async def test_query_returns_evidence(
    adapter: WHOGHOAdapter, canned_indicator_response: dict
) -> None:
    claim = Claim(text="infant mortality rate", domain=Domain.GENERAL)
    with respx.mock:
        respx.get(_INDICATOR_URL).mock(
            return_value=httpx.Response(200, json=canned_indicator_response)
        )
        result = await adapter.query(claim, max_items=5)

    assert len(result) == 1
    first = result[0]
    assert first.source_did == "did:web:who.int"
    assert first.source_version == "who-gho-odata-v1"
    assert first.stance is Stance.NEUTRAL  # Reference data
    assert "IMR" in first.excerpt
    assert "Infant Mortality Rate" in first.excerpt
    # Verify raw_hash is correct.
    assert (
        first.raw_hash
        == hashlib.sha256(first.excerpt.encode("utf-8")).hexdigest()
    )


async def test_query_respects_max_items(
    adapter: WHOGHOAdapter, canned_indicator_response: dict
) -> None:
    claim = Claim(text="mortality health", domain=Domain.GENERAL)
    with respx.mock:
        respx.get(_INDICATOR_URL).mock(
            return_value=httpx.Response(200, json=canned_indicator_response)
        )
        result = await adapter.query(claim, max_items=1)

    # Should match both IMR and HALE, but limit to 1.
    assert len(result) == 1


async def test_query_skips_indicators_missing_required_fields(
    adapter: WHOGHOAdapter,
) -> None:
    """Malformed indicators are dropped."""
    bad = {
        "value": [
            {"IndicatorCode": None, "IndicatorName": "missing code"},
            {"IndicatorCode": "OK_CODE", "IndicatorName": ""},
            {
                "IndicatorCode": "VALID",
                "IndicatorName": "Valid Indicator Name",
            },
        ]
    }
    claim = Claim(text="indicator", domain=Domain.GENERAL)
    with respx.mock:
        respx.get(_INDICATOR_URL).mock(return_value=httpx.Response(200, json=bad))
        result = await adapter.query(claim)

    assert len(result) == 1
    assert "VALID" in result[0].excerpt


async def test_query_propagates_http_error(adapter: WHOGHOAdapter) -> None:
    claim = Claim(text="mortality", domain=Domain.GENERAL)
    with respx.mock:
        respx.get(_INDICATOR_URL).mock(return_value=httpx.Response(503))
        with pytest.raises(httpx.HTTPStatusError):
            await adapter.query(claim)


async def test_query_respects_disable_env(adapter: WHOGHOAdapter) -> None:
    """Query should return empty list if GTV_WHO_GHO_DISABLE is set."""
    claim = Claim(text="mortality", domain=Domain.GENERAL)
    os.environ["GTV_WHO_GHO_DISABLE"] = "1"
    try:
        result = await adapter.query(claim)
        assert result == []
    finally:
        del os.environ["GTV_WHO_GHO_DISABLE"]


async def test_indicator_cache_populated_and_reused(
    adapter: WHOGHOAdapter, canned_indicator_response: dict
) -> None:
    """Cache should be populated on first call and reused on second."""
    claim = Claim(text="mortality health", domain=Domain.GENERAL)
    with respx.mock:
        # Mock the endpoint.
        route = respx.get(_INDICATOR_URL).mock(
            return_value=httpx.Response(200, json=canned_indicator_response)
        )

        # First call should fetch indicators.
        result1 = await adapter.query(claim, max_items=1)
        first_call_count = route.called

        # Second call should reuse cache, not make another request.
        result2 = await adapter.query(claim, max_items=1)
        second_call_count = route.called

    assert len(result1) > 0
    assert len(result2) > 0
    # Cache should have been populated after first call,
    # so second call should not have incremented the call count.
    assert second_call_count == first_call_count


async def test_health_healthy(adapter: WHOGHOAdapter) -> None:
    with respx.mock:
        respx.get(_INDICATOR_URL).mock(
            return_value=httpx.Response(200, json={"value": []})
        )
        h = await adapter.health()

    assert h.state == "HEALTHY"
    assert "responsive" in h.detail.lower()


async def test_health_degraded_on_500(adapter: WHOGHOAdapter) -> None:
    with respx.mock:
        respx.get(_INDICATOR_URL).mock(return_value=httpx.Response(500))
        h = await adapter.health()

    assert h.state == "DEGRADED"
    assert "500" in h.detail
