"""Tests for CrossrefAdapter — mocked and live."""
from __future__ import annotations

import hashlib
import os

import httpx
import pytest
import respx

from gtv.adapters.crossref import CrossrefAdapter
from gtv.models import Claim, Domain, SourceType, Stance, TrustTier

# ============================================================================
# Fixtures
# ============================================================================


@pytest.fixture
def canned_crossref_response() -> dict:
    """A minimal JSON response from Crossref API with 2 entries."""
    return {
        "status": "ok",
        "message-type": "work-list",
        "message": {
            "facets": {},
            "total-results": 2,
            "items": [
                {
                    "DOI": "10.1234/example.1",
                    "URL": "https://example.com/article1",
                    "title": ["Gravitational Waves from Merging Neutron Stars"],
                    "abstract": "We present observations of gravitational waves from the merger of two neutron stars. The detection was made using advanced LIGO and Virgo detectors. The signal shows clear evidence of mass transfer and ejecta formation. This event provides unique constraints on the neutron star equation of state and the production of heavy elements via rapid neutron capture.",
                },
                {
                    "DOI": "10.1234/example.2",
                    "title": ["Black Hole Formation in Gravitational Collapse"],
                    "abstract": "<jats:p>We study the formation of black holes through gravitational collapse in various spacetime metrics. Our numerical simulations use state-of-the-art adaptive mesh refinement techniques. The results show how the event horizon forms and expands during collapse. We also analyze the role of angular momentum in determining the final black hole properties.</jats:p>",
                },
            ],
        },
    }


@pytest.fixture
async def adapter() -> CrossrefAdapter:
    """Create a CrossrefAdapter instance for testing."""
    adapter = CrossrefAdapter()
    yield adapter
    await adapter.close()


# ============================================================================
# Unit Tests (Mocked)
# ============================================================================


@pytest.mark.asyncio
async def test_query_returns_evidence(
    adapter: CrossrefAdapter, canned_crossref_response: dict
) -> None:
    """Query should return list of Evidence records with valid fields."""
    claim = Claim(text="gravitational waves neutron stars", domain=Domain.PHYSICS)

    with respx.mock:
        respx.get(
            "https://api.crossref.org/works",
            params={
                "query": "gravitational waves neutron stars",
                "rows": 5,
                "select": "DOI,title,abstract,URL",
            },
        ).mock(return_value=httpx.Response(200, json=canned_crossref_response))

        results = await adapter.query(claim, max_items=5)

    assert len(results) == 2
    for evidence in results:
        # Check all required fields.
        assert evidence.claim_id == claim.claim_id
        assert evidence.source_did == "did:web:crossref.org"
        assert evidence.source_version == "crossref-api-v1"
        assert evidence.stance == Stance.NEUTRAL
        assert evidence.url
        assert len(evidence.raw_hash) == 64
        assert all(c in "0123456789abcdef" for c in evidence.raw_hash)
        assert evidence.retrieved_at.tzinfo is not None


@pytest.mark.asyncio
async def test_query_excerpt_from_abstract(
    adapter: CrossrefAdapter, canned_crossref_response: dict
) -> None:
    """Excerpt should be the abstract text, trimmed to 1200 chars."""
    claim = Claim(text="gravitational waves", domain=Domain.PHYSICS)

    with respx.mock:
        respx.get(
            "https://api.crossref.org/works",
            params={
                "query": "gravitational waves",
                "rows": 5,
                "select": "DOI,title,abstract,URL",
            },
        ).mock(return_value=httpx.Response(200, json=canned_crossref_response))

        results = await adapter.query(claim, max_items=5)

    # First entry has a known abstract without JATS tags.
    first_abstract = (
        "We present observations of gravitational waves from the merger of two "
        "neutron stars. The detection was made using advanced LIGO and Virgo detectors. "
        "The signal shows clear evidence of mass transfer and ejecta formation. This event "
        "provides unique constraints on the neutron star equation of state and the production "
        "of heavy elements via rapid neutron capture."
    )
    assert results[0].excerpt == first_abstract


@pytest.mark.asyncio
async def test_query_jats_tag_stripping(
    adapter: CrossrefAdapter, canned_crossref_response: dict
) -> None:
    """Excerpt should strip JATS XML tags from abstract."""
    claim = Claim(text="gravitational waves", domain=Domain.PHYSICS)

    with respx.mock:
        respx.get(
            "https://api.crossref.org/works",
            params={
                "query": "gravitational waves",
                "rows": 5,
                "select": "DOI,title,abstract,URL",
            },
        ).mock(return_value=httpx.Response(200, json=canned_crossref_response))

        results = await adapter.query(claim, max_items=5)

    # Second entry has JATS tags that should be stripped.
    second_abstract = (
        "We study the formation of black holes through gravitational collapse in "
        "various spacetime metrics. Our numerical simulations use state-of-the-art "
        "adaptive mesh refinement techniques. The results show how the event horizon "
        "forms and expands during collapse. We also analyze the role of angular momentum "
        "in determining the final black hole properties."
    )
    assert results[1].excerpt == second_abstract


@pytest.mark.asyncio
async def test_query_raw_hash_matches_abstract(
    adapter: CrossrefAdapter, canned_crossref_response: dict
) -> None:
    """raw_hash should match sha256 of the abstract bytes."""
    claim = Claim(text="gravitational waves", domain=Domain.PHYSICS)

    with respx.mock:
        respx.get(
            "https://api.crossref.org/works",
            params={
                "query": "gravitational waves",
                "rows": 5,
                "select": "DOI,title,abstract,URL",
            },
        ).mock(return_value=httpx.Response(200, json=canned_crossref_response))

        results = await adapter.query(claim, max_items=5)

    # Check that the hash matches for first result.
    first_abstract = (
        "We present observations of gravitational waves from the merger of two "
        "neutron stars. The detection was made using advanced LIGO and Virgo detectors. "
        "The signal shows clear evidence of mass transfer and ejecta formation. This event "
        "provides unique constraints on the neutron star equation of state and the production "
        "of heavy elements via rapid neutron capture."
    )
    expected_hash = hashlib.sha256(first_abstract.encode("utf-8")).hexdigest()
    assert results[0].raw_hash == expected_hash


@pytest.mark.asyncio
async def test_query_timeout_propagates(adapter: CrossrefAdapter) -> None:
    """Timeout exceptions should be raised, not swallowed."""
    claim = Claim(text="test", domain=Domain.PHYSICS)

    with respx.mock:
        respx.get(
            "https://api.crossref.org/works",
            params={
                "query": "test",
                "rows": 5,
                "select": "DOI,title,abstract,URL",
            },
        ).mock(side_effect=httpx.TimeoutException("Timeout"))

        with pytest.raises(httpx.TimeoutException):
            await adapter.query(claim, max_items=5)


@pytest.mark.asyncio
async def test_query_empty_claim_text() -> None:
    """Empty claim should return empty list (no query to send)."""
    adapter = CrossrefAdapter()
    try:
        # Create a claim with only stopwords to get empty query.
        claim = Claim(text="the a is", domain=Domain.PHYSICS)
        results = await adapter.query(claim)
        assert results == []
    finally:
        await adapter.close()


@pytest.mark.asyncio
async def test_health_check_healthy(adapter: CrossrefAdapter) -> None:
    """Health check should return HEALTHY on 200."""
    with respx.mock:
        respx.get(
            "https://api.crossref.org/works",
            params={"query": "test", "rows": "1"},
        ).mock(return_value=httpx.Response(200, json={"message": {"items": []}}))

        health = await adapter.health()

    assert health.state == "HEALTHY"


@pytest.mark.asyncio
async def test_health_check_degraded_on_error(adapter: CrossrefAdapter) -> None:
    """Health check should return DEGRADED on non-2xx status."""
    with respx.mock:
        respx.get(
            "https://api.crossref.org/works",
            params={"query": "test", "rows": "1"},
        ).mock(return_value=httpx.Response(503))

        health = await adapter.health()

    assert health.state == "DEGRADED"
    assert "503" in health.detail


@pytest.mark.asyncio
async def test_health_check_down_on_timeout(adapter: CrossrefAdapter) -> None:
    """Health check should return DOWN on timeout."""
    with respx.mock:
        respx.get(
            "https://api.crossref.org/works",
            params={"query": "test", "rows": "1"},
        ).mock(side_effect=httpx.TimeoutException("Timeout"))

        health = await adapter.health()

    assert health.state == "DOWN"
    assert "timeout" in health.detail.lower()


@pytest.mark.asyncio
async def test_adapter_metadata() -> None:
    """Adapter should expose correct metadata."""
    adapter = CrossrefAdapter()
    try:
        assert adapter.source_did == "did:web:crossref.org"
        assert adapter.name == "Crossref"
        assert adapter.source_type == SourceType.REFERENCE_DATA
        assert adapter.trust_tier == TrustTier.TIER_1
        assert adapter.freshness_sla_s == 5
    finally:
        await adapter.close()


@pytest.mark.asyncio
async def test_close_releases_client() -> None:
    """Calling close() should release the owned client."""
    adapter = CrossrefAdapter()
    assert adapter._owns_client is True
    await adapter.close()
    # After close, client should be closed (httpx tracks this).
    assert adapter._client.is_closed is True


@pytest.mark.asyncio
async def test_external_client_not_closed() -> None:
    """If an external client is provided, close() should not close it."""
    external_client = httpx.AsyncClient()
    adapter = CrossrefAdapter(client=external_client)
    assert adapter._owns_client is False
    await adapter.close()
    # External client should not be closed by adapter.
    assert not external_client.is_closed


# ============================================================================
# Integration Test (Live)
# ============================================================================


@pytest.mark.asyncio
async def test_crossref_live_query() -> None:
    """Live integration test: query real Crossref API.

    Only runs if GTV_LIVE=1 is set.
    """
    if not os.getenv("GTV_LIVE"):
        pytest.skip("GTV_LIVE not set; skipping live test")

    adapter = CrossrefAdapter()
    try:
        # Query with a simple claim.
        claim = Claim(
            text="machine learning neural networks",
            domain=Domain.GENERAL,
        )
        results = await adapter.query(claim, max_items=3)

        # We should get at least one result.
        assert len(results) >= 1

        # Each result should be valid.
        for evidence in results:
            assert evidence.claim_id == claim.claim_id
            assert evidence.source_did == "did:web:crossref.org"
            assert evidence.source_version == "crossref-api-v1"
            assert evidence.stance == Stance.NEUTRAL
            assert evidence.url
            assert len(evidence.raw_hash) == 64
            assert evidence.retrieved_at.tzinfo is not None
            assert 0 < len(evidence.excerpt) <= 1200

    finally:
        await adapter.close()
