"""Tests for in-memory snapshot store."""
from __future__ import annotations

import hashlib

import pytest

from gtv.adapters.snapshot import InMemorySnapshotStore


@pytest.mark.asyncio
async def test_put_and_get() -> None:
    """Store and retrieve content by hash."""
    store = InMemorySnapshotStore()
    content = b"Hello, world!"
    url = "https://example.com/page"

    # Put the content.
    raw_hash = await store.put(url, content)

    # Verify the hash is correct.
    expected_hash = hashlib.sha256(content).hexdigest()
    assert raw_hash == expected_hash
    assert len(raw_hash) == 64
    assert all(c in "0123456789abcdef" for c in raw_hash)

    # Get the content back.
    retrieved = await store.get(raw_hash)
    assert retrieved == content


@pytest.mark.asyncio
async def test_get_nonexistent() -> None:
    """Getting a non-existent hash returns None."""
    store = InMemorySnapshotStore()
    result = await store.get("0" * 64)
    assert result is None


@pytest.mark.asyncio
async def test_put_empty_content() -> None:
    """Even empty content should be stored and hashable."""
    store = InMemorySnapshotStore()
    empty_content = b""
    raw_hash = await store.put("https://example.com/empty", empty_content)

    # SHA256 of empty bytes is a known value.
    expected = hashlib.sha256(b"").hexdigest()
    assert raw_hash == expected

    retrieved = await store.get(raw_hash)
    assert retrieved == b""


@pytest.mark.asyncio
async def test_multiple_puts_same_content() -> None:
    """Putting the same content twice returns the same hash."""
    store = InMemorySnapshotStore()
    content = b"duplicate content"

    hash1 = await store.put("https://example.com/page1", content)
    hash2 = await store.put("https://example.com/page2", content)

    assert hash1 == hash2
    retrieved = await store.get(hash1)
    assert retrieved == content
