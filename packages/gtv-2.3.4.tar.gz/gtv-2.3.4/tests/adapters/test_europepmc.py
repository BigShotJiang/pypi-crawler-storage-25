"""Tests for the Europe PMC adapter (W44).

Contract:
- ``query()`` returns well-formed Evidence with a raw_hash that matches
  the excerpt bytes.
- Empty queries return ``[]``, not an exception.
- Upstream errors propagate as exceptions.
- ``health()`` maps 2xx/3xx to HEALTHY, everything else to DEGRADED/DOWN.
- Respects the GTV_EUROPEPMC_DISABLE environment variable.
"""
from __future__ import annotations

import hashlib
import os

import httpx
import pytest
import respx

from gtv.adapters.europepmc import EuropePMCAdapter
from gtv.models import Claim, Domain, Stance, TrustTier

_SEARCH_URL = "https://www.ebi.ac.uk/europepmc/webservices/rest/search"


@pytest.fixture
def canned_response() -> dict:
    return {
        "resultList": {
            "result": [
                {
                    "id": "12345",
                    "source": "MED",
                    "title": "Novel biomarkers for disease detection",
                    "abstractText": "We describe a new set of biomarkers",
                    "pubYear": "2024",
                },
                {
                    "id": "12346",
                    "source": "MED",
                    "title": "Biomarker validation study",
                    "abstractText": "Clinical validation of novel markers",
                    "pubYear": "2023",
                },
            ]
        },
        "hitCount": 2,
    }


@pytest.fixture
async def adapter() -> EuropePMCAdapter:
    a = EuropePMCAdapter()
    yield a
    await a.close()


# Tests

def test_adapter_identity() -> None:
    a = EuropePMCAdapter()
    assert a.source_did == "did:web:europepmc.org"
    assert a.name == "EuropePMC"
    assert a.trust_tier is TrustTier.TIER_1
    assert a.freshness_sla_s > 0


async def test_query_empty_claim_returns_empty(adapter: EuropePMCAdapter) -> None:
    claim = Claim(text="a b", domain=Domain.GENERAL)
    result = await adapter.query(claim)
    assert result == []


async def test_query_returns_evidence(
    adapter: EuropePMCAdapter, canned_response: dict
) -> None:
    claim = Claim(text="biomarker detection disease", domain=Domain.GENERAL)
    with respx.mock:
        respx.get(_SEARCH_URL).mock(
            return_value=httpx.Response(200, json=canned_response)
        )
        result = await adapter.query(claim, max_items=5)

    assert len(result) == 2
    first = result[0]
    assert first.source_did == "did:web:europepmc.org"
    assert first.source_version == "europepmc-rest-v1"
    assert first.stance is Stance.SUPPORTS  # Matches biomarker + detection keywords
    assert "12345" in str(first.url)
    assert "Novel biomarkers" in first.excerpt
    # Verify raw_hash is correct.
    assert (
        first.raw_hash
        == hashlib.sha256(first.excerpt.encode("utf-8")).hexdigest()
    )


async def test_query_respects_max_items(
    adapter: EuropePMCAdapter, canned_response: dict
) -> None:
    claim = Claim(text="biomarker", domain=Domain.GENERAL)
    with respx.mock:
        respx.get(_SEARCH_URL).mock(
            return_value=httpx.Response(200, json=canned_response)
        )
        result = await adapter.query(claim, max_items=1)

    assert len(result) == 1


async def test_query_skips_records_missing_required_fields(
    adapter: EuropePMCAdapter,
) -> None:
    """Malformed upstream records must be dropped, not crash the batch."""
    bad = {
        "resultList": {
            "result": [
                {"id": None, "title": "missing id"},
                {"id": "ok-id-1", "title": ""},
                {
                    "id": "abc-def-123",
                    "source": "MED",
                    "title": "OK ARTICLE",
                    "abstractText": "Good abstract",
                    "pubYear": "2024",
                },
            ]
        }
    }
    claim = Claim(text="article", domain=Domain.GENERAL)
    with respx.mock:
        respx.get(_SEARCH_URL).mock(return_value=httpx.Response(200, json=bad))
        result = await adapter.query(claim)

    assert len(result) == 1
    assert "OK ARTICLE" in result[0].excerpt


async def test_query_propagates_http_error(adapter: EuropePMCAdapter) -> None:
    claim = Claim(text="biomarker", domain=Domain.GENERAL)
    with respx.mock:
        respx.get(_SEARCH_URL).mock(return_value=httpx.Response(503))
        with pytest.raises(httpx.HTTPStatusError):
            await adapter.query(claim)


async def test_query_respects_disable_env(adapter: EuropePMCAdapter) -> None:
    """Query should return empty list if GTV_EUROPEPMC_DISABLE is set."""
    claim = Claim(text="biomarker", domain=Domain.GENERAL)
    os.environ["GTV_EUROPEPMC_DISABLE"] = "1"
    try:
        result = await adapter.query(claim)
        assert result == []
    finally:
        del os.environ["GTV_EUROPEPMC_DISABLE"]


async def test_health_healthy(adapter: EuropePMCAdapter) -> None:
    with respx.mock:
        respx.get(_SEARCH_URL).mock(
            return_value=httpx.Response(200, json={"resultList": {"result": []}})
        )
        h = await adapter.health()

    assert h.state == "HEALTHY"
    assert "responsive" in h.detail.lower()


async def test_health_degraded_on_500(adapter: EuropePMCAdapter) -> None:
    with respx.mock:
        respx.get(_SEARCH_URL).mock(return_value=httpx.Response(500))
        h = await adapter.health()

    assert h.state == "DEGRADED"
    assert "500" in h.detail
