"""Tests for NISTAdapter — mocked and live."""
from __future__ import annotations

import hashlib
import os

import httpx
import pytest
import respx

from gtv.adapters.nist import NISTAdapter
from gtv.models import Claim, Domain, Evidence, Stance

# ============================================================================
# Fixtures
# ============================================================================


@pytest.fixture
def canned_codata_response() -> str:
    """A minimal NIST CODATA plaintext response with sample constants."""
    return """\
CODATA 2019 Fundamental Physical Constants
Quantity (Symbol)  Value  Uncertainty  Unit
--
Planck constant (h)  6.62607015e-34  (exact)  J s
Planck constant (h)  4.135667696e-15  (exact)  eV s
speed of light in vacuum (c)  299792458  (exact)  m s-1
Newtonian constant of gravitation (G)  6.67430e-11  2.15e-15  m3 kg-1 s-2
fine-structure constant (alpha)  7.2973525693e-3  1.1e-12  1
Avogadro constant (N_A)  6.02214076e23  (exact)  mol-1
"""


@pytest.fixture
async def adapter() -> NISTAdapter:
    """Create a NISTAdapter instance for testing."""
    adapter = NISTAdapter()
    yield adapter
    await adapter.close()


# ============================================================================
# Unit Tests (Mocked)
# ============================================================================


@pytest.mark.asyncio
async def test_query_planck_constant(adapter: NISTAdapter, canned_codata_response: str) -> None:
    """Test query for Planck constant returns SUPPORTS evidence."""
    with respx.mock:
        # Mock the NIST constants endpoint
        respx.get(
            "https://physics.nist.gov/cgi-bin/cuu/Constants/Table/allascii.txt"
        ).mock(return_value=httpx.Response(200, text=canned_codata_response))

        claim = Claim(
            text="The Planck constant is approximately 6.626e-34 J*s",
            domain=Domain.PHYSICS,
        )

        evidence = await adapter.query(claim)

        assert len(evidence) > 0
        assert evidence[0].stance == Stance.SUPPORTS
        assert evidence[0].source_did == "did:web:nist.gov"
        assert "planck" in evidence[0].excerpt.lower()
        assert len(evidence[0].raw_hash) == 64
        assert evidence[0].retrieved_at.tzinfo is not None


@pytest.mark.asyncio
async def test_query_unmatched_term(adapter: NISTAdapter, canned_codata_response: str) -> None:
    """Test query for unmatched term returns empty list."""
    with respx.mock:
        respx.get(
            "https://physics.nist.gov/cgi-bin/cuu/Constants/Table/allascii.txt"
        ).mock(return_value=httpx.Response(200, text=canned_codata_response))

        claim = Claim(
            text="The price of Bitcoin is very high today",
            domain=Domain.GENERAL,
        )

        evidence = await adapter.query(claim)
        assert len(evidence) == 0


@pytest.mark.asyncio
async def test_query_speed_of_light(adapter: NISTAdapter, canned_codata_response: str) -> None:
    """Test query for speed of light returns evidence."""
    with respx.mock:
        respx.get(
            "https://physics.nist.gov/cgi-bin/cuu/Constants/Table/allascii.txt"
        ).mock(return_value=httpx.Response(200, text=canned_codata_response))

        claim = Claim(
            text="The speed of light in vacuum is 299792458 m/s",
            domain=Domain.PHYSICS,
        )

        evidence = await adapter.query(claim)
        assert len(evidence) > 0
        assert evidence[0].stance == Stance.SUPPORTS


@pytest.mark.asyncio
async def test_evidence_structure(adapter: NISTAdapter, canned_codata_response: str) -> None:
    """Test that evidence has proper structure and fields."""
    with respx.mock:
        respx.get(
            "https://physics.nist.gov/cgi-bin/cuu/Constants/Table/allascii.txt"
        ).mock(return_value=httpx.Response(200, text=canned_codata_response))

        claim = Claim(text="Avogadro constant", domain=Domain.GENERAL)

        evidence = await adapter.query(claim)
        if evidence:
            ev = evidence[0]
            assert isinstance(ev, Evidence)
            assert ev.claim_id == claim.claim_id
            assert ev.source_did == "did:web:nist.gov"
            assert ev.source_version == "nist-codata-2019"
            assert ev.stance == Stance.SUPPORTS
            assert len(ev.excerpt) <= 1200
            assert str(ev.url).startswith("https://physics.nist.gov")
            assert len(ev.raw_hash) == 64
            assert isinstance(ev.raw_hash, str)
            assert all(c in "0123456789abcdef" for c in ev.raw_hash)
            assert ev.retrieved_at.tzinfo is not None


@pytest.mark.asyncio
async def test_network_error_handling(adapter: NISTAdapter) -> None:
    """Test graceful handling of network errors."""
    with respx.mock:
        respx.get(
            "https://physics.nist.gov/cgi-bin/cuu/Constants/Table/allascii.txt"
        ).mock(side_effect=httpx.NetworkError("Connection failed"))

        claim = Claim(text="Planck constant test", domain=Domain.PHYSICS)

        # Should return empty list on network error, not raise
        evidence = await adapter.query(claim)
        assert isinstance(evidence, list)
        assert len(evidence) == 0


@pytest.mark.asyncio
async def test_health_check_success(adapter: NISTAdapter) -> None:
    """Test health check returns HEALTHY on success."""
    with respx.mock:
        respx.get("https://physics.nist.gov/cuu/Constants/").mock(
            return_value=httpx.Response(200)
        )

        health = await adapter.health()
        assert health.state == "HEALTHY"
        assert health.checked_at.tzinfo is not None


@pytest.mark.asyncio
async def test_health_check_network_error(adapter: NISTAdapter) -> None:
    """Test health check returns DOWN on network error."""
    with respx.mock:
        respx.get("https://physics.nist.gov/cuu/Constants/").mock(
            side_effect=httpx.NetworkError("Connection failed")
        )

        health = await adapter.health()
        assert health.state == "DOWN"
        assert "Network error" in health.detail


@pytest.mark.asyncio
async def test_snapshot_basic(adapter: NISTAdapter) -> None:
    """Test snapshot fetches and hashes content."""
    with respx.mock:
        test_content = b"NIST Constants Data"
        respx.get("https://physics.nist.gov/cuu/Constants/").mock(
            return_value=httpx.Response(200, content=test_content)
        )

        snapshot = await adapter.snapshot("https://physics.nist.gov/cuu/Constants/")
        assert snapshot.url == "https://physics.nist.gov/cuu/Constants/"
        assert snapshot.content == test_content
        assert snapshot.raw_hash == hashlib.sha256(test_content).hexdigest()


# ============================================================================
# Live Tests (skipped unless GTV_LIVE=1)
# ============================================================================


@pytest.mark.skipif(not os.environ.get("GTV_LIVE"), reason="GTV_LIVE not set")
@pytest.mark.asyncio
async def test_live_nist_query() -> None:
    """Live test: query actual NIST API for Planck constant."""
    adapter = NISTAdapter()
    try:
        claim = Claim(text="Planck constant", domain=Domain.PHYSICS)
        evidence = await adapter.query(claim)

        # Should get some evidence or empty (both acceptable in live context)
        assert isinstance(evidence, list)
        if evidence:
            assert evidence[0].source_did == "did:web:nist.gov"
            assert len(evidence[0].raw_hash) == 64
    finally:
        await adapter.close()


@pytest.mark.skipif(not os.environ.get("GTV_LIVE"), reason="GTV_LIVE not set")
@pytest.mark.asyncio
async def test_live_nist_health() -> None:
    """Live test: check actual NIST health endpoint."""
    adapter = NISTAdapter()
    try:
        health = await adapter.health()
        assert health.state in ["HEALTHY", "DEGRADED", "DOWN"]
    finally:
        await adapter.close()
