"""Tests for the adapter SDK surface (W38).

Covers:
 1. ``gtv.adapters.sdk`` public re-exports (prevents accidental breakage
    of the stable import path).
 2. Entry-point discovery — successful load, failure tolerance, allowlist
    filtering, and the disable env var.
 3. Conformance suite — accepts a valid adapter, rejects each kind of
    misbehaviour.
"""

from __future__ import annotations

from datetime import UTC, datetime
from types import SimpleNamespace
from typing import Any

import pytest

from gtv.adapters import sdk
from gtv.adapters.base import RawSnapshot, SourceAdapter
from gtv.adapters.conformance import (
    ConformanceError,
    run_adapter_conformance,
)
from gtv.adapters.discovery import discover_plugin_adapters
from gtv.models import Claim, Evidence, HealthStatus, Stance, TrustTier

# ---------------------------------------------------------------------------
# 1. Public SDK surface
# ---------------------------------------------------------------------------


def test_sdk_reexports_stable_surface() -> None:
    """These names form the public contract. Don't break them silently."""
    required = {
        "Claim", "Domain", "Evidence", "HealthStatus", "RawSnapshot",
        "SourceAdapter", "SourceType", "Stance", "TrustTier",
        "register_adapter",
    }
    missing = required - set(sdk.__all__)
    assert not missing, f"sdk.__all__ is missing {missing}"
    for name in required:
        assert hasattr(sdk, name), f"gtv.adapters.sdk.{name} is not re-exported"


def test_sdk_register_adapter_delegates() -> None:
    from gtv.adapters import REGISTRY

    class _Ghost(SourceAdapter):
        source_did = "did:web:ghost.example"
        name = "Ghost"
        trust_tier = TrustTier.TIER_3
        freshness_sla_s = 60

        async def query(self, claim: Claim, max_items: int = 5) -> list[Evidence]:
            return []

        async def snapshot(self, url: str) -> RawSnapshot:
            return RawSnapshot(url=url, content=b"", retrieved_at_iso="2026-04-21T00:00:00Z")

        async def health(self) -> HealthStatus:
            return HealthStatus(state="HEALTHY")

        async def close(self) -> None:
            return None

    adapter = _Ghost()
    saved = dict(REGISTRY)
    REGISTRY.pop(adapter.source_did, None)
    try:
        sdk.register_adapter(adapter)
        assert REGISTRY[adapter.source_did] is adapter
    finally:
        REGISTRY.clear()
        REGISTRY.update(saved)


# ---------------------------------------------------------------------------
# 2. Entry-point discovery
# ---------------------------------------------------------------------------


class _StubAdapter(SourceAdapter):
    """Minimal well-formed adapter used as a discovery/conformance fixture."""

    source_did = "did:web:sdk-stub.example"
    name = "SdkStub"
    trust_tier = TrustTier.TIER_2
    freshness_sla_s = 900

    async def query(self, claim: Claim, max_items: int = 5) -> list[Evidence]:
        return [
            Evidence(
                claim_id=claim.claim_id,
                source_did=self.source_did,
                source_version="1.0",
                stance=Stance.SUPPORTS,
                excerpt="stub",
                url="https://stub.example/",
                retrieved_at=datetime.now(tz=UTC),
                raw_hash="a" * 64,
            )
        ]

    async def snapshot(self, url: str) -> RawSnapshot:
        return RawSnapshot(url=url, content=b"", retrieved_at_iso="2026-04-21T00:00:00Z")

    async def health(self) -> HealthStatus:
        return HealthStatus(state="HEALTHY")

    async def close(self) -> None:
        return None


class _Boom:
    """Target that raises on instantiation — simulates a broken plugin."""

    def __init__(self) -> None:
        raise RuntimeError("plugin init failed")


class _NotAdapter:
    """Target that is zero-arg-constructible but isn't a SourceAdapter."""

    def __init__(self) -> None:
        pass


def _fake_entry_point(name: str, target: type) -> Any:
    """Build an EntryPoint-shaped stub whose ``.load()`` returns ``target``."""
    return SimpleNamespace(name=name, load=lambda: target)


@pytest.fixture
def patched_entry_points(monkeypatch: pytest.MonkeyPatch):
    """Install a fake ``_iter_plugin_entry_points`` returning whatever we pass."""

    holder: dict[str, list[Any]] = {"eps": []}

    def fake_iter() -> list[Any]:
        return list(holder["eps"])

    monkeypatch.setattr(
        "gtv.adapters.discovery._iter_plugin_entry_points", fake_iter
    )
    return holder


def test_discovery_loads_valid_plugin(patched_entry_points: dict[str, list[Any]]) -> None:
    patched_entry_points["eps"] = [_fake_entry_point("stub", _StubAdapter)]

    registered: list[SourceAdapter] = []
    loaded = discover_plugin_adapters(register_fn=lambda a: registered.append(a))

    assert len(loaded) == 1
    assert isinstance(loaded[0], _StubAdapter)
    assert registered == loaded


def test_discovery_skips_failing_plugin(patched_entry_points: dict[str, list[Any]]) -> None:
    patched_entry_points["eps"] = [
        _fake_entry_point("boom", _Boom),  # raises on __init__
        _fake_entry_point("stub", _StubAdapter),
    ]
    registered: list[SourceAdapter] = []
    loaded = discover_plugin_adapters(register_fn=lambda a: registered.append(a))

    # Exactly one survived — the well-formed one.
    assert len(loaded) == 1
    assert isinstance(loaded[0], _StubAdapter)


def test_discovery_rejects_non_adapter_target(patched_entry_points: dict[str, list[Any]]) -> None:
    patched_entry_points["eps"] = [_fake_entry_point("not-adapter", _NotAdapter)]
    loaded = discover_plugin_adapters(register_fn=lambda _a: None)
    assert loaded == []


def test_discovery_honours_disable_env(
    patched_entry_points: dict[str, list[Any]], monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("GTV_DISABLE_PLUGIN_ADAPTERS", "1")
    patched_entry_points["eps"] = [_fake_entry_point("stub", _StubAdapter)]

    loaded = discover_plugin_adapters(register_fn=lambda _a: None)
    assert loaded == []


def test_discovery_honours_allowlist(monkeypatch: pytest.MonkeyPatch) -> None:
    """Allowlist is applied inside _iter_plugin_entry_points, so we test
    the real function with a patched ``entry_points`` backend."""

    eps = [
        _fake_entry_point("keep", _StubAdapter),
        _fake_entry_point("drop", _StubAdapter),
    ]
    monkeypatch.setattr("gtv.adapters.discovery.entry_points", lambda group: eps)
    monkeypatch.setenv("GTV_PLUGIN_ADAPTER_ALLOWLIST", "keep")

    registered: list[SourceAdapter] = []
    loaded = discover_plugin_adapters(register_fn=lambda a: registered.append(a))

    assert len(loaded) == 1
    # Both use _StubAdapter but only the "keep" entry point was admitted.
    assert all(a.source_did == _StubAdapter.source_did for a in loaded)


def test_discovery_registration_failure_is_logged_not_raised(
    patched_entry_points: dict[str, list[Any]]
) -> None:
    patched_entry_points["eps"] = [_fake_entry_point("stub", _StubAdapter)]

    def _bad_register(_a: SourceAdapter) -> None:
        raise ValueError("already registered")

    loaded = discover_plugin_adapters(register_fn=_bad_register)
    assert loaded == []  # registration failure ⇒ plugin skipped, no raise


# ---------------------------------------------------------------------------
# 3. Conformance suite
# ---------------------------------------------------------------------------


async def test_conformance_passes_for_valid_adapter() -> None:
    await run_adapter_conformance(_StubAdapter())


async def test_conformance_rejects_bad_did() -> None:
    a = _StubAdapter()
    a.source_did = "not-a-did"
    with pytest.raises(ConformanceError, match="source_did"):
        await run_adapter_conformance(a)


async def test_conformance_rejects_non_list_query_result() -> None:
    class BrokenAdapter(_StubAdapter):
        async def query(self, claim: Claim, max_items: int = 5) -> Any:
            return "not a list"  # type: ignore[return-value]

    with pytest.raises(ConformanceError, match="must return a list"):
        await run_adapter_conformance(BrokenAdapter())


async def test_conformance_rejects_query_that_raises() -> None:
    class RaisingAdapter(_StubAdapter):
        async def query(self, claim: Claim, max_items: int = 5) -> list[Evidence]:
            raise RuntimeError("upstream down")

    with pytest.raises(ConformanceError, match="query\\(\\) raised"):
        await run_adapter_conformance(RaisingAdapter())


async def test_conformance_rejects_mismatched_source_did_in_evidence() -> None:
    class SpoofAdapter(_StubAdapter):
        async def query(self, claim: Claim, max_items: int = 5) -> list[Evidence]:
            return [
                Evidence(
                    claim_id=claim.claim_id,
                    source_did="did:web:SOMEBODY-ELSE",  # wrong!
                    source_version="1.0",
                    stance=Stance.SUPPORTS,
                    excerpt="x",
                    url="https://x/",
                    retrieved_at=datetime.now(tz=UTC),
                    raw_hash="0" * 64,
                )
            ]

    with pytest.raises(ConformanceError, match="source_did="):
        await run_adapter_conformance(SpoofAdapter())


async def test_conformance_rejects_non_idempotent_close() -> None:
    class StickyAdapter(_StubAdapter):
        def __init__(self) -> None:
            self._closed = False

        async def close(self) -> None:
            if self._closed:
                raise RuntimeError("already closed")
            self._closed = True

    with pytest.raises(ConformanceError, match="not idempotent"):
        await run_adapter_conformance(StickyAdapter())


async def test_conformance_rejects_wrong_health_type() -> None:
    class FunnyHealth(_StubAdapter):
        async def health(self) -> Any:
            return "ok"  # type: ignore[return-value]

    with pytest.raises(ConformanceError, match="health\\(\\) must return"):
        await run_adapter_conformance(FunnyHealth())
