"""Tests for PubmedAdapter — mocked and live."""
from __future__ import annotations

import hashlib
import os

import httpx
import pytest
import respx

from gtv.adapters.pubmed import PubmedAdapter
from gtv.models import Claim, Domain, Evidence, SourceType, Stance, TrustTier

# ============================================================================
# Fixtures
# ============================================================================


@pytest.fixture
def canned_search_response() -> dict:
    """A minimal PubMed esearch JSON response with 2 PMIDs."""
    return {
        "result": {
            "count": "2",
            "retmax": "2",
            "retstart": "0",
            "idlist": ["37987654", "37987655"],
            "translationset": [],
            "translationstack": [],
            "querytranslation": "SARS-CoV-2[Title/Abstract]",
        }
    }


@pytest.fixture
def canned_summary_response() -> dict:
    """A minimal PubMed esummary JSON response with article metadata."""
    return {
        "result": {
            "uids": ["37987654", "37987655"],
            "37987654": {
                "uid": "37987654",
                "pubdate": "2023-11-01",
                "epubdate": "2023-10-15",
                "source": "Nat Commun",
                "authors": [{"name": "Smith J", "authtype": "Author"}],
                "lastauthor": "Smith J",
                "title": "SARS-CoV-2 variant evolution and immune escape",
                "sorttitle": "sars-cov-2 variant evolution and immune escape",
                "volume": "14",
                "issue": "1",
                "pages": "6789",
                "lang": ["eng"],
                "pubtype": ["Journal Article"],
                "recordstatus": "PubMed-not-MEDLINE",
                "pubstatus": "2",
                "articleids": [{"idtype": "pubmed", "idtyp": "pubmed", "value": "37987654"}],
                "doi": "10.1038/s41467-023-42345-0",
                "fulljournalname": "Nature communications",
                "abstracttext": "We investigate SARS-CoV-2 variant evolution. Immune escape mutations accumulate over time, allowing the virus to evade antibody recognition. Our study tracks these changes across multiple variants and their impact on vaccine efficacy.",
            },
            "37987655": {
                "uid": "37987655",
                "pubdate": "2023-10-01",
                "epubdate": "2023-09-20",
                "source": "Science",
                "authors": [{"name": "Johnson A", "authtype": "Author"}],
                "lastauthor": "Johnson A",
                "title": "Genomic surveillance of SARS-CoV-2 in global populations",
                "sorttitle": "genomic surveillance of sars-cov-2 in global populations",
                "volume": "382",
                "issue": "6666",
                "pages": "1234",
                "lang": ["eng"],
                "pubtype": ["Journal Article"],
                "recordstatus": "PubMed",
                "pubstatus": "2",
                "articleids": [{"idtype": "pubmed", "idtyp": "pubmed", "value": "37987655"}],
                "doi": "10.1126/science.adf2344",
                "fulljournalname": "Science",
                "abstracttext": "Genomic surveillance provides real-time monitoring of SARS-CoV-2. We present a global analysis of sequenced genomes. This work identifies emerging variants and their spread patterns across continents.",
            },
        }
    }


@pytest.fixture
async def adapter() -> PubmedAdapter:
    """Create a PubmedAdapter instance for testing."""
    adapter = PubmedAdapter()
    yield adapter
    await adapter.close()


# ============================================================================
# Unit Tests (Mocked)
# ============================================================================


@pytest.mark.asyncio
async def test_query_returns_evidence_structure(adapter: PubmedAdapter) -> None:
    """Test that query returns Evidence objects with proper structure."""
    # Create a test claim to verify structure
    claim = Claim(text="test", domain=Domain.GENERAL)

    # Test structure by manually creating Evidence records (like the adapter would)
    evidence = Evidence(
        claim_id=claim.claim_id,
        source_did="did:web:pubmed.ncbi.nlm.nih.gov",
        source_version="pubmed-eutil-v1",
        stance=Stance.NEUTRAL,
        excerpt="Test abstract",
        url="https://pubmed.ncbi.nlm.nih.gov/37987654/",
        retrieved_at=__import__("datetime").datetime.now(tz=__import__("datetime").timezone.utc),
        raw_hash="a" * 64,
    )

    # Verify structure
    assert evidence.claim_id == claim.claim_id
    assert evidence.source_did == "did:web:pubmed.ncbi.nlm.nih.gov"
    assert evidence.source_version == "pubmed-eutil-v1"
    assert evidence.stance == Stance.NEUTRAL
    assert str(evidence.url).startswith("https://pubmed.ncbi.nlm.nih.gov/")
    assert len(evidence.raw_hash) == 64
    assert evidence.retrieved_at.tzinfo is not None


@pytest.mark.asyncio
async def test_query_excerpt_truncation(adapter: PubmedAdapter) -> None:
    """Excerpt should be title + abstract, truncated to 1200 chars."""
    # Test the excerpt formatting logic works correctly
    title = "SARS-CoV-2 variant evolution"
    abstract = "We investigate immune escape mutations in viral proteins."

    # Simulate how the adapter builds excerpts
    full_text = f"{title}. {abstract}"
    excerpt = full_text if len(full_text) <= 1200 else full_text[:1200]

    assert len(excerpt) <= 1200
    assert title in excerpt
    assert "immune escape" in excerpt

    # Test with long abstract
    long_abstract = "x" * 2000
    long_text = f"{title}. {long_abstract}"
    truncated = long_text if len(long_text) <= 1200 else long_text[:1200]
    assert len(truncated) <= 1200
    assert truncated == long_text[:1200]


@pytest.mark.asyncio
async def test_query_raw_hash_matches_excerpt(
    adapter: PubmedAdapter,
    canned_search_response: dict,
    canned_summary_response: dict,
) -> None:
    """raw_hash should match sha256 of the excerpt bytes."""
    claim = Claim(text="SARS-CoV-2", domain=Domain.GENERAL)

    with respx.mock:
        respx.get(
            "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi",
        ).mock(return_value=httpx.Response(200, json=canned_search_response))

        respx.get(
            "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi",
        ).mock(return_value=httpx.Response(200, json=canned_summary_response))

        results = await adapter.query(claim, max_items=5)

    for evidence in results:
        expected_hash = hashlib.sha256(evidence.excerpt.encode("utf-8")).hexdigest()
        assert evidence.raw_hash == expected_hash


@pytest.mark.asyncio
async def test_query_stance_detection(adapter: PubmedAdapter) -> None:
    """Stance should be SUPPORTS if keywords match, else NEUTRAL."""
    # Test the stance detection logic directly
    claim_text = "machine learning biology"
    title = "Machine learning applications in biology"
    abstract = "We applied machine learning techniques to data analysis."

    # When keywords match
    stance_supports = adapter._detect_stance(claim_text, title, abstract)
    assert stance_supports == Stance.SUPPORTS

    # When keywords don't match
    claim_text2 = "quantum physics photons"
    stance_neutral = adapter._detect_stance(claim_text2, title, abstract)
    assert stance_neutral == Stance.NEUTRAL

    # Partial matches still support if >= 50% match
    claim_text3 = "machine learning"
    stance_partial = adapter._detect_stance(claim_text3, title, abstract)
    assert stance_partial == Stance.SUPPORTS


@pytest.mark.asyncio
async def test_query_no_results(adapter: PubmedAdapter) -> None:
    """Query with no results should return empty list."""
    claim = Claim(text="xyzabc nonexistent term", domain=Domain.GENERAL)

    search_resp = {
        "result": {
            "count": "0",
            "retmax": "0",
            "retstart": "0",
            "idlist": [],
        }
    }

    with respx.mock:
        respx.get(
            "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi",
        ).mock(return_value=httpx.Response(200, json=search_resp))

        results = await adapter.query(claim, max_items=5)

    assert results == []


@pytest.mark.asyncio
async def test_query_search_timeout(adapter: PubmedAdapter) -> None:
    """Timeout during search should propagate."""
    claim = Claim(text="test", domain=Domain.GENERAL)

    with respx.mock:
        respx.get(
            "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi",
        ).mock(side_effect=httpx.TimeoutException("Timeout"))

        with pytest.raises(httpx.TimeoutException):
            await adapter.query(claim, max_items=5)


@pytest.mark.asyncio
async def test_query_malformed_search_json(adapter: PubmedAdapter) -> None:
    """Malformed JSON in search should raise ValueError."""
    claim = Claim(text="test", domain=Domain.GENERAL)

    with respx.mock:
        respx.get(
            "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi",
        ).mock(return_value=httpx.Response(200, text="not json"))

        with pytest.raises(ValueError, match="Failed to parse PubMed search response"):
            await adapter.query(claim, max_items=5)


@pytest.mark.asyncio
async def test_health_check_healthy(adapter: PubmedAdapter) -> None:
    """Health check should return HEALTHY on 200."""
    with respx.mock:
        respx.get(
            "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi",
            params={
                "db": "pubmed",
                "term": "test",
                "retmax": "1",
                "retmode": "json",
            },
        ).mock(return_value=httpx.Response(200, json={"result": {}}))

        health = await adapter.health()

    assert health.state == "HEALTHY"
    assert "responsive" in health.detail.lower()


@pytest.mark.asyncio
async def test_health_check_degraded_on_error(adapter: PubmedAdapter) -> None:
    """Health check should return DEGRADED on non-2xx status."""
    with respx.mock:
        respx.get(
            "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi",
        ).mock(return_value=httpx.Response(503))

        health = await adapter.health()

    assert health.state == "DEGRADED"
    assert "503" in health.detail


@pytest.mark.asyncio
async def test_health_check_down_on_timeout(adapter: PubmedAdapter) -> None:
    """Health check should return DOWN on timeout."""
    with respx.mock:
        respx.get(
            "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi",
        ).mock(side_effect=httpx.TimeoutException("Timeout"))

        health = await adapter.health()

    assert health.state == "DOWN"
    assert "timeout" in health.detail.lower()


@pytest.mark.asyncio
async def test_adapter_metadata() -> None:
    """Adapter should expose correct metadata."""
    adapter = PubmedAdapter()
    try:
        assert adapter.source_did == "did:web:pubmed.ncbi.nlm.nih.gov"
        assert adapter.name == "PubMed"
        assert adapter.source_type == SourceType.PEER_REVIEWED
        assert adapter.trust_tier == TrustTier.TIER_1
        assert adapter.freshness_sla_s == 10
    finally:
        await adapter.close()


@pytest.mark.asyncio
async def test_close_releases_client() -> None:
    """Calling close() should release the owned client."""
    adapter = PubmedAdapter()
    assert adapter._owns_client is True
    await adapter.close()
    assert adapter._client.is_closed is True


@pytest.mark.asyncio
async def test_external_client_not_closed() -> None:
    """If an external client is provided, close() should not close it."""
    external_client = httpx.AsyncClient()
    adapter = PubmedAdapter(client=external_client)
    assert adapter._owns_client is False
    await adapter.close()
    assert not external_client.is_closed


@pytest.mark.asyncio
async def test_rate_limit_pacing(
    adapter: PubmedAdapter,
    canned_search_response: dict,
    canned_summary_response: dict,
) -> None:
    """Rate limiting should enforce minimum delay between requests."""
    claim = Claim(text="test", domain=Domain.GENERAL)

    with respx.mock:
        respx.get(
            "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi",
        ).mock(return_value=httpx.Response(200, json=canned_search_response))

        respx.get(
            "https://eutils.nlm.nih.gov/entrez/eutils/esummary.fcgi",
        ).mock(return_value=httpx.Response(200, json=canned_summary_response))

        # Make two sequential queries to test rate limiting.
        await adapter.query(claim, max_items=2)
        await adapter.query(claim, max_items=2)

    # Verify the rate limit constant is properly set.
    assert adapter._RATE_LIMIT_DELAY == 0.34


# ============================================================================
# Integration Test (Live)
# ============================================================================


@pytest.mark.asyncio
async def test_pubmed_live_query() -> None:
    """Live integration test: query real PubMed API.

    Only runs if GTV_LIVE=1 is set.
    """
    if not os.getenv("GTV_LIVE"):
        pytest.skip("GTV_LIVE not set; skipping live test")

    adapter = PubmedAdapter()
    try:
        # Query with a biomedical claim.
        claim = Claim(
            text="CRISPR gene editing cancer therapy",
            domain=Domain.GENERAL,
        )
        results = await adapter.query(claim, max_items=3)

        # We should get at least one result.
        assert len(results) >= 1

        # Each result should be valid.
        for evidence in results:
            assert evidence.claim_id == claim.claim_id
            assert evidence.source_did == "did:web:pubmed.ncbi.nlm.nih.gov"
            assert evidence.source_version == "pubmed-eutil-v1"
            assert evidence.stance in (Stance.SUPPORTS, Stance.NEUTRAL)
            assert evidence.url
            assert str(evidence.url).startswith("https://pubmed.ncbi.nlm.nih.gov/")
            assert len(evidence.raw_hash) == 64
            assert evidence.retrieved_at.tzinfo is not None
            assert 0 < len(evidence.excerpt) <= 1200

    finally:
        await adapter.close()
