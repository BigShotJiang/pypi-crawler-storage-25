"""Tests for InspireHepAdapter — mocked and live."""
from __future__ import annotations

import hashlib
import os

import httpx
import pytest
import respx

from gtv.adapters.inspire_hep import InspireHepAdapter
from gtv.models import Claim, Domain, SourceType, Stance, TrustTier

# ============================================================================
# Fixtures
# ============================================================================


@pytest.fixture
def canned_inspire_response() -> dict:
    """A minimal JSON response from INSPIRE-HEP API with 2 entries."""
    return {
        "hits": {
            "total": 2,
            "hits": [
                {
                    "id": "1234567",
                    "metadata": {
                        "control_number": 1234567,
                        "titles": [
                            {"title": "Gravitational Waves from Merging Neutron Stars"}
                        ],
                        "abstracts": [
                            {
                                "value": "We present observations of gravitational waves from the merger of two neutron stars. The detection was made using advanced LIGO and Virgo detectors. The signal shows clear evidence of mass transfer and ejecta formation. This event provides unique constraints on the neutron star equation of state and the production of heavy elements via rapid neutron capture."
                            }
                        ],
                        "arxiv_eprints": [{"value": "2401.01234"}],
                        "dois": [{"value": "10.1234/example.1"}],
                    },
                },
                {
                    "id": "1234568",
                    "metadata": {
                        "control_number": 1234568,
                        "titles": [
                            {"title": "Black Hole Formation in Gravitational Collapse"}
                        ],
                        "abstracts": [
                            {
                                "value": "We study the formation of black holes through gravitational collapse in various spacetime metrics. Our numerical simulations use state-of-the-art adaptive mesh refinement techniques. The results show how the event horizon forms and expands during collapse. We also analyze the role of angular momentum in determining the final black hole properties."
                            }
                        ],
                        "arxiv_eprints": [{"value": "2401.05678"}],
                        "dois": [{"value": "10.1234/example.2"}],
                    },
                },
            ],
        }
    }


@pytest.fixture
async def adapter() -> InspireHepAdapter:
    """Create an InspireHepAdapter instance for testing."""
    adapter = InspireHepAdapter()
    yield adapter
    await adapter.close()


# ============================================================================
# Unit Tests (Mocked)
# ============================================================================


@pytest.mark.asyncio
async def test_query_returns_evidence(
    adapter: InspireHepAdapter, canned_inspire_response: dict
) -> None:
    """Query should return list of Evidence records with valid fields."""
    claim = Claim(text="gravitational waves neutron stars", domain=Domain.PHYSICS)

    with respx.mock:
        respx.get(
            "https://inspirehep.net/api/literature",
            params={
                "q": "gravitational waves neutron stars",
                "fields": "titles,abstracts,arxiv_eprints,dois,control_number",
                "size": 5,
            },
        ).mock(return_value=httpx.Response(200, json=canned_inspire_response))

        results = await adapter.query(claim, max_items=5)

    assert len(results) == 2
    for evidence in results:
        # Check all required fields.
        assert evidence.claim_id == claim.claim_id
        assert evidence.source_did == "did:web:inspirehep.net"
        assert evidence.source_version == "inspire-api-v1"
        assert evidence.stance == Stance.NEUTRAL
        assert str(evidence.url).startswith("https://inspirehep.net/literature/")
        assert len(evidence.raw_hash) == 64
        assert all(c in "0123456789abcdef" for c in evidence.raw_hash)
        assert evidence.retrieved_at.tzinfo is not None


@pytest.mark.asyncio
async def test_query_excerpt_from_abstract(
    adapter: InspireHepAdapter, canned_inspire_response: dict
) -> None:
    """Excerpt should be the abstract text, trimmed to 1200 chars."""
    claim = Claim(text="gravitational waves", domain=Domain.PHYSICS)

    with respx.mock:
        respx.get(
            "https://inspirehep.net/api/literature",
            params={
                "q": "gravitational waves",
                "fields": "titles,abstracts,arxiv_eprints,dois,control_number",
                "size": 5,
            },
        ).mock(return_value=httpx.Response(200, json=canned_inspire_response))

        results = await adapter.query(claim, max_items=5)

    # First entry has a known abstract.
    first_abstract = (
        "We present observations of gravitational waves from the merger of two "
        "neutron stars. The detection was made using advanced LIGO and Virgo detectors. "
        "The signal shows clear evidence of mass transfer and ejecta formation. This event "
        "provides unique constraints on the neutron star equation of state and the production "
        "of heavy elements via rapid neutron capture."
    )
    assert results[0].excerpt == first_abstract


@pytest.mark.asyncio
async def test_query_raw_hash_matches_abstract(
    adapter: InspireHepAdapter, canned_inspire_response: dict
) -> None:
    """raw_hash should match sha256 of the abstract bytes."""
    claim = Claim(text="gravitational waves", domain=Domain.PHYSICS)

    with respx.mock:
        respx.get(
            "https://inspirehep.net/api/literature",
            params={
                "q": "gravitational waves",
                "fields": "titles,abstracts,arxiv_eprints,dois,control_number",
                "size": 5,
            },
        ).mock(return_value=httpx.Response(200, json=canned_inspire_response))

        results = await adapter.query(claim, max_items=5)

    # Check that the hash matches.
    first_abstract = (
        "We present observations of gravitational waves from the merger of two "
        "neutron stars. The detection was made using advanced LIGO and Virgo detectors. "
        "The signal shows clear evidence of mass transfer and ejecta formation. This event "
        "provides unique constraints on the neutron star equation of state and the production "
        "of heavy elements via rapid neutron capture."
    )
    expected_hash = hashlib.sha256(first_abstract.encode("utf-8")).hexdigest()
    assert results[0].raw_hash == expected_hash


@pytest.mark.asyncio
async def test_query_timeout_propagates(adapter: InspireHepAdapter) -> None:
    """Timeout exceptions should be raised, not swallowed."""
    claim = Claim(text="test", domain=Domain.PHYSICS)

    with respx.mock:
        respx.get(
            "https://inspirehep.net/api/literature",
            params={
                "q": "test",
                "fields": "titles,abstracts,arxiv_eprints,dois,control_number",
                "size": 5,
            },
        ).mock(side_effect=httpx.TimeoutException("Timeout"))

        with pytest.raises(httpx.TimeoutException):
            await adapter.query(claim, max_items=5)


@pytest.mark.asyncio
async def test_query_empty_claim_text() -> None:
    """Empty claim should return empty list (no query to send)."""
    adapter = InspireHepAdapter()
    try:
        # Create a claim with only stopwords to get empty query.
        claim = Claim(text="the a is", domain=Domain.PHYSICS)
        results = await adapter.query(claim)
        assert results == []
    finally:
        await adapter.close()


@pytest.mark.asyncio
async def test_health_check_healthy(adapter: InspireHepAdapter) -> None:
    """Health check should return HEALTHY on 200."""
    with respx.mock:
        respx.get(
            "https://inspirehep.net/api/literature",
            params={"q": "test", "size": "1"},
        ).mock(return_value=httpx.Response(200, json={"hits": {"hits": []}}))

        health = await adapter.health()

    assert health.state == "HEALTHY"


@pytest.mark.asyncio
async def test_health_check_degraded_on_error(adapter: InspireHepAdapter) -> None:
    """Health check should return DEGRADED on non-2xx status."""
    with respx.mock:
        respx.get(
            "https://inspirehep.net/api/literature",
            params={"q": "test", "size": "1"},
        ).mock(return_value=httpx.Response(503))

        health = await adapter.health()

    assert health.state == "DEGRADED"
    assert "503" in health.detail


@pytest.mark.asyncio
async def test_health_check_down_on_timeout(adapter: InspireHepAdapter) -> None:
    """Health check should return DOWN on timeout."""
    with respx.mock:
        respx.get(
            "https://inspirehep.net/api/literature",
            params={"q": "test", "size": "1"},
        ).mock(side_effect=httpx.TimeoutException("Timeout"))

        health = await adapter.health()

    assert health.state == "DOWN"
    assert "timeout" in health.detail.lower()


@pytest.mark.asyncio
async def test_adapter_metadata() -> None:
    """Adapter should expose correct metadata."""
    adapter = InspireHepAdapter()
    try:
        assert adapter.source_did == "did:web:inspirehep.net"
        assert adapter.name == "INSPIRE-HEP"
        assert adapter.source_type == SourceType.PEER_REVIEWED
        assert adapter.trust_tier == TrustTier.TIER_1
        assert adapter.freshness_sla_s == 5
    finally:
        await adapter.close()


@pytest.mark.asyncio
async def test_close_releases_client() -> None:
    """Calling close() should release the owned client."""
    adapter = InspireHepAdapter()
    assert adapter._owns_client is True
    await adapter.close()
    # After close, client should be closed (httpx tracks this).
    assert adapter._client.is_closed is True


@pytest.mark.asyncio
async def test_external_client_not_closed() -> None:
    """If an external client is provided, close() should not close it."""
    external_client = httpx.AsyncClient()
    adapter = InspireHepAdapter(client=external_client)
    assert adapter._owns_client is False
    await adapter.close()
    # External client should not be closed by adapter.
    assert not external_client.is_closed


# ============================================================================
# Integration Test (Live)
# ============================================================================


@pytest.mark.asyncio
async def test_inspire_live_query() -> None:
    """Live integration test: query real INSPIRE-HEP API.

    Only runs if GTV_LIVE=1 is set.
    """
    if not os.getenv("GTV_LIVE"):
        pytest.skip("GTV_LIVE not set; skipping live test")

    adapter = InspireHepAdapter()
    try:
        # Query with a simple physics claim.
        claim = Claim(
            text="black hole thermodynamics entropy",
            domain=Domain.PHYSICS,
        )
        results = await adapter.query(claim, max_items=3)

        # We should get at least one result.
        assert len(results) >= 1

        # Each result should be valid.
        for evidence in results:
            assert evidence.claim_id == claim.claim_id
            assert evidence.source_did == "did:web:inspirehep.net"
            assert evidence.source_version == "inspire-api-v1"
            assert evidence.stance == Stance.NEUTRAL
            assert evidence.url
            assert len(evidence.raw_hash) == 64
            assert evidence.retrieved_at.tzinfo is not None
            assert 0 < len(evidence.excerpt) <= 1200

    finally:
        await adapter.close()
