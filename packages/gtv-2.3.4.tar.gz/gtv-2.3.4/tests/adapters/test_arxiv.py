"""Tests for ArxivAdapter — mocked and live."""
from __future__ import annotations

import hashlib
import os

import httpx
import pytest
import respx

from gtv.adapters.arxiv import ArxivAdapter
from gtv.models import Claim, Domain, SourceType, Stance, TrustTier

# ============================================================================
# Fixtures
# ============================================================================


@pytest.fixture
def canned_arxiv_response() -> str:
    """A minimal Atom XML response from arXiv API with 2 entries."""
    return """<?xml version="1.0" encoding="UTF-8"?>
<feed xmlns="http://www.w3.org/2005/Atom">
  <title>ArXiv Query Results</title>
  <link href="http://arxiv.org/api/query?search_query=all%3Agravitational%20waves&amp;max_results=2" rel="alternate" type="text/html"/>
  <link href="http://arxiv.org/api/query?search_query=all%3Agravitational%20waves&amp;max_results=2" rel="self" type="application/atom+xml"/>
  <id>http://arxiv.org/api/query?search_query=all%3Agravitational%20waves&amp;max_results=2</id>
  <updated>2024-01-15T10:00:00Z</updated>

  <entry>
    <id>http://arxiv.org/abs/2401.01234v1</id>
    <updated>2024-01-15T09:30:00Z</updated>
    <published>2024-01-15T09:30:00Z</published>
    <title>Gravitational Waves from Merging Neutron Stars</title>
    <summary>We present observations of gravitational waves from the merger of two neutron stars. The detection was made using advanced LIGO and Virgo detectors. The signal shows clear evidence of mass transfer and ejecta formation. This event provides unique constraints on the neutron star equation of state and the production of heavy elements via rapid neutron capture.</summary>
    <author><name>Smith, John</name></author>
    <link href="http://arxiv.org/abs/2401.01234v1" rel="alternate" type="text/html"/>
  </entry>

  <entry>
    <id>http://arxiv.org/abs/2401.05678v2</id>
    <updated>2024-01-14T14:20:00Z</updated>
    <published>2024-01-14T14:20:00Z</published>
    <title>Black Hole Formation in Gravitational Collapse</title>
    <summary>We study the formation of black holes through gravitational collapse in various spacetime metrics. Our numerical simulations use state-of-the-art adaptive mesh refinement techniques. The results show how the event horizon forms and expands during collapse. We also analyze the role of angular momentum in determining the final black hole properties.</summary>
    <author><name>Johnson, Alice</name></author>
    <link href="http://arxiv.org/abs/2401.05678v2" rel="alternate" type="text/html"/>
  </entry>
</feed>
"""


@pytest.fixture
async def adapter() -> ArxivAdapter:
    """Create an ArxivAdapter instance for testing."""
    adapter = ArxivAdapter()
    yield adapter
    await adapter.close()


# ============================================================================
# Unit Tests (Mocked)
# ============================================================================


@pytest.mark.asyncio
async def test_query_returns_evidence(
    adapter: ArxivAdapter, canned_arxiv_response: str
) -> None:
    """Query should return list of Evidence records with valid fields."""
    claim = Claim(text="gravitational waves neutron stars", domain=Domain.PHYSICS)

    with respx.mock:
        respx.get(
            "https://export.arxiv.org/api/query",
            params={
                "search_query": "all:gravitational waves neutron stars",
                "max_results": 5,
            },
        ).mock(return_value=httpx.Response(200, text=canned_arxiv_response))

        results = await adapter.query(claim, max_items=5)

    assert len(results) == 2
    for evidence in results:
        # Check all required fields.
        assert evidence.claim_id == claim.claim_id
        assert evidence.source_did == "did:web:arxiv.org"
        assert evidence.source_version == "arxiv-api-v1"
        assert evidence.stance == Stance.NEUTRAL
        assert str(evidence.url).startswith("http://arxiv.org/abs/")
        assert len(evidence.raw_hash) == 64
        assert all(c in "0123456789abcdef" for c in evidence.raw_hash)
        assert evidence.retrieved_at.tzinfo is not None


@pytest.mark.asyncio
async def test_query_excerpt_from_summary(
    adapter: ArxivAdapter, canned_arxiv_response: str
) -> None:
    """Excerpt should be the summary text, trimmed to 1200 chars."""
    claim = Claim(text="gravitational waves", domain=Domain.PHYSICS)

    with respx.mock:
        respx.get(
            "https://export.arxiv.org/api/query",
            params={
                "search_query": "all:gravitational waves",
                "max_results": 5,
            },
        ).mock(return_value=httpx.Response(200, text=canned_arxiv_response))

        results = await adapter.query(claim, max_items=5)

    # First entry has a known summary.
    first_summary = (
        "We present observations of gravitational waves from the merger of two "
        "neutron stars. The detection was made using advanced LIGO and Virgo detectors. "
        "The signal shows clear evidence of mass transfer and ejecta formation. This event "
        "provides unique constraints on the neutron star equation of state and the production "
        "of heavy elements via rapid neutron capture."
    )
    assert results[0].excerpt == first_summary


@pytest.mark.asyncio
async def test_query_raw_hash_matches_summary(
    adapter: ArxivAdapter, canned_arxiv_response: str
) -> None:
    """raw_hash should match sha256 of the summary bytes."""
    claim = Claim(text="gravitational waves", domain=Domain.PHYSICS)

    with respx.mock:
        respx.get(
            "https://export.arxiv.org/api/query",
            params={
                "search_query": "all:gravitational waves",
                "max_results": 5,
            },
        ).mock(return_value=httpx.Response(200, text=canned_arxiv_response))

        results = await adapter.query(claim, max_items=5)

    # Check that the hash matches.
    first_summary = (
        "We present observations of gravitational waves from the merger of two "
        "neutron stars. The detection was made using advanced LIGO and Virgo detectors. "
        "The signal shows clear evidence of mass transfer and ejecta formation. This event "
        "provides unique constraints on the neutron star equation of state and the production "
        "of heavy elements via rapid neutron capture."
    )
    expected_hash = hashlib.sha256(first_summary.encode("utf-8")).hexdigest()
    assert results[0].raw_hash == expected_hash


@pytest.mark.asyncio
async def test_query_timeout_propagates(adapter: ArxivAdapter) -> None:
    """Timeout exceptions should be raised, not swallowed."""
    claim = Claim(text="test", domain=Domain.PHYSICS)

    with respx.mock:
        respx.get(
            "https://export.arxiv.org/api/query",
            params={
                "search_query": "all:test",
                "max_results": 5,
            },
        ).mock(side_effect=httpx.TimeoutException("Timeout"))

        with pytest.raises(httpx.TimeoutException):
            await adapter.query(claim, max_items=5)


@pytest.mark.asyncio
async def test_query_empty_claim_text() -> None:
    """Empty claim should return empty list (no query to send)."""
    adapter = ArxivAdapter()
    try:
        # Create a claim with empty text is not possible due to validation.
        # Instead, test that claim_to_query returns empty.
        claim = Claim(text="the a is", domain=Domain.PHYSICS)
        results = await adapter.query(claim)
        assert results == []
    finally:
        await adapter.close()


@pytest.mark.asyncio
async def test_health_check_healthy(adapter: ArxivAdapter) -> None:
    """Health check should return HEALTHY on 200."""
    with respx.mock:
        respx.head(
            "https://export.arxiv.org/api/query",
            params={
                "search_query": "all:test",
                "max_results": "1",
            },
        ).mock(return_value=httpx.Response(200))

        health = await adapter.health()

    assert health.state == "HEALTHY"


@pytest.mark.asyncio
async def test_health_check_degraded_on_error(adapter: ArxivAdapter) -> None:
    """Health check should return DEGRADED on non-2xx status."""
    with respx.mock:
        respx.head(
            "https://export.arxiv.org/api/query",
            params={
                "search_query": "all:test",
                "max_results": "1",
            },
        ).mock(return_value=httpx.Response(503))

        health = await adapter.health()

    assert health.state == "DEGRADED"
    assert "503" in health.detail


@pytest.mark.asyncio
async def test_health_check_down_on_timeout(adapter: ArxivAdapter) -> None:
    """Health check should return DOWN on timeout."""
    with respx.mock:
        respx.head(
            "https://export.arxiv.org/api/query",
            params={
                "search_query": "all:test",
                "max_results": "1",
            },
        ).mock(side_effect=httpx.TimeoutException("Timeout"))

        health = await adapter.health()

    assert health.state == "DOWN"
    assert "timeout" in health.detail.lower()


@pytest.mark.asyncio
async def test_adapter_metadata() -> None:
    """Adapter should expose correct metadata."""
    adapter = ArxivAdapter()
    try:
        assert adapter.source_did == "did:web:arxiv.org"
        assert adapter.name == "arXiv"
        assert adapter.source_type == SourceType.PREPRINT
        assert adapter.trust_tier == TrustTier.TIER_2
        assert adapter.freshness_sla_s == 5
    finally:
        await adapter.close()


@pytest.mark.asyncio
async def test_close_releases_client() -> None:
    """Calling close() should release the owned client."""
    adapter = ArxivAdapter()
    assert adapter._owns_client is True
    await adapter.close()
    # After close, client should be closed (httpx tracks this).
    assert adapter._client.is_closed is True


@pytest.mark.asyncio
async def test_external_client_not_closed() -> None:
    """If an external client is provided, close() should not close it."""
    external_client = httpx.AsyncClient()
    adapter = ArxivAdapter(client=external_client)
    assert adapter._owns_client is False
    await adapter.close()
    # External client should not be closed by adapter.
    assert not external_client.is_closed


# ============================================================================
# Integration Test (Live)
# ============================================================================


@pytest.mark.asyncio
async def test_arxiv_live_query() -> None:
    """Live integration test: query real arXiv API.

    Only runs if GTV_LIVE=1 is set.
    """
    if not os.getenv("GTV_LIVE"):
        pytest.skip("GTV_LIVE not set; skipping live test")

    adapter = ArxivAdapter()
    try:
        # Query with a simple physics claim.
        claim = Claim(
            text="black hole thermodynamics entropy",
            domain=Domain.PHYSICS,
        )
        results = await adapter.query(claim, max_items=3)

        # We should get at least one result.
        assert len(results) >= 1

        # Each result should be valid.
        for evidence in results:
            assert evidence.claim_id == claim.claim_id
            assert evidence.source_did == "did:web:arxiv.org"
            assert evidence.source_version == "arxiv-api-v1"
            assert evidence.stance == Stance.NEUTRAL
            assert evidence.url
            assert len(evidence.raw_hash) == 64
            assert evidence.retrieved_at.tzinfo is not None
            assert 0 < len(evidence.excerpt) <= 1200

    finally:
        await adapter.close()
