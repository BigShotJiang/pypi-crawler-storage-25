"""Tests for OpenAlexAdapter — mocked and live."""
from __future__ import annotations

import hashlib
import os

import httpx
import pytest
import respx

from gtv.adapters.openalex import OpenAlexAdapter, _reconstruct_abstract
from gtv.models import Claim, Domain, SourceType, Stance, TrustTier

# ============================================================================
# Fixtures
# ============================================================================


@pytest.fixture
def canned_openalex_response() -> str:
    """A minimal JSON response from OpenAlex API with 2 works."""
    return """{
  "results": [
    {
      "id": "https://openalex.org/W2785477675",
      "title": "Gravitational Waves from Merging Neutron Stars",
      "abstract_inverted_index": {
        "We": [0],
        "present": [1],
        "observations": [2],
        "of": [3],
        "gravitational": [4],
        "waves": [5],
        "from": [6],
        "the": [7],
        "merger": [8],
        "of": [9],
        "two": [10],
        "neutron": [11],
        "stars": [12],
        "providing": [13],
        "unique": [14],
        "constraints": [15],
        "on": [16],
        "the": [17],
        "equation": [18],
        "of": [19],
        "state": [20]
      },
      "publication_year": 2024
    },
    {
      "id": "https://openalex.org/W2785477676",
      "title": "Black Hole Formation in Gravitational Collapse",
      "abstract_inverted_index": {
        "We": [0],
        "study": [1],
        "the": [2],
        "formation": [3],
        "of": [4],
        "black": [5],
        "holes": [6],
        "through": [7],
        "gravitational": [8],
        "collapse": [9]
      },
      "publication_year": 2023
    }
  ]
}
"""


@pytest.fixture
async def adapter() -> OpenAlexAdapter:
    """Create an OpenAlexAdapter instance for testing."""
    adapter = OpenAlexAdapter()
    yield adapter
    await adapter.close()


# ============================================================================
# Unit Tests (Mocked)
# ============================================================================


def test_reconstruct_abstract_from_inverted_index() -> None:
    """_reconstruct_abstract should rebuild prose from inverted index."""
    inverted = {
        "We": [0],
        "study": [1],
        "black": [2],
        "holes": [3],
    }
    result = _reconstruct_abstract(inverted)
    assert result == "We study black holes"


def test_reconstruct_abstract_empty_dict() -> None:
    """_reconstruct_abstract should return empty string for empty dict."""
    assert _reconstruct_abstract({}) == ""
    assert _reconstruct_abstract(None) == ""


def test_reconstruct_abstract_none_positions() -> None:
    """_reconstruct_abstract should handle None or invalid positions."""
    inverted = {"word": None, "another": [0]}
    result = _reconstruct_abstract(inverted)
    assert result == "another"


@pytest.mark.asyncio
async def test_query_returns_evidence(
    adapter: OpenAlexAdapter, canned_openalex_response: str
) -> None:
    """Query should return list of Evidence records with valid fields."""
    claim = Claim(text="gravitational waves neutron stars", domain=Domain.PHYSICS)

    with respx.mock:
        respx.get(
            "https://api.openalex.org/works",
            params={
                "search": "gravitational waves neutron stars",
                "per_page": 5,
                "mailto": adapter._email,
            },
        ).mock(return_value=httpx.Response(200, text=canned_openalex_response))

        results = await adapter.query(claim, max_items=5)

    assert len(results) == 2
    for evidence in results:
        # Check all required fields.
        assert evidence.claim_id == claim.claim_id
        assert evidence.source_did == "did:web:api.openalex.org"
        assert evidence.source_version == "openalex-api-v1"
        assert evidence.stance == Stance.NEUTRAL
        assert str(evidence.url).startswith("https://openalex.org/W")
        assert len(evidence.raw_hash) == 64
        assert all(c in "0123456789abcdef" for c in evidence.raw_hash)
        assert evidence.retrieved_at.tzinfo is not None


@pytest.mark.asyncio
async def test_query_uses_abstract_inverted_index(
    adapter: OpenAlexAdapter, canned_openalex_response: str
) -> None:
    """Excerpt should be reconstructed from abstract_inverted_index."""
    claim = Claim(text="gravitational waves", domain=Domain.PHYSICS)

    with respx.mock:
        respx.get(
            "https://api.openalex.org/works",
            params={
                "search": "gravitational waves",
                "per_page": 5,
                "mailto": adapter._email,
            },
        ).mock(return_value=httpx.Response(200, text=canned_openalex_response))

        results = await adapter.query(claim, max_items=5)

    # First entry should have reconstructed abstract.
    # Note: inverted index has multiple positions for words like "of" and "the".
    # Our reconstruction takes the last position for each word.
    assert "gravitational waves" in results[0].excerpt
    assert "neutron stars" in results[0].excerpt
    assert len(results[0].excerpt) > 50


@pytest.mark.asyncio
async def test_query_fallback_to_title_when_no_abstract(
    adapter: OpenAlexAdapter,
) -> None:
    """If abstract_inverted_index is absent, excerpt should use title."""
    response = """{
  "results": [
    {
      "id": "https://openalex.org/W123",
      "title": "A Study of Quantum Mechanics",
      "publication_year": 2024
    }
  ]
}
"""
    claim = Claim(text="quantum mechanics", domain=Domain.PHYSICS)

    with respx.mock:
        respx.get(
            "https://api.openalex.org/works",
            params={
                "search": "quantum mechanics",
                "per_page": 5,
                "mailto": adapter._email,
            },
        ).mock(return_value=httpx.Response(200, text=response))

        results = await adapter.query(claim, max_items=5)

    assert len(results) == 1
    assert results[0].excerpt == "A Study of Quantum Mechanics"


@pytest.mark.asyncio
async def test_query_raw_hash_matches_excerpt(
    adapter: OpenAlexAdapter, canned_openalex_response: str
) -> None:
    """raw_hash should match sha256 of the excerpt bytes."""
    claim = Claim(text="gravitational waves", domain=Domain.PHYSICS)

    with respx.mock:
        respx.get(
            "https://api.openalex.org/works",
            params={
                "search": "gravitational waves",
                "per_page": 5,
                "mailto": adapter._email,
            },
        ).mock(return_value=httpx.Response(200, text=canned_openalex_response))

        results = await adapter.query(claim, max_items=5)

    # Compute expected hash.
    first_excerpt = results[0].excerpt
    expected_hash = hashlib.sha256(first_excerpt.encode("utf-8")).hexdigest()
    assert results[0].raw_hash == expected_hash


@pytest.mark.asyncio
async def test_query_timeout_propagates(adapter: OpenAlexAdapter) -> None:
    """Timeout exceptions should be raised, not swallowed."""
    claim = Claim(text="test", domain=Domain.PHYSICS)

    with respx.mock:
        respx.get(
            "https://api.openalex.org/works",
            params={
                "search": "test",
                "per_page": 5,
                "mailto": adapter._email,
            },
        ).mock(side_effect=httpx.TimeoutException("Timeout"))

        with pytest.raises(httpx.TimeoutException):
            await adapter.query(claim, max_items=5)


@pytest.mark.asyncio
async def test_query_empty_results() -> None:
    """Query with no matching results should return empty list."""
    response = '{"results": []}'
    adapter = OpenAlexAdapter()
    try:
        claim = Claim(text="xyzabc123nonexistent", domain=Domain.PHYSICS)

        with respx.mock:
            respx.get(
                "https://api.openalex.org/works",
                params={
                    "search": "xyzabc123nonexistent",
                    "per_page": 5,
                    "mailto": adapter._email,
                },
            ).mock(return_value=httpx.Response(200, text=response))

            results = await adapter.query(claim, max_items=5)

        assert results == []
    finally:
        await adapter.close()


@pytest.mark.asyncio
async def test_health_check_healthy(adapter: OpenAlexAdapter) -> None:
    """Health check should return HEALTHY on 200."""
    with respx.mock:
        respx.get(
            "https://api.openalex.org/works",
            params={
                "search": "test",
                "per_page": "1",
                "mailto": adapter._email,
            },
        ).mock(return_value=httpx.Response(200))

        health = await adapter.health()

    assert health.state == "HEALTHY"


@pytest.mark.asyncio
async def test_health_check_degraded_on_error(adapter: OpenAlexAdapter) -> None:
    """Health check should return DEGRADED on non-2xx status."""
    with respx.mock:
        respx.get(
            "https://api.openalex.org/works",
            params={
                "search": "test",
                "per_page": "1",
                "mailto": adapter._email,
            },
        ).mock(return_value=httpx.Response(503))

        health = await adapter.health()

    assert health.state == "DEGRADED"
    assert "503" in health.detail


@pytest.mark.asyncio
async def test_health_check_down_on_timeout(adapter: OpenAlexAdapter) -> None:
    """Health check should return DOWN on timeout."""
    with respx.mock:
        respx.get(
            "https://api.openalex.org/works",
            params={
                "search": "test",
                "per_page": "1",
                "mailto": adapter._email,
            },
        ).mock(side_effect=httpx.TimeoutException("Timeout"))

        health = await adapter.health()

    assert health.state == "DOWN"
    assert "timeout" in health.detail.lower()


@pytest.mark.asyncio
async def test_adapter_metadata() -> None:
    """Adapter should expose correct metadata."""
    adapter = OpenAlexAdapter()
    try:
        assert adapter.source_did == "did:web:api.openalex.org"
        assert adapter.name == "OpenAlex"
        assert adapter.source_type == SourceType.REFERENCE_DATA
        assert adapter.trust_tier == TrustTier.TIER_2
        assert adapter.freshness_sla_s == 5
    finally:
        await adapter.close()


@pytest.mark.asyncio
async def test_close_releases_client() -> None:
    """Calling close() should release the owned client."""
    adapter = OpenAlexAdapter()
    assert adapter._owns_client is True
    await adapter.close()
    # After close, client should be closed (httpx tracks this).
    assert adapter._client.is_closed is True


@pytest.mark.asyncio
async def test_external_client_not_closed() -> None:
    """If an external client is provided, close() should not close it."""
    external_client = httpx.AsyncClient()
    adapter = OpenAlexAdapter(client=external_client)
    assert adapter._owns_client is False
    await adapter.close()
    # External client should not be closed by adapter.
    assert not external_client.is_closed


# ============================================================================
# Integration Test (Live)
# ============================================================================


@pytest.mark.asyncio
async def test_openalex_live_query() -> None:
    """Live integration test: query real OpenAlex API.

    Only runs if GTV_LIVE=1 is set.
    """
    if not os.getenv("GTV_LIVE"):
        pytest.skip("GTV_LIVE not set; skipping live test")

    adapter = OpenAlexAdapter()
    try:
        # Query with a simple physics claim.
        claim = Claim(
            text="black hole thermodynamics entropy",
            domain=Domain.PHYSICS,
        )
        results = await adapter.query(claim, max_items=3)

        # We should get at least one result.
        assert len(results) >= 1

        # Each result should be valid.
        for evidence in results:
            assert evidence.claim_id == claim.claim_id
            assert evidence.source_did == "did:web:api.openalex.org"
            assert evidence.source_version == "openalex-api-v1"
            assert evidence.stance == Stance.NEUTRAL
            assert evidence.url
            assert len(evidence.raw_hash) == 64
            assert evidence.retrieved_at.tzinfo is not None
            assert 0 < len(evidence.excerpt) <= 1200

    finally:
        await adapter.close()
