"""Tests for priority-based rate limiting (PriorityRateLimiter and RateLimitedAdapter)."""
from __future__ import annotations

import asyncio

import pytest

from gtv.adapters.base import RawSnapshot, SourceAdapter
from gtv.adapters.ratelimit import PriorityRateLimiter, RateLimitedAdapter
from gtv.models import Claim, Domain, Evidence, HealthStatus, Stance, TrustTier


class FakeAdapter(SourceAdapter):
    """A fake adapter that counts calls and returns deterministic evidence."""

    def __init__(self, name: str = "fake") -> None:
        self.source_did = "did:web:fake.example"
        self.name = name
        self.trust_tier = TrustTier.TIER_1
        self.freshness_sla_s = 300
        self.source_type = "web"
        self.query_call_count = 0
        self.snapshot_call_count = 0
        self.health_call_count = 0
        self.close_call_count = 0

    async def query(self, claim: Claim, max_items: int = 5) -> list[Evidence]:
        """Count calls and return fake evidence."""
        self.query_call_count += 1
        return [
            Evidence(
                evidence_id=f"ev-{self.query_call_count}-1",
                claim_id=claim.claim_id,
                source_did=self.source_did,
                source_version="1.0",
                stance=Stance.SUPPORTS,
                excerpt=f"Fake evidence for: {claim.text}",
                url="https://fake.example/doc",
                retrieved_at=claim.submitted_at,
                raw_hash="a" * 64,
            ),
        ]

    async def snapshot(self, url: str) -> RawSnapshot:
        """Count calls and return fake snapshot."""
        self.snapshot_call_count += 1
        return RawSnapshot(
            url=url,
            content=b"fake content",
            retrieved_at_iso="2026-04-22T00:00:00Z",
        )

    async def health(self) -> HealthStatus:
        """Count calls and return healthy status."""
        self.health_call_count += 1
        return HealthStatus(state="HEALTHY", detail="fake is alive")

    async def close(self) -> None:
        """Count calls."""
        self.close_call_count += 1


# ============================================================================
# PriorityRateLimiter Tests
# ============================================================================


@pytest.mark.asyncio
async def test_single_call_passes_immediately_with_tokens() -> None:
    """Single call passes immediately when bucket has tokens."""
    limiter = PriorityRateLimiter(rate_per_sec=10.0, burst=5)
    # Bucket starts full, should acquire immediately
    await limiter.acquire(priority=5)
    # If we got here without blocking, test passes


@pytest.mark.asyncio
async def test_exhausted_bucket_blocks_next_call() -> None:
    """Exhausted bucket blocks next call."""
    limiter = PriorityRateLimiter(rate_per_sec=10.0, burst=1)
    await limiter.acquire(priority=5)  # Take the only token

    # Next acquire should block until we have tokens
    task = asyncio.create_task(limiter.acquire(priority=5))
    # Give it a moment to start waiting
    await asyncio.sleep(0.01)
    assert not task.done()  # Should still be blocked

    # Give back a token (or wait for refill)
    limiter.release_unused()
    # Now the task should complete
    await asyncio.wait_for(task, timeout=1.0)


@pytest.mark.asyncio
async def test_refill_after_rate_per_sec_unblocks_waiter() -> None:
    """Refill after rate_per_sec seconds unblocks one waiter."""
    limiter = PriorityRateLimiter(rate_per_sec=1.0, burst=1)
    await limiter.acquire(priority=5)  # Take the only token

    # Schedule a second acquire
    task = asyncio.create_task(limiter.acquire(priority=5))
    await asyncio.sleep(0.01)
    assert not task.done()

    # Wait for ~1.1 seconds (enough for refill)
    await asyncio.sleep(1.1)
    # Now it should complete (1 second elapsed = 1 new token)
    await asyncio.wait_for(task, timeout=1.0)


@pytest.mark.asyncio
async def test_higher_priority_served_first() -> None:
    """Higher-priority (lower int) waiter is served first out of queue."""
    limiter = PriorityRateLimiter(rate_per_sec=10.0, burst=1)
    await limiter.acquire(priority=5)  # Take the only token

    order = []

    async def low_priority_task() -> None:
        await limiter.acquire(priority=10)
        order.append("low")

    async def high_priority_task() -> None:
        await limiter.acquire(priority=1)
        order.append("high")

    # Start low priority first, then high priority (they'll both wait)
    low_task = asyncio.create_task(low_priority_task())
    await asyncio.sleep(0.01)
    high_task = asyncio.create_task(high_priority_task())
    await asyncio.sleep(0.01)

    # Both should be waiting
    assert not low_task.done()
    assert not high_task.done()

    # Release a token; high priority should go first
    limiter.release_unused()
    await asyncio.sleep(0.05)

    assert order == ["high"]
    assert not low_task.done()

    # Release another; low priority should go next
    limiter.release_unused()
    await asyncio.sleep(0.05)

    assert order == ["high", "low"]


@pytest.mark.asyncio
async def test_fifo_within_same_priority() -> None:
    """FIFO within the same priority level."""
    limiter = PriorityRateLimiter(rate_per_sec=10.0, burst=1)
    await limiter.acquire(priority=5)  # Take the only token

    order = []

    async def acquire_and_log(name: str) -> None:
        await limiter.acquire(priority=5)
        order.append(name)

    # Start two tasks with same priority; first one should be served first
    task1 = asyncio.create_task(acquire_and_log("first"))
    await asyncio.sleep(0.01)
    task2 = asyncio.create_task(acquire_and_log("second"))
    await asyncio.sleep(0.01)

    # Both waiting
    assert not task1.done()
    assert not task2.done()

    # Release; first should go
    limiter.release_unused()
    await asyncio.sleep(0.05)
    assert order == ["first"]

    # Release again; second should go
    limiter.release_unused()
    await asyncio.sleep(0.05)
    assert order == ["first", "second"]


@pytest.mark.asyncio
async def test_release_unused_returns_token() -> None:
    """release_unused returns a token to the bucket."""
    limiter = PriorityRateLimiter(rate_per_sec=10.0, burst=2)
    await limiter.acquire(priority=5)
    await limiter.acquire(priority=5)  # Now bucket is empty

    # Should block
    task = asyncio.create_task(limiter.acquire(priority=5))
    await asyncio.sleep(0.01)
    assert not task.done()

    # Release one
    limiter.release_unused()
    await asyncio.sleep(0.05)
    assert task.done()


@pytest.mark.asyncio
async def test_burst_allows_concurrent_acquires() -> None:
    """burst > 1 allows N concurrent acquires without blocking."""
    limiter = PriorityRateLimiter(rate_per_sec=1.0, burst=5)

    # Should be able to acquire 5 times immediately
    for _ in range(5):
        await limiter.acquire(priority=5)

    # 6th should block
    task = asyncio.create_task(limiter.acquire(priority=5))
    await asyncio.sleep(0.01)
    assert not task.done()

    # Give it back a token
    limiter.release_unused()
    await asyncio.sleep(0.05)
    assert task.done()


@pytest.mark.asyncio
async def test_rate_limiter_init_validates_params() -> None:
    """__init__ validates rate_per_sec > 0 and burst >= 1."""
    with pytest.raises(ValueError, match="rate_per_sec"):
        PriorityRateLimiter(rate_per_sec=0, burst=1)

    with pytest.raises(ValueError, match="burst"):
        PriorityRateLimiter(rate_per_sec=1.0, burst=0)


# ============================================================================
# RateLimitedAdapter Tests
# ============================================================================


@pytest.mark.asyncio
async def test_rate_limited_adapter_delegates_source_did() -> None:
    """RateLimitedAdapter delegates source_did to inner."""
    inner = FakeAdapter(name="test_adapter")
    limiter = PriorityRateLimiter(rate_per_sec=10.0, burst=5)
    adapter = RateLimitedAdapter(inner, limiter)

    assert adapter.source_did == inner.source_did


@pytest.mark.asyncio
async def test_rate_limited_adapter_delegates_health() -> None:
    """RateLimitedAdapter.health delegates to inner."""
    inner = FakeAdapter()
    limiter = PriorityRateLimiter(rate_per_sec=10.0, burst=5)
    adapter = RateLimitedAdapter(inner, limiter)

    health = await adapter.health()
    assert health.state == "HEALTHY"
    assert inner.health_call_count == 1


@pytest.mark.asyncio
async def test_rate_limited_adapter_delegates_snapshot() -> None:
    """RateLimitedAdapter.snapshot delegates to inner."""
    inner = FakeAdapter()
    limiter = PriorityRateLimiter(rate_per_sec=10.0, burst=5)
    adapter = RateLimitedAdapter(inner, limiter)

    snapshot = await adapter.snapshot("https://example.com")
    assert snapshot.url == "https://example.com"
    assert inner.snapshot_call_count == 1


@pytest.mark.asyncio
async def test_rate_limited_adapter_delegates_close() -> None:
    """RateLimitedAdapter.close delegates to inner."""
    inner = FakeAdapter()
    limiter = PriorityRateLimiter(rate_per_sec=10.0, burst=5)
    adapter = RateLimitedAdapter(inner, limiter)

    await adapter.close()
    assert inner.close_call_count == 1


@pytest.mark.asyncio
async def test_rate_limited_adapter_query_acquires_and_releases() -> None:
    """RateLimitedAdapter.query acquires token, calls inner, completes."""
    inner = FakeAdapter()
    limiter = PriorityRateLimiter(rate_per_sec=10.0, burst=1)
    adapter = RateLimitedAdapter(inner, limiter)

    claim = Claim(text="test claim", domain=Domain.PHYSICS)

    # First query should work
    result = await adapter.query(claim, max_items=5)
    assert len(result) == 1
    assert inner.query_call_count == 1

    # Second query should block initially (token exhausted)
    task = asyncio.create_task(adapter.query(claim, max_items=5))
    await asyncio.sleep(0.01)
    assert not task.done()

    # Release lets next query proceed (via release_unused or refill)
    limiter.release_unused()
    result2 = await asyncio.wait_for(task, timeout=1.0)
    assert len(result2) == 1
    assert inner.query_call_count == 2


@pytest.mark.asyncio
async def test_rate_limited_adapter_priority_fn_is_honored() -> None:
    """priority_fn is called and honored when provided."""
    inner = FakeAdapter()
    limiter = PriorityRateLimiter(rate_per_sec=10.0, burst=1)

    def priority_from_domain(claim: Claim) -> int:
        # Physics = high priority (1), others = low (10)
        return 1 if claim.domain == Domain.PHYSICS else 10

    adapter = RateLimitedAdapter(inner, limiter, priority_fn=priority_from_domain)

    # Exhaust the bucket
    await adapter.query(
        Claim(text="first", domain=Domain.GENERAL), max_items=5
    )

    order = []

    async def query_and_log(domain: Domain, name: str) -> None:
        await adapter.query(Claim(text=name, domain=domain), max_items=5)
        order.append(name)

    # Queue up: low priority (general) then high priority (physics)
    task1 = asyncio.create_task(query_and_log(Domain.GENERAL, "general"))
    await asyncio.sleep(0.01)
    task2 = asyncio.create_task(query_and_log(Domain.PHYSICS, "physics"))
    await asyncio.sleep(0.01)

    # Both waiting
    assert not task1.done()
    assert not task2.done()

    # Release a token; physics (priority 1) should go first
    limiter.release_unused()
    await asyncio.sleep(0.05)

    assert "physics" in order
    assert len(order) == 1  # physics went, general still blocked

    # Release another; general should go
    limiter.release_unused()
    await asyncio.sleep(0.05)

    assert "general" in order
    assert len(order) == 2


@pytest.mark.asyncio
async def test_rate_limited_adapter_default_priority_fn() -> None:
    """Default priority_fn returns 5 for any claim."""
    inner = FakeAdapter()
    limiter = PriorityRateLimiter(rate_per_sec=10.0, burst=5)
    adapter = RateLimitedAdapter(inner, limiter)  # No priority_fn provided

    # Should work fine with default priority
    claim = Claim(text="test", domain=Domain.PHYSICS)
    result = await adapter.query(claim, max_items=5)
    assert len(result) == 1
    assert inner.query_call_count == 1
