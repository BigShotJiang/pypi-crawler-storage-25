"""Tests for telemetry metrics."""
from __future__ import annotations

import pytest


def test_metrics_increment():
    """Test that counters increment correctly."""
    from gtv.telemetry.metrics import gtv_requests_total

    # Reset and increment
    initial = gtv_requests_total.labels(endpoint="/test", status="200")._value.get()
    gtv_requests_total.labels(endpoint="/test", status="200").inc()
    assert gtv_requests_total.labels(endpoint="/test", status="200")._value.get() > initial


def test_verdicts_counter():
    """Test verdict counter with labels."""
    from gtv.telemetry.metrics import record_verdict

    # Record some verdicts
    record_verdict("SUPPORTED", "TIER_1")
    record_verdict("UNSUPPORTED", "TIER_2")

    # Verify they were recorded (just check that no exception is raised)
    assert True


def test_histogram_observes():
    """Test that histogram observes values."""
    from gtv.telemetry.metrics import gtv_request_duration_seconds

    # Observe some values
    gtv_request_duration_seconds.labels(endpoint="/verify").observe(0.05)
    gtv_request_duration_seconds.labels(endpoint="/verify").observe(0.15)

    # Verify bucket counts increased
    metric = gtv_request_duration_seconds.labels(endpoint="/verify")
    assert metric._sum.get() > 0


def test_label_cardinality_bounded():
    """Test that we avoid unbounded label cardinality."""
    from gtv.telemetry.metrics import gtv_requests_total

    # Use only finite, predefined endpoints and statuses
    endpoints = ["/verify", "/retrieve", "/health"]
    statuses = ["200", "400", "429", "500"]

    for ep in endpoints:
        for st in statuses:
            gtv_requests_total.labels(endpoint=ep, status=st).inc()

    # Should work without issue; no unbounded input from user


def test_metrics_survive_double_import():
    """Test that metrics can be imported twice without ValueError."""
    # This will happen in test suite anyway, but let's be explicit
    try:
        # First import (should succeed)
        from gtv.telemetry.metrics import gtv_requests_total as req1  # noqa: F401

        # Simulated second import (module is cached, but code tries to register again)
        from gtv.telemetry.metrics import gtv_requests_total as req2  # noqa: F401

        assert True
    except ValueError as e:
        pytest.fail(f"Metrics failed on double import: {e}")


def test_error_counter():
    """Test error counter increments on different error types."""
    from gtv.telemetry.metrics import gtv_errors_total

    gtv_errors_total.labels(endpoint="/verify", error_type="timeout").inc()
    gtv_errors_total.labels(endpoint="/verify", error_type="invalid_input").inc()

    assert True  # If we got here, no exception
