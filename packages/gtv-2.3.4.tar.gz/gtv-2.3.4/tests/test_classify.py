"""Claim classifier tests — 30+ labelled examples across all four classes."""
from __future__ import annotations

import pytest

from gtv.models import Claim, Domain
from gtv.verdict.classify import ClaimClass, classify

# ============================================================================
# FACTUAL claims — physics/STEM (≥10 examples)
# ============================================================================

@pytest.mark.parametrize("text,expected", [
    ("The speed of light in vacuum is 299792458 m/s.", ClaimClass.FACTUAL),
    ("Water freezes at 0 degrees Celsius at standard atmospheric pressure.", ClaimClass.FACTUAL),
    ("Photosynthesis converts CO2 and water into glucose and oxygen.", ClaimClass.FACTUAL),
    ("The Earth orbits the Sun in approximately 365.25 days.", ClaimClass.FACTUAL),
    ("Quantum entanglement is a phenomenon where particles become correlated.", ClaimClass.FACTUAL),
    ("Dark matter comprises approximately 85% of matter in the universe.", ClaimClass.FACTUAL),
    ("The fine-structure constant is approximately 1/137.", ClaimClass.FACTUAL),
    ("Gravity propagates at the speed of light according to general relativity.", ClaimClass.FACTUAL),
    ("The Higgs boson was discovered at CERN in 2012.", ClaimClass.FACTUAL),
    ("DNA has a double helix structure.", ClaimClass.FACTUAL),
    ("The speed of light is the best-measured physical constant.", ClaimClass.FACTUAL),
    ("Planck's constant equals 6.62607015 * 10^-34 joule-seconds.", ClaimClass.FACTUAL),
])
def test_factual_claims(text: str, expected: ClaimClass) -> None:
    """Factual STEM/physics claims should all classify as FACTUAL."""
    claim = Claim(text=text, domain=Domain.PHYSICS)
    assert classify(claim) == expected


# ============================================================================
# OPINION claims (≥7 examples)
# ============================================================================

@pytest.mark.parametrize("text,expected", [
    ("I think quantum mechanics is beautiful.", ClaimClass.OPINION),
    ("I believe the universe is deterministic.", ClaimClass.OPINION),
    ("In my opinion, string theory is the best approach to unification.", ClaimClass.OPINION),
    ("Scientists should prioritize renewable energy research.", ClaimClass.OPINION),
    ("You ought to read Feynman's lectures on physics.", ClaimClass.OPINION),
    ("String theory is the best approach and the greatest unification scheme and the most important development.", ClaimClass.OPINION),
    ("My perspective is that machine learning will transform science.", ClaimClass.OPINION),
])
def test_opinion_claims(text: str, expected: ClaimClass) -> None:
    """Opinion claims with belief stems or normative modals should classify as OPINION."""
    claim = Claim(text=text)
    assert classify(claim) == expected


# ============================================================================
# CREATIVE claims (≥5 examples)
# ============================================================================

@pytest.mark.parametrize("text,expected", [
    ("Write a poem about the birth of a star.", ClaimClass.CREATIVE),
    ("Invent a story about a physicist who travels through time.", ClaimClass.CREATIVE),
    ("Imagine a scenario where gravity suddenly reversed.", ClaimClass.CREATIVE),
    ("In the style of Shakespeare, describe quantum entanglement.", ClaimClass.CREATIVE),
    ("Compose a song about the periodic table.", ClaimClass.CREATIVE),
    ("Create a fictional world governed by different laws of physics.", ClaimClass.CREATIVE),
])
def test_creative_claims(text: str, expected: ClaimClass) -> None:
    """Creative claims requesting fictional/artistic output should classify as CREATIVE."""
    claim = Claim(text=text)
    assert classify(claim) == expected


# ============================================================================
# OUT_OF_SCOPE claims (≥5 examples)
# ============================================================================

@pytest.mark.parametrize("text,expected", [
    ("Can you diagnose my skin condition?", ClaimClass.OUT_OF_SCOPE),
    ("Is this a cancer or just a mole?", ClaimClass.OUT_OF_SCOPE),
    ("What is the price of Bitcoin tomorrow?", ClaimClass.OUT_OF_SCOPE),
    ("Will Ethereum hit $10,000 this year?", ClaimClass.OUT_OF_SCOPE),
    ("Should I invest in Tesla stock?", ClaimClass.OUT_OF_SCOPE),
    ("Is this contract legal in the state of California?", ClaimClass.OUT_OF_SCOPE),
    ("Am I liable if someone slips on my property?", ClaimClass.OUT_OF_SCOPE),
    ("Should I take antibiotics for this infection?", ClaimClass.OUT_OF_SCOPE),
    ("What is the best crypto to buy right now?", ClaimClass.OUT_OF_SCOPE),
    ("Can you provide financial advice about retirement planning?", ClaimClass.OUT_OF_SCOPE),
])
def test_out_of_scope_claims(text: str, expected: ClaimClass) -> None:
    """Medical, legal, crypto-price, and financial advice should classify as OUT_OF_SCOPE."""
    claim = Claim(text=text)
    assert classify(claim) == expected


# ============================================================================
# Edge cases — tricky claims that must classify as FACTUAL (≥3)
# ============================================================================

@pytest.mark.parametrize("text,expected", [
    # "best" in a factual superlative context, not evaluative
    ("The speed of light is the best-measured physical constant.", ClaimClass.FACTUAL),
    # Superlative within a factual statement, below dominance threshold
    ("DNA is the most important molecule in biology, responsible for inheritance.", ClaimClass.FACTUAL),
    # "Should" in a factual/descriptive sense, not normative
    ("Plants should receive adequate sunlight for photosynthesis.", ClaimClass.FACTUAL),
])
def test_edge_cases_factual(text: str, expected: ClaimClass) -> None:
    """Edge cases that contain lexicon triggers but remain FACTUAL."""
    claim = Claim(text=text)
    assert classify(claim) == expected


# ============================================================================
# Case insensitivity tests
# ============================================================================

@pytest.mark.parametrize("text,expected", [
    ("WRITE A POEM ABOUT STARS.", ClaimClass.CREATIVE),
    ("I THINK THE BEST APPROACH IS X.", ClaimClass.OPINION),
    ("IS THIS CANCER?", ClaimClass.OUT_OF_SCOPE),
    ("the speed of light is 3e8 m/s.", ClaimClass.FACTUAL),
])
def test_case_insensitivity(text: str, expected: ClaimClass) -> None:
    """All matching should be case-insensitive."""
    claim = Claim(text=text)
    assert classify(claim) == expected


# ============================================================================
# Priority tests — when multiple categories match
# ============================================================================

def test_creative_beats_opinion() -> None:
    """CREATIVE should win if both CREATIVE and OPINION markers are present."""
    text = "I think you should write a poem that reflects my opinion."
    claim = Claim(text=text)
    # Contains "I think" (OPINION) and "write a poem" (CREATIVE)
    # CREATIVE should win
    assert classify(claim) == ClaimClass.CREATIVE


def test_out_of_scope_over_factual() -> None:
    """OUT_OF_SCOPE should win over FACTUAL."""
    text = "What is the price of Bitcoin?"
    claim = Claim(text=text)
    assert classify(claim) == ClaimClass.OUT_OF_SCOPE


def test_creative_beats_out_of_scope() -> None:
    """CREATIVE should beat OUT_OF_SCOPE (highest priority)."""
    text = "Write a fictional story about someone who diagnosed cancer."
    claim = Claim(text=text)
    # Contains both "write a" (CREATIVE) and "diagnosed cancer" (OUT_OF_SCOPE)
    # CREATIVE wins
    assert classify(claim) == ClaimClass.CREATIVE


# ============================================================================
# Boundary cases
# ============================================================================

def test_superlative_dominance_threshold() -> None:
    """Superlatives need >30% of content words to trigger OPINION."""
    # This has exactly 1 superlative in ~10 content words -> ~10% -> should stay FACTUAL
    text = "The most important fundamental constant in physics is the fine-structure constant value one over one hundred thirty seven."
    claim = Claim(text=text)
    # 1 superlative "most important" / ~11 content words = 9% < 30%
    # Should be FACTUAL despite containing superlative
    result = classify(claim)
    assert result == ClaimClass.FACTUAL


def test_multiple_superlatives_high_dominance() -> None:
    """Multiple superlatives should aggregate toward OPINION classification."""
    # Many superlatives in a short text -> >30% -> OPINION
    text = "The best approach is the most important and the greatest discovery."
    claim = Claim(text=text)
    # "the best", "most important", "greatest" = 3 superlatives / ~6 content words = 50%
    # Should be OPINION
    result = classify(claim)
    assert result == ClaimClass.OPINION
