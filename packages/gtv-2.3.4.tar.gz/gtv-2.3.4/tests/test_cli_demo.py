"""Tests for gtv-demo CLI."""
from __future__ import annotations

import json
import subprocess
from pathlib import Path

import pytest


@pytest.fixture
def venv_path() -> Path:
    """Return path to virtual env bin."""
    venv = Path("/tmp/gtvenv")
    if not venv.exists():
        pytest.skip("venv not available")
    return venv


@pytest.fixture
def demo_cmd(venv_path: Path) -> list[str]:
    """Build the gtv-demo command."""
    return [str(venv_path / "bin" / "python"), "-m", "gtv.cli.demo"]


class TestDemoOffline:
    """Test gtv-demo in offline mode (no network calls)."""

    def test_offline_basic_claim(self, demo_cmd: list[str]) -> None:
        """Run gtv-demo --offline with a basic claim."""
        result = subprocess.run(
            [*demo_cmd, "--offline", "The speed of light is 299792458 m/s"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        assert result.returncode == 0
        assert "Verdict:" in result.stdout
        assert "UNVERIFIED" in result.stdout or "299792458" in result.stdout

    def test_offline_exit_code_0_on_unverified(self, demo_cmd: list[str]) -> None:
        """Exit code is 0 even if verdict is UNVERIFIED."""
        result = subprocess.run(
            [*demo_cmd, "--offline", "Some random claim"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        assert result.returncode == 0

    def test_offline_no_network_calls(self, demo_cmd: list[str]) -> None:
        """Offline mode doesn't make network calls (fast)."""
        # Should complete in <1s even with network disabled
        result = subprocess.run(
            [*demo_cmd, "--offline", "The Higgs boson mass is 125 GeV"],
            capture_output=True,
            text=True,
            timeout=2,
        )
        assert result.returncode == 0

    def test_offline_multiple_subclaims(self, demo_cmd: list[str]) -> None:
        """Handle multiple sentences in one claim."""
        claim = "The speed of light is 3e8 m/s. Water is H2O. The Earth is round."
        result = subprocess.run(
            [*demo_cmd, "--offline", claim],
            capture_output=True,
            text=True,
            timeout=10,
        )
        assert result.returncode == 0
        # Should extract up to 5 subclaims
        assert "Subclaim 1:" in result.stdout or "Verdict:" in result.stdout


class TestDemoJSON:
    """Test gtv-demo with --json flag."""

    def test_json_output_format(self, demo_cmd: list[str]) -> None:
        """--json outputs valid JSON."""
        result = subprocess.run(
            [*demo_cmd, "--offline", "--json", "The Higgs boson mass is 125 GeV"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        assert result.returncode == 0

        # Should be parseable JSON
        output = json.loads(result.stdout)
        assert isinstance(output, list)
        assert len(output) > 0

    def test_json_verdict_structure(self, demo_cmd: list[str]) -> None:
        """JSON output has expected structure."""
        result = subprocess.run(
            [*demo_cmd, "--offline", "--json", "Test claim"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        assert result.returncode == 0

        output = json.loads(result.stdout)
        for item in output:
            assert "claim" in item
            assert "verdict" in item
            assert "confidence" in item
            assert "evidence" in item
            assert isinstance(item["evidence"], list)
            assert isinstance(item["confidence"], (int, float))

    def test_json_exit_code_0(self, demo_cmd: list[str]) -> None:
        """JSON mode still exits 0 on success."""
        result = subprocess.run(
            [*demo_cmd, "--offline", "--json", "Any claim"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        assert result.returncode == 0


class TestDemoArguments:
    """Test CLI argument handling."""

    def test_missing_claim_returns_usage(self, demo_cmd: list[str]) -> None:
        """Missing positional arg prints usage and exits 64."""
        result = subprocess.run(
            demo_cmd,
            capture_output=True,
            text=True,
            timeout=10,
        )
        assert result.returncode == 64
        assert "usage:" in result.stderr or "usage" in result.stderr.lower()

    def test_help_flag(self, demo_cmd: list[str]) -> None:
        """--help flag works."""
        result = subprocess.run(
            [*demo_cmd, "--help"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        assert result.returncode == 0
        assert "gtv-demo" in result.stdout or "usage" in result.stdout.lower()

    def test_offline_flag_without_claim(self, demo_cmd: list[str]) -> None:
        """--offline without claim prints usage."""
        result = subprocess.run(
            [*demo_cmd, "--offline"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        assert result.returncode == 64

    def test_json_flag_without_claim(self, demo_cmd: list[str]) -> None:
        """--json without claim prints usage."""
        result = subprocess.run(
            [*demo_cmd, "--json"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        assert result.returncode == 64


class TestDemoOutput:
    """Test output formatting."""

    def test_human_readable_output(self, demo_cmd: list[str]) -> None:
        """Default output is human-readable (not JSON)."""
        result = subprocess.run(
            [*demo_cmd, "--offline", "Test claim about gravity"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        assert result.returncode == 0
        # Should have human-readable markers
        assert "Verdict:" in result.stdout
        assert "Subclaim" in result.stdout

    def test_verdict_confidence_range(self, demo_cmd: list[str]) -> None:
        """Confidence is between 0 and 100%."""
        result = subprocess.run(
            [*demo_cmd, "--offline", "--json", "Test claim"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        assert result.returncode == 0

        output = json.loads(result.stdout)
        for item in output:
            assert 0.0 <= item["confidence"] <= 1.0

    def test_empty_claim_error(self, demo_cmd: list[str]) -> None:
        """Empty string claim is handled gracefully."""
        result = subprocess.run(
            [*demo_cmd, "--offline", ""],
            capture_output=True,
            text=True,
            timeout=10,
        )
        # Should either exit 0 or 64, but not crash
        assert result.returncode in (0, 64)


class TestDemoIntegration:
    """End-to-end integration tests."""

    def test_real_claim_offline_produces_unverified(self, demo_cmd: list[str]) -> None:
        """Real claim in offline mode produces UNVERIFIED verdict."""
        result = subprocess.run(
            [*demo_cmd, "--offline", "The Higgs boson mass is 125 GeV"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        assert result.returncode == 0
        # In offline mode, all verdicts are UNVERIFIED or have 0 confidence
        output_str = result.stdout
        assert "UNVERIFIED" in output_str or "0%" in output_str

    def test_json_and_offline_together(self, demo_cmd: list[str]) -> None:
        """--json and --offline work together."""
        result = subprocess.run(
            [*demo_cmd, "--offline", "--json", "Physics claim"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        assert result.returncode == 0

        # Should be valid JSON
        output = json.loads(result.stdout)
        assert isinstance(output, list)

    def test_special_characters_in_claim(self, demo_cmd: list[str]) -> None:
        """Claims with special characters are handled."""
        claim = "E=mc² is Einstein's famous equation (E = m * c²)"
        result = subprocess.run(
            [*demo_cmd, "--offline", claim],
            capture_output=True,
            text=True,
            timeout=10,
        )
        assert result.returncode == 0

    def test_long_claim(self, demo_cmd: list[str]) -> None:
        """Very long claims are truncated gracefully."""
        claim = "The Earth orbits the Sun. " * 100  # Very long input
        result = subprocess.run(
            [*demo_cmd, "--offline", claim],
            capture_output=True,
            text=True,
            timeout=10,
        )
        assert result.returncode == 0
