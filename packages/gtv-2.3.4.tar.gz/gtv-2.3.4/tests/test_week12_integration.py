"""Week 12 integration tests — live-server wiring.

Verifies that Week 11 modules (telemetry middleware, DB-backed API keystore,
signed consensus provenance chain) are actually wired into the running app.
Not module-level tests — these run through the FastAPI TestClient.
"""
from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from gtv.models import AnchorProof, Envelope, Evidence, Stance, Verdict


def _make_envelope(
    verdict: Verdict,
    issuer_did: str,
    claim_id: str = "test-claim-id",
) -> dict:
    envelope = Envelope(
        verdict=verdict,
        confidence=0.9,
        evidence=[
            Evidence(
                claim_id=claim_id,
                source_did="did:source",
                source_version="1.0",
                stance=Stance.SUPPORTS,
                excerpt="test excerpt",
                url="https://example.com",
                retrieved_at=datetime.now(tz=UTC),
                raw_hash="0" * 64,
            )
        ],
        rationale="test",
        issuer_did=issuer_did,
        signature="stub://sig",
        rekor_uuid="test-uuid",
        rekor_log_index=0,
        tsa_token="stub://tsa",
        prov_graph="{}",
        anchor_proof=AnchorProof(
            rekor_inclusion_proof="stub://proof",
            tsa_tsr_primary="stub://tsa",
        ),
    )
    return envelope.model_dump(mode="json")


@pytest.fixture
def client() -> TestClient:
    from gtv.mcp.server import app
    return TestClient(app)


class TestConsensusAggregateEnvelope:
    """POST /consensus must return a signed AggregateEnvelope (Week 11 provenance)."""

    def test_consensus_response_includes_aggregate(self, client: TestClient) -> None:
        env1 = _make_envelope(Verdict.VERIFIED, "did:test:issuer1")
        env2 = _make_envelope(Verdict.VERIFIED, "did:test:issuer2")

        resp = client.post("/consensus", json={"envelopes": [env1, env2]})
        assert resp.status_code == 200

        data = resp.json()
        assert "aggregate" in data
        assert data["aggregate"] is not None

        agg = data["aggregate"]
        # AggregateEnvelope required fields
        assert "aggregate_id" in agg
        assert "consensus_verdict" in agg
        assert "consensus_confidence" in agg
        assert "input_refs" in agg
        assert "aggregate_canonical_hash" in agg

    def test_aggregate_input_refs_match_inputs(self, client: TestClient) -> None:
        env1 = _make_envelope(Verdict.VERIFIED, "did:test:issuer1")
        env2 = _make_envelope(Verdict.VERIFIED, "did:test:issuer2")

        resp = client.post("/consensus", json={"envelopes": [env1, env2]})
        agg = resp.json()["aggregate"]

        # Two inputs → two input refs
        assert len(agg["input_refs"]) == 2
        for ref in agg["input_refs"]:
            assert "envelope_id" in ref
            assert "issuer_did" in ref
            assert "rekor_log_index" in ref
            assert "envelope_canonical_hash" in ref
            assert "weight_applied" in ref

    def test_aggregate_hash_well_formed(self, client: TestClient) -> None:
        """Aggregate canonical hash is 64-char lowercase hex sha256."""
        import re

        env1 = _make_envelope(Verdict.VERIFIED, "did:test:issuer1")
        env2 = _make_envelope(Verdict.VERIFIED, "did:test:issuer2")

        r = client.post("/consensus", json={"envelopes": [env1, env2]})
        assert r.status_code == 200

        h = r.json()["aggregate"]["aggregate_canonical_hash"]
        assert re.fullmatch(r"[0-9a-f]{64}", h), f"bad hash format: {h}"


class TestTelemetryMiddlewareWired:
    """Telemetry middleware must increment request counters on /health."""

    def test_request_counter_increments(self, client: TestClient) -> None:
        from gtv.telemetry.metrics import gtv_requests_total

        initial = gtv_requests_total.labels(endpoint="/health", status="200")._value.get()
        resp = client.get("/health")
        assert resp.status_code == 200
        after = gtv_requests_total.labels(endpoint="/health", status="200")._value.get()
        assert after > initial

    def test_duration_histogram_observed(self, client: TestClient) -> None:
        from gtv.telemetry.metrics import gtv_request_duration_seconds

        initial_count = gtv_request_duration_seconds.labels(endpoint="/health")._sum.get()
        client.get("/health")
        after_count = gtv_request_duration_seconds.labels(endpoint="/health")._sum.get()
        # Duration observed (some non-negative amount added)
        assert after_count >= initial_count


class TestDBBackedAuth:
    """When GTV_API_KEY_DB is set, the middleware validates against the keystore."""

    def test_db_backed_key_authorizes(self, tmp_path: Path, monkeypatch) -> None:
        from gtv.auth.keystore import APIKeyStore

        db = tmp_path / "keys.db"
        store = APIKeyStore(str(db))
        _kid, raw_key = store.create_key(
            label="test", scopes=["verify", "consensus"], rate_limit_per_minute=None
        )

        monkeypatch.setenv("GTV_API_KEY_DB", str(db))
        monkeypatch.delenv("GTV_API_KEYS", raising=False)

        # Force server app to re-initialize with the env set
        import importlib

        import gtv.mcp.server as server_mod
        importlib.reload(server_mod)

        c = TestClient(server_mod.app)

        # /health skips auth
        assert c.get("/health").status_code == 200

        # Missing key → 401
        r_missing = c.post("/consensus", json={"envelopes": []})
        assert r_missing.status_code == 401

        # Valid DB-backed key → not 401 (400 because envelopes is empty, but auth passed)
        r_ok = c.post(
            "/consensus",
            json={"envelopes": []},
            headers={"Authorization": f"Bearer {raw_key}"},
        )
        assert r_ok.status_code != 401

    def test_revoked_db_key_rejected(self, tmp_path: Path, monkeypatch) -> None:
        from gtv.auth.keystore import APIKeyStore

        db = tmp_path / "keys.db"
        store = APIKeyStore(str(db))
        kid, raw_key = store.create_key(label="test", scopes=["verify"])
        assert store.revoke_key(kid)

        monkeypatch.setenv("GTV_API_KEY_DB", str(db))
        monkeypatch.delenv("GTV_API_KEYS", raising=False)

        import importlib

        import gtv.mcp.server as server_mod
        importlib.reload(server_mod)

        c = TestClient(server_mod.app)
        r = c.post(
            "/consensus",
            json={"envelopes": []},
            headers={"Authorization": f"Bearer {raw_key}"},
        )
        assert r.status_code == 401
