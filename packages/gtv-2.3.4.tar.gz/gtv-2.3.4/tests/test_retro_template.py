"""Guard against retrospective template rot."""

import re
from pathlib import Path


def test_template_has_required_sections():
    """Assert TEMPLATE.md contains all required H2 headings."""
    template_path = Path(__file__).parent.parent / "docs" / "retrospectives" / "TEMPLATE.md"

    assert template_path.exists(), f"Template not found at {template_path}"

    content = template_path.read_text()

    # Extract all H2 headings
    headings = re.findall(r"^## (.+)$", content, re.MULTILINE)
    heading_text = [h.strip() for h in headings]

    # Required sections
    required = {
        "What Shipped",
        "What Went Well",
        "What Went Wrong",
        "What We Learned",
        "Action Items",
        "Metrics Snapshot",
        "Sign-off",
    }

    found = set(heading_text)

    assert required.issubset(found), (
        f"Missing required sections: {required - found}\n"
        f"Found: {found}"
    )
