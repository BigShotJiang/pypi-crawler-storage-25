"""Tests for SOC2 controls mapping validation.

Verifies that the soc2_controls.md document is valid and the validation
script catches missing files.
"""

import subprocess
import sys
import tempfile
from pathlib import Path


def test_script_runs_clean():
    """Test that the SOC2 mapping check passes on the current doc."""
    script = Path(__file__).parent.parent / "scripts" / "check_soc2_mapping.py"
    result = subprocess.run(
        [sys.executable, str(script)],
        cwd=Path(__file__).parent.parent,
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, f"Script failed: {result.stderr}"
    assert "controls mapped" in result.stdout


def test_script_detects_missing_file():
    """Test that the script exits 1 when a referenced file is missing."""
    script = Path(__file__).parent.parent / "scripts" / "check_soc2_mapping.py"

    # Create a temp markdown with a reference to a nonexistent file
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir_path = Path(tmpdir)
        docs_dir = tmpdir_path / "docs" / "compliance"
        docs_dir.mkdir(parents=True)

        # Write a minimal test doc with one missing file reference
        test_doc = docs_dir / "soc2_controls.md"
        test_doc.write_text(
            """# SOC2 Controls

## Section 1

| Control ID | Criterion | Implementation | Evidence | Owner |
|---|---|---|---|---|
| CC1.1 | Test | `nonexistent/file/path.py` | Test | gtv-maintainers |
"""
        )

        # Run script from temp directory (it looks for docs/compliance/soc2_controls.md relative to script location)
        scripts_dir = tmpdir_path / "scripts"
        scripts_dir.mkdir()

        # Copy the script to temp directory
        import shutil

        shutil.copy(str(script), str(scripts_dir / "check_soc2_mapping.py"))

        result = subprocess.run(
            [sys.executable, str(scripts_dir / "check_soc2_mapping.py")],
            cwd=tmpdir_path,
            capture_output=True,
            text=True,
        )
        assert result.returncode == 1, f"Expected exit 1, got {result.returncode}; stdout: {result.stdout}; stderr: {result.stderr}"
        assert "missing-file errors" in result.stdout or "missing" in result.stderr.lower()
