"""Tests for certificate identity binding verification.

Covers:
1. Certificate parsing and SAN extraction.
2. OIDC issuer extension extraction.
3. Identity matching (success and failure cases).
"""
from __future__ import annotations

from datetime import UTC, datetime

import pytest
from cryptography import x509
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.x509.oid import NameOID

from gtv.did.verify_issuer import IssuerMismatchError, verify_cert_binds_to_identity


def _make_test_cert_with_san(
    email_san: str | None = None,
    uri_san: str | None = None,
    dns_san: str | None = None,
) -> str:
    """Create a test X.509 certificate with specified SANs.

    Args:
        email_san: Email SAN (RFC822Name).
        uri_san: URI SAN (UniformResourceIdentifier).
        dns_san: DNS SAN (DNSName).

    Returns:
        Certificate in PEM format (string).
    """
    private_key = ec.generate_private_key(ec.SECP256R1(), default_backend())
    subject = issuer = x509.Name(
        [x509.NameAttribute(NameOID.COMMON_NAME, "test-sigstore-cert")]
    )

    builder = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(issuer)
        .public_key(private_key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(datetime.now(UTC))
        .not_valid_after(datetime.now(UTC))
    )

    # Add SAN extension
    san_list = []
    if email_san:
        san_list.append(x509.RFC822Name(email_san))
    if uri_san:
        san_list.append(x509.UniformResourceIdentifier(uri_san))
    if dns_san:
        san_list.append(x509.DNSName(dns_san))

    if san_list:
        builder = builder.add_extension(
            x509.SubjectAlternativeName(san_list),
            critical=False,
        )

    cert = builder.sign(private_key, hashes.SHA256(), default_backend())

    return cert.public_bytes(serialization.Encoding.PEM).decode("utf-8")


class TestVerifyCertBindsToIdentity:
    """Tests for verify_cert_binds_to_identity."""

    def test_verify_email_san_match(self) -> None:
        """Verify success when email SAN matches expected."""
        cert_pem = _make_test_cert_with_san(email_san="test@example.com")
        expected_identity = {
            "issuer_email": "test@example.com",
            "issuer_san": None,
            "issuer_uri": None,
            "fulcio_oidc": None,
        }

        # Should not raise
        verify_cert_binds_to_identity(cert_pem, expected_identity)

    def test_verify_email_san_mismatch(self) -> None:
        """Verify failure when email SAN does not match."""
        cert_pem = _make_test_cert_with_san(email_san="test@example.com")
        expected_identity = {
            "issuer_email": "wrong@example.com",
            "issuer_san": None,
            "issuer_uri": None,
            "fulcio_oidc": None,
        }

        with pytest.raises(IssuerMismatchError, match="email SAN mismatch"):
            verify_cert_binds_to_identity(cert_pem, expected_identity)

    def test_verify_uri_san_match(self) -> None:
        """Verify success when URI SAN matches expected."""
        cert_pem = _make_test_cert_with_san(uri_san="https://github.com/user")
        expected_identity = {
            "issuer_email": None,
            "issuer_san": None,
            "issuer_uri": "https://github.com/user",
            "fulcio_oidc": None,
        }

        # Should not raise
        verify_cert_binds_to_identity(cert_pem, expected_identity)

    def test_verify_uri_san_mismatch(self) -> None:
        """Verify failure when URI SAN does not match."""
        cert_pem = _make_test_cert_with_san(uri_san="https://github.com/user")
        expected_identity = {
            "issuer_email": None,
            "issuer_san": None,
            "issuer_uri": "https://github.com/other",
            "fulcio_oidc": None,
        }

        with pytest.raises(IssuerMismatchError, match="URI SAN mismatch"):
            verify_cert_binds_to_identity(cert_pem, expected_identity)

    def test_verify_dns_san_match(self) -> None:
        """Verify success when DNS SAN matches expected."""
        cert_pem = _make_test_cert_with_san(dns_san="example.com")
        expected_identity = {
            "issuer_email": None,
            "issuer_san": "example.com",
            "issuer_uri": None,
            "fulcio_oidc": None,
        }

        # Should not raise
        verify_cert_binds_to_identity(cert_pem, expected_identity)

    def test_verify_dns_san_mismatch(self) -> None:
        """Verify failure when DNS SAN does not match."""
        cert_pem = _make_test_cert_with_san(dns_san="example.com")
        expected_identity = {
            "issuer_email": None,
            "issuer_san": "other.com",
            "issuer_uri": None,
            "fulcio_oidc": None,
        }

        with pytest.raises(IssuerMismatchError, match="DNS SAN mismatch"):
            verify_cert_binds_to_identity(cert_pem, expected_identity)

    def test_verify_oidc_issuer_no_extension(self) -> None:
        """Verify failure when OIDC issuer expected but cert has no extension."""
        cert_pem = _make_test_cert_with_san()  # No extensions
        expected_identity = {
            "issuer_email": None,
            "issuer_san": None,
            "issuer_uri": None,
            "fulcio_oidc": "https://oidc.example.com",
        }

        with pytest.raises(IssuerMismatchError, match="OIDC issuer mismatch"):
            verify_cert_binds_to_identity(cert_pem, expected_identity)

    def test_verify_multiple_sans_match(self) -> None:
        """Verify success with multiple SANs where all expected fields match."""
        cert_pem = _make_test_cert_with_san(
            email_san="test@example.com",
            uri_san="https://github.com/user",
            dns_san="example.com",
        )
        expected_identity = {
            "issuer_email": "test@example.com",
            "issuer_san": "example.com",
            "issuer_uri": "https://github.com/user",
            "fulcio_oidc": None,
        }

        # Should not raise
        verify_cert_binds_to_identity(cert_pem, expected_identity)

    def test_verify_no_sans_no_expectations(self) -> None:
        """Verify success when certificate has no SANs and none are expected."""
        cert_pem = _make_test_cert_with_san()  # No SANs
        expected_identity = {
            "issuer_email": None,
            "issuer_san": None,
            "issuer_uri": None,
            "fulcio_oidc": None,
        }

        # Should not raise
        verify_cert_binds_to_identity(cert_pem, expected_identity)

    def test_verify_cert_with_no_san_but_expected(self) -> None:
        """Verify failure when expected SAN but cert has none."""
        cert_pem = _make_test_cert_with_san()  # No SANs
        expected_identity = {
            "issuer_email": "test@example.com",
            "issuer_san": None,
            "issuer_uri": None,
            "fulcio_oidc": None,
        }

        with pytest.raises(IssuerMismatchError, match="email SAN mismatch"):
            verify_cert_binds_to_identity(cert_pem, expected_identity)

    def test_verify_malformed_cert_pem(self) -> None:
        """Verify failure with malformed certificate PEM."""
        cert_pem = "-----BEGIN CERTIFICATE-----\ninvalid\n-----END CERTIFICATE-----"
        expected_identity = {
            "issuer_email": None,
            "issuer_san": None,
            "issuer_uri": None,
            "fulcio_oidc": None,
        }

        with pytest.raises(ValueError, match="Failed to parse certificate"):
            verify_cert_binds_to_identity(cert_pem, expected_identity)

    def test_verify_all_fields_present_and_matching(self) -> None:
        """Verify success with all identity fields present and matching."""
        cert_pem = _make_test_cert_with_san(
            email_san="test@example.com",
            uri_san="https://github.com/user",
            dns_san="example.com",
        )
        expected_identity = {
            "issuer_email": "test@example.com",
            "issuer_san": "example.com",
            "issuer_uri": "https://github.com/user",
            "fulcio_oidc": None,
        }

        # Should not raise
        verify_cert_binds_to_identity(cert_pem, expected_identity)
