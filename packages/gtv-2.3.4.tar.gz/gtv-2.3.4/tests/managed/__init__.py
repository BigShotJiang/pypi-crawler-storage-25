"""Tests for managed offering control plane."""

# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
