"""Tests for usage tracking and snapshots."""

# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial

from datetime import timedelta

import pytest

from gtv.managed.usage import (
    UsageSnapshot,
    clear_usage,
    record_claim_verified,
    record_concurrent_verify,
    record_peer_added,
    record_peer_removed,
    snapshot,
)


@pytest.fixture(autouse=True)
def reset_usage():
    """Clear usage data before each test."""
    clear_usage()
    yield
    clear_usage()


class TestUsageSnapshot:
    """Test UsageSnapshot model."""

    def test_snapshot_model(self):
        """UsageSnapshot can be instantiated."""
        from datetime import UTC, datetime
        now = datetime.now(tz=UTC)
        snap = UsageSnapshot(
            tenant_id="test-tenant",
            window_start=now,
            window_end=now,
            claims_verified=10,
            concurrent_verifies_peak=2,
            federation_peers_count=1,
        )
        assert snap.tenant_id == "test-tenant"
        assert snap.claims_verified == 10
        assert snap.concurrent_verifies_peak == 2
        assert snap.federation_peers_count == 1

    def test_snapshot_defaults(self):
        """UsageSnapshot has sensible defaults."""
        from datetime import UTC, datetime
        now = datetime.now(tz=UTC)
        snap = UsageSnapshot(
            tenant_id="test",
            window_start=now,
            window_end=now,
        )
        assert snap.claims_verified == 0
        assert snap.concurrent_verifies_peak == 0
        assert snap.federation_peers_count == 0
        assert snap.verdict_signatures_emitted == 0


class TestRecordClaimVerified:
    """Test claim verification recording."""

    def test_record_single_claim(self):
        """Can record a single claim verification."""
        tenant_id = "tenant-1"
        record_claim_verified(tenant_id)
        snap = snapshot(tenant_id)
        assert snap.claims_verified == 1

    def test_record_multiple_claims(self):
        """Can record multiple claim verifications."""
        tenant_id = "tenant-1"
        for _ in range(5):
            record_claim_verified(tenant_id)
        snap = snapshot(tenant_id)
        assert snap.claims_verified == 5

    def test_record_different_tenants(self):
        """Claims are tracked separately per tenant."""
        record_claim_verified("tenant-1")
        record_claim_verified("tenant-1")
        record_claim_verified("tenant-2")

        snap1 = snapshot("tenant-1")
        snap2 = snapshot("tenant-2")

        assert snap1.claims_verified == 2
        assert snap2.claims_verified == 1


class TestRecordPeerAddedRemoved:
    """Test federation peer tracking."""

    def test_record_peer_added(self):
        """Can record a peer addition."""
        tenant_id = "tenant-1"
        record_peer_added(tenant_id)
        snap = snapshot(tenant_id)
        assert snap.federation_peers_count == 1

    def test_record_multiple_peers(self):
        """Can record multiple peer additions."""
        tenant_id = "tenant-1"
        for _ in range(3):
            record_peer_added(tenant_id)
        snap = snapshot(tenant_id)
        assert snap.federation_peers_count == 3

    def test_record_peer_removed(self):
        """Can record a peer removal."""
        tenant_id = "tenant-1"
        record_peer_added(tenant_id)
        record_peer_added(tenant_id)
        record_peer_removed(tenant_id)

        snap = snapshot(tenant_id)
        assert snap.federation_peers_count == 1

    def test_remove_below_zero(self):
        """Removing peers cannot go below zero."""
        tenant_id = "tenant-1"
        record_peer_removed(tenant_id)
        snap = snapshot(tenant_id)
        assert snap.federation_peers_count == 0

    def test_peers_separate_tenants(self):
        """Peer counts are separate per tenant."""
        record_peer_added("tenant-1")
        record_peer_added("tenant-1")
        record_peer_added("tenant-2")

        snap1 = snapshot("tenant-1")
        snap2 = snapshot("tenant-2")

        assert snap1.federation_peers_count == 2
        assert snap2.federation_peers_count == 1


class TestRecordConcurrentVerify:
    """Test concurrent verification peak tracking."""

    def test_record_concurrent_peak(self):
        """Can record concurrent verification count."""
        tenant_id = "tenant-1"
        record_concurrent_verify(tenant_id, 3)
        snap = snapshot(tenant_id)
        assert snap.concurrent_verifies_peak == 3

    def test_peak_is_maximum(self):
        """Concurrent peak tracks the maximum."""
        tenant_id = "tenant-1"
        record_concurrent_verify(tenant_id, 2)
        record_concurrent_verify(tenant_id, 5)
        record_concurrent_verify(tenant_id, 3)

        snap = snapshot(tenant_id)
        assert snap.concurrent_verifies_peak == 5

    def test_concurrent_separate_tenants(self):
        """Concurrent peaks are separate per tenant."""
        record_concurrent_verify("tenant-1", 5)
        record_concurrent_verify("tenant-2", 2)

        snap1 = snapshot("tenant-1")
        snap2 = snapshot("tenant-2")

        assert snap1.concurrent_verifies_peak == 5
        assert snap2.concurrent_verifies_peak == 2


class TestSnapshot:
    """Test snapshot generation."""

    def test_snapshot_empty_tenant(self):
        """Snapshot of unknown tenant returns zeros."""
        snap = snapshot("unknown-tenant")
        assert snap.tenant_id == "unknown-tenant"
        assert snap.claims_verified == 0
        assert snap.concurrent_verifies_peak == 0
        assert snap.federation_peers_count == 0
        assert snap.verdict_signatures_emitted == 0

    def test_snapshot_with_usage(self):
        """Snapshot includes recorded usage."""
        tenant_id = "test-tenant"
        record_claim_verified(tenant_id)
        record_claim_verified(tenant_id)
        record_peer_added(tenant_id)
        record_concurrent_verify(tenant_id, 2)

        snap = snapshot(tenant_id)
        assert snap.claims_verified == 2
        assert snap.federation_peers_count == 1
        assert snap.concurrent_verifies_peak == 2

    def test_snapshot_window_start_end(self):
        """Snapshot has correct window boundaries."""
        tenant_id = "test-tenant"
        snap = snapshot(tenant_id)

        # window_end should be close to now
        from datetime import UTC, datetime
        now = datetime.now(tz=UTC)
        assert (now - snap.window_end).total_seconds() < 5

        # window_start should be about 1 day before window_end
        delta = snap.window_end - snap.window_start
        assert 23.9 < delta.total_seconds() / 3600 < 24.1

    def test_snapshot_custom_window(self):
        """Snapshot respects custom window size."""
        tenant_id = "test-tenant"
        snap = snapshot(tenant_id, window=timedelta(hours=6))

        delta = snap.window_end - snap.window_start
        assert 5.9 < delta.total_seconds() / 3600 < 6.1

    def test_snapshot_small_window(self):
        """Snapshot works with small time windows."""
        tenant_id = "test-tenant"
        snap = snapshot(tenant_id, window=timedelta(minutes=5))

        delta = snap.window_end - snap.window_start
        assert delta.total_seconds() < 6 * 60


class TestClearUsage:
    """Test usage clearing."""

    def test_clear_all_usage(self):
        """Can clear all usage data."""
        record_claim_verified("tenant-1")
        record_claim_verified("tenant-2")
        record_peer_added("tenant-1")

        clear_usage()

        snap1 = snapshot("tenant-1")
        snap2 = snapshot("tenant-2")

        assert snap1.claims_verified == 0
        assert snap1.federation_peers_count == 0
        assert snap2.claims_verified == 0

    def test_clear_specific_tenant(self):
        """Can clear usage for a specific tenant."""
        record_claim_verified("tenant-1")
        record_claim_verified("tenant-2")

        clear_usage("tenant-1")

        snap1 = snapshot("tenant-1")
        snap2 = snapshot("tenant-2")

        assert snap1.claims_verified == 0
        assert snap2.claims_verified == 1

    def test_clear_nonexistent_tenant(self):
        """Clearing nonexistent tenant doesn't error."""
        record_claim_verified("tenant-1")
        clear_usage("nonexistent")
        snap = snapshot("tenant-1")
        assert snap.claims_verified == 1
