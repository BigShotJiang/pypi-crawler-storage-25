"""Tests for FastAPI router."""

# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial

import os

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from gtv.managed.api import router
from gtv.managed.tenants import InMemoryTenantStore, set_store
from gtv.managed.usage import clear_usage, record_claim_verified, record_peer_added


@pytest.fixture(autouse=True)
def reset():
    """Reset stores before each test."""
    set_store(InMemoryTenantStore())
    clear_usage()
    yield
    set_store(InMemoryTenantStore())
    clear_usage()


@pytest.fixture
def client():
    """Create a FastAPI test client with the managed router."""
    app = FastAPI()
    app.include_router(router)
    return TestClient(app)


@pytest.fixture
def admin_key(monkeypatch):
    """Set a test admin key in environment."""
    key = "test-admin-key-123"
    monkeypatch.setenv("GTV_MANAGED_ADMIN_KEY", key)
    return key


class TestPostTenants:
    """Test POST /managed/tenants endpoint."""

    def test_create_tenant_success(self, client, admin_key):
        """Can create a tenant with valid credentials."""
        response = client.post(
            "/managed/tenants",
            json={
                "name": "Test Tenant",
                "plan": "pro",
                "contact_email": "admin@test.com",
            },
            headers={"X-Admin-Key": admin_key},
        )
        assert response.status_code == 201
        data = response.json()
        assert data["name"] == "Test Tenant"
        assert data["plan"] == "pro"
        assert data["contact_email"] == "admin@test.com"
        assert data["status"] == "active"
        assert data["tenant_id"] is not None

    def test_create_tenant_with_billing(self, client, admin_key):
        """Can create tenant with billing ID."""
        response = client.post(
            "/managed/tenants",
            json={
                "name": "Enterprise",
                "plan": "enterprise",
                "contact_email": "cfo@enterprise.com",
                "billing_customer_id": "cust_stripe_123",
            },
            headers={"X-Admin-Key": admin_key},
        )
        assert response.status_code == 201
        data = response.json()
        assert data["billing_customer_id"] == "cust_stripe_123"

    def test_create_tenant_no_auth(self, client, admin_key, monkeypatch):
        """Create fails without auth."""
        # Clear the env var to simulate no admin key configured
        monkeypatch.delenv("GTV_MANAGED_ADMIN_KEY", raising=False)
        response = client.post(
            "/managed/tenants",
            json={
                "name": "Test",
                "plan": "free",
                "contact_email": "test@example.com",
            },
        )
        assert response.status_code == 401
        assert "not configured" in response.json()["detail"]

    def test_create_tenant_wrong_key(self, client, admin_key):
        """Create fails with wrong key."""
        response = client.post(
            "/managed/tenants",
            json={
                "name": "Test",
                "plan": "free",
                "contact_email": "test@example.com",
            },
            headers={"X-Admin-Key": "wrong-key"},
        )
        assert response.status_code == 401

    def test_create_tenant_invalid_plan(self, client, admin_key):
        """Create fails with invalid plan."""
        response = client.post(
            "/managed/tenants",
            json={
                "name": "Test",
                "plan": "platinum",
                "contact_email": "test@example.com",
            },
            headers={"X-Admin-Key": admin_key},
        )
        # Pydantic validation happens first, so we get 422
        assert response.status_code == 422

    def test_create_tenant_invalid_email(self, client, admin_key):
        """Create fails with invalid email."""
        response = client.post(
            "/managed/tenants",
            json={
                "name": "Test",
                "plan": "free",
                "contact_email": "not-an-email",
            },
            headers={"X-Admin-Key": admin_key},
        )
        assert response.status_code == 422  # Validation error


class TestGetTenants:
    """Test GET /managed/tenants/{tenant_id} endpoint."""

    def test_get_tenant(self, client, admin_key):
        """Can retrieve an existing tenant."""
        # Create first
        create_resp = client.post(
            "/managed/tenants",
            json={
                "name": "Test",
                "plan": "pro",
                "contact_email": "test@example.com",
            },
            headers={"X-Admin-Key": admin_key},
        )
        tenant_id = create_resp.json()["tenant_id"]

        # Get
        get_resp = client.get(
            f"/managed/tenants/{tenant_id}",
            headers={"X-Admin-Key": admin_key},
        )
        assert get_resp.status_code == 200
        data = get_resp.json()
        assert data["tenant_id"] == tenant_id
        assert data["name"] == "Test"

    def test_get_nonexistent_tenant(self, client, admin_key):
        """Get returns 404 for nonexistent tenant."""
        response = client.get(
            "/managed/tenants/nonexistent-id",
            headers={"X-Admin-Key": admin_key},
        )
        assert response.status_code == 404
        assert "not found" in response.json()["detail"]

    def test_get_tenant_no_auth(self, client):
        """Get fails without auth."""
        response = client.get("/managed/tenants/some-id")
        assert response.status_code == 401


class TestListTenants:
    """Test GET /managed/tenants endpoint."""

    def test_list_empty(self, client, admin_key):
        """List returns empty list initially."""
        response = client.get(
            "/managed/tenants",
            headers={"X-Admin-Key": admin_key},
        )
        assert response.status_code == 200
        assert response.json()["tenants"] == []

    def test_list_all(self, client, admin_key):
        """Can list all tenants."""
        # Create some
        for i in range(3):
            client.post(
                "/managed/tenants",
                json={
                    "name": f"Tenant {i}",
                    "plan": "free",
                    "contact_email": f"t{i}@example.com",
                },
                headers={"X-Admin-Key": admin_key},
            )

        response = client.get(
            "/managed/tenants",
            headers={"X-Admin-Key": admin_key},
        )
        assert response.status_code == 200
        tenants = response.json()["tenants"]
        assert len(tenants) == 3

    def test_list_filter_by_plan(self, client, admin_key):
        """Can filter by plan."""
        client.post(
            "/managed/tenants",
            json={
                "name": "Free",
                "plan": "free",
                "contact_email": "free@example.com",
            },
            headers={"X-Admin-Key": admin_key},
        )
        client.post(
            "/managed/tenants",
            json={
                "name": "Pro",
                "plan": "pro",
                "contact_email": "pro@example.com",
            },
            headers={"X-Admin-Key": admin_key},
        )

        response = client.get(
            "/managed/tenants?plan=free",
            headers={"X-Admin-Key": admin_key},
        )
        assert response.status_code == 200
        tenants = response.json()["tenants"]
        assert len(tenants) == 1
        assert tenants[0]["plan"] == "free"

    def test_list_filter_by_status(self, client, admin_key):
        """Can filter by status."""
        create_resp = client.post(
            "/managed/tenants",
            json={
                "name": "Test",
                "plan": "pro",
                "contact_email": "test@example.com",
            },
            headers={"X-Admin-Key": admin_key},
        )
        tenant_id = create_resp.json()["tenant_id"]

        # Suspend it
        client.post(
            f"/managed/tenants/{tenant_id}/suspend",
            headers={"X-Admin-Key": admin_key},
        )

        response = client.get(
            "/managed/tenants?status=suspended",
            headers={"X-Admin-Key": admin_key},
        )
        assert response.status_code == 200
        tenants = response.json()["tenants"]
        assert len(tenants) == 1
        assert tenants[0]["status"] == "suspended"


class TestSuspendReactivate:
    """Test suspend and reactivate endpoints."""

    def test_suspend_tenant(self, client, admin_key):
        """Can suspend a tenant."""
        create_resp = client.post(
            "/managed/tenants",
            json={
                "name": "Test",
                "plan": "pro",
                "contact_email": "test@example.com",
            },
            headers={"X-Admin-Key": admin_key},
        )
        tenant_id = create_resp.json()["tenant_id"]

        response = client.post(
            f"/managed/tenants/{tenant_id}/suspend",
            headers={"X-Admin-Key": admin_key},
        )
        assert response.status_code == 200
        assert response.json()["status"] == "suspended"

    def test_reactivate_tenant(self, client, admin_key):
        """Can reactivate a tenant."""
        create_resp = client.post(
            "/managed/tenants",
            json={
                "name": "Test",
                "plan": "pro",
                "contact_email": "test@example.com",
            },
            headers={"X-Admin-Key": admin_key},
        )
        tenant_id = create_resp.json()["tenant_id"]

        client.post(
            f"/managed/tenants/{tenant_id}/suspend",
            headers={"X-Admin-Key": admin_key},
        )

        response = client.post(
            f"/managed/tenants/{tenant_id}/reactivate",
            headers={"X-Admin-Key": admin_key},
        )
        assert response.status_code == 200
        assert response.json()["status"] == "active"

    def test_suspend_nonexistent(self, client, admin_key):
        """Suspending nonexistent tenant returns 404."""
        response = client.post(
            "/managed/tenants/nonexistent/suspend",
            headers={"X-Admin-Key": admin_key},
        )
        assert response.status_code == 404


class TestUsageEndpoint:
    """Test GET /managed/tenants/{tenant_id}/usage endpoint."""

    def test_get_usage_empty(self, client, admin_key):
        """Can get usage for a tenant with no recorded usage."""
        create_resp = client.post(
            "/managed/tenants",
            json={
                "name": "Test",
                "plan": "pro",
                "contact_email": "test@example.com",
            },
            headers={"X-Admin-Key": admin_key},
        )
        tenant_id = create_resp.json()["tenant_id"]

        response = client.get(
            f"/managed/tenants/{tenant_id}/usage",
            headers={"X-Admin-Key": admin_key},
        )
        assert response.status_code == 200
        data = response.json()
        assert data["tenant_id"] == tenant_id
        assert data["claims_verified"] == 0
        assert data["federation_peers_count"] == 0

    def test_get_usage_with_data(self, client, admin_key):
        """Can get usage with recorded events."""
        create_resp = client.post(
            "/managed/tenants",
            json={
                "name": "Test",
                "plan": "pro",
                "contact_email": "test@example.com",
            },
            headers={"X-Admin-Key": admin_key},
        )
        tenant_id = create_resp.json()["tenant_id"]

        # Record some usage
        record_claim_verified(tenant_id)
        record_claim_verified(tenant_id)
        record_peer_added(tenant_id)

        response = client.get(
            f"/managed/tenants/{tenant_id}/usage",
            headers={"X-Admin-Key": admin_key},
        )
        assert response.status_code == 200
        data = response.json()
        assert data["claims_verified"] == 2
        assert data["federation_peers_count"] == 1

    def test_get_usage_nonexistent(self, client, admin_key):
        """Getting usage for nonexistent tenant returns 404."""
        response = client.get(
            "/managed/tenants/nonexistent/usage",
            headers={"X-Admin-Key": admin_key},
        )
        assert response.status_code == 404


class TestQuotaCheckEndpoint:
    """Test GET /managed/tenants/{tenant_id}/quota-check endpoint."""

    def test_quota_check_within(self, client, admin_key):
        """Quota check returns allowed=True when within limits."""
        create_resp = client.post(
            "/managed/tenants",
            json={
                "name": "Test",
                "plan": "free",
                "contact_email": "test@example.com",
            },
            headers={"X-Admin-Key": admin_key},
        )
        tenant_id = create_resp.json()["tenant_id"]

        # Record some usage but stay within free limits (100 claims/day)
        for _ in range(50):
            record_claim_verified(tenant_id)

        response = client.get(
            f"/managed/tenants/{tenant_id}/quota-check",
            headers={"X-Admin-Key": admin_key},
        )
        assert response.status_code == 200
        data = response.json()
        assert data["allowed"] is True
        assert data["reason"] is None
        assert "claims_per_day" in data["headroom"]

    def test_quota_check_exceeded(self, client, admin_key):
        """Quota check returns allowed=False when limits exceeded."""
        create_resp = client.post(
            "/managed/tenants",
            json={
                "name": "Test",
                "plan": "free",
                "contact_email": "test@example.com",
            },
            headers={"X-Admin-Key": admin_key},
        )
        tenant_id = create_resp.json()["tenant_id"]

        # Record usage beyond free limit (100 claims/day)
        for _ in range(101):
            record_claim_verified(tenant_id)

        response = client.get(
            f"/managed/tenants/{tenant_id}/quota-check",
            headers={"X-Admin-Key": admin_key},
        )
        assert response.status_code == 200
        data = response.json()
        assert data["allowed"] is False
        assert "claims exceeded" in data["reason"]

    def test_quota_check_headroom(self, client, admin_key):
        """Quota check includes headroom percentages."""
        create_resp = client.post(
            "/managed/tenants",
            json={
                "name": "Test",
                "plan": "free",
                "contact_email": "test@example.com",
            },
            headers={"X-Admin-Key": admin_key},
        )
        tenant_id = create_resp.json()["tenant_id"]

        # Record 50% of daily limit
        for _ in range(50):
            record_claim_verified(tenant_id)

        response = client.get(
            f"/managed/tenants/{tenant_id}/quota-check",
            headers={"X-Admin-Key": admin_key},
        )
        assert response.status_code == 200
        data = response.json()
        assert abs(data["headroom"]["claims_per_day"] - 50.0) < 0.1

    def test_quota_check_nonexistent(self, client, admin_key):
        """Quota check for nonexistent tenant returns 404."""
        response = client.get(
            "/managed/tenants/nonexistent/quota-check",
            headers={"X-Admin-Key": admin_key},
        )
        assert response.status_code == 404


class TestAuthNoKeyConfigured:
    """Test auth when no admin key is configured."""

    def test_all_endpoints_reject_when_key_not_set(self, client):
        """All endpoints reject with 401 when no admin key is configured."""
        # Don't set GTV_MANAGED_ADMIN_KEY
        if "GTV_MANAGED_ADMIN_KEY" in os.environ:
            del os.environ["GTV_MANAGED_ADMIN_KEY"]

        response = client.post(
            "/managed/tenants",
            json={
                "name": "Test",
                "plan": "free",
                "contact_email": "test@example.com",
            },
        )
        assert response.status_code == 401
        assert "not configured" in response.json()["detail"]
