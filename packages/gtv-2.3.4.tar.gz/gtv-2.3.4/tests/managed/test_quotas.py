"""Tests for quota model and enforcement."""

# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial

from datetime import UTC, datetime

import pytest

from gtv.managed.quotas import (
    PlanQuota,
    QuotaCheckResult,
    check_quota,
    get_quota_for_plan,
)
from gtv.managed.tenants import Tenant
from gtv.managed.usage import UsageSnapshot


class TestPlanQuota:
    """Test PlanQuota model."""

    def test_quota_model(self):
        """PlanQuota can be instantiated."""
        quota = PlanQuota(
            plan="test",
            max_claims_per_day=100,
            max_concurrent_verifies=5,
            max_federation_peers=3,
        )
        assert quota.plan == "test"
        assert quota.max_claims_per_day == 100
        assert quota.burst_multiplier == 1.5  # default

    def test_quota_custom_burst(self):
        """PlanQuota allows custom burst multiplier."""
        quota = PlanQuota(
            plan="test",
            max_claims_per_day=100,
            max_concurrent_verifies=5,
            max_federation_peers=3,
            burst_multiplier=2.0,
        )
        assert quota.burst_multiplier == 2.0

    def test_quota_validation(self):
        """PlanQuota validates field constraints."""
        # max_claims_per_day must be > 0
        with pytest.raises(ValueError):
            PlanQuota(
                plan="bad",
                max_claims_per_day=0,
                max_concurrent_verifies=5,
                max_federation_peers=3,
            )

        # burst_multiplier must be > 1.0
        with pytest.raises(ValueError):
            PlanQuota(
                plan="bad",
                max_claims_per_day=100,
                max_concurrent_verifies=5,
                max_federation_peers=3,
                burst_multiplier=0.5,
            )


class TestGetQuotaForPlan:
    """Test quota retrieval."""

    def test_get_free_quota(self):
        """Free plan has correct quotas."""
        quota = get_quota_for_plan("free")
        assert quota.plan == "free"
        assert quota.max_claims_per_day == 100
        assert quota.max_concurrent_verifies == 2
        assert quota.max_federation_peers == 0

    def test_get_pro_quota(self):
        """Pro plan has correct quotas."""
        quota = get_quota_for_plan("pro")
        assert quota.plan == "pro"
        assert quota.max_claims_per_day == 10_000
        assert quota.max_concurrent_verifies == 10
        assert quota.max_federation_peers == 5

    def test_get_enterprise_quota(self):
        """Enterprise plan has correct quotas."""
        quota = get_quota_for_plan("enterprise")
        assert quota.plan == "enterprise"
        assert quota.max_claims_per_day == 1_000_000
        assert quota.max_concurrent_verifies == 100
        assert quota.max_federation_peers == 50

    def test_unknown_plan(self):
        """Raises KeyError for unknown plan."""
        with pytest.raises(KeyError, match="Unknown plan"):
            get_quota_for_plan("nonexistent")


class TestCheckQuota:
    """Test quota checking."""

    def test_quota_check_result(self):
        """QuotaCheckResult is properly constructed."""
        result = QuotaCheckResult(
            allowed=True,
            reason=None,
            headroom={"claims_per_day": 75.0},
        )
        assert result.allowed is True
        assert result.reason is None
        assert result.headroom == {"claims_per_day": 75.0}

    def test_empty_headroom_default(self):
        """QuotaCheckResult defaults headroom to empty dict."""
        result = QuotaCheckResult(allowed=True)
        assert result.headroom == {}

    def test_check_within_quota(self):
        """Tenant within quota returns allowed=True."""
        tenant = Tenant(name="Test", plan="free", contact_email="test@example.com")
        usage = UsageSnapshot(
            tenant_id=tenant.tenant_id,
            window_start=datetime.now(tz=UTC),
            window_end=datetime.now(tz=UTC),
            claims_verified=50,
            concurrent_verifies_peak=1,
            federation_peers_count=0,
        )

        result = check_quota(tenant, usage)
        assert result.allowed is True
        assert result.reason is None
        assert result.headroom["claims_per_day"] == 50.0  # 50% headroom
        assert result.headroom["concurrent_verifies"] == 50.0

    def test_check_at_quota(self):
        """Tenant at exactly the quota returns allowed=True."""
        tenant = Tenant(name="Test", plan="free", contact_email="test@example.com")
        usage = UsageSnapshot(
            tenant_id=tenant.tenant_id,
            window_start=datetime.now(tz=UTC),
            window_end=datetime.now(tz=UTC),
            claims_verified=100,  # max for free
            concurrent_verifies_peak=2,  # max for free
            federation_peers_count=0,
        )

        result = check_quota(tenant, usage)
        assert result.allowed is True
        assert result.headroom["claims_per_day"] == 0.0

    def test_check_exceeds_claims_quota(self):
        """Exceeding claims quota returns allowed=False."""
        tenant = Tenant(name="Test", plan="free", contact_email="test@example.com")
        usage = UsageSnapshot(
            tenant_id=tenant.tenant_id,
            window_start=datetime.now(tz=UTC),
            window_end=datetime.now(tz=UTC),
            claims_verified=101,  # exceeds free max of 100
            concurrent_verifies_peak=1,
            federation_peers_count=0,
        )

        result = check_quota(tenant, usage)
        assert result.allowed is False
        assert "claims exceeded" in result.reason
        assert result.headroom["claims_per_day"] == 0.0

    def test_check_exceeds_concurrent_quota(self):
        """Exceeding concurrent quota returns allowed=False."""
        tenant = Tenant(name="Test", plan="free", contact_email="test@example.com")
        usage = UsageSnapshot(
            tenant_id=tenant.tenant_id,
            window_start=datetime.now(tz=UTC),
            window_end=datetime.now(tz=UTC),
            claims_verified=50,
            concurrent_verifies_peak=3,  # exceeds free max of 2
            federation_peers_count=0,
        )

        result = check_quota(tenant, usage)
        assert result.allowed is False
        assert "concurrent verifies exceeded" in result.reason

    def test_check_exceeds_peers_quota(self):
        """Exceeding federation peers quota returns allowed=False."""
        tenant = Tenant(name="Test", plan="free", contact_email="test@example.com")
        usage = UsageSnapshot(
            tenant_id=tenant.tenant_id,
            window_start=datetime.now(tz=UTC),
            window_end=datetime.now(tz=UTC),
            claims_verified=50,
            concurrent_verifies_peak=1,
            federation_peers_count=1,  # free plan allows 0 peers
        )

        result = check_quota(tenant, usage)
        assert result.allowed is False
        assert "federation peers exceeded" in result.reason

    def test_check_multiple_exceeded(self):
        """Multiple exceeded quotas are reported in reason."""
        tenant = Tenant(name="Test", plan="free", contact_email="test@example.com")
        usage = UsageSnapshot(
            tenant_id=tenant.tenant_id,
            window_start=datetime.now(tz=UTC),
            window_end=datetime.now(tz=UTC),
            claims_verified=150,
            concurrent_verifies_peak=5,
            federation_peers_count=1,
        )

        result = check_quota(tenant, usage)
        assert result.allowed is False
        assert "claims exceeded" in result.reason
        assert "concurrent verifies exceeded" in result.reason
        assert "federation peers exceeded" in result.reason

    def test_check_pro_plan_headroom(self):
        """Pro plan headroom calculation is correct."""
        tenant = Tenant(name="Test", plan="pro", contact_email="test@example.com")
        usage = UsageSnapshot(
            tenant_id=tenant.tenant_id,
            window_start=datetime.now(tz=UTC),
            window_end=datetime.now(tz=UTC),
            claims_verified=9000,  # 90% of 10,000
            concurrent_verifies_peak=0,
            federation_peers_count=0,
        )

        result = check_quota(tenant, usage)
        assert result.allowed is True
        assert abs(result.headroom["claims_per_day"] - 10.0) < 0.1  # ~10% headroom

    def test_check_enterprise_plan_generous(self):
        """Enterprise plan has large headroom."""
        tenant = Tenant(
            name="Test",
            plan="enterprise",
            contact_email="test@example.com",
        )
        usage = UsageSnapshot(
            tenant_id=tenant.tenant_id,
            window_start=datetime.now(tz=UTC),
            window_end=datetime.now(tz=UTC),
            claims_verified=100_000,  # tiny fraction of 1M
            concurrent_verifies_peak=10,  # tiny fraction of 100
            federation_peers_count=5,  # tiny fraction of 50
        )

        result = check_quota(tenant, usage)
        assert result.allowed is True
        assert result.headroom["claims_per_day"] == 90.0  # 90% remaining
        assert result.headroom["concurrent_verifies"] == 90.0

    def test_check_free_plan_no_peers(self):
        """Free plan with 0 peers has 100% headroom."""
        tenant = Tenant(name="Test", plan="free", contact_email="test@example.com")
        usage = UsageSnapshot(
            tenant_id=tenant.tenant_id,
            window_start=datetime.now(tz=UTC),
            window_end=datetime.now(tz=UTC),
            claims_verified=50,
            concurrent_verifies_peak=1,
            federation_peers_count=0,
        )

        result = check_quota(tenant, usage)
        assert result.allowed is True
        assert result.headroom["federation_peers"] == 100.0
