"""Tests for tenant provisioning and lifecycle."""

# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial

import tempfile
from pathlib import Path

import pytest

from gtv.managed.tenants import (
    InMemoryTenantStore,
    JsonFileTenantStore,
    Tenant,
    create_tenant,
    get_tenant,
    list_tenants,
    reactivate_tenant,
    set_store,
    suspend_tenant,
)


@pytest.fixture(autouse=True)
def reset_store():
    """Reset to in-memory store before each test."""
    set_store(InMemoryTenantStore())
    yield
    set_store(InMemoryTenantStore())


class TestTenantModel:
    """Test Tenant Pydantic model."""

    def test_tenant_creation(self):
        """Tenant can be created with required fields."""
        tenant = Tenant(
            name="Test Co",
            plan="pro",
            contact_email="admin@test.com",
        )
        assert tenant.name == "Test Co"
        assert tenant.plan == "pro"
        assert tenant.contact_email == "admin@test.com"
        assert tenant.status == "active"
        assert tenant.tenant_id is not None
        assert tenant.created_at is not None

    def test_tenant_with_billing_id(self):
        """Tenant can include billing customer ID."""
        tenant = Tenant(
            name="Acme Corp",
            plan="enterprise",
            contact_email="billing@acme.com",
            billing_customer_id="cust_123456",
        )
        assert tenant.billing_customer_id == "cust_123456"

    def test_tenant_invalid_email(self):
        """Tenant rejects invalid email."""
        with pytest.raises(ValueError):
            Tenant(
                name="Bad Email",
                plan="free",
                contact_email="not-an-email",
            )

    def test_tenant_invalid_plan(self):
        """Tenant rejects unknown plan."""
        with pytest.raises(ValueError):
            Tenant(
                name="Unknown Plan",
                plan="platinum",
                contact_email="admin@test.com",
            )


class TestCreateTenant:
    """Test tenant creation API."""

    def test_create_tenant_free(self):
        """Can create a free plan tenant."""
        tenant = create_tenant(
            name="Startup",
            plan="free",
            contact_email="founder@startup.com",
        )
        assert tenant.name == "Startup"
        assert tenant.plan == "free"
        assert tenant.status == "active"
        assert tenant.billing_customer_id is None

    def test_create_tenant_with_billing(self):
        """Can create tenant with billing ID."""
        tenant = create_tenant(
            name="Enterprise Client",
            plan="enterprise",
            contact_email="cfo@enterprise.com",
            billing_customer_id="stripe_cust_abc123",
        )
        assert tenant.billing_customer_id == "stripe_cust_abc123"

    def test_create_multiple_tenants(self):
        """Multiple tenants get unique IDs."""
        t1 = create_tenant("Tenant 1", "free", "t1@example.com")
        t2 = create_tenant("Tenant 2", "pro", "t2@example.com")
        assert t1.tenant_id != t2.tenant_id


class TestGetTenant:
    """Test tenant retrieval."""

    def test_get_existing_tenant(self):
        """Can retrieve an existing tenant."""
        created = create_tenant("Test", "pro", "test@example.com")
        retrieved = get_tenant(created.tenant_id)
        assert retrieved is not None
        assert retrieved.tenant_id == created.tenant_id
        assert retrieved.name == "Test"

    def test_get_nonexistent_tenant(self):
        """Returns None for nonexistent tenant."""
        result = get_tenant("nonexistent-id")
        assert result is None


class TestSuspendReactivate:
    """Test tenant suspension and reactivation."""

    def test_suspend_tenant(self):
        """Can suspend an active tenant."""
        tenant = create_tenant("Test", "pro", "test@example.com")
        assert tenant.status == "active"

        suspended = suspend_tenant(tenant.tenant_id)
        assert suspended.status == "suspended"

        # Verify it persists
        retrieved = get_tenant(tenant.tenant_id)
        assert retrieved.status == "suspended"

    def test_reactivate_tenant(self):
        """Can reactivate a suspended tenant."""
        tenant = create_tenant("Test", "pro", "test@example.com")
        suspend_tenant(tenant.tenant_id)

        reactivated = reactivate_tenant(tenant.tenant_id)
        assert reactivated.status == "active"

        # Verify it persists
        retrieved = get_tenant(tenant.tenant_id)
        assert retrieved.status == "active"

    def test_suspend_nonexistent_tenant(self):
        """Suspending nonexistent tenant raises ValueError."""
        with pytest.raises(ValueError, match="not found"):
            suspend_tenant("nonexistent-id")

    def test_reactivate_nonexistent_tenant(self):
        """Reactivating nonexistent tenant raises ValueError."""
        with pytest.raises(ValueError, match="not found"):
            reactivate_tenant("nonexistent-id")


class TestListTenants:
    """Test tenant listing and filtering."""

    def test_list_empty(self):
        """Listing with no tenants returns empty list."""
        result = list_tenants()
        assert result == []

    def test_list_all_tenants(self):
        """Can list all tenants."""
        t1 = create_tenant("T1", "free", "t1@example.com")
        t2 = create_tenant("T2", "pro", "t2@example.com")
        t3 = create_tenant("T3", "enterprise", "t3@example.com")

        result = list_tenants()
        assert len(result) == 3
        ids = {t.tenant_id for t in result}
        assert ids == {t1.tenant_id, t2.tenant_id, t3.tenant_id}

    def test_list_filter_by_plan(self):
        """Can filter tenants by plan."""
        create_tenant("T1", "free", "t1@example.com")
        create_tenant("T2", "free", "t2@example.com")
        create_tenant("T3", "pro", "t3@example.com")

        free_tenants = list_tenants(plan="free")
        assert len(free_tenants) == 2
        assert all(t.plan == "free" for t in free_tenants)

        pro_tenants = list_tenants(plan="pro")
        assert len(pro_tenants) == 1
        assert pro_tenants[0].plan == "pro"

    def test_list_filter_by_status(self):
        """Can filter tenants by status."""
        t1 = create_tenant("T1", "free", "t1@example.com")
        t2 = create_tenant("T2", "pro", "t2@example.com")

        suspend_tenant(t1.tenant_id)

        active = list_tenants(status="active")
        assert len(active) == 1
        assert active[0].tenant_id == t2.tenant_id

        suspended = list_tenants(status="suspended")
        assert len(suspended) == 1
        assert suspended[0].tenant_id == t1.tenant_id

    def test_list_filter_by_plan_and_status(self):
        """Can filter by both plan and status."""
        t1 = create_tenant("T1", "free", "t1@example.com")
        create_tenant("T2", "free", "t2@example.com")
        t3 = create_tenant("T3", "pro", "t3@example.com")

        suspend_tenant(t1.tenant_id)
        suspend_tenant(t3.tenant_id)

        result = list_tenants(plan="free", status="suspended")
        assert len(result) == 1
        assert result[0].tenant_id == t1.tenant_id


class TestInMemoryStore:
    """Test in-memory tenant store."""

    def test_store_isolation(self):
        """In-memory store is isolated per instance."""
        store1 = InMemoryTenantStore()
        store2 = InMemoryTenantStore()

        t1 = Tenant(name="T1", plan="free", contact_email="t1@example.com")
        store1.create(t1)

        assert store1.get(t1.tenant_id) is not None
        assert store2.get(t1.tenant_id) is None

    def test_store_duplicate_create(self):
        """Creating duplicate tenant raises ValueError."""
        store = InMemoryTenantStore()
        tenant = Tenant(name="T1", plan="free", contact_email="t1@example.com")

        store.create(tenant)
        with pytest.raises(ValueError, match="already exists"):
            store.create(tenant)

    def test_store_update_nonexistent(self):
        """Updating nonexistent tenant raises ValueError."""
        store = InMemoryTenantStore()
        tenant = Tenant(name="T1", plan="free", contact_email="t1@example.com")

        with pytest.raises(ValueError, match="not found"):
            store.update(tenant)


class TestJsonFileStore:
    """Test JSON file-backed tenant store."""

    def test_json_store_persistence(self):
        """Tenants persist to JSON file."""
        with tempfile.TemporaryDirectory() as tmpdir:
            file_path = Path(tmpdir) / "tenants.json"

            # Create and persist
            store1 = JsonFileTenantStore(file_path)
            tenant = Tenant(
                name="Persistent",
                plan="pro",
                contact_email="persist@example.com",
            )
            store1.create(tenant)

            # Reload from disk
            store2 = JsonFileTenantStore(file_path)
            retrieved = store2.get(tenant.tenant_id)
            assert retrieved is not None
            assert retrieved.name == "Persistent"
            assert retrieved.plan == "pro"

    def test_json_store_file_format(self):
        """JSON store uses correct file format."""
        with tempfile.TemporaryDirectory() as tmpdir:
            file_path = Path(tmpdir) / "tenants.json"

            store = JsonFileTenantStore(file_path)
            tenant = Tenant(
                name="Test",
                plan="free",
                contact_email="test@example.com",
            )
            store.create(tenant)

            # Check file content
            import json
            with open(file_path) as f:
                data = json.load(f)
            assert tenant.tenant_id in data
            assert data[tenant.tenant_id]["name"] == "Test"
            assert data[tenant.tenant_id]["plan"] == "free"

    def test_json_store_corrupted_file(self):
        """JSON store handles corrupted files gracefully."""
        with tempfile.TemporaryDirectory() as tmpdir:
            file_path = Path(tmpdir) / "tenants.json"

            # Write corrupted JSON
            with open(file_path, "w") as f:
                f.write("{ invalid json }")

            # Should start fresh
            store = JsonFileTenantStore(file_path)
            assert store.list() == []

            # Should still work
            tenant = Tenant(name="Test", plan="free", contact_email="test@example.com")
            store.create(tenant)
            assert store.get(tenant.tenant_id) is not None

    def test_json_store_no_file(self):
        """JSON store creates file if it doesn't exist."""
        with tempfile.TemporaryDirectory() as tmpdir:
            file_path = Path(tmpdir) / "new_tenants.json"

            assert not file_path.exists()

            store = JsonFileTenantStore(file_path)
            tenant = Tenant(name="Test", plan="free", contact_email="test@example.com")
            store.create(tenant)

            assert file_path.exists()
