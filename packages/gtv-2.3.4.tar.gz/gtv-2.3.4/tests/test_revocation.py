"""Unit tests for RevocationList signing, verification, and checking.

Covers:
1. Round-trip sign/verify (build + verify)
2. Signature failure on tampered list
3. Issuer DID mismatch detection
4. Revocation-by-envelope-id
5. Revocation-by-issuer-did
6. Revocation-by-rekor-index
7. Union semantics across multiple lists
8. Malformed signature rejection
"""
from __future__ import annotations

import json
from datetime import UTC, datetime

import pytest
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ed25519

from gtv.models import AnchorProof, Envelope, Verdict
from gtv.revocation import RevocationList
from gtv.revocation.check import is_revoked
from gtv.revocation.list import build_revocation_list, verify_revocation_list


@pytest.fixture
def ed25519_private_key_pem(tmp_path):
    """Generate a test Ed25519 private key in PEM format."""
    private_key = ed25519.Ed25519PrivateKey.generate()
    pem_bytes = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    pem_file = tmp_path / "test_key.pem"
    pem_file.write_bytes(pem_bytes)
    return pem_file


@pytest.fixture
def issuer_did(ed25519_private_key_pem):
    """Derive the issuer_did from the test key."""
    pem_bytes = ed25519_private_key_pem.read_bytes()
    private_key = serialization.load_pem_private_key(pem_bytes, password=None)
    public_key = private_key.public_key()
    raw_bytes = public_key.public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    from gtv.sign.byok import _derive_did_key_from_public_key
    return _derive_did_key_from_public_key("Ed25519", raw_bytes)


@pytest.fixture
def test_envelope() -> Envelope:
    """Create a minimal test envelope."""
    return Envelope(
        envelope_id="test-envelope-1",
        verdict=Verdict.VERIFIED,
        confidence=0.95,
        evidence=[],
        issuer_did="did:key:ztest_issuer",
        issued_at=datetime.now(tz=UTC),
        signature="byok-ed25519:fake",
        rekor_uuid="test-uuid",
        rekor_log_index=42,
        tsa_token="fake-tsa",
        prov_graph="{}",
        anchor_proof=AnchorProof(
            rekor_inclusion_proof="fake",
            tsa_tsr_primary="fake",
        ),
    )


class TestBuildAndVerify:
    """Test round-trip build and verify."""

    def test_build_sign_verify_roundtrip(self, ed25519_private_key_pem, issuer_did):
        """Test that building, signing, and verifying works end-to-end."""
        rl = build_revocation_list(
            issuer_did=issuer_did,
            envelope_ids=["env-1", "env-2"],
            private_key_path=ed25519_private_key_pem,
        )

        assert rl.issuer_did == issuer_did
        assert rl.revoked_envelope_ids == ["env-1", "env-2"]
        assert rl.signature.startswith("byok-ed25519:")
        assert len(rl.canonical_hash) == 64  # SHA256 hex

        # Verify signature
        assert verify_revocation_list(rl) is True

    def test_verify_fails_on_tampered_signature(self, ed25519_private_key_pem, issuer_did):
        """Test that verification fails if signature is tampered."""
        rl = build_revocation_list(
            issuer_did=issuer_did,
            envelope_ids=["env-1"],
            private_key_path=ed25519_private_key_pem,
        )

        # Tamper with signature
        tampered_sig = "byok-ed25519:invalid_base64!@#$"
        tampered_rl = rl.model_copy(update={"signature": tampered_sig})

        assert verify_revocation_list(tampered_rl) is False

    def test_verify_fails_on_tampered_hash(self, ed25519_private_key_pem, issuer_did):
        """Test that verification fails if canonical_hash is tampered."""
        rl = build_revocation_list(
            issuer_did=issuer_did,
            envelope_ids=["env-1"],
            private_key_path=ed25519_private_key_pem,
        )

        # Tamper with hash
        tampered_rl = rl.model_copy(
            update={"canonical_hash": "0" * 64}
        )

        assert verify_revocation_list(tampered_rl) is False

    def test_verify_fails_on_wrong_issuer_did(self, ed25519_private_key_pem, issuer_did):
        """Test that verification fails if issuer_did is tampered."""
        rl = build_revocation_list(
            issuer_did=issuer_did,
            envelope_ids=["env-1"],
            private_key_path=ed25519_private_key_pem,
        )

        # Tamper with issuer_did
        tampered_rl = rl.model_copy(
            update={"issuer_did": "did:key:zwrong"}
        )

        assert verify_revocation_list(tampered_rl) is False

    def test_build_with_issuer_did_mismatch(self, ed25519_private_key_pem, issuer_did):
        """Test that build_revocation_list rejects mismatched issuer_did."""
        wrong_did = "did:key:zwrong"

        with pytest.raises(ValueError, match="does not match derived DID"):
            build_revocation_list(
                issuer_did=wrong_did,
                envelope_ids=["env-1"],
                private_key_path=ed25519_private_key_pem,
            )

    def test_build_requires_private_key(self, issuer_did):
        """Test that build_revocation_list requires private_key_path."""
        with pytest.raises(ValueError, match="private_key_path is required"):
            build_revocation_list(
                issuer_did=issuer_did,
                envelope_ids=["env-1"],
                private_key_path=None,
            )

    def test_build_fails_on_missing_key_file(self, issuer_did, tmp_path):
        """Test that build_revocation_list fails if key file doesn't exist."""
        missing_path = tmp_path / "nonexistent.pem"

        with pytest.raises(FileNotFoundError):
            build_revocation_list(
                issuer_did=issuer_did,
                envelope_ids=["env-1"],
                private_key_path=missing_path,
            )


class TestEnvelopeRevocation:
    """Test envelope revocation checking."""

    def test_revoke_by_envelope_id(self, ed25519_private_key_pem, issuer_did, test_envelope):
        """Test that envelopes are revoked by envelope_id."""
        rl = build_revocation_list(
            issuer_did=issuer_did,
            envelope_ids=[test_envelope.envelope_id],
            private_key_path=ed25519_private_key_pem,
        )

        status = is_revoked(test_envelope, [rl])
        assert status.revoked is True
        assert "envelope_id" in (status.reason or "").lower()
        assert status.revoked_by_list_id == rl.list_id

    def test_revoke_by_issuer_did(self, ed25519_private_key_pem, issuer_did, test_envelope):
        """Test that all envelopes are revoked by issuer_did."""
        rl = build_revocation_list(
            issuer_did=issuer_did,
            issuer_dids=[test_envelope.issuer_did],
            private_key_path=ed25519_private_key_pem,
        )

        status = is_revoked(test_envelope, [rl])
        assert status.revoked is True
        assert "issuer" in (status.reason or "").lower()
        assert status.revoked_by_list_id == rl.list_id

    def test_revoke_by_rekor_index(self, ed25519_private_key_pem, issuer_did, test_envelope):
        """Test that envelopes are revoked by rekor_log_index."""
        rl = build_revocation_list(
            issuer_did=issuer_did,
            rekor_indices=[test_envelope.rekor_log_index],
            private_key_path=ed25519_private_key_pem,
        )

        status = is_revoked(test_envelope, [rl])
        assert status.revoked is True
        assert "rekor" in (status.reason or "").lower()
        assert status.revoked_by_list_id == rl.list_id

    def test_not_revoked_empty_list(self, ed25519_private_key_pem, issuer_did, test_envelope):
        """Test that envelopes are not revoked by empty lists."""
        rl = build_revocation_list(
            issuer_did=issuer_did,
            private_key_path=ed25519_private_key_pem,
        )

        status = is_revoked(test_envelope, [rl])
        assert status.revoked is False
        assert status.reason is None
        assert status.revoked_by_list_id is None

    def test_not_revoked_wrong_envelope_id(self, ed25519_private_key_pem, issuer_did, test_envelope):
        """Test that envelopes are not revoked by wrong envelope_id."""
        rl = build_revocation_list(
            issuer_did=issuer_did,
            envelope_ids=["wrong-id"],
            private_key_path=ed25519_private_key_pem,
        )

        status = is_revoked(test_envelope, [rl])
        assert status.revoked is False


class TestMultipleLists:
    """Test union semantics across multiple revocation lists."""

    def test_revoked_by_first_list(self, ed25519_private_key_pem, issuer_did, test_envelope):
        """Test that envelope is revoked by first list."""
        rl1 = build_revocation_list(
            issuer_did=issuer_did,
            envelope_ids=[test_envelope.envelope_id],
            private_key_path=ed25519_private_key_pem,
        )
        rl2 = build_revocation_list(
            issuer_did=issuer_did,
            envelope_ids=["other-id"],
            private_key_path=ed25519_private_key_pem,
        )

        status = is_revoked(test_envelope, [rl1, rl2])
        assert status.revoked is True
        assert status.revoked_by_list_id == rl1.list_id

    def test_revoked_by_second_list(self, ed25519_private_key_pem, issuer_did, test_envelope):
        """Test that envelope is revoked by second list."""
        rl1 = build_revocation_list(
            issuer_did=issuer_did,
            envelope_ids=["other-id"],
            private_key_path=ed25519_private_key_pem,
        )
        rl2 = build_revocation_list(
            issuer_did=issuer_did,
            envelope_ids=[test_envelope.envelope_id],
            private_key_path=ed25519_private_key_pem,
        )

        status = is_revoked(test_envelope, [rl1, rl2])
        assert status.revoked is True
        assert status.revoked_by_list_id == rl2.list_id

    def test_skip_invalid_signatures(self, ed25519_private_key_pem, issuer_did, test_envelope):
        """Test that invalid signatures are skipped, valid ones are used."""
        rl1 = build_revocation_list(
            issuer_did=issuer_did,
            envelope_ids=["other-id"],
            private_key_path=ed25519_private_key_pem,
        )
        # Tamper with signature
        rl1_bad = rl1.model_copy(update={"signature": "byok-ed25519:invalid"})

        rl2 = build_revocation_list(
            issuer_did=issuer_did,
            envelope_ids=[test_envelope.envelope_id],
            private_key_path=ed25519_private_key_pem,
        )

        status = is_revoked(test_envelope, [rl1_bad, rl2])
        assert status.revoked is True
        assert status.revoked_by_list_id == rl2.list_id


class TestMalformedSignatures:
    """Test rejection of malformed signatures."""

    def test_invalid_signature_prefix(self, ed25519_private_key_pem, issuer_did):
        """Test that non-byok signatures are rejected."""
        rl = build_revocation_list(
            issuer_did=issuer_did,
            envelope_ids=["env-1"],
            private_key_path=ed25519_private_key_pem,
        )
        bad_rl = rl.model_copy(update={"signature": "invalid-prefix:xyz"})

        assert verify_revocation_list(bad_rl) is False

    def test_invalid_base64_in_signature(self, ed25519_private_key_pem, issuer_did):
        """Test that invalid base64 is rejected."""
        rl = build_revocation_list(
            issuer_did=issuer_did,
            envelope_ids=["env-1"],
            private_key_path=ed25519_private_key_pem,
        )
        bad_rl = rl.model_copy(update={"signature": "byok-ed25519:!!invalid!!"})

        assert verify_revocation_list(bad_rl) is False

    def test_invalid_did_format(self, ed25519_private_key_pem, issuer_did):
        """Test that invalid DIDs are rejected."""
        rl = build_revocation_list(
            issuer_did=issuer_did,
            envelope_ids=["env-1"],
            private_key_path=ed25519_private_key_pem,
        )
        bad_rl = rl.model_copy(update={"issuer_did": "not-a-did"})

        assert verify_revocation_list(bad_rl) is False


class TestRevocationListModel:
    """Test RevocationList Pydantic model properties."""

    def test_frozen_model(self, ed25519_private_key_pem, issuer_did):
        """Test that RevocationList is frozen (immutable)."""
        from pydantic import ValidationError

        rl = build_revocation_list(
            issuer_did=issuer_did,
            envelope_ids=["env-1"],
            private_key_path=ed25519_private_key_pem,
        )

        with pytest.raises(ValidationError):
            rl.list_id = "changed"

    def test_roundtrip_json(self, ed25519_private_key_pem, issuer_did):
        """Test that RevocationList survives JSON round-trip."""
        rl = build_revocation_list(
            issuer_did=issuer_did,
            envelope_ids=["env-1"],
            issuer_dids=["did:key:ztest"],
            rekor_indices=[42],
            private_key_path=ed25519_private_key_pem,
        )

        json_str = rl.model_dump_json()
        data = json.loads(json_str)
        rl2 = RevocationList.model_validate(data)

        assert rl == rl2
        assert verify_revocation_list(rl2) is True
