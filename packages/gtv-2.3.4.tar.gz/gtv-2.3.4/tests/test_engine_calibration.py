"""Confidence calibration tests for the verdict engine.

These tests verify that the confidence formula lands values within specific
bands for different evidence configurations, ensuring sensible calibration
across tiers and evidence age.
"""
from __future__ import annotations

from datetime import UTC, datetime, timedelta

import pytest

from gtv.models import Claim, Evidence, Stance, TrustTier, Verdict
from gtv.verdict.engine import VerdictInputs, decide


@pytest.fixture
def claim() -> Claim:
    return Claim(text="The speed of light in vacuum is 299792458 m/s.")


def _ev(
    source: str,
    stance: Stance,
    *,
    claim_id: str,
    age_months: int = 0,
) -> Evidence:
    """Helper to create Evidence at a specific age in months."""
    retrieved_at = datetime.now(tz=UTC) - timedelta(days=age_months * 30)
    return Evidence(
        claim_id=claim_id,
        source_did=source,
        source_version="v1",
        stance=stance,
        excerpt="x",
        url="https://example.org/e",
        retrieved_at=retrieved_at,
        raw_hash="a" * 64,
    )


def test_two_tier1_fresh_verify_confidence(claim: Claim) -> None:
    """Target 1: Two TIER_1 fresh sources → confidence in [0.80, 0.95]."""
    evidence = [
        _ev("did:web:arxiv.org", Stance.SUPPORTS, claim_id=claim.claim_id, age_months=0),
        _ev("did:web:crossref.org", Stance.SUPPORTS, claim_id=claim.claim_id, age_months=0),
    ]
    out = decide(VerdictInputs(
        claim=claim,
        evidence=evidence,
        tier_of={
            "did:web:arxiv.org": TrustTier.TIER_1,
            "did:web:crossref.org": TrustTier.TIER_1,
        },
    ))
    assert out.decision == Verdict.VERIFIED
    assert 0.80 <= out.confidence <= 0.95, \
        f"Expected confidence in [0.80, 0.95], got {out.confidence:.4f}"


def test_three_tier1_fresh_verify_confidence(claim: Claim) -> None:
    """Target 2: Three TIER_1 fresh sources → confidence in [0.85, 0.99]."""
    evidence = [
        _ev("did:web:arxiv.org", Stance.SUPPORTS, claim_id=claim.claim_id, age_months=0),
        _ev("did:web:crossref.org", Stance.SUPPORTS, claim_id=claim.claim_id, age_months=0),
        _ev("did:web:inspirehep.org", Stance.SUPPORTS, claim_id=claim.claim_id, age_months=0),
    ]
    out = decide(VerdictInputs(
        claim=claim,
        evidence=evidence,
        tier_of={
            "did:web:arxiv.org": TrustTier.TIER_1,
            "did:web:crossref.org": TrustTier.TIER_1,
            "did:web:inspirehep.org": TrustTier.TIER_1,
        },
    ))
    assert out.decision == Verdict.VERIFIED
    assert 0.85 <= out.confidence <= 0.99, \
        f"Expected confidence in [0.85, 0.99], got {out.confidence:.4f}"


def test_one_tier3_fresh_unverified_confidence(claim: Claim) -> None:
    """Target 3: Single TIER_3 source (no tier_of map) → confidence <= 0.50, UNVERIFIED."""
    evidence = [
        _ev("did:web:somewhere.org", Stance.SUPPORTS, claim_id=claim.claim_id, age_months=0),
    ]
    out = decide(VerdictInputs(
        claim=claim,
        evidence=evidence,
        tier_of=None,
    ))
    assert out.decision == Verdict.UNVERIFIED
    assert out.confidence <= 0.50, \
        f"Expected confidence <= 0.50, got {out.confidence:.4f}"


def test_two_tier1_aged_60mo_confidence_drops(claim: Claim) -> None:
    """Target 4: Two TIER_1 sources aged 60 months → confidence drops by >= 0.1."""
    evidence_fresh = [
        _ev("did:web:arxiv.org", Stance.SUPPORTS, claim_id=claim.claim_id, age_months=0),
        _ev("did:web:crossref.org", Stance.SUPPORTS, claim_id=claim.claim_id, age_months=0),
    ]
    out_fresh = decide(VerdictInputs(
        claim=claim,
        evidence=evidence_fresh,
        tier_of={
            "did:web:arxiv.org": TrustTier.TIER_1,
            "did:web:crossref.org": TrustTier.TIER_1,
        },
    ))

    evidence_aged = [
        _ev("did:web:arxiv.org", Stance.SUPPORTS, claim_id=claim.claim_id, age_months=60),
        _ev("did:web:crossref.org", Stance.SUPPORTS, claim_id=claim.claim_id, age_months=60),
    ]
    out_aged = decide(VerdictInputs(
        claim=claim,
        evidence=evidence_aged,
        tier_of={
            "did:web:arxiv.org": TrustTier.TIER_1,
            "did:web:crossref.org": TrustTier.TIER_1,
        },
    ))

    assert out_fresh.decision == Verdict.VERIFIED
    assert out_aged.decision == Verdict.VERIFIED
    drop = out_fresh.confidence - out_aged.confidence
    assert drop >= 0.099, \
        f"Expected confidence drop >= 0.099, got {drop:.4f} " \
        f"(fresh={out_fresh.confidence:.4f}, aged={out_aged.confidence:.4f})"


def test_no_evidence_confidence(claim: Claim) -> None:
    """Target 5: No evidence → confidence = 0.10."""
    out = decide(VerdictInputs(claim=claim, evidence=[]))
    assert out.decision == Verdict.UNVERIFIED
    assert out.confidence == 0.1, \
        f"Expected confidence = 0.10, got {out.confidence:.4f}"


def test_one_support_one_refute_confidence(claim: Claim) -> None:
    """Target 6: 1 SUPPORT + 1 REFUTE (contested) → confidence <= 0.60."""
    evidence = [
        _ev("did:web:arxiv.org", Stance.SUPPORTS, claim_id=claim.claim_id, age_months=0),
        _ev("did:web:inspirehep.net", Stance.REFUTES, claim_id=claim.claim_id, age_months=0),
    ]
    out = decide(VerdictInputs(claim=claim, evidence=evidence, tier_of=None))
    assert out.decision == Verdict.CONTESTED
    assert out.confidence <= 0.60, \
        f"Expected confidence <= 0.60, got {out.confidence:.4f}"


def test_baseline_tests_still_pass(claim: Claim) -> None:
    """Verify that the original 6 baseline tests still hold their properties."""
    # test_creative_short_circuits
    out = decide(VerdictInputs(claim=claim, evidence=[], is_creative=True))
    assert out.decision == Verdict.CREATIVE

    # test_opinion_short_circuits
    out = decide(VerdictInputs(claim=claim, evidence=[], is_opinion=True))
    assert out.decision == Verdict.OPINION

    # test_two_independent_supports_verify — updated to >= 0.8
    evidence = [
        _ev("did:web:arxiv.org", Stance.SUPPORTS, claim_id=claim.claim_id),
        _ev("did:web:crossref.org", Stance.SUPPORTS, claim_id=claim.claim_id),
    ]
    out = decide(VerdictInputs(
        claim=claim,
        evidence=evidence,
        tier_of={
            "did:web:arxiv.org": TrustTier.TIER_1,
            "did:web:crossref.org": TrustTier.TIER_1,
        },
    ))
    assert out.decision == Verdict.VERIFIED
    assert out.confidence >= 0.8

    # test_support_and_refute_is_contested
    evidence = [
        _ev("did:web:arxiv.org", Stance.SUPPORTS, claim_id=claim.claim_id),
        _ev("did:web:inspirehep.net", Stance.REFUTES, claim_id=claim.claim_id),
    ]
    out = decide(VerdictInputs(claim=claim, evidence=evidence))
    assert out.decision == Verdict.CONTESTED

    # test_no_evidence_is_unverified
    out = decide(VerdictInputs(claim=claim, evidence=[]))
    assert out.decision == Verdict.UNVERIFIED
    assert out.confidence <= 0.2

    # test_single_support_is_unverified
    evidence = [_ev("did:web:arxiv.org", Stance.SUPPORTS, claim_id=claim.claim_id)]
    out = decide(VerdictInputs(claim=claim, evidence=evidence))
    assert out.decision == Verdict.UNVERIFIED
