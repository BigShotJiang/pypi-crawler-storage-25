"""Integration test: verify_claim hits the cache on the second call.

Registers a stub adapter that counts how many times it was queried. On a
cache hit, the adapter is not touched. This is the forward-progress test
for W27 — it proves the cache actually short-circuits external I/O.

We deliberately avoid ``importlib.reload`` — reloading ``gtv.adapters``
creates a new REGISTRY dict, which breaks other tests that imported
REGISTRY at import time. Instead we mutate REGISTRY in place and swap
the cache on the server module directly.
"""
from __future__ import annotations

from datetime import UTC, datetime

import pytest
from fastapi.testclient import TestClient
from pydantic import HttpUrl

from gtv.adapters import REGISTRY
from gtv.adapters.base import HealthStatus, RawSnapshot, SourceAdapter
from gtv.cache import InMemoryCacheStore, NullCacheStore, VerdictCache
from gtv.models import Claim, Evidence, SourceType, Stance, TrustTier


class _CountingAdapter(SourceAdapter):
    source_did = "did:web:counting.example"
    name = "counting"
    source_type = SourceType.REFERENCE_DATA
    trust_tier = TrustTier.TIER_1
    freshness_sla_s = 60

    def __init__(self) -> None:
        self.call_count = 0

    async def query(self, claim: Claim, max_items: int = 5) -> list[Evidence]:
        self.call_count += 1
        return [
            Evidence(
                claim_id=claim.claim_id,
                source_did=self.source_did,
                source_version="v1",
                stance=Stance.SUPPORTS,
                excerpt="counted",
                url=HttpUrl("https://counting.example/e/1"),
                retrieved_at=datetime.now(tz=UTC),
                raw_hash="0" * 64,
            )
        ]

    async def snapshot(self, url: str) -> RawSnapshot:
        return RawSnapshot(url=url, content=b"", retrieved_at_iso="")

    async def health(self) -> HealthStatus:
        return HealthStatus(state="HEALTHY", detail="")

    async def close(self) -> None:
        return None


@pytest.fixture
def counting_server() -> tuple[TestClient, _CountingAdapter]:
    """Swap in a counting adapter and a fresh in-memory cache, no reloads."""
    import gtv.mcp.server as server_mod

    # Save and restore REGISTRY and the server's cache — no module reloads.
    saved = dict(REGISTRY)
    saved_cache = server_mod._VERDICT_CACHE
    REGISTRY.clear()
    adapter = _CountingAdapter()
    REGISTRY[adapter.source_did] = adapter
    server_mod._VERDICT_CACHE = VerdictCache(InMemoryCacheStore())

    client = TestClient(server_mod.app)
    try:
        yield client, adapter
    finally:
        REGISTRY.clear()
        REGISTRY.update(saved)
        server_mod._VERDICT_CACHE = saved_cache


def test_second_call_is_cache_hit(
    counting_server: tuple[TestClient, _CountingAdapter],
) -> None:
    client, adapter = counting_server

    r1 = client.post(
        "/tools/verify_claim",
        json={"claim": "pi is approximately 3.14", "domain": "math", "max_sources": 3},
    )
    assert r1.status_code == 200
    assert adapter.call_count == 1

    r2 = client.post(
        "/tools/verify_claim",
        json={"claim": "pi is approximately 3.14", "domain": "math", "max_sources": 3},
    )
    assert r2.status_code == 200
    # Cache hit — adapter not re-queried.
    assert adapter.call_count == 1

    # Response envelope should be byte-identical on the hit path
    # (same signature, same anchor proof, same tsa_token).
    env1 = r1.json()["envelope"]
    env2 = r2.json()["envelope"]
    assert env1["signature"] == env2["signature"]
    assert env1["rekor_uuid"] == env2["rekor_uuid"]


def test_cache_keys_separate_by_domain(
    counting_server: tuple[TestClient, _CountingAdapter],
) -> None:
    client, adapter = counting_server

    client.post(
        "/tools/verify_claim", json={"claim": "c1", "domain": "physics", "max_sources": 3}
    )
    client.post(
        "/tools/verify_claim", json={"claim": "c1", "domain": "math", "max_sources": 3}
    )
    # Different domains → different keys → two adapter calls.
    assert adapter.call_count == 2


def test_cache_keys_separate_by_max_sources(
    counting_server: tuple[TestClient, _CountingAdapter],
) -> None:
    client, adapter = counting_server

    client.post(
        "/tools/verify_claim", json={"claim": "c1", "domain": "physics", "max_sources": 3}
    )
    client.post(
        "/tools/verify_claim", json={"claim": "c1", "domain": "physics", "max_sources": 5}
    )
    assert adapter.call_count == 2


def test_cache_disabled_by_env() -> None:
    """A NullCacheStore-backed cache → both calls hit the adapter."""
    import gtv.mcp.server as server_mod

    saved = dict(REGISTRY)
    saved_cache = server_mod._VERDICT_CACHE
    REGISTRY.clear()
    adapter = _CountingAdapter()
    REGISTRY[adapter.source_did] = adapter
    # Null store == disabled cache: same behavior as GTV_CACHE_ENABLED=0
    server_mod._VERDICT_CACHE = VerdictCache(NullCacheStore())

    client = TestClient(server_mod.app)
    try:
        client.post(
            "/tools/verify_claim",
            json={"claim": "disabled test", "domain": "general", "max_sources": 3},
        )
        client.post(
            "/tools/verify_claim",
            json={"claim": "disabled test", "domain": "general", "max_sources": 3},
        )
        assert adapter.call_count == 2
    finally:
        REGISTRY.clear()
        REGISTRY.update(saved)
        server_mod._VERDICT_CACHE = saved_cache


def test_cache_key_normalization_collides_trivial_variants(
    counting_server: tuple[TestClient, _CountingAdapter],
) -> None:
    client, adapter = counting_server

    client.post(
        "/tools/verify_claim",
        json={"claim": "The sky is BLUE.", "domain": "physics", "max_sources": 3},
    )
    # Same claim, different casing + extra whitespace → same cache entry.
    client.post(
        "/tools/verify_claim",
        json={"claim": "the  sky   is  blue.", "domain": "physics", "max_sources": 3},
    )
    assert adapter.call_count == 1


