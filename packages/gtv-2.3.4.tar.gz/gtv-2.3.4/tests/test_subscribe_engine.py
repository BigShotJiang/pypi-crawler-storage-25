"""Tests for subscription engine: add/remove/list, webhook-on-change, error handling."""
from __future__ import annotations

import asyncio
from contextlib import suppress
from pathlib import Path
from unittest.mock import AsyncMock, patch

import pytest

from gtv.models import Verdict
from gtv.subscribe import Subscription, SubscriptionEngine


@pytest.fixture
def engine(tmp_path: Path) -> SubscriptionEngine:
    """Return a fresh engine with temp store."""
    return SubscriptionEngine(store_path=tmp_path / "subs.db")


def test_add_subscription(engine: SubscriptionEngine) -> None:
    """Test adding a subscription."""
    sub = engine.add("The sky is blue", "https://example.com/webhook", interval_s=600)
    assert sub.claim == "The sky is blue"
    assert sub.webhook_url == "https://example.com/webhook"
    assert sub.interval_s == 600
    assert sub.last_verdict is None
    assert sub.id in [s.id for s in engine.list_all()]


def test_remove_subscription(engine: SubscriptionEngine) -> None:
    """Test removing a subscription."""
    sub = engine.add("claim", "https://example.com/webhook")
    assert engine.remove(sub.id)
    assert not engine.list_all()
    assert not engine.remove("nonexistent")


def test_list_subscriptions(engine: SubscriptionEngine) -> None:
    """Test listing subscriptions."""
    sub1 = engine.add("claim1", "https://example.com/webhook1")
    sub2 = engine.add("claim2", "https://example.com/webhook2")
    subs = engine.list_all()
    assert len(subs) == 2
    assert any(s.id == sub1.id for s in subs)
    assert any(s.id == sub2.id for s in subs)


@pytest.mark.asyncio
async def test_check_one_fires_webhook_on_change() -> None:
    """Test _check_one fires webhook when verdict changes."""
    engine = SubscriptionEngine()
    sub = engine.add("claim", "https://example.com/webhook")

    # Mock _verify_one to return VERIFIED
    mock_envelope = AsyncMock()
    mock_envelope.verdict = Verdict.VERIFIED
    mock_envelope.confidence = 0.95

    posted_payloads = []

    async def mock_post_webhook(url: str, payload: dict) -> None:
        posted_payloads.append(payload)

    with patch.object(engine, "_post_webhook", side_effect=mock_post_webhook), patch(
        "gtv.subscribe.engine._verify_one", return_value=mock_envelope
    ):
        # First check: should fire (last_verdict is None)
        await engine._check_one(sub)
        assert len(posted_payloads) == 1
        assert posted_payloads[0]["old_verdict"] is None
        assert posted_payloads[0]["new_verdict"] == "VERIFIED"
        assert sub.last_verdict == "VERIFIED"

        # Second check with same verdict: should NOT fire
        await engine._check_one(sub)
        assert len(posted_payloads) == 1

        # Change verdict to UNVERIFIED
        mock_envelope.verdict = Verdict.UNVERIFIED
        await engine._check_one(sub)
        assert len(posted_payloads) == 2
        assert posted_payloads[1]["old_verdict"] == "VERIFIED"
        assert posted_payloads[1]["new_verdict"] == "UNVERIFIED"
        assert sub.last_verdict == "UNVERIFIED"


@pytest.mark.asyncio
async def test_check_one_handles_webhook_failure() -> None:
    """Test _check_one doesn't crash if webhook POST fails."""
    engine = SubscriptionEngine()
    sub = engine.add("claim", "https://example.com/webhook")

    mock_envelope = AsyncMock()
    mock_envelope.verdict = Verdict.VERIFIED
    mock_envelope.confidence = 0.95

    async def mock_post_webhook_fail(url: str, payload: dict) -> None:
        raise Exception("Webhook POST failed")

    with patch.object(engine, "_post_webhook", side_effect=mock_post_webhook_fail), patch(
        "gtv.subscribe.engine._verify_one", return_value=mock_envelope
    ):
        # Should not raise, only log
        await engine._check_one(sub)
        # Verdict should still be updated despite webhook failure
        assert sub.last_verdict == "VERIFIED"


@pytest.mark.asyncio
async def test_check_one_handles_verify_failure() -> None:
    """Test _check_one handles verification failure gracefully."""
    engine = SubscriptionEngine()
    sub = engine.add("claim", "https://example.com/webhook")

    async def mock_verify_fail(*args, **kwargs) -> None:
        raise Exception("Verify failed")

    with patch("gtv.subscribe.engine._verify_one", side_effect=mock_verify_fail):
        # Should not raise, only log
        await engine._check_one(sub)
        # last_verdict should remain None
        assert sub.last_verdict is None


@pytest.mark.asyncio
async def test_run_forever_with_tasks() -> None:
    """Test run_forever creates and awaits periodic check tasks."""
    engine = SubscriptionEngine()
    engine.add("claim", "https://example.com/webhook")

    async def mock_check_one(s: Subscription) -> None:
        # Stop after one iteration to avoid infinite loop
        raise asyncio.CancelledError()

    with patch.object(engine, "_check_one", side_effect=mock_check_one), suppress(
        TimeoutError
    ):
        await asyncio.wait_for(engine.run_forever(), timeout=1.0)
