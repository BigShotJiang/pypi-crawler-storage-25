"""Integration tests for gtv-verify CLI with issuer identity verification.

The core functionality is tested at the unit level in test_did_resolve and
test_verify_cert_binding. This file tests the CLI integration point:
- that issuer verification is skipped with --trust-issuer
- that unsupported DID methods are rejected loudly
"""
from __future__ import annotations

import json
from datetime import UTC, datetime
from pathlib import Path

from cryptography import x509
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.x509.oid import NameOID

from gtv.cli.verify import verify_file
from gtv.models import AnchorProof, Envelope, Verdict


def _make_test_cert_with_san(email_san: str | None = None) -> bytes:
    """Create a test X.509 certificate with specified SANs."""
    private_key = ec.generate_private_key(ec.SECP256R1(), default_backend())
    subject = issuer = x509.Name(
        [x509.NameAttribute(NameOID.COMMON_NAME, "test-sigstore-cert")]
    )

    builder = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(issuer)
        .public_key(private_key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(datetime.now(UTC))
        .not_valid_after(datetime.now(UTC))
    )

    # Add SAN extension
    san_list = []
    if email_san:
        san_list.append(x509.RFC822Name(email_san))

    if san_list:
        builder = builder.add_extension(
            x509.SubjectAlternativeName(san_list),
            critical=False,
        )

    cert = builder.sign(private_key, hashes.SHA256(), default_backend())
    return cert.public_bytes(serialization.Encoding.PEM)


def _make_test_envelope_with_issuer(
    issuer_did: str,
    cert_pem: bytes,
) -> dict:
    """Create a test envelope with stub signature and specified issuer."""
    cert_pem_str = cert_pem.decode("utf-8") if isinstance(cert_pem, bytes) else cert_pem

    rekor_proof = {
        "log_index": 0,
        "tree_size": 1,
        "root_hash": "deadbeef" * 8,
        "hashes": [],
        "certificate_pem": cert_pem_str,
    }

    base_env = Envelope(
        verdict=Verdict.VERIFIED,
        confidence=0.95,
        evidence=[],
        rationale="test rationale",
        issuer_did=issuer_did,
        signature="stub://test-sig",
        rekor_uuid="test-uuid",
        rekor_log_index=0,
        tsa_token="stub://test-tsa",
        prov_graph="{}",
        anchor_proof=AnchorProof(
            rekor_inclusion_proof=json.dumps(rekor_proof, sort_keys=True),
            tsa_tsr_primary="stub://tsa",
        ),
    )

    return base_env.model_dump(mode="json")


class TestVerifyCliIssuerIdentity:
    """Integration tests for CLI issuer verification."""

    def test_verify_with_trust_issuer_flag_skips_verification(
        self, tmp_path: Path
    ) -> None:
        """CLI with --trust-issuer should skip issuer verification."""
        cert_pem_bytes = _make_test_cert_with_san(email_san="test@example.com")

        issuer_did = "did:web:example.com"
        env = _make_test_envelope_with_issuer(
            issuer_did=issuer_did,
            cert_pem=cert_pem_bytes,
        )

        envelope_file = tmp_path / "envelope.json"
        envelope_file.write_text(json.dumps(env))

        # With --trust-issuer and allow_stub, should exit 0 (stub signature check returns early)
        exit_code = verify_file(
            envelope_file, allow_stub=True, allow_unrooted=True, trust_issuer=True
        )
        assert exit_code == 0
