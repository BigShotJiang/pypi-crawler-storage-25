"""Verdict engine — rule-based, deterministic, traceable."""
from __future__ import annotations

from datetime import UTC, datetime

import pytest

from gtv.models import Claim, Evidence, Stance, TrustTier, Verdict
from gtv.verdict.engine import VerdictInputs, decide


def _ev(source: str, stance: Stance, *, claim_id: str) -> Evidence:
    return Evidence(
        claim_id=claim_id,
        source_did=source,
        source_version="v1",
        stance=stance,
        excerpt="x",
        url="https://example.org/e",
        retrieved_at=datetime.now(tz=UTC),
        raw_hash="a" * 64,
    )


@pytest.fixture
def claim() -> Claim:
    return Claim(text="The speed of light in vacuum is 299792458 m/s.")


def test_creative_short_circuits(claim: Claim) -> None:
    out = decide(VerdictInputs(claim=claim, evidence=[], is_creative=True))
    assert out.decision == Verdict.CREATIVE


def test_opinion_short_circuits(claim: Claim) -> None:
    out = decide(VerdictInputs(claim=claim, evidence=[], is_opinion=True))
    assert out.decision == Verdict.OPINION


def test_two_independent_supports_verify(claim: Claim) -> None:
    evidence = [
        _ev("did:web:arxiv.org", Stance.SUPPORTS, claim_id=claim.claim_id),
        _ev("did:web:crossref.org", Stance.SUPPORTS, claim_id=claim.claim_id),
    ]
    out = decide(VerdictInputs(
        claim=claim,
        evidence=evidence,
        tier_of={"did:web:arxiv.org": TrustTier.TIER_1,
                 "did:web:crossref.org": TrustTier.TIER_1},
    ))
    assert out.decision == Verdict.VERIFIED
    assert out.confidence >= 0.8


def test_support_and_refute_is_contested(claim: Claim) -> None:
    evidence = [
        _ev("did:web:arxiv.org", Stance.SUPPORTS, claim_id=claim.claim_id),
        _ev("did:web:inspirehep.net", Stance.REFUTES, claim_id=claim.claim_id),
    ]
    out = decide(VerdictInputs(claim=claim, evidence=evidence))
    assert out.decision == Verdict.CONTESTED


def test_no_evidence_is_unverified(claim: Claim) -> None:
    out = decide(VerdictInputs(claim=claim, evidence=[]))
    assert out.decision == Verdict.UNVERIFIED
    assert out.confidence <= 0.2


def test_single_support_is_unverified(claim: Claim) -> None:
    evidence = [_ev("did:web:arxiv.org", Stance.SUPPORTS, claim_id=claim.claim_id)]
    out = decide(VerdictInputs(claim=claim, evidence=evidence))
    assert out.decision == Verdict.UNVERIFIED
