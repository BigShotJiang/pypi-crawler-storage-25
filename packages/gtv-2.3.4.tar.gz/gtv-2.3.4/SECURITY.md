# Security Policy

## Reporting a vulnerability

Email: security@groundtruth.example (placeholder — update on publish).

Please include:
- Affected component and commit/tag.
- Reproduction steps or PoC.
- Impact assessment.

We commit to:
- Acknowledgement within 48 hours.
- Disclosure SLA: 4 hours for CVEs once a fix is staged.
- Public post-mortem on every incident that affected production envelopes.

## Scope

In scope:
- Envelope forgery, signature or Rekor inclusion-proof bypass.
- RFC 3161 timestamp bypass.
- Source adapter impersonation or poisoning.
- DID document hijacking.
- MCP tool-description tampering.

Out of scope (Phase 1):
- Pilot-customer-private adapter code.
- Load / DoS without an amplification primitive.

## Supply chain

Every release produces:
- SBOM (SPDX-JSON) via Syft, cosign-signed, published to Rekor.
- SBOM (CycloneDX-JSON) via `cyclonedx-py`, cosign-signed.
- `pip-audit` clean.
- Reproducible Docker image digest in the release notes.

## Continuous security gates

Every PR and push to `main` must pass:

| Check | Tool | Scope | Policy |
|---|---|---|---|
| Dependency CVE scan | `pip-audit` | Python deps in `pyproject.toml` | Fail on any advisory |
| Secret scan | `gitleaks` | Full git history | Fail on any match |
| Filesystem vuln scan | `trivy fs` | Repo tree (language + OS deps) | Fail on HIGH/CRITICAL |
| Container vuln scan | `trivy image` | Built Docker image | Fail on HIGH/CRITICAL |
| CodeQL-equivalent SAST | Ruff (E, F, B, SIM, RUF rulesets) | Python source | Fail on any finding |
| Type safety | mypy `--strict` | `src/` | Fail on any error |

Weekly scheduled re-runs catch newly disclosed CVEs against an unchanged tree.

## Local developer tooling

`pre-commit` hooks catch most issues before commit:

```bash
pip install pre-commit && pre-commit install
```

A full local mirror of the CI security gate:

```bash
scripts/security_gate.sh          # full gate
scripts/security_gate.sh pip-audit  # single check
```

## Dependency updates

Dependabot opens weekly PRs for:
- Python dependencies (grouped: minor+patch in one PR, major individually).
- GitHub Actions versions.
- Docker base image.

Security advisories produce an immediate PR regardless of schedule.

## Code ownership

`CODEOWNERS` requires review from `@groundtruth/security` on any change to signing, anchoring, revocation, audit logging, authentication, CI, or Dockerfile. Merge to `main` is blocked without that approval.
