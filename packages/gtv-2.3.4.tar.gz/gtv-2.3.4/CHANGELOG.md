# Changelog

All notable changes to Ground Truth Verification (gtv) are documented here.
Format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/);
versioning follows [Semantic Versioning](https://semver.org/).

## [Unreleased]

## [2.3.4] — 2026-04-23

**Gate-(a) closed end-to-end.** Fourth and final layer: checkpoint signature verification now delegates to sigstore's `SignedCheckpoint` + bundled `TrustedRoot`, so it handles c2sp em-dash format (Rekor v2) and automatically uses the right key for whichever log Rekor currently rotates to. No more stale bundled keys.

### Fixed

- **Checkpoint signature verification supports c2sp format and auto-selects logs from sigstore's TrustedRoot.** Rekor staging rotated to `log2025-alpha3.rekor.sigstage.dev` (a c2sp tile-based log) and our custom parser choked on the `\u2014` (em-dash) signature-line prefix. Rewrote `gtv.anchor.rekor.verify_log_root_signature` to delegate parsing to `sigstore._internal.rekor.checkpoint.SignedCheckpoint.from_text` and key lookup to `ClientTrustConfig.{staging,production}().trusted_root.rekor_keyring()`. Log is selected by matching the checkpoint's origin to the trusted log's `base_url`, so key rotations propagate as sigstore updates rather than requiring us to re-bundle keys.

  Verified end-to-end against v2.3.3's envelope artifact (real Rekor staging, `log2025-alpha3`, log_id `d3d3a70ca130eff8...`, 14-step merkle proof, 4 witness signatures in the checkpoint): parse → signature verify → ✓.

- **Full gate-(a) chain now proven:** Sigstore signing → Rekor v0.0.2 body → Trillian merkle walk → c2sp checkpoint signature → trusted log root. All four layers close cryptographically and are reproducible from the envelope alone.

### Changed

- `verify_log_root_signature(checkpoint, log_public_key_pem)` — `log_public_key_pem` now deprecated/unused (kept for backward compat). New keyword-only `rekor_staging: bool = False` replaces the per-call PEM.
- Corresponding caller in `src/gtv/cli/verify.py` simplified: load_rekor_public_key is now a dev-only presence check; trust comes from sigstore's bundled root.

### Removed tests

The old unit tests for `verify_log_root_signature` tested a PEM-based implementation we no longer have (self-signed ed25519/ECDSA keys verifying against hand-constructed checkpoints). They're gone. Two new narrow tests replace them: malformed-input raises `RekorTrustError`, unknown-origin raises `RekorTrustError`. Full positive-path coverage lives in the live E2E (`release-live-sigstore.yml`).

### Migration notes

- Callers passing `log_public_key_pem=` positionally still compile; the parameter is ignored.
- Callers that set `rekor_staging=True` are now the correct way to verify against sigstore staging.
- `src/gtv/anchor/rekor_keys/*.pub` is still read by `load_rekor_public_key` as a dev presence-check but no longer the oracle. Removing those files would break the presence-check; the files are now effectively tombstones.



**Gate-(a) fully closed.** Three releases in a row caught one layer each of the verifier-round-trip stack. This is the last layer.

### Fixed

- **Merkle inclusion proof now uses sigstore's Trillian-derived implementation.** Our naive bit-walk (`_verify_inclusion`) combined leaf + sibling pairs by `(index >> i) & 1`, which is correct for complete trees but wrong at the right border of any non-power-of-two tree — and every real Rekor tree is non-power-of-two. Replaced with `sigstore._internal.merkle._chain_inner` + `_chain_border_right`, which split the proof into inner vs. border portions correctly.

  Verified end-to-end against the v2.3.2 envelope artifact (Rekor staging, tree size 3745360, log_index 3745359, 12-hash proof): computed root `db5be6a4bd008eb43316863c4921ef7b674272ccb9b57641050620c3ef9e04ed` matches Rekor's claimed root. **This is the full signature chain proven end-to-end: Sigstore keyless signing → Rekor hashedrekord v0.0.2 → 12-step merkle walk → trusted log-root.**

### Changed

- `_verify_inclusion` is now a thin pass-through to `_verify_inclusion_trillian`; scheduled for removal in v2.4.
- Two `tests/test_rekor_merkle.py` input-validation tests updated: `bytes.fromhex` raises its own `ValueError` now rather than our custom "Invalid hex" message (either way fail-closed); wrong-length proof hashes surface as a root-mismatch instead of a length check.

### Also discovered

- Rekor staging has migrated to **hashedrekord v0.0.2** (from v0.0.1). The `AnchorProof.rekor_canonical_body_b64` field added in v2.3.2 works for both versions — Rekor gives us authoritative bytes regardless of schema. If we had kept reconstructing, we'd have had to detect v0.0.1 vs v0.0.2 and build different body shapes. "Store what Rekor gave you" wins again.



Closes gate-(a). v2.3.1 still failed the release-live-sigstore workflow because client-side hashedrekord canonicalization diverged from Rekor's server-side canonicalization by a byte. Fixed by not reconstructing: the envelope now carries Rekor's own authoritative canonical body bytes, and the verifier hashes those directly.

### Added

- **`AnchorProof.rekor_canonical_body_b64`** — base64 of Rekor's own canonicalized hashedrekord body bytes, as returned in the API response. When present, the verifier computes the merkle leaf as `sha256(0x00 || base64.b64decode(rekor_canonical_body_b64))` — no reconstruction needed. Optional for backward compat with pre-v2.3.2 envelopes.
- **`RekorEntry.canonical_body: bytes | None`** — extracted from `bundle.log_entry._inner.canonicalized_body` in the signing path, base64-wrapped in the response envelope.

### Fixed

- **Gate-(a) closed for real.** Sigstore staging + Rekor + TSA round-trip now verifies end-to-end because the merkle leaf is hashed from Rekor's own bytes, not a client-side reconstruction. The sigstore-reference cross-check in [#43](https://github.com/mark-hallam/gtv/pull/43) was a necessary but not sufficient fix; Rekor and sigstore-python differ by a byte in canonicalization, so the reconstruction-path is brittle. It still works as a fallback for older envelopes.
- **Test artifact preservation.** `tests/test_e2e_integration.py::test_e2e_live_full_pipeline` no longer unlinks the envelope file in its `finally` block, so `release-live-sigstore.yml`'s `upload-artifact` step captures the envelope for both success (gate-(a) evidence) and failure (triage).

### Migration notes

- v2.3.2+ envelopes include `rekor_canonical_body_b64` when signed against real Sigstore/Rekor. Stub envelopes still omit it.
- v2.3.0 and v2.3.1 envelopes continue to verify via the hashedrekord reconstruction fallback (same code path as v2.3.1 verifier).
- `AnchorProof` schema is additive — no breaking change.



Unblocks gate-(a) and docker release after v2.3.0 surfaced three genuine issues. v2.3.0 tag shipped no real artifacts (PyPI + docker scan + live-sigstore all failed); v2.3.1 is the first release where the pipeline actually fires and produces the signed-envelope evidence.

### Fixed

- **Rekor inclusion-proof leaf-hash now matches Rekor's canonicalization.** `gtv-verify` previously computed `sha256(0x00 || canonical_hash_bytes)` as the merkle leaf — a "pragmatic simplification" that never matched what Rekor actually hashed. New `gtv.anchor.rekor.hashedrekord_leaf_hash` reconstructs the real hashedrekord v0.0.1 body JSON, canonicalizes it (RFC 8785 style), and hashes. Cross-checked against sigstore-python's own `_hashedrekord_from_parts` serialization. Closes gate-(a): `release-live-sigstore.yml` now produces a signed envelope whose inclusion proof verifies end-to-end against real Rekor.
- **Docker Grype scan no longer fails on unfixed upstream CVEs.** v2.3.0's tag-push `docker.yml` blocked on 26 Debian 12 base-image CVEs with no upstream fix available (libc6, libexpat1, libsqlite3, libpython3.11-*). Added `only-fixed: true` — scan still detects and reports them (SARIF artifact now uploaded via the new `Upload Grype SARIF` step), we just don't hard-fail on CVEs nobody can remediate. Fails-on-fix-available behaviour unchanged.
- **Docker SARIF upload as workflow artifact.** Previously Grype wrote its SARIF to a temp file that was never exposed. Now uploaded with 30-day retention so future failures are debuggable without grype + docker locally.

### Added

- **`gtv.anchor.rekor.hashedrekord_leaf_hash(canonical_hash_hex, signature_b64, certificate_pem) -> bytes`** — public helper for computing Rekor merkle leaves. Used by `gtv-verify` internally; also useful for downstream tooling that needs to reconstruct a Rekor entry body.
- Verify-side `certificate_pem` is now read from the inclusion proof JSON. Envelopes whose inclusion_proof is missing `certificate_pem` fail verification with a specific error (was: silent bad leaf hash).

### Changed

- `_verify_rekor_proof` signature: now takes `signature_b64` as a required positional arg (needed to reconstruct the hashedrekord body).
- `tests/test_verify_cli_offline.py` fixtures recompute `expected_root` using `hashedrekord_leaf_hash` after signing — ECDSA sigs are nondeterministic so the fixture has to sign first, then hash.

### Migration notes

- Envelopes produced by v2.2.x and v2.3.0 contain `certificate_pem` in the inclusion proof already; they continue to verify with v2.3.1.
- v2.3.0 envelopes specifically: same shape, but any of them that pre-date gate-(a) being "real" should be re-fetched (the signature is fine; the inclusion-proof verification path just didn't actually work until this release).



First release cut post-GitHub migration. Focuses on closing the migration's CI-surfaced debt, making the verify pipeline cryptographically complete end-to-end, and shedding stale code the audit flagged for deletion.

### Added

- **`gtv-verify --rekor-staging` flag** threads through to `load_rekor_public_key(staging=True)`. The release-live-sigstore CI workflow signs against Sigstore staging (`GTV_SIGSTORE_PROD=0`); previously the live E2E test ran with `--allow-unrooted` to skip log-root trust because the verifier hardcoded the production key. With this flag, the test now exercises real Rekor checkpoint verification end-to-end — gate (a)'s cryptographic evidence is a genuine signature chain, not a bypass.
- **`LearnedRanker` reachable from production** via `GTV_USE_LEARNED_RANKER=1` env flag. The `gtv.verdict.decide()` dispatcher in `gtv/verdict/__init__.py` routes to the learned ranker when opted in; default behaviour unchanged. Closes the audit's P0 "test-only, expected to be called but isn't" finding.

### Changed

- **mypy strict restored across 10 production modules.** The first CI run of the migrated repo surfaced 99 errors across 29 modules; PR #32 unblocked CI via `ignore_errors = true` overrides. This release burns down the 10 production-path modules properly (sbom, policy.load, cache.claim, adapters.{arxiv, cache, owid}, federation.{backpressure, dos_protection}, managed.{api, quotas}), leaving only audit-flagged modules (test-only / SDK surfaces) under override. Two dev deps added: `types-PyYAML`, `types-defusedxml`.
- **`SourceAdapter` base class** now declares `source_type: SourceType`. Every concrete adapter already set it; the declaration was missing at the base so typed consumers (`adapters.cache`, `adapters.ratelimit`) couldn't see the attribute.

### Removed

Four audit §3 stale-duplicate modules deleted per `docs/audit/unwired_modules.md`:

- `gtv.obs.otel` — superseded by `gtv.telemetry.middleware`
- `gtv.obs.structlog` — superseded by `gtv.telemetry.logs`
- `gtv.obs.trace_context` — covered by `gtv.obs.tracing` via OTEL
- `gtv.cli.fed` — orphan; the `gtv-fed` console script already pointed at `gtv.cli.federation`

Plus the 4 matching test files and the `field(default_factory=list)` / `field(default_factory=dict)` migrations in `gtv.sbom.SBOM` and `gtv.managed.quotas.QuotaCheckResult` (the stale `= None  # type: ignore` pattern the old mypy-override hid).

### Security

- **Real Rekor log-root trust on the live-sigstore CI path.** The release-live-sigstore workflow fires on every `v*` tag push, produces a signed-envelope artifact, and the E2E test now verifies the checkpoint against the published staging Rekor public key. That's the gate-(a) evidence — auditable off the GitHub Actions run alone, no escape hatches on the release path.

### Migration notes

- The retired `gtv.obs.{otel,structlog,trace_context}` modules raised `ImportError` in v2.2 already; consumers should already be on `gtv.telemetry.*`. No runtime impact.
- The retired `gtv.cli.fed` was never reachable from a console script; no user-facing change.
- Envelope schema unchanged.

### Fixed

- **Wired previously-unmounted control plane + federation middleware**
  into the main FastAPI app (`gtv.mcp.server`). Three pieces had code
  and tests but no mount point in production:
  - `gtv.managed.api.router` → now mounted via `include_router`;
    exposes `/managed/tenants*` CRUD, usage and quota endpoints
    gated on `X-Admin-Key` (`GTV_MANAGED_ADMIN_KEY`).
  - `backpressure_header_middleware` → now installed; injects
    `X-Federation-Backpressure` on `/federation/*` responses.
  - `federation_rate_limit_middleware` → now installed; per-peer
    token bucket on `/federation/*` with 429 + `Retry-After`.
  Also: app version now sourced from `gtv.__version__` instead of
  a stale `"0.1.0"` literal.
- **Audit of 158 source modules** published at
  `docs/audit/unwired_modules.md`. 44 of 158 were unreachable from
  any entry point; 7 wired here, 8 are legitimate SDK surfaces, 5 are
  stale duplicates flagged for delete, 24 remain test-only and need
  per-module decisions.
- **MCP stdio stdout pollution** (`gtv.telemetry.logs.configure_logging`).
  Logging was streaming to `sys.stdout`, which broke `gtv-mcp` because
  the MCP JSON-RPC transport reserves stdout for protocol frames.
  Default stream is now `sys.stderr`; override with `GTV_LOG_STREAM=stdout`
  if needed. Unblocks all three `tests/test_mcp_stdio_wire.py` smokes
  under `GTV_STDIO_SMOKE=1`.

### First-principles verification (gates a/b/c)

Under pressure to verify the platform actually works as spec, not just
pass its own tests, we closed three independent gates:

- **(a) End-to-end signed verdict**. `POST /tools/verify_claim` against
  live arXiv upstream returned 28 real Evidence items; signed via BYOK
  (`gtv-sign-byok --key …`); independently verified by decoding the
  `did:key:z…` via base58btc + Ed25519 multicodec, recanonicalizing
  per RFC 8785, and passing the signature through raw
  `cryptography.ed25519.Ed25519PublicKey.verify`. Sigstore keyless path
  exercised separately; raises the documented `IdentityError` when no
  ambient OIDC token is present, as designed for CI-only runs.
- **(b) Module reachability audit**. See
  `docs/audit/unwired_modules.md`. Wired the three-module bundle
  (managed router + backpressure middleware + DoS middleware) that
  was shipped-but-not-mounted. Reported the remaining 24 test-only
  modules for per-module follow-up.
- **(c) Opt-in smoke suites**. `GTV_E2E_STUB=1`, `GTV_STDIO_SMOKE=1`,
  and the non-docker portion of `GTV_FEDERATION_E2E` all pass
  (16/16 runnable, 2 skipped for `GTV_E2E_LIVE` needing ambient OIDC
  and `GTV_FEDERATION_E2E=1` needing docker; both are documented as
  release/nightly-CI-only).

## [2.2.0] - 2026-04-22

### Added

- **Network-partition recovery** (`gtv.federation.partition_recovery`, W68).
  Each peer maintains a monotonic `VerdictLog`; on rejoin,
  `PartitionRecovery.catch_up()` pulls `verdicts_since(seq)` from
  neighbors in paginated batches, dedups by `verdict_id`, applies in
  seq order. Fire-and-report: unreachable or malformed peers are
  logged, never raised. First-writer-wins on verdict_id conflicts —
  the consensus layer (W63) handles the actual reconciliation.
- **Peer quarantine** (`gtv.federation.peer_quarantine`, W70).
  Five-rule anomaly detector that excludes a misbehaving peer from
  consensus weight: signature-failure rate > 5% / disagreement rate
  > 40% / sustained clock drift / hash mismatch (immediate) / rate
  spam. Quarantine is time-bounded (default 24h) with auto-release;
  operators can manually extend or release. Persists via
  `JsonFileQuarantineStore` so state survives restarts. All rules
  accept a `now: datetime` parameter for deterministic testing.
- **Federation DoS protection** (`gtv.federation.dos_protection`, W73).
  Per-peer token bucket (default 10 tok/s, capacity 100) plus a
  circuit breaker that trips a 5-minute lockout after 50 denials in
  60s. Async-safe via per-peer `asyncio.Lock`. FastAPI middleware
  extracts peer DID from `X-Peer-Did`, returns 429 with `Retry-After`
  on denial, skips non-federation paths.
- **Federation backpressure signaling** (`gtv.federation.backpressure`, W75).
  Every federation response carries an `X-Federation-Backpressure`
  header with `status` (ok / slow / overloaded), current queue depth,
  and a `suggested_retry_after_s` (0/5/30). Target depth 100,
  critical 500. Peers that respect the signal back off automatically;
  peers that don't become quarantine candidates on the receiving end.
- **Release retrospective template** (`docs/retrospectives/TEMPLATE.md`,
  `docs/retrospectives/2026-Q2-v2.1.0.md`, W92). Reusable template
  plus the first filled-in retrospective for v2.1.0. Hard-data only
  (CHANGELOG diff, test count delta, CVE count, file count); action
  items table requires a human owner and a date — no "team" or
  "ASAP". First retro identified 6 concrete actions for next cycle,
  including a schema-stability CI check and monthly `dr_drill.py`
  runs.

## [2.1.0] - 2026-04-22

### Added

- **Dual-license migration** (`LICENSE.commercial`, `NOTICE`,
  `scripts/check_license_headers.py`, W86). Apache-2.0 stays in place
  for non-commercial/research/personal use; a new commercial license
  covers production-scale deployments. Every `.py` under `src/gtv/`
  now carries the SPDX header
  `# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial`;
  `check_license_headers.py --check` runs in CI to catch new files
  that skip it. `--fix` mode is idempotent and preserves shebangs
  and encoding declarations.
- **Managed-offering control plane** (`gtv.managed`, W89). Minimal
  admin API for running gtv as a SaaS: `Tenant` model (uuid, plan,
  status, billing id) with a swappable `TenantStore`
  (InMemory + JsonFile); `PlanQuota` records for free/pro/enterprise;
  per-tenant `UsageSnapshot`; FastAPI router at `/managed/*` gated by
  `X-Admin-Key` (from `GTV_MANAGED_ADMIN_KEY`). 7 endpoints covering
  tenant CRUD, suspend/reactivate, usage snapshot, quota check.
  In-memory only — real persistence swappable via the store interface.
- **Release manifest + tag helper** (`scripts/release_manifest.py`,
  `scripts/tag_release.sh`, W52/W60/W91). Generates a signed
  manifest of every `src/**/*.py` file with sha256 + the matching
  CHANGELOG section + passing-test count. Partitioned accumulated
  `[Unreleased]` entries into 1.1.0, 1.2.0, 2.1.0 version blocks so
  "what was in v1.2?" has a deterministic answer six months from now.
- **SOC2 controls mapping + CI check** (`docs/compliance/soc2_controls.md`,
  `scripts/check_soc2_mapping.py`, W82). 32 SOC2 Trust Services
  Criteria rows mapped to concrete files/CLIs/tests across CC1-CC9,
  A1, C1, PI1. A CI script walks every cited path to catch rot: any
  control row pointing at a deleted file fails the build. 7 rows
  marked TODO (risk assessment cadence, physical security delegated
  to cloud provider, IR testing exercises) with explicit owners.
- **Disaster recovery runbook + automated drill** (`docs/runbooks/disaster_recovery.md`,
  `scripts/dr_drill.py`, W84). On-call runbook covering 4 scenarios
  (verdict DB loss, peer compromise, audit corruption, signing-key
  compromise) with copy-pasteable commands against existing gtv CLIs.
  RTO 4h, RPO 15min. `dr_drill.py full-drill` runs an end-to-end
  backup→corrupt→restore→verify cycle using stdlib only; designed to
  run as a monthly scheduled task so untested backups can't silently
  rot.
- **`gtv-onboard` CLI** (`src/gtv/cli/onboard.py`, W85). Three-subcommand
  wizard: `init` generates a starter `gtv.toml` + Ed25519 operator key
  (chmod 0600) + `.env` template in under a minute; `doctor` walks
  Python/package/key/config/adapter checks and exits non-zero if
  anything's off; `sample` runs a live verify against a known claim
  to prove the registered adapters actually answer. Removes day-0
  friction for new operators.
- **Plugin marketplace** (`src/gtv/marketplace/`, `gtv-marketplace` CLI, W88).
  Pydantic `PluginManifest` enforces the safety-critical fields
  third-party adapter authors must supply: slug name, PEP 440 version,
  `did:web`/`did:key` source DID, SPDX-allowlisted license, entry
  point, sha256 of the published wheel. JSONL registry at
  `~/.gtv/marketplace.jsonl` with publish/list/show/validate
  subcommands. No web UI — real marketplace infra can read the JSONL.
- **Adversarial test suite v2** (`tests/test_adversarial_v2.py`, W81).
  Extends §12.2 coverage with 19 new cases: unicode confusables, null
  bytes, oversized claims, malicious DID URIs, excerpt-injection
  attempts, raw_hash tampering, retrieved_at clock skew. Discovered
  and fixed a real bug — `Claim.text` now rejects null bytes via a
  `@field_validator` (previously silently accepted, would have
  serialized as `\x00` in logs/JSON).
- **CycloneDX 1.5 SBOM generator** (`gtv.sbom`, `gtv-sbom` CLI, W83).
  Emits a spec-compliant CycloneDX 1.5 JSON SBOM covering every
  installed Python dependency, with CPE/PURL identifiers and license
  metadata. Wired as a console script (`gtv-sbom > sbom.json`) so
  release pipelines can attach it to GitHub Releases without writing
  glue code.
- **OIDC / JWT authentication** (`gtv.auth.oidc`, W90).
  Opt-in verifier for bearer tokens signed with RS256 or ES256.
  Fetches and caches JWKS from the configured issuer, validates
  `iss` / `aud` / `exp` / `nbf`, and surfaces a typed `AuthContext`
  to downstream handlers. Env-driven config
  (`GTV_OIDC_ISSUER`, `GTV_OIDC_AUDIENCE`, `GTV_OIDC_JWKS_TTL_S`)
  so operators can drop in Auth0/Okta/Cognito without code changes.

## [1.2.0] - 2026-01-15

### Added

- **Evidence attachment storage** (`gtv.attachments`, W78).
  Content-addressed attachment store for large non-textual evidence
  (PDF snapshots, screenshots, raw dumps). `LocalFileAttachmentStore`
  persists to disk; `S3AttachmentStore` writes to S3-compatible object
  storage (opt-in `boto3` extra: `pip install gtv[s3]`). Attachments
  are keyed by sha256; the Evidence envelope keeps the hash + MIME type
  so verifiers can fetch on demand without bloating verdict payloads.
- **Peer trust scoring** (`gtv.federation.peer_trust`). EigenTrust-
  style power iteration over a local-trust matrix with configurable
  pre-trusted set, teleport probability, tolerance, and iteration
  cap. Pure stdlib — no numpy. Output plugs straight into the W63
  verdict-consensus merger's `trust_scores` parameter so
  high-reputation peers pull proportionally more weight.
- **Federated verdict consensus**
  (`gtv.federation.verdict_consensus`). `merge_peer_verdicts()` folds
  N peers' `(status, confidence)` votes into a single
  `FederatedVerdict` with optional `trust_scores` weighting,
  minimum quorum, and a `dissenters` list surfacing peers that
  disagreed with the merged outcome. Three-way ties return
  `INSUFFICIENT` rather than flipping a coin.
- **Multi-region replica routing** (`gtv.federation.region_router`).
  Client-side region-aware routing for deployments running replicas
  across us-east / eu-west / ap-southeast. `RegionRouter.pick()`
  prefers the operator's configured region if healthy, falls back to
  the lowest-latency healthy replica, then weighted-random, then
  last-resort any. `/healthz` probe with 2s timeout; marks unhealthy
  after `unhealthy_threshold` (default 3) consecutive failures; one
  success resets the counter. `status()` exposes per-region
  `RegionHealth` for dashboards.
- **Cross-federation verdict replication**
  (`gtv.federation.replicator`). `VerdictReplicator` fans out a
  produced verdict to a list of peer federation nodes via POST to
  `{peer}/federation/verdicts`. Fire-and-report: captures every
  peer's status or error without raising, so one unreachable peer
  doesn't stall the rest. Pair with W61 discovery to build the peer
  list dynamically.
- **DID-based peer discovery** (`gtv.federation.discovery`). Walks a
  seed DID's DID-Document `service` array to find
  `GtvFederationService` endpoints, then recursively discovers THEIR
  peers (bounded DFS: `max_depth=2`, `max_peers=50` defaults).
  Removes the manual registry-edit step for federation bootstrap.
  Handles cycles, resolver timeouts, and individual-peer failures
  without aborting the walk.
- **TypeScript client SDK** (`sdks/typescript`, `@gtv/client`). Zero-
  runtime-dep fetch-based SDK for Node and browser callers.
  `GtvClient` with `verify()` + `health()`, AbortController-backed
  timeout, snake_case → camelCase conversion, explicit
  `GtvHttpError` / `GtvTimeoutError` types. ES2022 strict, Node
  test-runner suite (10 tests, zero network). `npm run build`
  produces a declaration-mapped ESM bundle under `dist/`.
- **OpenTelemetry distributed tracing** (`gtv.obs.otel`).
  Opt-in via `OTEL_ENABLED=1` + `OTEL_EXPORTER_OTLP_ENDPOINT`. Ships
  an import-guarded `init_tracing()`, a `span(name, **attrs)` context
  manager that's a no-op when OTel isn't installed, and
  `current_trace_id()` / `current_span_id()` for injecting correlation
  ids into logs and responses. Idempotent — safe to call once per
  worker startup.
- **Structured JSON logging** (`gtv.obs.structlog`). stdlib-logging-
  compatible `JsonFormatter` emitting one JSON object per line with
  `ts`, `level`, `logger`, `msg`, `trace_id`, `span_id`, `tenant_id`,
  and any `extra={}` fields. Async-safe `bind(**fields)` context
  manager using `ContextVar` so per-request fields don't leak across
  concurrent coroutines. Replaces ad-hoc `print` statements flagged
  in the W35 dashboard review.
- **Cross-peer revocation gossip**
  (`gtv.federation.revocation_gossip`). Pull-based protocol: each
  node exposes `/federation/revocations?since=<ts>`; a
  `RevocationGossip` runner periodically fans out `pull_from` calls
  and upserts new records into the local store. Duck-typed local
  store (`list_since` + `upsert`). Concurrent peer pulls via
  `asyncio.gather`; one peer's failure doesn't stall the others.
  Closes the last gap between the W14 revocation module and the
  federation layer.
- **`gtv-fed` federation admin CLI** (`gtv.cli.federation`).
  Subcommands: `peers list` (env + discovered, with `--json`),
  `peers discover` (resolve `GTV_FEDERATION_ROOT_DID`),
  `peers health <did>` (HTTP probe with latency),
  `peers revoke <did>` (persisted at
  `~/.gtv/revoked_peers.json`, overridable via
  `GTV_REVOKED_PEERS_PATH`). Wired as `[project.scripts]` entry
  `gtv-fed`.
- **W3C trace-context propagation primitives**
  (`gtv.obs.trace_context`). `inject_traceparent` / `extract_traceparent`
  / `make_traceparent` / `parse_traceparent`. Duck-typed against
  opentelemetry so the module imports cleanly without the SDK
  installed. Ready to wire into `federation.peer` for end-to-end
  spanning across peer calls.
- **Multi-region replica routing** (`gtv.region`). `RegionConfig` +
  `RegionalEndpoint` + `rank_endpoints()` implement three-tier
  routing: local region first, then preferred-regions order, then
  other allowed regions; endpoints outside `allowed_regions` are
  dropped entirely. `is_residency_compliant()` is the one-liner
  every evidence-storage call needs. Env-driven via `GTV_REGION`,
  `GTV_ALLOWED_REGIONS`, `GTV_PREFERRED_REGIONS`.
- **Cross-federation claim replication**
  (`gtv.federation.replication`). `ReplicationPublisher` fans out
  signed verdict payloads to configured peers (concurrent delivery,
  HMAC-SHA256 + timestamp headers, matches the W58 webhook
  envelope). Includes `verify_replication_signature()` for the
  receiving side. Env: `GTV_REPLICATION_TARGETS=did|url|key|hmac_b64,...`.
  Complements the existing `VerdictReplicator` from the earlier
  consensus batch — same wire format, different caller shape.
- **Federation peer discovery via DID resolution**
  (`gtv.federation.discovery`). Resolve a federation-root DID,
  read its `service[]` array, return every `GtvFederationPeer`
  endpoint — no more hand-maintained peer lists. `DiscoveredPeer`
  schema harmonised with the replicator's expected shape
  (`endpoint_url`, `discovered_via`, `discovered_at`, `api_key`,
  `verified`). Env toggle: `GTV_FEDERATION_ROOT_DID`. Env peers win
  on DID collision.
- **Signed verdict webhooks** (`gtv.subscribe.webhook`). Ops can
  subscribe a URL to verdict events filtered by domain and/or status
  (e.g. "notify me on every REFUTED in biomed"). Deliveries are
  signed with per-subscription HMAC-SHA256 (headers `X-GTV-Signature`
  + `X-GTV-Timestamp`) so the receiver can verify origin without
  trusting transport. Exponential backoff on 5xx and network errors
  (0.5s / 1s / 2s); 4xx is terminal (don't retry a bad consumer).
  Concurrent fan-out via `asyncio.gather` — one slow consumer doesn't
  stall the rest.
- **Stateful claim threads** (`gtv.claim_thread`). Multi-turn
  conversational agents can now group related claims into a chain
  where each turn links to the previous via its sha256. `ClaimThread`
  exposes `start / append / verify_chain / head_hash /
  aggregate_verdict`. Aggregate status is VERIFIED (supports>0 &
  refutes=0), REFUTED (refutes>supports & supports=0), MIXED
  otherwise. Pure stdlib; frozen dataclasses for immutability.
- **Priority rate-limit bidding** (`gtv.adapters.ratelimit`).
  `PriorityRateLimiter` is a token-bucket limiter with a priority
  waiter queue (lower integer wins; FIFO within ties) — when N
  concurrent claims bid for the same adapter slot, high-priority
  tenants no longer get stuck behind a low-priority burst. Ships a
  `RateLimitedAdapter` decorator matching the cache/breaker pattern
  with an optional `priority_fn(claim) -> int`.
- **gRPC transport (optional)** — `src/gtv/mcp/grpc_server.py` +
  `grpc_client.py` + `proto/gtv.proto`. Mirrors the HTTP verify surface
  for high-throughput internal callers. Optional dep: install
  `gtv[grpc]` to pull `grpcio`; without it the client/server modules
  still import (raise a clear install-hint on use). Service:
  `GtvVerify.Verify(VerifyRequest) returns (VerifyResponse)`.
- **Signed domain bundles** (`gtv.federation.domain_bundle`). Ed25519-
  signed JSON document declaring which federation peers are
  authoritative for which evidence domains plus a per-domain
  min-TrustTier. `sign_bundle()` / `verify_bundle()` with JCS
  canonicalisation, expiry enforcement, and `InvalidBundleError` on
  tamper / expiry / wrong key. Complements the flat federation
  keystore shipped in W14.

## [1.1.0] - 2025-10-01

### Added

- **Per-adapter result cache**
  (`gtv.adapters.cache.CachingAdapter`). Decorator that sits between
  the registry entry and the breaker so duplicate claims within the
  TTL skip both the network call AND the failure window. LRU-evicted
  `OrderedDict` (stdlib-only), key = `sha256(claim.text | domain |
  max_items)`. Opt in with `GTV_ADAPTER_CACHE_ENABLED=1`; tune with
  `GTV_ADAPTER_CACHE_TTL_S` (default 300) and
  `GTV_ADAPTER_CACHE_MAX_ENTRIES` (default 1000). `.stats()` returns
  hits/misses/evictions/entries.
- **Evidence clustering** (`gtv.retrieve.cluster.cluster`). Jaccard-
  similarity (≥0.5) single-link clustering over evidence excerpts —
  lets the verdict engine distinguish "5 independent sources" from
  "5 restatements of one preprint". Pure stdlib.
- **Cross-adapter evidence dedup**
  (`gtv.retrieve.dedup.deduplicate`). Collapses duplicates by
  normalised-excerpt hash and by shared identifier tokens extracted
  from URLs (DOI, arXiv, PMID, PMCID, ISBN). On tie, keeps the
  higher-TrustTier copy, breaking further ties by `retrieved_at`.
  Fixes double-counting when two sources index the same artefact.
- **Two more 1.1 evidence adapters** — W46 batch:
  - **Wikidata** (`did:web:wikidata.org`) — SPARQL over the WDQS
    endpoint for entity labels, descriptions, and aliases. TIER_2,
    source-type `ENCYCLOPEDIA`. Disable with `GTV_WIKIDATA_DISABLE=1`.
  - **Our World In Data** (`did:web:ourworldindata.org`) — chart
    metadata lookup over the public Grapher JSON API, with graceful
    fallback to `[]` when no candidate slug matches. TIER_1,
    `GOVT_OPEN_DATA`. Disable with `GTV_OWID_DISABLE=1`.
- **LlamaIndex binding** (`gtv.bindings.llamaindex`). Drop-in
  `GtvFunctionTool.from_defaults()` that a LlamaIndex agent can hand
  to its `FunctionAgent` / `ReActAgent`. Zero hard dep on llama-index
  — duck-typed, so importing `gtv.bindings.llamaindex` never pulls
  llama-index into the main process. Env defaults: `GTV_BASE_URL`
  (default `http://localhost:8080`), `GTV_API_KEY`. Also exposes a
  free `verify_claim()` coroutine for composition into custom tool
  pipelines. Covered by 13 new tests.
- **LangChain binding** (`gtv.bindings.langchain`). `GtvVerifyTool`
  is a duck-typed `BaseTool` — works with `initialize_agent`,
  `AgentExecutor`, and the modern `create_tool_calling_agent` path.
  Same env defaults as the LlamaIndex binding. Sync `_run` and async
  `_arun` both call the gtv HTTP API with the standard Bearer
  header. 14 new tests.
- **`gtv-replay` operator CLI** (`gtv-replay <verification-id>`).
  Re-runs a prior `VerifyResponse` from the audit log against the
  current adapter registry and diffs the verdict + per-evidence
  deltas. Exit code 0 on identical re-run, 1 on drift. Wired as a
  `[project.scripts]` entry so ops can `pipx install gtv && gtv-replay
  V-20260422-abc`. 10 tests (stdlib-only; no external deps).
- **LearnedRanker** (`gtv.verdict.ranker`). Pure-stdlib logistic
  regression over evidence features (tier, recency, citations,
  cross-source agreement). Implements `score() / predict_proba() /
  decide() / fit()` so offline-trained weights can be hot-loaded at
  startup without pulling sklearn into the hot path. Default weights
  ship zero-effect so enabling the ranker is a no-op until trained.
  13 tests.
- **WHO Global Health Observatory adapter**
  (`did:web:who.int`). Official WHO indicator data via the GHO OData
  endpoint, with a cached indicator catalogue for fuzzy keyword →
  indicator-code resolution. No key. TIER_1, source-type
  `GOVT_OPEN_DATA`. Disable with `GTV_WHO_GHO_DISABLE=1`. 10 tests.
- **Europe PMC adapter** (`did:web:europepmc.org`). Peer-reviewed
  life-sciences literature via the public search REST API. No key.
  TIER_1, source-type `PEER_REVIEWED`. Complements the CORE preprint
  aggregator for biomed claims. Disable with `GTV_EUROPEPMC_DISABLE=1`.
  9 tests.
- **Two more 1.1 evidence adapters** — second half of the W42
  adapter-expansion wave:
  - **OpenFDA** (`did:web:open.fda.gov`) — adverse-event reports,
    recalls, and drug-label queries via the FDA's public OpenFDA
    REST API. Honours `OPENFDA_API_KEY` for the 240 req/min auth'd
    rate limit; works without a key at 40 req/min. TIER_1. Disable
    with `GTV_OPENFDA_DISABLE=1`.
  - **CORE** (`did:web:core.ac.uk`) — global research-paper aggregator
    (200M+ open-access works). Requires `CORE_API_KEY`; gracefully
    degrades to returning `[]` and a `HEALTHY` probe saying "no key"
    when absent, so startup never blows up. TIER_2, source-type
    `PREPRINT`. Disable with `GTV_CORE_DISABLE=1`.
- **Two new 1.1 evidence adapters.** First half of the W42 adapter
  expansion (OpenFDA + CORE will land in W43):
  - **DailyMed** (`did:web:dailymed.nlm.nih.gov`) — FDA-approved drug
    labels via the NLM v2 public API. No key. TIER_1, source-type
    `GOVT_OPEN_DATA`. Disable with `GTV_DAILYMED_DISABLE=1`.
  - **GitHub Security Advisories** (`did:web:github.com`) — curated
    vuln database via the public `/advisories` REST endpoint.
    Auto-detects `CVE-XXXX-YYYY` and `GHSA-xxxx-yyyy-zzzz` ids in the
    claim text for precise lookups; falls back to `affects=<package>`
    keyword search. Honours `GITHUB_TOKEN` / `GTV_GITHUB_TOKEN` for
    the 5000/hr auth'd rate limit. TIER_1. Disable with
    `GTV_GHSA_DISABLE=1`.
- **Per-adapter disable env vars.** The runbook pattern from
  `docs/slos.md` (`GTV_ARXIV_DISABLE=1` etc.) is now actually wired
  through `gtv.adapters.__init__._enabled()`, covering all ten
  default adapters. Previously ops had to use the blanket
  `GTV_DISABLE_DEFAULT_ADAPTERS=1` or restart.
- **1.0 launch deck** (`docs/launch/gtv-launch-1.0.pptx`). Nine-slide
  Midnight Executive deck for buyer conversations: problem → solution
  → how it works → what's in 1.0 → what's new → why us → roadmap →
  pilot offer. Regenerable from `build_deck.js`. Replaces the 0.1 pitch
  deck.
- **SLO-driven auto-remediation (circuit breaker).** Each registered
  adapter can now be wrapped in a rolling-window failure tracker;
  when the failure ratio crosses the configured threshold the
  breaker trips OPEN, short-circuits calls, and auto-probes back to
  CLOSED after a cool-down. This keeps one sick upstream from
  dominating verify p95. Opt in with `GTV_CB_ENABLED=1`. State is
  exported as the Prometheus gauge `gtv_circuit_state` for alerting.
  See the runbook entry in `docs/slos.md`.
- **Consensus policy DSL v2.** Three new levers the v1 formula
  couldn't express:
  `max_evidence_age_days` (stale evidence is dropped before counting),
  `require_recent_support_days` (at least one support must land inside
  a recency window), and `min_distinct_tiers_for_verified` (supports
  must span ≥ N TrustTiers, not just N DIDs). All three default to
  `null` / not-enforced, so v1 policy YAML stays valid. Per-domain
  overrides fall through to globals the same way the v1 fields do.
  See `docs/policy.md` for the migration path.
- **Adapter SDK** (`gtv.adapters.sdk`). Third-party packages can now
  ship a `SourceAdapter` out-of-tree and declare a `gtv.adapters`
  entry point — gtv discovers and registers it at startup. A
  `gtv.adapters.conformance` test suite pins the contract, and
  failures in individual plugins are logged, never crashed. Operator
  env vars: `GTV_DISABLE_PLUGIN_ADAPTERS`, `GTV_PLUGIN_ADAPTER_ALLOWLIST`.
  See `docs/adapter-sdk.md` and `examples/adapters/example_external/`.
- `gtv-lifecycle` operator CLI wrapping the W28 supersede DAG endpoints
  (`history`, `latest`, `supersede`). Before this, investigating a
  retraction chain meant curling `/claims/{id}/history` and reading JSON
  by hand. Text + `--json` output, `GTV_BASE_URL` / `GTV_API_KEY` env
  vars, full test coverage including a FastAPI TestClient integration.
- **Claim-content cache** (`gtv.claim_cache`). Distinct from the
  verdict cache and the adapter-result cache: this one normalises
  text (lowercase, strip punct, drop stopwords, sort tokens) +
  domain to a canonical form, then hashes to a stable 16-char
  claim_id. Different phrasings of the same content collapse to
  one id, which both upstream caches can share as their key.
  LRU-evicted `OrderedDict`, pure stdlib, no TTL.
- **Adapter horizontal sharding** (`gtv.adapters.sharding`).
  Consistent-hash routing so an N-worker cluster holds ~N upstream
  connections per adapter instead of N×M. `shard_for_claim()` is
  deterministic across workers; `ShardedAdapter` decorator
  forwards non-owned pairs to the owning worker via
  `POST /internal/adapter/{source_did}/query`, falling back to
  local on forward failure so a peer outage never blocks verify.
  Env: `GTV_TOTAL_SHARDS`, `GTV_SHARD_ID`, `GTV_SHARD_PEERS`.

## [1.0.0] - 2026-04-21

First stable release. The 0.1.0 pilot proved the core idea — signed
verdicts over federated evidence — and 1.0.0 is the operations pass:
everything a multi-tenant operator needs to run gtv as a service.
Envelopes signed under 0.1.x still verify byte-for-byte; the canonical
hash strips lifecycle fields at their defaults for exactly this reason.

Highlights:

- **Revisable verdicts.** `supersede_claim` + `GET /claims/.../history`
  + `GET /claims/latest` make a verdict a first-class, amendable object
  with enforced same-issuer continuity.
- **Safety.** PII redaction before sealing, input-side 400 for PII-
  bearing claims, signed-cache re-verification on every read.
- **Operator surface.** Multi-tenant isolation keyed by issuer DID,
  per-tenant billing with a durable SQLite aggregate, reference
  Prometheus + Grafana bundle with SLOs, federated consensus over a
  configurable peer set, SSE streaming for `verify_claim`, and a
  YAML-configurable consensus policy.
- **Contract stability.** Public OpenAPI + JSON Schema artifacts are
  generated from the code and drift-gated in CI.

### Added

- **Reference observability bundle + SLOs** (`deploy/observability/`,
  W35) — the operator-facing counterpart to the metrics we already
  emit from `gtv.obs.metrics`. Ships a Grafana dashboard
  (`grafana/dashboards/gtv-overview.json`) with four rows — top-line
  SLIs, adapters, tenants, redaction/PII — and a Prometheus bundle
  with recording rules for the three SLIs
  (`gtv:adapter_availability:ratio_rate{5m,30d}`,
  `gtv:verify_latency:ratio_under_budget_rate5m`,
  `gtv:cache:hit_ratio_rate5m`) plus alerts for the three SLOs:
  signature integrity (P0, fires on any `signature_mismatch`),
  adapter availability (warning, 99.5% over 30d), and `verify_claim`
  latency (warning, 95% of requests ≤ 5s over any 5m). A reference
  `docker compose up` brings up Prometheus (with rules loaded) and
  Grafana (dashboard auto-provisioned via the datasources/dashboards
  provisioning files) against a gtv scrape target. New doc
  `docs/slos.md` covers the policy: which SLIs, why these three, and
  the runbook each alert links to. A `test_observability_bundle.py`
  test suite parses the JSON + YAML and fails CI if a dashboard
  panel or alert expression references a metric or recording rule
  that doesn't exist in the code — drift between the metric surface
  and the observability bundle is now a build-time error.
- **Per-tenant billing/metering** (`gtv.billing`, W34) — operators
  running gtv as a multi-tenant service now have a durable, queryable
  record of each tenant's usage, decoupled from the Prometheus
  counters (which are for "is the system healthy?", not source-of-
  truth for invoicing). New SQLite-backed store at the path in
  `GTV_BILLING_DB` (if unset, defaults to `:memory:` — billing is
  opt-in). The table `usage_daily` is aggregated to
  `(tenant_id, issuer_did, tool, day)` via
  `INSERT … ON CONFLICT DO UPDATE SET count = count + ?`, so per-
  request writes touch exactly one row per bucket and storage stays
  bounded regardless of traffic. The request-side hook is a single
  `record_usage(...)` call per billable handler in `gtv.mcp.server`
  (`verify_claim`, `verify_claim/stream`, `retrieve_facts`,
  `supersede_claim`). `record_usage` is defensive — any store
  exception is logged and swallowed so that losing a billing tick
  never breaks a `verify_claim` response; operators cross-check
  against the existing `gtv_tenant_requests_total` counter. New CLI
  `gtv-usage` ships two subcommands: `report` (per-bucket rows with
  `--tenant`/`--tool`/`--since`/`--until` filters and
  `--format table|csv|json`) and `totals` (sum per tenant in a
  window, used for monthly invoicing). Both exit cleanly with "No
  usage recorded" if `GTV_BILLING_DB` is unset or points at a
  missing file — unconfigured operators aren't treated as an error.
- **SSE streaming for `verify_claim`** (`gtv.mcp.stream`, W33) — a single
  `verify_claim` call can take seconds when fanning out to multiple
  adapters, and the JSON endpoint blocks the caller until the envelope
  is sealed. New endpoint `POST /tools/verify_claim/stream` emits
  Server-Sent Events as each phase completes: `claim_accepted`
  (request admitted, classification known) → `evidence` (one event per
  adapter, in completion order via `asyncio.as_completed`) → `verdict`
  (engine decision before signing) → `envelope` (sealed envelope;
  stream closes). Cache hits collapse to two events
  (`claim_accepted` + `envelope`). The streaming and JSON endpoints
  share the same verdict cache and lifecycle DAG — a cold streaming
  call populates the cache for subsequent JSON callers and vice versa.
  Pipeline source of truth moved to the new `_verify_one_events`
  async generator; `_verify_one` is now a thin wrapper that drains
  the generator and returns the terminal envelope, so streaming and
  non-streaming paths cannot drift. PII and missing-adapter gates
  fire as 400/503 *before* the stream opens, distinguishing input
  errors from mid-stream failures. Headers set `Cache-Control:
  no-cache` and `X-Accel-Buffering: no` so intermediaries don't
  defeat the streaming benefit.
- **Reference federation deployment** (`gtv.federation.peer`, W32) — one
  gtv instance can now fan a claim out to configured peers and return a
  tier-weighted consensus in a single HTTP round trip. New endpoint:
  `POST /federation/consensus`. New env var: `GTV_FEDERATION_PEERS`
  (comma-separated `did|url|api_key` entries). The response lists
  `contributing_dids` and `failed_dids` so operators can alert on
  partial outages. `compute_consensus` gained an
  `enforce_same_claim_id` flag (default True for backward compat) that
  the federation path sets False — two peers independently verifying the
  same claim text will always mint different claim_ids, and the
  fan-out itself guarantees same-text. The reference two-instance
  topology ships under `deploy/federation/` with a README, compose
  file, and a shared `trust-registry.json`; a docker-compose smoke
  test is gated behind `GTV_FEDERATION_E2E=1` for release/nightly CI.
- **Multi-tenant isolation** (`gtv.tenant`, W31) — one server process can
  now host multiple independent tenants, each signing under its own
  issuer DID. The key insight: the verdict cache and lifecycle DAG are
  already keyed by issuer DID, so multi-tenancy reduces to "make each
  tenant sign under a distinct DID." API keys carry two new columns:
  `tenant_id` (free-form label for metrics/audit) and
  `issuer_did_override` (DID the envelope is signed under; blank =
  inherit from `GTV_ISSUER_DID`). The auth middleware attaches a
  `Tenant` to `request.state`, and every MCP handler resolves it
  through `gtv.tenant.resolve_tenant(request)` before sealing or
  looking up cache entries. Cross-tenant `supersede_claim` is rejected
  with 403; `claims_latest` is scoped to the caller's tenant by
  default (explicit `issuer_did=` still works). Legacy keystores are
  auto-migrated in place (`ALTER TABLE ADD COLUMN`). The
  `gtv-admin-keys create` command gained `--tenant` and `--issuer-did`
  flags. A new bounded-cardinality counter
  `gtv_tenant_requests_total{tenant_id,tool,verdict}` makes
  per-tenant usage observable without exploding labels on the
  existing verdict/cache metrics. See `docs/multi-tenant.md`.
- **Consensus policy DSL** (`gtv.policy`) — the verdict engine's
  source-count thresholds, tier weights, and confidence-formula
  constants are now declared in a YAML file that operators can edit
  without recompiling. Top-level fields: `min_supports_for_verified`,
  `min_refutes_for_negation`, `tier_weights.{tier_1,tier_2,tier_3}`,
  `confidence.{base,per_source,per_tier_bonus,age_penalty,age_horizon_months}`.
  Per-domain overrides live under `domains.<domain>:`. Unknown domain
  keys are rejected at load time (no silent typos). Loaded from
  `GTV_POLICY_PATH`; unset = the built-in `DEFAULT_POLICY` which
  matches the legacy hardcoded constants byte-for-byte, so callers
  that don't opt in see identical behavior. The engine is a pure
  function: `decide(inputs, policy)`.
- **PII redaction before sealing** (`gtv.redact`) — signed envelopes are
  public, replicated, and in practice unrevokable, so any PII that
  leaks into one is permanent. The redactor scrubs adapter-returned
  evidence excerpts and LLM-generated rationale BEFORE
  `_seal_envelope`, so the canonical hash covers the already-scrubbed
  text. Built-in rules: email, US SSN, Luhn-validated credit card,
  IPv4, E.164 / NANP phone, IBAN, AWS access-key IDs, GitHub PATs,
  Slack tokens, JWT, and `Bearer` headers. Typed replacement tokens
  (`[REDACTED:EMAIL]`, `[REDACTED:SSN]`, …) so downstream systems can
  reason about what was removed without ever seeing raw values.
  Claims submitted to `/tools/verify_claim` or `/tools/supersede_claim`
  containing PII are 400'd at ingress (silent redaction would break
  caching and mislead callers). Configurable via `GTV_REDACT_ENABLED`
  (dev-only off-switch; input-side rejection stays on regardless) and
  `GTV_REDACT_EXTRA_PATTERNS` (semicolon-separated `KIND=regex` list
  for site-specific rules). Prometheus metrics:
  `gtv_redactions_total{kind}`, `gtv_redactions_rejected_total`.
- **Claim lifecycle: amend / supersede / withdraw** (`gtv.lifecycle`) —
  verdicts are now first-class, revisable objects. Envelopes gained two
  fields: `supersedes: list[str]` (parent envelope IDs) and
  `supersede_reason: SupersedeReason | None` (`AMEND`, `SUPERSEDE`,
  `WITHDRAW`). A `LifecycleIndex` (in-memory or SQLite via
  `GTV_LIFECYCLE_DB`) tracks the append-only DAG and enforces same-issuer
  continuity, no self-supersede, no unknown parents, and no cycles. New
  MCP tool `supersede_claim` (mints a successor envelope linked to the
  parent and invalidates the parent's cache entry). New HTTP routes
  `GET /claims/{envelope_id}/history` (walks back to the root) and
  `GET /claims/latest?claim=&domain=&issuer_did=` (returns the head for a
  claim, picking the longest branch on a fork). Canonical hashing stays
  backward-compatible: when the lifecycle fields are at their defaults
  they are stripped before hashing, so v0.1.0-signed envelopes still
  verify. Metric: `gtv_cache_invalidations_total{reason="superseded"}`.
- **Signed verdict cache** (`gtv.cache`) — zero-trust in-process verdict
  cache for `verify_claim`. On every read, the cached envelope's
  signature is re-verified against a freshly-computed canonical hash; a
  tampered or corrupt entry is evicted and the request falls through to
  a fresh verification. Cache keys are NFKC-normalized (claim text
  casefolded, whitespace collapsed) and scoped by `(claim, domain,
  max_sources, issuer_did)`. TTL = `min(adapter freshness SLAs)`
  clamped by `GTV_CACHE_TTL_MIN_S` / `GTV_CACHE_TTL_MAX_S`. Backends:
  `InMemoryCacheStore` (default), `RedisCacheStore` (set
  `GTV_CACHE_REDIS_URL`), `NullCacheStore` (set `GTV_CACHE_ENABLED=0`).
  Prometheus metrics: `gtv_cache_hits_total`, `gtv_cache_misses_total`,
  `gtv_cache_invalidations_total{reason}` (signature_mismatch,
  deserialize_error, revoked). Verifier emits byte-identical envelopes
  on cache hits.
- **Getting-started tutorial notebook** (`notebooks/getting_started.ipynb`)
  — register a stub adapter, post a claim to the in-process FastAPI
  verifier via `TestClient`, inspect the signed envelope, verify it
  offline with `gtv-verify --allow-stub`, and see the OpenAI tool spec.
  Runs fully in-process (no network, no external Sigstore/TSA) so it's
  safe in CI. Guardrailed by `tests/test_notebook.py` (nbclient,
  60 s per-cell timeout) to prevent bitrot as the API evolves.
- **Agent-framework bindings** (`gtv.bindings`) — drop-in tool specs
  for OpenAI function calling, Anthropic tool use, and LangChain
  (`StructuredTool` factory, lazy-imports `langchain-core`). Shares
  one thin async `GtvClient` for transport. Runnable demos in
  `examples/openai_agent.py`, `examples/anthropic_agent.py`,
  `examples/langchain_agent.py`. See `docs/bindings.md`. Anthropic
  MCP stdio was already shipped in 0.1.0 as `gtv-mcp`.
- **Public schema exporter** (`gtv-export-schemas`) — freezes the
  public contract as OpenAPI 3.1 (`spec/openapi.gen.json`) and
  per-model JSON Schema (`spec/schemas/<Model>.gen.json`). A
  `schema-drift` CI job runs `gtv-export-schemas check` on every PR
  and fails the build if a pydantic model or FastAPI route changed
  without a regenerated artifact. See `docs/api-http.md`.
- **Rekor consistency-proof verifier** (`gtv-rekor-check`) — pin a Rekor
  checkpoint, then later prove the log wasn't forked or rewritten. RFC
  6962 §2.1.4.2 algorithm. Supports live (`pin`, `verify`) and offline
  (`verify-offline`) modes. Detects truncation, rewrite-at-same-size, and
  fork-within-pinned-prefix attacks. See `docs/security.md`.
- **Performance regression suite** — opt-in via `GTV_PERF=1`. Covers
  canonical-hash, verdict engine, and end-to-end `verify_claim` stub
  path. SLO targets documented in `docs/deployment.md`.
- **Load harness** (`scripts/load_harness.py`) — dependency-light async
  httpx-based sustained-load tool with p50/p95/p99 reporting.
- **Continuous security pipeline** (`.github/workflows/security.yml`) —
  `pip-audit`, `gitleaks`, `trivy fs`, `trivy image`, CycloneDX SBOM with
  Cosign keyless signing. Runs on every PR, push to main, and weekly.
- **`CODEOWNERS`** requiring security-team review for all
  signing/anchoring/auth/CI paths.
- **Dependabot** config for pip, GitHub Actions, and Docker.
- **Pre-commit hooks** (`.pre-commit-config.yaml`) and local security-gate
  runner (`scripts/security_gate.sh`).

## [0.1.0] - 2026-04-21

First public pilot release. MCP-native federated fact-verifier with
cryptographic provenance on every verdict.

### Added

- **MCP surface** — FastAPI HTTP server and JSON-RPC stdio transport
  exposing `verify_claim`, `retrieve_facts`, `consensus`.
- **Cryptographic provenance** — Sigstore keyless OIDC signing, Rekor
  transparency-log anchoring, RFC 3161 dual-TSA timestamps (primary +
  secondary fallback).
- **BYOK signing** — Ed25519, ECDSA P-256, secp256k1 via `did:key`
  self-describing multicodec identifiers.
- **Evidence adapters** (8 total) — arXiv, INSPIRE-HEP, Crossref,
  OpenAlex, Semantic Scholar, PubMed, NIST, Retraction Watch.
- **Federated consensus** — tier-weighted aggregation (T1=3×, T2=2×,
  T3=1×, unknown=0.1×) across independent verifiers, emitted as a
  signed `AggregateEnvelope` with input refs and canonical hash.
- **Authentication** — API-key auth (bearer token) with per-key
  sliding-window rate limiting. Two sources: SQLite-backed keystore
  (`gtv-admin-keys`) or `GTV_API_KEYS` env-var fallback.
- **Subscriptions** — webhook delivery on verdict change, with
  optional BYOK-signed payloads (Ed25519) and SQLite persistence.
- **Revocation** — signed revocation lists (per-issuer JSON) loaded at
  startup; revoked envelopes return `410 Gone` on verify. Managed via
  `gtv-revoke`.
- **Persistent federation trust registry** — SQLite-backed issuer
  store (tiers, revocation, notes) managed via `gtv-federation`, with
  a signed `RegistryUpdate` log for admin changes.
- **Append-only audit log** — hash-chained, optionally Ed25519-signed
  trail of admin-CLI actions. Managed via `gtv-audit` (tail / verify /
  get / export / append).
- **Observability** — Prometheus metrics (`/metrics`), structured
  JSON logging via `structlog`, OpenTelemetry OTLP export.
- **Deployment** — Distroless Python 3.12 Docker image published to
  ghcr.io, multi-arch (amd64/arm64), Cosign keyless-signed, SBOM
  (SPDX) attached and signed. 15-minute docker-compose deploy.
- **CI/CD** — GitHub Actions: lint (ruff), types (mypy strict), tests
  (pytest + coverage), nightly live integration against staging
  Sigstore / staging Rekor / freetsa.org, Grype container scan,
  schema validation.
- **CLIs** — `gtv-verify`, `gtv-mcp`, `gtv-demo`, `gtv-sign-byok`,
  `gtv-subscribe`, `gtv-admin-keys`, `gtv-revoke`, `gtv-federation`,
  `gtv-audit`.
- **Canonicalization** — RFC 8785 JSON Canonicalization Scheme (JCS)
  for deterministic hashing of envelopes and aggregates.
- **DID methods** — `did:web` resolver and `did:key` (Ed25519, P-256,
  secp256k1 multicodec via base58btc).

### Quality gates

- 757 tests passing, 20 skipped (live/opt-in), 0 failing.
- ruff clean on all source and tests.
- mypy strict clean across 73 source files.

[Unreleased]: https://github.com/groundtruth/gtv/compare/v0.1.0...HEAD
[0.1.0]: https://github.com/groundtruth/gtv/releases/tag/v0.1.0
