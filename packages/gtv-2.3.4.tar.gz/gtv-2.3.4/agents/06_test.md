# Agent 06 — Test

**Read `agents/00_overview.md` first. The seven rules apply to you too.**

## Mission

Be the adversary. Every other agent is trying to ship features; you're trying to break them, prove them, and pin them down so they can't regress silently. Coverage isn't the goal — *confidence to ship* is the goal.

## What done looks like (Phase 1)

1. Test coverage ≥85% across `src/gtv/` (reported by pytest-cov in CI, fails the build below threshold).
2. Property-based tests (via `hypothesis`) covering: canonicalization stability, confidence bounds, adapter input/output invariants, envelope round-trip.
3. End-to-end test: spin up the FastAPI app with a fake adapter, POST a claim, verify the returned envelope passes `gtv-verify`. Runs in every CI.
4. Golden envelope fixtures in `tests/fixtures/envelopes/` — 10+ hand-reviewed envelopes covering all six verdict types. Any PR that changes their hashes must justify it.
5. Adversarial claim battery — `tests/adversarial/` — 30+ claims chosen to break specific parts of the pipeline (injection, oversize, non-UTF-8, contradictory evidence, stale dates, blocked sources). All pass or fail with expected verdicts.
6. Live source smoke test — nightly GitHub Action that hits live arXiv/INSPIRE/Crossref, asserts we still parse what they return.

## Week-by-week

- **W1 [DONE by scaffold]:** 18 baseline tests green.
- **W2:** Property tests for canonicalize + confidence. Hypothesis strategies defined in `tests/strategies.py`.
- **W3:** End-to-end test with in-process FastAPI client + fake adapter. Signed envelope → `gtv-verify` passes.
- **W4:** Golden envelopes + adversarial battery.
- **W5:** Mutation testing (`mutmut`) on `verdict/engine.py` — score ≥75%. If a surviving mutant shows a gap, write the test.
- **W6:** Load test in CI — `locust` at 10 RPS for 1 minute against the docker image, P95 ≤10s, zero 5xx.
- **W7:** Chaos test — kill Rekor, kill one TSA, kill one adapter; assert graceful degradation matches docs.

## Files you own

- `tests/**` — except per-agent unit tests in their domains (which they maintain, but you audit).
- `tests/conftest.py` — shared fixtures, live-test gate.
- `tests/strategies.py` — hypothesis strategies.
- `tests/fixtures/` — golden envelopes, sample claims, cassettes (VCR-style for adapter tests if you add them).
- `tests/adversarial/` — adversarial claim battery.
- `tests/load/` — load test scenarios.
- `docs/testing.md` — how-to-run, how-to-add.

## Files you do NOT touch

- Anything under `src/gtv/` without the owning agent's PR. You write tests against their code; you don't rewrite it.

## Concrete first task (W2)

Ship property tests for `anchor/canonicalize.py`. This module is the foundation — if it's wrong, every envelope ever produced is wrong retroactively.

Create `tests/test_canonicalize_properties.py`:

```python
from hypothesis import given, strategies as st
from gtv.anchor.canonicalize import canonicalize, sha256

# Strategy: arbitrary JSON-compatible dicts with string keys.
json_value = st.recursive(
    st.one_of(st.none(), st.booleans(), st.integers(min_value=-2**53, max_value=2**53),
              st.text(min_size=0, max_size=100)),
    lambda children: st.one_of(
        st.lists(children, max_size=5),
        st.dictionaries(st.text(min_size=1, max_size=20), children, max_size=5),
    ),
    max_leaves=20,
)

@given(json_value)
def test_canonicalize_is_deterministic(v):
    assert canonicalize(v) == canonicalize(v)

@given(json_value)
def test_canonicalize_is_stable_under_dict_reordering(v):
    # If we shuffle dict key order via dict(sorted(...)) the output must be identical.
    def shuffle(x):
        if isinstance(x, dict):
            return {k: shuffle(v) for k, v in sorted(x.items(), reverse=True)}
        if isinstance(x, list):
            return [shuffle(e) for e in x]
        return x
    assert canonicalize(v) == canonicalize(shuffle(v))

@given(json_value)
def test_sha256_is_deterministic(v):
    assert sha256(canonicalize(v)) == sha256(canonicalize(v))
```

Run with `pytest tests/test_canonicalize_properties.py --hypothesis-profile=ci`. Add a `ci` profile in `conftest.py` that caps examples at 200 to keep CI under 30s for this file.

## Do NOT

- Trust coverage %. 100% coverage with no assertions is 0% confidence.
- Mock what you're testing. Don't mock `decide()` when testing `decide()`. Mock the I/O boundary, nothing deeper.
- Write flaky tests. A test that fails 1% of the time is a test that will fail the day before launch. Quarantine flakes to a separate suite within 24h; fix within 72h.
- Use real network calls in the default test suite. Live calls go behind `@pytest.mark.live` and run nightly only.
- Let a failing test live. If a test is red on main for >2h, either fix it or delete it and write an issue. No skipped-then-forgotten tests.

## Success signal

A new contributor clones the repo, runs `pytest`, everything passes in under 30 seconds. They make a one-line change to `verdict/engine.py`, run `pytest`, and at least one test fails pointing at the exact behaviour they changed.
