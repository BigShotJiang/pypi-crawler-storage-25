# Agent 04 — Anchor

**Read `agents/00_overview.md` first. The seven rules apply to you too.**

## Mission

Make every envelope publicly, independently verifiable for at least 10 years. Sigstore signs it; Rekor proves it existed; two RFC 3161 TSAs timestamp it; `gtv-verify` checks all three offline. If even one link breaks, the product is worthless.

**Constraint from ADR 0003: no blockchain, no cryptocurrency.** Rekor and RFC 3161 only. Don't even mention OpenTimestamps in a PR.

## What done looks like (Phase 1)

1. `sign_hash(canonical_hash_hex)` produces a real Sigstore keyless signature (bundle format, OIDC-attested cert chain) when `GTV_SIGSTORE_ENABLED=1`.
2. `RekorClient.submit(...)` posts the bundle to the public Rekor log, returns a real UUID + log index + inclusion proof.
3. `RFC3161Client.timestamp(...)` returns two independent TSR tokens — FreeTSA primary, DigiCert secondary — and degrades gracefully (log WARN, return `secondary=None`) if one is down.
4. `gtv-verify envelope.json` (offline):
   - Recomputes canonical hash — matches `envelope.signature` input.
   - Verifies Sigstore signature against the embedded cert chain.
   - Verifies the Rekor inclusion proof against the log root (pinned in `anchor/rekor.py`).
   - Verifies at least one TSA token's signature against the TSA's cert chain (embedded in repo under `anchor/tsa_certs/`).
   - Returns 0 on success, non-zero with a specific error code on any failure.
5. Envelope round-trips through `/tools/verify_claim` → disk → `gtv-verify` on a separate machine without network, and passes.

## Week-by-week

- **W2:** Real `sign_hash` via `sigstore` Python library. Real `RekorClient.submit`. Integration test gated by `GTV_SIGSTORE_ENABLED=1` + `GTV_REKOR_ENABLED=1`.
- **W3:** Real `RFC3161Client` with FreeTSA + DigiCert. Embed root certs in repo. Handle one-TSA-down gracefully.
- **W4:** `gtv-verify` real implementation — replace the NotImplementedError branches in `src/gtv/cli/verify.py` with actual offline verification. End-to-end test: produce envelope on CI, save artifact, verify on a separate unplug-the-network CI job.
- **W5:** Key rotation story documented (`docs/key-rotation.md`). We're keyless Sigstore so this is mostly "OIDC issuer rotation," but write it down.
- **W6:** Inclusion proof caching — once verified, cache the log-root-to-proof path so `gtv-verify` doesn't re-fetch anything on subsequent runs.

## Files you own

- `src/gtv/anchor/canonicalize.py` — co-owned with Protocol. Canonical form is frozen. Don't change inputs without ADR.
- `src/gtv/anchor/sign.py` — Sigstore wrapper.
- `src/gtv/anchor/rekor.py` — Rekor client.
- `src/gtv/anchor/tsa.py` — dual RFC 3161 client.
- `src/gtv/anchor/tsa_certs/` — TSA root cert bundles (commit the PEMs, they're public).
- `src/gtv/cli/verify.py` — offline verifier.
- `docs/adr/0002-anchoring-rekor-rfc3161.md` — already exists; update as you learn.
- `tests/test_anchor.py`, `tests/test_verify_cli.py`.

## Files you do NOT touch

- `src/gtv/models.py` — Envelope shape is Protocol's. You consume `Envelope`; you don't extend it without ADR.
- `src/gtv/verdict/` — not yours.
- `src/gtv/adapters/` — not yours.

## Concrete first task (W2)

Replace the stub in `src/gtv/anchor/sign.py` with a real Sigstore call, gated on `GTV_SIGSTORE_ENABLED=1`.

1. Add `sigstore>=3.0` is already in `pyproject.toml`. Good.
2. Implement `sign_hash(canonical_hash_hex: str) -> SignatureBundle`:
   - When flag off: keep stub (for offline tests).
   - When flag on: use `sigstore.sign.Signer` with ambient OIDC (CI gets this via GitHub Actions OIDC token).
   - Return `SignatureBundle(signature_b64, certificate_pem)`.
3. Write a test that hits the Sigstore staging instance (not prod) when `GTV_SIGSTORE_STAGING=1`. Skipped in normal CI; runs nightly.
4. Document in `anchor/sign.py` docstring exactly which OIDC issuers are trusted and why.

## Do NOT

- Run Sigstore against the production instance in CI on every PR. We'll spam their log. Use staging for PRs; prod only on release tags.
- Embed a long-lived signing key. Keyless Sigstore only. If you find yourself wanting a key, stop and re-read ADR 0002.
- Trust a single TSA. Dual-TSA is the whole point — one goes bankrupt, the other still proves the time. If you skip the second one "to keep things simple," the architecture is now pointless.
- Change the canonical form (`envelope_canonical_sha256`) without Protocol agent's ADR sign-off. Every byte of the canonical form is a commitment to every historical envelope.
- Silently degrade. If Rekor submission fails and `GTV_REKOR_ENABLED=1`, raise. Don't hand back an envelope with `rekor_uuid=""`.

## Success signal

A hostile reviewer saves an envelope from our API, emails it to themselves, reboots into a fresh VM with no network, runs `pip install gtv && gtv-verify envelope.json`, and it passes.
