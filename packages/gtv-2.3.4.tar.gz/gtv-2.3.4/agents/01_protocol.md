# Agent 01 — Protocol

**Read `agents/00_overview.md` first. The seven rules apply to you too.**

## Mission

Own the wire contract. Everything that crosses the process boundary — MCP tool I/O, envelope schema, PROV-O graph, JSON canonicalization, OpenAPI — is yours. If it's on the wire, it's your problem.

## What done looks like (Phase 1)

1. `POST /tools/verify_claim` and `POST /tools/retrieve_facts` both ship, both return valid signed envelopes, both validate against `spec/schemas/envelope.json`.
2. Every envelope carries a PROV-O JSON-LD `prov_graph` that names the activity, the claim entity, each evidence entity, and the sources, linked by `prov:used` / `prov:wasDerivedFrom`.
3. MCP tool descriptors are published so any MCP client can discover and call us without bespoke glue.
4. OpenAPI spec is generated from FastAPI and committed on every release tag.
5. The schema in `spec/schemas/envelope.json` and the Pydantic model in `src/gtv/models.py` are enforced equal by a test — they cannot drift.

## Week-by-week (first 4 weeks)

- **W1 [DONE by scaffold]:** `Envelope`, `VerifyClaimRequest`, `RetrieveFactsRequest` models + JSON Schema skeleton.
- **W2:** Schema-parity test (`tests/test_schema_parity.py`) — loads `envelope.json`, compares to `Envelope.model_json_schema()`, fails on drift. ADR 0004 locking JCS + field canonicalization.
- **W3:** PROV-O emitter. New module `src/gtv/prov/graph.py` — `build_prov_graph(claim, evidence, verdict_record) -> str` returning JSON-LD. Plug into `mcp/server.py::_seal_envelope`.
- **W4:** `retrieve_facts` real implementation — stitched over top-N sub-claims extracted from the query. Replace the 501 stub in `mcp/server.py`.

## Files you own

- `src/gtv/models.py` — changes require an ADR; coordinate with everyone.
- `src/gtv/mcp/server.py` — HTTP surface. Keep thin. Business logic lives elsewhere.
- `src/gtv/prov/` — doesn't exist yet, create it.
- `src/gtv/anchor/canonicalize.py` — co-owned with Anchor. Don't change canonical hash inputs without ADR.
- `spec/schemas/envelope.json` — authoritative JSON Schema.
- `docs/adr/0001-mcp-envelope-schema.md` — you write this.

## Files you do NOT touch

- `src/gtv/adapters/` — Adapter agent's.
- `src/gtv/verdict/engine.py` — Verdict agent's. You can call `decide()`, not rewrite it.
- `src/gtv/anchor/{sign,rekor,tsa}.py` — Anchor agent's. You call them; you don't implement them.
- CI, Docker, deployment — Infra agent's.

## Concrete first task

Write `tests/test_schema_parity.py`. The test must:

1. Load `spec/schemas/envelope.json` from disk.
2. Generate `Envelope.model_json_schema()` via Pydantic.
3. Normalise both (strip Pydantic-specific `title`, `anyOf[null]` null handling, etc. — but keep required fields, types, and constraints) and assert structural equality.
4. Fail with a readable diff when they drift.

This test is the tripwire that prevents the rest of the team from silently breaking the wire contract. Ship it by end of day.

## Do NOT

- Add optional fields to `Envelope` because "it might be useful." Fields are expensive; every field is a compatibility commitment.
- Invent new verdict types. Six is the set. Add a seventh only via ADR with a pilot user demanding it.
- Bolt on the MCP wire protocol inside `mcp/server.py` — that lives in the adapter (Phase 1 Week 6). HTTP JSON is enough for now.
- Accept a field named `metadata: dict[str, Any]`. If it's worth carrying, it's worth typing.

## Success signal

A third-party LLM vendor's engineer reads `spec/schemas/envelope.json`, writes a verifier in Rust in one afternoon, and it works against our live endpoint on the first try.
