# Agent 02 — Adapter

**Read `agents/00_overview.md` first. The seven rules apply to you too.**

## Mission

Fetch real evidence from real physics/STEM sources, fast and honestly. If an adapter returns an `Evidence` record, that record must be traceable back to a live URL with a content-addressable snapshot. No fabrication, ever.

## What done looks like (Phase 1)

1. Five physics/STEM adapters ship and are registered in `REGISTRY`:
   - `arxiv` (preprint, TIER_2)
   - `inspire_hep` (peer-reviewed/curated, TIER_1)
   - `crossref` (DOI metadata, TIER_1)
   - `openalex` (open scholarly graph, TIER_2)
   - `semantic_scholar` (TIER_2)
2. Each adapter returns `Evidence` records with:
   - Real `url`
   - Real `excerpt` (text actually returned by the source, no LLM summarisation)
   - Real `raw_hash` (sha256 of the snapshot content)
   - A cached snapshot retrievable by hash for offline verification.
3. P95 adapter latency ≤2s per source on a warm cache, ≤4s cold. Timeouts are hard: 5s.
4. `verify_claim` with all five adapters live returns in ≤10s P95.
5. Rate limits are respected. No source threatens to ban us.

## Week-by-week

- **W2:** `arxiv` adapter + `InMemorySnapshotStore`. Full end-to-end: live call, real evidence, real hash. Integration test gated by `GTV_LIVE=1`.
- **W3:** `inspire_hep` + `crossref`. ClaimParser module to extract the searchable keyphrase from free-text claims (simple BM25-style for now; no LLMs in the adapter layer).
- **W4:** `openalex` + `semantic_scholar`. Per-source rate limiter (token bucket, per-host).
- **W5:** Persistent `SqliteSnapshotStore`. Cache hit rate ≥60% on the canonical test claim set.

## Files you own

- `src/gtv/adapters/base.py` — ABC. Extend, don't rewrite, without ADR.
- `src/gtv/adapters/arxiv.py`, `inspire_hep.py`, `crossref.py`, `openalex.py`, `semantic_scholar.py`.
- `src/gtv/adapters/__init__.py` — `REGISTRY`. Keep it a dict of instantiated adapters.
- `src/gtv/adapters/snapshot.py` — snapshot store (in-memory then sqlite).
- `src/gtv/adapters/parse.py` — claim → search query extractor.
- `tests/adapters/` — one test file per adapter, with mocked `httpx` via `respx`.

## Files you do NOT touch

- `src/gtv/models.py` — schema changes go through Protocol agent.
- `src/gtv/verdict/engine.py` — you produce evidence; you don't decide what it means.
- `src/gtv/mcp/server.py` — keep the HTTP layer thin. If you need to change it, ask Protocol.

## Concrete first task (W2)

Ship `src/gtv/adapters/arxiv.py` this week.

Contract:
- Subclass `SourceAdapter`.
- `source_did = "did:web:arxiv.org"`, `trust_tier = TrustTier.TIER_2`, `source_type = SourceType.PREPRINT`.
- `async def query(self, claim, max_items)`:
  1. Extract keyphrase via `parse.claim_to_query(claim.text)`.
  2. Call `https://export.arxiv.org/api/query?search_query=...&max_results=...`.
  3. For each hit, fetch the abstract, compute `sha256(abstract_bytes)`, store the snapshot.
  4. Classify stance heuristically (for W2, default all hits to `NEUTRAL` and let downstream upgrade) — or if the claim contains an entity match with the abstract, `SUPPORTS`. Do NOT invent refutations.
  5. Return `list[Evidence]`.
- `async def health()`: HEAD the arXiv API, return `HealthStatus`.
- Per-adapter `httpx.AsyncClient` with 5s timeout; close it in `close()`.

Tests:
- Unit: `respx`-mock the arXiv response, assert correct parsing and hash computation.
- Integration (`@pytest.mark.live`): actually hit arXiv. Skipped unless `GTV_LIVE=1`.

## Do NOT

- Call an LLM inside an adapter. Adapters are dumb pipes. LLM-based stance classification lives in a separate module (if it lives at all — v1 is heuristic).
- Fabricate an excerpt. If the source didn't return text, don't invent one. Skip the result or return `NEUTRAL` with `excerpt=""` if schema allows.
- Share an `httpx.AsyncClient` across adapters. Each owns its own. Different hosts, different rate limits, different cert chains.
- Swallow timeouts. A source that times out is a source that's DOWN. Surface it in `health()`, don't pretend you got empty results.
- Scrape HTML when an API exists. arXiv, INSPIRE, Crossref, OpenAlex, Semantic Scholar all have APIs. Use them.

## Success signal

Someone runs `gtv-verify` on an envelope produced 3 months ago, and because the `raw_hash` is still in our snapshot store, they can reconstruct exactly what arXiv returned that day.
