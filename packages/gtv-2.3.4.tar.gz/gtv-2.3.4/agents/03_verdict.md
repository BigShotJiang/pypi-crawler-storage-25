# Agent 03 — Verdict

**Read `agents/00_overview.md` first. The seven rules apply to you too.**

## Mission

Turn evidence into a defensible verdict. Every decision the engine emits must be reproducible, explainable in one sentence, and predictable from the rules alone — no learned models, no randomness, no hidden state in v1.

## What done looks like (Phase 1)

1. `decide(VerdictInputs) -> VerdictRecord` is pure, deterministic, and covered by ≥20 unit tests spanning every branch of the decision tree.
2. Every verdict carries a `rationale` that a non-engineer can read and agree with.
3. The six verdict types are all exercised: VERIFIED, UNVERIFIED, CONTESTED, OPINION, CREATIVE, OUT_OF_SCOPE.
4. Confidence calibration is sane: multi-source TIER_1 supports land ≥0.8; single-source TIER_3 supports stay ≤0.5; 5-year-old evidence takes a visible confidence hit.
5. Claim classifier routes opinion/creative/out-of-scope claims before any adapter fan-out (saves latency and dollars).

## Week-by-week

- **W1 [DONE by scaffold]:** rule-based `decide()` + 6 baseline tests green.
- **W2:** Claim classifier — `src/gtv/verdict/classify.py::classify(claim) -> ClaimClass`. Heuristic: opinion markers ("I think", "should", "best"), creative markers (fiction requests), out-of-scope markers (medical/legal/crypto-price). Returns an enum the engine uses to short-circuit.
- **W3:** Confidence calibration sweep — 50 synthetic claim/evidence scenarios with expected verdict + confidence band; tests assert we land inside the band.
- **W4:** Rationale templating — swap bare f-strings for a small template module so Protocol agent can localise rationales later without touching engine logic.
- **W5:** Published `docs/verdict-rules.md` — human-readable decision tree, identical to what the code does.

## Files you own

- `src/gtv/verdict/engine.py` — the `decide` function and helpers.
- `src/gtv/verdict/classify.py` — claim classifier. Doesn't exist yet; create it.
- `src/gtv/verdict/rationale.py` — rationale templates. Create it in W4.
- `tests/test_engine.py`, `tests/test_classify.py` — unit coverage.
- `docs/verdict-rules.md` — rules doc. Must match code exactly.

## Files you do NOT touch

- `src/gtv/models.py` — `Verdict` enum changes go through Protocol agent via ADR.
- `src/gtv/adapters/` — Adapter agent's. Don't call them from the engine.
- `src/gtv/mcp/server.py` — Protocol agent's. You ship a function; they wire it up.

## Concrete first task (W2)

Ship `src/gtv/verdict/classify.py`.

Contract:
```python
from enum import StrEnum
from gtv.models import Claim

class ClaimClass(StrEnum):
    FACTUAL = "FACTUAL"       # route to adapters
    OPINION = "OPINION"        # short-circuit → Verdict.OPINION
    CREATIVE = "CREATIVE"      # short-circuit → Verdict.CREATIVE
    OUT_OF_SCOPE = "OUT_OF_SCOPE"  # short-circuit → Verdict.OUT_OF_SCOPE

def classify(claim: Claim) -> ClaimClass: ...
```

Heuristics only (no LLM). Regex + lexicon. Build the lexicon in the module. Test with at least 30 labelled examples spanning all four classes.

Then update `mcp/server.py::verify_claim` to call `classify()` before the adapter fan-out; short-circuit on non-FACTUAL.

## Do NOT

- Add a learned model. v2. Not now. ADR 0005 will lock when v2 starts — don't sneak it in.
- Make `decide` async. It's pure CPU; keep it synchronous. The fan-out around it is async.
- Add global mutable state — no module-level caches, no memoisation. Same inputs → same output, always.
- Invent new branches of the decision tree without writing the test first. TDD here, non-negotiable — the verdict engine is the part of the system auditors will stare at.
- Tune confidence constants to make a specific test pass. Tune to make the calibration sweep pass.

## Success signal

A journalist screenshots a VERIFIED envelope, shows it to a physicist, and the physicist reads the rationale and says "yeah, that's the right reason."
