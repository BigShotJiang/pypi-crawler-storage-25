# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Stateful claim threads for conversational claim refinement.

A ClaimThread is a tamper-evident chain of (claim, verdict) pairs, enabling
claim refinement across multiple conversational turns. Each turn links to the
previous via sha256 hashing, forming an immutable audit trail.
"""
from __future__ import annotations

import hashlib
import json
import uuid
from dataclasses import dataclass
from datetime import UTC, datetime


@dataclass(frozen=True)
class ClaimTurn:
    """A single turn in a claim thread.

    Attributes:
        turn_id: Unique identifier for this turn (UUID4).
        parent_turn_id: ID of the previous turn, None for first turn.
        claim_id: The claim being assessed in this turn.
        verdict_hash: SHA256 of the canonical verdict JSON for this turn.
        created_at: ISO 8601 UTC timestamp when turn was created.
        prev_chain_hash: SHA256 of the previous turn's canonical bytes,
                        None for first turn. Used to verify chain integrity.
    """

    turn_id: str
    parent_turn_id: str | None
    claim_id: str
    verdict_hash: str
    created_at: str
    prev_chain_hash: str | None

    def canonical_bytes(self) -> bytes:
        """Return canonical JSON representation of this turn for hashing.

        Uses sorted keys and UTF-8 encoding to ensure deterministic hashing.
        """
        canonical = {
            "turn_id": self.turn_id,
            "parent_turn_id": self.parent_turn_id,
            "claim_id": self.claim_id,
            "verdict_hash": self.verdict_hash,
            "created_at": self.created_at,
            "prev_chain_hash": self.prev_chain_hash,
        }
        return json.dumps(canonical, sort_keys=True).encode("utf-8")

    def chain_hash(self) -> str:
        """Compute SHA256 hash of this turn's canonical bytes."""
        return hashlib.sha256(self.canonical_bytes()).hexdigest()


class ClaimThread:
    """An immutable chain of claim verdicts across conversational turns.

    ClaimThread enables refining a claim across multiple turns by maintaining
    a tamper-evident chain. Each turn links to the previous turn via SHA256
    hashing, preventing modification without detection.
    """

    def __init__(self, thread_id: str, turns: list[ClaimTurn], verdicts: dict[str, dict] | None = None) -> None:
        """Initialize a ClaimThread with a thread ID and list of turns.

        Args:
            thread_id: Unique identifier for this thread.
            turns: List of ClaimTurn objects in chronological order.
            verdicts: Optional dict mapping turn_id to verdict dict for aggregation.
        """
        self.thread_id = thread_id
        self.turns = turns
        self._verdicts = verdicts or {}

    @classmethod
    def start(
        cls, first_claim_id: str, first_verdict: dict
    ) -> ClaimThread:
        """Create a new thread with a single initial turn.

        Args:
            first_claim_id: The claim ID for the first turn.
            first_verdict: Verdict dictionary for the first claim.
                          Will be canonicalized and hashed.

        Returns:
            A new ClaimThread with one turn.
        """
        turn_id = str(uuid.uuid4())
        thread_id = str(uuid.uuid4())
        created_at = datetime.now(tz=UTC).isoformat()

        # Hash the verdict
        verdict_hash = _hash_verdict(first_verdict)

        turn = ClaimTurn(
            turn_id=turn_id,
            parent_turn_id=None,
            claim_id=first_claim_id,
            verdict_hash=verdict_hash,
            created_at=created_at,
            prev_chain_hash=None,
        )

        return cls(thread_id, [turn], {turn_id: first_verdict})

    def append(self, claim_id: str, verdict: dict) -> ClaimTurn:
        """Append a new turn to the thread, linking to the previous turn.

        Args:
            claim_id: The claim ID for the new turn.
            verdict: Verdict dictionary for the new claim.

        Returns:
            The newly created ClaimTurn.

        Raises:
            ValueError: If the thread is empty (should not occur with normal usage).
        """
        if not self.turns:
            raise ValueError("Cannot append to an empty thread")

        prev_turn = self.turns[-1]
        new_turn_id = str(uuid.uuid4())
        created_at = datetime.now(tz=UTC).isoformat()

        # Hash the verdict
        verdict_hash = _hash_verdict(verdict)

        # Compute hash of previous turn
        prev_chain_hash = prev_turn.chain_hash()

        new_turn = ClaimTurn(
            turn_id=new_turn_id,
            parent_turn_id=prev_turn.turn_id,
            claim_id=claim_id,
            verdict_hash=verdict_hash,
            created_at=created_at,
            prev_chain_hash=prev_chain_hash,
        )

        self.turns.append(new_turn)
        self._verdicts[new_turn_id] = verdict
        return new_turn

    def head_hash(self) -> str:
        """Compute the SHA256 hash of the latest turn in the chain.

        Returns:
            SHA256 hexdigest of the most recent turn's canonical bytes.

        Raises:
            ValueError: If the thread has no turns.
        """
        if not self.turns:
            raise ValueError("Cannot compute head hash of an empty thread")
        return self.turns[-1].chain_hash()

    def verify_chain(self) -> bool:
        """Verify that the entire chain is tamper-free.

        Checks that each turn's prev_chain_hash matches the actual hash of
        the previous turn. The first turn must have prev_chain_hash == None.

        Returns:
            True if the chain is valid, False otherwise.
        """
        for i, turn in enumerate(self.turns):
            if i == 0:
                # First turn must have no parent
                if turn.parent_turn_id is not None:
                    return False
                if turn.prev_chain_hash is not None:
                    return False
            else:
                # Check parent link
                prev_turn = self.turns[i - 1]
                if turn.parent_turn_id != prev_turn.turn_id:
                    return False
                # Check chain hash
                expected_hash = prev_turn.chain_hash()
                if turn.prev_chain_hash != expected_hash:
                    return False

        return True

    def aggregate_verdict(self) -> dict:
        """Aggregate verdicts across all turns into a thread-level verdict.

        Counts turns with status == "VERIFIED" as supports and
        status == "REFUTED" as refutes. Applies these rules:

        - VERIFIED: supports > 0 and refutes == 0
        - REFUTED: refutes > supports and supports == 0
        - MIXED: all other cases
        - confidence: mean of per-turn confidence values

        Returns:
            Dictionary with keys:
            - status: 'VERIFIED' | 'MIXED' | 'REFUTED'
            - confidence: float (0.0 to 1.0)
            - turns: int (total number of turns)
            - supports: int (number of VERIFIED verdicts)
            - refutes: int (number of REFUTED verdicts)
        """
        if not self.turns:
            return {
                "status": "MIXED",
                "confidence": 0.0,
                "turns": 0,
                "supports": 0,
                "refutes": 0,
            }

        supports = 0
        refutes = 0
        confidence_sum = 0.0
        confidence_count = 0

        for turn in self.turns:
            # Look up verdict in stored verdicts
            verdict = self._verdicts.get(turn.turn_id)
            if verdict:
                status = verdict.get("status")
                if status == "VERIFIED":
                    supports += 1
                elif status == "REFUTED":
                    refutes += 1

                # Accumulate confidence if present
                confidence = verdict.get("confidence", 0.0)
                confidence_sum += confidence
                confidence_count += 1

        # Determine overall status
        if supports > 0 and refutes == 0:
            status = "VERIFIED"
        elif refutes > supports and supports == 0:
            status = "REFUTED"
        else:
            status = "MIXED"

        # Compute mean confidence
        mean_confidence = (
            confidence_sum / confidence_count if confidence_count > 0 else 0.0
        )

        return {
            "status": status,
            "confidence": mean_confidence,
            "turns": len(self.turns),
            "supports": supports,
            "refutes": refutes,
        }


def _hash_verdict(verdict: dict) -> str:
    """Hash a verdict dictionary using canonical JSON form.

    Args:
        verdict: Verdict dictionary to hash.

    Returns:
        SHA256 hexdigest of the canonical JSON representation.
    """
    canonical = json.dumps(verdict, sort_keys=True).encode("utf-8")
    return hashlib.sha256(canonical).hexdigest()
