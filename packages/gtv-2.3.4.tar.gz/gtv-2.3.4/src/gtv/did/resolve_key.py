# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""did:key DID method parser.

Extracts raw public-key bytes from did:key DIDs using multibase+multicodec.
Format: did:key:z<base58btc-encoded multicodec key>

Multicodec prefixes:
- Ed25519: 0xed 0x01 (32-byte key)
- NIST P-256: 0x12 0x00 (33-byte compressed point)
- secp256k1: 0xe7 0x01 (33-byte compressed point)

See: https://w3c-ccg.github.io/did-method-key/
"""
from __future__ import annotations

from dataclasses import dataclass


def _base58btc_decode(encoded: str) -> bytes:
    """Decode a base58btc string to bytes. Inline decoder (~20 lines)."""
    alphabet = b"123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
    decoded = 0
    for char in encoded:
        try:
            digit = alphabet.index(ord(char) if isinstance(char, str) else char)
        except ValueError:
            raise ValueError(f"Invalid base58btc character: {char}") from None
        decoded = decoded * 58 + digit

    # Convert to bytes (big-endian), handling leading zeros
    result = bytearray()
    if decoded == 0:
        result.append(0)
    while decoded > 0:
        result.append(decoded & 0xFF)
        decoded >>= 8

    # Count leading '1' chars (encoded zeros) and prepend them
    leading_ones = len(encoded) - len(encoded.lstrip("1"))
    result = bytearray(leading_ones) + result
    return bytes(reversed(result))


@dataclass
class ParsedDIDKey:
    """Parsed did:key with extracted key material."""

    key_type: str
    public_key_bytes: bytes


# Multicodec prefix registry: (prefix_bytes, key_type, expected_length)
_MULTICODEC_TYPES = {
    b"\xed\x01": ("Ed25519", 32),
    b"\x12\x00": ("NIST P-256", 33),
    b"\xe7\x01": ("secp256k1", 33),
}


def parse_did_key(did: str) -> ParsedDIDKey:
    """Parse a did:key DID and extract the public key.

    Args:
        did: DID string (e.g., "did:key:z6MkpTHR8VNsBxYAAWHut2Geadd9jSwuBV8xRoAnwWsdvktH").

    Returns:
        ParsedDIDKey with key_type and public_key_bytes.

    Raises:
        ValueError: If the DID is malformed, has invalid base58, unknown multicodec, etc.
    """
    if not isinstance(did, str):
        raise ValueError(f"DID must be a string, not {type(did).__name__}")

    if not did.startswith("did:key:z"):
        raise ValueError(f"Invalid did:key format: must start with 'did:key:z', got {did[:20]}...")

    # Extract the base58btc-encoded portion (everything after "did:key:z")
    encoded_key = did[9:]

    if not encoded_key:
        raise ValueError("did:key has no key material after 'did:key:z'")

    # Decode from base58btc
    try:
        key_bytes = _base58btc_decode(encoded_key)
    except ValueError as e:
        raise ValueError(f"Invalid base58btc encoding in did:key: {e}") from e

    if len(key_bytes) < 2:
        raise ValueError(f"Decoded key material too short ({len(key_bytes)} bytes), cannot be a multicodec key")

    # Extract multicodec prefix (first 1-2 bytes)
    # Most multicodecs are 2 bytes; check that first
    prefix_2 = key_bytes[:2]
    if prefix_2 in _MULTICODEC_TYPES:
        key_type, expected_len = _MULTICODEC_TYPES[prefix_2]
        payload = key_bytes[2:]
        if len(payload) != expected_len:
            raise ValueError(
                f"Multicodec {key_type} expects {expected_len}-byte key, got {len(payload)} bytes"
            )
        return ParsedDIDKey(key_type=key_type, public_key_bytes=payload)

    # Check single-byte multicodecs (less common, but for completeness)
    # No single-byte multicodecs in our registry, but structure is here for extension.

    raise ValueError(
        f"Unknown multicodec prefix in did:key: {prefix_2.hex()}"
    )
