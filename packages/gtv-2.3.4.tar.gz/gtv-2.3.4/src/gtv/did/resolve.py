# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""DID resolution dispatcher for did:web and did:key.

Supports:
- did:web: resolves to HTTPS URLs and fetches DID documents.
- did:key: parses multibase-encoded multicodec keys for BYOK workflows.

Custom verificationMethod type: "SigstoreIdentity2024"
Defines issuer identity fields extracted from Sigstore certificates:
  - issuer_email: email identity from cert SAN
  - issuer_san: DNS SAN or other identifier
  - issuer_uri: URI SAN identifier
  - fulcio_oidc: OIDC issuer URL from cert extensions

did:web spec: https://w3c-ccg.github.io/did-method-web/
- did:web:example.com → GET https://example.com/.well-known/did.json
- did:web:example.com:path:to:resource → GET https://example.com/path/to/resource/did.json

did:key spec: https://w3c-ccg.github.io/did-method-key/
- did:key:z<base58btc> → parse multicodec key, extract raw bytes + type
"""
from __future__ import annotations

from typing import Any

import httpx

from gtv.did.resolve_key import parse_did_key


class DIDResolutionError(Exception):
    """Raised when DID resolution fails."""

    pass


def parse_did_web(did: str) -> str:
    """Parse a did:web DID and return the HTTPS URL to fetch the DID document.

    Args:
        did: DID string (e.g., "did:web:example.com" or "did:web:example.com:path:to:resource").

    Returns:
        HTTPS URL to fetch the DID document.

    Raises:
        DIDResolutionError: If the DID is not did:web or is malformed.
    """
    if not did.startswith("did:web:"):
        raise DIDResolutionError(f"Not a did:web DID: {did}")

    # Remove "did:web:" prefix
    remainder = did[8:]
    if not remainder:
        raise DIDResolutionError("did:web with no authority")

    # Split on first ":" to separate authority from path components
    parts = remainder.split(":")
    authority = parts[0]

    if not authority:
        raise DIDResolutionError("did:web with empty authority")

    # Validate authority is a domain name (basic check: contains no invalid chars)
    if not authority.replace(".", "").replace("-", "").isalnum():
        raise DIDResolutionError(f"Invalid authority in did:web: {authority}")

    # Construct the URL
    if len(parts) == 1:
        # No path components: did:web:example.com
        url = f"https://{authority}/.well-known/did.json"
    else:
        # Path components: did:web:example.com:path:to:resource
        path_components = parts[1:]
        path = "/".join(path_components)
        url = f"https://{authority}/{path}/did.json"

    return url


async def resolve_did_web(
    did: str, *, timeout: float = 5.0, client: httpx.AsyncClient | None = None
) -> dict[str, Any]:
    """Resolve a did:web DID to its DID document.

    Args:
        did: DID string to resolve (e.g., "did:web:example.com").
        timeout: HTTP request timeout in seconds (default: 5.0).
        client: Optional httpx.AsyncClient to use (default: create temporary client).

    Returns:
        DID document as a dict. Must include "id" field matching the requested DID.

    Raises:
        DIDResolutionError: If resolution fails (non-200, invalid JSON, DID mismatch, etc.).
    """
    # Parse the DID to get the URL
    url = parse_did_web(did)

    # Fetch the DID document
    close_client = False
    if client is None:
        client = httpx.AsyncClient()
        close_client = True

    try:
        response = await client.get(url, timeout=timeout)
    except Exception as e:
        raise DIDResolutionError(f"Failed to fetch DID document from {url}: {e}") from e
    finally:
        if close_client:
            await client.aclose()

    # Check HTTP status
    if response.status_code != 200:
        raise DIDResolutionError(
            f"DID document fetch failed with status {response.status_code}: {url}"
        )

    # Parse JSON
    try:
        did_doc = response.json()
    except Exception as e:
        raise DIDResolutionError(
            f"Failed to parse DID document JSON from {url}: {e}"
        ) from e

    # Validate DID document structure
    if not isinstance(did_doc, dict):
        raise DIDResolutionError(
            f"DID document is not a JSON object (got {type(did_doc).__name__})"
        )

    # Check that "id" field exists and matches the requested DID
    doc_id = did_doc.get("id")
    if not doc_id:
        raise DIDResolutionError("DID document missing required 'id' field")

    if doc_id != did:
        raise DIDResolutionError(
            f"DID mismatch: requested {did}, document claims {doc_id}"
        )

    return did_doc


def extract_expected_identity(did_doc: dict[str, Any]) -> dict[str, Any]:
    """Extract expected issuer identity from a DID document.

    Looks for verificationMethod entries with custom type "SigstoreIdentity2024".
    Returns the first matching entry or an empty identity (all fields None).

    The SigstoreIdentity2024 type defines:
      - issuer_email: email identity from certificate SAN
      - issuer_san: DNS or other SAN identifier
      - issuer_uri: URI SAN identifier
      - fulcio_oidc: OIDC issuer URL from certificate extension

    Args:
        did_doc: DID document dict (output from resolve_did_web).

    Returns:
        Dict with keys {"issuer_email", "issuer_san", "issuer_uri", "fulcio_oidc"}.
        Missing fields are set to None. If no SigstoreIdentity2024 entry found,
        all fields are None.
    """
    default_identity = {
        "issuer_email": None,
        "issuer_san": None,
        "issuer_uri": None,
        "fulcio_oidc": None,
    }

    verification_methods = did_doc.get("verificationMethod", [])
    if not isinstance(verification_methods, list):
        return default_identity

    for vm in verification_methods:
        if not isinstance(vm, dict):
            continue

        # Look for our custom type
        vm_type = vm.get("type")
        if vm_type == "SigstoreIdentity2024":
            # Extract fields from the verificationMethod
            identity = {
                "issuer_email": vm.get("issuer_email"),
                "issuer_san": vm.get("issuer_san"),
                "issuer_uri": vm.get("issuer_uri"),
                "fulcio_oidc": vm.get("fulcio_oidc"),
            }
            return identity

    # No matching entry found; return all None
    return default_identity


def resolve_did(did: str) -> dict[str, Any]:
    """Dispatcher: route DID to correct handler.

    Currently supports:
    - did:web:... → returns parsed HTTPS URL (caller fetches document)
    - did:key:z... → returns parsed key with key_type and public_key_bytes

    Args:
        did: DID string.

    Returns:
        For did:web: dict with 'url' key (string).
        For did:key: dict with 'key_type' (str) and 'public_key_bytes' (bytes).

    Raises:
        DIDResolutionError: If DID method is unsupported or parsing fails.
    """
    if not isinstance(did, str):
        raise DIDResolutionError(f"DID must be a string, not {type(did).__name__}")

    if did.startswith("did:web:"):
        return {"url": parse_did_web(did)}
    elif did.startswith("did:key:"):
        try:
            parsed = parse_did_key(did)
            return {
                "key_type": parsed.key_type,
                "public_key_bytes": parsed.public_key_bytes,
            }
        except ValueError as e:
            raise DIDResolutionError(f"Failed to parse did:key: {e}") from e
    else:
        # Extract method name for error message
        method = did.split(":")[1] if ":" in did else "unknown"
        raise DIDResolutionError(f"Unsupported DID method: {method}")
