# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Verify that a signing certificate binds to an expected issuer identity.

Extracts Subject Alternative Names (SAN) and OIDC issuer extensions from the
certificate and compares them to the expected identity from the DID document.

Raises IssuerMismatchError if the certificate does not match the expected identity.
"""
from __future__ import annotations

from typing import Any, cast

from cryptography import x509
from cryptography.hazmat.backends import default_backend
from cryptography.x509.oid import ExtensionOID


class IssuerMismatchError(Exception):
    """Raised when certificate identity does not match expected identity."""

    pass


def verify_cert_binds_to_identity(cert_pem: str, expected_identity: dict[str, Any]) -> None:
    """Verify that a certificate's identity matches the expected identity.

    Extracts from the certificate:
    - Email SAN (RFC822Name)
    - URI SAN (UniformResourceIdentifier)
    - DNS SAN (DNSName)
    - OIDC issuer from Sigstore-specific extension (1.3.6.1.4.1.57264.1.1)

    Compares against expected_identity fields:
    - issuer_email: Expected email SAN
    - issuer_uri: Expected URI SAN
    - issuer_san: Expected DNS SAN or other identifier
    - fulcio_oidc: Expected OIDC issuer URL

    Args:
        cert_pem: X.509 certificate in PEM format.
        expected_identity: Dict with keys {"issuer_email", "issuer_san", "issuer_uri", "fulcio_oidc"}.

    Raises:
        IssuerMismatchError: If the certificate does not match the expected identity.
        ValueError: If the certificate cannot be parsed.
    """
    # Parse certificate
    try:
        cert = x509.load_pem_x509_certificate(
            cert_pem.encode("utf-8"),
            backend=default_backend(),
        )
    except Exception as e:
        raise ValueError(f"Failed to parse certificate: {e}") from e

    # Extract SAN
    cert_email_san = None
    cert_uri_san = None
    cert_dns_san = None

    try:
        san_ext = cert.extensions.get_extension_for_oid(ExtensionOID.SUBJECT_ALTERNATIVE_NAME)
        san_value = cast(x509.SubjectAlternativeName, san_ext.value)
        for name in san_value:
            if isinstance(name, x509.RFC822Name):
                cert_email_san = name.value
            elif isinstance(name, x509.UniformResourceIdentifier):
                cert_uri_san = name.value
            elif isinstance(name, x509.DNSName):
                cert_dns_san = name.value
    except x509.ExtensionNotFound:
        pass  # No SAN extension

    # Extract OIDC issuer from Sigstore extension (OID 1.3.6.1.4.1.57264.1.1)
    cert_oidc_issuer = None
    sigstore_oidc_oid = x509.ObjectIdentifier("1.3.6.1.4.1.57264.1.1")
    try:
        oidc_ext = cert.extensions.get_extension_for_oid(sigstore_oidc_oid)
        # UnrecognizedExtension exposes the raw DER via .value (bytes).
        raw = cast(x509.UnrecognizedExtension, oidc_ext.value).value
        cert_oidc_issuer = raw.decode("utf-8") if isinstance(raw, bytes) else str(raw)
    except (x509.ExtensionNotFound, AttributeError, ValueError):
        pass  # No OIDC extension or different format

    # Validate expected identity fields
    expected_email = expected_identity.get("issuer_email")
    expected_uri = expected_identity.get("issuer_uri")
    expected_san = expected_identity.get("issuer_san")
    expected_oidc = expected_identity.get("fulcio_oidc")

    # Check each expected field against the certificate
    if expected_email and cert_email_san != expected_email:
        raise IssuerMismatchError(
            f"Certificate email SAN mismatch: expected {expected_email}, got {cert_email_san}"
        )

    if expected_uri and cert_uri_san != expected_uri:
        raise IssuerMismatchError(
            f"Certificate URI SAN mismatch: expected {expected_uri}, got {cert_uri_san}"
        )

    if expected_san and cert_dns_san != expected_san:
        raise IssuerMismatchError(
            f"Certificate DNS SAN mismatch: expected {expected_san}, got {cert_dns_san}"
        )

    if expected_oidc and cert_oidc_issuer != expected_oidc:
        raise IssuerMismatchError(
            f"Certificate OIDC issuer mismatch: expected {expected_oidc}, got {cert_oidc_issuer}"
        )

    # If we get here, all expected fields matched (or were None, meaning no check needed)
