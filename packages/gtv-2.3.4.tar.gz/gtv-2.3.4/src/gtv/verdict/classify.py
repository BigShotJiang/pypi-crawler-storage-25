# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Heuristic claim classifier — routes opinion/creative/out-of-scope claims
before adapter fan-out to save latency and adapter rate-limit budget.

Pure function. Regex + lexicon. No LLMs, no learned models, no global mutable state.
"""
from __future__ import annotations

import re
from enum import StrEnum

from gtv.models import Claim


class ClaimClass(StrEnum):
    """Four classes a claim can fall into."""
    FACTUAL = "FACTUAL"
    OPINION = "OPINION"
    CREATIVE = "CREATIVE"
    OUT_OF_SCOPE = "OUT_OF_SCOPE"


# ============================================================================
# Lexicon: compiled regexes and word sets (module-level, frozen)
# ============================================================================

# CREATIVE markers — highest priority. Phrases requesting fictional, artistic, or
# imaginative output.
_CREATIVE_PHRASES = frozenset((
    r"\bwrite\s+a\s+(poem|story|song|script|novel|essay|book)\b",
    r"\binvent\s+a\s+(story|scenario|character|world|civilization)\b",
    r"\bfictional\b",
    r"\bimagine\s+a\s+(scenario|world|story|situation)\b",
    r"\bmade.up\b",
    r"\bmade\s+up\b",
    r"\bpretend\b",
    r"\bin\s+the\s+style\s+of\b",
    r"\bcompose\s+a\b",
    r"\bcreate\s+a\s+(fictional|made.up|imaginary)\b",
))

_CREATIVE_REGEX = re.compile("|".join(_CREATIVE_PHRASES), re.IGNORECASE)

# OPINION markers. Three sub-patterns:
# 1. First-person belief stems: "I think", "I believe", "in my opinion"
# 2. Normative modals: "should", "ought to", "must be"
# 3. Evaluative superlatives: "the best", "the worst", "most beautiful"
#    (but require superlative dominance — roughly >30% of content words)

_OPINION_BELIEF = frozenset((
    r"\bi\s+(think|believe|suppose|reckon|feel|consider|am\s+convinced|am\s+certain)\b",
    r"\bin\s+my\s+opinion\b",
    r"\bmy\s+(view|opinion|belief|perspective|take)\b",
))

_OPINION_MODAL = frozenset((
    r"\b(?:you|we|they|people|scientists|researchers|one|everyone)\s+should\b",
    r"\bshould\s+(?:be|have|not)\b",
    r"\bought\s+to\b",
    r"\bmust\s+be\b",
))

_OPINION_SUPERLATIVE = frozenset((
    r"\bthe\s+best\b",
    r"\bthe\s+worst\b",
    r"\bthe\s+greatest\b",
    r"\bthe\s+most\s+\w+\b",
    r"\bmost\s+beautiful\b",
    r"\bmost\s+important\b",
    r"\bmost\s+significant\b",
    r"\bbest\s+\w+\b",
    r"\bworst\s+\w+\b",
))

_OPINION_BELIEF_REGEX = re.compile("|".join(_OPINION_BELIEF), re.IGNORECASE)
_OPINION_MODAL_REGEX = re.compile("|".join(_OPINION_MODAL), re.IGNORECASE)
_OPINION_SUPERLATIVE_REGEX = re.compile("|".join(_OPINION_SUPERLATIVE), re.IGNORECASE)

# OUT_OF_SCOPE markers. Four domains: medical diagnosis, legal advice,
# crypto price prediction, personal financial advice.

_OUT_OF_SCOPE_MEDICAL = frozenset((
    r"\bdiagnose\b",
    r"\bdiagnosis\b",
    r"\bcancer\b",
    r"\bis\s+this\s+(a\s+)?(skin\s+condition|disease|illness|infection|tumor|cancer)\b",
    r"\bshould\s+i\s+take\b",
    r"\bdrug\b",
    r"\bmedication\b",
    r"\btreatment\s+for\b",
))

_OUT_OF_SCOPE_LEGAL = frozenset((
    r"\bam\s+i\s+liable\b",
    r"\bis\s+(this|that|a|the)\s+\w+\s+legal\b",
    r"\blegal\s+advice\b",
    r"\bjurisdiction\b",
    r"\blawsuit\b",
    r"\bcontract\s+(review|interpretation)\b",
))

_OUT_OF_SCOPE_CRYPTO = frozenset((
    r"\bprice\s+of\s+(btc|bitcoin|eth|ethereum|crypto|cryptocurrency)\b",
    r"\bwill\s+(btc|bitcoin|eth|ethereum)\s+hit\b",
    r"\bbest\s+(crypto|cryptocurrency)\s+to\s+buy\b",
    r"\bcryptocurrency\s+investment\b",
))

_OUT_OF_SCOPE_FINANCIAL = frozenset((
    r"\bshould\s+i\s+invest\s+in\b",
    r"\bis\s+x\s+a\s+good\s+investment\b",
    r"\bfinancial\s+advice\b",
    r"\binvestment\s+recommendation\b",
))

_OUT_OF_SCOPE_MEDICAL_REGEX = re.compile("|".join(_OUT_OF_SCOPE_MEDICAL), re.IGNORECASE)
_OUT_OF_SCOPE_LEGAL_REGEX = re.compile("|".join(_OUT_OF_SCOPE_LEGAL), re.IGNORECASE)
_OUT_OF_SCOPE_CRYPTO_REGEX = re.compile("|".join(_OUT_OF_SCOPE_CRYPTO), re.IGNORECASE)
_OUT_OF_SCOPE_FINANCIAL_REGEX = re.compile("|".join(_OUT_OF_SCOPE_FINANCIAL), re.IGNORECASE)


# ============================================================================
# Classifier
# ============================================================================

def classify(claim: Claim) -> ClaimClass:
    """Classify a claim into one of four categories.

    Priority order:
      1. CREATIVE (highest) — if creative markers match, return CREATIVE
      2. OUT_OF_SCOPE — if out-of-scope markers match
      3. OPINION — if opinion markers match
      4. FACTUAL (default)

    Args:
        claim: The Claim object to classify.

    Returns:
        ClaimClass: One of FACTUAL, OPINION, CREATIVE, OUT_OF_SCOPE.
    """
    text = claim.text

    # 1. CREATIVE (highest priority)
    if _CREATIVE_REGEX.search(text):
        return ClaimClass.CREATIVE

    # 2. OUT_OF_SCOPE
    if (_OUT_OF_SCOPE_MEDICAL_REGEX.search(text) or
        _OUT_OF_SCOPE_LEGAL_REGEX.search(text) or
        _OUT_OF_SCOPE_CRYPTO_REGEX.search(text) or
        _OUT_OF_SCOPE_FINANCIAL_REGEX.search(text)):
        return ClaimClass.OUT_OF_SCOPE

    # 3. OPINION
    if _OPINION_BELIEF_REGEX.search(text):
        return ClaimClass.OPINION

    if _OPINION_MODAL_REGEX.search(text):
        return ClaimClass.OPINION

    # For superlatives, check dominance: superlative phrases / total words
    # (rough heuristic: if superlatives are >15% of words, classify as OPINION)
    if _OPINION_SUPERLATIVE_REGEX.search(text):
        superlative_matches = _OPINION_SUPERLATIVE_REGEX.findall(text)
        # Count all words in the text
        words = text.split()
        total_words = len(words)
        # If superlatives are a significant proportion of words, it's evaluative
        if total_words > 0 and len(superlative_matches) / total_words > 0.15:
            return ClaimClass.OPINION

    # 4. FACTUAL (default)
    return ClaimClass.FACTUAL
