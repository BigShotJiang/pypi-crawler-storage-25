# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Deterministic, rule-based verdict engine (v1 — build spec §9.1).

No learned model here. One input, one output, one reason. The point is
that a reviewer can read the rule, trace it through a test, and predict
exactly what the engine will return.

Thresholds, tier weights, and the confidence-formula constants live in
`gtv.policy` so operators can tune them without recompiling. The
default policy encodes the legacy constants byte-for-byte, so callers
that don't pass a policy get identical behavior.

v2 (Phase 2) swaps `_confidence` for a calibrated learned ranker — not here.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime, timedelta

from gtv.models import (
    Claim,
    Evidence,
    Stance,
    TrustTier,
    Verdict,
    VerdictRecord,
)
from gtv.policy import DEFAULT_POLICY, Policy
from gtv.policy.schema import ResolvedPolicy


@dataclass(frozen=True)
class VerdictInputs:
    claim: Claim
    evidence: list[Evidence]
    is_opinion: bool = False
    is_creative: bool = False
    tier_of: dict[str, TrustTier] | None = None  # source_did → tier


def _distinct_sources(items: list[Evidence]) -> set[str]:
    return {e.source_did for e in items}


def _age_months(retrieved_at: datetime) -> float:
    now = datetime.now(tz=UTC)
    delta = now - retrieved_at
    return max(0.0, delta.days / 30.0)


def _confidence(
    count: int,
    tier_bonus: float,
    oldest_age_months: float,
    resolved: ResolvedPolicy,
) -> float:
    """clamp(base + per_source*n + per_tier_bonus*bonus - age_penalty*age_norm, 0, 0.99)."""
    f = resolved.confidence
    age_norm = min(1.0, oldest_age_months / f.age_horizon_months)
    raw = (
        f.base
        + f.per_source * count
        + f.per_tier_bonus * tier_bonus
        - f.age_penalty * age_norm
    )
    return max(0.0, min(0.99, raw))


def _tier_bonus(
    items: list[Evidence],
    tier_of: dict[str, TrustTier] | None,
    resolved: ResolvedPolicy,
) -> float:
    if not tier_of:
        return 0.0
    tw = resolved.tier_weights
    weights = {
        TrustTier.TIER_1: tw.tier_1,
        TrustTier.TIER_2: tw.tier_2,
        TrustTier.TIER_3: tw.tier_3,
    }
    return sum(
        weights.get(tier_of.get(e.source_did, TrustTier.TIER_3), tw.tier_3)
        for e in items
    )


def _oldest_age(items: list[Evidence]) -> float:
    if not items:
        return 0.0
    return max(_age_months(e.retrieved_at) for e in items)


def _filter_by_age(
    items: list[Evidence], max_age_days: int | None
) -> list[Evidence]:
    """Drop evidence older than ``max_age_days``. v1 passes through."""
    if max_age_days is None:
        return items
    cutoff = datetime.now(tz=UTC) - timedelta(days=max_age_days)
    return [e for e in items if e.retrieved_at >= cutoff]


def _has_recent(
    items: list[Evidence], within_days: int | None
) -> bool:
    """Return True if any item is within the recency window. v1 ⇒ True."""
    if within_days is None:
        return True
    cutoff = datetime.now(tz=UTC) - timedelta(days=within_days)
    return any(e.retrieved_at >= cutoff for e in items)


def _distinct_tiers(
    items: list[Evidence], tier_of: dict[str, TrustTier] | None
) -> set[TrustTier]:
    """Tiers present among the supporting sources. Missing mappings
    default to TIER_3 — the safe assumption when an operator hasn't
    classified a source yet."""
    if not items:
        return set()
    lookup = tier_of or {}
    return {lookup.get(e.source_did, TrustTier.TIER_3) for e in items}


def decide(inputs: VerdictInputs, policy: Policy | None = None) -> VerdictRecord:
    """Return a VerdictRecord for the given inputs. Pure function.

    ``policy`` is optional; when ``None`` the built-in default is
    used, which reproduces the legacy hardcoded engine exactly.
    """
    pol = policy or DEFAULT_POLICY
    resolved = pol.for_domain(inputs.claim.domain)

    if inputs.is_creative:
        return _record(inputs, Verdict.CREATIVE, 0.99, "Marked as creative output.")
    if inputs.is_opinion:
        return _record(inputs, Verdict.OPINION, 0.9, "Classified as opinion / interpretation.")

    # v2: age filter runs BEFORE anything else. Stale evidence is
    # invisible to the rest of the engine — it can't contribute to
    # supports, refutes, confidence, or tier diversity.
    fresh = _filter_by_age(inputs.evidence, resolved.max_evidence_age_days)

    supports = [e for e in fresh if e.stance == Stance.SUPPORTS]
    refutes = [e for e in fresh if e.stance == Stance.REFUTES]

    distinct_supports = _distinct_sources(supports)
    distinct_refutes = _distinct_sources(refutes)
    i_s, i_r = len(distinct_supports), len(distinct_refutes)

    if i_s >= resolved.min_supports_for_verified and i_r == 0:
        # v2: recent-support gate
        if not _has_recent(supports, resolved.require_recent_support_days):
            return _record(
                inputs, Verdict.UNVERIFIED, 0.3,
                f"Insufficient recent corroboration: no support within "
                f"{resolved.require_recent_support_days} days.",
            )
        # v2: cross-tier gate
        if resolved.min_distinct_tiers_for_verified is not None:
            n_tiers = len(_distinct_tiers(supports, inputs.tier_of))
            if n_tiers < resolved.min_distinct_tiers_for_verified:
                return _record(
                    inputs, Verdict.UNVERIFIED, 0.3,
                    f"Insufficient tier diversity: supports span {n_tiers} "
                    f"tier(s); require "
                    f"{resolved.min_distinct_tiers_for_verified}.",
                )
        conf = _confidence(
            i_s, _tier_bonus(supports, inputs.tier_of, resolved),
            _oldest_age(supports), resolved,
        )
        return _record(inputs, Verdict.VERIFIED, conf,
                       f"Verified: {i_s} independent sources support; no refutations.")

    if i_r >= resolved.min_refutes_for_negation and i_s == 0:
        conf = _confidence(
            i_r, _tier_bonus(refutes, inputs.tier_of, resolved),
            _oldest_age(refutes), resolved,
        )
        return _record(inputs, Verdict.VERIFIED, conf,
                       f"Verified (negated): {i_r} independent sources refute; no supports.")

    if i_s >= 1 and i_r >= 1:
        delta = abs(i_s - i_r)
        conf = _confidence(
            delta,
            _tier_bonus(supports + refutes, inputs.tier_of, resolved),
            _oldest_age(supports + refutes),
            resolved,
        )
        return _record(inputs, Verdict.CONTESTED, conf,
                       f"Contested: {i_s} support, {i_r} refute.")

    if not inputs.evidence:
        return _record(inputs, Verdict.UNVERIFIED, 0.1,
                       "No evidence retrieved from any federated source.")

    # Evidence existed but was filtered to nothing (all stale) OR just
    # too few distinct sources. Keep rationales honest for each.
    if not fresh:
        return _record(
            inputs, Verdict.UNVERIFIED, 0.15,
            f"All evidence older than max_evidence_age_days="
            f"{resolved.max_evidence_age_days}.",
        )

    return _record(inputs, Verdict.UNVERIFIED, 0.3,
                   f"Insufficient distinct-source corroboration "
                   f"(supports={i_s}, refutes={i_r}).")


def _record(
    inputs: VerdictInputs,
    decision: Verdict,
    confidence: float,
    rationale: str,
) -> VerdictRecord:
    return VerdictRecord(
        claim_id=inputs.claim.claim_id,
        decision=decision,
        confidence=confidence,
        evidence_refs=[e.evidence_id for e in inputs.evidence],
        rationale=rationale,
    )


class VerdictEngine:
    """Thin OO façade around `decide`. Kept so callers can swap in v2 later."""

    def __init__(self, policy: Policy | None = None) -> None:
        self._policy = policy

    def decide(self, inputs: VerdictInputs) -> VerdictRecord:
        return decide(inputs, self._policy)
