# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Verdict engine.

Default dispatch is the deterministic rule-based v1 in :mod:`gtv.verdict.engine`.
Setting ``GTV_USE_LEARNED_RANKER=1`` opts into the experimental learned
ranker in :mod:`gtv.verdict.ranker` for A/B evaluation. No ML deps; pure
stdlib + the existing gtv models.

The rule-based and learned paths both return a :class:`VerdictRecord`, so
callers (``gtv.mcp.server``) do not branch on ranker selection.
"""
from __future__ import annotations

import os

from gtv.models import VerdictRecord
from gtv.policy import Policy
from gtv.verdict.engine import VerdictEngine, VerdictInputs
from gtv.verdict.engine import decide as _rule_based_decide
from gtv.verdict.ranker import LearnedRanker

_LEARNED_RANKER_ENV = "GTV_USE_LEARNED_RANKER"


def _use_learned_ranker() -> bool:
    return os.getenv(_LEARNED_RANKER_ENV) == "1"


def decide(
    inputs: VerdictInputs,
    policy: Policy | None = None,
) -> VerdictRecord:
    """Dispatch a verdict decision to the rule-based or learned engine.

    When ``GTV_USE_LEARNED_RANKER=1`` is set in the environment, the
    experimental :class:`LearnedRanker` is used and ``policy`` is ignored
    (the learned path has its own weights). Otherwise the rule-based
    :func:`gtv.verdict.engine.decide` runs with ``policy``.
    """
    if _use_learned_ranker():
        return LearnedRanker().decide(inputs)
    return _rule_based_decide(inputs, policy)


__all__ = ["LearnedRanker", "VerdictEngine", "decide"]
