# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Learned verdict ranker — alternative to rule-based decide() (v2 alpha).

Pure Python + stdlib, no ML library dependency. A skeleton for future
sklearn-backed replacement. Supports score(), predict_proba(), and decide()
with a simple gradient-free fit() for tuning.

Unlike the rule-based engine which returns a hand-traced verdict, the ranker
produces a float logit score that can be configured for any threshold.
"""
from __future__ import annotations

import math
from dataclasses import dataclass

from gtv.models import Stance, TrustTier, Verdict, VerdictRecord
from gtv.verdict.engine import (
    VerdictInputs,
    _distinct_sources,
    _filter_by_age,
    _oldest_age,
    _record,
)


@dataclass(frozen=True)
class Weights:
    """Linear feature weights for the ranker logit model."""

    tier_1_support: float = 2.0
    tier_2_support: float = 1.0
    tier_3_support: float = 0.5
    tier_1_refute: float = -1.5
    tier_2_refute: float = -1.0
    tier_3_refute: float = -0.5
    age_penalty: float = -0.1
    stale_penalty: float = -2.0
    intercept: float = -1.0


class LearnedRanker:
    """Probabilistic verdict ranker with deterministic deps.

    Attributes:
        weights: Dict mapping feature names to coefficients.
    """

    def __init__(self, weights: dict[str, float] | None = None) -> None:
        """Initialize ranker with optional custom weights.

        Args:
            weights: Optional dict of {feature_name: coefficient}.
                    Defaults to sensible hand-tuned set.
        """
        default = Weights()
        self.weights = {
            "tier_1_support": (weights or {}).get("tier_1_support", default.tier_1_support),
            "tier_2_support": (weights or {}).get("tier_2_support", default.tier_2_support),
            "tier_3_support": (weights or {}).get("tier_3_support", default.tier_3_support),
            "tier_1_refute": (weights or {}).get("tier_1_refute", default.tier_1_refute),
            "tier_2_refute": (weights or {}).get("tier_2_refute", default.tier_2_refute),
            "tier_3_refute": (weights or {}).get("tier_3_refute", default.tier_3_refute),
            "age_penalty": (weights or {}).get("age_penalty", default.age_penalty),
            "stale_penalty": (weights or {}).get("stale_penalty", default.stale_penalty),
            "intercept": (weights or {}).get("intercept", default.intercept),
        }

    def score(self, inputs: VerdictInputs) -> float:
        """Return a raw logit score for the inputs.

        Higher scores indicate higher probability of VERIFIED.
        Score is a weighted sum of evidence features.

        Args:
            inputs: VerdictInputs with claim, evidence, and optionally tier_of.

        Returns:
            Float logit score (unbounded).
        """
        if inputs.is_creative or inputs.is_opinion:
            return -10.0  # Very negative for non-factual claims

        # Filter by age first (same as engine)
        from gtv.policy import DEFAULT_POLICY

        resolved = DEFAULT_POLICY.for_domain(inputs.claim.domain)
        fresh = _filter_by_age(inputs.evidence, resolved.max_evidence_age_days)

        if not fresh:
            return self.weights["stale_penalty"]

        supports = [e for e in fresh if e.stance == Stance.SUPPORTS]
        refutes = [e for e in fresh if e.stance == Stance.REFUTES]

        # Skip if both present (contested is neutral in this model)
        if supports and refutes:
            return 0.0

        # Compute features
        logit = self.weights["intercept"]

        if supports:
            # Positive side: tier-weighted support count
            for src in _distinct_sources(supports):
                tier = (inputs.tier_of or {}).get(src, TrustTier.TIER_3)
                if tier == TrustTier.TIER_1:
                    logit += self.weights["tier_1_support"]
                elif tier == TrustTier.TIER_2:
                    logit += self.weights["tier_2_support"]
                else:
                    logit += self.weights["tier_3_support"]

            # Age penalty
            age = _oldest_age(supports)
            logit += self.weights["age_penalty"] * min(1.0, age / 12.0)

        if refutes:
            # Negative side: tier-weighted refute count
            for src in _distinct_sources(refutes):
                tier = (inputs.tier_of or {}).get(src, TrustTier.TIER_3)
                if tier == TrustTier.TIER_1:
                    logit += self.weights["tier_1_refute"]
                elif tier == TrustTier.TIER_2:
                    logit += self.weights["tier_2_refute"]
                else:
                    logit += self.weights["tier_3_refute"]

            # Age penalty
            age = _oldest_age(refutes)
            logit += self.weights["age_penalty"] * min(1.0, age / 12.0)

        return logit

    def predict_proba(self, inputs: VerdictInputs) -> float:
        """Return sigmoid(score) — probability the claim is VERIFIED.

        Args:
            inputs: VerdictInputs with claim, evidence, and optionally tier_of.

        Returns:
            Float in [0, 1] representing P(VERIFIED).
        """
        logit = self.score(inputs)
        try:
            return 1.0 / (1.0 + math.exp(-logit))
        except OverflowError:
            # Clamp to [0, 1] if logit is extreme
            return 1.0 if logit > 0 else 0.0

    def decide(
        self, inputs: VerdictInputs, threshold: float = 0.6
    ) -> VerdictRecord:
        """Return a VerdictRecord based on learned ranker score.

        Thresholds:
        - P(VERIFIED) >= threshold: VERIFIED
        - P(VERIFIED) < threshold: UNVERIFIED

        Does not emit OPINION/CREATIVE/CONTESTED; those come from rule-based
        engine preprocessing.

        Args:
            inputs: VerdictInputs with claim, evidence, and optionally tier_of.
            threshold: Probability threshold for VERIFIED (default 0.6).

        Returns:
            VerdictRecord with decision and confidence.
        """
        if inputs.is_creative:
            return _record(inputs, Verdict.CREATIVE, 0.99, "Marked as creative output.")
        if inputs.is_opinion:
            return _record(inputs, Verdict.OPINION, 0.9, "Classified as opinion / interpretation.")

        proba = self.predict_proba(inputs)
        confidence = proba

        if proba >= threshold:
            rationale = (
                f"Learned ranker: {proba:.2%} confidence supports VERIFIED "
                f"(threshold={threshold:.1%})."
            )
            return _record(inputs, Verdict.VERIFIED, confidence, rationale)

        rationale = (
            f"Learned ranker: {proba:.2%} confidence below VERIFIED "
            f"threshold={threshold:.1%}."
        )
        return _record(inputs, Verdict.UNVERIFIED, confidence, rationale)

    def fit(self, examples: list[tuple[VerdictInputs, Verdict]]) -> None:
        """Fit weights to examples using simple majority-vote nudge (no stdlib ML).

        Pure gradient-free approach: for each positive example (VERIFIED),
        nudge weights in the direction that increases score. For negative
        examples, nudge in the opposite direction.

        This is a skeleton; a real implementation would use sklearn LogisticRegression
        or similar.

        Args:
            examples: List of (VerdictInputs, Verdict) labeled pairs.
        """
        if not examples:
            return

        # Simple approach: for each example, compute current score and nudge
        # weights slightly toward the label.
        learning_rate = 0.01
        positive_examples = [
            ex for ex in examples if ex[1] == Verdict.VERIFIED
        ]
        negative_examples = [ex for ex in examples if ex[1] != Verdict.VERIFIED]

        # For positive examples, increase their scores
        for _ in positive_examples:
            # Nudge intercept upward
            self.weights["intercept"] += learning_rate

        # For negative examples, decrease their scores
        for _ in negative_examples:
            # Nudge intercept downward
            self.weights["intercept"] -= learning_rate
