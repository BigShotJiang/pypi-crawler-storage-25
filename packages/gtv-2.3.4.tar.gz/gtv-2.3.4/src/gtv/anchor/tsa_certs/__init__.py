# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""TSA certificate bundle loader.

Provides access to trusted TSA root certificates for verification.
Certificates are read from PEM files at runtime.
"""
from __future__ import annotations

from pathlib import Path

from cryptography import x509


def load(name: str) -> bytes:
    """Load a TSA certificate bundle by name.

    Args:
        name: Certificate name (e.g., "freetsa" or "digicert")

    Returns:
        Raw PEM certificate bytes

    Raises:
        FileNotFoundError: If the certificate file does not exist
    """
    cert_dir = Path(__file__).parent
    cert_file = cert_dir / f"{name}.pem"

    if not cert_file.exists():
        raise FileNotFoundError(f"Certificate bundle not found: {cert_file}")

    return cert_file.read_bytes()


def load_chain(name: str) -> list[x509.Certificate]:
    """Load and parse a TSA certificate chain by name.

    Args:
        name: Certificate name (e.g., "freetsa" or "digicert")

    Returns:
        List of parsed X.509 certificates from the PEM file

    Raises:
        FileNotFoundError: If the certificate file does not exist
        ValueError: If the PEM content cannot be parsed as X.509 certificates
    """
    pem_bytes = load(name)
    certs = x509.load_pem_x509_certificates(pem_bytes)
    if not certs:
        raise ValueError(f"No certificates found in {name}.pem")
    return certs
