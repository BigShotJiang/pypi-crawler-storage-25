# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""RFC 8785 JSON Canonicalization Scheme (JCS).

Every envelope is signed over the output of `canonicalize`. The same bytes
are uploaded to Rekor and hashed for the RFC 3161 TimeStampReq. Bit-exact
reproducibility is a hard requirement — see tests/test_canonicalize.py.
"""
from __future__ import annotations

import hashlib
import json
import math
from typing import Any

from pydantic import BaseModel


def _validate_string(s: str) -> None:
    """Validate that a string contains no UTF-16 surrogate code points.

    RFC 8785 requires strings to be valid UTF-8. Surrogate code points
    (U+D800 through U+DFFF) are invalid UTF-8 and cannot be encoded.
    Reject them at validation time with a clear error.
    """
    for char in s:
        code = ord(char)
        if 0xD800 <= code <= 0xDFFF:
            raise ValueError(
                f"String contains invalid UTF-16 surrogate code point U+{code:04X}. "
                "Surrogate characters cannot be encoded to UTF-8."
            )


def _canonicalize_value(value: Any) -> Any:
    """Recursively convert a value into its RFC 8785 canonical form.

    Rules (subset sufficient for our schemas):
    - Objects: keys sorted lexicographically by UTF-16 code unit.
    - Arrays: order preserved.
    - Strings: UTF-8 with the JSON string escaping Python's `json` already does.
    - Numbers: integers as integers; finite floats via Python's shortest
      round-trip repr (same as json.dumps on CPython; deterministic across
      3.12+ on every platform we ship on). Integer-valued floats are
      coerced to int so serialisation drops the ".0" — matching the ES6
      ToString shape RFC 8785 mandates.
    - NaN / Infinity: rejected outright. Signed payloads must be finite.
    - None → null; bool untouched.
    """
    if isinstance(value, dict):
        for k in value:
            _validate_string(k)
        return {k: _canonicalize_value(value[k]) for k in sorted(value.keys())}
    if isinstance(value, list | tuple):
        return [_canonicalize_value(v) for v in value]
    if isinstance(value, bool) or value is None:
        return value
    if isinstance(value, str):
        _validate_string(value)
        return value
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError(
                "NaN and Infinity are not permitted in signed payloads."
            )
        if value.is_integer():
            return int(value)
        return value
    # BaseModel → dict recursively
    if isinstance(value, BaseModel):
        return _canonicalize_value(value.model_dump(mode="json"))
    raise TypeError(f"Non-canonicalisable type in signed payload: {type(value)!r}")


def canonicalize(obj: Any) -> bytes:
    """Return the RFC 8785 canonical JSON byte representation."""
    canonical = _canonicalize_value(obj)
    return json.dumps(
        canonical,
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=False,  # we already sorted recursively
        allow_nan=False,
    ).encode("utf-8")


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def envelope_canonical_sha256(envelope: BaseModel) -> str:
    """Hash the canonical form of an envelope, omitting signature fields.

    Signed-over payload = envelope minus {signature, rekor_uuid, rekor_log_index,
    tsa_token, anchor_proof, envelope_id, issued_at}. The issuer populates these
    after signing; the verifier re-hashes the remaining canonical form to check.

    Backward-compat: lifecycle fields (supersedes, supersede_reason) are stripped
    when at their defaults (empty list / None) so pre-W28 envelopes hash
    identically. Once either is set, both are included in the hash, making
    lifecycle links tamper-evident.
    """
    dumped = envelope.model_dump(mode="json")
    for stripped in (
        "signature",
        "rekor_uuid",
        "rekor_log_index",
        "tsa_token",
        "anchor_proof",
        "envelope_id",
        "issued_at",
    ):
        dumped.pop(stripped, None)
    # Lifecycle fields: only include in the hash when actually used.
    if dumped.get("supersedes") == []:
        dumped.pop("supersedes", None)
    if dumped.get("supersede_reason") is None:
        dumped.pop("supersede_reason", None)
    return sha256(canonicalize(dumped))
