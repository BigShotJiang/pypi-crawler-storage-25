# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Sigstore keyless signing.

Week 1 provides a minimal wrapper around the `sigstore` Python client so that
the verdict engine can sign a canonical payload hash without the callers
caring about OIDC flows. Real signing is gated on the environment variable
`GTV_SIGSTORE_ENABLED=1` — in tests we fall back to a deterministic stub
that produces a clearly-marked `stub://` signature value so that verification
regressions show up loudly rather than silently "passing".

This is deliberately small. Agents extending it must not leak long-lived
private keys into the codebase. Everything keyless, always.

The signing flow is "bundled" — when real Sigstore signing is enabled,
`sign_hash()` returns both the SignatureBundle AND the RekorEntry (since the
sigstore library submits to Rekor automatically during signing). The caller
(mcp/server.py::_seal_envelope) handles unpacking both results.
"""
from __future__ import annotations

import hashlib
import os
from dataclasses import dataclass
from typing import NamedTuple


@dataclass(frozen=True)
class SignatureBundle:
    """What we hand to Rekor and carry in the envelope."""
    signature_b64: str
    certificate_pem: str
    signing_algorithm: str = "ECDSA_P256_SHA256"
    bundle_format: str = "sigstore-bundle-v1"


# Import RekorEntry for type hints. Both code paths (stub + real) always
# populate it; callers can treat it as non-optional.
from gtv.anchor.rekor import RekorEntry  # noqa: E402


class SigningResult(NamedTuple):
    """Result of a signing operation: signature + Rekor entry (always present)."""
    signature_bundle: SignatureBundle
    rekor_entry: RekorEntry


def sign_hash(canonical_hash_hex: str) -> SigningResult:
    """Sign a hex SHA-256 hash. Returns a SigningResult with signature + optional Rekor entry.

    Routes to real Sigstore when `GTV_SIGSTORE_ENABLED=1`, otherwise a
    deterministic stub for local dev / CI. The stub is *not* verifiable;
    tests that call this must assert that behaviour explicitly.

    When real signing is enabled, the Rekor entry is produced as a side-effect
    of the signing process (the sigstore library submits to Rekor internally).
    """
    if os.environ.get("GTV_SIGSTORE_ENABLED") == "1":
        return _sign_with_sigstore(canonical_hash_hex)
    return _sign_stub(canonical_hash_hex)


def _sign_stub(canonical_hash_hex: str) -> SigningResult:
    """Deterministic stub for local dev / CI when signing is disabled."""
    digest = hashlib.sha256(canonical_hash_hex.encode("utf-8")).hexdigest()
    stub_bundle = SignatureBundle(
        signature_b64=f"stub://{digest}",
        certificate_pem="stub://dev-cert",
        signing_algorithm="STUB",
        bundle_format="stub-v0",
    )
    stub_entry = RekorEntry(
        uuid=f"stub-{canonical_hash_hex[:16]}",
        log_index=0,
        inclusion_proof=f"stub://{canonical_hash_hex}",
    )
    return SigningResult(signature_bundle=stub_bundle, rekor_entry=stub_entry)


def _sign_with_sigstore(canonical_hash_hex: str) -> SigningResult:
    """Keyless OIDC sign path using ambient credentials, with automatic Rekor submission.

    Uses the Sigstore Python library with ambient OIDC identity. By default,
    routes to the Sigstore staging instance unless GTV_SIGSTORE_PROD=1 is set.

    Trusted OIDC issuers (Sigstore staging defaults):
    - GitHub Actions (https://token.actions.githubusercontent.com)
    - Google Cloud (https://accounts.google.com, via Workload Identity)
    - Kubernetes (https://kubernetes.default.svc)
    - Spiffe (spiffe://*) via trust-on-first-use

    Environment flags:
    - GTV_SIGSTORE_ENABLED=1: Enable real signing (required)
    - GTV_SIGSTORE_PROD=1: Use production instance (default: staging)
    - GTV_SIGSTORE_INTERACTIVE=1: Allow interactive OAuth device flow
      (default: fail if no ambient token available)

    The sigstore library automatically submits to Rekor during signing.
    We extract the Rekor entry (uuid, log_index, inclusion_proof) from
    the returned Bundle and return both signature + Rekor metadata together.

    Raises:
    - IdentityError: If no ambient OIDC token available and interactive mode
      not enabled.
    - Any Sigstore library error: Real errors propagate loudly; we never
      silently fall back to stubs when the flag is on.
    """
    import base64

    from cryptography.hazmat.primitives import serialization
    from sigstore import oidc
    from sigstore.models import ClientTrustConfig
    from sigstore.sign import SigningContext

    # Determine staging vs production. ClientTrustConfig exposes the trust
    # roots for each Sigstore instance; SigningContext.from_trust_config
    # is the single documented entry point.
    use_prod = os.environ.get("GTV_SIGSTORE_PROD") == "1"
    trust_config = (
        ClientTrustConfig.production() if use_prod else ClientTrustConfig.staging()
    )
    signing_context = SigningContext.from_trust_config(trust_config)

    # Detect or obtain OIDC token.
    # sigstore.oidc.detect_credential can either return None (no ambient
    # context) or raise sigstore.oidc.IdentityError (context recognized but
    # unusable — e.g. GitHub Actions without id-token: write). Treat both
    # as "no usable token" and produce the same clean RuntimeError so
    # callers have one failure mode to handle.
    try:
        token_str = oidc.detect_credential()
    except oidc.IdentityError as e:
        token_str = None
        detect_error: Exception | None = e
    else:
        detect_error = None

    if token_str is None:
        # No ambient token; check if interactive mode is enabled.
        if os.environ.get("GTV_SIGSTORE_INTERACTIVE") != "1":
            raise RuntimeError(
                "No ambient OIDC token found and GTV_SIGSTORE_INTERACTIVE not set. "
                "Set GTV_SIGSTORE_INTERACTIVE=1 to enable device flow, or ensure "
                "OIDC token is available (GitHub Actions, Workload Identity, etc.)"
            ) from detect_error
        # Interactive flow: oidc.Issuer will handle device flow internally.
        # For now we require explicit token; full device flow is future work.
        raise RuntimeError(
            "Interactive device flow not yet implemented. "
            "Please provide an OIDC token via environment or CI runner."
        )

    identity_token = oidc.IdentityToken(token_str)

    # Convert hex hash to bytes and sign.
    # The sigstore library automatically submits the bundle to Rekor during this call.
    data_to_sign = bytes.fromhex(canonical_hash_hex)

    # Use the signing context to get a signer and produce the bundle.
    with signing_context.signer(identity_token) as signer:
        sigstore_bundle = signer.sign_artifact(data_to_sign)

    # Extract base64 signature and PEM certificate from the sigstore bundle.
    sig_bytes = sigstore_bundle.signature
    sig_b64 = base64.b64encode(sig_bytes).decode("ascii")

    cert_pem = sigstore_bundle.signing_certificate.public_bytes(
        serialization.Encoding.PEM
    ).decode("utf-8")

    sig_bundle = SignatureBundle(
        signature_b64=sig_b64,
        certificate_pem=cert_pem,
        signing_algorithm="ECDSA_P256_SHA256",
        bundle_format="sigstore-bundle-v1",
    )

    # Extract Rekor entry from the sigstore bundle.
    # The sigstore library already submitted to Rekor, so we just extract the metadata.
    # Pass the certificate PEM for inclusion in the proof (needed for offline verification).
    from gtv.anchor.rekor import RekorClient
    rekor_client = RekorClient()
    rekor_entry = rekor_client.extract_entry_from_bundle(
        sigstore_bundle,
        certificate_pem=cert_pem,
    )

    return SigningResult(signature_bundle=sig_bundle, rekor_entry=rekor_entry)
