# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""RFC 3161 Time-Stamp Authority clients — FreeTSA primary, DigiCert secondary.

Two independent TSAs so that a single outage cannot block envelope issuance.
The envelope carries the primary TSR and, when available, the secondary TSR.
Verification requires at least one valid TSR.
"""
from __future__ import annotations

import base64
import hashlib
import logging
import os
from dataclasses import dataclass
from datetime import UTC, datetime

import httpx
from rfc3161_client import (
    HashAlgorithm,
    TimestampRequestBuilder,
    decode_timestamp_response,
)

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class TimestampToken:
    tsr_b64: str
    authority: str
    issued_at: datetime | None = None


class RFC3161Client:
    def __init__(
        self,
        *,
        primary_url: str | None = None,
        secondary_url: str | None = None,
        timeout: float = 5.0,
    ) -> None:
        self.primary_url = primary_url or os.environ.get(
            "GTV_TSA_PRIMARY_URL", "https://freetsa.org/tsr"
        )
        self.secondary_url = secondary_url or os.environ.get(
            "GTV_TSA_SECONDARY_URL", "http://timestamp.digicert.com"
        )
        self.timeout = timeout

    async def timestamp(self, data: bytes) -> tuple[TimestampToken, TimestampToken | None]:
        """Obtain a primary + (best-effort) secondary timestamp token.

        When GTV_TSA_ENABLED=1:
          1. Submits a TimeStampRequest to the primary TSA (FreeTSA).
          2. Attempts secondary TSA (DigiCert) on best-effort basis.
          3. Returns (primary, secondary) where secondary may be None if it fails.
          4. If primary fails, raises RuntimeError loudly.
          5. If secondary fails, logs WARN and returns (primary, None).

        When GTV_TSA_ENABLED is not set:
          Returns stub tokens for local dev / CI.
        """
        if os.environ.get("GTV_TSA_ENABLED") != "1":
            stub_digest = hashlib.sha256(data).hexdigest()
            issued_at = datetime.now(tz=UTC)
            return (
                TimestampToken(
                    tsr_b64=base64.b64encode(f"stub-primary:{stub_digest}".encode()).decode(),
                    authority=self.primary_url,
                    issued_at=issued_at,
                ),
                TimestampToken(
                    tsr_b64=base64.b64encode(f"stub-secondary:{stub_digest}".encode()).decode(),
                    authority=self.secondary_url,
                    issued_at=issued_at,
                ),
            )

        # Real RFC 3161 flow: request both TSAs
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            # Primary TSA (required)
            primary = await self._request_tsa(client, self.primary_url, data, is_primary=True)

            # Secondary TSA (best-effort)
            secondary = None
            try:
                secondary = await self._request_tsa(
                    client, self.secondary_url, data, is_primary=False
                )
            except Exception as e:
                logger.warning(
                    "Secondary TSA request failed (non-fatal)",
                    extra={"tsa_url": self.secondary_url, "error": str(e)},
                )

            return (primary, secondary)

    async def _request_tsa(
        self,
        client: httpx.AsyncClient,
        tsa_url: str,
        data: bytes,
        is_primary: bool = False,
    ) -> TimestampToken:
        """Request a timestamp from a single TSA.

        Args:
            client: HTTP client instance
            tsa_url: TSA endpoint URL
            data: Raw data to timestamp (will be SHA256-hashed)
            is_primary: If True, raises on failure; if False, failure is logged

        Returns:
            TimestampToken with base64-encoded TSR

        Raises:
            RuntimeError: If primary TSA fails or on any TSP parsing error
            httpx.HTTPError: If request fails (wrapped in RuntimeError if primary)
        """
        try:
            # Build RFC 3161 TimeStampRequest with SHA256 hash
            ts_req = (
                TimestampRequestBuilder(data=data, hash_algorithm=HashAlgorithm.SHA256)
                .build()
            )

            # POST to TSA with proper content-type
            resp = await client.post(
                tsa_url,
                content=ts_req.as_bytes(),
                headers={"Content-Type": "application/timestamp-query"},
            )
            resp.raise_for_status()

            # Parse TimeStampResponse
            ts_resp = decode_timestamp_response(resp.content)

            # Extract the timestamp token (binary) and base64-encode it
            tsr_bytes = ts_resp.time_stamp_token()
            tsr_b64 = base64.b64encode(tsr_bytes).decode("ascii")

            # Extract issued_at from TST info if available
            issued_at = None
            try:
                if ts_resp.tst_info is not None:
                    # tst_info has a gen_time property (datetime)
                    issued_at = ts_resp.tst_info.gen_time
            except Exception:
                pass

            return TimestampToken(tsr_b64=tsr_b64, authority=tsa_url, issued_at=issued_at)

        except Exception as e:
            msg = f"TSA request failed to {tsa_url}: {e!s}"
            if is_primary:
                logger.error(msg, extra={"tsa_url": tsa_url})
                raise RuntimeError(msg) from e
            else:
                logger.warning(msg, extra={"tsa_url": tsa_url})
                raise
