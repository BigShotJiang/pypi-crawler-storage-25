# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Envelope anchoring: canonical JSON, signing, Rekor, RFC 3161 TSAs."""
