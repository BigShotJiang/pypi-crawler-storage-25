# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Rekor consistency proof verification (RFC 6962 §2.1.4.2 / RFC 9162 §2.1.4.2).

Rekor anchors every envelope into an append-only Merkle transparency log. An
inclusion proof (already implemented in `gtv-verify`) proves a single envelope
sits in the tree at a given checkpoint. A *consistency* proof proves something
stronger: that the log wasn't forked or rewritten between two checkpoints. If
the log operator silently rebuilt the tree to drop an entry, any prior
checkpoint pinned by a verifier would fail the consistency check.

The algorithm below is the RFC 6962 canonical verifier. The generator is
included for tests — we build a tree ourselves, ask for the proof, and check
the verifier agrees. No third-party dep.

Usage:

    from gtv.anchor.consistency import verify_consistency_proof

    verify_consistency_proof(
        first_size=42,
        second_size=177,
        first_root=bytes.fromhex(pinned_root_hex),
        second_root=bytes.fromhex(current_root_hex),
        proof=[bytes.fromhex(h) for h in rekor_proof_hashes],
    )

Raises `ConsistencyProofError` if the log has been tampered with.
"""
from __future__ import annotations

import hashlib
from collections.abc import Iterator


class ConsistencyProofError(Exception):
    """Raised when a Rekor consistency proof does not verify."""


# ---------------------------------------------------------------------------
# RFC 6962 hashing primitives
# ---------------------------------------------------------------------------

def _leaf_hash(data: bytes) -> bytes:
    """RFC 6962 leaf hash: SHA-256(0x00 || data)."""
    return hashlib.sha256(b"\x00" + data).digest()


def _node_hash(left: bytes, right: bytes) -> bytes:
    """RFC 6962 internal-node hash: SHA-256(0x01 || left || right)."""
    return hashlib.sha256(b"\x01" + left + right).digest()


# ---------------------------------------------------------------------------
# Verifier
# ---------------------------------------------------------------------------

def verify_consistency_proof(
    *,
    first_size: int,
    second_size: int,
    first_root: bytes,
    second_root: bytes,
    proof: list[bytes],
) -> None:
    """Verify a Rekor consistency proof between two checkpoints.

    This is the canonical RFC 6962 §2.1.4.2 algorithm. It reconstructs both
    the old and the new roots from the supplied proof hashes and checks they
    match the supplied roots. If either check fails, the log has been forked
    or rewritten between the two checkpoints.

    Args:
        first_size: Tree size at the earlier (pinned) checkpoint.
        second_size: Tree size at the later checkpoint. Must be >= first_size.
        first_root: Root hash at the earlier checkpoint (32 bytes).
        second_root: Root hash at the later checkpoint (32 bytes).
        proof: Ordered list of sibling hashes from the log operator, each
            32 bytes. May be empty when first_size == second_size or
            first_size == 0.

    Raises:
        ConsistencyProofError: On any mismatch.
    """
    if first_size < 0 or second_size < 0:
        raise ConsistencyProofError("Tree sizes must be non-negative")
    if second_size < first_size:
        raise ConsistencyProofError(
            f"second_size ({second_size}) < first_size ({first_size})"
        )
    if len(first_root) != 32 or len(second_root) != 32:
        raise ConsistencyProofError("Root hashes must be 32 bytes")
    for i, h in enumerate(proof):
        if len(h) != 32:
            raise ConsistencyProofError(f"proof[{i}] is not 32 bytes")

    # Trivial cases.
    if first_size == second_size:
        if proof:
            raise ConsistencyProofError(
                "Proof must be empty when first_size == second_size"
            )
        if first_root != second_root:
            raise ConsistencyProofError(
                "Roots differ at identical tree size — log has been rewritten"
            )
        return

    if first_size == 0:
        # The empty tree is a prefix of anything. No proof data is required.
        if proof:
            raise ConsistencyProofError(
                "Proof must be empty when first_size == 0"
            )
        return

    if not proof:
        raise ConsistencyProofError("Non-trivial proof is empty")

    # Walk the path. See RFC 6962 §2.1.4.2.
    node = first_size - 1
    last_node = second_size - 1

    # Peel off common trailing 1-bits.
    while node & 1:
        node >>= 1
        last_node >>= 1

    proof_iter: Iterator[bytes] = iter(proof)

    try:
        seed = next(proof_iter) if node > 0 else first_root

        old_hash = seed
        new_hash = seed

        while node > 0:
            if node & 1:
                # We're a right child: sibling is on the left in both trees.
                sibling = next(proof_iter)
                old_hash = _node_hash(sibling, old_hash)
                new_hash = _node_hash(sibling, new_hash)
            elif node < last_node:
                # We're a left child AND a right subtree exists in the new
                # tree: sibling contributes only to the new root.
                sibling = next(proof_iter)
                new_hash = _node_hash(new_hash, sibling)
            # else: we're a left child with no right sibling at this level —
            # consume nothing, just ascend.

            node >>= 1
            last_node >>= 1

        # After old_hash settles, keep climbing the new tree until we reach
        # its root, consuming remaining proof hashes as right siblings.
        while last_node > 0:
            sibling = next(proof_iter)
            new_hash = _node_hash(new_hash, sibling)
            last_node >>= 1

        # All proof hashes must be consumed exactly.
        try:
            leftover = next(proof_iter)
        except StopIteration:
            pass
        else:
            del leftover
            raise ConsistencyProofError(
                "Proof contains unused hashes — log operator sent too much"
            )

    except StopIteration as e:
        raise ConsistencyProofError(
            "Proof is truncated — log operator sent too little"
        ) from e

    if old_hash != first_root:
        raise ConsistencyProofError(
            f"Reconstructed first root {old_hash.hex()} does not match "
            f"supplied first root {first_root.hex()} — log forked"
        )
    if new_hash != second_root:
        raise ConsistencyProofError(
            f"Reconstructed second root {new_hash.hex()} does not match "
            f"supplied second root {second_root.hex()} — log forked"
        )


# ---------------------------------------------------------------------------
# Reference merkle tree (used by tests and by --generate in the CLI)
# ---------------------------------------------------------------------------

def merkle_root(leaves: list[bytes]) -> bytes:
    """Compute the RFC 6962 Merkle root over `leaves`.

    `leaves` is a list of already-hashed leaf nodes (32 bytes each) OR raw
    leaf data — we detect by length. To stay unambiguous, callers should
    pass pre-hashed leaves produced by `_leaf_hash` or the module-level
    helper `leaf_hash`.
    """
    if not leaves:
        return hashlib.sha256(b"").digest()
    return _subtree_root(leaves, 0, len(leaves))


def _largest_power_of_two_strictly_less_than(n: int) -> int:
    """Largest 2^k with 2^k < n. Used for RFC 6962 tree splitting."""
    if n <= 1:
        raise ValueError("n must be > 1")
    k = 1
    while (k << 1) < n:
        k <<= 1
    return k


def _subtree_root(leaves: list[bytes], lo: int, hi: int) -> bytes:
    """Root of the RFC 6962 subtree over leaves[lo:hi]."""
    n = hi - lo
    if n == 1:
        return leaves[lo]
    k = _largest_power_of_two_strictly_less_than(n)
    left = _subtree_root(leaves, lo, lo + k)
    right = _subtree_root(leaves, lo + k, hi)
    return _node_hash(left, right)


def generate_consistency_proof(leaves: list[bytes], first_size: int) -> list[bytes]:
    """Generate an RFC 6962 consistency proof from leaves[0:first_size] to leaves[0:second_size].

    Exists so tests can build a known-correct proof without standing up a real
    Rekor. Not used in production paths; Rekor generates its own proofs.

    `leaves` is a list of pre-hashed leaf nodes (32 bytes each); `second_size`
    is implicit as `len(leaves)`.
    """
    second_size = len(leaves)
    if first_size < 0 or first_size > second_size:
        raise ValueError(
            f"first_size {first_size} out of range [0, {second_size}]"
        )
    if first_size in (0, second_size):
        return []
    return _subproof(leaves, 0, second_size, first_size, starting_from_old_root=True)


def _subproof(
    leaves: list[bytes],
    lo: int,
    hi: int,
    m: int,
    *,
    starting_from_old_root: bool,
) -> list[bytes]:
    """RFC 6962 §2.1.2 SUBPROOF recursion.

    Returns the consistency subproof for a subtree covering leaves[lo:hi]
    assuming the old tree contained the first `m` leaves of this subtree.
    """
    n = hi - lo
    if m == n:
        # Complete subtree — either omit (old root already known) or include it.
        if starting_from_old_root:
            return []
        return [_subtree_root(leaves, lo, hi)]

    k = _largest_power_of_two_strictly_less_than(n)
    if m <= k:
        # Old tree lives entirely in the left subtree; include right subtree's root.
        inner = _subproof(leaves, lo, lo + k, m, starting_from_old_root=starting_from_old_root)
        return [*inner, _subtree_root(leaves, lo + k, hi)]
    # Old tree spans into the right subtree; left subtree's root goes into the proof.
    inner = _subproof(leaves, lo + k, hi, m - k, starting_from_old_root=False)
    return [*inner, _subtree_root(leaves, lo, lo + k)]


# Public re-export for tests / CLI.
leaf_hash = _leaf_hash
