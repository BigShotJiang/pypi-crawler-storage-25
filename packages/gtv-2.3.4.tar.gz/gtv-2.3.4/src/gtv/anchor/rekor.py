# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Rekor transparency log client.

The Sigstore Python library handles Rekor submission automatically as part of
the signing process (sigstore.sign.Signer.sign_artifact calls the RekorLogSubmitter
internally). This module extracts the resulting Rekor entry fields from the
Bundle returned by signing, so the envelope can be populated with:
- uuid: the Rekor entry UUID
- log_index: the transparency log entry index
- inclusion_proof: JSON serialization of the inclusion proof (hashes + checkpoint)

Also provides Rekor log-root verification: loading the trusted public key,
verifying checkpoint signatures, and detecting placeholder keys.
"""
from __future__ import annotations

import base64
import hashlib
import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any

from cryptography import x509
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization

if TYPE_CHECKING:
    from sigstore.models import Bundle


class RekorTrustError(Exception):
    """Raised when Rekor log root verification fails."""

    pass


@dataclass(frozen=True)
class RekorEntry:
    uuid: str
    log_index: int
    inclusion_proof: str
    # Raw canonicalized hashedrekord body bytes as Rekor hashed them. When
    # populated from a real sigstore.Bundle, these are the authoritative bytes
    # whose sha256(0x00 || body) is the merkle leaf. None for stub entries.
    canonical_body: bytes | None = None


class RekorClient:
    """Rekor integration via Sigstore bundle (no-op when GTV_REKOR_ENABLED).

    Since the sigstore library submits to Rekor automatically during signing,
    this class is a passthrough that extracts Rekor metadata from the already-
    submitted Bundle.
    """

    def __init__(self, base_url: str | None = None, timeout: float = 10.0) -> None:
        # base_url and timeout are kept for API compatibility, but unused
        # since submission happens inside sigstore.sign.Signer.sign_artifact.
        self.base_url = base_url or os.environ.get(
            "GTV_REKOR_URL", "https://rekor.sigstore.dev"
        )
        self.timeout = timeout

    def extract_entry_from_bundle(
        self,
        bundle: Bundle | Any,
        certificate_pem: str | None = None,
    ) -> RekorEntry:
        """Extract Rekor entry UUID, log_index, and proof from a signed Bundle.

        The Bundle's log_entry property contains:
        - log_id: identifies which Rekor instance
        - log_index: position in the transparency log
        - inclusion_proof: merkle tree proof with checkpoint

        The inclusion_proof JSON also includes the signing certificate (PEM)
        for offline signature verification.

        Args:
            bundle: Sigstore Bundle (or stub) with log_entry.
            certificate_pem: Optional certificate PEM. If not provided and the
                bundle is real, extracted from bundle.signing_certificate.
        """
        log_entry = bundle.log_entry
        log_index = log_entry._inner.log_index

        # Extract inclusion_proof (merkle tree + checkpoint).
        inclusion_proof_obj = log_entry._inner.inclusion_proof
        proof_dict = {
            "log_index": inclusion_proof_obj.log_index,
            "tree_size": inclusion_proof_obj.tree_size,
            "root_hash": inclusion_proof_obj.root_hash.hex() if inclusion_proof_obj.root_hash else "",
            "hashes": [h.hex() for h in inclusion_proof_obj.hashes] if inclusion_proof_obj.hashes else [],
        }
        if inclusion_proof_obj.checkpoint:
            proof_dict["checkpoint"] = inclusion_proof_obj.checkpoint.envelope

        # Include certificate for offline verification.
        if certificate_pem:
            proof_dict["certificate_pem"] = certificate_pem
        elif hasattr(bundle, "signing_certificate") and bundle.signing_certificate:
            # Extract from real bundle if available.
            cert_pem = bundle.signing_certificate.public_bytes(
                serialization.Encoding.PEM
            ).decode("utf-8")
            proof_dict["certificate_pem"] = cert_pem

        inclusion_proof_json = json.dumps(proof_dict, sort_keys=True)

        # For the UUID, we use the log_index as a stable identifier.
        # The actual Rekor entry UUID would come from the API response,
        # but the log_index is the primary lookup key and unique per log.
        uuid = f"rekor-entry-{log_index}"

        # Rekor returns the already-canonicalized body in the API response;
        # sigstore-python stashes it on `_inner.canonicalized_body`. These are
        # the authoritative bytes for merkle-leaf hashing — any client-side
        # reconstruction is a guess at Rekor's canonicalization rules.
        canonical_body = getattr(log_entry._inner, "canonicalized_body", None)

        return RekorEntry(
            uuid=uuid,
            log_index=log_index,
            inclusion_proof=inclusion_proof_json,
            canonical_body=canonical_body,
        )


def load_rekor_public_key(staging: bool = False) -> bytes:
    """Load the Rekor public key from the rekor_keys/ directory.

    The public key should be an ECDSA P-256 or Ed25519 public key in PEM format.
    Production uses ECDSA P-256.

    Args:
        staging: If True, load the staging key; otherwise load production.

    Returns:
        The PEM-encoded public key as bytes.

    Raises:
        RekorTrustError: If the key is not found, is still a placeholder, or is invalid.
    """
    key_name = "rekor_staging.pub" if staging else "rekor_prod.pub"
    key_dir = Path(__file__).parent / "rekor_keys"
    key_path = key_dir / key_name

    if not key_path.exists():
        raise RekorTrustError(
            f"Rekor public key not found: {key_path}. "
            "Run with --allow-unrooted for dev."
        )

    key_bytes = key_path.read_bytes()

    # Check if this is still a placeholder (contains "TODO" or is very small).
    # ECDSA P-256 public keys in PEM are ~178 bytes, Ed25519 are ~100-150 bytes.
    # Use 50 as a threshold to catch obvious placeholders.
    if b"TODO" in key_bytes or len(key_bytes) < 50:
        raise RekorTrustError(
            f"Rekor public key not provisioned in {key_path}; "
            "run with --allow-unrooted for dev."
        )

    return key_bytes


def verify_log_root_signature(
    checkpoint: str,
    log_public_key_pem: bytes | None = None,
    *,
    rekor_staging: bool = False,
) -> None:
    """Verify a signed Rekor checkpoint against sigstore's trusted Rekor keyring.

    Delegates c2sp checkpoint parsing + signature verification to sigstore-python's
    ``SignedCheckpoint`` (handles the ``\\u2014`` em-dash signature block format used
    by Rekor v2 / tile-based logs). The log's public key is looked up from sigstore's
    bundled TrustedRoot by matching the checkpoint's origin to the trusted log's
    ``base_url``, so key rotations in Rekor propagate as sigstore-python updates
    rather than requiring us to re-bundle keys.

    Args:
        checkpoint: The full signed checkpoint text (multi-line, c2sp format).
        log_public_key_pem: *Deprecated*, unused. Kept for backward compat with
            pre-v2.3.4 callers. The log key is now sourced from sigstore's
            trust root, not from a PEM file.
        rekor_staging: If True, use sigstore's staging trust root; otherwise
            production. Must match the Rekor instance that produced the entry.

    Raises:
        RekorTrustError: If the checkpoint cannot be parsed, no trusted log in
            the configured trust root matches the checkpoint origin, or the
            signature fails to verify.
    """
    # log_public_key_pem is now sourced from sigstore's trust root; the parameter
    # is kept only to avoid breaking existing callers. A future release can drop it.
    _ = log_public_key_pem

    # Imports are inside the function so the module stays importable in
    # environments where sigstore internals shift between minor versions.
    try:
        from sigstore._internal.rekor.checkpoint import SignedCheckpoint
        from sigstore._internal.trust import KeyringPurpose
        from sigstore._utils import KeyID
        from sigstore.models import ClientTrustConfig
    except ImportError as e:
        raise RekorTrustError(
            f"Cannot import sigstore checkpoint verification internals: {e}"
        ) from e

    try:
        signed_checkpoint = SignedCheckpoint.from_text(checkpoint)
    except Exception as e:
        raise RekorTrustError(f"Cannot parse checkpoint: {e}") from e

    origin = signed_checkpoint.checkpoint.origin

    try:
        cfg = ClientTrustConfig.staging() if rekor_staging else ClientTrustConfig.production()
        keyring = cfg.trusted_root.rekor_keyring(KeyringPurpose.VERIFY)
    except Exception as e:
        raise RekorTrustError(
            f"Failed to load sigstore {'staging' if rekor_staging else 'production'} "
            f"trust root: {e}"
        ) from e

    target_log_id: Any = None
    for tlog in cfg.trusted_root._inner.tlogs:
        # Match by exact origin or substring — Rekor sometimes strips the scheme.
        if origin in tlog.base_url or tlog.base_url.endswith(origin):
            target_log_id = KeyID(tlog.log_id.key_id)
            break

    if target_log_id is None:
        raise RekorTrustError(
            f"No trusted log in {'staging' if rekor_staging else 'production'} "
            f"trust root matches checkpoint origin {origin!r}"
        )

    try:
        signed_checkpoint.signed_note.verify(keyring, target_log_id)
    except Exception as e:
        raise RekorTrustError(f"Checkpoint signature verification failed: {e}") from e


def hashedrekord_leaf_hash(
    canonical_hash_hex: str,
    signature_b64: str,
    certificate_pem: str,
) -> bytes:
    """Compute the Rekor merkle-tree leaf hash for a hashedrekord v0.0.1 entry.

    A Rekor merkle leaf is ``sha256(0x00 || canonicalized_body)`` where the
    canonicalized body is the JCS-canonical (RFC 8785) JSON serialization of
    the hashedrekord v0.0.1 schema:

    .. code-block:: json

        {
          "apiVersion": "0.0.1",
          "kind": "hashedrekord",
          "spec": {
            "data":      { "hash": { "algorithm": "sha256", "value": "<hex>" } },
            "signature": { "content": "<sig b64>",
                           "publicKey": { "content": "<PEM b64>" } }
          }
        }

    The "canonicalized" part matters: alphabetically sorted keys, no whitespace.
    Rekor stores exactly these bytes as the leaf. Our previous verifier used
    ``sha256(0x00 || canonical_hash_bytes)`` as a "pragmatic simplification",
    which produced a different leaf and so a different computed merkle root —
    any real inclusion proof we fetched from Rekor failed to reconstruct.

    Args:
        canonical_hash_hex: Hex SHA-256 of the canonical envelope (what was
            signed). Goes in ``spec.data.hash.value``.
        signature_b64: Base64 of the raw signature bytes. Goes in
            ``spec.signature.content``.
        certificate_pem: PEM-encoded signing certificate (including the
            ``-----BEGIN CERTIFICATE-----`` header). Gets base64-wrapped and
            placed in ``spec.signature.publicKey.content``.

    Returns:
        The 32-byte leaf hash.

    Raises:
        ValueError: If the certificate PEM is malformed.
    """
    # Validate the cert parses (Rekor does). We don't use the parsed object
    # further; the body puts the PEM text (base64-wrapped).
    try:
        x509.load_pem_x509_certificate(certificate_pem.encode(), default_backend())
    except Exception as e:
        raise ValueError(f"certificate PEM is not valid: {e}") from e

    cert_b64 = base64.b64encode(certificate_pem.encode()).decode("ascii")

    body = {
        "apiVersion": "0.0.1",
        "kind": "hashedrekord",
        "spec": {
            "data": {
                "hash": {"algorithm": "sha256", "value": canonical_hash_hex},
            },
            "signature": {
                "content": signature_b64,
                "publicKey": {"content": cert_b64},
            },
        },
    }

    # JCS-style canonicalization: sorted keys, no whitespace, UTF-8.
    canonical = json.dumps(body, separators=(",", ":"), sort_keys=True)
    return hashlib.sha256(b"\x00" + canonical.encode("utf-8")).digest()
