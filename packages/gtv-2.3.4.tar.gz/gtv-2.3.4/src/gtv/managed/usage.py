# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Usage tracking and snapshots.

Records tenant usage events (claims verified, peers added/removed) and
provides rolling-window snapshots for quota checking and billing.
"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta

from pydantic import BaseModel, Field


class UsageSnapshot(BaseModel):
    """A point-in-time snapshot of tenant usage."""

    tenant_id: str
    window_start: datetime
    window_end: datetime
    claims_verified: int = Field(ge=0, default=0)
    concurrent_verifies_peak: int = Field(ge=0, default=0)
    federation_peers_count: int = Field(ge=0, default=0)
    verdict_signatures_emitted: int = Field(ge=0, default=0)


# In-memory usage tracking bucketed by tenant_id and day
_daily_counters: dict[str, dict[str, int]] = {}
_peer_counters: dict[str, int] = {}
_concurrent_peak: dict[str, int] = {}


def record_claim_verified(tenant_id: str) -> None:
    """Increment claim verification count for today.

    Args:
        tenant_id: The tenant's UUID.
    """
    if tenant_id not in _daily_counters:
        _daily_counters[tenant_id] = {}

    today = datetime.now(tz=UTC).date().isoformat()
    if today not in _daily_counters[tenant_id]:
        _daily_counters[tenant_id][today] = 0

    _daily_counters[tenant_id][today] += 1


def record_peer_added(tenant_id: str) -> None:
    """Record federation peer addition.

    Args:
        tenant_id: The tenant's UUID.
    """
    if tenant_id not in _peer_counters:
        _peer_counters[tenant_id] = 0
    _peer_counters[tenant_id] += 1


def record_peer_removed(tenant_id: str) -> None:
    """Record federation peer removal.

    Args:
        tenant_id: The tenant's UUID.
    """
    if tenant_id not in _peer_counters:
        _peer_counters[tenant_id] = 0
    _peer_counters[tenant_id] = max(0, _peer_counters[tenant_id] - 1)


def record_concurrent_verify(tenant_id: str, count: int) -> None:
    """Record peak concurrent verifications.

    Args:
        tenant_id: The tenant's UUID.
        count: Current count of concurrent verifies.
    """
    if tenant_id not in _concurrent_peak:
        _concurrent_peak[tenant_id] = 0
    _concurrent_peak[tenant_id] = max(_concurrent_peak[tenant_id], count)


def snapshot(
    tenant_id: str,
    window: timedelta | None = None,
) -> UsageSnapshot:
    """Generate a usage snapshot for the given window.

    If window is None, defaults to the past 24 hours.
    Counts claims verified within [now - window, now].

    Args:
        tenant_id: The tenant's UUID.
        window: Time window (default 1 day).

    Returns:
        A UsageSnapshot with current usage metrics.
    """
    if window is None:
        window = timedelta(days=1)

    now = datetime.now(tz=UTC)
    window_start = now - window
    window_end = now

    # Count claims verified in this window
    claims = 0
    if tenant_id in _daily_counters:
        today = now.date().isoformat()
        if today in _daily_counters[tenant_id]:
            # For simplicity, count all claims from today that are before window_end
            # (more sophisticated window logic could be added)
            claims = _daily_counters[tenant_id][today]

    peers = _peer_counters.get(tenant_id, 0)
    concurrent_peak = _concurrent_peak.get(tenant_id, 0)

    return UsageSnapshot(
        tenant_id=tenant_id,
        window_start=window_start,
        window_end=window_end,
        claims_verified=claims,
        concurrent_verifies_peak=concurrent_peak,
        federation_peers_count=peers,
        verdict_signatures_emitted=0,  # Placeholder for future implementation
    )


def clear_usage(tenant_id: str | None = None) -> None:
    """Clear usage data (for testing).

    Args:
        tenant_id: If provided, clear only this tenant's data.
                   If None, clear all data.
    """
    global _daily_counters, _peer_counters, _concurrent_peak
    if tenant_id is None:
        _daily_counters = {}
        _peer_counters = {}
        _concurrent_peak = {}
    else:
        _daily_counters.pop(tenant_id, None)
        _peer_counters.pop(tenant_id, None)
        _concurrent_peak.pop(tenant_id, None)
