# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Tenant provisioning and lifecycle management.

Pydantic model for Tenant and backing store interfaces.
In-memory store provided for local dev; callers can implement their own
by subclassing TenantStore.
"""

from __future__ import annotations

import json
import uuid
from abc import ABC, abstractmethod
from datetime import UTC, datetime
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, EmailStr, Field


class Tenant(BaseModel):
    """A customer or organization using gtv in a managed deployment."""

    tenant_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str = Field(min_length=1, max_length=255)
    plan: Literal["free", "pro", "enterprise"]
    created_at: datetime = Field(default_factory=lambda: datetime.now(tz=UTC))
    status: Literal["active", "suspended", "churned"] = "active"
    contact_email: EmailStr
    billing_customer_id: str | None = None


class TenantStore(ABC):
    """Abstract base for tenant persistence — implement for your backing store."""

    @abstractmethod
    def create(self, tenant: Tenant) -> Tenant:
        """Persist a tenant and return it."""
        pass

    @abstractmethod
    def get(self, tenant_id: str) -> Tenant | None:
        """Retrieve a tenant by ID; return None if not found."""
        pass

    @abstractmethod
    def update(self, tenant: Tenant) -> Tenant:
        """Update an existing tenant."""
        pass

    @abstractmethod
    def list(
        self, plan: str | None = None, status: str | None = None
    ) -> list[Tenant]:
        """List tenants, optionally filtered by plan and/or status."""
        pass


class InMemoryTenantStore(TenantStore):
    """Simple in-memory store keyed by tenant_id."""

    def __init__(self) -> None:
        self._tenants: dict[str, Tenant] = {}

    def create(self, tenant: Tenant) -> Tenant:
        if tenant.tenant_id in self._tenants:
            raise ValueError(f"Tenant {tenant.tenant_id} already exists")
        self._tenants[tenant.tenant_id] = tenant
        return tenant

    def get(self, tenant_id: str) -> Tenant | None:
        return self._tenants.get(tenant_id)

    def update(self, tenant: Tenant) -> Tenant:
        if tenant.tenant_id not in self._tenants:
            raise ValueError(f"Tenant {tenant.tenant_id} not found")
        self._tenants[tenant.tenant_id] = tenant
        return tenant

    def list(
        self, plan: str | None = None, status: str | None = None
    ) -> list[Tenant]:
        result = list(self._tenants.values())
        if plan is not None:
            result = [t for t in result if t.plan == plan]
        if status is not None:
            result = [t for t in result if t.status == status]
        return result


class JsonFileTenantStore(TenantStore):
    """Persists tenants to a JSON file for local development."""

    def __init__(self, file_path: str | Path) -> None:
        self.file_path = Path(file_path)
        self._tenants: dict[str, Tenant] = {}
        self._load()

    def _load(self) -> None:
        """Load tenants from disk if file exists."""
        if self.file_path.exists():
            try:
                with open(self.file_path) as f:
                    data = json.load(f)
                    for tenant_id, tenant_dict in data.items():
                        # Rehydrate datetime objects from ISO strings
                        if isinstance(tenant_dict.get("created_at"), str):
                            tenant_dict["created_at"] = datetime.fromisoformat(
                                tenant_dict["created_at"]
                            )
                        self._tenants[tenant_id] = Tenant(**tenant_dict)
            except Exception:
                # If file is corrupted, start fresh
                self._tenants = {}

    def _save(self) -> None:
        """Persist tenants to disk."""
        self.file_path.parent.mkdir(parents=True, exist_ok=True)
        data = {}
        for tenant_id, tenant in self._tenants.items():
            tenant_dict = tenant.model_dump()
            # Serialize datetime to ISO string
            if isinstance(tenant_dict.get("created_at"), datetime):
                tenant_dict["created_at"] = tenant_dict["created_at"].isoformat()
            data[tenant_id] = tenant_dict
        with open(self.file_path, "w") as f:
            json.dump(data, f, indent=2)

    def create(self, tenant: Tenant) -> Tenant:
        if tenant.tenant_id in self._tenants:
            raise ValueError(f"Tenant {tenant.tenant_id} already exists")
        self._tenants[tenant.tenant_id] = tenant
        self._save()
        return tenant

    def get(self, tenant_id: str) -> Tenant | None:
        return self._tenants.get(tenant_id)

    def update(self, tenant: Tenant) -> Tenant:
        if tenant.tenant_id not in self._tenants:
            raise ValueError(f"Tenant {tenant.tenant_id} not found")
        self._tenants[tenant.tenant_id] = tenant
        self._save()
        return tenant

    def list(
        self, plan: str | None = None, status: str | None = None
    ) -> list[Tenant]:
        result = list(self._tenants.values())
        if plan is not None:
            result = [t for t in result if t.plan == plan]
        if status is not None:
            result = [t for t in result if t.status == status]
        return result


# Global store instance — swappable for testing/deployment
_store: TenantStore = InMemoryTenantStore()


def set_store(store: TenantStore) -> None:
    """Replace the global tenant store (for testing or deployment config)."""
    global _store
    _store = store


def get_store() -> TenantStore:
    """Retrieve the current tenant store."""
    return _store


# High-level provisioning API

def create_tenant(
    name: str,
    plan: Literal["free", "pro", "enterprise"],
    contact_email: str,
    billing_customer_id: str | None = None,
) -> Tenant:
    """Create and persist a new tenant.

    Args:
        name: Human-readable tenant name.
        plan: Pricing plan.
        contact_email: Contact email address.
        billing_customer_id: Optional opaque ID for external billing system.

    Returns:
        The created Tenant.

    Raises:
        ValueError: If email is invalid or tenant creation fails.
    """
    tenant = Tenant(
        name=name,
        plan=plan,
        contact_email=contact_email,
        billing_customer_id=billing_customer_id,
    )
    return _store.create(tenant)


def get_tenant(tenant_id: str) -> Tenant | None:
    """Retrieve a tenant by ID.

    Args:
        tenant_id: The tenant's UUID.

    Returns:
        The Tenant, or None if not found.
    """
    return _store.get(tenant_id)


def suspend_tenant(tenant_id: str) -> Tenant:
    """Suspend a tenant's access.

    Args:
        tenant_id: The tenant's UUID.

    Returns:
        The updated Tenant.

    Raises:
        ValueError: If tenant not found.
    """
    tenant = _store.get(tenant_id)
    if tenant is None:
        raise ValueError(f"Tenant {tenant_id} not found")
    tenant.status = "suspended"
    return _store.update(tenant)


def reactivate_tenant(tenant_id: str) -> Tenant:
    """Reactivate a suspended tenant.

    Args:
        tenant_id: The tenant's UUID.

    Returns:
        The updated Tenant.

    Raises:
        ValueError: If tenant not found.
    """
    tenant = _store.get(tenant_id)
    if tenant is None:
        raise ValueError(f"Tenant {tenant_id} not found")
    tenant.status = "active"
    return _store.update(tenant)


def list_tenants(
    plan: str | None = None, status: str | None = None
) -> list[Tenant]:
    """List tenants with optional filtering.

    Args:
        plan: Filter by plan ("free", "pro", "enterprise"); None for all.
        status: Filter by status ("active", "suspended", "churned"); None for all.

    Returns:
        List of matching Tenants.
    """
    return _store.list(plan=plan, status=status)
