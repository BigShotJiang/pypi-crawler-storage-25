# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Quota model and enforcement logic.

Each plan has fixed quotas across three dimensions:
- claims_per_day: number of claim verifications allowed per day
- concurrent_verifies: max simultaneous verify operations
- federation_peers: max number of federation peers allowed
- burst_multiplier: temporary surge allowance (e.g., 1.5x for 10% of time)

Hard-coded quotas for free/pro/enterprise plans.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from pydantic import BaseModel, Field

from gtv.managed.tenants import Tenant


class PlanQuota(BaseModel):
    """Quotas for a pricing plan."""

    plan: str = Field(min_length=1)
    max_claims_per_day: int = Field(gt=0)
    max_concurrent_verifies: int = Field(gt=0)
    max_federation_peers: int = Field(ge=0)
    burst_multiplier: float = Field(gt=1.0, default=1.5)


@dataclass
class QuotaCheckResult:
    """Result of a quota check."""

    allowed: bool
    reason: str | None = None
    headroom: dict[str, float] = field(default_factory=dict)  # % remaining per metric


# Hard-coded quota definitions
_QUOTAS: dict[str, PlanQuota] = {
    "free": PlanQuota(
        plan="free",
        max_claims_per_day=100,
        max_concurrent_verifies=2,
        max_federation_peers=0,
    ),
    "pro": PlanQuota(
        plan="pro",
        max_claims_per_day=10_000,
        max_concurrent_verifies=10,
        max_federation_peers=5,
    ),
    "enterprise": PlanQuota(
        plan="enterprise",
        max_claims_per_day=1_000_000,
        max_concurrent_verifies=100,
        max_federation_peers=50,
    ),
}


def get_quota_for_plan(plan: str) -> PlanQuota:
    """Retrieve quota definition for a plan.

    Args:
        plan: Plan name ("free", "pro", "enterprise").

    Returns:
        The PlanQuota.

    Raises:
        KeyError: If plan is unknown.
    """
    if plan not in _QUOTAS:
        raise KeyError(f"Unknown plan: {plan}")
    return _QUOTAS[plan]


def check_quota(tenant: Tenant, current_usage: UsageSnapshot) -> QuotaCheckResult:
    """Check if tenant usage is within quota.

    Calculates headroom as a percentage (0-100) remaining for each metric.
    Returns allowed=False if ANY metric exceeds its limit.

    Args:
        tenant: The tenant.
        current_usage: Current usage snapshot.

    Returns:
        QuotaCheckResult with allowed status and headroom breakdown.

    Raises:
        KeyError: If tenant plan is unknown.
    """
    quota = get_quota_for_plan(tenant.plan)

    headroom = {}
    allowed = True
    reasons = []

    # Check claims per day
    max_claims = quota.max_claims_per_day
    headroom_pct = max(
        0.0, 100.0 * (1.0 - current_usage.claims_verified / max_claims)
    )
    headroom["claims_per_day"] = headroom_pct
    if current_usage.claims_verified > max_claims:
        allowed = False
        reasons.append(
            f"claims exceeded: {current_usage.claims_verified} / {max_claims}"
        )

    # Check concurrent verifies
    max_concurrent = quota.max_concurrent_verifies
    headroom_pct = max(
        0.0,
        100.0
        * (
            1.0
            - current_usage.concurrent_verifies_peak / max_concurrent
        ),
    )
    headroom["concurrent_verifies"] = headroom_pct
    if current_usage.concurrent_verifies_peak > max_concurrent:
        allowed = False
        reasons.append(
            f"concurrent verifies exceeded: {current_usage.concurrent_verifies_peak} / {max_concurrent}"
        )

    # Check federation peers
    max_peers = quota.max_federation_peers
    if max_peers > 0:
        headroom_pct = max(
            0.0,
            100.0 * (1.0 - current_usage.federation_peers_count / max_peers),
        )
    else:
        headroom_pct = 100.0 if current_usage.federation_peers_count == 0 else 0.0
    headroom["federation_peers"] = headroom_pct
    if current_usage.federation_peers_count > max_peers:
        allowed = False
        reasons.append(
            f"federation peers exceeded: {current_usage.federation_peers_count} / {max_peers}"
        )

    reason = "; ".join(reasons) if reasons else None

    return QuotaCheckResult(
        allowed=allowed,
        reason=reason,
        headroom=headroom,
    )


# Import after class definitions to avoid circular import
from gtv.managed.usage import UsageSnapshot  # noqa: E402
