# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Managed offering control plane — tenant provisioning, quotas, and usage.

This module provides the minimum API surface for gtv.example to manage
multi-tenant self-hosted deployments in a SaaS model.

Exports:
- Tenant model and provisioning functions
- Quota model and enforcement logic
- Usage tracking and snapshots
- FastAPI router for control plane endpoints
"""

from gtv.managed.api import router
from gtv.managed.quotas import (
    PlanQuota,
    QuotaCheckResult,
    check_quota,
    get_quota_for_plan,
)
from gtv.managed.tenants import (
    Tenant,
    TenantStore,
    create_tenant,
    get_tenant,
    list_tenants,
    reactivate_tenant,
    suspend_tenant,
)
from gtv.managed.usage import (
    UsageSnapshot,
    record_claim_verified,
    record_peer_added,
    record_peer_removed,
    snapshot,
)

__all__ = [
    "PlanQuota",
    "QuotaCheckResult",
    "Tenant",
    "TenantStore",
    "UsageSnapshot",
    "check_quota",
    "create_tenant",
    "get_quota_for_plan",
    "get_tenant",
    "list_tenants",
    "reactivate_tenant",
    "record_claim_verified",
    "record_peer_added",
    "record_peer_removed",
    "router",
    "snapshot",
    "suspend_tenant",
]
