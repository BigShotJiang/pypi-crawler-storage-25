# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""FastAPI router for managed offering control plane.

All endpoints require an admin API key via X-Admin-Key header.
Admin key comes from GTV_MANAGED_ADMIN_KEY env var.
"""

from __future__ import annotations

import os
from typing import Any, Literal

from fastapi import APIRouter, Header, HTTPException, Query, status
from pydantic import BaseModel, EmailStr

from gtv.managed.quotas import check_quota
from gtv.managed.tenants import (
    create_tenant,
    get_tenant,
    list_tenants,
    reactivate_tenant,
    suspend_tenant,
)
from gtv.managed.usage import snapshot

router = APIRouter(prefix="/managed", tags=["managed"])


# Request/Response models
class CreateTenantRequest(BaseModel):
    """Request to create a new tenant."""

    name: str
    plan: Literal["free", "pro", "enterprise"]
    contact_email: EmailStr
    billing_customer_id: str | None = None


class QuotaCheckResponse(BaseModel):
    """Response from quota check endpoint."""

    allowed: bool
    reason: str | None = None
    headroom: dict[str, float]


# Helper: validate admin key
def _check_admin_key(x_admin_key: str | None = Header(None)) -> None:
    """Validate admin API key from X-Admin-Key header.

    Args:
        x_admin_key: The admin key from the header.

    Raises:
        HTTPException: If key is missing or invalid.
    """
    expected_key = os.environ.get("GTV_MANAGED_ADMIN_KEY", "").strip()

    # If no expected key is configured, reject all requests
    if not expected_key:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Admin API not configured (GTV_MANAGED_ADMIN_KEY not set)",
        )

    if not x_admin_key or x_admin_key != expected_key:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid admin key",
        )


# Endpoints

@router.post("/tenants", status_code=status.HTTP_201_CREATED)
def post_tenants(
    req: CreateTenantRequest,
    x_admin_key: str | None = Header(None),
) -> dict[str, Any]:
    """Create a new tenant.

    Args:
        req: Tenant creation request.
        x_admin_key: Admin API key.

    Returns:
        The created Tenant as a dict.

    Raises:
        HTTPException: 401 if auth fails, 400 if plan is invalid.
    """
    _check_admin_key(x_admin_key)

    # Validate plan
    if req.plan not in ("free", "pro", "enterprise"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid plan: {req.plan}. Must be 'free', 'pro', or 'enterprise'.",
        )

    try:
        tenant = create_tenant(
            name=req.name,
            plan=req.plan,
            contact_email=req.contact_email,
            billing_customer_id=req.billing_customer_id,
        )
        return tenant.model_dump()
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        ) from e


@router.get("/tenants/{tenant_id}")
def get_tenants_by_id(
    tenant_id: str,
    x_admin_key: str | None = Header(None),
) -> dict[str, Any]:
    """Retrieve a tenant by ID.

    Args:
        tenant_id: The tenant's UUID.
        x_admin_key: Admin API key.

    Returns:
        The Tenant as a dict.

    Raises:
        HTTPException: 401 if auth fails, 404 if tenant not found.
    """
    _check_admin_key(x_admin_key)

    tenant = get_tenant(tenant_id)
    if tenant is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Tenant {tenant_id} not found",
        )

    return tenant.model_dump()


@router.get("/tenants")
def list_all_tenants(
    plan: str | None = Query(None),
    status: str | None = Query(None),
    x_admin_key: str | None = Header(None),
) -> dict[str, Any]:
    """List all tenants with optional filtering.

    Args:
        plan: Filter by plan ('free', 'pro', 'enterprise').
        status: Filter by status ('active', 'suspended', 'churned').
        x_admin_key: Admin API key.

    Returns:
        List of Tenants as dicts.

    Raises:
        HTTPException: 401 if auth fails.
    """
    _check_admin_key(x_admin_key)

    tenants = list_tenants(plan=plan, status=status)
    return {"tenants": [t.model_dump() for t in tenants]}


@router.post("/tenants/{tenant_id}/suspend")
def post_suspend(
    tenant_id: str,
    x_admin_key: str | None = Header(None),
) -> dict[str, Any]:
    """Suspend a tenant.

    Args:
        tenant_id: The tenant's UUID.
        x_admin_key: Admin API key.

    Returns:
        The suspended Tenant as a dict.

    Raises:
        HTTPException: 401 if auth fails, 404 if tenant not found.
    """
    _check_admin_key(x_admin_key)

    try:
        tenant = suspend_tenant(tenant_id)
        return tenant.model_dump()
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Tenant {tenant_id} not found",
        ) from e


@router.post("/tenants/{tenant_id}/reactivate")
def post_reactivate(
    tenant_id: str,
    x_admin_key: str | None = Header(None),
) -> dict[str, Any]:
    """Reactivate a suspended tenant.

    Args:
        tenant_id: The tenant's UUID.
        x_admin_key: Admin API key.

    Returns:
        The reactivated Tenant as a dict.

    Raises:
        HTTPException: 401 if auth fails, 404 if tenant not found.
    """
    _check_admin_key(x_admin_key)

    try:
        tenant = reactivate_tenant(tenant_id)
        return tenant.model_dump()
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Tenant {tenant_id} not found",
        ) from e


@router.get("/tenants/{tenant_id}/usage")
def get_usage(
    tenant_id: str,
    x_admin_key: str | None = Header(None),
) -> dict[str, Any]:
    """Get usage snapshot for a tenant.

    Args:
        tenant_id: The tenant's UUID.
        x_admin_key: Admin API key.

    Returns:
        The UsageSnapshot as a dict.

    Raises:
        HTTPException: 401 if auth fails, 404 if tenant not found.
    """
    _check_admin_key(x_admin_key)

    tenant = get_tenant(tenant_id)
    if tenant is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Tenant {tenant_id} not found",
        )

    usage = snapshot(tenant_id)
    return usage.model_dump()


@router.get("/tenants/{tenant_id}/quota-check")
def get_quota_check(
    tenant_id: str,
    x_admin_key: str | None = Header(None),
) -> QuotaCheckResponse:
    """Check if tenant is within quota.

    Args:
        tenant_id: The tenant's UUID.
        x_admin_key: Admin API key.

    Returns:
        QuotaCheckResponse with allowed status and headroom.

    Raises:
        HTTPException: 401 if auth fails, 404 if tenant not found,
                       400 if plan is unknown.
    """
    _check_admin_key(x_admin_key)

    tenant = get_tenant(tenant_id)
    if tenant is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Tenant {tenant_id} not found",
        )

    try:
        usage = snapshot(tenant_id)
        result = check_quota(tenant, usage)
        return QuotaCheckResponse(
            allowed=result.allowed,
            reason=result.reason,
            headroom=result.headroom,
        )
    except KeyError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        ) from e
