# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Multi-region replica routing and data-residency enforcement.

When gtv is deployed across multiple regions (us-east, eu-west, ap-southeast),
a verify request arriving in us-east should prefer local adapters, caches, and
peers to minimize latency and data-residency risk.

This module provides region-aware endpoint ranking and residency compliance
checks to enforce hard data-residency boundaries while allowing graceful
fallback to preferred regions within those boundaries.
"""
from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass(frozen=True)
class RegionConfig:
    """Immutable region configuration for multi-region routing."""

    local_region: str
    """The region where this instance is running (e.g. 'us-east-1').
    If set to 'global', disables local-first preference."""

    allowed_regions: frozenset[str]
    """Hard residency cap: endpoints outside this set are always dropped.
    Empty set means no residency restriction (allow anything)."""

    preferred_regions: list[str]
    """Ordered fallback list for non-local endpoints.
    Earlier positions rank higher."""

    def __post_init__(self) -> None:
        """Validate that all preferred regions are in allowed_regions (if set)."""
        if self.allowed_regions and self.preferred_regions:
            for region in self.preferred_regions:
                if region not in self.allowed_regions:
                    raise ValueError(
                        f"preferred_region '{region}' not in allowed_regions"
                    )


@dataclass(frozen=True)
class RegionalEndpoint:
    """An endpoint in a specific region with a priority value."""

    url: str
    """The endpoint URL."""

    region: str
    """The region this endpoint is in (e.g. 'us-east-1')."""

    priority: int
    """Numeric priority; lower values rank higher within the same tier.
    Used to break ties within the same region."""


def load_region_config_from_env() -> RegionConfig:
    """Load region configuration from environment variables.

    Environment variables:
    - GTV_REGION: local region (default: 'global')
    - GTV_ALLOWED_REGIONS: comma-separated list of allowed regions
      (default: empty = no restriction)
    - GTV_PREFERRED_REGIONS: comma-separated ordered list of preferred
      fallback regions (default: empty)

    Returns:
        RegionConfig: The configuration loaded from the environment.
    """
    local_region = os.environ.get("GTV_REGION", "global")

    allowed_str = os.environ.get("GTV_ALLOWED_REGIONS", "").strip()
    allowed_regions = (
        frozenset(r.strip() for r in allowed_str.split(",") if r.strip())
        if allowed_str
        else frozenset()
    )

    preferred_str = os.environ.get("GTV_PREFERRED_REGIONS", "").strip()
    preferred_regions = (
        [r.strip() for r in preferred_str.split(",") if r.strip()]
        if preferred_str
        else []
    )

    return RegionConfig(
        local_region=local_region,
        allowed_regions=allowed_regions,
        preferred_regions=preferred_regions,
    )


def rank_endpoints(
    endpoints: list[RegionalEndpoint], cfg: RegionConfig
) -> list[RegionalEndpoint]:
    """Rank endpoints by region affinity and priority.

    Ranking order:
    1. Drop any endpoint outside cfg.allowed_regions (unless allowed_regions is empty).
    2. Local region endpoints (if local_region != 'global') rank first.
    3. Non-local endpoints rank by position in cfg.preferred_regions.
    4. Tie-break on priority (lower first).
    5. Maintain stable sort order for same-region, same-priority endpoints.

    Args:
        endpoints: List of endpoints to rank.
        cfg: Region configuration defining local, allowed, and preferred regions.

    Returns:
        list[RegionalEndpoint]: Sorted endpoints (non-compliant ones removed).
    """
    if not endpoints:
        return []

    # Filter: drop endpoints outside allowed_regions (if set)
    if cfg.allowed_regions:
        filtered = [e for e in endpoints if e.region in cfg.allowed_regions]
    else:
        filtered = endpoints[:]

    if not filtered:
        return []

    # Compute sort key for each endpoint
    def sort_key(endpoint: RegionalEndpoint, index: int) -> tuple:
        """Return (tier, preferred_position, priority, input_order)."""
        # Tier 0: local region (if not 'global')
        if cfg.local_region != "global" and endpoint.region == cfg.local_region:
            return (0, 0, endpoint.priority, index)

        # Tier 1: preferred regions (by position in preferred list)
        if endpoint.region in cfg.preferred_regions:
            preferred_position = cfg.preferred_regions.index(endpoint.region)
            return (1, preferred_position, endpoint.priority, index)

        # Tier 2: any other allowed region
        return (2, 0, endpoint.priority, index)

    # Sort with stable sort (preserves input order for identical keys)
    sorted_endpoints = sorted(
        enumerate(filtered), key=lambda x: sort_key(x[1], x[0])
    )

    return [endpoint for _, endpoint in sorted_endpoints]


def is_residency_compliant(evidence_region: str, cfg: RegionConfig) -> bool:
    """Check if an evidence region complies with residency boundaries.

    Args:
        evidence_region: The region where evidence originated.
        cfg: Region configuration defining allowed_regions.

    Returns:
        bool: True if evidence_region is in cfg.allowed_regions.
              If allowed_regions is empty, returns True (no restriction).
    """
    if not cfg.allowed_regions:
        return True
    return evidence_region in cfg.allowed_regions
