# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Load a `Policy` from YAML (or JSON — YAML is a superset).

No live reload, no signals, no watchers. The only entry point is
`load_policy(path)` which returns a fully-validated `Policy` or
raises `PolicyError`. Env integration reads `GTV_POLICY_PATH`.
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import yaml

from gtv.policy.schema import Policy


class PolicyError(ValueError):
    """Raised when a policy file is missing, malformed, or fails schema."""


DEFAULT_POLICY: Policy = Policy()
"""Sentinel policy that matches the legacy hardcoded engine byte-for-byte."""


def load_policy(path: str | os.PathLike[str]) -> Policy:
    """Parse + validate the YAML at ``path`` into a `Policy`.

    Raises `PolicyError` on any failure (file not found, malformed
    YAML, schema violation). Call sites are expected to either
    surface the error at startup or fall back to `DEFAULT_POLICY`.
    """
    p = Path(path).expanduser()
    if not p.exists():
        raise PolicyError(f"Policy file not found: {p}")
    try:
        raw = p.read_text(encoding="utf-8")
    except OSError as exc:
        raise PolicyError(f"Unable to read policy file {p}: {exc}") from exc
    try:
        data: Any = yaml.safe_load(raw)
    except yaml.YAMLError as exc:
        raise PolicyError(f"Malformed YAML in {p}: {exc}") from exc
    if data is None:
        # Empty file → default policy.
        return DEFAULT_POLICY
    if not isinstance(data, dict):
        raise PolicyError(
            f"Policy file {p} must contain a mapping at the top level, "
            f"got {type(data).__name__}."
        )
    try:
        return Policy.model_validate(data)
    except Exception as exc:  # pydantic ValidationError subclasses Exception
        raise PolicyError(f"Policy schema violation in {p}: {exc}") from exc


def load_policy_from_env() -> Policy:
    """Read `GTV_POLICY_PATH`; return the parsed policy or the default.

    An explicitly-set but invalid path is a hard error — we refuse to
    silently fall through to the default when the operator clearly
    intended to load a custom policy. Unset = default, which matches
    legacy behavior.
    """
    path = os.environ.get("GTV_POLICY_PATH", "").strip()
    if not path:
        return DEFAULT_POLICY
    return load_policy(path)
