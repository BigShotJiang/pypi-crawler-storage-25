# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Pydantic schema for the consensus policy DSL.

Field-level validation lives here so every other module can trust
that a `Policy` object is well-formed. Validation catches the
operator-authoring failure modes: negative thresholds, tier weights
outside [0,1], confidence coefficients that could push the score
out of [0,1], and unknown domain keys.
"""
from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field, field_validator

from gtv.models import Domain


class TierWeights(BaseModel):
    """Contribution of each trust tier to the confidence bonus term.

    Values are per-evidence-item coefficients. Keep ≤ 1.0 per tier;
    aggregate bonus is capped downstream by the confidence clamp.
    """

    model_config = ConfigDict(frozen=True)

    tier_1: float = Field(default=1.0, ge=0.0, le=1.0)
    tier_2: float = Field(default=0.7, ge=0.0, le=1.0)
    tier_3: float = Field(default=0.4, ge=0.0, le=1.0)


class ConfidenceFormula(BaseModel):
    """Linear confidence model: base + per_source*n + per_tier_bonus*w - age_penalty*norm.

    Matches the legacy engine byte-for-byte when defaults are used.
    Clamp is hardcoded to [0, 0.99] for compatibility with existing
    consumers that treat 1.0 as "miracle" and reject it.
    """

    model_config = ConfigDict(frozen=True)

    base: float = Field(default=0.5, ge=0.0, le=1.0)
    per_source: float = Field(default=0.15, ge=0.0, le=1.0)
    per_tier_bonus: float = Field(default=0.05, ge=0.0, le=1.0)
    age_penalty: float = Field(default=0.1, ge=0.0, le=1.0)
    age_horizon_months: float = Field(default=60.0, gt=0.0)


class DomainPolicy(BaseModel):
    """Per-domain overrides. Any field left unset falls through to the
    global values. Operators typically use this to tighten biology
    (require 3 sources) or loosen physics (allow 1 TIER_1 source).

    v2 additions (W39):

    * ``max_evidence_age_days`` — evidence older than this is dropped
      before counting. Used for fast-moving domains (medical guidance,
      security advisories) where yesterday's consensus is not today's.
    * ``require_recent_support_days`` — even if N historical sources
      support the claim, require ≥1 of them to be within this window.
      Protects against echo-chambers of archived content.
    * ``min_distinct_tiers_for_verified`` — supports must be spread
      across ≥ N distinct trust tiers (not just N DIDs). Guards against
      a single-tier monoculture (e.g. "all tier-3 blogs agree").
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    min_supports_for_verified: int | None = Field(default=None, ge=1)
    min_refutes_for_negation: int | None = Field(default=None, ge=1)
    tier_weights: TierWeights | None = None
    confidence: ConfidenceFormula | None = None

    # --- v2 (W39) temporal + cross-tier primitives --------------------
    max_evidence_age_days: int | None = Field(default=None, ge=1)
    require_recent_support_days: int | None = Field(default=None, ge=1)
    min_distinct_tiers_for_verified: int | None = Field(
        default=None, ge=1, le=3
    )


class Policy(BaseModel):
    """Top-level policy document.

    ``domains`` is keyed by the `Domain` enum values as strings so the
    YAML stays human-readable: ``physics:``, ``biology:``, etc. An
    unknown key raises at load time — we don't silently accept typos.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    min_supports_for_verified: int = Field(default=2, ge=1)
    min_refutes_for_negation: int = Field(default=2, ge=1)
    tier_weights: TierWeights = Field(default_factory=TierWeights)
    confidence: ConfidenceFormula = Field(default_factory=ConfidenceFormula)

    # v2 (W39) — globals for temporal + cross-tier primitives. ``None``
    # means "not enforced", which matches v1 behavior exactly.
    max_evidence_age_days: int | None = Field(default=None, ge=1)
    require_recent_support_days: int | None = Field(default=None, ge=1)
    min_distinct_tiers_for_verified: int | None = Field(
        default=None, ge=1, le=3
    )

    domains: dict[str, DomainPolicy] = Field(default_factory=dict)

    @field_validator("domains")
    @classmethod
    def _validate_domain_keys(
        cls, v: dict[str, DomainPolicy]
    ) -> dict[str, DomainPolicy]:
        known = {d.value for d in Domain}
        bad = set(v) - known
        if bad:
            raise ValueError(
                f"Unknown domain(s) in policy: {sorted(bad)}. "
                f"Known: {sorted(known)}."
            )
        return v

    # -- Resolution helpers --------------------------------------------

    def for_domain(self, domain: str | Domain | None) -> ResolvedPolicy:
        """Flatten global + per-domain overrides into a single struct.

        Callers pass the resolved policy into `decide()` so there are
        no scattered `if domain_override is not None` branches in the
        verdict engine.
        """
        key = domain.value if isinstance(domain, Domain) else domain
        override = self.domains.get(key or "")
        if override is None:
            return ResolvedPolicy(
                min_supports_for_verified=self.min_supports_for_verified,
                min_refutes_for_negation=self.min_refutes_for_negation,
                tier_weights=self.tier_weights,
                confidence=self.confidence,
                max_evidence_age_days=self.max_evidence_age_days,
                require_recent_support_days=self.require_recent_support_days,
                min_distinct_tiers_for_verified=(
                    self.min_distinct_tiers_for_verified
                ),
            )
        return ResolvedPolicy(
            min_supports_for_verified=(
                override.min_supports_for_verified
                if override.min_supports_for_verified is not None
                else self.min_supports_for_verified
            ),
            min_refutes_for_negation=(
                override.min_refutes_for_negation
                if override.min_refutes_for_negation is not None
                else self.min_refutes_for_negation
            ),
            tier_weights=override.tier_weights or self.tier_weights,
            confidence=override.confidence or self.confidence,
            max_evidence_age_days=(
                override.max_evidence_age_days
                if override.max_evidence_age_days is not None
                else self.max_evidence_age_days
            ),
            require_recent_support_days=(
                override.require_recent_support_days
                if override.require_recent_support_days is not None
                else self.require_recent_support_days
            ),
            min_distinct_tiers_for_verified=(
                override.min_distinct_tiers_for_verified
                if override.min_distinct_tiers_for_verified is not None
                else self.min_distinct_tiers_for_verified
            ),
        )


class ResolvedPolicy(BaseModel):
    """Policy after per-domain overrides have been flattened into the
    globals. The verdict engine only ever works with this type."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    min_supports_for_verified: int
    min_refutes_for_negation: int
    tier_weights: TierWeights
    confidence: ConfidenceFormula

    # v2 primitives — None means "not enforced". v1 policies resolve to
    # all-None here, which keeps the verdict engine's v1 code path alive.
    max_evidence_age_days: int | None = None
    require_recent_support_days: int | None = None
    min_distinct_tiers_for_verified: int | None = None
