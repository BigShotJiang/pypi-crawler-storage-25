# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Consensus policy DSL.

Operators declare verdict thresholds in YAML instead of recompiling
the server. The policy model covers the levers the verdict engine
actually uses — source-count thresholds, tier weights, and the
confidence-formula constants — plus per-domain overrides.

The default policy, `DEFAULT_POLICY`, encodes the exact constants
the legacy hardcoded engine used, so callers that don't supply a
policy get byte-identical behavior.

See `docs/policy.md` for the authoring guide.
"""
from gtv.policy.load import (
    DEFAULT_POLICY,
    PolicyError,
    load_policy,
    load_policy_from_env,
)
from gtv.policy.schema import (
    ConfidenceFormula,
    DomainPolicy,
    Policy,
    TierWeights,
)

__all__ = [
    "DEFAULT_POLICY",
    "ConfidenceFormula",
    "DomainPolicy",
    "Policy",
    "PolicyError",
    "TierWeights",
    "load_policy",
    "load_policy_from_env",
]
