# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Sub-claim extraction from free-text input.

Rule-based, stdlib only. Splits on sentence boundaries, filters questions
and imperatives, preserves order, caps at max_subclaims.
"""
from __future__ import annotations

import re


def extract_subclaims(text: str, max_subclaims: int = 5) -> list[str]:
    """Extract sub-claims (sentences) from free-text input.

    Rules:
    - Split on sentence boundaries (., !, ?, newlines)
    - Filter out questions (starting with question words or in source text)
    - Filter out imperatives (starting with verbs in imperative form)
    - Strip whitespace
    - Preserve order
    - Cap at max_subclaims

    Args:
        text: Free-text input (e.g., paragraph or document)
        max_subclaims: Maximum number of sub-claims to return (default 5)

    Returns:
        List of extracted sub-claims (sentences), ordered and capped.
    """
    if not text or not text.strip():
        return []

    # First pass: locate question marks in original text to mark sentences as questions
    # Split on sentence boundaries: . ! ? or newlines
    sentences = re.split(r'[.!?\n]+', text)

    # Check which sentences were originally questions by looking for ? before the split point
    # Simpler approach: check if the original text has '?' near the sentence in original form
    question_indices = set()
    pos = 0
    for i, sent in enumerate(sentences):
        # Find where this sentence ends in the original text
        sent_start = text.find(sent, pos)
        if sent_start >= 0:
            sent_end = sent_start + len(sent)
            pos = sent_end
            # Check if there's a ? immediately after (within punctuation)
            check_pos = sent_end
            while check_pos < len(text) and text[check_pos] in ' \t':
                check_pos += 1
            if check_pos < len(text) and text[check_pos] == '?':
                question_indices.add(i)

    # Clean and filter
    subclaims = []
    for i, sentence in enumerate(sentences):
        # Strip leading/trailing whitespace
        sentence = sentence.strip()

        # Skip empty sentences
        if not sentence:
            continue

        # Skip questions (marked as such in question_indices or start with question words)
        if i in question_indices or \
           sentence.startswith('What ') or \
           sentence.startswith('Who ') or \
           sentence.startswith('When ') or \
           sentence.startswith('Where ') or \
           sentence.startswith('Why ') or \
           sentence.startswith('How '):
            continue

        # Skip imperatives: simple heuristic is first word suggests a verb
        # Common imperative starters: "Go", "Do", "Make", "Find", "Check", "See", etc.
        first_word = sentence.split()[0].lower() if sentence.split() else ""
        imperative_markers = {
            'go', 'do', 'make', 'find', 'check', 'see', 'get', 'take', 'look',
            'try', 'help', 'tell', 'give', 'think', 'consider', 'let', 'put',
            'bring', 'show', 'keep', 'write', 'know', 'set', 'ask', 'call',
            'feel', 'watch', 'believe', 'hold', 'open', 'close', 'start',
            'stop', 'run', 'walk', 'come', 'use', 'work', 'play',
            'search', 'read', 'say', 'name', 'list', 'count', 'describe',
            'explain', 'answer', 'calculate', 'compute', 'solve', 'prove',
        }
        if first_word in imperative_markers:
            continue

        # All checks pass; add to subclaims
        subclaims.append(sentence)

        # Stop if we've reached max
        if len(subclaims) >= max_subclaims:
            break

    return subclaims
