# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Evidence retrieval and processing."""
from __future__ import annotations

from gtv.retrieve.cluster import cluster
from gtv.retrieve.dedup import deduplicate

__all__ = ["cluster", "deduplicate"]
