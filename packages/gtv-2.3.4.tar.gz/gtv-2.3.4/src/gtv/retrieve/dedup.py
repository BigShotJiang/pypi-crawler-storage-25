# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Evidence deduplication across adapters.

When two sources return evidence for the same underlying artefact (e.g. arXiv
preprint + Crossref DOI of the same paper), we shouldn't count it twice in the
verdict weighting.

Pure stdlib implementation: no network, no external dependencies.
"""
from __future__ import annotations

import hashlib
import re
from typing import Final

from gtv.adapters import REGISTRY
from gtv.models import Evidence

# Patterns to extract identifiers from URLs.
_DOI_PATTERN: Final[re.Pattern[str]] = re.compile(r"10\.\S+/\S+")
_ARXIV_PATTERN: Final[re.Pattern[str]] = re.compile(r"\d{4}\.\d{4,5}")
_PMID_PATTERN: Final[re.Pattern[str]] = re.compile(r"(\d{7,8})")  # PMIDs are typically 7-8 digits
_PMCID_PATTERN: Final[re.Pattern[str]] = re.compile(r"pmc/articles/pmc(\d+)")
_ISBN_PATTERN: Final[re.Pattern[str]] = re.compile(r"\b(?:ISBN|isbn)[-\s]?(?=[-0-9 ]{10}(?:[-0-9X ]?|(?:[-0-9X]?[-0-9X]){2})(?:-[-0-9X])?(?:[-0-9 ]{13})?$)[-0-9X -.]{13}[-X]?\b|97[89][0-9]{10}(?:(?=(?:[^0-9]|^))|$)")


def _normalize_excerpt(excerpt: str) -> str:
    """Normalize excerpt: lowercase, strip punctuation, collapse whitespace."""
    # Lowercase and remove non-alphanumeric (except spaces)
    normalized = re.sub(r"[^a-z0-9\s]", "", excerpt.lower())
    # Collapse multiple whitespaces into one
    normalized = re.sub(r"\s+", " ", normalized).strip()
    return normalized


def _hash_excerpt(excerpt: str) -> str:
    """SHA1 hash of normalized excerpt."""
    normalized = _normalize_excerpt(excerpt)
    return hashlib.sha1(normalized.encode("utf-8")).hexdigest()


def _extract_identifiers(url: str) -> set[str]:
    """Extract identifier tokens from a URL.

    Returns a set of (type, id) tuples: DOI, arXiv ID, PMID, PMCID, ISBN.
    """
    identifiers: set[str] = set()
    url_str = str(url)

    # DOI
    doi_match = _DOI_PATTERN.search(url_str)
    if doi_match:
        identifiers.add(("doi", doi_match.group().lower()))

    # arXiv ID
    arxiv_match = _ARXIV_PATTERN.search(url_str)
    if arxiv_match:
        identifiers.add(("arxiv", arxiv_match.group()))

    # PMID (if in pubmed or europepmc domain)
    if "pubmed" in url_str or "europepmc" in url_str:
        pmid_match = _PMID_PATTERN.search(url_str)
        if pmid_match:
            pmid = pmid_match.group(1)
            identifiers.add(("pmid", pmid))

    # PMCID
    pmcid_match = _PMCID_PATTERN.search(url_str)
    if pmcid_match:
        identifiers.add(("pmcid", pmcid_match.group(1)))

    # ISBN
    isbn_match = _ISBN_PATTERN.search(url_str)
    if isbn_match:
        identifiers.add(("isbn", isbn_match.group().replace("-", "").replace(" ", "")))

    return identifiers


def _get_trust_tier_rank(source_did: str) -> int:
    """Return rank for trust tier: higher = more trustworthy.

    TIER_1 > TIER_2 > TIER_3. Default to TIER_2 for unknown sources.
    """
    if source_did not in REGISTRY:
        return 2  # Unknown source defaults to TIER_2

    adapter = REGISTRY[source_did]
    tier = adapter.trust_tier
    if tier.value == "TIER_1":
        return 3
    elif tier.value == "TIER_2":
        return 2
    elif tier.value == "TIER_3":
        return 1
    return 2  # Default


def deduplicate(evidences: list[Evidence]) -> list[Evidence]:
    """Deduplicate evidence across adapters.

    Strategy:
    1. Normalize excerpt, hash with sha1 → cluster by hash (exact content duplicates).
    2. Extract identifier tokens from URLs (DOI, arXiv, PMID, PMCID, ISBN).
       If two evidences share any identifier, they're duplicates.
    3. Keep the one with higher trust_tier; break ties by most recent retrieved_at.
    4. Return deduplicated list, preserving original order of kept items.

    Args:
        evidences: List of Evidence objects.

    Returns:
        Deduplicated list of Evidence objects.
    """
    if not evidences:
        return []

    if len(evidences) == 1:
        return evidences

    # Build clusters: evidence IDs grouped by duplicates.
    # Use a union-find approach.
    clusters: dict[str, set[str]] = {}  # cluster_id -> {evidence_id, ...}
    cluster_map: dict[str, str] = {}  # evidence_id -> cluster_id

    def find_or_create_cluster(evidence_id: str) -> str:
        """Return the canonical cluster ID for an evidence."""
        if evidence_id not in cluster_map:
            cluster_map[evidence_id] = evidence_id
            clusters[evidence_id] = {evidence_id}
        return cluster_map[evidence_id]

    def merge_clusters(id1: str, id2: str) -> None:
        """Merge two evidence items into the same cluster."""
        c1 = find_or_create_cluster(id1)
        c2 = find_or_create_cluster(id2)
        if c1 == c2:
            return

        # Merge c2 into c1.
        clusters[c1].update(clusters[c2])
        del clusters[c2]
        for eid in clusters[c1]:
            cluster_map[eid] = c1

    # Index: excerpt_hash -> evidence_id
    excerpt_hash_map: dict[str, list[str]] = {}
    for e in evidences:
        h = _hash_excerpt(e.excerpt)
        if h not in excerpt_hash_map:
            excerpt_hash_map[h] = []
        excerpt_hash_map[h].append(e.evidence_id)

    # Cluster by excerpt hash.
    for evidence_ids in excerpt_hash_map.values():
        if len(evidence_ids) > 1:
            for eid in evidence_ids[1:]:
                merge_clusters(evidence_ids[0], eid)

    # Index: identifier -> evidence_id
    identifier_map: dict[tuple[str, str], list[str]] = {}
    for e in evidences:
        identifiers = _extract_identifiers(e.url)
        for identifier in identifiers:
            if identifier not in identifier_map:
                identifier_map[identifier] = []
            identifier_map[identifier].append(e.evidence_id)

    # Cluster by shared identifiers.
    for evidence_ids in identifier_map.values():
        if len(evidence_ids) > 1:
            for eid in evidence_ids[1:]:
                merge_clusters(evidence_ids[0], eid)

    # Ensure all evidences are in clusters (even if no duplicates found).
    for e in evidences:
        find_or_create_cluster(e.evidence_id)

    # For each cluster, keep the best evidence.
    # Build a mapping: evidence_id -> Evidence
    id_to_evidence = {e.evidence_id: e for e in evidences}

    kept_ids: set[str] = set()
    for cluster_ids in clusters.values():
        # Find the best evidence in the cluster.
        best_id = None
        best_rank = -1
        best_retrieved = None

        for eid in cluster_ids:
            e = id_to_evidence[eid]
            rank = _get_trust_tier_rank(e.source_did)

            if best_id is None:
                best_id = eid
                best_rank = rank
                best_retrieved = e.retrieved_at
            else:
                # Higher rank is better; if tied, more recent is better.
                if rank > best_rank:
                    best_id = eid
                    best_rank = rank
                    best_retrieved = e.retrieved_at
                elif rank == best_rank and e.retrieved_at > best_retrieved:
                    best_id = eid
                    best_retrieved = e.retrieved_at

        kept_ids.add(best_id)

    # Return kept evidences in original order.
    result = [e for e in evidences if e.evidence_id in kept_ids]
    return result
