# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Evidence clustering for grouped analysis.

Group similar-but-not-identical evidences into clusters so the verdict engine
can report "5 independent sources" vs "5 restatements of one preprint".

Pure stdlib implementation: no network, no external dependencies.
"""
from __future__ import annotations

import re
from typing import Final

from gtv.models import Evidence

# Conservative English stopwords for tokenization.
_STOPWORDS: Final[set[str]] = {
    "a", "about", "above", "after", "again", "against", "all", "am", "an",
    "and", "any", "are", "as", "at", "be", "because", "been", "before",
    "being", "below", "between", "both", "but", "by", "can", "cannot",
    "could", "did", "do", "does", "doing", "down", "during", "each", "few",
    "for", "from", "further", "had", "has", "have", "having", "he", "her",
    "here", "hers", "herself", "him", "himself", "his", "how", "i", "if",
    "in", "into", "is", "it", "its", "itself", "just", "me", "might", "more",
    "most", "must", "my", "myself", "no", "nor", "not", "of", "off", "on",
    "once", "only", "or", "other", "our", "ours", "ourselves", "out", "over",
    "own", "same", "she", "should", "so", "some", "such", "than", "that",
    "the", "their", "theirs", "them", "themselves", "then", "there", "these",
    "they", "this", "those", "through", "to", "too", "under", "until", "up",
    "very", "was", "we", "were", "what", "when", "where", "which", "while",
    "who", "whom", "why", "with", "would", "you", "your", "yours", "yourself",
    "yourselves",
}


def _tokenize_excerpt(excerpt: str) -> set[str]:
    """Tokenize excerpt: lowercase, split on non-alphanumeric, drop stopwords.

    Args:
        excerpt: Raw excerpt text.

    Returns:
        Set of non-stopword tokens.
    """
    # Lowercase and split on non-alphanumeric.
    text = excerpt.lower()
    tokens = re.split(r"[^a-z0-9]+", text)

    # Filter: remove empty, remove stopwords, keep length > 1.
    filtered = {
        t for t in tokens
        if t and len(t) > 1 and t not in _STOPWORDS
    }

    return filtered


def _jaccard_similarity(set1: set[str], set2: set[str]) -> float:
    """Compute Jaccard similarity between two token sets.

    Args:
        set1: First token set.
        set2: Second token set.

    Returns:
        Float in [0, 1]; 1.0 = identical, 0.0 = disjoint.
    """
    if not set1 and not set2:
        return 1.0
    if not set1 or not set2:
        return 0.0

    intersection = len(set1 & set2)
    union = len(set1 | set2)
    return intersection / union if union > 0 else 0.0


class _UnionFind:
    """Simple union-find for clustering."""

    def __init__(self, n: int):
        self.parent = list(range(n))
        self.rank = [0] * n

    def find(self, x: int) -> int:
        """Find the root of x with path compression."""
        if self.parent[x] != x:
            self.parent[x] = self.find(self.parent[x])
        return self.parent[x]

    def union(self, x: int, y: int) -> None:
        """Union the sets containing x and y."""
        px, py = self.find(x), self.find(y)
        if px == py:
            return
        if self.rank[px] < self.rank[py]:
            px, py = py, px
        self.parent[py] = px
        if self.rank[px] == self.rank[py]:
            self.rank[px] += 1


def cluster(evidences: list[Evidence]) -> list[list[Evidence]]:
    """Cluster similar evidences using Jaccard similarity over token sets.

    Strategy:
    1. Tokenize each excerpt (lowercase, split on non-alphanumeric, drop stopwords).
    2. Compute Jaccard similarity between token sets.
    3. Two evidences cluster together if similarity >= 0.5 (single-link clustering).
    4. Return clusters sorted by size descending.

    Args:
        evidences: List of Evidence objects.

    Returns:
        List of clusters, where each cluster is a list of Evidence objects.
        Clusters are sorted by size descending.
    """
    if not evidences:
        return []

    if len(evidences) == 1:
        return [[evidences[0]]]

    # Tokenize all excerpts.
    tokens = [_tokenize_excerpt(e.excerpt) for e in evidences]

    # Single-link clustering: connect evidence if similarity >= 0.5.
    uf = _UnionFind(len(evidences))

    for i in range(len(evidences)):
        for j in range(i + 1, len(evidences)):
            sim = _jaccard_similarity(tokens[i], tokens[j])
            if sim >= 0.5:
                uf.union(i, j)

    # Group by root.
    clusters_map: dict[int, list[int]] = {}
    for i in range(len(evidences)):
        root = uf.find(i)
        if root not in clusters_map:
            clusters_map[root] = []
        clusters_map[root].append(i)

    # Convert to evidence clusters and sort by size descending.
    result = [
        [evidences[idx] for idx in cluster_indices]
        for cluster_indices in clusters_map.values()
    ]
    result.sort(key=len, reverse=True)

    return result
