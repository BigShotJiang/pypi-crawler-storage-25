# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""SBOM (Software Bill of Materials) generation and vulnerability scanning.

Generates CycloneDX 1.5 format SBOMs from the current Python environment
and performs basic vulnerability scanning against a local advisory database.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from importlib.metadata import distributions
from typing import Any


@dataclass(frozen=True)
class Component:
    """A single software component in the SBOM."""

    name: str
    version: str
    purl: str  # pkg:pypi/<name>@<version>
    sha256: str | None = None  # wheel sha256 if determinable
    license: str | None = None  # SPDX id if determinable


@dataclass(frozen=True)
class SBOM:
    """A complete Software Bill of Materials."""

    bom_format: str = "CycloneDX"
    spec_version: str = "1.5"
    serial_number: str = ""  # urn:uuid:...
    components: list[Component] = field(default_factory=list)
    generated_at: str = ""  # ISO 8601

    def __post_init__(self) -> None:
        """Validate SBOM fields."""
        if not self.serial_number.startswith("urn:uuid:"):
            raise ValueError(
                f"serial_number must start with 'urn:uuid:', got '{self.serial_number}'"
            )


def collect_components() -> list[Component]:
    """Walk importlib.metadata for every installed distribution in the
    current environment.

    Returns:
        List of Component objects for each installed distribution.
    """
    components = []
    for dist in distributions():
        name = dist.metadata.get("Name", "")
        version = dist.metadata.get("Version", "")
        if not name or not version:
            continue

        purl = f"pkg:pypi/{name.lower()}@{version}"

        # Try to extract license from metadata
        license_value = dist.metadata.get("License-Expression") or dist.metadata.get(
            "License"
        )

        # Try to extract sha256 from RECORD if available
        sha256_value = None
        if dist.files:
            for file in dist.files:
                if file.name.endswith(".whl"):
                    if hasattr(file, "hash") and file.hash:
                        sha256_value = str(file.hash)
                    break

        component = Component(
            name=name,
            version=version,
            purl=purl,
            sha256=sha256_value,
            license=license_value,
        )
        components.append(component)

    return components


def render_cyclonedx(sbom: SBOM) -> dict[str, Any]:
    """Serialise SBOM to CycloneDX 1.5 JSON shape.

    Args:
        sbom: The SBOM to serialize.

    Returns:
        Dictionary matching CycloneDX 1.5 JSON schema.
    """
    components_list = []
    for comp in sbom.components:
        component_dict: dict[str, Any] = {
            "type": "library",
            "name": comp.name,
            "version": comp.version,
            "purl": comp.purl,
        }
        if comp.sha256:
            component_dict["hashes"] = [{"alg": "SHA-256", "content": comp.sha256}]
        if comp.license:
            component_dict["licenses"] = [{"license": {"name": comp.license}}]
        components_list.append(component_dict)

    return {
        "bomFormat": sbom.bom_format,
        "specVersion": sbom.spec_version,
        "serialNumber": sbom.serial_number,
        "version": 1,
        "metadata": {"timestamp": sbom.generated_at, "component": None},
        "components": components_list,
    }


def scan_vulns(components: list[Component], advisory_file: str) -> list[dict[str, Any]]:
    """Load a local JSON advisory file and scan components for vulnerabilities.

    Advisory file format: [{name, version_spec, severity, id}, ...]
    version_spec matches via simple '<', '<=', '==' operators.

    Args:
        components: List of components to scan.
        advisory_file: Path to JSON advisory file.

    Returns:
        List of matched vulnerability dictionaries.

    Raises:
        ValueError: If an unknown operator is found in version_spec.
    """
    with open(advisory_file) as f:
        advisories = json.load(f)

    hits = []
    for advisory in advisories:
        adv_name = advisory.get("name", "").lower()
        version_spec = advisory.get("version_spec", "")
        severity = advisory.get("severity")
        vuln_id = advisory.get("id")

        for comp in components:
            if comp.name.lower() != adv_name:
                continue

            # Parse and evaluate version_spec
            if not version_spec:
                hits.append(
                    {
                        "component": comp.name,
                        "version": comp.version,
                        "severity": severity,
                        "id": vuln_id,
                    }
                )
                continue

            # Extract operator and version
            if version_spec.startswith("<="):
                op = "<="
                spec_version = version_spec[2:].strip()
            elif version_spec.startswith("<"):
                op = "<"
                spec_version = version_spec[1:].strip()
            elif version_spec.startswith("=="):
                op = "=="
                spec_version = version_spec[2:].strip()
            else:
                raise ValueError(f"Unknown operator in version_spec: {version_spec}")

            # Simple version comparison (string-based for simplicity)
            match_found = (
                (op == "==" and comp.version == spec_version)
                or (op == "<" and comp.version < spec_version)
                or (op == "<=" and comp.version <= spec_version)
            )

            if match_found:
                hits.append(
                    {
                        "component": comp.name,
                        "version": comp.version,
                        "severity": severity,
                        "id": vuln_id,
                    }
                )

    return hits
