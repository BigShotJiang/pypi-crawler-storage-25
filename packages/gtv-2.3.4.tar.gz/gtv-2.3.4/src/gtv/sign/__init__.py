# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Sign subpackage: BYOK (bring-your-own-key) signing and verification.

Exports the public API for signing envelopes with private keys and verifying
signatures against did:key DIDs.
"""
from __future__ import annotations

from gtv.sign.byok import sign_envelope_byok, verify_envelope_byok

__all__ = ["sign_envelope_byok", "verify_envelope_byok"]
