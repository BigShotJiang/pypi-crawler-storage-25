# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Bring-Your-Own-Key (BYOK) signing and verification for envelopes.

Signs envelopes with private keys (Ed25519, NIST P-256, secp256k1) and produces
self-describing signatures (byok-ed25519:<base64>, etc.). Verifies by parsing the
issuer_did (did:key:z...) to extract the public key, then validates the signature.

Canonicalization follows RFC 8785 (see anchor.canonicalize). Issuer DID is derived
from the public key using multicodec prefixes and base58btc encoding (inverse of
did.resolve_key.parse_did_key).
"""
from __future__ import annotations

import base64
from typing import TYPE_CHECKING

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec, ed25519
from cryptography.hazmat.primitives.asymmetric.utils import decode_dss_signature

from gtv.anchor.canonicalize import canonicalize
from gtv.did.resolve_key import parse_did_key

if TYPE_CHECKING:
    from gtv.models import Envelope


def _base58btc_encode(data: bytes) -> str:
    """Encode bytes to base58btc string (inverse of parse_did_key decoder)."""
    alphabet = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"

    # Convert bytes to integer (big-endian)
    num = int.from_bytes(data, "big")

    # Encode to base58
    if num == 0:
        encoded = [alphabet[0]]
    else:
        encoded = []
        while num > 0:
            num, remainder = divmod(num, 58)
            encoded.append(alphabet[remainder])
        encoded.reverse()

    # Prepend leading zeros (encoded as '1')
    leading_zeros = len(data) - len(data.lstrip(b"\x00"))
    return alphabet[0] * leading_zeros + "".join(encoded)


def _derive_did_key_from_public_key(
    key_type: str,
    public_key_bytes: bytes,
) -> str:
    """Construct a did:key:z... from key type and raw public key bytes.

    Args:
        key_type: "Ed25519", "NIST P-256", or "secp256k1"
        public_key_bytes: Raw public key material

    Returns:
        did:key:z... string

    Raises:
        ValueError: If key_type is unsupported
    """
    # Map key_type to multicodec prefix
    multicodec_prefixes = {
        "Ed25519": b"\xed\x01",
        "NIST P-256": b"\x12\x00",
        "secp256k1": b"\xe7\x01",
    }

    if key_type not in multicodec_prefixes:
        raise ValueError(f"Unsupported key type: {key_type}")

    prefix = multicodec_prefixes[key_type]
    key_material = prefix + public_key_bytes
    encoded = _base58btc_encode(key_material)
    return f"did:key:z{encoded}"


def _extract_public_key_from_pem(
    pem_bytes: bytes,
) -> tuple[str, bytes]:
    """Extract public key bytes and type from a PEM-encoded private key.

    Args:
        pem_bytes: Private key in PEM format

    Returns:
        (key_type, public_key_bytes) tuple

    Raises:
        ValueError: If PEM cannot be parsed or key type is unsupported
    """
    try:
        private_key_obj = serialization.load_pem_private_key(pem_bytes, password=None)
    except Exception as e:
        raise ValueError(f"Failed to load PEM private key: {e}") from e

    if isinstance(private_key_obj, ed25519.Ed25519PrivateKey):
        public_key_ed = private_key_obj.public_key()
        raw_bytes = public_key_ed.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw,
        )
        return "Ed25519", raw_bytes
    elif isinstance(private_key_obj, ec.EllipticCurvePrivateKey):
        public_key_obj: ec.EllipticCurvePublicKey = private_key_obj.public_key()
        if private_key_obj.curve.name == "secp256r1":  # NIST P-256
            # P-256 public keys are typically stored as 65-byte uncompressed or 33-byte compressed
            # For did:key, we use compressed point format (33 bytes)
            raw_bytes = public_key_obj.public_bytes(
                encoding=serialization.Encoding.X962,
                format=serialization.PublicFormat.CompressedPoint,
            )
            return "NIST P-256", raw_bytes
        elif private_key_obj.curve.name == "secp256k1":
            raw_bytes = public_key_obj.public_bytes(
                encoding=serialization.Encoding.X962,
                format=serialization.PublicFormat.CompressedPoint,
            )
            return "secp256k1", raw_bytes
        else:
            raise ValueError(f"Unsupported elliptic curve: {private_key_obj.curve.name}")
    else:
        raise ValueError(f"Unsupported key type: {type(private_key_obj).__name__}")


def sign_envelope_byok(
    envelope: Envelope,
    private_key_pem: bytes,
) -> Envelope:
    """Sign an envelope with a BYOK private key.

    Computes the canonical form (excluding signature, rekor_*, tsa_token, anchor_proof,
    envelope_id, issued_at), signs it, and returns a new Envelope with:
    - signature: "byok-<key_type>:<base64>"
    - issuer_did: "did:key:z..." (derived from public key)

    Args:
        envelope: Envelope to sign (signature field ignored)
        private_key_pem: Private key in PEM format (bytes)

    Returns:
        New Envelope with signature and issuer_did populated

    Raises:
        ValueError: If PEM is invalid or signing fails
    """
    # Extract key material and type
    key_type, public_key_bytes = _extract_public_key_from_pem(private_key_pem)

    # Derive issuer DID from public key
    issuer_did = _derive_did_key_from_public_key(key_type, public_key_bytes)

    # Load the actual private key for signing
    try:
        private_key = serialization.load_pem_private_key(private_key_pem, password=None)
    except Exception as e:
        raise ValueError(f"Failed to load PEM private key: {e}") from e

    # Compute canonical payload (excluding signature-related fields and issuer_did).
    # issuer_did is excluded because we're deriving it from the key, so it's not
    # yet known at signing time. For Sigstore, issuer_did is populated before signing.
    dumped = envelope.model_dump(mode="json")
    for stripped in (
        "signature",
        "rekor_uuid",
        "rekor_log_index",
        "tsa_token",
        "anchor_proof",
        "envelope_id",
        "issued_at",
        "issuer_did",
    ):
        dumped.pop(stripped, None)
    canonical_bytes = canonicalize(dumped)

    # Sign the canonical bytes
    if isinstance(private_key, ed25519.Ed25519PrivateKey):
        sig_bytes = private_key.sign(canonical_bytes)
    elif isinstance(private_key, ec.EllipticCurvePrivateKey):
        # ECDSA signature (P-256 or secp256k1)
        sig_der = private_key.sign(canonical_bytes, ec.ECDSA(hashes.SHA256()))
        # Convert DER to raw format (r || s, each 32 bytes for P-256/secp256k1)
        r, s = decode_dss_signature(sig_der)
        sig_bytes = r.to_bytes(32, byteorder="big") + s.to_bytes(32, byteorder="big")
    else:
        raise ValueError(f"Unsupported key type: {type(private_key).__name__}")

    # Encode signature: byok-<key_type>:<base64>
    # Normalize key type: "NIST P-256" -> "nistp256", "secp256k1" -> "secp256k1"
    sig_type = key_type.lower().replace(" ", "").replace("-", "")
    sig_b64 = base64.b64encode(sig_bytes).decode("ascii")
    signature_str = f"byok-{sig_type}:{sig_b64}"

    # Return new envelope with signature and issuer_did
    return envelope.model_copy(
        update={
            "signature": signature_str,
            "issuer_did": issuer_did,
        }
    )


def verify_envelope_byok(envelope: Envelope) -> None:
    """Verify a BYOK-signed envelope.

    Parses the issuer_did to extract the public key, extracts the signature format,
    and verifies the signature against the canonical envelope payload.

    Args:
        envelope: Envelope with issuer_did (did:key:z...) and signature (byok-*:...)

    Raises:
        ValueError: If DID is malformed, signature format is invalid, or verification fails
    """
    if not envelope.issuer_did.startswith("did:key:z"):
        raise ValueError(
            f"Envelope issuer_did must be a did:key (did:key:z...), got: {envelope.issuer_did}"
        )

    # Parse issuer DID to get public key
    try:
        parsed = parse_did_key(envelope.issuer_did)
    except ValueError as e:
        raise ValueError(f"Failed to parse issuer_did: {e}") from e

    key_type = parsed.key_type
    public_key_bytes = parsed.public_key_bytes

    # Parse signature format: byok-<type>:<base64>
    if not envelope.signature.startswith("byok-"):
        raise ValueError(
            f"Expected byok-* signature format, got: {envelope.signature[:20]}..."
        )

    try:
        sig_type_and_b64 = envelope.signature[5:]  # Strip "byok-"
        sig_type, sig_b64 = sig_type_and_b64.split(":", 1)
        sig_bytes = base64.b64decode(sig_b64)
    except (ValueError, IndexError) as e:
        raise ValueError(f"Invalid signature format: {e}") from e

    # Verify signature type matches key type
    # Normalize key type: "NIST P-256" -> "nistp256", "secp256k1" -> "secp256k1"
    expected_sig_type = key_type.lower().replace(" ", "").replace("-", "")
    if sig_type != expected_sig_type:
        raise ValueError(
            f"Signature type mismatch: expected {expected_sig_type}, got {sig_type}"
        )

    # Compute canonical payload (same exclusions as signing, including issuer_did).
    # issuer_did is excluded because it's derived from the key and not part of the
    # signed payload for BYOK.
    dumped = envelope.model_dump(mode="json")
    for stripped in (
        "signature",
        "rekor_uuid",
        "rekor_log_index",
        "tsa_token",
        "anchor_proof",
        "envelope_id",
        "issued_at",
        "issuer_did",
    ):
        dumped.pop(stripped, None)
    canonical_bytes = canonicalize(dumped)

    # Verify signature
    if key_type == "Ed25519":
        try:
            public_key = ed25519.Ed25519PublicKey.from_public_bytes(public_key_bytes)
            public_key.verify(sig_bytes, canonical_bytes)
        except Exception as e:
            raise ValueError(f"Ed25519 signature verification failed: {e}") from e
    elif key_type in ("NIST P-256", "secp256k1"):
        # Reconstruct the EC public key from bytes (X962 format)
        try:
            if key_type == "NIST P-256":
                from cryptography.hazmat.primitives.asymmetric.ec import (
                    SECP256R1,
                )
                curve_obj: ec.EllipticCurve = SECP256R1()
            else:  # secp256k1
                from cryptography.hazmat.primitives.asymmetric.ec import (
                    SECP256K1,
                )
                curve_obj = SECP256K1()

            public_key_ec = ec.EllipticCurvePublicKey.from_encoded_point(
                curve_obj, public_key_bytes
            )

            # Convert raw signature (r || s, 32 bytes each) to DER format for verification
            if len(sig_bytes) != 64:
                raise ValueError(
                    f"Invalid {key_type} signature length: expected 64, got {len(sig_bytes)}"
                )
            r = int.from_bytes(sig_bytes[:32], byteorder="big")
            s = int.from_bytes(sig_bytes[32:64], byteorder="big")
            from cryptography.hazmat.primitives.asymmetric.utils import (
                encode_dss_signature,
            )
            sig_der = encode_dss_signature(r, s)

            public_key_ec.verify(sig_der, canonical_bytes, ec.ECDSA(hashes.SHA256()))
        except Exception as e:
            raise ValueError(f"{key_type} signature verification failed: {e}") from e
    else:
        raise ValueError(f"Unsupported key type: {key_type}")
