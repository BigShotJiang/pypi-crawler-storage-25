# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""LlamaIndex FunctionTool binding for gtv verify_claim.

Exposes a free function and a factory that don't import llama_index — they
simply define the interface LlamaIndex expects. If the user has llama-index
installed, they can use these as drop-in tools.

Example:

    from gtv.bindings.llamaindex import GtvFunctionTool

    tool = GtvFunctionTool.from_defaults(base_url="http://localhost:8000")
    # tool.fn is the verify_claim function
    # tool.metadata.name == "verify_claim"
    # tool.metadata.description starts with "Verify a factual claim..."
"""
from __future__ import annotations

import os
from typing import Any

import httpx


def verify_claim(claim_text: str, domain: str = "general") -> dict[str, Any]:
    """Verify a factual claim against gtv.

    Args:
        claim_text: The claim to verify.
        domain: Domain constraint (default: "general").

    Returns:
        The envelope dict from gtv with verdict, rationale, evidence, etc.

    Raises:
        httpx.HTTPError: If the request fails.
        ValueError: If the response is malformed.
    """
    base_url = os.getenv("GTV_BASE_URL", "http://localhost:8000")
    api_key = os.getenv("GTV_API_KEY")
    timeout = float(os.getenv("GTV_TIMEOUT", "30.0"))

    url = f"{base_url.rstrip('/')}/tools/verify_claim"
    headers = {"Content-Type": "application/json"}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"

    resp = httpx.post(
        url,
        json={"claim": claim_text, "domain": domain},
        headers=headers,
        timeout=timeout,
    )
    if resp.status_code >= 400:
        raise httpx.HTTPError(f"gtv returned HTTP {resp.status_code}: {resp.text}")

    try:
        data = resp.json()
        envelope = data.get("envelope")
        if not isinstance(envelope, dict):
            raise ValueError(f"expected envelope dict, got {type(envelope).__name__}")
        return envelope
    except Exception as e:
        raise ValueError(f"failed to parse gtv response: {e}") from e


class _ToolMetadata:
    """Duck-typed metadata object for LlamaIndex FunctionTool."""

    def __init__(self, name: str, description: str) -> None:
        self.name = name
        self.description = description


class GtvFunctionTool:
    """LlamaIndex-compatible FunctionTool for verifying claims.

    LlamaIndex expects FunctionTool to have:
      - metadata.name: str
      - metadata.description: str
      - fn: callable

    This class provides those attributes without importing llama_index.
    """

    def __init__(
        self,
        base_url: str | None = None,
        api_key: str | None = None,
        timeout: float = 30.0,
    ) -> None:
        """Initialize the tool.

        Args:
            base_url: URL of the gtv verifier (env default: GTV_BASE_URL).
            api_key: Bearer token for authentication (env default: GTV_API_KEY).
            timeout: HTTP request timeout in seconds.
        """
        self.base_url = base_url or os.getenv("GTV_BASE_URL", "http://localhost:8000")
        self.api_key = api_key or os.getenv("GTV_API_KEY")
        self.timeout = timeout

        self.metadata = _ToolMetadata(
            name="verify_claim",
            description=(
                "Verify a factual claim against federated, cryptographically-signed "
                "evidence sources. Returns verdict, confidence, and rationale."
            ),
        )
        self.fn = self._verify

    def _verify(self, claim_text: str, domain: str = "general") -> dict[str, Any]:
        """Internal verify function with configured base_url/api_key/timeout."""
        url = f"{self.base_url.rstrip('/')}/tools/verify_claim"
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"

        resp = httpx.post(
            url,
            json={"claim": claim_text, "domain": domain},
            headers=headers,
            timeout=self.timeout,
        )
        if resp.status_code >= 400:
            raise httpx.HTTPError(f"gtv returned HTTP {resp.status_code}: {resp.text}")

        try:
            data = resp.json()
            envelope = data.get("envelope")
            if not isinstance(envelope, dict):
                raise ValueError(f"expected envelope dict, got {type(envelope).__name__}")
            return envelope
        except Exception as e:
            raise ValueError(f"failed to parse gtv response: {e}") from e

    @classmethod
    def from_defaults(
        cls,
        base_url: str | None = None,
        api_key: str | None = None,
        timeout: float = 30.0,
    ) -> GtvFunctionTool:
        """Factory to create a GtvFunctionTool with optional overrides.

        Args:
            base_url: Override GTV_BASE_URL environment variable.
            api_key: Override GTV_API_KEY environment variable.
            timeout: HTTP request timeout in seconds.

        Returns:
            A GtvFunctionTool instance ready to use with LlamaIndex agents.
        """
        return cls(base_url=base_url, api_key=api_key, timeout=timeout)
