# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Agent-framework bindings for gtv.

Each submodule exports a tool specification in the shape the target
framework expects, plus a thin HTTP client that marshals calls to the
gtv verifier.

Submodules:

* ``client``          — shared async HTTP client (no framework deps).
* ``openai_tools``    — OpenAI function-calling schema.
* ``anthropic_tools`` — Anthropic tool-use schema.
* ``langchain``       — LangChain ``StructuredTool`` factory
                        (optional; requires ``langchain-core``).
"""
from gtv.bindings.client import GtvClient, GtvHttpError

__all__ = ["GtvClient", "GtvHttpError"]
