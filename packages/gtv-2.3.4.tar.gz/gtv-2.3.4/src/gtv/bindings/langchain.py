# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""LangChain bindings for gtv. Two patterns:

1. Factory (requires langchain-core):
   from gtv.bindings.langchain import make_verify_claim_tool
   tool = make_verify_claim_tool(base_url="http://localhost:8000")

2. Direct class (zero framework deps):
   from gtv.bindings.langchain import GtvVerifyTool
   tool = GtvVerifyTool(base_url="http://localhost:8000")
"""
from __future__ import annotations

import os
from typing import Any

import httpx


class GtvVerifyTool:
    """Duck-typed BaseTool — LangChain discovers _run/_arun via introspection."""

    name: str = "gtv_verify"
    description: str = (
        "Verify a factual claim against federated, cryptographically-signed "
        "evidence sources. Returns verdict, confidence, and rationale."
    )

    def __init__(
        self,
        base_url: str | None = None,
        api_key: str | None = None,
        timeout: float = 30.0,
    ) -> None:
        self.base_url = base_url or os.getenv("GTV_BASE_URL", "http://localhost:8000")
        self.api_key = api_key or os.getenv("GTV_API_KEY")
        self.timeout = timeout

    def _headers(self) -> dict[str, str]:
        h = {"Content-Type": "application/json"}
        if self.api_key:
            h["Authorization"] = f"Bearer {self.api_key}"
        return h

    def _run(self, claim_text: str, domain: str = "general") -> str:
        import httpx as sync_httpx
        url = f"{self.base_url.rstrip('/')}/tools/verify_claim"
        resp = sync_httpx.post(
            url,
            json={"claim": claim_text, "domain": domain},
            headers=self._headers(),
            timeout=self.timeout,
        )
        if resp.status_code >= 400:
            return f"Error {resp.status_code}: {resp.text}"
        try:
            env = resp.json().get("envelope", {})
            return (
                f"Verdict: {env.get('verdict', 'UNKNOWN')} "
                f"(confidence: {env.get('confidence', 0):.1%}). "
                f"{env.get('rationale', '')}"
            )
        except Exception as e:
            return f"Failed: {e}"

    async def _arun(self, claim_text: str, domain: str = "general") -> str:
        url = f"{self.base_url.rstrip('/')}/tools/verify_claim"
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            resp = await client.post(
                url,
                json={"claim": claim_text, "domain": domain},
                headers=self._headers(),
            )
            if resp.status_code >= 400:
                return f"Error {resp.status_code}: {resp.text}"
            try:
                env = resp.json().get("envelope", {})
                return (
                    f"Verdict: {env.get('verdict', 'UNKNOWN')} "
                    f"(confidence: {env.get('confidence', 0):.1%}). "
                    f"{env.get('rationale', '')}"
                )
            except Exception as e:
                return f"Failed: {e}"


def _import_structured_tool() -> Any:
    """Lazy-import StructuredTool."""
    try:
        from langchain_core.tools import StructuredTool  # type: ignore[import-not-found]
    except ImportError as e:
        raise ImportError(
            "langchain_core is required for gtv.bindings.langchain. "
            "Install with: pip install langchain-core"
        ) from e
    return StructuredTool


def make_verify_claim_tool(
    base_url: str = "http://localhost:8000",
    *,
    api_key: str | None = None,
    name: str = "gtv_verify_claim",
    description: str | None = None,
) -> Any:
    """Build a StructuredTool for verify_claim."""
    structured_tool = _import_structured_tool()

    async def _run(
        claim: str, domain: str = "general", max_sources: int = 5
    ) -> dict[str, Any]:
        from gtv.bindings.client import GtvClient

        async with GtvClient(base_url, api_key=api_key) as client:
            return await client.verify_claim(
                claim, domain=domain, max_sources=max_sources
            )

    return structured_tool.from_function(
        coroutine=_run,
        name=name,
        description=description or "Verify a factual claim against federated evidence.",
    )


def make_retrieve_facts_tool(
    base_url: str = "http://localhost:8000",
    *,
    api_key: str | None = None,
    name: str = "gtv_retrieve_facts",
    description: str | None = None,
) -> Any:
    """Build a StructuredTool for retrieve_facts."""
    structured_tool = _import_structured_tool()

    async def _run(
        query: str, domain: str = "general", max_results: int = 5
    ) -> dict[str, Any]:
        from gtv.bindings.client import GtvClient

        async with GtvClient(base_url, api_key=api_key) as client:
            return await client.retrieve_facts(
                query, domain=domain, max_results=max_results
            )

    return structured_tool.from_function(
        coroutine=_run,
        name=name,
        description=description or "Retrieve multiple evidenced facts about a topic.",
    )
