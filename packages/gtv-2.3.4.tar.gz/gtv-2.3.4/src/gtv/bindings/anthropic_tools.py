# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Anthropic tool-use bindings for gtv.

Anthropic's tool-use schema is flatter than OpenAI's — the tool dict
itself carries ``name``, ``description``, and ``input_schema`` at the
top level (no nested ``function`` key).

As with the OpenAI bindings, no anthropic-python dependency here —
just dicts in the shape the Messages API expects. Pass ``TOOLS`` to
``client.messages.create(tools=...)``, then route each returned
``tool_use`` block through :func:`dispatch`.

Example:

    from anthropic import AsyncAnthropic
    from gtv.bindings.anthropic_tools import TOOLS, dispatch
    from gtv.bindings.client import GtvClient

    llm = AsyncAnthropic()
    async with GtvClient("http://localhost:8000") as gtv:
        msg = await llm.messages.create(
            model="claude-3-5-sonnet-latest",
            max_tokens=1024,
            tools=TOOLS,
            messages=[{"role": "user", "content": "Fact-check this claim..."}],
        )
        for block in msg.content:
            if block.type == "tool_use":
                result = await dispatch(gtv, block.name, block.input)
"""
from __future__ import annotations

from typing import Any

from gtv.bindings.client import GtvClient

VERIFY_CLAIM_TOOL: dict[str, Any] = {
    "name": "verify_claim",
    "description": (
        "Verify a single factual claim against federated, cryptographically-"
        "signed evidence sources. Returns a signed envelope with verdict, "
        "confidence, evidence excerpts, and anchor proofs."
    ),
    "input_schema": {
        "type": "object",
        "properties": {
            "claim": {
                "type": "string",
                "description": "The factual claim to verify (1-2000 chars).",
            },
            "domain": {
                "type": "string",
                "enum": ["physics", "math", "cs", "astronomy", "materials", "general"],
                "description": "Topic domain. Defaults to 'general'.",
            },
            "max_sources": {
                "type": "integer",
                "minimum": 1,
                "maximum": 20,
                "description": "Maximum evidence items per source. Defaults to 5.",
            },
        },
        "required": ["claim"],
    },
}


RETRIEVE_FACTS_TOOL: dict[str, Any] = {
    "name": "retrieve_facts",
    "description": (
        "Retrieve multiple evidenced facts about a topic. Each fact is "
        "independently verified and included in a single signed envelope."
    ),
    "input_schema": {
        "type": "object",
        "properties": {
            "query": {
                "type": "string",
                "description": "Free-text query (1-500 chars).",
            },
            "domain": {
                "type": "string",
                "enum": ["physics", "math", "cs", "astronomy", "materials", "general"],
                "description": "Topic domain. Defaults to 'general'.",
            },
            "max_results": {
                "type": "integer",
                "minimum": 1,
                "maximum": 20,
                "description": "Maximum fact items to return. Defaults to 5.",
            },
        },
        "required": ["query"],
    },
}


TOOLS: list[dict[str, Any]] = [VERIFY_CLAIM_TOOL, RETRIEVE_FACTS_TOOL]


async def dispatch(
    client: GtvClient,
    tool_name: str,
    tool_input: dict[str, Any],
) -> dict[str, Any]:
    """Dispatch an Anthropic ``tool_use`` block to the matching gtv endpoint.

    Args:
        client: An open ``GtvClient``.
        tool_name: The ``name`` field on a ``tool_use`` content block.
        tool_input: The ``input`` dict from the same block.

    Returns:
        The JSON body the verifier returned (envelope or facts envelope).

    Raises:
        ValueError: unknown tool name.
    """
    if tool_name == "verify_claim":
        return await client.verify_claim(**tool_input)
    if tool_name == "retrieve_facts":
        return await client.retrieve_facts(**tool_input)
    raise ValueError(f"unknown gtv tool: {tool_name}")
