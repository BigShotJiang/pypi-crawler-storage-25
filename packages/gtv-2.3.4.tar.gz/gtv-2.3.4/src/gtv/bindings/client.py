# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Thin async HTTP client for the gtv verifier.

Every agent binding in this package uses this one transport so there's
exactly one place to update auth, retry policy, or request shape. The
client is framework-agnostic — the OpenAI / Anthropic / LangChain
bindings all call these same methods.

Design notes:

* httpx is already a core dep, so this adds no new runtime bloat.
* Bearer-token auth is optional; if ``api_key`` is None the header is
  omitted (matches the server's open-by-default mode).
* Errors surface as ``GtvHttpError`` with status + body for the caller
  to log. Network errors propagate as httpx exceptions — callers that
  want them flattened should wrap.
"""
from __future__ import annotations

from typing import Any

import httpx


class GtvHttpError(Exception):
    """Non-2xx response from the gtv verifier."""

    def __init__(self, status: int, body: str) -> None:
        super().__init__(f"gtv returned HTTP {status}: {body}")
        self.status = status
        self.body = body


class GtvClient:
    """Async client for the gtv verifier HTTP API.

    Usage:

        async with GtvClient("http://localhost:8000", api_key="...") as c:
            env = await c.verify_claim("The speed of light is 3e8 m/s.")
    """

    def __init__(
        self,
        base_url: str = "http://localhost:8000",
        *,
        api_key: str | None = None,
        timeout: float = 30.0,
        client: httpx.AsyncClient | None = None,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._api_key = api_key
        self._owns_client = client is None
        self._client = client or httpx.AsyncClient(timeout=timeout)

    async def __aenter__(self) -> GtvClient:
        return self

    async def __aexit__(self, *_: object) -> None:
        await self.aclose()

    async def aclose(self) -> None:
        """Close the underlying httpx client if we own it."""
        if self._owns_client:
            await self._client.aclose()

    def _headers(self) -> dict[str, str]:
        h = {"Content-Type": "application/json"}
        if self._api_key:
            h["Authorization"] = f"Bearer {self._api_key}"
        return h

    async def _post(self, path: str, body: dict[str, Any]) -> dict[str, Any]:
        url = f"{self._base_url}{path}"
        resp = await self._client.post(url, json=body, headers=self._headers())
        if resp.status_code >= 400:
            raise GtvHttpError(resp.status_code, resp.text)
        data = resp.json()
        if not isinstance(data, dict):
            raise GtvHttpError(resp.status_code, f"expected JSON object, got {type(data).__name__}")
        return data

    async def verify_claim(
        self,
        claim: str,
        *,
        domain: str = "general",
        context: str | None = None,
        min_confidence: float = 0.5,
        max_sources: int = 5,
    ) -> dict[str, Any]:
        """POST /tools/verify_claim and return the envelope JSON."""
        body: dict[str, Any] = {
            "claim": claim,
            "domain": domain,
            "min_confidence": min_confidence,
            "max_sources": max_sources,
        }
        if context is not None:
            body["context"] = context
        data = await self._post("/tools/verify_claim", body)
        envelope = data.get("envelope")
        if not isinstance(envelope, dict):
            raise GtvHttpError(200, f"missing envelope in response: {data}")
        return envelope

    async def retrieve_facts(
        self,
        query: str,
        *,
        domain: str = "general",
        max_results: int = 5,
    ) -> dict[str, Any]:
        """POST /tools/retrieve_facts and return the envelope JSON."""
        return await self._post(
            "/tools/retrieve_facts",
            {"query": query, "domain": domain, "max_results": max_results},
        )

    async def consensus(self, envelopes: list[dict[str, Any]]) -> dict[str, Any]:
        """POST /consensus and return the aggregate response."""
        return await self._post("/consensus", {"envelopes": envelopes})
