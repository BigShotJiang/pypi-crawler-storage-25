# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""OpenAI function-calling bindings for gtv.

Exports two tool specs that can be passed directly to the OpenAI
chat-completions API under ``tools=[...]``, plus a small async dispatch
helper that turns an OpenAI tool call into a gtv HTTP request.

No OpenAI SDK dependency here — this module just emits plain dicts in
the shape the API expects. That keeps gtv installable without pulling
openai-python into every user's tree.

Example:

    from openai import AsyncOpenAI
    from gtv.bindings.openai_tools import TOOLS, dispatch
    from gtv.bindings.client import GtvClient

    llm = AsyncOpenAI()
    async with GtvClient("http://localhost:8000") as gtv:
        resp = await llm.chat.completions.create(
            model="gpt-4o", tools=TOOLS,
            messages=[{"role": "user", "content": "Fact-check this claim..."}],
        )
        for call in resp.choices[0].message.tool_calls or []:
            result = await dispatch(gtv, call.function.name, call.function.arguments)
"""
from __future__ import annotations

import json
from typing import Any

from gtv.bindings.client import GtvClient

VERIFY_CLAIM_TOOL: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "verify_claim",
        "description": (
            "Verify a single factual claim against federated, cryptographically-"
            "signed evidence sources. Returns a signed envelope with verdict, "
            "confidence, evidence excerpts, and anchor proofs."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "claim": {
                    "type": "string",
                    "description": "The factual claim to verify (1-2000 chars).",
                },
                "domain": {
                    "type": "string",
                    "enum": ["physics", "math", "cs", "astronomy", "materials", "general"],
                    "description": "Topic domain. Defaults to 'general'.",
                },
                "max_sources": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": 20,
                    "description": "Maximum evidence items to fetch per source. Defaults to 5.",
                },
            },
            "required": ["claim"],
        },
    },
}


RETRIEVE_FACTS_TOOL: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "retrieve_facts",
        "description": (
            "Retrieve multiple evidenced facts about a topic. Each fact is "
            "independently verified and included in a single signed envelope."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Free-text query (1-500 chars).",
                },
                "domain": {
                    "type": "string",
                    "enum": ["physics", "math", "cs", "astronomy", "materials", "general"],
                    "description": "Topic domain. Defaults to 'general'.",
                },
                "max_results": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": 20,
                    "description": "Maximum fact items to return. Defaults to 5.",
                },
            },
            "required": ["query"],
        },
    },
}


TOOLS: list[dict[str, Any]] = [VERIFY_CLAIM_TOOL, RETRIEVE_FACTS_TOOL]


async def dispatch(
    client: GtvClient,
    function_name: str,
    arguments: str | dict[str, Any],
) -> dict[str, Any]:
    """Dispatch an OpenAI tool call to the matching gtv endpoint.

    Args:
        client: An open ``GtvClient``.
        function_name: The tool name from ``tool_call.function.name``.
        arguments: The tool-call arguments. OpenAI returns this as a
            JSON string; dict is also accepted for direct testing.

    Returns:
        The JSON body the verifier returned (envelope or facts envelope).

    Raises:
        ValueError: unknown function name or invalid arguments JSON.
    """
    if isinstance(arguments, str):
        try:
            args = json.loads(arguments)
        except json.JSONDecodeError as e:
            raise ValueError(f"invalid tool arguments JSON: {e}") from e
    else:
        args = arguments

    if function_name == "verify_claim":
        return await client.verify_claim(**args)
    if function_name == "retrieve_facts":
        return await client.retrieve_facts(**args)
    raise ValueError(f"unknown gtv tool: {function_name}")
