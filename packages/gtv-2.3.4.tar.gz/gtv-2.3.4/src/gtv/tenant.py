# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Multi-tenant identity resolution.

A tenant is defined by exactly two things: a stable string id
(``tenant_id``) and the issuer DID it signs verdicts under. Everything
else that feels "tenant-scoped" (verdict cache, lifecycle chain) is
already keyed by issuer DID, so the multi-tenant boundary is simply:
**each tenant signs under a distinct issuer DID**.

Key points
----------
* The server-default tenant has ``tenant_id == ""`` and
  ``issuer_did == GTV_ISSUER_DID`` (or the hardcoded placeholder if the
  env var is unset).
* When auth is disabled, every request runs as the default tenant.
* When an API key authenticates, ``auth.middleware`` attaches a
  ``Tenant`` to ``request.state`` so handlers can resolve it without
  reaching back into the keystore.

This module has no dependency on FastAPI so non-HTTP call sites
(tests, CLI) can build a tenant directly.
"""
from __future__ import annotations

import os
from dataclasses import dataclass

DEFAULT_ISSUER_DID_FALLBACK = "did:web:verify.groundtruth.example"


@dataclass(frozen=True)
class Tenant:
    """Immutable tenant identity used during request handling."""

    tenant_id: str
    issuer_did: str

    @property
    def is_default(self) -> bool:
        """True if this tenant is the unnamed server-default tenant."""
        return self.tenant_id == ""


def default_tenant() -> Tenant:
    """Build the server-default tenant from the environment.

    Called at request time (not at import time) so tests that
    monkeypatch ``GTV_ISSUER_DID`` see the expected value.
    """
    return Tenant(
        tenant_id="",
        issuer_did=os.environ.get("GTV_ISSUER_DID", DEFAULT_ISSUER_DID_FALLBACK),
    )


def tenant_from_api_key(
    tenant_id: str,
    issuer_did_override: str | None,
) -> Tenant:
    """Construct a Tenant from API-key columns.

    A blank ``issuer_did_override`` falls through to the server-default
    DID, so an operator can tag keys with a tenant label for
    metrics/audit purposes without forcing every tenant to run under a
    distinct DID.
    """
    if issuer_did_override:
        return Tenant(tenant_id=tenant_id, issuer_did=issuer_did_override)
    return Tenant(
        tenant_id=tenant_id,
        issuer_did=os.environ.get("GTV_ISSUER_DID", DEFAULT_ISSUER_DID_FALLBACK),
    )


def resolve_tenant(request: object) -> Tenant:
    """Return the tenant attached to ``request.state`` or the default.

    Accepts anything with a ``.state`` attribute (Starlette ``Request``)
    so we don't have to take a FastAPI dependency here. When the auth
    middleware hasn't stashed a tenant (auth disabled, /health,
    /metrics, or a missing key), we fall back to the server default so
    callers always get a valid issuer DID.
    """
    state = getattr(request, "state", None)
    if state is not None:
        tenant = getattr(state, "tenant", None)
        if isinstance(tenant, Tenant):
            return tenant
    return default_tenant()
