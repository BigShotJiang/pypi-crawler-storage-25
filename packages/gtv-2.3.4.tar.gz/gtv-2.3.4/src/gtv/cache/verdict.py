# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Signed verdict cache.

The cache layer is **zero-trust**: on every read we re-derive the
canonical hash from the cached envelope and verify the embedded
signature matches. If anything is off — truncated bytes, swapped
envelope, forged entry — the cache entry is dropped and we fall through
to a fresh verification.

Design notes:
  * The cache stores the full signed ``Envelope`` as canonical JSON bytes.
  * TTL = min(adapter freshness SLAs for evidence in the envelope),
    clamped by ``GTV_CACHE_TTL_MAX_S`` and ``GTV_CACHE_TTL_MIN_S``.
    OPINION / CREATIVE / OUT_OF_SCOPE envelopes have no evidence — they
    use the default TTL (``GTV_CACHE_TTL_S``).
  * Signature re-validation uses the same ECDSA-over-canonical-hash
    machinery ``gtv-verify`` uses. Stub envelopes are checked against
    the stub-signing rule (``stub://{sha256(canonical_hash_hex)}``),
    so a tampered envelope still gets rejected even in dev/CI.
"""
from __future__ import annotations

import base64
import hashlib
import json
import logging
import os
from dataclasses import dataclass

from cryptography import x509
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec

from gtv.anchor.canonicalize import envelope_canonical_sha256
from gtv.cache.key import CacheKey
from gtv.cache.store import CacheStore, InMemoryCacheStore, NullCacheStore, RedisCacheStore
from gtv.models import Envelope

logger = logging.getLogger(__name__)

# Default TTL for envelopes with no evidence (OPINION / CREATIVE / OUT_OF_SCOPE).
_DEFAULT_TTL_S = 300
# Absolute clamps so a pathological SLA can't pin a result forever or flap instantly.
_DEFAULT_TTL_MIN_S = 1
_DEFAULT_TTL_MAX_S = 3600


@dataclass(frozen=True)
class CacheStats:
    hits: int = 0
    misses: int = 0
    signature_rejections: int = 0
    deserialize_errors: int = 0


class VerdictCache:
    """Zero-trust cache: revalidates envelopes on read."""

    def __init__(
        self,
        store: CacheStore,
        *,
        default_ttl_s: int = _DEFAULT_TTL_S,
        ttl_min_s: int = _DEFAULT_TTL_MIN_S,
        ttl_max_s: int = _DEFAULT_TTL_MAX_S,
    ) -> None:
        self._store = store
        self._default_ttl_s = default_ttl_s
        self._ttl_min_s = ttl_min_s
        self._ttl_max_s = ttl_max_s
        # In-process counters so tests/metrics can cross-check without prometheus.
        self._hits = 0
        self._misses = 0
        self._sig_rejections = 0
        self._deserialize_errors = 0

    @property
    def stats(self) -> CacheStats:
        return CacheStats(
            hits=self._hits,
            misses=self._misses,
            signature_rejections=self._sig_rejections,
            deserialize_errors=self._deserialize_errors,
        )

    async def get(self, key: CacheKey) -> Envelope | None:
        """Look up a cached envelope. Returns None on miss/invalid."""
        raw = await self._store.get(key.digest)
        if raw is None:
            self._misses += 1
            return None

        # Deserialize
        try:
            data = json.loads(raw)
            envelope = Envelope.model_validate(data)
        except Exception as e:
            logger.warning("cache: deserialize error, evicting %s: %s", key.digest[:12], e)
            self._deserialize_errors += 1
            await self._store.delete(key.digest)
            self._misses += 1
            return None

        # Re-validate signature. A bad envelope never escapes the cache.
        if not self._signature_ok(envelope):
            logger.warning("cache: signature mismatch, evicting %s", key.digest[:12])
            self._sig_rejections += 1
            await self._store.delete(key.digest)
            self._misses += 1
            return None

        self._hits += 1
        return envelope

    async def set(self, key: CacheKey, envelope: Envelope) -> None:
        """Cache an envelope. TTL = min(evidence SLAs) clamped to our range."""
        raw = envelope.model_dump_json().encode("utf-8")
        ttl = self._compute_ttl(envelope)
        await self._store.set(key.digest, raw, ttl_s=ttl)

    async def invalidate(self, key: CacheKey) -> None:
        await self._store.delete(key.digest)

    async def clear(self) -> None:
        await self._store.clear()

    def _compute_ttl(self, envelope: Envelope) -> int:
        # Evidence-based freshness: use the tightest adapter SLA on the envelope.
        # Evidence doesn't carry its own freshness_sla_s directly, so we look up
        # the adapter by source_did at cache time via the registry. Import here
        # to avoid a top-level circular import.
        from gtv.adapters import REGISTRY

        slas: list[int] = []
        for ev in envelope.evidence:
            for adapter in REGISTRY.values():
                if adapter.source_did == ev.source_did:
                    slas.append(int(adapter.freshness_sla_s))
                    break

        if not slas:
            return max(self._ttl_min_s, min(self._default_ttl_s, self._ttl_max_s))

        return max(self._ttl_min_s, min(min(slas), self._ttl_max_s))

    def _signature_ok(self, envelope: Envelope) -> bool:
        """Re-compute canonical hash and verify the embedded signature.

        Stub envelopes (signature prefix ``stub://``) are accepted after
        the canonical-hash check only — they're only used in dev/test.
        """
        canonical_hex = envelope_canonical_sha256(envelope)

        if envelope.signature.startswith("stub://"):
            # Stub signing (see gtv.anchor.sign._sign_stub): signature is
            # ``stub://{sha256(canonical_hash_hex)}``. Recompute the same
            # digest; a tampered envelope changes the canonical hash and the
            # derived digest, so the check fails loudly.
            expected_digest = hashlib.sha256(canonical_hex.encode("utf-8")).hexdigest()
            return envelope.signature == f"stub://{expected_digest}"

        # Real signature: re-verify ECDSA over the canonical hash bytes.
        try:
            sig_bytes = base64.b64decode(envelope.signature)
            proof = json.loads(envelope.anchor_proof.rekor_inclusion_proof)
            cert_pem = proof.get("certificate_pem")
            if not cert_pem:
                return False
            cert = x509.load_pem_x509_certificate(
                cert_pem.encode("utf-8"), backend=default_backend()
            )
            pub = cert.public_key()
            if not isinstance(pub, ec.EllipticCurvePublicKey):
                return False
            pub.verify(sig_bytes, bytes.fromhex(canonical_hex), ec.ECDSA(hashes.SHA256()))
            return True
        except Exception:
            return False


def make_cache_from_env() -> VerdictCache:
    """Build a VerdictCache wired to whichever backend the env asks for.

    Flags:
      * ``GTV_CACHE_ENABLED`` — ``0`` to disable entirely (returns a
        cache wrapping ``NullCacheStore``). Default: ``1``.
      * ``GTV_CACHE_REDIS_URL`` — if set, uses Redis. Otherwise in-memory.
      * ``GTV_CACHE_TTL_S`` — default TTL in seconds (default 300).
      * ``GTV_CACHE_TTL_MIN_S`` / ``GTV_CACHE_TTL_MAX_S`` — clamps.
    """
    if os.environ.get("GTV_CACHE_ENABLED", "1") == "0":
        return VerdictCache(NullCacheStore())

    default_ttl = int(os.environ.get("GTV_CACHE_TTL_S", str(_DEFAULT_TTL_S)))
    ttl_min = int(os.environ.get("GTV_CACHE_TTL_MIN_S", str(_DEFAULT_TTL_MIN_S)))
    ttl_max = int(os.environ.get("GTV_CACHE_TTL_MAX_S", str(_DEFAULT_TTL_MAX_S)))

    redis_url = os.environ.get("GTV_CACHE_REDIS_URL")
    store: CacheStore
    store = RedisCacheStore(redis_url) if redis_url else InMemoryCacheStore()
    return VerdictCache(
        store,
        default_ttl_s=default_ttl,
        ttl_min_s=ttl_min,
        ttl_max_s=ttl_max,
    )
