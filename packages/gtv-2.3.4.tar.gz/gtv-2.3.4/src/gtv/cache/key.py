# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Deterministic cache keys for verify_claim envelopes.

First-principles rule: the key must cover every input that affects the
envelope. Claim text + domain + max_sources + issuer_did is sufficient;
nothing else is user-controlled. Normalize whitespace and case so trivial
variants collide instead of missing.
"""
from __future__ import annotations

import hashlib
import unicodedata
from dataclasses import dataclass


@dataclass(frozen=True)
class CacheKey:
    """A cache key derived from the user-facing inputs.

    Attributes:
        digest: 64-char lowercase hex sha256 of the normalized tuple.
        claim_normalized: The claim text after whitespace/case normalization.
        domain: The claim domain (lowercased).
        max_sources: The max-sources cap (stored as-is).
        issuer_did: The issuer DID this verifier would sign under.
    """

    digest: str
    claim_normalized: str
    domain: str
    max_sources: int
    issuer_did: str


def normalize_claim(text: str) -> str:
    """Collapse whitespace and unicode-normalize.

    Rules:
    - NFKC unicode normalization (e.g. full-width digits → ASCII).
    - Collapse runs of whitespace to a single space.
    - Strip leading/trailing whitespace.
    - Casefold (stronger than lower() for i18n).
    """
    nfkc = unicodedata.normalize("NFKC", text)
    collapsed = " ".join(nfkc.split())
    return collapsed.casefold()


def build_key(
    *,
    claim_text: str,
    domain: str,
    max_sources: int,
    issuer_did: str,
) -> CacheKey:
    """Construct a CacheKey from the verify_claim request inputs."""
    normalized = normalize_claim(claim_text)
    domain_lc = domain.casefold()
    payload = "\x1f".join([normalized, domain_lc, str(int(max_sources)), issuer_did])
    digest = hashlib.sha256(payload.encode("utf-8")).hexdigest()
    return CacheKey(
        digest=digest,
        claim_normalized=normalized,
        domain=domain_lc,
        max_sources=int(max_sources),
        issuer_did=issuer_did,
    )
