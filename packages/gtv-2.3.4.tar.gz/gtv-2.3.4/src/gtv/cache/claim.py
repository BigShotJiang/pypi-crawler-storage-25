# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Per-claim cache layer for normalized text, tokens, and identifiers.

This module caches the expensive parsing results of a Claim so that repeated
work on the same text (regardless of claim_id) is skipped. The cache key is
sha256(normalized_text + "|" + domain), making two Claims with identical text
and domain share a cache entry.
"""
from __future__ import annotations

import hashlib
import re
import time
from collections import OrderedDict
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from gtv.models import Claim


@dataclass(frozen=True)
class ParsedClaim:
    """Immutable result of parsing a Claim's text and domain.

    Attributes:
        claim_id: The original claim_id (for traceability).
        normalized_text: Lowercased, whitespace-collapsed, punct-trimmed text.
        tokens: Tuple of alphanumeric tokens extracted from normalized_text.
        domain: The claim's domain.
        identifiers: Dict mapping identifier type to list of found values.
            Keys: "cve", "doi", "arxiv", "pmid".
        cached_at: time.monotonic() when this entry was created.
    """

    claim_id: str
    normalized_text: str
    tokens: tuple[str, ...]
    domain: str
    identifiers: dict[str, list[str]]
    cached_at: float


class ClaimCache:
    """LRU cache for ParsedClaim entries with TTL support.

    Key: sha256(normalized_text + "|" + domain).hexdigest()
    Eviction: LRU when max_entries exceeded; TTL-based on time.monotonic().

    The cache ignores claim_id, so two Claim objects with identical text
    and domain return the same cached ParsedClaim.
    """

    def __init__(self, ttl_s: float = 3600.0, max_entries: int = 5000) -> None:
        """Initialize the cache.

        Args:
            ttl_s: Time-to-live in seconds. 0 disables TTL.
            max_entries: Maximum number of entries before LRU eviction.
        """
        self.ttl_s = ttl_s
        self.max_entries = max_entries
        self._cache: OrderedDict[str, ParsedClaim] = OrderedDict()
        self._hits = 0
        self._misses = 0
        self._evictions = 0

    def get_or_parse(self, claim: Claim) -> ParsedClaim:
        """Get or parse a claim, returning a ParsedClaim.

        Args:
            claim: A Claim model instance.

        Returns:
            A ParsedClaim with normalized text, tokens, and identifiers.
        """
        cache_key = self._make_key(claim.text, claim.domain)

        # Check cache hit (not expired).
        if cache_key in self._cache:
            entry = self._cache[cache_key]
            if self.ttl_s <= 0 or (time.monotonic() - entry.cached_at <= self.ttl_s):
                # Move to end (most recent).
                self._cache.move_to_end(cache_key)
                self._hits += 1
                return entry
            else:
                # TTL expired; remove and treat as miss.
                del self._cache[cache_key]

        # Cache miss; parse.
        self._misses += 1
        parsed = self._parse_claim(claim)

        # Store in cache.
        self._cache[cache_key] = parsed
        self._cache.move_to_end(cache_key)

        # Evict LRU if needed.
        while len(self._cache) > self.max_entries:
            self._cache.popitem(last=False)  # Remove oldest.
            self._evictions += 1

        return parsed

    def stats(self) -> dict[str, int]:
        """Return cache statistics.

        Returns:
            A dict with keys: hits, misses, evictions, entries.
        """
        return {
            "hits": self._hits,
            "misses": self._misses,
            "evictions": self._evictions,
            "entries": len(self._cache),
        }

    def clear(self) -> None:
        """Clear all cached entries and reset statistics."""
        self._cache.clear()
        self._hits = 0
        self._misses = 0
        self._evictions = 0

    @staticmethod
    def _make_key(claim_text: str, domain: str) -> str:
        """Build a cache key from claim text and domain.

        Args:
            claim_text: The claim text.
            domain: The claim domain (as string or StrEnum).

        Returns:
            A sha256 hex digest.
        """
        normalized = claim_text.strip().lower()
        domain_str = str(domain).lower()
        payload = f"{normalized}|{domain_str}"
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()

    @staticmethod
    def _parse_claim(claim: Claim) -> ParsedClaim:
        """Parse a claim into normalized text, tokens, and identifiers.

        Args:
            claim: A Claim model instance.

        Returns:
            A ParsedClaim with parsed results.
        """
        # Normalize: lowercase, collapse whitespace, strip leading/trailing punct.
        normalized = claim.text.lower()
        normalized = " ".join(normalized.split())  # Collapse whitespace.
        normalized = normalized.strip("'.\"!?,;:-()[]{}@#$%^&*_=+`~")

        # Tokenize: split on non-alphanumeric, drop empties.
        tokens = tuple(t for t in re.split(r"\W+", normalized) if t)

        # Extract identifiers.
        identifiers = ClaimCache._extract_identifiers(claim.text)

        return ParsedClaim(
            claim_id=claim.claim_id,
            normalized_text=normalized,
            tokens=tokens,
            domain=str(claim.domain),
            identifiers=identifiers,
            cached_at=time.monotonic(),
        )

    @staticmethod
    def _extract_identifiers(text: str) -> dict[str, list[str]]:
        """Extract identifiers from claim text.

        Patterns:
        - cve: CVE-YYYY-NNNN or CVE-YYYY-NNNNNNN (case-insensitive, stored uppercase).
        - doi: 10.NNNN.../...
        - arxiv: NNNN.NNNNN or NNNN.NNNNN vN
        - pmid: after "PMID:" or in pubmed.ncbi.nlm.nih.gov/<digits>

        Args:
            text: The claim text.

        Returns:
            A dict mapping identifier type to list of found values.
        """
        identifiers: dict[str, list[str]] = {
            "cve": [],
            "doi": [],
            "arxiv": [],
            "pmid": [],
        }

        # CVE: CVE-YYYY-NNNN or CVE-YYYY-NNNNNNN
        cve_pattern = r"CVE-\d{4}-\d{4,7}"
        for match in re.finditer(cve_pattern, text, re.IGNORECASE):
            identifiers["cve"].append(match.group(0).upper())

        # DOI: 10.NNNN+/[^\s]+
        doi_pattern = r"10\.\d{4,9}/[^\s]+"
        for match in re.finditer(doi_pattern, text):
            identifiers["doi"].append(match.group(0))

        # arXiv: NNNN.NNNNN(vN)?
        arxiv_pattern = r"\d{4}\.\d{4,5}(?:v\d+)?"
        for match in re.finditer(arxiv_pattern, text):
            identifiers["arxiv"].append(match.group(0))

        # PMID: after "PMID:" or in URL pubmed.ncbi.nlm.nih.gov/<digits>
        pmid_after_label = r"PMID[:\s]+(\d+)"
        for match in re.finditer(pmid_after_label, text, re.IGNORECASE):
            identifiers["pmid"].append(match.group(1))

        pmid_in_url = r"pubmed\.ncbi\.nlm\.nih\.gov/(\d+)"
        for match in re.finditer(pmid_in_url, text):
            pmid_val = match.group(1)
            if pmid_val not in identifiers["pmid"]:
                identifiers["pmid"].append(pmid_val)

        # Remove duplicates while preserving order.
        for key in identifiers:
            identifiers[key] = list(dict.fromkeys(identifiers[key]))

        return identifiers
