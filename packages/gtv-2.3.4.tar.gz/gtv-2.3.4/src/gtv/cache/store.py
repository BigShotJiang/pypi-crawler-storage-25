# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Storage backends for the verdict cache.

Three backends, one Protocol:
  * ``InMemoryCacheStore`` — dict with per-key expiry. Default.
  * ``RedisCacheStore`` — uses ``redis.asyncio``. Opt in by setting
    ``GTV_CACHE_REDIS_URL``.
  * ``NullCacheStore`` — returns None on every read. For disabled state.

Every backend stores raw bytes (the envelope as canonical JSON) with a
TTL in seconds. The caller — ``VerdictCache`` — owns serialization and
signature re-validation. The store is *dumb* on purpose: if it gets
compromised, the cryptographic check in ``VerdictCache.get`` catches it.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Protocol


class CacheStore(Protocol):
    """Raw bytes-in / bytes-out cache with TTL."""

    async def get(self, key: str) -> bytes | None: ...
    async def set(self, key: str, value: bytes, ttl_s: int) -> None: ...
    async def delete(self, key: str) -> None: ...
    async def clear(self) -> None: ...


@dataclass
class _Entry:
    value: bytes
    expires_at: float


@dataclass
class InMemoryCacheStore:
    """Process-local dict with per-key expiry. Not LRU-bounded on purpose:
    callers that want a bound should plug in Redis with maxmemory.

    Thread/async safety: single-threaded event-loop is assumed (standard
    asyncio). No locks. If you multi-thread this, wrap it.
    """

    _store: dict[str, _Entry] = field(default_factory=dict)

    async def get(self, key: str) -> bytes | None:
        entry = self._store.get(key)
        if entry is None:
            return None
        if entry.expires_at <= time.monotonic():
            self._store.pop(key, None)
            return None
        return entry.value

    async def set(self, key: str, value: bytes, ttl_s: int) -> None:
        self._store[key] = _Entry(value=value, expires_at=time.monotonic() + max(1, ttl_s))

    async def delete(self, key: str) -> None:
        self._store.pop(key, None)

    async def clear(self) -> None:
        self._store.clear()


class NullCacheStore:
    """Backend that stores nothing. Used when caching is disabled."""

    async def get(self, key: str) -> bytes | None:
        return None

    async def set(self, key: str, value: bytes, ttl_s: int) -> None:
        return None

    async def delete(self, key: str) -> None:
        return None

    async def clear(self) -> None:
        return None


class RedisCacheStore:
    """Redis-backed cache. Uses ``redis.asyncio`` — in ``dependencies``.

    Keys are prefixed so multiple gtv instances sharing a Redis don't
    collide by default.
    """

    def __init__(self, url: str, *, key_prefix: str = "gtv:verdict:") -> None:
        # Import lazily so users without a Redis URL don't need the driver
        # codepath at import time. Redis is already in project deps.
        import redis.asyncio as aioredis

        self._client = aioredis.from_url(url, decode_responses=False)
        self._prefix = key_prefix

    def _k(self, key: str) -> str:
        return f"{self._prefix}{key}"

    async def get(self, key: str) -> bytes | None:
        value = await self._client.get(self._k(key))
        if value is None:
            return None
        # redis-py's typing is loose here; at runtime it returns bytes because
        # we set decode_responses=False.
        return bytes(value)

    async def set(self, key: str, value: bytes, ttl_s: int) -> None:
        await self._client.set(self._k(key), value, ex=max(1, ttl_s))

    async def delete(self, key: str) -> None:
        await self._client.delete(self._k(key))

    async def clear(self) -> None:
        # Deliberately only clears our prefix. SCAN is O(N) — caller's problem.
        async for key in self._client.scan_iter(match=f"{self._prefix}*"):
            await self._client.delete(key)

    async def aclose(self) -> None:
        await self._client.aclose()
