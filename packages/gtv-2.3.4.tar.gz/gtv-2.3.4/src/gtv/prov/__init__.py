# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Provenance graph building for PROV-O JSON-LD encoding."""
from __future__ import annotations

from gtv.prov.graph import build_prov_graph

__all__ = ["build_prov_graph"]
