# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Build W3C PROV-O JSON-LD graphs encoding verdict provenance.

This module constructs deterministic, canonical JSON-LD documents
that link activity (verification), claim entity, evidence entities,
and verdict entity in a traceable graph.
"""
from __future__ import annotations

import json
from datetime import datetime
from typing import Any

from gtv.models import Claim, Evidence, VerdictRecord


def build_prov_graph(
    *,
    claim: Claim,
    evidence: list[Evidence],
    verdict_record: VerdictRecord,
    issuer_did: str,
    issued_at: datetime,
) -> str:
    """Return a JSON-LD string encoding the provenance of this verdict.

    Args:
        claim: The claim being verified.
        evidence: The evidence retrieved and evaluated.
        verdict_record: The verdict decision and reasoning.
        issuer_did: The DID of the issuing verification service.
        issued_at: The ISO datetime when the verdict was issued.

    Returns:
        A deterministic JSON-LD string (JSON) with sorted keys.
    """
    activity_id = f"gtv:verify-{verdict_record.verdict_id}"
    claim_id = f"gtv:claim-{claim.claim_id}"
    verdict_id = f"gtv:verdict-{verdict_record.verdict_id}"

    # Build the activity node (the verification process).
    # Typed as dict[str, Any] so we can attach list-valued prov:used below
    # without mypy complaining about widening from the initial str-valued literal.
    activity: dict[str, Any] = {
        "@id": activity_id,
        "@type": "prov:Activity",
        "prov:startedAtTime": issued_at.isoformat(),
        "prov:wasAssociatedWith": issuer_did,
    }

    # Build the claim entity node.
    claim_entity: dict[str, Any] = {
        "@id": claim_id,
        "@type": "prov:Entity",
        "prov:value": claim.text,
        "gtv:domain": claim.domain,
    }

    # Build evidence entity nodes and collect references for activity and verdict.
    evidence_entities = []
    used_refs = []  # For prov:used in activity
    derived_from_refs = []  # For prov:wasDerivedFrom in verdict

    for ev in evidence:
        ev_id = f"gtv:evidence-{ev.evidence_id}"
        used_refs.append(ev_id)
        derived_from_refs.append(ev_id)

        ev_entity = {
            "@id": ev_id,
            "@type": "prov:Entity",
            "prov:wasGeneratedBy": activity_id,
            "gtv:stance": ev.stance,
            "gtv:source": ev.source_did,
            "gtv:raw_hash": ev.raw_hash,
            "gtv:url": str(ev.url),
            "prov:generatedAtTime": ev.retrieved_at.isoformat(),
        }
        evidence_entities.append(ev_entity)

    # Add prov:used to activity (bidirectional: activity uses evidence).
    if used_refs:
        activity["prov:used"] = used_refs

    # Build the verdict entity node.
    verdict_entity = {
        "@id": verdict_id,
        "@type": "prov:Entity",
        "prov:wasGeneratedBy": activity_id,
        "gtv:decision": verdict_record.decision,
        "gtv:confidence": verdict_record.confidence,
        "gtv:rationale": verdict_record.rationale,
    }

    # Add prov:wasDerivedFrom to verdict (links each evidence).
    if derived_from_refs:
        verdict_entity["prov:wasDerivedFrom"] = derived_from_refs

    # Assemble the graph.
    graph_nodes = [activity, claim_entity, verdict_entity, *evidence_entities]

    doc = {
        "@context": {
            "prov": "https://www.w3.org/ns/prov#",
            "gtv": "https://groundtruth.example/vocab/",
        },
        "@graph": graph_nodes,
    }

    # Deterministic serialization: sort keys, compact separators.
    return json.dumps(doc, sort_keys=True, separators=(",", ":"))
