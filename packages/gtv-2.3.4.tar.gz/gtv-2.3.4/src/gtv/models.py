# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Core Pydantic models — single source of truth for every schema in gtv.

These mirror §5 and §6 of the build spec. Any change here requires an ADR
and must be accompanied by a schema bump in `spec/schemas/`.
"""
from __future__ import annotations

import uuid
from datetime import UTC, datetime
from enum import StrEnum
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, HttpUrl, field_validator


def _utcnow() -> datetime:
    return datetime.now(tz=UTC)


def _uuid7() -> str:
    # UUIDv7 is still optional in stdlib; for Phase 1 we emit v4 prefixed with
    # a timestamp component to preserve sortability without a hard dep.
    return str(uuid.uuid4())


# ---------------------------------------------------------------------------
# Enums — the only allowed verdicts / stances / source types.
# ---------------------------------------------------------------------------

class Verdict(StrEnum):
    VERIFIED = "VERIFIED"
    UNVERIFIED = "UNVERIFIED"
    CONTESTED = "CONTESTED"
    OPINION = "OPINION"
    CREATIVE = "CREATIVE"
    OUT_OF_SCOPE = "OUT_OF_SCOPE"


class Stance(StrEnum):
    SUPPORTS = "SUPPORTS"
    REFUTES = "REFUTES"
    NEUTRAL = "NEUTRAL"
    QUALIFIES = "QUALIFIES"


class SourceType(StrEnum):
    PREPRINT = "PREPRINT"
    PEER_REVIEWED = "PEER_REVIEWED"
    REFERENCE_DATA = "REFERENCE_DATA"
    GOVT_OPEN_DATA = "GOVT_OPEN_DATA"
    ENCYCLOPEDIA = "ENCYCLOPEDIA"


class TrustTier(StrEnum):
    TIER_1 = "TIER_1"
    TIER_2 = "TIER_2"
    TIER_3 = "TIER_3"


class Domain(StrEnum):
    PHYSICS = "physics"
    MATH = "math"
    CS = "cs"
    ASTRONOMY = "astronomy"
    MATERIALS = "materials"
    GENERAL = "general"


# ---------------------------------------------------------------------------
# Records
# ---------------------------------------------------------------------------

class Source(BaseModel):
    model_config = ConfigDict(frozen=True)
    source_did: str
    name: str
    type: SourceType
    trust_tier: TrustTier
    freshness_sla_s: int = Field(ge=0)
    last_audit: datetime


class Claim(BaseModel):
    model_config = ConfigDict(frozen=True)
    claim_id: str = Field(default_factory=_uuid7)
    text: str = Field(min_length=1, max_length=2000)
    domain: Domain = Domain.GENERAL
    submitted_at: datetime = Field(default_factory=_utcnow)
    submitter_did: str | None = None

    @field_validator("text")
    @classmethod
    def text_no_null_bytes(cls, v: str) -> str:
        """Reject null bytes in claim text to prevent downstream filter bypasses."""
        if "\x00" in v:
            raise ValueError(
                "Claim text contains null bytes, which are not permitted"
            )
        return v


class Evidence(BaseModel):
    model_config = ConfigDict(frozen=True)
    evidence_id: str = Field(default_factory=_uuid7)
    claim_id: str
    source_did: str
    source_version: str
    stance: Stance
    excerpt: str = Field(max_length=1200)
    url: HttpUrl
    retrieved_at: datetime
    raw_hash: str = Field(pattern=r"^[0-9a-f]{64}$")


class VerdictRecord(BaseModel):
    model_config = ConfigDict(frozen=True)
    verdict_id: str = Field(default_factory=_uuid7)
    claim_id: str
    decision: Verdict
    confidence: float = Field(ge=0.0, le=1.0)
    evidence_refs: list[str]
    rationale: str = Field(max_length=1500)


class AnchorProof(BaseModel):
    model_config = ConfigDict(frozen=True)
    rekor_inclusion_proof: str
    tsa_tsr_primary: str
    tsa_tsr_secondary: str | None = None
    # Base64 of Rekor's own canonicalized hashedrekord body bytes. When present,
    # verifiers hash this directly as the merkle leaf rather than reconstructing
    # the body client-side. Rekor is the authoritative canonicalizer; any
    # client-side reconstruction is guessing at Rekor's whitespace + key-order
    # rules. Optional for backward compat with pre-v2.3.2 envelopes.
    rekor_canonical_body_b64: str | None = None


class SupersedeReason(StrEnum):
    """Why a new envelope replaces an older one.

    AMEND: minor correction (typo, rationale tweak, evidence refresh) —
           same underlying claim, same verdict semantics.
    SUPERSEDE: a newer verdict entirely (consensus shifted, stale data
           replaced, verdict flipped) — the claim text may be unchanged
           but the verdict is now the authoritative one.
    WITHDRAW: issuer is voluntarily retracting without a replacement; a
           final no-evidence envelope may still ship for auditability.
    """

    AMEND = "AMEND"
    SUPERSEDE = "SUPERSEDE"
    WITHDRAW = "WITHDRAW"


class Envelope(BaseModel):
    """The signed, anchored response envelope returned to every MCP caller."""
    model_config = ConfigDict(frozen=True)

    envelope_id: str = Field(default_factory=_uuid7)
    verdict: Verdict
    confidence: float = Field(ge=0.0, le=1.0)
    evidence: list[Evidence]
    rationale: str = Field(default="", max_length=1500)
    issuer_did: str
    issued_at: datetime = Field(default_factory=_utcnow)
    signature: str
    rekor_uuid: str
    rekor_log_index: int = Field(ge=0)
    tsa_token: str
    prov_graph: str  # PROV-O JSON-LD serialised
    anchor_proof: AnchorProof
    # Lifecycle (W28): envelope IDs this one replaces, plus why. When both are
    # at default (empty list + None), they are stripped from the canonical
    # form so pre-W28 envelopes continue to verify unchanged.
    supersedes: list[str] = Field(default_factory=list)
    supersede_reason: SupersedeReason | None = None

    def canonical_hash(self) -> str:
        """Hash the canonical form — see anchor.canonicalize."""
        from gtv.anchor.canonicalize import envelope_canonical_sha256
        return envelope_canonical_sha256(self)


# ---------------------------------------------------------------------------
# MCP tool request / response models
# ---------------------------------------------------------------------------

class VerifyClaimRequest(BaseModel):
    claim: str = Field(min_length=1, max_length=2000)
    domain: Domain = Domain.GENERAL
    context: str | None = Field(default=None, max_length=8000)
    min_confidence: float = Field(default=0.5, ge=0.0, le=1.0)
    max_sources: int = Field(default=5, ge=1, le=20)


class RetrieveFactsRequest(BaseModel):
    query: str = Field(min_length=1, max_length=500)
    domain: Domain = Domain.GENERAL
    max_results: int = Field(default=5, ge=1, le=20)


class FactItem(BaseModel):
    model_config = ConfigDict(frozen=True)
    text: str
    verdict: Verdict
    confidence: float = Field(ge=0.0, le=1.0)
    evidence: list[Evidence]


class RetrieveFactsEnvelope(BaseModel):
    model_config = ConfigDict(frozen=True)
    envelope_id: str = Field(default_factory=_uuid7)
    facts: list[FactItem]
    issuer_did: str
    issued_at: datetime = Field(default_factory=_utcnow)
    signature: str
    rekor_uuid: str
    rekor_log_index: int = Field(ge=0)
    tsa_token: str
    anchor_proof: AnchorProof


HealthState = Literal["HEALTHY", "DEGRADED", "DOWN"]


class HealthStatus(BaseModel):
    model_config = ConfigDict(frozen=True)
    state: HealthState
    detail: str = ""
    checked_at: datetime = Field(default_factory=_utcnow)
