# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Build and verify RevocationLists with cryptographic signatures.

Signing follows the BYOK pattern: canonicalize unsigned fields (RFC 8785),
sign with Ed25519, verify public key from issuer_did.
"""
from __future__ import annotations

import base64
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING
from uuid import uuid4

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ed25519

from gtv.anchor.canonicalize import canonicalize, sha256
from gtv.did.resolve_key import parse_did_key
from gtv.sign.byok import _derive_did_key_from_public_key

if TYPE_CHECKING:
    pass

from gtv.revocation import RevocationList


def build_revocation_list(
    issuer_did: str,
    envelope_ids: list[str] | None = None,
    issuer_dids: list[str] | None = None,
    rekor_indices: list[int] | None = None,
    private_key_path: str | Path | None = None,
) -> RevocationList:
    """Build and sign a RevocationList.

    Canonicalizes the unsigned portion (list_id, issuer_did, revoked_*, issued_at),
    signs with Ed25519, and returns a signed RevocationList.

    Args:
        issuer_did: The did:key:z... of the issuer (signer)
        envelope_ids: List of envelope_ids to revoke individually (default: [])
        issuer_dids: List of issuer_dids to revoke entirely (default: [])
        rekor_indices: List of Rekor log indices to revoke (default: [])
        private_key_path: Path to Ed25519 private key in PEM format

    Returns:
        Signed RevocationList with signature and canonical_hash populated

    Raises:
        ValueError: If private_key_path is None, invalid, or not Ed25519
        FileNotFoundError: If private_key_path does not exist
    """
    if private_key_path is None:
        raise ValueError("private_key_path is required")

    envelope_ids = envelope_ids or []
    issuer_dids = issuer_dids or []
    rekor_indices = rekor_indices or []

    # Load and validate private key
    pem_path = Path(private_key_path)
    if not pem_path.exists():
        raise FileNotFoundError(f"Private key file not found: {pem_path}")

    try:
        pem_bytes = pem_path.read_bytes()
        private_key_obj = serialization.load_pem_private_key(pem_bytes, password=None)
    except Exception as e:
        raise ValueError(f"Failed to load PEM private key: {e}") from e

    if not isinstance(private_key_obj, ed25519.Ed25519PrivateKey):
        raise ValueError(
            f"Private key must be Ed25519, got {type(private_key_obj).__name__}"
        )

    # Verify issuer_did derivation matches
    public_key_obj = private_key_obj.public_key()
    raw_public_key_bytes = public_key_obj.public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    derived_did = _derive_did_key_from_public_key("Ed25519", raw_public_key_bytes)

    if derived_did != issuer_did:
        raise ValueError(
            f"Provided issuer_did does not match derived DID from private key. "
            f"Expected {derived_did}, got {issuer_did}"
        )

    # Create unsigned RevocationList with placeholder signature/hash
    now = datetime.now(tz=UTC)
    list_id = str(uuid4())

    # Build unsigned dict
    unsigned_dict = {
        "list_id": list_id,
        "issuer_did": issuer_did,
        "revoked_envelope_ids": envelope_ids,
        "revoked_issuer_dids": issuer_dids,
        "revoked_rekor_log_indices": rekor_indices,
        "issued_at": now.isoformat(),
    }

    # Canonicalize and hash
    canonical_bytes = canonicalize(unsigned_dict)
    canonical_hash = sha256(canonical_bytes)

    # Sign
    sig_bytes = private_key_obj.sign(canonical_bytes)
    sig_b64 = base64.b64encode(sig_bytes).decode("ascii")
    signature_str = f"byok-ed25519:{sig_b64}"

    # Create and return signed RevocationList
    return RevocationList(
        list_id=list_id,
        issuer_did=issuer_did,
        revoked_envelope_ids=envelope_ids,
        revoked_issuer_dids=issuer_dids,
        revoked_rekor_log_indices=rekor_indices,
        issued_at=now,
        signature=signature_str,
        canonical_hash=canonical_hash,
    )


def verify_revocation_list(rl: RevocationList) -> bool:
    """Verify a RevocationList signature.

    Recomputes the canonical hash of the unsigned portion, extracts the public
    key from issuer_did, and verifies the Ed25519 signature.

    Args:
        rl: RevocationList to verify

    Returns:
        True if signature is valid, False otherwise
    """
    try:
        # Validate issuer_did format
        if not rl.issuer_did.startswith("did:key:z"):
            return False

        # Parse issuer DID
        try:
            parsed = parse_did_key(rl.issuer_did)
        except ValueError:
            return False

        if parsed.key_type != "Ed25519":
            return False

        public_key_bytes = parsed.public_key_bytes

        # Extract signature
        if not rl.signature.startswith("byok-ed25519:"):
            return False

        try:
            sig_b64 = rl.signature[13:]  # Strip "byok-ed25519:"
            sig_bytes = base64.b64decode(sig_b64)
        except (ValueError, IndexError):
            return False

        # Recompute canonical hash
        unsigned_dict = {
            "list_id": rl.list_id,
            "issuer_did": rl.issuer_did,
            "revoked_envelope_ids": rl.revoked_envelope_ids,
            "revoked_issuer_dids": rl.revoked_issuer_dids,
            "revoked_rekor_log_indices": rl.revoked_rekor_log_indices,
            "issued_at": rl.issued_at.isoformat(),
        }
        canonical_bytes = canonicalize(unsigned_dict)
        recomputed_hash = sha256(canonical_bytes)

        # Verify hash matches
        if recomputed_hash != rl.canonical_hash:
            return False

        # Verify signature
        public_key = ed25519.Ed25519PublicKey.from_public_bytes(public_key_bytes)
        public_key.verify(sig_bytes, canonical_bytes)

        return True
    except Exception:
        return False


__all__ = [
    "build_revocation_list",
    "verify_revocation_list",
]
