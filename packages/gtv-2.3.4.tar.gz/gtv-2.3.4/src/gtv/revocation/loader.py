# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Load revocation lists from disk and environment.

Revocation lists are stored as JSON files. The loader reads all *.json files
from a directory, parses each as a RevocationList, verifies its signature,
and returns only the valid lists.
"""
from __future__ import annotations

import json
import logging
import os
from pathlib import Path

from gtv.revocation import RevocationList
from gtv.revocation.list import verify_revocation_list

logger = logging.getLogger(__name__)


def load_revocation_lists_from_dir(path: str | Path) -> list[RevocationList]:
    """Load and verify revocation lists from a directory.

    Reads all *.json files in the directory, parses each as a RevocationList,
    and verifies its signature via verify_revocation_list. Skips any list
    whose signature doesn't verify.

    Args:
        path: Directory path containing *.json revocation list files

    Returns:
        List of verified RevocationList objects
    """
    path = Path(path)
    verified_lists: list[RevocationList] = []

    if not path.is_dir():
        logger.warning(f"Revocation directory does not exist: {path}")
        return verified_lists

    json_files = sorted(path.glob("*.json"))
    if not json_files:
        logger.info(f"No revocation list files found in {path}")
        return verified_lists

    for json_file in json_files:
        try:
            with open(json_file) as f:
                data = json.load(f)
            rl = RevocationList.model_validate(data)

            # Verify signature
            if not verify_revocation_list(rl):
                logger.warning(
                    f"Revocation list {json_file} failed signature verification; skipping"
                )
                continue

            verified_lists.append(rl)
            logger.info(f"Loaded revocation list {rl.list_id} from {json_file}")

        except json.JSONDecodeError as e:
            logger.warning(f"Failed to parse JSON in {json_file}: {e}")
        except ValueError as e:
            logger.warning(f"Failed to validate RevocationList in {json_file}: {e}")
        except Exception as e:
            logger.warning(f"Error loading revocation list {json_file}: {e}")

    logger.info(f"Loaded {len(verified_lists)} verified revocation lists from {path}")
    return verified_lists


def load_revocation_lists_from_env() -> list[RevocationList]:
    """Load revocation lists from the GTV_REVOCATION_DIR environment variable.

    If GTV_REVOCATION_DIR is not set, returns an empty list.

    Returns:
        List of verified RevocationList objects
    """
    rev_dir = os.getenv("GTV_REVOCATION_DIR")
    if not rev_dir:
        return []

    return load_revocation_lists_from_dir(rev_dir)


__all__ = [
    "load_revocation_lists_from_dir",
    "load_revocation_lists_from_env",
]
