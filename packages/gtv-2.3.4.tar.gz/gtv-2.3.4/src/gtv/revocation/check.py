# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Check envelopes against revocation lists.

An envelope is revoked if ANY verified list revokes it by:
- envelope_id (direct revocation)
- issuer_did (entire issuer compromise)
- rekor_log_index (specific Rekor entry)
"""
from __future__ import annotations

from dataclasses import dataclass

from gtv.models import Envelope
from gtv.revocation import RevocationList
from gtv.revocation.list import verify_revocation_list


@dataclass(frozen=True)
class RevocationStatus:
    """Status of an envelope against revocation lists.

    Attributes:
        revoked: Whether the envelope is revoked by any verified list
        reason: Human-readable reason for revocation (None if not revoked)
        revoked_by_list_id: ID of the list that revoked it (None if not revoked)
    """

    revoked: bool
    reason: str | None = None
    revoked_by_list_id: str | None = None


def is_revoked(
    envelope: Envelope, revocation_lists: list[RevocationList]
) -> RevocationStatus:
    """Check if an envelope is revoked by any list.

    Only considers lists with valid signatures. An envelope is revoked if:
    1. Its envelope_id is in revoked_envelope_ids, OR
    2. Its issuer_did is in revoked_issuer_dids, OR
    3. Its rekor_log_index is in revoked_rekor_log_indices

    Args:
        envelope: Envelope to check
        revocation_lists: List of RevocationLists to check against

    Returns:
        RevocationStatus indicating revocation status
    """
    for rl in revocation_lists:
        # Verify signature first
        if not verify_revocation_list(rl):
            # Skip lists with invalid signatures
            continue

        # Check by envelope_id
        if envelope.envelope_id in rl.revoked_envelope_ids:
            return RevocationStatus(
                revoked=True,
                reason="Envelope revoked by envelope_id",
                revoked_by_list_id=rl.list_id,
            )

        # Check by issuer_did
        if envelope.issuer_did in rl.revoked_issuer_dids:
            return RevocationStatus(
                revoked=True,
                reason="Issuer revoked due to compromise",
                revoked_by_list_id=rl.list_id,
            )

        # Check by rekor_log_index
        if envelope.rekor_log_index in rl.revoked_rekor_log_indices:
            return RevocationStatus(
                revoked=True,
                reason="Envelope revoked by Rekor log index",
                revoked_by_list_id=rl.list_id,
            )

    return RevocationStatus(revoked=False)


__all__ = [
    "RevocationStatus",
    "is_revoked",
]
