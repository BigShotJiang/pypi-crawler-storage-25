# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Revocation system for GTV — invalidate envelopes and issuer keys post-facto.

A RevocationList is a cryptographically signed document that lists:
- revoked_envelope_ids: Individual envelopes to reject
- revoked_issuer_dids: All envelopes from a compromised issuer
- revoked_rekor_log_indices: Envelopes at specific Rekor indices

Each list is signed by its issuer, verified via their did:key DID, and publicly
verifiable. Clients check envelopes against one or more lists.
"""
from __future__ import annotations

from datetime import UTC, datetime
from uuid import uuid4

from pydantic import BaseModel, ConfigDict, Field

from gtv.anchor.canonicalize import canonicalize, sha256


class RevocationList(BaseModel):
    """A cryptographically signed revocation list.

    Frozen (immutable) to ensure signature consistency. Signature is computed
    over the canonical form of the unsigned fields.
    """

    model_config = ConfigDict(frozen=True)

    list_id: str = Field(default_factory=lambda: str(uuid4()))
    issuer_did: str  # did:key:z..., the signer of this list
    revoked_envelope_ids: list[str] = Field(default_factory=list)
    revoked_issuer_dids: list[str] = Field(default_factory=list)
    revoked_rekor_log_indices: list[int] = Field(default_factory=list)
    issued_at: datetime = Field(default_factory=lambda: datetime.now(tz=UTC))
    signature: str  # "byok-ed25519:<base64>"
    canonical_hash: str  # SHA256 hex of canonical unsigned form


def _get_unsigned_dict(rl: RevocationList) -> dict[str, object]:
    """Extract the unsigned portion of a RevocationList for hashing/signing.

    Excludes: signature, canonical_hash.
    """
    data = rl.model_dump(mode="json")
    data.pop("signature", None)
    data.pop("canonical_hash", None)
    return data


def compute_revocation_list_hash(rl: RevocationList) -> str:
    """Compute the SHA256 hash of the canonical form of an unsigned RevocationList."""
    unsigned = _get_unsigned_dict(rl)
    canonical_bytes = canonicalize(unsigned)
    return sha256(canonical_bytes)


__all__ = [
    "RevocationList",
    "compute_revocation_list_hash",
]
