# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Pilot-facing telemetry: structured logging and Prometheus metrics.

Exports `install_telemetry(app)` to configure logging and add middleware to a FastAPI app.
"""
from __future__ import annotations

from typing import TYPE_CHECKING

from gtv.telemetry.logs import configure_logging
from gtv.telemetry.metrics import record_verdict  # noqa: F401
from gtv.telemetry.middleware import TelemetryMiddleware

if TYPE_CHECKING:
    from fastapi import FastAPI


def install_telemetry(app: FastAPI) -> None:
    """Install telemetry: structured logging and request/verdict metrics.

    Idempotent. Configures structlog, adds TelemetryMiddleware.

    Args:
        app: FastAPI application instance.
    """
    configure_logging()
    app.add_middleware(TelemetryMiddleware)
