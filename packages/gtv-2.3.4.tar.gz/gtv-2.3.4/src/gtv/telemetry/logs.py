# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Structured logging with structlog.

ISO 8601 UTC timestamps, JSON renderer, log level from GTV_LOG_LEVEL env var.
Idempotent configuration: safe to call multiple times.
"""
from __future__ import annotations

import logging
import os
import sys

import structlog

__all__ = ["configure_logging", "get_logger"]


_logging_configured = False


def configure_logging() -> None:
    """Configure structlog with JSON renderer, ISO timestamps, UTC.

    Reads GTV_LOG_LEVEL env var (default: INFO).
    Idempotent: safe to call multiple times.
    """
    global _logging_configured

    if _logging_configured:
        return

    _logging_configured = True
    log_level = os.getenv("GTV_LOG_LEVEL", "INFO").upper()

    # Route logs to stderr so stdout is free for JSON-RPC (MCP stdio transport)
    # and CLI tool output. stdout is for app data; stderr is for diagnostics.
    # GTV_LOG_STREAM=stdout is available for callers that need the old
    # behavior, but it must never be set when gtv-mcp is running.
    stream_name = os.getenv("GTV_LOG_STREAM", "stderr").lower()
    stream = sys.stdout if stream_name == "stdout" else sys.stderr

    # Configure standard library logging
    logging.basicConfig(
        format="%(message)s",
        stream=stream,
        level=getattr(logging, log_level),
    )

    # Configure structlog
    structlog.configure(
        processors=[
            structlog.stdlib.filter_by_level,
            structlog.stdlib.add_logger_name,
            structlog.stdlib.add_log_level,
            structlog.stdlib.PositionalArgumentsFormatter(),
            structlog.processors.TimeStamper(fmt="iso", utc=True),
            structlog.processors.StackInfoRenderer(),
            structlog.processors.format_exc_info,
            structlog.processors.UnicodeDecoder(),
            structlog.processors.JSONRenderer(),
        ],
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
        cache_logger_on_first_use=True,
    )


def get_logger(name: str) -> structlog.BoundLogger:
    """Get a bound structlog logger.

    Args:
        name: Logger name (usually __name__).

    Returns:
        Bound structlog logger instance.
    """
    return structlog.get_logger(name)  # type: ignore[no-any-return]
