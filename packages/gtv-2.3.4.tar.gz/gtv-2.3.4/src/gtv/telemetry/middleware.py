# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""TelemetryMiddleware for per-request structured logging and metrics.

Logs every request as {event: "request", method, path, status, duration_ms, api_key_id}.
Records metrics: gtv_requests_total (by endpoint and status),
gtv_request_duration_seconds (histogram), gtv_errors_total (on 5xx or exception).
"""
from __future__ import annotations

import time
from collections.abc import Awaitable, Callable
from typing import Any

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response

from gtv.telemetry.logs import get_logger
from gtv.telemetry.metrics import (
    gtv_errors_total,
    gtv_request_duration_seconds,
    gtv_requests_total,
)

logger = get_logger(__name__)

__all__ = ["TelemetryMiddleware"]


class TelemetryMiddleware(BaseHTTPMiddleware):
    """Record per-request telemetry: logs, request counters, latency histogram.

    On every request:
    - Logs structured JSON with method, path, status, duration_ms, api_key_id (if present).
    - Increments gtv_requests_total[endpoint, status].
    - Observes duration in gtv_request_duration_seconds[endpoint].
    - On 5xx or exception: increments gtv_errors_total[endpoint, error_type].
    """

    async def dispatch(
        self, request: Request, call_next: Callable[[Request], Awaitable[Response]]
    ) -> Response:
        """Process request and record telemetry.

        Args:
            request: Incoming request.
            call_next: Next middleware or endpoint handler.

        Returns:
            Response from handler.
        """
        start_time = time.perf_counter()
        endpoint = request.url.path
        method = request.method

        # Extract api_key_id from scope (set by auth middleware)
        api_key_id = None
        if "api_key_id" in request.scope:
            api_key_id = request.scope["api_key_id"]

        status = 500
        error_type = None

        try:
            response = await call_next(request)
            status = response.status_code

            # Record metrics
            gtv_requests_total.labels(endpoint=endpoint, status=status).inc()

            if status >= 500:
                error_type = "server_error"
                gtv_errors_total.labels(endpoint=endpoint, error_type=error_type).inc()

            return response

        except Exception as exc:
            # On exception, treat as 500
            error_type = type(exc).__name__
            gtv_requests_total.labels(endpoint=endpoint, status=500).inc()
            gtv_errors_total.labels(endpoint=endpoint, error_type=error_type).inc()
            raise

        finally:
            # Record duration
            duration_ms = (time.perf_counter() - start_time) * 1000
            gtv_request_duration_seconds.labels(endpoint=endpoint).observe(
                duration_ms / 1000
            )

            # Log structured event
            log_context: dict[str, Any] = {
                "event": "request",
                "method": method,
                "path": endpoint,
                "status": status,
                "duration_ms": round(duration_ms, 2),
            }
            if api_key_id:
                log_context["api_key_id"] = api_key_id

            logger.info(**log_context)
