# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Prometheus metrics for pilot-facing telemetry.

Module-level singletons: gtv_requests_total, gtv_verdicts_total, gtv_errors_total, gtv_request_duration_seconds.
Register once per process; safe to import multiple times.
"""
from __future__ import annotations

from typing import cast

from prometheus_client import REGISTRY, Counter, Histogram

__all__ = [
    "gtv_errors_total",
    "gtv_request_duration_seconds",
    "gtv_requests_total",
    "gtv_verdicts_total",
    "record_verdict",
]

# Request counters
try:
    gtv_requests_total: Counter = Counter(
        "gtv_requests_total",
        "Total requests by endpoint and status",
        ["endpoint", "status"],
        registry=REGISTRY,
    )
except ValueError:
    # Already registered (e.g., in test suite); retrieve existing
    gtv_requests_total = cast(
        Counter, REGISTRY._names_to_collectors["gtv_requests_total"]
    )

try:
    gtv_errors_total: Counter = Counter(
        "gtv_errors_total",
        "Total errors by endpoint and error type",
        ["endpoint", "error_type"],
        registry=REGISTRY,
    )
except ValueError:
    gtv_errors_total = cast(
        Counter, REGISTRY._names_to_collectors["gtv_errors_total"]
    )

try:
    gtv_verdicts_total: Counter = Counter(
        "gtv_verdicts_by_tier_total",
        "Total verdicts issued by verdict and tier",
        ["verdict", "tier"],
        registry=REGISTRY,
    )
except ValueError:
    gtv_verdicts_total = cast(
        Counter, REGISTRY._names_to_collectors["gtv_verdicts_by_tier_total"]
    )

# Request latency histogram with sensible buckets
try:
    gtv_request_duration_seconds: Histogram = Histogram(
        "gtv_request_duration_seconds",
        "Request duration in seconds",
        ["endpoint"],
        buckets=(0.01, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5, 10, 30),
        registry=REGISTRY,
    )
except ValueError:
    gtv_request_duration_seconds = cast(
        Histogram, REGISTRY._names_to_collectors["gtv_request_duration_seconds"]
    )


def record_verdict(verdict: str, tier: str) -> None:
    """Record a verdict issued.

    Args:
        verdict: Verdict value (e.g., "SUPPORTED", "UNSUPPORTED", "OPINION").
        tier: Tier of the verdict source (e.g., "TIER_1", "TIER_2").
    """
    gtv_verdicts_total.labels(verdict=verdict, tier=tier).inc()
