# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Sign and verify webhook payloads using BYOK Ed25519.

Webhooks that POST verdict-change notifications are cryptographically signed
so the receiver can trust the payload came from the expected verifier.

Input: webhook payload dict + path to Ed25519 private key PEM.
Output: dict with {payload, signature, issuer_did}.

Signature format: "byok-ed25519:<base64>" (matches BYOK convention).
Issuer DID: "did:key:z..." (derived from Ed25519 public key).

Required env var: GTV_WEBHOOK_SIGNING_KEY (path to Ed25519 private key PEM file).
"""
from __future__ import annotations

import base64
from pathlib import Path
from typing import Any

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ed25519

from gtv.anchor.canonicalize import canonicalize
from gtv.sign.byok import _derive_did_key_from_public_key


def sign_webhook_payload(
    payload: dict[str, Any], private_key_pem_path: str | Path
) -> dict[str, Any]:
    """Sign a webhook payload with an Ed25519 private key.

    Canonicalizes the payload, signs it, and returns a dict with:
    - payload: the original payload (for receiver reference)
    - signature: "byok-ed25519:<base64>" format
    - issuer_did: "did:key:z..." derived from the public key

    Args:
        payload: Arbitrary dict to sign (webhook payload)
        private_key_pem_path: Path to Ed25519 private key in PEM format

    Returns:
        dict with keys {payload, signature, issuer_did}

    Raises:
        ValueError: If PEM is invalid or key is not Ed25519
        FileNotFoundError: If PEM file does not exist
    """
    # Load PEM file
    pem_path = Path(private_key_pem_path)
    if not pem_path.exists():
        raise FileNotFoundError(f"Private key file not found: {pem_path}")

    pem_bytes = pem_path.read_bytes()

    # Parse private key
    try:
        private_key_obj = serialization.load_pem_private_key(pem_bytes, password=None)
    except Exception as e:
        raise ValueError(f"Failed to load PEM private key: {e}") from e

    if not isinstance(private_key_obj, ed25519.Ed25519PrivateKey):
        raise ValueError(
            f"Private key must be Ed25519, got {type(private_key_obj).__name__}"
        )

    # Extract public key and derive DID
    public_key_ed = private_key_obj.public_key()
    raw_public_key_bytes = public_key_ed.public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    issuer_did = _derive_did_key_from_public_key("Ed25519", raw_public_key_bytes)

    # Canonicalize payload and sign
    canonical_bytes = canonicalize(payload)
    sig_bytes = private_key_obj.sign(canonical_bytes)

    # Encode signature in BYOK format
    sig_b64 = base64.b64encode(sig_bytes).decode("ascii")
    signature_str = f"byok-ed25519:{sig_b64}"

    return {
        "payload": payload,
        "signature": signature_str,
        "issuer_did": issuer_did,
    }


def verify_webhook_payload(signed: dict[str, Any]) -> dict[str, Any]:
    """Verify a signed webhook payload.

    Extracts the public key from issuer_did, then verifies the signature
    against the canonicalized payload.

    Args:
        signed: Dict with keys {payload, signature, issuer_did}

    Returns:
        The original payload if signature is valid

    Raises:
        ValueError: If signature format is invalid, DID is malformed,
                   or verification fails
        KeyError: If required keys are missing from signed dict
    """
    payload = signed["payload"]
    signature_str = signed["signature"]
    issuer_did = signed["issuer_did"]

    # Parse issuer_did
    if not issuer_did.startswith("did:key:z"):
        raise ValueError(
            f"issuer_did must be a did:key (did:key:z...), got: {issuer_did}"
        )

    # Import here to avoid circular dependency
    from gtv.did.resolve_key import parse_did_key

    try:
        parsed = parse_did_key(issuer_did)
    except ValueError as e:
        raise ValueError(f"Failed to parse issuer_did: {e}") from e

    key_type = parsed.key_type
    public_key_bytes = parsed.public_key_bytes

    if key_type != "Ed25519":
        raise ValueError(
            f"Expected Ed25519 key in issuer_did, got {key_type}"
        )

    # Parse signature format: byok-ed25519:<base64>
    if not signature_str.startswith("byok-ed25519:"):
        raise ValueError(
            f"Expected byok-ed25519:... signature format, got: {signature_str[:20]}..."
        )

    try:
        sig_b64 = signature_str[13:]  # Strip "byok-ed25519:"
        sig_bytes = base64.b64decode(sig_b64)
    except (ValueError, IndexError) as e:
        raise ValueError(f"Invalid signature format: {e}") from e

    # Verify signature
    try:
        public_key = ed25519.Ed25519PublicKey.from_public_bytes(public_key_bytes)
        public_key.verify(sig_bytes, canonicalize(payload))
    except Exception as e:
        raise ValueError(f"Ed25519 signature verification failed: {e}") from e

    if not isinstance(payload, dict):
        raise ValueError(f"Signed payload must be a dict, got {type(payload).__name__}")
    return payload
