# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""SQLite-backed subscription store for persistent claim tracking.

Simple schema: one subscriptions table.
No ORM, no migrations framework, just sqlite3 + hand-rolled SQL.
"""
from __future__ import annotations

import sqlite3
import threading
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from gtv.subscribe.engine import Subscription


class SubscriptionStore:
    """SQLite-backed store for subscriptions.

    Thread-safe via a lock. Connection is kept as an instance attribute.
    Schema: subscriptions(id, claim, webhook_url, interval_s, last_verdict, last_checked_at).
    """

    def __init__(self, path: str | Path = "~/.gtv/subscriptions.db") -> None:
        """Initialize store and create table if not exists."""
        self.path = Path(path).expanduser()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._conn = sqlite3.connect(str(self.path), check_same_thread=False)
        self._conn.isolation_level = None  # autocommit mode
        self._init_schema()

    def _init_schema(self) -> None:
        """Create subscriptions table if not exists."""
        self._conn.execute(
            """
            CREATE TABLE IF NOT EXISTS subscriptions (
                id TEXT PRIMARY KEY,
                claim TEXT NOT NULL,
                webhook_url TEXT NOT NULL,
                interval_s INTEGER NOT NULL,
                last_verdict TEXT,
                last_checked_at TEXT
            )
            """
        )

    def add(self, sub: Subscription) -> None:
        """Add or upsert a subscription."""
        with self._lock:
            self._conn.execute(
                """
                INSERT OR REPLACE INTO subscriptions
                (id, claim, webhook_url, interval_s, last_verdict, last_checked_at)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    sub.id,
                    sub.claim,
                    sub.webhook_url,
                    sub.interval_s,
                    sub.last_verdict,
                    sub.last_checked_at.isoformat() if sub.last_checked_at else None,
                ),
            )

    def remove(self, sub_id: str) -> bool:
        """Remove a subscription by id. Return True if found."""
        with self._lock:
            cursor = self._conn.execute("DELETE FROM subscriptions WHERE id = ?", (sub_id,))
            return cursor.rowcount > 0

    def get(self, sub_id: str) -> Subscription | None:
        """Get a subscription by id."""
        with self._lock:
            cursor = self._conn.execute(
                "SELECT id, claim, webhook_url, interval_s, last_verdict, last_checked_at FROM subscriptions WHERE id = ?",
                (sub_id,),
            )
            row = cursor.fetchone()
            if row:
                return self._row_to_subscription(row)
            return None

    def list_all(self) -> list[Subscription]:
        """Return all subscriptions."""
        with self._lock:
            cursor = self._conn.execute(
                "SELECT id, claim, webhook_url, interval_s, last_verdict, last_checked_at FROM subscriptions ORDER BY id"
            )
            return [self._row_to_subscription(row) for row in cursor.fetchall()]

    def update_verdict(self, sub_id: str, verdict: str, checked_at_iso: str) -> bool:
        """Update last_verdict and last_checked_at for a subscription. Return True if found."""
        with self._lock:
            cursor = self._conn.execute(
                "UPDATE subscriptions SET last_verdict = ?, last_checked_at = ? WHERE id = ?",
                (verdict, checked_at_iso, sub_id),
            )
            return cursor.rowcount > 0

    @staticmethod
    def _row_to_subscription(row: tuple[object, ...]) -> Subscription:
        """Convert a DB row to a Subscription object."""
        from datetime import datetime

        from gtv.subscribe.engine import Subscription

        id_raw, claim_raw, webhook_url_raw, interval_s_raw, last_verdict_raw, last_checked_at_iso_raw = row

        # SQLite typing: cursor returns object; constrain to the declared column types.
        assert isinstance(id_raw, str)
        assert isinstance(claim_raw, str)
        assert isinstance(webhook_url_raw, str)
        assert isinstance(interval_s_raw, int)
        assert last_verdict_raw is None or isinstance(last_verdict_raw, str)
        assert last_checked_at_iso_raw is None or isinstance(last_checked_at_iso_raw, str)

        last_checked_at = (
            datetime.fromisoformat(last_checked_at_iso_raw)
            if last_checked_at_iso_raw
            else None
        )
        return Subscription(
            id=id_raw,
            claim=claim_raw,
            webhook_url=webhook_url_raw,
            interval_s=interval_s_raw,
            last_verdict=last_verdict_raw,
            last_checked_at=last_checked_at,
        )

    def close(self) -> None:
        """Close the database connection."""
        with self._lock:
            self._conn.close()
