# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Webhook-based subscription engine for periodic claim re-verification.

Polling daemon: subscribes to claims, periodically re-verifies, fires webhooks on verdict change.
Backed by SQLite store for durable persistence. Restart-safe: reloads state from DB on init.
"""
from __future__ import annotations

import asyncio
import logging
import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path

import httpx

from gtv.mcp.server import _verify_one
from gtv.models import Claim
from gtv.tenant import default_tenant

logger = logging.getLogger(__name__)


@dataclass
class Subscription:
    """A claim subscription with polling and webhook callback."""

    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    claim: str = ""
    webhook_url: str = ""
    interval_s: int = 3600
    last_verdict: str | None = None
    last_checked_at: datetime | None = None


class SubscriptionEngine:
    """SQLite-backed polling engine for claim subscriptions.

    Manages subscriptions, runs periodic verifications, fires webhooks on verdict change.
    """

    def __init__(self, store_path: str | Path | None = None) -> None:
        """Initialize subscription engine with optional store path.

        Args:
            store_path: Path to SQLite database (default ~/.gtv/subscriptions.db).
                       If None, uses the default.
        """
        from gtv.subscribe.store import SubscriptionStore

        if store_path is None:
            store_path = "~/.gtv/subscriptions.db"
        self._store = SubscriptionStore(store_path)

    def add(self, claim: str, webhook_url: str, interval_s: int = 3600) -> Subscription:
        """Add a new subscription and return it."""
        sub = Subscription(
            id=str(uuid.uuid4()),
            claim=claim,
            webhook_url=webhook_url,
            interval_s=interval_s,
        )
        self._store.add(sub)
        return sub

    def remove(self, sub_id: str) -> bool:
        """Remove a subscription by id. Return True if found."""
        return self._store.remove(sub_id)

    def list_all(self) -> list[Subscription]:
        """Return all subscriptions."""
        return self._store.list_all()

    async def run_forever(self) -> None:
        """Main loop: periodically check each subscription.

        Runs all checks concurrently with asyncio.gather.
        Logs errors but never crashes.
        """
        tasks = []
        for sub in self._store.list_all():
            task = asyncio.create_task(self._periodic_check(sub))
            tasks.append(task)

        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)

    async def _periodic_check(self, sub: Subscription) -> None:
        """Periodically check one subscription.

        Check immediately on startup, then every interval_s seconds.
        """
        while True:
            try:
                await self._check_one(sub)
            except Exception as e:
                logger.exception(f"Unexpected error checking subscription {sub.id}: {e}")

            await asyncio.sleep(sub.interval_s)

    async def _check_one(self, sub: Subscription) -> None:
        """Run verification, fire webhook if verdict changed.

        Initial run always fires webhook (last_verdict is None).
        """
        try:
            claim_obj = Claim(text=sub.claim)
            # The subscription daemon runs outside an HTTP request, so there's
            # no tenant in request.state — fall through to the server-default
            # issuer DID. A future iteration could persist the creator's
            # tenant on the subscription row if per-tenant signing is needed.
            envelope = await _verify_one(
                claim_obj,
                max_sources=5,
                issuer_did=default_tenant().issuer_did,
            )
            new_verdict = str(envelope.verdict)

            # Fire webhook if verdict changed or on first run
            if sub.last_verdict is None or sub.last_verdict != new_verdict:
                payload = {
                    "subscription_id": sub.id,
                    "claim": sub.claim,
                    "old_verdict": sub.last_verdict,
                    "new_verdict": new_verdict,
                    "confidence": envelope.confidence,
                    "timestamp": datetime.now(UTC).isoformat(),
                }
                try:
                    await self._post_webhook(sub.webhook_url, payload)
                except Exception as e:
                    logger.error(f"Failed to post webhook for sub {sub.id}: {e}")
                # Update verdict regardless of webhook success
                sub.last_verdict = new_verdict

            sub.last_checked_at = datetime.now(UTC)
            # Persist changes to store
            self._store.add(sub)
        except Exception as e:
            logger.exception(f"Error verifying claim for sub {sub.id}: {e}")

    async def _post_webhook(self, url: str, payload: dict[str, str | float | None]) -> None:
        """POST webhook to url with payload. Log failure, don't crash.

        If GTV_WEBHOOK_SIGNING_KEY is set, the payload is signed with Ed25519
        (BYOK path) and the receiver gets {"payload": ..., "signature": ...,
        "issuer_did": ...}. Otherwise, the raw payload is posted.
        """
        import os

        body: dict[str, object] = dict(payload)
        key_path = os.environ.get("GTV_WEBHOOK_SIGNING_KEY")
        if key_path:
            try:
                from gtv.subscribe.webhook_signer import sign_webhook_payload

                body = sign_webhook_payload(dict(payload), key_path)
            except Exception as e:
                logger.error(f"Failed to sign webhook payload: {e}; sending unsigned")

        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                resp = await client.post(url, json=body)
                resp.raise_for_status()
                logger.debug(f"Webhook posted to {url}: {resp.status_code}")
        except Exception as e:
            logger.error(f"Webhook POST to {url} failed: {e}")
