# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""HTTP webhook dispatcher for verdict change subscriptions.

Manages webhook subscriptions with domain and status filtering, HMAC-SHA256 signing,
exponential backoff retry logic, and concurrent fan-out delivery.
"""
from __future__ import annotations

import asyncio
import hashlib
import hmac
import json
import logging
import time
from dataclasses import dataclass
from typing import Any

import httpx

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class WebhookSubscription:
    """A webhook subscription with filtering and signing key."""

    subscription_id: str
    url: str
    domains: list[str] | None  # None = all domains
    status_filter: list[str] | None  # None = all statuses; e.g. ["REFUTED"]
    secret: bytes  # HMAC-SHA256 signing key


@dataclass(frozen=True)
class DeliveryResult:
    """Result of attempting delivery to a webhook endpoint."""

    subscription_id: str
    url: str
    status_code: int | None
    attempts: int
    error: str | None


class WebhookDispatcher:
    """Manages webhook subscriptions and dispatches verdict payloads."""

    def __init__(
        self, client: httpx.AsyncClient | None = None, timeout: float = 5.0, max_retries: int = 3
    ) -> None:
        """Initialize the webhook dispatcher.

        Args:
            client: Optional httpx.AsyncClient to reuse; if None, one will be created per dispatch.
            timeout: HTTP request timeout in seconds (default 5.0).
            max_retries: Maximum number of retry attempts for 5xx/network errors (default 3).
        """
        self._subscriptions: dict[str, WebhookSubscription] = {}
        self._client = client
        self._timeout = timeout
        self._max_retries = max_retries

    async def register(self, sub: WebhookSubscription) -> None:
        """Register a webhook subscription.

        Args:
            sub: WebhookSubscription to register.
        """
        self._subscriptions[sub.subscription_id] = sub

    async def unregister(self, subscription_id: str) -> None:
        """Unregister a webhook subscription.

        Args:
            subscription_id: ID of the subscription to remove.
        """
        self._subscriptions.pop(subscription_id, None)

    async def dispatch(self, verdict_payload: dict[str, Any]) -> list[DeliveryResult]:
        """Fan out a verdict payload to all matching subscriptions.

        Filters subscriptions by domain and status, then posts to each matching webhook.
        Uses concurrent delivery with asyncio.gather.

        Args:
            verdict_payload: Dictionary with keys like 'domain', 'status', etc.

        Returns:
            List of DeliveryResult, one per subscription (whether success or failure).
        """
        # Filter matching subscriptions
        matching = self._filter_matching_subscriptions(verdict_payload)

        # Fan out delivery concurrently
        tasks = [self._deliver_to_subscription(sub, verdict_payload) for sub in matching]
        results = await asyncio.gather(*tasks, return_exceptions=False)
        return results

    def _filter_matching_subscriptions(
        self, verdict_payload: dict[str, Any]
    ) -> list[WebhookSubscription]:
        """Filter subscriptions that match the verdict payload.

        Args:
            verdict_payload: Verdict dict with 'domain' and 'status' keys.

        Returns:
            List of matching subscriptions.
        """
        payload_domain = verdict_payload.get("domain")
        payload_status = verdict_payload.get("status")

        matching = []
        for sub in self._subscriptions.values():
            # Check domain filter
            if sub.domains is not None and payload_domain not in sub.domains:
                continue

            # Check status filter
            if sub.status_filter is not None and payload_status not in sub.status_filter:
                continue

            matching.append(sub)

        return matching

    async def _deliver_to_subscription(
        self, sub: WebhookSubscription, verdict_payload: dict[str, Any]
    ) -> DeliveryResult:
        """Attempt to deliver a verdict to a subscription with retries.

        Uses exponential backoff: 0.5s, 1s, 2s between attempts.
        4xx responses do not retry (terminal failures).
        5xx and network errors retry up to max_retries.

        Args:
            sub: WebhookSubscription to deliver to.
            verdict_payload: Verdict payload to send.

        Returns:
            DeliveryResult with status, attempts, and error (if any).
        """
        body_bytes = json.dumps(verdict_payload).encode("utf-8")
        timestamp = str(int(time.time()))

        # Compute HMAC-SHA256 signature
        signature = hmac.new(sub.secret, body_bytes, hashlib.sha256).hexdigest()

        headers = {
            "X-GTV-Signature": f"sha256={signature}",
            "X-GTV-Timestamp": timestamp,
            "Content-Type": "application/json",
        }

        attempt = 0
        last_error = None
        last_status_code = None
        backoff_delays = [0.5, 1.0, 2.0]

        while attempt <= self._max_retries:
            attempt += 1
            try:
                client = self._client or httpx.AsyncClient(timeout=self._timeout)
                try:
                    resp = await client.post(sub.url, content=body_bytes, headers=headers)
                    last_status_code = resp.status_code

                    if resp.status_code < 400:
                        # Success
                        return DeliveryResult(
                            subscription_id=sub.subscription_id,
                            url=sub.url,
                            status_code=resp.status_code,
                            attempts=attempt,
                            error=None,
                        )
                    elif 400 <= resp.status_code < 500:
                        # 4xx: terminal failure, don't retry
                        return DeliveryResult(
                            subscription_id=sub.subscription_id,
                            url=sub.url,
                            status_code=resp.status_code,
                            attempts=attempt,
                            error=f"HTTP {resp.status_code}",
                        )
                    else:
                        # 5xx: retry
                        last_error = f"HTTP {resp.status_code}"
                finally:
                    if self._client is None:
                        await client.aclose()

            except (httpx.RequestError, httpx.HTTPError, TimeoutError) as e:
                last_error = str(e)
                # Retry on network/timeout errors

            # Check if we should retry
            if attempt <= self._max_retries:
                if attempt < len(backoff_delays):
                    delay = backoff_delays[attempt - 1]
                else:
                    delay = backoff_delays[-1]
                await asyncio.sleep(delay)

        # All retries exhausted
        return DeliveryResult(
            subscription_id=sub.subscription_id,
            url=sub.url,
            status_code=last_status_code,
            attempts=attempt,
            error=last_error or "Unknown error",
        )

    async def close(self) -> None:
        """Close the dispatcher and any managed client."""
        if self._client is not None:
            await self._client.aclose()
