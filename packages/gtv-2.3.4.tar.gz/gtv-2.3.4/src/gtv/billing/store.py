# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""SQLite-backed daily usage aggregator.

See ``gtv.billing.__init__`` for the design rationale. This module
holds the pure storage layer; the request-side hook lives in
``gtv.mcp.server`` and is implemented as a single ``record_usage()``
call per billable handler.

Public surface
--------------
* :class:`UsageRow` — one row in the daily aggregate table.
* :class:`UsageStore` — the SQLite wrapper. UPSERTs counts and
  exposes a query API for reports.
* :func:`make_store_from_env` — factory used by the server. Reads
  ``GTV_BILLING_DB`` (path on disk) and falls back to ``:memory:``
  when unset so opt-out is the default.
* :func:`record_usage` — convenience that hits the process-default
  store. Server handlers call this after authenticating the request.
* :func:`reset_default_store` — test hook to drop the cached store.
"""

from __future__ import annotations

import os
import sqlite3
import threading
from dataclasses import dataclass
from datetime import UTC, date, datetime


@dataclass(frozen=True)
class UsageRow:
    """One row in the daily aggregate table."""

    tenant_id: str
    issuer_did: str
    tool: str
    day: str  # YYYY-MM-DD UTC
    count: int


_SCHEMA = """
CREATE TABLE IF NOT EXISTS usage_daily (
    tenant_id   TEXT NOT NULL,
    issuer_did  TEXT NOT NULL,
    tool        TEXT NOT NULL,
    day         TEXT NOT NULL,
    count       INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (tenant_id, issuer_did, tool, day)
);
CREATE INDEX IF NOT EXISTS idx_usage_tenant_day
    ON usage_daily(tenant_id, day);
"""


class UsageStore:
    """Thread-safe daily usage aggregator.

    Single-connection design: SQLite serialises writes per connection.
    A module-level lock protects concurrent writers since the FastAPI
    handler may be called from multiple worker threads under uvicorn.
    """

    def __init__(self, db_path: str) -> None:
        self._db_path = db_path
        # check_same_thread=False because async handlers may execute on
        # different threads via the worker pool. The Lock below
        # serialises writes — SQLite itself is happy with multi-thread
        # access as long as one writer is active at a time.
        self._conn = sqlite3.connect(db_path, check_same_thread=False)
        self._conn.executescript(_SCHEMA)
        self._conn.commit()
        self._lock = threading.Lock()

    @property
    def db_path(self) -> str:
        return self._db_path

    def record(
        self,
        *,
        tenant_id: str,
        issuer_did: str,
        tool: str,
        when: datetime | None = None,
        count: int = 1,
    ) -> None:
        """Increment the (tenant, issuer, tool, day) bucket by ``count``."""
        if count <= 0:
            return
        when = when or datetime.now(tz=UTC)
        day = when.astimezone(UTC).date().isoformat()
        with self._lock:
            self._conn.execute(
                """
                INSERT INTO usage_daily
                    (tenant_id, issuer_did, tool, day, count)
                VALUES (?, ?, ?, ?, ?)
                ON CONFLICT(tenant_id, issuer_did, tool, day) DO UPDATE
                    SET count = count + excluded.count
                """,
                (tenant_id, issuer_did, tool, day, count),
            )
            self._conn.commit()

    def query(
        self,
        *,
        tenant_id: str | None = None,
        issuer_did: str | None = None,
        tool: str | None = None,
        since: date | None = None,
        until: date | None = None,
    ) -> list[UsageRow]:
        """Return aggregate rows matching the given filters.

        Filters compose with AND. ``since``/``until`` are inclusive.
        Order: most recent day first, then tenant_id, then tool — the
        same order the CLI prints.
        """
        clauses: list[str] = []
        params: list[object] = []
        if tenant_id is not None:
            clauses.append("tenant_id = ?")
            params.append(tenant_id)
        if issuer_did is not None:
            clauses.append("issuer_did = ?")
            params.append(issuer_did)
        if tool is not None:
            clauses.append("tool = ?")
            params.append(tool)
        if since is not None:
            clauses.append("day >= ?")
            params.append(since.isoformat())
        if until is not None:
            clauses.append("day <= ?")
            params.append(until.isoformat())
        where = (" WHERE " + " AND ".join(clauses)) if clauses else ""
        sql = (
            "SELECT tenant_id, issuer_did, tool, day, count "
            "FROM usage_daily" + where + " "
            "ORDER BY day DESC, tenant_id ASC, tool ASC"
        )
        with self._lock:
            cur = self._conn.execute(sql, params)
            rows = cur.fetchall()
        return [UsageRow(*r) for r in rows]

    def totals_by_tenant(
        self,
        *,
        since: date | None = None,
        until: date | None = None,
    ) -> dict[str, int]:
        """Sum of all calls per tenant in the window. Used by invoicing."""
        clauses: list[str] = []
        params: list[object] = []
        if since is not None:
            clauses.append("day >= ?")
            params.append(since.isoformat())
        if until is not None:
            clauses.append("day <= ?")
            params.append(until.isoformat())
        where = (" WHERE " + " AND ".join(clauses)) if clauses else ""
        sql = (
            "SELECT tenant_id, SUM(count) "
            "FROM usage_daily" + where + " "
            "GROUP BY tenant_id ORDER BY SUM(count) DESC"
        )
        with self._lock:
            cur = self._conn.execute(sql, params)
            rows = cur.fetchall()
        return {tenant_id: int(total) for tenant_id, total in rows}

    def close(self) -> None:
        with self._lock:
            self._conn.close()


# ---------------------------------------------------------------------------
# Process-default store
# ---------------------------------------------------------------------------

_DEFAULT_STORE: UsageStore | None = None
_DEFAULT_STORE_LOCK = threading.Lock()


def make_store_from_env() -> UsageStore:
    """Return (and lazily build) the process-default store.

    Reads ``GTV_BILLING_DB``. If unset, falls back to ``:memory:``
    so the metering codepath is exercised in tests but never writes
    to disk in default deployments — operators must opt in to
    persistent billing.
    """
    global _DEFAULT_STORE
    with _DEFAULT_STORE_LOCK:
        if _DEFAULT_STORE is None:
            db_path = os.environ.get("GTV_BILLING_DB", ":memory:")
            _DEFAULT_STORE = UsageStore(db_path)
        return _DEFAULT_STORE


def reset_default_store() -> None:
    """Drop the cached process-default store. Test-only hook."""
    global _DEFAULT_STORE
    with _DEFAULT_STORE_LOCK:
        if _DEFAULT_STORE is not None:
            _DEFAULT_STORE.close()
            _DEFAULT_STORE = None


def record_usage(
    *,
    tenant_id: str,
    issuer_did: str,
    tool: str,
    when: datetime | None = None,
    count: int = 1,
) -> None:
    """Record a billable call against the process-default store.

    Designed to be a single-line hook from request handlers — never
    raises (logs and swallows) because losing a billing tick must
    never break a verify_claim response.
    """
    try:
        store = make_store_from_env()
        store.record(
            tenant_id=tenant_id,
            issuer_did=issuer_did,
            tool=tool,
            when=when,
            count=count,
        )
    except Exception:  # pragma: no cover - defensive
        # Billing is observability, not critical path. Swallow and
        # let the response succeed; operators surface drops via the
        # existing TENANT_REQUESTS Prometheus counter delta.
        import logging

        logging.getLogger(__name__).exception(
            "record_usage failed for tenant=%s tool=%s",
            tenant_id,
            tool,
        )
