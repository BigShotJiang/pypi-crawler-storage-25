# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Per-tenant billing/metering store (W34).

Operators selling gtv to multiple tenants need a durable record of
each tenant's usage so they can invoice. Prometheus counters answer
"is the system healthy?" — they're not source-of-truth for accounting.

Design
------
* One SQLite table aggregated to ``(tenant, issuer_did, tool, day)``.
  Per-request rows would balloon disk usage and slow queries; daily
  rollups are sufficient for monthly invoicing and trend analysis.
* Append via UPSERT: ``INSERT ... ON CONFLICT DO UPDATE SET count = count + ?``.
  One INSERT per request, but it touches one row per
  (tenant, issuer_did, tool, day) bucket — bounded cardinality.
* Default DB path: ``GTV_BILLING_DB`` env var, or in-memory if unset
  (so tests that never opt in still work).
* The CLI ``gtv-usage`` reads the same DB to produce reports.

Threading model: each writer opens its own connection because SQLite
is single-writer per connection. ``record_usage`` is called from the
async request handler — we use ``check_same_thread=False`` and a
thread-safe lock around the cursor.
"""

from __future__ import annotations

from gtv.billing.store import (
    UsageRow,
    UsageStore,
    make_store_from_env,
    record_usage,
    reset_default_store,
)

__all__ = [
    "UsageRow",
    "UsageStore",
    "make_store_from_env",
    "record_usage",
    "reset_default_store",
]
