# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Our World in Data adapter — curated open data charts on world topics.

Our World in Data publishes research and interactive visualizations on
global problems: health, food, poverty, inequality, violence, rights,
technology, environment, energy. All data is open source and free.

The platform exposes chart metadata via a JSON API, but lacks a general
search API. We use the published chart catalog and heuristic matching
to locate candidate charts relevant to claims.

API: https://ourworldindata.org/grapher/<slug>.metadata.json
No API key required. Metadata is cached on CDN; chart data is sourced
from underlying datasets (many with their own versioning).
"""
from __future__ import annotations

import asyncio
import hashlib
import logging
from datetime import UTC, datetime
from typing import Any

import httpx
from pydantic import HttpUrl

from gtv.adapters.base import RawSnapshot, SourceAdapter
from gtv.adapters.parse import claim_to_query
from gtv.models import Claim, Evidence, HealthStatus, SourceType, Stance, TrustTier

logger = logging.getLogger(__name__)


class OwidAdapter(SourceAdapter):
    """Search Our World in Data charts for evidence on global statistics."""

    source_did = "did:web:ourworldindata.org"
    name = "Our World in Data"
    source_type = SourceType.GOVT_OPEN_DATA
    trust_tier = TrustTier.TIER_1
    freshness_sla_s = 10

    _BASE = "https://ourworldindata.org"
    _CHARTS_CATALOG = f"{_BASE}/charts.json"
    _RATE_LIMIT_DELAY = 1.0

    def __init__(self, client: httpx.AsyncClient | None = None) -> None:
        self._client = client or httpx.AsyncClient(
            timeout=10.0,
            headers={"Accept": "application/json"},
        )
        self._owns_client = client is None
        self._last_request_time = 0.0
        self._charts_cache: dict[str, dict[str, Any]] | None = None

    async def _rate_limit(self) -> None:
        now = asyncio.get_event_loop().time()
        elapsed = now - self._last_request_time
        if elapsed < self._RATE_LIMIT_DELAY:
            await asyncio.sleep(self._RATE_LIMIT_DELAY - elapsed)
        self._last_request_time = asyncio.get_event_loop().time()

    async def _load_charts_catalog(self) -> dict[str, dict[str, Any]]:
        """Load the static charts catalog (cached in memory).

        The catalog maps slug to chart metadata including title.
        Returns {} on error (fail gracefully).
        """
        if self._charts_cache is not None:
            return self._charts_cache

        try:
            await self._rate_limit()
            response = await self._client.get(self._CHARTS_CATALOG)
            response.raise_for_status()
            catalog = response.json()
            # catalog is expected to be a dict of {slug: {title, ...}}
            self._charts_cache = catalog if isinstance(catalog, dict) else {}
        except (httpx.TimeoutException, httpx.NetworkError, httpx.HTTPStatusError):
            self._charts_cache = {}
        except ValueError:
            self._charts_cache = {}

        return self._charts_cache

    async def query(self, claim: Claim, max_items: int = 5) -> list[Evidence]:
        """Search OWID charts matching claim keywords.

        Strategy: load the chart catalog, search chart titles for keyword
        matches, fetch metadata for top N matches, return evidence.
        Falls back gracefully to [] if catalog is unavailable.
        """
        query_str = claim_to_query(claim.text)
        if not query_str:
            return []

        catalog = await self._load_charts_catalog()
        if not catalog:
            # Catalog unavailable; don't crash, just return [].
            return []

        # Simple heuristic: find charts whose title contains any query token.
        query_tokens = set(query_str.lower().split())
        scored_charts: list[tuple[str, int]] = []

        for slug, chart_data in catalog.items():
            title = (chart_data.get("title") or "").lower()
            if not title:
                continue
            score = sum(1 for token in query_tokens if token in title)
            if score > 0:
                scored_charts.append((slug, score))

        # Sort by relevance (higher score first) and take top N.
        scored_charts.sort(key=lambda x: x[1], reverse=True)
        top_slugs = [slug for slug, _ in scored_charts[:max_items]]

        evidence_list: list[Evidence] = []
        for slug in top_slugs:
            chart_url = f"{self._BASE}/grapher/{slug}"
            metadata_url = f"{chart_url}.metadata.json"

            try:
                await self._rate_limit()
                response = await self._client.get(metadata_url)
                response.raise_for_status()
                metadata = response.json()
            except (
                httpx.TimeoutException,
                httpx.NetworkError,
                httpx.HTTPStatusError,
            ):
                # Skip this chart on error; don't crash.
                continue
            except ValueError:
                # Malformed metadata; skip.
                continue

            # Extract useful metadata fields.
            title = metadata.get("title", "").strip()
            subtitle = metadata.get("subtitle", "").strip()
            source = metadata.get("source", {})
            source_name = (
                source.get("name", "").strip()
                if isinstance(source, dict)
                else ""
            )

            if not title:
                continue

            # Build excerpt from title, subtitle, and source.
            excerpt_parts = [title]
            if subtitle:
                excerpt_parts.append(subtitle)
            if source_name:
                excerpt_parts.append(f"Source: {source_name}")

            excerpt = " | ".join(excerpt_parts)
            if len(excerpt) > 1200:
                excerpt = excerpt[:1200]

            raw_hash = hashlib.sha256(excerpt.encode("utf-8")).hexdigest()
            evidence_list.append(
                Evidence(
                    claim_id=claim.claim_id,
                    source_did=self.source_did,
                    source_version="owid-chart-metadata",
                    stance=Stance.NEUTRAL,
                    excerpt=excerpt,
                    url=HttpUrl(chart_url),
                    retrieved_at=datetime.now(tz=UTC),
                    raw_hash=raw_hash,
                )
            )

        return evidence_list

    async def snapshot(self, url: str) -> RawSnapshot:
        """Fetch raw chart metadata or HTML for audit."""
        response = await self._client.get(url)
        response.raise_for_status()
        return RawSnapshot(
            url=url,
            content=response.content,
            retrieved_at_iso=datetime.now(tz=UTC).isoformat(),
        )

    async def health(self) -> HealthStatus:
        try:
            await self._rate_limit()
            response = await self._client.get(self._CHARTS_CATALOG, timeout=3.0)
            if 200 <= response.status_code < 400:
                return HealthStatus(
                    state="HEALTHY", detail="OWID charts catalog responsive"
                )
            return HealthStatus(
                state="DEGRADED",
                detail=f"OWID charts catalog returned {response.status_code}",
            )
        except httpx.TimeoutException:
            return HealthStatus(state="DOWN", detail="OWID catalog timeout (>3s)")
        except httpx.NetworkError as e:
            return HealthStatus(state="DOWN", detail=f"Network error: {e}")

    async def close(self) -> None:
        if self._owns_client:
            await self._client.aclose()
