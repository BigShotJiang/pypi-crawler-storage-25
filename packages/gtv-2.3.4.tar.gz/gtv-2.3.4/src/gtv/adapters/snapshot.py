# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""In-memory and persistent snapshot stores for content-addressing.

Snapshot stores manage the raw bytes fetched from sources, indexed by sha256.
"""
from __future__ import annotations

import hashlib
from abc import ABC, abstractmethod


class SnapshotStore(ABC):
    """Abstract snapshot store — implement for in-memory, sqlite, redis, etc."""

    @abstractmethod
    async def put(self, url: str, content_bytes: bytes) -> str:
        """Store content, return sha256 hexdigest."""

    @abstractmethod
    async def get(self, raw_hash: str) -> bytes | None:
        """Retrieve content by sha256 hexdigest, or None if not found."""


class InMemorySnapshotStore(SnapshotStore):
    """Simple in-memory snapshot store — no persistence."""

    def __init__(self) -> None:
        self._store: dict[str, bytes] = {}

    async def put(self, url: str, content_bytes: bytes) -> str:
        """Store content, return sha256 hexdigest.

        Args:
            url: The source URL (used for logging/audit; not part of content hash).
            content_bytes: The raw bytes to store.

        Returns:
            The sha256 hexdigest of content_bytes.
        """
        raw_hash = hashlib.sha256(content_bytes).hexdigest()
        self._store[raw_hash] = content_bytes
        return raw_hash

    async def get(self, raw_hash: str) -> bytes | None:
        """Retrieve content by sha256 hexdigest.

        Args:
            raw_hash: A sha256 hexdigest (lowercase, 64 hex chars).

        Returns:
            The content bytes, or None if not found.
        """
        return self._store.get(raw_hash)
