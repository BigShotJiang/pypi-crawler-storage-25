# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Retraction Watch adapter — query and snapshot integration.

Retraction Watch provides a database of retracted scholarly articles via
the Crossref Labs API. This adapter queries for retracted DOIs and returns
evidence with REFUTES stance when a paper is retracted.
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import logging
from datetime import UTC, datetime

import httpx
from pydantic import HttpUrl

from gtv.adapters.base import RawSnapshot, SourceAdapter
from gtv.models import Claim, Evidence, HealthStatus, SourceType, Stance, TrustTier

logger = logging.getLogger(__name__)


class RetractionWatchAdapter(SourceAdapter):
    """Query Retraction Watch for retracted paper information."""

    source_did = "did:web:retractionwatch.com"
    name = "Retraction Watch"
    source_type = SourceType.REFERENCE_DATA
    trust_tier = TrustTier.TIER_1
    freshness_sla_s = 10

    # Crossref Labs rate limit: conservative 1 req/sec
    _RATE_LIMIT_DELAY = 1.0

    def __init__(
        self,
        client: httpx.AsyncClient | None = None,
    ) -> None:
        """Initialize the Retraction Watch adapter.

        Args:
            client: AsyncClient with custom timeout (default: 10s).
        """
        self._client = client or httpx.AsyncClient(timeout=10.0)
        self._owns_client = client is None
        self._last_request_time = 0.0

    async def _rate_limit(self) -> None:
        """Enforce rate limit between requests."""
        now = asyncio.get_event_loop().time()
        elapsed = now - self._last_request_time
        if elapsed < self._RATE_LIMIT_DELAY:
            await asyncio.sleep(self._RATE_LIMIT_DELAY - elapsed)
        self._last_request_time = asyncio.get_event_loop().time()

    async def _extract_dois(self, claim_text: str) -> list[str]:
        """Extract potential DOIs from claim text.

        Simple pattern matching for DOI format (10.xxxx/yyyy).

        Args:
            claim_text: The claim text to search.

        Returns:
            A list of extracted DOI strings.
        """
        dois = []
        words = claim_text.split()
        for word in words:
            # Look for DOI pattern: 10.xxxx/yyyy or variations
            if "10." in word and "/" in word:
                # Extract just the DOI part (handle punctuation)
                doi = word.rstrip(".,;:")
                if doi.startswith("10."):
                    dois.append(doi)
        return dois

    async def query(self, claim: Claim, max_items: int = 5) -> list[Evidence]:
        """Query Retraction Watch for retracted papers related to the claim.

        If the claim or any cited paper is retracted, returns REFUTES evidence.
        Otherwise returns empty list (no evidence of retraction = not support).

        Args:
            claim: The Claim to search for.
            max_items: Max results to return (default 5).

        Returns:
            A list of Evidence records with REFUTES stance if retraction found.
        """
        # Try to extract DOIs from the claim text.
        dois = await self._extract_dois(claim.text)

        evidence_list: list[Evidence] = []

        for doi in dois:
            await self._rate_limit()
            url = "https://api.labs.crossref.org/retraction-watch/query"
            params = {"doi": doi}

            try:
                response = await self._client.get(url, params=params)
                response.raise_for_status()
            except (httpx.TimeoutException, httpx.NetworkError, httpx.HTTPStatusError) as e:
                logger.warning(f"Failed to query Retraction Watch for DOI {doi}: {e}")
                continue

            try:
                result = response.json()
            except json.JSONDecodeError as e:
                logger.warning(f"Failed to parse Retraction Watch response for {doi}: {e}")
                continue

            # Check if retraction was found in the result.
            # The API returns a status field; retracted status indicates a match.
            if isinstance(result, dict):
                # API may return matched entries in various formats.
                # Common structure: {"status": "found", "retracted": True, ...}
                # or array of results.
                retracted = (
                    result.get("retracted", False)
                    or result.get("status") == "retracted"
                )

                if retracted:
                    excerpt = f"DOI {doi} is listed as retracted in Retraction Watch database."
                    raw_hash = hashlib.sha256(excerpt.encode("utf-8")).hexdigest()

                    url_obj = HttpUrl(f"https://retractionwatch.com/retracted/?doi={doi}")

                    evidence = Evidence(
                        claim_id=claim.claim_id,
                        source_did=self.source_did,
                        source_version="retraction-watch-v1",
                        stance=Stance.REFUTES,
                        excerpt=excerpt,
                        url=url_obj,
                        retrieved_at=datetime.now(tz=UTC),
                        raw_hash=raw_hash,
                    )
                    evidence_list.append(evidence)

            elif isinstance(result, list):
                # Array of retraction records
                for record in result:
                    if isinstance(record, dict) and record.get("retracted"):
                        excerpt = f"DOI {doi} is listed as retracted in Retraction Watch database."
                        raw_hash = hashlib.sha256(excerpt.encode("utf-8")).hexdigest()

                        url_obj = HttpUrl(f"https://retractionwatch.com/retracted/?doi={doi}")

                        evidence = Evidence(
                            claim_id=claim.claim_id,
                            source_did=self.source_did,
                            source_version="retraction-watch-v1",
                            stance=Stance.REFUTES,
                            excerpt=excerpt,
                            url=url_obj,
                            retrieved_at=datetime.now(tz=UTC),
                            raw_hash=raw_hash,
                        )
                        evidence_list.append(evidence)
                        break

        return evidence_list

    async def snapshot(self, url: str) -> RawSnapshot:
        """Fetch and hash a single Retraction Watch page.

        Args:
            url: The Retraction Watch URL.

        Returns:
            A RawSnapshot with content and computed hash.
        """
        await self._rate_limit()
        response = await self._client.get(url)
        response.raise_for_status()

        return RawSnapshot(
            url=url,
            content=response.content,
            retrieved_at_iso=datetime.now(tz=UTC).isoformat(),
        )

    async def health(self) -> HealthStatus:
        """Check the Retraction Watch / Crossref endpoint.

        Returns:
            HealthStatus with state and optional detail.
        """
        try:
            await self._rate_limit()
            response = await self._client.get(
                "https://api.labs.crossref.org/retraction-watch/query"
            )
            if response.status_code < 500:
                return HealthStatus(
                    state="HEALTHY",
                    detail="Retraction Watch API accessible",
                    checked_at=datetime.now(tz=UTC),
                )
            else:
                return HealthStatus(
                    state="DEGRADED",
                    detail=f"Retraction Watch returned {response.status_code}",
                    checked_at=datetime.now(tz=UTC),
                )
        except (httpx.TimeoutException, httpx.NetworkError):
            return HealthStatus(
                state="DOWN",
                detail="Network error reaching Retraction Watch",
                checked_at=datetime.now(tz=UTC),
            )

    async def close(self) -> None:
        """Release HTTP client if owned by this adapter."""
        if self._owns_client:
            await self._client.aclose()
