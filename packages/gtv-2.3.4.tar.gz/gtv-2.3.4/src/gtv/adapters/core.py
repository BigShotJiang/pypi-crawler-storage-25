# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""CORE research aggregator adapter.

CORE is a global aggregator of open-access research across multiple
repositories and platforms. It provides access to millions of preprints,
peer-reviewed articles, and research datasets via a public REST API.

API: https://api.core.ac.uk/v3/search/works
Requires CORE_API_KEY env var for authentication. If not present, the
adapter registers but returns [] on query and marks health DEGRADED.
"""
from __future__ import annotations

import asyncio
import hashlib
import logging
import os
from datetime import UTC, datetime

import httpx
from pydantic import HttpUrl

from gtv.adapters.base import RawSnapshot, SourceAdapter
from gtv.adapters.parse import claim_to_query
from gtv.models import Claim, Evidence, HealthStatus, SourceType, Stance, TrustTier

logger = logging.getLogger(__name__)


class CoreAdapter(SourceAdapter):
    """Search CORE research aggregator for evidence."""

    source_did = "did:web:core.ac.uk"
    name = "CORE"
    source_type = SourceType.PREPRINT
    trust_tier = TrustTier.TIER_2
    freshness_sla_s = 10

    _BASE = "https://api.core.ac.uk/v3/search/works"
    _RATE_LIMIT_DELAY = 0.5  # conservative: 2 req/sec

    def __init__(self, client: httpx.AsyncClient | None = None) -> None:
        headers = {"Accept": "application/json"}
        self._api_key = os.getenv("CORE_API_KEY")
        if self._api_key:
            headers["Authorization"] = f"Bearer {self._api_key}"
        self._client = client or httpx.AsyncClient(timeout=10.0, headers=headers)
        self._owns_client = client is None
        self._last_request_time = 0.0

    async def _rate_limit(self) -> None:
        now = asyncio.get_event_loop().time()
        elapsed = now - self._last_request_time
        if elapsed < self._RATE_LIMIT_DELAY:
            await asyncio.sleep(self._RATE_LIMIT_DELAY - elapsed)
        self._last_request_time = asyncio.get_event_loop().time()

    @staticmethod
    def _detect_stance(text: str) -> Stance:
        """Heuristic to detect stance from abstract/title text.

        Borrowed from pubmed adapter logic: look for refutation keywords.
        """
        lower = text.lower()
        refute_keywords = [
            "no significant", "not associated", "failed", "no evidence",
            "contrary", "refutes", "not found", "negative", "no link",
            "disputed", "contradicts",
        ]
        for kw in refute_keywords:
            if kw in lower:
                return Stance.REFUTES

        support_keywords = [
            "confirms", "supports", "demonstrates", "shows", "evidence",
            "found", "associated", "significant", "proven", "validated",
            "establishes", "verifies", "correlation", "causation",
        ]
        for kw in support_keywords:
            if kw in lower:
                return Stance.SUPPORTS

        return Stance.NEUTRAL

    async def query(self, claim: Claim, max_items: int = 5) -> list[Evidence]:
        """Search CORE for research matching the claim.

        Returns [] with no error if CORE_API_KEY is not set; the health()
        method will mark status DEGRADED.
        """
        if not self._api_key:
            return []

        query_str = claim_to_query(claim.text)
        if not query_str:
            return []

        await self._rate_limit()
        params: dict[str, str | int] = {
            "q": query_str,
            "limit": max_items,
        }
        try:
            response = await self._client.get(self._BASE, params=params)
            response.raise_for_status()
        except (httpx.TimeoutException, httpx.NetworkError, httpx.HTTPStatusError):
            raise

        try:
            payload = response.json()
        except ValueError as e:
            raise ValueError(f"Failed to parse CORE response: {e}") from e

        items = payload.get("results", []) or []
        evidence_list: list[Evidence] = []
        for item in items[:max_items]:
            item_id = item.get("id")
            title = (item.get("title") or "").strip()
            abstract = (item.get("abstract") or "").strip()

            if not item_id or not title:
                continue

            # Determine URL: downloadUrl > first of urls > fallback to CORE record page
            download_url = item.get("downloadUrl")
            if download_url:
                url_str = download_url
            else:
                urls = item.get("urls") or []
                url_str = (
                    urls[0]
                    if urls and urls[0]
                    else f"https://core.ac.uk/works/{item_id}"
                )

            # Build excerpt from abstract
            excerpt = f"{title}. {abstract[:600]}" if abstract else title
            if len(excerpt) > 1200:
                excerpt = excerpt[:1200]

            # Detect stance from abstract + title
            stance = self._detect_stance(f"{title} {abstract}")

            raw_hash = hashlib.sha256(excerpt.encode("utf-8")).hexdigest()
            url = HttpUrl(url_str)
            evidence_list.append(
                Evidence(
                    claim_id=claim.claim_id,
                    source_did=self.source_did,
                    source_version="core-v3",
                    stance=stance,
                    excerpt=excerpt,
                    url=url,
                    retrieved_at=datetime.now(tz=UTC),
                    raw_hash=raw_hash,
                )
            )

        return evidence_list

    async def snapshot(self, url: str) -> RawSnapshot:
        """Fetch the raw document for audit."""
        response = await self._client.get(url)
        response.raise_for_status()
        return RawSnapshot(
            url=url,
            content=response.content,
            retrieved_at_iso=datetime.now(tz=UTC).isoformat(),
        )

    async def health(self) -> HealthStatus:
        if not self._api_key:
            return HealthStatus(state="DEGRADED", detail="CORE_API_KEY not set")

        try:
            await self._rate_limit()
            response = await self._client.get(
                self._BASE,
                params={"q": "test", "limit": 1},
                timeout=3.0,
            )
            if 200 <= response.status_code < 400:
                return HealthStatus(state="HEALTHY", detail="CORE responsive")
            if response.status_code in (403, 429):
                return HealthStatus(
                    state="DEGRADED",
                    detail=f"CORE rate-limited ({response.status_code})",
                )
            return HealthStatus(
                state="DEGRADED", detail=f"CORE returned {response.status_code}"
            )
        except httpx.TimeoutException:
            return HealthStatus(state="DOWN", detail="CORE timeout (>3s)")
        except httpx.NetworkError as e:
            return HealthStatus(state="DOWN", detail=f"Network error: {e}")

    async def close(self) -> None:
        if self._owns_client:
            await self._client.aclose()
