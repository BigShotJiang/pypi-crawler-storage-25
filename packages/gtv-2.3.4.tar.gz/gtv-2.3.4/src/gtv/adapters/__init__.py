# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Source adapters — one per federated source.

Add a new adapter by:
1. Subclassing `SourceAdapter` in a new module (e.g. `arxiv.py`).
2. Registering it in `REGISTRY` below.
3. Adding a contract test in `tests/adapters/`.

Never return fabricated evidence. On failure, report `HealthStatus.DEGRADED`
and return an empty list.
"""
from __future__ import annotations

import os

from gtv.adapters.base import SourceAdapter

REGISTRY: dict[str, SourceAdapter] = {}


def _maybe_wrap_breaker(adapter: SourceAdapter) -> SourceAdapter:
    """If ``GTV_CB_ENABLED`` is truthy, wrap in the circuit breaker.

    Declared here so every `register()` call — default adapters, plugin
    adapters, SDK users — gets the same remediation envelope without
    each site needing to opt in. Default OFF so behavior is unchanged
    for anyone who hasn't tuned their SLOs yet.
    """
    if os.getenv("GTV_CB_ENABLED", "0") not in ("1", "true", "yes"):
        return adapter
    # Late import so tests that disable prom or swap modules still work.
    from gtv.obs.circuit import AdapterCircuitBreaker, load_circuit_config_from_env

    return AdapterCircuitBreaker(adapter, load_circuit_config_from_env())


def _maybe_wrap_cache(adapter: SourceAdapter) -> SourceAdapter:
    """If ``GTV_ADAPTER_CACHE_ENABLED`` is truthy, wrap with per-adapter cache.

    Sits INSIDE the breaker — cache first, breaker second — so a burst
    of duplicate claims never even reaches the rolling-window failure
    tracker. Default OFF.
    """
    if os.getenv("GTV_ADAPTER_CACHE_ENABLED", "0") not in ("1", "true", "yes"):
        return adapter
    from gtv.adapters.cache import CachingAdapter, load_adapter_cache_config_from_env

    cfg = load_adapter_cache_config_from_env()
    return CachingAdapter(adapter, ttl_s=cfg.ttl_s, max_entries=cfg.max_entries)


def register(adapter: SourceAdapter) -> None:
    # Cache first (so hits skip the breaker), then breaker, then registry.
    wrapped = _maybe_wrap_breaker(_maybe_wrap_cache(adapter))
    if wrapped.source_did in REGISTRY:
        raise ValueError(f"Duplicate adapter registration: {wrapped.source_did}")
    REGISTRY[wrapped.source_did] = wrapped


def _enabled(env_var: str) -> bool:
    """True unless an adapter-specific disable env var is set.

    Matches the runbook in ``docs/slos.md``: ops can ``export
    GTV_FOO_DISABLE=1`` to stop bleeding latency budget from a sick
    adapter without redeploying.
    """
    return os.getenv(env_var, "0") not in ("1", "true", "yes")


# Register default adapters unless disabled.
if not os.getenv("GTV_DISABLE_DEFAULT_ADAPTERS"):
    from gtv.adapters.arxiv import ArxivAdapter
    from gtv.adapters.core import CoreAdapter
    from gtv.adapters.crossref import CrossrefAdapter
    from gtv.adapters.dailymed import DailyMedAdapter
    from gtv.adapters.europepmc import EuropePMCAdapter
    from gtv.adapters.ghsa import GhsaAdapter
    from gtv.adapters.inspire_hep import InspireHepAdapter
    from gtv.adapters.nist import NISTAdapter
    from gtv.adapters.openalex import OpenAlexAdapter
    from gtv.adapters.openfda import OpenFDAAdapter
    from gtv.adapters.owid import OwidAdapter
    from gtv.adapters.pubmed import PubmedAdapter
    from gtv.adapters.retraction_watch import RetractionWatchAdapter
    from gtv.adapters.semantic_scholar import SemanticScholarAdapter
    from gtv.adapters.who_gho import WHOGHOAdapter
    from gtv.adapters.wikidata import WikidataAdapter

    if _enabled("GTV_ARXIV_DISABLE"):
        register(ArxivAdapter())
    if _enabled("GTV_INSPIRE_HEP_DISABLE"):
        register(InspireHepAdapter())
    if _enabled("GTV_CROSSREF_DISABLE"):
        register(CrossrefAdapter())
    if _enabled("GTV_OPENALEX_DISABLE"):
        register(OpenAlexAdapter())
    if _enabled("GTV_SEMANTIC_SCHOLAR_DISABLE"):
        register(SemanticScholarAdapter())
    if _enabled("GTV_PUBMED_DISABLE"):
        register(PubmedAdapter())
    if _enabled("GTV_NIST_DISABLE"):
        register(NISTAdapter())
    if _enabled("GTV_RETRACTION_WATCH_DISABLE"):
        register(RetractionWatchAdapter())
    if _enabled("GTV_DAILYMED_DISABLE"):
        register(DailyMedAdapter())
    if _enabled("GTV_GHSA_DISABLE"):
        register(GhsaAdapter())
    if _enabled("GTV_OPENFDA_DISABLE"):
        register(OpenFDAAdapter())
    if _enabled("GTV_CORE_DISABLE"):
        register(CoreAdapter())
    if _enabled("GTV_EUROPEPMC_DISABLE"):
        register(EuropePMCAdapter())
    if _enabled("GTV_WHO_GHO_DISABLE"):
        register(WHOGHOAdapter())
    if _enabled("GTV_WIKIDATA_DISABLE"):
        register(WikidataAdapter())
    if _enabled("GTV_OWID_DISABLE"):
        register(OwidAdapter())

# Pick up out-of-tree adapter plugins via Python entry points (W38).
# Failures in individual plugins are logged, never raised — a broken
# third-party plugin must not prevent server startup.
from gtv.adapters.discovery import discover_plugin_adapters  # noqa: E402

discover_plugin_adapters(register_fn=register)
