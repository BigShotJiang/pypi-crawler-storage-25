# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""OpenFDA drug label adapter.

OpenFDA is the public API for FDA-approved drug labels. It aggregates SPL
(Structured Product Labeling) data from DailyMed and provides structured
access to indications, warnings, dosage, and other clinical information.

API: https://api.fda.gov/drug/label.json
No API key required. Optional OPENFDA_API_KEY env var for higher rate limits.
"""
from __future__ import annotations

import asyncio
import hashlib
import logging
import os
from datetime import UTC, datetime

import httpx
from pydantic import HttpUrl

from gtv.adapters.base import RawSnapshot, SourceAdapter
from gtv.adapters.parse import claim_to_query
from gtv.models import Claim, Evidence, HealthStatus, SourceType, Stance, TrustTier

logger = logging.getLogger(__name__)


class OpenFDAAdapter(SourceAdapter):
    """Search OpenFDA for drug label evidence."""

    source_did = "did:web:open.fda.gov"
    name = "OpenFDA"
    source_type = SourceType.GOVT_OPEN_DATA
    trust_tier = TrustTier.TIER_1
    freshness_sla_s = 10

    _BASE = "https://api.fda.gov/drug/label.json"
    _RATE_LIMIT_DELAY = 0.5  # conservative: 2 req/sec keeps well under any published ceiling

    def __init__(self, client: httpx.AsyncClient | None = None) -> None:
        headers = {"Accept": "application/json"}
        api_key = os.getenv("OPENFDA_API_KEY")
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"
        self._client = client or httpx.AsyncClient(timeout=10.0, headers=headers)
        self._owns_client = client is None
        self._last_request_time = 0.0

    async def _rate_limit(self) -> None:
        now = asyncio.get_event_loop().time()
        elapsed = now - self._last_request_time
        if elapsed < self._RATE_LIMIT_DELAY:
            await asyncio.sleep(self._RATE_LIMIT_DELAY - elapsed)
        self._last_request_time = asyncio.get_event_loop().time()

    async def query(self, claim: Claim, max_items: int = 5) -> list[Evidence]:
        """Search OpenFDA for drug labels matching keywords in the claim.

        Labels are reference data — stance is NEUTRAL by default. The
        verdict engine will treat label presence as confirming the
        drug exists and its approved indications, nothing more.
        """
        query_str = claim_to_query(claim.text)
        if not query_str:
            return []

        await self._rate_limit()
        params: dict[str, str | int] = {
            "search": f"openfda.brand_name:{query_str}",
            "limit": max_items,
        }
        try:
            response = await self._client.get(self._BASE, params=params)
            response.raise_for_status()
        except (httpx.TimeoutException, httpx.NetworkError, httpx.HTTPStatusError):
            raise

        try:
            payload = response.json()
        except ValueError as e:
            raise ValueError(f"Failed to parse OpenFDA response: {e}") from e

        items = payload.get("results", []) or []
        evidence_list: list[Evidence] = []
        for item in items[:max_items]:
            item_id = item.get("id")
            openfda = item.get("openfda") or {}
            brand_names = openfda.get("brand_name") or []
            generic_names = openfda.get("generic_name") or []
            indications = item.get("indications_and_usage") or []

            if not item_id:
                continue

            # Use first brand_name or generic_name as title
            title = None
            if brand_names and brand_names[0]:
                title = brand_names[0]
            elif generic_names and generic_names[0]:
                title = generic_names[0]

            if not title:
                continue

            # Build excerpt from indications
            body = ""
            if indications and indications[0]:
                body = indications[0][:800]  # truncate to reasonable size

            excerpt = f"{title}. {body}" if body else title
            if len(excerpt) > 1200:
                excerpt = excerpt[:1200]

            raw_hash = hashlib.sha256(excerpt.encode("utf-8")).hexdigest()
            url = HttpUrl(f"https://labels.fda.gov/{item_id}")
            evidence_list.append(
                Evidence(
                    claim_id=claim.claim_id,
                    source_did=self.source_did,
                    source_version="openfda-v1",
                    stance=Stance.NEUTRAL,
                    excerpt=excerpt,
                    url=url,
                    retrieved_at=datetime.now(tz=UTC),
                    raw_hash=raw_hash,
                )
            )

        return evidence_list

    async def snapshot(self, url: str) -> RawSnapshot:
        """Fetch the raw label document for audit."""
        response = await self._client.get(url)
        response.raise_for_status()
        return RawSnapshot(
            url=url,
            content=response.content,
            retrieved_at_iso=datetime.now(tz=UTC).isoformat(),
        )

    async def health(self) -> HealthStatus:
        try:
            await self._rate_limit()
            response = await self._client.get(
                self._BASE,
                params={
                    "search": "openfda.brand_name:aspirin",
                    "limit": 1,
                },
                timeout=3.0,
            )
            if 200 <= response.status_code < 400:
                return HealthStatus(state="HEALTHY", detail="OpenFDA responsive")
            return HealthStatus(
                state="DEGRADED", detail=f"OpenFDA returned {response.status_code}"
            )
        except httpx.TimeoutException:
            return HealthStatus(state="DOWN", detail="OpenFDA timeout (>3s)")
        except httpx.NetworkError as e:
            return HealthStatus(state="DOWN", detail=f"Network error: {e}")

    async def close(self) -> None:
        if self._owns_client:
            await self._client.aclose()
