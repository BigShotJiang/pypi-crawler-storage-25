# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""The single protocol every source adapter must implement.

Design rules (see build spec §8):

- Async only. Never block.
- Per-source `httpx.AsyncClient` — never share.
- Respect upstream rate limits. Use exponential backoff with jitter.
- Cache responsibly (ETag / Last-Modified / 24h negative on 404).
- On hard failure: return [] + report DEGRADED. Never fabricate evidence.
- Every `Evidence` you emit must carry an exact `source_version` and `raw_hash`.
"""
from __future__ import annotations

import hashlib
from abc import ABC, abstractmethod
from dataclasses import dataclass

from gtv.models import Claim, Evidence, HealthStatus, SourceType, TrustTier


@dataclass(frozen=True)
class RawSnapshot:
    """Immutable content snapshot from a source — content-addressed by raw_hash."""
    url: str
    content: bytes
    retrieved_at_iso: str

    @property
    def raw_hash(self) -> str:
        return hashlib.sha256(self.content).hexdigest()


class SourceAdapter(ABC):
    source_did: str
    name: str
    trust_tier: TrustTier
    source_type: SourceType
    freshness_sla_s: int

    @abstractmethod
    async def query(self, claim: Claim, max_items: int = 5) -> list[Evidence]:
        """Return evidence items relevant to `claim`.

        On any error, return [] and emit a DEGRADED health record via `health()`.
        """

    @abstractmethod
    async def snapshot(self, url: str) -> RawSnapshot:
        """Fetch-and-hash a single source document. Used for audit trails."""

    @abstractmethod
    async def health(self) -> HealthStatus:
        """Check the upstream. Must complete in < freshness_sla_s."""

    @abstractmethod
    async def close(self) -> None:
        """Release HTTP pools / DB handles / etc."""
