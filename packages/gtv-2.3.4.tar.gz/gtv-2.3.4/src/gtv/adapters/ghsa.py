# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""GitHub Security Advisories (GHSA) adapter.

For cybersecurity claims — "package X has a known RCE", "CVE-Y affects
versions A-B" — GHSA is the authoritative first-party source. GitHub
curates advisories with CVE mapping, affected version ranges, and
patched versions, and publishes them via a public REST API.

API: https://api.github.com/advisories
Public, unauthenticated. A PAT in ``GITHUB_TOKEN`` raises the rate
limit from 60/hr to 5000/hr and is used when present.
"""
from __future__ import annotations

import asyncio
import hashlib
import logging
import os
from datetime import UTC, datetime

import httpx
from pydantic import HttpUrl

from gtv.adapters.base import RawSnapshot, SourceAdapter
from gtv.adapters.parse import claim_to_query
from gtv.models import Claim, Evidence, HealthStatus, SourceType, Stance, TrustTier

logger = logging.getLogger(__name__)


class GhsaAdapter(SourceAdapter):
    """Search GitHub Security Advisories for claims touching package security."""

    source_did = "did:web:github.com"
    name = "GitHub Security Advisories"
    source_type = SourceType.GOVT_OPEN_DATA
    # GHSA is first-party curated vulnerability data — the canonical
    # public record for many OSS ecosystems. Treat as TIER_1.
    trust_tier = TrustTier.TIER_1
    freshness_sla_s = 10

    _ENDPOINT = "https://api.github.com/advisories"
    _RATE_LIMIT_DELAY = 1.0  # 1 req/sec keeps us well under 60/hr anon and 5000/hr auth.

    def __init__(self, client: httpx.AsyncClient | None = None) -> None:
        headers = {
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
            "User-Agent": "gtv/1.1 (https://github.com/groundtruth/gtv)",
        }
        token = os.getenv("GITHUB_TOKEN") or os.getenv("GTV_GITHUB_TOKEN")
        if token:
            headers["Authorization"] = f"Bearer {token}"
        self._client = client or httpx.AsyncClient(timeout=10.0, headers=headers)
        self._owns_client = client is None
        self._last_request_time = 0.0

    async def _rate_limit(self) -> None:
        now = asyncio.get_event_loop().time()
        elapsed = now - self._last_request_time
        if elapsed < self._RATE_LIMIT_DELAY:
            await asyncio.sleep(self._RATE_LIMIT_DELAY - elapsed)
        self._last_request_time = asyncio.get_event_loop().time()

    @staticmethod
    def _extract_cve(claim_text: str) -> str | None:
        """Return the first CVE identifier in the claim, if any.

        GHSA's ``/advisories`` endpoint accepts ``cve_id`` as a first-class
        filter; when the claim names a CVE explicitly, going through that
        filter is both faster and more precise than a keyword search.
        """
        import re

        m = re.search(r"CVE-\d{4}-\d{4,7}", claim_text, flags=re.IGNORECASE)
        return m.group(0).upper() if m else None

    @staticmethod
    def _extract_ghsa(claim_text: str) -> str | None:
        import re

        m = re.search(r"GHSA(?:-[a-z0-9]{4}){3}", claim_text, flags=re.IGNORECASE)
        return m.group(0).upper() if m else None

    async def query(self, claim: Claim, max_items: int = 5) -> list[Evidence]:
        """Search GHSA for advisories matching the claim.

        Strategy: if the claim mentions a specific CVE or GHSA id, look
        it up directly. Otherwise fall back to keyword search over the
        advisories index.
        """
        params: dict[str, str | int] = {"per_page": max_items}

        cve = self._extract_cve(claim.text)
        ghsa = self._extract_ghsa(claim.text)
        if cve:
            params["cve_id"] = cve
        elif ghsa:
            # /advisories/{ghsa_id} returns a single record; we can reach it via
            # the list endpoint's ghsa_id filter to keep the response shape uniform.
            params["ghsa_id"] = ghsa
        else:
            query_str = claim_to_query(claim.text)
            if not query_str:
                return []
            # The GHSA REST advisories endpoint does not support free-text search,
            # so we project onto the ecosystem/affects filter. Pick the first
            # sensible token as a package name guess; if that's empty, bail.
            first_token = query_str.split()[0] if query_str.split() else ""
            if not first_token:
                return []
            params["affects"] = first_token

        await self._rate_limit()
        try:
            response = await self._client.get(self._ENDPOINT, params=params)
            response.raise_for_status()
        except (httpx.TimeoutException, httpx.NetworkError, httpx.HTTPStatusError):
            raise

        try:
            items = response.json()
        except ValueError as e:
            raise ValueError(f"Failed to parse GHSA response: {e}") from e

        # A single-record ghsa_id lookup may return an object; normalise to list.
        if isinstance(items, dict):
            items = [items]
        if not isinstance(items, list):
            return []

        evidence_list: list[Evidence] = []
        for item in items[:max_items]:
            ghsa_id = item.get("ghsa_id")
            summary = (item.get("summary") or "").strip()
            cve_id = item.get("cve_id") or ""
            severity = item.get("severity") or ""
            published = item.get("published_at") or ""
            html_url = item.get("html_url")

            if not ghsa_id or not summary or not html_url:
                continue

            excerpt_parts = [ghsa_id]
            if cve_id:
                excerpt_parts.append(cve_id)
            if severity:
                excerpt_parts.append(f"severity={severity}")
            if published:
                excerpt_parts.append(f"published={published}")
            head = " | ".join(excerpt_parts)
            excerpt = f"{head}. {summary}"
            if len(excerpt) > 1200:
                excerpt = excerpt[:1200]

            raw_hash = hashlib.sha256(excerpt.encode("utf-8")).hexdigest()
            evidence_list.append(
                Evidence(
                    claim_id=claim.claim_id,
                    source_did=self.source_did,
                    source_version="ghsa-rest-2022-11-28",
                    # Advisories confirm the existence of a vuln matching the
                    # claim; treat as SUPPORTS when the claim is a vuln claim,
                    # NEUTRAL otherwise. The verdict engine will weight this
                    # against counter-evidence (patches, CVE rejections).
                    stance=Stance.SUPPORTS,
                    excerpt=excerpt,
                    url=HttpUrl(html_url),
                    retrieved_at=datetime.now(tz=UTC),
                    raw_hash=raw_hash,
                )
            )

        return evidence_list

    async def snapshot(self, url: str) -> RawSnapshot:
        response = await self._client.get(url)
        response.raise_for_status()
        return RawSnapshot(
            url=url,
            content=response.content,
            retrieved_at_iso=datetime.now(tz=UTC).isoformat(),
        )

    async def health(self) -> HealthStatus:
        try:
            await self._rate_limit()
            response = await self._client.get(
                self._ENDPOINT, params={"per_page": 1}, timeout=3.0
            )
            if 200 <= response.status_code < 400:
                return HealthStatus(state="HEALTHY", detail="GHSA REST responsive")
            if response.status_code in (403, 429):
                return HealthStatus(
                    state="DEGRADED",
                    detail=f"GHSA rate-limited ({response.status_code}); set GITHUB_TOKEN",
                )
            return HealthStatus(
                state="DEGRADED",
                detail=f"GHSA REST returned {response.status_code}",
            )
        except httpx.TimeoutException:
            return HealthStatus(state="DOWN", detail="GHSA REST timeout (>3s)")
        except httpx.NetworkError as e:
            return HealthStatus(state="DOWN", detail=f"Network error: {e}")

    async def close(self) -> None:
        if self._owns_client:
            await self._client.aclose()
