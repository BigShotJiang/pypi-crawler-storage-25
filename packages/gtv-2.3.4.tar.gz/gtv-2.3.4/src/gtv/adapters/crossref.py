# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Crossref adapter — query and snapshot integration for metadata and references."""
from __future__ import annotations

import json
import re
from datetime import UTC, datetime

import httpx
from pydantic import HttpUrl

from gtv.adapters.base import RawSnapshot, SourceAdapter
from gtv.adapters.parse import claim_to_query
from gtv.adapters.snapshot import InMemorySnapshotStore, SnapshotStore
from gtv.models import Claim, Evidence, HealthStatus, SourceType, Stance, TrustTier

# User-Agent for Crossref polite pool access.
_USER_AGENT = "gtv/0.1 (+https://github.com/groundtruth/gtv; mailto:ops@groundtruth.example)"


class CrossrefAdapter(SourceAdapter):
    """Fetch and verify evidence from Crossref metadata database."""

    source_did = "did:web:crossref.org"
    name = "Crossref"
    source_type = SourceType.REFERENCE_DATA
    trust_tier = TrustTier.TIER_1
    freshness_sla_s = 5

    def __init__(
        self,
        client: httpx.AsyncClient | None = None,
        snapshot_store: SnapshotStore | None = None,
    ) -> None:
        """Initialize the Crossref adapter.

        Args:
            client: AsyncClient with custom timeout (default: 5s).
            snapshot_store: SnapshotStore for content-addressing (default: InMemory).
        """
        self._client = client or httpx.AsyncClient(timeout=5.0)
        self._snapshot_store = snapshot_store or InMemorySnapshotStore()
        self._owns_client = client is None  # track if we created it (for cleanup)

    async def query(self, claim: Claim, max_items: int = 5) -> list[Evidence]:
        """Query Crossref for works relevant to the claim.

        Args:
            claim: The Claim to search for.
            max_items: Max results to return (default 5).

        Returns:
            A list of Evidence records, one per matching work.

        Raises:
            httpx.TimeoutException, httpx.NetworkError: On network failure.
        """
        # Extract search query from claim text.
        query_str = claim_to_query(claim.text)
        if not query_str:
            return []

        # Call Crossref API with polite User-Agent.
        url = "https://api.crossref.org/works"
        params: dict[str, str | int] = {
            "query": query_str,
            "rows": max_items,
            "select": "DOI,title,abstract,URL",
        }
        headers = {"User-Agent": _USER_AGENT}

        try:
            response = await self._client.get(url, params=params, headers=headers)
            response.raise_for_status()
        except httpx.TimeoutException:
            raise
        except httpx.NetworkError:
            raise
        except httpx.HTTPStatusError:
            raise

        # Parse JSON response.
        try:
            data = response.json()
        except json.JSONDecodeError as e:
            raise ValueError(f"Failed to parse Crossref API response: {e}") from e

        # Extract entries from message.items.
        evidence_list: list[Evidence] = []
        items = data.get("message", {}).get("items", [])

        for item in items:
            # Extract DOI.
            doi = item.get("DOI")
            if not doi:
                continue

            # Build URL: prefer URL field, fallback to doi.org.
            url_str = item.get("URL")
            if not url_str:
                url_str = f"https://doi.org/{doi}"

            # Extract excerpt: prefer abstract (stripped of JATS tags), else title.
            excerpt = ""
            abstract = item.get("abstract")
            if abstract:
                # Strip JATS tags: <[^>]+> -> ""
                excerpt = re.sub(r"<[^>]+>", "", abstract).strip()
            if not excerpt:
                # Fallback to title.
                titles = item.get("title")
                if titles and isinstance(titles, list) and len(titles) > 0:
                    excerpt = titles[0].strip()
                elif titles and isinstance(titles, str):
                    excerpt = titles.strip()

            excerpt = excerpt if len(excerpt) <= 1200 else excerpt[:1200]

            # Store in snapshot store to get raw_hash.
            excerpt_bytes = excerpt.encode("utf-8")
            raw_hash = await self._snapshot_store.put(url_str, excerpt_bytes)

            # Build Evidence record.
            evidence = Evidence(
                claim_id=claim.claim_id,
                source_did=self.source_did,
                source_version="crossref-api-v1",
                stance=Stance.NEUTRAL,
                excerpt=excerpt,
                url=HttpUrl(url_str),
                retrieved_at=datetime.now(tz=UTC),
                raw_hash=raw_hash,
            )
            evidence_list.append(evidence)

        return evidence_list

    async def snapshot(self, url: str) -> RawSnapshot:
        """Fetch and hash a single Crossref work page.

        Args:
            url: The Crossref URL (usually a DOI URL or direct work URL).

        Returns:
            A RawSnapshot with content and computed hash.

        Raises:
            httpx.TimeoutException, httpx.NetworkError, httpx.HTTPStatusError:
                On network or HTTP errors.
        """
        headers = {"User-Agent": _USER_AGENT}
        response = await self._client.get(url, headers=headers)
        response.raise_for_status()

        return RawSnapshot(
            url=url,
            content=response.content,
            retrieved_at_iso=datetime.now(tz=UTC).isoformat(),
        )

    async def health(self) -> HealthStatus:
        """Check Crossref API health.

        GET a minimal query with a 3s timeout.

        Returns:
            HealthStatus with state and detail message.
        """
        try:
            headers = {"User-Agent": _USER_AGENT}
            response = await self._client.get(
                "https://api.crossref.org/works",
                params={"query": "test", "rows": "1"},
                headers=headers,
                timeout=3.0,
            )
            if response.status_code in (200, 301, 302, 304):
                return HealthStatus(state="HEALTHY", detail="Crossref API responsive")
            else:
                return HealthStatus(
                    state="DEGRADED",
                    detail=f"Crossref API returned {response.status_code}",
                )
        except httpx.TimeoutException:
            return HealthStatus(state="DOWN", detail="Crossref API timeout (>3s)")
        except httpx.NetworkError as e:
            return HealthStatus(state="DOWN", detail=f"Network error: {e}")

    async def close(self) -> None:
        """Close the httpx client if we own it."""
        if self._owns_client:
            await self._client.aclose()
