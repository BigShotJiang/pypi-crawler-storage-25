# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Adapter horizontal sharding via consistent hashing.

Problem: at 100 workers x ~16 adapters = 1600 upstream connections -- wasteful
for rarely-hit adapters. Solution: route each (claim, adapter) pair to exactly
one shard per N workers, so only O(N) connections total.

Wire format for forwarding: POST {peer_url}/internal/adapter/{source_did}/query
with JSON {"claim_id": ..., "claim_text": ..., "domain": ..., "max_items": N}.
Expect JSON list of Evidence dicts back.
"""
from __future__ import annotations

import hashlib
import logging
import os
from dataclasses import dataclass

import httpx

from gtv.adapters.base import RawSnapshot, SourceAdapter
from gtv.models import Claim, Evidence, HealthStatus

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class ShardConfig:
    """Configuration for horizontal sharding across N workers."""

    total_shards: int  # total workers in cluster
    my_shard_id: int   # 0-indexed; this worker's ID

    def __post_init__(self) -> None:
        if self.my_shard_id >= self.total_shards:
            raise ValueError(
                f"my_shard_id ({self.my_shard_id}) must be < total_shards ({self.total_shards})"
            )


def load_shard_config_from_env() -> ShardConfig | None:
    """Read GTV_TOTAL_SHARDS + GTV_SHARD_ID from environment.

    Returns None if either unset. Raises ValueError if my_shard_id >= total_shards.
    """
    total_shards_str = os.environ.get("GTV_TOTAL_SHARDS")
    my_shard_id_str = os.environ.get("GTV_SHARD_ID")

    if total_shards_str is None or my_shard_id_str is None:
        return None

    total_shards = int(total_shards_str)
    my_shard_id = int(my_shard_id_str)

    return ShardConfig(total_shards=total_shards, my_shard_id=my_shard_id)


def shard_for_claim(claim_id: str, source_did: str, total_shards: int) -> int:
    """Consistent hash: sha256(claim_id | source_did) mod total_shards.

    Every worker agrees on ownership given the same inputs.
    """
    key = f"{claim_id}|{source_did}"
    digest = hashlib.sha256(key.encode()).hexdigest()
    # Convert first 8 hex chars to int for uniform distribution
    hash_int = int(digest[:8], 16)
    return hash_int % total_shards


def owns(claim_id: str, source_did: str, cfg: ShardConfig) -> bool:
    """True iff this worker owns the (claim_id, source_did) pair."""
    shard = shard_for_claim(claim_id, source_did, cfg.total_shards)
    return shard == cfg.my_shard_id


def _parse_shard_peers() -> dict[int, str]:
    """Parse GTV_SHARD_PEERS=0=http://w0:8080,1=http://w1:8080,...

    Returns a dict mapping shard_id -> peer_url.
    Empty dict if env var unset.
    """
    peers_str = os.environ.get("GTV_SHARD_PEERS", "")
    if not peers_str:
        return {}

    peers = {}
    for pair in peers_str.split(","):
        pair = pair.strip()
        if not pair:
            continue
        try:
            shard_id_str, url = pair.split("=", 1)
            shard_id = int(shard_id_str)
            peers[shard_id] = url
        except ValueError:
            logger.warning(f"Ignoring malformed peer spec: {pair}")

    return peers


async def _forward_to_shard(
    peer_url: str,
    client: httpx.AsyncClient,
    claim_id: str,
    claim_text: str,
    domain: str,
    source_did: str,
    max_items: int,
) -> list[Evidence]:
    """Forward query to owning shard; return parsed Evidence list.

    On HTTP error, return empty list (fallback to local execution with warning).
    No retries (circuit breaker handles that upstream).
    """
    try:
        url = f"{peer_url}/internal/adapter/{source_did}/query"
        payload = {
            "claim_id": claim_id,
            "claim_text": claim_text,
            "domain": domain,
            "max_items": max_items,
        }
        resp = await client.post(url, json=payload, timeout=10.0)
        resp.raise_for_status()
        data = resp.json()
        # Parse list of dicts as Evidence
        return [Evidence.model_validate(d) for d in data]
    except Exception as e:
        logger.warning(
            f"Forward to {peer_url} failed: {e}. Falling back to local execution."
        )
        return []


class ShardedAdapter(SourceAdapter):
    """Wraps a SourceAdapter with consistent-hash sharding routing.

    If this worker owns (claim_id, source_did), delegates to inner adapter.
    Otherwise, forwards via HTTP to the owning worker. On forwarding failure,
    falls back to local execution with warning log.

    Attributes like health(), snapshot(), close() pass through to inner.
    """

    def __init__(
        self,
        inner: SourceAdapter,
        cfg: ShardConfig,
        client: httpx.AsyncClient | None = None,
    ) -> None:
        self._inner = inner
        self._cfg = cfg
        self._client = client or httpx.AsyncClient()
        self._peer_urls = _parse_shard_peers()

        # Mirror the wrapped adapter's identity.
        self.source_did = inner.source_did
        self.name = inner.name
        self.trust_tier = inner.trust_tier
        self.freshness_sla_s = inner.freshness_sla_s
        self.source_type = inner.source_type

    async def query(self, claim: Claim, max_items: int = 5) -> list[Evidence]:
        """Route to owning shard, or local if owned or forwarding fails."""
        if owns(claim.claim_id, self.source_did, self._cfg):
            # This worker owns it
            return await self._inner.query(claim, max_items=max_items)

        # Forward to owner
        target_shard = shard_for_claim(
            claim.claim_id, self.source_did, self._cfg.total_shards
        )
        peer_url = self._peer_urls.get(target_shard)

        if not peer_url:
            # Missing peer URL; fall back to local
            logger.warning(
                f"No peer URL for shard {target_shard}. Falling back to local execution."
            )
            return await self._inner.query(claim, max_items=max_items)

        result = await _forward_to_shard(
            peer_url,
            self._client,
            claim.claim_id,
            claim.text,
            str(claim.domain),
            self.source_did,
            max_items,
        )

        # If forward returned empty, fall back to local
        if not result:
            return await self._inner.query(claim, max_items=max_items)

        return result

    async def snapshot(self, url: str) -> RawSnapshot:
        """Pass through to inner; no sharding."""
        return await self._inner.snapshot(url)

    async def health(self) -> HealthStatus:
        """Pass through to inner."""
        return await self._inner.health()

    async def close(self) -> None:
        """Close inner and HTTP client."""
        await self._inner.close()
        await self._client.aclose()
