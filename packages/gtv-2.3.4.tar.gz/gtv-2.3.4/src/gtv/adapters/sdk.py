# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Public SDK for writing out-of-tree gtv source adapters.

Before this module existed, shipping a new adapter meant opening a PR
against ``src/gtv/adapters/`` and waiting for it to land in a release.
With the SDK, third parties can ship an adapter as an independent PyPI
package: declare an entry point in ``[project.entry-points."gtv.adapters"]``,
install it alongside gtv, and the server picks it up at startup.

This module is the **only** import path third-party adapters should
depend on. Everything in ``gtv.adapters.base``, ``gtv.models``, etc.
is considered internal and may move in a minor release. The SDK
surface is frozen across minor releases inside a major.

Typical external adapter skeleton::

    # my_adapter/__init__.py
    from gtv.adapters.sdk import (
        SourceAdapter, RawSnapshot, HealthStatus, TrustTier,
        SourceType, Stance, Claim, Evidence,
    )

    class MyAdapter(SourceAdapter):
        source_did = "did:web:my-source.example"
        name = "MySource"
        trust_tier = TrustTier.TIER_2
        freshness_sla_s = 3600

        async def query(self, claim, max_items=5): ...
        async def snapshot(self, url): ...
        async def health(self): ...
        async def close(self): ...

    # pyproject.toml
    # [project.entry-points."gtv.adapters"]
    # my-source = "my_adapter:MyAdapter"

The conformance suite (``gtv.adapters.conformance``) is the contract.
If your adapter passes ``run_adapter_conformance(MyAdapter())``, it's
safe to register.
"""

from __future__ import annotations

from gtv.adapters.base import RawSnapshot, SourceAdapter
from gtv.models import (
    Claim,
    Domain,
    Evidence,
    HealthStatus,
    SourceType,
    Stance,
    TrustTier,
)

# Re-exports (public SDK surface).
__all__ = [
    "Claim",
    "Domain",
    "Evidence",
    "HealthStatus",
    "RawSnapshot",
    "SourceAdapter",
    "SourceType",
    "Stance",
    "TrustTier",
    "register_adapter",
]

# Stable entry point group name. Third-party adapter packages declare
# themselves under ``[project.entry-points."gtv.adapters"]``.
ENTRY_POINT_GROUP = "gtv.adapters"


def register_adapter(adapter: SourceAdapter) -> None:
    """Register an adapter with the process-wide registry.

    This is a stable alias for the internal ``gtv.adapters.register``
    function. External adapters should prefer declaring an entry point
    so they're picked up automatically; use ``register_adapter`` only
    for in-process wiring (tests, embedded deployments).
    """
    # Deferred import — avoids a circular import through __init__.py which
    # itself calls discovery at module-load time.
    from gtv.adapters import register

    register(adapter)
