# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""arXiv preprint adapter — query and snapshot integration."""
from __future__ import annotations

# Use defusedxml instead of stdlib xml.etree to protect against XXE,
# billion-laughs, and external-entity-expansion attacks on the arXiv
# response. arXiv is Tier 2 (not the highest trust); a MITM or compromised
# endpoint could feed us malicious XML.
from datetime import UTC, datetime

import defusedxml.ElementTree as ET  # noqa: N817 — keep stdlib-style alias
import httpx
from pydantic import HttpUrl

from gtv.adapters.base import RawSnapshot, SourceAdapter
from gtv.adapters.parse import claim_to_query
from gtv.adapters.snapshot import InMemorySnapshotStore, SnapshotStore
from gtv.models import Claim, Evidence, HealthStatus, SourceType, Stance, TrustTier


class ArxivAdapter(SourceAdapter):
    """Fetch and verify evidence from arXiv preprints."""

    source_did = "did:web:arxiv.org"
    name = "arXiv"
    source_type = SourceType.PREPRINT
    trust_tier = TrustTier.TIER_2
    freshness_sla_s = 5

    def __init__(
        self,
        client: httpx.AsyncClient | None = None,
        snapshot_store: SnapshotStore | None = None,
    ) -> None:
        """Initialize the arXiv adapter.

        Args:
            client: AsyncClient with custom timeout (default: 5s).
            snapshot_store: SnapshotStore for content-addressing (default: InMemory).
        """
        self._client = client or httpx.AsyncClient(timeout=5.0)
        self._snapshot_store = snapshot_store or InMemorySnapshotStore()
        self._owns_client = client is None  # track if we created it (for cleanup)

    async def query(self, claim: Claim, max_items: int = 5) -> list[Evidence]:
        """Query arXiv for papers relevant to the claim.

        Args:
            claim: The Claim to search for.
            max_items: Max results to return (default 5).

        Returns:
            A list of Evidence records, one per matching paper.

        Raises:
            httpx.TimeoutException, httpx.NetworkError: On network failure.
        """
        # Extract search query from claim text.
        query_str = claim_to_query(claim.text)
        if not query_str:
            return []

        # Call arXiv API.
        url = "https://export.arxiv.org/api/query"
        params: dict[str, str | int] = {
            "search_query": f"all:{query_str}",
            "max_results": max_items,
        }

        try:
            response = await self._client.get(url, params=params)
            response.raise_for_status()
        except httpx.TimeoutException:
            raise
        except httpx.NetworkError:
            raise
        except httpx.HTTPStatusError:
            raise

        # Parse Atom XML response.
        try:
            root = ET.fromstring(response.content)
        except ET.ParseError as e:
            raise ValueError(f"Failed to parse arXiv API response: {e}") from e

        # arXiv API response uses Atom namespace.
        ns = {"atom": "http://www.w3.org/2005/Atom"}

        # Extract entries.
        evidence_list: list[Evidence] = []
        for entry_elem in root.findall("atom:entry", ns):
            # Extract fields from XML.
            id_elem = entry_elem.find("atom:id", ns)
            summary_elem = entry_elem.find("atom:summary", ns)

            if id_elem is None or id_elem.text is None:
                continue

            # The id is a URL like "http://arxiv.org/abs/2401.12345v1".
            entry_id = id_elem.text.strip()

            summary = (summary_elem.text or "") if summary_elem is not None else ""
            summary = summary.strip()

            # Trim excerpt to 1200 chars max.
            excerpt = summary if len(summary) <= 1200 else summary[:1200]

            # Store summary in snapshot store to get raw_hash.
            summary_bytes = summary.encode("utf-8")
            raw_hash = await self._snapshot_store.put(entry_id, summary_bytes)

            # Build Evidence record.
            evidence = Evidence(
                claim_id=claim.claim_id,
                source_did=self.source_did,
                source_version="arxiv-api-v1",
                stance=Stance.NEUTRAL,
                excerpt=excerpt,
                url=HttpUrl(entry_id),
                retrieved_at=datetime.now(tz=UTC),
                raw_hash=raw_hash,
            )
            evidence_list.append(evidence)

        return evidence_list

    async def snapshot(self, url: str) -> RawSnapshot:
        """Fetch and hash a single arXiv abstract page.

        Args:
            url: The arXiv URL (usually an abs/ or pdf/ URL).

        Returns:
            A RawSnapshot with content and computed hash.

        Raises:
            httpx.TimeoutException, httpx.NetworkError, httpx.HTTPStatusError:
                On network or HTTP errors.
        """
        response = await self._client.get(url)
        response.raise_for_status()

        return RawSnapshot(
            url=url,
            content=response.content,
            retrieved_at_iso=datetime.now(tz=UTC).isoformat(),
        )

    async def health(self) -> HealthStatus:
        """Check arXiv API health.

        HEAD a minimal query with a 3s timeout.

        Returns:
            HealthStatus with state and detail message.
        """
        try:
            response = await self._client.head(
                "https://export.arxiv.org/api/query",
                params={"search_query": "all:test", "max_results": "1"},
                timeout=3.0,
            )
            if response.status_code in (200, 301, 302, 304):
                return HealthStatus(state="HEALTHY", detail="arXiv API responsive")
            else:
                return HealthStatus(
                    state="DEGRADED",
                    detail=f"arXiv API returned {response.status_code}",
                )
        except httpx.TimeoutException:
            return HealthStatus(state="DOWN", detail="arXiv API timeout (>3s)")
        except httpx.NetworkError as e:
            return HealthStatus(state="DOWN", detail=f"Network error: {e}")

    async def close(self) -> None:
        """Close the httpx client if we own it."""
        if self._owns_client:
            await self._client.aclose()
