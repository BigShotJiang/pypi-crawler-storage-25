# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""OpenAlex adapter — query and snapshot integration for scholarly metadata.

OpenAlex is a comprehensive aggregator of scholarly metadata covering
preprints, peer-reviewed papers, and reference data across all domains.
"""
from __future__ import annotations

import json
import os
from datetime import UTC, datetime

import httpx
from pydantic import HttpUrl

from gtv.adapters.base import RawSnapshot, SourceAdapter
from gtv.adapters.parse import claim_to_query
from gtv.adapters.snapshot import InMemorySnapshotStore, SnapshotStore
from gtv.models import Claim, Evidence, HealthStatus, SourceType, Stance, TrustTier


def _reconstruct_abstract(inverted_index: dict[str, list[int]] | None) -> str:
    """Reconstruct prose abstract from OpenAlex inverted index.

    OpenAlex abstracts are stored as inverted indexes:
    {"word": [position1, position2, ...], ...}

    We invert this to reconstruct the original order.

    Args:
        inverted_index: The abstract_inverted_index dict from OpenAlex.

    Returns:
        Reconstructed abstract as a string, or empty string if invalid.
    """
    if not inverted_index or not isinstance(inverted_index, dict):
        return ""

    # Build position -> word map.
    position_map: dict[int, str] = {}
    for word, positions in inverted_index.items():
        if isinstance(positions, list):
            for pos in positions:
                if isinstance(pos, int):
                    position_map[pos] = word

    if not position_map:
        return ""

    # Reconstruct by sorting positions and joining words.
    sorted_positions = sorted(position_map.keys())
    words = [position_map[pos] for pos in sorted_positions]
    return " ".join(words)


class OpenAlexAdapter(SourceAdapter):
    """Fetch and verify evidence from OpenAlex scholarly metadata."""

    source_did = "did:web:api.openalex.org"
    name = "OpenAlex"
    source_type = SourceType.REFERENCE_DATA
    trust_tier = TrustTier.TIER_2
    freshness_sla_s = 5

    def __init__(
        self,
        client: httpx.AsyncClient | None = None,
        snapshot_store: SnapshotStore | None = None,
    ) -> None:
        """Initialize the OpenAlex adapter.

        Args:
            client: AsyncClient with custom timeout (default: 5s).
            snapshot_store: SnapshotStore for content-addressing (default: InMemory).
        """
        self._client = client or httpx.AsyncClient(timeout=5.0)
        self._snapshot_store = snapshot_store or InMemorySnapshotStore()
        self._owns_client = client is None  # track if we created it (for cleanup)
        # Polite pool email: use env var or default.
        self._email = os.getenv(
            "GTV_OPENALEX_EMAIL", "gtv-polite@example.invalid"
        )

    async def query(self, claim: Claim, max_items: int = 5) -> list[Evidence]:
        """Query OpenAlex for works relevant to the claim.

        Args:
            claim: The Claim to search for.
            max_items: Max results to return (default 5).

        Returns:
            A list of Evidence records, one per matching work.

        Raises:
            httpx.TimeoutException, httpx.NetworkError: On network failure.
        """
        # Extract search query from claim text.
        query_str = claim_to_query(claim.text)
        if not query_str:
            return []

        # Call OpenAlex API with polite pool email.
        url = "https://api.openalex.org/works"
        params: dict[str, str | int] = {
            "search": query_str,
            "per_page": max_items,
            "mailto": self._email,
        }

        try:
            response = await self._client.get(url, params=params)
            response.raise_for_status()
        except httpx.TimeoutException:
            raise
        except httpx.NetworkError:
            raise
        except httpx.HTTPStatusError:
            raise

        # Parse JSON response.
        try:
            data = response.json()
        except json.JSONDecodeError as e:
            raise ValueError(f"Failed to parse OpenAlex API response: {e}") from e

        # Extract entries from results.
        evidence_list: list[Evidence] = []
        results = data.get("results", [])

        for result in results:
            # Extract ID: OpenAlex uses https://openalex.org/W...
            openalex_id = result.get("id")
            if not openalex_id:
                continue

            # Build excerpt: prefer abstract, fallback to title.
            excerpt = ""
            abstract_inverted = result.get("abstract_inverted_index")
            if abstract_inverted:
                excerpt = _reconstruct_abstract(abstract_inverted)

            if not excerpt:
                # Fallback to title.
                title = result.get("title")
                if title:
                    excerpt = title.strip()

            excerpt = excerpt if len(excerpt) <= 1200 else excerpt[:1200]

            # Store in snapshot store to get raw_hash.
            excerpt_bytes = excerpt.encode("utf-8")
            raw_hash = await self._snapshot_store.put(openalex_id, excerpt_bytes)

            # Build Evidence record.
            evidence = Evidence(
                claim_id=claim.claim_id,
                source_did=self.source_did,
                source_version="openalex-api-v1",
                stance=Stance.NEUTRAL,
                excerpt=excerpt,
                url=HttpUrl(openalex_id),
                retrieved_at=datetime.now(tz=UTC),
                raw_hash=raw_hash,
            )
            evidence_list.append(evidence)

        return evidence_list

    async def snapshot(self, url: str) -> RawSnapshot:
        """Fetch and hash a single OpenAlex work page.

        Args:
            url: The OpenAlex URL.

        Returns:
            A RawSnapshot with content and computed hash.

        Raises:
            httpx.TimeoutException, httpx.NetworkError, httpx.HTTPStatusError:
                On network or HTTP errors.
        """
        response = await self._client.get(url)
        response.raise_for_status()

        return RawSnapshot(
            url=url,
            content=response.content,
            retrieved_at_iso=datetime.now(tz=UTC).isoformat(),
        )

    async def health(self) -> HealthStatus:
        """Check OpenAlex API health.

        GET a minimal query with a 3s timeout.

        Returns:
            HealthStatus with state and detail message.
        """
        try:
            response = await self._client.get(
                "https://api.openalex.org/works",
                params={"search": "test", "per_page": "1", "mailto": self._email},
                timeout=3.0,
            )
            if response.status_code in (200, 301, 302, 304):
                return HealthStatus(state="HEALTHY", detail="OpenAlex API responsive")
            else:
                return HealthStatus(
                    state="DEGRADED",
                    detail=f"OpenAlex API returned {response.status_code}",
                )
        except httpx.TimeoutException:
            return HealthStatus(state="DOWN", detail="OpenAlex API timeout (>3s)")
        except httpx.NetworkError as e:
            return HealthStatus(state="DOWN", detail=f"Network error: {e}")

    async def close(self) -> None:
        """Close the httpx client if we own it."""
        if self._owns_client:
            await self._client.aclose()
