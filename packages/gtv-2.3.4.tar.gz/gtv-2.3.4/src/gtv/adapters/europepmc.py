# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Europe PMC adapter — EMBL-EBI life-sciences literature search.

Europe PMC is the European life sciences literature search service operated
by EMBL-EBI. It aggregates peer-reviewed biomedical and life sciences
articles from PubMed Central and other curated sources.

API: https://www.ebi.ac.uk/europepmc/webservices/rest/search
No API key required. Respects rate limits.
"""
from __future__ import annotations

import asyncio
import hashlib
import logging
import os
from datetime import UTC, datetime

import httpx
from pydantic import HttpUrl

from gtv.adapters.base import RawSnapshot, SourceAdapter
from gtv.adapters.parse import claim_to_query
from gtv.models import Claim, Evidence, HealthStatus, SourceType, Stance, TrustTier

logger = logging.getLogger(__name__)


class EuropePMCAdapter(SourceAdapter):
    """Europe PMC literature evidence via the public REST search API."""

    source_did = "did:web:europepmc.org"
    name = "EuropePMC"
    source_type = SourceType.PEER_REVIEWED
    trust_tier = TrustTier.TIER_1
    freshness_sla_s = 10

    _BASE = "https://www.ebi.ac.uk/europepmc/webservices/rest/search"
    # Rate limit: 1 req/sec is conservative for a free service.
    _RATE_LIMIT_DELAY = 1.0

    def __init__(self, client: httpx.AsyncClient | None = None) -> None:
        self._client = client or httpx.AsyncClient(
            timeout=10.0,
            headers={"Accept": "application/json"},
        )
        self._owns_client = client is None
        self._last_request_time = 0.0

    async def _rate_limit(self) -> None:
        now = asyncio.get_event_loop().time()
        elapsed = now - self._last_request_time
        if elapsed < self._RATE_LIMIT_DELAY:
            await asyncio.sleep(self._RATE_LIMIT_DELAY - elapsed)
        self._last_request_time = asyncio.get_event_loop().time()

    async def query(self, claim: Claim, max_items: int = 5) -> list[Evidence]:
        """Search Europe PMC for articles matching keywords in the claim.

        Returns SUPPORTS stance if at least 50% of claim keywords are found
        in the title/abstract. Otherwise NEUTRAL.
        """
        # Check if adapter is disabled via environment variable.
        if os.getenv("GTV_EUROPEPMC_DISABLE"):
            return []

        query_str = claim_to_query(claim.text)
        if not query_str:
            return []

        await self._rate_limit()
        params: dict[str, str | int] = {
            "query": query_str,
            "format": "json",
            "resultType": "lite",
            "pageSize": max_items,
        }
        try:
            response = await self._client.get(self._BASE, params=params)
            response.raise_for_status()
        except (httpx.TimeoutException, httpx.NetworkError, httpx.HTTPStatusError):
            raise

        try:
            payload = response.json()
        except ValueError as e:
            raise ValueError(f"Failed to parse Europe PMC response: {e}") from e

        results = payload.get("resultList", {}).get("result", []) or []
        evidence_list: list[Evidence] = []

        for item in results[:max_items]:
            item_id = item.get("id")
            source = item.get("source")  # e.g., "MED"
            title = (item.get("title") or "").strip()
            abstract = (item.get("abstractText") or "").strip()
            pub_year = item.get("pubYear") or ""

            if not item_id or not title:
                continue

            # Build excerpt from title, abstract, and year.
            excerpt = f"{title}."
            if abstract:
                excerpt += f" {abstract}"
            if pub_year:
                excerpt += f" (Published {pub_year})"

            if len(excerpt) > 1200:
                excerpt = excerpt[:1200]

            raw_hash = hashlib.sha256(excerpt.encode("utf-8")).hexdigest()

            # Build URL based on source.
            if source and source.upper() == "MED":
                url = HttpUrl(f"https://europepmc.org/article/MED/{item_id}")
            else:
                url = HttpUrl(
                    f"https://europepmc.org/abstract/{source or 'UNKNOWN'}/{item_id}"
                )

            # Detect stance using keyword heuristic.
            stance = self._detect_stance(claim.text, title, abstract)

            evidence_list.append(
                Evidence(
                    claim_id=claim.claim_id,
                    source_did=self.source_did,
                    source_version="europepmc-rest-v1",
                    stance=stance,
                    excerpt=excerpt,
                    url=url,
                    retrieved_at=datetime.now(tz=UTC),
                    raw_hash=raw_hash,
                )
            )

        return evidence_list

    def _detect_stance(self, claim_text: str, title: str, abstract: str) -> Stance:
        """Simple heuristic for stance detection.

        If the title or abstract contains at least 50% of claim keywords,
        assume SUPPORTS. Otherwise NEUTRAL.
        """
        claim_words = {w.lower() for w in claim_to_query(claim_text).split() if w}
        if not claim_words:
            return Stance.NEUTRAL

        text_to_search = f"{title} {abstract}".lower()
        matches = sum(1 for w in claim_words if w in text_to_search)

        if matches >= len(claim_words) * 0.5:
            return Stance.SUPPORTS

        return Stance.NEUTRAL

    async def snapshot(self, url: str) -> RawSnapshot:
        """Fetch and hash a single Europe PMC article page."""
        response = await self._client.get(url)
        response.raise_for_status()

        return RawSnapshot(
            url=url,
            content=response.content,
            retrieved_at_iso=datetime.now(tz=UTC).isoformat(),
        )

    async def health(self) -> HealthStatus:
        try:
            await self._rate_limit()
            response = await self._client.get(
                self._BASE,
                params={
                    "query": "test",
                    "format": "json",
                    "resultType": "lite",
                    "pageSize": "1",
                },
                timeout=3.0,
            )
            if 200 <= response.status_code < 400:
                return HealthStatus(
                    state="HEALTHY", detail="Europe PMC responsive"
                )
            return HealthStatus(
                state="DEGRADED",
                detail=f"Europe PMC returned {response.status_code}",
            )
        except httpx.TimeoutException:
            return HealthStatus(state="DOWN", detail="Europe PMC timeout (>3s)")
        except httpx.NetworkError as e:
            return HealthStatus(state="DOWN", detail=f"Network error: {e}")

    async def close(self) -> None:
        if self._owns_client:
            await self._client.aclose()
