# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""DailyMed adapter — FDA-approved drug labels (SPL / Structured Product Labeling).

DailyMed is the NLM/NIH public repository of FDA-approved drug package
inserts. It's the authoritative source for "what does the FDA actually
say about this drug" — indications, dosage, warnings, interactions.

A gtv verify for a pharma claim (e.g. "Drug X is indicated for
condition Y") is well-served by a DailyMed label hit: it's first-party,
versioned, and signed off by the manufacturer under FDA oversight.

API: https://dailymed.nlm.nih.gov/dailymed/services/v2/spls.json
No API key required. Conservative rate limit (1 req/sec) because the
service is free and operated by NLM.
"""
from __future__ import annotations

import asyncio
import hashlib
import logging
from datetime import UTC, datetime

import httpx
from pydantic import HttpUrl

from gtv.adapters.base import RawSnapshot, SourceAdapter
from gtv.adapters.parse import claim_to_query
from gtv.models import Claim, Evidence, HealthStatus, SourceType, Stance, TrustTier

logger = logging.getLogger(__name__)


class DailyMedAdapter(SourceAdapter):
    """FDA-approved drug label evidence via DailyMed's public v2 API."""

    source_did = "did:web:dailymed.nlm.nih.gov"
    name = "DailyMed"
    source_type = SourceType.GOVT_OPEN_DATA
    trust_tier = TrustTier.TIER_1
    freshness_sla_s = 10

    _BASE = "https://dailymed.nlm.nih.gov/dailymed/services/v2"
    # NLM asks callers to be gentle — 1 req/sec is well under any published ceiling.
    _RATE_LIMIT_DELAY = 1.0

    def __init__(self, client: httpx.AsyncClient | None = None) -> None:
        self._client = client or httpx.AsyncClient(
            timeout=10.0,
            headers={"Accept": "application/json"},
        )
        self._owns_client = client is None
        self._last_request_time = 0.0

    async def _rate_limit(self) -> None:
        now = asyncio.get_event_loop().time()
        elapsed = now - self._last_request_time
        if elapsed < self._RATE_LIMIT_DELAY:
            await asyncio.sleep(self._RATE_LIMIT_DELAY - elapsed)
        self._last_request_time = asyncio.get_event_loop().time()

    async def query(self, claim: Claim, max_items: int = 5) -> list[Evidence]:
        """Search DailyMed for SPL records matching keywords in the claim.

        Labels are reference data — stance is NEUTRAL by default. The
        verdict engine will treat label presence as confirming the
        drug exists and its approved indications, nothing more.
        """
        query_str = claim_to_query(claim.text)
        if not query_str:
            return []

        await self._rate_limit()
        params: dict[str, str | int] = {
            "drug_name": query_str,
            "pagesize": max_items,
            "page": 1,
        }
        try:
            response = await self._client.get(
                f"{self._BASE}/spls.json", params=params
            )
            response.raise_for_status()
        except (httpx.TimeoutException, httpx.NetworkError, httpx.HTTPStatusError):
            raise

        try:
            payload = response.json()
        except ValueError as e:
            raise ValueError(f"Failed to parse DailyMed response: {e}") from e

        items = payload.get("data", []) or []
        evidence_list: list[Evidence] = []
        for item in items[:max_items]:
            setid = item.get("setid")
            title = (item.get("title") or "").strip()
            published = item.get("published_date") or ""
            spl_version = item.get("spl_version") or ""
            if not setid or not title:
                continue

            excerpt = (
                f"{title}. Published {published} (SPL v{spl_version})."
                if published
                else title
            )
            if len(excerpt) > 1200:
                excerpt = excerpt[:1200]

            raw_hash = hashlib.sha256(excerpt.encode("utf-8")).hexdigest()
            url = HttpUrl(
                f"https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid={setid}"
            )
            evidence_list.append(
                Evidence(
                    claim_id=claim.claim_id,
                    source_did=self.source_did,
                    source_version="dailymed-v2",
                    stance=Stance.NEUTRAL,
                    excerpt=excerpt,
                    url=url,
                    retrieved_at=datetime.now(tz=UTC),
                    raw_hash=raw_hash,
                )
            )

        return evidence_list

    async def snapshot(self, url: str) -> RawSnapshot:
        """Fetch the raw drug-info HTML (or JSON endpoint) for audit."""
        response = await self._client.get(url)
        response.raise_for_status()
        return RawSnapshot(
            url=url,
            content=response.content,
            retrieved_at_iso=datetime.now(tz=UTC).isoformat(),
        )

    async def health(self) -> HealthStatus:
        try:
            await self._rate_limit()
            response = await self._client.get(
                f"{self._BASE}/spls.json",
                params={"drug_name": "aspirin", "pagesize": 1},
                timeout=3.0,
            )
            if 200 <= response.status_code < 400:
                return HealthStatus(state="HEALTHY", detail="DailyMed v2 responsive")
            return HealthStatus(
                state="DEGRADED", detail=f"DailyMed v2 returned {response.status_code}"
            )
        except httpx.TimeoutException:
            return HealthStatus(state="DOWN", detail="DailyMed v2 timeout (>3s)")
        except httpx.NetworkError as e:
            return HealthStatus(state="DOWN", detail=f"Network error: {e}")

    async def close(self) -> None:
        if self._owns_client:
            await self._client.aclose()
