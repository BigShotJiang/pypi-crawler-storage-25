# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""INSPIRE-HEP adapter — query and snapshot integration for peer-reviewed physics literature."""
from __future__ import annotations

import json
from datetime import UTC, datetime

import httpx
from pydantic import HttpUrl

from gtv.adapters.base import RawSnapshot, SourceAdapter
from gtv.adapters.parse import claim_to_query
from gtv.adapters.snapshot import InMemorySnapshotStore, SnapshotStore
from gtv.models import Claim, Evidence, HealthStatus, SourceType, Stance, TrustTier


class InspireHepAdapter(SourceAdapter):
    """Fetch and verify evidence from INSPIRE-HEP physics literature database."""

    source_did = "did:web:inspirehep.net"
    name = "INSPIRE-HEP"
    source_type = SourceType.PEER_REVIEWED
    trust_tier = TrustTier.TIER_1
    freshness_sla_s = 5

    def __init__(
        self,
        client: httpx.AsyncClient | None = None,
        snapshot_store: SnapshotStore | None = None,
    ) -> None:
        """Initialize the INSPIRE-HEP adapter.

        Args:
            client: AsyncClient with custom timeout (default: 5s).
            snapshot_store: SnapshotStore for content-addressing (default: InMemory).
        """
        self._client = client or httpx.AsyncClient(timeout=5.0)
        self._snapshot_store = snapshot_store or InMemorySnapshotStore()
        self._owns_client = client is None  # track if we created it (for cleanup)

    async def query(self, claim: Claim, max_items: int = 5) -> list[Evidence]:
        """Query INSPIRE-HEP for papers relevant to the claim.

        Args:
            claim: The Claim to search for.
            max_items: Max results to return (default 5).

        Returns:
            A list of Evidence records, one per matching paper.

        Raises:
            httpx.TimeoutException, httpx.NetworkError: On network failure.
        """
        # Extract search query from claim text.
        query_str = claim_to_query(claim.text)
        if not query_str:
            return []

        # Call INSPIRE-HEP API.
        url = "https://inspirehep.net/api/literature"
        params: dict[str, str | int] = {
            "q": query_str,
            "fields": "titles,abstracts,arxiv_eprints,dois,control_number",
            "size": max_items,
        }

        try:
            response = await self._client.get(url, params=params)
            response.raise_for_status()
        except httpx.TimeoutException:
            raise
        except httpx.NetworkError:
            raise
        except httpx.HTTPStatusError:
            raise

        # Parse JSON response.
        try:
            data = response.json()
        except json.JSONDecodeError as e:
            raise ValueError(f"Failed to parse INSPIRE-HEP API response: {e}") from e

        # Extract entries from hits.
        evidence_list: list[Evidence] = []
        hits = data.get("hits", {}).get("hits", [])

        for hit in hits:
            metadata = hit.get("metadata", {})

            # Extract ID: prefer control_number, fallback to id from _ui
            record_id = metadata.get("control_number") or hit.get("id")
            if not record_id:
                continue

            # Build URL.
            url_str = f"https://inspirehep.net/literature/{record_id}"

            # Extract excerpt: first abstract's value, trimmed to 1200 chars.
            abstracts = metadata.get("abstracts", [])
            excerpt = ""
            if abstracts and isinstance(abstracts, list):
                first_abstract = abstracts[0]
                if isinstance(first_abstract, dict):
                    excerpt = first_abstract.get("value", "").strip()
            if not excerpt:
                # Fallback to title if no abstract.
                titles = metadata.get("titles", [])
                if titles and isinstance(titles, list):
                    first_title = titles[0]
                    if isinstance(first_title, dict):
                        excerpt = first_title.get("title", "").strip()

            excerpt = excerpt if len(excerpt) <= 1200 else excerpt[:1200]

            # Store in snapshot store to get raw_hash.
            excerpt_bytes = excerpt.encode("utf-8")
            raw_hash = await self._snapshot_store.put(url_str, excerpt_bytes)

            # Build Evidence record.
            evidence = Evidence(
                claim_id=claim.claim_id,
                source_did=self.source_did,
                source_version="inspire-api-v1",
                stance=Stance.NEUTRAL,
                excerpt=excerpt,
                url=HttpUrl(url_str),
                retrieved_at=datetime.now(tz=UTC),
                raw_hash=raw_hash,
            )
            evidence_list.append(evidence)

        return evidence_list

    async def snapshot(self, url: str) -> RawSnapshot:
        """Fetch and hash a single INSPIRE-HEP literature page.

        Args:
            url: The INSPIRE-HEP URL.

        Returns:
            A RawSnapshot with content and computed hash.

        Raises:
            httpx.TimeoutException, httpx.NetworkError, httpx.HTTPStatusError:
                On network or HTTP errors.
        """
        response = await self._client.get(url)
        response.raise_for_status()

        return RawSnapshot(
            url=url,
            content=response.content,
            retrieved_at_iso=datetime.now(tz=UTC).isoformat(),
        )

    async def health(self) -> HealthStatus:
        """Check INSPIRE-HEP API health.

        HEAD a minimal query with a 3s timeout.

        Returns:
            HealthStatus with state and detail message.
        """
        try:
            response = await self._client.get(
                "https://inspirehep.net/api/literature",
                params={"q": "test", "size": "1"},
                timeout=3.0,
            )
            if response.status_code in (200, 301, 302, 304):
                return HealthStatus(state="HEALTHY", detail="INSPIRE-HEP API responsive")
            else:
                return HealthStatus(
                    state="DEGRADED",
                    detail=f"INSPIRE-HEP API returned {response.status_code}",
                )
        except httpx.TimeoutException:
            return HealthStatus(state="DOWN", detail="INSPIRE-HEP API timeout (>3s)")
        except httpx.NetworkError as e:
            return HealthStatus(state="DOWN", detail=f"Network error: {e}")

    async def close(self) -> None:
        """Close the httpx client if we own it."""
        if self._owns_client:
            await self._client.aclose()
