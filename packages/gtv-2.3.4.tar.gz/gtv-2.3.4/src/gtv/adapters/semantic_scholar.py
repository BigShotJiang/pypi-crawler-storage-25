# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Semantic Scholar adapter — query and snapshot integration.

Semantic Scholar provides a comprehensive index of academic papers across
multiple domains, with both preprint and peer-reviewed content.
"""
from __future__ import annotations

import json
import os
from datetime import UTC, datetime

import httpx
from pydantic import HttpUrl

from gtv.adapters.base import RawSnapshot, SourceAdapter
from gtv.adapters.parse import claim_to_query
from gtv.adapters.snapshot import InMemorySnapshotStore, SnapshotStore
from gtv.models import Claim, Evidence, HealthStatus, SourceType, Stance, TrustTier


class SemanticScholarAdapter(SourceAdapter):
    """Fetch and verify evidence from Semantic Scholar API."""

    source_did = "did:web:api.semanticscholar.org"
    name = "Semantic Scholar"
    source_type = SourceType.REFERENCE_DATA
    trust_tier = TrustTier.TIER_2
    freshness_sla_s = 5

    def __init__(
        self,
        client: httpx.AsyncClient | None = None,
        snapshot_store: SnapshotStore | None = None,
    ) -> None:
        """Initialize the Semantic Scholar adapter.

        Args:
            client: AsyncClient with custom timeout (default: 5s).
            snapshot_store: SnapshotStore for content-addressing (default: InMemory).
        """
        self._client = client or httpx.AsyncClient(timeout=5.0)
        self._snapshot_store = snapshot_store or InMemorySnapshotStore()
        self._owns_client = client is None  # track if we created it (for cleanup)
        # Optional API key for higher rate limits.
        self._api_key = os.getenv("GTV_S2_API_KEY")

    async def query(self, claim: Claim, max_items: int = 5) -> list[Evidence]:
        """Query Semantic Scholar for papers relevant to the claim.

        Args:
            claim: The Claim to search for.
            max_items: Max results to return (default 5).

        Returns:
            A list of Evidence records, one per matching paper.

        Raises:
            httpx.TimeoutException, httpx.NetworkError: On network failure.
            httpx.HTTPStatusError: On HTTP errors including 429 rate limits.
        """
        # Extract search query from claim text.
        query_str = claim_to_query(claim.text)
        if not query_str:
            return []

        # Call Semantic Scholar API.
        url = "https://api.semanticscholar.org/graph/v1/paper/search"
        params: dict[str, str | int] = {
            "query": query_str,
            "limit": max_items,
            "fields": "title,abstract,year,authors,externalIds",
        }
        headers = {}
        if self._api_key:
            headers["x-api-key"] = self._api_key

        try:
            response = await self._client.get(url, params=params, headers=headers)
            response.raise_for_status()
        except httpx.TimeoutException:
            raise
        except httpx.NetworkError:
            raise
        except httpx.HTTPStatusError:
            raise

        # Parse JSON response.
        try:
            data = response.json()
        except json.JSONDecodeError as e:
            raise ValueError(
                f"Failed to parse Semantic Scholar API response: {e}"
            ) from e

        # Extract entries from data.
        evidence_list: list[Evidence] = []
        papers = data.get("data", [])

        for paper in papers:
            # Extract paper ID from externalIds.
            external_ids = paper.get("externalIds", {})
            paper_id = external_ids.get("CorpusId")
            if not paper_id:
                # Fallback to DOI if available.
                doi = external_ids.get("DOI")
                if doi:
                    paper_id = doi
                else:
                    continue

            # Build URL using Semantic Scholar URL pattern.
            if str(paper_id).startswith("10."):  # DOI
                url_str = f"https://doi.org/{paper_id}"
            else:
                # Corpus ID
                url_str = f"https://www.semanticscholar.org/paper/{paper_id}"

            # Extract excerpt: prefer abstract, fallback to title.
            excerpt = ""
            abstract = paper.get("abstract")
            if abstract:
                excerpt = abstract.strip()

            if not excerpt:
                # Fallback to title.
                title = paper.get("title")
                if title:
                    excerpt = title.strip()

            excerpt = excerpt if len(excerpt) <= 1200 else excerpt[:1200]

            # Store in snapshot store to get raw_hash.
            excerpt_bytes = excerpt.encode("utf-8")
            raw_hash = await self._snapshot_store.put(url_str, excerpt_bytes)

            # Build Evidence record.
            evidence = Evidence(
                claim_id=claim.claim_id,
                source_did=self.source_did,
                source_version="s2-api-v1",
                stance=Stance.NEUTRAL,
                excerpt=excerpt,
                url=HttpUrl(url_str),
                retrieved_at=datetime.now(tz=UTC),
                raw_hash=raw_hash,
            )
            evidence_list.append(evidence)

        return evidence_list

    async def snapshot(self, url: str) -> RawSnapshot:
        """Fetch and hash a single Semantic Scholar paper page.

        Args:
            url: The Semantic Scholar or paper URL.

        Returns:
            A RawSnapshot with content and computed hash.

        Raises:
            httpx.TimeoutException, httpx.NetworkError, httpx.HTTPStatusError:
                On network or HTTP errors.
        """
        headers = {}
        if self._api_key:
            headers["x-api-key"] = self._api_key

        response = await self._client.get(url, headers=headers)
        response.raise_for_status()

        return RawSnapshot(
            url=url,
            content=response.content,
            retrieved_at_iso=datetime.now(tz=UTC).isoformat(),
        )

    async def health(self) -> HealthStatus:
        """Check Semantic Scholar API health.

        GET a minimal query with a 3s timeout.

        Returns:
            HealthStatus with state and detail message.
        """
        try:
            headers = {}
            if self._api_key:
                headers["x-api-key"] = self._api_key

            response = await self._client.get(
                "https://api.semanticscholar.org/graph/v1/paper/search",
                params={"query": "test", "limit": "1"},
                headers=headers,
                timeout=3.0,
            )
            if response.status_code in (200, 301, 302, 304):
                return HealthStatus(
                    state="HEALTHY", detail="Semantic Scholar API responsive"
                )
            else:
                return HealthStatus(
                    state="DEGRADED",
                    detail=f"Semantic Scholar API returned {response.status_code}",
                )
        except httpx.TimeoutException:
            return HealthStatus(
                state="DOWN", detail="Semantic Scholar API timeout (>3s)"
            )
        except httpx.NetworkError as e:
            return HealthStatus(state="DOWN", detail=f"Network error: {e}")

    async def close(self) -> None:
        """Close the httpx client if we own it."""
        if self._owns_client:
            await self._client.aclose()
