# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""NIST CODATA fundamental constants adapter — query and snapshot integration.

NIST provides authoritative physical measurement data via the CODATA
fundamental constants list. This adapter queries NIST fundamental constants
and returns evidence for numeric/physical claims with SUPPORTS or NEUTRAL stance.
"""
from __future__ import annotations

import asyncio
import hashlib
import logging
import re
from datetime import UTC, datetime

import httpx
from pydantic import HttpUrl

from gtv.adapters.base import RawSnapshot, SourceAdapter
from gtv.models import Claim, Evidence, HealthStatus, SourceType, Stance, TrustTier

logger = logging.getLogger(__name__)


class NISTAdapter(SourceAdapter):
    """Fetch and verify evidence from NIST fundamental constants."""

    source_did = "did:web:nist.gov"
    name = "NIST Fundamental Constants"
    source_type = SourceType.REFERENCE_DATA
    trust_tier = TrustTier.TIER_1
    freshness_sla_s = 10

    # NIST constants endpoint: conservative 1 req/sec
    _RATE_LIMIT_DELAY = 1.0

    def __init__(
        self,
        client: httpx.AsyncClient | None = None,
    ) -> None:
        """Initialize the NIST adapter.

        Args:
            client: AsyncClient with custom timeout (default: 10s).
        """
        self._client = client or httpx.AsyncClient(timeout=10.0)
        self._owns_client = client is None
        self._last_request_time = 0.0
        self._constants_cache: dict[str, str] | None = None

    async def _rate_limit(self) -> None:
        """Enforce rate limit between requests."""
        now = asyncio.get_event_loop().time()
        elapsed = now - self._last_request_time
        if elapsed < self._RATE_LIMIT_DELAY:
            await asyncio.sleep(self._RATE_LIMIT_DELAY - elapsed)
        self._last_request_time = asyncio.get_event_loop().time()

    async def _fetch_constants(self) -> dict[str, str]:
        """Fetch NIST CODATA constants list and parse it.

        Returns a dict mapping constant names to their values with uncertainty.
        """
        if self._constants_cache is not None:
            return self._constants_cache

        await self._rate_limit()
        url = "https://physics.nist.gov/cgi-bin/cuu/Constants/Table/allascii.txt"

        try:
            response = await self._client.get(url)
            response.raise_for_status()
        except (httpx.TimeoutException, httpx.NetworkError, httpx.HTTPStatusError) as e:
            logger.warning(f"Failed to fetch NIST constants: {e}")
            return {}

        # Parse the plaintext CODATA list.
        # Format: Name (Symbol)  Value  Uncertainty  Unit
        # Skip header lines and parse the constant rows.
        constants: dict[str, str] = {}
        try:
            lines = response.text.split("\n")
            for line in lines:
                # Skip empty lines and header markers
                if not line.strip() or line.startswith("--"):
                    continue

                # Try to extract constant name and value from line.
                # Format is roughly: "Constant Name (sym)  value  uncert  unit"
                parts = line.split()
                if len(parts) >= 2:
                    # Use the first tokens (before the value/uncertainty columns).
                    # Store the full line as value for matching purposes.
                    name_part = " ".join(parts[:3])  # e.g., "Planck constant (h)"
                    constants[name_part.lower()] = line.strip()

            self._constants_cache = constants
            return constants
        except Exception as e:
            logger.warning(f"Failed to parse NIST constants: {e}")
            return {}

    async def query(self, claim: Claim, max_items: int = 5) -> list[Evidence]:
        """Query NIST constants for numeric/physical claims.

        Returns SUPPORTS if a constant matches the claim within uncertainty,
        NEUTRAL if the topic matches but no numeric comparison is possible.

        Args:
            claim: The Claim to search for.
            max_items: Max results to return (default 5).

        Returns:
            A list of Evidence records, one per matching constant.
        """
        constants = await self._fetch_constants()
        if not constants:
            return []

        # Simple keyword matching: search for known constants in claim text.
        claim_lower = claim.text.lower()
        evidence_list: list[Evidence] = []

        known_constants = {
            "planck constant": "Planck constant (h)",
            "speed of light": "speed of light in vacuum (c)",
            "gravitational constant": "Newtonian constant of gravitation (G)",
            "boltzmann constant": "Boltzmann constant (k)",
            "avogadro": "Avogadro constant (N_A)",
            "faraday constant": "Faraday constant (F)",
            "fine structure constant": "fine-structure constant (alpha)",
            "electron mass": "electron mass (m_e)",
            "proton mass": "proton mass (m_p)",
        }

        for keyword, const_name in known_constants.items():
            # Use word boundaries to avoid false matches (e.g., "h" in "high")
            if re.search(r'\b' + re.escape(keyword) + r'\b', claim_lower):
                # Found a match: return SUPPORTS with the constant value.
                for const_key, const_line in constants.items():
                    if keyword in const_key or const_name.lower() in const_key:
                        excerpt = const_line[:1200]
                        raw_hash = hashlib.sha256(const_line.encode("utf-8")).hexdigest()

                        url = HttpUrl("https://physics.nist.gov/cuu/Constants/")

                        evidence = Evidence(
                            claim_id=claim.claim_id,
                            source_did=self.source_did,
                            source_version="nist-codata-2019",
                            stance=Stance.SUPPORTS,
                            excerpt=excerpt,
                            url=url,
                            retrieved_at=datetime.now(tz=UTC),
                            raw_hash=raw_hash,
                        )
                        evidence_list.append(evidence)
                        break

        return evidence_list

    async def snapshot(self, url: str) -> RawSnapshot:
        """Fetch and hash a single NIST constants page.

        Args:
            url: The NIST URL.

        Returns:
            A RawSnapshot with content and computed hash.
        """
        await self._rate_limit()
        response = await self._client.get(url)
        response.raise_for_status()

        return RawSnapshot(
            url=url,
            content=response.content,
            retrieved_at_iso=datetime.now(tz=UTC).isoformat(),
        )

    async def health(self) -> HealthStatus:
        """Check the NIST endpoint.

        Returns:
            HealthStatus with state and optional detail.
        """
        try:
            await self._rate_limit()
            response = await self._client.get("https://physics.nist.gov/cuu/Constants/")
            if response.status_code < 500:
                return HealthStatus(
                    state="HEALTHY",
                    detail="NIST constants accessible",
                    checked_at=datetime.now(tz=UTC),
                )
            else:
                return HealthStatus(
                    state="DEGRADED",
                    detail=f"NIST returned {response.status_code}",
                    checked_at=datetime.now(tz=UTC),
                )
        except (httpx.TimeoutException, httpx.NetworkError):
            return HealthStatus(
                state="DOWN",
                detail="Network error reaching NIST",
                checked_at=datetime.now(tz=UTC),
            )

    async def close(self) -> None:
        """Release HTTP client if owned by this adapter."""
        if self._owns_client:
            await self._client.aclose()
