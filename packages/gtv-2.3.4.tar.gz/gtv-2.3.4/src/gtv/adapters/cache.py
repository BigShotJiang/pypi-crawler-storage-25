# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Adapter-level result caching to reuse query() calls for near-identical claims.

Problem: when two users verify overlapping claims hitting the same adapters,
every adapter call goes out again. This is wasteful when the same claim text
hits the same adapter within a short window (e.g., 5 minutes).

Solution: wrap each adapter in a CachingAdapter that caches the list[Evidence]
returned by query() keyed on (claim.text, claim.domain, max_items). The cache
is LRU with a configurable TTL and max_entries.

Cache key: SHA256(claim.text + "|" + str(claim.domain) + "|" + str(max_items))
Cache value: list[Evidence] + cached_at (monotonic timestamp)
Expiry: now - cached_at > ttl_s
LRU eviction: when entries > max_entries, drop the oldest hit

The wrapper is transparent — all SourceAdapter attributes and methods
(health(), snapshot(), close()) pass through to inner.
"""
from __future__ import annotations

import hashlib
import os
import time
from collections import OrderedDict
from dataclasses import dataclass

from gtv.adapters.base import RawSnapshot, SourceAdapter
from gtv.models import Claim, Evidence, HealthStatus


def _now() -> float:
    """Monotonic clock — monkeypatchable in tests via this symbol."""
    return time.monotonic()


@dataclass(frozen=True)
class AdapterCacheConfig:
    """Configuration for adapter-level result caching."""

    ttl_s: float = 300.0
    max_entries: int = 1000

    def __post_init__(self) -> None:
        if self.ttl_s < 0:
            raise ValueError("ttl_s must be >= 0")
        if self.max_entries < 1:
            raise ValueError("max_entries must be >= 1")


def load_adapter_cache_config_from_env() -> AdapterCacheConfig:
    """Build an AdapterCacheConfig from environment variables.

    Env vars:
      * GTV_ADAPTER_CACHE_ENABLED — "1" to enable, "0" to disable (default "1")
      * GTV_ADAPTER_CACHE_TTL_S — seconds, default 300
      * GTV_ADAPTER_CACHE_MAX_ENTRIES — int, default 1000
    """
    ttl_s = float(os.environ.get("GTV_ADAPTER_CACHE_TTL_S", "300.0"))
    max_entries = int(os.environ.get("GTV_ADAPTER_CACHE_MAX_ENTRIES", "1000"))
    return AdapterCacheConfig(ttl_s=ttl_s, max_entries=max_entries)


@dataclass
class _CacheEntry:
    """A cached query result with its timestamp."""

    evidence: list[Evidence]
    cached_at: float


class CachingAdapter(SourceAdapter):
    """Wraps a SourceAdapter with an LRU result cache.

    Same decorator pattern as AdapterCircuitBreaker. Caches the list[Evidence]
    returned by query() and reuses it for repeated calls with the same
    (claim.text, claim.domain, max_items) within the TTL window.

    Callers use this transparently — the SourceAdapter interface is unchanged.
    """

    def __init__(
        self,
        inner: SourceAdapter,
        ttl_s: float = 300.0,
        max_entries: int = 1000,
    ) -> None:
        self._inner = inner
        self._ttl_s = ttl_s
        self._max_entries = max_entries
        # Cache: key -> _CacheEntry
        self._cache: OrderedDict[str, _CacheEntry] = OrderedDict()
        # Stats
        self._hits = 0
        self._misses = 0
        self._evictions = 0
        # Mirror the wrapped adapter's identity.
        self.source_did = inner.source_did
        self.name = inner.name
        self.trust_tier = inner.trust_tier
        self.freshness_sla_s = inner.freshness_sla_s
        self.source_type = inner.source_type

    # ---- cache management --------------------------------------------------

    def _make_cache_key(self, claim: Claim, max_items: int) -> str:
        """Create a SHA256 cache key from claim text, domain, and max_items."""
        key_str = f"{claim.text}|{claim.domain}|{max_items}"
        return hashlib.sha256(key_str.encode()).hexdigest()

    def _is_expired(self, entry: _CacheEntry) -> bool:
        """Check if a cache entry has exceeded its TTL."""
        return (_now() - entry.cached_at) > self._ttl_s

    def _get_cached(self, key: str) -> list[Evidence] | None:
        """Retrieve from cache, return None if missing or expired."""
        if key not in self._cache:
            self._misses += 1
            return None
        entry = self._cache[key]
        if self._is_expired(entry):
            # Expired; remove it and treat as a miss.
            del self._cache[key]
            self._misses += 1
            return None
        # Hit: move to end (LRU) and return.
        self._cache.move_to_end(key)
        self._hits += 1
        return entry.evidence

    def _set_cached(self, key: str, evidence: list[Evidence]) -> None:
        """Store in cache with current timestamp. Evict oldest if needed."""
        self._cache[key] = _CacheEntry(evidence=evidence, cached_at=_now())
        self._cache.move_to_end(key)
        # Evict if over capacity.
        while len(self._cache) > self._max_entries:
            self._cache.popitem(last=False)
            self._evictions += 1

    # ---- SourceAdapter surface ---------------------------------------------

    async def query(self, claim: Claim, max_items: int = 5) -> list[Evidence]:
        """Query with caching. Cache hit reuses result; miss calls inner."""
        key = self._make_cache_key(claim, max_items)
        cached = self._get_cached(key)
        if cached is not None:
            return cached
        result = await self._inner.query(claim, max_items=max_items)
        self._set_cached(key, result)
        return result

    async def snapshot(self, url: str) -> RawSnapshot:
        """Pass through to inner; no caching."""
        return await self._inner.snapshot(url)

    async def health(self) -> HealthStatus:
        """Pass through to inner."""
        return await self._inner.health()

    async def close(self) -> None:
        """Close inner and clear cache."""
        await self._inner.close()
        self._cache.clear()

    def stats(self) -> dict[str, int]:
        """Return cache performance metrics."""
        return {
            "hits": self._hits,
            "misses": self._misses,
            "evictions": self._evictions,
            "entries": len(self._cache),
        }
