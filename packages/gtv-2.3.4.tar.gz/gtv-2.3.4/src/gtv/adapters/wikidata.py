# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Wikidata adapter — structured knowledge base via SPARQL.

Wikidata is the free and open knowledge base that can be read and edited
by both humans and machines. It serves as central storage for the structured
data of its Wikimedia sister projects including Wikipedia.

The Wikidata SPARQL endpoint exposes entity labels, descriptions, and
relationships in JSON-LD and other RDF formats. For general fact verification,
Wikidata provides encyclopedic reference data at scale.

API: https://query.wikidata.org/sparql
Public, unauthenticated. No rate-limit headers, but 1 req/sec is observed
as best practice to avoid overload on the shared endpoint.
"""
from __future__ import annotations

import asyncio
import hashlib
import logging
from datetime import UTC, datetime

import httpx
from pydantic import HttpUrl

from gtv.adapters.base import RawSnapshot, SourceAdapter
from gtv.adapters.parse import claim_to_query
from gtv.models import Claim, Evidence, HealthStatus, SourceType, Stance, TrustTier

logger = logging.getLogger(__name__)


class WikidataAdapter(SourceAdapter):
    """Search Wikidata SPARQL endpoint for encyclopedic evidence."""

    source_did = "did:web:wikidata.org"
    name = "Wikidata"
    source_type = SourceType.ENCYCLOPEDIA
    trust_tier = TrustTier.TIER_2
    freshness_sla_s = 10

    _ENDPOINT = "https://query.wikidata.org/sparql"
    _RATE_LIMIT_DELAY = 1.0  # 1 req/sec is community best practice.

    def __init__(self, client: httpx.AsyncClient | None = None) -> None:
        self._client = client or httpx.AsyncClient(
            timeout=10.0,
            headers={"Accept": "application/sparql-results+json"},
        )
        self._owns_client = client is None
        self._last_request_time = 0.0

    async def _rate_limit(self) -> None:
        now = asyncio.get_event_loop().time()
        elapsed = now - self._last_request_time
        if elapsed < self._RATE_LIMIT_DELAY:
            await asyncio.sleep(self._RATE_LIMIT_DELAY - elapsed)
        self._last_request_time = asyncio.get_event_loop().time()

    async def query(self, claim: Claim, max_items: int = 5) -> list[Evidence]:
        """Search Wikidata entities matching the claim via SPARQL.

        Strategy: extract claim tokens, construct a SPARQL query to search
        entity labels and aliases, return top N results with descriptions.
        """
        query_str = claim_to_query(claim.text)
        if not query_str:
            return []

        # Build a simple SPARQL query that searches for entities whose label
        # or alias matches any of the query tokens. We use the
        # mwApiService:apiResponse shortcut to call MediaWiki's search API
        # internally (simpler than full entity graph traversal).
        # Fallback: construct a safe SPARQL that searches rdfs:label.
        sparql_query = f"""
SELECT ?item ?itemLabel ?itemDescription WHERE {{
  SERVICE wikibase:mwApiResponse {{
    ?search wikibase:search "{query_str}" ;
            wikibase:limit {max_items} .
    ?item wikibase:apiOutputItem mwapi:item .
  }}
  SERVICE wikibase:label {{ bd:serviceParam wikibase:language "en" . }}
}}
LIMIT {max_items}
"""

        await self._rate_limit()
        try:
            response = await self._client.get(
                self._ENDPOINT,
                params={
                    "query": sparql_query,
                    "format": "json",
                },
            )
            response.raise_for_status()
        except (httpx.TimeoutException, httpx.NetworkError, httpx.HTTPStatusError):
            raise

        try:
            payload = response.json()
        except ValueError as e:
            raise ValueError(f"Failed to parse Wikidata SPARQL response: {e}") from e

        results = payload.get("results", {}).get("bindings", [])
        evidence_list: list[Evidence] = []

        for item in results[:max_items]:
            item_uri = item.get("item", {}).get("value")
            label = (item.get("itemLabel", {}).get("value") or "").strip()
            description = (item.get("itemDescription", {}).get("value") or "").strip()

            if not item_uri or not label:
                continue

            excerpt = f"{label}"
            if description:
                excerpt += f". {description}"
            if len(excerpt) > 1200:
                excerpt = excerpt[:1200]

            raw_hash = hashlib.sha256(excerpt.encode("utf-8")).hexdigest()
            evidence_list.append(
                Evidence(
                    claim_id=claim.claim_id,
                    source_did=self.source_did,
                    source_version="wikidata-sparql",
                    stance=Stance.NEUTRAL,
                    excerpt=excerpt,
                    url=HttpUrl(item_uri),
                    retrieved_at=datetime.now(tz=UTC),
                    raw_hash=raw_hash,
                )
            )

        return evidence_list

    async def snapshot(self, url: str) -> RawSnapshot:
        """Fetch raw entity JSON from Wikidata for audit."""
        response = await self._client.get(url)
        response.raise_for_status()
        return RawSnapshot(
            url=url,
            content=response.content,
            retrieved_at_iso=datetime.now(tz=UTC).isoformat(),
        )

    async def health(self) -> HealthStatus:
        try:
            await self._rate_limit()
            # Simple health check: ask for a single well-known entity (Q5 = human).
            sparql_query = "SELECT ?item WHERE { ?item rdfs:label 'human'@en . } LIMIT 1"
            response = await self._client.get(
                self._ENDPOINT,
                params={"query": sparql_query, "format": "json"},
                timeout=3.0,
            )
            if 200 <= response.status_code < 400:
                return HealthStatus(state="HEALTHY", detail="Wikidata SPARQL responsive")
            return HealthStatus(
                state="DEGRADED",
                detail=f"Wikidata SPARQL returned {response.status_code}",
            )
        except httpx.TimeoutException:
            return HealthStatus(state="DOWN", detail="Wikidata SPARQL timeout (>3s)")
        except httpx.NetworkError as e:
            return HealthStatus(state="DOWN", detail=f"Network error: {e}")

    async def close(self) -> None:
        if self._owns_client:
            await self._client.aclose()
