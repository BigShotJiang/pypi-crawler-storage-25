# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Adapter conformance suite — the contract gtv expects from every adapter.

Third-party adapters import ``run_adapter_conformance`` in their own
test file::

    import pytest
    from gtv.adapters.conformance import run_adapter_conformance
    from my_adapter import MyAdapter

    @pytest.mark.asyncio
    async def test_my_adapter_conforms() -> None:
        adapter = MyAdapter()
        try:
            await run_adapter_conformance(adapter)
        finally:
            await adapter.close()

Passing the suite does **not** prove the adapter is correct (that's
upstream-specific), but it proves the adapter is safe to register: it
won't crash the server, won't fabricate evidence, won't leak handles.

Checks performed:
  1. ``source_did`` is a non-empty string and looks like a DID.
  2. ``trust_tier`` is a valid ``TrustTier`` enum value.
  3. ``freshness_sla_s`` is a positive int.
  4. ``health()`` returns a ``HealthStatus`` enum without raising.
  5. ``query()`` returns a list (possibly empty) of ``Evidence``
     objects, and each one has the claim's ``claim_id``.
  6. ``query()`` swallows transient failure — if the adapter raises
     on a plausible claim, that's a conformance failure. (Exception:
     genuine programmer errors like ``ValueError(max_items < 0)``
     are fine; we only feed well-formed inputs.)
  7. ``close()`` is idempotent (can be called twice without error).
"""

from __future__ import annotations

from gtv.adapters.base import SourceAdapter
from gtv.models import Claim, Domain, Evidence, HealthStatus, TrustTier


class ConformanceError(AssertionError):
    """Raised when an adapter fails a conformance check."""


def _assert(cond: bool, msg: str) -> None:
    if not cond:
        raise ConformanceError(msg)


async def run_adapter_conformance(
    adapter: SourceAdapter,
    *,
    sample_claim_text: str = "Water boils at 100 degrees Celsius at 1 atm.",
    sample_domain: Domain = Domain.GENERAL,
    max_items: int = 3,
) -> None:
    """Assert an adapter meets the gtv contract. Raises on failure.

    This is an async function so callers can ``await`` it inside an
    async pytest test. Passing a synchronous callback is not supported
    because every adapter method is async by contract.
    """
    # 1. static fields
    _assert(
        isinstance(adapter.source_did, str) and adapter.source_did.startswith("did:"),
        f"source_did must be a 'did:'-prefixed string (got {adapter.source_did!r})",
    )
    _assert(
        isinstance(adapter.name, str) and bool(adapter.name),
        f"name must be non-empty string (got {adapter.name!r})",
    )
    _assert(
        isinstance(adapter.trust_tier, TrustTier),
        f"trust_tier must be a TrustTier enum (got {type(adapter.trust_tier).__name__})",
    )
    _assert(
        isinstance(adapter.freshness_sla_s, int) and adapter.freshness_sla_s > 0,
        f"freshness_sla_s must be a positive int (got {adapter.freshness_sla_s!r})",
    )

    # 4. health
    try:
        health = await adapter.health()
    except Exception as e:
        raise ConformanceError(f"health() raised {type(e).__name__}: {e}") from e
    _assert(
        isinstance(health, HealthStatus),
        f"health() must return HealthStatus, got {type(health).__name__}",
    )

    # 5 + 6. query
    claim = Claim(text=sample_claim_text, domain=sample_domain)
    try:
        result = await adapter.query(claim, max_items=max_items)
    except Exception as e:
        raise ConformanceError(
            f"query() raised {type(e).__name__}: {e}; adapters must swallow "
            "transient failures and return [] instead."
        ) from e

    _assert(
        isinstance(result, list),
        f"query() must return a list, got {type(result).__name__}",
    )
    for i, item in enumerate(result):
        _assert(
            isinstance(item, Evidence),
            f"query() item {i} must be Evidence, got {type(item).__name__}",
        )
        _assert(
            item.claim_id == claim.claim_id,
            f"query() item {i} has claim_id={item.claim_id} but claim has {claim.claim_id}",
        )
        _assert(
            item.source_did == adapter.source_did,
            f"query() item {i} has source_did={item.source_did!r} but "
            f"adapter is {adapter.source_did!r}",
        )
        _assert(
            isinstance(item.raw_hash, str) and len(item.raw_hash) == 64,
            f"query() item {i} raw_hash must be 64-char hex digest",
        )

    # 7. close idempotent
    try:
        await adapter.close()
        await adapter.close()  # second call must not raise
    except Exception as e:
        raise ConformanceError(
            f"close() is not idempotent — second call raised {type(e).__name__}: {e}"
        ) from e
