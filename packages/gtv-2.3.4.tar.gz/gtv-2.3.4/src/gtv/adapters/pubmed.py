# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""PubMed/NIH e-utilities adapter — query and snapshot integration."""
from __future__ import annotations

import asyncio
import json
import os
from datetime import UTC, datetime

import httpx
from pydantic import HttpUrl

from gtv.adapters.base import RawSnapshot, SourceAdapter
from gtv.adapters.parse import claim_to_query
from gtv.adapters.snapshot import InMemorySnapshotStore, SnapshotStore
from gtv.models import Claim, Evidence, HealthStatus, SourceType, Stance, TrustTier


class PubmedAdapter(SourceAdapter):
    """Fetch and verify evidence from PubMed biomedical literature."""

    source_did = "did:web:pubmed.ncbi.nlm.nih.gov"
    name = "PubMed"
    source_type = SourceType.PEER_REVIEWED
    trust_tier = TrustTier.TIER_1
    freshness_sla_s = 10

    # PubMed e-utilities rate limit: 3 req/sec without API key, 10 req/sec with.
    # Use 0.34s between calls (safe for 3 req/sec, leaves margin).
    _RATE_LIMIT_DELAY = 0.34

    def __init__(
        self,
        client: httpx.AsyncClient | None = None,
        snapshot_store: SnapshotStore | None = None,
    ) -> None:
        """Initialize the PubMed adapter.

        Args:
            client: AsyncClient with custom timeout (default: 10s).
            snapshot_store: SnapshotStore for content-addressing (default: InMemory).
        """
        self._client = client or httpx.AsyncClient(timeout=10.0)
        self._snapshot_store = snapshot_store or InMemorySnapshotStore()
        self._owns_client = client is None
        self._api_key = os.getenv("GTV_PUBMED_API_KEY")
        self._last_request_time = 0.0

    async def _rate_limit(self) -> None:
        """Enforce rate limit between requests."""
        now = asyncio.get_event_loop().time()
        elapsed = now - self._last_request_time
        if elapsed < self._RATE_LIMIT_DELAY:
            await asyncio.sleep(self._RATE_LIMIT_DELAY - elapsed)
        self._last_request_time = asyncio.get_event_loop().time()

    async def query(self, claim: Claim, max_items: int = 5) -> list[Evidence]:
        """Query PubMed for articles relevant to the claim.

        Args:
            claim: The Claim to search for.
            max_items: Max results to return (default 5).

        Returns:
            A list of Evidence records, one per matching article.
        """
        query_str = claim_to_query(claim.text)
        if not query_str:
            return []

        # Step 1: esearch to get PMIDs.
        await self._rate_limit()
        search_url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi"
        params: dict[str, str | int] = {
            "db": "pubmed",
            "term": query_str,
            "retmax": max_items,
            "retmode": "json",
        }
        if self._api_key:
            params["api_key"] = self._api_key

        try:
            response = await self._client.get(search_url, params=params)
            response.raise_for_status()
        except (httpx.TimeoutException, httpx.NetworkError, httpx.HTTPStatusError):
            raise

        try:
            search_result = response.json()
        except json.JSONDecodeError as e:
            raise ValueError(f"Failed to parse PubMed search response: {e}") from e

        # Extract PMIDs from the response.
        pmids = search_result.get("esearchresult", {}).get("idlist", [])
        if not pmids:
            return []

        # Step 2: esummary to get article metadata.
        await self._rate_limit()
        summary_url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi"
        params = {
            "db": "pubmed",
            "id": ",".join(pmids),
            "retmode": "json",
        }
        if self._api_key:
            params["api_key"] = self._api_key

        try:
            response = await self._client.get(summary_url, params=params)
            response.raise_for_status()
        except (httpx.TimeoutException, httpx.NetworkError, httpx.HTTPStatusError):
            raise

        try:
            summary_result = response.json()
        except json.JSONDecodeError as e:
            raise ValueError(
                f"Failed to parse PubMed summary response: {e}"
            ) from e

        # Parse articles.
        evidence_list: list[Evidence] = []
        uids = summary_result.get("result", {}).get("uids", [])

        for uid in uids:
            if uid == "uids":  # Skip the uids metadata field
                continue

            article = summary_result.get("result", {}).get(uid, {})
            if not article:
                continue

            title = article.get("title", "")
            abstract = article.get("abstracttext", "")

            # Build excerpt: title + abstract, up to 1200 chars.
            full_text = f"{title}. {abstract}" if abstract else title
            excerpt = full_text if len(full_text) <= 1200 else full_text[:1200]

            # Store in snapshot for raw_hash.
            excerpt_bytes = excerpt.encode("utf-8")
            raw_hash = await self._snapshot_store.put(
                f"pubmed:{uid}", excerpt_bytes
            )

            # Detect stance: simple heuristic — if title/abstract contains affirmative
            # language about the claim keywords, SUPPORTS; else NEUTRAL.
            stance = self._detect_stance(claim.text, title, abstract)

            # Build PubMed URL.
            url = HttpUrl(f"https://pubmed.ncbi.nlm.nih.gov/{uid}/")

            evidence = Evidence(
                claim_id=claim.claim_id,
                source_did=self.source_did,
                source_version="pubmed-eutil-v1",
                stance=stance,
                excerpt=excerpt,
                url=url,
                retrieved_at=datetime.now(tz=UTC),
                raw_hash=raw_hash,
            )
            evidence_list.append(evidence)

        return evidence_list

    def _detect_stance(self, claim_text: str, title: str, abstract: str) -> Stance:
        """Simple heuristic for stance detection.

        If the title or abstract contains multiple keywords from the claim,
        assume SUPPORTS. Otherwise NEUTRAL.
        """
        claim_words = {w.lower() for w in claim_to_query(claim_text).split() if w}
        if not claim_words:
            return Stance.NEUTRAL

        text_to_search = f"{title} {abstract}".lower()
        matches = sum(1 for w in claim_words if w in text_to_search)

        # If at least 50% of claim keywords are in the article, assume SUPPORTS.
        if matches >= len(claim_words) * 0.5:
            return Stance.SUPPORTS

        return Stance.NEUTRAL

    async def snapshot(self, url: str) -> RawSnapshot:
        """Fetch and hash a single PubMed article page.

        Args:
            url: The PubMed URL.

        Returns:
            A RawSnapshot with content and computed hash.
        """
        response = await self._client.get(url)
        response.raise_for_status()

        return RawSnapshot(
            url=url,
            content=response.content,
            retrieved_at_iso=datetime.now(tz=UTC).isoformat(),
        )

    async def health(self) -> HealthStatus:
        """Check PubMed e-utilities health.

        Quick search with 3s timeout.

        Returns:
            HealthStatus with state and detail message.
        """
        try:
            await self._rate_limit()
            response = await self._client.get(
                "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi",
                params={
                    "db": "pubmed",
                    "term": "test",
                    "retmax": "1",
                    "retmode": "json",
                },
                timeout=3.0,
            )
            if response.status_code in (200, 301, 302, 304):
                return HealthStatus(
                    state="HEALTHY", detail="PubMed e-utilities responsive"
                )
            else:
                return HealthStatus(
                    state="DEGRADED",
                    detail=f"PubMed e-utilities returned {response.status_code}",
                )
        except httpx.TimeoutException:
            return HealthStatus(state="DOWN", detail="PubMed e-utilities timeout (>3s)")
        except httpx.NetworkError as e:
            return HealthStatus(state="DOWN", detail=f"Network error: {e}")

    async def close(self) -> None:
        """Close the httpx client if we own it."""
        if self._owns_client:
            await self._client.aclose()
