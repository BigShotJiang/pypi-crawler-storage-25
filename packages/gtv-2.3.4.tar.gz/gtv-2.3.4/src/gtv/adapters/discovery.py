# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Discover and register out-of-tree adapters via Python entry points.

Any installed package that declares an entry point under the
``gtv.adapters`` group is loaded, instantiated, and registered with
the process-wide adapter registry. Plugin failures are **logged, not
raised** — a single broken plugin must not prevent server startup.

Entry point format::

    [project.entry-points."gtv.adapters"]
    my-source = "my_package.module:AdapterClass"

The target must be a zero-arg-constructible ``SourceAdapter`` subclass.
If instantiation or registration raises, we log at WARNING and skip
that plugin.

Env vars:
 * ``GTV_DISABLE_PLUGIN_ADAPTERS`` — set to ``1`` to suppress discovery
   entirely (useful for deterministic tests and locked-down deploys).
 * ``GTV_PLUGIN_ADAPTER_ALLOWLIST`` — comma-separated list of entry
   point names to accept; anything else is ignored. Empty / unset
   means "load all".
"""

from __future__ import annotations

import logging
import os
from importlib.metadata import EntryPoint, entry_points
from typing import Any

from gtv.adapters.base import SourceAdapter

logger = logging.getLogger(__name__)

ENTRY_POINT_GROUP = "gtv.adapters"


def _iter_plugin_entry_points() -> list[EntryPoint]:
    """Return all ``gtv.adapters`` entry points, filtered by allowlist."""
    try:
        eps = list(entry_points(group=ENTRY_POINT_GROUP))
    except Exception as e:  # pragma: no cover — defensive
        logger.warning("entry_points lookup failed: %s", e)
        return []

    allowlist_raw = os.environ.get("GTV_PLUGIN_ADAPTER_ALLOWLIST", "").strip()
    if not allowlist_raw:
        return eps

    allow = {name.strip() for name in allowlist_raw.split(",") if name.strip()}
    return [ep for ep in eps if ep.name in allow]


def discover_plugin_adapters(*, register_fn: Any = None) -> list[SourceAdapter]:
    """Load, instantiate, and register every declared plugin adapter.

    Returns the adapters that were successfully registered so callers
    can surface a startup banner. Plugins that fail to load or instantiate
    are logged and skipped, never raised.

    Args:
        register_fn: injection point for the registry ``register`` function
            so this module stays loosely coupled to ``__init__.py`` (and
            tests can pass a dummy).
    """
    if os.getenv("GTV_DISABLE_PLUGIN_ADAPTERS") == "1":
        logger.info("plugin adapter discovery disabled via GTV_DISABLE_PLUGIN_ADAPTERS")
        return []

    if register_fn is None:
        # Late import — avoid circular with __init__.py.
        from gtv.adapters import register as _reg

        register_fn = _reg

    loaded: list[SourceAdapter] = []
    for ep in _iter_plugin_entry_points():
        try:
            cls = ep.load()
        except Exception as e:
            logger.warning("plugin %s failed to import: %s", ep.name, e)
            continue

        try:
            instance = cls()
        except Exception as e:
            logger.warning("plugin %s failed to instantiate: %s", ep.name, e)
            continue

        if not isinstance(instance, SourceAdapter):
            logger.warning(
                "plugin %s did not produce a SourceAdapter (got %s); skipping",
                ep.name,
                type(instance).__name__,
            )
            continue

        try:
            register_fn(instance)
        except Exception as e:
            logger.warning("plugin %s registration failed: %s", ep.name, e)
            continue

        loaded.append(instance)
        logger.info(
            "plugin adapter loaded: name=%s did=%s tier=%s",
            ep.name,
            instance.source_did,
            instance.trust_tier,
        )

    return loaded
