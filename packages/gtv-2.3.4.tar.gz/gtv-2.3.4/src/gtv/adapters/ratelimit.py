# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Priority-based rate limiting for adapter queries.

Problem: when the verifier fires N concurrent claims at the same adapter,
they serialize on a single lock. Without priority awareness, a SLOW query
can block an URGENT one indefinitely.

Solution: a token-bucket rate limiter with priority queues. Each waiter
holds a priority integer (lower wins first, FIFO within ties). Tokens
are replenished via monotonic clock, not background tasks.

Public API:
  - PriorityRateLimiter: token-bucket with priority queue
  - RateLimitedAdapter: SourceAdapter decorator that acquires/releases tokens

The decorator respects tenant priority via an optional priority_fn
that extracts priority from a Claim.
"""
from __future__ import annotations

import asyncio
import time
from collections.abc import Callable

from gtv.adapters.base import RawSnapshot, SourceAdapter
from gtv.models import Claim, Evidence, HealthStatus


def _now() -> float:
    """Monotonic clock — monkeypatchable in tests via this symbol."""
    return time.monotonic()


class PriorityRateLimiter:
    """Token-bucket rate limiter with priority queues.

    Waiters are served in priority order (lower integer = higher priority).
    Ties are broken by arrival order (FIFO).

    Internal state: asyncio.Condition + a priority heap.
    Token refill: computed on-demand from monotonic clock.
    """

    def __init__(self, rate_per_sec: float, burst: int = 1) -> None:
        """Initialize the rate limiter.

        Args:
            rate_per_sec: tokens per second (e.g., 2.0 = 1 token every 0.5s)
            burst: max tokens in bucket at any time (burst capacity)
        """
        if rate_per_sec <= 0:
            raise ValueError("rate_per_sec must be > 0")
        if burst < 1:
            raise ValueError("burst must be >= 1")

        self._rate_per_sec = rate_per_sec
        self._burst = burst
        self._tokens = float(burst)
        self._last_refill = _now()
        self._condition = asyncio.Condition(asyncio.Lock())
        # Priority queue: list of (priority, arrival_order, event)
        self._waiters: list[tuple[int, int, asyncio.Event]] = []
        self._next_arrival_order = 0

    async def acquire(self, priority: int = 5) -> None:
        """Block until a token is available.

        Lower priority integer wins first (e.g., 0 > 10). Ties broken by FIFO.

        Args:
            priority: numeric priority (default 5, safe middle ground)
        """
        event = asyncio.Event()
        arrival_order = None

        async with self._condition:
            # Refill tokens before checking availability
            self._refill()

            # If tokens available and no one ahead, take a token immediately
            if self._tokens >= 1.0 and not self._has_higher_priority_waiter(
                priority
            ):
                self._tokens -= 1.0
                return

            # Otherwise, add ourselves to the priority queue and wait
            arrival_order = self._next_arrival_order
            self._next_arrival_order += 1
            self._waiters.append((priority, arrival_order, event))
            # Sort by priority, then by arrival order
            self._waiters.sort(key=lambda x: (x[0], x[1]))

        # Release lock while waiting for the event
        # Periodically check if we should wake up due to refill
        while not event.is_set():
            try:
                await asyncio.wait_for(event.wait(), timeout=0.1)
                return
            except TimeoutError:
                # Check if we have a token now
                async with self._condition:
                    self._refill()
                    if self._tokens >= 1.0 and self._is_our_turn(
                        priority, arrival_order
                    ):
                        self._tokens -= 1.0
                        # Remove ourselves from the queue
                        self._waiters = [
                            (p, a, e)
                            for p, a, e in self._waiters
                            if not (p == priority and a == arrival_order)
                        ]
                        return

    def release_unused(self) -> None:
        """Return an unused token to the bucket.

        Call this if you acquired but didn't use (e.g., request cancelled).
        Wakes one waiter (highest priority first).
        """
        asyncio.create_task(self._release_and_wake())  # noqa: RUF006

    async def _release_and_wake(self) -> None:
        """Async helper to release a token and wake the next waiter."""
        async with self._condition:
            self._tokens = min(self._tokens + 1.0, float(self._burst))
            self._wake_next_waiter()

    def _refill(self) -> None:
        """Compute elapsed time and add tokens based on rate_per_sec."""
        now = _now()
        elapsed = now - self._last_refill
        self._last_refill = now
        self._tokens = min(
            self._tokens + elapsed * self._rate_per_sec, float(self._burst)
        )

    def _has_higher_priority_waiter(self, priority: int) -> bool:
        """Check if any waiter has strictly higher priority (lower int)."""
        return any(wp[0] < priority for wp in self._waiters)

    def _is_our_turn(self, priority: int, arrival_order: int | None) -> bool:
        """Check if this (priority, arrival_order) is first in the queue."""
        if not self._waiters or arrival_order is None:
            return False
        first_p, first_a, _ = self._waiters[0]
        return first_p == priority and first_a == arrival_order

    def _wake_next_waiter(self) -> None:
        """Remove the first waiter from queue and signal its event."""
        if self._waiters:
            # Take the first (highest priority, earliest arrival)
            _, _, event = self._waiters.pop(0)
            event.set()


class RateLimitedAdapter(SourceAdapter):
    """Wraps a SourceAdapter with priority rate limiting.

    Respects tenant priority via an optional priority_fn that extracts
    priority from a Claim. Defaults to priority 5 (neutral).

    All SourceAdapter methods (health, snapshot, close) pass through
    to the inner adapter unchanged.
    """

    def __init__(
        self,
        inner: SourceAdapter,
        rate_limiter: PriorityRateLimiter,
        priority_fn: Callable[[Claim], int] | None = None,
    ) -> None:
        """Initialize the rate-limited adapter.

        Args:
            inner: the wrapped SourceAdapter
            rate_limiter: shared PriorityRateLimiter instance
            priority_fn: optional callable that extracts priority from a Claim
                         (default: always returns 5)
        """
        self._inner = inner
        self._rate_limiter = rate_limiter
        self._priority_fn = priority_fn or (lambda _: 5)

        # Mirror the wrapped adapter's identity
        self.source_did = inner.source_did
        self.name = inner.name
        self.trust_tier = inner.trust_tier
        self.freshness_sla_s = inner.freshness_sla_s
        self.source_type = inner.source_type

    async def query(self, claim: Claim, max_items: int = 5) -> list[Evidence]:
        """Query with rate limiting. Acquires token, calls inner, then releases."""
        priority = self._priority_fn(claim)
        await self._rate_limiter.acquire(priority=priority)
        try:
            return await self._inner.query(claim, max_items=max_items)
        except asyncio.CancelledError:
            # If the request was cancelled, return the unused token
            self._rate_limiter.release_unused()
            raise

    async def snapshot(self, url: str) -> RawSnapshot:
        """Pass through to inner; no rate limiting."""
        return await self._inner.snapshot(url)

    async def health(self) -> HealthStatus:
        """Pass through to inner; no rate limiting."""
        return await self._inner.health()

    async def close(self) -> None:
        """Close inner adapter."""
        await self._inner.close()
