# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""WHO Global Health Observatory (GHO) adapter — curated health indicators.

The WHO Global Health Observatory provides a centralized hub of health
data and information from the World Health Organization. It exposes
standardized indicators (infant mortality, disease prevalence, etc.) that
support health claims verification.

API: https://ghoapi.azureedge.net/api/Indicator (list),
     https://ghoapi.azureedge.net/api/{INDICATOR_CODE} (data)
No API key required. OData JSON responses.
"""
from __future__ import annotations

import asyncio
import hashlib
import logging
import os
from datetime import UTC, datetime

import httpx
from pydantic import HttpUrl

from gtv.adapters.base import RawSnapshot, SourceAdapter
from gtv.adapters.parse import claim_to_query
from gtv.models import Claim, Evidence, HealthStatus, SourceType, Stance, TrustTier

logger = logging.getLogger(__name__)


class WHOGHOAdapter(SourceAdapter):
    """WHO Global Health Observatory evidence via the OData API."""

    source_did = "did:web:who.int"
    name = "WHO GHO"
    source_type = SourceType.GOVT_OPEN_DATA
    trust_tier = TrustTier.TIER_1
    freshness_sla_s = 10

    _BASE = "https://ghoapi.azureedge.net/api"
    _RATE_LIMIT_DELAY = 1.0

    def __init__(self, client: httpx.AsyncClient | None = None) -> None:
        self._client = client or httpx.AsyncClient(
            timeout=10.0,
            headers={"Accept": "application/json"},
        )
        self._owns_client = client is None
        self._last_request_time = 0.0
        self._indicator_cache: dict[str, str] | None = None  # code -> name

    async def _rate_limit(self) -> None:
        now = asyncio.get_event_loop().time()
        elapsed = now - self._last_request_time
        if elapsed < self._RATE_LIMIT_DELAY:
            await asyncio.sleep(self._RATE_LIMIT_DELAY - elapsed)
        self._last_request_time = asyncio.get_event_loop().time()

    async def _fetch_indicators(self) -> dict[str, str]:
        """Fetch and cache the full indicator list.

        Returns a dict mapping indicator code to indicator name.
        """
        if self._indicator_cache is not None:
            return self._indicator_cache

        await self._rate_limit()
        try:
            response = await self._client.get(f"{self._BASE}/Indicator")
            response.raise_for_status()
        except (httpx.TimeoutException, httpx.NetworkError, httpx.HTTPStatusError):
            raise

        try:
            payload = response.json()
        except ValueError as e:
            raise ValueError(f"Failed to parse WHO GHO Indicator list: {e}") from e

        indicators = payload.get("value", []) or []
        cache: dict[str, str] = {}
        for item in indicators:
            code = item.get("IndicatorCode")
            name = item.get("IndicatorName")
            if code and name:
                cache[code] = name

        self._indicator_cache = cache
        return cache

    async def query(self, claim: Claim, max_items: int = 5) -> list[Evidence]:
        """Search WHO GHO indicators by keyword matching.

        Returns indicator names as NEUTRAL evidence (reference data).
        """
        # Check if adapter is disabled via environment variable.
        if os.getenv("GTV_WHO_GHO_DISABLE"):
            return []

        query_str = claim_to_query(claim.text)
        if not query_str:
            return []

        try:
            indicators = await self._fetch_indicators()
        except (httpx.TimeoutException, httpx.NetworkError, httpx.HTTPStatusError):
            raise

        # Filter indicators by substring match on query keywords.
        query_keywords = set(query_str.lower().split())
        matching: list[tuple[str, str]] = []

        for code, name in indicators.items():
            name_lower = name.lower()
            # Match if any query keyword is a substring of the indicator name.
            if any(keyword in name_lower for keyword in query_keywords):
                matching.append((code, name))

        evidence_list: list[Evidence] = []
        for code, name in matching[:max_items]:
            excerpt = f"Indicator: {name} (Code: {code})"
            raw_hash = hashlib.sha256(excerpt.encode("utf-8")).hexdigest()

            # Build URL: use the indicator metadata URL pattern.
            url = HttpUrl(f"https://www.who.int/data/gho/indicator-metadata-registry/imr-details/{code}")

            evidence_list.append(
                Evidence(
                    claim_id=claim.claim_id,
                    source_did=self.source_did,
                    source_version="who-gho-odata-v1",
                    stance=Stance.NEUTRAL,  # Always NEUTRAL — this is reference data.
                    excerpt=excerpt,
                    url=url,
                    retrieved_at=datetime.now(tz=UTC),
                    raw_hash=raw_hash,
                )
            )

        return evidence_list

    async def snapshot(self, url: str) -> RawSnapshot:
        """Fetch and hash a single WHO GHO indicator page."""
        response = await self._client.get(url)
        response.raise_for_status()

        return RawSnapshot(
            url=url,
            content=response.content,
            retrieved_at_iso=datetime.now(tz=UTC).isoformat(),
        )

    async def health(self) -> HealthStatus:
        try:
            await self._rate_limit()
            response = await self._client.get(
                f"{self._BASE}/Indicator",
                timeout=3.0,
            )
            if 200 <= response.status_code < 400:
                return HealthStatus(state="HEALTHY", detail="WHO GHO responsive")
            return HealthStatus(
                state="DEGRADED",
                detail=f"WHO GHO returned {response.status_code}",
            )
        except httpx.TimeoutException:
            return HealthStatus(state="DOWN", detail="WHO GHO timeout (>3s)")
        except httpx.NetworkError as e:
            return HealthStatus(state="DOWN", detail=f"Network error: {e}")

    async def close(self) -> None:
        if self._owns_client:
            await self._client.aclose()
