# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Claim-to-query extraction: heuristic keyphrases from free-text claims.

Pure, deterministic, stdlib-only. No LLMs.
"""
from __future__ import annotations

import re
from typing import Final

# Common English stopwords (conservative list, from standard IR).
_STOPWORDS: Final[set[str]] = {
    "a", "about", "above", "after", "again", "against", "all", "am", "an",
    "and", "any", "are", "aren't", "as", "at", "be", "because", "been",
    "before", "being", "below", "between", "both", "but", "by", "can't",
    "cannot", "could", "couldn't", "did", "didn't", "do", "does", "doesn't",
    "doing", "don't", "down", "during", "each", "few", "for", "from",
    "further", "had", "hadn't", "has", "hasn't", "have", "haven't", "having",
    "he", "he'd", "he'll", "he's", "her", "here", "here's", "hers", "herself",
    "him", "himself", "his", "how", "how's", "i", "i'd", "i'll", "i'm", "i've",
    "if", "in", "into", "is", "isn't", "it", "it's", "its", "itself", "just",
    "k", "ks", "let's", "me", "more", "most", "mustn't", "my", "myself", "no",
    "nor", "not", "of", "off", "on", "once", "only", "or", "other", "ought",
    "our", "ours", "ourselves", "out", "over", "own", "same", "shan't",
    "she", "she'd", "she'll", "she's", "should", "shouldn't", "so", "some",
    "such", "than", "that", "that's", "the", "their", "theirs", "them",
    "themselves", "then", "there", "there's", "these", "they", "they'd",
    "they'll", "they're", "they've", "this", "those", "through", "to",
    "too", "under", "until", "up", "very", "was", "wasn't", "we", "we'd",
    "we'll", "we're", "we've", "were", "weren't", "what", "what's", "when",
    "when's", "where", "where's", "which", "while", "who", "who's", "whom",
    "why", "why's", "with", "won't", "wouldn't", "you", "you'd", "you'll",
    "you're", "you've", "your", "yours", "yourself", "yourselves",
}


def claim_to_query(text: str) -> str:
    """Extract a search query from a claim text.

    Heuristic: lowercase, strip punctuation (except hyphens inside words),
    split on whitespace, remove stopwords, keep noun-ish tokens, join with spaces.

    Returns a space-joined query string <= 200 chars.
    """
    # Lowercase and strip leading/trailing whitespace.
    text = text.lower().strip()

    # Remove excessive punctuation but preserve hyphens within words.
    # Replace sequences of special chars with single space.
    text = re.sub(r"[^\w\s-]", " ", text)

    # Split into tokens.
    tokens = text.split()

    # Filter: keep tokens that are not pure stopwords, length > 1.
    # Also keep tokens that look like abbreviations (all caps, e.g. "GRB").
    query_tokens = [
        t for t in tokens
        if t and t not in _STOPWORDS and len(t) > 1
    ]

    # Join and truncate to 200 chars.
    query = " ".join(query_tokens)
    if len(query) > 200:
        query = query[:200].rsplit(" ", 1)[0]  # trim to last full word

    return query
