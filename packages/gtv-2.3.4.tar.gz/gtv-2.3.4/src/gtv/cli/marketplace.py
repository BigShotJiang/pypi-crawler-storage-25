# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Plugin marketplace CLI — publish, list, and validate plugin manifests.

Subcommands:
  gtv-marketplace publish <manifest.toml>  - publish a plugin to the registry
  gtv-marketplace list [--name FILTER]     - list all plugins or filter by name
  gtv-marketplace show <name>              - show full manifest of latest version
  gtv-marketplace validate <manifest.toml> - validate a manifest without publishing

Default registry location: ~/.gtv/marketplace.jsonl

Exit codes:
  0 = success
  1 = validation/data error (bad manifest, duplicate, not found, etc.)
  2 = usage error (missing required argument)
  3 = file not found
  4 = file read/write error
"""
from __future__ import annotations

import json
import sys
import tomllib
from datetime import UTC, datetime
from hashlib import sha256
from pathlib import Path
from typing import Any

from gtv.marketplace.manifest import PluginManifest
from gtv.marketplace.registry import add_manifest, latest, load_registry


def _get_default_registry_path() -> Path:
    """Return default registry location: ~/.gtv/marketplace.jsonl"""
    return Path.home() / ".gtv" / "marketplace.jsonl"


def _load_toml_manifest(path: str) -> dict[str, Any]:
    """Load and parse a TOML manifest file.

    Args:
        path: Path to .toml file.

    Returns:
        Parsed TOML dict.

    Raises:
        FileNotFoundError: If file does not exist.
        ValueError: If TOML is malformed.
    """
    manifest_path = Path(path)
    if not manifest_path.exists():
        raise FileNotFoundError(f"Manifest file not found: {path}")

    try:
        with open(manifest_path, "rb") as f:
            return tomllib.load(f)
    except tomllib.TOMLDecodeError as e:
        raise ValueError(f"Invalid TOML in {path}: {e}") from e
    except OSError as e:
        raise OSError(f"Failed to read {path}: {e}") from e


def _compute_wheel_sha256(wheel_path: str) -> str:
    """Compute SHA256 of a wheel file.

    Args:
        wheel_path: Path to the .whl file.

    Returns:
        Lowercase hex SHA256 string.

    Raises:
        FileNotFoundError: If wheel does not exist.
        OSError: If read fails.
    """
    wheel = Path(wheel_path)
    if not wheel.exists():
        raise FileNotFoundError(f"Wheel file not found: {wheel_path}")

    h = sha256()
    with open(wheel, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def cmd_publish(argv: list[str]) -> int:
    """Publish a plugin manifest to the registry.

    Usage: gtv-marketplace publish <manifest.toml> [--wheel <path.whl>] [--registry <path>]

    Args:
        argv: Remaining arguments after 'publish'.

    Returns:
        Exit code (0 = success, non-zero = error).
    """
    if not argv or argv[0] in ("--help", "-h"):
        print(
            "usage: gtv-marketplace publish <manifest.toml> "
            "[--wheel <path.whl>] [--registry <path>]",
            file=sys.stderr,
        )
        return 2

    manifest_path = argv[0]
    wheel_path = None
    registry_path = _get_default_registry_path()

    i = 1
    while i < len(argv):
        arg = argv[i]
        if arg == "--wheel" and i + 1 < len(argv):
            wheel_path = argv[i + 1]
            i += 2
        elif arg == "--registry" and i + 1 < len(argv):
            registry_path = Path(argv[i + 1])
            i += 2
        else:
            i += 1

    # Load and validate manifest from TOML
    try:
        toml_data = _load_toml_manifest(manifest_path)
    except FileNotFoundError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 3
    except (ValueError, OSError) as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 4

    # Extract manifest section from TOML (expect [plugin] or [marketplace])
    manifest_dict = toml_data.get("plugin") or toml_data.get("marketplace")
    if not manifest_dict:
        print(
            "ERROR: TOML must contain [plugin] or [marketplace] section",
            file=sys.stderr,
        )
        return 1

    # Validate manifest schema
    try:
        manifest = PluginManifest.model_validate(manifest_dict)
    except Exception as e:
        print(f"ERROR: Invalid manifest schema: {e}", file=sys.stderr)
        return 1

    # Compute wheel hash if provided
    if wheel_path:
        try:
            manifest.signed_sha256 = _compute_wheel_sha256(wheel_path)
        except FileNotFoundError as e:
            print(f"ERROR: {e}", file=sys.stderr)
            return 3
        except OSError as e:
            print(f"ERROR: {e}", file=sys.stderr)
            return 4

    # Stamp published_at
    manifest.published_at = datetime.now(tz=UTC)

    # Add to registry (rejects duplicates)
    try:
        add_manifest(registry_path, manifest)
    except ValueError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 1
    except OSError as e:
        print(f"ERROR: Failed to write registry: {e}", file=sys.stderr)
        return 4

    print(f"Published {manifest.name}@{manifest.version} to {registry_path}")
    return 0


def cmd_list(argv: list[str]) -> int:
    """List all plugins in the registry, optionally filtered by name prefix.

    Usage: gtv-marketplace list [--name FILTER] [--registry <path>]

    Args:
        argv: Remaining arguments after 'list'.

    Returns:
        Exit code (0 = success, non-zero = error).
    """
    name_filter = None
    registry_path = _get_default_registry_path()

    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "--name" and i + 1 < len(argv):
            name_filter = argv[i + 1]
            i += 2
        elif arg == "--registry" and i + 1 < len(argv):
            registry_path = Path(argv[i + 1])
            i += 2
        else:
            i += 1

    try:
        all_manifests = load_registry(registry_path)
    except Exception as e:
        print(f"ERROR: Failed to load registry: {e}", file=sys.stderr)
        return 4

    # Filter by name prefix if provided
    if name_filter:
        all_manifests = [m for m in all_manifests if m.name.startswith(name_filter)]

    if not all_manifests:
        if name_filter:
            print(f"No plugins found matching '{name_filter}'")
        else:
            print("No plugins in registry")
        return 0

    # Group by name, show latest version of each
    seen_names = set()
    latest_per_name = {}
    for manifest in all_manifests:
        if manifest.name not in seen_names:
            seen_names.add(manifest.name)
            latest_per_name[manifest.name] = manifest

    # Sort by name and display
    for name in sorted(latest_per_name.keys()):
        m = latest_per_name[name]
        print(f"{m.name}@{m.version} — {m.description}")

    return 0


def cmd_show(argv: list[str]) -> int:
    """Show the full manifest of the latest version of a plugin.

    Usage: gtv-marketplace show <name> [--registry <path>]

    Args:
        argv: Remaining arguments after 'show'.

    Returns:
        Exit code (0 = success, non-zero = error).
    """
    if not argv or argv[0] in ("--help", "-h"):
        print("usage: gtv-marketplace show <name> [--registry <path>]", file=sys.stderr)
        return 2

    name = argv[0]
    registry_path = _get_default_registry_path()

    i = 1
    while i < len(argv):
        arg = argv[i]
        if arg == "--registry" and i + 1 < len(argv):
            registry_path = Path(argv[i + 1])
            i += 2
        else:
            i += 1

    try:
        manifest = latest(registry_path, name)
    except Exception as e:
        print(f"ERROR: Failed to load registry: {e}", file=sys.stderr)
        return 4

    if not manifest:
        print(f"ERROR: Plugin '{name}' not found in registry", file=sys.stderr)
        return 1

    print(json.dumps(manifest.model_dump(mode="json"), indent=2))
    return 0


def cmd_validate(argv: list[str]) -> int:
    """Validate a manifest TOML without publishing.

    Usage: gtv-marketplace validate <manifest.toml>

    Args:
        argv: Remaining arguments after 'validate'.

    Returns:
        Exit code (0 = valid, 1 = invalid).
    """
    if not argv or argv[0] in ("--help", "-h"):
        print("usage: gtv-marketplace validate <manifest.toml>", file=sys.stderr)
        return 2

    manifest_path = argv[0]

    try:
        toml_data = _load_toml_manifest(manifest_path)
    except FileNotFoundError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 3
    except (ValueError, OSError) as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 4

    # Extract manifest section
    manifest_dict = toml_data.get("plugin") or toml_data.get("marketplace")
    if not manifest_dict:
        print(
            "ERROR: TOML must contain [plugin] or [marketplace] section",
            file=sys.stderr,
        )
        return 1

    # Validate schema
    try:
        PluginManifest.model_validate(manifest_dict)
    except Exception as e:
        print(f"ERROR: Invalid manifest schema: {e}", file=sys.stderr)
        return 1

    print(f"✓ {manifest_path} is valid")
    return 0


def main(argv: list[str] | None = None) -> int:
    """Main entry point for gtv-marketplace CLI.

    Args:
        argv: Command-line arguments (defaults to sys.argv[1:])

    Returns:
        Exit code (0 = success, non-zero = error).
    """
    argv = argv if argv is not None else sys.argv[1:]

    if not argv or argv[0] in ("--help", "-h", "help"):
        print(
            """usage: gtv-marketplace <subcommand> [options]

Subcommands:
  publish <manifest.toml>  - Publish a plugin to the registry
                             Options: --wheel <path.whl> --registry <path>
  list [--name FILTER]     - List plugins (optionally filter by name prefix)
                             Options: --registry <path>
  show <name>              - Show full manifest of latest version
                             Options: --registry <path>
  validate <manifest.toml> - Validate a manifest without publishing

Default registry: ~/.gtv/marketplace.jsonl
""",
            file=sys.stderr,
        )
        return 2

    subcommand = argv[0]
    remaining = argv[1:]

    if subcommand == "publish":
        return cmd_publish(remaining)
    elif subcommand == "list":
        return cmd_list(remaining)
    elif subcommand == "show":
        return cmd_show(remaining)
    elif subcommand == "validate":
        return cmd_validate(remaining)
    else:
        print(f"ERROR: Unknown subcommand '{subcommand}'", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
