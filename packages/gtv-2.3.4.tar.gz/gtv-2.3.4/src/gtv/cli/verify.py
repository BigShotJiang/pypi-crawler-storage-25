# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Offline envelope verifier.

Target: < 300 LOC total (see build spec §7). Zero external services.
Verifies:
 1. Canonical JSON hash matches the signed-over payload hash.
 2. Sigstore signature bundle verifies against the canonical hash.
 3. Rekor inclusion proof matches the claimed log index.
 4. Issuer identity from DID document matches certificate (if --trust-issuer=False).
 5. At least one RFC 3161 TSR verifies over the canonical hash (W4).

Exit codes:
 0 = fully verified
 2 = stub detected (not verifiable)
 3 = signature mismatch / verification failed
 4 = Rekor proof mismatch
 5 = schema error / parse error
 6 = log-root key not trusted / missing
 7 = issuer verification failed
"""
from __future__ import annotations

import asyncio
import base64
import hashlib
import json
import sys
from pathlib import Path

from cryptography import x509
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec

from gtv.anchor.canonicalize import envelope_canonical_sha256
from gtv.anchor.rekor import (
    RekorTrustError,
    hashedrekord_leaf_hash,
    load_rekor_public_key,
    verify_log_root_signature,
)
from gtv.did.resolve import DIDResolutionError, extract_expected_identity, resolve_did_web
from gtv.did.verify_issuer import IssuerMismatchError, verify_cert_binds_to_identity
from gtv.federation.loader import load_registry_from_env
from gtv.federation.registry import DEFAULT_REGISTRY, IssuerRegistry
from gtv.models import Envelope


def verify_file(
    path: Path,
    allow_stub: bool = False,
    allow_unrooted: bool = False,
    trust_issuer: bool = False,
    allow_unlisted: bool = False,
    offline: bool = False,
    rekor_staging: bool = False,
) -> int:
    """Verify an offline envelope: hash, signature, Rekor proof, and issuer identity.

    Args:
        path: Path to envelope JSON file.
        allow_stub: If True, exit 0 even if signature is stub:// (default: exit 2).
        allow_unrooted: If True, skip Rekor log root trust check (default: fail if key missing).
        trust_issuer: If True, skip DID resolution and issuer verification (default: False, verify issuer).
        allow_unlisted: If True, skip federation registry check (default: fail if issuer not in registry).
        offline: If True, perform ONLY local verification (no network calls); skip issuer identity check.
        rekor_staging: If True, verify the checkpoint against the staging Rekor public key
            instead of production. Use when the envelope was signed against Sigstore staging
            (GTV_SIGSTORE_PROD=0). Default False = production.

    Returns:
        Exit code (0 = OK, 2 = stub, 3 = sig fail, 4 = proof fail, 5 = schema, 6 = trust, 7 = issuer).
        (Note: exit code 7 is not emitted when offline=True.)
    """
    # Load the federation registry (falls back to DEFAULT_REGISTRY if env not set).
    registry = load_registry_from_env() or DEFAULT_REGISTRY
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as e:
        print(f"ERROR: Failed to read/parse envelope: {e}", file=sys.stderr)
        return 5

    try:
        env = Envelope.model_validate(data)
    except Exception as e:
        print(f"ERROR: Schema validation failed: {e}", file=sys.stderr)
        return 5

    recomputed = envelope_canonical_sha256(env)
    print(f"canonical-hash: {recomputed}")

    # Check for stub signature.
    if env.signature.startswith("stub://"):
        print("WARNING: envelope carries a STUB signature. Not cryptographically verifiable.")
        return 0 if allow_stub else 2

    # Verify Sigstore signature.
    try:
        _verify_sigstore_signature(env, recomputed)
        print("signature: OK")
    except Exception as e:
        print(f"ERROR: Signature verification failed: {e}", file=sys.stderr)
        return 3

    # Verify Rekor inclusion proof (non-stub path).
    if env.anchor_proof.rekor_inclusion_proof.startswith("stub://"):
        print("WARNING: envelope carries a STUB Rekor proof. Not cryptographically verifiable.")
        return 0 if allow_stub else 2

    try:
        log_index, tree_size = _verify_rekor_proof(
            env.anchor_proof.rekor_inclusion_proof,
            recomputed,
            env.signature,
            allow_unrooted=allow_unrooted,
            rekor_staging=rekor_staging,
            rekor_canonical_body_b64=env.anchor_proof.rekor_canonical_body_b64,
        )
        print(f"rekor-proof: OK (log_index={log_index}, tree_size={tree_size})")
    except ValueError as e:
        print(f"ERROR: Rekor proof verification failed: {e}", file=sys.stderr)
        return 4
    except RekorTrustError as e:
        # Log root key not trusted or signature verification failed.
        print(f"ERROR: {e}", file=sys.stderr)
        return 6

    # Verify issuer identity (unless --trust-issuer or --offline is set)
    if not trust_issuer and not offline:
        try:
            _verify_issuer_identity(env, registry, allow_unlisted=allow_unlisted)
            print("issuer-identity: OK")
        except (DIDResolutionError, IssuerMismatchError, ValueError) as e:
            print(f"ERROR: Issuer verification failed: {e}", file=sys.stderr)
            return 7
    elif offline:
        print("issuer-identity: SKIPPED (offline mode)")

    # TSA verification is W4.
    if env.tsa_token.startswith("stub://"):
        print("WARNING: envelope carries a STUB TSA token. TSA verification pending (W4).")
    else:
        print("INFO: TSA verification pending (W4).")

    return 0


def _verify_issuer_identity(
    env: Envelope,
    registry: IssuerRegistry,
    allow_unlisted: bool = False,
) -> None:
    """Verify that the envelope issuer identity matches the certificate.

    First checks if the issuer_did is in the federation registry (unless --allow-unlisted).
    Then resolves the issuer_did (did:web only), extracts expected identity from the DID doc,
    extracts the signing certificate, and verifies they match.

    Args:
        env: Envelope with issuer_did and certificate in inclusion_proof.
        registry: IssuerRegistry to check issuer membership.
        allow_unlisted: If True, skip registry check.

    Raises:
        DIDResolutionError: If DID resolution fails.
        IssuerMismatchError: If certificate does not match expected identity.
        ValueError: If certificate cannot be extracted or parsed, or if issuer not in registry.
    """
    issuer_did = env.issuer_did

    # Check federation registry (unless --allow-unlisted is set).
    if not allow_unlisted:
        trusted_issuer = registry.get(issuer_did)
        if trusted_issuer is None:
            raise ValueError(
                f"Issuer DID not in trusted registry: {issuer_did}. "
                "Use --allow-unlisted to bypass this check."
            )

    # Resolve the DID (only did:web is supported for Week 4)
    if not issuer_did.startswith("did:web:"):
        raise DIDResolutionError(
            f"Unsupported DID method: {issuer_did}. "
            "Only did:web is supported in Week 4."
        )

    # Resolve the DID document asynchronously
    try:
        did_doc = asyncio.run(resolve_did_web(issuer_did))
    except DIDResolutionError:
        raise

    # Extract expected identity from DID document
    expected_identity = extract_expected_identity(did_doc)

    # Extract certificate from inclusion_proof JSON
    cert_pem = None
    try:
        proof = json.loads(env.anchor_proof.rekor_inclusion_proof)
        cert_pem = proof.get("certificate_pem")
    except (json.JSONDecodeError, AttributeError):
        pass

    if not cert_pem:
        raise ValueError("No certificate PEM found in inclusion_proof")

    # Verify certificate binds to expected identity
    verify_cert_binds_to_identity(cert_pem, expected_identity)


def _verify_sigstore_signature(env: Envelope, canonical_hash_hex: str) -> None:
    """Verify ECDSA P-256 signature against the canonical hash.

    Args:
        env: Envelope with signature and certificate_pem (in inclusion_proof JSON).
        canonical_hash_hex: The canonical hash (hex string).

    Raises:
        Exception: If signature is invalid or verification fails.
    """
    # Extract and decode signature.
    try:
        sig_bytes = base64.b64decode(env.signature)
    except Exception as e:
        raise ValueError(f"Invalid base64 signature: {e}") from e

    # Extract certificate from inclusion_proof JSON.
    # The certificate is embedded during signing for offline verification.
    cert_pem = None
    try:
        proof = json.loads(env.anchor_proof.rekor_inclusion_proof)
        cert_pem = proof.get("certificate_pem")
    except (json.JSONDecodeError, AttributeError):
        pass

    if not cert_pem:
        raise ValueError("No certificate PEM found in inclusion_proof")

    # Load certificate (PEM format).
    try:
        cert = x509.load_pem_x509_certificate(
            cert_pem.encode("utf-8"),
            backend=default_backend(),
        )
    except Exception as e:
        raise ValueError(f"Failed to load certificate: {e}") from e

    # Extract public key and verify signature.
    public_key = cert.public_key()
    if not isinstance(public_key, ec.EllipticCurvePublicKey):
        raise ValueError("Certificate public key is not ECDSA")

    canonical_hash_bytes = bytes.fromhex(canonical_hash_hex)

    try:
        public_key.verify(
            sig_bytes,
            canonical_hash_bytes,
            ec.ECDSA(hashes.SHA256()),
        )
    except Exception as e:
        raise ValueError(f"Signature verification failed: {e}") from e


def _verify_rekor_proof(
    proof_json: str,
    canonical_hash_hex: str,
    signature_b64: str,
    allow_unrooted: bool = False,
    rekor_staging: bool = False,
    rekor_canonical_body_b64: str | None = None,
) -> tuple[int, int]:
    """Verify Rekor inclusion proof (RFC 6962 merkle tree).

    Reconstructs the Rekor hashedrekord v0.0.1 body from the envelope's
    canonical hash, signature, and embedded signing certificate; computes
    the leaf hash as ``sha256(0x00 || canonical_body)``; walks the provided
    sibling hashes; and checks the resulting root matches the proof's claimed
    root. If a signed checkpoint is present (and ``allow_unrooted`` is False),
    additionally verifies the checkpoint's signature against the trusted Rekor
    public key.

    Args:
        proof_json: JSON string with ``{log_index, tree_size, root_hash,
            hashes, certificate_pem, checkpoint?}``.
        canonical_hash_hex: The canonical envelope hash (hex string).
        signature_b64: Base64 of the raw signature bytes (``env.signature``).
        allow_unrooted: If True, skip the log-root trust check. The leaf +
            merkle-walk check still runs — ``--allow-unrooted`` does NOT
            accept a mismatched root.
        rekor_staging: If True, use the staging Rekor public key instead of
            production.

    Returns:
        (log_index, tree_size) if proof is valid.

    Raises:
        ValueError: If the proof is missing fields, the certificate cannot be
            extracted, or the computed root does not match the claimed root.
        RekorTrustError: If the log root is not trusted.
    """
    try:
        proof = json.loads(proof_json)
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid JSON in inclusion proof: {e}") from e

    log_index = proof.get("log_index")
    tree_size = proof.get("tree_size")
    root_hash_hex = proof.get("root_hash")
    hashes = proof.get("hashes", [])
    certificate_pem = proof.get("certificate_pem")

    if log_index is None or tree_size is None or root_hash_hex is None:
        raise ValueError("Inclusion proof missing required fields")

    if not isinstance(log_index, int) or not isinstance(tree_size, int):
        raise ValueError("log_index and tree_size must be integers")

    if log_index >= tree_size:
        raise ValueError(f"log_index ({log_index}) >= tree_size ({tree_size})")

    # Prefer Rekor's authoritative canonical body when present: it's the bytes
    # Rekor itself hashed, so sha256(0x00 || body) is guaranteed to match.
    # Fall back to client-side reconstruction for pre-v2.3.2 envelopes.
    if rekor_canonical_body_b64:
        try:
            canonical_body = base64.b64decode(rekor_canonical_body_b64)
        except Exception as e:
            raise ValueError(
                f"rekor_canonical_body_b64 is not valid base64: {e}"
            ) from e
        leaf_hash = hashlib.sha256(b"\x00" + canonical_body).digest()
    else:
        if not certificate_pem:
            raise ValueError(
                "Inclusion proof missing certificate_pem and envelope has no "
                "rekor_canonical_body_b64; cannot compute the merkle leaf."
            )
        # Reconstruct Rekor's hashedrekord v0.0.1 body and hash it as the merkle leaf.
        leaf_hash = hashedrekord_leaf_hash(
            canonical_hash_hex=canonical_hash_hex,
            signature_b64=signature_b64,
            certificate_pem=certificate_pem,
        )

    # Verify merkle tree inclusion via RFC 6962 proof using sigstore's
    # Trillian-derived implementation (which correctly handles the tree's
    # right border on incomplete trees — our earlier _verify_inclusion walk
    # only worked for simple cases).
    computed_root = _verify_inclusion_trillian(leaf_hash, log_index, tree_size, hashes)

    # Check against the claimed root hash.
    expected_root = bytes.fromhex(root_hash_hex)
    if computed_root != expected_root:
        raise ValueError(
            f"Computed root hash does not match claimed root: "
            f"{computed_root.hex()} != {expected_root.hex()}"
        )

    # Verify checkpoint (signed log-root statement) against Rekor public key.
    if not allow_unrooted:
        checkpoint = proof.get("checkpoint")
        if not checkpoint:
            raise RekorTrustError(
                "No checkpoint in inclusion proof; cannot verify log root. "
                "Set --allow-unrooted to skip root trust check."
            )

        # Sanity-check that a Rekor key file is present on disk (dev guard
        # against running with a stale placeholder); the actual log key used
        # to verify the checkpoint is sourced from sigstore's bundled
        # TrustedRoot inside verify_log_root_signature.
        load_rekor_public_key(staging=rekor_staging)

        try:
            verify_log_root_signature(checkpoint, rekor_staging=rekor_staging)
        except RekorTrustError:
            raise
    else:
        # Warn that we're skipping the log root check.
        print("WARNING: Rekor log root verification skipped (--allow-unrooted).", file=sys.stderr)

    return log_index, tree_size


def _verify_inclusion_trillian(
    leaf_hash: bytes,
    index: int,
    tree_size: int,
    proof_hashes: list[str],
) -> bytes:
    """Compute the Merkle root from a leaf and its RFC 6962 inclusion proof
    using sigstore-python's Trillian-derived implementation.

    Splits the proof into `inner` (path up the tree where siblings are within
    the authenticated range) and `border` (path along the tree's right edge
    where all siblings are left children). This decomposition is what the
    naive bit-walk below gets wrong on incomplete trees — which is every
    non-power-of-two Rekor tree. Delegating to sigstore keeps the crypto
    logic in one place.

    Args:
        leaf_hash: SHA-256 hash of the leaf (32 bytes, already `sha256(0x00 || body)`).
        index: Leaf index in the tree.
        tree_size: Total number of leaves in the tree.
        proof_hashes: List of sibling hashes (hex strings) to combine.

    Returns:
        Computed root hash (bytes).

    Raises:
        ValueError: If the proof is malformed or the hashes count disagrees
            with the inner+border decomposition.
    """
    from sigstore._internal.merkle import (
        _chain_border_right,
        _chain_inner,
        _decomp_inclusion_proof,
    )

    if index >= tree_size:
        raise ValueError(f"Leaf index {index} out of range [0, {tree_size})")

    hash_bytes = [bytes.fromhex(h) for h in proof_hashes]
    inner, border = _decomp_inclusion_proof(index, tree_size)
    if inner + border != len(hash_bytes):
        raise ValueError(
            f"inclusion proof has wrong size: expected {inner + border}, "
            f"got {len(hash_bytes)}"
        )

    intermediate = _chain_inner(leaf_hash, hash_bytes[:inner], index)
    return _chain_border_right(intermediate, hash_bytes[inner:])


def _verify_inclusion(
    leaf_hash: bytes,
    index: int,
    tree_size: int,
    proof_hashes: list[str],
) -> bytes:
    """Deprecated naive RFC 6962 bit-walk.

    Kept so existing unit tests that call it still link; routes to the
    Trillian implementation for correctness. Remove in v2.4 once callers
    migrate.
    """
    return _verify_inclusion_trillian(leaf_hash, index, tree_size, proof_hashes)


def _merkle_hash(left: bytes, right: bytes) -> bytes:
    """Combine two merkle tree nodes (RFC 6962): sha256(0x01 || left || right)."""
    combined = bytes([0x01]) + left + right
    return hashlib.sha256(combined).digest()


def main(argv: list[str] | None = None) -> int:
    """CLI entry point for gtv-verify."""
    argv = argv if argv is not None else sys.argv[1:]

    # Check for --consensus flag first (can have multiple envelope paths)
    if "--consensus" in argv:
        return _consensus_mode(argv)

    # Parse arguments for single envelope verify mode.
    allow_stub = False
    allow_unrooted = False
    trust_issuer = False
    allow_unlisted = False
    offline = False
    rekor_staging = False
    envelope_path = None

    for arg in argv:
        if arg == "--allow-stub":
            allow_stub = True
        elif arg == "--allow-unrooted":
            allow_unrooted = True
        elif arg == "--trust-issuer":
            trust_issuer = True
        elif arg == "--allow-unlisted":
            allow_unlisted = True
        elif arg == "--offline":
            offline = True
        elif arg == "--rekor-staging":
            rekor_staging = True
        elif not arg.startswith("-"):
            envelope_path = arg

    if envelope_path is None:
        print(
            "usage: gtv-verify [--offline] [--allow-stub] [--allow-unrooted] "
            "[--trust-issuer] [--allow-unlisted] [--rekor-staging] <envelope.json>",
            file=sys.stderr,
        )
        return 64

    return verify_file(
        Path(envelope_path),
        allow_stub=allow_stub,
        allow_unrooted=allow_unrooted,
        trust_issuer=trust_issuer,
        allow_unlisted=allow_unlisted,
        offline=offline,
        rekor_staging=rekor_staging,
    )


def _consensus_mode(argv: list[str]) -> int:
    """Handle --consensus mode: read multiple envelopes and compute consensus.

    Usage: gtv-verify --consensus env1.json env2.json [envN.json ...]

    Exit codes:
        0 = success
        1 = mismatched claim_ids or other consensus error
        2 = empty input
        5 = parse/schema error
    """
    # Extract envelope paths (everything after --consensus)
    try:
        consensus_idx = argv.index("--consensus")
        envelope_paths = [Path(p) for p in argv[consensus_idx + 1:] if not p.startswith("-")]
    except (ValueError, IndexError):
        envelope_paths = []

    if not envelope_paths:
        print(
            "usage: gtv-verify --consensus <envelope.json> [envelope.json ...]",
            file=sys.stderr,
        )
        return 2

    # Load and parse all envelopes
    envelopes = []
    for path in envelope_paths:
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            env = Envelope.model_validate(data)
            envelopes.append(env)
        except (json.JSONDecodeError, OSError) as e:
            print(f"ERROR: Failed to read/parse {path}: {e}", file=sys.stderr)
            return 5
        except Exception as e:
            print(f"ERROR: Schema validation failed for {path}: {e}", file=sys.stderr)
            return 5

    if not envelopes:
        return 2

    # Compute consensus
    try:
        from gtv.federation.consensus import compute_consensus

        result = compute_consensus(envelopes)
        print(json.dumps({
            "verdict": result.verdict.value,
            "confidence": result.confidence,
            "tally": [
                {
                    "verdict": t.verdict.value,
                    "weighted_votes": t.weighted_votes,
                    "envelope_count": t.envelope_count,
                }
                for t in result.tally
            ],
            "unknown_dids": result.unknown_dids,
        }))
        return 0
    except ValueError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
