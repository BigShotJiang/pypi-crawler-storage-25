# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""CLI: verify a Rekor transparency-log consistency proof between two checkpoints.

Use-case: pin a Rekor checkpoint today. Tomorrow, fetch a new checkpoint and
prove the log hasn't been forked or rewritten between then and now. If
verification fails, treat every envelope anchored between the two checkpoints
as suspect — the log operator has lost integrity.

Usage
-----

    # Pin today's checkpoint.
    gtv-rekor-check pin --url https://rekor.sigstore.dev --out pinned.json

    # Tomorrow, prove the log still extends that checkpoint.
    gtv-rekor-check verify --pinned pinned.json --url https://rekor.sigstore.dev

    # Or feed both checkpoints + proof from files (no network).
    gtv-rekor-check verify-offline \\
        --first pinned.json --second current.json --proof proof.json

Exit codes:
  0 = log is consistent (or pinned successfully)
  1 = inconsistency detected — log has been forked or rewritten
  2 = argument / I/O error
"""
from __future__ import annotations

import argparse
import json
import sys
from typing import Any

import httpx

from gtv.anchor.consistency import (
    ConsistencyProofError,
    verify_consistency_proof,
)

_REKOR_DEFAULT = "https://rekor.sigstore.dev"


# ---------------------------------------------------------------------------
# Rekor HTTP adapters
# ---------------------------------------------------------------------------

def _fetch_log_info(base_url: str, timeout: float = 10.0) -> dict[str, Any]:
    """GET /api/v1/log — returns current {treeSize, rootHash, signedTreeHead}."""
    resp = httpx.get(
        f"{base_url.rstrip('/')}/api/v1/log",
        timeout=timeout,
        headers={"Accept": "application/json"},
    )
    resp.raise_for_status()
    info: dict[str, Any] = resp.json()
    return info


def _fetch_consistency(
    base_url: str,
    *,
    first_size: int,
    last_size: int,
    tree_id: str | None = None,
    timeout: float = 10.0,
) -> dict[str, Any]:
    """GET /api/v1/log/proof?firstSize=m&lastSize=n — returns {rootHash, hashes[]}."""
    params: dict[str, str] = {
        "firstSize": str(first_size),
        "lastSize": str(last_size),
    }
    if tree_id:
        params["treeID"] = tree_id
    resp = httpx.get(
        f"{base_url.rstrip('/')}/api/v1/log/proof",
        params=params,
        timeout=timeout,
        headers={"Accept": "application/json"},
    )
    resp.raise_for_status()
    data: dict[str, Any] = resp.json()
    return data


# ---------------------------------------------------------------------------
# Subcommands
# ---------------------------------------------------------------------------

def cmd_pin(args: argparse.Namespace) -> int:
    info = _fetch_log_info(args.url, timeout=args.timeout)
    record = {
        "url": args.url,
        "tree_size": info["treeSize"],
        "root_hash": info["rootHash"],  # hex
        "tree_id": info.get("treeID"),
    }
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(record, f, indent=2, sort_keys=True)
    print(
        f"Pinned Rekor checkpoint: tree_size={record['tree_size']} "
        f"root={record['root_hash'][:16]}… → {args.out}"
    )
    return 0


def cmd_verify(args: argparse.Namespace) -> int:
    with open(args.pinned, encoding="utf-8") as f:
        pinned = json.load(f)

    first_size = int(pinned["tree_size"])
    first_root_hex = pinned["root_hash"]
    tree_id = pinned.get("tree_id")

    # Fetch current state.
    info = _fetch_log_info(args.url, timeout=args.timeout)
    second_size = int(info["treeSize"])
    second_root_hex = info["rootHash"]

    if second_size < first_size:
        print(
            f"ERROR: current Rekor tree_size ({second_size}) is smaller than "
            f"pinned tree_size ({first_size}) — log has been truncated.",
            file=sys.stderr,
        )
        return 1

    if second_size == first_size:
        if second_root_hex != first_root_hex:
            print(
                "ERROR: tree_size unchanged but root_hash differs — log rewritten.",
                file=sys.stderr,
            )
            return 1
        print(
            f"OK: Rekor checkpoint unchanged at tree_size={second_size}."
        )
        return 0

    proof_resp = _fetch_consistency(
        args.url,
        first_size=first_size,
        last_size=second_size,
        tree_id=tree_id,
        timeout=args.timeout,
    )
    proof_hex: list[str] = proof_resp.get("hashes", [])
    proof = [bytes.fromhex(h) for h in proof_hex]

    try:
        verify_consistency_proof(
            first_size=first_size,
            second_size=second_size,
            first_root=bytes.fromhex(first_root_hex),
            second_root=bytes.fromhex(second_root_hex),
            proof=proof,
        )
    except ConsistencyProofError as e:
        print(f"ERROR: consistency proof failed: {e}", file=sys.stderr)
        return 1

    print(
        f"OK: Rekor log extended from size {first_size} → {second_size} "
        f"({len(proof)} proof hashes verified)."
    )
    return 0


def cmd_verify_offline(args: argparse.Namespace) -> int:
    with open(args.first, encoding="utf-8") as f:
        first = json.load(f)
    with open(args.second, encoding="utf-8") as f:
        second = json.load(f)
    with open(args.proof, encoding="utf-8") as f:
        proof_data = json.load(f)

    proof_hex: list[str] = proof_data.get("hashes") or proof_data.get("proof") or []

    try:
        verify_consistency_proof(
            first_size=int(first["tree_size"]),
            second_size=int(second["tree_size"]),
            first_root=bytes.fromhex(first["root_hash"]),
            second_root=bytes.fromhex(second["root_hash"]),
            proof=[bytes.fromhex(h) for h in proof_hex],
        )
    except ConsistencyProofError as e:
        print(f"ERROR: consistency proof failed: {e}", file=sys.stderr)
        return 1

    print(
        f"OK: Rekor log extended from size {first['tree_size']} "
        f"→ {second['tree_size']} ({len(proof_hex)} proof hashes verified)."
    )
    return 0


# ---------------------------------------------------------------------------
# Arg parsing
# ---------------------------------------------------------------------------

def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="gtv-rekor-check",
        description="Verify Rekor transparency-log consistency between two checkpoints.",
    )
    sub = p.add_subparsers(dest="command", required=True)

    pin = sub.add_parser("pin", help="Fetch current Rekor checkpoint and save to file.")
    pin.add_argument("--url", default=_REKOR_DEFAULT, help="Rekor base URL")
    pin.add_argument("--timeout", type=float, default=10.0)
    pin.add_argument("--out", required=True, help="Path to write pinned checkpoint JSON")
    pin.set_defaults(func=cmd_pin)

    v = sub.add_parser(
        "verify", help="Verify consistency from a pinned checkpoint to current Rekor state."
    )
    v.add_argument("--pinned", required=True, help="Path to pinned checkpoint JSON")
    v.add_argument("--url", default=_REKOR_DEFAULT, help="Rekor base URL")
    v.add_argument("--timeout", type=float, default=10.0)
    v.set_defaults(func=cmd_verify)

    vo = sub.add_parser(
        "verify-offline",
        help="Verify consistency from pre-fetched checkpoint/proof files (no network).",
    )
    vo.add_argument("--first", required=True, help="First (earlier) checkpoint JSON")
    vo.add_argument("--second", required=True, help="Second (later) checkpoint JSON")
    vo.add_argument("--proof", required=True, help="Proof JSON (from /api/v1/log/proof)")
    vo.set_defaults(func=cmd_verify_offline)

    return p


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)
    try:
        return int(args.func(args))
    except httpx.HTTPError as e:
        print(f"ERROR: Rekor HTTP request failed: {e}", file=sys.stderr)
        return 2
    except (OSError, ValueError, KeyError) as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
