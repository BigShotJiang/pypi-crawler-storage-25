# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""``gtv-usage`` — read the per-tenant usage aggregate written by the
billing/metering layer (W34).

Subcommands
-----------
* ``gtv-usage report [--tenant T] [--tool X] [--since YYYY-MM-DD] [--until YYYY-MM-DD] [--format table|csv|json]``
* ``gtv-usage totals [--since YYYY-MM-DD] [--until YYYY-MM-DD]``

Both subcommands read the SQLite DB at ``GTV_BILLING_DB`` (or
``--db-path``). If no DB is configured the commands exit cleanly with
"no usage recorded" — billing is opt-in, so an unconfigured operator
isn't an error.

This CLI is read-only. Writes happen exclusively from the request
handler hook in ``gtv.mcp.server`` so that one tenant DB == one
write source.
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import sys
from datetime import date
from pathlib import Path

from gtv.billing.store import UsageRow, UsageStore


def _parse_date(s: str | None) -> date | None:
    if s is None:
        return None
    return date.fromisoformat(s)


def _open_store(db_path: str | None) -> UsageStore | None:
    """Resolve the DB path: CLI flag > env var > none.

    Returns ``None`` if no DB is configured AND the candidate path
    doesn't exist on disk — callers print "no usage recorded" rather
    than auto-creating an empty file.
    """
    candidate = db_path or os.environ.get("GTV_BILLING_DB")
    if not candidate:
        return None
    if candidate != ":memory:" and not Path(candidate).expanduser().exists():
        return None
    return UsageStore(str(Path(candidate).expanduser()))


def _print_table(rows: list[UsageRow]) -> None:
    if not rows:
        print("No usage recorded.")
        return
    cols = ("day", "tenant_id", "issuer_did", "tool", "count")
    widths = {c: len(c) for c in cols}
    for r in rows:
        for c in cols:
            widths[c] = max(widths[c], len(str(getattr(r, c))))
    header = "  ".join(c.ljust(widths[c]) for c in cols)
    print(header)
    print("-" * len(header))
    for r in rows:
        print("  ".join(str(getattr(r, c)).ljust(widths[c]) for c in cols))


def _print_csv(rows: list[UsageRow]) -> None:
    writer = csv.writer(sys.stdout)
    writer.writerow(["day", "tenant_id", "issuer_did", "tool", "count"])
    for r in rows:
        writer.writerow([r.day, r.tenant_id, r.issuer_did, r.tool, r.count])


def _print_json(rows: list[UsageRow]) -> None:
    payload = [
        {
            "day": r.day,
            "tenant_id": r.tenant_id,
            "issuer_did": r.issuer_did,
            "tool": r.tool,
            "count": r.count,
        }
        for r in rows
    ]
    json.dump(payload, sys.stdout, indent=2)
    sys.stdout.write("\n")


def cmd_report(args: argparse.Namespace) -> int:
    store = _open_store(args.db_path)
    if store is None:
        print("No usage recorded.")
        return 0
    rows = store.query(
        tenant_id=args.tenant,
        tool=args.tool,
        since=_parse_date(args.since),
        until=_parse_date(args.until),
    )
    if args.format == "csv":
        _print_csv(rows)
    elif args.format == "json":
        _print_json(rows)
    else:
        _print_table(rows)
    return 0


def cmd_totals(args: argparse.Namespace) -> int:
    store = _open_store(args.db_path)
    if store is None:
        print("No usage recorded.")
        return 0
    totals = store.totals_by_tenant(
        since=_parse_date(args.since),
        until=_parse_date(args.until),
    )
    if not totals:
        print("No usage recorded in window.")
        return 0
    width = max(len(t) for t in totals) if totals else 0
    width = max(width, len("tenant_id"))
    print(f"{'tenant_id'.ljust(width)}  total_calls")
    print("-" * (width + 14))
    for tenant, total in totals.items():
        print(f"{tenant.ljust(width)}  {total}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="gtv-usage",
        description="Per-tenant billing/metering reports.",
    )
    parser.add_argument(
        "--db-path",
        help="Path to billing DB (default: $GTV_BILLING_DB).",
    )
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_report = sub.add_parser(
        "report", help="Per-(tenant, tool, day) usage rows."
    )
    p_report.add_argument("--tenant", help="Filter to a single tenant.")
    p_report.add_argument("--tool", help="Filter to a single tool.")
    p_report.add_argument("--since", help="ISO date (inclusive).")
    p_report.add_argument("--until", help="ISO date (inclusive).")
    p_report.add_argument(
        "--format",
        choices=("table", "csv", "json"),
        default="table",
        help="Output format (default: table).",
    )
    p_report.set_defaults(func=cmd_report)

    p_totals = sub.add_parser(
        "totals", help="Total calls per tenant in the window."
    )
    p_totals.add_argument("--since", help="ISO date (inclusive).")
    p_totals.add_argument("--until", help="ISO date (inclusive).")
    p_totals.set_defaults(func=cmd_totals)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
