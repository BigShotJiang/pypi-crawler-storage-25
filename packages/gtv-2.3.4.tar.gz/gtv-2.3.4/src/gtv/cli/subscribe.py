# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""CLI for managing claim subscriptions and webhook callbacks.

Usage: gtv-subscribe add <claim> --webhook <url> [--interval 3600] [--db-path ~/.gtv/subscriptions.db]
       gtv-subscribe list [--db-path ~/.gtv/subscriptions.db]
       gtv-subscribe remove <id> [--db-path ~/.gtv/subscriptions.db]
       gtv-subscribe run [--db-path ~/.gtv/subscriptions.db]

The subscribe command uses SQLite for persistence. Default location: ~/.gtv/subscriptions.db
"""
from __future__ import annotations

import asyncio
import sys
from pathlib import Path

import structlog

from gtv.subscribe import Subscription, SubscriptionEngine
from gtv.subscribe.store import SubscriptionStore

logger = structlog.get_logger(__name__)


def cmd_add(claim: str, webhook: str, interval_s: int = 3600, db_path: Path | None = None) -> None:
    """Add a new subscription."""
    store = SubscriptionStore(db_path or "~/.gtv/subscriptions.db")
    sub = Subscription(
        id=str(__import__("uuid").uuid4()),
        claim=claim,
        webhook_url=webhook,
        interval_s=interval_s,
    )
    store.add(sub)
    store.close()
    print(f"Added subscription {sub.id}")
    print(f"  Claim: {claim}")
    print(f"  Webhook: {webhook}")
    print(f"  Interval: {interval_s}s")


def cmd_list(db_path: Path | None = None) -> None:
    """List all subscriptions."""
    store = SubscriptionStore(db_path or "~/.gtv/subscriptions.db")
    subs = store.list_all()
    store.close()

    if not subs:
        print("No subscriptions.")
        return
    for sub in subs:
        status = "pending" if sub.last_verdict is None else f"{sub.last_verdict}"
        print(f"{sub.id} | {sub.claim[:50]:50} | {status:12} | {sub.interval_s}s")


def cmd_remove(sub_id: str, db_path: Path | None = None) -> None:
    """Remove a subscription by id."""
    store = SubscriptionStore(db_path or "~/.gtv/subscriptions.db")
    found = store.remove(sub_id)
    store.close()

    if found:
        print(f"Removed subscription {sub_id}")
    else:
        print(f"Subscription {sub_id} not found.")
        sys.exit(1)


def cmd_run(db_path: Path | None = None) -> None:
    """Run the polling engine forever."""
    engine = SubscriptionEngine(store_path=db_path or "~/.gtv/subscriptions.db")
    print(f"Starting engine with {len(engine.list_all())} subscriptions...")
    asyncio.run(engine.run_forever())


def main() -> None:
    """CLI entrypoint."""
    import argparse

    parser = argparse.ArgumentParser(description="Manage claim subscriptions and webhooks")
    subparsers = parser.add_subparsers(dest="cmd", help="Command")

    # add
    p_add = subparsers.add_parser("add", help="Add a subscription")
    p_add.add_argument("claim", help="Claim text")
    p_add.add_argument("--webhook", required=True, help="Webhook URL")
    p_add.add_argument("--interval", type=int, default=3600, help="Polling interval in seconds")
    p_add.add_argument("--db-path", type=Path, help="Path to subscriptions database")

    # list
    p_list = subparsers.add_parser("list", help="List subscriptions")
    p_list.add_argument("--db-path", type=Path, help="Path to subscriptions database")

    # remove
    p_remove = subparsers.add_parser("remove", help="Remove a subscription")
    p_remove.add_argument("id", help="Subscription ID")
    p_remove.add_argument("--db-path", type=Path, help="Path to subscriptions database")

    # run
    p_run = subparsers.add_parser("run", help="Run the polling engine")
    p_run.add_argument("--db-path", type=Path, help="Path to subscriptions database")

    args = parser.parse_args()

    if args.cmd == "add":
        cmd_add(args.claim, args.webhook, args.interval, args.db_path)
    elif args.cmd == "list":
        cmd_list(args.db_path)
    elif args.cmd == "remove":
        cmd_remove(args.id, args.db_path)
    elif args.cmd == "run":
        cmd_run(args.db_path)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
