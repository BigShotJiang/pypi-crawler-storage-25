# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""BYOK envelope signer CLI.

Usage: gtv-sign-byok --key mykey.pem --envelope draft.json --out signed.json

Reads a draft envelope JSON, signs it with a private key PEM, and writes the
signed envelope (with signature and issuer_did populated) to the output file.

Note: This CLI requires that the console-script entry be added to pyproject.toml:
  gtv-sign-byok = "gtv.cli.sign:main"

Exit codes:
  0 = success
  2 = missing required argument
  3 = input file not found
  4 = invalid JSON or envelope schema
  5 = invalid private key PEM
  6 = signing failed
  7 = output write failed
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

from gtv.models import Envelope
from gtv.sign import sign_envelope_byok


def main(argv: list[str] | None = None) -> int:
    """CLI entry point for gtv-sign-byok.

    Args:
        argv: Command-line arguments (defaults to sys.argv[1:])

    Returns:
        Exit code (0 = success, non-zero = error)
    """
    argv = argv if argv is not None else sys.argv[1:]

    # Parse arguments
    key_pem_path = None
    envelope_path = None
    out_path = None

    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "--key" and i + 1 < len(argv):
            key_pem_path = argv[i + 1]
            i += 2
        elif arg == "--envelope" and i + 1 < len(argv):
            envelope_path = argv[i + 1]
            i += 2
        elif arg == "--out" and i + 1 < len(argv):
            out_path = argv[i + 1]
            i += 2
        else:
            i += 1

    # Validate required arguments
    if not key_pem_path or not envelope_path or not out_path:
        print(
            "usage: gtv-sign-byok --key <key.pem> --envelope <draft.json> --out <signed.json>",
            file=sys.stderr,
        )
        return 2

    # Load private key PEM
    try:
        key_path = Path(key_pem_path)
        if not key_path.exists():
            print(f"ERROR: Private key file not found: {key_path}", file=sys.stderr)
            return 3
        key_pem_bytes = key_path.read_bytes()
    except OSError as e:
        print(f"ERROR: Failed to read private key file: {e}", file=sys.stderr)
        return 3

    # Load envelope JSON
    try:
        env_path = Path(envelope_path)
        if not env_path.exists():
            print(f"ERROR: Envelope file not found: {env_path}", file=sys.stderr)
            return 3
        env_data = json.loads(env_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        print(f"ERROR: Invalid JSON in envelope file: {e}", file=sys.stderr)
        return 4
    except OSError as e:
        print(f"ERROR: Failed to read envelope file: {e}", file=sys.stderr)
        return 3

    # Validate envelope schema
    try:
        env = Envelope.model_validate(env_data)
    except Exception as e:
        print(f"ERROR: Envelope schema validation failed: {e}", file=sys.stderr)
        return 4

    # Sign the envelope
    try:
        signed_env = sign_envelope_byok(env, key_pem_bytes)
    except ValueError as e:
        print(f"ERROR: Signing failed: {e}", file=sys.stderr)
        return 6
    except Exception as e:
        print(f"ERROR: Unexpected error during signing: {e}", file=sys.stderr)
        return 6

    # Write signed envelope
    try:
        out_file = Path(out_path)
        out_file.parent.mkdir(parents=True, exist_ok=True)
        signed_json = signed_env.model_dump_json(indent=2)
        out_file.write_text(signed_json, encoding="utf-8")
    except OSError as e:
        print(f"ERROR: Failed to write output file: {e}", file=sys.stderr)
        return 7

    print(f"Signed envelope written to: {out_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
