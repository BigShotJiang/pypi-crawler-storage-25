# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Revocation list CLI.

Commands:
- gtv-revoke create: Build and sign a revocation list
- gtv-revoke verify: Verify a revocation list signature
- gtv-revoke check: Check if an envelope is revoked

Entry point: gtv-revoke
Note: Console script added to pyproject.toml by orchestrator.

Exit codes:
  0 = success
  2 = missing required argument / invalid command
  3 = file not found
  4 = invalid JSON or schema
  5 = invalid private key PEM
  6 = operation failed
  7 = output write failed
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

from gtv.models import Envelope
from gtv.revocation import RevocationList
from gtv.revocation.check import is_revoked
from gtv.revocation.list import build_revocation_list, verify_revocation_list


def create_cmd(argv: list[str]) -> int:
    """Build and sign a revocation list.

    Usage:
      gtv-revoke create --issuer-did <did> --key <pem> [--envelope-id ...] [--issuer-did-revoke ...] [--rekor-index ...] --out <file>
    """
    issuer_did = None
    key_path = None
    envelope_ids = []
    issuer_dids = []
    rekor_indices = []
    out_path = None

    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "--issuer-did" and i + 1 < len(argv):
            issuer_did = argv[i + 1]
            i += 2
        elif arg == "--key" and i + 1 < len(argv):
            key_path = argv[i + 1]
            i += 2
        elif arg == "--envelope-id" and i + 1 < len(argv):
            envelope_ids.append(argv[i + 1])
            i += 2
        elif arg == "--issuer-did-revoke" and i + 1 < len(argv):
            issuer_dids.append(argv[i + 1])
            i += 2
        elif arg == "--rekor-index" and i + 1 < len(argv):
            try:
                rekor_indices.append(int(argv[i + 1]))
            except ValueError:
                print(
                    f"ERROR: Invalid Rekor index (must be int): {argv[i + 1]}",
                    file=sys.stderr,
                )
                return 6
            i += 2
        elif arg == "--out" and i + 1 < len(argv):
            out_path = argv[i + 1]
            i += 2
        else:
            i += 1

    if not issuer_did or not key_path or not out_path:
        print(
            "usage: gtv-revoke create --issuer-did <did> --key <pem> "
            "[--envelope-id ...] [--issuer-did-revoke ...] [--rekor-index ...] --out <file>",
            file=sys.stderr,
        )
        return 2

    # Load and build revocation list
    try:
        key_file = Path(key_path)
        if not key_file.exists():
            print(f"ERROR: Private key file not found: {key_file}", file=sys.stderr)
            return 3
        rl = build_revocation_list(
            issuer_did=issuer_did,
            envelope_ids=envelope_ids,
            issuer_dids=issuer_dids,
            rekor_indices=rekor_indices,
            private_key_path=key_file,
        )
    except FileNotFoundError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 3
    except ValueError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 5 if "key" in str(e).lower() else 6

    # Write revocation list
    try:
        out_file = Path(out_path)
        out_file.parent.mkdir(parents=True, exist_ok=True)
        out_file.write_text(rl.model_dump_json(indent=2), encoding="utf-8")
    except OSError as e:
        print(f"ERROR: Failed to write output file: {e}", file=sys.stderr)
        return 7

    print(f"Revocation list written to: {out_path}")
    return 0


def verify_cmd(argv: list[str]) -> int:
    """Verify a revocation list signature.

    Usage:
      gtv-revoke verify <file>
    """
    if not argv:
        print("usage: gtv-revoke verify <file>", file=sys.stderr)
        return 2

    file_path = argv[0]

    try:
        file = Path(file_path)
        if not file.exists():
            print(f"ERROR: File not found: {file}", file=sys.stderr)
            return 3
        rl_data = json.loads(file.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        print(f"ERROR: Invalid JSON: {e}", file=sys.stderr)
        return 4
    except OSError as e:
        print(f"ERROR: Failed to read file: {e}", file=sys.stderr)
        return 3

    try:
        rl = RevocationList.model_validate(rl_data)
    except Exception as e:
        print(f"ERROR: Invalid RevocationList schema: {e}", file=sys.stderr)
        return 4

    if verify_revocation_list(rl):
        print("valid")
        return 0
    else:
        print("invalid")
        return 1


def check_cmd(argv: list[str]) -> int:
    """Check if an envelope is revoked.

    Usage:
      gtv-revoke check --envelope <envelope.json> --list <list.json> [--list ...]
    """
    envelope_path = None
    list_paths = []

    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "--envelope" and i + 1 < len(argv):
            envelope_path = argv[i + 1]
            i += 2
        elif arg == "--list" and i + 1 < len(argv):
            list_paths.append(argv[i + 1])
            i += 2
        else:
            i += 1

    if not envelope_path or not list_paths:
        print(
            "usage: gtv-revoke check --envelope <envelope.json> --list <list.json> [--list ...]",
            file=sys.stderr,
        )
        return 2

    # Load envelope
    try:
        env_file = Path(envelope_path)
        if not env_file.exists():
            print(f"ERROR: Envelope file not found: {env_file}", file=sys.stderr)
            return 3
        env_data = json.loads(env_file.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        print(f"ERROR: Invalid JSON in envelope: {e}", file=sys.stderr)
        return 4
    except OSError as e:
        print(f"ERROR: Failed to read envelope: {e}", file=sys.stderr)
        return 3

    try:
        envelope = Envelope.model_validate(env_data)
    except Exception as e:
        print(f"ERROR: Invalid Envelope schema: {e}", file=sys.stderr)
        return 4

    # Load revocation lists
    lists = []
    for list_path in list_paths:
        try:
            list_file = Path(list_path)
            if not list_file.exists():
                print(f"ERROR: List file not found: {list_file}", file=sys.stderr)
                return 3
            list_data = json.loads(list_file.read_text(encoding="utf-8"))
        except json.JSONDecodeError as e:
            print(f"ERROR: Invalid JSON in list: {e}", file=sys.stderr)
            return 4
        except OSError as e:
            print(f"ERROR: Failed to read list: {e}", file=sys.stderr)
            return 3

        try:
            rl = RevocationList.model_validate(list_data)
            lists.append(rl)
        except Exception as e:
            print(f"ERROR: Invalid RevocationList schema: {e}", file=sys.stderr)
            return 4

    # Check revocation status
    status = is_revoked(envelope, lists)
    if status.revoked:
        print(f"revoked: {status.reason} (list: {status.revoked_by_list_id})")
        return 1
    else:
        print("not_revoked")
        return 0


def main(argv: list[str] | None = None) -> int:
    """CLI entry point for gtv-revoke.

    Dispatches to subcommands: create, verify, check.
    """
    argv = argv if argv is not None else sys.argv[1:]

    if not argv or argv[0] in ("-h", "--help"):
        print(
            "usage: gtv-revoke <create|verify|check> ...\n"
            "\n"
            "Commands:\n"
            "  create   Build and sign a revocation list\n"
            "  verify   Verify a revocation list signature\n"
            "  check    Check if an envelope is revoked",
        )
        return 0 if argv and argv[0] in ("-h", "--help") else 2

    cmd = argv[0]
    cmd_argv = argv[1:]

    if cmd == "create":
        return create_cmd(cmd_argv)
    elif cmd == "verify":
        return verify_cmd(cmd_argv)
    elif cmd == "check":
        return check_cmd(cmd_argv)
    else:
        print(f"ERROR: Unknown command: {cmd}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
