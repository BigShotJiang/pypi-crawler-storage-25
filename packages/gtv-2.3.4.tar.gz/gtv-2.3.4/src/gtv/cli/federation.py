# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Operator CLI for federation peer management and health probing.

Subcommands:
  gtv-fed peers list              — list all configured peers (env + discovered)
  gtv-fed peers discover          — resolve GTV_FEDERATION_ROOT_DID and print discovered peers
  gtv-fed peers health <did>      — health probe a specific peer
  gtv-fed peers revoke <did>      — mark a peer as revoked locally

All commands work with federation peers loaded from GTV_FEDERATION_PEERS env var
and discovered via GTV_FEDERATION_ROOT_DID.

Output:
  text (default) — human-readable table
  --json         — machine-readable JSON

Exit codes:
  0 success
  1 user error (bad args, missing env, peer not found)
  2 operational error (peer unreachable, network error)
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import sys
import time
from pathlib import Path
from typing import Any

import httpx

from gtv.federation.discovery import discover_peers_from_did, load_discovery_config_from_env
from gtv.federation.peer import load_peers_from_env

logger = logging.getLogger(__name__)

DEFAULT_TIMEOUT = 3.0


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _revoked_peers_path() -> Path:
    """Get the path to the revoked peers JSON file."""
    custom_path = os.environ.get("GTV_REVOKED_PEERS_PATH")
    if custom_path:
        return Path(custom_path).expanduser()
    return Path.home() / ".gtv" / "revoked_peers.json"


def _load_revoked_peers() -> set[str]:
    """Load the set of revoked peer DIDs from local storage."""
    path = _revoked_peers_path()
    if not path.exists():
        return set()
    try:
        data = json.loads(path.read_text())
        return set(data.get("revoked_dids", []))
    except Exception as e:
        logger.warning(f"Failed to load revoked peers: {e}")
        return set()


def _save_revoked_peers(revoked: set[str]) -> None:
    """Save the set of revoked peer DIDs to local storage."""
    path = _revoked_peers_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    data = {"revoked_dids": sorted(revoked)}
    path.write_text(json.dumps(data, indent=2))


async def _discover_peers_async() -> list[Any]:
    """Discover peers from GTV_FEDERATION_ROOT_DID."""
    root_did = load_discovery_config_from_env()
    if not root_did:
        return []
    try:
        async with httpx.AsyncClient(timeout=DEFAULT_TIMEOUT) as client:
            peers = await discover_peers_from_did(root_did, client=client)
        return peers
    except Exception as e:
        logger.warning(f"Failed to discover peers: {e}")
        return []


def _format_peers_table(peers: list[Any]) -> str:
    """Format peers as a human-readable table."""
    if not peers:
        return "(no peers)"

    # Header
    lines = [
        f"{'DID':45} | {'Endpoint URL':40} | {'Source':8} | {'Verified':8}"
    ]
    lines.append("-" * 110)

    for peer in peers:
        did = getattr(peer, "did", "?")[:45]
        endpoint = getattr(peer, "endpoint_url", getattr(peer, "url", "?"))[:40]
        source = getattr(peer, "discovered_via", "env")
        verified = "yes" if getattr(peer, "verified", False) else "no"
        lines.append(f"{did:45} | {endpoint:40} | {source:8} | {verified:8}")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Commands: peers
# ---------------------------------------------------------------------------


def cmd_peers_list(args: Any) -> int:
    """List all configured peers."""
    # Load env peers synchronously
    env_peers = load_peers_from_env()

    # Discover peers async
    discovered_peers = asyncio.run(_discover_peers_async())

    # Merge (env takes precedence)
    env_by_did = {p.did: p for p in env_peers}
    all_peers = list(env_by_did.values())
    for d_peer in discovered_peers:
        if d_peer.did not in env_by_did:
            all_peers.append(d_peer)

    # Filter out revoked peers unless --all is set
    revoked = _load_revoked_peers()
    if not args.all:
        all_peers = [p for p in all_peers if getattr(p, "did", None) not in revoked]

    if args.json:
        output = [
            {
                "did": getattr(p, "did", "?"),
                "endpoint_url": getattr(p, "endpoint_url", getattr(p, "url", "?")),
                "source": getattr(p, "discovered_via", "env"),
                "verified": getattr(p, "verified", False),
            }
            for p in all_peers
        ]
        print(json.dumps(output, indent=2))
        return 0

    print(f"Peers ({len(all_peers)} total):")
    print()
    print(_format_peers_table(all_peers))
    return 0


def cmd_peers_discover(args: Any) -> int:
    """Discover peers from GTV_FEDERATION_ROOT_DID."""
    root_did = load_discovery_config_from_env()
    if not root_did:
        print("ERROR: GTV_FEDERATION_ROOT_DID not set", file=sys.stderr)
        return 1

    discovered = asyncio.run(_discover_peers_async())

    if args.json:
        output = [
            {
                "did": p.did,
                "endpoint_url": p.endpoint_url,
                "discovered_via": p.discovered_via,
                "verified": p.verified,
                "api_key": p.api_key if hasattr(p, "api_key") else None,
            }
            for p in discovered
        ]
        print(json.dumps(output, indent=2))
        return 0

    if not discovered:
        print(f"No peers discovered from {root_did}")
        return 0

    print(f"Discovered {len(discovered)} peer(s) from {root_did}:")
    print()
    print(_format_peers_table(discovered))
    return 0


async def _health_probe_async(peer_url: str, timeout: float = DEFAULT_TIMEOUT) -> tuple[int | None, float]:
    """Probe a peer's /healthz endpoint and measure latency."""
    start = time.time()
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            resp = await client.get(f"{peer_url}/healthz")
        latency = time.time() - start
        return resp.status_code, latency
    except Exception as e:
        logger.warning(f"Health probe failed: {e}")
        return None, time.time() - start


def cmd_peers_health(args: Any) -> int:
    """Health probe a specific peer."""
    # Find the peer by DID
    env_peers = load_peers_from_env()
    discovered_peers = asyncio.run(_discover_peers_async())

    target_peer = None
    for p in env_peers:
        if p.did == args.did:
            target_peer = p
            break
    if not target_peer:
        for p in discovered_peers:
            if p.did == args.did:
                target_peer = p
                break

    if not target_peer:
        print(f"ERROR: Peer not found: {args.did}", file=sys.stderr)
        return 1

    # Probe health
    peer_url = getattr(target_peer, "url", None) or getattr(target_peer, "endpoint_url", None)
    if not peer_url:
        print("ERROR: Peer has no endpoint URL", file=sys.stderr)
        return 1

    status_code, latency = asyncio.run(_health_probe_async(peer_url))

    if args.json:
        output = {
            "did": args.did,
            "endpoint_url": peer_url,
            "status_code": status_code,
            "latency_ms": round(latency * 1000, 2),
        }
        print(json.dumps(output, indent=2))
        return 0

    if status_code is None:
        print(f"Health probe failed: {args.did} at {peer_url}")
        return 2

    print(f"Health check for {args.did}:")
    print(f"  Endpoint:    {peer_url}")
    print(f"  Status code: {status_code}")
    print(f"  Latency:     {latency * 1000:.2f}ms")
    return 0 if status_code == 200 else 1


def cmd_peers_revoke(args: Any) -> int:
    """Mark a peer as revoked locally."""
    # Find the peer (validate it exists)
    env_peers = load_peers_from_env()
    discovered_peers = asyncio.run(_discover_peers_async())

    target_found = False
    for p in env_peers:
        if p.did == args.did:
            target_found = True
            break
    if not target_found:
        for p in discovered_peers:
            if p.did == args.did:
                target_found = True
                break

    if not target_found:
        print(f"ERROR: Peer not found: {args.did}", file=sys.stderr)
        return 1

    # Add to revoked set and persist
    revoked = _load_revoked_peers()
    if args.did in revoked:
        print(f"Peer already revoked: {args.did}")
        return 0

    revoked.add(args.did)
    _save_revoked_peers(revoked)

    if args.json:
        print(json.dumps({"did": args.did, "status": "revoked"}))
        return 0

    print(f"Revoked peer: {args.did}")
    return 0


# ---------------------------------------------------------------------------
# Parser + entry point
# ---------------------------------------------------------------------------


def _build_parser() -> Any:
    """Build the argument parser."""
    import argparse

    p = argparse.ArgumentParser(
        prog="gtv-fed",
        description="Operator CLI for federation peer management.",
    )
    p.add_argument(
        "--json",
        action="store_true",
        help="Emit output as JSON instead of human-readable text.",
    )

    sub = p.add_subparsers(dest="cmd", required=True)

    # peers
    p_peers = sub.add_parser("peers", help="Manage federation peers.")
    p_peers_sub = p_peers.add_subparsers(dest="peers_cmd", required=True)

    # peers list
    p_peers_list = p_peers_sub.add_parser("list", help="List all configured peers.")
    p_peers_list.add_argument(
        "--all",
        action="store_true",
        help="Include revoked peers (default: only active peers).",
    )
    p_peers_list.set_defaults(func=cmd_peers_list)

    # peers discover
    p_peers_disc = p_peers_sub.add_parser("discover", help="Discover peers from root DID.")
    p_peers_disc.set_defaults(func=cmd_peers_discover)

    # peers health
    p_peers_health = p_peers_sub.add_parser("health", help="Health probe a peer.")
    p_peers_health.add_argument("did", help="Peer DID to probe.")
    p_peers_health.set_defaults(func=cmd_peers_health)

    # peers revoke
    p_peers_revoke = p_peers_sub.add_parser("revoke", help="Revoke a peer locally.")
    p_peers_revoke.add_argument("did", help="Peer DID to revoke.")
    p_peers_revoke.set_defaults(func=cmd_peers_revoke)

    return p


def main(argv: list[str] | None = None) -> int:
    """CLI entry point."""
    argv = argv if argv is not None else sys.argv[1:]
    parser = _build_parser()

    try:
        args = parser.parse_args(argv)
    except SystemExit as e:
        return e.code if isinstance(e.code, int) else 2

    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
