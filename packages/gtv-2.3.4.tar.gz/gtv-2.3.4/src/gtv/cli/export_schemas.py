# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Export OpenAPI + JSON Schema artifacts for the public gtv contract.

This freezes the public machine-readable contract so agent authors and
integrators have a stable reference. Source of truth is:

  * FastAPI app     -> ``spec/openapi.gen.json``
  * Pydantic models -> ``spec/schemas/<Model>.gen.json``

Two modes:

  * default / ``write``  — regenerate artifacts on disk.
  * ``check``            — regenerate in memory and exit non-zero if any
                            artifact drifted. Intended for CI.

The ``.gen.json`` suffix distinguishes generated artifacts from the
curated hand-written ``spec/schemas/*.json`` that describe the MCP tool
advertisement contract.
"""
from __future__ import annotations

import argparse
import json
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from pydantic import BaseModel


# Models that form the public wire contract. Each produces a
# ``<Model>.gen.json`` in spec/schemas/. Keep this list sorted to make
# drift diffs cleaner.
def _collect_public_models() -> tuple[tuple[type[BaseModel], str], ...]:
    """Collect the set of models that belong to the public contract.

    Each entry is (model, mode). ``mode`` is ``"validation"`` for models
    that appear on the request side (what a client may send) and
    ``"serialization"`` for models that appear on the response side
    (what the server always emits).

    The distinction matters because pydantic marks fields with a
    ``default_factory`` as *optional* in validation-mode schemas but as
    *required* in serialization-mode schemas. For response contracts we
    want the latter: clients can rely on e.g. ``envelope_id`` always
    being present.

    Imported lazily to keep ``--help`` fast and to avoid a hard import
    cycle if this module is executed before the FastAPI app is built.
    """
    from gtv.models import (
        AnchorProof,
        Claim,
        Envelope,
        Evidence,
        FactItem,
        HealthStatus,
        RetrieveFactsEnvelope,
        RetrieveFactsRequest,
        VerdictRecord,
        VerifyClaimRequest,
    )

    return (
        # Response / record models — server always fills defaults.
        (AnchorProof, "serialization"),
        (Claim, "serialization"),
        (Envelope, "serialization"),
        (Evidence, "serialization"),
        (FactItem, "serialization"),
        (HealthStatus, "serialization"),
        (RetrieveFactsEnvelope, "serialization"),
        (VerdictRecord, "serialization"),
        # Request models — client supplies, defaults are optional.
        (RetrieveFactsRequest, "validation"),
        (VerifyClaimRequest, "validation"),
    )


@dataclass(frozen=True)
class Artifact:
    """A single generated schema file (relative path + JSON content)."""

    relative_path: Path
    content: dict[str, Any]


def build_artifacts() -> list[Artifact]:
    """Build the full set of generated artifacts in deterministic order.

    Returns:
        List of ``Artifact``, one per file the exporter is responsible for.
        Order is stable: OpenAPI first, then models sorted by name.
    """
    from gtv.mcp.server import app

    artifacts: list[Artifact] = []

    # FastAPI OpenAPI document. Calling app.openapi() generates the full
    # 3.1 document, including every endpoint and every response model.
    openapi_doc = app.openapi()
    artifacts.append(
        Artifact(
            relative_path=Path("spec/openapi.gen.json"),
            content=openapi_doc,
        )
    )

    for model, mode in sorted(_collect_public_models(), key=lambda pair: pair[0].__name__):
        schema = model.model_json_schema(mode=mode)  # type: ignore[arg-type]
        artifacts.append(
            Artifact(
                relative_path=Path(f"spec/schemas/{model.__name__}.gen.json"),
                content=schema,
            )
        )

    return artifacts


def _canonical_json(doc: dict[str, Any]) -> str:
    """Serialize a JSON doc deterministically.

    sort_keys + indent=2 + newline terminator. The newline at EOF keeps
    the file POSIX-clean and keeps git diffs minimal.
    """
    return json.dumps(doc, sort_keys=True, indent=2) + "\n"


def write_artifacts(root: Path, artifacts: list[Artifact]) -> list[Path]:
    """Write every artifact to disk under ``root``.

    Returns:
        Paths written, in the same order as ``artifacts``.
    """
    written: list[Path] = []
    for artifact in artifacts:
        out = root / artifact.relative_path
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(_canonical_json(artifact.content), encoding="utf-8")
        written.append(out)
    return written


def check_artifacts(root: Path, artifacts: list[Artifact]) -> list[Path]:
    """Verify on-disk artifacts match the generated content.

    Returns:
        List of paths that drifted or were missing. Empty list means
        the tree is in sync.
    """
    drifted: list[Path] = []
    for artifact in artifacts:
        on_disk_path = root / artifact.relative_path
        expected = _canonical_json(artifact.content)
        if not on_disk_path.exists():
            drifted.append(on_disk_path)
            continue
        actual = on_disk_path.read_text(encoding="utf-8")
        if actual != expected:
            drifted.append(on_disk_path)
    return drifted


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="gtv-export-schemas",
        description=(
            "Freeze the public gtv OpenAPI + JSON Schema contract to disk. "
            "Use `check` in CI to catch drift before release."
        ),
    )
    parser.add_argument(
        "mode",
        choices=("write", "check"),
        nargs="?",
        default="write",
        help="'write' regenerates artifacts; 'check' exits non-zero on drift",
    )
    parser.add_argument(
        "--root",
        type=Path,
        default=Path.cwd(),
        help="Repo root (default: current working directory).",
    )
    args = parser.parse_args(argv)

    artifacts = build_artifacts()

    if args.mode == "write":
        written = write_artifacts(args.root, artifacts)
        for path in written:
            print(f"wrote {path.relative_to(args.root)}")
        print(f"{len(written)} artifacts regenerated.")
        return 0

    # mode == "check"
    drifted = check_artifacts(args.root, artifacts)
    if not drifted:
        print(f"OK: {len(artifacts)} artifacts in sync.")
        return 0

    print("ERROR: schema drift detected. Run `gtv-export-schemas write`.", file=sys.stderr)
    for path in drifted:
        rel = path.relative_to(args.root) if path.is_absolute() else path
        print(f"  drift: {rel}", file=sys.stderr)
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
