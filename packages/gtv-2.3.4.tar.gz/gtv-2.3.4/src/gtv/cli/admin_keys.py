# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""CLI for managing API keys.

Usage: gtv-admin-keys create --label <label> --scopes <scopes> [--rate-limit <n>] [--db-path ~/.gtv/api_keys.db]
       gtv-admin-keys list [--db-path ~/.gtv/api_keys.db]
       gtv-admin-keys revoke <key_id> [--db-path ~/.gtv/api_keys.db]

The admin-keys command uses SQLite for persistence. Default location: ~/.gtv/api_keys.db
"""
from __future__ import annotations

import sys
from pathlib import Path

import structlog

from gtv.auth.keystore import APIKeyStore

logger = structlog.get_logger(__name__)


def cmd_create(
    label: str,
    scopes: str,
    rate_limit: int | None = None,
    db_path: Path | None = None,
    tenant: str = "",
    issuer_did: str | None = None,
) -> None:
    """Create a new API key."""
    store = APIKeyStore(db_path or "~/.gtv/api_keys.db")
    scopes_list = [s.strip() for s in scopes.split(",")]
    key_id, raw_key = store.create_key(
        label,
        scopes_list,
        rate_limit,
        tenant_id=tenant,
        issuer_did_override=issuer_did,
    )
    store.close()

    print(f"Created API key: {key_id}")
    print()
    print("Raw key (SAVE THIS NOW, you won't see it again):")
    print(f"  {raw_key}")
    print()
    print("Key details:")
    print(f"  Label:          {label}")
    print(f"  Scopes:         {', '.join(scopes_list)}")
    if rate_limit is not None:
        print(f"  Rate limit:     {rate_limit} req/min")
    if tenant:
        print(f"  Tenant:         {tenant}")
    if issuer_did:
        print(f"  Issuer DID:     {issuer_did}")
    print()
    print("WARNING: DO NOT LOSE THIS KEY. Store it in a secure location.")


def cmd_list(db_path: Path | None = None) -> None:
    """List all API keys."""
    store = APIKeyStore(db_path or "~/.gtv/api_keys.db")
    keys = store.list_keys()
    store.close()

    if not keys:
        print("No API keys.")
        return

    # Header
    print(
        f"{'Key ID':20} | {'Label':20} | {'Tenant':12} | {'Scopes':20} | "
        f"{'Status':10} | {'Rate Limit':10} | {'Issuer DID':30}"
    )
    print("-" * 140)

    for key in keys:
        status = "active" if key.is_active() else "revoked"
        scopes_str = ",".join(key.scopes) if key.scopes else "-"
        rate_limit_str = f"{key.rate_limit_per_minute}" if key.rate_limit_per_minute else "-"
        tenant_str = key.tenant_id or "-"
        issuer_str = key.issuer_did_override or "-"
        print(
            f"{key.key_id:20} | {key.label:20} | {tenant_str:12} | {scopes_str:20} | "
            f"{status:10} | {rate_limit_str:10} | {issuer_str:30}"
        )


def cmd_revoke(key_id: str, db_path: Path | None = None) -> None:
    """Revoke an API key by key_id."""
    store = APIKeyStore(db_path or "~/.gtv/api_keys.db")
    found = store.revoke_key(key_id)
    store.close()

    if found:
        print(f"Revoked API key {key_id}")
    else:
        print(f"API key {key_id} not found.")
        sys.exit(1)


def main() -> None:
    """CLI entrypoint."""
    import argparse

    parser = argparse.ArgumentParser(description="Manage API keys")
    subparsers = parser.add_subparsers(dest="cmd", help="Command")

    # create
    p_create = subparsers.add_parser("create", help="Create a new API key")
    p_create.add_argument("--label", required=True, help="Key label")
    p_create.add_argument("--scopes", required=True, help="Comma-separated scopes (e.g., verify,consensus)")
    p_create.add_argument("--rate-limit", type=int, help="Rate limit in requests per minute")
    p_create.add_argument("--db-path", type=Path, help="Path to API keys database")
    p_create.add_argument(
        "--tenant",
        default="",
        help="Tenant id this key belongs to (empty = default tenant)",
    )
    p_create.add_argument(
        "--issuer-did",
        default=None,
        help="Issuer DID override for this tenant (falls through to GTV_ISSUER_DID if unset)",
    )

    # list
    p_list = subparsers.add_parser("list", help="List all API keys")
    p_list.add_argument("--db-path", type=Path, help="Path to API keys database")

    # revoke
    p_revoke = subparsers.add_parser("revoke", help="Revoke an API key")
    p_revoke.add_argument("key_id", help="Key ID to revoke")
    p_revoke.add_argument("--db-path", type=Path, help="Path to API keys database")

    args = parser.parse_args()

    if args.cmd == "create":
        cmd_create(
            args.label,
            args.scopes,
            args.rate_limit,
            args.db_path,
            tenant=args.tenant,
            issuer_did=args.issuer_did,
        )
    elif args.cmd == "list":
        cmd_list(args.db_path)
    elif args.cmd == "revoke":
        cmd_revoke(args.key_id, args.db_path)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
