# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""CLI for the append-only signed audit log.

Commands:
- gtv-audit tail [--limit N] [--db PATH] [--format {text,json}]
- gtv-audit verify [--db PATH]
- gtv-audit get <seq> [--db PATH] [--format {text,json}]
- gtv-audit export [--db PATH] [--out PATH]
- gtv-audit append --actor A --action X --target T [--details JSON] [--db PATH]

Entry point: gtv-audit
Note: Console script added to pyproject.toml by orchestrator.

Exit codes:
  0 = success
  1 = not found / operation failed
  2 = missing required argument / invalid command
"""
from __future__ import annotations

import json
import os
import sys

from gtv.audit.store import AuditRecord, AuditStore


def _get_db_path(db_arg: str | None) -> str:
    """Resolve the database path from CLI arg or env var.

    Priority: CLI flag > environment variable > default.
    """
    if db_arg:
        return db_arg
    env_path = os.environ.get("GTV_AUDIT_DB")
    if env_path:
        return env_path
    return os.path.expanduser("~/.gtv/audit.db")


def _format_signature_status(record: AuditRecord) -> str:
    """Format signature status for text output."""
    if record.signature == "unsigned":
        return "unsigned"
    if record.signature == "BAD":
        return "BAD"
    return "ok"


def cmd_tail(limit: int = 20, db: str | None = None, format: str = "text") -> int:  # noqa: A002
    """Print N most-recent records."""
    db_path = _get_db_path(db)
    store = AuditStore(db_path)
    try:
        records = store.tail(limit=limit)

        if format == "json":
            output = [r.model_dump(mode="json") for r in records]
            print(json.dumps(output))
        else:  # text format
            if not records:
                print("0 records")
                return 0

            for record in records:
                sig_status = _format_signature_status(record)
                # Text format: [seq] timestamp  actor  action  target  (signature: ok/unsigned/BAD)
                print(
                    f"[{record.seq}] {record.timestamp}  {record.actor}  {record.action}  "
                    f"{record.target}  (signature: {sig_status})"
                )

        return 0
    finally:
        store.close()


def cmd_verify(db: str | None = None) -> int:
    """Verify the audit chain integrity."""
    db_path = _get_db_path(db)
    store = AuditStore(db_path)
    try:
        intact, first_bad_seq = store.verify_chain()

        if intact:
            # Count total records for reporting
            # Get the highest seq by tailing with a large limit
            records = store.tail(limit=1000000)
            total = len(records)
            print(f"Chain intact: {total} records")
            return 0
        else:
            print(f"CHAIN BROKEN at seq={first_bad_seq}")
            return 1
    finally:
        store.close()


def cmd_get(seq: int, db: str | None = None, format: str = "text") -> int:  # noqa: A002
    """Fetch one record by seq."""
    db_path = _get_db_path(db)
    store = AuditStore(db_path)
    try:
        record = store.get(seq)

        if record is None:
            print(f"Record {seq} not found.", file=sys.stderr)
            return 1

        if format == "json":
            print(json.dumps(record.model_dump(mode="json")))
        else:  # text format
            sig_status = _format_signature_status(record)
            print(f"seq:       {record.seq}")
            print(f"timestamp: {record.timestamp}")
            print(f"actor:     {record.actor}")
            print(f"action:    {record.action}")
            print(f"target:    {record.target}")
            print(f"details:   {json.dumps(record.details)}")
            print(f"prev_hash: {record.prev_hash}")
            print(f"record_hash: {record.record_hash}")
            print(f"signature: {sig_status}")

        return 0
    finally:
        store.close()


def cmd_export(db: str | None = None, out: str | None = None) -> int:
    """Export full chain as JSON lines."""
    db_path = _get_db_path(db)
    store = AuditStore(db_path)
    try:
        records = store.tail(limit=1000000)  # Get all records

        # Reverse to get chronological order (tail returns newest first)
        records.reverse()

        if out:
            try:
                with open(out, "w") as output_file:
                    for record in records:
                        line = json.dumps(record.model_dump(mode="json"))
                        output_file.write(line + "\n")
            except OSError as e:
                print(f"ERROR: Cannot open {out}: {e}", file=sys.stderr)
                return 1
        else:
            for record in records:
                line = json.dumps(record.model_dump(mode="json"))
                print(line)

        return 0
    finally:
        store.close()


def cmd_append(
    actor: str,
    action: str,
    target: str,
    details: str | None = None,
    db: str | None = None,
) -> int:
    """Manually append a record."""
    db_path = _get_db_path(db)
    store = AuditStore(db_path)
    try:
        # Parse details as JSON
        if details:
            try:
                details_dict = json.loads(details)
            except json.JSONDecodeError as e:
                print(f"ERROR: Invalid JSON in --details: {e}", file=sys.stderr)
                return 1
        else:
            details_dict = {}

        record = store.append(actor, action, target, details_dict)
        print(record.seq)
        return 0
    finally:
        store.close()


def main(argv: list[str] | None = None) -> int:
    """CLI entry point for gtv-audit.

    Dispatches to subcommands: tail, verify, get, export, append.

    Args:
        argv: Command line arguments (default: sys.argv[1:])

    Returns:
        Exit code: 0 on success, 1 on not found, 2 on argument error.
    """
    import argparse

    argv = argv if argv is not None else sys.argv[1:]

    parser = argparse.ArgumentParser(
        description="Manage the append-only signed audit log",
        prog="gtv-audit",
    )
    subparsers = parser.add_subparsers(dest="cmd", help="Command")

    # tail
    p_tail = subparsers.add_parser("tail", help="Print N most-recent records")
    p_tail.add_argument("--limit", type=int, default=20, help="Number of records to return (default: 20)")
    p_tail.add_argument("--db", help="Path to audit database (default: ~/.gtv/audit.db)")
    p_tail.add_argument(
        "--format",
        choices=["text", "json"],
        default="text",
        help="Output format (default: text)",
    )

    # verify
    p_verify = subparsers.add_parser("verify", help="Verify chain integrity")
    p_verify.add_argument("--db", help="Path to audit database (default: ~/.gtv/audit.db)")

    # get
    p_get = subparsers.add_parser("get", help="Fetch one record by seq")
    p_get.add_argument("seq", type=int, help="Record sequence number")
    p_get.add_argument("--db", help="Path to audit database (default: ~/.gtv/audit.db)")
    p_get.add_argument(
        "--format",
        choices=["text", "json"],
        default="text",
        help="Output format (default: text)",
    )

    # export
    p_export = subparsers.add_parser("export", help="Export full chain as JSON lines")
    p_export.add_argument("--db", help="Path to audit database (default: ~/.gtv/audit.db)")
    p_export.add_argument("--out", help="Output file (default: stdout)")

    # append
    p_append = subparsers.add_parser("append", help="Manually append a record")
    p_append.add_argument("--actor", required=True, help="Actor performing the action")
    p_append.add_argument("--action", required=True, help="Action being recorded")
    p_append.add_argument("--target", required=True, help="Target of the action")
    p_append.add_argument("--details", help="JSON object with additional details (default: {})")
    p_append.add_argument("--db", help="Path to audit database (default: ~/.gtv/audit.db)")

    try:
        args = parser.parse_args(argv)
    except SystemExit as e:
        # argparse calls sys.exit() on error; convert to return code
        return e.code if isinstance(e.code, int) else 2

    if args.cmd == "tail":
        return cmd_tail(args.limit, args.db, args.format)
    elif args.cmd == "verify":
        return cmd_verify(args.db)
    elif args.cmd == "get":
        return cmd_get(args.seq, args.db, args.format)
    elif args.cmd == "export":
        return cmd_export(args.db, args.out)
    elif args.cmd == "append":
        return cmd_append(args.actor, args.action, args.target, args.details, args.db)
    else:
        parser.print_help()
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
