# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""CLI for SBOM generation and vulnerability scanning."""
from __future__ import annotations

import argparse
import json
import sys
from datetime import UTC, datetime
from uuid import uuid4

from gtv.sbom import SBOM, collect_components, render_cyclonedx, scan_vulns


def generate_sbom(output: str | None = None) -> int:
    """Generate an SBOM from the current environment.

    Args:
        output: Path to write SBOM JSON file. If None, writes to stdout.

    Returns:
        Exit code (0 on success).
    """
    components = collect_components()

    sbom = SBOM(
        serial_number=f"urn:uuid:{uuid4()}",
        components=components,
        generated_at=datetime.now(UTC).isoformat(),
    )

    sbom_dict = render_cyclonedx(sbom)
    sbom_json = json.dumps(sbom_dict, indent=2)

    if output:
        with open(output, "w") as f:
            f.write(sbom_json)
        print(f"SBOM written to {output}")
    else:
        print(sbom_json)

    return 0


def scan_sbom(sbom_path: str, advisories_path: str, fail_on: str | None = None) -> int:
    """Scan an SBOM for known vulnerabilities.

    Args:
        sbom_path: Path to SBOM JSON file.
        advisories_path: Path to advisory database JSON file.
        fail_on: Exit non-zero if severity matches (e.g., 'critical', 'high').

    Returns:
        Exit code (0 if no matches, non-zero if matches and --fail-on set).
    """
    with open(sbom_path) as f:
        sbom_dict = json.load(f)

    # Extract components from SBOM
    from gtv.sbom import Component

    components = []
    for comp_dict in sbom_dict.get("components", []):
        comp = Component(
            name=comp_dict["name"],
            version=comp_dict["version"],
            purl=comp_dict["purl"],
            sha256=None,
            license=None,
        )
        components.append(comp)

    hits = scan_vulns(components, advisories_path)

    if hits:
        print(f"Found {len(hits)} vulnerability/vulnerabilities:")
        for hit in hits:
            print(
                f"  {hit['component']}=={hit['version']}: "
                f"{hit['severity']} (ID: {hit['id']})"
            )

        if fail_on and any(hit["severity"] == fail_on for hit in hits):
            return 1
    else:
        print("No vulnerabilities found.")

    return 0


def main() -> None:
    """Main entry point for gtv-sbom CLI."""
    parser = argparse.ArgumentParser(
        prog="gtv-sbom", description="SBOM generation and vulnerability scanning"
    )
    subparsers = parser.add_subparsers(dest="command", help="Command to run")

    # generate subcommand
    gen_parser = subparsers.add_parser("generate", help="Generate SBOM")
    gen_parser.add_argument(
        "--output", default=None, help="Output file path (default: stdout)"
    )

    # scan subcommand
    scan_parser = subparsers.add_parser("scan", help="Scan SBOM for vulnerabilities")
    scan_parser.add_argument("--sbom", required=True, help="Path to SBOM JSON file")
    scan_parser.add_argument(
        "--advisories", required=True, help="Path to advisory database JSON file"
    )
    scan_parser.add_argument(
        "--fail-on",
        default=None,
        help="Exit non-zero if severity matches (e.g., critical, high)",
    )

    args = parser.parse_args()

    if args.command == "generate":
        exit_code = generate_sbom(output=args.output)
    elif args.command == "scan":
        exit_code = scan_sbom(
            sbom_path=args.sbom,
            advisories_path=args.advisories,
            fail_on=args.fail_on,
        )
    else:
        parser.print_help()
        exit_code = 1

    sys.exit(exit_code)


if __name__ == "__main__":
    main()
