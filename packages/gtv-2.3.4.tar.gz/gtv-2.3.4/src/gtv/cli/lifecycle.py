# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Operator CLI for the claim lifecycle DAG (W28 endpoints).

Before this existed, operators investigating a retraction chain had to
``curl /claims/{id}/history`` and read JSON by hand. That's the bug: the
lifecycle surface was shippable but not usable.

Subcommands:
  gtv-lifecycle history    <envelope_id>
  gtv-lifecycle latest     <claim_text> [--domain] [--issuer-did]
  gtv-lifecycle supersede  <parent_envelope_id> --claim TEXT
                           [--reason {AMEND,SUPERSEDE,WITHDRAW}]
                           [--domain DOMAIN] [--max-sources N]

All three speak HTTP to a running gtv server. Env vars:
  GTV_BASE_URL   base URL of the server     (default http://localhost:8000)
  GTV_API_KEY    bearer token for supersede (no default — 401 without)

Output:
  text (default) — human-readable chain / envelope summary
  --json         — raw server payload, suitable for piping into jq

Exit codes:
  0 success
  1 not-found / forbidden / server rejected the request
  2 argument error / network error
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from typing import Any

import httpx

DEFAULT_BASE_URL = "http://localhost:8000"
DEFAULT_TIMEOUT = 30.0


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _base_url(arg: str | None) -> str:
    return (arg or os.environ.get("GTV_BASE_URL") or DEFAULT_BASE_URL).rstrip("/")


def _api_key(arg: str | None) -> str | None:
    return arg or os.environ.get("GTV_API_KEY")


def _headers(api_key: str | None) -> dict[str, str]:
    h = {"content-type": "application/json"}
    if api_key:
        h["authorization"] = f"Bearer {api_key}"
    return h


def _print_error_from_response(resp: httpx.Response) -> None:
    """Render a server error response as a concise stderr message."""
    try:
        body = resp.json()
        detail = body.get("detail", body)
    except Exception:
        detail = resp.text
    print(f"ERROR ({resp.status_code}): {detail}", file=sys.stderr)


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------


def cmd_history(args: argparse.Namespace) -> int:
    url = f"{_base_url(args.base_url)}/claims/{args.envelope_id}/history"
    try:
        resp = httpx.get(url, timeout=DEFAULT_TIMEOUT)
    except httpx.HTTPError as e:
        print(f"ERROR: request failed: {e}", file=sys.stderr)
        return 2

    if resp.status_code != 200:
        _print_error_from_response(resp)
        return 1

    payload = resp.json()
    if args.json:
        print(json.dumps(payload, indent=2, sort_keys=True))
        return 0

    entries = payload.get("entries", [])
    if not entries:
        print("(empty chain)")
        return 0

    print(f"Lifecycle chain for {args.envelope_id} (newest first):")
    print()
    for i, entry in enumerate(entries):
        marker = "HEAD" if i == 0 else f"  {i}"
        reason = entry.get("supersede_reason") or "—"
        parents = entry.get("parents") or []
        parent_str = ", ".join(parents) if parents else "—"
        print(f"  [{marker}] {entry['envelope_id']}")
        print(f"         issuer:  {entry['issuer_did']}")
        print(f"         verdict: {entry['verdict']}  domain: {entry['domain']}")
        print(f"         reason:  {reason}")
        print(f"         parents: {parent_str}")
        print()
    return 0


def cmd_latest(args: argparse.Namespace) -> int:
    params: dict[str, str] = {"claim": args.claim, "domain": args.domain}
    if args.issuer_did:
        params["issuer_did"] = args.issuer_did

    url = f"{_base_url(args.base_url)}/claims/latest"
    api_key = _api_key(args.api_key)
    try:
        resp = httpx.get(
            url,
            params=params,
            headers=_headers(api_key) if api_key else {},
            timeout=DEFAULT_TIMEOUT,
        )
    except httpx.HTTPError as e:
        print(f"ERROR: request failed: {e}", file=sys.stderr)
        return 2

    if resp.status_code != 200:
        _print_error_from_response(resp)
        return 1

    payload = resp.json()
    if args.json:
        print(json.dumps(payload, indent=2, sort_keys=True))
        return 0

    env = payload.get("envelope", {})
    _print_envelope_summary(env)
    return 0


def cmd_supersede(args: argparse.Namespace) -> int:
    api_key = _api_key(args.api_key)
    if not api_key:
        print(
            "ERROR: supersede requires authentication. Pass --api-key or set GTV_API_KEY.",
            file=sys.stderr,
        )
        return 2

    body: dict[str, Any] = {
        "parent_envelope_id": args.parent_envelope_id,
        "claim": args.claim,
        "domain": args.domain,
        "reason": args.reason,
        "max_sources": args.max_sources,
    }
    url = f"{_base_url(args.base_url)}/tools/supersede_claim"
    try:
        resp = httpx.post(
            url,
            content=json.dumps(body),
            headers=_headers(api_key),
            timeout=DEFAULT_TIMEOUT,
        )
    except httpx.HTTPError as e:
        print(f"ERROR: request failed: {e}", file=sys.stderr)
        return 2

    if resp.status_code != 200:
        _print_error_from_response(resp)
        return 1

    payload = resp.json()
    if args.json:
        print(json.dumps(payload, indent=2, sort_keys=True))
        return 0

    env = payload.get("envelope", {})
    print(f"Superseded {args.parent_envelope_id} with reason {args.reason}.")
    print()
    _print_envelope_summary(env)
    return 0


def _print_envelope_summary(env: dict[str, Any]) -> None:
    """One-envelope human-readable summary, used by latest + supersede."""
    if not env:
        print("(no envelope in response)")
        return
    print(f"envelope_id:      {env.get('envelope_id', '?')}")
    print(f"claim_id:         {env.get('claim_id', '?')}")
    print(f"verdict:          {env.get('verdict', '?')}")
    print(f"confidence:       {env.get('confidence', '?')}")
    print(f"issuer_did:       {env.get('issuer_did', '?')}")
    print(f"issued_at:        {env.get('issued_at', '?')}")
    supersedes = env.get("supersedes") or []
    print(f"supersedes:       {', '.join(supersedes) if supersedes else '—'}")
    print(f"supersede_reason: {env.get('supersede_reason') or '—'}")
    ev = env.get("evidence") or []
    print(f"evidence:         {len(ev)} item(s)")


# ---------------------------------------------------------------------------
# Parser + entry point
# ---------------------------------------------------------------------------


def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="gtv-lifecycle",
        description="Inspect and drive the claim-supersede DAG.",
    )
    p.add_argument(
        "--base-url",
        help=f"gtv server base URL (default: ${{GTV_BASE_URL}} or {DEFAULT_BASE_URL})",
    )
    p.add_argument(
        "--api-key",
        help="Bearer token (default: $GTV_API_KEY). Required for supersede.",
    )
    p.add_argument(
        "--json",
        action="store_true",
        help="Emit the raw server payload as JSON instead of text.",
    )

    sub = p.add_subparsers(dest="cmd", required=True)

    # history
    ph = sub.add_parser("history", help="Show the ancestor chain of an envelope.")
    ph.add_argument("envelope_id", help="Envelope ID to look up.")
    ph.set_defaults(func=cmd_history)

    # latest
    pl = sub.add_parser("latest", help="Show the head envelope for a claim.")
    pl.add_argument("claim", help="Claim text (quoted).")
    pl.add_argument(
        "--domain",
        default="general",
        choices=["physics", "math", "cs", "astronomy", "materials", "general"],
        help="Claim domain (default: general).",
    )
    pl.add_argument(
        "--issuer-did",
        help="Issuer DID scope (default: the calling tenant's DID).",
    )
    pl.set_defaults(func=cmd_latest)

    # supersede
    ps = sub.add_parser(
        "supersede",
        help="Issue a new envelope that supersedes an existing one.",
    )
    ps.add_argument("parent_envelope_id", help="Envelope ID being superseded.")
    ps.add_argument("--claim", required=True, help="Claim text for the new envelope.")
    ps.add_argument(
        "--domain",
        default="general",
        choices=["physics", "math", "cs", "astronomy", "materials", "general"],
        help="Claim domain (default: general).",
    )
    ps.add_argument(
        "--reason",
        default="SUPERSEDE",
        choices=["AMEND", "SUPERSEDE", "WITHDRAW"],
        help="Why this envelope replaces the parent (default: SUPERSEDE).",
    )
    ps.add_argument(
        "--max-sources",
        type=int,
        default=5,
        help="Max evidence sources for the replacement verdict (default: 5).",
    )
    ps.set_defaults(func=cmd_supersede)

    return p


def main(argv: list[str] | None = None) -> int:
    argv = argv if argv is not None else sys.argv[1:]
    parser = _build_parser()
    try:
        args = parser.parse_args(argv)
    except SystemExit as e:
        return e.code if isinstance(e.code, int) else 2
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
