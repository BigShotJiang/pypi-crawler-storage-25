# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""One-command demo: verify a claim and print a human-readable report.

No server, no OIDC, no external config. Single positional arg is the claim text.
Internally uses the same verify pipeline as the MCP server, but skips signing/anchoring
for offline-friendly demo mode.

Usage:
    gtv-demo "The Higgs boson mass is 125 GeV"
    gtv-demo --offline "The speed of light is 299792458 m/s"
    gtv-demo --json "Einstein's mass-energy equivalence is E=mc²"
"""
from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys
from dataclasses import asdict, dataclass

from gtv.adapters.base import SourceAdapter
from gtv.models import Claim, Domain, Evidence, Verdict
from gtv.retrieve.extract import extract_subclaims
from gtv.verdict.classify import ClaimClass, classify


def _bold(text: str) -> str:
    """Return text with ANSI bold (no external deps)."""
    return f"\033[1m{text}\033[0m"


def _green(text: str) -> str:
    """Return text with ANSI green."""
    return f"\033[32m{text}\033[0m"


def _red(text: str) -> str:
    """Return text with ANSI red."""
    return f"\033[31m{text}\033[0m"


def _yellow(text: str) -> str:
    """Return text with ANSI yellow."""
    return f"\033[33m{text}\033[0m"


def _dim(text: str) -> str:
    """Return text with ANSI dim."""
    return f"\033[2m{text}\033[0m"


@dataclass
class DemoEvidence:
    """Lightweight evidence record for demo output."""
    source_did: str
    excerpt: str
    stance: str
    url: str


@dataclass
class DemoVerdict:
    """Single subclaim verdict for demo output."""
    claim: str
    verdict: str
    confidence: float
    evidence_items: list[DemoEvidence]


async def _verify_one_demo(claim: Claim, offline: bool) -> DemoVerdict:
    """Verify a single claim in demo mode (no signing/anchoring).

    If offline=True, all verdicts are UNVERIFIED with empty evidence.
    If offline=False, call the standard _verify_one from the MCP server.

    Args:
        claim: The Claim to verify.
        offline: If True, skip all network calls and return UNVERIFIED.

    Returns:
        DemoVerdict with verdict, confidence, and top evidence items.
    """
    if offline:
        # Pure offline mode: no adapters, no network calls
        return DemoVerdict(
            claim=claim.text,
            verdict=Verdict.UNVERIFIED,
            confidence=0.0,
            evidence_items=[],
        )

    # Non-offline: call the real verify pipeline
    from gtv.adapters import REGISTRY
    from gtv.verdict import decide
    from gtv.verdict.engine import VerdictInputs

    # Classify claim first
    claim_class = classify(claim)

    if claim_class == ClaimClass.OPINION:
        return DemoVerdict(
            claim=claim.text,
            verdict=Verdict.OPINION,
            confidence=0.9,
            evidence_items=[],
        )

    if claim_class == ClaimClass.CREATIVE:
        return DemoVerdict(
            claim=claim.text,
            verdict=Verdict.CREATIVE,
            confidence=0.99,
            evidence_items=[],
        )

    if claim_class == ClaimClass.OUT_OF_SCOPE:
        return DemoVerdict(
            claim=claim.text,
            verdict=Verdict.OUT_OF_SCOPE,
            confidence=0.8,
            evidence_items=[],
        )

    # FACTUAL claims: run adapters
    if not REGISTRY:
        return DemoVerdict(
            claim=claim.text,
            verdict=Verdict.UNVERIFIED,
            confidence=0.0,
            evidence_items=[],
        )

    adapters = list(REGISTRY.values())

    async def timed_adapter_query(
        adapter: SourceAdapter,
        claim: Claim,
        max_items: int,
    ) -> list[Evidence]:
        try:
            result = await adapter.query(claim, max_items=max_items)
            return result
        except Exception:
            return []

    evidence_batches = await asyncio.gather(
        *(timed_adapter_query(a, claim, 5) for a in adapters),
        return_exceptions=True,
    )
    evidence = [e for batch in evidence_batches if isinstance(batch, list) for e in batch]

    # Decide verdict
    record = decide(VerdictInputs(
        claim=claim,
        evidence=evidence,
        tier_of={a.source_did: a.trust_tier for a in adapters},
    ))

    # Convert to demo verdict with top evidence items
    evidence_items = [
        DemoEvidence(
            source_did=e.source_did,
            excerpt=e.excerpt[:100] + "..." if len(e.excerpt) > 100 else e.excerpt,
            stance=e.stance,
            url=str(e.url),
        )
        for e in evidence[:3]  # Top 3 evidence items
    ]

    return DemoVerdict(
        claim=claim.text,
        verdict=record.decision,
        confidence=record.confidence,
        evidence_items=evidence_items,
    )


def _print_verdict_human(verdicts: list[DemoVerdict]) -> None:
    """Print verdict report in human-readable format with colors."""
    print()
    for i, v in enumerate(verdicts, 1):
        print(_bold(f"Subclaim {i}:"))
        print(f"  {v.claim}")
        print()

        # Color verdict based on decision
        if v.verdict == Verdict.VERIFIED:
            verdict_str = _green(f"{v.verdict} ({v.confidence:.0%})")
        elif v.verdict == Verdict.UNVERIFIED:
            verdict_str = _yellow(f"{v.verdict} ({v.confidence:.0%})")
        elif v.verdict == Verdict.CONTESTED:
            verdict_str = _red(f"{v.verdict} ({v.confidence:.0%})")
        else:
            verdict_str = f"{v.verdict} ({v.confidence:.0%})"

        print(f"  Verdict: {verdict_str}")
        print()

        if v.evidence_items:
            print("  Evidence:")
            for e in v.evidence_items:
                print(f"    - {_dim(e.source_did)}")
                print(f"      Stance: {e.stance}")
                print(f"      URL: {e.url}")
                print(f"      {e.excerpt}")
                print()
        else:
            print("  No evidence retrieved.")
            print()


def _print_verdict_json(verdicts: list[DemoVerdict]) -> None:
    """Print verdict report as JSON."""
    output = []
    for v in verdicts:
        output.append({
            "claim": v.claim,
            "verdict": v.verdict,
            "confidence": v.confidence,
            "evidence": [asdict(e) for e in v.evidence_items],
        })
    print(json.dumps(output, indent=2))


def main(argv: list[str] | None = None) -> int:
    """CLI entry point for gtv-demo."""
    argv = argv if argv is not None else sys.argv[1:]

    parser = argparse.ArgumentParser(
        description="One-command demo: verify a claim with gtv (no server, no config).",
        prog="gtv-demo",
    )
    parser.add_argument(
        "claim",
        nargs="?",
        help="Claim text to verify",
    )
    parser.add_argument(
        "--offline",
        action="store_true",
        help="Skip all network calls; emit UNVERIFIED for everything (useful for CI tests)",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Output machine-readable JSON instead of human-readable report",
    )

    args = parser.parse_args(argv)

    if not args.claim:
        parser.print_help(file=sys.stderr)
        return 64

    # Disable default adapters if offline
    if args.offline:
        os.environ["GTV_DISABLE_DEFAULT_ADAPTERS"] = "1"

    # Extract subclaims from the input text
    subclaims = extract_subclaims(args.claim, max_subclaims=5)

    if not subclaims:
        # If no subclaims extracted, treat the whole input as one claim
        subclaims = [args.claim]

    # Create Claim objects
    claims = [Claim(text=text, domain=Domain.GENERAL) for text in subclaims]

    # Run verification (async)
    async def run_verification() -> list[DemoVerdict]:
        return await asyncio.gather(
            *(_verify_one_demo(claim, args.offline) for claim in claims),
            return_exceptions=False,
        )

    verdicts = asyncio.run(run_verification())

    # Print output
    if args.json:
        _print_verdict_json(verdicts)
    else:
        _print_verdict_human(verdicts)

    # Always exit 0 (even if verdict is UNVERIFIED)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
