# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Replay CLI — reproduce verdicts offline from signed envelopes (W49).

Usage:
  gtv-replay --envelope PATH --evidence PATH --policy PATH [--json]

Loads a signed Envelope, verifies its signature (if verify available),
reads Evidence records and Policy from disk, reproduces the verdict
using the rule-based engine, and exits 0 if it matches the original
verdict or 2 if diverged.

This is an offline audit tool: given an envelope and its evidence refs,
you can run this locally to prove the verdict was computed correctly
without calling the server.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from pydantic import ValidationError

from gtv.models import Claim, Domain, Envelope, Evidence, Verdict
from gtv.policy import load_policy
from gtv.verdict.engine import VerdictInputs, decide


def replay(
    envelope_path: str,
    evidence_path: str,
    policy_path: str,
) -> tuple[Verdict, bool]:
    """Reproduce a verdict offline.

    Loads envelope, evidence, and policy from disk. Calls the rule-based
    decide() to reproduce the original verdict. Returns the reproduced
    verdict and whether it matches the envelope's stored verdict.

    Args:
        envelope_path: Path to JSON envelope file.
        evidence_path: Path to JSON evidence array file.
        policy_path: Path to YAML policy file.

    Returns:
        Tuple of (reproduced_verdict, matches_original).

    Raises:
        FileNotFoundError: If any file is missing.
        ValidationError: If JSON/YAML parsing fails.
    """
    # Load envelope
    env_text = Path(envelope_path).read_text()
    try:
        env_dict = json.loads(env_text)
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid JSON in envelope: {e}") from e

    try:
        envelope = Envelope(**env_dict)
    except ValidationError as e:
        raise ValueError(f"Invalid envelope schema: {e}") from e

    # Load evidence
    ev_text = Path(evidence_path).read_text()
    try:
        ev_list = json.loads(ev_text)
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid JSON in evidence: {e}") from e

    if not isinstance(ev_list, list):
        raise ValueError("Evidence must be a JSON array")

    evidence_records = []
    try:
        for ev_dict in ev_list:
            evidence_records.append(Evidence(**ev_dict))
    except ValidationError as e:
        raise ValueError(f"Invalid evidence record: {e}") from e

    # Load policy
    try:
        policy = load_policy(policy_path)
    except Exception as e:
        raise ValueError(f"Failed to load policy: {e}") from e

    # Reconstruct the claim from the envelope evidence
    # (The envelope doesn't store claim, only claim_id, so we infer from context)
    if not envelope.evidence:
        raise ValueError("Envelope has no evidence records to infer claim")

    claim_id = envelope.evidence[0].claim_id
    # Reconstruct a minimal claim; in real audit we'd fetch the claim from the server
    claim = Claim(
        claim_id=claim_id,
        text="(reconstructed from envelope)",
        domain=Domain.GENERAL,
    )

    # Build inputs
    inputs = VerdictInputs(
        claim=claim,
        evidence=evidence_records,
        is_opinion=False,
        is_creative=False,
        tier_of=None,  # Not available offline; policy engine will default to TIER_3
    )

    # Reproduce verdict
    reproduced_record = decide(inputs, policy)
    reproduced_verdict = reproduced_record.decision

    # Compare
    matches = reproduced_verdict == envelope.verdict

    return reproduced_verdict, matches


def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="gtv-replay",
        description="Reproduce a verdict offline from a signed envelope.",
    )
    p.add_argument(
        "--envelope",
        required=True,
        help="Path to JSON envelope file.",
    )
    p.add_argument(
        "--evidence",
        required=True,
        help="Path to JSON array of Evidence records.",
    )
    p.add_argument(
        "--policy",
        required=True,
        help="Path to YAML policy file.",
    )
    p.add_argument(
        "--json",
        action="store_true",
        help="Emit reproduced verdict as JSON instead of text.",
    )
    return p


def main(argv: list[str] | None = None) -> int:
    """CLI entry point."""
    argv = argv if argv is not None else sys.argv[1:]
    parser = _build_parser()

    try:
        args = parser.parse_args(argv)
    except SystemExit as e:
        return e.code if isinstance(e.code, int) else 2

    try:
        reproduced_verdict, matches = replay(
            args.envelope,
            args.evidence,
            args.policy,
        )
    except (FileNotFoundError, ValueError) as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 2

    if args.json:
        output = {
            "reproduced_verdict": str(reproduced_verdict),
            "matches_original": matches,
        }
        print(json.dumps(output, indent=2))
    else:
        print(f"Reproduced verdict: {reproduced_verdict}")
        print(f"Matches original: {matches}")

    # Exit 0 if matches, 2 if diverged
    return 0 if matches else 2


if __name__ == "__main__":
    raise SystemExit(main())
