# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Regex-based PII redactor.

Patterns are intentionally conservative — every rule is narrow enough
that a reasonable factual claim ("the speed of light is 299,792,458
m/s") will not accidentally match. False positives in signed envelopes
are recoverable (the rationale reads slightly worse); false negatives
are a permanent data-leak liability, so we favor catching over
cosmetics.

The redactor is pure-Python, no external services, and deterministic —
the same input always produces the same tokens in the same order, so
unit tests can assert on output byte-for-byte.

Replacement tokens are typed (`[REDACTED:EMAIL]`, `[REDACTED:SSN]`,
etc.) so downstream systems can reason about what was removed without
ever seeing the raw value. Counts are returned alongside so metrics can
be incremented without the redactor itself owning a Prometheus import.
"""
from __future__ import annotations

import os
import re
from collections.abc import Callable
from dataclasses import dataclass, field
from re import Pattern
from typing import ClassVar, Final

# -- Rule definitions --------------------------------------------------
# Each rule = (kind, compiled pattern, optional post-match filter).
# Order matters: longer / more specific rules must run first so that,
# e.g., "ssn inside an email address" doesn't double-redact. We group
# rules that are mutually-exclusive-by-anchor (word-boundary) so the
# order between them is safe.

_EMAIL_RE: Final[Pattern[str]] = re.compile(
    r"\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b"
)

# US SSN: ddd-dd-dddd, excluding obvious invalid ranges (000, 666,
# 900-999). Tight enough that a three-hyphen ISBN won't match.
_SSN_RE: Final[Pattern[str]] = re.compile(
    r"\b(?!000|666|9\d\d)\d{3}-(?!00)\d{2}-(?!0000)\d{4}\b"
)

# Credit-card: 13-19 digits with optional spaces/dashes in groups of 4.
# We validate Luhn in a post-filter so random big numbers don't match.
_CC_RE: Final[Pattern[str]] = re.compile(
    r"\b(?:\d[ -]?){13,19}\b"
)

# IPv4. Filter ensures each octet is 0-255.
_IPV4_RE: Final[Pattern[str]] = re.compile(
    r"\b(?:\d{1,3}\.){3}\d{1,3}\b"
)

# E.164 / NANP phone numbers. Requires a + or a ( or a leading 1- so
# it doesn't eat every 10-digit sequence in a chemistry paper.
_PHONE_RE: Final[Pattern[str]] = re.compile(
    r"""(?x)
    (?:
      \+\d{1,3}[\s\-]?\d{1,4}[\s\-]?\d{3,4}[\s\-]?\d{3,4}   # +1 415 555 1212
      |
      \(\d{3}\)[\s\-]?\d{3}[\s\-]?\d{4}                       # (415) 555-1212
      |
      \b1[\s\-]\d{3}[\s\-]\d{3}[\s\-]\d{4}\b                  # 1-415-555-1212
    )
    """
)

# IBAN: 2 letters + 2 digits + up to 30 alphanum, min total length 15.
_IBAN_RE: Final[Pattern[str]] = re.compile(
    r"\b[A-Z]{2}\d{2}[A-Z0-9]{11,30}\b"
)

# Common API-key / secret shapes. We aim at the high-signal ones that
# are common in LLM output: AWS access-key IDs, GitHub PATs, Slack
# tokens, generic JWT bearer tokens, and long hex/base64 bearer strings
# when prefixed with "Bearer ".
_AWS_AKID_RE: Final[Pattern[str]] = re.compile(r"\b(?:AKIA|ASIA)[A-Z0-9]{16}\b")
_GH_PAT_RE: Final[Pattern[str]] = re.compile(r"\bghp_[A-Za-z0-9]{36}\b")
_SLACK_RE: Final[Pattern[str]] = re.compile(
    r"\bxox[baprs]-[A-Za-z0-9\-]{10,}\b"
)
_JWT_RE: Final[Pattern[str]] = re.compile(
    r"\beyJ[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}\b"
)
_BEARER_RE: Final[Pattern[str]] = re.compile(
    r"\bBearer\s+[A-Za-z0-9_\-\.=]{20,}\b"
)


def _luhn_ok(digits: str) -> bool:
    """Standard Luhn check. Rejects strings with < 13 digits."""
    s = [int(c) for c in digits if c.isdigit()]
    if len(s) < 13 or len(s) > 19:
        return False
    total = 0
    # Luhn: double every second digit from the right.
    for i, d in enumerate(reversed(s)):
        if i % 2 == 1:
            d *= 2
            if d > 9:
                d -= 9
        total += d
    return total % 10 == 0


def _ipv4_ok(s: str) -> bool:
    parts = s.split(".")
    if len(parts) != 4:
        return False
    return all(p.isdigit() and 0 <= int(p) <= 255 for p in parts)


@dataclass
class RedactionResult:
    """Return value from `Redactor.redact()`.

    `text` is the scrubbed string. `counts` maps each kind of PII to
    the number of matches replaced. Callers can use `counts` to
    increment metrics without importing anything from `obs`.
    """

    text: str
    counts: dict[str, int] = field(default_factory=dict)

    @property
    def total(self) -> int:
        return sum(self.counts.values())

    @property
    def any_redacted(self) -> bool:
        return self.total > 0


class Redactor:
    """Stateless redactor. Thread-safe; build one and reuse."""

    # Order = precedence. Longer/more-specific first.
    _RULES: ClassVar[tuple[tuple[str, Pattern[str]], ...]] = (
        ("JWT", _JWT_RE),
        ("BEARER", _BEARER_RE),
        ("AWS_AKID", _AWS_AKID_RE),
        ("GH_PAT", _GH_PAT_RE),
        ("SLACK", _SLACK_RE),
        ("IBAN", _IBAN_RE),
        ("EMAIL", _EMAIL_RE),
        ("PHONE", _PHONE_RE),
        ("SSN", _SSN_RE),
        ("CC", _CC_RE),
        ("IPV4", _IPV4_RE),
    )

    # Kinds whose match must survive a post-match filter.
    _POST: ClassVar[dict[str, Callable[[str], bool]]] = {
        "CC": _luhn_ok,
        "IPV4": _ipv4_ok,
    }

    def __init__(self, *, extra_patterns: list[tuple[str, str]] | None = None) -> None:
        """Optionally extend with site-specific patterns.

        `extra_patterns` = list of (kind, regex_source). Extra rules run
        AFTER the built-ins, so a built-in that already matches wins.
        """
        self._extra: list[tuple[str, Pattern[str]]] = [
            (kind, re.compile(src)) for kind, src in (extra_patterns or [])
        ]

    def redact(self, text: str) -> RedactionResult:
        if not text:
            return RedactionResult(text=text, counts={})
        counts: dict[str, int] = {}
        out = text
        for kind, pattern in (*self._RULES, *self._extra):
            post = self._POST.get(kind)

            def _sub(
                m: re.Match[str],
                _kind: str = kind,
                _post: Callable[[str], bool] | None = post,
            ) -> str:
                s = m.group(0)
                if _post is not None and not _post(s):
                    return s
                counts[_kind] = counts.get(_kind, 0) + 1
                return f"[REDACTED:{_kind}]"

            out = pattern.sub(_sub, out)
        # Prune zeros from the counts dict (happens when a post-filter
        # rejected every candidate for a rule).
        counts = {k: v for k, v in counts.items() if v > 0}
        return RedactionResult(text=out, counts=counts)

    def contains_pii(self, text: str) -> bool:
        """True if `redact(text)` would change anything."""
        return self.redact(text).any_redacted


# -- Module-level singleton & env gating ------------------------------

_DEFAULT_REDACTOR: Redactor | None = None


def _load_extra_patterns_from_env() -> list[tuple[str, str]]:
    """Parse GTV_REDACT_EXTRA_PATTERNS.

    Format: semicolon-separated `KIND=regex` pairs. Example:
    `GTV_REDACT_EXTRA_PATTERNS="EMP_ID=EMP-\\d{6};INT_URL=https://int\\..*"`

    Invalid regexes are silently skipped — we log at import time in
    the caller, not here, to keep this pure.
    """
    raw = os.environ.get("GTV_REDACT_EXTRA_PATTERNS", "").strip()
    if not raw:
        return []
    out: list[tuple[str, str]] = []
    for pair in raw.split(";"):
        pair = pair.strip()
        if not pair or "=" not in pair:
            continue
        kind, _, src = pair.partition("=")
        kind = kind.strip()
        src = src.strip()
        if not kind or not src:
            continue
        try:
            re.compile(src)
        except re.error:
            continue
        out.append((kind, src))
    return out


def _get_default_redactor() -> Redactor:
    global _DEFAULT_REDACTOR
    if _DEFAULT_REDACTOR is None:
        _DEFAULT_REDACTOR = Redactor(extra_patterns=_load_extra_patterns_from_env())
    return _DEFAULT_REDACTOR


def _redaction_enabled() -> bool:
    return os.environ.get("GTV_REDACT_ENABLED", "1") != "0"


def redact_text(text: str) -> RedactionResult:
    """Module-level convenience. Honors `GTV_REDACT_ENABLED`."""
    if not _redaction_enabled():
        return RedactionResult(text=text, counts={})
    return _get_default_redactor().redact(text)


def contains_pii(text: str) -> bool:
    """True if `text` contains anything the default redactor would scrub.

    Always runs regardless of `GTV_REDACT_ENABLED` — callers use this
    for input-side rejection, which should not be quietly disabled.
    """
    return _get_default_redactor().contains_pii(text)


def redact_envelope_fields(
    *,
    rationale: str,
    evidence_excerpts: list[str],
) -> tuple[str, list[str], dict[str, int]]:
    """Redact the fields that land in a signed envelope.

    Returns `(rationale_scrubbed, excerpts_scrubbed, total_counts)`.
    Counts are summed across all fields so the caller increments the
    metric once with one dict.

    Honors `GTV_REDACT_ENABLED` — when disabled, returns inputs
    unchanged and an empty counts dict. Disabled mode is for
    development only; production must leave it on.
    """
    if not _redaction_enabled():
        return rationale, list(evidence_excerpts), {}
    redactor = _get_default_redactor()
    r = redactor.redact(rationale)
    ex_out: list[str] = []
    totals: dict[str, int] = dict(r.counts)
    for ex in evidence_excerpts:
        er = redactor.redact(ex)
        ex_out.append(er.text)
        for k, v in er.counts.items():
            totals[k] = totals.get(k, 0) + v
    return r.text, ex_out, totals


def reset_default_redactor_for_tests() -> None:
    """Test-only: drop the module-level singleton so env changes take effect."""
    global _DEFAULT_REDACTOR
    _DEFAULT_REDACTOR = None
