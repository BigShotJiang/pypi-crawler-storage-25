# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""PII redaction for signed envelopes.

Signed envelopes are public, replicated, and in practice unrevokable —
a credit-card number or SSN that lands in `rationale` or an evidence
excerpt is a permanent GDPR / CCPA / HIPAA liability. This package
redacts that data BEFORE the envelope is sealed, so signatures are
computed over already-scrubbed text.

Input-side: `contains_pii()` lets the request layer 400 a claim that
would require redaction (redacting a user-submitted claim silently
would break caching and mislead the caller).

Output-side: `redact_envelope_fields()` scrubs adapter-returned evidence
excerpts and LLM-generated rationale before sealing.

All redaction is regex-based and dependency-free. No ML. No network.
"""
from gtv.redact.redactor import (
    RedactionResult,
    Redactor,
    contains_pii,
    redact_envelope_fields,
    redact_text,
)

__all__ = [
    "RedactionResult",
    "Redactor",
    "contains_pii",
    "redact_envelope_fields",
    "redact_text",
]
