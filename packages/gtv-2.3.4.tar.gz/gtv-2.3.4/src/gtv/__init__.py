# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Ground Truth Verification System — federated fact verifier for LLM agents."""

__version__ = "2.3.4"
