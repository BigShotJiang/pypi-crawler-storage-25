# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""SQLite-backed API key store for persistent key management.

Simple schema: one api_keys table.
No ORM, no migrations framework, just sqlite3 + hand-rolled SQL.
"""
from __future__ import annotations

import hashlib
import secrets
import sqlite3
import threading
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    pass


@dataclass
class APIKey:
    """Represents an API key with metadata.

    ``tenant_id`` partitions the verifier: each tenant signs with its own
    issuer DID, which in turn isolates its verdict cache and lifecycle
    chain (both are keyed by issuer DID). Empty string = the default
    tenant that uses ``GTV_ISSUER_DID``.

    ``issuer_did_override`` lets a tenant sign under a DID different from
    the server default without spinning up a separate process. Unset =
    use the server default.
    """

    key_id: str
    label: str
    scopes: list[str]
    rate_limit_per_minute: int | None
    created_at: datetime
    revoked_at: datetime | None
    last_used_at: datetime | None
    tenant_id: str = ""
    issuer_did_override: str | None = None

    def has_scope(self, scope: str) -> bool:
        """Check if this key has the given scope."""
        return scope in self.scopes

    def is_active(self) -> bool:
        """Check if this key is active (not revoked)."""
        return self.revoked_at is None


class APIKeyStore:
    """SQLite-backed store for API keys.

    Thread-safe via a lock. Connection is kept as an instance attribute.
    Schema: api_keys(key_hash, key_id, label, scopes, rate_limit_per_minute, created_at, revoked_at, last_used_at).
    """

    def __init__(self, path: str | Path = "~/.gtv/api_keys.db") -> None:
        """Initialize store and create table if not exists."""
        self.path = Path(path).expanduser()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._conn = sqlite3.connect(str(self.path), check_same_thread=False)
        self._conn.isolation_level = None  # autocommit mode
        self._init_schema()

    def _init_schema(self) -> None:
        """Create api_keys table if not exists and migrate older schemas.

        Multi-tenant columns (``tenant_id``, ``issuer_did_override``) are
        added on upgrade so existing pilot databases keep working without
        manual intervention. SQLite ``ALTER TABLE ADD COLUMN`` is
        O(1) metadata-only and safe to run unconditionally on each boot.
        """
        self._conn.execute(
            """
            CREATE TABLE IF NOT EXISTS api_keys (
                key_hash TEXT PRIMARY KEY,
                key_id TEXT UNIQUE NOT NULL,
                label TEXT,
                scopes TEXT,
                rate_limit_per_minute INTEGER,
                created_at TEXT NOT NULL,
                revoked_at TEXT,
                last_used_at TEXT,
                tenant_id TEXT NOT NULL DEFAULT '',
                issuer_did_override TEXT
            )
            """
        )
        # Best-effort in-place migration for DBs created before W31.
        existing = {
            row[1]
            for row in self._conn.execute("PRAGMA table_info(api_keys)").fetchall()
        }
        if "tenant_id" not in existing:
            self._conn.execute(
                "ALTER TABLE api_keys ADD COLUMN tenant_id TEXT NOT NULL DEFAULT ''"
            )
        if "issuer_did_override" not in existing:
            self._conn.execute(
                "ALTER TABLE api_keys ADD COLUMN issuer_did_override TEXT"
            )

    def create_key(
        self,
        label: str,
        scopes: list[str],
        rate_limit_per_minute: int | None = None,
        *,
        tenant_id: str = "",
        issuer_did_override: str | None = None,
    ) -> tuple[str, str]:
        """Create a new API key.

        ``tenant_id`` defaults to the empty string, which maps to the
        server-default tenant (signs under ``GTV_ISSUER_DID``).
        ``issuer_did_override`` lets this key's verdicts be signed under a
        different DID, giving the tenant its own cache + lifecycle
        namespace without spinning up another process.

        Returns (key_id, raw_key). raw_key is the ONLY time the raw key is visible.
        """
        key_id = f"key_{secrets.token_urlsafe(16)}"
        raw_key = f"gtv_{secrets.token_urlsafe(32)}"
        key_hash = hashlib.sha256(raw_key.encode()).hexdigest()
        now = datetime.utcnow().isoformat()
        scopes_str = ",".join(scopes) if scopes else ""

        with self._lock:
            self._conn.execute(
                """
                INSERT INTO api_keys
                (key_hash, key_id, label, scopes, rate_limit_per_minute, created_at,
                 revoked_at, last_used_at, tenant_id, issuer_did_override)
                VALUES (?, ?, ?, ?, ?, ?, NULL, NULL, ?, ?)
                """,
                (
                    key_hash,
                    key_id,
                    label,
                    scopes_str,
                    rate_limit_per_minute,
                    now,
                    tenant_id,
                    issuer_did_override,
                ),
            )

        return key_id, raw_key

    def verify_key(self, raw_key: str) -> APIKey | None:
        """Verify a raw key and return the APIKey if valid and active."""
        key_hash = hashlib.sha256(raw_key.encode()).hexdigest()

        with self._lock:
            cursor = self._conn.execute(
                """
                SELECT key_id, label, scopes, rate_limit_per_minute, created_at,
                       revoked_at, last_used_at, tenant_id, issuer_did_override
                FROM api_keys
                WHERE key_hash = ?
                """,
                (key_hash,),
            )
            row = cursor.fetchone()
            if row:
                # Update last_used_at
                now = datetime.utcnow().isoformat()
                self._conn.execute(
                    "UPDATE api_keys SET last_used_at = ? WHERE key_hash = ?",
                    (now, key_hash),
                )
                # Build APIKey with updated last_used_at
                (
                    key_id_raw,
                    label_raw,
                    scopes_raw,
                    rate_limit_raw,
                    created_at_raw,
                    revoked_at_raw,
                    _,
                    tenant_id_raw,
                    issuer_did_override_raw,
                ) = row
                assert isinstance(key_id_raw, str)
                assert isinstance(label_raw, str) or label_raw is None
                assert isinstance(scopes_raw, str) or scopes_raw is None
                assert rate_limit_raw is None or isinstance(rate_limit_raw, int)
                assert isinstance(created_at_raw, str)
                assert revoked_at_raw is None or isinstance(revoked_at_raw, str)
                assert isinstance(tenant_id_raw, str) or tenant_id_raw is None
                assert (
                    issuer_did_override_raw is None
                    or isinstance(issuer_did_override_raw, str)
                )

                scopes = scopes_raw.split(",") if scopes_raw else []
                api_key = APIKey(
                    key_id=key_id_raw,
                    label=label_raw or "",
                    scopes=scopes,
                    rate_limit_per_minute=rate_limit_raw,
                    created_at=datetime.fromisoformat(created_at_raw),
                    revoked_at=datetime.fromisoformat(revoked_at_raw) if revoked_at_raw else None,
                    last_used_at=datetime.fromisoformat(now),
                    tenant_id=tenant_id_raw or "",
                    issuer_did_override=issuer_did_override_raw,
                )
                return api_key
        return None

    def revoke_key(self, key_id: str) -> bool:
        """Revoke a key by key_id. Return True if found."""
        now = datetime.utcnow().isoformat()
        with self._lock:
            cursor = self._conn.execute(
                "UPDATE api_keys SET revoked_at = ? WHERE key_id = ?",
                (now, key_id),
            )
            return cursor.rowcount > 0

    def list_keys(self) -> list[APIKey]:
        """Return all keys (NEVER returns raw keys, only metadata)."""
        with self._lock:
            cursor = self._conn.execute(
                """
                SELECT key_id, label, scopes, rate_limit_per_minute, created_at,
                       revoked_at, last_used_at, tenant_id, issuer_did_override
                FROM api_keys
                ORDER BY created_at DESC
                """
            )
            return [self._row_to_api_key(row) for row in cursor.fetchall()]

    def touch_last_used(self, key_hash: str) -> None:
        """Update last_used_at for a key hash."""
        with self._lock:
            self._conn.execute(
                "UPDATE api_keys SET last_used_at = ? WHERE key_hash = ?",
                (datetime.utcnow().isoformat(), key_hash),
            )

    @staticmethod
    def _row_to_api_key(row: tuple[object, ...]) -> APIKey:
        """Convert a DB row to an APIKey object."""
        (
            key_id_raw,
            label_raw,
            scopes_raw,
            rate_limit_raw,
            created_at_raw,
            revoked_at_raw,
            last_used_at_raw,
            tenant_id_raw,
            issuer_did_override_raw,
        ) = row

        # SQLite typing: cursor returns object; constrain to the declared column types.
        assert isinstance(key_id_raw, str)
        assert isinstance(label_raw, str) or label_raw is None
        assert isinstance(scopes_raw, str) or scopes_raw is None
        assert rate_limit_raw is None or isinstance(rate_limit_raw, int)
        assert isinstance(created_at_raw, str)
        assert revoked_at_raw is None or isinstance(revoked_at_raw, str)
        assert last_used_at_raw is None or isinstance(last_used_at_raw, str)
        assert tenant_id_raw is None or isinstance(tenant_id_raw, str)
        assert (
            issuer_did_override_raw is None
            or isinstance(issuer_did_override_raw, str)
        )

        scopes = scopes_raw.split(",") if scopes_raw else []
        created_at = datetime.fromisoformat(created_at_raw)
        revoked_at = datetime.fromisoformat(revoked_at_raw) if revoked_at_raw else None
        last_used_at = datetime.fromisoformat(last_used_at_raw) if last_used_at_raw else None

        return APIKey(
            key_id=key_id_raw,
            label=label_raw or "",
            scopes=scopes,
            rate_limit_per_minute=rate_limit_raw,
            created_at=created_at,
            revoked_at=revoked_at,
            last_used_at=last_used_at,
            tenant_id=tenant_id_raw or "",
            issuer_did_override=issuer_did_override_raw,
        )

    def close(self) -> None:
        """Close the database connection."""
        with self._lock:
            self._conn.close()
