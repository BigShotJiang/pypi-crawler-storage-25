# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""OIDC SSO verifier for enterprise IdP integration (Okta, Auth0, Azure AD).

Validates JWT bearer tokens against an OIDC provider's JWKS endpoint.
Supports RS256 and ES256 signature algorithms. Caches JWKS with configurable TTL.
"""
from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass
from typing import Any

import httpx
import jwt
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ec, rsa


class OidcAuthError(Exception):
    """Raised when OIDC token verification fails."""
    pass


@dataclass(frozen=True)
class OidcConfig:
    """OIDC provider configuration."""
    issuer: str                 # e.g. "https://example.okta.com"
    audience: str               # expected aud claim
    jwks_url: str               # well-known jwks_uri
    jwks_cache_ttl_s: int = 3600


@dataclass(frozen=True)
class OidcPrincipal:
    """Authenticated OIDC principal."""
    sub: str                    # OIDC subject
    email: str | None
    tenant_id: str | None       # mapped from a configurable claim
    scopes: list[str]           # from scope claim (space-separated)
    raw_claims: dict


class OidcVerifier:
    """Validates JWT bearer tokens from an OIDC provider."""

    def __init__(
        self,
        cfg: OidcConfig,
        client: httpx.AsyncClient | None = None
    ) -> None:
        """Initialize the OIDC verifier.

        Args:
            cfg: OIDC configuration.
            client: Optional httpx.AsyncClient for JWKS fetching. If None,
                a client will be created internally.
        """
        self.cfg = cfg
        self.client = client
        self._owned_client = client is None
        self._jwks_cache: dict[str, Any] | None = None
        self._jwks_cache_time: float = 0.0
        self._tenant_claim = os.environ.get("GTV_OIDC_TENANT_CLAIM", "tenant_id")

    async def verify(self, bearer_token: str) -> OidcPrincipal:
        """Validate and decode a JWT bearer token.

        Validates:
        - Signature (RS256 or ES256) against JWKS
        - iss (issuer) matches configured issuer
        - aud (audience) matches configured audience
        - exp (expiration) is in the future
        - nbf (not-before) is in the past (if present)

        Args:
            bearer_token: The JWT token (without "Bearer " prefix).

        Returns:
            OidcPrincipal with subject, email, tenant_id, and scopes.

        Raises:
            OidcAuthError: On any validation failure.
        """
        try:
            header = jwt.get_unverified_header(bearer_token)
        except Exception as e:
            raise OidcAuthError(f"Failed to decode token header: {e}") from e

        kid = header.get("kid")
        if not kid:
            raise OidcAuthError("Missing 'kid' in JWT header")

        alg = header.get("alg")
        if alg not in ("RS256", "ES256"):
            raise OidcAuthError(f"Unsupported algorithm: {alg}")

        # Fetch JWKS (with cache)
        jwks = await self._fetch_jwks()

        # Find the key by kid
        key_data = None
        for key in jwks.get("keys", []):
            if key.get("kid") == kid:
                key_data = key
                break

        if not key_data:
            # Key not found; try refreshing JWKS once
            self._jwks_cache = None
            self._jwks_cache_time = 0.0
            jwks = await self._fetch_jwks()
            for key in jwks.get("keys", []):
                if key.get("kid") == kid:
                    key_data = key
                    break

        if not key_data:
            raise OidcAuthError(f"Key with kid '{kid}' not found in JWKS")

        # Build public key from JWKS
        try:
            public_key = self._build_public_key(key_data, alg)
        except OidcAuthError:
            raise
        except Exception as e:
            raise OidcAuthError(f"Failed to build public key: {e}") from e

        # Convert to PEM for PyJWT
        try:
            pem = public_key.public_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PublicFormat.SubjectPublicKeyInfo
            )
        except Exception as e:
            raise OidcAuthError(f"Failed to encode public key to PEM: {e}") from e

        # Verify and decode token
        try:
            claims = jwt.decode(
                bearer_token,
                pem,
                algorithms=[alg],
                audience=self.cfg.audience,
                issuer=self.cfg.issuer,
                options={"verify_exp": True}
            )
        except jwt.ExpiredSignatureError as e:
            raise OidcAuthError(f"Token expired: {e}") from e
        except jwt.InvalidAudienceError as e:
            raise OidcAuthError(f"Invalid audience: {e}") from e
        except jwt.InvalidIssuerError as e:
            raise OidcAuthError(f"Invalid issuer: {e}") from e
        except jwt.DecodeError as e:
            raise OidcAuthError(f"Token signature verification failed: {e}") from e
        except Exception as e:
            raise OidcAuthError(f"Token verification failed: {e}") from e

        # Extract claims
        sub = claims.get("sub")
        if not sub:
            raise OidcAuthError("Missing 'sub' claim")

        email = claims.get("email")
        tenant_id = claims.get(self._tenant_claim)

        # Parse scopes (space-separated string or list)
        scopes_raw = claims.get("scope", "")
        if isinstance(scopes_raw, str):
            scopes = [s.strip() for s in scopes_raw.split() if s.strip()]
        elif isinstance(scopes_raw, list):
            scopes = [str(s) for s in scopes_raw]
        else:
            scopes = []

        return OidcPrincipal(
            sub=sub,
            email=email,
            tenant_id=tenant_id,
            scopes=scopes,
            raw_claims=claims
        )

    async def _fetch_jwks(self) -> dict[str, Any]:
        """Fetch JWKS from the issuer, with caching."""
        now = time.time()

        # Return cached JWKS if still valid
        if self._jwks_cache is not None and (now - self._jwks_cache_time) < self.cfg.jwks_cache_ttl_s:
            return self._jwks_cache

        # Fetch fresh JWKS
        try:
            if self.client is None:
                # Create a temporary client for this request
                async with httpx.AsyncClient() as temp_client:
                    response = await temp_client.get(self.cfg.jwks_url, timeout=10.0)
                    response.raise_for_status()
                    jwks = response.json()
            else:
                response = await self.client.get(self.cfg.jwks_url, timeout=10.0)
                response.raise_for_status()
                jwks = response.json()
        except httpx.HTTPError as e:
            raise OidcAuthError(f"Failed to fetch JWKS from {self.cfg.jwks_url}: {e}") from e
        except json.JSONDecodeError as e:
            raise OidcAuthError(f"Invalid JSON in JWKS response: {e}") from e

        # Cache the JWKS
        self._jwks_cache = jwks
        self._jwks_cache_time = now

        return jwks

    def _build_public_key(self, key_data: dict[str, Any], alg: str) -> rsa.RSAPublicKey | ec.EllipticCurvePublicKey:
        """Build a public key from JWKS key data.

        Args:
            key_data: Key data from JWKS.
            alg: Algorithm (RS256 or ES256).

        Returns:
            RSA or EC public key.
        """
        kty = key_data.get("kty")

        if alg == "RS256" and kty == "RSA":
            # RSA key
            n_b64 = key_data.get("n")
            e_b64 = key_data.get("e")
            if not n_b64 or not e_b64:
                raise OidcAuthError("Missing RSA parameters in JWKS")

            import base64
            # Add padding
            n_b64 = n_b64 + "=" * (4 - len(n_b64) % 4)
            e_b64 = e_b64 + "=" * (4 - len(e_b64) % 4)

            n = int.from_bytes(base64.urlsafe_b64decode(n_b64), "big")
            e = int.from_bytes(base64.urlsafe_b64decode(e_b64), "big")

            public_numbers = rsa.RSAPublicNumbers(e, n)
            return public_numbers.public_key(default_backend())

        elif alg == "ES256" and kty == "EC":
            # EC key
            crv = key_data.get("crv")
            x_b64 = key_data.get("x")
            y_b64 = key_data.get("y")

            if crv != "P-256":
                raise OidcAuthError(f"Unsupported EC curve: {crv}")
            if not x_b64 or not y_b64:
                raise OidcAuthError("Missing EC parameters in JWKS")

            import base64
            # Add padding
            x_b64 = x_b64 + "=" * (4 - len(x_b64) % 4)
            y_b64 = y_b64 + "=" * (4 - len(y_b64) % 4)

            x = int.from_bytes(base64.urlsafe_b64decode(x_b64), "big")
            y = int.from_bytes(base64.urlsafe_b64decode(y_b64), "big")

            public_numbers = ec.EllipticCurvePublicNumbers(x, y, ec.SECP256R1())
            return public_numbers.public_key(default_backend())

        else:
            raise OidcAuthError(f"Unsupported key type: {kty} for algorithm {alg}")

    async def close(self) -> None:
        """Close the client if we own it."""
        if self._owned_client and self.client is not None:
            await self.client.aclose()


def load_oidc_config_from_env() -> OidcConfig | None:
    """Load OIDC configuration from environment variables.

    Reads:
    - GTV_OIDC_ISSUER: OIDC issuer URL
    - GTV_OIDC_AUDIENCE: expected audience claim
    - GTV_OIDC_JWKS_URL: JWKS endpoint URL
    - GTV_OIDC_JWKS_CACHE_TTL_S: cache TTL in seconds (default: 3600)

    Returns:
        OidcConfig if GTV_OIDC_ISSUER is set, None otherwise.
    """
    issuer = os.environ.get("GTV_OIDC_ISSUER", "").strip()
    if not issuer:
        return None

    audience = os.environ.get("GTV_OIDC_AUDIENCE", "").strip()
    jwks_url = os.environ.get("GTV_OIDC_JWKS_URL", "").strip()
    cache_ttl_s = int(os.environ.get("GTV_OIDC_JWKS_CACHE_TTL_S", "3600"))

    if not audience or not jwks_url:
        raise ValueError("GTV_OIDC_AUDIENCE and GTV_OIDC_JWKS_URL must be set if GTV_OIDC_ISSUER is set")

    return OidcConfig(
        issuer=issuer,
        audience=audience,
        jwks_url=jwks_url,
        jwks_cache_ttl_s=cache_ttl_s
    )
