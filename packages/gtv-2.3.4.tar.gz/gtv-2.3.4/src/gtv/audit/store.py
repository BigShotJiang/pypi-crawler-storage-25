# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""SQLite-backed hash-chained, Ed25519-signed append-only audit log store.

Immutable record stream with cryptographic integrity guarantees.
Thread-safe via a single lock. No ORM, no migrations framework.
"""
from __future__ import annotations

import base64
import hashlib
import json
import sqlite3
import threading
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

from pydantic import BaseModel, ConfigDict, Field

if TYPE_CHECKING:
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

# Try to import Ed25519 key handling; fall back gracefully if unavailable
try:
    from cryptography.hazmat.backends import default_backend as _default_backend
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

    HAS_CRYPTOGRAPHY = True
except ImportError:
    HAS_CRYPTOGRAPHY = False
    Ed25519PrivateKey = None  # type: ignore
    _default_backend = None  # type: ignore


class AuditRecord(BaseModel):
    """Immutable audit log record with hash chaining and optional signature.

    Fields:
        seq: Monotonic sequence number (1-indexed, guaranteed unique).
        timestamp: UTC timestamp of the record.
        actor: Actor identifier (e.g., "admin", actor DID).
        action: Action name (e.g., "apikey.create", "federation.revoke").
        target: Target identifier (e.g., key id, issuer did).
        details: Arbitrary context dict.
        prev_hash: 64-char hex of SHA256 hash of previous record (or "0"*64 for seq=1).
        record_hash: 64-char hex of SHA256 hash of record (minus hash and signature fields).
        signature: Ed25519 signature as "ed25519:<base64>" or "unsigned".
    """

    model_config = ConfigDict(frozen=True)

    seq: int = Field(ge=1)
    timestamp: str  # ISO 8601 UTC
    actor: str
    action: str
    target: str
    details: dict[str, object]
    prev_hash: str = Field(min_length=64, max_length=64)
    record_hash: str = Field(min_length=64, max_length=64)
    signature: str


class AuditStore:
    """SQLite-backed append-only audit log store.

    Thread-safe via a single lock. Enforces hash chaining and optional Ed25519 signing.
    """

    def __init__(self, db_path: str | Path, signing_key_path: str | None = None) -> None:
        """Initialize store and create table if not exists.

        Args:
            db_path: Path to SQLite database. Supports ~-expansion.
            signing_key_path: Optional path to Ed25519 private key in PEM format.
                              If not provided, records are signed as "unsigned".
        """
        self.path = Path(db_path).expanduser()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._conn = sqlite3.connect(str(self.path), check_same_thread=False)
        self._conn.isolation_level = None  # autocommit mode
        self._signing_key: Ed25519PrivateKey | None = None
        self._verifying_key: object = None

        # Load signing key if provided
        if signing_key_path:
            self._load_signing_key(signing_key_path)

        self._init_schema()

    def _load_signing_key(self, key_path: str | Path) -> None:
        """Load Ed25519 private key from PEM file.

        Args:
            key_path: Path to PEM-encoded Ed25519 private key.

        Raises:
            ImportError: If cryptography is not available.
            FileNotFoundError: If key file does not exist.
        """
        if not HAS_CRYPTOGRAPHY:
            raise ImportError(
                "cryptography library required for Ed25519 signing. "
                "Install via 'pip install cryptography' or upgrade sigstore."
            )

        key_path = Path(key_path).expanduser()
        with open(key_path, "rb") as f:
            pem_data = f.read()

        loaded_key = serialization.load_pem_private_key(
            pem_data,
            password=None,
            backend=_default_backend(),
        )
        # Type narrowing: if we got here with HAS_CRYPTOGRAPHY=True,
        # the key must be Ed25519PrivateKey, but mypy doesn't infer that
        self._signing_key = loaded_key  # type: ignore[assignment]
        self._verifying_key = loaded_key.public_key()

    def _init_schema(self) -> None:
        """Create audit_log table if not exists."""
        self._conn.execute(
            """
            CREATE TABLE IF NOT EXISTS audit_log (
                seq INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                actor TEXT NOT NULL,
                action TEXT NOT NULL,
                target TEXT NOT NULL,
                details TEXT NOT NULL,
                prev_hash TEXT NOT NULL,
                record_hash TEXT NOT NULL,
                signature TEXT NOT NULL
            )
            """
        )

    @staticmethod
    def _canonicalize(record: dict[str, Any]) -> bytes:
        """Canonicalize a record dict (RFC 8785 JCS subset).

        Produces deterministic JSON by sorting keys recursively.
        """
        def _canon_value(val: object) -> object:
            if isinstance(val, dict):
                return {k: _canon_value(val[k]) for k in sorted(val.keys())}
            if isinstance(val, (list, tuple)):
                return [_canon_value(v) for v in val]
            return val

        canonical = _canon_value(record)
        return json.dumps(
            canonical,
            ensure_ascii=False,
            separators=(",", ":"),
            sort_keys=False,  # Already sorted recursively
        ).encode("utf-8")

    @staticmethod
    def _hash_bytes(data: bytes) -> str:
        """SHA256 hash bytes to 64-char hex string."""
        return hashlib.sha256(data).hexdigest()

    def append(
        self,
        actor: str,
        action: str,
        target: str,
        details: dict[str, object] | None = None,
    ) -> AuditRecord:
        """Append a record to the audit log.

        Args:
            actor: Actor identifier.
            action: Action name.
            target: Target identifier.
            details: Optional context dict.

        Returns:
            The appended AuditRecord.
        """
        if details is None:
            details = {}

        with self._lock:
            # Get previous record for chaining
            cursor = self._conn.execute(
                "SELECT record_hash FROM audit_log ORDER BY seq DESC LIMIT 1"
            )
            row = cursor.fetchone()
            prev_hash = row[0] if row else "0" * 64

            # Timestamp (UTC)
            timestamp = datetime.now(UTC).isoformat()

            # Build record dict (without seq yet, since it's auto-generated)
            # We'll insert and get the seq back
            record_dict = {
                "actor": actor,
                "action": action,
                "target": target,
                "details": details,
                "prev_hash": prev_hash,
            }

            # Canonicalize and hash (omitting record_hash and signature)
            canonical = self._canonicalize(record_dict)
            record_hash = self._hash_bytes(canonical)

            # Sign if key is loaded
            if self._signing_key:
                sig_bytes = self._signing_key.sign(canonical)
                signature = f"ed25519:{base64.b64encode(sig_bytes).decode('ascii')}"
            else:
                signature = "unsigned"

            # Insert into DB
            self._conn.execute(
                """
                INSERT INTO audit_log
                (timestamp, actor, action, target, details, prev_hash, record_hash, signature)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    timestamp,
                    actor,
                    action,
                    target,
                    json.dumps(details),
                    prev_hash,
                    record_hash,
                    signature,
                ),
            )

            # Get the sequence number of the inserted row
            cursor = self._conn.execute("SELECT last_insert_rowid()")
            seq = cursor.fetchone()[0]
            assert isinstance(seq, int)

            # Construct and return the AuditRecord
            return AuditRecord(
                seq=seq,
                timestamp=timestamp,
                actor=actor,
                action=action,
                target=target,
                details=details,
                prev_hash=prev_hash,
                record_hash=record_hash,
                signature=signature,
            )

    def get(self, seq: int) -> AuditRecord | None:
        """Get a record by sequence number.

        Args:
            seq: Sequence number to retrieve.

        Returns:
            The AuditRecord if found, None otherwise.
        """
        with self._lock:
            cursor = self._conn.execute(
                """
                SELECT seq, timestamp, actor, action, target, details,
                       prev_hash, record_hash, signature
                FROM audit_log WHERE seq = ?
                """,
                (seq,),
            )
            row = cursor.fetchone()
            if row:
                return self._row_to_record(row)
            return None

    def tail(self, limit: int = 50) -> list[AuditRecord]:
        """Get the most recent records.

        Args:
            limit: Maximum number of records to return.

        Returns:
            List of AuditRecords, newest first.
        """
        with self._lock:
            cursor = self._conn.execute(
                """
                SELECT seq, timestamp, actor, action, target, details,
                       prev_hash, record_hash, signature
                FROM audit_log ORDER BY seq DESC LIMIT ?
                """,
                (limit,),
            )
            return [self._row_to_record(row) for row in cursor.fetchall()]

    def verify_chain(self) -> tuple[bool, int | None]:
        """Verify the integrity of the entire audit chain.

        Checks:
        1. seq is strictly monotonic from 1.
        2. prev_hash correctly chains to previous record_hash.
        3. record_hash matches sha256(canonical(record)).
        4. Signature (if present) verifies against public key.

        Returns:
            (True, None) if chain is valid.
            (False, first_bad_seq) if chain is broken.
        """
        with self._lock:
            cursor = self._conn.execute(
                """
                SELECT seq, timestamp, actor, action, target, details,
                       prev_hash, record_hash, signature
                FROM audit_log ORDER BY seq
                """
            )
            records = cursor.fetchall()

            if not records:
                return (True, None)

            expected_seq = 1
            prev_hash = "0" * 64

            for row in records:
                seq, timestamp, actor, action, target, details_json, row_prev_hash, record_hash, signature = row

                # Type assertions for SQLite columns
                assert isinstance(seq, int)
                assert isinstance(timestamp, str)
                assert isinstance(actor, str)
                assert isinstance(action, str)
                assert isinstance(target, str)
                assert isinstance(details_json, str)
                assert isinstance(row_prev_hash, str)
                assert isinstance(record_hash, str)
                assert isinstance(signature, str)

                # Check seq monotonicity
                if seq != expected_seq:
                    return (False, seq)

                # Check prev_hash chain
                if row_prev_hash != prev_hash:
                    return (False, seq)

                # Parse details
                details = json.loads(details_json)
                assert isinstance(details, dict)

                # Reconstruct and verify record_hash
                record_dict = {
                    "actor": actor,
                    "action": action,
                    "target": target,
                    "details": details,
                    "prev_hash": row_prev_hash,
                }
                canonical = self._canonicalize(record_dict)
                expected_hash = self._hash_bytes(canonical)

                if record_hash != expected_hash:
                    return (False, seq)

                # Verify signature if present and key available
                if signature != "unsigned" and self._verifying_key:
                    if not signature.startswith("ed25519:"):
                        return (False, seq)
                    try:
                        sig_b64 = signature.split(":", 1)[1]
                        sig_bytes = base64.b64decode(sig_b64)
                        # Will raise InvalidSignature if verification fails
                        self._verifying_key.verify(sig_bytes, canonical)  # type: ignore[attr-defined]
                    except Exception:
                        return (False, seq)

                expected_seq += 1
                prev_hash = record_hash

            return (True, None)

    @staticmethod
    def _row_to_record(row: tuple[object, ...]) -> AuditRecord:
        """Convert a DB row to an AuditRecord."""
        seq, timestamp, actor, action, target, details_json, prev_hash, record_hash, signature = row

        # Type assertions
        assert isinstance(seq, int)
        assert isinstance(timestamp, str)
        assert isinstance(actor, str)
        assert isinstance(action, str)
        assert isinstance(target, str)
        assert isinstance(details_json, str)
        assert isinstance(prev_hash, str)
        assert isinstance(record_hash, str)
        assert isinstance(signature, str)

        details = json.loads(details_json)
        assert isinstance(details, dict)

        return AuditRecord(
            seq=seq,
            timestamp=timestamp,
            actor=actor,
            action=action,
            target=target,
            details=details,
            prev_hash=prev_hash,
            record_hash=record_hash,
            signature=signature,
        )

    def close(self) -> None:
        """Close the database connection."""
        with self._lock:
            self._conn.close()
