# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Audit log store — hash-chained, Ed25519-signed append-only ledger.

Provides cryptographic integrity guarantees for Ground Truth Verification.
"""
from gtv.audit.store import AuditRecord, AuditStore

__all__ = ["AuditRecord", "AuditStore"]
