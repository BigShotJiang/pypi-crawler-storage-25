# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""JSONL-on-disk registry for PluginManifest entries.

Provides a simple, append-only registry where each line is a JSON-encoded manifest.
Functions support lookup by name and retrieval of the latest version.
"""
from __future__ import annotations

import json
from pathlib import Path

from gtv.marketplace.manifest import PluginManifest


def load_registry(path: Path) -> list[PluginManifest]:
    """Load all manifests from a JSONL registry file.

    Args:
        path: Path to the JSONL registry file.

    Returns:
        List of PluginManifest objects (empty if file does not exist).
        Silently skips malformed lines.
    """
    if not path.exists():
        return []

    manifests: list[PluginManifest] = []
    try:
        with open(path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    data = json.loads(line)
                    manifest = PluginManifest.model_validate(data)
                    manifests.append(manifest)
                except Exception:
                    # Log and skip malformed entries silently
                    pass
    except OSError:
        # Registry file does not exist or cannot be read; return empty list
        return []

    return manifests


def add_manifest(path: Path, manifest: PluginManifest) -> None:
    """Append a manifest to the JSONL registry.

    Rejects duplicates: if a manifest with the same name and version already
    exists in the registry, raises ValueError.

    Args:
        path: Path to the JSONL registry file.
        manifest: PluginManifest to append.

    Raises:
        ValueError: If a duplicate (same name + version) already exists.
    """
    existing = load_registry(path)

    # Check for duplicates
    for existing_manifest in existing:
        if (
            existing_manifest.name == manifest.name
            and existing_manifest.version == manifest.version
        ):
            raise ValueError(
                f"Duplicate manifest: {manifest.name}@{manifest.version} "
                "already exists in registry"
            )

    # Append to registry
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "a", encoding="utf-8") as f:
        f.write(manifest.model_dump_json() + "\n")


def find_by_name(path: Path, name: str) -> list[PluginManifest]:
    """Find all versions of a plugin by name.

    Returns manifests sorted by version (newest first). Uses packaging.version.Version
    for semantic version ordering.

    Args:
        path: Path to the JSONL registry file.
        name: Plugin name to search for.

    Returns:
        List of PluginManifest objects matching the name (newest first).
    """
    from packaging.version import Version as PackagingVersion

    all_manifests = load_registry(path)
    matching = [m for m in all_manifests if m.name == name]

    # Sort by version descending (newest first)
    matching.sort(
        key=lambda m: PackagingVersion(m.version),
        reverse=True,
    )

    return matching


def latest(path: Path, name: str) -> PluginManifest | None:
    """Get the latest version of a plugin by name.

    Args:
        path: Path to the JSONL registry file.
        name: Plugin name to search for.

    Returns:
        The latest PluginManifest, or None if not found.
    """
    matches = find_by_name(path, name)
    return matches[0] if matches else None
