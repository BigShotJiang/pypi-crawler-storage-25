# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Plugin marketplace — manifest schema, registry, and CLI for publishing adapters.

Provides a lightweight marketplace for third-party SourceAdapter plugins:
- Manifest schema defining plugin metadata and safety fields
- JSONL-on-disk registry for discovery
- CLI for publishing and listing plugins
"""

from gtv.marketplace.manifest import PluginManifest

__all__ = ["PluginManifest"]
