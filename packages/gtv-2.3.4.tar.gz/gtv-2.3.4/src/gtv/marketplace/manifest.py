# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Plugin manifest schema — metadata contract between marketplace and plugin authors.

Defines PluginManifest: a Pydantic model encoding name, version, license, DID,
entry point, and other safety-critical fields that third-party authors supply
when publishing a SourceAdapter plugin.
"""

from __future__ import annotations

import re
from datetime import datetime
from typing import Literal

from packaging.version import Version as PackagingVersion
from pydantic import BaseModel, Field, HttpUrl, field_validator

# SPDX license allowlist: common open-source licenses suitable for GTV plugins.
ALLOWED_SPDX_LICENSES = {"MIT", "Apache-2.0", "BSD-3-Clause", "MPL-2.0"}

# Regex for slug validation: lowercase alphanumeric + dashes only.
SLUG_PATTERN = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")


class PluginManifest(BaseModel):
    """Contract between marketplace and plugin author.

    Safety-critical fields:
      - name: slug form, uniquely identifies the plugin
      - version: PEP 440 compliant
      - entry_point: module:ClassName path to the SourceAdapter subclass
      - source_did: did:web: or did:key: identity of the plugin author
      - license: SPDX id from a curated allowlist
      - signed_sha256: sha256 of the published wheel (populated by publish)
      - trust_tier_claim: what tier the author claims (gtv maintainers verify)

    Non-critical fields:
      - author: human-readable name
      - description: ≤500 chars overview
      - homepage: HTTP(S) URL for documentation
      - published_at: ISO 8601 timestamp (populated at publish)
    """

    name: str = Field(
        description="Unique slug identifier for the plugin (lowercase, dashes only)"
    )
    version: str = Field(description="PEP 440 version string")
    author: str = Field(description="Author name or organization")
    description: str = Field(
        max_length=500,
        description="Short description of what the plugin does",
    )
    homepage: HttpUrl = Field(description="URL to plugin documentation")
    entry_point: str = Field(
        description="Entry point path, e.g., 'my_pkg.adapter:MyAdapter'"
    )
    source_did: str = Field(
        description="DID identity of the plugin author (did:web: or did:key:)"
    )
    trust_tier_claim: Literal["tier_1", "tier_2", "tier_3"] = Field(
        description="Trust tier claimed by author (gtv maintainers verify before listing)"
    )
    license: str = Field(
        description="SPDX license identifier (from curated allowlist)"
    )
    signed_sha256: str | None = Field(
        default=None,
        description="SHA256 of the published wheel (populated at publish time)",
    )
    published_at: datetime | None = Field(
        default=None,
        description="ISO 8601 timestamp when the manifest was published",
    )

    @field_validator("name")
    @classmethod
    def validate_slug(cls, v: str) -> str:
        if not SLUG_PATTERN.match(v):
            raise ValueError(
                f"name must be lowercase alphanumeric with dashes only, got: {v}"
            )
        return v

    @field_validator("version")
    @classmethod
    def validate_version(cls, v: str) -> str:
        try:
            PackagingVersion(v)
        except Exception as e:
            raise ValueError(f"version must be PEP 440 compliant: {e}") from e
        return v

    @field_validator("entry_point")
    @classmethod
    def validate_entry_point(cls, v: str) -> str:
        # Format: module.path:ClassName
        if ":" not in v:
            raise ValueError(
                f"entry_point must be in format 'module.path:ClassName', got: {v}"
            )
        module_path, class_name = v.rsplit(":", 1)
        if not module_path or not class_name:
            raise ValueError(
                f"entry_point parts must be non-empty, got: {v}"
            )
        # Basic validation: module path should have dots and alphanumerics/underscores
        if not all(
            part.replace("_", "").isalnum() for part in module_path.split(".")
        ):
            raise ValueError(
                f"entry_point module path contains invalid characters: {v}"
            )
        # Class name should be a valid Python identifier
        if not class_name.isidentifier():
            raise ValueError(
                f"entry_point class name is not a valid identifier: {v}"
            )
        return v

    @field_validator("source_did")
    @classmethod
    def validate_source_did(cls, v: str) -> str:
        if not (v.startswith("did:web:") or v.startswith("did:key:")):
            raise ValueError(
                f"source_did must start with 'did:web:' or 'did:key:', got: {v}"
            )
        return v

    @field_validator("license")
    @classmethod
    def validate_license(cls, v: str) -> str:
        if v not in ALLOWED_SPDX_LICENSES:
            allowed = ", ".join(sorted(ALLOWED_SPDX_LICENSES))
            raise ValueError(
                f"license must be one of: {allowed}, got: {v}"
            )
        return v

    @field_validator("signed_sha256")
    @classmethod
    def validate_signed_sha256(cls, v: str | None) -> str | None:
        if v is None:
            return None
        # SHA256 is exactly 64 hex characters
        if not re.match(r"^[a-f0-9]{64}$", v.lower()):
            raise ValueError(
                f"signed_sha256 must be a valid SHA256 hex string (64 chars), got: {v}"
            )
        return v.lower()

