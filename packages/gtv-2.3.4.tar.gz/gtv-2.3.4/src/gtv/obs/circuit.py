# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""SLO-driven circuit breaker for source adapters (W40).

Problem: one flaky adapter should not drag down every verify call.
When an upstream's error rate climbs past an operator-chosen
threshold, keep calling it and the whole verdict pipeline slows to
that adapter's tail latency. The cost of each failed call is paid
*per request* — and with N adapters in parallel, a single broken
one can dominate p99.

Solution: wrap every adapter in a rolling-window failure tracker.
When the ratio of failures in the last ``window`` calls exceeds
``failure_ratio``, trip to OPEN: ``query()`` short-circuits to ``[]``
without calling upstream. After ``cooldown_s`` seconds we move to
HALF_OPEN — the next call is a real probe. A successful probe
closes the breaker; a failing probe re-opens it with a fresh timer.

The same pattern (Netflix Hystrix, Envoy outlier detection) is a
well-understood way to keep p99 bounded when an upstream is sick.
We don't invent a new algorithm — we implement the boring one
correctly and make it observable.

Config (env vars):
  * ``GTV_CB_ENABLED`` — ``0`` to bypass; default ``1``.
  * ``GTV_CB_WINDOW`` — sample size, int >= 1, default 20.
  * ``GTV_CB_MIN_SAMPLES`` — minimum calls before evaluating, default 5.
  * ``GTV_CB_FAILURE_RATIO`` — trip threshold in [0.0, 1.0], default 0.5.
  * ``GTV_CB_COOLDOWN_S`` — OPEN→HALF_OPEN delay, default 30.

The breaker is Prometheus-observable via the ``gtv_circuit_state``
gauge (0=CLOSED, 1=HALF_OPEN, 2=OPEN, labelled by adapter).
"""
from __future__ import annotations

import logging
import os
import time
from collections import deque
from dataclasses import dataclass
from enum import IntEnum

from prometheus_client import Gauge

from gtv.adapters.base import RawSnapshot, SourceAdapter
from gtv.models import Claim, Evidence, HealthStatus

logger = logging.getLogger(__name__)


class CircuitState(IntEnum):
    """Gauge-friendly ints so Grafana can alert on numeric comparison."""

    CLOSED = 0
    HALF_OPEN = 1
    OPEN = 2


CIRCUIT_STATE = Gauge(
    "gtv_circuit_state",
    "Adapter circuit-breaker state (0=CLOSED, 1=HALF_OPEN, 2=OPEN)",
    ["adapter"],
)


class CircuitOpenError(RuntimeError):
    """Raised by ``snapshot()`` when the breaker is OPEN.

    ``query()`` swallows this and returns ``[]`` to match the soft-fail
    contract every adapter already honours. ``snapshot()`` surfaces it
    so auditors see a clear "blocked by breaker" signal.
    """


@dataclass(frozen=True)
class CircuitConfig:
    window: int = 20
    min_samples: int = 5
    failure_ratio: float = 0.5
    cooldown_s: float = 30.0

    def __post_init__(self) -> None:
        if self.window < 1:
            raise ValueError("window must be >= 1")
        if self.min_samples < 1:
            raise ValueError("min_samples must be >= 1")
        if not 0.0 <= self.failure_ratio <= 1.0:
            raise ValueError("failure_ratio must be in [0.0, 1.0]")
        if self.cooldown_s < 0:
            raise ValueError("cooldown_s must be >= 0")


def load_circuit_config_from_env() -> CircuitConfig:
    """Build a CircuitConfig from environment variables."""
    return CircuitConfig(
        window=int(os.environ.get("GTV_CB_WINDOW", "20")),
        min_samples=int(os.environ.get("GTV_CB_MIN_SAMPLES", "5")),
        failure_ratio=float(os.environ.get("GTV_CB_FAILURE_RATIO", "0.5")),
        cooldown_s=float(os.environ.get("GTV_CB_COOLDOWN_S", "30")),
    )


def _now() -> float:
    """Monotonic clock — monkeypatchable in tests via this symbol."""
    return time.monotonic()


class AdapterCircuitBreaker(SourceAdapter):
    """Wraps a ``SourceAdapter`` with a rolling-window circuit breaker.

    Drop-in: callers keep using the ``SourceAdapter`` interface, so
    the registry, discovery, and evidence pipeline are unchanged.
    Only the construction site needs to wrap.
    """

    def __init__(
        self,
        inner: SourceAdapter,
        config: CircuitConfig | None = None,
    ) -> None:
        self._inner = inner
        self._cfg = config or CircuitConfig()
        self._state: CircuitState = CircuitState.CLOSED
        self._history: deque[bool] = deque(maxlen=self._cfg.window)
        self._opened_at: float | None = None
        # Mirror the wrapped adapter's identity so health checks, the
        # verdict engine, and the registry treat us transparently.
        self.source_did = inner.source_did
        self.name = inner.name
        self.trust_tier = inner.trust_tier
        self.freshness_sla_s = inner.freshness_sla_s
        self._publish_state()

    # ---- core state machine -----------------------------------------

    @property
    def state(self) -> CircuitState:
        return self._state

    def _publish_state(self) -> None:
        CIRCUIT_STATE.labels(adapter=self._inner.name).set(int(self._state))

    def _transition(self, new: CircuitState, *, reason: str) -> None:
        if new is self._state:
            return
        logger.info(
            "circuit[%s] %s -> %s (%s)",
            self._inner.name, self._state.name, new.name, reason,
        )
        self._state = new
        self._publish_state()

    def _maybe_trip(self) -> None:
        if len(self._history) < self._cfg.min_samples:
            return
        failures = sum(1 for ok in self._history if not ok)
        ratio = failures / len(self._history)
        if ratio >= self._cfg.failure_ratio:
            self._opened_at = _now()
            self._transition(
                CircuitState.OPEN,
                reason=f"failure_ratio={ratio:.2f} >= {self._cfg.failure_ratio}",
            )

    def _cooldown_elapsed(self) -> bool:
        if self._opened_at is None:
            return True
        return (_now() - self._opened_at) >= self._cfg.cooldown_s

    def _record(self, ok: bool) -> None:
        """Record an outcome and advance the state machine."""
        self._history.append(ok)
        if self._state is CircuitState.HALF_OPEN:
            if ok:
                self._history.clear()
                self._opened_at = None
                self._transition(CircuitState.CLOSED, reason="probe succeeded")
            else:
                self._opened_at = _now()
                self._transition(CircuitState.OPEN, reason="probe failed")
            return
        # CLOSED: evaluate the ratio; if we trip, the open-timer starts here.
        if self._state is CircuitState.CLOSED:
            self._maybe_trip()

    def _should_skip(self) -> bool:
        """Return True iff the breaker should short-circuit this call."""
        if self._state is CircuitState.OPEN:
            if self._cooldown_elapsed():
                self._transition(CircuitState.HALF_OPEN, reason="cooldown elapsed")
                return False  # the probe is allowed through
            return True
        return False

    # ---- SourceAdapter surface --------------------------------------

    async def query(self, claim: Claim, max_items: int = 5) -> list[Evidence]:
        if self._should_skip():
            return []
        try:
            result = await self._inner.query(claim, max_items=max_items)
        except Exception:
            self._record(False)
            raise
        self._record(True)
        return result

    async def snapshot(self, url: str) -> RawSnapshot:
        if self._should_skip():
            raise CircuitOpenError(f"circuit OPEN for adapter {self._inner.name}")
        try:
            result = await self._inner.snapshot(url)
        except Exception:
            self._record(False)
            raise
        self._record(True)
        return result

    async def health(self) -> HealthStatus:
        """Report the wrapped adapter's health, downgraded by breaker state.

        A healthy upstream but OPEN breaker is still DEGRADED from the
        caller's perspective — the engine must see "this adapter is not
        usable right now" regardless of upstream HTTP 200s.
        """
        upstream = await self._inner.health()
        if self._state is CircuitState.OPEN:
            return HealthStatus(
                state="DEGRADED",
                detail=f"circuit OPEN; upstream state={upstream.state}",
            )
        return upstream

    async def close(self) -> None:
        await self._inner.close()
