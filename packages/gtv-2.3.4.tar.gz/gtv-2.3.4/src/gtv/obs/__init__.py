# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Observability stubs for smoke test."""
