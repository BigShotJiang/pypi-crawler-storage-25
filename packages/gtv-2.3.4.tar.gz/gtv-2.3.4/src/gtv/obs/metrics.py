# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Prometheus metrics for Ground Truth Verification.

Metrics declared as module-level singletons and used throughout the service.
"""
from __future__ import annotations

from prometheus_client import Counter, Histogram

from gtv.models import Verdict

# Verdicts issued by outcome
VERDICTS_TOTAL = Counter(
    "gtv_verdicts_total",
    "Verdicts issued by outcome",
    ["verdict"],
)

# verify_claim wall time
VERIFY_DURATION = Histogram(
    "gtv_verify_duration_seconds",
    "verify_claim wall time",
    ["verdict"],
)

# Per-adapter query latency
ADAPTER_LATENCY = Histogram(
    "gtv_adapter_latency_seconds",
    "Per-adapter query latency",
    ["adapter", "outcome"],
)

# Evidence items returned per claim
EVIDENCE_COUNT = Histogram(
    "gtv_evidence_count",
    "Evidence items returned per claim",
)

# Verdict-cache hits (by tool name).
CACHE_HITS = Counter(
    "gtv_cache_hits_total",
    "Verdict cache hits",
    ["tool"],
)

# Verdict-cache misses (by tool name).
CACHE_MISSES = Counter(
    "gtv_cache_misses_total",
    "Verdict cache misses",
    ["tool"],
)

# Verdict-cache entries evicted for cause (signature_mismatch, deserialize_error).
CACHE_INVALIDATIONS = Counter(
    "gtv_cache_invalidations_total",
    "Verdict cache evictions, by reason",
    ["reason"],
)

# PII redactions applied before sealing, by kind (EMAIL, SSN, CC, ...).
REDACTIONS_TOTAL = Counter(
    "gtv_redactions_total",
    "PII redactions applied before sealing, by kind",
    ["kind"],
)

# Claims rejected at the request boundary for containing PII.
REDACTIONS_REJECTED = Counter(
    "gtv_redactions_rejected_total",
    "Requests rejected at ingress because the claim contained PII",
)

# Per-tenant request counter. Kept separate from the core verdict /
# cache metrics so adding tenant labels does not multiply cardinality on
# every Grafana panel. ``tenant_id`` is ``"_default"`` for unattributed
# traffic (auth disabled or env-var key fallback).
TENANT_REQUESTS = Counter(
    "gtv_tenant_requests_total",
    "Requests by tenant, MCP tool, and verdict",
    ["tenant_id", "tool", "verdict"],
)


def record_verdict(verdict: Verdict, duration_s: float, evidence_count: int) -> None:
    """Record a verdict with its duration and evidence count.

    Args:
        verdict: The Verdict enum value.
        duration_s: Elapsed time in seconds.
        evidence_count: Number of evidence items retrieved.
    """
    VERDICTS_TOTAL.labels(verdict=verdict.value).inc()
    VERIFY_DURATION.labels(verdict=verdict.value).observe(duration_s)
    EVIDENCE_COUNT.observe(evidence_count)


def record_adapter_call(adapter_name: str, outcome: str, latency_s: float) -> None:
    """Record an adapter call with its outcome and latency.

    Args:
        adapter_name: Name/DID of the adapter.
        outcome: One of "ok", "error", "timeout".
        latency_s: Elapsed time in seconds.
    """
    ADAPTER_LATENCY.labels(adapter=adapter_name, outcome=outcome).observe(latency_s)
