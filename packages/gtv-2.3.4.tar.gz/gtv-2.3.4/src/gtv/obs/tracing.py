# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""OpenTelemetry tracing instrumentation for FastAPI.

Configures traces to export to OTLP HTTP if GTV_OTEL_ENDPOINT is set,
otherwise uses a no-op provider for local development.
"""
from __future__ import annotations

import os

from fastapi import FastAPI
from opentelemetry import trace
from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor


def init_tracing(app: FastAPI) -> None:
    """Initialize OpenTelemetry tracing for FastAPI.

    Idempotent. Reads GTV_OTEL_ENDPOINT env var; if unset, installs no-op provider
    (traces created but not exported, keeps code paths live for local dev).
    Instruments FastAPI.

    Args:
        app: FastAPI application instance.
    """
    otel_endpoint = os.getenv("GTV_OTEL_ENDPOINT")

    if otel_endpoint:
        # Configure OTLP HTTP exporter and batch processor
        exporter = OTLPSpanExporter(endpoint=otel_endpoint)
        trace_provider = TracerProvider()
        trace_provider.add_span_processor(BatchSpanProcessor(exporter))
        trace.set_tracer_provider(trace_provider)
    else:
        # No-op provider for local dev; traces still created but not exported
        trace.set_tracer_provider(TracerProvider())

    # Instrument FastAPI
    FastAPIInstrumentor.instrument_app(app)
