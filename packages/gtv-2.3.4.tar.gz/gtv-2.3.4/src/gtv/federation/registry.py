# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""In-memory issuer registry for the federation.

Supports registration, lookup, and filtering of trusted issuers.
Each issuer has a DID, trust tier, and optional Sigstore identity binding.
"""
from __future__ import annotations

from pydantic import BaseModel

from gtv.models import TrustTier


class TrustedIssuer(BaseModel):
    """A trusted issuer in the federation.

    Attributes:
        did: DID identifying this issuer (e.g., "did:web:verify.groundtruth.example").
        trust_tier: The trust tier (TIER_1, TIER_2, or TIER_3).
        display_name: Human-readable name for this issuer.
        expected_fulcio_oidc: Optional OIDC issuer URL expected in Sigstore certificates.
        expected_issuer_email: Optional email identity expected in Sigstore certificates.
        notes: Optional notes about this issuer (e.g., "Local/stub issuer for development").
    """

    did: str
    trust_tier: TrustTier
    display_name: str
    expected_fulcio_oidc: str | None = None
    expected_issuer_email: str | None = None
    notes: str | None = None


class IssuerRegistry:
    """In-memory registry of trusted issuers.

    Thread-unsafe; intended for Phase 1 only. Future versions will add
    persistence and consensus (Phase 2 scope).
    """

    def __init__(self) -> None:
        """Initialize an empty registry."""
        self._issuers: dict[str, TrustedIssuer] = {}

    def add(self, issuer: TrustedIssuer) -> None:
        """Register a new trusted issuer.

        Args:
            issuer: The issuer to add.

        Raises:
            ValueError: If the DID is already registered.
        """
        if issuer.did in self._issuers:
            raise ValueError(f"Issuer already registered: {issuer.did}")
        self._issuers[issuer.did] = issuer

    def get(self, did: str) -> TrustedIssuer | None:
        """Look up an issuer by DID.

        Args:
            did: The DID to look up.

        Returns:
            The TrustedIssuer, or None if not found.
        """
        return self._issuers.get(did)

    def remove(self, did: str) -> None:
        """Unregister an issuer by DID.

        Args:
            did: The DID to remove.

        Raises:
            ValueError: If the DID is not registered.
        """
        if did not in self._issuers:
            raise ValueError(f"Issuer not found: {did}")
        del self._issuers[did]

    def list_all(self) -> list[TrustedIssuer]:
        """List all registered issuers.

        Returns:
            A list of all TrustedIssuer objects, in arbitrary order.
        """
        return list(self._issuers.values())

    def filter_by_tier(self, tier: TrustTier) -> list[TrustedIssuer]:
        """Filter issuers by trust tier.

        Args:
            tier: The trust tier to filter by.

        Returns:
            A list of issuers with the specified tier.
        """
        return [issuer for issuer in self._issuers.values() if issuer.trust_tier == tier]


# Module-level default registry, pre-populated with one reference entry.
DEFAULT_REGISTRY = IssuerRegistry()
DEFAULT_REGISTRY.add(
    TrustedIssuer(
        did="did:web:verify.groundtruth.example",
        trust_tier=TrustTier.TIER_1,
        display_name="GTV Reference Implementation",
        notes="Local/stub issuer for development.",
    )
)
