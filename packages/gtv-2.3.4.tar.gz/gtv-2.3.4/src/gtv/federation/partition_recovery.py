# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Network partition recovery via verdict catch-up protocol.

When a peer rejoins after an outage, it retrieves verdicts it missed from
its neighbors using a monotonically-increasing sequence number. Each verdict
is assigned a seq on emission; on rejoin, the recovering peer asks peers
for verdicts_since(local_seq) and replays them.

This is a catch-up protocol, not a CRDT. The consensus layer handles
conflicting claims; we just apply entries deterministically in seq order.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime
from typing import Protocol

import httpx
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)


class VerdictLogEntry(BaseModel):
    """A single entry in the verdict log with monotonic sequence number."""

    seq: int = Field(..., description="Monotonically increasing sequence number per peer")
    verdict_id: str = Field(..., description="Immutable verdict identifier")
    tenant_id: str = Field(..., description="Tenant that issued this verdict")
    emitted_at: datetime = Field(..., description="UTC timestamp of emission")
    peer_did: str = Field(..., description="DID of the peer that emitted this verdict")


class VerdictLog(Protocol):
    """Duck-typed interface for verdict log storage and retrieval."""

    def latest_seq(self) -> int:
        """Return the highest sequence number seen so far (or 0 if empty)."""
        ...

    def append(self, entry: VerdictLogEntry) -> None:
        """Append an entry to the log.

        Must enforce monotonicity: reject if entry.seq <= latest_seq().
        """
        ...

    def since(self, seq: int, limit: int = 1000) -> list[VerdictLogEntry]:
        """Return all entries with sequence > seq, ordered ascending, up to limit.

        Args:
            seq: The reference sequence number (exclusive).
            limit: Maximum entries to return.

        Returns:
            List of VerdictLogEntry ordered by seq ascending.
        """
        ...


class InMemoryVerdictLog:
    """In-memory implementation of VerdictLog using a sorted dict."""

    def __init__(self) -> None:
        """Initialize an empty log."""
        self._entries: dict[int, VerdictLogEntry] = {}

    def latest_seq(self) -> int:
        """Return the highest sequence number, or 0 if empty."""
        if not self._entries:
            return 0
        return max(self._entries.keys())

    def append(self, entry: VerdictLogEntry) -> None:
        """Append an entry, enforcing monotonic increase.

        Raises:
            ValueError: If entry.seq is not strictly greater than latest_seq().
        """
        latest = self.latest_seq()
        if entry.seq <= latest:
            raise ValueError(
                f"Sequence regression: entry seq {entry.seq} not > latest {latest}"
            )
        self._entries[entry.seq] = entry

    def since(self, seq: int, limit: int = 1000) -> list[VerdictLogEntry]:
        """Return entries with seq > given value, in ascending order."""
        # Get all seq values greater than the given seq, sorted
        keys = sorted(k for k in self._entries if k > seq)
        # Limit to the requested number
        keys = keys[:limit]
        # Return entries in order
        return [self._entries[k] for k in keys]


@dataclass(frozen=True)
class CatchUpReport:
    """Summary of a catch-up operation."""

    peers_reached: int = 0
    peers_unreachable: int = 0
    entries_applied: int = 0
    conflicts: list[str] = field(default_factory=list)
    new_latest_seq: int = 0


class PartitionRecovery:
    """Orchestrates catch-up from network partition via batch polling from peers."""

    def __init__(
        self,
        local_log: VerdictLog,
        peers: list[dict] | None = None,
        httpx_client: httpx.AsyncClient | None = None,
        batch_size: int = 500,
    ) -> None:
        """Initialize partition recovery handler.

        Args:
            local_log: The local VerdictLog (duck-typed).
            peers: List of peer dicts with 'did' and 'endpoint_url' keys.
            httpx_client: Optional reusable httpx.AsyncClient.
            batch_size: Max entries to fetch per request (default 500).
        """
        self.local_log = local_log
        self.peers = peers or []
        self.httpx_client = httpx_client
        self.batch_size = batch_size
        self._seen_verdict_ids: set[str] = set()

    async def catch_up(self) -> CatchUpReport:
        """Fetch verdicts from all peers and replay them locally.

        For each peer:
        1. Fetch GET {peer}/federation/verdicts_since?seq=<local_latest>&limit=<batch>
        2. Deduplicate by verdict_id (first-writer-wins).
        3. Apply entries in seq order, enforcing monotonicity.
        4. If more entries available, paginate (refetch with updated seq).

        Handles:
        - Unreachable peers: skip, log, continue.
        - Partial batches: continue pagination.
        - Conflicting verdict_ids: log conflict, keep first.

        Returns:
            CatchUpReport with summary stats.
        """
        if not self.peers:
            return CatchUpReport(
                peers_reached=0,
                peers_unreachable=0,
                entries_applied=0,
                conflicts=[],
                new_latest_seq=self.local_log.latest_seq(),
            )

        peers_reached = 0
        peers_unreachable = 0
        total_applied = 0
        conflicts: list[str] = []

        # Collect all verdicts from all peers
        all_verdicts: list[VerdictLogEntry] = []

        for peer in self.peers:
            peer_did = peer.get("did", "unknown")
            endpoint_url = peer.get("endpoint_url", "")

            if not endpoint_url:
                logger.warning(f"Peer {peer_did} missing endpoint_url")
                peers_unreachable += 1
                continue

            try:
                # Fetch all verdicts from this peer via pagination
                peer_verdicts = await self._fetch_from_peer(endpoint_url, peer_did)
                all_verdicts.extend(peer_verdicts)
                peers_reached += 1
            except Exception as e:
                logger.warning(f"Failed to reach peer {peer_did} at {endpoint_url}: {e}")
                peers_unreachable += 1
                continue

        # Deduplicate by verdict_id (first-writer-wins)
        seen_by_id: dict[str, VerdictLogEntry] = {}
        for entry in all_verdicts:
            if entry.verdict_id in seen_by_id:
                # Conflict detected
                conflicts.append(entry.verdict_id)
                logger.debug(
                    f"Verdict {entry.verdict_id} from multiple peers; keeping first"
                )
            else:
                seen_by_id[entry.verdict_id] = entry

        # Sort deduplicated verdicts by seq and apply
        deduplicated = sorted(seen_by_id.values(), key=lambda e: e.seq)
        for entry in deduplicated:
            try:
                self.local_log.append(entry)
                total_applied += 1
            except ValueError as e:
                logger.error(f"Failed to append verdict {entry.verdict_id}: {e}")

        return CatchUpReport(
            peers_reached=peers_reached,
            peers_unreachable=peers_unreachable,
            entries_applied=total_applied,
            conflicts=conflicts,
            new_latest_seq=self.local_log.latest_seq(),
        )

    async def _fetch_from_peer(
        self, endpoint_url: str, peer_did: str
    ) -> list[VerdictLogEntry]:
        """Fetch all verdicts from a peer via pagination.

        Args:
            endpoint_url: Base URL of the peer.
            peer_did: Peer identifier for logging.

        Returns:
            List of VerdictLogEntry objects from this peer.

        Raises:
            Exception: On network errors or malformed responses.
        """
        verdicts: list[VerdictLogEntry] = []
        current_seq = self.local_log.latest_seq()

        while True:
            # Fetch batch
            url = f"{endpoint_url}/federation/verdicts_since"
            params = {"seq": current_seq, "limit": self.batch_size}

            try:
                if self.httpx_client is not None:
                    resp = await self.httpx_client.get(url, params=params, timeout=10.0)
                else:
                    async with httpx.AsyncClient(timeout=10.0) as client:
                        resp = await client.get(url, params=params)

                if resp.status_code != 200:
                    raise RuntimeError(
                        f"Peer {peer_did} returned {resp.status_code}: {resp.text[:200]}"
                    )

                data = resp.json()
                if not isinstance(data, dict) or "entries" not in data:
                    raise ValueError(f"Malformed response from {peer_did}: missing 'entries' key")

                entries_data = data.get("entries", [])
                if not isinstance(entries_data, list):
                    raise ValueError("Malformed response: 'entries' is not a list")

                batch = [VerdictLogEntry(**e) for e in entries_data]

                if not batch:
                    # No more entries
                    break

                verdicts.extend(batch)
                current_seq = batch[-1].seq

                # If batch is smaller than limit, we've reached the end
                if len(batch) < self.batch_size:
                    break

            except Exception as e:
                logger.error(f"Error fetching from {peer_did}: {e}")
                raise

        return verdicts


def make_verdicts_since_handler(log: VerdictLog):
    """Create an async FastAPI handler for GET /federation/verdicts_since.

    The returned handler accepts query parameters:
    - seq: reference sequence (exclusive); defaults to 0.
    - limit: max entries to return; defaults to 1000.

    Returns a JSON response:
    {
        "entries": [
            {
                "seq": <int>,
                "verdict_id": <str>,
                "tenant_id": <str>,
                "emitted_at": <ISO 8601>,
                "peer_did": <str>
            },
            ...
        ]
    }

    Args:
        log: The VerdictLog instance (duck-typed).

    Returns:
        An async callable that FastAPI can mount.
    """

    async def handler(seq: int = 0, limit: int = 1000):
        """Handle GET /federation/verdicts_since?seq=<int>&limit=<int>."""
        # Enforce reasonable limits
        limit = min(limit, 10000)
        limit = max(limit, 1)

        entries = log.since(seq, limit=limit)
        return {
            "entries": [
                {
                    "seq": e.seq,
                    "verdict_id": e.verdict_id,
                    "tenant_id": e.tenant_id,
                    "emitted_at": e.emitted_at.isoformat(),
                    "peer_did": e.peer_did,
                }
                for e in entries
            ]
        }

    return handler
