# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Signed domain bundles for federation peers.

A domain bundle is a signed JSON document that declares which peers are
authoritative for which evidence domains (physics, cs, biomed), plus
min-trust-tier requirements per domain. Operators sign and ship bundles;
gtv verifies signatures, caches, and routes verification accordingly.

Public API:
    @dataclass(frozen=True)
    class DomainBundle:
        issuer_did: str
        domain_map: dict[str, list[str]]  # domain -> list of peer DIDs
        min_tier_per_domain: dict[str, str]  # domain -> "TIER_1"|"TIER_2"|"TIER_3"
        issued_at: str  # ISO 8601 UTC
        ttl_s: int

    def sign_bundle(bundle: DomainBundle, ed25519_private_key: bytes) -> str:
        '''Return base64url-encoded JWS with detached payload hash (JCS canonical JSON).'''

    def verify_bundle(jws: str, ed25519_public_key: bytes) -> DomainBundle:
        '''Raise InvalidBundleError on bad sig / expired. Return the bundle.'''
"""
from __future__ import annotations

import base64
import json
from dataclasses import dataclass
from datetime import UTC, datetime

from cryptography.hazmat.primitives.asymmetric import ed25519

from gtv.anchor.canonicalize import canonicalize


class InvalidBundleError(Exception):
    """Raised when a domain bundle is invalid, expired, or fails signature verification."""

    pass


@dataclass(frozen=True)
class DomainBundle:
    """A signed declaration of domain -> peer mappings and trust tiers.

    Attributes:
        issuer_did: DID of the operator signing this bundle (did:key:z...).
        domain_map: Mapping of domain name to list of authoritative peer DIDs.
        min_tier_per_domain: Mapping of domain name to minimum trust tier ("TIER_1", "TIER_2", "TIER_3").
        issued_at: ISO 8601 UTC timestamp when the bundle was signed.
        ttl_s: Time-to-live in seconds. Bundle is expired if now > issued_at + ttl_s.
    """

    issuer_did: str
    domain_map: dict[str, list[str]]
    min_tier_per_domain: dict[str, str]
    issued_at: str
    ttl_s: int

    def validate(self) -> None:
        """Validate bundle structure and expiry.

        Raises:
            InvalidBundleError: If validation fails.
        """
        # Validate issued_at is ISO 8601 UTC and not expired
        try:
            issued = datetime.fromisoformat(self.issued_at.replace("Z", "+00:00"))
            if issued.tzinfo is None:
                raise ValueError("issued_at must have timezone info")
        except (ValueError, TypeError) as e:
            raise InvalidBundleError(f"Invalid issued_at format: {e}") from e

        now = datetime.now(UTC)
        # Expiry is issued_at + ttl_s (in seconds)
        issued_utc = issued.astimezone(UTC)
        expiry_timestamp = issued_utc.timestamp() + self.ttl_s
        if now.timestamp() > expiry_timestamp:
            raise InvalidBundleError("Bundle expired")

        # Validate domain_map and min_tier_per_domain consistency
        for domain in self.min_tier_per_domain:
            if domain not in self.domain_map:
                raise InvalidBundleError(
                    f"Domain {domain!r} in min_tier_per_domain but not in domain_map"
                )

        for domain in self.domain_map:
            if domain not in self.min_tier_per_domain:
                raise InvalidBundleError(
                    f"Domain {domain!r} in domain_map but not in min_tier_per_domain"
                )

        # Validate tier values
        valid_tiers = {"TIER_1", "TIER_2", "TIER_3"}
        for domain, tier in self.min_tier_per_domain.items():
            if tier not in valid_tiers:
                raise InvalidBundleError(
                    f"Invalid tier {tier!r} for domain {domain!r}; must be one of {valid_tiers}"
                )


def sign_bundle(bundle: DomainBundle, ed25519_private_key: bytes) -> str:
    """Sign a domain bundle and return a base64url-encoded JWS.

    The JWS payload is the canonical JSON form of the bundle (RFC 8785).
    Signature uses Ed25519. Returns the compact JWS form: header.payload.signature.

    Args:
        bundle: DomainBundle to sign.
        ed25519_private_key: Ed25519 private key (raw 32-byte format).

    Returns:
        Base64url-encoded JWS string (header.payload.signature).

    Raises:
        ValueError: If the private key is invalid or signing fails.
    """
    # Validate bundle structure (not expiry) before signing
    # Expiry is checked at verification time
    try:
        issued = datetime.fromisoformat(bundle.issued_at.replace("Z", "+00:00"))
        if issued.tzinfo is None:
            raise ValueError("issued_at must have timezone info")
    except (ValueError, TypeError) as e:
        raise InvalidBundleError(f"Invalid issued_at format: {e}") from e

    # Validate domain_map and min_tier_per_domain consistency
    for domain in bundle.min_tier_per_domain:
        if domain not in bundle.domain_map:
            raise InvalidBundleError(
                f"Domain {domain!r} in min_tier_per_domain but not in domain_map"
            )

    for domain in bundle.domain_map:
        if domain not in bundle.min_tier_per_domain:
            raise InvalidBundleError(
                f"Domain {domain!r} in domain_map but not in min_tier_per_domain"
            )

    # Validate tier values
    valid_tiers = {"TIER_1", "TIER_2", "TIER_3"}
    for domain, tier in bundle.min_tier_per_domain.items():
        if tier not in valid_tiers:
            raise InvalidBundleError(
                f"Invalid tier {tier!r} for domain {domain!r}; must be one of {valid_tiers}"
            )

    # Construct canonical JSON payload
    bundle_dict = {
        "issuer_did": bundle.issuer_did,
        "domain_map": bundle.domain_map,
        "min_tier_per_domain": bundle.min_tier_per_domain,
        "issued_at": bundle.issued_at,
        "ttl_s": bundle.ttl_s,
    }
    payload_bytes = canonicalize(bundle_dict)

    # Create JWS header (minimal: typ and alg)
    header = {"typ": "JWT", "alg": "EdDSA"}
    header_b64 = base64.urlsafe_b64encode(
        json.dumps(header, separators=(",", ":"), sort_keys=True).encode("utf-8")
    ).rstrip(b"=")

    # Encode payload in base64url
    payload_b64 = base64.urlsafe_b64encode(payload_bytes).rstrip(b"=")

    # Sign header.payload
    signing_input = header_b64 + b"." + payload_b64

    try:
        private_key_obj = ed25519.Ed25519PrivateKey.from_private_bytes(
            ed25519_private_key
        )
    except (ValueError, TypeError) as e:
        raise ValueError(f"Invalid Ed25519 private key: {e}") from e

    signature = private_key_obj.sign(signing_input)
    signature_b64 = base64.urlsafe_b64encode(signature).rstrip(b"=")

    return (signing_input + b"." + signature_b64).decode("ascii")


def verify_bundle(jws: str, ed25519_public_key: bytes) -> DomainBundle:
    """Verify a JWS-signed domain bundle and return the decoded bundle.

    Args:
        jws: Base64url-encoded JWS string (header.payload.signature).
        ed25519_public_key: Ed25519 public key (raw 32-byte format).

    Returns:
        Decoded and validated DomainBundle.

    Raises:
        InvalidBundleError: If signature verification fails, bundle is expired,
                      malformed JSON, or validation fails.
    """
    # Parse JWS: header.payload.signature
    parts = jws.split(".")
    if len(parts) != 3:
        raise InvalidBundleError(f"Invalid JWS format: expected 3 parts, got {len(parts)}")

    header_b64, payload_b64, signature_b64 = parts

    # Decode and verify signature
    try:
        # Add padding if needed
        def decode_b64url(s: str) -> bytes:
            padding = (4 - len(s) % 4) % 4
            return base64.urlsafe_b64decode(s + "=" * padding)

        header_json = decode_b64url(header_b64)
        payload_bytes = decode_b64url(payload_b64)
        signature = decode_b64url(signature_b64)

        header = json.loads(header_json)
        if header.get("alg") != "EdDSA":
            raise InvalidBundleError(f"Unsupported algorithm: {header.get('alg')}")

    except (ValueError, KeyError, TypeError) as e:
        raise InvalidBundleError(f"Failed to decode JWS: {e}") from e

    # Verify signature
    signing_input = header_b64.encode("ascii") + b"." + payload_b64.encode("ascii")
    try:
        public_key_obj = ed25519.Ed25519PublicKey.from_public_bytes(ed25519_public_key)
        public_key_obj.verify(signature, signing_input)
    except Exception as e:
        raise InvalidBundleError(f"Signature verification failed: {e}") from e

    # Decode and parse bundle
    try:
        bundle_dict = json.loads(payload_bytes)
    except json.JSONDecodeError as e:
        raise InvalidBundleError(f"Invalid JSON in bundle payload: {e}") from e

    # Reconstruct DomainBundle
    try:
        bundle = DomainBundle(
            issuer_did=bundle_dict["issuer_did"],
            domain_map=bundle_dict["domain_map"],
            min_tier_per_domain=bundle_dict["min_tier_per_domain"],
            issued_at=bundle_dict["issued_at"],
            ttl_s=bundle_dict["ttl_s"],
        )
    except (KeyError, TypeError) as e:
        raise InvalidBundleError(f"Missing or invalid bundle field: {e}") from e

    # Validate bundle (including expiry)
    bundle.validate()

    return bundle
