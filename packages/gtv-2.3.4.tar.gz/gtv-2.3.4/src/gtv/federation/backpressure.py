# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Backpressure signaling for federation peers.

When local processing is saturated (e.g., replicator fanout lagging),
we signal backpressure to peers so they throttle their sends until
the queue drains.

Backpressure signal states:
- ok: queue depth < target (suggest clients continue)
- slow: target <= queue depth < critical (suggest 5s retry)
- overloaded: queue depth >= critical (suggest 30s retry)
"""
from __future__ import annotations

import json
import logging
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Literal

if TYPE_CHECKING:
    from fastapi import FastAPI

logger = logging.getLogger(__name__)


@dataclass
class BackpressureSignal:
    """Backpressure signal sent to federation peers.

    Attributes:
        status: One of 'ok', 'slow', 'overloaded'.
        queue_depth: Current queue depth (items pending processing).
        target_queue_depth: Target depth below which status is 'ok'.
        suggested_retry_after_s: Suggested retry interval in seconds.
    """

    status: Literal["ok", "slow", "overloaded"]
    queue_depth: int
    target_queue_depth: int
    suggested_retry_after_s: int

    def to_json(self) -> str:
        """Serialize to JSON for HTTP header."""
        return json.dumps(
            {
                "status": self.status,
                "queue_depth": self.queue_depth,
                "target_queue_depth": self.target_queue_depth,
                "suggested_retry_after_s": self.suggested_retry_after_s,
                "timestamp": datetime.now(tz=UTC).isoformat(),
            }
        )


class BackpressureMonitor:
    """Tracks queue depth and computes backpressure signals.

    The monitor is updated by the replicator/queue system to track
    how many items are pending processing. Endpoints query the monitor
    before returning to include the signal in response headers.

    Attributes:
        target_queue_depth: Queue depth threshold for 'ok' status.
        critical_queue_depth: Queue depth threshold for 'overloaded' status.
    """

    def __init__(
        self,
        target_queue_depth: int = 100,
        critical_queue_depth: int = 500,
    ):
        """Initialize the backpressure monitor.

        Args:
            target_queue_depth: Queue depth below which status is 'ok'.
                Default 100 items.
            critical_queue_depth: Queue depth at/above which status is
                'overloaded'. Default 500 items. Anything between target
                and critical is 'slow'.
        """
        self.target_queue_depth = target_queue_depth
        self.critical_queue_depth = critical_queue_depth
        self.queue_depth = 0

    def set_queue_depth(self, depth: int) -> None:
        """Update the current queue depth.

        Args:
            depth: Current number of items in the processing queue.
        """
        self.queue_depth = depth

    def compute_signal(
        self,
        target: int | None = None,
        critical: int | None = None,
    ) -> BackpressureSignal:
        """Compute the backpressure signal.

        Determines status based on queue_depth relative to thresholds:
        - ok: depth < target
        - slow: target <= depth < critical (suggest 5s retry)
        - overloaded: depth >= critical (suggest 30s retry)

        Args:
            target: Override target_queue_depth (default uses instance value).
            critical: Override critical_queue_depth (default uses instance value).

        Returns:
            BackpressureSignal with current status and recommended retry interval.
        """
        target = target if target is not None else self.target_queue_depth
        critical = critical if critical is not None else self.critical_queue_depth
        depth = self.queue_depth

        if depth < target:
            status: Literal["ok", "slow", "overloaded"] = "ok"
            retry_after = 0
        elif depth < critical:
            status = "slow"
            retry_after = 5
        else:
            status = "overloaded"
            retry_after = 30

        return BackpressureSignal(
            status=status,
            queue_depth=depth,
            target_queue_depth=target,
            suggested_retry_after_s=retry_after,
        )


def backpressure_header_middleware(
    app: FastAPI, monitor: BackpressureMonitor
) -> None:
    """FastAPI middleware that adds backpressure signal to federation responses.

    Injects X-Federation-Backpressure header on every federation endpoint response.
    The header contains a JSON-serialized BackpressureSignal so peers can see our
    queue depth and decide whether to retry immediately or back off.

    Args:
        app: FastAPI application instance.
        monitor: BackpressureMonitor instance.
    """
    from starlette.middleware.base import BaseHTTPMiddleware
    from starlette.requests import Request
    from starlette.responses import Response

    class BackpressureHeaderMiddleware(BaseHTTPMiddleware):
        async def dispatch(
            self, request: Request, call_next: Callable[[Request], Awaitable[Response]]
        ) -> Response:
            # Execute the endpoint
            response = await call_next(request)

            # Add backpressure header on federation paths
            if request.url.path.startswith("/federation/"):
                signal = monitor.compute_signal()
                response.headers[
                    "X-Federation-Backpressure"
                ] = signal.to_json()

            return response

    app.add_middleware(BackpressureHeaderMiddleware)
