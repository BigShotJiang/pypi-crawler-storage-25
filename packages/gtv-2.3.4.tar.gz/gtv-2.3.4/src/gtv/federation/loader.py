# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Load issuer registries from JSON files or environment variables."""
from __future__ import annotations

import json
import sys
from pathlib import Path

from gtv.federation.registry import IssuerRegistry, TrustedIssuer


def load_registry_from_json(path: str | Path) -> IssuerRegistry:
    """Load a registry from a JSON file.

    The JSON file should contain a list of objects, each with the fields
    required by TrustedIssuer (did, trust_tier, display_name, and optionals).

    Args:
        path: Path to the JSON file.

    Returns:
        A populated IssuerRegistry.

    Raises:
        FileNotFoundError: If the file does not exist.
        ValueError: If the JSON is invalid or contains invalid issuer data.
    """
    path = Path(path)

    if not path.exists():
        raise FileNotFoundError(f"Registry file not found: {path}")

    with open(path) as f:
        data = json.load(f)

    if not isinstance(data, list):
        raise ValueError("Registry JSON must be a list of issuer objects")

    registry = IssuerRegistry()
    for item in data:
        issuer = TrustedIssuer(**item)
        registry.add(issuer)

    return registry


def load_registry_from_env(env_var: str = "GTV_FEDERATION_REGISTRY") -> IssuerRegistry | None:
    """Load a registry from an environment variable.

    The environment variable should contain the path to a JSON file.
    If the variable is not set, returns None.
    If the variable is set but the file does not exist, logs a warning
    and returns None.

    Args:
        env_var: Name of the environment variable (default: "GTV_FEDERATION_REGISTRY").

    Returns:
        A populated IssuerRegistry, or None if the environment variable is unset
        or the file is not found.
    """
    import os

    path_str = os.getenv(env_var)
    if path_str is None:
        return None

    path = Path(path_str)
    if not path.exists():
        sys.stderr.write(f"Warning: {env_var}={path_str} does not exist\n")
        return None

    try:
        return load_registry_from_json(path)
    except Exception as e:
        sys.stderr.write(
            f"Warning: Failed to load registry from {env_var}={path_str}: {e}\n"
        )
        return None
