# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Per-peer rate limiting and circuit breaker for federation endpoints.

Protects federation endpoints (/federation/verdicts, /federation/verdicts_since,
/federation/revocations) from DoS attacks by hostile peers.

Implements:
- Token bucket rate limiter per peer DID
- Circuit breaker that locks out peers with sustained floods
- Thread-safe / async-safe using asyncio.Lock per peer
"""
from __future__ import annotations

import asyncio
import logging
import time
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from fastapi import FastAPI

logger = logging.getLogger(__name__)


class RateLimitExceededError(Exception):
    """Raised when a peer exceeds its rate limit."""

    pass


@dataclass
class _PeerState:
    """Per-peer rate-limit state."""

    tokens: float  # Current tokens in bucket
    last_refill: float  # Monotonic clock timestamp of last refill
    denial_count: int = 0  # Count of denials in the current window
    denial_window_start: float = 0.0  # Start of current 60-second window
    locked_out_until: float = 0.0  # Monotonic time when lockout expires (0 = not locked)
    lock: asyncio.Lock = field(default_factory=asyncio.Lock)


class PeerRateLimiter:
    """Token bucket rate limiter keyed by peer DID.

    Limits incoming requests from federated peers to prevent DoS.
    Uses monotonic (clock-insensitive) time for all internal bookkeeping.

    Attributes:
        tokens_per_sec: Tokens granted per second (float).
        bucket_capacity: Max tokens in bucket (int).
        lockout_threshold: # denials in 60s to trigger circuit breaker (int).
        lockout_duration_s: Duration of circuit breaker lockout (int).
        _clock: Callable that returns current time (for testing).
    """

    def __init__(
        self,
        tokens_per_sec: float = 10.0,
        bucket_capacity: int = 100,
        lockout_threshold: int = 50,
        lockout_duration_s: int = 300,
        clock: Callable[[], float] | None = None,
    ):
        """Initialize the rate limiter.

        Args:
            tokens_per_sec: Tokens added per second. Default 10.0/s = 1 token per 100ms.
            bucket_capacity: Max tokens in bucket. Default 100 (10s worth at max rate).
            lockout_threshold: # of denials in 60s that triggers a 5-min lockout. Default 50.
            lockout_duration_s: Lockout duration in seconds. Default 300 (5 min).
            clock: Optional callable that returns current time (for testing). Defaults to time.monotonic.
        """
        self.tokens_per_sec = tokens_per_sec
        self.bucket_capacity = bucket_capacity
        self.lockout_threshold = lockout_threshold
        self.lockout_duration_s = lockout_duration_s
        self._clock = clock or time.monotonic
        self.peers: dict[str, _PeerState] = {}

    async def try_acquire(
        self, peer_did: str, tokens: int = 1
    ) -> bool:
        """Try to acquire tokens for a peer.

        Uses asyncio.Lock per peer to serialize concurrent acquires on the same peer.
        Returns False without raising if the peer is locked out or insufficient tokens.

        Args:
            peer_did: The peer's DID.
            tokens: Number of tokens to acquire. Default 1.

        Returns:
            True if tokens were granted, False if denied.

        Raises:
            RateLimitExceededError: Only raised if you call with explicit raise_on_exceed=True.
        """
        now = self._clock()

        if peer_did not in self.peers:
            # First request from this peer; initialize state
            self.peers[peer_did] = _PeerState(
                tokens=self.bucket_capacity,
                last_refill=now,
                denial_window_start=now,
            )

        state = self.peers[peer_did]

        # Acquire the per-peer lock to serialize updates
        async with state.lock:
            now = self._clock()

            # Check if peer is locked out
            if state.locked_out_until > now:
                # Still in lockout; deny immediately
                return False

            # Refill bucket based on elapsed time
            elapsed = now - state.last_refill
            refill = elapsed * self.tokens_per_sec
            state.tokens = min(
                self.bucket_capacity, state.tokens + refill
            )
            state.last_refill = now

            # Check if sufficient tokens
            if state.tokens >= tokens:
                # Grant the tokens
                state.tokens -= tokens
                return True

            # Deny: insufficient tokens
            # Increment denial counter
            if now - state.denial_window_start >= 60.0:
                # Window expired; reset
                state.denial_count = 1
                state.denial_window_start = now
            else:
                state.denial_count += 1

            # Check if sustained flood triggers circuit breaker
            if state.denial_count > self.lockout_threshold:
                state.locked_out_until = now + self.lockout_duration_s
                logger.warning(
                    "Peer %s exceeded denial threshold (%d denials in 60s); "
                    "locking out for %d seconds",
                    peer_did,
                    state.denial_count,
                    self.lockout_duration_s,
                )

            return False

    def is_locked_out(self, peer_did: str) -> bool:
        """Check if a peer is currently locked out.

        Args:
            peer_did: The peer's DID.

        Returns:
            True if the peer is in a lockout window, False otherwise.
        """
        if peer_did not in self.peers:
            return False

        state = self.peers[peer_did]
        now = self._clock()
        return state.locked_out_until > now


def federation_rate_limit_middleware(
    app: FastAPI, limiter: PeerRateLimiter
) -> None:
    """FastAPI middleware for federation rate limiting.

    Extracts peer DID from the X-Peer-Did header and applies per-peer
    rate limiting. Returns 429 with Retry-After header if the peer exceeds
    its limit.

    Args:
        app: FastAPI application instance.
        limiter: PeerRateLimiter instance.
    """
    from fastapi import Request, status
    from fastapi.responses import JSONResponse
    from starlette.middleware.base import BaseHTTPMiddleware
    from starlette.responses import Response

    class FederationRateLimitMiddleware(BaseHTTPMiddleware):
        async def dispatch(
            self, request: Request, call_next: Callable[[Request], Awaitable[Response]]
        ) -> Response:
            # Skip rate limiting for non-federation paths
            path = request.url.path
            if not path.startswith("/federation/"):
                return await call_next(request)

            # Extract peer DID from X-Peer-Did header
            peer_did = request.headers.get("X-Peer-Did", "").strip()
            if not peer_did:
                # Try fallback: Bearer token from Authorization header
                auth_header = request.headers.get("Authorization", "").strip()
                if auth_header.startswith("Bearer "):
                    # Use the token as a pseudo-peer identifier
                    peer_did = auth_header[7:]  # Strip "Bearer "

            if not peer_did:
                # No peer identifier; allow but log
                logger.debug(
                    "Federation request without peer DID header or Authorization; "
                    "skipping rate limit check"
                )
                return await call_next(request)

            # Try to acquire a token
            allowed = await limiter.try_acquire(peer_did, tokens=1)
            if not allowed:
                return JSONResponse(
                    status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                    content={"detail": "Rate limit exceeded for this peer"},
                    headers={
                        "Retry-After": "60",
                        "X-Peer-Did": peer_did,
                    },
                )

            # Request is allowed; proceed
            response = await call_next(request)

            # Add informational headers to response
            response.headers["X-Peer-Did"] = peer_did

            return response

    app.add_middleware(FederationRateLimitMiddleware)
