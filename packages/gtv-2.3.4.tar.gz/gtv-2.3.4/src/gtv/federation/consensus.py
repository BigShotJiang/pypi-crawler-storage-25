# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Multi-verifier consensus via tier-weighted majority voting.

Implements the federated-verifier quorum mechanism: given multiple envelopes
(each signed by a different verifier DID for the same claim), compute a
single consensus verdict using tier-weighted majority.

Algorithm (from first principles, no overbuilding):
1. Input: list[Envelope], all for the same claim (caller's responsibility).
2. Look up each issuer_did in the federation registry to get trust tier.
3. Weight per tier: tier-1 = 3.0, tier-2 = 2.0, tier-3 = 1.0, unknown = 0.1.
4. Sum weighted votes per verdict; majority-weighted verdict wins.
5. Ties → CONTESTED.
6. Confidence = (winning_weight / total_weight), clamped to [0.0, 1.0].
7. Return ConsensusResult with verdict, confidence, tally, unknown_dids.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import NamedTuple

from gtv.federation.registry import IssuerRegistry
from gtv.models import Envelope, Verdict

logger = logging.getLogger(__name__)


class Tally(NamedTuple):
    """Vote tally by verdict."""
    verdict: Verdict
    weighted_votes: float
    envelope_count: int


@dataclass(frozen=True)
class ConsensusResult:
    """Result of multi-verifier consensus voting.

    Attributes:
        verdict: The consensus verdict (VERIFIED, UNVERIFIED, CONTESTED, etc.).
        confidence: Confidence of the verdict in [0.0, 1.0].
        tally: List of Tally objects showing votes per verdict.
        unknown_dids: List of issuer DIDs not found in the registry.
    """
    verdict: Verdict
    confidence: float
    tally: list[Tally]
    unknown_dids: list[str]


def compute_consensus(
    envelopes: list[Envelope],
    registry: IssuerRegistry | None = None,
    *,
    enforce_same_claim_id: bool = True,
) -> ConsensusResult:
    """Compute consensus verdict from multiple signed envelopes.

    Args:
        envelopes: List of Envelope objects, all for the same claim.
                   Caller is responsible for ensuring all envelopes describe
                   the same claim (same claim_id in Evidence).
        registry: The IssuerRegistry to look up trust tiers. If None, uses
                  the DEFAULT_REGISTRY.
        enforce_same_claim_id: If True (default), raise when envelopes
            disagree on ``evidence.claim_id``. This is the correct
            invariant when the caller hand-assembles envelopes for the
            same claim_id (e.g., the CLI consensus tool). It is **wrong**
            for federation: two peers independently verifying the same
            claim text will each construct a fresh ``Claim`` with a new
            claim_id. The federation endpoint sets this False because it
            guarantees same-claim-text via fan-out.

    Returns:
        ConsensusResult with consensus verdict, confidence, and tally.

    Raises:
        ValueError: If envelopes list is empty, or if
            ``enforce_same_claim_id`` is True and evidence claim_ids
            disagree.
    """
    if not envelopes:
        raise ValueError("Cannot compute consensus on empty envelope list")

    # Use default registry if none provided.
    if registry is None:
        from gtv.federation.registry import DEFAULT_REGISTRY
        registry = DEFAULT_REGISTRY

    # Optional same-claim-id sanity check. Federation callers guarantee
    # same claim text via fan-out and skip this.
    if enforce_same_claim_id:
        all_claim_ids: set[str] = set()
        for env in envelopes:
            for evidence in env.evidence:
                all_claim_ids.add(evidence.claim_id)

        if len(all_claim_ids) > 1:
            raise ValueError(
                f"Not all envelopes have the same claim: found claim_ids {all_claim_ids}"
            )

    # Weight tiers (first-principles defaults).
    tier_weights = {
        "TIER_1": 3.0,
        "TIER_2": 2.0,
        "TIER_3": 1.0,
    }
    unknown_weight = 0.1

    # Accumulate votes by verdict.
    votes: dict[Verdict, float] = {}
    envelope_counts: dict[Verdict, int] = {}
    unknown_dids: list[str] = []

    for env in envelopes:
        issuer = registry.get(env.issuer_did)
        if issuer is None:
            weight = unknown_weight
            unknown_dids.append(env.issuer_did)
            logger.warning(
                f"Issuer DID not in registry: {env.issuer_did} (weight={unknown_weight})"
            )
        else:
            # Trust tier is an enum (TrustTier.TIER_1, etc.); extract the name.
            tier_name = issuer.trust_tier.value  # e.g., "TIER_1"
            weight = tier_weights.get(tier_name, unknown_weight)

        votes[env.verdict] = votes.get(env.verdict, 0.0) + weight
        envelope_counts[env.verdict] = envelope_counts.get(env.verdict, 0) + 1

    # Find the verdict(s) with the highest weight.
    max_weight = max(votes.values())
    winning_verdicts = [v for v, w in votes.items() if w == max_weight]

    # If there's a tie, verdict is CONTESTED.
    if len(winning_verdicts) > 1:
        consensus_verdict = Verdict.CONTESTED
        # For a tie, use the weight of the CONTESTED result if it exists,
        # otherwise split the difference or use the max as base.
        winning_weight = max_weight
    else:
        consensus_verdict = winning_verdicts[0]
        winning_weight = max_weight

    # Confidence = winning_weight / total_weight, clamped.
    total_weight = sum(votes.values())
    confidence = min(1.0, max(0.0, winning_weight / total_weight if total_weight > 0 else 0.0))

    # Build tally (sorted by weight descending, then alphabetically).
    tally = [
        Tally(verdict=v, weighted_votes=votes[v], envelope_count=envelope_counts[v])
        for v in sorted(votes.keys(), key=lambda v: (-votes[v], v.value))
    ]

    return ConsensusResult(
        verdict=consensus_verdict,
        confidence=confidence,
        tally=tally,
        unknown_dids=unknown_dids,
    )
