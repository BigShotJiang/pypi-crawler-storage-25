# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Split-brain detection and recovery for federated verdict consensus.

After a network partition heals, two previously-disconnected federation quorums
may each have issued verdicts (or revocations) for the same claim_id. This
module detects divergence and proposes a merge strategy.

Algorithm:
1. detect_divergence: Find the longest common prefix of peers' chain_hashes
   (the common ancestor), and identify per-peer branches after it.
2. propose_merge: Apply strategy selection:
   - If >= supermajority threshold peers agree on a head_hash,
     strategy = "prefer_supermajority" and winner = that hash.
   - Else if timestamps exist and not all tied, strategy = "prefer_latest"
     and winner = hash with highest timestamp.
   - Else strategy = "manual_review" (no winner).
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ClaimLineage:
    """Lineage (history) of a claim known to a single federation peer.

    Attributes:
        claim_id: Unique claim identifier.
        peer_did: DID of the peer reporting this lineage.
        head_hash: SHA256 of the latest state (verdict or revocation).
        head_timestamp: ISO 8601 UTC timestamp of head_hash.
        chain_hashes: Ordered list of historical head hashes, from earliest
                      to latest. Should include head_hash as the final entry.
    """

    claim_id: str
    peer_did: str
    head_hash: str
    head_timestamp: str
    chain_hashes: list[str]


@dataclass(frozen=True)
class DivergenceReport:
    """Result of analyzing divergence across multiple peers' lineages.

    Attributes:
        claim_id: The claim being analyzed.
        divergent: True iff > 1 distinct head_hash exists across peers.
        common_ancestor_hash: SHA256 of the longest shared prefix, or None
                              if no common prefix exists (disjoint histories).
        branches: Dict mapping peer_did to list of hashes AFTER the common
                  ancestor (empty list if peer is at the common ancestor).
        branch_leaders: Dict mapping peer_did to its head_hash.
    """

    claim_id: str
    divergent: bool
    common_ancestor_hash: str | None
    branches: dict[str, list[str]]
    branch_leaders: dict[str, str]


@dataclass(frozen=True)
class MergeProposal:
    """Proposal for resolving a divergence via merge strategy.

    Attributes:
        claim_id: The claim being merged.
        strategy: Merge strategy used:
                  - "prefer_supermajority": >= supermajority peers agree.
                  - "prefer_latest": Highest head_timestamp wins.
                  - "manual_review": No clear winner (tie or insufficient data).
        winner_peer_did: DID of the winning peer, or None if manual_review.
        winner_head_hash: Head hash of the winner, or None if manual_review.
        losers: List of peer DIDs whose head_hash was not selected.
    """

    claim_id: str
    strategy: str
    winner_peer_did: str | None
    winner_head_hash: str | None
    losers: list[str]


def detect_divergence(lineages: list[ClaimLineage]) -> DivergenceReport:
    """Detect divergence in claim lineages across federation peers.

    Given N peers' lineages for the same claim, find the deepest common
    ancestor (longest shared prefix of chain_hashes) and identify per-peer
    branches after it.

    Args:
        lineages: List of ClaimLineage objects from multiple peers.

    Returns:
        DivergenceReport with divergent flag, common ancestor, and branches.

    Raises:
        ValueError: If claim_ids don't all match.
    """
    if not lineages:
        return DivergenceReport(
            claim_id="",
            divergent=False,
            common_ancestor_hash=None,
            branches={},
            branch_leaders={},
        )

    # Verify all claim_ids match
    claim_ids = {lin.claim_id for lin in lineages}
    if len(claim_ids) > 1:
        raise ValueError(
            f"Mismatched claim_ids: {claim_ids}. "
            "All lineages must be for the same claim."
        )

    claim_id = lineages[0].claim_id

    # Special case: single peer -> trivially not divergent
    if len(lineages) == 1:
        lin = lineages[0]
        return DivergenceReport(
            claim_id=claim_id,
            divergent=False,
            common_ancestor_hash=(
                lin.chain_hashes[-1] if lin.chain_hashes else None
            ),
            branches={lin.peer_did: []},
            branch_leaders={lin.peer_did: lin.head_hash},
        )

    # Find longest common prefix of all chain_hashes lists
    common_prefix_len = 0
    if lineages[0].chain_hashes:
        for idx in range(len(lineages[0].chain_hashes)):
            # Check if all peers have this index and same hash
            if all(
                len(lin.chain_hashes) > idx
                and lin.chain_hashes[idx] == lineages[0].chain_hashes[idx]
                for lin in lineages
            ):
                common_prefix_len = idx + 1
            else:
                break

    common_ancestor_hash = (
        lineages[0].chain_hashes[common_prefix_len - 1]
        if common_prefix_len > 0
        else None
    )

    # Extract branches and branch leaders
    branches: dict[str, list[str]] = {}
    branch_leaders: dict[str, str] = {}

    for lin in lineages:
        branch = lin.chain_hashes[common_prefix_len:]
        branches[lin.peer_did] = branch
        branch_leaders[lin.peer_did] = lin.head_hash

    # Check if divergent: > 1 distinct head_hash
    distinct_heads = {lin.head_hash for lin in lineages}
    divergent = len(distinct_heads) > 1

    return DivergenceReport(
        claim_id=claim_id,
        divergent=divergent,
        common_ancestor_hash=common_ancestor_hash,
        branches=branches,
        branch_leaders=branch_leaders,
    )


def propose_merge(
    report: DivergenceReport,
    lineages: list[ClaimLineage],
    supermajority: float = 0.66,
) -> MergeProposal:
    """Propose a merge strategy to resolve divergence.

    Applies the following strategy selection in order:
    1. If >= supermajority of peers agree on a head_hash, use that hash
       and strategy = "prefer_supermajority".
    2. Else if timestamps exist and not all tied, pick the hash with the
       highest timestamp and strategy = "prefer_latest".
    3. Else strategy = "manual_review" with no winner.

    Args:
        report: DivergenceReport from detect_divergence.
        lineages: Original ClaimLineage list (for timestamps and peer lookup).
        supermajority: Threshold for supermajority agreement (default 0.66).

    Returns:
        MergeProposal with selected strategy and winner (if any).
    """
    if not lineages:
        return MergeProposal(
            claim_id=report.claim_id,
            strategy="manual_review",
            winner_peer_did=None,
            winner_head_hash=None,
            losers=[],
        )

    # Count peers per head_hash
    hash_to_peers: dict[str, list[str]] = {}
    hash_to_timestamp: dict[str, str] = {}

    for lin in lineages:
        if lin.head_hash not in hash_to_peers:
            hash_to_peers[lin.head_hash] = []
        hash_to_peers[lin.head_hash].append(lin.peer_did)
        hash_to_timestamp[lin.head_hash] = lin.head_timestamp

    # Strategy 1: Check for supermajority agreement
    supermajority_count = len(lineages) * supermajority
    for head_hash, peers in hash_to_peers.items():
        if len(peers) >= supermajority_count:
            # Winner by supermajority
            winner_peer_did = peers[0]
            losers = [p for lin in lineages for p in [lin.peer_did]
                      if lin.head_hash != head_hash]
            return MergeProposal(
                claim_id=report.claim_id,
                strategy="prefer_supermajority",
                winner_peer_did=winner_peer_did,
                winner_head_hash=head_hash,
                losers=losers,
            )

    # Strategy 2: Pick highest timestamp (if not all tied)
    timestamps = set(hash_to_timestamp.values())
    if len(timestamps) > 1:
        # Not all timestamps tied; find the max
        max_timestamp = max(hash_to_timestamp.items(), key=lambda x: x[1])
        winner_head_hash = max_timestamp[0]
        winner_peer_did = hash_to_peers[winner_head_hash][0]
        losers = [p for lin in lineages for p in [lin.peer_did]
                  if lin.head_hash != winner_head_hash]
        return MergeProposal(
            claim_id=report.claim_id,
            strategy="prefer_latest",
            winner_peer_did=winner_peer_did,
            winner_head_hash=winner_head_hash,
            losers=losers,
        )

    # Strategy 3: Manual review (all timestamps tied or no clear winner)
    return MergeProposal(
        claim_id=report.claim_id,
        strategy="manual_review",
        winner_peer_did=None,
        winner_head_hash=None,
        losers=[],
    )
