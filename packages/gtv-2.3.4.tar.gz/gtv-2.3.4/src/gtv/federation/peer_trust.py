# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""EigenTrust-style peer reputation scoring over local trust matrices.

Implements global trust score computation from a local-trust matrix by
power iteration with teleportation. Each peer publishes local trust ratings
of its direct peers; this module computes the global (eigenvector-like)
reputation vector.

Algorithm (EigenTrust):
1. Normalize rows of local_trust so each row sums to 1.
   - If a row sums to 0 (peer trusts nobody), distribute uniformly over
     pre-trusted peers, or uniformly over all peers if no pre-trusted list.
2. Initialize reputation vector t as uniform over pre-trusted peers
   (or uniform over all peers if none).
3. Iterate: t_new = (1 - alpha) * M^T @ t + alpha * p
   where M is the normalized trust matrix, p is the teleport vector,
   alpha is the teleport probability.
4. Stop when ||t_new - t|| < tol or max_iters reached.
5. Return normalized dict {peer_did: score}, summing to 1.0.
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class TrustMatrix:
    """Local trust matrix from peers.

    Attributes:
        peers: Ordered list of peer DIDs (indices 0..n-1).
        local_trust: n x n matrix where local_trust[i][j] is the trust
                     score (0..1) that peer i assigns to peer j.
    """

    peers: list[str]
    local_trust: list[list[float]]

    def __post_init__(self) -> None:
        """Validate matrix dimensions."""
        n = len(self.peers)
        if len(self.local_trust) != n:
            raise ValueError(
                f"local_trust row count {len(self.local_trust)} != peer count {n}"
            )
        for i, row in enumerate(self.local_trust):
            if len(row) != n:
                raise ValueError(
                    f"local_trust row {i} has {len(row)} cols, expected {n}"
                )


def compute_global_trust(
    matrix: TrustMatrix,
    pre_trusted: list[str] | None = None,
    alpha: float = 0.15,
    max_iters: int = 100,
    tol: float = 1e-6,
) -> dict[str, float]:
    """Compute global trust scores via EigenTrust power iteration.

    Args:
        matrix: TrustMatrix with peers and local_trust values.
        pre_trusted: List of peer DIDs to prefer in teleportation.
                     If None, uniform teleportation over all peers.
        alpha: Probability of teleportation (default 0.15).
        max_iters: Maximum iterations (default 100).
        tol: Convergence tolerance for L2 norm (default 1e-6).

    Returns:
        Dict mapping peer_did to trust score (0..1), normalized to sum ~1.0.
    """
    n = len(matrix.peers)
    peer_to_idx = {did: i for i, did in enumerate(matrix.peers)}

    # Validate pre_trusted if provided
    if pre_trusted is not None:
        for did in pre_trusted:
            if did not in peer_to_idx:
                raise ValueError(f"pre_trusted peer {did} not in matrix")

    # Step 1: Normalize rows of local_trust.
    # If a row sums to 0, distribute uniformly over pre_trusted or all peers.
    m = []
    for _i, row in enumerate(matrix.local_trust):
        row_sum = sum(row)
        if row_sum == 0:
            # Peer trusts nobody; use uniform fallback
            if pre_trusted:
                # Uniform over pre_trusted
                fallback_indices = [peer_to_idx[did] for did in pre_trusted]
                normalized_row = [0.0] * n
                for j in fallback_indices:
                    normalized_row[j] = 1.0 / len(fallback_indices)
            else:
                # Uniform over all peers
                normalized_row = [1.0 / n] * n
        else:
            # Normalize by row sum
            normalized_row = [v / row_sum for v in row]
        m.append(normalized_row)

    # Step 2: Initialize teleport vector and reputation vector.
    if pre_trusted:
        pre_trusted_indices = [peer_to_idx[did] for did in pre_trusted]
        p = [0.0] * n
        for j in pre_trusted_indices:
            p[j] = 1.0 / len(pre_trusted_indices)
    else:
        # Uniform over all peers
        p = [1.0 / n] * n

    # Initialize reputation uniform
    t = [1.0 / n] * n

    # Step 3: Power iteration.
    for _iteration in range(max_iters):
        # t_new = (1 - alpha) * M^T @ t + alpha * p
        t_new = [0.0] * n

        # Compute M^T @ t (transpose multiply)
        for j in range(n):
            for i in range(n):
                t_new[j] += m[i][j] * t[i]

        # Add teleport term
        for j in range(n):
            t_new[j] = (1.0 - alpha) * t_new[j] + alpha * p[j]

        # Check convergence: ||t_new - t||
        diff_sq = sum((t_new[i] - t[i]) ** 2 for i in range(n))
        norm = diff_sq ** 0.5

        t = t_new

        if norm < tol:
            break

    # Step 4: Normalize to sum to 1.0 and return as dict.
    total = sum(t)
    result = {}
    for i, did in enumerate(matrix.peers):
        result[did] = t[i] / total if total > 0 else 1.0 / n

    return result
