# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Build and verify registry updates with cryptographic signatures.

Shipping signed registry update records — a cryptographically signed append-only
log of federation registry changes so pilots can prove they didn't silently change
trust tiers.

Signing follows the BYOK pattern: canonicalize unsigned fields (RFC 8785),
sign with Ed25519, verify public key from issuer_did.
"""
from __future__ import annotations

import base64
import hashlib
from datetime import UTC, datetime
from pathlib import Path
from typing import Literal
from uuid import uuid4

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ed25519
from pydantic import BaseModel, ConfigDict, Field

from gtv.anchor.canonicalize import canonicalize
from gtv.did.resolve_key import parse_did_key
from gtv.sign.byok import _derive_did_key_from_public_key


class RegistryUpdate(BaseModel):
    """A cryptographically signed federation registry update.

    Frozen (immutable) to ensure signature consistency. Signature is computed
    over the canonical form of the unsigned fields (update_id, operation,
    issuer_did, old_tier, new_tier, actor_did, issued_at).
    """

    model_config = ConfigDict(frozen=True)

    update_id: str = Field(default_factory=lambda: str(uuid4()))
    operation: Literal["add", "update_tier", "revoke"]
    issuer_did: str  # did:key:z..., the pilot being registered/updated
    old_tier: str | None = None  # Previous tier (None for 'add')
    new_tier: str | None = None  # New tier (None for 'revoke')
    actor_did: str  # did:key:z..., the signer (who authorized this)
    issued_at: datetime = Field(default_factory=lambda: datetime.now(tz=UTC))
    signature: str  # "byok-ed25519:<base64>"
    canonical_hash: str  # SHA256 hex of canonical unsigned form


def build_registry_update(
    operation: Literal["add", "update_tier", "revoke"],
    issuer_did: str,
    old_tier: str | None,
    new_tier: str | None,
    actor_private_key_pem_path: str | Path,
) -> RegistryUpdate:
    """Build and sign a RegistryUpdate.

    Canonicalizes the unsigned portion (update_id, operation, issuer_did,
    old_tier, new_tier, actor_did, issued_at), signs with Ed25519, and
    returns a signed RegistryUpdate.

    Args:
        operation: One of "add", "update_tier", "revoke"
        issuer_did: The did:key:z... of the pilot being registered/updated
        old_tier: Previous tier (None for 'add')
        new_tier: New tier (None for 'revoke')
        actor_private_key_pem_path: Path to Ed25519 private key in PEM format

    Returns:
        Signed RegistryUpdate with signature and canonical_hash populated

    Raises:
        ValueError: If private_key_pem_path is None, invalid, or not Ed25519
        FileNotFoundError: If private_key_pem_path does not exist
    """
    # Load and validate private key
    pem_path = Path(actor_private_key_pem_path)
    if not pem_path.exists():
        raise FileNotFoundError(f"Private key file not found: {pem_path}")

    try:
        pem_bytes = pem_path.read_bytes()
        private_key_obj = serialization.load_pem_private_key(pem_bytes, password=None)
    except Exception as e:
        raise ValueError(f"Failed to load PEM private key: {e}") from e

    if not isinstance(private_key_obj, ed25519.Ed25519PrivateKey):
        raise ValueError(
            f"Private key must be Ed25519, got {type(private_key_obj).__name__}"
        )

    # Derive actor_did from public key
    public_key_obj = private_key_obj.public_key()
    raw_public_key_bytes = public_key_obj.public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    actor_did = _derive_did_key_from_public_key("Ed25519", raw_public_key_bytes)

    # Create unsigned dict with update_id and issued_at
    now = datetime.now(tz=UTC)
    update_id = str(uuid4())

    # Build unsigned dict (fields that go into canonical form)
    unsigned_dict = {
        "update_id": update_id,
        "operation": operation,
        "issuer_did": issuer_did,
        "old_tier": old_tier,
        "new_tier": new_tier,
        "actor_did": actor_did,
        "issued_at": now.isoformat(),
    }

    # Canonicalize and hash
    canonical_bytes = canonicalize(unsigned_dict)
    canonical_hash = hashlib.sha256(canonical_bytes).hexdigest()

    # Sign
    sig_bytes = private_key_obj.sign(canonical_bytes)
    sig_b64 = base64.b64encode(sig_bytes).decode("ascii")
    signature_str = f"byok-ed25519:{sig_b64}"

    # Create and return signed RegistryUpdate
    return RegistryUpdate(
        update_id=update_id,
        operation=operation,
        issuer_did=issuer_did,
        old_tier=old_tier,
        new_tier=new_tier,
        actor_did=actor_did,
        issued_at=now,
        signature=signature_str,
        canonical_hash=canonical_hash,
    )


def verify_registry_update(update: RegistryUpdate) -> bool:
    """Verify a RegistryUpdate signature.

    Recomputes the canonical hash of the unsigned portion, extracts the public
    key from actor_did, and verifies the Ed25519 signature.

    Args:
        update: RegistryUpdate to verify

    Returns:
        True if signature is valid, False otherwise
    """
    try:
        # Validate actor_did format
        if not update.actor_did.startswith("did:key:z"):
            return False

        # Parse actor DID
        try:
            parsed = parse_did_key(update.actor_did)
        except ValueError:
            return False

        if parsed.key_type != "Ed25519":
            return False

        public_key_bytes = parsed.public_key_bytes

        # Extract signature
        if not update.signature.startswith("byok-ed25519:"):
            return False

        try:
            sig_b64 = update.signature[13:]  # Strip "byok-ed25519:"
            sig_bytes = base64.b64decode(sig_b64)
        except (ValueError, IndexError):
            return False

        # Recompute canonical hash
        unsigned_dict = {
            "update_id": update.update_id,
            "operation": update.operation,
            "issuer_did": update.issuer_did,
            "old_tier": update.old_tier,
            "new_tier": update.new_tier,
            "actor_did": update.actor_did,
            "issued_at": update.issued_at.isoformat(),
        }
        canonical_bytes = canonicalize(unsigned_dict)
        recomputed_hash = hashlib.sha256(canonical_bytes).hexdigest()

        # Verify hash matches
        if recomputed_hash != update.canonical_hash:
            return False

        # Verify signature
        public_key = ed25519.Ed25519PublicKey.from_public_bytes(public_key_bytes)
        public_key.verify(sig_bytes, canonical_bytes)

        return True
    except Exception:
        return False


class UpdateLog:
    """Append-only JSON lines log of RegistryUpdates.

    Stores updates as one JSON line per update. Supports verify_all()
    to validate all entries in the log.
    """

    def __init__(self, path: str | Path | None = None) -> None:
        """Initialize the log with an optional path.

        Args:
            path: Path to the JSON lines log file. Defaults to ~/.gtv/federation_updates.jsonl
        """
        if path is None:
            home = Path.home()
            path = home / ".gtv" / "federation_updates.jsonl"
        self.path = Path(path)

    def append(self, update: RegistryUpdate) -> None:
        """Append a RegistryUpdate to the log.

        Args:
            update: RegistryUpdate to append
        """
        # Ensure parent directory exists
        self.path.parent.mkdir(parents=True, exist_ok=True)

        # Write as a single JSON line
        line = update.model_dump_json() + "\n"
        existing = self.path.read_text(errors="ignore") if self.path.exists() else ""
        self.path.write_text(existing + line)

    def verify_all(self) -> tuple[int, int]:
        """Verify all updates in the log.

        Returns:
            Tuple of (valid_count, invalid_count)
        """
        valid_count = 0
        invalid_count = 0

        if not self.path.exists():
            return valid_count, invalid_count

        try:
            content = self.path.read_text()
        except Exception:
            return valid_count, invalid_count

        for line in content.strip().split("\n"):
            if not line.strip():
                continue

            try:
                update = RegistryUpdate.model_validate_json(line)
                if verify_registry_update(update):
                    valid_count += 1
                else:
                    invalid_count += 1
            except Exception:
                invalid_count += 1

        return valid_count, invalid_count


__all__ = [
    "RegistryUpdate",
    "UpdateLog",
    "build_registry_update",
    "verify_registry_update",
]
