# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Federation peer client.

A gtv instance federates by forwarding a claim to peer verifiers and
folding their sealed envelopes into a tier-weighted consensus. The
peer client is deliberately thin: it POSTs to ``/tools/verify_claim``
on a peer and returns the parsed :class:`gtv.models.Envelope`.

Nothing in this module validates signatures or trust tiers — that's
the caller's responsibility (``federation.consensus.compute_consensus``
drives the weighting, ``verify.signature`` checks the crypto).

Peer configuration is a single env var to keep the operator surface
minimal:

    GTV_FEDERATION_PEERS=<did>|<url>|<api_key>,<did>|<url>|<api_key>...

* ``did``      — the peer's issuer DID (also its key in the registry).
* ``url``      — base URL of the peer (no trailing slash).
* ``api_key``  — Bearer token the peer accepts. May be empty for peers
  running with auth disabled.

Entries are ``|``-separated so DIDs (which contain colons) parse cleanly.
"""
from __future__ import annotations

import logging
import os
from dataclasses import dataclass

import httpx

from gtv.models import Domain, Envelope

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class FederationPeer:
    """One configured peer verifier."""

    did: str
    url: str
    api_key: str = ""

    def auth_header(self) -> dict[str, str]:
        """Return the Authorization header, or an empty dict if no key."""
        if not self.api_key:
            return {}
        return {"Authorization": f"Bearer {self.api_key}"}


def load_peers_from_env(
    env_var: str = "GTV_FEDERATION_PEERS",
) -> list[FederationPeer]:
    """Parse ``GTV_FEDERATION_PEERS`` into a list of FederationPeer.

    Empty / unset env var returns ``[]`` (federation disabled).
    Malformed entries are skipped with a warning; one bad peer should
    not take the whole federation offline.
    """
    raw = os.environ.get(env_var, "").strip()
    if not raw:
        return []

    peers: list[FederationPeer] = []
    for idx, chunk in enumerate(raw.split(",")):
        chunk = chunk.strip()
        if not chunk:
            continue
        parts = chunk.split("|")
        if len(parts) < 2 or not parts[0] or not parts[1]:
            logger.warning(
                "Skipping malformed %s entry #%d: %r (expected did|url[|api_key])",
                env_var,
                idx,
                chunk,
            )
            continue
        did, url = parts[0].strip(), parts[1].strip().rstrip("/")
        api_key = parts[2].strip() if len(parts) >= 3 else ""
        peers.append(FederationPeer(did=did, url=url, api_key=api_key))
    return peers


async def fetch_peer_envelope(
    peer: FederationPeer,
    claim: str,
    *,
    domain: Domain = Domain.GENERAL,
    max_sources: int = 5,
    timeout_s: float = 10.0,
    client: httpx.AsyncClient | None = None,
) -> Envelope:
    """Call ``POST /tools/verify_claim`` on a peer and return its envelope.

    Args:
        peer: The peer to query.
        claim: Claim text to verify.
        domain: Claim domain.
        max_sources: Forwarded to the peer's verifier.
        timeout_s: Per-request timeout in seconds.
        client: Optional caller-owned httpx client (for connection reuse
            in fanned-out calls). A new client is created if None.

    Returns:
        Parsed :class:`Envelope` signed by the peer.

    Raises:
        httpx.HTTPError: On transport or non-2xx responses.
        pydantic.ValidationError: If the peer returned a malformed envelope.
    """
    payload = {
        "claim": claim,
        "domain": domain.value if isinstance(domain, Domain) else str(domain),
        "max_sources": max_sources,
    }
    url = f"{peer.url}/tools/verify_claim"
    headers = peer.auth_header()

    if client is None:
        async with httpx.AsyncClient(timeout=timeout_s) as c:
            resp = await c.post(url, json=payload, headers=headers)
    else:
        resp = await client.post(url, json=payload, headers=headers, timeout=timeout_s)

    resp.raise_for_status()
    return Envelope.model_validate(resp.json())
