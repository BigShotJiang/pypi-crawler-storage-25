# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Cross-federation verdict replication.

When a verdict is produced locally, optionally replicate it to peers
so they can cache/serve it.
"""
from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass

import httpx

from gtv.federation.discovery import DiscoveredPeer

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class ReplicationResult:
    """Result of replicating a verdict to a peer."""

    peer_did: str
    endpoint_url: str
    status_code: int | None
    error: str | None


class VerdictReplicator:
    """Replicate verdicts to peer nodes."""

    def __init__(
        self, client: httpx.AsyncClient | None = None, timeout: float = 5.0
    ) -> None:
        """Initialize the verdict replicator.

        Args:
            client: Optional httpx.AsyncClient for reuse.
            timeout: Per-request timeout in seconds (default 5.0).
        """
        self.client = client
        self.timeout = timeout

    async def replicate(
        self, verdict_payload: dict, peers: list[DiscoveredPeer]
    ) -> list[ReplicationResult]:
        """Replicate a verdict to multiple peers concurrently.

        POSTs the verdict to {peer.endpoint_url}/federation/verdicts on each peer.
        Fan-out via asyncio.gather. Network errors and timeouts are captured
        in the error field without raising.

        Args:
            verdict_payload: The verdict dict to replicate.
            peers: List of DiscoveredPeer targets.

        Returns:
            List of ReplicationResult objects (one per peer).
        """
        if not peers:
            return []

        tasks = [
            self._replicate_to_peer(verdict_payload, peer) for peer in peers
        ]
        results = await asyncio.gather(*tasks, return_exceptions=False)
        return results

    async def _replicate_to_peer(
        self, verdict_payload: dict, peer: DiscoveredPeer
    ) -> ReplicationResult:
        """Replicate a verdict to a single peer.

        Args:
            verdict_payload: The verdict dict.
            peer: The target peer.

        Returns:
            ReplicationResult with status or error.
        """
        url = f"{peer.endpoint_url}/federation/verdicts"

        try:
            if self.client is not None:
                resp = await self.client.post(
                    url,
                    json=verdict_payload,
                    headers={"Content-Type": "application/json"},
                    timeout=self.timeout,
                )
            else:
                async with httpx.AsyncClient(timeout=self.timeout) as client:
                    resp = await client.post(
                        url,
                        json=verdict_payload,
                        headers={"Content-Type": "application/json"},
                    )

            return ReplicationResult(
                peer_did=peer.did,
                endpoint_url=peer.endpoint_url,
                status_code=resp.status_code,
                error=None,
            )
        except TimeoutError:
            return ReplicationResult(
                peer_did=peer.did,
                endpoint_url=peer.endpoint_url,
                status_code=None,
                error="Timeout",
            )
        except httpx.HTTPError as e:
            return ReplicationResult(
                peer_did=peer.did,
                endpoint_url=peer.endpoint_url,
                status_code=None,
                error=str(e),
            )
        except Exception as e:
            return ReplicationResult(
                peer_did=peer.did,
                endpoint_url=peer.endpoint_url,
                status_code=None,
                error=str(e),
            )

    async def close(self) -> None:
        """Close the client if it was passed in (for symmetry)."""
        # Note: We don't own the client, so we don't close it here.
        # The caller is responsible for managing its lifecycle.
        pass
