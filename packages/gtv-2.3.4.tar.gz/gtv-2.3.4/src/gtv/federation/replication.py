# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Cross-federation claim replication publisher.

Peers optionally replicate newly-verified claims to each other for caching.
This is pub/sub, not consensus. Each target receives HMAC-signed payloads
via POST /federation/replicate.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import logging
import os
import time
from dataclasses import dataclass
from typing import Any

import httpx

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class ReplicationTarget:
    """One configured replication target peer."""

    did: str
    url: str  # base URL of peer (no trailing slash)
    api_key: str | None  # Bearer token; None if no auth
    hmac_secret: bytes  # signing key for replication envelope


@dataclass(frozen=True)
class ReplicationResult:
    """Result of attempting replication to a target."""

    target_did: str
    accepted: bool
    status_code: int | None
    error: str | None


class ReplicationPublisher:
    """Fan-out publisher for verified claims to federation peers."""

    def __init__(
        self,
        targets: list[ReplicationTarget],
        client: httpx.AsyncClient | None = None,
        timeout: float = 5.0,
    ) -> None:
        """Initialize the replication publisher.

        Args:
            targets: List of ReplicationTarget peers to replicate to.
            client: Optional httpx.AsyncClient to reuse; if None, one will be created per publish.
            timeout: HTTP request timeout in seconds (default 5.0).
        """
        self._targets = targets
        self._client = client
        self._timeout = timeout

    async def publish(self, verdict_payload: dict[str, Any]) -> list[ReplicationResult]:
        """Fan out verdict_payload to each target's /federation/replicate endpoint.

        Each request is HMAC-SHA256 signed. No retries at this layer
        (upstream webhook dispatcher handles that).

        Args:
            verdict_payload: Dictionary with the verified claim verdict to replicate.

        Returns:
            List of ReplicationResult, one per target (whether success or failure).
        """
        import asyncio

        tasks = [self._replicate_to_target(target, verdict_payload) for target in self._targets]
        results = await asyncio.gather(*tasks, return_exceptions=False)
        return results

    async def _replicate_to_target(
        self, target: ReplicationTarget, verdict_payload: dict[str, Any]
    ) -> ReplicationResult:
        """Replicate a verdict to a single target.

        Args:
            target: ReplicationTarget to send to.
            verdict_payload: Verdict payload to replicate.

        Returns:
            ReplicationResult with status and error (if any).
        """
        body_bytes = json.dumps(verdict_payload).encode("utf-8")
        timestamp = str(int(time.time()))

        # Compute HMAC-SHA256 signature
        signature = hmac.new(target.hmac_secret, body_bytes, hashlib.sha256).hexdigest()

        headers = {
            "X-GTV-Replication-Signature": f"sha256={signature}",
            "X-GTV-Replication-Timestamp": timestamp,
            "Content-Type": "application/json",
        }

        # Add Authorization header if api_key is set
        if target.api_key:
            headers["Authorization"] = f"Bearer {target.api_key}"

        url = f"{target.url}/federation/replicate"

        try:
            client = self._client or httpx.AsyncClient(timeout=self._timeout)
            try:
                resp = await client.post(url, content=body_bytes, headers=headers)
                status_code = resp.status_code

                if status_code < 400:
                    return ReplicationResult(
                        target_did=target.did,
                        accepted=True,
                        status_code=status_code,
                        error=None,
                    )
                else:
                    return ReplicationResult(
                        target_did=target.did,
                        accepted=False,
                        status_code=status_code,
                        error=f"HTTP {status_code}",
                    )
            finally:
                if self._client is None:
                    await client.aclose()

        except (httpx.RequestError, httpx.HTTPError, TimeoutError) as e:
            return ReplicationResult(
                target_did=target.did,
                accepted=False,
                status_code=None,
                error=str(e),
            )

    async def close(self) -> None:
        """Close the publisher and any managed client."""
        if self._client is not None:
            await self._client.aclose()


def verify_replication_signature(
    body: bytes,
    signature_header: str,
    hmac_secret: bytes,
    max_age_s: int = 300,
    timestamp_header: str = "",
) -> bool:
    """Server-side helper: verify HMAC-SHA256 signature and timestamp freshness.

    Args:
        body: Raw request body bytes.
        signature_header: Value of X-GTV-Replication-Signature header.
        hmac_secret: HMAC-SHA256 signing key.
        max_age_s: Maximum age of timestamp in seconds (default 300).
        timestamp_header: Value of X-GTV-Replication-Timestamp header (optional for backward compat).

    Returns:
        True if signature and timestamp are valid, False otherwise.
    """
    # Verify HMAC signature
    if not signature_header.startswith("sha256="):
        return False

    provided_sig = signature_header[7:]  # Remove "sha256=" prefix
    expected_sig = hmac.new(hmac_secret, body, hashlib.sha256).hexdigest()

    if not hmac.compare_digest(provided_sig, expected_sig):
        return False

    # Verify timestamp freshness if provided
    if timestamp_header:
        try:
            timestamp = int(timestamp_header)
            now = int(time.time())
            age = now - timestamp

            if age < 0 or age > max_age_s:
                return False
        except (ValueError, TypeError):
            return False

    return True


def load_replication_targets_from_env(
    env_var: str = "GTV_REPLICATION_TARGETS",
) -> list[ReplicationTarget]:
    """Parse ``GTV_REPLICATION_TARGETS`` into a list of ReplicationTarget.

    Format: ``<did>|<url>|<api_key>|<hmac_b64>,...``

    Empty / unset env var returns ``[]`` (replication disabled).
    Malformed entries are skipped with a warning; one bad target should
    not take the whole replication offline.

    Args:
        env_var: Environment variable name (default "GTV_REPLICATION_TARGETS").

    Returns:
        List of ReplicationTarget instances.
    """
    raw = os.environ.get(env_var, "").strip()
    if not raw:
        return []

    targets: list[ReplicationTarget] = []
    for idx, chunk in enumerate(raw.split(",")):
        chunk = chunk.strip()
        if not chunk:
            continue
        parts = chunk.split("|")
        if len(parts) < 3 or not parts[0] or not parts[1]:
            logger.warning(
                "Skipping malformed %s entry #%d: %r (expected did|url|api_key|hmac_b64)",
                env_var,
                idx,
                chunk,
            )
            continue

        did = parts[0].strip()
        url = parts[1].strip().rstrip("/")
        api_key = parts[2].strip() if len(parts) >= 3 else None
        api_key = api_key if api_key else None

        # Parse HMAC secret from base64
        hmac_b64 = parts[3].strip() if len(parts) >= 4 else ""
        if not hmac_b64:
            logger.warning(
                "Skipping malformed %s entry #%d: %r (missing hmac_b64)",
                env_var,
                idx,
                chunk,
            )
            continue

        try:
            hmac_secret = base64.b64decode(hmac_b64)
        except Exception as e:
            logger.warning(
                "Skipping malformed %s entry #%d: %r (invalid hmac_b64: %s)",
                env_var,
                idx,
                chunk,
                e,
            )
            continue

        targets.append(
            ReplicationTarget(did=did, url=url, api_key=api_key, hmac_secret=hmac_secret)
        )

    return targets
