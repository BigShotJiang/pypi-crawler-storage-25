# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Client-side region-aware routing with health probing and failover."""
from __future__ import annotations

import asyncio
import random
import time
from dataclasses import dataclass
from datetime import datetime, timezone

import httpx


@dataclass(frozen=True)
class RegionEndpoint:
    """Configuration for a regional replica endpoint."""

    region: str  # e.g. "us-east-1"
    url: str  # base URL of that replica
    weight: int = 100  # higher = preferred among healthy peers


@dataclass(frozen=True)
class RegionHealth:
    """Health status snapshot for a region."""

    region: str
    healthy: bool
    last_probed: str  # ISO 8601 UTC
    latency_ms: float | None
    consecutive_failures: int


class RegionRouter:
    """Client-side region-aware router with health tracking."""

    def __init__(
        self,
        endpoints: list[RegionEndpoint],
        preferred_region: str | None = None,
        client: httpx.AsyncClient | None = None,
        probe_interval_s: float = 30.0,
        unhealthy_threshold: int = 3,
    ) -> None:
        """Initialize router with endpoints and health configuration.

        Args:
            endpoints: List of RegionEndpoint configurations.
            preferred_region: Preferred region to route to if healthy.
            client: httpx.AsyncClient for health probes. If None, one is created.
            probe_interval_s: Seconds between health probes.
            unhealthy_threshold: Consecutive failures to mark unhealthy.

        Raises:
            ValueError: If endpoints is empty.
        """
        if not endpoints:
            raise ValueError("At least one endpoint is required")

        self.endpoints = {ep.region: ep for ep in endpoints}
        self.preferred_region = preferred_region
        self.probe_interval_s = probe_interval_s
        self.unhealthy_threshold = unhealthy_threshold
        self._client = client or httpx.AsyncClient()
        self._own_client = client is None

        # Health state: region -> (healthy, last_probed, latency_ms, consecutive_failures)
        self._health: dict[str, tuple[bool, str, float | None, int]] = {
            region: (True, _now_iso(), None, 0) for region in self.endpoints
        }
        self._lock = asyncio.Lock()

    async def pick(self) -> RegionEndpoint:
        """Return the best healthy endpoint.

        Priority:
        1. preferred_region, if healthy
        2. Any healthy endpoint with lowest latency_ms
        3. Weighted random among healthy endpoints (if no latency data)
        4. ANY endpoint (last resort)

        Returns:
            RegionEndpoint to use for the request.
        """
        async with self._lock:
            healthy_regions = [
                region for region, (is_healthy, _, _, _) in self._health.items()
                if is_healthy
            ]

        # 1. Try preferred region
        if self.preferred_region and self.preferred_region in healthy_regions:
            return self.endpoints[self.preferred_region]

        # 2. Pick lowest-latency healthy
        if healthy_regions:
            latencies = {}
            async with self._lock:
                for region in healthy_regions:
                    _, _, latency, _ = self._health[region]
                    if latency is not None:
                        latencies[region] = latency

            if latencies:
                # At least one has latency data; use lowest
                best = min(latencies, key=latencies.get)
                return self.endpoints[best]

            # 3. Weighted random among healthy (no latency data yet)
            weights = [self.endpoints[r].weight for r in healthy_regions]
            return self.endpoints[random.choices(healthy_regions, weights=weights, k=1)[0]]

        # 4. Fall back to ANY endpoint (last resort)
        all_regions = list(self.endpoints.keys())
        return self.endpoints[all_regions[0]]

    async def probe_all(self) -> list[RegionHealth]:
        """Probe all endpoints' health and update internal state.

        Makes GET requests to {url}/healthz with 2s timeout.
        Updates health state based on 2xx status (healthy) or failure.

        Returns:
            List of RegionHealth snapshots after probing.
        """
        tasks = [self._probe_one(region) for region in self.endpoints]
        await asyncio.gather(*tasks)
        return self.status()

    async def _probe_one(self, region: str) -> None:
        """Probe a single endpoint and update health state."""
        endpoint = self.endpoints[region]
        url = f"{endpoint.url.rstrip('/')}/healthz"
        start = time.monotonic()

        try:
            resp = await self._client.get(url, timeout=2.0)
            latency_ms = (time.monotonic() - start) * 1000
            is_healthy = 200 <= resp.status_code < 300
        except Exception:
            latency_ms = None
            is_healthy = False

        async with self._lock:
            _, _, _, failures = self._health[region]

            if is_healthy:
                # Success: reset counter and mark healthy
                self._health[region] = (True, _now_iso(), latency_ms, 0)
            else:
                # Failure: increment counter
                new_failures = failures + 1
                # Mark unhealthy only after reaching threshold
                healthy = new_failures < self.unhealthy_threshold
                self._health[region] = (healthy, _now_iso(), latency_ms, new_failures)

    def status(self) -> list[RegionHealth]:
        """Return current health status for all regions.

        Does not probe; reflects last probe results.

        Returns:
            List of RegionHealth snapshots.
        """
        result = []
        for region in self.endpoints:
            healthy, last_probed, latency_ms, failures = self._health[region]
            result.append(
                RegionHealth(
                    region=region,
                    healthy=healthy,
                    last_probed=last_probed,
                    latency_ms=latency_ms,
                    consecutive_failures=failures,
                )
            )
        return result

    async def close(self) -> None:
        """Close the internal HTTP client if we created it."""
        if self._own_client:
            await self._client.aclose()


def _now_iso() -> str:
    """Return current time as ISO 8601 UTC string."""
    return datetime.now(timezone.utc).isoformat(timespec="seconds")  # noqa: UP017
