# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Cross-peer revocation propagation via pull-based gossip protocol.

Nodes expose /federation/revocations?since=<timestamp> to return a list of
revocation records. A gossip runner periodically pulls from each peer and
merges new entries into the local store.
"""
from __future__ import annotations

import asyncio
from dataclasses import dataclass
from typing import Protocol

import httpx


@dataclass(frozen=True)
class RevocationRecord:
    """A cryptographically signed revocation that marks a claim or evidence invalid.

    Immutable to ensure signature consistency. The revocation_id is typically
    a SHA256 of (target_id + reason + issued_at), or supplied by the client.
    """

    revocation_id: str  # sha256 of (target_id + reason + issued_at), or client-supplied
    target_id: str  # claim_id or evidence_id being revoked
    reason: str
    issuer_did: str
    issued_at: str  # ISO 8601 UTC
    signature: str | None = None  # base64; optional — adopted if issuer key known


class LocalStore(Protocol):
    """Duck-typed interface for revocation storage."""

    def list_since(self, timestamp: str) -> list[RevocationRecord]:
        """Return all revocation records issued after the given ISO 8601 timestamp."""
        ...

    def upsert(self, record: RevocationRecord) -> bool:
        """Insert or update a record. Return True if inserted, False if already exists."""
        ...


class RevocationGossip:
    """Pull-based gossip protocol for federated revocation propagation."""

    def __init__(
        self,
        local_store: LocalStore,
        client: httpx.AsyncClient | None = None,
        timeout: float = 5.0,
    ) -> None:
        """Initialize the gossip protocol handler.

        Args:
            local_store: Duck-typed store with list_since() and upsert() methods.
            client: Optional httpx.AsyncClient for HTTP requests. If None, one is created.
            timeout: Request timeout in seconds.
        """
        self.local_store = local_store
        self.client = client
        self._owned_client = client is None
        if self._owned_client:
            self.client = httpx.AsyncClient(timeout=timeout)
        self.timeout = timeout
        self.last_error: dict[str, Exception] | None = None

    async def pull_from(
        self, peer_did: str, peer_url: str, since: str | None = None
    ) -> list[RevocationRecord]:
        """Pull revocation records from a single peer.

        Args:
            peer_did: The peer's DID for logging/tracking.
            peer_url: The base URL of the peer (e.g., "https://peer.example.com").
            since: Optional ISO 8601 timestamp to filter records.

        Returns:
            List of RevocationRecord objects parsed from the peer's response.

        Raises:
            httpx.RequestError: If the HTTP request fails.
        """
        endpoint = f"{peer_url}/federation/revocations"
        params = {}
        if since is not None:
            params["since"] = since

        response = await self.client.get(
            endpoint, params=params, timeout=self.timeout
        )
        response.raise_for_status()

        data = response.json()
        records = []
        for item in data:
            record = RevocationRecord(
                revocation_id=item["revocation_id"],
                target_id=item["target_id"],
                reason=item["reason"],
                issuer_did=item["issuer_did"],
                issued_at=item["issued_at"],
                signature=item.get("signature"),
            )
            records.append(record)

        return records

    async def gossip_round(
        self, peers: list[tuple[str, str]], since: str | None = None
    ) -> dict[str, int]:
        """Pull from all peers concurrently and merge new records.

        Args:
            peers: List of (peer_did, peer_url) tuples.
            since: Optional ISO 8601 timestamp to filter records.

        Returns:
            Dictionary mapping peer_did -> count of new records adopted.
            If a peer errors, its count is 0 and the error is stashed in last_error.
        """
        self.last_error = None
        results = {}

        async def _pull_and_merge(peer_did: str, peer_url: str) -> int:
            try:
                records = await self.pull_from(peer_did, peer_url, since=since)
            except Exception as e:
                if self.last_error is None:
                    self.last_error = {}
                self.last_error[peer_did] = e
                return 0

            adopted_count = 0
            for record in records:
                # Validation: reject records with empty target_id or revocation_id
                if not record.target_id or not record.revocation_id:
                    continue

                # Upsert returns True if newly inserted, False if already exists
                if self.local_store.upsert(record):
                    adopted_count += 1

            return adopted_count

        # Pull from all peers concurrently
        tasks = [_pull_and_merge(did, url) for did, url in peers]
        counts = await asyncio.gather(*tasks)

        # Map results back to peer DIDs
        for (peer_did, _), count in zip(peers, counts, strict=True):
            results[peer_did] = count

        return results

    async def close(self) -> None:
        """Close the HTTP client if owned by this instance."""
        if self._owned_client and self.client is not None:
            await self.client.aclose()
