# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Cross-federation audit chain consistency verifier.

Verifies that audit chains from multiple peers are consistent at their common prefix,
allowing for asynchronous replication where peers may have different tail lengths.
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class AuditEntry:
    """Represents a single audit log entry in a federated chain.

    Attributes:
        entry_id: SHA256 hash of the entry contents.
        claim_id: Identifier of the claim this entry relates to.
        prev_entry_id: SHA256 hash of the previous entry in the chain, or None for first entry.
        payload_hash: SHA256 hash of the entry's payload bytes.
        peer_did: DID of the peer that issued this entry.
        issued_at: ISO 8601 UTC timestamp when the entry was issued.
    """

    entry_id: str
    claim_id: str
    prev_entry_id: str | None
    payload_hash: str
    peer_did: str
    issued_at: str


@dataclass(frozen=True)
class ChainConsistencyReport:
    """Result of verifying audit chain consistency across peers.

    Attributes:
        claim_id: The claim ID being verified.
        consistent: True if all chains are internally linked and share a common prefix.
        divergence_index: Index where chains diverge (None if consistent).
        shared_prefix_length: Length of the common prefix shared by all peers.
        peer_heads: Mapping of peer DID to the head (latest) entry_id in their chain.
        errors: List of validation error messages.
    """

    claim_id: str
    consistent: bool
    divergence_index: int | None
    shared_prefix_length: int
    peer_heads: dict[str, str]
    errors: list[str]


def verify_chain_consistency(
    peer_chains: dict[str, list[AuditEntry]],
) -> ChainConsistencyReport:
    """Verify that audit chains from multiple peers are consistent.

    Checks:
    1. Each peer's chain is internally linked (prev_entry_id of entry i+1 == entry_id of entry i).
    2. Entries at each index match across peers up to the point of divergence.
    3. After divergence, each peer's tail is self-consistent but not compared.

    Returns consistent=True only when:
    - Every peer's chain is internally linked
    - All peers share a common prefix covering every entry up to min(len(chain))
    - divergence_index is None iff consistent=True

    If one peer's chain is a pure prefix of another's, that is CONSISTENT.

    Args:
        peer_chains: Dict mapping peer DID to list of AuditEntry objects in order.

    Returns:
        ChainConsistencyReport with verification results.
    """
    errors: list[str] = []
    peer_heads: dict[str, str] = {}
    claim_id: str | None = None

    # Validate each peer's chain independently
    for peer_did, chain in peer_chains.items():
        if not chain:
            errors.append(f"peer {peer_did}: empty chain")
            continue

        # Record the head entry_id for this peer
        peer_heads[peer_did] = chain[-1].entry_id

        # Get claim_id from first entry (verify it's consistent across peers later)
        if claim_id is None:
            claim_id = chain[0].claim_id
        else:
            if chain[0].claim_id != claim_id:
                claim_id = chain[0].claim_id  # Use the one from first peer

        # Validate internal chain linking
        for i, entry in enumerate(chain):
            # Check claim_id consistency
            if entry.claim_id != claim_id:
                errors.append(
                    f"peer {peer_did}: claim_id mismatch on entry {i} "
                    f"(expected {claim_id}, got {entry.claim_id})"
                )

            # Check chain linking
            if i == 0:
                # First entry should have prev_entry_id = None
                if entry.prev_entry_id is not None:
                    errors.append(
                        f"peer {peer_did}: broken link at index {i} "
                        f"(first entry should have prev_entry_id=None)"
                    )
            else:
                # Subsequent entries should link to previous entry
                if entry.prev_entry_id != chain[i - 1].entry_id:
                    errors.append(
                        f"peer {peer_did}: broken link at index {i} "
                        f"(expected prev_entry_id={chain[i - 1].entry_id}, "
                        f"got {entry.prev_entry_id})"
                    )

    # If any peer has an empty chain or broken link, not consistent
    if errors:
        return ChainConsistencyReport(
            claim_id=claim_id or "",
            consistent=False,
            divergence_index=None,
            shared_prefix_length=0,
            peer_heads=peer_heads,
            errors=errors,
        )

    # No peers - vacuously consistent
    if not peer_chains:
        return ChainConsistencyReport(
            claim_id="",
            consistent=True,
            divergence_index=None,
            shared_prefix_length=0,
            peer_heads={},
            errors=[],
        )

    # Find the minimum chain length (this is the max common prefix we could have)
    min_length = min(len(chain) for chain in peer_chains.values())

    # Check for divergence in the common prefix
    divergence_index: int | None = None
    for idx in range(min_length):
        # Get the entry at idx from the first peer
        first_peer_did = next(iter(peer_chains.keys()))
        first_entry = peer_chains[first_peer_did][idx]

        # Compare with all other peers
        for peer_did, chain in peer_chains.items():
            if peer_did == first_peer_did:
                continue
            entry = chain[idx]

            # Check if entries match
            if entry.entry_id != first_entry.entry_id:
                divergence_index = idx
                break

        if divergence_index is not None:
            break

    if divergence_index is not None:
        # Chains diverged
        return ChainConsistencyReport(
            claim_id=claim_id or "",
            consistent=False,
            divergence_index=divergence_index,
            shared_prefix_length=divergence_index,
            peer_heads=peer_heads,
            errors=errors,
        )

    # No divergence found in common prefix - consistent
    return ChainConsistencyReport(
        claim_id=claim_id or "",
        consistent=True,
        divergence_index=None,
        shared_prefix_length=min_length,
        peer_heads=peer_heads,
        errors=errors,
    )
