# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Cryptographic provenance tracking for consensus aggregation.

When POST /consensus aggregates N input envelopes into a consensus result,
the output must cryptographically reference each input envelope's Rekor index
and canonical hash, not just return a verdict tally.

AggregateEnvelope extends consensus by recording:
- Consensus verdict, confidence, and weighted tally
- Full InputRef for each contributing envelope (issuer, verdict, confidence,
  rekor_uuid, rekor_log_index, canonical hash, trust tier, applied weight)
- A deterministic aggregate_canonical_hash that can be verified against
  the original envelopes
"""
from __future__ import annotations

from datetime import UTC, datetime

from pydantic import BaseModel, ConfigDict, Field

from gtv.anchor.canonicalize import canonicalize, sha256
from gtv.federation.consensus import ConsensusResult
from gtv.models import Envelope, TrustTier, Verdict


class InputRef(BaseModel):
    """Cryptographic reference to a contributing input envelope.

    Attributes:
        envelope_id: The envelope's unique identifier.
        issuer_did: The verifier DID that issued this envelope.
        verdict: The verdict claimed in the envelope.
        confidence: The verifier's confidence in their verdict.
        rekor_uuid: UUID of the Rekor log entry.
        rekor_log_index: Index in the Rekor log (immutable, enables auditability).
        envelope_canonical_hash: SHA256 of the envelope's canonical form
                                 (64-hex string).
        trust_tier: The trust tier assigned to this issuer (T1/T2/T3 or None
                    if unknown).
        weight_applied: The weight actually applied in consensus computation
                       (reflects tier: 3.0/2.0/1.0/0.1).
    """
    model_config = ConfigDict(frozen=True)

    envelope_id: str
    issuer_did: str
    verdict: Verdict
    confidence: float = Field(ge=0.0, le=1.0)
    rekor_uuid: str
    rekor_log_index: int = Field(ge=0)
    envelope_canonical_hash: str = Field(pattern=r"^[0-9a-f]{64}$")
    trust_tier: TrustTier | None = None
    weight_applied: float = Field(ge=0.0)


class AggregateEnvelope(BaseModel):
    """Consensus aggregate with full cryptographic provenance.

    Attributes:
        aggregate_id: Unique identifier for this aggregate (UUIDv7).
        consensus_verdict: The consensus verdict (VERIFIED, UNVERIFIED, CONTESTED, etc.).
        consensus_confidence: Confidence of the verdict in [0.0, 1.0].
        tally: Dict mapping verdict strings to weighted vote counts.
        input_refs: Full cryptographic reference to each contributing envelope.
        aggregated_at: When the aggregation was computed (UTC).
        aggregate_canonical_hash: Deterministic SHA256 of the canonical form
                                 (64-hex string). Same inputs → same hash,
                                 regardless of ordering (canonicalization handles
                                 ordering).
    """
    model_config = ConfigDict(frozen=True)

    aggregate_id: str
    consensus_verdict: Verdict
    consensus_confidence: float = Field(ge=0.0, le=1.0)
    tally: dict[str, float]
    input_refs: list[InputRef]
    aggregated_at: datetime
    aggregate_canonical_hash: str = Field(pattern=r"^[0-9a-f]{64}$")


def build_aggregate_envelope(
    envelopes: list[Envelope],
    consensus: ConsensusResult,
    trust_registry: dict[str, TrustTier] | None = None,
) -> AggregateEnvelope:
    """Build an AggregateEnvelope from envelopes and consensus result.

    Deterministic: same inputs (regardless of ordering) always produce the same
    aggregate_canonical_hash via RFC 8785 canonicalization.

    Args:
        envelopes: The input envelopes aggregated into the consensus.
        consensus: The ConsensusResult from compute_consensus(envelopes).
        trust_registry: Optional dict mapping issuer_did → TrustTier. If not
                       provided, use DEFAULT_REGISTRY.

    Returns:
        An AggregateEnvelope with full provenance tracking.
    """
    if not envelopes:
        raise ValueError("Cannot build aggregate from empty envelope list")

    if trust_registry is None:
        from gtv.federation.registry import DEFAULT_REGISTRY
        trust_registry = {issuer.did: issuer.trust_tier
                         for issuer in DEFAULT_REGISTRY.list_all()}

    # Build tier weights (must match consensus.py exactly).
    tier_weights = {
        "TIER_1": 3.0,
        "TIER_2": 2.0,
        "TIER_3": 1.0,
    }
    unknown_weight = 0.1

    # Build InputRef for each envelope.
    input_refs: list[InputRef] = []
    for env in envelopes:
        tier = trust_registry.get(env.issuer_did)
        weight = unknown_weight if tier is None else tier_weights.get(tier.value, unknown_weight)

        ref = InputRef(
            envelope_id=env.envelope_id,
            issuer_did=env.issuer_did,
            verdict=env.verdict,
            confidence=env.confidence,
            rekor_uuid=env.rekor_uuid,
            rekor_log_index=env.rekor_log_index,
            envelope_canonical_hash=env.canonical_hash(),
            trust_tier=tier,
            weight_applied=weight,
        )
        input_refs.append(ref)

    # Build tally dict from consensus result.
    tally_dict: dict[str, float] = {}
    for tally_item in consensus.tally:
        tally_dict[tally_item.verdict.value] = tally_item.weighted_votes

    # Build aggregate ID (using same logic as Envelope).
    from gtv.models import _uuid7
    aggregate_id = _uuid7()
    aggregated_at = datetime.now(tz=UTC)

    # Build canonical dict for hashing (deterministic, sorted keys at every level).
    canonical_dict = {
        "aggregate_id": aggregate_id,
        "consensus_verdict": consensus.verdict.value,
        "consensus_confidence": consensus.confidence,
        "tally": tally_dict,
        "input_refs": [
            {
                "envelope_id": ref.envelope_id,
                "issuer_did": ref.issuer_did,
                "verdict": ref.verdict.value,
                "confidence": ref.confidence,
                "rekor_uuid": ref.rekor_uuid,
                "rekor_log_index": ref.rekor_log_index,
                "envelope_canonical_hash": ref.envelope_canonical_hash,
                "trust_tier": ref.trust_tier.value if ref.trust_tier else None,
                "weight_applied": ref.weight_applied,
            }
            for ref in input_refs
        ],
        "aggregated_at": aggregated_at.isoformat(),
    }

    aggregate_canonical_hash = sha256(canonicalize(canonical_dict))

    return AggregateEnvelope(
        aggregate_id=aggregate_id,
        consensus_verdict=consensus.verdict,
        consensus_confidence=consensus.confidence,
        tally=tally_dict,
        input_refs=input_refs,
        aggregated_at=aggregated_at,
        aggregate_canonical_hash=aggregate_canonical_hash,
    )


def verify_aggregate_envelope(
    agg: AggregateEnvelope,
    original_envelopes: list[Envelope],
) -> bool:
    """Verify an AggregateEnvelope against the original envelopes.

    Checks:
    1. Every input_ref matches an original envelope by (envelope_id, rekor_log_index,
       envelope_canonical_hash).
    2. The tally can be re-computed from the original envelopes and matches the
       aggregate's tally.

    Args:
        agg: The AggregateEnvelope to verify.
        original_envelopes: The original envelopes that should match input_refs.

    Returns:
        True if verification succeeds, False otherwise.
    """
    if not original_envelopes:
        return False

    # Build a map of envelopes by (envelope_id, rekor_log_index) for fast lookup.
    envelope_map: dict[tuple[str, int], Envelope] = {}
    for env in original_envelopes:
        key = (env.envelope_id, env.rekor_log_index)
        envelope_map[key] = env

    # Verify each InputRef matches an original envelope.
    if len(agg.input_refs) != len(original_envelopes):
        return False

    for ref in agg.input_refs:
        key = (ref.envelope_id, ref.rekor_log_index)
        if key not in envelope_map:
            return False

        env = envelope_map[key]

        # Verify critical fields match.
        if env.canonical_hash() != ref.envelope_canonical_hash:
            return False
        if env.issuer_did != ref.issuer_did:
            return False
        if env.verdict != ref.verdict:
            return False
        if env.confidence != ref.confidence:
            return False
        if env.rekor_uuid != ref.rekor_uuid:
            return False

    # Verify that the tally matches a re-computation.
    from gtv.federation.consensus import compute_consensus
    recomputed = compute_consensus(original_envelopes)

    # Build the recomputed tally as a dict.
    recomputed_tally: dict[str, float] = {}
    for tally_item in recomputed.tally:
        recomputed_tally[tally_item.verdict.value] = tally_item.weighted_votes

    # Compare tallies (allow small floating-point tolerance).
    if set(agg.tally.keys()) != set(recomputed_tally.keys()):
        return False

    for verdict, weight in agg.tally.items():
        if not agg.tally or abs(weight - recomputed_tally.get(verdict, 0.0)) > 1e-9:
            return False

    return True
