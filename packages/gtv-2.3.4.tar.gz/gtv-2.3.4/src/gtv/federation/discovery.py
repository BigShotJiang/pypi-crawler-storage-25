# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""DID-based federation peer discovery.

Resolves a federation-root DID and walks its service array to discover
peer endpoints with type 'GtvFederationPeer'. Peers are discovered via
DID resolution without multi-level traversal (simple single-hop lookup).
"""
from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from typing import Any

import httpx

from gtv.did.resolve import DIDResolutionError, resolve_did_web

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class DiscoveredPeer:
    """A peer discovered via DID resolution or operator seed.

    Schema is shared with `gtv.federation.replicator` so that a peer
    discovered via DID can be fed straight into the replicator without
    a shape translation step.
    """

    did: str
    endpoint_url: str  # verification service endpoint
    discovered_via: str = "did"  # "did" | "seed" | "env"
    discovered_at: str = ""  # ISO 8601 UTC; empty = caller didn't stamp
    api_key: str | None = None  # optional pre-shared key from DID doc
    verified: bool = False  # signature chain checked

    # Backward-compat: some call sites used `.url` before this rename.
    @property
    def url(self) -> str:
        return self.endpoint_url


async def discover_peers_from_did(
    root_did: str, client: httpx.AsyncClient | None = None
) -> list[DiscoveredPeer]:
    """Resolve the root DID and discover federation peers from its service array.

    Resolves the root DID's document and extracts all services with
    type 'GtvFederationPeer'. The serviceEndpoint can be either a string
    or an object with 'url' and optional 'apiKey' fields. Malformed
    service entries are skipped (not raised).

    Args:
        root_did: The federation root DID to resolve.
        client: Optional httpx.AsyncClient for reuse.

    Returns:
        List of DiscoveredPeer objects (may be empty if root doesn't resolve
        or has no peers).
    """
    peers: list[DiscoveredPeer] = []

    try:
        # Resolve the DID document
        did_doc = await resolve_did_web(root_did, client=client)
    except DIDResolutionError as e:
        logger.warning(f"Failed to resolve root DID {root_did}: {e}")
        return []
    except Exception as e:
        logger.error(f"Unexpected error resolving DID {root_did}: {e}")
        return []

    # Extract service array
    services = did_doc.get("service", [])
    if not isinstance(services, list):
        logger.warning(f"DID document service array is not a list: {type(services)}")
        return []

    # Walk services and extract GtvFederationPeer entries
    for service in services:
        if not isinstance(service, dict):
            logger.debug("Skipping non-dict service entry")
            continue

        service_type = service.get("type")
        if service_type != "GtvFederationPeer":
            # Not a federation peer, skip
            continue

        # Parse serviceEndpoint (string or object)
        endpoint = service.get("serviceEndpoint")
        if not endpoint:
            logger.warning("GtvFederationPeer service missing serviceEndpoint")
            continue

        url: str | None = None
        api_key: str | None = None

        if isinstance(endpoint, str):
            url = endpoint
        elif isinstance(endpoint, dict):
            url = endpoint.get("url")
            api_key = endpoint.get("apiKey")
        else:
            logger.warning(
                f"Malformed serviceEndpoint: expected string or dict, got {type(endpoint)}"
            )
            continue

        if not url:
            logger.warning("Malformed serviceEndpoint: missing url")
            continue

        # Get peer DID (optional, default to root_did)
        peer_did = service.get("id", root_did)

        # Create DiscoveredPeer (verified=True since we resolved the DID doc)
        peers.append(
            DiscoveredPeer(
                did=peer_did,
                endpoint_url=url,
                discovered_via="did",
                api_key=api_key,
                verified=True,
            )
        )

    return peers


def merge_discovered_with_env(
    env_peers: list[Any], discovered: list[DiscoveredPeer]
) -> list[Any]:
    """Merge discovered peers with environment-configured peers.

    Environment-configured peers take precedence on DID collision
    (operator-configured takes precedence over discovered).

    Args:
        env_peers: List of FederationPeer objects from env (have 'did' attr).
        discovered: List of DiscoveredPeer objects from DID resolution.

    Returns:
        Combined list of peers (union, env wins on collision).
    """
    # Build a map of env peers by DID
    env_by_did = {p.did: p for p in env_peers}

    # Add discovered peers unless they collide with env
    result = list(env_by_did.values())
    for discovered_peer in discovered:
        if discovered_peer.did not in env_by_did:
            result.append(discovered_peer)

    return result


def load_discovery_config_from_env(env_var: str = "GTV_FEDERATION_ROOT_DID") -> str | None:
    """Load the federation root DID from an environment variable.

    Args:
        env_var: The environment variable name (default: GTV_FEDERATION_ROOT_DID).

    Returns:
        The root DID string, or None if not set.
    """
    root_did = os.environ.get(env_var, "").strip()
    return root_did if root_did else None
