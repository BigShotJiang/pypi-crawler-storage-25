# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Federation registry for trusted issuers."""
from __future__ import annotations

from gtv.federation.audit_verifier import (
    AuditEntry,
    ChainConsistencyReport,
    verify_chain_consistency,
)
from gtv.federation.consensus import ConsensusResult, compute_consensus
from gtv.federation.discovery import (
    DiscoveredPeer,
    discover_peers_from_did,
    load_discovery_config_from_env,
    merge_discovered_with_env,
)
from gtv.federation.domain_bundle import (
    DomainBundle,
    InvalidBundleError,
    sign_bundle,
    verify_bundle,
)
from gtv.federation.loader import load_registry_from_env, load_registry_from_json
from gtv.federation.partition_recovery import (
    CatchUpReport,
    InMemoryVerdictLog,
    PartitionRecovery,
    VerdictLogEntry,
    make_verdicts_since_handler,
)
from gtv.federation.peer_trust import TrustMatrix, compute_global_trust
from gtv.federation.region_router import RegionEndpoint, RegionHealth, RegionRouter
from gtv.federation.registry import DEFAULT_REGISTRY, IssuerRegistry, TrustedIssuer
from gtv.federation.replicator import ReplicationResult, VerdictReplicator
from gtv.federation.revocation_gossip import RevocationGossip, RevocationRecord
from gtv.federation.split_brain import (
    ClaimLineage,
    DivergenceReport,
    MergeProposal,
    detect_divergence,
    propose_merge,
)
from gtv.federation.verdict_consensus import (
    FederatedVerdict,
    PeerVerdict,
    merge_peer_verdicts,
)

__all__ = [
    "DEFAULT_REGISTRY",
    "AuditEntry",
    "CatchUpReport",
    "ChainConsistencyReport",
    "ClaimLineage",
    "ConsensusResult",
    "DiscoveredPeer",
    "DivergenceReport",
    "DomainBundle",
    "FederatedVerdict",
    "InMemoryVerdictLog",
    "InvalidBundleError",
    "IssuerRegistry",
    "MergeProposal",
    "PartitionRecovery",
    "PeerVerdict",
    "RegionEndpoint",
    "RegionHealth",
    "RegionRouter",
    "ReplicationResult",
    "RevocationGossip",
    "RevocationRecord",
    "TrustMatrix",
    "TrustedIssuer",
    "VerdictLogEntry",
    "VerdictReplicator",
    "compute_consensus",
    "compute_global_trust",
    "detect_divergence",
    "discover_peers_from_did",
    "load_discovery_config_from_env",
    "load_registry_from_env",
    "load_registry_from_json",
    "make_verdicts_since_handler",
    "merge_discovered_with_env",
    "merge_peer_verdicts",
    "propose_merge",
    "sign_bundle",
    "verify_bundle",
    "verify_chain_consistency",
]
