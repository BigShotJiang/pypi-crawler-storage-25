# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Federated verdict consensus over peer verdicts with trust weighting.

Merges verdicts from multiple federated peers using trust-weighted voting.
Each peer publishes a verdict (VERIFIED, REFUTED, INSUFFICIENT) with a
confidence score. This module computes a merged verdict by trust-weighting
each peer's vote and selecting the winning status.

Algorithm:
1. If < min_quorum peers, return INSUFFICIENT with confidence 0.
2. Weight each peer's vote by trust_scores.get(peer_did, 1.0) * confidence.
3. Sum weighted votes per status; pick argmax status.
4. If all statuses are tied at equal weight: return INSUFFICIENT.
5. Merged confidence = weighted mean of confidences for peers voting for
   the winning status.
6. Track dissenters (peers whose status disagrees with the winning status).
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class PeerVerdict:
    """Verdict issued by a single federated peer.

    Attributes:
        peer_did: DID of the peer that issued this verdict.
        status: Verdict status ("VERIFIED", "REFUTED", "INSUFFICIENT").
        confidence: Confidence in [0, 1].
        issued_at: ISO 8601 UTC timestamp.
    """

    peer_did: str
    status: str
    confidence: float
    issued_at: str


@dataclass(frozen=True)
class FederatedVerdict:
    """Result of merging verdicts from federated peers.

    Attributes:
        status: Merged verdict status.
        confidence: Weighted-mean confidence of peers voting for the status.
        quorum_size: Count of peers that contributed to the merge.
        dissenters: List of peer DIDs whose status disagrees with the
                    merged status.
    """

    status: str
    confidence: float
    quorum_size: int
    dissenters: list[str]


def merge_peer_verdicts(
    peer_verdicts: list[PeerVerdict],
    trust_scores: dict[str, float] | None = None,
    min_quorum: int = 2,
) -> FederatedVerdict:
    """Merge verdicts from multiple peers using trust-weighted voting.

    Args:
        peer_verdicts: List of PeerVerdict objects.
        trust_scores: Optional dict mapping peer_did to trust score (0..1).
                      Defaults to 1.0 for peers not in the dict.
        min_quorum: Minimum number of peers required (default 2).
                    If fewer peers, status = "INSUFFICIENT".

    Returns:
        FederatedVerdict with merged status, confidence, quorum_size,
        and dissenters.
    """
    if trust_scores is None:
        trust_scores = {}

    # Check quorum
    if len(peer_verdicts) < min_quorum:
        return FederatedVerdict(
            status="INSUFFICIENT",
            confidence=0.0,
            quorum_size=len(peer_verdicts),
            dissenters=[],
        )

    # If empty, return INSUFFICIENT
    if not peer_verdicts:
        return FederatedVerdict(
            status="INSUFFICIENT",
            confidence=0.0,
            quorum_size=0,
            dissenters=[],
        )

    # Accumulate weighted votes per status
    votes: dict[str, float] = {}
    vote_counts: dict[str, int] = {}
    confidence_sums: dict[str, float] = {}

    for pv in peer_verdicts:
        trust = trust_scores.get(pv.peer_did, 1.0)
        weight = trust * pv.confidence

        votes[pv.status] = votes.get(pv.status, 0.0) + weight
        vote_counts[pv.status] = vote_counts.get(pv.status, 0) + 1
        confidence_sums[pv.status] = confidence_sums.get(pv.status, 0.0) + pv.confidence

    # Find winning status(es)
    if not votes:
        return FederatedVerdict(
            status="INSUFFICIENT",
            confidence=0.0,
            quorum_size=len(peer_verdicts),
            dissenters=[],
        )

    max_weight = max(votes.values())
    winning_statuses = [s for s, w in votes.items() if w == max_weight]

    # If all 3 statuses tie at equal weight, return INSUFFICIENT
    # (only when we have exactly 3 distinct statuses all at max_weight)
    if len(votes) == 3 and len(winning_statuses) == 3:
        return FederatedVerdict(
            status="INSUFFICIENT",
            confidence=0.0,
            quorum_size=len(peer_verdicts),
            dissenters=[],
        )

    # Pick the first winning status (arbitrary but deterministic)
    winning_status = winning_statuses[0]

    # Compute weighted-mean confidence for the winning status
    winning_count = vote_counts.get(winning_status, 0)
    if winning_count > 0:
        merged_confidence = confidence_sums[winning_status] / winning_count
    else:
        merged_confidence = 0.0

    # Track dissenters
    dissenters = [
        pv.peer_did for pv in peer_verdicts if pv.status != winning_status
    ]

    return FederatedVerdict(
        status=winning_status,
        confidence=merged_confidence,
        quorum_size=len(peer_verdicts),
        dissenters=dissenters,
    )
