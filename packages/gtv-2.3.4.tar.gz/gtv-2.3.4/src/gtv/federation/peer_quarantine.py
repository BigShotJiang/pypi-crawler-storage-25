# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Peer quarantine rule engine and manager.

When a peer starts producing verdicts that systematically disagree with consensus
or exhibit other anomalous behavior, nothing quarantines it by default. This module
implements a rule-based quarantine system that watches peer behavior and removes
peers from consensus weight when they trigger any of these rules:

1. **Signature failure rate** > 5% over last 100 verdicts received
2. **Disagreement rate** (vs. local consensus) > 40% over last 50 federation decisions
3. **Stale clock** — peer's emitted_at drifts > 5 min from local clock for > 10 consecutive verdicts
4. **Hash mismatch** — peer's claimed verdict hash doesn't match recomputed hash (immediate)
5. **Rate spam** — peer emits > 10x its historical 1-hour average (configurable)

When quarantined, the peer's verdicts are excluded from consensus weight but still
logged for audit. Quarantine state is time-bounded (default 24h) with auto-release;
operators can manually extend or release.
"""
from __future__ import annotations

import json
import logging
from abc import ABC, abstractmethod
from collections import deque
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from enum import StrEnum
from pathlib import Path

logger = logging.getLogger(__name__)


class QuarantineReason(StrEnum):
    """Why a peer was quarantined."""
    SIGNATURE_FAILURE_RATE = "signature_failure_rate"
    DISAGREEMENT_RATE = "disagreement_rate"
    STALE_CLOCK = "stale_clock"
    HASH_MISMATCH = "hash_mismatch"
    RATE_SPAM = "rate_spam"


@dataclass(frozen=True)
class QuarantineDecision:
    """Decision to quarantine a peer."""
    peer_did: str
    reason: QuarantineReason
    reason_detail: str
    recommended_duration_s: int


@dataclass(frozen=True)
class QuarantineRecord:
    """Persisted record of a quarantine."""
    peer_did: str
    reason: QuarantineReason
    quarantined_at: datetime
    duration_s: int
    applied_at: datetime
    released_at: datetime | None = None

    def is_active(self, now: datetime) -> bool:
        """Check if quarantine is still active at given time."""
        if self.released_at is not None:
            return now < self.released_at
        expiry = self.applied_at + timedelta(seconds=self.duration_s)
        return now < expiry

    def to_dict(self) -> dict:
        """Convert to JSON-serializable dict."""
        return {
            "peer_did": self.peer_did,
            "reason": self.reason.value,
            "quarantined_at": self.quarantined_at.isoformat(),
            "duration_s": self.duration_s,
            "applied_at": self.applied_at.isoformat(),
            "released_at": self.released_at.isoformat() if self.released_at else None,
        }

    @staticmethod
    def from_dict(d: dict) -> QuarantineRecord:
        """Reconstruct from JSON dict."""
        return QuarantineRecord(
            peer_did=d["peer_did"],
            reason=QuarantineReason(d["reason"]),
            quarantined_at=datetime.fromisoformat(d["quarantined_at"]),
            duration_s=d["duration_s"],
            applied_at=datetime.fromisoformat(d["applied_at"]),
            released_at=datetime.fromisoformat(d["released_at"]) if d.get("released_at") else None,
        )


@dataclass
class PeerVerdictRecord:
    """One verdict received from a peer."""
    verdict_id: str
    emitted_at: datetime
    signature_valid: bool
    hash_valid: bool
    claim_agreement: bool | None  # None if consensus didn't form yet


class PeerBehaviorTracker:
    """Tracks behavior of a peer across recent verdicts."""

    def __init__(self, window_size: int = 100):
        """Initialize tracker.

        Args:
            window_size: How many verdicts to keep in rolling window (default 100).
        """
        self.window_size = window_size
        # Rolling window of verdicts per peer
        self.verdicts: dict[str, deque[PeerVerdictRecord]] = {}
        # Counters per peer
        self.signature_failures: dict[str, int] = {}
        self.hash_mismatches: dict[str, int] = {}
        self.disagreements: dict[str, int] = {}
        self.stale_clock_consecutive: dict[str, int] = {}
        # Rate tracking: timestamps of verdicts per peer (last hour)
        self.verdict_timestamps: dict[str, deque[datetime]] = {}

    def record_verdict_received(
        self,
        peer_did: str,
        verdict_id: str,
        emitted_at: datetime,
        signature_valid: bool,
        hash_valid: bool,
        claim_agreement: bool | None = None,
    ) -> None:
        """Record a verdict received from a peer.

        Args:
            peer_did: The peer's DID.
            verdict_id: Unique verdict ID.
            emitted_at: When the peer emitted it.
            signature_valid: Whether signature verified.
            hash_valid: Whether computed hash matches claimed hash.
            claim_agreement: True if peer's verdict agrees with consensus, False otherwise,
                           None if no consensus yet.
        """
        if peer_did not in self.verdicts:
            self.verdicts[peer_did] = deque(maxlen=self.window_size)
            self.verdict_timestamps[peer_did] = deque(maxlen=3600)  # 1 hour in seconds

        record = PeerVerdictRecord(
            verdict_id=verdict_id,
            emitted_at=emitted_at,
            signature_valid=signature_valid,
            hash_valid=hash_valid,
            claim_agreement=claim_agreement,
        )
        self.verdicts[peer_did].append(record)
        self.verdict_timestamps[peer_did].append(emitted_at)

        # Update failure counters
        if not signature_valid:
            self.signature_failures[peer_did] = self.signature_failures.get(peer_did, 0) + 1
        if not hash_valid:
            self.hash_mismatches[peer_did] = self.hash_mismatches.get(peer_did, 0) + 1
        if claim_agreement is False:
            self.disagreements[peer_did] = self.disagreements.get(peer_did, 0) + 1

    def get_verdict_window(self, peer_did: str, limit: int) -> list[PeerVerdictRecord]:
        """Get last N verdicts from a peer."""
        if peer_did not in self.verdicts:
            return []
        return list(self.verdicts[peer_did])[-limit:]

    def get_signature_failure_rate(self, peer_did: str) -> float:
        """Get signature failure rate over last 100 verdicts."""
        verdicts = self.get_verdict_window(peer_did, self.window_size)
        if not verdicts:
            return 0.0
        failures = sum(1 for v in verdicts if not v.signature_valid)
        return failures / len(verdicts)

    def get_disagreement_rate(self, peer_did: str, limit: int = 50) -> float:
        """Get disagreement rate over last N verdicts."""
        verdicts = self.get_verdict_window(peer_did, limit)
        if not verdicts:
            return 0.0
        disagreements = sum(1 for v in verdicts if v.claim_agreement is False)
        return disagreements / len(verdicts)

    def count_consecutive_stale_clocks(
        self, peer_did: str, max_drift_s: int = 300, now: datetime | None = None
    ) -> int:
        """Count consecutive stale clock verdicts from end.

        Args:
            peer_did: The peer's DID.
            max_drift_s: Max allowed drift in seconds (default 300 = 5 min).
            now: Current time (default: UTC now).

        Returns:
            Number of consecutive stale-clock verdicts at the end of window.
        """
        if now is None:
            now = datetime.now(tz=UTC)

        verdicts = self.get_verdict_window(peer_did, self.window_size)
        if not verdicts:
            return 0

        count = 0
        for v in reversed(verdicts):
            drift = abs((v.emitted_at - now).total_seconds())
            if drift > max_drift_s:
                count += 1
            else:
                break
        return count

    def count_rate_violations(
        self, peer_did: str, now: datetime | None = None, multiplier: int = 10
    ) -> float:
        """Compute current rate vs. historical 1-hour average.

        Args:
            peer_did: The peer's DID.
            now: Current time (default: UTC now).
            multiplier: Rate violation threshold (default 10x).

        Returns:
            Current rate / historical average (or 0 if no history).
        """
        if now is None:
            now = datetime.now(tz=UTC)

        if peer_did not in self.verdict_timestamps:
            return 0.0

        timestamps = self.verdict_timestamps[peer_did]
        if not timestamps:
            return 0.0

        # Count verdicts in last hour
        one_hour_ago = now - timedelta(hours=1)
        recent_count = sum(1 for ts in timestamps if ts > one_hour_ago)

        # Historical average: total / time elapsed (clamped to max 1 hour)
        oldest = timestamps[0]
        age = max((now - oldest).total_seconds(), 1.0)
        age_hours = min(age / 3600.0, 1.0)  # Cap at 1 hour for fresh peers
        historical_avg = len(timestamps) / age_hours if age_hours > 0 else 0.0

        if historical_avg == 0:
            return 0.0
        return recent_count / historical_avg


class QuarantineRule(ABC):
    """Base class for quarantine rules."""

    @abstractmethod
    def evaluate(
        self, tracker: PeerBehaviorTracker, peer_did: str, now: datetime
    ) -> QuarantineDecision | None:
        """Evaluate if peer should be quarantined.

        Args:
            tracker: The behavior tracker.
            peer_did: Peer DID to evaluate.
            now: Current time.

        Returns:
            QuarantineDecision if peer violates rule, else None.
        """
        pass


class SignatureFailureRule(QuarantineRule):
    """Signature failure rate > 5% over last 100 verdicts."""

    def __init__(self, threshold: float = 0.05, window_size: int = 100):
        self.threshold = threshold
        self.window_size = window_size

    def evaluate(
        self, tracker: PeerBehaviorTracker, peer_did: str, now: datetime
    ) -> QuarantineDecision | None:
        """Check signature failure rate."""
        rate = tracker.get_signature_failure_rate(peer_did)
        if rate > self.threshold:
            return QuarantineDecision(
                peer_did=peer_did,
                reason=QuarantineReason.SIGNATURE_FAILURE_RATE,
                reason_detail=f"Signature failure rate {rate:.1%} > {self.threshold:.1%} over last {self.window_size} verdicts",
                recommended_duration_s=86400,  # 24 hours
            )
        return None


class DisagreementRule(QuarantineRule):
    """Disagreement rate vs. consensus > 40% over last 50 decisions."""

    def __init__(self, threshold: float = 0.40, window_size: int = 50):
        self.threshold = threshold
        self.window_size = window_size

    def evaluate(
        self, tracker: PeerBehaviorTracker, peer_did: str, now: datetime
    ) -> QuarantineDecision | None:
        """Check disagreement rate."""
        rate = tracker.get_disagreement_rate(peer_did, self.window_size)
        if rate > self.threshold:
            return QuarantineDecision(
                peer_did=peer_did,
                reason=QuarantineReason.DISAGREEMENT_RATE,
                reason_detail=f"Disagreement rate {rate:.1%} > {self.threshold:.1%} over last {self.window_size} decisions",
                recommended_duration_s=86400,  # 24 hours
            )
        return None


class StaleClockRule(QuarantineRule):
    """Stale clock: emitted_at drifts > 5 min for > 10 consecutive verdicts."""

    def __init__(self, max_drift_s: int = 300, consecutive_threshold: int = 10):
        self.max_drift_s = max_drift_s
        self.consecutive_threshold = consecutive_threshold

    def evaluate(
        self, tracker: PeerBehaviorTracker, peer_did: str, now: datetime
    ) -> QuarantineDecision | None:
        """Check stale clock."""
        consecutive = tracker.count_consecutive_stale_clocks(
            peer_did, max_drift_s=self.max_drift_s, now=now
        )
        if consecutive >= self.consecutive_threshold:
            return QuarantineDecision(
                peer_did=peer_did,
                reason=QuarantineReason.STALE_CLOCK,
                reason_detail=f"{consecutive} consecutive verdicts with emitted_at drifted > {self.max_drift_s}s from local clock",
                recommended_duration_s=86400,  # 24 hours
            )
        return None


class HashMismatchRule(QuarantineRule):
    """Hash mismatch: immediate quarantine on any occurrence."""

    def __init__(self):
        pass

    def evaluate(
        self, tracker: PeerBehaviorTracker, peer_did: str, now: datetime
    ) -> QuarantineDecision | None:
        """Check for hash mismatch (any occurrence)."""
        verdicts = tracker.get_verdict_window(peer_did, tracker.window_size)
        if any(not v.hash_valid for v in verdicts):
            return QuarantineDecision(
                peer_did=peer_did,
                reason=QuarantineReason.HASH_MISMATCH,
                reason_detail="Peer's claimed verdict hash does not match recomputed hash",
                recommended_duration_s=604800,  # 7 days (more serious)
            )
        return None


class RateSpamRule(QuarantineRule):
    """Rate spam: peer emits > 10x historical 1-hour average."""

    def __init__(self, multiplier: int = 10):
        self.multiplier = multiplier

    def evaluate(
        self, tracker: PeerBehaviorTracker, peer_did: str, now: datetime
    ) -> QuarantineDecision | None:
        """Check rate spam."""
        ratio = tracker.count_rate_violations(peer_did, now=now, multiplier=self.multiplier)
        if ratio > self.multiplier:
            return QuarantineDecision(
                peer_did=peer_did,
                reason=QuarantineReason.RATE_SPAM,
                reason_detail=f"Peer rate {ratio:.1f}x historical 1-hour average (threshold {self.multiplier}x)",
                recommended_duration_s=3600,  # 1 hour
            )
        return None


class JsonFileQuarantineStore:
    """Persist quarantine records to JSON file."""

    def __init__(self, path: str | None = None):
        """Initialize store.

        Args:
            path: Path to JSON file. If None, in-memory only.
        """
        self.path = Path(path) if path else None
        self.records: list[QuarantineRecord] = []
        if self.path and self.path.exists():
            try:
                with open(self.path) as f:
                    data = json.load(f)
                    self.records = [QuarantineRecord.from_dict(r) for r in data]
            except (json.JSONDecodeError, KeyError) as e:
                logger.warning(f"Failed to load quarantine store from {self.path}: {e}")

    def save(self, records: list[QuarantineRecord]) -> None:
        """Persist records to file."""
        self.records = records
        if not self.path:
            return
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            with open(self.path, "w") as f:
                json.dump([r.to_dict() for r in records], f, indent=2)
        except OSError as e:
            logger.error(f"Failed to save quarantine store to {self.path}: {e}")

    def load(self) -> list[QuarantineRecord]:
        """Return in-memory records."""
        return self.records


class PeerQuarantine:
    """Manages peer quarantine state and auto-release."""

    def __init__(
        self,
        default_duration_s: int = 86400,
        store: JsonFileQuarantineStore | None = None,
    ):
        """Initialize quarantine manager.

        Args:
            default_duration_s: Default quarantine duration in seconds (24h).
            store: Optional persistence store.
        """
        self.default_duration_s = default_duration_s
        self.store = store or JsonFileQuarantineStore()
        self._records = self.store.load()
        # Initialize rule engine with default thresholds
        self.rules: list[QuarantineRule] = [
            SignatureFailureRule(threshold=0.05, window_size=100),
            DisagreementRule(threshold=0.40, window_size=50),
            StaleClockRule(max_drift_s=300, consecutive_threshold=10),
            HashMismatchRule(),
            RateSpamRule(multiplier=10),
        ]

    def quarantine(
        self,
        peer_did: str,
        reason: QuarantineReason,
        duration_s: int | None = None,
        applied_at: datetime | None = None,
    ) -> None:
        """Record a quarantine.

        Args:
            peer_did: The peer's DID.
            reason: Why it was quarantined.
            duration_s: How long (default: self.default_duration_s).
            applied_at: When it was applied (default: UTC now).
        """
        if duration_s is None:
            duration_s = self.default_duration_s
        if applied_at is None:
            applied_at = datetime.now(tz=UTC)

        record = QuarantineRecord(
            peer_did=peer_did,
            reason=reason,
            quarantined_at=datetime.now(tz=UTC),
            duration_s=duration_s,
            applied_at=applied_at,
        )
        # Remove any existing active quarantine for this peer (re-quarantine resets duration)
        self._records = [r for r in self._records if r.peer_did != peer_did or not r.is_active(applied_at)]
        self._records.append(record)
        self.store.save(self._records)

    def release(self, peer_did: str, applied_at: datetime | None = None) -> None:
        """Manually release a quarantine.

        Args:
            peer_did: The peer's DID.
            applied_at: When release was applied (default: UTC now).
        """
        if applied_at is None:
            applied_at = datetime.now(tz=UTC)

        # Update the record with release time
        for record in self._records:
            if record.peer_did == peer_did and record.is_active(applied_at):
                # Create a new released record
                released = QuarantineRecord(
                    peer_did=record.peer_did,
                    reason=record.reason,
                    quarantined_at=record.quarantined_at,
                    duration_s=record.duration_s,
                    applied_at=record.applied_at,
                    released_at=applied_at,
                )
                self._records[self._records.index(record)] = released
                break
        self.store.save(self._records)

    def is_quarantined(self, peer_did: str, now: datetime | None = None) -> bool:
        """Check if peer is currently quarantined.

        Args:
            peer_did: The peer's DID.
            now: Current time (default: UTC now).

        Returns:
            True if any active quarantine exists.
        """
        if now is None:
            now = datetime.now(tz=UTC)

        for record in self._records:
            if record.peer_did == peer_did and record.is_active(now):
                return True
        return False

    def active(self, now: datetime | None = None) -> list[QuarantineRecord]:
        """Get all currently active quarantines.

        Args:
            now: Current time (default: UTC now).

        Returns:
            List of active quarantine records.
        """
        if now is None:
            now = datetime.now(tz=UTC)

        return [r for r in self._records if r.is_active(now)]

    def evaluate_all(
        self, tracker: PeerBehaviorTracker, now: datetime | None = None
    ) -> list[QuarantineDecision]:
        """Run all rules against all peers in tracker.

        Args:
            tracker: The behavior tracker.
            now: Current time (default: UTC now).

        Returns:
            List of QuarantineDecisions triggered by any rule.
        """
        if now is None:
            now = datetime.now(tz=UTC)

        decisions: list[QuarantineDecision] = []
        for peer_did in tracker.verdicts:
            # Skip if already quarantined
            if self.is_quarantined(peer_did, now=now):
                continue

            for rule in self.rules:
                decision = rule.evaluate(tracker, peer_did, now)
                if decision:
                    decisions.append(decision)
                    break  # Stop at first rule that triggers for this peer

        return decisions
