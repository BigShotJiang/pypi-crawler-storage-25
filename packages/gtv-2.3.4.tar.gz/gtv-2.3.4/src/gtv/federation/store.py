# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""SQLite-backed issuer store for persistent federation trust registry.

Thread-safe storage for trusted issuers with soft-delete (revocation) support.
No ORM, no migrations framework, just sqlite3 + hand-rolled SQL.
"""
from __future__ import annotations

import sqlite3
import threading
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING

from gtv.models import TrustTier

if TYPE_CHECKING:
    pass


@dataclass(frozen=True)
class StoredIssuer:
    """Represents a stored issuer record.

    Attributes:
        issuer_did: DID identifying this issuer (e.g., "did:web:verify.groundtruth.example").
        name: Human-readable name for this issuer.
        trust_tier: The trust tier (TIER_1, TIER_2, or TIER_3).
        added_at: ISO 8601 timestamp when the issuer was added.
        updated_at: ISO 8601 timestamp of the last update.
        revoked_at: ISO 8601 timestamp of revocation, or None if active.
        notes: Optional notes about this issuer.
    """

    issuer_did: str
    name: str
    trust_tier: TrustTier
    added_at: str
    updated_at: str
    revoked_at: str | None
    notes: str

    def is_active(self) -> bool:
        """Check if this issuer is active (not revoked)."""
        return self.revoked_at is None


class IssuerStore:
    """SQLite-backed store for trusted issuers.

    Thread-safe via a lock. Connection is kept as an instance attribute.
    Schema: issuers(issuer_did, name, trust_tier, added_at, updated_at, revoked_at, notes).
    """

    def __init__(self, path: str | Path = "~/.gtv/federation.db") -> None:
        """Initialize store and create table if not exists.

        Args:
            path: Path to the SQLite database file. Defaults to ~/.gtv/federation.db.
                  Parent directories are created automatically.
        """
        self.path = Path(path).expanduser()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._conn = sqlite3.connect(str(self.path), check_same_thread=False)
        self._conn.isolation_level = None  # autocommit mode
        self._init_schema()

    def _init_schema(self) -> None:
        """Create issuers table if not exists."""
        self._conn.execute(
            """
            CREATE TABLE IF NOT EXISTS issuers (
                issuer_did TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                trust_tier TEXT NOT NULL,
                added_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                revoked_at TEXT,
                notes TEXT
            )
            """
        )

    def add(self, issuer_did: str, name: str, trust_tier: TrustTier, notes: str = "") -> None:
        """Add or update an issuer (upsert).

        If the issuer already exists, updates its metadata and refreshes updated_at.
        Does not affect revoked_at (soft-delete).

        Args:
            issuer_did: The DID of the issuer.
            name: Human-readable name.
            trust_tier: The trust tier.
            notes: Optional notes about the issuer.
        """
        now = datetime.now(UTC).isoformat()
        with self._lock:
            # Check if already exists to preserve added_at
            cursor = self._conn.execute(
                "SELECT added_at FROM issuers WHERE issuer_did = ?",
                (issuer_did,),
            )
            row = cursor.fetchone()
            added_at = row[0] if row else now

            self._conn.execute(
                """
                INSERT OR REPLACE INTO issuers
                (issuer_did, name, trust_tier, added_at, updated_at, notes)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (issuer_did, name, trust_tier.value, added_at, now, notes),
            )

    def update_tier(self, issuer_did: str, trust_tier: TrustTier) -> bool:
        """Update the trust tier of an issuer.

        Updates updated_at. Does not restore revoked issuers.

        Args:
            issuer_did: The DID of the issuer.
            trust_tier: The new trust tier.

        Returns:
            True if the issuer was found and updated, False otherwise.
        """
        now = datetime.now(UTC).isoformat()
        with self._lock:
            cursor = self._conn.execute(
                "UPDATE issuers SET trust_tier = ?, updated_at = ? WHERE issuer_did = ?",
                (trust_tier.value, now, issuer_did),
            )
            return cursor.rowcount > 0

    def revoke(self, issuer_did: str) -> bool:
        """Revoke an issuer by setting revoked_at.

        Args:
            issuer_did: The DID of the issuer.

        Returns:
            True if the issuer was found and revoked, False otherwise.
        """
        now = datetime.now(UTC).isoformat()
        with self._lock:
            cursor = self._conn.execute(
                "UPDATE issuers SET revoked_at = ? WHERE issuer_did = ?",
                (now, issuer_did),
            )
            return cursor.rowcount > 0

    def get(self, issuer_did: str) -> StoredIssuer | None:
        """Get an active issuer by DID.

        Returns None if not found or if revoked. Use get_raw() for audit access.

        Args:
            issuer_did: The DID to look up.

        Returns:
            The StoredIssuer, or None if not found or revoked.
        """
        with self._lock:
            cursor = self._conn.execute(
                """
                SELECT issuer_did, name, trust_tier, added_at, updated_at, revoked_at, notes
                FROM issuers WHERE issuer_did = ? AND revoked_at IS NULL
                """,
                (issuer_did,),
            )
            row = cursor.fetchone()
            if row:
                return self._row_to_issuer(row)
            return None

    def get_raw(self, issuer_did: str) -> StoredIssuer | None:
        """Get an issuer by DID, including revoked issuers (audit access).

        Args:
            issuer_did: The DID to look up.

        Returns:
            The StoredIssuer, or None if not found.
        """
        with self._lock:
            cursor = self._conn.execute(
                """
                SELECT issuer_did, name, trust_tier, added_at, updated_at, revoked_at, notes
                FROM issuers WHERE issuer_did = ?
                """,
                (issuer_did,),
            )
            row = cursor.fetchone()
            if row:
                return self._row_to_issuer(row)
            return None

    def list_active(self) -> list[StoredIssuer]:
        """List all active (non-revoked) issuers.

        Returns:
            A list of active StoredIssuer objects.
        """
        with self._lock:
            cursor = self._conn.execute(
                """
                SELECT issuer_did, name, trust_tier, added_at, updated_at, revoked_at, notes
                FROM issuers WHERE revoked_at IS NULL ORDER BY issuer_did
                """
            )
            return [self._row_to_issuer(row) for row in cursor.fetchall()]

    def list_all(self) -> list[StoredIssuer]:
        """List all issuers including revoked ones.

        Returns:
            A list of all StoredIssuer objects.
        """
        with self._lock:
            cursor = self._conn.execute(
                """
                SELECT issuer_did, name, trust_tier, added_at, updated_at, revoked_at, notes
                FROM issuers ORDER BY issuer_did
                """
            )
            return [self._row_to_issuer(row) for row in cursor.fetchall()]

    def get_tier(self, issuer_did: str) -> TrustTier | None:
        """Get the trust tier of an active issuer.

        Args:
            issuer_did: The DID to look up.

        Returns:
            The TrustTier if found and active, None otherwise.
        """
        issuer = self.get(issuer_did)
        return issuer.trust_tier if issuer else None

    @staticmethod
    def _row_to_issuer(row: tuple[object, ...]) -> StoredIssuer:
        """Convert a DB row to a StoredIssuer object."""
        issuer_did_raw, name_raw, trust_tier_raw, added_at_raw, updated_at_raw, revoked_at_raw, notes_raw = row

        # SQLite typing: cursor returns object; constrain to the declared column types.
        assert isinstance(issuer_did_raw, str)
        assert isinstance(name_raw, str)
        assert isinstance(trust_tier_raw, str)
        assert isinstance(added_at_raw, str)
        assert isinstance(updated_at_raw, str)
        assert revoked_at_raw is None or isinstance(revoked_at_raw, str)
        assert notes_raw is None or isinstance(notes_raw, str)

        return StoredIssuer(
            issuer_did=issuer_did_raw,
            name=name_raw,
            trust_tier=TrustTier(trust_tier_raw),
            added_at=added_at_raw,
            updated_at=updated_at_raw,
            revoked_at=revoked_at_raw,
            notes=notes_raw or "",
        )

    def close(self) -> None:
        """Close the database connection."""
        with self._lock:
            self._conn.close()
