# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Claim-level cache: canonicalize and deduplicate claims by content."""
from __future__ import annotations

import hashlib
import string
import time
from collections import OrderedDict
from typing import Final

# Reuse stopwords from gtv.adapters.parse
_STOPWORDS: Final[set[str]] = {
    "a", "about", "above", "after", "again", "against", "all", "am", "an",
    "and", "any", "are", "aren't", "as", "at", "be", "because", "been",
    "before", "being", "below", "between", "both", "but", "by", "can't",
    "cannot", "could", "couldn't", "did", "didn't", "do", "does", "doesn't",
    "doing", "don't", "down", "during", "each", "few", "for", "from",
    "further", "had", "hadn't", "has", "hasn't", "have", "haven't", "having",
    "he", "he'd", "he'll", "he's", "her", "here", "here's", "hers", "herself",
    "him", "himself", "his", "how", "how's", "i", "i'd", "i'll", "i'm", "i've",
    "if", "in", "into", "is", "isn't", "it", "it's", "its", "itself", "just",
    "k", "ks", "let's", "me", "more", "most", "mustn't", "my", "myself", "no",
    "nor", "not", "of", "off", "on", "once", "only", "or", "other", "ought",
    "our", "ours", "ourselves", "out", "over", "own", "same", "shan't",
    "she", "she'd", "she'll", "she's", "should", "shouldn't", "so", "some",
    "such", "than", "that", "that's", "the", "their", "theirs", "them",
    "themselves", "then", "there", "there's", "these", "they", "they'd",
    "they'll", "they're", "they've", "this", "those", "through", "to",
    "too", "under", "until", "up", "very", "was", "wasn't", "we", "we'd",
    "we'll", "we're", "we've", "were", "weren't", "what", "what's", "when",
    "when's", "where", "where's", "which", "while", "who", "who's", "whom",
    "why", "why's", "with", "won't", "wouldn't", "you", "you'd", "you'll",
    "you're", "you've", "your", "yours", "yourself", "yourselves",
}


def canonicalize_claim(text: str, domain: str) -> str:
    """Return a stable canonical form for claim deduplication.

    Applies:
    1. Lowercase
    2. Strip punctuation
    3. Collapse whitespace
    4. Remove stopwords
    5. Sort tokens alphabetically (loses word order but captures content identity)
    6. Prepend domain:

    Args:
        text: Raw claim text.
        domain: Claim domain (e.g., "health", "politics").

    Returns:
        Canonical form: "domain:token1 token2 ..." (alphabetically sorted).
    """
    # Lowercase
    text = text.lower()

    # Remove punctuation: replace all punctuation with space
    text = text.translate(str.maketrans(string.punctuation, " " * len(string.punctuation)))

    # Collapse whitespace
    tokens = text.split()

    # Remove stopwords and filter empty strings
    filtered = [t for t in tokens if t and t not in _STOPWORDS]

    # Sort alphabetically
    sorted_tokens = sorted(filtered)

    # Prepend domain (also lowercased)
    canonical = f"{domain.lower()}:{' '.join(sorted_tokens)}"
    return canonical


def claim_id_for(text: str, domain: str) -> str:
    """Return a deterministic 16-char hex claim ID.

    Args:
        text: Raw claim text.
        domain: Claim domain.

    Returns:
        sha256(canonicalize_claim(text, domain))[:16] as hex.
    """
    canonical = canonicalize_claim(text, domain)
    digest = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
    return digest[:16]


class ClaimCache:
    """LRU cache keyed on canonical claim form, returning claim IDs.

    Attributes:
        _max_entries: Maximum number of entries before LRU eviction.
        _cache: OrderedDict mapping canonical form to (claim_id, cached_at).
        _hits: Count of cache hits.
        _misses: Count of cache misses.
    """

    def __init__(self, max_entries: int = 10_000) -> None:
        """Initialize the cache.

        Args:
            max_entries: Maximum number of entries before LRU eviction.
        """
        self._max_entries = max_entries
        self._cache: OrderedDict[str, tuple[str, float]] = OrderedDict()
        self._hits = 0
        self._misses = 0

    def get(self, text: str, domain: str) -> str | None:
        """Return the cached claim_id if this text+domain has been seen.

        Args:
            text: Raw claim text.
            domain: Claim domain.

        Returns:
            The cached claim_id, or None if not found.
        """
        canonical = canonicalize_claim(text, domain)
        if canonical in self._cache:
            claim_id, _cached_at = self._cache[canonical]
            # Move to end for LRU
            self._cache.move_to_end(canonical)
            self._hits += 1
            return claim_id
        self._misses += 1
        return None

    def put(self, text: str, domain: str) -> str:
        """Register the claim and return its canonical id.

        Idempotent: registering the same canonical form twice returns the same id.
        Evicts oldest entry if max_entries is exceeded.

        Args:
            text: Raw claim text.
            domain: Claim domain.

        Returns:
            The canonical claim_id.
        """
        canonical = canonicalize_claim(text, domain)
        if canonical in self._cache:
            claim_id, _ = self._cache[canonical]
            # Move to end for LRU
            self._cache.move_to_end(canonical)
            return claim_id

        # Generate new claim_id
        claim_id = claim_id_for(text, domain)
        self._cache[canonical] = (claim_id, time.time())

        # Evict oldest if necessary
        if len(self._cache) > self._max_entries:
            self._cache.popitem(last=False)

        return claim_id

    def stats(self) -> dict:
        """Return cache statistics.

        Returns:
            Dictionary with keys: 'entries', 'hits', 'misses'.
        """
        return {
            "entries": len(self._cache),
            "hits": self._hits,
            "misses": self._misses,
        }
