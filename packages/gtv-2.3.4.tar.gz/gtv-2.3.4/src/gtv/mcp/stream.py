# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Server-Sent Event types for the streaming verify_claim endpoint (W33).

The streaming endpoint emits a sequence of typed events so callers can
react before the final sealed envelope is ready:

  1. ``claim_accepted`` — request was admitted; classification known.
  2. ``evidence`` — one event per adapter that returned (in completion
     order, not registration order).
  3. ``verdict`` — verdict engine decision, before signing/anchoring.
  4. ``envelope`` — terminal: the sealed envelope. Stream closes after.
  5. ``error`` — terminal: non-recoverable failure. Stream closes after.

Each event is sent on the wire as::

    event: <phase>
    data: <json payload>
    \n

Pydantic models are used so the JSON shape is generated and validated
the same way as the rest of the API surface.
"""

from __future__ import annotations

import json
from typing import Literal

from pydantic import BaseModel

from gtv.models import Envelope, Evidence


class StreamClaimAccepted(BaseModel):
    """First event: server has accepted the claim and started work."""

    phase: Literal["claim_accepted"] = "claim_accepted"
    claim_id: str
    classification: str
    issuer_did: str


class StreamEvidence(BaseModel):
    """Per-adapter evidence event, emitted in completion order."""

    phase: Literal["evidence"] = "evidence"
    source_did: str
    status: Literal["ok", "timeout", "error"]
    elapsed_ms: float
    items: list[Evidence]


class StreamVerdict(BaseModel):
    """Verdict engine decision, before anchoring/signing."""

    phase: Literal["verdict"] = "verdict"
    verdict: str
    confidence: float
    rationale: str
    evidence_count: int


class StreamEnvelope(BaseModel):
    """Terminal: the sealed envelope with signatures + anchors."""

    phase: Literal["envelope"] = "envelope"
    envelope: Envelope


class StreamError(BaseModel):
    """Terminal: non-recoverable failure mid-stream."""

    phase: Literal["error"] = "error"
    detail: str


StreamEvent = (
    StreamClaimAccepted
    | StreamEvidence
    | StreamVerdict
    | StreamEnvelope
    | StreamError
)


def encode_sse(event: StreamEvent) -> bytes:
    """Encode a stream event in the Server-Sent Events wire format.

    Returns a bytes buffer that can be yielded directly from a
    ``StreamingResponse`` body. Includes the trailing blank line that
    separates events.
    """
    payload = event.model_dump(mode="json")
    body = json.dumps(payload, separators=(",", ":"))
    return f"event: {event.phase}\ndata: {body}\n\n".encode()
