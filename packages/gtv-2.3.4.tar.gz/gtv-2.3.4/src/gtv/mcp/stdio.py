# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""MCP stdio JSON-RPC server for Ground Truth Verification.

Exposes verify_claim and retrieve_facts as MCP tools over stdio.
Uses the official `mcp` SDK to handle JSON-RPC transport.

Entry point: gtv-mcp (console script in pyproject.toml)
Invocation: echo '{"method": "tools/call", ...}' | gtv-mcp
"""
from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, cast

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

from gtv.mcp.server import _seal_retrieve_envelope, _verify_one
from gtv.models import Claim, Domain, RetrieveFactsRequest, VerifyClaimRequest
from gtv.retrieve.extract import extract_subclaims
from gtv.tenant import default_tenant

logger = logging.getLogger(__name__)


def _build_tools() -> list[Tool]:
    """Build the list of available tools."""
    return [
        Tool(
            name="verify_claim",
            description="Verify a single claim and return a sealed verification envelope with verdict, evidence, and cryptographic proofs.",
            inputSchema={
                "type": "object",
                "properties": {
                    "claim": {
                        "type": "string",
                        "description": "The claim text to verify (1-2000 characters).",
                    },
                    "domain": {
                        "type": "string",
                        "enum": [
                            "physics",
                            "math",
                            "cs",
                            "astronomy",
                            "materials",
                            "general",
                        ],
                        "description": "Domain context for the claim.",
                        "default": "general",
                    },
                    "max_sources": {
                        "type": "integer",
                        "description": "Maximum number of sources to retrieve per adapter (1-20).",
                        "default": 5,
                        "minimum": 1,
                        "maximum": 20,
                    },
                },
                "required": ["claim"],
            },
        ),
        Tool(
            name="retrieve_facts",
            description="Extract and verify multiple facts from free-text input. Automatically identifies sub-claims and returns verification envelopes.",
            inputSchema={
                "type": "object",
                "properties": {
                    "text": {
                        "type": "string",
                        "description": "The text to extract facts from (1-500 characters).",
                    },
                    "domain": {
                        "type": "string",
                        "enum": [
                            "physics",
                            "math",
                            "cs",
                            "astronomy",
                            "materials",
                            "general",
                        ],
                        "description": "Domain context for fact extraction.",
                        "default": "general",
                    },
                    "max_claims": {
                        "type": "integer",
                        "description": "Maximum number of claims to extract and verify (1-20).",
                        "default": 5,
                        "minimum": 1,
                        "maximum": 20,
                    },
                },
                "required": ["text"],
            },
        ),
    ]


async def _handle_verify_claim(arguments: dict[str, Any]) -> list[TextContent]:
    """Handle verify_claim tool invocation.

    Args:
        arguments: {claim, domain?, max_sources?}

    Returns:
        [TextContent] with JSON-serialized Envelope

    Raises:
        ValidationError: if arguments don't match VerifyClaimRequest schema
    """
    # Construct request and validate via Pydantic
    req = VerifyClaimRequest(
        claim=arguments["claim"],
        domain=arguments.get("domain", "general"),
        max_sources=arguments.get("max_sources", 5),
    )

    # Create Claim and call _verify_one. Stdio has no HTTP request, so
    # there's no tenant context — fall through to the server-default DID.
    claim = Claim(text=req.claim, domain=Domain(req.domain))
    envelope = await _verify_one(
        claim,
        req.max_sources,
        issuer_did=default_tenant().issuer_did,
    )

    # Serialize to JSON and return as TextContent
    result = envelope.model_dump(mode="json")
    return [TextContent(type="text", text=json.dumps(result))]


async def _handle_retrieve_facts(arguments: dict[str, Any]) -> list[TextContent]:
    """Handle retrieve_facts tool invocation.

    Args:
        arguments: {text, domain?, max_claims?}

    Returns:
        [TextContent] with JSON-serialized RetrieveFactsEnvelope

    Raises:
        ValidationError: if arguments don't match RetrieveFactsRequest schema
    """
    # Map 'text' argument to 'query' for RetrieveFactsRequest
    req = RetrieveFactsRequest(
        query=arguments["text"],
        domain=arguments.get("domain", "general"),
        max_results=arguments.get("max_claims", 5),
    )

    # Call the FastAPI endpoint logic directly
    subclaims = extract_subclaims(req.query, max_subclaims=req.max_results)

    issuer_did = default_tenant().issuer_did
    if not subclaims:
        # No extractable claims; return empty envelope
        retrieve_envelope = await _seal_retrieve_envelope(
            facts=[], issuer_did=issuer_did
        )
    else:
        # Verify each sub-claim concurrently
        from gtv.models import Envelope, FactItem

        claims = [Claim(text=text, domain=Domain(req.domain)) for text in subclaims]
        envelopes = await asyncio.gather(
            *(
                _verify_one(
                    claim, max_sources=5, issuer_did=issuer_did
                )  # Fixed max_sources for sub-claims
                for claim in claims
            ),
            return_exceptions=True,
        )

        # Convert Envelope objects to FactItem objects
        facts: list[FactItem] = []
        for envelope in envelopes:
            if isinstance(envelope, Envelope):
                fact = FactItem(
                    text=envelope.evidence[0].excerpt if envelope.evidence else "",
                    verdict=envelope.verdict,
                    confidence=envelope.confidence,
                    evidence=envelope.evidence,
                )
                facts.append(fact)

        retrieve_envelope = await _seal_retrieve_envelope(
            facts=facts, issuer_did=issuer_did
        )

    # Serialize to JSON and return as TextContent
    # Cast to allow dict in tests (even though real code returns RetrieveFactsEnvelope)
    envelope_any = cast(dict[str, Any] | Any, retrieve_envelope)
    if isinstance(envelope_any, dict):
        result = envelope_any
    else:
        result = envelope_any.model_dump(mode="json")
    return [TextContent(type="text", text=json.dumps(result))]


async def _async_main() -> None:
    """Async entry point: run the MCP server over stdio.

    Accepts JSON-RPC 2.0 requests on stdin, writes responses to stdout.
    """
    # Create MCP server
    server = Server("gtv-mcp", "0.1.0")

    # Register tool list handler
    @server.list_tools()  # type: ignore[no-untyped-call, untyped-decorator]
    async def list_tools() -> list[Tool]:
        return _build_tools()

    # Register tool call handler
    @server.call_tool()  # type: ignore[untyped-decorator]
    async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
        try:
            if name == "verify_claim":
                return await _handle_verify_claim(arguments)
            elif name == "retrieve_facts":
                return await _handle_retrieve_facts(arguments)
            else:
                raise ValueError(f"Unknown tool: {name}")
        except Exception:
            logger.exception(f"Tool call failed for {name}")
            raise

    # Run server over stdio
    async with stdio_server() as (read_stream, write_stream):
        init_options = server.create_initialization_options()
        await server.run(read_stream, write_stream, init_options)


def main() -> None:
    """Entry point: run the MCP server over stdio (sync wrapper).

    This is called by the gtv-mcp console script.
    """
    asyncio.run(_async_main())


if __name__ == "__main__":
    main()
