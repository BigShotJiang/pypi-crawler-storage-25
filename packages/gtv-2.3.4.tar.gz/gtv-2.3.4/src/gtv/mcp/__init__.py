# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""MCP tool surface — FastAPI app + tool handlers."""
