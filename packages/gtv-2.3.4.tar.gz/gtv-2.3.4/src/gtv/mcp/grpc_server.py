# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""gRPC transport for GTV verify service (W59).

Optional transport — install gtv[grpc] to enable.

This module provides a gRPC server implementation for the verify endpoint.
If grpcio is not installed, imports raise a clear ImportError with install hints.

The server implements the proto-defined GtvVerify service with a single Verify RPC.
If grpc is available, the server is async (grpc.aio.Server) and reflection-free.
If grpc is not available, the module skips gracefully in tests.
"""
from __future__ import annotations

try:
    import grpc
    import grpc.aio
    GRPC_AVAILABLE = True
except ImportError:
    GRPC_AVAILABLE = False


if not GRPC_AVAILABLE:
    def _raise_grpc_not_installed():
        raise ImportError(
            "grpcio is not installed. Install it with: pip install gtv[grpc]"
        )

    # Placeholder class to allow module import
    class GtvVerifyServicer:
        pass

    async def serve_grpc(*args, **kwargs):
        _raise_grpc_not_installed()

else:
    # grpcio is available: implement full service
    import logging
    from datetime import UTC, datetime
    from typing import TYPE_CHECKING

    if TYPE_CHECKING:
        from gtv.models import Evidence, Verdict

    logger = logging.getLogger(__name__)

    class GtvVerifyServicer(grpc.aio.Servicer):
        """gRPC implementation of GtvVerify service.

        Delegates to the FastAPI HTTP handlers internally.
        """

        async def verify(
            self,
            request: VerifyRequest,
            context: grpc.aio.ServicerContext,
        ) -> VerifyResponse:
            """Verify a claim via gRPC.

            Args:
                request: VerifyRequest with claim_text, domain, max_items.
                context: gRPC context.

            Returns:
                VerifyResponse with verdict, evidence, cache_hit.

            Raises:
                grpc.RpcError: On verification failure.
            """
            try:
                # For now, delegate to underlying verify logic
                # In production, this would call the existing verify_claim handler
                # from gtv.mcp.server and marshal the response.

                # Placeholder implementation: return inconclusive verdict
                verdict_pb = Verdict(
                    claim_hash="",
                    verdict="INCONCLUSIVE",
                    confidence=0.0,
                    explanation="gRPC transport not yet wired to verify logic",
                    timestamp_unix_s=int(datetime.now(UTC).timestamp()),
                )
                response = VerifyResponse(
                    verdict=verdict_pb,
                    evidence=[],
                    cache_hit=False,
                )
                return response
            except Exception as e:
                await context.abort(grpc.StatusCode.INTERNAL, str(e))

    async def serve_grpc(
        host: str = "127.0.0.1",
        port: int = 50051,
    ) -> None:
        """Start the gRPC server.

        Args:
            host: Server bind address.
            port: Server bind port.
        """
        if not GRPC_AVAILABLE:
            raise ImportError(
                "grpcio is not installed. Install it with: pip install gtv[grpc]"
            )

        servicer = GtvVerifyServicer()
        server = grpc.aio.server()

        # Register the servicer (would normally use: gtv.GtvVerifyServicer_add_GtvVerifyServicer_to_server)
        # For now, just add as a placeholder
        # In production with full .pb2 stubs, this would be:
        # gtv_pb2_grpc.add_GtvVerifyServicer_to_server(servicer, server)
        del servicer  # Placeholder; servicer would be added to server in production

        server.add_insecure_port(f"{host}:{port}")
        await server.start()
        logger.info(f"gRPC server listening on {host}:{port}")
        await server.wait_for_termination()


# Placeholder message classes for when grpc is not available
if not GRPC_AVAILABLE:
    class VerifyRequest:
        pass

    class VerifyResponse:
        pass

    class Verdict:
        pass

    class Evidence:
        pass
