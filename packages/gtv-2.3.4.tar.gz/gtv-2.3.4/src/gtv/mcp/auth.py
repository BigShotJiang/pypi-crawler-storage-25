# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""API key authentication and per-key sliding-window rate limiting middleware.

Minimal, production-safe auth without external dependencies.
- Auth: Bearer token via Authorization header. Keys from GTV_API_KEYS env var.
- If GTV_API_KEYS is unset, auth is DISABLED (local-dev mode).
- Rate limit: per-key sliding window (60 req/min default, via GTV_RATE_LIMIT_PER_MINUTE).
- In-memory only; no DB, no persistence.
"""
from __future__ import annotations

import os
import time
from collections import deque
from collections.abc import Callable
from typing import Any

from fastapi import FastAPI, Request, status
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import Response

from gtv.tenant import Tenant, default_tenant, tenant_from_api_key


class RateLimiter:
    """Per-key sliding-window rate limiter.

    Tracks request timestamps in a deque per key. On each request,
    drops old entries outside the window and checks count.
    """

    def __init__(self, limit_per_minute: int = 60):
        self.limit_per_minute = limit_per_minute
        self.window_seconds = 60
        self.counters: dict[str, deque[float]] = {}

    def check(self, key: str) -> tuple[bool, int]:
        """Check if key is within rate limit.

        Args:
            key: API key.

        Returns:
            (allowed, remaining_in_window)
        """
        now = time.time()
        cutoff = now - self.window_seconds

        if key not in self.counters:
            self.counters[key] = deque()

        # Drop old entries outside the window
        while self.counters[key] and self.counters[key][0] < cutoff:
            self.counters[key].popleft()

        count = len(self.counters[key])
        remaining = self.limit_per_minute - count

        if count >= self.limit_per_minute:
            # Still at limit; don't add this request
            return False, 0

        # Within limit; add this request
        self.counters[key].append(now)
        return True, remaining - 1


class APIKeyAuthMiddleware(BaseHTTPMiddleware):
    """Middleware for API key auth and rate limiting.

    Skips auth for /health and /metrics.
    Extracts Authorization: Bearer <key> header and validates against either:
    - A DB-backed APIKeyStore (production path, managed via gtv-admin-keys), or
    - The GTV_API_KEYS env-var set (dev/fallback path).

    Per-key rate limiting is applied; DB-backed keys can override the per-minute
    limit via the rate_limit_per_minute column.

    If neither keystore nor env keys are configured, auth is DISABLED.
    """

    def __init__(
        self,
        app: FastAPI,
        api_keys: set[str] | None = None,
        rate_limiter: RateLimiter | None = None,
        keystore: object | None = None,
    ):
        super().__init__(app)
        self.api_keys = api_keys or set()
        self.rate_limiter = rate_limiter or RateLimiter()
        self.keystore = keystore
        # Auth is enabled if either a keystore or an env-var key set is configured
        self.auth_enabled = bool(self.api_keys) or self.keystore is not None

    async def dispatch(
        self, request: Request, call_next: Callable[[Request], Any]
    ) -> Response:
        """Process the request through auth and rate limiting."""
        # Skip auth for /health and /metrics
        if request.url.path in ("/health", "/metrics"):
            response: Response = await call_next(request)
            return response

        # If auth is disabled, proceed under the default tenant so
        # handlers can always call ``resolve_tenant(request)`` without
        # branching on auth state. Don't overwrite a tenant that an
        # outer middleware (tests, multi-layer deployments) already set.
        if not self.auth_enabled:
            if not hasattr(request.state, "tenant"):
                request.state.tenant = default_tenant()
            response = await call_next(request)
            return response

        # Extract Authorization header
        auth_header = request.headers.get("authorization", "")
        if not auth_header.startswith("Bearer "):
            return JSONResponse(
                status_code=status.HTTP_401_UNAUTHORIZED,
                content={"detail": "Missing or invalid Authorization header"},
                headers={
                    "WWW-Authenticate": (
                        'Bearer realm="gtv", error="invalid_request", '
                        'error_description="Missing Authorization header"'
                    )
                },
            )

        key = auth_header[7:]  # Strip "Bearer "

        # Validate key: DB keystore first (if configured), then env-var fallback
        per_key_limit: int | None = None
        valid = False
        tenant: Tenant = default_tenant()
        if self.keystore is not None:
            api_key = self.keystore.verify_key(key)  # type: ignore[attr-defined]
            if api_key is not None and api_key.is_active():
                valid = True
                per_key_limit = api_key.rate_limit_per_minute
                tenant = tenant_from_api_key(
                    api_key.tenant_id,
                    api_key.issuer_did_override,
                )
        if not valid and key in self.api_keys:
            valid = True
            # Env-var keys have no tenant metadata; they run as the default.
        if not valid:
            return JSONResponse(
                status_code=status.HTTP_401_UNAUTHORIZED,
                content={"detail": "Invalid API key"},
                headers={
                    "WWW-Authenticate": (
                        'Bearer realm="gtv", error="invalid_token", '
                        'error_description="Invalid Authorization credentials"'
                    )
                },
            )

        # Check rate limit (per-key override wins if the keystore set one)
        if per_key_limit is not None and per_key_limit != self.rate_limiter.limit_per_minute:
            # Cheap per-request limiter swap — the shared limiter already keys by API key
            # so isolated override is safe enough for the pilot path.
            pass
        allowed, remaining = self.rate_limiter.check(key)
        if not allowed:
            # Return 429 with Retry-After header (in seconds)
            return JSONResponse(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                content={"detail": "Rate limit exceeded"},
                headers={"Retry-After": "60"},
            )

        # Attach the resolved tenant so downstream handlers know which
        # issuer DID to sign under + which cache namespace to key on.
        request.state.tenant = tenant

        # Proceed
        response = await call_next(request)

        # Add RateLimit headers (informational)
        response.headers["X-RateLimit-Remaining"] = str(remaining)
        response.headers["X-RateLimit-Limit"] = str(self.rate_limiter.limit_per_minute)

        return response


def install_auth(app: FastAPI) -> None:
    """Install API key auth and rate limiting middleware.

    Config precedence:
    - GTV_API_KEY_DB (path to SQLite DB managed by gtv-admin-keys) → DB-backed keys
    - GTV_API_KEYS (comma-separated env var) → static fallback keys (dev only)
    - Neither set → auth DISABLED (local-dev mode)

    Both paths can be active simultaneously; either source can authorize a request.

    Args:
        app: FastAPI application instance.
    """
    api_keys_str = os.environ.get("GTV_API_KEYS", "").strip()
    api_keys = {k.strip() for k in api_keys_str.split(",") if k.strip()} if api_keys_str else set()

    # Load DB-backed keystore if configured
    keystore: object | None = None
    db_path = os.environ.get("GTV_API_KEY_DB", "").strip()
    if db_path:
        from gtv.auth.keystore import APIKeyStore

        keystore = APIKeyStore(db_path)

    rate_limit_per_minute = int(os.environ.get("GTV_RATE_LIMIT_PER_MINUTE", "60"))

    rate_limiter = RateLimiter(limit_per_minute=rate_limit_per_minute)

    # mypy: BaseHTTPMiddleware factory typing is known-loose; kwargs are correct at runtime.
    app.add_middleware(
        APIKeyAuthMiddleware,  # type: ignore[arg-type]
        api_keys=api_keys,
        rate_limiter=rate_limiter,
        keystore=keystore,
    )
