# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""gRPC client for GTV verify service (W59).

Optional transport — install gtv[grpc] to enable.

This module provides a gRPC client for connecting to the verify service.
If grpcio is not installed, imports raise a clear ImportError with install hints.
"""
from __future__ import annotations

try:
    import grpc
    import grpc.aio
    GRPC_AVAILABLE = True
except ImportError:
    GRPC_AVAILABLE = False


if not GRPC_AVAILABLE:
    def _raise_grpc_not_installed():
        raise ImportError(
            "grpcio is not installed. Install it with: pip install gtv[grpc]"
        )

    class GtvVerifyClient:
        """Placeholder client when grpc is not installed."""

        def __init__(self, *args, **kwargs):
            _raise_grpc_not_installed()

else:
    # grpcio is available: implement full client
    class GtvVerifyClient:
        """Async gRPC client for GtvVerify service.

        Usage:
            async with GtvVerifyClient("localhost:50051") as client:
                response = await client.verify(
                    claim_text="...",
                    domain="physics",
                    max_items=10,
                )
        """

        def __init__(self, target: str):
            """Initialize client with server address.

            Args:
                target: Server address (e.g., "localhost:50051").
            """
            self.target = target
            self.channel = None
            self.stub = None

        async def __aenter__(self):
            """Context manager entry: create channel and stub."""
            self.channel = grpc.aio.secure_channel(
                self.target,
                grpc.ssl_channel_credentials(),
            ) if "localhost" not in self.target else grpc.aio.insecure_channel(
                self.target
            )
            # Stub creation would happen here with: gtv_pb2_grpc.GtvVerifyStub(self.channel)
            # For now, placeholder
            return self

        async def __aexit__(self, exc_type, exc_val, exc_tb):
            """Context manager exit: close channel."""
            if self.channel:
                await self.channel.close()

        async def verify(
            self,
            claim_text: str,
            domain: str,
            max_items: int = 10,
        ):
            """Verify a claim via gRPC.

            Args:
                claim_text: Claim to verify.
                domain: Evidence domain.
                max_items: Maximum evidence items to return.

            Returns:
                VerifyResponse with verdict, evidence, cache_hit.

            Raises:
                grpc.RpcError: On server error.
            """
            if not GRPC_AVAILABLE:
                raise ImportError(
                    "grpcio is not installed. Install it with: pip install gtv[grpc]"
                )

            if not self.stub:
                raise RuntimeError(
                    "Client not initialized. Use 'async with GtvVerifyClient(...) as client:'"
                )

            # Would normally construct VerifyRequest with: request = VerifyRequest(...)
            # and call: return await self.stub.Verify(request)
            # For now, placeholder
            raise NotImplementedError(
                "gRPC client stub not wired. Full implementation requires .pb2 stubs."
            )
