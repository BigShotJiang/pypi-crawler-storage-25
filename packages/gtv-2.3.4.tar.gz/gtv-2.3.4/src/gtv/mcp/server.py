# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""FastAPI app exposing the two MCP tools: verify_claim and retrieve_facts.

The MCP wire protocol is not bolted on here — this app exposes HTTP JSON
endpoints that the MCP adapter (Phase 1 week 6) marshals into tool calls.
Keeping that boundary thin means the verdict logic can be tested without
any MCP machinery.
"""
from __future__ import annotations

import asyncio
import base64
import contextlib
import logging
import time
from collections.abc import AsyncIterator
from datetime import UTC, datetime

from fastapi import FastAPI, HTTPException, Request, status
from fastapi.responses import StreamingResponse
from prometheus_client import make_asgi_app
from pydantic import BaseModel

from gtv import __version__ as _gtv_version
from gtv.adapters import REGISTRY
from gtv.adapters.base import SourceAdapter
from gtv.anchor.canonicalize import envelope_canonical_sha256
from gtv.anchor.sign import sign_hash
from gtv.anchor.tsa import RFC3161Client
from gtv.billing import record_usage
from gtv.cache import build_key, make_cache_from_env
from gtv.federation.backpressure import (
    BackpressureMonitor,
    backpressure_header_middleware,
)
from gtv.federation.consensus import compute_consensus
from gtv.federation.dos_protection import (
    PeerRateLimiter,
    federation_rate_limit_middleware,
)
from gtv.federation.peer import fetch_peer_envelope, load_peers_from_env
from gtv.federation.provenance import build_aggregate_envelope
from gtv.lifecycle import LifecycleError, make_index_from_env
from gtv.managed.api import router as managed_router
from gtv.mcp.auth import install_auth
from gtv.mcp.stream import (
    StreamClaimAccepted,
    StreamEnvelope,
    StreamError,
    StreamEvent,
    StreamEvidence,
    StreamVerdict,
    encode_sse,
)
from gtv.models import (
    AnchorProof,
    Claim,
    Domain,
    Envelope,
    Evidence,
    FactItem,
    RetrieveFactsEnvelope,
    RetrieveFactsRequest,
    SupersedeReason,
    Verdict,
    VerdictRecord,
    VerifyClaimRequest,
)
from gtv.obs.metrics import (
    CACHE_HITS,
    CACHE_INVALIDATIONS,
    CACHE_MISSES,
    REDACTIONS_REJECTED,
    REDACTIONS_TOTAL,
    TENANT_REQUESTS,
    record_adapter_call,
    record_verdict,
)
from gtv.obs.tracing import init_tracing
from gtv.policy import load_policy_from_env
from gtv.prov import build_prov_graph
from gtv.redact import contains_pii, redact_envelope_fields
from gtv.retrieve.extract import extract_subclaims
from gtv.revocation.check import is_revoked
from gtv.revocation.loader import load_revocation_lists_from_env
from gtv.telemetry import install_telemetry
from gtv.tenant import resolve_tenant
from gtv.verdict import decide
from gtv.verdict.classify import ClaimClass, classify
from gtv.verdict.engine import VerdictInputs

logger = logging.getLogger(__name__)

app = FastAPI(
    title="Ground Truth Verification System", version=_gtv_version
)

# Initialize OpenTelemetry tracing
init_tracing(app)

# Install API key auth and rate limiting middleware
install_auth(app)

# Install pilot telemetry (structured logging + Prometheus request metrics)
install_telemetry(app)

# Federation middleware: backpressure signal + per-peer rate limiting.
# These only act on /federation/* paths (dispatch check inside each middleware).
# Monitors are module-globals so the replicator and peer-trust layers can
# update them; they're wired up lazily when those subsystems initialize.
_BACKPRESSURE_MONITOR = BackpressureMonitor()
backpressure_header_middleware(app, _BACKPRESSURE_MONITOR)
_PEER_RATE_LIMITER = PeerRateLimiter()
federation_rate_limit_middleware(app, _PEER_RATE_LIMITER)

# Mount Prometheus metrics endpoint
app.mount("/metrics", make_asgi_app())

# Managed control plane (tenant CRUD, quotas, usage) — X-Admin-Key auth.
app.include_router(managed_router)

# Load revocation lists at module init (cached, not per-request)
_REVOCATION_LISTS = load_revocation_lists_from_env()

# Signed verdict cache — zero-trust, re-validates envelopes on read.
# See src/gtv/cache/verdict.py.
_VERDICT_CACHE = make_cache_from_env()

# Claim lifecycle index — tracks amend/supersede/withdraw links between
# envelopes so /claims/{id}/history and /claims/latest can walk the DAG.
# See src/gtv/lifecycle/index.py.
_LIFECYCLE = make_index_from_env()

# Consensus policy — operator-authored YAML that tunes verdict
# thresholds / tier weights / confidence formula. Loaded from
# GTV_POLICY_PATH; defaults to the legacy hardcoded constants if
# unset. See src/gtv/policy/.
_POLICY = load_policy_from_env()


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok"}


class EnvelopeResponse(BaseModel):
    envelope: Envelope


async def _verify_one_events(
    claim: Claim,
    max_sources: int,
    *,
    issuer_did: str,
) -> AsyncIterator[StreamEvent]:
    """Async generator: drive the verify pipeline yielding phase events.

    Phases (in order):
      1. ``claim_accepted`` — classification known; work has started.
      2. ``evidence`` — one event per adapter, in completion order
         (only emitted for FACTUAL claims that fan out to adapters).
      3. ``verdict`` — verdict engine decision, before anchoring.
      4. ``envelope`` — sealed envelope. Always the terminal event for
         a successful run.

    This generator is the source of truth. ``_verify_one`` is a thin
    wrapper that drains it and returns the final envelope, so the
    streaming and non-streaming endpoints share the exact same
    pipeline (no drift, no duplicated logic).
    """
    start_time = time.perf_counter()

    # Short-circuit: classify claim before adapter fan-out.
    claim_class = classify(claim)

    yield StreamClaimAccepted(
        claim_id=claim.claim_id,
        classification=claim_class.value,
        issuer_did=issuer_did,
    )

    # Non-FACTUAL classes skip adapter fan-out and verdict engine;
    # short-circuit straight to envelope.
    short_circuit_table = {
        ClaimClass.OPINION: (
            Verdict.OPINION,
            0.9,
            "Classified as opinion / subjective interpretation; no factual verification performed.",
        ),
        ClaimClass.CREATIVE: (
            Verdict.CREATIVE,
            0.99,
            "Marked as creative output; no factual verification performed.",
        ),
        ClaimClass.OUT_OF_SCOPE: (
            Verdict.OUT_OF_SCOPE,
            0.8,
            "Out of scope for this service; no factual verification performed.",
        ),
    }

    if claim_class in short_circuit_table:
        decision, conf, rationale = short_circuit_table[claim_class]
        record = VerdictRecord(
            claim_id=claim.claim_id,
            decision=decision,
            confidence=conf,
            evidence_refs=[],
            rationale=rationale,
        )
        yield StreamVerdict(
            verdict=decision.value,
            confidence=conf,
            rationale=rationale,
            evidence_count=0,
        )
        envelope = await _seal_envelope(
            claim=claim,
            verdict=record.decision,
            confidence=record.confidence,
            evidence=[],
            rationale=record.rationale,
            verdict_record=record,
            issuer_did=issuer_did,
        )
        elapsed = time.perf_counter() - start_time
        record_verdict(record.decision, elapsed, 0)
        yield StreamEnvelope(envelope=envelope)
        return

    # FACTUAL claims fan out to adapters. Use as_completed so the
    # streaming endpoint can emit per-adapter events in completion
    # order rather than waiting for the slowest adapter.
    adapters = list(REGISTRY.values())

    async def timed_adapter_query(
        adapter: SourceAdapter,
    ) -> tuple[SourceAdapter, str, float, list[Evidence]]:
        """Run an adapter, recording metrics. Returns a tagged tuple.

        Returns ``(adapter, status, elapsed_s, items)`` so the caller
        can emit a per-adapter SSE event without re-deriving the
        adapter identity. Errors are surfaced via the status string
        and an empty items list — the streaming layer should not
        crash on a single adapter failure.
        """
        adapter_start = time.perf_counter()
        try:
            result = await adapter.query(claim, max_items=max_sources)
            elapsed = time.perf_counter() - adapter_start
            record_adapter_call(adapter.source_did, "ok", elapsed)
            return adapter, "ok", elapsed, result
        except TimeoutError:
            elapsed = time.perf_counter() - adapter_start
            record_adapter_call(adapter.source_did, "timeout", elapsed)
            return adapter, "timeout", elapsed, []
        except Exception:
            elapsed = time.perf_counter() - adapter_start
            record_adapter_call(adapter.source_did, "error", elapsed)
            return adapter, "error", elapsed, []

    evidence: list[Evidence] = []
    pending = [
        asyncio.create_task(timed_adapter_query(a)) for a in adapters
    ]
    for coro in asyncio.as_completed(pending):
        adapter, status_str, elapsed_s, items = await coro
        evidence.extend(items)
        yield StreamEvidence(
            source_did=adapter.source_did,
            status=status_str,
            elapsed_ms=elapsed_s * 1000.0,
            items=items,
        )

    record = decide(
        VerdictInputs(
            claim=claim,
            evidence=evidence,
            tier_of={a.source_did: a.trust_tier for a in adapters},
        ),
        _POLICY,
    )

    yield StreamVerdict(
        verdict=record.decision.value,
        confidence=record.confidence,
        rationale=record.rationale,
        evidence_count=len(evidence),
    )

    envelope = await _seal_envelope(
        claim=claim,
        verdict=record.decision,
        confidence=record.confidence,
        evidence=evidence,
        rationale=record.rationale,
        verdict_record=record,
        issuer_did=issuer_did,
    )
    elapsed = time.perf_counter() - start_time
    record_verdict(record.decision, elapsed, len(evidence))
    yield StreamEnvelope(envelope=envelope)


async def _verify_one(
    claim: Claim,
    max_sources: int,
    *,
    issuer_did: str,
) -> Envelope:
    """Verify a single claim and return a sealed Envelope.

    Thin wrapper over ``_verify_one_events`` that drains the generator
    and returns the terminal envelope. Used by the non-streaming
    ``verify_claim`` and ``retrieve_facts`` endpoints, plus internal
    callers (subscribe engine, stdio bridge).
    """
    final: Envelope | None = None
    async for ev in _verify_one_events(
        claim, max_sources, issuer_did=issuer_did
    ):
        if isinstance(ev, StreamEnvelope):
            final = ev.envelope
    if final is None:  # pragma: no cover - generator invariant
        raise RuntimeError(
            "_verify_one_events terminated without an envelope event"
        )
    return final


@app.post("/tools/verify_claim", response_model=EnvelopeResponse)
async def verify_claim(
    req: VerifyClaimRequest, request: Request
) -> EnvelopeResponse:
    if not REGISTRY:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="No source adapters registered.",
        )

    # Input-side PII gate. Redacting a user-submitted claim silently
    # would break caching and mislead the caller ("did gtv verify what
    # I asked about or something else?"); reject with 400 instead.
    if contains_pii(req.claim):
        REDACTIONS_REJECTED.inc()
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Claim contains personally identifiable information; "
            "please re-submit with the PII removed.",
        )

    tenant = resolve_tenant(request)
    issuer_did = tenant.issuer_did
    cache_key = build_key(
        claim_text=req.claim,
        domain=req.domain,
        max_sources=req.max_sources,
        issuer_did=issuer_did,
    )
    prior_sig_rejections = _VERDICT_CACHE.stats.signature_rejections
    prior_deserialize_errors = _VERDICT_CACHE.stats.deserialize_errors

    cached = await _VERDICT_CACHE.get(cache_key)
    stats = _VERDICT_CACHE.stats
    # Record any invalidations that just happened on the read path.
    if stats.signature_rejections > prior_sig_rejections:
        CACHE_INVALIDATIONS.labels(reason="signature_mismatch").inc(
            stats.signature_rejections - prior_sig_rejections
        )
    if stats.deserialize_errors > prior_deserialize_errors:
        CACHE_INVALIDATIONS.labels(reason="deserialize_error").inc(
            stats.deserialize_errors - prior_deserialize_errors
        )

    if cached is not None:
        CACHE_HITS.labels(tool="verify_claim").inc()
        envelope = cached
    else:
        CACHE_MISSES.labels(tool="verify_claim").inc()
        claim = Claim(text=req.claim, domain=req.domain)
        envelope = await _verify_one(
            claim, req.max_sources, issuer_did=issuer_did
        )
        # Register as a root in the lifecycle index so subsequent
        # supersede_claim calls can link to it. Duplicate registration is
        # benign (persistent lifecycle DB + cold cache restart); suppress
        # that and any other lifecycle error since the envelope is already
        # signed and ready to ship.
        with contextlib.suppress(LifecycleError):
            _LIFECYCLE.register(
                envelope,
                claim_text=req.claim,
                domain=str(req.domain),
            )
        await _VERDICT_CACHE.set(cache_key, envelope)

    # Emit a tenant-labelled counter so operators can slice traffic by
    # tenant without blowing up cardinality on the core metrics.
    TENANT_REQUESTS.labels(
        tenant_id=tenant.tenant_id or "_default",
        tool="verify_claim",
        verdict=envelope.verdict.value,
    ).inc()
    # Persist a billable record. UPSERTs into the daily aggregate
    # table — one INSERT per (tenant, issuer, tool, day) bucket.
    record_usage(
        tenant_id=tenant.tenant_id or "_default",
        issuer_did=tenant.issuer_did,
        tool="verify_claim",
    )

    # Check revocation if lists are loaded — always, even on cache hit.
    if _REVOCATION_LISTS:
        revocation_status = is_revoked(envelope, _REVOCATION_LISTS)
        if revocation_status.revoked:
            # Evict the cached entry: serving a revoked envelope twice is worse than once.
            await _VERDICT_CACHE.invalidate(cache_key)
            raise HTTPException(
                status_code=status.HTTP_410_GONE,
                detail=f"Issuer or envelope has been revoked: {revocation_status.reason}",
            )

    return EnvelopeResponse(envelope=envelope)


# ---------------------------------------------------------------------------
# Streaming verify_claim (W33)
# ---------------------------------------------------------------------------
#
# A single verify_claim can take seconds when fanning out to multiple
# adapters. The non-streaming endpoint forces the caller to wait until
# the envelope is sealed before they see anything. /tools/verify_claim/
# stream emits Server-Sent Events as each phase completes:
#
#   event: claim_accepted   → server has admitted the request
#   event: evidence         → one event per adapter (completion order)
#   event: verdict          → engine decision, before signing
#   event: envelope         → sealed envelope; stream closes
#   event: error            → terminal failure
#
# Cache hits short-circuit the stream: a single envelope event is
# emitted and the stream closes. Lifecycle registration + revocation
# checks mirror /tools/verify_claim so the two endpoints are
# behaviourally identical from the caller's POV — only the delivery
# pattern differs.


@app.post("/tools/verify_claim/stream")
async def verify_claim_stream(
    req: VerifyClaimRequest, request: Request
) -> StreamingResponse:
    """Stream verify_claim phases as Server-Sent Events.

    See module-level comment for event sequence. Returns 4xx/5xx
    *before* opening the stream for input-validation failures (PII,
    no adapters), so callers can distinguish "request rejected" from
    "stream errored mid-way".
    """
    # Pre-stream gates. Same checks as /tools/verify_claim — better
    # to fail with a structured HTTP error than to open a stream and
    # immediately emit an error event the caller may not be set up
    # to handle.
    if not REGISTRY:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="No source adapters registered.",
        )
    if contains_pii(req.claim):
        REDACTIONS_REJECTED.inc()
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=(
                "Claim contains personally identifiable information; "
                "please re-submit with the PII removed."
            ),
        )

    tenant = resolve_tenant(request)
    issuer_did = tenant.issuer_did
    cache_key = build_key(
        claim_text=req.claim,
        domain=req.domain,
        max_sources=req.max_sources,
        issuer_did=issuer_did,
    )

    # Cache lookup happens before the stream opens. A hit collapses
    # the stream to two events: claim_accepted (so the caller knows
    # we admitted the request) + envelope. We do NOT re-emit
    # evidence/verdict events from a cached envelope — those are
    # phase events, and from cache there were no phases to observe.
    cached = await _VERDICT_CACHE.get(cache_key)

    async def event_stream() -> AsyncIterator[bytes]:
        envelope: Envelope | None = None
        try:
            if cached is not None:
                CACHE_HITS.labels(tool="verify_claim_stream").inc()
                # On a cache hit we don't have the original Claim
                # object handy (we never re-derived it), so use the
                # envelope_id of the cached envelope as the stable
                # identifier the client can correlate against.
                yield encode_sse(
                    StreamClaimAccepted(
                        claim_id=cached.envelope_id,
                        classification="cached",
                        issuer_did=issuer_did,
                    )
                )
                envelope = cached
            else:
                CACHE_MISSES.labels(tool="verify_claim_stream").inc()
                claim = Claim(text=req.claim, domain=req.domain)
                async for ev in _verify_one_events(
                    claim, req.max_sources, issuer_did=issuer_did
                ):
                    yield encode_sse(ev)
                    if isinstance(ev, StreamEnvelope):
                        envelope = ev.envelope

                if envelope is not None:
                    with contextlib.suppress(LifecycleError):
                        _LIFECYCLE.register(
                            envelope,
                            claim_text=req.claim,
                            domain=str(req.domain),
                        )
                    await _VERDICT_CACHE.set(cache_key, envelope)

            if envelope is not None:
                # Mirror /tools/verify_claim's tenant counter so SSE
                # traffic is visible to operators alongside the
                # JSON endpoint.
                TENANT_REQUESTS.labels(
                    tenant_id=tenant.tenant_id or "_default",
                    tool="verify_claim_stream",
                    verdict=envelope.verdict.value,
                ).inc()
                record_usage(
                    tenant_id=tenant.tenant_id or "_default",
                    issuer_did=tenant.issuer_did,
                    tool="verify_claim_stream",
                )

                # Revocation gate. If the envelope (or its issuer) is
                # revoked we surface that mid-stream and evict from
                # cache, mirroring the JSON endpoint's 410 behaviour.
                if _REVOCATION_LISTS:
                    rev = is_revoked(envelope, _REVOCATION_LISTS)
                    if rev.revoked:
                        await _VERDICT_CACHE.invalidate(cache_key)
                        yield encode_sse(
                            StreamError(
                                detail=(
                                    "Issuer or envelope has been "
                                    f"revoked: {rev.reason}"
                                )
                            )
                        )
                        return

                # Cache hit branch already yielded claim_accepted but
                # not envelope; either way, ensure envelope is the
                # last thing on the wire.
                if cached is not None:
                    yield encode_sse(StreamEnvelope(envelope=envelope))
        except Exception as exc:  # pragma: no cover - defensive
            logger.exception("verify_claim_stream failed mid-stream")
            yield encode_sse(StreamError(detail=str(exc)))

    headers = {
        # SSE clients expect no-cache + keep-alive. Without explicit
        # no-cache, intermediaries can buffer the whole stream and
        # defeat the streaming benefit.
        "Cache-Control": "no-cache",
        "X-Accel-Buffering": "no",
    }
    return StreamingResponse(
        event_stream(),
        media_type="text/event-stream",
        headers=headers,
    )


# ---------------------------------------------------------------------------
# Claim lifecycle endpoints (W28)
# ---------------------------------------------------------------------------


class SupersedeClaimRequest(BaseModel):
    """Body for POST /tools/supersede_claim.

    Replaces ``parent_envelope_id`` with a new signed envelope for
    ``claim`` carrying ``supersedes=[parent]`` + ``supersede_reason``.
    """

    parent_envelope_id: str
    claim: str
    domain: Domain = Domain.GENERAL
    reason: SupersedeReason = SupersedeReason.SUPERSEDE
    max_sources: int = 5


class HistoryEntry(BaseModel):
    envelope_id: str
    issuer_did: str
    domain: str
    verdict: str
    parents: list[str]
    supersede_reason: SupersedeReason | None


class HistoryResponse(BaseModel):
    entries: list[HistoryEntry]


@app.post("/tools/supersede_claim", response_model=EnvelopeResponse)
async def supersede_claim(
    req: SupersedeClaimRequest, request: Request
) -> EnvelopeResponse:
    """Issue a new envelope that supersedes an existing one.

    Preconditions:
      * ``parent_envelope_id`` is registered in the lifecycle index.
      * The parent's issuer_did matches the *calling tenant's* issuer DID.
        A key belonging to tenant B cannot supersede tenant A's envelope
        even if both live in the same process.
      * At least one adapter is registered so we can ground the new verdict.

    Effects:
      * A fresh envelope is verified, sealed with ``supersedes=[parent]``
        + ``supersede_reason`` (both inside the signed canonical hash).
      * The new envelope is registered in the lifecycle index.
      * The parent's verdict-cache entry (best-effort) is invalidated.
    """
    if not REGISTRY:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="No source adapters registered.",
        )

    # Input-side PII gate (same rationale as verify_claim).
    if contains_pii(req.claim):
        REDACTIONS_REJECTED.inc()
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Claim contains personally identifiable information; "
            "please re-submit with the PII removed.",
        )

    parent = _LIFECYCLE.get(req.parent_envelope_id)
    if parent is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Unknown parent envelope {req.parent_envelope_id}",
        )

    tenant = resolve_tenant(request)
    issuer_did = tenant.issuer_did
    if parent.issuer_did != issuer_did:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=(
                f"Cannot supersede envelope issued by {parent.issuer_did}; "
                f"this tenant is {issuer_did}."
            ),
        )

    # Generate a fresh verdict, then re-seal it with the supersede link so
    # the signed canonical form carries the lifecycle provenance.
    claim = Claim(text=req.claim, domain=req.domain)
    fresh = await _verify_one(claim, req.max_sources, issuer_did=issuer_did)
    sealed = await _seal_envelope(
        claim=claim,
        verdict=fresh.verdict,
        confidence=fresh.confidence,
        evidence=list(fresh.evidence),
        rationale=fresh.rationale,
        verdict_record=VerdictRecord(
            claim_id=claim.claim_id,
            decision=fresh.verdict,
            confidence=fresh.confidence,
            evidence_refs=[e.evidence_id for e in fresh.evidence],
            rationale=fresh.rationale,
        ),
        issuer_did=issuer_did,
        supersedes=[parent.envelope_id],
        supersede_reason=req.reason,
    )

    try:
        _LIFECYCLE.register(sealed, claim_text=req.claim, domain=str(req.domain))
    except LifecycleError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Lifecycle invariant violated ({e.code}): {e}",
        ) from e

    # Best-effort: invalidate the parent's cached entry so callers stop
    # getting the stale envelope. We try several plausible max_sources
    # because the original request that produced the parent may have used
    # a different value; a miss here is harmless (cache is advisory).
    parent_claim_text = parent.claim_normalized
    for ms in {req.max_sources, 3, 5, 10}:
        parent_key = build_key(
            claim_text=parent_claim_text,
            domain=parent.domain,
            max_sources=ms,
            issuer_did=parent.issuer_did,
        )
        await _VERDICT_CACHE.invalidate(parent_key)
    CACHE_INVALIDATIONS.labels(reason="superseded").inc()

    TENANT_REQUESTS.labels(
        tenant_id=tenant.tenant_id or "_default",
        tool="supersede_claim",
        verdict=sealed.verdict.value,
    ).inc()
    record_usage(
        tenant_id=tenant.tenant_id or "_default",
        issuer_did=tenant.issuer_did,
        tool="supersede_claim",
    )

    return EnvelopeResponse(envelope=sealed)


@app.get("/claims/{envelope_id}/history", response_model=HistoryResponse)
async def claims_history(envelope_id: str) -> HistoryResponse:
    """Return the ancestor chain of an envelope (newest first)."""
    chain = _LIFECYCLE.history(envelope_id)
    if not chain:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Envelope {envelope_id} is not registered in the lifecycle index.",
        )
    return HistoryResponse(
        entries=[
            HistoryEntry(
                envelope_id=e.envelope_id,
                issuer_did=e.issuer_did,
                domain=e.domain,
                verdict=e.verdict,
                parents=list(e.parents),
                supersede_reason=e.supersede_reason,
            )
            for e in chain
        ],
    )


@app.get("/claims/latest", response_model=EnvelopeResponse)
async def claims_latest(
    request: Request,
    claim: str,
    domain: Domain = Domain.GENERAL,
    issuer_did: str | None = None,
) -> EnvelopeResponse:
    """Return the head envelope for a logical claim.

    Scoped to ``issuer_did`` (defaults to the calling tenant's DID).
    Because the lifecycle index is partitioned by issuer DID, tenants
    automatically see only their own chain unless they pass an explicit
    ``issuer_did=`` query arg targeting another publisher.

    Returns 404 if no envelope has been registered for that claim.
    """
    tenant = resolve_tenant(request)
    did = issuer_did or tenant.issuer_did
    head = _LIFECYCLE.latest(claim_text=claim, domain=str(domain), issuer_did=did)
    if head is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="No envelope registered for this claim.",
        )
    envelope = _LIFECYCLE.get_envelope(head.envelope_id)
    if envelope is None:
        # Should not happen unless the lifecycle store was populated without
        # the payload (e.g. a partial migration). Surface it clearly.
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=(
                f"Envelope {head.envelope_id} is registered but has no stored "
                "payload; cannot return it."
            ),
        )
    return EnvelopeResponse(envelope=envelope)


@app.post("/tools/retrieve_facts")
async def retrieve_facts(
    req: RetrieveFactsRequest, request: Request
) -> RetrieveFactsEnvelope:
    """Retrieve and verify multiple facts from free-text input.

    Workflow:
    1. Extract sub-claims from the query text
    2. For each sub-claim, call _verify_one concurrently
    3. Gather results into a RetrieveFactsEnvelope
    4. Seal and return
    """
    if not REGISTRY:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="No source adapters registered.",
        )

    tenant = resolve_tenant(request)
    issuer_did = tenant.issuer_did

    # Extract sub-claims from the query text
    subclaims = extract_subclaims(req.query, max_subclaims=req.max_results)

    if not subclaims:
        # No extractable claims; return empty envelope
        return await _seal_retrieve_envelope(
            facts=[],
            issuer_did=issuer_did,
        )

    # Verify each sub-claim concurrently
    claims = [Claim(text=text, domain=req.domain) for text in subclaims]
    envelopes = await asyncio.gather(
        *(
            _verify_one(claim, max_sources=5, issuer_did=issuer_did)
            for claim in claims
        ),
        return_exceptions=True,
    )

    # Convert Envelope objects to FactItem objects
    facts: list[FactItem] = []
    for envelope in envelopes:
        if isinstance(envelope, Envelope):
            fact = FactItem(
                text=envelope.evidence[0].excerpt if envelope.evidence else "",
                verdict=envelope.verdict,
                confidence=envelope.confidence,
                evidence=envelope.evidence,
            )
            facts.append(fact)
        # If envelope is an exception, skip it (fail loudly would be error handling)

    sealed = await _seal_retrieve_envelope(facts=facts, issuer_did=issuer_did)
    TENANT_REQUESTS.labels(
        tenant_id=tenant.tenant_id or "_default",
        tool="retrieve_facts",
        verdict="n/a",
    ).inc()
    record_usage(
        tenant_id=tenant.tenant_id or "_default",
        issuer_did=tenant.issuer_did,
        tool="retrieve_facts",
    )
    return sealed


async def _seal_retrieve_envelope(
    *,
    facts: list[FactItem],
    issuer_did: str,
) -> RetrieveFactsEnvelope:
    """Seal a RetrieveFactsEnvelope with signatures and anchors.

    Similar to _seal_envelope but for the retrieve_facts response structure.
    Constructs a partial envelope, signs it, timestamps it, and returns the sealed result.

    Args:
        facts: List of FactItem entries to include in the envelope.
        issuer_did: DID under which the envelope is signed. Passed in
            from the request-scoped tenant by the caller.

    Returns:
        A sealed RetrieveFactsEnvelope.
    """
    partial = RetrieveFactsEnvelope.model_construct(
        facts=facts,
        issuer_did=issuer_did,
        signature="",
        rekor_uuid="",
        rekor_log_index=0,
        tsa_token="",
        anchor_proof=AnchorProof(
            rekor_inclusion_proof="",
            tsa_tsr_primary="",
            tsa_tsr_secondary=None,
        ),
    )

    canonical_hash_hex = envelope_canonical_sha256(partial)
    signing_result = sign_hash(canonical_hash_hex)

    sig_bundle = signing_result.signature_bundle
    rekor_entry = signing_result.rekor_entry

    tsa = RFC3161Client()
    primary, secondary = await tsa.timestamp(canonical_hash_hex.encode())

    return RetrieveFactsEnvelope(
        facts=facts,
        issuer_did=issuer_did,
        signature=sig_bundle.signature_b64,
        rekor_uuid=rekor_entry.uuid,
        rekor_log_index=rekor_entry.log_index,
        tsa_token=primary.tsr_b64,
        anchor_proof=AnchorProof(
            rekor_inclusion_proof=rekor_entry.inclusion_proof,
            tsa_tsr_primary=primary.tsr_b64,
            tsa_tsr_secondary=secondary.tsr_b64 if secondary else None,
            rekor_canonical_body_b64=(
                base64.b64encode(rekor_entry.canonical_body).decode("ascii")
                if rekor_entry.canonical_body
                else None
            ),
        ),
    )


async def _seal_envelope(
    *,
    claim: Claim,
    verdict: Verdict,
    confidence: float,
    evidence: list[Evidence],
    rationale: str,
    verdict_record: VerdictRecord,
    issuer_did: str,
    supersedes: list[str] | None = None,
    supersede_reason: SupersedeReason | None = None,
) -> Envelope:
    # PII scrub BEFORE signing. Signed envelopes are public & unrevokable;
    # a leak here is permanent. Pass rationale + every evidence excerpt
    # through the redactor in one shot so we emit the metric once.
    excerpt_texts = [e.excerpt for e in evidence]
    rationale, scrubbed_excerpts, redaction_counts = redact_envelope_fields(
        rationale=rationale,
        evidence_excerpts=excerpt_texts,
    )
    if redaction_counts:
        for _kind, _n in redaction_counts.items():
            REDACTIONS_TOTAL.labels(kind=_kind).inc(_n)
        # Replace excerpts in place. We preserve every other field so
        # raw_hash, url, retrieved_at, etc. remain the adapter's ground
        # truth — redaction only modifies excerpt text.
        evidence = [
            ev.model_copy(update={"excerpt": new_excerpt})
            for ev, new_excerpt in zip(evidence, scrubbed_excerpts, strict=True)
        ]

    issued_at = datetime.now(tz=UTC)
    prov_graph = build_prov_graph(
        claim=claim,
        evidence=evidence,
        verdict_record=verdict_record,
        issuer_did=issuer_did,
        issued_at=issued_at,
    )
    supersedes_list = list(supersedes) if supersedes else []
    partial = Envelope.model_construct(
        verdict=verdict,
        confidence=confidence,
        evidence=evidence,
        rationale=rationale,
        issuer_did=issuer_did,
        signature="",
        rekor_uuid="",
        rekor_log_index=0,
        tsa_token="",
        prov_graph=prov_graph,
        anchor_proof=AnchorProof(
            rekor_inclusion_proof="",
            tsa_tsr_primary="",
            tsa_tsr_secondary=None,
        ),
        supersedes=supersedes_list,
        supersede_reason=supersede_reason,
    )

    canonical_hash_hex = envelope_canonical_sha256(partial)
    signing_result = sign_hash(canonical_hash_hex)

    # signing_result is a SigningResult with both the signature bundle
    # and the Rekor entry (the Rekor entry is populated if GTV_SIGSTORE_ENABLED=1;
    # otherwise it's from the stub).
    sig_bundle = signing_result.signature_bundle
    rekor_entry = signing_result.rekor_entry

    tsa = RFC3161Client()
    primary, secondary = await tsa.timestamp(canonical_hash_hex.encode())

    return Envelope(
        verdict=verdict,
        confidence=confidence,
        evidence=evidence,
        rationale=rationale,
        issuer_did=issuer_did,
        signature=sig_bundle.signature_b64,
        rekor_uuid=rekor_entry.uuid,
        rekor_log_index=rekor_entry.log_index,
        tsa_token=primary.tsr_b64,
        prov_graph=prov_graph,
        anchor_proof=AnchorProof(
            rekor_inclusion_proof=rekor_entry.inclusion_proof,
            tsa_tsr_primary=primary.tsr_b64,
            tsa_tsr_secondary=secondary.tsr_b64 if secondary else None,
            rekor_canonical_body_b64=(
                base64.b64encode(rekor_entry.canonical_body).decode("ascii")
                if rekor_entry.canonical_body
                else None
            ),
        ),
        supersedes=supersedes_list,
        supersede_reason=supersede_reason,
    )


class ConsensusRequest(BaseModel):
    """Request body for POST /consensus."""
    envelopes: list[dict[str, object]]


class ConsensusResponse(BaseModel):
    """Response for POST /consensus."""
    verdict: str
    confidence: float
    tally: list[dict[str, object]]
    unknown_dids: list[str]
    # Signed provenance chain: one InputRef per input envelope + aggregate canonical hash.
    # Enables cryptographic proof that the consensus was computed from the declared inputs.
    aggregate: dict[str, object] | None = None


@app.post("/consensus", response_model=ConsensusResponse)
async def consensus(req: ConsensusRequest) -> ConsensusResponse:
    """Compute consensus verdict from multiple signed envelopes.

    Request body: {"envelopes": [<envelope json>, ...]}
    Response: {"verdict": "...", "confidence": 0.xx, "tally": [...], "unknown_dids": [...]}

    Returns 400 on validation errors or mismatched claims.
    """
    if not req.envelopes:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="envelopes list cannot be empty",
        )

    # Parse all envelopes
    try:
        envelopes = [Envelope.model_validate(e) for e in req.envelopes]
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid envelope: {e}",
        ) from e

    # Compute consensus
    try:
        result = compute_consensus(envelopes)
        # Build the signed provenance chain — deterministic aggregate with InputRefs.
        aggregate = build_aggregate_envelope(envelopes, result)
        return ConsensusResponse(
            verdict=result.verdict.value,
            confidence=result.confidence,
            tally=[
                {
                    "verdict": t.verdict.value,
                    "weighted_votes": t.weighted_votes,
                    "envelope_count": t.envelope_count,
                }
                for t in result.tally
            ],
            unknown_dids=result.unknown_dids,
            aggregate=aggregate.model_dump(mode="json"),
        )
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        ) from e


# -----------------------------------------------------------------------------
# Federated consensus: fan a claim out to configured peers + local verifier,
# then fold the returned envelopes through compute_consensus. This is the
# W32 entry point — `/consensus` only computes over caller-supplied envelopes,
# which forces every client to implement its own fan-out. `/federation/consensus`
# owns the fan-out so a single HTTP call suffices.
# -----------------------------------------------------------------------------


class FederationConsensusRequest(BaseModel):
    """Request body for POST /federation/consensus."""

    claim: str
    domain: Domain = Domain.GENERAL
    max_sources: int = 5
    include_local: bool = True
    # Per-peer call timeout in seconds. Conservative: federation is
    # IO-bound, so 10s keeps the p99 predictable even if one peer is
    # slow; callers who need tighter SLOs override.
    peer_timeout_s: float = 10.0


class FederationConsensusResponse(BaseModel):
    """Response for POST /federation/consensus."""

    verdict: str
    confidence: float
    tally: list[dict[str, object]]
    unknown_dids: list[str]
    # DIDs that were queried and responded successfully.
    contributing_dids: list[str]
    # DIDs that were queried but errored out (transport, non-2xx, bad
    # envelope). Operators want this to alert on federation health.
    failed_dids: list[str]
    aggregate: dict[str, object] | None = None


@app.post(
    "/federation/consensus", response_model=FederationConsensusResponse
)
async def federation_consensus(
    req: FederationConsensusRequest, request: Request
) -> FederationConsensusResponse:
    """Fan a claim out to configured peers and compute tier-weighted consensus.

    The local verifier is included in the fan-out by default (set
    ``include_local=false`` to aggregate only remote peers). Peer
    failures are non-fatal: a consensus over the surviving peers is
    still returned, and the failed DIDs are reported so operators can
    alert on partial outages.
    """
    import httpx

    peers = load_peers_from_env()
    if not peers and not req.include_local:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="No federation peers configured and include_local=False.",
        )

    envelopes: list[Envelope] = []
    contributing_dids: list[str] = []
    failed_dids: list[str] = []

    # Local leg: reuse verify_claim's own plumbing so cache, lifecycle,
    # PII gate, and tenant attribution all still apply.
    if req.include_local:
        try:
            local = await verify_claim(
                VerifyClaimRequest(
                    claim=req.claim,
                    domain=req.domain,
                    max_sources=req.max_sources,
                ),
                request,
            )
            envelopes.append(local.envelope)
            contributing_dids.append(local.envelope.issuer_did)
        except HTTPException:
            # Re-raise so callers see real input errors (PII, 503) rather
            # than a silent "local leg failed, consensus over 0 envelopes".
            raise
        except Exception as exc:  # pragma: no cover - defensive
            logger.warning("Local leg failed: %s", exc)
            failed_dids.append("local")

    # Remote legs: fan out concurrently, tolerate per-peer failure.
    if peers:
        async with httpx.AsyncClient(timeout=req.peer_timeout_s) as client:
            results = await asyncio.gather(
                *(
                    fetch_peer_envelope(
                        peer,
                        req.claim,
                        domain=req.domain,
                        max_sources=req.max_sources,
                        timeout_s=req.peer_timeout_s,
                        client=client,
                    )
                    for peer in peers
                ),
                return_exceptions=True,
            )
        for peer, result in zip(peers, results, strict=True):
            if isinstance(result, BaseException):
                logger.warning("Peer %s failed: %s", peer.did, result)
                failed_dids.append(peer.did)
                continue
            envelopes.append(result)
            contributing_dids.append(result.issuer_did)

    if not envelopes:
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail=f"All federation legs failed: {failed_dids}",
        )

    # Federation fan-out guarantees same-claim-text; individual peers
    # each mint their own claim_id, so skip the strict claim_id check.
    consensus_result = compute_consensus(
        envelopes, enforce_same_claim_id=False
    )
    aggregate = build_aggregate_envelope(envelopes, consensus_result)

    return FederationConsensusResponse(
        verdict=consensus_result.verdict.value,
        confidence=consensus_result.confidence,
        tally=[
            {
                "verdict": t.verdict.value,
                "weighted_votes": t.weighted_votes,
                "envelope_count": t.envelope_count,
            }
            for t in consensus_result.tally
        ],
        unknown_dids=consensus_result.unknown_dids,
        contributing_dids=contributing_dids,
        failed_dids=failed_dids,
        aggregate=aggregate.model_dump(mode="json"),
    )
