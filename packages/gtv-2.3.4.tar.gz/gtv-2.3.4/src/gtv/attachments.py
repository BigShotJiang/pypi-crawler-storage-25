# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Content-addressable blob store for evidence attachments.

Supports S3/MinIO and local-filesystem backends. Keys are SHA256 hex digests.

Use `make_attachment_store_from_env()` to instantiate from environment, or
construct a backend directly.
"""

from __future__ import annotations

import asyncio
import hashlib
import os
from pathlib import Path
from typing import Any, Protocol, runtime_checkable


def compute_digest(content: bytes) -> str:
    """Compute SHA256 hex digest of content."""
    return hashlib.sha256(content).hexdigest()


@runtime_checkable
class AttachmentStore(Protocol):
    """Content-addressable blob store. Keys are sha256 hex digests."""

    async def put(self, content: bytes, content_type: str) -> str:
        """Store content, return sha256 hex digest (the key)."""
        ...

    async def get(self, digest: str) -> bytes:
        """Return bytes by digest. Raise KeyError if missing."""
        ...

    async def exists(self, digest: str) -> bool:
        """Check if a digest exists."""
        ...

    async def delete(self, digest: str) -> None:
        """Delete by digest."""
        ...

    async def url_for(self, digest: str, expires_in_s: int = 3600) -> str:
        """Return a URL the client can GET. For S3, a presigned URL; for
        local-fs, file:// URL."""
        ...

    async def close(self) -> None:
        """Release resources."""
        ...


class LocalFileAttachmentStore:
    """Stores blobs at {root}/<first-2 hex>/<remaining-62 hex>."""

    def __init__(self, root: str) -> None:
        """Initialize local file store.

        Args:
            root: Directory to store attachments in.
        """
        self._root = Path(root)

    def _get_path(self, digest: str) -> Path:
        """Get file path for a digest."""
        if len(digest) != 64:
            raise ValueError(f"Invalid digest format: {digest}")
        return self._root / digest[:2] / digest[2:]

    async def put(self, content: bytes, content_type: str) -> str:
        """Store content, return sha256 hex digest."""
        digest = compute_digest(content)
        path = self._get_path(digest)
        path.parent.mkdir(parents=True, exist_ok=True)

        # Write to temp file, then atomic rename
        temp_path = path.with_suffix(".tmp")
        await asyncio.to_thread(temp_path.write_bytes, content)
        await asyncio.to_thread(path.parent.joinpath(path.name).unlink, missing_ok=True)
        await asyncio.to_thread(temp_path.rename, path)

        return digest

    async def get(self, digest: str) -> bytes:
        """Return bytes by digest. Raise KeyError if missing."""
        path = self._get_path(digest)
        if not await asyncio.to_thread(path.exists):
            raise KeyError(digest)
        return await asyncio.to_thread(path.read_bytes)

    async def exists(self, digest: str) -> bool:
        """Check if a digest exists."""
        path = self._get_path(digest)
        return await asyncio.to_thread(path.exists)

    async def delete(self, digest: str) -> None:
        """Delete by digest."""
        path = self._get_path(digest)
        await asyncio.to_thread(path.unlink, missing_ok=True)

    async def url_for(self, digest: str, expires_in_s: int = 3600) -> str:
        """Return a file:// URL for local storage."""
        path = self._get_path(digest)
        return path.as_uri()

    async def close(self) -> None:
        """No-op for local file store."""
        pass


class S3AttachmentStore:
    """S3/MinIO backend. Uses boto3 if installed; otherwise raises at init-time."""

    def __init__(
        self,
        bucket: str,
        region: str = "us-east-1",
        client: Any = None,
        prefix: str = "attachments/",
    ) -> None:
        """Initialize S3 attachment store.

        Args:
            bucket: S3 bucket name.
            region: AWS region (default: us-east-1).
            client: Optional boto3 client for dependency injection (testing).
            prefix: Key prefix for all objects (default: attachments/).

        Raises:
            RuntimeError: If boto3 is not installed and client is not provided.
        """
        self._bucket = bucket
        self._region = region
        self._prefix = prefix

        if client is not None:
            self._client = client
        else:
            try:
                import boto3
            except ImportError as e:
                raise RuntimeError(
                    "boto3 is required for S3AttachmentStore. "
                    "Install with: pip install gtv[s3]"
                ) from e

            self._client = boto3.client("s3", region_name=region)

    def _get_key(self, digest: str) -> str:
        """Get S3 key for a digest."""
        return f"{self._prefix}{digest[:2]}/{digest[2:]}"

    async def put(self, content: bytes, content_type: str) -> str:
        """Store content in S3, return sha256 hex digest."""
        digest = compute_digest(content)
        key = self._get_key(digest)

        await asyncio.to_thread(
            self._client.put_object,
            Bucket=self._bucket,
            Key=key,
            Body=content,
            ContentType=content_type,
        )

        return digest

    async def get(self, digest: str) -> bytes:
        """Return bytes by digest from S3. Raise KeyError if missing."""
        key = self._get_key(digest)

        try:
            response = await asyncio.to_thread(
                self._client.get_object, Bucket=self._bucket, Key=key
            )
            # Boto3 returns a StreamingBody object; read it
            body = response.get("Body")
            if body is None:
                raise KeyError(digest)
            return await asyncio.to_thread(body.read)
        except KeyError:
            raise
        except Exception as e:
            # Boto3 raises various exceptions; KeyError is more idiomatic
            if "NoSuchKey" in str(type(e).__name__) or "NoSuchKey" in str(e):
                raise KeyError(digest) from e
            raise

    async def exists(self, digest: str) -> bool:
        """Check if digest exists in S3."""
        key = self._get_key(digest)

        try:
            await asyncio.to_thread(
                self._client.head_object, Bucket=self._bucket, Key=key
            )
            return True
        except Exception as e:
            if "NotFound" in str(type(e).__name__) or "404" in str(e):
                return False
            raise

    async def delete(self, digest: str) -> None:
        """Delete digest from S3."""
        key = self._get_key(digest)
        await asyncio.to_thread(
            self._client.delete_object, Bucket=self._bucket, Key=key
        )

    async def url_for(self, digest: str, expires_in_s: int = 3600) -> str:
        """Return a presigned URL for the S3 object."""
        key = self._get_key(digest)
        url = await asyncio.to_thread(
            self._client.generate_presigned_url,
            "get_object",
            Params={"Bucket": self._bucket, "Key": key},
            ExpiresIn=expires_in_s,
        )
        return url

    async def close(self) -> None:
        """Close the S3 client if it has a close method."""
        if hasattr(self._client, "close"):
            await asyncio.to_thread(self._client.close)


def make_attachment_store_from_env() -> AttachmentStore | None:
    """Create attachment store from environment variables.

    Reads GTV_ATTACHMENT_BACKEND: 'local' | 's3' | unset (returns None).

    For local backend:
        GTV_ATTACHMENT_ROOT (required)

    For S3 backend:
        GTV_ATTACHMENT_BUCKET (required)
        GTV_ATTACHMENT_REGION (optional, default: us-east-1)
        GTV_ATTACHMENT_PREFIX (optional, default: attachments/)

    Returns:
        An AttachmentStore instance, or None if backend is not configured.

    Raises:
        ValueError: If required environment variables are missing.
        RuntimeError: If boto3 is required but not installed.
    """
    backend = os.getenv("GTV_ATTACHMENT_BACKEND")

    if backend is None:
        return None

    if backend == "local":
        root = os.getenv("GTV_ATTACHMENT_ROOT")
        if not root:
            raise ValueError(
                "GTV_ATTACHMENT_BACKEND=local requires GTV_ATTACHMENT_ROOT"
            )
        return LocalFileAttachmentStore(root)

    if backend == "s3":
        bucket = os.getenv("GTV_ATTACHMENT_BUCKET")
        if not bucket:
            raise ValueError(
                "GTV_ATTACHMENT_BACKEND=s3 requires GTV_ATTACHMENT_BUCKET"
            )
        region = os.getenv("GTV_ATTACHMENT_REGION", "us-east-1")
        prefix = os.getenv("GTV_ATTACHMENT_PREFIX", "attachments/")
        return S3AttachmentStore(bucket=bucket, region=region, prefix=prefix)

    raise ValueError(
        f"Unknown GTV_ATTACHMENT_BACKEND: {backend!r}. "
        "Must be 'local', 's3', or unset."
    )
