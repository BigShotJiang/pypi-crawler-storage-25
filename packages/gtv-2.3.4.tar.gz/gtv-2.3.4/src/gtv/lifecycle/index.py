# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Lifecycle index implementation (in-memory + optional SQLite backend).

The index is append-only: envelopes are registered once and never
mutated. Edge direction is child → parent (``supersedes`` links point
backward), which matches the canonical envelope. We materialise the
reverse (parent → children) adjacency at write time for cheap
forward walks (``latest``, ``descendants``).

Concurrency: the in-memory index assumes single-threaded asyncio. If
you fan out registrations across threads, wrap it.
"""
from __future__ import annotations

import os
import sqlite3
import threading
import unicodedata
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from gtv.lifecycle.errors import LifecycleError
from gtv.models import Envelope, SupersedeReason


def normalize_claim_for_lifecycle(text: str) -> str:
    """Produce a canonical normalized form for cross-envelope claim matching.

    Same normalization as the verdict cache key: NFKC → collapse
    whitespace → casefold. Kept in this module to avoid a circular
    dependency with ``gtv.cache`` (lifecycle is a lower layer).
    """
    return " ".join(unicodedata.normalize("NFKC", text).split()).casefold()


@dataclass(frozen=True)
class LifecycleEntry:
    """Immutable snapshot of a registered envelope's lifecycle metadata."""

    envelope_id: str
    issuer_did: str
    claim_normalized: str
    domain: str
    verdict: str
    parents: tuple[str, ...] = ()
    supersede_reason: SupersedeReason | None = None
    # Canonical JSON of the full signed envelope. Stored so
    # ``/claims/{id}`` can return the envelope without a separate store.
    envelope_payload: bytes = b""


class LifecycleIndex:
    """In-process lifecycle index. Backs the HTTP lifecycle endpoints."""

    def __init__(self) -> None:
        self._entries: dict[str, LifecycleEntry] = {}
        # Reverse index: parent_id → set[child_id]. Maintained on register.
        self._children: dict[str, set[str]] = {}
        # (claim_normalized, domain, issuer_did) → set of envelope_ids for
        # that logical claim. Lets ``latest`` find the head without scanning.
        self._by_claim: dict[tuple[str, str, str], set[str]] = {}

    # ------------------------------------------------------------------
    # Mutation
    # ------------------------------------------------------------------
    def register(self, envelope: Envelope, *, claim_text: str, domain: str) -> LifecycleEntry:
        """Record an envelope + its supersede links.

        Validates:
          * ``envelope.envelope_id`` is not already registered (duplicate).
          * No self-supersede (``envelope_id`` in its own ``supersedes``).
          * Every parent exists in the index.
          * Cross-issuer supersede is rejected — a new issuer cannot
            "take over" another's lifecycle chain.
          * No cycles (parents' ancestors must not include this envelope).

        Raises:
            LifecycleError: on any invariant violation.
        """
        env_id = envelope.envelope_id
        if env_id in self._entries:
            raise LifecycleError("duplicate", f"envelope {env_id} already registered")
        if env_id in envelope.supersedes:
            raise LifecycleError("self_supersede", "an envelope cannot supersede itself")

        for parent_id in envelope.supersedes:
            parent = self._entries.get(parent_id)
            if parent is None:
                raise LifecycleError(
                    "unknown_parent", f"parent envelope {parent_id} is not registered"
                )
            if parent.issuer_did != envelope.issuer_did:
                raise LifecycleError(
                    "cross_issuer",
                    f"issuer {envelope.issuer_did} cannot supersede envelope "
                    f"issued by {parent.issuer_did}",
                )
            # Walking up from parent must not loop back to env_id. Since the
            # index is append-only, env_id is not yet in the graph, so this
            # only fires if the caller passed a forged/prebuilt envelope
            # whose id collides with an ancestor — still worth catching.
            if self._ancestors_contain(parent_id, env_id):
                raise LifecycleError(
                    "cycle", f"adding {env_id} would create a cycle through {parent_id}"
                )

        entry = LifecycleEntry(
            envelope_id=env_id,
            issuer_did=envelope.issuer_did,
            claim_normalized=normalize_claim_for_lifecycle(claim_text),
            domain=domain,
            verdict=str(envelope.verdict),
            parents=tuple(envelope.supersedes),
            supersede_reason=envelope.supersede_reason,
            envelope_payload=envelope.model_dump_json().encode("utf-8"),
        )
        self._entries[env_id] = entry
        for parent_id in entry.parents:
            self._children.setdefault(parent_id, set()).add(env_id)
        self._by_claim.setdefault(
            (entry.claim_normalized, entry.domain, entry.issuer_did), set()
        ).add(env_id)
        return entry

    def get_envelope(self, envelope_id: str) -> Envelope | None:
        """Reconstruct the full envelope for a registered ID. None if unknown."""
        entry = self._entries.get(envelope_id)
        if entry is None or not entry.envelope_payload:
            return None
        import json as _json
        data = _json.loads(entry.envelope_payload.decode("utf-8"))
        return Envelope.model_validate(data)

    # ------------------------------------------------------------------
    # Queries
    # ------------------------------------------------------------------
    def get(self, envelope_id: str) -> LifecycleEntry | None:
        return self._entries.get(envelope_id)

    def parents(self, envelope_id: str) -> tuple[str, ...]:
        entry = self._entries.get(envelope_id)
        return entry.parents if entry is not None else ()

    def children(self, envelope_id: str) -> tuple[str, ...]:
        return tuple(sorted(self._children.get(envelope_id, ())))

    def history(self, envelope_id: str) -> list[LifecycleEntry]:
        """Return the ancestor chain of an envelope, newest first.

        Result[0] is the envelope itself; the tail walks backward
        through parents via BFS (deterministic order for multi-parent
        merges: parents in declared order, then their parents, etc.).
        Missing parents are skipped — they can't appear in an
        in-memory index that rejects unknown-parent registrations.
        """
        entry = self._entries.get(envelope_id)
        if entry is None:
            return []
        order: list[LifecycleEntry] = [entry]
        seen = {envelope_id}
        queue: list[str] = list(entry.parents)
        while queue:
            nxt = queue.pop(0)
            if nxt in seen:
                continue
            seen.add(nxt)
            parent_entry = self._entries.get(nxt)
            if parent_entry is None:
                continue
            order.append(parent_entry)
            queue.extend(p for p in parent_entry.parents if p not in seen)
        return order

    def descendants(self, envelope_id: str) -> list[LifecycleEntry]:
        """BFS forward through children. Returns descendants only
        (excludes the root envelope). Deterministic child ordering."""
        if envelope_id not in self._entries:
            return []
        order: list[LifecycleEntry] = []
        seen = {envelope_id}
        queue: list[str] = sorted(self._children.get(envelope_id, ()))
        while queue:
            nxt = queue.pop(0)
            if nxt in seen:
                continue
            seen.add(nxt)
            child = self._entries.get(nxt)
            if child is None:
                continue
            order.append(child)
            queue.extend(sorted(c for c in self._children.get(nxt, ()) if c not in seen))
        return order

    def heads(
        self, *, claim_normalized: str, domain: str, issuer_did: str
    ) -> list[LifecycleEntry]:
        """Current heads for a logical claim (entries with no children)."""
        ids = self._by_claim.get((claim_normalized, domain, issuer_did), set())
        return [
            self._entries[i]
            for i in sorted(ids)
            if not self._children.get(i)
        ]

    def latest(
        self, *, claim_text: str, domain: str, issuer_did: str
    ) -> LifecycleEntry | None:
        """Pick a single head for a logical claim.

        Returns the head with the largest descendant set (most recent by
        depth) breaking ties by envelope_id for determinism. If the claim
        has no registered envelope, returns ``None``.
        """
        heads = self.heads(
            claim_normalized=normalize_claim_for_lifecycle(claim_text),
            domain=domain,
            issuer_did=issuer_did,
        )
        if not heads:
            return None
        if len(heads) == 1:
            return heads[0]
        # Multiple heads => the chain forked. Pick the one whose ancestry
        # is longest (most-updated branch); break ties deterministically.
        return max(heads, key=lambda e: (len(self.history(e.envelope_id)), e.envelope_id))

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------
    def _ancestors_contain(self, start: str, target: str) -> bool:
        """Walk up from ``start`` checking whether ``target`` is an ancestor."""
        stack = [start]
        seen: set[str] = set()
        while stack:
            cur = stack.pop()
            if cur == target:
                return True
            if cur in seen:
                continue
            seen.add(cur)
            entry = self._entries.get(cur)
            if entry is None:
                continue
            stack.extend(entry.parents)
        return False

    def __len__(self) -> int:
        return len(self._entries)


# ----------------------------------------------------------------------
# SQLite-backed index (opt-in)
# ----------------------------------------------------------------------

_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS lifecycle_entries (
    envelope_id TEXT PRIMARY KEY,
    issuer_did TEXT NOT NULL,
    claim_normalized TEXT NOT NULL,
    domain TEXT NOT NULL,
    verdict TEXT NOT NULL,
    supersede_reason TEXT,
    envelope_payload BLOB
);
CREATE TABLE IF NOT EXISTS lifecycle_links (
    child_id TEXT NOT NULL,
    parent_id TEXT NOT NULL,
    position INTEGER NOT NULL,
    PRIMARY KEY (child_id, parent_id),
    FOREIGN KEY (child_id) REFERENCES lifecycle_entries(envelope_id),
    FOREIGN KEY (parent_id) REFERENCES lifecycle_entries(envelope_id)
);
CREATE INDEX IF NOT EXISTS idx_lifecycle_links_parent ON lifecycle_links(parent_id);
CREATE INDEX IF NOT EXISTS idx_lifecycle_by_claim
    ON lifecycle_entries(claim_normalized, domain, issuer_did);
"""


@dataclass
class SQLiteLifecycleIndex:
    """SQLite-backed lifecycle index.

    Loads the whole graph into an in-memory ``LifecycleIndex`` on init
    (lifecycle data is small — one row per envelope, expected scale
    well under the tens-of-millions range we'd need to shard), then
    writes registrations back to disk. Reads stay O(chain) and never
    hit SQLite after init.

    Thread-safety: protected by a lock around register() so a webhook
    callback can't race a verify_claim on the same parent.
    """

    path: Path
    _memory: LifecycleIndex = field(default_factory=LifecycleIndex)
    _conn: sqlite3.Connection | None = None
    _lock: threading.Lock = field(default_factory=threading.Lock)

    def __post_init__(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(self.path), check_same_thread=False)
        self._conn.executescript(_SCHEMA_SQL)
        self._conn.commit()
        self._load_from_disk()

    def _load_from_disk(self) -> None:
        assert self._conn is not None
        rows = self._conn.execute(
            "SELECT envelope_id, issuer_did, claim_normalized, domain, verdict, "
            "supersede_reason, envelope_payload FROM lifecycle_entries"
        ).fetchall()
        # Build a temporary lookup of parents by child so we can load them
        # topologically (parents must exist before children get registered).
        links_by_child: dict[str, list[str]] = {}
        # Read ORDER BY position so parents are inserted in declared order.
        for child_id, parent_id, _position in self._conn.execute(
            "SELECT child_id, parent_id, position FROM lifecycle_links "
            "ORDER BY child_id, position"
        ):
            links_by_child.setdefault(child_id, []).append(parent_id)

        row_by_id: dict[str, tuple[Any, ...]] = {r[0]: r for r in rows}
        registered: set[str] = set()

        def _register(env_id: str) -> None:
            if env_id in registered:
                return
            for p in links_by_child.get(env_id, []):
                if p in row_by_id:
                    _register(p)
            row = row_by_id[env_id]
            entry = LifecycleEntry(
                envelope_id=row[0],
                issuer_did=row[1],
                claim_normalized=row[2],
                domain=row[3],
                verdict=row[4],
                parents=tuple(links_by_child.get(env_id, ())),
                supersede_reason=SupersedeReason(row[5]) if row[5] is not None else None,
                envelope_payload=bytes(row[6]) if row[6] is not None else b"",
            )
            self._memory._entries[env_id] = entry
            for parent_id in entry.parents:
                self._memory._children.setdefault(parent_id, set()).add(env_id)
            self._memory._by_claim.setdefault(
                (entry.claim_normalized, entry.domain, entry.issuer_did), set()
            ).add(env_id)
            registered.add(env_id)

        for env_id in row_by_id:
            _register(env_id)

    def register(self, envelope: Envelope, *, claim_text: str, domain: str) -> LifecycleEntry:
        with self._lock:
            entry = self._memory.register(envelope, claim_text=claim_text, domain=domain)
            assert self._conn is not None
            self._conn.execute(
                "INSERT INTO lifecycle_entries "
                "(envelope_id, issuer_did, claim_normalized, domain, verdict, "
                "supersede_reason, envelope_payload) "
                "VALUES (?, ?, ?, ?, ?, ?, ?)",
                (
                    entry.envelope_id,
                    entry.issuer_did,
                    entry.claim_normalized,
                    entry.domain,
                    entry.verdict,
                    entry.supersede_reason.value if entry.supersede_reason is not None else None,
                    entry.envelope_payload,
                ),
            )
            for position, parent_id in enumerate(entry.parents):
                self._conn.execute(
                    "INSERT INTO lifecycle_links (child_id, parent_id, position) "
                    "VALUES (?, ?, ?)",
                    (entry.envelope_id, parent_id, position),
                )
            self._conn.commit()
            return entry

    # Delegate reads to the in-memory view.
    def get(self, envelope_id: str) -> LifecycleEntry | None:
        return self._memory.get(envelope_id)

    def get_envelope(self, envelope_id: str) -> Envelope | None:
        return self._memory.get_envelope(envelope_id)

    def parents(self, envelope_id: str) -> tuple[str, ...]:
        return self._memory.parents(envelope_id)

    def children(self, envelope_id: str) -> tuple[str, ...]:
        return self._memory.children(envelope_id)

    def history(self, envelope_id: str) -> list[LifecycleEntry]:
        return self._memory.history(envelope_id)

    def descendants(self, envelope_id: str) -> list[LifecycleEntry]:
        return self._memory.descendants(envelope_id)

    def heads(
        self, *, claim_normalized: str, domain: str, issuer_did: str
    ) -> list[LifecycleEntry]:
        return self._memory.heads(
            claim_normalized=claim_normalized, domain=domain, issuer_did=issuer_did
        )

    def latest(
        self, *, claim_text: str, domain: str, issuer_did: str
    ) -> LifecycleEntry | None:
        return self._memory.latest(
            claim_text=claim_text, domain=domain, issuer_did=issuer_did
        )

    def __len__(self) -> int:
        return len(self._memory)

    def close(self) -> None:
        if self._conn is not None:
            self._conn.close()
            self._conn = None


def make_index_from_env() -> LifecycleIndex | SQLiteLifecycleIndex:
    """Env-driven factory.

    ``GTV_LIFECYCLE_DB`` → SQLite at that path. Otherwise in-memory.
    """
    db_path = os.environ.get("GTV_LIFECYCLE_DB")
    if db_path:
        return SQLiteLifecycleIndex(path=Path(db_path).expanduser())
    return LifecycleIndex()
