# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Claim lifecycle index: amend / supersede / withdraw linkage (W28).

Every newly-issued envelope can declare ``supersedes=[parent_ids]`` +
``supersede_reason``. Those fields are part of the canonical hash — a
tamper-evident, signed provenance chain.

This module owns the *index* that maps envelope IDs to their parent
and child links so history and "latest" lookups are O(chain).

Public surface:

* :class:`LifecycleIndex` — in-memory default index (dict-backed).
* :func:`make_index_from_env` — env-driven factory (SQLite backend
  via ``GTV_LIFECYCLE_DB``, else in-memory).
* :exc:`LifecycleError` — all user-facing validation failures.
"""
from __future__ import annotations

from gtv.lifecycle.errors import LifecycleError
from gtv.lifecycle.index import (
    LifecycleEntry,
    LifecycleIndex,
    make_index_from_env,
    normalize_claim_for_lifecycle,
)

__all__ = [
    "LifecycleEntry",
    "LifecycleError",
    "LifecycleIndex",
    "make_index_from_env",
    "normalize_claim_for_lifecycle",
]
