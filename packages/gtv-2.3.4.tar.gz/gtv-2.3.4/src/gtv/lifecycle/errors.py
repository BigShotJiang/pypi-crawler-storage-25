# SPDX-License-Identifier: Apache-2.0 OR LicenseRef-gtv-commercial
"""Errors raised by the lifecycle index.

Kept separate so both the index and the server layer can import it
without pulling in the full index module.
"""
from __future__ import annotations


class LifecycleError(ValueError):
    """A supersede/amend/withdraw request violated an invariant.

    Attributes:
        code: Machine-readable reason tag (e.g. ``"unknown_parent"``).
    """

    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code
