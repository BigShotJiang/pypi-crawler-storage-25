import { test } from "node:test";
import assert from "node:assert";
import {
  GtvClient,
  GtvHttpError,
  GtvTimeoutError,
  type VerifyRequest,
} from "../dist/index.js";

// Mock fetch for testing
function createMockFetch(
  response: Record<string, unknown> | null = null,
  status: number = 200,
  shouldDelay: boolean = false,
): typeof fetch {
  return async (url: string, options?: RequestInit) => {
    if (shouldDelay) {
      await new Promise((resolve) => setTimeout(resolve, 20_000));
    }

    return {
      ok: status >= 200 && status < 300,
      status,
      text: async () => JSON.stringify(response || { error: "error" }),
      json: async () => response || { error: "error" },
    } as Response;
  };
}

test("verify happy path", async () => {
  const mockResponse = {
    status: "VERIFIED",
    confidence: 0.95,
    claim_id: "claim_123",
    evidence: [
      {
        source_did: "did:example:abc",
        source_version: "1.0",
        stance: "SUPPORTS",
        excerpt: "This supports the claim",
        url: "https://example.com",
        retrieved_at: "2024-01-01T00:00:00Z",
        raw_hash: "abc123",
      },
    ],
  };

  const client = new GtvClient({
    baseUrl: "https://verify.example.com",
    fetchImpl: createMockFetch(mockResponse),
  });

  const result = await client.verify({
    claimText: "The sky is blue",
  });

  assert.strictEqual(result.status, "VERIFIED");
  assert.strictEqual(result.confidence, 0.95);
  assert.strictEqual(result.claimId, "claim_123");
  assert.strictEqual(result.evidence[0].sourceDid, "did:example:abc");
  assert.strictEqual(result.evidence[0].stance, "SUPPORTS");
  assert.strictEqual(result.evidence[0].retrievedAt, "2024-01-01T00:00:00Z");
});

test("verify with domain and maxItems", async () => {
  const mockResponse = { status: "VERIFIED", confidence: 0.8, claim_id: "claim_456", evidence: [] };
  let capturedBody: string | null = null;

  const mockFetch: typeof fetch = async (url: string, options?: RequestInit) => {
    if (options?.body) {
      capturedBody = options.body as string;
    }
    return {
      ok: true,
      status: 200,
      text: async () => JSON.stringify(mockResponse),
      json: async () => mockResponse,
    } as Response;
  };

  const client = new GtvClient({
    baseUrl: "https://verify.example.com",
    fetchImpl: mockFetch,
  });

  const req: VerifyRequest = {
    claimText: "Test claim",
    domain: "physics",
    maxItems: 5,
  };

  await client.verify(req);

  assert(capturedBody);
  const body = JSON.parse(capturedBody);
  assert.strictEqual(body.claim_text, "Test claim");
  assert.strictEqual(body.domain, "physics");
  assert.strictEqual(body.max_items, 5);
});

test("verify includes Authorization header when apiKey set", async () => {
  const mockResponse = { status: "VERIFIED", confidence: 0.8, claim_id: "claim_789", evidence: [] };
  let capturedHeaders: HeadersInit | undefined;

  const mockFetch: typeof fetch = async (url: string, options?: RequestInit) => {
    capturedHeaders = options?.headers as HeadersInit;
    return {
      ok: true,
      status: 200,
      text: async () => JSON.stringify(mockResponse),
      json: async () => mockResponse,
    } as Response;
  };

  const client = new GtvClient({
    baseUrl: "https://verify.example.com",
    apiKey: "sk_test_123",
    fetchImpl: mockFetch,
  });

  await client.verify({ claimText: "Test" });

  assert(capturedHeaders);
  const headerRecord = capturedHeaders as Record<string, string>;
  assert.strictEqual(headerRecord["Authorization"], "Bearer sk_test_123");
});

test("verify omits Authorization header when apiKey not set", async () => {
  const mockResponse = { status: "VERIFIED", confidence: 0.8, claim_id: "claim_000", evidence: [] };
  let capturedHeaders: HeadersInit | undefined;

  const mockFetch: typeof fetch = async (url: string, options?: RequestInit) => {
    capturedHeaders = options?.headers as HeadersInit;
    return {
      ok: true,
      status: 200,
      text: async () => JSON.stringify(mockResponse),
      json: async () => mockResponse,
    } as Response;
  };

  const client = new GtvClient({
    baseUrl: "https://verify.example.com",
    fetchImpl: mockFetch,
  });

  await client.verify({ claimText: "Test" });

  assert(capturedHeaders);
  const headerRecord = capturedHeaders as Record<string, string>;
  assert(!("Authorization" in headerRecord));
});

test("verify converts snake_case to camelCase", async () => {
  const mockResponse = {
    status: "VERIFIED",
    confidence: 0.9,
    claim_id: "claim_abc",
    trace_id: "trace_xyz",
    evidence: [
      {
        source_did: "did:test",
        source_version: "2.0",
        stance: "REFUTES",
        excerpt: "test excerpt",
        url: "https://test.com",
        retrieved_at: "2024-02-01T12:00:00Z",
        raw_hash: "def456",
      },
    ],
  };

  const client = new GtvClient({
    baseUrl: "https://verify.example.com",
    fetchImpl: createMockFetch(mockResponse),
  });

  const result = await client.verify({ claimText: "Test" });

  assert.strictEqual(result.traceId, "trace_xyz");
  assert.strictEqual(result.evidence[0].sourceDid, "did:test");
  assert.strictEqual(result.evidence[0].sourceVersion, "2.0");
  assert.strictEqual(result.evidence[0].retrievedAt, "2024-02-01T12:00:00Z");
  assert.strictEqual(result.evidence[0].rawHash, "def456");
});

test("verify timeout triggers abort and raises GtvTimeoutError", async () => {
  const mockFetch: typeof fetch = async (url: string, options?: RequestInit) => {
    // Simulate abort by checking the signal and waiting for it to be aborted
    const signal = options?.signal;
    if (signal && signal.aborted) {
      const error = new Error("Aborted");
      (error as any).name = "AbortError";
      throw error;
    }
    // If not aborted yet, set up listener and wait
    if (signal) {
      return new Promise((_, reject) => {
        signal.addEventListener("abort", () => {
          const error = new Error("Aborted");
          (error as any).name = "AbortError";
          reject(error);
        });
      });
    }
    throw new Error("No signal provided");
  };

  const client = new GtvClient({
    baseUrl: "https://verify.example.com",
    timeoutMs: 50,
    fetchImpl: mockFetch,
  });

  try {
    await client.verify({ claimText: "Test" });
    assert.fail("Should have raised GtvTimeoutError");
  } catch (error) {
    assert(error instanceof GtvTimeoutError);
    assert((error as Error).message.includes("timeout"));
  }
});

test("verify 4xx raises GtvHttpError", async () => {
  const client = new GtvClient({
    baseUrl: "https://verify.example.com",
    fetchImpl: createMockFetch(null, 400),
  });

  try {
    await client.verify({ claimText: "Test" });
    assert.fail("Should have raised GtvHttpError");
  } catch (error) {
    assert(error instanceof GtvHttpError);
    assert.strictEqual((error as GtvHttpError).status, 400);
  }
});

test("verify 5xx raises GtvHttpError", async () => {
  const client = new GtvClient({
    baseUrl: "https://verify.example.com",
    fetchImpl: createMockFetch(null, 500),
  });

  try {
    await client.verify({ claimText: "Test" });
    assert.fail("Should have raised GtvHttpError");
  } catch (error) {
    assert(error instanceof GtvHttpError);
    assert.strictEqual((error as GtvHttpError).status, 500);
  }
});

test("health healthy", async () => {
  const mockResponse = { status: "HEALTHY" };

  const client = new GtvClient({
    baseUrl: "https://verify.example.com",
    fetchImpl: createMockFetch(mockResponse),
  });

  const result = await client.health();

  assert.strictEqual(result.status, "HEALTHY");
});

test("health degraded", async () => {
  const mockResponse = { status: "DEGRADED" };

  const client = new GtvClient({
    baseUrl: "https://verify.example.com",
    fetchImpl: createMockFetch(mockResponse),
  });

  const result = await client.health();

  assert.strictEqual(result.status, "DEGRADED");
});
