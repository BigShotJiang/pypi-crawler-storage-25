# GTV Client SDK for TypeScript

A zero-dependency TypeScript client library for the GTV (Ground Truth Verification) API, designed for Node.js and browser environments using global `fetch`.

## Installation

```bash
npm install @gtv/client
```

## Quick Start

```typescript
import { GtvClient } from "@gtv/client";

const client = new GtvClient({
  baseUrl: "https://verify.example.com",
  apiKey: "your_api_key", // optional
});

// Verify a claim
const verdict = await client.verify({
  claimText: "The Earth is round",
  domain: "physics",
  maxItems: 10,
});

console.log(verdict.status); // "VERIFIED", "REFUTED", "UNCERTAIN", or "CONFLICTED"
console.log(verdict.confidence); // 0.0 to 1.0
console.log(verdict.evidence); // array of Evidence objects

// Check API health
const health = await client.health();
console.log(health.status); // "HEALTHY", "DEGRADED", or "DOWN"
```

## API

### GtvClient

#### Constructor

```typescript
new GtvClient(options: GtvClientOptions)
```

Options:
- `baseUrl` (string, required): Base URL of the GTV API server
- `apiKey` (string, optional): API key for authentication
- `timeoutMs` (number, optional): Request timeout in milliseconds (default: 15000)
- `fetchImpl` (typeof fetch, optional): Custom fetch implementation for testing

#### Methods

**`verify(req: VerifyRequest): Promise<Verdict>`**

Verify a claim against evidence sources.

**`health(): Promise<HealthResponse>`**

Check the API health status.

### Types

```typescript
interface VerifyRequest {
  claimText: string;
  domain?: string;     // e.g., "physics", "cs", "biomed"
  maxItems?: number;   // maximum evidence items to return
}

interface Verdict {
  status: "VERIFIED" | "REFUTED" | "UNCERTAIN" | "CONFLICTED";
  confidence: number;
  evidence: Evidence[];
  claimId: string;
  traceId?: string;
}

interface Evidence {
  sourceDid: string;
  sourceVersion: string;
  stance: "SUPPORTS" | "REFUTES" | "NEUTRAL" | "QUALIFIES";
  excerpt: string;
  url: string;
  retrievedAt: string;
  rawHash: string;
}

interface HealthResponse {
  status: "HEALTHY" | "DEGRADED" | "DOWN";
}
```

### Error Handling

```typescript
import { GtvHttpError, GtvTimeoutError } from "@gtv/client";

try {
  const verdict = await client.verify({ claimText: "..." });
} catch (error) {
  if (error instanceof GtvTimeoutError) {
    console.error("Request timed out");
  } else if (error instanceof GtvHttpError) {
    console.error(`HTTP ${error.status}: ${error.body}`);
  } else {
    console.error("Unexpected error:", error);
  }
}
```

## Development

```bash
# Install dependencies
npm install

# Build TypeScript
npm run build

# Run tests
npm test
```

## License

MIT
