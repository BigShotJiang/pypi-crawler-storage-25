/**
 * GTV Verify API TypeScript Client SDK
 * Zero-dependency, uses global fetch
 */

export interface GtvClientOptions {
  baseUrl: string;
  apiKey?: string;
  timeoutMs?: number;
  fetchImpl?: typeof fetch;
}

export interface VerifyRequest {
  claimText: string;
  domain?: string;
  maxItems?: number;
}

export interface Evidence {
  sourceDid: string;
  sourceVersion: string;
  stance: "SUPPORTS" | "REFUTES" | "NEUTRAL" | "QUALIFIES";
  excerpt: string;
  url: string;
  retrievedAt: string;
  rawHash: string;
}

export interface Verdict {
  status: "VERIFIED" | "REFUTED" | "UNCERTAIN" | "CONFLICTED";
  confidence: number;
  evidence: Evidence[];
  claimId: string;
  traceId?: string;
}

export interface HealthResponse {
  status: "HEALTHY" | "DEGRADED" | "DOWN";
}

export class GtvHttpError extends Error {
  constructor(
    public status: number,
    public body: string,
    message?: string,
  ) {
    super(message || `HTTP ${status}: ${body}`);
    this.name = "GtvHttpError";
    Object.setPrototypeOf(this, GtvHttpError.prototype);
  }
}

export class GtvTimeoutError extends Error {
  constructor(message?: string) {
    super(message || "Request timeout");
    this.name = "GtvTimeoutError";
    Object.setPrototypeOf(this, GtvTimeoutError.prototype);
  }
}

/**
 * Convert snake_case object keys to camelCase
 */
function snakeToCamel(obj: unknown): unknown {
  if (obj === null || obj === undefined) return obj;
  if (typeof obj !== "object") return obj;
  if (obj instanceof Date) return obj;

  if (Array.isArray(obj)) {
    return obj.map(snakeToCamel);
  }

  const result: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(obj)) {
    const camelKey = key.replace(/_([a-z])/g, (_, letter) =>
      letter.toUpperCase(),
    );
    result[camelKey] = snakeToCamel(value);
  }
  return result;
}

export class GtvClient {
  private baseUrl: string;
  private apiKey?: string;
  private timeoutMs: number;
  private fetchImpl: typeof fetch;

  constructor(opts: GtvClientOptions) {
    this.baseUrl = opts.baseUrl.replace(/\/$/, "");
    this.apiKey = opts.apiKey;
    this.timeoutMs = opts.timeoutMs ?? 15_000;
    this.fetchImpl = opts.fetchImpl ?? fetch;
  }

  async verify(req: VerifyRequest): Promise<Verdict> {
    const url = `${this.baseUrl}/tools/verify_claim`;
    const body = {
      claim_text: req.claimText,
      domain: req.domain,
      max_items: req.maxItems,
    };

    const headers: Record<string, string> = {
      "Content-Type": "application/json",
    };

    if (this.apiKey) {
      headers["Authorization"] = `Bearer ${this.apiKey}`;
    }

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), this.timeoutMs);

    try {
      const response = await this.fetchImpl(url, {
        method: "POST",
        headers,
        body: JSON.stringify(body),
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        const errorBody = await response.text();
        throw new GtvHttpError(response.status, errorBody);
      }

      const data = await response.json();
      return snakeToCamel(data) as Verdict;
    } catch (error) {
      clearTimeout(timeoutId);

      if (error instanceof GtvHttpError || error instanceof GtvTimeoutError) {
        throw error;
      }

      if (
        (error instanceof DOMException && error.name === "AbortError") ||
        (error instanceof Error && error.name === "AbortError")
      ) {
        throw new GtvTimeoutError(
          `Request timeout after ${this.timeoutMs}ms`,
        );
      }

      throw error;
    }
  }

  async health(): Promise<HealthResponse> {
    const url = `${this.baseUrl}/healthz`;
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), this.timeoutMs);

    try {
      const response = await this.fetchImpl(url, {
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        const errorBody = await response.text();
        throw new GtvHttpError(response.status, errorBody);
      }

      const data = await response.json();
      return snakeToCamel(data) as HealthResponse;
    } catch (error) {
      clearTimeout(timeoutId);

      if (error instanceof GtvHttpError || error instanceof GtvTimeoutError) {
        throw error;
      }

      if (
        (error instanceof DOMException && error.name === "AbortError") ||
        (error instanceof Error && error.name === "AbortError")
      ) {
        throw new GtvTimeoutError(
          `Request timeout after ${this.timeoutMs}ms`,
        );
      }

      throw error;
    }
  }
}
