"""The example adapter must pass the conformance suite.

Every third-party adapter should have a test like this. It proves the
adapter meets the contract gtv relies on — without it, plugins can
silently break server startup.
"""

from __future__ import annotations

import pytest
from example_external import EchoAdapter

from gtv.adapters.conformance import run_adapter_conformance


@pytest.mark.asyncio
async def test_echo_adapter_conforms() -> None:
    adapter = EchoAdapter()
    try:
        await run_adapter_conformance(adapter)
    finally:
        await adapter.close()
