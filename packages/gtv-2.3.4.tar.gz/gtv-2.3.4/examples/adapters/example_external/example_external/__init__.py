"""Minimal out-of-tree gtv source adapter.

Demonstrates the shape of a third-party adapter. It intentionally does
nothing useful — it just echoes the claim text back as a single piece
of (stub) evidence — so you can copy this package, rename it, and
replace ``query`` with real upstream calls.
"""

from __future__ import annotations

import hashlib
from datetime import UTC, datetime

from gtv.adapters.sdk import (
    Claim,
    Evidence,
    HealthStatus,
    RawSnapshot,
    SourceAdapter,
    Stance,
    TrustTier,
)


class EchoAdapter(SourceAdapter):
    """Echo adapter — returns the claim text as a single stub Evidence item.

    This is the smallest possible adapter that satisfies the
    conformance suite. It is ``TrustTier.TIER_3`` because the output
    has no grounding in any external source.
    """

    source_did = "did:web:example-echo.invalid"
    name = "ExampleEcho"
    trust_tier = TrustTier.TIER_3
    freshness_sla_s = 3600

    async def query(self, claim: Claim, max_items: int = 5) -> list[Evidence]:
        body = f"echo: {claim.text}".encode()
        return [
            Evidence(
                claim_id=claim.claim_id,
                source_did=self.source_did,
                source_version="0.1.0",
                stance=Stance.NEUTRAL,
                excerpt=f"echo: {claim.text[:140]}",
                url="https://example.invalid/echo",
                retrieved_at=datetime.now(tz=UTC),
                raw_hash=hashlib.sha256(body).hexdigest(),
            )
        ]

    async def snapshot(self, url: str) -> RawSnapshot:
        content = b"echo adapter snapshot"
        return RawSnapshot(
            url=url,
            content=content,
            retrieved_at_iso=datetime.now(tz=UTC).isoformat(),
        )

    async def health(self) -> HealthStatus:
        return HealthStatus(state="HEALTHY", detail="echo adapter is always HEALTHY")

    async def close(self) -> None:
        return None
