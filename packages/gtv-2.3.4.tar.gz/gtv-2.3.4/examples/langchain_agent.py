"""LangChain agent that uses gtv as its fact-checking tool.

Run:
    pip install langchain langchain-openai langchain-core
    export OPENAI_API_KEY=sk-...
    # gtv-mcp running on localhost:8000
    python examples/langchain_agent.py "Claim text here"
"""
from __future__ import annotations

import asyncio
import sys

from gtv.bindings.langchain import make_retrieve_facts_tool, make_verify_claim_tool


async def run(claim: str, gtv_url: str = "http://localhost:8000") -> None:
    from langchain.agents import AgentExecutor, create_tool_calling_agent
    from langchain_core.prompts import ChatPromptTemplate
    from langchain_openai import ChatOpenAI

    tools = [
        make_verify_claim_tool(base_url=gtv_url),
        make_retrieve_facts_tool(base_url=gtv_url),
    ]

    prompt = ChatPromptTemplate.from_messages([
        ("system", "You are a rigorous fact-checker. Use gtv tools to verify claims."),
        ("human", "{input}"),
        ("placeholder", "{agent_scratchpad}"),
    ])

    llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)
    agent = create_tool_calling_agent(llm, tools, prompt)
    executor = AgentExecutor(agent=agent, tools=tools, verbose=True)

    result = await executor.ainvoke({"input": f"Please verify: {claim}"})
    print(result["output"])


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python examples/langchain_agent.py 'claim text'")
        sys.exit(2)
    asyncio.run(run(sys.argv[1]))
