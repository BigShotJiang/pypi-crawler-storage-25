"""OpenAI function-calling loop against a local gtv verifier.

Run:
    pip install openai
    export OPENAI_API_KEY=sk-...
    # gtv-mcp running on localhost:8000
    python examples/openai_agent.py "Claim text here"
"""
from __future__ import annotations

import asyncio
import sys

from gtv.bindings.client import GtvClient
from gtv.bindings.openai_tools import TOOLS, dispatch


async def run(claim: str, gtv_url: str = "http://localhost:8000") -> None:
    # openai is an optional dep — import here so this file is importable
    # without it installed (e.g. by the test collector).
    from openai import AsyncOpenAI

    llm = AsyncOpenAI()
    messages: list[dict] = [
        {"role": "system", "content": "You are a rigorous fact-checker. Call the gtv tools when a claim needs verification."},
        {"role": "user", "content": f"Please verify: {claim}"},
    ]

    async with GtvClient(gtv_url) as gtv:
        for _ in range(5):  # tool-loop cap
            resp = await llm.chat.completions.create(
                model="gpt-4o-mini",
                tools=TOOLS,
                messages=messages,
            )
            msg = resp.choices[0].message
            messages.append(msg.model_dump(exclude_none=True))

            if not msg.tool_calls:
                print(msg.content)
                return

            for call in msg.tool_calls:
                result = await dispatch(gtv, call.function.name, call.function.arguments)
                messages.append({
                    "role": "tool",
                    "tool_call_id": call.id,
                    "content": str(result),
                })


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python examples/openai_agent.py 'claim text'")
        sys.exit(2)
    asyncio.run(run(sys.argv[1]))
