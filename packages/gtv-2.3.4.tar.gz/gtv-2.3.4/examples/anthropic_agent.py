"""Anthropic tool-use loop against a local gtv verifier.

Run:
    pip install anthropic
    export ANTHROPIC_API_KEY=sk-ant-...
    # gtv-mcp running on localhost:8000
    python examples/anthropic_agent.py "Claim text here"
"""
from __future__ import annotations

import asyncio
import sys

from gtv.bindings.anthropic_tools import TOOLS, dispatch
from gtv.bindings.client import GtvClient


async def run(claim: str, gtv_url: str = "http://localhost:8000") -> None:
    from anthropic import AsyncAnthropic

    llm = AsyncAnthropic()
    messages: list[dict] = [
        {"role": "user", "content": f"Please verify: {claim}"},
    ]

    async with GtvClient(gtv_url) as gtv:
        for _ in range(5):  # tool-loop cap
            resp = await llm.messages.create(
                model="claude-3-5-sonnet-latest",
                max_tokens=1024,
                system="You are a rigorous fact-checker. Use the gtv tools to verify claims.",
                tools=TOOLS,
                messages=messages,
            )

            # Record the assistant turn
            messages.append({"role": "assistant", "content": resp.content})

            tool_uses = [b for b in resp.content if b.type == "tool_use"]
            if not tool_uses:
                # No more tool calls — print the final text and exit
                text = "".join(b.text for b in resp.content if b.type == "text")
                print(text)
                return

            tool_results = []
            for use in tool_uses:
                result = await dispatch(gtv, use.name, use.input)
                tool_results.append({
                    "type": "tool_result",
                    "tool_use_id": use.id,
                    "content": str(result),
                })
            messages.append({"role": "user", "content": tool_results})


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python examples/anthropic_agent.py 'claim text'")
        sys.exit(2)
    asyncio.run(run(sys.argv[1]))
