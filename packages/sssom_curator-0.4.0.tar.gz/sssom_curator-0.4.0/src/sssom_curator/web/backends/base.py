"""An abstract backend for the SSSOM Curator web application."""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections import Counter
from collections.abc import Iterable, Sequence

import curies
from curies import Reference
from sssom_pydantic import SemanticMapping
from sssom_pydantic.api import SemanticMappingHash, hash_mapping_to_reference
from sssom_pydantic.process import Mark
from sssom_pydantic.query import Query

from ..utils import PersistRemoteFailure, PersistRemoteSuccess, State, persist_remote
from ...repository import Repository

__all__ = [
    "Controller",
]


class Controller(ABC):
    """A module for interacting with mappings."""

    def __init__(
        self,
        *,
        repository: Repository,
        semantic_mapping_hash: SemanticMappingHash | None = None,
        converter: curies.Converter,
        target_references: Iterable[Reference] | None = None,
        add_date: bool = True,
    ) -> None:
        """Initialize the controller."""
        self.repository = repository
        self._mapping_hash = semantic_mapping_hash or hash_mapping_to_reference
        self.converter = converter
        self.total_curated = 0
        self.target_references = set(target_references) if target_references is not None else None
        self.add_date = add_date

    def mapping_hash(self, mapping: SemanticMapping) -> Reference:
        """Get the hash of a mapping."""
        return self._mapping_hash(mapping, self.converter)

    @abstractmethod
    def get_prefix_counter(self, state: State | None = None) -> Counter[tuple[str, str]]:
        """Get a subject/object prefix counter."""

    @abstractmethod
    def get_predictions(self, state: State | None = None) -> Sequence[SemanticMapping]:
        """Get predicted semantic mappings."""

    @abstractmethod
    def count_predictions(self, query: Query | None = None) -> int:
        """Count the number of predictions to check for the given filters."""

    @abstractmethod
    def mark(self, reference: Reference, mark: Mark, authors: Reference | list[Reference]) -> None:
        """Mark the given mapping as correct."""

    @abstractmethod
    def count_unpersisted(self) -> int:
        """Count the number of unpersisted curations."""

    @abstractmethod
    def persist(self) -> None:
        """Mark the given mapping as correct."""

    def count_remote_unpersisted(self) -> int:
        """Count the number of curations that haven't been persisted to a remote repository."""
        return self.total_curated

    def persist_remote(self, author: Reference) -> PersistRemoteSuccess | PersistRemoteFailure:
        """Persist remotely."""
        label = "mappings" if self.total_curated > 1 else "mapping"
        commit_message = f"Curated {self.total_curated:,} {label} ({author.curie})"
        match persist_remote(self.repository.predictions_path.parent, commit_message):
            case PersistRemoteSuccess() as rv:
                self.total_curated = 0
                return rv
            case PersistRemoteFailure() as rv:
                return rv
