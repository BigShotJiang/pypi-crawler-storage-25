from setuptools import setup
import os

# Read README.md for the long description if it exists
long_description = ""
if os.path.exists("README.md"):
    with open("README.md", "r", encoding="utf-8") as f:
        long_description = f.read()

setup(
    name='avix-engine',
    version='1.0.1',
    description='AVIX: The Ultra-Premium Archival Trust Format with SHA-256 Integrity Sentry.',
    long_description=long_description,
    long_description_content_type='text/markdown',
    author='Escrawl Products',
    author_email='contact@escrawl.com',
    url='https://github.com/escrawl/avix-engine', # Update with actual URL when launched
    py_modules=['avix', 'image_pixel_converter', 'cli'], # Exposes the new 'avix' import interface
    license_files=[], # Bypasses setuptools License-File metadata generation bug
    entry_points={
        'console_scripts': [
            'avix=cli:main',
        ],
    },
    install_requires=[
        'numpy>=1.21.0',
        'Pillow>=9.0.0',
        'zstandard>=0.19.0',
        'numba>=0.56.0'
    ],
    extras_require={
        'gpu': ['cupy>=10.0.0'] # Optional hybrid GPU acceleration
    },
    classifiers=[
        'Development Status :: 5 - Production/Stable',
        'Intended Audience :: Developers',
        'Intended Audience :: Healthcare Industry',
        'Intended Audience :: Science/Research',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Topic :: Multimedia :: Graphics :: Graphics Conversion',
        'Topic :: Scientific/Engineering :: Image Processing',
    ],
    python_requires='>=3.8',
    keywords='image compression lossless avix archival medical medical-imaging',
)
