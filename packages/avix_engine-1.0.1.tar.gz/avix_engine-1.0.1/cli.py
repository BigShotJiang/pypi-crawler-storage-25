"""
AVIX CLI: The Command Line Interface for the Archival Trust Format
-----------------------------------------------------------------

Usage:
  avix compress <input_image> <output_avix> [--mode archival|standard]
  avix decompress <input_avix> <output_image>
  avix info <input_avix>
"""

import sys
import os
import argparse
import time
from PIL import Image
import avix

# Gorgeous ANSI colors for CLI feedback
GREEN = "\033[92m"
BLUE = "\033[94m"
YELLOW = "\033[93m"
RED = "\033[91m"
RESET = "\033[0m"
BOLD = "\033[1m"

def print_banner():
    banner = rf"""{BLUE}{BOLD}
    _    __     _______  __
   / \   \ \   / /_ _\ \/ /
  / _ \   \ \ / / | | \  / 
 / ___ \   \ V /  | | /  \ 
/_/   \_\   \_/  |___/_/\_\
   The Archival Trust Format{RESET}
    """
    print(banner)

def main():
    parser = argparse.ArgumentParser(description="AVIX CLI: Archival Trust Image Format Tool")
    subparsers = parser.add_subparsers(dest="command", help="Available subcommands")

    # Compress Parser
    compress_parser = subparsers.add_parser("compress", help="Compress an image to .avix format")
    compress_parser.add_argument("input_image", help="Path to input image (PNG, TIFF, JPEG)")
    compress_parser.add_argument("output_avix", help="Path to save compressed .avix file")
    compress_parser.add_argument("--mode", choices=["archival", "standard"], default="archival", 
                                 help="Compression mode ('archival' is high ratio, 'standard' is fast)")

    # Decompress Parser
    decompress_parser = subparsers.add_parser("decompress", help="Decompress an .avix file back to an image")
    decompress_parser.add_argument("input_avix", help="Path to input .avix file")
    decompress_parser.add_argument("output_image", help="Path to save decompressed image")

    # Info Parser
    info_parser = subparsers.add_parser("info", help="Inspect .avix file metadata and verify integrity")
    info_parser.add_argument("input_avix", help="Path to input .avix file")

    if len(sys.argv) == 1:
        print_banner()
        parser.print_help()
        sys.exit(0)

    args = parser.parse_args()

    if args.command == "compress":
        print(f"\n{BLUE}[*] Compressing '{args.input_image}' to '{args.output_avix}' using mode '{args.mode}'...{RESET}")
        start_time = time.time()
        try:
            success = avix.encode(args.input_image, args.output_avix, mode=args.mode)
            if success:
                elapsed = time.time() - start_time
                orig_size = os.path.getsize(args.input_image)
                new_size = os.path.getsize(args.output_avix)
                ratio = (orig_size / new_size) if new_size > 0 else 1.0
                print(f"{GREEN}[+] Compression Complete! ({elapsed:.2f}s){RESET}")
                print(f"    Original Size:  {orig_size / 1024:.2f} KB")
                print(f"    AVIX Size:      {new_size / 1024:.2f} KB")
                print(f"    Space Saved:    {((orig_size - new_size) / orig_size) * 100:.2f}% (Ratio: {ratio:.2f}x)")
            else:
                print(f"{RED}[-] Compression failed.{RESET}")
        except Exception as e:
            print(f"{RED}[-] Error during compression: {e}{RESET}")

    elif args.command == "decompress":
        print(f"\n{BLUE}[*] Decompressing '{args.input_avix}' to '{args.output_image}'...{RESET}")
        start_time = time.time()
        try:
            # We first decode the image into memory
            img = avix.decode(args.input_avix)
            if img:
                img.save(args.output_image)
                elapsed = time.time() - start_time
                print(f"{GREEN}[+] Decompression & Integrity Check Successful! ({elapsed:.2f}s){RESET}")
                print(f"    Saved as: {args.output_image}")
            else:
                print(f"{RED}[-] Decompression failed (invalid file).{RESET}")
        except Exception as e:
            print(f"{RED}[-] INTEGRITY FAULT DETECTED: {e}{RESET}")

    elif args.command == "info":
        print_banner()
        print(f"{BLUE}[*] Inspecting file: {args.input_avix}...{RESET}")
        if not os.path.exists(args.input_avix):
            print(f"{RED}[-] File does not exist.{RESET}")
            sys.exit(1)

        try:
            # Check SHA-256 integrity dynamically first
            with open(args.input_avix, 'rb') as f:
                data = f.read()

            is_sealed = False
            has_corrupt = False
            if len(data) > 36 and data[-36:-32] == b"SHA2":
                is_sealed = True
                import hashlib
                expected_hash = data[-32:]
                actual_hash = hashlib.sha256(data[:-36]).digest()
                if expected_hash != actual_hash:
                    has_corrupt = True

            # Extract dimensions and metadata without full payload decompression
            magic = data[:4]
            if magic == b"AVXT":
                version = data[4]
                width = int.from_bytes(data[5:7], 'big')
                height = int.from_bytes(data[7:9], 'big')
                channels = data[9]
                print(f"\n{BOLD}AVIX File Information:{RESET}")
                print(f"  Format:           {GREEN}Unified Tiled Format v{version}{RESET}")
                print(f"  Dimensions:       {width} x {height}")
                print(f"  Channels:         {channels} ({'RGBA' if channels==4 else 'RGB'})")
                
                # Integrity State
                if is_sealed:
                    if has_corrupt:
                        print(f"  Integrity State:  {RED}{BOLD}[!] DAMAGED / CORRUPTED (SHA-256 Sentry Mismatch){RESET}")
                    else:
                        print(f"  Integrity State:  {GREEN}[v] SECURE & MATHEMATICALLY VERIFIED{RESET}")
                else:
                    print(f"  Integrity State:  {YELLOW}[?] UNSEALED LEGACY FORMAT{RESET}")
            else:
                print(f"\n{BOLD}AVIX File Information:{RESET}")
                print(f"  Format:           {YELLOW}Legacy Single-Block format ({magic.decode('utf-8', errors='ignore')}){RESET}")

        except Exception as e:
            print(f"{RED}[-] Error parsing file: {e}{RESET}")

if __name__ == "__main__":
    main()
