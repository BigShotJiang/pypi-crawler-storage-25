"""
AVIX Engine: The Ultra-Premium Archival Trust Format
----------------------------------------------------

This module exposes the official AVIX encoding and decoding interfaces for Python developers.
"""

from image_pixel_converter import (
    compress_avix as encode,
    decompress_avix as decode_to_file,
    decompress_avix_to_image as decode,
    extract_avix_thumbnail as extract_thumbnail,
    NUMBA_AVAILABLE,
    GPU_AVAILABLE
)

__version__ = "1.0.0"
__all__ = ['encode', 'decode', 'decode_to_file', 'extract_thumbnail', 'NUMBA_AVAILABLE', 'GPU_AVAILABLE']
