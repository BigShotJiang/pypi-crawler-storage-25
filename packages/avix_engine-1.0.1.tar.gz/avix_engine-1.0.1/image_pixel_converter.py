import numpy as np
from PIL import Image
import os
import sys
import time
import io
import concurrent.futures
try:
    import zstandard as zstd
except ImportError:
    zstd = None

# Hybrid GPU Probing
try:
    import cupy as cp
    GPU_AVAILABLE = True
except ImportError:
    cp = None
    GPU_AVAILABLE = False

# Numba JIT Core (Replaces the C++ DLL for true 64-bit cross-platform native speed)
try:
    import numba
    from numba import njit, prange
    NUMBA_AVAILABLE = True
    
    @njit(parallel=True, fastmath=True)
    def numba_encode_left(pixels, out):
        h, w, c = pixels.shape
        for i in prange(h):
            for j in range(w):
                for k in range(c):
                    if i == 0 and j == 0:
                        out[0, 0, k] = (pixels[0, 0, k] - 128) % 256
                    elif j == 0:
                        out[i, 0, k] = (pixels[i, 0, k] - pixels[i-1, 0, k]) % 256
                    else:
                        out[i, j, k] = (pixels[i, j, k] - pixels[i, j-1, k]) % 256

    @njit(parallel=True, fastmath=True)
    def numba_decode_left(res, out):
        h, w, c = res.shape
        for k in prange(c):
            out[0, 0, k] = (res[0, 0, k] + 128) % 256
            for i in range(1, h):
                out[i, 0, k] = (res[i, 0, k] + out[i-1, 0, k]) % 256
            for i in range(h):
                for j in range(1, w):
                    out[i, j, k] = (res[i, j, k] + out[i, j-1, k]) % 256

    @njit(parallel=True, fastmath=True)
    def numba_encode_up(pixels, out):
        h, w, c = pixels.shape
        for j in prange(w):
            for i in range(h):
                for k in range(c):
                    if i == 0 and j == 0:
                        out[0, 0, k] = (pixels[0, 0, k] - 128) % 256
                    elif i == 0:
                        out[0, j, k] = (pixels[0, j, k] - pixels[0, j-1, k]) % 256
                    else:
                        out[i, j, k] = (pixels[i, j, k] - pixels[i-1, j, k]) % 256
                        
    @njit(parallel=True, fastmath=True)
    def numba_decode_up(res, out):
        h, w, c = res.shape
        for k in prange(c):
            out[0, 0, k] = (res[0, 0, k] + 128) % 256
            for j in range(1, w):
                out[0, j, k] = (res[0, j, k] + out[0, j-1, k]) % 256
            for j in range(w):
                for i in range(1, h):
                    out[i, j, k] = (res[i, j, k] + out[i-1, j, k]) % 256

    @njit(parallel=True, fastmath=True)
    def numba_encode_paeth(pixels, out):
        h, w, c = pixels.shape
        for k in prange(c):
            out[0, 0, k] = (pixels[0, 0, k] - 128) % 256
            for j in range(1, w):
                out[0, j, k] = (pixels[0, j, k] - pixels[0, j-1, k]) % 256
            for i in range(1, h):
                out[i, 0, k] = (pixels[i, 0, k] - pixels[i-1, 0, k]) % 256
                for j in range(1, w):
                    a = int(pixels[i, j-1, k])
                    b = int(pixels[i-1, j, k])
                    cc = int(pixels[i-1, j-1, k])
                    p = a + b - cc
                    pa = abs(p - a)
                    pb = abs(p - b)
                    pc = abs(p - cc)
                    if pa <= pb and pa <= pc:
                        pred = a
                    elif pb <= pc:
                        pred = b
                    else:
                        pred = cc
                    out[i, j, k] = (pixels[i, j, k] - pred) % 256

    @njit(parallel=True, fastmath=True)
    def numba_decode_paeth(res, out):
        h, w, c = res.shape
        for k in prange(c):
            out[0, 0, k] = (res[0, 0, k] + 128) % 256
            for j in range(1, w):
                out[0, j, k] = (res[0, j, k] + out[0, j-1, k]) % 256
            for i in range(1, h):
                out[i, 0, k] = (res[i, 0, k] + out[i-1, 0, k]) % 256
                for j in range(1, w):
                    a = int(out[i, j-1, k])
                    b = int(out[i-1, j, k])
                    cc = int(out[i-1, j-1, k])
                    p = a + b - cc
                    pa = abs(p - a)
                    pb = abs(p - b)
                    pc = abs(p - cc)
                    if pa <= pb and pa <= pc:
                        pred = a
                    elif pb <= pc:
                        pred = b
                    else:
                        pred = cc
                    out[i, j, k] = (res[i, j, k] + pred) % 256

    # Remove the old c_core references
    avix_c_core = None

except ImportError:
    NUMBA_AVAILABLE = False
    avix_c_core = None

def load_image(file_path):
    """
    Load an image file and preserve its transparency (RGBA) if present.
    """
    try:
        img = Image.open(file_path)
        # If image has alpha or is palette-based with transparency, use RGBA
        if img.mode in ("RGBA", "LA") or (img.mode == "P" and "transparency" in img.info):
            return img.convert("RGBA")
        return img.convert("RGB")
    except Exception as e:
        print(f"Error loading image: {e}")
        return None

def image_to_pixels(image):
    """
    Convert image into a 2D array of pixels where each pixel is represented as [R, G, B].
    
    Args:
        image (PIL.Image.Image): The input image.
        
    Returns:
        numpy.ndarray: A 3D array of shape (height, width, 3) containing RGB values.
                       Note: Technically this is a 3D array where the 3rd dimension is the RGB vector.
                       If a strictly 2D array of objects/tuples is needed, we could restructure, 
                       but standard numpy representation (H, W, 3) is best for pixel manipulation.
    """
    # Convert image to numpy array.
    # Dimensions will be (Height, Width, 3) 
    pixels = np.array(image)
    return pixels

def pixels_to_binary(pixels):
    """
    Convert pixel array into raw binary bytes using RGB byte mapping.
    
    Args:
        pixels (numpy.ndarray): The 3D array of pixels (Height, Width, 3).
        
    Returns:
        bytes: Raw binary data of the pixels.
    """
    # Ensure data type is uint8 (0-255)
    pixels_uint8 = pixels.astype(np.uint8)
    # Convert to bytes
    return pixels_uint8.tobytes()

def save_binary(data, file_path):
    """
    Save the binary pixel data into a .bin file.
    
    Args:
        data (bytes): The binary data to save.
        file_path (str): The destination file path.
    """
    try:
        with open(file_path, 'wb') as f:
            f.write(data)
        print(f"Successfully saved binary data to {file_path}")
    except Exception as e:
        print(f"Error saving binary file: {e}")

def load_binary(file_path):
    """
    Read binary pixel data from a .bin file.
    
    Args:
        file_path (str): Path to the binary file.
        
    Returns:
        bytes: The binary data read from the file.
    """
    try:
        with open(file_path, 'rb') as f:
            data = f.read()
        return data
    except Exception as e:
        print(f"Error loading binary file: {e}")
        return None

def binary_to_image(binary_data, width, height):
    """
    Reconstruct the original image from binary pixel data using known width and height.
    
    Args:
        binary_data (bytes): Raw binary pixel data.
        width (int): Width of the original image.
        height (int): Height of the original image.
        
    Returns:
        PIL.Image.Image: The reconstructed image.
    """
    try:
        # Calculate expected number of bytes
        expected_bytes = width * height * 3
        if len(binary_data) != expected_bytes:
            print(f"Error: Data length ({len(binary_data)}) does not match expected size for {width}x{height} image ({expected_bytes}).")
            return None
            
        # Convert bytes back to numpy array
        # frombuffer is efficient and creates a read-only array, copying might be safer if we want to modify
        pixels = np.frombuffer(binary_data, dtype=np.uint8)
        
        # Reshape to (Height, Width, 3)
        pixels_reshaped = pixels.reshape((height, width, 3))
        
        # Create PIL Image from array
        image = Image.fromarray(pixels_reshaped, 'RGB')
        return image
    except Exception as e:
        print(f"Error reconstructing image: {e}")
        return None

def create_sample_image(path):
    """Creates a sample image for demonstration purposes."""
    # Create a 100x100 image with a gradient or pattern
    width, height = 100, 100
    array = np.zeros((height, width, 3), dtype=np.uint8)
    
    # Fill with a simple pattern
    for y in range(height):
        for x in range(width):
            array[y, x] = [x % 256, y % 256, (x + y) % 256]
            
    img = Image.fromarray(array, 'RGB')
    img.save(path)
    print(f"Created sample image at {path}")
    return width, height

def verify_identical(img1, img2):
    """Verifies if two images are identical."""
    arr1 = np.array(img1)
    arr2 = np.array(img2)
    return np.array_equal(arr1, arr2)

def calculate_storage_size(data):
    """
    Calculate storage size in bytes for data.
    
    Args:
        data (bytes or str): The data or file path to measure.
        
    Returns:
        int: Size in bytes.
    """
    if isinstance(data, str) and os.path.exists(data):
        return os.path.getsize(data)
    elif isinstance(data, (bytes, bytearray)):
        return len(data)
    return 0

def compare_pixel_similarity(p1, p2, tolerance):
    """
    Determine whether two RGB pixels are approximately equal based on tolerance.
    
    Args:
        p1 (numpy.ndarray): Pixel [R, G, B]
        p2 (numpy.ndarray): Pixel [R, G, B]
        tolerance (int): Max difference allowed per channel.
        
    Returns:
        bool: True if similar.
    """
    # Cast to int to avoid uint8 overflow/wrapping during subtraction
    return np.all(np.abs(p1.astype(int) - p2.astype(int)) <= tolerance)

def pixels_to_rle(pixels, tolerance=0):
    """
    Convert pixel array into RLE format storing (pixel_value, count) pairs.
    Binary Format per run: R(1) G(1) B(1) Count(2) = 5 bytes.
    
    Args:
        pixels (numpy.ndarray): The 3D array of pixels (Height, Width, 3).
        tolerance (int): pixel matching tolerance.
        
    Returns:
        bytes: RLE compressed binary data.
    """
    flat_pixels = pixels.reshape(-1, 3)
    if len(flat_pixels) == 0:
        return b""
        
    rle_data = bytearray()
    current_pixel = flat_pixels[0]
    count = 1
    
    for i in range(1, len(flat_pixels)):
        next_pixel = flat_pixels[i]
        
        # Check similarity
        # If tolerance is 0, we can use simple equality for speed
        if tolerance == 0:
            match = np.array_equal(current_pixel, next_pixel)
        else:
            match = compare_pixel_similarity(current_pixel, next_pixel, tolerance)
            
        if match and count < 65535:
            count += 1
        else:
            # Append current run
            rle_data.extend(current_pixel.astype(np.uint8).tobytes())
            rle_data.extend(int(count).to_bytes(2, byteorder='big'))
            
            # Reset
            current_pixel = next_pixel
            count = 1
            
    # Append last run
    rle_data.extend(current_pixel.astype(np.uint8).tobytes())
    rle_data.extend(int(count).to_bytes(2, byteorder='big'))
    
    return bytes(rle_data)

def rle_to_pixels(rle_data, width, height):
    """
    Reconstruct the original pixel sequence from RLE-compressed data.
    
    Args:
        rle_data (bytes): RLE compressed binary data.
        width (int): Image width.
        height (int): Image height.
        
    Returns:
        numpy.ndarray: 3D array of pixels (Height, Width, 3).
    """
    try:
        expected_pixels = width * height
        pixels = np.zeros((expected_pixels, 3), dtype=np.uint8)
        
        offset = 0
        current_pixel_idx = 0
        
        data_len = len(rle_data)
        
        while offset + 5 <= data_len:
            # Read R, G, B
            r = rle_data[offset]
            g = rle_data[offset+1]
            b = rle_data[offset+2]
            # Read Count (2 bytes)
            count = int.from_bytes(rle_data[offset:offset+5][3:5], byteorder='big')
            offset += 5
            
            # Fill array
            end_idx = current_pixel_idx + count
            if end_idx > expected_pixels:
                end_idx = expected_pixels

            pixels[current_pixel_idx:end_idx] = [r, g, b]
            current_pixel_idx += count
            if current_pixel_idx >= expected_pixels:
                break
            
        return pixels.reshape((height, width, 3))
    except Exception as e:
        print(f"Error decoding RLE: {e}")
        return None

# --- Palette Based Compression ---

def extract_palette(pixels):
    """
    Extract unique pixel palette and map each pixel to a palette index.
    
    Args:
        pixels (numpy.ndarray): The 3D array of pixels (Height, Width, 3).
        
    Returns:
        tuple: (palette, indices)
            palette: numpy array of unique RGB colors (N, 3)
            indices: numpy array of indices mapping original pixels to palette (Height*Width,)
            
    Note: 'indices' will generally be smaller int types (uint8, uint16, etc) depending on palette size.
    """
    # Flatten pixels to (N, 3)
    flat_pixels = pixels.reshape(-1, 3)
    
    # Find unique rows (colors) and inverse indices
    # axis=0 means treat rows as elements
    palette, indices = np.unique(flat_pixels, axis=0, return_inverse=True)
    
    return palette, indices

def rle_encode_indices(indices):
    """
    Apply RLE to the palette index sequence.
    Vectorized via NumPy for high speed.
    """
    if len(indices) == 0:
        return b""
        
    # 1. Detect changes in the index stream
    changes = np.where(indices[1:] != indices[:-1])[0] + 1
    starts = np.concatenate(([0], changes))
    ends = np.concatenate((changes, [len(indices)]))
    
    run_values = indices[starts]
    run_lengths = ends - starts
    
    # 2. Determine index byte size
    max_index = np.max(run_values)
    if max_index < 256:
        index_bytes = 1
        idx_dtype = np.uint8
    elif max_index < 65536:
        index_bytes = 2
        idx_dtype = '>u2'
    else:
        index_bytes = 4
        idx_dtype = '>u4'
        
    # 3. Handle runs longer than 65535
    if np.any(run_lengths > 65535):
        new_values = []
        new_lengths = []
        for val, length in zip(run_values, run_lengths):
            while length > 65535:
                new_values.append(val)
                new_lengths.append(65535)
                length -= 65535
            new_values.append(val)
            new_lengths.append(length)
        run_values = np.array(new_values, dtype=indices.dtype)
        run_lengths = np.array(new_lengths, dtype=np.uint16)
    else:
        run_values = run_values.astype(indices.dtype)
        run_lengths = run_lengths.astype(np.uint16)

    # 4. Binary construction
    res = bytearray([index_bytes])
    total_runs = len(run_values)
    lengths_bin = run_lengths.astype('>u2').tobytes()
    values_bin = run_values.astype(idx_dtype).tobytes()
    
    for i in range(total_runs):
        res.extend(values_bin[i*index_bytes : (i+1)*index_bytes])
        res.extend(lengths_bin[i*2 : (i+1)*2])
        
    return bytes(res)
def rle_decode_indices(rle_data, total_pixels):
    """
    Reconstruct the palette index sequence from RLE encoded data.
    Optimized via NumPy indexing.
    """
    if len(rle_data) == 0:
        return np.array([], dtype=int)
        
    index_bytes = rle_data[0]
    entry_size = index_bytes + 2
    
    # Bulk read all data
    payload = np.frombuffer(rle_data[1:], dtype=np.uint8)
    num_entries = len(payload) // entry_size
    
    # Reshape to easily extract columns
    rows = payload[:num_entries * entry_size].reshape((num_entries, entry_size))
    
    # Extract Counts (last 2 bytes of each row)
    counts_raw = rows[:, -2:].copy().view('>u2').reshape(-1)
    
    # Extract Indices (first bytes of each row)
    if index_bytes == 1:
        indices_raw = rows[:, 0].astype(int)
    elif index_bytes == 2:
        indices_raw = rows[:, :2].copy().view('>u2').reshape(-1).astype(int)
    else:
        indices_raw = rows[:, :4].copy().view('>u4').reshape(-1).astype(int)
        
    # Reconstruct the sequence using np.repeat
    return np.repeat(indices_raw, counts_raw)

def palette_indices_to_pixels(indices, palette, width, height):
    """
    Reconstruct pixels from indices and palette.
    
    Args:
        indices (numpy.ndarray): 1D array of indices.
        palette (numpy.ndarray): Palette array (N, 3).
        width, height: stored image dims.
        
    Returns:
        numpy.ndarray: Reconstructed 3D pixel array.
    """
    # Simply lookup indices in palette
    pixels_flat = palette[indices]
    return pixels_flat.reshape((height, width, 3))

def pixels_to_differential(pixels):
    """
    Encode pixels with differential residuals (Sub/Left prediction + Up prediction).
    Optimized via slicing to avoid large memory allocations.
    """
    h, w, c = pixels.shape
    # Use int16 to handle subtractions without underflow before modulo
    res = pixels.astype(np.int16)
    
    # Horizontal prediction (Left)
    res[:, 1:] -= pixels[:, :-1]
    # Vertical prediction for first column (Up)
    res[1:, 0] -= pixels[:-1, 0]
    # Anchor point
    res[0, 0] -= 128
    
    return (res % 256).astype(np.uint8)

def differential_to_pixels(residuals, width, height):
    """
    Reconstruct original pixels from differential residuals losslessly.
    """
    if not residuals.flags.writeable:
        residuals = residuals.copy()
        
    residuals[0, 0] = (residuals[0, 0].astype(np.int16) + 128) % 256
    
    # Calculate column 0
    residuals[:, 0] = np.cumsum(residuals[:, 0], axis=0, dtype=np.uint8)
    
    # Optimize axis 1 cumsum via contiguous transpose
    res_t = np.ascontiguousarray(residuals.transpose(2, 0, 1))
    pixels_t = np.cumsum(res_t, axis=2, dtype=np.uint8)
    pixels = pixels_t.transpose(1, 2, 0)
    return pixels




def adaptive_compress(pixels):
    """
    Analyzes the image to select the best compression strategy based on its properties:
    - Low noise/gradient (screenshots, cartoons): uses palette/RLE.
    - High noise/gradient (photographs): uses differential residuals.
    """
    # 1. Count unique colors
    flat_pixels = pixels.reshape(-1, 3)
    unique_colors = len(np.unique(flat_pixels, axis=0))
    
    # If the image has a limited number of colors, treat it as low gradient/noise
    if unique_colors <= 2048:
        image_type = "Low gradient/noise (Screenshot, Cartoon)"
        recommended_strategy = "Palette + RLE"
    else:
        image_type = "High gradient/noise (Photograph)"
        recommended_strategy = "Differential Encoding"
        
    return image_type, recommended_strategy

def get_fast_palette_info(pixel_array):
    """
    Rapidly extract palette info using 32-bit integer views.
    Handles both RGB (3) and RGBA (4) channels.
    """
    h, w, c = pixel_array.shape
    if c == 3:
        padded = np.zeros((h, w, 4), dtype=np.uint8)
        padded[..., :3] = pixel_array
        flat_32 = padded.view(np.uint32).reshape(-1)
    else:
        # RGBA is already 4 bytes
        flat_32 = np.ascontiguousarray(pixel_array).view(np.uint32).reshape(-1)
    
    palette_32, indices = np.unique(flat_32, return_inverse=True)
    
    if len(palette_32) > 65536:
        return None, None
        
    # Convert back
    if c == 3:
        palette_out = palette_32.view(np.uint8).reshape(-1, 4)[:, :3]
    else:
        palette_out = palette_32.view(np.uint8).reshape(-1, 4)
    return palette_out, indices

def compress_avix(image_source, output_path, mode='archival'):
    """
    Compress an image into .avix format using Block-Based Tiling (AVXT).
    Tiles are 1024x1024 for optimal memory/CPU balance.
    """
    global GPU_AVAILABLE
    if isinstance(image_source, str):
        img = load_image(image_source)
    else:
        img = image_source
        
    if img is None:
        return False
        
    width, height = img.size
    pixel_array = image_to_pixels(img)
    channels = pixel_array.shape[2]
    
    # 1. Generate Embedded Thumbnail (128px max)
    thumb_size_limit = 128
    thumb_img = img.copy()
    thumb_img.thumbnail((thumb_size_limit, thumb_size_limit))
    thumb_io = io.BytesIO()
    thumb_img.convert("RGB").save(thumb_io, format="JPEG", quality=85)
    thumb_data = thumb_io.getvalue()
    thumb_len = len(thumb_data)

    # 2. Extract and Serialize Metadata
    metadata = {}
    try:
        # Extract basic info and EXIF
        if hasattr(img, 'info'):
            for k, v in img.info.items():
                if isinstance(v, (str, int, float, bool)):
                    metadata[f"info_{k}"] = v
        
        exif = img.getexif()
        if exif:
            from PIL.ExifTags import TAGS
            for tag_id, value in exif.items():
                tag_name = TAGS.get(tag_id, tag_id)
                if isinstance(value, (str, int, float, bool)):
                    metadata[f"exif_{tag_name}"] = value
    except:
        pass
        
    import json
    meta_json = json.dumps(metadata).encode('utf-8')
    meta_len = len(meta_json)

    # 3. Tile-Based Compression
    tile_size = 1024
    tiles_data = bytearray()
    
    zstd_level = 22 if mode == 'archival' else 3
    final_ctx = zstd.ZstdCompressor(level=zstd_level, threads=-1)
    trial_ctx = zstd.ZstdCompressor(level=1)
    
    def _compress_tile(args):
        y, x, tile_w, tile_h, tile = args
        local_trial_ctx = zstd.ZstdCompressor(level=1)
        local_final_ctx = zstd.ZstdCompressor(level=zstd_level)
        
        # --- HYBRID GPU MATH ---
        gpu_ok = GPU_AVAILABLE
        if gpu_ok:
            try:
                # Move tile to VRAM
                gtile = cp.array(tile, dtype=cp.uint8)
                gdecorr = gtile.copy()
                
                if channels >= 3:
                    gg = gtile[..., 1]
                    gdecorr[..., 0] = (gtile[..., 0].astype(cp.int16) - gg) % 256
                    gdecorr[..., 2] = (gtile[..., 2].astype(cp.int16) - gg) % 256
                
                # AVX2: Left
                gres_left = cp.zeros_like(gdecorr)
                gres_left[:, 1:, :] = (gdecorr[:, 1:, :].astype(cp.int16) - gdecorr[:, :-1, :].astype(cp.int16)) % 256
                gres_left[:, 0, :] = (gdecorr[:, 0, :].astype(cp.int16) - 128) % 256
                
                # AVX3: Up
                gres_up = gdecorr.astype(cp.int16)
                gres_up[1:, :] -= gdecorr[:-1, :]
                gres_up[0, 1:] -= gdecorr[0, :-1]
                gres_up[0, 0] -= 128
                gres_up = (gres_up % 256).astype(cp.uint8)
                
                # Pull results back to CPU for Zstd
                decorr = gdecorr.get()
                candidates = {
                    b"AVX2": cp.ascontiguousarray(gres_left.transpose(2, 0, 1)).get().tobytes(),
                    b"AVX3": cp.ascontiguousarray(gres_up.transpose(2, 0, 1)).get().tobytes(),
                    b"AVX4": cp.ascontiguousarray(gdecorr.transpose(2, 0, 1)).get().tobytes()
                }
            except:
                gpu_ok = False
        
        if not gpu_ok:
            # Optimized CPU Logic
            decorr = tile.copy()
            if channels >= 3:
                g = tile[..., 1]
                decorr[..., 0] = (tile[..., 0].astype(np.int16) - g) % 256
                decorr[..., 2] = (tile[..., 2].astype(np.int16) - g) % 256
            
            if NUMBA_AVAILABLE:
                # Numba JIT PATH (Ultimate 64-bit Native CPU Speed)
                decorr_contig = np.ascontiguousarray(decorr)
                res_left = np.zeros_like(decorr_contig)
                res_up = np.zeros_like(decorr_contig)
                res_paeth = np.zeros_like(decorr_contig)
                
                numba_encode_left(decorr_contig, res_left)
                numba_encode_up(decorr_contig, res_up)
                numba_encode_paeth(decorr_contig, res_paeth)
                
                candidates = {
                    b"AVX2": np.ascontiguousarray(res_left.transpose(2, 0, 1)).tobytes(),
                    b"AVX3": np.ascontiguousarray(res_up.transpose(2, 0, 1)).tobytes(),
                    b"AVX6": np.ascontiguousarray(res_paeth.transpose(2, 0, 1)).tobytes(),
                    b"AVX4": np.ascontiguousarray(decorr_contig.transpose(2, 0, 1)).tobytes()
                }
            else:
                # Pure NumPy Fallback
                candidates = {
                    b"AVX2": np.ascontiguousarray(pixels_to_differential(decorr).transpose(2, 0, 1)).tobytes(),
                    b"AVX4": np.ascontiguousarray(decorr.transpose(2, 0, 1)).tobytes()
                }
                res_up = decorr.astype(np.int16)
                res_up[1:, :] -= decorr[:-1, :]
                res_up[0, 1:] -= decorr[0, :-1]
                res_up[0, 0] -= 128
                candidates[b"AVX3"] = np.ascontiguousarray((res_up % 256).astype(np.uint8).transpose(2, 0, 1)).tobytes()
        
        # AVX5 (Always CPU-based for small-scale palette logic)
        pal, idxs = get_fast_palette_info(tile)
        if pal is not None:
            rle = rle_encode_indices(idxs)
            candidates[b"AVX5"] = len(pal).to_bytes(4, 'big') + pal.astype(np.uint8).tobytes() + rle
            
        results = []
        for m, d in candidates.items():
            results.append((m, len(local_trial_ctx.compress(d))))
        
        best_m, _ = min(results, key=lambda x: x[1])
        best_p = local_final_ctx.compress(candidates[best_m])
        
        return best_m + len(best_p).to_bytes(4, 'big') + best_p

    # Build argument list
    tile_args = []
    for y in range(0, height, tile_size):
        for x in range(0, width, tile_size):
            tile_w = min(tile_size, width - x)
            tile_h = min(tile_size, height - y)
            tile = pixel_array[y:y+tile_h, x:x+tile_w]
            tile_args.append((y, x, tile_w, tile_h, tile))

    # Execute massively in parallel using 100% of the CPU
    import concurrent.futures
    import os
    max_w = os.cpu_count() or 4
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_w) as executor:
        for tile_bytes in executor.map(_compress_tile, tile_args):
            tiles_data.extend(tile_bytes)
    
    # 4. Final File Construction (Unified Header v2)
    # [Magic:4][Ver:1][W:2][H:2][C:1][Flags:1][ThumbLen:4][ThumbData][MetaLen:4][MetaData][TileSize:2]
    version = 2
    flags = 0 # Reserved for future (Encryption, etc.)
    
    header = (
        b"AVXT" + 
        int(version).to_bytes(1, 'big') +
        int(width).to_bytes(2, 'big') + 
        int(height).to_bytes(2, 'big') + 
        int(channels).to_bytes(1, 'big') +
        int(flags).to_bytes(1, 'big') +
        int(thumb_len).to_bytes(4, 'big') +
        thumb_data +
        int(meta_len).to_bytes(4, 'big') +
        meta_json +
        int(tile_size).to_bytes(2, 'big')
    )
    
    # --- SHA-256 INTEGRITY SENTRY ---
    import hashlib
    file_payload = header + tiles_data
    sentry_hash = hashlib.sha256(file_payload).digest()
    sentry_footer = b"SHA2" + sentry_hash
    
    with open(output_path, 'wb') as f:
        f.write(file_payload + sentry_footer)
    return True

def decode_payload_to_pixels(magic, decompressed_bytes, width, height, channels=3):
    """
    Modified to handle single tiles or full images.
    """
    total_pixels = width * height
    if magic == b"AVX5":
        num_colors = int.from_bytes(decompressed_bytes[0:4], 'big')
        palette_bytes_len = num_colors * channels
        palette_bytes = decompressed_bytes[4 : 4+palette_bytes_len]
        rle_indices_data = decompressed_bytes[4+palette_bytes_len : ]
        palette = np.frombuffer(palette_bytes, dtype=np.uint8).reshape((num_colors, channels))
        indices = rle_decode_indices(rle_indices_data, total_pixels)
        return palette[indices].reshape(height, width, channels)
    elif magic in (b"AVX2", b"AVX3", b"AVX4", b"AVX6"):
        residuals_planar = np.frombuffer(decompressed_bytes, dtype=np.uint8).reshape((channels, height, width))
        residuals = np.ascontiguousarray(residuals_planar.transpose(1, 2, 0))
        if magic == b"AVX2":
            if NUMBA_AVAILABLE:
                decorrelated = np.zeros_like(residuals)
                numba_decode_left(residuals, decorrelated)
            else:
                decorrelated = differential_to_pixels(residuals, width, height)
        elif magic == b"AVX3":
            if NUMBA_AVAILABLE:
                decorrelated = np.zeros_like(residuals)
                numba_decode_up(residuals, decorrelated)
            else:
                if not residuals.flags.writeable: residuals = residuals.copy()
                residuals[0, 0] = (residuals[0, 0].astype(np.int16) + 128) % 256
                residuals[0, :] = np.cumsum(residuals[0, :], axis=0, dtype=np.uint8)
                decorrelated = np.cumsum(residuals, axis=0, dtype=np.uint8)
        elif magic == b"AVX6":
            if NUMBA_AVAILABLE:
                decorrelated = np.zeros_like(residuals)
                numba_decode_paeth(residuals, decorrelated)
            else:
                decorrelated = residuals
        elif magic == b"AVX4":
            decorrelated = residuals
        else:
            return None
        pixels = decorrelated.copy()
        if channels >= 3:
            g = decorrelated[..., 1].astype(np.int16)
            pixels[..., 0] = (decorrelated[..., 0].astype(np.int16) + g) % 256
            pixels[..., 2] = (decorrelated[..., 2].astype(np.int16) + g) % 256
        return pixels
    return np.zeros((height, width, channels), dtype=np.uint8)

def decompress_avix_to_image(avix_path):
    """
    Decompress an .avix file directly into an in-memory Pillow image.
    Supports legacy and modern formats (RGB/RGBA).
    """
    try:
        import zstandard as zstd
    except ImportError:
        return None
        
    if not os.path.exists(avix_path):
        return None
        
    import mmap
    f = open(avix_path, 'rb')
    # Use memory mapping to bypass massive RAM bloat on extreme resolution files
    data = mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ)
    
    if len(data) < 8:
        data.close(); f.close()
        return None
        
    # --- SHA-256 INTEGRITY SENTRY CHECK ---
    if len(data) > 36 and data[-36:-32] == b"SHA2":
        import hashlib
        expected_hash = data[-32:]
        actual_hash = hashlib.sha256(data[:-36]).digest()
        if expected_hash != actual_hash:
            data.close(); f.close()
            raise Exception("ARCHIVAL INTEGRITY COMPROMISED: SHA-256 mismatch. File has suffered bit-rot!")
        
    magic = data[:4]
    if magic not in (b"AVXT", b"AVIX", b"AVX2", b"AVX3", b"AVX4", b"AVX5"):
        data.close(); f.close()
        return None
        
    if magic == b"AVXT":
        version = data[4]
        if version == 2:
            width = int.from_bytes(data[5:7], 'big')
            height = int.from_bytes(data[7:9], 'big')
            channels = data[9]
            # flags = data[10]
            thumb_len = int.from_bytes(data[11:15], 'big')
            thumb_end = 15 + thumb_len
            
            meta_len = int.from_bytes(data[thumb_end:thumb_end+4], 'big')
            meta_start = thumb_end + 4
            meta_end = meta_start + meta_len
            try:
                import json
                meta_json = data[meta_start:meta_end].decode('utf-8')
                metadata = json.loads(meta_json)
            except:
                metadata = {}
                
            tile_size = int.from_bytes(data[meta_end:meta_end+2], 'big')
            cursor = meta_end + 2
        else:
            # Fallback for v1 Tiled (AVXT without version byte)
            width = int.from_bytes(data[4:6], 'big')
            height = int.from_bytes(data[6:8], 'big')
            channels = data[8]
            thumb_len = int.from_bytes(data[9:13], 'big')
            thumb_end = 13 + thumb_len
            meta_len = int.from_bytes(data[thumb_end:thumb_end+4], 'big')
            meta_start = thumb_end + 4
            meta_end = meta_start + meta_len
            try:
                import json
                metadata = json.loads(data[meta_start:meta_end].decode('utf-8'))
            except: metadata = {}
            tile_size = int.from_bytes(data[meta_end:meta_end+2], 'big')
            cursor = meta_end + 2
            
        full_pixels = np.zeros((height, width, channels), dtype=np.uint8)
        dctx = zstd.ZstdDecompressor()
        
        for y in range(0, height, tile_size):
            for x in range(0, width, tile_size):
                t_magic = data[cursor:cursor+4]
                t_len = int.from_bytes(data[cursor+4:cursor+8], 'big')
                t_payload = data[cursor+8:cursor+8+t_len]
                cursor += 8 + t_len
                tw = min(tile_size, width - x)
                th = min(tile_size, height - y)
                t_decomp = dctx.decompress(t_payload)
                t_pixels = decode_payload_to_pixels(t_magic, t_decomp, tw, th, channels)
                full_pixels[y:y+th, x:x+tw] = t_pixels
        
        img = Image.fromarray(full_pixels, 'RGBA' if channels == 4 else 'RGB')
        if metadata: img.info.update(metadata)
        data.close()
        f.close()
        return img
        
    else:
        width = int.from_bytes(data[4:6], 'big')
        height = int.from_bytes(data[6:8], 'big')
        
        if len(data) > 8 and data[8] in (3, 4):
            channels = data[8]
            thumb_len = int.from_bytes(data[9:13], 'big')
            thumb_end = 13 + thumb_len
            
            # Standard single-block format (backward compatible)
            compressed_payload = data[thumb_end:]
            dctx = zstd.ZstdDecompressor()
            decomp = dctx.decompress(compressed_payload)
            pixels = decode_payload_to_pixels(magic, decomp, width, height, channels)
            
            data.close()
            f.close()
            return Image.fromarray(pixels, 'RGBA' if channels == 4 else 'RGB')
        else:
            # Legacy V1
            compressed_payload = data[8:]
            dctx = zstd.ZstdDecompressor()
            decomp = dctx.decompress(compressed_payload)
            pixels = decode_payload_to_pixels(magic, decomp, width, height, 3)
            
            data.close()
            f.close()
            return Image.fromarray(pixels, 'RGB')

def extract_avix_thumbnail(avix_path):
    """
    Extract only the embedded thumbnail for instant preview.
    """
    if not os.path.exists(avix_path):
        return None
    try:
        with open(avix_path, 'rb') as f:
            data = f.read(2048) # Read header area
            if len(data) < 15:
                return None
            
            magic = data[:4]
            if magic == b"AVXT":
                version = data[4]
                if version == 2:
                    thumb_len = int.from_bytes(data[11:15], 'big')
                    f.seek(15)
                    thumb_data = f.read(thumb_len)
                    return Image.open(io.BytesIO(thumb_data))
                else:
                    # Legacy v1 Tiled
                    if data[8] in (3, 4):
                        thumb_len = int.from_bytes(data[9:13], 'big')
                        f.seek(13)
                        thumb_data = f.read(thumb_len)
                        return Image.open(io.BytesIO(thumb_data))
            else:
                # Legacy single-block formats
                if data[8] in (3, 4):
                    thumb_len = int.from_bytes(data[9:13], 'big')
                    f.seek(13)
                    thumb_data = f.read(thumb_len)
                    return Image.open(io.BytesIO(thumb_data))
    except:
        pass
    return None


def decompress_avix(avix_path, output_image_path):
    """
    Decompress an .avix file and reconstruct the original image exactly.
    Read width, height, and content directly from the custom binary header.
    Supports all legacy and modern formats (AVIX, AVX2, AVX3, AVX4, AVX5).
    """
    try:
        import zstandard as zstd
    except ImportError:
        print("Error: 'zstandard' library is required to decompress files.")
        return False
        
    if not os.path.exists(avix_path):
        print(f"Error: File not found at {avix_path}")
        return False
        
    with open(avix_path, 'rb') as f:
        data = f.read()
        
    if len(data) < 8:
        print(f"Error: File is too small to be a valid .avix archive.")
        return False
        
    magic = data[:4]
    if magic not in (b"AVIX", b"AVX2", b"AVX3", b"AVX4", b"AVX5"):
        print(f"Error: File is not a valid .avix archive.")
        return False
        
    # Read width, height and channels from header
    width = int.from_bytes(data[4:6], 'big')
    height = int.from_bytes(data[6:8], 'big')
    
    # Determine header size and payload offset
    if len(data) > 8 and data[8] in (3, 4):
        channels = data[8]
        # New format with ThumbLen at offset 9
        if len(data) > 13:
            thumb_len = int.from_bytes(data[9:13], 'big')
            payload_offset = 13 + thumb_len
            compressed_payload = data[payload_offset:]
        else:
            # Fallback for transient format
            compressed_payload = data[9:]
    else:
        # Legacy
        channels = 3
        compressed_payload = data[8:]
    
    # Decompress payload
    dctx = zstd.ZstdDecompressor()
    try:
        decompressed_bytes = dctx.decompress(compressed_payload)
    except Exception as e:
        print(f"Error decompressing payload: {e}")
        return False
        
    # Reconstruct original pixels
    pixels = decode_payload_to_pixels(magic, decompressed_bytes, width, height, channels)
    
    # Save as image
    if channels == 4:
        img = Image.fromarray(pixels, 'RGBA')
    else:
        img = Image.fromarray(pixels, 'RGB')
    img.save(output_image_path)
    print(f"Successfully decompressed {avix_path} into {output_image_path}")
    return True

def format_size(size_bytes):
    """
    Format size in bytes to human readable string (GB, MB, KB, bytes).
    
    Args:
        size_bytes (int): Size in bytes.
        
    Returns:
        str: Formatted string (e.g. "1.50 MB").
    """
    if size_bytes == 0:
        return "0 bytes"
    
    # Define thresholds
    GB = 1024 ** 3
    MB = 1024 ** 2
    KB = 1024
    
    if size_bytes >= GB:
        return f"{size_bytes / GB:.2f} GB ({size_bytes} bytes)"
    elif size_bytes >= MB:
        return f"{size_bytes / MB:.2f} MB ({size_bytes} bytes)"
    elif size_bytes >= KB:
        return f"{size_bytes / KB:.2f} KB ({size_bytes} bytes)"
    else:
        return f"{size_bytes} bytes"

def main():
    import argparse
    import time
    
    parser = argparse.ArgumentParser(description="Convert images to pixel binary and back.")
    parser.add_argument("input_image", nargs="?", help="Path to input image/archive file.")
    parser.add_argument("--compress", action="store_true", help="Compress input image to .avix format.")
    parser.add_argument("--decompress", action="store_true", help="Decompress input .avix file back to image format.")
    parser.add_argument("--output", help="Optional output path for compressed or decompressed file.")
    parser.add_argument("--tolerance", type=int, default=0, help="Tolerance for approximate pixel matching in RLE (default: 0). Set to 0 for strict lossless.")
    args = parser.parse_args()

    if args.compress:
        if not args.input_image:
            print("Error: Input image or directory path is required when using --compress.")
            return
        if os.path.isdir(args.input_image):
            valid_extensions = {'.png', '.jpg', '.jpeg', '.bmp', '.webp', '.tiff'}
            print(f"Scanning folder {args.input_image} for image files...")
            files_to_compress = []
            for root, _, files in os.walk(args.input_image):
                for file in files:
                    if os.path.splitext(file)[1].lower() in valid_extensions:
                        files_to_compress.append(os.path.join(root, file))
            if not files_to_compress:
                print("No image files found in the directory.")
                return
            print(f"Found {len(files_to_compress)} image file(s). Compressing...")
            for file_path in files_to_compress:
                out_path = os.path.splitext(file_path)[0] + ".avix"
                compress_avix(file_path, out_path)
            return
        else:
            output_path = args.output or os.path.splitext(args.input_image)[0] + ".avix"
            compress_avix(args.input_image, output_path)
            return

    if args.decompress:
        if not args.input_image:
            print("Error: Input .avix file or directory path is required when using --decompress.")
            return
        if os.path.isdir(args.input_image):
            print(f"Scanning folder {args.input_image} for .avix files...")
            files_to_decompress = []
            for root, _, files in os.walk(args.input_image):
                for file in files:
                    if file.lower().endswith('.avix'):
                        files_to_decompress.append(os.path.join(root, file))
            if not files_to_decompress:
                print("No .avix files found in the directory.")
                return
            print(f"Found {len(files_to_decompress)} .avix file(s). Decompressing...")
            for file_path in files_to_decompress:
                out_path = os.path.splitext(file_path)[0] + "_restored.png"
                decompress_avix(file_path, out_path)
            return
        else:
            output_path = args.output or os.path.splitext(args.input_image)[0] + "_restored.png"
            decompress_avix(args.input_image, output_path)
            return

    print("--- Image Pixel Converter Module Demo ---")
    print(f"Configurations: Tolerance={args.tolerance}")
    
    # 1. Setup paths
    base_dir = os.path.dirname(os.path.abspath(__file__))
    
    if args.input_image:
        sample_image_path = os.path.abspath(args.input_image)
        if not os.path.exists(sample_image_path):
            print(f"Error: File not found at {sample_image_path}")
            return
        base_name = os.path.splitext(os.path.basename(sample_image_path))[0]
    else:
        sample_image_path = os.path.join(base_dir, "sample_input.png")
        base_name = "sample_input"
        # Create sample if running default demo and it doesn't exist
        if not os.path.exists(sample_image_path):
            create_sample_image(sample_image_path)

    binary_output_path = os.path.join(base_dir, f"{base_name}_data.bin")
    rle_output_path = os.path.join(base_dir, f"{base_name}_rle.bin")
    reconstructed_image_path = os.path.join(base_dir, f"{base_name}_reconstructed.png")
    rle_reconstructed_image_path = os.path.join(base_dir, f"{base_name}_rle_reconstructed.png")
        
    # 3. Load Image
    print(f"\n1. Loading image from {sample_image_path}...")
    original_img = load_image(sample_image_path)
    if original_img is None:
        return
    
    width, height = original_img.size
    print(f"   Image loaded. Dimensions: {width}x{height}")
    
    # 4. Convert to Pixels
    print("\n2. Converting image to pixel array...")
    pixel_array = image_to_pixels(original_img)
    print(f"   Pixel array shape: {pixel_array.shape}")
    
    # Run adaptive analysis
    image_type, recommended_strategy = adaptive_compress(pixel_array)
    print(f"\n--- Adaptive Image Analysis ---")
    print(f"   Detected image type: {image_type}")
    print(f"   Recommended strategy for optimal 100% Lossless: {recommended_strategy}")
    
    # 5. Convert to Binary (Raw)
    print("\n3. Converting pixels to raw binary data...")
    binary_data = pixels_to_binary(pixel_array)
    raw_size = calculate_storage_size(binary_data)
    print(f"   Raw binary data size: {format_size(raw_size)}")
    
    # 6. Save Binary
    save_binary(binary_data, binary_output_path)
    
    # 7. Convert to RLE
    print(f"\n4. Converting pixels to RLE data (Tolerance: {args.tolerance})...")
    start_time = time.time()
    rle_data = pixels_to_rle(pixel_array, tolerance=args.tolerance)
    rle_time = time.time() - start_time
    rle_size = calculate_storage_size(rle_data)
    print(f"   RLE binary data size: {format_size(rle_size)}")
    print(f"   Compression Ratio: {raw_size / rle_size:.2f}x" if rle_size > 0 else "   Compression Ratio: N/A")
    print(f"   Time taken: {rle_time:.4f}s")
    
    # 8. Save RLE
    save_binary(rle_data, rle_output_path)
    
    # 9. Reconstruct from RLE
    print(f"\n5. Reconstructing image from RLE data...")
    reconstructed_pixels = rle_to_pixels(rle_data, width, height)
    
    if reconstructed_pixels is not None:
        rle_img = Image.fromarray(reconstructed_pixels, 'RGB')
        
        print(f"\n6. Verifying RLE reconstruction...")
        if args.tolerance == 0:
            is_identical = verify_identical(original_img, rle_img)
            if is_identical:
                print("   SUCCESS! RLE Reconstructed image is IDENTICAL to the original (Lossless).")
            else:
                print("   WARNING! RLE Reconstructed image differs (Unexpected for tolerance=0).")
        else:
            diff = np.abs(pixel_array.astype(int) - reconstructed_pixels.astype(int))
            # Check max difference
            max_diff = np.max(diff) if diff.size > 0 else 0
            print(f"   Approximate match verification. Max channel diff found: {max_diff}")
            if max_diff <= args.tolerance:
                print(f"   SUCCESS! Differences conform to tolerance {args.tolerance}.")
            else:
                print(f"   WARNING! Differences ({max_diff}) exceed tolerance {args.tolerance}.")
                
        rle_img.save(rle_reconstructed_image_path)
        print(f"   Saved RLE reconstructed image to {rle_reconstructed_image_path}")

    # --- Palette Compression Demo ---
    print("\n--- Palette + RLE Compression Demo (Lossless) ---")
    
    # 1. Extract Palette
    print("1. Extracting unique palette...")
    start_time = time.time()
    palette, indices = extract_palette(pixel_array)
    palette_time = time.time() - start_time
    print(f"   Palette size: {len(palette)} unique colors.")
    print(f"   Palette extraction time: {palette_time:.4f}s")
    
    # 2. Encode Indices with RLE
    print("2. Encoding palette indices with RLE...")
    start_time = time.time()
    rle_indices_data = rle_encode_indices(indices)
    rle_indices_time = time.time() - start_time
    
    # Calculate sizes
    # Palette data size: N * 3 bytes (RGB)
    palette_data_size = len(palette) * 3
    # RLE Indices size: len(rle_indices_data)
    rle_indices_size = len(rle_indices_data)
    # Total
    total_palette_compressed_size = palette_data_size + rle_indices_size
    
    print(f"   RLE Indices encoding time: {rle_indices_time:.4f}s")
    print(f"   Palette Data Size: {format_size(palette_data_size)}")
    print(f"   RLE Indices Size: {format_size(rle_indices_size)}")
    print(f"   Total Compressed Size: {format_size(total_palette_compressed_size)}")
    print(f"   Compression Ratio: {raw_size / total_palette_compressed_size:.2f}x")
    
    # --- Zstd Compression (Advanced) ---
    print("\n--- Advanced Compression (Zstd) ---")
    
    try:
        import zstandard as zstd
        print("Attempting to compress the best previous result using Zstd (Level 22)...")
        
        cctx = zstd.ZstdCompressor(level=22)
        
        # 1. Compress Raw
        zstd_raw_data = cctx.compress(binary_data)
        zstd_raw_size = len(zstd_raw_data)
        print(f"1. Zstd on Raw Data: {format_size(zstd_raw_size)} (Ratio: {raw_size/zstd_raw_size:.2f}x)")
        
        # 2. Compress RLE
        zstd_rle_data = cctx.compress(rle_data)
        zstd_rle_size = len(zstd_rle_data)
        print(f"2. Zstd on RLE Data: {format_size(zstd_rle_size)} (Ratio: {raw_size/zstd_rle_size:.2f}x)")
        
        # 3. Compress Palette+RLE
        # Palette format: N*3 bytes
        # Indices format: RLE encoded bytes
        palette_binary = palette.astype(np.uint8).tobytes()
        palette_bytes_len = len(palette_binary)
        full_palette_stream = int(palette_bytes_len).to_bytes(4, 'big') + palette_binary + rle_indices_data
        
        zstd_palette_data = cctx.compress(full_palette_stream)
        zstd_palette_size = len(zstd_palette_data)
        print(f"3. Zstd on Palette+RLE: {format_size(zstd_palette_size)} (Ratio: {raw_size/zstd_palette_size:.2f}x)")
        
        # 4. Compress Differential Residuals (Gradients/Noise-friendly)
        residuals = pixels_to_differential(pixel_array)
        zstd_diff_data = cctx.compress(residuals.tobytes())
        zstd_diff_size = len(zstd_diff_data)
        print(f"4. Zstd on Differential Residuals: {format_size(zstd_diff_size)} (Ratio: {raw_size/zstd_diff_size:.2f}x)")
        
        # Find winner
        min_advanced_size = min(zstd_raw_size, zstd_rle_size, zstd_palette_size, zstd_diff_size)
        best_method = ""
        if min_advanced_size == zstd_raw_size: best_method = "Zstd(Raw)"
        elif min_advanced_size == zstd_rle_size: best_method = "Zstd(RLE)"
        elif min_advanced_size == zstd_palette_size: best_method = "Zstd(Palette+RLE)"
        else: best_method = "Zstd(Differential)"

    except ImportError:
        print("Error: 'zstandard' library not found. Please run 'pip install zstandard'")
        min_advanced_size = float('inf')
        best_method = "N/A"

    # Summary Update
    print("\n--- Final Summary ---")
    print(f"Original Image Size (disk): {format_size(calculate_storage_size(sample_image_path))}")
    print(f"Raw Binary Size: {format_size(raw_size)}")
    print(f"Standard RLE Size (Tolerance {args.tolerance}): {format_size(rle_size)}")
    print(f"Palette + RLE Size (Lossless): {format_size(total_palette_compressed_size)}")
    
    if min_advanced_size != float('inf'):
        print(f"Advanced Zstd Size ({best_method}): {format_size(min_advanced_size)}")
        best_overall_size = min(rle_size, total_palette_compressed_size, min_advanced_size)
    else:
        best_overall_size = min(rle_size, total_palette_compressed_size)
        
    print(f"Best Overall Compressed Size: {format_size(best_overall_size)}")
    print(f"Space Saved vs Raw: {format_size(raw_size - best_overall_size)}")
    
    # Comparison to original file
    original_file_size = calculate_storage_size(sample_image_path)
    if best_overall_size < original_file_size:
        print(f"VICTORY! We beat the original file size by {format_size(original_file_size - best_overall_size)}!")
    else:
        print(f"Close! Original file is still {format_size(best_overall_size - original_file_size)} smaller.")

if __name__ == "__main__":
    main()
