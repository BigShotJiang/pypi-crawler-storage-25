"""Configuration management for CrowdTime CLI.

Config is stored at ~/.crowdtime/config.toml using platformdirs.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import tomlkit
from platformdirs import user_config_dir

CONFIG_DIR = Path(user_config_dir("crowdtime", ensure_exists=True))
CONFIG_FILE = CONFIG_DIR / "config.toml"

DEFAULT_CONFIG = {
    "server": {
        "url": "https://api.crowdtime.lat",
    },
    "defaults": {
        "organization": "",
        "project": "",
        "daily_target": "8h",
        "weekly_target": "40h",
        "date_format": "%Y-%m-%d",
        "time_format": "24h",
    },
    "display": {
        "theme": "auto",
        "color": True,
        "compact": False,
    },
}


class CrowdTimeConfig:
    """Manages CrowdTime CLI configuration."""

    def __init__(self) -> None:
        self._ensure_config_dir()
        self._doc = self._load()

    def _ensure_config_dir(self) -> None:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)

    def _load(self) -> tomlkit.TOMLDocument:
        if CONFIG_FILE.exists():
            return tomlkit.parse(CONFIG_FILE.read_text())
        # Create default config
        doc = tomlkit.document()
        for section, values in DEFAULT_CONFIG.items():
            table = tomlkit.table()
            for key, value in values.items():
                table.add(key, value)
            doc.add(section, table)
        CONFIG_FILE.write_text(tomlkit.dumps(doc))
        CONFIG_FILE.chmod(0o600)
        return doc

    def get(self, key: str, default: Any = None) -> Any:
        """Get a config value using dot notation (e.g. 'server.url')."""
        parts = key.split(".")
        current: Any = self._doc
        for part in parts:
            if isinstance(current, dict) and part in current:
                current = current[part]
            else:
                return default
        return current

    def set(self, key: str, value: Any) -> None:
        """Set a config value using dot notation."""
        parts = key.split(".")
        if len(parts) < 2:
            raise ValueError("Config key must have at least section.key format (e.g. 'server.url')")

        section = parts[0]
        if section not in self._doc:
            self._doc.add(section, tomlkit.table())

        current: Any = self._doc[section]
        for part in parts[1:-1]:
            if part not in current:
                current[part] = tomlkit.table()
            current = current[part]

        current[parts[-1]] = value
        self.save()

    def save(self) -> None:
        """Write config to disk."""
        CONFIG_FILE.write_text(tomlkit.dumps(self._doc))
        CONFIG_FILE.chmod(0o600)

    def all(self) -> dict[str, Any]:
        """Return the full config as a dict."""
        return dict(self._doc)

    @property
    def server_url(self) -> str:
        return str(self.get("server.url", "https://api.crowdtime.lat")).rstrip("/")

    @property
    def frontend_url(self) -> str:
        """Frontend URL, derived from server URL if not explicitly set.

        Default derivation: https://api.crowdtime.lat → https://app.crowdtime.lat
        Local dev: http://localhost:8001 → http://localhost:3000
        """
        explicit = self.get("server.frontend_url", "")
        if explicit:
            return str(explicit).rstrip("/")
        url = self.server_url
        if "://api." in url:
            return url.replace("://api.", "://app.")
        if "localhost:8001" in url:
            return url.replace("localhost:8001", "localhost:3000")
        return url

    @property
    def organization(self) -> str:
        return str(self.get("defaults.organization", ""))

    @property
    def default_project(self) -> str:
        return str(self.get("defaults.project", ""))

    @property
    def daily_target(self) -> str:
        return str(self.get("defaults.daily_target", "8h"))

    @property
    def weekly_target(self) -> str:
        return str(self.get("defaults.weekly_target", "40h"))

    @property
    def config_path(self) -> Path:
        return CONFIG_FILE


def get_config() -> CrowdTimeConfig:
    """Get a CrowdTimeConfig instance."""
    return CrowdTimeConfig()
