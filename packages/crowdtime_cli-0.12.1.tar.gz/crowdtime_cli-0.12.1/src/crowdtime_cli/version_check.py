"""PyPI version check: warn when the installed CLI is out of date.

A single outbound call to PyPI, cached locally for 12 hours. The check is
fire-and-forget — network errors, PyPI outages, and parse failures are all
silenced so they never affect command output or exit status.

Opt-out:
- Environment variable: ``CROWDTIME_NO_VERSION_CHECK=1``
- Config flag: ``[update_check] enabled = false`` in ``config.toml``
"""

from __future__ import annotations

import json
import os
import re
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional, Tuple

import httpx

from . import __version__

PYPI_URL = "https://pypi.org/pypi/crowdtime-cli/json"
CHECK_INTERVAL = timedelta(hours=12)
FETCH_TIMEOUT_SEC = 2.0
OPT_OUT_ENV = "CROWDTIME_NO_VERSION_CHECK"

_VERSION_RE = re.compile(r"^(\d+)\.(\d+)\.(\d+)$")


def _cache_path() -> Path:
    """Return the cache file path. Deferred so tests can monkeypatch CONFIG_DIR."""
    from .config import CONFIG_DIR
    return CONFIG_DIR / "version_check.json"


def _parse_simple(v: Optional[str]) -> Optional[Tuple[int, int, int]]:
    """Parse a strict ``MAJOR.MINOR.PATCH`` version string.

    Returns None for dev builds, pre-releases, and local versions —
    we deliberately skip the check in those cases rather than risk a
    false positive.
    """
    if not v:
        return None
    m = _VERSION_RE.match(v)
    if not m:
        return None
    return int(m.group(1)), int(m.group(2)), int(m.group(3))


def _read_cache() -> dict:
    try:
        return json.loads(_cache_path().read_text())
    except (FileNotFoundError, ValueError, OSError):
        return {}


def _write_cache(latest: Optional[str]) -> None:
    """Write the cache atomically via tmp-file + os.replace.

    Guards against two concurrent ``ct`` processes interleaving writes and
    leaving a truncated/partial JSON behind (which would silently disable
    the cache on the next read).
    """
    try:
        path = _cache_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        payload = json.dumps({
            "last_checked": datetime.now(timezone.utc).isoformat(),
            "latest_version": latest,
        })
        fd, tmp = tempfile.mkstemp(
            prefix="version_check-", suffix=".tmp", dir=str(path.parent),
        )
        try:
            with os.fdopen(fd, "w") as f:
                f.write(payload)
            os.replace(tmp, path)
        except Exception:
            # Ensure tmp doesn't linger if replace fails.
            try:
                os.unlink(tmp)
            except OSError:
                pass
            raise
    except OSError:
        pass  # Cache is a performance nicety — never fatal.


def _is_fresh(cache: dict) -> bool:
    last = cache.get("last_checked")
    if not isinstance(last, str):
        return False
    try:
        last_dt = datetime.fromisoformat(last)
    except ValueError:
        return False
    if last_dt.tzinfo is None:
        last_dt = last_dt.replace(tzinfo=timezone.utc)
    delta = datetime.now(timezone.utc) - last_dt
    # Guard against a system clock set to the past: a negative delta would
    # otherwise keep stale caches "fresh" indefinitely. Treat any non-positive
    # delta as stale so we re-fetch on the next invocation.
    return timedelta(0) <= delta < CHECK_INTERVAL


def _fetch_latest() -> Optional[str]:
    """Fetch the latest published version from PyPI. Returns None on any failure."""
    try:
        resp = httpx.get(PYPI_URL, timeout=FETCH_TIMEOUT_SEC)
        resp.raise_for_status()
        version = resp.json().get("info", {}).get("version")
        return version if isinstance(version, str) else None
    except Exception:
        return None


def get_latest(force_refresh: bool = False) -> Optional[str]:
    """Return the latest known version string, from cache or a fresh fetch.

    When ``force_refresh=True``, always hit PyPI and update the cache.
    Otherwise, a cache entry younger than ``CHECK_INTERVAL`` is reused.
    A failed fetch falls back to the previous cached value (if any) so
    transient PyPI outages don't wipe out the warning signal.
    """
    cache = _read_cache()
    cached_latest = cache.get("latest_version")
    if not force_refresh and _is_fresh(cache):
        return cached_latest if isinstance(cached_latest, str) else None

    fetched = _fetch_latest()
    if fetched is not None:
        _write_cache(fetched)
        return fetched

    # Fetch failed. Refresh the timestamp anyway so we don't retry on every
    # single command, but preserve any prior cached version for warning text.
    _write_cache(cached_latest if isinstance(cached_latest, str) else None)
    return cached_latest if isinstance(cached_latest, str) else None


def _opt_out() -> bool:
    """Return True when the user has disabled the version check."""
    if os.environ.get(OPT_OUT_ENV) == "1":
        return True
    try:
        from .config import get_config
        return not get_config().get("update_check.enabled", True)
    except Exception:
        return False


def is_outdated(current: str, latest: Optional[str]) -> bool:
    """Return True iff ``current`` and ``latest`` are both parseable and current < latest."""
    current_t = _parse_simple(current)
    latest_t = _parse_simple(latest)
    if current_t is None or latest_t is None:
        return False
    return current_t < latest_t


def check_and_warn(console) -> None:
    """Daily-ish check: print an upgrade hint on stderr if out of date.

    Silent on any error. Honors the opt-out env var and config flag. Dev /
    pre-release / local versions are skipped (no comparison possible).
    """
    if _opt_out():
        return
    if _parse_simple(__version__) is None:
        return  # dev build — not something we can sensibly compare
    latest = get_latest()
    if not is_outdated(__version__, latest):
        return
    console.print(
        f"[yellow]\u26a0 crowdtime-cli {latest} is available "
        f"(you have {__version__}). "
        f"Run [bold]pip install -U crowdtime-cli[/bold] to upgrade.[/yellow]",
        highlight=False,
    )
