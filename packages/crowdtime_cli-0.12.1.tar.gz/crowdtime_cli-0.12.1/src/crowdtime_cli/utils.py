"""Utility functions for duration parsing, date parsing, and formatting."""

from __future__ import annotations

import re
from datetime import date, timedelta
from decimal import Decimal, InvalidOperation


def parse_duration(text: str) -> Decimal:
    """Parse a duration string into decimal hours.

    Accepts:
        "2h"       -> 2.0
        "2h30m"    -> 2.5
        "2.5h"     -> 2.5
        "2.5"      -> 2.5 (assumed hours)
        "2:30"     -> 2.5
        "150m"     -> 2.5
        "0.25d"    -> 2.0 (1 day = 8h)
        "30"       -> 0.5 (assumed minutes if <= 480, else error)
    """
    text = text.strip().lower()

    # Format: 2:30
    match = re.match(r"^(\d+):(\d{1,2})$", text)
    if match:
        hours = int(match.group(1))
        minutes = int(match.group(2))
        return Decimal(str(hours)) + Decimal(str(minutes)) / Decimal("60")

    # Format: 2h30m or 2h 30m
    match = re.match(r"^(\d+(?:\.\d+)?)\s*h\s*(?:(\d+)\s*m)?$", text)
    if match:
        hours = Decimal(match.group(1))
        minutes = Decimal(match.group(2) or "0")
        return hours + minutes / Decimal("60")

    # Format: 150m
    match = re.match(r"^(\d+(?:\.\d+)?)\s*m$", text)
    if match:
        return Decimal(match.group(1)) / Decimal("60")

    # Format: 0.25d
    match = re.match(r"^(\d+(?:\.\d+)?)\s*d$", text)
    if match:
        return Decimal(match.group(1)) * Decimal("8")

    # Format: 2.5h (explicit hours)
    match = re.match(r"^(\d+(?:\.\d+)?)\s*h$", text)
    if match:
        return Decimal(match.group(1))

    # Format: plain number - assume hours
    match = re.match(r"^(\d+(?:\.\d+)?)$", text)
    if match:
        value = Decimal(match.group(1))
        return value

    raise ValueError(f"Cannot parse duration: '{text}'. Try formats like 2h, 2h30m, 2:30, 150m, 0.25d")


def format_duration(hours: Decimal | float | str | None) -> str:
    """Format decimal hours into a human-readable string like '2h 30m'."""
    if hours is None:
        return "0m"
    try:
        h = Decimal(str(hours))
    except (InvalidOperation, ValueError):
        return "0m"

    if h <= 0:
        return "0m"

    total_minutes = int(h * 60)
    hrs = total_minutes // 60
    mins = total_minutes % 60

    if hrs and mins:
        return f"{hrs}h {mins}m"
    elif hrs:
        return f"{hrs}h"
    else:
        return f"{mins}m"


def parse_date(text: str) -> date:
    """Parse a date string into a date object.

    Accepts:
        "today"         -> today
        "yesterday"     -> yesterday
        "monday"        -> most recent Monday
        "last friday"   -> previous week's Friday
        "2026-03-10"    -> date(2026, 3, 10)
        "3/10"          -> date(current_year, 3, 10)
        "03/10/2026"    -> date(2026, 3, 10)
    """
    text = text.strip().lower()
    today = date.today()

    if text == "today":
        return today

    if text == "yesterday":
        return today - timedelta(days=1)

    # Day names
    day_names = {
        "monday": 0, "tuesday": 1, "wednesday": 2, "thursday": 3,
        "friday": 4, "saturday": 5, "sunday": 6,
        "mon": 0, "tue": 1, "wed": 2, "thu": 3,
        "fri": 4, "sat": 5, "sun": 6,
    }

    # "last <day>"
    match = re.match(r"^last\s+(\w+)$", text)
    if match:
        day_name = match.group(1)
        if day_name in day_names:
            target = day_names[day_name]
            days_back = (today.weekday() - target) % 7
            if days_back == 0:
                days_back = 7
            days_back += 7  # "last" means previous week
            return today - timedelta(days=days_back)

    # Just a day name (most recent occurrence, including today)
    if text in day_names:
        target = day_names[text]
        days_back = (today.weekday() - target) % 7
        if days_back == 0:
            days_back = 0  # today if it matches
        return today - timedelta(days=days_back)

    # ISO format: YYYY-MM-DD
    match = re.match(r"^(\d{4})-(\d{1,2})-(\d{1,2})$", text)
    if match:
        return date(int(match.group(1)), int(match.group(2)), int(match.group(3)))

    # US format: M/D or M/D/YYYY
    match = re.match(r"^(\d{1,2})/(\d{1,2})(?:/(\d{4}))?$", text)
    if match:
        month = int(match.group(1))
        day = int(match.group(2))
        year = int(match.group(3)) if match.group(3) else today.year
        return date(year, month, day)

    raise ValueError(
        f"Cannot parse date: '{text}'. Try: today, yesterday, monday, "
        f"last friday, 2026-03-10, 3/10"
    )


def format_date(d: date | None, fmt: str = "%Y-%m-%d") -> str:
    """Format a date for display."""
    if d is None:
        return ""
    return d.strftime(fmt)


def format_iso_date(date_str: str | None, placeholder: str = "—") -> str:
    """Format an ISO date/datetime string for display (YYYY-MM-DD).

    Use this for API response strings that are already ISO-formatted.
    Returns *placeholder* when *date_str* is empty/None.
    """
    if not date_str:
        return placeholder
    return date_str[:10]


def format_iso_datetime(dt_str: str | None, placeholder: str = "—") -> str:
    """Format an ISO datetime string for display (YYYY-MM-DD HH:MM:SS).

    Strips the timezone suffix and replaces 'T' with a space.
    Returns *placeholder* when *dt_str* is empty/None.
    """
    if not dt_str:
        return placeholder
    return dt_str[:19].replace("T", " ")


def is_uuid(value: str) -> bool:
    """Check if a string looks like a valid UUID."""
    return bool(re.match(
        r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$',
        value.lower(),
    ))


def truncate(text: str, max_length: int = 50) -> str:
    """Truncate text to a maximum length with ellipsis."""
    if len(text) <= max_length:
        return text
    return text[: max_length - 1] + "\u2026"


def resolve_period(
    today_flag: bool = False,
    yesterday_flag: bool = False,
    week: bool = False,
    last_week: bool = False,
    month: bool = False,
    last_month: bool = False,
    quarter: bool = False,
    last_quarter: bool = False,
    from_date: str | None = None,
    to_date: str | None = None,
    default: str = "week",
) -> tuple[str, str]:
    """Resolve a date range from period flags.

    Shared helper used by report, insights, and other date-ranged commands.
    *default* controls the fallback when no flag is set: ``"week"`` (this week)
    or ``"month"`` (this month).
    """
    import typer
    from .formatters import format_error

    today = date.today()

    if today_flag:
        d = format_date(today)
        return d, d
    if yesterday_flag:
        d = format_date(today - timedelta(days=1))
        return d, d
    if week:
        start = today - timedelta(days=today.weekday())
        return format_date(start), format_date(today)
    if last_week:
        start = today - timedelta(days=today.weekday() + 7)
        end = start + timedelta(days=6)
        return format_date(start), format_date(end)
    if month:
        start = today.replace(day=1)
        return format_date(start), format_date(today)
    if last_month:
        first_of_this = today.replace(day=1)
        end = first_of_this - timedelta(days=1)
        start = end.replace(day=1)
        return format_date(start), format_date(end)
    if quarter:
        q_month = ((today.month - 1) // 3) * 3 + 1
        start = today.replace(month=q_month, day=1)
        return format_date(start), format_date(today)
    if last_quarter:
        q_month = ((today.month - 1) // 3) * 3 + 1
        end = today.replace(month=q_month, day=1) - timedelta(days=1)
        lq_month = ((end.month - 1) // 3) * 3 + 1
        start = end.replace(month=lq_month, day=1)
        return format_date(start), format_date(end)
    if from_date and to_date:
        try:
            return format_date(parse_date(from_date)), format_date(parse_date(to_date))
        except ValueError as e:
            format_error(str(e))
            raise typer.Exit(1)
    if from_date:
        try:
            return format_date(parse_date(from_date)), format_date(today)
        except ValueError as e:
            format_error(str(e))
            raise typer.Exit(1)

    # Default period
    if default == "month":
        start = today.replace(day=1)
    else:
        start = today - timedelta(days=today.weekday())
    return format_date(start), format_date(today)
