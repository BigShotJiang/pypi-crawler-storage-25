"""Rich-based output formatting for CrowdTime CLI."""

from __future__ import annotations

import json
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal
from typing import Any

from rich.console import Console
from rich.panel import Panel
from rich.progress import BarColumn, Progress, TextColumn
from rich.table import Table
from rich.text import Text

from .models import FavoriteEntry, ParseResult, Project, Suggestion, TimeEntry
from .utils import format_duration, format_iso_datetime, truncate

console = Console()

# Currency symbols for multi-currency display
CURRENCY_SYMBOLS: dict[str, str] = {
    "USD": "$",
    "EUR": "\u20ac",
    "GBP": "\u00a3",
    "ARS": "AR$",
}


def format_currency(
    amount: str | float | Decimal | None,
    currency: str = "USD",
    none_display: str | None = None,
) -> str:
    """Format a currency amount for display.

    Returns a formatted string like "$1,234.56" or "€1,234.56".
    When *amount* is ``None``, returns *none_display* if set, otherwise
    "$0.00" (with the appropriate currency symbol).
    """
    sym = CURRENCY_SYMBOLS.get(currency, f"{currency} ")
    if amount is None:
        return none_display if none_display is not None else f"{sym}0.00"
    try:
        value = Decimal(str(amount))
    except (ValueError, ArithmeticError):
        return none_display if none_display is not None else f"{sym}0.00"
    return f"{sym}{value:,.2f}"


def extract_results(data: Any) -> list[Any]:
    """Extract a list of results from an API response.

    Handles paginated responses (``{"results": [...]}``), report responses
    (``{"projects": [...]}``, ``{"members": [...]}``, ``{"entries": [...]}``),
    and bare arrays (``[...]``).
    """
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        for key in ("results", "projects", "members", "entries", "clients", "snapshots"):
            if key in data:
                return data[key]
        return []
    return []


def format_error(message: str) -> None:
    """Print an error message."""
    console.print(f"[bold red]Error:[/bold red] {message}")


def format_success(message: str) -> None:
    """Print a success message."""
    console.print(f"[bold green]Done:[/bold green] {message}")


def format_warning(message: str) -> None:
    """Print a warning message."""
    console.print(f"[bold yellow]Warning:[/bold yellow] {message}")


def format_timer(entry: TimeEntry) -> None:
    """Display the currently running timer as a Rich panel."""
    if not entry.is_running:
        console.print("[dim]No timer is currently running.[/dim]")
        return

    elapsed = ""
    if entry.start_time:
        now = datetime.now(timezone.utc)
        start = entry.start_time
        if start.tzinfo is None:
            start = start.replace(tzinfo=timezone.utc)
        delta = now - start
        total_seconds = int(delta.total_seconds())
        hours = total_seconds // 3600
        minutes = (total_seconds % 3600) // 60
        seconds = total_seconds % 60
        elapsed = f"{hours:02d}:{minutes:02d}:{seconds:02d}"

    parts: list[str] = []
    if entry.description:
        parts.append(f"[bold]{entry.description}[/bold]")
    if entry.project_name:
        parts.append(f"[cyan]{entry.project_name}[/cyan]")
    if entry.task_name:
        parts.append(f"[dim]{entry.task_name}[/dim]")
    if entry.is_billable:
        parts.append("[green]$[/green]")

    title = " | ".join(parts) if parts else "[dim]No description[/dim]"

    panel = Panel(
        f"[bold green]{elapsed}[/bold green]" if elapsed else "[dim]Running...[/dim]",
        title=title,
        subtitle="[dim]Timer running[/dim]",
        border_style="green",
        padding=(0, 2),
    )
    console.print(panel)


def format_entry_summary(entry: TimeEntry) -> None:
    """Display a single time entry summary."""
    parts: list[str] = []
    if entry.description:
        parts.append(f"[bold]{entry.description}[/bold]")
    if entry.project_name:
        parts.append(f"[cyan]{entry.project_name}[/cyan]")
    if entry.task_name:
        parts.append(f"[dim]{entry.task_name}[/dim]")
    if entry.duration is not None:
        parts.append(f"[yellow]{format_duration(entry.duration)}[/yellow]")
    if entry.date:
        parts.append(f"[dim]{entry.date}[/dim]")

    console.print(" | ".join(parts))


def format_entry_detail(entry: TimeEntry) -> None:
    """Display detailed view of a single time entry."""
    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column("Field", style="dim", width=12)
    table.add_column("Value")

    table.add_row("ID", str(entry.id))
    table.add_row("Date", str(entry.date or ""))
    table.add_row("Project", f"[cyan]{entry.project_name or ''}[/cyan]")
    if entry.task_name:
        table.add_row("Task", entry.task_name)
    table.add_row("Description", entry.description or "[dim](none)[/dim]")
    if entry.is_running:
        table.add_row("Duration", "[green]running[/green]")
    else:
        table.add_row("Duration", f"[yellow]{format_duration(entry.duration)}[/yellow]")
    table.add_row("Billable", "[green]Yes[/green]" if entry.is_billable else "[dim]No[/dim]")
    if entry.source:
        table.add_row("Source", entry.source)
    if entry.user_name:
        table.add_row("User", entry.user_name)
    if entry.created_at:
        table.add_row("Created", format_iso_datetime(str(entry.created_at)))

    console.print(table)


def format_favorite_detail(fav: FavoriteEntry) -> None:
    """Display detailed view of a single favorite."""
    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column("Field", style="dim", width=12)
    table.add_column("Value")

    table.add_row("ID", str(fav.id))
    table.add_row("Project", f"[cyan]{fav.project_name or ''}[/cyan]")
    if fav.task_name:
        table.add_row("Task", fav.task_name)
    table.add_row("Description", fav.description or "[dim](none)[/dim]")
    table.add_row("Billable", "[green]Yes[/green]" if fav.is_billable else "[dim]No[/dim]")
    table.add_row("Position", str(fav.position))
    table.add_row("Uses", str(fav.use_count))
    if fav.created_at:
        table.add_row("Created", format_iso_datetime(str(fav.created_at)))

    console.print(table)


def format_entries_table(entries: list[TimeEntry], show_date: bool = True) -> None:
    """Display time entries in a Rich table."""
    if not entries:
        console.print("[dim]No entries found.[/dim]")
        return

    table = Table(show_header=True, header_style="bold")
    table.add_column("ID", style="dim")
    if show_date:
        table.add_column("Date", width=12)
    table.add_column("Project", style="cyan", width=15)
    table.add_column("Task", style="dim", width=15)
    table.add_column("Description", width=35)
    table.add_column("Duration", justify="right", width=8)
    table.add_column("$", justify="center", width=3)

    for entry in entries:
        row: list[str] = [str(entry.id)]
        if show_date:
            row.append(str(entry.date or ""))
        row.extend([
            entry.project_name or "",
            entry.task_name or "",
            truncate(entry.description, 35),
            format_duration(entry.duration) if not entry.is_running else "[green]running[/green]",
            "[green]$[/green]" if entry.is_billable else "",
        ])
        table.add_row(*row)

    # Total
    total_hours = sum(
        (e.duration or Decimal("0")) for e in entries if not e.is_running
    )
    console.print(table)
    console.print(f"\n[bold]Total:[/bold] {format_duration(total_hours)} ({len(entries)} entries)")


def format_status(
    user_name: str,
    org_name: str,
    running_entry: TimeEntry | None,
    today_entries: list[TimeEntry],
    daily_target: str,
    week_entries: list[TimeEntry] | None = None,
) -> None:
    """Display the full status dashboard."""
    # Header
    console.print(f"\n[bold]CrowdTime[/bold] | {user_name} @ {org_name}\n")

    # Running timer
    if running_entry:
        format_timer(running_entry)
        console.print()
    else:
        console.print("[dim]No timer running[/dim]\n")

    # Today's summary
    from .utils import parse_duration
    try:
        target_hours = parse_duration(daily_target)
    except ValueError:
        target_hours = Decimal("8")

    today_total = sum(
        (e.duration or Decimal("0")) for e in today_entries if not e.is_running
    )

    console.print("[bold]Today[/bold]")
    progress_pct = min(float(today_total / target_hours * 100), 100) if target_hours else 0

    bar_width = 30
    filled = int(bar_width * progress_pct / 100)
    bar = "[green]" + "\u2588" * filled + "[/green]" + "[dim]" + "\u2591" * (bar_width - filled) + "[/dim]"
    console.print(
        f"  {bar} {format_duration(today_total)} / {format_duration(target_hours)} "
        f"({progress_pct:.0f}%)"
    )

    if today_entries:
        for entry in today_entries[-5:]:
            prefix = "[green]\u25cf[/green]" if entry.is_running else "[dim]\u25cb[/dim]"
            dur = "running" if entry.is_running else format_duration(entry.duration)
            desc = truncate(entry.description or "(no description)", 40)
            proj = f" [cyan]{entry.project_name}[/cyan]" if entry.project_name else ""
            console.print(f"  {prefix} {desc}{proj} [{dur}]")

    # Week summary
    if week_entries is not None:
        console.print("\n[bold]This Week[/bold]")
        days: dict[str, Decimal] = {}
        day_names = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
        for entry in week_entries:
            if entry.date:
                day_key = day_names[entry.date.weekday()]
                days[day_key] = days.get(day_key, Decimal("0")) + (entry.duration or Decimal("0"))

        week_total = sum(days.values(), Decimal("0"))
        for day_name in day_names:
            hrs = days.get(day_name, Decimal("0"))
            day_bar_width = 20
            day_pct = min(float(hrs / target_hours * 100), 100) if target_hours else 0
            day_filled = int(day_bar_width * day_pct / 100)
            day_bar = "\u2588" * day_filled + "\u2591" * (day_bar_width - day_filled)
            style = "green" if day_pct >= 100 else "yellow" if day_pct >= 50 else "dim"
            console.print(f"  {day_name} [{style}]{day_bar}[/{style}] {format_duration(hrs)}")

        console.print(f"\n  [bold]Week total:[/bold] {format_duration(week_total)}")

    console.print()


def format_weekly_table(entries_by_day: dict[str, list[TimeEntry]]) -> None:
    """Display entries grouped by day in a weekly view."""
    for day_label, entries in entries_by_day.items():
        day_total = sum((e.duration or Decimal("0")) for e in entries)
        console.print(f"\n[bold]{day_label}[/bold] - {format_duration(day_total)}")
        if entries:
            for entry in entries:
                dur = format_duration(entry.duration)
                desc = truncate(entry.description or "(no description)", 40)
                proj = f" [cyan]{entry.project_name}[/cyan]" if entry.project_name else ""
                console.print(f"  \u25cb {desc}{proj} [{dur}]")
        else:
            console.print("  [dim]No entries[/dim]")


def format_projects_table(projects: list[Project]) -> None:
    """Display projects in a table."""
    if not projects:
        console.print("[dim]No projects found.[/dim]")
        return

    table = Table(show_header=True, header_style="bold")
    table.add_column("ID", style="dim")
    table.add_column("Name", style="bold", width=20)
    table.add_column("Code", width=8)
    table.add_column("Client", width=15)
    table.add_column("Status", width=10)
    table.add_column("Billable", justify="center", width=8)

    for project in projects:
        status_style = "green" if project.status == "active" else "dim"
        table.add_row(
            str(project.id),
            project.name,
            project.code,
            project.client_name or "",
            f"[{status_style}]{project.status}[/{status_style}]",
            "[green]$[/green]" if project.is_billable else "",
        )

    console.print(table)


def format_parse_result(result: ParseResult) -> None:
    """Display AI parse result for confirmation."""
    conf_style = "green" if result.confidence > 0.8 else "yellow"

    console.print("\n[bold]Parsed Time Entry[/bold]")
    console.print(f"  Confidence: [{conf_style}]{result.confidence:.0%}[/{conf_style}]")

    if result.description:
        console.print(f"  Description: [bold]{result.description}[/bold]")
    if result.project_name:
        console.print(f"  Project:     [cyan]{result.project_name}[/cyan]")
    if result.task_name:
        console.print(f"  Task:        {result.task_name}")
    if result.hours is not None:
        console.print(f"  Duration:    [yellow]{format_duration(result.hours)}[/yellow]")
    if result.date:
        console.print(f"  Date:        {result.date}")
    console.print(f"  Billable:    {'Yes' if result.is_billable else 'No'}")

    if result.ambiguities:
        console.print("\n  [yellow]Ambiguities:[/yellow]")
        for amb in result.ambiguities:
            console.print(f"    - {amb}")

    console.print()


def format_suggestions(suggestions: list[Suggestion]) -> None:
    """Display AI suggestions as a numbered list."""
    if not suggestions:
        console.print("[dim]No suggestions available.[/dim]")
        return

    console.print("\n[bold]Suggested entries[/bold]\n")
    for i, s in enumerate(suggestions, 1):
        console.print(f"  [bold]{i}.[/bold] {s.description}")
        parts: list[str] = []
        if s.project_name:
            parts.append(f"[cyan]{s.project_name}[/cyan]")
        if s.task_name:
            parts.append(s.task_name)
        if s.estimated_hours:
            parts.append(f"[yellow]{format_duration(s.estimated_hours)}[/yellow]")
        if parts:
            console.print(f"     {' | '.join(parts)}")
        if s.reason:
            console.print(f"     [dim]{s.reason}[/dim]")
    console.print()


def format_favorites_table(favorites: list[FavoriteEntry]) -> None:
    """Display favorites in a table."""
    if not favorites:
        console.print("[dim]No favorites found.[/dim]")
        return

    table = Table(show_header=True, header_style="bold")
    table.add_column("ID", style="dim")
    table.add_column("Project", style="cyan", width=15)
    table.add_column("Task", width=15)
    table.add_column("Description", width=30)
    table.add_column("$", justify="center", width=3)
    table.add_column("Uses", justify="right", width=6)

    for fav in favorites:
        table.add_row(
            str(fav.id),
            fav.project_name or "",
            fav.task_name or "",
            truncate(fav.description, 30),
            "[green]$[/green]" if fav.is_billable else "",
            str(fav.use_count),
        )

    console.print(table)


def format_report(data: list[dict[str, Any]], group_by: str = "project") -> None:
    """Display report data in a table."""
    if not data:
        console.print("[dim]No data for this period.[/dim]")
        return

    # Check if any row has amount data
    has_amounts = any(row.get("total_amount") for row in data)

    table = Table(show_header=True, header_style="bold", title="Time Report")
    table.add_column(group_by.capitalize(), style="bold", width=20)
    table.add_column("Hours", justify="right", width=10)
    table.add_column("Billable", justify="right", width=10)
    if has_amounts:
        table.add_column("Amount", justify="right", width=12)
    table.add_column("Entries", justify="right", width=8)

    total_hours = Decimal("0")
    total_billable = Decimal("0")
    total_amount = Decimal("0")

    # Map group_by to actual API response key names
    group_key_map = {
        "project": ("project_name", "project"),
        "client": ("client_name", "client"),
        "task": ("task_name", "task"),
        "day": ("date", "day"),
    }

    for row in data:
        hours = Decimal(str(row.get("total_hours", row.get("hours", 0))))
        billable = Decimal(str(row.get("billable_hours", 0)))
        amount = Decimal(str(row.get("total_amount", 0)))
        total_hours += hours
        total_billable += billable
        total_amount += amount

        # Resolve the label for this row's group
        keys = group_key_map.get(group_by, (group_by,))
        label = ""
        for k in keys:
            label = row.get(k, "")
            if label:
                break
        if not label:
            label = row.get("project", row.get("project_name", ""))

        row_data = [
            str(label),
            format_duration(hours),
            format_duration(billable),
        ]
        if has_amounts:
            row_data.append(format_currency(amount))
        row_data.append(str(row.get("entry_count", row.get("entries_count", ""))))
        table.add_row(*row_data)

    section_data = [
        "[bold]Total[/bold]",
        f"[bold]{format_duration(total_hours)}[/bold]",
        f"[bold]{format_duration(total_billable)}[/bold]",
    ]
    if has_amounts:
        section_data.append(f"[bold]{format_currency(total_amount)}[/bold]")
    section_data.append("")

    table.add_section()
    table.add_row(*section_data)

    console.print(table)


ROLE_LABELS = {
    "owner": "Owner",
    "admin": "Admin",
    "manager": "Account Manager",
    "project_manager": "Project Manager",
    "member": "Member",
    "viewer": "Viewer",
}


def format_members_table(members: list[dict[str, Any]]) -> None:
    """Display organization members in a table."""
    if not members:
        console.print("[dim]No members found.[/dim]")
        return

    table = Table(show_header=True, header_style="bold")
    table.add_column("Name", width=20)
    table.add_column("Email", width=25)
    table.add_column("Role", width=18)
    table.add_column("Status", width=10)

    for m in members:
        status = "[green]Active[/green]" if m.get("is_active", True) else "[dim]Inactive[/dim]"
        role = m.get("role", "member")
        role_label = ROLE_LABELS.get(role, role)
        table.add_row(
            m.get("user_name", ""),
            m.get("user_email", ""),
            role_label,
            status,
        )

    console.print(table)


# ---------------------------------------------------------------------------
# Status styling — shared by timesheet, invoice, and other domain commands
# ---------------------------------------------------------------------------

_STATUS_STYLES: dict[str, dict[str, str]] = {
    "timesheet": {
        "submitted": "blue",
        "approved": "green",
        "rejected": "red",
        "draft": "dim",
    },
    "invoice": {
        "draft": "dim",
        "sent": "blue",
        "viewed": "cyan",
        "partial": "yellow",
        "paid": "green",
        "overdue": "red bold",
        "void": "red dim",
    },
}


def status_style(status: str | None, context: str = "default") -> str:
    """Return Rich markup style for a status value.

    *context* selects the style map: ``"timesheet"``, ``"invoice"``, etc.
    Falls back to ``"yellow"`` for unknown statuses.
    """
    styles = _STATUS_STYLES.get(context, {})
    return styles.get(status or "", "yellow")


def status_label(status: str | None, default: str = "Not Submitted") -> str:
    """Return human-readable label for a status value.

    *default* is returned when *status* is falsy (e.g. ``"Draft"`` for
    invoices, ``"Not Submitted"`` for timesheets).
    """
    if not status:
        return default
    return status.capitalize()


def print_json(data: Any) -> None:
    """Print data as formatted JSON."""
    if hasattr(data, "model_dump"):
        data = data.model_dump(mode="json")
    elif isinstance(data, list) and data and hasattr(data[0], "model_dump"):
        data = [item.model_dump(mode="json") for item in data]
    console.print_json(json.dumps(data, default=str))
