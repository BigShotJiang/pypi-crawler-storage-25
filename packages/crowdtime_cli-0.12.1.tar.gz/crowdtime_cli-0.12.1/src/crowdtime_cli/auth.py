"""Authentication and token management for CrowdTime CLI.

Stores API tokens in the system keyring, with file-based fallback.
"""

from __future__ import annotations

from pathlib import Path

from .config import CONFIG_DIR

SERVICE_NAME = "crowdtime"
USERNAME = "api_token"
CREDENTIALS_FILE = CONFIG_DIR / "credentials"


def save_token(token: str) -> None:
    """Store the API token, preferring keyring with file fallback."""
    try:
        import keyring

        keyring.set_password(SERVICE_NAME, USERNAME, token)
    except Exception:
        _save_token_file(token)


def get_token() -> str | None:
    """Retrieve the stored API token."""
    try:
        import keyring

        token = keyring.get_password(SERVICE_NAME, USERNAME)
        if token:
            return token
    except Exception:
        pass
    return _get_token_file()


def clear_token() -> None:
    """Remove the stored API token."""
    try:
        import keyring

        keyring.delete_password(SERVICE_NAME, USERNAME)
    except Exception:
        pass
    _clear_token_file()


def _save_token_file(token: str) -> None:
    """File-based fallback for token storage."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CREDENTIALS_FILE.write_text(token)
    CREDENTIALS_FILE.chmod(0o600)


def _get_token_file() -> str | None:
    """File-based fallback for token retrieval."""
    if CREDENTIALS_FILE.exists():
        content = CREDENTIALS_FILE.read_text().strip()
        return content if content else None
    return None


def _clear_token_file() -> None:
    """Remove file-based token."""
    if CREDENTIALS_FILE.exists():
        CREDENTIALS_FILE.unlink()
