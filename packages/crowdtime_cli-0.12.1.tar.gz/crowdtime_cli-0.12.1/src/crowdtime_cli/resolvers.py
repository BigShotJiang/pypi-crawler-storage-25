"""Shared name-to-UUID resolution helpers for CLI commands."""

from __future__ import annotations

from rich.console import Console

from .client import APIError, CrowdTimeClient
from .formatters import extract_results
from .utils import is_uuid

console = Console(stderr=True)


def resolve_project(client: CrowdTimeClient, project_ref: str) -> str:
    """Resolve a project name, code, or UUID to a UUID.

    Args:
        client: Authenticated API client.
        project_ref: Project UUID, code, or name.

    Returns:
        The project UUID string.

    Raises:
        APIError: If the project cannot be found.
    """
    if is_uuid(project_ref):
        return project_ref

    # Search by name/code
    data = client.get("/projects/", params={"search": project_ref})
    projects_list = extract_results(data)

    # Try exact code match first (case-insensitive)
    for p in projects_list:
        if (p.get("code") or "").lower() == project_ref.lower():
            return p["id"]

    # Then try exact name match (case-insensitive)
    for p in projects_list:
        if (p.get("name") or "").lower() == project_ref.lower():
            return p["id"]

    # Single result — use it
    if len(projects_list) == 1:
        return projects_list[0]["id"]

    if not projects_list:
        raise APIError(f"No project found matching '{project_ref}'.", status_code=404)

    # Multiple ambiguous matches
    names = [f"{p.get('name')} ({p.get('code', '')})" for p in projects_list[:5]]
    raise APIError(
        f"Multiple projects match '{project_ref}': {', '.join(names)}. Use the project UUID instead.",
        status_code=400,
    )


def resolve_task(client: CrowdTimeClient, task_ref: str, project_id: str | None = None) -> str:
    """Resolve a task name or UUID to a UUID. Auto-assigns to project if needed.

    Args:
        client: Authenticated API client.
        task_ref: Task name or UUID.
        project_id: If provided, ensures the task is assigned to this project.

    Returns:
        The task UUID string.
    """
    # If it looks like a UUID already, use it directly
    if is_uuid(task_ref):
        task_id = task_ref
    else:
        # Search org tasks by name
        data = client.get("/tasks/", params={"search": task_ref})
        tasks_list = extract_results(data)

        # Exact match (case-insensitive)
        task_id = None
        for t in tasks_list:
            if t.get("name", "").lower() == task_ref.lower():
                task_id = t["id"]
                break

        if task_id is None:
            # No match — create the task
            console.print(f"[dim]Task '{task_ref}' not found — creating it...[/dim]")
            new_task = client.post("/tasks/", data={"name": task_ref})
            task_id = new_task["id"]

    # If a project is specified, ensure the task is assigned to it
    if project_id:
        _ensure_task_assigned_to_project(client, task_id, project_id)

    return task_id


def _ensure_task_assigned_to_project(
    client: CrowdTimeClient, task_id: str, project_id: str
) -> None:
    """Check if a task is assigned to a project; assign it if not."""
    # List tasks currently assigned to the project
    try:
        data = client.get(f"/projects/{project_id}/tasks/")
        assigned = extract_results(data)

        for pt in assigned:
            # The response has 'task' (UUID) field
            if pt.get("task") == task_id:
                return  # Already assigned

        # Not assigned — assign it
        console.print(f"[dim]Assigning task to project...[/dim]")
        client.post(f"/projects/{project_id}/tasks/", data={"task": task_id})
    except APIError:
        # If we can't check/assign, let the API validate later
        pass


