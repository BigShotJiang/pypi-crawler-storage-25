"""Authentication commands: login, logout, whoami, data-export, delete-account."""

from __future__ import annotations

import json
from typing import Optional

import typer
from rich.console import Console

from ..auth import clear_token, get_token, save_token
from ..client import CrowdTimeClient
from ..config import get_config
from ..formatters import format_error, format_success, print_json
from ..models import User

app = typer.Typer(name="auth", help="Authentication commands.")
console = Console()


@app.command()
def login(
    token: Optional[str] = typer.Option(
        None, "--token", "-t",
        help="API token for manual authentication (skips browser login).",
    ),
    no_browser: bool = typer.Option(
        False, "--no-browser",
        help="Don't open a browser. Prompt for token instead.",
    ),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Authenticate with the CrowdTime server.

    By default, opens your browser for Google OAuth login.
    Use --token to provide an API token directly, or --no-browser to be prompted.
    """
    if token:
        _login_with_token(token, output_json)
    elif no_browser:
        manual_token = typer.prompt("API Token", hide_input=True)
        if not manual_token or not manual_token.strip():
            format_error("Token cannot be empty.")
            raise typer.Exit(1)
        _login_with_token(manual_token.strip(), output_json)
    else:
        _login_with_browser(output_json)


def _login_with_token(token: str, output_json: bool) -> None:
    """Authenticate using a provided API token."""
    token = token.strip()
    if not token:
        format_error("Token cannot be empty.")
        raise typer.Exit(1)

    save_token(token)
    try:
        client = CrowdTimeClient(require_auth=True, require_org=False)
        data = client.get("/api/v1/auth/me/", org_scoped=False)
        user = User(**data)

        if output_json:
            print_json(user)
        else:
            format_success(f"Logged in as {user.display_name} ({user.email})")
    except SystemExit:
        clear_token()
        format_error("Invalid token. Could not authenticate.")
        raise typer.Exit(1)


def _login_with_browser(output_json: bool) -> None:
    """Authenticate via browser-based Google OAuth."""
    from ..oauth import run_oauth_flow

    config = get_config()
    server_url = config.server_url

    console.print(f"\n[bold]Opening browser for Google login...[/bold]")
    console.print(f"[dim]Server: {server_url}[/dim]")
    console.print(f"[dim]Waiting for authentication (up to 2 minutes)...[/dim]\n")

    result = run_oauth_flow(server_url)

    if result is None:
        console.print()
        format_error(
            "Browser login failed or timed out.\n"
            "  Possible causes:\n"
            "  - Browser didn't open (try copying the URL manually)\n"
            "  - Google OAuth is not configured on the server\n"
            "  - Login was cancelled or took too long\n\n"
            "  You can also login with a token:\n"
            "    ct auth login --token <your-api-token>\n"
            "    ct auth login --no-browser"
        )
        raise typer.Exit(1)

    api_token, org_slug = result

    # Store the token
    save_token(api_token)

    # Auto-set the organization if returned
    if org_slug:
        config.set("defaults.organization", org_slug)

    # Verify the token works
    try:
        client = CrowdTimeClient(require_auth=True, require_org=False)
        data = client.get("/api/v1/auth/me/", org_scoped=False)
        user = User(**data)

        if output_json:
            print_json(user)
        else:
            format_success(f"Logged in as {user.display_name} ({user.email})")
            if org_slug:
                console.print(f"  Organization set to [cyan]{org_slug}[/cyan]")
            console.print()
    except SystemExit:
        clear_token()
        format_error("Token verification failed after OAuth login.")
        raise typer.Exit(1)


@app.command()
def logout() -> None:
    """Log out and remove stored credentials."""
    if not get_token():
        console.print("[dim]Already logged out.[/dim]")
        return

    clear_token()
    format_success("Logged out. Token removed.")


@app.command()
def whoami(
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Show the currently authenticated user and organization."""
    client = CrowdTimeClient(require_auth=True, require_org=False)
    data = client.get("/api/v1/auth/me/", org_scoped=False)
    user = User(**data)

    if output_json:
        print_json(user)
        return

    console.print(f"\n[bold]{user.display_name}[/bold]")
    console.print(f"  Email:    {user.email}")
    console.print(f"  Timezone: {user.timezone}")

    org_slug = client.config.organization
    if org_slug:
        console.print(f"  Org:      [cyan]{org_slug}[/cyan]")
    else:
        console.print("  Org:      [dim]Not set (run ct org switch <slug>)[/dim]")
    console.print()


@app.command("data-export")
def data_export(
    output_file: Optional[str] = typer.Option(
        None, "--output", "-o",
        help="Write export to file instead of stdout.",
    ),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON (default for this command)."),
) -> None:
    """Export all your personal data (GDPR data portability).

    Downloads a JSON dump of all your data across all organizations:
    time entries, timesheets, favorites, expenses, API tokens, etc.
    """
    client = CrowdTimeClient(require_auth=True, require_org=False)
    data = client.get("/api/v1/auth/data-export/", org_scoped=False)

    formatted = json.dumps(data, indent=2, default=str)

    if output_file:
        with open(output_file, "w") as f:
            f.write(formatted)
        format_success(f"Data exported to {output_file}")
        console.print(f"  [dim]{len(data.get('time_entries', []))} time entries, "
                      f"{len(data.get('timesheets', []))} timesheets, "
                      f"{len(data.get('favorites', []))} favorites[/dim]")
    else:
        console.print(formatted)


@app.command("delete-account")
def delete_account(
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation prompt."),
    cancel: bool = typer.Option(False, "--cancel", help="Cancel a pending account deletion."),
    status_check: bool = typer.Option(False, "--status", help="Check deletion status."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Request or cancel account deletion (GDPR right to erasure).

    Schedules your account for permanent deletion after a 30-day grace period.
    During the grace period, you can cancel with --cancel.
    """
    client = CrowdTimeClient(require_auth=True, require_org=False)

    if status_check:
        data = client.get("/api/v1/auth/delete-account/", org_scoped=False)
        if output_json:
            console.print(json.dumps(data, indent=2))
        elif data.get("scheduled"):
            console.print(f"[yellow]Account deletion scheduled[/yellow]")
            console.print(f"  Scheduled at: {data['scheduled_at']}")
            console.print(f"  Deletes after: {data['delete_after']}")
        else:
            console.print("[dim]No pending account deletion.[/dim]")
        return

    if cancel:
        client.delete("/api/v1/auth/delete-account/", org_scoped=False)
        format_success("Account deletion cancelled.")
        return

    # Request deletion
    if not force and not output_json:
        console.print("\n[bold red]⚠ Account Deletion[/bold red]")
        console.print("This will permanently delete your account and all associated data after 30 days.")
        console.print("During the grace period, you can cancel with: ct auth delete-account --cancel\n")
        if not typer.confirm("Are you sure you want to delete your account?"):
            console.print("[dim]Cancelled.[/dim]")
            raise typer.Exit(0)

    # Build request body
    from ..auth import get_token as _get_token
    body = {}

    # Check if user has a password (try password-based confirmation)
    me_data = client.get("/api/v1/auth/change-password/", org_scoped=False)
    if me_data.get("has_password"):
        if output_json or force:
            password = typer.prompt("Password", hide_input=True)
        else:
            password = typer.prompt("Enter your password to confirm", hide_input=True)
        body["password"] = password
    else:
        body["confirm"] = True

    data = client.post("/api/v1/auth/delete-account/", data=body, org_scoped=False)

    if output_json:
        console.print(json.dumps(data, indent=2))
    else:
        console.print(f"\n[yellow]{data.get('detail', 'Account deletion scheduled.')}[/yellow]")
        if data.get("delete_after"):
            console.print(f"  Deletes after: {data['delete_after']}")
        console.print(f"\n  To cancel: [bold]ct auth delete-account --cancel[/bold]\n")
