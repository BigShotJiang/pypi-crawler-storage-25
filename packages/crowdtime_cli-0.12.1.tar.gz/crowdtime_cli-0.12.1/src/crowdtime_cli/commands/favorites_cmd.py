"""Favorites commands: list, show, create, edit, delete, start."""

from __future__ import annotations

from typing import Optional

import typer
from rich.console import Console

from ..client import APIError, CrowdTimeClient
from ..formatters import (
    extract_results,
    format_error,
    format_favorite_detail,
    format_favorites_table,
    format_success,
    format_timer,
    print_json,
)
from ..models import FavoriteEntry, TimeEntry
from ..resolvers import resolve_project, resolve_task

app = typer.Typer(name="favorites", help="Manage favorite time entry templates.")
console = Console()


@app.command("list")
def list_favorites(
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """List all saved favorites."""
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.get("/favorites/")
        favs_list = extract_results(data)
        favorites = [FavoriteEntry(**item) for item in favs_list]

        if output_json:
            print_json(favorites)
        else:
            format_favorites_table(favorites)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command()
def show(
    favorite_id: str = typer.Argument(..., help="Favorite ID to view."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Show details of a favorite."""
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.get(f"/favorites/{favorite_id}/")
        fav = FavoriteEntry(**data)

        if output_json:
            print_json(fav)
        else:
            format_favorite_detail(fav)
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Favorite {favorite_id} not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@app.command()
def edit(
    favorite_id: str = typer.Argument(..., help="Favorite ID to edit."),
    project: Optional[str] = typer.Option(None, "--project", "-p", help="New project name or ID."),
    task: Optional[str] = typer.Option(None, "--task", "-t", help="New task name or ID."),
    notes: Optional[str] = typer.Option(None, "--notes", "-n", help="New description/notes."),
    billable: Optional[bool] = typer.Option(None, "--billable/--no-billable", "-b/-B",
                                            help="Mark as billable/non-billable."),
    position: Optional[int] = typer.Option(None, "--position", help="Display position (0-based)."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Edit an existing favorite template.

    Examples:
        ct favorites edit <id> --notes "Updated description"
        ct favorites edit <id> --project my-project --task Design
        ct favorites edit <id> --no-billable
        ct favorites edit <id> --position 0
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    payload: dict = {}
    if notes is not None:
        payload["notes"] = notes
    resolved_project_id = None
    if project is not None:
        try:
            resolved_project_id = resolve_project(client, project)
            payload["project"] = resolved_project_id
        except APIError as e:
            format_error(f"Failed to resolve project '{project}': {e.message}")
            raise typer.Exit(1)
    if task is not None:
        try:
            payload["task"] = resolve_task(client, task, project_id=resolved_project_id)
        except APIError as e:
            format_error(f"Failed to resolve task '{task}': {e.message}")
            raise typer.Exit(1)
    if billable is not None:
        payload["is_billable"] = billable
    if position is not None:
        payload["position"] = position

    if not payload:
        format_error("No changes specified. Use --notes, --project, --task, --billable, or --position.")
        raise typer.Exit(1)

    try:
        data = client.patch(f"/favorites/{favorite_id}/", data=payload)
        fav = FavoriteEntry(**data)

        if output_json:
            print_json(fav)
        else:
            format_success(f"Favorite updated (ID: {fav.id})")
            format_favorite_detail(fav)
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Favorite {favorite_id} not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@app.command()
def create(
    description: str = typer.Argument("", help="Description for the favorite."),
    project: Optional[str] = typer.Option(None, "--project", "-p", help="Project name or ID."),
    task: Optional[str] = typer.Option(None, "--task", "-t", help="Task name or ID."),
    notes: Optional[str] = typer.Option(None, "--notes", "-n", help="Additional notes."),
    billable: bool = typer.Option(True, "--billable/--no-billable", "-b/-B",
                                  help="Mark as billable."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Create a new favorite entry template."""
    client = CrowdTimeClient(require_auth=True, require_org=True)

    # Resolve project — accept name, code, or UUID
    project_ref = project or client.config.default_project
    if not project_ref:
        format_error("Project is required. Use -p <project> or set a default with: ct projects switch <slug>")
        raise typer.Exit(1)

    try:
        project_id = resolve_project(client, project_ref)
    except APIError as e:
        format_error(f"Failed to resolve project '{project_ref}': {e.message}")
        raise typer.Exit(1)

    # Combine description and notes: description is the main text,
    # --notes appends additional context
    combined_notes = description
    if notes:
        combined_notes = f"{description}\n{notes}".strip() if description else notes

    payload: dict = {
        "is_billable": billable,
        "project": project_id,
    }
    if combined_notes:
        payload["notes"] = combined_notes
    if task:
        try:
            payload["task"] = resolve_task(client, task, project_id=project_id)
        except APIError as e:
            format_error(f"Failed to resolve task '{task}': {e.message}")
            raise typer.Exit(1)

    try:
        data = client.post("/favorites/", data=payload)
        fav = FavoriteEntry(**data)

        if output_json:
            print_json(fav)
        else:
            desc = fav.notes or "(no description)"
            format_success(f"Favorite '{desc}' created (ID: {fav.id})")
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command()
def delete(
    favorite_id: str = typer.Argument(..., help="Favorite ID to delete."),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation."),
) -> None:
    """Delete a favorite."""
    client = CrowdTimeClient(require_auth=True, require_org=True)

    if not force:
        try:
            data = client.get(f"/favorites/{favorite_id}/")
            fav = FavoriteEntry(**data)
            desc = fav.notes or fav.project_name or favorite_id
        except APIError as e:
            if e.status_code == 404:
                format_error(f"Favorite {favorite_id} not found.")
                raise typer.Exit(1)
            desc = favorite_id
        if not typer.confirm(f"Delete favorite '{desc}'?"):
            console.print("[dim]Cancelled.[/dim]")
            return

    try:
        client.delete(f"/favorites/{favorite_id}/")
        format_success(f"Favorite deleted (ID: {favorite_id}).")
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Favorite {favorite_id} not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@app.command()
def start(
    favorite_id: str = typer.Argument(..., help="Favorite ID to start timer from."),
    note: Optional[str] = typer.Option(None, "--note", "-n", help="Override the favorite's description."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Start a timer from a favorite template.

    Use --note to override the saved description with something specific.
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    payload: dict = {}
    if note is not None:
        payload["notes"] = note

    try:
        data = client.post(f"/favorites/{favorite_id}/start/", data=payload if payload else None)
        entry = TimeEntry(**data)

        if output_json:
            print_json(entry)
        else:
            format_success("Timer started from favorite")
            format_timer(entry)
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Favorite {favorite_id} not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)
