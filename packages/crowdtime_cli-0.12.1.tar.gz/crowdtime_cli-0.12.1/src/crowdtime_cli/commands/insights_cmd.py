"""Insights commands: projects, team, overview — PM analytics and health dashboards."""

from __future__ import annotations

from decimal import Decimal
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from ..client import APIError, CrowdTimeClient
from ..formatters import extract_results, format_currency, format_error, print_json
from ..utils import format_date, format_duration, resolve_period

app = typer.Typer(name="insights", help="Project health, team utilization, and analytics.")
console = Console()


def _resolve_period(**kwargs) -> tuple[str, str]:
    """Insights default to this month (vs this week for reports)."""
    return resolve_period(**kwargs, default="month")


@app.command("projects")
def projects_insights(
    week: bool = typer.Option(False, "--week", "-w", help="This week."),
    last_week: bool = typer.Option(False, "--last-week", help="Last week."),
    month: bool = typer.Option(False, "--month", help="This month (default)."),
    last_month: bool = typer.Option(False, "--last-month", help="Last month."),
    quarter: bool = typer.Option(False, "--quarter", "-q", help="This quarter."),
    last_quarter: bool = typer.Option(False, "--last-quarter", help="Last quarter."),
    from_date: Optional[str] = typer.Option(None, "--from", help="Start date (YYYY-MM-DD)."),
    to_date: Optional[str] = typer.Option(None, "--to", help="End date (YYYY-MM-DD)."),
    at_risk: bool = typer.Option(False, "--at-risk", help="Show only projects at or above budget alert threshold."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Project health dashboard with budget forecasting and alerts.

    Shows budget usage, burn rate, exhaustion date, and weekly trends
    for all active projects. Requires project_manager+ role.

    Examples:
        ct insights projects
        ct insights projects --quarter
        ct insights projects --at-risk
        ct insights projects --from 2025-01-01 --to 2025-03-31
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    period_from, period_to = _resolve_period(
        week=week, last_week=last_week, month=month, last_month=last_month,
        quarter=quarter, last_quarter=last_quarter,
        from_date=from_date, to_date=to_date,
    )

    try:
        data = client.get("/insights/projects/", params={
            "date_from": period_from,
            "date_to": period_to,
        })

        if output_json:
            if at_risk:
                alert_project_ids = {a.get("project_id") for a in data.get("alerts", [])}
                data["projects"] = [p for p in data.get("projects", []) if p.get("id") in alert_project_ids]
            print_json(data)
            return

        projects = data.get("projects", [])
        alerts = data.get("alerts", [])

        # Filter to at-risk projects only
        if at_risk:
            alert_project_ids = {a.get("project_id") for a in alerts}
            projects = [p for p in projects if p.get("id") in alert_project_ids]

        console.print(f"\n[dim]Project Insights: {period_from} to {period_to}[/dim]")

        if not projects:
            msg = "No at-risk projects found." if at_risk else "No active projects found."
            console.print(f"[dim]{msg}[/dim]\n")
            return

        # Show alerts first if any
        if alerts:
            alert_lines = []
            for a in alerts:
                icon = "[red]!![/red]" if a.get("severity") == "danger" else "[yellow]![/yellow]"
                alert_lines.append(f"  {icon} {a['project']}: {a['message']}")
            console.print(Panel(
                "\n".join(alert_lines),
                title="[bold]Budget Alerts[/bold]",
                border_style="yellow",
                expand=False,
            ))

        table = Table(show_header=True, header_style="bold", title="Project Health")
        table.add_column("Project", min_width=16)
        table.add_column("Client", min_width=12)
        table.add_column("Hours", justify="right", width=10)
        table.add_column("Billable", justify="right", width=10)
        table.add_column("Members", justify="right", width=8)
        table.add_column("Budget", justify="right", width=12)
        table.add_column("Used %", justify="right", width=8)
        table.add_column("Burn/Wk", justify="right", width=10)
        table.add_column("Exhaustion", width=12)

        for p in projects:
            hours = format_duration(Decimal(str(p.get("hours", 0))))
            billable_h = format_duration(Decimal(str(p.get("billable_hours", 0))))
            members = str(p.get("member_count", 0))
            budget_type = p.get("budget_type", "none")
            budget_amount = p.get("budget_amount")

            # Budget display
            if budget_amount and budget_type != "none":
                if budget_type == "hours":
                    budget_str = f"{budget_amount}h"
                else:
                    budget_str = format_currency(Decimal(str(budget_amount)))
            else:
                budget_str = "[dim]--[/dim]"

            # Usage percentage with color
            pct = p.get("budget_used_pct")
            if pct is not None:
                if pct >= 95:
                    pct_str = f"[red]{pct:.0f}%[/red]"
                elif pct >= 80:
                    pct_str = f"[yellow]{pct:.0f}%[/yellow]"
                else:
                    pct_str = f"[green]{pct:.0f}%[/green]"
            else:
                pct_str = "[dim]--[/dim]"

            # Burn rate
            burn = p.get("burn_rate_weekly")
            if burn is not None:
                if budget_type == "hours":
                    burn_str = f"{burn}h"
                else:
                    burn_str = format_currency(Decimal(str(burn)))
            else:
                burn_str = "[dim]--[/dim]"

            # Exhaustion date
            exhaust = p.get("estimated_exhaustion_date")
            if exhaust:
                exhaust_str = f"[yellow]{exhaust}[/yellow]"
            elif pct is not None and pct >= 100:
                exhaust_str = "[red]Exceeded[/red]"
            else:
                exhaust_str = "[dim]--[/dim]"

            table.add_row(
                p.get("name", ""),
                p.get("client_name") or "[dim]--[/dim]",
                hours,
                billable_h,
                members,
                budget_str,
                pct_str,
                burn_str,
                exhaust_str,
            )

        console.print(table)
        console.print()
    except APIError as e:
        if e.status_code == 403:
            format_error("Insufficient permissions. Requires project_manager or higher.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@app.command("team")
def team_insights(
    week: bool = typer.Option(False, "--week", "-w", help="This week."),
    last_week: bool = typer.Option(False, "--last-week", help="Last week."),
    month: bool = typer.Option(False, "--month", help="This month (default)."),
    last_month: bool = typer.Option(False, "--last-month", help="Last month."),
    quarter: bool = typer.Option(False, "--quarter", "-q", help="This quarter."),
    last_quarter: bool = typer.Option(False, "--last-quarter", help="Last quarter."),
    from_date: Optional[str] = typer.Option(None, "--from", help="Start date (YYYY-MM-DD)."),
    to_date: Optional[str] = typer.Option(None, "--to", help="End date (YYYY-MM-DD)."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Team utilization and workload dashboard.

    Shows per-member hours, utilization percentage, capacity usage,
    and timesheet status. Requires project_manager+ role.

    Examples:
        ct insights team
        ct insights team --week
        ct insights team --last-month
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    period_from, period_to = _resolve_period(
        week=week, last_week=last_week, month=month, last_month=last_month,
        quarter=quarter, last_quarter=last_quarter,
        from_date=from_date, to_date=to_date,
    )

    try:
        data = client.get("/insights/team/", params={
            "date_from": period_from,
            "date_to": period_to,
        })

        if output_json:
            print_json(data)
            return

        members = data.get("members", [])
        summary = data.get("summary", {})

        console.print(f"\n[dim]Team Insights: {period_from} to {period_to}[/dim]")

        if not members:
            console.print("[dim]No team members found.[/dim]\n")
            return

        # Summary panel
        avg_util = summary.get("avg_utilization", 0)
        overloaded = summary.get("overloaded_count", 0)
        underutilized = summary.get("underutilized_count", 0)
        pending_ts = summary.get("timesheets_pending", 0)

        summary_parts = []
        summary_parts.append(f"  Avg Utilization: [bold]{avg_util:.0f}%[/bold]")
        if overloaded:
            summary_parts.append(f"  Overloaded:      [red]{overloaded}[/red]")
        if underutilized:
            summary_parts.append(f"  Underutilized:   [yellow]{underutilized}[/yellow]")
        if pending_ts:
            summary_parts.append(f"  Pending Sheets:  [yellow]{pending_ts}[/yellow]")

        console.print(Panel(
            "\n".join(summary_parts),
            title="[bold]Team Summary[/bold]",
            border_style="blue",
            expand=False,
        ))

        table = Table(show_header=True, header_style="bold", title="Team Members")
        table.add_column("Member", min_width=20)
        table.add_column("Hours", justify="right", width=10)
        table.add_column("Billable", justify="right", width=10)
        table.add_column("Utilization", justify="right", width=12)
        table.add_column("Capacity", justify="right", width=10)
        table.add_column("Timesheet", width=12)

        for m in members:
            total_h = format_duration(Decimal(str(m.get("total_hours", 0))))
            billable_h = format_duration(Decimal(str(m.get("billable_hours", 0))))

            util_pct = m.get("utilization_pct", 0)
            if util_pct >= 90:
                util_str = f"[green]{util_pct:.0f}%[/green]"
            elif util_pct >= 50:
                util_str = f"[yellow]{util_pct:.0f}%[/yellow]"
            else:
                util_str = f"[red]{util_pct:.0f}%[/red]"

            cap_pct = m.get("capacity_pct", 0)
            if cap_pct > 110:
                cap_str = f"[red]{cap_pct:.0f}%[/red]"
            elif cap_pct >= 80:
                cap_str = f"[green]{cap_pct:.0f}%[/green]"
            else:
                cap_str = f"[dim]{cap_pct:.0f}%[/dim]"

            ts_status = m.get("timesheet_status", "unknown")
            ts_map = {
                "approved": "[green]Approved[/green]",
                "submitted": "[blue]Submitted[/blue]",
                "draft": "[dim]Draft[/dim]",
                "rejected": "[red]Rejected[/red]",
                "not_submitted": "[yellow]Missing[/yellow]",
            }
            ts_str = ts_map.get(ts_status, ts_status)

            name = m.get("name") or m.get("email", "")

            table.add_row(name, total_h, billable_h, util_str, cap_str, ts_str)

        console.print(table)
        console.print()
    except APIError as e:
        if e.status_code == 403:
            format_error("Insufficient permissions. Requires project_manager or higher.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@app.command("allocations")
def allocations_insights(
    week: bool = typer.Option(False, "--week", "-w", help="This week."),
    last_week: bool = typer.Option(False, "--last-week", help="Last week."),
    month: bool = typer.Option(False, "--month", help="This month (default)."),
    last_month: bool = typer.Option(False, "--last-month", help="Last month."),
    quarter: bool = typer.Option(False, "--quarter", "-q", help="This quarter."),
    last_quarter: bool = typer.Option(False, "--last-quarter", help="Last quarter."),
    from_date: Optional[str] = typer.Option(None, "--from", help="Start date (YYYY-MM-DD)."),
    to_date: Optional[str] = typer.Option(None, "--to", help="End date (YYYY-MM-DD)."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Team resource allocation — who is working where.

    Shows per-member per-project hour breakdown with capacity usage.
    Helps PMs identify who is overloaded, underutilized, or available.
    Requires project_manager+ role.

    Examples:
        ct insights allocations
        ct insights allocations --week
        ct insights allocations --last-month
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    period_from, period_to = _resolve_period(
        week=week, last_week=last_week, month=month, last_month=last_month,
        quarter=quarter, last_quarter=last_quarter,
        from_date=from_date, to_date=to_date,
    )

    try:
        data = client.get("/insights/allocations/", params={
            "date_from": period_from,
            "date_to": period_to,
        })

        if output_json:
            print_json(data)
            return

        allocations = data.get("allocations", [])

        console.print(f"\n[dim]Team Allocations: {period_from} to {period_to}[/dim]")

        if not allocations:
            console.print("[dim]No time entries found for this period.[/dim]\n")
            return

        for member in allocations:
            name = member.get("name", "")
            total_h = format_duration(Decimal(str(member.get("total_hours", 0))))
            cap_pct = member.get("capacity_pct", 0)
            avail_h = format_duration(Decimal(str(member.get("available_hours", 0))))

            if cap_pct > 100:
                cap_str = f"[red]{cap_pct:.0f}%[/red]"
            elif cap_pct >= 80:
                cap_str = f"[green]{cap_pct:.0f}%[/green]"
            else:
                cap_str = f"[dim]{cap_pct:.0f}%[/dim]"

            console.print(
                f"\n[bold]{name}[/bold]  "
                f"{total_h} logged  |  {cap_str} capacity  |  {avail_h} available"
            )

            projects = member.get("projects", [])
            if projects:
                table = Table(show_header=True, header_style="dim", box=None, padding=(0, 2))
                table.add_column("Project", min_width=20)
                table.add_column("Hours", justify="right", width=10)
                table.add_column("Billable", justify="right", width=10)
                table.add_column("% Time", justify="right", width=8)

                for p in projects:
                    pct = p.get("pct", 0)
                    pct_str = f"{pct:.0f}%"
                    table.add_row(
                        p.get("project_name", ""),
                        format_duration(Decimal(str(p.get("hours", 0)))),
                        format_duration(Decimal(str(p.get("billable_hours", 0)))),
                        pct_str,
                    )
                console.print(table)
            else:
                console.print("  [dim]No time logged[/dim]")

        console.print()
    except APIError as e:
        if e.status_code == 403:
            format_error("Insufficient permissions. Requires project_manager or higher.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@app.command("financial")
def financial_insights(
    week: bool = typer.Option(False, "--week", "-w", help="This week."),
    last_week: bool = typer.Option(False, "--last-week", help="Last week."),
    month: bool = typer.Option(False, "--month", help="This month (default)."),
    last_month: bool = typer.Option(False, "--last-month", help="Last month."),
    quarter: bool = typer.Option(False, "--quarter", "-q", help="This quarter."),
    last_quarter: bool = typer.Option(False, "--last-quarter", help="Last quarter."),
    from_date: Optional[str] = typer.Option(None, "--from", help="Start date (YYYY-MM-DD)."),
    to_date: Optional[str] = typer.Option(None, "--to", help="End date (YYYY-MM-DD)."),
    compare: bool = typer.Option(False, "--compare", "-c", help="Compare with previous period."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Financial dashboard with revenue KPIs, AR aging, and top clients.

    Shows total revenue, average hourly rate, billable ratio, uninvoiced
    amount, AR aging buckets, revenue trends, and top 5 clients by revenue.
    Requires manager+ role.

    Examples:
        ct insights financial
        ct insights financial --quarter
        ct insights financial --last-month --compare
        ct insights financial --from 2026-01-01 --to 2026-03-31
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    period_from, period_to = _resolve_period(
        week=week, last_week=last_week, month=month, last_month=last_month,
        quarter=quarter, last_quarter=last_quarter,
        from_date=from_date, to_date=to_date,
    )

    params: dict = {"date_from": period_from, "date_to": period_to}
    if compare:
        params["compare"] = "true"

    try:
        data = client.get("/insights/financial/", params=params)

        if output_json:
            print_json(data)
            return

        current = data.get("current", {})
        previous = data.get("previous")
        ar_aging = data.get("ar_aging", {})
        revenue_trend = data.get("revenue_trend", [])
        top_clients = data.get("top_clients", [])

        console.print(f"\n[dim]Financial Insights: {period_from} to {period_to}[/dim]")

        # ─── KPI Panel ────────────────────────────────────
        kpi_lines = []
        revenue = current.get("total_revenue", 0)
        avg_rate = current.get("avg_hourly_rate", 0)
        billable_ratio = current.get("billable_ratio", 0)
        uninvoiced = current.get("uninvoiced_amount", 0)
        outstanding = current.get("outstanding_ar", 0)
        overdue = current.get("overdue_ar", 0)

        kpi_lines.append(f"  Revenue:         [bold]{format_currency(revenue)}[/bold]")
        kpi_lines.append(f"  Avg Hourly Rate: [bold]{format_currency(avg_rate)}[/bold]/hr")
        kpi_lines.append(f"  Billable Ratio:  [bold]{billable_ratio:.1f}%[/bold]")
        kpi_lines.append(f"  Uninvoiced:      [yellow]{format_currency(uninvoiced)}[/yellow]")
        kpi_lines.append(f"  Outstanding AR:  {format_currency(outstanding)}")
        if overdue > 0:
            kpi_lines.append(f"  Overdue AR:      [red]{format_currency(overdue)}[/red]")

        if previous:
            prev_rev = previous.get("total_revenue", 0)
            if prev_rev > 0:
                change_pct = (revenue - prev_rev) / prev_rev * 100
                arrow = "[green]↑" if change_pct >= 0 else "[red]↓"
                kpi_lines.append(f"  vs Previous:     {arrow} {abs(change_pct):.1f}%[/]")

        console.print(Panel(
            "\n".join(kpi_lines),
            title="[bold]Financial KPIs[/bold]",
            border_style="green",
            expand=False,
        ))

        # ─── AR Aging Table ────────────────────────────────
        total_ar = sum(ar_aging.values())
        if total_ar > 0:
            ar_table = Table(show_header=True, header_style="bold", title="Accounts Receivable Aging")
            ar_table.add_column("Bucket", width=16)
            ar_table.add_column("Amount", justify="right", width=14)
            ar_table.add_column("% of AR", justify="right", width=10)

            buckets = [
                ("Current", ar_aging.get("current", 0)),
                ("1-30 days", ar_aging.get("days_1_30", 0)),
                ("31-60 days", ar_aging.get("days_31_60", 0)),
                ("61-90 days", ar_aging.get("days_61_90", 0)),
                ("90+ days", ar_aging.get("days_90_plus", 0)),
            ]

            for label, amount in buckets:
                if amount > 0:
                    pct = amount / total_ar * 100
                    style = "[red]" if "90" in label or "61" in label else ""
                    end_style = "[/red]" if style else ""
                    ar_table.add_row(
                        f"{style}{label}{end_style}",
                        f"{style}{format_currency(amount)}{end_style}",
                        f"{style}{pct:.0f}%{end_style}",
                    )

            ar_table.add_section()
            ar_table.add_row("[bold]Total[/bold]", f"[bold]{format_currency(total_ar)}[/bold]", "")
            console.print(ar_table)

        # ─── Top Clients ──────────────────────────────────
        if top_clients:
            clients_table = Table(show_header=True, header_style="bold", title="Top Clients by Revenue")
            clients_table.add_column("Client", min_width=20)
            clients_table.add_column("Revenue", justify="right", width=14)
            clients_table.add_column("Hours", justify="right", width=10)

            for c in top_clients:
                clients_table.add_row(
                    c.get("name", "Unknown"),
                    format_currency(c.get("revenue", 0)),
                    format_duration(Decimal(str(c.get("hours", 0)))),
                )
            console.print(clients_table)

        # ─── Revenue Trend ─────────────────────────────────
        if revenue_trend:
            trend_table = Table(show_header=True, header_style="bold", title="Revenue Trend")
            trend_table.add_column("Month", width=10)
            trend_table.add_column("Total", justify="right", width=14)
            trend_table.add_column("Invoiced", justify="right", width=14)
            trend_table.add_column("Uninvoiced", justify="right", width=14)

            for r in revenue_trend:
                total = r.get("total", 0)
                invoiced = r.get("invoiced", 0)
                uninv = total - invoiced
                trend_table.add_row(
                    r.get("month", ""),
                    format_currency(total),
                    format_currency(invoiced),
                    f"[yellow]{format_currency(uninv)}[/yellow]" if uninv > 0 else format_currency(0),
                )
            console.print(trend_table)

        console.print()
    except APIError as e:
        if e.status_code == 403:
            format_error("Insufficient permissions. Requires manager or higher.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@app.command("profitability")
def profitability_insights(
    week: bool = typer.Option(False, "--week", "-w", help="This week."),
    last_week: bool = typer.Option(False, "--last-week", help="Last week."),
    month: bool = typer.Option(False, "--month", help="This month (default)."),
    last_month: bool = typer.Option(False, "--last-month", help="Last month."),
    quarter: bool = typer.Option(False, "--quarter", "-q", help="This quarter."),
    last_quarter: bool = typer.Option(False, "--last-quarter", help="Last quarter."),
    from_date: Optional[str] = typer.Option(None, "--from", help="Start date (YYYY-MM-DD)."),
    to_date: Optional[str] = typer.Option(None, "--to", help="End date (YYYY-MM-DD)."),
    by_client: bool = typer.Option(False, "--by-client", help="Group by client instead of project."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Profitability analysis showing revenue, cost, and margin by project or client.

    Revenue is computed from billable time entries. Cost is derived from team
    compensation configs (hourly rate or prorated salary). Margin = Revenue - Cost.
    Requires manager+ role. Cost data requires payroll compensation configs.

    Examples:
        ct insights profitability
        ct insights profitability --quarter --by-client
        ct insights profitability --last-month
        ct insights profitability --from 2026-01-01 --to 2026-03-31 --json
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    period_from, period_to = _resolve_period(
        week=week, last_week=last_week, month=month, last_month=last_month,
        quarter=quarter, last_quarter=last_quarter,
        from_date=from_date, to_date=to_date,
    )

    params: dict = {
        "date_from": period_from,
        "date_to": period_to,
        "group_by": "client" if by_client else "project",
    }

    try:
        data = client.get("/insights/profitability/", params=params)

        if output_json:
            print_json(data)
            return

        items = data.get("items", [])
        totals = data.get("totals", {})
        group_by = data.get("group_by", "project")
        has_cost = totals.get("cost") is not None

        console.print(f"\n[dim]Profitability Analysis: {period_from} to {period_to}[/dim]")

        if not items:
            console.print("[dim]No billable time entries found for this period.[/dim]\n")
            return

        # ─── Table ────────────────────────────────────
        title = "Profitability by Client" if group_by == "client" else "Profitability by Project"
        table = Table(show_header=True, header_style="bold", title=title)
        table.add_column("Name" if group_by == "client" else "Project", min_width=20)
        if group_by == "project":
            table.add_column("Client", min_width=14)
        table.add_column("Revenue", justify="right", width=12)
        table.add_column("Hours", justify="right", width=10)
        if has_cost:
            table.add_column("Cost", justify="right", width=12)
            table.add_column("Margin", justify="right", width=12)
            table.add_column("Margin %", justify="right", width=10)

        for item in items:
            revenue = item.get("revenue", 0)
            hours = item.get("billable_hours", 0)
            row = [item.get("name", "Unknown")]
            if group_by == "project":
                row.append(item.get("client_name", ""))
            row.append(format_currency(revenue))
            row.append(format_duration(Decimal(str(hours))))

            if has_cost:
                cost = item.get("cost")
                margin = item.get("margin")
                margin_pct = item.get("margin_pct")

                if cost is not None:
                    row.append(format_currency(cost))
                    margin_style = "[green]" if margin >= 0 else "[red]"
                    row.append(f"{margin_style}{format_currency(margin)}[/]")
                    pct_style = "[green]" if margin_pct >= 0 else "[red]"
                    row.append(f"{pct_style}{margin_pct:.1f}%[/]")
                else:
                    row.extend(["—", "—", "—"])

            table.add_row(*row)

        # Totals row
        table.add_section()
        total_row = ["[bold]Total[/bold]"]
        if group_by == "project":
            total_row.append("")
        total_row.append(f"[bold]{format_currency(totals.get('revenue', 0))}[/bold]")
        total_row.append(f"[bold]{format_duration(Decimal(str(totals.get('billable_hours', 0))))}[/bold]")
        if has_cost:
            total_cost = totals.get("cost", 0)
            total_margin = totals.get("margin", 0)
            total_margin_pct = totals.get("margin_pct", 0)
            total_row.append(f"[bold]{format_currency(total_cost)}[/bold]")
            margin_style = "[green]" if total_margin >= 0 else "[red]"
            total_row.append(f"[bold]{margin_style}{format_currency(total_margin)}[/][/bold]")
            pct_style = "[green]" if total_margin_pct >= 0 else "[red]"
            total_row.append(f"[bold]{pct_style}{total_margin_pct:.1f}%[/][/bold]")

        table.add_row(*total_row)
        console.print(table)

        if not has_cost:
            console.print(
                "[dim]ℹ Cost data unavailable — configure compensation in Payroll to see margins.[/dim]"
            )

        console.print()
    except APIError as e:
        if e.status_code == 403:
            format_error("Insufficient permissions. Requires manager or higher.")
        else:
            format_error(e.message)
        raise typer.Exit(1)
