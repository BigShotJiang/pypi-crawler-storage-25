"""Version command: show installed and latest CrowdTime CLI versions."""

from __future__ import annotations

import typer
from rich.console import Console

from .. import __version__
from ..formatters import print_json
from ..version_check import _parse_simple, get_latest, is_outdated

app = typer.Typer(name="version", help="Show installed and latest CLI versions.")
console = Console()


@app.callback(invoke_without_command=True)
def version(
    ctx: typer.Context,
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Show the installed CLI version and the latest published on PyPI.

    Bypasses the 12-hour cache used by the background update check —
    always fetches the latest version fresh.
    """
    if ctx.invoked_subcommand is not None:
        return

    latest = get_latest(force_refresh=True)
    outdated = is_outdated(__version__, latest)
    parseable = _parse_simple(__version__) is not None and _parse_simple(latest or "") is not None
    up_to_date = parseable and not outdated

    if output_json:
        print_json({
            "installed": __version__,
            "latest": latest,
            "up_to_date": up_to_date if parseable else None,
            "outdated": outdated,
        })
        return

    console.print(f"Installed: [bold]{__version__}[/bold]")
    if latest is None:
        console.print("Latest:    [dim](could not reach PyPI)[/dim]")
    else:
        console.print(f"Latest:    [bold]{latest}[/bold]")

    if not parseable:
        console.print("[dim]Unable to compare versions (dev or pre-release build).[/dim]")
    elif outdated:
        console.print(
            f"[yellow]\u26a0 A newer version is available. "
            f"Run [bold]pip install -U crowdtime-cli[/bold] to upgrade.[/yellow]"
        )
    else:
        console.print("[green]\u2713 You are up to date.[/green]")
