"""Task commands: list, create, presets, apply-preset."""

from __future__ import annotations

from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from ..client import APIError, CrowdTimeClient
from ..formatters import extract_results, format_error, format_success, format_warning, print_json
from ..models import Task
from ..resolvers import resolve_project

app = typer.Typer(name="tasks", help="Manage tasks.")
console = Console()


@app.command("presets")
def list_presets(
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """List available task presets for quick org setup."""
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.get("/tasks/apply-preset/")
        presets = extract_results(data)

        if output_json:
            print_json(presets)
            return

        if not presets:
            console.print("[dim]No presets available.[/dim]")
            return

        for preset in presets:
            console.print(f"\n[bold]{preset['label']}[/bold] [dim]({preset['name']})[/dim]")
            console.print(f"  {preset.get('description', '')}")
            task_names = preset.get("tasks", [])
            console.print(f"  Tasks: {', '.join(task_names)}")

        console.print()
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command("apply-preset")
def apply_preset(
    preset_name: str = typer.Argument(..., help="Preset name (e.g. software_development)."),
    project: Optional[str] = typer.Option(
        None, "--project", "-p",
        help="Also assign all preset tasks to this project.",
    ),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Apply a task preset to the organization.

    Creates tasks from a predefined set. Existing tasks with the same name
    are skipped (idempotent). Use --project to also assign all tasks to a project.

    Examples:
        ct tasks apply-preset software_development
        ct tasks apply-preset software_development --project <project-id>
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    payload: dict = {"preset_name": preset_name}
    if project:
        payload["project_id"] = project

    try:
        data = client.post("/tasks/apply-preset/", data=payload)
        tasks_list = extract_results(data)

        if output_json:
            print_json(tasks_list)
        else:
            count = len(tasks_list)
            msg = f"Applied preset '{preset_name}': {count} tasks"
            if project:
                msg += f" (also assigned to project)"
            format_success(msg)

            table = Table(show_header=True, header_style="bold")
            table.add_column("Name", width=25)
            table.add_column("Billable", justify="center", width=8)
            for t in tasks_list:
                name = t.get("name", "") if isinstance(t, dict) else t.name
                billable = t.get("is_billable", True) if isinstance(t, dict) else t.is_billable
                table.add_row(name, "[green]$[/green]" if billable else "")
            console.print(table)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command()
def edit(
    task_id: str = typer.Argument(..., help="Task ID to edit."),
    name: Optional[str] = typer.Option(None, "--name", help="New task name."),
    billable: Optional[bool] = typer.Option(None, "--billable/--no-billable", "-b/-B",
                                            help="Mark as billable/non-billable."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Edit an existing task.

    Examples:
        ct tasks edit <task-id> --name "Code Review"
        ct tasks edit <task-id> --no-billable
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    payload: dict = {}
    if name is not None:
        payload["name"] = name
    if billable is not None:
        payload["is_billable"] = billable

    if not payload:
        format_error("No changes specified. Use --name or --billable/--no-billable.")
        raise typer.Exit(1)

    try:
        data = client.patch(f"/tasks/{task_id}/", data=payload)
        task = Task(**data)

        if output_json:
            print_json(task)
        else:
            format_success(f"Task '{task.name}' updated (ID: {task.id})")
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Task '{task_id}' not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@app.command()
def archive(
    task_id: str = typer.Argument(..., help="Task ID to archive."),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation."),
) -> None:
    """Archive a task."""
    if not force:
        if not typer.confirm(f"Archive task '{task_id}'?"):
            console.print("[dim]Cancelled.[/dim]")
            return

    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        client.delete(f"/tasks/{task_id}/")
        format_success(f"Task '{task_id}' archived.")
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Task '{task_id}' not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@app.command("list")
def list_tasks(
    project: Optional[str] = typer.Option(None, "--project", "-p", help="Filter by project."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """List available tasks."""
    client = CrowdTimeClient(require_auth=True, require_org=True)

    params: dict = {}
    if project:
        try:
            params["project"] = resolve_project(client, project)
        except APIError as e:
            format_error(f"Failed to resolve project '{project}': {e.message}")
            raise typer.Exit(1)

    try:
        data = client.get("/tasks/", params=params)
        tasks_list = extract_results(data)
        tasks = [Task(**item) for item in tasks_list]

        if output_json:
            print_json(tasks)
            return

        if not tasks:
            console.print("[dim]No tasks found.[/dim]")
            console.print("Run [bold]ct tasks create <name> --project <slug>[/bold] to add a task.")
            return

        table = Table(show_header=True, header_style="bold")
        table.add_column("ID", style="dim")
        table.add_column("Name", width=25)
        table.add_column("Project", style="cyan", width=15)
        table.add_column("Billable", justify="center", width=8)

        for t in tasks:
            table.add_row(
                str(t.id),
                t.name,
                t.project_name or "",
                "[green]$[/green]" if t.is_billable else "",
            )

        console.print(table)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command()
def create(
    name: str = typer.Argument(..., help="Task name."),
    project: Optional[str] = typer.Option(None, "--project", "-p", help="Project to assign to."),
    billable: bool = typer.Option(True, "--billable/--no-billable", "-b/-B",
                                  help="Mark as billable."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Create a new task. If --project is specified, also assigns it to that project."""
    client = CrowdTimeClient(require_auth=True, require_org=True)

    payload: dict = {"name": name, "is_billable": billable}

    try:
        data = client.post("/tasks/", data=payload)
        task = Task(**data)

        # If a project is specified, assign the task to it
        if project:
            try:
                client.post(f"/projects/{project}/tasks/", data={"task": task.id})
            except APIError as e:
                # Task was created but assignment failed — warn, don't fail
                format_warning(
                    f"Task created but could not assign "
                    f"to project '{project}': {e.message}"
                )

        if output_json:
            print_json(task)
        else:
            msg = f"Task '{task.name}' created (ID: {task.id})"
            if project:
                msg += f" and assigned to project"
            format_success(msg)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)
