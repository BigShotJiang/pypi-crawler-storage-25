"""Log commands: create, edit, delete, list."""

from __future__ import annotations

from typing import Optional

import typer
from rich.console import Console

from ..client import APIError, CrowdTimeClient
from ..formatters import (
    extract_results,
    format_entries_table,
    format_entry_detail,
    format_entry_summary,
    format_error,
    format_success,
    print_json,
)
from ..models import TimeEntry
from ..resolvers import resolve_project, resolve_task
from ..utils import format_date, parse_date, parse_duration

app = typer.Typer(name="log", help="Log and manage time entries.")
console = Console()


@app.callback(invoke_without_command=True)
def log_default(
    ctx: typer.Context,
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Log and manage time entries. Run without arguments to list today's entries."""
    if ctx.invoked_subcommand is None:
        _list_entries(date_str="today", output_json=output_json)


@app.command()
def create(
    duration: str = typer.Argument(..., help="Duration (e.g. 2h, 2h30m, 2:30, 150m)."),
    description: Optional[str] = typer.Argument(None, help="What did you work on?"),
    project: Optional[str] = typer.Option(None, "--project", "-p", help="Project slug or ID."),
    task: Optional[str] = typer.Option(None, "--task", "-t", help="Task name or ID."),
    date: Optional[str] = typer.Option(None, "--date", "-d", help="Date in YYYY-MM-DD (default: today)."),
    billable: Optional[bool] = typer.Option(None, "--billable/--no-billable", "-b/-B",
                                            help="Mark as billable/non-billable."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Log a completed time entry.

    Examples:
        ct log create 2h "Code review"
        ct log create -p myproject 2h30m "Feature work"
        ct l -p myproject -d yesterday 1:30 "Standup"
    """
    try:
        hours = parse_duration(duration)
    except ValueError as e:
        format_error(str(e))
        raise typer.Exit(1)

    client = CrowdTimeClient(require_auth=True, require_org=True)

    payload: dict = {
        "hours": str(hours),
    }
    if description:
        payload["notes"] = description

    project_ref = project or client.config.default_project
    if project_ref:
        try:
            payload["project"] = resolve_project(client, project_ref)
        except APIError as e:
            format_error(f"Failed to resolve project '{project_ref}': {e.message}")
            raise typer.Exit(1)
    if task:
        try:
            payload["task"] = resolve_task(client, task, project_id=payload.get("project"))
        except APIError as e:
            format_error(f"Failed to resolve task '{task}': {e.message}")
            raise typer.Exit(1)
    if date:
        try:
            parsed = parse_date(date)
            payload["date"] = format_date(parsed)
        except ValueError as e:
            format_error(str(e))
            raise typer.Exit(1)
    if billable is not None:
        payload["is_billable"] = billable

    try:
        data = client.post("/time/", data=payload)
        entry = TimeEntry(**data)

        if output_json:
            print_json(entry)
        else:
            format_success("Time entry logged")
            format_entry_summary(entry)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command()
def show(
    entry_id: str = typer.Argument(..., help="Time entry ID to view."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Show details of a single time entry."""
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.get(f"/time/{entry_id}/")
        entry = TimeEntry(**data)

        if output_json:
            print_json(entry)
        else:
            format_entry_detail(entry)
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Entry {entry_id} not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@app.command()
def edit(
    entry_id: str = typer.Argument(..., help="Time entry ID to edit."),
    duration: Optional[str] = typer.Option(None, "--duration", help="New duration."),
    description: Optional[str] = typer.Option(None, "--description", help="New description."),
    project: Optional[str] = typer.Option(None, "--project", "-p", help="New project."),
    task: Optional[str] = typer.Option(None, "--task", "-t", help="New task."),
    date: Optional[str] = typer.Option(None, "--date", "-d", help="New date (YYYY-MM-DD)."),
    billable: Optional[bool] = typer.Option(None, "--billable/--no-billable", "-b/-B",
                                            help="Mark as billable/non-billable."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Edit an existing time entry."""
    client = CrowdTimeClient(require_auth=True, require_org=True)

    payload: dict = {}
    if duration:
        try:
            payload["hours"] = str(parse_duration(duration))
        except ValueError as e:
            format_error(str(e))
            raise typer.Exit(1)
    if description is not None:
        payload["notes"] = description
    resolved_project_id = None
    if project:
        try:
            resolved_project_id = resolve_project(client, project)
            payload["project"] = resolved_project_id
        except APIError as e:
            format_error(f"Failed to resolve project '{project}': {e.message}")
            raise typer.Exit(1)
    if task:
        task_project_id = resolved_project_id
        if not task_project_id:
            try:
                entry_data = client.get(f"/time/{entry_id}/")
                task_project_id = entry_data.get("project")
            except APIError:
                pass  # Let resolve_task try without project context
        try:
            payload["task"] = resolve_task(client, task, project_id=task_project_id)
        except APIError as e:
            format_error(f"Failed to resolve task '{task}': {e.message}")
            raise typer.Exit(1)
    if date:
        try:
            payload["date"] = format_date(parse_date(date))
        except ValueError as e:
            format_error(str(e))
            raise typer.Exit(1)
    if billable is not None:
        payload["is_billable"] = billable

    if not payload:
        format_error("No changes specified. Use --duration, --description, --project, etc.")
        raise typer.Exit(1)

    try:
        data = client.patch(f"/time/{entry_id}/", data=payload)
        entry = TimeEntry(**data)

        if output_json:
            print_json(entry)
        else:
            format_success(f"Entry updated (ID: {entry_id})")
            format_entry_summary(entry)
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Entry {entry_id} not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@app.command()
def delete(
    entry_id: str = typer.Argument(..., help="Time entry ID to delete."),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation."),
) -> None:
    """Delete a time entry."""
    client = CrowdTimeClient(require_auth=True, require_org=True)

    if not force:
        # Fetch entry details for confirmation
        try:
            data = client.get(f"/time/{entry_id}/")
            entry = TimeEntry(**data)
            desc = entry.description or "(no description)"
            if not typer.confirm(f"Delete entry '{desc}'?"):
                console.print("[dim]Cancelled.[/dim]")
                return
        except APIError as e:
            if e.status_code == 404:
                format_error(f"Entry {entry_id} not found.")
            else:
                format_error(e.message)
            raise typer.Exit(1)

    try:
        client.delete(f"/time/{entry_id}/")
        format_success(f"Entry deleted (ID: {entry_id}).")
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Entry {entry_id} not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@app.command("bulk-delete")
def bulk_delete(
    ids: list[str] = typer.Argument(..., help="Time entry IDs to delete."),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Delete multiple time entries at once.

    Pass one or more entry IDs. Locked entries and entries on submitted
    timesheets are skipped automatically.

    Examples:
        ct log bulk-delete id1 id2 id3
        ct log bulk-delete id1 id2 --force
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    if not force:
        if not typer.confirm(f"Delete {len(ids)} time entries?"):
            console.print("[dim]Cancelled.[/dim]")
            return

    try:
        data = client.post("/time/bulk-delete/", data={"ids": ids})

        if output_json:
            print_json(data)
            return

        deleted_count = data.get("deleted_count", 0)
        skipped = data.get("skipped", [])

        if deleted_count:
            format_success(f"Deleted {deleted_count} entries.")
        if skipped:
            for s in skipped:
                console.print(f"  [yellow]Skipped[/yellow] {s['id']}: {s['reason']}")
        if not deleted_count and not skipped:
            console.print("[dim]No matching entries found.[/dim]")
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command()
def duplicate(
    entry_id: str = typer.Argument(..., help="Time entry ID to duplicate."),
    date: Optional[str] = typer.Option(None, "--date", "-d", help="Date for the new entry (YYYY-MM-DD, default: today)."),
    duration: Optional[str] = typer.Option(None, "--duration", help="Override duration."),
    description: Optional[str] = typer.Option(None, "--description", help="Override description."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Duplicate an existing time entry.

    Copies project, task, description, duration, and billable status.
    The new entry defaults to today's date unless --date is specified.

    Examples:
        ct log duplicate abc123-...
        ct log duplicate abc123-... --date yesterday
        ct log duplicate abc123-... --duration 3h --description "Continued work"
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    # Fetch the source entry
    try:
        data = client.get(f"/time/{entry_id}/")
        source = TimeEntry(**data)
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Entry {entry_id} not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)

    # Build payload from source, applying overrides
    payload: dict = {}

    if duration:
        try:
            payload["hours"] = str(parse_duration(duration))
        except ValueError as e:
            format_error(str(e))
            raise typer.Exit(1)
    elif source.duration is not None:
        payload["hours"] = str(source.duration)

    payload["notes"] = description if description is not None else (source.description or "")

    if source.project:
        payload["project"] = source.project
    if source.task:
        payload["task"] = source.task
    if source.is_billable is not None:
        payload["is_billable"] = source.is_billable

    # Date: override or today
    if date:
        try:
            parsed = parse_date(date)
            payload["date"] = format_date(parsed)
        except ValueError as e:
            format_error(str(e))
            raise typer.Exit(1)
    else:
        payload["date"] = format_date(parse_date("today"))

    try:
        new_data = client.post("/time/", data=payload)
        entry = TimeEntry(**new_data)

        if output_json:
            print_json(entry)
        else:
            format_success("Entry duplicated")
            format_entry_summary(entry)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command("list")
def list_entries(
    today_flag: bool = typer.Option(False, "--today", help="Show today's entries."),
    yesterday_flag: bool = typer.Option(False, "--yesterday", help="Show yesterday's entries."),
    date: Optional[str] = typer.Option(None, "--date", "-d", help="Filter by date (YYYY-MM-DD)."),
    week: bool = typer.Option(False, "--week", "-w", help="Show this week's entries."),
    month: bool = typer.Option(False, "--month", "-m", help="Show this month's entries."),
    from_date: Optional[str] = typer.Option(None, "--from", help="Start date for range filter (YYYY-MM-DD)."),
    to_date: Optional[str] = typer.Option(None, "--to", help="End date for range filter (YYYY-MM-DD)."),
    project: Optional[str] = typer.Option(None, "--project", "-p", help="Filter by project."),
    task: Optional[str] = typer.Option(None, "--task", "-t", help="Filter by task name or ID."),
    billable: Optional[bool] = typer.Option(None, "--billable/--no-billable", "-b/-B",
                                            help="Filter by billable status."),
    user: Optional[str] = typer.Option(None, "--user", "-u", help="Filter by user ID (manager+ only)."),
    format_output: str = typer.Option("table", "--format", help="Output format: table, json, csv."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """List time entries with optional filters."""
    effective_date = date
    if today_flag:
        effective_date = "today"
    elif yesterday_flag:
        effective_date = "yesterday"

    _list_entries(
        date_str=effective_date,
        week=week,
        month=month,
        from_date=from_date,
        to_date=to_date,
        project=project,
        task=task,
        billable=billable,
        user=user,
        format_output=format_output,
        output_json=output_json,
    )


def _list_entries(
    date_str: str | None = None,
    week: bool = False,
    month: bool = False,
    from_date: str | None = None,
    to_date: str | None = None,
    project: str | None = None,
    task: str | None = None,
    billable: bool | None = None,
    user: str | None = None,
    format_output: str = "table",
    output_json: bool = False,
) -> None:
    """Internal function to list entries."""
    from datetime import date as date_type, timedelta

    client = CrowdTimeClient(require_auth=True, require_org=True)

    params: dict = {}

    if date_str:
        try:
            parsed = parse_date(date_str)
            params["date"] = format_date(parsed)
        except ValueError as e:
            format_error(str(e))
            raise typer.Exit(1)
    elif week:
        today = date_type.today()
        start = today - timedelta(days=today.weekday())
        params["date_from"] = format_date(start)
        params["date_to"] = format_date(today)
    elif month:
        today = date_type.today()
        start = today.replace(day=1)
        params["date_from"] = format_date(start)
        params["date_to"] = format_date(today)

    if from_date:
        try:
            params["date_from"] = format_date(parse_date(from_date))
        except ValueError as e:
            format_error(str(e))
            raise typer.Exit(1)
    if to_date:
        try:
            params["date_to"] = format_date(parse_date(to_date))
        except ValueError as e:
            format_error(str(e))
            raise typer.Exit(1)

    if project:
        try:
            params["project"] = resolve_project(client, project)
        except APIError as e:
            format_error(f"Failed to resolve project '{project}': {e.message}")
            raise typer.Exit(1)
    if task:
        try:
            params["task"] = resolve_task(client, task, project_id=params.get("project"))
        except APIError as e:
            format_error(f"Failed to resolve task '{task}': {e.message}")
            raise typer.Exit(1)
    if billable is not None:
        params["is_billable"] = str(billable).lower()
    if user:
        params["user"] = user

    try:
        data = client.get("/time/", params=params)
        entries = [TimeEntry(**item) for item in extract_results(data)]

        if format_output == "json" or output_json:
            print_json(entries)
        elif format_output == "csv":
            _print_csv(entries)
        else:
            format_entries_table(entries, show_date=True)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


def _print_csv(entries: list[TimeEntry]) -> None:
    """Print entries as CSV (plain output, safe for piping)."""
    print("id,date,project,task,description,duration,billable,hourly_rate,billable_amount")
    for e in entries:
        desc = (e.description or "").replace('"', '""')
        rate = getattr(e, "hourly_rate", None) or ""
        amount = getattr(e, "billable_amount", None) or ""
        print(
            f'{e.id},{e.date or ""},'
            f'{e.project_name or ""},{e.task_name or ""},'
            f'"{desc}",{e.duration or 0},'
            f'{"yes" if e.is_billable else "no"},'
            f'{rate},{amount}'
        )


@app.command("save")
def save_as_favorite(
    entry_id: str = typer.Argument(..., help="Time entry ID to save as a favorite."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Save an existing time entry as a favorite template.

    Copies the entry's project, task, description, and billable status
    into a new favorite for quick reuse.

    Examples:
        ct log save abc123-...
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    # Fetch the source entry
    try:
        data = client.get(f"/time/{entry_id}/")
        source = TimeEntry(**data)
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Entry {entry_id} not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)

    if not source.project:
        format_error("Entry has no project — cannot save as favorite.")
        raise typer.Exit(1)

    payload: dict = {
        "project": source.project,
        "is_billable": source.is_billable if source.is_billable is not None else True,
    }
    if source.description:
        payload["notes"] = source.description
    if source.task:
        payload["task"] = source.task

    try:
        fav_data = client.post("/favorites/", data=payload)

        if output_json:
            print_json(fav_data)
        else:
            desc = source.description or "(no description)"
            fav_id = fav_data.get("id", "")
            format_success(f"Saved '{desc}' as favorite (ID: {fav_id})")
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)
