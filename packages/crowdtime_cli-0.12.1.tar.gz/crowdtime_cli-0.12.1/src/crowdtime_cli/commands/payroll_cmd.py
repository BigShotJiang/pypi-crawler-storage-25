"""Payroll commands: compensation, periods, liquidation, payments."""

from __future__ import annotations

from decimal import Decimal
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from ..client import APIError, CrowdTimeClient
from ..formatters import extract_results, format_currency, format_error, format_success, format_warning, print_json
from ..utils import format_duration, format_iso_date

app = typer.Typer(name="payroll", help="Manage payroll and compensation.")
console = Console()


# ─── Helpers ──────────────────────────────────────────────────────


STATUS_COLORS = {
    "draft": "yellow",
    "calculated": "blue",
    "approved": "green",
    "paid": "green",
    "pending": "yellow",
    "failed": "red",
    "unpaid": "dim",
}






def _format_rate(entry: dict) -> str:
    """Format rate display based on compensation type."""
    comp_type = entry.get("compensation_type", "")
    if comp_type == "hourly":
        rate = entry.get("hourly_rate")
        return f"{format_currency(rate)}/hr" if rate is not None else "—"
    elif comp_type == "salary":
        salary = entry.get("monthly_salary")
        return f"{format_currency(salary)}/mo" if salary is not None else "—"
    return "—"




def _resolve_period(client: CrowdTimeClient, period_str: str | None) -> str | None:
    """Resolve a YYYY-MM period string to a period ID."""
    if not period_str:
        return None
    try:
        data = client.get("/payroll/periods/")
        periods = extract_results(data)
        for p in periods:
            if p.get("period_start", "").startswith(period_str):
                return p["id"]
    except APIError as e:
        format_warning(f"Could not resolve payroll period: {e.message}")
    return None


def _validate_effective_date(effective: str | None) -> str:
    """Validate and return an effective date string (must be 1st of month).

    If *effective* is ``None``, defaults to the 1st of the current month.
    """
    from datetime import date as date_type

    if effective:
        try:
            parsed = date_type.fromisoformat(effective)
        except ValueError:
            format_error(f"Invalid date format '{effective}'. Use YYYY-MM-DD.")
            raise typer.Exit(1)
        if parsed.day != 1:
            format_error(f"Effective date must be the 1st of a month (got {effective}).")
            raise typer.Exit(1)
        return effective
    else:
        today = date_type.today()
        return f"{today.year}-{today.month:02d}-01"


def _resolve_member(client: CrowdTimeClient, member: str) -> dict | None:
    """Resolve a member identifier (email or name) to a membership dict."""
    try:
        data = client.get("/members/")
        members = extract_results(data)
        member_lower = member.lower()
        for m in members:
            user = m.get("user", {})
            email = user.get("email", "").lower()
            name = f"{user.get('first_name', '')} {user.get('last_name', '')}".strip().lower()
            if email == member_lower or name == member_lower:
                return m
    except APIError as e:
        format_warning(f"Could not resolve member: {e.message}")
    return None


# ─── Commands ─────────────────────────────────────────────────────


@app.callback(invoke_without_command=True)
def payroll_default(
    ctx: typer.Context,
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Show payroll summary or manage payroll."""
    if ctx.invoked_subcommand is None:
        summary(output_json=output_json)


@app.command("summary")
def summary(
    period: Optional[str] = typer.Option(None, "--period", help="Period as YYYY-MM."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Show payroll summary for a month.

    Defaults to the current month if no period is specified.

    Examples:
        ct payroll
        ct payroll summary
        ct payroll summary --period 2026-03
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        params = {}
        if period:
            params["search"] = period
        data = client.get("/payroll/periods/", params=params)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)

    periods = extract_results(data)

    if output_json:
        print_json(periods)
        return

    if not periods:
        console.print("[dim]No payroll periods found.[/dim]")
        console.print("Run [bold]ct payroll run[/bold] to create and calculate a payroll period.")
        return

    table = Table(title="Payroll Periods", show_lines=False)
    table.add_column("Period", width=12)
    table.add_column("Status", width=12)
    table.add_column("Members", justify="right", width=8)
    table.add_column("Total", justify="right", width=14)
    table.add_column("Paid", justify="right", width=14)

    for p in periods:
        start = format_iso_date(p.get("period_start"))
        st = p.get("status", "")
        color = STATUS_COLORS.get(st, "white")
        table.add_row(
            start[:7],
            f"[{color}]{st.upper()}[/{color}]",
            str(p.get("member_count", 0)),
            format_currency(p.get("total_amount"), none_display="—"),
            format_currency(p.get("total_paid"), none_display="—"),
        )

    console.print(table)


@app.command("members")
def members(
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """List members with their compensation configuration.

    Examples:
        ct payroll members
        ct payroll members --json
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        comp_data = client.get("/payroll/compensation/")
        member_data = client.get("/members/")
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)

    configs = comp_data if isinstance(comp_data, list) else comp_data.get("results", [])
    all_members = member_data if isinstance(member_data, list) else member_data.get("results", [])

    # Build a map of membership_id -> latest config
    config_map = {}
    for c in configs:
        mid = c.get("membership")
        if mid not in config_map:
            config_map[mid] = c

    if output_json:
        print_json({"members": all_members, "compensation_configs": configs})
        return

    table = Table(title="Payroll Members", show_lines=False)
    table.add_column("Name", width=20)
    table.add_column("Email", width=24)
    table.add_column("Type", width=10)
    table.add_column("Rate", justify="right", width=14)
    table.add_column("Since", width=12)

    hourly_count = 0
    salary_count = 0
    unconfigured_count = 0

    for m in all_members:
        if not m.get("is_active", True):
            continue
        user = m.get("user", {})
        name = f"{user.get('first_name', '')} {user.get('last_name', '')}".strip() or user.get("email", "")
        email = user.get("email", "")
        mid = m.get("id")
        config = config_map.get(mid)

        if config:
            comp_type = config.get("compensation_type", "")
            rate = _format_rate(config)
            since = format_iso_date(config.get("effective_from"))
            type_label = comp_type.capitalize()
            if comp_type == "hourly":
                hourly_count += 1
            else:
                salary_count += 1
        else:
            type_label = "—"
            rate = "Not set"
            since = "—"
            unconfigured_count += 1

        table.add_row(name, email, type_label, rate, since)

    console.print(table)
    active_count = hourly_count + salary_count + unconfigured_count
    parts = []
    if hourly_count:
        parts.append(f"{hourly_count} hourly")
    if salary_count:
        parts.append(f"{salary_count} salary")
    if unconfigured_count:
        parts.append(f"{unconfigured_count} unconfigured")
    console.print(f"{active_count} members ({', '.join(parts)})")


@app.command("show")
def show(
    member: str = typer.Argument(..., help="Member email or name."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Show a member's compensation details.

    Examples:
        ct payroll show alice@company.com
        ct payroll show alice@company.com --json
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    resolved = _resolve_member(client, member)
    if not resolved:
        format_error(f"Member '{member}' not found.")
        raise typer.Exit(1)

    membership_id = resolved["id"]
    user = resolved.get("user", {})

    try:
        data = client.get("/payroll/compensation/", params={"membership": membership_id})
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)

    configs = extract_results(data)

    if output_json:
        print_json({"member": resolved, "compensation_configs": configs})
        return

    name = f"{user.get('first_name', '')} {user.get('last_name', '')}".strip() or user.get("email", "")
    console.print(f"\n[bold]{name}[/bold] ({user.get('email', '')})")

    if not configs:
        console.print("[dim]  No compensation configured.[/dim]")
        return

    table = Table(show_header=True, show_lines=False)
    table.add_column("Effective From", width=14)
    table.add_column("Type", width=10)
    table.add_column("Rate", justify="right", width=14)
    table.add_column("Currency", width=10)

    for c in configs:
        table.add_row(
            format_iso_date(c.get("effective_from")),
            c.get("compensation_type", "").capitalize(),
            _format_rate(c),
            c.get("currency", "USD"),
        )

    console.print(table)


@app.command("set-rate")
def set_rate(
    member: str = typer.Argument(..., help="Member email or name."),
    rate: str = typer.Argument(..., help="Hourly rate (e.g. 75.00)."),
    effective: Optional[str] = typer.Option(None, "--effective", "-e", help="Effective from (YYYY-MM-DD, must be 1st of month). Default: 1st of current month."),
    currency: Optional[str] = typer.Option(None, "--currency", "-c", help="Currency code (e.g. USD, EUR). Default: org currency."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Set hourly rate for a member.

    Examples:
        ct payroll set-rate alice@company.com 75.00
        ct payroll set-rate alice@company.com 90.00 --effective 2026-04-01
        ct payroll set-rate alice@company.com 50.00 --currency EUR
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    resolved = _resolve_member(client, member)
    if not resolved:
        format_error(f"Member '{member}' not found.")
        raise typer.Exit(1)

    effective_date = _validate_effective_date(effective)

    payload: dict = {
        "membership": resolved["id"],
        "compensation_type": "hourly",
        "hourly_rate": rate,
        "effective_from": effective_date,
    }
    if currency:
        payload["currency"] = currency.upper()

    try:
        data = client.post("/payroll/compensation/", data=payload)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)

    if output_json:
        print_json(data)
        return

    user = resolved.get("user", {})
    name = f"{user.get('first_name', '')} {user.get('last_name', '')}".strip() or user.get("email", "")
    cur = data.get("currency", currency or "USD")
    format_success(f"Set hourly rate for {name}.")
    console.print(f"  [dim]Rate:[/dim] {format_currency(rate, cur)}/hr  [dim]Currency:[/dim] {cur}  [dim]Effective:[/dim] {effective_date}")


@app.command("set-salary")
def set_salary(
    member: str = typer.Argument(..., help="Member email or name."),
    amount: str = typer.Argument(..., help="Monthly salary (e.g. 5000.00)."),
    effective: Optional[str] = typer.Option(None, "--effective", "-e", help="Effective from (YYYY-MM-DD, must be 1st of month). Default: 1st of current month."),
    currency: Optional[str] = typer.Option(None, "--currency", "-c", help="Currency code (e.g. USD, EUR). Default: org currency."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Set monthly salary for a member.

    Examples:
        ct payroll set-salary bob@company.com 5000
        ct payroll set-salary bob@company.com 6000 --effective 2026-04-01
        ct payroll set-salary bob@company.com 3000 --currency EUR
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    resolved = _resolve_member(client, member)
    if not resolved:
        format_error(f"Member '{member}' not found.")
        raise typer.Exit(1)

    effective_date = _validate_effective_date(effective)

    payload: dict = {
        "membership": resolved["id"],
        "compensation_type": "salary",
        "monthly_salary": amount,
        "effective_from": effective_date,
    }
    if currency:
        payload["currency"] = currency.upper()

    try:
        data = client.post("/payroll/compensation/", data=payload)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)

    if output_json:
        print_json(data)
        return

    user = resolved.get("user", {})
    name = f"{user.get('first_name', '')} {user.get('last_name', '')}".strip() or user.get("email", "")
    cur = data.get("currency", currency or "USD")
    format_success(f"Set monthly salary for {name}.")
    console.print(f"  [dim]Salary:[/dim] {format_currency(amount, cur)}/mo  [dim]Currency:[/dim] {cur}  [dim]Effective:[/dim] {effective_date}")


@app.command("run")
def run(
    period: Optional[str] = typer.Option(None, "--period", help="Period as YYYY-MM. Default: current month."),
    dry_run: bool = typer.Option(False, "--dry-run", help="Preview without creating."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Run payroll liquidation for a month.

    Creates a payroll period (if needed) and calculates gross pay
    for all members with compensation configs.

    Examples:
        ct payroll run
        ct payroll run --dry-run
        ct payroll run --period 2026-02
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    from datetime import date as date_type
    if period:
        parts = period.split("-")
        period_start = f"{parts[0]}-{parts[1]}-01"
    else:
        today = date_type.today()
        period_start = f"{today.year}-{today.month:02d}-01"

    # Find or create the period
    period_id = None
    try:
        data = client.get("/payroll/periods/")
        periods = extract_results(data)
        for p in periods:
            if p.get("period_start") == period_start:
                period_id = p["id"]
                break
    except APIError as e:
        format_warning(f"Could not fetch payroll periods: {e.message}")

    if not period_id:
        try:
            new_period = client.post("/payroll/periods/", data={"period_start": period_start})
            period_id = new_period["id"]
        except APIError as e:
            format_error(e.message)
            raise typer.Exit(1)

    # Calculate
    try:
        url = f"/payroll/periods/{period_id}/calculate/"
        if dry_run:
            url = f"{url}?dry_run=true"
        data = client.post(url, data={})
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)

    if output_json:
        print_json(data)
        return

    # Display results
    if dry_run:
        entries = data.get("entries", [])
        title = f"Payroll Liquidation — {period_start[:7]} (dry run)"
    else:
        entries = data.get("entries", [])
        title = f"Payroll Liquidation — {period_start[:7]}"

    if not entries:
        console.print("[dim]No members with compensation configs found.[/dim]")
        return

    # Check if we have mixed currencies
    currencies = set(e.get("currency", "USD") for e in entries)
    show_currency = len(currencies) > 1

    table = Table(title=title, show_lines=False)
    table.add_column("Member", width=20)
    table.add_column("Type", width=10)
    table.add_column("Hours", justify="right", width=12)
    table.add_column("Rate", justify="right", width=14)
    table.add_column("Amount", justify="right", width=14)
    if show_currency:
        table.add_column("Currency", width=8)

    total_hours = Decimal("0")
    total_amount = Decimal("0")

    for e in entries:
        hours = Decimal(str(e.get("total_hours", "0")))
        amount = Decimal(str(e.get("gross_amount", "0")))
        cur = e.get("currency", "USD")
        total_hours += hours
        total_amount += amount

        row = [
            e.get("member_name", ""),
            e.get("compensation_type", "").capitalize(),
            format_duration(e.get("total_hours")),
            _format_rate(e),
            format_currency(e.get("gross_amount"), cur),
        ]
        if show_currency:
            row.append(cur)
        table.add_row(*row)

    # Total row
    table.add_section()
    if show_currency:
        table.add_row("[bold]Total[/bold]", "", f"[bold]{format_duration(total_hours)}[/bold]", "", "", "")
    else:
        cur = next(iter(currencies)) if currencies else "USD"
        table.add_row(
            "[bold]Total[/bold]", "",
            f"[bold]{format_duration(total_hours)}[/bold]", "",
            f"[bold]{format_currency(total_amount, cur)}[/bold]",
        )

    console.print(table)

    # Show per-currency breakdown when mixed
    breakdown = data.get("currency_breakdown", {})
    if show_currency and breakdown:
        console.print("\n[bold]Currency Breakdown:[/bold]")
        for cur, info in sorted(breakdown.items()):
            console.print(f"  {cur}: {format_currency(info.get('total', '0'), cur)} ({info.get('count', 0)} members)")

    if dry_run:
        console.print("\n[yellow]This is a dry run. No payroll period was created.[/yellow]")
    else:
        st = data.get("status", "calculated")
        color = STATUS_COLORS.get(st, "white")
        console.print(f"\n  Status: [{color}]{st.upper()}[/{color}]")


@app.command("periods")
def periods(
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """List all payroll periods.

    Examples:
        ct payroll periods
        ct payroll periods --json
    """
    # Delegate to summary
    summary(output_json=output_json)


@app.command("period")
def period_detail(
    period_id: str = typer.Argument(..., help="Payroll period ID."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Show payroll period detail with member breakdown.

    Examples:
        ct payroll period <period-id>
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.get(f"/payroll/periods/{period_id}/")
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)

    if output_json:
        print_json(data)
        return

    start = format_iso_date(data.get("period_start"))
    st = data.get("status", "")
    color = STATUS_COLORS.get(st, "white")

    # Header info
    info = Table(show_header=False, box=None, padding=(0, 2))
    info.add_column("Key", style="dim", width=12)
    info.add_column("Value")
    info.add_row("Period", start[:7])
    info.add_row("Status", f"[{color}]{st.upper()}[/{color}]")
    info.add_row("Members", str(data.get("member_count", 0)))
    info.add_row("Total", format_currency(data.get("total_amount"), none_display="—"))
    info.add_row("Paid", format_currency(data.get("total_paid"), none_display="—"))

    panel = Panel(info, title="[bold]Payroll Period[/bold]", border_style=color, padding=(1, 1))
    console.print(panel)

    # Entries table
    entries = data.get("entries", [])
    if entries:
        table = Table(title="Entries", show_lines=False)
        table.add_column("Member", width=20)
        table.add_column("Type", width=10)
        table.add_column("Hours", justify="right", width=12)
        table.add_column("Rate", justify="right", width=14)
        table.add_column("Amount", justify="right", width=14)
        table.add_column("Payment", width=10)

        for e in entries:
            ps = e.get("payment_status", "unpaid")
            ps_color = STATUS_COLORS.get(ps, "dim")
            table.add_row(
                e.get("member_name", ""),
                e.get("compensation_type", "").capitalize(),
                format_duration(e.get("total_hours")),
                _format_rate(e),
                format_currency(e.get("gross_amount"), none_display="—"),
                f"[{ps_color}]{ps.upper()}[/{ps_color}]",
            )

        console.print(table)


@app.command("approve")
def approve(
    period_id: str = typer.Argument(..., help="Payroll period ID."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Approve a calculated payroll period.

    Examples:
        ct payroll approve <period-id>
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.post(f"/payroll/periods/{period_id}/approve/", data={})
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)

    if output_json:
        print_json(data)
        return

    format_success(f"Payroll period {format_iso_date(data.get('period_start'))[:7]} approved.")
    console.print(f"  [dim]Total:[/dim] {format_currency(data.get('total_amount'), none_display='—')}  [dim]Members:[/dim] {data.get('member_count', 0)}")


@app.command("mark-paid")
def mark_paid(
    period_id: str = typer.Argument(..., help="Payroll period ID."),
    member: Optional[str] = typer.Argument(None, help="Member email (omit for --all)."),
    all_members: bool = typer.Option(False, "--all", help="Mark all entries as paid."),
    method: str = typer.Option("bank_transfer", "--method", "-m", help="Payment method."),
    reference: str = typer.Option("", "--reference", "--ref", "-r", help="Payment reference."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Mark a payroll entry as paid.

    Examples:
        ct payroll mark-paid <period-id> alice@company.com --method bank_transfer --ref TXN-123
        ct payroll mark-paid <period-id> --all --method bank_transfer --ref BATCH-456
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    if all_members:
        # Bulk mark all paid
        try:
            data = client.post(f"/payroll/periods/{period_id}/mark-all-paid/", data={
                "payment_method": method,
                "reference": reference,
            })
        except APIError as e:
            format_error(e.message)
            raise typer.Exit(1)

        if output_json:
            print_json(data)
            return

        format_success(f"All entries marked as paid for period {format_iso_date(data.get('period_start'))[:7]}.")
        console.print(f"  [dim]Total paid:[/dim] {format_currency(data.get('total_paid'), none_display='—')}")
        return

    if not member:
        format_error("Specify a member email or use --all to mark all entries as paid.")
        raise typer.Exit(1)

    # Find the specific entry for this member
    try:
        period_data = client.get(f"/payroll/periods/{period_id}/")
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)

    entries = period_data.get("entries", [])
    target_entry = None
    member_lower = member.lower()
    for e in entries:
        if e.get("member_email", "").lower() == member_lower:
            target_entry = e
            break

    if not target_entry:
        format_error(f"No entry found for '{member}' in this period.")
        raise typer.Exit(1)

    entry_id = target_entry["id"]

    # Create payment if needed, then mark paid
    try:
        # Try creating a payment first
        payment_data = client.post("/payroll/payments/", data={
            "payroll_entry": entry_id,
            "payment_method": method,
            "reference": reference,
        })
        payment_id = payment_data["id"]
    except APIError:
        # Payment may already exist — find it
        try:
            payments = client.get("/payroll/payments/", params={"payroll_period": period_id})
            payment_list = payments if isinstance(payments, list) else payments.get("results", [])
            payment_id = None
            for p in payment_list:
                if p.get("payroll_entry") == entry_id:
                    payment_id = p["id"]
                    break
            if not payment_id:
                format_error("Could not create or find payment for this entry.")
                raise typer.Exit(1)
        except APIError as e:
            format_error(e.message)
            raise typer.Exit(1)

    # Mark as paid
    try:
        data = client.post(f"/payroll/payments/{payment_id}/mark-paid/", data={})
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)

    if output_json:
        print_json(data)
        return

    format_success(f"Marked {target_entry.get('member_name', member)} as paid for {format_iso_date(period_data.get('period_start'))[:7]}.")
    console.print(f"  Amount: {format_currency(target_entry.get('gross_amount'), none_display='—')} | Method: {method} | Ref: {reference or '—'}")


@app.command("payments")
def payments(
    period: Optional[str] = typer.Option(None, "--period", help="Period as YYYY-MM."),
    member: Optional[str] = typer.Option(None, "--member", help="Filter by member email."),
    status_filter: Optional[str] = typer.Option(None, "--status", help="Filter: pending, paid, failed."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """List payroll payments.

    Examples:
        ct payroll payments
        ct payroll payments --period 2026-03
        ct payroll payments --status paid
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    params = {}
    if period:
        period_id = _resolve_period(client, period)
        if period_id:
            params["payroll_period"] = period_id
    if status_filter:
        params["status"] = status_filter
    if member:
        resolved = _resolve_member(client, member)
        if resolved:
            params["membership"] = resolved["id"]

    try:
        data = client.get("/payroll/payments/", params=params)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)

    payment_list = extract_results(data)

    if output_json:
        print_json(payment_list)
        return

    if not payment_list:
        console.print("[dim]No payments found.[/dim]")
        return

    table = Table(title="Payroll Payments", show_lines=False)
    table.add_column("Member", width=20)
    table.add_column("Amount", justify="right", width=14)
    table.add_column("Status", width=10)
    table.add_column("Method", width=16)
    table.add_column("Paid At", width=12)
    table.add_column("Reference", width=16)

    for p in payment_list:
        st = p.get("status", "")
        color = STATUS_COLORS.get(st, "white")
        table.add_row(
            p.get("member_name", ""),
            format_currency(p.get("amount"), none_display="—"),
            f"[{color}]{st.upper()}[/{color}]",
            p.get("payment_method", "").replace("_", " ").title(),
            format_iso_date(p.get("paid_at")),
            p.get("reference", "") or "—",
        )

    console.print(table)
