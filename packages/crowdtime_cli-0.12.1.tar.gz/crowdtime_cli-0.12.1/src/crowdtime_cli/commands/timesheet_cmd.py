"""Timesheet commands: list, submit, approve, reject, team overview."""

from __future__ import annotations

from datetime import date as date_type, timedelta
from decimal import Decimal
from typing import Optional

import typer
from rich.console import Console

from ..client import APIError, CrowdTimeClient
from ..formatters import (
    extract_results,
    format_error,
    format_success,
    print_json,
    status_label as _status_label,
    status_style as _raw_status_style,
)
from ..utils import format_date, format_duration, format_iso_date, format_iso_datetime, parse_date

app = typer.Typer(name="timesheet", help="Manage timesheets and approvals.")
console = Console()


# ─── Helpers ──────────────────────────────────────────────────────


def _status_style(status: str | None) -> str:
    return _raw_status_style(status, context="timesheet")


def _print_timesheets_table(timesheets: list[dict], show_user: bool = False) -> None:
    """Print timesheets in a Rich table."""
    from rich.table import Table

    if not timesheets:
        console.print("[dim]No timesheets found.[/dim]")
        console.print("Run [bold]ct timesheet submit[/bold] to submit your current timesheet.")
        return

    table = Table(show_header=True, header_style="bold")
    table.add_column("ID", style="dim")
    if show_user:
        table.add_column("User", width=20)
    table.add_column("Period", width=25)
    table.add_column("Total", justify="right", width=8)
    table.add_column("Billable", justify="right", width=8)
    table.add_column("Status", width=14)
    table.add_column("Progress", width=10)
    table.add_column("Reviewer", width=15)

    for ts in timesheets:
        status = ts.get("status", "draft")
        style = _status_style(status)
        raw_progress = ts.get("approval_progress") or ""
        if raw_progress and "/" in raw_progress:
            parts = raw_progress.split("/")
            approved, total = parts[0], parts[1]
            if approved == total:
                progress = f"[green]{raw_progress} projects[/green]"
            elif approved == "0":
                progress = f"[dim]{raw_progress} projects[/dim]"
            else:
                progress = f"[yellow]{raw_progress} projects[/yellow]"
        else:
            progress = "—"

        row = [str(ts.get("id", ""))]
        if show_user:
            row.append(ts.get("user_name", ts.get("user_email", "")))
        row.extend([
            f"{ts.get('period_start', '')} → {ts.get('period_end', '')}",
            format_duration(Decimal(str(ts.get("total_hours", 0)))),
            format_duration(Decimal(str(ts.get("billable_hours", 0)))),
            f"[{style}]{_status_label(status)}[/{style}]",
            progress,
            ts.get("reviewer_name") or "—",
        ])
        table.add_row(*row)

    console.print(table)


def _print_team_overview(data: dict) -> None:
    """Print team overview in a Rich table."""
    from rich.table import Table

    members = data.get("members", [])
    period_start = data.get("period_start", "")
    period_end = data.get("period_end", "")

    console.print(f"\n[dim]Period: {period_start} to {period_end}[/dim]")

    if not members:
        console.print("[dim]No team members found.[/dim]")
        return

    table = Table(show_header=True, header_style="bold", title="Team Timesheet Overview")
    table.add_column("Member", width=22)
    table.add_column("Hours", justify="right", width=8)
    table.add_column("Capacity", justify="right", width=10)
    table.add_column("Used %", justify="right", width=8)
    table.add_column("Billable", justify="right", width=8)
    table.add_column("Entries", justify="right", width=8)
    table.add_column("Status", width=14)

    for m in members:
        status = m.get("timesheet_status")
        style = _status_style(status)

        capacity_pct = m.get("capacity_percent", 0)
        if capacity_pct > 100:
            pct_display = f"[red]{capacity_pct}%[/red]"
        elif capacity_pct >= 80:
            pct_display = f"[green]{capacity_pct}%[/green]"
        else:
            pct_display = f"[yellow]{capacity_pct}%[/yellow]"

        period_cap = m.get("period_capacity_hours", "40.0")

        table.add_row(
            m.get("user_name", ""),
            format_duration(Decimal(str(m.get("total_hours", 0)))),
            f"{period_cap}h",
            pct_display,
            format_duration(Decimal(str(m.get("billable_hours", 0)))),
            str(m.get("entry_count", 0)),
            f"[{style}]{_status_label(status)}[/{style}]",
        )

    console.print(table)


# ─── Commands ─────────────────────────────────────────────────────


@app.callback(invoke_without_command=True)
def timesheet_default(ctx: typer.Context) -> None:
    """Manage timesheets and approvals."""
    if ctx.invoked_subcommand is None:
        list_timesheets()


@app.command("list")
def list_timesheets(
    user: Optional[str] = typer.Option(None, "--user", "-u", help="User ID to view (manager+)."),
    status_filter: Optional[str] = typer.Option(
        None, "--status", "-s",
        help="Filter by status: draft, submitted, approved, rejected.",
    ),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """List timesheets. Managers can view other users' timesheets.

    Examples:
        ct timesheet list
        ct timesheet list --user <user-id>
        ct timesheet list --status submitted
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    params: dict = {}
    if user:
        params["user_id"] = user
    if status_filter:
        params["status"] = status_filter

    try:
        data = client.get("/timesheets/", params=params or None)
        results = extract_results(data)

        if output_json:
            print_json(results)
        else:
            # Show user column when filtering by status (manager view) or by user
            _print_timesheets_table(results, show_user=bool(user or status_filter))
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command("submit")
def submit_timesheet(
    period_start: str = typer.Option(
        ..., "--from", help="Period start date (YYYY-MM-DD or keyword)."
    ),
    period_end: str = typer.Option(
        ..., "--to", help="Period end date (YYYY-MM-DD or keyword)."
    ),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation prompt."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Submit a timesheet for approval.

    Computes total hours from your time entries in the given period.
    Shows a preview of hours before submitting (use --force to skip).

    Examples:
        ct timesheet submit --from 2026-03-09 --to 2026-03-15
        ct timesheet submit --from monday --to friday --force
    """
    try:
        start = format_date(parse_date(period_start))
        end = format_date(parse_date(period_end))
    except ValueError as e:
        format_error(str(e))
        raise typer.Exit(1)

    client = CrowdTimeClient(require_auth=True, require_org=True)

    # Preview: fetch entries for the period and show summary before confirming
    if not force and not output_json:
        try:
            entries_data = client.get("/time-entries/", params={
                "date_from": start,
                "date_to": end,
            })
            entries = extract_results(entries_data)
            total_h = sum(Decimal(str(e.get("hours", 0))) for e in entries)
            billable_h = sum(
                Decimal(str(e.get("hours", 0)))
                for e in entries if e.get("is_billable")
            )
            console.print(f"\n[dim]Period: {start} → {end}[/dim]")
            console.print(
                f"  Entries: [bold]{len(entries)}[/bold]  |  "
                f"Total: [bold]{format_duration(total_h)}[/bold]  |  "
                f"Billable: [bold]{format_duration(billable_h)}[/bold]"
            )
            if not entries:
                format_error("No time entries found for this period. Cannot submit.")
                raise typer.Exit(1)
            if not typer.confirm("\nSubmit this timesheet for approval?"):
                console.print("[dim]Cancelled.[/dim]")
                raise typer.Exit(0)
        except APIError:
            pass  # If preview fails, proceed to submit (server will validate)

    try:
        result = client.post("/timesheets/submit/", data={
            "period_start": start,
            "period_end": end,
        })

        if output_json:
            print_json(result)
        else:
            total = format_duration(Decimal(str(result.get("total_hours", 0))))
            billable = format_duration(Decimal(str(result.get("billable_hours", 0))))
            entry_count = result.get("entry_count", 0)
            format_success(
                f"Timesheet submitted ({start} → {end}): "
                f"{total} total, {billable} billable, {entry_count} entries"
            )
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command("approve")
def approve_timesheet(
    timesheet_id: str = typer.Argument(..., help="Timesheet ID to approve."),
    project: Optional[str] = typer.Option(None, "--project", "-p", help="Approve only this project's portion (project ID)."),
    notes: Optional[str] = typer.Option(None, "--notes", "-n", help="Reviewer notes."),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation prompt."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Approve a submitted timesheet (project_manager+).

    Without --project: approves all project portions at once (manager+).
    With --project: approves only that project's portion (PM for that project).

    Examples:
        ct timesheet approve <timesheet-id>
        ct timesheet approve <timesheet-id> --project <project-id>
        ct timesheet approve <timesheet-id> --notes "Looks good" --force
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    if not force and not output_json:
        scope = f"project portion for {project}" if project else "all projects"
        if not typer.confirm(f"Approve timesheet {timesheet_id[:8]}… ({scope})?"):
            console.print("[dim]Cancelled.[/dim]")
            raise typer.Exit(0)

    try:
        data: dict = {}
        if notes:
            data["notes"] = notes

        if project:
            result = client.post(
                f"/timesheets/{timesheet_id}/approvals/{project}/approve/",
                data=data or None,
            )
        else:
            result = client.post(f"/timesheets/{timesheet_id}/approve/", data=data or None)

        if output_json:
            print_json(result)
        else:
            if project:
                project_name = result.get("project_name") or project[:8]
                ts_status = result.get("timesheet_status", "")
                format_success(f"Project '{project_name}' approved.")
                if ts_status == "approved":
                    console.print("[green]All projects approved — timesheet fully approved.[/green]")
            else:
                user_name = result.get("user_name", "user")
                format_success(f"Timesheet from {user_name} approved (all projects).")
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Timesheet '{timesheet_id}' not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@app.command("reject")
def reject_timesheet(
    timesheet_id: str = typer.Argument(..., help="Timesheet ID to reject."),
    project: Optional[str] = typer.Option(None, "--project", "-p", help="Reject only this project's portion (project ID)."),
    notes: str = typer.Option(
        ..., "--notes", "-n", help="Rejection reason (required)."
    ),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation prompt."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Reject a submitted timesheet with notes (project_manager+).

    Rejecting any project portion rejects the entire timesheet.
    The user must fix entries and resubmit.

    Examples:
        ct timesheet reject <timesheet-id> --notes "Missing entries for Wednesday"
        ct timesheet reject <timesheet-id> --project <project-id> --notes "Hours seem too high" --force
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    if not force and not output_json:
        console.print("[yellow]Rejecting will return the entire timesheet for revision.[/yellow]")
        if not typer.confirm(f"Reject timesheet {timesheet_id[:8]}…?"):
            console.print("[dim]Cancelled.[/dim]")
            raise typer.Exit(0)

    try:
        if project:
            result = client.post(
                f"/timesheets/{timesheet_id}/approvals/{project}/reject/",
                data={"notes": notes},
            )
        else:
            result = client.post(f"/timesheets/{timesheet_id}/reject/", data={
                "notes": notes,
            })

        if output_json:
            print_json(result)
        else:
            if project:
                project_name = result.get("project_name") or project[:8]
                format_success(f"Project '{project_name}' rejected. Timesheet returned for revision.")
            else:
                user_name = result.get("user_name", "user")
                format_success(f"Timesheet from {user_name} rejected.")
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Timesheet '{timesheet_id}' not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@app.command("recall")
def recall_timesheet(
    timesheet_id: str = typer.Argument(..., help="Timesheet ID to recall."),
    notes: Optional[str] = typer.Option(None, "--notes", "-n", help="Reason for recalling."),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation prompt."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Recall a submitted timesheet back to draft (submitter only, before approval).

    Examples:
        ct timesheet recall <timesheet-id>
        ct timesheet recall <timesheet-id> --notes "Need to fix Wednesday entries" --force
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    if not force and not output_json:
        if not typer.confirm(f"Recall timesheet {timesheet_id[:8]}… back to draft?"):
            console.print("[dim]Cancelled.[/dim]")
            raise typer.Exit(0)

    try:
        data: dict = {}
        if notes:
            data["notes"] = notes

        result = client.post(f"/timesheets/{timesheet_id}/recall/", data=data or None)

        if output_json:
            print_json(result)
        else:
            format_success("Timesheet recalled to draft. You can now edit and resubmit.")
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Timesheet '{timesheet_id}' not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@app.command("team")
def team_overview(
    period_start: Optional[str] = typer.Option(
        None, "--from", help="Period start date (YYYY-MM-DD, default: current week)."
    ),
    period_end: Optional[str] = typer.Option(
        None, "--to", help="Period end date (YYYY-MM-DD)."
    ),
    week: bool = typer.Option(False, "--week", "-w", help="This week (default if no period specified)."),
    last_week: bool = typer.Option(False, "--last-week", help="Last week."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Show team timesheet overview for a period (manager+).

    Displays all org members with their hours and timesheet status,
    including those who haven't submitted yet.

    Examples:
        ct timesheet team
        ct timesheet team --last-week
        ct timesheet team --from 2026-03-09 --to 2026-03-15
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    params: dict = {}

    if period_start:
        try:
            params["period_start"] = format_date(parse_date(period_start))
        except ValueError as e:
            format_error(str(e))
            raise typer.Exit(1)
    if period_end:
        try:
            params["period_end"] = format_date(parse_date(period_end))
        except ValueError as e:
            format_error(str(e))
            raise typer.Exit(1)

    if last_week and not period_start:
        today = date_type.today()
        start = today - timedelta(days=today.weekday() + 7)
        end = start + timedelta(days=6)
        params["period_start"] = format_date(start)
        params["period_end"] = format_date(end)

    try:
        data = client.get("/timesheets/team-overview/", params=params or None)

        if output_json:
            print_json(data)
        else:
            _print_team_overview(data)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command("viewable-users")
def viewable_users(
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """List team members whose timesheets you can view (manager+).

    Examples:
        ct timesheet viewable-users
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.get("/timesheets/viewable-users/")
        users = extract_results(data)

        if output_json:
            print_json(users)
        else:
            from rich.table import Table

            if not users:
                console.print("[dim]No viewable users found.[/dim]")
                return

            table = Table(show_header=True, header_style="bold")
            table.add_column("ID", style="dim")
            table.add_column("Name", width=20)
            table.add_column("Email", width=30)

            for u in users:
                table.add_row(
                    u.get("id", ""),
                    u.get("full_name", ""),
                    u.get("email", ""),
                )

            console.print(table)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command("bulk-approve")
def bulk_approve_timesheets(
    timesheet_ids: list[str] = typer.Argument(..., help="Timesheet IDs to approve."),
    project: Optional[str] = typer.Option(None, "--project", "-p", help="Approve only this project's portion in each timesheet (PM for that project)."),
    notes: Optional[str] = typer.Option(None, "--notes", "-n", help="Reviewer notes."),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation prompt."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Approve multiple submitted timesheets at once (manager+).

    Without --project: approves all project portions in each timesheet (manager+).
    With --project: approves only that project's portion in each timesheet (PM).

    Examples:
        ct timesheet bulk-approve <id1> <id2> <id3>
        ct timesheet bulk-approve <id1> <id2> --project <project-id>
        ct timesheet bulk-approve <id1> <id2> --notes "Week approved" --force
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    if not force and not output_json:
        scope = f"project {project}" if project else "all projects"
        if not typer.confirm(f"Approve {len(timesheet_ids)} timesheet(s) ({scope})?"):
            console.print("[dim]Cancelled.[/dim]")
            raise typer.Exit(0)

    try:
        if project:
            # Per-project bulk: loop and approve each individually
            approved = 0
            skipped = 0
            errors: list[str] = []
            for ts_id in timesheet_ids:
                try:
                    data: dict = {}
                    if notes:
                        data["notes"] = notes
                    client.post(
                        f"/timesheets/{ts_id}/approvals/{project}/approve/",
                        data=data or None,
                    )
                    approved += 1
                except APIError as e:
                    skipped += 1
                    errors.append(f"  {ts_id}: {e.message}")

            result = {"total_approved": approved, "total_skipped": skipped}
            if output_json:
                print_json(result)
            else:
                format_success(f"Approved {approved} timesheet(s) for project.")
                if skipped:
                    console.print(
                        f"[yellow]Skipped {skipped} (not found, not submitted, or no matching project):[/yellow]"
                    )
                    for err in errors:
                        console.print(f"[yellow]{err}[/yellow]")
        else:
            payload: dict = {"timesheet_ids": timesheet_ids}
            if notes:
                payload["notes"] = notes

            result = client.post("/timesheets/bulk-approve/", data=payload)

            if output_json:
                print_json(result)
            else:
                approved = result.get("total_approved", 0)
                skipped = result.get("total_skipped", 0)
                format_success(f"Approved {approved} timesheet(s).")
                if skipped:
                    console.print(
                        f"[yellow]Skipped {skipped} (not found or not submitted).[/yellow]"
                    )
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command("bulk-reject")
def bulk_reject_timesheets(
    timesheet_ids: list[str] = typer.Argument(..., help="Timesheet IDs to reject."),
    project: Optional[str] = typer.Option(None, "--project", "-p", help="Reject only this project's portion in each timesheet (PM for that project)."),
    notes: str = typer.Option(
        ..., "--notes", "-n", help="Rejection reason (required)."
    ),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation prompt."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Reject multiple submitted timesheets at once (manager+).

    Without --project: rejects all timesheets entirely (manager+).
    With --project: rejects that project's portion in each timesheet (PM).
    Rejecting any portion rejects the entire timesheet.

    Examples:
        ct timesheet bulk-reject <id1> <id2> --notes "Incomplete entries"
        ct timesheet bulk-reject <id1> <id2> --project <project-id> --notes "Hours too high" --force
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    if not force and not output_json:
        console.print(f"[yellow]Rejecting will return all {len(timesheet_ids)} timesheet(s) for revision.[/yellow]")
        if not typer.confirm("Proceed?"):
            console.print("[dim]Cancelled.[/dim]")
            raise typer.Exit(0)

    try:
        if project:
            # Per-project bulk: loop and reject each individually
            rejected = 0
            skipped = 0
            errors = []
            for ts_id in timesheet_ids:
                try:
                    client.post(
                        f"/timesheets/{ts_id}/approvals/{project}/reject/",
                        data={"notes": notes},
                    )
                    rejected += 1
                except APIError as e:
                    skipped += 1
                    errors.append(f"  {ts_id}: {e.message}")

            result = {"total_rejected": rejected, "total_skipped": skipped}
            if output_json:
                print_json(result)
            else:
                format_success(f"Rejected {rejected} timesheet(s) for project.")
                if skipped:
                    console.print(
                        f"[yellow]Skipped {skipped} (not found, not submitted, or no matching project).[/yellow]"
                    )
                    for err in errors:
                        console.print(f"[dim]{err}[/dim]")
        else:
            result = client.post("/timesheets/bulk-reject/", data={
                "timesheet_ids": timesheet_ids,
                "notes": notes,
            })

            if output_json:
                print_json(result)
            else:
                rejected = result.get("total_rejected", 0)
                skipped = result.get("total_skipped", 0)
                format_success(f"Rejected {rejected} timesheet(s).")
                if skipped:
                    console.print(
                        f"[yellow]Skipped {skipped} (not found or not submitted).[/yellow]"
                    )
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command("history")
def timesheet_history(
    timesheet_id: str = typer.Argument(..., help="Timesheet ID."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Show the full audit trail for a timesheet.

    Displays all state changes: submissions, approvals, rejections, recalls.

    Examples:
        ct timesheet history <timesheet-id>
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        events = client.get(f"/timesheets/{timesheet_id}/history/")
        results = extract_results(events)

        if output_json:
            print_json(results)
        else:
            from rich.table import Table

            if not results:
                console.print("[dim]No history events found.[/dim]")
                return

            table = Table(show_header=True, header_style="bold", title="Timesheet History")
            table.add_column("Date", width=20)
            table.add_column("Event", width=14)
            table.add_column("By", width=20)
            table.add_column("Notes", width=40)

            for e in results:
                event_type = e.get("event_type", "")
                event_styles = {
                    "submitted": "blue",
                    "approved": "green",
                    "rejected": "red",
                    "recalled": "yellow",
                }
                style = event_styles.get(event_type, "dim")

                created = format_iso_datetime(e.get("created_at"))

                table.add_row(
                    created,
                    f"[{style}]{event_type.capitalize()}[/{style}]",
                    e.get("actor_name", "—"),
                    e.get("notes", "") or "—",
                )

            console.print(table)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command("approvals")
def timesheet_approvals(
    timesheet_id: str = typer.Argument(..., help="Timesheet ID."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Show per-project approval status for a timesheet.

    Displays which projects have been approved, rejected, or are still
    pending review. Useful for PMs to see which portions need their action.

    Examples:
        ct timesheet approvals <timesheet-id>
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        results = client.get(f"/timesheets/{timesheet_id}/approvals/")
        if isinstance(results, dict):
            results = results.get("results", results) if "results" in results else [results]
        if not isinstance(results, list):
            results = [results]

        if output_json:
            print_json(results)
        else:
            from rich.table import Table

            if not results:
                console.print("[dim]No project approvals found for this timesheet.[/dim]")
                return

            table = Table(
                show_header=True, header_style="bold",
                title="Project Approvals",
            )
            table.add_column("Project", width=25)
            table.add_column("Hours", justify="right", width=8)
            table.add_column("Billable", justify="right", width=8)
            table.add_column("Entries", justify="right", width=8)
            table.add_column("Status", width=12)
            table.add_column("Reviewed By", width=18)

            for a in results:
                a_status = a.get("status", "pending")
                status_styles = {
                    "approved": "green",
                    "rejected": "red",
                    "pending": "yellow",
                }
                style = status_styles.get(a_status, "dim")
                label = a_status.capitalize()

                table.add_row(
                    a.get("project_name", ""),
                    format_duration(Decimal(str(a.get("hours", 0)))),
                    format_duration(Decimal(str(a.get("billable_hours", 0)))),
                    str(a.get("entry_count", 0)),
                    f"[{style}]{label}[/{style}]",
                    a.get("reviewed_by_name") or "—",
                )

            console.print(table)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command("compliance")
def compliance_report(
    period_start: Optional[str] = typer.Option(
        None, "--from", help="Period start date (YYYY-MM-DD, default: current week)."
    ),
    period_end: Optional[str] = typer.Option(
        None, "--to", help="Period end date (YYYY-MM-DD)."
    ),
    week: bool = typer.Option(False, "--week", help="Current week."),
    last_week: bool = typer.Option(False, "--last-week", help="Last week."),
    month: bool = typer.Option(False, "--month", help="Current month."),
    last_month: bool = typer.Option(False, "--last-month", help="Last month."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Show timesheet compliance report for a period (manager+).

    Displays who hasn't submitted, who's pending approval (with days
    waiting), and a summary of submission status across the org.

    Examples:
        ct timesheet compliance
        ct timesheet compliance --last-week
        ct timesheet compliance --month
        ct timesheet compliance --last-month
        ct timesheet compliance --from 2026-03-09 --to 2026-03-15
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    params: dict = {}

    if period_start:
        try:
            params["period_start"] = format_date(parse_date(period_start))
        except ValueError as e:
            format_error(str(e))
            raise typer.Exit(1)
    if period_end:
        try:
            params["period_end"] = format_date(parse_date(period_end))
        except ValueError as e:
            format_error(str(e))
            raise typer.Exit(1)

    if not period_start:
        today = date_type.today()
        if last_week:
            start = today - timedelta(days=today.weekday() + 7)
            end = start + timedelta(days=6)
            params["period_start"] = format_date(start)
            params["period_end"] = format_date(end)
        elif week:
            start = today - timedelta(days=today.weekday())
            end = start + timedelta(days=6)
            params["period_start"] = format_date(start)
            params["period_end"] = format_date(end)
        elif month:
            start = today.replace(day=1)
            if today.month == 12:
                end = today.replace(year=today.year + 1, month=1, day=1) - timedelta(days=1)
            else:
                end = today.replace(month=today.month + 1, day=1) - timedelta(days=1)
            params["period_start"] = format_date(start)
            params["period_end"] = format_date(end)
        elif last_month:
            first_of_this_month = today.replace(day=1)
            end = first_of_this_month - timedelta(days=1)
            start = end.replace(day=1)
            params["period_start"] = format_date(start)
            params["period_end"] = format_date(end)

    try:
        data = client.get("/timesheets/compliance/", params=params or None)

        if output_json:
            print_json(data)
            return

        from rich.panel import Panel
        from rich.table import Table

        period = f"{data.get('period_start', '')} → {data.get('period_end', '')}"
        summary = data.get("summary", {})

        # Summary panel
        total = summary.get("total_members", 0)
        approved_n = summary.get("approved", 0)
        pending_n = summary.get("pending_approval", 0)
        not_sub_n = summary.get("not_submitted", 0)
        rejected_n = summary.get("rejected", 0)

        pct_complete = round(approved_n / total * 100) if total > 0 else 0

        summary_text = (
            f"[dim]Period:[/dim] {period}\n"
            f"[dim]Members:[/dim] {total}  |  "
            f"[green]Approved: {approved_n}[/green]  |  "
            f"[blue]Pending: {pending_n}[/blue]  |  "
            f"[yellow]Not Submitted: {not_sub_n}[/yellow]  |  "
            f"[red]Rejected: {rejected_n}[/red]\n"
            f"[dim]Completion:[/dim] {pct_complete}%"
        )
        console.print(Panel(summary_text, title="Timesheet Compliance", border_style="dim"))

        # Not submitted
        not_submitted = data.get("not_submitted", [])
        if not_submitted:
            table = Table(
                show_header=True, header_style="bold",
                title=f"[yellow]Not Submitted ({len(not_submitted)})[/yellow]",
            )
            table.add_column("Member", width=22)
            table.add_column("Email", width=28)
            table.add_column("Role", width=10)
            table.add_column("Has Entries", width=12)
            table.add_column("Days Overdue", width=12, justify="right")
            table.add_column("Status", width=10)

            for m in not_submitted:
                has_entries = "Yes" if m.get("has_entries") else "No"
                ts_status = m.get("status", "none")
                days_overdue = m.get("days_overdue")
                days_str = str(days_overdue) if days_overdue is not None else "-"
                if days_overdue and days_overdue >= 7:
                    days_str = f"[red]{days_str}[/red]"
                elif days_overdue and days_overdue >= 3:
                    days_str = f"[yellow]{days_str}[/yellow]"
                table.add_row(
                    m.get("user_name", ""),
                    m.get("user_email", ""),
                    m.get("role", ""),
                    f"[green]{has_entries}[/green]" if m.get("has_entries") else f"[dim]{has_entries}[/dim]",
                    days_str,
                    f"[dim]{ts_status}[/dim]",
                )
            console.print(table)

        # Pending approval
        pending = data.get("pending_approval", [])
        if pending:
            table = Table(
                show_header=True, header_style="bold",
                title=f"[blue]Pending Approval ({len(pending)})[/blue]",
            )
            table.add_column("Member", width=22)
            table.add_column("Timesheet ID", style="dim")
            table.add_column("Hours", justify="right", width=8)
            table.add_column("Submitted", width=12)
            table.add_column("Days Pending", justify="right", width=13)

            for p in pending:
                days = p.get("days_pending", 0)
                days_style = "red" if days >= 3 else "yellow" if days >= 1 else "dim"
                submitted = format_iso_date(p.get("submitted_at"))
                table.add_row(
                    p.get("user_name", ""),
                    p.get("timesheet_id", ""),
                    format_duration(Decimal(str(p.get("total_hours", 0)))),
                    submitted,
                    f"[{days_style}]{days}d[/{days_style}]",
                )
            console.print(table)

        # Rejected
        rejected_list = data.get("rejected", [])
        if rejected_list:
            table = Table(
                show_header=True, header_style="bold",
                title=f"[red]Rejected ({len(rejected_list)})[/red]",
            )
            table.add_column("Member", width=22)
            table.add_column("Timesheet ID", style="dim")
            table.add_column("Hours", justify="right", width=8)
            table.add_column("Reviewer Notes", width=35)

            for r in rejected_list:
                table.add_row(
                    r.get("user_name", ""),
                    r.get("timesheet_id", ""),
                    format_duration(Decimal(str(r.get("total_hours", 0)))),
                    r.get("reviewer_notes", "") or "—",
                )
            console.print(table)

        if not not_submitted and not pending and not rejected_list:
            console.print(
                f"\n[green]All {total} members have approved timesheets for this period.[/green]"
            )

    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)
