"""Invoice commands: list, show, create, send, void, pay, pdf, duplicate, add-item, recurring, retainer."""

from __future__ import annotations

import calendar
from datetime import date as date_type, datetime as datetime_type, timedelta
from decimal import Decimal
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from ..client import APIError, CrowdTimeClient
from ..formatters import (
    extract_results,
    format_currency,
    format_error,
    format_success,
    print_json,
    status_label as _raw_status_label,
    status_style as _raw_status_style,
)
from ..utils import format_date, format_duration, format_iso_date, parse_date

app = typer.Typer(name="invoice", help="Manage invoices, payments, and billing.")
console = Console()

# ─── Sub-apps for nested commands ─────────────────────────────────

recurring_app = typer.Typer(name="recurring", help="Manage recurring invoice templates.")
retainer_app = typer.Typer(name="retainer", help="Manage retainer agreements.")
app.add_typer(recurring_app, name="recurring")
app.add_typer(retainer_app, name="retainer")


# ─── Helpers ──────────────────────────────────────────────────────


def _status_style(status: str | None) -> str:
    return _raw_status_style(status, context="invoice")


def _status_label(status: str | None) -> str:
    return _raw_status_label(status, default="Draft")




def _resolve_period(period: str) -> tuple[str, str]:
    """Resolve a preset period name into (start_date, end_date) ISO strings.

    Uses Monday as the default week start day.
    """
    today = date_type.today()

    if period == "last-week":
        # Monday of last week to Sunday of last week
        monday_this_week = today - timedelta(days=today.weekday())
        start = monday_this_week - timedelta(days=7)
        end = start + timedelta(days=6)
    elif period == "last-2-weeks":
        monday_this_week = today - timedelta(days=today.weekday())
        start = monday_this_week - timedelta(days=14)
        end = monday_this_week - timedelta(days=1)
    elif period == "last-month":
        first_this_month = today.replace(day=1)
        last_day_prev = first_this_month - timedelta(days=1)
        start = last_day_prev.replace(day=1)
        end = last_day_prev
    elif period == "this-month":
        start = today.replace(day=1)
        last_day = calendar.monthrange(today.year, today.month)[1]
        end = today.replace(day=last_day)
    else:
        raise ValueError(
            f"Unknown period '{period}'. "
            "Choose: last-week, last-2-weeks, last-month, this-month."
        )

    return format_date(start), format_date(end)


def _resolve_payment_terms(value: str) -> int | None:
    """Resolve a payment terms string to an integer number of days.

    Returns None if the value is invalid.
    """
    mapping = {
        "receipt": 0,
        "net15": 15,
        "net30": 30,
    }
    lower = value.strip().lower()
    if lower in mapping:
        return mapping[lower]
    try:
        return int(lower)
    except ValueError:
        return None


def _print_invoices_table(invoices: list[dict]) -> None:
    """Print invoices in a Rich table."""
    if not invoices:
        console.print("[dim]No invoices found.[/dim]")
        console.print("Run [bold]ct invoice create --client <id>[/bold] to create an invoice.")
        return

    # Show currency column only when invoices use multiple currencies
    currencies = {inv.get("currency", "USD") for inv in invoices}
    multi_currency = len(currencies) > 1

    table = Table(show_header=True, header_style="bold")
    table.add_column("Number", width=14)
    table.add_column("Client", width=20)
    table.add_column("Type", width=10)
    if multi_currency:
        table.add_column("Cur", width=5)
    table.add_column("Issue Date", width=12)
    table.add_column("Due Date", width=12)
    table.add_column("Total", justify="right", width=12)
    table.add_column("Due", justify="right", width=12)
    table.add_column("Status", width=16)

    for inv in invoices:
        status = inv.get("status", "draft")
        style = _status_style(status)
        currency = inv.get("currency", "USD")
        inv_type = inv.get("invoice_type", inv.get("type", "standard"))

        # Build status label with days overdue indicator
        days_overdue = inv.get("days_overdue")
        status_text = f"[{style}]{_status_label(status)}[/{style}]"
        if days_overdue and days_overdue > 0:
            status_text += f" [red]({days_overdue}d)[/red]"

        row = [
            inv.get("invoice_number", inv.get("number", "")),
            inv.get("client_name", ""),
            inv_type.capitalize() if inv_type else "Standard",
        ]
        if multi_currency:
            row.append(currency)
        row.extend([
            inv.get("issue_date", ""),
            inv.get("due_date", ""),
            format_currency(inv.get("total_amount", inv.get("total", 0)), currency),
            format_currency(inv.get("amount_due", inv.get("due", 0)), currency),
            status_text,
        ])
        table.add_row(*row)

    console.print(table)


def _print_invoice_detail(data: dict) -> None:
    """Print detailed invoice view."""
    currency = data.get("currency", "USD")
    status = data.get("status", "draft")
    style = _status_style(status)

    console.print()
    console.print(f"[bold]Invoice {data.get('invoice_number', data.get('number', ''))}[/bold]")
    console.print(f"  ID:             {data.get('id', '')}")
    if data.get("subject"):
        console.print(f"  Subject:        {data['subject']}")
    console.print(f"  Client:         {data.get('client_name', '')}")
    if data.get("from_name"):
        console.print(f"  From:           {data['from_name']}")
    inv_type = data.get("invoice_type", data.get("type", "standard"))
    console.print(f"  Type:           {inv_type.capitalize() if inv_type else 'Standard'}")
    console.print(f"  Status:         [{style}]{_status_label(status)}[/{style}]")
    console.print(f"  Issue Date:     {data.get('issue_date', '')}")
    console.print(f"  Due Date:       {data.get('due_date', '')}")
    if data.get("period_start") or data.get("period_end"):
        period_str = f"{data.get('period_start', '?')} to {data.get('period_end', '?')}"
        console.print(f"  Period:         {period_str}")
    console.print(f"  Currency:       {currency}")

    if data.get("po_number"):
        console.print(f"  PO Number:      {data['po_number']}")

    # Line items
    line_items = data.get("line_items", data.get("items", []))
    if line_items:
        console.print()
        items_table = Table(show_header=True, header_style="bold", title="Line Items")
        items_table.add_column("#", width=4, justify="right")
        items_table.add_column("Description", width=35)
        items_table.add_column("Qty", justify="right", width=8)
        items_table.add_column("Rate", justify="right", width=10)
        items_table.add_column("Amount", justify="right", width=12)
        items_table.add_column("Tax", width=5, justify="center")

        for i, item in enumerate(line_items, 1):
            qty = item.get("quantity", item.get("qty", 0))
            rate = item.get("unit_price", item.get("rate", 0))
            amount = item.get("amount", item.get("total", 0))
            taxable = item.get("is_taxable", item.get("taxable", False))

            items_table.add_row(
                str(i),
                item.get("description", ""),
                str(qty),
                format_currency(rate, currency),
                format_currency(amount, currency),
                "[green]Y[/green]" if taxable else "[dim]N[/dim]",
            )

        console.print(items_table)

    # Totals
    console.print()
    console.print("[bold]Totals[/bold]")
    console.print(f"  Subtotal:       {format_currency(data.get('subtotal', data.get('total_amount', 0)), currency)}")
    if data.get("tax_amount"):
        tax_rate = data.get("tax_rate", "")
        tax_label = f" ({tax_rate}%)" if tax_rate else ""
        console.print(f"  Tax{tax_label}:          {format_currency(data['tax_amount'], currency)}")
    if data.get("discount_amount"):
        console.print(f"  Discount:       -{format_currency(data['discount_amount'], currency)}")
    console.print(f"  [bold]Total:          {format_currency(data.get('total_amount', data.get('total', 0)), currency)}[/bold]")
    console.print(f"  Paid:           {format_currency(data.get('paid_amount', data.get('amount_paid', 0)), currency)}")
    console.print(f"  [bold]Amount Due:     {format_currency(data.get('amount_due', data.get('due', 0)), currency)}[/bold]")

    # Payments
    payments = data.get("payments", [])
    if payments:
        console.print()
        pay_table = Table(show_header=True, header_style="bold", title="Payments")
        pay_table.add_column("Date", width=12)
        pay_table.add_column("Amount", justify="right", width=12)
        pay_table.add_column("Method", width=15)
        pay_table.add_column("Reference", width=20)
        pay_table.add_column("Notes", width=25)

        for pay in payments:
            pay_table.add_row(
                pay.get("payment_date", pay.get("date", "")),
                format_currency(pay.get("amount", 0), currency),
                pay.get("payment_method", pay.get("method", "")) or "",
                pay.get("reference", "") or "",
                pay.get("notes", "") or "",
            )

        console.print(pay_table)

    # Notes and terms
    if data.get("notes"):
        console.print(f"\n[dim]Notes:[/dim] {data['notes']}")
    if data.get("terms"):
        console.print(f"[dim]Terms:[/dim] {data['terms']}")

    console.print()


# ─── Commands ─────────────────────────────────────────────────────


@app.callback(invoke_without_command=True)
def invoice_default(ctx: typer.Context) -> None:
    """Manage invoices, payments, and billing."""
    if ctx.invoked_subcommand is None:
        list_invoices()


@app.command("list")
def list_invoices(
    status: Optional[str] = typer.Option(
        None, "--status", "-s", help="Filter by status: draft, sent, paid, overdue, void, partial."
    ),
    overdue: bool = typer.Option(False, "--overdue", help="Show only overdue invoices (shortcut for --status overdue)."),
    unpaid: bool = typer.Option(
        False, "--unpaid", help="Show all unpaid invoices (sent, viewed, overdue, partially paid)."
    ),
    client_id: Optional[str] = typer.Option(
        None, "--client", "-c", help="Filter by client ID."
    ),
    invoice_type: Optional[str] = typer.Option(
        None, "--type", "-t", help="Filter by type: standard, recurring, retainer."
    ),
    date_from: Optional[str] = typer.Option(
        None, "--from", help="Filter by issue date from (YYYY-MM-DD)."
    ),
    date_to: Optional[str] = typer.Option(
        None, "--to", help="Filter by issue date to (YYYY-MM-DD)."
    ),
    due_from: Optional[str] = typer.Option(
        None, "--due-from", help="Filter by due date from (YYYY-MM-DD)."
    ),
    due_to: Optional[str] = typer.Option(
        None, "--due-to", help="Filter by due date to (YYYY-MM-DD)."
    ),
    search: Optional[str] = typer.Option(
        None, "--search", "-q", help="Search by invoice number, subject, or client name."
    ),
    min_amount: Optional[float] = typer.Option(
        None, "--min-amount", help="Filter by minimum total amount."
    ),
    max_amount: Optional[float] = typer.Option(
        None, "--max-amount", help="Filter by maximum total amount."
    ),
    sort: Optional[str] = typer.Option(
        None, "--sort", help="Sort by: issue_date, due_date, total, amount_due, created_at. Prefix with - for descending."
    ),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """List invoices in the current organization.

    Examples:
        ct invoice list
        ct invoice list --status sent
        ct invoice list --overdue
        ct invoice list --unpaid
        ct invoice list --client <client-id> --status paid
        ct invoice list --type recurring
        ct invoice list --from 2026-01-01 --to 2026-03-31
        ct invoice list --search "INV-001"
        ct invoice list --min-amount 1000 --max-amount 5000
        ct invoice list --sort -due_date
        ct invoice list --due-from 2026-04-01 --due-to 2026-04-30
    """
    # Convenience flags override explicit --status
    if overdue and not status:
        status = "overdue"
    elif unpaid and not status:
        status = "sent,viewed,overdue,partially_paid"

    client = CrowdTimeClient(require_auth=True, require_org=True)

    params: dict = {}
    if status:
        params["status"] = status
    if client_id:
        params["client"] = client_id
    if invoice_type:
        params["invoice_type"] = invoice_type
    if date_from:
        params["issue_date_from"] = date_from
    if date_to:
        params["issue_date_to"] = date_to
    if search:
        params["search"] = search
    if min_amount is not None:
        params["total_min"] = str(min_amount)
    if max_amount is not None:
        params["total_max"] = str(max_amount)
    if due_from:
        params["due_date_from"] = due_from
    if due_to:
        params["due_date_to"] = due_to
    if sort:
        params["ordering"] = sort

    try:
        data = client.get("/invoices/", params=params or None)
        results = extract_results(data)

        if output_json:
            print_json(results)
        else:
            _print_invoices_table(results)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command("summary")
def invoice_summary(
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Show invoice summary statistics.

    Displays counts by status, total outstanding, overdue, paid, draft
    amounts, and average days to payment.

    Examples:
        ct invoice summary
        ct invoice summary --json
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.get("/invoices/summary/")

        if output_json:
            print_json(data)
            return

        from ..formatters import format_currency as _fc

        currency = data.get("currency", "USD")

        console.print("\n[bold]Invoice Summary[/bold]\n")

        # Status counts
        counts = data.get("count_by_status", {})
        total = data.get("invoice_count", 0)
        console.print(f"  Total invoices: [bold]{total}[/bold]")
        if counts:
            parts = []
            for s, c in sorted(counts.items()):
                style = {
                    "draft": "dim", "sent": "blue", "paid": "green",
                    "overdue": "red", "void": "red dim", "partial": "yellow",
                    "viewed": "cyan",
                }.get(s, "yellow")
                parts.append(f"[{style}]{s}: {c}[/{style}]")
            console.print(f"  By status: {', '.join(parts)}")

        console.print()

        # Financial totals
        console.print(f"  Outstanding: [bold]{_fc(data.get('total_outstanding', 0), currency)}[/bold]")
        overdue = data.get("total_overdue", 0)
        overdue_str = _fc(overdue, currency)
        if overdue and Decimal(str(overdue)) > 0:
            console.print(f"  Overdue:     [red bold]{overdue_str}[/red bold]")
        else:
            console.print(f"  Overdue:     {overdue_str}")
        console.print(f"  Paid:        [green]{_fc(data.get('total_paid', 0), currency)}[/green]")
        console.print(f"  Draft:       [dim]{_fc(data.get('total_draft', 0), currency)}[/dim]")

        # Overdue aging
        overdue_count = data.get("overdue_count", 0)
        if overdue_count:
            oldest = data.get("oldest_overdue_due_date")
            aging_detail = ""
            if oldest:
                from datetime import date as dt_date
                try:
                    oldest_date = dt_date.fromisoformat(oldest)
                    days_overdue = (dt_date.today() - oldest_date).days
                    aging_detail = f" (oldest: {days_overdue} days)"
                except ValueError:
                    pass
            console.print(f"  Overdue:     [red bold]{overdue_count} invoice{'s' if overdue_count != 1 else ''}{aging_detail}[/red bold]")

        avg_days = data.get("avg_days_to_payment")
        collection_rate = data.get("collection_rate")
        if avg_days is not None or collection_rate is not None:
            console.print()
        if avg_days is not None:
            console.print(f"  Avg. days to payment: [bold]{avg_days}[/bold]")
        if collection_rate is not None:
            rate_style = "green" if collection_rate >= 80 else ("yellow" if collection_rate >= 50 else "red")
            console.print(f"  Collection rate:      [{rate_style} bold]{collection_rate}%[/{rate_style} bold]")

        console.print()
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command("aging")
def invoice_aging(
    client_id: Optional[str] = typer.Option(
        None, "--client", "-c", help="Filter by client ID."
    ),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Show invoice aging report grouped by overdue buckets.

    Displays unpaid invoices grouped into aging buckets: current (not yet due),
    1-30 days, 31-60 days, 61-90 days, and 90+ days overdue.

    Examples:
        ct invoice aging
        ct invoice aging --client <client-id>
        ct invoice aging --json
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    params: dict = {}
    if client_id:
        params["client"] = client_id

    try:
        data = client.get("/invoices/aging/", params=params or None)

        if output_json:
            print_json(data)
            return

        grand_total = Decimal(str(data.get("grand_total", 0)))
        total_invoices = data.get("total_invoices", 0)
        currency = data.get("currency", "USD")

        if total_invoices == 0:
            console.print("[green]No unpaid invoices.[/green]")
            return

        console.print(f"\n[bold]Invoice Aging Report[/bold]")
        console.print(f"  Total unpaid: [bold]{total_invoices}[/bold] invoices — {format_currency(grand_total, currency)}\n")

        for bucket in data.get("buckets", []):
            count = bucket.get("count", 0)
            if count == 0:
                continue

            bucket_total = Decimal(str(bucket.get("total", 0)))
            label = bucket.get("label", "")
            key = bucket.get("key", "")

            # Color based on severity
            if key == "current":
                style = "green"
            elif key == "1_30":
                style = "yellow"
            elif key == "31_60":
                style = "red"
            else:
                style = "red bold"

            console.print(f"  [{style}]{label}[/{style}]: {count} invoice{'s' if count != 1 else ''} — {format_currency(bucket_total, currency)}")

            # Show individual invoices in the bucket
            table = Table(show_header=True, header_style="dim", padding=(0, 1))
            table.add_column("Number", width=14)
            table.add_column("Client", width=22)
            table.add_column("Due Date", width=12)
            table.add_column("Days", justify="right", width=6)
            table.add_column("Amount Due", justify="right", width=14)

            for inv in bucket.get("invoices", []):
                currency = inv.get("currency", "USD")
                days = inv.get("days_overdue", 0)
                days_str = str(days) if days > 0 else "-"
                table.add_row(
                    inv.get("invoice_number", ""),
                    inv.get("client_name", ""),
                    inv.get("due_date", ""),
                    days_str,
                    format_currency(inv.get("amount_due", 0), currency),
                )

            console.print(table)
            console.print()

    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command("show")
def show_invoice(
    invoice_id: str = typer.Argument(..., help="Invoice ID."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Show detailed view of an invoice.

    Examples:
        ct invoice show <invoice-id>
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.get(f"/invoices/{invoice_id}/")

        if output_json:
            print_json(data)
        else:
            _print_invoice_detail(data)
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Invoice '{invoice_id}' not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@app.command("create")
def create_invoice(
    client_id: str = typer.Option(..., "--client", "-c", help="Client ID."),
    from_date: Optional[str] = typer.Option(None, "--from", help="Period start date (YYYY-MM-DD)."),
    to_date: Optional[str] = typer.Option(None, "--to", help="Period end date (YYYY-MM-DD)."),
    period: Optional[str] = typer.Option(
        None, "--period", "-P",
        help="Preset period: last-week, last-2-weeks, last-month, this-month.",
    ),
    group_by: Optional[str] = typer.Option(
        None, "--group-by", "-g", help="Group line items by: project, task, user, date, none."
    ),
    tax_rate: Optional[float] = typer.Option(
        None, "--tax-rate", help="Tax rate percentage (e.g. 21 for 21%)."
    ),
    notes: Optional[str] = typer.Option(None, "--notes", "-n", help="Invoice notes."),
    terms: Optional[str] = typer.Option(None, "--terms", help="Payment terms text."),
    payment_terms: Optional[str] = typer.Option(
        None, "--payment-terms",
        help="Payment terms: receipt, net15, net30, or number of days.",
    ),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Create an invoice from tracked time entries.

    Generates an invoice for a client's billable time entries within
    the specified date range. Use --period for preset ranges or
    --from/--to for custom dates.

    Examples:
        ct invoice create --client <id> --from 2026-03-01 --to 2026-03-31
        ct invoice create --client <id> --period last-month --group-by project
        ct invoice create --client <id> --period last-2-weeks --payment-terms net30
        ct invoice create --client <id> --from monday --to friday --payment-terms 15
    """
    # Resolve period dates
    if period:
        if from_date or to_date:
            format_error("Cannot use --period together with --from/--to. Choose one.")
            raise typer.Exit(1)
        try:
            start, end = _resolve_period(period)
        except ValueError as e:
            format_error(str(e))
            raise typer.Exit(1)
    elif from_date and to_date:
        try:
            start = format_date(parse_date(from_date))
            end = format_date(parse_date(to_date))
        except ValueError as e:
            format_error(str(e))
            raise typer.Exit(1)
    else:
        format_error("Provide either --period or both --from and --to.")
        raise typer.Exit(1)

    # Resolve payment terms
    payment_terms_days: int | None = None
    if payment_terms is not None:
        payment_terms_days = _resolve_payment_terms(payment_terms)
        if payment_terms_days is None:
            format_error(
                f"Invalid --payment-terms: '{payment_terms}'. "
                "Use: receipt, net15, net30, or a number of days."
            )
            raise typer.Exit(1)

    client = CrowdTimeClient(require_auth=True, require_org=True)

    payload: dict = {
        "client_id": client_id,
        "date_from": start,
        "date_to": end,
    }
    if group_by:
        payload["group_by"] = group_by
    if tax_rate is not None:
        payload["tax_rate"] = str(tax_rate)
    if notes:
        payload["notes"] = notes
    if terms:
        payload["terms"] = terms
    if payment_terms_days is not None:
        payload["payment_terms_days"] = payment_terms_days

    try:
        data = client.post("/invoices/from-time-entries/", data=payload)

        if output_json:
            print_json(data)
        else:
            inv_number = data.get("invoice_number", data.get("number", ""))
            currency = data.get("currency", "USD")
            total = format_currency(data.get("total_amount", data.get("total", 0)), currency)
            line_items = data.get("line_items", data.get("items", []))
            items_count = len(line_items)

            # Count expense line items
            expense_count = sum(
                1 for item in line_items
                if item.get("line_item_type") == "expense"
                or item.get("type") == "expense"
            )

            msg = (
                f"Invoice {inv_number} created as draft: {total} "
                f"({items_count} line item{'s' if items_count != 1 else ''}, "
                f"period {start} to {end})"
            )
            format_success(msg)
            console.print(f"  ID: {data.get('id', '')}")

            if expense_count:
                console.print(
                    f"  [dim]Includes {expense_count} expense"
                    f"{'s' if expense_count != 1 else ''}.[/dim]"
                )
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command("create-blank")
def create_blank_invoice(
    client_id: str = typer.Option(..., "--client", "-c", help="Client ID."),
    issue_date: str = typer.Option(..., "--issue-date", help="Issue date."),
    due_date: Optional[str] = typer.Option(None, "--due-date", help="Due date (auto-calculated from --payment-terms if omitted)."),
    subject: Optional[str] = typer.Option(None, "--subject", "-s", help="Invoice subject line."),
    payment_terms: Optional[str] = typer.Option(
        None, "--payment-terms",
        help="Payment terms: receipt, net15, net30, or number of days. Auto-calculates due date.",
    ),
    currency: Optional[str] = typer.Option(None, "--currency", help="Currency code (e.g. USD, EUR)."),
    notes: Optional[str] = typer.Option(None, "--notes", "-n", help="Invoice notes."),
    terms: Optional[str] = typer.Option(None, "--terms", help="Payment terms text (e.g. bank account details)."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Create an empty draft invoice for manual line item addition.

    Examples:
        ct invoice create-blank --client <id> --issue-date today
        ct invoice create-blank --client <id> --issue-date 2026-03-15 --payment-terms net30
        ct invoice create-blank --client <id> --issue-date today --due-date 2026-04-15 --currency EUR
        ct invoice create-blank --client <id> --issue-date today --terms "Wire to IBAN XX" --notes "March work"
    """
    try:
        parsed_issue_date = parse_date(issue_date)
        parsed_issue = format_date(parsed_issue_date)
    except ValueError as e:
        format_error(str(e))
        raise typer.Exit(1)

    # Resolve payment terms days
    payment_terms_days: int | None = None
    if payment_terms is not None:
        payment_terms_days = _resolve_payment_terms(payment_terms)
        if payment_terms_days is None:
            format_error(
                f"Invalid --payment-terms: '{payment_terms}'. "
                "Use: receipt, net15, net30, or a number of days."
            )
            raise typer.Exit(1)

    # Resolve due date: explicit --due-date > calculated from --payment-terms > default net30
    parsed_due = None
    if due_date:
        try:
            parsed_due = format_date(parse_date(due_date))
        except ValueError as e:
            format_error(str(e))
            raise typer.Exit(1)
    elif payment_terms_days is not None:
        parsed_due = format_date(parsed_issue_date + timedelta(days=payment_terms_days))
    else:
        # Default to net30
        payment_terms_days = 30
        parsed_due = format_date(parsed_issue_date + timedelta(days=30))

    api_client = CrowdTimeClient(require_auth=True, require_org=True)

    payload: dict = {
        "client": client_id,
        "issue_date": parsed_issue,
        "due_date": parsed_due,
    }
    if subject:
        payload["subject"] = subject
    if currency:
        payload["currency"] = currency
    if notes:
        payload["notes"] = notes
    if terms:
        payload["terms"] = terms
    if payment_terms_days is not None:
        payload["payment_terms_days"] = payment_terms_days

    try:
        data = api_client.post("/invoices/", data=payload)

        if output_json:
            print_json(data)
        else:
            inv_number = data.get("invoice_number", data.get("number", ""))
            format_success(f"Blank invoice {inv_number} created as draft.")
            console.print(f"  ID: {data.get('id', '')}")
            console.print("[dim]Add line items with: ct invoice add-item <invoice-id> ...[/dim]")
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command("update")
def update_invoice(
    invoice_id: str = typer.Argument(..., help="Invoice ID to update (must be draft)."),
    invoice_number: Optional[str] = typer.Option(None, "--number", help="Invoice number (e.g. INV-0078)."),
    subject: Optional[str] = typer.Option(None, "--subject", "-s", help="Invoice subject line."),
    issue_date: Optional[str] = typer.Option(None, "--issue-date", help="Issue date."),
    due_date: Optional[str] = typer.Option(None, "--due-date", help="Due date."),
    notes: Optional[str] = typer.Option(None, "--notes", "-n", help="Invoice notes."),
    terms: Optional[str] = typer.Option(None, "--terms", help="Payment terms text (e.g. bank account details)."),
    footer: Optional[str] = typer.Option(None, "--footer", help="Invoice footer text."),
    currency: Optional[str] = typer.Option(None, "--currency", help="Currency code (e.g. USD, EUR)."),
    tax_rate: Optional[float] = typer.Option(None, "--tax-rate", help="Tax rate percentage (e.g. 21 for 21%)."),
    payment_terms: Optional[str] = typer.Option(
        None, "--payment-terms",
        help="Payment terms: receipt, net15, net30, or number of days.",
    ),
    from_name: Optional[str] = typer.Option(None, "--from-name", help="Issuer/sender name."),
    from_email: Optional[str] = typer.Option(None, "--from-email", help="Issuer/sender email."),
    from_address: Optional[str] = typer.Option(None, "--from-address", help="Issuer/sender address."),
    client_name: Optional[str] = typer.Option(None, "--client-name", help="Bill-to client name."),
    client_email: Optional[str] = typer.Option(None, "--client-email", help="Bill-to client email."),
    client_address: Optional[str] = typer.Option(None, "--client-address", help="Bill-to client address."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Update a draft invoice's fields.

    Only draft invoices can be edited. Once sent, use void + recreate.

    Examples:
        ct invoice update <id> --subject "March 2026 Development"
        ct invoice update <id> --terms "Wire to IBAN XX" --notes "Net 30"
        ct invoice update <id> --tax-rate 21 --due-date 2026-04-15
        ct invoice update <id> --number "INV-0078"
        ct invoice update <id> --from-name "Acme Inc" --from-email "billing@acme.com"
        ct invoice update <id> --client-name "Beta Corp" --client-email "ap@beta.com"
    """
    # Build payload from provided options
    payload: dict = {}

    if invoice_number is not None:
        payload["invoice_number"] = invoice_number
    if subject is not None:
        payload["subject"] = subject
    if notes is not None:
        payload["notes"] = notes
    if terms is not None:
        payload["terms"] = terms
    if footer is not None:
        payload["footer"] = footer
    if currency is not None:
        payload["currency"] = currency
    if tax_rate is not None:
        payload["tax_rate"] = str(tax_rate)
    if from_name is not None:
        payload["from_name"] = from_name
    if from_email is not None:
        payload["from_email"] = from_email
    if from_address is not None:
        payload["from_address"] = from_address
    if client_name is not None:
        payload["client_name"] = client_name
    if client_email is not None:
        payload["client_email"] = client_email
    if client_address is not None:
        payload["client_address"] = client_address

    if issue_date is not None:
        try:
            payload["issue_date"] = format_date(parse_date(issue_date))
        except ValueError as e:
            format_error(str(e))
            raise typer.Exit(1)

    if due_date is not None:
        try:
            payload["due_date"] = format_date(parse_date(due_date))
        except ValueError as e:
            format_error(str(e))
            raise typer.Exit(1)

    if payment_terms is not None:
        days = _resolve_payment_terms(payment_terms)
        if days is None:
            format_error(
                f"Invalid --payment-terms: '{payment_terms}'. "
                "Use: receipt, net15, net30, or a number of days."
            )
            raise typer.Exit(1)
        payload["payment_terms_days"] = days

    if not payload:
        format_error("No fields to update. Provide at least one option.")
        raise typer.Exit(1)

    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.patch(f"/invoices/{invoice_id}/", data=payload)

        if output_json:
            print_json(data)
        else:
            inv_number = data.get("invoice_number", data.get("number", invoice_id))
            fields = ", ".join(payload.keys())
            format_success(f"Invoice {inv_number} updated ({fields}).")
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Invoice '{invoice_id}' not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@app.command("send")
def send_invoice(
    invoice_id: str = typer.Argument(..., help="Invoice ID to send."),
    to: Optional[list[str]] = typer.Option(
        None, "--to",
        help="Contact ID(s) to send to. Repeat for multiple. Default: primary contact.",
    ),
    cc: Optional[list[str]] = typer.Option(
        None, "--cc",
        help="Contact ID(s) to CC. Repeat for multiple.",
    ),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Send an invoice to the client.

    Transitions the invoice from draft to sent status.
    Use --to to specify contact(s) or it defaults to the client's primary contact.
    This action cannot be undone (use void instead).

    Examples:
        ct invoice send <invoice-id>
        ct invoice send <invoice-id> --to <contact-id>
        ct invoice send <invoice-id> --to <contact-id-1> --to <contact-id-2> --cc <contact-id-3>
        ct invoice send <invoice-id> --force
    """
    if not force:
        if not typer.confirm("Send this invoice? This cannot be undone."):
            console.print("[dim]Cancelled.[/dim]")
            return

    client = CrowdTimeClient(require_auth=True, require_org=True)

    payload: dict = {}
    if to:
        payload["contact_ids"] = to
    if cc:
        payload["cc_contact_ids"] = cc

    try:
        data = client.post(f"/invoices/{invoice_id}/send/", data=payload if payload else None)

        if output_json:
            print_json(data)
        else:
            inv_number = data.get("invoice_number", data.get("number", invoice_id))
            recipients = data.get("recipient_emails", [])
            cc_list = data.get("cc_emails", [])
            msg = f"Invoice {inv_number} sent"
            if recipients:
                msg += f" to {', '.join(recipients)}"
            if cc_list:
                msg += f" (CC: {', '.join(cc_list)})"
            format_success(msg)
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Invoice '{invoice_id}' not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@app.command("void")
def void_invoice(
    invoice_id: str = typer.Argument(..., help="Invoice ID to void."),
    reason: str = typer.Option(..., "--reason", "-r", help="Reason for voiding (required)."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Void an invoice.

    Marks the invoice as void with a reason. Voided invoices
    cannot be edited or sent. Time entries are unlinked.

    Examples:
        ct invoice void <invoice-id> --reason "Duplicate invoice"
        ct invoice void <invoice-id> -r "Client requested cancellation"
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.post(f"/invoices/{invoice_id}/void/", data={"void_reason": reason})

        if output_json:
            print_json(data)
        else:
            inv_number = data.get("invoice_number", data.get("number", invoice_id))
            format_success(f"Invoice {inv_number} voided.")
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Invoice '{invoice_id}' not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@app.command("pay")
def record_payment(
    invoice_id: str = typer.Argument(..., help="Invoice ID to record payment for."),
    amount: str = typer.Option(..., "--amount", "-a", help="Payment amount."),
    payment_date: Optional[str] = typer.Option(
        None, "--date", "-d", help="Payment date (default: today)."
    ),
    method: Optional[str] = typer.Option(
        None, "--method", "-m", help="Payment method (e.g. bank_transfer, credit_card, check, cash, other)."
    ),
    reference: Optional[str] = typer.Option(
        None, "--reference", "-r", help="Payment reference number."
    ),
    notes: Optional[str] = typer.Option(None, "--notes", "-n", help="Payment notes."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Record a payment against an invoice.

    Examples:
        ct invoice pay <invoice-id> --amount 1500.00
        ct invoice pay <invoice-id> --amount 500 --date 2026-03-10 --method bank_transfer --reference "TXN-123"
    """
    try:
        parsed_amount = Decimal(amount)
    except (ValueError, ArithmeticError):
        format_error(f"Invalid amount: '{amount}'. Provide a numeric value.")
        raise typer.Exit(1)
    if parsed_amount <= 0:
        format_error("Amount must be greater than zero.")
        raise typer.Exit(1)

    parsed_date = None
    if payment_date:
        try:
            parsed_date = format_date(parse_date(payment_date))
        except ValueError as e:
            format_error(str(e))
            raise typer.Exit(1)

    client = CrowdTimeClient(require_auth=True, require_org=True)

    payload: dict = {"amount": str(parsed_amount)}
    if parsed_date:
        payload["payment_date"] = parsed_date
    if method:
        payload["payment_method"] = method
    if reference:
        payload["reference"] = reference
    if notes:
        payload["notes"] = notes

    try:
        data = client.post(f"/invoices/{invoice_id}/payments/", data=payload)

        if output_json:
            print_json(data)
        else:
            remaining = data.get("amount_due", data.get("remaining", None))
            inv_status = data.get("invoice_status", data.get("status", ""))
            currency = data.get("currency", "USD")
            msg = f"Payment of {format_currency(parsed_amount, currency)} recorded."
            if remaining is not None:
                msg += f" Remaining: {format_currency(remaining, currency)}."
            if inv_status == "paid":
                msg += " Invoice is now fully paid."
            format_success(msg)
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Invoice '{invoice_id}' not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@app.command("pdf")
def download_pdf(
    invoice_id: str = typer.Argument(..., help="Invoice ID."),
    output: Optional[str] = typer.Option(
        None, "--output", "-o", help="Output file path (default: invoice-<number>.pdf)."
    ),
) -> None:
    """Download invoice as PDF.

    Examples:
        ct invoice pdf <invoice-id>
        ct invoice pdf <invoice-id> --output ~/invoices/march-2026.pdf
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        # Get invoice details first for the filename
        invoice_data = client.get(f"/invoices/{invoice_id}/")
        inv_number = invoice_data.get("invoice_number", invoice_data.get("number", invoice_id))

        # Download the PDF
        pdf_data = client.get(f"/invoices/{invoice_id}/pdf/", raw=True)

        if output:
            file_path = Path(output).expanduser()
        else:
            safe_number = inv_number.replace("/", "-").replace("\\", "-")
            file_path = Path(f"invoice-{safe_number}.pdf")

        # Ensure parent directory exists
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_bytes(pdf_data if isinstance(pdf_data, bytes) else pdf_data.encode())

        format_success(f"Invoice PDF saved to {file_path}")
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Invoice '{invoice_id}' not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)
    except OSError as e:
        format_error(f"Could not write file: {e}")
        raise typer.Exit(1)


@app.command("duplicate")
def duplicate_invoice(
    invoice_id: str = typer.Argument(..., help="Invoice ID to duplicate."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Duplicate an existing invoice as a new draft.

    Creates a copy of the invoice with new dates and number,
    preserving line items.

    Examples:
        ct invoice duplicate <invoice-id>
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.post(f"/invoices/{invoice_id}/duplicate/")

        if output_json:
            print_json(data)
        else:
            new_number = data.get("invoice_number", data.get("number", ""))
            format_success(f"Invoice duplicated as {new_number} (draft).")
            console.print(f"  ID: {data.get('id', '')}")
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Invoice '{invoice_id}' not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@app.command("add-item")
def add_line_item(
    invoice_id: str = typer.Argument(..., help="Invoice ID to add line item to."),
    description: str = typer.Option(..., "--description", "--desc", "-d", help="Line item description."),
    quantity: str = typer.Option(..., "--qty", "-q", help="Quantity (e.g. hours)."),
    rate: str = typer.Option(..., "--rate", "-r", help="Unit rate."),
    taxable: Optional[bool] = typer.Option(None, "--taxable/--no-taxable", help="Whether item is taxable."),
    discount_type: Optional[str] = typer.Option(
        None, "--discount-type",
        help="Discount type: fixed, percent, or hours.",
    ),
    discount_value: Optional[str] = typer.Option(
        None, "--discount-value",
        help="Discount value (amount, percentage, or hours depending on type).",
    ),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Add a line item to a draft invoice.

    Supports per-line discounts: fixed amount, percentage, or hours deducted.

    Examples:
        ct invoice add-item <invoice-id> --desc "Development work" --qty 10 --rate 150
        ct invoice add-item <invoice-id> --desc "Consulting" --qty 5 --rate 200 --taxable
        ct invoice add-item <invoice-id> --desc "Design" --qty 20 --rate 120 --discount-type hours --discount-value 2
        ct invoice add-item <invoice-id> --desc "Support" --qty 10 --rate 100 --discount-type percent --discount-value 10
    """
    try:
        parsed_qty = Decimal(quantity)
        parsed_rate = Decimal(rate)
    except (ValueError, ArithmeticError):
        format_error("Invalid quantity or rate. Provide numeric values.")
        raise typer.Exit(1)

    if discount_type and discount_type not in ("fixed", "percent", "hours"):
        format_error("Invalid discount type. Choose from: fixed, percent, hours.")
        raise typer.Exit(1)

    client = CrowdTimeClient(require_auth=True, require_org=True)

    payload: dict = {
        "description": description,
        "quantity": str(parsed_qty),
        "unit_price": str(parsed_rate),
    }
    if taxable is not None:
        payload["is_taxable"] = taxable
    if discount_type:
        payload["discount_type"] = discount_type
    if discount_value:
        payload["discount_value"] = discount_value

    try:
        data = client.post(f"/invoices/{invoice_id}/line-items/", data=payload)

        if output_json:
            print_json(data)
        else:
            amount = Decimal(str(data.get("amount", parsed_qty * parsed_rate)))
            discount_amt = Decimal(str(data.get("discount_amount", 0)))
            msg = (
                f"Line item added: {description} "
                f"({parsed_qty} x {format_currency(parsed_rate)} = {format_currency(amount)})"
            )
            if discount_amt > 0:
                msg += f" [dim](discount: {format_currency(discount_amt)})[/dim]"
            format_success(msg)
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Invoice '{invoice_id}' not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


# ─── Recurring Templates ─────────────────────────────────────────


@recurring_app.callback(invoke_without_command=True)
def recurring_default(ctx: typer.Context) -> None:
    """Manage recurring invoice templates."""
    if ctx.invoked_subcommand is None:
        list_recurring()


@recurring_app.command("list")
def list_recurring(
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """List recurring invoice templates.

    Examples:
        ct invoice recurring list
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.get("/invoices/recurring-templates/")
        results = extract_results(data)

        if output_json:
            print_json(results)
        else:
            if not results:
                console.print("[dim]No recurring templates found.[/dim]")
                return

            table = Table(show_header=True, header_style="bold")
            table.add_column("ID", style="dim")
            table.add_column("Name", width=20)
            table.add_column("Client", width=18)
            table.add_column("Schedule", width=14)
            table.add_column("Active", width=8, justify="center")
            table.add_column("Next Run", width=12)
            table.add_column("Generated", justify="right", width=10)

            for tmpl in results:
                is_active = tmpl.get("is_active", tmpl.get("active", False))
                active_label = "[green]Yes[/green]" if is_active else "[dim]No[/dim]"

                table.add_row(
                    str(tmpl.get("id", "")),
                    tmpl.get("name", tmpl.get("title", "")),
                    tmpl.get("client_name", ""),
                    tmpl.get("schedule", tmpl.get("frequency", "")),
                    active_label,
                    tmpl.get("next_run_date", tmpl.get("next_run", "")) or "",
                    str(tmpl.get("invoices_generated", tmpl.get("generated_count", 0))),
                )

            console.print(table)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@recurring_app.command("show")
def show_recurring(
    template_id: str = typer.Argument(..., help="Recurring template ID."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Show details of a recurring invoice template.

    Examples:
        ct invoice recurring show <template-id>
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.get(f"/invoices/recurring-templates/{template_id}/")

        if output_json:
            print_json(data)
        else:
            console.print()
            console.print(f"[bold]{data.get('name', '')}[/bold]")
            console.print(f"  Client:          {data.get('client_name', '')}")
            console.print(f"  Schedule:        {data.get('schedule', '')}")
            is_active = data.get("is_active", False)
            active_label = "[green]Active[/green]" if is_active else "[dim]Inactive[/dim]"
            console.print(f"  Status:          {active_label}")
            console.print(f"  Currency:        {data.get('currency', 'USD')}")
            console.print(f"  Payment Terms:   {data.get('payment_terms_days', 30)} days")
            console.print(f"  Next Run:        {data.get('next_run_date', '') or 'Not scheduled'}")
            console.print(f"  Last Run:        {data.get('last_run_date', '') or 'Never'}")
            console.print(f"  Total Generated: {data.get('total_generated', 0)}")
            console.print(f"  Auto-send:       {'Yes' if data.get('auto_send') else 'No'}")
            console.print(f"  Pull Entries:    {'Yes' if data.get('pull_time_entries') else 'No'}")
            console.print(f"  Group By:        {data.get('group_by', 'project')}")

            line_items = data.get("line_items", [])
            if line_items:
                console.print()
                console.print("[bold]Line Items:[/bold]")
                for item in line_items:
                    qty = item.get("quantity", 0)
                    price = item.get("unit_price", 0)
                    console.print(f"  • {item.get('description', '')} — {qty} × {format_currency(Decimal(str(price)), data.get('currency', 'USD'))}")

            if data.get("notes"):
                console.print()
                console.print(f"  Notes: {data['notes']}")
            console.print()
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Recurring template '{template_id}' not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@recurring_app.command("create")
def create_recurring(
    name: str = typer.Option(..., "--name", "-n", help="Template name."),
    client_id: str = typer.Option(..., "--client", "-c", help="Client ID."),
    schedule: str = typer.Option(..., "--schedule", "-s", help="Schedule: weekly, biweekly, monthly, quarterly."),
    next_run: str = typer.Option(..., "--next-run", help="Next run date (YYYY-MM-DD)."),
    currency: Optional[str] = typer.Option(None, "--currency", help="Currency code (e.g. USD)."),
    payment_terms: Optional[int] = typer.Option(None, "--payment-terms", help="Payment terms in days."),
    auto_send: bool = typer.Option(False, "--auto-send", help="Automatically send generated invoices."),
    pull_entries: bool = typer.Option(True, "--pull-entries/--no-pull-entries", help="Pull time entries into invoice."),
    group_by: Optional[str] = typer.Option(None, "--group-by", "-g", help="Group by: project, task, user, date, none."),
    notes: Optional[str] = typer.Option(None, "--notes", help="Invoice notes."),
    terms: Optional[str] = typer.Option(None, "--terms", help="Payment terms text."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Create a recurring invoice template.

    Examples:
        ct invoice recurring create --name "Monthly Acme" --client <id> --schedule monthly --next-run 2026-05-01
        ct invoice recurring create --name "Weekly Retainer" --client <id> --schedule weekly --next-run 2026-04-07 --auto-send
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    payload: dict = {
        "name": name,
        "client": client_id,
        "schedule": schedule,
        "next_run_date": next_run,
        "pull_time_entries": pull_entries,
    }
    if currency:
        payload["currency"] = currency
    if payment_terms is not None:
        payload["payment_terms_days"] = payment_terms
    if auto_send:
        payload["auto_send"] = True
    if group_by:
        payload["group_by"] = group_by
    if notes:
        payload["notes"] = notes
    if terms:
        payload["terms"] = terms

    try:
        data = client.post("/invoices/recurring-templates/", data=payload)

        if output_json:
            print_json(data)
        else:
            format_success(
                f"Recurring template '{data.get('name')}' created "
                f"(ID: {data.get('id')}, schedule: {data.get('schedule')}, "
                f"next run: {data.get('next_run_date')})"
            )
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@recurring_app.command("update")
def update_recurring(
    template_id: str = typer.Argument(..., help="Recurring template ID."),
    name: Optional[str] = typer.Option(None, "--name", "-n", help="Template name."),
    schedule: Optional[str] = typer.Option(None, "--schedule", "-s", help="Schedule: weekly, biweekly, monthly, quarterly."),
    next_run: Optional[str] = typer.Option(None, "--next-run", help="Next run date (YYYY-MM-DD)."),
    active: Optional[bool] = typer.Option(None, "--active/--inactive", help="Activate or deactivate."),
    auto_send: Optional[bool] = typer.Option(None, "--auto-send/--no-auto-send", help="Auto-send invoices."),
    payment_terms: Optional[int] = typer.Option(None, "--payment-terms", help="Payment terms in days."),
    group_by: Optional[str] = typer.Option(None, "--group-by", "-g", help="Group by: project, task, user, date, none."),
    notes: Optional[str] = typer.Option(None, "--notes", help="Invoice notes."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Update a recurring invoice template.

    Examples:
        ct invoice recurring update <id> --schedule monthly
        ct invoice recurring update <id> --inactive
        ct invoice recurring update <id> --next-run 2026-06-01 --auto-send
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    payload: dict = {}
    if name is not None:
        payload["name"] = name
    if schedule is not None:
        payload["schedule"] = schedule
    if next_run is not None:
        payload["next_run_date"] = next_run
    if active is not None:
        payload["is_active"] = active
    if auto_send is not None:
        payload["auto_send"] = auto_send
    if payment_terms is not None:
        payload["payment_terms_days"] = payment_terms
    if group_by is not None:
        payload["group_by"] = group_by
    if notes is not None:
        payload["notes"] = notes

    if not payload:
        format_error("No changes specified. Use --help to see available options.")
        raise typer.Exit(1)

    try:
        data = client.patch(f"/invoices/recurring-templates/{template_id}/", data=payload)

        if output_json:
            print_json(data)
        else:
            format_success(f"Recurring template '{data.get('name')}' updated.")
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Recurring template '{template_id}' not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@recurring_app.command("delete")
def delete_recurring(
    template_id: str = typer.Argument(..., help="Recurring template ID."),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation."),
) -> None:
    """Delete a recurring invoice template.

    Examples:
        ct invoice recurring delete <template-id>
        ct invoice recurring delete <template-id> --force
    """
    if not force:
        if not typer.confirm(f"Delete recurring template '{template_id}'?"):
            console.print("[dim]Cancelled.[/dim]")
            return

    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        client.delete(f"/invoices/recurring-templates/{template_id}/")
        format_success(f"Recurring template '{template_id}' deleted.")
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Recurring template '{template_id}' not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@recurring_app.command("generate-now")
def generate_now(
    template_id: str = typer.Argument(..., help="Recurring template ID."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Manually generate an invoice from a recurring template.

    Examples:
        ct invoice recurring generate-now <template-id>
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.post(f"/invoices/recurring-templates/{template_id}/generate-now/")

        if output_json:
            print_json(data)
        else:
            format_success(data.get("detail", "Invoice generated successfully."))
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Recurring template '{template_id}' not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


# ─── Retainers ────────────────────────────────────────────────────


@retainer_app.callback(invoke_without_command=True)
def retainer_default(ctx: typer.Context) -> None:
    """Manage retainer agreements."""
    if ctx.invoked_subcommand is None:
        list_retainers()


@retainer_app.command("list")
def list_retainers(
    status: Optional[str] = typer.Option(
        None, "--status", "-s", help="Filter by status: pending, active, paused, completed, cancelled."
    ),
    client_id: Optional[str] = typer.Option(
        None, "--client", "-c", help="Filter by client ID."
    ),
    search: Optional[str] = typer.Option(
        None, "--search", "-q", help="Search by retainer name or client name."
    ),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """List retainer agreements.

    Examples:
        ct invoice retainer list
        ct invoice retainer list --status active
        ct invoice retainer list --client <client-id>
        ct invoice retainer list --search "Acme"
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    params: dict = {}
    if status:
        params["status"] = status
    if client_id:
        params["client"] = client_id
    if search:
        params["search"] = search

    try:
        data = client.get("/invoices/retainers/", params=params or None)
        results = extract_results(data)

        if output_json:
            print_json(results)
        else:
            if not results:
                console.print("[dim]No retainers found.[/dim]")
                return

            table = Table(show_header=True, header_style="bold")
            table.add_column("ID", style="dim")
            table.add_column("Name", width=20)
            table.add_column("Client", width=18)
            table.add_column("Monthly", justify="right", width=12)
            table.add_column("Balance", justify="right", width=12)
            table.add_column("Status", width=10)

            for ret in results:
                ret_status = ret.get("status", "active")
                style = "green" if ret_status == "active" else "dim"
                currency = ret.get("currency", "USD")
                balance = Decimal(str(ret.get("balance", 0)))
                monthly = Decimal(str(ret.get("monthly_amount", ret.get("monthly", 0)) or 0))
                # Color balance: dim for inactive/paused, red if ≤ 1 month, yellow ≤ 2 months, green otherwise
                if ret_status != "active":
                    balance_style = "dim"
                elif monthly > 0 and balance <= monthly:
                    balance_style = "red"
                elif monthly > 0 and balance <= monthly * 2:
                    balance_style = "yellow"
                else:
                    balance_style = "green"

                table.add_row(
                    str(ret.get("id", "")),
                    ret.get("name", ret.get("title", "")),
                    ret.get("client_name", ""),
                    format_currency(monthly, currency),
                    f"[{balance_style}]{format_currency(balance, currency)}[/{balance_style}]",
                    f"[{style}]{ret_status.capitalize()}[/{style}]",
                )

            console.print(table)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@retainer_app.command("show")
def show_retainer(
    retainer_id: str = typer.Argument(..., help="Retainer ID."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Show retainer details including balance.

    Examples:
        ct invoice retainer show <retainer-id>
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.get(f"/invoices/retainers/{retainer_id}/")

        if output_json:
            print_json(data)
        else:
            currency = data.get("currency", "USD")
            status = data.get("status", "active")
            style = "green" if status == "active" else "dim"

            console.print()
            console.print(f"[bold]{data.get('name', '')}[/bold]")
            console.print(f"  ID:              {data.get('id', '')}")
            console.print(f"  Client:          {data.get('client_name', '')}")
            console.print(f"  Status:          [{style}]{status.capitalize()}[/{style}]")
            console.print(f"  Monthly Amount:  {format_currency(data.get('monthly_amount', 0), currency)}")
            console.print(f"  Included Hours:  {data.get('included_hours', 0)}h")
            console.print(f"  Overage Rate:    {format_currency(data.get('overage_rate', 0), currency)}/h")
            console.print(f"  Start Date:      {data.get('start_date', '')}")
            if data.get("end_date"):
                console.print(f"  End Date:        {data['end_date']}")

            # Balance info
            console.print()
            console.print("[bold]Balance[/bold]")
            console.print(f"  Total Deposited: {format_currency(data.get('total_deposited', 0), currency)}")
            console.print(f"  Total Withdrawn: {format_currency(data.get('total_withdrawn', 0), currency)}")
            balance = Decimal(str(data.get('balance', 0)))
            console.print(f"  [bold]Available:     {format_currency(balance, currency)}[/bold]")

            # Depletion forecast based on withdrawal history
            if balance > 0:
                try:
                    withdrawals_data = client.get(f"/invoices/retainers/{retainer_id}/withdrawals/")
                    withdrawals = extract_results(withdrawals_data)
                    active_wds = [
                        w for w in withdrawals
                        if not w.get("reversed_at") and w.get("created_at")
                    ]
                    if len(active_wds) >= 2:
                        dates = sorted(
                            datetime_type.fromisoformat(w["created_at"].replace("Z", "+00:00"))
                            for w in active_wds
                        )
                        span_days = max((dates[-1] - dates[0]).days, 1)
                        total_wd = sum(Decimal(str(w.get("amount", 0))) for w in active_wds)
                        burn_per_week = total_wd / Decimal(str(span_days)) * 7
                        if burn_per_week > 0:
                            weeks_left = balance / burn_per_week
                            depletion_date = date_type.today() + timedelta(weeks=float(weeks_left))
                            console.print()
                            console.print("[bold]Forecast[/bold]")
                            console.print(f"  Burn Rate:       {format_currency(burn_per_week, currency)}/week")
                            console.print(f"  Weeks Left:      {float(weeks_left):.1f}")
                            if weeks_left <= 4:
                                console.print(f"  Depleted By:     [red]{depletion_date.isoformat()}[/red]")
                            else:
                                console.print(f"  Depleted By:     {depletion_date.isoformat()}")
                except APIError:
                    pass  # Silently skip forecast if withdrawals unavailable

            console.print()
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Retainer '{retainer_id}' not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@retainer_app.command("withdraw")
def retainer_withdraw(
    retainer_id: str = typer.Argument(..., help="Retainer ID to withdraw from."),
    invoice_id: str = typer.Option(..., "--invoice", "-i", help="Target invoice ID to apply credit to."),
    amount: str = typer.Option(..., "--amount", "-a", help="Amount to withdraw."),
    notes: Optional[str] = typer.Option(None, "--notes", "-n", help="Notes for the withdrawal."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Withdraw from retainer balance to pay an invoice.

    Applies retainer credit to a standard invoice. The amount is deducted
    from the retainer balance and applied as a payment on the target invoice.

    Examples:
        ct invoice retainer withdraw <retainer-id> --invoice <invoice-id> --amount 500
        ct invoice retainer withdraw <retainer-id> -i <invoice-id> -a 1000 -n "March credit"
    """
    try:
        parsed_amount = Decimal(amount)
    except (ValueError, ArithmeticError):
        format_error(f"Invalid amount: '{amount}'. Provide a numeric value.")
        raise typer.Exit(1)
    if parsed_amount <= 0:
        format_error("Amount must be greater than zero.")
        raise typer.Exit(1)

    client = CrowdTimeClient(require_auth=True, require_org=True)

    payload: dict = {
        "invoice_id": invoice_id,
        "amount": str(parsed_amount),
    }
    if notes:
        payload["notes"] = notes

    try:
        data = client.post(f"/invoices/retainers/{retainer_id}/withdraw/", data=payload)

        if output_json:
            print_json(data)
        else:
            inv_number = data.get("invoice_number", invoice_id)
            retainer_name = data.get("retainer_name", retainer_id)
            currency = data.get("currency", "USD")
            format_success(
                f"Withdrew {format_currency(parsed_amount, currency)} from retainer "
                f'"{retainer_name}" and applied to invoice {inv_number}.'
            )
    except APIError as e:
        if e.status_code == 404:
            format_error("Retainer or invoice not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@retainer_app.command("withdrawals")
def list_withdrawals(
    retainer_id: str = typer.Argument(..., help="Retainer ID."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """List all withdrawals for a retainer.

    Examples:
        ct invoice retainer withdrawals <retainer-id>
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        # Fetch retainer to get currency
        retainer_data = client.get(f"/invoices/retainers/{retainer_id}/")
        currency = retainer_data.get("currency", "USD")

        data = client.get(f"/invoices/retainers/{retainer_id}/withdrawals/")
        results = extract_results(data)

        if output_json:
            print_json(results)
        else:
            if not results:
                console.print("[dim]No withdrawals found for this retainer.[/dim]")
                return

            table = Table(show_header=True, header_style="bold")
            table.add_column("ID", style="dim")
            table.add_column("Invoice", width=14)
            table.add_column("Amount", justify="right", width=12)
            table.add_column("Date", width=12)
            table.add_column("Status", width=10)
            table.add_column("Notes", width=25)

            for wd in results:
                is_reversed = wd.get("reversed_at") is not None
                status_label = "[red]Reversed[/red]" if is_reversed else "[green]Active[/green]"
                created = format_iso_date(wd.get("created_at"))

                table.add_row(
                    str(wd.get("id", "")),
                    wd.get("invoice_number", ""),
                    format_currency(wd.get("amount", 0), currency),
                    created,
                    status_label,
                    wd.get("notes", "") or "",
                )

            console.print(table)
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Retainer '{retainer_id}' not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@retainer_app.command("reverse-withdrawal")
def reverse_withdrawal(
    retainer_id: str = typer.Argument(..., help="Retainer ID."),
    withdrawal_id: str = typer.Option(..., "--withdrawal", "-w", help="Withdrawal ID to reverse."),
    reason: str = typer.Option(..., "--reason", "-r", help="Reason for reversal (required)."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Reverse a retainer withdrawal.

    Returns the amount back to the retainer balance and adjusts the
    target invoice's payment accordingly.

    Examples:
        ct invoice retainer reverse-withdrawal <retainer-id> --withdrawal <id> --reason "Client renegotiation"
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.post(
            f"/invoices/retainers/{retainer_id}/withdrawals/{withdrawal_id}/reverse/",
            data={"reason": reason},
        )

        if output_json:
            print_json(data)
        else:
            currency = data.get("currency", "USD")
            format_success(
                f"Withdrawal reversed. {format_currency(data.get('amount', 0), currency)} "
                f"returned to retainer balance."
            )
    except APIError as e:
        if e.status_code == 404:
            format_error("Retainer or withdrawal not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


# ─── Tax Rates ───────────────────────────────────────────────────────

tax_app = typer.Typer(name="tax-rates", help="Manage organization tax rates.")
app.add_typer(tax_app, name="tax-rates")


@tax_app.callback(invoke_without_command=True)
def tax_rates_list(
    ctx: typer.Context,
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """List tax rates for the organization.

    Examples:
        ct invoice tax-rates
        ct invoice tax-rates --json
    """
    if ctx.invoked_subcommand is not None:
        return

    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.get("/invoices/tax-rates/")
        results = extract_results(data)

        if output_json:
            print_json(data)
        else:
            if not results:
                console.print("[dim]No tax rates configured.[/dim]")
                return

            table = Table(title="Tax Rates")
            table.add_column("ID", style="dim")
            table.add_column("Name", style="bold")
            table.add_column("Rate %", justify="right")
            table.add_column("Default")
            table.add_column("Active")

            for tr in results:
                is_default = "[green]Yes[/green]" if tr.get("is_default") else ""
                is_active = "[green]Yes[/green]" if tr.get("is_active", True) else "[dim]No[/dim]"
                table.add_row(
                    str(tr.get("id", "")),
                    tr.get("name", ""),
                    f"{tr.get('rate', 0)}%",
                    is_default,
                    is_active,
                )

            console.print(table)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@tax_app.command("create")
def create_tax_rate(
    name: str = typer.Option(..., "--name", "-n", help="Tax rate name (e.g. 'VAT', 'Sales Tax')."),
    rate: str = typer.Option(..., "--rate", "-r", help="Tax rate as percentage (e.g. 21.0)."),
    default: bool = typer.Option(False, "--default", "-d", help="Set as default tax rate for new invoices."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Create a new tax rate for the organization.

    Examples:
        ct invoice tax-rates create --name "VAT" --rate 21.0
        ct invoice tax-rates create --name "Sales Tax" --rate 8.25 --default
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    payload: dict = {"name": name, "rate": rate}
    if default:
        payload["is_default"] = True

    try:
        data = client.post("/invoices/tax-rates/", data=payload)

        if output_json:
            print_json(data)
        else:
            format_success(f"Tax rate '{data.get('name', name)}' created at {data.get('rate', rate)}%.")
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@tax_app.command("update")
def update_tax_rate(
    tax_rate_id: str = typer.Argument(..., help="Tax rate ID to update."),
    name: Optional[str] = typer.Option(None, "--name", "-n", help="New name."),
    rate: Optional[str] = typer.Option(None, "--rate", "-r", help="New rate percentage (e.g. 21.0)."),
    default: Optional[bool] = typer.Option(None, "--default/--no-default", help="Set or unset as default tax rate."),
    active: Optional[bool] = typer.Option(None, "--active/--no-active", help="Activate or deactivate."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Update an existing tax rate.

    Examples:
        ct invoice tax-rates update <id> --rate 22.0
        ct invoice tax-rates update <id> --name "VAT 2026" --default
        ct invoice tax-rates update <id> --no-active
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    payload: dict = {}
    if name is not None:
        payload["name"] = name
    if rate is not None:
        payload["rate"] = rate
    if default is not None:
        payload["is_default"] = default
    if active is not None:
        payload["is_active"] = active

    if not payload:
        format_error("No fields to update. Use --name, --rate, --default, or --active.")
        raise typer.Exit(1)

    try:
        data = client.patch(f"/invoices/tax-rates/{tax_rate_id}/", data=payload)

        if output_json:
            print_json(data)
        else:
            format_success(f"Tax rate '{data.get('name', '')}' updated ({data.get('rate', '')}%).")
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@tax_app.command("delete")
def delete_tax_rate(
    tax_rate_id: str = typer.Argument(..., help="Tax rate ID to delete."),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation prompt."),
) -> None:
    """Delete a tax rate.

    Deleting a tax rate does not affect existing invoices that use it.

    Examples:
        ct invoice tax-rates delete <id>
        ct invoice tax-rates delete <id> --force
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    if not force:
        if not typer.confirm(f"Delete tax rate {tax_rate_id}?"):
            console.print("[dim]Cancelled.[/dim]")
            raise typer.Exit(0)

    try:
        client.delete(f"/invoices/tax-rates/{tax_rate_id}/")
        format_success("Tax rate deleted.")
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


# ─── Uninvoiced Entries ────────────��─────────────────────────────────


@app.command("uninvoiced")
def uninvoiced_entries(
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Show uninvoiced billable entries grouped by client.

    Useful for reviewing what work is ready to bill before creating invoices.

    Examples:
        ct invoice uninvoiced
        ct invoice uninvoiced --json
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.get("/invoices/uninvoiced-entries/")
        results = extract_results(data)

        if output_json:
            print_json(data)
        else:
            if not results:
                console.print("[dim]No uninvoiced billable entries found.[/dim]")
                return

            table = Table(title="Uninvoiced Billable Entries")
            table.add_column("Client", style="bold")
            table.add_column("Entries", justify="right")
            table.add_column("Hours", justify="right")
            table.add_column("Amount", justify="right", style="green")
            table.add_column("Client ID", style="dim")

            total_entries = 0
            total_hours = Decimal("0")
            total_amount = Decimal("0")

            for row in results:
                hours = Decimal(str(row.get("total_hours", 0)))
                amount = Decimal(str(row.get("total_amount", 0)))
                count = row.get("entry_count", 0)
                total_entries += count
                total_hours += hours
                total_amount += amount

                table.add_row(
                    row.get("client_name", "Unknown"),
                    str(count),
                    f"{hours:.1f}",
                    format_currency(amount),
                    str(row.get("client_id", "")),
                )

            table.add_section()
            table.add_row(
                "[bold]Total[/bold]",
                f"[bold]{total_entries}[/bold]",
                f"[bold]{total_hours:.1f}[/bold]",
                f"[bold]{format_currency(total_amount)}[/bold]",
                "",
            )

            console.print(table)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


# ─── Line Item Management ────────────────────────────────────────────


@app.command("update-item")
def update_line_item(
    invoice_id: str = typer.Argument(..., help="Invoice ID."),
    item_id: str = typer.Argument(..., help="Line item ID."),
    description: Optional[str] = typer.Option(None, "--description", "-d", help="Item description."),
    quantity: Optional[str] = typer.Option(None, "--quantity", "-q", help="Quantity (e.g. hours)."),
    unit_price: Optional[str] = typer.Option(None, "--unit-price", "-p", help="Unit price."),
    discount_type: Optional[str] = typer.Option(None, "--discount-type", help="Discount type: fixed, percent, hours."),
    discount_value: Optional[str] = typer.Option(None, "--discount-value", help="Discount value."),
    taxable: Optional[bool] = typer.Option(None, "--taxable/--no-taxable", help="Whether this item is taxable."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Update a line item on a draft invoice.

    Examples:
        ct invoice update-item <invoice-id> <item-id> --quantity 10 --unit-price 150
        ct invoice update-item <invoice-id> <item-id> --description "Updated scope"
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    payload: dict = {}
    if description is not None:
        payload["description"] = description
    if quantity is not None:
        payload["quantity"] = quantity
    if unit_price is not None:
        payload["unit_price"] = unit_price
    if discount_type is not None:
        payload["discount_type"] = discount_type
    if discount_value is not None:
        payload["discount_value"] = discount_value
    if taxable is not None:
        payload["is_taxable"] = taxable

    if not payload:
        format_error("No fields to update. Use --description, --quantity, --unit-price, etc.")
        raise typer.Exit(1)

    try:
        data = client.patch(
            f"/invoices/{invoice_id}/line-items/{item_id}/",
            data=payload,
        )

        if output_json:
            print_json(data)
        else:
            desc = data.get("description", "")[:50]
            format_success(f"Line item updated: {desc}")
    except APIError as e:
        if e.status_code == 404:
            format_error("Invoice or line item not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@app.command("remove-item")
def remove_line_item(
    invoice_id: str = typer.Argument(..., help="Invoice ID."),
    item_id: str = typer.Argument(..., help="Line item ID to remove."),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation."),
) -> None:
    """Remove a line item from a draft invoice.

    Examples:
        ct invoice remove-item <invoice-id> <item-id>
        ct invoice remove-item <invoice-id> <item-id> --force
    """
    if not force:
        confirm = typer.confirm("Remove this line item from the invoice?")
        if not confirm:
            console.print("[dim]Cancelled.[/dim]")
            raise typer.Exit(0)

    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        client.delete(f"/invoices/{invoice_id}/line-items/{item_id}/")
        format_success("Line item removed.")
    except APIError as e:
        if e.status_code == 404:
            format_error("Invoice or line item not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)
