"""Expense commands: list, create, edit, delete, categories, add-category."""

from __future__ import annotations

from datetime import date as date_type
from decimal import Decimal
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from ..client import APIError, CrowdTimeClient
from ..formatters import extract_results, format_currency, format_error, format_success, print_json
from ..utils import format_date, format_iso_date, parse_date

app = typer.Typer(name="expense", help="Manage expenses.")
console = Console()


# ─── Helpers ──────────────────────────────────────────────────────


def _print_expenses_table(expenses: list[dict]) -> None:
    """Print expenses in a Rich table."""
    if not expenses:
        console.print("[dim]No expenses found.[/dim]")
        console.print("Run [bold]ct expense create[/bold] to log an expense.")
        return

    table = Table(show_header=True, header_style="bold")
    table.add_column("ID", style="dim")
    table.add_column("Date", width=12)
    table.add_column("Description", width=25)
    table.add_column("Category", width=14)
    table.add_column("Project", style="cyan", width=15)
    table.add_column("Vendor", width=14)
    table.add_column("Amount", justify="right", width=12)
    table.add_column("$", justify="center", width=3)
    table.add_column("Inv", justify="center", width=4)

    total = Decimal("0")

    for exp in expenses:
        amount = exp.get("amount", 0)
        try:
            total += Decimal(str(amount))
        except (ValueError, ArithmeticError):
            pass

        is_billable = exp.get("is_billable", False)
        is_invoiced = exp.get("is_invoiced", False)

        table.add_row(
            str(exp.get("id", "")),
            exp.get("date", ""),
            exp.get("description", ""),
            exp.get("category_name", exp.get("category", "")) or "",
            exp.get("project_name", exp.get("project", "")) or "",
            exp.get("vendor", "") or "",
            format_currency(amount),
            "[green]$[/green]" if is_billable else "",
            "[blue]Y[/blue]" if is_invoiced else "",
        )

    console.print(table)
    console.print(f"\n[bold]Total:[/bold] {format_currency(total)} ({len(expenses)} expenses)")


# ─── Commands ─────────────────────────────────────────────────────


@app.callback(invoke_without_command=True)
def expense_default(ctx: typer.Context) -> None:
    """Manage expenses."""
    if ctx.invoked_subcommand is None:
        list_expenses()


@app.command("list")
def list_expenses(
    from_date: Optional[str] = typer.Option(None, "--from", help="Start date filter (YYYY-MM-DD)."),
    to_date: Optional[str] = typer.Option(None, "--to", help="End date filter (YYYY-MM-DD)."),
    project: Optional[str] = typer.Option(None, "--project", "-p", help="Filter by project slug or ID."),
    category: Optional[str] = typer.Option(None, "--category", "-c", help="Filter by category."),
    billable: Optional[bool] = typer.Option(None, "--billable/--no-billable", help="Filter by billable status."),
    invoiced: Optional[bool] = typer.Option(None, "--invoiced/--uninvoiced", help="Filter by invoiced status."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """List expenses with optional filters.

    By default, shows the current month's expenses.

    Examples:
        ct expense list
        ct expense list --from 2026-03-01 --to 2026-03-31
        ct expense list --project myproject --billable
        ct expense list --category travel --uninvoiced
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    params: dict = {}

    # Default to current month if no date filters provided
    if not from_date and not to_date:
        today = date_type.today()
        start = today.replace(day=1)
        params["date_from"] = format_date(start)
        params["date_to"] = format_date(today)

    if from_date:
        try:
            params["date_from"] = format_date(parse_date(from_date))
        except ValueError as e:
            format_error(str(e))
            raise typer.Exit(1)
    if to_date:
        try:
            params["date_to"] = format_date(parse_date(to_date))
        except ValueError as e:
            format_error(str(e))
            raise typer.Exit(1)

    if project:
        params["project"] = project
    if category:
        params["category"] = category
    if billable is not None:
        params["is_billable"] = str(billable).lower()
    if invoiced is not None:
        params["is_invoiced"] = str(invoiced).lower()

    try:
        data = client.get("/expenses/", params=params)
        results = extract_results(data)

        if output_json:
            print_json(results)
        else:
            _print_expenses_table(results)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command("show")
def show_expense(
    expense_id: str = typer.Argument(..., help="Expense ID."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Show expense details.

    Examples:
        ct expense show <expense-id>
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.get(f"/expenses/{expense_id}/")

        if output_json:
            print_json(data)
        else:
            console.print()
            console.print(f"[bold]{data.get('description', '')}[/bold]")
            console.print(f"  ID:          {data.get('id', '')}")
            console.print(f"  Amount:      {format_currency(data.get('amount'))}")
            console.print(f"  Date:        {data.get('date', '')}")
            if data.get("project_name") or data.get("project"):
                console.print(f"  Project:     [cyan]{data.get('project_name', data.get('project', ''))}[/cyan]")
            if data.get("category_name") or data.get("category"):
                console.print(f"  Category:    {data.get('category_name', data.get('category', ''))}")
            if data.get("vendor"):
                console.print(f"  Vendor:      {data['vendor']}")
            console.print(f"  Billable:    {'Yes' if data.get('is_billable') else 'No'}")
            console.print(f"  Invoiced:    {'Yes' if data.get('is_invoiced') else 'No'}")
            if data.get("notes"):
                console.print(f"  Notes:       {data['notes']}")
            if data.get("receipt_url"):
                console.print(f"  Receipt:     {data['receipt_url']}")
            console.print(f"  Created:     {format_iso_date(data.get('created_at'))}")
            console.print()
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Expense '{expense_id}' not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@app.command("create")
def create_expense(
    description: str = typer.Argument(..., help="Expense description."),
    amount: float = typer.Option(..., "--amount", "-a", help="Expense amount."),
    project: Optional[str] = typer.Option(None, "--project", "-p", help="Project slug or ID."),
    category: Optional[str] = typer.Option(None, "--category", "-c", help="Expense category."),
    vendor: Optional[str] = typer.Option(None, "--vendor", help="Vendor name."),
    date: Optional[str] = typer.Option(None, "--date", "-d", help="Expense date in YYYY-MM-DD (default: today)."),
    billable: Optional[bool] = typer.Option(None, "--billable/--no-billable", "-b/-B",
                                            help="Mark as billable (default: billable)."),
    notes: Optional[str] = typer.Option(None, "--notes", "-n", help="Additional notes."),
    receipt_url: Optional[str] = typer.Option(None, "--receipt-url", help="URL to receipt image."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Create a new expense.

    Examples:
        ct expense create "Flight to NYC" --amount 450.00 --category travel
        ct expense create "Lunch with client" -a 85.50 -p myproject -c meals
        ct expense create "Software license" -a 199 --vendor "JetBrains" --date yesterday -B
    """
    if amount <= 0:
        format_error("Amount must be greater than zero.")
        raise typer.Exit(1)

    client = CrowdTimeClient(require_auth=True, require_org=True)

    payload: dict = {
        "description": description,
        "amount": str(Decimal(str(amount))),
    }

    if project:
        payload["project"] = project
    if category:
        payload["category"] = category
    if vendor:
        payload["vendor"] = vendor
    if date:
        try:
            parsed = parse_date(date)
            payload["date"] = format_date(parsed)
        except ValueError as e:
            format_error(str(e))
            raise typer.Exit(1)
    if billable is not None:
        payload["is_billable"] = billable
    if notes:
        payload["notes"] = notes
    if receipt_url:
        payload["receipt_url"] = receipt_url

    try:
        data = client.post("/expenses/", data=payload)

        if output_json:
            print_json(data)
        else:
            exp_desc = data.get("description", description)
            exp_amount = format_currency(data.get("amount", amount))
            format_success(f"Expense '{exp_desc}' created — {exp_amount} (ID: {data.get('id', '')})")
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command("edit")
def edit_expense(
    expense_id: str = typer.Argument(..., help="Expense ID to edit."),
    amount: Optional[float] = typer.Option(None, "--amount", "-a", help="New amount."),
    description: Optional[str] = typer.Option(None, "--description", help="New description."),
    project: Optional[str] = typer.Option(None, "--project", "-p", help="New project slug or ID."),
    category: Optional[str] = typer.Option(None, "--category", "-c", help="New category."),
    vendor: Optional[str] = typer.Option(None, "--vendor", help="New vendor name."),
    date: Optional[str] = typer.Option(None, "--date", "-d", help="New date (YYYY-MM-DD)."),
    billable: Optional[bool] = typer.Option(None, "--billable/--no-billable", "-b/-B",
                                            help="Mark as billable/non-billable."),
    notes: Optional[str] = typer.Option(None, "--notes", "-n", help="New notes."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Edit an existing expense.

    Examples:
        ct expense edit <expense-id> --amount 500.00
        ct expense edit <expense-id> --description "Updated description" --category meals
        ct expense edit <expense-id> -p newproject -B
    """
    if amount is not None and amount <= 0:
        format_error("Amount must be greater than zero.")
        raise typer.Exit(1)

    client = CrowdTimeClient(require_auth=True, require_org=True)

    payload: dict = {}
    if amount is not None:
        payload["amount"] = str(Decimal(str(amount)))
    if description is not None:
        payload["description"] = description
    if project is not None:
        payload["project"] = project
    if category is not None:
        payload["category"] = category
    if vendor is not None:
        payload["vendor"] = vendor
    if date:
        try:
            payload["date"] = format_date(parse_date(date))
        except ValueError as e:
            format_error(str(e))
            raise typer.Exit(1)
    if billable is not None:
        payload["is_billable"] = billable
    if notes is not None:
        payload["notes"] = notes

    if not payload:
        format_error("No changes specified. Use --amount, --description, --project, etc.")
        raise typer.Exit(1)

    try:
        data = client.patch(f"/expenses/{expense_id}/", data=payload)

        if output_json:
            print_json(data)
        else:
            format_success(f"Expense {expense_id} updated.")
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Expense '{expense_id}' not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@app.command("delete")
def delete_expense(
    expense_id: str = typer.Argument(..., help="Expense ID to delete."),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation."),
) -> None:
    """Delete an expense.

    Examples:
        ct expense delete <expense-id>
        ct expense delete <expense-id> --force
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    if not force:
        # Fetch expense details for confirmation
        try:
            data = client.get(f"/expenses/{expense_id}/")
            desc = data.get("description", "(no description)")
            amount = format_currency(data.get("amount"))
            if not typer.confirm(f"Delete expense '{desc}' ({amount})?"):
                console.print("[dim]Cancelled.[/dim]")
                return
        except APIError as e:
            if e.status_code == 404:
                format_error(f"Expense '{expense_id}' not found.")
            else:
                format_error(e.message)
            raise typer.Exit(1)

    try:
        client.delete(f"/expenses/{expense_id}/")
        format_success(f"Expense {expense_id} deleted.")
    except APIError as e:
        if e.status_code == 404:
            format_error(f"Expense '{expense_id}' not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@app.command("categories")
def list_categories(
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """List all expense categories.

    Examples:
        ct expense categories
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.get("/expenses/categories/")
        results = extract_results(data)

        if output_json:
            print_json(results)
        else:
            if not results:
                console.print("[dim]No expense categories found.[/dim]")
                return

            table = Table(show_header=True, header_style="bold")
            table.add_column("ID", style="dim")
            table.add_column("Name", width=25)

            for cat in results:
                table.add_row(
                    str(cat.get("id", "")),
                    cat.get("name", ""),
                )

            console.print(table)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command("add-category")
def add_category(
    name: str = typer.Argument(..., help="Category name."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Create a new expense category.

    Examples:
        ct expense add-category travel
        ct expense add-category "Office Supplies"
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.post("/expenses/categories/", data={"name": name})

        if output_json:
            print_json(data)
        else:
            format_success(f"Category '{data.get('name', name)}' created (ID: {data.get('id', '')})")
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)
