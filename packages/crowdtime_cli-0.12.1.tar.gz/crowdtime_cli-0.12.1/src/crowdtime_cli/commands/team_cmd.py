"""Team commands: manage manager → direct-report assignments.

Mirrors Harvest's manager model. Admins assign members as direct reports
to a manager; the manager can see those members' hours across any project
without being added as a PM to each project individually.

Bulk operations use the delta-based ``/manager-assignments/bulk-set/``
endpoint — the client computes ``add`` and ``remove`` sets, keeping
concurrent edits from clobbering each other.
"""

from __future__ import annotations

from typing import List, Optional

import typer
from rich.console import Console
from rich.table import Table

from ..client import APIError, CrowdTimeClient
from ..formatters import extract_results, format_error, format_success, print_json

app = typer.Typer(name="team", help="Manage direct-report assignments.")
console = Console()


def _members_list(client: CrowdTimeClient) -> list[dict]:
    data = client.get("/members/")
    return extract_results(data)


def _resolve_membership(client: CrowdTimeClient, ref: str, *, members: Optional[list[dict]] = None) -> dict:
    """Resolve a membership by email, user UUID, or membership UUID.

    Accepts an optional pre-fetched ``members`` list to avoid repeat HTTP
    calls when resolving many refs at once.
    """
    members = members or _members_list(client)
    ref_lower = ref.lower()
    for m in members:
        if (m.get("user", {}).get("email") or "").lower() == ref_lower:
            return m
    for m in members:
        if m.get("id") == ref:
            return m
    for m in members:
        if m.get("user", {}).get("id") == ref:
            return m
    raise APIError(
        f"No member found matching '{ref}'. Use email, user ID, or membership ID.",
        status_code=404,
    )


def _current_direct_report_ids(client: CrowdTimeClient, manager_id: str) -> set[str]:
    """Return the set of membership IDs currently assigned to ``manager_id``."""
    data = client.get("/manager-assignments/", params={"manager": manager_id})
    rows = extract_results(data)
    return {row["member"] for row in rows}


def _render_bulk_result(result: dict, *, members_by_id: dict[str, dict]) -> None:
    """Pretty-print the bulk-set response."""
    added = result.get("added") or []
    removed = result.get("removed") or []
    skipped = result.get("skipped") or {}

    def _label(mid: str) -> str:
        m = members_by_id.get(mid)
        if not m:
            return mid
        u = m.get("user") or {}
        return u.get("full_name") or u.get("email") or mid

    if added:
        console.print(f"[green]+ added[/green]   {', '.join(_label(x) for x in added)}")
    if removed:
        console.print(f"[red]- removed[/red] {', '.join(_label(x) for x in removed)}")
    for bucket_key, color, noun in (
        ("already_assigned", "dim", "already assigned"),
        ("not_assigned", "dim", "not assigned"),
        ("not_in_org", "yellow", "not in org"),
        ("invalid_role", "yellow", "invalid"),
    ):
        items = skipped.get(bucket_key) or []
        if items:
            console.print(f"[{color}]· {noun}: {', '.join(_label(x) for x in items)}[/{color}]")


def _bulk_set(
    client: CrowdTimeClient,
    manager_id: str,
    *,
    add: List[str],
    remove: List[str],
    members: list[dict],
    output_json: bool,
) -> None:
    """Call the bulk-set endpoint and render the result."""
    if not add and not remove:
        console.print("[dim]Nothing to change.[/dim]")
        return
    members_by_id = {m["id"]: m for m in members}
    try:
        result = client.post("/manager-assignments/bulk-set/", data={
            "manager": manager_id,
            "add": add,
            "remove": remove,
        })
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)
    if output_json:
        print_json(result)
        return
    added_n = len(result.get("added") or [])
    removed_n = len(result.get("removed") or [])
    if added_n or removed_n:
        parts = []
        if added_n:
            parts.append(f"{added_n} added")
        if removed_n:
            parts.append(f"{removed_n} removed")
        format_success("; ".join(parts))
    _render_bulk_result(result, members_by_id=members_by_id)


@app.command("assign")
def assign(
    manager: str = typer.Argument(..., help="Manager (email, user ID, or membership ID)."),
    members: Optional[List[str]] = typer.Argument(None, help="One or more members to assign (email, user ID, or membership ID)."),
    assign_all: bool = typer.Option(False, "--all", help="Assign every active member of the organization."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Assign one or more members as direct reports to a manager.

    Admin+ only. The member's hours become visible to the manager across
    all projects — no per-project PM assignment needed.

    Examples:
        ct team assign alice@acme.com bob@acme.com
        ct team assign alice@acme.com bob@acme.com carol@acme.com dave@acme.com
        ct team assign alice@acme.com --all
    """
    if bool(members) == assign_all:
        format_error(
            "Pass one or more members, OR use --all. Not both, not neither."
            if members and assign_all
            else "Specify members to assign, or pass --all."
        )
        raise typer.Exit(2)

    client = CrowdTimeClient(require_auth=True, require_org=True)
    try:
        all_members = _members_list(client)
        manager_m = _resolve_membership(client, manager, members=all_members)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)

    if assign_all:
        add_ids = [
            m["id"] for m in all_members
            if m.get("is_active", True) and m["id"] != manager_m["id"]
        ]
    else:
        try:
            resolved = [
                _resolve_membership(client, ref, members=all_members)
                for ref in members
            ]
        except APIError as e:
            format_error(e.message)
            raise typer.Exit(1)
        add_ids = [m["id"] for m in resolved]

    _bulk_set(
        client, manager_m["id"],
        add=add_ids, remove=[],
        members=all_members, output_json=output_json,
    )


@app.command("unassign")
def unassign(
    manager: str = typer.Argument(..., help="Manager (email, user ID, or membership ID)."),
    members: Optional[List[str]] = typer.Argument(None, help="One or more direct reports to remove. Mutually exclusive with --all."),
    unassign_all: bool = typer.Option(False, "--all", help="Remove every current direct report of this manager."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Remove one or more direct-report assignments from a manager.

    Admin+ only.

    Examples:
        ct team unassign alice@acme.com bob@acme.com
        ct team unassign alice@acme.com --all
    """
    if bool(members) == unassign_all:
        format_error(
            "Pass one or more members, OR use --all. Not both, not neither."
            if members and unassign_all
            else "Specify members to unassign, or pass --all."
        )
        raise typer.Exit(2)

    client = CrowdTimeClient(require_auth=True, require_org=True)
    try:
        all_members = _members_list(client)
        manager_m = _resolve_membership(client, manager, members=all_members)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)

    if unassign_all:
        try:
            remove_ids = list(_current_direct_report_ids(client, manager_m["id"]))
        except APIError as e:
            format_error(e.message)
            raise typer.Exit(1)
    else:
        try:
            resolved = [
                _resolve_membership(client, ref, members=all_members)
                for ref in members
            ]
        except APIError as e:
            format_error(e.message)
            raise typer.Exit(1)
        remove_ids = [m["id"] for m in resolved]

    _bulk_set(
        client, manager_m["id"],
        add=[], remove=remove_ids,
        members=all_members, output_json=output_json,
    )


@app.command("set")
def set_reports(
    manager: str = typer.Argument(..., help="Manager (email, user ID, or membership ID)."),
    members: List[str] = typer.Option(
        [], "--member", "-m",
        help="Member to include as a direct report. Repeat for each. Pass zero to clear all.",
    ),
    all_members: bool = typer.Option(False, "--all", help="Set the direct reports to every active org member."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Declaratively set the full list of direct reports for a manager.

    Computes the diff against the current assignments and applies it in one
    atomic call. Members not in the list are unassigned; new members are
    added. Admin+ only.

    Examples:
        ct team set alice@acme.com --member bob@acme.com --member carol@acme.com
        ct team set alice@acme.com --all       # replace with every org member
        ct team set alice@acme.com              # clear all reports (no --member flags)
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        all_active = _members_list(client)
        manager_m = _resolve_membership(client, manager, members=all_active)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)

    if all_members:
        if members:
            format_error("Pass --member or --all, not both.")
            raise typer.Exit(2)
        desired = {
            m["id"] for m in all_active
            if m.get("is_active", True) and m["id"] != manager_m["id"]
        }
    else:
        try:
            desired = {
                _resolve_membership(client, ref, members=all_active)["id"]
                for ref in members
            }
        except APIError as e:
            format_error(e.message)
            raise typer.Exit(1)

    try:
        current = _current_direct_report_ids(client, manager_m["id"])
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)

    add_ids = sorted(desired - current)
    remove_ids = sorted(current - desired)

    _bulk_set(
        client, manager_m["id"],
        add=add_ids, remove=remove_ids,
        members=all_active, output_json=output_json,
    )


@app.command("list")
def list_assignments(
    manager: Optional[str] = typer.Option(None, "--manager", "-m", help="Filter to a manager (ID, user ID, or email)."),
    member: Optional[str] = typer.Option(None, "--member", help="Filter to a member (ID, user ID, or email)."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """List manager→direct-report assignments.

    Admin+ sees all assignments in the org. Other roles see only rows where
    they are the manager.
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    params: dict = {}
    try:
        if manager:
            m = _resolve_membership(client, manager)
            params["manager"] = m["id"]
        if member:
            m = _resolve_membership(client, member)
            params["member"] = m["id"]
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)

    try:
        data = client.get("/manager-assignments/", params=params)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)

    rows = extract_results(data)

    if output_json:
        print_json(rows)
        return

    if not rows:
        console.print("[dim]No direct-report assignments.[/dim]")
        return

    table = Table(show_header=True, header_style="bold")
    table.add_column("Assignment ID", style="dim")
    table.add_column("Manager")
    table.add_column("Manager Email", style="dim")
    table.add_column("Direct Report")
    table.add_column("Report Email", style="dim")

    for row in rows:
        table.add_row(
            row.get("id", ""),
            row.get("manager_name") or "-",
            row.get("manager_email") or "-",
            row.get("member_name") or "-",
            row.get("member_email") or "-",
        )

    console.print(table)


@app.command("reports")
def reports(
    manager: Optional[str] = typer.Option(None, "--manager", "-m", help="Manager to list reports for. Defaults to you."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Show direct reports of a manager (defaults to the current user).

    Examples:
        ct team reports
        ct team reports --manager alice@acme.com
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    params: dict = {}
    if manager:
        try:
            m = _resolve_membership(client, manager)
            params["manager"] = m["id"]
        except APIError as e:
            format_error(e.message)
            raise typer.Exit(1)

    try:
        data = client.get("/manager-assignments/", params=params)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)

    rows = extract_results(data)

    if output_json:
        print_json(rows)
        return

    if not rows:
        console.print("[dim]No direct reports.[/dim]")
        return

    table = Table(show_header=True, header_style="bold")
    table.add_column("Direct Report")
    table.add_column("Email", style="dim")
    table.add_column("User ID", style="dim")
    table.add_column("Assignment ID", style="dim")

    for row in rows:
        table.add_row(
            row.get("member_name") or "-",
            row.get("member_email") or "-",
            row.get("member_user_id") or "-",
            row.get("id", ""),
        )

    console.print(table)
