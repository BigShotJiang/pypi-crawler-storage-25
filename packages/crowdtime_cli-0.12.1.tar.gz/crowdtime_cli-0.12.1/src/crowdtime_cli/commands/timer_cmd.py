"""Timer commands: start, stop, status, switch, discard."""

from __future__ import annotations

from typing import Optional

import typer
from rich.console import Console

from ..client import APIError, CrowdTimeClient
from ..formatters import format_entry_summary, format_error, format_success, format_timer, print_json
from ..utils import format_duration
from ..models import TimeEntry
from ..resolvers import resolve_project, resolve_task

app = typer.Typer(name="timer", help="Timer commands for tracking time.")
console = Console()


@app.command()
def start(
    description: str = typer.Argument("", help="What are you working on?"),
    project: Optional[str] = typer.Option(None, "--project", "-p", help="Project name or ID."),
    task: Optional[str] = typer.Option(None, "--task", "-t", help="Task name or ID."),
    billable: Optional[bool] = typer.Option(None, "--billable/--no-billable", "-b/-B",
                                            help="Mark as billable/non-billable."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Start a new timer.

    If a timer is already running, you'll be asked to stop it first.
    Use 'ct timer switch' to stop and start in one step.
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    project_ref = project or client.config.default_project
    if not project_ref:
        format_error("Project is required. Use -p <project> or set a default with: ct projects switch <slug>")
        raise typer.Exit(1)

    try:
        project_id = resolve_project(client, project_ref)
    except APIError as e:
        format_error(f"Failed to resolve project '{project_ref}': {e.message}")
        raise typer.Exit(1)

    payload: dict = {
        "project_id": project_id,
    }
    if description:
        payload["notes"] = description
    if task:
        try:
            payload["task_id"] = resolve_task(client, task, project_id=project_id)
        except APIError as e:
            format_error(f"Failed to resolve task '{task}': {e.message}")
            raise typer.Exit(1)
    if billable is not None:
        payload["is_billable"] = billable

    try:
        data = client.post("/time/start/", data=payload)
        entry = TimeEntry(**data)

        if output_json:
            print_json(entry)
        else:
            format_success(f"Timer started (ID: {entry.id})")
            format_timer(entry)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command()
def stop(
    note: Optional[str] = typer.Option(None, "--note", "-n", help="Add a note to the entry."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Stop the currently running timer."""
    client = CrowdTimeClient(require_auth=True, require_org=True)

    payload: dict = {}
    if note:
        payload["notes"] = note

    try:
        data = client.post("/time/stop/", data=payload if payload else None)
        warning = data.pop("warning", None) if isinstance(data, dict) else None
        entry = TimeEntry(**data)

        if output_json:
            print_json(entry)
        else:
            dur = format_duration(entry.duration) if entry.duration else "0m"
            format_success(f"Timer stopped — {dur} logged")
            if warning:
                console.print(f"[yellow]⚠ {warning}[/yellow]")
            format_entry_summary(entry)
    except APIError as e:
        if e.status_code == 404:
            format_error("No timer is currently running.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@app.command()
def status(
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Show the currently running timer.

    Examples:
        ct timer status
        ct timer status --json
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.get("/time/running/")
        entry = TimeEntry(**data)

        if output_json:
            print_json(entry)
        else:
            format_timer(entry)
    except APIError as e:
        if e.status_code == 404:
            console.print("[dim]No timer is currently running.[/dim]")
        else:
            format_error(e.message)
            raise typer.Exit(1)


@app.command()
def edit(
    description: Optional[str] = typer.Option(None, "--description", "-n", help="New description/notes."),
    project: Optional[str] = typer.Option(None, "--project", "-p", help="New project name or ID."),
    task: Optional[str] = typer.Option(None, "--task", "-t", help="New task name or ID."),
    billable: Optional[bool] = typer.Option(None, "--billable/--no-billable", "-b/-B",
                                            help="Mark as billable/non-billable."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Edit the currently running timer without stopping it.

    Update the description, project, task, or billable status.
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    # Get the running timer
    try:
        data = client.get("/time/running/")
        entry = TimeEntry(**data)
    except APIError as e:
        if e.status_code == 404:
            format_error("No timer is currently running.")
        else:
            format_error(e.message)
        raise typer.Exit(1)

    payload: dict = {}
    if description is not None:
        payload["notes"] = description
    resolved_project_id = None
    if project:
        try:
            resolved_project_id = resolve_project(client, project)
            payload["project"] = resolved_project_id
        except APIError as e:
            format_error(f"Failed to resolve project '{project}': {e.message}")
            raise typer.Exit(1)
    if task:
        try:
            payload["task"] = resolve_task(client, task, project_id=resolved_project_id or entry.project)
        except APIError as e:
            format_error(f"Failed to resolve task '{task}': {e.message}")
            raise typer.Exit(1)
    if billable is not None:
        payload["is_billable"] = billable

    if not payload:
        format_error("No changes specified. Use --description, --project, --task, or --billable/--no-billable.")
        raise typer.Exit(1)

    try:
        data = client.patch(f"/time/{entry.id}/", data=payload)
        updated = TimeEntry(**data)

        if output_json:
            print_json(updated)
        else:
            format_success("Timer updated")
            format_timer(updated)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command()
def switch(
    description: str = typer.Argument("", help="What are you switching to?"),
    project: Optional[str] = typer.Option(None, "--project", "-p", help="Project name or ID."),
    task: Optional[str] = typer.Option(None, "--task", "-t", help="Task name or ID."),
    billable: Optional[bool] = typer.Option(None, "--billable/--no-billable", "-b/-B",
                                            help="Mark as billable/non-billable."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Stop the current timer and start a new one."""
    client = CrowdTimeClient(require_auth=True, require_org=True)

    # Stop current timer
    try:
        stop_data = client.post("/time/stop/")
        stopped = TimeEntry(**stop_data)
        if not output_json:
            dur = format_duration(stopped.duration) if stopped.duration else "0h"
            console.print(f"[dim]Stopped: {stopped.description or '(no description)'} "
                          f"({stopped.project_name or ''}) — {dur}[/dim]")
    except APIError as e:
        if e.status_code != 404:
            format_error(f"Could not stop current timer: {e.message}")
            raise typer.Exit(1)

    # Start new timer
    project_ref = project or client.config.default_project
    if not project_ref:
        format_error("Project is required. Use -p <project> or set a default with: ct projects switch <slug>")
        raise typer.Exit(1)

    try:
        project_id = resolve_project(client, project_ref)
    except APIError as e:
        format_error(f"Failed to resolve project '{project_ref}': {e.message}")
        raise typer.Exit(1)

    payload: dict = {
        "project_id": project_id,
    }
    if description:
        payload["notes"] = description
    if task:
        try:
            payload["task_id"] = resolve_task(client, task, project_id=project_id)
        except APIError as e:
            format_error(f"Failed to resolve task '{task}': {e.message}")
            raise typer.Exit(1)
    if billable is not None:
        payload["is_billable"] = billable

    try:
        data = client.post("/time/start/", data=payload)
        entry = TimeEntry(**data)

        if output_json:
            print_json(entry)
        else:
            format_success("Switched timer")
            format_timer(entry)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command("continue")
def continue_timer(
    note: Optional[str] = typer.Option(None, "--note", "-n", help="Override or add a description."),
    billable: Optional[bool] = typer.Option(None, "--billable/--no-billable", "-b/-B",
                                            help="Override billable status."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Continue the last stopped timer.

    Starts a new timer with the same project, task, and description as
    the most recently stopped entry. Great for resuming after a break.

    Examples:
        ct timer continue
        ct timer continue --note "Continuing from earlier"
        ct timer continue --no-billable
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    # Fetch recent entries to find the last non-running one
    try:
        data = client.get("/time/", params={"page_size": "1", "ordering": "-start_time"})
        from ..formatters import extract_results
        entries = extract_results(data)
        if not entries:
            format_error("No recent entries to continue from.")
            raise typer.Exit(1)

        last = entries[0]
        if last.get("is_running"):
            format_error("A timer is already running. Stop it first or use 'ct timer switch'.")
            raise typer.Exit(1)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)

    # Build start payload from the last entry
    project_id = last.get("project")
    if not project_id:
        format_error("Last entry has no project — cannot continue.")
        raise typer.Exit(1)

    payload: dict = {"project_id": project_id}
    if note:
        payload["notes"] = note
    elif last.get("notes"):
        payload["notes"] = last["notes"]
    if last.get("task"):
        payload["task_id"] = last["task"]
    if billable is not None:
        payload["is_billable"] = billable
    elif last.get("is_billable") is not None:
        payload["is_billable"] = last["is_billable"]

    try:
        data = client.post("/time/start/", data=payload)
        entry = TimeEntry(**data)

        if output_json:
            print_json(entry)
        else:
            format_success("Timer continued from last entry")
            format_timer(entry)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command()
def discard(
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation."),
) -> None:
    """Discard the running timer without saving."""
    client = CrowdTimeClient(require_auth=True, require_org=True)

    # Get the running entry
    try:
        data = client.get("/time/running/")
        entry = TimeEntry(**data)
    except APIError as e:
        if e.status_code == 404:
            console.print("[dim]No timer is currently running.[/dim]")
            return
        format_error(e.message)
        raise typer.Exit(1)

    if not force:
        desc = entry.description or "(no description)"
        if not typer.confirm(f"Discard timer '{desc}'?"):
            console.print("[dim]Cancelled.[/dim]")
            return

    try:
        client.delete(f"/time/{entry.id}/")
        format_success("Timer discarded.")
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)
