"""Organization commands: list, show, switch, members, invite."""

from __future__ import annotations

from typing import Optional

import click
import typer
from rich.console import Console
from rich.table import Table

from ..client import APIError, CrowdTimeClient
from ..config import get_config
from ..formatters import extract_results, format_error, format_members_table, format_success, print_json
from ..utils import format_iso_date
from ..models import Organization

app = typer.Typer(name="org", help="Manage organizations.")
console = Console()


@app.command("list")
def list_orgs(
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """List organizations you belong to."""
    client = CrowdTimeClient(require_auth=True, require_org=False)

    try:
        data = client.get("/api/v1/organizations/", org_scoped=False)
        orgs_list = extract_results(data)
        orgs = [Organization(**item) for item in orgs_list]

        if output_json:
            print_json(orgs)
            return

        if not orgs:
            console.print("[dim]No organizations found.[/dim]")
            console.print("Run [bold]ct org create <name>[/bold] to create an organization.")
            return

        current_slug = client.config.organization

        table = Table(show_header=True, header_style="bold")
        table.add_column("", width=3)
        table.add_column("Name", width=20)
        table.add_column("Slug", width=15)
        table.add_column("Role", width=18)
        table.add_column("Members", justify="right", width=8)

        for org in orgs:
            marker = "[green]*[/green]" if org.slug == current_slug else " "
            table.add_row(
                marker,
                org.name,
                org.slug,
                org.role or "",
                str(org.member_count or ""),
            )

        console.print(table)
        if current_slug:
            console.print(f"\n[dim]* = current organization ({current_slug})[/dim]")
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command("show")
def show_org(
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Show details of the current organization."""
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        # Get the org slug, then fetch full details
        slug = client.config.organization
        data = client.get("/api/v1/organizations/", org_scoped=False)
        orgs_list = extract_results(data)
        org_data = next((o for o in orgs_list if o.get("slug") == slug), None)

        if not org_data:
            format_error(f"Organization '{slug}' not found.")
            raise typer.Exit(1)

        if output_json:
            print_json(org_data)
            return

        table = Table(show_header=False, box=None, padding=(0, 2))
        table.add_column("Field", style="dim", width=20)
        table.add_column("Value")

        table.add_row("Name", org_data.get("name", ""))
        table.add_row("Slug", org_data.get("slug", ""))
        table.add_row("Your Role", org_data.get("my_role", org_data.get("role", "")))
        table.add_row("Members", str(org_data.get("member_count", "")))
        table.add_row("Currency", org_data.get("default_currency", "USD"))
        table.add_row("Week Starts", str(org_data.get("week_start_day", "monday")).capitalize())
        if org_data.get("require_task_on_entry"):
            table.add_row("Require Task", "[green]Yes[/green]")
        if org_data.get("require_notes_on_entry"):
            table.add_row("Require Notes", "[green]Yes[/green]")
        if org_data.get("default_payment_terms_days"):
            table.add_row("Payment Terms", f"{org_data['default_payment_terms_days']} days")
        if org_data.get("created_at"):
            table.add_row("Created", format_iso_date(org_data["created_at"]))

        console.print(table)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command("create")
def create_org(
    name: str = typer.Argument(..., help="Name for the new organization."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Create a new organization."""
    client = CrowdTimeClient(require_auth=True, require_org=False)

    try:
        data = client.post(
            "/api/v1/organizations/create-personal/",
            data={"name": name},
            org_scoped=False,
        )
        org = data.get("organization", {})

        if output_json:
            print_json(data)
        else:
            slug = org.get("slug", "")
            format_success(f"Organization '{org.get('name', name)}' created (slug: {slug})")
            console.print(f"[dim]Switch to it with: ct org switch {slug}[/dim]")
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command("switch")
def switch_org(
    slug: str = typer.Argument(..., help="Organization slug to switch to."),
) -> None:
    """Switch the active organization."""
    # Verify the org exists
    client = CrowdTimeClient(require_auth=True, require_org=False)

    try:
        data = client.get("/api/v1/organizations/", org_scoped=False)
        orgs_list = extract_results(data)
        slugs = [o.get("slug", "") for o in orgs_list]

        if slug not in slugs:
            format_error(f"Organization '{slug}' not found. Available: {', '.join(slugs)}")
            raise typer.Exit(1)

    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)

    config = get_config()
    config.set("defaults.organization", slug)
    format_success(f"Switched to organization '{slug}'")


@app.command()
def members(
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """List members of the current organization."""
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.get("/members/")
        members_list = extract_results(data)

        if output_json:
            print_json(members_list)
        else:
            format_members_table(members_list)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command()
def invite(
    email: str = typer.Argument(..., help="Email address to invite."),
    role: str = typer.Option(
        "member", "--role", "-r",
        help="Role for the new member.",
        click_type=click.Choice(
            ["admin", "manager", "project_manager", "member", "viewer"],
            case_sensitive=False,
        ),
    ),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Invite a member to the current organization."""
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.post("/members/invite/", data={
            "email": email,
            "role": role,
        })

        if output_json:
            print_json(data)
        else:
            format_success(f"Invitation sent to {email} (role: {role})")
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command("update-member")
def update_member(
    user_id: str = typer.Argument(..., help="User ID of the member to update."),
    role: Optional[str] = typer.Option(None, "--role", "-r",
                                        help="New role for the member.",
                                        click_type=click.Choice(
                                            ["admin", "manager", "project_manager", "member", "viewer"],
                                            case_sensitive=False,
                                        )),
    rate: Optional[str] = typer.Option(None, "--rate", help="Hourly rate for this member."),
    capacity: Optional[float] = typer.Option(None, "--capacity", help="Weekly capacity hours."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Update an organization member's role, rate, or capacity.

    Examples:
        ct org update-member <user-id> --role project_manager
        ct org update-member <user-id> --rate 150
        ct org update-member <user-id> --role admin --rate 200
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    payload: dict = {}
    if role is not None:
        payload["role"] = role
    if rate is not None:
        payload["hourly_rate"] = rate
    if capacity is not None:
        payload["weekly_capacity_hours"] = capacity

    if not payload:
        format_error("Provide at least --role, --rate, or --capacity to update.")
        raise typer.Exit(1)

    try:
        data = client.patch(f"/members/{user_id}/", data=payload)
        if output_json:
            print_json(data)
        else:
            name = data.get("user_name") or data.get("user_email", user_id)
            parts = []
            if role:
                parts.append(f"role={data.get('role', role)}")
            if rate:
                parts.append(f"rate={data.get('hourly_rate', rate)}")
            if capacity is not None:
                parts.append(f"capacity={data.get('weekly_capacity_hours', capacity)}h")
            format_success(f"Updated {name}: {', '.join(parts)}")
    except APIError as e:
        if e.status_code == 404:
            format_error("Member not found.")
        elif e.status_code == 400:
            format_error(e.message)
        else:
            format_error(e.message)
        raise typer.Exit(1)


@app.command("remove-member")
def remove_member(
    user_id: str = typer.Argument(..., help="User ID of the member to remove."),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation."),
) -> None:
    """Remove a member from the organization.

    Deactivates their membership and revokes all API tokens for this org.
    Cannot remove the organization owner.

    Examples:
        ct org remove-member <user-id>
        ct org remove-member <user-id> --force
    """
    if not force:
        if not typer.confirm(f"Remove member '{user_id}' from this organization?"):
            console.print("[dim]Cancelled.[/dim]")
            return

    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        client.delete(f"/members/{user_id}/")
        format_success(f"Member '{user_id}' removed from organization.")
    except APIError as e:
        if e.status_code == 404:
            format_error("Member not found.")
        elif e.status_code == 400:
            format_error(e.message)
        else:
            format_error(e.message)
        raise typer.Exit(1)


@app.command("resend-invite")
def resend_invite(
    invitation_id: str = typer.Argument(..., help="Invitation ID to resend."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Resend a pending invitation email."""
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.post(f"/invitations/{invitation_id}/resend/")

        if output_json:
            print_json(data)
        else:
            format_success("Invitation email resent.")
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command("revoke-invite")
def revoke_invite(
    invitation_id: str = typer.Argument(..., help="Invitation ID to revoke."),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Revoke a pending invitation."""
    if not force:
        if not typer.confirm(f"Revoke invitation '{invitation_id}'?"):
            console.print("[dim]Cancelled.[/dim]")
            return

    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.post(f"/invitations/{invitation_id}/revoke/")

        if output_json:
            print_json(data)
        else:
            format_success("Invitation revoked.")
    except APIError as e:
        if e.status_code == 404:
            format_error("Invitation not found.")
        else:
            format_error(e.message)
        raise typer.Exit(1)


@app.command()
def invitations(
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """List pending invitations for the current organization."""
    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.get("/invitations/")
        inv_list = extract_results(data)

        if output_json:
            print_json(inv_list)
            return

        pending = [i for i in inv_list if i.get("status") == "pending"]
        if not pending:
            console.print("[dim]No pending invitations.[/dim]")
            return

        table = Table(show_header=True, header_style="bold")
        table.add_column("ID", style="dim")
        table.add_column("Email", width=25)
        table.add_column("Role", width=18)
        table.add_column("Status", width=10)
        table.add_column("Expires", width=12)

        role_labels = {
            "owner": "Owner",
            "admin": "Admin",
            "manager": "Account Manager",
            "project_manager": "Project Manager",
            "member": "Member",
            "viewer": "Viewer",
        }

        for inv in pending:
            table.add_row(
                inv.get("id", ""),
                inv.get("email", ""),
                role_labels.get(inv.get("role", ""), inv.get("role", "")),
                inv.get("status", ""),
                format_iso_date(inv.get("expires_at")),
            )

        console.print(table)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)
