"""Report commands: report, projects, team, client, budget."""

from __future__ import annotations

from typing import Optional

import typer
from rich.console import Console

from ..client import APIError, CrowdTimeClient
from ..formatters import extract_results, format_currency, format_error, format_report, print_json
from ..utils import format_date, format_duration, resolve_period

app = typer.Typer(name="report", help="Generate time reports.")
console = Console()


# Keep local alias for backward compatibility within this module.
_resolve_period = resolve_period


@app.callback(invoke_without_command=True)
def report(
    ctx: typer.Context,
    today_flag: bool = typer.Option(False, "--today", help="Report for today."),
    yesterday_flag: bool = typer.Option(False, "--yesterday", help="Report for yesterday."),
    week: bool = typer.Option(False, "--week", "-w", help="Report for this week."),
    last_week: bool = typer.Option(False, "--last-week", help="Report for last week."),
    month: bool = typer.Option(False, "--month", "-m", help="Report for this month."),
    last_month: bool = typer.Option(False, "--last-month", help="Report for last month."),
    quarter: bool = typer.Option(False, "--quarter", "-q", help="Report for this quarter."),
    last_quarter: bool = typer.Option(False, "--last-quarter", help="Report for last quarter."),
    from_date: Optional[str] = typer.Option(None, "--from", help="Start date (YYYY-MM-DD)."),
    to_date: Optional[str] = typer.Option(None, "--to", help="End date (YYYY-MM-DD)."),
    project: Optional[str] = typer.Option(None, "--project", "-p", help="Filter by project."),
    client_filter: Optional[str] = typer.Option(None, "--client", "-c", help="Filter by client ID."),
    group_by: str = typer.Option("project", "--group-by", "-g",
                                 help="Group by: project, task, day, client."),
    format_output: str = typer.Option("table", "--format", "-f",
                                      help="Output format: table, json, csv, markdown."),
) -> None:
    """Generate a time report.

    Examples:
        ct report --week
        ct report --month --group-by task
        ct report --last-quarter --group-by client
        ct report --from 2026-03-01 --to 2026-03-10 -p myproject
    """
    if ctx.invoked_subcommand is not None:
        return

    period_from, period_to = _resolve_period(
        today_flag, yesterday_flag, week, last_week, month, last_month,
        quarter, last_quarter, from_date, to_date,
    )

    valid_group_by = ["project", "task", "day", "client"]
    if group_by not in valid_group_by:
        format_error(f"Invalid group-by value '{group_by}'. Choose from: {', '.join(valid_group_by)}")
        raise typer.Exit(1)

    client = CrowdTimeClient(require_auth=True, require_org=True)

    params: dict = {
        "from": period_from,
        "to": period_to,
        "group_by": group_by,
    }
    if project:
        params["project"] = project
    if client_filter:
        params["client_id"] = client_filter

    if group_by == "project":
        endpoint = "/reports/project-summary/"
    elif group_by == "client":
        endpoint = "/reports/client-invoice/"
    else:
        endpoint = "/reports/time-detail/"

    try:
        data = client.get(endpoint, params=params)
        results = extract_results(data)

        if format_output == "json":
            print_json(results)
        elif format_output == "csv":
            _print_report_csv(results, group_by)
        elif format_output == "markdown":
            _print_report_markdown(results, group_by, period_from, period_to)
        else:
            console.print(f"\n[dim]Period: {period_from} to {period_to}[/dim]")
            format_report(results, group_by=group_by)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command("projects")
def project_report(
    week: bool = typer.Option(False, "--week", "-w", help="This week."),
    month: bool = typer.Option(False, "--month", "-m", help="This month (default if no period specified)."),
    last_month: bool = typer.Option(False, "--last-month", help="Last month."),
    quarter: bool = typer.Option(False, "--quarter", "-q", help="This quarter."),
    last_quarter: bool = typer.Option(False, "--last-quarter", help="Last quarter."),
    from_date: Optional[str] = typer.Option(None, "--from", help="Start date (YYYY-MM-DD)."),
    to_date: Optional[str] = typer.Option(None, "--to", help="End date (YYYY-MM-DD)."),
    client_filter: Optional[str] = typer.Option(None, "--client", "-c", help="Filter by client ID."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Project breakdown report."""
    # Custom dates override preset flags
    if from_date or to_date:
        period_from, period_to = _resolve_period(from_date=from_date, to_date=to_date)
    elif week:
        period_from, period_to = _resolve_period(week=True)
    elif last_month:
        period_from, period_to = _resolve_period(last_month=True)
    elif quarter:
        period_from, period_to = _resolve_period(quarter=True)
    elif last_quarter:
        period_from, period_to = _resolve_period(last_quarter=True)
    else:
        # Default to this month when no period flags given
        period_from, period_to = _resolve_period(month=True)

    client = CrowdTimeClient(require_auth=True, require_org=True)

    params: dict = {"from": period_from, "to": period_to}
    if client_filter:
        params["client_id"] = client_filter

    try:
        data = client.get("/reports/project-summary/", params=params)
        results = extract_results(data)

        if output_json:
            print_json(results)
        else:
            console.print(f"\n[dim]Period: {period_from} to {period_to}[/dim]")
            format_report(results, group_by="project")
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command("team")
def team_report(
    week: bool = typer.Option(False, "--week", "-w", help="This week."),
    month: bool = typer.Option(False, "--month", "-m", help="This month (default if no period specified)."),
    last_month: bool = typer.Option(False, "--last-month", help="Last month."),
    quarter: bool = typer.Option(False, "--quarter", "-q", help="This quarter."),
    last_quarter: bool = typer.Option(False, "--last-quarter", help="Last quarter."),
    from_date: Optional[str] = typer.Option(None, "--from", help="Start date (YYYY-MM-DD)."),
    to_date: Optional[str] = typer.Option(None, "--to", help="End date (YYYY-MM-DD)."),
    member: Optional[str] = typer.Option(None, "--member", help="Filter by team member."),
    client_filter: Optional[str] = typer.Option(None, "--client", "-c", help="Filter by client ID."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Team utilization report."""
    if from_date or to_date:
        period_from, period_to = _resolve_period(from_date=from_date, to_date=to_date)
    elif week:
        period_from, period_to = _resolve_period(week=True)
    elif last_month:
        period_from, period_to = _resolve_period(last_month=True)
    elif quarter:
        period_from, period_to = _resolve_period(quarter=True)
    elif last_quarter:
        period_from, period_to = _resolve_period(last_quarter=True)
    else:
        period_from, period_to = _resolve_period(month=True)

    client = CrowdTimeClient(require_auth=True, require_org=True)

    params: dict = {
        "from": period_from,
        "to": period_to,
    }
    if member:
        params["member"] = member
    if client_filter:
        params["client_id"] = client_filter

    try:
        data = client.get("/reports/team-utilization/", params=params)
        results = extract_results(data)

        if output_json:
            print_json(results)
        else:
            console.print(f"\n[dim]Team Report: {period_from} to {period_to}[/dim]")
            _print_team_table(results)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


def _print_team_table(data: list[dict]) -> None:
    """Print team utilization table."""
    from rich.table import Table
    from ..utils import format_duration
    from decimal import Decimal

    if not data:
        console.print("[dim]No data.[/dim]")
        return

    has_amounts = any(row.get("total_amount") for row in data)

    has_capacity = any(row.get("capacity_percent") is not None for row in data)

    table = Table(show_header=True, header_style="bold", title="Team Utilization")
    table.add_column("Member", width=20)
    table.add_column("Hours", justify="right", width=10)
    table.add_column("Billable", justify="right", width=10)
    if has_amounts:
        table.add_column("Amount", justify="right", width=12)
    table.add_column("Utilization", justify="right", width=12)
    if has_capacity:
        table.add_column("Capacity", justify="right", width=10)

    for row in data:
        hours = Decimal(str(row.get("total_hours", 0)))
        billable = Decimal(str(row.get("billable_hours", 0)))
        amount = Decimal(str(row.get("total_amount", 0)))
        utilization = row.get("utilization_percent", 0)
        row_data = [
            row.get("user_name", ""),
            format_duration(hours),
            format_duration(billable),
        ]
        if has_amounts:
            row_data.append(format_currency(amount))
        row_data.append(f"{float(utilization):.0f}%")
        if has_capacity:
            cap_pct = row.get("capacity_percent", 0)
            if cap_pct > 110:
                cap_str = f"[red]{cap_pct:.0f}%[/red]"
            elif cap_pct >= 80:
                cap_str = f"[green]{cap_pct:.0f}%[/green]"
            else:
                cap_str = f"[dim]{cap_pct:.0f}%[/dim]"
            row_data.append(cap_str)
        table.add_row(*row_data)

    console.print(table)


def _resolve_group_label(row: dict, group_by: str) -> str:
    """Resolve the display label for a report row based on group_by."""
    key_map = {
        "project": ("project_name", "project"),
        "client": ("client_name", "client"),
        "task": ("task_name", "task"),
        "day": ("date", "day"),
    }
    for k in key_map.get(group_by, (group_by,)):
        val = row.get(k, "")
        if val:
            return str(val)
    return row.get("project", row.get("project_name", ""))


def _print_report_csv(data: list[dict], group_by: str) -> None:
    """Print report as CSV."""
    console.print(f"{group_by},hours,billable_hours,total_amount,entry_count")
    for row in data:
        console.print(
            f'{_resolve_group_label(row, group_by)},'
            f'{row.get("total_hours", row.get("hours", 0))},'
            f'{row.get("billable_hours", 0)},'
            f'{row.get("total_amount", 0)},'
            f'{row.get("entry_count", row.get("entries_count", 0))}'
        )


def _print_report_markdown(data: list[dict], group_by: str, from_d: str, to_d: str) -> None:
    """Print report as Markdown."""
    from decimal import Decimal

    console.print(f"## Time Report ({from_d} to {to_d})\n")
    console.print(f"| {group_by.capitalize()} | Hours | Billable | Amount | Entries |")
    console.print("|---|---|---|---|---|")
    for row in data:
        hours = format_duration(Decimal(str(row.get("total_hours", row.get("hours", 0)))))
        billable = format_duration(Decimal(str(row.get("billable_hours", 0))))
        amount = format_currency(row.get("total_amount", 0))
        console.print(
            f"| {_resolve_group_label(row, group_by)} "
            f"| {hours} | {billable} | {amount} | {row.get('entry_count', row.get('entries_count', 0))} |"
        )


@app.command("client")
def client_report(
    week: bool = typer.Option(False, "--week", "-w", help="This week."),
    month: bool = typer.Option(False, "--month", "-m", help="This month (default if no period specified)."),
    last_month: bool = typer.Option(False, "--last-month", help="Last month."),
    quarter: bool = typer.Option(False, "--quarter", "-q", help="This quarter."),
    last_quarter: bool = typer.Option(False, "--last-quarter", help="Last quarter."),
    from_date: Optional[str] = typer.Option(None, "--from", help="Start date (YYYY-MM-DD)."),
    to_date: Optional[str] = typer.Option(None, "--to", help="End date (YYYY-MM-DD)."),
    client_filter: Optional[str] = typer.Option(None, "--client", "-c", help="Filter by client ID."),
    detail: bool = typer.Option(False, "--detail", "-d", help="Show per-project breakdown within each client."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Client billing summary — billable hours and amounts grouped by client.

    Shows each client's total billable hours, amount, number of projects,
    and number of entries for the period.

    Use --detail to see per-project breakdown within each client.

    Examples:
        ct report client
        ct report client --week
        ct report client --last-quarter
        ct report client --detail --client <client-id>
        ct report client --from 2026-01-01 --to 2026-03-31
    """
    from decimal import Decimal
    from rich.table import Table

    if from_date or to_date:
        period_from, period_to = _resolve_period(from_date=from_date, to_date=to_date)
    elif week:
        period_from, period_to = _resolve_period(week=True)
    elif last_month:
        period_from, period_to = _resolve_period(last_month=True)
    elif quarter:
        period_from, period_to = _resolve_period(quarter=True)
    elif last_quarter:
        period_from, period_to = _resolve_period(last_quarter=True)
    else:
        period_from, period_to = _resolve_period(month=True)

    client = CrowdTimeClient(require_auth=True, require_org=True)

    params: dict = {"from": period_from, "to": period_to}
    if client_filter:
        params["client_id"] = client_filter
    if detail:
        params["detail"] = "projects"

    try:
        data = client.get("/reports/client-invoice/", params=params)
        results = extract_results(data)
        totals = data.get("totals", {}) if isinstance(data, dict) else {}

        if output_json:
            print_json(data if isinstance(data, dict) else results)
            return

        if not results:
            console.print("[dim]No billable data for this period.[/dim]")
            return

        console.print(f"\n[dim]Client Billing: {period_from} to {period_to}[/dim]")

        table = Table(show_header=True, header_style="bold", title="Client Billing Summary")
        table.add_column("Client", style="bold", width=25)
        table.add_column("Hours", justify="right", width=10)
        table.add_column("Amount", justify="right", width=14)
        table.add_column("Projects", justify="right", width=10)
        table.add_column("Entries", justify="right", width=8)

        for row in results:
            currency = row.get("currency", "USD")
            table.add_row(
                row.get("client_name", "Unknown"),
                format_duration(Decimal(str(row.get("total_hours", 0)))),
                format_currency(row.get("total_amount", 0), currency),
                str(row.get("project_count", 0)),
                str(row.get("entry_count", 0)),
            )
            # Show per-project detail rows when --detail is used
            projects = row.get("projects", [])
            if projects:
                for proj in projects:
                    code = proj.get("project_code", "")
                    name = proj.get("project_name", "")
                    label = f"  [dim]{code}[/dim] {name}" if code else f"  {name}"

                    # Append budget indicator if available
                    budget_pct = proj.get("budget_percent_used")
                    if budget_pct is not None:
                        if budget_pct >= 100:
                            budget_tag = f" [red bold]({budget_pct:.0f}% used)[/red bold]"
                        elif budget_pct >= 80:
                            budget_tag = f" [yellow]({budget_pct:.0f}% used)[/yellow]"
                        else:
                            budget_tag = f" [dim]({budget_pct:.0f}% used)[/dim]"
                        label += budget_tag

                    table.add_row(
                        label,
                        f"[dim]{format_duration(Decimal(str(proj.get('total_hours', 0))))}[/dim]",
                        f"[dim]{format_currency(proj.get('total_amount', 0), currency)}[/dim]",
                        "",
                        f"[dim]{proj.get('entry_count', 0)}[/dim]",
                    )

        # Totals row — use common currency if all clients share one
        if totals:
            currencies_seen = {row.get("currency", "USD") for row in results}
            mixed = len(currencies_seen) > 1
            totals_currency = "USD" if mixed else currencies_seen.pop()
            table.add_section()
            amount_str = format_currency(totals.get('total_amount', 0), totals_currency)
            if mixed:
                amount_str += " *"
            table.add_row(
                "[bold]Total[/bold]",
                f"[bold]{format_duration(Decimal(str(totals.get('total_hours', 0))))}[/bold]",
                f"[bold]{amount_str}[/bold]",
                "",
                "",
            )

        console.print(table)
        if totals and len({row.get("currency", "USD") for row in results}) > 1:
            console.print("[dim]* Mixed currencies — total shown in USD (approximate)[/dim]")
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@app.command("budget")
def budget_report(
    project: str = typer.Option(..., "--project", "-p", help="Project ID (required)."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Budget burn-down report for a project.

    Shows daily budget snapshots: hours, amount spent, budget remaining,
    and percentage used.

    Examples:
        ct report budget -p <project-id>
    """
    from decimal import Decimal
    from rich.table import Table

    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.get("/reports/budget-burn/", params={"project_id": project})
        results = extract_results(data)

        if output_json:
            print_json(data if isinstance(data, dict) else results)
            return

        if not results:
            # Check if the project simply has no budget configured
            try:
                proj = client.get(f"/projects/{project}/")
                bt = proj.get("budget_type", "none")
                if bt == "none":
                    console.print("[yellow]This project has no budget configured.[/yellow]")
                    console.print("[dim]Set a budget with: ct project update <id> --budget-type hours --budget-amount <n>[/dim]")
                else:
                    console.print("[dim]No budget snapshots yet for this project.[/dim]")
            except Exception:
                console.print("[dim]No budget snapshots for this project.[/dim]")
            return

        console.print(f"\n[dim]Budget Burn-Down: project {project}[/dim]")

        table = Table(show_header=True, header_style="bold", title="Budget Burn-Down")
        table.add_column("Date", width=12)
        table.add_column("Hours", justify="right", width=10)
        table.add_column("Amount", justify="right", width=14)
        table.add_column("Remaining", justify="right", width=14)
        table.add_column("Used %", justify="right", width=8)

        for row in results:
            pct = row.get("budget_percent_used")
            pct_str = f"{float(pct):.0f}%" if pct is not None else "—"
            remaining = row.get("budget_remaining")

            # Color code remaining budget
            remaining_str = format_currency(remaining) if remaining is not None else "—"
            if remaining is not None and float(remaining) <= 0:
                remaining_str = f"[red]{remaining_str}[/red]"

            table.add_row(
                row.get("date", ""),
                format_duration(Decimal(str(row.get("total_hours", 0)))),
                format_currency(row.get("total_amount", 0)),
                remaining_str,
                pct_str,
            )

        console.print(table)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


# ─── Saved Reports ───────────────────────────────────────────────────


saved_app = typer.Typer(name="saved", help="Manage saved report configurations.")
app.add_typer(saved_app)


@saved_app.command("list")
def saved_list(
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """List saved report configurations.

    Shows your own saved reports plus any shared by teammates.
    """
    from rich.table import Table

    client = CrowdTimeClient(require_auth=True, require_org=True)

    try:
        data = client.get("/reports/saved/")
        results = extract_results(data)

        if output_json:
            print_json(results)
            return

        if not results:
            console.print("[dim]No saved reports.[/dim]")
            return

        table = Table(show_header=True, header_style="bold", title="Saved Reports")
        table.add_column("ID", width=36)
        table.add_column("Name", style="bold", width=25)
        table.add_column("Type", width=18)
        table.add_column("Shared", justify="center", width=8)
        table.add_column("Created By", width=20)

        for row in results:
            shared = "[green]Yes[/green]" if row.get("is_shared") else "[dim]No[/dim]"
            table.add_row(
                str(row.get("id", "")),
                row.get("name", ""),
                row.get("report_type", ""),
                shared,
                row.get("created_by_name", "") or "—",
            )

        console.print(table)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@saved_app.command("create")
def saved_create(
    name: str = typer.Option(..., "--name", "-n", help="Name for the saved report."),
    report_type: str = typer.Option(
        ..., "--type", "-t",
        help="Report type: time_detail, project_summary, team_utilization, client_invoice, budget_burn.",
    ),
    shared: bool = typer.Option(False, "--shared", "-s", help="Share with team members."),
    project: Optional[str] = typer.Option(None, "--project", "-p", help="Filter by project ID."),
    client_filter: Optional[str] = typer.Option(None, "--client", "-c", help="Filter by client ID."),
    from_date: Optional[str] = typer.Option(None, "--from", help="Default start date (YYYY-MM-DD)."),
    to_date: Optional[str] = typer.Option(None, "--to", help="Default end date (YYYY-MM-DD)."),
    group_by: Optional[str] = typer.Option(None, "--group-by", "-g", help="Default group_by."),
) -> None:
    """Create a saved report configuration.

    Saves filter presets for quick access later.

    Examples:
        ct report saved create -n "Q1 Client Billing" -t client_invoice --from 2026-01-01 --to 2026-03-31 --shared
        ct report saved create -n "My Project Hours" -t project_summary -p <project-id>
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    filters: dict = {}
    if project:
        filters["project_id"] = project
    if client_filter:
        filters["client_id"] = client_filter
    if from_date:
        filters["date_from"] = from_date
    if to_date:
        filters["date_to"] = to_date
    if group_by:
        filters["group_by"] = group_by

    payload = {
        "name": name,
        "report_type": report_type,
        "is_shared": shared,
        "filters": filters,
    }

    try:
        data = client.post("/reports/saved/", data=payload)
        console.print(f"[green]Saved report created:[/green] {data.get('name', name)} ({data.get('id', '')})")
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@saved_app.command("delete")
def saved_delete(
    report_id: str = typer.Argument(help="ID of the saved report to delete."),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation prompt."),
) -> None:
    """Delete a saved report configuration.

    Examples:
        ct report saved delete <report-id>
        ct report saved delete <report-id> --force
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    if not force:
        if not typer.confirm(f"Delete saved report {report_id[:8]}…?"):
            console.print("[dim]Cancelled.[/dim]")
            raise typer.Exit(0)

    try:
        client.delete(f"/reports/saved/{report_id}/")
        console.print("[green]Saved report deleted.[/green]")
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)


@saved_app.command("run")
def saved_run(
    report_id: str = typer.Argument(help="ID of the saved report to run."),
    from_date: Optional[str] = typer.Option(None, "--from", help="Override start date (YYYY-MM-DD)."),
    to_date: Optional[str] = typer.Option(None, "--to", help="Override end date (YYYY-MM-DD)."),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Run a saved report with its stored filters.

    Executes the saved report configuration and displays results.
    Use --from/--to to override the saved date range.

    Examples:
        ct report saved run <report-id>
        ct report saved run <report-id> --from 2026-04-01 --to 2026-04-30
        ct report saved run <report-id> --json
    """
    client = CrowdTimeClient(require_auth=True, require_org=True)

    params: dict = {}
    if from_date:
        params["date_from"] = from_date
    if to_date:
        params["date_to"] = to_date

    try:
        data = client.get(f"/reports/saved/{report_id}/run/", params=params)

        if output_json:
            print_json(data)
            return

        # Display based on report structure
        if "members" in data:
            # team_utilization or similar member-based report
            members = data.get("members", [])
            if data.get("totals"):
                _print_team_table(members)
            else:
                print_json(data)
        elif "clients" in data:
            # client_invoice
            from rich.table import Table as RichTable
            from decimal import Decimal

            clients = data.get("clients", [])
            table = RichTable(show_header=True, header_style="bold", title="Client Invoice Report")
            table.add_column("Client", min_width=20)
            table.add_column("Hours", justify="right", width=10)
            table.add_column("Amount", justify="right", width=12)
            table.add_column("Projects", justify="right", width=8)
            for c in clients:
                table.add_row(
                    c.get("client_name", ""),
                    format_duration(Decimal(str(c.get("total_hours", 0)))),
                    format_currency(Decimal(str(c.get("total_amount", 0)))),
                    str(c.get("project_count", 0)),
                )
            console.print(table)
        elif "results" in data or "entries" in data:
            # time_detail or project_summary
            results = extract_results(data)
            format_report(results, group_by="project")
        elif "snapshots" in data:
            # budget_burn
            print_json(data)
        else:
            # Fallback: show as JSON
            print_json(data)
    except APIError as e:
        format_error(e.message)
        raise typer.Exit(1)
