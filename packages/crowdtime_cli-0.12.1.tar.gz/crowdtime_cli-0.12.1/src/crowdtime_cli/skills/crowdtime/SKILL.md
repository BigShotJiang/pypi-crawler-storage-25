---
name: crowdtime
description: "CrowdTime CLI time tracking assistant. Use this skill whenever the user mentions time tracking, logging hours, starting or stopping timers, managing projects or tasks, generating time reports, checking work status, logging expenses, managing invoices, payroll, compensation, or anything related to the CrowdTime CLI tool (ct/crowdtime commands). Also trigger when users mention timesheets, billable hours, weekly summaries, project budgets, expenses, receipts, vendor payments, client contacts, payroll runs, salaries, hourly rates, compensation configs, or want to track what they worked on or spent money on. Even if they don't say 'CrowdTime' explicitly — if they're talking about tracking time, logging work, recording expenses, managing payroll, or checking hours in a context where the CrowdTime CLI is available, use this skill."
---

# CrowdTime CLI

CrowdTime is an AI-powered time tracking and expense management CLI. The primary commands are `crowdtime` and `ct` (short alias). This skill teaches you how to use the CLI to help users track time, log expenses, manage projects and client contacts, and generate reports and invoices.

## Before Using Any Command

Check if the CLI is installed and authenticated:

```bash
ct auth whoami
```

If not authenticated, guide the user through setup:
```bash
ct config set server.url https://api.crowdtime.lat  # or http://localhost:8001 for local dev
ct auth login                          # Opens browser for Google OAuth (default)
ct auth login --token <their-api-token>  # Or provide a token directly
ct auth login --no-browser             # Prompt for token (headless environments)
ct org switch <org-slug>
```

## Core Commands Quick Reference

### Status (default command)
```bash
ct              # Full dashboard: running timer, today's entries, weekly breakdown
ct status       # Same as bare ct
ct s            # Short alias
ct s --json     # Machine-readable output
```

### Timers
```bash
ct timer start "description" -p project-slug -t "task name"  # Start a timer
ct timer stop                                     # Stop the running timer
ct timer status                                   # Check running timer
ct timer edit -n "new description" -t "new task"  # Edit running timer without stopping
ct timer switch "new task" -p other-project       # Stop current, start new (atomic)
ct timer continue                                 # Resume last stopped entry as new timer
ct timer continue -b                              # Resume and override as billable
ct timer discard                                  # Discard without saving

# Short aliases
ct ts "working on API" -p backend    # timer start
ct tx                                # timer stop
ct t                                 # timer status
ct c                                 # timer continue
```

### Logging Time

**Options MUST come BEFORE positional arguments (duration, description).**

```bash
# Log time entries (all equivalent):
ct log -p project-slug 2h "code review"
ct log -p project-slug -t "Design" -d yesterday 2h30m "meeting"
ct log -p project-slug -b 1:30 "design work"

# Short alias — `ct l`:
ct l -p project-slug 2h "code review"
ct l -p project-slug -t "Research" -d yesterday 2h30m "meeting"
```

Other log commands:
```bash
ct log list --week                                  # This week's entries
ct log list --task "Design" --billable              # Filter by task + billable
ct log list --user <user-id>                        # See team member's entries (manager+)
ct log list --format csv                            # CSV with financial columns
ct log edit <entry-id> --duration 3h               # Edit an entry
ct log edit <entry-id> --task "Research"            # Change task
ct log delete <entry-id>                           # Delete an entry
ct log duplicate <entry-id>                        # Duplicate an entry (optionally override fields)
ct log bulk-delete <id1> <id2> <id3>               # Delete multiple entries at once
ct log save <entry-id>                             # Save entry as favorite template

# Short aliases
ct ll                                # log list (today)
ct ll --week                         # log list this week
ct ll --month                        # log list this month
ct ll -b                             # log list billable only
```

**Duration formats**: `2h`, `2h30m`, `2:30`, `150m`, `0.25d` (1 day = 8h), or plain number (hours)

**Date formats**: `today`, `yesterday`, `monday`..`sunday`, `last friday`, `2026-03-10`, `3/10`

### Clients
```bash
ct clients list                     # List all clients
ct clients show <id>                # Client details
ct clients create "Acme Corp"       # Create a client
ct clients create "Acme" --contact "John" --email john@acme.com --address-line1 "123 Main St" --city "NYC" --country "US"
ct clients archive <id>             # Archive a client

# Client contacts
ct clients contacts <id>            # List contacts for a client
ct clients add-contact <id> --name "Jane Doe" --email jane@acme.com --role "CTO" --primary --receives-invoices
ct clients remove-contact <id> <contact-id>
```

### Expenses
```bash
ct expense list                     # List expenses
ct expense list --from 2026-03-01 --to 2026-03-31 --billable
ct expense create --amount 49.99 "Domain renewal" --project acme-website --category "Software" --vendor "Namecheap" --billable
ct expense edit <id> --amount 59.99 --description "Domain + SSL renewal"
ct expense delete <id>
ct expense categories               # List expense categories
ct expense add-category "Travel"    # Create a new category

# Short alias
ct ex list                          # expense list
ct ex create --amount 25 "Lunch with client" --category "Meals" --billable
```

### Projects
```bash
ct projects list                    # List all projects
ct projects show <id>               # Project details
ct projects create "New Project" --client "Acme" --budget 100 --budget-type hours -b
ct projects create "New Project" --client "Acme" --billing-mode per_person  # Set billing mode
ct projects archive <id>            # Archive a project
ct projects switch <slug>           # Set default project

# Short alias
ct p                                # projects list
ct p -a                             # include archived
```

#### Project Members
```bash
ct projects update-member <project-id> <user-id> --role project_manager --rate 150  # Set per-project role & rate
ct projects add-members <project-id> --user <uid1> --user <uid2> --role member --rate 120  # Bulk add
```

#### Bulk Task Assignment
```bash
ct projects add-tasks <project-id> --task <tid1> --task <tid2>  # Bulk assign tasks to project
```

**Note:** `--client` on `projects create` accepts a client name. If the client doesn't exist yet, it will be auto-created.

**Billing modes:** `custom` (default), `per_task` (rate per task), `per_person` (rate per person).

**Rate waterfall** (order depends on billing mode):
- `custom`: Entry → ProjectMember → ProjectTask → Project → Task → Membership → User
- `per_task`: Entry → ProjectTask → Task → ProjectMember → Membership → User → Project (last)
- `per_person`: Entry → ProjectMember → Membership → User → ProjectTask → Task → Project (last)

#### Project Budget
```bash
ct projects budget <slug>           # View budget status (hours used, remaining, % spent)
ct projects budget <slug> --refresh # Refresh the budget snapshot before viewing
```

### Tasks
```bash
ct tasks list                       # List all org tasks
ct tasks list -p project-slug       # Filter by project
ct tasks create "Code Review" -p project-slug -b   # Create and assign to project
ct tasks presets                    # List available task presets
ct tasks apply-preset software_development -p project-slug  # Apply a preset
```

**Available presets:** `software_development`, `marketing_agency`, `design_studio`, `consulting`, `legal`, `accounting`

**Note:** `tasks create -p` creates the task at the org level AND assigns it to the specified project. The `-t` flag on `ct log create` and `ct timer start` accepts task names — if the task doesn't exist, it will be auto-created and assigned to the project.

### Reports
```bash
ct report --week                    # This week (default)
ct report --month                   # This month
ct report --last-month              # Last month (full)
ct report --quarter                 # This quarter (Q1/Q2/Q3/Q4)
ct report --last-quarter            # Last quarter (full)
ct report --today                   # Today
ct report --from 2026-03-01 --to 2026-03-15 -p project-slug
ct report -g day                    # Group by day (also: project, task, client)
ct report -f csv                    # Output as CSV (also: table, json, markdown)
ct report projects --month          # Project breakdown
ct report team --week               # Team utilization
ct report client --last-quarter     # Client billing for last quarter

# Saved reports
ct report saved list                # List saved report configs
ct report saved create -n "Q1 Billing" -t client_invoice --from 2026-01-01 --to 2026-03-31 --shared
ct report saved run <id>            # Run a saved report with stored filters
ct report saved run <id> --from 2026-04-01 --to 2026-04-30  # Override dates
ct report saved delete <id>         # Delete a saved report

# Short alias
ct r --week                         # report this week
```

### Insights (Dashboards)
```bash
ct insights projects                        # Project health: budget, burn rate, exhaustion
ct insights projects --quarter              # This quarter
ct insights projects --at-risk              # Only projects above budget alert threshold
ct insights team                            # Team utilization, capacity, timesheet status
ct insights team --week                     # This week
ct insights allocations                     # Who is working where: per-member per-project hours
ct insights allocations --week              # This week's allocations
ct insights financial                       # Revenue KPIs, AR aging, top clients (manager+)
ct insights financial --quarter --compare   # Compare with previous quarter
ct insights financial --last-month          # Last month
ct insights profitability                   # Revenue, cost, margin by project (manager+)
ct insights profitability --by-client       # Group by client instead of project
ct insights profitability --quarter         # This quarter
```

### AI Features
```bash
ct ai suggest                            # Get AI suggestions based on your patterns
ct ai summarize --week                   # Weekly summary
ct ai summarize --for standup            # Formatted for standup
ct ai summarize --for slack --copy       # Formatted for Slack, copied to clipboard
```

### Favorites
```bash
ct favorites list                        # List saved templates
ct favorites create "Daily standup" -p meetings -t standup
ct favorites start <id>                  # Start timer from template
ct favorites start <id> -n "custom note" # Start with overridden description
ct favorites delete <id>
```

### Timesheets
```bash
ct timesheet list                       # List your timesheets
ct timesheet list --status submitted    # Filter by status
ct timesheet submit --from 2026-03-10 --to 2026-03-16  # Submit full week
ct timesheet submit --from 2026-03-30 --to 2026-03-31  # Partial week (end-of-month split)
ct timesheet recall <id>                # Recall submitted timesheet back to draft (--force to skip confirm)
ct timesheet approve <id>               # Approve all project portions at once (manager+)
ct timesheet approve <id> --project <project-id>  # Approve one project's portion (PM for that project)
ct timesheet approve <id> --force       # Skip confirmation prompt
ct timesheet reject <id> --notes "Missing entries for Wednesday"  # Reject with notes
ct timesheet reject <id> --project <project-id> --notes "Hours too high"  # Reject one project portion
ct timesheet approvals <id>             # Show per-project approval status
ct timesheet team                       # Team overview with capacity % (manager+)
ct timesheet team --from 2026-03-10 --to 2026-03-16  # Custom period
ct timesheet team --last-week           # Last week's overview
ct timesheet bulk-approve <id1> <id2>   # Approve multiple timesheets at once (manager+)
ct timesheet bulk-approve <id1> <id2> --project <project-id>  # Bulk-approve for a specific project (PM)
ct timesheet bulk-reject <id1> <id2> --notes "reason"  # Reject multiple timesheets (manager+)
ct timesheet history <id>               # Full audit trail (submissions, approvals, rejections)
ct timesheet viewable-users             # List users whose timesheets you can view/approve
ct timesheet compliance                 # Current week compliance report (manager+)
ct timesheet compliance --last-week     # Last week's compliance
ct timesheet compliance --month         # Current month compliance
ct timesheet compliance --last-month    # Last month's compliance
```

### Invoices
```bash
ct invoice list                         # List all invoices
ct invoice list --status draft          # Filter by status
ct invoice list --due-from 2026-04-01 --due-to 2026-04-30  # Filter by due date
ct invoice summary                      # Aggregated stats: counts, outstanding, overdue, paid
ct invoice aging                        # Overdue aging report: buckets 1-30d, 31-60d, 61-90d, 90+d
ct invoice aging --client <id>          # Aging for a specific client
ct invoice show <id>                    # Invoice details with line items
ct invoice create --client <id> --period last-month --payment-terms net30  # From time entries
ct invoice create --client <id> --period last-month --group-by user        # Group by team member
ct invoice create-blank --client <id> --issue-date today --payment-terms net30  # Empty draft
ct invoice update <id> --terms "Wire to IBAN XX" --notes "March"  # Edit draft fields
ct invoice update <id> --subject "April Dev" --currency EUR --tax-rate <id>  # More fields
ct invoice add-item <id> --desc "Development" --qty 40 --rate 150  # Add line item
ct invoice add-item <id> --desc "Support" --qty 10 --rate 100 --discount-type hours --discount-value 2  # With discount
ct invoice update-item <inv-id> <item-id> --quantity 20 --unit-price 175  # Edit a line item
ct invoice remove-item <inv-id> <item-id>           # Remove a line item from draft
ct invoice send <id>                    # Mark as sent (sends to primary contact)
ct invoice send <id> --to <contact-id>  # Send to specific contact(s)
ct invoice send <id> --to <id1> --to <id2> --cc <id3>  # Multiple recipients + CC
ct invoice pay <id> --amount 1500      # Record payment
ct invoice void <id> -r "Duplicate"    # Void an invoice
ct invoice duplicate <id>              # Duplicate an existing invoice
ct invoice pdf <id>                     # Download invoice as PDF
ct invoice pdf <id> --output ~/march.pdf  # Download to specific path
ct invoice uninvoiced                   # Show uninvoiced billable entries by client
```

### Tax Rates
```bash
ct invoice tax-rates                    # List organization tax rates
ct invoice tax-rates create --name "VAT" --rate 21.0  # Create a tax rate
ct invoice tax-rates create --name "Sales Tax" --rate 8.25 --default  # Set as default
ct invoice tax-rates update <id> --rate 22.0          # Update rate
ct invoice tax-rates update <id> --no-active          # Deactivate
ct invoice tax-rates delete <id>                      # Delete a tax rate
```

### Recurring Invoices
```bash
ct invoice recurring list                          # List all recurring templates
ct invoice recurring show <id>                     # Template details + line items
ct invoice recurring create --name "Monthly Acme" --client <id> --schedule monthly --next-run 2026-05-01
ct invoice recurring create --name "Weekly" --client <id> --schedule weekly --next-run 2026-04-07 --auto-send
ct invoice recurring update <id> --schedule monthly --next-run 2026-06-01
ct invoice recurring update <id> --inactive        # Deactivate a template
ct invoice recurring delete <id>                   # Delete a template
ct invoice recurring generate-now <id>             # Manually trigger generation
```

### Retainers
```bash
ct invoice retainer list                           # List all retainers
ct invoice retainer show <id>                      # Retainer details + balance
ct invoice retainer withdraw <id> -i <inv-id> -a 2000  # Apply retainer credit to invoice
ct invoice retainer withdrawals <id>               # View withdrawal history
ct invoice retainer reverse-withdrawal <id> -w <wd-id> -r "reason"  # Reverse a withdrawal
```

### Billing
```bash
ct billing              # Show subscription status (plan, seats, pricing, next bill)
ct billing status       # Same as bare ct billing
ct billing checkout     # Start subscription via Stripe Checkout in browser (owner only)
ct billing checkout annual  # Start with annual plan
ct billing portal       # Open Stripe billing portal in browser (admin+ only)
ct billing plan annual  # Switch to annual billing (owner only)
ct billing plan monthly # Switch to monthly billing (owner only)
ct billing reactivate   # Undo a pending cancellation (owner only)
ct billing events       # View billing event audit log (owner only)
ct billing events -n 50 # Show last 50 events

# Short alias
ct b                    # billing status
```

### Payroll
```bash
ct payroll                              # Current month summary
ct payroll summary --period 2026-03     # Summary for a specific month
ct payroll members                      # List members with compensation config
ct payroll show alice@company.com       # One member's compensation details
ct payroll set-rate alice@co.com 75.00  # Set hourly rate (effective 1st of month)
ct payroll set-rate alice@co.com 90 --effective 2026-04-01  # Future rate change
ct payroll set-salary bob@co.com 5000   # Set monthly salary
ct payroll run                          # Run payroll liquidation (current month)
ct payroll run --dry-run                # Preview without creating
ct payroll run --period 2026-02         # Run for specific month
ct payroll periods                      # List all payroll periods
ct payroll period <period-id>           # Period detail with breakdown
ct payroll approve <period-id>          # Approve a calculated period
ct payroll mark-paid <period-id> alice@co.com --method bank_transfer --ref TXN-123
ct payroll mark-paid <period-id> --all --method bank_transfer --ref BATCH-456
ct payroll payments                     # List all payments
ct payroll payments --period 2026-03 --status paid
```

**Access**: Only admins and owners can access payroll. Regular members cannot see any payroll data.

**Compensation types**: `hourly` (gross = hours × rate) or `salary` (fixed monthly amount, no proration).

**Workflow**: Configure compensation → Run liquidation → Approve → Mark paid.

### Team (Direct Reports)
```bash
ct team list                                           # All direct-report assignments (admin+) or your own
ct team list --manager alice@company.com               # Filter to a specific manager
ct team reports                                        # Show YOUR direct reports
ct team reports --manager alice@company.com            # Someone else's reports (admin+)
ct team assign alice@co.com bob@co.com                 # Assign bob as a direct report of alice (admin+)
ct team assign alice@co.com bob@co.com carol@co.com    # Assign multiple in one call
ct team assign alice@co.com --all                      # Assign every active org member as her reports
ct team unassign alice@co.com bob@co.com               # Remove one or more reports (by member, not assignment id)
ct team unassign alice@co.com --all                    # Clear all her direct reports
ct team set alice@co.com --member bob@co.com --member carol@co.com  # Declarative: replace the full set
ct team set alice@co.com                               # Clear all (zero --member flags)
ct team set alice@co.com --all                         # Set her reports to the full org
```

All mutating commands (`assign`, `unassign`, `set`) hit the atomic `bulk-set` endpoint — changes apply in a single transaction and the response reports `added` / `removed` / `skipped` buckets.

**Visibility rule**: a `manager` or `project_manager` sees time entries / timesheets / team reports only for users in their visible set, which is the union of:
1. **Direct reports** — members assigned via `ct team assign`.
2. **PM-project members** — users of projects where the caller holds `project_role = project_manager`.

A `manager` with **zero** assignments and **zero** PM projects sees only their own entries. `admin` and `owner` always see everything. This is the Harvest-style assignment model: assign *people* to a manager for cross-project visibility, or assign them as a PM on specific projects for project-scoped visibility.

### Organizations
```bash
ct org list                             # List your organizations
ct org show                             # Show current org details (currency, week start, settings)
ct org create "My Company"              # Create a new organization
ct org switch <slug>                    # Switch active organization
ct org members                          # List members (manager+ only)
ct org invitations                      # List pending invitations
ct org invite user@example.com -r member
ct org invite client@acme.com -r viewer              # External client stakeholder (read-only)
ct org invite pm@company.com -r project_manager      # Project manager (no financial access)
ct org invite billing@company.com -r manager          # Account manager (full financial access)
ct org resend-invite <invitation-id>                  # Resend a pending invitation
ct org revoke-invite <invitation-id>                  # Cancel a pending invitation
```

**Role hierarchy** (lowest → highest):
- **viewer** — external client stakeholder, read-only access scoped to assigned projects
- **member** — can log time, manage own entries
- **project_manager** — manage projects, tasks, timesheets, team time; no financial data
- **manager** (Account Manager) — everything project_manager does + invoices, rates, clients, billing
- **admin** — manage org settings, members, integrations
- **owner** — full control, can delete org

### Aliases
```bash
ct aliases                              # Show all shortcut commands in a table
```

### Configuration
```bash
ct config list                          # Show all config
ct config set server.url https://...    # Set server URL
ct config set defaults.project myproj   # Set default project
ct config set defaults.daily_target 7h  # Set daily target
ct config edit                          # Open in editor
ct config set update_check.enabled false  # Disable the daily update-check warning
```

### Version
```bash
ct version                              # Show installed + latest CLI version (hits PyPI)
ct version --json                       # Machine-readable output
ct --version                            # Print just the installed version (no network)
```

The CLI also runs a once-per-12-hours background update check after every command and prints a one-line hint on stderr when a newer version exists. Opt out with `CROWDTIME_NO_VERSION_CHECK=1` or `ct config set update_check.enabled false`.

## Common Workflows

Read `references/workflows.md` for detailed multi-step workflow patterns including:
- Daily time tracking routines
- End-of-week reporting
- Project setup and management
- Project setup and configuration (billing modes, task presets, bulk member/task assignment)
- Bulk time entry for past days
- Team management and timesheets
- Timesheet submission and approval
- Expense tracking and categorization
- Invoicing and billing (including expenses)
- Payroll management (compensation, liquidation, payments)
- Managing client contacts
- Checking project budgets
- Retainer management and withdrawals

## Complete Command Reference

Read `references/commands.md` for the full reference of every command, subcommand, flag, and option available in the CLI.

## Guidelines for Helping Users

1. **Always check status first** — run `ct s --json` to understand current state (running timer, today's entries) before suggesting actions
2. **Always use explicit commands** — always construct the full `ct log`, `ct timer start`, etc. commands with proper flags. Never use magic routing (`ct "natural language"`) or `ct ai parse` — you are an LLM fully capable of constructing the correct command yourself
3. **Always ask for the project if missing** — if the user asks to log time without specifying a project, ASK them which project before running the command. Run `ct p --json` to list available projects and present them as options. Never log time without a project unless the user has a default set (check `ct config get defaults.project`). If there's only one project available, use it automatically without asking
4. **Project identifiers** — the `-p` flag on `ct log`, `ct timer start`, etc. accepts a project **UUID**, **code** (e.g. `PROJ1`), or **name**. The CLI auto-resolves names and codes to UUIDs. If ambiguous, use the UUID from `ct p --json`
5. **Task identifiers** — the `-t` flag accepts a task **name** or **UUID**. The CLI will auto-resolve names to UUIDs. If a task doesn't exist, it will be auto-created and assigned to the project. **Prefer using tasks when logging time** — they make reports and summaries much more useful. If the user doesn't specify a task but describes their work (e.g. "code review", "meeting", "design"), suggest an appropriate task name
6. **Flag ordering for `ct log` / `ct l`** — ALL options (`-p`, `-d`, `-b`, `-t`) MUST come BEFORE the positional arguments (duration, description). Example: `ct log -p myproject -t "Research" -d yesterday 2h "description"`. Getting this wrong causes errors
7. **Use `--json` for parsing** — when you need to process output programmatically, add `--json` to any command
8. **Respect running timers** — check `ct t --json` before starting a new timer; use `ct timer switch` to atomically swap
9. **Default project** — if the user frequently logs to the same project, suggest `ct projects switch <slug>` to set a default
10. **Date intelligence** — the CLI understands natural dates; use `yesterday`, `last friday`, etc. rather than computing ISO dates
11. **Confirm destructive actions** — `delete`, `discard`, and `archive` commands ask for confirmation; use `--force` only when the user explicitly wants to skip
12. **Output formats** — `ct report` supports `table`, `json`, `csv`, and `markdown` via `--format`; suggest `csv` for spreadsheet export, `markdown` for docs
13. **Ask for details when vague** — if the user's request is ambiguous (e.g. "log 2 hours" with no description or project), ask them for the missing context rather than guessing. It's better to ask one clarifying question than to log something wrong that needs to be edited or deleted
14. **Expenses** — when the user mentions expenses, receipts, or purchases, use the `ct expense` commands. Always suggest a category and ask if the expense is billable. If recording a billable expense for a client project, always set `--project` and `--billable` so it gets included automatically when the client is invoiced
15. **Invoices include expenses** — when creating invoices with `ct invoice create --period`, billable expenses from the same period are automatically included as line items. Mention this to users so they know their expenses will appear on the invoice. Invoices can be grouped by `project`, `task`, `user`, `date`, or `none` via `--group-by`. Line items support discounts (`--discount-type fixed|percent|hours --discount-value N`)
16. **Client contacts** — use `ct clients contacts` and `ct clients add-contact` to manage multiple contacts per client. Set `--primary` for the main point of contact. Use `--receives-invoices` to flag contacts who should receive invoice emails
17. **Payroll** — payroll data is strictly confidential. Only HR managers, admins, and owners can access it. When the user asks about payroll, always use the `ct payroll` commands. Compensation types are `hourly` (rate × hours) or `salary` (fixed monthly). Rate changes are always effective from the 1st of a month. The payroll workflow is: configure compensation → run liquidation → approve → mark paid
