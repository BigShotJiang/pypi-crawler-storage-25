# CrowdTime CLI — Complete Command Reference

Every command, subcommand, argument, flag, and option in the CrowdTime CLI.

## Table of Contents

- [Global Behavior](#global-behavior)
- [ct (bare / status)](#ct-bare--status)
- [ct auth](#ct-auth)
- [ct timer](#ct-timer)
- [ct log](#ct-log)
- [ct clients](#ct-clients)
- [ct expense](#ct-expense)
- [ct billing](#ct-billing)
- [ct payroll](#ct-payroll)
- [ct projects](#ct-projects)
- [ct tasks](#ct-tasks)
- [ct report](#ct-report)
- [ct ai](#ct-ai)
- [ct favorites](#ct-favorites)
- [ct org](#ct-org)
- [ct config](#ct-config)
- [ct timesheet](#ct-timesheet)
- [ct invoice](#ct-invoice)
- [ct insights](#ct-insights)
- [ct team](#ct-team)
- [ct version](#ct-version)
- [ct aliases](#ct-aliases)
- [Short Aliases](#short-aliases)

---

## Global Behavior

- Entry points: `crowdtime` and `ct` (identical)
- Config file: `~/.crowdtime/config.toml`
- Token storage: OS keychain (via `keyring`), fallback to `~/.crowdtime/credentials`
- All org-scoped commands require: authenticated user + active organization
- `--json` flag on most commands outputs machine-readable JSON

### Magic Routing

Any unrecognized first argument routes to AI parsing:
```bash
ct "2h on project alpha code review"   # → ct ai parse "..."
```

---

## ct (bare / status)

Shows full status dashboard.

```
ct
ct status [--json]
ct s [--json]           # alias
```

**Output includes:**
- Authenticated user and current organization
- Running timer (if any) with elapsed HH:MM:SS
- Today's entries with progress bar toward daily target
- This week's breakdown with daily hour bars

**Endpoints called:**
- `GET /api/v1/auth/me/`
- `GET /time/running/`
- `GET /time/daily/{today}/`
- `GET /time/weekly/{monday}/`

---

## ct auth

### ct auth login

```
ct auth login [--token/-t TOKEN] [--no-browser] [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `--token`, `-t` | string | API token (skips browser login) |
| `--no-browser` | flag | Prompt for token instead of opening browser |
| `--json` | flag | JSON output |

- Default (no flags): opens browser for Google OAuth login
- `--token`: provide an API token directly
- `--no-browser`: prompts for token interactively (useful for headless environments)
- Stores token in OS keychain with file fallback
- Validates by calling `GET /api/v1/auth/me/`

### ct auth logout

```
ct auth logout
```

Removes stored credentials from keychain and file.

### ct auth whoami

```
ct auth whoami [--json]
```

Shows: name, email, timezone, current organization.

### ct auth data-export

```
ct auth data-export [--output/-o FILE] [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `--output`, `-o` | string | Write export to file (otherwise stdout) |
| `--json` | flag | JSON output (default for this command) |

Exports all personal data (GDPR data portability): time entries, timesheets, favorites, expenses, API tokens, AI logs, etc.

- Endpoint: `GET /api/v1/auth/data-export/`

### ct auth delete-account

```
ct auth delete-account [--force/-f] [--cancel] [--status] [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `--force`, `-f` | flag | Skip confirmation prompt |
| `--cancel` | flag | Cancel a pending account deletion |
| `--status` | flag | Check deletion status |
| `--json` | flag | JSON output |

Schedules account for permanent deletion after 30-day grace period. Requires password confirmation (or `confirm=true` for OAuth-only accounts). Cancel anytime during grace period with `--cancel`.

- Request deletion: `POST /api/v1/auth/delete-account/`
- Cancel deletion: `DELETE /api/v1/auth/delete-account/`
- Check status: `GET /api/v1/auth/delete-account/`

---

## ct timer

### ct timer start

```
ct timer start [DESCRIPTION] [options]
```

| Argument/Option | Type | Description |
|-----------------|------|-------------|
| `DESCRIPTION` | string (optional) | What you're working on |
| `--project`, `-p` | string | Project slug or UUID |
| `--task`, `-t` | string | Task name or UUID (auto-creates and assigns if needed) |
| `--billable`, `-b` | flag | Mark as billable |
| `--no-billable`, `-B` | flag | Mark as non-billable |
| `--json` | flag | JSON output |

- Fails if a timer is already running (use `switch` instead)
- Uses default project from config if `--project` not specified
- Endpoint: `POST /time/start/`

### ct timer stop

```
ct timer stop [--note/-n NOTE] [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `--note`, `-n` | string | Add a note to the completed entry |
| `--json` | flag | JSON output |

- Returns 404 if no timer running
- Response includes a `warning` field when the timer was capped at MAX_TIMER_HOURS (12h)
- Endpoint: `POST /time/stop/`

### ct timer status

```
ct timer status [--json]
```

Shows running timer with elapsed HH:MM:SS, description, project, task, billable status. The API response includes an `elapsed_seconds` computed field (seconds since timer started; null when not running).
Endpoint: `GET /time/running/`

### ct timer edit

```
ct timer edit [options]
```

| Option | Type | Description |
|--------|------|-------------|
| `--description`, `-n` | string | New description/notes |
| `--project`, `-p` | string | New project slug or UUID |
| `--task`, `-t` | string | New task name or UUID |
| `--billable`, `-b` | flag | Mark as billable |
| `--no-billable`, `-B` | flag | Mark as non-billable |
| `--json` | flag | JSON output |

- Edits the currently running timer without stopping it
- Fails if no timer is running
- At least one change must be specified
- Endpoint: `PATCH /time/{id}/`

### ct timer switch

```
ct timer switch [DESCRIPTION] [options]
```

Same arguments and options as `timer start`. Atomically stops the current timer and starts a new one.

### ct timer continue

```
ct timer continue [--note/-n NOTE] [--billable/-b] [--no-billable/-B] [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `--note`, `-n` | string | Override or add a description |
| `--billable`, `-b` | flag | Override billable status (mark billable) |
| `--no-billable`, `-B` | flag | Override billable status (mark non-billable) |
| `--json` | flag | Output as JSON |

Starts a new timer with the same project, task, and description as the most recently stopped entry. Great for resuming after a break. Use `--billable`/`--no-billable` to override the original entry's billable status.

- **Endpoint:** `GET /time/` (fetch last entry) + `POST /time/start/`
- **Alias:** `ct c` (e.g. `ct c -b` to continue as billable)

### ct timer discard

```
ct timer discard [--force/-f]
```

| Option | Type | Description |
|--------|------|-------------|
| `--force`, `-f` | flag | Skip confirmation prompt |

Discards the running timer without saving any time entry.

---

## ct log

**Bare `ct log` (no arguments)** lists today's entries (same as `ct log list`).

`ct log` with options/args auto-routes to `ct log create` — all three forms below are equivalent:
- `ct log -p proj 2h "work"`
- `ct log create -p proj 2h "work"`
- `ct l -p proj 2h "work"`

### ct log create

```
ct log [create] [OPTIONS] DURATION [DESCRIPTION]
```

**IMPORTANT: Options MUST come BEFORE positional arguments (duration, description).** This is a Typer/Click constraint.

| Argument/Option | Type | Description |
|-----------------|------|-------------|
| `DURATION` | string (required) | Time spent: `2h`, `2h30m`, `2:30`, `150m`, `0.25d`, or number |
| `DESCRIPTION` | string (optional) | What you worked on |
| `--project`, `-p` | string | Project slug or UUID |
| `--task`, `-t` | string | Task name or UUID (auto-creates and assigns if needed) |
| `--date`, `-d` | string | Date (default: today) |
| `--billable`, `-b` | flag | Billable |
| `--no-billable`, `-B` | flag | Non-billable |
| `--json` | flag | JSON output |

**Usage examples:**
```bash
ct log -p crowdtime-dev 2h "code review"
ct log -p crowdtime-dev -t "Research" -d yesterday 2h30m "meeting"

# Short alias (ct l):
ct l -p crowdtime-dev 2h "code review"
ct l -p crowdtime-dev -t "Design" 1:30 "wireframes"
```

**Duration formats:**
| Format | Example | Result |
|--------|---------|--------|
| Hours | `2h` | 2.0 hours |
| Hours + minutes | `2h30m` | 2.5 hours |
| HH:MM | `2:30` | 2.5 hours |
| Minutes | `150m` | 2.5 hours |
| Days | `0.25d` | 2.0 hours (1d = 8h) |
| Decimal | `2.5` | 2.5 hours |

**Date formats:**
| Format | Example |
|--------|---------|
| Keywords | `today`, `yesterday` |
| Day names | `monday`, `tue`, `fri` |
| Last + day | `last friday` |
| ISO | `2026-03-10` |
| US short | `3/10`, `03/10/2026` |

Endpoint: `POST /time/`

### ct log show

```
ct log show ENTRY_ID [--json]
```

Shows detailed view of a single time entry: ID, date, project, task, description, duration, billable status, source, user, created timestamp.
Endpoint: `GET /time/{id}/`

### ct log edit

```
ct log edit ENTRY_ID [options]
```

| Option | Type | Description |
|--------|------|-------------|
| `--duration` | string | New duration |
| `--description` | string | New description |
| `--project`, `-p` | string | New project |
| `--task`, `-t` | string | New task (name or UUID) |
| `--date`, `-d` | string | New date |
| `--billable`, `-b` | flag | Set billable |
| `--no-billable`, `-B` | flag | Set non-billable |
| `--json` | flag | JSON output |

Only provided fields are updated. Endpoint: `PATCH /time/{id}/`

### ct log delete

```
ct log delete ENTRY_ID [--force/-f]
```

Requires confirmation unless `--force`. Endpoint: `DELETE /time/{id}/`

### ct log duplicate

```
ct log duplicate ENTRY_ID [options]
```

Duplicates an existing time entry. Copies project, task, description, duration, and billable status. Defaults to today's date.

| Option | Type | Description |
|--------|------|-------------|
| `--date`, `-d` | string | Date for new entry (default: today) |
| `--duration` | string | Override duration |
| `--description` | string | Override description |
| `--json` | flag | JSON output |

Endpoint: `GET /time/{id}/` (fetch source) then `POST /time/` (create copy)

### ct log list

```
ct log list [options]
```

| Option | Type | Description |
|--------|------|-------------|
| `--today` | flag | Show today's entries |
| `--yesterday` | flag | Show yesterday's entries |
| `--date`, `-d` | string | Specific date |
| `--week`, `-w` | flag | This week |
| `--month`, `-m` | flag | This month |
| `--from` | string | Start date for range |
| `--to` | string | End date for range |
| `--project`, `-p` | string | Filter by project |
| `--task`, `-t` | string | Filter by task name or ID |
| `--billable/-B` | flag | Filter billable / non-billable entries |
| `--user`, `-u` | string | Filter by user ID (manager+ only) |
| `--format` | string | Output: `table`, `json`, `csv` |
| `--json` | flag | JSON output |

CSV output includes financial columns: `hourly_rate`, `billable_amount`.

Endpoint: `GET /time/`

### ct log bulk-delete

```
ct log bulk-delete ID1 ID2 ... [--force/-f] [--json]
```

Delete multiple time entries at once. Locked entries and entries on submitted/approved timesheets are skipped automatically. Reports deleted and skipped counts.

| Option | Type | Description |
|--------|------|-------------|
| `--force`, `-f` | flag | Skip confirmation |
| `--json` | flag | JSON output |

Endpoint: `POST /time/bulk-delete/`

### ct log save

```
ct log save ENTRY_ID [--json]
```

| Argument/Option | Type | Description |
|-----------------|------|-------------|
| `ENTRY_ID` | string (required) | UUID of the time entry to save as a favorite |
| `--json` | flag | JSON output |

Saves an existing time entry as a favorite template. Copies the entry's project, task, description, and billable status into a new favorite. Useful for turning a one-off entry into a reusable shortcut.

Endpoint: `GET /time/{id}/` (fetch entry) then `POST /favorites/` (create favorite)

---

## ct clients

### ct clients list

```
ct clients list [--archived/-a] [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `--archived`, `-a` | flag | Include archived clients |
| `--json` | flag | JSON output |

Shows: ID, Name, Contact, Projects count, Status.
Endpoint: `GET /clients/`

### ct clients show

```
ct clients show CLIENT_ID [--json]
```

Shows: ID, name, currency, contact info, status.
Endpoint: `GET /clients/{id}/`

### ct clients create

```
ct clients create NAME [options]
```

| Option | Type | Description |
|--------|------|-------------|
| `--currency` | string | Currency code (e.g. USD) |
| `--contact` | string | Contact person name |
| `--email` | string | Contact email |
| `--address-line1` | string | Street address |
| `--address-line2` | string | Suite, unit, etc. |
| `--city` | string | City |
| `--state` | string | State or province |
| `--postal-code` | string | Postal / ZIP code |
| `--country` | string | Country |
| `--json` | flag | JSON output |

Endpoint: `POST /clients/`

### ct clients edit

```
ct clients edit CLIENT_ID [options]
```

| Option | Type | Description |
|--------|------|-------------|
| `--name` | string | New client name |
| `--currency` | string | Currency code (e.g. EUR) |
| `--contact` | string | Contact person name |
| `--email` | string | Contact email |
| `--address-line1` | string | Street address |
| `--city` | string | City |
| `--state` | string | State or province |
| `--postal-code` | string | Postal / ZIP code |
| `--country` | string | Country |
| `--json` | flag | JSON output |

At least one option is required. Endpoint: `PATCH /clients/{id}/`

### ct clients archive

```
ct clients archive CLIENT_ID [--force/-f]
```

Soft-archives the client. Requires confirmation unless `--force`.
Endpoint: `DELETE /clients/{id}/`

### ct clients contacts

```
ct clients contacts CLIENT [--json]
```

Lists all contacts for a client. Shows: Name, Email, Phone, Role, Primary status.
Endpoint: `GET /clients/{id}/contacts/`

### ct clients add-contact

```
ct clients add-contact CLIENT --name NAME [options]
```

| Option | Type | Description |
|--------|------|-------------|
| `--name` | string (required) | Contact person name |
| `--email` | string | Contact email address |
| `--phone` | string | Contact phone number |
| `--role` | string | Contact's role (e.g. "CTO", "Billing Manager") |
| `--primary` | flag | Set as primary contact |
| `--receives-invoices` | flag | Contact receives invoice emails |
| `--json` | flag | JSON output |

Endpoint: `POST /clients/{id}/contacts/`

### ct clients remove-contact

```
ct clients remove-contact CLIENT CONTACT_ID [--force/-f]
```

| Option | Type | Description |
|--------|------|-------------|
| `--force`, `-f` | flag | Skip confirmation prompt |

Removes a contact from the client. Requires confirmation unless `--force`.
Endpoint: `DELETE /clients/{id}/contacts/{contact_id}/`

---

## ct expense

Short alias: `ct ex`

### ct expense list

```
ct expense list [options]
```

| Option | Type | Description |
|--------|------|-------------|
| `--from` | string | Start date for range |
| `--to` | string | End date for range |
| `--project`, `-p` | string | Filter by project |
| `--category` | string | Filter by category |
| `--billable` | flag | Only billable expenses |
| `--invoiced` | flag | Only invoiced expenses |
| `--json` | flag | JSON output |

Shows: ID, Date, Description, Amount, Category, Project, Billable, Invoiced.
Endpoint: `GET /expenses/`

### ct expense show

```
ct expense show EXPENSE_ID [--json]
```

Shows full expense details: description, amount, date, project, category, vendor, billable/invoiced status, notes, receipt URL.
Endpoint: `GET /expenses/<id>/`

### ct expense create

```
ct expense create --amount AMOUNT DESCRIPTION [options]
```

**IMPORTANT: `--amount` and other options MUST come BEFORE the positional description argument.**

| Argument/Option | Type | Description |
|-----------------|------|-------------|
| `DESCRIPTION` | string (required) | What the expense is for |
| `--amount` | float (required) | Expense amount |
| `--project`, `-p` | string | Project slug or UUID |
| `--category` | string | Expense category name |
| `--vendor` | string | Vendor or merchant name |
| `--date`, `-d` | string | Date (default: today) |
| `--billable`, `-b` | flag | Mark as billable |
| `--notes` | string | Additional notes |
| `--receipt-url` | string | URL to receipt image |
| `--json` | flag | JSON output |

**Usage examples:**
```bash
ct expense create --amount 49.99 "Domain renewal" --project acme-website --category "Software" --billable
ct ex create --amount 125 "Client lunch" --category "Meals" --vendor "La Trattoria" --billable --notes "Q1 planning lunch"
ct ex create --amount 29.99 "Adobe subscription" -p design-project --category "Software" -d yesterday -b
```

Endpoint: `POST /expenses/`

### ct expense edit

```
ct expense edit EXPENSE_ID [options]
```

| Option | Type | Description |
|--------|------|-------------|
| `--amount` | float | New amount |
| `--description` | string | New description |
| `--project`, `-p` | string | New project |
| `--category` | string | New category |
| `--vendor` | string | New vendor |
| `--date`, `-d` | string | New date |
| `--billable`, `-b` | flag | Set billable |
| `--notes` | string | New notes |
| `--json` | flag | JSON output |

Only provided fields are updated. Endpoint: `PATCH /expenses/{id}/`

### ct expense delete

```
ct expense delete EXPENSE_ID [--force/-f]
```

| Option | Type | Description |
|--------|------|-------------|
| `--force`, `-f` | flag | Skip confirmation prompt |

Requires confirmation unless `--force`. Endpoint: `DELETE /expenses/{id}/`

### ct expense categories

```
ct expense categories [--json]
```

Lists all expense categories for the organization.
Endpoint: `GET /expenses/categories/`

### ct expense add-category

```
ct expense add-category NAME [--json]
```

Creates a new expense category at the organization level.
Endpoint: `POST /expenses/categories/`

---

## ct billing

Short alias: `ct b`

### ct billing (bare / status)

```
ct billing [--json]
ct billing status [--json]
ct b [--json]           # alias
```

Shows subscription status in a Rich panel: status, plan (monthly/annual), seat count, base price, per-seat price, total monthly cost, next billing date, and next billing amount.

**Status colors:**
| Status | Color |
|--------|-------|
| ACTIVE | green |
| TRIALING | blue |
| PAST_DUE, UNPAID | red |
| CANCELED, PAUSED | yellow |

Handles 402 (subscription inactive) and 404 (no subscription) gracefully.

Endpoint: `GET /billing/`

### ct billing portal

```
ct billing portal [--json]
```

Opens the Stripe Customer Portal in the default browser. Allows updating payment methods, viewing Stripe invoices, and managing the subscription.

- Requires **admin+** role (API enforces this; shows friendly error on 403)
- Prints the portal URL for manual access if the browser doesn't open
- `--json` outputs `{"portal_url": "..."}` instead of opening the browser

Endpoint: `POST /billing/portal/`

### ct billing checkout

```
ct billing checkout [monthly|annual] [--json]
```

Opens Stripe Checkout in the browser to start a new subscription (with free trial). Defaults to monthly plan.

- Requires **owner** role
- Opens the Stripe-hosted checkout page in the default browser
- After checkout, redirects to the billing settings page
- `--json` outputs `{"checkout_url": "..."}` instead of opening the browser
- Errors if the organization already has an active subscription

Endpoint: `POST /billing/checkout/`

### ct billing plan

```
ct billing plan <monthly|annual> [--json]
```

Switches the billing plan between monthly and annual. The change takes effect immediately with prorated credit for the remainder of the current period.

- Requires **owner** role
- Shows the new billing amount after switching
- Errors if already on the target plan

Endpoint: `PATCH /billing/plan/`

### ct billing reactivate

```
ct billing reactivate [--json]
```

Undoes a pending cancellation so the subscription continues at the end of the current billing period.

- Requires **owner** role
- Only works when `cancel_at_period_end` is true
- Shows the next renewal date after reactivation

Endpoint: `POST /billing/reactivate/`

### ct billing events

```
ct billing events [--limit/-n N] [--json]
```

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `--limit`, `-n` | int | 20 | Number of events to show |
| `--json` | flag | | JSON output |

Shows recent Stripe webhook events processed for this organization. Each event shows date, event type, and processing status (OK, FAILED, PENDING).

- Requires **owner** role

Endpoint: `GET /billing/events/`

---

## ct payroll

Access restricted to admins and owners.

### ct payroll (bare / summary)

```
ct payroll [--json]
ct payroll summary [--period YYYY-MM] [--json]
```

Shows payroll periods overview. Defaults to listing all periods.

Endpoint: `GET /payroll/periods/`

### ct payroll members

```
ct payroll members [--json]
```

Lists all active members with their current compensation configuration (type, rate, effective date).

Endpoints: `GET /payroll/compensation/` + `GET /members/`

### ct payroll show

```
ct payroll show MEMBER [--json]
```

| Argument | Type | Description |
|----------|------|-------------|
| `MEMBER` | string (required) | Member email or name |

Shows all compensation configs for a member (rate history).

Endpoint: `GET /payroll/compensation/?membership=<id>`

### ct payroll set-rate

```
ct payroll set-rate MEMBER RATE [--effective/-e DATE] [--json]
```

| Argument/Option | Type | Description |
|-----------------|------|-------------|
| `MEMBER` | string (required) | Member email or name |
| `RATE` | string (required) | Hourly rate (e.g. 75.00) |
| `--effective`, `-e` | string | Effective from date (YYYY-MM-DD, must be 1st of month). Default: 1st of current month |

Sets an hourly compensation config. Creates a new config record (previous configs preserved).

Endpoint: `POST /payroll/compensation/`

### ct payroll set-salary

```
ct payroll set-salary MEMBER AMOUNT [--effective/-e DATE] [--json]
```

| Argument/Option | Type | Description |
|-----------------|------|-------------|
| `MEMBER` | string (required) | Member email or name |
| `AMOUNT` | string (required) | Monthly salary (e.g. 5000.00) |
| `--effective`, `-e` | string | Effective from date (YYYY-MM-DD, must be 1st of month). Default: 1st of current month |

Sets a fixed monthly salary compensation config.

Endpoint: `POST /payroll/compensation/`

### ct payroll run

```
ct payroll run [--period YYYY-MM] [--dry-run] [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `--period` | string | Period as YYYY-MM (default: current month) |
| `--dry-run` | flag | Preview calculations without saving |

Creates a payroll period (if needed) and runs liquidation calculation:
- **Hourly** members: `gross = total_hours × hourly_rate`
- **Salary** members: `gross = monthly_salary` (flat, no proration)

Members without a compensation config are skipped.

Endpoints: `POST /payroll/periods/` + `POST /payroll/periods/<id>/calculate/`

### ct payroll periods

```
ct payroll periods [--json]
```

Lists all payroll periods. Same as `ct payroll summary`.

### ct payroll period

```
ct payroll period PERIOD_ID [--json]
```

Shows period detail with member-by-member breakdown including hours, rates, gross amounts, and payment status.

Endpoint: `GET /payroll/periods/<id>/`

### ct payroll approve

```
ct payroll approve PERIOD_ID [--json]
```

Approves a calculated period. Only calculated periods can be approved.

**Status transitions**: draft → calculated → approved → paid

Endpoint: `POST /payroll/periods/<id>/approve/`

### ct payroll mark-paid

```
ct payroll mark-paid PERIOD_ID [MEMBER] [--all] [--method/-m METHOD] [--reference/--ref/-r REF] [--json]
```

| Argument/Option | Type | Description |
|-----------------|------|-------------|
| `PERIOD_ID` | string (required) | Payroll period ID |
| `MEMBER` | string (optional) | Member email (for individual payment) |
| `--all` | flag | Mark all entries as paid |
| `--method`, `-m` | string | Payment method: `bank_transfer` (default), `check`, `cash`, `other` |
| `--reference`, `--ref`, `-r` | string | External reference (transaction ID, check number) |

Marks payroll entries as paid. Either specify a member email OR use `--all`.

Endpoints: `POST /payroll/payments/` + `POST /payroll/payments/<id>/mark-paid/` or `POST /payroll/periods/<id>/mark-all-paid/`

### ct payroll payments

```
ct payroll payments [--period YYYY-MM] [--member MEMBER] [--status STATUS] [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `--period` | string | Filter by period (YYYY-MM) |
| `--member` | string | Filter by member email |
| `--status` | string | Filter: `pending`, `paid`, `failed` |

Lists payroll payments with amount, status, method, and reference.

Endpoint: `GET /payroll/payments/`

---

## ct projects

### ct projects list

```
ct projects list [--archived/-a] [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `--archived`, `-a` | flag | Include archived projects |
| `--json` | flag | JSON output |

Shows: ID, Name, Code, Client, Status, Billable. Marks default project.
Endpoint: `GET /projects/`

### ct projects show

```
ct projects show PROJECT_ID [--json]
```

Shows: ID, code, client, status, billable, billing mode, budget type/amount, alert threshold, notes.
Endpoint: `GET /projects/{id}/`

### ct projects create

```
ct projects create NAME [options]
```

| Option | Type | Description |
|--------|------|-------------|
| `--client`, `-c` | string | Client name (auto-creates if not found) |
| `--billable`, `-b` | flag | Billable (default: true) |
| `--no-billable`, `-B` | flag | Non-billable |
| `--billing-mode` | string | Billing mode: `per_task`, `per_person`, `custom` (default) |
| `--color` | string | Hex color code |
| `--budget` | float | Budget amount (hours or money depending on `--budget-type`) |
| `--budget-type` | string | Budget type: `hours` (default when `--budget` given), `money`, `none` |
| `--budget-alert` | int | Budget alert threshold percentage (default: 80) |
| `--code` | string | Short project code |
| `--json` | flag | JSON output |

**Billing modes:**
| Mode | Description |
|------|-------------|
| `custom` | Default. Full rate waterfall: Entry → ProjectMember → ProjectTask → Project → Task → Membership → User |
| `per_task` | Task-first waterfall: Entry → ProjectTask → Task → ProjectMember → Membership → User → Project (last) |
| `per_person` | Person-first waterfall: Entry → ProjectMember → Membership → User → ProjectTask → Task → Project (last) |

Endpoint: `POST /projects/`

### ct projects update

```
ct projects update PROJECT_ID [options]
```

| Option | Type | Description |
|--------|------|-------------|
| `PROJECT_ID` | string (required) | Project slug or UUID |
| `--name/-n` | string | New project name |
| `--client/-c` | string | Client name (auto-creates if not found) |
| `--billable/--no-billable` | flag | Mark as billable or not |
| `--billing-mode/-m` | string | Billing mode: per_task, per_person, custom |
| `--color` | string | Project color hex code (e.g. #FF5733) |
| `--budget` | float | Budget amount (hours or money) |
| `--budget-type` | string | Budget type: hours, money, none |
| `--budget-alert` | int | Budget alert threshold percentage |
| `--code` | string | Short project code |
| `--status/-s` | string | Project status: active, paused, completed, archived |
| `--json` | flag | JSON output |

Updates an existing project. Only specified options are changed; unspecified fields remain unchanged.

**Usage examples:**
```bash
ct projects update my-project --name "New Name"
ct projects update my-project --budget 200 --budget-type hours
ct projects update my-project --billing-mode per_person --status paused
ct projects update my-project --budget-alert 90
```

### ct projects archive

```
ct projects archive PROJECT_ID [--force/-f]
```

Requires confirmation unless `--force`. Endpoint: `PATCH /projects/{id}/`

### ct projects switch

```
ct projects switch SLUG
```

Sets project as default for new entries. Saves to config `defaults.project`.

### ct projects budget

```
ct projects budget PROJECT [--refresh] [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `PROJECT` | string (required) | Project slug or UUID |
| `--refresh` | flag | Refresh the budget snapshot before displaying |
| `--json` | flag | JSON output |

Shows budget status: budget type (hours/money), total budget, spent, remaining, percentage used, progress bar, weekly burn rate, and estimated exhaustion date.
If `--refresh` is specified, triggers a fresh budget snapshot calculation before displaying.

**Usage examples:**
```bash
ct projects budget acme-website              # View current budget status
ct projects budget acme-website --refresh    # Refresh snapshot and view
```

### ct projects members

```
ct projects members PROJECT_ID [--json]
```

| Argument/Option | Type | Description |
|-----------------|------|-------------|
| `PROJECT_ID` | string (required) | Project slug or UUID |
| `--json` | flag | Output as JSON |

Lists all members assigned to a project with their project role, org role, hourly rate, and user ID.

**Usage examples:**
```bash
ct projects members acme-website              # List project team
ct projects members acme-website --json       # JSON output for scripting
```

Endpoint: `GET /projects/{id}/members/`

### ct projects tasks

```
ct projects tasks PROJECT_ID [--json]
```

| Argument/Option | Type | Description |
|-----------------|------|-------------|
| `PROJECT_ID` | string (required) | Project slug or UUID |
| `--json` | flag | Output as JSON |

Lists all tasks assigned to a project with billable status, task-level rate, project-level rate override, and active status.

**Usage examples:**
```bash
ct projects tasks acme-website               # List project tasks
ct projects tasks acme-website --json        # JSON output for scripting
```

Endpoint: `GET /projects/{id}/tasks/`

### ct projects update-member

```
ct projects update-member PROJECT_ID USER_ID [options]
```

| Argument/Option | Type | Description |
|-----------------|------|-------------|
| `PROJECT_ID` | string (required) | Project slug or UUID |
| `USER_ID` | string (required) | User UUID or email |
| `--role` | string | Project-level role override (e.g. `project_manager`, `member`, `viewer`) |
| `--rate` | float | Hourly rate override for this project member |
| `--json` | flag | JSON output |

Updates a member's project-specific role and/or rate. The `--role` sets a `project_role` that overrides the member's org-level role for this project only. Response includes `effective_role`, `org_role`, and `org_hourly_rate` for context.

**Usage examples:**
```bash
ct projects update-member website-redesign alice@co.com --role project_manager --rate 150
ct projects update-member <project-id> <user-id> --rate 120
```

Endpoint: `PATCH /projects/{id}/members/{user_id}/`

### ct projects add-members

```
ct projects add-members PROJECT_ID --user USER_ID [--user USER_ID ...] [--role ROLE] [--rate RATE] [--json]
```

| Argument/Option | Type | Description |
|-----------------|------|-------------|
| `PROJECT_ID` | string (required) | Project slug or UUID |
| `--user` | string (repeatable, required) | User UUID or email (specify multiple times) |
| `--role` | string | Project role for all added members |
| `--rate` | float | Hourly rate for all added members |
| `--json` | flag | JSON output |

Bulk-adds multiple members to a project in a single operation.

**Usage examples:**
```bash
ct projects add-members website-redesign --user alice@co.com --user bob@co.com --role member --rate 120
ct projects add-members <project-id> --user <uid1> --user <uid2>
```

Endpoint: `POST /projects/{id}/members/bulk/`

### ct projects add-tasks

```
ct projects add-tasks PROJECT_ID --task TASK_ID [--task TASK_ID ...] [--json]
```

| Argument/Option | Type | Description |
|-----------------|------|-------------|
| `PROJECT_ID` | string (required) | Project slug or UUID |
| `--task` | string (repeatable, required) | Task UUID or name (specify multiple times) |
| `--json` | flag | JSON output |

Bulk-assigns multiple existing org-level tasks to a project in a single operation.

**Usage examples:**
```bash
ct projects add-tasks website-redesign --task <tid1> --task <tid2>
ct projects add-tasks <project-id> --task "Design" --task "Development" --task "QA"
```

Endpoint: `POST /projects/{id}/tasks/bulk/`

---

## ct tasks

### ct tasks list

```
ct tasks list [--project/-p PROJECT] [--json]
```

Shows: ID, Name, Project, Billable. Endpoint: `GET /tasks/`

### ct tasks create

```
ct tasks create NAME [--project/-p PROJECT] [--billable/-b] [--no-billable/-B] [--json]
```

Creates an organization-level task. If `--project` is specified, also assigns the task to that project (via ProjectTask).
Endpoint: `POST /tasks/` + `POST /projects/{id}/tasks/`

### ct tasks edit

```
ct tasks edit TASK_ID [--name NAME] [--billable/-b] [--no-billable/-B] [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `--name` | string | New task name |
| `--billable`, `-b` / `--no-billable`, `-B` | flag | Mark as billable or non-billable |
| `--json` | flag | JSON output |

At least one option is required. Endpoint: `PATCH /tasks/{id}/`

### ct tasks archive

```
ct tasks archive TASK_ID [--force/-f]
```

Archives a task. Requires confirmation unless `--force`. Endpoint: `DELETE /tasks/{id}/`

### ct tasks presets

```
ct tasks presets [--json]
```

Lists all available task presets with their included task names.

**Available presets:**
| Preset | Tasks Included |
|--------|---------------|
| `software_development` | Development, Code Review, QA Testing, DevOps, Documentation, Meetings, Planning |
| `marketing_agency` | Strategy, Content Creation, Social Media, Analytics, Client Communication, Design |
| `design_studio` | Research, Wireframing, Visual Design, Prototyping, User Testing, Revisions |
| `consulting` | Research, Analysis, Strategy, Client Meetings, Reporting, Travel |
| `legal` | Research, Drafting, Review, Client Meetings, Filing, Court Preparation |
| `accounting` | Bookkeeping, Tax Preparation, Audit, Reporting, Client Meetings, Advisory |

Endpoint: `GET /tasks/presets/`

### ct tasks apply-preset

```
ct tasks apply-preset PRESET [--project/-p PROJECT] [--json]
```

| Argument/Option | Type | Description |
|-----------------|------|-------------|
| `PRESET` | string (required) | Preset name (e.g. `software_development`) |
| `--project`, `-p` | string | Project slug or UUID to assign created tasks to |
| `--json` | flag | JSON output |

Creates all tasks from a preset at the org level. If `--project` is specified, also assigns them to that project.

**Usage examples:**
```bash
ct tasks presets                                           # List available presets
ct tasks apply-preset software_development                 # Create tasks org-wide
ct tasks apply-preset marketing_agency -p acme-campaign    # Create and assign to project
```

Endpoint: `POST /tasks/presets/{preset}/apply/`

---

## ct report

### ct report (main)

```
ct report [period options] [filter options] [output options]
```

**Period options** (default: this week):

| Option | Description |
|--------|-------------|
| `--today` | Today only |
| `--yesterday` | Yesterday |
| `--week`, `-w` | This week |
| `--last-week` | Last week |
| `--month`, `-m` | This month |
| `--last-month` | Last month (full) |
| `--quarter`, `-q` | This quarter |
| `--last-quarter` | Last quarter (full) |
| `--from` | Start date (with optional `--to`) |
| `--to` | End date |

**Filter options:**

| Option | Type | Description |
|--------|------|-------------|
| `--project`, `-p` | string | Filter by project |
| `--client`, `-c` | string | Filter by client ID |

**Output options:**

| Option | Type | Description |
|--------|------|-------------|
| `--group-by`, `-g` | string | `project` (default), `task`, `day`, `client` |
| `--format`, `-f` | string | `table` (default), `json`, `csv`, `markdown` |

Endpoint: `GET /reports/time-detail/` or `GET /reports/project-summary/`

### ct report projects

```
ct report projects [--week/-w] [--month/-m] [--last-month] [--quarter/-q] [--last-quarter] [--from DATE] [--to DATE] [--client/-c CLIENT] [--json]
```

Project breakdown with hours, billable, amounts, budget info. Default: this month. Custom dates (`--from`/`--to`) override preset flags. `--client` filters by client ID. Endpoint: `GET /reports/project-summary/`

### ct report team

```
ct report team [--week/-w] [--month/-m] [--last-month] [--quarter/-q] [--last-quarter] [--from DATE] [--to DATE] [--member MEMBER] [--client/-c CLIENT] [--json]
```

Team utilization: Member, Hours, Billable, Amount, Utilization %, Capacity %. Includes weekly capacity hours and capacity percentage for workload assessment. Custom dates (`--from`/`--to`) override preset flags. `--client` filters by client ID. Endpoint: `GET /reports/team-utilization/`

### ct report client

```
ct report client [--week/-w] [--month/-m] [--last-month] [--quarter/-q] [--last-quarter] [--from DATE] [--to DATE] [--client/-c CLIENT] [--detail/-d] [--json]
```

Client billing summary: Client, Hours, Amount, Projects, Entries. Shows billable time grouped by client with per-client currency. Default: this month. Use `--detail` to see per-project breakdown within each client (adds indented project rows with budget % used indicator when budgets exist). Endpoint: `GET /reports/client-invoice/` (pass `?detail=projects` for project breakdown with `budget_type`, `budget_amount`, `budget_percent_used`, and `budget_remaining` fields)

### ct report budget

```
ct report budget --project/-p PROJECT_ID [--json]
```

Budget burn-down for a project: Date, Hours, Amount, Remaining, Used %. Shows daily budget snapshots with color-coded remaining amounts (red when over budget). Requires `--project`. Endpoint: `GET /reports/budget-burn/`

### ct report saved list

```
ct report saved list [--json]
```

List saved report configurations. Shows your own reports plus any shared by teammates. Columns: ID, Name, Type, Shared, Created By. Endpoint: `GET /reports/saved/`

### ct report saved create

```
ct report saved create --name/-n NAME --type/-t TYPE [--shared/-s] [--project/-p ID] [--client/-c ID] [--from DATE] [--to DATE] [--group-by/-g GROUP]
```

Create a saved report configuration. Types: `time_detail`, `project_summary`, `team_utilization`, `client_invoice`, `budget_burn`. Use `--shared` to share with team members. Endpoint: `POST /reports/saved/`

### ct report saved delete

```
ct report saved delete <REPORT_ID>
```

Delete a saved report configuration. Endpoint: `DELETE /reports/saved/<id>/`

### ct report saved run

```
ct report saved run <REPORT_ID> [--from DATE] [--to DATE] [--json]
```

Run a saved report with its stored filters and display results. Use `--from`/`--to` to override the saved date range for the current run. Auto-detects report type and formats output accordingly. Endpoint: `GET /reports/saved/<id>/run/`

---

## ct ai

### ct ai parse

```
ct ai parse TEXT [--dry-run] [--force/-f] [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `TEXT` | string (required) | Natural language time entry |
| `--dry-run` | flag | Preview without creating |
| `--force`, `-f` | flag | Skip confirmation |
| `--json` | flag | JSON output |

Shows parsed: description, project, task, duration, date, billable, confidence, ambiguities.
Endpoints: `POST /ai/parse/` then `POST /ai/parse/confirm/`

### ct ai suggest

```
ct ai suggest [--date/-d DATE] [--json]
```

AI-powered suggestions based on work patterns. Interactive: select a suggestion to start a timer.
Endpoint: `GET /ai/suggestions/`

### ct ai summarize

```
ct ai summarize [period] [--for FORMAT] [--copy/-c] [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `--today` | flag | Today |
| `--week`, `-w` | flag | This week (default) |
| `--month`, `-m` | flag | This month |
| `--for` | string | `report` (default), `standup`, `slack` |
| `--copy`, `-c` | flag | Copy to clipboard |
| `--json` | flag | JSON output |

Generates headline, total hours, project breakdown, insights.
Endpoint: `GET /ai/summary/weekly/`

---

## ct favorites

### ct favorites list

```
ct favorites list [--json]
```

Shows: ID, Project, Task, Description, Use count. Endpoint: `GET /favorites/`

### ct favorites show

```
ct favorites show FAVORITE_ID [--json]
```

Shows detailed view of a favorite: ID, project, task, description, billable status, position, use count, created timestamp.
Endpoint: `GET /favorites/{id}/`

### ct favorites edit

```
ct favorites edit FAVORITE_ID [--project/-p] [--task/-t] [--notes/-n] [--billable/-b] [--no-billable/-B] [--position] [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `--project`, `-p` | string | New project name or ID |
| `--task`, `-t` | string | New task name or ID |
| `--notes`, `-n` | string | New description/notes |
| `--billable`, `-b` | flag | Set billable |
| `--no-billable`, `-B` | flag | Set non-billable |
| `--position` | integer | Display position (0-based) |
| `--json` | flag | JSON output |

Only provided fields are updated. Endpoint: `PATCH /favorites/{id}/`

### ct favorites create

```
ct favorites create [DESCRIPTION] [--project/-p] [--task/-t] [--notes/-n] [--billable/-b] [--no-billable/-B] [--json]
```

Creates a reusable entry template. Project is required (via `-p` or default project). Task names are resolved to UUIDs automatically. Endpoint: `POST /favorites/`

### ct favorites delete

```
ct favorites delete FAVORITE_ID [--force/-f]
```

Endpoint: `DELETE /favorites/{id}/`

### ct favorites start

```
ct favorites start FAVORITE_ID [--note/-n NOTE] [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `--note`, `-n` | string | Override the favorite's description with custom text |
| `--json` | flag | JSON output |

Starts a timer from a saved template. Use `--note` to override the default description.
Endpoint: `POST /favorites/{id}/start/`

---

## ct org

### ct org show

```
ct org show [--json]
```

Shows details of the current organization: name, slug, your role, member count, currency, week start day, entry requirements, payment terms, creation date.
Endpoint: `GET /api/v1/organizations/`

### ct org list

```
ct org list [--json]
```

Lists organizations you belong to. Marks current with `*`. Non-org-scoped.
Endpoint: `GET /api/v1/organizations/`

### ct org create

```
ct org create NAME [--json]
```

Creates a new organization with the given name. Max 10 organizations per user. Non-org-scoped.
Endpoint: `POST /api/v1/organizations/create-personal/`

### ct org switch

```
ct org switch SLUG
```

Switches active organization. Saves to config `defaults.organization`.

### ct org members

```
ct org members [--json]
```

Shows: Name, Email, Role, Status. Requires manager+ role. Endpoint: `GET /members/`

### ct org invite

```
ct org invite EMAIL [--role/-r ROLE] [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `--role`, `-r` | string | `admin`, `manager`, `project_manager`, `member` (default), `viewer` |

**Roles:**
- `viewer` — external client stakeholder, read-only access scoped to assigned projects
- `member` — can log time, manage own entries
- `project_manager` — manage projects, tasks, timesheets, team time; no financial data (rates, invoices)
- `manager` — Account Manager: project management + invoices, rates, clients, billing
- `admin` — manage org settings, members, integrations

Endpoint: `POST /members/invite/`

### ct org update-member

```
ct org update-member USER_ID [options]
```

| Argument/Option | Type | Description |
|-----------------|------|-------------|
| `USER_ID` | string (required) | User UUID |
| `--role`, `-r` | string | New org role: admin, manager, project_manager, member, viewer |
| `--rate` | string | Hourly rate |
| `--capacity` | float | Weekly capacity hours |
| `--json` | flag | Output as JSON |

Updates an organization member's role, hourly rate, or weekly capacity. Cannot change the owner's role.

**Usage examples:**
```bash
ct org update-member <user-id> --role project_manager
ct org update-member <user-id> --rate 150
ct org update-member <user-id> --role admin --rate 200
```

Endpoint: `PATCH /members/{user_id}/`

### ct org remove-member

```
ct org remove-member USER_ID [--force]
```

| Argument/Option | Type | Description |
|-----------------|------|-------------|
| `USER_ID` | string (required) | User UUID |
| `--force`, `-f` | flag | Skip confirmation prompt |

Removes a member from the organization. Deactivates their membership and revokes all API tokens for this org. Cannot remove the organization owner.

**Usage examples:**
```bash
ct org remove-member <user-id>
ct org remove-member <user-id> --force
```

Endpoint: `DELETE /members/{user_id}/`

### ct org invitations

```
ct org invitations [--json]
```

Lists pending invitations for the current organization. Endpoint: `GET /invitations/`

### ct org resend-invite

```
ct org resend-invite INVITATION_ID [--json]
```

Resends the invitation email for a pending invitation. Endpoint: `POST /invitations/{id}/resend/`

### ct org revoke-invite

```
ct org revoke-invite INVITATION_ID [--force/-f] [--json]
```

Revokes a pending invitation. Requires confirmation unless `--force`. Endpoint: `POST /invitations/{id}/revoke/`

---

## ct config

### ct config set

```
ct config set KEY VALUE
```

Uses dot notation. Examples:
- `ct config set server.url https://api.crowdtime.io`
- `ct config set defaults.project myproject`
- `ct config set defaults.daily_target 7h`
- `ct config set display.compact true`

Auto-converts boolean strings.

### ct config get

```
ct config get KEY
```

### ct config list

```
ct config list [--json]
```

Shows all config with file path.

### ct config edit

```
ct config edit
```

Opens in `$EDITOR`, `$VISUAL`, or `nano`.

### Config Structure

```toml
[server]
url = "https://api.crowdtime.lat"

[defaults]
organization = ""
project = ""
daily_target = "8h"
weekly_target = "40h"
date_format = "%Y-%m-%d"
time_format = "24h"

[display]
theme = "auto"
color = true
compact = false
```

---

## ct timesheet

### ct timesheet list

```
ct timesheet list [--user USER_ID] [--status STATUS] [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `--user`, `-u` | string | User ID to view (manager+) |
| `--status`, `-s` | string | Filter: `draft`, `submitted`, `approved`, `rejected` |
| `--json` | flag | JSON output |

Lists your timesheets (or all viewable timesheets for managers). Endpoint: `GET /timesheets/`

### ct timesheet submit

```
ct timesheet submit --from DATE --to DATE [--force/-f] [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `--from` | string (required) | Period start date |
| `--to` | string (required) | Period end date |
| `--force`, `-f` | flag | Skip confirmation prompt |
| `--json` | flag | JSON output |

Submits a timesheet for the given period (any date range — not limited to full weeks). Supports partial-week submissions for end-of-month splits. Shows a preview of entries and hours before confirming (use `--force` to skip). Rejects zero-hour submissions and periods that overlap with already submitted/approved timesheets. Endpoint: `POST /timesheets/submit/`

### ct timesheet approve

```
ct timesheet approve TIMESHEET_ID [--project PROJECT_ID] [--notes NOTES] [--force] [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `--project`, `-p` | string | Approve only this project's portion (project ID) |
| `--notes`, `-n` | string | Reviewer notes |
| `--force`, `-f` | flag | Skip confirmation prompt |
| `--json` | flag | JSON output |

Without `--project`: approves ALL project portions at once (manager+ role). With `--project`: approves only that project's portion — PM for that project can do this. When all project portions are approved, the timesheet auto-transitions to approved.

Endpoints:
- Bulk: `POST /timesheets/{id}/approve/`
- Per-project: `POST /timesheets/{id}/approvals/{project_id}/approve/`

### ct timesheet reject

```
ct timesheet reject TIMESHEET_ID [--project PROJECT_ID] --notes NOTES [--force] [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `--project`, `-p` | string | Reject only this project's portion (project ID) |
| `--notes`, `-n` | string (required) | Rejection reason |
| `--force`, `-f` | flag | Skip confirmation prompt |
| `--json` | flag | JSON output |

Rejecting ANY project portion rejects the entire timesheet — the user must fix entries and resubmit. Notes are required.

Endpoints:
- Bulk: `POST /timesheets/{id}/reject/`
- Per-project: `POST /timesheets/{id}/approvals/{project_id}/reject/`

### ct timesheet recall

```
ct timesheet recall TIMESHEET_ID [--notes NOTES] [--force] [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `--notes`, `-n` | string | Reason for recalling |
| `--force`, `-f` | flag | Skip confirmation prompt |
| `--json` | flag | JSON output |

Recalls a submitted timesheet back to draft so you can edit and resubmit. Only the timesheet owner can recall, and only before it's been approved or rejected. Notes are optional but recorded in the audit trail.
Endpoint: `POST /timesheets/{id}/recall/`

### ct timesheet team

```
ct timesheet team [--week/-w] [--last-week] [--from DATE] [--to DATE] [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `--week`, `-w` | flag | This week (default) |
| `--last-week` | flag | Last week |
| `--from` | string | Start date for custom period |
| `--to` | string | End date for custom period |
| `--json` | flag | JSON output |

Shows team overview with hours, capacity, utilization %, and timesheet status for each member. Requires manager+ role.
Endpoint: `GET /timesheets/team-overview/`

### ct timesheet bulk-approve

```
ct timesheet bulk-approve ID1 ID2 [ID3 ...] [--project PROJECT_ID] [--notes NOTES] [--force] [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `ID1 ID2 ...` | string (required) | Timesheet IDs to approve |
| `--project`, `-p` | string | Approve only this project's portion in each timesheet (PM for that project) |
| `--notes`, `-n` | string | Reviewer notes |
| `--force`, `-f` | flag | Skip confirmation prompt |
| `--json` | flag | JSON output |

Without `--project`: approves all project portions in each timesheet (manager+ role). With `--project`: approves only that project's portion in each timesheet (PM for that project). Skips timesheets that are not found or not in submitted status.
Endpoint: `POST /timesheets/bulk-approve/` (without --project), per-project endpoint per timesheet (with --project)

### ct timesheet bulk-reject

```
ct timesheet bulk-reject ID1 ID2 [ID3 ...] [--project PROJECT_ID] --notes NOTES [--force] [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `ID1 ID2 ...` | string (required) | Timesheet IDs to reject |
| `--project`, `-p` | string | Reject only this project's portion in each timesheet (PM for that project) |
| `--notes`, `-n` | string (required) | Rejection reason |
| `--force`, `-f` | flag | Skip confirmation prompt |
| `--json` | flag | JSON output |

Without `--project`: rejects all timesheets entirely (manager+ role). With `--project`: rejects that project's portion in each timesheet (PM). Rejecting any portion rejects the entire timesheet. Notes are required. Skips timesheets that are not found or not in submitted status.
Endpoint: `POST /timesheets/bulk-reject/` (without --project), per-project endpoint per timesheet (with --project)

### ct timesheet history

```
ct timesheet history TIMESHEET_ID [--json]
```

Shows the full audit trail for a timesheet — all submissions, approvals, rejections, and recalls with timestamps, actors, and notes.
Endpoint: `GET /timesheets/{id}/history/`

### ct timesheet viewable-users

```
ct timesheet viewable-users [--json]
```

Lists team members whose timesheets you can view (manager+).
Endpoint: `GET /timesheets/viewable-users/`

### ct timesheet approvals

```
ct timesheet approvals TIMESHEET_ID [--json]
```

Shows per-project approval status for a timesheet. Displays each project's hours, billable hours, entry count, approval status (pending/approved/rejected), and reviewer. Useful for PMs to see which project portions still need their review.

Endpoint: `GET /timesheets/{id}/approvals/`

### ct timesheet compliance

```
ct timesheet compliance [--from DATE] [--to DATE] [--week] [--last-week] [--month] [--last-month] [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `--from` | string | Period start date (YYYY-MM-DD, default: current week) |
| `--to` | string | Period end date (YYYY-MM-DD) |
| `--week` | flag | Current week |
| `--last-week` | flag | Last week |
| `--month` | flag | Current month |
| `--last-month` | flag | Last month |
| `--json` | flag | JSON output |

Shows timesheet compliance report for a period (manager+ role). Displays:
- Summary: total members, approved/pending/not submitted/rejected counts, completion %
- Not Submitted: members who haven't submitted, whether they have time entries
- Pending Approval: submitted timesheets waiting review, with days pending
- Rejected: timesheets needing resubmission, with reviewer notes

Endpoint: `GET /timesheets/compliance/`

---

## ct invoice

### ct invoice list

```
ct invoice list [--status STATUS] [--overdue] [--unpaid] [--client CLIENT] [--type TYPE] [--from DATE] [--to DATE] [--due-from DATE] [--due-to DATE] [--search QUERY] [--min-amount NUM] [--max-amount NUM] [--sort FIELD] [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `--status` `-s` | string | Filter: `draft`, `sent`, `viewed`, `partial`, `paid`, `overdue`, `void`. Supports comma-separated values (e.g. `sent,overdue`) |
| `--overdue` | flag | Show only overdue invoices (shortcut for `--status overdue`) |
| `--unpaid` | flag | Show all unpaid invoices (sent, viewed, overdue, partially paid) |
| `--client` `-c` | string | Filter by client ID |
| `--type` `-t` | string | Filter by type: `standard`, `recurring`, `retainer` |
| `--from` | string | Filter by issue date from (YYYY-MM-DD) |
| `--to` | string | Filter by issue date to (YYYY-MM-DD) |
| `--due-from` | string | Filter by due date from (YYYY-MM-DD) |
| `--due-to` | string | Filter by due date to (YYYY-MM-DD) |
| `--search` `-q` | string | Search by invoice number, subject, or client name |
| `--min-amount` | float | Filter by minimum total amount |
| `--max-amount` | float | Filter by maximum total amount |
| `--sort` | string | Sort by: `issue_date`, `due_date`, `total`, `amount_due`, `created_at`. Prefix with `-` for descending |
| `--json` | flag | JSON output |

Response includes `days_overdue` field (integer) for overdue invoices — shows how many days past due. Status column in table shows days overdue indicator (e.g. `Overdue (15d)`).

Endpoint: `GET /invoices/`

### ct invoice summary

```
ct invoice summary [--json]
```

Shows invoice summary statistics: counts by status, total outstanding, overdue, paid, draft amounts, average days to payment, and collection rate (paid / total collectible as %). Endpoint: `GET /invoices/summary/`

### ct invoice aging

```
ct invoice aging [--client CLIENT] [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `--client` `-c` | string | Filter by client ID |
| `--json` | flag | JSON output |

Invoice aging report grouped by overdue buckets: current (not yet due), 1-30 days, 31-60 days, 61-90 days, and 90+ days overdue. Shows per-bucket totals, invoice count, and individual invoices with days overdue. Endpoint: `GET /invoices/aging/`

### ct invoice show

```
ct invoice show INVOICE_ID [--json]
```

Shows invoice details including line items, payments, and totals. Endpoint: `GET /invoices/{id}/`

### ct invoice create

```
ct invoice create --client CLIENT --from DATE --to DATE [--period PERIOD] [--group-by GROUP] [--tax-rate RATE] [--payment-terms TERMS] [--notes NOTES] [--terms TEXT] [--json]
```

Creates an invoice from tracked time entries. Requires either `--from`/`--to` or `--period`.

| Option | Type | Description |
|--------|------|-------------|
| `--client` | string (required) | Client ID |
| `--from` | string | Period start date |
| `--to` | string | Period end date |
| `--period` | string | Preset: `last-week`, `last-2-weeks`, `last-month`, `this-month` |
| `--group-by` | string | Group line items by: `project`, `task`, `user`, `date`, `none` |
| `--tax-rate` | float | Tax rate percentage (e.g. 21 for 21%) |
| `--payment-terms` | string | Payment terms: `receipt`, `net15`, `net30`, or number of days |
| `--notes` | string | Invoice notes |
| `--terms` | string | Payment terms text |
| `--json` | flag | JSON output |

Billable time entries and expenses from the period are automatically imported as line items.

**Usage examples:**
```bash
ct invoice create --client <id> --period last-month --payment-terms net30
ct invoice create --client <id> --from 2026-03-01 --to 2026-03-31
ct invoice create --client <id> --period last-2-weeks --group-by project
ct invoice create --client <id> --period last-month --group-by user    # One line item per team member
```

Endpoint: `POST /invoices/from-time-entries/`

### ct invoice create-blank

```
ct invoice create-blank --client CLIENT --issue-date DATE [--due-date DATE] [--payment-terms TERMS] [--subject SUBJECT] [--terms TEXT] [--notes NOTES] [--currency CUR] [--json]
```

Creates an empty draft invoice for manual line item addition. If `--due-date` is omitted, it's auto-calculated from `--payment-terms` (default: net30). `--terms` sets the payment terms text (e.g. bank account details).

Endpoint: `POST /invoices/`

### ct invoice update

```
ct invoice update INVOICE_ID [--number NUM] [--subject SUBJECT] [--issue-date DATE] [--due-date DATE] [--notes NOTES] [--terms TEXT] [--footer TEXT] [--currency CUR] [--tax-rate RATE] [--payment-terms TERMS] [--from-name NAME] [--from-email EMAIL] [--from-address ADDR] [--client-name NAME] [--client-email EMAIL] [--client-address ADDR] [--json]
```

Updates fields on a draft invoice. All fields are editable: invoice number, from/bill-to details, dates, currency, payment terms, notes, terms, footer. Only draft invoices can be edited — once sent, use void + recreate.

Endpoint: `PATCH /invoices/{id}/`

### ct invoice add-item

```
ct invoice add-item INVOICE_ID --description DESC --qty QTY --rate RATE [--discount-type TYPE] [--discount-value VALUE] [--taxable/--no-taxable] [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `--description`, `--desc` | string (required) | Line item description |
| `--qty` | float (required) | Quantity (e.g. hours) |
| `--rate` | float (required) | Unit rate |
| `--discount-type` | string | Discount type: `fixed` (flat amount), `percent` (percentage), `hours` (deduct hours at unit rate) |
| `--discount-value` | float | Discount value (amount, percentage, or hours depending on type) |
| `--taxable` / `--no-taxable` | flag | Whether the item is taxable |
| `--json` | flag | JSON output |

**Discount types:**
| Type | Example | Effect |
|------|---------|--------|
| `fixed` | `--discount-type fixed --discount-value 100` | Subtracts $100 from line total |
| `percent` | `--discount-type percent --discount-value 10` | Subtracts 10% from line total |
| `hours` | `--discount-type hours --discount-value 2` | Deducts 2 hours at the unit rate (e.g. 2 × $150 = $300 off) |

**Usage examples:**
```bash
ct invoice add-item <id> --desc "Development" --qty 40 --rate 150
ct invoice add-item <id> --desc "Consulting" --qty 10 --rate 200 --discount-type percent --discount-value 15
ct invoice add-item <id> --desc "Support" --qty 20 --rate 100 --discount-type hours --discount-value 2
```

Adds a line item to a draft invoice. Endpoint: `POST /invoices/{id}/line-items/`

### ct invoice send

```
ct invoice send INVOICE_ID [--to CONTACT_ID]... [--cc CONTACT_ID]... [--force/-f] [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `--to` | string (repeatable) | Contact ID(s) to send to. Repeat for multiple. Default: primary contact |
| `--cc` | string (repeatable) | Contact ID(s) to CC. Repeat for multiple |
| `--force`, `-f` | flag | Skip confirmation prompt |
| `--json` | flag | JSON output |

Transitions invoice from draft to sent. This action cannot be undone (use void instead). Endpoint: `POST /invoices/{id}/send/`

### ct invoice pay

```
ct invoice pay INVOICE_ID --amount AMOUNT [--date DATE] [--method METHOD] [--reference REF] [--notes NOTES] [--json]
```

Records a payment against an invoice. Method choices: `bank_transfer`, `credit_card`, `check`, `cash`, `paypal`, `other`. Endpoint: `POST /invoices/{id}/payments/`

### ct invoice void

```
ct invoice void INVOICE_ID --reason/-r REASON [--json]
```

Voids an invoice with a required reason. Endpoint: `POST /invoices/{id}/void/`

### ct invoice duplicate

```
ct invoice duplicate INVOICE_ID [--json]
```

Creates a copy of an existing invoice as a new draft. Endpoint: `POST /invoices/{id}/duplicate/`

---

### ct invoice recurring list

```
ct invoice recurring list [--json]
```

Lists all recurring invoice templates. Shows: ID, Name, Client, Schedule, Active, Next Run, Generated count.
Endpoint: `GET /invoices/recurring-templates/`

### ct invoice recurring show

```
ct invoice recurring show TEMPLATE_ID [--json]
```

Shows full details of a recurring template including line items.
Endpoint: `GET /invoices/recurring-templates/{id}/`

### ct invoice recurring create

```
ct invoice recurring create --name NAME --client CLIENT_ID --schedule SCHEDULE --next-run DATE [options]
```

| Option | Type | Description |
|--------|------|-------------|
| `--name`, `-n` | string (required) | Template name |
| `--client`, `-c` | string (required) | Client ID |
| `--schedule`, `-s` | string (required) | `weekly`, `biweekly`, `monthly`, `quarterly` |
| `--next-run` | date (required) | Next generation date (YYYY-MM-DD) |
| `--currency` | string | Currency code (e.g. USD) |
| `--payment-terms` | integer | Payment terms in days |
| `--auto-send` | flag | Auto-send generated invoices |
| `--pull-entries/--no-pull-entries` | flag | Pull time entries (default: yes) |
| `--group-by`, `-g` | string | Group by: `project`, `task`, `user`, `date`, `none` |
| `--notes` | string | Invoice notes |
| `--terms` | string | Payment terms text |
| `--json` | flag | JSON output |

Endpoint: `POST /invoices/recurring-templates/`

### ct invoice recurring update

```
ct invoice recurring update TEMPLATE_ID [options]
```

| Option | Type | Description |
|--------|------|-------------|
| `--name`, `-n` | string | Template name |
| `--schedule`, `-s` | string | Schedule frequency |
| `--next-run` | date | Next generation date |
| `--active/--inactive` | flag | Activate or deactivate |
| `--auto-send/--no-auto-send` | flag | Auto-send setting |
| `--payment-terms` | integer | Payment terms in days |
| `--group-by`, `-g` | string | Group by setting |
| `--notes` | string | Invoice notes |
| `--json` | flag | JSON output |

Endpoint: `PATCH /invoices/recurring-templates/{id}/`

### ct invoice recurring delete

```
ct invoice recurring delete TEMPLATE_ID [--force/-f]
```

Deletes a recurring template. Requires confirmation unless `--force`.
Endpoint: `DELETE /invoices/recurring-templates/{id}/`

### ct invoice recurring generate-now

```
ct invoice recurring generate-now TEMPLATE_ID [--json]
```

Manually triggers invoice generation from a template, regardless of schedule.
Endpoint: `POST /invoices/recurring-templates/{id}/generate-now/`

---

### ct invoice retainer list

```
ct invoice retainer list [--status STATUS] [--client CLIENT] [--search QUERY] [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `--status` `-s` | string | Filter: `pending`, `active`, `paused`, `completed`, `cancelled` |
| `--client` `-c` | string | Filter by client ID |
| `--search` `-q` | string | Search by retainer name or client name |
| `--json` | flag | JSON output |

Endpoint: `GET /invoices/retainers/`

### ct invoice retainer show

```
ct invoice retainer show RETAINER_ID [--json]
```

Shows retainer details including balance info (total deposited, total withdrawn, available balance). When there is a positive balance and withdrawal history (2+ withdrawals), also shows a **depletion forecast** with weekly burn rate, weeks remaining, and estimated depletion date (highlighted red if ≤4 weeks).

### ct invoice retainer withdraw

```
ct invoice retainer withdraw RETAINER_ID --invoice INVOICE_ID --amount AMOUNT [--notes NOTES] [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `--invoice`, `-i` | string (required) | Target invoice ID to apply credit to |
| `--amount`, `-a` | string (required) | Amount to withdraw |
| `--notes`, `-n` | string | Notes for the withdrawal |
| `--json` | flag | JSON output |

Withdraws from retainer balance and applies as payment on the target invoice. The target invoice must be:
- Same client as the retainer
- Same currency
- Not a draft, void, paid, or retainer-type invoice

Endpoint: `POST /invoices/retainers/{id}/withdraw/`

### ct invoice retainer withdrawals

```
ct invoice retainer withdrawals RETAINER_ID [--json]
```

Lists all withdrawals for a retainer with amount, target invoice, date, and status (active/reversed).

Endpoint: `GET /invoices/retainers/{id}/withdrawals/`

### ct invoice retainer reverse-withdrawal

```
ct invoice retainer reverse-withdrawal RETAINER_ID --withdrawal WITHDRAWAL_ID --reason REASON [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `--withdrawal`, `-w` | string (required) | Withdrawal ID to reverse |
| `--reason`, `-r` | string (required) | Reason for reversal |
| `--json` | flag | JSON output |

Reverses a withdrawal: returns the amount to the retainer balance and adjusts the target invoice's payment.

Endpoint: `POST /invoices/retainers/{id}/withdrawals/{wid}/reverse/`

### ct invoice uninvoiced

```
ct invoice uninvoiced [--json]
```

Shows uninvoiced billable time entries grouped by client. Displays client name, entry count, total hours, and total amount with a totals row. Useful for reviewing what work is ready to bill before creating invoices.

Endpoint: `GET /invoices/uninvoiced-entries/`

### ct invoice update-item

```
ct invoice update-item INVOICE_ID ITEM_ID [--description TEXT] [--quantity NUM] [--unit-price NUM] [--discount-type TYPE] [--discount-value NUM] [--taxable/--no-taxable] [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `--description`, `-d` | string | Item description |
| `--quantity`, `-q` | string | Quantity (e.g. hours) |
| `--unit-price`, `-p` | string | Unit price |
| `--discount-type` | string | Discount type: `fixed`, `percent`, `hours` |
| `--discount-value` | string | Discount value |
| `--taxable/--no-taxable` | flag | Whether item is taxable |
| `--json` | flag | JSON output |

Updates a line item on a draft invoice. Endpoint: `PATCH /invoices/{id}/line-items/{item_id}/`

### ct invoice remove-item

```
ct invoice remove-item INVOICE_ID ITEM_ID [--force/-f]
```

| Option | Type | Description |
|--------|------|-------------|
| `--force`, `-f` | flag | Skip confirmation prompt |

Removes a line item from a draft invoice. Endpoint: `DELETE /invoices/{id}/line-items/{item_id}/`

### ct invoice pdf

```
ct invoice pdf INVOICE_ID [--output/-o PATH]
```

| Option | Type | Description |
|--------|------|-------------|
| `--output`, `-o` | string | Output file path (default: `invoice-<number>.pdf`) |

Downloads the invoice as a PDF file. Endpoint: `GET /invoices/{id}/pdf/`

### ct invoice tax-rates

```
ct invoice tax-rates [--json]
```

Lists all tax rates for the organization. Shows name, rate %, default status, and active status.

Endpoint: `GET /invoices/tax-rates/`

### ct invoice tax-rates create

```
ct invoice tax-rates create --name NAME --rate RATE [--default] [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `--name`, `-n` | string (required) | Tax rate name (e.g. "VAT", "Sales Tax") |
| `--rate`, `-r` | string (required) | Tax rate as percentage (e.g. 21.0) |
| `--default`, `-d` | flag | Set as default tax rate for new invoices |
| `--json` | flag | JSON output |

Creates a new tax rate for the organization. Endpoint: `POST /invoices/tax-rates/`

### ct invoice tax-rates update

```
ct invoice tax-rates update <id> [--name NAME] [--rate RATE] [--default/--no-default] [--active/--no-active] [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `<id>` | string (required) | Tax rate ID |
| `--name`, `-n` | string | New name |
| `--rate`, `-r` | string | New rate percentage (e.g. 22.0) |
| `--default/--no-default` | flag | Set or unset as default tax rate |
| `--active/--no-active` | flag | Activate or deactivate |
| `--json` | flag | JSON output |

Updates an existing tax rate. At least one field must be provided. Endpoint: `PATCH /invoices/tax-rates/{id}/`

### ct invoice tax-rates delete

```
ct invoice tax-rates delete <id> [--force/-f]
```

Deletes a tax rate. Does not affect existing invoices that reference it. Use `--force` to skip confirmation. Endpoint: `DELETE /invoices/tax-rates/{id}/`

---

## ct insights

PM analytics and financial dashboards: project health, team utilization, budget forecasting, and financial KPIs. Requires project_manager+ (projects/team) or manager+ (financial) role.

### ct insights projects

```
ct insights projects [--week/-w] [--last-week] [--month] [--last-month] [--quarter/-q] [--last-quarter] [--from DATE] [--to DATE] [--at-risk] [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `--week/-w` | flag | This week |
| `--last-week` | flag | Last week |
| `--month` | flag | This month (default) |
| `--last-month` | flag | Last month |
| `--quarter/-q` | flag | This quarter |
| `--last-quarter` | flag | Last quarter |
| `--from` | string | Start date (YYYY-MM-DD) |
| `--to` | string | End date (YYYY-MM-DD) |
| `--at-risk` | flag | Show only projects at or above budget alert threshold |
| `--json` | flag | JSON output |

Project health dashboard showing hours, billable hours, budget usage, burn rate, exhaustion date, member count, and budget alerts for all active projects. Highlights budget warnings (>=80%) and dangers (>=95%). Financial fields (billable_amount) hidden from non-managers. Use `--at-risk` to filter to only projects that have triggered budget alerts.

**Usage examples:**
```bash
ct insights projects                          # This month (default)
ct insights projects --quarter                # This quarter
ct insights projects --at-risk                # Only over-budget projects
ct insights projects --from 2025-01-01 --to 2025-03-31  # Custom range
```

### ct insights team

```
ct insights team [--week/-w] [--last-week] [--month] [--last-month] [--quarter/-q] [--last-quarter] [--from DATE] [--to DATE] [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `--week/-w` | flag | This week |
| `--last-week` | flag | Last week |
| `--month` | flag | This month (default) |
| `--last-month` | flag | Last month |
| `--quarter/-q` | flag | This quarter |
| `--last-quarter` | flag | Last quarter |
| `--from` | string | Start date (YYYY-MM-DD) |
| `--to` | string | End date (YYYY-MM-DD) |
| `--json` | flag | JSON output |

Team utilization dashboard with per-member hours, billable hours, utilization %, capacity %, and timesheet status. Summary panel shows average utilization, overloaded/underutilized counts, and pending timesheets.

**Usage examples:**
```bash
ct insights team                              # This month (default)
ct insights team --week                       # This week
ct insights team --last-month                 # Last month
```

### ct insights allocations

```
ct insights allocations [--week/-w] [--last-week] [--month] [--last-month] [--quarter/-q] [--last-quarter] [--from DATE] [--to DATE] [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `--week/-w` | flag | This week |
| `--last-week` | flag | Last week |
| `--month` | flag | This month (default) |
| `--last-month` | flag | Last month |
| `--quarter/-q` | flag | This quarter |
| `--last-quarter` | flag | Last quarter |
| `--from` | string | Start date (YYYY-MM-DD) |
| `--to` | string | End date (YYYY-MM-DD) |
| `--json` | flag | JSON output |

Team resource allocation view showing per-member per-project hour breakdown. For each team member, displays total hours, capacity usage, available hours, and a breakdown of hours by project with percentage of time. Helps PMs identify who is overloaded, underutilized, or available for new work. Requires project_manager+ role.

**Usage examples:**
```bash
ct insights allocations                       # This month (default)
ct insights allocations --week                # This week
ct insights allocations --last-month          # Last month
```

Endpoint: `GET /insights/allocations/`

### ct insights financial

```
ct insights financial [--week/-w] [--last-week] [--month] [--last-month] [--quarter/-q] [--last-quarter] [--from DATE] [--to DATE] [--compare/-c] [--json]
```

| Option | Type | Description |
|--------|------|-------------|
| `--week/-w` | flag | This week |
| `--last-week` | flag | Last week |
| `--month` | flag | This month (default) |
| `--last-month` | flag | Last month |
| `--quarter/-q` | flag | This quarter |
| `--last-quarter` | flag | Last quarter |
| `--from` | string | Start date (YYYY-MM-DD) |
| `--to` | string | End date (YYYY-MM-DD) |
| `--compare`, `-c` | flag | Compare with previous period |
| `--json` | flag | JSON output |

Financial dashboard for managers+. Shows:
- **KPI panel**: total revenue, average hourly rate, billable ratio, uninvoiced amount, outstanding/overdue AR
- **AR aging table**: buckets (current, 1-30, 31-60, 61-90, 90+ days) with amounts and percentages
- **Top clients**: top 5 clients by revenue with hours
- **Revenue trend**: monthly total/invoiced/uninvoiced breakdown

With `--compare`, shows period-over-period revenue change percentage.

**Usage examples:**
```bash
ct insights financial                         # This month (default)
ct insights financial --quarter               # This quarter
ct insights financial --last-month --compare  # Last month vs previous
ct insights financial --from 2026-01-01 --to 2026-03-31  # Custom range
```

Endpoint: `GET /insights/financial/`

---

### ct insights profitability

```
ct insights profitability [--week/-w] [--last-week] [--month] [--last-month] [--quarter/-q] [--last-quarter] [--from DATE] [--to DATE] [--by-client] [--json]
```

Profitability analysis showing revenue, cost, and gross margin by project or client. Revenue is computed from billable time entries. Cost is derived from payroll compensation configs (hourly rate or prorated monthly salary at 160 hrs/month). Requires manager+ role.

**Options:**
| Option | Description |
|--------|-------------|
| `--week/-w` | This week |
| `--last-week` | Last week |
| `--month` | This month (default) |
| `--last-month` | Last month |
| `--quarter/-q` | This quarter |
| `--last-quarter` | Last quarter |
| `--from DATE` | Custom start date (YYYY-MM-DD) |
| `--to DATE` | Custom end date (YYYY-MM-DD) |
| `--by-client` | Group by client instead of project |
| `--json` | Output as JSON |

**Output columns:** Name, Client (project mode), Revenue, Hours, Cost, Margin, Margin %. Cost and margin columns appear only when compensation configs exist in payroll.

**Examples:**
```bash
ct insights profitability                         # This month by project
ct insights profitability --by-client             # Group by client
ct insights profitability --quarter               # This quarter
ct insights profitability --last-month --json     # JSON output
ct insights profitability --from 2026-01-01 --to 2026-03-31  # Custom range
```

Endpoint: `GET /insights/profitability/`

---

## ct team

Manage manager → direct-report assignments. Mirrors Harvest's manager model: assign people to a manager so the manager can see their hours across any project without being a PM on each project individually. Orthogonal to per-project PM assignments; visibility is the union of both.

### ct team list

```
ct team list [options]
```

Lists manager → direct-report assignments in the current organization. Admins and owners see everything; managers and project managers see only rows where they are the manager.

**Options:**
- `--manager/-m TEXT` — filter to a specific manager (membership ID, user ID, or email)
- `--member TEXT` — filter to a specific member
- `--json` — JSON output

Endpoint: `GET /manager-assignments/`

### ct team reports

```
ct team reports [options]
```

Shows the direct reports of a manager. Defaults to the current user. Same shape as `ct team list` but focused on the "who reports to this person" view.

**Options:**
- `--manager/-m TEXT` — target manager (defaults to the caller). Admins can query any manager; non-admin callers can only see their own.
- `--json` — JSON output

### ct team assign

```
ct team assign MANAGER MEMBER [MEMBER...] [--json]
ct team assign MANAGER --all [--json]
```

Assigns one or more members as direct reports to `MANAGER`. Admin or owner only.

Each positional accepts an email, user ID, or membership ID. `--all` assigns every active member of the organization (excluding the manager themselves). Mutually exclusive with positional members.

- Manager must have role `project_manager`, `manager`, `admin`, or `owner`.
- Members must be in the same organization.
- Already-assigned members are silently skipped (reported in `skipped.already_assigned`).

Endpoint: `POST /manager-assignments/bulk-set/` with `{manager, add: [ids]}`.

### ct team unassign

```
ct team unassign MANAGER MEMBER [MEMBER...] [--json]
ct team unassign MANAGER --all [--json]
```

Removes one or more direct-report assignments from `MANAGER`. Admin or owner only.

Each positional is a member (email, user ID, or membership ID) — **not** an assignment ID. `--all` clears every current direct report for this manager.

Endpoint: `POST /manager-assignments/bulk-set/` with `{manager, remove: [ids]}`.

### ct team set

```
ct team set MANAGER [--member EMAIL]... [--all] [--json]
```

Declaratively sets the full list of direct reports for `MANAGER`. The CLI fetches the current assignments, computes the diff against the desired set, and applies both adds and removes in a single atomic call. Admin or owner only.

Examples:

- `ct team set alice@co.com --member bob --member carol` — reports are exactly {bob, carol}; anyone else currently assigned is unassigned.
- `ct team set alice@co.com` — clear all (zero `--member` flags).
- `ct team set alice@co.com --all` — reports are every active org member.

Endpoint: `POST /manager-assignments/bulk-set/` with both `add` and `remove` computed client-side.

### Visibility semantics

A `manager` or `project_manager` sees time entries, timesheets, and team reports only for users in their **visible set**, which is the union of:

1. **Direct reports** — members in `ct team list --manager me`.
2. **PM-project members** — users of projects where the caller holds `project_role = project_manager` (see `ct projects update-member`).

A `manager` with **zero** assignments and **zero** PM projects sees only their own entries. `admin` and `owner` always see everything.

Timesheet approval follows the same rule: a manager can approve/reject only timesheets of users in their visible set (or projects where they are the explicit PM). Admins/owners can approve anything.

---

## ct version

```
ct version [--json]
```

Shows the installed CrowdTime CLI version and the latest version published to PyPI. Fetches fresh from PyPI every call (bypasses the 12-hour background-check cache).

**Output:**
- Plain: three lines — installed, latest, and a summary (`✓ You are up to date` or `⚠ A newer version is available`).
- `--json`: `{ "installed": "0.10.0", "latest": "0.11.0", "up_to_date": false, "outdated": true }`.

**Related:** after every other `ct` command, the CLI also performs a once-per-12-hours background check against PyPI and prints a one-line upgrade hint to stderr when out of date. Opt out with either:

- `CROWDTIME_NO_VERSION_CHECK=1` environment variable
- `ct config set update_check.enabled false`

Dev builds, pre-release tags (`rc`, `a`, `dev`, etc.), and local version suffixes are skipped — no warning, no network call is wasted on comparing uncomparable versions.

**Note:** `ct --version` (top-level flag) prints only the installed version without hitting the network, while `ct version` (subcommand) also fetches and compares.

---

## ct aliases

```
ct aliases
```

Displays all available shortcut commands in a formatted table. Shows each alias and what command it expands to. Useful for quickly discovering available shortcuts.

---

## Short Aliases

| Alias | Expands To |
|-------|-----------|
| `ct` | `ct status` |
| `ct s` | `ct status` |
| `ct t` | `ct timer status` |
| `ct ts` | `ct timer start` |
| `ct tx` | `ct timer stop` |
| `ct l` | `ct log` (create) |
| `ct ll` | `ct log list` |
| `ct p` | `ct projects list` |
| `ct r` | `ct report` |
| `ct b` | `ct billing status` |
| `ct sw` | `ct timer switch` |
| `ct c` | `ct timer continue` |
| `ct d` | `ct timer discard` |
| `ct f <id>` | `ct favorites start <id>` |
| `ct ex` | `ct expense` |
| `ct "text"` | `ct ai parse "text"` |
