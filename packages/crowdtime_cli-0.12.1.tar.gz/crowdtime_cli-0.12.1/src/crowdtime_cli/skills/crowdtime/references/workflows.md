# CrowdTime CLI — Common Workflows

Multi-step workflow patterns for real-world time tracking scenarios.

## Table of Contents

- [Daily Routines](#daily-routines)
- [End of Week](#end-of-week)
- [Project Setup](#project-setup)
- [Project Setup and Configuration](#project-setup-and-configuration)
- [Backfilling Time](#backfilling-time)
- [Team Management](#team-management)
- [Reporting and Export](#reporting-and-export)
- [Timesheet Submission and Approval](#timesheet-submission-and-approval)
- [Expense Tracking](#expense-tracking)
- [Client Contact Management](#client-contact-management)
- [Project Budget Tracking](#project-budget-tracking)
- [Invoicing and Billing](#invoicing-and-billing)
- [Payroll Management](#payroll-management)
- [Subscription and Billing](#subscription-and-billing)
- [Troubleshooting](#troubleshooting)

---

## Daily Routines

### Morning Start

```bash
# Check what's going on
ct s

# Start working
ct ts "morning standup" -p team-meetings
```

### Edit Running Timer

```bash
# Fix description without stopping the timer
ct timer edit -n "updated description"

# Change task on current timer
ct timer edit -t "code review"

# Toggle billable status
ct timer edit -b     # mark billable
ct timer edit -B     # mark non-billable
```

### Switch Between Tasks

```bash
# Atomic switch — stops current timer and starts new one
ct timer switch "API endpoint work" -p backend

# Or stop and start separately
ct tx
ct ts "design review" -p frontend
```

### Resume After a Break

```bash
# Continue what you were doing before (lunch, meeting, etc.)
ct timer continue

# Continue with updated notes
ct timer continue --note "Continued after standup"

# Continue and override billable status
ct timer continue -b     # resume as billable
ct timer continue -B     # resume as non-billable

# Short alias
ct c
ct c -b                  # continue as billable
```

### End of Day

```bash
# Stop running timer
ct tx

# Check today's log
ct ll --today

# See total hours
ct s
```

### Quick Entry Without Timer

If you forgot to use a timer, log directly:

```bash
ct l -p acme-project 1h30m "client call with Acme"
ct l -p backend 45m "code review for PR #234"
```

---

## End of Week

### Weekly Review

```bash
# See the full week at a glance
ct s

# Detailed report grouped by project
ct report --week -g project

# Report grouped by day to spot gaps
ct report --week -g day

# Get AI summary for standup
ct ai summarize --week --for standup

# Get AI summary for Slack, auto-copied
ct ai summarize --week --for slack --copy
```

### Fill In Missing Days

```bash
# Check what days are light
ct report --week -g day

# Backfill entries
ct l -p project-alpha -d monday 6h "feature development"
ct l -p project-alpha -d monday 2h "code review"
ct l -p project-beta -d tuesday 7h "API integration"
```

### Client Billing Summary

```bash
# Billable hours and amounts grouped by client
ct report client --month

# Filter to a specific client
ct report client --client <client-id> --from 2026-01-01 --to 2026-03-31

# JSON for programmatic use
ct report client --month --json
```

### Budget Tracking

```bash
# Budget burn-down for a project
ct report budget -p <project-id>

# JSON for external tools
ct report budget -p <project-id> --json
```

### Invoice Overview

```bash
# Quick invoice summary (counts, outstanding, overdue, avg days to payment)
ct invoice summary

# List overdue invoices sorted by due date (shows days overdue indicator)
ct invoice list --status overdue --sort due_date

# Full aging report — invoices grouped by overdue buckets (current, 1-30d, 31-60d, 61-90d, 90+d)
ct invoice aging

# Aging for a specific client
ct invoice aging --client CLIENT_ID

# Filter invoices by due date range (e.g. due this month)
ct invoice list --due-from 2026-04-01 --due-to 2026-04-30
```

### Export for Invoicing

```bash
# CSV export for spreadsheet
ct report --month -p client-project -f csv > march-2026-hours.csv

# Markdown for docs/email
ct report --month -g project -f markdown

# JSON for programmatic use
ct report --month -f json

# Filter by client across all report types
ct report projects --client <client-id> --month
ct report team --client <client-id> --month
```

---

## Project Setup

### Create a New Project with Tasks

```bash
# Create the project (client is auto-created if it doesn't exist)
ct projects create "Website Redesign" --client "Acme Corp" --budget 200 --code WR -b

# Create tasks for the project (use project slug, not display name)
ct tasks create "Design" -p website-redesign -b
ct tasks create "Development" -p website-redesign -b
ct tasks create "QA Testing" -p website-redesign -b
ct tasks create "Meetings" -p website-redesign -B  # non-billable

# Set as default if it's your main project
ct projects switch website-redesign
```

### Create Favorites for Recurring Work

```bash
# Create templates for things you do every day
ct favorites create "Daily standup" -p team-meetings -t standup
ct favorites create "Code review" -p engineering -t review -b
ct favorites create "Sprint planning" -p team-meetings -t planning

# Save an existing time entry as a favorite template
ct log save <entry-id>   # copies project, task, description, billable status

# Start a timer from a favorite
ct favorites list    # find the ID
ct favorites start <id>

# Start with custom description (overrides template notes)
ct favorites start <id> -n "Sprint 42 planning"
```

---

## Project Setup and Configuration

### Full Project Setup with Billing Mode, Presets, and Team

Set up a complete project with billing configuration, task presets, and team members in one go.

```bash
# 1. Create the project with a billing mode
ct projects create "Website Redesign" --client "Acme Corp" --budget 200 --code WR -b --billing-mode per_person

# 2. Apply a task preset instead of creating tasks one by one
ct tasks apply-preset software_development -p website-redesign

# 3. Bulk-add team members with roles and rates
ct projects add-members website-redesign --user alice@co.com --user bob@co.com --role member --rate 120

# 4. Set project-specific roles and rates for individual members
ct projects update-member website-redesign alice@co.com --role project_manager --rate 150

# 5. Review the project team and tasks
ct projects members website-redesign
ct projects tasks website-redesign

# 6. Set as default project
ct projects switch website-redesign
```

### Configure Per-Person Billing

When using `per_person` billing mode, each team member can have their own rate on the project.

```bash
# Create project with per-person billing
ct projects create "Consulting Engagement" --client "Beta Inc" --billing-mode per_person -b

# Add members with different rates
ct projects add-members consulting-engagement --user senior@co.com --user junior@co.com
ct projects update-member consulting-engagement senior@co.com --rate 200
ct projects update-member consulting-engagement junior@co.com --rate 100
```

### Apply Task Presets to an Existing Project

```bash
# Browse available presets
ct tasks presets

# Apply a preset — creates tasks and assigns them to the project
ct tasks apply-preset design_studio -p website-redesign

# Bulk-assign additional existing tasks
ct projects add-tasks website-redesign --task "Admin" --task "Travel"
```

### Managing Tasks

```bash
# Rename a task
ct tasks edit <task-id> --name "Code Review & QA"

# Change billable status
ct tasks edit <task-id> --no-billable

# Archive a task no longer needed
ct tasks archive <task-id>
```

### Invoice with Per-User Grouping

When a project uses per-person billing, grouping the invoice by user gives clients a clear breakdown.

```bash
# Create invoice grouped by team member
ct invoice create --client "Acme Corp" --period last-month --group-by user --payment-terms net30

# Add a line item with a discount (e.g. 2 hours courtesy)
ct invoice add-item <invoice-id> --desc "Extra support" --qty 10 --rate 150 --discount-type hours --discount-value 2

# Review and send
ct invoice show <invoice-id>
ct invoice send <invoice-id>
```

---

## Backfilling Time

### Log a Full Past Day

```bash
# Log multiple entries for yesterday (options MUST come before duration/description)
ct l -p team -d yesterday 1h "standup + planning"
ct l -p project-alpha -d yesterday -b 4h "feature implementation"
ct l -p project-alpha -d yesterday -b 2h "code review"
ct l -p project-alpha -d yesterday -B 1h "documentation"
```

### Log for a Specific Past Date

```bash
ct l -p training -d "last wednesday" 8h "workshop"
ct l -p acme -d 2026-03-05 3h "client meeting"
```

### Duplicate a Previous Entry

```bash
# Clone yesterday's entry to today (same project, task, duration, description)
ct log duplicate <entry-id>

# Clone but adjust the date and duration
ct log duplicate <entry-id> --date yesterday --duration 3h

# Clone with a new description
ct log duplicate <entry-id> --description "Continued work on feature"
```

### Clean Up Incorrect Entries

```bash
# Delete multiple entries at once (e.g. duplicate imports)
ct log bulk-delete <id1> <id2> <id3>

# Skip confirmation with --force
ct log bulk-delete <id1> <id2> --force

# Locked entries and entries on submitted timesheets are safely skipped
```

---

## Team Management

### Onboard a New Team Member

```bash
# Invite a regular team member
ct org invite newdev@company.com -r member

# Invite a project manager (can manage projects/tasks/timesheets, no financial access)
ct org invite pm@company.com -r project_manager

# Invite an account manager (full financial access: invoices, rates, clients)
ct org invite billing@company.com -r manager

# Invite an external client stakeholder (read-only, scoped to their projects)
ct org invite client@acme.com -r viewer

# They receive an email with an "Accept Invitation" link
# New users can sign up with email/password or Google OAuth
```

### Manage Invitations

```bash
# List pending invitations
ct org invitations

# Resend an invitation email
ct org resend-invite <invitation-id>

# Revoke a pending invitation
ct org revoke-invite <invitation-id>
```

### Update or Remove Members

```bash
# Change a member's role
ct org update-member <user-id> --role project_manager

# Update hourly rate
ct org update-member <user-id> --rate 150

# Update weekly capacity
ct org update-member <user-id> --capacity 40

# Combine multiple updates
ct org update-member <user-id> --role admin --rate 200

# Remove a member (deactivates membership and revokes API tokens)
ct org remove-member <user-id>
ct org remove-member <user-id> --force  # Skip confirmation
```

### Role Reference

| Role | Description |
|------|-------------|
| `viewer` | External client: read-only, scoped to assigned projects |
| `member` | Logs time, manages own entries |
| `project_manager` | Manages projects, tasks, timesheets, team time. No financial data |
| `manager` | Account Manager: everything above + invoices, rates, clients, billing |
| `admin` | Manages org settings, members, integrations |
| `owner` | Full control including org deletion |

### Check Team Activity

```bash
# Team utilization this week
ct report team --week

# Specific member
ct report team --month --member john@company.com

# List all members
ct org members
```

### Assign Direct Reports to a Manager

A `manager` or `project_manager` sees time entries, timesheets, and reports only for users they are responsible for. Two independent axes determine that visibility:

1. **Direct-report assignments** (`ct team assign`) — person-based, visible across every project the member works on.
2. **Per-project PM assignment** (`ct projects update-member ... --role project_manager`) — project-based, visible to the PM for anyone logging time on that project.

A `manager` with zero assignments and zero PM projects sees only their own entries. `admin` and `owner` always see everything.

```bash
# Admin assigns three members as direct reports of a manager
ct team assign alice@company.com bob@company.com
ct team assign alice@company.com carol@company.com
ct team assign alice@company.com dave@company.com

# Alice — now a manager for those three — checks who reports to her
ct team reports

# Alice reviews her team's hours for the week (scoped automatically)
ct log list --week

# Alice can approve their timesheets without being a PM on any of their projects
ct timesheet list --status submitted
ct timesheet approve <timesheet-id>

# Remove an assignment later
ct team list --manager alice@company.com   # find the assignment ID
ct team unassign <assignment-id>
```

**Tip**: combine with per-project PM assignment when a manager should also see *all* contributors on a specific project — even those who aren't direct reports. For example, use `ct projects update-member <project-id> <user-id> --role project_manager` for a project lead, and `ct team assign` for HR-style oversight.

---

## Reporting and Export

### Client Billing Report

```bash
# Monthly billable hours for a specific project
ct report --month -p client-project -f csv > invoice-data.csv

# Project breakdown across all projects
ct report projects --month

# Detailed with day-by-day breakdown
ct report --from 2026-03-01 --to 2026-03-31 -g day -p client-project
```

### Personal Productivity

```bash
# How did I spend my week?
ct report --week -g project

# Daily breakdown
ct report --week -g day

# Get AI insights
ct ai summarize --week
```

### Custom Date Ranges

```bash
# Last two weeks
ct report --from 2026-02-24 --to 2026-03-09

# Specific sprint (2 weeks)
ct report --from 2026-03-01 --to 2026-03-14 -g task

# Quarter to date
ct report --quarter -g project -f markdown

# Last quarter client billing
ct report client --last-quarter

# Last month team utilization
ct report team --last-month
```

### Saving and Reusing Reports

```bash
# Save a quarterly client billing report
ct report saved create -n "Q1 Client Billing" -t client_invoice --from 2026-01-01 --to 2026-03-31 --shared

# Save a team report preset
ct report saved create -n "Monthly Team" -t team_utilization --shared

# List saved reports
ct report saved list

# Run a saved report with stored filters
ct report saved run <report-id>

# Run a saved report with overridden date range
ct report saved run <report-id> --from 2026-04-01 --to 2026-04-30

# Delete a saved report
ct report saved delete <report-id>
```

---

## Timesheet Submission and Approval

### Submit a Timesheet

Timesheets can cover any date range — a full week, a partial week, or a custom period.
This is useful when the month ends mid-week and you need to split submissions.

```bash
# Review your week first
ct report --week -g day

# Fill any gaps
ct l -p project-alpha -d monday 6h "feature development"

# Submit a full week
ct timesheet submit --from 2026-03-09 --to 2026-03-15 --force

# Submit a partial week (e.g. end-of-month split)
ct timesheet submit --from monday --to wednesday --force   # Close out March
ct timesheet submit --from thursday --to friday --force     # Start April

# Check submission status
ct timesheet list

# Made a mistake? Recall it back to draft (before approval) — confirms before executing
ct timesheet recall <timesheet-id> --notes "Need to fix Wednesday entries"
ct timesheet recall <timesheet-id> --force  # Skip confirmation

# Fix and resubmit
ct l -p project-alpha -d friday 2h "missed entry"
ct timesheet submit --from 2026-03-09 --to 2026-03-15 --force
```

### Project Manager: Review Project-Scoped Approvals

```bash
# See team overview for this week
ct timesheet team

# View per-project approval breakdown for a timesheet
ct timesheet approvals <timesheet-id>

# Approve YOUR project's portion (PM for that project) — confirms before executing
ct timesheet approve <timesheet-id> --project <project-id>
ct timesheet approve <timesheet-id> --project <project-id> --notes "Looks good"
ct timesheet approve <timesheet-id> --project <project-id> --force  # Skip confirmation

# Reject a project portion (rejects entire timesheet — user must fix & resubmit)
ct timesheet reject <timesheet-id> --project <project-id> --notes "Hours seem too high for this task"

# Bulk-approve for your specific project across multiple timesheets (PM)
ct timesheet bulk-approve <id1> <id2> --project <project-id>

# When all project portions are approved, the timesheet auto-approves
```

### Manager+: Bulk Approve/Reject

```bash
# Approve an entire timesheet at once (all project portions) — confirms before executing
ct timesheet approve <timesheet-id>
ct timesheet approve <timesheet-id> --force  # Skip confirmation

# Approve multiple timesheets at once
ct timesheet bulk-approve <id1> <id2> <id3> --notes "Week approved"

# Reject with feedback
ct timesheet reject <timesheet-id> --notes "Missing entries for Wednesday — please add your standup and dev hours"

# Reject multiple timesheets at once
ct timesheet bulk-reject <id1> <id2> --notes "Incomplete entries for the week"

# View full audit trail for a timesheet (submissions, approvals, rejections)
ct timesheet history <timesheet-id>
```

### Approval Permission Tiers

| Tier | Role | Scope |
|------|------|-------|
| 1 | `project_manager` | Can approve for projects they're assigned to as PM |
| 2 | `manager` | Can approve for ANY project (client-level authority) |
| 3 | `admin` / `owner` | Can approve anything org-wide |

### HR: Compliance Check

```bash
# Check who hasn't submitted for this week
ct timesheet compliance

# Check last week's compliance
ct timesheet compliance --last-week

# Custom period
ct timesheet compliance --from 2026-03-09 --to 2026-03-15

# Shows: summary (counts + completion %), not submitted list (with has_entries flag),
# pending approval (with days waiting), and rejected timesheets needing resubmission
```

### End-of-Week / End-of-Month Timesheet Routine

```bash
# 1. Check your hours
ct report --week

# 2. Fill gaps
ct report --week -g day   # spot light days

# 3a. Submit full week
ct timesheet submit --from 2026-03-09 --to 2026-03-15 --force

# 3b. OR submit partial week (month ends mid-week)
ct timesheet submit --from 2026-03-30 --to 2026-03-31 --force  # Close March
# ...later, after logging remaining days...
ct timesheet submit --from 2026-04-01 --to 2026-04-05 --force  # Submit April portion

# 4. (Manager) Review team — shows capacity %, status, and partial submissions
ct timesheet team

# 5. (Manager) Bulk approve all submitted
ct timesheet list --status submitted   # get IDs
ct timesheet bulk-approve <id1> <id2> <id3>
```

---

## Expense Tracking

### Logging an Expense

```bash
# Log a billable expense to a project
ct expense create --amount 49.99 "Domain renewal" --project acme-website --category "Software" --vendor "Namecheap" --billable

# Log a non-billable internal expense
ct expense create --amount 29.99 "Team Slack subscription" --category "Software"

# Log a past expense
ct ex create --amount 85 "Client dinner" --category "Meals" --vendor "La Trattoria" -d yesterday --billable -p acme-project
```

### Setting Up Expense Categories

```bash
# Check existing categories
ct expense categories

# Add categories for your organization
ct expense add-category "Software"
ct expense add-category "Travel"
ct expense add-category "Meals"
ct expense add-category "Office Supplies"
ct expense add-category "Hardware"
```

### Reviewing Expenses

```bash
# List expenses for a period
ct expense list --from 2026-03-01 --to 2026-03-31

# Filter by project and billable status
ct expense list --project acme-website --billable

# Check which expenses have been invoiced
ct expense list --invoiced

# Check uninvoiced billable expenses
ct expense list --billable --from 2026-03-01 --to 2026-03-31
```

### Editing and Deleting Expenses

```bash
# Fix an amount
ct expense edit <expense-id> --amount 59.99

# Change the category
ct expense edit <expense-id> --category "Travel"

# Delete an incorrect expense
ct expense delete <expense-id>
```

---

## Client Contact Management

### Editing Client Details

```bash
# Update client name
ct clients edit <client-id> --name "Acme Corporation"

# Change currency
ct clients edit <client-id> --currency EUR

# Update contact info and address
ct clients edit <client-id> --contact "Jane Doe" --email jane@acme.com --city "New York"
```

### Adding Contacts to a Client

```bash
# List existing contacts
ct clients contacts <client-id>

# Add a primary contact
ct clients add-contact <client-id> --name "Jane Smith" --email jane@acme.com --phone "+1-555-0123" --role "CEO" --primary

# Add additional contacts
ct clients add-contact <client-id> --name "Bob Johnson" --email bob@acme.com --role "Billing Manager" --receives-invoices
ct clients add-contact <client-id> --name "Alice Chen" --email alice@acme.com --role "Project Lead"
```

### Removing a Contact

```bash
# List contacts to find the ID
ct clients contacts <client-id>

# Remove a contact
ct clients remove-contact <client-id> <contact-id>
```

---

## Project Budget Tracking

### Checking Project Budget

```bash
# View budget status for a project
ct projects budget acme-website

# Refresh the snapshot (recalculates from latest time entries)
ct projects budget acme-website --refresh

# Check multiple projects
ct projects budget acme-website
ct projects budget internal-tools
```

### Budget Monitoring Routine

```bash
# 1. Get project health dashboard with burn rates and exhaustion dates
ct insights projects

# 2. Show only at-risk projects (above budget alert threshold)
ct insights projects --at-risk

# 3. Check all project budgets in detail
ct report projects --month

# 4. Drill into projects that look close to budget
ct projects budget acme-website --refresh

# 5. If over budget, review recent entries
ct report --month -p acme-website -g task
```

### Updating Project Budget

```bash
# Increase budget amount
ct projects update acme-website --budget 300 --budget-type hours

# Change budget alert threshold
ct projects update acme-website --budget-alert 90

# Change billing mode
ct projects update my-project --billing-mode per_person

# Pause a project
ct projects update my-project --status paused
```

### Team Utilization Review

```bash
# 1. Get team utilization dashboard
ct insights team

# 2. Check team workload this week
ct insights team --week

# 3. See who is working on what — per-member per-project breakdown
ct insights allocations

# 4. Check allocations for a specific week
ct insights allocations --week

# 5. Drill into specific member's time
ct report team --month --member alice@co.com

# 6. Check timesheet compliance
ct timesheet compliance
```

### Financial Review (Manager+)

```bash
# 1. Revenue KPIs — total revenue, avg rate, billable ratio, AR aging
ct insights financial

# 2. Compare with previous period
ct insights financial --last-month --compare

# 3. Quarterly financial overview
ct insights financial --quarter

# 4. Identify uninvoiced revenue
ct insights financial --json | jq '.current.uninvoiced_amount'

# 5. Check AR aging details — full aging report with buckets
ct invoice aging

# 6. Profitability by project
ct insights profitability

# 7. Profitability by client (who's most profitable?)
ct insights profitability --by-client --quarter

# 8. Export profitability data
ct insights profitability --json
```

---

## Invoicing and Billing

### Review Uninvoiced Work

```bash
# See what billable work is ready to invoice, grouped by client
ct invoice uninvoiced

# Review the client report for the same period
ct report client --month

# Check tax rates are configured before creating invoices
ct invoice tax-rates
ct invoice tax-rates create --name "VAT" --rate 21.0 --default  # If needed
```

### Create and Send an Invoice

```bash
# 1. Create a draft invoice with period preset (auto-imports time + expenses)
ct invoice create --client "Acme Corp" --period last-month --payment-terms net30

# The output shows how many time entries and expenses were included.
# Billable expenses from the period are automatically added as line items.

# 2. Or create a blank draft and add items manually
ct invoice create-blank --client <client-id> --issue-date today --payment-terms net30
ct invoice add-item <invoice-id> --desc "Development" --qty 40 --rate 150
ct invoice add-item <invoice-id> --desc "Setup fee" --qty 1 --rate 500

# 3. Update draft fields (terms, notes, etc.)
ct invoice update <invoice-id> --terms "Wire to IBAN XX" --notes "March 2026"

# 4. Adjust line items if needed
ct invoice update-item <invoice-id> <item-id> --quantity 35 --unit-price 175
ct invoice remove-item <invoice-id> <item-id> --force  # Remove unwanted item

# 5. Review the invoice (includes time entries + expenses as line items)
ct invoice show <invoice-id>

# 6. Download PDF for review or send directly
ct invoice pdf <invoice-id>
ct invoice send <invoice-id>
ct invoice send <invoice-id> --to <contact-id> --cc <cc-id>  # Send to specific contacts
```

### Invoice with Period Presets

```bash
# Last week's billable time + expenses
ct invoice create --client "Acme Corp" --period last-week --payment-terms receipt

# Last two weeks
ct invoice create --client "Acme Corp" --period last-2-weeks --payment-terms net15

# Last month
ct invoice create --client "Acme Corp" --period last-month --payment-terms net30

# This month so far
ct invoice create --client "Acme Corp" --period this-month --payment-terms 45
```

### Invoice for a Specific Project

```bash
# Create invoice from time entries for a specific date range
ct invoice create --client <client-id> --from 2026-03-01 --to 2026-03-31

# Review and send — note: billable expenses from the period are included
ct invoice show <invoice-id>
ct invoice send <invoice-id>
```

### Creating Invoice with Expenses

```bash
# 1. Make sure billable expenses are logged with the right project
ct expense list --billable --from 2026-03-01 --to 2026-03-31

# 2. Create invoice with period preset — expenses are auto-included
ct invoice create --client "Acme Corp" --period last-month --payment-terms net30

# 3. Review — expenses appear as separate line items
ct invoice show <invoice-id>

# 4. Send
ct invoice send <invoice-id>
```

### Record Payment

```bash
# Full payment
ct invoice pay <invoice-id> --amount 1500 --method bank_transfer --reference "TXN-12345"

# Check invoice status
ct invoice show <invoice-id>
```

### Monthly Invoicing Routine

```bash
# 1. Review all projects for the month
ct report --month -g project

# 2. Check billable expenses for the month
ct expense list --billable --from 2026-03-01 --to 2026-03-31

# 3. List clients that need invoicing
ct clients list

# 4. Create invoices per client (period preset auto-imports time + expenses)
ct invoice create --client "Acme Corp" --period last-month --payment-terms net30
ct invoice create --client "Beta Inc" --period last-month --payment-terms net30

# 5. Review and send all drafts
ct invoice list --status draft
ct invoice show <invoice-id-1>    # Verify time entries + expenses look correct
ct invoice send <invoice-id-1>
ct invoice show <invoice-id-2>
ct invoice send <invoice-id-2>
```

### Duplicate a Recurring Invoice

```bash
# Find a previous invoice to base on
ct invoice list --client "Acme Corp" --status paid

# Duplicate it
ct invoice duplicate <invoice-id>

# Update the new draft as needed
ct invoice show <new-invoice-id>
```

---

## Recurring Invoice Templates

### Set Up a Monthly Recurring Invoice

```bash
# 1. Create a recurring template for a client
ct invoice recurring create --name "Monthly Acme Invoice" --client <client-id> \
  --schedule monthly --next-run 2026-05-01 --payment-terms 30 --group-by project

# 2. Verify the template
ct invoice recurring show <template-id>

# 3. If you want invoices sent automatically when generated
ct invoice recurring update <template-id> --auto-send
```

### Manage Recurring Templates

```bash
# List all templates
ct invoice recurring list

# Pause a template
ct invoice recurring update <template-id> --inactive

# Resume it
ct invoice recurring update <template-id> --active

# Change schedule
ct invoice recurring update <template-id> --schedule weekly --next-run 2026-04-14

# Manually generate an invoice from a template (out-of-cycle)
ct invoice recurring generate-now <template-id>

# Delete a template
ct invoice recurring delete <template-id>
```

---

## Retainer Management

### Set Up a Retainer and Track Balance

```bash
# 1. List retainers (with optional filters)
ct invoice retainer list
ct invoice retainer list --status active
ct invoice retainer list --client <client-id>
ct invoice retainer list --search "Acme"

# 2. View retainer details and balance
ct invoice retainer show <retainer-id>
```

### Apply Retainer Credit to an Invoice

```bash
# 1. Check retainer balance
ct invoice retainer show <retainer-id>

# 2. Find the invoice to pay
ct invoice list --status sent --client "Acme Corp"

# 3. Apply retainer credit
ct invoice retainer withdraw <retainer-id> --invoice <invoice-id> --amount 2000 --notes "March credit"

# 4. Verify the invoice payment
ct invoice show <invoice-id>
```

### View Withdrawal History

```bash
# List all withdrawals for a retainer
ct invoice retainer withdrawals <retainer-id>
```

### Reverse a Withdrawal

```bash
# If a withdrawal was applied incorrectly
ct invoice retainer reverse-withdrawal <retainer-id> --withdrawal <withdrawal-id> --reason "Applied to wrong invoice"

# Verify the reversal
ct invoice retainer show <retainer-id>    # Balance restored
ct invoice show <invoice-id>               # Payment removed
```

### Monthly Retainer Routine

```bash
# 1. Generate retainer invoice for the period
#    (done via web UI or API — generates draft with retainer fee + overage)

# 2. Review and send the retainer invoice
ct invoice list --type retainer --status draft
ct invoice show <retainer-invoice-id>
ct invoice send <retainer-invoice-id>

# 3. Record payment when client pays the retainer invoice
ct invoice pay <retainer-invoice-id> --amount 5000 --method bank_transfer --reference "TXN-456"

# 4. Now the retainer balance increases — apply to standard invoices
ct invoice retainer show <retainer-id>
ct invoice retainer withdraw <retainer-id> --invoice <standard-invoice-id> --amount 3000
```

---

## Payroll Management

### Set Up Member Compensation

```bash
# List members to see who needs compensation setup
ct payroll members

# Set hourly rate for a contractor
ct payroll set-rate alice@company.com 75.00

# Set hourly rate in a specific currency (for international teams)
ct payroll set-rate alice@company.com 65.00 --currency EUR

# Set monthly salary for a full-time employee
ct payroll set-salary bob@company.com 5000

# Set monthly salary in a specific currency
ct payroll set-salary bob@company.com 4500 --currency GBP

# Set a future rate change (effective next month)
ct payroll set-rate alice@company.com 90.00 --effective 2026-04-01

# Review a member's compensation history
ct payroll show alice@company.com
```

### Monthly Payroll Routine

```bash
# 1. Preview the payroll before committing
ct payroll run --dry-run

# 2. Run the actual liquidation
ct payroll run

# 3. Review the calculated period
ct payroll periods
ct payroll period <period-id>

# 4. Approve the period
ct payroll approve <period-id>

# 5. Mark all payments as paid (bulk)
ct payroll mark-paid <period-id> --all --method bank_transfer --ref BATCH-2026-03

# Or mark individual payments
ct payroll mark-paid <period-id> alice@company.com --method bank_transfer --ref TXN-98765
ct payroll mark-paid <period-id> bob@company.com --method bank_transfer --ref TXN-98766
```

### Run Payroll for a Past Month

```bash
# Run for a specific past month
ct payroll run --period 2026-02

# Approve and pay
ct payroll approve <period-id>
ct payroll mark-paid <period-id> --all --method bank_transfer --ref BATCH-2026-02
```

### Check Payment Status

```bash
# List all payments
ct payroll payments

# Filter by period and status
ct payroll payments --period 2026-03 --status pending

# Filter by member
ct payroll payments --member alice@company.com
```

### Payroll Access Control

Only admins and owners can access payroll data.

---

## Subscription and Billing

### Check Subscription Status

```bash
# Quick check
ct billing

# Machine-readable
ct billing --json
```

### Start a Subscription

```bash
# Start a free trial (opens Stripe Checkout in browser)
ct billing checkout

# Start with annual plan (20% savings)
ct billing checkout annual
```

### Manage Subscription via Stripe Portal

```bash
# Open Stripe billing portal (admin+ only)
ct billing portal

# From the portal you can:
# - Update payment method
# - View past Stripe invoices
# - Cancel subscription
```

### Switch Billing Plan

```bash
# Switch to annual billing (saves 20%)
ct billing plan annual

# Switch back to monthly
ct billing plan monthly

# Change takes effect immediately with prorated credit
```

### Reactivate a Canceled Subscription

```bash
# If subscription is set to cancel at period end:
ct billing reactivate

# Verify it's active again
ct billing
```

### View Billing Event History

```bash
# Show recent billing events (webhook audit log)
ct billing events

# Show more events
ct billing events -n 50

# Machine-readable
ct billing events --json
```

### Handle Subscription Issues

```bash
# If you see "subscription is inactive" errors on other commands:
ct billing                # Check current status
ct billing portal         # Open portal to update payment or resubscribe

# If subscription is canceled but still within billing period:
ct billing reactivate     # Undo the cancellation

# If you get "permission denied":
# - billing portal requires admin+ role
# - plan changes and reactivation require owner role
# Ask your org owner to manage the subscription.
```

---

## Troubleshooting

### "Not authenticated" Error

```bash
ct auth whoami           # Check current auth status
ct auth login            # Re-authenticate (opens browser)
ct auth login --token <your-token>  # Or use a token directly
```

### "No organization selected" Error

```bash
ct org list              # See available orgs
ct org switch <slug>     # Select one
```

### "Timer already running" Error

```bash
ct t                     # See what's running
ct timer switch "new task" -p project   # Switch to new task
# or
ct tx                    # Stop current timer first
```

### Wrong Default Project

```bash
ct config get defaults.project      # Check current default
ct projects switch <correct-slug>   # Change it
```

### Server Connection Issues

```bash
ct config get server.url            # Check configured URL
ct config set server.url https://api.crowdtime.lat   # Fix if needed
```

### Check Current Configuration

```bash
ct config list                      # See all settings
ct config edit                      # Edit in your editor
```

---

## Account & Data Management (GDPR)

### Export Personal Data

```bash
# Export all personal data to a JSON file
ct auth data-export --output my-data.json

# View export in terminal
ct auth data-export
```

### Delete Account

```bash
# Request account deletion (30-day grace period)
ct auth delete-account

# Check deletion status
ct auth delete-account --status

# Cancel pending deletion
ct auth delete-account --cancel
```
