"""Browser-based OAuth login flow for CrowdTime CLI.

Opens the user's browser for Google OAuth authentication. The CLI polls
the server for the auth code, then exchanges it for an API token (PKCE-protected).
"""

from __future__ import annotations

import hashlib
import secrets
import time
import webbrowser

import httpx


def run_oauth_flow(server_url: str, timeout: int = 120) -> tuple[str, str] | None:
    """Run the browser-based OAuth login flow with PKCE protection.

    1. Opens browser for Google OAuth on the server
    2. Polls the server until the auth code is available
    3. Exchanges the code + PKCE verifier for an API token

    Args:
        server_url: The CrowdTime server URL (e.g. https://api.crowdtime.lat).
        timeout: Max seconds to wait for the user to complete OAuth.

    Returns:
        Tuple of (api_token, org_slug) on success, or None on failure/timeout.
    """
    # Generate PKCE pair
    code_verifier = secrets.token_hex(32)
    code_challenge = hashlib.sha256(code_verifier.encode()).hexdigest()

    # Generate state for CSRF protection
    state = secrets.token_hex(32)

    login_url = (
        f'{server_url}/api/v1/auth/cli-login/'
        f'?state={state}&code_challenge={code_challenge}'
    )

    if not webbrowser.open(login_url):
        return None

    # Poll the server for the auth code
    poll_url = f'{server_url}/api/v1/auth/cli-poll/?state={state}'
    deadline = time.monotonic() + timeout
    poll_interval = 2  # seconds

    while time.monotonic() < deadline:
        time.sleep(poll_interval)
        try:
            response = httpx.get(poll_url, timeout=10.0)
            if response.status_code == 200:
                data = response.json()
                if data.get('status') == 'complete' and data.get('code'):
                    return _exchange_code(
                        server_url=server_url,
                        code=data['code'],
                        code_verifier=code_verifier,
                    )
        except (httpx.HTTPError, ValueError, KeyError):
            pass  # Retry on transient errors

    return None


def _exchange_code(
    server_url: str,
    code: str,
    code_verifier: str,
) -> tuple[str, str] | None:
    """Exchange a one-time auth code for an API token via server-to-server POST.

    Args:
        server_url: The CrowdTime server URL.
        code: The one-time auth code from polling.
        code_verifier: The PKCE verifier to prove we initiated the flow.

    Returns:
        Tuple of (api_token, org_slug) on success, or None on failure.
    """
    try:
        response = httpx.post(
            f'{server_url}/api/v1/auth/cli-exchange/',
            json={
                'code': code,
                'code_verifier': code_verifier,
            },
            timeout=10.0,
        )

        if response.status_code != 200:
            return None

        data = response.json()
        token = data.get('token')
        org_slug = data.get('org_slug', '')

        if not token:
            return None

        return token, org_slug

    except (httpx.HTTPError, ValueError, KeyError):
        return None
