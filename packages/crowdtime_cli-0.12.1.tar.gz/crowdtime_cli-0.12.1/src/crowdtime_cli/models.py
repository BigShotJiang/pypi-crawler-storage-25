"""Pydantic models for CrowdTime API responses."""

from __future__ import annotations

import datetime as dt
from decimal import Decimal
from typing import Any, Optional
from pydantic import BaseModel, Field, model_validator


class User(BaseModel):
    id: str
    email: str
    first_name: str = ""
    last_name: str = ""
    timezone: str = "UTC"

    @property
    def display_name(self) -> str:
        if self.first_name or self.last_name:
            return f"{self.first_name} {self.last_name}".strip()
        return self.email


class Organization(BaseModel):
    id: str
    name: str
    slug: str
    role: str | None = None
    member_count: int | None = None


class Project(BaseModel):
    id: str
    name: str
    code: str = ""
    client: str | None = None
    client_name: str | None = None
    color: str = "#3B82F6"
    billing_mode: str = "custom"
    status: str = "active"
    is_billable: bool = True
    budget_type: str | None = "none"
    budget_amount: Decimal | None = None
    budget_alert_percent: int | None = 80
    description: str = ""
    notes: str = ""


class Task(BaseModel):
    id: str
    name: str
    project: str | None = None
    project_name: str | None = None
    is_billable: bool = True


class TimeEntry(BaseModel):
    model_config = {"extra": "ignore"}

    id: str | None = None
    description: str = ""
    notes: str = ""
    project: str | None = None
    project_name: str | None = None
    project_code: str | None = None
    project_color: str | None = None
    task: str | None = None
    task_name: str | None = None
    date: Optional[dt.date] = None
    start_time: Optional[dt.datetime] = None
    end_time: Optional[dt.datetime] = None
    duration: Decimal | None = None
    hours: Decimal | None = None
    is_running: bool = False
    is_billable: bool = True
    hourly_rate: Decimal | None = None
    billable_amount: Decimal | None = None
    user: str | None = None
    user_name: str | None = None
    source: str = ""
    created_at: Optional[dt.datetime] = None
    updated_at: Optional[dt.datetime] = None

    @model_validator(mode="before")
    @classmethod
    def _normalize_fields(cls, data: Any) -> Any:
        if isinstance(data, dict):
            # Map API field names to CLI field names
            if "notes" in data and not data.get("description"):
                data["description"] = data["notes"]
            if "hours" in data and not data.get("duration"):
                data["duration"] = data["hours"]
        return data


class FavoriteEntry(BaseModel):
    model_config = {"extra": "ignore"}

    id: str
    project: str | None = None
    project_name: str | None = None
    task: str | None = None
    task_name: str | None = None
    notes: str = ""
    description: str = ""
    is_billable: bool = True
    position: int = 0
    use_count: int = 0
    created_at: Optional[dt.datetime] = None

    @model_validator(mode="before")
    @classmethod
    def _normalize_fields(cls, data: Any) -> Any:
        if isinstance(data, dict):
            if "notes" in data and not data.get("description"):
                data["description"] = data["notes"]
        return data


class ParseResult(BaseModel):
    """Result from AI parse endpoint.

    The API returns flat fields (hours, description, project_id, etc.)
    alongside confidence, ambiguities, and parse_log_id.
    """
    model_config = {"extra": "ignore"}

    hours: Decimal | None = None
    description: str = ""
    project_id: str | None = None
    project_name: str | None = None
    task_id: str | None = None
    task_name: str | None = None
    date: Optional[dt.date] = None
    is_billable: bool = True
    confidence: float = 0.0
    ambiguities: list[str] = Field(default_factory=list)
    parse_log_id: str | None = None

    @property
    def parsed_fields(self) -> dict[str, Any]:
        """Return the parsed entry fields as a dict (for confirm endpoint)."""
        fields: dict[str, Any] = {}
        if self.hours is not None:
            fields["hours"] = str(self.hours)
        if self.description:
            fields["description"] = self.description
            fields["notes"] = self.description
        if self.project_id:
            fields["project_id"] = self.project_id
        if self.project_name:
            fields["project_name"] = self.project_name
        if self.task_id:
            fields["task_id"] = self.task_id
        if self.task_name:
            fields["task_name"] = self.task_name
        if self.date:
            fields["date"] = str(self.date)
        fields["is_billable"] = self.is_billable
        return fields


class Suggestion(BaseModel):
    model_config = {"extra": "ignore"}

    project_name: str = ""
    project_id: str | None = None
    task_name: str | None = ""
    task_id: str | None = None
    description: str = ""
    estimated_hours: Decimal | None = None
    reason: str = ""


class WeeklySummary(BaseModel):
    headline: str = ""
    total_hours: Decimal = Decimal("0")
    project_breakdown: list[dict[str, Any]] = Field(default_factory=list)
    insights: list[str] = Field(default_factory=list)


class ReportRow(BaseModel):
    project: str = ""
    task: str = ""
    hours: Decimal = Decimal("0")
    billable_hours: Decimal = Decimal("0")
    entries_count: int = 0


class Member(BaseModel):
    id: str
    user_email: str = ""
    user_name: str = ""
    role: str = "member"
    is_active: bool = True


class TokenResponse(BaseModel):
    id: str | None = None
    name: str = ""
    key: str = ""
    key_prefix: str = ""
    scopes: list[str] = Field(default_factory=list)


class CompensationConfig(BaseModel):
    id: str
    membership: str | None = None
    member_name: str = ""
    member_email: str = ""
    compensation_type: str = ""
    hourly_rate: Decimal | None = None
    monthly_salary: Decimal | None = None
    currency: str = "USD"
    effective_from: Optional[dt.date] = None


class PayrollPeriod(BaseModel):
    id: str
    period_start: Optional[dt.date] = None
    period_end: Optional[dt.date] = None
    status: str = "draft"
    total_amount: Decimal = Decimal("0")
    total_paid: Decimal = Decimal("0")
    member_count: int = 0


class PayrollEntry(BaseModel):
    id: str
    member_name: str = ""
    member_email: str = ""
    compensation_type: str = ""
    hourly_rate: Decimal | None = None
    monthly_salary: Decimal | None = None
    total_hours: Decimal = Decimal("0")
    gross_amount: Decimal = Decimal("0")
    payment_status: str = "unpaid"


class PayrollPayment(BaseModel):
    id: str
    amount: Decimal = Decimal("0")
    status: str = "pending"
    payment_method: str = "bank_transfer"
    paid_at: Optional[dt.datetime] = None
    reference: str = ""
    member_name: str = ""
