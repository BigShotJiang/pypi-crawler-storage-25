# hik_check

A command-line tool for Hikvision device management.

## Installation

```bash
pip install hik_check
```

## Requirements

- Python >= 3.7
- `requests` library (installed automatically)

## Usage

```bash
hik_check [options]
```

## Developer

Migara Mewantha
