from .script import main
