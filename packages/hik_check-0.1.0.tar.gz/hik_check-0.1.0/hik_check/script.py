#!/usr/bin/env python3
# Developer: Migara Mewantha
# Hikvision Device Management Script (Python Port)
# Version: 6.0 (py)

# =====================================
# Installation
# =====================================
# pip3 install requests
# chmod +x hikcheck.py
# sudo python3 hikcheck.py install

import sys
import os
import json
import time
import argparse
import random
import csv
import subprocess
import re
import shutil
import xml.etree.ElementTree as ET
from datetime import datetime

# Check for requests library
try:
    import requests
    from requests.auth import HTTPDigestAuth
    from requests.packages.urllib3.exceptions import InsecureRequestWarning
    # Suppress SSL warnings for local IPs
    requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
except ImportError:
    print("\033[0;31mERROR: Python 'requests' library is missing.\033[0m")
    print("Please run: pip3 install requests")
    sys.exit(1)

# ================================
# Configuration & Globals
# ================================

SCRIPT_NAME = "hikcheck"
INSTALL_PATH = f"/usr/local/bin/{SCRIPT_NAME}"
# CONFIG_DIR = os.path.expanduser("~/.config/hikcheck")
# CONFIG_FILE = os.path.join(CONFIG_DIR, "config.json")
CONFIG_DIR = ""
CONFIG_FILE = ""

# Colors
RED = '\033[0;31m'
GREEN = '\033[0;32m'
BLUE = '\033[1;34m'
YELLOW = '\033[1;33m'
NC = '\033[0m'

# Default Config
DEFAULT_CONFIG = {
    "username": "admin",
    "password": "Hik12345",
    "base_ip": "192.168.1",
    "timeout": 5
}

# Current runtime config
CONFIG = DEFAULT_CONFIG.copy()

# ================================
# Utility Functions
# ================================

def print_error(msg):
    print(f"{RED}ERROR: {msg}{NC}", file=sys.stderr)

def print_success(msg):
    print(f"{GREEN}✓ {msg}{NC}")

def print_info(msg):
    print(f"{BLUE}ℹ {msg}{NC}")

def print_warning(msg):
    print(f"{YELLOW}⚠ {msg}{NC}")

def get_user_home():
    if 'SUDO_USER' in os.environ:
        sudo_user = os.environ['SUDO_USER']
        return os.path.expanduser(F"~{sudo_user}")
    return os.path.expanduser("~")

CONFIG_DIR = os.path.join(get_user_home(), ".config", "hikcheck")
CONFIG_FILE = os.path.join(CONFIG_DIR, "config.json")

print("Config: ", CONFIG_FILE)

def load_config():
    global CONFIG
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, 'r') as f:
                loaded = json.load(f)
                CONFIG.update(loaded)
        except Exception as e:
            print_warning(f"Failed to load config: {e}")

def create_config():
    os.makedirs(CONFIG_DIR, exist_ok=True)
    with open(CONFIG_FILE, 'w') as f:
        json.dump(CONFIG, f, indent=4)
    print_success(f"Configuration file created at {CONFIG_FILE}")

def get_session():
    """Returns a requests session with Digest Auth configured."""
    s = requests.Session()
    s.auth = HTTPDigestAuth(CONFIG['username'], CONFIG['password'])
    s.headers.update({'Content-Type': 'application/json'})
    return s

def clean_xml(xml_string):
    """Removes namespaces to make parsing easier."""
    return re.sub(r' xmlns="[^"]+"', '', xml_string, count=1)

# ================================
# Device Query Functions
# ================================

def get_device_info(ip_addr):
    url = f"http://{ip_addr}/ISAPI/System/deviceInfo"
    try:
        r = get_session().get(url, timeout=CONFIG['timeout'])
        if r.status_code == 200:
            try:
                # Basic XML parsing
                root = ET.fromstring(clean_xml(r.text))
                model = root.findtext('model')
                fw_ver = root.findtext('firmwareVersion')
                fw_date = root.findtext('firmwareReleasedDate')

                print(f"{BLUE}Device Information:{NC}")
                print(f"   Device Model: {model}")
                print(f"   Firmware Version: {fw_ver}")
                print(f"   Firmware Build: {fw_date}")
                print("")
                return True
            except ET.ParseError:
                print_error("Failed to parse device info XML")
        else:
            print_error(f"HTTP Error {r.status_code}")
    except requests.RequestException:
        print_error("Connection failed")
    return False

def get_device_time(ip_addr):
    url = f"http://{ip_addr}/ISAPI/System/time"
    try:
        r = get_session().get(url, timeout=CONFIG['timeout'])
        if r.status_code == 200:
            root = ET.fromstring(clean_xml(r.text))
            local_time = root.findtext('localTime')
            tz_node = root.find('timeZone')
            tz_string = tz_node.text if tz_node is not None else "Unknown"

            # Extract offset like +05:30
            tz_offset_match = re.search(r'[+-][0-9]{1,2}:[0-9]{2}', tz_string)
            tz_offset = tz_offset_match.group(0) if tz_offset_match else "Unknown"

            print(f"{BLUE}Time Details:{NC}")
            print(f"   Local Time: {local_time}")
            print(f"   Timezone: {tz_offset}")
            print(f"   Timezone Data: {tz_string}")
            print("")
            return True
        else:
            print_error("Could not retrieve time information")
    except requests.RequestException:
        print_error("Connection failed")
    return False

def get_device_counts(ip_addr):
    print(f"{BLUE}Counts:{NC}")
    session = get_session()

    # 1. User Count
    try:
        r = session.get(f"http://{ip_addr}/ISAPI/AccessControl/UserInfo/Count?format=json", timeout=CONFIG['timeout'])
        if r.status_code == 200:
            data = r.json()
            # Handle potential nesting differences or missing keys
            count = data.get('UserInfoCount', {}).get('userNumber', 'Error')
            print(f"   User Count: {count}")
        else:
            print("   User Count: ERROR")
    except:
        print("   User Count: ERROR")

    # 2. Card Count
    try:
        r = session.get(f"http://{ip_addr}/ISAPI/AccessControl/CardInfo/Count?format=json", timeout=CONFIG['timeout'])
        if r.status_code == 200:
            data = r.json()
            count = data.get('CardInfoCount', {}).get('cardNumber', 'Error')
            print(f"   Card Count: {count}")
        else:
            print("   Card Count: ERROR")
    except:
        print("   Card Count: ERROR")

    # 3. Face Count
    try:
        r = session.get(f"http://{ip_addr}/ISAPI/Intelligent/FDLib/Count?format=json", timeout=CONFIG['timeout'])
        face_count = "ERROR"
        if r.status_code == 200:
            data = r.json()
            # Replicating jq logic: select(.faceLibType == "blackFD")
            if 'FDRecordDataInfo' in data:
                # Ensure list
                infos = data['FDRecordDataInfo'] if isinstance(data['FDRecordDataInfo'], list) else [data['FDRecordDataInfo']]
                for item in infos:
                    if item.get('faceLibType') == 'blackFD':
                        face_count = item.get('recordDataNumber', 'Error')
                        break

        if face_count == "ERROR" or face_count is None:
             print("   Face Count: ERROR")
        else:
             print(f"   Face Count: {face_count}")

    except:
        print("   Face Count: ERROR")
    print("")

def test_connection(ip_addr):
    print_info(f"Testing connection to {ip_addr}...")

    # Ping
    try:
        subprocess.run(['ping', '-c', '1', '-W', '2', ip_addr], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)
        print_success("Device is reachable (ping successful)")
    except subprocess.CalledProcessError:
        print_warning("Device did not respond to ping")

    # API Check
    try:
        r = get_session().get(f"http://{ip_addr}/ISAPI/System/deviceInfo", timeout=CONFIG['timeout'])
        if r.status_code == 200:
            print_success("API connection successful")
            get_device_info(ip_addr)
        else:
            print_error(f"API connection failed (HTTP {r.status_code})")
    except requests.RequestException as e:
        print_error(f"API connection failed: {e}")

# ================================
# Fetch Logic
# ================================

def draw_progress_bar(current, total, width=40):
    if total <= 0: total = 1
    percent = int(current * 100 / total)
    if percent > 100: percent = 100

    filled = int(percent * width / 100)
    empty = width - filled

    bar = '#' * filled + '.' * empty
    sys.stdout.write(f"\rProgress: [{bar}] {percent}% ({current}/{total})")
    sys.stdout.flush()

def fetch_events(ip_ending, start_time, end_time, timezone):
    timezone = timezone.strip()
    device_ip = f"{CONFIG['base_ip']}.{ip_ending}"

    print(f"\n{YELLOW}Starting Fetching Events from Device {device_ip}{NC}\n")

    # Input Device Type
    print("Select the device type")
    print("  1. FR (default)")
    print("  2. HAC")
    print("  3. SFR")
    dtype_in = input("Enter the No. : ").strip()

    if dtype_in == "2":
        device_type = "HAC"
    elif dtype_in == "3":
        device_type = "SFR"
    else:
        device_type = "FR"

    print(f"\nStart Time:    {start_time}")
    print(f"End Time  :    {end_time}\n")
    print(f"{GREEN}Choose an option...{NC}")
    print("  1. Fetch success events only")
    print("  2. Fetch all events")
    opt_in = input("Enter option: ").strip()

    major = 0
    minor = 0
    page_size = 30

    if opt_in == "1":
        if device_type == "HAC":
            major = 5
            minor = 1
            page_size = 5
        elif device_type in ["SFR", "FR"]:
            major = 5
            minor = 75

    print(f"\nUsing Major={major}, Minor={minor} (Device: {device_type})\n")
    print(f"{GREEN}Connecting to device {device_ip}...{NC}")

    position = 0
    total_matches = 0
    total_fetched = 0
    checkin_count = 0
    checkout_count = 0
    all_events = []

    session = get_session()
    url = f"http://{device_ip}/ISAPI/AccessControl/AcsEvent?format=json"

    while True:
        payload = {
            "AcsEventCond": {
                "searchID": "1",
                "searchResultPosition": position,
                "maxResults": page_size,
                "major": major,
                "minor": minor,
                "startTime": f"{start_time}{timezone}",
                "endTime": f"{end_time}{timezone}"
            }
        }

        # print("=== DEBUG INFO ===")
        # print(f"URL: {url}")
        # print(f"Position: {position}, Page Size: {page_size}")
        # print(f"Major: {major}, Minor: {minor}")
        # print(f"Start Time: {start_time}{timezone}")
        # print(f"End Time: {end_time}{timezone}")
        # print(f"Payload: {json.dumps(payload, indent=2)}")

        try:
            r = session.post(url, json=payload, timeout=CONFIG['timeout'] + 5)
            # print(f"Status Code: {r.status_code}")
            # print(f"Response Headers: {dict(r.headers)}")
            # print(f"Response Body: {r.text}")
            if r.status_code != 200:
                print_error(f"HTTP Error {r.status_code}")
                print_error(r)
                print(payload)
                break

            data = r.json()
            acs_event = data.get("AcsEvent", {})

            # Update Total Matches
            tm = acs_event.get("totalMatches", 0)
            if isinstance(tm, int) and tm > 0:
                total_matches = tm
                print(f"Total Matches: {total_matches}")

            is_continue = input("Continue? (y/n): ").strip().lower()
            if is_continue != "y":
                break

            info_list = acs_event.get("InfoList", [])
            # Sometimes InfoList is a single dict if one result, or list if multiple
            if isinstance(info_list, dict):
                info_list = [info_list]
            elif not info_list:
                info_list = []

            count = len(info_list)
            if count == 0:
                break

            # Store Data
            all_events.extend(info_list)
            total_fetched += count

            draw_progress_bar(total_fetched, total_matches)

            # Count check-ins/outs for SFR
            if device_type == "SFR":
                for ev in info_list:
                    status = ev.get("attendanceStatus")
                    if status == "checkIn":
                        checkin_count += 1
                    elif status == "checkOut":
                        checkout_count += 1

            # Break conditions
            if position + count >= total_matches:
                break

            position += count

        except Exception as e:
            print_error(f"Exception during fetch: {e}")
            break

    print("\n\n============ SUMMARY ============")
    print(f"IP Address:       {device_ip}")
    print(f"Total Actions:    {total_matches}")
    print(f"Total Saved:      {total_fetched}")
    if device_type == "SFR":
        print(f"Check-ins:        {checkin_count}")
        print(f"Check-outs:       {checkout_count}")
    print("=================================\n")

    save_q = input("Do you want to save results? (y/n): ").strip().lower()
    if save_q != 'y':
        print("Exiting without saving.")
        return

    print("\nSelect output format:")
    print("1) Pretty JSON")
    print("2) CSV")
    fmt = input("Choose option: ").strip()

    base_filename = f"{device_ip}.acs_events"

    if fmt == "1":
        out_file = f"{base_filename}.json"
        with open(out_file, 'w') as f:
            json.dump(all_events, f, indent=4)
        print(f"Saved pretty JSON → {out_file}")

    elif fmt == "2":
        out_file = f"{base_filename}.csv"
        # CSV Headers: time,name,employeeNo,major,minor,attendanceStatus,serialNo
        with open(out_file, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(["time", "name", "employeeNo", "major", "minor", "attendanceStatus", "serialNo"])
            for ev in all_events:
                writer.writerow([
                    ev.get("time", ""),
                    ev.get("name", ""),
                    ev.get("employeeNoString", ""),
                    ev.get("major", ""),
                    ev.get("minor", ""),
                    ev.get("attendanceStatus", "N/A"),
                    ev.get("serialNo", "")
                ])
        print(f"Saved CSV → {out_file}")
    else:
        print("Invalid option.")

# ================================
# Wipe Logic
# ================================

def wipe_device(ip_ending, dev_type_arg="FR"):
    if not ip_ending:
        print_error("No IP ending provided.")
        return

    ip = f"{CONFIG['base_ip']}.{ip_ending}"
    dev_type = dev_type_arg.upper()

    print(f"{RED}========================================={NC}")
    print(f"{RED} ⚠  DANGER ZONE: Wiping Device {ip} {NC}")
    print(f"{RED}========================================={NC}")

    if dev_type == "HAC":
        print_info("Mode: High Assurance (HAC) - Will verify deletion.")

    print("This action will delete ALL users and events.\n")

    captcha = random.randint(1000, 9999)
    print(f"To confirm, type the code: {YELLOW}{captcha}{NC}")
    user_input = input("Enter code: ").strip()

    if user_input != str(captcha):
        print(f"\n{RED}Incorrect code. Operation cancelled.{NC}")
        return

    print(f"\n{YELLOW}Sending wipe command...{NC}")

    session = get_session()
    # PUT request to delete all
    wipe_payload = {
        "UserInfoDetail": {
            "mode": "all",
            "EmployeeNoList": [] # Empty list required by some firmware
        }
    }

    try:
        r = session.put(
            f"http://{ip}/ISAPI/AccessControl/UserInfoDetail/Delete?format=json",
            json=wipe_payload,
            timeout=CONFIG['timeout']
        )

        if r.status_code == 200:
            print_success("Wipe command accepted.")
        else:
            print_error(f"Failed to wipe. Code: {r.status_code} Msg: {r.text}")
            return
    except Exception as e:
        print_error(f"Connection failed: {e}")
        return

    # HAC Polling
    if dev_type == "HAC":
        print(f"{YELLOW}Waiting for database to clear (checking every 5s)...{NC}")
        loop_limit = 24
        loop_count = 0

        while loop_count < loop_limit:
            try:
                r = session.get(f"http://{ip}/ISAPI/AccessControl/CardInfo/Count?format=json", timeout=2)
                if r.status_code == 200:
                    cnt = r.json().get('CardInfoCount', {}).get('cardNumber', -1)
                    if cnt == 0:
                        print(f"\r{GREEN}Database cleared! (Cards: 0){NC}          ")
                        break
                    sys.stdout.write(f"\r{BLUE}Processing... Current Card Count: {cnt} ...{NC}")
                    sys.stdout.flush()
            except:
                pass

            time.sleep(5)
            loop_count += 1
        print("") # newline
    else:
        print("Refreshing data...")
        time.sleep(2)

    print("\n-----------------------------------------")
    print(" Final Device Status")
    print("-----------------------------------------")
    print("")
    get_device_counts(ip)




# Query User details
def fetch_user(ip_addr, user_state_id, mode):
    """
    Fetch user information from access control device.

    Args:
        ip_addr: IP address of the device
        user_state_id: Employee number to search for
        mode: If False, show simple logs. If True, return full response data.

    Returns:
        dict if mode is True, None otherwise
    """

    url = f"http://{ip_addr}/ISAPI/AccessControl/UserInfo/Search?format=json"

    payload = {
        "UserInfoSearchCond": {
            "maxResults": 10,
            "searchID": "1",
            "searchResultPosition": 0,
            "EmployeeNoList": [{"employeeNo": user_state_id}]
        }
    }

    try:
        response = requests.post(
            url,
            auth=HTTPDigestAuth('admin', 'Hik12345'),
            headers={"Content-Type": "application/json"},
            json=payload,
            timeout=10
        )

        response.raise_for_status()
        data = response.json()

        # Check if request was successful
        if data.get("UserInfoSearch", {}).get("responseStatusStrg") == "OK":
            user_info = data["UserInfoSearch"]["UserInfo"][0]
            user_name = user_info.get("name", "Unknown")

            if not mode:
                print(f"User name: {user_name}")
                print(f"Successfully synced to device {ip_addr}")
            else:
                return data
        else:
            # No match found
            if not mode:
                print(f"No match at device {ip_addr}")
            else:
                return data

    except requests.exceptions.RequestException as e:
        if not mode:
            print(f"Error connecting to device {ip_addr}: {str(e)}")
        else:
            return {"error": str(e)}


# ================================
# Installation
# ================================

def install_script():
    if os.geteuid() != 0:
        print_warning("Please run installation with sudo")
        sys.exit(1)

    print_info(f"Installing to {INSTALL_PATH}...")

    # Copy current script
    current_file = os.path.abspath(sys.argv[0])
    try:
        shutil.copy(current_file, INSTALL_PATH)
        os.chmod(INSTALL_PATH, 0o755)
        create_config()
        print_success("Installation complete!")
        print_info(f"You can now use '{SCRIPT_NAME}' from anywhere")
    except Exception as e:
        print_error(f"Installation failed: {e}")

def uninstall_script():
    print_warning("Uninstalling hikcheck...")
    if os.path.exists(INSTALL_PATH):
        try:
            # Need root
            if not os.access(INSTALL_PATH, os.W_OK):
                print_error("Permission denied. Run with sudo.")
                return
            os.remove(INSTALL_PATH)
            print_success(f"Removed {INSTALL_PATH}")
        except Exception as e:
            print_error(f"Error removing script: {e}")

    if os.path.exists(CONFIG_DIR):
        q = input("Remove configuration directory? (y/n): ").strip().lower()
        if q == 'y':
            shutil.rmtree(CONFIG_DIR)
            print_success("Configuration removed")

# ================================
# Main
# ================================


# ================================
# User Data Batch Fetch
# ================================

def save_users_csv(users, ip_addr, output_dir):
    """
    Saves user list to a CSV file in the specified directory.
    """
    if not users:
        print_warning(f"No users to save for {ip_addr}")
        return None

    try:
        os.makedirs(output_dir, exist_ok=True)
        csv_file = os.path.join(output_dir, f"users_{ip_addr}.csv")

        with open(csv_file, 'w', newline='') as f:
            writer = csv.writer(f)
            # Headers: userstate, name, starttime, endtime
            writer.writerow(["userstate", "name", "starttime", "endtime"])

            for u in users:
                valid = u.get("Valid", {})
                writer.writerow([
                    u.get("employeeNo", ""),
                    u.get("name", ""),
                    valid.get("beginTime", ""),
                    valid.get("endTime", "")
                ])

        print_success(f"Saved {len(users)} users to {csv_file}")
        return csv_file
    except Exception as e:
        print_error(f"Failed to save CSV: {e}")
        return None

def fetch_all_users(ip_addr):
    """
    Fetches all users from the device using pagination.
    Returns a list of user dicts.
    """
    print(f"\n{BLUE}Fetching all users from {ip_addr}...{NC}")

    session = get_session()
    url = f"http://{ip_addr}/ISAPI/AccessControl/UserInfo/Search?format=json"

    all_users = []
    position = 0
    page_size = 30
    total_matches = 0

    # Progress Bar initialization
    sys.stdout.write(f"\rInitializing fetch...")
    sys.stdout.flush()

    retry_count = 0
    MAX_RETRIES = 3

    while True:
        payload = {
            "UserInfoSearchCond": {
                "maxResults": page_size,
                "searchID": "1",
                "searchResultPosition": position,
                "EmployeeNoList": []
            }
        }

        try:
            r = session.post(url, json=payload, timeout=CONFIG['timeout'] + 5)

            # Handle 401 specifically by refreshing session
            if r.status_code == 401:
                if retry_count < MAX_RETRIES:
                    retry_count += 1
                    # print_warning(f"Auth failed (401). Retrying {retry_count}/{MAX_RETRIES} with new session...")
                    session = get_session() # Refresh session/nonce
                    time.sleep(1) # Small backoff
                    continue # Retry the same request
                else:
                    print_error("Multiple 401 errors. credentials might be wrong or device is rejecting requests.")
                    break

            if r.status_code != 200:
                print_error(f"HTTP Error {r.status_code}")
                # print_error(r.text)
                break

            # Reset retry count on success
            retry_count = 0

            data = r.json()
            search_result = data.get("UserInfoSearch", {})

            # Update total matches for progress bar
            tm = search_result.get("totalMatches", 0)
            if tm > 0:
                total_matches = tm

            # Extract users
            users = search_result.get("UserInfo", [])
            if isinstance(users, dict):
                users = [users]

            if not users:
                break

            all_users.extend(users)
            current_count = len(all_users)

            # Draw progress
            draw_progress_bar(current_count, total_matches)

            # Check for more
            status = search_result.get("responseStatusStrg", "OK")

            if status != "MORE":
                break

            if current_count >= total_matches and total_matches > 0:
                break

            position += len(users)

        except Exception as e:
            print_error(f"Error during fetch: {e}")
            break

    print(f"\n{GREEN}Fetch complete. Total users: {len(all_users)}{NC}")
    return all_users


# ================================
# Card Data Batch Fetch
# ================================

def save_cards_csv(cards, ip_addr, output_dir):
    """Saves card list to a CSV file in the specified directory."""
    if not cards:
        print_warning(f"No cards to save for {ip_addr}")
        return None

    try:
        os.makedirs(output_dir, exist_ok=True)
        csv_file = os.path.join(output_dir, f"cards_{ip_addr}.csv")

        with open(csv_file, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(["employeeNo", "cardNo", "cardType", "leaderCard"])
            for c in cards:
                writer.writerow([
                    c.get("employeeNo", ""),
                    c.get("cardNo", ""),
                    c.get("cardType", ""),
                    c.get("leaderCard", "")
                ])

        print_success(f"Saved {len(cards)} cards to {csv_file}")
        return csv_file
    except Exception as e:
        print_error(f"Failed to save CSV: {e}")
        return None


def fetch_all_cards(ip_addr):
    """Fetches all cards from the device using pagination."""
    print(f"\n{BLUE}Fetching all cards from {ip_addr}...{NC}")

    session = get_session()
    url = f"http://{ip_addr}/ISAPI/AccessControl/CardInfo/Search?format=json"

    all_cards = []
    position = 0
    page_size = 100
    total_matches = 0

    sys.stdout.write(f"\rInitializing fetch...")
    sys.stdout.flush()

    retry_count = 0
    MAX_RETRIES = 3

    while True:
        payload = {
            "CardInfoSearchCond": {
                "searchID": "1",
                "searchResultPosition": position,
                "maxResults": page_size
            }
        }

        try:
            r = session.post(url, json=payload, timeout=CONFIG['timeout'] + 5)

            if r.status_code == 401:
                if retry_count < MAX_RETRIES:
                    retry_count += 1
                    session = get_session()
                    time.sleep(1)
                    continue
                else:
                    print_error("Multiple 401 errors. Credentials may be wrong.")
                    break

            if r.status_code != 200:
                print_error(f"HTTP Error {r.status_code}")
                break

            retry_count = 0

            data = r.json()
            search_result = data.get("CardInfoSearch", {})

            tm = search_result.get("totalMatches", 0)
            if tm > 0:
                total_matches = tm

            cards = search_result.get("CardInfo", [])
            if isinstance(cards, dict):
                cards = [cards]

            if not cards:
                break

            all_cards.extend(cards)
            current_count = len(all_cards)

            draw_progress_bar(current_count, total_matches)

            status = search_result.get("responseStatusStrg", "OK")
            if status != "MORE":
                break

            if current_count >= total_matches and total_matches > 0:
                break

            position += len(cards)

        except Exception as e:
            print_error(f"Error during fetch: {e}")
            break

    print(f"\n{GREEN}Fetch complete. Total cards: {len(all_cards)}{NC}")
    return all_cards


# ================================
# Main
# ================================

def main():
    load_config()


    parser = argparse.ArgumentParser(description="Hikvision Device Management Tool (Python)")
    subparsers = parser.add_subparsers(dest="command")

    # Subcommands
    subparsers.add_parser("install", help="Install hikcheck to system")
    subparsers.add_parser("uninstall", help="Remove hikcheck from system")
    subparsers.add_parser("config", help="Edit configuration")

    # Count
    p_count = subparsers.add_parser("count", help="Get device counts")
    p_count.add_argument("ips", nargs="+", help="IP endings")

    # Data
    p_data = subparsers.add_parser("data", help="Get device data")
    p_data.add_argument("ips", nargs="+", help="IP endings (e.g. 165 166)")

    # Info
    p_info = subparsers.add_parser("info", help="Get device info only")
    p_info.add_argument("ips", nargs="+", help="IP endings")

    # Time
    p_time = subparsers.add_parser("time", help="Get device time settings")
    p_time.add_argument("ips", nargs="+", help="IP endings")

    # Test
    p_test = subparsers.add_parser("test", help="Test connection")
    p_test.add_argument("ip", help="IP ending")

    # Wipe
    p_wipe = subparsers.add_parser("wipe", help="Wipe device data")
    p_wipe.add_argument("ip", help="IP ending")
    p_wipe.add_argument("type", nargs="?", default="FR", help="Device type (default: FR)")

    # Fetch
    p_fetch = subparsers.add_parser("fetch", help="Fetch access events")
    p_fetch.add_argument("ip", help="IP ending")
    p_fetch.add_argument("start", help="Start time (YYYY-MM-DDThh:mm:ss)")
    p_fetch.add_argument("end", help="End time (YYYY-MM-DDThh:mm:ss)")
    p_fetch.add_argument("tz", help="Timezone offset (e.g. +05:30). For negative, use ' -- -05:00'")

    # Overrides
    parser.add_argument("-u", "--username", help="Override username")
    parser.add_argument("-p", "--password", help="Override password")
    parser.add_argument("-b", "--base-ip", help="Override base IP")
    parser.add_argument("-t", "--timeout", type=int, help="Override timeout")

    # Fetch User
    p_user_data = subparsers.add_parser("user_data", help="Get user details from reader")
    p_user_data.add_argument("user_state_id", help="Latest user state Id")
    p_user_data.add_argument("ips", nargs="+", help="IP endings")
    p_user_data.add_argument("--json", dest="mode", action="store_true", help="Output raw JSON instead of text logs")

    # Users Batch Fetch
    p_users = subparsers.add_parser("users", help="Fetch all users and save to CSV")
    p_users.add_argument("ips", nargs="+", help="IP endings")

    # Cards Batch Fetch
    p_cards = subparsers.add_parser("cards", help="Fetch all cards and save to CSV")
    p_cards.add_argument("ips", nargs="+", help="IP endings")

    args = parser.parse_args()

    # Apply Overrides
    if args.username: CONFIG['username'] = args.username
    if args.password: CONFIG['password'] = args.password
    if args.base_ip: CONFIG['base_ip'] = args.base_ip
    if args.timeout: CONFIG['timeout'] = args.timeout

    if args.command == "install":
        install_script()
    elif args.command == "uninstall":
        uninstall_script()
    elif args.command == "config":
        editor = os.environ.get('EDITOR', 'nano')
        subprocess.call([editor, CONFIG_FILE])
    elif args.command == "data":
        for ip_end in args.ips:
            full_ip = f"{CONFIG['base_ip']}.{ip_end}"
            print(f"=========================================\n Device Report for: {full_ip}\n=========================================")
            get_device_info(full_ip)
            get_device_time(full_ip)
            get_device_counts(full_ip)
    elif args.command == "info":
        for ip_end in args.ips:
            full_ip = f"{CONFIG['base_ip']}.{ip_end}"
            print(f"=========================================\n Device Info for: {full_ip}\n=========================================")
            get_device_info(full_ip)
    elif args.command == "time":
        for ip_end in args.ips:
            full_ip = f"{CONFIG['base_ip']}.{ip_end}"
            print(f"=========================================\n Time Settings for: {full_ip}\n=========================================")
            get_device_time(full_ip)
    elif args.command == "test":
        test_connection(f"{CONFIG['base_ip']}.{args.ip}")
    elif args.command == "wipe":
        wipe_device(args.ip, args.type)
    elif args.command == "fetch":
        fetch_events(args.ip, args.start, args.end, args.tz)
    elif args.command == "count":
        for ip_end in args.ips:
            full_ip = f"{CONFIG['base_ip']}.{ip_end}"
            print(f"=========================================\n Device Counts for: {full_ip}\n=========================================")
            get_device_counts(full_ip)
    elif args.command == "user_data":
        for ip_end in args.ips:
            full_ip = f"{CONFIG['base_ip']}.{ip_end}"
            print(f"=========================================\n Checking the Readers for user: {full_ip} \n================================")
            res = fetch_user(full_ip, args.user_state_id, args.mode)
            if args.mode and res:
                print(json.dumps(res, indent=4))
    elif args.command == "users":
        summary_logs = []
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        batch_dir = f"hikcheck_users_batch_{timestamp}"

        print(f"\n{BLUE}Output Directory: {batch_dir}{NC}\n")

        for ip_end in args.ips:
            full_ip = f"{CONFIG['base_ip']}.{ip_end}"
            print(f"=========================================\n Fetching Users from: {full_ip} \n================================")
            users_list = fetch_all_users(full_ip)
            saved_path = save_users_csv(users_list, full_ip, batch_dir)

            # Add to summary
            summary_logs.append({
                "device": full_ip,
                "count": len(users_list),
                "saved_at": saved_path if saved_path else "FAILED"
            })

        print("\n" + "="*40)
        print(" EXECUTION SUMMARY")
        print("="*40)
        for log in summary_logs:
            print(f"Device: {log['device']}")
            print(f"  - Users Fetched: {log['count']}")
            print(f"  - Saved To:      {log['saved_at']}")
            print("-" * 20)
        print("="*40 + "\n")

    elif args.command == "cards":
        summary_logs = []
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        batch_dir = f"hikcheck_cards_batch_{timestamp}"

        print(f"\n{BLUE}Output Directory: {batch_dir}{NC}\n")

        for ip_end in args.ips:
            full_ip = f"{CONFIG['base_ip']}.{ip_end}"
            print(f"=========================================\n Fetching Cards from: {full_ip} \n=========================================")
            cards_list = fetch_all_cards(full_ip)
            saved_path = save_cards_csv(cards_list, full_ip, batch_dir)

            summary_logs.append({
                "device": full_ip,
                "count": len(cards_list),
                "saved_at": saved_path if saved_path else "FAILED"
            })

        print("\n" + "="*40)
        print(" EXECUTION SUMMARY")
        print("="*40)
        for log in summary_logs:
            print(f"Device: {log['device']}")
            print(f"  - Cards Fetched: {log['count']}")
            print(f"  - Saved To:      {log['saved_at']}")
            print("-" * 20)
        print("="*40 + "\n")

    else:
        parser.print_help()

if __name__ == "__main__":
    main()
