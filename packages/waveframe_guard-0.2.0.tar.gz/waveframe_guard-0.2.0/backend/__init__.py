"""
Waveframe Guard backend package.
"""