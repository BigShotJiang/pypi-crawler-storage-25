import logging
import sys
import importlib.metadata


logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

def print_hello_world():
    return "Hello world."

# TODO: [START] Uncomment when testing
# if __name__ == "__main__":
#     logger.info(f"############ sys.modules: {sys.modules.keys()}")
#     logger.info(f"########### version: {importlib.metadata.version("my_simple_test")}")
# TODO: [END] Uncomment when testing
