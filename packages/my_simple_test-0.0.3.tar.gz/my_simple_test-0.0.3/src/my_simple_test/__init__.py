import logging
import importlib.metadata

# [START] Uncomment when testing
# logger = logging.getLogger(__name__)
# logging.basicConfig(level=logging.INFO)
#
# logger.info(f"########### version: {importlib.metadata.version("my_simple_test")}")
# [END] Uncomment when testing

__version__ = importlib.metadata.version("my_simple_test")