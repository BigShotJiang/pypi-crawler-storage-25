"""
DRIDiD module.
"""

from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

import numpy as np
import polars as pl

from idid._types import (
    FloatArray,
    OutcomeModel,
    OutcomeRegressionKwargs,
    TreatmentModel,
)
from idid.drdid import PanelParams as ParamsPanelS
from idid.drdid import RcParams as ParamsRcS
from idid.drdid import (
    att_dr_panel,
    att_dr_rc,
    att_ipw_panel,
    att_ipw_rc,
    att_oreg_panel,
    att_oreg_rc,
    att_std_ipw_panel,
    att_std_ipw_rc,
    estimate_dy,
    fast_logit,
    get_dy,
    se_if,
)
from idid.nuisance_estimators import OLS, FastLogit, logit_oreg

__all__ = [
    "latt_dr_panel",
    "latt_dr_rc",
    "DrIDiDRes",
    "ParamsPanel",
    "ParamsRc",
]


def get_xmat(subset: pl.DataFrame, covariates: list[str] | None = None):
    if covariates:
        cols = ["constant"] + covariates
    else:
        cols = ["constant"]
    X = subset.with_columns(constant=pl.lit(1)).select(cols).to_numpy()
    return X


@dataclass
class ParamsPanel:
    subset: pl.DataFrame
    X: FloatArray
    dY: FloatArray
    dD: FloatArray
    E: FloatArray
    Y1: FloatArray | None = None
    Y0: FloatArray | None = None
    D1: FloatArray | None = None
    D0: FloatArray | None = None


@dataclass(slots=True)
class ParamsRc:
    subset: pl.DataFrame
    X: FloatArray
    Y: FloatArray
    T: FloatArray
    D: FloatArray
    E: FloatArray


@dataclass
class DrIDiDRes:
    latt: float
    se: float
    IF: np.ndarray
    num: float
    den: float
    IF_num: np.ndarray
    IF_den: np.ndarray
    extra: dict[str, Any] | None = None


def _latt_panel(
    params: ParamsPanel,
    att_fn: Callable,
    num_kwargs: OutcomeRegressionKwargs | None = None,
    den_kwargs: OutcomeRegressionKwargs | None = None,
) -> DrIDiDRes:
    num_kwargs = num_kwargs or {}
    den_kwargs = den_kwargs or {}
    num = att_fn(
        ParamsPanelS(
            subset=params.subset,
            X=params.X,
            G=params.E,
            dY=params.dY,
            Y1=params.Y1,
            Y0=params.Y0,
        ),
        **num_kwargs,
    )
    den = att_fn(
        ParamsPanelS(
            subset=params.subset,
            X=params.X,
            G=params.E,
            dY=params.dD,
            Y1=params.D1,
            Y0=params.D0,
        ),
        **den_kwargs,
    )

    tau_num = num.att
    tau_den = den.att
    est = tau_num / tau_den

    IF = (num.IF - est * den.IF) / tau_den
    se = se_if(IF)

    return DrIDiDRes(
        latt=est,
        se=se,
        IF=IF,
        num=tau_num,
        den=tau_den,
        IF_num=num.IF,
        IF_den=den.IF,
        extra={
            "num": num.extra,
            "den": den.extra,
        },
    )


def latt_dr_panel_csa(
    params: ParamsPanel,
    num_kwargs: OutcomeRegressionKwargs | None = None,
    den_kwargs: OutcomeRegressionKwargs | None = None,
) -> DrIDiDRes:
    """Double robust estimator by double application of CSA."""
    if den_kwargs is None:
        den_kwargs = {
            "use_levels": True,
            "ns_est": logit_oreg,
        }
    return _latt_panel(
        params,
        att_fn=att_dr_panel,
        num_kwargs=num_kwargs,
        den_kwargs=den_kwargs,
    )


def latt_dr_panel(
    params: ParamsPanel,
    num_kwargs: OutcomeRegressionKwargs | None = None,
    den_kwargs: OutcomeRegressionKwargs | None = None,
) -> DrIDiDRes:
    """DRIDiD estimator for panel data.

    The base structure follows the implementation of `att_dr_panel` of
    [csa-py](https://github.com/jsr-p/csa-py/blob/main/src/csa/drdid.py#L916)
    which build upon the
    [original R implementation](https://psantanna.com/DRDID/index.html).
    """
    from idid.nuisance_estimators import oreg

    num_kwargs = num_kwargs or {}
    if den_kwargs is None:
        den_kwargs = {
            "use_levels": True,
            "ns_est": logit_oreg,
        }

    E = params.E
    X = params.X
    dy_num = get_dy(
        ParamsPanelS(
            subset=params.subset,
            X=X,
            G=E,
            dY=params.dY,
            Y1=params.Y1,
            Y0=params.Y0,
        )
    )
    dy_den = get_dy(
        ParamsPanelS(
            subset=params.subset,
            X=X,
            G=E,
            dY=params.dD,
            Y1=params.D1,
            Y0=params.D0,
        )
    )

    eps_num = num_kwargs.get("eps", 0.01)
    eps_den = den_kwargs.get("eps", eps_num)
    eps = min(eps_num, eps_den)
    ps_tr = fast_logit(endog=E.ravel(), exog=X)
    ps_fit = np.clip(ps_tr.predict(), eps, 1 - eps).reshape(-1, 1)

    w_t = E.reshape(-1, 1)
    w_c = ps_fit * (1 - E) / (1 - ps_fit)

    orp_num = ParamsPanelS(
        subset=params.subset,
        X=X,
        G=E,
        dY=params.dY,
        Y1=params.Y1,
        Y0=params.Y0,
    )
    orp_den = ParamsPanelS(
        subset=params.subset,
        X=X,
        G=E,
        dY=params.dD,
        Y1=params.D1,
        Y0=params.D0,
    )
    dy_hat_num = estimate_dy(
        dy_num,
        (E == 0).ravel(),
        orp_num,
        ns_est=num_kwargs.get("ns_est", oreg),
        use_levels=num_kwargs.get("use_levels", False),
    )
    dy_hat_den = estimate_dy(
        dy_den,
        (E == 0).ravel(),
        orp_den,
        ns_est=den_kwargs.get("ns_est", oreg),
        use_levels=den_kwargs.get("use_levels", False),
    )

    dr_att_t_num = w_t * (dy_num - dy_hat_num)
    dr_att_c_num = w_c * (dy_num - dy_hat_num)
    eta_t_num = dr_att_t_num.mean() / w_t.mean()
    eta_c_num = dr_att_c_num.mean() / w_c.mean()
    tau_num = eta_t_num - eta_c_num
    if_num = (dr_att_t_num - w_t * eta_t_num) / w_t.mean() - (
        dr_att_c_num - w_c * eta_c_num
    ) / w_c.mean()

    dr_att_t_den = w_t * (dy_den - dy_hat_den)
    dr_att_c_den = w_c * (dy_den - dy_hat_den)
    eta_t_den = dr_att_t_den.mean() / w_t.mean()
    eta_c_den = dr_att_c_den.mean() / w_c.mean()
    tau_den = eta_t_den - eta_c_den
    if_den = (dr_att_t_den - w_t * eta_t_den) / w_t.mean() - (
        dr_att_c_den - w_c * eta_c_den
    ) / w_c.mean()

    est = tau_num / tau_den

    IF = (if_num - est * if_den) / tau_den
    se = se_if(IF)

    return DrIDiDRes(
        latt=est,
        se=se,
        IF=IF,
        num=tau_num,
        den=tau_den,
        IF_num=if_num,
        IF_den=if_den,
        extra={
            "num": {},
            "den": {},
        },
    )


def latt_dr_panel_check(
    params: ParamsPanel,
    num_kwargs: OutcomeRegressionKwargs | None = None,
    den_kwargs: OutcomeRegressionKwargs | None = None,
) -> DrIDiDRes:
    from idid.drdid import att_dr_panel_check

    return _latt_panel(
        params,
        att_fn=att_dr_panel_check,
        num_kwargs=num_kwargs,
        den_kwargs=den_kwargs,
    )


def latt_oreg_panel(
    params: ParamsPanel,
    num_kwargs: OutcomeRegressionKwargs | None = None,
    den_kwargs: OutcomeRegressionKwargs | None = None,
) -> DrIDiDRes:
    return _latt_panel(
        params,
        att_fn=att_oreg_panel,
        num_kwargs=num_kwargs,
        den_kwargs=den_kwargs,
    )


def latt_ipw_panel(
    params: ParamsPanel,
    num_kwargs: OutcomeRegressionKwargs | None = None,
    den_kwargs: OutcomeRegressionKwargs | None = None,
) -> DrIDiDRes:
    return _latt_panel(
        params,
        att_fn=att_ipw_panel,
        num_kwargs=num_kwargs,
        den_kwargs=den_kwargs,
    )


def latt_dml_panel(
    params: ParamsPanel,
    *,
    m_m: OutcomeModel | None = None,
    g_m: TreatmentModel | None = None,
    p_m: TreatmentModel | None = None,
    num_kwargs: OutcomeRegressionKwargs | None = None,
    den_kwargs: OutcomeRegressionKwargs | None = None,
    **kwargs: Any,
) -> DrIDiDRes:
    from idid.dmlidid import latt_dml_panel as _latt_dml_panel

    if den_kwargs is not None:
        raise ValueError(
            "latt_dml_panel estimates numerator and denominator jointly; "
            "pass shared kwargs via num_kwargs"
        )

    if params.D0 is None or params.D1 is None:
        raise ValueError("latt_dml_panel requires panel levels D0 and D1")

    model_kwargs = {
        "m_m": OLS() if m_m is None else m_m,
        "g_m": FastLogit() if g_m is None else g_m,
        "p_m": FastLogit() if p_m is None else p_m,
    }

    call_kwargs = {
        **kwargs,
        **model_kwargs,
        **(num_kwargs or {}),
    }

    return _latt_dml_panel(
        X=params.X,
        E=params.E,
        dY=params.dY,
        D0=params.D0,
        D1=params.D1,
        **call_kwargs,
    )


def latt_ee_panel(
    params: ParamsPanel,
    num_kwargs: OutcomeRegressionKwargs | None = None,
    den_kwargs: OutcomeRegressionKwargs | None = None,
) -> DrIDiDRes:
    """Estimating equation estimator."""
    from idid.drdid import OLS

    return latt_dml_panel(
        params,
        m_m=OLS(),
        g_m=FastLogit(),
        p_m=FastLogit(),
        nfolds=1,
    )


def latt_std_ipw_panel(
    params: ParamsPanel,
    num_kwargs: OutcomeRegressionKwargs | None = None,
    den_kwargs: OutcomeRegressionKwargs | None = None,
) -> DrIDiDRes:
    return _latt_panel(
        params,
        att_fn=att_std_ipw_panel,
        num_kwargs=num_kwargs,
        den_kwargs=den_kwargs,
    )


def latt_dr_imp_panel(
    params: ParamsPanel,
    num_kwargs: OutcomeRegressionKwargs | None = None,
    den_kwargs: OutcomeRegressionKwargs | None = None,
) -> DrIDiDRes:
    from idid.drdid import att_dr_panel_imp

    return _latt_panel(
        params,
        att_fn=att_dr_panel_imp,
        num_kwargs=num_kwargs,
        den_kwargs=den_kwargs,
    )


# NOTE: Repeated Cross-Sections


def _latt_rc(
    params: ParamsRc,
    att_fn: Callable,
    num_kwargs: OutcomeRegressionKwargs | None = None,
    den_kwargs: OutcomeRegressionKwargs | None = None,
) -> DrIDiDRes:
    num_kwargs = num_kwargs or {}
    den_kwargs = den_kwargs or {}
    num = att_fn(
        ParamsRcS(
            subset=params.subset,
            X=params.X,
            Y=params.Y,
            T=params.T,
            D=params.E,
        ),
        **num_kwargs,
    )
    den = att_fn(
        ParamsRcS(
            subset=params.subset,
            X=params.X,
            Y=params.D,
            T=params.T,
            D=params.E,
        ),
        **den_kwargs,
    )

    tau_num = num.att
    tau_den = den.att
    est = tau_num / tau_den

    IF = (num.IF - est * den.IF) / tau_den
    se = se_if(IF)

    return DrIDiDRes(
        latt=est,
        se=se,
        IF=IF,
        num=tau_num,
        den=tau_den,
        IF_num=num.IF,
        IF_den=den.IF,
        extra={
            "num": getattr(num, "extra", None),
            "den": getattr(den, "extra", None),
        },
    )


def latt_dr_rc_csa(
    params: ParamsRc,
    num_kwargs: OutcomeRegressionKwargs | None = None,
    den_kwargs: OutcomeRegressionKwargs | None = None,
) -> DrIDiDRes:
    """Double robust estimator by double application of CSA."""
    return _latt_rc(
        params,
        att_fn=att_dr_rc,
        num_kwargs=num_kwargs,
        den_kwargs=den_kwargs,
    )


def latt_dr_rc(
    params: ParamsRc,
    num_kwargs: OutcomeRegressionKwargs | None = None,
    den_kwargs: OutcomeRegressionKwargs | None = None,
) -> DrIDiDRes:
    """DRIDiD estimator for repeated cross-sections.

    The base structure follows the implementation of `att_dr_rc` of
    [csa-py](https://github.com/jsr-p/csa-py/blob/main/src/csa/drdid.py#L315)
    which build upon the
    [original R implementation](https://psantanna.com/DRDID/index.html).
    """
    from idid.nuisance_estimators import oreg

    num_kwargs = num_kwargs or {}
    den_kwargs = den_kwargs or {}

    Y, X, T, D, E = (
        params.Y,
        params.X,
        params.T,
        params.D,
        params.E,
    )
    eps_num = num_kwargs.get("eps", 1e-6)
    eps_den = den_kwargs.get("eps", eps_num)
    eps = min(eps_num, eps_den)
    ps_tr = fast_logit(endog=E.ravel(), exog=X)
    ps_fit = np.clip(ps_tr.predict(), eps, 1 - eps).reshape(-1, 1)

    ns_num = num_kwargs.get("ns_est", oreg)
    ns_den = den_kwargs.get("ns_est", oreg)

    def _fit_rc_core(outcome: np.ndarray, ns_est) -> tuple[float, np.ndarray]:
        b = (E == 1) & (T == 0)
        nse_c_pre = ns_est(X, outcome, b.ravel())
        b = (E == 0) & (T == 1)
        nse_c_post = ns_est(X, outcome, b.ravel())
        b = (E == 1) & (T == 0)
        nse_t_pre = ns_est(X, outcome, b.ravel())
        b = (E == 1) & (T == 1)
        nse_t_post = ns_est(X, outcome, b.ravel())

        mu_0y = T * nse_c_post.pred + (1 - T) * nse_c_pre.pred
        w_t_pre = E * (1 - T)
        w_t_post = E * T
        w_c_pre = ps_fit * (1 - E) * (1 - T) / (1 - ps_fit)
        w_c_post = ps_fit * (1 - E) * T / (1 - ps_fit)

        res_tau1 = outcome - mu_0y
        eta_t_pre = w_t_pre * res_tau1 / w_t_pre.mean()
        eta_t_post = w_t_post * res_tau1 / w_t_post.mean()
        eta_c_pre = w_c_pre * res_tau1 / w_c_pre.mean()
        eta_c_post = w_c_post * res_tau1 / w_c_post.mean()

        res_tau2_post = nse_t_post.pred - nse_c_post.pred
        eta_d_post = (E / E.mean()) * res_tau2_post
        eta_dt1_post = (E * T / (E * T).mean()) * res_tau2_post

        res_tau2_pre = nse_t_pre.pred - nse_c_pre.pred
        eta_d_pre = (E / E.mean()) * res_tau2_pre
        eta_dt0_pre = (E * (1 - T) / (E * (1 - T)).mean()) * res_tau2_pre

        att_t_pre = eta_t_pre.mean()
        att_t_post = eta_t_post.mean()
        att_c_pre = eta_c_pre.mean()
        att_c_post = eta_c_post.mean()
        att_d_pre = eta_d_pre.mean()
        att_d_post = eta_d_post.mean()
        att_dt0_pre = eta_dt0_pre.mean()
        att_dt1_post = eta_dt1_post.mean()

        tau1 = (att_t_post - att_t_pre) - (att_c_post - att_c_pre)
        tau2_1 = att_d_post - att_dt1_post
        tau2_2 = att_d_pre - att_dt0_pre
        tau = tau1 + (tau2_1 - tau2_2)

        if_t_pre = eta_t_pre - w_t_pre * att_t_pre / w_t_pre.mean()
        if_t_post = eta_t_post - w_t_post * att_t_post / w_t_post.mean()
        if_c_pre = eta_c_pre - w_c_pre * att_c_pre / w_c_pre.mean()
        if_c_post = eta_c_post - w_c_post * att_c_post / w_c_post.mean()
        if_e1 = eta_d_post - E * att_d_post / E.mean()
        if_e2 = eta_dt1_post - E * T * att_dt1_post / (E * T).mean()
        if_e3 = eta_d_pre - E * att_d_pre / E.mean()
        if_e4 = eta_dt0_pre - E * (1 - T) * att_dt0_pre / (E * (1 - T)).mean()
        if_e = (if_e1 - if_e2) - (if_e3 - if_e4)
        if_tau = (if_t_post - if_t_pre) - (if_c_post - if_c_pre) + if_e
        return tau, if_tau

    tau_num, if_num = _fit_rc_core(Y, ns_num)
    tau_den, if_den = _fit_rc_core(D, ns_den)
    est = tau_num / tau_den
    IF = (if_num - est * if_den) / tau_den
    return DrIDiDRes(
        latt=est,
        se=se_if(IF),
        IF=IF,
        num=tau_num,
        den=tau_den,
        IF_num=if_num,
        IF_den=if_den,
        extra={"num": {}, "den": {}},
    )


def latt_oreg_rc(
    params: ParamsRc,
    num_kwargs: OutcomeRegressionKwargs | None = None,
    den_kwargs: OutcomeRegressionKwargs | None = None,
) -> DrIDiDRes:
    return _latt_rc(
        params,
        att_fn=att_oreg_rc,
        num_kwargs=num_kwargs,
        den_kwargs=den_kwargs,
    )


def latt_ipw_rc(
    params: ParamsRc,
    num_kwargs: OutcomeRegressionKwargs | None = None,
    den_kwargs: OutcomeRegressionKwargs | None = None,
) -> DrIDiDRes:
    return _latt_rc(
        params,
        att_fn=att_ipw_rc,
        num_kwargs=num_kwargs,
        den_kwargs=den_kwargs,
    )


def latt_std_ipw_rc(
    params: ParamsRc,
    num_kwargs: OutcomeRegressionKwargs | None = None,
    den_kwargs: OutcomeRegressionKwargs | None = None,
) -> DrIDiDRes:
    return _latt_rc(
        params,
        att_fn=att_std_ipw_rc,
        num_kwargs=num_kwargs,
        den_kwargs=den_kwargs,
    )


def latt_dr_imp_rc(
    params: ParamsRc,
    num_kwargs: OutcomeRegressionKwargs | None = None,
    den_kwargs: OutcomeRegressionKwargs | None = None,
) -> DrIDiDRes:
    from idid.drdid import att_dr_rc_imp

    return _latt_rc(
        params,
        att_fn=att_dr_rc_imp,
        num_kwargs=num_kwargs,
        den_kwargs=den_kwargs,
    )


def latt_dml_rc(
    params: ParamsRc,
    *,
    m_m: OutcomeModel | None = None,
    g_m: TreatmentModel | None = None,
    p_m: TreatmentModel | None = None,
    num_kwargs: OutcomeRegressionKwargs | None = None,
    den_kwargs: OutcomeRegressionKwargs | None = None,
    **kwargs: Any,
) -> DrIDiDRes:
    from idid.dmlidid import latt_dml_rc as _latt_dml_rc

    if den_kwargs is not None:
        raise ValueError(
            "latt_dml_rc estimates numerator and denominator jointly; "
            "pass shared kwargs via num_kwargs"
        )

    model_kwargs = {
        "m_m": OLS() if m_m is None else m_m,
        "g_m": FastLogit() if g_m is None else g_m,
        "p_m": FastLogit() if p_m is None else p_m,
    }

    call_kwargs = {
        **kwargs,
        **model_kwargs,
        **(num_kwargs or {}),
    }

    return _latt_dml_rc(
        X=params.X,
        Y=params.Y,
        T=params.T,
        D=params.D,
        E=params.E,
        **call_kwargs,
    )


def latt_ee_rc(
    params: ParamsRc,
    num_kwargs: OutcomeRegressionKwargs | None = None,
    den_kwargs: OutcomeRegressionKwargs | None = None,
) -> DrIDiDRes:
    """Estimating equation estimator."""
    from idid.drdid import OLS

    return latt_dml_rc(
        params,
        m_m=OLS(),
        g_m=FastLogit(),
        p_m=FastLogit(),
        nfolds=1,
    )
