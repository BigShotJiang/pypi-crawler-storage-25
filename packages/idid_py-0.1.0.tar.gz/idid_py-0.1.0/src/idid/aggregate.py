"""
Instrumented DiD aggregated effects implementation.
"""

from __future__ import annotations

import warnings
from collections.abc import Callable
from copy import deepcopy
from dataclasses import dataclass, field
from typing import Any

import numpy as np
import polars as pl

from idid import multiplier
from idid._types import AggMethod
from idid.estimators import (
    IDidParams,
    IDidResult,
    get_units,
    latt_et_all,
    se_if_np,
    se_ifs,
    units_map,
)
from idid.summary import summarize_agg_te
from idid.utils import ReprMixin, pl_ci, pull, sorted_unqs

__all__ = [
    "AggLattResult",
    "agg_calendar_cumu",
    "agg_calendar_cumu_nw",
    "agg_calendar_nw",
    "agg_cohort_nw",
    "agg_dynamic_nw",
    "agg_sel_custom",
    "agg_simple",
    "agg_sel",
    "agg_latt",
]


@dataclass
class Cols:
    cohort: str
    time: str
    outcome: str
    treatment: str
    unit: str

    @property
    def e(self) -> str:
        return self.cohort

    @property
    def t(self) -> str:
        return self.time

    @property
    def d(self) -> str:
        return self.treatment

    @property
    def y(self) -> str:
        return self.outcome

    @property
    def i(self) -> str:
        return self.unit


class IFGroupEvent:
    def __init__(
        self,
        if_ge: np.ndarray,
        probs: np.ndarray,
        ev: np.ndarray,
    ):
        self.if_ge = if_ge
        self.probs = probs
        self.ev = ev
        self.e_to_id = dict(zip(self.ev, range(len(self.ev))))

    def rep_if(self, e: int, rep: int) -> np.ndarray:
        return np.repeat(self.if_ge[:, [self.e_to_id[e]]], repeats=rep, axis=1)

    def rep_prob(self, e: int, rep: int) -> np.ndarray:
        return np.repeat(self.probs[self.e_to_id[e]], repeats=rep).reshape(
            1, -1
        )

    def if_pe_cohort(self, e: int) -> np.ndarray:
        return self.if_ge[:, [self.e_to_id[e]]]

    def prob_cohort(self, e: int) -> np.ndarray:
        return self.probs[self.e_to_id[e]].reshape(1, -1)


class Events:
    """
    Namespace to compute indicators to select events:

    - Dynamic: (E + l <= T)
    - Calendar: (E <= t)
    - Group: (E <= T)
    - Dynamic Balanced: (E + l' <= T)

    for computing IF(P(E = e | event)).
    """

    @staticmethod
    def dynamic(T: int, l: int) -> Callable[[np.ndarray], np.ndarray]:
        return lambda ev: (ev <= T - l) & (ev > 0)

    @staticmethod
    def calendar(t: int) -> Callable[[np.ndarray], np.ndarray]:
        return lambda ev: (ev <= t) & (ev > 0)

    @staticmethod
    def group() -> Callable[[np.ndarray], np.ndarray]:
        return lambda ev: ev > 0


class IFsAgg:
    def __init__(self, df: pl.DataFrame, cols: Cols):
        self.df = df
        self.cols = cols
        self.gpc = group_probs(
            self.df,
            self.cols.e,
            self.cols.i,
        ).sort(self.cols.e)
        self.units = get_units(
            self.df,
            self.cols.i,
            self.cols.e,
        )
        self.if_pe = self.if_group_probs()
        self.pe = pull(self.gpc, "pg")
        self.ev = pull(self.gpc, cols.e)
        self.e_to_id = dict(zip(self.ev, range(len(self.ev))))

    def if_group_probs(self):
        """returns IF(P(E = e))"""
        ev = pull(self.gpc, self.cols.e)
        pe = pull(self.gpc, "pg")
        Ei = pull(self.units, self.cols.e, keep_dims=True)

        # IF(P(E = e))
        Ie = 1 * (Ei == ev)
        if_pe = Ie - pe.reshape(1, -1)
        return if_pe

    def if_group_event(
        self, event_fn: Callable[[np.ndarray], np.ndarray]
    ) -> IFGroupEvent:
        """Computes IF(P(E = e | event)).
        Events:
            - Dynamic: (E + l <= T)
            - Calendar: (E <= t)
            - Group: (E <= T)
        """
        event = event_fn(self.ev)
        if not event.any():
            return IFGroupEvent(
                np.empty((self.units.height, 0)),
                np.empty(0),
                self.ev[event],
            )
        if_den = self.if_pe[:, event].sum(axis=1, keepdims=True)  # IF(P(event))
        pew = self.pe[event].reshape(1, -1)
        if_num = self.if_pe[:, event]
        psi_den = pew.sum()
        if_ge = if_quotient_rule(
            psi_num=pew, psi_den=psi_den, if_num=if_num, if_den=if_den
        )
        return IFGroupEvent(if_ge, (pew / pew.sum()).ravel(), self.ev[event])

    def rep_if_pe(self, e: int, rep: int) -> np.ndarray:
        return np.repeat(self.if_pe[:, [self.e_to_id[e]]], repeats=rep, axis=1)

    def rep_pe(self, e: int, rep: int) -> np.ndarray:
        return np.repeat(self.pe[self.e_to_id[e]], repeats=rep).reshape(1, -1)

    def if_pe_cohort(self, e: int) -> np.ndarray:
        return self.if_pe[:, [self.e_to_id[e]]]


def gt_count(
    df: pl.DataFrame,
    g_col: str = "g",
    t_col: str = "t",
):
    return df.group_by(g_col, t_col).agg(pl.len().alias("gt_count"))


def cprobs_m(
    data: pl.DataFrame,
    pg: pl.DataFrame,
    t_col: str = "t",
    g_col: str = "g",
):
    return (
        gt_count(
            data,
            g_col=g_col,
            t_col=t_col,
        )
        .join(pg, how="left", on=g_col)
        .with_columns(
            K=pl.col(t_col) - pl.col(g_col),
            treat=pl.col(g_col).gt(0),
        )
        .with_columns(
            pge=(pl.col("pg") / pl.col("pg").sum().over("K")) * pl.col("treat")
        )
    )


def if_weights_fraction(
    weights: np.ndarray,
    w_denom: float,
    IF_num: np.ndarray,
):
    """Influnce function of a weighted fraction estimand."""
    IF_denom = IF_num.sum(axis=1, keepdims=True)
    return (1 / w_denom) * (IF_num - weights * IF_denom)


def if_quotient_rule(
    psi_num: np.ndarray,
    psi_den: np.ndarray,
    if_num: np.ndarray,
    if_den: np.ndarray,
):
    """Ratio rule for influence functions"""
    return (1 / psi_den) * (if_num - (psi_num / psi_den) * if_den)


def if_product_rule(
    psi_1: np.ndarray,
    psi_2: np.ndarray,
    if_1: np.ndarray,
    if_2: np.ndarray,
):
    """Product rule for influence functions"""
    return if_1 * psi_2 + psi_1 * if_2


def if_product_rule_inp(
    psi_1: np.ndarray,
    psi_2: np.ndarray,
    if_1: np.ndarray,
    if_2: np.ndarray,
):
    """Product rule for influence functions with inner product.

    E.g. (n, k) @ (k, 1) + (n, k) @ (k, 1) -> (n, 1)
    """
    return if_1 @ psi_2 + if_2 @ psi_1


def if_weighted_att(
    est: np.ndarray,
    w: np.ndarray,
    IF_att: np.ndarray,
    IF_w: np.ndarray,
):
    """Computes the weighted influence function.

    Required: estimate, weight, and influnce function of both.
    """
    # Final IF is sum of IF(w) * ATT + w * IF(ATT)
    return IF_w * est + w * IF_att


@dataclass(repr=False)
class WeightedATT(ReprMixin):
    latt: float
    se: float
    IF: np.ndarray


@dataclass
class WeightedATTs:
    watt1: WeightedATT
    watt2: WeightedATT
    watt3: WeightedATT
    k: int


@dataclass
class IDidAggParams:
    """
    atts:
        df with estimates LATT(e, t), AET(e, t)
    IFs_latt:
        EIF: IF(LATT(e, t))
    IFs_aet:
        EIF: IF(AET(e, t))
    """

    res: IDidResult
    dp: IDidParams
    latts: pl.DataFrame
    IFs_latt: np.ndarray
    IFs_aet: np.ndarray
    extra: dict = field(default_factory=dict, kw_only=True)


def _cols_from_dp(dp: IDidParams) -> Cols:
    return Cols(
        cohort=dp.e_col,
        time=dp.t_col,
        outcome=dp.y_col,
        treatment=dp.d_col,
        unit=dp.i_col,
    )


def _ifs_agg_from_ap(ap: IDidAggParams) -> IFsAgg:
    return IFsAgg(df=ap.res.dp.data_orig, cols=_cols_from_dp(ap.dp))


def _overall_from_if(
    estimates: pl.DataFrame, IF: np.ndarray
) -> tuple[float, float, np.ndarray]:
    overall_if = IF.mean(axis=1, keepdims=True)
    overall_latt = float(estimates["latt"].mean())
    overall_se = float(se_if_np(overall_if))
    return overall_latt, overall_se, overall_if


@dataclass
class AggEventResult:
    latt: float
    se: float
    IF: np.ndarray
    w: np.ndarray


def _agg_event(
    ap: IDidAggParams,
    ifs_agg: IFsAgg,
    event_fn: Callable[[np.ndarray], np.ndarray],
    m_est: np.ndarray,
) -> AggEventResult:
    """Aggregate over cells selected by an event and estimate mask."""
    Ev = pull(ap.latts, ap.dp.e_col)
    ifa = ifs_agg.if_group_event(event_fn)

    if not np.array_equal(ifa.ev, Ev[m_est]):
        raise ValueError("Event cohorts do not align with selected estimates")

    latts = pull(ap.latts, "latt")[m_est]
    aets = pull(ap.latts, "denom")[m_est]
    if_aet = ap.IFs_aet[:, m_est]  # 1{Cond} AET(e, t)
    if_latts = ap.IFs_latt[:, m_est]
    if_gp = ifa.if_ge

    aetcp = aets * ifa.probs
    w_den = aetcp.sum()  # Σ_{e} 1{Cond(e)} P(E = e | Cond(E)) AET(e, t)
    w = aetcp / w_den
    # IF(P(E = e | Cond(E)) AET(e, t))
    if_aetcp = if_product_rule(aets, ifa.probs, if_aet, if_gp)
    # IF(P(E = e | Cond(E)) AET(e, t) / Σ_{e} 1{Cond(e)} P(E = e | Cond(E)) AET(e, t))
    if_weights = if_weights_fraction(
        weights=w,
        w_denom=w_den,
        IF_num=if_aetcp,
    )
    if_w_estimand = if_product_rule(w, latts, if_weights, if_latts)
    IF = if_w_estimand.sum(axis=1, keepdims=True)
    est = float((w * latts).sum())
    se = float(se_if_np(IF))
    return AggEventResult(est, se, IF, w)


def _agg_event_basic(
    ap: IDidAggParams,
    ifs_agg: IFsAgg,
    event_fn: Callable[[np.ndarray], np.ndarray],
    m_est: np.ndarray,
) -> AggEventResult:
    """Aggregate over cells selected by an event and estimate mask."""
    Ev = pull(ap.latts, ap.dp.e_col)
    ifa = ifs_agg.if_group_event(event_fn)

    if not np.array_equal(ifa.ev, Ev[m_est]):
        raise ValueError("Event cohorts do not align with selected estimates")

    latts = pull(ap.latts, "latt")[m_est]
    if_latts = ap.IFs_latt[:, m_est]
    if_gp = ifa.if_ge
    w = ifa.probs
    IF = if_product_rule_inp(w, latts, if_gp, if_latts)
    est = float((w * latts).sum())
    se = float(se_if_np(IF))
    return AggEventResult(est, se, IF, w)


def _agg_event_bal_basic(
    ap: IDidAggParams,
    ige: IFGroupEvent,
    m_est: np.ndarray,
) -> AggEventResult:
    """Aggregate over cells selected by an event and estimate mask."""
    Ev = pull(ap.latts, ap.dp.e_col)
    if not np.array_equal(ige.ev, Ev[m_est]):
        raise ValueError("Event cohorts do not align with selected estimates")
    latts = pull(ap.latts, "latt")[m_est]
    if_latts = ap.IFs_latt[:, m_est]
    if_gp = ige.if_ge
    w = ige.probs
    IF = if_product_rule_inp(w, latts, if_gp, if_latts)
    est = float((w * latts).sum())
    se = float(se_if_np(IF))
    return AggEventResult(est, se, IF, w)


def _agg_event_bal(
    ap: IDidAggParams,
    ige: IFGroupEvent,
    m_est: np.ndarray,
) -> AggEventResult:
    """Balanced event aggregation with IV/AET weights."""
    Ev = pull(ap.latts, ap.dp.e_col)
    if not np.array_equal(ige.ev, Ev[m_est]):
        raise ValueError("Event cohorts do not align with selected estimates")

    latts = pull(ap.latts, "latt")[m_est]
    aets = pull(ap.latts, "denom")[m_est]
    if_aet = ap.IFs_aet[:, m_est]
    if_latts = ap.IFs_latt[:, m_est]
    if_gp = ige.if_ge

    aetcp = aets * ige.probs
    w_den = aetcp.sum()
    w = aetcp / w_den
    if_aetcp = if_product_rule(aets, ige.probs, if_aet, if_gp)
    if_weights = if_weights_fraction(
        weights=w,
        w_denom=w_den,
        IF_num=if_aetcp,
    )
    if_w_estimand = if_product_rule(w, latts, if_weights, if_latts)
    IF = if_w_estimand.sum(axis=1, keepdims=True)
    est = float((w * latts).sum())
    se = float(se_if_np(IF))
    return AggEventResult(est, se, IF, w)


def _empty_dynamic_bal_result(
    ap: IDidAggParams,
    ifge: IFGroupEvent,
    lp: int,
    T: int,
    msg: str,
) -> AggLattResult:
    return AggLattResult(
        estimates=pl.DataFrame(
            schema={
                "k": pl.Int64,
                "latt": pl.Float64,
                "se": pl.Float64,
                "lower": pl.Float64,
                "upper": pl.Float64,
            }
        ),
        overall_latt=float("nan"),
        overall_se=float("nan"),
        IF=np.empty((ap.dp.n, 0)),
        IF_overall=np.full((ap.dp.n, 1), np.nan),
        IFs_weight={},
        params=ap,
        method="dynamic_bal",
        extra={
            "balanced_cohorts": ifge.ev,
            "lprime": lp,
            "T": T,
            "warning": msg,
        },
    )


def agg_sel(ap: IDidAggParams) -> AggLattResult:
    """
    Computes the θ_{sel}^{O} by weighting θ_{sel(e)}^{O}.

    Notes:
    1. First we compute θ_{sel(e)}^{O} and
        IF(P(E = e | E <= T) x [AET(e, t) / Σ_{t >= e} AET(e, t)])
    2. Then we compute θ_{sel}^{O}
    3. Then we compute IF(θ_{sel}^{O}) by the product rule using the IF
       computed in 1. and the IF(LATT(e, t))s.
    """
    ifs_agg = _ifs_agg_from_ap(ap)
    Ev = pull(ap.latts, ap.dp.e_col)
    tv = pull(ap.latts, ap.dp.t_col)
    ifa = ifs_agg.if_group_event(Events.group())
    aets_all = pull(ap.latts, "denom")
    latts_all = pull(ap.latts, "latt")

    eff_sel: dict[Any, float] = {}
    se_eff_sel: dict[Any, float] = {}
    w_aet: dict[Any, np.ndarray] = {}
    if_w_sel_es: dict[Any, np.ndarray] = {}
    ifs_sel_e: dict[Any, np.ndarray] = {}

    Es = sorted_unqs(Ev)
    for e in Es:
        m = (Ev == e) & (tv >= e)
        aets = aets_all[m]
        latts = latts_all[m]
        w = aets / (w_den := aets.sum())
        eff_sel[e] = float((w * latts).sum())  # θ_{sel(e)}^{O}
        w_aet[e] = w
        # IF([AET(e, t) / Σ_{t >= e} AET(e, t)]})
        if_aet_ratio = if_quotient_rule(
            aets,
            w_den,
            ap.IFs_aet[:, m],
            ap.IFs_aet[:, m].sum(axis=1, keepdims=True),
        )
        # IF(P(E = e | E <= T) x [AET(e, t) / Σ_{t >= e} AET(e, t)])
        if_w_sel_es[e] = if_product_rule(
            ifa.prob_cohort(e), w_aet[e], ifa.if_pe_cohort(e), if_aet_ratio
        )

        # Σ_{t} IF([AET(e, t) / Σ_{t >= e} AET(e, t)] LATT(e, t)) for fixed e
        ifs_sel_e[e] = if_product_rule_inp(
            w_aet[e], latts, if_aet_ratio, ap.IFs_latt[:, m]
        )
        # se(\hat{θ}_{sel}^{IV}(e))
        se_eff_sel[e] = se_if_np(ifs_sel_e[e])

    # for each cohort e, repeat P(E = e | E <= T) for t >= e
    w_all = np.column_stack(
        [ifa.rep_prob(e, w_aet[e].shape[0]) * w_aet[e] for e in Es]
    )
    m_all = (Ev > 0) & (tv >= Ev)
    latts_all = pull(ap.latts, "latt")[m_all]
    if_latts = ap.IFs_latt[:, m_all]
    if_w_sel = np.column_stack([if_w_sel_es[e] for e in Es])
    IF_overall = if_product_rule(w_all, latts_all, if_w_sel, if_latts).sum(
        axis=1,
        keepdims=True,
    )
    # θ_{sel}^{O}
    est = float(sum(ifa.prob_cohort(e).item() * eff_sel[e] for e in Es))
    se = float(se_if_np(IF_overall))
    # estimates show θ_{sel(e)}^{O} for each e and corresponding standard error
    estimates = pl.DataFrame(
        [
            {
                "cohort": e,
                "latt": eff_sel[e],
                "se": se_eff_sel[e],
            }
            for e in Es
        ]
    ).with_columns(pl_ci("latt"))
    return AggLattResult(
        estimates=estimates,
        overall_latt=est,
        overall_se=se,
        IF=np.column_stack([ifs_sel_e[e] for e in Es]),
        IF_overall=IF_overall,
        params=ap,
        method="cohort",
        IFs_weight={"single": if_w_sel},
    )


def agg_sel_custom(ap: IDidAggParams) -> AggLattResult:
    """Selector aggregation after remapping cohorts to custom groups."""
    custom_map = ap.extra.get("custom_map")
    if custom_map is None:
        raise ValueError("agg_sel_custom requires `custom_map` in ap.extra")

    remap_items = sorted(custom_map.items())
    target_labels = list(dict.fromkeys(target for _, target in remap_items))
    if 0 in target_labels:
        raise ValueError("custom_map cannot map treated cohorts to 0")

    if any(isinstance(label, str) for label in target_labels):
        label_to_code = {
            label: idx for idx, label in enumerate(target_labels, start=1)
        }
        code_to_label = {code: label for label, code in label_to_code.items()}
        remap_codes = {
            src: label_to_code[target] for src, target in remap_items
        }
    else:
        remap_codes = dict(remap_items)
        code_to_label = {int(target): target for target in target_labels}

    ap_custom = deepcopy(ap)
    e_col = ap.dp.e_col
    ap_custom.latts = ap_custom.latts.with_columns(
        pl.col(e_col).replace(remap_codes)
    )
    ap_custom.dp.data_orig = ap_custom.dp.data_orig.with_columns(
        pl.col(e_col).replace(remap_codes)
    )

    out = agg_sel(ap_custom)
    out.method = "cohort_custom"
    if any(isinstance(label, str) for label in code_to_label.values()):
        out.estimates = out.estimates.with_columns(
            pl.col("cohort")
            .replace_strict(
                code_to_label,
                default=pl.col("cohort").cast(pl.Utf8),
                return_dtype=pl.Utf8,
            )
            .alias("cohort")
        )
        out.extra["cohort_labels"] = code_to_label
    out.extra["custom_map"] = custom_map
    return out


def agg_simple(ap: IDidAggParams) -> AggLattResult:
    r"""Simple aggregation.

    The weighted estimand:
        \theta^{o,IV}_{W} (equal to \theta^{o,W})
    """
    ifs_agg = _ifs_agg_from_ap(ap)
    ifa = ifs_agg.if_group_event(Events.group())
    Ev = pull(ap.latts, ap.dp.e_col)
    tv = pull(ap.latts, ap.dp.t_col)
    post = tv >= Ev
    ev_to_col = dict(zip(ifa.ev.tolist(), range(len(ifa.ev))))
    cols = np.array([ev_to_col[e] for e in Ev[post]])
    p_cell = ifa.probs[cols]
    weights = p_cell / p_cell.sum()
    if_w = ifa.if_ge[:, cols]
    IF_w = if_quotient_rule(
        p_cell,
        p_cell.sum(),
        if_w,
        if_w.sum(axis=1, keepdims=True),
    )
    latts = pull(ap.latts, "latt")[post]
    if_latts = ap.IFs_latt[:, post]
    IF = if_product_rule(weights, latts, IF_w, if_latts).sum(
        axis=1,
        keepdims=True,
    )
    est = float(weights @ latts)
    se = float(se_if_np(IF))
    estimates = pl.DataFrame(
        {"effect": ["overall"], "latt": [est], "se": [se]}
    ).with_columns(pl_ci("latt"))
    return AggLattResult(
        estimates=estimates,
        overall_latt=est,
        overall_se=se,
        IF=IF,
        IF_overall=IF,
        IFs_weight={"single": IF_w},
        params=ap,
        method="simple",
    )


def agg_dynamic(ap: IDidAggParams) -> AggLattResult:
    r"""

    \theta^{IV}_{es(l)} estimand.
    """
    ifs_agg = _ifs_agg_from_ap(ap)
    events = Events()
    Ev = pull(ap.latts, ap.dp.e_col)
    tv = pull(ap.latts, ap.dp.t_col)
    lv = tv - Ev
    T = int(tv.max())
    min_l = ap.extra.get("min_l", 0)
    max_l = ap.extra.get("max_l", 10)

    rows = []
    IFs = []
    for l in sorted_unqs(lv):
        if l < min_l or l > max_l:
            continue
        out = _agg_event(ap, ifs_agg, events.dynamic(T, int(l)), lv == l)
        rows.append((int(l), out.latt, out.se))
        IFs.append(out.IF)
    estimates = (
        pl.DataFrame(rows, schema=["l", "latt", "se"], orient="row")
        .with_columns(pl_ci("latt"))
        .sort("l")
    )
    IF = np.column_stack(IFs) if IFs else np.empty((ap.dp.n, 0))
    overall_latt, overall_se, IF_overall = _overall_from_if(estimates, IF)
    return AggLattResult(
        estimates=estimates,
        overall_latt=overall_latt,
        overall_se=overall_se,
        IF=IF,
        IF_overall=IF_overall,
        params=ap,
        method="dynamic",
    )


def agg_dynamic_nw(ap: IDidAggParams) -> AggLattResult:
    r"""Dynamic aggregation using CSA-style cohort weights, without AET weights.


    \theta^{es(l)}
    """
    ifs_agg = _ifs_agg_from_ap(ap)
    events = Events()
    tv = pull(ap.latts, ap.dp.t_col)
    Ev = pull(ap.latts, ap.dp.e_col)
    lv = tv - Ev
    T = int(tv.max())
    min_l = ap.extra.get("min_l", 0)
    max_l = ap.extra.get("max_l", 10)

    rows = []
    IFs = []
    IFs_weight = {}
    for l in sorted_unqs(lv):
        if l < min_l or l > max_l:
            continue
        event = events.dynamic(T, int(l))
        ifa = ifs_agg.if_group_event(event)
        out = _agg_event_basic(ap, ifs_agg, event, lv == l)
        rows.append((int(l), out.latt, out.se))
        IFs.append(out.IF)
        IFs_weight[int(l)] = ifa.if_ge
    estimates = (
        pl.DataFrame(rows, schema=["l", "latt", "se"], orient="row")
        .with_columns(pl_ci("latt"))
        .sort("l")
    )
    IF = np.column_stack(IFs) if IFs else np.empty((ap.dp.n, 0))
    overall_latt, overall_se, IF_overall = _overall_from_if(estimates, IF)
    return AggLattResult(
        estimates=estimates,
        overall_latt=overall_latt,
        overall_se=overall_se,
        IF=IF,
        IF_overall=IF_overall,
        IFs_weight=IFs_weight,
        params=ap,
        method="dynamic",
    )


def agg_dynamic_bal_nw(ap: IDidAggParams) -> AggLattResult:
    r"""Dynamic aggregation using CSA-style cohort weights, without AET weights.


    The estimand: \theta^{bal,es(l,l')}.
    """
    ifs_agg = _ifs_agg_from_ap(ap)
    events = Events()
    tv = pull(ap.latts, ap.dp.t_col)
    Ev = pull(ap.latts, ap.dp.e_col)
    lv = tv - Ev
    T = int(tv.max())
    min_l = ap.extra.get("min_l", 5)
    max_l = ap.extra.get("max_l", 10)
    lp = ap.extra.get("lprime", 3)

    rows = []
    IFs = []
    IFs_weight = {}
    event = events.dynamic(T, int(lp))
    ifge = ifs_agg.if_group_event(event)

    if ifge.ev.size == 0:
        msg = (
            "No cohorts satisfy the balanced dynamic requirement "
            f"E + lprime <= T for lprime={lp} and T={T}."
        )
        warnings.warn(msg, RuntimeWarning, stacklevel=2)
        return _empty_dynamic_bal_result(ap, ifge, lp, T, msg)

    lvs = sorted_unqs(lv)
    for l in lvs[lvs <= lp]:  # only consider l = 0, 1, ..., lp
        if l < min_l or l > max_l:
            continue
        m_est = (lv == l) & (Ev <= T - lp)  # 1{t = e + l}1{e + l' <= T}
        out = _agg_event_bal_basic(ap, ifge, m_est)
        rows.append((int(l), out.latt, out.se))
        IFs.append(out.IF)
        IFs_weight[int(l)] = ifge.if_ge
    estimates = (
        pl.DataFrame(rows, schema=["l", "latt", "se"], orient="row")
        .with_columns(pl_ci("latt"))
        .sort("l")
    )
    IF = np.column_stack(IFs) if IFs else np.empty((ap.dp.n, 0))
    overall_latt, overall_se, IF_overall = _overall_from_if(estimates, IF)
    return AggLattResult(
        estimates=estimates,
        overall_latt=overall_latt,
        overall_se=overall_se,
        IF=IF,
        IF_overall=IF_overall,
        IFs_weight=IFs_weight,
        params=ap,
        method="dynamic_bal",
        extra={
            "balanced_cohorts": ifge.ev,
            "lprime": lp,
            "T": T,
        },
    )


def agg_dynamic_bal(ap: IDidAggParams) -> AggLattResult:
    r"""Balanced dynamic aggregation with IV/AET weights.

    The estimand: \theta^{IV,bal}_{es(l,l')}.
    """
    ifs_agg = _ifs_agg_from_ap(ap)
    events = Events()
    tv = pull(ap.latts, ap.dp.t_col)
    Ev = pull(ap.latts, ap.dp.e_col)
    lv = tv - Ev
    T = int(tv.max())
    min_l = ap.extra.get("min_l", 5)
    max_l = ap.extra.get("max_l", 10)
    lp = ap.extra.get("lprime", 3)

    rows = []
    IFs = []
    IFs_weight = {}
    event = events.dynamic(T, int(lp))
    ifge = ifs_agg.if_group_event(event)

    if ifge.ev.size == 0:
        msg = (
            "No cohorts satisfy the balanced dynamic requirement "
            f"E + lprime <= T for lprime={lp} and T={T}."
        )
        warnings.warn(msg, RuntimeWarning, stacklevel=2)
        return _empty_dynamic_bal_result(ap, ifge, lp, T, msg)

    lvs = sorted_unqs(lv)
    for l in lvs[lvs <= lp]:
        if l < min_l or l > max_l:
            continue
        m_est = (lv == l) & (Ev <= T - lp)
        out = _agg_event_bal(ap, ifge, m_est)
        rows.append((int(l), out.latt, out.se))
        IFs.append(out.IF)
        IFs_weight[int(l)] = ifge.if_ge
    estimates = (
        pl.DataFrame(rows, schema=["l", "latt", "se"], orient="row")
        .with_columns(pl_ci("latt"))
        .sort("l")
    )
    IF = np.column_stack(IFs) if IFs else np.empty((ap.dp.n, 0))
    overall_latt, overall_se, IF_overall = _overall_from_if(estimates, IF)
    return AggLattResult(
        estimates=estimates,
        overall_latt=overall_latt,
        overall_se=overall_se,
        IF=IF,
        IF_overall=IF_overall,
        IFs_weight=IFs_weight,
        params=ap,
        method="dynamic_bal",
        extra={
            "balanced_cohorts": ifge.ev,
            "lprime": lp,
            "T": T,
        },
    )


def agg_calendar(ap: IDidAggParams) -> AggLattResult:
    r"""
    \theta^{IV}_{c}(\tilde{t})
    """
    ifs_agg = _ifs_agg_from_ap(ap)
    events = Events()
    tv = pull(ap.latts, ap.dp.t_col)

    rows = []
    IFs = []
    for t in sorted_unqs(tv):
        out = _agg_event(ap, ifs_agg, events.calendar(int(t)), tv == t)
        rows.append((int(t), out.latt, out.se))
        IFs.append(out.IF)
    estimates = (
        pl.DataFrame(rows, schema=[ap.dp.t_col, "latt", "se"], orient="row")
        .with_columns(pl_ci("latt"))
        .sort(ap.dp.t_col)
    )
    IF = np.column_stack(IFs) if IFs else np.empty((ap.dp.n, 0))
    overall_latt, overall_se, IF_overall = _overall_from_if(estimates, IF)
    return AggLattResult(
        estimates=estimates,
        overall_latt=overall_latt,
        overall_se=overall_se,
        IF=IF,
        IF_overall=IF_overall,
        params=ap,
        method="calendar",
    )


def agg_calendar_nw(ap: IDidAggParams) -> AggLattResult:
    """Calendar aggregation using CSA-style cohort weights, without AET weights."""
    ifs_agg = _ifs_agg_from_ap(ap)
    events = Events()
    tv = pull(ap.latts, ap.dp.t_col)

    rows = []
    IFs = []
    IFs_weight = {}
    for t in sorted_unqs(tv):
        event = events.calendar(int(t))
        ifa = ifs_agg.if_group_event(event)
        out = _agg_event_basic(ap, ifs_agg, event, tv == t)
        rows.append((int(t), out.latt, out.se))
        IFs.append(out.IF)
        IFs_weight[int(t)] = ifa.if_ge
    estimates = (
        pl.DataFrame(rows, schema=[ap.dp.t_col, "latt", "se"], orient="row")
        .with_columns(pl_ci("latt"))
        .sort(ap.dp.t_col)
    )
    IF = np.column_stack(IFs) if IFs else np.empty((ap.dp.n, 0))
    overall_latt, overall_se, IF_overall = _overall_from_if(estimates, IF)
    return AggLattResult(
        estimates=estimates,
        overall_latt=overall_latt,
        overall_se=overall_se,
        IF=IF,
        IF_overall=IF_overall,
        IFs_weight=IFs_weight,
        params=ap,
        method="calendar",
    )


def agg_calendar_cumu_nw(ap: IDidAggParams) -> AggLattResult:
    """Cumulative calendar effects from summing CSA-style calendar effects.

    The overall effect is just the cumulatie effect for the latest period.
    """
    cal = agg_calendar_nw(ap)
    t_col = ap.dp.t_col
    latt = np.cumsum(pull(cal.estimates, "latt"))
    IF = np.cumsum(cal.IF, axis=1)
    se = np.apply_along_axis(se_if_np, 0, IF)
    estimates = (
        cal.estimates.select(t_col)
        .with_columns(
            latt=pl.Series(latt),
            se=pl.Series(se),
        )
        .with_columns(pl_ci("latt"))
    )
    overall_latt, overall_se, IF_overall = _overall_from_if(estimates, IF)
    return AggLattResult(
        estimates=estimates,
        overall_latt=overall_latt,
        overall_se=overall_se,
        IF=IF,
        IF_overall=IF_overall,
        IFs_weight=cal.IFs_weight,
        params=ap,
        method="calendar_cumu",
    )


def agg_calendar_cumu(ap: IDidAggParams) -> AggLattResult:
    """Cumulative calendar effects from summing IV-weighted calendar effects."""
    cal = agg_calendar(ap)
    t_col = ap.dp.t_col
    latt = np.cumsum(pull(cal.estimates, "latt"))
    IF = np.cumsum(cal.IF, axis=1)
    se = np.apply_along_axis(se_if_np, 0, IF)
    estimates = (
        cal.estimates.select(t_col)
        .with_columns(
            latt=pl.Series(latt),
            se=pl.Series(se),
        )
        .with_columns(pl_ci("latt"))
    )
    overall_latt, overall_se, IF_overall = _overall_from_if(estimates, IF)
    return AggLattResult(
        estimates=estimates,
        overall_latt=overall_latt,
        overall_se=overall_se,
        IF=IF,
        IF_overall=IF_overall,
        IFs_weight=cal.IFs_weight,
        params=ap,
        method="calendar_cumu",
    )


def agg_cohort_nw(ap: IDidAggParams) -> AggLattResult:
    r"""Cohort aggregation using CSA-style uniform post-period weights.

    \theta^{O,sel} and individual \theta^{O,sel}(\tilde{e}) effects.
    """
    ifs_agg = _ifs_agg_from_ap(ap)
    events = Events()
    ifa = ifs_agg.if_group_event(events.group())
    Ev = pull(ap.latts, ap.dp.e_col)
    tv = pull(ap.latts, ap.dp.t_col)
    latts_all = pull(ap.latts, "latt")

    rows = []
    IFs = []
    for e in sorted_unqs(Ev):
        m = (Ev == e) & (tv >= e)
        latts = latts_all[m]
        w = np.ones_like(latts) / len(latts)
        IF = ap.IFs_latt[:, m] @ w
        est = float(w @ latts)  # \theta^{O,sel}(\tilde{e})
        se = float(se_if_np(IF))
        rows.append((int(e), est, se))
        IFs.append(IF)
    estimates = (
        pl.DataFrame(rows, schema=[ap.dp.e_col, "latt", "se"], orient="row")
        .with_columns(pl_ci("latt"))
        .sort(ap.dp.e_col)
    )
    IF = np.column_stack(IFs) if IFs else np.empty((ap.dp.n, 0))
    atts = pull(estimates, "latt")
    IF_overall = if_product_rule_inp(ifa.probs, atts, ifa.if_ge, IF)
    overall_latt = float(ifa.probs @ atts)
    overall_se = float(se_if_np(IF_overall))
    return AggLattResult(
        estimates=estimates,
        overall_latt=overall_latt,
        overall_se=overall_se,
        IF=IF,
        IF_overall=IF_overall,
        IFs_weight={"overall": ifa.if_ge},
        params=ap,
        method="cohort",
    )


def group_probs(
    df: pl.DataFrame,
    g_col: str = "g",
    i_col: str = "id",
) -> pl.DataFrame:
    return (
        df.group_by(g_col)
        .agg(pl.col(i_col).n_unique().alias("count"))
        .with_columns(pg=pl.col("count") / pl.col("count").sum())
    )


def _cprobs_m(
    data: pl.DataFrame,
    pg: pl.DataFrame,
    t_col: str = "t",
    g_col: str = "g",
) -> pl.DataFrame:
    """Computes conditional probabilities for weighting.

    pge:
        P(E = e | E + l <= T)
    pgt:
        P(E = e | E <= t)
    """
    treat = pl.col("treat")
    vt = treat & pl.col(g_col).le(pl.col(t_col))
    return (
        data.select(g_col, t_col)
        .unique()
        .sort(g_col, t_col)
        .join(pg, how="left", on=g_col)
        .with_columns(
            K=pl.col(t_col) - pl.col(g_col),
            treat=pl.col(g_col).gt(0),
        )
        .with_columns(
            pge=(pl.col("pg") / pl.col("pg").sum().over("K")) * pl.col("treat"),
            pgt=(pl.col("pg").mul(vt) / pl.col("pg").mul(vt).sum().over(t_col)),
        )
        .drop("count", "treat")
    )


def cprobs_csa(res: IDidResult) -> pl.DataFrame:
    """Compute probabilities for weighting ala. CSA.

    NOTE:
        - the group probabilities are computed with the full data
          (i.e. also with the possibly excluded groups)
    """
    dp = res.dp
    data = res.dp.data_orig  # need the original data before filtering
    data_p = data.join(
        res.estimates.select(dp.e_col, dp.t_col),
        how="inner",
        on=[dp.e_col, dp.t_col],
    )
    pg = group_probs(data, g_col=dp.e_col, i_col=dp.i_col)
    cprobs = _cprobs_m(data_p, pg, g_col=dp.e_col, t_col=dp.t_col)
    return cprobs


@dataclass(repr=False)
class AggLattBoot(ReprMixin):
    """Multiplier-bootstrap metadata and confidence bands."""

    __repr_fields__ = ("B", "c", "c_overall")

    B: int
    c: float
    c_overall: float
    estimates: pl.DataFrame
    estimates_overall: pl.DataFrame


@dataclass(repr=False)
class AggLattResult(ReprMixin):
    """Result object returned by {py:func}`idid.agg_latt`.

    It stores aggregate treatment-effect summaries built from the cell-level
    output of {py:class}`idid.estimators.IDidResult`. Depending on `method`, the
    rows of `estimates` correspond to event times, cohorts, calendar periods,
    cumulative effects, or a single overall effect.

    The main user-facing fields are:

    - `estimates`: aggregate estimates with standard errors and confidence
      intervals
    - `overall_latt`: overall scalar summary for the chosen aggregation
    - `overall_se`: standard error of `overall_latt`
    - `IF` and `IF_overall`: influence functions for pointwise and overall
      inference
    - `boot`: multiplier-bootstrap metadata when `boot=True`
    """

    __repr_fields__ = (
        "method",
        "overall_latt",
        "overall_se",
        "boot",
        "extra",
        "estimates",
        "IF",
        "IF_overall",
        "IFs_weight",
    )

    estimates: pl.DataFrame
    overall_latt: float
    overall_se: float
    IF: np.ndarray
    IF_overall: np.ndarray
    method: AggMethod
    IFs_weight: dict[Any, np.ndarray] = field(
        default_factory=dict, kw_only=True
    )
    params: IDidAggParams
    boot: AggLattBoot | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def summary(self):
        summarize_agg_te(self)

    def plot(
        self,
        *,
        ax: Any | None = None,
        fig_path: str | None = None,
        title: str | None = None,
        xlabel: str | None = None,
        ylabel: str = "Estimate",
        color: str = "#0072B2",
    ) -> tuple[Any, Any]:
        """Plot aggregated effects with points and confidence bars."""
        from idid.plotting import plot_agg

        return plot_agg(
            [self],
            ax=ax,
            fig_path=fig_path,
            title=title,
            xlabel=xlabel,
            ylabel=ylabel,
            colors=[color],
        )


def get_filter_nan_atts(atts: pl.DataFrame) -> np.ndarray:
    return (
        atts.select(
            pl.col("latt").is_not_null()
            & pl.col("latt").is_not_nan()
            & pl.col("latt").is_infinite().not_()
        )
        .to_numpy()
        .ravel()
    )


def agg_pars_from_res(
    res: IDidResult,
    min_l: int = 0,
    max_l: int = 10,
    agg_kwargs: dict[str, Any] | None = None,
) -> IDidAggParams:
    IFs = res.IFs
    IFs_c = res.IFs_aet

    latts = res.estimates
    dp = res.dp
    notna = get_filter_nan_atts(latts)
    latts = latts.filter(notna).with_columns(
        K=pl.col(dp.t_col) - pl.col(dp.e_col)
    )

    IFs = IFs[:, notna]
    IFs_aet = IFs_c[:, notna]

    extra = dict(
        min_l=min_l,
        max_l=max_l,
    )
    if agg_kwargs is not None:
        extra.update(agg_kwargs)

    return IDidAggParams(
        res=res,
        dp=dp,
        latts=latts,
        IFs_latt=IFs,
        IFs_aet=IFs_aet,
        extra=extra,
    )


def _csa_to_agg_latt(csa_res, ap: IDidAggParams) -> AggLattResult:
    return AggLattResult(
        estimates=csa_res.estimates,
        overall_latt=csa_res.overall_latt,
        overall_se=csa_res.overall_se,
        IF=csa_res.IF,
        IF_overall=csa_res.IF_overall,
        method=csa_res.method,
        IFs_weight=csa_res.IFs_weight,
        params=ap,
    )


def _agg_latt_csa(ap: IDidAggParams, method: AggMethod) -> AggLattResult:
    """CSA-style aggregation, wrapped in this package's result object."""
    import csa

    dp = ap.dp
    atts = ap.res.estimates
    gp = cprobs_csa(ap.res).join(
        atts.select(dp.e_col, dp.t_col),
        how="inner",
        on=(dp.e_col, dp.t_col),
    )
    csap = csa.CsaParams(
        att=pull(atts, "att"),
        gp=gp,
        df=ap.res.dp.data_orig.select(dp.i_col, dp.e_col).unique(),
        n=ap.res.n,
        if_att=ap.IFs_latt,
        i_col=dp.i_col,
        g_col=dp.e_col,
        t_col=dp.t_col,
        y_col=dp.y_col,
        control=dp.control,
        method=dp.method,
    )

    match method:
        case "simple":
            csa_res = csa.simple_csa(csap)
        case "calendar":
            csa_res = csa.calendar_csa(csap)
        case "group" | "cohort":
            csa_res = csa.group_csa(csap)
        case "dynamic":
            csa_res = csa.dynamic_csa(csap)
        case _:
            raise ValueError(f"Invalid aggregation method {method}")
    return _csa_to_agg_latt(csa_res, ap)


def _with_bootstrap_se(res: AggLattResult, B: int) -> AggLattResult:
    """Update aggregate result standard errors using multiplier bootstrap."""
    bres = multiplier.bstrap(res.IF, B=B)
    boot_est = multiplier.bstrap_ov(bres, pull(res.estimates, "latt"))
    estimates = res.estimates.with_columns(
        se=boot_est["se"],
        lower=boot_est["lower"],
        upper=boot_est["upper"],
    )

    IF_overall = res.IF_overall
    if IF_overall.ndim == 1:
        IF_overall = IF_overall.reshape(-1, 1)
    bres_overall = multiplier.bstrap(IF_overall, B=B)
    boot_overall = multiplier.bstrap_ov(
        bres_overall,
        np.array([res.overall_latt]),
    )

    return AggLattResult(
        estimates=estimates,
        overall_latt=res.overall_latt,
        overall_se=float(boot_overall["se"].item()),
        IF=res.IF,
        IF_overall=res.IF_overall,
        method=res.method,
        IFs_weight=res.IFs_weight,
        params=res.params,
        boot=AggLattBoot(
            B=B,
            c=float(bres.c),
            c_overall=float(bres_overall.c),
            estimates=boot_est,
            estimates_overall=boot_overall,
        ),
        extra=res.extra,
    )


def agg_latt(
    res: IDidResult,
    method: AggMethod = "simple",
    boot: bool = False,
    B: int = 1000,
    verbose: bool = False,
    min_l: int = 0,
    max_l: int = 10,
    complier_weighted: bool = True,
    agg_kwargs: dict[str, Any] | None = None,
    **extra_kwargs: Any,
) -> AggLattResult:
    r"""Aggregates cohort-time LATT estimates.

    This is the main aggregation entry point for the package. It takes the
    cell-level output from {py:func}`idid.estimate` and computes one of the
    aggregations studied in the paper, such as:

    - event-study / dynamic effects
    - balanced dynamic effects
    - cohort effects
    - calendar-time effects
    - cumulative calendar effects
    - overall simple effects

    The `method` argument selects the target estimand. The returned
    {py:class}`AggLattResult <idid.aggregate.AggLattResult>` contains the aggregate estimates, standard errors,
    confidence intervals, and influence functions.

    `complier_weighted=True` uses the IDiD weighting scheme based on the
    relative complier shares in each `(e, t)` cell. Setting
    `complier_weighted=False` uses the corresponding CSA-style weighting
    instead.

    `boot=True` applies multiplier bootstrap inference to the aggregate
    influence functions and replaces the pointwise standard errors and
    confidence intervals in the returned object.

    `agg_kwargs` and `extra_kwargs` are forwarded to aggregation-specific
    helpers. For example, they can be used to pass balancing parameters for
    dynamic effects or a custom cohort map for `"cohort_custom"`.
    """
    extra = dict(agg_kwargs or {})
    extra.update(extra_kwargs)
    ap = agg_pars_from_res(
        res,
        min_l=min_l,
        max_l=max_l,
        agg_kwargs=extra,
    )

    if complier_weighted:
        match method:
            case "dynamic":
                agg_res = agg_dynamic(ap)
            case "dynamic_bal":
                agg_res = agg_dynamic_bal(ap)
            case "cohort_custom":
                agg_res = agg_sel_custom(ap)
            case "group" | "cohort":
                agg_res = agg_sel(ap)
            case "calendar":
                agg_res = agg_calendar(ap)
            case "calendar_cumu":
                agg_res = agg_calendar_cumu(ap)
            case "simple":
                agg_res = agg_simple(ap)
            case _:
                raise ValueError(f"Invalid aggregation method {method}")
    else:
        match method:
            case "dynamic":
                agg_res = agg_dynamic_nw(ap)
            case "dynamic_bal":
                agg_res = agg_dynamic_bal_nw(ap)
            case "cohort_custom":
                agg_res = agg_sel_custom(ap)
            case "group" | "cohort":
                agg_res = agg_cohort_nw(ap)
            case "calendar":
                agg_res = agg_calendar_nw(ap)
            case "calendar_cumu":
                agg_res = agg_calendar_cumu_nw(ap)
            case "simple":
                agg_res = agg_simple(ap)
            case _:
                raise ValueError(f"Invalid aggregation method {method}")

    if boot:
        agg_res = _with_bootstrap_se(agg_res, B=B)

    return agg_res


def group_diff_idid(est_f: IDidResult, est_m: IDidResult) -> IDidResult:
    """Construct cell-level differences between two IDiD estimation results.

    This helper is intended for subgroup comparisons. It takes two
    {py:class}`IDidResult <idid.estimators.IDidResult>` objects estimated on disjoint samples, aligns their
    common `(e, t)` cells, and returns a new {py:class}`IDidResult <idid.estimators.IDidResult>` whose
    cell-level estimates equal the difference between the two groups.

    The returned object keeps valid influence functions for the difference, so
    it can be passed directly to {py:func}`idid.agg_latt` for dynamic, cohort, or
    calendar aggregation of subgroup effects.
    """

    # joint estimation object
    est_j = deepcopy(est_f)

    # compute group-wise probabilities
    n_m = est_m.dp.n
    n_f = est_f.dp.n
    n = n_m + n_f
    p_m = n_m / n
    p_f = n_f / n
    if (
        overlap := set(est_m.dp.data_orig[est_f.dp.i_col])
        & set(est_f.dp.data_orig[est_f.dp.i_col])
    ) != set():
        raise ValueError(
            f"n={len(overlap)} units overlap; overlapping={list(overlap)[:5]}..."
        )
    # remap est_m.units and est_f
    j_units_rm = pl.concat(
        (
            est_m.dp.data_orig.select(est_m.dp.i_col, est_m.dp.e_col)
            .unique()
            .sort(est_m.dp.i_col),
            est_f.dp.data_orig.select(est_f.dp.i_col, est_f.dp.e_col)
            .unique()
            .sort(est_f.dp.i_col),
        )
    )
    j_units_map = units_map(j_units_rm, est_m.dp.i_col)
    j_units = j_units_rm.with_columns(
        pl.col("id").replace_strict(j_units_map).cast(pl.Int32)
    )
    j_data_orig = pl.concat((est_m.dp.data_orig, est_f.dp.data_orig))
    rev_m = {v: k for k, v in est_m.dp.units_map.items()}
    rev_f = {v: k for k, v in est_f.dp.units_map.items()}
    j_data = pl.concat(
        (
            est_m.dp.data.with_columns(pl.col("id").replace_strict(rev_m)),
            est_f.dp.data.with_columns(pl.col("id").replace_strict(rev_f)),
        )
    )
    dp = est_f.dp
    estimates_j = (
        est_f.estimates.select(dp.e_col, dp.t_col, "latt")
        .with_row_index(name="idx_f")
        .join(
            est_m.estimates.select(
                dp.e_col,
                dp.t_col,
                pl.col("latt").alias("latt_m"),
            ).with_row_index(name="idx_m"),
            how="inner",
            on=[dp.e_col, dp.t_col],
        )
        .with_columns(
            # difference
            pl.col("latt").sub(pl.col("latt_m")),
        )
        .drop("latt_m")
    )

    IF_f = est_f.IFs[:, estimates_j["idx_f"].to_numpy().ravel()]
    IF_m = est_m.IFs[:, estimates_j["idx_m"].to_numpy().ravel()]
    IF_j = np.vstack(((1 / p_m) * IF_m, -(1 / p_f) * IF_f))

    est_j.dp.data = j_data
    est_j.dp.data_orig = j_data_orig
    est_j.dp.units_map = j_units_map
    est_j.dp.n = n
    est_j.IFs = IF_j
    est_j.n = n
    est_j.units = j_units
    # Estimate with union of group to AET(e, t) estimates for the weighting;
    ress = latt_et_all(est_j.dp)
    est_j.IFs_aet = ress.IFs_aet
    est_j.estimates = (
        estimates_j.drop("idx_f", "idx_m")
        .join(
            ress.estimates.select(dp.e_col, dp.t_col, pl.col("denom")),
            how="inner",
            on=[dp.e_col, dp.t_col],
        )
        .with_columns(se=pl.lit(se_ifs(est_j.IFs)))
        .with_columns(pl_ci("latt"))
    )
    return est_j


def _agg_event_nso(
    ap: IDidAggParams,
    ifs_agg: IFsAgg,
    event_fn: Callable[[np.ndarray], np.ndarray],
    m_est: np.ndarray,
) -> AggEventResult:
    """Not summing to one. Don't use; for testing purposes only."""
    Ev = pull(ap.latts, ap.dp.e_col)
    ifa = ifs_agg.if_group_event(event_fn)

    if not np.array_equal(ifa.ev, Ev[m_est]):
        raise ValueError("Event cohorts do not align with selected estimates")

    latts = pull(ap.latts, "latt")[m_est]
    aets = pull(ap.latts, "denom")[m_est]
    if_aet = ap.IFs_aet[:, m_est]
    if_latts = ap.IFs_latt[:, m_est]
    if_gp = ifa.if_ge

    # IF(AET(e, t) / Σ_{e} 1{Cond(e)} AET(e, t))
    w_aet = aets / (w_aet_den := aets.sum())
    if_w_aet = if_weights_fraction(
        weights=w_aet,
        w_denom=w_aet_den,
        IF_num=if_aet,
    )
    w = w_aet * ifa.probs
    # IF(P(E = e | Cond(E)) * [AET(e, t) / Σ_{e} 1{Cond(e)} AET(e, t)])
    if_w = if_product_rule(w_aet, ifa.probs, if_w_aet, if_gp)
    # IF(w LATT(e, t))
    if_w_estimand = if_product_rule(w, latts, if_w, if_latts)
    IF = if_w_estimand.sum(axis=1, keepdims=True)
    est = float((w * latts).sum())
    se = float(se_if_np(IF))
    return AggEventResult(est, se, IF, w)
