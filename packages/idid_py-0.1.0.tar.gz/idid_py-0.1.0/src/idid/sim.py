"""
Simulation functions for IDiD.
"""

from typing import Literal

import numpy as np
import numpy.random as npr
import polars as pl

# other
from polars import col as c
from scipy.special import expit, softmax


def sim_toy_binary_panel(
    n: int = 10_000,
    tau: float = 1.0,
    kappa: float = 1.0,
    seed: int = 0,
    ps_on: Literal["linear", "nonlinear"] = "linear",
    or_on: Literal["linear", "nonlinear"] = "linear",
    extra: bool = False,
) -> pl.DataFrame:
    """Simulates panel dataset.

    For simulation experiment 1.
    """

    rng = np.random.default_rng(seed)

    # observed covariates only
    Z1 = rng.normal(size=n)
    Z2 = rng.normal(size=n)

    def ps_index(z1, z2):
        if ps_on == "linear":
            return 0.8 * z1 - 0.5 * z2
        elif ps_on == "nonlinear":
            return (
                0.8 * np.sin(z1) - 0.5 * (z2 > 0).astype(float) + 0.3 * z1 * z2
            )
        else:
            raise ValueError("ps_on must be 'linear' or 'nonlinear'")

    def or_signal(z1, z2):
        if or_on == "linear":
            return 0.8 * z1 - 0.5 * z2
        elif or_on == "nonlinear":
            return (
                0.8 * np.sin(z1) - 0.5 * (z2 > 0).astype(float) + 0.3 * z1 * z2
            )
        else:
            raise ValueError("or_on must be 'linear' or 'nonlinear'")

    # exposure cohort: 0 = never, 2 = exposed in period 2
    pE = 1 / (1 + np.exp(-ps_index(Z1, Z2)))
    E_id = np.where(rng.uniform(size=n) < pE, 2, 0).astype(int)

    ids = np.repeat(np.arange(n), 2)
    t = np.tile(np.array([1, 2]), n)
    E = np.repeat(E_id, 2)
    post = ((E == 2) & (t == 2)).astype(int)

    # untreated treatment path
    s = or_signal(Z1, Z2)
    UD = rng.uniform(size=n)

    pD0_1 = 1 / (1 + np.exp(-(s - 0.2)))
    pD0_2 = 1 / (1 + np.exp(-(s + 0.2)))

    pD1_1 = pD0_1
    pD1_2 = 1 / (1 + np.exp(-(s + 0.2 + kappa)))

    D0_1 = (UD < pD0_1).astype(int)
    D0_2 = (UD < pD0_2).astype(int)
    D1_1 = (UD < pD1_1).astype(int)
    D1_2 = (UD < pD1_2).astype(int)

    D0_t = np.column_stack([D0_1, D0_2]).reshape(-1)
    D1_t = np.column_stack([D1_1, D1_2]).reshape(-1)
    D_t = D0_t + post * (D1_t - D0_t)

    # untreated outcomes
    eps0 = rng.normal(scale=0.2, size=(n, 2))
    base = or_signal(Z1, Z2)

    Y0_1 = base + eps0[:, 0]
    base_2 = base + 0.8 * or_signal(Z1, Z2)
    Y0_2 = base_2 + eps0[:, 1]

    Y0_t = np.column_stack([Y0_1, Y0_2]).reshape(-1)
    Y1_t = Y0_t + tau
    Y_t = Y0_t + D_t * (Y1_t - Y0_t)

    #  For efficiency bound:
    # - propensity
    # - m(X) = E[Y_t | X, C = 1] control mean function (true value)
    # - g(X) = E[D_t | X, C = 1] control mean function (true value)
    # - w_t, w_c; depend on E[E_e]; p(X)
    pD0_t = np.column_stack([pD0_1, pD0_2]).reshape(-1)
    pD1_t = np.column_stack([pD1_1, pD1_2]).reshape(-1)
    base_t = np.column_stack([base, base_2]).reshape(-1)
    pE_t = np.column_stack([pE, pE]).reshape(-1)
    # For efficiency bound repeated cross-section:
    # - p(X) := P(E = 1 | X)
    # - E[Y | X, C = 1, T = t]
    # - E[Y | X, C = 1, T = e - 1]
    # - E[D | X, C = 1, T = t]
    # - E[D | X, C = 1, T = e - 1]
    # - w_t, w_c; depend on E[E_e]; p(X)

    # Y
    m_t_pre = base + tau * pD1_1
    m_t_post = base_2 + tau * pD1_2
    m_t_pre = np.column_stack((m_t_pre, m_t_pre)).reshape(-1)
    m_t_post = np.column_stack((m_t_post, m_t_post)).reshape(-1)
    m_c_pre = base + tau * pD0_1
    m_c_post = base_2 + tau * pD0_2
    m_c_pre = np.column_stack((m_c_pre, m_c_pre)).reshape(-1)
    m_c_post = np.column_stack((m_c_post, m_c_post)).reshape(-1)
    # D
    g_t_pre = pD1_1
    g_t_post = pD1_2
    g_t_pre = np.column_stack((g_t_pre, g_t_pre)).reshape(-1)
    g_t_post = np.column_stack((g_t_post, g_t_post)).reshape(-1)
    g_c_pre = pD0_1
    g_c_post = pD0_2
    g_c_pre = np.column_stack((g_c_pre, g_c_pre)).reshape(-1)
    g_c_post = np.column_stack((g_c_post, g_c_post)).reshape(-1)

    df = pl.DataFrame(
        {
            "id": ids,
            "t": t,
            "E": E,
            "D0_t": D0_t,
            "D1_t": D1_t,
            "D_t": D_t,
            "Y0_t": Y0_t,
            "Y1_t": Y1_t,
            "Y_t": Y_t,
            "Z1": np.repeat(Z1, 2),
            "Z2": np.repeat(Z2, 2),
        }
    )
    if extra:
        cols = {
            "pD0_t": pD0_t,
            "pD1_t": pD1_t,
            "base_t": base_t,
            "pE": pE_t,
            "m_t_pre": m_t_pre,
            "m_t_post": m_t_post,
            "m_c_pre": m_c_pre,
            "m_c_post": m_c_post,
            "g_t_pre": g_t_pre,
            "g_t_post": g_t_post,
            "g_c_pre": g_c_pre,
            "g_c_post": g_c_post,
        }
        df = df.with_columns(
            pl.lit(v).alias(k) for k, v in cols.items()
        ).with_columns(
            m=pl.col("base_t") + tau * pl.col("pD0_t"),
            g=pl.col("pD0_t"),
            m_t=pl.col("base_t") + tau * pl.col("pD1_t"),
            g_t=pl.col("pD1_t"),
        )
    return df


def sim_toy_binary_rc(
    n: int = 10_000,
    tau: float = 1.0,
    kappa: float = 1.0,
    seed: int = 0,
    lam: float = 0.5,
    ps_on: Literal["linear", "nonlinear"] = "linear",
    or_on: Literal["linear", "nonlinear"] = "linear",
    extra: bool = True,
) -> pl.DataFrame:
    """Simulates repeated cross-sections dataset.

    For Simulation experiment 1.
    """
    import numpy as np
    import polars as pl

    if not (0.0 < lam < 1.0):
        raise ValueError("lam must be in (0, 1).")

    rng = np.random.default_rng(seed)

    dfp = sim_toy_binary_panel(
        n=n,
        tau=tau,
        kappa=kappa,
        seed=seed,
        ps_on=ps_on,
        or_on=or_on,
        extra=extra,
    )

    T_obs = np.where(rng.uniform(size=n) <= lam, 2, 1)

    return (
        dfp.join(
            pl.DataFrame(
                {
                    "id": np.arange(n),
                    "T": T_obs,
                }
            ),
            on="id",
            how="left",
        )
        .filter(pl.col("t") == pl.col("T"))
        .with_columns(pl.col("T").alias("t_obs"))
        .rename(
            {
                "Y_t": "Y",
                "D_t": "D",
            }
        )
    )


# NOTE: --- Other simulation experiments ---


def sample_cat(probs: np.ndarray, supp: np.ndarray):
    """
    probs: shape (n, k), rows sum to 1
    suppG: shape (k,)

    returns (n, 1) column of drawn categoricals
    """
    u = np.random.rand(probs.shape[0])
    samples_idx = (np.cumsum(probs, axis=1) > u[:, None]).argmax(axis=1)
    return np.array(supp)[samples_idx][:, None]


def get_pars_suppE(suppE: np.ndarray):
    """Returns parameters for P(E = e | X) staggered case."""
    return np.linspace(start=0.1, stop=0.3, num=suppE.shape[0])


def sim_stag_panel(
    n: int,
    T: int,
    E_cohorts: list[int] | None = None,
    te_factor: int = 1,
    delta: float = 1,
    start_period: int = 1,
    confounded: bool = False,
    onesided: bool = False,
    te_varying: bool = False,
    with_group: bool = False,
    include_extras: bool = False,
) -> pl.DataFrame:
    """Simulate balanced panel data under a staggered-exposure DGP.

    The returned data are in long format with one row per unit-period and are
    designed for the examples and simulation experiments in the paper. The
    exposure cohorts are determined by `E_cohorts`, where `0` denotes the
    never-exposed group.

    Key options:

    - `confounded=True` adds an unobserved time-varying confounder to both the
      treatment and outcome equations
    - `onesided=True` enforces no treatment before exposure and absorbing
      treatment thereafter
    - `te_varying=True` makes treatment effects vary with event time
    - `with_group=True` adds a binary subgroup variable `F` used in the group
      comparison simulations
    - `include_extras=True` returns latent and potential-outcome variables used
      for diagnostics and Monte Carlo evaluation
    """
    if E_cohorts is None:
        E_cohorts = [0] + list(range(2, T))

    nper = T - start_period + 1
    # support: suppE = {0, 2, 3, ..., E}
    suppE = np.array(E_cohorts)
    E = suppE.shape[0]
    X = npr.normal(size=(n, 1))
    beta_e = get_pars_suppE(suppE)
    ell_e = beta_e[None, :] * X  # (n, |suppE|)
    pe = softmax(ell_e, axis=1)
    Es = sample_cat(pe, suppE).ravel()

    ts = np.arange(start_period, T + 1)
    t = np.tile(ts, n)
    ids = np.repeat(np.arange(n), nper)
    Ess = np.repeat(Es, nper)

    de = te_factor * (t - Ess + 1)
    post = ((de > 0) & (Ess > 0)).astype(int)
    # Selector: exposed (E > 0) and post-exposure (t - E >= 0)
    s = ((Ess > 0) & ((t - Ess) >= 0)).astype(int)

    U_t = npr.uniform(size=(n * nper,))
    nu = np.repeat(npr.uniform(low=-1, high=-0.5, size=n), nper)  # FE treatment
    rX = np.repeat(X.ravel(), nper)

    H = (
        # time-varying confounder H_t
        # npr.normal(size=rX.shape[0], scale=0.01)
        npr.normal(size=rX.shape[0], scale=1)
        # np.repeat(npr.normal(size=X.shape[0]), nper)
        if confounded
        else np.zeros(shape=rX.shape[0])
    )

    if delta <= 0:
        raise ValueError("Effect on the treatment should be positive")

    # L = nu + rX + H + (t / T)
    L_t = nu + 0.5 * rX + H + (1 / 8) * t / T
    L1_t = L_t + post * delta
    p0 = expit(L_t)
    p1 = expit(L1_t)

    D0_t = (U_t <= p0).astype(np.int8)
    D1_t = (U_t <= p1).astype(np.int8)  # monotonicity

    # Observed treatment
    D_t = D0_t + s * (D1_t - D0_t)

    extra_vars = dict()

    if onesided:
        # No treatment before exposure and never-exposed remain untreated
        D_t = np.where(s, D_t, 0).astype(np.int8)

        # Absorbing treatment within id: once treated, always treated
        D_t = D_t.reshape(n, nper)
        D_t = np.maximum.accumulate(D_t, axis=1).astype(np.int8)
        D_t = D_t.ravel()

    # Outcome t

    if te_varying:
        # First treatment period G = min {t : D_t = 1}, or 0 if never treated
        t2 = t.reshape(n, nper)
        D2 = D_t.reshape(n, nper)
        has_treat = D2.any(axis=1)
        G_id = np.where(has_treat, np.where(D2 == 1, t2, np.inf).min(axis=1), 0)
        G_id = G_id.astype(int)
        G = G_id[ids]
        extra_vars |= {"G": G}
        _tau_p = 1
        tau_p = ((t - G + 1) * _tau_p) / 2 * (t - G >= 0) * (G > 0)
    else:
        tau_p = 1

    if with_group:
        # group effect differ by 0.5 in treatment effects
        F = npr.binomial(n=1, p=0.5, size=(n,))
        Fs = np.repeat(F, nper)
        tau_p = tau_p - 0.5 * Fs

    eta = npr.normal(loc=Es / E, scale=1)
    reta = np.repeat(eta, nper)
    eps_t = npr.normal(size=(n * nper,))
    nu_t = npr.normal(size=(n * nper,))
    Y0_t = rX + H + reta + (t / T) + eps_t  # with FE and trend
    Y1_t = Y0_t + tau_p + nu_t

    # Observed outcomes
    Y_t = Y0_t + D_t * (Y1_t - Y0_t)

    # Unexposed outcomes
    Yinf_t = Y0_t + D0_t * (Y1_t - Y0_t)

    df = pl.DataFrame(
        {
            "id": ids,
            "E": Ess,
            "t": t,
            "X": rX,
            "D_t": D_t,
            "Y_t": Y_t,
        }
    )

    if with_group:
        # always include the group variable
        group_var = {"F": Fs}
        df = df.with_columns(pl.lit(v).alias(k) for k, v in group_var.items())

    if onesided:
        df = df.with_columns(
            pl.col("t")
            .filter(pl.col("D_t") == 1)
            .min()
            .over("id")
            .fill_null(0)
            .alias("G")
        )

    if not include_extras:
        return df

    # pick out P(E = e | X) and l_e(X) corresponding to E_i
    mapp = dict(zip(suppE, range(len(suppE))))
    pick_e = np.array([mapp[e] for e in Es])
    ell_e_p = ell_e[np.arange(ell_e.shape[0]), pick_e]
    p_e = pe[np.arange(pe.shape[0]), pick_e]
    extra_vars |= {
        "ell": np.repeat(ell_e_p, nper),
        "pe": np.repeat(p_e, nper),
    }
    extra_vars |= {
        "post": post,
        "s": s,
        "D0_t": D0_t,
        "D1_t": D1_t,
        "eta": reta,
        "de": de,
        "Yinf_t": Yinf_t,
        "p0": p0,
        "p1": p1,
        "Y0_t": Y0_t,
        "Y1_t": Y1_t,
    }
    return df.with_columns(pl.lit(v).alias(k) for k, v in extra_vars.items())


def sim_stag_rc(
    n: int,
    T: int,
    E_cohorts: list[int] = [0] + list(range(1, 5)),
    te_factor: int = 1,
    tau_d: float = 1,
    start_period: int = 1,
    confounded: bool = False,
    onesided: bool = False,
    te_varying: bool = False,
    **kwargs,
):
    """Simulate repeated cross-sections from the staggered-exposure DGP.

    This function draws a fresh cross-section in each period by repeatedly
    simulating panel data and then keeping only the observations for the
    current period. The result is a repeated cross-section analogue of
    {py:func}`sim_stag_panel`.

    Most keyword arguments are forwarded to {py:func}`sim_stag_panel`, including
    options such as `confounded`, `onesided`, `te_varying`, `with_group`, and
    `include_extras`.
    """
    ts = np.arange(start_period, T + 1)
    nper = T - start_period + 1
    nt = n // nper

    dfs = []
    for t in ts:
        df = sim_stag_panel(
            n=nt,
            T=T,
            E_cohorts=E_cohorts,
            confounded=confounded,
            onesided=onesided,
            te_varying=te_varying,
            **kwargs,
        )
        dfs.append(
            df.filter(pl.col("t").eq(t)).with_columns(
                pl.col("id").cast(pl.Utf8) + f"t={t}"
            )
        )
    return pl.concat(dfs).with_columns(pl.col("id").rank("ordinal")).sort("id")


def latet():
    return (
        c("Y1_t")
        .sub("Y0_t")
        #  NOTE: we have already filtered by E = e (treated)
        # hence this computes E[Y1_t - Y0_t | E = e, D1_t - D0_t]
        # i.e. the CLATT
        .filter(c("D1_t").gt(c("D0_t")))
        .mean()
        .alias("LATET")
    )


def aet():
    return (
        #  NOTE: we have already filtered by E = e (treated)
        c("D1_t").gt(c("D0_t")).mean().alias("AET")
    )


def ate():
    return c("Y1_t").sub("Y0_t").mean().alias("ATE")


def avg_evolution(df: pl.DataFrame):
    return (
        df.group_by("E", "t", maintain_order=True)
        .agg(
            pl.col("D0_t").mean().round(1),
            pl.col("D1_t").mean().round(1),
            pl.col("D_t").mean().round(1),
            pl.col("Y_t").mean().round(1),
            pl.col("Yinf_t").mean().round(1),
            c("D1_t").gt(c("D0_t")).mean().alias("compliers"),
            c("D1_t").sub(c("D0_t")).mean().alias("relevance"),
            c("D_t").sub(c("D0_t")).mean().alias("relevance2"),
            latet(),
        )
        .sort("E", "t")
        .with_columns(pl.selectors.float().round(3))
    )


def pt_outcomes(t_col: str, t_val: int):
    return [
        pl.col("Y_t")
        .filter(pl.col(t_col).eq(t_val))
        .first()
        .over("id")
        .alias("Y_e1"),
        pl.col("D_t")
        .filter(pl.col(t_col).eq(t_val))
        .first()
        .over("id")
        .alias("D_e1"),
    ]


def pt_outcome(outcome: str, t_col: str, t_val: int):
    return (
        pl.col(outcome)
        .filter(pl.col(t_col).eq(t_val))
        .first()
        .over("id")
        .alias(f"{outcome}m1")
    )


def sampled_groups(df: pl.DataFrame):
    return (
        df.unique("id")
        .select(pl.col("E").value_counts())
        .unnest("E")
        .with_columns(
            pl.col("count")
            .truediv(pl.col("count").sum())
            .mul(100)
            .alias("frac"),
        )
        .sort("E")
    )
