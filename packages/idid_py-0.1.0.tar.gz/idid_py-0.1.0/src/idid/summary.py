from __future__ import annotations

from typing import TYPE_CHECKING, Any

import polars as pl
import tabulate

if TYPE_CHECKING:
    from idid.aggregate import AggLattResult
    from idid.estimators import IDidResult


def add_stars(df: pl.DataFrame):
    return df.with_columns(
        stars=pl.when(pl.col("lower").is_nan() | pl.col("upper").is_nan())
        .then(pl.lit(""))
        .when(
            pl.col("lower").gt(0) & pl.col("upper").gt(0)
            | pl.col("lower").lt(0) & pl.col("upper").lt(0)
        )
        .then(pl.lit("*"))
        .otherwise(pl.lit(""))
    )


method_titles = {
    "dynamic": "Dynamic",
    "dynamic_bal": "Balanced dynamic",
    "group": "Group",
    "cohort": "Cohort",
    "cohort_custom": "Custom cohort",
    "calendar": "Time",
}
method_col_titles = {
    "dynamic": "Event time",
    "dynamic_bal": "Event time",
    "group": "Group",
    "cohort": "Cohort",
    "cohort_custom": "Cohort",
    "calendar": "Time",
}
control_map = {
    "never": "Never treated",
    "notyet": "Not yet treated",
}
type_agg_map = {
    "dynamic": "event-study/dynamic",
    "dynamic_bal": "balanced event-study/dynamic",
    "group": "group/cohort",
    "cohort": "cohort",
    "cohort_custom": "custom cohort",
    "calendar": "calendar time",
}
est_method_title = {
    "dr": "Doubly Robust",
    "dr_imp": "Doubly Robust (improved)",
    "reg": "Outcome Regression",
    "dml": "Double Machine Learning",
}
compact_plain = tabulate.TableFormat(
    lineabove=None,
    linebelowheader=None,
    linebetweenrows=None,
    linebelow=None,
    headerrow=tabulate.DataRow(begin="", sep=" ", end=""),
    datarow=tabulate.DataRow(begin="", sep=" ", end=""),
    padding=0,
    with_header_hide=None,
)


def summarize_gt(res: IDidResult, show_denom: bool = True):
    print("Cohort-Time Local Average Treatment Effects on the Treated:")
    cols = [
        res.dp.e_col,
        res.dp.t_col,
        "latt",
        "se",
        "lower",
        "upper",
    ]
    headers = [
        "E",
        "t",
        "LATT(e, t)",
        "Std. Error",
        "[95% Pointwise.",
        "Conf. Band]",
        "",
    ]
    floatfmt = [".0f", ".0f", ".4f", ".4f", ".4f", ".4f", "s"]
    if show_denom:
        cols.insert(2, "denom")
        headers.insert(2, "AET(e, t)")
        floatfmt.insert(2, ".4f")

    rows = res.estimates.select(cols).pipe(add_stars).rows()
    table_str_gt = tabulate.tabulate(
        rows,
        headers=headers,
        floatfmt=tuple(floatfmt),
        tablefmt=compact_plain,
        colalign=("center", "center", *["right"] * (len(headers) - 2)),
        stralign="left",
        numalign="right",
    )
    print(table_str_gt)
    print("---")
    print("Signif. codes: `*' confidence band does not cover 0")
    print(f"Control group: {control_map.get(res.dp.control, '')}")
    print(f"Estimation Method: {est_method_title.get(res.dp.method, '')}")
    if res.dp.method == "dml":
        extras = [
            latt.extra
            for latt in res.latts.values()
            if getattr(latt, "extra", None) is not None
        ]
        if extras:
            meta = extras[0]
            print(
                "DML nuisance models: "
                f"m_m={meta.get('m_m', '')}, "
                f"g_m={meta.get('g_m', '')}, "
                f"p_m={meta.get('p_m', '')}"
            )
            print(f"DML cross-fitting folds: {meta.get('nfolds', '')}")


def overall_table(
    overall_data: list[tuple[Any, ...]],
    interval_title: str = "[95%  ",
):
    df_oa = pl.DataFrame(
        overall_data,
        schema=["latt", "se", "lower", "upper"],
        orient="row",
    ).pipe(add_stars)
    return tabulate.tabulate(
        df_oa.rows(),
        headers=[
            "LATT",
            "Std. Error",
            interval_title,
            "Conf. Band]",
            "",
        ],
        floatfmt=(".4f", ".4f", ".4f", ".4f", "s"),
        tablefmt="plain",
    )


def summarize_agg_te(agg_te: AggLattResult):
    df = agg_te.estimates.pipe(add_stars)
    method = agg_te.method
    method_title = method_titles.get(method, method.capitalize())
    method_col_title = method_col_titles.get(method, method.capitalize())
    controls = control_map.get(agg_te.params.dp.control, "")
    type_ = type_agg_map.get(method, method.capitalize())
    is_boot = agg_te.boot is not None
    cint_left_title = "[95% Simult." if is_boot else "[95% Pointwise"
    if is_boot:
        overall_data = agg_te.boot.estimates_overall.select(
            "latt", "se", "lower", "upper"
        ).rows()
    else:
        overall_data = [
            (
                est := agg_te.overall_latt,
                se := agg_te.overall_se,
                est - 1.96 * se,
                est + 1.96 * se,
            )
        ]
    table_str_oa = overall_table(
        overall_data,
        interval_title="[95% Simult." if is_boot else "[95%  ",
    )
    table_str = tabulate.tabulate(
        df.rows(),
        headers=[
            method_col_title,
            "Estimate",
            "Std. Error",
            cint_left_title,
            "Conf. Band]",
            "",
        ],
        floatfmt=(".0f", ".4f", ".4f", ".4f", ".4f", "s"),
        tablefmt="plain",
    )
    if method == "simple":
        print(table_str_oa)
    else:
        print(f"Overall summary of ATT's based on {type_} aggregation:")
        print(table_str_oa)
        print()
        print(f"{method_title} effects:")
        print(table_str)
        print("---")
        print("Signif. codes: `*' confidence band does not cover 0")
        print(f"Control group: {controls}")
        print(
            "Estimation Method: "
            f"{est_method_title.get(agg_te.params.dp.method, '')}"
        )
    if agg_te.extra.get("balanced_cohorts") is not None:
        cohorts = agg_te.extra["balanced_cohorts"]
        cohorts_str = ", ".join(map(str, cohorts.tolist()))
        if cohorts_str == "":
            cohorts_str = "<none>"
        print(f"Balanced cohorts: {cohorts_str}")
        print(f"lprime: {agg_te.extra.get('lprime')}")
    if agg_te.boot is not None:
        print(
            "Multiplier bootstrap: "
            f"B={agg_te.boot.B}, "
            f"c={agg_te.boot.c:.4f}, "
            f"overall c={agg_te.boot.c_overall:.4f}"
        )
