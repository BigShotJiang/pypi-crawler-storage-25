"""
Sorry for calling this module for `utils`.
"""

from dataclasses import is_dataclass
from typing import Iterable, Sequence

import numpy as np
import polars as pl


def pull(df: pl.DataFrame, col: str, keep_dims: bool = False):
    arr = df.select(col).to_numpy()
    if keep_dims:
        return arr
    return arr.ravel()


def pulls(
    df: pl.DataFrame, cols: Sequence[str], keep_dims: bool = False
) -> Iterable[np.ndarray]:
    return (pull(df, c, keep_dims) for c in cols)


def sorted_unqs(arr: np.ndarray) -> np.ndarray:
    return np.sort(np.unique(arr))


class ReprMixin:
    """Compact repr for result objects with large arrays/dataframes."""

    __repr_fields__: tuple[str, ...] | None = None
    __repr_max_items__: int = 4

    @classmethod
    def _short(cls, val):
        max_items = cls.__repr_max_items__
        if isinstance(val, pl.DataFrame):
            cols = val.columns[:max_items]
            more = "" if len(val.columns) <= max_items else ", ..."
            return (
                f"DataFrame[{val.height}x{val.width}; {', '.join(cols)}{more}]"
            )
        if isinstance(val, np.ndarray):
            return f"ndarray{val.shape}"
        if hasattr(val, "shape"):
            return f"{type(val).__name__}{val.shape}"
        if isinstance(val, dict):
            keys = list(val)[:max_items]
            more = "" if len(val) <= max_items else ", ..."
            return f"dict[{', '.join(map(str, keys))}{more}]"
        if isinstance(val, (list, tuple)):
            items = [cls._short(v) for v in val[:max_items]]
            more = "" if len(val) <= max_items else ", ..."
            opener, closer = ("[", "]") if isinstance(val, list) else ("(", ")")
            return f"{opener}{', '.join(items)}{more}{closer}"
        if is_dataclass(val) and not isinstance(val, type):
            name = val.__class__.__name__
            data = vars(val)
            fields = getattr(val, "__repr_fields__", None)
            if fields is None:
                fields = tuple(
                    k
                    for k, v in data.items()
                    if isinstance(v, (str, int, float, bool))
                )[:max_items]
            if not fields:
                return f"{name}(...)"
            inner = ", ".join(
                f"{k}={cls._short(data[k])}" for k in fields if k in data
            )
            return f"{name}({inner})"
        return repr(val)

    def __repr__(self):
        data = vars(self)
        fields = self.__repr_fields__ or tuple(data)
        items = []
        for key in fields:
            if key not in data:
                continue
            val = data[key]
            if val is None or (isinstance(val, str) and val == ""):
                continue
            if isinstance(val, (list, tuple, dict)) and len(val) == 0:
                continue
            items.append(f"{key}={self._short(val)}")
        return f"{self.__class__.__name__}({', '.join(items)})"


def _print_summary(df: pl.DataFrame):
    with pl.Config(tbl_rows=100, tbl_cols=10):
        print(df.with_columns(pl.selectors.float().round(3)))


def compare_ests(res, out, *, name: str = "estimates") -> None:
    """Compare scalar estimates and standard errors between two results."""

    def _scalar_stats(a, b, label):
        a = float(a)
        b = float(b)
        diff = a - b
        denom = abs(a) + 1e-8

        print(f"\n[{label}]")
        print("res :", a)
        print("out :", b)
        print("diff:", diff)
        print("rel :", diff / denom)

    print(f"\n==== {name} diagnostics ====")

    _scalar_stats(res.latt, out.att, "att")
    _scalar_stats(res.num, out.num, "num")
    _scalar_stats(res.den, out.den, "den")

    if hasattr(res, "se") and hasattr(out, "se"):
        _scalar_stats(res.se, out.se, "se")


def _stats_if(a, b, label):
    a = a.ravel()
    b = b.ravel()
    diff = a - b

    print(f"\n[{label}]")
    print("var:")
    print(np.var(a))
    print(np.var(b))

    print("mean:")
    print(np.mean(a))
    print(np.mean(b))

    corr = np.corrcoef(a, b)[0, 1]
    print(f"corr: {corr:.6f}")

    print("diff:")
    print("  mean:", diff.mean())
    print("  std :", diff.std())
    print("  max :", np.max(np.abs(diff)))

    rel = diff / (np.std(a) + 1e-8)
    print("rel diff (scaled by sd):")
    print("  std :", rel.std())
    print("  max :", np.max(np.abs(rel)))


def compare_if(res, out, *, name: str = "IF") -> None:
    """Compare influence functions and components between two results."""

    print(f"\n==== {name} diagnostics ====")

    _stats_if(res.IF, out.IF, "IF")
    _stats_if(res.IF_num, out.IF_num, "IF_num")
    _stats_if(res.IF_den, out.IF_den, "IF_den")


def describe(x) -> None:
    x = np.asarray(x)
    print(f"n      : {x.size}")
    print(f"mean   : {x.mean():.6f}")
    print(f"std    : {x.std(ddof=1):.6f}")
    print(f"min    : {x.min():.6f}")
    print(f"25%    : {np.quantile(x, 0.25):.6f}")
    print(f"median : {np.median(x):.6f}")
    print(f"75%    : {np.quantile(x, 0.75):.6f}")
    print(f"max    : {x.max():.6f}")


def pl_ci(est_col: str = "latt"):
    return (
        (pl.col(est_col) - pl.col("se") * 1.96).alias("lower"),
        (pl.col(est_col) + pl.col("se") * 1.96).alias("upper"),
    )
