from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np
import statsmodels.api as sm
from scipy.special import expit
from sklearn.base import BaseEstimator, ClassifierMixin, RegressorMixin

from idid import logreg

__all__ = [
    "FastLogitWrap",
    "FastLogit",
    "OLS",
    "fast_logit",
    "ols",
    "logit",
]


@dataclass(repr=False)
class FastLogitWrap:
    beta: np.ndarray
    X: np.ndarray

    def predict(self, X: np.ndarray | None = None, which: str = "prob"):
        if X is None:
            X = self.X
        if which not in ["prob", "linear"]:
            raise ValueError()
        if which == "linear":
            return X @ self.beta
        return expit(X @ self.beta)


@dataclass(repr=False)
class FastLogit(BaseEstimator, ClassifierMixin):
    beta_: np.ndarray | None = field(default=None, init=False, repr=False)

    def fit(self, X: np.ndarray, y: np.ndarray) -> "FastLogit":
        out = logreg.irls(X=X, y=y)
        self.beta_ = np.asarray(out.coefficients)
        self.classes_ = np.array([0, 1])
        return self

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        if self.beta_ is None:
            raise ValueError("Model is not fitted.")
        p = expit(X @ self.beta_)
        return np.column_stack([1.0 - p, p])

    def predict(self, X: np.ndarray) -> np.ndarray:
        return (self.predict_proba(X)[:, 1] >= 0.5).astype(int)

    def decision_function(self, X: np.ndarray) -> np.ndarray:
        if self.beta_ is None:
            raise ValueError("Model is not fitted.")
        return X @ self.beta_


@dataclass(repr=False)
class OLS(BaseEstimator, RegressorMixin):
    beta_: np.ndarray | None = field(default=None, init=False, repr=False)

    def fit(self, X: np.ndarray, y: np.ndarray) -> "OLS":
        self.beta_ = ols(endog=y, exog=X).ravel()
        return self

    def predict(self, X: np.ndarray) -> np.ndarray:
        if self.beta_ is None:
            raise ValueError("Model is not fitted.")
        return X @ self.beta_


def fast_logit(endog: np.ndarray, exog: np.ndarray) -> FastLogitWrap:
    out = logreg.irls(X=exog, y=endog)
    return FastLogitWrap(np.asarray(out.coefficients), exog)


def ols(endog: np.ndarray, exog: np.ndarray) -> np.ndarray:
    model = sm.OLS(endog=endog, exog=exog)
    results = model.fit(disp=0)
    return results.params.reshape(-1, 1)


def logit(endog: np.ndarray, exog: np.ndarray):
    model = sm.Logit(endog=endog, exog=exog).fit(disp=0)
    return model


@dataclass
class OregOutput:
    m: Any
    params: np.ndarray
    pred: np.ndarray


def oreg(
    X: np.ndarray,
    Y: np.ndarray,
    b: np.ndarray,
    weights: np.ndarray | None = None,
) -> OregOutput:
    if b.dtype != np.bool_:
        raise ValueError("Input array must be of boolean dtype.")
    if weights is not None:
        m = sm.WLS(
            endog=Y[b], exog=X[b, :], weights=weights[b], hasconst=True
        ).fit(disp=0)
    else:
        m = sm.OLS(endog=Y[b], exog=X[b, :]).fit(disp=0)
    params = m.params.reshape(-1, 1)
    pred = m.predict(X).reshape(-1, 1)
    if np.isnan(params).any():
        raise ValueError(f"NaN in params {params}")
    return OregOutput(m=m, params=params, pred=pred)


def logit_oreg(
    X: np.ndarray,
    Y: np.ndarray,
    b: np.ndarray,
    weights: np.ndarray | None = None,
) -> OregOutput:
    if b.dtype != np.bool_:
        raise ValueError("Input array must be of boolean dtype.")
    if weights is not None:
        raise NotImplementedError("weights are not supported for logit_oreg")
    m = fast_logit(endog=Y[b].ravel(), exog=X[b, :])
    pred = expit(X @ m.beta).reshape(-1, 1)
    params = np.asarray(m.beta).reshape(-1, 1)
    if np.isnan(params).any():
        raise ValueError(f"NaN in params {params}")
    return OregOutput(m=m, params=params, pred=pred)
