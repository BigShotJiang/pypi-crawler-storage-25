from idid import nuisance_estimators
from idid.aggregate import agg_latt
from idid.estimators import estimate
from idid.sim import sim_stag_panel, sim_stag_rc

__all__ = [
    "agg_latt",
    "estimate",
    "sim_stag_rc",
    "sim_stag_panel",
    "nuisance_estimators",
]

__version__ = "0.1.0"
