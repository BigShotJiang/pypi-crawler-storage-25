"""
Instrumented DiD implementation.
"""

from __future__ import annotations

import itertools as it
from collections import OrderedDict
from contextlib import nullcontext
from dataclasses import dataclass
from typing import Any, Iterable, Literal, overload

import numpy as np
import polars as pl
from tqdm import tqdm

from idid import dridid, nuisance_estimators
from idid._types import (
    LATT,
    Control,
    DMLKwargs,
    FailedLATT,
    LATTs,
    Method,
    OutcomeRegressionKwargs,
)
from idid.dridid import ParamsPanel, ParamsRc
from idid.summary import summarize_gt
from idid.utils import ReprMixin, pl_ci, pull, pulls, sorted_unqs

__all__ = [
    "IDidResult",
    "estimate",
]


def pcols(s: str) -> Iterable[pl.Expr]:
    return (pl.col(c) for c in s.split())


@dataclass(repr=False)
class IDidParams:
    data: pl.DataFrame
    e_col: str
    t_col: str
    d_col: str
    y_col: str
    i_col: str
    n: int
    data_orig: pl.DataFrame  # For aggregation later
    units_map: dict[Any, int]
    covariates: list[str] | None = None
    balanced: bool = True
    control: Control = "never"
    method: Method = "dr"
    dml_kwargs: DMLKwargs | None = None
    num_kwargs: OutcomeRegressionKwargs | None = None
    den_kwargs: OutcomeRegressionKwargs | None = None
    verbose: bool = True
    prelim_check: bool = False


def concat_ifs(
    dp: IDidParams,
    res: LATTs,
    IF_name: str = "IF",
):
    i_col = dp.i_col
    IFs = np.zeros(shape=(dp.n, len(res)))
    for j, r in enumerate(res.values()):
        if isinstance(r, FailedLATT):
            IFs[:, j] = np.nan
            continue
        IFs[pull(r.ids, i_col), j] = getattr(r, IF_name).ravel()
    return IFs


def get_res_ov(
    res: LATTs,
    ses: np.ndarray,
    e_col: str = "g",
    t_col: str = "t",
):
    return pl.DataFrame(
        [
            (r.g, r.t, r.latt, se, r.num, r.denom)
            for r, se in zip(res.values(), ses)
        ],
        schema=[e_col, t_col, "latt", "se", "num", "denom"],
        orient="row",
    )


@dataclass
class CohortTimePair:
    e: int
    t: int
    pt: int


def observed_both(
    t: int,
    pt: int,
    t_col: str,
    i_col: str,
):
    # Picks out ids that are observed *both* in period pt and t
    return (pl.col(t_col).eq(t).any() & pl.col(t_col).eq(pt).any()).over(i_col)


def subset_data(dp: IDidParams, gtp: CohortTimePair):
    """ """
    data = dp.data
    match dp.control:
        case "never":
            data = data.with_columns(C=pl.col(dp.e_col).eq(0).cast(pl.Int8))
        case "notyet":
            data = data.with_columns(
                # compare with not-yet-exposed at time t
                C=(pl.col(dp.e_col).gt(gtp.t) | pl.col(dp.e_col).eq(0)).cast(
                    pl.Int8
                )
            )
    if dp.balanced:
        return (
            data.with_columns(
                E=pl.col(dp.e_col).eq(gtp.e).cast(pl.Int8),
            )
            .filter(
                ((pl.col("E") == 1) | (pl.col("C") == 1))
                & pl.col(dp.t_col).is_in([gtp.pt, gtp.t])
            )
            .sort(dp.i_col, dp.t_col)
            .with_columns(
                Y0=pl.col(dp.y_col).first().over(dp.i_col),
                Y1=pl.col(dp.y_col).last().over(dp.i_col),
                D0=pl.col(dp.d_col).first().over(dp.i_col),
                D1=pl.col(dp.d_col).last().over(dp.i_col),
            )
            .with_columns(
                dY=pl.col("Y1") - pl.col("Y0"),
                dD=pl.col("D1") - pl.col("D0"),
            )
            .filter(pl.col(dp.t_col) == gtp.t)
        )
    # Repeated cross-section
    return (
        data.with_columns(
            E=pl.col(dp.e_col).eq(gtp.e).cast(pl.Int8),
        )
        .filter(
            pl.col("E").eq(1) | pl.col("C").eq(1),
            # relevant periods
            pl.col(dp.t_col).is_in([gtp.pt, gtp.t]),
        )
        .sort(dp.i_col, dp.t_col)
    )


def latt_et_panel(
    dp: IDidParams,
    pr: CohortTimePair,
    method: Method,
):
    """Estimate LATT(e, t) for given method."""

    match method:
        case "reg":
            dridid_fn = dridid.latt_oreg_panel
        case "ipw":
            dridid_fn = dridid.latt_ipw_panel
        case "std_ipw":
            dridid_fn = dridid.latt_std_ipw_panel
        case "dr":
            dridid_fn = dridid.latt_dr_panel
        case "check":
            dridid_fn = dridid.latt_dr_panel_check
        case "dml":
            dridid_fn = dridid.latt_dml_panel
        case "ee":
            dridid_fn = dridid.latt_ee_panel
        case "imp":
            dridid_fn = dridid.latt_dr_imp_panel
        case _:
            raise ValueError(f"Invalid method {method}")

    subset = subset_data(dp, pr)

    E = pull(subset, "E", keep_dims=True)
    X = dridid.get_xmat(subset, covariates=dp.covariates)
    # if dp.prelim_check:
    #     pc = drdid.PrelimCheck(subset=subset, G=G.ravel(), X=X, g=g, t=t)
    #     if check_failed := drdid.prelim_check(pc):
    #         print(f"Preliminary check failed: {check_failed}")

    dres = dridid_fn(
        ParamsPanel(
            subset=subset,
            X=X,
            E=E,
            dY=pull(subset, "dY", keep_dims=True),
            dD=pull(subset, "dD", keep_dims=True),
            Y1=pull(subset, dp.y_col, keep_dims=True),
            Y0=(
                pull(subset, dp.y_col, keep_dims=True)
                - pull(subset, "dY", keep_dims=True)
            ),
            D1=pull(subset, dp.d_col, keep_dims=True),
            D0=(
                pull(subset, dp.d_col, keep_dims=True)
                - pull(subset, "dD", keep_dims=True)
            ),
        ),
        num_kwargs=dp.num_kwargs,
        den_kwargs=dp.den_kwargs,
        **(dp.dml_kwargs or {}),
    )
    IF = (dp.n / subset.shape[0]) * dres.IF  # (n / n_1) * IF
    IF_aet = (dp.n / subset.shape[0]) * dres.IF_den
    return LATT(
        latt=dres.latt,
        num=dres.num,
        denom=dres.den,
        IF=IF,
        IF_aet=IF_aet,
        g=pr.e,
        t=pr.t,
        ids=subset.select(dp.i_col, "E"),
        ns=subset.shape[0],
        extra=dres.extra,
    )


def latt_et_rc(
    dp: IDidParams,
    pr: CohortTimePair,
    method: Method,
):
    match method:
        case "reg":
            dridid_fn = dridid.latt_oreg_rc
        case "ipw":
            dridid_fn = dridid.latt_ipw_rc
        case "std_ipw":
            dridid_fn = dridid.latt_std_ipw_rc
        case "dr":
            dridid_fn = dridid.latt_dr_rc
        case "dml":
            dridid_fn = dridid.latt_dml_rc
        case "ee":
            dridid_fn = dridid.latt_ee_rc
        case "imp":
            dridid_fn = dridid.latt_dr_imp_rc
        case _:
            raise ValueError(f"Invalid method {method}")
    subset = subset_data(dp, pr)
    check = check_nyt(subset, pr, dp)
    if not check.ok:
        return FailedLATT(
            latt=np.nan,
            num=np.nan,
            denom=np.nan,
            g=pr.e,
            t=pr.t,
            reason=check.msg,
        )
    dres = dridid_fn(
        ParamsRc(
            subset=subset,
            X=dridid.get_xmat(subset, covariates=dp.covariates),
            Y=pull(subset, dp.y_col, keep_dims=True),
            D=pull(subset, dp.d_col, keep_dims=True),
            T=(pull(subset, dp.t_col, keep_dims=True) == pr.t),
            E=pull(subset, "E", keep_dims=True),
        ),
        num_kwargs=dp.num_kwargs,
        den_kwargs=dp.den_kwargs,
        **(dp.dml_kwargs or {}),
    )
    IF = (dp.n / subset.shape[0]) * dres.IF  # (n / n_1) * IF
    IF_aet = (dp.n / subset.shape[0]) * dres.IF_den
    gp = (
        subset.select(dp.i_col, "E")
        .with_columns(
            IF=pl.lit(IF.ravel()),
            IF_aet=pl.lit(IF_aet.ravel()),
        )
        .group_by(dp.i_col, "E")
        .agg(pl.col("IF").sum(), pl.col("IF_aet").sum())
        .sort(dp.i_col)
    )
    IF = pull(gp, "IF", keep_dims=True)
    IF_aet = pull(gp, "IF_aet", keep_dims=True)
    return LATT(
        latt=dres.latt,
        num=dres.num,
        denom=dres.den,
        IF=IF,
        IF_aet=IF_aet,
        g=pr.e,
        t=pr.t,
        ids=gp.select(dp.i_col, "E"),
        ns=subset.shape[0],
        extra=dres.extra,
    )


@dataclass
class BaseCheck:
    gt: int
    gpt: int
    ct: int
    cpt: int
    controls: dict[str, list[int]]
    pr: CohortTimePair


@dataclass
class NytCheck:
    ok: bool
    bc: BaseCheck
    msg: str = ""


def base_check(base: pl.DataFrame, pr: CohortTimePair, dp: IDidParams):
    t_col = dp.t_col
    E = pull(base, "E")
    C = pull(base, "C")
    t = pull(base, t_col)
    gt = ((E == 1) & (t == pr.t)).sum().item()
    gpt = ((E == 1) & (t == pr.pt)).sum().item()
    ct = ((C == 1) & (t == pr.t)).sum().item()
    cpt = ((C == 1) & (t == pr.pt)).sum().item()

    groups = pull(base, dp.e_col)
    controls = {
        "pt": sorted_unqs(groups[(C == 1) & (t == pr.pt)]).tolist(),
        "t": sorted_unqs(groups[(C == 1) & (t == pr.t)]).tolist(),
    }
    return BaseCheck(
        gt=gt,
        gpt=gpt,
        ct=ct,
        cpt=cpt,
        controls=controls,
        pr=pr,
    )


def check_nyt(base: pl.DataFrame, pr: CohortTimePair, dp: IDidParams):
    """Computes check for not yet treated case."""
    #  TODO: Refactor this
    cases = np.array(["gt", "gpt", "ct", "cpt"], dtype=str)
    bc = base_check(base, pr, dp)
    checks = np.array([bc.gt, bc.gpt, bc.ct, bc.cpt], dtype=int)
    failed = cases[checks == 0]
    if failed.size == 0:
        return NytCheck(ok=True, msg="", bc=bc)
    msg = ""
    for c in failed:
        match c:
            case "gt":
                msg = f"no treated units at t for  (pt, t)={(pr.pt, pr.t)} for g={pr.e}"

            case "gpt":
                msg = f"no treated units at pt for (pt, t)={(pr.pt, pr.t)} for g={pr.e}"

            case "ct":
                msg = f"no control units at t for  (pt, t)={(pr.pt, pr.t)} for g={pr.e}"

            case "cpt":
                msg = f"no control units at pt for (pt, t)={(pr.pt, pr.t)} for g={pr.e}"
            case _:
                raise ValueError(f"Invalid case {c}")
    return NytCheck(ok=False, msg=msg, bc=bc)


def compute_latt_et(dp: IDidParams, pr: CohortTimePair) -> LATT | FailedLATT:
    """Computes the ATT(g, t) for the given group-time pair.

    Selects the correct data and method based on the parameters.
    """
    match dp.method, dp.balanced:
        case method, True:
            return latt_et_panel(dp, pr, method=method)
        case method, False:
            # Unbalanced case is repeated cross-section
            return latt_et_rc(dp, pr, method=method)
        case _:
            raise ValueError(
                "Invalid control or method; "
                f"{dp.control=}, {dp.method=}, balanced={dp.balanced=}"
            )


@dataclass(repr=False)
class IDidResult(ReprMixin):
    """Result object returned by {py:func}`idid.estimate`.

    This is the main container for cell-level IDiD estimates. It stores the
    estimated $LATT(e, t)$ values, their standard errors, the underlying
    influence functions, and the estimation metadata needed for summaries and
    subsequent aggregation via {py:func}`idid.agg_latt`.

    The most important user-facing fields are:

    - `estimates`: a Polars data frame with one row per identified `(e, t)`
      cell
    - `dp`: the estimation parameters and original column mapping
    - `IFs`: influence functions for the LATT estimates
    - `IFs_aet`: influence functions for the corresponding first-stage / AET
      quantities
    """

    __repr_fields__ = (
        "n",
        "dp",
        "periods",
        "estimates",
        "IFs",
        "IFs_aet",
        "fail_msg",
    )

    estimates: pl.DataFrame
    dp: IDidParams
    n: int
    periods: Periods
    latts: LATTs
    units: pl.DataFrame
    IFs: np.ndarray
    IFs_aet: np.ndarray
    fail_msg: str = ""

    def summary(self, show_denom: bool = True):
        summarize_gt(self, show_denom=show_denom)


def get_gts_map(gr: np.ndarray, tr: np.ndarray, dp: IDidParams):
    """Constructs map of each group g to relevant time periods t."""
    gp = (
        dp.data.filter(
            pl.col(dp.e_col).is_in(gr),
            pl.col(dp.t_col).is_in(tr),
        )
        .group_by(dp.e_col)
        .agg(pl.col(dp.t_col).unique())
        .sort(dp.e_col)
    )
    gts_map = OrderedDict(
        {g: sorted(ts.to_list()) for g, ts in zip(gp[dp.e_col], gp[dp.t_col])}
    )
    return gts_map


def prep_periods(dp: IDidParams):
    gs = sorted_unqs(pull(dp.data, dp.e_col))
    ts = sorted_unqs(pull(dp.data, dp.t_col))
    t_min = ts.min()
    t_max = ts.max()
    # relevant groups; treated at some date that is not the first period
    gr = gs[(gs > 0) & (gs > t_min)]
    tr = ts[ts > t_min]  # Y_{t} - Y_{t-1} only defined for t > t_min.
    g_max = gr.max()
    any_never_treated = (gs == 0).any()
    if dp.control == "never" and not any_never_treated:
        raise ValueError(
            "No never-treated group found in data; "
            "set control='notyet' to allow for never-treated groups. "
            "We assume `e_col` equals 0 for the never-treated group"
        )
    if dp.control == "notyet" and not any_never_treated:
        # Don't compute ATT(g, t) for last treated group (is control group)
        # Also drop time periods with t >= max(G) as we have no c-group there
        gr = gr[gr < g_max]
        tr = tr[tr < g_max]
    gts_map = get_gts_map(gr, tr, dp)
    gts = sorted([(g, ts) for g, ts in gts_map.items()], key=lambda x: x[0])
    return Periods(
        gs=gs,
        ts=ts,
        t_min=t_min,
        t_max=t_max,
        gr=gr,
        tr=tr,
        gts=gts,
        gts_map=gts_map,
        g_max=g_max,
        any_never_treated=any_never_treated,
    )


@dataclass(repr=True)
class Periods:
    gs: np.ndarray
    ts: np.ndarray
    t_min: int
    t_max: int
    gr: np.ndarray
    tr: np.ndarray
    gts: list[tuple[int, list[int]]]
    g_max: int
    gts_map: dict[int, list[int]]
    any_never_treated: bool

    def csa_pairs(self):
        gts = list(it.product(self.gr.tolist(), self.tr.tolist()))
        return gts

    def total_gts(self):
        return sum(len(ts) for _, ts in self.gts)


def prep_data(dp: IDidParams, p: Periods) -> IDidParams:
    """Prepare data for estimation.

    Notes:
    - We map units ids to integers {0, 1, ..., n-1} for easy indexing
      using the map `units_map`.
    """
    dp.data = dp.data.with_columns(
        # map units to integers for easy indexing
        pl.col(dp.i_col).replace_strict(dp.units_map).alias(dp.i_col)
    )
    if dp.control == "notyet":
        if not p.any_never_treated:
            # filter out periods with t >= max(G) if no never-treated group
            dp.data = dp.data.filter(pl.col(dp.t_col).lt(p.g_max))
        dp.data = dp.data.with_columns(
            # groups with G larger than max(t) are considered never-treated.
            pl.when(pl.col(dp.e_col) > p.t_max)
            .then(pl.lit(0))
            .otherwise(pl.col(dp.e_col))
            .alias(dp.e_col)
        )
    # Sort once here; e.g. `get_base` assumes sorted data.
    dp.data = dp.data.sort(dp.i_col, dp.t_col)
    return dp


def get_pt_period(g: int, t: int) -> int:
    if g <= t:  # post-treatment period
        return g - 1
    return t - 1


def get_units(df: pl.DataFrame, i_col: str, g_col: str) -> pl.DataFrame:
    """Returns unique (id, E) pairs i.e. the units with exposre group."""
    return df.select(i_col, g_col).unique().sort(i_col)


def latt_et_all(dp: IDidParams) -> IDidResult:
    periods = prep_periods(dp)
    dp = prep_data(dp, periods)
    res: LATTs = OrderedDict()
    gts = [(g, ts) for g, ts in periods.gts_map.items()]
    with (
        tqdm(desc="Computing LATT(e, t)", total=sum(len(ts) for _, ts in gts))
        if dp.verbose
        else nullcontext() as pbar
    ):
        for e, ts in gts:
            for t in ts:
                if t >= e:
                    if pbar:
                        pbar.set_postfix_str(f"e={e}, t={t}")
                    latt_et = compute_latt_et(
                        dp,
                        CohortTimePair(e=e, t=t, pt=get_pt_period(e, t)),
                    )
                    res[(e, t)] = latt_et
                    if pbar:
                        pbar.update(1)

    IFs_aet = concat_ifs(dp, res, IF_name="IF_aet")  # AET IF
    IFs = concat_ifs(dp, res, IF_name="IF")  # LATT IFs
    ses = se_ifs(IFs)
    estimates = (
        get_res_ov(
            res,
            ses,
            e_col=dp.e_col,
            t_col=dp.t_col,
        )
        .with_columns(
            ns=pl.Series(
                [r.ns if isinstance(r, LATT) else None for r in res.values()]
            )
        )
        .with_columns(pl_ci("latt"))
    )
    return IDidResult(
        estimates=estimates,
        IFs=IFs,
        IFs_aet=IFs_aet,
        dp=dp,
        latts=res,
        units=get_units(dp.data, dp.i_col, dp.e_col),
        n=dp.n,
        periods=periods,
    )


def units_map(data: pl.DataFrame, i_col: str) -> dict[Any, int]:
    """Mapping from units to new index.

    To speed up indexing in IF.
    """
    units = data.select(pl.col(i_col).unique()).with_row_index(name="id_int")
    mapping = dict(zip(units[i_col], units["id_int"]))
    return mapping


def estimate(
    data: pl.DataFrame,
    outcome: str,
    cohort: str,
    time: str,
    unit: str,
    treatment: str,
    covariates: list[str] | None = None,
    balanced: bool = True,
    control: Control = "never",
    method: Method = "reg",
    dml_kwargs: DMLKwargs | None = None,
    num_kwargs: OutcomeRegressionKwargs | None = None,
    den_kwargs: OutcomeRegressionKwargs | None = None,
    verbose: bool = False,
) -> IDidResult:
    """Estimates the LATT(e, t) parameters.

    data:
        Input data in long format.

    outcome:
        Name of the outcome column.

    cohort:
        Name of the exposure-cohort column, usually `E`. This column records
        first exposure time. When `control="never"`, the never-exposed group
        must be coded as `0`, i.e. `E = 0`.

    time:
        Name of the time-period column.

    unit:
        Name of the unit identifier column.

    treatment:
        Name of the observed treatment column.

    covariates:
        Optional list of covariate column names used in nuisance estimation.
        If omitted, the estimators are fit without observed covariates.

    dml_kwargs:
        Extra kwargs passed to the DML estimators.

        Supported keys:
            - nfolds:
                Number of cross-fitting folds.
            - m_m:
                Outcome nuisance model.
            - g_m:
                Treatment nuisance model.
            - p_m:
                Propensity model for P(E = 1 | X).

    num_kwargs, den_kwargs:
        Extra kwargs passed to outcome-regression-style numerator and
        denominator estimators.

        Supported keys:
            - ns_est:
                Nuisance estimator used for the outcome-regression step.
                This controls how conditional means are fit.
            - use_levels:
                Panel only. If True, estimate post and pre levels separately
                and then difference them. If False, estimate the change
                outcome directly.

    Returns an {py:class}`IDidResult <idid.estimators.IDidResult>` object
    containing the cell-level estimates, standard errors, and influence
    functions used for aggregation and inference.

    This is the main entry point for the package.
    It computes the cohort-time local average treatment effects on the treated
    for all identified `(e, t)` pairs under either:

    - balanced panel data (`balanced=True`)
    - repeated cross-sections (`balanced=False`)

    The estimator is selected through `method`, for example:

    - `"dr"`: doubly robust
    - `"dml"`: double machine learning
    - `"reg"`: outcome regression
    - `"ipw"` / `"std_ipw"`: inverse-probability weighting variants

    """
    if den_kwargs is None and method in {"dr", "check", "imp"}:
        den_kwargs = {
            "ns_est": nuisance_estimators.logit_oreg,
            "use_levels": True,
        }
    if control == "never":
        groups = set(
            data.select(pl.col(cohort).drop_nulls().unique())
            .get_column(cohort)
            .to_list()
        )
        if 0 not in groups:
            found = sorted(groups)
            raise ValueError(
                "control='never' requires a never-exposed cohort coded as 0 "
                f"in column '{cohort}'. Found cohorts: {found}"
            )
    return latt_et_all(
        IDidParams(
            data=data,
            e_col=cohort,
            t_col=time,
            d_col=treatment,
            y_col=outcome,
            i_col=unit,
            covariates=covariates,
            n=data.select(pl.col(unit).n_unique()).item(),
            balanced=balanced,
            control=control,
            method=method,
            dml_kwargs=dml_kwargs,
            num_kwargs=num_kwargs,
            den_kwargs=den_kwargs,
            data_orig=data.select(cohort, time, outcome, unit).clone(),
            verbose=verbose,
            units_map=units_map(data, unit),
        )
    )


def get_controls(latt: LATT, res: IDidResult) -> pl.DataFrame:
    """Return the control units used for a given cell-level LATT estimate.

    This helper maps the internal unit ids stored on `latt.ids` back to the
    original unit ids of the input data and returns the control units together
    with their exposure cohort.
    """
    return (
        res.dp.data_orig.select(res.dp.i_col, res.dp.e_col)
        .unique()
        .join(
            latt.ids.filter(
                # NOTE: E is a binary indicator with E = 0 meaning control
                # (also in the not-yet-exposed case)
                pl.col("E").eq(0)
            ).select(
                pl.col(res.dp.i_col).replace_strict(
                    {v: k for k, v in res.dp.units_map.items()}
                )
            ),
            how="inner",
            on=res.dp.i_col,
        )
    )


def se_if_np(IF: np.ndarray, N: int | None = None):
    if N is None:
        N = IF.shape[0]
    return np.sqrt((IF * IF / N).sum() / N)


def se_ifs(IFs: np.ndarray):
    nc = IFs.shape[1]
    return np.array([se_if_np(IFs[:, i]).item() for i in range(nc)])


# NOTE: misc helpers


def _get_subsets(dp: IDidParams):
    """gets subsets"""

    periods = prep_periods(dp)
    dp = prep_data(dp, periods)
    gts = [(g, ts) for g, ts in periods.gts_map.items()]
    subsets = dict()
    for g, ts in gts:
        for t in ts:
            pr = CohortTimePair(e=g, t=t, pt=get_pt_period(g, t))
            subset = subset_data(dp, pr)

            G = pull(subset, "G", keep_dims=True)
            X = dridid.get_xmat(subset, covariates=dp.covariates)

            orp = ParamsPanel(
                subset=subset,
                X=X,
                E=G,
                dY=pull(subset, "dY", keep_dims=True),
                dD=pull(subset, "dD", keep_dims=True),
                Y1=pull(subset, dp.y_col, keep_dims=True),
                Y0=(
                    pull(subset, dp.y_col, keep_dims=True)
                    - pull(subset, "dY", keep_dims=True)
                ),
                D1=pull(subset, dp.d_col, keep_dims=True),
                D0=(
                    pull(subset, dp.d_col, keep_dims=True)
                    - pull(subset, "dD", keep_dims=True)
                ),
            )
            subsets[(g, t)] = orp
    return subsets


def get_subsets(
    data: pl.DataFrame,
    outcome: str,
    group: str,
    time: str,
    unit: str,
    treatment: str,
    covariates: list[str] | None = None,
    balanced: bool = True,
    control: Control = "never",
    method: Method = "reg",
    num_kwargs: OutcomeRegressionKwargs | None = None,
    den_kwargs: OutcomeRegressionKwargs | None = None,
    verbose: bool = True,
) -> dict[str, ParamsPanel]:
    data = data.with_columns(K=pl.col(time) - pl.col(group))
    return _get_subsets(
        IDidParams(
            data=data,
            e_col=group,
            t_col=time,
            d_col=treatment,
            y_col=outcome,
            i_col=unit,
            covariates=covariates,
            n=data.select(pl.col(unit).n_unique()).item(),
            balanced=balanced,
            control=control,
            method=method,
            num_kwargs=num_kwargs,
            den_kwargs=den_kwargs,
            data_orig=data.select(group, time, outcome, unit).clone(),
            verbose=verbose,
            units_map=units_map(data, unit),
        )
    )


@overload
def _get_params_period(
    pr: CohortTimePair,
    data: pl.DataFrame,
    outcome: str,
    cohort: str,
    time: str,
    unit: str,
    treatment: str,
    covariates: list[str] | None = None,
    *,
    balanced: Literal[True],
    control: Control = "never",
    method: Method = "reg",
    num_kwargs: OutcomeRegressionKwargs | None = None,
    den_kwargs: OutcomeRegressionKwargs | None = None,
    verbose: bool = True,
) -> tuple[ParamsPanel, IDidParams]: ...


@overload
def _get_params_period(
    pr: CohortTimePair,
    data: pl.DataFrame,
    outcome: str,
    cohort: str,
    time: str,
    unit: str,
    treatment: str,
    covariates: list[str] | None = None,
    *,
    balanced: Literal[False],
    control: Control = "never",
    method: Method = "reg",
    num_kwargs: OutcomeRegressionKwargs | None = None,
    den_kwargs: OutcomeRegressionKwargs | None = None,
    verbose: bool = True,
) -> tuple[ParamsRc, IDidParams]: ...


def _get_params_period(
    pr: CohortTimePair,
    data: pl.DataFrame,
    outcome: str,
    cohort: str,
    time: str,
    unit: str,
    treatment: str,
    covariates: list[str] | None = None,
    balanced: bool = True,
    control: Control = "never",
    method: Method = "reg",
    num_kwargs: OutcomeRegressionKwargs | None = None,
    den_kwargs: OutcomeRegressionKwargs | None = None,
    verbose: bool = True,
) -> tuple[ParamsPanel | ParamsRc, IDidParams]:
    data = data.with_columns(K=pl.col(time) - pl.col(cohort))
    dp = IDidParams(
        data=data,
        e_col=cohort,
        t_col=time,
        d_col=treatment,
        y_col=outcome,
        i_col=unit,
        covariates=covariates,
        n=data.select(pl.col(unit).n_unique()).item(),
        balanced=balanced,
        control=control,
        method=method,
        num_kwargs=num_kwargs,
        den_kwargs=den_kwargs,
        data_orig=data.select(cohort, time, outcome, unit).clone(),
        verbose=verbose,
        units_map=units_map(data, unit),
    )
    subset = subset_data(dp, pr)
    if balanced:
        pars = ParamsPanel(
            subset=subset,
            X=dridid.get_xmat(subset, covariates=dp.covariates),
            E=pull(subset, "E", keep_dims=True),
            dY=pull(subset, "dY", keep_dims=True),
            dD=pull(subset, "dD", keep_dims=True),
            Y1=pull(subset, dp.y_col, keep_dims=True),
            Y0=(
                pull(subset, dp.y_col, keep_dims=True)
                - pull(subset, "dY", keep_dims=True)
            ),
            D1=pull(subset, dp.d_col, keep_dims=True),
            D0=(
                pull(subset, dp.d_col, keep_dims=True)
                - pull(subset, "dD", keep_dims=True)
            ),
        )
    else:
        pars = ParamsRc(
            subset=subset,
            X=dridid.get_xmat(subset, covariates=dp.covariates),
            Y=pull(subset, dp.y_col, keep_dims=True),
            D=pull(subset, dp.d_col, keep_dims=True),
            T=(pull(subset, dp.t_col, keep_dims=True) == pr.t),
            E=pull(subset, "E", keep_dims=True),
        )
    return pars, dp


def latt_simple(dp: IDidParams, pp: ParamsPanel, gtp: CohortTimePair):
    """Miyaji no covariates estimator."""
    from idid.dridid import DrIDiDRes

    subset = pp.subset
    E, dY, dD = pulls(subset, cols="E dY dD".split(" "), keep_dims=False)

    if (E == 0).all():
        raise ValueError(f"No one in group {gtp.e}")
    elif (E == 1).all():
        if dp.verbose:
            print(f"No controls for group {gtp.e} in period {gtp.t}")
        return FailedLATT(
            latt=np.nan, num=np.nan, denom=np.nan, g=gtp.e, t=gtp.t
        )

    # num individuals in panel
    n = dp.n

    # clatt
    # mean over subsample ok as denominator
    alpha1 = dY[E == 1].mean()
    alpha0 = dY[E == 0].mean()
    pi1 = dD[E == 1].mean()
    pi0 = dD[E == 0].mean()
    num = alpha1 - alpha0
    denom = pi1 - pi0
    clatt = num / denom

    C = E == 0
    gp = E.sum() / n
    cp = (E == 0).sum() / n
    delta = dY - dD * clatt
    if1 = E * (delta - (E * delta / E.mean()).mean()) / gp
    if2 = (E == 0) * (delta - (C * delta / C.mean()).mean()) / cp
    IF = (1 / denom) * (if1 - if2)
    if1d = E * (dD - pi1) / gp
    if2d = (E == 0) * (dD - pi0) / cp
    IF_aet = if1d - if2d  # IF for CAET
    return DrIDiDRes(
        latt=clatt,
        se=se_if_np(IF),
        IF=IF,
        num=num,
        den=denom,
        IF_num=if1,
        IF_den=IF_aet,
    )
