from pathlib import Path
from typing import TYPE_CHECKING, Any

import numpy as np
import polars as pl
import seaborn as sns
from matplotlib import pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import MaxNLocator

if TYPE_CHECKING:
    from collections.abc import Sequence

    from idid.aggregate import AggLattResult

title_map = {
    "D_t": r"$D_t$",
    "Y_t": r"$Y_t$",
}


def _agg_x_col(res: "AggLattResult") -> str:
    x_candidates = [
        "k",
        "l",
        res.params.dp.t_col,
        res.params.dp.e_col,
        "effect",
        "cohort",
        "group",
    ]
    x_col = next(
        (col for col in x_candidates if col in res.estimates.columns), None
    )
    if x_col is None:
        raise ValueError(
            f"Could not infer x-axis column from {res.estimates.columns}"
        )
    return x_col


def _agg_label(res: "AggLattResult", idx: int) -> str:
    method = res.method.replace("_", " ").title()
    if res.boot is not None:
        return f"{method} (boot)"
    if idx == 0:
        return method
    return f"{method} {idx + 1}"


def _ordered_estimates(res: "AggLattResult", x_col: str) -> pl.DataFrame:
    if res.method == "cohort_custom":
        return res.estimates
    return res.estimates.sort(x_col)


def _as_axis_values(values: list[Any]) -> tuple[np.ndarray, list[str] | None]:
    if all(
        isinstance(v, (int, float, np.integer, np.floating)) for v in values
    ):
        return np.asarray(values, dtype=float), None
    labels = [str(v) for v in values]
    return np.arange(len(labels), dtype=float), labels


def plot_agg(
    results: "Sequence[AggLattResult]",
    *,
    labels: "Sequence[str] | None" = None,
    ax: Any | None = None,
    fig_path: str | None = None,
    title: str | None = None,
    xlabel: str | None = None,
    ylabel: str = "Estimate",
    colors: "Sequence[str] | None" = None,
) -> tuple[Any, Any]:
    """Plot one or several aggregate IDiD results on a shared axis.

    This is the main plotting helper for {py:class}`idid.aggregate.AggLattResult`.
    It is intended for event-study style displays of dynamic effects, but it
    also handles cohort, calendar, cumulative, and simple aggregations.

    When multiple results are supplied, the function checks that they share the
    same x-axis support and then offsets the point estimates slightly so the
    confidence bars remain readable.
    """
    if len(results) == 0:
        raise ValueError("Need at least one aggregation result to plot")

    base = results[0]
    if base.estimates.is_empty():
        raise ValueError("Cannot plot empty aggregation result")

    x_col = _agg_x_col(base)
    x_ref_vals = (
        _ordered_estimates(base, x_col).select(x_col).to_series().to_list()
    )
    x_ref, x_ticklabels = _as_axis_values(x_ref_vals)

    for res in results[1:]:
        if res.estimates.is_empty():
            raise ValueError("Cannot plot empty aggregation result")
        x_other_col = _agg_x_col(res)
        if x_other_col != x_col:
            raise ValueError(
                "All aggregation results must use the same x-axis variable"
            )
        x_other_vals = (
            _ordered_estimates(res, x_col).select(x_col).to_series().to_list()
        )
        if x_ref_vals != x_other_vals:
            raise ValueError(
                "All aggregation results must have the same x-axis support"
            )

    if labels is not None and len(labels) != len(results):
        raise ValueError("labels must match the number of results")
    if colors is not None and len(colors) != len(results):
        raise ValueError("colors must match the number of results")

    created_fig = False
    if ax is None:
        fig, ax = plt.subplots(figsize=(6.4, 4.2))
        created_fig = True
    else:
        fig = ax.figure

    if colors is None:
        colors = sns.color_palette("colorblind", n_colors=len(results))
    if labels is None:
        labels = [_agg_label(res, i) for i, res in enumerate(results)]

    offsets = (
        np.linspace(-0.12, 0.12, len(results)) if len(results) > 1 else [0.0]
    )
    show_legend = len(set(labels)) > 1

    for offset, color, label, res in zip(
        offsets, colors, labels, results, strict=True
    ):
        pdf = _ordered_estimates(res, x_col).to_pandas()
        x = x_ref + offset
        y = pdf["latt"].to_numpy(dtype=float)
        lower = pdf["lower"].to_numpy(dtype=float)
        upper = pdf["upper"].to_numpy(dtype=float)
        yerr = np.vstack((y - lower, upper - y))
        ax.errorbar(
            x,
            y,
            yerr=yerr,
            fmt="o",
            color=color,
            ecolor=color,
            elinewidth=1.2,
            capsize=3,
            markersize=5.5,
            label=label,
        )

    ax.axhline(0, color="0.35", linewidth=0.8, linestyle="--", zorder=0)
    ax.set_xlabel(
        xlabel
        or {
            "k": "Event time",
            "l": "Event time",
            base.params.dp.t_col: "Time",
            base.params.dp.e_col: "Cohort",
            "effect": "",
            "cohort": "Cohort",
        }.get(x_col, x_col)
    )
    ax.set_ylabel(ylabel)
    ax.set_title(title or f"{base.method.replace('_', ' ').title()} effects")
    ax.grid(alpha=0.25)
    if x_ticklabels is None:
        ax.xaxis.set_major_locator(MaxNLocator(integer=True))
    else:
        ax.set_xticks(x_ref)
        ax.set_xticklabels(x_ticklabels)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)

    if show_legend:
        ax.legend(
            loc="upper center",
            bbox_to_anchor=(0.5, -0.18),
            frameon=False,
            borderaxespad=0.0,
            ncols=min(len(results), 3),
        )

    if created_fig:
        fig.tight_layout(rect=(0, 0.12 if show_legend else 0, 1, 1))
    elif show_legend:
        fig.tight_layout(rect=(0, 0.12, 1, 1))
    if fig_path is not None:
        Path(fig_path).parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(fig_path, dpi=300, bbox_inches="tight")

    return fig, ax


def plot_evolution(
    gp: pl.DataFrame,
    fig_path: str = "output/evolution.png",
    group_col: str = "E",
    time_col: str = "t",
    treatment_col: str = "D_t",
    outcome_col: str = "Y_t",
    include_bands: bool = False,
    z: float = 1.96,
):
    """Plot mean treatment and outcome evolution by exposure cohort."""
    plot_df = gp.sort(group_col, time_col).to_pandas()
    cohorts = sorted(plot_df[group_col].unique())
    palette = sns.color_palette("colorblind", n_colors=len(cohorts))

    fig, axes = plt.subplots(1, 2, figsize=(10, 4), sharex=True)
    for ax, col, ylabel in zip(
        axes,
        [treatment_col, outcome_col],
        ["Average Treatment", "Average Outcome"],
        strict=True,
    ):
        se_col = f"{col}_se"
        for cohort, color in zip(cohorts, palette, strict=True):
            sdf = plot_df.loc[plot_df[group_col] == cohort].sort_values(
                time_col
            )
            ax.plot(
                sdf[time_col],
                sdf[col],
                marker="o",
                linewidth=2,
                color=color,
                label=str(cohort),
            )
            if include_bands and se_col in sdf:
                lower = sdf[col] - z * sdf[se_col]
                upper = sdf[col] + z * sdf[se_col]
                ax.fill_between(
                    sdf[time_col],
                    lower,
                    upper,
                    color=color,
                    alpha=0.15,
                    linewidth=0,
                )
        ax.set_xlabel("Time")
        ax.set_ylabel(ylabel)
        ax.set_title(title_map.get(col, col))
        ax.grid(alpha=0.25)
        sns.despine(ax=ax)

    handles, labels = axes[0].get_legend_handles_labels()
    for ax in axes:
        legend = ax.get_legend()
        if legend is not None:
            legend.remove()
    fig.legend(
        handles,
        labels,
        title=group_col,
        loc="center left",
        bbox_to_anchor=(0.89, 0.5),
        frameon=False,
        borderaxespad=0.2,
        handlelength=1.6,
    )
    fig.tight_layout(rect=(0, 0, 0.9, 1))
    if fig_path:
        Path(fig_path).parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(fig_path, dpi=300, bbox_inches="tight")
        plt.close(fig)
    return fig, ax


def plot_evolution_groups(
    gp0: pl.DataFrame,
    gp1: pl.DataFrame,
    fig_path: str | None = None,
    group_col: str = "E",
    time_col: str = "t",
    treatment_col: str = "D_t",
    outcome_col: str = "Y_t",
    include_bands: bool = False,
    z: float = 1.96,
    labels: tuple[str, str] = ("Group 0", "Group 1"),
):
    """Plot group-specific evolutions on shared axes."""
    g0 = gp0.sort(group_col, time_col).to_pandas()
    g1 = gp1.sort(group_col, time_col).to_pandas()
    cohorts = sorted(set(g0[group_col].unique()) | set(g1[group_col].unique()))
    palette = sns.color_palette("colorblind", n_colors=len(cohorts))
    color_map = dict(zip(cohorts, palette, strict=True))

    fig, axes = plt.subplots(1, 2, figsize=(10.5, 4), sharex=True)
    panel_specs = [
        (axes[0], treatment_col, "Average Treatment"),
        (axes[1], outcome_col, "Average Outcome"),
    ]
    line_specs = [
        (g0, "--", labels[0]),
        (g1, "-", labels[1]),
    ]

    for ax, col, ylabel in panel_specs:
        se_col = f"{col}_se"
        for pdf, linestyle, _ in line_specs:
            for cohort in cohorts:
                sdf = pdf.loc[pdf[group_col] == cohort].sort_values(time_col)
                if sdf.empty:
                    continue
                ax.plot(
                    sdf[time_col],
                    sdf[col],
                    marker="o",
                    linewidth=2,
                    linestyle=linestyle,
                    color=color_map[cohort],
                )
                if include_bands and se_col in sdf:
                    lower = sdf[col] - z * sdf[se_col]
                    upper = sdf[col] + z * sdf[se_col]
                    ax.fill_between(
                        sdf[time_col],
                        lower,
                        upper,
                        color=color_map[cohort],
                        alpha=0.08,
                        linewidth=0,
                    )
        ax.set_xlabel("Time")
        ax.set_ylabel(ylabel)
        ax.set_title(title_map.get(col, col))
        ax.grid(alpha=0.25)
        sns.despine(ax=ax)

    cohort_handles = [
        Line2D(
            [0],
            [0],
            color=color_map[cohort],
            marker="o",
            linewidth=2,
            linestyle="-",
            label=f"E={cohort}",
        )
        for cohort in cohorts
    ]
    group_handles = [
        Line2D(
            [0],
            [0],
            color="black",
            linewidth=2.4,
            linestyle=linestyle,
            label=glabel,
        )
        for _, linestyle, glabel in line_specs
    ]
    cohort_legend = fig.legend(
        cohort_handles,
        [h.get_label() for h in cohort_handles],
        title="Cohort",
        loc="upper center",
        bbox_to_anchor=(0.43, -0.02),
        frameon=False,
        ncols=min(len(cohort_handles), 4),
        fontsize=9,
    )
    group_legend = fig.legend(
        group_handles,
        [h.get_label() for h in group_handles],
        title="Group",
        loc="upper center",
        bbox_to_anchor=(0.72, -0.02),
        frameon=False,
        ncols=len(group_handles),
        fontsize=9,
    )
    fig.add_artist(cohort_legend)
    fig.add_artist(group_legend)
    fig.tight_layout(rect=(0, 0.02, 1, 1))
    if fig_path:
        Path(fig_path).parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(fig_path, dpi=300, bbox_inches="tight")
    return fig, ax


def summarize_evolution(df: pl.DataFrame) -> pl.DataFrame:
    """Compute group-time means and standard errors for D_t and Y_t."""
    return df.group_by("E", "t").agg(
        pl.col("D_t").mean(),
        pl.col("Y_t").mean(),
        pl.col("D_t").std().truediv(pl.len().sqrt()).alias("D_t_se"),
        pl.col("Y_t").std().truediv(pl.len().sqrt()).alias("Y_t_se"),
    )


def plot_evolution_panel_rc(
    gp_panel: pl.DataFrame,
    gp_rc: pl.DataFrame,
    fig_path: str = "output/evolution.png",
    group_col: str = "E",
    time_col: str = "t",
    treatment_col: str = "D_t",
    outcome_col: str = "Y_t",
    include_bands: bool = True,
    z: float = 1.96,
) -> None:
    """Plot panel above repeated cross-section evolution with one legend."""
    plot_df = (
        pl.concat(
            [
                gp_panel.with_columns(kind=pl.lit("Panel")),
                gp_rc.with_columns(kind=pl.lit("Repeated cross-sections")),
            ]
        )
        .sort("kind", group_col, time_col)
        .to_pandas()
    )
    cohorts = sorted(plot_df[group_col].unique())
    palette = sns.color_palette("colorblind", n_colors=len(cohorts))
    color_map = dict(zip(cohorts, palette))

    fig, axes = plt.subplots(
        2,
        2,
        figsize=(10, 7),
        sharex=True,
        sharey="col",
    )
    panels = [
        ("Panel", treatment_col, "Average Treatment"),
        ("Panel", outcome_col, "Average Outcome"),
        ("Repeated cross-sections", treatment_col, "Average Treatment"),
        ("Repeated cross-sections", outcome_col, "Average Outcome"),
    ]

    for ax, (kind, col, ylabel) in zip(axes.ravel(), panels, strict=True):
        se_col = f"{col}_se"
        ss = plot_df.loc[plot_df["kind"] == kind]
        for cohort in cohorts:
            sdf = ss.loc[ss[group_col] == cohort].sort_values(time_col)
            if sdf.empty:
                continue
            ax.plot(
                sdf[time_col],
                sdf[col],
                marker="o",
                linewidth=2,
                color=color_map[cohort],
                label=str(cohort),
            )
            if include_bands and se_col in sdf:
                lower = sdf[col] - z * sdf[se_col]
                upper = sdf[col] + z * sdf[se_col]
                ax.fill_between(
                    sdf[time_col],
                    lower,
                    upper,
                    color=color_map[cohort],
                    alpha=0.15,
                    linewidth=0,
                )
        ax.set_xlabel("Time")
        ax.set_ylabel(ylabel)
        ax.xaxis.set_major_locator(MaxNLocator(integer=True))
        ax.grid(alpha=0.25)
        sns.despine(ax=ax)

    axes[0, 0].set_title(title_map.get(treatment_col, treatment_col))
    axes[0, 1].set_title(title_map.get(outcome_col, outcome_col))
    axes[0, 0].text(
        -0.18,
        0.5,
        "Panel",
        transform=axes[0, 0].transAxes,
        rotation=90,
        va="center",
        ha="center",
        fontweight="bold",
    )
    axes[1, 0].text(
        -0.18,
        0.5,
        "Repeated cross-sections",
        transform=axes[1, 0].transAxes,
        rotation=90,
        va="center",
        ha="center",
        fontweight="bold",
    )

    handles, labels = axes[0, 0].get_legend_handles_labels()
    fig.legend(
        handles,
        labels,
        title=group_col,
        loc="center right",
        frameon=False,
    )
    fig.tight_layout(rect=(0, 0, 0.95, 1))
    Path(fig_path).parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(fig_path, dpi=300, bbox_inches="tight")
    plt.close(fig)
