"""
Module to compute multiplier bootstrap.

Taken from:
    https://github.com/jsr-p/csa-py/blob/main/src/csa/multiplier.py
"""

from dataclasses import dataclass

import numpy as np
import polars as pl
import scipy as sp


def qnorm(p: float):
    # Percent point function (inverse of cdf - percentiles).
    return sp.stats.norm.ppf(p)


def to_arr(val):
    return pl.DataFrame(val).to_numpy()


def rademacher(n: int):
    kappa = (np.sqrt(5) + 1) / 2
    return np.random.choice(
        [kappa, 1 - kappa],
        size=n,
        p=[1 - kappa / np.sqrt(5), kappa / np.sqrt(5)],
    )


def bstrap_ov(mb: "MBootRes", atts: np.ndarray) -> pl.DataFrame:
    return (
        pl.DataFrame({"latt": atts})
        .with_columns(se=pl.Series(mb.se), c=mb.c)
        .with_columns(
            lower=pl.col("latt") - pl.col("se") * pl.col("c"),
            upper=pl.col("latt") + pl.col("se") * pl.col("c"),
        )
        .drop("c")
    )


overview = bstrap_ov


@dataclass(repr=False)
class MBootRes:
    bres: np.ndarray
    V: np.ndarray
    se: np.ndarray
    c: float


def mult_boot(IF: np.ndarray, B: int):
    r"""
    Multiplier bootstrap.

    The rademacher are drawn directly from bernoulli using `kappa` value in CSA.

    scaling by $\sqrt{n}$ yields
    $\sqrt{n}(ATT^{*}_{t \geq (g - \delta)} - \hat{ATT}_{t \geq (g - \delta)})$
    which is is approximately normal with covariance $\Sigma$.
    """
    n, k = IF.shape
    bres_sim = np.zeros(shape=(B, k))
    for b in range(B):
        V = rademacher(n)
        bres_sim[b] = V @ IF  # Inner product each col of IF with V
    bres_sim = bres_sim / n  # E_n [V * IF]
    return np.sqrt(n) * bres_sim


def compute_b_sigma(bres: np.ndarray):
    """Computes \\hat{\\Sigma}^{1/2}(g, t)"""
    qdiff = np.quantile(bres, q=0.75, axis=0) - np.quantile(
        bres, q=0.25, axis=0
    )
    b_sigma = qdiff / (qnorm(0.75) - qnorm(0.25))
    return b_sigma


def bstrap(
    IF: np.ndarray,
    B: int = 1000,
    alpha: float = 0.05,
) -> MBootRes:
    n = IF.shape[0]
    bres = mult_boot(IF, B)
    V = np.cov(bres, rowvar=False)
    b_sigma = compute_b_sigma(bres)
    b_t = np.abs(bres / b_sigma[None, :]).max(axis=1)
    crit_val = np.quantile(b_t, q=1 - alpha).item()
    se = b_sigma / np.sqrt(n)
    if crit_val >= 7:
        print(
            "Simultaneous critical value is arguably `too large' to be"
            "realible. This usually happens when number of observations per"
            "group is small and/or there is not much variation in outcomes."
        )

    return MBootRes(bres, V, se, crit_val)


boot = bstrap
