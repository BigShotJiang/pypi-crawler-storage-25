"""
DML estimators for IDiD.
"""

from __future__ import annotations

from functools import partial
from typing import (
    Callable,
    Iterable,
    Literal,
)

import numpy as np
from sklearn.base import clone
from sklearn.dummy import DummyRegressor
from sklearn.model_selection import StratifiedKFold, cross_val_predict

from idid._types import (
    BoolArray,
    FloatArray,
    IntArray,
    OutcomeModel,
    TreatmentModel,
)
from idid.dridid import DrIDiDRes

__all__ = ["latt_dml_panel", "latt_dml_rc"]


def _model_name(model: object) -> str:
    return type(model).__name__


def _crossfit_subset_predict(
    model,
    X: FloatArray,
    y: FloatArray,
    cv_splits: Iterable[tuple[IntArray, IntArray]],
    train_mask_fn: Callable[[IntArray], BoolArray],
    *,
    method: Literal["predict", "predict_proba"] = "predict",
) -> FloatArray:
    """Out-of-fold predictions after training on a subset of each train fold."""
    out = np.empty_like(y, dtype=float)

    for I_train, I_test in cv_splits:
        mask = train_mask_fn(I_train)
        est = clone(model)
        est.fit(X[I_train][mask], y[I_train][mask])

        if method == "predict":
            out[I_test] = est.predict(X[I_test])
        else:
            out[I_test] = est.predict_proba(X[I_test])[:, 1]

    return out


def _group_mask(
    E: FloatArray,
    e: int,
) -> Callable[[IntArray], BoolArray]:
    return lambda I: E[I] == e


def latt_dml_panel(
    X: FloatArray,
    E: FloatArray,
    dY: FloatArray,
    D0: FloatArray,
    D1: FloatArray,
    m_m: OutcomeModel,
    g_m: TreatmentModel,
    p_m: TreatmentModel,
    *,
    eps: float = 0.01,
    nfolds: int = 5,
) -> DrIDiDRes:
    """Double Machine-Learning Estimator.

    As implemented in:
        Raaschou-Pedersen, J. S. (2026).
        Doubly Robust Instrumented Difference-in-Differences.
        Unpublished manuscript (May 2026).
    """
    E = np.ravel(E)
    dY = np.ravel(dY)
    D0 = np.ravel(D0)
    D1 = np.ravel(D1)
    n = dY.shape[0]

    if nfolds == 1:
        # no cross-fitting
        cv_splits = [(np.arange(n), np.arange(n))]
    else:
        cv = StratifiedKFold(n_splits=nfolds, shuffle=True, random_state=1234)
        cv_splits = list(cv.split(X, E))

    phat = cross_val_predict(p_m, X, E, cv=cv_splits, method="predict_proba")[
        :, 1
    ]
    phat = np.clip(phat, eps, 1 - eps)
    rhohat = cross_val_predict(DummyRegressor(), X, E, cv=cv_splits)

    gm = partial(_group_mask, E)

    # E[ΔY | X, E = 0]
    dYhat = _crossfit_subset_predict(
        m_m, X, dY, cv_splits, gm(0), method="predict"
    )
    # E[D1 | X, E = 0], E[D0 | X, E = 0]
    g1hat = _crossfit_subset_predict(
        g_m, X, D1, cv_splits, gm(0), method="predict_proba"
    )
    g0hat = _crossfit_subset_predict(
        g_m, X, D0, cv_splits, gm(0), method="predict_proba"
    )
    dDhat = g1hat - g0hat

    w_t = E / rhohat.mean()
    w_c = phat * (1 - E) / (1 - phat)
    w_c = w_c / w_c.mean()

    dD = D1 - D0
    psi_b = (w_t - w_c) * (dY - dYhat)
    psi_a = (w_t - w_c) * (dD - dDhat)
    num = psi_b.mean()
    den = psi_a.mean()
    tau = num / den
    varphi = (psi_b - tau * psi_a) / den
    var = np.mean(np.square(varphi))
    se = np.sqrt(var / n)

    return DrIDiDRes(
        latt=tau,
        se=se,
        num=num,
        den=den,
        IF=varphi,
        IF_num=psi_b,
        IF_den=psi_a,
        extra={
            "nfolds": nfolds,
            "m_m": _model_name(m_m),
            "g_m": _model_name(g_m),
            "p_m": _model_name(p_m),
        },
    )


def _cell_mask_rc(
    E: FloatArray,
    T: FloatArray,
    e: int,
    t: int,
) -> Callable[[IntArray], BoolArray]:
    return lambda I: (E[I] == e) & (T[I] == t)


def latt_dml_rc(
    X: FloatArray,
    E: FloatArray,
    T: FloatArray,
    Y: FloatArray,
    D: FloatArray,
    m_m: OutcomeModel,
    g_m: TreatmentModel,
    p_m: TreatmentModel,
    *,
    eps: float = 0.01,
    nfolds: int = 5,
) -> DrIDiDRes:
    """Double Machine-Learning Estimator.

    As implemented in:
        Raaschou-Pedersen, J. S. (2026).
        Doubly Robust Instrumented Difference-in-Differences.
        Unpublished manuscript (May 2026).
    """
    E = np.ravel(E)
    T = np.ravel(T)
    Y = np.ravel(Y)
    D = np.ravel(D)
    n = Y.shape[0]

    # stratify on treatment and period indicators
    if nfolds == 1:
        # no cross-fitting
        cvs = [(np.arange(n), np.arange(n))]
    else:
        strata = 2 * E.astype(int) + T.astype(int)
        cv = StratifiedKFold(n_splits=nfolds, shuffle=True, random_state=1234)
        cvs = list(cv.split(X, strata))

    # propensity score P(E = 1 | X)
    phat = cross_val_predict(p_m, X, E, cv=cvs, method="predict_proba")[:, 1]
    phat = np.clip(phat, eps, 1 - eps)

    # marginal probability P(E = 1)
    rhohat = cross_val_predict(DummyRegressor(), X, E, cv=cvs)

    # mean functions numerator:
    # E[Y | X, E = 1, T = 1], E[Y | X, E = 1, T = 0],
    # E[Y | X, E = 0, T = 1], E[Y | X, E = 0, T = 0]
    cm = partial(_cell_mask_rc, E, T)
    m_t_post = _crossfit_subset_predict(m_m, X, Y, cvs, cm(1, 1))
    m_t_pre = _crossfit_subset_predict(m_m, X, Y, cvs, cm(1, 0))
    m_c_post = _crossfit_subset_predict(m_m, X, Y, cvs, cm(0, 1))
    m_c_pre = _crossfit_subset_predict(m_m, X, Y, cvs, cm(0, 0))
    # mean functions denominator:
    # E[D | X, E = 1, T = 1], E[D | X, E = 1, T = 0],
    # E[D | X, E = 0, T = 1], E[D | X, E = 0, T = 0]
    g_t_post = _crossfit_subset_predict(
        g_m, X, D, cvs, cm(1, 1), method="predict_proba"
    )
    g_t_pre = _crossfit_subset_predict(
        g_m, X, D, cvs, cm(1, 0), method="predict_proba"
    )
    g_c_post = _crossfit_subset_predict(
        g_m, X, D, cvs, cm(0, 1), method="predict_proba"
    )
    g_c_pre = _crossfit_subset_predict(
        g_m, X, D, cvs, cm(0, 0), method="predict_proba"
    )

    # weights
    w_t_pre = (E * (1 - T)).astype(float)
    w_t_post = (E * T).astype(float)
    w_t_pre /= w_t_pre.mean()
    w_t_post /= w_t_post.mean()
    # w_{0, t}^{rc}
    w_c_pre = phat * (1 - E) * (1 - T) / (1 - phat)
    w_c_post = phat * (1 - E) * T / (1 - phat)
    w_c_pre /= w_c_pre.mean()
    w_c_post /= w_c_post.mean()

    w_t = w_t_post - w_t_pre
    w_c = w_c_post - w_c_pre
    w_t_p = E / rhohat.mean()  # treated weights panel

    # joint mean functions
    m_t = T * m_t_post + (1 - T) * m_t_pre
    m_c = T * m_c_post + (1 - T) * m_c_pre
    g_t = T * g_t_post + (1 - T) * g_t_pre
    g_c = T * g_c_post + (1 - T) * g_c_pre

    psi_b1 = w_t * (Y - m_t) - w_c * (Y - m_c)
    psi_b2 = w_t_p * (m_t_post - m_t_pre - (m_c_post - m_c_pre))
    psi_b = psi_b1 + psi_b2

    psi_a1 = w_t * (D - g_t) - w_c * (D - g_c)
    psi_a2 = w_t_p * (g_t_post - g_t_pre - (g_c_post - g_c_pre))
    psi_a = psi_a1 + psi_a2

    num = psi_b.mean()
    den = psi_a.mean()
    tau = num / den
    varphi = (psi_b - tau * psi_a) / den
    var = np.mean(np.square(varphi))
    se = np.sqrt(var / n)

    return DrIDiDRes(
        latt=tau,
        se=se,
        num=num,
        den=den,
        IF=varphi,
        IF_num=psi_b,
        IF_den=psi_a,
        extra={
            "nfolds": nfolds,
            "m_m": _model_name(m_m),
            "g_m": _model_name(g_m),
            "p_m": _model_name(p_m),
        },
    )


def latt_dml_rc_tester(
    X: FloatArray,
    E: FloatArray,
    T: FloatArray,
    Y: FloatArray,
    D: FloatArray,
    m_m: OutcomeModel,
    g_m: TreatmentModel,
    p_m: TreatmentModel,
    *,
    eps: float = 0.01,
    nfolds: int = 5,
) -> DrIDiDRes:
    """Double Machine-Learning Estimator.

    As implemented in:
        Raaschou-Pedersen, J. S. (2026).
        Doubly Robust Instrumented Difference-in-Differences.
        Unpublished manuscript (May 2026).
    """
    E = np.ravel(E)
    T = np.ravel(T)
    Y = np.ravel(Y)
    D = np.ravel(D)
    n = Y.shape[0]

    # stratify on treatment and period indicators
    if nfolds == 1:
        # no cross-fitting
        cvs = [(np.arange(n), np.arange(n))]
    else:
        strata = 2 * E.astype(int) + T.astype(int)
        cv = StratifiedKFold(n_splits=nfolds, shuffle=True, random_state=1234)
        cvs = list(cv.split(X, strata))

    # propensity score P(E = 1 | X)
    phat = cross_val_predict(p_m, X, E, cv=cvs, method="predict_proba")[:, 1]
    phat = np.clip(phat, eps, 1 - eps)

    # marginal probability P(E = 1)
    rhohat = cross_val_predict(DummyRegressor(), X, E, cv=cvs)

    # mean functions numerator:
    # E[Y | X, E = 1, T = 1], E[Y | X, E = 1, T = 0],
    # E[Y | X, E = 0, T = 1], E[Y | X, E = 0, T = 0]
    cm = partial(_cell_mask_rc, E, T)
    m_t_post = _crossfit_subset_predict(m_m, X, Y, cvs, cm(1, 1))
    m_t_pre = _crossfit_subset_predict(m_m, X, Y, cvs, cm(1, 0))
    m_c_post = _crossfit_subset_predict(m_m, X, Y, cvs, cm(0, 1))
    m_c_pre = _crossfit_subset_predict(m_m, X, Y, cvs, cm(0, 0))
    # mean functions denominator:
    # E[D | X, E = 1, T = 1], E[D | X, E = 1, T = 0],
    # E[D | X, E = 0, T = 1], E[D | X, E = 0, T = 0]
    g_t_post = _crossfit_subset_predict(
        g_m, X, D, cvs, cm(1, 1), method="predict_proba"
    )
    g_t_pre = _crossfit_subset_predict(
        g_m, X, D, cvs, cm(1, 0), method="predict_proba"
    )
    g_c_post = _crossfit_subset_predict(
        g_m, X, D, cvs, cm(0, 1), method="predict_proba"
    )
    g_c_pre = _crossfit_subset_predict(
        g_m, X, D, cvs, cm(0, 0), method="predict_proba"
    )

    # weights
    w_t_pre = (E * (1 - T)).astype(float)
    w_t_post = (E * T).astype(float)
    w_t_pre /= w_t_pre.mean()
    w_t_post /= w_t_post.mean()
    # w_{0, t}^{rc}
    w_c_pre = phat * (1 - E) * (1 - T) / (1 - phat)
    w_c_post = phat * (1 - E) * T / (1 - phat)
    w_c_pre /= w_c_pre.mean()
    w_c_post /= w_c_post.mean()

    w_t = w_t_post - w_t_pre
    w_c = w_c_post - w_c_pre
    w_t_p = E / rhohat.mean()  # treated weights panel

    # joint mean functions
    m_t = T * m_t_post + (1 - T) * m_t_pre
    m_c = T * m_c_post + (1 - T) * m_c_pre
    g_t = T * g_t_post + (1 - T) * g_t_pre
    g_c = T * g_c_post + (1 - T) * g_c_pre

    psi_b1 = w_t * (Y - m_t) - w_c * (Y - m_c)
    psi_b2 = w_t_p * (m_t_post - m_t_pre - (m_c_post - m_c_pre))
    psi_b = psi_b1 + psi_b2

    psi_a1 = w_t * (D - g_t) - w_c * (D - g_c)
    psi_a2 = w_t_p * (g_t_post - g_t_pre - (g_c_post - g_c_pre))
    psi_a = psi_a1 + psi_a2

    # computing estimate with kappa terms
    ky1 = np.mean(w_t_p * (m_t_post - m_c_post))
    ky2 = np.mean(w_t_post * (m_t_post - m_c_post))
    ky3 = np.mean(w_t_p * (m_t_pre - m_c_pre))
    ky4 = np.mean(w_t_pre * (m_t_pre - m_c_pre))
    kappa_Y = ky1 - ky2 - (ky3 - ky4)
    kd1 = np.mean(w_t_p * (g_t_post - g_c_post))
    kd2 = np.mean(w_t_post * (g_t_post - g_c_post))
    kd3 = np.mean(w_t_p * (g_t_pre - g_c_pre))
    kd4 = np.mean(w_t_pre * (g_t_pre - g_c_pre))
    kappa_D = kd1 - kd2 - (kd3 - kd4)
    num2 = np.mean((w_t - w_c) * (Y - m_c))
    den2 = np.mean((w_t - w_c) * (D - g_c))
    est2 = (num2 + kappa_Y) / (den2 + kappa_D)

    num = psi_b.mean()
    den = psi_a.mean()
    tau = num / den
    varphi = (psi_b - tau * psi_a) / den
    var = np.mean(np.square(varphi))
    se = np.sqrt(var / n)

    return DrIDiDRes(
        latt=tau,
        se=se,
        num=num,
        den=den,
        IF=varphi,
        IF_num=psi_b,
        IF_den=psi_a,
        extra={
            "est2": est2,
            "nfolds": nfolds,
            "m_m": _model_name(m_m),
            "g_m": _model_name(g_m),
            "p_m": _model_name(p_m),
        },
    )
