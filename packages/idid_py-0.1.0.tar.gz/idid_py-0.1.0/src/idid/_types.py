from dataclasses import dataclass
from enum import StrEnum
from typing import Any, Literal, Protocol, TypeAlias, TypedDict, Union

import numpy as np
import polars as pl
from numpy.typing import NDArray

from idid.utils import ReprMixin

__all__ = [
    "Control",
    "Method",
    "AggMethod",
    "OutcomeRegressionKwargs",
    "DMLKwargs",
]

FloatArray = NDArray[np.float64]
IntArray = NDArray[np.int_]
BoolArray = NDArray[np.bool_]
FloatLike = float | np.floating


class OutcomeModel(Protocol):
    def fit(self, X: FloatArray, y: FloatArray) -> Any: ...

    def predict(self, X: FloatArray) -> FloatArray: ...


class TreatmentModel(Protocol):
    def fit(self, X: FloatArray, y: FloatArray) -> Any: ...

    def predict_proba(self, X: FloatArray) -> FloatArray: ...


class HasPred(Protocol):
    pred: FloatArray


class NuisanceEstimator(Protocol):
    def __call__(
        self,
        X: FloatArray,
        Y: FloatArray,
        b: BoolArray,
        weights: FloatArray | None = None,
    ) -> HasPred: ...


class OutcomeRegressionKwargs(TypedDict, total=False):
    """Kwargs passed to outcome-regression-style nuisance estimators.

    ns_est:
        Nuisance estimator used for the outcome regression step.
        In the panel case this can be used for either E[Δ_{t-e+1}Y_t | X, E=0]
        directly or, when ``use_levels=True``, for separate models of
        E[Y_t | X, E=0] and E[Y_{e-1} | X, E=0].

    use_levels:
        If True, estimate post and pre outcome levels separately and take
        their difference. If False, estimate the change outcome directly.
    """

    ns_est: NuisanceEstimator
    use_levels: bool


class DMLKwargs(TypedDict, total=False):
    """Kwargs passed to the DML LATT estimators.

    nfolds:
        Number of folds used for cross-fitting. Set to 1 to disable
        cross-fitting and recover the estimating-equation version.

    m_m:
        Outcome nuisance model.

    g_m:
        Treatment nuisance model.

    p_m:
        Propensity model for P(E_e = 1 | X, E_e + C = 1).
    """

    nfolds: int
    m_m: OutcomeModel
    g_m: TreatmentModel
    p_m: TreatmentModel


class Controls(StrEnum):
    nye = "nye"
    nev = "nev"
    all = "all"


@dataclass(repr=False)
class LATT(ReprMixin):
    __repr_fields__ = (
        "g",
        "t",
        "latt",
        "num",
        "denom",
        "ns",
        "ids",
        "IF",
        "IF_aet",
        "extra",
    )

    latt: float
    num: float
    denom: float
    g: int
    t: int
    IF: np.ndarray
    IF_aet: np.ndarray
    ids: pl.DataFrame
    ns: int | None = None
    extra: dict[str, Any] | None = None


@dataclass
class FailedLATT:
    latt: float
    num: float
    denom: float
    g: int
    t: int
    reason: str = ""


LATTs: TypeAlias = dict[tuple[int, int], Union[LATT, FailedLATT]]

Control = Literal["never", "notyet", "nvmy"]
Method = Literal["reg", "dr", "ipw", "std_ipw", "check", "dml", "ee", "imp"]

AggMethod: TypeAlias = Literal[
    "simple",
    "group",
    "cohort",
    "cohort_custom",
    "calendar",
    "dynamic",
    "dynamic_bal",
    "calendar_cumu",
]
