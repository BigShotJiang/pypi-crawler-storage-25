# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from core.common.version import get_version


def get_system_info():
    return {
        "engine": "TileSim",
        "version": get_version()
    }