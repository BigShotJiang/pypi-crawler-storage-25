# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

from dataclasses import dataclass


@dataclass
class OperatorPredictRequest:
    op_name: str
    input_shapes: list
    output_shapes: list
    input_precision: list[str]
    output_precision: list[str]
    accelerator: str
    backend_type: str = None  # eng 或 theo
    core_num: int = None
    tiling_config: list = None
    op_state: str = "dynamic"  # dynamic 或 static
    extra_param: dict = None


@dataclass
class OperatorPredictResponse:
    op_name: str

    # 时间开销
    latency: float
    component_latency: {}

    # 利用率
    l2_hit_rate: float
    cube_utilization_rate: float
    vec_utilization_rate: float

    # 操作数
    mem_volume: {}
    compute_workload: {}
    gm_volume: float

    # tiling信息
    tiling_info: {}

    # 其他指标
    ideal_time_by_mem: float = 0.0
    ideal_time_by_cube: float = 0.0
    ideal_time_by_vec: float = 0.0
    # 和理想性能的差距 = max(ideal_time_by_mem/cube/vec) / latency * 100%
    ideal_ratio: float = 0.0

