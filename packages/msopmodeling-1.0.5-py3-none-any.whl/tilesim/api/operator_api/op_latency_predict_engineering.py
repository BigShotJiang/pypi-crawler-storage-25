# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

import copy
import os
import sys
import traceback
from dataclasses import asdict
from pathlib import Path

import yaml

from api.operator_api.models.operator_api_models import OperatorPredictRequest, OperatorPredictResponse
from core.backend.engineering_costmodel.core.aicore_costmodel import AICoreCostModel
from core.backend.engineering_costmodel.core.tiling_and_core_split.tiling_strategy_register import TilingParam, \
    convert_list_to_tiling_param
from core.backend.engineering_costmodel.op_model.abs import ABSModel
from core.backend.engineering_costmodel.op_model.add import AddModel
from core.backend.engineering_costmodel.op_model.add_rms_norm import AddRmsNormModel
from core.backend.engineering_costmodel.op_model.ascend_quant_v2 import AscendQuantV2
from core.backend.engineering_costmodel.op_model.basic_operator import BasicOperatorModel
from core.backend.engineering_costmodel.op_model.batch_matmul import BatchMatmul
from core.backend.engineering_costmodel.op_model.clip_by_value_v2 import ClipByValueV2Model
from core.backend.engineering_costmodel.op_model.concat_d import ConcatDModel
from core.backend.engineering_costmodel.op_model.cumsum import CumSumModel
from core.backend.engineering_costmodel.op_model.div import DivModel
from core.backend.engineering_costmodel.op_model.dynamic_quant import DynamicQuant
from core.backend.engineering_costmodel.op_model.equal import EqualModel
from core.backend.engineering_costmodel.op_model.fused_infer_attention import FusedInferAttentionV4, \
    FlashAttentionInner
from core.backend.engineering_costmodel.op_model.gather_v2 import GatherV2Model
from core.backend.engineering_costmodel.op_model.gelu import GeluModel
from core.backend.engineering_costmodel.op_model.greater_equal import GreaterEqualModel
from core.backend.engineering_costmodel.op_model.groupedmatmul import GroupedMatmul
from core.backend.engineering_costmodel.op_model.hstu import HstuDenseForward
from core.backend.engineering_costmodel.op_model.layer_norm_v3 import LayerNormV3Model
from core.backend.engineering_costmodel.op_model.lightning_indexer import LightningIndexer
from core.backend.engineering_costmodel.op_model.log import LogModel
from core.backend.engineering_costmodel.op_model.matmul import Matmul
from core.backend.engineering_costmodel.op_model.moe_distribute_combine import MoeDistributeCombine
from core.backend.engineering_costmodel.op_model.moe_distribute_dispatch import MoeDispatchDispatch
from core.backend.engineering_costmodel.op_model.moe_gating_topk import MoeGatingTopK
from core.backend.engineering_costmodel.op_model.mul import MulModel
from core.backend.engineering_costmodel.op_model.multi_latent_attention import MultiLatentAttention
from core.backend.engineering_costmodel.op_model.paged_attention import PagedAttention
from core.backend.engineering_costmodel.op_model.quant_batch_matmul_v3 import QuantBatchMatmulV3
from core.backend.engineering_costmodel.op_model.ring_mla_prefill_bf16_kernel import RINGMLAPrefillBF16Kernel
from core.backend.engineering_costmodel.op_model.rms_norm import RmsNormModel
from core.backend.engineering_costmodel.op_model.slice_v2 import SliceV2
from core.backend.engineering_costmodel.op_model.softmax import SoftmaxFlashV2Model
from core.backend.engineering_costmodel.op_model.sparse_attn_sharedkv import SparseAttnSharedkv
from core.backend.engineering_costmodel.op_model.sparse_flash_attention import SparseFlashAttention
from core.backend.engineering_costmodel.op_model.swish import SwishModel
from core.backend.engineering_costmodel.op_model.topk import TopKV2Model
from core.backend.engineering_costmodel.op_model.transpose_batchmatmul import TransposeBatchMatMul
from core.common.entity import DType, OpType, ResultKey, CoreType, OpState
from core.common.log_format import logging
from core.config.arc_spec import load_arc_config

# 创建一个日志记录器
logger = logging.getLogger(__name__)

project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if project_root not in sys.path:
    sys.path.insert(0, project_root)


def _build_op(op_type, input_dtypes, output_dtypes, op_state, extra_param) -> BasicOperatorModel:
    """build operator model"""

    if len(output_dtypes) == 0:
        output_dtypes = [input_dtypes[-1]]

    if extra_param is None:
        op_model = op_type(input_dtypes[0], output_dtypes[0], op_state=op_state)
    else:
        if extra_param.get('enable_fit') is not None:
            extra_param.pop('enable_fit')
        op_model = op_type(input_dtypes[0], output_dtypes[0], op_state=op_state, **extra_param)
    return op_model


def _run_op(op_model, tiling_list, input_shapes, arc_config):
    """run time prediction"""
    return op_model.time_predict(input_shapes, tiling_list, AICoreCostModel(arc_config))


def _get_default_tiling(op_model, input_shapes) -> list[TilingParam]:
    """get default tiling by input shapes"""
    return op_model.get_tiling_strategy(input_shapes)


function_mapping = {
    OpType.MatMul: Matmul,
    OpType.AddRmsNorm: AddRmsNormModel,
    OpType.RmsNorm: RmsNormModel,
    OpType.LayerNorm: LayerNormV3Model,
    OpType.Gelu: GeluModel,
    OpType.ClipByValueV2: ClipByValueV2Model,
    OpType.Add: AddModel,
    OpType.Div: DivModel,
    OpType.Log: LogModel,
    OpType.Mul: MulModel,
    OpType.Swish: SwishModel,
    OpType.Abs: ABSModel,
    OpType.QuantBatchMatmulV3: QuantBatchMatmulV3,
    OpType.HstuDenseForwardFuxi: HstuDenseForward,
    OpType.AscendQuantV2: AscendQuantV2,
    OpType.DynamicQuant: DynamicQuant,
    OpType.Cumsum: CumSumModel,
    OpType.Equal: EqualModel,
    OpType.BatchMatMul: BatchMatmul,
    OpType.FusedInferAttentionScore: FusedInferAttentionV4,
    OpType.FlashAttention: FlashAttentionInner,
    OpType.UnpadFlashAttentionMlaBF16NdKernel: FlashAttentionInner,
    OpType.MoeDistributeDispatchV2: MoeDispatchDispatch,
    OpType.MoeDistributeCombineV2: MoeDistributeCombine,
    OpType.TopKV2: TopKV2Model,
    OpType.MultiHeadLatentAttention: MultiLatentAttention,
    OpType.RINGMLAPrefillBF16Kernel: RINGMLAPrefillBF16Kernel,
    OpType.ConcatD: ConcatDModel,
    OpType.GroupedMatmul: GroupedMatmul,
    OpType.Slice: SliceV2,
    OpType.Gather: GatherV2Model,
    OpType.PageAttention: PagedAttention,
    OpType.MoeGatingTopK: MoeGatingTopK,
    OpType.LightningIndexer: LightningIndexer,
    OpType.SparseFlashAttention: SparseFlashAttention,
    OpType.SparseAttnSharedkv: SparseAttnSharedkv,
    OpType.GreaterEqual: GreaterEqualModel,
    OpType.TransposeBatchMatMul: TransposeBatchMatMul,
    OpType.Softmax: SoftmaxFlashV2Model
}

default_tiling_mapping = {
    OpType.MatMul: [TilingParam(0, 0, 0, 0, 0, 0, 0, 24, 1, 1, swizzle_offset=-1)],
    OpType.AddRmsNorm: [TilingParam(0, 0, 0, 58, 128, 0, 0, 48, 1, swizzle_offset=1, swizzle_direction=0)],
    OpType.LayerNorm: [TilingParam(0, 0, 0, 26, 128, 0, 0, 48, 1, swizzle_offset=1, swizzle_direction=0)],
    OpType.Gelu: [TilingParam(0, 0, 0, 172, 32, 0, 0, 48, 1, swizzle_offset=1, swizzle_direction=0)],
    OpType.ClipByValueV2: [TilingParam(0, 0, 0, 74, 64, 0, 0, 48, 1, swizzle_offset=1, swizzle_direction=0)],
    OpType.Add: [TilingParam(0, 0, 0, 172, 32, 0, 0, 48, 1, swizzle_offset=1, swizzle_direction=0)],
    OpType.Div: [TilingParam(0, 0, 0, 86, 64, 0, 0, 48, 1, swizzle_offset=1, swizzle_direction=0)],
    OpType.Log: [TilingParam(0, 0, 0, 172, 64, 0, 0, 48, 1, swizzle_offset=1, swizzle_direction=0)],
    OpType.Mul: [TilingParam(0, 0, 0, 86, 64, 0, 0, 48, 1, swizzle_offset=1, swizzle_direction=0)],
    OpType.Swish: [TilingParam(0, 0, 0, 172, 32, 0, 0, 48, 1, swizzle_offset=1, swizzle_direction=0)],
    OpType.Abs: [TilingParam(0, 0, 0, 172, 64, 0, 0, 48, 1, swizzle_offset=1, swizzle_direction=0)],
    OpType.HstuDenseForwardFuxi: [
        TilingParam(m0=128, k0=256, n0=128, m1=128, k1a=256, k1b=256, n1=128, w=4, h=6, swizzle_offset=1,
                    swizzle_direction=0),
        TilingParam(m0=0, k0=0, n0=0, m1=128, k1a=0, k1b=0, n1=256, w=4, h=6, swizzle_offset=1, swizzle_direction=0)],
    OpType.DynamicQuant: [TilingParam(0, 0, 0, 1, 7168, 0, 0, 1, 1, 1, swizzle_offset=1, swizzle_direction=0)],
    OpType.Cumsum: [TilingParam(0, 0, 0, 1, 94, 0, 0, 48, 1, swizzle_offset=0, swizzle_direction=0)],
    OpType.Equal: [TilingParam(0, 0, 0, 3, 2001, 0, 0, 48, 1, swizzle_offset=0, swizzle_direction=0)],
    OpType.BatchMatMul: [TilingParam(0, 0, 0, 0, 0, 0, 0, 4, 6, 1)],
    OpType.FusedInferAttentionScore: FusedInferAttentionV4.get_default_tiling_param(),
    OpType.FlashAttention: [TilingParam(128, 1024, 64, 128, 1024, 128, 128, 4, 6, 1),
                            TilingParam(8, 1024, 0, 8, 1024, 0, 0, 8, 6, 1),
                            TilingParam(128, 1024, 64, 128, 1024, 128, 128, 4, 6, 1),
                            TilingParam(8, 1024, 0, 8, 1024, 0, 0, 8, 6, 1)],
    OpType.UnpadFlashAttentionMlaBF16NdKernel: [TilingParam(128, 1024, 64, 128, 1024, 128, 128, 4, 6, 1),
                                                TilingParam(8, 1024, 0, 8, 1024, 0, 0, 8, 6, 1),
                                                TilingParam(128, 1024, 64, 128, 1024, 128, 128, 4, 6, 1),
                                                TilingParam(8, 1024, 0, 8, 1024, 0, 0, 8, 6, 1)],
    OpType.ConcatD: [TilingParam(0, 0, 0, 192, 64, 0, 0, 48, 1, swizzle_offset=1, swizzle_direction=0)],
    OpType.TopKV2: [
        TilingParam(0, 0, 0, 28 * 8, 7168, 0, 0, 1, 1, swizzle_offset=0, swizzle_direction=0)],
    OpType.MultiHeadLatentAttention: [TilingParam(128, 1024, 64, 128, 1024, 128, 128, 4, 6, 1),
                                      TilingParam(8, 1024, 0, 8, 1024, 0, 0, 8, 6, 1),
                                      TilingParam(128, 1024, 64, 128, 1024, 128, 128, 4, 6, 1),
                                      TilingParam(8, 1024, 0, 8, 1024, 0, 0, 8, 6, 1)],
    OpType.RINGMLAPrefillBF16Kernel: [TilingParam(128, 1024, 64, 128, 1024, 128, 128, 4, 6, 1),
                                      TilingParam(8, 1024, 0, 8, 1024, 0, 0, 8, 6, 1),
                                      TilingParam(128, 1024, 64, 128, 1024, 128, 128, 4, 6, 1),
                                      TilingParam(8, 1024, 0, 8, 1024, 0, 0, 8, 6, 1)],
    OpType.Slice: [],
    OpType.Gather: [TilingParam(0, 0, 0, 192, 64, 0, 0, 48, 1, swizzle_offset=1, swizzle_direction=0)],
    OpType.PageAttention: [TilingParam(128, 1024, 64, 128, 1024, 128, 128, 4, 6, 1),
                           TilingParam(8, 1024, 0, 8, 1024, 0, 0, 8, 6, 1),
                           TilingParam(128, 1024, 64, 128, 1024, 128, 128, 4, 6, 1),
                           TilingParam(8, 1024, 0, 8, 1024, 0, 0, 8, 6, 1)],
    OpType.LightningIndexer: [
        TilingParam(128, 128, 128, 128, 128, 128, 128, 24, 1, swizzle_offset=1, swizzle_direction=0),
        TilingParam(0, 0, 0, 32, 512, 0, 0, 48, 1, swizzle_offset=1, swizzle_direction=0),
    ],
    OpType.GreaterEqual: [TilingParam(0, 0, 0, 50, 2002, 0, 0, 40, 1, swizzle_offset=0, swizzle_direction=0)],
    OpType.TransposeBatchMatMul: [TilingParam(0, 0, 0, 0, 0, 0, 0, 4, 6, 1)],
    OpType.Softmax: [TilingParam(0, 0, 0, 8, 1024, 0, 0, 1, 1, 1, swizzle_offset=0, swizzle_direction=0)]
}


def _fix_core_num(tiling_default_config, core_num, core_type):
    dup_core = 2 if core_type == CoreType.MIX else 1

    for tiling in tiling_default_config:
        # m0 tiling = 0的是AIV tiling配置
        if tiling.m0 == 0:
            tiling.core_num = core_num * dup_core
            tiling.parallel_core_num = core_num * dup_core
        else:
            tiling.core_num = core_num
            tiling.parallel_core_num = core_num


def _reset_core_num(op_input: dict) -> dict:
    op_type = OpType.from_str(op_input['op_name'])
    config_path = Path(op_input.get('accelerator'))
    with open(config_path, 'r', encoding='utf-8') as f:
        data = yaml.safe_load(f)
    if op_type.core_type == CoreType.AIV:
        op_input['core_num'] = data.get("core_config").get("vec_core_num")
    else:
        op_input['core_num'] = data.get("core_config").get("cube_core_num")
    return op_input


def _op_input_convert(op_input: dict) -> OperatorPredictRequest:
    return OperatorPredictRequest(
        op_name=op_input.get('op_name'),
        input_shapes=op_input.get('input_shapes'),
        output_shapes=op_input.get('output_shapes'),
        input_precision=op_input.get('input_precision'),
        output_precision=op_input.get('output_precision'),
        accelerator=op_input.get('accelerator'),
        backend_type=op_input.get('backend_type'),
        core_num=op_input.get('core_num'),
        tiling_config=op_input.get('tiling_config'),
        op_state=op_input.get('op_state', 'dynamic'),
        extra_param=op_input.get('extra_param'),
    )


def _convert_tuning_tiling_param(tiling_param: list) -> list[list[TilingParam]]:
    if len(tiling_param) == 0 or tiling_param[0] is None:
        raise ValueError("tiling_param is empty")

    ret = []
    for tiling_group in tiling_param:
        single_tiling = []
        for t in tiling_group:
            single_tiling.append(convert_list_to_tiling_param(t))
        ret.append(single_tiling)

    return ret


def op_latency_predict(op_input: dict | OperatorPredictRequest):
    """旧版工程可达入口"""
    logger.info(f'[API.OP_LATENCY_PREDICT_ENGINEERING] receive new request for operator costmodel: {op_input}')
    try:
        if isinstance(op_input, dict):
            op_input = _op_input_convert(op_input)
        input_precision = [DType.from_str(precision) for precision in op_input.input_precision]
        output_precision = [DType.from_str(precision) for precision in op_input.output_precision]
        op_type = OpType.from_str(op_input.op_name)

        # 处理核数
        if op_input.core_num is not None:
            core_num = op_input.core_num
        else:
            config_path = Path(op_input.accelerator)
            with open(config_path, 'r', encoding='utf-8') as f:
                data = yaml.safe_load(f)
            if op_type.core_type == CoreType.AIV:
                core_num = data.get("core_config").get("vec_core_num")
            else:
                core_num = data.get("core_config").get("cube_core_num")

        # 算子函数选择
        op_function = function_mapping.get(op_type)
        if op_function is None:
            raise NotImplementedError(f"op_type: {op_type} not implemented")

        # npu硬件参数
        if op_input.accelerator is not None and os.path.exists(op_input.accelerator):
            arc_config = load_arc_config(op_input.accelerator)
        else:
            raise ValueError(f"npu_spec_config path {op_input.accelerator} is not found")
        op_input.extra_param = op_input.extra_param if op_input.extra_param is not None else {}
        if op_type == OpType.Slice:
            op_input.extra_param |= {'vec_core_num': core_num, 'output_shape': op_input.output_shapes}
        if op_type == OpType.Gather:
            op_input.extra_param |= {'block_dim': core_num}
        if op_type in [OpType.MoeGatingTopK, OpType.LightningIndexer, OpType.TransposeBatchMatMul]:
            op_input.extra_param |= {'output_shape': op_input.output_shapes}
        op_state = OpState.from_str(op_input.op_state)
        # 构建算子建模实体
        op_model = _build_op(op_function, input_precision, output_precision, op_state, op_input.extra_param)

        tiling_default_config, predict_result = _run_tuning_config(op_input, op_type, core_num, op_model, arc_config)

        op_output = to_output(op_input, predict_result, tiling_default_config)

        return op_output
    except Exception as e:
        error_stack = traceback.format_exc()
        logger.error(f"[API.OP_LATENCY_PREDICT_ENGINEERING] failed to predict operator costmodel: {e}")
        logger.error(error_stack)
        return {'error': str(e), 'error_stack': error_stack}


def _run_tuning_config(op_input, op_type, core_num, op_model, arc_config):
    # tiling参数配置

    if op_input.tiling_config is not None:
        tiling_default_config = _convert_tuning_tiling_param(op_input.tiling_config)
    elif op_type not in default_tiling_mapping:
        tiling_default_config = [_get_default_tiling(op_model, op_input.input_shapes)]
    else:
        tiling_default_config = [copy.deepcopy(default_tiling_mapping.get(op_type))]

    best_tiling = None
    best_result = float('inf')
    for tiling in tiling_default_config:
        _fix_core_num(tiling, core_num, op_type.core_type)
        res = _run_op(op_model, tiling, op_input.input_shapes, arc_config)
        res_latency = res[ResultKey.CORE_TIME]
        if res_latency < best_result:
            best_result = res_latency
            best_tiling = tiling
            predict_result = res
    tiling_default_config = best_tiling
    return tiling_default_config, predict_result


def format_tiling_output(op_name: str, tiling_list: list[TilingParam]):
    """统一格式化输出tiling信息"""
    tiling_info = {}
    for i, tiling in enumerate(tiling_list):
        core_type = CoreType.AIC if tiling.k0 > 0 else CoreType.AIV
        tiling_info[f"name_{i}"] = {
            "item_name": f"算子{op_name}第{i + 1}阶段{core_type.desc} tiling参数",
            "tiling_type": tiling.tiling_strategy.name,
            "l0_m": tiling.m0,
            "l0_n": tiling.n0,
            "l0_k": tiling.k0,
            "l1_m": tiling.m1,
            "l1_n": tiling.n1,
            "l1_k": tiling.k1a,  # k1a is equal to k1b in the current tilesim
            "ub_m": tiling.m1,
            "ub_n": tiling.n1,
            "param": {
                "swizzle_dir": tiling.swizzle_direction,
                "swizzle_offset": tiling.swizzle_offset
            }
        }
    return tiling_info


def to_output(
        op_input: OperatorPredictRequest, predict_result: dict[ResultKey:float], tiling_list: list[TilingParam]
):
    component_latency = {
        "CUBE": predict_result.get(ResultKey.CUBE_TIME, 0),
        "MTE1": predict_result.get(ResultKey.MTE1_TIME, 0),
        "MTE2": predict_result.get(ResultKey.MTE2_TIME_AIC, 0),
        "FIXPIPE": predict_result.get(ResultKey.FIXPIPE_TIME, 0),
        "VEC": predict_result.get(ResultKey.VEC_TIME, 0),
        "MTE2_AIV": predict_result.get(ResultKey.MTE2_TIME_AIV, 0),
        "MTE3": predict_result.get(ResultKey.MTE3_TIME, 0),
        "AIC_MEM_ACCESS": max(predict_result.get(ResultKey.MTE1_TIME, 0),
                              predict_result.get(ResultKey.MTE2_TIME_AIC, 0),
                              predict_result.get(ResultKey.FIXPIPE_TIME, 0)),
        "AIV_MEM_ACCESS": (predict_result.get(ResultKey.MTE2_TIME_AIV, 0) + predict_result.get(ResultKey.MTE3_TIME, 0))
        if '910B' in op_input.accelerator
        else max(predict_result.get(ResultKey.MTE2_TIME_AIV, 0), predict_result.get(ResultKey.MTE3_TIME, 0))
    }

    tiling_info = format_tiling_output(op_input.op_name, tiling_list)
    mem_volume = {
        "L1_cache": predict_result.get(ResultKey.L1_CACHE, 0),
        "L0A_cache": predict_result.get(ResultKey.L0A_CACHE, 0),
        "L0B_cache": predict_result.get(ResultKey.L0B_CACHE, 0),
        "L0C_cache": predict_result.get(ResultKey.L0C_CACHE, 0),
        "L2_cache": predict_result.get(ResultKey.L2_CACHE, 0),
        "UB_cache": predict_result.get(ResultKey.UB_CACHE, 0)
    }
    compute_workload = {
        "CUBE": predict_result.get(ResultKey.AIC_TOTAL_MKN, 0) * 2 / predict_result[ResultKey.CORE_TIME],
        "VEC": predict_result.get(ResultKey.AIV_TOTAL_CYCLES, 0)
    }

    op_output = OperatorPredictResponse(
        op_name=op_input.op_name,
        latency=predict_result[ResultKey.CORE_TIME],
        component_latency=component_latency,
        l2_hit_rate=1 - predict_result[ResultKey.L2_MISS_RATE],
        cube_utilization_rate=component_latency["CUBE"] / predict_result[ResultKey.CORE_TIME],
        vec_utilization_rate=component_latency["VEC"] / predict_result[ResultKey.CORE_TIME],
        mem_volume=mem_volume,
        compute_workload=compute_workload,
        gm_volume=0,
        tiling_info=tiling_info,
        ideal_time_by_mem=0,
        ideal_time_by_cube=0,
        ideal_time_by_vec=0,
        ideal_ratio=0,
    )
    return asdict(op_output)
