# TileOp 性能预测 API 技术文档

## 一、概述

TileOp 性能预测 API 用于预测 NPU 上 Tile 级别算子的执行耗时。该 API 支持两种预测后端：

| 后端类型 | 说明 | 适用场景 |
|---------|------|---------|
| **PyPTO** | 基于 PTO (Performance Timing Object) 指令模拟 | 精确建模，支持复杂指令序列 |
| **PLAIN** | 基于解析模型的性能计算 | 快速估算，覆盖面广 |

---

## 二、API 接口

### 2.1 入口函数

```python
def tile_op_latency_predict_pypto(tile_op: dict, config: dict = None) -> dict:
    """
    TileOp 性能预测对外接口

    Args:
        tile_op: TileOp 的接口实体类，包含 opcode、输入输出张量等信息
        config: 其他参数（预留，暂未使用）

    Returns:
        dict: 包含 latency 和 cycles 字段的预测结果，或错误信息
    """
```

### 2.2 请求格式

```python
tile_op_request = {
    "magic": int,           # TileOp 唯一标识
    "opcode": str,          # 操作码名称，如 "ADD", "MUL", "COPY_IN" 等
    "iOperand": [           # 输入张量列表（camelCase 格式）
        {
            "magic": int,
            "dataTypeStr": str,     # 数据类型，如 "FP16", "FP32"
            "bufferType": str,      # 内存位置，如 "UB", "L1", "GM"
            "offset": [int, int],   # 相对于原始张量的偏移
            "shape": [int, int],    # 张量形状
            "rawMagic": int,        # 原始张量标识
            "rawShape": [int, int]  # 原始张量形状
        }
    ],
    "oOperand": [...]       # 输出张量列表，格式同 iOperand
}
```

### 2.3 响应格式

```python
response = {
    "latency": float,       # 预测耗时，单位：微秒 (us)
    "cycles": float         # 预测耗时，单位：时钟周期数
}
```

### 2.4 调用示例

```python
from api.tile_op_api.tile_op_costmodel import tile_op_latency_predict_pypto

# 构造请求
request = {
    "magic": 12345,
    "opcode": "ADD",
    "iOperand": [
        {
            "magic": 1,
            "dataTypeStr": "FP16",
            "bufferType": "UB",
            "offset": [0, 0],
            "shape": [128, 256],
            "rawMagic": 100,
            "rawShape": [1024, 1024]
        },
        {
            "magic": 2,
            "dataTypeStr": "FP16",
            "bufferType": "UB",
            "offset": [0, 0],
            "shape": [128, 256],
            "rawMagic": 101,
            "rawShape": [1024, 1024]
        }
    ],
    "oOperand": [
        {
            "magic": 3,
            "dataTypeStr": "FP16",
            "bufferType": "UB",
            "offset": [0, 0],
            "shape": [128, 256],
            "rawMagic": 102,
            "rawShape": [1024, 1024]
        }
    ]
}

# 调用预测
result = tile_op_latency_predict_pypto(request)
print(f"Predicted latency: {result['latency']} us")
print(f"Predicted cycles: {result['cycles']} cycles")
```

---

## 三、支持的操作码

### 3.1 向量运算类

| 操作码 | 说明 | TileOpCode |
|-------|------|-----------|
| `ADD` | 向量加法 | `TileOpCode.ADD` |
| `SUB` | 向量减法 | `TileOpCode.SUB` |
| `MUL` | 向量乘法 | `TileOpCode.MUL` |
| `DIV` | 向量除法 | `TileOpCode.DIV` |
| `MAX` / `MAXIMUM` | 向量最大值 | `TileOpCode.MAX` |
| `MIN` / `MINIMUM` | 向量最小值 | `TileOpCode.MIN` |
| `ADDS` | 向量加标量 | `TileOpCode.ADDS` |
| `MULS` | 向量乘标量 | `TileOpCode.MULS` |
| `SUBS` | 向量减标量 | `TileOpCode.SUBS` |
| `DIVS` | 向量除标量 | `TileOpCode.DIVS` |
| `ABS` | 绝对值 | `TileOpCode.ABS` |
| `SQRT` | 平方根 | `TileOpCode.SQRT` |
| `RSQRT` | 平方根倒数 | `TileOpCode.RSQRT` |
| `CAST` | 类型转换 | `TileOpCode.CAST` |

### 3.2 规约运算类

| 操作码 | 说明 | TileOpCode |
|-------|------|-----------|
| `ROWSUM_SINGLE` | 单行求和 | `TileOpCode.ROWSUM_SINGLE` |
| `ROWMAX_SINGLE` | 单行最大值 | `TileOpCode.ROWMAX_SINGLE` |
| `ROWMIN_SINGLE` | 单行最小值 | `TileOpCode.ROWMIN_SINGLE` |
| `ROWSUM_LINE` | 按行求和 | `TileOpCode.REDUCE_SUM` |
| `ROWMAX_LINE` | 按行最大值 | `TileOpCode.REDUCE_MAX` |
| `ROWMIN_LINE` | 按行最小值 | `TileOpCode.REDUCE_MIN` |

### 3.3 数据搬运类

| 操作码 | 说明 | TileOpCode |
|-------|------|-----------|
| `COPY_IN` | 数据搬入 | `TileOpCode.COPY` |
| `UB_COPY_IN` | UB 数据搬入 | `TileOpCode.COPY` |
| `UB_COPY_OUT` | UB 数据搬出 | `TileOpCode.COPY` |
| `L0C_COPY_UB` | L0C 到 UB 拷贝 | `TileOpCode.COPY` |

### 3.4 其他操作

| 操作码 | 说明 | TileOpCode |
|-------|------|-----------|
| `EXPAND` / `BRCB` | 广播扩展 | `TileOpCode.BROADCAST` |
| `GATHER_ELEMENT` | 元素收集 | `TileOpCode.GATHER` |
| `EXTRACT` | 元素提取 | `TileOpCode.EXTRACT` |
| `WHERE_TT` | 条件选择 | `TileOpCode.SELECT` |
| `BITSORT` | 位排序 | `TileOpCode.BITSORT` |
| `MRGSORT` | 归并排序 | `TileOpCode.MRGSORT` |
| `VEC_DUP` | 向量复制 | `TileOpCode.VEC_DUP` |
| `RANGE` | 范围生成 | `TileOpCode.RANGE` |
| `ONEHOT` | One-hot 编码 | `TileOpCode.ONEHOT` |
| `TRANSPOSE_VNCHWCONV` | 转置 (VNCHWCONV) | `TileOpCode.TRANSPOSE_VNCHWCONV` |
| `TRANSPOSE_MOVEIN` | 转置搬入 | `TileOpCode.TRANSPOSE_MOVEIN` |
| `TRANSPOSE_MOVEOUT` | 转置搬出 | `TileOpCode.TRANSPOSE_MOVEOUT` |

---

## 四、数据模型

### 4.1 领域实体关系

```
┌─────────────────────────────────────────────────────────────┐
│                    TileOpPredictRequest                      │
│  (API 层请求模型，支持 camelCase/snake_case 自动转换)         │
└─────────────────────────────────────────────────────────────┘
                              │ to_domain()
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                      TileOpEntity                            │
│  (领域实体，性能建模的核心数据结构)                           │
│  ├── magic: int              # 唯一标识                      │
│  ├── opcode: TileOpCode      # 操作码枚举                    │
│  ├── i_operand: [TileEntity] # 输入张量列表                  │
│  ├── o_operand: [TileEntity] # 输出张量列表                  │
│  └── context: TileOpContext  # 建模上下文                    │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                       TileEntity                             │
│  (张量实体)                                                  │
│  ├── magic: int              # 唯一标识                      │
│  ├── data_type_str: DType    # 数据类型                      │
│  ├── buffer_type: MemLoc     # 内存位置                      │
│  ├── shape: [int, int]       # 形状                          │
│  ├── offset: [int, int]      # 偏移                          │
│  ├── raw_magic: int          # 原始张量标识                  │
│  └── raw_shape: [int, int]   # 原始张量形状                  │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                     TileOpContext                            │
│  (建模上下文)                                                │
│  ├── arc_config: ArcConfig   # 微架构配置                    │
│  ├── core_num: int           # 使用的核数                    │
│  ├── barrier: bool           # 是否需要 barrier              │
│  └── enable_small_pkt_bw: bool # 是否启用小包带宽拟合        │
└─────────────────────────────────────────────────────────────┘
```

### 4.2 核心数据结构

#### TileEntity

```python
@dataclass
class TileEntity:
    magic: int | str           # Tile 唯一标识
    data_type_str: DType       # 数据精度格式 (FP16/FP32/BF16/INT8 等)
    buffer_type: MemLoc        # 内存位置 (UB/L1/L0A/L0B/L0C/GM 等)
    shape: list[int]           # Tile 形状（二维）
    offset: list[int]          # 相对于原始 Tensor 的位置偏移
    raw_magic: int | str       # 原始 global tensor 的唯一标识
    raw_shape: list[int]       # 原始 global tensor 的 shape
    start_addr: int            # 起始地址（默认 0x0）
```

#### TileOpEntity

```python
@dataclass
class TileOpEntity:
    magic: int | str           # TileOp 唯一标识
    opcode: TileOpCode         # TileOp 类型枚举
    i_operand: list[TileEntity]  # 输入 operand 列表
    o_operand: list[TileEntity]  # 输出 operand 列表
    context: TileOpContext     # 建模用到的额外入参
```

#### TileOpLatency

```python
@dataclass
class TileOpLatency:
    latency: float                              # 总耗时 (us)
    cycles: float                               # 总耗时（时钟周期数）
    unit_latency: dict[CoreUnit, float]         # 各组件耗时
    data_transfer: dict[tuple[MemLoc, MemLoc], float]  # 数据通路搬运量
```

---

## 五、后端实现

### 5.1 注册与分发机制

```
┌─────────────────────────────────────────────────────────────┐
│                    tile_op_latency_predict_pypto             │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                      tile_op_dispatch                        │
│  根据 (opcode, op_type, version) 查找注册的 handler          │
└─────────────────────────────────────────────────────────────┘
                              │
           ┌──────────────────┼──────────────────┐
           ▼                  ▼                  ▼
    ┌─────────────┐    ┌─────────────┐    ┌─────────────┐
    │   PyPTO     │    │   PLAIN     │    │   ...       │
    │   Handler   │    │   Handler   │    │             │
    └─────────────┘    └─────────────┘    └─────────────┘
```

#### 注册装饰器

```python
@tile_op_handler(
    opcode=TileOpCode.ADD,      # 支持单个或列表
    op_type=TileOpType.PLAIN,   # PyPTO 或 PLAIN
    version=0                   # 版本号，默认使用最高版本
)
def add_handler(tile_op: TileOpEntity) -> TileOpLatency:
    # 实现性能预测逻辑
    ...
```

#### 分发函数

```python
def tile_op_dispatch(
    tile_op: TileOpEntity,
    op_type: TileOpType,
    version: int = None
) -> TileOpLatency:
    """
    根据 opcode、op_type、version 查找并调用对应的 handler

    支持结果缓存，相同输入参数直接返回缓存结果
    """
```

### 5.2 PLAIN 后端实现

PLAIN 后端基于解析模型计算性能，核心实现位于 `core/backend/tile_op_costmodel/plain_ops/`。

#### 5.2.1 向量运算 (vec_op.py)

```python
@tile_op_handler(
    opcode=[TileOpCode.ADD, TileOpCode.SUB, TileOpCode.MUL, ...],
    op_type=TileOpType.PLAIN
)
def plain_simple_op_based_on_cce(tile_op: TileOpEntity) -> TileOpLatency:
    """
    基于CCE指令周期的向量运算建模

    计算公式：
    1. repeats = ceil(元素数 * 数据类型大小 / 单次repeat元素数)
    2. cycles = computing_cycles * repeats
    3. latency = cycles / 时钟频率
    """
    arc_config = tile_op.context.arc_config
    vec_inst = tile_op_to_inst.get(tile_op.opcode)  # 映射到 VecOpType

    input_tile = tile_op.i_operand[0]
    input_d_type = input_tile.data_type_str

    # 计算重复次数
    repeats = math.ceil(
        math.prod(input_tile.shape) * input_d_type.size /
        arc_config.vec_config.vec_size_single_repeat[input_d_type]
    )

    # 查表获取计算周期
    cycles = arc_config.lookup_vec_cycle(vec_inst, input_d_type, CycleType.COMPUTING_CYCLES)
    cycles *= repeats

    # 如果需要 barrier，加上间隔周期
    if tile_op.context.barrier:
        cycles += arc_config.lookup_vec_cycle(vec_inst, input_d_type, CycleType.INTERVAL_CYCLES)

    latency = cycles / arc_config.clock_freq
    return TileOpLatency(latency=latency, cycles=cycles, unit_latency={CoreUnit.VEC: latency})
```

#### 5.2.2 规约运算 (vec_op.py)

```python
@tile_op_handler(
    opcode=[TileOpCode.REDUCE_SUM, TileOpCode.REDUCE_MAX, TileOpCode.REDUCE_MIN],
    op_type=TileOpType.PLAIN
)
def plain_reduce_op_based_on_cce(tile_op: TileOpEntity) -> TileOpLatency:
    """
    规约运算建模 - 采用多轮规约策略

    算法：
    1. 第一轮：对输入数据进行基础操作（如 VADD）
    2. 后续轮：使用跨组规约指令（如 VCGADD）
    3. 直到剩余元素数 <= 单次repeat元素数
    """
```

#### 5.2.3 数据搬运 (copy_op.py)

```python
@tile_op_handler(opcode=TileOpCode.COPY, op_type=TileOpType.PLAIN)
def plain_copy(tile_op: TileOpEntity) -> TileOpLatency:
    """
    数据搬运建模

    分两种情况：
    1. UB -> UB：使用 VCOPY 指令，按向量运算计算
    2. 跨内存搬运：使用 MTE 指令，按带宽模型计算
       latency = data_size / bandwidth
    """
    src_mem = src_tile.buffer_type
    dst_mem = dst_tile.buffer_type

    if src_mem == MemLoc.UB and dst_mem == MemLoc.UB:
        # VCOPY 指令
        ...
    else:
        # MTE 搬运
        data_size = math.prod(dst_tile.shape) * dst_tile.data_type_str.size
        bw, is_small_pkt = arc_config.lookup_bw(src_mem, dst_mem, core_num, pkt_size=data_size)
        latency = data_size / bw
```

#### 5.2.4 矩阵乘 (cube_op.py)

```python
@tile_op_handler(opcode=TileOpCode.GEMM, op_type=TileOpType.PLAIN, version=1)
def plain_gemm_based_on_l1_pipe(tile_op: TileOpEntity) -> TileOpLatency:
    """
    GEMM 建模 - 基于 L1 流水线模型

    计算模型：
    1. 搬运时间：L1 -> L0A/L0B 的数据搬运
    2. 计算时间：Cube 核矩阵乘计算
    3. 总时间：max(搬运时间 - 首块搬运时间, 计算时间) + 首块搬运时间
    """

@tile_op_handler(opcode=TileOpCode.MMAD, op_type=TileOpType.PLAIN, version=1)
def plain_mmad(tile_op: TileOpEntity) -> TileOpLatency:
    """
    MMAD 建模 - 矩阵乘累加

    输入在 L0A/L0B，输出累加到 L0C
    """
```

### 5.3 PyPTO 后端实现

PyPTO 后端基于 PTO 指令模拟器进行性能预测，实现位于 `core/backend/tile_op_costmodel/pypto_ops/`。

```python
@tile_op_handler(
    opcode=[TileOpCode.ADD, TileOpCode.SUB, TileOpCode.MUL, ...],
    op_type=TileOpType.PyPTO
)
def binary_costmodel(tile_op: TileOpEntity) -> TileOpLatency:
    """
    二元运算的 PyPTO 建模

    流程：
    1. 将 TileEntity 转换为 PTOTile
    2. 调用 pto_dispatch 执行指令模拟
    3. 累加得到总耗时
    """
    shapes = [in_tile0.shape, in_tile1.shape, out_tile.shape]

    # 维度转换
    new_shapes, repeat = convert_shapes(shapes, out_tile.data_type_str.size)

    # 构造 PTO Tile
    src0 = PTOTile(new_shapes[0][0], new_shapes[0][1], out_tile.data_type_str, in_addr0)
    src1 = PTOTile(new_shapes[1][0], new_shapes[1][1], out_tile.data_type_str, in_addr1)
    dest = PTOTile(new_shapes[2][0], new_shapes[2][1], out_tile.data_type_str, out_addr)

    # 调用 PTO 指令模拟
    pto_inst = opcode_pto_projection(opcode.value)
    for _ in range(repeat_times):
        latency += pto_dispatch(pto_inst, BinaryInst(dest, src0, src1))

    return TileOpLatency(latency=latency, unit_latency={CoreUnit.VEC: latency})
```

---

## 六、扩展开发指南

### 6.1 添加新的 TileOp 类型

1. **在 `TileOpCode` 枚举中添加新操作码**

```python
# core/common/tile_op_enum.py
class TileOpCode(Enum):
    NEW_OP = ("new_op", [CoreUnit.VEC])  # 操作码名称和执行单元
```

2. **在 API 层添加映射**

```python
# api/tile_op_api/tile_op_costmodel.py
_OP_CODE_CONVERT = {
    "NEW_OP": TileOpCode.NEW_OP,
    ...
}
```

3. **实现性能预测 handler**

```python
# core/backend/tile_op_costmodel/plain_ops/vec_op.py
@tile_op_handler(opcode=TileOpCode.NEW_OP, op_type=TileOpType.PLAIN)
def plain_new_op(tile_op: TileOpEntity) -> TileOpLatency:
    # 实现建模逻辑
    ...
```

### 6.2 添加新的后端类型

1. **定义新的 TileOpType**

```python
# core/common/tile_op_enum.py
class TileOpType(Enum):
    PyPTO = "PyPTO"
    PLAIN = "PLAIN"
    NEW_BACKEND = "new_backend"  # 新后端
```

2. **创建 handler 实现目录**

```
core/backend/tile_op_costmodel/
└── new_backend_ops/
    ├── __init__.py
    └── vec_op.py
```

3. **实现 handler 并注册**

```python
@tile_op_handler(opcode=TileOpCode.ADD, op_type=TileOpType.NEW_BACKEND)
def new_backend_add(tile_op: TileOpEntity) -> TileOpLatency:
    ...
```

### 6.3 版本管理

同一 `(opcode, op_type)` 组合支持多个版本，默认使用最高版本：

```python
# 版本 0（默认）
@tile_op_handler(opcode=TileOpCode.GEMM, op_type=TileOpType.PLAIN, version=0)
def gemm_v0(tile_op: TileOpEntity) -> TileOpLatency:
    ...

# 版本 1（改进版）
@tile_op_handler(opcode=TileOpCode.GEMM, op_type=TileOpType.PLAIN, version=1)
def gemm_v1(tile_op: TileOpEntity) -> TileOpLatency:
    ...

# 调用时指定版本
latency = tile_op_dispatch(tile_op, TileOpType.PLAIN, version=0)
```

---

## 七、文件结构

```
api/tile_op_api/
├── tile_op_costmodel.py           # API 入口
└── models/
    └── tile_op_api_models.py      # 请求/响应模型

core/backend/tile_op_costmodel/
├── tile_op_backend_entity.py      # 领域实体定义
├── tile_op_registry.py            # 注册与分发机制
├── plain_ops/                     # PLAIN 后端实现
│   ├── vec_op.py                  # 向量运算
│   ├── copy_op.py                 # 数据搬运
│   └── cube_op.py                 # 矩阵乘
└── pypto_ops/                     # PyPTO 后端实现
    ├── binary.py                  # 二元运算
    ├── unary.py                   # 单目运算
    ├── reduce.py                  # 规约运算
    ├── scale.py                   # 标量运算
    ├── functions.py               # 辅助函数
    └── pto/                       # PTO 模拟器
        ├── pto_registry.py        # PTO 指令注册
        └── instructions/          # 指令实现
```

---

## 八、注意事项

1. **内存位置约束**：
   - 向量运算输入输出必须在 `UB`
   - `GEMM` 输入必须在 `L1`
   - `MMAD` 输入必须在 `L0A/L0B`

2. **数据类型支持**：
   - 向量运算支持：`FP16`, `FP32`, `BF16`, `INT8`
   - 矩阵乘支持：`FP16`, `INT8`

3. **缓存机制**：
   - `tile_op_dispatch` 会缓存计算结果
   - 相同输入参数直接返回缓存，避免重复计算
   - 可通过 `reset_tile_op_cache()` 清空缓存

4. **错误处理**：
   - 不支持的操作码返回 `latency=0, cycles=0`
   - 其他错误返回包含 `error` 和 `error_stack` 的字典