# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from abc import ABC, abstractmethod
from dataclasses import dataclass

from core.common import MemLoc
from core.common.entity import CoreType
from core.config.arc_spec import ArcConfig


@dataclass
class BandwidthEntity:
    burst: int
    burst_len: int
    src_stride: int
    dst_stride: int
    src_addr: str
    dst_addr: str
    mode: str
    core_cnt: int
    padding: bool
    padding_value: str
    src_mem: MemLoc
    dst_mem: MemLoc
    core_type: CoreType


@dataclass
class BandwidthPredictor(ABC):
    arc_config: ArcConfig

    @abstractmethod
    def get_bandwidth(self, req_list: list[BandwidthEntity]) -> float:
        """
        给定一个/多个MTE请求，返回这多个请求的平均带宽
        Args:
            req_list:   请求列表

        Returns:        带宽，单位B/us

        """
        pass
