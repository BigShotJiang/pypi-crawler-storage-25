from core.backend.bandwidth_costmodel.npu.npu_type import NPUBandwidth
import numpy as np
from core.common.entity import MemLoc
from core.common.log_format import logging
import json
import os

logger = logging.getLogger(__name__)


class DavidV100(NPUBandwidth):
    name = "David V100"
    config = None

    @staticmethod
    def get_out_to_ub(config: json, max_core: tuple[int, int], core_num: int = -1) -> float:
        if core_num > max_core[1] or core_num < 0:
            raise ValueError(f'core_num:{core_num} must be <= {max_core[1]} and >=1')
        ret = min(config["one_ai_core_bandwidth"] * core_num, config["hba_max_bandwidth"])
        return ret

    # 返回的单位：GB/s
    @staticmethod
    def get_ub_to_out(config: json, max_core: tuple[int, int], core_num: int = -1) -> float:
        # UB往GM写时，全是写的cache，所以拟合函数是两个线性函数
        if core_num > max_core[1] or core_num < 0:
            raise ValueError(f'core_num:{core_num} must be <= {max_core[1]} and >=1')
        ret = np.piecewise(core_num, [core_num < config["first_linear_core_num"],
                                      core_num >= config["first_linear_core_num"]],
                           [lambda x: config["first_linear_Slope"] * x + config["first_linear_intercept"],
                            lambda x: config["second_linear_Slope"] * x + config["second_linear_intercept"]])
        return ret.item(0)

    path_to_function = {(MemLoc.GM, MemLoc.UB): get_out_to_ub, (MemLoc.UB, MemLoc.GM): get_ub_to_out}

    def __init__(self):
        current_path = os.path.dirname(os.path.abspath(__file__))
        with open(os.path.join(current_path, "../../../../config/arc_config/davidV100/davidV100.json"), "r",
                  encoding="utf-8") as f:
            self.config = json.load(f)
        if self.config is None:
            raise ValueError(f'load jason config from arc_config/davidV100.json failed')

    def get_bandwidth(self, path: tuple[MemLoc, MemLoc], core_num: int = -1) -> float:
        k = path[0].value + "_TO_" + path[1].value
        if k in self.config["path"] and path in self.path_to_function:
            ret = self.path_to_function[path](self.config["path"][k],
                                              (self.config["AIC_core_num"], self.config["AIV_core_num"]), core_num)
        else:
            raise ValueError(f'path:{k} not in config')

        logger.info(f"NPU type {self.name}, bandwidth is {ret}")
        return ret

    def check_path(self, path: tuple[MemLoc, MemLoc]) -> bool:
        k = path[0].value + "_TO_" + path[1].value
        if k in self.config["path"]:
            return True
        else:
            return False
