# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import inspect
from dataclasses import dataclass
from typing import Callable

from core.backend.tile_op_costmodel.tile_op_backend_entity import TileOpEntity, TileOpLatency
from core.common.log_format import logging
from core.common.tile_op_enum import TileOpCode, TileOpType

logger = logging.getLogger(__name__)


@dataclass
class OpRegistryItem:
    opcode: TileOpCode
    op_type: TileOpType
    op_version: int
    handler: Callable


class TileOpRegistry:
    def __init__(self):
        self._tile_ops: dict[tuple[TileOpCode, TileOpType, int], OpRegistryItem] = {}
        self._max_version: dict[tuple[TileOpCode, TileOpType], int] = {}

    def register(self, item: OpRegistryItem):
        key = (item.opcode, item.op_type, item.op_version)
        if key in self._tile_ops:
            raise ValueError(f"Duplicate registration for {key}")
        version_key = (item.opcode, item.op_type)
        old_version = self._max_version.get(version_key, -1)
        new_version = max(old_version, item.op_version)
        self._max_version[version_key] = new_version
        self._tile_ops[key] = item

    def get_max_version(self, opcode: TileOpCode, op_type: TileOpType) -> int:
        key = (opcode, op_type)
        if key not in self._max_version:
            raise KeyError(f"No tile op registered for {key}")
        return self._max_version.get((opcode, op_type))

    def get(self, opcode: TileOpCode, op_type: TileOpType, version: int) -> OpRegistryItem:
        key = (opcode, op_type, version)
        if key not in self._tile_ops:
            raise KeyError(f"No tile op registered for {key}")
        return self._tile_ops[key]


_TILE_OP_REGISTRY = TileOpRegistry()
_TILE_OP_LATENCY_CACHE = {}


@dataclass
class TileOpKey:
    pass


def tile_op_handler(opcode: TileOpCode | list[TileOpCode], op_type: TileOpType | list[TileOpType] = TileOpType.PLAIN,
                    version: int = 0):
    def decorator(func):
        if not callable(func):
            raise TypeError("tile_op_handler decorator expects a callable as the function argument")

        key = (opcode, op_type, version)

        sig = inspect.signature(func)
        params = list(sig.parameters.values())
        if len(params) != 1:
            raise TypeError(
                f"Op '{key}' must have exactly 2 input parameter"
            )

        # TileOpEntity格式校验
        tile_op = params[0]

        input_dto = tile_op.annotation
        if input_dto is inspect.Parameter.empty:
            raise TypeError(
                f"Op '{key}' must annotate input DTO type"
            )

        if not issubclass(input_dto, TileOpEntity):
            raise TypeError(
                f"Input type of op '{key}' must inherit from DTOBase"
            )

        # 返回值校验
        output_dto = sig.return_annotation
        if output_dto is inspect.Signature.empty:
            raise TypeError(
                f"Op '{key}' must annotate return DTO type"
            )

        if not issubclass(output_dto, TileOpLatency):
            raise TypeError(
                f"Return type of op '{key}' must inherit from DTOBase"
            )

        opcode_list = []
        if not isinstance(opcode, list):
            opcode_list.append(opcode)
        else:
            opcode_list = opcode

        op_type_list = []
        if not isinstance(op_type, list):
            op_type_list.append(op_type)
        else:
            op_type_list = op_type

        for single_type in op_type_list:
            for single_code in opcode_list:
                _TILE_OP_REGISTRY.register(
                    OpRegistryItem(
                        opcode=single_code,
                        op_type=single_type,
                        op_version=version,
                        handler=func,
                    )
                )

    return decorator


def reset_tile_op_cache():
    global _TILE_OP_LATENCY_CACHE
    _TILE_OP_LATENCY_CACHE = {}


def tile_op_dispatch(tile_op: TileOpEntity, op_type: TileOpType, version: int = None) -> TileOpLatency:
    if version is None:
        version = _TILE_OP_REGISTRY.get_max_version(tile_op.opcode, op_type)
    tile_op_key = (hash(tile_op), op_type, version)
    cache_latency = _TILE_OP_LATENCY_CACHE.get(tile_op_key)
    if cache_latency is not None:
        return cache_latency

    handler = _TILE_OP_REGISTRY.get(tile_op.opcode, op_type, version)
    latency = handler.handler(tile_op)
    _TILE_OP_LATENCY_CACHE[tile_op_key] = latency
    return latency