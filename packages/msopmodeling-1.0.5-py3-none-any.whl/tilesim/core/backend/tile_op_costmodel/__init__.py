# __init__.py
# 必须先 import pypto_ops，触发注册机制
from .tile_op_registry import tile_op_dispatch
from . import pypto_ops          # 触发 tile-level op 注册
from . import plain_ops
from .pypto_ops import pto