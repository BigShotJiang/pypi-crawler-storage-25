from core.backend.engineering_costmodel.op_model.pto import tadd, tmul, tcvt, trowmax, texp, trowsum, tsub, \
    tmatmul, tmuls, tmin, tmax
from core.backend.engineering_costmodel.op_model.pto.entity import PTOTile
from core.backend.engineering_costmodel.op_model.pto.include.pto_utils import CPTOTile, RoundMode
from core.backend.tile_op_costmodel.pypto_ops.pto.pto_interface import BinaryInst, ReduceInst, UnaryInst, TMATMUL, \
    ScaleInst
from core.backend.tile_op_costmodel.pypto_ops.pto.pto_registry import pto_register


def tile_py2c(pytile: PTOTile) -> CPTOTile:
    row = pytile.rows
    col = pytile.cols
    addr = pytile.addr
    dtype = pytile.precision
    c_tile = CPTOTile(
        row=row,
        col=col,
        addr=addr,
        row_stride=col,
        dtype=dtype,
    )
    return c_tile


pto_version = 'v220'


@pto_register("tadd")
def tile_add(bin_params: BinaryInst, ctx=None) -> int:
    src1 = tile_py2c(bin_params.src1)
    src0 = tile_py2c(bin_params.src0)
    dst = tile_py2c(bin_params.dst)
    return tadd(pto_version, dst, src1, src0)


@pto_register("tsub")
def tile_sub(bin_params: BinaryInst, ctx=None) -> int:
    src1 = tile_py2c(bin_params.src1)
    src0 = tile_py2c(bin_params.src0)
    dst = tile_py2c(bin_params.dst)
    return tsub(pto_version, dst, src1, src0)


@pto_register("tmul")
def tile_mul(bin_params: BinaryInst, ctx=None) -> int:
    src1 = tile_py2c(bin_params.src1)
    src0 = tile_py2c(bin_params.src0)
    dst = tile_py2c(bin_params.dst)
    return tmul(pto_version, dst, src1, src0)


@pto_register("tmin")
def tile_min(bin_params: BinaryInst, ctx=None) -> int:
    src1 = tile_py2c(bin_params.src1)
    src0 = tile_py2c(bin_params.src0)
    dst = tile_py2c(bin_params.dst)
    return tmin(pto_version, dst, src1, src0)


@pto_register("tmax")
def tile_max(bin_params: BinaryInst, ctx=None) -> int:
    src1 = tile_py2c(bin_params.src1)
    src0 = tile_py2c(bin_params.src0)
    dst = tile_py2c(bin_params.dst)
    return tmax(pto_version, dst, src1, src0)


@pto_register("tmuls")
def tile_muls(scalar_params: ScaleInst, ctx=None) -> int:
    src0 = tile_py2c(scalar_params.src0)
    src1 = 1
    dst = tile_py2c(scalar_params.dst)
    return tmuls(pto_version, dst, src0, src1)


@pto_register("tcvt")
def tile_convert(cvt_params: UnaryInst, ctx=None) -> int:
    src = tile_py2c(cvt_params.src)
    dst = tile_py2c(cvt_params.dst)
    mode = RoundMode.CAST_ROUND
    return tcvt(pto_version, src, dst, mode)


@pto_register("texp")
def tile_exp(unary_params: UnaryInst, ctx=None) -> int:
    src = tile_py2c(unary_params.src)
    dst = tile_py2c(unary_params.dst)
    return texp(pto_version, dst, src)


@pto_register("trowmax")
def tile_row_max(reduce_params: ReduceInst, ctx=None) -> int:
    src = tile_py2c(reduce_params.src)
    tmp = tile_py2c(reduce_params.tmp)
    dst = tile_py2c(reduce_params.dst)
    return trowmax(pto_version, dst, src, tmp)


@pto_register("trowsum")
def tile_row_sum(reduce_params: ReduceInst, ctx=None) -> int:
    src = tile_py2c(reduce_params.src)
    tmp = tile_py2c(reduce_params.tmp)
    dst = tile_py2c(reduce_params.dst)
    return trowsum(pto_version, dst, src, tmp)


@pto_register("matmul")
def tile_matmul(matmul_params: TMATMUL, ctx=None) -> int:
    a_matrix = tile_py2c(matmul_params.a_matrix)
    b_matrix = tile_py2c(matmul_params.b_matrix)
    c_matrix = tile_py2c(matmul_params.c_matrix)
    return tmatmul(pto_version, a_matrix, b_matrix, c_matrix)