# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import pkgutil
import importlib
from . import instructions  # 关键：触发所有 pto 指令文件导入，从而完成注册
from .pto_registry import pto_dispatch

# 自动import所有.py文件
for m in pkgutil.iter_modules(__path__):
    if not m.ispkg:
        importlib.import_module(f"{__name__}.{m.name}")