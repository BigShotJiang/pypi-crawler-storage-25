# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from core.backend.tile_op_costmodel.tile_op_backend_entity import TileOpLatency, TileOpEntity
from core.backend.tile_op_costmodel.pypto_ops.pto.pto_registry import pto_dispatch
from core.backend.engineering_costmodel.op_model.pto.entity import PTOTile
from core.backend.tile_op_costmodel.pypto_ops.pto.pto_interface import ReduceInst
from core.backend.tile_op_costmodel.pypto_ops.functions import convert_shapes, get_address, opcode_pto_projection
from core.backend.tile_op_costmodel.tile_op_registry import tile_op_handler, TileOpType
from core.common.entity import CoreUnit
from core.common.tile_op_enum import TileOpCode


def reduce(tile_op: TileOpEntity) -> TileOpLatency:
    opcode = tile_op.opcode
    in_tile = tile_op.i_operand[0]
    tmp = tile_op.i_operand[1]
    out_tile = tile_op.o_operand[0]
    shapes = [in_tile.shape, in_tile.shape, out_tile.shape]
    # 获取地址
    in_addr = get_address(in_tile.offset, in_tile.raw_shape, in_tile.raw_magic, in_tile.start_addr)
    tmp_addr = get_address(tmp.offset, tmp.raw_shape, tmp.raw_magic, tmp.start_addr)
    out_addr = get_address(out_tile.offset, out_tile.raw_shape, out_tile.raw_magic, out_tile.start_addr)
    # 维度转换
    new_shapes, repeat = convert_shapes(shapes, out_tile.data_type_str.size)
    cycles = 0
    src = PTOTile(new_shapes[0][0], new_shapes[0][1], out_tile.data_type_str, in_addr)
    tmp = PTOTile(new_shapes[1][0], new_shapes[1][1], out_tile.data_type_str, tmp_addr)
    dest = PTOTile(new_shapes[2][0], new_shapes[2][1], out_tile.data_type_str, out_addr)
    repeat_times = max(repeat)
    pto_inst = opcode_pto_projection(opcode.value)
    for _ in range(repeat_times):
        # 调用该tile op对应的pto instruction
        cycles += pto_dispatch(pto_inst, ReduceInst(dest, src, tmp))
    latency = cycles / tile_op.context.arc_config.clock_freq
    return TileOpLatency(latency=latency, unit_latency={CoreUnit.VEC: latency}, cycles=cycles)


@tile_op_handler(opcode=[TileOpCode.ROWSUM_SINGLE, TileOpCode.ROWMAX_SINGLE, TileOpCode.ROWMIN_SINGLE], op_type=TileOpType.PyPTO)
def reduce_costmodel(tile_op: TileOpEntity) -> TileOpLatency:
    return reduce(tile_op)


