# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import math
import numpy as np


def convert_shapes(shapes, size):
    if isinstance(shapes[0], int):
        shapes = [shapes]

    new_shapes = []
    repeat = []
    overflow = 1
    _PTO_MAX_BYTES = 32768
    for tile_shape in shapes:
        # 取前5维
        tile_shape = np.array(tile_shape)
        if tile_shape.shape[0] > 5:
            # 返回: (后5个数组, 剩余部分沿0轴的乘积)
            tile_shape = tile_shape[-5:]
            overflow = np.prod(tile_shape[:-5], axis=0, keepdims=True)

        other_dims = tile_shape[:-2]
        scale_factor_1 = math.prod(other_dims)
        # 计算2维
        dim1 = tile_shape[-2]
        dim2 = tile_shape[-1]
        cnt = 0
        # 检查字节限制
        while dim1 * dim2 * size > _PTO_MAX_BYTES:
            if dim1 > 2:  # 切分
                dim1 //= 2
            else:
                dim2 //= 2
            cnt += 1
        new_shapes.append([dim1, dim2])
        scale_factor_2 = 2 ** cnt
        repeat.append(scale_factor_1*overflow*scale_factor_2)

    return new_shapes, repeat


def get_address(offset, raw_shape, raw_magic, start_addr):
    if all(v is None for v in (offset, raw_shape, raw_magic)):
        addr = hex(start_addr)
    else:
        _RAW_MAGIC_MAX_SIZE = 1024 * 1024
        addr = hex(raw_magic * _RAW_MAGIC_MAX_SIZE)
        if np.any(offset):
            for i in range(offset):
                addr += offset[i] * raw_shape[i]
    return addr


def opcode_pto_projection(tileop):
    pto_tileop_map = {
        "add": "tadd",
        "sub": "tsub",
        "mul": "tmul",
        "div": "tdiv",
        "max": "tmax",
        "min": "tmin",
        "adds": "tadds",
        "muls": "tmuls",
        "subs": "tsubs",
        "divs": "tdivs",
        "maxs": "tmaxs",
        "mins": "tmins",
        "a_mul_b": "tmatmul",
        "cast": "tcvt",
        "reduce_sum": "rowsum",
        "reduce_max": "rowmax",
        "reduce_min": "rowmin"
    }
    return pto_tileop_map.get(tileop)


def inst_pto_projection(pto_inst_name: str):
    pto_tileop_map = {
        "TADD": "tadd",
        "TSUB": "tsub",
        "TMUL": "tmul",
        "TDIV": "tdiv",
        "TMAX": "tmax",
        "TMIN": "tmin",
        "TADDS": "tadds",
        "TMULS": "tmuls",
        "TSUBS": "tsubs",
        "TDIVS": "tdivs",
        "TMAXS": "tmaxs",
        "TMINS": "tmins",
        "TMATMUL": "tmatmul",
        "TCVT": "tcvt",
        "TROWSUM": "rowsum",
        "TROWMAX": "rowmax",
        "TROWMIN": "rowmin"
    }
    return pto_tileop_map.get(pto_inst_name)