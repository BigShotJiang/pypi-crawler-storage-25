# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import math

from core.common.entity import VecOpType, CycleType, DType, CoreUnit
from core.common.log_format import logging
from core.backend.tile_op_costmodel.tile_op_backend_entity import TileOpEntity, TileOpLatency
from core.backend.tile_op_costmodel.tile_op_registry import tile_op_handler, TileOpType, TileOpCode

logger = logging.getLogger(__name__)

tile_op_to_inst = {
    TileOpCode.ADD: VecOpType.VADD,
    TileOpCode.SUB: VecOpType.VSUB,
    TileOpCode.MUL: VecOpType.VMUL,
    TileOpCode.DIV: VecOpType.VDIV,
    TileOpCode.MAX: VecOpType.VMAX,
    TileOpCode.MIN: VecOpType.VMIN,
    TileOpCode.ADDS: VecOpType.VADDS,
    TileOpCode.SUBS: VecOpType.VSUBS,
    TileOpCode.MULS: VecOpType.VMULS,
    TileOpCode.DIVS: VecOpType.VDIVS,
    TileOpCode.MAXS: VecOpType.VMAXS,
    TileOpCode.MINS: VecOpType.VMINS,
    TileOpCode.ABS: VecOpType.VABS,
    TileOpCode.EXP: VecOpType.VEXP,
    TileOpCode.SQRT: VecOpType.VSQRT,
    TileOpCode.RELU: VecOpType.RELU,
    TileOpCode.BROADCAST: VecOpType.VBRCB,
    TileOpCode.SELECT: VecOpType.VSEL,
    TileOpCode.NOT_EQUAL: VecOpType.VCMPV_NE,
    TileOpCode.GREATER_EQUAL: VecOpType.VCMPV_GE,
    TileOpCode.LOG: VecOpType.LOG,
    TileOpCode.TRANSPOSE: VecOpType.VTRANS
}


@tile_op_handler(opcode=[TileOpCode.ADD, TileOpCode.SUB, TileOpCode.MUL, TileOpCode.DIV, TileOpCode.MAX, TileOpCode.MIN,
                         TileOpCode.ABS, TileOpCode.EXP, TileOpCode.SQRT, TileOpCode.RELU, TileOpCode.LOG,
                         TileOpCode.MULS, TileOpCode.ADDS, TileOpCode.SUBS, TileOpCode.DIVS, TileOpCode.MAXS,
                         TileOpCode.MINS, TileOpCode.BROADCAST, TileOpCode.SELECT, TileOpCode.NOT_EQUAL,
                         TileOpCode.GREATER_EQUAL, TileOpCode.TRANSPOSE
                         ],
                 op_type=TileOpType.PLAIN)
def plain_simple_op_based_on_cce(tile_op: TileOpEntity) -> TileOpLatency:
    arc_config = tile_op.context.arc_config
    # 基础指令，可以直接关联cce名称
    vec_inst = tile_op_to_inst.get(tile_op.opcode)
    if vec_inst is None:
        raise KeyError(f"tile_op {tile_op.opcode} is not supported in plain_simple_op_based_on_cce now")

    input_tile = tile_op.i_operand[0]
    input_d_type = input_tile.data_type_str
    repeats = math.ceil(
        math.prod(input_tile.shape) * input_d_type.size / arc_config.vec_config.vec_size_single_repeat[input_d_type])
    cycles = arc_config.lookup_vec_cycle(vec_inst, input_d_type, CycleType.COMPUTING_CYCLES)

    cycles *= repeats

    if tile_op.context.barrier:
        cycles += arc_config.lookup_vec_cycle(vec_inst, input_d_type, CycleType.INTERVAL_CYCLES)

    latency = cycles / arc_config.clock_freq
    return TileOpLatency(latency=latency, unit_latency={CoreUnit.VEC: latency}, cycles=cycles)


@tile_op_handler(opcode=[TileOpCode.REDUCE_SUM, TileOpCode.REDUCE_MAX, TileOpCode.REDUCE_MIN], op_type=TileOpType.PLAIN)
def plain_reduce_op_based_on_cce(tile_op: TileOpEntity) -> TileOpLatency:
    arc_config = tile_op.context.arc_config

    # 基础指令，可以直接关联cce名称
    input_tile = tile_op.i_operand[0]
    input_d_type = input_tile.data_type_str

    if tile_op.opcode == TileOpCode.REDUCE_SUM:
        basic_op = VecOpType.VADD
        reduce_op = VecOpType.VCGADD
    elif tile_op.opcode == TileOpCode.REDUCE_MAX:
        basic_op = VecOpType.VMAX
        reduce_op = VecOpType.VCGMAX
    elif tile_op.opcode == TileOpCode.REDUCE_MIN:
        basic_op = VecOpType.VMIN
        reduce_op = VecOpType.VCGMAX
    else:
        raise Exception(f"not support opcode {tile_op.opcode.name}")

    # 一次repeat执行多少元素
    elements_single_repeat = arc_config.vec_config.vec_size_single_repeat[input_d_type] / input_d_type.size
    repeats = math.ceil(math.prod(input_tile.shape) / elements_single_repeat)

    cycles = 0
    compute_cycle_reduce = arc_config.lookup_vec_cycle(reduce_op, input_d_type, CycleType.COMPUTING_CYCLES)
    # 不需要基础操作
    if repeats == 1:
        cycles += compute_cycle_reduce
        if tile_op.context.barrier:
            cycles += arc_config.lookup_vec_cycle(reduce_op, input_d_type, CycleType.INTERVAL_CYCLES)
    else:
        basic_repeat = 0
        loop = 1 if tile_op.context.barrier else 0
        while repeats > 1:
            loop += 1
            basic_repeat += repeats - 1
            repeats = math.ceil(repeats / elements_single_repeat)
        compute_cycle_basic = arc_config.lookup_vec_cycle(basic_op, input_d_type, CycleType.COMPUTING_CYCLES)
        interval_basic_cycle = arc_config.lookup_vec_cycle(basic_op, input_d_type, CycleType.INTERVAL_CYCLES)
        interval_cycle_reduce = arc_config.lookup_vec_cycle(reduce_op, input_d_type, CycleType.INTERVAL_CYCLES)

        # 基础操作的计算时间
        cycles += basic_repeat * compute_cycle_basic
        # 每轮内部可以进行并行，但是两轮之间需要同步
        cycles += loop * interval_basic_cycle
        # 最后一轮的reduce操作
        cycles += compute_cycle_reduce + interval_cycle_reduce
    latency = cycles / arc_config.clock_freq
    return TileOpLatency(latency=latency, unit_latency={CoreUnit.VEC: latency}, cycles=cycles)


@tile_op_handler(opcode=TileOpCode.CAST, op_type=TileOpType.PLAIN)
def plain_cast(tile_op: TileOpEntity) -> TileOpLatency:
    src_tensor = tile_op.i_operand[0]
    dst_tensor = tile_op.o_operand[0]
    if src_tensor.buffer_type != dst_tensor.buffer_type:
        raise Exception("cast input and output should in the same mem")

    if src_tensor.data_type_str.size == dst_tensor.data_type_str.size:
        logger.warning("cast instruction with same size, skip this instruction")
        return TileOpLatency(latency=0, unit_latency={}, cycles=0)

    vec_inst = None
    if src_tensor.data_type_str == DType.FP32:
        if dst_tensor.data_type_str == DType.FP16:
            vec_inst = VecOpType.CONV_F322F16
        elif dst_tensor.data_type_str == DType.BF16:
            vec_inst = VecOpType.CONV_F322BF16
    elif src_tensor.data_type_str == DType.FP16:
        if dst_tensor.data_type_str == DType.FP32:
            vec_inst = VecOpType.CONV_F162F32
    elif src_tensor.data_type_str == DType.BF16:
        if dst_tensor.data_type_str == DType.FP32:
            vec_inst = VecOpType.CONV_BF162F32

    if vec_inst is None:
        logger.warning(f"not support cast from {src_tensor.data_type_str} to {dst_tensor.data_type_str}")
        vec_inst = VecOpType.CONV_F322F16  # NEXT -- 测试更多的指令

    arc_config = tile_op.context.arc_config
    repeats = math.ceil(
        math.prod(src_tensor.shape) * src_tensor.data_type_str.size / arc_config.vec_config.vec_size_single_repeat.get(
            src_tensor.data_type_str))
    cycles = arc_config.lookup_vec_cycle(vec_inst, src_tensor.data_type_str, CycleType.COMPUTING_CYCLES)

    cycles *= repeats

    if tile_op.context.barrier:
        cycles += arc_config.lookup_vec_cycle(vec_inst, src_tensor.data_type_str, CycleType.INTERVAL_CYCLES)

    latency = cycles / arc_config.clock_freq
    return TileOpLatency(latency=latency, unit_latency={CoreUnit.VEC: latency}, cycles=cycles)


@tile_op_handler(opcode=[TileOpCode.VIEW, TileOpCode.ASSEMBLE, TileOpCode.BARRIER, TileOpCode.NULL_OP, TileOpCode.ALLOC,
                         TileOpCode.SET_FLAG, TileOpCode.WAIT_FLAG],
                 op_type=[TileOpType.PLAIN, TileOpType.PyPTO])
def plain_empty(tile_op: TileOpEntity) -> TileOpLatency:
    return TileOpLatency(latency=0, unit_latency={}, cycles=0)


@tile_op_handler(opcode=TileOpCode.SCALAR_AIC, op_type=[TileOpType.PLAIN])
def plain_scalar_aic(tile_op: TileOpEntity) -> TileOpLatency:
    """
    Scalar 操作的时延计算

    arith. 开头的操作是 Scalar 操作，在 AIC_S 或 AIV_S 上执行
    返回1cycle的耗时
    """
    arc_config = tile_op.context.arc_config
    SCALAR_OP_LATENCY = 1 / arc_config.clock_freq  # 1cycle的耗时
    unit_latency = {CoreUnit.AIC_SCALAR: SCALAR_OP_LATENCY}

    return TileOpLatency(latency=SCALAR_OP_LATENCY, unit_latency=unit_latency, cycles=1)


@tile_op_handler(opcode=TileOpCode.SCALAR_AIV, op_type=[TileOpType.PLAIN])
def plain_scalar_aiv(tile_op: TileOpEntity) -> TileOpLatency:
    """
    Scalar 操作的时延计算

    arith. 开头的操作是 Scalar 操作，在 AIC_S 或 AIV_S 上执行
    返回1cycle的耗时
    """
    arc_config = tile_op.context.arc_config
    SCALAR_OP_LATENCY = 1 / arc_config.clock_freq  # 1cycle的耗时
    unit_latency = {CoreUnit.AIV_SCALAR: SCALAR_OP_LATENCY}

    return TileOpLatency(latency=SCALAR_OP_LATENCY, unit_latency=unit_latency, cycles=1)