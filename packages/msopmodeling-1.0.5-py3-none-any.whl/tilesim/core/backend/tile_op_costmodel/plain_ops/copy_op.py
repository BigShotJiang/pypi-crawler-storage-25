# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import math

from core.backend.tile_op_costmodel.tile_op_backend_entity import TileOpEntity, TileOpLatency
from core.backend.tile_op_costmodel.tile_op_registry import tile_op_handler
from core.common.entity import MemLoc, VecOpType, CycleType
from core.common.log_format import logging
from core.common.tile_op_enum import TileOpCode, TileOpType

logger = logging.getLogger(__name__)


@tile_op_handler(opcode=TileOpCode.COPY, op_type=TileOpType.PLAIN)
def plain_copy(tile_op: TileOpEntity) -> TileOpLatency:
    if len(tile_op.i_operand) != 1 or len(tile_op.o_operand) != 1:
        raise Exception("copy should have one input and one output")

    src_tile = tile_op.i_operand[0]
    dst_tile = tile_op.o_operand[0]

    src_mem = src_tile.buffer_type
    dst_mem = dst_tile.buffer_type
    context = tile_op.context

    data_transfer = {}
    small_pkt_transfer = {}
    if src_mem == MemLoc.UB and dst_mem == MemLoc.UB:
        # VCOPY指令
        arc_config = context.arc_config
        vec_inst = VecOpType.from_str('VCOPY')

        input_d_type = src_tile.data_type_str
        repeats = math.ceil(
            math.prod(dst_tile.shape) * input_d_type.size / arc_config.vec_config.vec_size_single_repeat[input_d_type])
        cycles = arc_config.lookup_vec_cycle(vec_inst, input_d_type, CycleType.COMPUTING_CYCLES)

        cycles *= repeats

        if context.barrier:
            cycles += arc_config.lookup_vec_cycle(vec_inst, input_d_type, CycleType.INTERVAL_CYCLES)

        latency = cycles / arc_config.clock_freq
    else:
        # MTE指令
        # NEXT 可能会存在携带转置之类的随路操作，先暂时不考虑
        if src_tile.shape != dst_tile.shape:
            logger.warning("copy input and output shape should be the same")

        data_size = math.prod(dst_tile.shape) * dst_tile.data_type_str.size
        bw, is_small_pkt = context.arc_config.lookup_bw(src_mem, dst_mem, context.core_num, pkt_size=data_size if context.enable_small_pkt_bw else -1)
        latency = data_size / bw
        data_transfer = {
            (src_mem, dst_mem): data_size
        }
        if is_small_pkt:
            small_pkt_transfer = {
                (src_mem, dst_mem): data_size
            }
        cycles = int(latency * context.arc_config.clock_freq)
    core_unit = TileOpCode.COPY.get_core_units(src_mem, dst_mem)[0]

    return TileOpLatency(latency=latency, unit_latency={core_unit: latency}, data_transfer=data_transfer, cycles=cycles, small_pkt_transfer=small_pkt_transfer)