# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from core.backend.backend_entity.backend_logistic import LogisticEntity
from core.backend.backend_entity.backend_math import EvalCtxEntity
from core.backend.theoretical_costmodel.evaluation.optimal_pipeline.optimal_pipeline_theo_model import OptimalPipelineModel
from core.common.backend_config import BackendConfig, EvaluationType
from core.pipeline.basic_operator import OperatorResult


def theo_eval_dispatch(backend_input: BackendConfig, eval_ctx: EvalCtxEntity, op_list: list[LogisticEntity], eval_type: EvaluationType = EvaluationType.THEO_OPTIMAL_PIPE) -> OperatorResult:
    if eval_type == EvaluationType.THEO_OPTIMAL_PIPE:
        theo_eval = OptimalPipelineModel(backend_input, eval_ctx)
    else:
        raise ValueError(f'Unsupported eval type: {eval_type}')

    return theo_eval.eval(op_list)