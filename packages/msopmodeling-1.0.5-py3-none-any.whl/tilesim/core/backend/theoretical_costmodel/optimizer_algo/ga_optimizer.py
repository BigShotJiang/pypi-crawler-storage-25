# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import math

import matplotlib.pyplot as plt
import numpy as np
from pygad import pygad

from core.backend.theoretical_costmodel.optimizer_algo.optimizer_algo import OptimizerAlgo

# 设置中文字体支持
plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False


class Optimizer(OptimizerAlgo):
    def __init__(self, value_func, params_range, step, iter_num=500):
        super().__init__(value_func, params_range, step)
        # 存储优化过程数据用于可视化
        self.best_fitness_history = []
        self.avg_fitness_history = []
        self.solution_history = []
        self.generation_history = []
        self.step = step[0]
        self.iter_num = iter_num
        # 定义约束条件函数
        self.constraint_funcs = []

    def add_constraint(self, constraint_func):
        """添加约束条件函数"""
        self.constraint_funcs.append(constraint_func)

    def set_constraint(self, constraint_func):
        """设置单个约束条件（向后兼容）"""
        self.constraint_funcs = [constraint_func]

    def _check_constraints(self, chromosome):
        """检查所有约束条件"""
        if not self.constraint_funcs:
            return True

        for constraint_func in self.constraint_funcs:
            if not constraint_func(chromosome.tolist()):
                return False
        return True

    def _custom_mutation(self, offspring, ga_instance):
        """自定义变异函数，确保变异后的解满足所有约束条件"""
        for chromosome_idx in range(offspring.shape[0]):
            self._apply_random_mutation(offspring[chromosome_idx], ga_instance)

            # 检查所有约束条件
            max_attempts = 200
            attempt = 0

            while not self._check_constraints(offspring[chromosome_idx]) and attempt < max_attempts:
                self._apply_random_mutation(offspring[chromosome_idx], ga_instance)
                attempt += 1

        return offspring

    def _apply_random_mutation(self, chromosome, ga_instance):
        """应用随机变异到单个染色体，根据参数范围生成新值"""
        # 获取变异概率
        mutation_probability = ga_instance.mutation_probability
        if mutation_probability is None:
            mutation_probability = ga_instance.mutation_percent_genes / 100

        # 对每个基因进行变异
        for gene_idx in range(chromosome.shape[0]):
            # 随机决定是否变异这个基因
            if np.random.random() < mutation_probability:
                # 获取该基因的可行解列表
                gene_space = ga_instance.gene_space[gene_idx]

                self._mutate_gene_value(chromosome, gene_idx, gene_space)

    def _mutate_gene_value(self, chromosome, gene_idx, gene_space):
        if isinstance(gene_space, list):
            # 如果gene_space是列表（可行解列表），从列表中随机选择一个值
            # 确保不选择当前值（除非只有一个选择）
            current_value = chromosome[gene_idx]
            available_values = [val for val in gene_space if val != current_value]

            if available_values:
                new_value = np.random.choice(available_values)
                chromosome[gene_idx] = new_value
            # 如果只有一个值可选，保持原值不变
        else:
            # 如果gene_space是字典（范围），保持原有逻辑
            low = gene_space['low']
            high = gene_space['high']
            step = gene_space.get('step', 1)

            # 生成新的随机值
            if step > 0:
                # 离散值
                num_steps = int((high - low) / step) + 1
                new_value = low + np.random.randint(0, num_steps) * step
            else:
                # 连续值
                new_value = np.random.uniform(low, high)

            chromosome[gene_idx] = new_value

    def optimize(self) -> tuple[list[float], float]:
        # 定义适应度函数（由于pygad默认最大化适应度，我们取负值以实现最小化）
        def fitness_func(ga_instance, sol, solution_idx):
            # 调用价值函数
            value = self.value_func(sol.tolist())
            # 取负值，因为pygad默认最大化适应度
            return -value[0]

        # 设置基因空间（每个变量的可行解列表）
        gene_space = []
        for i, param_range in enumerate(self.params_range):
            low, high = param_range

            # 检查是否是固定值参数
            if low == high:
                gene_space.append([low])  # 使用列表表示固定值
            else:
                # 检查范围是否满足步长要求
                if high - low < self.step:
                    # 如果范围小于步长，使用步长为1
                    step = high - low
                else:
                    step = self.step

                # 根据范围和步长生成可行解列表
                # 确保范围是步长的倍数
                adjusted_low = ((low + step - 1) // step) * step
                adjusted_high = ((high + step - 1) // step) * step

                # 生成可行解列表
                num_values = int((adjusted_high - adjusted_low) / step) + 1
                feasible_values = [adjusted_low + j * step for j in range(num_values)]

                # 确保值在原始范围内
                feasible_values = [val for val in feasible_values if low <= val <= high]

                # 如果没有可行解，使用原始范围的中点
                if not feasible_values:
                    feasible_values = [math.ceil((low + high) / 2)]

                gene_space.append(feasible_values)

        # 配置遗传算法参数
        num_generations = self.iter_num  # 迭代次数
        num_parents_mating = 10  # 交配的父代数量
        sol_per_pop = 50  # 种群大小
        num_genes = self.n_params  # 基因数量（变量数量）

        # 创建遗传算法实例
        ga_instance = pygad.GA(
            num_generations=num_generations,
            num_parents_mating=num_parents_mating,
            fitness_func=fitness_func,
            sol_per_pop=sol_per_pop,
            num_genes=num_genes,
            gene_space=gene_space,
            parent_selection_type="sss",  # 稳态选择
            keep_parents=1,  # 保留父代数量
            crossover_type="single_point",  # 单点交叉
            mutation_type=self._custom_mutation,  # 使用自定义变异函数
            mutation_percent_genes=20,  # 突变百分比
            on_generation=self._callback_generation  # 添加回调函数记录每代数据
        )

        # 运行遗传算法
        ga_instance.run()

        # 获取最佳解
        solution, solution_fitness, _ = ga_instance.best_solution()

        # 由于适应度函数取了负值，这里需要转换回原始值
        best_value = -solution_fitness

        return solution.tolist(), best_value

    def _callback_generation(self, ga_instance):
        """回调函数，记录每一代的数据"""
        generation = ga_instance.generations_completed
        best_fitness = -ga_instance.best_solution()[1]  # 转换为原始值
        avg_fitness = -np.mean(ga_instance.last_generation_fitness)  # 转换为原始值

        self.generation_history.append(generation)
        self.best_fitness_history.append(best_fitness)
        self.avg_fitness_history.append(avg_fitness)
        self.solution_history.append(ga_instance.best_solution()[0].tolist())

    def visualize(self, fig_size=(12, 8)):
        """可视化优化过程和结果"""
        if not self.generation_history:
            logger.warning("没有可用的优化数据，请先运行optimize()方法")
            return

        plt.figure(figsize=fig_size)

        # 1. 绘制适应度变化曲线
        plt.subplot(2, 2, 1)
        plt.plot(self.generation_history, self.best_fitness_history, 'b-', label='最佳适应度')
        plt.plot(self.generation_history, self.avg_fitness_history, 'r--', label='平均适应度')
        plt.xlabel('代数')
        plt.ylabel('适应度值')
        plt.title('适应度随代数的变化')
        plt.legend()
        plt.grid(True)

        # 2. 绘制参数变化轨迹
        plt.subplot(2, 2, 2)
        solutions = np.array(self.solution_history)
        for i in range(self.n_params):
            plt.plot(self.generation_history, solutions[:, i], label=f'参数 {i + 1}')
        plt.xlabel('代数')
        plt.ylabel('参数值')
        plt.title('参数随代数的变化')
        plt.legend()
        plt.grid(True)

        # 3. 绘制最后一代的参数分布
        plt.subplot(2, 2, 3)
        # 这里需要访问pygad内部数据，由于pygad不直接提供，我们可以跳过或使用其他方法
        # 作为替代，我们可以显示最优解的参数构成
        best_solution = self.solution_history[-1]
        param_labels = [f'参数 {i + 1}' for i in range(self.n_params)]
        plt.bar(param_labels, best_solution)
        plt.ylabel('参数值')
        plt.title('最优解的参数构成')

        # 4. 显示最优解的信息
        plt.subplot(2, 2, 4)
        plt.axis('off')
        best_value = self.best_fitness_history[-1]
        info_text = f"最优值: {best_value:.4f}\n\n最优解:\n"
        for i, param in enumerate(best_solution):
            info_text += f"参数 {i + 1}: {param:.2f}\n"

        info_text += f"\n总代数: {len(self.generation_history)}"
        plt.text(0.1, 0.9, info_text, fontsize=12, verticalalignment='top')
        plt.title('优化结果摘要')

        plt.tight_layout()
        plt.show()