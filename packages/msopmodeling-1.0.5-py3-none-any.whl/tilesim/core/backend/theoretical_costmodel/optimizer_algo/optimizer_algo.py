# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

from abc import ABC, abstractmethod
from collections.abc import Callable


class OptimizerAlgo(ABC):

    def __init__(self, value_func: Callable[[list[float]], list[float]],
                 params_range: list[tuple[float, float]], step: list[float]):
        """
        给定价值函数，取值范围，初始化优化函数
        :param value_func:      价值函数，入参1 list，表示n个决策变量； 入参2 算子基本信息；返回 float，表示n个决策变量对应到的函数值
        :param params_range:    n个决策变量的取值范围
        :param step:            入参步长
        """
        self.n_params = len(params_range)
        self.value_func = value_func
        self.params_range = params_range
        self.step = step

    @abstractmethod
    def optimize(self) -> tuple[list[float], float]:
        """
        优化求解
        :return:    [最优解的决策变量值，最优解决策变量的函数值]
        """
        pass