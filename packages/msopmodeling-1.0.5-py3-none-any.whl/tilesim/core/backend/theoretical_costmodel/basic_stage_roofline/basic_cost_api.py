import math
from dataclasses import dataclass

from enum import Enum
from core.config.arc_spec import ArcConfig
from core.common.entity import VecOpType, DType, CycleType, MemLoc


class ModelLevel(Enum):
    """模型等级"""
    MODEL_L0 = 0
    MODEL_L1 = 1
    MODEL_L2 = 2
    MODEL_L3 = 3


missing_inst_d_type = {
    "VCMPV_NE": {
        "INT64": "FP32"
    },
    "VSEL": {
        "INT32": "FP32",
        "i1": "FP32"
    },
    "VMUL": {
        "INT32": "FP32"
    },
    "VADD": {
        "INT32": "FP32"
    },
    "VBRCB": {
        "INT32": "FP32"
    }
}


@dataclass
class EventCost:
    # 组件名称
    component_name: str
    # 组件的指令花费时间
    cost_time: float
    # 指令结束时间点
    end_time: float = 0.0


@dataclass
class TensorData:
    """张量数据类，用于表示提取出的算子信息"""
    # NEXT -- 与tilesim_dsl/common/tensor.py下同名类需要统一
    # 张量在ttir中的名称，一般用百分号加数字表示
    name: str
    # 张量形状
    shape: list[int]
    # 数据格式
    d_type: str
    # 所在Mem location
    mem_loc: str
    # 地址（首元素地址）
    address: str
    # 搬运size 
    d_size: str = "big_pkt"


@dataclass
class InstEvent:
    # 指令的编号
    event_id: int
    # 指令的输入tensor
    input_tensors: list[TensorData]
    # 指令的输出tensor
    output_tensors: list[TensorData]
    # 指令名称
    inst_name: str = ""
    # 在原始ttir中的指令名称
    raw_inst_name: str = ""
    # 本条指令依赖的其他指令编号
    event_depend_id: list[int] = None


def mte2_cost_model(vec_inst: InstEvent, past_events: list[EventCost], arc_config: ArcConfig,
                    model_level=ModelLevel.MODEL_L3) -> EventCost:
    """
    计算MTE2搬运指令的花费时间
    tensor: 搬运的额张量，给定了形状、地址
    config: 额外的信息输入，比如核数等
    拟合二次函数表达 数据量与MTE2带宽的关系
    """
    tensor = vec_inst.input_tensors[0]
    datasize = DType.from_str(tensor.d_type).size
    total_elements = 1
    for dim in tensor.shape:
        total_elements *= dim

    data_size_bytes = total_elements * datasize

    if model_level == ModelLevel.MODEL_L3:
        # GM->L2带宽是标称带宽
        standard_bw, _ = arc_config.lookup_bw(MemLoc.GM, MemLoc.L2)
        standard_bw = standard_bw / arc_config.core_config.vec_core_num
    elif model_level == ModelLevel.MODEL_L2:
        inner_dim_size = tensor.shape[-1] * datasize
        standard_bw, _ = arc_config.lookup_bw(MemLoc.GM, MemLoc.L2, -1, inner_dim_size)
        if inner_dim_size >= 256:
            # davidV100下，小包搬运直接返回单核带宽，而大包搬运返回总带宽，所以要除以核数
            standard_bw = standard_bw * 0.9 / arc_config.core_config.vec_core_num

    mte2_time = data_size_bytes / standard_bw
    event_start_time = 0
    for i, past_event in enumerate(past_events):
        if i in vec_inst.event_depend_id or past_event.component_name == "MTE2" or past_event.component_name == "MTE3":
            event_start_time = max(event_start_time, past_event.end_time)
    return EventCost("MTE2", mte2_time, event_start_time + mte2_time)


def mte3_cost_model(vec_inst: InstEvent, past_events: list[EventCost], arc_config: ArcConfig,
                    model_level=ModelLevel.MODEL_L3) -> EventCost:
    """
    计算MTE3搬运指令的花费时间
    tensor: 搬运的额张量，给定了形状、地址
    config: 额外的信息输入，比如核数等
    """
    tensor = vec_inst.input_tensors[0]
    datasize = DType.from_str(tensor.d_type).size
    total_elements = 1
    for dim in tensor.shape:
        total_elements *= dim

    data_size_bytes = total_elements * datasize
    standard_bw, _ = arc_config.lookup_bw(MemLoc.GM, MemLoc.L2)
    standard_bw = standard_bw / arc_config.core_config.vec_core_num  # 标称带宽，与mte2相同
    mte3_time = data_size_bytes / standard_bw
    event_start_time = 0
    for i, past_event in enumerate(past_events):
        if i in vec_inst.event_depend_id or past_event.component_name == "MTE3" or past_event.component_name == "MTE2":
            event_start_time = max(event_start_time, past_event.end_time)
    return EventCost("MTE3", mte3_time, event_start_time + mte3_time)


compute_dict = {}


def vec_instruction_cost_model(vec_inst: InstEvent, past_events: list[EventCost], arc_config: ArcConfig) -> EventCost:
    """
    vec指令计算时间
    tensors:    指令输入
    inst_name:  指令名称
    config:     其他额外的输入，比如cce指令的相关参数
    """

    tensors = vec_inst.input_tensors
    inst_name = vec_inst.inst_name
    freq = arc_config.clock_freq
    d_type = tensors[0].d_type
    vec_op_type = VecOpType(inst_name)
    if inst_name in missing_inst_d_type.keys() and d_type in missing_inst_d_type[inst_name].keys():
        vec_op_dtype = DType.from_str(missing_inst_d_type[inst_name][d_type])
    else:
        vec_op_dtype = DType.from_str(d_type)

    basic_tensor_size = DType.from_str(d_type).size
    for dim in tensors[0].shape:
        basic_tensor_size *= dim

    basic_vec_throughput = arc_config.vec_config.vec_size_single_repeat[vec_op_dtype]
    repeats = math.ceil(basic_tensor_size / basic_vec_throughput)
    compute_cycles = arc_config.lookup_vec_cycle(vec_op_type, vec_op_dtype, CycleType.COMPUTING_CYCLES) * repeats
    pipe_cycles = 0

    compute_dict[inst_name] = compute_dict.get(inst_name, 0) + compute_cycles

    vec_time = (compute_cycles + pipe_cycles) / freq
    event_start_time = 0
    for i, past_event in enumerate(past_events):
        if i in vec_inst.event_depend_id or past_event.component_name == "Vec":
            event_start_time = max(event_start_time, past_event.end_time)
    return EventCost("Vec", vec_time, event_start_time + vec_time)


def raw_ir_cost_model(vec_inst: InstEvent, past_events: list[EventCost]) -> EventCost:
    """对于仅构建依赖关系的ir进行结束时延计算"""
    event_start_time = 0
    for i, past_event in enumerate(past_events):
        if i in vec_inst.event_depend_id:
            event_start_time = max(event_start_time, past_event.end_time)
    return EventCost("raw", 0, event_start_time)


def analyze_parallel_result(event_cost_list: list[EventCost], tile_num, model_level=ModelLevel.MODEL_L3) -> tuple[
    float, float, float, float]:
    """
    输入各种指令级的预测时间，进行流水掩盖的分析，得到总的时间
    """
    if event_cost_list[0].component_name != "MTE2":
        raise ValueError("首个event不属于MTE2组件，该行为不支持")
    if event_cost_list[-1].component_name != "MTE3":
        raise ValueError("最后一个event不属于MTE3组件，该行为不支持")

    event_time_dict = {}
    for event in event_cost_list:
        if event.component_name not in event_time_dict:
            event_time_dict[event.component_name] = event.cost_time
        else:
            event_time_dict[event.component_name] += event.cost_time

    mte2_time_per_tile = event_time_dict.get("MTE2", 0)
    mte3_time_per_tile = event_time_dict.get("MTE3", 0)
    compute_time_per_tile = event_time_dict.get("Vec", 0)
    if model_level == ModelLevel.MODEL_L3:
        # L3级别不考虑同步依赖
        tail_time = 0 if event_time_dict.get("MTE3", 0) > event_time_dict.get("MTE2", 0) else event_cost_list[
            -1].cost_time
        e2e_time_per_tile = max(compute_time_per_tile, mte2_time_per_tile, mte3_time_per_tile) + tail_time
    else:
        e2e_time_per_tile = event_cost_list[-1].end_time
    # tile之间的MTE2&3可以并行，需要减去多算的时间
    parallel_time_between_tile = min(event_cost_list[0].cost_time, event_cost_list[-1].cost_time)
    e2e_time = e2e_time_per_tile * tile_num - parallel_time_between_tile * (tile_num - 1)

    return e2e_time, mte2_time_per_tile * tile_num, mte3_time_per_tile * tile_num, compute_time_per_tile * tile_num


def get_ttir_op_time(inst_event_list, tile_num, arc_config, model_level=ModelLevel.MODEL_L3):
    events: list[EventCost] = []
    for vec_inst in inst_event_list:
        if vec_inst.inst_name == "MTE2":
            events.append(mte2_cost_model(vec_inst, events, arc_config, model_level))
        elif vec_inst.inst_name == "MTE3":
            events.append(mte3_cost_model(vec_inst, events, arc_config, model_level))
        elif "(raw)" in vec_inst.inst_name:
            events.append(raw_ir_cost_model(vec_inst, events))
        else:
            events.append(vec_instruction_cost_model(vec_inst, events, arc_config))
    return analyze_parallel_result(events, tile_num, model_level)
