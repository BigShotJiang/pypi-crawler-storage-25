# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from typing import Any

from core.backend.backend_entity.backend_logistic import SubTaskEntity
from core.backend.backend_entity.ir_to_entity import BackendEntity
from core.common.backend_config import BackendConfig
from core.backend.engineering_costmodel.optim.optim import Optim


def _assign_indices_to_blocks_naive(max_i, max_j, core_num):
    """
    将二维索引(i,j)分配到不同的block中
    """
    block_dict = {}  # {block_id: [tile_indices]}
    block_id = 0
    task_assign_result = []
    for i in range(max_i):
        for j in range(max_j):
            block_dict.setdefault(block_id, []).append([i, j])
            task_assign_result.append((i, j, block_id))
            block_id += 1
            if block_id == core_num:
                block_id = 0

    return block_dict, task_assign_result


class OptimMatMulImpl(Optim):
    def __init__(self, backend_config: BackendConfig, backend_entity: BackendEntity):
        super().__init__(backend_config, backend_entity)

    def _default_tuning_generate(self) -> list[dict[str, Any]]:
        candidates = [
            {
                'tm': 256,
                'tn': 128,
                'tk': 128
            },
            {
                'tm': 128,
                'tn': 256,
                'tk': 128
            }
        ]
        return candidates

    def _generate_sub_task(self, tuning_candidate: list) -> list[SubTaskEntity]:
        ctx = self.backend_entity.eval_ctx.env
        t_m = tuning_candidate['tm']
        t_n = tuning_candidate['tn']
        max_i = ctx['M_0'] // t_m
        max_j = ctx['N_0'] // t_n
        sub_task_entities = []
        self.backend_entity.eval_ctx.assign('m_c_0', t_m)
        self.backend_entity.eval_ctx.assign('n_c_0', t_n)

        for task_entity in self.backend_entity.task_dict.values():
            block_dict, task_assign_result = _assign_indices_to_blocks_naive(max_i, max_j, self.backend_config.aic_core_num)
            idx = 0
            for i, j, block_id in task_assign_result:
                sub_task_entity = SubTaskEntity(root_task_name=task_entity.name,
                                                index=idx,
                                                core_idx=block_id,
                                                indices={'i_0': i, 'j_0': j},
                                                root_task=task_entity
                                                )
                sub_task_entities.append(sub_task_entity)
        return sub_task_entities