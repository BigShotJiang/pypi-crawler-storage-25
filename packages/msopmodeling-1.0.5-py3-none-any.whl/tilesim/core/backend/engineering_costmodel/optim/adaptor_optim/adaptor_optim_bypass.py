# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

from core.backend.backend_entity.backend_logistic import SubTaskEntity
from core.backend.engineering_costmodel.optim.optim import Optim


class OptimAdaptorImpl(Optim):
    def _generate_sub_task(self, tuning_candidate: list) -> list[SubTaskEntity]:
        sub_task_list = []
        idx = 0
        for task_entity in self.backend_entity.task_dict.values():
            sub_task_entity = SubTaskEntity(
                root_task_name=task_entity.name,
                index=idx,
                core_idx=0,
                root_task=task_entity
            )
            sub_task_list.append(sub_task_entity)
            idx += 1
        return sub_task_list