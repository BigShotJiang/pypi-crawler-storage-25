import json
from abc import abstractmethod, ABC
from copy import copy
from typing import Any

from core.backend.backend_entity.backend_context import bind_version
from core.backend.backend_entity.backend_entity import VarEntity
from core.backend.backend_entity.backend_logistic import SubTaskEntity
from core.backend.backend_entity.ir_to_entity import BackendEntity
from core.common.log_format import logging
from core.common.backend_config import BackendConfig
from core.backend.engineering_costmodel.evaluation.eng_evaluation_dispatch import eng_eval_dispatch
from core.pipeline.basic_operator import OperatorResult

logger = logging.getLogger(__name__)


class Optim(ABC):
    def __init__(self, backend_config: BackendConfig, backend_entity: BackendEntity):
        self.backend_config = backend_config
        self.backend_entity = backend_entity
        self.origin_ctx = copy(backend_entity.eval_ctx)
        self.optim_config = backend_config.optim_config

    @abstractmethod
    def _generate_sub_task(self, tuning_candidate: dict[str, Any]) -> list[SubTaskEntity]:
        """
        给定可选参数，生成一组父任务切分规则，这里的切分目前主要是指 分核+tiling+C&V同步 的设置
        Args:
            tuning_candidate:   可选参数 key - 变量名称； value - 可选参数值；

        Returns:
            一组子任务切分结果， 顺序也即代表执行顺序

        """
        pass

    def _default_tuning_generate(self) -> list[dict[str, Any]]:
        """
        如果用户没有输入tuning_candidates, 就调用这个函数生成一个默认的tuning_candidates
        Returns:
                多组可以选择的候选参数 key - 变量名称； value - 可选参数值；
        """
        return [{}]

    def _eval_host_by_candidates(self, candidate: dict[str, Any]):
        """处理一些tile切分数量等操作"""
        self.backend_entity.eval_ctx = copy(self.origin_ctx)

        for k, v in candidate.items():
            version = self.backend_entity.eval_ctx.get_version(k)
            name = bind_version(k, version)
            self.backend_entity.eval_ctx.assign(name, v)
        for host_op in self.backend_entity.host_ops:
            output = host_op.outputs[0]
            if isinstance(output, VarEntity):
                value = output.eval(self.backend_entity.eval_ctx)
                self.backend_entity.eval_ctx.assign(output.name, value.value)

    def _eval_time(self, sub_tasks: list[SubTaskEntity]) -> OperatorResult:
        """对sub_tasks中的表达式求值，再调用sim接口计算耗时"""
        res = eng_eval_dispatch(self.backend_config, self.backend_entity.eval_ctx, sub_tasks)
        with open("trace.json", "w", encoding='utf-8') as f:
            json.dump(res.trace, f, indent=2)
        return res

    def __call__(self, *args, **kwargs) -> OperatorResult:
        sim_res = None
        candidates = self.backend_config.optim_config.tuning_candidates
        if self.backend_config.optim_config.tuning_candidates is None:
            candidates = self._default_tuning_generate()

        for tuning_candidate in candidates:
            self._eval_host_by_candidates(tuning_candidate)
            sub_task_entities = self._generate_sub_task(tuning_candidate)
            sim_res_tmp = self._eval_time(sub_task_entities)
            if sim_res is None or sim_res.latency > sim_res_tmp.latency:
                sim_res = sim_res_tmp
        return sim_res