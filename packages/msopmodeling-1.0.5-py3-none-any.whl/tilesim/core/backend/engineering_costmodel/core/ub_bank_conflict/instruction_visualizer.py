# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

# ------------------------------ 可视化层 -----------------------   -------
from typing import List, Tuple
from dataclasses import dataclass
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from pathlib import Path
import matplotlib.font_manager as fm  # 新增：字体管理模块

from core.backend.engineering_costmodel.core.ub_bank_conflict.operand import Operand
from core.backend.engineering_costmodel.core.ub_bank_conflict.repeat_pipeline import RepeatPipeline
from core.backend.engineering_costmodel.op_model.pto.cce.config.configs import update_cce_config_cache, \
    get_cce_cycle_config
from core.common import DType
from core.common.log_format import logging
from core.config.arc_spec import load_arc_config

# 创建一个日志记录器
logger = logging.getLogger(__name__)


@dataclass
class BankParam:
    vec_op_name: str
    vec_op_dtype: DType
    dst: int
    src0: int
    repeat_times: int
    src0_block_stride: int
    dst_repeat_stride: int
    src0_repeat_stride: int
    dst_block_stride: int = 1  # 可选参数，vc开头指令无该参数，默认1
    cce_interval: int = 1
    src1: int = None  # 可选参数，双vector输入指令，参数必传
    src1_block_stride: int = None  # 可选参数
    src1_repeat_stride: int = None  # 可选参数


class InstructionVisualizer:
    def __init__(self, bank_params: list[BankParam], skip_visualize: bool = True):  # 新增：跳过绘图（遍历场景无需可视化）
        self.repeat_count = 0
        self.k = 0
        self.base = 1
        self.src0 = None
        self.src1 = None
        self.dst = None
        self.bank_params: List[BankParam] = bank_params
        self.pipelines: List[RepeatPipeline] = []
        self.skip_visualize = skip_visualize  # 控制是否跳过绘图

    def build_all_pipelines(self):
        self.pipelines.clear()
        prev_pipeline = None
        idx = 1
        # 待优化代码，应外部传入arc_config
        current_module_path = Path(__file__).resolve()
        current_module_dir = current_module_path.parent
        config_file_path = current_module_dir / "../../../../config/arc_config/910B1/910B1.yaml"
        # 再次resolve()：将相对路径转为绝对路径（关键，消除../../的歧义）
        config_file_path = config_file_path.resolve()
        arc_config = load_arc_config(config_file_path)
        for bank_param in self.bank_params:
            self.repeat_count += bank_param.repeat_times

            update_cce_config_cache(arc_config.vec_no_bank_conflict_intrinsics_dict)
            cce_intrinsics_dic = get_cce_cycle_config(bank_param.vec_op_name, bank_param.vec_op_dtype)
            self.k = cce_intrinsics_dic["interval_cycles"] - 3
            self.base = cce_intrinsics_dic["computing_cycles"]
            self.src0 = Operand("src0",
                                bank_param.src0,
                                bank_param.src0_block_stride,
                                bank_param.src0_repeat_stride)
            if all([bank_param.src1 is not None,
                    bank_param.src1_block_stride is not None,
                    bank_param.src1_repeat_stride is not None]):
                self.src1 = Operand("src1",
                                    bank_param.src1,
                                    bank_param.src1_block_stride,
                                    bank_param.src1_repeat_stride)
            self.dst = Operand("dst",
                               bank_param.dst,
                               bank_param.dst_block_stride,
                               bank_param.dst_repeat_stride)

            for _ in range(0, bank_param.repeat_times):
                logger.debug("[Building Repeat %s]", idx)
                pipeline = RepeatPipeline(
                    repeat_idx=idx,
                    src0=self.src0,
                    src1=self.src1,
                    dst=self.dst,
                    prev_pipeline=prev_pipeline,
                    k=self.k,
                    base=self.base
                )
                self.pipelines.append(pipeline)
                prev_pipeline = pipeline
                idx += 1
                logger.debug("[Build Repeat Finish] %s", pipeline)

    def visualize(self, figsize: Tuple[int, int] = (20, 14)):
        if self.skip_visualize:
            return  # 遍历场景默认跳过绘图，提升效率

        fig, ax = plt.subplots(figsize=figsize)
        self._draw_pipelines(ax)
        self._set_plot_properties(ax)
        self._add_legend(ax)
        plt.tight_layout()
        plt.show()

    def _draw_pipelines(self, ax):
        colors = {"read": "#3498db", "compute": "#2ecc71", "write": "#e74c3c"}
        conflict_colors = {
            "read_conflict": "#9b59b6",
            "write_conflict": "#f39c12",
            "rw_conflict": "#e67e22",
            "read_cross_rw_delay": "#d35400",
            "write_cross_ww_delay": "#8e44ad"
        }

        for pipeline in self.pipelines:
            repeat_idx = pipeline.repeat_idx
            y_pos = repeat_idx

            self._draw_read_stage(ax, pipeline, y_pos, colors, conflict_colors)
            self._draw_compute_stage(ax, pipeline, y_pos, colors)
            self._draw_write_stage(ax, pipeline, y_pos, colors, conflict_colors)
            self._draw_connection_line(ax, pipeline, y_pos)

    def _draw_read_stage(self, ax, pipeline, y_pos, colors, conflict_colors):
        read_start = pipeline.read_stage.get_start_time()
        read_dur = pipeline.read_stage.total_cycles
        read_end = read_start + read_dur

        if pipeline.read_cross_rw_delay > 0:
            read_color = conflict_colors["read_cross_rw_delay"]
            read_label = f"读(跨RW延迟{int(pipeline.read_cross_rw_delay)}cyc)" if pipeline.read_conflict_cnt == 0 else \
                f"读(内部{int(pipeline.read_conflict_cnt)}冲+跨RW延迟{int(pipeline.read_cross_rw_delay)}cyc)"
        elif pipeline.read_conflict_cnt > 0:
            read_color = conflict_colors["read_conflict"]
            read_label = f"读(内部{int(pipeline.read_conflict_cnt)}冲)"
        else:
            read_color = colors["read"]
            read_label = f"读(并行)\n"

        self._draw_rectangle(ax, (read_start, y_pos - 0.3), read_dur, 0.6, read_color, read_label)
        self._add_time_label(ax, read_start, read_end, y_pos)

    def _draw_compute_stage(self, ax, pipeline, y_pos, colors):
        compute_start = pipeline.compute_stage.get_start_time()
        compute_dur = pipeline.compute_stage.total_cycles
        self._draw_rectangle(ax, (compute_start, y_pos - 0.3), compute_dur, 0.6, colors["compute"], "计算")

    def _draw_write_stage(self, ax, pipeline, y_pos, colors, conflict_colors):
        write_start = pipeline.write_stage.get_start_time()
        write_dur = pipeline.write_stage.total_cycles
        write_end = write_start + write_dur

        if pipeline.write_cross_ww_delay > 0:
            write_color = conflict_colors["write_cross_ww_delay"]
            if pipeline.has_rw_conflict:
                write_label = (
                    f"写(内部读写冲+跨WW延迟{int(pipeline.write_cross_ww_delay)}cyc)\n"
                    f"冲突={pipeline.write_conflict_cnt}cyc"
                )
            elif pipeline.write_conflict_cnt > 0:
                write_label = (
                    f"写(内部{int(pipeline.write_conflict_cnt)}冲+"
                    f"跨WW延迟{int(pipeline.write_cross_ww_delay)}cyc"
                )
            else:
                write_label = f"写(跨WW延迟{int(pipeline.write_cross_ww_delay)}cyc)"
        elif pipeline.has_rw_conflict:
            write_color = conflict_colors["rw_conflict"]
            write_label = f"写(内部读写冲)\n冲突={pipeline.write_conflict_cnt}cyc"
        elif pipeline.write_conflict_cnt > 0:
            write_color = conflict_colors["write_conflict"]
            write_label = f"写(内部{int(pipeline.write_conflict_cnt)}冲)"
        else:
            write_color = colors["write"]
            write_label = "写(无冲突)"

        self._draw_rectangle(ax, (write_start, y_pos - 0.3), write_dur, 0.6, write_color, write_label)
        self._add_time_label(ax, write_start, write_end, y_pos)

    def _draw_connection_line(self, ax, pipeline, y_pos):
        if pipeline.prev_pipeline is not None:
            prev_read_end = pipeline.prev_pipeline.read_stage.get_end_time()
            current_read_start = pipeline.read_stage.get_start_time()
            ax.plot([prev_read_end, current_read_start], [y_pos - 0.5, y_pos - 0.5],
                    color='red', linestyle='--', linewidth=1.0, alpha=0.7)
            ax.text((prev_read_end + current_read_start) / 2, y_pos - 0.65,
                    f"衔接",
                    ha='center', va='top', fontsize=6, color='red', fontweight='bold')

    def _draw_rectangle(self, ax, position, width, height, color, label):
        ax.add_patch(mpatches.Rectangle(position, width, height, facecolor=color, edgecolor='black', linewidth=0.8))
        ax.text(position[0] + width / 2, position[1] + height / 2, label,
                ha='center', va='center', fontsize=7, fontweight='bold', wrap=True)

    def _add_time_label(self, ax, start, end, y_pos):
        ax.text(start + (end - start) / 2, y_pos + 0.38, f"{start:.0f}-{end:.0f}",
                ha='center', va='bottom', fontsize=7, color='black')

    def _set_plot_properties(self, ax):
        ax.set_xlabel("时间（Cycle数）", fontsize=12, fontweight='bold')
        ax.set_ylabel("Repeat编号", fontsize=12, fontweight='bold')
        ax.set_ylim(0.5, self.repeat_count + 1.2)
        ax.set_xlim(0, max(pipeline.end_time for pipeline in self.pipelines) + 3)
        ax.set_yticks(range(1, self.repeat_count + 1))
        ax.grid(axis='x', alpha=0.3, linestyle='--')
        ax.set_title("指令流水线执行甘特图（read基础偏移+跨Repeat读写/写写冲突延迟）",
                     fontsize=14, fontweight='bold', pad=20)

    def _add_legend(self, ax):
        legend_elements = [
            mpatches.Patch(color="#3498db", label="无冲突读"),
            mpatches.Patch(color="#9b59b6", label="读(内部冲突)"),
            mpatches.Patch(color="#d35400", label="读(跨Repeat延迟)"),
            mpatches.Patch(color="#2ecc71", label="计算（1Cycle）"),
            mpatches.Patch(color="#e74c3c", label="无冲突写"),
            mpatches.Patch(color="#f39c12", label="写(内部冲突)"),
            mpatches.Patch(color="#e67e22", label="写(内部读写冲突)"),
            mpatches.Patch(color="#8e44ad", label="写(跨Repeat延迟)"),
            mpatches.Patch(color='red', linestyle='--', label="Repeat间衔接线（含max_conflict偏移）")
        ]
        ax.legend(handles=legend_elements, loc='lower right', fontsize=10)


# ------------------------------ 全局中文字体配置（解决乱码核心） ------------------------------
def setup_chinese_font():
    """设置matplotlib中文字体，自动适配Windows/macOS/Linux系统"""
    try:
        # 1. 优先尝试系统常见中文字体（按优先级排序）
        font_names = [
            'Microsoft YaHei',  # Windows：微软雅黑
            'SimHei',  # Windows：黑体
            'Heiti TC',  # macOS：黑体-繁
            'Arial Unicode MS',  # macOS：Unicode字体
            'WenQuanYi Zen Hei',  # Linux：文泉驿正黑
            'DejaVu Sans'  # 兜底：默认英文黑体（防止无中文字体）
        ]

        # 2. 选择系统中存在的第一个字体
        selected_font = None
        for font_name in font_names:
            if font_name in [f.name for f in fm.fontManager.ttflist]:
                selected_font = font_name
                break

        # 3. 设置全局字体
        plt.rcParams['font.sans-serif'] = [selected_font]  # 中文文本字体
        plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示异常问题
        logger.info("✅ 成功加载中文字体：%s", selected_font)
    except Exception as e:
        # 异常兜底：使用默认配置（可能仍有乱码，但避免程序崩溃）
        plt.rcParams['font.sans-serif'] = ['DejaVu Sans', 'SimHei']
        plt.rcParams['axes.unicode_minus'] = False
        logger.info("⚠️  中文字体加载失败，使用默认字体（可能仍乱码）：%s", e)


def count_bank_conflict(bank_params: list[BankParam]):
    logger.debug("bank_param len : %s", len(bank_params))

    visual = InstructionVisualizer(bank_params, skip_visualize=True)
    visual.build_all_pipelines()
    pipelines = visual.pipelines
    bank_conflict_count = 0
    pipeline_idx = -1
    for bank_param in bank_params:
        pre_pipeline_idx = pipeline_idx + 1
        pipeline_idx += bank_param.repeat_times
        bank_conflict_count += (pipelines[pipeline_idx].end_time - pipelines[pre_pipeline_idx].end_time
                                - (pipeline_idx - pre_pipeline_idx)
                                + pipelines[pre_pipeline_idx].read_conflict_cnt + pipelines[
                                    pre_pipeline_idx].write_conflict_cnt)

    return bank_conflict_count


# ------------------------------ 执行入口 ------------------------------
if __name__ == "__main__":
    # 初始化中文字体（程序启动时执行）
    setup_chinese_font()

    # 1. 实例化可视化器（可自定义参数，默认是Repeat 1-20）
    bank_param_vabs = BankParam(
        vec_op_name="VABS",
        vec_op_dtype=DType.FP32,
        repeat_times=20,  # Repeat数量（固定1-20）
        src0=0,  # src0起始block编号
        dst=1,  # dst起始block编号
        src0_block_stride=1,  # src0同Repeat内block间隔步长
        dst_block_stride=1,  # dst同Repeat内block间隔步长
        src0_repeat_stride=8,  # src0 Repeat间block间隔步长
        dst_repeat_stride=8  # dst Repeat间block间隔步长
    )

    bank_param_vadd = BankParam(
        vec_op_name="VADD",
        vec_op_dtype=DType.FP32,
        repeat_times=30,  # Repeat数量（固定1-20）
        src0=0,  # src0起始block编号
        src1=0,  # src1起始block编号
        dst=1,  # dst起始block编号
        src0_block_stride=1,  # src0同Repeat内block间隔步长
        src1_block_stride=1,  # src1同Repeat内block间隔步长
        dst_block_stride=1,  # dst同Repeat内block间隔步长
        src0_repeat_stride=8,  # src0 Repeat间block间隔步长
        src1_repeat_stride=8,  # src1 Repeat间block间隔步长
        dst_repeat_stride=8,  # dst Repeat间block间隔步长
    )

    bank_param_vcgmax = BankParam(
        vec_op_name="VCGMAX",
        vec_op_dtype=DType.FP32,
        repeat_times=30,  # Repeat数量（固定1-20）
        src0=0,  # src0起始block编号
        dst=1,  # dst起始block编号
        src0_block_stride=1,  # src0同Repeat内block间隔步长
        dst_block_stride=1,  # dst同Repeat内block间隔步长
        src0_repeat_stride=8,  # src0 Repeat间block间隔步长
        dst_repeat_stride=1  # dst Repeat间block间隔步长
    )

    bank_param_vdiv1 = BankParam(
        vec_op_name="VDIV",
        vec_op_dtype=DType.FP32,
        repeat_times=96,  # Repeat数量（固定1-20）
        src0=0,  # src0起始block编号
        src1=1024,  # src1起始block编号
        dst=3072,  # dst起始block编号
        src0_block_stride=1,  # src0同Repeat内block间隔步长
        src1_block_stride=1,  # src1同Repeat内block间隔步长
        dst_block_stride=8,  # dst同Repeat内block间隔步长
        src0_repeat_stride=8,  # src0 Repeat间block间隔步长
        src1_repeat_stride=8,  # src1 Repeat间block间隔步长
        dst_repeat_stride=8  # dst Repeat间block间隔步长
    )

    bank_param_vdiv2 = BankParam(
        vec_op_name="VDIV",
        vec_op_dtype=DType.FP32,
        repeat_times=8,  # Repeat数量（固定1-20）
        src0=0,  # src0起始block编号
        src1=1024,  # src1起始block编号
        dst=3072,  # dst起始block编号
        src0_block_stride=1,  # src0同Repeat内block间隔步长
        src1_block_stride=1,  # src1同Repeat内block间隔步长
        dst_block_stride=8,  # dst同Repeat内block间隔步长
        src0_repeat_stride=8,  # src0 Repeat间block间隔步长
        src1_repeat_stride=8,  # src1 Repeat间block间隔步长
        dst_repeat_stride=8  # dst Repeat间block间隔步长
    )

    bank_param_vexp = BankParam(
        vec_op_name="VEXP",
        vec_op_dtype=DType.FP32,
        repeat_times=192,  # Repeat数量（固定1-20）
        src0=0,  # src0起始block编号
        dst=1024,  # dst起始block编号
        src0_block_stride=1,  # src0同Repeat内block间隔步长
        dst_block_stride=1,  # dst同Repeat内block间隔步长
        src0_repeat_stride=8,  # src0 Repeat间block间隔步长
        dst_repeat_stride=8  # dst Repeat间block间隔步长
    )

    bank_param_vexp1 = BankParam(
        vec_op_name="VEXP",
        vec_op_dtype=DType.FP32,
        repeat_times=26,  # Repeat数量（固定1-20）
        src0=0,  # src0起始block编号
        dst=1,  # dst起始block编号
        src0_block_stride=1,  # src0同Repeat内block间隔步长
        dst_block_stride=1,  # dst同Repeat内block间隔步长
        src0_repeat_stride=8,  # src0 Repeat间block间隔步长
        dst_repeat_stride=8  # dst Repeat间block间隔步长
    )

    bank_conflict_cnt = count_bank_conflict([bank_param_vexp1
                                             ])
    print(f"bank conflict count : {bank_conflict_cnt}")

    visualizer = InstructionVisualizer(
        [
            bank_param_vexp1
        ],
        skip_visualize=False
    )

    # 2. 构建所有流水线（可选，可视化时自动构建）
    visualizer.build_all_pipelines()

    # 3. 执行可视化（自动构建流水线+生成甘特图）
    visualizer.visualize()