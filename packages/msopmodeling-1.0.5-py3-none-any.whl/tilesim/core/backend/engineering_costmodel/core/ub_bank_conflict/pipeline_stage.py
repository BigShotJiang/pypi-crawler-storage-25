# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.


from typing import List
from core.backend.engineering_costmodel.core.ub_bank_conflict.cycle import Cycle


class PipelineStage:
    def __init__(self, stage_name: str):
        self.stage_name = stage_name
        self.cycles: List[Cycle] = []

    @property
    def total_cycles(self) -> int:
        return int(self.get_end_time() - self.get_start_time()) if self.cycles else 0

    def get_start_time(self) -> float:
        return min(cycle.start_time for cycle in self.cycles) if self.cycles else 0.0

    def get_end_time(self) -> float:
        return max(cycle.end_time for cycle in self.cycles) if self.cycles else 0.0

    def add_cycle(self, cycle: Cycle):
        self.cycles.append(cycle)
        self.cycles.sort(key=lambda x: x.start_time)

    def __repr__(self):
        return (
            f"Stage({self.stage_name}, "
            f"{self.total_cycles}cyc, ["
            f"{self.get_start_time():.1f}, "
            f"{self.get_end_time():.1f}])"
        )