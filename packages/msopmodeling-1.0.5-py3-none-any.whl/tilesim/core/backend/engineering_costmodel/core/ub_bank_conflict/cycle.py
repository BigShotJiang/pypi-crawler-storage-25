# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.


from typing import List
from core.backend.engineering_costmodel.core.ub_bank_conflict.block import Block


# ------------------------------ 流水线层 ------------------------------
class Cycle:
    """周期类，描述单个cycle的时间范围、阶段类型和处理的block"""
    def __init__(self, stage_type: str, start_time: float):
        self.stage_type = stage_type  # 阶段类型：read/compute/write
        self.start_time = start_time  # 开始时间
        self.end_time = start_time + 1  # 结束时间（每个cycle耗时1）
        self.blocks: List[Block] = []  # 该周期处理的block集合

    def add_blocks(self, blocks: List[Block]):
        """添加多个block到当前周期"""
        self.blocks.extend(blocks)

    def __repr__(self):
        return f"Cycle({self.stage_type}, [{self.start_time:.1f}, {self.end_time:.1f}])"