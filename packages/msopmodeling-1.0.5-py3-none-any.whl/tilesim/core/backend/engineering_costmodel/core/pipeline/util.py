# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

import json

import matplotlib.patches as patches
import matplotlib.pyplot as plt

from core.common.entity import Block, CoreType, ResultKey


def calculate_tail_blocks_pipeline_time(time_data: list[tuple]) -> float:
    """
    计算有尾块情况下的，多轮数据计算的总体时间（扣去掩盖时间）
    """
    i_cnt = len(time_data)
    j_cnt = len(time_data[0])
    time_cost = [0.0] * j_cnt

    # 初始化第一行的时间
    time_cost[0] = time_data[0][0]
    for j in range(1, j_cnt):
        time_cost[j] = time_cost[j - 1] + time_data[0][j]

    # 处理后续行的时间
    for i in range(1, i_cnt):
        new_time_cost = [0.0] * j_cnt
        new_time_cost[0] = time_cost[0] + time_data[i][0]
        
        for j in range(1, j_cnt):
            new_time_cost[j] = max(new_time_cost[j - 1], time_cost[j]) + time_data[i][j]
        
        time_cost = new_time_cost

    return time_cost[j_cnt - 1]