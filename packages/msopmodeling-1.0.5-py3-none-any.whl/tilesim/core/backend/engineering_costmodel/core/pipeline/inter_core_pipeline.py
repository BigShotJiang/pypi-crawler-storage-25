# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from itertools import groupby

from core.common.entity import Block, ResultKey, CoreType, MemLoc, MemType, PipeAnaConfig
from core.backend.engineering_costmodel.core.aicore_costmodel import AICoreCostModel
from core.backend.engineering_costmodel.core.cache_hit_caculator import (
    calculate_l2_hit_rate,
    calculate_l1_hit,
)
from core.backend.engineering_costmodel.core.pipeline.aic_pipeline import AICPipeline
from core.backend.engineering_costmodel.core.pipeline.aiv_pipeline import AIVPipeline


def calculate_multi_blocks_pipeline_time(blocks: list[Block]) -> float:
    """
    cv并行块的时间累加，同一个batch id的，就表示可以并行，取大值，否则直接累加
    :param blocks:
    :return:
    """
    core_avail_time_dict = {CoreType.AIC: 0, CoreType.AIV: 0}
    stream_time_dict = {}
    total_time = 0

    for b in blocks:
        # 同一个loop_idx,round_idx，则是同一条数据
        stream_id = f'{int(b.loop_idx)}_{int(b.round_idx)}'
        stream_time = stream_time_dict[stream_id] if stream_id in stream_time_dict.keys() else 0
        core_avail_time = core_avail_time_dict.get(b.core_type)
        if core_avail_time is None:
            raise ValueError("core_avail_time get None")

        b_start_time = max(stream_time, core_avail_time)
        b.time_start = b_start_time
        b_end_time = b_start_time + b.time[ResultKey.CORE_TIME]

        stream_time_dict[stream_id] = b_end_time
        core_avail_time_dict[b.core_type] = b_end_time
        total_time = max(total_time, b_end_time)

    return total_time


def get_keys(t):
    return (t.core_type.value, t.loop_idx, t.round_idx, t.section.block_idx, t.batch_idx)


def generate_blocks(total_input_tiles, total_output_tiles):
    """
    根据batch id 构建出 单核连续执行block
    :param total_input_tiles:
    :param total_output_tiles:
    :return:
    """
    # 按照 loop_idx, round_idx, block_idx, batch_id 划分 tiles
    total_input_tiles.sort(key=get_keys)
    input_tiles_by_key = {k: list(g) for k, g in groupby(total_input_tiles, get_keys)}
    total_output_tiles.sort(key=get_keys)
    output_tiles_by_key = {k: list(g) for k, g in groupby(total_output_tiles, get_keys)}

    # 生成block
    blocks = []
    for key, input_tiles in input_tiles_by_key.items():
        if key not in output_tiles_by_key:
            raise ValueError(f"key not in output_tiles_by_key")
        output_tiles = output_tiles_by_key[key]
        blocks.append(Block(key, input_tiles, output_tiles))

    blocks.sort(key=lambda b: (b.batch_idx, b.section.bias))
    return blocks


def _mark_batch_for_one_sec(section, loop_size, group_size_by_idx, block_round):
    group_size = group_size_by_idx.get(section.group_idx)
    if group_size is None:
        raise ValueError("group_size get None")

    total_tiles = section.input_tiles + section.output_tiles
    for _, tile in enumerate(total_tiles):
        loop_idx = tile.idx_in_section // (block_round * section.tile_round)
        round_idx = tile.idx_in_section // section.tile_round % block_round
        batch_idx = (
                loop_idx * (loop_size - 1)
                + section.group_idx * (group_size - 1)
                + round_idx
                + section.block_idx
        )
        tile.batch_idx = batch_idx
        tile.loop_idx = loop_idx
        tile.round_idx = round_idx

    # 同一个batch的，需要重新归一化idx_in_section
    tiles_by_batch_idx = {}
    for tile in section.input_tiles:
        if tile.batch_idx not in tiles_by_batch_idx:
            tiles_by_batch_idx[tile.batch_idx] = [tile]
        else:
            tiles_by_batch_idx[tile.batch_idx].append(tile)

    for _, tiles in tiles_by_batch_idx.items():
        # 按照idx_in_section排序
        tiles.sort(key=lambda t: t.idx_in_section)
        tiles_size = len(tiles)
        for i, tile in enumerate(tiles):
            tile.idx_in_batch = i / tiles_size


class InterCorePipeline:

    def __init__(self, section_list: list, aicore_costmodel: AICoreCostModel):
        self.section_list = section_list
        self.aicore_pipeline = {
            section.bias: (
                AICPipeline(aicore_costmodel, section.tiling_param)
                if section.core_type == CoreType.AIC
                else AIVPipeline(aicore_costmodel, section.tiling_param)
            )
            for section in self.section_list
        }
        self.cube_core_num = aicore_costmodel.arc_config.core_config.cube_core_num
        self.aicore_cost_model = aicore_costmodel
        self.pipe_ana_config = PipeAnaConfig()

    def _mark_batch_idx_for_tiles(self, block_round=3):
        """对每个tile划分对应的batch id"""
        parallel_block_id = 0
        core_type_set = set()
        idx_in_block = 0
        for section in self.section_list:
            if section.core_type in core_type_set:
                parallel_block_id += 1
                core_type_set = {section.core_type}
                idx_in_block = 0
            else:
                core_type_set.add(section.core_type)
            section.group_idx = parallel_block_id
            section.block_idx = idx_in_block
            idx_in_block += 1

        # 计算每个group包含的cv block数量 和 一个loop包含了多少block数量
        grouped_sections = {
            group_idx: [s for s in self.section_list if s.group_idx == group_idx]
            for group_idx in range(parallel_block_id + 1)
        }
        group_size_by_idx = {}
        loop_size = 1
        for group_idx, sections in grouped_sections.items():
            group_size = block_round - 1 + len(sections)
            group_size_by_idx[group_idx] = group_size
            loop_size += group_size - 1

        # 划分tile的批次
        for section in self.section_list:
            _mark_batch_for_one_sec(section, loop_size, group_size_by_idx, block_round)

    def __get_max_tiles_core(self):
        """
        为避免重复计算太多，以tiles最多的核作为主要计算对象
        :return: aic_core, aiv_core
        """

        # 统计各个核的tile总体积，按照最大的核算时间：用其中一对CV即可，默认CV绑定
        sections_by_cv_block = {}
        for section in self.section_list:
            if section.group_idx not in sections_by_cv_block:
                sections_by_cv_block[section.group_idx] = [section]
            else:
                sections_by_cv_block[section.group_idx].append(section)
        max_blocks_cv_block = None
        max_blocks_cv_block_idx = -1
        for group_idx, sections in sections_by_cv_block.items():
            if max_blocks_cv_block is None or len(sections) > max_blocks_cv_block:
                max_blocks_cv_block = len(sections)
                max_blocks_cv_block_idx = group_idx

        # 包含了C&V块的group
        sections = sections_by_cv_block.get(max_blocks_cv_block_idx)
        if sections is None:
            raise ValueError("sections get None")

        # 选择其中tile size最大的AIC和AIV
        max_aic, max_aiv = None, None
        for section in sections:
            core_set = {tile.core for tile in section.input_tiles}
            tile_size_by_core = {
                core_idx: sum(
                    [tile.size for tile in section.input_tiles if tile.core == core_idx]
                )
                for core_idx in core_set
            }
            # 如果是AIC核，则选择一个核
            if section.core_type == CoreType.AIC:
                # 从tile_size_by_core中选择size最大的core_idx
                max_aic = max(tile_size_by_core, key=tile_size_by_core.get)
            else:
                max_aiv = max(tile_size_by_core, key=tile_size_by_core.get)

        return max_aic, max_aiv

    @staticmethod
    def __to_result(blocks: list[Block]):
        aic_time = 0
        aiv_time = 0
        cube_time = 0
        vec_time = 0
        mte1_time = 0
        mte2_time_aic = 0
        mte2_time_aiv = 0
        mte3_time = 0
        fixpipe_time = 0

        for block in blocks:
            if block.core_type == CoreType.AIC:
                aic_time += block.time[ResultKey.CORE_TIME]
                cube_time += block.time[ResultKey.CUBE_TIME]
                mte1_time += block.time[ResultKey.MTE1_TIME]
                mte2_time_aic += block.time[ResultKey.MTE2_TIME_AIC]
                fixpipe_time += block.time[ResultKey.FIXPIPE_TIME]
            else:
                aiv_time += block.time[ResultKey.CORE_TIME]
                vec_time += block.time[ResultKey.VEC_TIME]
                mte2_time_aiv += block.time[ResultKey.MTE2_TIME_AIV]
                mte3_time += block.time[ResultKey.MTE3_TIME]

        return {
            ResultKey.AIC_TIME: aic_time,
            ResultKey.AIV_TIME: aiv_time,
            ResultKey.CUBE_TIME: cube_time,
            ResultKey.VEC_TIME: vec_time,
            ResultKey.MTE1_TIME: mte1_time,
            ResultKey.MTE2_TIME_AIC: mte2_time_aic,
            ResultKey.MTE2_TIME_AIV: mte2_time_aiv,
            ResultKey.MTE3_TIME: mte3_time,
            ResultKey.FIXPIPE_TIME: fixpipe_time,
        }

    def __get_input_output_tiles(self, total_tiles):
        # 获取到tile size最大的核，以该核作为分析对象
        max_aic, max_aiv = self.__get_max_tiles_core()
        aic_input_tiles = [
            t
            for t in total_tiles
            if t.core == max_aic and t.input_bias >= 0 and t.core_type == CoreType.AIC
        ]
        aic_input_tiles.sort(key=lambda t: (t.batch_idx, t.idx_in_batch))
        aic_output_tiles = [
            t
            for t in total_tiles
            if t.core == max_aic and t.input_bias == -1 and t.core_type == CoreType.AIC
        ]
        aic_output_tiles.sort(key=lambda t: (t.batch_idx, t.idx_in_batch))
        aiv_input_tiles = [
            t
            for t in total_tiles
            if t.core == max_aiv and t.input_bias >= 0 and t.core_type == CoreType.AIV
        ]
        aiv_input_tiles.sort(key=lambda t: (t.batch_idx, t.idx_in_batch))
        aiv_output_tiles = [
            t
            for t in total_tiles
            if t.core == max_aiv and t.input_bias == -1 and t.core_type == CoreType.AIV
        ]
        aiv_output_tiles.sort(key=lambda t: (t.batch_idx, t.idx_in_batch))
        return aic_input_tiles, aic_output_tiles, aiv_input_tiles, aiv_output_tiles

    def __get_input_output_tiles_for_core_idx(self, total_tiles, core_idx):
        # 根据core_idx选择核作为分析对象
        aic_input_tiles = [
            t
            for t in total_tiles
            if t.core == core_idx and t.input_bias >= 0 and t.core_type == CoreType.AIC
        ]
        aic_input_tiles.sort(key=lambda t: (t.batch_idx, t.idx_in_batch))
        aic_output_tiles = [
            t
            for t in total_tiles
            if t.core == core_idx and t.input_bias == -1 and t.core_type == CoreType.AIC
        ]
        aic_output_tiles.sort(key=lambda t: (t.batch_idx, t.idx_in_batch))
        aiv_input_tiles = [
            t
            for t in total_tiles
            if t.core == core_idx and t.input_bias >= 0 and t.core_type == CoreType.AIV
        ]
        aiv_input_tiles.sort(key=lambda t: (t.batch_idx, t.idx_in_batch))
        aiv_output_tiles = [
            t
            for t in total_tiles
            if t.core == core_idx and t.input_bias == -1 and t.core_type == CoreType.AIV
        ]
        aiv_output_tiles.sort(key=lambda t: (t.batch_idx, t.idx_in_batch))
        return aic_input_tiles, aic_output_tiles, aiv_input_tiles, aiv_output_tiles

    def _calculate_avg_core_time(self, total_tiles, hit_rate):
        # AIC核时间取平均
        # 定义所有核的编号
        all_cores = list(range(self.cube_core_num))

        # 用于保存每个核的 res 字典
        all_res = []

        # 遍历每个核
        for core_idx in all_cores:
            aic_input_tiles, aic_output_tiles, aiv_input_tiles, aiv_output_tiles = self.__get_input_output_tiles_for_core_idx(
                total_tiles, core_idx)

            # 合并输入输出tile
            single_block_input_tiles = aic_input_tiles + aiv_input_tiles
            single_block_output_tiles = aic_output_tiles + aiv_output_tiles

            # 生成block
            blocks = generate_blocks(single_block_input_tiles, single_block_output_tiles)
            aiv_total_cycles = 0
            # 计算每个block的时间
            for block in blocks:
                block.time = self.aicore_pipeline.get(block.section.bias).calculate_time(block.input_tiles, block.output_tiles, self.pipe_ana_config)
                aiv_total_cycles += block.time.get(ResultKey.AIV_TOTAL_CYCLES, 0)
            # 计算当前核的core_time
            core_time = calculate_multi_blocks_pipeline_time(blocks)

            # 为当前核生成 res 字典
            res = self.__to_result(blocks)
            res[ResultKey.CORE_TIME] = core_time
            res[ResultKey.L2_MISS_RATE] = 1 - hit_rate
            res[ResultKey.AIC_TOTAL_MKN] = sum(sec.m * sec.k * sec.n for sec in self.section_list)
            res[ResultKey.AIV_TOTAL_CYCLES] = aiv_total_cycles

            # 保存当前核的 res
            all_res.append(res)

            # 对 self.cube_core_num 个 res 字典中的每个键取平均值
        avg_res = {}
        for key in all_res[0].keys():
            avg_res[key] = sum(res[key] for res in all_res) / len(all_res)

        return avg_res

    def _calculate_without_avg_core_time(self, total_tiles, hit_rate):
        aic_input_tiles, aic_output_tiles, aiv_input_tiles, aiv_output_tiles = self.__get_input_output_tiles(
            total_tiles)

        # 计算各个block的时间，每个block按照 loop_idx, round_idx, block_idx 确定唯一的block（每个block是tile_round轮计算）
        single_block_input_tiles = aic_input_tiles + aiv_input_tiles
        single_block_output_tiles = aic_output_tiles + aiv_output_tiles
        blocks = generate_blocks(single_block_input_tiles, single_block_output_tiles)

        aiv_total_cycles = 0
        for block in blocks:
            block.time = self.aicore_pipeline.get(block.section.bias).calculate_time(block.input_tiles, block.output_tiles)
            aiv_total_cycles += block.time.get(ResultKey.AIV_TOTAL_CYCLES, 0)

        # 计算CV并行情况下的时间
        core_time = calculate_multi_blocks_pipeline_time(blocks)

        res = self.__to_result(blocks)
        res[ResultKey.CORE_TIME] = core_time
        res[ResultKey.L2_MISS_RATE] = 1 - hit_rate
        res[ResultKey.AIC_TOTAL_MKN] = sum(sec.m * sec.k * sec.n for sec in self.section_list)
        res[ResultKey.AIV_TOTAL_CYCLES] = aiv_total_cycles

        return res

    def _cache_stat(self, total_tiles, ret):
        L0A_cache = 0
        L0B_cache = 0
        L0C_cache = 0
        L2_cache = 0
        L1_cache = 0
        UB_cache = 0
        for tile in total_tiles:
            tile_d_size = tile.size * tile.precision.size
            if tile.l1_hit == 0 and tile.l2_hit == 0:
                L2_cache += tile_d_size
            if tile.core_type == CoreType.AIC:
                if tile.l1_hit == 0:
                    L1_cache += tile.size
                L0A_cache += tile_d_size
                L0B_cache += tile_d_size
                L0C_cache += tile_d_size
            if tile.core_type == CoreType.AIV:
                UB_cache += tile_d_size
        ret[ResultKey.L0A_CACHE] = L0A_cache
        ret[ResultKey.L0B_CACHE] = L0B_cache
        ret[ResultKey.L0C_CACHE] = L0C_cache
        ret[ResultKey.L2_CACHE] = L2_cache
        ret[ResultKey.L1_CACHE] = L1_cache
        ret[ResultKey.UB_CACHE] = UB_cache

    def calculate_sections_time(self, plot_cv_block=False, use_avg_core=False, pipe_ana_config: PipeAnaConfig = None):
        # 标记每个tile属于哪个batch
        if pipe_ana_config is None:
            self.pipe_ana_config = PipeAnaConfig()
        self._mark_batch_idx_for_tiles(block_round=2)
        total_tiles = [
                          t for section in self.section_list for t in section.input_tiles
                      ] + [t for section in self.section_list for t in section.output_tiles]

        # 按照 batch_idx, idx_in_batch 进行排序
        total_tiles.sort(key=lambda t: (t.batch_idx, t.idx_in_batch))

        # 模拟L2 cache命中率
        l2_cache = self.aicore_cost_model.arc_config.lookup_cache_size(MemLoc.L2)
        if l2_cache[0] != MemType.SHARE_MEM:
            raise ValueError("L2 is not share memory")
        l2_cache_size = l2_cache[1]
        hit_rate = calculate_l2_hit_rate(total_tiles, l2_cache_size)

        # 模拟L1 cache命中率
        aic_input_tiles_dict = {i: [] for i in range(self.cube_core_num)}
        for tile in total_tiles:
            if tile.core_type == CoreType.AIC:
                aic_input_tiles_dict[tile.core].append(tile)
        for tile in aic_input_tiles_dict.values():
            l1_cache = self.aicore_cost_model.arc_config.lookup_cache_size(MemLoc.L1)
            if l1_cache[0] != MemType.LOCAL_MEM:
                raise ValueError("L1 is not local memory")
            l1_cache_size = l1_cache[1]
            calculate_l1_hit(tile, l1_cache_size)

        if not use_avg_core:
            ret = self._calculate_without_avg_core_time(total_tiles, hit_rate)
        else:
            ret = self._calculate_avg_core_time(total_tiles, hit_rate)

        self._cache_stat(total_tiles, ret)

        return ret