# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

from core.common.entity import (
    Tile,
    ResultKey,
    MemLoc, PipeAnaConfig, CoreUnit,
)
from core.backend.engineering_costmodel.core.aicore_costmodel import AICoreCostModel
from core.backend.engineering_costmodel.core.pipeline.util import calculate_tail_blocks_pipeline_time
from core.backend.engineering_costmodel.core.tiling_and_core_split.tiling_strategy_register import TilingParam


def _calculate_vec_process_data(input_tiles: list[Tile]):
    l2_cache_size = 0
    ub_cache_size = 0
    for tile in input_tiles:
        element_cnt, input_size_dict, output_shape_dict = tile.get_op_element_cnt()
        for key, value in input_size_dict.items():
            v_size = sum(value)
            if key == MemLoc.L2 or key == MemLoc.GM:
                l2_cache_size += v_size
            ub_cache_size += v_size
    return l2_cache_size, ub_cache_size


class AIVPipeline:
    def __init__(
            self,
            aicore: AICoreCostModel,
            tiling_param: TilingParam,
            delta: float = 0,
            small_pack: bool = False,
            mte2_aiv_hit_rate: float = 0,
            mte3_hit_rate: float = 0,
    ):
        self.aicore = aicore
        self.tiling_param = tiling_param
        self.delta = delta
        self.small_pack = small_pack
        self.mte2_aiv_hit_rate = mte2_aiv_hit_rate
        self.mte3_hit_rate = mte3_hit_rate
        self.pipe_ana_config = PipeAnaConfig()
        self.statistic_record = {}

    def _init_pipe(self, config: PipeAnaConfig):
        if config is None:
            config = PipeAnaConfig()
        self.pipe_ana_config = config
        self.statistic_record = {
            ResultKey.AIV_TOTAL_CYCLES: 0,
            ResultKey.MTE2_TIME_AIV: 0,
            ResultKey.VEC_TIME: 0,
            ResultKey.MTE3_TIME: 0,
            ResultKey.CORE_TIME: 0,
            ResultKey.AIV_TIME: 0,
            ResultKey.L2_MISS_RATE: 1,
            ResultKey.L2_CACHE: 0,
            ResultKey.UB_CACHE: 0
        }

    def _calculate_single_tile_times(self, tile: Tile, time_cache: dict) -> tuple[float, dict[CoreUnit, float]]:
        """计算单个 tile 的 MTE2, VEC, MTE3 时间，并利用缓存。"""
        tile_size = (tile.rows, tile.cols)
        if tile_size in time_cache:
            # 从缓存中获取时间
            cached_times = time_cache[tile_size]
            time_mte2 = cached_times['mte2']
            time_vec = cached_times['vec']
            time_mte3 = cached_times['mte3']
            vec_cycles = cached_times['total_cycles']
        else:
            # 计算时间并存入缓存
            element_cnt, input_size_dict, output_shape_dict = tile.get_op_element_cnt()
            copy_out_data = output_shape_dict.get(MemLoc.GM, []) + output_shape_dict.get(MemLoc.L2, [])
            copy_out_data_hccs = output_shape_dict.get(MemLoc.SHM, [])

            time_mte2 = self.aicore.time_mte2_aiv(
                input_size_dict.get(MemLoc.GM, []),
                0,
                self.tiling_param.parallel_core_num,
                self.small_pack,
            )
            time_mte2 += self.aicore.time_mte2_aiv(
                input_size_dict.get(MemLoc.L2, []),
                1,
                self.tiling_param.parallel_core_num,
                self.small_pack)
            time_vec, vec_cycles = self.aicore.time_vec(tile.fused_op, element_cnt)
            time_mte3 = self.aicore.time_mte3(
                copy_out_data,
                self.mte3_hit_rate,
                self.tiling_param.parallel_core_num,
                self.small_pack,
            )
            time_mte3 = time_mte3 + self.aicore.time_mte3_load(copy_out_data_hccs)
            # 缓存结果
            time_cache[tile_size] = {
                'mte2': time_mte2,
                'vec': time_vec,
                'mte3': time_mte3,
                'total_cycles': vec_cycles
            }

        CoreUnit_latency = {
            CoreUnit.AIV_MTE2: time_mte2,
            CoreUnit.VEC: time_vec,
            CoreUnit.AIV_MTE3: time_mte3
        }
        return vec_cycles, CoreUnit_latency

    def _process_tile_list_latency(self, input_tiles: list[Tile]) -> list[tuple[float]]:
        """逐Tile计算每个Tile花费的时间"""
        # 先排序，按照idx排序
        input_tiles.sort(key=lambda x: x.idx_in_section)

        time_cache = {}
        time_data = []

        for tile in input_tiles:
            cycles, CoreUnit_latency = self._calculate_single_tile_times(tile, time_cache)
            self.statistic_record[ResultKey.MTE2_TIME_AIV] += CoreUnit_latency[CoreUnit.AIV_MTE2]
            self.statistic_record[ResultKey.VEC_TIME] += CoreUnit_latency[CoreUnit.VEC]
            self.statistic_record[ResultKey.MTE3_TIME] += CoreUnit_latency[CoreUnit.AIV_MTE3]
            self.statistic_record[ResultKey.AIV_TOTAL_CYCLES] += cycles

            # 1) MTE2 VEC不开启double buffer
            if (CoreUnit.AIV_MTE2, CoreUnit.VEC) in self.pipe_ana_config.un_parallel_components:
                tile_time = (CoreUnit_latency[CoreUnit.AIV_MTE2] + CoreUnit_latency[CoreUnit.VEC], CoreUnit_latency[CoreUnit.AIV_MTE3])
            # 2) VEC MTE3不开启double buffer
            elif (CoreUnit.VEC, CoreUnit.AIV_MTE3) in self.pipe_ana_config.un_parallel_components:
                tile_time = (CoreUnit_latency[CoreUnit.AIV_MTE2], CoreUnit_latency[CoreUnit.VEC] + CoreUnit_latency[CoreUnit.AIV_MTE3])
            # 3) MTE2 MTE3 不可并行
            elif (CoreUnit.AIV_MTE2, CoreUnit.AIV_MTE3) in self.pipe_ana_config.un_parallel_components:
                tile_time = (CoreUnit_latency[CoreUnit.AIV_MTE2] + CoreUnit_latency[CoreUnit.AIV_MTE3], CoreUnit_latency[CoreUnit.VEC])
            # 4) 三者都不开启double buffer
            elif (CoreUnit.AIV_MTE2, CoreUnit.VEC, CoreUnit.AIV_MTE3) in self.pipe_ana_config.un_parallel_components:
                tile_time = (CoreUnit_latency[CoreUnit.AIV_MTE2] + CoreUnit_latency[CoreUnit.VEC] + CoreUnit_latency[CoreUnit.AIV_MTE3],)
            # 5) 全部开启double buffer
            else:
                tile_time = (CoreUnit_latency[CoreUnit.AIV_MTE2], CoreUnit_latency[CoreUnit.VEC], CoreUnit_latency[CoreUnit.AIV_MTE3])
            time_data.append(tile_time)

        return time_data

    def calculate_time(self, input_tiles: list[Tile], output_tiles: list[Tile], pipe_ana_config: PipeAnaConfig = None):  # output_tiles 未被使用
        """计算 AIV 流水线的总时间。"""
        self._init_pipe(pipe_ana_config)

        # 调用处理函数
        time_data = self._process_tile_list_latency(input_tiles)

        # 计算流水时间
        aiv_time = calculate_tail_blocks_pipeline_time(time_data)

        # 计算Cache访存量
        l2_cache_size, ub_cache_size = _calculate_vec_process_data(input_tiles)

        self.statistic_record.update({
            ResultKey.CORE_TIME: aiv_time,
            ResultKey.AIV_TIME: aiv_time,
            ResultKey.L2_MISS_RATE: 1,
            ResultKey.L2_CACHE: l2_cache_size,
            ResultKey.UB_CACHE: ub_cache_size
        })
        return self.statistic_record