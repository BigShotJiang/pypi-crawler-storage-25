# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

from core.common.entity import Tile


class Node:
    __slots__ = ("value", "size", "prev", "next")

    def __init__(self, value, size):
        self.value = value
        self.size = size
        self.prev = None
        self.next = None


class FixedFIFOQueue:
    def __init__(self, max_capacity):
        self.max_capacity = max_capacity
        self.capacity = 0
        self.length = 0
        self.head = None
        self.tail = None
        self.node_map = {}

    def _dequeue(self):
        """
        移除队首元素
        """
        if self.length == 0:
            return

        # 移除队首
        old_head = self.head
        del self.node_map[old_head.value]

        # 更新链表
        if self.length == 1:
            self.head = self.tail = None
        else:
            self.head = old_head.next
            self.head.prev = None
        self.length -= 1
        self.capacity -= old_head.size

    def enqueue(self, value, size):
        """
        加入一个新的元素
        """
        # 如果队列已满，移除队首元素
        if self.capacity + size > self.max_capacity:
            self._dequeue()

        # 创建新节点
        new_node = Node(value, size)
        self.node_map[value] = new_node

        # 新节点成为新的队尾
        if self.length == 0:
            self.head = self.tail = new_node
        else:
            self.tail.next = new_node
            new_node.prev = self.tail
            self.tail = new_node
        self.length += 1
        self.capacity += size

    def move_to_end(self, value):
        if value not in self.node_map:
            raise ValueError(f"{value} not in queue")

        # 如果本身就在队尾，无需更新
        node = self.node_map[value]
        if node is self.tail:
            return

        # 如果不在队尾，则先移除该节点
        if node is self.head:
            self.head = node.next
            self.head.prev = None
        else:
            # 前序连接到当前节点的next
            node.prev.next = node.next
            node.next.prev = node.prev

        # 将该节点加到队尾
        node.prev = self.tail
        node.next = None
        self.tail.next = node
        self.tail = node

    def __contains__(self, value):
        return value in self.node_map

    def __len__(self):
        return self.length


def calculate_l2_hit_rate(tiles: list[Tile], l2_cache_size: float):
    """
    计算l2 cache的命中率
    Args:
        tiles:          经过排序后的tile列表
        l2_cache_size:  l2的容量，单位B
    """
    queue = FixedFIFOQueue(l2_cache_size)

    hit_cnt = 0
    miss_cnt = 0
    for tile in tiles:
        if queue.__contains__(tile.tile_name):
            tile.l2_hit = 1
            hit_cnt += tile.size
            queue.move_to_end(tile.tile_name)
        else:
            miss_cnt += tile.size
            queue.enqueue(tile.tile_name, tile.size * tile.precision.size)

    hit_rate = hit_cnt / (hit_cnt + miss_cnt)
    return hit_rate


def calculate_l1_hit(tiles: list[Tile], l1_cache_size: float):
    """
    计算l1 cache的命中率
    Args:
        tiles:          经过排序后的tile列表
        l1_cache_size:  l1的容量，单位B
    """
    if len(tiles) == 0:
        return 0
    queue = FixedFIFOQueue(l1_cache_size)

    hit_cnt = 0
    miss_cnt = 0
    for tile in tiles:
        if queue.__contains__(tile.tile_name):
            tile.l1_hit = 1
            hit_cnt += 1
            queue.move_to_end(tile.tile_name)
        else:
            queue.enqueue(tile.tile_name, tile.size * tile.precision.size)
            miss_cnt += 1
    hit_rate = hit_cnt / (hit_cnt + miss_cnt)
    return hit_rate