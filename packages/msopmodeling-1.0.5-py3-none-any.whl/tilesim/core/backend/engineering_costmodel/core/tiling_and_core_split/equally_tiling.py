# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

import math

import matplotlib.patches as patches
import matplotlib.pyplot as plt
import numpy as np
from tqdm import tqdm

from core.common.entity import (
    CoreType,
    DType,
    Tile,
    OutputType,
    Section,
    DirectionType,
)

OPEN_PLOT = False
OPEN_BAR = True


class LoopParam:
    def __init__(self, max_bound, step, element_count, k, core_num, input_bias=0):
        """
        某层循环（外层循环/内层循环）的参数。循环是指 分tile的时候需要按照 行优先、列优先 去遍历，所以提取了公用逻辑，将参数抽取到这个类里面
        Args:
            max_bound:          循环的最大值
            step:               循环的步长（一个tile块在该方向的大小）
            element_count:      该方向分核的时候，每个核占据多少个元素
            k:                  该层循环的k轴切割tiling大小
            core_num:           分核的该方向上的核排布数量
            input_bias:         第几个输入（AIC核使用）
        """
        self.max_bound = max_bound
        self.step = step
        self.element_count = element_count
        self.k = k
        self.core_num = core_num
        self.input_bias = input_bias


def generate_tiles_one_direction(
    core_type: CoreType,
    outer_param: LoopParam,
    inner_param: LoopParam,
    section,
    input_precision: DType,
    output_precision: DType,
    sup_param: int = 0,
    loop: int = 0,
) -> tuple[list[Tile], list[Tile]]:
    """
    给定内外层循环参数，完成分核和L1 tiling
    """
    input_tiles, output_tiles = [], []
    core_idx = 0

    # 尾核的数量
    outer_reminder = outer_param.max_bound - outer_param.core_num * int(outer_param.element_count)
    inner_reminder = inner_param.max_bound - inner_param.core_num * int(inner_param.element_count)

    # 显示进度条使用
    total_tile_cnt = (
        math.ceil(outer_param.element_count / outer_param.step)
        * math.ceil(inner_param.element_count / inner_param.step)
        * outer_param.core_num
        * inner_param.core_num
    )
    if OPEN_BAR:
        pbar = tqdm(total=total_tile_cnt, desc="generate tiles", unit=" tiles")

    # 外层分核循环范围
    outer_start = 0
    while outer_start < outer_param.max_bound:
        outer_end = _calculate_outer_range(outer_start, outer_param, outer_reminder)
        outer_end = min(outer_end, outer_param.max_bound)

        # 内层分核循环范围
        inner_start = 0
        while inner_start < inner_param.max_bound:
            inner_end = _calculate_inner_range(inner_start, inner_param, inner_reminder)
            inner_end = min(inner_end, inner_param.max_bound)

            idx_in_section = 0

            # 处理外层循环
            outer_loop_result = _process_outer_loop(
                [inner_start, inner_end, outer_start, outer_end], [outer_param, inner_param],
                core_type, section, core_idx, sup_param, [input_precision, output_precision],
                idx_in_section, input_tiles, output_tiles
            )

            # 更新内层循环起点
            inner_start = outer_loop_result['inner_start']
            core_idx = outer_loop_result['core_idx']

            if OPEN_BAR:
                pbar.update(outer_loop_result['tiles_generated'])

        # 更新外层循环起点
        outer_start = outer_loop_result['outer_start']

    if OPEN_PLOT:
        _plot_tiles(output_tiles, "output tiles")
        _plot_input_tiles(input_tiles, section)

    return input_tiles, output_tiles


def _calculate_outer_range(outer_start: int, outer_param: LoopParam, outer_reminder: int) -> int:
    """
    计算外层循环的结束位置
    """
    if outer_reminder > 0:
        outer_end = outer_start + int(outer_param.element_count)
        outer_reminder -= 1
    else:
        outer_end = outer_start + math.ceil(outer_param.element_count)
    return outer_end


def _calculate_inner_range(inner_start: int, inner_param: LoopParam, inner_reminder: int) -> int:
    """
    计算内层循环的结束位置
    """
    if inner_reminder > 0:
        inner_end = inner_start + int(inner_param.element_count)
        inner_reminder -= 1
    else:
        inner_end = inner_start + math.ceil(inner_param.element_count)
    return inner_end


def _process_outer_loop(
    in_out_start_end: list[int],
    in_out_param: list[LoopParam],
    core_type: CoreType,
    section,
    core_idx: int,
    sup_param: int,
    in_out_precision: list[DType],
    idx_in_section: int,
    input_tiles: list[Tile],
    output_tiles: list[Tile],
) -> dict:
    """
    处理外层循环，生成Tile对象
    """
    tiles_generated = 0
    max_outer_iter = in_out_start_end[2]
    max_inner_iter = in_out_start_end[0]

    for outer_iter in np.arange(in_out_start_end[2], in_out_start_end[3], in_out_param[1].step):
        outer_counts = _calculate_counts(outer_iter, in_out_start_end[3], in_out_param[1])
        for inner_iter in np.arange(in_out_start_end[0], in_out_start_end[1], in_out_param[0].step):
            inner_counts = _calculate_counts(inner_iter, in_out_start_end[1], in_out_param[0])

            # 生成输入矩阵
            if core_type == CoreType.AIC:
                aic_input_tiles, aic_output_tile = _generate_aic_tiles(
                    section, core_idx, outer_iter, inner_iter, outer_counts, inner_counts,
                    sup_param, in_out_precision[0], in_out_precision[1], idx_in_section
                )
                input_tiles.extend(aic_input_tiles)
                output_tiles.append(aic_output_tile)
            else:
                aiv_input_tiles, aiv_output_tile = _generate_aiv_tiles(
                    section, core_idx, outer_iter, inner_iter, outer_counts, inner_counts,
                    sup_param, in_out_precision[0], in_out_precision[1], idx_in_section
                )
                input_tiles.extend(aiv_input_tiles)
                output_tiles.append(aiv_output_tile)

            # 更新最大坐标
            current_max_inner_iter = inner_iter + inner_counts
            current_max_outer_iter = outer_iter + outer_counts

            if current_max_inner_iter > max_inner_iter:
                max_inner_iter = current_max_inner_iter
            if current_max_outer_iter > max_outer_iter:
                max_outer_iter = current_max_outer_iter

            # 更新轮次计数
            idx_in_section += 1
            tiles_generated += 1

    return {
        'inner_start': max_inner_iter,
        'core_idx': core_idx + 1,
        'outer_start': max_outer_iter,
        'tiles_generated': tiles_generated
    }


def _calculate_counts(iter_id: int, end: int, param: LoopParam) -> int:
    """
    计算循环的块大小
    """
    return param.step if iter_id + param.step <= end else end - iter_id


def _generate_aic_tiles(
    section,
    core_idx: int,
    outer_iter: int,
    inner_iter: int,
    outer_counts: int,
    inner_counts: int,
    sup_param: int,
    input_precision: DType,
    output_precision: DType,
    idx_in_section: int,
) -> tuple[list[Tile], Tile]:
    """
    生成AIC核的输入和输出Tile
    """
    input_tiles_m1_n1 = []
    # A矩阵
    input_tiles_m1_n1.extend(
        _generate_aic_k_split_tiles(
            core_idx, outer_iter, inner_iter, outer_counts, inner_counts, sup_param,
            input_precision, 0, idx_in_section
        )
    )
    # B矩阵
    input_tiles_m1_n1.extend(
        _generate_aic_k_split_tiles(
            core_idx, outer_iter, inner_iter, outer_counts, inner_counts, sup_param,
            input_precision, 1, idx_in_section
        )
    )
    # C矩阵
    row_start, rows = (
        (inner_iter, inner_counts)
        if inner_param.input_bias == 0
        else (outer_iter, outer_counts)
    )
    col_start, cols = (
        (outer_iter, outer_counts)
        if inner_param.input_bias == 0
        else (inner_iter, inner_counts)
    )
    output_tile_m1_n1 = Tile(
        section,
        core_idx,
        row_start,
        col_start,
        rows,
        cols,
        idx_in_section,
        output_precision,
        -1,
    )
    return input_tiles_m1_n1, output_tile_m1_n1


def _generate_aic_k_split_tiles(
    core_idx: int,
    outer_iter: int,
    inner_iter: int,
    outer_counts: int,
    inner_counts: int,
    sup_param: int,
    input_precision: DType,
    input_bias: int,
    idx_in_section: int,
) -> list[Tile]:
    """
    生成AIC核的K轴分块输入Tile
    """
    split_k_input_tiles = []
    for k_iter in range(0, sup_param, inner_param.k):
        cols = inner_param.k if k_iter + inner_param.k <= sup_param else sup_param - k_iter
        t = Tile(
            section,
            core_idx,
            outer_iter,
            k_iter,
            outer_counts,
            cols,
            idx_in_section,
            input_precision,
            input_bias,
        )
        split_k_input_tiles.append(t)
    return split_k_input_tiles


def _generate_aiv_tiles(
    section,
    core_idx: int,
    outer_iter: int,
    inner_iter: int,
    outer_counts: int,
    inner_counts: int,
    sup_param: int,
    input_precision: DType,
    output_precision: DType,
    idx_in_section: int,
) -> tuple[list[Tile], Tile]:
    """
    生成AIV核的输入和输出Tile
    """
    input_tiles_m1_n1 = []

    row_start, rows = (
        (inner_iter, inner_counts)
        if inner_param.input_bias == 0
        else (outer_iter, outer_counts)
    )
    col_start, cols = (
        (outer_iter, outer_counts)
        if inner_param.input_bias == 0
        else (inner_iter, inner_counts)
    )

    # 生成输入tile
    for i in range(sup_param):
        input_tiles_m1_n1.append(
            Tile(
                section,
                core_idx,
                row_start,
                col_start,
                rows,
                cols,
                idx_in_section,
                input_precision,
                i,
            )
        )
    # 生成输出tile
    output_tile_m1_n1 = Tile(
        section,
        core_idx,
        row_start,
        col_start,
        rows,
        cols,
        idx_in_section,
        output_precision,
        -1,
    )
    return input_tiles_m1_n1, output_tile_m1_n1


def _plot_tiles(tiles: list[Tile], title: str) -> None:
    """
    绘制Tile的分布图
    """
    plot_result(tiles, title)


def _plot_input_tiles(input_tiles: list[Tile], section) -> None:
    """
    绘制输入Tile的分布图
    """
    input_tiles_by_matrix = {}
    for tile in input_tiles:
        input_tiles_by_matrix.setdefault(tile.input_bias, []).append(tile)

    for matrix_id, tiles in input_tiles_by_matrix.items():
        plot_result(tiles, f"{matrix_id} input tiles for {section}")


def generate_tiles_aic(section: Section) -> tuple[list[Tile], list[Tile]]:
    """
    对于某个AIC section的输入矩阵，按照tiling参数划分成tiles
    """
    tiling_param = section.tiling_param

    # 每个核平均的长宽
    m_core = section.m / tiling_param.h
    n_core = section.n / tiling_param.w

    m_param = LoopParam(
        section.m, tiling_param.m1, m_core, tiling_param.k1a, tiling_param.h, 0
    )
    n_param = LoopParam(
        section.n, tiling_param.n1, n_core, tiling_param.k1b, tiling_param.w, 1
    )

    # 行内优先循环，Z字型，n优先循环，m（列）外循环
    input_tiles, output_tiles = [], []
    if tiling_param.outer_dir == DirectionType.Z:
        input_tiles, output_tiles = generate_tiles_one_direction(
            CoreType.AIC,
            m_param,
            n_param,
            section,
            section.input_precision,
            section.output_precision,
            section.k,
        )
    # 列内优先循环，N字型，m优先循环，n（行）外循环

    elif tiling_param.outer_dir == DirectionType.N:
        input_tiles, output_tiles = generate_tiles_one_direction(
            CoreType.AIC,
            n_param,
            m_param,
            section,
            section.input_precision,
            section.output_precision,
            section.k,
        )

    return input_tiles, output_tiles


def generate_tiles_aiv(section: Section) -> tuple[list[Tile], list[Tile]]:
    """
    对于某个AIV section的输入矩阵，按照tiling参数划分成tiles
    """
    tiling_param = section.tiling_param
    # 每个核平均的长宽
    m_core = section.m / tiling_param.h
    n_core = section.n / tiling_param.w

    m_param = LoopParam(section.m, tiling_param.m1, m_core, 0, tiling_param.h, 0)
    n_param = LoopParam(section.n, tiling_param.n1, n_core, 0, tiling_param.w, 1)

    # 行内优先循环，Z字型，n优先循环，m（列）外
    input_tiles, output_tiles = [], []
    if tiling_param.outer_dir == "Z":
        input_tiles, output_tiles = generate_tiles_one_direction(
            CoreType.AIV,
            m_param,
            n_param,
            section,
            section.input_precision,
            section.output_precision,
            sup_param=section.input_cnt,
        )
    # 列内优先循环，N字型，m优先循环，n（行）外循环
    elif tiling_param.outer_dir == "N":
        input_tiles, output_tiles = generate_tiles_one_direction(
            CoreType.AIV,
            n_param,
            m_param,
            section,
            section.input_precision,
            section.output_precision,
            sup_param=section.input_cnt,
        )

    # 如果输出只有一个数据的话，直接就忽略
    if section.output_type == OutputType.TO_ONE:
        return input_tiles, []
    else:
        return input_tiles, output_tiles


def plot_result(tiles: list[Tile], title: str = "") -> None:
    """
    绘制Tile的分布图
    """
    # 按核分组并计算边界框
    tiles_by_core, core_rects = group_tiles_by_core(tiles)

    # 初始化绘图环境
    fig, ax, color = initialize_plot()

    # 绘制核心边界框
    draw_core_boundaries(ax, core_rects)

    # 绘制Tile
    draw_tiles(ax, tiles_by_core, color)

    # 设置绘图环境和显示图表
    finalize_plot(ax, tiles, title)


def group_tiles_by_core(tiles: list[Tile]) -> tuple[dict, dict]:
    """
    按核心分组Tile，并计算每个核心的边界框
    """
    tiles_by_core = {}
    core_rects = {}

    for tile in tiles:
        core_id = tile.core
        tiles_by_core.setdefault(core_id, []).append(tile)

        if core_id not in core_rects:
            core_rects[core_id] = (
                tile.row_start,
                tile.col_start,
                tile.row_start + tile.rows,
                tile.col_start + tile.cols,
            )
        else:
            current_rect = core_rects[core_id]
            new_rect = (
                min(current_rect[0], tile.row_start),
                min(current_rect[1], tile.col_start),
                max(current_rect[2], tile.row_start + tile.rows),
                max(current_rect[3], tile.col_start + tile.cols),
            )
            core_rects[core_id] = new_rect

    return tiles_by_core, core_rects


def initialize_plot() -> tuple[plt.Figure, plt.Axes, matplotlib.colors.Colormap]:
    """
    初始化绘图环境
    """
    fig, ax = plt.subplots()
    color = plt.get_cmap("viridis")
    return fig, ax, color


def draw_core_boundaries(ax: plt.Axes, core_rects: dict) -> None:
    """
    绘制每个核心的边界框
    """
    for _, rect in core_rects.items():
        core_rect = patches.Rectangle(
            (rect[1], rect[0]),
            rect[3] - rect[1],
            rect[2] - rect[0],
            edgecolor="r",
            facecolor="none",
            linewidth=5,
        )
        ax.add_patch(core_rect)


def draw_tiles(ax: plt.Axes, tiles_by_core: dict, color: matplotlib.colors.Colormap) -> None:
    """
    绘制每个Tile的矩形
    """
    idx_in_section_set = set([tile.idx_in_section for tile in sum(tiles_by_core.values(), [])])
    step = idx_in_section_set.__len__() // 5
    max_id = max([tile.idx_in_section for tile in sum(tiles_by_core.values(), [])]) // step

    for _, core_tiles in tiles_by_core.items():
        for tile in core_tiles:
            face = color((tile.idx_in_section // step) / max_id)
            x = tile.row_start
            y = tile.col_start
            w = tile.rows
            h = tile.cols
            rec = patches.Rectangle((y, x), h, w, edgecolor="b", facecolor=face)
            ax.add_patch(rec)


def finalize_plot(ax: plt.Axes, tiles: list[Tile], title: str) -> None:
    """
    设置绘图环境和显示图表
    """
    max_x = max([tile.row_start + tile.rows for tile in tiles])
    max_y = max([tile.col_start + tile.cols for tile in tiles])
    ax.set_xlim(max_y)
    ax.set_ylim(max_x)
    ax.invert_xaxis()

    sm = plt.cm.ScalarMappable(cmap=plt.get_cmap("viridis"))
    sm.set_array([])
    plt.colorbar(sm, ax=ax, orientation="horizontal")

    plt.title(title)
    plt.show()