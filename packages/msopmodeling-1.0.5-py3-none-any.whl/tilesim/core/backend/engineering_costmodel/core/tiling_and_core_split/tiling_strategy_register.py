# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

from collections import namedtuple
from enum import Enum

from core.common.entity import DirectionType

LoopStep = namedtuple('LoopStep', [
    'multi_core_m_step',
    'multi_core_n_step',
    'core_m_step',
    'core_n_step',
    'stride_m_step',
    'stride_n_step'
])


class TilingStrategyEnum(Enum):
    CATLASS = 0
    EQUALLY = 1
    SWIZZLE = 2
    UNFOLD = 3

    @staticmethod
    def from_str(strategy: str):
        for item in TilingStrategyEnum:
            if item.name.lower() == strategy.lower():
                return item
        raise ValueError(f"不支持的tiling策略: {strategy}")


class TilingParam:
    def __init__(
            self,
            # 基础切块参数
            m0,
            n0,
            k0,
            m1,
            n1,
            k1a,
            k1b,
            # 分核参数
            w,
            h,
            d=1,
            w_stride=0,
            h_stride=0,
            # 数据搬运方向参数
            inner_dir=DirectionType.Z,
            outer_dir=DirectionType.Z,
            # catlass的tiling配置参数
            swizzle_offset=-1,
            swizzle_direction=0,
            # tiling策略
            tiling_strategy=TilingStrategyEnum.CATLASS,
            align_tiles: int = 0,
            op_name="",
            parallel_config=None,
    ):
        # l0 tiling数据
        self.m0 = m0
        self.n0 = n0
        self.k0 = k0
        # l1 tiling数据，对于AIV核，k不需要，m1默认为1
        self.m1 = m1
        self.n1 = n1
        self.k1a = k1a
        self.k1b = k1b
        # 分核参数 w-横向并排放置多少个核，对应n；h-纵向并排放置多少个核，对应m
        self.w = w
        self.h = h
        self.d = d
        self.w_stride = w_stride
        self.h_stride = h_stride
        self.core_num = w * h * d
        self.inner_dir = inner_dir
        self.outer_dir = outer_dir
        self.swizzle_offset = swizzle_offset
        self.swizzle_direction = swizzle_direction
        self.tiling_strategy = tiling_strategy
        self.align_tiles = align_tiles
        self.op_name = op_name
        self.parallel_config = parallel_config
        self.parallel_core_num = self.core_num

    def get_loop_step(self):
        multi_core_m_step = self.h * (self.h_stride + 1) * self.m1
        multi_core_n_step = self.w * (self.w_stride + 1) * self.n1
        core_m_step = (self.h_stride + 1) * self.m1
        core_n_step = (self.w_stride + 1) * self.n1
        stride_m_step = self.m1
        stride_n_step = self.n1
        return LoopStep(
            multi_core_m_step,
            multi_core_n_step,
            core_m_step,
            core_n_step,
            stride_m_step,
            stride_n_step)

    def __str__(self):
        return (
            f"m0:{self.m0},n0:{self.n0},k0:{self.k0},m1:{self.m1},n1:{self.n1},"
            f"k1a:{self.k1a},k1b:{self.k1b},w:{self.w},h:{self.h}"
        )


def convert_list_to_tiling_param(tiling_param: list):
    tiling_strategy = TilingStrategyEnum.from_str(tiling_param[0])

    if tiling_strategy == TilingStrategyEnum.CATLASS:
        m, n, k0, k1, core_num, swizzle_offset, swizzle_direction = tiling_param[1:8]
        w = core_num
        h = 1
    elif tiling_strategy == TilingStrategyEnum.SWIZZLE:
        m, n, k0, k1, w, h = tiling_param[1:7]
        swizzle_offset, swizzle_direction = 1, 0
    else:
        raise ValueError(f"不支持的tiling策略: {tiling_strategy}")

    return TilingParam(
        m0=m,
        n0=n,
        k0=k0,
        m1=m,
        n1=n,
        k1a=k1,
        k1b=k1,
        w=w,
        h=h,
        swizzle_offset=swizzle_offset,
        swizzle_direction=swizzle_direction,
    )