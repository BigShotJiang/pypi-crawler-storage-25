# Copyright (c) Huawei Technologies Co., Ltd. 2025-202  _5. All rights reserved.

import math
import time

from core.common.entity import CoreType, Section, Tile
from core.backend.engineering_costmodel.core.tiling_and_core_split.tiling_strategy import TilingStrategy
from core.backend.engineering_costmodel.core.tiling_and_core_split.tiling_strategy_register import \
    TilingStrategyEnum


class CatlassTiling(TilingStrategy):

    def __init__(self, single_tile_output: bool = False):
        super().__init__(TilingStrategyEnum.CATLASS)
        self.m = 0
        self.n = 0
        self.k = 0
        self.tiling_param = None
        self.section = None
        self.total_tile_cnt = 0
        # 添加实例变量来保持状态
        self.swizzle_offset_idx = 0
        self.col_offset = 0
        self.cur_outer_dir = 1
        self.single_tile_output = single_tile_output

    def __init_from_section(self, sec: Section):
        self.m = sec.m
        self.n = sec.n
        self.k = sec.k
        self.tiling_param = sec.tiling_param
        self.section = sec
        self.total_tile_cnt = math.ceil(self.m / self.tiling_param.m1) * math.ceil(
            self.n / self.tiling_param.n1
        )
        # 初始化状态变量
        self.swizzle_offset_idx = self.tiling_param.swizzle_offset
        self.col_offset = 0
        self.cur_outer_dir = 1

    def __generate_k_splits(self):
        """生成k轴上的分割长度列表"""
        k_len_split = []
        former_k = self.k // self.tiling_param.d
        former_k_cnt = self.tiling_param.d - self.k % self.tiling_param.d
        for i in range(self.tiling_param.d):
            if i < former_k_cnt:
                k_len_split.append(former_k)
            else:
                k_len_split.append(former_k + 1)
        return k_len_split

    def __generate_io_tiles_aic(
            self, row_start, col_start, rows, cols, core_offset, idx_in_section
    ):
        k_len_split = self.__generate_k_splits()
        output_tiles, input_tiles = [], []
        k_offset = 0

        for i in range(self.tiling_param.d):
            k_len = k_len_split[i]
            core_idx = core_offset + i
            if not self.single_tile_output:
                output_tiles.append(
                    Tile(
                        self.section,
                        core_idx,
                        row_start,
                        col_start,
                        rows,
                        cols,
                        idx_in_section,
                        self.section.output_precision,
                        -1,
                        k_len,
                        k_offset,
                    )
                )
            k_axis_input_tiles, k_axis_output_tiles = (
                self.__generate_tiles_for_k_axis(
                    core_idx, row_start, col_start, rows, cols, k_offset, k_len, idx_in_section
                ))
            input_tiles.extend(k_axis_input_tiles)
            output_tiles.extend(k_axis_output_tiles)
            k_offset += k_len

        return input_tiles, output_tiles

    def __generate_tiles_for_k_axis(
            self, core_idx, row_start, col_start, rows, cols, k_offset, k_len, idx_in_section
    ):
        input_tiles, output_tiles = [], []
        k_start = k_offset
        k_end = k_offset + k_len

        while k_start < k_end:
            k_len_single_input = min(k_end - k_start, self.tiling_param.k1a)
            # A,B矩阵
            input_tiles.extend(
                [Tile(
                    self.section,
                    core_idx,
                    row_start,
                    k_start,
                    rows,
                    k_len_single_input,
                    idx_in_section,
                    self.section.input_precision,
                    0,
                    k_len,
                    k_offset,
                ), Tile(
                    self.section,
                    core_idx,
                    col_start,
                    k_start,
                    cols,
                    k_len_single_input,
                    idx_in_section,
                    self.section.input_precision,
                    1,
                    k_len,
                    k_offset,
                )]
            )
            # C矩阵
            if self.single_tile_output:
                output_tiles.append(
                    Tile(self.section,
                         core_idx,
                         row_start,
                         col_start,
                         rows,
                         cols,
                         idx_in_section,
                         self.section.input_precision,
                         -1,
                         k_len,
                         k_start))
                idx_in_section += 1

            k_start += k_len_single_input

        return input_tiles, output_tiles

    def __generate_io_tiles_aiv(
            self, row_start, col_start, rows, cols, core_offset, idx_in_section
    ):
        input_tiles = [
            Tile(
                self.section,
                core_offset,
                row_start,
                col_start,
                rows,
                cols,
                idx_in_section,
                self.section.input_precision,
                1,
                0,
                0,
            )
        ]
        output_tiles = [
            Tile(
                self.section,
                core_offset,
                row_start,
                col_start,
                rows,
                cols,
                idx_in_section,
                self.section.input_precision,
                -1,
                0,
                0,
            )
        ]
        return input_tiles, output_tiles

    def __update_coordinate_swizzle_col_fixed(self, row_start, col_start, rows, cols):
        """按列优先方式进行坐标更新"""
        row_start += rows
        self.swizzle_offset_idx -= 1

        if self.swizzle_offset_idx == 0 or row_start >= self.m:
            # 更新列坐标
            if self.cur_outer_dir == 1:
                col_start += cols
            else:
                col_start -= self.tiling_param.n1

            self.swizzle_offset_idx = self.tiling_param.swizzle_offset

            # 检查是否需要换向
            if (self.cur_outer_dir == 1 and col_start >= self.n) or (self.cur_outer_dir == -1 and col_start < 0):
                # 回退列坐标
                if self.cur_outer_dir == 1:
                    col_start -= cols
                else:
                    col_start += self.tiling_param.n1
                self.cur_outer_dir *= -1
                self.col_offset = row_start
            else:
                # 重置行坐标到偏移位置
                row_start = self.col_offset

        return row_start, col_start

    def generate_tiles(self, section: Section, open_plot=False, single_tile_output=False):
        time_start = time.time()
        self.single_tile_output = single_tile_output
        self.__init_from_section(section)

        row_start, col_start = 0, 0
        tile_cnt = 0

        input_tiles, output_tiles = [], []
        core_idx, idx_in_section = 0, 0

        while tile_cnt < self.total_tile_cnt:
            rows = min(self.tiling_param.m1, self.m - row_start)
            cols = min(self.tiling_param.n1, self.n - col_start)

            input_tiles_single_idx, output_tiles_single_idx = (
                self.__generate_io_tiles_aic(
                    row_start, col_start, rows, cols, core_idx, idx_in_section
                )
                if self.section.core_type == CoreType.AIC
                else self.__generate_io_tiles_aiv(
                    row_start, col_start, rows, cols, core_idx, idx_in_section
                )
            )

            core_idx += self.tiling_param.d
            if core_idx >= self.tiling_param.core_num:
                core_idx = 0
                if not single_tile_output:
                    idx_in_section += 1
                else:
                    idx_in_section += len(output_tiles_single_idx)

            input_tiles.extend(input_tiles_single_idx)
            output_tiles.extend(output_tiles_single_idx)

            # 更新坐标
            if self.tiling_param.swizzle_direction == 0:
                row_start, col_start = self.__update_coordinate_swizzle_col_fixed(
                    row_start, col_start, rows, cols
                )

            tile_cnt += 1

        return input_tiles, output_tiles