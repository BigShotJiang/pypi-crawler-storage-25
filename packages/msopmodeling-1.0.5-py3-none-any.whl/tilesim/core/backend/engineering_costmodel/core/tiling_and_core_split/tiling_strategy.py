# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

import abc

from core.backend.engineering_costmodel.core.tiling_and_core_split.tiling_strategy_register import TilingStrategyEnum


class TilingStrategy(abc.ABC):

    def __init__(self, strategy: TilingStrategyEnum):
        self.strategy = strategy

    @abc.abstractmethod
    def generate_tiles(self, section, open_plot=False, single_tile_output=False) -> tuple[list, list]:
        """
        切分tile
        :param section:
        :return: input_tiles, output_tiles
        """
        pass