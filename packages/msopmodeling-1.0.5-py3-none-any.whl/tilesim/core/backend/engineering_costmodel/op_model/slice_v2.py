# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

import numpy as np

from core.common.entity import DType, ResultKey
from core.common.log_format import logging

# 创建一个日志记录器
logger = logging.getLogger("engineering_costmodel.operator_test.operator_tests")


class Layout:
    def __init__(self, shape, stride=None):
        self.dim = len(shape)
        self.s = shape
        if stride:
            self.d = stride
        else:
            self.make_stride()

    def make_stride(self, form="RowMajor"):
        d = [1 for i in range(self.dim)]
        if form == "RowMajor":
            for i in range((self.dim - 1), 0, -1):
                d[i - 1] = d[i] * self.s[i]
        self.d = d


class SliceV2:
    # 8.3.RC1.alpha001, SliceV2
    def __init__(self, input_precision: DType, output_precision: DType, output_shape, arch="910B", vec_core_num=48, **kwargs):
        if arch == "910B":
            self.ub_size = 192 * 1024
        else:
            self.ub_size = 256 * 1024
        self.output_shape = output_shape
        self.data_size = input_precision.size
        self.core_num = vec_core_num

    def pre_process(self, input_shape, output_shape):
        self.dim = len(input_shape)
        self.input_shape = input_shape
        self.input_size = int(np.prod(input_shape) * self.data_size)
        self.output_shape = output_shape
        self.output_size = int(np.prod(output_shape) * self.data_size)
        self.step = [1 for i in range(self.dim)]

        self.input_layout = Layout(input_shape)
        self.output_layout = Layout(output_shape)

        # 从右往左第一个切分轴
        cut_axis = self.dim - 1
        single_size = self.data_size
        while (
                cut_axis >= 0
                and self.output_shape[cut_axis] == self.input_shape[cut_axis]
                and self.step[cut_axis] == 1
        ):
            single_size *= output_shape[cut_axis]
            cut_axis -= 1
        if cut_axis >= 0 and self.step[cut_axis] == 1:
            single_size *= output_shape[cut_axis]

        # 如果切分轴是最后一个轴
        if cut_axis == self.dim - 1:
            # 如果Step[-1]!=1，一次搬运的size是End-Start
            if self.step[self.dim - 1] != 1:
                single_size = (
                                      self.input_shape[self.dim - 1] - self.output_shape[self.dim - 1]
                              ) * self.data_size
            else:
                single_size = self.output_shape[self.dim - 1] * self.data_size
        self.cut_axis = cut_axis
        self.single_size = single_size
        self.information = {}  # 包含分支和组件信息

    def mov_out_to_ub(
            self, burst=0, burst_size=0, src_stride=0, dst_stride=0, src_offset=0, dst_offset=0
    ):
        head = 1e-7
        size = burst * burst_size
        if size > 8192:
            self.mte2_bw = 39 * 1024 ** 3
        else:
            self.mte2_bw = 20 * 1024 ** 3
        return head + burst * burst_size / self.mte2_bw

    def mov_ub_to_out(
            self, burst=0, burst_size=0, src_stride=0, dst_stride=0, src_offset=0, dst_offset=0
    ):
        head = 1e-7
        self.mte3_bw = 80 * 1024 ** 3
        return head + burst * burst_size / self.mte3_bw

    def mov_out_to_ub_align(
            self, burst, burst_size=0, src_stride=0, dst_stride=0, src_offset=0, dst_offset=0
    ):
        head = 1e-7
        self.mte2_bw = 30 * 1024 ** 3
        return head + burst * burst_size / self.mte2_bw

    def mov_ub_to_out_align(
            self, burst, burst_size=0, src_stride=0, dst_stride=0, src_offset=0, dst_offset=0
    ):
        head = 1e-7
        self.mte3_bw = 45 * 1024 ** 3
        return head + burst * burst_size / self.mte3_bw

    def _handle_small_cut_axis_case(self):
        """处理切分轴较小的情况"""
        # VNCHWCONV处理的SingleSize不超过6144B？
        single_size = min(6144, 6144 // self.cut_size * self.cut_size)
        self.information["branch"] = "Small CutAxis"
        # mte2是瓶颈组件
        # mte2搬运模式：Burst=1，BurstSize=CutSize的连续整块数据搬运，搬运SingleSzie//CutSize次
        # 起始地址不对齐似乎不影响带宽
        self.mte2_bw = 15 * 1024 ** 3  # 对于一次搬运5600B左右的数据量，带宽大概是如此
        mte2 = float(max(self.input_size, single_size) / self.core_num / self.mte2_bw)

        # mte3搬运模式：Burst=1，BurstSize=SingleSize的连续整块数据搬运
        self.mte3_bw = 105 * 1024 ** 3
        mte3 = float(max(self.output_size, single_size) / self.core_num / self.mte3_bw)

        # 一次VNCHWCONV处理16组
        # step只影响VNCHWCONV
        vec_size = 16 * single_size  # B
        outer_loop_per_core = max(self.input_size, single_size) / self.core_num / vec_size
        self.vnchwconv = float(
            outer_loop_per_core * 1.625e-6
        )  # 1.62 5e-6是一个很粗糙的值，需要测试确认，但目前不知道如何测试VNCHWCONV指令的耗时曲线

        self.information["SingleSize(B)"] = single_size
        self.information["aiv_mte2_time(us)"] = mte2 * 1e6
        self.information["mte2_BW(GB/s)"] = self.mte2_bw / 1024 ** 3
        self.information["aiv_mte3_time(us)"] = mte3 * 1e6
        self.information["mte3_BW(GB/s)"] = self.mte3_bw / 1024 ** 3
        self.information["VNCHWCONV(us)"] = self.vnchwconv * 1e6
        t = mte2 + mte3 + self.vnchwconv
        self.information["aiv_time(us)"] = t * 1e6
        return t

    def _calculate_composition_params(self, src_stride_size, outer_loop):
        """计算组合传输参数"""
        outer_loop_per_core = (outer_loop + self.core_num - 1) // self.core_num  # 单核OuterLoop
        burst = self.ub_size // self.single_size  # 一次批量传输的Burst大小
        burst = min(burst, self.input_shape[self.cut_axis - 1])  # Burst不能超过上一个轴的大小
        if src_stride_size < 256 * 12:
            burst = 2  # ?
        return outer_loop_per_core, burst

    def _handle_composition_case(self, src_stride_size, outer_loop):
        """处理组合传输情况"""
        outer_loop_per_core, burst = self._calculate_composition_params(src_stride_size, outer_loop)

        single_size = burst * self.single_size  # 一次mte2搬运指令总共的SingleSize
        if burst == 0:
            rounds = 0
        else:
            rounds = outer_loop_per_core // burst  # 多少次mte2搬运指令

        tail_burst = outer_loop_per_core - rounds * burst  # 尾块
        tail_size = tail_burst * self.single_size

        # SrcStride是否对齐512B似乎不影响带宽？
        # 这样计算流水是对的，但不好使，不知道为什么带宽会随着Rounds上升而下降，Cache的命中率似乎在降低
        mte2_time = rounds * self.mov_out_to_ub(
            burst=burst, burst_size=self.single_size, src_stride=src_stride_size
        ) + self.mov_out_to_ub(
            burst=tail_burst, burst_size=self.single_size, src_stride=src_stride_size
        )
        mte3_time = rounds * self.mov_ub_to_out(
            burst=1, burst_size=single_size
        ) + self.mov_ub_to_out(burst=1, burst_size=tail_size)

        t = mte2_time + mte3_time
        self.information["branch"] = "Composition"
        self.information["OuterLoopPerCore"] = outer_loop_per_core
        self.information["TailSize"] = tail_size
        self.information["Rounds"] = rounds
        self.information["Burst"] = burst
        self.information["SingleSize(B)"] = single_size
        self.information["aiv_mte2_time(us)"] = mte2_time * 1e6
        self.information["aiv_mte3_time(us)"] = mte3_time * 1e6
        self.information["aiv_time(us)"] = t * 1e6
        return t

    def _handle_32b_aligned_full_loop(self, outer_loop):
        """处理32字节对齐的完整循环"""
        self.information["branch"] = "Full Loop 32B Align"
        single_size = self.single_size
        outer_loop_per_core = (outer_loop + self.core_num - 1) // self.core_num
        mte2_time = outer_loop_per_core * self.mov_out_to_ub_align(
            burst=1, burst_size=single_size
        )
        mte3_time = outer_loop_per_core * self.mov_ub_to_out_align(
            burst=1, burst_size=single_size
        )
        return mte2_time, mte3_time, single_size

    def _handle_non_32b_aligned_full_loop(self, outer_loop):
        """处理非32字节对齐的完整循环"""
        self.information["branch"] = "Full Loop"
        mov_32b = 2e-7
        single_size = (self.single_size // 32) * 32
        outer_loop_per_core = (outer_loop + self.core_num - 1) // self.core_num
        mte2_time = (
                outer_loop_per_core * mov_32b
                + outer_loop_per_core
                * self.mov_out_to_ub_align(burst=1, burst_size=single_size)
        )
        mte3_time = (
                outer_loop_per_core * mov_32b
                + outer_loop_per_core
                * self.mov_ub_to_out_align(burst=1, burst_size=single_size)
        )
        return mte2_time, mte3_time, single_size

    def _update_performance_info(self, mte2_time, mte3_time, single_size, t):
        """更新性能信息"""
        self.information["SingleSize(B)"] = single_size
        self.information["aiv_mte2_time(us)"] = mte2_time * 1e6
        self.information["mte2_BW(GB/s)"] = self.mte2_bw / 1024 ** 3
        self.information["aiv_mte3_time(us)"] = mte3_time * 1e6
        self.information["mte3_BW(GB/s)"] = self.mte3_bw / 1024 ** 3
        self.information["aiv_time(us)"] = t * 1e6

    def _time_predict(self, input_shape, output_shape):
        self.pre_process(input_shape, output_shape)

        if self.cut_axis <= 0:
            bw = 100 * 1024 ** 3
            t = self.output_size / self.core_num / bw
            self.information["branch"] = "CutAxis<=0"
            self.information["aiv_mte2_time(us)"] = t * 1e6
            self.information["aiv_mte3_time(us)"] = t * 1e6
            self.information["aiv_time(us)"] = 2 * t * 1e6
            return self.information["aiv_time(us)"]

        # 切分轴之后的Input数据量很小，直接把切分轴之后的数据不做切分整体搬到UB，然后用VNCHWCONV在UB里切分
        self.cut_size = int(np.prod(self.input_layout.s[self.cut_axis:])) * self.data_size
        if self.cut_size < 1536:  # 试出来的边界
            t = self._handle_small_cut_axis_case()
            return t * 1e6

        src_stride_size = self.input_layout.d[self.cut_axis - 1] * self.data_size
        outer_loop = int(np.prod(self.output_shape[: self.cut_axis]))

        # 判断是否满足组合传输条件
        condition1 = self.single_size < self.ub_size
        condition2 = np.prod(self.input_shape[:self.cut_axis]) == outer_loop
        condition3 = (src_stride_size % 32 == 0) and (self.single_size % 32 == 0)

        if condition1 and condition2 and condition3:
            t = self._handle_composition_case(src_stride_size, outer_loop)
            return t * 1e6

        # Burst=1，每回合mte2，mte3传输一个SingleSize
        # 对齐32B
        if self.single_size % 32 == 0:
            mte2_time, mte3_time, single_size = self._handle_32b_aligned_full_loop(outer_loop)
        # 不对齐32B，会先传输一个32B
        else:
            mte2_time, mte3_time, single_size = self._handle_non_32b_aligned_full_loop(outer_loop)

        t = mte2_time + mte3_time
        self._update_performance_info(mte2_time, mte3_time, single_size, t)
        return t * 1e6  # us

    def time_predict(self, shapes: list, tiling_param, aicore):
        core_time = self._time_predict(shapes[0], self.output_shape[0]) + 1.5 # CPU头开销
        return {
            ResultKey.CORE_TIME: core_time,
            ResultKey.VEC_TIME: self.information['aiv_time(us)'],
            ResultKey.MTE2_TIME_AIV: self.information['aiv_mte2_time(us)'],
            ResultKey.MTE3_TIME: self.information['aiv_mte3_time(us)'],
            ResultKey.L2_MISS_RATE: 1
        }


if __name__ == "__main__":
    input_shape = [384, 180, 160]
    output_shape = [384, 90, 160]
    s = SliceV2(DType.FP32, DType.FP32, output_shape=output_shape)
    t = s._time_predict(
        input_shape=input_shape,
        output_shape=output_shape
    )
    logger.info("t = %s", t)
    logger.info("S.information = %s", s.information)