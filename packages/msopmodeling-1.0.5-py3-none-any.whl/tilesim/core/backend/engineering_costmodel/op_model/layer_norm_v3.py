# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

from core.backend.engineering_costmodel.core.aicore_costmodel import AICoreCostModel
from core.common.entity import (
    CoreType,
    VecOpType,
    DType,
    ResultKey,
    Section,
    TensorData,
    MemLoc, PipeAnaConfig, CoreUnit,
)
from core.backend.engineering_costmodel.core.pipeline.aiv_pipeline import AIVPipeline
from core.backend.engineering_costmodel.core.tiling_and_core_split.catlass_tiling import CatlassTiling
from core.backend.engineering_costmodel.core.tiling_and_core_split.tiling_strategy_register import TilingParam
from core.backend.engineering_costmodel.core.vector_op import VectorBasicOp
from core.backend.engineering_costmodel.op_model.basic_operator import BasicOperatorModel
from core.common.log_format import logging

# 创建一个日志记录器
logger = logging.getLogger(__name__)


class LayerNormV3Model(BasicOperatorModel):
    def __init__(self, input_precision: DType, output_precision: DType, **kwargs):
        super().__init__(
            "LayerNormV3Forward", CoreType.AIV, input_precision, output_precision
        )
        self._init_tensors(input_precision)
        if input_precision == DType.BF16:
            self.layer_norm_v3_op = self._generate_layer_norm_v3_op_bf16()
        else:
            self.layer_norm_v3_op = self._generate_layer_norm_v3_op_fp32()

    def _init_tensors(self, input_precision):
        """初始化张量对象"""
        row, col, part_col = "row", "col", "part_col"
        self.input_x = TensorData("input_x", input_precision, [row, col], MemLoc.GM)
        self.input_gamma_beta = TensorData("input_gamma", input_precision, [col], MemLoc.GM)
        self.input_x_ub = TensorData("input_x", DType.FP32, [row, col], MemLoc.UB)
        self.input_gamma_beta_ub = TensorData("input_gamma", DType.FP32, [col], MemLoc.UB)
        self.full_data = TensorData("full_data_on_ub", DType.FP32, [row, col], MemLoc.UB)
        self.part_data = TensorData("vcadd_input_data", DType.FP32, [row, part_col], MemLoc.UB)
        self.reduce_data = TensorData("reduce_data", DType.FP32, [row, 1], MemLoc.UB)
        self.output_rstd = TensorData("reduce_data", DType.FP32, [row, 1], MemLoc.GM)
        self.output_norm = TensorData("reduce_data", input_precision, [row, col], MemLoc.GM)
        self.row = "row"
        self.col = "col"
        self.part_col = "part_col"

    def _generate_layer_norm_v3_op_bf16(self):
        bf16_initial_ops = [
            VectorBasicOp(VecOpType.CONV_BF162F32, [self.input_x], [self.input_x_ub], pipe_barrier=False),
            VectorBasicOp(VecOpType.VMULS, [self.input_x], [self.full_data]),
            VectorBasicOp(VecOpType.MOVEV, [self.full_data], [self.full_data]),
        ]
        bf16_final_ops = \
            [VectorBasicOp(VecOpType.VMUL, [self.part_data, self.reduce_data], [self.part_data]) for _ in range(9)] + \
            [VectorBasicOp(VecOpType.VMUL, [self.part_data, self.input_gamma_beta], [self.part_data]) for _ in range(9)] + \
            [VectorBasicOp(VecOpType.VADD, [self.part_data, self.input_gamma_beta], [self.part_data]) for _ in range(8)] + \
            [VectorBasicOp(VecOpType.VADD, [self.part_data, self.input_gamma_beta], [self.part_data, self.full_data])] + \
            [VectorBasicOp(VecOpType.CONV_F322BF16, [self.full_data], [self.output_norm])]

        return bf16_initial_ops + \
               self._create_first_reduce_ops() + \
               self._create_sub_ops() + \
               self._create_second_reduce_ops() + \
               bf16_final_ops

    def _generate_layer_norm_v3_op_fp32(self):
        """构建完整的操作序列"""
        return (
                self._create_initial_ops()
                + self._create_first_reduce_ops()
                + self._create_sub_ops()
                + self._create_second_reduce_ops()
                + self._create_final_ops()
        )

    def _create_initial_ops(self):
        """创建初始操作（VMULS和MOVEV）"""
        return [
            VectorBasicOp(VecOpType.VMULS, [self.input_x], [self.full_data], pipe_barrier=False),
            VectorBasicOp(VecOpType.MOVEV, [self.full_data], [self.full_data]),
        ]

    def _create_first_reduce_ops(self):
        """创建第一个ReduceSum操作序列"""
        ops = [VectorBasicOp(VecOpType.VADD, [self.part_data, self.part_data], [self.part_data]) for _ in range(9)]
        ops.append(VectorBasicOp(VecOpType.VCADD, [self.part_data], [self.reduce_data]))
        return ops

    def _create_sub_ops(self):
        """创建减法相关操作（VSUB和VMUL）"""
        sub_ops = [VectorBasicOp(VecOpType.VSUB, [self.part_data, self.part_data], [self.part_data]) for _ in range(9)]
        return sub_ops + [
            VectorBasicOp(VecOpType.VMUL_SELF, [self.full_data, self.full_data], [self.full_data]),
            VectorBasicOp(VecOpType.VMULS, [self.full_data], [self.full_data]),
        ]

    def _create_second_reduce_ops(self):
        """创建第二个ReduceSum操作序列"""
        ops = [VectorBasicOp(VecOpType.VADD, [self.part_data, self.part_data], [self.part_data]) for _ in range(9)]
        ops.extend([
            VectorBasicOp(VecOpType.VCADD, [self.part_data], [self.reduce_data]),
            VectorBasicOp(VecOpType.VADDS, [self.reduce_data], [self.reduce_data]),
            VectorBasicOp(VecOpType.VSQRT, [self.reduce_data], [self.reduce_data]),
            VectorBasicOp(VecOpType.VDIV, [self.reduce_data], [self.reduce_data, self.output_rstd]),
        ])
        return ops

    def _create_final_ops(self):
        """创建最终的乘法和加法操作"""
        mul_ops = [
            VectorBasicOp(VecOpType.VMUL, [self.part_data, self.reduce_data], [self.part_data]) for _ in range(9)
        ]
        gamma_ops = [
            VectorBasicOp(VecOpType.VMUL, [self.part_data, self.input_gamma_beta], [self.part_data]) for _ in range(9)
        ]
        add_ops = \
            [VectorBasicOp(VecOpType.VADD, [self.part_data, self.input_gamma_beta], [self.part_data]) for _ in range(8)] + \
            [VectorBasicOp(VecOpType.VADD, [self.part_data, self.input_gamma_beta], [self.part_data, self.output_norm])]
        return mul_ops + gamma_ops + add_ops

    def time_predict(
            self, shapes: list, tiling_param: list[TilingParam], aicore: AICoreCostModel
    ) -> dict[ResultKey, float]:
        rows = 1
        for i in range(len(shapes[0]) - 1):
            rows *= shapes[0][i]
        cols = shapes[0][-1]
        logger.info("rows = %s", rows)
        logger.info("cols = %s", cols)

        section = Section(
            0,
            CoreType.AIV,
            rows,
            0,
            cols,
            tiling_param[0],
            self.input_precision,
            self.output_precision,
        )
        tiling = CatlassTiling()
        input_tiles, output_tiles = tiling.generate_tiles(section)
        logger.info("len(input_tiles) = %s", len(input_tiles))
        for tile in input_tiles:
            tile.fused_op = self.layer_norm_v3_op
            shape_dict = {
                self.row: tile.rows,
                self.col: tile.cols,
                self.part_col: tile.cols // 20,
            }
            tile.shape_dict = shape_dict

        aiv_pipe = AIVPipeline(aicore, tiling_param[0])

        core_set = {tile.core for tile in input_tiles}
        size_by_core = {
            core: sum([t.size for t in input_tiles if t.core == core])
            for core in core_set
        }
        max_size_core = max(size_by_core.items(), key=lambda x: x[1])[0]
        input_tiles_new = [tile for tile in input_tiles if tile.core == max_size_core]
        pipe_ana_config = [(CoreUnit.AIV_MTE2, CoreUnit.VEC, CoreUnit.AIV_MTE3)]
        ret = aiv_pipe.calculate_time(input_tiles_new, output_tiles, PipeAnaConfig(pipe_ana_config))
        if self.input_precision == DType.BF16:
            ret[ResultKey.CORE_TIME] += 9
            ret[ResultKey.AIV_TIME] += 9
        elif self.input_precision == DType.FP32:
            ret[ResultKey.CORE_TIME] += 3
            ret[ResultKey.AIV_TIME] += 3
        return ret