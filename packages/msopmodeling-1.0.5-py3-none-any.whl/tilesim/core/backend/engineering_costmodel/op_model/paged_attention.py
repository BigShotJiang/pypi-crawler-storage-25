# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from core.common.entity import DType, CoreType, ResultKey
from core.backend.engineering_costmodel.core.aicore_costmodel import AICoreCostModel
from core.backend.engineering_costmodel.core.tiling_and_core_split.tiling_strategy_register import TilingParam
from core.backend.engineering_costmodel.op_model.fused_infer_attention import Layout, FlashAttentionInner
from core.backend.engineering_costmodel.op_model.basic_operator import BasicOperatorModel


def _parse_shape(shapes: list, input_param: list) -> list:
    q = shapes[0]
    k = shapes[1]
    v = shapes[2]
    block = shapes[3]

    if len(q) != 3 or len(k) != 4 or len(v) != 4 or len(block) != 2:
        raise ValueError(f"shape error for {shapes}")

    # batch
    if q[0] != block[0]:
        raise ValueError(f"batch size of q and block should be equal, but got {q[0]} and {block[0]}")

    # d
    if q[-1] != k[-1] or k[-1] != v[-1]:
        raise ValueError(f"d of q, k, v should be equal, but got {q[-1]}, {k[-1]}, {v[-1]}")

    # page block
    if k[0] != v[0] or k[1] != v[1]:
        raise ValueError(f"page block size of k and v should be equal, but got {k[:2]} and {v[:2]}")

    # n
    if k[2] != v[2]:
        raise ValueError(f"n of k and v should be equal, but got {k[2]} and {v[2]}")

    b, s1, n, d = q[0], q[1], k[2], q[2]

    if input_param is None or len(input_param) == 0:
        s2 = k[0] * k[1]
    else:
        s2_list = input_param[0]
        if type(input_param[0]) == int:
            s2_list = [input_param[0]]

        if len(s2_list) != b:
            raise ValueError(f"length of s2_list should be equal to b, but got {len(s2_list)} and {b}")

        s2 = s2_list[0]

    return [[b, s1, 1, d], [b, s2, n, d], [b, s2, n, d]]


class PagedAttention(BasicOperatorModel):

    def __init__(self,
                 input_precision: DType,
                 output_precision: DType,
                 layout: str = "BSND",
                 param: list = None,
                 **kwargs
                 ):
        super().__init__("PagedAttention", CoreType.MIX, input_precision, output_precision)
        self.fa = FlashAttentionInner(
            input_precision=input_precision,
            output_precision=output_precision,
            layout=layout,
            param=param)
        self.layout = Layout(layout)

    def time_predict(
            self, shapes: list, tiling_param: list[TilingParam], aicore: AICoreCostModel
    ) -> dict[ResultKey, float]:
        shapes = _parse_shape(shapes, self.fa.param)
        res = self.fa.time_predict(shapes, tiling_param, aicore)
        return res