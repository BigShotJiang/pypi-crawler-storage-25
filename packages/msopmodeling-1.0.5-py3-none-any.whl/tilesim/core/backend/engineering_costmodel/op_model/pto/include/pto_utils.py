from core.common.entity import DType


class CPointer:
    def __init__(self, addr, dtype):
        # 地址：支持 int 或 hex 字符串
        if isinstance(addr, str):
            self.addr = int(addr, 16)
        elif isinstance(addr, int):
            self.addr = addr
        else:
            raise TypeError("addr must be int or hex string (e.g., '0x1000')")
        self.dtype = dtype
        self.dtype_size = dtype.size

    def __add__(self, other):
        if not isinstance(other, int):
            raise TypeError("only pointer + int is supported")
        return CPointer(self.addr + other * self.dtype_size, self.dtype)

    def __iadd__(self, other):
        if not isinstance(other, int):
            raise TypeError("only pointer += int is supported")
        self.addr += other * self.dtype_size
        return self

    def __repr__(self):
        return f"CPointer(addr=0x{self.addr:X}, precision={self.dtype_size})"

    def to_block_id(self):
        return self.addr // 32


# 不符合规范，无法修改，且为临时适配
class CPTOTile:
    def init_template(self):
        # Template
        self.Loc_ = None
        self.Element_ = None
        self.Rows_ = None
        self.Cols_ = None
        self.BFractal = None
        self.SFractal_ = None
        self.PadValue = None
        self.SFractalSize = None
        self.RowValid_ = self.Rows_
        self.ColValid_ = self.Cols_

    def init_public(self):
        # public
        self.Loc = self.Loc_
        self.Rows = self.Rows_
        self.Cols = self.Cols_

    def __init__(self, row, col, row_stride, addr, dtype: DType):
        self.init_template()

        self.RowStride = row_stride
        self.Rows = row
        self.Cols = col
        self.addr = addr
        self.DType = dtype
        self.SFractal = SLayout.ColMajor

        self.isRowMajor = True
        self.isColMajor = False
        self.isBoxedLayout = 0
        self.isInnerColMajor = False
        self.isInnerRowMajor = False
        self.InnerRows = 0
        self.InnerCols = 0
        self.InnerNumel = 0

    def GetValidRow(self):
        return self.Rows

    def GetValidCol(self):
        return self.Cols

    def data(self):
        return self


class SLayout:
    RowMajor = "RowMajor"
    ColMajor = "ColMajor"


def __cce_get_tile_ptr(tile: CPTOTile):
    return CPointer(tile.addr, tile.DType)


# fake
def SetContinuousMask(*args):
    pass


class RoundMode:
    CAST_RINT = "CAST_RINT"
    CAST_ROUND = "CAST_ROUND"
    CAST_FLOOR = "CAST_FLOOR"
    CAST_CEIL = "CAST_CEIL"
    CAST_TRUNC = "CAST_TRUNC"
    CAST_ODD = "CAST_ODD"
    CAST_NONE = "CAST_NONE"
