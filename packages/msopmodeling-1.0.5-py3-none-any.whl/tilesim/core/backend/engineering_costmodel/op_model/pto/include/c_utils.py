from core.common.entity import DType


def sizeof(dtype: DType):
    return dtype.size


int32_t = DType.INT32
int16_t = DType.INT16
