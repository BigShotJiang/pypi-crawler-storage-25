import logging
from copy import deepcopy
from typing import Optional

from core.backend.engineering_costmodel.core.ub_bank_conflict.instruction_visualizer import BankParam
from core.backend.engineering_costmodel.op_model.pto.cce.config.configs import get_cce_cycle_config
from core.backend.engineering_costmodel.op_model.pto.include.pto_utils import CPTOTile, CPointer
from core.common import DType
from core.frontend.ir.core.ir_logistic import OpIR

logger = logging.getLogger(__name__)
standard_binary_cce = {'vadd', 'vdiv', 'vsub', 'vmul', 'vsel', 'vmin', 'vmax'}
standard_unary_cce = {'vexp'}
scale_cce = {'vmuls', 'vadds', 'vmaxs', 'vmins'}
reduce_cce = {'vcmax', 'vcadd'}
wo_bank_cce = {'movemask1', 'movemask2'}  # also w/o repeat


def call_cce(op_ir: OpIR, pipe_barrier=False) -> (int, Optional[BankParam]):
    if op_ir.level != 'cce':
        raise TypeError(f"op_ir.level={op_ir.level} not cce.")
    cce_fun_name = op_ir.op_code
    if cce_fun_name in standard_binary_cce:
        return adaptor(op_ir, {}, pipe_barrier)
    elif cce_fun_name in (standard_unary_cce | scale_cce | reduce_cce):
        unary_alias = {'src0': 'src', 'src0BlockStride': 'srcBlockStride', 'src0RepeatStride': 'srcRepeatStride'}
        return adaptor(op_ir, unary_alias, pipe_barrier)

    elif cce_fun_name == 'mad':
        return mad(**op_ir.config), None
    elif cce_fun_name.startswith('vconv'):
        op_ir.op_code = 'conv'
        unary_alias = {'src0': 'src', 'src0BlockStride': 'srcBlockStride', 'src0RepeatStride': 'srcRepeatStride'}
        return adaptor(op_ir, unary_alias, pipe_barrier)
    elif cce_fun_name in wo_bank_cce:
        mapped_config_name = op_ir.op_code.upper()

        # movemask 默认dtype
        cce_dtype = DType.FP32
        cce_cycle_config = get_cce_cycle_config(mapped_config_name, cce_dtype)
        if pipe_barrier:
            cce_cycle = cce_cycle_config['head_cycles']
        else:
            cce_cycle = cce_cycle_config['computing_cycles']

        return cce_cycle, None
    else:
        logger.error(f"cce_fun_name={cce_fun_name} not implemented.")
        return 0, None


def mad(c: CPTOTile, a: CPTOTile, b: CPTOTile, m, k, n, unitFlag, kDirectionAlign, cmatrixSource, cmatrixInitVal):
    return m * k * n


def get_bank_param(vec_op_name: str, cce_interval, op_ir_config):
    def get_block_id(ptr: CPointer):
        if ptr:
            return ptr.to_block_id()
        else:
            return None

    return BankParam(
        vec_op_name=vec_op_name,
        vec_op_dtype=op_ir_config['dst'].dtype,
        dst=get_block_id(op_ir_config['dst']),
        src0=get_block_id(op_ir_config['src0']),
        src1=get_block_id(op_ir_config['src1']),
        repeat_times=op_ir_config['repeat'],
        dst_block_stride=op_ir_config['dstBlockStride'],
        src0_block_stride=op_ir_config['src0BlockStride'],
        src1_block_stride=op_ir_config['src1BlockStride'],
        dst_repeat_stride=op_ir_config['dstRepeatStride'],
        src0_repeat_stride=op_ir_config['src0RepeatStride'],
        src1_repeat_stride=op_ir_config['src1RepeatStride'],
        cce_interval=cce_interval,
    )


def get_cycles(config, repeat, pipe_barrier=False):
    return config['head_cycles'] + (repeat - 1) * config['computing_cycles'] \
        if pipe_barrier else config['computing_cycles'] * repeat


def standard_binary(op_ir: OpIR, pipe_barrier) -> (int, BankParam):
    mapped_config_name = op_ir.op_code.upper()
    cce_dtype = op_ir.config["dst"].dtype
    cce_cycle_config = get_cce_cycle_config(mapped_config_name, cce_dtype)
    cycles = get_cycles(cce_cycle_config, op_ir.config['repeat'], pipe_barrier)
    bank_param = get_bank_param(mapped_config_name, cce_interval=cce_cycle_config['interval_cycles'], op_ir_config=op_ir.config)
    return cycles, bank_param


def adaptor(op_ir: OpIR, alias_map, pipe_barrier) -> (int, BankParam):
    param = op_ir.config
    null_pointer = None
    default_value = 1

    def double_get(name, default):
        nonlocal param
        alias = alias_map.get(name, name)
        if alias not in param:
            logger.debug(
                f"[CCE BANK COMPUTE] cce param: without alias=%s, name=%s, fallback to => default_value=%s",
                alias, name, default)
        return param.get(alias, default)

    binary_param = {
        'dst': double_get('dst', null_pointer),
        'src0': double_get('src0', null_pointer),
        'src1': double_get('src1', null_pointer),
        'repeat': double_get('repeat', default_value),
        'dstBlockStride': double_get('dstBlockStride', default_value),
        'src0BlockStride': double_get('src0BlockStride', default_value),
        'src1BlockStride': double_get('src1BlockStride', None),
        'dstRepeatStride': double_get('dstRepeatStride', default_value),
        'src0RepeatStride': double_get('src0RepeatStride', default_value),
        'src1RepeatStride': double_get('src1RepeatStride', None),
    }
    op_ir = deepcopy(op_ir)
    op_ir.config = binary_param
    return standard_binary(op_ir, pipe_barrier)
