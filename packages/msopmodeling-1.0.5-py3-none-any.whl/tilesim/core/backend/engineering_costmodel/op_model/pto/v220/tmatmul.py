from core.backend.engineering_costmodel.op_model.pto.include import std
from core.backend.engineering_costmodel.op_model.pto.include.c_utils import sizeof
from core.backend.engineering_costmodel.op_model.pto.include.pto_utils import SLayout
from core.frontend.ir.core.ir import KernelIR
from core.frontend.ir.core.ir_logistic import OpIR


def TMatmul(TileAcc, TileLeft, TileRight, cmatrix_source, CmatrixInitVal, c_matrix, a_matrix, b_matrix, m, k, n,
            kernel_ir):
    AType = TileLeft.DType
    BType = TileRight.DType
    CType = TileAcc.DType
    c = c_matrix
    a = a_matrix
    b = b_matrix
    k_direction_align = True
    if std.is_same(AType, float).value and std.is_same(CType, float).value:
        if TileLeft.isRowMajor and TileLeft.SFractal == SLayout.ColMajor:
            k_direction_align = True
    unit_flag = 0
    kernel_ir.add_op(OpIR(level='cce', op_code='mad', inputs=[a, b], outputs=[c],
                          config={'c': c, 'a': a, 'b': b, 'm': m, 'k': k, 'n': n, 'unitFlag': unit_flag,
                                  'kDirectionAlign': k_direction_align, 'cmatrixSource': cmatrix_source,
                                  'cmatrixInitVal': CmatrixInitVal}))


def Checkstatic(TileAcc, TileLeft, TileRight, kernel_ir):
    m = TileAcc.Rows
    n = TileAcc.Cols
    k = TileLeft.Cols
    left_size = m * k * sizeof(TileLeft.DType)
    right_size = k * n * sizeof(TileRight.DType)
    acc_size = m * n * sizeof(TileAcc.DType)


def TMATMUL_IMPL(c_matrix, a_matrix, b_matrix):
    TileAcc, TileLeft, TileRight = c_matrix, a_matrix, b_matrix
    kernel_ir = KernelIR('pto_tmatmul')
    Checkstatic(TileAcc, TileLeft, TileRight, kernel_ir)
    m = a_matrix.GetValidRow()
    k = a_matrix.GetValidCol()
    n = b_matrix.GetValidCol()
    TMatmul(TileAcc, TileLeft, TileRight, True, True, c_matrix.data(), a_matrix.data(), b_matrix.data(), m, k, n,
            kernel_ir)
    return kernel_ir


def TMATMUL_ACC_IMPL(c_out_matrix, c_in_matrix, a_matrix, b_matrix):
    TileAcc, TileLeft, TileRight = c_in_matrix, a_matrix, b_matrix
    kernel_ir = KernelIR('pto_tmatmul')
    Checkstatic(TileAcc, TileLeft, TileRight, kernel_ir)
    m = a_matrix.GetValidRow()
    k = a_matrix.GetValidCol()
    n = b_matrix.GetValidCol()
    TMatmul(TileAcc, TileLeft, TileRight, True, True, c_out_matrix.data(), a_matrix.data(), b_matrix.data(), m, k, n,
            kernel_ir)
    return kernel_ir


def TMATMUL_BIAS_IMPL(c_matrix, a_matrix, b_matrix, bias_matrix):
    TileAcc, TileLeft, TileRight, TileBias = c_matrix, a_matrix, b_matrix, bias_matrix
    kernel_ir = KernelIR('pto_tmatmul')
    Checkstatic(TileAcc, TileLeft, TileRight, kernel_ir)
    CType = TileAcc.DType
    BiasType = TileBias.DType
    is_bias_valid = 0
    BiasType = 0
    m = a_matrix.GetValidRow()
    k = a_matrix.GetValidCol()
    n = b_matrix.GetValidCol()
    c = c_matrix.data()
    bias = bias_matrix.data()
    xd = c & 4294967295 | (bias & 4294967295) << 32
    TMatmul(TileAcc, TileLeft, TileRight, True, True, xd, a_matrix.data(), b_matrix.data(), m, k, n, kernel_ir)
    return kernel_ir