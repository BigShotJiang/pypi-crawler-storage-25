import pandas as pd

from core.common.entity import DType
from core.backend.engineering_costmodel.op_model.pto import tadd
from core.backend.engineering_costmodel.op_model.pto.include.pto_utils import CPTOTile


def val_model():
    df = pd.read_csv('warmup_10_tadd.csv')
    corner_cases = []
    avg_pre = 0
    for index, csv_row in df.iterrows():
        true_res = csv_row['vec_cycles']
        mapping = {
            "float": DType.FP32,
            "int32": DType.INT32,
            "int16": DType.FP16,
            "half": DType.FP16
        }

        row, col = csv_row['row'], csv_row['col']
        dt = mapping.get(csv_row['dtype'], '????')
        dst = CPTOTile(
            row=row,
            col=col,
            row_stride=col,
            addr="0x18000",
            dtype=dt,
        )
        src0 = CPTOTile(
            row=row,
            col=col,
            row_stride=col,
            addr="0x0000",
            dtype=dt,
        )
        src1 = CPTOTile(
            row=row,
            col=col,
            row_stride=col,
            addr="0x8000",
            dtype=dt,
        )
        model_cycles = tadd('v220', dst, src0, src1)
        precision = round(1 - abs(model_cycles - true_res) / true_res, 3)
        avg_pre = avg_pre + precision

        if precision < 0.7:
            print(f"row:{row['row']},col:{row['col']},type:{row['dtype']}")
            map_np = {
                "float": 'np.float32',
                "int32": 'np.int32',
                "int16": 'np.int16',
                "half": 'np.float16'
            }
            corner_cases.append((row['row'], row['col'], map_np.get(row['dtype']), round(precision, 3)))

    print(f"avg_pre={avg_pre / len(df)}")
    print(f"corner_cases={corner_cases}")


if __name__ == '__main__':
    val_model()