# Copyright (c) Huawei Technologies Co., Ltd. 2025-2026. All rights reserved.

from core.common.entity import VecOpType, DType
from core.common.log_format import logging

# 创建一个日志记录器
logger = logging.getLogger(__name__)
cce_config = {}


def update_cce_config_cache(vec_no_bank_conflict_intrinsics_dict=None):
    global cce_config
    cce_config = vec_no_bank_conflict_intrinsics_dict.copy()


def get_cce_cycle_config(cce_func_name: str, cce_dtype: DType):
    fallback = {
        'computing_cycles': 1,
        'head_cycles': 14,
        'interval_cycles': 18
    }
    key = (VecOpType.from_str(cce_func_name), cce_dtype)
    if key not in cce_config:
        logger.error(f"cce_func_name={cce_func_name} not in cce_config, fallback={fallback}")
        return fallback
    vec_intrinsics = cce_config[key]

    return {
        'computing_cycles': vec_intrinsics.computing_cycles,
        'head_cycles': vec_intrinsics.head_cycles,
        'interval_cycles': vec_intrinsics.interval_cycles
    }