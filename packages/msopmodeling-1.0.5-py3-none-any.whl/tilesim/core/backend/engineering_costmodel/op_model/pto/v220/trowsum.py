from core.backend.engineering_costmodel.op_model.pto.include.bisheng_utils import PIPE_V
from core.backend.engineering_costmodel.op_model.pto.include.c_utils import sizeof
from core.backend.engineering_costmodel.op_model.pto.include.pto_const import REPEAT_MAX, REPEAT_BYTE, \
    BLOCK_BYTE_SIZE, BLOCK_MAX_PER_REPEAT
from core.backend.engineering_costmodel.op_model.pto.include.pto_utils import __cce_get_tile_ptr, SetContinuousMask
from core.frontend.ir.core.ir import KernelIR
from core.frontend.ir.core.ir_logistic import OpIR


def VcaddByMode(T, cnt_mode_en, cols, dst_repeat_stride, src_repeat_stride, n_elem_per_repeat, dst, src, repeat_times,
                kernel_ir):
    if dst_repeat_stride > 65535:
        i = 0
        while i < repeat_times:
            kernel_ir.add_op(
                OpIR(level='cce', op_code='vcadd', inputs=[src + i * cols], outputs=[dst + i * dst_repeat_stride],
                     config={'dst': dst + i * dst_repeat_stride, 'src': src + i * cols, 'repeat': 1,
                             'srcBlockStride': 0, 'dstRepeatStride': 1, 'srcRepeatStride': 0, 'mode': True}))
            i += 1
    elif cnt_mode_en:
        kernel_ir.add_op(OpIR(level='cce', op_code='set_mask_count', inputs=[], outputs=[], config={}))
        kernel_ir.add_op(OpIR(level='cce', op_code='vmask', inputs=[], outputs=[],
                              config={'cce_args': [0, repeat_times * n_elem_per_repeat]}))
        kernel_ir.add_op(OpIR(level='cce', op_code='vcadd', inputs=[src], outputs=[dst],
                              config={'dst': dst, 'src': src, 'repeat': 0, 'srcBlockStride': dst_repeat_stride,
                                      'dstRepeatStride': 1, 'srcRepeatStride': src_repeat_stride, 'mode': True}))
        kernel_ir.add_op(OpIR(level='cce', op_code='set_mask_norm', inputs=[], outputs=[], config={}))
        kernel_ir.add_op(OpIR(level='cce', op_code='vmask', inputs=[], outputs=[], config={'cce_args': [-1, -1]}))
    else:
        kernel_ir.add_op(OpIR(level='cce', op_code='vcadd', inputs=[src], outputs=[dst],
                              config={'dst': dst, 'src': src, 'repeat': repeat_times,
                                      'srcBlockStride': dst_repeat_stride, 'dstRepeatStride': 1,
                                      'srcRepeatStride': src_repeat_stride, 'mode': True}))


def VaddByMode(T, cnt_mode_en, dst_cols, src0_cols, src1_cols, dst_repeat_stride, src0_repeat_stride,
               src1_repeat_stride, n_elem_per_repeat, dst, src0, src1, repeat_times, kernel_ir):
    if (dst_repeat_stride > REPEAT_MAX or src0_repeat_stride > REPEAT_MAX) or src1_repeat_stride > REPEAT_MAX:
        i = 0
        while i < repeat_times:
            kernel_ir.add_op(OpIR(level='cce', op_code='vadd', inputs=[src0 + i * src0_cols, src1 + i * src1_cols],
                                  outputs=[dst + i * dst_cols],
                                  config={'dst': dst + i * dst_cols, 'src0': src0 + i * src0_cols,
                                          'src1': src1 + i * src1_cols, 'repeat': 1, 'dstBlockStride': 1,
                                          'src0BlockStride': 1, 'src1BlockStride': 1, 'dstRepeatStride': 0,
                                          'src0RepeatStride': 0, 'src1RepeatStride': 0}))
            i += 1
    elif cnt_mode_en:
        kernel_ir.add_op(OpIR(level='cce', op_code='set_mask_count', inputs=[], outputs=[], config={}))
        kernel_ir.add_op(OpIR(level='cce', op_code='vmask', inputs=[], outputs=[],
                              config={'cce_args': [0, repeat_times * n_elem_per_repeat]}))
        kernel_ir.add_op(OpIR(level='cce', op_code='vadd', inputs=[src0, src1], outputs=[dst],
                              config={'dst': dst, 'src0': src0, 'src1': src1, 'repeat': 0, 'dstBlockStride': 1,
                                      'src0BlockStride': 1, 'src1BlockStride': 1, 'dstRepeatStride': dst_repeat_stride,
                                      'src0RepeatStride': src0_repeat_stride, 'src1RepeatStride': src1_repeat_stride}))
        kernel_ir.add_op(OpIR(level='cce', op_code='set_mask_norm', inputs=[], outputs=[], config={}))
        kernel_ir.add_op(OpIR(level='cce', op_code='vmask', inputs=[], outputs=[], config={'cce_args': [-1, -1]}))
    else:
        kernel_ir.add_op(OpIR(level='cce', op_code='vadd', inputs=[src0, src1], outputs=[dst],
                              config={'dst': dst, 'src0': src0, 'src1': src1, 'repeat': repeat_times,
                                      'dstBlockStride': 1, 'src0BlockStride': 1, 'src1BlockStride': 1,
                                      'dstRepeatStride': dst_repeat_stride, 'src0RepeatStride': src0_repeat_stride,
                                      'src1RepeatStride': src1_repeat_stride}))


def TRowSum(T, TileDataOut, TileDataIn, TileDataTmp, n_elem_per_repeat, dst_repeat_stride, src_repeat_stride,
            tmp_repeat_stride, dst_data, src_data, tmp_data, valid_col, valid_row, kernel_ir):
    dst = __cce_get_tile_ptr(dst_data)
    src = __cce_get_tile_ptr(src_data)
    tmp = __cce_get_tile_ptr(tmp_data)
    src_repeat_per_row = valid_col // n_elem_per_repeat
    remain = valid_col % n_elem_per_repeat
    row_repeat_times = valid_row // REPEAT_MAX
    repeat_times = 0
    dst_p = dst
    src_p = src
    tmp_p = tmp
    if valid_col == n_elem_per_repeat:
        VcaddByMode(T, True, TileDataIn.Cols, dst_repeat_stride, src_repeat_stride, n_elem_per_repeat, dst, src,
                    valid_row, kernel_ir)
        kernel_ir.add_op(
            OpIR(level='cce', op_code='pipe_barrier', inputs=[], outputs=[], config={'cce_args': [PIPE_V]}))
        return
    if valid_col < n_elem_per_repeat:
        SetContinuousMask(remain)
        repeat_times = valid_row % REPEAT_MAX if row_repeat_times == 0 else REPEAT_MAX
        kernel_ir.add_op(
            OpIR(level='cce', op_code='pipe_barrier', inputs=[], outputs=[], config={'cce_args': [PIPE_V]}))
        VcaddByMode(T, True, TileDataIn.Cols, dst_repeat_stride, src_repeat_stride, n_elem_per_repeat, dst_p, src_p,
                    repeat_times, kernel_ir)
        row_repeat_times -= 1
        dst_p += repeat_times * TileDataOut.Cols
        src_p += repeat_times * TileDataIn.Cols
        tmp_p += repeat_times * TileDataTmp.Cols
        while row_repeat_times >= 0:
            repeat_times = valid_row % REPEAT_MAX if row_repeat_times == 0 else REPEAT_MAX
            kernel_ir.add_op(
                OpIR(level='cce', op_code='pipe_barrier', inputs=[], outputs=[], config={'cce_args': [PIPE_V]}))
            VcaddByMode(T, True, TileDataIn.Cols, dst_repeat_stride, src_repeat_stride, n_elem_per_repeat, dst_p, src_p,
                        repeat_times, kernel_ir)
            row_repeat_times -= 1
            dst_p += repeat_times * TileDataOut.Cols
            src_p += repeat_times * TileDataIn.Cols
            tmp_p += repeat_times * TileDataTmp.Cols
        kernel_ir.add_op(OpIR(level='cce', op_code='vmask', inputs=[], outputs=[], config={'cce_args': [-1, -1]}))
        return
    if valid_col < 2 * n_elem_per_repeat:
        if src_repeat_stride < BLOCK_MAX_PER_REPEAT or tmp_repeat_stride < BLOCK_MAX_PER_REPEAT:
            return
        kernel_ir.add_op(OpIR(level='cce', op_code='copy_ubuf_to_ubuf', inputs=[src], outputs=[tmp],
                              config={'dst': tmp, 'src': src, 'sid': 0, 'nBurst': valid_row,
                                      'lenBurst': BLOCK_MAX_PER_REPEAT,
                                      'srcGap': src_repeat_stride - BLOCK_MAX_PER_REPEAT,
                                      'dstGap': tmp_repeat_stride - BLOCK_MAX_PER_REPEAT}))
        kernel_ir.add_op(
            OpIR(level='cce', op_code='pipe_barrier', inputs=[], outputs=[], config={'cce_args': [PIPE_V]}))
    i = 0
    i = 0
    while i < src_repeat_per_row // 2:
        VaddByMode(T, True, TileDataTmp.Cols, TileDataIn.Cols, TileDataIn.Cols, tmp_repeat_stride, src_repeat_stride,
                   src_repeat_stride, n_elem_per_repeat, tmp + i * n_elem_per_repeat, src + i * 2 * n_elem_per_repeat,
                   src + (i * 2 + 1) * n_elem_per_repeat, valid_row, kernel_ir)
        kernel_ir.add_op(
            OpIR(level='cce', op_code='pipe_barrier', inputs=[], outputs=[], config={'cce_args': [PIPE_V]}))
        i += 1
    if src_repeat_per_row != 1 and src_repeat_per_row % 2 == 1:
        VaddByMode(T, True, TileDataTmp.Cols, TileDataTmp.Cols, TileDataIn.Cols, tmp_repeat_stride, tmp_repeat_stride,
                   src_repeat_stride, n_elem_per_repeat, tmp, tmp, src + (src_repeat_per_row - 1) * n_elem_per_repeat,
                   valid_row, kernel_ir)
        kernel_ir.add_op(
            OpIR(level='cce', op_code='pipe_barrier', inputs=[], outputs=[], config={'cce_args': [PIPE_V]}))
    cur_len = 0
    loop_remain = 0
    repeat_offset = 0
    repeat_times = valid_row % REPEAT_MAX if row_repeat_times == 0 else REPEAT_MAX
    cur_len = src_repeat_per_row
    if remain > 0:
        repeat_offset = 0 if cur_len == 1 else cur_len // 2 - 1
        SetContinuousMask(remain)
        VaddByMode(T, True, TileDataTmp.Cols, TileDataTmp.Cols, TileDataIn.Cols, tmp_repeat_stride, tmp_repeat_stride,
                   src_repeat_stride, n_elem_per_repeat, tmp_p + repeat_offset * n_elem_per_repeat,
                   tmp_p + repeat_offset * n_elem_per_repeat, src_p + cur_len * n_elem_per_repeat, repeat_times,
                   kernel_ir)
        kernel_ir.add_op(
            OpIR(level='cce', op_code='pipe_barrier', inputs=[], outputs=[], config={'cce_args': [PIPE_V]}))
        kernel_ir.add_op(OpIR(level='cce', op_code='vmask', inputs=[], outputs=[], config={'cce_args': [-1, -1]}))
    cur_len = cur_len // 2
    while cur_len > 1:
        i = 0
        while i < cur_len // 2:
            VaddByMode(T, True, TileDataTmp.Cols, TileDataTmp.Cols, TileDataTmp.Cols, tmp_repeat_stride,
                       tmp_repeat_stride, tmp_repeat_stride, n_elem_per_repeat, tmp_p + i * n_elem_per_repeat,
                       tmp_p + i * 2 * n_elem_per_repeat, tmp_p + (i * 2 + 1) * n_elem_per_repeat, repeat_times,
                       kernel_ir)
            kernel_ir.add_op(
                OpIR(level='cce', op_code='pipe_barrier', inputs=[], outputs=[], config={'cce_args': [PIPE_V]}))
            i += 1
        loop_remain = cur_len % 2
        cur_len = cur_len // 2
        if loop_remain > 0:
            VaddByMode(T, True, TileDataTmp.Cols, TileDataTmp.Cols, TileDataTmp.Cols, tmp_repeat_stride,
                       tmp_repeat_stride, tmp_repeat_stride, n_elem_per_repeat,
                       tmp_p + (cur_len - 1) * n_elem_per_repeat, tmp_p + (cur_len - 1) * n_elem_per_repeat,
                       tmp_p + cur_len * 2 * n_elem_per_repeat, repeat_times, kernel_ir)
            kernel_ir.add_op(
                OpIR(level='cce', op_code='pipe_barrier', inputs=[], outputs=[], config={'cce_args': [PIPE_V]}))
    VcaddByMode(T, True, TileDataTmp.Cols, dst_repeat_stride, tmp_repeat_stride, n_elem_per_repeat, dst_p, tmp_p,
                repeat_times, kernel_ir)
    kernel_ir.add_op(OpIR(level='cce', op_code='pipe_barrier', inputs=[], outputs=[], config={'cce_args': [PIPE_V]}))
    row_repeat_times -= 1
    dst_p += repeat_times * TileDataOut.Cols
    src_p += repeat_times * TileDataIn.Cols
    tmp_p += repeat_times * TileDataTmp.Cols
    while row_repeat_times > 0:
        repeat_times = valid_row % REPEAT_MAX if row_repeat_times == 0 else REPEAT_MAX
        cur_len = src_repeat_per_row
        if remain > 0:
            repeat_offset = 0 if cur_len == 1 else cur_len // 2 - 1
            SetContinuousMask(remain)
            VaddByMode(T, True, TileDataTmp.Cols, TileDataTmp.Cols, TileDataIn.Cols, tmp_repeat_stride,
                       tmp_repeat_stride, src_repeat_stride, n_elem_per_repeat,
                       tmp_p + repeat_offset * n_elem_per_repeat, tmp_p + repeat_offset * n_elem_per_repeat,
                       src_p + cur_len * n_elem_per_repeat, repeat_times, kernel_ir)
            kernel_ir.add_op(
                OpIR(level='cce', op_code='pipe_barrier', inputs=[], outputs=[], config={'cce_args': [PIPE_V]}))
            kernel_ir.add_op(OpIR(level='cce', op_code='vmask', inputs=[], outputs=[], config={'cce_args': [-1, -1]}))
        cur_len = cur_len // 2
        while cur_len > 1:
            i = 0
            while i < cur_len // 2:
                VaddByMode(T, True, TileDataTmp.Cols, TileDataTmp.Cols, TileDataTmp.Cols, tmp_repeat_stride,
                           tmp_repeat_stride, tmp_repeat_stride, n_elem_per_repeat, tmp_p + i * n_elem_per_repeat,
                           tmp_p + i * 2 * n_elem_per_repeat, tmp_p + (i * 2 + 1) * n_elem_per_repeat, repeat_times,
                           kernel_ir)
                kernel_ir.add_op(
                    OpIR(level='cce', op_code='pipe_barrier', inputs=[], outputs=[], config={'cce_args': [PIPE_V]}))
                i += 1
            loop_remain = cur_len % 2
            cur_len = cur_len // 2
            if loop_remain > 0:
                VaddByMode(T, True, TileDataTmp.Cols, TileDataTmp.Cols, TileDataTmp.Cols, tmp_repeat_stride,
                           tmp_repeat_stride, tmp_repeat_stride, n_elem_per_repeat,
                           tmp_p + (cur_len - 1) * n_elem_per_repeat, tmp_p + (cur_len - 1) * n_elem_per_repeat,
                           tmp_p + cur_len * 2 * n_elem_per_repeat, repeat_times, kernel_ir)
                kernel_ir.add_op(
                    OpIR(level='cce', op_code='pipe_barrier', inputs=[], outputs=[], config={'cce_args': [PIPE_V]}))
        VcaddByMode(T, True, TileDataTmp.Cols, dst_repeat_stride, tmp_repeat_stride, n_elem_per_repeat, dst_p, tmp_p,
                    repeat_times, kernel_ir)
        kernel_ir.add_op(
            OpIR(level='cce', op_code='pipe_barrier', inputs=[], outputs=[], config={'cce_args': [PIPE_V]}))
        row_repeat_times -= 1
        dst_p += repeat_times * TileDataOut.Cols
        src_p += repeat_times * TileDataIn.Cols
        tmp_p += repeat_times * TileDataTmp.Cols


def TROWSUM_IMPL(dst, src, tmp):
    TileDataOut, TileDataIn, TileDataTmp = dst, src, tmp
    kernel_ir = KernelIR('pto_trowsum')
    T = TileDataIn.DType
    is_target_type = 0
    half = 0
    valid_col = src.GetValidCol()
    valid_row = src.GetValidRow()
    if valid_col == 0 or valid_row == 0:
        return
    n_elem_per_block = BLOCK_BYTE_SIZE // sizeof(T)
    n_elem_per_repeat = REPEAT_BYTE // sizeof(T)
    dst_repeat_stride = TileDataOut.Cols
    src_repeat_stride = TileDataIn.Cols // n_elem_per_block
    tmp_repeat_stride = TileDataTmp.Cols // n_elem_per_block
    TRowSum(T, TileDataOut, TileDataIn, TileDataTmp, n_elem_per_repeat, dst_repeat_stride, src_repeat_stride,
            tmp_repeat_stride, dst.data(), src.data(), tmp.data(), valid_col, valid_row, kernel_ir)
    return kernel_ir