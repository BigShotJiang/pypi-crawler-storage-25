from core.backend.engineering_costmodel.op_model.pto.include.c_utils import sizeof
from core.backend.engineering_costmodel.op_model.pto.include.pto_const import REPEAT_MAX, REPEAT_STRIDE_MAX, \
    REPEAT_BYTE, BLOCK_BYTE_SIZE
from core.backend.engineering_costmodel.op_model.pto.include.pto_utils import __cce_get_tile_ptr, \
    SetContinuousMask
from core.frontend.ir.core.ir import KernelIR
from core.frontend.ir.core.ir_logistic import OpIR


def TMin(TileData, elements_per_repeat, block_size_elem, stride, dst, src0, src1, num_repeat_per_line,
         num_remain_per_line, valid_row, kernel_ir):
    dst_ptr = __cce_get_tile_ptr(dst)
    src0_ptr = __cce_get_tile_ptr(src0)
    src1_ptr = __cce_get_tile_ptr(src1)
    if num_repeat_per_line > 0:
        num_loop = num_repeat_per_line // REPEAT_MAX
        remain_after_loop = num_repeat_per_line % REPEAT_MAX
        i = 0
        while i < valid_row:
            if num_loop:
                j = 0
                while j < num_loop:
                    kernel_ir.add_op(OpIR(level='cce', op_code='vmin',
                                          inputs=[src0_ptr + i * stride + j * elements_per_repeat * REPEAT_MAX,
                                                  src1_ptr + i * stride + j * elements_per_repeat * REPEAT_MAX],
                                          outputs=[dst_ptr + i * stride + j * elements_per_repeat * REPEAT_MAX],
                                          config={'dst': dst_ptr + i * stride + j * elements_per_repeat * REPEAT_MAX,
                                                  'src0': src0_ptr + i * stride + j * elements_per_repeat * REPEAT_MAX,
                                                  'src1': src1_ptr + i * stride + j * elements_per_repeat * REPEAT_MAX,
                                                  'repeat': REPEAT_MAX, 'dstBlockStride': 1, 'src0BlockStride': 1,
                                                  'src1BlockStride': 1, 'dstRepeatStride': 8, 'src0RepeatStride': 8,
                                                  'src1RepeatStride': 8}))
                    j += 1
            if remain_after_loop:
                kernel_ir.add_op(OpIR(level='cce', op_code='vmin',
                                      inputs=[src0_ptr + i * stride + num_loop * elements_per_repeat * REPEAT_MAX,
                                              src1_ptr + i * stride + num_loop * elements_per_repeat * REPEAT_MAX],
                                      outputs=[dst_ptr + i * stride + num_loop * elements_per_repeat * REPEAT_MAX],
                                      config={'dst': dst_ptr + i * stride + num_loop * elements_per_repeat * REPEAT_MAX,
                                              'src0': src0_ptr + i * stride + num_loop * elements_per_repeat * REPEAT_MAX,
                                              'src1': src1_ptr + i * stride + num_loop * elements_per_repeat * REPEAT_MAX,
                                              'repeat': remain_after_loop, 'dstBlockStride': 1, 'src0BlockStride': 1,
                                              'src1BlockStride': 1, 'dstRepeatStride': 8, 'src0RepeatStride': 8,
                                              'src1RepeatStride': 8}))
            i += 1
    dst_ptr += num_repeat_per_line * elements_per_repeat
    src0_ptr += num_repeat_per_line * elements_per_repeat
    src1_ptr += num_repeat_per_line * elements_per_repeat
    if num_remain_per_line:
        num_loop = valid_row // REPEAT_MAX
        remain_after_loop = valid_row % REPEAT_MAX
        stride_over_flag = stride // block_size_elem > REPEAT_STRIDE_MAX
        SetContinuousMask(num_remain_per_line)
        if num_loop:
            i = 0
            while i < num_loop:
                if stride_over_flag:
                    j = 0
                    while j < REPEAT_MAX:
                        kernel_ir.add_op(OpIR(level='cce', op_code='vmin',
                                              inputs=[src0_ptr + i * REPEAT_MAX * stride + j * stride,
                                                      src1_ptr + i * REPEAT_MAX * stride + j * stride],
                                              outputs=[dst_ptr + i * REPEAT_MAX * stride + j * stride],
                                              config={'dst': dst_ptr + i * REPEAT_MAX * stride + j * stride,
                                                      'src0': src0_ptr + i * REPEAT_MAX * stride + j * stride,
                                                      'src1': src1_ptr + i * REPEAT_MAX * stride + j * stride,
                                                      'repeat': 1, 'dstBlockStride': 1, 'src0BlockStride': 1,
                                                      'src1BlockStride': 1, 'dstRepeatStride': 1, 'src0RepeatStride': 1,
                                                      'src1RepeatStride': 1}))
                        j += 1
                else:
                    kernel_ir.add_op(OpIR(level='cce', op_code='vmin', inputs=[src0_ptr + i * REPEAT_MAX * stride,
                                                                               src1_ptr + i * REPEAT_MAX * stride],
                                          outputs=[dst_ptr + i * REPEAT_MAX * stride],
                                          config={'dst': dst_ptr + i * REPEAT_MAX * stride,
                                                  'src0': src0_ptr + i * REPEAT_MAX * stride,
                                                  'src1': src1_ptr + i * REPEAT_MAX * stride, 'repeat': REPEAT_MAX,
                                                  'dstBlockStride': 1, 'src0BlockStride': 1, 'src1BlockStride': 1,
                                                  'dstRepeatStride': stride // block_size_elem,
                                                  'src0RepeatStride': stride // block_size_elem,
                                                  'src1RepeatStride': stride // block_size_elem}))
                i += 1
        if remain_after_loop:
            if stride_over_flag:
                j = 0
                while j < remain_after_loop:
                    kernel_ir.add_op(OpIR(level='cce', op_code='vmin',
                                          inputs=[src0_ptr + num_loop * REPEAT_MAX * stride + j * stride,
                                                  src1_ptr + num_loop * REPEAT_MAX * stride + j * stride],
                                          outputs=[dst_ptr + num_loop * REPEAT_MAX * stride + j * stride],
                                          config={'dst': dst_ptr + num_loop * REPEAT_MAX * stride + j * stride,
                                                  'src0': src0_ptr + num_loop * REPEAT_MAX * stride + j * stride,
                                                  'src1': src1_ptr + num_loop * REPEAT_MAX * stride + j * stride,
                                                  'repeat': 1, 'dstBlockStride': 1, 'src0BlockStride': 1,
                                                  'src1BlockStride': 1, 'dstRepeatStride': 1, 'src0RepeatStride': 1,
                                                  'src1RepeatStride': 1}))
                    j += 1
            else:
                kernel_ir.add_op(OpIR(level='cce', op_code='vmin', inputs=[src0_ptr + num_loop * REPEAT_MAX * stride,
                                                                           src1_ptr + num_loop * REPEAT_MAX * stride],
                                      outputs=[dst_ptr + num_loop * REPEAT_MAX * stride],
                                      config={'dst': dst_ptr + num_loop * REPEAT_MAX * stride,
                                              'src0': src0_ptr + num_loop * REPEAT_MAX * stride,
                                              'src1': src1_ptr + num_loop * REPEAT_MAX * stride,
                                              'repeat': remain_after_loop, 'dstBlockStride': 1, 'src0BlockStride': 1,
                                              'src1BlockStride': 1, 'dstRepeatStride': stride // block_size_elem,
                                              'src0RepeatStride': stride // block_size_elem,
                                              'src1RepeatStride': stride // block_size_elem}))
        kernel_ir.add_op(OpIR(level='cce', op_code='vmask', inputs=[], outputs=[], config={'cce_args': [-1, -1]}))


def TMIN_IMPL(dst, src0, src1):
    TileData = dst
    kernel_ir = KernelIR('pto_tmin')
    block_size_elem = BLOCK_BYTE_SIZE // sizeof(TileData.DType)
    elements_per_repeat = REPEAT_BYTE // sizeof(TileData.DType)
    num_repeat_per_line = dst.GetValidCol() // elements_per_repeat
    num_remain_per_line = dst.GetValidCol() % elements_per_repeat
    stride = TileData.RowStride
    valid_row = dst.GetValidRow()
    TMin(TileData, elements_per_repeat, block_size_elem, stride, dst.data(), src0.data(), src1.data(),
         num_repeat_per_line, num_remain_per_line, valid_row, kernel_ir)
    return kernel_ir