from core.backend.engineering_costmodel.op_model.pto.include.bisheng_utils import PIPE_V
from core.backend.engineering_costmodel.op_model.pto.include.pto_utils import __cce_get_tile_ptr, CPTOTile
from core.frontend.ir.core.ir import KernelIR
from core.frontend.ir.core.ir_logistic import OpIR


def TUnary(TileData, Func, dst, src, valid_col, current_func, kernel_ir):
    TileData = dst
    dst_ptr = __cce_get_tile_ptr(dst)
    src_ptr = __cce_get_tile_ptr(src)
    TShape0 = TileData.Rows
    TShape1 = TileData.Cols
    kernel_ir.add_op(OpIR(level='cce', op_code='set_mask_count', inputs=[], outputs=[], config={}))
    kernel_ir.add_op(OpIR(level='cce', op_code='vmask', inputs=[], outputs=[], config={'cce_args': [0, valid_col]}))
    i = 0
    while i < TShape0:
        current_func(dst_ptr + i * TShape1, src_ptr + i * TShape1, 1, 1, 1, 8, 8, kernel_ir)
        i += 1
    kernel_ir.add_op(OpIR(level='cce', op_code='pipe_barrier', inputs=[], outputs=[], config={'cce_args': [PIPE_V]}))
    kernel_ir.add_op(OpIR(level='cce', op_code='set_mask_norm', inputs=[], outputs=[], config={}))
    kernel_ir.add_op(OpIR(level='cce', op_code='vmask', inputs=[], outputs=[], config={'cce_args': [-1, -1]}))


def _vrsqrt(DataType, dst, src, repeat, dst_block_stride, src_block_stride, dst_repeat_stride, src_repeat_stride,
            kernel_ir):
    kernel_ir.add_op(OpIR(level='cce', op_code='vrsqrt', inputs=[src, repeat], outputs=[dst],
                          config={'dst': dst, 'src': src, 'repeat': repeat, 'dstBlockStride': dst_block_stride,
                                  'srcBlockStride': src_block_stride, 'dstRepeatStride': dst_repeat_stride,
                                  'srcRepeatStride': src_repeat_stride}))


def TRsqrtCustom(TileData, dst, src, valid_col, kernel_ir):
    dst_ptr = __cce_get_tile_ptr(dst)
    src_ptr = __cce_get_tile_ptr(src)
    TShape0 = TileData.Rows
    TShape1 = TileData.Cols
    kernel_ir.add_op(OpIR(level='cce', op_code='set_mask_count', inputs=[], outputs=[], config={}))
    kernel_ir.add_op(OpIR(level='cce', op_code='vmask', inputs=[], outputs=[], config={'cce_args': [0, valid_col]}))
    i = 0
    while i < TShape0:
        kernel_ir.add_op(
            OpIR(level='cce', op_code='vsqrt', inputs=[src_ptr + i * TShape1, 1], outputs=[src_ptr + i * TShape1],
                 config={'dst': src_ptr + i * TShape1, 'src': src_ptr + i * TShape1, 'repeat': 1, 'dstBlockStride': 1,
                         'srcBlockStride': 1, 'dstRepeatStride': 8, 'srcRepeatStride': 8}))
        i += 1
    kernel_ir.add_op(OpIR(level='cce', op_code='pipe_barrier', inputs=[], outputs=[], config={'cce_args': [PIPE_V]}))
    kernel_ir.add_op(OpIR(level='cce', op_code='vmask', inputs=[], outputs=[], config={'cce_args': [0, valid_col]}))
    i = 0
    while i < TShape0:
        kernel_ir.add_op(
            OpIR(level='cce', op_code='vector_dup', inputs=['_unparse_expr_failed:(typenameTileData::DType)(1.0)', 1],
                 outputs=[dst_ptr + i * TShape1],
                 config={'dst': dst_ptr + i * TShape1, 'src': '_unparse_expr_failed:(typenameTileData::DType)(1.0)',
                         'repeat': 1, 'dstBlockStride': 1, 'srcBlockStride': 1, 'dstRepeatStride': 8,
                         'srcRepeatStride': 8}))
        i += 1
    kernel_ir.add_op(OpIR(level='cce', op_code='pipe_barrier', inputs=[], outputs=[], config={'cce_args': [PIPE_V]}))
    kernel_ir.add_op(OpIR(level='cce', op_code='vmask', inputs=[], outputs=[], config={'cce_args': [0, valid_col]}))
    i = 0
    while i < TShape0:
        kernel_ir.add_op(OpIR(level='cce', op_code='vdiv', inputs=[dst_ptr + i * TShape1, src_ptr + i * TShape1],
                              outputs=[dst_ptr + i * TShape1],
                              config={'dst': dst_ptr + i * TShape1, 'src0': dst_ptr + i * TShape1,
                                      'src1': src_ptr + i * TShape1, 'repeat': 1, 'dstBlockStride': 1,
                                      'src0BlockStride': 1, 'src1BlockStride': 1, 'dstRepeatStride': 8,
                                      'src0RepeatStride': 8, 'src1RepeatStride': 8}))
        i += 1
    kernel_ir.add_op(OpIR(level='cce', op_code='pipe_barrier', inputs=[], outputs=[], config={'cce_args': [PIPE_V]}))
    kernel_ir.add_op(OpIR(level='cce', op_code='set_mask_norm', inputs=[], outputs=[], config={}))
    kernel_ir.add_op(OpIR(level='cce', op_code='vmask', inputs=[], outputs=[], config={'cce_args': [-1, -1]}))


def TRSQRT_IMPL(dst, src):
    TileData = dst
    kernel_ir = KernelIR('pto_tunaryop')
    valid_col = dst.GetValidCol()
    TRsqrtCustom(TileData, dst.data(), src.data(), valid_col, kernel_ir)
    return kernel_ir


def _vsqrt(DataType, dst, src, repeat, dst_block_stride, src_block_stride, dst_repeat_stride, src_repeat_stride,
           kernel_ir):
    kernel_ir.add_op(OpIR(level='cce', op_code='vsqrt', inputs=[src, repeat], outputs=[dst],
                          config={'dst': dst, 'src': src, 'repeat': repeat, 'dstBlockStride': dst_block_stride,
                                  'srcBlockStride': src_block_stride, 'dstRepeatStride': dst_repeat_stride,
                                  'srcRepeatStride': src_repeat_stride}))


def TSQRT_IMPL(dst: CPTOTile, src: CPTOTile):
    TileData = dst
    kernel_ir = KernelIR('pto_tunaryop')
    valid_col = dst.GetValidCol()
    func_ptr = _vsqrt
    TUnary(TileData, func_ptr, dst.data(), src.data(), valid_col, func_ptr, kernel_ir)
    return kernel_ir


def _vexp(dst, src, repeat, dst_block_stride, src_block_stride, dst_repeat_stride, src_repeat_stride, kernel_ir):
    DataType = dst
    kernel_ir.add_op(OpIR(level='cce', op_code='vexp', inputs=[src, repeat], outputs=[dst],
                          config={'dst': dst, 'src': src, 'repeat': repeat, 'dstBlockStride': dst_block_stride,
                                  'srcBlockStride': src_block_stride, 'dstRepeatStride': dst_repeat_stride,
                                  'srcRepeatStride': src_repeat_stride}))


def TEXP_IMPL(dst: CPTOTile, src: CPTOTile):
    TileData = dst
    kernel_ir = KernelIR('pto_tunaryop')
    valid_col = dst.GetValidCol()
    func_ptr = _vexp
    TUnary(TileData, func_ptr, dst.data(), src.data(), valid_col, func_ptr, kernel_ir)
    return kernel_ir