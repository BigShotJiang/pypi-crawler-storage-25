# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

import math

from core.backend.engineering_costmodel.core.aicore_costmodel import AICoreCostModel
from core.common.entity import (
    DType,
    CoreType,
    VecOpType,
    ResultKey,
    Section,
)
from core.backend.engineering_costmodel.core.pipeline.inter_core_pipeline import InterCorePipeline
from core.backend.engineering_costmodel.core.tiling_and_core_split.catlass_tiling import CatlassTiling
from core.backend.engineering_costmodel.core.tiling_and_core_split.tiling_strategy_register import TilingParam
from core.backend.engineering_costmodel.core.vector_op import VectorBasicOp, FusedVectorOp
from core.backend.engineering_costmodel.op_model.basic_operator import BasicOperatorModel


class FlashAttentionV2Forward(BasicOperatorModel):

    def __init__(self, input_precision: DType, output_precision: DType, **kwargs):
        super().__init__(
            "FlashAttentionV2Forward", CoreType.MIX, input_precision, output_precision
        )
        self.section_list = None

        if input_precision == DType.FP8:
            self.input_precision_aiv = DType.FP16
            self.output_precision_aiv = DType.FP16
        else:
            self.input_precision_aiv = DType.FP32
            self.output_precision_aiv = DType.FP32

        self.softmax_stage = self._create_softmax_stages()
        self.output_stage = self._create_output_stage()

    def _create_softmax_stages(self):
        """创建softmax计算阶段"""
        comb1 = self._create_softmax_comb1()
        comb2 = self._create_softmax_comb2()
        
        softmax_op_1 = FusedVectorOp(
            basic_op_list=comb1,
            intput_precision=self.input_precision_aiv,
            output_precision=self.output_precision_aiv,
        )
        softmax_op_2 = FusedVectorOp(
            basic_op_list=comb2,
            intput_precision=self.input_precision_aiv,
            output_precision=self.output_precision_aiv,
        )

        return [softmax_op_1, softmax_op_2]

    def _create_softmax_comb1(self):
        """创建softmax组合1"""
        return [
            VectorBasicOp(VecOpType.VADD, 0, pipe_barrier=False),
            VectorBasicOp(VecOpType.VMUL, 1, pre_id=0),
            VectorBasicOp(VecOpType.VSEL, 2, pre_id=1),
            VectorBasicOp(VecOpType.VCGMAX, 3, io_ratio=8, pre_id=2),
            VectorBasicOp(VecOpType.BRCB, 4, pre_id=3, io_ratio=1 / 8),
            VectorBasicOp(VecOpType.VSUB, 5, pre_id=4),
            VectorBasicOp(VecOpType.VEXP, 6, pre_id=5),
            VectorBasicOp(VecOpType.VCGADD, 7, pre_id=6, io_ratio=8),
            VectorBasicOp(VecOpType.BRCB, 8, pre_id=7, io_ratio=1 / 8),
        ]

    def _create_softmax_comb2(self):
        """创建softmax组合2"""
        return [
            VectorBasicOp(VecOpType.VADD, 0, pipe_barrier=False),
            VectorBasicOp(VecOpType.VMUL, 1, pre_id=0),
            VectorBasicOp(VecOpType.VSEL, 2, pre_id=1),
            VectorBasicOp(VecOpType.VCGMAX, 3, io_ratio=8, pipe_barrier=False),
            VectorBasicOp(VecOpType.VCGMAX, 4, io_ratio=8, pre_id=3),
            VectorBasicOp(VecOpType.VMAX, 5, pre_id=4),
            VectorBasicOp(VecOpType.VCGMAX, 6, io_ratio=8, pre_id=2),
            VectorBasicOp(VecOpType.BRCB, 7, io_ratio=1 / 8, pre_id=6),
            VectorBasicOp(VecOpType.VMAX, 8, pre_id=7),
            VectorBasicOp(VecOpType.VSUB, 9, pre_id=8),
            VectorBasicOp(VecOpType.VEXP, 10, pre_id=9),
            VectorBasicOp(VecOpType.VMUL, 11, pre_id=10),
            VectorBasicOp(VecOpType.VADD, 12, pre_id=11),
            VectorBasicOp(VecOpType.VCGADD, 13, io_ratio=8, pipe_barrier=False),
            VectorBasicOp(VecOpType.VCGADD, 14, io_ratio=8, pre_id=13),
            VectorBasicOp(VecOpType.VADD, 15, pre_id=14),
            VectorBasicOp(VecOpType.VCGADD, 16, io_ratio=8, pre_id=15),
            VectorBasicOp(VecOpType.BRCB, 17, pre_id=16, io_ratio=1 / 8),
        ]

    def _create_output_stage(self):
        """创建输出阶段"""
        comb3 = [
            VectorBasicOp(VecOpType.VADD, 0, pipe_barrier=False),
            VectorBasicOp(VecOpType.VMUL, 1, pipe_barrier=False),
            VectorBasicOp(VecOpType.VDIV, 2, pre_id=0),
        ]
        return FusedVectorOp(
            comb3, self.input_precision_aiv, self.output_precision_aiv
        )

    def _create_section_qk(self, m, k, n, tiling_param):
        """创建QK计算section"""
        return Section(
            bias=0,
            core_type=CoreType.AIC,
            m=m,
            k=k,
            n=n,
            tiling_param=tiling_param[0],
            input_precision=self.input_precision,
            output_precision=self.output_precision,
        )

    def _create_section_softmax_1(self, m, n, tiling_param):
        """创建softmax1计算section"""
        sec_softmax_1 = Section(
            bias=1,
            core_type=CoreType.AIV,
            m=m,
            k=0,
            n=n,
            tiling_param=tiling_param[1],
            input_precision=self.input_precision_aiv,
            output_precision=self.output_precision_aiv,
            input_cnt=1,
            output_cnt=1,
        )
        sec_softmax_1.input_dependency = {0: 0}
        return sec_softmax_1

    def _create_section_pv(self, m, k, n, tiling_param):
        """创建PV计算section"""
        sec_pv = Section(
            bias=2,
            core_type=CoreType.AIC,
            m=m,
            k=n,
            n=k,
            tiling_param=tiling_param[2],
            input_precision=self.input_precision,
            output_precision=self.output_precision,
        )
        sec_pv.input_dependency = {0: 1}
        return sec_pv

    def _create_section_softmax_2(self, m, k, n, tiling_param):
        """创建softmax2计算section"""
        sec_softmax_2 = Section(
            bias=3,
            core_type=CoreType.AIV,
            m=m,
            k=0,
            n=k,
            tiling_param=tiling_param[3],
            input_precision=self.input_precision_aiv,
            output_precision=self.output_precision_aiv,
            input_cnt=1,
            output_cnt=1,
        )
        sec_softmax_2.input_dependency = {0: 2}
        return sec_softmax_2

    def _calculate_tile_nums(self, section):
        """计算section的tile数量"""
        section.tile_nums = (
            section.m * section.n / (section.tiling_param.m1 * section.tiling_param.n1)
        )
        section.tile_nums_per_core = section.tile_nums / (
            section.tiling_param.w * section.tiling_param.h
        )

    def _calculate_tile_round(self, sections):
        """计算每个section的tile round"""
        sec_softmax_2 = sections[3]
        if sec_softmax_2.tile_nums_per_core <= 1:
            for section in sections:
                section.tile_round = math.ceil(section.tile_nums_per_core)
        else:
            for section in sections:
                section.tile_round = math.ceil(
                    section.tile_nums_per_core / sec_softmax_2.tile_nums_per_core
                )

    def _generate_sections(self, m, k, n, tiling_param: list[TilingParam]):
        """生成各个计算阶段的sections"""
        sec_qk = self._create_section_qk(m, k, n, tiling_param)
        sec_softmax_1 = self._create_section_softmax_1(m, n, tiling_param)
        sec_pv = self._create_section_pv(m, k, n, tiling_param)
        sec_softmax_2 = self._create_section_softmax_2(m, k, n, tiling_param)

        sections = [sec_qk, sec_softmax_1, sec_pv, sec_softmax_2]
        
        # 计算tile数量
        for section in sections:
            self._calculate_tile_nums(section)
        
        # 计算tile round
        self._calculate_tile_round(sections)
        
        return sections

    def _generate_tiles(self):
        """分section生成tile"""
        tiling = CatlassTiling()
        for section in self.section_list:
            tiles = tiling.generate_tiles(section)
            section.input_tiles = tiles[0]
            section.output_tiles = tiles[1]

    def _setup_softmax_tiles(self):
        """设置softmax计算的tiles"""
        softmax_sec = self.section_list[1]
        for tile in softmax_sec.input_tiles:
            if tile.col_start == 0:
                tile.fused_op = self.softmax_stage[0]
            else:
                tile.fused_op = self.softmax_stage[1]

    def _setup_output_tiles(self):
        """设置输出计算的tiles"""
        for tile in self.section_list[3].input_tiles:
            tile.fused_op = self.output_stage

    def _calculate_cv_parallel_time(self, attn_num):
        """计算CV并行时间"""
        inter_core_pipe = InterCorePipeline(self.section_list, self.aicore)
        res = inter_core_pipe.calculate_sections_time(plot_cv_block=True)

        for k, _ in res.items():
            if k in ResultKey.time_keys():
                res[k] *= attn_num
        
        return res

    def time_predict(
        self, shapes: list, tiling_param: list[TilingParam], aicore: AICoreCostModel
    ) -> dict[ResultKey, float]:
        """
        分成 N1 个attn计算， 每个attn Q = [B*S1, D], 
        K/V = [B*S2, D] ==> QK = [B*S1,D, B*S2] - mkn, 
        Softmax = [B*S1,B*S2] - mn, 
        PV = [B*S  _1,B*S2,D] - mnk, 
        output = [B*S1, D] - mk
        :param shapes:   [B, N1, N2, S1, S2, D] 格式
        B - batch size
        N1/N2 - head相关参数，N1 = GQA的组数， N2 = 各组头数
        S1/S2 - sequence len， S1 = Q的seq len， S2 = K/V的seq len
        D - head dim
        :param tiling_param: [cube_tiling, vec_tiling]
        :param aicore:
        :return:
        """
        # 解析参数
        m = shapes[0] * shapes[3]
        k = shapes[5]
        n = shapes[0] * shapes[4]
        attn_num = shapes[1]
        self.aicore = aicore

        # 生成sections
        self.section_list = self._generate_sections(m, k, n, tiling_param)

        # 生成tiles
        self.__generate_tiles()

        # 设置softmax和output的tiles
        self._setup_softmax_tiles()
        self._setup_output_tiles()

        # 计算CV并行时间
        res = self._calculate_cv_parallel_time(attn_num)

        return res