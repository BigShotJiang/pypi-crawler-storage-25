# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

from core.backend.engineering_costmodel.core.aicore_costmodel import AICoreCostModel
from core.common.entity import (
    CoreType,
    VecOpType,
    DType,
    ResultKey,
    Section,
    TensorData,
    MemLoc,
)
from core.backend.engineering_costmodel.core.pipeline.aiv_pipeline import AIVPipeline
from core.backend.engineering_costmodel.core.tiling_and_core_split.catlass_tiling import CatlassTiling
from core.backend.engineering_costmodel.core.tiling_and_core_split.tiling_strategy_register import TilingParam
from core.backend.engineering_costmodel.core.vector_op import VectorBasicOp

from core.common.log_format import logging
from core.backend.engineering_costmodel.op_model.basic_operator import BasicOperatorModel

# 创建一个日志记录器
logger = logging.getLogger(__name__)


class CumSumModel(BasicOperatorModel):
    def __init__(self, input_precision: DType, output_precision: DType, **kwargs):
        super().__init__("CumSum", CoreType.AIV, input_precision, output_precision)
        row, col = "row", "col"
        input_dup_x1 = TensorData(
            "input_dup_x1", DType.FP32, [row, col], MemLoc.GM
        )
        input_dup_x2 = TensorData(
            "input_dup_x2", DType.FP32, [row, col], MemLoc.GM
        )
        input_dup_x3 = TensorData(
            "input_dup_x3", DType.FP32, [row, col], MemLoc.GM
        )
        dup_out = TensorData("dup_out", DType.FP16, [row, col], MemLoc.GM)
        comb = [
            VectorBasicOp(
                VecOpType.VECTOR_DUP,
                [input_dup_x1, input_dup_x2, input_dup_x3],
                [dup_out],
                pipe_barrier=False,
            )
        ]
        self.cumsum = comb
        self.row = row
        self.col = col

    def time_predict(
        self, shapes: list, tiling_param: list[TilingParam], aicore: AICoreCostModel
    ) -> dict[ResultKey, float]:
        rows = 1
        for i in range(len(shapes[0]) - 1):
            rows *= shapes[0][i]
        cols = shapes[0][-1]
        logger.info("rows = %s", rows)
        logger.info("cols = %s", cols)
        # tiling&分核
        section = Section(
            0,
            CoreType.AIV,
            rows,
            0,
            cols,
            tiling_param[0],
            self.input_precision,
            self.output_precision,
        )
        tiling = CatlassTiling()
        input_tiles, output_tiles = tiling.generate_tiles(section)
        for tile in input_tiles:
            tile.fused_op = self.cumsum
            shape_dict = {self.row: tile.rows, self.col: tile.cols}
            tile.shape_dict = shape_dict
        aiv_pipe = AIVPipeline(aicore, tiling_param[0], small_pack=True)
        core_set = {tile.core for tile in input_tiles}
        size_by_core = {
            core: sum([t.size for t in input_tiles if t.core == core])
            for core in core_set
        }
        max_size_core = max(size_by_core.items(), key=lambda x: x[1])[0]
        input_tiles = [tile for tile in input_tiles if tile.core == max_size_core]
        return aiv_pipe.calculate_time(input_tiles, output_tiles)