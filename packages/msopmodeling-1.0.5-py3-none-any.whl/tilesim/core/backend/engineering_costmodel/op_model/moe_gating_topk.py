# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import math

from core.backend.engineering_costmodel.core.aicore_costmodel import AICoreCostModel
from core.common.entity import (
    CoreType,
    VecOpType,
    DType,
    ResultKey,
    Section,
    TensorData,
    MemLoc,
)
from core.backend.engineering_costmodel.core.pipeline.aiv_pipeline import AIVPipeline
from core.backend.engineering_costmodel.core.tiling_and_core_split.catlass_tiling import CatlassTiling
from core.backend.engineering_costmodel.core.tiling_and_core_split.tiling_strategy_register import TilingParam
from core.backend.engineering_costmodel.core.vector_op import VectorBasicOp
from core.backend.engineering_costmodel.op_model.basic_operator import BasicOperatorModel
from core.common.log_format import logging

# 创建一个日志记录器
logger = logging.getLogger(__name__)


class MoeGatingTopK(BasicOperatorModel):
    def __init__(self, input_precision: DType, output_precision: DType, output_shape, **kwargs):
        super().__init__(
            "MoeGatingTopKForward", CoreType.AIV, input_precision, output_precision
        )
        self.k = output_shape[0][-1]
        self.full_row = output_shape[0][0]
        self.vadds_times = int(math.log2(output_shape[0][0]))
        self.row, self.col = 'row', 'col'
        self._init_tensors(input_precision)
        self._op = self._generate_op_bf16()

    def _init_tensors(self, input_precision):
        self.input_x = TensorData("input_x", input_precision, [self.row, self.col], MemLoc.GM)
        self.input_x_ub = TensorData("input_x_ub", DType.FP32, [self.row, self.col], MemLoc.UB)
        self.topk_out = TensorData("topk_out", input_precision, [self.row, self.k], MemLoc.GM)

    def _generate_op_bf16(self):
        return [
                   VectorBasicOp(VecOpType.CONV_BF162F32, [self.input_x], [self.input_x_ub], pipe_barrier=False),
                   VectorBasicOp(VecOpType.VMULS, [self.input_x_ub], [self.input_x_ub]),  # -x
                   VectorBasicOp(VecOpType.VEXP, [self.input_x_ub], [self.input_x_ub]),  # e^-x
                   VectorBasicOp(VecOpType.VADDS, [self.input_x_ub], [self.input_x_ub]),  # 1 + e^-x
                   VectorBasicOp(VecOpType.VDIV, [self.input_x_ub], [self.input_x_ub]),  # 1 / (1 + e^-x) := sigmoid_x
               ] + [
                   VectorBasicOp(VecOpType.VADDS, [self.input_x_ub], [self.input_x_ub]) for _ in range(self.vadds_times)
               ] + [
                   VectorBasicOp(VecOpType.VBS32, [self.input_x_ub], [self.input_x_ub]),
                   VectorBasicOp(VecOpType.VREDUCEV2, [self.input_x_ub], [self.input_x_ub]),
                   VectorBasicOp(VecOpType.VCADD, [self.input_x_ub], [self.input_x_ub])  # NEXT -- 缺少VCPADD，此处用VCADD代替
               ] + [
                   VectorBasicOp(VecOpType.VBS32, [self.input_x_ub], [self.input_x_ub]),
                   VectorBasicOp(VecOpType.VREDUCEV2, [self.input_x_ub], [self.input_x_ub])
               ] * int(self.full_row // 1024 // 4) + [
                   VectorBasicOp(VecOpType.CONV_S322F32, [self.input_x_ub], [self.input_x_ub]),
                   VectorBasicOp(VecOpType.VMS4V2, [self.input_x_ub], [self.input_x_ub]),
                   VectorBasicOp(VecOpType.VREDUCEV2, [self.input_x_ub], [self.input_x_ub]),
                   VectorBasicOp(VecOpType.VMULS, [self.input_x_ub], [self.input_x_ub]),
                   VectorBasicOp(VecOpType.VCADD, [self.input_x_ub], [self.input_x_ub]),
                   VectorBasicOp(VecOpType.VDIV, [self.input_x_ub], [self.input_x_ub]),
                   VectorBasicOp(VecOpType.VMULS, [self.input_x_ub], [self.input_x_ub]),
                   # 3个输出，shape分别是[row, k]、[row, k]、[row, col]
                   VectorBasicOp(VecOpType.CONV_F322BF16, [self.input_x_ub], [self.topk_out]),
                   VectorBasicOp(VecOpType.CONV_F322BF16, [self.input_x_ub], [self.topk_out]),
                   VectorBasicOp(VecOpType.CONV_F322BF16, [self.input_x_ub], [self.input_x])
               ]

    def get_tiling_strategy(self, shapes: list) -> list[TilingParam]:
        m1 = max(1, shapes[0][0] // 32)
        n1 = 1

        tiling_list = [TilingParam(0, 0, 0, m1, n1, 0, 0, 48, 1, swizzle_offset=1, swizzle_direction=0)]

        return tiling_list

    def time_predict(
            self, shapes: list, tiling_param: list[TilingParam], aicore: AICoreCostModel
    ) -> dict[ResultKey, float]:
        # NEXT -- 暂未考虑bias
        rows = shapes[0][0]
        cols = shapes[0][1]
        logger.info("rows = %s", rows)
        logger.info("cols = %s", cols)

        section = Section(
            0,
            CoreType.AIV,
            rows,
            0,
            cols,
            tiling_param[0],
            self.input_precision,
            self.output_precision,
        )
        tiling = CatlassTiling()
        input_tiles, output_tiles = tiling.generate_tiles(section)
        logger.info("len(input_tiles) = %s", len(input_tiles))
        for tile in input_tiles:
            tile.fused_op = self._op
            shape_dict = {
                self.row: tile.rows,
                self.col: tile.cols
            }
            tile.shape_dict = shape_dict

        aiv_pipe = AIVPipeline(aicore, tiling_param[0])

        core_set = {tile.core for tile in input_tiles}
        size_by_core = {
            core: sum([t.size for t in input_tiles if t.core == core])
            for core in core_set
        }
        max_size_core = max(size_by_core.items(), key=lambda x: x[1])[0]
        input_tiles_new = [tile for tile in input_tiles if tile.core == max_size_core]
        ret = aiv_pipe.calculate_time(input_tiles_new, output_tiles)
        return ret