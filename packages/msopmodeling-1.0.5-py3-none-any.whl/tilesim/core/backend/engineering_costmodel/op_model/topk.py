# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

from core.backend.engineering_costmodel.core.aicore_costmodel import AICoreCostModel
from core.common.entity import CoreType, DType, ResultKey
from core.backend.engineering_costmodel.core.tiling_and_core_split.tiling_strategy_register import TilingParam
from core.backend.engineering_costmodel.op_model.basic_operator import BasicOperatorModel
from core.common.log_format import logging

# 创建一个日志记录器
logger = logging.getLogger(__name__)

_RESULT_SAMPLES = {
    (128, 50, 8): {
        ResultKey.VEC_TIME: 4.358,
        ResultKey.MTE2_TIME_AIV: 5.842,
        ResultKey.MTE3_TIME: 0.667,
        ResultKey.AIV_TOTAL_CYCLES: 1889110,
        ResultKey.CORE_TIME: 29.48,
        ResultKey.AIV_TIME: 23.747,
        ResultKey.L2_MISS_RATE: 1.,
    }
}


class TopKV2Model(BasicOperatorModel):
    def __init__(
            self,
            input_precision: DType,
            output_precision: DType,
            **kwargs
    ):
        super().__init__(
            "TopKV2", CoreType.AIV, input_precision, output_precision
        )

    def topk_op(self):
        """
        根据hiascend关于topk定义, 其存在两种模式`常规模式`和`高性能模式` for topk_op

        > https://www.hiascend.com/document/detail/zh/canncommercial/83RC1/API/ascendcopapi/atlasascendc_api_07_0836.html
        """

        pass

    def op_normal_mode(self):
        """Normal模式"""
        pass

    def op_small_mode(self):
        """Small模式"""
        pass

    def _time_predict_temp(
            self, shapes: list, tiling_param: list[TilingParam], aicore: AICoreCostModel
    ) -> dict[ResultKey, float]:
        """
        作为临时的对接方案
        """
        rows = 1
        for i in range(len(shapes[0]) - 1):
            rows *= shapes[0][i]
        cols = shapes[0][-1]
        result = _RESULT_SAMPLES.get((rows, cols, 8), None)
        if result is None:
            logger.warning("未命中默认shape")
            result = _RESULT_SAMPLES.get((128, 50, 8))
        return result

    def time_predict(
            self, shapes: list, tiling_param: list[TilingParam], aicore: AICoreCostModel
    ) -> dict[ResultKey, float]:
        return self._time_predict_temp(shapes, tiling_param, aicore)