# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

from core.backend.engineering_costmodel.core.aicore_costmodel import AICoreCostModel
from core.common.entity import (
    CoreType,
    VecOpType,
    DType,
    ResultKey,
    Section,
    TensorData,
    MemLoc,
)
from core.backend.engineering_costmodel.core.pipeline.aiv_pipeline import AIVPipeline
from core.backend.engineering_costmodel.core.tiling_and_core_split.catlass_tiling import CatlassTiling
from core.backend.engineering_costmodel.core.tiling_and_core_split.tiling_strategy_register import TilingParam
from core.backend.engineering_costmodel.core.vector_op import VectorBasicOp
from core.backend.engineering_costmodel.op_model.basic_operator import BasicOperatorModel
from core.common.log_format import logging

# 创建一个日志记录器
logger = logging.getLogger(__name__)


class RmsNormModel(BasicOperatorModel):
    def __init__(self, input_precision: DType, output_precision: DType, **kwargs):
        super().__init__(
            "RmsNormForward", CoreType.AIV, input_precision, output_precision
        )
        self.row, self.col, self.col_half = "row", "col", "col_half"
        self._init_tensors(input_precision)
        if input_precision == DType.BF16:
            self.rms_norm_op = self._generate_rms_norm_op_bf16()
        else:
            self.rms_norm_op = self._generate_rms_norm_op_fp32()

    def _init_tensors(self, input_precision):
        self.input_x = TensorData("input_x", input_precision, [self.row, self.col], MemLoc.GM)
        self.input_gamma = TensorData("input_gamma", input_precision, [self.col], MemLoc.GM)
        self.input_x_ub = TensorData("input_x_ub", DType.FP32, [self.row, self.col], MemLoc.UB)
        self.input_gamma_ub = TensorData("input_gamma_ub", DType.FP32, [self.col], MemLoc.UB)
        self.x_square = TensorData("x_square", DType.FP32, [self.row, self.col], MemLoc.UB)
        self.vadd = TensorData("vadd", DType.FP32, [self.row, 64], MemLoc.UB)
        self.vadd_1 = TensorData("vadd_1", DType.FP32, [self.row, self.col_half], MemLoc.UB)
        self.vadd_2 = TensorData("vadd_2", DType.FP32, [self.row, self.col_half], MemLoc.UB)
        self.reduce_sum_result = TensorData("reduce_sum_result", DType.FP32, [self.row, 1], MemLoc.UB)
        self.reduce_sum_per_dim = TensorData("reduce_sum_per_dim", DType.FP32, [self.row, self.col],
                                             MemLoc.UB)
        self.reduce_sum_add_eps = TensorData("reduce_sum_add_eps", DType.FP32, [self.row, 1], MemLoc.UB)
        self.sqrt_result = TensorData("sqrt_result", DType.FP32, [self.row, 1], MemLoc.UB)
        self.rstd = TensorData("rstd", DType.FP32, [self.row, 1], MemLoc.UB)
        self.rstd_gm = TensorData("rstd_gm", DType.FP32, [self.row, 1], MemLoc.GM)
        self.broadcast = TensorData("broadcast", DType.FP32, [self.row, self.col], MemLoc.UB)
        self.x_mul_broadcast = TensorData("x_mul_broadcast", DType.FP32, [self.row, self.col], MemLoc.UB)
        self.out = TensorData("out", input_precision, [self.row, self.col], MemLoc.GM)

    def _generate_rms_norm_op_bf16(self):
        return [
                   VectorBasicOp(VecOpType.CONV_BF162F32, [self.input_x], [self.input_x_ub], pipe_barrier=False),
                   VectorBasicOp(VecOpType.VMUL_SELF, [self.input_x_ub, self.input_x_ub], [self.x_square]),
                   VectorBasicOp(VecOpType.MOVEV, [self.x_square], [self.x_square])] + \
               [
                   VectorBasicOp(VecOpType.VADD, [self.vadd, self.vadd], [self.vadd]) for _ in range(16)] + \
               [
                   VectorBasicOp(VecOpType.VCADD, [self.vadd_2], [self.reduce_sum_result]),
                   VectorBasicOp(VecOpType.VMULS, [self.reduce_sum_result], [self.reduce_sum_per_dim]),
                   VectorBasicOp(VecOpType.VADDS, [self.reduce_sum_per_dim], [self.reduce_sum_add_eps]),
                   VectorBasicOp(VecOpType.VSQRT, [self.reduce_sum_add_eps], [self.sqrt_result]),
                   VectorBasicOp(VecOpType.VDIV, [self.sqrt_result], [self.rstd, self.rstd_gm]),
                   VectorBasicOp(VecOpType.VBRCB, [self.rstd], [self.broadcast]),
                   VectorBasicOp(VecOpType.VCOPY, [self.broadcast], [self.broadcast]),
                   VectorBasicOp(VecOpType.VMUL, [self.input_x_ub, self.broadcast], [self.x_mul_broadcast]),
                   VectorBasicOp(VecOpType.CONV_BF162F32, [self.input_gamma], [self.input_gamma_ub]),
                   VectorBasicOp(VecOpType.VMUL, [self.x_mul_broadcast, self.input_gamma], [self.x_mul_broadcast]),
                   VectorBasicOp(VecOpType.CONV_F322BF16, [self.x_mul_broadcast], [self.out])
               ]

    def _generate_rms_norm_op_fp32(self):
        return [
            *self._generate_initial_operations(),
            *self._generate_reduce_sum_operations(),
            *self._generate_sqrt_and_div_operations(),
            *self._generate_broadcast_and_mul_operations(),
        ]

    def _generate_initial_operations(self):
        return [
            VectorBasicOp(VecOpType.VMUL_SELF, [self.input_x, self.input_x_ub], [self.x_square], pipe_barrier=False),
            VectorBasicOp(VecOpType.MOVEV, [self.x_square], [self.x_square]),
        ]

    def _generate_reduce_sum_operations(self):
        return [
            VectorBasicOp(VecOpType.VADD, [self.vadd_1, self.vadd_1], [self.vadd_1]),
            VectorBasicOp(VecOpType.VADD, [self.vadd_2, self.vadd_2], [self.vadd_2]),
            VectorBasicOp(VecOpType.VCADD, [self.vadd_2], [self.reduce_sum_result]),
            VectorBasicOp(VecOpType.VMULS, [self.reduce_sum_result], [self.reduce_sum_per_dim]),
            VectorBasicOp(VecOpType.VADDS, [self.reduce_sum_per_dim], [self.reduce_sum_add_eps]),
        ]

    def _generate_sqrt_and_div_operations(self):
        return [
            VectorBasicOp(VecOpType.VSQRT, [self.reduce_sum_add_eps], [self.sqrt_result]),
            VectorBasicOp(VecOpType.VDIV, [self.sqrt_result], [self.rstd, self.rstd_gm]),
        ]

    def _generate_broadcast_and_mul_operations(self):
        return [
            VectorBasicOp(VecOpType.VBRCB, [self.rstd], [self.broadcast]),
            VectorBasicOp(VecOpType.VCOPY, [self.broadcast], [self.broadcast]),
            VectorBasicOp(VecOpType.VMUL, [self.input_x_ub, self.broadcast], [self.x_mul_broadcast]),
            VectorBasicOp(VecOpType.VMUL, [self.x_mul_broadcast, self.input_gamma], [self.out]),
        ]

    def get_tiling_strategy(self, shapes: list) -> list[TilingParam]:
        reduce_dim_size = shapes[0][-1]
        n1 = reduce_dim_size
        if reduce_dim_size == 1536:
            m1 = 8
        elif reduce_dim_size == 128:
            m1 = 95
        else:
            m1 = 13000 // reduce_dim_size

        tiling_list = [TilingParam(0, 0, 0, m1, n1, 0, 0, 48, 1, swizzle_offset=1, swizzle_direction=0)]

        return tiling_list

    def time_predict(
            self, shapes: list, tiling_param: list[TilingParam], aicore: AICoreCostModel
    ) -> dict[ResultKey, float]:
        rows = 1
        for i in range(len(shapes[0]) - 1):
            rows *= shapes[0][i]
        cols = shapes[0][-1]
        logger.info("rows = %s", rows)
        logger.info("cols = %s", cols)

        section = Section(
            0,
            CoreType.AIV,
            rows,
            0,
            cols,
            tiling_param[0],
            self.input_precision,
            self.output_precision,
        )
        tiling = CatlassTiling()
        input_tiles, output_tiles = tiling.generate_tiles(section)
        logger.info("len(input_tiles) = %s", len(input_tiles))
        for tile in input_tiles:
            tile.fused_op = self.rms_norm_op
            shape_dict = {
                self.row: tile.rows,
                self.col: tile.cols,
                self.col_half: tile.cols // 2,
            }
            tile.shape_dict = shape_dict

        aiv_pipe = AIVPipeline(aicore, tiling_param[0])

        core_set = {tile.core for tile in input_tiles}
        size_by_core = {
            core: sum([t.size for t in input_tiles if t.core == core])
            for core in core_set
        }
        max_size_core = max(size_by_core.items(), key=lambda x: x[1])[0]
        input_tiles_new = [tile for tile in input_tiles if tile.core == max_size_core]
        ret = aiv_pipe.calculate_time(input_tiles_new, output_tiles)
        if self.input_precision == DType.BF16:
            ret[ResultKey.CORE_TIME] += 4
            ret[ResultKey.VEC_TIME] += 4
            ret[ResultKey.AIV_TIME] += 4
        return ret