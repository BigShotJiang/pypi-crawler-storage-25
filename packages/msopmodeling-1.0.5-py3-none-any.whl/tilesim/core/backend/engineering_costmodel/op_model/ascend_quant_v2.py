# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

from core.backend.engineering_costmodel.core.aicore_costmodel import AICoreCostModel
from core.backend.engineering_costmodel.core.pipeline.aiv_pipeline import AIVPipeline
from core.backend.engineering_costmodel.core.tiling_and_core_split.catlass_tiling import CatlassTiling
from core.backend.engineering_costmodel.core.tiling_and_core_split.tiling_strategy_register import TilingParam
from core.backend.engineering_costmodel.core.vector_op import VectorBasicOp
from core.backend.engineering_costmodel.op_model.basic_operator import BasicOperatorModel
from core.common.entity import (
    DType,
    CoreType,
    Section,
    VecOpType,
    TensorData,
    MemLoc, ResultKey, PipeAnaConfig, CoreUnit, OpState,
)
from core.common.log_format import logging

# 创建一个日志记录器
logger = logging.getLogger(__name__)


def _create_tensor(name, precision, shape, cache_type):
    return TensorData(name, precision, shape, cache_type)


class AscendQuantV2(BasicOperatorModel):
    def __init__(
            self,
            input_precision: DType,
            output_precision: DType,
            has_offset=True,
            sqrt_mode=False,
            op_state=None
    ):
        super().__init__(
            "AscendQuantV2", CoreType.AIV, input_precision, output_precision
        )
        self.section_list = None
        if op_state == OpState.DYNAMIC:
            self.scalar = 4
        else:
            self.scalar = 0

        # per channel
        self.row, self.col = "row", "col"
        self.input_x = _create_tensor("input_x", self.input_precision, [self.row, self.col], MemLoc.GM)
        self.input_scale = _create_tensor("input_scale", DType.FP32, [self.col], MemLoc.UB)
        self.input_offset = _create_tensor("input_offset", DType.FP32, [self.col], MemLoc.UB)

        self.x_mul_scale = _create_tensor("x_mul_scale", DType.FP32, [self.row, self.col], MemLoc.UB)
        self.add_offset = _create_tensor("add_offset", DType.FP32, [self.row, self.col], MemLoc.UB)
        self.conv_int32 = _create_tensor("conv_int32", DType.INT32, [self.row, self.col], MemLoc.UB)
        self.conv_fp16 = _create_tensor("conv_fp16", DType.FP16, [self.row, self.col], MemLoc.UB)
        self.out = _create_tensor("out", DType.INT8, [self.row, self.col], MemLoc.GM)

        self.ascend_quant_v2_op = self._generate_combinations(has_offset, sqrt_mode)

    def get_tiling_strategy(self, shapes: list) -> list[TilingParam]:
        m, n = shapes[0]

        # 如果满核分配，则一行一个数据
        if m > 40:
            tm, tn = 1, n
        else:
            tm = 1
            tn = 256

        tiling_list = [
            TilingParam(m0=0, k0=0, n0=0, m1=tm, k1a=0, k1b=0, n1=tn, w=4, h=6, swizzle_offset=1, swizzle_direction=0)
        ]

        return tiling_list

    def _generate_combinations(self, has_offset, sqrt_mode):

        if self.input_precision == DType.FP16 or self.input_precision == DType.BF16:
            base_ops = [
                self._create_vector_op(VecOpType.CONV_BF162F32, [self.input_x], [self.x_mul_scale], pipe_barrier=False),
                self._create_vector_op(VecOpType.VMUL, [self.x_mul_scale, self.input_scale], [self.x_mul_scale]),
                self._create_vector_op(VecOpType.CONV_F322S32R, [self.x_mul_scale], [self.conv_int32]),
                self._create_vector_op(VecOpType.CONV_DEQ, [self.conv_int32], [self.conv_fp16]),
                self._create_vector_op(VecOpType.CONV_F162S8R, [self.conv_fp16], [self.out])
            ]
        else:
            base_ops = [
                self._create_vector_op(VecOpType.VMUL, [self.input_x, self.input_scale], [self.x_mul_scale], pipe_barrier=False),
                self._create_vector_op(VecOpType.CONV_F322S32R, [self.x_mul_scale], [self.conv_int32]),
                self._create_vector_op(VecOpType.CONV_DEQ, [self.conv_int32], [self.conv_fp16]),
                self._create_vector_op(VecOpType.CONV_F162S8R, [self.conv_fp16], [self.out])
            ]

        if sqrt_mode and has_offset:
            return [
                *base_ops[:1],
                self._create_vector_op(VecOpType.VMUL, [self.x_mul_scale, self.input_scale], [self.x_mul_scale]),
                self._create_vector_op(VecOpType.VADD, [self.x_mul_scale, self.input_offset], [self.add_offset]),
                self._create_vector_op(VecOpType.CONV_F322S32R, [self.add_offset], [self.conv_int32]),
                *base_ops[2:],
            ]

        elif has_offset:
            return [
                *base_ops[:1],
                self._create_vector_op(VecOpType.VADD, [self.x_mul_scale, self.input_offset], [self.add_offset]),
                self._create_vector_op(VecOpType.CONV_F322S32R, [self.add_offset], [self.conv_int32]),
                *base_ops[2:],
            ]

        elif sqrt_mode:
            return [
                *base_ops[:1],
                self._create_vector_op(VecOpType.VMUL, [self.x_mul_scale, self.input_scale], [self.x_mul_scale]),
                *base_ops[1:],
            ]
        else:
            return base_ops

    def _create_vector_op(self, op_type, inputs, outputs, pipe_barrier=True):
        return VectorBasicOp(op_type, inputs, outputs, pipe_barrier=pipe_barrier)

    def time_predict(
            self, shapes: list, tiling_param: list[TilingParam], aicore: AICoreCostModel
    ) -> dict[ResultKey, float]:
        rows = shapes[0][0]
        cols = shapes[0][1]
        scale = shapes[1]
        offset = shapes[2]
        # 合并成一个张量
        cols = rows * cols
        rows = 1
        logger.info("rows: %s, cols: %s, scale: %s, offset: %s", rows, cols, scale, offset)

        sec = Section(
            0,
            CoreType.AIV,
            rows,
            0,
            cols,
            tiling_param[0],
            self.input_precision,
            self.output_precision,
        )
        tiling = CatlassTiling()
        input_tiles, output_tiles = tiling.generate_tiles(sec)

        for tile in input_tiles:
            tile.fused_op = self.ascend_quant_v2_op
            shape_dict = {self.row: tile.rows, self.col: tile.cols}
            tile.shape_dict = shape_dict
            logger.info("input: %s, %s, %s", sec.bias, tile.rows, tile.cols)

        aiv_pipeline = AIVPipeline(aicore, tiling_param[0])

        core_set = {tile.core for tile in input_tiles}
        size_by_core = {
            core: sum([t.size for t in input_tiles if t.core == core])
            for core in core_set
        }
        max_size_core = max(size_by_core.items(), key=lambda x: x[1])[0]
        input_tiles = [tile for tile in input_tiles if tile.core == max_size_core]
        pipe_ana_config = [(CoreUnit.AIV_MTE2, CoreUnit.VEC, CoreUnit.AIV_MTE3)]
        latency = aiv_pipeline.calculate_time(input_tiles, output_tiles, PipeAnaConfig(pipe_ana_config))
        latency[ResultKey.CORE_TIME] = latency[ResultKey.CORE_TIME] + self.scalar
        return latency