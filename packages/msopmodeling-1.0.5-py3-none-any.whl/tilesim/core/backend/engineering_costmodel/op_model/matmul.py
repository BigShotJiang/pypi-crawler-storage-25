# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

import math

from core.backend.engineering_costmodel.core.aicore_costmodel import AICoreCostModel
from core.common.entity import DType, CoreType, Section, ResultKey
from core.backend.engineering_costmodel.core.pipeline.inter_core_pipeline import InterCorePipeline
from core.backend.engineering_costmodel.core.tiling_and_core_split.catlass_tiling import CatlassTiling
from core.backend.engineering_costmodel.core.tiling_and_core_split.swizzle_tiling import generate_tiles
from core.backend.engineering_costmodel.core.tiling_and_core_split.tiling_strategy_register import TilingParam
from core.backend.engineering_costmodel.op_model.basic_operator import BasicOperatorModel


def matmul_tiling(m, k, n, core_num, d, input_precision: DType, output_precision: DType):
    tm, tn, tk0, tk1 = 128, 256, 64, 256
    if input_precision == DType.FP32:
        tk0 = 32
        tk1 = 128
    elif input_precision == DType.INT8:
        tk0 = 128
        tk1 = 512

    wh = int(core_num / d)
    if m < 128:
        tm = m
        tn = 16
        tk0 = 32
        tk1 = 32

    m_tiles = math.ceil(m / tm)
    h = min(m_tiles, core_num)
    w = wh // h

    if w * h < core_num:
        h = core_num
        w = 1

    tiling = TilingParam(
        m0=tm, n0=tn, k0=tk0,
        m1=tm, n1=tn, k1a=tk1, k1b=tk1,
        swizzle_offset=0,
        swizzle_direction=0,
        w=w, h=h, d=d
    )
    return tiling


class Matmul(BasicOperatorModel):

    def __init__(self, input_precision: DType, output_precision: DType, **kwargs):
        super().__init__("Matmul", CoreType.AIC, input_precision, output_precision)
        self.section_list = None

    def __generate_sections(self, m, k, n, tiling_param: list[TilingParam]):
        cube_tiling = tiling_param[0]

        sec = Section(
            bias=0,
            core_type=CoreType.AIC,
            m=m,
            k=k,
            n=n,
            tiling_param=cube_tiling,
            input_precision=self.input_precision,
            output_precision=self.output_precision,
        )
        tile_cnt = math.ceil(m / cube_tiling.m1) * math.ceil(n / cube_tiling.n1)
        sec.tile_round = tile_cnt
        return [sec]

    def __generate_tiles(self, tiling_param: TilingParam):
        """
        分section生成tile
        """

        tiling_func = CatlassTiling().generate_tiles
        if tiling_param.swizzle_offset < 0:
            tiling_func = generate_tiles

        for section in self.section_list:
            tiles = tiling_func(section)
            section.input_tiles = tiles[0]
            section.output_tiles = tiles[1]

    def time_predict(
            self, shapes: list, tiling_param: list[TilingParam], aicore: AICoreCostModel
    ) -> dict[ResultKey, float]:
        """
        matmul算子
        :param shapes:   [M,K,N]
        :param tiling_param: [cube_tiling]
        :param aicore:
        :return:
        """

        ma, ka = shapes[0]
        kb, nb = shapes[1]

        if ka != kb:
            nb, kb = shapes[1]

        if ka != kb:
            raise ValueError("matmul reduce轴维度需要相同！")

        m, k, n = ma, ka, nb

        if tiling_param[0].m0 == 0:
            tiling_param = [matmul_tiling(m, k, n, tiling_param[0].core_num, tiling_param[0].d, self.input_precision, self.output_precision)]

        # 生成section结构
        self.section_list = self.__generate_sections(m, k, n, tiling_param)

        # tiling&分核
        self.__generate_tiles(tiling_param[0])

        # 并行流水时间计算
        inter_core_pipe = InterCorePipeline(self.section_list, aicore)
        res = inter_core_pipe.calculate_sections_time(plot_cv_block=True)

        return res