# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

from core.common.entity import (
    CoreType,
    VecOpType,
    DType,
    ResultKey,
    Section,
    TensorData,
    MemLoc,
)
from core.backend.engineering_costmodel.core.aicore_costmodel import AICoreCostModel
from core.backend.engineering_costmodel.core.pipeline.inter_core_pipeline import InterCorePipeline
from core.backend.engineering_costmodel.core.tiling_and_core_split.catlass_tiling import CatlassTiling
from core.backend.engineering_costmodel.core.tiling_and_core_split.tiling_strategy_register import TilingParam
from core.backend.engineering_costmodel.core.vector_op import VectorBasicOp
from core.backend.engineering_costmodel.op_model.basic_operator import BasicOperatorModel


def _parse_shape(shapes: list):
    m, k = shapes[0][0], shapes[0][1]
    if len(shapes[1]) == 4:
        # (k1，n1，n0，k0) 或 (n1，k1，k0，n0) 格式，其中ceil(k / k0) = k1，ceil(n / n0) = n1
        shape_prod = shapes[1][1] * shapes[1][2]
        n = shapes[1][0] * shapes[1][3] if shape_prod == k else shape_prod
    else:
        n = shapes[1][1]
    return m, k, n


class QuantBatchMatmulV3(BasicOperatorModel):
    def __init__(self, x_precision: DType, output_precision: DType, **kwargs):
        super().__init__(
            "QuantBatchMatmulV3", CoreType.MIX, x_precision, output_precision
        )
        self.x_precision = x_precision
        self.section_list = None

        # 使用您提供的张量定义
        m, n = "m", "n"
        input_x = TensorData("input_x", DType.FP32, [m, n], MemLoc.L2)
        adds_input_x = TensorData(
            "adds_input_x", DType.FP32, [m, n], MemLoc.UB
        )
        pertoken_scale = TensorData(
            "pertoken_scale", DType.FP32, [m, n], MemLoc.GM
        )
        quant_x = TensorData("quant_x", DType.FP32, [m, n], MemLoc.UB)
        out = TensorData("out", DType.FP16, [m, n], MemLoc.GM)

        # 使用您提供的融合操作序列
        self.fused_op = [
            VectorBasicOp(
                VecOpType.VADDS, [input_x], [adds_input_x], pipe_barrier=False
            ),
            VectorBasicOp(VecOpType.CONV_S322F32, [adds_input_x], [quant_x]),
            VectorBasicOp(VecOpType.VMUL, [pertoken_scale, adds_input_x], [quant_x]),
            VectorBasicOp(VecOpType.CONV_F322F16, [quant_x], [out]),
        ]

        self.m_dim = m
        self.n_dim = n

    def get_tiling_strategy(self, shapes: list) -> list[TilingParam]:
        m, k, n = _parse_shape(shapes)
        tm, tn, tk1, tk0 = 128, 256, 256, 64
        if self.input_precision.size == 1:
            tn = 512
        elif self.input_precision.size == 4:
            tn = 128

        tm, tn, tk1, tk0 = min(m, tm), min(n, tn), min(k, tk1), min(k, tk0)

        tiling_list = [
            TilingParam(m0=tm, k0=tk0, n0=tn, m1=tm, k1a=tk1, k1b=tk1, n1=tn, w=4, h=6, swizzle_offset=1,
                        swizzle_direction=0),
            TilingParam(m0=0, k0=0, n0=0, m1=tm, k1a=0, k1b=0, n1=tn, w=4, h=6, swizzle_offset=1, swizzle_direction=0)
        ]

        return tiling_list

    def _generate_sections(self, m, k, n, tiling_params):
        """生成量化路径的两个计算段"""
        # Cube计算段
        cube_section = Section(
            bias=0,
            core_type=CoreType.AIC,
            m=m,
            k=k,
            n=n,
            tiling_param=tiling_params[0],
            input_precision=self.x_precision,
            output_precision=DType.INT8,
        )

        # Vector计算段
        vector_section = Section(
            bias=1,
            core_type=CoreType.AIV,
            m=m,
            k=0,
            n=n,
            tiling_param=tiling_params[1],
            input_precision=DType.FP32,
            output_precision=self.output_precision,
        )
        vector_section.input_dependency = {0: 0}  # 依赖Cube输出

        return [cube_section, vector_section]

    def _generate_tiles(self, tiling_params: list[TilingParam]):
        """生成tiles并分配给section"""
        tiling = CatlassTiling()
        for i, section in enumerate(self.section_list):
            if i < len(tiling_params):
                tiles = tiling.generate_tiles(section)
                section.input_tiles = tiles[0]
                section.output_tiles = tiles[1]

    def time_predict(
            self, shapes: list, tiling_param: list[TilingParam], aicore: AICoreCostModel
    ) -> dict[ResultKey, float]:
        m, k, n = _parse_shape(shapes)
        self.section_list = self._generate_sections(m, k, n, tiling_param)
        self._generate_tiles(tiling_param)

        # 为Vector段设置融合操作
        for tile in self.section_list[1].input_tiles:
            tile.fused_op = self.fused_op
            tile.shape_dict = {self.m_dim: tile.rows, self.n_dim: tile.cols}

        pipeline = InterCorePipeline(self.section_list, aicore)
        ret = pipeline.calculate_sections_time(plot_cv_block=True, use_avg_core=True)
        if m == 1:
            data_size = m * k * n
            time_aic_scalar = 5.6285 + 3.0745 * 1e-7 * data_size
            ret[ResultKey.CORE_TIME] = max(ret[ResultKey.CORE_TIME], time_aic_scalar) * 2
            ret[ResultKey.AIC_TIME] = max(ret[ResultKey.AIC_TIME], time_aic_scalar)
        else:
            time_aic_scalar = 15
            ret[ResultKey.CORE_TIME] += time_aic_scalar
            ret[ResultKey.AIC_TIME] += time_aic_scalar
        return ret