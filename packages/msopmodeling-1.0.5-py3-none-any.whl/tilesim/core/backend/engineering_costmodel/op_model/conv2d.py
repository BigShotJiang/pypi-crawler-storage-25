# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

import math

from core.backend.engineering_costmodel.core.aicore_costmodel import AICoreCostModel
from core.common.entity import DType, ResultKey
from core.backend.engineering_costmodel.core.tiling_and_core_split.tiling_strategy_register import TilingParam
from core.backend.engineering_costmodel.op_model.matmul import Matmul as MatmulOp
from core.common.log_format import logging

# 创建一个日志记录器
logger = logging.getLogger(__name__)


def NCHW_to_NC1HWC0(shape, C0=8):
    N, C, H, W = shape
    C1 = (C + C0 - 1) // C0
    return [N, C1, H, W, C0]


def NCHW_to_FRACTAL_Z(shape, C0=8, N0=16):
    c_out, c_in, k_h, k_w = shape
    N1 = (c_out + N0 - 1) // N0
    C1HW = (k_h * k_w * c_in + C0 - 1) // C0
    return [C1HW, N1, N0, C0]


class NaiveConv2D(MatmulOp):
    def __init__(
            self,
            input_precision: DType,
            output_precision: DType,
    ) -> None:
        super().__init__(input_precision, output_precision)
        self._op_name = "Conv2D"

    def time_predict(
            self,
            shapes: list[list, list],
            tiling_param: list[TilingParam],
            aicore: AICoreCostModel,
            **kwargs
    ) -> dict[ResultKey, float]:
        """
        Naive time prediction considering
        conv2d = im2col + matmul
        and im2col time = 0
        """
        input_shapes, output_shapes = shapes

        batch, C1, h_in, w_in, C0 = input_shapes[0]
        c_in = C0 * C1

        C1HW, N1, N0, C0 = input_shapes[1]
        c_out = N1 * N0
        k2 = C1HW * C0 // c_in
        kernel = int(math.sqrt(k2))
        if kernel * kernel != k2:
            raise ValueError(f"kernel sqrt : {kernel * kernel} not equals with k2")

        bias = input_shapes[2][0]

        N_out, C1_out, h_out, w_out, C0_out = output_shapes
        if N_out != batch:
            raise ValueError("Input and output batch sizes are not the same.")
        if c_out != C0_out * C1_out:
            raise ValueError("Output shape is incorrect.")

        kernel_tuple = (kernel, kernel) if isinstance(kernel, int) else kernel

        k = c_in * kernel_tuple[0] * kernel_tuple[1]
        m = h_out * w_out
        n = c_out

        mm_res = super().time_predict(
            shapes=[[m, k], [k, n]],
            tiling_param=tiling_param,
            aicore=aicore,
        )

        for k in mm_res:
            if k != ResultKey.L2_MISS_RATE:
                mm_res[k] *= batch

        if bias:
            ...  # NEXT -- implement bias here

        return mm_res


if __name__ == "__main__":
    import argparse
    import json

    from core.config.arc_spec import load_arc_config

    parser = argparse.ArgumentParser(description="算子性能预测")
    parser.add_argument(
        "--npu_spec",
        nargs="?",
        type=str,
        help="芯片配置参数",
        default="../api/npu_spec_config/910B1_FP32.json",
    )
    parser.add_argument("--precision", type=str, default="fp32")
    parser.add_argument(
        "--tiling_calculator_output", type=str, default="outputs2d.json"
    )

    args = parser.parse_args()
    if args.precision in ["fp32", "float32"]:
        args.precision = DType.FP32
    elif args.precision in ["fp16", "float16"]:
        args.precision = DType.FP16

    with open(args.tiling_calculator_output) as f:
        conv2d_inputs = json.load(f)

    outputs = []

    for inp in conv2d_inputs:
        base_k = int(32 / args.precision.value[0])
        tiling_data = TilingParam(
            m0=inp["tilingData"]["run"]["mL0"] * 16,
            n0=inp["tilingData"]["run"]["nUbL0cFactor"]
               * inp["tilingData"]["run"]["cubN"]
               * 16,
            k0=inp["tilingData"]["run"]["kL0"] * base_k,
            m1=inp["tilingData"]["run"]["mL0"]
               * inp["tilingData"]["run"]["mAl1Factor"]
               * 16,
            n1=inp["tilingData"]["run"]["nUbL0cFactor"]
               * inp["tilingData"]["run"]["cubN"]
               * inp["tilingData"]["run"]["mAl1Factor"]
               * 16,
            k1a=inp["tilingData"]["run"]["kAl116"] * base_k,
            k1b=inp["tilingData"]["run"]["kAl116"] * base_k,
            w=inp["tilingData"]["run"]["mDim"] * inp["tilingData"]["run"]["batchDim"],
            h=inp["tilingData"]["run"]["nDim"],
            d=1,
            align_tiles=1,
        )
        logger.info("tiling_data is %s", tiling_data)
        arc_config = load_arc_config('910B1')
        cost_model = AICoreCostModel(arc_config)

        NCHW_shape = [inp["tilingData"]["shapes"]["batch"],
                      inp["tilingData"]["shapes"]["cIn"],
                      inp["tilingData"]["shapes"]["hi"],
                      inp["tilingData"]["shapes"]["wi"]]
        input_image_shape = NCHW_to_NC1HWC0(NCHW_shape)
        conv_shape = [inp["tilingData"]["shapes"]["cOut"],
                      inp["tilingData"]["shapes"]["cIn"],
                      inp["tilingData"]["shapes"]["kh"],
                      inp["tilingData"]["shapes"]["kw"]]
        conv_shape = NCHW_to_FRACTAL_Z(conv_shape, C0=8, N0=16)
        bias_shape = [inp["tilingData"]["shapes"]["cOut"]]
        input_shapes = [input_image_shape, conv_shape, bias_shape]

        NCHW_shape = [inp["tilingData"]["shapes"]["batch"],
                      inp["tilingData"]["shapes"]["cOut"],
                      inp["tilingData"]["shapes"]["ho"],
                      inp["tilingData"]["shapes"]["wo"]]
        output_image_shape = NCHW_to_NC1HWC0(NCHW_shape)
        shapes = [input_shapes, output_image_shape]

        output = NaiveConv2D(args.precision, args.precision).time_predict(
            shapes=shapes,
            tiling_param=[tiling_data],
            aicore=cost_model,
        )
        outputs.append({d.value[1]: v for d, v in output.items()})

    with open("output_example.json", "w", encoding="utf-8") as f:
        json.dump(outputs, f, indent=4, ensure_ascii=False)