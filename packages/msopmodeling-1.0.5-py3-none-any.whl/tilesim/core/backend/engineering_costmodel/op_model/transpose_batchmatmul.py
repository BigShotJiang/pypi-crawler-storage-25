# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import copy
import math

from core.backend.engineering_costmodel.core.aicore_costmodel import AICoreCostModel
from core.common.entity import DType, CoreType, ResultKey
from core.backend.engineering_costmodel.core.tiling_and_core_split.tiling_strategy_register import TilingParam
from core.backend.engineering_costmodel.op_model.matmul import Matmul
from core.backend.engineering_costmodel.op_model.basic_operator import BasicOperatorModel
from core.common.log_format import logging

# 创建一个日志记录器
logger = logging.getLogger(__name__)


class TransposeBatchMatMul(BasicOperatorModel):
    def __init__(self, input_precision: DType, output_precision: DType, output_shape, **kwargs):
        super().__init__("TransposeBatchMatMul", CoreType.AIC, input_precision, output_precision)
        self.section_list = None
        self.output_shape = output_shape
        self.scalar = 8
        self.transpose_x1 = False
        self.transpose_out = False

    def _parse_shapes(self, shapes: list):
        if len(shapes[0]) != 3 or len(shapes[1]) != 3:
            raise ValueError("TransposeBatchMatMul input and output dim must be 3")

        if shapes[0][0] != shapes[1][0]:
            # 第一维不相等，说明input_0的batch和m维度交换了位置
            shapes[0][0], shapes[0][1] = shapes[0][1], shapes[0][0]
            self.transpose_x1 = True

        batch_num, m, k = shapes[0]
        batch_num_b, kb, n = shapes[1]
        if batch_num != batch_num_b:
            raise ValueError("batch dim not match")
        if k != kb:
            raise ValueError("k dim not match")

        if self.output_shape[0][1] == batch_num:
            self.transpose_out = True

        return batch_num, m, k, n

    def time_predict(self, shapes: list, tiling_param: list[TilingParam], aicore: AICoreCostModel) -> dict[
        ResultKey, float]:
        """
        TransposeBatchMatMul算子
        :param shapes:   A[batch, m, k], B[batch, k, n]
        :param tiling_param: [cube_tiling]
        :param aicore:
        :return:
        """
        batch_num, m, k, n = self._parse_shapes(shapes)

        # batch 分核
        tiling = copy.copy(tiling_param[0])
        if batch_num >= tiling.core_num:
            # 单核计算的batch数量
            batch_per_core = math.ceil(batch_num / tiling.core_num)
            batch_num = batch_per_core
            tiling.core_num = 1
            tiling.w = 1
            tiling.h = 1
        else:
            # 单个batch有多少核
            core_per_batch = tiling.core_num // batch_num
            batch_num = 1
            tiling.core_num = core_per_batch
            tiling.w = core_per_batch
            tiling.h = 1

        matmul = Matmul(self.input_precision, self.output_precision)
        res = matmul.time_predict([[m, k], [k, n]], tiling_param, aicore)

        for k in ResultKey.time_keys():
            if k in res:
                res[k] *= batch_num
        if self.transpose_x1:
            mte2_transpose_time = res[ResultKey.MTE2_TIME_AIC] * 2
            res[ResultKey.MTE2_TIME_AIC] += mte2_transpose_time
            res[ResultKey.CORE_TIME] += mte2_transpose_time
            res[ResultKey.AIC_TIME] += mte2_transpose_time
        if self.transpose_out:
            fixpipe_transpose_time = res[ResultKey.FIXPIPE_TIME] * 2
            res[ResultKey.FIXPIPE_TIME] += fixpipe_transpose_time
            res[ResultKey.CORE_TIME] += fixpipe_transpose_time
            res[ResultKey.AIC_TIME] += fixpipe_transpose_time
        res[ResultKey.CORE_TIME] += self.scalar
        res[ResultKey.AIC_TIME] += self.scalar
        if m > 64:
            fitting = 0.3085 * m + 32
            res[ResultKey.CORE_TIME] += fitting
            res[ResultKey.AIC_TIME] += fitting
            res[ResultKey.CUBE_TIME] += fitting
        res[ResultKey.CORE_TIME] = max(res[ResultKey.CORE_TIME], 13.85)
        return res