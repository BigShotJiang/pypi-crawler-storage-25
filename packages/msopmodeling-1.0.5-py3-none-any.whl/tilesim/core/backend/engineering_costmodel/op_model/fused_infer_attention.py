# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

import copy
import math
from enum import Enum
from functools import partial

from core.common.entity import DType, CoreType, VecOpType, ResultKey, Section, TensorData, MemLoc
from core.backend.engineering_costmodel.core.aicore_costmodel import AICoreCostModel
from core.backend.engineering_costmodel.core.pipeline.inter_core_pipeline import InterCorePipeline
from core.backend.engineering_costmodel.core.tiling_and_core_split.catlass_tiling import CatlassTiling
from core.backend.engineering_costmodel.core.tiling_and_core_split.tiling_strategy_register import TilingParam
from core.backend.engineering_costmodel.core.vector_op import VectorBasicOp
from core.backend.engineering_costmodel.op_model.basic_operator import BasicOperatorModel
from core.backend.engineering_costmodel.op_model.basic_operator import task_divide


class FaType(Enum):
    IFA = "IFA"
    FA = "FA"
    PFA = "PFA"
    UFA = "UFA"
    DEFAULT = "DEFAULT"


class Layout(Enum):
    BSND = "BSND"
    BNSD = "BNSD"
    TND = "TND"
    BSH = "BSH"
    SBH = "SBH"
    MLA_SBH = "MLA_SBH"
    MLA_BSND = "MLA_BSND"
    BNSD_NBSD = "BNSD_NBSD"
    RINGMLA_TND = "RINGMLA_TND"


def parse_mla_shape(shapes, param=None):
    # PagedMultiLatentAttentionWithCombineCache...
    q_n, q_r, k_n, k_r = shapes[:4]
    if len(q_n) == 3 and len(q_r) == 3 and len(k_n) == 4 and len(k_r) == 4:
        b, n1, n2, s1, s2, d1, d2 = q_n[0], q_n[1], k_n[2], 1, k_n[0], q_n[2] + q_r[2], q_n[2]
    elif len(q_n) == 3 and len(q_r) == 3 and len(k_n) == 3 and len(k_r) == 3:
        b, n1, n2, s1, s2, d1, d2 = q_n[1], 1, 1, q_n[0], k_n[0], q_n[2] + q_r[2], q_n[2]
    else:
        raise ValueError("shape and q are not equal")

    # 当不传入真实的数据的时候，认为实际使用一一半的大小
    param_check = param is not None and isinstance(param, list) and isinstance(param[0], list) and isinstance(
        param[0][0], int)
    if param_check:
        s2 = param[0][0]
    else:
        s2 //= 2

    return [b, n1, n2, s1, s2, d1, d2]


def parse_ring_mla_shape(shapes):
    # NEXT -- 获取入参的seqlen，作为实际的序列长度
    q_n, q_r, k_n, k_r = shapes[:4]
    b, n1, n2, s1, s2, d1, d2 = 1, q_n[1], k_n[1], q_n[0], k_n[0], q_n[2] + q_r[2], k_n[2] + k_r[2]
    return [b, n1, n2, s1, s2, d1, d2]


def parser_shapes(shapes, layout, param=None):
    """将算子原始输入shape解析成仿真所需格式"""

    if layout == Layout.MLA_SBH or layout == Layout.MLA_BSND:
        return parse_mla_shape(shapes, param)

    if layout == Layout.RINGMLA_TND:
        return parse_ring_mla_shape(shapes)

    q, k, v = shapes[0], shapes[1], shapes[2]
    q_rope_dim = 0
    kv_rope_dim = 0
    if len(shapes) > 25 and shapes[24] and shapes[25]:
        q_rope_dim = shapes[24][-1]
        kv_rope_dim = shapes[25][-1]

    if layout == Layout.BSND:
        b, n1, n2, s1, s2, d1, d2 = q[0], q[2], k[2], q[1], k[1], q[-1], v[-1]
    elif layout == Layout.BNSD or layout == Layout.BNSD_NBSD:
        b, n1, n2, s1, s2, d1, d2 = q[0], q[1], k[1], q[2], k[2], q[-1], v[-1]
    elif layout == Layout.TND:
        b, n1, n2, s1, s2, d1, d2 = 1, q[1], k[1], q[0], k[0], q[-1], v[-1]
    elif layout == Layout.BSH:
        b, n1, n2, s1, s2, d1, d2 = q[0], 1, 1, q[1], k[1], q[-1], v[-1]
    elif layout == Layout.SBH:
        b, n1, n2, s1, s2, d1, d2 = q[1], 1, 1, q[0], k[0], q[-1], v[-1]
    else:
        raise ValueError("Invalid input_layout")
    return [b, n1, n2, s1, s2, d1 + q_rope_dim, d2 + kv_rope_dim]


class FusedInferAttentionV4(BasicOperatorModel):

    def __init__(self,
                 input_precision: DType,
                 output_precision: DType,
                 fa_type: str = "DEFAULT",
                 input_layout: str = "BSND",
                 actual_seq_lengths: list[int] = None,
                 actual_seq_lengths_kv: list[int] = None,
                 **kwargs):

        super().__init__("FusedInferAttention", CoreType.MIX, input_precision, output_precision)
        self.fa = FlashAttentionInner(input_precision, output_precision, fa_type, input_layout, actual_seq_lengths,
                                      actual_seq_lengths_kv)
        self.layout = Layout(input_layout)
        self.actual_seq_lengths = actual_seq_lengths

    @staticmethod
    def get_default_tiling_param():
        w, h = 4, 6
        tiling_args = {
            "pfa_mm1": {"m0": 128, "n0": 256, "k0": 64, "m1": 128, "n1": 256, "k1a": 64, "k1b": 64, "w": w, "h": h, },
            "pfa_vec1": {"m0": 0, "n0": 0, "k0": 0, "m1": 128, "n1": 128, "k1a": 0, "k1b": 0, "w": w * 2, "h": h, },
            "pfa_mm2": {"m0": 128, "n0": 128, "k0": 128, "m1": 128, "n1": 128, "k1a": 128, "k1b": 128, "w": w,
                        "h": h, },
            "pfa_vec2": {"m0": 0, "n0": 0, "k0": 0, "m1": 128, "n1": 128, "k1a": 0, "k1b": 0, "w": w * 2, "h": h, },
            "ifa_mm1": {"m0": 16, "n0": 256, "k0": 64, "m1": 16, "n1": 256, "k1a": 64, "k1b": 64, "w": w, "h": h,
                        "d": 1},
            "ifa_vec1": {"m0": 0, "n0": 0, "k0": 0, "m1": 64, "n1": 256, "k1a": 0, "k1b": 0, "w": w * 2, "h": h,
                         "d": 1},
            "ifa_mm2": {"m0": 16, "n0": 128, "k0": 128, "m1": 16, "n1": 128, "k1a": 128, "k1b": 128, "w": w // 2,
                        "h": h // 2, "d": 4},
            "ifa_vec2": {"m0": 0, "n0": 0, "k0": 0, "m1": 128, "n1": 128, "k1a": 0, "k1b": 0, "w": w * 2, "h": h,
                         "d": 1},
        }
        ifa_mm1 = TilingParam(**tiling_args["ifa_mm1"])
        ifa_vec1 = TilingParam(**tiling_args["ifa_vec1"])
        ifa_mm2 = TilingParam(**tiling_args["ifa_mm2"])
        ifa_vec2 = TilingParam(**tiling_args["ifa_vec2"])
        pfa_mm1 = TilingParam(**tiling_args["pfa_mm1"])
        pfa_vec1 = TilingParam(**tiling_args["pfa_vec1"])
        pfa_mm2 = TilingParam(**tiling_args["pfa_mm2"])
        pfa_vec2 = TilingParam(**tiling_args["pfa_vec2"])
        ifa = [ifa_mm1, ifa_vec1, ifa_mm2, ifa_vec2]
        pfa = [pfa_mm1, pfa_vec1, pfa_mm2, pfa_vec2]
        return ifa + pfa

    def time_predict(self, shapes: list, tiling_param: list[TilingParam], aicore: AICoreCostModel) -> dict[
        ResultKey, float]:

        s1 = parser_shapes(shapes=shapes, layout=self.layout)[3]
        if self.actual_seq_lengths:
            s1 = self.actual_seq_lengths[0]
        pfa_tiling_param = tiling_param[:len(tiling_param) // 2]
        ifa_tiling_param = tiling_param[len(tiling_param) // 2:]
        if s1 == 1:  # s1 ==1 will goto increment flash attention else goto prompt flash attention
            self.fa.fa_type = FaType.IFA
            res = self.fa.time_predict(shapes, ifa_tiling_param, aicore)
        else:
            self.fa.fa_type = FaType.PFA
            res = self.fa.time_predict(shapes, pfa_tiling_param, aicore)
        return res


class FlashAttentionInner(BasicOperatorModel):
    SCALE_THRESHOLD = 1000000

    def __init__(self, input_precision: DType,
                 output_precision: DType,
                 fa_type: str = "DEFAULT",
                 layout: str = "BSND",
                 actual_seq_lengths: list[int] = None,
                 actual_seq_lengths_kv: list[int] = None,
                 param: list = None,
                 triu: bool = False,
                 **kwargs
                 ):
        super().__init__("FlashAttentionV2Forward", CoreType.MIX, input_precision, output_precision)
        self.section_list = None
        self.tasks = 1

        self.q_s1_block_num = 1
        if input_precision == DType.FP8:
            self.middle_type_precision = DType.FP16
        else:
            self.middle_type_precision = DType.FP32
        self.flash_decode_flag = False
        self.row, self.col = 'row', 'col'
        self.fa_type = FaType(fa_type)
        self.layout = Layout(layout)
        self.actual_seq_lengths = actual_seq_lengths
        self.actual_seq_lengths_kv = actual_seq_lengths_kv
        self.param = param
        self.triu = triu

    @staticmethod
    def _get_ifa_scale_time(s2):
        # 拟合结果
        def aic_scale_time(x):
            k1, b1 = 0.0007544198929916596, 29.146374712643695
            return k1 * x + b1

        def aiv_scale_time(x):
            k2, b2 = 1.9947156186482524, -3.5327901012062632
            return k2 * math.log(x, math.e) + b2

        return aic_scale_time(s2) * 0.8, aiv_scale_time(s2) * 0.8

    @staticmethod
    def _get_ufa_scale_time(s2):
        # 拟合结果
        def exp_func(x, a, b, c):
            return a * math.exp(b * x) + c

        a1, b1, c1 = 18.62021502233657, 0.1909082605273587, 19.256808792554278
        aic_scale_time = partial(exp_func, a=a1, b=b1, c=c1)
        a2, b2, c2 = 54.786816315744055, 0.04442230987404488, -26.454774035539916
        aiv_scale_time = partial(exp_func, a=a2, b=b2, c=c2)
        return min(aic_scale_time(s2 * 0.01), 50), max(aiv_scale_time(s2 * 0.01), 50)

    def time_predict(self, shapes: list, tiling_param: list[TilingParam], aicore: AICoreCostModel) -> dict[
        ResultKey, float]:
        """
        分成 N1 个attn计算， 每个attn Q = [B*S1, D], K/V = [B*S2, D] ==>
            QK = [B*S1,D, B*S2] - mkn, Softmax = [B*S1,B*S2] - mn,
            PV = [B*S1,B*S2,D] - mnk, output = [B*S1, D] - mk
        :param shapes:   [B, N1, N2, S1, S2, D] 格式
        B - batch size
        N1/N2 - head相关参数，N1 = GQA的组数， N2 = 各组头数
        S1/S2 - sequence len， S1 = Q的seq len， S2 = K/V的seq len
        D - head dim
        input_layout SBH seq batch h=d*n
        :param tiling_param: [cube_tiling, vec_tiling]
        :param aicore:
        """
        aic_core_num = tiling_param[0].core_num
        b, q_n1, kv_n2, q_s1, kv_s2, d1, d2 = parser_shapes(shapes, self.layout, self.param)
        if self.actual_seq_lengths:
            q_s1 = self.actual_seq_lengths[0] if isinstance(self.actual_seq_lengths, list) else self.actual_seq_lengths
        if self.actual_seq_lengths_kv:
            kv_s2 = self.actual_seq_lengths_kv[0] if isinstance(self.actual_seq_lengths_kv, list) else self.actual_seq_lengths_kv
        d = max(d1, d2)
        shapes = b, q_n1, kv_n2, q_s1, kv_s2, d1, d2
        self.__generate_sections(shapes, tiling_param)
        self.__generate_tiles()
        self._register_fused_op_to_tiles(d)
        res = InterCorePipeline(self.section_list, aicore).calculate_sections_time()

        triu_param = 0.5 if self.triu else 1

        for k, _ in res.items():
            if k in ResultKey.time_keys():
                res[k] *= self.tasks * triu_param * math.ceil(self.q_s1_block_num / aic_core_num)

        aic_scale, aiv_scale = 0, 0
        if self.fa_type == FaType.IFA:
            aic_scale, aiv_scale = self._get_ifa_scale_time(kv_s2)
        elif self.fa_type == FaType.UFA:
            aic_scale, aiv_scale = self._get_ufa_scale_time(kv_s2)
        res[ResultKey.CORE_TIME] += aic_scale
        res[ResultKey.AIC_TIME] += aic_scale
        res[ResultKey.AIV_TIME] += aiv_scale

        return res

    def __generate_sections(self, shapes, tiling_param: list[TilingParam]):
        b, q_n1, kv_n2, q_s1, kv_s2, d1, d2 = shapes
        m = q_s1 * q_n1
        # 特殊逻辑，后面修改
        k1 = d1
        k2 = d2
        n = kv_s2  # * kv_n2
        flash_decode_tiling = None

        if q_s1 == 1:
            flash_decode_tiling = self._task_divide_and_check_flash_decode(shapes, tiling_param)
        else:
            if b != 1:
                # if not ifa mul batch
                m *= b
        if m >= 65536:
            # 对m缩放，减少仿真耗时
            self.q_s1_block_num = math.ceil(m / 256)
            m = 256
            for tiling in tiling_param:
                tiling.core_num = 1
        sec_qk = Section(bias=0,
                         core_type=CoreType.AIC,
                         m=m,
                         k=k1,
                         n=n,
                         tiling_param=tiling_param[0],
                         input_precision=self.input_precision,
                         output_precision=self.input_precision)
        sec_softmax_1 = Section(bias=1,
                                core_type=CoreType.AIV,
                                m=m,
                                k=0,
                                n=n,
                                tiling_param=tiling_param[1],
                                input_precision=self.middle_type_precision,
                                output_precision=self.middle_type_precision)
        sec_softmax_1.input_dependency = {0: 0}

        sec_pv = Section(bias=2,
                         core_type=CoreType.AIC,
                         m=m,
                         k=n,
                         n=k2,
                         tiling_param=tiling_param[2],
                         input_precision=self.input_precision,
                         output_precision=self.input_precision,
                         single_tile_output=True if q_s1 == 1 else False)
        sec_pv.input_dependency = {0: 1}

        secs = [sec_qk, sec_softmax_1, sec_pv]
        secs.extend(self.__last_section(m, k2, tiling_param, flash_decode_tiling))
        self.section_list = secs
        self.__compute_tile_round()

    def __last_section(self, m, k2, tiling_param, flash_decode_tiling):
        if self.flash_decode_flag:
            sec_softmax_2 = Section(bias=3,
                                    core_type=CoreType.AIV,
                                    m=m,
                                    k=0,
                                    n=k2,
                                    tiling_param=tiling_param[3],
                                    input_precision=self.middle_type_precision,
                                    output_precision=self.middle_type_precision, )
            sec_softmax_2.input_dependency = {0: 2}
            sec_flash_decode = Section(bias=4,
                                       core_type=CoreType.AIV,
                                       m=m,
                                       k=0,
                                       n=k2,
                                       tiling_param=flash_decode_tiling,
                                       input_precision=self.middle_type_precision,
                                       output_precision=self.output_precision)
            sec_softmax_2.input_dependency = {0: 3}
            return [sec_softmax_2, sec_flash_decode]
        else:
            sec_softmax_2 = Section(bias=3,
                                    core_type=CoreType.AIV,
                                    m=m,
                                    k=0,
                                    n=k2,
                                    tiling_param=tiling_param[3],
                                    input_precision=self.middle_type_precision,
                                    output_precision=self.output_precision, )

            sec_softmax_2.input_dependency = {0: 2}
            return [sec_softmax_2]

    def __compute_tile_round(self):
        core_tiles = []
        for sec in self.section_list:
            tile_nums = sec.m * sec.n / (sec.tiling_param.m1 * sec.tiling_param.n1)
            tile_nums_per_core = tile_nums / sec.tiling_param.core_num
            core_tiles.append(tile_nums_per_core)
        softmax_stage2_core_tile = core_tiles[3]
        for core_tile, sec in zip(core_tiles, self.section_list):
            if softmax_stage2_core_tile > 1:
                sec.tile_round = math.ceil(core_tile / softmax_stage2_core_tile)
            else:
                sec.tile_round = math.ceil(core_tile)

    def __generate_tiles(self):
        """
        分section生成tile
        """
        tiling = CatlassTiling()
        for section in self.section_list:
            tiles = tiling.generate_tiles(section, single_tile_output=section.single_tile_output)
            section.input_tiles = tiles[0]
            section.output_tiles = tiles[1]

    def _register_fused_op_to_tiles(self, blocks_num):
        """
        register fused vectors to tiles in section
        """
        softmax_stage1_first, softmax_stage1_other = self._softmax_stage_1()
        # section 2
        for tile in self.section_list[1].input_tiles:
            if tile.col_start == 0:
                tile.fused_op = softmax_stage1_first
            else:
                tile.fused_op = softmax_stage1_other

            shape_dict = {
                self.row: tile.rows,
                self.col: tile.cols
            }
            tile.shape_dict = shape_dict
        softmax_stage2_first, softmax_stage2_mid, softmax_stage2_last = self._softmax_stage_2()
        # section 4
        for tile in self.section_list[3].input_tiles:
            if tile.col_start == 0:
                # 跳过第一个
                tile.fused_op = softmax_stage2_first
            elif tile.col_start + tile.cols >= blocks_num:
                tile.fused_op = softmax_stage2_last
            else:
                tile.fused_op = softmax_stage2_mid

            shape_dict = {
                self.row: tile.rows,
                self.col: tile.cols
            }
            tile.shape_dict = shape_dict
        # flash decode
        if self.flash_decode_flag:
            flash_decode = self._softmax_inter_core_reduce()
            for tile in self.section_list[-1].input_tiles:
                tile.fused_op = flash_decode
                shape_dict = {
                    self.row: tile.rows,
                    self.col: tile.cols
                }
                tile.shape_dict = shape_dict

    def _softmax_stage_1(self):
        """
        softmax stage 1:
            first loop fused vec: comb_softmax_1_first
            other loops fused vec: comb_softmax_1
        """
        sec2_s1_s2_gm = TensorData("sec2_s1_s2_gm", DType.FP32, [self.row, self.col], MemLoc.GM)
        sec2_s1_s2_ub = TensorData("sec2_s1_s2_ub", DType.FP32, [self.row, self.col], MemLoc.UB)
        sec2_s1_1_ub = TensorData("sec2_s1_1_ub", DType.FP32, [self.row, 1], MemLoc.UB)
        sec2_s1_8_ub = TensorData("sec2_s1_8_ub", DType.FP32, [self.row, 8], MemLoc.UB)

        # section 1
        comb_softmax_1_first = [  # without pse and mask
            VectorBasicOp(VecOpType.VMUL, [sec2_s1_s2_gm], [sec2_s1_s2_ub]),
            VectorBasicOp(VecOpType.VCGMAX, [sec2_s1_s2_ub], [sec2_s1_1_ub]),
            VectorBasicOp(VecOpType.BRCB, [sec2_s1_1_ub], [sec2_s1_8_ub]),
            VectorBasicOp(VecOpType.VSUB, [sec2_s1_s2_ub], [sec2_s1_s2_ub]),
            VectorBasicOp(VecOpType.VEXP, [sec2_s1_s2_ub], [sec2_s1_s2_ub, sec2_s1_s2_gm]),
            VectorBasicOp(VecOpType.VCGADD, [sec2_s1_s2_ub], [sec2_s1_1_ub]),
            VectorBasicOp(VecOpType.BRCB, [sec2_s1_1_ub], [sec2_s1_8_ub])
        ]
        # section 2
        comb_softmax_1 = [
            VectorBasicOp(VecOpType.VMUL, [sec2_s1_s2_gm], [sec2_s1_s2_ub]),
            VectorBasicOp(VecOpType.VCGMAX, [sec2_s1_s2_ub], [sec2_s1_1_ub]),
            VectorBasicOp(VecOpType.BRCB, [sec2_s1_1_ub], [sec2_s1_8_ub]),
            VectorBasicOp(VecOpType.VMAX, [sec2_s1_8_ub, sec2_s1_8_ub], [sec2_s1_8_ub]),

            VectorBasicOp(VecOpType.VSUB, [sec2_s1_8_ub, sec2_s1_8_ub], [sec2_s1_8_ub]),
            VectorBasicOp(VecOpType.VEXP, [sec2_s1_8_ub], [sec2_s1_8_ub]),
            VectorBasicOp(VecOpType.VMUL, [sec2_s1_8_ub, sec2_s1_8_ub], [sec2_s1_8_ub]),

            VectorBasicOp(VecOpType.VSUB, [sec2_s1_s2_ub, sec2_s1_s2_ub], [sec2_s1_s2_ub]),
            VectorBasicOp(VecOpType.VEXP, [sec2_s1_s2_ub], [sec2_s1_s2_ub, sec2_s1_s2_gm]),
            VectorBasicOp(VecOpType.VCGADD, [sec2_s1_s2_ub], [sec2_s1_1_ub]),
            VectorBasicOp(VecOpType.BRCB, [sec2_s1_1_ub], [sec2_s1_8_ub]),

            VectorBasicOp(VecOpType.VADD, [sec2_s1_8_ub, sec2_s1_8_ub], [sec2_s1_8_ub])
        ]
        return comb_softmax_1_first, comb_softmax_1

    def _softmax_stage_2(self):
        sec4_s1_d2_gm = TensorData("sec4_s1_d2_gm", DType.FP32, [self.row, self.col], MemLoc.GM)
        sec4_s1_d2_ub = TensorData("sec4_s1_d2_ub", DType.FP32, [self.row, self.col], MemLoc.UB)

        comb_softmax_2_first = [VectorBasicOp(VecOpType.NULL_OP, [sec4_s1_d2_gm], [sec4_s1_d2_ub])]
        comb_softmax_2_mid = [
            VectorBasicOp(VecOpType.VMUL, [sec4_s1_d2_ub, sec4_s1_d2_ub], [sec4_s1_d2_ub]),
            VectorBasicOp(VecOpType.VADD, [sec4_s1_d2_gm, sec4_s1_d2_ub], [sec4_s1_d2_ub])
        ]
        comb_softmax_2_last = [
            VectorBasicOp(VecOpType.VMUL, [sec4_s1_d2_ub, sec4_s1_d2_ub], [sec4_s1_d2_ub]),
            VectorBasicOp(VecOpType.VADD, [sec4_s1_d2_gm, sec4_s1_d2_ub], [sec4_s1_d2_ub]),
            VectorBasicOp(VecOpType.VDIV, [sec4_s1_d2_ub, sec4_s1_d2_ub], [sec4_s1_d2_gm])
        ]
        return comb_softmax_2_first, comb_softmax_2_mid, comb_softmax_2_last

    def _softmax_inter_core_reduce(self):
        sec4_s1_d2_gm = TensorData("sec4_s1_d2_gm", DType.FP32, [self.row, self.col], MemLoc.GM)
        sec4_s1_d2_ub = TensorData("sec4_s1_d2_ub", DType.FP32, [self.row, self.col], MemLoc.UB)

        flash_decode = [
            VectorBasicOp(VecOpType.VMAX, [sec4_s1_d2_gm], [sec4_s1_d2_ub]),
            VectorBasicOp(VecOpType.VSUB, [sec4_s1_d2_ub], [sec4_s1_d2_ub]),
            VectorBasicOp(VecOpType.VEXP, [sec4_s1_d2_ub], [sec4_s1_d2_ub]),
            VectorBasicOp(VecOpType.VMUL, [sec4_s1_d2_ub], [sec4_s1_d2_ub]),
            VectorBasicOp(VecOpType.VADD, [sec4_s1_d2_ub], [sec4_s1_d2_ub]),
            VectorBasicOp(VecOpType.VDIV, [sec4_s1_d2_ub], [sec4_s1_d2_ub]),
            VectorBasicOp(VecOpType.VMUL, [sec4_s1_d2_ub], [sec4_s1_d2_ub]),
            VectorBasicOp(VecOpType.VMUL, [sec4_s1_d2_ub], [sec4_s1_d2_ub]),
            VectorBasicOp(VecOpType.VADD, [sec4_s1_d2_ub], [sec4_s1_d2_gm]),
        ]
        return flash_decode

    def _task_divide_and_check_flash_decode(self, shapes, tiling_param: list[TilingParam]):
        b, q_n1, kv_n2, q_s1, kv_s2, d1, d2 = shapes
        aic_num = 24
        flash_decode_tiling = None

        if (b * kv_n2) < aic_num * 0.4:
            def split_bns(core_num):  # enable flash decode
                bn = b * kv_n2
                split_kv_part = core_num // bn
                max_actual_seq = kv_s2
                while ((max_actual_seq / split_kv_part) < 512) and (split_kv_part > 1):  # 源代码注释// 512, 经验值
                    split_kv_part -= 1
                used_core_num = split_kv_part * bn
                # NEXT -- 开启SplitKV 切分S2时多出来重复的对Q搬运L0A 需要处理
                return used_core_num

            num_tasks = split_bns(aic_num)
            self.flash_decode_flag = True
            flash_decode_tiling = copy.deepcopy(tiling_param[-1])
            flash_decode_task_num = task_divide(flash_decode_tiling, b * kv_n2)
            # NEXT -- 开启后  flash decode task 切分为b*n2任务 需要处理
        else:
            num_tasks = b * kv_n2
        for t in tiling_param:
            self.tasks = task_divide(t, num_tasks)
        return flash_decode_tiling