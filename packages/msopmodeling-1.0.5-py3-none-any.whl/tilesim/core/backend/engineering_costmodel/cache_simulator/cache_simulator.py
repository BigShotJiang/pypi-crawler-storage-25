# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from abc import ABC
from typing import List, Dict, Tuple

from core.backend.backend_entity.backend_entity import TensorEntity
from core.backend.engineering_costmodel.cache_simulator.replacement_policy import ReplacementPolicy, FIFOPolicy, LRUPolicy, PseudoLRUPolicy, ReplacementPolicyType


class CacheSimulator(ABC):
    """Cache模拟器抽象基类"""

    def __init__(self, capacity_bytes: int, policy: ReplacementPolicy):
        """
        初始化Cache模拟器

        Args:
            capacity_bytes: Cache容量（字节）
            policy: 替换策略
        """
        self._capacity = capacity_bytes
        self._policy = policy
        self._cached_tensors: Dict[str, TensorEntity] = {}
        self._current_size = 0

        # 统计信息
        self._stats = {
            'total_accesses': 0,
            'hits': 0,
            'misses': 0,
            'evictions': 0,
            'total_hit_bytes': 0,
            'total_miss_bytes': 0
        }

    @property
    def capacity(self) -> int:
        """Cache容量"""
        return self._capacity

    @property
    def current_size(self) -> int:
        """当前使用的容量"""
        return self._current_size

    @property
    def utilization(self) -> float:
        """容量利用率"""
        return self._current_size / self._capacity if self._capacity > 0 else 0

    def access(self, tensor: TensorEntity) -> Tuple[int, int]:
        """
        访问Cache，尝试获取张量

        Args:
            tensor: 要访问的张量

        Returns:
            (命中的字节数, 未命中的字节数)
        """
        self._stats['total_accesses'] += 1

        hit_bytes = 0
        miss_bytes = tensor.get_size()

        # 检查是否有重叠的张量
        for cached_name, cached_tensor in self._cached_tensors.items():
            if cached_name != tensor.name:
                # NEXT -- 判断逻辑需要修改
                continue
            overlap_size = cached_tensor.get_overlap_size(tensor)
            if overlap_size > 0:
                hit_bytes += overlap_size
                # 更新访问记录
                self._policy.on_access(cached_name)

        miss_bytes -= hit_bytes

        # 更新统计信息
        if hit_bytes > 0:
            self._stats['hits'] += 1
            self._stats['total_hit_bytes'] += hit_bytes
        if miss_bytes > 0:
            self._stats['misses'] += 1
            self._stats['total_miss_bytes'] += miss_bytes

        # 如果完全命中，不需要插入
        if miss_bytes == 0:
            return hit_bytes, miss_bytes

        # 尝试插入未命中的部分
        self._insert_tensor(tensor)

        return hit_bytes, miss_bytes

    def _insert_tensor(self, tensor: TensorEntity) -> None:
        """
        插入张量到Cache中

        Args:
            tensor: 要插入的张量
        """
        tensor_size = tensor.get_size()

        # 如果张量已存在，先移除
        if tensor.name in self._cached_tensors:
            self._remove_tensor(tensor.name)

        # 腾出空间
        while self._current_size + tensor_size > self._capacity:
            victim_name = self._policy.get_victim()
            if victim_name is None:
                break
            self._remove_tensor(victim_name)
            self._stats['evictions'] += 1

        # 如果还是放不下，说明单个张量就超过容量，不插入
        if tensor_size > self._capacity:
            return

        # 插入张量
        self._cached_tensors[tensor.name] = tensor
        self._current_size += tensor_size
        self._policy.on_insert(tensor.name)

    def _remove_tensor(self, tensor_name: str) -> None:
        """
        从Cache中移除张量

        Args:
            tensor_name: 要移除的张量名称
        """
        if tensor_name in self._cached_tensors:
            tensor = self._cached_tensors[tensor_name]
            self._current_size -= tensor.get_size()
            del self._cached_tensors[tensor_name]
            self._policy.on_remove(tensor_name)

    def get_stats(self) -> Dict:
        """获取统计信息"""
        stats = self._stats.copy()
        if stats['total_accesses'] > 0:
            stats['hit_rate'] = stats['hits'] / stats['total_accesses']
            stats['miss_rate'] = stats['misses'] / stats['total_accesses']
        else:
            stats['hit_rate'] = 0.0
            stats['miss_rate'] = 0.0

        if stats['total_hit_bytes'] + stats['total_miss_bytes'] > 0:
            stats['byte_hit_rate'] = stats['total_hit_bytes'] / (
                    stats['total_hit_bytes'] + stats['total_miss_bytes']
            )
        else:
            stats['byte_hit_rate'] = 0.0

        return stats

    def reset(self) -> None:
        """重置Cache状态"""
        self._cached_tensors.clear()
        self._current_size = 0
        self._policy.reset()
        self._stats = {
            'total_accesses': 0,
            'hits': 0,
            'misses': 0,
            'evictions': 0,
            'total_hit_bytes': 0,
            'total_miss_bytes': 0
        }

    def get_cached_tensors(self) -> List[str]:
        """获取当前缓存的所有张量名称"""
        return list(self._cached_tensors.keys())


class FIFOCache(CacheSimulator):
    """FIFO策略的Cache"""

    def __init__(self, capacity_bytes: int):
        super().__init__(capacity_bytes, FIFOPolicy())


class LRUCache(CacheSimulator):
    """LRU策略的Cache"""

    def __init__(self, capacity_bytes: int):
        super().__init__(capacity_bytes, LRUPolicy())


class PseudoLRUCache(CacheSimulator):
    """pLRU策略的Cache"""

    def __init__(self, capacity_bytes: int):
        super().__init__(capacity_bytes, PseudoLRUPolicy())


def create_cache(capacity_bytes: int, policy_type: ReplacementPolicyType = ReplacementPolicyType.P_LRU) -> CacheSimulator:
    """
    工厂函数：创建指定策略的Cache

    Args:
        capacity_bytes: Cache容量（字节）
        policy_type: 策略类型 ('FIFO', 'LRU', 'pLRU')

    Returns:
        CacheSimulator实例
    """

    if policy_type == ReplacementPolicyType.FIFO:
        return FIFOCache(capacity_bytes)
    elif policy_type == ReplacementPolicyType.LRU:
        return LRUCache(capacity_bytes)
    elif policy_type == ReplacementPolicyType.P_LRU:
        return PseudoLRUCache(capacity_bytes)
    else:
        raise ValueError(f"不支持的策略类型: {policy_type}")
