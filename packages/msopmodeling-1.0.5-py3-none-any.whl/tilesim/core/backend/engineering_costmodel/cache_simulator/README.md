# Cache模拟器

一个高效的、可扩展的Cache模拟器实现，支持多种替换策略（FIFO、LRU、pLRU），特别适用于张量数据的缓存模拟。

## 主要特性

### ✨ 核心功能
- **抽象类设计**：便于扩展和继承新的替换策略
- **多种替换策略**：内置FIFO、LRU、pLRU三种策略
- **张量重叠检测**：智能识别张量间的数据重叠，精确计算命中率
- **多种数据类型**：支持FP32、FP16、INT32、INT16、INT8等数据类型
- **详细统计信息**：提供命中率、字节命中率、驱逐次数等统计数据
- **高性能实现**：使用高效的数据结构，适合大规模模拟

### 🎯 适用场景
- GPU/NPU内存层次结构模拟
- 深度学习模型推理中的张量缓存分析
- 存储系统性能评估
- Cache替换策略研究

## 架构设计

### 类层次结构

```
ReplacementPolicy (抽象基类)
├── FIFOPolicy (先进先出)
├── LRUPolicy (最近最少使用)
└── pLRUPolicy (伪LRU)

CacheSimulator (抽象基类)
├── FIFOCache
├── LRUCache
└── pLRUCache
```

### 核心组件

1. **DataType**: 数据类型枚举，定义了各种精度格式及其字节大小
2. **Tensor**: 张量数据结构，包含name、dtype、shape、offset等信息
3. **ReplacementPolicy**: 替换策略抽象基类
4. **CacheSimulator**: Cache模拟器抽象基类

## 快速开始

### 基本使用

```python
from cache_simulator import LRUCache, Tensor, DataType

# 创建一个1MB的LRU Cache
cache = LRUCache(capacity_bytes=1024 * 1024)

# 创建张量
tensor = Tensor(
    name="tensor_1",
    dtype=DataType.FP32,
    shape=[100, 100],
    raw_name="global_tensor",
    raw_shape=[1000, 1000],
    offset=[0, 0]
)

# 访问Cache
hit_bytes, miss_bytes = cache.access(tensor)
print(f"命中: {hit_bytes} bytes, 未命中: {miss_bytes} bytes")

# 查看统计信息
stats = cache.get_stats()
print(f"命中率: {stats['hit_rate']:.2%}")
```

### 使用工厂函数

```python
from cache_simulator import create_cache

# 创建不同策略的Cache
fifo_cache = create_cache(capacity_bytes=1024*1024, policy_type='FIFO')
lru_cache = create_cache(capacity_bytes=1024*1024, policy_type='LRU')
plru_cache = create_cache(capacity_bytes=1024*1024, policy_type='pLRU')
```

## 详细文档

### Tensor类

张量是Cache中存储的基本单元。

```python
tensor = Tensor(
    name="unique_id",        # 唯一标识符
    dtype=DataType.FP32,     # 数据类型
    shape=[100, 200],        # 当前张量形状
    raw_name="parent",       # 父张量名称
    raw_shape=[1000, 1000],  # 父张量形状
    offset=[50, 100]         # 在父张量中的偏移
)
```

**重要方法**：
- `get_size_bytes()`: 计算张量占用的字节数
- `overlaps_with(other)`: 检查是否与另一个张量重叠
- `get_overlap_size(other)`: 计算重叠区域的字节数

### CacheSimulator类

所有Cache的基类，提供统一的接口。

**主要方法**：

```python
# 访问张量，返回(命中字节数, 未命中字节数)
hit_bytes, miss_bytes = cache.access(tensor)

# 获取统计信息
stats = cache.get_stats()
# 返回: {
#     'total_accesses': 总访问次数,
#     'hits': 命中次数,
#     'misses': 未命中次数,
#     'evictions': 驱逐次数,
#     'total_hit_bytes': 总命中字节数,
#     'total_miss_bytes': 总未命中字节数,
#     'hit_rate': 命中率,
#     'miss_rate': 未命中率,
#     'byte_hit_rate': 字节命中率
# }

# 获取当前缓存的张量列表
cached_tensors = cache.get_cached_tensors()

# 重置Cache
cache.reset()

# 获取容量利用率
utilization = cache.utilization
```

### 替换策略

#### FIFO (First-In-First-Out)
- 最简单的替换策略
- 先进入Cache的数据先被替换
- 访问不改变数据的位置

```python
cache = FIFOCache(capacity_bytes=1024*1024)
```

#### LRU (Least Recently Used)
- 替换最久未使用的数据
- 每次访问都会更新数据的使用时间
- 使用OrderedDict实现，O(1)复杂度

```python
cache = LRUCache(capacity_bytes=1024*1024)
```

#### pLRU (pseudo-LRU)
- LRU的近似算法
- 使用树形结构减少开销
- 适合大规模Cache模拟

```python
cache = pLRUCache(capacity_bytes=1024*1024)
```

## 高级特性

### 张量重叠检测

Cache能够智能识别张量间的数据重叠，这对于处理子张量访问非常重要。

```python
# 父张量: [1000, 1000]
tensor_a = Tensor(
    name="a",
    dtype=DataType.FP32,
    shape=[50, 50],
    raw_name="global",
    raw_shape=[1000, 1000],
    offset=[0, 0]  # 左上角
)

tensor_b = Tensor(
    name="b",
    dtype=DataType.FP32,
    shape=[50, 50],
    raw_name="global",
    raw_shape=[1000, 1000],
    offset=[25, 25]  # 有25x25的重叠
)

# 检查重叠
overlaps = tensor_a.overlaps_with(tensor_b)  # True
overlap_size = tensor_a.get_overlap_size(tensor_b)  # 2500 bytes
```

### 扩展自定义策略

继承`ReplacementPolicy`类实现自定义策略：

```python
from cache_simulator import ReplacementPolicy, CacheSimulator

class MyCustomPolicy(ReplacementPolicy):
    def __init__(self):
        super().__init__()
        # 初始化自定义数据结构
    
    def on_access(self, tensor_name: str) -> None:
        # 处理访问事件
        pass
    
    def on_insert(self, tensor_name: str) -> None:
        # 处理插入事件
        pass
    
    def on_remove(self, tensor_name: str) -> None:
        # 处理移除事件
        pass
    
    def get_victim(self) -> Optional[str]:
        # 返回要被替换的张量名称
        pass
    
    def reset(self) -> None:
        # 重置策略状态
        pass

# 创建使用自定义策略的Cache
class MyCustomCache(CacheSimulator):
    def __init__(self, capacity_bytes: int):
        super().__init__(capacity_bytes, MyCustomPolicy())
```

## 性能优化

### 时间复杂度
- **FIFO**: O(1) 访问, O(1) 插入/删除
- **LRU**: O(1) 访问, O(1) 插入/删除
- **pLRU**: O(log n) 访问, O(n) 插入/删除

### 空间复杂度
- **FIFO**: O(n) - 存储队列
- **LRU**: O(n) - 存储有序字典
- **pLRU**: O(n) - 存储列表和树结构

### 优化建议
1. 对于大规模模拟，使用pLRU减少开销
2. 批量访问时考虑预分配内存
3. 定期调用`reset()`清理统计数据

## 示例场景

### 场景1: 深度学习推理优化

```python
# 模拟GPU缓存，分析不同batch size的影响
cache = LRUCache(capacity_bytes=8 * 1024 * 1024 * 1024)  # 8GB

for layer_idx in range(num_layers):
    for batch_idx in range(num_batches):
        # 创建activation张量
        activation = Tensor(
            name=f"act_{layer_idx}_{batch_idx}",
            dtype=DataType.FP16,
            shape=[batch_size, hidden_dim],
            raw_name=f"layer_{layer_idx}_output",
            raw_shape=[total_samples, hidden_dim],
            offset=[batch_idx * batch_size, 0]
        )
        
        hit, miss = cache.access(activation)
        # 分析命中情况...
```

### 场景2: 对比不同替换策略

```python
# 创建多个Cache进行对比
policies = {
    'FIFO': FIFOCache(capacity),
    'LRU': LRUCache(capacity),
    'pLRU': pLRUCache(capacity)
}

# 执行相同的访问序列
for tensor in access_sequence:
    for name, cache in policies.items():
        cache.access(tensor)

# 对比结果
for name, cache in policies.items():
    stats = cache.get_stats()
    print(f"{name}: 命中率={stats['hit_rate']:.2%}, "
          f"字节命中率={stats['byte_hit_rate']:.2%}")
```

## 测试

运行示例代码：

```bash
python example_usage.py
```

这将运行5个示例场景，展示Cache模拟器的各种功能。

## 依赖

- Python 3.7+
- NumPy

## License

MIT License

## 贡献

欢迎提交Issue和Pull Request！

## 注意事项

1. **张量命名**: 确保每个张量的name是唯一的
2. **raw_name**: 相同raw_name的张量才会进行重叠检测
3. **offset验证**: offset、shape和raw_shape的维度必须一致
4. **容量限制**: 如果单个张量大于Cache容量，将不会被缓存

## 常见问题

**Q: 如何处理不同raw_name的张量？**
A: 不同raw_name的张量被视为完全独立，不会检测重叠。

**Q: Cache满了会怎样？**
A: 根据替换策略自动驱逐数据，统计信息中的evictions字段会记录驱逐次数。

**Q: 可以动态改变Cache容量吗？**
A: 当前实现不支持，建议重新创建Cache实例。

**Q: 如何选择合适的替换策略？**
A: 
- FIFO: 简单场景，访问模式规律
- LRU: 局部性强的访问模式
- pLRU: 大规模模拟，对精确度要求不高

## 更新日志

### v1.0.0 (2024-01)
- 初始版本
- 支持FIFO、LRU、pLRU三种策略
- 实现张量重叠检测
- 提供详细统计信息