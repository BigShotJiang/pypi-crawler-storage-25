# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import math
from abc import ABC, abstractmethod
from copy import copy
from dataclasses import dataclass
from enum import Enum

from core.backend.backend_entity.backend_context import EvalCtxEntity, bind_version


class ExprFunc(Enum):
    MIN = 'min'
    MAX = 'max'
    FLOOR = 'floor'
    CEIL = 'ceil'
    STR_CON = 'str_con'

    @staticmethod
    def from_str(func: str):
        for e in ExprFunc:
            if e.value == func:
                return e
        raise Exception(f'unknown func: {func}')


class ExprOpEnum(Enum):
    ADD = '+'
    SUB = '-'
    MUL = '*'
    DIV = '/'
    FLOORDIV = '//'
    MOD = '%'
    LT = '<'
    LE = '<='
    GT = '>'
    GE = '>='
    EQ = '=='
    NE = '!='
    AND = 'and'
    OR = 'or'
    NOT = 'not'

    @staticmethod
    def from_str(op: str):
        for e in ExprOpEnum:
            if e.value == op:
                return e
        raise Exception(f'unknown op: {op}')


class MathEntity(ABC):

    def __init__(self):
        pass


class ExprEntity(MathEntity):
    @abstractmethod
    def eval(self, ctx: EvalCtxEntity):
        pass


@dataclass
class RangeEntity(MathEntity):
    start: ExprEntity | int
    end: ExprEntity | int
    step: ExprEntity | int

    def eval(self, ctx: EvalCtxEntity):
        new_range = copy(self)
        new_range.start = int(self.start.eval(ctx))
        new_range.end = int(self.end.eval(ctx))
        new_range.step = int(self.step.eval(ctx))
        return new_range

    def evaluated(self):
        return isinstance(self.start, int) and isinstance(self.end, int) and isinstance(self.step, int)


@dataclass(frozen=True)
class ConstExprEntity(ExprEntity):
    value: int | float | bool

    def eval(self, ctx: EvalCtxEntity):
        return self.value


@dataclass(frozen=True)
class VarExprEntity(ExprEntity):
    name: str

    def eval(self, ctx: EvalCtxEntity):
        use_activated_name, var_version = ctx.get_version_by_phi(self.name)
        # Handle both old int format and new tuple format
        if self.name.startswith('%'):  # ttir tensor/scalar
            name = self.name
        elif use_activated_name:
            # Phi function is activated, use the activated name directly
            name = var_version
        else:
            name = bind_version(self.name, var_version)
        if name not in ctx.env:
            raise Exception(f'undefined variable: {name}')
        return ctx.env.get(name)


@dataclass(frozen=True)
class BinaryExprEntity(ExprEntity):
    # '+', '-', '*', '/', '//', '%'
    op: ExprOpEnum
    lhs: ExprEntity
    rhs: ExprEntity

    def eval(self, ctx: EvalCtxEntity):
        l = self.lhs.eval(ctx)
        r = self.rhs.eval(ctx)
        match self.op:
            case ExprOpEnum.ADD:
                return l + r
            case ExprOpEnum.SUB:
                return l - r
            case ExprOpEnum.MUL:
                return l * r
            case ExprOpEnum.DIV:
                return l / r
            case ExprOpEnum.FLOORDIV:
                return l // r
            case ExprOpEnum.MOD:
                return l % r
        raise Exception(f'unknown op: {self.op}')


@dataclass(frozen=True)
class CompareExprEntity(ExprEntity):
    op: ExprOpEnum  # '<', '<=', '>', '=='
    lhs: ExprEntity
    rhs: ExprEntity

    def eval(self, ctx: EvalCtxEntity):
        l = self.lhs.eval(ctx)
        r = self.rhs.eval(ctx)
        match self.op:
            case ExprOpEnum.LT:
                return l < r
            case ExprOpEnum.LE:
                return l <= r
            case ExprOpEnum.GT:
                return l > r
            case ExprOpEnum.GE:
                return l >= r
            case ExprOpEnum.EQ:
                return l == r
            case ExprOpEnum.NE:
                return l != r
        raise Exception(f'unknown compare op: {self.op}')


@dataclass(frozen=True)
class LogicalExprEntity(ExprEntity):
    op: ExprOpEnum  # 'and', 'or', 'not'
    operands: list[ExprEntity]

    def eval(self, ctx: EvalCtxEntity):
        if self.op == ExprOpEnum.AND:
            for op in self.operands:
                if not op.eval(ctx):
                    return False
            return True
        elif self.op == ExprOpEnum.OR:
            for op in self.operands:
                if op.eval(ctx):
                    return True
            return False
        elif self.op == ExprOpEnum.NOT:
            return not self.operands[0].eval(ctx)
        else:
            raise Exception(f'unknown logical op: {self.op}')


@dataclass(frozen=True)
class CallExprEntity(ExprEntity):
    func: ExprFunc  # 'min', 'max', 'floor', 'ceil'
    args: list[ExprEntity]

    def eval(self, ctx: EvalCtxEntity):
        match self.func:
            case ExprFunc.MIN:
                return min(op.eval(ctx) for op in self.args)
            case ExprFunc.MAX:
                return max(op.eval(ctx) for op in self.args)
            case ExprFunc.FLOOR:
                return int(self.args[0].eval(ctx))
            case ExprFunc.CEIL:
                return math.ceil(self.args[0].eval(ctx))
            case ExprFunc.STR_CON:
                return ''.join(str(op.eval(ctx)) for op in self.args)
        raise Exception(f'unknown func: {self.func}')
