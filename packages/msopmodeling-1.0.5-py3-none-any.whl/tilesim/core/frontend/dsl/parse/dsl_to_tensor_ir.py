# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import ast
from copy import copy

from core.common.entity import DType, MemLoc
from core.frontend.dsl.parse.dsl_to_expr_ir import expr_parse, slice_parse
from core.frontend.dsl.parse.ssa_env import SSAEnv
from core.frontend.ir.core.ir_entity import TensorIR
from core.frontend.ir.core.ir_math import ExprIR, VarExprIR


# -----------------------------------------
# Tensor属性转换工具方法
# -----------------------------------------
def _attr_list_parse(elts: list) -> list:
    """张量定义中的多个属性，构成了一个list，转换逻辑"""
    res = []
    for elt in elts:
        res.append(_attr_parse(elt))
    return res


def _attr_parse(node) -> ExprIR | DType | MemLoc:
    """张量定义中的：shape/mem_loc/dtype的转换"""
    if isinstance(node, ast.Name):
        attr = VarExprIR(node.id)
    elif isinstance(node, ast.Attribute):
        if node.value.id == 'MemLoc':
            return MemLoc.from_str(node.attr)
        if node.value.id == 'DType':
            return DType.from_str(node.attr)
        raise ValueError(f"Unsupported attr: {ast.dump(node)}")
    elif isinstance(node, ast.expr):
        attr = expr_parse(node)
    else:
        attr = node.value
    return attr


# -----------------------------------------
# 三类张量转换的逻辑：
# 一、def: q = T.Tensor(shape = [n,,m]....)
# 二、view_range : q_tile = q[i:i+n, j:j+m]
# 三、view_op: q_tile = q.view([n, m])
# -----------------------------------------
def _tensor_parse_by_tensor_def(call: ast.Call, tensor_name: str) -> TensorIR:
    """解析函数定义中的tensor类型入参： def kernel(X: Tensor(shape=[128,128], dtype="FP32")):"""
    kwargs = {}
    for kw in call.keywords:
        if kw.arg == "shape":
            kwargs[kw.arg] = _attr_list_parse(kw.value.elts)
        elif kw.arg == "dtype" or kw.arg == "mem_loc":
            kwargs[kw.arg] = _attr_parse(kw.value)

    tensor_ir = TensorIR(
        name=tensor_name,
        shape=kwargs["shape"],
        dtype=kwargs["dtype"],
        mem_loc=kwargs["mem_loc"]
    )
    return tensor_ir


def _tensor_parse_by_view_range(node: ast.Subscript, env: SSAEnv, local_tensor_name: str = None) -> TensorIR:
    """解析张量定义： X = A[1:2, 2:3]"""
    global_tensor_name = node.value.id
    global_tensor = env.read_var(global_tensor_name)
    if not isinstance(global_tensor, TensorIR):
        raise ValueError(f"Global tensor {global_tensor_name} is not a TensorIR.")
    dims = []
    for dim in node.slice.dims:
        dim_range = slice_parse(dim)
        dims.append(dim_range)
    local_tensor = TensorIR(
        name=local_tensor_name,
        shape=dims,
        dtype=global_tensor.dtype,
        mem_loc=global_tensor.mem_loc,
        raw_tensor=global_tensor
    )
    return local_tensor


def _tensor_parse_by_view_op(node: ast.Call, env: SSAEnv, local_tensor_name: str = None) -> TensorIR:
    """解析张量定义： X = A.view([128, 128])"""
    args = node.args
    if len(args) != 1:
        raise ValueError("Unsupported tensor view operation.")

    global_tensor_name = node.func.value.id
    global_tensor = env.read_var(global_tensor_name)
    if not isinstance(global_tensor, TensorIR):
        raise ValueError(f"Global tensor {global_tensor_name} is not a TensorIR.")

    dims = []
    dim_elts = args[0].elts
    for dim in dim_elts:
        dims.append(expr_parse(dim))

    local_tensor = TensorIR(
        name=local_tensor_name,
        shape=dims,
        dtype=global_tensor.dtype,
        mem_loc=global_tensor.mem_loc,
        raw_tensor=global_tensor
    )
    return local_tensor


# -----------------------------------------
# 对外暴露的张量转换方法
# -----------------------------------------
def tensor_parse(node: ast.Assign | ast.arg, env: SSAEnv = None) -> TensorIR:
    """解析的单独一行的张量赋值语句"""
    if isinstance(node, ast.arg):
        tensor_name = node.arg
        tensor_body = node.annotation
    elif isinstance(node, ast.Assign):
        tensor_name = node.targets[0].id
        tensor_body = node.value
    else:
        raise ValueError(f"Unsupported tensor definition: {ast.dump(node)}")

    return tensor_parse_inline(tensor_body, env, tensor_name)


def tensor_parse_inline(node: ast.Call | ast.Subscript | ast.arg | ast.Name, env: SSAEnv,
                        tensor_name: str) -> TensorIR:
    """解析行内的张量赋值，比如T.TileOp.copy(tile, global_tensor[i:i+m, j:j+m])"""

    # 直接以名称引用
    if isinstance(node, ast.arg) or isinstance(node, ast.Name):
        tensor = env.read_var(tensor_name)
        if not isinstance(tensor, TensorIR):
            raise ValueError(f"Global tensor {tensor_name} is not a TensorIR.")
        return copy(tensor)

    if isinstance(node, ast.Call):
        # 1） 以Tensor定义的方式给出
        if isinstance(node.func, ast.Name) and node.func.id == "Tensor":
            return _tensor_parse_by_tensor_def(node, tensor_name)

        # 2） 以view的形式给出
        if isinstance(node.func, ast.Attribute) and node.func.attr == 'view':
            return _tensor_parse_by_view_op(node, env, tensor_name)

    # 3） 以切片的形式给出
    if isinstance(node, ast.Subscript):
        return _tensor_parse_by_view_range(node, env, tensor_name)

    raise ValueError(f"Unsupported tensor definition: {ast.dump(node)}")


def get_tensor_assign_type(node: ast.Assign | ast.arg) -> int:
    """判断是否是Tensor的赋值语句： 0-不是tensor assign， 1-allocate赋值， 2-使用符号的slice（view）赋值， 3-使用view的函数赋值"""
    if isinstance(node, ast.Assign):
        value = node.value
    elif isinstance(node, ast.arg):
        value = node.annotation
    else:
        raise ValueError(f"Unsupported tensor definition: {ast.dump(node)}")

    if isinstance(value, ast.Call):
        # 1） Tensor赋值（分配地址空间）
        if isinstance(value.func, ast.Name) and value.func.id == "Tensor":
            return 1
        # 3） 使用Tensor.view进行切片
        elif isinstance(value.func, ast.Attribute) and value.func.attr == 'view':
            return 3
        return 0
        # 2） 如果是切片形式的从global tensor上取一小块
    elif isinstance(value, ast.Subscript):
        return 2
    else:
        return 0