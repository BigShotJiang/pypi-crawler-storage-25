import ast
from dataclasses import dataclass

from core.common.entity import MemLoc, DType
from core.common.log_format import logging
from core.frontend.dsl.parse.dsl_to_logistic_ir import body_parse
from core.frontend.dsl.parse.dsl_to_op_ir import generate_allocate_op
from core.frontend.dsl.parse.dsl_to_tensor_ir import tensor_parse, get_tensor_assign_type
from core.frontend.dsl.parse.dsl_to_var_ir import var_parse
from core.frontend.dsl.parse.ssa_env import SSAEnv
from core.frontend.ir.core.ir import KernelIR

logger = logging.getLogger(__name__)


@dataclass
class IrBuilder:
    env: SSAEnv = None
    eval_context: dict[str, float | int | bool | MemLoc | DType] = None
    kernel_ir: KernelIR = None

    def __post_init__(self):
        if self.env is None:
            self.env = SSAEnv()

        if self.eval_context is None:
            self.eval_context = dict()

    def _build_def(self, func_def: ast.FunctionDef):
        """构建函数定义的ir"""
        self.kernel_ir = KernelIR(name=func_def.name)
        default_values = [None] * (len(func_def.args.args) - len(func_def.args.defaults)) + func_def.args.defaults
        for i, arg in enumerate(func_def.args.args):
            default_value = default_values[i]

            # 变量 & Tensor赋值
            tensor_def_type = get_tensor_assign_type(arg)
            if tensor_def_type > 0:
                obj = tensor_parse(arg)
            else:
                obj = var_parse(arg, default_value)

            self.env.write_var(obj)
            self.kernel_ir.add_op(generate_allocate_op(obj))

    def build(self, tree: ast.Module, eval_context: dict[str, float | int | bool | MemLoc | DType]) -> KernelIR:
        if len(tree.body) > 1:
            raise Exception("only support single function in dsl")

        if not isinstance(tree.body[0], ast.FunctionDef):
            raise Exception("only support single function in dsl")

        self.eval_context = eval_context
        func = tree.body[0]

        # def解析
        self._build_def(func_def=func)

        # body解析
        body_ops = body_parse(body_nodes=func.body, env=self.env)
        self.kernel_ir.add_op(body_ops)

        # 处理phi函数 - 每个scope_id都记录对应的phi函数
        for phi_func in self.env.phi_func_list:
            for scope_id in phi_func.scope_referrers.keys():
                if scope_id not in self.kernel_ir.phi_func_dict:
                    self.kernel_ir.phi_func_dict[scope_id] = []
                self.kernel_ir.phi_func_dict[scope_id].append(phi_func)

        return self.kernel_ir