# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import ast
import traceback
import uuid

from core.common.tile_op_enum import TileOpCode
from core.common.log_format import logging
from core.frontend.dsl.parse.dsl_to_expr_ir import range_parse, expr_parse
from core.frontend.dsl.parse.dsl_to_op_ir import tensor_op_parse, generate_allocate_op, generate_view_op
from core.frontend.dsl.parse.dsl_to_tensor_ir import _attr_list_parse, get_tensor_assign_type, tensor_parse
from core.frontend.dsl.parse.dsl_to_var_ir import var_parse
from core.frontend.dsl.parse.ssa_env import SSAEnv
from core.frontend.ir.core.ir_entity import VarIR
from core.frontend.ir.core.ir_logistic import TaskIR, LogisticIR, ForIR, IfIR, OpIR
from core.frontend.ir.core.ir_math import RangeIR, ConstExprIR, VarExprIR

logger = logging.getLogger(__name__)


def _parse_stmt(stmt: ast.stmt, env: SSAEnv) -> LogisticIR | None:
    if isinstance(stmt, ast.Expr) and isinstance(stmt.value, ast.Call):
        logistic_ir = tensor_op_parse(stmt.value, env)
    elif isinstance(stmt, ast.For):
        logistic_ir = _for_parse(stmt, env)
    elif isinstance(stmt, ast.If):
        logistic_ir = _if_parse(stmt, env)
    elif isinstance(stmt, ast.With):
        logistic_ir = _task_parse(stmt, env)
    elif isinstance(stmt, ast.Assign):
        assign_type = get_tensor_assign_type(stmt)
        if assign_type > 0:
            obj = tensor_parse(stmt, env)
            if assign_type == 1:
                logistic_ir = generate_allocate_op(obj)
            elif assign_type in [2, 3]:
                logistic_ir = generate_view_op(obj, env)
            else:
                raise ValueError("未知的tensor赋值类型")
        else:
            obj = var_parse(stmt)
            logistic_ir = generate_allocate_op(obj)
    else:
        logger.info(f"不支持/忽略的语句类型{type(stmt)}")
        return None
    return logistic_ir


def body_parse(body_nodes: list[ast.stmt], env: SSAEnv) -> list[LogisticIR]:
    result = []
    for stmt in body_nodes:
        try:
            logistic_ir = _parse_stmt(stmt, env)
            if logistic_ir is None:
                continue
            if isinstance(logistic_ir, OpIR) and logistic_ir.op_code != TileOpCode.STORE:
                if logistic_ir.outputs and not isinstance(logistic_ir.outputs[-1], VarIR):
                    # NEXT: 不要hardcode在代码中，可以考虑通过TileOp/TensorOp的输入输出config定义判断处理
                    for output in logistic_ir.outputs:
                        env.write_var(output)
            result.append(logistic_ir)
        except Exception as e:
            traceback.print_exc()
            raise ValueError(f"\\n解析语句出错: 第 {stmt.lineno} 行: {ast.unparse(stmt)}。 报错内容如下: {e}") from e
    return result


def _task_parse(node, env: SSAEnv) -> TaskIR:
    """解析DSL中的Task语句"""
    env.push_stack()
    item = node.items[0]
    ctx = item.context_expr

    if not isinstance(ctx, ast.Call) or not isinstance(ctx.func, ast.Attribute) or ctx.func.attr != "Task":
        raise ValueError("DSL中Task语法错误")

    range_kw = next(kw for kw in ctx.keywords if kw.arg == "range")
    task_name = next(kw for kw in ctx.keywords if kw.arg == "name")
    if task_name is not None and isinstance(task_name.value, ast.Constant) and isinstance(task_name.value.value, str):
        task_name = task_name.value.value
    else:
        task_name = f"task_{id(node)}"

    max_value = _attr_list_parse(range_kw.value.elts)
    index_list = [v.id for v in item.optional_vars.elts]
    indices = []
    for idx, r in zip(index_list, max_value):
        range_ir = RangeIR(ConstExprIR(0), r, ConstExprIR(1))
        idx_ir = VarIR(name=idx, value=range_ir)
        env.write_var(idx_ir)
        indices.append(idx_ir)
    body = body_parse(node.body, env)

    task_ir = TaskIR(
        indices=indices,
        body=body,
        task_name=task_name,
    )
    env.pop_stack()
    return task_ir


def _for_parse(node: ast.For, env: SSAEnv) -> ForIR:
    """FOR语句解析"""
    # Save current variable versions before loop (for loop-carrying variables)
    # We need to snapshot which variables exist before the loop
    loop_entry_scope = env._scope[-1]
    loop_entry_vars = set(loop_entry_scope.version_map.keys())

    scope_id = uuid.uuid4().__str__()
    env.push_stack(scope_id)  # push 1: loop scope
    idx = node.target.id
    range_call = node.iter
    range_var = VarIR(idx, range_parse(range_call))

    # Write the loop index variable
    env.write_var(range_var)

    body_ir = body_parse(node.body, env)

    # Push a scope for collecting loop body writes (for loop exit Phi)
    env.push_stack()  # push 2: loop body collection scope

    # Collect variables modified inside the loop body
    loop_modified_vars = set()
    for stmt in env._scope[-2].version_map.keys():
        if stmt in loop_entry_vars:
            loop_modified_vars.add(stmt)

    # Pop the body collection scope (this will create Phis if needed)
    collected_scope = env.pop_stack()

    # Pop the loop scope - this creates the loop exit Phi
    env.pop_stack()

    # For proper SSA, we need to handle loop-carrying variables
    # Variables that existed before the loop and were modified inside need:
    # 1. An entry Phi (initial value + loop body value)
    # 2. An exit Phi (value outside + value after loop)

    # Note: The current implementation handles exit Phi through pop_stack above
    # Entry Phi would require more complex CFG analysis

    for_ir = ForIR(
        scope_id=scope_id,
        range=range_var,
        body=body_ir
    )
    return for_ir


def _if_parse(node: ast.If, env: SSAEnv) -> IfIR:
    """IF语句解析"""
    scope_id = uuid.uuid4().__str__()
    env.push_stack(scope_id)
    cond = expr_parse(node.test)

    if_scope = uuid.uuid4().__str__()
    env.push_stack(if_scope)
    if_body = body_parse(node.body, env)
    env.pop_stack()

    else_scope_id = None
    else_body = None

    if node.orelse:
        else_scope = uuid.uuid4().__str__()
        else_scope_id = else_scope
        env.push_stack(else_scope)
        else_body = body_parse(node.orelse, env)
        env.pop_stack()

    env.pop_stack()

    if_ir = IfIR(
        cond=cond,
        if_body=if_body,
        else_body=else_body,
        scope_id=scope_id,
        if_scope_id=if_scope,
        else_scope_id=else_scope_id
    )
    return if_ir