# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import ast

from core.frontend.dsl.parse.dsl_to_expr_ir import expr_parse
from core.frontend.ir.core.ir_entity import VarIR


def _var_parse_by_arg(node: ast.arg, default_value=None) -> VarIR:
    """def里面入参的一些设定"""
    var_name = node.arg
    value = None
    if default_value is not None:
        value = expr_parse(default_value)
    return VarIR(var_name, value)


def _var_parse_by_assign(node: ast.Assign) -> VarIR:
    """普通的变量赋值"""
    var_name = node.targets[0].id
    value = expr_parse(node.value)
    return VarIR(var_name, value)


def var_parse(node: ast.arg | ast.Assign, default_value=None) -> VarIR:
    """变量转换"""
    if isinstance(node, ast.arg):
        return _var_parse_by_arg(node, default_value)
    elif isinstance(node, ast.Assign):
        return _var_parse_by_assign(node)
    else:
        raise ValueError(f'var_parse error, unsupported node type: {type(node)}')
