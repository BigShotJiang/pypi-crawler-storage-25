# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

from core.common.entity import MemLoc, DType, CoreType
from core.frontend.dsl.grammar.tensor import Tensor


def _tile_op_loc_validation(dst: Tensor, src_list: list[Tensor], core_type: CoreType):
    """
    tile op 强限制起点终点的位置
    Args:
        dst:        起点
        src_list:   终点
        core_type:  Cube/Vec

    Returns:

    """
    if core_type == CoreType.AIV:
        if dst.mem_loc != MemLoc.UB.value:
            raise ValueError(f"{core_type} the output of vec tile op should in UB")
        if any(t.mem_loc != MemLoc.UB.value for t in src_list):
            raise ValueError(f"{core_type} the input of vec tile op should in UB")
    elif core_type == CoreType.AIC:
        if dst.mem_loc != MemLoc.L0C.value:
            raise ValueError(f"{core_type} the output of cube tile op should in L0C")
        elif any(t.mem_loc != MemLoc.L1.value for t in src_list):
            raise ValueError(f"{core_type} the input of cube tile op should in L1")
    else:
        raise ValueError(f"not support op type: {core_type}")


class TileOp:
    """
    EXAMPLE
    TileOp的基本格式为：
        第一个入参为 output tensor
        最后一个入参如果
            不是 Tensor类： 则最后一个入参为 TileOp 的格式配置 ===> dict 格式
            是 Tensor类： 则最后一个入参也是 TileOp 的一个输入 Tensor
        其他所有入参均是 Tensor 类， 表示 TileOp 的输入Tensor

    运算里面需要实现的包括两个内容：
        1） 函数调用的记录，通过 parent.record_call实现
        2） 入参校验，是否是合法的入参格式
    以上两个内容，每类运算的：
        **共同的部分** 由 __basic_***_vector_op_validation(...) 里面实现。
        **独自的逻辑** 在各op内部独立实现。
    """

    def __init__(self, parent):
        self.parent = parent

    ###################################双目运算类########################################
    def _basic_binocular_vector_op_validation(self, dst: Tensor, src1: Tensor, src2: Tensor, op_name: str, config):
        """
        基础vector双目运算的入参校验
        """
        _tile_op_loc_validation(dst, [src1, src2], CoreType.AIV)

        tensor_op = f'TileOp.{op_name}'
        # step1. 调用记录
        self.parent.record_call(tensor_op, [dst.__str__()], [src1.__str__(), src2.__str__()], config)

        # step2. 参数校验： 1） 输入输出的形状、shape是否符合基本运算标准。 2） 输入输出的数据精度是否在支持范围内
        if dst.shape != src1.shape:
            raise ValueError(f"{tensor_op} tensor shape mismatch")

        if dst.shape != src2.shape and not all(d == 1 for d in src2.shape):
            raise ValueError(f"{tensor_op} add only support [Vector,Vector] or [Vector,Scalar]")

        if dst.dtype != src1.dtype or dst.dtype != src2.dtype:
            raise ValueError(f"{tensor_op} tensor dtype mismatch")

    def add(self, dst: Tensor, src1: Tensor, src2: Tensor, config: dict = None):
        self._basic_binocular_vector_op_validation(dst, src1, src2, "add", config)

    def sub(self, dst: Tensor, src1: Tensor, src2: Tensor, config: dict = None):
        self._basic_binocular_vector_op_validation(dst, src1, src2, "sub", config)

    def mul(self, dst: Tensor, src1: Tensor, src2: Tensor, config: dict = None):
        self._basic_binocular_vector_op_validation(dst, src1, src2, "mul", config)

    def div(self, dst: Tensor, src1: Tensor, src2: Tensor, config: dict = None):
        self._basic_binocular_vector_op_validation(dst, src1, src2, "div", config)

    def max(self, dst: Tensor, src1: Tensor, src2: Tensor, config: dict = None):
        self._basic_binocular_vector_op_validation(dst, src1, src2, "max", config)

    def min(self, dst: Tensor, src1: Tensor, src2: Tensor, config: dict = None):
        self._basic_binocular_vector_op_validation(dst, src1, src2, "min", config)

    def select(self, dst: Tensor, src1: Tensor, src2: Tensor, config: dict = None):
        self._basic_binocular_vector_op_validation(dst, src1, src2, "select", config)

    def not_equal(self, dst: Tensor, src1: Tensor, src2: Tensor, config: dict = None):
        self._basic_binocular_vector_op_validation(dst, src1, src2, "not_equal", config)

    def greater_equal(self, dst: Tensor, src1: Tensor, src2: Tensor, config: dict = None):
        self._basic_binocular_vector_op_validation(dst, src1, src2, "greater_equal", config)

    ###################################向量标量运算类类########################################
    def _basic_scalar_vector_op_validation(self, dst: Tensor, src1: Tensor, src2: Tensor, op_name: str, config):
        pass

    def adds(self, dst: Tensor, src: Tensor, config: dict = None):
        self._basic_binocular_vector_op_validation(dst, src, "add", config)

    def subs(self, dst: Tensor, src: Tensor, config: dict = None):
        self._basic_binocular_vector_op_validation(dst, src, "sub", config)

    def muls(self, dst: Tensor, src: Tensor, config: dict = None):
        self._basic_binocular_vector_op_validation(dst, src, "mul", config)

    def divs(self, dst: Tensor, src: Tensor, config: dict = None):
        self._basic_binocular_vector_op_validation(dst, src, "div", config)

    def maxs(self, dst: Tensor, src: Tensor, config: dict = None):
        self._basic_binocular_vector_op_validation(dst, src, "max", config)

    def mins(self, dst: Tensor, src: Tensor, config: dict = None):
        self._basic_binocular_vector_op_validation(dst, src, "min", config)

    ###################################单目运算类########################################
    def __basic_monocular_vector_op_validation(self, dst: Tensor, src: Tensor, op_name: str, config):
        """
        基础vector单目运算的入参校验
        """
        _tile_op_loc_validation(dst, [src], CoreType.AIV)
        tensor_op = f'TileOp.{op_name}'
        # step1. 调用记录
        self.parent.record_call(tensor_op, [dst.__str__()], [src.__str__()], config)

        # step2. 参数校验： 1） 输入输出的形状、shape是否符合基本运算标准。 2） 输入输出的数据精度是否在支持范围内
        if dst.shape != src.shape:
            raise ValueError(f"{tensor_op} tensor shape mismatch")

        if dst.dtype != src.dtype:
            raise ValueError(f"{tensor_op} tensor dtype mismatch")

    def abs(self, dst: Tensor, src: Tensor, config: dict = None):
        self.__basic_monocular_vector_op_validation(dst, src, "abs", config)

    def exp(self, dst: Tensor, src: Tensor, config: dict = None):
        self.__basic_monocular_vector_op_validation(dst, src, "exp", config)

    def sqrt(self, dst: Tensor, src: Tensor, config: dict = None):
        self.__basic_monocular_vector_op_validation(dst, src, "sqrt", config)

    def relu(self, dst: Tensor, src: Tensor, config: dict = None):
        self.__basic_monocular_vector_op_validation(dst, src, "relu", config)

    def log(self, dst: Tensor, src: Tensor, config: dict = None):
        self.__basic_monocular_vector_op_validation(dst, src, "log", config)

    ###################################规约运算类########################################
    def __basic_reduce_vector_op_validation(self, dst: Tensor, src: Tensor, op_name: str, config):
        """
        基础vector reduce类运算的入参校验
        """
        _tile_op_loc_validation(dst, [src], CoreType.AIV)
        tensor_op = f'TileOp.{op_name}'

        # step1. 调用记录
        self.parent.record_call(tensor_op, [dst.__str__()], [src.__str__()], config)

        # step2. 参数校验： 1） 输入输出的形状、shape是否符合基本运算标准。 2） 输入输出的数据精度是否在支持范围内

        # 规约轴输出 = 1， 其他轴输出 = 输入
        reduce_axis = config['reduce_axis']
        for d, src_shape in enumerate(src.shape):
            if d != reduce_axis:
                if dst.shape[d] != src_shape:
                    raise ValueError(f"{tensor_op} tensor shape mismatch")
            else:
                if dst.shape[d] != 1:
                    raise ValueError(f"{tensor_op} reduce_axis error")

        if dst.dtype != src.dtype:
            raise ValueError(f"{tensor_op} tensor dtype mismatch")

    def reduce_sum(self, dst: Tensor, src: Tensor, config: dict):
        """
        规约求和
        Args:
            dst:        output tensor
            src:        input tensor
            config:     reduce_axis 规约轴编号（从0开始）
        """
        self.__basic_reduce_vector_op_validation(dst, src, "reduce_sum", config)

    def reduce_max(self, dst: Tensor, src: Tensor, config: dict):
        """
        规约求max
        Args:
            dst:        output tensor
            src:        input tensor
            config:     reduce_axis 规约轴编号（从0开始）
        """
        self.__basic_reduce_vector_op_validation(dst, src, "reduce_max", config)

    def reduce_min(self, dst: Tensor, src: Tensor, config: dict):
        """
        规约求min
        Args:
            dst:        output tensor
            src:        input tensor
            config:     reduce_axis 规约轴编号（从0开始）
        """
        self.__basic_reduce_vector_op_validation(dst, src, "reduce_min", config)

    ###################################广播运算类########################################
    def broadcast(self, dst: Tensor, src: Tensor, config: dict):
        # NEXT 待完善
        pass

    ###################################矩阵乘运算类########################################
    def __basic_gemm_cube_op_validation(self, dst: Tensor, src1: Tensor, src2: Tensor, op_name: str, config: dict):
        """
        基础cube运算 gemm类运算的入参校验
        """
        _tile_op_loc_validation(dst, [src1, src2], CoreType.AIC)
        tensor_op = f'TileOp.{op_name}'

        # step1. 调用记录
        self.parent.record_call(tensor_op, [dst.__str__()], [src1.__str__(), src2.__str__()], config)

        # step2. 参数校验： 1） 输入输出的形状、shape是否符合基本运算标准。 2） 输入输出的数据精度是否在支持范围内
        # 形状校验：仅支持二维tensor
        if len(src1.shape) != 2 or len(src2.shape) != 2 or len(dst.shape) != 2:
            raise ValueError(f"{tensor_op} only support 2D Tensor")

        shape1 = src1.shape
        shape2 = src2.shape
        shape3 = dst.shape

        # 转置
        if 'transpose_B' in config.keys():
            n, k = src2.shape
            shape2 = [k, n]

        # 形状校验： MKN风格
        if (
                # M
                (shape1[0] != shape3[0]) or
                # K
                (shape1[1] != shape2[1]) or
                # N
                (shape2[0] != shape3[1])
        ):
            raise ValueError(f"{tensor_op} shape error")

        # 输入数据格式必须相同
        if src1.dtype != src2.dtype:
            raise ValueError(f"{tensor_op} src1.dtype must be equal to src2.dtype")

        # 支持的数据精度 NEXT 待补充完全
        d_type_set = {
            (DType.FP16, DType.FP32),
            (DType.FP16, DType.FP16),
            (DType.INT8, DType.INT32),
        }
        if (src1.dtype, dst.dtype) not in d_type_set:
            raise ValueError(f"{tensor_op} not support src.dtype + dst.dtype")

    def gemm(self, dst: Tensor, src1: Tensor, src2: Tensor, config: dict = None):
        """
        一般矩阵乘，仅支持 二维张量的输入，格式为 [M,K]@[K,N] = [M,N]
        Args:
            dst:        output tensor
            src1:       左矩阵
            src2:       右矩阵
            config:     transpose_B: 是否转置右矩阵，转置后为 [K,N]格式，否则为[N,K]格式
        """
        self.__basic_gemm_cube_op_validation(dst, src1, src2, "gemm", config)

    def mmad(self, dst: Tensor, src1: Tensor, src2: Tensor, config: dict = None):
        """
        一般矩阵乘，仅支持 二维张量的输入，格式为 [M,K]@[K,N] = [M,N]
        Args:
            dst:        output tensor
            src1:       左矩阵
            src2:       右矩阵
            config:     transpose_B: 是否转置右矩阵，转置后为 [K,N]格式，否则为[N,K]格式
        """
        self.__basic_gemm_cube_op_validation(dst, src1, src2, "gemm", config)

    ###################################卷积运算类########################################
    def __basic_conv_cube_op_validation(self, dst: Tensor, src1: Tensor, src2: Tensor, op_name: str, config: dict):
        # NEXT 待完善
        pass

    def conv2d(self, dst: Tensor, src1: Tensor, src2: Tensor, config: dict):
        # NEXT 待完善
        self.__basic_conv_cube_op_validation(dst, src1, src2, "conv2d", config)

    def conv3d(self, dst: Tensor, src1: Tensor, src2: Tensor, config: dict):
        # NEXT 待完善
        self.__basic_conv_cube_op_validation(dst, src1, src2, "conv3d", config)

    ###################################同步########################################
    def barrier(self):
        pass

    def set_flag(self, config: dict):
        """
        Args:
            config: dict k1-units, v1-[CoreUnit] 需要阻塞的组件; k2-flag_id, v2-str， 与wait flag一一对应
        Returns:
        """
        pass

    def wait_flag(self, config: dict):
        """
        Args:
            config: dict k1-units, v1-[CoreUnit] 需要阻塞的组件; k2-flag_id, v2-str， 与set flag一一对应
        Returns:
        """
        pass

    ###################################数据控制类########################################
    def copy(self, dst: Tensor, src: Tensor, config: dict = None):
        if dst.mem_loc == src.mem_loc and dst.mem_loc != MemLoc.UB:
            raise ValueError("mte copy dest location should not same with source location")
        if dst.dtype != src.dtype:
            raise ValueError("copy dest dtype should be same with source dtype")
        self.parent.record_call("copy", dst, src, config)

    def cast(self, dst: Tensor, src: Tensor, config: dict = None):
        pass

    def view(self, dst: Tensor, src: Tensor, offset: list[int]):
        if dst.mem_loc != src.mem_loc:
            raise ValueError("view dest location should be same with source location")
        if dst.dtype != src.dtype:
            raise ValueError("view dest dtype should be same with source dtype")
        config = {'offset': offset}
        self.parent.record_call("view", dst, src, config)

    def null_op(self):
        pass