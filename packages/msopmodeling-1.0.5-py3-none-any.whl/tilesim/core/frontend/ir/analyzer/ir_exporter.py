# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

import ast
import inspect
import math
from pathlib import Path
from typing import Any

from core.common.entity import MemLoc
from core.common.op_registry import init_registry
from core.common.tile_op_enum import TileOpCode
from core.frontend.dsl.parse.ir_builder_by_dsl import IrBuilder
from core.frontend.ir.core.ir import KernelIR
from core.frontend.ir.core.ir_entity import TensorIR, VarIR, EntityIR
from core.frontend.ir.core.ir_logistic import LogisticIR, OpIR, TaskIR, ForIR, IfIR
from core.frontend.ir.core.ir_math import MathIR, ExprIR, RangeIR, ConstExprIR, VarExprIR, OpExprIR, CompareExprIR, \
    LogicalExprIR, CallExprIR, ExprOpEnum, ExprFunc


class IRExporter:
    """将tilesim执行过程中的IR导出为可读的MLIR风格文本"""

    def __init__(self, indent: str = "  ", dynamic_shape: dict = None):
        self.indent = indent
        self._var_counter = 0
        self._tensor_counter = 0
        self._dynamic_shape = dynamic_shape or {}
        self._entity_names = set()  # 追踪已导出的实体名称
        self._var_name_map = {}  # origin_name -> name 的映射表

    def export_kernel_ir(self, kernel_ir: KernelIR) -> str:
        """导出KernelIR为MLIR风格文本"""
        lines = []

        # 预先收集变量名映射关系（origin_name -> name）
        self._collect_var_name_mapping(kernel_ir)

        # 添加文件头注释
        lines.append(f"// Generated IR for kernel: {kernel_ir.name}")
        lines.append("")

        # 添加dynamic_shape元数据
        if self._dynamic_shape:
            lines.append("// Dynamic Shape Metadata:")
            lines.append("// ==========")
            for key, value in self._dynamic_shape.items():
                if isinstance(value, DType):
                    lines.append(f"// {key}: {value.name}")
                else:
                    lines.append(f"// {key}: {value}")
            lines.append("")
            lines.append("")

        lines.append("module {")

        lines.append(f"  ts.func public @{kernel_ir.name}() {{")

        # 导出所有操作（按顺序）
        for op in kernel_ir.ops:
            if isinstance(op, OpIR):
                lines.append(f"    {self._format_op_mlir(op)}")
            elif isinstance(op, TaskIR):
                lines.extend(self._format_task_mlir(op, base_indent=2))
            elif isinstance(op, ForIR):
                lines.extend(self._format_for_mlir(op, base_indent=2))
            elif isinstance(op, IfIR):
                lines.extend(self._format_if_mlir(op, base_indent=2))

        lines.append("  }")
        lines.append("}")

        return "\n".join(lines)

    def _collect_var_name_mapping(self, kernel_ir: KernelIR):
        """收集变量名映射关系（origin_name -> name）"""

        visited = set()
        to_visit = []

        # 从kernel_ir.ops开始遍历
        to_visit.extend(kernel_ir.ops)

        while to_visit:
            obj = to_visit.pop()
            if id(obj) in visited:
                continue
            visited.add(id(obj))

            if isinstance(obj, VarIR):
                if obj.origin_name and obj.origin_name != obj.name:
                    self._var_name_map[obj.origin_name] = obj.name

            elif isinstance(obj, (TaskIR, ForIR, IfIR, OpIR)):
                # 遍历属性
                if hasattr(obj, 'body') and isinstance(obj.body, list):
                    to_visit.extend(obj.body)
                if hasattr(obj, 'indices') and isinstance(obj.indices, list):
                    to_visit.extend(obj.indices)
                if hasattr(obj, 'if_body') and isinstance(obj.if_body, list):
                    to_visit.extend(obj.if_body)
                if hasattr(obj, 'else_body') and isinstance(obj.else_body, list):
                    to_visit.extend(obj.else_body)
                if hasattr(obj, 'inputs') and isinstance(obj.inputs, list):
                    to_visit.extend(obj.inputs)
                if hasattr(obj, 'outputs') and isinstance(obj.outputs, list):
                    to_visit.extend(obj.outputs)
                if hasattr(obj, 'range'):
                    to_visit.append(obj.range)
                if hasattr(obj, 'cond'):
                    to_visit.append(obj.cond)

    def _format_tensor_alloc(self, tensor: TensorIR) -> str:
        """格式化TensorIR为alloc语句"""
        # 格式化shape
        shape_parts = []
        shape_display = []
        for dim in tensor.shape:
            dim_str = self._format_math_ir(dim)
            shape_parts.append(dim_str)
            # 用于显示 - 尝试获取实际值
            value = self._resolve_math_value(dim)
            if value is not None:
                shape_display.append(str(value))
            elif isinstance(dim, VarExprIR):
                shape_display.append(f"%{dim.name}")
            else:
                shape_display.append(dim_str)

        shape_str = ", ".join(shape_parts)
        shape_display_str = "x".join(shape_display) if shape_display else "0"

        # 格式化dtype - 尝试获取实际DType值
        dtype_display = self._resolve_dtype(tensor.dtype)

        # mem_loc
        memloc_str = tensor.mem_loc.value if isinstance(tensor.mem_loc, MemLoc) else str(tensor.mem_loc)

        return f"%{tensor.name} = ts.tensor.alloc shape = [{shape_str}] dtype = {dtype_display} mem_loc = {memloc_str} : tensor<{shape_display_str}x{dtype_display}>"

    def _format_var_alloc(self, var: VarIR) -> str:
        """格式化VarIR为alloc语句"""
        value_str = self._format_math_ir(var.value)

        if isinstance(var.value, ConstExprIR):
            if isinstance(var.value.value, int):
                return f"%{var.name} = arith.constant {var.value.value} : i32"
            elif isinstance(var.value.value, float):
                return f"%{var.name} = arith.constant {var.value.value} : f32"
            elif isinstance(var.value.value, bool):
                val = "true" if var.value.value else "false"
                return f"%{var.name} = arith.constant {val} : i1"

        elif isinstance(var.value, RangeIR):
            start_str = self._format_math_ir(var.value.start)
            end_str = self._format_math_ir(var.value.end)
            step_str = self._format_math_ir(var.value.step)
            return f"%{var.name} = ts.make_range {{end = {end_str}, start = {start_str}, step = {step_str}}} : range<i32>"

        return f"%{var.name} = ts.var {value_str} : i32"

    def _format_entity_alloc(self, entity: EntityIR) -> str:
        """格式化实体alloc语句"""
        if isinstance(entity, TensorIR):
            return self._format_tensor_alloc(entity)
        elif isinstance(entity, VarIR):
            return self._format_var_alloc(entity)
        return f"// unknown entity: {entity.name}"

    def _format_task_mlir(self, task: TaskIR, base_indent: int = 2) -> list[str]:
        """格式化TaskIR为MLIR风格"""
        indent = self.indent * base_indent
        lines = []

        # 开始task块
        core_type = self._infer_core_type(task.body)
        core_attr = f" core_type = {core_type}" if core_type != "UNKNOWN" else ""

        lines.append(f"{indent}// Task: {task.task_name}")
        lines.append(f"{indent}ts.task @{task.task_name}{core_attr} {{")

        # 格式化索引
        for idx in task.indices:
            if isinstance(idx.value, RangeIR):
                range_str = self._format_range(idx.value)
                lines.append(f"{indent}  %{idx.name} = ts.task_index range = {range_str} : i32")
            else:
                value_str = self._format_math_ir(idx.value)
                lines.append(f"{indent}  %{idx.name} = ts.task_index value = {value_str} : i32")

        # 递归格式化body内的所有操作（包括嵌套的ForIR和IfIR）
        lines.extend(self._format_body_ops(task.body, base_indent + 1))

        # 结束task块
        lines.append(f"{indent}}}")
        return lines

    def _format_body_ops(self, ops: list[LogisticIR], base_indent: int) -> list[str]:
        """格式化body内的操作，递归处理嵌套结构"""
        indent = self.indent * base_indent
        lines = []

        for op in ops:
            if isinstance(op, OpIR):
                lines.append(f"{indent}{self._format_op_mlir(op)}")
            elif isinstance(op, ForIR):
                lines.extend(self._format_for_mlir(op, base_indent))
            elif isinstance(op, IfIR):
                lines.extend(self._format_if_mlir(op, base_indent))
            elif isinstance(op, EntityIR):
                # 独立的实体alloc
                lines.append(f"{indent}{self._format_entity_alloc(op)}")

        return lines

    def _format_for_mlir(self, for_ir: ForIR, base_indent: int = 2) -> list[str]:
        """格式化ForIR为MLIR风格"""
        indent = self.indent * base_indent
        lines = []

        # 提取range信息
        if isinstance(for_ir.range.value, RangeIR):
            range_str = self._format_range(for_ir.range.value)
            lines.append(f"{indent}for %{for_ir.range.name} in {range_str} {{")
        else:
            value_str = self._format_math_ir(for_ir.range.value)
            lines.append(f"{indent}for %{for_ir.range.name} in {value_str} {{")

        # 递归格式化body
        lines.extend(self._format_body_ops(for_ir.body, base_indent + 1))

        lines.append(f"{indent}}}")
        return lines

    def _format_if_mlir(self, if_ir: IfIR, base_indent: int = 2) -> list[str]:
        """格式化IfIR为MLIR风格"""
        indent = self.indent * base_indent
        lines = []

        cond_str = self._format_math_ir(if_ir.cond)
        lines.append(f"{indent}if ({cond_str}) {{")

        # if_body
        lines.extend(self._format_body_ops(if_ir.if_body, base_indent + 1))

        if if_ir.else_body:
            lines.append(f"{indent}}} else {{")
            lines.extend(self._format_body_ops(if_ir.else_body, base_indent + 1))
            lines.append(f"{indent}}}")
        else:
            lines.append(f"{indent}}}")

        return lines

    def _get_inputs_and_outputs(self, op: OpIR):
        # 获取输入输出名称
        inputs = []
        for inp in op.inputs:
            if hasattr(inp, 'name'):
                inputs.append(f"%{inp.name}")
            elif isinstance(inp, str):
                inputs.append(inp)

        outputs = []
        for out in op.outputs:
            if hasattr(out, 'name'):
                outputs.append(f"%{out.name}")
            elif isinstance(out, str):
                outputs.append(out)
        return inputs, outputs

    def _format_op_mlir(self, op: OpIR) -> str:
        """格式化OpIR为MLIR风格"""
        opcode = op.op_code.value
        inputs, outputs = self._get_inputs_and_outputs(op)

        # 不同操作类型使用不同的格式
        if opcode == "alloc":
            # ALLOC的输出是TensorIR，需要格式化完整信息
            if op.outputs:
                for out in op.outputs:
                    if isinstance(out, TensorIR):
                        return self._format_tensor_alloc(out)
                    elif isinstance(out, VarIR):
                        return self._format_var_alloc(out)
            # 如果输出不是实体类型，使用通用格式
            result = outputs[0] if outputs else "result"
            return f"{result} = ts.alloc"

        elif opcode == "view":
            result = outputs[0] if outputs else "result"
            src = inputs[0] if inputs else "input"
            return f"{result} = ts.tensor.view src = {src} // tensor view"

        elif opcode == "copy":
            src = inputs[0] if len(inputs) > 0 else "src"
            dst = outputs[0] if outputs else "dst"
            return f"ts.tensor.copy {dst}, {src} // data transfer"

        elif opcode == "mmad":
            result = outputs[0] if outputs else "result"
            input1 = inputs[0] if len(inputs) > 0 else "A"
            input2 = inputs[1] if len(inputs) > 1 else "B"
            return f"ts.op.mmad {result}, {input1}, {input2} // matrix multiply-accumulate"

        elif opcode == "gemm":
            result = outputs[0] if outputs else "result"
            input1 = inputs[0] if len(inputs) > 0 else "A"
            input2 = inputs[1] if len(inputs) > 1 else "B"
            return f"ts.op.gemm {result}, {input1}, {input2} // general matrix multiply"

        elif opcode in ["add", "sub", "mul", "div"]:
            result = outputs[0] if outputs else "result"
            input1 = inputs[0] if len(inputs) > 0 else "x"
            input2 = inputs[1] if len(inputs) > 1 else "y"
            return f"{result} = arith.{opcode} {input1}, {input2} : f32"

        elif opcode in ["add", "max", "min"]:
            result = outputs[0] if outputs else "result"
            input1 = inputs[0] if len(inputs) > 0 else "x"
            input2 = inputs[1] if len(inputs) > 1 else "y"
            return f"{result} = ts.vop.{opcode} {input1}, {input2} : vector"

        else:
            # 通用操作格式
            input_str = ", ".join(inputs)
            result_str = outputs[0] if outputs else "_"

            if op.level.value == "HostOp":
                return f"{result_str} = ts.host.{opcode}({input_str})"
            else:
                return f"ts.op.{opcode} {input_str} -> {result_str}"

    def _format_range(self, range_ir: RangeIR) -> str:
        """格式化RangeIR"""
        start = self._format_math_ir(range_ir.start)
        end = self._format_math_ir(range_ir.end)
        step = self._format_math_ir(range_ir.step)
        return f"[{start}, {end}, {step})"

    def _infer_core_type(self, body: list[LogisticIR]) -> str:
        """推断任务的核心类型"""
        core_set = set()
        for op in body:
            if not isinstance(op, OpIR):
                continue
            for op_item in op.return_body_ops():
                # 对于COPY操作，需要从输入输出推断memory location
                if op_item.op_code == TileOpCode.COPY:
                    src_mem = None
                    dst_mem = None
                    if op.inputs and isinstance(op.inputs[0], EntityIR) and hasattr(op.inputs[0], 'mem_loc'):
                        src_mem = op.inputs[0].mem_loc
                    if op.outputs and isinstance(op.outputs[0], EntityIR) and hasattr(op.outputs[0], 'mem_loc'):
                        dst_mem = op.outputs[0].mem_loc

                    if src_mem and dst_mem:
                        core_type = op_item.op_code.get_core_type(src_mem, dst_mem)
                        if core_type:
                            core_set.add(core_type.name)
                else:
                    core_type = op_item.op_code.get_core_type()
                    if core_type:
                        core_set.add(core_type.name)

        if "AIC" in core_set and "AIV" in core_set:
            return "MIX"
        elif "AIC" in core_set:
            return "AIC"
        elif "AIV" in core_set:
            return "AIV"
        return "UNKNOWN"

    def _format_math_ir(self, math_ir: MathIR) -> str:
        """格式化MathIR"""
        if isinstance(math_ir, RangeIR):
            return self._format_range(math_ir)

        elif isinstance(math_ir, ConstExprIR):
            return str(math_ir.value)

        elif isinstance(math_ir, VarExprIR):
            # 使用映射表获取实际的变量名
            actual_name = self._var_name_map.get(math_ir.name, math_ir.name)
            return f"%{actual_name}"

        elif isinstance(math_ir, OpExprIR):
            lhs = self._format_math_ir(math_ir.lhs)
            rhs = self._format_math_ir(math_ir.rhs)
            op_map = {
                ExprOpEnum.ADD: "+",
                ExprOpEnum.SUB: "-",
                ExprOpEnum.MUL: "*",
                ExprOpEnum.DIV: "/",
                ExprOpEnum.FLOORDIV: "//",
                ExprOpEnum.MOD: "%"
            }
            op_str = op_map.get(math_ir.op, math_ir.op.value)
            return f"({lhs} {op_str} {rhs})"

        elif isinstance(math_ir, CompareExprIR):
            lhs = self._format_math_ir(math_ir.lhs)
            rhs = self._format_math_ir(math_ir.rhs)
            op_map = {
                ExprOpEnum.LT: "<",
                ExprOpEnum.LE: "<=",
                ExprOpEnum.GT: ">",
                ExprOpEnum.GE: ">=",
                ExprOpEnum.EQ: "==",
                ExprOpEnum.NE: "!="
            }
            op_str = op_map.get(math_ir.op, math_ir.op.value)
            return f"({lhs} {op_str} {rhs})"

        elif isinstance(math_ir, LogicalExprIR):
            if math_ir.op == ExprOpEnum.NOT:
                operand = self._format_math_ir(math_ir.operands[0])
                return f"(!{operand})"
            operands_str = " && ".join([self._format_math_ir(op) for op in math_ir.operands])
            op_map = {ExprOpEnum.AND: "&&", ExprOpEnum.OR: "||"}
            return f"({operands_str})"

        elif isinstance(math_ir, CallExprIR):
            args_str = ", ".join([self._format_math_ir(arg) for arg in math_ir.args])
            return f"{math_ir.func.value}({args_str})"

        elif isinstance(math_ir, ExprIR) and hasattr(math_ir, 'name'):
            return f"%{math_ir.name}"

        return str(math_ir)

    def _resolve_math_value(self, math_ir):
        """尝试解析MathIR表达式为具体值"""
        if isinstance(math_ir, ConstExprIR):
            return math_ir.value
        elif isinstance(math_ir, VarExprIR):
            if math_ir.name in self._dynamic_shape:
                value = self._dynamic_shape[math_ir.name]
                if isinstance(value, DType):
                    return value.name
                return value
            return None
        elif isinstance(math_ir, OpExprIR):
            lhs = self._resolve_math_value(math_ir.lhs)
            rhs = self._resolve_math_value(math_ir.rhs)
            if lhs is not None and rhs is not None:
                if math_ir.op == ExprOpEnum.ADD:
                    return lhs + rhs
                elif math_ir.op == ExprOpEnum.SUB:
                    return lhs - rhs
                elif math_ir.op == ExprOpEnum.MUL:
                    return lhs * rhs
                elif math_ir.op == ExprOpEnum.DIV:
                    return lhs / rhs
                elif math_ir.op == ExprOpEnum.FLOORDIV:
                    return lhs // rhs
                else:
                    raise ValueError(f"Unsupported math_ir.op: {math_ir.op}")
        elif isinstance(math_ir, CallExprIR):
            # 处理函数调用，如ceil
            arg_values = [self._resolve_math_value(arg) for arg in math_ir.args]
            if all(v is not None for v in arg_values):
                if math_ir.func == ExprFunc.CEIL:
                    return math.ceil(arg_values[0])
                elif math_ir.func == ExprFunc.FLOOR:
                    return math.floor(arg_values[0])
                elif math_ir.func == ExprFunc.MIN:
                    return min(arg_values)
                elif math_ir.func == ExprFunc.MAX:
                    return max(arg_values)
                else:
                    raise ValueError(f"Unsupported math_ir.func: {math_ir.func}")
        return None

    def _resolve_dtype(self, dtype_ir):
        """解析dtype表达式为DType字符串"""
        if isinstance(dtype_ir, DType):
            return dtype_ir.name.lower()
        elif isinstance(dtype_ir, VarExprIR):
            if dtype_ir.name in self._dynamic_shape:
                value = self._dynamic_shape[dtype_ir.name]
                if isinstance(value, DType):
                    return value.name.lower()
                return str(value).lower()
            return dtype_ir.name.lower()
        elif isinstance(dtype_ir, ConstExprIR):
            if isinstance(dtype_ir.value, DType):
                return dtype_ir.value.name.lower()
            return str(dtype_ir.value).lower()
        return str(dtype_ir).lower()


def export_ir_from_dsl(
        dsl_func: callable,
        dynamic_shape: dict[str, Any],
        output_path: str
) -> str:
    """
    从DSL函数导出IR到文本文件

    Args:
        dsl_func: DSL函数
        dynamic_shape: 动态形状上下文
        output_path: 输出文件路径

    Returns:
        导出的IR文本
    """
    # 初始化注册表
    init_registry()

    # 解析DSL为IR
    src = inspect.getsource(dsl_func)
    tree = ast.parse(src)

    ir_builder = IrBuilder()
    kernel_ir = ir_builder.build(tree, dynamic_shape)

    # 导出IR（传递dynamic_shape以便包含元数据）
    exporter = IRExporter(dynamic_shape=dynamic_shape)
    ir_text = exporter.export_kernel_ir(kernel_ir)

    # 写入文件
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(ir_text)

    return ir_text


# 示例用法
if __name__ == "__main__":
    import sys

    # 添加项目路径
    project_root = Path(__file__).parent
    sys.path.insert(0, str(project_root))

    # 导入MatMul算子DSL示例
    from ops.engineering_model.cube_op.matmul_l0 import matmul_l0
    from core.common.entity import DType

    # 设置动态形状
    dynamic_shape = {
        "M": 2048,
        "K": 512,
        "N": 1024,
        "input_dtype": DType.FP16,
        "output_dtype": DType.FP32,
        "tm": 128,
        "tn": 256,
        "tk1": 256,
        "tk0": 64,
    }

    # 导出IR
    output_path = "matmul_l0.tsir"
    ir_text = export_ir_from_dsl(matmul_l0, dynamic_shape, output_path)