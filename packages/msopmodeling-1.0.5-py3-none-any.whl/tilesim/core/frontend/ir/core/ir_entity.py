# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, TYPE_CHECKING

from core.common.entity import DType, MemLoc
from core.frontend.ir.core.ir_math import MathIR, RangeIR, ExprIR, VarExprIR

if TYPE_CHECKING:
    from core.backend.backend_entity.backend_entity import TensorEntity, VarEntity


# 变量、张量等实体类
class EntityIR(ABC):

    def __init__(self, name: str):
        self.name = name
        self.origin_name = name

    @abstractmethod
    def to_entity(self) -> Any:
        pass


def _parse_raw_tensor(tensor: 'TensorIR'):
    """Recursively parse raw tensor information"""
    raw_tensor_name = None
    raw_tensor_shape = None
    if tensor.raw_tensor is not None:
        if tensor.raw_tensor.raw_tensor is not None:
            return _parse_raw_tensor(tensor.raw_tensor)
        raw_tensor_name = tensor.raw_tensor.name
        if len(tensor.raw_tensor.shape) > 0:
            raw_tensor_shape = tensor.raw_tensor.to_entity().shape

    return raw_tensor_name, raw_tensor_shape


@dataclass
class TensorIR(EntityIR):
    shape: list[MathIR]
    dtype: DType | ExprIR
    mem_loc: MemLoc | ExprIR
    raw_tensor: 'TensorIR' = None

    def __init__(self, name: str, shape: list[MathIR], dtype: DType | ExprIR, mem_loc: MemLoc | ExprIR, raw_tensor: 'TensorIR' = None):
        super().__init__(name)
        self.shape = shape
        self.dtype = dtype
        self.mem_loc = mem_loc
        self.raw_tensor = raw_tensor

    def to_entity(self):
        """Lazy import to avoid circular dependency"""
        from core.backend.backend_entity.backend_entity import TensorEntity

        shape = []
        offset = []

        for dim in self.shape:
            if isinstance(dim, RangeIR):
                shape.append(dim.get_shape().to_entity())
                offset.append(dim.start.to_entity())
            elif isinstance(dim, ExprIR):
                shape.append(dim.to_entity())
                offset.append(0)
            else:
                raise ValueError(f'不支持的shape类型: {type(dim)}')

        dtype = self.dtype
        if isinstance(self.dtype, VarExprIR):
            dtype = self.dtype.to_entity()

        mem_loc = self.mem_loc
        if isinstance(self.mem_loc, VarExprIR):
            mem_loc = self.mem_loc.to_entity()

        raw_tensor_name, raw_tensor_shape = _parse_raw_tensor(self)
        return TensorEntity(self.name, shape, dtype, mem_loc, raw_tensor_name, raw_tensor_shape, offset)


@dataclass
class VarIR(EntityIR):
    value: MathIR

    def __init__(self, name: str, value: MathIR):
        super().__init__(name)
        self.value = value

    def to_entity(self):
        """Lazy import to avoid circular dependency"""
        from core.backend.backend_entity.backend_entity import VarEntity
        return VarEntity(self.name, self.value.to_entity())