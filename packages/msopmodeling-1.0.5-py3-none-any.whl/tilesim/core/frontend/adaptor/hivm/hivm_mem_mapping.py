# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
"""
HIVM地址空间到MemLoc的映射

HIVM MLIR中使用的地址空间:
- gm: 全局内存 (Global Memory)
- cbuf: L1缓存 (用于AIC核)
- ub: UB缓存 (Unified Buffer, 用于AIV核)
- cc: L0C缓存 (Cube输出缓存)
"""
from core.common.entity import MemLoc

# HIVM地址空间到MemLoc的映射表
HIVM_MEM_MAPPING: dict[str, MemLoc] = {
    'gm': MemLoc.GM,
    'cbuf': MemLoc.L1,
    'ub': MemLoc.UB,
    'cc': MemLoc.L0C,
    'l0a': MemLoc.L0A,
    'l0b': MemLoc.L0B,
    'l2': MemLoc.L2,
}


def hivm_mem_to_memloc(hivm_mem: str) -> MemLoc:
    """
    将HIVM地址空间字符串转换为MemLoc枚举值

    Args:
        hivm_mem: HIVM地址空间字符串，如 'gm', 'cbuf', 'ub', 'cc'

    Returns:
        对应的MemLoc枚举值

    Raises:
        ValueError: 如果传入的地址空间字符串不被支持
    """
    hivm_mem_lower = hivm_mem.lower()
    if hivm_mem_lower in HIVM_MEM_MAPPING:
        return HIVM_MEM_MAPPING[hivm_mem_lower]
    raise ValueError(f"Unknown HIVM memory space: {hivm_mem}")


def memloc_to_hivm_mem(mem_loc: MemLoc) -> str:
    """
    将MemLoc枚举值转换为HIVM地址空间字符串

    Args:
        mem_loc: MemLoc枚举值

    Returns:
        对应的HIVM地址空间字符串

    Raises:
        ValueError: 如果传入的MemLoc不支持对应的HIVM映射
    """
    reverse_mapping = {v: k for k, v in HIVM_MEM_MAPPING.items()}
    if mem_loc in reverse_mapping:
        return reverse_mapping[mem_loc]
    raise ValueError(f"No HIVM memory space mapping for MemLoc: {mem_loc}")