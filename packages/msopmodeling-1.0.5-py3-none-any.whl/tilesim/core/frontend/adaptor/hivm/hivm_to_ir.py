# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
"""
HIVM MLIR到KernelIR的转换器

直接将HIVM MLIR格式解析为KernelIR，避免InstEvent中间层，提高效率。
"""
import re
from typing import Optional

from core.common.backend_config import BackendConfig
from core.common.entity import DType, MemLoc, OpLevel, CoreType, CoreUnit
from core.common.tile_op_enum import TileOpCode
from core.frontend.ir.core.ir import KernelIR
from core.frontend.ir.core.ir_entity import TensorIR, VarIR
from core.frontend.ir.core.ir_logistic import TaskIR, ForIR, OpIR
from core.frontend.ir.core.ir_math import ConstExprIR, VarExprIR, RangeIR
from core.frontend.adaptor.hivm.hivm_op_mapping import hivm_op_to_tileopcode, is_sync_op
from core.frontend.adaptor.hivm.hivm_parser import (
    parse_memref, parse_for_loop, parse_func_def, parse_constant,
    extract_hivm_instruction, parse_instruction_operands, parse_dtype,
    extract_operand_type_pairs, parse_arith_operation, get_arith_op_tile_code,
    parse_sync_flag_instruction,
    ForLoopInfo, FuncInfo, ArithOpInfo, SyncFlagInfo
)
from core.frontend.adaptor.hivm.hivm_utils import clean_mlir_line, get_core_type_from_hivm


class HIVMToIrBuilder:
    """
    HIVM MLIR到KernelIR的转换器

    解析HIVM MLIR格式，直接生成KernelIR，用于后端仿真。
    """

    def __init__(self, mlir_code: str, param, backend_config: BackendConfig):
        """
        初始化HIVM IR构建器

        Args:
            mlir_code: HIVM MLIR代码字符串
            param: 额外参数
            backend_config: 后端配置
        """
        self.mlir_code = mlir_code
        self.param = param
        self.backend_config = backend_config
        self.kernel_ir = KernelIR("HIVM")

        # 变量注册表：存储所有定义的变量
        self.var_registry: dict[str, any] = {}  # 变量名 -> 值
        self.tensor_registry: dict[str, TensorIR] = {}  # 张量名 -> TensorIR
        # 张量源映射：追踪张量来自哪个源张量（用于解析动态形状）
        self.tensor_source_map: dict[str, str] = {}  # 目标张量名 -> 源张量名

        # 当前处理的函数信息
        self.current_core_type: CoreType = CoreType.MIX
        self.current_func_name: str = ""

        # 从 param.input_dict 初始化变量注册表
        if param is not None and hasattr(param, 'input_dict') and param.input_dict:
            for key, value in param.input_dict.items():
                # 确保key以%开头
                if not key.startswith('%'):
                    key = f'%{key}'
                self.var_registry[key] = value

    def parse(self) -> KernelIR:
        """
        解析HIVM MLIR代码，生成KernelIR

        Returns:
            KernelIR对象
        """
        lines = self.mlir_code.split('\n')
        lines = [clean_mlir_line(line) for line in lines]
        lines = [line for line in lines if line]  # 移除空行

        i = 0
        while i < len(lines):
            line = lines[i]

            # 解析函数定义
            if line.startswith('func.func'):
                func_info = parse_func_def(lines, i)
                if func_info:
                    self._parse_function(func_info)
                    i = func_info.body_lines.__len__() + i + 2  # 跳过函数体
                    continue

            # 解析常量定义
            const_info = parse_constant(line)
            if const_info:
                var_name, value, dtype = const_info
                self.var_registry[var_name] = value
                i += 1
                continue

            i += 1

        return self.kernel_ir

    def _parse_function(self, func_info: FuncInfo):
        """
        解析函数定义，生成TaskIR

        Args:
            func_info: 函数信息
        """
        self.current_func_name = func_info.name
        self.current_core_type = get_core_type_from_hivm(func_info.attrs)

        # 保存当前变量注册表状态（只保存 input_dict 中的值和常量）
        # 这样每个函数都能独立计算自己的变量值
        saved_var_registry = {}
        for key, value in self.var_registry.items():
            # 只保存函数参数和常量定义
            if key.startswith('%arg') or key.startswith('%c'):
                saved_var_registry[key] = value

        # 保存当前tensor注册表状态（每个函数独立处理自己的tensor）
        saved_tensor_registry = dict(self.tensor_registry)
        saved_tensor_source_map = dict(self.tensor_source_map)

        # 创建TaskIR
        task_name = f"{func_info.name}_task"
        task = TaskIR(indices=[], body=[], task_name=task_name)

        # 解析函数参数，创建输入张量
        for arg_name, arg_type, arg_attrs in func_info.args:
            if 'memref' in arg_type:
                tensor_ir = self._parse_memref_to_tensor(arg_type, arg_name)
                if tensor_ir:
                    self.tensor_registry[arg_name] = tensor_ir

        # 解析函数体
        body_result = self._parse_function_body(func_info.body_lines, task)
        if isinstance(body_result, ForIR):
            task.body.append(body_result)

        # 设置TaskIR的核类型
        task_entity = task.to_entity()
        task_entity.core_type = self.current_core_type

        self.kernel_ir.add_op(task)

        # 恢复变量注册表状态（为下一个函数准备）
        self.var_registry = saved_var_registry
        # 恢复tensor注册表状态（为下一个函数准备）
        self.tensor_registry = saved_tensor_registry
        self.tensor_source_map = saved_tensor_source_map

    def _parse_function_body(self, body_lines: list[str], task: TaskIR) -> TaskIR | ForIR:
        """
        解析函数体

        Args:
            body_lines: 函数体行列表
            task: 当前TaskIR

        Returns:
            处理后的TaskIR或最外层的ForIR
        """
        i = 0
        outer_loops = []

        while i < len(body_lines):
            line = body_lines[i].strip()

            # 解析常量定义
            const_info = parse_constant(line)
            if const_info:
                var_name, value, dtype = const_info
                self.var_registry[var_name] = value
                i += 1
                continue

            # 解析scf.for循环
            if line.startswith('scf.for'):
                for_info = parse_for_loop(body_lines, i)
                if for_info:
                    for_ir = self._parse_scf_for(for_info, task)
                    if for_ir:
                        outer_loops.append(for_ir)
                    i = for_info.end_line_idx + 1
                    continue

            # 解析HIVM指令
            hivm_inst = extract_hivm_instruction(line)
            if hivm_inst:
                op_ir = self._parse_hivm_instruction(line)
                if op_ir:
                    task.body.append(op_ir)
                i += 1
                continue

            # 解析arith操作 (如 arith.addi, arith.muli 等)
            arith_op_info = parse_arith_operation(line)
            if arith_op_info:
                op_ir = self._parse_arith_instruction(arith_op_info)
                if op_ir:
                    task.body.append(op_ir)
                i += 1
                continue

            # 解析其他赋值语句
            if '=' in line and not line.startswith('}'):
                self._parse_assignment(line)
                i += 1
                continue

            i += 1

        # 如果有外层循环，返回第一个循环
        if outer_loops:
            return outer_loops[0]

        return task

    def _parse_scf_for(self, for_info: ForLoopInfo, task: TaskIR) -> Optional[ForIR]:
        """
        解析scf.for循环，生成ForIR

        Args:
            for_info: 循环信息
            task: 当前TaskIR

        Returns:
            ForIR对象
        """
        # 解析循环范围
        lower_bound = self._parse_bound(for_info.lower_bound)
        upper_bound = self._parse_bound(for_info.upper_bound)
        step = self._parse_bound(for_info.step)

        # 创建循环变量
        iter_var_name = for_info.iter_var
        range_ir = RangeIR(
            start=ConstExprIR(lower_bound) if isinstance(lower_bound, int) else lower_bound,
            end=ConstExprIR(upper_bound) if isinstance(upper_bound, int) else upper_bound,
            step=ConstExprIR(step) if isinstance(step, int) else step
        )
        for_range = VarIR(name=iter_var_name, value=range_ir)

        # 解析循环体
        body = []
        i = 0
        body_lines = for_info.body_lines

        while i < len(body_lines):
            line = body_lines[i].strip()

            # 嵌套循环
            if line.startswith('scf.for'):
                nested_for_info = parse_for_loop(body_lines, i)
                if nested_for_info:
                    nested_for_ir = self._parse_scf_for(nested_for_info, task)
                    if nested_for_ir:
                        body.append(nested_for_ir)
                    i = nested_for_info.end_line_idx + 1
                    continue

            # HIVM指令
            hivm_inst = extract_hivm_instruction(line)
            if hivm_inst:
                op_ir = self._parse_hivm_instruction(line)
                if op_ir:
                    body.append(op_ir)
                i += 1
                continue

            # 常量定义
            const_info = parse_constant(line)
            if const_info:
                var_name, value, dtype = const_info
                self.var_registry[var_name] = value
                i += 1
                continue

            # 解析arith操作
            arith_op_info = parse_arith_operation(line)
            if arith_op_info:
                op_ir = self._parse_arith_instruction(arith_op_info)
                if op_ir:
                    body.append(op_ir)
                i += 1
                continue

            # 其他赋值语句
            if '=' in line and not line.startswith('}'):
                self._parse_assignment(line)
                i += 1
                continue

            i += 1

        # 创建ForIR
        scope_id = f"for_{iter_var_name}"
        return ForIR(scope_id=scope_id, range=for_range, body=body)

    def _convert_to_tensor_ir(self, var_type_pairs, line) -> list[TensorIR]:
        tensor_irs = []
        for var_name, type_str in var_type_pairs:
            if var_name in self.tensor_registry:
                tensor_irs.append(self.tensor_registry[var_name])
            elif type_str and 'memref' in type_str:
                # 从类型字符串创建张量
                tensor = self._parse_memref_to_tensor(type_str, var_name)
                if tensor:
                    self.tensor_registry[var_name] = tensor
                    tensor_irs.append(tensor)
            else:
                # 创建临时张量
                temp_tensor = self._create_temp_tensor(var_name, line, is_input=True)
                if temp_tensor:
                    tensor_irs.append(temp_tensor)
        return tensor_irs

    def _parse_hivm_instruction(self, line: str) -> Optional[OpIR]:
        """
        解析HIVM指令，生成OpIR

        Args:
            line: HIVM指令行

        Returns:
            OpIR对象，如果指令不需要生成操作则返回None
        """
        line = line.strip()

        # 提取指令名
        hivm_inst = extract_hivm_instruction(line)
        if not hivm_inst:
            return None

        op_name, full_inst = hivm_inst

        # 特殊处理：为运行时值的指令提供默认值
        self._handle_runtime_value_instruction(line, op_name)

        # 获取TileOpCode
        try:
            op_code = hivm_op_to_tileopcode(op_name)
        except ValueError:
            # 未知指令，跳过
            return None

        if op_code is None:
            # 不需要生成操作的指令（如pointer_cast）
            # 但仍需注册tensor到registry
            self._handle_non_op_instruction(line, op_name)
            return None

        # 解析操作数（变量-类型对）
        input_pairs, output_pairs = extract_operand_type_pairs(line)

        # 解析属性
        _, _, attrs = parse_instruction_operands(line)

        # 特殊处理 mmadL1 操作
        if 'mmadL1' in op_name or 'batchMmadL1' in op_name:
            return self._parse_mmadL1_instruction(line, op_code, input_pairs, output_pairs, attrs)

        # 转换输入输出为TensorIR
        input_tensors = self._convert_to_tensor_ir(input_pairs, line)
        output_tensors = self._convert_to_tensor_ir(output_pairs, line)

        # 特殊处理同步指令
        if is_sync_op(op_name):
            sync_info = parse_sync_flag_instruction(line)
            if sync_info:
                return self._create_sync_op_ir(sync_info, op_name)
            # 如果解析失败，使用旧的默认方式
            config = {'sync_type': op_name}
            return OpIR(OpLevel.TILE_OP, TileOpCode.BARRIER, input_tensors, output_tensors, config)

        return OpIR(OpLevel.TILE_OP, op_code, input_tensors, output_tensors, attrs if attrs else None)

    def _create_set_flag(self, sync_info: SyncFlagInfo, op_name: str):
        # 格式：set_flag[<PIPE_src>, <PIPE_dst>, <EVENT_ID>]
        # 语义：当 PIPE_src 中之前的指令都执行完后，设置标志位为1
        # flag_id 由 src_pipe 和 event_id 组成（因为 wait_flag 检查的是 src_pipe 的标志）
        src_unit = self._pipe_to_core_unit(sync_info.src_pipe)
        dst_unit = self._pipe_to_core_unit(sync_info.dst_pipe)

        # 解析 event_id 的实际值
        resolved_event_id = self._resolve_event_id(sync_info.event_id)

        # flag_id 用于匹配 set/wait 对，使用 src_pipe 和解析后的 event_id
        flag_id = f"{sync_info.src_pipe}_{resolved_event_id}"

        config = {'sync_type': op_name,
                  'src_unit': src_unit,
                  'dst_unit': dst_unit,
                  'flag_id': flag_id,
                  'event_id': resolved_event_id,
                  'event_id_orig': sync_info.event_id,
                  'src_pipe': sync_info.src_pipe,
                  'dst_pipe': sync_info.dst_pipe}

        return OpIR(OpLevel.TILE_OP, TileOpCode.SET_FLAG, [], [], config)

    def _create_wait_flag(self, sync_info: SyncFlagInfo, op_name: str):
        # 格式：wait_flag[<PIPE_src>, <PIPE_dst>, <EVENT_ID>]
        # 语义：当执行到 wait_flag，如果 PIPE_src 标志位为0，阻塞 PIPE_dst
        # 如果标志位为1，PIPE_dst 后续指令开始执行，同时标志位设为0
        src_unit = self._pipe_to_core_unit(sync_info.src_pipe)
        dst_unit = self._pipe_to_core_unit(sync_info.dst_pipe)

        # 解析 event_id 的实际值
        resolved_event_id = self._resolve_event_id(sync_info.event_id)

        # flag_id 用于匹配 set/wait 对，使用 src_pipe 和解析后的 event_id
        flag_id = f"{sync_info.src_pipe}_{resolved_event_id}"

        config = {'sync_type': op_name,
                  'src_unit': src_unit,
                  'dst_unit': dst_unit,
                  'flag_id': flag_id,
                  'event_id': resolved_event_id,
                  'event_id_orig': sync_info.event_id,
                  'src_pipe': sync_info.src_pipe,
                  'dst_pipe': sync_info.dst_pipe}

        return OpIR(OpLevel.TILE_OP, TileOpCode.WAIT_FLAG, [], [], config)

    def _create_sync_block_set(self, sync_info: SyncFlagInfo, op_name: str):
        # 格式：sync_block_set[<CUBE/VECTOR>, <PIPE_xxx>, <PIPE_S>] flag = N
        # 语义：当本核指定pipe的操作都完成后，给对方核发送信号
        # 参数说明：
        #   - <CUBE/VECTOR>: 本核类型（CUBE=AIC, VECTOR=AIV）
        #   - <PIPE_xxx>: 要查询完成情况的流水线组件
        #   - <PIPE_S>: 不重要，对仿真无影响
        #   - flag: 用于匹配 set/wait 对的标志号（跨核共享）
        #
        # 示例：sync_block_set[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag=2
        # 含义：当本核（AIC）的 MTE2 操作都执行完后，给对方核（AIV）发送信号
        src_unit = self._pipe_to_core_unit(sync_info.src_pipe)
        dst_unit = self._pipe_to_core_unit(sync_info.dst_pipe)
        core_type_str = sync_info.core_type  # CUBE (AIC) 或 VECTOR (AIV)，表示本核类型
        pipe = sync_info.src_pipe  # 要查询的流水线组件
        flag_num = sync_info.flag

        # 将字符串转换为 CoreType 枚举
        if core_type_str == 'CUBE':
            core_type = CoreType.AIC
        elif core_type_str == 'VECTOR':
            core_type = CoreType.AIV
        else:
            core_type = self.current_core_type

        # 构造 flag_id：只使用 flag_num，因为同一个 flag 跨核共享
        flag_id = f"block_{flag_num}"

        config = {'sync_type': op_name,
                  'src_unit': src_unit,
                  'dst_unit': dst_unit,
                  'flag_id': flag_id,
                  'core_type': core_type,  # 设置方的核类型
                  'flag_num': flag_num,
                  'pipe': pipe}

        return OpIR(OpLevel.TILE_OP, TileOpCode.SET_FLAG, [], [], config)

    def _create_sync_block_wait(self, sync_info: SyncFlagInfo, op_name: str):
        # 格式：sync_block_wait[<CUBE/VECTOR>, <PIPE_xxx>, <PIPE_S>] flag = N
        # 语义：阻塞本核所有组件，直到收到对方核的信号
        # 参数说明：
        #   - <CUBE/VECTOR>: 本核类型（CUBE=AIC, VECTOR=AIV）
        #   - <PIPE_xxx>: 等待的数据类型（信息性，不影响仿真逻辑）
        #   - <PIPE_S>: 不重要，对仿真无影响
        #   - flag: 用于匹配 set/wait 对的标志号（跨核共享）
        #
        # 示例：sync_block_wait[<VECTOR>, <PIPE_MTE2>, <PIPE_S>] flag=2
        # 含义：阻塞本核（AIV）所有组件，直到收到对方核（AIC）的信号
        src_unit = self._pipe_to_core_unit(sync_info.src_pipe, True)
        dst_unit = self._pipe_to_core_unit(sync_info.dst_pipe)
        core_type_str = sync_info.core_type  # CUBE (AIC) 或 VECTOR (AIV)，表示本核类型
        flag_num = sync_info.flag

        # 将字符串转换为 CoreType 枚举
        if core_type_str == 'CUBE':
            core_type = CoreType.AIC
        elif core_type_str == 'VECTOR':
            core_type = CoreType.AIV
        else:
            core_type = self.current_core_type

        # 构造 flag_id：只使用 flag_num，与 sync_block_set 保持一致
        flag_id = f"block_{flag_num}"

        # sync_block_wait 阻塞本核所有组件，不指定特定组件
        config = {'sync_type': op_name,
                  'src_unit': src_unit,
                  'dst_unit': None,  # None表示阻塞AIC或AIV所有组件
                  'flag_id': flag_id,
                  'core_type': core_type,  # 等待方的核类型
                  'flag_num': flag_num}

        return OpIR(OpLevel.TILE_OP, TileOpCode.WAIT_FLAG, [], [], config)

    def _create_pipe_barrier(self, sync_info: SyncFlagInfo, op_name: str):
        # 格式：pipe_barrier[<PIPE_xxx>]
        # 流水线屏障，等待该流水线所有操作完成
        pipe = sync_info.src_pipe
        unit = self._pipe_to_core_unit(pipe)

        config = {'sync_type': op_name,
                  'unit': unit.desc if unit else None,
                  'pipe': pipe}

        return OpIR(OpLevel.TILE_OP, TileOpCode.BARRIER, [], [], config)

    def _create_sync_op_ir(self, sync_info: SyncFlagInfo, op_name: str) -> Optional[OpIR]:
        """
        创建同步操作的OpIR

        Args:
            sync_info: 同步指令解析信息
            op_name: 操作名称

        Returns:
            OpIR对象
        """
        if sync_info.op_type == 'set_flag':
            return self._create_set_flag(sync_info, op_name)
        elif sync_info.op_type == 'wait_flag':
            return self._create_wait_flag(sync_info, op_name)
        elif sync_info.op_type == 'sync_block_set':
            return self._create_sync_block_set(sync_info, op_name)
        elif sync_info.op_type == 'sync_block_wait':
            return self._create_sync_block_wait(sync_info, op_name)
        elif sync_info.op_type == 'pipe_barrier':
            return self._create_pipe_barrier(sync_info, op_name)

        # 默认返回 BARRIER
        return OpIR(OpLevel.TILE_OP, TileOpCode.BARRIER, [], [], {'sync_type': op_name})

    def _pipe_to_core_unit(self, pipe: str, other_core_type: bool = False) -> Optional[CoreUnit]:
        """
        将HIVM流水线名称转换为CoreUnit枚举值

        Args:
            pipe: 流水线名称 (如 PIPE_M, PIPE_V, PIPE_MTE2, PIPE_S)
            other_core_type: 是否用对方核类型去查找

        Returns:
            CoreUnit枚举值
        """
        # 流水线到CoreUnit的映射
        # AIC流水线
        aic_pipe_mapping = {
            'PIPE_M': CoreUnit.CUBE,
            'PIPE_MTE1': CoreUnit.AIC_MTE1,
            'PIPE_MTE2': CoreUnit.AIC_MTE2,
            'PIPE_MTE3': CoreUnit.AIC_MTE3,
            'PIPE_FIX': CoreUnit.AIC_FIXPIPE,
            'PIPE_FIXPIPE': CoreUnit.AIC_FIXPIPE,
            'PIPE_S': CoreUnit.AIC_SCALAR,  # AIC Scalar 组件
        }

        # AIV流水线
        aiv_pipe_mapping = {
            'PIPE_V': CoreUnit.VEC,
            'PIPE_MTE2': CoreUnit.AIV_MTE2,
            'PIPE_MTE3': CoreUnit.AIV_MTE3,
            'PIPE_S': CoreUnit.AIV_SCALAR,  # AIV Scalar 组件
        }

        # 根据当前核类型选择映射
        if self.current_core_type == CoreType.AIC:
            return aic_pipe_mapping.get(pipe) if other_core_type is False else aiv_pipe_mapping.get(pipe)
        elif self.current_core_type == CoreType.AIV:
            return aiv_pipe_mapping.get(pipe) if other_core_type is False else aic_pipe_mapping.get(pipe)
        else:
            # 尝试从两个映射中查找
            if pipe in aic_pipe_mapping:
                return aic_pipe_mapping[pipe]
            if pipe in aiv_pipe_mapping:
                return aiv_pipe_mapping[pipe]
            return None

    def _resolve_event_id(self, event_id: str) -> str:
        """
        解析 event_id 为实际值

        Args:
            event_id: 事件ID，可能是 <EVENT_ID0> 格式或变量名 %17 格式

        Returns:
            解析后的事件ID字符串，如 "EVENT_ID0"
        """
        # 清理尖括号
        clean_id = event_id.strip('<>')

        # 如果已经是 EVENT_IDx 格式，直接返回
        if clean_id.startswith('EVENT_ID'):
            return clean_id

        # 如果是变量名（如 %17），尝试从 var_registry 获取值
        if clean_id.startswith('%'):
            if clean_id in self.var_registry:
                value = self.var_registry[clean_id]
                if isinstance(value, int):
                    return f"EVENT_ID{value}"
            # 无法解析，返回原始变量名（后续可能需要动态处理）
            return clean_id

        return clean_id

    def _make_flag_id(self, src_pipe: str, event_id: str) -> str:
        """
        构造flag_id，用于匹配set_flag和wait_flag对

        Args:
            src_pipe: 源流水线（标志位所属的流水线）
            event_id: 事件ID

        Returns:
            flag_id字符串
        """
        # 解析 event_id 为实际值
        resolved_event_id = self._resolve_event_id(event_id)
        return f"{src_pipe}_{resolved_event_id}"

    def _handle_runtime_value_instruction(self, line: str, op_name: str) -> None:
        """
        处理产生运行时值的指令，为它们提供默认值

        Args:
            line: 指令行
            op_name: 操作名称
        """
        # 检查是否是产生运行时值的指令
        runtime_value_ops = [
            'hivm.hir.get_block_idx',
            'hivm.hir.get_sub_block_idx',
        ]

        if op_name in runtime_value_ops:
            # 提取结果变量名
            # 格式: %2 = hivm.hir.get_block_idx -> i64
            match = re.match(r'(%\w+)\s*=\s*', line)
            if match:
                var_name = match.group(1)
                # 为运行时值提供默认值 0
                # 用户可以通过 input_dict 覆盖这些值
                if var_name not in self.var_registry:
                    self.var_registry[var_name] = 0

    def _handle_non_op_instruction(self, line: str, op_name: str) -> None:
        """
        处理不需要生成操作的指令（如pointer_cast）

        这些指令虽然不生成操作，但需要注册tensor信息以便后续指令引用

        Args:
            line: 指令行
            op_name: 操作名称
        """
        # 处理 pointer_cast 指令
        if op_name == 'hivm.hir.pointer_cast':
            # 格式: %var = hivm.hir.pointer_cast(...) : memref<...>
            match = re.match(r'(%\w+)\s*=\s*hivm\.hir\.pointer_cast\s*\([^)]*\)\s*:\s*', line)
            if match:
                var_name = match.group(1)
                # 使用 _extract_memref 来正确提取嵌套的 memref
                memref_str = self._extract_memref(line)
                if memref_str:
                    tensor_ir = self._parse_memref_to_tensor(memref_str, var_name)
                    if tensor_ir:
                        self.tensor_registry[var_name] = tensor_ir

    def _parse_mmadL1_instruction(self, line: str, op_code: TileOpCode,
                                  input_pairs: list, output_pairs: list,
                                  attrs: dict) -> Optional[OpIR]:
        """
        特殊解析 mmadL1 指令

        mmadL1 格式:
        hivm.hir.mmadL1 {...} ins(%a, %b, %init_cond, %real_m, %real_k, %real_n : ...)
                         outs(%c : ...)

        输入矩阵A和B是分块格式（4D），实际矩阵维度由 real_m, real_k, real_n 指定
        """
        # 提取矩阵输入 (前两个)
        a_var, a_type = input_pairs[0] if len(input_pairs) > 0 else (None, None)
        b_var, b_type = input_pairs[1] if len(input_pairs) > 1 else (None, None)

        # 提取维度参数 (第4, 5, 6个输入)
        # real_m, real_k, real_n
        real_m_var = input_pairs[3][0] if len(input_pairs) > 3 else None
        real_k_var = input_pairs[4][0] if len(input_pairs) > 4 else None
        real_n_var = input_pairs[5][0] if len(input_pairs) > 5 else None

        # 解析维度值
        m = self._parse_dim_value(real_m_var)
        k = self._parse_dim_value(real_k_var)
        n = self._parse_dim_value(real_n_var)

        # 创建矩阵A (m x k)
        a_tensor = None
        if a_var and a_type and 'memref' in a_type:
            a_tensor = self._create_tensor_with_shape(a_var, a_type, [m, k])
            if a_tensor:
                self.tensor_registry[a_var] = a_tensor

        # 创建矩阵B (k x n)
        b_tensor = None
        if b_var and b_type and 'memref' in b_type:
            b_tensor = self._create_tensor_with_shape(b_var, b_type, [k, n])
            if b_tensor:
                self.tensor_registry[b_var] = b_tensor

        # 创建输出矩阵C (m x n)
        c_var, c_type = output_pairs[0] if output_pairs else (None, None)
        c_tensor = None
        if c_var and c_type and 'memref' in c_type:
            c_tensor = self._create_tensor_with_shape(c_var, c_type, [m, n])
            if c_tensor:
                self.tensor_registry[c_var] = c_tensor

        input_tensors = [t for t in [a_tensor, b_tensor] if t is not None]
        output_tensors = [c_tensor] if c_tensor else []

        return OpIR(OpLevel.TILE_OP, op_code, input_tensors, output_tensors, attrs if attrs else None)

    def _parse_dim_value(self, var_name: str) -> int:
        """解析维度值"""
        if not var_name:
            return 1024  # 默认值

        # 格式: %c64 -> 64
        match = re.match(r'%c(\d+)$', var_name)
        if match:
            return int(match.group(1))

        # 从变量注册表查找
        if var_name in self.var_registry:
            val = self.var_registry[var_name]
            if isinstance(val, int):
                return val

        return 1024  # 默认值

    def _create_tensor_with_shape(self, var_name: str, memref_str: str, shape: list[int]) -> Optional[TensorIR]:
        """使用指定形状创建张量"""
        try:
            memref_info = parse_memref(memref_str)
            shape_ir = [ConstExprIR(dim) for dim in shape]
            return TensorIR(
                name=var_name,
                shape=shape_ir,
                dtype=memref_info.dtype,
                mem_loc=memref_info.mem_loc
            )
        except Exception:
            return None

    def _parse_memref_to_tensor(self, memref_str: str, name: str) -> Optional[TensorIR]:
        """
        从memref类型字符串创建TensorIR

        Args:
            memref_str: memref类型字符串
            name: 张量名称

        Returns:
            TensorIR对象
        """
        memref_info = parse_memref(memref_str)

        # 转换形状
        shape_ir = []
        for dim_idx, dim in enumerate(memref_info.shape):
            if isinstance(dim, int):
                shape_ir.append(ConstExprIR(dim))
            elif dim == '?':
                # 动态维度：使用1024作为默认值，后续可以通过param覆盖
                # 这里使用常量而不是变量，避免undefined variable错误
                shape_ir.append(ConstExprIR(1024))
            else:
                # 解析为整数
                shape_ir.append(ConstExprIR(int(dim)))

        return TensorIR(
            name=name,
            shape=shape_ir,
            dtype=memref_info.dtype,
            mem_loc=memref_info.mem_loc
        )

    def _parse_bound(self, bound_str: str) -> int | VarExprIR:
        """
        解析循环边界表达式

        Args:
            bound_str: 边界表达式字符串

        Returns:
            整数值或VarExprIR
        """
        bound_str = bound_str.strip()

        # 尝试解析为整数常量
        if bound_str.startswith('%c') and '_i' in bound_str:
            # 格式: %c2048_i32 或 %c-1_i64
            match = re.match(r'%c(-?\d+)_i\d+', bound_str)
            if match:
                return int(match.group(1))

        # 尝试从变量注册表获取
        if bound_str in self.var_registry:
            value = self.var_registry[bound_str]
            if isinstance(value, (int, float)):
                return int(value)
            # 如果是表达式，需要进一步解析
            if isinstance(value, str):
                # 尝试解析常量表达式
                if value.isdigit() or (value.startswith('-') and value[1:].isdigit()):
                    return int(value)

        # 处理 %argN 格式的变量引用 - 这是函数参数
        if bound_str.startswith('%arg'):
            # 这是函数参数引用，保留完整变量名（含%前缀）
            return VarExprIR(bound_str)

        # 处理 %N 格式的计算结果引用 (如 %6, %7)
        if bound_str.startswith('%') and bound_str[1:].lstrip('-').isdigit():
            # 这是前序计算的结果，查找其值
            if bound_str in self.var_registry:
                value = self.var_registry[bound_str]
                if isinstance(value, (int, float)):
                    return int(value)
            # 如果没有找到值，返回默认值 0，避免循环边界无法计算
            # 注意：这会导致循环次数为0，但至少不会报错
            # 用户可以通过 input_dict 提供这些值
            return VarExprIR(bound_str)

        # 尝试直接解析为整数
        try:
            return int(bound_str)
        except ValueError:
            pass

        # 返回变量表达式，保留原始格式
        return VarExprIR(bound_str)

    def _parse_assignment(self, line: str):
        """
        解析赋值语句，更新变量注册表

        Args:
            line: 赋值语句行
        """
        line = line.strip()

        # 匹配 %var = expr 格式
        match = re.match(r'(%\w+)\s*=\s*(.+)$', line)
        if match:
            var_name = match.group(1)
            expr = match.group(2).strip()

            # 如果变量已经有值（由 _parse_arith_instruction 计算），跳过
            if var_name in self.var_registry and isinstance(self.var_registry[var_name], (int, float)):
                return

            # 处理运行时值指令（如 get_block_idx）
            if 'hivm.hir.get_block_idx' in expr or 'hivm.hir.get_sub_block_idx' in expr:
                # 为运行时值提供默认值 0
                self.var_registry[var_name] = 0
                return

            # 处理memref.view等操作
            if 'memref.view' in expr:
                # 提取memref信息并创建张量
                memref_match = re.search(r'memref<[^>]+>', expr)
                if memref_match:
                    tensor_ir = self._parse_memref_to_tensor(memref_match.group(0), var_name)
                    if tensor_ir:
                        self.tensor_registry[var_name] = tensor_ir

            # 处理memref.reinterpret_cast - 需要从sizes或目标memref中提取形状
            elif 'memref.reinterpret_cast' in expr:
                self._handle_memref_reinterpret_cast(var_name, expr)

            # 处理memref.cast - 需要从源memref获取形状，而不是目标memref的动态形状
            elif 'memref.cast' in expr:
                self._handle_memref_cast(var_name, expr)

            # 处理pointer_cast
            elif 'pointer_cast' in expr:
                memref_match = re.search(r'memref<[^>]+>', expr)
                if memref_match:
                    tensor_ir = self._parse_memref_to_tensor(memref_match.group(0), var_name)
                    if tensor_ir:
                        self.tensor_registry[var_name] = tensor_ir

            # 处理算术运算 - 由 _parse_arith_instruction 处理，这里不再重复处理

    def _handle_memref_reinterpret_cast(self, var_name: str, expr: str):
        """
        处理memref.reinterpret_cast操作，从sizes或目标memref中提取形状

        memref.reinterpret_cast 格式:
        %var = memref.reinterpret_cast %src to offset: [...], sizes: [dim1, dim2, ...], strides: [...] : src_type to dst_type

        Args:
            var_name: 目标变量名
            expr: 表达式字符串
        """
        # 尝试从sizes属性中提取形状
        # 格式: sizes: [dim1, dim2, ...]
        sizes_match = re.search(r'sizes:\s*\[([^\]]+)\]', expr)
        if sizes_match:
            sizes_str = sizes_match.group(1)
            # 解析每个维度
            shape = []
            for dim_str in sizes_str.split(','):
                dim_str = dim_str.strip()
                # 尝试解析为整数
                try:
                    shape.append(int(dim_str))
                except ValueError:
                    # 可能是变量引用，如 %arg15
                    # 尝试从var_registry获取值
                    if dim_str in self.var_registry:
                        val = self.var_registry[dim_str]
                        if isinstance(val, int):
                            shape.append(val)
                        else:
                            shape.append(1024)  # 默认值
                    else:
                        shape.append(1024)  # 默认值

            # 提取memref信息获取dtype和mem_loc
            memref_str = self._extract_memref(expr)
            if memref_str:
                memref_info = parse_memref(memref_str)
                shape_ir = [ConstExprIR(dim) for dim in shape]
                tensor_ir = TensorIR(
                    name=var_name,
                    shape=shape_ir,
                    dtype=memref_info.dtype,
                    mem_loc=memref_info.mem_loc
                )
                self.tensor_registry[var_name] = tensor_ir
                return

        # 如果无法从sizes提取，尝试从目标memref提取
        # 目标memref是最后一个memref<...>
        memref_str = self._extract_memref(expr)
        if memref_str:
            tensor_ir = self._parse_memref_to_tensor(memref_str, var_name)
            if tensor_ir:
                self.tensor_registry[var_name] = tensor_ir

    def _handle_memref_cast(self, var_name: str, expr: str):
        """
        处理memref.cast操作，从源tensor获取形状

        memref.cast 格式:
        %cast = memref.cast %src : memref<固定形状> to memref<?x?x?...>

        对于目标memref带有动态形状(?)的情况，使用源memref的固定形状

        Args:
            var_name: 目标变量名
            expr: 表达式字符串
        """
        # 提取源变量名
        # 格式: memref.cast %src : ...
        src_match = re.search(r'memref\.cast\s+(%\w+)', expr)
        if not src_match:
            return
        src_var = src_match.group(1)

        # 提取源memref类型（第一个memref<...>，它有固定形状）
        # 格式: memref.cast %src : memref<固定形状> to memref<动态形状>
        src_memref = self._extract_memref(expr, src_var)

        # 尝试提取目标memref类型
        dst_memref_match = re.search(r'to\s+(memref<[^>]+>)', expr)
        if dst_memref_match:
            dst_memref = dst_memref_match.group(1)
        else:
            dst_memref = None

        # 记录源tensor映射关系
        self.tensor_source_map[var_name] = src_var

        # 检查源tensor是否已在registry中
        if src_var in self.tensor_registry:
            # 直接使用源tensor的形状创建目标tensor
            src_tensor = self.tensor_registry[src_var]
            tensor_ir = TensorIR(
                name=var_name,
                shape=src_tensor.shape,
                dtype=src_tensor.dtype,
                mem_loc=src_tensor.mem_loc
            )
            self.tensor_registry[var_name] = tensor_ir
        elif src_memref:
            # 从源memref创建tensor
            tensor_ir = self._parse_memref_to_tensor(src_memref, var_name)
            if tensor_ir:
                self.tensor_registry[var_name] = tensor_ir

    def _parse_arith_instruction(self, arith_op_info: ArithOpInfo) -> Optional[OpIR]:
        """
        解析arith操作，生成OpIR

        Args:
            arith_op_info: scalar算术操作信息

        Returns:
            OpIR对象
        """
        # 获取指令映射
        inst_name, raw_inst_name = get_arith_op_tile_code(arith_op_info.op_name)
        if inst_name == 'UNKNOWN':
            return None

        # 解析数据类型
        dtype = parse_dtype(arith_op_info.dtype)

        # 尝试计算算术表达式的值并记录到 var_registry
        self._try_eval_arith_op(arith_op_info)

        # 确定内存位置 - Scalar 操作的内存位置不重要，使用默认值
        mem_loc = MemLoc.UB if self.current_core_type == CoreType.AIV else MemLoc.L1
        if inst_name == 'SCALAR_OP':
            inst_name = 'SCALAR_AIV' if self.current_core_type == CoreType.AIV else 'SCALAR_AIC'

        # 创建输入张量
        input_tensors = []
        for operand in arith_op_info.operands:
            if operand in self.tensor_registry:
                input_tensors.append(self.tensor_registry[operand])
            else:
                # 创建临时张量
                temp_tensor = self._create_scalar_tensor_with_mem(operand, dtype, mem_loc)
                self.tensor_registry[operand] = temp_tensor
                input_tensors.append(temp_tensor)

        # 创建输出张量
        output_tensor = self._create_scalar_tensor_with_mem(arith_op_info.result_var, dtype, mem_loc)
        self.tensor_registry[arith_op_info.result_var] = output_tensor

        # 创建OpIR
        try:
            op_code = TileOpCode[inst_name]
        except KeyError:
            # 未知操作码，使用NULL_OP
            op_code = TileOpCode.NULL_OP

        return OpIR(
            OpLevel.TILE_OP,
            op_code,
            input_tensors,
            [output_tensor],
            {'raw_inst_name': raw_inst_name}
        )

    def __eval_arith_op(self, operand_values, op_name):
        result = None

        if len(operand_values) >= 2:
            a, b = operand_values[0], operand_values[1]
            if op_name == 'arith.addi' or op_name == 'arith.addf':
                result = a + b
            elif op_name == 'arith.subi' or op_name == 'arith.subf':
                result = a - b
            elif op_name == 'arith.muli' or op_name == 'arith.mulf' or op_name == 'arith.mulsi':
                result = a * b
            elif op_name == 'arith.divsi' or op_name == 'arith.divf':
                if b != 0:
                    result = a // b if op_name == 'arith.divsi' else a / b
            elif op_name == 'arith.divui':
                if b != 0:
                    result = int(a) // int(b)
            elif op_name == 'arith.remsi':
                if b != 0:
                    result = a % b
            elif op_name == 'arith.minsi':
                result = min(a, b)
            elif op_name == 'arith.maxsi':
                result = max(a, b)
            elif op_name == 'arith.minf':
                result = min(a, b)
            elif op_name == 'arith.maxf':
                result = max(a, b)
            elif op_name == 'arith.andi':
                result = int(a) & int(b)
            elif op_name == 'arith.ori':
                result = int(a) | int(b)
            elif op_name == 'arith.xori':
                result = int(a) ^ int(b)
            elif op_name == 'arith.shli':
                result = int(a) << int(b)
            elif op_name == 'arith.shrsi' or op_name == 'arith.shrui':
                result = int(a) >> int(b)
        elif len(operand_values) == 1:
            a = operand_values[0]
            if op_name == 'arith.negf':
                result = -a
            elif op_name == 'arith.trunci' or op_name == 'arith.extsi' or op_name == 'arith.extui':
                # 类型转换操作，直接返回值
                result = int(a)
            elif op_name == 'arith.extf' or op_name == 'arith.truncf':
                # 浮点类型转换
                result = a
            elif op_name == 'arith.index_cast' or op_name == 'arith.index_castui':
                # index 类型转换
                result = int(a)
        return result

    def _try_eval_arith_op(self, arith_op_info: ArithOpInfo) -> None:
        """
        尝试计算算术操作的值并记录到 var_registry

        Args:
            arith_op_info: 算术操作信息
        """
        # 获取操作数的值
        operand_values = []
        for operand in arith_op_info.operands:
            if operand in self.var_registry:
                val = self.var_registry[operand]
                if isinstance(val, (int, float)):
                    operand_values.append(val)
                else:
                    # 无法计算
                    return
            else:
                # 操作数未知，无法计算
                return

        # 根据操作类型计算结果
        op_name = arith_op_info.op_name
        result = self.__eval_arith_op(operand_values, op_name)

        # 如果计算成功，记录结果
        if result is not None:
            # 确保结果是整数（对于整数类型）
            if arith_op_info.dtype.startswith('i') or arith_op_info.dtype.startswith('u'):
                result = int(result)
            self.var_registry[arith_op_info.result_var] = result

    def _create_scalar_tensor_with_mem(self, var_name: str, dtype: DType, mem_loc: MemLoc) -> TensorIR:
        """
        创建标量张量，指定内存位置

        Args:
            var_name: 变量名
            dtype: 数据类型
            mem_loc: 内存位置

        Returns:
            TensorIR对象
        """
        name = var_name
        return TensorIR(
            name=name,
            shape=[ConstExprIR(1)],
            dtype=dtype,
            mem_loc=mem_loc
        )

    def _create_scalar_tensor(self, var_name: str, dtype: DType) -> TensorIR:
        """
        创建标量张量

        Args:
            var_name: 变量名
            dtype: 数据类型

        Returns:
            TensorIR对象
        """
        name = var_name
        return TensorIR(
            name=name,
            shape=[ConstExprIR(1)],
            dtype=dtype,
            mem_loc=MemLoc.UB if self.current_core_type == CoreType.AIV else MemLoc.L1
        )

    def _create_temp_tensor(self, var_name: str, line: str, is_input: bool) -> Optional[TensorIR]:
        """
        创建临时张量

        Args:
            var_name: 变量名
            line: 所在行
            is_input: 是否为输入

        Returns:
            TensorIR对象
        """
        # 尝试从行中提取memref信息（支持嵌套<>）
        memref_str = self._extract_memref(line)
        if memref_str:
            return self._parse_memref_to_tensor(memref_str, var_name)

        # 创建默认张量
        return TensorIR(
            name=var_name,
            shape=[ConstExprIR(1)],
            dtype=DType.FP32,
            mem_loc=MemLoc.UB if self.current_core_type == CoreType.AIV else MemLoc.L1
        )

    def _extract_memref(self, line: str, var_name: str = None) -> Optional[str]:
        """
        从行中提取memref字符串（支持嵌套<>）

        Args:
            line: 代码行
            var_name: 可选的变量名，用于提取该变量对应的memref

        Returns:
            memref字符串，如果未找到返回None
        """
        if var_name:
            # 查找特定变量对应的memref
            # 格式: %var_name : memref<...>
            pattern = re.escape(var_name) + r'\s*:\s*(memref<)'
            match = re.search(pattern, line)
            if match:
                start = match.start(1)
                # 从memref<开始，找到匹配的>
                i = start + 7  # 跳过 'memref<'
                depth = 1
                while i < len(line) and depth > 0:
                    if line[i] == '<':
                        depth += 1
                    elif line[i] == '>':
                        depth -= 1
                    i += 1
                return line[start:i]

        # 提取第一个memref
        start = line.find('memref<')
        if start == -1:
            return None

        depth = 1
        i = start + 7  # 跳过 'memref<'
        while i < len(line) and depth > 0:
            if line[i] == '<':
                depth += 1
            elif line[i] == '>':
                depth -= 1
            i += 1
        return line[start:i]


def build_ir_from_hivm(mlir_code: str, param, backend_config: BackendConfig) -> KernelIR:
    """
    从HIVM MLIR代码构建KernelIR

    Args:
        mlir_code: HIVM MLIR代码字符串
        param: 额外参数
        backend_config: 后端配置

    Returns:
        KernelIR对象
    """
    builder = HIVMToIrBuilder(mlir_code, param, backend_config)
    ret = builder.parse()
    return ret