# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from core.frontend.adaptor.hivm.hivm_to_ir import build_ir_from_hivm, HIVMToIrBuilder

__all__ = ['build_ir_from_hivm', 'HIVMToIrBuilder']