# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from core.common.entity import CoreUnit


class EvaluationType(Enum):
    # 0表示Eng
    ENG_PIPE_BY_RULE = (0, 'eng_pipe_by_rule')
    # 1表示Theo
    THEO_OPTIMAL_PIPE = (1, 'theo_optimal_pipe')

    @staticmethod
    def from_str(s):
        for item in EvaluationType:
            if s in item.value:
                return item
        raise ValueError(f'invalid evaluation type: {s}')


class OptimType(Enum):
    MATMUL_OPTIM = 'matmul_optim'
    ADAPTOR_BYPASS_OPTIM = 'adaptor_bypass_optim'
    GENERAL_BY_SEQ_OPTIM = 'general_by_seq_optim'


class FitParamKey(Enum):
    BW_COEFF = ('bw_coeff', 1.0)
    COMP_COEFF = ('comp_coeff', 1.0)
    SCALAR_TIME = ('scalar_time', 0.0)

    def __init__(self, key, default_value):
        self.key = key
        self.default_value = default_value


@dataclass
class TaskIndexConfig:
    """对工程可达的下标进行的配置，主要用于分核，如无配置，则按照task index的默认顺序"""
    # 需要参与分核的下标名称，如 i,j,k
    index_name: str
    # 分核的顺序编号，越小的越靠近外层循环，如编号相同，则按照下标的字母顺序排序
    seq_num: int = 0
    # 分核的stride，如果数值为 n，就表示下标迭代 n次，核 id++，-1表示不分核
    split_core_stride: int = -1
    # 是否开启Z字型遍历，若开启，则在该下标的外层下标，进行Z字型遍历（如i,j，j开启之后，i与i+1的j轴遍历方向相反）
    enable_swizzle: bool = False


@dataclass
class OptimConfig:
    """之后遇到新的需要补充的后端config，继承该类实现"""
    # 后端optim的类型
    optim_method: OptimType = OptimType.GENERAL_BY_SEQ_OPTIM
    # 需要寻优参数的可选范围，如果不填，则按照默认规则进行。目前，主要是支持tile size寻优
    tuning_candidates: list[dict[str, Any]] = None
    # 任务的分核配置等设定
    task_index_config: dict[str, list[TaskIndexConfig]] = None


class MutexComponents:
    def __init__(self, component: CoreUnit, mutex_components: list[CoreUnit]):
        self.mutex_map = {}  # key=组件名，value=该组件的互斥组件集合
        self.add_mutex(component, mutex_components)

    def add_mutex(self, component: CoreUnit, mutex_components: list[CoreUnit]):
        """
        添加组件的互斥关系（支持单个/多个互斥组件）
        :param component: 主组件
        :param mutex_components: 与主组件互斥的一个或多个组件
        """
        # 过滤空值和自身互斥的无效配置
        valid_mutex = [mc for mc in mutex_components if mc and mc != component]
        if not valid_mutex:
            return

        # 为主组件添加互斥组件
        if component not in self.mutex_map:
            self.mutex_map[component] = set()
        self.mutex_map[component].update(valid_mutex)

        # 对称补全：为每个互斥组件添加当前主组件作为互斥项
        for mc in valid_mutex:
            if mc not in self.mutex_map:
                self.mutex_map[mc] = set()
            self.mutex_map[mc].add(component)

    def get_mutex(self, component) -> set[CoreUnit]:
        """
        获取指定组件的所有互斥组件
        :param component: 目标组件
        :return: 互斥组件集合（无则返回空集合）
        """
        return self.mutex_map.get(component, set())


@dataclass
class EvalConfig:
    """之后遇到新的需要补充的后端config，继承该类实现"""
    # 后端eval的类型
    eval_method: EvaluationType = EvaluationType.ENG_PIPE_BY_RULE
    # 拟合系数
    fit_param: dict[FitParamKey, float] = field(default_factory=dict)
    # 是否开启auto pipe的优化
    enable_auto_pipe: bool = True
    # 是否加上小包搬运的拟合系数
    enable_small_package: bool = False
    # 组件之间的张量运算是否紧密排布
    enable_pipe_bubble: bool = False
    # 互斥组件配置，在计算时延的时候认为不可并行
    pipe_exclusive_config: MutexComponents = MutexComponents(CoreUnit.AIV_MTE2, [CoreUnit.AIV_MTE3])

    def set_default_fit_param(self):
        for key in FitParamKey:
            if key not in self.fit_param:
                self.fit_param[key] = key.default_value


@dataclass
class BackendConfig:
    # 硬件平台配置
    accelerator: str
    # 使用的AIC核数
    aic_core_num: int = 0
    # 使用的AIV核数
    aiv_core_num: int = 0
    # 算子的张量格式，比如BNSD
    layout_format: str = None
    # eval配置：每个模型都需要
    eval_config: EvalConfig = None
    # optim配置：仅仅是工程可达模型需要
    optim_config: OptimConfig = None
