# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

import logging
import os


def get_project_root() -> str:
    """
    查找项目根目录（通过识别根目录下的标识文件）
    返回：项目根目录的绝对路径
    """
    # 当前文件所在目录
    current_dir = os.path.abspath(os.path.dirname(__file__))

    # 向上遍历，直到找到根目录的标识文件
    while True:
        marker_files = [
            "requirements.txt",  # 依赖文件
        ]
        # 检查当前目录是否包含任意一个标识文件
        has_marker = any(os.path.exists(os.path.join(current_dir, marker)) for marker in marker_files)

        if has_marker:
            return current_dir

        parent_dir = os.path.dirname(current_dir)
        # 到达系统根目录仍未找到，返回当前文件目录作为日志目录
        if parent_dir == current_dir:  # 已经到根目录（如/或C:\）
            return os.path.abspath(os.path.dirname(__file__))

        current_dir = parent_dir


# 获取当前项目根目录
PROJECT_ROOT = get_project_root()

# 完整的日志文件路径
log_file_path = os.path.join(PROJECT_ROOT, "run.log")

# 配置日志记录
logging.basicConfig(
    level=logging.INFO,  # 设置日志级别
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",  # 设置日志格式
    datefmt="%Y-%m-%d %H:%M:%S",  # 设置日期时间格式
    filename=log_file_path,  # 日志输出文件
    filemode="a",  # 文件模式，'w'表示覆盖写入，'a'表示追加写入
)