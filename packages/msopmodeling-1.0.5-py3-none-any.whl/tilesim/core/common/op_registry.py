# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

from typing import Dict, Callable, Optional, Union

from core.common.entity import OpType, BackendType


class OpRegistry:
    def __init__(self):
        self._mapping: Dict[OpType, Dict[BackendType, Callable]] = {}

    def register(self, op_types: OpType | list[OpType], backend: Union[BackendType, str] = BackendType.THEO):
        """
        装饰器：注册 OpType + backend 到对应Op类
        """
        if isinstance(backend, str):
            backend = BackendType.from_str(backend)

        def decorator(func_or_cls: Callable) -> Callable:
            if not isinstance(op_types, list):
                op_type_list = [op_types]
            else:
                op_type_list = op_types

            for op_type in op_type_list:
                if op_type not in self._mapping:
                    self._mapping[op_type] = {}
                self._mapping[op_type][backend] = func_or_cls
            return func_or_cls

        return decorator

    def get_handler(self, op_type: OpType, backend: BackendType = BackendType.THEO) -> Optional[Callable]:
        """
        给定OpType+backend，获取算子costmodel函数
        """
        if op_type not in self._mapping:
            raise ValueError(f"不支持的算子类型：{op_type}")
        ret = self._mapping[op_type].get(backend)
        if ret is None:
            raise ValueError(f"{op_type}找不到对应的CostModel后端：{backend}")
        return ret

    def get_all_mappings(self) -> Dict[OpType, Dict[BackendType, Callable]]:
        """获取所有注册的映射"""
        return dict(self._mapping)

    @classmethod
    def register_modules(cls):
        cls._auto_import("ops.theoretical_model.basic_vec_op")
        cls._auto_import("ops.theoretical_model.cube_op")
        cls._auto_import("ops.theoretical_model.cv_fused_op")
        cls._auto_import("ops.theoretical_model.vector_fused_op")
        cls._auto_import("ops.theoretical_model.ttir_op")
        cls._auto_import("ops.engineering_model.ttir_op")
        cls._auto_import("ops.engineering_model.cube_op")
        cls._auto_import("ops.engineering_model.cv_fused_op")
        cls._auto_import("ops.engineering_model.hivm_op")
        cls._auto_import("ops.custom_op")

    @staticmethod
    def _auto_import(package_name):
        import pkgutil
        import importlib

        package = importlib.import_module(package_name)

        for _, module_name, _ in pkgutil.iter_modules(package.__path__):
            importlib.import_module(f"{package_name}.{module_name}")


def init_registry():
    OpRegistry.register_modules()


op_registry = OpRegistry()