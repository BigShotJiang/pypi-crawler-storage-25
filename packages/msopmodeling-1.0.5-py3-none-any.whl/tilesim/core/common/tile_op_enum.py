# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from enum import Enum

from sympy.strategies.core import switch

from core.common.entity import CoreUnit, MemLoc, CoreType


class TileOpType(Enum):
    # PyPTO的tileOp
    PyPTO = "PyPTO"
    # 朴素的TileOp实现，直接用CCE性能*repeats
    PLAIN = "PLAIN"


class TileOpCode(Enum):
    # Host侧的操作（DSL/IR转换的时候需要，不应流转到后端）
    ALLOC = ("alloc", [])
    RE_ASSIGN = ("re_assign", [])

    # Kernel侧的操作（后端需要感知和评估耗时）
    ADD = ("add", [CoreUnit.VEC])
    SUB = ("sub", [CoreUnit.VEC])
    SUB2 = ("sub2", [CoreUnit.VEC])
    MUL = ("mul", [CoreUnit.VEC])
    DIV = ("div", [CoreUnit.VEC])
    MAX = ("max", [CoreUnit.VEC])
    MIN = ("min", [CoreUnit.VEC])
    CAST = ("cast", [CoreUnit.VEC])
    ADDS = ("adds", [CoreUnit.VEC])
    SUBS = ("subs", [CoreUnit.VEC])
    MULS = ("muls", [CoreUnit.VEC])
    DIVS = ("divs", [CoreUnit.VEC])
    MAXS = ("maxs", [CoreUnit.VEC])
    MINS = ("mins", [CoreUnit.VEC])
    ABS = ("abs", [CoreUnit.VEC])
    EXP = ("exp", [CoreUnit.VEC])
    SQRT = ("sqrt", [CoreUnit.VEC])
    RELU = ("relu", [CoreUnit.VEC])
    REDUCE_SUM = ("reduce_sum", [CoreUnit.VEC])
    REDUCE_MAX = ("reduce_max", [CoreUnit.VEC])
    REDUCE_MIN = ("reduce_min", [CoreUnit.VEC])
    ROWSUM_SINGLE = ("rowsum_single", [CoreUnit.VEC])
    ROWMAX_SINGLE = ("rowmax_single", [CoreUnit.VEC])
    ROWMIN_SINGLE = ("rowmin_single", [CoreUnit.VEC])
    RSQRT = ("rsqrt", [CoreUnit.VEC])
    BITSORT = ("bitsort", [CoreUnit.VEC])
    ONEHOT = ("onehot", [CoreUnit.VEC])
    MRGSORT = ("mrgsort", [CoreUnit.VEC])
    TILEDMRGSORT = ("tiledmrgsort", [CoreUnit.VEC])
    PAIRMIN = ("pairmin", [CoreUnit.VEC])
    PAIRMAX = ("pairmax", [CoreUnit.VEC])
    PAIRSUM = ("pairsum", [CoreUnit.VEC])
    TRANSPOSE_MOVEOUT = ("transpose_moveout", [CoreUnit.VEC])
    TRANSPOSE_MOVEIN = ("transpose_movein", [CoreUnit.VEC])
    TRANSPOSE_VNCHWCONV = ("transpose_vnchwconv", [CoreUnit.VEC])
    ROWEXPAND = ("rowexpand", [CoreUnit.VEC])
    GATHER = ("gather", [CoreUnit.VEC])
    RANGE = ("range", [CoreUnit.VEC])
    VEC_DUP = ("vec_dup", [CoreUnit.VEC])
    BROADCAST = ("broadcast", [CoreUnit.VEC])
    EXTRACT = ("extract", [CoreUnit.VEC])
    GEMM = ("gemm", [CoreUnit.AIC_MTE1, CoreUnit.CUBE])
    COPY = ("copy", [])
    VIEW = ("view", [])
    ASSEMBLE = ("assemble", [])
    BARRIER = ("barrier", [])
    NULL_OP = ("null_op", [])
    SELECT = ("select", [CoreUnit.VEC])
    NOT_EQUAL = ("not_equal", [CoreUnit.VEC])
    GREATER_EQUAL = ("greater_equal", [CoreUnit.VEC])
    LOG = ("log", [CoreUnit.VEC])
    TRANSPOSE = ("transpose", [CoreUnit.VEC])
    MMAD = ("mmad", [CoreUnit.CUBE])
    CONV2D = ("conv2d", [CoreUnit.AIC_MTE1, CoreUnit.CUBE])
    CONV3D = ("conv3d", [CoreUnit.AIC_MTE1, CoreUnit.CUBE])

    # 同步操作
    SET_FLAG = ("set_flag", [])
    WAIT_FLAG = ("wait_flag", [])

    # Scalar 操作（例如hivm中arith. 开头的操作，在 AIC_SCALAR 或 AIV_SCALAR 上执行）
    SCALAR_AIC = ("scalar_aic", [CoreUnit.AIC_SCALAR])
    SCALAR_AIV = ("scalar_aiv", [CoreUnit.AIV_SCALAR])

    # 仅仅用于标记理论极限里面的算子输入输出，其他地方不写
    STORE = ("store", [])
    LOAD = ("load", [])

    def __init__(self, value, core_units):
        self._value_ = value
        self.core_units = core_units

    @staticmethod
    def from_str(opcode: str):
        for op in TileOpCode:
            if op.value == opcode:
                return op
        raise ValueError(f"Unknown opcode: {opcode}")

    def get_core_units(self, src_mem: MemLoc = None, dst_mem: MemLoc = None):
        if self != TileOpCode.COPY:
            return self.core_units

        if src_mem is None or dst_mem is None:
            raise ValueError("src_mem and dst_mem cannot be None when opcode is copy")

        if src_mem in [MemLoc.GM, MemLoc.L2]:
            if dst_mem == MemLoc.UB:
                return [CoreUnit.AIV_MTE2]
            elif dst_mem in [MemLoc.L1, MemLoc.L0A, MemLoc.L0B]:
                return [CoreUnit.AIC_MTE2]

        elif src_mem == MemLoc.UB:
            if dst_mem in [MemLoc.L1, MemLoc.GM, MemLoc.L2]:
                return [CoreUnit.AIV_MTE3]
            elif dst_mem == MemLoc.UB:
                return [CoreUnit.VEC]

        elif src_mem == MemLoc.L1:
            if dst_mem in [MemLoc.GM, MemLoc.L2]:
                return [CoreUnit.AIC_MTE3]
            elif dst_mem in [MemLoc.L0A, MemLoc.L0B, MemLoc.UB]:
                return [CoreUnit.AIC_MTE1]

        elif src_mem == MemLoc.L0C:
            if dst_mem in [MemLoc.GM, MemLoc.L2, MemLoc.UB, MemLoc.L1]:
                return [CoreUnit.AIC_FIXPIPE]

        raise ValueError(f"Unknown dst_mem: {dst_mem} when src_mem is {src_mem} and opcode is copy")

    def get_core_type(self, src_mem: MemLoc = None, dst_mem: MemLoc = None) -> CoreType | None:
        core_units = self.get_core_units(src_mem, dst_mem)
        if len(core_units) == 0:
            return None
        return core_units[0].core_type