# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import json
import os


def get_version():
    base_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    version_file = os.path.join(base_dir, "version", "version.json")

    with open(version_file, "r") as f:
        data = json.load(f)

    return f"{data['name']}.{data['version']}.{data['release_type']}.{data['release_date']}"