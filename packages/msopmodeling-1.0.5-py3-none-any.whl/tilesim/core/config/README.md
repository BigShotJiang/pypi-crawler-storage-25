# 一、 微架构参数配置说明

## 1. N卡（仅可用于理论极限）

### 1.1 Cube算力

**单拍运算数据量**

统一采用：

| 数据精度格式 | 单拍运算 [M, K, N] |
|--------|----------------|
| FP32   | [4,2,4]        |
| HF32   | [4,4,4]        |
| FP16   | [4,4,4]        |
| INT8   | [4,8,4]        |

**主频配置**

对于能够查到主频的，采用实际查到的主频，查不到的统一用2.52GHz

**单拍运算Cycles**

1) 单拍运算Cycles在能够确定核数的情况下，通过标称算力、核数、单拍运算数据量外推。如下所示：
$ repeat\_cycles = \frac{算力}{freq\cdot core\_num \cdot (m * n * k *2)}$
2) 当无法确认核数的情况下，统一采用FP32 2Cycles，其他数据格式 1 Cycles（与NPU保持一致）

**核数**

1) 如可以查询到可靠资料，则以资料为准
2) 通过Cycles反推，逻辑如下
$ core\_num = \frac{算力}{freq\cdot repeat\_cycles \cdot (m * n * k *2)}$

### 单配置特殊说明

1) **H20**
参数来源于湛卢：

![img.png](images/img.png)

此外，通过Nvidia官网得到H20\L20对比图：

![img.png](images/img_H20_L20.png)

基于该图外推Cuda Core的FP32算力

2) **H200**

除上述材料外，还找到了下述材料，不过如果按照下述材料配置主频核与核数，则Tensor Core的单拍计算量不符合预期，因此不做采用：

https://jx.huawei.com/community/comgroup/postsDetails?postId=4e16ab4193464ee1b5eb99d005293b97&welink_open_uri=aDU6Ly80NzE2NTE3MzE0Nzc5NTcvaHRtbC9pbmRleC5odG1sIy9qeC9kZXRhaWw/aWQ9NGUxNmFiNDE5MzQ2NGVlMWI1ZWI5OWQwMDUyOTNiOTcmdHlwZT1mcmVlX3Bvc3QmdXJsPQ==