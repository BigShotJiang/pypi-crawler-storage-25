# MatMul算子tiling策略（DavidV100）

本文档提供MatMul算子在不同情况下的AscendC默认tiling策略，用户可以酌情选择来作为TileSim MatMul类算子的输入，以达到预测性能和AscendC实现的算子实测相近。默认tiling策略来源于算子源码仓：https://gitcode.com/cann/ops-nn。

本文按照策略执行优先级从高到低排列。

## 1 K_EQUAL_ZERO Tiling
  - 触发条件:
    - K == 0
    - 无Bias (hasBias == false)
  - 切分方式:
    - 全核并行处理输出全0矩阵填充
    - 不进行实际矩阵乘法，直接初始化输出，走AIV计算

## 2 MN_EQUAL_ONE Tiling

  - 触发条件:
    - M == 1 || N == 1
    - 数据类型为FP32
    - 当M=1时: N >= 512 && N % 32 == 0 && K % 512 == 0
    - 当N=1时: M >= 512 && M % 32 == 0 && K % 512 == 0
  - 切分方式:
    - 按32切分MN方向进行多核并行，tailMN = max(m,n) % 32
    - K方向循环 loopK = K / 512
  - 特点: 针对FP32的一维向量场景优化

## 3 BASIC_STREAM_K Tiling

  - 触发条件:
    - A矩阵格式必须是ND
    - SKTiling分支、DPSKTiling分支满足其一
    - SKTiling分支:
      - K >= 8192 且 K >= aicNum * 256/dtypeSize
      - 用256/32对齐M、N后的切分份数 mCnt * nCnt <= aicNum/2
      - FP32时 K <= 2000000 (为保证精度)
    - DPSKTiling分支:
      - M % 256 == 0 && N % 256 == 0
      - K >= 8192 且 K >= aicNum * 128/dtypeSize
      - mCnt * nCnt >= aicNum 且 (mCnt * nCnt) % aicNum <= aicNum/2 且余数不为0
  - 切分方式:
    - SK分支: K轴多核切分, M、N轴按基本块切分
      - baseM = ceil(M/mCnt), baseN = ceil(N/nCnt)
      - singleCoreK = ceil(K / kCnt)
    - DPSK分支: MN轴分块, K轴切分处理余数
      - kCnt = aicNum / (totalMNCnt % aicNum)
    - L0C2Out优化: N > 64 && N % 16 != 0 时启用ND_FIXPIPE_1_2

## 4 Stream K Tiling

  - 触发条件:
    - 不支持非连续tensor
    - SKTiling分支、DPSKTiling分支满足其一，条件与BASIC_STREAM_K相同
    - FP32时 K <= 2000000 (为保证精度)
  - 切分方式:
    - 与Basic Stream K相似
    - K轴256B对齐, baseK 128B对齐
    - 考虑L0A_SIZE_2(64KB)限制

## 5 BASIC_ASWT Tiling

  - 触发条件:
    - 默认支持所有场景 (除Stream K特殊场景)
    - AL1 Full Load分支:
        - L0C2Out == ON_THE_FLY
      - N >= 512
      - 非单轮场景 (mCnt * nCnt > aicNum)
      - L2命中率不够高 (M < maxStepM * baseM)
      - AL1Size + biasSize <= 3/4 * L1Size
      - 全载后总数据搬运量至少减少20%
    - BL1 Full Load分支:
        - M >= 512
      - 其他条件类似AL1
  - 切分方式:
    - AL1 Full Load: A矩阵全载L1
        - singleCoreM = M, singleCoreN = baseN
      - 优先调整stepK为2,再调整baseN
      - 考虑B矩阵4buffer
    - BL1 Full Load: B矩阵全载L1
        - singleCoreN = N, singleCoreM = baseM
      - 优先调整stepK为2,再调整baseM
    - 普通LoadBalancing: 负载均衡切分
        - stepK = remainL1 / 2 / ((baseM+baseN) * baseK) / dtypeSize


## 6 FULL_LOAD_BASE Tiling

  - 优先级: 5 (最低)
  - 触发条件:
    - AB L1 Full Load分支:
        - 单轮场景 (mCnt * nCnt <= aicNum)
      - AL1Size + BL1Size + biasSize <= L1Size
      - DAV_3510: 单边矩阵<=64KB且总和<=272KB
    - A L1 Full Load分支:
        - N >= 512
      - M < N (针对A全载)
      - AL1Size <= 1/2 * (L1Size - biasSize)
      - M <= 256 或 M < baseM (K全载场景)
    - B L1 Full Load分支:
        - M >= 512
      - N < M (针对B全载)
      - BL1Size <= 1/2 * (L1Size - biasSize)
      - N <= 256 或 N < baseN (K全载场景)
  - 切分方式:
    - AB全载: A和B都全载L1
        - singleCoreM和singleCoreN按块分配
    - AL1全载/BL1全载: 对应矩阵全载,另一个矩阵分块
