# 算子建模工具使用文档

## 一、概述

本算子建模工具采用三层架构设计：

- **前端DSL**：描述算子的计算逻辑和数据流
- **IR（中间表示）**：定义张量、内存位置、数据类型等核心实体
- **后端实体类**：继承`EngineeringOperator`基类，完成算子注册、输入校验、配置管理

通过本文档，您可以学会如何为一个算子构建完整的工程可达性能模型。

---

## 二、核心概念

### 2.1 内存层次结构 (`MemLoc`)

| 内存位置 | 说明 | 适用核类型 |
|---------|------|-----------|
| `GM` | 全局内存 | AIC/AIV |
| `L1` | AIC核本地内存 | AIC |
| `L0A` / `L0B` | AIC核输入缓冲区 | AIC |
| `L0C` | AIC核输出缓冲区 | AIC |
| `UB` | AIV核统一缓冲区 | AIV |

### 2.2 数据类型 (`DType`)

支持的数据类型：`FP16`, `FP32`, `BF16`, `INT8`, `INT32`, `INT64`, `UINT64`, `BOOL` 等。

### 2.3 TileOp 运算分类

| 类别 | 操作 | 说明 |
|-----|------|------|
| **数据搬运** | `copy`, `cast`, `view` | 内存间数据传输 |
| **矩阵运算** | `gemm`, `mmad` | Cube核矩阵乘，输出在L0C |
| **双目向量运算** | `add`, `sub`, `mul`, `div`, `max`, `min` | 输入输出均在UB |
| **单目向量运算** | `exp`, `sqrt`, `relu`, `abs`, `log` | 输入输出均在UB |
| **规约运算** | `reduce_sum`, `reduce_max`, `reduce_min` | 输入UB，输出UB |
| **同步操作** | `set_flag`, `wait_flag`, `barrier` | 核间同步 |

---

## 三、算子建模步骤

### 步骤1：定义符号变量

使用 `T.define_symbol()` 定义动态形状参数：

```python
from core.frontend.dsl.grammar.kernel import T

# 定义算子需要的符号变量
M, N, K, input_dtype, output_dtype = T.define_symbol(5)
```

### 步骤2：编写DSL函数

DSL函数描述算子的计算流程：

```python
from core.frontend.dsl.grammar.tensor import Tensor
from core.common.entity import MemLoc, DType

def my_operator(
    # 定义输入输出张量
    input_a: Tensor(shape=[M, K], dtype=input_dtype, mem_loc=MemLoc.GM),
    input_b: Tensor(shape=[K, N], dtype=input_dtype, mem_loc=MemLoc.GM),
    output: Tensor(shape=[M, N], dtype=output_dtype, mem_loc=MemLoc.GM),

    # 定义tiling参数（可选）
    tm=None,  # M轴切块大小
    tn=None,  # N轴切块大小
    tk=None,  # K轴切块大小
):
    # 计算分块数量
    m_tiles = T.ceil(M / tm)
    n_tiles = T.ceil(N / tn)
    k_tiles = T.ceil(K / tk)

    # 定义Task并行区域
    with T.Task(name="compute_task", range=[m_tiles, n_tiles]) as ([i, j]):
        # 分配中间张量
        out_l0c = Tensor(shape=[tm, tn], dtype=output_dtype, mem_loc=MemLoc.L0C)

        for k_idx in range(k_tiles):
            # 计算切片偏移
            a_tile = input_a[i*tm : T.min((i+1)*tm, M), k_idx*tk : T.min((k_idx+1)*tk, K)]
            b_tile = input_b[k_idx*tk : T.min((k_idx+1)*tk, K), j*tn : T.min((j+1)*tn, N)]

            # 搬运数据到L1
            a_l1 = Tensor(shape=[tm, tk], dtype=input_dtype, mem_loc=MemLoc.L1)
            b_l1 = Tensor(shape=[tk, tn], dtype=input_dtype, mem_loc=MemLoc.L1)
            T.TileOp.copy(a_l1, a_tile)
            T.TileOp.copy(b_l1, b_tile)

            # 矩阵乘计算
            T.TileOp.gemm(out_l0c, a_l1, b_l1)

        # 写回结果
        out_tile = output[i*tm : T.min((i+1)*tm, M), j*tn : T.min((j+1)*tn, N)]
        T.TileOp.copy(out_tile, out_l0c)
```

### 步骤3：实现算子实体类

继承 `EngineeringOperator` 并实现必要方法：

```python
from typing import Any
from core.common.entity import OpType, BackendType
from core.common.op_registry import op_registry
from core.common.backend_config import OptimType, OptimConfig, TaskIndexConfig
from core.pipeline.tilesim_eng.eng_operator import EngineeringOperator

@op_registry.register(OpType.MatMul, BackendType.ENG)  # 注册算子
class EngMyOperator(EngineeringOperator):

    @property
    def operator_dsl(self):
        """返回DSL函数"""
        return my_operator

    @property
    def optim_type(self) -> OptimType:
        """选择优化策略"""
        return OptimType.GENERAL_BY_SEQ_OPTIM

    def _input_check(self):
        """输入校验"""
        input_shapes = self.op_input.input_shapes
        output_shapes = self.op_input.output_shapes

        # 示例：校验输入数量
        if len(input_shapes) != 2:
            raise ValueError("inputs length must be 2")

    def _set_optim_config(self) -> OptimConfig:
        """设置优化配置（分核策略等）"""
        task_index_configs = {
            "compute_task": [
                TaskIndexConfig(
                    index_name='i',       # Task中的循环变量名
                    seq_num=0,            # 分核优先级（越小越外层）
                    split_core_stride=1,  # 分核步长，-1表示不分核
                    enable_swizzle=False  # 是否启用Z字遍历
                ),
                TaskIndexConfig(
                    index_name='j',
                    seq_num=1,
                    split_core_stride=1,
                    enable_swizzle=True
                )
            ]
        }

        return OptimConfig(
            optim_method=self.optim_type,
            tuning_candidates=self.op_input.param.tuning_candidates,
            task_index_config=task_index_configs
        )

    def _dynamic_shape_assign(self) -> dict[str, Any]:
        """将输入shape映射到DSL符号变量"""
        input_shapes = self.op_input.input_shapes
        input_dtypes = self.op_input.input_dtypes

        return {
            "M": input_shapes[0][0],
            "K": input_shapes[0][1],
            "N": input_shapes[1][1],
            "input_dtype": input_dtypes[0],
            "output_dtype": self.op_input.output_dtypes[0],
        }
```

---

## 四、DSL语法详解

### 4.1 张量定义

```python
Tensor(shape=[dim1, dim2, ...], dtype=DType.FP16, mem_loc=MemLoc.UB)
```

- `shape`: 张量形状，支持符号变量
- `dtype`: 数据类型
- `mem_loc`: 内存位置

### 4.2 Task并行区域

```python
with T.Task(name="task_name", range=[tiles_m, tiles_n]) as ([i, j]):
    # i, j 为循环变量
    # 在此区域内描述单个task的计算逻辑
```

### 4.3 常用辅助函数

| 函数 | 说明 |
|-----|------|
| `T.ceil(a, b)` | 向上取整除法 |
| `T.min(a, b)` | 最小值 |
| `T.max(a, b)` | 最大值 |
| `T.str_con(prefix, idx)` | 字符串拼接，用于flag_id |

### 4.4 TileOp操作详解

#### 数据搬运类

```python
# copy: 内存间数据拷贝
T.TileOp.copy(dst_tensor, src_tensor)

# cast: 数据类型转换
T.TileOp.cast(dst_tensor, src_tensor)
```

#### 矩阵运算类（Cube核，输出在L0C）

```python
# gemm: 矩阵乘 [M,K] @ [K,N] = [M,N]
T.TileOp.gemm(dst_l0c, src1_l1, src2_l1)

# mmad: 矩阵乘累加
T.TileOp.mmad(dst_l0c, src1_l0a, src2_l0b)
```

#### 向量运算类（Vector核，输入输出均在UB）

```python
# 双目运算
T.TileOp.add(dst_ub, src1_ub, src2_ub)
T.TileOp.sub(dst_ub, src1_ub, src2_ub)
T.TileOp.mul(dst_ub, src1_ub, src2_ub)
T.TileOp.div(dst_ub, src1_ub, src2_ub)
T.TileOp.max(dst_ub, src1_ub, src2_ub)

# 单目运算
T.TileOp.exp(dst_ub, src_ub)
T.TileOp.sqrt(dst_ub, src_ub)
T.TileOp.relu(dst_ub, src_ub)

# 规约运算（需指定axis）
T.TileOp.reduce_sum(dst_ub, src_ub, config={"reduce_axis": 1})
T.TileOp.reduce_max(dst_ub, src_ub, config={"reduce_axis": 1})
```

#### 同步操作

```python
# 设置同步标志
T.TileOp.set_flag(config={
    "flag_id": "sync_flag_0",
    "units": ["aiv_mte2"]  # 指定同步的组件
})

# 等待同步标志
T.TileOp.wait_flag(config={
    "flag_id": "sync_flag_0"
})
```

---

## 五、完整示例：FlashAttention建模

以下是一个简化的FlashAttention建模示例：

```python
# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from typing import Any

from core.common import MemLoc, DType, OpType, BackendType
from core.common import op_registry
from core.common.backend_config import OptimType, OptimConfig, TaskIndexConfig
from core.frontend.dsl.grammar.kernel import T
from core.frontend.dsl.grammar.tensor import Tensor
from core.pipeline.tilesim_eng.eng_operator import EngineeringOperator

# 定义符号变量
S1, S2, D1, D2, C_TYPE, V_TYPE = T.define_symbol(6)


def flash_attention(
    q: Tensor(shape=[S1, D1], dtype=C_TYPE, mem_loc=MemLoc.GM),
    k: Tensor(shape=[D1, S2], dtype=C_TYPE, mem_loc=MemLoc.GM),
    v: Tensor(shape=[S2, D2], dtype=C_TYPE, mem_loc=MemLoc.GM),
    o: Tensor(shape=[S1, D2], dtype=C_TYPE, mem_loc=MemLoc.GM),
    t_s1=None, t_s2=None, t_d1=None, t_d2=None,
):
    """FlashAttention DSL实现"""
    s1_tiles = T.ceil(S1 / t_s1)
    s2_tiles = T.ceil(S2 / t_s2)

    with T.Task(name="fa_task", range=[s1_tiles]) as ([i]):
        # 计算偏移
        s1_start = i * t_s1
        s1_end = T.min((i + 1) * t_s1, S1)
        s1_size = s1_end - s1_start

        # 分配工作空间
        workspace_s = Tensor(shape=[s1_size, t_s2], dtype=V_TYPE, mem_loc=MemLoc.GM)

        # QK矩阵乘
        for j in range(s2_tiles):
            s2_start = j * t_s2
            s2_end = T.min((j + 1) * t_s2, S2)
            s2_size = s2_end - s2_start

            q_tile = q[s1_start:s1_end, :]
            k_tile = k[:, s2_start:s2_end]

            # L1缓冲区
            q_l1 = Tensor(shape=[s1_size, D1], dtype=C_TYPE, mem_loc=MemLoc.L1)
            k_l1 = Tensor(shape=[D1, s2_size], dtype=C_TYPE, mem_loc=MemLoc.L1)
            T.TileOp.copy(q_l1, q_tile)
            T.TileOp.copy(k_l1, k_tile)

            # QK乘结果
            s_l0c = Tensor(shape=[s1_size, s2_size], dtype=V_TYPE, mem_loc=MemLoc.L0C)
            T.TileOp.gemm(s_l0c, q_l1, k_l1)
            T.TileOp.copy(workspace_s[:, 0:s2_size], s_l0c)

            # Softmax计算（在UB中）
            s_ub = Tensor(shape=[s1_size, s2_size], dtype=V_TYPE, mem_loc=MemLoc.UB)
            T.TileOp.copy(s_ub, workspace_s[:, 0:s2_size])

            # row max
            row_max = Tensor(shape=[s1_size, 1], dtype=V_TYPE, mem_loc=MemLoc.UB)
            T.TileOp.reduce_max(row_max, s_ub, config={"reduce_axis": 1})

            # exp(s - max)
            T.TileOp.sub(s_ub, s_ub, row_max)
            T.TileOp.exp(s_ub, s_ub)

            # PV乘
            p_l1 = Tensor(shape=[s1_size, s2_size], dtype=C_TYPE, mem_loc=MemLoc.L1)
            T.TileOp.cast(p_l1, s_ub)
            T.TileOp.copy(p_l1, s_ub)

            v_tile = v[s2_start:s2_end, :]
            v_l1 = Tensor(shape=[s2_size, D2], dtype=C_TYPE, mem_loc=MemLoc.L1)
            T.TileOp.copy(v_l1, v_tile)

            o_l0c = Tensor(shape=[s1_size, D2], dtype=V_TYPE, mem_loc=MemLoc.L0C)
            T.TileOp.gemm(o_l0c, p_l1, v_l1)

            # 写回输出
            o_tile = o[s1_start:s1_end, :]
            T.TileOp.copy(o_tile, o_l0c)


@op_registry.register(OpType.FlashAttention, BackendType.ENG)
class EngFlashAttention(EngineeringOperator):

    @property
    def operator_dsl(self):
        return flash_attention

    @property
    def optim_type(self) -> OptimType:
        return OptimType.GENERAL_BY_SEQ_OPTIM

    def _input_check(self):
        input_shapes = self.op_input.input_shapes
        # 添加必要的shape校验

    def _set_optim_config(self) -> OptimConfig:
        task_index_configs = {
            "fa_task": [
                TaskIndexConfig(
                    index_name="i",
                    seq_num=0,
                    split_core_stride=1,
                    enable_swizzle=False
                )
            ]
        }
        return OptimConfig(
            optim_method=self.optim_type,
            tuning_candidates=self.op_input.param.tuning_candidates,
            task_index_config=task_index_configs
        )

    def _dynamic_shape_assign(self) -> dict[str, Any]:
        input_shapes = self.op_input.input_shapes
        input_dtypes = self.op_input.input_dtypes

        s1 = input_shapes[0][1]  # Q的seq len
        d1 = input_shapes[0][-1]  # head dim
        s2 = input_shapes[1][1]  # KV的seq len
        d2 = input_shapes[2][-1]  # V的head dim
        c_type = input_dtypes[0]
        v_type = DType.FP32 if c_type == DType.FP16 else DType.FP16

        return {
            "S1": s1, "S2": s2, "D1": d1, "D2": d2,
            "C_TYPE": c_type, "V_TYPE": v_type,
        }
```

---

## 六、调用算子模型

```python
from core.common.entity import DType

# 构造输入参数
op_input = {
    'input_shapes': [[1, 1024, 32, 128], [1, 2048, 32, 128], [1, 2048, 32, 64]],
    'output_shapes': [[1, 1024, 32, 64]],
    'input_dtypes': [DType.FP16.name, DType.FP16.name, DType.FP16.name],
    'output_dtypes': [DType.FP16.name],
    'accelerator': 'path/to/chip_config.yaml',
    'aic_core_num': 24,
    'aiv_core_num': 24,
    'extra_param': {
        'tuning_candidates': [
            {'t_s1': 128, 't_s2': 256, 't_d1': 128, 't_d2': 64}
        ]
    }
}

# 转换并运行
op_input_obj = EngFlashAttention.op_input_convert(op_input)
result = EngFlashAttention(op_input_obj).run()
result.print_format()
```

---

## 七、注意事项

1. **内存位置约束**：
   - Cube运算（gemm/mmad）输入必须在L1，输出在L0C
   - Vector运算输入输出必须在UB

2. **Task命名**：Task的name需与`_set_optim_config`中的配置key一致

3. **符号变量**：DSL函数参数名需与`_dynamic_shape_assign`返回的dict key一致

4. **Tiling参数**：通过`tuning_candidates`传入，支持多组参数自动寻优

5. **注册机制**：使用`@op_registry.register(OpType.XXX, BackendType.ENG)`注册算子

---

## 八、文件结构参考

```
ops/engineering_model/
├── cube_op/                    # 纯Cube算子
│   └── matmul_l0.py           # MatMul示例
├── cv_fused_op/               # Cube-Vector融合算子
│   ├── flash_attention.py
│   └── flash_attention_single_task.py
└── ttir_op/                   # Triton IR算子
    └── triton_op.py
```

---

如有更多问题，请参考 `ops/engineering_model/` 目录下的现有实现。