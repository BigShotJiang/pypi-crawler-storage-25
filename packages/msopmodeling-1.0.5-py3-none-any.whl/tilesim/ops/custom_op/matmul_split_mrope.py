# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from typing import Any

from core.common import OpType, BackendType, MemLoc, DType
from core.common import op_registry
from core.frontend.dsl.grammar.tensor_op import TensorOp
from core.pipeline.tilesim_theo.theo_operator import TheoreticalOperator
from core.frontend.dsl.grammar.kernel import T
from core.frontend.dsl.grammar.tensor import Tensor

Q_N, K_N, N_3, N, D, half_D, dtype = T.define_symbol(7)


def matmul_split_mrope():
    # 对应comb_in = Tensor(shape=[N, HC, HC], dtype=DType.FP32, mem_loc=MemLoc.UB)

    # 对应T.TensorOp.null_op(x_in, x)

    mat_a = Tensor(shape=[N, 5120], dtype=DType.BF16, mem_loc=MemLoc.GM)
    mat_b = Tensor(shape=[2560, 5120], dtype=DType.BF16, mem_loc=MemLoc.GM)

    q_gamma = Tensor(shape=[D], dtype=DType.BF16, mem_loc=MemLoc.GM)
    k_gamma = Tensor(shape=[D], dtype=DType.BF16, mem_loc=MemLoc.GM)

    ori_sin = Tensor(shape=[65536, 64], dtype=DType.BF16, mem_loc=MemLoc.GM)
    ori_cos = Tensor(shape=[65536, 64], dtype=DType.BF16, mem_loc=MemLoc.GM)

    position = Tensor(shape=[3, N], dtype=DType.INT64, mem_loc=MemLoc.GM)
    cos_sin = Tensor(shape=[65536, D], dtype=DType.BF16, mem_loc=MemLoc.GM)

    # 进入get_gold函数开始
    position_flat = Tensor(shape=[N_3], dtype=DType.INT64, mem_loc=MemLoc.UB)
    T.TensorOp.null_op(position_flat, position)  # position flatten

    tmp = Tensor(shape=[N_3, D], dtype=DType.INT64, mem_loc=MemLoc.UB)
    T.TensorOp.null_op(tmp, cos_sin)  # 从position位置索引中提取cos sin值

    # 从tmp中切出两个rope
    rope_cos = Tensor(shape=[N_3, 1, half_D], dtype=DType.INT64, mem_loc=MemLoc.UB)
    rope_sin = Tensor(shape=[N_3, 1, half_D], dtype=DType.INT64, mem_loc=MemLoc.UB)

    T.TensorOp.store(rope_sin)
    T.TensorOp.store(rope_cos)

    # 对应res = mat_a @ mat_b.transpose(0,1)
    res = Tensor(shape=[N, 2560], dtype=DType.BF16, mem_loc=MemLoc.UB)
    # 对应mat_a = Tensor(shape=[N, 5120], dtype=DType.BF16, mem_loc=MemLoc.GM)
    mat_b_t = Tensor(shape=[5120, 2560], dtype=DType.BF16, mem_loc=MemLoc.UB)

    for i in range(100):
        T.TensorOp.null_op(mat_b, mat_b_t)
        T.TensorOp.gemm(res, mat_a, mat_b_t)
    # 将res切分为三个子矩阵q,k,v
    q = Tensor(shape=[N, 2048], dtype=DType.BF16, mem_loc=MemLoc.UB)
    k = Tensor(shape=[N, 256], dtype=DType.BF16, mem_loc=MemLoc.UB)
    v = Tensor(shape=[N, 256], dtype=DType.BF16, mem_loc=MemLoc.UB)
    # 缓存q,k,v
    T.TensorOp.store(q)
    T.TensorOp.store(k)
    T.TensorOp.store(v)

    # q,k进行rms_norm 将q,k reshape成[T,16,128] 后平方 /128 +eps  开根号  倒数 最后*gamma
    T.TensorOp.null_op(q, q_gamma)
    T.TensorOp.null_op(k, k_gamma)
    # norm后的qk需要再store一次
    T.TensorOp.store(q)
    T.TensorOp.store(k)
    # norm后的q k ,进mrope流程
    q = Tensor(shape=[N, 2048], dtype=DType.BF16, mem_loc=MemLoc.GM)
    k = Tensor(shape=[N, 256], dtype=DType.BF16, mem_loc=MemLoc.GM)

    rope_cos_in = Tensor(shape=[N_3, 1, half_D], dtype=DType.INT64, mem_loc=MemLoc.GM)
    rope_sin_in = Tensor(shape=[N_3, 1, half_D], dtype=DType.INT64, mem_loc=MemLoc.GM)

    cos = Tensor(shape=[3, N, half_D], dtype=DType.FP32, mem_loc=MemLoc.UB)
    T.TensorOp.null_op(cos, rope_cos_in)  # 对cos进行交错操作再赋值回去
    T.TensorOp.store(cos)

    sin = Tensor(shape=[3, N, half_D], dtype=DType.FP32, mem_loc=MemLoc.UB)
    T.TensorOp.null_op(sin, rope_sin_in)  # 对cos进行交错操作再赋值回去
    T.TensorOp.store(sin)

    # 搬入q_rms_norm 并reshape,切分成x1 x2再分别与cos sin运算，最后拼接
    q_reshape = Tensor(shape=[N, 16, D], dtype=DType.BF16, mem_loc=MemLoc.UB)
    T.TensorOp.null_op(q_reshape, q)

    x1 = Tensor(shape=[N, 16, half_D], dtype=DType.BF16, mem_loc=MemLoc.UB)
    x2 = Tensor(shape=[N, 16, half_D], dtype=DType.BF16, mem_loc=MemLoc.UB)

    term1 = Tensor(shape=[N, 1, half_D], dtype=DType.BF16, mem_loc=MemLoc.UB)
    term2 = Tensor(shape=[N, 1, half_D], dtype=DType.BF16, mem_loc=MemLoc.UB)

    o1 = Tensor(shape=[N, 1, half_D], dtype=DType.BF16, mem_loc=MemLoc.UB)
    o2 = Tensor(shape=[N, 1, half_D], dtype=DType.BF16, mem_loc=MemLoc.UB)

    #对应 o1=x1*cos-x2*sin
    T.TensorOp.mul(term1, x1, cos)
    T.TensorOp.mul(term2, x2, sin)
    T.TensorOp.add(o1, term1, term2)
    #对应 o2=x2*cos+x1*sin
    T.TensorOp.mul(term1, x1, sin)
    T.TensorOp.mul(term2, x2, cos)
    T.TensorOp.add(o2, term1, term2)
    # o1 o2拼接成完整的query_rot，query_rot和query_pass拼成完整的query
    T.TensorOp.store(q_reshape)

    # 搬入K_rms_norm 并reshape,操作与q类似
    k_reshape = Tensor(shape=[N, 2, D], dtype=DType.BF16, mem_loc=MemLoc.UB)
    T.TensorOp.null_op(k_reshape, k)

    x1_k = Tensor(shape=[N, 2, half_D], dtype=DType.BF16, mem_loc=MemLoc.UB)
    x2_k = Tensor(shape=[N, 2, half_D], dtype=DType.BF16, mem_loc=MemLoc.UB)

    term1 = Tensor(shape=[N, 1, half_D], dtype=DType.BF16, mem_loc=MemLoc.UB)
    term2 = Tensor(shape=[N, 1, half_D], dtype=DType.BF16, mem_loc=MemLoc.UB)

    o1 = Tensor(shape=[N, 1, half_D], dtype=DType.BF16, mem_loc=MemLoc.UB)
    o2 = Tensor(shape=[N, 1, half_D], dtype=DType.BF16, mem_loc=MemLoc.UB)

    #对应 o1=x1*cos-x2*sin
    T.TensorOp.mul(term1, x1, cos)
    T.TensorOp.mul(term2, x2, sin)
    T.TensorOp.add(o1, term1, term2)
    #对应 o2=x2*cos+x1*sin
    T.TensorOp.mul(term1, x1, sin)
    T.TensorOp.mul(term2, x2, cos)
    T.TensorOp.add(o2, term1, term2)
    # o1 o2拼接成完整的query_rot，query_rot和query_pass拼成完整的query
    T.TensorOp.store(k_reshape)


def matmul_merge_mrope():
    mat_a = Tensor(shape=[N, 5120], dtype=DType.BF16, mem_loc=MemLoc.GM)
    mat_b = Tensor(shape=[2560, 5120], dtype=DType.BF16, mem_loc=MemLoc.GM)

    q_gamma = Tensor(shape=[D], dtype=DType.BF16, mem_loc=MemLoc.GM)
    k_gamma = Tensor(shape=[D], dtype=DType.BF16, mem_loc=MemLoc.GM)

    position = Tensor(shape=[3, N], dtype=DType.INT64, mem_loc=MemLoc.GM)
    cos_sin = Tensor(shape=[65536, D], dtype=DType.BF16, mem_loc=MemLoc.GM)

    # 搬入
    T.TensorOp.null_op(mat_a, mat_b)
    T.TensorOp.null_op(q_gamma, k_gamma)
    T.TensorOp.null_op(position, cos_sin)

    # 搬出
    q_reshape = Tensor(shape=[N, 16, D], dtype=DType.BF16, mem_loc=MemLoc.UB)
    k_reshape = Tensor(shape=[N, 2, D], dtype=DType.BF16, mem_loc=MemLoc.UB)

    T.TensorOp.store(q_reshape)
    T.TensorOp.store(k_reshape)


@op_registry.register(OpType.MatMulMrope, BackendType.THEO)
class TheoMatMulMrope(TheoreticalOperator):
    operator_dsl = matmul_split_mrope

    def _input_check(self):
        pass

    def _dynamic_shape_assign(self) -> dict[str, Any]:
        dynamic_shape = {
            'N': 768,
            'N_3': 768 * 3,
            'D': 128,
            'half_D': 64,
            'Q_N': 16,
            'K_N': 2,
            'dtype': self.op_input.input_dtypes[0],
        }
        return dynamic_shape