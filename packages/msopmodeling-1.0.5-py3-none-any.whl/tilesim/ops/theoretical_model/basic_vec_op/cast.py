# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import math
from typing import Any

from core.common.backend_config import BackendConfig, FitParamKey
from core.pipeline.tilesim_theo.theo_operator import TheoreticalOperator
from core.common import op_registry
from core.common import OpType, BackendType, MemLoc
from core.frontend.dsl.grammar.kernel import T
from core.frontend.dsl.grammar.tensor import Tensor

a, dtype_i, dtype_o = T.define_symbol(3)


def cast(src1: Tensor(shape=[a], dtype=dtype_i, mem_loc=MemLoc.GM),
         output: Tensor(shape=[a], dtype=dtype_o, mem_loc=MemLoc.GM)
         ):
    """cast算子DSL实现"""
    src1_ub = Tensor(shape=[a], dtype=dtype_i, mem_loc=MemLoc.UB)
    output_ub = Tensor(shape=[a], dtype=dtype_o, mem_loc=MemLoc.UB)
    T.TensorOp.null_op(src1_ub, src1)
    T.TensorOp.cast(output_ub, src1_ub)
    T.TensorOp.store(output_ub)


@op_registry.register(OpType.Cast, BackendType.THEO)
class TheoCast(TheoreticalOperator):

    operator_dsl = cast

    def _input_check(self):
        if len(self.op_input.output_shapes) != 1:
            raise ValueError("[TheoCast] input length must be 1")
        if len(self.op_input.output_shapes) != 1:
            raise ValueError("[TheoCast] output length must be 1")
        input_size = math.prod(self.op_input.input_shapes[0])
        output_size = math.prod(self.op_input.output_shapes[0])
        if input_size != output_size:
            raise ValueError("[TheoCast] input and output size must be equal")

    def _dynamic_shape_assign(self) -> dict[str, Any]:
        input_shapes = self.op_input.input_shapes
        input_dtypes = self.op_input.input_dtypes
        output_dtypes = self.op_input.output_dtypes
        dynamic_shape = {
            'a': math.prod(input_shapes[0]),
            'dtype_i': input_dtypes[0],
            'dtype_o': output_dtypes[0]
        }
        return dynamic_shape

    def _adjust_coeff(self, backend_config: BackendConfig):
        input_shape = self.op_input.input_shapes[0]
        fit_param = backend_config.eval_config.fit_param

        if FitParamKey.BW_COEFF not in fit_param:
            fit_param[FitParamKey.BW_COEFF] = 0.5

        if FitParamKey.COMP_COEFF not in fit_param:
            fit_param[FitParamKey.COMP_COEFF] = 0.025

        if FitParamKey.SCALAR_TIME not in fit_param:
            fit_param[FitParamKey.SCALAR_TIME] = 1.0