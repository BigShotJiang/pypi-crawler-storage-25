# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import math
from dataclasses import dataclass, field
from typing import Any

from core.backend.engineering_costmodel.utils import generate_sequence_lengths_truncated
from core.common import OpType, BackendType, DType, MemLoc
from core.common import op_registry
from core.pipeline.basic_operator import OperatorExtraParam
from core.pipeline.tilesim_theo.theo_operator import TheoreticalOperator
from core.frontend.dsl.grammar.kernel import T
from core.frontend.dsl.grammar.tensor import Tensor


@dataclass
class HSTUExtraParam(OperatorExtraParam):
    actual_seq_len: list[int] = field(default_factory=list)
    dist_param: list[float] = field(default_factory=list)


S1, S2, D1, D2 = 1024, 1024, 128, 80

dtype = DType.FP32
mem_loc = MemLoc.GM


def hstu(q: Tensor(shape=[S1, D1], dtype=dtype, mem_loc=mem_loc),
         k: Tensor(shape=[D1, S2], dtype=dtype, mem_loc=mem_loc),
         v: Tensor(shape=[S2, D2], dtype=dtype, mem_loc=mem_loc),
         out: Tensor(shape=[S1, D2], dtype=dtype, mem_loc=mem_loc)
         ):
    """
    HSTU 算子DSL实现
    Args:
        q:
        k:
        v:
        out:

    Returns:

    """
    qk = Tensor(shape=[S1, S2], dtype=dtype, mem_loc=MemLoc.L0C)
    x = Tensor(shape=[S1, S2], dtype=dtype, mem_loc=MemLoc.UB)
    out_l0c = Tensor(shape=[S1, D2], dtype=dtype, mem_loc=MemLoc.L0C)

    T.TensorOp.gemm(qk, q, k)
    T.TensorOp.exp(x, qk, qk)  # x/(1+e-x)
    T.TensorOp.add(x, x, x)
    T.TensorOp.div(x, qk, x)
    T.TensorOp.mul(x, x, x)  # scale
    T.TensorOp.gemm(out_l0c, x, v)
    T.TensorOp.store(out_l0c)


@op_registry.register(OpType.HstuDenseForwardFuxi, BackendType.THEO)
class TheoHstu(TheoreticalOperator):
    operator_dsl = hstu
    extra_param_class = HSTUExtraParam

    def _input_check(self):
        input_shapes = self.op_input.input_shapes
        output_shapes = self.op_input.output_shapes

        if len(input_shapes) < 3:
            raise ValueError(f"[TheoOp.{TheoHstu.op_name}]: inputs len must be >= 3")
        if len(output_shapes) != 1:
            raise ValueError(f"[TheoOp.{TheoHstu.op_name}]: outputs len must be 1")

            # S1轴相等
        if input_shapes[0][0] != output_shapes[0][0]:
            raise ValueError(f"[TheoOp.{TheoHstu.op_name}]: S1 must be equal")

    def _dynamic_shape_assign(self) -> dict[str, Any]:

        layout_format = self.op_input.layout_format
        b = self.op_input.input_shapes[0][1]
        total_seq_len = b * self.op_input.input_shapes[0][0]

        param: HSTUExtraParam = self.op_input.param

        if layout_format == 'jagged':

            if param.actual_seq_len is not None:
                actual_seq_len = param.actual_seq_len
            else:
                if param.dist_param is not None:
                    max_seq_len, mean, std, min_seq_len = param.dist_param
                else:
                    max_seq_len = self.op_input.input_shapes[0][0]
                    min_seq_len = 0
                    mean = math.ceil(0.9 * max_seq_len)
                    # 95%分位
                    std = (max_seq_len - min_seq_len) / 6
                actual_seq_len = generate_sequence_lengths_truncated(b, mean, std, min_seq_len, max_seq_len)

            total_seq_len = sum(actual_seq_len)

        dynamic_shape = {
            'S1': total_seq_len,
            'S2': self.op_input.input_shapes[1][0],
            'D1': self.op_input.input_shapes[0][2],
            'D2': self.op_input.input_shapes[2][2],
            'dtype': self.op_input.input_dtypes[0],
            'mem_loc': MemLoc.GM,
        }

        return dynamic_shape