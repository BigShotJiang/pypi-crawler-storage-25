# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from typing import Any

from core.pipeline.tilesim_theo.theo_operator import TheoreticalOperator
from core.common import op_registry
from core.common import OpType, BackendType, DType, MemLoc
from core.frontend.dsl.grammar.kernel import T
from core.frontend.dsl.grammar.tensor import Tensor

batch, M1, K1, B2, K2, N2, B3, M3, N3 = 1, 128, 128, 1, 128, 128, 1, 128, 128
input_d_type = DType.FP32
output_d_type = DType.FP32


def batch_matmul(src1: Tensor(shape=[M1, K1], dtype=input_d_type, mem_loc=MemLoc.GM),
                 src2: Tensor(shape=[K2, N2], dtype=input_d_type, mem_loc=MemLoc.GM),
                 output: Tensor(shape=[M3, N3], dtype=output_d_type, mem_loc=MemLoc.GM),
                 ):
    """
    batch matmul DSL实现
    Args:
        src1:       左矩阵
        src2:       右矩阵
        output:     输出矩阵
        batch:      batch维度大小

    Returns:

    """
    output_l0c = Tensor(shape=[M3, N3], dtype=output_d_type, mem_loc=MemLoc.L0C)
    for _ in range(batch):
        T.TensorOp.gemm(output_l0c, src1, src2)
    T.TensorOp.store(output_l0c)


@op_registry.register(OpType.BatchMatMul, BackendType.THEO)
class TheoBatchMatMul(TheoreticalOperator):
    operator_dsl = batch_matmul

    def _input_check(self):
        input_shapes = self.op_input.input_shapes
        output_shapes = self.op_input.output_shapes
        if len(input_shapes) != 2:
            raise ValueError("[TheoOp.batched_matmul]: inputs len must be 3")

        if input_shapes[0][1] != output_shapes[0][1]:
            raise ValueError("[TheoOp.batched_matmul]: input_shapes[0][1] do not match output_shapes[0][1]")
        if input_shapes[0][2] != input_shapes[1][1]:
            raise ValueError("[TheoOp.batched_matmul]: input_shapes[0][1] do not match output_shapes[1][0]")
        if input_shapes[1][2] != output_shapes[0][2]:
            raise ValueError("[TheoOp.batched_matmul]: input_shapes[1][2] do not match output_shapes[0][2]")
        if input_shapes[0][0] != input_shapes[1][0]:
            raise ValueError("[TheoOp.batched_matmul]: input_shapes[0][0] do not match input_shapes[1][0]")
        if input_shapes[0][0] != output_shapes[0][0]:
            raise ValueError("[TheoOp.batched_matmul]: input_shapes[0][0] do not match output_shapes[0][0]")

        if input_shapes[0][0] != input_shapes[1][0] or input_shapes[0][1] != output_shapes[0][1]:
            raise ValueError("[TheoOp.batched_matmul]: unsupported inputs")

    def _dynamic_shape_assign(self) -> dict[str, Any]:
        input_shapes = self.op_input.input_shapes
        output_shapes = self.op_input.output_shapes
        dynamic_shape = {
            'batch': input_shapes[0][0],
            'M1': input_shapes[0][1],
            'K1': input_shapes[0][2],
            'B2': input_shapes[1][0],
            'K2': input_shapes[1][1],
            'N2': input_shapes[1][2],
            'B3': output_shapes[0][0],
            'M3': output_shapes[0][1],
            'N3': output_shapes[0][2],
            "input_d_type": self.op_input.input_dtypes[0],
            "output_d_type": self.op_input.output_dtypes[0]
        }
        return dynamic_shape