# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from typing import Any

from core.pipeline.tilesim_theo.theo_operator import TheoreticalOperator
from core.common import op_registry
from core.common import OpType, BackendType, DType, MemLoc
from core.frontend.dsl.grammar.kernel import T
from core.frontend.dsl.grammar.tensor import Tensor

M1 = M2 = M3 = M4 = 128
N1 = N2 = N3 = N4 = 64
dtype = DType.FP32
mem_loc = MemLoc.GM


def layer_norm(src1: Tensor(shape=[M1, N1], dtype=dtype, mem_loc=mem_loc),
               src2: Tensor(shape=[M2, N2], dtype=dtype, mem_loc=mem_loc),
               src3: Tensor(shape=[M3, N3], dtype=dtype, mem_loc=mem_loc),
               output: Tensor(shape=[M4, N4], dtype=dtype, mem_loc=mem_loc)
               ):
    """
    LayerNorm 算子DSL实现
    Args:
        src1:
        src2:
        src3:
        output:

    Returns:

    """
    _middle = Tensor(shape=[M1, N1], dtype=dtype, mem_loc=MemLoc.UB)
    _mean = Tensor(shape=[M1, 1], dtype=dtype, mem_loc=MemLoc.UB)
    _x_mean = Tensor(shape=[M1, N1], dtype=dtype, mem_loc=MemLoc.UB)
    _out = Tensor(shape=[M4, N4], dtype=dtype, mem_loc=MemLoc.UB)

    T.TensorOp.mul(_middle, src1, src1)  # x*(1/n)
    T.TensorOp.reduce_sum(_mean, _middle, config={
        'reduce_axis': 1
    })  # E[X]
    T.TensorOp.broadcast(_middle, _mean)
    T.TensorOp.sub(_x_mean, _middle, src1)  # x-E[x]
    T.TensorOp.mul(_x_mean, _x_mean, _x_mean)  # ^2
    T.TensorOp.mul(_x_mean, _x_mean, _x_mean)  # *1/n
    T.TensorOp.reduce_sum(_mean, _x_mean, config={
        'reduce_axis': 1
    })
    T.TensorOp.broadcast(_x_mean, _mean)
    T.TensorOp.add(_x_mean, _x_mean, _x_mean)  # +epsilon
    T.TensorOp.sqrt(_x_mean, _x_mean, _x_mean)  # sqrt
    T.TensorOp.div(_middle, _middle, _x_mean)  # rstd
    T.TensorOp.mul(_middle, _middle, _middle)  # *rstd
    T.TensorOp.mul(_middle, _middle, src2)  # *gamma
    T.TensorOp.add(_out, _middle, src3)  # + beta
    T.TensorOp.store(_out)


@op_registry.register(OpType.LayerNorm, BackendType.THEO)
class TheoLayerNorm(TheoreticalOperator):
    operator_dsl = layer_norm

    def _input_check(self):
        input_shapes = self.op_input.input_shapes
        output_shapes = self.op_input.output_shapes
        if len(input_shapes) != 3:
            raise ValueError(f"[TheoOp.{TheoLayerNorm.op_name}]: inputs len must be 3")

        if len(output_shapes) != 1:
            raise ValueError(f"[TheoOp.{TheoLayerNorm.op_name}]: outputs len must be 1")
        for shape in input_shapes:
            if len(shape) != 2:
                raise ValueError(f"[TheoOp.{TheoLayerNorm.op_name}]: input dim must be 2")
            if shape[0] != output_shapes[0][0] and shape[0] != 1:
                raise ValueError(f"[TheoOp.{TheoLayerNorm.op_name}]: input dim0 not match output")
            if shape[1] != output_shapes[0][1] and shape[1] != 1:
                raise ValueError(f"[TheoOp.{TheoLayerNorm.op_name}]: input dim1 not match output")

    def _dynamic_shape_assign(self) -> dict[str, Any]:
        input_shapes = self.op_input.input_shapes
        output_shapes = self.op_input.output_shapes
        dynamic_shape = {
            'M1': input_shapes[0][0],
            'N1': input_shapes[0][1],
            'M2': input_shapes[1][0],
            'N2': input_shapes[1][1],
            'M3': input_shapes[2][0],
            'N3': input_shapes[2][1],
            'M4': output_shapes[0][0],
            'N4': output_shapes[0][1],
            'dtype': self.op_input.input_dtypes[0],
            'mem_loc': MemLoc.GM,
        }

        return dynamic_shape