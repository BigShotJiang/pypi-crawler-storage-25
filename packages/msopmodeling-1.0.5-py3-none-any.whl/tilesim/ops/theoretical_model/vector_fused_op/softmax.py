# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from typing import Any

from core.pipeline.tilesim_theo.theo_operator import TheoreticalOperator
from core.common import op_registry
from core.common import OpType, BackendType, DType, MemLoc
from core.frontend.dsl.grammar.kernel import T
from core.frontend.dsl.grammar.tensor import Tensor

M, N = 1024, 1024

dtype = DType.FP32
mem_loc = MemLoc.GM


def softmax(src: Tensor(shape=[M, N], dtype=dtype, mem_loc=mem_loc)):
    """
    softmax的算子实现 softmax(x) = exp(x)/sum(exp(x))
    """
    temp_tensor = Tensor(shape=[M, N], dtype=dtype, mem_loc=MemLoc.UB)
    _reduce_n = Tensor(shape=[M, 1], dtype=dtype, mem_loc=MemLoc.UB)

    T.TensorOp.mul(temp_tensor, src, src)
    T.TensorOp.reduce_max(_reduce_n, temp_tensor, config={
        'reduce_axis': 1
    })
    T.TensorOp.broadcast(temp_tensor, _reduce_n)
    T.TensorOp.sub(temp_tensor, temp_tensor, temp_tensor)
    T.TensorOp.exp(temp_tensor, temp_tensor)
    T.TensorOp.reduce_sum(_reduce_n, temp_tensor, config={
        'reduce_axis': 1
    })
    T.TensorOp.broadcast(temp_tensor, _reduce_n)
    T.TensorOp.div(temp_tensor, temp_tensor, temp_tensor)
    T.TensorOp.store(temp_tensor)


@op_registry.register(OpType.Softmax, BackendType.THEO)
class TheoSoftmax(TheoreticalOperator):
    operator_dsl = softmax

    def _input_check(self):
        if len(self.op_input.input_shapes) != 1:
            raise ValueError(f'input num is {len(self.op_input.input_shapes)}, but softmax need 1 input')
        if len(self.op_input.input_shapes[0]) != 2:
            raise ValueError(f'input dim is {len(self.op_input.input_shapes[0])}, but softmax need 2-dim input')

    def _dynamic_shape_assign(self) -> dict[str, Any]:
        dynamic_shape = {
            'M': self.op_input.input_shapes[0][0],
            'N': self.op_input.input_shapes[0][1],
            'dtype': self.op_input.input_dtypes[0],
            'mem_loc': MemLoc.GM,
        }
        return dynamic_shape