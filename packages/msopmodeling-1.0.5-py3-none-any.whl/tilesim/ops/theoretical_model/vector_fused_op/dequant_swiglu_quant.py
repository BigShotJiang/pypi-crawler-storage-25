# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import math
from typing import Any

from core.common.backend_config import BackendConfig, FitParamKey
from core.pipeline.tilesim_theo.theo_operator import TheoreticalOperator
from core.common import op_registry
from core.common import OpType, BackendType, DType, MemLoc
from core.frontend.dsl.grammar.kernel import T
from core.frontend.dsl.grammar.tensor import Tensor

x_shape, yout_shape, i_dtype, o_dtype, scale_dtype = T.define_symbol(5)


def dequant_swiglu_quant(x: Tensor(shape=[x_shape], dtype=i_dtype, mem_loc=MemLoc.GM),
                         yout: Tensor(shape=[yout_shape], dtype=o_dtype, mem_loc=MemLoc.GM)
                         ):
    """
    dequant_swiglu_quant算子DSL实现
    """
    input_ub = Tensor(shape=[x_shape], dtype=i_dtype, mem_loc=MemLoc.UB)

    _A_input = Tensor(shape=[yout_shape], dtype=i_dtype, mem_loc=MemLoc.UB)
    _A = Tensor(shape=[yout_shape], dtype=scale_dtype, mem_loc=MemLoc.UB)
    _B = Tensor(shape=[yout_shape], dtype=scale_dtype, mem_loc=MemLoc.UB)
    _one = Tensor(shape=[1], dtype=DType.FP32, mem_loc=MemLoc.UB)
    _tmp = Tensor(shape=[yout_shape], dtype=DType.FP32, mem_loc=MemLoc.UB)
    _out = Tensor(shape=[yout_shape], dtype=o_dtype, mem_loc=MemLoc.UB)

    T.TensorOp.null_op(input_ub, x)
    T.TensorOp.cast(_A, _A_input)

    T.TensorOp.muls(_A, _A, _one)
    T.TensorOp.exp(_A, _A)
    T.TensorOp.adds(_A, _A, _one)
    T.TensorOp.div(_A, _one, _A)
    T.TensorOp.cast(_A, _A_input)
    T.TensorOp.mul(_A, _A, _A)
    T.TensorOp.mul(_A, _A, _B)

    T.TensorOp.abs(_A, _A)
    T.TensorOp.max(_A, _A, _A)
    T.TensorOp.muls(_A, _A, _A)
    T.TensorOp.cast(_A_input, _A)
    T.TensorOp.cast(_tmp, _A_input)
    T.TensorOp.cast(_out, _tmp)
    T.TensorOp.store(_out)


@op_registry.register(OpType.DequantSwigluQuant, BackendType.THEO)
class TheoDequantSwigluQuant(TheoreticalOperator):
    operator_dsl = dequant_swiglu_quant

    def _input_check(self):
        input_shapes = self.op_input.input_shapes
        output_shapes = self.op_input.output_shapes
        if len(input_shapes) != 7:
            raise ValueError(f"[TheoOp.{TheoDequantSwigluQuant.op_name}]: inputs len must be 7")
        if len(output_shapes) != 2:
            raise ValueError(f"[TheoOp.{TheoDequantSwigluQuant.op_name}]: outputs len must be 2")
        if input_shapes[0][-1] != 2 * output_shapes[0][-1]:
            raise ValueError(
                f"[TheoOp.{TheoDequantSwigluQuant.op_name}]: input_shape last dim must be twice the size of output_shape last dim")
        pass

    def _dynamic_shape_assign(self) -> dict[str, Any]:
        """
            InputShapes:
            1. x
            2. weightScaleOptional
            3. activationScaleOptional
            4. biasOptional
            5. quantScaleOptional
            6. quantOffsetOptional
            7. groupIndexOptional

            OutputShapes:
            1. yOut
            2. scaleOut
        """
        input_shapes = self.op_input.input_shapes
        output_shapes = self.op_input.output_shapes
        input_dtypes = self.op_input.input_dtypes
        output_dtypes = self.op_input.output_dtypes
        dynamic_shape = {
            'x_shape': math.prod(input_shapes[0]),
            'yout_shape': math.prod(output_shapes[0]),
            'i_dtype': input_dtypes[0],
            'o_dtype': output_dtypes[0],
            'scale_dtype': output_dtypes[1],
        }
        return dynamic_shape

    def _adjust_coeff(self, backend_config: BackendConfig):
        fit_param = backend_config.eval_config.fit_param

        if FitParamKey.BW_COEFF not in fit_param:
            fit_param[FitParamKey.BW_COEFF] = 8.0

        if FitParamKey.COMP_COEFF not in fit_param:
            fit_param[FitParamKey.COMP_COEFF] = 5.0

        if FitParamKey.SCALAR_TIME not in fit_param:
            fit_param[FitParamKey.SCALAR_TIME] = 1.0