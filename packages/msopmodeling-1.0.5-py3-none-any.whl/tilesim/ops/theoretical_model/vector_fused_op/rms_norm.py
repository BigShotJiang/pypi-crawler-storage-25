# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import math
from typing import Any

from core.pipeline.tilesim_theo.theo_operator import TheoreticalOperator
from core.common import op_registry
from core.common import OpType, BackendType, DType, MemLoc
from core.frontend.dsl.grammar.kernel import T
from core.frontend.dsl.grammar.tensor import Tensor

ROW, COL = T.define_symbol(2)
dtype_x, dtype_gamma, dtype_eps, dtype_rstd = T.define_symbol(4)


def rms_norm(x: Tensor(shape=[ROW, COL], dtype=dtype_x, mem_loc=MemLoc.GM),
             gamma: Tensor(shape=[ROW], dtype=dtype_gamma, mem_loc=MemLoc.GM),
             epsilon: Tensor(shape=[1], dtype=dtype_eps, mem_loc=MemLoc.GM),
             y_out: Tensor(shape=[ROW, COL], dtype=dtype_x, mem_loc=MemLoc.GM),
             rstd_out: Tensor(shape=[ROW, 1], dtype=dtype_rstd, mem_loc=MemLoc.GM)
             ):
    """
    rms_norm算子DSL实现
    x	输入	表示进行归一化计算的输入。公式中的`x`。	FLOAT32、FLOAT16、BFLOAT16	ND
    gamma	输入	表示进行归一化计算的缩放因子（权重），公式中的`g`。	FLOAT32、FLOAT16、BFLOAT16	ND
    epsilon	可选属性	添加到分母中的值，以确保数值稳定，对应公式中的eps
    y	输出	表示进行归一化后的最终输出，公式中的`RmsNorm(x)`。	FLOAT32、FLOAT16、BFLOAT16	ND
    rstd	输出	表示归一化后的标准差倒数，公式中`Rms(x)`的倒数。
    """
    _x_ub = Tensor(shape=[ROW, COL], dtype=dtype_x, mem_loc=MemLoc.UB)
    _reduce_n = Tensor(shape=[ROW, 1], dtype=dtype_x, mem_loc=MemLoc.UB)
    _one_div_n = Tensor(shape=[1], dtype=DType.FP32, mem_loc=MemLoc.UB)
    _ones = Tensor(shape=[1], dtype=DType.FP32, mem_loc=MemLoc.UB)
    _broadcast_n = Tensor(shape=[ROW, COL], dtype=dtype_x, mem_loc=MemLoc.UB)
    _y = Tensor(shape=[ROW, COL], dtype=dtype_x, mem_loc=MemLoc.UB)
    _rstd = Tensor(shape=[ROW, 1], dtype=dtype_rstd, mem_loc=MemLoc.UB)

    T.TensorOp.mul(_x_ub, x, x)  # VMUL后的shape[ROW, COL]
    T.TensorOp.reduce_sum(_reduce_n, _x_ub, config={
        'reduce_axis': -1
    })  # VADD+VCADD后的shape[ROW, 1]
    T.TensorOp.muls(_reduce_n, _reduce_n, _one_div_n)  # VMULS后的shape[ROW, 1]
    T.TensorOp.adds(_reduce_n, _reduce_n, epsilon)  # VADDS后的shape[M1, 1]

    T.TensorOp.sqrt(_rstd, _reduce_n)  # VSQRT后的shape[ROW, 1]
    T.TensorOp.store(_rstd)

    T.TensorOp.div(_reduce_n, _ones, _reduce_n)  # VDIV后的shape[ROW, 1]
    T.TensorOp.broadcast(_broadcast_n, _reduce_n)  # broadcast后的shape[ROW, COL]

    T.TensorOp.mul(_x_ub, _broadcast_n, _x_ub)  # VMUL后的shape[ROW, COL]
    T.TensorOp.mul(_y, _x_ub, gamma)  # VMUL后的shape[ROW, COL]
    T.TensorOp.store(_y)


@op_registry.register(OpType.RmsNorm, BackendType.THEO)
class TheoRMSNorm(TheoreticalOperator):
    operator_dsl = rms_norm

    def _input_check(self):
        input_shapes = self.op_input.input_shapes
        output_shapes = self.op_input.output_shapes
        if len(input_shapes) != 2 and len(input_shapes) != 3:
            raise ValueError(f"[TheoOp.{TheoRMSNorm.op_name}]: inputs len must be 2 or 3")
        if len(output_shapes) != 2:
            raise ValueError(f"[TheoOp.{TheoRMSNorm.op_name}]: outputs len must be 2")
        if input_shapes[0] != output_shapes[0]:
            raise ValueError(f"[TheoOp.{TheoRMSNorm.op_name}]: input_shapes[0] and output_shapes[0] must be equal")

    def _dynamic_shape_assign(self) -> dict[str, Any]:
        input_shapes = self.op_input.input_shapes
        input_dtypes = self.op_input.input_dtypes
        output_dtypes = self.op_input.output_dtypes
        dynamic_shape = {
            'ROW': math.prod(input_shapes[0][:-1]),
            'COL': input_shapes[0][-1],
            'dtype_x': input_dtypes[0],
            'dtype_gamma': input_dtypes[1],
            'dtype_eps': DType.FP32,
            'dtype_rstd': output_dtypes[1]
        }
        return dynamic_shape