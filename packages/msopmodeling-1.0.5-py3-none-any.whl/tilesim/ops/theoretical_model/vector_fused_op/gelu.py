# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from typing import Any

from core.pipeline.tilesim_theo.theo_operator import TheoreticalOperator
from core.common import op_registry
from core.common import OpType, BackendType, DType, MemLoc
from core.frontend.dsl.grammar.kernel import T
from core.frontend.dsl.grammar.tensor import Tensor

m1, n1, m2, n2 = 128, 128, 128, 128
d_type = DType.FP32


def theo_gelu(src1: Tensor(shape=[m1, n1], dtype=d_type, mem_loc=MemLoc.GM),
              output: Tensor(shape=[m2, n2], dtype=d_type, mem_loc=MemLoc.GM)):
    """
    GeLU算子DSL实现
    Args:
        src1:
        output:

    Returns:

    """
    input_x1 = Tensor([m1, n1], d_type, MemLoc.GM)
    input_x2 = Tensor([m2, n2], d_type, MemLoc.UB)
    x_square = Tensor([m1, n1], d_type, MemLoc.UB)
    x_cube = Tensor([m1, n1], d_type, MemLoc.UB)
    s_mul_x_cube = Tensor([m1, n1], d_type, MemLoc.UB)
    add_result = Tensor([m1, n1], d_type, MemLoc.UB)
    y = Tensor([m1, n1], d_type, MemLoc.UB)
    exp_y = Tensor([m1, n1], d_type, MemLoc.UB)
    s_add_exp_y = Tensor([m1, n1], d_type, MemLoc.UB)
    out = Tensor([m1, n1], d_type, MemLoc.UB)

    T.TensorOp.mul(x_square, input_x1, input_x1)  # 公式 input_x^2, x_square = input_x^2
    T.TensorOp.mul(x_cube, x_square, input_x2)  # 公式 input_x^3, x_cube = x_square * input_x
    T.TensorOp.mul(s_mul_x_cube, x_cube, x_cube)  # 公式 0.044715 * input_x^3, s_mul_x_cube= scalar * x_cube
    T.TensorOp.add(add_result, input_x2, s_mul_x_cube)  # 公式 input_x + 0.044715 * input_x^3,
    T.TensorOp.mul(y, input_x2, add_result)  # 公式 y = (input_x + 0.044715 * input_x^3) * (-2) * (np.sqrt(2/np.pi)
    T.TensorOp.mul(exp_y, y)  # e(y)
    T.TensorOp.add(s_add_exp_y, exp_y, exp_y)  # 公式 1 + e(y)
    T.TensorOp.div(out, input_x2, s_add_exp_y)  # 公式 input_x / (1 + e(y))
    T.TensorOp.store(out)


@op_registry.register(OpType.Gelu, BackendType.THEO)
class TheoGelu(TheoreticalOperator):
    operator_dsl = theo_gelu

    def _input_check(self):
        input_shapes = self.op_input.input_shapes
        output_shapes = self.op_input.output_shapes
        if len(input_shapes) != 1:
            raise ValueError("[TheoOp.gelu]: inputs len must be 1")

        if len(output_shapes) != 1:
            raise ValueError("[TheoOp.gelu]: outputs len must be 1")

        for shape in input_shapes:
            if len(shape) != 2:
                raise ValueError("[TheoOp.gelu]: input dim must be 2")
            if shape[0] != output_shapes[0][0]:
                raise ValueError("[TheoOp.gelu]: input dim0 not match output")
            if shape[1] != output_shapes[0][1]:
                raise ValueError("[TheoOp.gelu]: input dim1 not match output")

    def _dynamic_shape_assign(self) -> dict[str, Any]:
        input_shapes = self.op_input.input_shapes
        output_shapes = self.op_input.output_shapes
        dynamic_shape = {
            'm1': input_shapes[0][0],
            'n1': input_shapes[0][1],
            'm2': output_shapes[0][0],
            'n2': output_shapes[0][1]
        }

        return dynamic_shape