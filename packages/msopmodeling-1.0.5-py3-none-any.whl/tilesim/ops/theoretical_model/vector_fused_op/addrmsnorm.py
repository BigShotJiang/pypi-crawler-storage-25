# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from typing import Any

from core.pipeline.tilesim_theo.theo_operator import TheoreticalOperator
from core.common import op_registry
from core.common import OpType, BackendType, DType, MemLoc
from core.frontend.dsl.grammar.kernel import T
from core.frontend.dsl.grammar.tensor import Tensor

M1, N1, M2, N2, N3, M4, N4 = 128, 128, 128, 128, 128, 128, 128
d_type = DType.FP32


def theo_addrmsnorm(input1: Tensor(shape=[M1, N1], dtype=d_type, mem_loc=MemLoc.GM),
                    input2: Tensor(shape=[M2, N2], dtype=d_type, mem_loc=MemLoc.GM),
                    input_gama: Tensor(shape=[N3], dtype=d_type, mem_loc=MemLoc.GM),
                    output: Tensor(shape=[M4, N4], dtype=d_type, mem_loc=MemLoc.GM)):
    """
    add rms norm 算子DSL实现
    Args:
        input1:
        input2:
        input_gama:
        output:

    Returns:

    """
    x1_add_x2 = Tensor([M1, N1], d_type, MemLoc.UB)
    x_square = Tensor([M1, N1], d_type, MemLoc.UB)
    reduce_sum_result = Tensor([M1, 1], DType.FP32, MemLoc.UB)
    reduce_sum_add_eps = Tensor([M1, 1], DType.FP32, MemLoc.UB)
    div_result = Tensor([M1, N1], d_type, MemLoc.UB)
    sqrt_result = Tensor([M1, 1], DType.FP32, MemLoc.UB)
    output_ub = Tensor(shape=[M4, N4], dtype=d_type, mem_loc=MemLoc.UB)

    T.TensorOp.add(x1_add_x2, input1, input2)  # x1+x2
    T.TensorOp.mul(x_square, x1_add_x2, x1_add_x2)  # x_square*xquare
    T.TensorOp.reduce_sum(reduce_sum_result, x_square)
    T.TensorOp.add(reduce_sum_add_eps, reduce_sum_result, reduce_sum_result)
    T.TensorOp.div(reduce_sum_add_eps, reduce_sum_result, reduce_sum_result)
    T.TensorOp.sqrt(sqrt_result, reduce_sum_add_eps)
    T.TensorOp.div(div_result, x1_add_x2, sqrt_result)
    T.TensorOp.mul(output_ub, div_result, input_gama)
    T.TensorOp.store(output_ub)


@op_registry.register(OpType.AddRmsNorm, BackendType.THEO)
class TheoAddRmsNorm(TheoreticalOperator):
    operator_dsl = theo_addrmsnorm

    def _input_check(self):
        input_shapes = self.op_input.input_shapes
        output_shapes = self.op_input.output_shapes
        if len(input_shapes) != 3:
            raise ValueError("[TheoOp.addrmsnorm]: inputs len must be 2")

        if len(output_shapes) != 1:
            raise ValueError("[TheoOp.addrmsnorm]: outputs len must be 1")

        if len(input_shapes[0]) != 2 or len(input_shapes[1]) != 2:
            raise ValueError("[TheoOp.addrmsnorm]: input0 and input1 len must be 2")

        if input_shapes[0][0] != 1 or input_shapes[1][0] != 1:
            raise ValueError("[TheoOp.addrmsnorm]: input[0][0] and input[1][0] must be 2")

        if input_shapes[0][1] != input_shapes[2][0] or input_shapes[1][1] != input_shapes[2][0]:
            raise ValueError("[TheoOp.addrmsnorm]: input[0][1] , input[1][1] and input[2][0] must be equal")

    def _dynamic_shape_assign(self) -> dict[str, Any]:
        input_shapes = self.op_input.input_shapes
        output_shapes = self.op_input.output_shapes
        dynamic_shape = {
            'M1': input_shapes[0][0],
            'N1': input_shapes[0][1],
            'M2': input_shapes[1][0],
            'N2': input_shapes[1][1],
            'N3': input_shapes[2][0],
            'M4': output_shapes[0][0],
            'N4': output_shapes[0][1]
        }
        return dynamic_shape