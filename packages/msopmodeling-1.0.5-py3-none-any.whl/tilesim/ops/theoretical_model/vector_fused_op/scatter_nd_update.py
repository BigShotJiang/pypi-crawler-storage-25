# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import math
from typing import Any

from core.common.backend_config import BackendConfig, FitParamKey
from core.pipeline.tilesim_theo.theo_operator import TheoreticalOperator
from core.common import op_registry
from core.common import OpType, BackendType, MemLoc
from core.frontend.dsl.grammar.kernel import T
from core.frontend.dsl.grammar.tensor import Tensor

UPDATE_SIZE, TOTAL_SIZE, dtype = T.define_symbol(3)


def scatter_nd_update(input_x: Tensor(shape=[TOTAL_SIZE], dtype=dtype, mem_loc=MemLoc.GM),
                      updates: Tensor(shape=[UPDATE_SIZE], dtype=dtype, mem_loc=MemLoc.GM),
                      ):
    """
    scatter_nd_update算子DSL实现，根据给定下标，把updates内容更新到input_x上
    """
    updates_ub = Tensor(shape=[UPDATE_SIZE], dtype=dtype, mem_loc=MemLoc.UB)
    input_ub = Tensor(shape=[TOTAL_SIZE], dtype=dtype, mem_loc=MemLoc.UB)

    T.TensorOp.null_op(updates_ub, updates)
    T.TensorOp.null_op(input_ub, input_x)
    T.TensorOp.copy(updates_ub, updates_ub)
    T.TensorOp.store(updates_ub)


@op_registry.register(OpType.ScatterNdUpdate, BackendType.THEO)
class TheoScatterNdUpdate(TheoreticalOperator):
    operator_dsl = scatter_nd_update

    def _input_check(self):
        input_shapes = self.op_input.input_shapes
        output_shapes = self.op_input.output_shapes
        if len(input_shapes) != 3:
            raise ValueError(f"[TheoOp.{TheoScatterNdUpdate.op_name}]: inputs len must be 3")
        if len(output_shapes) != 1:
            raise ValueError(f"[TheoOp.{TheoScatterNdUpdate.op_name}]: outputs len must be 1")
        if input_shapes[0] != output_shapes[0]:
            raise ValueError(
                f"[TheoOp.{TheoScatterNdUpdate.op_name}]: input_shapes[0] and output_shapes[0] must be equal")
        pass

    def _dynamic_shape_assign(self) -> dict[str, Any]:
        input_shapes = self.op_input.input_shapes
        output_shapes = self.op_input.output_shapes
        input_dtypes = self.op_input.input_dtypes
        dynamic_shape = {
            'TOTAL_SIZE': math.prod(input_shapes[0]),
            'UPDATE_SIZE': input_shapes[1][0] * math.prod(input_shapes[2]),
            'dtype': input_dtypes[0]
        }
        return dynamic_shape

    def _adjust_coeff(self, backend_config: BackendConfig):
        fit_param = backend_config.eval_config.fit_param

        if FitParamKey.BW_COEFF not in fit_param:
            fit_param[FitParamKey.BW_COEFF] = 10

        if FitParamKey.COMP_COEFF not in fit_param:
            fit_param[FitParamKey.COMP_COEFF] = 1.0

        if FitParamKey.SCALAR_TIME not in fit_param:
            fit_param[FitParamKey.SCALAR_TIME] = 9.0