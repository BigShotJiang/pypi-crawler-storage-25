# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import math
from typing import Any

from core.common.backend_config import FitParamKey, BackendConfig
from core.pipeline.tilesim_theo.theo_operator import TheoreticalOperator
from core.common import op_registry
from core.common import OpType, BackendType, DType, MemLoc
from core.frontend.dsl.grammar.kernel import T
from core.frontend.dsl.grammar.tensor import Tensor

i_shape, o_shape, dtype = T.define_symbol(3)


def swiglu(x: Tensor(shape=[i_shape], dtype=dtype, mem_loc=MemLoc.GM),
           out: Tensor(shape=[o_shape], dtype=dtype, mem_loc=MemLoc.GM)
           ):
    """
    swiglu算子DSL实现
    """
    input_ub = Tensor(shape=[i_shape], dtype=dtype, mem_loc=MemLoc.UB)

    _A = Tensor(shape=[o_shape], dtype=dtype, mem_loc=MemLoc.UB)
    _B = Tensor(shape=[o_shape], dtype=dtype, mem_loc=MemLoc.UB)
    _one = Tensor(shape=[1], dtype=DType.FP32, mem_loc=MemLoc.UB)

    T.TensorOp.null_op(input_ub, x)
    T.TensorOp.muls(_A, _A, _one)
    T.TensorOp.exp(_A, _A)
    T.TensorOp.adds(_A, _A, _one)
    T.TensorOp.div(_A, _one, _A)
    T.TensorOp.mul(_A, _A, _A)
    T.TensorOp.mul(_A, _A, _B)
    T.TensorOp.store(_A)


@op_registry.register(OpType.Swiglu, BackendType.THEO)
class TheoSwiglu(TheoreticalOperator):
    operator_dsl = swiglu

    def _input_check(self):
        input_shapes = self.op_input.input_shapes
        output_shapes = self.op_input.output_shapes
        if len(input_shapes) != 1:
            raise ValueError(f"[TheoOp.{TheoSwiglu.op_name}]: inputs len must be 1")
        if len(output_shapes) != 1:
            raise ValueError(f"[TheoOp.{TheoSwiglu.op_name}]: outputs len must be 1")
        if input_shapes[0][-1] != 2 * output_shapes[0][-1]:
            raise ValueError(
                f"[TheoOp.{TheoSwiglu.op_name}]: input_shape last dim must be twice the size of output_shape last dim")
        pass

    def _dynamic_shape_assign(self) -> dict[str, Any]:
        """
            InputShapes:
            1. x

            OutputShapes:
            1. out
        """
        input_shapes = self.op_input.input_shapes
        output_shapes = self.op_input.output_shapes
        input_dtypes = self.op_input.input_dtypes
        dynamic_shape = {
            'i_shape': math.prod(input_shapes[0]),
            'o_shape': math.prod(output_shapes[0]),
            'dtype': input_dtypes[0]
        }
        return dynamic_shape

    def _adjust_coeff(self, backend_config: BackendConfig):
        fit_param = backend_config.eval_config.fit_param

        if FitParamKey.BW_COEFF not in fit_param:
            fit_param[FitParamKey.BW_COEFF] = 0.7

        if FitParamKey.COMP_COEFF not in fit_param:
            fit_param[FitParamKey.COMP_COEFF] = 1

        if FitParamKey.SCALAR_TIME not in fit_param:
            fit_param[FitParamKey.SCALAR_TIME] = 4