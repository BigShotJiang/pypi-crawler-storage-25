# Copyright (c) Huawei Technologies Co., Ltd. 2025-2026. All rights reserved.

from typing import Any

from core.common.backend_config import FitParamKey, BackendConfig
from core.pipeline.tilesim_theo.theo_operator import TheoreticalOperator
from core.common import op_registry
from core.common import OpType, BackendType


def pad_v3():
    """
    pad_v3算子DSL实现
    """
    pass


@op_registry.register(OpType.PadV3, BackendType.THEO)
class TheoPadV3(TheoreticalOperator):
    operator_dsl = pad_v3

    def _input_check(self):
        pass

    def _dynamic_shape_assign(self) -> dict[str, Any]:
        pass

    def _adjust_coeff(self, backend_config: BackendConfig):
        fit_param = backend_config.eval_config.fit_param

        if FitParamKey.BW_COEFF not in fit_param:
            fit_param[FitParamKey.BW_COEFF] = 0.01

        if FitParamKey.COMP_COEFF not in fit_param:
            fit_param[FitParamKey.COMP_COEFF] = 1.0

        if FitParamKey.SCALAR_TIME not in fit_param:
            fit_param[FitParamKey.SCALAR_TIME] = 51.92