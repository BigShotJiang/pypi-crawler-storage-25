# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from typing import Any

from core.pipeline.tilesim_theo.theo_operator import TheoreticalOperator
from core.common import op_registry
from core.common import OpType, BackendType, DType, MemLoc
from core.frontend.dsl.grammar.kernel import T
from core.frontend.dsl.grammar.tensor import Tensor

M1 = M2 = 128
N1 = N2 = 128
dtype = DType.FP32
mem_loc = MemLoc.GM


def concat_d(src1: Tensor(shape=[M1, N1], dtype=dtype, mem_loc=mem_loc),
             src2: Tensor(shape=[M1, N1], dtype=dtype, mem_loc=mem_loc),
             output: Tensor(shape=[M2, N2], dtype=dtype, mem_loc=mem_loc)
             ):
    """
    concat_d 算子DSL实现
    Args:
        src1:
        src2:
        output:

    Returns:

    """
    output_ub = Tensor(shape=[M2, N2], dtype=dtype, mem_loc=MemLoc.UB)
    T.TensorOp.null_op(output_ub, src1)  # null op是不是应该以src输入为准
    T.TensorOp.null_op(output_ub, src2)
    T.TensorOp.store(output_ub)


@op_registry.register(OpType.ConcatD, BackendType.THEO)
class TheoConcatD(TheoreticalOperator):
    operator_dsl = concat_d

    def _input_check(self):
        input_shapes = self.op_input.input_shapes
        output_shapes = self.op_input.output_shapes
        if len(input_shapes) != 2:
            raise ValueError(f"[TheoOp.{TheoConcatD.op_name}]: inputs len must be 2")

        if len(output_shapes) != 1:
            raise ValueError(f"[TheoOp.{TheoConcatD.op_name}]: outputs len must be 1")

        if input_shapes[0][0] != input_shapes[1][0] or input_shapes[0][1] != input_shapes[1][1]:
            raise ValueError(f"[TheoOp.{TheoConcatD.op_name}]: src1 src2 shapes must match")
        if (output_shapes[0][1] != input_shapes[1][1] + input_shapes[0][1]
                and output_shapes[0][0] == input_shapes[1][0]):
            raise ValueError(f"[TheoOp.{TheoConcatD.op_name}]: src3 second dim must equal to src1+src2 ")

    def _dynamic_shape_assign(self) -> dict[str, Any]:
        input_shapes = self.op_input.input_shapes
        output_shapes = self.op_input.output_shapes
        dynamic_shape = {
            'M1': input_shapes[0][0],
            'N1': input_shapes[0][1],
            'M2': input_shapes[1][0],
            'N2': input_shapes[1][1],
            'M3': output_shapes[0][0],
            'N3': output_shapes[0][1],
            'dtype': self.op_input.input_dtypes[0],
            'mem_loc': MemLoc.GM,
        }
        return dynamic_shape