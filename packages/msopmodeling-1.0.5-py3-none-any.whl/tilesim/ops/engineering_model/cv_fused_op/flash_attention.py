# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from typing import Any

from core.common import MemLoc, DType, OpType, BackendType
from core.common import op_registry
from core.common.backend_config import OptimType, OptimConfig
from core.frontend.dsl.grammar.kernel import T
from core.frontend.dsl.grammar.tensor import Tensor
from core.pipeline.tilesim_eng.eng_operator import EngineeringOperator

B, S1, S2, N, D1, D2, C_TYPE, V_TYPE = T.define_symbol(8)


def flash_attention(
        q: Tensor(shape=[S1, D1], dtype=C_TYPE, mem_loc=MemLoc.GM),
        k: Tensor(shape=[D1, S2], dtype=C_TYPE, mem_loc=MemLoc.GM),
        v: Tensor(shape=[S2, D2], dtype=C_TYPE, mem_loc=MemLoc.GM),
        o: Tensor(shape=[S1, D2], dtype=C_TYPE, mem_loc=MemLoc.GM),

        # C/V的S1切块大小： s1c = (AIC_CNT/AIV_CNT) * s1v
        t_s1c=None,
        t_s1v=None,

        # C/V的S2切块大小
        t_s2c=None,
        t_s2v=None,

        # C/V间数据同步的大小。 matmul计算 n_s2 个tile块，一次性同步给AIV进行计算
        n_s2=None,

):
    t_s2_trans = n_s2 * t_s1c

    # 中间变量分配
    workspace_s = Tensor(shape=[t_s1c, t_s2_trans], dtype=V_TYPE, mem_loc=MemLoc.GM)
    workspace_p = Tensor(shape=[t_s1c, t_s2_trans], dtype=V_TYPE, mem_loc=MemLoc.GM)
    workspace_o = Tensor(shape=[t_s1c, D2], dtype=V_TYPE, mem_loc=MemLoc.GM)

    # 常驻UB内存分配
    workspace_ub_m = Tensor(shape=[t_s1v, 8], dtype=V_TYPE, mem_loc=MemLoc.UB)
    workspace_ub_expmax = Tensor(shape=[t_s1v, 8], dtype=V_TYPE, mem_loc=MemLoc.UB)
    workspace_ub_l = Tensor(shape=[t_s1v, 8], dtype=V_TYPE, mem_loc=MemLoc.UB)
    workspace_ub_o = Tensor(shape=[t_s1v, D2], dtype=V_TYPE, mem_loc=MemLoc.UB)

    # QK乘
    s1_tiles_c = T.ceil(S1 / t_s1c)
    s2_tiles_c = T.ceil(S2 / t_s2c)

    with T.Task(name="qk", range=[s1_tiles_c, s2_tiles_c]) as ([i, j]):
        # 张量声明
        q_tile_l1 = Tensor(shape=[t_s1c, t_s2c], dtype=C_TYPE, mem_loc=MemLoc.L1)
        k_tile_l1 = Tensor(shape=[t_s2c, t_s1c], dtype=C_TYPE, mem_loc=MemLoc.L1)
        s_tile_l0c = Tensor(shape=[t_s1c, t_s2c], dtype=V_TYPE, mem_loc=MemLoc.L0C)

        s_tile = workspace_s.view([t_s1c, t_s2c])

        T.TileOp.copy(q_tile_l1, q[i * t_s1c: T.min((i + 1) * t_s1c, S1), :])
        T.TileOp.copy(k_tile_l1, k[:, j * t_s2c: T.min((j + 1) * t_s2c, S2)])
        T.TileOp.gemm(s_tile_l0c, q_tile_l1, k_tile_l1)

        T.TileOp.copy(s_tile, s_tile_l0c)

    # softmax
    s1_tiles_v = T.ceil(S1/t_s1v/2)
    s2_tiles_v = T.ceil(S2/t_s2v)
    with T.Task(name="softmax", range=[s1_tiles_v, s2_tiles_v]) as ([i, j]):
        s_tile = workspace_s.view([t_s1v, t_s2v])
        s_tile_ub = Tensor(shape=[t_s1v, t_s2v], dtype=V_TYPE, mem_loc=MemLoc.UB)
        p_tile = workspace_p.view([t_s1v, t_s2v])

        T.TileOp.copy(s_tile_ub, s_tile)

        # row_max
        row_max = Tensor(shape=[t_s1v, 1], dtype=V_TYPE, mem_loc=MemLoc.UB)
        cur_m = Tensor(shape=[t_s1v, 8], dtype=V_TYPE, mem_loc=MemLoc.UB)
        T.TileOp.reduce_max(row_max, s_tile_ub, axis=1)
        T.TileOp.broadcast(cur_m, row_max, axis=1)

        # 每行除第一个tile块外，更新全局row_max
        if j > 0:
            T.TileOp.max(cur_m, cur_m, workspace_ub_m)
            T.TileOp.sub(workspace_ub_expmax, cur_m, workspace_ub_m)

            T.TileOp.exp(workspace_ub_expmax, workspace_ub_expmax)

            T.TileOp.sub(s_tile_ub, s_tile_ub, cur_m)
            T.TileOp.exp(s_tile_ub, s_tile_ub)

            cur_l_reduce = Tensor(shape=[t_s1v, 1], dtype=V_TYPE, mem_loc=MemLoc.UB)
            cur_l = Tensor(shape=[t_s1v, t_s2v], dtype=V_TYPE, mem_loc=MemLoc.UB)
            T.TileOp.reduce_sum(cur_l_reduce, s_tile_ub, axis=1)
            T.TileOp.broadcast(cur_l, cur_l_reduce, axis=1)

            T.TileOp.mul(workspace_ub_l, workspace_ub_l, workspace_ub_expmax)
            T.TileOp.add(workspace_ub_l, workspace_ub_l, cur_l)

        else:
            T.TileOp.sub(s_tile_ub, s_tile_ub, cur_m)
            T.TileOp.exp(s_tile_ub, s_tile_ub)

            cur_l_reduce = Tensor(shape=[t_s1v, 1], dtype=V_TYPE, mem_loc=MemLoc.UB)
            T.TileOp.reduce_sum(cur_l_reduce, s_tile_ub, axis=1)
            T.TileOp.broadcast(workspace_ub_l, cur_l_reduce, axis=1)

        T.TileOp.copy(p_tile, s_tile_ub)


    # PV乘 [s1,s2] * [s2, D2]
    with T.Task(range=[s1_tiles_c, s2_tiles_c]) as ([i, j]):
        p_tile = workspace_p.view([t_s1c, t_s2c])

        p_tile_l1 = Tensor(shape=[t_s1c, t_s2c], dtype=C_TYPE, mem_loc=MemLoc.L1)
        v_tile_l1 = Tensor(shape=[t_s2c, D2], dtype=C_TYPE, mem_loc=MemLoc.L1)
        o_tile_l0c = Tensor(shape=[t_s1c, D2], dtype=V_TYPE, mem_loc=MemLoc.L0C)

        T.TileOp.copy(p_tile_l1, p_tile)
        T.TileOp.copy(v_tile_l1, v[i * t_s2c: T.min((i + 1) * t_s1c, S2), :])
        T.TileOp.gemm(o_tile_l0c, p_tile_l1, v_tile_l1)

        T.TileOp.copy(workspace_o, o_tile_l0c)

    # update
    s2_tiles_update = T.ceil(S2/t_s2_trans)
    with T.Task(range=[s1_tiles_v, s2_tiles_update]) as ([i, j]):
        cur_o = Tensor(shape=[t_s1v, D2], dtype=V_TYPE, mem_loc=MemLoc.UB)
        T.TileOp.copy(cur_o, workspace_o[0:t_s1v,:])

        # 每行除第一个tile块外，更新output
        if j > 0:
            T.TileOp.mul(workspace_ub_o, workspace_ub_o, workspace_ub_expmax)
            T.TileOp.add(workspace_ub_o, cur_o, workspace_ub_o)

            # 每行最后一个tile块，除以分母
            if j == s2_tiles_v - 1:
                # o = o / l （向量 / 标量）
                T.TileOp.div(workspace_ub_o, workspace_ub_o, workspace_ub_l)
                T.TileOp.copy(o[i * t_s1v : T.min((i + 1) * t_s1v, S1),:], workspace_ub_o)


class EngFlashAttention(EngineeringOperator):

    @property
    def operator_dsl(self):
        return flash_attention

    @property
    def optim_type(self) -> OptimType:
        return OptimType.GENERAL_BY_SEQ_OPTIM


    def _input_check(self):
        input_shapes = self.op_input.input_shapes
        output_shapes = self.op_input.output_shapes

        if len(input_shapes) != 3:
            raise ValueError(f"[TheoOp.{EngFlashAttention.op_name}]: inputs len must be 3")
        if len(output_shapes) != 1:
            raise ValueError(f"[TheoOp.{EngFlashAttention.op_name}]: outputs len must be 1")

        # S1轴相等
        if input_shapes[0][0] != output_shapes[0][0]:
            raise ValueError(f"[TheoOp.{EngFlashAttention.op_name}]: S1 must be equal")

        # S2轴相等
        if input_shapes[1][1] != input_shapes[2][0]:
            raise ValueError(f"[TheoOp.{EngFlashAttention.op_name}]: S2 must be equal")

    def _dynamic_shape_assign(self) -> dict[str, Any]:
        input_shapes = self.op_input.input_shapes
        input_dtypes = self.op_input.input_dtypes
        # Q
        b, s1, d1 = input_shapes[0]

        # K
        d1, s2 = input_shapes[1][-2:]

        # V
        d2 = input_shapes[2][1]
        # NEXT shape对齐

        matmul_type = input_dtypes[0]
        vec_type = DType.FP32

        dynamic_shape = {
            "S1": s1 * b,
            "S2": s2,
            "D1": d1,
            "D2": d2,
            "d_type": matmul_type,
            "vec_d_type": vec_type,
            "mem_loc": MemLoc.GM
        }

        return dynamic_shape