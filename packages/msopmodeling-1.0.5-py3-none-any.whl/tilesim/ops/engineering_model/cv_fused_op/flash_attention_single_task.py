# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from typing import Any

from core.common import MemLoc, DType, OpType, BackendType
from core.common import op_registry
from core.common.backend_config import OptimType, OptimConfig, TaskIndexConfig
from core.common.entity import CoreUnit
from core.frontend.dsl.grammar.kernel import T
from core.frontend.dsl.grammar.tensor import Tensor
from core.pipeline.tilesim_eng.eng_operator import EngineeringOperator

B, S1, S2, N, D1, D2, C_TYPE, V_TYPE = T.define_symbol(8)


def flash_attention(
        q: Tensor(shape=[S1, D1], dtype=C_TYPE, mem_loc=MemLoc.GM),
        k: Tensor(shape=[D1, S2], dtype=C_TYPE, mem_loc=MemLoc.GM),
        v: Tensor(shape=[S2, D2], dtype=C_TYPE, mem_loc=MemLoc.GM),
        o: Tensor(shape=[S1, D2], dtype=C_TYPE, mem_loc=MemLoc.GM),

        # C/V的S1切块大小： s1c = (AIC_CNT/AIV_CNT) * s1v
        t_s1c=None,
        t_s1v=None,
        # D轴切分大小
        t_d1=None,
        t_d2=None,
        t_dv=None,

        # C/V的S2切块大小
        t_s2c=None,
        t_s2v=None,

        # C/V间数据同步的大小。 matmul计算 n_s2 个tile块，一次性同步给AIV进行计算
        n_s2=None,

):
    t_s2_trans = n_s2 * t_s2c
    d_tiles1 = T.ceil(D1 / t_d1)
    d_tiles2 = T.ceil(D2 / t_d2)
    d_tilesv = T.ceil(D2 / t_dv)

    s1_tiles_cnt = T.ceil(S1 / t_s1c)
    s2_tiles_cnt = T.ceil(S2 / t_s2_trans)

    with T.Task(name="single_s1_task", range=[s1_tiles_cnt]) as ([i]):
        # offset
        s1_start_idx = i * t_s1c
        s1_end_idx = T.min((i + 1) * t_s1c, S1)
        s1_size = s1_end_idx - s1_start_idx
        s1_end_idx_v = T.min(i * t_s1c + t_s1v, S1)
        s1_size_v = s1_end_idx_v - s1_start_idx

        # 中间变量分配
        workspace_s = Tensor(shape=[s1_size, t_s2_trans], dtype=V_TYPE, mem_loc=MemLoc.GM)
        workspace_p = Tensor(shape=[s1_size, t_s2_trans], dtype=C_TYPE, mem_loc=MemLoc.GM)
        workspace_o = Tensor(shape=[s1_size, D2], dtype=V_TYPE, mem_loc=MemLoc.GM)

        # 常驻UB内存分配
        workspace_ub_m = Tensor(shape=[s1_size_v, 8], dtype=V_TYPE, mem_loc=MemLoc.UB)
        workspace_ub_expmax = Tensor(shape=[s1_size_v, 8], dtype=V_TYPE, mem_loc=MemLoc.UB)
        workspace_ub_l = Tensor(shape=[s1_size_v, 8], dtype=V_TYPE, mem_loc=MemLoc.UB)
        workspace_ub_o = Tensor(shape=[s1_size_v, D2], dtype=V_TYPE, mem_loc=MemLoc.UB)

        first_tile = True
        for j in range(s2_tiles_cnt):
            s2_large_start_idx = j * t_s2_trans
            s2_large_end_idx = T.min((j + 1) * t_s2_trans, S2)
            s2_large_size = s2_large_end_idx - s2_large_start_idx

            # task tile 定义
            q_tile = q[s1_start_idx: s1_end_idx, :]
            k_tile = k[:, s2_large_start_idx: s2_large_end_idx]
            v_tile = v[s2_large_start_idx: s2_large_end_idx, :]

            #######################################
            ##              QK乘                 ##
            #######################################
            for s2c_idx in range(n_s2):
                s2_start_idx = s2c_idx * t_s2c
                s2_end_idx = T.min((s2c_idx + 1) * t_s2c, s2_large_size)
                s2_size = s2_end_idx - s2_start_idx

                s_tile_l0c = Tensor(shape=[s1_size, s2_size], dtype=V_TYPE, mem_loc=MemLoc.L0C)
                for d_idx in range(d_tiles1):
                    d_start_idx = d_idx * t_d1
                    d_end_idx = T.min((d_idx + 1) * t_d1, D1)
                    d_size = d_end_idx - d_start_idx

                    q_tile_l1 = Tensor(shape=[s1_size, d_size], dtype=C_TYPE, mem_loc=MemLoc.L1)
                    T.TileOp.copy(q_tile_l1, q_tile[:, d_start_idx: d_end_idx])

                    k_tile_l1 = Tensor(shape=[d_size, s2_size], dtype=C_TYPE, mem_loc=MemLoc.L1)
                    T.TileOp.copy(k_tile_l1, k_tile[d_start_idx: d_end_idx, s2_start_idx: s2_end_idx])

                    T.TileOp.gemm(s_tile_l0c, q_tile_l1, k_tile_l1)
                T.TileOp.copy(workspace_s[:, s2_start_idx: s2_end_idx], s_tile_l0c)
                T.TileOp.set_flag(config={"flag_id": T.str_con('f1_',s2c_idx),"src_unit": CoreUnit.AIC_FIXPIPE,
                                          'dst_unit': CoreUnit.AIC_FIXPIPE})

            #######################################
            ##             softmax               ##
            #######################################
            v_s2_cnt = T.ceil(s2_large_size / t_s2v)
            for s2v_idx in range(v_s2_cnt):
                T.TileOp.wait_flag(config={"flag_id": T.str_con('f1_',s2v_idx), "src_unit": CoreUnit.AIC_FIXPIPE,
                                           'dst_unit': CoreUnit.AIV_MTE2})
                # s2 offset calculation
                s2_start_idx = s2v_idx * t_s2v
                s2_end_idx = T.min((s2v_idx + 1) * t_s2v, s2_large_size)
                s2_size = s2_end_idx - s2_start_idx

                # copy in
                s_tile_ub = Tensor(shape=[s1_size_v, s2_size], dtype=V_TYPE, mem_loc=MemLoc.UB)
                T.TileOp.copy(s_tile_ub, workspace_s[0:s1_size_v, s2_start_idx: s2_end_idx])

                # row max
                row_max = Tensor(shape=[s1_size_v, 1], dtype=V_TYPE, mem_loc=MemLoc.UB)
                cur_m = Tensor(shape=[s1_size_v, 8], dtype=V_TYPE, mem_loc=MemLoc.UB)
                T.TileOp.reduce_max(row_max, s_tile_ub, axis=1)
                T.TileOp.broadcast(cur_m, row_max, axis=1)

                # 除去每行第一个块之外都需要更新
                if not first_tile:
                    T.TileOp.max(cur_m, cur_m, workspace_ub_m)
                    T.TileOp.sub(workspace_ub_expmax, cur_m, workspace_ub_m)

                    T.TileOp.exp(workspace_ub_expmax, workspace_ub_expmax)

                    T.TileOp.sub(s_tile_ub, s_tile_ub, cur_m)
                    T.TileOp.exp(s_tile_ub, s_tile_ub)

                    cur_l_reduce = Tensor(shape=[s1_size_v, 1], dtype=V_TYPE, mem_loc=MemLoc.UB)
                    cur_l = Tensor(shape=[s1_size_v, s2_size], dtype=V_TYPE, mem_loc=MemLoc.UB)
                    T.TileOp.reduce_sum(cur_l_reduce, s_tile_ub, axis=1)
                    T.TileOp.broadcast(cur_l, cur_l_reduce, axis=1)

                    T.TileOp.mul(workspace_ub_l, workspace_ub_l, workspace_ub_expmax)
                    T.TileOp.add(workspace_ub_l, workspace_ub_l, cur_l)

                else:
                    T.TileOp.sub(s_tile_ub, s_tile_ub, cur_m)
                    T.TileOp.exp(s_tile_ub, s_tile_ub)

                    cur_l_reduce = Tensor(shape=[s1_size_v, 1], dtype=V_TYPE, mem_loc=MemLoc.UB)
                    T.TileOp.reduce_sum(cur_l_reduce, s_tile_ub, axis=1)
                    T.TileOp.broadcast(workspace_ub_l, cur_l_reduce, axis=1)
                    first_tile = False

                p_tile_ub = Tensor(shape=[s1_size_v, s2_size], dtype=C_TYPE, mem_loc=MemLoc.UB)
                T.TileOp.cast(p_tile_ub, s_tile_ub)
                T.TileOp.copy(workspace_p[0:s1_size_v, s2_start_idx: s2_end_idx], p_tile_ub)

            #######################################
            ##              PV乘                 ##
            #######################################
            for d_idx in range(d_tiles2):
                d_start_idx = d_idx * t_d2
                d_end_idx = T.min((d_idx + 1) * t_d2, D2)
                d_size = d_end_idx - d_start_idx

                o_tile_l0c = Tensor(shape=[s1_size, d_size], dtype=V_TYPE, mem_loc=MemLoc.L0C)
                for s2c_idx in range(n_s2):
                    s2_start_idx = s2c_idx * t_s2c
                    s2_end_idx = T.min((s2c_idx + 1) * t_s2c, s2_large_size)
                    s2_size = s2_end_idx - s2_start_idx

                    p_tile_l1 = Tensor(shape=[s1_size, s2_size], dtype=C_TYPE, mem_loc=MemLoc.L1)
                    T.TileOp.copy(p_tile_l1, workspace_p[:, s2_start_idx: s2_end_idx])

                    v_tile_l1 = Tensor(shape=[s2_size, d_size], dtype=C_TYPE, mem_loc=MemLoc.L1)
                    T.TileOp.copy(v_tile_l1, v_tile[s2_start_idx: s2_end_idx, d_start_idx: d_end_idx])

                    T.TileOp.gemm(o_tile_l0c, p_tile_l1, v_tile_l1)
                T.TileOp.copy(workspace_o[:, d_start_idx: d_end_idx], o_tile_l0c)

            #######################################
            ##             update                ##
            #######################################
            for d_idx in range(d_tilesv):
                d_start_idx = d_idx * t_dv
                d_end_idx = T.min((d_idx + 1) * t_dv, D2)
                d_size = d_end_idx - d_start_idx

                o_tile_ub = Tensor(shape=[s1_size_v, d_size], dtype=V_TYPE, mem_loc=MemLoc.UB)
                T.TileOp.copy(o_tile_ub, workspace_o[0:s1_size_v, d_start_idx: d_end_idx])

                if j > 0:
                    o_tile_ub_last = workspace_ub_o[:, d_start_idx: d_end_idx]
                    T.TileOp.mul(o_tile_ub_last, o_tile_ub_last, workspace_ub_expmax)
                    T.TileOp.add(o_tile_ub_last, o_tile_ub, o_tile_ub_last)

                    if j == s2_tiles_cnt - 1:
                        T.TileOp.div(o_tile_ub_last, o_tile_ub_last, workspace_ub_l)
                        T.TileOp.copy(o[s1_start_idx:s1_end_idx_v, :], o_tile_ub_last)


@op_registry.register(OpType.FlashAttention, BackendType.ENG)
class EngFlashAttention(EngineeringOperator):

    @property
    def operator_dsl(self):
        return flash_attention

    @property
    def optim_type(self) -> OptimType:
        return OptimType.GENERAL_BY_SEQ_OPTIM

    def _input_check(self):
        """
        input shape = [B, S1, N1, D1] [B, S2, N2, D1] [B, S2, N2, D2]
        output shape = [B, S1, N1, D2]
        """
        if self.op_input.input_dict:
            required_dynamic_shape = {'b', 'n', 's1', 's2', 'd1', 'd2', 'dtype'}
            for key in required_dynamic_shape:
                if key not in self.op_input.input_dict:
                    raise ValueError(f"[EngOp.{EngFlashAttention.op_name}]: input_dict must have key {key}")

    def _set_optim_config(self) -> OptimConfig:
        task_index_configs = {
            "single_s1_task":[
                TaskIndexConfig(
                    index_name="i",
                    seq_num=0,
                    split_core_stride=1,
                    enable_swizzle=False
                )
            ]
        }

        optim_config = OptimConfig(
            optim_method=self.optim_type,
            tuning_candidates=self.op_input.param.tuning_candidates,
            task_index_config=task_index_configs
        )
        return optim_config

    def _dynamic_shape_assign(self) -> dict[str, Any]:
        input_dict = self.op_input.input_dict
        if input_dict:
            b = input_dict['b']
            n1 = input_dict['n']
            s1 = input_dict['s1']
            s2 = input_dict['s2']
            d1 = input_dict['d1']
            d2 = input_dict['d2']
            c_type = DType.from_str(input_dict['dtype'])
        else:
            input_shapes = self.op_input.input_shapes
            input_dtypes = self.op_input.input_dtypes
            # Q
            b, s1, n1, d1 = input_shapes[0]

            # K
            _, s2, _, _ = input_shapes[1]

            # V
            d2 = input_shapes[2][-1]

            c_type = input_dtypes[0]
        v_type = DType.FP32 if c_type == DType.FP16 else DType.FP16

        dynamic_shape = {
            "S1": s1 * b * n1,
            "S2": s2,
            "D1": d1,
            "D2": d2,
            "C_TYPE": c_type,
            "V_TYPE": v_type,
        }

        return dynamic_shape
