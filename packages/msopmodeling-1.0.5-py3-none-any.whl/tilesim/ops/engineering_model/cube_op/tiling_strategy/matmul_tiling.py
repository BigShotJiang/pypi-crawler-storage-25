# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

import os
from typing import Dict, Any, Tuple

from core.common.entity import DType


class MatMulTilingPredictor:
    """
    MatMul tiling策略预测器

    按照 AscendC 的默认tiling策略，根据输入参数预测合适的tiling配置。当前只支持910B和310P芯片
    策略说明见docs/tiling_config/matmul_tiling_910B_310P.md
    策略优先级从高到低：
    1. BL1FullloadWithFixpipeTiling
    2. AL1FullLoadTiling
    3. BL1FullLoadTiling
    4. L2CacheTiling
    5. SingleCoreSplitKTiling
    6. DeterministicMultiCoreSplitKTiling
    7. L2CacheTiling310P
    """

    # 各种策略的默认tiling配置
    DEFAULT_TILINGS = {
        # BL1FullloadWithFixpipeTiling
        "bl1_fullload_fixpipe": {
            "tm": 128,  # baseM = 向下对齐到128
            "tn": 16,  # baseN = N对齐到16
            "tk1": 16,  # baseK = 向下对齐到16
            "tk0": 16
        },
        # AL1FullLoadTiling
        "al1_fullload": {
            "tm": 16,  # baseM = 16
            "tn": 16,  # baseN = 16
            "tk1": 256,  # baseK = 256
            "tk0": 64
        },
        # BL1FullLoadTiling
        "bl1_fullload": {
            "tm": 128,
            "tn": 256,
            "tk1": 256,
            "tk0": 64
        },
        # L2CacheTiling
        "l2_cache": {
            "tm": 128,
            "tn": 256,
            "tk1": 256,
            "tk0": 64
        },
        # SingleCoreSplitKTiling
        "single_core_split_k": {
            "tm": 128,
            "tn": 256,
            "tk1": 256,
            "tk0": 64
        },
        # DeterministicMultiCoreSplitKTiling
        "deterministic_split_k": {
            "tm": 128,
            "tn": 256,
            "tk1": 256,
            "tk0": 64
        },
        # L2CacheTiling310P
        "l2_cache_310p": {
            "tm": 128,
            "tn": 256,
            "tk1": 256,
            "tk0": 64
        },
    }

    def __init__(self, chip: str = "910B1"):
        """
        初始化tiling预测器

        Args:
            chip: 芯片型号，默认910B1
        """
        if os.path.exists(chip):  # 如果是路径
            basename = os.path.basename(chip)
            chip = os.path.splitext(basename)[0]
        if chip not in ['910B1', '910B2', '910B3', '910B4', '910B4-1', '310P']:
            raise ValueError(f"不支持的芯片类型：{chip}")
        self.chip = chip
        if chip == '310P':
            self.support_l0c2out = False
            self.support_l12btbf16 = False
            self.aic_core_num = 16
        else:
            self.support_l0c2out = True
            self.support_l12btbf16 = True
            if chip in ['910B1', '910B2']:
                self.aic_core_num = 24
            else:
                self.aic_core_num = 20

    def _get_dtype_size(self, dtype: DType) -> int:
        """获取数据类型大小"""
        return dtype.size

    def _is_aligned(self, value: int, align: int) -> bool:
        """检查是否对齐"""
        return value % align == 0

    def _align_down(self, value: int, align: int) -> int:
        """向下对齐"""
        return (value // align) * align

    def _align_up(self, value: int, align: int) -> int:
        """向上对齐"""
        return ((value + align - 1) // align) * align

    def _check_bl1_fullload_fixpipe(self, m: int, n: int, k: int, dtype: DType) -> bool:
        """
        检查是否触发 BL1FullloadWithFixpipeTiling 策略

        触发条件:
        - 芯片支持L0C2out
        - N < 256 且 N 不对齐
        - K <= 256
        - N % (256/dtypeSize) != 0
        - 256/dtypeSize % N != 0 (Fixpipe Bound场景)
        """
        if not self.support_l0c2out:
            return False

        dtype_size = self._get_dtype_size(dtype)
        tile_256 = 256 / dtype_size

        if n < 256 and k <= 256:
            if n % tile_256 != 0:
                if tile_256 % n != 0:
                    return True

        return False

    def _check_al1_fullload(self, m: int, n: int, k: int, dtype: DType, a_trans: bool, b_trans: bool) -> bool:
        """
        检查是否触发 AL1FullLoadTiling 策略

        触发条件:
        - 芯片支持L0C2out
        - 数据类型为FP32
        - !isATrans && isBTrans
        - M <= 16 && N > 16 && N <= 16*aicNum
        - K >= 4096
        - K对齐到512/dtypeSize
        - AL1大小不超过L1容量限制
        """
        if not self.support_l0c2out:
            return False

        if dtype != DType.FP32:
            return False

        if a_trans or not b_trans:
            return False

        if m > 16 or n <= 16 or n > 16 * self.aic_core_num:
            return False

        if k < 4096:
            return False

        dtype_size = self._get_dtype_size(dtype)
        if not self._is_aligned(k, 512 / dtype_size):
            return False

        # AL1 大小检查 (简化版)
        al1_size = m * k * dtype_size
        if al1_size > 1024 * 1024:  # 1MB作为L1容量限制
            return False

        return True

    def _check_bl1_fullload(self, m: int, n: int, k: int, dtype: DType, a_trans: bool, b_trans: bool) -> bool:
        """
        检查是否触发 BL1FullLoadTiling 策略

        触发条件:
        - 子策略1 (V2 Tiling):
            - FP32类型, isATrans && !isBTrans
            - M范围: [30848, 98048]
            - N = 512, K = 512
            - A、B均为ND格式, 无Bias
        - 子策略2: 其他BL1全载场景
        """
        if not self.support_l0c2out:
            return False

        # V2 Tiling策略
        if dtype == DType.FP32 and a_trans and not b_trans:
            if 30848 <= m <= 98048 and n == 512 and k == 512:
                return True

        # 其他BL1全载场景 (简化判断: 小K场景)
        if k <= 512:
            return True

        return False

    def _check_l2_cache(self, m: int, n: int, k: int, dtype: DType) -> bool:
        """
        检查是否触发 L2CacheTiling 策略

        触发条件:
        - 芯片支持L0C2out
        - 总数据量 > L2Ratio * 100MB (避免L2数据置换)
        """
        if not self.support_l0c2out:
            return False

        dtype_size = self._get_dtype_size(dtype)
        total_bytes = (m * k + k * n + m * n) * dtype_size

        # L2Ratio 默认取 0.8
        l2_threshold = 0.8 * 100 * 1024 * 1024  # 80MB

        return total_bytes > l2_threshold

    def _check_single_core_split_k(self, m: int, n: int, k: int, dtype: DType) -> bool:
        """
        检查是否触发 SingleCoreSplitKTiling 策略

        触发条件:
        - 芯片支持L0C2out
        - 不支持L12BtBf16
        - K >= 27392 (SPLIT_K_THRES)
        - 或者满足特殊通道条件: K=1536时的MKN/NKM通道
        """
        if not self.support_l0c2out:
            return False

        if self.support_l12btbf16:
            return False

        split_k_thres = 27392
        if k >= split_k_thres:
            return True

        # 特殊通道条件 (简化处理)
        if k == 1536:
            return True

        return False

    def _check_deterministic_split_k(self, m: int, n: int, k: int, dtype: DType) -> bool:
        """
        检查是否触发 DeterministicMultiCoreSplitKTiling 策略

        触发条件:
        - 不支持L12BtBf16
        - K >= 1000且K <= 4608时的特定场景
        - 或 K >= 27392 的MTE2 Bound场景
        - 或 M,N <= 64且K >= 6144的MN64场景
        """
        if self.support_l12btbf16:
            return False

        # K >= 1000且K <= 4608
        if 1000 <= k <= 4608:
            return True

        # K >= 27392 的MTE2 Bound场景
        if k >= 27392:
            return True

        # M,N <= 64且K >= 6144的MN64场景
        if m <= 64 and n <= 64 and k >= 6144:
            return True

        return False

    def _check_l2_cache_310p(self, m: int, n: int, k: int, dtype: DType) -> bool:
        """
        检查是否触发 L2CacheTiling310P 策略

        触发条件:
        - 芯片不支持L12BtBf16和L0C2out (310P芯片)
        - 固定(4,2)或(5,2)的分块模式
        """
        if self.support_l0c2out:
            return False

        if self.support_l12btbf16:
            return False

        return True

    def predict_tiling(self, m: int, n: int, k: int, dtype: DType,
                       a_trans: bool = False, b_trans: bool = False) -> Tuple[str, Dict[str, Any]]:
        """
        预测MatMul的tiling策略和配置

        Args:
            m: M维度大小
            n: N维度大小
            k: K维度大小
            dtype: 数据类型
            a_trans: A矩阵是否转置
            b_trans: B矩阵是否转置

        Returns:
            (策略名称, tiling配置字典)
        """
        # 按优先级检查各策略
        if self._check_bl1_fullload_fixpipe(m, n, k, dtype):
            tiling = self.DEFAULT_TILINGS["bl1_fullload_fixpipe"].copy()
            # BL1FullloadWithFixpipeTiling需要根据实际N调整tn
            tiling["tn"] = self._align_up(n, 16)
            if tiling["tn"] > n:
                tiling["tn"] = self._align_down(n, 16)
            if tiling["tn"] == 0:
                tiling["tn"] = 16
            return "BL1FullloadWithFixpipeTiling", tiling

        if self._check_al1_fullload(m, n, k, dtype, a_trans, b_trans):
            tiling = self.DEFAULT_TILINGS["al1_fullload"].copy()
            return "AL1FullLoadTiling", tiling

        if self._check_bl1_fullload(m, n, k, dtype, a_trans, b_trans):
            tiling = self.DEFAULT_TILINGS["bl1_fullload"].copy()
            return "BL1FullLoadTiling", tiling

        if self._check_l2_cache(m, n, k, dtype):
            tiling = self.DEFAULT_TILINGS["l2_cache"].copy()
            # L2CacheTiling可能需要根据核数调整
            return "L2CacheTiling", tiling

        if self._check_single_core_split_k(m, n, k, dtype):
            tiling = self.DEFAULT_TILINGS["single_core_split_k"].copy()
            return "SingleCoreSplitKTiling", tiling

        if self._check_deterministic_split_k(m, n, k, dtype):
            tiling = self.DEFAULT_TILINGS["deterministic_split_k"].copy()
            return "DeterministicMultiCoreSplitKTiling", tiling

        if self._check_l2_cache_310p(m, n, k, dtype):
            tiling = self.DEFAULT_TILINGS["l2_cache_310p"].copy()
            return "L2CacheTiling310P", tiling

        # 默认策略
        tiling = self.DEFAULT_TILINGS["l2_cache"].copy()
        return "DefaultTiling", tiling