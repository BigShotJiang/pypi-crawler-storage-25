# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
"""
HIVM工程模型

直接将HIVM MLIR解析为KernelIR并执行工程仿真。
"""
import pathlib
from abc import ABC
from enum import Enum
from typing import Any, final

from core.common import OpType, BackendType, op_registry
from core.common.backend_config import BackendConfig, OptimConfig, OptimType, FitParamKey
from core.frontend.adaptor.hivm.hivm_utils import HIVMExtraParam
from core.pipeline.basic_operator import BasicOperator
from core.pipeline.hivm.hivm_to_eng_sim import hivm_to_eng_sim


class HIVMModelLevel(Enum):
    """HIVM模型层级"""
    # 极限模型：不考虑同步开销
    level1 = (1, {
        'enable_small_package': False,
        'enable_pipe_barrier': False,
        'enable_pipe_babble': False
    })
    # 工程模型：考虑同步开销
    level2 = (2, {
        'enable_small_package': True,
        'enable_pipe_barrier': True,
        'enable_pipe_babble': True
    })

    def __init__(self, level, config):
        self.level = level
        self.config = config

    @staticmethod
    def from_level(level: int):
        for m in HIVMModelLevel:
            if m.level == level:
                return m
        raise ValueError(f"invalid level: {level}")


@op_registry.register(OpType.HIVM, BackendType.ENG)
class EngHivm(BasicOperator, ABC):
    """
    HIVM工程模型

    直接处理HIVM MLIR格式，将其解析为KernelIR并执行工程仿真。
    """
    extra_param_class = HIVMExtraParam

    @property
    def operator_dsl(self):
        return None

    @property
    def extra_param_format(self):
        return HIVMExtraParam

    def _input_check(self):
        """输入校验"""
        pass

    @property
    @final
    def backend_type(self):
        return BackendType.ENG

    @property
    @final
    def optim_type(self) -> OptimType:
        return OptimType.ADAPTOR_BYPASS_OPTIM

    def _set_optim_config(self) -> OptimConfig:
        return OptimConfig(OptimType.ADAPTOR_BYPASS_OPTIM)

    @property
    def eval_type(self):
        pass

    def _adjust_coeff(self, backend_config: BackendConfig):
        """调整拟合系数"""
        enable_fit = self.op_input.param is not None and self.op_input.param.enable_fit
        if not enable_fit:
            return
        fit_param_input = self.op_input.param.fit_param
        if not fit_param_input:
            return
        fit_param = backend_config.eval_config.fit_param

        if FitParamKey.BW_COEFF not in fit_param:
            fit_param[FitParamKey.BW_COEFF] = fit_param_input.get('bw_coeff', 1)

        if FitParamKey.COMP_COEFF not in fit_param:
            fit_param[FitParamKey.COMP_COEFF] = fit_param_input.get('comp_coeff', 1)

        if FitParamKey.SCALAR_TIME not in fit_param:
            fit_param[FitParamKey.SCALAR_TIME] = fit_param_input.get('scalar_time', 0)

    def _dynamic_shape_assign(self) -> dict[str, Any]:
        """动态形状赋值"""
        return self.op_input.input_dict

    def run(self):
        """执行仿真"""
        param: HIVMExtraParam = self.op_input.param
        path = pathlib.Path(param.hivm_path)
        if not path.exists():
            raise ValueError(f"hivm path {path} does not exist")
        with open(path, "r", encoding="utf-8") as f:
            mlir = f.read()

        # 输入校验
        self._input_check()

        # 动态形状生成
        dynamic_shape_dict = self._dynamic_shape_assign()

        # 获取模型层级
        config = HIVMModelLevel.from_level(param.model_level)

        # 设置配置
        optim_config = self._set_optim_config()
        eval_config = self._set_eval_config()
        backend_config = BackendConfig(
            accelerator=self.op_input.accelerator,
            aic_core_num=self.op_input.aic_core_num,
            aiv_core_num=self.op_input.aiv_core_num,
            layout_format=self.op_input.layout_format,
            eval_config=eval_config,
            optim_config=optim_config
        )

        enable_fit = self.op_input.param is not None and self.op_input.param.enable_fit
        if enable_fit:
            self._adjust_coeff(backend_config)
        eval_config.set_default_fit_param()

        # 调用HIVM pipeline
        res = hivm_to_eng_sim(
            mlir=mlir,
            dynamic_shape=dynamic_shape_dict,
            backend_config=backend_config,
            param=param
        )

        if enable_fit:
            res = self._post_fit(backend_config, res)

        return res