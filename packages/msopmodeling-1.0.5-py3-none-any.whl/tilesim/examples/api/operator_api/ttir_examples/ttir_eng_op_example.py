# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import json
import os

from api.operator_api.op_latency_predict import op_latency_predict, save_optimization_hints_csv


def main():
    example_input_path = './input_example_engineering_ttir.json'
    example_output_path = './output_example_engineering_ttir.json'

    with open(example_input_path, "r", encoding="utf-8") as f:
        op_input_example = json.load(f)

    op_output_dict = {}
    for op_input_data in op_input_example:
        result, optimization_hints = op_latency_predict(op_input_data)
        ttir_path = op_input_data.get('extra_param').get('ttir_path')
        basename = os.path.basename(ttir_path)
        op_name = os.path.splitext(basename)[0]
        op_id = f'{len(op_output_dict)}_{op_name}'
        op_output_dict[op_id] = result
        if optimization_hints:
            hints_csv_path = f'optimization_hints_{op_id}.csv'
            save_optimization_hints_csv(optimization_hints, hints_csv_path)
    with open(example_output_path, "w", encoding="utf-8") as f:
        op_output_dict = json.dumps(
            op_output_dict, indent=2, ensure_ascii=False
        )
        f.write(op_output_dict)


if __name__ == '__main__':
    main()
