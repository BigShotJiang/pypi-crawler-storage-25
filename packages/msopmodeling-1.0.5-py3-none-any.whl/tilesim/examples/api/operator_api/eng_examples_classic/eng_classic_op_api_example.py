# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import json

from api.operator_api.op_latency_predict_engineering import op_latency_predict


def main():
    example_input_path = 'input_example_engineering_classic.json'
    example_output_path = 'output_example_engineering_classic.json'

    with open(example_input_path, "r", encoding="utf-8") as f:
        op_input_example = json.load(f)

    op_output_dict = {}
    for op_input_data in op_input_example:
        result = op_latency_predict(op_input_data)
        op_output_dict[f'OP_{len(op_output_dict)}'] = result
    with open(example_output_path, "w", encoding="utf-8") as f:
        op_output_dict = json.dumps(
            op_output_dict, indent=2, ensure_ascii=False
        )
        f.write(op_output_dict)


if __name__ == '__main__':
    main()
