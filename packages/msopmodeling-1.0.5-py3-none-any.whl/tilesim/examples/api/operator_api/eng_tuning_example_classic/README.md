# tiling参数与example的含义说明

## 1 tiling参数含义说明

- **m0, n0, k0**：L0 cache内的切块大小；
- **m1, n1, k1a, k1b**：L1 cache内的切块大小；
- **w, h**：分核的宽与高，实际使用的时候只关注w*h；
- **swizzle_offset**：swizzle分核的偏置；
- **swizzle_direction**：swizzle分核的方向；

关于Swizzle的具体含义可参考：https://gitcode.com/cann/catlass/blob/master/docs/contents/advanced/swizzle_explanation.md


## 2 input_example.json含义说明

- **op_name**：算子名称；
- **input_shapes**：算子输入shape；
- **output_shapes**：算子输出shape
- **input_precision**：算子输入数据类型；
- **input_precision**：算子输出数据类型；
- **core_num**：使用核数。对于AIC和AIV算子，填对应的组件核数；对于MIX算子，填AIC核数；
- **tiling_config**：tiling寻优空间，格式为多个tiling策略组成的list，其中tiling策略是由多个tiling阶段组成的list（对于大部分算子只有一个tiling阶段，一些mix算子有多个tiling阶段）。
  - 单个tiling阶段配置含义（最内层list，记为tiling_param）：第1个字符串表示tiling方式，当前支持catlass和swizzle；数字含义如下：
    - **catlass**：m, n, k0, k1, w, swizzle_offset, swizzle_direction = tiling_param[1:8]，h = 1；
    - **swizzle**：m, n, k0, k1, w, h = tiling_param[1:7]，swizzle_offset = 1, swizzle_direction = 0。
    - **和第1节的对应关系**：m0 = m1 = m, n0 = n1 = n, k1a = k1b = k1。
- **accelerator**：使用的微架构配置文件。


## 3 output_example.json含义说明

- **op_name**：算子名称；
- **latency**：预测的算子E2E时延，单位：us；
- **component_latency**：详细组件时延，单位：us；
- **l2_hit_rate**：L2命中率；
- **cube_utilization_rate**：cube计算单元利用率，即cube忙时间除以算子执行总时间；
- **vec_utilization_rate**：vec计算单元利用率，即vec忙时间除以算子执行总时间；
- **mem_volume**：算子执行占用的cache大小，单位：Byte；
- **compute_workload**：计算组件负载，CUBE单位：FLOPs, VEC单位：cycles；
- **gm_volume**：总计分配的GM内存（输入+输出+中间临时变量）；
- **tiling_info**：tiling寻优结果，格式内容不定，对于matmul算子含义如下：
  - **item_name**：tiling副标题；
  - **l0_m, l0_n, l0_k**：即第1节的m0, n0, k0；
  - **l1_m, l1_n, l1_k**：即第1节的m1, n1, k1a，其中k1b = k1a；
  - **ub_m, ub_n**：ub切块的大小；
  - **param**：
    - **swizzle_dir, swizzle_offset**：即第1节的swizzle_offset和swizzle_direction。
- **ideal开头的项**：算子理想执行时间，暂不支持。
