# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
"""
HIVM工程模型示例

演示如何使用HIVM MLIR文件进行工程仿真。
"""
import json
import os
import sys

from api.operator_api.op_latency_predict import op_latency_predict, save_optimization_hints_csv

# 添加项目根目录到路径
project_root = os.path.dirname(
    os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
sys.path.insert(0, project_root)


def _resolve_paths(op_input_data: dict, base_dir: str) -> dict:
    """
    将输入数据中的相对路径转换为绝对路径

    Args:
        op_input_data: 输入数据字典
        base_dir: 基准目录（用于解析相对路径）

    Returns:
        处理后的输入数据字典
    """
    import copy
    op_input_data = copy.deepcopy(op_input_data)

    # 处理 accelerator 路径
    accelerator = op_input_data.get('accelerator')
    if accelerator and not os.path.isabs(accelerator):
        op_input_data['accelerator'] = os.path.normpath(os.path.join(base_dir, accelerator))

    # 处理 extra_param 中的路径
    extra_param = op_input_data.get('extra_param', {})
    if extra_param:
        # 处理 hivm_path
        hivm_path = extra_param.get('hivm_path')
        if hivm_path and not os.path.isabs(hivm_path):
            extra_param['hivm_path'] = os.path.normpath(os.path.join(base_dir, hivm_path))

    return op_input_data


def main():
    # 使用绝对路径
    example_dir = os.path.dirname(os.path.abspath(__file__))
    example_input_path = os.path.join(example_dir, 'input_example_engineering_hivm.json')
    example_output_path = os.path.join(example_dir, 'output_example_engineering_hivm.json')

    with open(example_input_path, "r", encoding="utf-8") as f:
        op_input_example = json.load(f)

    op_output_dict = {}
    for op_input_data in op_input_example:
        # 将相对路径转换为绝对路径
        op_input_data = _resolve_paths(op_input_data, example_dir)
        result, optimization_hints = op_latency_predict(op_input_data)
        hivm_path = op_input_data.get('extra_param').get('hivm_path')
        basename = os.path.basename(hivm_path)
        op_name = os.path.splitext(basename)[0]
        op_output_dict[f'{len(op_output_dict)}_{op_name}'] = result

        if optimization_hints:
            hints_csv_path = os.path.join(example_dir, f'optimization_hints_{op_name}.csv')
            save_optimization_hints_csv(optimization_hints, hints_csv_path)

    with open(example_output_path, "w", encoding="utf-8") as f:
        op_output_dict = json.dumps(
            op_output_dict, indent=2, ensure_ascii=False
        )
        f.write(op_output_dict)


if __name__ == '__main__':
    main()
