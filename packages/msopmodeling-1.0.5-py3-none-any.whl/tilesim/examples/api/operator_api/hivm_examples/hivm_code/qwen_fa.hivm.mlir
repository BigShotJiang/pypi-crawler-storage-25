// -----// IR Dump After InjectSync (hivm-inject-sync) //----- //
func.func @_attn_fwd_mix_aic(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8, #hivm.address_space<gm>> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8, #hivm.address_space<gm>> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg4: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg5: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg6: memref<?xf32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 1 : i32}, %arg7: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 1 : i32}, %arg8: i32, %arg9: i32, %arg10: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, func_dyn_memref_args = dense<[false, true, true, true, true, true, true, true, false, false, false]> : vector<11xi1>, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIC>, hivm.part_of_mix, mix_mode = "mix", parallel_mode = "simd"} {
  %c3_i64 = arith.constant 3 : i64
  %c2_i64 = arith.constant 2 : i64
  %c1_i64 = arith.constant 1 : i64
  %c1_i64_0 = arith.constant 1 : i64
  %c0_i64 = arith.constant 0 : i64
  %c-1_i64 = arith.constant -1 : i64
  %c1_i64_1 = arith.constant 1 : i64
  %c0_i64_2 = arith.constant 0 : i64
  %c-1_i64_3 = arith.constant -1 : i64
  %c8192_i64 = arith.constant 8192 : i64
  %c65536_i64 = arith.constant 65536 : i64
  %c28672_i64 = arith.constant 28672 : i64
  %c61440_i64 = arith.constant 61440 : i64
  %c24576_i64 = arith.constant 24576 : i64
  %c53248_i64 = arith.constant 53248 : i64
  %c16384_i64 = arith.constant 16384 : i64
  %c36864_i64 = arith.constant 36864 : i64
  %c0_i64_4 = arith.constant 0 : i64
  %c20_i32 = arith.constant 20 : i32
  %c2048_i32 = arith.constant 2048 : i32
  %c1024_i32 = arith.constant 1024 : i32
  %c131072_i64 = arith.constant 131072 : i64
  %c8388608_i64 = arith.constant 8388608 : i64
  %c64_i32 = arith.constant 64 : i32
  %c16_i32 = arith.constant 16 : i32
  %c0_i32 = arith.constant 0 : i32
  %c32_i32 = arith.constant 32 : i32
  %c128 = arith.constant 128 : index
  %true = arith.constant true
  %c64 = arith.constant 64 : index
  %c32 = arith.constant 32 : index
  hivm.hir.set_ffts_base_addr %arg0
  hivm.hir.set_mask_norm
  %0 = arith.muli %arg8, %arg9 : i32
  %1 = arith.muli %0, %arg10 : i32
  annotation.mark %1 {logical_block_num} : i32
  %2 = hivm.hir.get_block_idx -> i64
  %3 = arith.trunci %2 : i64 to i32
  %4 = arith.muli %arg10, %arg9 : i32
  %5 = arith.divsi %3, %4 : i32
  %6 = arith.remsi %5, %arg8 : i32
  hivm.hir.sync_block_set[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 2
  %7 = arith.index_cast %2 : i64 to index
  %8 = affine.apply affine_map<()[s0] -> (s0 * 45056)>()[%7]
  %view = memref.view %arg2[%8][] : memref<?xi8, #hivm.address_space<gm>> to memref<64x32xf32, #hivm.address_space<gm>>
  %9 = affine.apply affine_map<()[s0] -> (s0 * 45056 + 8192)>()[%7]
  %view_5 = memref.view %arg2[%9][] : memref<?xi8, #hivm.address_space<gm>> to memref<64x32xf16, #hivm.address_space<gm>>
  %10 = affine.apply affine_map<()[s0] -> (s0 * 45056 + 12288)>()[%7]
  %view_6 = memref.view %arg2[%10][] : memref<?xi8, #hivm.address_space<gm>> to memref<64x128xf32, #hivm.address_space<gm>>
  hivm.hir.set_flag[<PIPE_M>, <PIPE_MTE1>, <EVENT_ID0>]
  hivm.hir.set_flag[<PIPE_M>, <PIPE_MTE1>, <EVENT_ID1>]
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID0>]
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID1>]
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID3>]
  hivm.hir.set_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID4>]
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID5>]
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID6>]
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID7>]
  hivm.hir.set_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID1>]
  scf.for %arg11 = %6 to %c2048_i32 step %c20_i32  : i32 {
    %11 = arith.index_cast %arg11 : i32 to index
    %12 = arith.index_cast %6 : i32 to index
    %13 = arith.index_cast %c2048_i32 : i32 to index
    %14 = arith.index_cast %c20_i32 : i32 to index
    %15 = affine.apply affine_map<()[s0, s1, s2] -> (((s0 - s1) floordiv s2) mod 2)>()[%11, %12, %14]
    %16 = arith.index_cast %15 : index to i1
    %c0_i64_7 = arith.constant 0 : i64
    %c1_i64_8 = arith.constant 1 : i64
    %17 = arith.select %16, %c0_i64_7, %c1_i64_8 : i64
    %18 = hivm.hir.pointer_cast(%c0_i64_4, %c36864_i64) : memref<8x4x16x16xf16, #hivm.address_space<cbuf>>
    annotation.mark %18 {hivm.multi_buffer = 2 : i32} : memref<8x4x16x16xf16, #hivm.address_space<cbuf>>
    %19 = arith.divsi %arg11, %c16_i32 : i32
    %20 = arith.remsi %arg11, %c16_i32 : i32
    %21 = arith.divsi %19, %c64_i32 : i32
    %22 = arith.remsi %19, %c64_i32 : i32
    %23 = arith.extsi %21 : i32 to i64
    %24 = arith.muli %23, %c8388608_i64 : i64
    %25 = arith.extsi %22 : i32 to i64
    %26 = arith.muli %25, %c131072_i64 : i64
    %27 = arith.addi %24, %26 : i64
    %28 = arith.index_cast %27 : i64 to index
    %29 = arith.muli %20, %c64_i32 : i32
    %30 = arith.index_cast %29 : i32 to index
    %31 = affine.apply affine_map<()[s0, s1] -> (s0 + s1 * 128)>()[%28, %30]
    %reinterpret_cast = memref.reinterpret_cast %arg3 to offset: [%31], sizes: [64, 128], strides: [128, 1] : memref<?xf16, #hivm.address_space<gm>> to memref<64x128xf16, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
    %cast = memref.cast %18 : memref<8x4x16x16xf16, #hivm.address_space<cbuf>> to memref<?x?x?x?xf16, #hivm.address_space<cbuf>>
    hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, %17]
    hivm.hir.pipe_barrier[<PIPE_MTE2>]
    hivm.hir.nd2nz {dst_continuous} ins(%reinterpret_cast : memref<64x128xf16, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>) outs(%cast : memref<?x?x?x?xf16, #hivm.address_space<cbuf>>)
    hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID0>]
    hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID0>]
    %32:2 = scf.for %arg12 = %c0_i32 to %c1024_i32 step %c32_i32 iter_args(%arg13 = %c0_i32, %arg14 = %c0_i32) -> (i32, i32)  : i32 {
      %33 = arith.index_cast %arg12 : i32 to index
      %34 = arith.index_cast %c0_i32 : i32 to index
      %35 = arith.index_cast %c1024_i32 : i32 to index
      %36 = arith.index_cast %c32_i32 : i32 to index
      %37 = arith.index_cast %arg11 : i32 to index
      %38 = arith.index_cast %6 : i32 to index
      %39 = arith.index_cast %c2048_i32 : i32 to index
      %40 = arith.index_cast %c20_i32 : i32 to index
      %41 = affine.apply affine_map<()[s0, s1, s2, s3, s4, s5, s6] -> (((s0 - s1) floordiv s3 + ((s4 - s5) floordiv s6) * ((-s1 + s2 + s3 - 1) floordiv s3)) mod 2)>()[%33, %34, %35, %36, %37, %38, %40]
      %42 = arith.index_cast %41 : index to i1
      %c6_i64 = arith.constant 6 : i64
      %c7_i64 = arith.constant 7 : i64
      %43 = arith.select %42, %c6_i64, %c7_i64 : i64
      %c4_i64 = arith.constant 4 : i64
      %c5_i64 = arith.constant 5 : i64
      %44 = arith.select %42, %c4_i64, %c5_i64 : i64
      %c2_i64_9 = arith.constant 2 : i64
      %c3_i64_10 = arith.constant 3 : i64
      %45 = arith.select %42, %c2_i64_9, %c3_i64_10 : i64
      %46 = arith.index_cast %arg12 : i32 to index
      %47 = arith.index_cast %c0_i32 : i32 to index
      %48 = arith.index_cast %c1024_i32 : i32 to index
      %49 = arith.index_cast %c32_i32 : i32 to index
      %50 = arith.index_cast %arg11 : i32 to index
      %51 = arith.index_cast %6 : i32 to index
      %52 = arith.index_cast %c2048_i32 : i32 to index
      %53 = arith.index_cast %c20_i32 : i32 to index
      %54 = affine.apply affine_map<()[s0, s1, s2, s3, s4, s5, s6] -> ((s0 - s1) floordiv s3 + ((s4 - s5) floordiv s6) * ((-s1 + s2 + s3 - 1) floordiv s3))>()[%46, %47, %48, %49, %50, %51, %53]
      %55 = arith.index_cast %54 : index to i64
      %56 = arith.index_cast %arg12 : i32 to index
      %57 = arith.index_cast %c0_i32 : i32 to index
      %58 = arith.index_cast %c1024_i32 : i32 to index
      %59 = arith.index_cast %c32_i32 : i32 to index
      %60 = arith.index_cast %arg11 : i32 to index
      %61 = arith.index_cast %6 : i32 to index
      %62 = arith.index_cast %c2048_i32 : i32 to index
      %63 = arith.index_cast %c20_i32 : i32 to index
      %64 = affine.apply affine_map<()[s0, s1, s2, s3, s4, s5, s6] -> ((s0 - s1) floordiv s3 + ((s4 - s5) floordiv s6) * ((-s1 + s2 + s3 - 1) floordiv s3))>()[%56, %57, %58, %59, %60, %61, %63]
      %65 = arith.index_cast %64 : index to i64
      %66 = hivm.hir.pointer_cast(%c28672_i64, %c65536_i64) : memref<8x2x16x16xf16, #hivm.address_space<cbuf>>
      annotation.mark %66 {hivm.multi_buffer = 2 : i32} : memref<8x2x16x16xf16, #hivm.address_space<cbuf>>
      %67 = hivm.hir.pointer_cast(%c24576_i64, %c61440_i64) : memref<2x4x16x16xf16, #hivm.address_space<cbuf>>
      annotation.mark %67 {hivm.multi_buffer = 2 : i32} : memref<2x4x16x16xf16, #hivm.address_space<cbuf>>
      %68 = hivm.hir.pointer_cast(%c16384_i64, %c53248_i64) : memref<8x2x16x16xf16, #hivm.address_space<cbuf>>
      annotation.mark %68 {hivm.multi_buffer = 2 : i32} : memref<8x2x16x16xf16, #hivm.address_space<cbuf>>
      %69 = arith.index_cast %arg14 : i32 to index
      %70 = affine.apply affine_map<()[s0, s1] -> (s0 + s1 * 128)>()[%28, %69]
      %reinterpret_cast_11 = memref.reinterpret_cast %arg4 to offset: [%70], sizes: [32, 128], strides: [128, 1] : memref<?xf16, #hivm.address_space<gm>> to memref<32x128xf16, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
      %71 = arith.index_cast %arg13 : i32 to index
      %72 = affine.apply affine_map<()[s0, s1] -> (s0 + s1 * 128)>()[%28, %71]
      %reinterpret_cast_12 = memref.reinterpret_cast %arg5 to offset: [%72], sizes: [32, 128], strides: [128, 1] : memref<?xf16, #hivm.address_space<gm>> to memref<32x128xf16, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
      %cast_13 = memref.cast %68 : memref<8x2x16x16xf16, #hivm.address_space<cbuf>> to memref<?x?x?x?xf16, #hivm.address_space<cbuf>>
      hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, %45]
      hivm.hir.nd2nz {dst_continuous} ins(%reinterpret_cast_11 : memref<32x128xf16, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>) outs(%cast_13 : memref<?x?x?x?xf16, #hivm.address_space<cbuf>>)
      hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID1>]
      %73 = hivm.hir.pointer_cast(%c0_i64_4) : memref<2x4x16x16xf32, #hivm.address_space<cc>>
      %cast_14 = memref.cast %73 : memref<2x4x16x16xf32, #hivm.address_space<cc>> to memref<?x?x?x?xf32, #hivm.address_space<cc>>
      hivm.hir.wait_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
      hivm.hir.mmadL1 {already_set_real_mkn, b_transpose, fixpipe_already_inserted = true} ins(%cast, %cast_13, %true, %c64, %c128, %c32 : memref<?x?x?x?xf16, #hivm.address_space<cbuf>>, memref<?x?x?x?xf16, #hivm.address_space<cbuf>>, i1, index, index, index) outs(%cast_14 : memref<?x?x?x?xf32, #hivm.address_space<cc>>) sync_related_args(%c-1_i64_3, %c1_i64, %c-1_i64_3, %45, %65, %c0_i64_2, %c1_i64_1 : i64, i64, i64, i64, i64, i64, i64)
      hivm.hir.set_flag[<PIPE_M>, <PIPE_FIX>, <EVENT_ID0>]
      hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 0
      hivm.hir.wait_flag[<PIPE_M>, <PIPE_FIX>, <EVENT_ID0>]
      hivm.hir.fixpipe {dma_mode = #hivm.dma_mode<nz2nd>} ins(%cast_14 : memref<?x?x?x?xf32, #hivm.address_space<cc>>) outs(%view : memref<64x32xf32, #hivm.address_space<gm>>)
      hivm.hir.set_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
      annotation.mark %view : memref<64x32xf32, #hivm.address_space<gm>>
      hivm.hir.sync_block_set[<CUBE>, <PIPE_FIX>, <PIPE_S>] flag = 1
      hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE3>, <PIPE_S>] flag = 1
      %cast_15 = memref.cast %67 : memref<2x4x16x16xf16, #hivm.address_space<cbuf>> to memref<?x?x?x?xf16, #hivm.address_space<cbuf>>
      hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, %44]
      hivm.hir.nd2nz {dst_continuous} ins(%view_5 : memref<64x32xf16, #hivm.address_space<gm>>) outs(%cast_15 : memref<?x?x?x?xf16, #hivm.address_space<cbuf>>)
      hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID3>]
      hivm.hir.sync_block_set[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 2
      %cast_16 = memref.cast %66 : memref<8x2x16x16xf16, #hivm.address_space<cbuf>> to memref<?x?x?x?xf16, #hivm.address_space<cbuf>>
      hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, %43]
      hivm.hir.nd2nz {dst_continuous} ins(%reinterpret_cast_12 : memref<32x128xf16, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>) outs(%cast_16 : memref<?x?x?x?xf16, #hivm.address_space<cbuf>>)
      hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID2>]
      %74 = hivm.hir.pointer_cast(%c8192_i64) : memref<8x4x16x16xf32, #hivm.address_space<cc>>
      %cast_17 = memref.cast %74 : memref<8x4x16x16xf32, #hivm.address_space<cc>> to memref<?x?x?x?xf32, #hivm.address_space<cc>>
      hivm.hir.wait_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID1>]
      hivm.hir.mmadL1 {already_set_real_mkn, fixpipe_already_inserted = true} ins(%cast_15, %cast_16, %true, %c64, %c32, %c128 : memref<?x?x?x?xf16, #hivm.address_space<cbuf>>, memref<?x?x?x?xf16, #hivm.address_space<cbuf>>, i1, index, index, index) outs(%cast_17 : memref<?x?x?x?xf32, #hivm.address_space<cc>>) sync_related_args(%c3_i64, %c2_i64, %44, %43, %55, %c0_i64, %c1_i64_0 : i64, i64, i64, i64, i64, i64, i64)
      hivm.hir.set_flag[<PIPE_M>, <PIPE_FIX>, <EVENT_ID1>]
      hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 3
      hivm.hir.wait_flag[<PIPE_M>, <PIPE_FIX>, <EVENT_ID1>]
      hivm.hir.fixpipe {dma_mode = #hivm.dma_mode<nz2nd>} ins(%cast_17 : memref<?x?x?x?xf32, #hivm.address_space<cc>>) outs(%view_6 : memref<64x128xf32, #hivm.address_space<gm>>)
      hivm.hir.set_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID1>]
      annotation.mark %view_6 : memref<64x128xf32, #hivm.address_space<gm>>
      hivm.hir.sync_block_set[<CUBE>, <PIPE_FIX>, <PIPE_S>] flag = 1
      %75 = arith.addi %arg13, %c32_i32 : i32
      %76 = arith.addi %arg14, %c32_i32 : i32
      scf.yield %75, %76 : i32, i32
    } {tt.divisibility_arg1 = dense<32> : tensor<1xi32>}
    hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, %17]
  }
  hivm.hir.wait_flag[<PIPE_M>, <PIPE_MTE1>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_M>, <PIPE_MTE1>, <EVENT_ID1>]
  hivm.hir.pipe_barrier[<PIPE_ALL>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID1>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID3>]
  hivm.hir.wait_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID4>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID5>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID6>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID7>]
  hivm.hir.wait_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID1>]
  hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 0
  hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 3
  return
}

// -----// IR Dump After InjectSync (hivm-inject-sync) //----- //
func.func @_attn_fwd_mix_aiv(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8, #hivm.address_space<gm>> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8, #hivm.address_space<gm>> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg4: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg5: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg6: memref<?xf32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 1 : i32}, %arg7: memref<?xf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 1 : i32}, %arg8: i32, %arg9: i32, %arg10: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, func_dyn_memref_args = dense<[false, true, true, true, true, true, true, true, false, false, false]> : vector<11xi1>, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.part_of_mix, mix_mode = "mix", parallel_mode = "simd"} {
  %c74624_i64 = arith.constant 74624 : i64
  %c58240_i64 = arith.constant 58240 : i64
  %c58112_i64 = arith.constant 58112 : i64
  %c25216_i64 = arith.constant 25216 : i64
  %c24192_i64 = arith.constant 24192 : i64
  %c7808_i64 = arith.constant 7808 : i64
  %c7552_i64 = arith.constant 7552 : i64
  %c7424_i64 = arith.constant 7424 : i64
  %c7296_i64 = arith.constant 7296 : i64
  %c5248_i64 = arith.constant 5248 : i64
  %c4224_i64 = arith.constant 4224 : i64
  %c4096_i64 = arith.constant 4096 : i64
  %c0_i64 = arith.constant 0 : i64
  %c7680_i64 = arith.constant 7680 : i64
  %c57984_i64 = arith.constant 57984 : i64
  %c41600_i64 = arith.constant 41600 : i64
  %cst = arith.constant 1.000000e+00 : f32
  %cst_0 = arith.constant 0xFF800000 : f32
  %c32_i32 = arith.constant 32 : i32
  %cst_1 = arith.constant 8.838800e-02 : f32
  %c0_i32 = arith.constant 0 : i32
  %c16_i32 = arith.constant 16 : i32
  %c64_i32 = arith.constant 64 : i32
  %c8388608_i64 = arith.constant 8388608 : i64
  %c131072_i64 = arith.constant 131072 : i64
  %c1024_i32 = arith.constant 1024 : i32
  %c2048_i32 = arith.constant 2048 : i32
  %c20_i32 = arith.constant 20 : i32
  %cst_2 = arith.constant 0.000000e+00 : f32
  %0 = arith.muli %arg8, %arg9 : i32
  %1 = arith.muli %0, %arg10 : i32
  %2 = hivm.hir.get_block_idx -> i64
  %3 = arith.trunci %2 : i64 to i32
  %4 = arith.muli %arg10, %arg9 : i32
  %5 = hivm.hir.pointer_cast(%c41600_i64) : memref<32x128xf32, #hivm.address_space<ub>>
  %6 = hivm.hir.pointer_cast(%c57984_i64) : memref<32xf32, #hivm.address_space<ub>>
  %7 = hivm.hir.pointer_cast(%c7680_i64) : memref<32xf32, #hivm.address_space<ub>>
  %8 = arith.index_cast %2 : i64 to index
  %9 = affine.apply affine_map<()[s0] -> (s0 * 45056)>()[%8]
  %view = memref.view %arg2[%9][] : memref<?xi8, #hivm.address_space<gm>> to memref<64x32xf32, #hivm.address_space<gm>>
  %10 = affine.apply affine_map<()[s0] -> (s0 * 45056 + 8192)>()[%8]
  %view_3 = memref.view %arg2[%10][] : memref<?xi8, #hivm.address_space<gm>> to memref<64x32xf16, #hivm.address_space<gm>>
  %11 = affine.apply affine_map<()[s0] -> (s0 * 45056 + 12288)>()[%8]
  %view_4 = memref.view %arg2[%11][] : memref<?xi8, #hivm.address_space<gm>> to memref<64x128xf32, #hivm.address_space<gm>>
  %12 = hivm.hir.get_sub_block_idx -> i64
  %13 = arith.index_cast %12 : i64 to index
  %14 = affine.apply affine_map<()[s0] -> (s0 * 32)>()[%13]
  hivm.hir.set_ffts_base_addr %arg0
  hivm.hir.set_mask_norm
  annotation.mark %1 {logical_block_num} : i32
  %15 = arith.divsi %3, %4 : i32
  %16 = arith.remsi %15, %arg8 : i32
  hivm.hir.sync_block_set[<VECTOR>, <PIPE_MTE2>, <PIPE_S>] flag = 0
  hivm.hir.sync_block_set[<VECTOR>, <PIPE_MTE2>, <PIPE_S>] flag = 3
  hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
  hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID0>]
  hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
  hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID1>]
  hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID2>]
  scf.for %arg11 = %16 to %c2048_i32 step %c20_i32  : i32 {
    %17 = arith.divsi %arg11, %c16_i32 : i32
    %18 = arith.remsi %arg11, %c16_i32 : i32
    %19 = arith.divsi %17, %c64_i32 : i32
    %20 = arith.remsi %17, %c64_i32 : i32
    %21 = arith.extsi %19 : i32 to i64
    %22 = arith.muli %21, %c8388608_i64 : i64
    %23 = arith.extsi %20 : i32 to i64
    %24 = arith.muli %23, %c131072_i64 : i64
    %25 = arith.addi %22, %24 : i64
    %26 = arith.index_cast %25 : i64 to index
    %27 = arith.muli %18, %c64_i32 : i32
    %28 = arith.index_cast %27 : i32 to index
    %29 = affine.apply affine_map<()[s0, s1] -> (s0 + s1 * 128)>()[%26, %28]
    %reinterpret_cast = memref.reinterpret_cast %arg7 to offset: [%29], sizes: [64, 128], strides: [128, 1] : memref<?xf16, #hivm.address_space<gm>> to memref<64x128xf16, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
    hivm.hir.vbrc ins(%cst : f32) outs(%7 : memref<32xf32, #hivm.address_space<ub>>)
    hivm.hir.vbrc ins(%cst_0 : f32) outs(%6 : memref<32xf32, #hivm.address_space<ub>>)
    %collapse_shape = memref.collapse_shape %5 [[0, 1]] : memref<32x128xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
    hivm.hir.vbrc ins(%cst_2 : f32) outs(%collapse_shape : memref<4096xf32, #hivm.address_space<ub>>)
    %30:5 = scf.for %arg12 = %c0_i32 to %c1024_i32 step %c32_i32 iter_args(%arg13 = %7, %arg14 = %5, %arg15 = %6, %arg16 = %c0_i32, %arg17 = %c0_i32) -> (memref<32xf32, #hivm.address_space<ub>>, memref<32x128xf32, #hivm.address_space<ub>>, memref<32xf32, #hivm.address_space<ub>>, i32, i32)  : i32 {
      hivm.hir.sync_block_wait[<VECTOR>, <PIPE_FIX>, <PIPE_S>] flag = 1
      %subview_9 = memref.subview %view[%14, 0] [32, 32] [1, 1] : memref<64x32xf32, #hivm.address_space<gm>> to memref<32x32xf32, strided<[32, 1], offset: ?>, #hivm.address_space<gm>>
      %collapse_shape_10 = memref.collapse_shape %subview_9 [[0, 1]] : memref<32x32xf32, strided<[32, 1], offset: ?>, #hivm.address_space<gm>> into memref<1024xf32, strided<[1], offset: ?>, #hivm.address_space<gm>>
      %39 = hivm.hir.pointer_cast(%c0_i64) : memref<1024xf32, #hivm.address_space<ub>>
      hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
      hivm.hir.load ins(%collapse_shape_10 : memref<1024xf32, strided<[1], offset: ?>, #hivm.address_space<gm>>) outs(%39 : memref<1024xf32, #hivm.address_space<ub>>)
      hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
      hivm.hir.sync_block_set[<VECTOR>, <PIPE_MTE2>, <PIPE_S>] flag = 0
      %40 = hivm.hir.pointer_cast(%c0_i64) : memref<32x32xf32, #hivm.address_space<ub>>
      %collapse_shape_11 = memref.collapse_shape %40 [[0, 1]] : memref<32x32xf32, #hivm.address_space<ub>> into memref<1024xf32, #hivm.address_space<ub>>
      hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
      hivm.hir.vmul ins(%39, %cst_1 : memref<1024xf32, #hivm.address_space<ub>>, f32) outs(%collapse_shape_11 : memref<1024xf32, #hivm.address_space<ub>>)
      %41 = hivm.hir.pointer_cast(%c4096_i64) : memref<32x1xf32, #hivm.address_space<ub>>
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.vreduce <max> ins(%40 : memref<32x32xf32, #hivm.address_space<ub>>) outs(%41 : memref<32x1xf32, #hivm.address_space<ub>>) unsigned_src = false reduce_dims = [1]
      %collapse_shape_12 = memref.collapse_shape %41 [[0, 1]] : memref<32x1xf32, #hivm.address_space<ub>> into memref<32xf32, #hivm.address_space<ub>>
      %42 = hivm.hir.pointer_cast(%c4096_i64) : memref<32xf32, #hivm.address_space<ub>>
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.vmax ins(%arg15, %collapse_shape_12 : memref<32xf32, #hivm.address_space<ub>>, memref<32xf32, #hivm.address_space<ub>>) outs(%42 : memref<32xf32, #hivm.address_space<ub>>)
      %expand_shape_13 = memref.expand_shape %42 [[0, 1]] output_shape [32, 1] : memref<32xf32, #hivm.address_space<ub>> into memref<32x1xf32, #hivm.address_space<ub>>
      %43 = hivm.hir.pointer_cast(%c0_i64) : memref<32x32xf32, #hivm.address_space<ub>>
      %44 = hivm.hir.pointer_cast(%c4224_i64) : memref<256xf32, #hivm.address_space<ub>>
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.vsub ins(%40, %expand_shape_13 : memref<32x32xf32, #hivm.address_space<ub>>, memref<32x1xf32, #hivm.address_space<ub>>) outs(%43 : memref<32x32xf32, #hivm.address_space<ub>>) temp_buffer(%44 : memref<256xf32, #hivm.address_space<ub>>) broadcast = [1]
      %45 = hivm.hir.pointer_cast(%c0_i64) : memref<32x32xf32, #hivm.address_space<ub>>
      %collapse_shape_14 = memref.collapse_shape %43 [[0, 1]] : memref<32x32xf32, #hivm.address_space<ub>> into memref<1024xf32, #hivm.address_space<ub>>
      %collapse_shape_15 = memref.collapse_shape %45 [[0, 1]] : memref<32x32xf32, #hivm.address_space<ub>> into memref<1024xf32, #hivm.address_space<ub>>
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.vexp ins(%collapse_shape_14 : memref<1024xf32, #hivm.address_space<ub>>) outs(%collapse_shape_15 : memref<1024xf32, #hivm.address_space<ub>>)
      %46 = hivm.hir.pointer_cast(%c5248_i64) : memref<1024xf16, #hivm.address_space<ub>>
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID0>]
      hivm.hir.vcast ins(%collapse_shape_15 : memref<1024xf32, #hivm.address_space<ub>>) outs(%46 : memref<1024xf16, #hivm.address_space<ub>>)
      hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE3>, <EVENT_ID0>]
      hivm.hir.sync_block_wait[<VECTOR>, <PIPE_MTE2>, <PIPE_S>] flag = 2
      %subview_16 = memref.subview %view_3[%14, 0] [32, 32] [1, 1] : memref<64x32xf16, #hivm.address_space<gm>> to memref<32x32xf16, strided<[32, 1], offset: ?>, #hivm.address_space<gm>>
      %collapse_shape_17 = memref.collapse_shape %subview_16 [[0, 1]] : memref<32x32xf16, strided<[32, 1], offset: ?>, #hivm.address_space<gm>> into memref<1024xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
      hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE3>, <EVENT_ID0>]
      hivm.hir.store ins(%46 : memref<1024xf16, #hivm.address_space<ub>>) outs(%collapse_shape_17 : memref<1024xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>) {tiled_op}
      hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID0>]
      annotation.mark %subview_16 : memref<32x32xf16, strided<[32, 1], offset: ?>, #hivm.address_space<gm>>
      hivm.hir.sync_block_set[<VECTOR>, <PIPE_MTE3>, <PIPE_S>] flag = 1
      %47 = hivm.hir.pointer_cast(%c7296_i64) : memref<32x1xf32, #hivm.address_space<ub>>
      hivm.hir.vreduce <sum> ins(%45 : memref<32x32xf32, #hivm.address_space<ub>>) outs(%47 : memref<32x1xf32, #hivm.address_space<ub>>) unsigned_src = false reduce_dims = [1]
      hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
      %collapse_shape_18 = memref.collapse_shape %47 [[0, 1]] : memref<32x1xf32, #hivm.address_space<ub>> into memref<32xf32, #hivm.address_space<ub>>
      %48 = hivm.hir.pointer_cast(%c7424_i64) : memref<32xf32, #hivm.address_space<ub>>
      hivm.hir.vsub ins(%arg15, %42 : memref<32xf32, #hivm.address_space<ub>>, memref<32xf32, #hivm.address_space<ub>>) outs(%48 : memref<32xf32, #hivm.address_space<ub>>)
      %49 = hivm.hir.pointer_cast(%c7424_i64) : memref<32xf32, #hivm.address_space<ub>>
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.vexp ins(%48 : memref<32xf32, #hivm.address_space<ub>>) outs(%49 : memref<32xf32, #hivm.address_space<ub>>)
      %50 = hivm.hir.pointer_cast(%c7552_i64) : memref<32xf32, #hivm.address_space<ub>>
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.vmul ins(%arg13, %49 : memref<32xf32, #hivm.address_space<ub>>, memref<32xf32, #hivm.address_space<ub>>) outs(%50 : memref<32xf32, #hivm.address_space<ub>>)
      %51 = hivm.hir.pointer_cast(%c7680_i64) : memref<32xf32, #hivm.address_space<ub>>
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.vadd ins(%50, %collapse_shape_18 : memref<32xf32, #hivm.address_space<ub>>, memref<32xf32, #hivm.address_space<ub>>) outs(%51 : memref<32xf32, #hivm.address_space<ub>>)
      %expand_shape_19 = memref.expand_shape %49 [[0, 1]] output_shape [32, 1] : memref<32xf32, #hivm.address_space<ub>> into memref<32x1xf32, #hivm.address_space<ub>>
      %52 = hivm.hir.pointer_cast(%c7808_i64) : memref<32x128xf32, #hivm.address_space<ub>>
      %53 = hivm.hir.pointer_cast(%c24192_i64) : memref<256xf32, #hivm.address_space<ub>>
      hivm.hir.vmul ins(%arg14, %expand_shape_19 : memref<32x128xf32, #hivm.address_space<ub>>, memref<32x1xf32, #hivm.address_space<ub>>) outs(%52 : memref<32x128xf32, #hivm.address_space<ub>>) temp_buffer(%53 : memref<256xf32, #hivm.address_space<ub>>) broadcast = [1]
      hivm.hir.sync_block_wait[<VECTOR>, <PIPE_FIX>, <PIPE_S>] flag = 1
      %subview_20 = memref.subview %view_4[%14, 0] [32, 128] [1, 1] : memref<64x128xf32, #hivm.address_space<gm>> to memref<32x128xf32, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
      %collapse_shape_21 = memref.collapse_shape %subview_20 [[0, 1]] : memref<32x128xf32, strided<[128, 1], offset: ?>, #hivm.address_space<gm>> into memref<4096xf32, strided<[1], offset: ?>, #hivm.address_space<gm>>
      %54 = hivm.hir.pointer_cast(%c25216_i64) : memref<4096xf32, #hivm.address_space<ub>>
      hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
      hivm.hir.load ins(%collapse_shape_21 : memref<4096xf32, strided<[1], offset: ?>, #hivm.address_space<gm>>) outs(%54 : memref<4096xf32, #hivm.address_space<ub>>)
      hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID1>]
      hivm.hir.sync_block_set[<VECTOR>, <PIPE_MTE2>, <PIPE_S>] flag = 3
      %55 = hivm.hir.pointer_cast(%c41600_i64) : memref<32x128xf32, #hivm.address_space<ub>>
      %collapse_shape_22 = memref.collapse_shape %52 [[0, 1]] : memref<32x128xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
      %collapse_shape_23 = memref.collapse_shape %55 [[0, 1]] : memref<32x128xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
      hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID1>]
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.vadd ins(%54, %collapse_shape_22 : memref<4096xf32, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_23 : memref<4096xf32, #hivm.address_space<ub>>)
      hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
      %56 = arith.addi %arg16, %c32_i32 : i32
      %57 = arith.addi %arg17, %c32_i32 : i32
      %58 = hivm.hir.pointer_cast(%c57984_i64) : memref<32xf32, #hivm.address_space<ub>>
      hivm.hir.copy ins(%42 : memref<32xf32, #hivm.address_space<ub>>) outs(%58 : memref<32xf32, #hivm.address_space<ub>>)
      scf.yield %51, %55, %58, %56, %57 : memref<32xf32, #hivm.address_space<ub>>, memref<32x128xf32, #hivm.address_space<ub>>, memref<32xf32, #hivm.address_space<ub>>, i32, i32
    } {tt.divisibility_arg1 = dense<32> : tensor<1xi32>}
    %31 = hivm.hir.pointer_cast(%c58112_i64) : memref<32xf32, #hivm.address_space<ub>>
    hivm.hir.pipe_barrier[<PIPE_V>]
    hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID1>]
    hivm.hir.vln ins(%30#0 : memref<32xf32, #hivm.address_space<ub>>) outs(%31 : memref<32xf32, #hivm.address_space<ub>>)
    %32 = hivm.hir.pointer_cast(%c58112_i64) : memref<32xf32, #hivm.address_space<ub>>
    hivm.hir.pipe_barrier[<PIPE_V>]
    hivm.hir.vadd ins(%30#2, %31 : memref<32xf32, #hivm.address_space<ub>>, memref<32xf32, #hivm.address_space<ub>>) outs(%32 : memref<32xf32, #hivm.address_space<ub>>)
    hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE3>, <EVENT_ID1>]
    %expand_shape = memref.expand_shape %30#0 [[0, 1]] output_shape [32, 1] : memref<32xf32, #hivm.address_space<ub>> into memref<32x1xf32, #hivm.address_space<ub>>
    %33 = hivm.hir.pointer_cast(%c58240_i64) : memref<32x128xf32, #hivm.address_space<ub>>
    %34 = hivm.hir.pointer_cast(%c74624_i64) : memref<256xf32, #hivm.address_space<ub>>
    hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID2>]
    hivm.hir.vdiv ins(%30#1, %expand_shape : memref<32x128xf32, #hivm.address_space<ub>>, memref<32x1xf32, #hivm.address_space<ub>>) outs(%33 : memref<32x128xf32, #hivm.address_space<ub>>) temp_buffer(%34 : memref<256xf32, #hivm.address_space<ub>>) broadcast = [1]
    %35 = arith.muli %17, %c1024_i32 : i32
    %36 = arith.index_cast %35 : i32 to index
    %37 = affine.apply affine_map<()[s0, s1] -> (s0 + s1)>()[%36, %28]
    %reinterpret_cast_5 = memref.reinterpret_cast %arg6 to offset: [%37], sizes: [64], strides: [1] : memref<?xf32, #hivm.address_space<gm>> to memref<64xf32, strided<[1], offset: ?>, #hivm.address_space<gm>>
    %subview = memref.subview %reinterpret_cast_5[%14] [32] [1] {to_be_bubbled_slice} : memref<64xf32, strided<[1], offset: ?>, #hivm.address_space<gm>> to memref<32xf32, strided<[1], offset: ?>, #hivm.address_space<gm>>
    hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE3>, <EVENT_ID1>]
    hivm.hir.store ins(%32 : memref<32xf32, #hivm.address_space<ub>>) outs(%subview : memref<32xf32, strided<[1], offset: ?>, #hivm.address_space<gm>>) {tiled_op}
    hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID1>]
    %collapse_shape_6 = memref.collapse_shape %33 [[0, 1]] : memref<32x128xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
    %38 = hivm.hir.pointer_cast(%c58240_i64) : memref<4096xf16, #hivm.address_space<ub>>
    hivm.hir.pipe_barrier[<PIPE_V>]
    hivm.hir.vcast ins(%collapse_shape_6 : memref<4096xf32, #hivm.address_space<ub>>) outs(%38 : memref<4096xf16, #hivm.address_space<ub>>)
    hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE3>, <EVENT_ID2>]
    %subview_7 = memref.subview %reinterpret_cast[%14, 0] [32, 128] [1, 1] {to_be_bubbled_slice} : memref<64x128xf16, strided<[128, 1], offset: ?>, #hivm.address_space<gm>> to memref<32x128xf16, strided<[128, 1], offset: ?>, #hivm.address_space<gm>>
    %collapse_shape_8 = memref.collapse_shape %subview_7 [[0, 1]] : memref<32x128xf16, strided<[128, 1], offset: ?>, #hivm.address_space<gm>> into memref<4096xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>
    hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE3>, <EVENT_ID2>]
    hivm.hir.store ins(%38 : memref<4096xf16, #hivm.address_space<ub>>) outs(%collapse_shape_8 : memref<4096xf16, strided<[1], offset: ?>, #hivm.address_space<gm>>) {tiled_op}
    hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID2>]
  }
  hivm.hir.pipe_barrier[<PIPE_ALL>]
  hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
  hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID1>]
  hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID2>]
  hivm.hir.sync_block_wait[<VECTOR>, <PIPE_MTE2>, <PIPE_S>] flag = 2
  return
}

