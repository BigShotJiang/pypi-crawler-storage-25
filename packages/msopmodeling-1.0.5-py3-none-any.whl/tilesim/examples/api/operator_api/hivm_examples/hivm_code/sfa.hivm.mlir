// -----// IR Dump After InjectSync (hivm-inject-sync) //----- //
func.func @sparse_flash_attention_prefill_kernel_mix_aic(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8, #hivm.address_space<gm>> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8, #hivm.address_space<gm>> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xbf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg4: memref<?xbf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32}, %arg5: memref<?xbf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32}, %arg6: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32}, %arg7: memref<?xf32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 2 : i32}, %arg8: memref<?xbf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg9: memref<?xbf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32}, %arg10: memref<?xf32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32}, %arg11: memref<?xbf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 2 : i32}, %arg12: memref<?xf32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 2 : i32}, %arg13: i32 {tt.divisibility = 16 : i32}, %arg14: i32 {tt.divisibility = 16 : i32}, %arg15: i32 {tt.divisibility = 16 : i32}, %arg16: i32 {tt.divisibility = 16 : i32}, %arg17: i32 {tt.divisibility = 16 : i32}, %arg18: i32 {tt.divisibility = 16 : i32}, %arg19: i32 {tt.divisibility = 16 : i32}, %arg20: i32 {tt.divisibility = 16 : i32}, %arg21: i32 {tt.divisibility = 16 : i32}, %arg22: i32 {tt.divisibility = 16 : i32}, %arg23: i32 {tt.divisibility = 16 : i32}, %arg24: i32 {tt.divisibility = 16 : i32}, %arg25: i32 {tt.divisibility = 16 : i32}, %arg26: i32 {tt.divisibility = 16 : i32}, %arg27: i32 {tt.divisibility = 16 : i32}, %arg28: i32 {tt.divisibility = 16 : i32}, %arg29: i32 {tt.divisibility = 16 : i32}, %arg30: i32 {tt.divisibility = 16 : i32}, %arg31: i32 {tt.divisibility = 16 : i32}, %arg32: i32 {tt.divisibility = 16 : i32}, %arg33: f32, %arg34: i32, %arg35: i32, %arg36: i32, %arg37: i32, %arg38: i32, %arg39: i32, %arg40: i32, %arg41: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, func_dyn_memref_args = dense<[false, true, true, true, true, true, true, true, true, true, true, true, true, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false]> : vector<42xi1>, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIC>, hivm.part_of_mix, mix_mode = "mix", parallel_mode = "simd"} {
  %c3_i64 = arith.constant 3 : i64
  %c1_i64 = arith.constant 1 : i64
  %c0_i64 = arith.constant 0 : i64
  %c1_i64_0 = arith.constant 1 : i64
  %c0_i64_1 = arith.constant 0 : i64
  %c-1_i64 = arith.constant -1 : i64
  %c1_i64_2 = arith.constant 1 : i64
  %c0_i64_3 = arith.constant 0 : i64
  %c-1_i64_4 = arith.constant -1 : i64
  %c8192_i64 = arith.constant 8192 : i64
  %c405504_i64 = arith.constant 405504 : i64
  %c169984_i64 = arith.constant 169984 : i64
  %c401408_i64 = arith.constant 401408 : i64
  %c165888_i64 = arith.constant 165888 : i64
  %c253952_i64 = arith.constant 253952 : i64
  %c18432_i64 = arith.constant 18432 : i64
  %c235520_i64 = arith.constant 235520 : i64
  %c0_i64_5 = arith.constant 0 : i64
  %c128_i32 = arith.constant 128 : i32
  %c128 = arith.constant 128 : index
  %c256_i32 = arith.constant 256 : i32
  %c0_i32 = arith.constant 0 : i32
  %c8_i32 = arith.constant 8 : i32
  %c2_i32 = arith.constant 2 : i32
  %true = arith.constant true
  %c1_i32 = arith.constant 1 : i32
  %c16 = arith.constant 16 : index
  %c576 = arith.constant 576 : index
  %c256 = arith.constant 256 : index
  hivm.hir.set_ffts_base_addr %arg0
  hivm.hir.set_mask_norm
  %0 = arith.muli %arg39, %arg40 : i32
  %1 = arith.muli %0, %arg41 : i32
  annotation.mark %1 {logical_block_num} : i32
  %2 = hivm.hir.get_block_idx -> i64
  %3 = arith.trunci %2 : i64 to i32
  %4 = arith.muli %arg41, %arg40 : i32
  %5 = arith.divsi %3, %4 : i32
  %6 = arith.remsi %5, %arg39 : i32
  hivm.hir.sync_block_set[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 2
  %7 = arith.muli %6, %arg38 : i32
  %8 = arith.addi %6, %c1_i32 : i32
  %9 = arith.muli %8, %arg38 : i32
  %10 = arith.minsi %arg34, %9 : i32
  %11 = arith.muli %6, %arg29 : i32
  %12 = arith.muli %6, %arg31 : i32
  %13 = arith.index_cast %11 : i32 to index
  %14 = arith.index_cast %arg30 : i32 to index
  %reinterpret_cast = memref.reinterpret_cast %arg11 to offset: [%13], sizes: [16, 128], strides: [%14, 1] : memref<?xbf16, #hivm.address_space<gm>> to memref<16x128xbf16, strided<[?, 1], offset: ?>, #hivm.address_space<gm>>
  %15 = arith.index_cast %12 : i32 to index
  %16 = arith.index_cast %arg32 : i32 to index
  %17 = arith.index_cast %arg15 : i32 to index
  %18 = arith.index_cast %arg26 : i32 to index
  %19 = arith.index_cast %2 : i64 to index
  %20 = affine.apply affine_map<()[s0] -> (s0 * 8192)>()[%19]
  %view = memref.view %arg2[%20][] : memref<?xi8, #hivm.address_space<gm>> to memref<16x128xf32, #hivm.address_space<gm>>
  hivm.hir.set_flag[<PIPE_M>, <PIPE_MTE1>, <EVENT_ID0>]
  hivm.hir.set_flag[<PIPE_M>, <PIPE_MTE1>, <EVENT_ID1>]
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID0>]
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID1>]
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID3>]
  hivm.hir.set_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID4>]
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID5>]
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID6>]
  hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID7>]
  hivm.hir.set_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID1>]
  scf.for %arg42 = %7 to %10 step %c1_i32  : i32 {
    %21 = arith.muli %arg42, %arg13 : i32
    %22 = arith.muli %arg42, %arg24 : i32
    %23 = arith.index_cast %21 : i32 to index
    %reinterpret_cast_6 = memref.reinterpret_cast %arg3 to offset: [%23], sizes: [16, 576], strides: [%17, 1] : memref<?xbf16, #hivm.address_space<gm>> to memref<16x576xbf16, strided<[?, 1], offset: ?>, #hivm.address_space<gm>>
    %24 = arith.index_cast %22 : i32 to index
    scf.for %arg43 = %c0_i32 to %c8_i32 step %c1_i32  : i32 {
      %25 = arith.index_cast %arg43 : i32 to index
      %26 = arith.index_cast %c0_i32 : i32 to index
      %27 = arith.index_cast %c8_i32 : i32 to index
      %28 = arith.index_cast %c1_i32 : i32 to index
      %29 = arith.index_cast %arg42 : i32 to index
      %30 = arith.index_cast %7 : i32 to index
      %31 = arith.index_cast %10 : i32 to index
      %32 = arith.index_cast %c1_i32 : i32 to index
      %33 = affine.apply affine_map<()[s0, s1, s2, s3, s4, s5, s6] -> (((s0 - s1) floordiv s3 + ((s4 - s5) floordiv s6) * ((-s1 + s2 + s3 - 1) floordiv s3)) mod 2)>()[%25, %26, %27, %28, %29, %30, %32]
      %34 = arith.index_cast %33 : index to i1
      %c4_i64 = arith.constant 4 : i64
      %c5_i64 = arith.constant 5 : i64
      %35 = arith.select %34, %c4_i64, %c5_i64 : i64
      %c2_i64 = arith.constant 2 : i64
      %c3_i64_7 = arith.constant 3 : i64
      %36 = arith.select %34, %c2_i64, %c3_i64_7 : i64
      %c0_i64_8 = arith.constant 0 : i64
      %c1_i64_9 = arith.constant 1 : i64
      %37 = arith.select %34, %c0_i64_8, %c1_i64_9 : i64
      %38 = arith.index_cast %arg43 : i32 to index
      %39 = arith.index_cast %c0_i32 : i32 to index
      %40 = arith.index_cast %c8_i32 : i32 to index
      %41 = arith.index_cast %c1_i32 : i32 to index
      %42 = arith.index_cast %arg42 : i32 to index
      %43 = arith.index_cast %7 : i32 to index
      %44 = arith.index_cast %10 : i32 to index
      %45 = arith.index_cast %c1_i32 : i32 to index
      %46 = affine.apply affine_map<()[s0, s1, s2, s3, s4, s5, s6] -> ((s0 - s1) floordiv s3 + ((s4 - s5) floordiv s6) * ((-s1 + s2 + s3 - 1) floordiv s3))>()[%38, %39, %40, %41, %42, %43, %45]
      %47 = arith.index_cast %46 : index to i64
      %48 = hivm.hir.pointer_cast(%c0_i64_5, %c235520_i64) : memref<36x1x16x16xbf16, #hivm.address_space<cbuf>>
      annotation.mark %48 {hivm.multi_buffer = 2 : i32} : memref<36x1x16x16xbf16, #hivm.address_space<cbuf>>
      %49 = hivm.hir.pointer_cast(%c18432_i64, %c253952_i64) : memref<36x8x16x16xbf16, #hivm.address_space<cbuf>>
      annotation.mark %49 {hivm.multi_buffer = 2 : i32} : memref<36x8x16x16xbf16, #hivm.address_space<cbuf>>
      %50 = hivm.hir.pointer_cast(%c165888_i64, %c401408_i64) : memref<8x1x16x16xbf16, #hivm.address_space<cbuf>>
      annotation.mark %50 {hivm.multi_buffer = 2 : i32} : memref<8x1x16x16xbf16, #hivm.address_space<cbuf>>
      %51 = arith.muli %arg43, %c128_i32 : i32
      %cast = memref.cast %48 : memref<36x1x16x16xbf16, #hivm.address_space<cbuf>> to memref<?x?x?x?xbf16, #hivm.address_space<cbuf>>
      hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, %37]
      hivm.hir.nd2nz {dst_continuous} ins(%reinterpret_cast_6 : memref<16x576xbf16, strided<[?, 1], offset: ?>, #hivm.address_space<gm>>) outs(%cast : memref<?x?x?x?xbf16, #hivm.address_space<cbuf>>)
      hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID1>]
      %52 = arith.index_cast %51 : i32 to index
      %53 = affine.apply affine_map<()[s0, s1, s2] -> (s0 + s1 * s2)>()[%24, %52, %18]
      %reinterpret_cast_10 = memref.reinterpret_cast %arg8 to offset: [%53], sizes: [128, 576], strides: [%18, 1] : memref<?xbf16, #hivm.address_space<gm>> to memref<128x576xbf16, strided<[?, 1], offset: ?>, #hivm.address_space<gm>>
      %cast_11 = memref.cast %49 : memref<36x8x16x16xbf16, #hivm.address_space<cbuf>> to memref<?x?x?x?xbf16, #hivm.address_space<cbuf>>
      hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, %36]
      hivm.hir.nd2nz {dst_continuous} ins(%reinterpret_cast_10 : memref<128x576xbf16, strided<[?, 1], offset: ?>, #hivm.address_space<gm>>) outs(%cast_11 : memref<?x?x?x?xbf16, #hivm.address_space<cbuf>>)
      hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID0>]
      %54 = hivm.hir.pointer_cast(%c0_i64_5) : memref<8x1x16x16xf32, #hivm.address_space<cc>>
      %cast_12 = memref.cast %54 : memref<8x1x16x16xf32, #hivm.address_space<cc>> to memref<?x?x?x?xf32, #hivm.address_space<cc>>
      hivm.hir.wait_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
      hivm.hir.mmadL1 {already_set_real_mkn, b_transpose, fixpipe_already_inserted = true} ins(%cast, %cast_11, %true, %c16, %c576, %c128 : memref<?x?x?x?xbf16, #hivm.address_space<cbuf>>, memref<?x?x?x?xbf16, #hivm.address_space<cbuf>>, i1, index, index, index) outs(%cast_12 : memref<?x?x?x?xf32, #hivm.address_space<cc>>) sync_related_args(%c1_i64, %c0_i64, %37, %36, %47, %c0_i64_3, %c1_i64_2 : i64, i64, i64, i64, i64, i64, i64)
      hivm.hir.set_flag[<PIPE_M>, <PIPE_FIX>, <EVENT_ID0>]
      hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 0
      hivm.hir.wait_flag[<PIPE_M>, <PIPE_FIX>, <EVENT_ID0>]
      hivm.hir.fixpipe {dma_mode = #hivm.dma_mode<nz2nd>} ins(%cast_12 : memref<?x?x?x?xf32, #hivm.address_space<cc>>) outs(%view : memref<16x128xf32, #hivm.address_space<gm>>)
      hivm.hir.set_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
      annotation.mark %view : memref<16x128xf32, #hivm.address_space<gm>>
      hivm.hir.sync_block_set[<CUBE>, <PIPE_FIX>, <PIPE_S>] flag = 1
      %cast_13 = memref.cast %50 : memref<8x1x16x16xbf16, #hivm.address_space<cbuf>> to memref<?x?x?x?xbf16, #hivm.address_space<cbuf>>
      hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE3>, <PIPE_S>] flag = 1
      hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, %35]
      hivm.hir.pipe_barrier[<PIPE_MTE2>]
      hivm.hir.nd2nz {dst_continuous} ins(%reinterpret_cast : memref<16x128xbf16, strided<[?, 1], offset: ?>, #hivm.address_space<gm>>) outs(%cast_13 : memref<?x?x?x?xbf16, #hivm.address_space<cbuf>>)
      hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID2>]
      hivm.hir.sync_block_set[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 2
      hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID2>]
      scf.for %arg44 = %c0_i32 to %c2_i32 step %c1_i32  : i32 {
        %55 = arith.index_cast %arg44 : i32 to index
        %56 = arith.index_cast %c0_i32 : i32 to index
        %57 = arith.index_cast %c2_i32 : i32 to index
        %58 = arith.index_cast %c1_i32 : i32 to index
        %59 = arith.index_cast %arg43 : i32 to index
        %60 = arith.index_cast %c0_i32 : i32 to index
        %61 = arith.index_cast %c8_i32 : i32 to index
        %62 = arith.index_cast %c1_i32 : i32 to index
        %63 = arith.index_cast %arg42 : i32 to index
        %64 = arith.index_cast %7 : i32 to index
        %65 = arith.index_cast %10 : i32 to index
        %66 = arith.index_cast %c1_i32 : i32 to index
        %67 = affine.apply affine_map<()[s0, s1, s2, s3, s4, s5, s6, s7, s8, s9, s10] -> (((s0 - s1) floordiv s3 + ((s4 - s5) floordiv s7) * ((-s1 + s2 + s3 - 1) floordiv s3) + ((s8 - s9) floordiv s10) * (((-s1 + s2 + s3 - 1) floordiv s3) * ((-s5 + s6 + s7 - 1) floordiv s7))) mod 2)>()[%55, %56, %57, %58, %59, %60, %61, %62, %63, %64, %66]
        %68 = arith.index_cast %67 : index to i1
        %c6_i64 = arith.constant 6 : i64
        %c7_i64 = arith.constant 7 : i64
        %69 = arith.select %68, %c6_i64, %c7_i64 : i64
        %70 = arith.index_cast %arg44 : i32 to index
        %71 = arith.index_cast %c0_i32 : i32 to index
        %72 = arith.index_cast %c2_i32 : i32 to index
        %73 = arith.index_cast %c1_i32 : i32 to index
        %74 = arith.index_cast %arg43 : i32 to index
        %75 = arith.index_cast %c0_i32 : i32 to index
        %76 = arith.index_cast %c8_i32 : i32 to index
        %77 = arith.index_cast %c1_i32 : i32 to index
        %78 = arith.index_cast %arg42 : i32 to index
        %79 = arith.index_cast %7 : i32 to index
        %80 = arith.index_cast %10 : i32 to index
        %81 = arith.index_cast %c1_i32 : i32 to index
        %82 = affine.apply affine_map<()[s0, s1, s2, s3, s4, s5, s6, s7, s8, s9, s10] -> ((s0 - s1) floordiv s3 + ((s4 - s5) floordiv s7) * ((-s1 + s2 + s3 - 1) floordiv s3) + ((s8 - s9) floordiv s10) * (((-s1 + s2 + s3 - 1) floordiv s3) * ((-s5 + s6 + s7 - 1) floordiv s7)))>()[%70, %71, %72, %73, %74, %75, %76, %77, %78, %79, %81]
        %83 = arith.index_cast %82 : index to i64
        %84 = hivm.hir.pointer_cast(%c169984_i64, %c405504_i64) : memref<16x8x16x16xbf16, #hivm.address_space<cbuf>>
        annotation.mark %84 {hivm.multi_buffer = 2 : i32} : memref<16x8x16x16xbf16, #hivm.address_space<cbuf>>
        %85 = arith.muli %arg44, %c256_i32 : i32
        %86 = arith.index_cast %85 : i32 to index
        %87 = affine.apply affine_map<()[s0, s1, s2, s3] -> (s0 + s1 + s2 * s3)>()[%86, %24, %52, %18]
        %reinterpret_cast_14 = memref.reinterpret_cast %arg8 to offset: [%87], sizes: [128, 256], strides: [%18, 1] : memref<?xbf16, #hivm.address_space<gm>> to memref<128x256xbf16, strided<[?, 1], offset: ?>, #hivm.address_space<gm>>
        %cast_15 = memref.cast %84 : memref<16x8x16x16xbf16, #hivm.address_space<cbuf>> to memref<?x?x?x?xbf16, #hivm.address_space<cbuf>>
        hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, %69]
        hivm.hir.nd2nz {dst_continuous} ins(%reinterpret_cast_14 : memref<128x256xbf16, strided<[?, 1], offset: ?>, #hivm.address_space<gm>>) outs(%cast_15 : memref<?x?x?x?xbf16, #hivm.address_space<cbuf>>)
        hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_MTE1>, <EVENT_ID3>]
        %88 = hivm.hir.pointer_cast(%c8192_i64) : memref<16x1x16x16xf32, #hivm.address_space<cc>>
        %cast_16 = memref.cast %88 : memref<16x1x16x16xf32, #hivm.address_space<cc>> to memref<?x?x?x?xf32, #hivm.address_space<cc>>
        hivm.hir.wait_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID1>]
        hivm.hir.mmadL1 {already_set_real_mkn, fixpipe_already_inserted = true} ins(%cast_13, %cast_15, %true, %c16, %c128, %c256 : memref<?x?x?x?xbf16, #hivm.address_space<cbuf>>, memref<?x?x?x?xbf16, #hivm.address_space<cbuf>>, i1, index, index, index) outs(%cast_16 : memref<?x?x?x?xf32, #hivm.address_space<cc>>) sync_related_args(%c-1_i64, %c3_i64, %c-1_i64, %69, %83, %c0_i64_1, %c1_i64_0 : i64, i64, i64, i64, i64, i64, i64)
        hivm.hir.set_flag[<PIPE_M>, <PIPE_FIX>, <EVENT_ID1>]
        %89 = affine.apply affine_map<()[s0, s1] -> (s0 + s1)>()[%15, %86]
        %reinterpret_cast_17 = memref.reinterpret_cast %arg12 to offset: [%89], sizes: [16, 256], strides: [%16, 1] : memref<?xf32, #hivm.address_space<gm>> to memref<16x256xf32, strided<[?, 1], offset: ?>, #hivm.address_space<gm>>
        hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 3
        hivm.hir.wait_flag[<PIPE_M>, <PIPE_FIX>, <EVENT_ID1>]
        hivm.hir.fixpipe {dma_mode = #hivm.dma_mode<nz2nd>} ins(%cast_16 : memref<?x?x?x?xf32, #hivm.address_space<cc>>) outs(%reinterpret_cast_17 : memref<16x256xf32, strided<[?, 1], offset: ?>, #hivm.address_space<gm>>)
        hivm.hir.set_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID1>]
        hivm.hir.sync_block_set[<CUBE>, <PIPE_FIX>, <PIPE_S>] flag = 1
      }
      hivm.hir.set_flag[<PIPE_MTE1>, <PIPE_MTE2>, %35]
    }
  }
  hivm.hir.wait_flag[<PIPE_M>, <PIPE_MTE1>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_M>, <PIPE_MTE1>, <EVENT_ID1>]
  hivm.hir.pipe_barrier[<PIPE_ALL>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID1>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID2>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID3>]
  hivm.hir.wait_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID4>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID5>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID6>]
  hivm.hir.wait_flag[<PIPE_MTE1>, <PIPE_MTE2>, <EVENT_ID7>]
  hivm.hir.wait_flag[<PIPE_FIX>, <PIPE_M>, <EVENT_ID1>]
  hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 0
  hivm.hir.sync_block_wait[<CUBE>, <PIPE_MTE2>, <PIPE_S>] flag = 3
  return
}

// -----// IR Dump After InjectSync (hivm-inject-sync) //----- //
func.func @sparse_flash_attention_prefill_kernel_mix_aiv(%arg0: i64 {hacc.arg_type = #hacc.arg_type<ffts_base_address>}, %arg1: memref<?xi8, #hivm.address_space<gm>> {hacc.arg_type = #hacc.arg_type<sync_block_lock>}, %arg2: memref<?xi8, #hivm.address_space<gm>> {hacc.arg_type = #hacc.arg_type<workspace>}, %arg3: memref<?xbf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg4: memref<?xbf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32}, %arg5: memref<?xbf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32}, %arg6: memref<?xi32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32}, %arg7: memref<?xf32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 2 : i32}, %arg8: memref<?xbf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 0 : i32}, %arg9: memref<?xbf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32}, %arg10: memref<?xf32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32}, %arg11: memref<?xbf16, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 2 : i32}, %arg12: memref<?xf32, #hivm.address_space<gm>> {tt.divisibility = 16 : i32, tt.tensor_kind = 2 : i32}, %arg13: i32 {tt.divisibility = 16 : i32}, %arg14: i32 {tt.divisibility = 16 : i32}, %arg15: i32 {tt.divisibility = 16 : i32}, %arg16: i32 {tt.divisibility = 16 : i32}, %arg17: i32 {tt.divisibility = 16 : i32}, %arg18: i32 {tt.divisibility = 16 : i32}, %arg19: i32 {tt.divisibility = 16 : i32}, %arg20: i32 {tt.divisibility = 16 : i32}, %arg21: i32 {tt.divisibility = 16 : i32}, %arg22: i32 {tt.divisibility = 16 : i32}, %arg23: i32 {tt.divisibility = 16 : i32}, %arg24: i32 {tt.divisibility = 16 : i32}, %arg25: i32 {tt.divisibility = 16 : i32}, %arg26: i32 {tt.divisibility = 16 : i32}, %arg27: i32 {tt.divisibility = 16 : i32}, %arg28: i32 {tt.divisibility = 16 : i32}, %arg29: i32 {tt.divisibility = 16 : i32}, %arg30: i32 {tt.divisibility = 16 : i32}, %arg31: i32 {tt.divisibility = 16 : i32}, %arg32: i32 {tt.divisibility = 16 : i32}, %arg33: f32, %arg34: i32, %arg35: i32, %arg36: i32, %arg37: i32, %arg38: i32, %arg39: i32, %arg40: i32, %arg41: i32) attributes {SyncBlockLockArgIdx = 0 : i64, WorkspaceArgIdx = 1 : i64, func_dyn_memref_args = dense<[false, true, true, true, true, true, true, true, true, true, true, true, true, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false]> : vector<42xi1>, hacc.entry, hacc.function_kind = #hacc.function_kind<DEVICE>, hivm.func_core_type = #hivm.func_core_type<AIV>, hivm.part_of_mix, mix_mode = "mix", parallel_mode = "simd"} {
  %c84128_i64 = arith.constant 84128 : i64
  %c83616_i64 = arith.constant 83616 : i64
  %c67232_i64 = arith.constant 67232 : i64
  %c50848_i64 = arith.constant 50848 : i64
  %c50784_i64 = arith.constant 50784 : i64
  %c50272_i64 = arith.constant 50272 : i64
  %c50240_i64 = arith.constant 50240 : i64
  %c50176_i64 = arith.constant 50176 : i64
  %c50144_i64 = arith.constant 50144 : i64
  %c50080_i64 = arith.constant 50080 : i64
  %c50016_i64 = arith.constant 50016 : i64
  %c49984_i64 = arith.constant 49984 : i64
  %c49920_i64 = arith.constant 49920 : i64
  %c49856_i64 = arith.constant 49856 : i64
  %c45760_i64 = arith.constant 45760 : i64
  %c45696_i64 = arith.constant 45696 : i64
  %c45184_i64 = arith.constant 45184 : i64
  %c36992_i64 = arith.constant 36992 : i64
  %c32896_i64 = arith.constant 32896 : i64
  %c32832_i64 = arith.constant 32832 : i64
  %c32768_i64 = arith.constant 32768 : i64
  %c24576_i64 = arith.constant 24576 : i64
  %c16384_i64 = arith.constant 16384 : i64
  %c8192_i64 = arith.constant 8192 : i64
  %c84640_i64 = arith.constant 84640 : i64
  %c0_i64 = arith.constant 0 : i64
  %c0 = arith.constant 0 : index
  %cst = arith.constant 0xFF800000 : f32
  %c128_i32 = arith.constant 128 : i32
  %c1024 = arith.constant 1024 : index
  %cst_0 = arith.constant 2.000000e+00 : f32
  %c256_i32 = arith.constant 256 : i32
  %cst_1 = arith.constant 0.000000e+00 : f32
  %c0_i32 = arith.constant 0 : i32
  %c8_i32 = arith.constant 8 : i32
  %c2_i32 = arith.constant 2 : i32
  %c2147483647_i32 = arith.constant 2147483647 : i32
  %c-2139095040_i32 = arith.constant -2139095040 : i32
  %c1_i32 = arith.constant 1 : i32
  hivm.hir.set_ffts_base_addr %arg0
  hivm.hir.set_mask_norm
  %0 = arith.muli %arg39, %arg40 : i32
  %1 = arith.muli %0, %arg41 : i32
  annotation.mark %1 {logical_block_num} : i32
  %2 = hivm.hir.get_block_idx -> i64
  %3 = arith.trunci %2 : i64 to i32
  %4 = arith.muli %arg41, %arg40 : i32
  %5 = arith.divsi %3, %4 : i32
  %6 = arith.remsi %5, %arg39 : i32
  hivm.hir.sync_block_set[<VECTOR>, <PIPE_MTE2>, <PIPE_S>] flag = 0
  hivm.hir.sync_block_set[<VECTOR>, <PIPE_MTE2>, <PIPE_S>] flag = 3
  %7 = hivm.hir.pointer_cast(%c0_i64) : memref<16x128xf32, #hivm.address_space<ub>>
  %8 = hivm.hir.pointer_cast(%c84640_i64) : memref<16xf32, #hivm.address_space<ub>>
  %9 = arith.muli %6, %arg38 : i32
  %10 = arith.addi %6, %c1_i32 : i32
  %11 = arith.muli %10, %arg38 : i32
  %12 = arith.minsi %arg34, %11 : i32
  %13 = arith.muli %6, %arg29 : i32
  %14 = arith.muli %6, %arg31 : i32
  %15 = arith.index_cast %13 : i32 to index
  %16 = arith.index_cast %arg30 : i32 to index
  %reinterpret_cast = memref.reinterpret_cast %arg11 to offset: [%15], sizes: [16, 128], strides: [%16, 1] : memref<?xbf16, #hivm.address_space<gm>> to memref<16x128xbf16, strided<[?, 1], offset: ?>, #hivm.address_space<gm>>
  %17 = arith.index_cast %14 : i32 to index
  %18 = arith.index_cast %arg32 : i32 to index
  %19 = arith.index_cast %arg23 : i32 to index
  %20 = arith.index_cast %2 : i64 to index
  %21 = affine.apply affine_map<()[s0] -> (s0 * 8192)>()[%20]
  %view = memref.view %arg2[%21][] : memref<?xi8, #hivm.address_space<gm>> to memref<16x128xf32, #hivm.address_space<gm>>
  %22 = hivm.hir.get_sub_block_idx -> i64
  %23 = arith.index_cast %22 : i64 to index
  %24 = arith.cmpi eq, %23, %c0 : index
  hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
  hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID0>]
  hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_MTE2>, <EVENT_ID0>]
  hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
  scf.for %arg42 = %9 to %12 step %c1_i32  : i32 {
    %25 = arith.muli %arg42, %arg22 : i32
    %26 = arith.index_cast %25 : i32 to index
    hivm.hir.pipe_barrier[<PIPE_V>]
    hivm.hir.pipe_barrier[<PIPE_V>]
    hivm.hir.vbrc ins(%cst : f32) outs(%8 : memref<16xf32, #hivm.address_space<ub>>)
    %27 = scf.for %arg43 = %c0_i32 to %c8_i32 step %c1_i32 iter_args(%arg44 = %8) -> (memref<16xf32, #hivm.address_space<ub>>)  : i32 {
      %28 = arith.muli %arg43, %c128_i32 : i32
      %29 = arith.index_cast %28 : i32 to index
      hivm.hir.sync_block_wait[<VECTOR>, <PIPE_FIX>, <PIPE_S>] flag = 1
      %collapse_shape = memref.collapse_shape %view [[0, 1]] : memref<16x128xf32, #hivm.address_space<gm>> into memref<2048xf32, #hivm.address_space<gm>>
      %30 = hivm.hir.pointer_cast(%c8192_i64) : memref<2048xf32, #hivm.address_space<ub>>
      hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
      hivm.hir.load ins(%collapse_shape : memref<2048xf32, #hivm.address_space<gm>>) outs(%30 : memref<2048xf32, #hivm.address_space<ub>>)
      hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
      hivm.hir.sync_block_set[<VECTOR>, <PIPE_MTE2>, <PIPE_S>] flag = 0
      %31 = hivm.hir.pointer_cast(%c8192_i64) : memref<16x128xf32, #hivm.address_space<ub>>
      %collapse_shape_2 = memref.collapse_shape %31 [[0, 1]] : memref<16x128xf32, #hivm.address_space<ub>> into memref<2048xf32, #hivm.address_space<ub>>
      hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID0>]
      hivm.hir.vmul ins(%30, %arg33 : memref<2048xf32, #hivm.address_space<ub>>, f32) outs(%collapse_shape_2 : memref<2048xf32, #hivm.address_space<ub>>)
      %32 = affine.apply affine_map<()[s0] -> (s0 + 128)>()[%29]
      %33 = arith.maxsi %29, %c1024 : index
      %34 = arith.minsi %32, %33 : index
      %35 = affine.apply affine_map<()[s0, s1] -> (s0 - s1)>()[%34, %29]
      %subview = memref.subview %31[0, 0] [16, %35] [1, 1] : memref<16x128xf32, #hivm.address_space<ub>> to memref<16x?xf32, strided<[128, 1]>, #hivm.address_space<ub>>
      %collapse_shape_3 = memref.collapse_shape %7 [[0, 1]] : memref<16x128xf32, #hivm.address_space<ub>> into memref<2048xf32, #hivm.address_space<ub>>
      hivm.hir.vbrc ins(%cst : f32) outs(%collapse_shape_3 : memref<2048xf32, #hivm.address_space<ub>>)
      %subview_4 = memref.subview %7[0, 0] [16, %35] [1, 1] : memref<16x128xf32, #hivm.address_space<ub>> to memref<16x?xf32, strided<[128, 1]>, #hivm.address_space<ub>>
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.copy ins(%subview : memref<16x?xf32, strided<[128, 1]>, #hivm.address_space<ub>>) outs(%subview_4 : memref<16x?xf32, strided<[128, 1]>, #hivm.address_space<ub>>)
      hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
      %36 = hivm.hir.bitcast %7 : memref<16x128xf32, #hivm.address_space<ub>> -> memref<16x128xi32, #hivm.address_space<ub>>
      %37 = hivm.hir.pointer_cast(%c16384_i64) : memref<2048xi32, #hivm.address_space<ub>>
      hivm.hir.vbrc ins(%c2147483647_i32 : i32) outs(%37 : memref<2048xi32, #hivm.address_space<ub>>)
      %collapse_shape_5 = memref.collapse_shape %36 [[0, 1]] : memref<16x128xi32, #hivm.address_space<ub>> into memref<2048xi32, #hivm.address_space<ub>>
      %38 = hivm.hir.pointer_cast(%c16384_i64) : memref<2048xi32, #hivm.address_space<ub>>
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.vand ins(%collapse_shape_5, %37 : memref<2048xi32, #hivm.address_space<ub>>, memref<2048xi32, #hivm.address_space<ub>>) outs(%38 : memref<2048xi32, #hivm.address_space<ub>>)
      %39 = hivm.hir.pointer_cast(%c16384_i64) : memref<2048xi32, #hivm.address_space<ub>>
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.vadd ins(%38, %c-2139095040_i32 : memref<2048xi32, #hivm.address_space<ub>>, i32) outs(%39 : memref<2048xi32, #hivm.address_space<ub>>)
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.vmin ins(%39, %c1_i32 : memref<2048xi32, #hivm.address_space<ub>>, i32) outs(%39 : memref<2048xi32, #hivm.address_space<ub>>)
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.vmax ins(%39, %c0_i32 : memref<2048xi32, #hivm.address_space<ub>>, i32) outs(%39 : memref<2048xi32, #hivm.address_space<ub>>)
      %40 = hivm.hir.pointer_cast(%c16384_i64) : memref<2048xf32, #hivm.address_space<ub>>
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.vcast ins(%39 : memref<2048xi32, #hivm.address_space<ub>>) outs(%40 : memref<2048xf32, #hivm.address_space<ub>>)
      %41 = hivm.hir.pointer_cast(%c16384_i64) : memref<2048xi1, #hivm.address_space<ub>>
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.vcmp ins(%40, %cst_1 : memref<2048xf32, #hivm.address_space<ub>>, f32) outs(%41 : memref<2048xi1, #hivm.address_space<ub>>)
      %42 = hivm.hir.pointer_cast(%c16384_i64) : memref<2048xi1, #hivm.address_space<ub>>
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.vnot ins(%41 : memref<2048xi1, #hivm.address_space<ub>>) outs(%42 : memref<2048xi1, #hivm.address_space<ub>>)
      %43 = hivm.hir.pointer_cast(%c24576_i64) : memref<16x128xf32, #hivm.address_space<ub>>
      %collapse_shape_6 = memref.collapse_shape %43 [[0, 1]] : memref<16x128xf32, #hivm.address_space<ub>> into memref<2048xf32, #hivm.address_space<ub>>
      %44 = hivm.hir.pointer_cast(%c32768_i64) : memref<16xf32, #hivm.address_space<ub>>
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.vsel ins(%42, %cst, %collapse_shape_3 : memref<2048xi1, #hivm.address_space<ub>>, f32, memref<2048xf32, #hivm.address_space<ub>>) outs(%collapse_shape_6 : memref<2048xf32, #hivm.address_space<ub>>) temp_buffer(%44 : memref<16xf32, #hivm.address_space<ub>>)
      %45 = hivm.hir.pointer_cast(%c32832_i64) : memref<16x1xf32, #hivm.address_space<ub>>
      %46 = hivm.hir.pointer_cast(%c32896_i64) : memref<1024xf32, #hivm.address_space<ub>>
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.vreduce <max> ins(%43 : memref<16x128xf32, #hivm.address_space<ub>>) outs(%45 : memref<16x1xf32, #hivm.address_space<ub>>) temp_buffer(%46 : memref<1024xf32, #hivm.address_space<ub>>) unsigned_src = false reduce_dims = [1]
      %collapse_shape_7 = memref.collapse_shape %45 [[0, 1]] : memref<16x1xf32, #hivm.address_space<ub>> into memref<16xf32, #hivm.address_space<ub>>
      %47 = hivm.hir.pointer_cast(%c36992_i64) : memref<16x128xf32, #hivm.address_space<ub>>
      %48 = hivm.hir.pointer_cast(%c45184_i64) : memref<128xf32, #hivm.address_space<ub>>
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID0>]
      hivm.hir.vsub ins(%7, %45 : memref<16x128xf32, #hivm.address_space<ub>>, memref<16x1xf32, #hivm.address_space<ub>>) outs(%47 : memref<16x128xf32, #hivm.address_space<ub>>) temp_buffer(%48 : memref<128xf32, #hivm.address_space<ub>>) broadcast = [1]
      %49 = hivm.hir.pointer_cast(%c36992_i64) : memref<16x128xf32, #hivm.address_space<ub>>
      %collapse_shape_8 = memref.collapse_shape %47 [[0, 1]] : memref<16x128xf32, #hivm.address_space<ub>> into memref<2048xf32, #hivm.address_space<ub>>
      %collapse_shape_9 = memref.collapse_shape %49 [[0, 1]] : memref<16x128xf32, #hivm.address_space<ub>> into memref<2048xf32, #hivm.address_space<ub>>
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.vexp ins(%collapse_shape_8 : memref<2048xf32, #hivm.address_space<ub>>) outs(%collapse_shape_9 : memref<2048xf32, #hivm.address_space<ub>>)
      %50 = hivm.hir.pointer_cast(%c45696_i64) : memref<16x1xf32, #hivm.address_space<ub>>
      %51 = hivm.hir.pointer_cast(%c45760_i64) : memref<1024xf32, #hivm.address_space<ub>>
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.vreduce <sum> ins(%49 : memref<16x128xf32, #hivm.address_space<ub>>) outs(%50 : memref<16x1xf32, #hivm.address_space<ub>>) temp_buffer(%51 : memref<1024xf32, #hivm.address_space<ub>>) unsigned_src = false reduce_dims = [1]
      %collapse_shape_10 = memref.collapse_shape %50 [[0, 1]] : memref<16x1xf32, #hivm.address_space<ub>> into memref<16xf32, #hivm.address_space<ub>>
      %52 = hivm.hir.pointer_cast(%c49856_i64) : memref<16xf32, #hivm.address_space<ub>>
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.vln ins(%collapse_shape_10 : memref<16xf32, #hivm.address_space<ub>>) outs(%52 : memref<16xf32, #hivm.address_space<ub>>)
      %53 = hivm.hir.pointer_cast(%c49856_i64) : memref<16xf32, #hivm.address_space<ub>>
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.vadd ins(%collapse_shape_7, %52 : memref<16xf32, #hivm.address_space<ub>>, memref<16xf32, #hivm.address_space<ub>>) outs(%53 : memref<16xf32, #hivm.address_space<ub>>)
      %54 = hivm.hir.pointer_cast(%c49920_i64) : memref<16xf32, #hivm.address_space<ub>>
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.vadd ins(%arg44, %53 : memref<16xf32, #hivm.address_space<ub>>, memref<16xf32, #hivm.address_space<ub>>) outs(%54 : memref<16xf32, #hivm.address_space<ub>>)
      %55 = hivm.hir.pointer_cast(%c49920_i64) : memref<16xf32, #hivm.address_space<ub>>
      %56 = hivm.hir.pointer_cast(%c49984_i64) : memref<8xf32, #hivm.address_space<ub>>
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.vdiv ins(%54, %cst_0 : memref<16xf32, #hivm.address_space<ub>>, f32) outs(%55 : memref<16xf32, #hivm.address_space<ub>>) temp_buffer(%56 : memref<8xf32, #hivm.address_space<ub>>)
      %57 = hivm.hir.pointer_cast(%c50016_i64) : memref<16xf32, #hivm.address_space<ub>>
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.vsub ins(%arg44, %55 : memref<16xf32, #hivm.address_space<ub>>, memref<16xf32, #hivm.address_space<ub>>) outs(%57 : memref<16xf32, #hivm.address_space<ub>>)
      %58 = hivm.hir.pointer_cast(%c50016_i64) : memref<16xf32, #hivm.address_space<ub>>
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.vexp ins(%57 : memref<16xf32, #hivm.address_space<ub>>) outs(%58 : memref<16xf32, #hivm.address_space<ub>>)
      %59 = hivm.hir.pointer_cast(%c50080_i64) : memref<16xf32, #hivm.address_space<ub>>
      hivm.hir.vsub ins(%53, %55 : memref<16xf32, #hivm.address_space<ub>>, memref<16xf32, #hivm.address_space<ub>>) outs(%59 : memref<16xf32, #hivm.address_space<ub>>)
      %60 = hivm.hir.pointer_cast(%c50080_i64) : memref<16xf32, #hivm.address_space<ub>>
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.vexp ins(%59 : memref<16xf32, #hivm.address_space<ub>>) outs(%60 : memref<16xf32, #hivm.address_space<ub>>)
      %61 = hivm.hir.pointer_cast(%c50080_i64) : memref<16xf32, #hivm.address_space<ub>>
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.vadd ins(%58, %60 : memref<16xf32, #hivm.address_space<ub>>, memref<16xf32, #hivm.address_space<ub>>) outs(%61 : memref<16xf32, #hivm.address_space<ub>>)
      %62 = hivm.hir.pointer_cast(%c50080_i64) : memref<16xf32, #hivm.address_space<ub>>
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.vln ins(%61 : memref<16xf32, #hivm.address_space<ub>>) outs(%62 : memref<16xf32, #hivm.address_space<ub>>)
      %63 = hivm.hir.pointer_cast(%c49920_i64) : memref<16xf32, #hivm.address_space<ub>>
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.vadd ins(%55, %62 : memref<16xf32, #hivm.address_space<ub>>, memref<16xf32, #hivm.address_space<ub>>) outs(%63 : memref<16xf32, #hivm.address_space<ub>>)
      %64 = hivm.hir.pointer_cast(%c50144_i64) : memref<16xi1, #hivm.address_space<ub>>
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.vcmp ins(%63, %63 : memref<16xf32, #hivm.address_space<ub>>, memref<16xf32, #hivm.address_space<ub>>) outs(%64 : memref<16xi1, #hivm.address_space<ub>>)
      %65 = hivm.hir.pointer_cast(%c50144_i64) : memref<16xi1, #hivm.address_space<ub>>
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.vnot ins(%64 : memref<16xi1, #hivm.address_space<ub>>) outs(%65 : memref<16xi1, #hivm.address_space<ub>>)
      %66 = hivm.hir.pointer_cast(%c50176_i64) : memref<16xf32, #hivm.address_space<ub>>
      %67 = hivm.hir.pointer_cast(%c50240_i64) : memref<8xf32, #hivm.address_space<ub>>
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.vsel ins(%65, %53, %63 : memref<16xi1, #hivm.address_space<ub>>, memref<16xf32, #hivm.address_space<ub>>, memref<16xf32, #hivm.address_space<ub>>) outs(%66 : memref<16xf32, #hivm.address_space<ub>>) temp_buffer(%67 : memref<8xf32, #hivm.address_space<ub>>)
      %68 = hivm.hir.pointer_cast(%c49856_i64) : memref<16xf32, #hivm.address_space<ub>>
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.vsub ins(%53, %66 : memref<16xf32, #hivm.address_space<ub>>, memref<16xf32, #hivm.address_space<ub>>) outs(%68 : memref<16xf32, #hivm.address_space<ub>>)
      %69 = hivm.hir.pointer_cast(%c49856_i64) : memref<16xf32, #hivm.address_space<ub>>
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.vexp ins(%68 : memref<16xf32, #hivm.address_space<ub>>) outs(%69 : memref<16xf32, #hivm.address_space<ub>>)
      %70 = hivm.hir.pointer_cast(%c36992_i64) : memref<16x128xf32, #hivm.address_space<ub>>
      %71 = hivm.hir.pointer_cast(%c50272_i64) : memref<128xf32, #hivm.address_space<ub>>
      hivm.hir.vdiv ins(%49, %50 : memref<16x128xf32, #hivm.address_space<ub>>, memref<16x1xf32, #hivm.address_space<ub>>) outs(%70 : memref<16x128xf32, #hivm.address_space<ub>>) temp_buffer(%71 : memref<128xf32, #hivm.address_space<ub>>) broadcast = [1]
      %72 = hivm.hir.pointer_cast(%c36992_i64) : memref<16x128xbf16, #hivm.address_space<ub>>
      %collapse_shape_11 = memref.collapse_shape %70 [[0, 1]] : memref<16x128xf32, #hivm.address_space<ub>> into memref<2048xf32, #hivm.address_space<ub>>
      %collapse_shape_12 = memref.collapse_shape %72 [[0, 1]] : memref<16x128xbf16, #hivm.address_space<ub>> into memref<2048xbf16, #hivm.address_space<ub>>
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.vcast ins(%collapse_shape_11 : memref<2048xf32, #hivm.address_space<ub>>) outs(%collapse_shape_12 : memref<2048xbf16, #hivm.address_space<ub>>)
      hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE3>, <EVENT_ID0>]
      hivm.hir.sync_block_wait[<VECTOR>, <PIPE_MTE2>, <PIPE_S>] flag = 2
      hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE3>, <EVENT_ID0>]
      scf.if %24 {
        hivm.hir.store ins(%72 : memref<16x128xbf16, #hivm.address_space<ub>>) outs(%reinterpret_cast : memref<16x128xbf16, strided<[?, 1], offset: ?>, #hivm.address_space<gm>>)
      } {limit_sub_block_id0}
      hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID0>]
      hivm.hir.sync_block_set[<VECTOR>, <PIPE_MTE3>, <PIPE_S>] flag = 1
      %73 = hivm.hir.pointer_cast(%c50784_i64) : memref<16xf32, #hivm.address_space<ub>>
      hivm.hir.vsub ins(%arg44, %66 : memref<16xf32, #hivm.address_space<ub>>, memref<16xf32, #hivm.address_space<ub>>) outs(%73 : memref<16xf32, #hivm.address_space<ub>>)
      %74 = hivm.hir.pointer_cast(%c50784_i64) : memref<16xf32, #hivm.address_space<ub>>
      hivm.hir.pipe_barrier[<PIPE_V>]
      hivm.hir.vexp ins(%73 : memref<16xf32, #hivm.address_space<ub>>) outs(%74 : memref<16xf32, #hivm.address_space<ub>>)
      %expand_shape = memref.expand_shape %74 [[0, 1]] output_shape [16, 1] : memref<16xf32, #hivm.address_space<ub>> into memref<16x1xf32, #hivm.address_space<ub>>
      %expand_shape_13 = memref.expand_shape %69 [[0, 1]] output_shape [16, 1] : memref<16xf32, #hivm.address_space<ub>> into memref<16x1xf32, #hivm.address_space<ub>>
      scf.for %arg45 = %c0_i32 to %c2_i32 step %c1_i32  : i32 {
        %76 = arith.muli %arg45, %c256_i32 : i32
        %77 = arith.index_cast %76 : i32 to index
        %78 = affine.apply affine_map<()[s0, s1] -> (s0 + s1)>()[%17, %77]
        %reinterpret_cast_14 = memref.reinterpret_cast %arg12 to offset: [%78], sizes: [16, 256], strides: [%18, 1] : memref<?xf32, #hivm.address_space<gm>> to memref<16x256xf32, strided<[?, 1], offset: ?>, #hivm.address_space<gm>>
        %79 = affine.apply affine_map<()[s0, s1] -> (s0 + s1)>()[%26, %77]
        %reinterpret_cast_15 = memref.reinterpret_cast %arg7 to offset: [%79], sizes: [16, 256], strides: [%19, 1] : memref<?xf32, #hivm.address_space<gm>> to memref<16x256xf32, strided<[?, 1], offset: ?>, #hivm.address_space<gm>>
        %80 = hivm.hir.pointer_cast(%c50848_i64) : memref<16x256xf32, #hivm.address_space<ub>>
        hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_MTE2>, <EVENT_ID0>]
        hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
        hivm.hir.load ins(%reinterpret_cast_15 : memref<16x256xf32, strided<[?, 1], offset: ?>, #hivm.address_space<gm>>) outs(%80 : memref<16x256xf32, #hivm.address_space<ub>>) eviction_policy = <EvictFirst>
        hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID1>]
        %81 = hivm.hir.pointer_cast(%c67232_i64) : memref<16x256xf32, #hivm.address_space<ub>>
        hivm.hir.sync_block_wait[<VECTOR>, <PIPE_FIX>, <PIPE_S>] flag = 1
        hivm.hir.load ins(%reinterpret_cast_14 : memref<16x256xf32, strided<[?, 1], offset: ?>, #hivm.address_space<gm>>) outs(%81 : memref<16x256xf32, #hivm.address_space<ub>>) eviction_policy = <EvictFirst>
        hivm.hir.set_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID2>]
        hivm.hir.sync_block_set[<VECTOR>, <PIPE_MTE2>, <PIPE_S>] flag = 3
        %82 = hivm.hir.pointer_cast(%c50848_i64) : memref<16x256xf32, #hivm.address_space<ub>>
        %83 = hivm.hir.pointer_cast(%c83616_i64) : memref<128xf32, #hivm.address_space<ub>>
        hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID1>]
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vmul ins(%80, %expand_shape : memref<16x256xf32, #hivm.address_space<ub>>, memref<16x1xf32, #hivm.address_space<ub>>) outs(%82 : memref<16x256xf32, #hivm.address_space<ub>>) temp_buffer(%83 : memref<128xf32, #hivm.address_space<ub>>) broadcast = [1]
        %84 = hivm.hir.pointer_cast(%c67232_i64) : memref<16x256xf32, #hivm.address_space<ub>>
        %85 = hivm.hir.pointer_cast(%c84128_i64) : memref<128xf32, #hivm.address_space<ub>>
        hivm.hir.wait_flag[<PIPE_MTE2>, <PIPE_V>, <EVENT_ID2>]
        hivm.hir.vmul ins(%81, %expand_shape_13 : memref<16x256xf32, #hivm.address_space<ub>>, memref<16x1xf32, #hivm.address_space<ub>>) outs(%84 : memref<16x256xf32, #hivm.address_space<ub>>) temp_buffer(%85 : memref<128xf32, #hivm.address_space<ub>>) broadcast = [1]
        %86 = hivm.hir.pointer_cast(%c50848_i64) : memref<16x256xf32, #hivm.address_space<ub>>
        %collapse_shape_16 = memref.collapse_shape %82 [[0, 1]] : memref<16x256xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        %collapse_shape_17 = memref.collapse_shape %84 [[0, 1]] : memref<16x256xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        %collapse_shape_18 = memref.collapse_shape %86 [[0, 1]] : memref<16x256xf32, #hivm.address_space<ub>> into memref<4096xf32, #hivm.address_space<ub>>
        hivm.hir.pipe_barrier[<PIPE_V>]
        hivm.hir.vadd ins(%collapse_shape_16, %collapse_shape_17 : memref<4096xf32, #hivm.address_space<ub>>, memref<4096xf32, #hivm.address_space<ub>>) outs(%collapse_shape_18 : memref<4096xf32, #hivm.address_space<ub>>)
        hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
        hivm.hir.set_flag[<PIPE_V>, <PIPE_MTE3>, <EVENT_ID1>]
        hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE3>, <EVENT_ID1>]
        scf.if %24 {
          hivm.hir.store ins(%86 : memref<16x256xf32, #hivm.address_space<ub>>) outs(%reinterpret_cast_15 : memref<16x256xf32, strided<[?, 1], offset: ?>, #hivm.address_space<gm>>)
        } {limit_sub_block_id0}
        hivm.hir.set_flag[<PIPE_MTE3>, <PIPE_MTE2>, <EVENT_ID0>]
      }
      %75 = hivm.hir.pointer_cast(%c84640_i64) : memref<16xf32, #hivm.address_space<ub>>
      hivm.hir.copy ins(%66 : memref<16xf32, #hivm.address_space<ub>>) outs(%75 : memref<16xf32, #hivm.address_space<ub>>)
      scf.yield %75 : memref<16xf32, #hivm.address_space<ub>>
    }
  }
  hivm.hir.pipe_barrier[<PIPE_ALL>]
  hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_V>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_MTE3>, <PIPE_MTE2>, <EVENT_ID0>]
  hivm.hir.wait_flag[<PIPE_V>, <PIPE_MTE2>, <EVENT_ID1>]
  hivm.hir.sync_block_wait[<VECTOR>, <PIPE_MTE2>, <PIPE_S>] flag = 2
  return
}
