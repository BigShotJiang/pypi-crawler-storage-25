# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import json
import sys
import os

# Add project root to path
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../..'))
sys.path.insert(0, project_root)

from api.tile_op_api.tile_op_costmodel import tile_op_latency_predict_pypto


def main():
    example_input_path = './input_example.json'
    example_output_path = './output_example.json'

    with open(example_input_path, "r", encoding="utf-8") as f:
        tile_op_input_example = json.load(f)

    tile_op_output_dict = {}
    for tile_op_input_data in tile_op_input_example:
        result = tile_op_latency_predict_pypto(tile_op_input_data)
        tile_op_output_dict[f'OP_{len(tile_op_output_dict)}'] = result
        print(f"Processed {result.get('opcode', tile_op_input_data.get('opcode', 'unknown'))}: {result}")

    with open(example_output_path, "w", encoding="utf-8") as f:
        tile_op_output_json = json.dumps(
            tile_op_output_dict, indent=2, ensure_ascii=False
        )
        f.write(tile_op_output_json)

    print(f"\nResults written to {example_output_path}")


if __name__ == '__main__':
    main()