# SSA测试用例说明文档

## 概述

本文档描述了为tilesim项目中SSA（Static Single Assignment）实现构造的测试用例。这些测试覆盖了从DSL到IR再到Entity展开的完整流程中的SSA处理。

---

## 项目架构

```
DSL语法 --> IR表达 --> 未展开的后端Entity --> Optim分核排布 --> Eval展开 --> 时间计算
    |            |              |                    |              |           |
    v            v              v                    v              v           v
 IrBuilder     KernelIR  PhiFuncEntity         TaskQueue   LogisticEntity  SimEvent
  + SSAEnv
```

两次SSA相关的语言设计处理：
1. **DSL -> IR (前端)**: `core/frontend/dsl/parse/ir_builder_by_dsl.py` 中的 `IrBuilder` 和 `SSAEnv`
2. **Eval展开 (后端)**: `core/backend/backend_entity/backend_logistic.py` 中的 `LogisticEntity.expand()` 和 `EvalCtxEntity`

---

## 测试目录结构

```
tests/
├── ut/
│   ├── core/frontend/dsl/parse/
│   │   └── test_ir_ssa_parse.py           # 前端DSL到IR的SSA测试
│   └── core/backend/backend_entity/
│       ├── test_backend_entity_ssa_expand.py  # 后端Entity展开SSA测试
│       └── test_ir_to_entity_ssa.py           # IR到Entity转换SSA测试
└── st/ssa_integration/
    └── test_ssa_end_to_end.py             # 端到端SSA集成测试
```

---

## 测试用例详解

### 1. 前端DSL到IR的SSA测试 (`test_ir_ssa_parse.py`)

#### 1.1 顺序赋值测试 (`TestSSASequentialAssignment`)

**测试目的**: 验证简单的变量顺序赋值产生正确的版本号

**测试用例**:
- `test_simple_var_assignment`: 验证`x = 1; x = 2; x = 3`产生版本`x`, `x.1`, `x.2`
- `test_multiple_vars_independent`: 验证多个独立变量的版本管理互不影响

**预期行为**:
```
x = 1   -> x (version 0)
x = 2   -> x.1 (version 1)
x = 3   -> x.2 (version 2)
y = x   -> 使用x.2
```

#### 1.2 If语句测试 (`TestSSAIfStatement`)

**测试目的**: 验证if/else分支中变量被修改时Phi函数的正确生成

**测试用例**:
- `test_if_else_both_modify`: if和else都修改变量，需要Phi合并
- `test_if_one_branch_modify`: 只有if分支修改变量，仍需Phi
- `test_no_branch_modify`: 两分支都不修改变量，不需Phi

**预期行为**:
```python
x = 0           # x
if True:
    x = 1       # x.1
else:
    x = 2       # x.2
# 合并点需要: phi(x, x.1, x.2) -> x.3
```

#### 1.3 For循环测试 (`TestSSAForLoop`)

**测试目的**: 验证循环体内修改变量时的SSA处理

**测试用例**:
- `test_for_loop_var_not_modified`: 循环内不修改，无需Phi
- `test_for_loop_var_modified`: 循环内修改，需要Phi

**预期行为**:
```python
x = 0           # x
for i in range(5):
    x = i       # x.1
# 循环合并点需要: phi(x, x.1) -> x.2
```

#### 1.4 嵌套结构测试 (`TestSSANestedStructure`)

**测试目的**: 验证嵌套if/for结构中的SSA处理

**测试用例**:
- `test_nested_if_inside_if`: 嵌套if结构
- `test_for_inside_if`: if内嵌套for
- `test_if_inside_for`: for内嵌套if

#### 1.5 Task作用域测试 (`TestSSATaskScope`)

**测试目的**: 验证Task内的变量版本管理

---

### 2. 后端Entity展开SSA测试 (`test_backend_entity_ssa_expand.py`)

#### 2.1 版本绑定函数测试 (`TestBindVersion`)

**测试目的**: 验证`bind_version(name, version)`函数的正确性

**测试用例**:
- `test_bind_version_zero`: 版本0时返回原名
- `test_bind_version_positive`: 版本>0时返回`name.version`

#### 2.2 EvalCtxEntity版本管理测试 (`TestEvalCtxEntityVersionManagement`)

**测试目的**: 验证EvalCtxEntity的版本管理功能

**测试用例**:
- `test_initial_version`: 新变量初始版本为0
- `test_update_version`: 版本号正确更新
- `test_multiple_independent_vars`: 多变量独立版本管理
- `test_assign_env`: 环境变量赋值
- `test_assign_dict`: 批量赋值
- `test_create_tmp_ctx`: 创建临时context

#### 2.3 PhiFuncEntity测试 (`TestPhiFuncEntity`)

**测试目的**: 验证Phi函数实体的行为

**测试用例**:
- `test_phi_activate_simple`: 简单激活测试
- `test_phi_activate_multiple_scopes`: 多scope激活
- `test_phi_activate_invalid_scope`: 无效scope抛异常
- `test_phi_activate_empty_scope_referrers`: 空scope_referrers测试

#### 2.4 EvalCtxEntity与Phi集成测试 (`TestEvalCtxEntityWithPhi`)

**测试用例**:
- `test_get_merge_phi_name`: 通过Phi获取合并后的变量名
- `test_activate_phi`: activate_phi方法测试
- `test_no_phi_name`: 无Phi时直接返回变量名
- `test_activate_phi_multiple_phis_in_scope`: 一个scope多个Phi

#### 2.5 SSA回归测试 (`TestSSABugRegression`)

**测试目的**: 防止已知SSA问题的回归

**测试用例**:
- `test_phi_scope_referrer_consistency`: Phi的scope_referrer和referred_name一致性
- `test_phi_activation_before_use`: Phi使用前必须激活
- `test_context_version_isolation`: 临时context的版本共享行为

#### 2.6 SSA边界情况测试 (`TestSSACornerCases`)

**测试用例**:
- `test_empty_phi_referrers`: 空Phi引用
- `test_single_referrer_phi`: 单引用Phi
- `test_nested_scope_phis`: 嵌套scope多Phi

#### 2.7 SSA集成测试 (`TestSSAIntegrationWithVersions`)

**测试用例**:
- `test_version_and_phi_interaction`: 版本号与Phi交互
- `test_version_isolation_with_phi`: 带Phi的版本隔离

#### 2.8 SSA数据一致性测试 (`TestSSADataConsistency`)

**测试用例**:
- `test_version_counter_independence`: 版本计数器独立性

---

### 3. IR到Entity转换SSA测试 (`test_ir_to_entity_ssa.py`)

#### 3.1 Phi函数转换测试 (`TestPhiFuncConversion`)

**测试用例**:
- `test_phi_to_entity`: 单个Phi转换
- `test_phi_to_entity_empty_scope_referrers`: 空scope_referrers转换
- `test_multiple_phis_convert`: 多Phi转换

#### 3.2 BackendEntity构建测试 (`TestBackendEntityBuild`)

**测试用例**:
- `test_build_with_phi_dict`: 带Phi字典的构建
- `test_build_with_empty_phi_dict`: 空Phi字典构建
- `test_build_with_task_and_phi`: Task和Phi共存构建

#### 3.3 Phi Scope一致性测试 (`TestPhiScopeConsistency`)

**测试用例**:
- `test_phi_scope_mapping`: Phi在phi_func_by_scope中的正确索引

#### 3.4 Task中Phi测试 (`TestPhiWithTaskIRBody`)

**测试用例**:
- `test_task_phi_preservation`: TaskIR中Phi函数保留

#### 3.5 Phi激活集成测试 (`TestPhiEntityActivateIntegration`)

**测试用例**:
- `test_phi_activate_in_backend_entity`: BackendEntity中的Phi激活

---

### 4. 端到端SSA集成测试 (`test_ssa_end_to_end.py`)

**测试目的**: 验证从DSL到Entity到Expand的完整流程

**测试用例**:
- `test_dsl_to_ir_ssa_simple`: DSL到IR的简单SSA
- `test_dsl_to_ir_if_phi`: if语句Phi生成
- `test_ir_to_entity_to_expand`: IR到Entity到Expand流程
- `test_phi_in_expand_flow`: Expand流程中Phi处理
- `test_version_preservation_across_stages`: 跨阶段版本保持

#### 回归测试 (`TestSSABugRegression`)
- `test_phi_scope_referrer_consistency`
- `test_phi_activation_before_use`
- `test_context_version_isolation`

---

## 关键SSA概念与代码实现

### Phi函数结构

```python
@dataclass
class PhiFuncEntity:
    id: str                        # Phi函数唯一标识
    result_name: str              # 合并后的变量名
    referred_name: list[str]      # 要合并的变量版本列表
    activated_name: str = None    # 当前激活的版本
    scope_referrers: dict[str, str]  # scope_id -> referred_name映射
```

### EvalCtxEntity版本管理

```python
@dataclass
class EvalCtxEntity:
    env: dict[str, int | float | bool]          # 变量到值的映射
    version_manager: dict[str, int]             # 变量到版本号的映射
    phi_func_by_scope: dict[str, list[PhiFuncEntity]]  # scope到Phi列表
    phi_func_by_name: dict[str, PhiFuncEntity]  # 变量名到Phi的映射
```

### 关键方法

- `bind_version(name, version)`: 将变量名和版本号绑定
- `activate_phi(scope_id)`: 根据scope_id激活对应的Phi函数
- `_get_merge_phi_name(name)`: 获取变量名经过Phi合并后的实际名称

---

## 重要发现

1. **create_tmp_ctx的行为**:
   - `env`: 使用`copy()`浅拷贝字典
   - `version_manager`: 直接引用（不拷贝）
   - `phi_func_by_scope`: 不传递，使用默认空字典
   - `phi_func_by_name`: 不传递，使用默认空字典

2. **Phi激活特性**:
   - Phi对象的`activated_name`是共享状态
   - 在一个context中激活会影响其他共享该Phi对象的context
   - Phi必须在`_get_merge_phi_name`调用前激活

3. **版本号作用域**:
   - 由于`version_manager`直接引用，临时context的版本修改会污染原context
   - 这是当前实现的特性，使用时需要注意

---

## 运行测试

```bash
# 运行所有SSA测试
python -m pytest tests/ut/core/frontend/dsl/parse/test_ir_ssa_parse.py -v
python -m pytest tests/ut/core/backend/backend_entity/test_backend_entity_ssa_expand.py -v
python -m pytest tests/ut/core/backend/backend_entity/test_ir_to_entity_ssa.py -v

# 运行集成测试
python -m pytest tests/st/ssa_integration/test_ssa_end_to_end.py -v
```

---

## 注意事项

1. 由于`core/backend/tile_op_costmodel`和`core/backend/engineering_costmodel`存在循环导入，某些测试文件使用了延迟导入或skip机制。
2. 测试用例基于对代码实现的理解编写，如果代码行为改变，测试用例可能需要相应更新。
3. 当前实现中`create_tmp_ctx`的引用共享行为是需要注意的设计决策点。

---

## 未来扩展

如果需要更全面的SSA测试，可以考虑添加：

1. 真实算子（如matmul）的端到端SSA验证
2. 更复杂的嵌套控制流结构的测试
3. 边界条件测试：极大/极小的版本号
4. 性能测试：大规模Phi函数的处理效率