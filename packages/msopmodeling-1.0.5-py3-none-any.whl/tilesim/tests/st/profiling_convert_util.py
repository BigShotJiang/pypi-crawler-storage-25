# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import ast
from enum import Enum

from pandas import Series


class ProfilingDataFormat(Enum):
    ZHANLU = 'zhanlu'
    MSPROF = 'msprof'
    ZHANLU_PROF = 'zhanlu_prof'
    SGLANG_PROF = "sglang_prof"


def _shape_convert(shapes: str) -> list[list[int]]:
    if not isinstance(shapes, str):
        return []
    shape_list = []
    shapes = shapes.strip().replace('"', '')
    for shape in shapes.split(';'):
        if shape == '':
            shape_list.append([])
        else:
            shape_list.append([int(x) for x in shape.split(',')])
    return shape_list


def _dtype_convert(dtype: str) -> list[str]:
    if not isinstance(dtype, str):
        return []
    dtype_list = []
    dtype = dtype.strip().replace('"', '')
    for dtype_str in dtype.split(';'):
        dtype_list.append(dtype_str.strip())
    return dtype_list


def _dtype_convert_torch_format(dtype: str) -> list[str]:
    dtype_list = ast.literal_eval(dtype)
    ret = []
    for dtype_i in dtype_list:
        if "CustomDType" in dtype_i:
            start = dtype_i.find("dtype='") + len("dtype='")
            end = dtype_i.find("'", start)
            dtype_i = dtype_i[start:end]
        else:
            dtype_i = dtype_i.replace("torch.", "")
        ret.append(dtype_i.strip().upper())
    return ret


def _str_convert(input_str: str):
    if input_str is None or input_str.strip() == '':
        return None
    else:
        return ast.literal_eval(input_str)


def _get_zhanlu_format(row: Series) -> dict:
    parameters_input = row.get('parameters_input', '')
    parameters_input_list = _str_convert(parameters_input)
    extra_param = None
    if parameters_input_list is not None:
        for item in parameters_input_list:
            if isinstance(item, dict):
                extra_param = item
                break
    if extra_param is None:
        extra_param = _str_convert(row.get('extra_param', row.get('tilesim_extra_param')))
    return {
        'op_name': row['kernel_type'],
        'input_shapes': _str_convert(row['inputs_shape']),
        'output_shapes': _str_convert(row['outputs_shape']),
        'input_precision': _dtype_convert_torch_format(row['inputs_dtype']),
        'output_precision': _dtype_convert_torch_format(row['outputs_dtype']),
        'block_dim': row['block_dim'],
        'profiling_time': row['profiling_time'],
        'parameters_input': parameters_input,
        'extra_param': extra_param
    }


def _get_zhanlu_prof_format(row: Series) -> dict:
    input_dtypes = _dtype_convert(row['Input Data Types'])
    output_dtypes = _dtype_convert(row['Output Data Types'])

    if row['HF32 Eligible'] == 'YES':
        input_len = len(input_dtypes)
        for idx in range(input_len):
            if input_dtypes[idx] == 'FP32' or input_dtypes[idx] == 'FLOAT':
                input_dtypes[idx] = 'HF32'
        output_len = len(output_dtypes)
        for idx in range(output_len):
            if output_dtypes[idx] == 'FP32' or output_dtypes[idx] == 'FLOAT':
                output_dtypes[idx] = 'HF32'

    res = {
        'op_name': row['Type'],
        'input_shapes': _shape_convert(row['Input Shapes']),
        'output_shapes': _shape_convert(row['Output Shapes']),
        'input_precision': input_dtypes,
        'output_precision': output_dtypes,
        'block_dim': row['Block Dim'],
        'profiling_time': row['Duration(us)']
    }
    return res


def _get_msprof_format(row: Series) -> dict:
    input_dtypes = _dtype_convert(row['Input Data Types'])
    output_dtypes = _dtype_convert(row['Output Data Types'])

    if row['HF32 Eligible'] == 'YES':
        input_len = len(input_dtypes)
        for idx in range(input_len):
            if input_dtypes[idx] == 'FP32' or input_dtypes[idx] == 'FLOAT':
                input_dtypes[idx] = 'HF32'
        output_len = len(output_dtypes)
        for idx in range(output_len):
            if output_dtypes[idx] == 'FP32' or output_dtypes[idx] == 'FLOAT':
                output_dtypes[idx] = 'HF32'

    res = {
        'op_name': row.get('OP Type', row.get('Type')),
        'input_shapes': _shape_convert(row['Input Shapes']),
        'output_shapes': _shape_convert(row['Output Shapes']),
        'input_precision': input_dtypes,
        'output_precision': output_dtypes,
        'block_dim': row['Block Dim'],
        'profiling_time': row.get('Task Duration(us)', row.get('Duration(us)'))
    }

    return res


def _get_sglang_prof_format(row: Series) -> dict:
    input_dtypes = _dtype_convert(row['Input Data Types'])
    output_dtypes = _dtype_convert(row['Output Data Types'])

    if row['HF32 Eligible'] == 'YES':
        input_len = len(input_dtypes)
        for idx in range(input_len):
            if input_dtypes[idx] == 'FP32' or input_dtypes[idx] == 'FLOAT':
                input_dtypes[idx] = 'HF32'
        output_len = len(output_dtypes)
        for idx in range(output_len):
            if output_dtypes[idx] == 'FP32' or output_dtypes[idx] == 'FLOAT':
                output_dtypes[idx] = 'HF32'

    res = {
        'op_name': row['Type'],
        'input_shapes': _shape_convert(row['Input Shapes']),
        'output_shapes': _shape_convert(row['Output Shapes']),
        'input_precision': input_dtypes,
        'output_precision': output_dtypes,
        'block_dim': row['Block Dim'],
        'profiling_time': row['Duration(us)']
    }

    return res


def get_profiling_data(row: Series, profiling_format: ProfilingDataFormat) -> dict:
    if profiling_format == ProfilingDataFormat.ZHANLU:
        profiling_data = _get_zhanlu_format(row)
    elif profiling_format == ProfilingDataFormat.MSPROF:
        profiling_data = _get_msprof_format(row)
    elif profiling_format == ProfilingDataFormat.ZHANLU_PROF:
        profiling_data = _get_zhanlu_prof_format(row)
    elif profiling_format == ProfilingDataFormat.SGLANG_PROF:
        profiling_data = _get_sglang_prof_format(row)
    else:
        raise ValueError(f'不支持的采集数据格式: {profiling_format}')

    return profiling_data
