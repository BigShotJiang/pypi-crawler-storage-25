# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

import pandas as pd

from api.operator_api.models.operator_api_models import OperatorPredictRequest
from api.operator_api.op_latency_predict import op_latency_predict as dsl_predict
from api.operator_api.op_latency_predict_engineering import op_latency_predict as classic_predict
from core.common import BackendType
from tests.st.profiling_convert_util import ProfilingDataFormat, get_profiling_data


def _run_predict(prof, accelerator_config_path, enable_fit: bool, backend_type: BackendType = BackendType.THEO):
    op_input = OperatorPredictRequest(op_name=prof['op_name'],
                                      input_shapes=prof['input_shapes'],
                                      output_shapes=prof['output_shapes'],
                                      input_precision=prof['input_precision'],
                                      output_precision=prof['output_precision'],
                                      accelerator=accelerator_config_path,
                                      core_num=prof['block_dim'],
                                      extra_param=prof.get('extra_param'))

    if enable_fit:
        if op_input.extra_param is None:
            op_input.extra_param = {}
        op_input.extra_param['enable_fit'] = True

    if backend_type == BackendType.THEO:
        op_input.backend_type = backend_type.value

    if backend_type == BackendType.ENG_CLASSIC:
        op_output = classic_predict(op_input)
    else:
        op_output = dsl_predict(op_input)
    return op_output


def operator_check(accelerator: str,
                   profiling_file_path: str,
                   accuracy_required: float,
                   accumulate_accuracy: bool = False,
                   enable_fit: bool = False,
                   backend_type: BackendType = BackendType.THEO,
                   profiling_format: ProfilingDataFormat = ProfilingDataFormat.ZHANLU):
    """理论极限、工程可达、旧版工程可达通用的st入口"""
    df = pd.read_csv(profiling_file_path)
    profiling_total = 0
    predict_total = 0
    accelerator_config_path = f"../../../../../core/config/arc_config/{accelerator}/{accelerator}.yaml"
    case_cache = {}
    print()
    for index, row in df.iterrows():
        prof = get_profiling_data(row, profiling_format)
        op_name = prof['op_name']
        input_shapes = prof['input_shapes']
        output_shapes = prof['output_shapes']
        input_precision = prof['input_precision']
        output_precision = prof['output_precision']
        block_dim = prof['block_dim']
        profiling_time = prof['profiling_time']
        parameters_input = prof.get('parameters_input', '')

        # 计算时间
        key = f'{op_name}_{input_shapes}_{output_shapes}_{input_precision}_{output_precision}_{block_dim}_{parameters_input}'
        if key in case_cache:
            op_output = case_cache[key]
        else:
            op_output = _run_predict(prof, accelerator_config_path, enable_fit, backend_type)
            case_cache[key] = op_output
        latency = op_output.get('latency')
        assert latency is not None
        # 如果没有开启系数拟合，则表示一定是理论极限
        if not enable_fit and backend_type == BackendType.THEO:
            assert latency < profiling_time, f'latency不满足理论极限，predict = {latency}, real = {profiling_time}'

        # 计算相对精度和绝对精度
        accuracy = 1 - abs(latency - profiling_time) / profiling_time
        absolute_accuracy = latency / profiling_time
        print(f'index = {index}, '
              f'op_name = {op_name}, '
              f'accuracy = {round(accuracy * 100, 2)}%, '
              f'absolute_accuracy = {round(absolute_accuracy * 100, 2)}%, '
              f'predict_latency = {round(latency, 2)}, '
              f'profiling = {round(profiling_time, 2)}, '
              f'input_shapes = {input_shapes}, '
              f'block_dim = {block_dim}')

        if not accumulate_accuracy:
            assert accuracy > accuracy_required

        profiling_total += profiling_time
        predict_total += latency

    # 累计精度比较
    if accumulate_accuracy:
        accumulate_accuracy = 1 - abs(predict_total - profiling_total) / profiling_total
        print(f'accumulate_accuracy = {round(accumulate_accuracy * 100, 2)}%')
        assert accumulate_accuracy > accuracy_required
