# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

from tests.st.ops_accuracy.eng_ops_classic.eng_classic_ops_test_util import eng_classic_operator_check


def test_dynamic_quant_zhanlu_910B4_1():
    accelerator = '910B4-1'
    profiling_path = f'dynamicquant_zhanlu_profiling_910B4_1.csv'
    eng_classic_operator_check(accelerator, profiling_path, accuracy_required=0.80, accumulate_accuracy=True)


def test_dynamic_quant_deekseek_v3_quant_decode_910B4_1():
    accelerator = '910B4-1'
    profiling_path = f'dynamicquant_deekseek_v3_quant_decode_910B4_1.csv'
    eng_classic_operator_check(accelerator, profiling_path, accuracy_required=0.68, accumulate_accuracy=True)
