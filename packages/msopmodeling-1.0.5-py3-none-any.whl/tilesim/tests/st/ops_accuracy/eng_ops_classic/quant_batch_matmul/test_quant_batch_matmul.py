# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from tests.st.ops_accuracy.eng_ops_classic.eng_classic_ops_test_util import eng_classic_operator_check
from tests.st.profiling_convert_util import ProfilingDataFormat


def test_qbmm_zhanlu_data_bad_case_910B4():
    accelerator = '910B4'
    profiling_path = f'qbmm_prefill_case_from_zhanlu_bad_case_910B4.csv'
    eng_classic_operator_check(accelerator, profiling_path, accuracy_required=0.60, accumulate_accuracy=False)


def test_qbmm_zhanlu_data_good_case_910B4():
    accelerator = '910B4'
    profiling_path = f'qbmm_prefill_case_from_zhanlu_good_case_910B4.csv'
    eng_classic_operator_check(accelerator, profiling_path, accuracy_required=0.74, accumulate_accuracy=False)


def test_qbmm_zhanlu_data_910B4_1():
    accelerator = '910B4-1'
    profiling_path = f'quantbatchmatmulv3_zhanlu_profiling_910B4_1.csv'
    eng_classic_operator_check(accelerator, profiling_path, accuracy_required=0.83, accumulate_accuracy=True)


def test_qbmm_zhanlu_data_910B1():
    accelerator = '910B1'
    profiling_path = f'quantbatchmatmulv3_dpsk_v4_decode_zhanlu_profiling_910B1.csv'
    eng_classic_operator_check(accelerator, profiling_path, accuracy_required=0.89, accumulate_accuracy=True)


def test_qbmm_dsv4_910B1():
    accelerator = '910B1'
    profiling_path = f'qbmm_dsv4_multi_batch.csv'
    eng_classic_operator_check(accelerator, profiling_path, accuracy_required=0.90, accumulate_accuracy=True,
                               profiling_format=ProfilingDataFormat.MSPROF)
