# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

from tests.st.ops_accuracy.eng_ops_classic.eng_classic_ops_test_util import eng_classic_operator_check


def test_sparseflashattention_zhanlu_910B4_1():
    accelerator = '910B4-1'
    profiling_path = f'sparseflashattention_zhanlu_profiling_910B4_1.csv'
    eng_classic_operator_check(accelerator, profiling_path, accuracy_required=0.90, accumulate_accuracy=True)


def test_sparseflashattention_command_optimized_deepseekv3_bf16_001_910B4_1():
    accelerator = '910B4-1'
    profiling_path = f'sparseflashattention_command_optimized_deepseekv3.2_bf16_001_910B4_1.csv'
    eng_classic_operator_check(accelerator, profiling_path, accuracy_required=0.90, accumulate_accuracy=True)
