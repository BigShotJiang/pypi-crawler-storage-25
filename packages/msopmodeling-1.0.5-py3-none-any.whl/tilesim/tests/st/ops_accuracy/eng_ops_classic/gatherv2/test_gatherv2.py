# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import pandas as pd
import ast
from api.operator_api.models.operator_api_models import OperatorPredictRequest
from api.operator_api.op_latency_predict_engineering import op_latency_predict


def test_gatherv2_zhanlu_910B1():
    accelerator = '910B1'
    profiling_path = f'gather_profiling_910B1.csv'
    eng_operator_accuracy_check_gather(accelerator, profiling_path, accuracy_required=0.63, accumulate_accuracy=True)


def eng_operator_accuracy_check_gather(accelerator: str, profiling_file_path: str, accuracy_required: float,
                                       accumulate_accuracy: bool = False):
    """工程latency精度回归测试，适配GatherV2专用格式"""
    df = pd.read_csv(profiling_file_path)
    accelerator_config_path = f"../../../../../core/config/arc_config/{accelerator}/{accelerator}.yaml"

    case_cache = {}
    for index, row in df.iterrows():
        # 1. 固定 op_name
        op_name = "GatherV2"

        # 2. 合并 selfshape 和 indexshape
        dim_val = row.get('dim', 0)
        input_shapes = [
            list(ast.literal_eval(str(row['selfshape']))),
            list(ast.literal_eval(str(row['indexshape']))),
            [int(dim_val)]  # dim 也包装成列表，对应 shapes[2][0]
        ]

        # 3. 提取 Block_Dim 和 实际耗时 (这里暂取 MTE2，你可以根据业务逻辑修改)
        block_dim = row['Block_Dim']
        actual_latency = row['Avg_MTE2_Time'] + row['Avg_MTE3_Time']
        input_dtype = row.get('input_dtype')
        output_dtype = row.get('output_dtype')
        input_precision = input_dtype if pd.notna(input_dtype) else ["BF16"]
        output_precision = output_dtype if pd.notna(output_dtype) else ["BF16"]
        # 4. 构建缓存 Key
        key = f'{op_name}_{input_shapes}_{block_dim}'

        if key in case_cache:
            op_output = case_cache[key]
        else:
            op_input = OperatorPredictRequest(
                op_name=op_name,
                input_shapes=input_shapes,
                output_shapes=[],  # 如果预测函数需要，请补充计算逻辑
                input_precision=input_precision,  # 默认精度，若CSV有此列请替换
                output_precision=output_precision,
                accelerator=accelerator_config_path,
                core_num=block_dim
            )
            op_output = op_latency_predict(op_input)
            case_cache[key] = op_output
        latency = op_output.get('latency')
        assert latency is not None
        # 5. 精度计算与填充
        df.loc[index, 'predict_latency'] = latency
        accuracy = 1 - abs(latency - actual_latency) / actual_latency
        df.loc[index, 'accuracy'] = accuracy

        print(f'index = {index}, accuracy = {round(accuracy * 100, 2)}%, '
              f'predict = {round(latency, 2)}, actual = {round(actual_latency, 2)}')

        if not accumulate_accuracy:
            assert accuracy > accuracy_required

    if accumulate_accuracy:
        total_actual = df['Avg_MTE2_Time'].sum()
        total_predict = df['predict_latency'].sum()
        acc_accuracy = 1 - abs(total_predict - total_actual) / total_actual
        print(f'--- Final Accumulate Accuracy = {round(acc_accuracy * 100, 2)}% ---')
        assert acc_accuracy > accuracy_required


if __name__ == "__main__":
    test_gatherv2_zhanlu_910B1()
