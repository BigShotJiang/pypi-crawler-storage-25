# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

from tests.st.ops_accuracy.eng_ops_classic.eng_classic_ops_test_util import eng_classic_operator_check


def test_gmm_dpsk_v4_a3_decode():
    accelerator = '910B1'
    profiling_path = f'groupedmatmul_dpsk-v4-a3_zhanlu_profiling_910B1.csv'
    eng_classic_operator_check(accelerator, profiling_path, accuracy_required=0.87, accumulate_accuracy=True)


def test_gmm_command_optimized_deepseek_v3_2_bf16_009_prefill():
    accelerator = '910B4-1'
    profiling_path = f'groupedmatmul_command_optimized_deepseekv3.2_bf16_009_prefill_910B4_1.csv'
    eng_classic_operator_check(accelerator, profiling_path, accuracy_required=0.95, accumulate_accuracy=True)


def test_gmm_command_optimized_deepseek_and_v3_2_bf16_decode():
    accelerator = '910B4-1'
    profiling_path = f'groupedmatmul_command_optimized_deepseek_and_v3.2_bf16_decode_910B4_1.csv'
    eng_classic_operator_check(accelerator, profiling_path, accuracy_required=0.99, accumulate_accuracy=True)


def test_gmm_deepseek_v3_quant_decode_910B4_1():
    accelerator = '910B4-1'
    profiling_path = f'groupedmatmul_deepseek_v3_quant_decode_910B4_1.csv'
    eng_classic_operator_check(accelerator, profiling_path, accuracy_required=0.84, accumulate_accuracy=True)
