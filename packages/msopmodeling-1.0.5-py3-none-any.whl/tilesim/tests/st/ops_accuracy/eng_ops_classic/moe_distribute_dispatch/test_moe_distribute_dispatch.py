# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

from tests.st.ops_accuracy.eng_ops_classic.eng_classic_ops_test_util import eng_classic_operator_check


def test_moe_distribute_dispatchv2_zhanlu_910B1():
    accelerator = '910B1'
    profiling_path = f'moe_distribute_dispatchv2_dpsk-v4-a3_zhanlu_profiling_910B1.csv'
    eng_classic_operator_check(accelerator, profiling_path, accuracy_required=0.96, accumulate_accuracy=True)
