# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

from tests.st.ops_accuracy.eng_ops_classic.eng_classic_ops_test_util import eng_classic_operator_check


def test_ring_mla_prefill_bf16_kernel_zhanlu_deepseekv3_2_bf16_prefill_910B4_1():
    accelerator = '910B4-1'
    profiling_path = f'ring_mla_prefill_bf16_kernel_zhanlu_deepseekv3.2_bf16_910B4_1.csv'
    eng_classic_operator_check(accelerator, profiling_path, accuracy_required=0.48, accumulate_accuracy=True)
