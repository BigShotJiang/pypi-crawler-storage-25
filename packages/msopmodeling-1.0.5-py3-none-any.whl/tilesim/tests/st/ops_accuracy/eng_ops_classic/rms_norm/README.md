# 1. 输入格式
输入格式要求：输入数据固定为2个，其中第一个输入任意维数，后一个输入固定一维。
要求input[0].shape[-1] == input[1].shape[0]。

# 2. 精度说明
# 2.1 shape覆盖
基于：
Deepseek-v3-no-quant
Deepseek-v3-w8a8c8
Deepseek-v3.2
Qwen3-VL-MoE-image
Qwen3-VL-MoE-video
Qwen3Nex
的模型采集的相关RmsNorm数据
总体累计精度 约为95% ，shape较小的时候误差较大

# 2.2 微架构覆盖
覆盖910B4_1平台
