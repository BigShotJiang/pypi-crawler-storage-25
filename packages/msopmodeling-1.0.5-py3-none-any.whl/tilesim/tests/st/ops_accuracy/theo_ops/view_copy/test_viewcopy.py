# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from tests.st.ops_accuracy.theo_ops.theo_ops_test_util import theo_operator_check


def test_viewcopy_zhanlu_910B1():
    accelerator = '910B1'
    profiling_path = f'viewcopy_dpsk-v4-a3_zhanlu_profiling_910B1.csv'
    theo_operator_check(accelerator, profiling_path, accuracy_required=0.02, accumulate_accuracy=True, enable_fit=False)


def test_viewcopy_zhanlu_910B1_fit():
    accelerator = '910B1'
    profiling_path = f'viewcopy_dpsk-v4-a3_zhanlu_profiling_910B1.csv'
    theo_operator_check(accelerator, profiling_path, accuracy_required=0.90, accumulate_accuracy=True, enable_fit=True)


def test_viewcopy_command_optimized_qwen3vl_moe_image_001_output_forward_0000_910B4_1_fit():
    accelerator = '910B4-1'
    profiling_path = f'viewcopy_command_optimized_qwen3vl_moe_image_001_output-forward-0000_910B4-1.csv'
    theo_operator_check(accelerator, profiling_path, accuracy_required=0.90, accumulate_accuracy=True, enable_fit=True)
