# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from tests.st.ops_accuracy.theo_ops.theo_ops_test_util import theo_operator_check


def test_add_zhanlu_910B4_1_theo():
    accelerator = '910B4-1'
    profiling_path = f'add_zhanlu_profiling_910B4_1.csv'
    theo_operator_check(accelerator, profiling_path, accuracy_required=0.46, accumulate_accuracy=True)


def test_add_zhanlu_910B4_fit():
    accelerator = '910B4-1'
    profiling_path = f'add_zhanlu_profiling_910B4_1.csv'
    theo_operator_check(accelerator, profiling_path, accuracy_required=0.98, accumulate_accuracy=True, enable_fit=True)
