# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from tests.st.ops_accuracy.theo_ops.theo_ops_test_util import theo_operator_check
from tests.st.profiling_convert_util import ProfilingDataFormat


def test_swiglu_910B1():
    accelerator = '910B1'
    profiling_path = f'swiglu.csv'
    theo_operator_check(accelerator, profiling_path, accuracy_required=0.049, accumulate_accuracy=True,
                        enable_fit=False, profiling_format=ProfilingDataFormat.SGLANG_PROF)


def test_swiglu_910B1_fit():
    accelerator = '910B1'
    profiling_path = f'swiglu.csv'
    theo_operator_check(accelerator, profiling_path, accuracy_required=0.95, accumulate_accuracy=True,
                        enable_fit=True, profiling_format=ProfilingDataFormat.SGLANG_PROF)


def test_swiglu_command_optimized_deepseek_bf16_016_910B4_1():
    accelerator = '910B4-1'
    profiling_path = f'swiglu_command_optimized_deepseek_bf16_016_910B4-1.csv'
    theo_operator_check(accelerator, profiling_path, accuracy_required=0.72, accumulate_accuracy=True, enable_fit=False)


def test_swiglu_command_optimized_deepseek_bf16_016_910B4_1_fit():
    accelerator = '910B4-1'
    profiling_path = f'swiglu_command_optimized_deepseek_bf16_016_910B4-1.csv'
    theo_operator_check(accelerator, profiling_path, accuracy_required=0.95, accumulate_accuracy=True, enable_fit=True)


def test_swiglu_command_optimized_deepseek_and_3_2_bf16_decode_910B4_1_fit():
    accelerator = '910B4-1'
    profiling_path = f'swiglu_command_optimized_deepseek_and_3_2_bf16_decode_910B4-1.csv'
    theo_operator_check(accelerator, profiling_path, accuracy_required=0.66, accumulate_accuracy=True, enable_fit=True)
