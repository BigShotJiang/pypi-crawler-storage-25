# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
from tests.st.profiling_convert_util import ProfilingDataFormat
from tests.st.ops_accuracy.theo_ops.theo_ops_test_util import theo_operator_check


def test_dtypecast_zhanlu_910B1():
    accelerator = '910B1'
    profiling_path = f'dtypecast_dpsk-v4-a3_zhanlu_profiling_910B1.csv'
    theo_operator_check(accelerator, profiling_path, accuracy_required=0.30, accumulate_accuracy=True,
                        enable_fit=False)


def test_dtypecast_zhanlu_910B1_fit():
    accelerator = '910B1'
    profiling_path = f'dtypecast_dpsk-v4-a3_zhanlu_profiling_910B1.csv'
    theo_operator_check(accelerator, profiling_path, accuracy_required=0.94, accumulate_accuracy=True,
                        enable_fit=True)


def test_cast_zhanlu_910B1():
    accelerator = '910B1'
    profiling_path = f'cast_dpsk-v4-a3_zhanlu_profiling_910B1.csv'
    theo_operator_check(accelerator, profiling_path, accuracy_required=0.05, accumulate_accuracy=True,
                        enable_fit=False, profiling_format=ProfilingDataFormat.ZHANLU_PROF)


def test_cast_zhanlu_910B1_fit():
    accelerator = '910B1'
    profiling_path = f'cast_dpsk-v4-a3_zhanlu_profiling_910B1.csv'  # profiling同样的输入输出，耗时差别很大
    theo_operator_check(accelerator, profiling_path, accuracy_required=0.20, accumulate_accuracy=True,
                        enable_fit=True, profiling_format=ProfilingDataFormat.ZHANLU_PROF)
