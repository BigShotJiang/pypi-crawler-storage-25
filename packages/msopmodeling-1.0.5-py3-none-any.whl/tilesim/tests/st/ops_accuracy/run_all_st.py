import os
import sys
import subprocess


def run_all_test_cases(test_directory):
    root_dir = os.path.dirname(os.path.abspath(__file__))
    test_dir = os.path.join(root_dir, test_directory)
    print(f"开始使用pytest执行A文件夹下所有测试用例，根目录：{root_dir}\n")

    # 记录总体执行状态
    total_folders = 0
    failed_folders = []

    for item in os.listdir(test_dir):
        item_path = os.path.join(test_dir, item)
        if os.path.isdir(item_path):
            total_folders += 1
            print(f"===== 开始处理文件夹: {item} =====")

            py_files = [f for f in os.listdir(item_path) if f.endswith('.py') and not f.startswith('__')]
            if not py_files:
                print(f"文件夹 {item} 中未找到Python测试文件，跳过")
                continue

            # 保存当前工作目录，执行完后恢复
            original_cwd = os.getcwd()
            try:
                os.chdir(item_path)
                # -v: 详细输出 -s: 显示print输出 --tb=short: 简化错误栈信息
                pytest_cmd = [
                                 sys.executable, "-m", "pytest",
                                 "-v", "--tb=short"
                             ] + py_files

                print(f"执行pytest命令: {' '.join(pytest_cmd)}")
                print("-" * 50)

                # 执行pytest命令（实时输出，不捕获）
                result = subprocess.run(
                    pytest_cmd,
                    check=False,  # 不抛出异常，手动处理返回码
                    encoding='utf-8'
                )

                print("-" * 50)
                # 记录执行结果
                if result.returncode == 0:
                    print(f"文件夹 {item} 测试用例全部通过！")
                else:
                    print(f"文件夹 {item} 测试用例执行失败，返回码: {result.returncode}")
                    failed_folders.append(item)

            except Exception as e:
                print(f"执行文件夹 {item} 测试用例时出错: {str(e)}")
                failed_folders.append(item)
            finally:
                # 恢复原工作目录
                os.chdir(original_cwd)

            print(f"===== 结束处理文件夹: {item} =====\n")

    # 输出汇总报告
    print("=" * 60)
    print("测试执行汇总")
    print(f"总共处理文件夹数: {total_folders}")
    print(f"执行成功的文件夹数: {total_folders - len(failed_folders)}")
    print(f"执行失败的文件夹数: {len(failed_folders)}")
    if failed_folders:
        print(f"失败的文件夹列表: {', '.join(failed_folders)}")
    print("所有测试文件夹执行完成！")


if __name__ == "__main__":
    test_directory = "theo_ops"  # eng_ops_classic 或者 theo_ops
    run_all_test_cases(test_directory)
