# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

from tests.st.model_accuracy.model_accuracy_st_util import model_check
from tests.st.profiling_convert_util import ProfilingDataFormat


def test_command_optimized_deepseek_bf16_016_zhanlu_910B4_1():
    accelerator = '910B4-1'
    profiling_path = f'output-forward-0000.csv'
    model_check(accelerator, profiling_path, accuracy_required=0.80, profiling_format=ProfilingDataFormat.ZHANLU)


def test_command_optimized_deepseek_bf16_016_zhanlu_910B4_1_GroupedMatmul():
    accelerator = '910B4-1'
    profiling_path = f'output-forward-0000.csv'
    model_check(accelerator, profiling_path, accuracy_required=0.80, profiling_format=ProfilingDataFormat.ZHANLU,
                op_type_for_test='GroupedMatmul', verbose=True)
