# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import pandas as pd

from api.tile_op_api.tile_op_costmodel import tile_op_latency_predict_pypto

def _shape_convert(shape: str) -> list[int]:
    if not isinstance(shape, str):
        return []
    shape = shape.strip().replace('"', '').replace("[", "").replace("]", "")
    return [int(x) for x in shape.split(',')]

def tile_op_check(
        profiling_file_path: str,
        test_case_file_path: str,
        accuracy_required: float,
        accelerator: str = None,
):
    test_case_df = pd.read_csv(test_case_file_path)
    result_df = pd.read_csv(profiling_file_path)
    # profiling level_1_predict 列转成float类型

    comp_res = []
    test_case_dict = {}
    for index, row in test_case_df.iterrows():
        data = {
            "magic": row["magic"],
            "opcode": row["opcode"].upper(),
            "iOperand": [
                {
                    "magic": row["i_operand_0_magic"],
                    "rawMagic": row["i_operand_0_raw_magic"],
                    "shape": _shape_convert(row["i_operand_0_shape"]),
                    "rawShape": _shape_convert(row["i_operand_0_raw_shape"]),
                    "dataTypeStr": row["i_operand_0_data_type_str"],
                    "bufferType": row["i_operand_0_buffer_type"],
                    "offset": _shape_convert(row["i_operand_0_offset"]),
                },
                {
                    "magic": row["i_operand_1_magic"],
                    "rawMagic": row["i_operand_1_raw_magic"],
                    "shape": _shape_convert(row["i_operand_1_shape"]),
                    "rawShape": _shape_convert(row["i_operand_1_raw_shape"]),
                    "dataTypeStr": row["i_operand_1_data_type_str"],
                    "bufferType": row["i_operand_1_buffer_type"],
                    "offset": _shape_convert(row["i_operand_1_offset"]),
                }
            ],
            "oOperand": [{
                    "magic": row["i_operand_0_magic"],
                    "rawMagic": row["i_operand_0_raw_magic"],
                    "shape": _shape_convert(row["i_operand_0_shape"]),
                    "rawShape": _shape_convert(row["i_operand_0_raw_shape"]),
                    "dataTypeStr": row["i_operand_0_data_type_str"],
                    "bufferType": row["i_operand_0_buffer_type"],
                    "offset": _shape_convert(row["i_operand_0_offset"]),
                }]
        }

        test_case_dict[row["test_case"]] = data

    for index, row in result_df.iterrows():
        test_case = row["test_case"]

        if test_case not in test_case_dict:
            continue
        data = test_case_dict[test_case]
        op1_shape = data["iOperand"][0]["shape"]
        res = tile_op_latency_predict_pypto(data)
        tile_sim_res = res["latency"]

        tile_sim_accuracy = 0
        level1_accuracy = 0

        profiling = row["profiling"]
        level1 = row["level_1_predict"]

        if profiling != 'PMU Missing':
            profiling = float(profiling)
            tile_sim_accuracy = 1 - abs(tile_sim_res - profiling) / profiling

            # assert tile_sim_accuracy > accuracy_required

            if type(level1) is not str:
                level1_accuracy = 1 - abs(level1 - profiling) / profiling

        comp_res.append([test_case, op1_shape, profiling, level1, tile_sim_res, tile_sim_accuracy, level1_accuracy])

    df = pd.DataFrame(comp_res, columns=["test_case","shape", "profiling", "level_1_predict", "tile_sim_predict", "tile_sim_accuracy", "level_1_accuracy"])
    df.to_csv("tile_op_check_result.csv", index=False)