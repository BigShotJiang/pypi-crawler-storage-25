# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
"""
SSA Unit Tests - Direct SSAEnv testing without circular imports

This file tests the SSA implementation at the unit level by creating
minimal mock objects to avoid circular imports.
"""

import pytest
from dataclasses import dataclass
from typing import Optional


# Mock EntityIR to avoid circular imports
@dataclass
class MockEntityIR:
    name: str
    origin_name: str
    value: object = None


# Mock PhiFuncIR to avoid circular imports
@dataclass
class MockPhiFuncIR:
    id: str
    result_name: str
    referred_name: list[str]
    scope_referrers: dict[str, str]


def create_ssa_env():
    """Create SSAEnv with minimal dependencies"""
    from core.frontend.dsl.parse.ssa_env import SSAEnv, _generate_phi

    # Temporarily replace _generate_phi to avoid circular imports
    original_generate = _generate_phi

    def mock_generate_phi(var_name: str, versions: set[str], scope_referrers: dict[str, str]):
        # Note: var_name here is actually the merged version name (e.g., "x.3")
        # from the actual SSAEnv implementation in pop_stack()
        return MockPhiFuncIR(
            id="mock-phi",
            result_name=var_name,  # This is the merged version, not original name
            referred_name=list(versions),
            scope_referrers=scope_referrers
        )

    # Monkey patch
    import core.frontend.dsl.parse.ssa_env as ssa_env_module
    ssa_env_module._generate_phi = mock_generate_phi

    env = SSAEnv()
    return env, original_generate


def restore_generate_phi(original):
    """Restore original _generate_phi"""
    import core.frontend.dsl.parse.ssa_env as ssa_env_module
    ssa_env_module._generate_phi = original


def get_original_var_name(name: str) -> str:
    """从变量名中提取原始变量名（去除版本号后缀）"""
    return name.split('.')[0] if '.' in name else name


class TestSSABasicOperations:
    """Test basic SSA operations"""

    def test_write_var_creates_version(self):
        """Writing a variable should create a versioned name"""
        env, original = create_ssa_env()

        var = MockEntityIR(name="x", origin_name="x")
        env.write_var(var)

        # First version should be the original name
        assert var.name == "x"

        restore_generate_phi(original)

    def test_write_var_multiple_versions(self):
        """Multiple writes should create multiple versions"""
        env, original = create_ssa_env()

        var1 = MockEntityIR(name="x", origin_name="x")
        env.write_var(var1)
        assert var1.name == "x"

        var2 = MockEntityIR(name="x", origin_name="x")
        env.write_var(var2)
        assert var2.name == "x.1"

        var3 = MockEntityIR(name="x", origin_name="x")
        env.write_var(var3)
        assert var3.name == "x.2"

        restore_generate_phi(original)

    def test_read_var_latest_version(self):
        """Reading should return the latest version"""
        env, original = create_ssa_env()

        var1 = MockEntityIR(name="x", origin_name="x")
        env.write_var(var1)

        var2 = MockEntityIR(name="x", origin_name="x")
        env.write_var(var2)

        read_var = env.read_var("x")
        assert read_var.name == "x.1"

        restore_generate_phi(original)

    def test_read_undefined_raises_error(self):
        """Reading undefined variable should raise NameError"""
        env, original = create_ssa_env()

        with pytest.raises(NameError, match="used before definition"):
            env.read_var("undefined")

        restore_generate_phi(original)


class TestScopeStack:
    """Test scope stack management"""

    def test_push_pop_balance(self):
        """push and pop should maintain balance"""
        env, original = create_ssa_env()

        initial_size = len(env._scope)

        env.push_stack("scope-1")
        assert len(env._scope) == initial_size + 1

        env.pop_stack()
        assert len(env._scope) == initial_size

        restore_generate_phi(original)

    def test_nested_scopes(self):
        """Nested scopes should work correctly"""
        env, original = create_ssa_env()

        initial_size = len(env._scope)

        env.push_stack("outer")
        env.push_stack("inner")
        env.push_stack("innermost")

        assert len(env._scope) == initial_size + 3

        env.pop_stack()
        env.pop_stack()
        env.pop_stack()

        assert len(env._scope) == initial_size

        restore_generate_phi(original)


class TestPhiGeneration:
    """Test Phi function generation"""

    def test_phi_at_merge_point(self):
        """Phi should be generated at merge points"""
        env, original = create_ssa_env()

        # Initial value
        var_x = MockEntityIR(name="x", origin_name="x")
        env.write_var(var_x)

        # Create if-else structure
        env.push_stack("if-outer")

        # if branch
        env.push_stack("if-branch")
        var_x_if = MockEntityIR(name="x", origin_name="x")
        env.write_var(var_x_if)
        env.pop_stack()

        # else branch
        env.push_stack("else-branch")
        var_x_else = MockEntityIR(name="x", origin_name="x")
        env.write_var(var_x_else)
        env.pop_stack()

        # pop outer - should generate phi
        env.pop_stack()

        # Check phi was generated
        # The result_name is the merged version (e.g., "x.2"), not the original name
        phi_for_x = any(isinstance(phi, MockPhiFuncIR) and get_original_var_name(phi.result_name) == "x"
                       for phi in env.phi_func_list)
        assert phi_for_x, "Phi should be generated for x at if-else merge point"

        restore_generate_phi(original)

    def test_phi_not_generated_no_merge(self):
        """No phi should be generated without version merge"""
        env, original = create_ssa_env()

        # Simple nesting, no variable modification
        env.push_stack("outer")
        env.push_stack("inner")
        env.pop_stack()
        env.pop_stack()

        assert len(env.phi_func_list) == 0

        restore_generate_phi(original)

    def test_phi_scope_referrers(self):
        """Phi scope_referrers should map correctly"""
        env, original = create_ssa_env()

        var_x = MockEntityIR(name="x", origin_name="x")
        env.write_var(var_x)

        env.push_stack("if-outer")

        env.push_stack("branch-1")
        var_x_1 = MockEntityIR(name="x", origin_name="x")
        env.write_var(var_x_1)
        env.pop_stack()

        env.push_stack("branch-2")
        var_x_2 = MockEntityIR(name="x", origin_name="x")
        env.write_var(var_x_2)
        env.pop_stack()

        env.push_stack("branch-3")
        var_x_3 = MockEntityIR(name="x", origin_name="x")
        env.write_var(var_x_3)
        env.pop_stack()

        env.pop_stack()

        # Find phi for x
        phi_x = next((phi for phi in env.phi_func_list
                     if isinstance(phi, MockPhiFuncIR) and get_original_var_name(phi.result_name) == "x"), None)
        assert phi_x is not None

        # Should have 3 scope referrers
        assert len(phi_x.scope_referrers) == 3

        # All referred names should be in scope_referrers values
        for ref_name in phi_x.referred_name:
            assert ref_name in phi_x.scope_referrers.values()

        restore_generate_phi(original)

    def test_phi_multiple_variables(self):
        """Multiple variables should each get phi"""
        env, original = create_ssa_env()

        var_x = MockEntityIR(name="x", origin_name="x")
        var_y = MockEntityIR(name="y", origin_name="y")
        env.write_var(var_x)
        env.write_var(var_y)

        env.push_stack("if-outer")

        env.push_stack("if-branch")
        env.write_var(MockEntityIR(name="x", origin_name="x"))
        env.write_var(MockEntityIR(name="y", origin_name="y"))
        env.pop_stack()

        env.push_stack("else-branch")
        env.write_var(MockEntityIR(name="x", origin_name="x"))
        env.write_var(MockEntityIR(name="y", origin_name="y"))
        env.pop_stack()

        env.pop_stack()

        # Check phi for both x and y
        phi_vars = set(get_original_var_name(phi.result_name) for phi in env.phi_func_list
                      if isinstance(phi, MockPhiFuncIR))
        assert "x" in phi_vars
        assert "y" in phi_vars

        restore_generate_phi(original)

    def test_phi_with_body_only_no_phi(self):
        """Variable written in last scope's body shouldn't create phi"""
        env, original = create_ssa_env()

        env.push_stack("outer")

        env.push_stack("branch-1")
        var_x_1 = MockEntityIR(name="x", origin_name="x")
        env.write_var(var_x_1)
        env.pop_stack()

        # Pop outer - only one branch wrote x, no phi needed
        env.pop_stack()

        # No phi should be generated
        assert len(env.phi_func_list) == 0

        restore_generate_phi(original)


class TestVersionCounter:
    """Test version counting"""

    def test_version_counter_independence(self):
        """Different variables should have independent version counters"""
        env, original = create_ssa_env()

        for i in range(10):
            env.write_var(MockEntityIR(name="a", origin_name="a"))

        for i in range(5):
            env.write_var(MockEntityIR(name="b", origin_name="b"))

        assert env._version_counter.get("a", 0) == 10
        assert env._version_counter.get("b", 0) == 5

        restore_generate_phi(original)

    def test_version_counter_continues_across_scopes(self):
        """Version counter should continue across scopes"""
        env, original = create_ssa_env()

        var1 = MockEntityIR(name="x", origin_name="x")
        env.write_var(var1)
        assert var1.name == "x"

        env.push_stack("scope-1")
        var2 = MockEntityIR(name="x", origin_name="x")
        env.write_var(var2)
        assert var2.name == "x.1"

        env.pop_stack()

        var3 = MockEntityIR(name="x", origin_name="x")
        env.write_var(var3)
        assert var3.name == "x.2"

        assert env._version_counter.get("x", 0) == 3

        restore_generate_phi(original)


class TestScopeInheritance:
    """Test scope inheritance"""

    def test_child_scope_inherits_variable(self):
        """Child scope should inherit parent's variables"""
        env, original = create_ssa_env()

        var_x = MockEntityIR(name="x", origin_name="x")
        env.write_var(var_x)

        env.push_stack("child")

        # Should be able to read parent's variable
        read_var = env.read_var("x")
        assert read_var.name == "x"

        env.pop_stack()
        restore_generate_phi(original)

    def test_child_scope_can_hide_variable(self):
        """Child scope can hide parent's variable with new definition"""
        env, original = create_ssa_env()

        var_x = MockEntityIR(name="x", origin_name="x")
        env.write_var(var_x)

        env.push_stack("child")

        # Write new version in child
        var_x_child = MockEntityIR(name="x", origin_name="x")
        env.write_var(var_x_child)

        # Read should return child's version
        read_var = env.read_var("x")
        assert read_var.name == "x.1"

        env.pop_stack()

        # After pop, should still have parent's version (or phi)
        read_var = env.read_var("x")
        # Since child wrote a new version, merging should create phi
        # But with no parent merge, behavior depends on implementation

        restore_generate_phi(original)


def test_phi_referrers_consistency():
    """Test that phi function generates consistent scope referrers"""
    env, original = create_ssa_env()

    var_x = MockEntityIR(name="x", origin_name="x")
    env.write_var(var_x)

    env.push_stack("outer")

    env.push_stack("branch-a")
    env.write_var(MockEntityIR(name="x", origin_name="x"))
    env.pop_stack()

    env.push_stack("branch-b")
    env.write_var(MockEntityIR(name="x", origin_name="x"))
    env.pop_stack()

    env.pop_stack()

    phi_x = next((phi for phi in env.phi_func_list
                 if isinstance(phi, MockPhiFuncIR) and get_original_var_name(phi.result_name) == "x"), None)
    assert phi_x is not None

    # Scope referrers should map each scope to the correct referenced name
    for scope_id, ref_name in phi_x.scope_referrers.items():
        assert ref_name in phi_x.referred_name, \
            f"Scope {scope_id} refers to {ref_name} which is not in referred_name"

    # Each referred_name should have exactly one scope
    ref_to_scopes = {}
    for scope_id, ref_name in phi_x.scope_referrers.items():
        ref_to_scopes.setdefault(ref_name, []).append(scope_id)

    restore_generate_phi(original)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])