# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
"""
后端Entity展开的SSA测试用例

测试内容：
1. EvalCtxEntity版本管理 - 变量版本号的管理
2. Phi函数激活 - 根据scope_id激活正确的变量版本
3. 版本绑定函数的正确性
4. 上下文隔离测试

注意：由于循环导入问题，某些测试需要mock或延迟导入
"""

import pytest
from unittest.mock import Mock, MagicMock

# 只导入不会触发循环导入的核心模块
from core.backend.backend_entity.backend_context import PhiFuncEntity, EvalCtxEntity, bind_version


class TestBindVersion:
    """测试版本绑定函数"""

    def test_bind_version_zero(self):
        """测试版本号为0时绑定为原名称"""
        assert bind_version("x", 0) == "x"
        assert bind_version("tensor", 0) == "tensor"

    def test_bind_version_positive(self):
        """测试正版本号绑定为带后缀的名称"""
        assert bind_version("x", 1) == "x.1"
        assert bind_version("tensor", 2) == "tensor.2"
        assert bind_version("y", 10) == "y.10"
        assert bind_version("result", 99) == "result.99"


class TestEvalCtxEntityVersionManagement:
    """测试EvalCtxEntity的版本管理"""

    def test_initial_version(self):
        """测试初始版本号"""
        ctx = EvalCtxEntity(env={}, version_manager={})

        # 新变量初始版本应为0
        assert ctx.get_version("x") == 0
        assert ctx.get_version("y") == 0
        assert ctx.get_version("tensor_data") == 0

    def test_update_version(self):
        """测试版本号更新"""
        ctx = EvalCtxEntity(env={}, version_manager={})

        ctx.update_version("x", 1)
        assert ctx.get_version("x") == 1

        ctx.update_version("x", 2)
        assert ctx.get_version("x") == 2

        ctx.update_version("x", 5)
        assert ctx.get_version("x") == 5

    def test_multiple_independent_vars(self):
        """测试多个独立变量的版本管理"""
        ctx = EvalCtxEntity(env={}, version_manager={})

        ctx.update_version("x", 1)
        ctx.update_version("y", 2)
        ctx.update_version("z", 3)

        assert ctx.get_version("x") == 1
        assert ctx.get_version("y") == 2
        assert ctx.get_version("z") == 3

    def test_assign_env(self):
        """测试环境变量赋值"""
        ctx = EvalCtxEntity(env={}, version_manager={})

        ctx.assign("i", 5)
        assert ctx.env["i"] == 5

        ctx.assign("j", 10)
        assert ctx.env["j"] == 10

        ctx.assign("flag", True)
        assert ctx.env["flag"] is True

    def test_assign_dict(self):
        """测试批量赋值"""
        ctx = EvalCtxEntity(env={}, version_manager={})

        ctx.assign_dict({"i": 1, "j": 2, "k": 3})
        assert ctx.env["i"] == 1
        assert ctx.env["j"] == 2
        assert ctx.env["k"] == 3

        ctx.assign_dict({"a": 10, "b": 20, "c": 30, "d": 40})
        assert ctx.env["a"] == 10
        assert ctx.env["b"] == 20
        assert ctx.env["c"] == 30
        assert ctx.env["d"] == 40

    def test_create_tmp_ctx(self):
        """测试创建临时上下文"""
        ctx = EvalCtxEntity(env={"i": 5}, version_manager={"x": 1})

        tmp_ctx = ctx.create_tmp_ctx()

        # 临时context应该有相同的基础环境
        assert tmp_ctx.env["i"] == 5
        assert tmp_ctx.version_manager["x"] == 1

        # 修改临时context不应该影响原context
        tmp_ctx.assign("i", 10)
        assert ctx.env["i"] == 5
        assert tmp_ctx.env["i"] == 10

    def test_tmp_ctx_version_isolation(self):
        """
        测试临时context版本隔离

        注意：create_tmp_ctx中version_manager是直接引用（浅拷贝），
        所以对tmp_ctx的版本修改会影响原ctx。这是当前实现的特性。
        """
        ctx = EvalCtxEntity(
            env={"i": 1},
            version_manager={"x": 1, "y": 2}
        )

        tmp_ctx = ctx.create_tmp_ctx()

        # 修改临时context的版本
        tmp_ctx.update_version("x", 5)
        tmp_ctx.update_version("y", 10)

        # 注意：由于version_manager直接引用，修改会影响原context
        assert ctx.get_version("x") == 5
        assert ctx.get_version("y") == 10

        # 临时context的版本也改变
        assert tmp_ctx.get_version("x") == 5
        assert tmp_ctx.get_version("y") == 10

    def test_phi_dict_persistence_in_tmp_ctx(self):
        """
        测试phi字典在临时context中的行为

        注意：create_tmp_ctx中，env使用copy，version_manager直接引用，
        但phi_func_by_scope和phi_func_by_name不传参，会变成空的default_factory。
        这是当前实现的特性。
        """
        phi = PhiFuncEntity(
            id="phi-1",
            result_name="x",
            referred_name=["x", "x.1"],
            scope_referrers={"scope-1": "x", "scope-2": "x.1"}
        )

        ctx = EvalCtxEntity(
            env={},
            version_manager={},
            phi_func_by_scope={"scope-1": [phi]},
            phi_func_by_name={"x": phi}
        )

        tmp_ctx = ctx.create_tmp_ctx()

        # 注意：create_tmp_ctx不会传入phi字典，所以tmp_ctx的phi字典为空
        assert tmp_ctx.phi_func_by_scope == {}
        assert tmp_ctx.phi_func_by_name == {}


class TestPhiFuncEntity:
    """测试Phi函数实体"""

    def test_phi_activate_simple(self):
        """测试Phi函数激活"""
        phi = PhiFuncEntity(
            id="phi-1",
            result_name="x",
            referred_name=["x", "x.1"],
            scope_referrers={
                "scope-1": "x",
                "scope-2": "x.1"
            }
        )

        # 激活scope-1应该激活x
        phi.activate("scope-1")
        assert phi.activated_name == "x"

        # 激活scope-2应该激活x.1
        phi.activate("scope-2")
        assert phi.activated_name == "x.1"

    def test_phi_activate_multiple_scopes(self):
        """测试多个scope的激活"""
        phi = PhiFuncEntity(
            id="phi-many",
            result_name="var",
            referred_name=["var", "var.1", "var.2"],
            scope_referrers={
                "branch-a": "var",
                "branch-b": "var.1",
                "branch-c": "var.2"
            }
        )

        # 测试每个scope的激活
        for scope_id, expected_name in [
            ("branch-a", "var"),
            ("branch-b", "var.1"),
            ("branch-c", "var.2")
        ]:
            phi.activate(scope_id)
            assert phi.activated_name == expected_name

    def test_phi_activate_invalid_scope(self):
        """测试激活无效scope时抛出异常"""
        phi = PhiFuncEntity(
            id="phi-1",
            result_name="x",
            referred_name=["x", "x.1"],
            scope_referrers={
                "scope-1": "x",
                "scope-2": "x.1"
            }
        )

        with pytest.raises(ValueError, match="scope-999 not in phi func scope_referrers"):
            phi.activate("scope-999")

    def test_phi_activate_empty_scope_referrers(self):
        """测试空scope_referrers时的激活"""
        phi = PhiFuncEntity(
            id="phi-empty",
            result_name="y",
            referred_name=["y", "y.1"],
            scope_referrers={}
        )

        # 激活应该失败，因为scope_referrers为空
        with pytest.raises(ValueError):
            phi.activate("any-scope")


class TestEvalCtxEntityWithPhi:
    """测试EvalCtxEntity的Phi函数处理"""

    def test_get_merge_phi_name(self):
        """测试通过phi获取合并后的变量名"""
        phi = PhiFuncEntity(
            id="phi-1",
            result_name="x",
            referred_name=["x", "x.1"],
            scope_referrers={
                "scope-1": "x",
                "scope-2": "x.1"
            }
        )

        ctx = EvalCtxEntity(
            env={},
            version_manager={},
            phi_func_by_scope={
                "scope-1": [phi],
                "scope-2": [phi]
            },
            phi_func_by_name={
                "x": phi
            }
        )

        # 未激活时应该报错
        with pytest.raises(Exception, match="phi func x is not activated"):
            ctx._get_merge_phi_name("x")

        # 激活scope-1后应该返回x
        ctx.activate_phi("scope-1")
        assert ctx._get_merge_phi_name("x") == "x"

    def test_activate_phi(self):
        """测试activate_phi方法"""
        phi = PhiFuncEntity(
            id="phi-1",
            result_name="x",
            referred_name=["x", "x.1"],
            scope_referrers={
                "scope-1": "x",
                "scope-2": "x.1"
            }
        )

        ctx = EvalCtxEntity(
            env={},
            version_manager={},
            phi_func_by_scope={"scope-1": [phi]},
            phi_func_by_name={"x": phi}
        )

        ctx.activate_phi("scope-1")
        assert phi.activated_name == "x"

    def test_no_phi_name(self):
        """测试没有phi函数时直接返回变量名"""
        ctx = EvalCtxEntity(env={}, version_manager={})
        assert ctx._get_merge_phi_name("x") == "x"
        assert ctx._get_merge_phi_name("any_var") == "any_var"

    def test_activate_phi_multiple_phis_in_scope(self):
        """测试一个scope有多个phi函数的情况"""
        phi_x = PhiFuncEntity(
            id="phi-x",
            result_name="x",
            referred_name=["x", "x.1"],
            scope_referrers={"scope-1": "x.1", "scope-2": "x"}
        )

        phi_y = PhiFuncEntity(
            id="phi-y",
            result_name="y",
            referred_name=["y", "y.1"],
            scope_referrers={"scope-1": "y.1", "scope-2": "y"}
        )

        ctx = EvalCtxEntity(
            env={},
            version_manager={},
            phi_func_by_scope={
                "scope-1": [phi_x, phi_y],
                "scope-2": [phi_x, phi_y]
            },
            phi_func_by_name={
                "x": phi_x,
                "y": phi_y
            }
        )

        # 激活scope-1
        ctx.activate_phi("scope-1")

        # 两个phi都应该被激活
        assert phi_x.activated_name == "x.1"
        assert phi_y.activated_name == "y.1"


class TestSSABugRegression:
    """针对已知SSA问题的回归测试"""

    def test_phi_scope_referrer_consistency(self):
        """
        回归测试：确保phi函数的scope_referrer和referred_name一致性

        问题描述：如果phi函数的scope_referrer引用了不存在的referred_name，
        或者反之，会导致运行时错误。
        """
        # 正确的phi函数构造
        phi = PhiFuncEntity(
            id="test-phi",
            result_name="x",
            referred_name=["x", "x.1"],
            scope_referrers={
                "scope-1": "x",
                "scope-2": "x.1"
            }
        )

        # 验证一致性
        for scope_id, ref_name in phi.scope_referrers.items():
            assert ref_name in phi.referred_name, \
                f"scope {scope_id}引用的{ref_name}不在referred_name中"

        for ref_name in phi.referred_name:
            assert ref_name in phi.scope_referrers.values(), \
                f"referred_name中的{ref_name}没有对应的scope_id"

    def test_phi_activation_before_use(self):
        """
        回归测试：确保phi函数在使用前被激活

        问题描述：如果phi函数未被激活就调用_get_merge_phi_name会抛异常
        注意：activate_phi需要scope_id在phi_func_by_scope中查找
        """
        phi = PhiFuncEntity(
            id="test-phi",
            result_name="x",
            referred_name=["x", "x.1"],
            scope_referrers={
                "scope-1": "x",
                "scope-2": "x.1"
            }
        )

        ctx = EvalCtxEntity(
            env={},
            version_manager={},
            phi_func_by_scope={
                "scope-1": [phi],
                "scope-2": [phi]
            },
            phi_func_by_name={"x": phi}
        )

        # 未激活时调用应该抛异常
        with pytest.raises(Exception, match="is not activated"):
            ctx._get_merge_phi_name("x")

        # 激活scope-1后应该正常工作
        ctx.activate_phi("scope-1")
        assert ctx._get_merge_phi_name("x") == "x"

    def test_context_version_isolation(self):
        """
        回归测试：create_tmp_ctx的版本共享行为

        当前实现中，version_manager直接引用（不深拷贝），
        所以临时context的版本修改会影响原context。
        这是实现的一个特性，记录在此。
        """
        ctx = EvalCtxEntity(
            env={"i": 1},
            version_manager={"x": 1, "y": 2}
        )

        tmp_ctx = ctx.create_tmp_ctx()

        # 修改临时context的版本
        tmp_ctx.update_version("x", 5)
        tmp_ctx.update_version("y", 10)

        # 注意：由于version_manager直接引用，原context也会受影响
        assert ctx.get_version("x") == 5
        assert ctx.get_version("y") == 10

        # 临时context的版本也改变
        assert tmp_ctx.get_version("x") == 5
        assert tmp_ctx.get_version("y") == 10


class TestSSACornerCases:
    """SSA边界情况测试"""

    def test_empty_phi_referrers(self):
        """测试空的phi引用"""
        # 虽然不太可能出现，但确保代码能处理
        phi = PhiFuncEntity(
            id="empty-phi",
            result_name="x",
            referred_name=[],
            scope_referrers={}
        )

        ctx = EvalCtxEntity(
            env={},
            version_manager={},
            phi_func_by_name={"x": phi}
        )

        # 由于没有scope_referrers，无法激活
        with pytest.raises(ValueError):
            phi.activate("any-scope")

    def test_single_referrer_phi(self):
        """
        测试只有一个引用的phi函数

        注意：根据SSA定义，phi应该至少合并2个版本
        这个测试验证代码是否能处理1个引用的情况（可能不应该出现）
        """
        phi = PhiFuncEntity(
            id="single-phi",
            result_name="x",
            referred_name=["x.1"],
            scope_referrers={"scope-1": "x.1"}
        )

        # 应该能正常激活
        phi.activate("scope-1")
        assert phi.activated_name == "x.1"

    def test_nested_scope_phis(self):
        """测试嵌套作用域中的多个phi函数"""
        # 嵌套结构可能产生多个phi函数
        # 确保它们能正确处理
        phi1 = PhiFuncEntity(
            id="phi-1",
            result_name="x",
            referred_name=["x", "x.1"],
            scope_referrers={"inner-1": "x.1", "inner-2": "x"}
        )

        phi2 = PhiFuncEntity(
            id="phi-2",
            result_name="y",
            referred_name=["y", "y.1"],
            scope_referrers={"inner-1": "y.1", "inner-2": "y"}
        )

        ctx = EvalCtxEntity(
            env={},
            version_manager={},
            phi_func_by_scope={
                "inner-1": [phi1, phi2],
                "inner-2": [phi1, phi2]
            },
            phi_func_by_name={
                "x": phi1,
                "y": phi2
            }
        )

        # 激活inner-1
        ctx.activate_phi("inner-1")

        # 两个phi都应该被激活
        assert phi1.activated_name == "x.1"
        assert phi2.activated_name == "y.1"

        # 获取合并后的名称
        assert ctx._get_merge_phi_name("x") == "x.1"
        assert ctx._get_merge_phi_name("y") == "y.1"


class TestSSAIntegrationWithVersions:
    """测试SSA与版本管理的集成"""

    def test_version_and_phi_interaction(self):
        """测试版本号和phi函数的交互"""
        phi = PhiFuncEntity(
            id="phi-var",
            result_name="data",
            referred_name=["data", "data.1", "data.2"],
            scope_referrers={
                "branch-1": "data.1",
                "branch-2": "data.2",
                "branch-3": "data"
            }
        )

        ctx = EvalCtxEntity(
            env={},
            version_manager={"data.1": 3, "data.2": 5},  # 为合并后的版本预先设置版本号
            phi_func_by_scope={
                "branch-1": [phi],
                "branch-2": [phi],
                "branch-3": [phi]
            },
            phi_func_by_name={"data": phi}
        )

        # 激活branch-1
        ctx.activate_phi("branch-1")

        # 获取合并后的名称应该是data.1
        merged_name = ctx._get_merge_phi_name("data")
        assert merged_name == "data.1"

        # 获取data.1的版本号
        assert ctx.get_version("data") == 3  # 使用合并后的名称获取版本

    def test_version_isolation_with_phi(self):
        """
        测试带phi时的版本隔离

        注意：由于create_tmp_ctx不复制phi_func_by_scope和phi_func_by_name，
        tmp_ctx的activate_phi不会找到任何phi函数来激活。
        这是当前实现的特性，phi激活需要在原context上完成。
        """
        phi = PhiFuncEntity(
            id="phi-test",
            result_name="x",
            referred_name=["x", "x.1"],
            scope_referrers={"scope-a": "x", "scope-b": "x.1"}
        )

        ctx = EvalCtxEntity(
            env={},
            version_manager={"x": 1, "x.1": 2},
            phi_func_by_scope={
                "scope-a": [phi],
                "scope-b": [phi]
            },
            phi_func_by_name={"x": phi}
        )

        tmp_ctx = ctx.create_tmp_ctx()

        # 在原context中激活scope-a
        ctx.activate_phi("scope-a")

        # 在临时context中获取合并后的名称
        # 注意：由于tmp_ctx没有phi_dict，需要直接检查原context
        merged_name = ctx._get_merge_phi_name("x")
        assert merged_name == "x"
        assert phi.activated_name == "x"

        # tmp_ctx由于没有phi_dict，无法获取合并名称
        # 但可以通过其他方式获取


class TestSSADataConsistency:
    """测试SSA数据一致性问题"""

    def test_version_counter_independence(self):
        """测试不同变量的版本计数器独立"""
        ctx = EvalCtxEntity(env={}, version_manager={})

        # 模拟不同变量的版本演进
        ctx.update_version("a", 1)
        ctx.update_version("b", 1)
        ctx.update_version("a", 2)
        ctx.update_version("c", 1)
        ctx.update_version("b", 3)
        ctx.update_version("a", 5)

        assert ctx.get_version("a") == 5
        assert ctx.get_version("b") == 3
        assert ctx.get_version("c") == 1

        # 验证变量之间互不影响
        ctx.update_version("b", 10)
        assert ctx.get_version("a") == 5  # a的版本不应该变
        assert ctx.get_version("b") == 10


if __name__ == "__main__":
    pytest.main([__file__, "-v"])