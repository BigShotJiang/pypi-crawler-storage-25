# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
"""
IR到Entity转换的SSA测试用例

测试内容：
1. Phi函数的转换 - 验证PhiFuncIR正确转换为PhiFuncEntity
2. TaskEntity的转换 - 验证Task中的phi函数正确传递
3. BackendEntity的构建 - 验证完整的BackendEntity中phi函数字典正确
"""

import pytest
import uuid

from core.common.entity import DType, MemLoc, OpLevel
from core.frontend.ir.core.ir import KernelIR
from core.frontend.ir.core.ir_logistic import TaskIR, PhiFuncIR, OpIR
from core.frontend.ir.core.ir_entity import VarIR
from core.frontend.ir.core.ir_math import RangeIR, ConstExprIR
from core.backend.backend_entity.ir_to_entity import backend_entity_build


class TestPhiFuncConversion:
    """测试Phi函数从IR到Entity的转换"""

    def test_phi_to_entity(self):
        """测试单个phi函数转换"""
        phi_ir = PhiFuncIR(
            id="phi-1",
            result_name="x",
            referred_name=["x", "x.1"],
            scope_referrers={
                "scope-1": "x",
                "scope-2": "x.1"
            }
        )

        phi_entity = phi_ir.to_entity()

        # 验证转换正确
        assert phi_entity.id == "phi-1"
        assert phi_entity.result_name == "x"
        assert sorted(phi_entity.referred_name) == sorted(["x", "x.1"])
        assert phi_entity.scope_referrers == {
            "scope-1": "x",
            "scope-2": "x.1"
        }

    def test_phi_to_entity_empty_scope_referrers(self):
        """测试空scope_referrers的phi转换"""
        phi_ir = PhiFuncIR(
            id="phi-empty",
            result_name="y",
            referred_name=["y", "y.1"],
            scope_referrers={}
        )

        phi_entity = phi_ir.to_entity()

        assert phi_entity.scope_referrers == {}
        assert phi_entity.activated_name is None

    def test_multiple_phis_convert(self):
        """测试多个phi函数转换"""
        phi_list = [
            PhiFuncIR(
                id="phi-1",
                result_name="x",
                referred_name=["x", "x.1"],
                scope_referrers={"scope-1": "x", "scope-2": "x.1"}
            ),
            PhiFuncIR(
                id="phi-2",
                result_name="y",
                referred_name=["y", "y.1", "y.2"],
                scope_referrers={"if-scope": "y.1", "else-scope": "y.2", "outer": "y"}
            )
        ]

        entities = [phi.to_entity() for phi in phi_list]

        # 验证所有phi都正确转换
        assert len(entities) == 2
        assert entities[0].result_name == "x"
        assert entities[1].result_name == "y"
        assert len(entities[1].referred_name) == 3


class TestBackendEntityBuild:
    """测试BackendEntity构建中的phi处理"""

    def test_build_with_phi_dict(self):
        """测试构建带phi函数字典的BackendEntity"""
        # 创建KernelIR
        kernel_ir = KernelIR(name="test_kernel")

        # 添加phi函数
        phi_1 = PhiFuncIR(
            id="phi-1",
            result_name="x",
            referred_name=["x", "x.1"],
            scope_referrers={"if-scope": "x.1", "else-scope": "x"}
        )
        phi_2 = PhiFuncIR(
            id="phi-2",
            result_name="y",
            referred_name=["y", "y.1"],
            scope_referrers={"if-scope": "y.1", "else-scope": "y"}
        )

        kernel_ir.phi_func_dict = {
            "if-scope": [phi_1, phi_2],
            "else-scope": [phi_1, phi_2]
        }

        # 构建BackendEntity
        variable_ctx = {"M": 10, "N": 20, "i": 5}
        backend_entity = backend_entity_build(kernel_ir, variable_ctx, task_kernel=False)

        # 验证EvalCtxEntity中phi函数正确传递
        assert "if-scope" in backend_entity.eval_ctx.phi_func_by_scope
        assert "else-scope" in backend_entity.eval_ctx.phi_func_by_scope
        assert "x" in backend_entity.eval_ctx.phi_func_by_name
        assert "y" in backend_entity.eval_ctx.phi_func_by_name

        # 验证phi函数实体
        phi_x = backend_entity.eval_ctx.phi_func_by_name["x"]
        assert phi_x.result_name == "x"
        assert phi_x.id == "phi-1"

        phi_y = backend_entity.eval_ctx.phi_func_by_name["y"]
        assert phi_y.result_name == "y"
        assert phi_y.id == "phi-2"

    def test_build_with_empty_phi_dict(self):
        """测试构建无phi函数的BackendEntity"""
        kernel_ir = KernelIR(name="test_kernel")
        kernel_ir.phi_func_dict = {}

        variable_ctx = {}
        backend_entity = backend_entity_build(kernel_ir, variable_ctx, task_kernel=False)

        # 验证空的phi字典
        assert len(backend_entity.eval_ctx.phi_func_by_scope) == 0
        assert len(backend_entity.eval_ctx.phi_func_by_name) == 0

    def test_build_with_task_and_phi(self):
        """测试包含TaskIR和phi函数的构建"""
        # 创建KernelIR
        kernel_ir = KernelIR(name="test_kernel")

        # 添加一个简单的TaskIR
        range_ir = RangeIR(ConstExprIR(0), ConstExprIR(10), ConstExprIR(1))
        idx_ir = VarIR(name="i", value=range_ir)

        task_ir = TaskIR(
            indices=[idx_ir],
            body=[],
            task_name="test_task"
        )
        kernel_ir.add_op(task_ir)

        # 添加phi函数
        phi = PhiFuncIR(
            id="phi-1",
            result_name="x",
            referred_name=["x", "x.1"],
            scope_referrers={"scope-1": "x", "scope-2": "x.1"}
        )
        kernel_ir.phi_func_dict = {
            "scope-1": [phi],
            "scope-2": [phi]
        }

        # 构建
        variable_ctx = {}
        backend_entity = backend_entity_build(kernel_ir, variable_ctx, task_kernel=True)

        # 验证TaskEntity存在
        assert "test_task" in backend_entity.task_dict

        # 验证phi函数存在
        assert "x" in backend_entity.eval_ctx.phi_func_by_name
        assert phi.result_name == backend_entity.eval_ctx.phi_func_by_name["x"].result_name


class TestPhiScopeConsistency:
    """测试Phi函数scope一致性"""

    def test_phi_scope_mapping(self):
        """验证phi函数在phi_func_by_scope中的正确索引"""
        kernel_ir = KernelIR(name="test_kernel")

        # 创建3个scope，每个scope有不同的phi函数
        phi_x = PhiFuncIR(
            id="phi-x",
            result_name="x",
            referred_name=["x", "x.1"],
            scope_referrers={"scope-a": "x", "scope-b": "x.1"}
        )

        phi_y = PhiFuncIR(
            id="phi-y",
            result_name="y",
            referred_name=["y", "y.1"],
            scope_referrers={"scope-a": "y", "scope-b": "y.1"}
        )

        # phi_x在scope-a和scope-b，phi_y只在scope-a
        kernel_ir.phi_func_dict = {
            "scope-a": [phi_x, phi_y],
            "scope-b": [phi_x]
        }

        variable_ctx = {}
        backend_entity = backend_entity_build(kernel_ir, variable_ctx, task_kernel=False)

        # 验证scope-a有2个phi，scope-b有1个phi
        assert len(backend_entity.eval_ctx.phi_func_by_scope["scope-a"]) == 2
        assert len(backend_entity.eval_ctx.phi_func_by_scope["scope-b"]) == 1

        # 验证phi_func_by_name中都有
        assert "x" in backend_entity.eval_ctx.phi_func_by_name
        assert "y" in backend_entity.eval_ctx.phi_func_by_name


class TestPhiWithTaskIRBody:
    """测试TaskIR body中phi函数的处理"""

    def test_task_phi_preservation(self):
        """验证TaskIR中phi函数在转换后保留"""
        kernel_ir = KernelIR(name="test_kernel")

        # 创建一个TaskIR
        task_ir = TaskIR(
            indices=[VarIR(name="i", value=RangeIR(ConstExprIR(0), ConstExprIR(5), ConstExprIR(1)))],
            body=[],
            task_name="task_with_phi"
        )
        kernel_ir.add_op(task_ir)

        # 为task添加phi函数（注意：phi通常定义在task级别的merge点）
        phi = PhiFuncIR(
            id="task-phi",
            result_name="x",
            referred_name=["x", "x.1"],
            scope_referrers={"task-if": "x.1", "task-else": "x"}
        )
        kernel_ir.phi_func_dict = {
            "task-if": [phi],
            "task-else": [phi]
        }

        variable_ctx = {}
        backend_entity = backend_entity_build(kernel_ir, variable_ctx, task_kernel=True)

        # 验证TaskEntity和phi都存在
        assert "task_with_phi" in backend_entity.task_dict
        task_entity = backend_entity.task_dict["task_with_phi"]

        # TaskEntity转换时，phi应该在eval_ctx中
        assert "x" in backend_entity.eval_ctx.phi_func_by_name
        assert backend_entity.eval_ctx.phi_func_by_name["x"].result_name == "x"


class TestPhiEntityActivateIntegration:
    """测试phi实体激活与使用的集成"""

    def test_phi_activate_in_backend_entity(self):
        """测试在BackendEntity中激活和使用phi"""
        # 构建BackendEntity
        kernel_ir = KernelIR(name="test_kernel")

        # Phi的scope_referrers：每个scope_id应该对应它实际使用的变量版本
        # branch-1使用var.1，branch-2使用var
        phi = PhiFuncIR(
            id="phi-integration",
            result_name="var",  # 原始变量名（作为索引key）
            referred_name=["var.1", "var"],  # 需要合并的版本
            scope_referrers={"branch-1": "var.1", "branch-2": "var"}
        )

        kernel_ir.phi_func_dict = {
            "branch-1": [phi],
            "branch-2": [phi]
        }

        variable_ctx = {"var": 0}
        backend_entity = backend_entity_build(kernel_ir, variable_ctx, task_kernel=False)

        # 验证phi_func_by_name正确索引
        assert "var" in backend_entity.eval_ctx.phi_func_by_name

        # 获取phi实体
        phi_entity = backend_entity.eval_ctx.phi_func_by_name["var"]
        assert hasattr(phi_entity, 'activated_name'), "phi_func_by_name应该包含PhiFuncEntity"

        # 激活branch-1 - 应该激活var.1
        backend_entity.eval_ctx.activate_phi("branch-1")
        assert phi_entity.activated_name == "var.1"

        # 获取合并后的变量名
        merged_name = backend_entity.eval_ctx._get_merge_phi_name("var")
        assert merged_name == "var.1"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])