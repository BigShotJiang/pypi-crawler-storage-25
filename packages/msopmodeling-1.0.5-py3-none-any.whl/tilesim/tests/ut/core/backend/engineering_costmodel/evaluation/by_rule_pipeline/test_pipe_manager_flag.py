# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
"""
Unit tests for set_flag/wait_flag synchronization in PipeManager

This file tests the flag-based synchronization mechanism used for
AIC/AIV core synchronization in the engineering cost model.
"""

import pytest
from core.backend.engineering_costmodel.evaluation.by_rule_pipeline.pipe_manager import (
    PipeManager, CoreUnitPipeKey
)
from core.common.entity import CoreUnit, CoreType


class TestCoreUnitPipeKey:
    """Test CoreUnitPipeKey hashing and equality"""

    def test_hash_with_core_unit(self):
        """CoreUnitPipeKey should be hashable with CoreUnit"""
        key1 = CoreUnitPipeKey(CoreUnit.CUBE, 0)
        key2 = CoreUnitPipeKey(CoreUnit.CUBE, 0)
        assert hash(key1) == hash(key2)
        assert key1 == key2

    def test_hash_with_different_core_index(self):
        """Different core indices should produce different hashes"""
        key1 = CoreUnitPipeKey(CoreUnit.CUBE, 0)
        key2 = CoreUnitPipeKey(CoreUnit.CUBE, 1)
        assert hash(key1) != hash(key2)
        assert key1 != key2

    def test_hash_with_different_core_unit(self):
        """Different core units should produce different hashes"""
        key1 = CoreUnitPipeKey(CoreUnit.CUBE, 0)
        key2 = CoreUnitPipeKey(CoreUnit.VEC, 0)
        assert hash(key1) != hash(key2)
        assert key1 != key2

    def test_hash_with_string_key(self):
        """CoreUnitPipeKey should work with string keys"""
        key1 = CoreUnitPipeKey("tensor_0", 0)
        key2 = CoreUnitPipeKey("tensor_0", 0)
        assert hash(key1) == hash(key2)
        assert key1 == key2


class TestSetFlagBasic:
    """Test basic set_flag functionality"""

    def test_set_flag_single_unit(self):
        """Setting flag for a single unit should record the time"""
        pm = PipeManager()
        pm.update_core_index(0)
        pm.update_pipe([CoreUnit.CUBE], 100.0)

        pm.set_unit_flag([CoreUnit.CUBE], "flag_0")

        assert "flag_0" in pm.unit_wait_manager
        key = CoreUnitPipeKey(CoreUnit.CUBE, 0)
        assert key in pm.unit_wait_manager["flag_0"]
        assert pm.unit_wait_manager["flag_0"][key] == 100.0

    def test_set_flag_multiple_units(self):
        """Setting flag for multiple units should record times for all

        Note: set_unit_flag uses last_op_finish which is updated by update_pipe.
        All units in the same set_flag call get the same last_op_finish time.
        """
        pm = PipeManager()
        pm.update_core_index(0)
        pm.update_pipe([CoreUnit.CUBE], 100.0)
        pm.update_pipe([CoreUnit.AIC_MTE1], 80.0)  # This updates last_op_finish to 80.0

        pm.set_unit_flag([CoreUnit.CUBE, CoreUnit.AIC_MTE1], "flag_0")

        assert "flag_0" in pm.unit_wait_manager
        cube_key = CoreUnitPipeKey(CoreUnit.CUBE, 0)
        mte1_key = CoreUnitPipeKey(CoreUnit.AIC_MTE1, 0)
        # Both units get last_op_finish time (80.0 from the last update_pipe)
        assert pm.unit_wait_manager["flag_0"][cube_key] == 80.0
        assert pm.unit_wait_manager["flag_0"][mte1_key] == 80.0

    def test_set_flag_multiple_flags(self):
        """Multiple flags should be tracked independently"""
        pm = PipeManager()
        pm.update_core_index(0)
        pm.update_pipe([CoreUnit.CUBE], 100.0)

        pm.set_unit_flag([CoreUnit.CUBE], "flag_0")
        pm.update_pipe([CoreUnit.CUBE], 200.0)
        pm.set_unit_flag([CoreUnit.CUBE], "flag_1")

        cube_key = CoreUnitPipeKey(CoreUnit.CUBE, 0)
        assert pm.unit_wait_manager["flag_0"][cube_key] == 100.0
        assert pm.unit_wait_manager["flag_1"][cube_key] == 200.0

    def test_set_flag_updates_last_op_finish(self):
        """set_flag should use last_op_finish time"""
        pm = PipeManager()
        pm.update_core_index(0)
        pm.update_pipe([CoreUnit.CUBE], 100.0)
        # last_op_finish should now be 100.0

        pm.set_unit_flag([CoreUnit.VEC], "flag_0")

        vec_key = CoreUnitPipeKey(CoreUnit.VEC, 0)
        # VEC wasn't updated, but last_op_finish was 100.0
        assert pm.unit_wait_manager["flag_0"][vec_key] == 100.0


class TestWaitFlagBasic:
    """Test basic wait_flag functionality"""

    def test_wait_flag_returns_max_time(self):
        """wait_flag should return the maximum time among all units"""
        pm = PipeManager()
        pm.update_core_index(0)
        pm.update_pipe([CoreUnit.CUBE], 100.0)
        pm.update_pipe([CoreUnit.AIC_MTE1], 150.0)

        pm.set_unit_flag([CoreUnit.CUBE, CoreUnit.AIC_MTE1], "flag_0")

        wait_time = pm.wait_unit_flag("flag_0")
        assert wait_time == 150.0

    def test_wait_flag_nonexistent_flag(self):
        """wait_flag for nonexistent flag raises ValueError

        Note: The current implementation raises ValueError when trying to get
        max of empty sequence. This is expected behavior for flags that were
        never set.
        """
        pm = PipeManager()

        with pytest.raises(ValueError):
            pm.wait_unit_flag("nonexistent_flag")

    def test_wait_flag_single_unit(self):
        """wait_flag for single unit should return that unit's time"""
        pm = PipeManager()
        pm.update_core_index(0)
        pm.update_pipe([CoreUnit.CUBE], 100.0)

        pm.set_unit_flag([CoreUnit.CUBE], "flag_0")

        wait_time = pm.wait_unit_flag("flag_0")
        assert wait_time == 100.0


class TestSetWaitFlagSynchronization:
    """Test set_flag/wait_flag synchronization scenarios"""

    def test_aic_aiv_sync_scenario(self):
        """Test typical AIC-AIV synchronization scenario

        Scenario: AIC produces data, AIV consumes it
        1. AIC computes and sets flag
        2. AIV waits for flag before consuming
        """
        pm = PipeManager()
        pm.update_core_index(0)

        # AIC operations
        pm.update_pipe([CoreUnit.AIC_MTE2], 10.0)   # Load data
        pm.update_pipe([CoreUnit.CUBE], 50.0)       # Compute
        pm.update_pipe([CoreUnit.AIC_FIXPIPE], 60.0)  # Store result

        # Set flag for AIV_MTE2 to indicate data is ready
        pm.set_unit_flag([CoreUnit.AIV_MTE2], "data_ready")

        # AIV waits for the flag
        wait_time = pm.wait_unit_flag("data_ready")
        assert wait_time == 60.0

        # AIV can now start after wait_time
        pm.update_pipe([CoreUnit.AIV_MTE2], wait_time + 20.0)  # AIV loads at 80.0

        assert pm.pipe_dict[CoreUnitPipeKey(CoreUnit.AIV_MTE2, 0)] == 80.0

    def test_multi_flag_sync_scenario(self):
        """Test multiple flags for different synchronization points"""
        pm = PipeManager()
        pm.update_core_index(0)

        # First synchronization point
        pm.update_pipe([CoreUnit.CUBE], 100.0)
        pm.set_unit_flag([CoreUnit.VEC], "sync_point_1")

        # Second synchronization point
        pm.update_pipe([CoreUnit.CUBE], 200.0)
        pm.set_unit_flag([CoreUnit.VEC], "sync_point_2")

        # Check both flags
        assert pm.wait_unit_flag("sync_point_1") == 100.0
        assert pm.wait_unit_flag("sync_point_2") == 200.0

    def test_flag_across_multiple_cores(self):
        """Test flag synchronization across multiple cores"""
        pm = PipeManager()

        # Core 0 sets flag
        pm.update_core_index(0)
        pm.update_pipe([CoreUnit.CUBE], 100.0)
        pm.set_unit_flag([CoreUnit.CUBE], "flag_0")

        # Core 1 sets same flag
        pm.update_core_index(1)
        pm.update_pipe([CoreUnit.CUBE], 150.0)
        pm.set_unit_flag([CoreUnit.CUBE], "flag_0")

        # Core 2 waits for flag - should get max from all cores
        pm.update_core_index(2)
        wait_time = pm.wait_unit_flag("flag_0")

        # Note: wait_unit_flag returns max of all entries for the flag
        assert wait_time == 150.0

    def test_flag_override_scenario(self):
        """Test flag override when set multiple times"""
        pm = PipeManager()
        pm.update_core_index(0)

        # First set
        pm.update_pipe([CoreUnit.CUBE], 100.0)
        pm.set_unit_flag([CoreUnit.CUBE], "flag_0")

        # Continue operations
        pm.update_pipe([CoreUnit.CUBE], 200.0)
        # Set same flag again (override)
        pm.set_unit_flag([CoreUnit.CUBE], "flag_0")

        # Wait should get the latest time
        wait_time = pm.wait_unit_flag("flag_0")
        assert wait_time == 200.0


class TestFlagWithDifferentUnits:
    """Test flag behavior with different CoreUnit types"""

    def test_flag_with_aic_units(self):
        """Test flag with AIC-specific units"""
        pm = PipeManager()
        pm.update_core_index(0)

        aic_units = [CoreUnit.CUBE, CoreUnit.AIC_MTE1, CoreUnit.AIC_MTE2, CoreUnit.AIC_FIXPIPE]
        for i, unit in enumerate(aic_units):
            pm.update_pipe([unit], float((i + 1) * 10))

        pm.set_unit_flag(aic_units, "aic_flag")

        wait_time = pm.wait_unit_flag("aic_flag")
        assert wait_time == 40.0  # FIXPIPE has the highest time

    def test_flag_with_aiv_units(self):
        """Test flag with AIV-specific units"""
        pm = PipeManager()
        pm.update_core_index(0)

        aiv_units = [CoreUnit.VEC, CoreUnit.AIV_MTE2, CoreUnit.AIV_MTE3]
        for i, unit in enumerate(aiv_units):
            pm.update_pipe([unit], float((i + 1) * 20))

        pm.set_unit_flag(aiv_units, "aiv_flag")

        wait_time = pm.wait_unit_flag("aiv_flag")
        assert wait_time == 60.0  # AIV_MTE3 has the highest time

    def test_flag_with_mixed_units(self):
        """Test flag with mixed AIC and AIV units"""
        pm = PipeManager()
        pm.update_core_index(0)

        # Simulate CV fused operation
        pm.update_pipe([CoreUnit.CUBE], 100.0)       # AIC compute
        pm.update_pipe([CoreUnit.AIC_FIXPIPE], 120.0)  # AIC output
        pm.update_pipe([CoreUnit.AIV_MTE2], 140.0)   # AIV load
        pm.update_pipe([CoreUnit.VEC], 200.0)        # AIV compute

        pm.set_unit_flag([CoreUnit.VEC, CoreUnit.CUBE], "cv_sync")

        wait_time = pm.wait_unit_flag("cv_sync")
        assert wait_time == 200.0


class TestFlagEdgeCases:
    """Test edge cases for flag operations"""

    def test_empty_unit_list(self):
        """Setting flag with empty unit list should create empty entry

        Note: wait_unit_flag raises ValueError for empty flag manager
        because max() of empty sequence is invalid.
        """
        pm = PipeManager()
        pm.update_core_index(0)
        pm.update_pipe([CoreUnit.CUBE], 100.0)

        pm.set_unit_flag([], "empty_flag")

        assert "empty_flag" in pm.unit_wait_manager
        assert len(pm.unit_wait_manager["empty_flag"]) == 0

        # wait raises ValueError for empty flag manager
        with pytest.raises(ValueError):
            pm.wait_unit_flag("empty_flag")

    def test_flag_before_any_operations(self):
        """Setting flag before any operations should record 0"""
        pm = PipeManager()
        pm.update_core_index(0)

        pm.set_unit_flag([CoreUnit.CUBE], "early_flag")

        cube_key = CoreUnitPipeKey(CoreUnit.CUBE, 0)
        assert pm.unit_wait_manager["early_flag"][cube_key] == 0.0

    def test_consecutive_flags_same_unit(self):
        """Test consecutive flag operations on same unit"""
        pm = PipeManager()
        pm.update_core_index(0)

        for i in range(5):
            pm.update_pipe([CoreUnit.CUBE], float(i * 100))
            pm.set_unit_flag([CoreUnit.CUBE], f"flag_{i}")

        # Verify all flags
        for i in range(5):
            wait_time = pm.wait_unit_flag(f"flag_{i}")
            assert wait_time == float(i * 100)


class TestFlagIntegrationWithPipeManager:
    """Test flag integration with other PipeManager operations"""

    def test_flag_with_update_pipe_working(self):
        """Test flag alongside update_pipe_working"""
        pm = PipeManager()
        pm.update_core_index(0)

        pm.update_pipe([CoreUnit.CUBE], 100.0)
        pm.update_pipe_working({CoreUnit.CUBE: 50.0})

        pm.set_unit_flag([CoreUnit.CUBE], "flag_0")

        wait_time = pm.wait_unit_flag("flag_0")
        assert wait_time == 100.0

        # pipe_working should not affect flag time
        assert pm.pipe_working_dict[CoreUnitPipeKey(CoreUnit.CUBE, 0)] == 50.0

    def test_flag_preserves_other_pipe_data(self):
        """Setting flags should not affect other pipe data"""
        pm = PipeManager()
        pm.update_core_index(0)

        pm.update_pipe([CoreUnit.CUBE], 100.0)
        pm.update_pipe([CoreUnit.VEC], 200.0)

        pm.set_unit_flag([CoreUnit.CUBE], "cube_flag")

        # VEC pipe should be unchanged
        vec_key = CoreUnitPipeKey(CoreUnit.VEC, 0)
        assert pm.pipe_dict[vec_key] == 200.0

        # CUBE pipe should be unchanged
        cube_key = CoreUnitPipeKey(CoreUnit.CUBE, 0)
        assert pm.pipe_dict[cube_key] == 100.0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])