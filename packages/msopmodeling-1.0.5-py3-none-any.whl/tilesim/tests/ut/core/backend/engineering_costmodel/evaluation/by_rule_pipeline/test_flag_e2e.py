# Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
"""
End-to-end tests for set_flag/wait_flag synchronization

This file tests the complete synchronization flow in realistic scenarios
that mimic actual operator usage patterns.
"""

import pytest
from core.backend.engineering_costmodel.evaluation.by_rule_pipeline.pipe_manager import (
    PipeManager, CoreUnitPipeKey
)
from core.common.entity import CoreUnit, CoreType


class TestFlashAttentionSyncPattern:
    """Test synchronization pattern similar to FlashAttention

    FlashAttention uses set_flag/wait_flag for AIC-AIV synchronization:
    1. AIC computes QK matmul tiles
    2. set_flag notifies AIV that data is ready
    3. AIV wait_flag and computes softmax
    """

    def test_flash_attention_tile_sync(self):
        """Simulate FlashAttention tile synchronization"""
        pm = PipeManager()

        # Simulate multiple tiles (n_s2 tiles)
        n_tiles = 4
        pm.update_core_index(0)

        for tile_idx in range(n_tiles):
            # AIC computes QK matmul
            pm.update_pipe([CoreUnit.AIC_MTE2], tile_idx * 100.0 + 10.0)
            pm.update_pipe([CoreUnit.CUBE], tile_idx * 100.0 + 50.0)
            pm.update_pipe([CoreUnit.AIC_FIXPIPE], tile_idx * 100.0 + 60.0)

            # Set flag for this tile
            flag_id = f"qk_tile_{tile_idx}"
            pm.set_unit_flag([CoreUnit.AIV_MTE2], flag_id)

        # Verify all flags are set
        assert len(pm.unit_wait_manager) == n_tiles

        # AIV waits for each tile and processes
        for tile_idx in range(n_tiles):
            flag_id = f"qk_tile_{tile_idx}"
            wait_time = pm.wait_unit_flag(flag_id)

            # AIV should start after the tile is ready
            expected_ready = tile_idx * 100.0 + 60.0
            assert wait_time == expected_ready

            # AIV processes softmax
            aiv_start = wait_time + 5.0  # Small delay
            pm.update_pipe([CoreUnit.AIV_MTE2], aiv_start + 10.0)
            pm.update_pipe([CoreUnit.VEC], aiv_start + 50.0)

    def test_flash_attention_double_buffer_sync(self):
        """Test double buffering pattern with flags"""
        pm = PipeManager()
        pm.update_core_index(0)

        # Double buffer: while AIC computes tile N+1, AIV processes tile N
        total_tiles = 8

        for i in range(total_tiles):
            # AIC always ahead by one tile
            aic_finish = (i + 1) * 100.0
            pm.update_pipe([CoreUnit.CUBE], aic_finish)
            pm.set_unit_flag([CoreUnit.AIV_MTE2], f"tile_{i}")

            # AIV waits and processes previous tile (if not first)
            if i > 0:
                prev_flag = f"tile_{i-1}"
                wait_time = pm.wait_unit_flag(prev_flag)
                # AIV should be able to overlap with AIC
                pm.update_pipe([CoreUnit.VEC], wait_time + 80.0)

        # Verify final state
        assert len(pm.unit_wait_manager) == total_tiles


class TestMoeExpertParallelSync:
    """Test synchronization pattern for MoE expert parallelism"""

    def test_expert_dispatch_sync(self):
        """Simulate MoE expert dispatch synchronization"""
        pm = PipeManager()

        num_experts = 4
        num_cores = 2

        # Each core handles different experts
        for core_idx in range(num_cores):
            pm.update_core_index(core_idx)

            for expert_idx in range(num_experts // num_cores):
                # Compute expert dispatch
                pm.update_pipe([CoreUnit.VEC], (expert_idx + 1) * 50.0)

                # Set flag for expert completion
                expert_id = expert_idx * num_cores + core_idx
                pm.set_unit_flag([CoreUnit.AIV_MTE3], f"expert_{expert_id}_done")

        # Combine step waits for all experts
        pm.update_core_index(0)
        all_flags = [f"expert_{i}_done" for i in range(num_experts)]

        # Each flag should have the correct completion time
        for i, flag in enumerate(all_flags):
            wait_time = pm.wait_unit_flag(flag)
            # Verify the flag was set correctly
            assert flag in pm.unit_wait_manager


class TestPipelineParallelSync:
    """Test synchronization for pipeline parallelism scenarios"""

    def test_stage_boundary_sync(self):
        """Test synchronization at pipeline stage boundaries"""
        pm = PipeManager()
        pm.update_core_index(0)

        # Stage 1: AIC computation
        stage1_ops = [
            (CoreUnit.AIC_MTE2, 10.0),
            (CoreUnit.CUBE, 100.0),
            (CoreUnit.AIC_FIXPIPE, 120.0),
        ]
        for unit, time in stage1_ops:
            pm.update_pipe([unit], time)

        # Stage 1 complete, signal Stage 2
        pm.set_unit_flag([CoreUnit.AIV_MTE2, CoreUnit.VEC], "stage1_complete")

        # Stage 2: AIV computation waits for Stage 1
        sync_time = pm.wait_unit_flag("stage1_complete")
        assert sync_time == 120.0

        stage2_ops = [
            (CoreUnit.AIV_MTE2, sync_time + 10.0),
            (CoreUnit.VEC, sync_time + 100.0),
        ]
        for unit, time in stage2_ops:
            pm.update_pipe([unit], time)

        # Verify final timing
        vec_key = CoreUnitPipeKey(CoreUnit.VEC, 0)
        assert pm.pipe_dict[vec_key] == 220.0  # 120 + 100

    def test_multi_stage_pipeline(self):
        """Test multi-stage pipeline with multiple sync points"""
        pm = PipeManager()
        pm.update_core_index(0)

        num_stages = 3
        stage_duration = 100.0

        current_time = 0.0
        for stage in range(num_stages):
            # Alternate between AIC and AIV stages
            if stage % 2 == 0:
                compute_unit = CoreUnit.CUBE
                sync_units = [CoreUnit.AIV_MTE2]
            else:
                compute_unit = CoreUnit.VEC
                sync_units = [CoreUnit.AIC_MTE2]

            # Compute
            current_time += stage_duration
            pm.update_pipe([compute_unit], current_time)

            # Sync point
            flag_id = f"stage_{stage}_done"
            pm.set_unit_flag(sync_units, flag_id)

        # Verify all stages completed
        assert len(pm.unit_wait_manager) == num_stages

        # Verify sync times
        for stage in range(num_stages):
            sync_time = pm.wait_unit_flag(f"stage_{stage}_done")
            assert sync_time == (stage + 1) * stage_duration


class TestConcurrentKernelSync:
    """Test synchronization for concurrent kernel execution"""

    def test_independent_kernels_with_sync(self):
        """Test independent kernels that need to sync at a point"""
        pm = PipeManager()

        # Kernel A on core 0
        pm.update_core_index(0)
        pm.update_pipe([CoreUnit.CUBE], 100.0)
        pm.update_pipe([CoreUnit.AIC_FIXPIPE], 110.0)
        pm.set_unit_flag([CoreUnit.VEC], "kernel_a_done")

        # Kernel B on core 1
        pm.update_core_index(1)
        pm.update_pipe([CoreUnit.CUBE], 150.0)
        pm.update_pipe([CoreUnit.AIC_FIXPIPE], 160.0)
        pm.set_unit_flag([CoreUnit.VEC], "kernel_b_done")

        # Merge kernel waits for both
        pm.update_core_index(2)
        a_done = pm.wait_unit_flag("kernel_a_done")
        b_done = pm.wait_unit_flag("kernel_b_done")

        # Merge can start after both kernels complete
        merge_start = max(a_done, b_done)
        assert merge_start == 160.0

        pm.update_pipe([CoreUnit.VEC], merge_start + 50.0)

    def test_producer_multiple_consumers(self):
        """Test one producer signaling multiple consumers"""
        pm = PipeManager()
        pm.update_core_index(0)

        # Producer computes
        pm.update_pipe([CoreUnit.CUBE], 100.0)
        pm.update_pipe([CoreUnit.AIC_FIXPIPE], 110.0)

        # Signal multiple consumer units
        consumer_units = [CoreUnit.AIV_MTE2, CoreUnit.VEC, CoreUnit.AIV_MTE3]
        pm.set_unit_flag(consumer_units, "data_ready")

        # All consumers wait and get the same time
        wait_time = pm.wait_unit_flag("data_ready")
        assert wait_time == 110.0

        # Verify all units are in the flag
        flag_manager = pm.unit_wait_manager["data_ready"]
        for unit in consumer_units:
            key = CoreUnitPipeKey(unit, 0)
            assert key in flag_manager


class TestSyncTimingCorrectness:
    """Test timing correctness of synchronization"""

    def test_no_sync_overhead(self):
        """Verify that sync operations don't add artificial delays"""
        pm = PipeManager()
        pm.update_core_index(0)

        # Compute without sync
        pm.update_pipe([CoreUnit.CUBE], 100.0)
        time_before_sync = pm.last_op_finish

        # Set and wait flag
        pm.set_unit_flag([CoreUnit.VEC], "flag_0")
        wait_time = pm.wait_unit_flag("flag_0")

        assert wait_time == time_before_sync
        assert pm.last_op_finish == time_before_sync  # No change from sync ops

    def test_sync_respects_max_time(self):
        """Verify sync returns max time when multiple units involved"""
        pm = PipeManager()
        pm.update_core_index(0)

        # Different units finish at different times
        pm.update_pipe([CoreUnit.CUBE], 100.0)
        pm.update_pipe([CoreUnit.AIC_MTE1], 80.0)
        pm.update_pipe([CoreUnit.AIC_MTE2], 120.0)

        # Last update was AIC_MTE2 at 120.0
        pm.set_unit_flag([CoreUnit.CUBE, CoreUnit.AIC_MTE1, CoreUnit.AIC_MTE2], "multi_flag")

        wait_time = pm.wait_unit_flag("multi_flag")
        # All units get last_op_finish (120.0), so max is 120.0
        assert wait_time == 120.0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])