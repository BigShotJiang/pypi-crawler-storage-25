#!/usr/bin/python3
# -*- coding: utf-8 -*-
# -------------------------------------------------------------------------
# This file is part of the MindStudio project.
# Copyright (c) 2025 Huawei Technologies Co.,Ltd.
#
# MindStudio is licensed under Mulan PSL v2.
# You can use this software according to the terms and conditions of the Mulan PSL v2.
# You may obtain a copy of Mulan PSL v2 at:
#
#          http://license.coscl.org.cn/MulanPSL2
#
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND,
# EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT,
# MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
# See the Mulan PSL v2 for more details.
# -------------------------------------------------------------------------
import json
import os


class ConfigLoader:
    """负责输入 JSON 配置的加载与 accelerator 路径解析。"""

    def __init__(self, arc_config_dir: str):
        """
        Args:
            arc_config_dir: tilesim 内置 arc_config 目录的绝对路径，
                            用于按芯片型号自动搜索 YAML 文件。
        """
        self._arc_config_dir = arc_config_dir

    def load(self, json_path: str) -> list[dict]:
        """从 JSON 文件加载配置列表，并将 accelerator 相对路径转为绝对路径。

        Args:
            json_path: 输入 JSON 文件路径（绝对或相对路径均可）。

        Raises:
            FileNotFoundError: 文件不存在。
            json.JSONDecodeError: JSON 格式错误。
        """
        abs_path = os.path.abspath(json_path)
        base_dir = os.path.dirname(abs_path)
        with open(abs_path, "r", encoding="utf-8") as f:
            configs = json.load(f)
        for cfg in configs:
            accelerator = cfg.get("accelerator", "")
            if accelerator:
                try:
                    cfg["accelerator"] = self._find_accelerator(accelerator, base_dir)
                except FileNotFoundError as e:
                    raise FileNotFoundError(
                        f"配置项 '{cfg.get('op_name', '?')}' 的 accelerator 无法解析:\n  {e}"
                    ) from e
        return configs

    def apply_soctype(self, configs: list[dict], soctype: str) -> list[dict]:
        """查找 <soctype>.yaml 并覆盖所有配置中的 accelerator 字段。

        返回覆盖后的新配置列表（不修改原列表中的对象引用，逐项更新字段）。

        Args:
            configs: 已加载的配置列表。
            soctype: 芯片型号，如 "910B1"、"910B4"。

        Raises:
            FileNotFoundError: 在 arc_config_dir 下找不到对应 YAML 文件。
        """
        yaml_abs = self._find_accelerator(f"{soctype}.yaml", self._arc_config_dir)
        for cfg in configs:
            cfg["accelerator"] = yaml_abs
        return configs

    def _find_accelerator(self, accelerator: str, base_dir: str) -> str:
        """三级优先级路径解析。

        1. 绝对路径 → 直接返回（不校验是否存在，由调用方决定）
        2. 相对路径 → 先尝试相对于 base_dir
        3. 若不存在 → 在 arc_config_dir 下递归查找同名文件

        Raises:
            FileNotFoundError: 三级查找均未命中时抛出，含明确的搜索路径提示。
        """
        if os.path.isabs(accelerator):
            return accelerator

        candidate = os.path.normpath(os.path.join(base_dir, accelerator))
        if os.path.exists(candidate):
            return candidate

        filename = os.path.basename(accelerator)
        for root, _, files in os.walk(self._arc_config_dir):
            if filename in files:
                return os.path.join(root, filename)

        raise FileNotFoundError(
            f"找不到 accelerator 配置文件 '{filename}'。\n"
            f"  已查找路径: {candidate}\n"
            f"  已递归搜索: {self._arc_config_dir}"
        )
