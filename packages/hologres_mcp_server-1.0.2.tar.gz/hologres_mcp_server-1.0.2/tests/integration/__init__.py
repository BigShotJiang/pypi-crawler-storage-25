"""Integration tests for Hologres MCP Server."""
