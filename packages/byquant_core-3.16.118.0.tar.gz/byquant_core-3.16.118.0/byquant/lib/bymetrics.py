#!/usr/bin/env python
# -*- coding: utf-8; py-indent-offset:4 -*-
###############################################################################
#
# Author : Algoor
# Email : info@algoor.com
# Copyright (C) 2015-2024 Algoor.com
#
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
###############################################################################

#from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from byquant import auth as byauth

def byMetrics(arr1,arr2):
    # mae = mean_absolute_error(arr1, arr2)
    # mse = mean_squared_error(arr1, arr2)
    # r2s = r2_score(arr1, arr2)
    # result = {}
    # result['MAE'] = mae
    # result['MSE'] = mse
    # result['R2S'] = r2s
    # return result
    return None
    
    
    
    
    