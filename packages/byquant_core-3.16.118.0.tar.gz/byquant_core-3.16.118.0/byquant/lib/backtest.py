#!/usr/bin/env python
# -*- coding: utf-8; py-indent-offset:4 -*-
###############################################################################
#
# Author : Algoor
# Email : info@algoor.com
# Copyright (C) 2015-2024 Algoor.com
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
###############################################################################



 
from __future__ import (absolute_import, division, print_function,unicode_literals)
import backtrader as bt
import numpy as np
#from analysis import *
from byquant import analysis as analysis
from byquant import auth as byauth

def getPkwargs():
    if byauth.get()[0] > 0:
        pkwargs = dict(
                    
            iplot=True,
            numfigs=1,
            # to have a tight packing on the chart wether only the x axis or also
            # the y axis have (see matplotlib)
            ytight = False,
            # y-margin (top/bottom) for the subcharts. This will not overrule the
            # option plotinfo.plotymargin
            yadjust = 0.0,
            # Each new line is in z-order below the previous one. change it False
            # to have lines paint above the previous line
            zdown = True,
            # Rotation of the date labes on the x axis
            tickrotation = 15,
            # How many "subparts" takes a major chart (datas) in the overall chart
            # This is proportional to the total number of subcharts
            rowsmajor = 5,
            # How many "subparts" takes a minor chart (indicators/observers) in the
            # overall chart. This is proportional to the total number of subcharts
            # Together with rowsmajor, this defines a proportion ratio betwen data
            # charts and indicators/observers charts
            rowsminor = 1,
            # Distance in between subcharts
            plotdist = 0.0,
            # Have a grid in the background of all charts
            grid = False,
            # Default plotstyle for the OHLC bars which (line -> line on close)
            # Other options: 'bar' and 'candle'
            #style = self.style,
            style = 'candle',
            # Default color for the 'line on close' plot
            loc = '#206BC4',
            # Default color for a bullish bar/candle (0.75 -> intensity of gray)
            barup = '#F8A488', ##206BC4
            # Default color for a bearish bar/candle
            bardown = '#8FB5E1', ##F14A12
            # Level of transparency to apply to bars/cancles (NOT USED)
            bartrans = 0.50,
            # Wether the candlesticks have to be filled or be transparent
            barupfill = True,
            bardownfill = False,
            # Wether the candlesticks have to be filled or be transparent
            fillalpha = 0.20,
            # Wether to plot volume or not. Note: if the data in question has no
            # volume values, volume plotting will be skipped even if this is True
            volume = True,
            # Wether to overlay the volume on the data or use a separate subchart
            voloverlay = True,
            # Scaling of the volume to the data when plotting as overlay
            volscaling = 0.33,
            # Pushing overlay volume up for better visibiliy. Experimentation
            # needed if the volume and data overlap too much
            volpushup = 0.00,
            # Default colour for the volume of a bullish day
            volup = (253/255,237/255,231/255,0.5),
            # 0.66 of gray
            # Default colour for the volume of a bearish day
            voldown = (232/255,240/255,247/255,0.5),
            # (204, 96, 115)
            # Transparency to apply to the volume when overlaying
            voltrans = 0.50,
            # Transparency for text labels (NOT USED CURRENTLY)
            subtxttrans = 0.88,
            # Default font text size for labels on the chart
            subtxtsize = 8,
            # Transparency for the legend (NOT USED CURRENTLY)
            legendtrans = 0.25,
            # Wether indicators have a leged displaey in their charts
            legendind = True,
            # Location of the legend for indicators (see matplotlib)
            legendindloc = 'upper left',
            # Plot the last value of a line after the Object name
            linevalues = True,
            # Plot a tag at the end of each line with the last value
            valuetags = True,
            # Default color for horizontal lines (see plotinfo.plothlines)
            hlinescolor = '0.88',
            # shade of gray
            # Default style for horizontal lines
            hlinesstyle = '--',
            # Default width for horizontal lines
            hlineswidth = 0.5,
            # Default color scheme: Tableau 10
            #lcolors = tableau10,
            # strftime Format string for the display of ticks on the x axis
            #fmt_x_ticks = None,
            # strftime Format string for the display of data points values
            #fmt_x_data = None,
            
            fmt_x_ticks="%Y-%m-%d %H:%M:%S", 
            fmt_x_data="%Y-%m-%d %H:%M:%S"
    
           )
    else:
        pkwargs = dict()
        
    return pkwargs
               
class Trades(bt.observers.Trades):
    plotlines = dict(
    pnlplus=dict(_name='Positive',
                 marker='o', color='#F05824',
                 markersize=5.0, fillstyle='full'),
    pnlminus=dict(_name='Negative',
                  marker='o', color='#009344',
                  markersize=5.0, fillstyle='none'))
                  
# 修改 BuySell 的样式
class ByQuant_com(bt.observers.BuySell):
    
    params = (('barplot', True), ('bardist', 0.05))
    
    plotlines = dict(
    #buy=dict(marker=r'$\Uparrow$', markersize=10.0, color='#F05824' ),
    #sell=dict(marker=r'$\Downarrow$', markersize=10.0, color='#009344'))
    buy=dict(marker='^', markersize=5.0, color='#F05824' ),
    sell=dict(marker='v', markersize=5.0, color='#009344'))

class Orders(bt.observer.Observer):
    lines = ('created', 'expired',)
 
    plotinfo = dict(plot=True, subplot=True, plotlinelabels=True)
 
    plotlines = dict(
        created=dict(marker='*', markersize=8.0, color='#206BC4', fillstyle='none'),
        expired=dict(marker='o', markersize=8.0, color='#F05824', fillstyle='full')
    )
    
 
    def next(self):
        for order in self._owner._orderspending:
            if order.data is not self.data:
                continue
 
            if not order.isbuy():
                continue
 
            # Only interested in "buy" orders, because the sell orders
            # in the strategy are Market orders and will be immediately
            # executed
 
            if order.status in [bt.Order.Accepted, bt.Order.Submitted]:
                self.lines.created[0] = order.created.price
 
            elif order.status in [bt.Order.Expired]:
                self.lines.expired[0] = order.created.price
        
class Balance(bt.observers.Broker):
    #alias = ('CashValue',)
    lines = ('cash', 'value')
    
    plotinfo = dict(plot=True, subplot=True)
    
    plotlines = dict(
        cash=dict(_name='Cash',linestyle='-', linewidth=1.0, color='#F05824'),
        #value=dict(_method='bar', color='#206BC4', alpha=0.50, width=1.0),
        value=dict(_name='Value',linestyle='-', linewidth=1.0, color='#206BC4'),
        #value=dict(_method='bar', color='#F05824', alpha=0.10, width=1.0),
    )
    
    #def next(self):
    #    self.lines.cash[0] = self._owner.broker.getcash()
    #    self.lines.value[0] = self._owner.broker.getvalue()
        #self.lines.capital[0] = self.lines.cash[0] + self.lines.value[0]
        #print(self.lines.cash[-1])
    

        
class DrawDown(bt.observers.DrawDown):

    plotlines = dict(
        #drawdown=dict(linestyle='-', linewidth=1.0, color='#009344'),
        drawdown=dict(_name='Drawdown',_method='bar', color='#206BC4', alpha=0.5, width=1.0)
    )
    
    #def next(self):
    #    self.lines.cash[0] = self._owner.broker.getcash()
    #    self.lines.value[0] = value = self._owner.broker.getvalue()
    
"""class byTimeReturn(bt.observers.TimeReturn):

    plotlines = dict(
        timereturn=dict(linestyle='-', linewidth=1.0, color='#F05824'),
        #timereturn=dict(_method='bar', color='#F05824',  width=1.0)
    )"""

class Backtest_ByQuant(bt.observer.Observer):
    #alias = ('CashValue',)
    lines = ('profit', 'loss')
    #profit/loss
    plotinfo = dict(plot=True, subplot=True)
    
    plotlines = dict(
        #cash=dict(linestyle='-', linewidth=1.0, color='#F05824'),
        #value=dict(_method='bar', color='#206BC4', alpha=0.50, width=1.0),
        #value=dict(linestyle='-', linewidth=1.0, color='#206BC4'),
        profit=dict(_name='Profit Ratio',_method='bar', color='#F37950', alpha=1, width=1.0),
        loss=dict(_name='Loss Ratio',_method='bar', color='#33A96A', alpha=1, width=1.0),
    )
    
    #def __init__(self):
    #    self.startcash = 0
        
    def start(self):
        self.startcash = self._owner.broker.getcash()
        
    
    #def prenext(self):
        #print('C',self._owner.broker.getcash())
        #print('V',self._owner.broker.getvalue())
        
    def next(self):
        
        profit_loss = (self._owner.broker.getvalue() - self.startcash) / self.startcash
        
        if profit_loss > 0:
            self.lines.profit[0] = profit_loss
            self.lines.loss[0] = np.nan
        else:
            self.lines.profit[0] = np.nan
            self.lines.loss[0] = profit_loss
            

        #self.lines.profit[0] = (self._owner.broker.getvalue() - self.startcash) / self.startcash
        #self.lines.loss[0] = (self._owner.broker.getvalue() - self.startcash) / self.startcash
        #print(self.lines.returns[0])
        #self.lastcash = self._owner.broker.getcash()
        #self.lastvalue = self._owner.broker.getvalue()
        #self.lines.cumreturns[0] = self.lines.cumreturns[-1] + self.lines.returns[0]
        #print(self.lines.cash[-1])
 
    

        

