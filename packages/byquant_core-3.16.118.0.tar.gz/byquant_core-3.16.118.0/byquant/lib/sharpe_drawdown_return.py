#!/usr/bin/env python
# -*- coding: utf-8; py-indent-offset:4 -*-
###############################################################################
#
# Copyright (C) 2022-2023 ByQuant.com
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
###############################################################################

#import talib
import pandas as pd
#import backtrader as bt
import numpy as np
#from byquant import auth as byauth


#计算夏普率、最大回撤、年化收益率
def baSR_DD_AR(data,period=252):
    #公式 夏普率 = (回报率均值 - 无风险率) / 回报率的标准差 *无风险利率 3%，日平均忽略不计
    # pct_change()是pandas里面的自带的计算每日增长率的函数，它和calculate_profit_pct函数功能是一样的，用于计算股票的单次收益率。
    if period == 252:
        close = data.copy()[-period:]
    else:
        close = data.copy()
    daily_return = close.pct_change()
    
    avg_return = daily_return.mean() # 回报率均值 
    std_return = daily_return.std() # 回报率标准差
    sharp = avg_return / std_return #计算夏普
    sharp_ratio = sharp * np.sqrt(period) #period=252时为年化夏普比率 #计算夏普 年华夏普
    
    cumulative = 1*(1+daily_return).cumprod() # 计算累计收益
    max_return = cumulative.cummax() # 计算回撤序列
    drawdown = (cumulative - max_return) / max_return
    max_drawdown = drawdown.min()
    
    returns_periodic_mean = ((1+daily_return).prod())**(1/daily_return.shape[0])-1
    annualize_returns = (1+returns_periodic_mean)**period-1
    
    return sharp_ratio,max_drawdown,annualize_returns

    

def SR_DD_AR(data,period=252):
    if isinstance(data, pd.DataFrame):
        return baSR_DD_AR(data.close,period=period)
    elif isinstance(data, (pd.Series,np.ndarray)):
        return baSR_DD_AR(data,period=period)
    elif 'trader.' in str(type(data)):
        return None
    else:
        return None



sr_dd_ar = SR_DD_AR
#AROON_NP = AROON


#计算夏普率
def baSharpeRatio(data,period=252):
    #公式 夏普率 = (回报率均值 - 无风险率) / 回报率的标准差 *无风险利率 3%，日平均忽略不计
    # pct_change()是pandas里面的自带的计算每日增长率的函数，它和calculate_profit_pct函数功能是一样的，用于计算股票的单次收益率。
    if period == 252:
        close = data.copy()[-period:]
    else:
        close = data.copy()
    daily_return = close.pct_change()
    # 回报率均值 
    avg_return = daily_return.mean()
    # 回报率标准差
    std_return = daily_return.std()
    #计算夏普
    sharp = avg_return / std_return
    #计算夏普 年华夏普
    sharp_ratio = sharp * np.sqrt(period) #period=252时为年化夏普比率
    return sharp_ratio

    

def SharpeRatio(data,period=252):
    if isinstance(data, pd.DataFrame):
        return baSharpeRatio(data.close,period=period)
    elif isinstance(data, (pd.Series,np.ndarray)):
        return baSharpeRatio(data,period=period)
    elif 'trader.' in str(type(data)):
        return None
    else:
        return None



sharperatio = SharpeRatio
#AROON_NP = AROON



def baDrawDown(data,period=252):
    if period == 252:
        close = data.copy()[-period:]
    else:
        close = data.copy()
    daily_return = close.pct_change()
    # 计算累计收益
    cumulative = 1*(1+daily_return).cumprod()
    # 计算回撤序列
    max_return = cumulative.cummax()
    
    drawdown = (cumulative - max_return) / max_return
    
    
    max_drawdown = drawdown.min()

    return max_drawdown
    

    

def DrawDown(data,period=252):
    if isinstance(data, pd.DataFrame):
        return baDrawDown(data.close,period=period)
    elif isinstance(data, (pd.Series,np.ndarray)):
        return baDrawDown(data,period=period)
    elif 'trader.' in str(type(data)):
        return None
    else:
        return None



drawdown = DrawDown
#AROON_NP = AROON



def baAnnualizeReturns(data,period=252):
    if period == 252:
        close = data.copy()[-period:]
    else:
        close = data.copy()
    daily_return = close.pct_change()
    
    returns_periodic_mean = ((1+daily_return).prod())**(1/daily_return.shape[0])-1
    
    annualize_returns = (1+returns_periodic_mean)**period-1
    
    return annualize_returns
    

    

def AnnualizeReturns(data,period=252):
    if isinstance(data, pd.DataFrame):
        return baAnnualizeReturns(data.close,period=period)
    elif isinstance(data, (pd.Series,np.ndarray)):
        return baAnnualizeReturns(data,period=period)
    elif 'trader.' in str(type(data)):
        return None
    else:
        return None



annualizereturns = AnnualizeReturns
#AROON_NP = AROON
