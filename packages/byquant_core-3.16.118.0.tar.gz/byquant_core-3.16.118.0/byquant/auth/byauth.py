# #!/usr/bin/env python
# # -*- coding: utf-8; py-indent-offset:4 -*-
# ###############################################################################
# #
# # Author : Trabi
# # Email : info@byquant.com
# # Copyright (C) 2022-2023 ByQuant.com
# #
# #  ███████   ██    ██   ██████   ██    ██    ████    ██    ██  ████████  
# #  ██    ██   ██  ██   ██    ██  ██    ██   ██  ██   ███   ██     ██     
# #  ███████     ████    ██    ██  ██    ██  ████████  ██ ██ ██     ██         █████  █████  █████
# #  ██    ██     ██     ██   ██   ██    ██  ██    ██  ██   ███     ██         █      █   █  █ █ █
# #  ███████      ██      ███████   ██████   ██    ██  ██    ██     ██     ██  █████  █████  █ █ █
# #
# # This program is free software: you can redistribute it and/or modify
# # it under the terms of the GNU General Public License as published by
# # the Free Software Foundation, either version 3 of the License, or
# # (at your option) any later version.
# #
# # This program is distributed in the hope that it will be useful,
# # but WITHOUT ANY WARRANTY; without even the implied warranty of
# # MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# # GNU General Public License for more details.
# #
# # You should have received a copy of the GNU General Public License
# # along with this program.  If not, see <http://www.gnu.org/licenses/>.
# #
# ###############################################################################


from __future__ import (absolute_import, division, print_function,unicode_literals)
from cachetools import cached, LRUCache,TTLCache
ttl_cache = TTLCache(maxsize=100, ttl=86400)
@cached(ttl_cache)
def info():
    __memberlevel = 5
    __expiredate = '2027-12-31'
    return __memberlevel,__expiredate
        
get = info

# from __future__ import (absolute_import, division, print_function,unicode_literals)

# #import pandas as pd
# import json
# import hashlib
# import requests
# from byquant import setting
# from cachetools import cached, LRUCache,TTLCache
# #import os
# #userAuth = by.user(token='******').auth()
# ttl_cache = TTLCache(maxsize=100, ttl=86400)
# @cached(ttl_cache)
# def info():
#     __memberlevel = 0
#     __expiredate = ''
#     __token = setting.BYQUANT_API_TOKEN
#     __tokencrypto = ''
#     #current_file_path = os.path.abspath(__file__)
#     params = {
#             #'api_name': api_name,
#             'token': __token,
#             'site': 'ByQuant.com',
#             #'fields': fields
#         }
        
#     res = requests.post('http://api.byquant.com/', params)
#     if res:
#         __result = json.loads(res.text)
#         __tokencrypto = __result['tokencrypto']
        
#         md5Str = str(hashlib.md5((__token + "@Trabi").encode("utf8")).hexdigest())
#         if md5Str == __tokencrypto:
#             __expiredate = __result['expiredate']
#             __memberlevel = __result['memberlevel']
            




#     return __memberlevel,__expiredate
        

# get = info

