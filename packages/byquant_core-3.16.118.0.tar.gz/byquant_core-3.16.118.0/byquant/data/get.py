#!/usr/bin/env python
# -*- coding: utf-8; py-indent-offset:4 -*-
###############################################################################
#
# Author : Trabi
# Email : info@byquant.com
# Copyright (C) 2022-2023 ByQuant.com
#
#  ███████   ██    ██   ██████   ██    ██    ████    ██    ██  ████████  
#  ██    ██   ██  ██   ██    ██  ██    ██   ██  ██   ███   ██     ██     
#  ███████     ████    ██    ██  ██    ██  ████████  ██ ██ ██     ██         █████  █████  █████
#  ██    ██     ██     ██   ██   ██    ██  ██    ██  ██   ███     ██         █      █   █  █ █ █
#  ███████      ██      ███████   ██████   ██    ██  ██    ██     ██     ██  █████  █████  █ █ █
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
###############################################################################

from __future__ import (absolute_import, division, print_function,unicode_literals)

import os
import time
#import ccxt
#import yfinance as yf
import tushare as ts
import akshare as ak
import baostock as bs
import pandas as pd
from datetime import date, datetime, timedelta
# from market import signals as tawSignal
#from alpaca.data.historical import CryptoHistoricalDataClient, StockHistoricalDataClient
#from alpaca.data.requests import CryptoBarsRequest, StockBarsRequest
#from alpaca.data.timeframe import TimeFrame
#from alpaca.trading.client import TradingClient
#from alpaca.trading.requests import GetAssetsRequest
#from alpaca.trading.enums import AssetClass
#from alpaca.trading.requests import GetOrdersRequest
#from alpaca.trading.enums import OrderSide, QueryOrderStatus
#from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest, StopOrderRequest, StopLimitOrderRequest, TrailingStopOrderRequest
#from alpaca.data.requests import CryptoLatestQuoteRequest

# from alpaca.broker.models import Contact, Identity, Disclosures, Agreement
# from alpaca.broker.requests import CreateAccountRequest
# from alpaca.broker.enums import TaxIdType, FundingSource, AgreementType
# from alpaca.broker.requests import CreateJournalRequest
# from alpaca.broker.enums import JournalEntryType
# from alpaca.broker.client import BrokerClient
# from alpaca.broker.requests import CreateACHTransferRequest
# from alpaca.broker.enums import TransferDirection, TransferTiming
# from alpaca.trading.enums import OrderSide, TimeInForce

# from alpaca.broker.requests import CreateACHRelationshipRequest
# from alpaca.broker.enums import BankAccountType
# import byquant
#from byquant import exchange
from byquant import auth as byauth
from pathlib import Path

# from market import models as marketModels

class Bar():

    def __init__(self, symbol, ktype='quote', freq='1d', renew=True, cachetime=86400, start='', end='', limit=1000,source='',token='', fields=[]):
        
        self.authInfo = byauth.get()
        if not byauth.get()[0] > 0:
            print('*** Start ByQuant.com Data Engine ***')
        self.symbol = symbol
        #print(f'Bar: {self.symbol}')
        if self.symbol in ['symbol','symbol1','symbol2','stock','cnstock','symbola','symbolb']:
            self.symbol = '600519.SSEs'
        elif self.symbol in ['fund']:
            self.symbol = '600519.SSEs'
        elif self.symbol in ['future','future_code']:
            self.symbol = '600519.SSEs'
        elif self.symbol in ['option']:
            self.symbol = '600519.SSEs'
        elif self.symbol in ['index','indexus','indexcn']:
            self.symbol = '000016.SSEi'
        # else:
        #     self.symbol = '600519.SSEs' #AAPL.NASDAQ


        
        self.market = ''
        self.offset = 0
        self.ktype = ktype
        self.freq = freq
        self.start = start
        self.end = end
        if self.start != '' and self.end == '':
                self.end = date.today()
        #print(self.start)
        #print(self.end)
        self.limit=limit
        self.cachetime = cachetime
        self.renew = renew
        self.fields = fields
        #print(self.symbol)
        self.underlying_ex, self.underlying, self.exchange, self.market = self.parse_symbol(self.symbol)

        #self.MARKET_DATA_PATH = '~/.byquant/%s/' % (self.ktype)
        self.MARKET_DATA_PATH = '.byquant/%s/' % (self.ktype)
        self.filedir = self.MARKET_DATA_PATH + '%s/%s/' % (self.exchange, self.freq)
        dir_path = Path(self.filedir)
        dir_path.mkdir(parents=True, exist_ok=True)
        #self.filepath = self.filedir + '%s.csv' % (self.symbol.replace('.' + self.exchange, ''))
        self.filepath = self.filedir + '%s.csv' % (self.symbol.replace('.', '_'))
        

        
        
        self.source = source
        self.token = token
        #print(self.token)


    def parse_symbol(self,converted_symbol):
        converted_symbol = converted_symbol.replace('~', '/').replace('$', ':')

        if '.' not in converted_symbol:
            raise ValueError(f"Invalid symbol format: {converted_symbol}")
        
        # 拆分代码和交易所市场部分
        underlying, exchange_market = converted_symbol.split('.', 1)
        
        # 定义交易所反向映射规则
        reverse_exchange_mapping = {
            'SSE': 'SH',
            'SZSE': 'SZ',
            'GFEX': 'GFE',
            'DCE': 'DCE',
            'CZCE': 'ZCE',
            'INE': 'INE',
            'SHFE': 'SHF',
            'CFFEX': 'CFX',
            'BSE': 'BJ'
        }

        # Define valid market types and their full names
        market_mapping = {
            's': 'stock',
            'f': 'future',
            'o': 'option',
            'e': 'fund',
            'm': 'margin',
            'i': 'index'
        }
        
        
        # 初始化市场类型为默认值 's'
        market_code = 's'
        market = 'stock'
        exchange = exchange_market
        
        # 检查最后一个字符是否是有效的市场类型
        if exchange_market and exchange_market[-1] in market_mapping:
            market_code = exchange_market[-1]
            market = market_mapping[market_code]
            exchange = exchange_market[:-1]
        
        # 验证交易所全称是否有效
        if exchange not in reverse_exchange_mapping:
            raise ValueError(f"Unknown exchange: {exchange}")
        
        # 获取交易所前缀
        exchange_prefix = reverse_exchange_mapping[exchange]
        
        # 构建原始代码
        symbol = f"{underlying}.{exchange_prefix}"
        
        return symbol, underlying ,exchange, market

    def quote(self):

        #print('001')

        file_path = Path(self.filepath)
        if not file_path.exists() or self.cachetime == 0:
            result = self.createQuote()
        #elif self.haskey == 'no':
        #    result = self.createQuote()
        elif self.renew == False:
            result = self.readCSV()
        else:
            stat = file_path.stat()
            fileTime = stat.st_ctime

            #fileTime = int(os.path.getmtime(self.filepath))
            nowTime = time.time()
            expireTime = fileTime + self.cachetime
            if nowTime > expireTime:
                result = self.updateQuote()
            else:
                result = self.readCSV()

        result = self.filterQuote(result)

        return result
    
    def indexstock(self):

        file_path = Path(self.filepath)
        if not file_path.exists() or self.cachetime == 0:
            result = self.createIndexStocks()
        elif self.renew == False:
            result = self.readCSV()
        else:
            stat = file_path.stat()
            fileTime = stat.st_ctime

            #fileTime = int(os.path.getmtime(self.filepath))
            nowTime = time.time()
            expireTime = fileTime + self.cachetime
            if nowTime > expireTime:
                result = self.updateIndexStocks()
            else:
                result = self.readCSV()

        #result = self.filterQuote(result)

        return result
    
    def filterQuote(self, data):
        
        # First check if data is empty or not a DataFrame
        if not isinstance(data, pd.DataFrame) or data.empty:
            return pd.DataFrame()  # Return empty DataFrame if no valid data
        
        # Now we can safely assume data is a DataFrame
        if "quote_time" in data.columns:
            data.rename(columns={"quote_time": "datetime"}, inplace=True)
            
        data['datetime'] = pd.to_datetime(data['datetime'])
        data = data.sort_values('datetime')  # 数据顺序排列

        if self.start != '':
            #print(pd.to_datetime(self.start, format='%Y-%m-%d'))
            #print(pd.to_datetime(data['datetime'], format='%Y%m%d%H%M%S%f'))
            
            if self.freq == '1d':
                data = data[(data['datetime'] >= pd.to_datetime(self.start)) & (data['datetime'] <= pd.to_datetime(self.end))]
            
        if self.limit > 0:
            data = data.tail(self.limit)
        
        if self.fields:
            data = data[self.fields]
        #else:
        #    data = data[['datetime','open','high','low','close','volume']]
        data.set_index('datetime', inplace=True)
        return data
        
        
        

    def quoteTimeSort(self):

        result = self.quote()
        #result.rename(columns={"quote_time": "datetime"}, inplace=True)
        #result['datetime'] = pd.to_datetime(result['datetime'])
        # print(df)
        #result = result.sort_values('datetime')  # 数据顺序排列
        # print(df)

        return result
        
    # def checkYfinance(self):
    #     try:
    #         data = yf.download('AAPL', start='2023-01-01', end='2023-01-30',progress=False)
    #         if len(data) > 0:
    #             return True
    #         else:
    #             return False
    #     except Exception as e:
    #         return False

    def signal(self):
        self.haskey = self.checkKey()
        if not os.path.exists(self.filepath):
            result = self.createSignal()
        elif self.haskey == 'no':
            result = self.createSignal()
        else:
            result = self.readCSV()
        return result

    def createQuote(self):
        df = {}
        # print(f'symbol {self.symbol}')
        # print(f'market {self.market}')
        # print(f'exchange {self.exchange}')
        try:
            if self.market == 'index' and self.exchange in ['SSE', 'SZSE', 'MSCI', 'CSI', 'CICC', 'SW', 'OTH']:
                df = self.tushareIndexApi()


            elif self.market == 'stock' and self.exchange in ['SSE', 'SZSE', 'BSE', 'AMEX', 'ARCA', 'BATS', 'HKEX', 'NASDAQ', 'NYSE', 'OTC',
                                 'NYSEARCA', 'FTXU', 'CBSE', 'GNSS', 'ERSX']:
                if self.source == 'akshare' or self.source == 'ak':
                    df = self.akshareStockApi()
                elif (self.source == 'baostock' or self.source == 'bs' ):
                    df = self.baostockStockApi()
                elif self.source == 'tushare' or self.source == 'ts':
                    df = self.tushareStockApi()
                elif self.source == 'yahoo' or self.source == 'yh':
                    df = self.yahooApi()
                elif self.exchange in ['SSE', 'SZSE', 'BSE']:
                    if self.token != '':
                        df = self.tushareStockApi()
                    elif self.freq == '1d':
                        df = self.akshareStockApi()
                    else:
                        df = self.baostockStockApi()

                elif self.exchange in ['AMEX', 'ARCA', 'BATS', 'NASDAQ', 'NYSE', 'OTC', 'NYSEARCA', 'FTXU', 'CBSE',
                                       'GNSS', 'ERSX']:

                    df = self.yahooApi()

                elif self.exchange in ['HKEX']:
                    if self.token != '':
                        df = self.tushareHKStockApi()  # 没有权限
                    else:
                        pass
                            
                if len(df) < 10:
                    #df = self.yahooApi()
                    df = self.akshareStockApi()
                        


            elif self.market == 'fund' and self.exchange in ['SSE', 'SZSE']:
                df = self.tushareFundApi()




            elif self.market == 'future' and self.exchange in ['SSE', 'SZSE','GFEX', 'DCE','CZCE', 'INE', 'SHFE','CFFEX', 'BJSE']:
                df = self.tushareFutureApi()

            elif self.market == 'option' and self.exchange in ['SSE', 'SZSE']:
                df = self.tushareOptionApi()

            elif self.market == 'option' and self.exchange in ['GFEX', 'DCE','CZCE', 'INE', 'SHFE','CFFEX']:
                df = self.tushareOptionApi()

            elif self.exchange == 'ALPACA':
                df = self.alpacaCryptoApi()

            else:
                df = self.ccxtApi()

            if len(df) > 0 and (self.cachetime > 0 or self.renew == True):
                self.saveCSV(df)



        except Exception as e:
            print(e.args)
            pass

        ###########

        return df
    
    def createIndexStocks(self):
        df = {}
        # print(f'symbol {self.symbol}')
        # print(f'market {self.market}')
        # print(f'exchange {self.exchange}')
        try:
            if self.market == 'index' and self.exchange in ['SSE', 'SZSE', 'MSCI', 'CSI', 'CICC', 'SW', 'OTH']:
                df = self.tushareIndexStocksApi()


            if len(df) > 0 and (self.cachetime > 0 or self.renew == True):
                self.saveCSV(df)



        except Exception as e:
            print(e.args)
            pass

        ###########

        return df

    # def yahooApi(self):
    #     df = {}
    #     try:
    #         if self.freq == 'D' or self.freq == '1d':
    #             periodlUS = '10y'
    #             intervalUS = '1d'
    #         elif self.freq == '1min' or self.freq == '1m':
    #             periodlUS = '7d'
    #             intervalUS = '1m'
    #         elif self.freq == '5min' or self.freq == '5m':
    #             periodlUS = '60d'
    #             intervalUS = '5m'
    #         elif self.freq == '15min':
    #             periodlUS = '60d'
    #             intervalUS = '15m'
    #         elif self.freq == '30min':
    #             periodlUS = '60d'
    #             intervalUS = '30m'
    #         elif self.freq == '60min' or self.freq == '1h':
    #             periodlUS = '1y'
    #             intervalUS = '1h'
    #         elif self.freq == 'W':
    #             periodlUS = '1y'
    #             intervalUS = '1wk'
    #         elif self.freq == 'M':
    #             periodlUS = '1y'
    #             intervalUS = '1mo'

    #         self.underlying_ex = self.underlying_ex.replace('.SH', '.SS')
    #         dfTemp = yf.download(  # or pdr.get_data_yahoo(...
    #                 tickers=self.underlying_ex,  # tickers list or string as well
    #                 period=periodlUS,
    #                 # use "period" instead of start/end # valid periods: 1d,5d,1mo,3mo,6mo,1y,2y,5y,10y,ytd,max# (optional, default is '1mo')
    #                 interval=intervalUS,
    #                 # valid intervals: 1m,2m,5m,15m,30m,60m,90m,1h,1d,5d,1wk,1mo,3mo  # fetch data by interval (including intraday if period < 60 days) # (optional, default is '1d')
    #                 ignore_tz=False,
    #                 # Whether to ignore timezone when aligning ticker data from # different timezones. Default is False.
    #                 group_by='ticker',  # group by ticker (to access via data['SPY']) # (optional, default is 'column')
    #                 auto_adjust=True,  # adjust all OHLC automatically # (optional, default is False)
    #                 repair=False,  # attempt repair of missing data or currency mixups e.g. $/cents
    #                 prepost=False,  # download pre/post regular market hours data # (optional, default is False)
    #                 threads=True,
    #                 # use threads for mass downloading? (True/False/Integer) # (optional, default is True)
    #                 progress=False,
    #                 proxy=None  # proxy URL scheme use use when downloading?# (optional, default is None)
    #             )
    #         dfTemp.reset_index(drop=False, inplace=True)
    #         if self.freq == 'D' or self.freq == '1d' or self.freq == 'W' or self.freq == 'M':
    #             dfTemp['Datetime'] = dfTemp['Date']
    #             dfTemp['Datetime'] = dfTemp['Datetime'].dt.tz_convert('UTC')
    #             dfTemp['Datetime'] = dfTemp['Datetime'].dt.tz_localize(None)
    #         # dfTemp['symbol'] = self.symbol

    #         df = pd.DataFrame()
    #         df['quote_time'] = dfTemp['Datetime']
    #         df['open'] = dfTemp['Open']
    #         df['high'] = dfTemp['High']
    #         df['low'] = dfTemp['Low']
    #         df['close'] = dfTemp['Close']
    #         df['volume'] = dfTemp['Volume']




    #     except Exception as e:
    #         print(e.args)
    #         pass

    #     ###########

    #     return df

    def tushareStockApi(self):
        df = {}
        try:
            pro = ts.pro_api(self.token)
            # underlying = self.symbol.replace('~', '/').replace('$', ':').replace('.' + self.exchange, '')
            if self.exchange == 'SSE':
                self.underlying_ex = self.underlying_ex.replace('.SS', '.SH')

            startDay = date.today() + timedelta(days=-1000)
            if self.freq == '1m':
                startDay = date.today() + timedelta(days=-15)
            startDay = format(startDay.strftime('%Y%m%d'))
            # print(LastWeek)
            toDay = date.today()
            toDay = format(toDay.strftime('%Y%m%d'))

            dfTemp = pro.daily(**{
                "ts_code": self.underlying_ex, "trade_date": "", "start_date": startDay, "end_date": toDay,
                "offset": "",
                "limit": ""
            }, fields=[
                "ts_code", "trade_date", "open", "high", "low", "close", "pre_close", "change", "pct_chg", "vol",
                "amount"
            ])
            # print(dfTemp)

            df = pd.DataFrame()
            df['quote_time'] = dfTemp['trade_date']
            df['open'] = dfTemp['open']
            df['high'] = dfTemp['high']
            df['low'] = dfTemp['low']
            df['close'] = dfTemp['close']
            df['volume'] = dfTemp['vol']

        except Exception as e:
            print(e.args)
            pass

        ###########

        return df
    
    def tushareFutureApi(self):
        df = {}
        try:
            pro = ts.pro_api(self.token)
            # underlying = self.symbol.replace('~', '/').replace('$', ':').replace('.' + self.exchange, '')
            #print(self.exchange)
            #print(self.underlying_ex)
            if self.exchange == 'SSE':
                self.underlying_ex = self.underlying_ex.replace('.SS', '.SH')
            # 拉取数据

            
            # print(self.exchange)
            # print(self.token)
            # print(self.underlying_ex)

            """if self.start == '':
                self.start = date.today() + timedelta(days=-1000)
            if self.freq == '1m':
                self.start = date.today() + timedelta(days=-15)
            if self.end == '':
                self.end = date.today()"""


            startDay = date.today() + timedelta(days=-1000)
            if self.freq == '1m':
                startDay = date.today() + timedelta(days=-15)
            startDay = format(startDay.strftime('%Y%m%d'))
            # print(LastWeek)
            toDay = date.today()
            toDay = format(toDay.strftime('%Y%m%d'))
            # print(startDay)
            # print(toDay)
            # print(self.underlying)
            
            # print(self.underlying_ex)
            # print(self.underlying_ex)
            # print(toDay)
            #print(dfTemp)
            # 拉取数据
            dfTemp = pro.fut_daily(**{
                "trade_date": "","ts_code": self.underlying_ex,"exchange": "","start_date": "","end_date": toDay,"limit": "","offset": ""
            }, fields=[
                "ts_code","trade_date","pre_close","pre_settle","open","high","low","close","settle","change1","change2","vol","amount","oi","oi_chg"
            ])
            
            # print(self.token)
            # print(dfTemp)

            df = pd.DataFrame()
            df['quote_time'] = dfTemp['trade_date']
            df['open'] = dfTemp['open']
            df['high'] = dfTemp['high']
            df['low'] = dfTemp['low']
            df['close'] = dfTemp['close']
            df['volume'] = dfTemp['vol']




        except Exception as e:
            print(e.args)
            pass

        ###########

        return df
    
    def tushareOptionApi(self):
        df = {}
        try:
            pro = ts.pro_api(self.token)
            if self.exchange == 'SSE':
                self.underlying_ex = self.underlying_ex.replace('.SS', '.SH')
            # 拉取数据
            """if self.start == '':
                self.start = date.today() + timedelta(days=-1000)
            if self.freq == '1m':
                self.start = date.today() + timedelta(days=-15)
            if self.end == '':
                self.end = date.today()"""

            startDay = date.today() + timedelta(days=-1000)
            if self.freq == '1m':
                startDay = date.today() + timedelta(days=-15)
            startDay = format(startDay.strftime('%Y%m%d'))

            toDay = date.today()
            toDay = format(toDay.strftime('%Y%m%d'))
            # 拉取数据

            
            dfTemp = pro.opt_daily(**{
                "ts_code": self.underlying_ex,"trade_date": "","start_date": "","end_date": toDay,"exchange": "","limit": "","offset": ""
            }, fields=[
                "ts_code","trade_date","exchange","pre_settle","pre_close","open","high","low","close","settle","vol","amount","oi"
            ])

            df = pd.DataFrame()
            df['quote_time'] = dfTemp['trade_date']
            df['open'] = dfTemp['open']
            df['high'] = dfTemp['high']
            df['low'] = dfTemp['low']
            df['close'] = dfTemp['close']
            df['volume'] = dfTemp['vol']




        except Exception as e:
            print(e.args)
            pass

        ###########

        return df

    def tushareHKStockApi(self):
        df = {}
        try:
            pro = ts.pro_api(self.token)
            startDay = date.today() + timedelta(days=-1000)
            if self.freq == '1m':
                startDay = date.today() + timedelta(days=-15)
            startDay = format(startDay.strftime('%Y%m%d'))
            # print(LastWeek)
            toDay = date.today()
            toDay = format(toDay.strftime('%Y%m%d'))
            # print(startDay)
            # print(toDay)
            # print(self.underlying)
            dfTemp = pro.hk_daily(**{
                "ts_code": self.underlying, "trade_date": "", "start_date": startDay, "end_date": toDay, "offset": "",
                "limit": ""
            }, fields=[
                "ts_code", "trade_date", "open", "high", "low", "close", "pre_close", "change", "pct_chg", "vol",
                "amount"
            ])
            # print(dfTemp)

            df = pd.DataFrame()
            df['quote_time'] = dfTemp['trade_date']
            df['open'] = dfTemp['open']
            df['high'] = dfTemp['high']
            df['low'] = dfTemp['low']
            df['close'] = dfTemp['close']
            df['volume'] = dfTemp['vol']




        except Exception as e:
            print(e.args)
            pass

        ###########

        return df
        
    def akshareStockApi(self):
        df = {}
        try:
            #pro = ts.pro_api(self.tushareKey)
            # underlying = self.symbol.replace('~', '/').replace('$', ':').replace('.' + self.exchange, '')
            #if self.exchange == 'SSE':
            #    self.underlying_ex = self.underlying_ex.replace('.SS', '.SH')
            
            self.underlying_num = self.underlying_ex.replace('.SH', '').replace('.SZ', '').replace('.SZ', '')
            



            startDay = date.today() + timedelta(days=-1000)
            if self.freq == '1m':
                startDay = date.today() + timedelta(days=-15)
            startDay = format(startDay.strftime('%Y%m%d'))
            # print(LastWeek)
            toDay = date.today()
            toDay = format(toDay.strftime('%Y%m%d'))

            dfTemp = ak.stock_zh_a_hist(symbol=self.underlying_num, period="daily", start_date=startDay, end_date=toDay, adjust="")

            
            dfTemp.rename(columns={"日期": "trade_date"}, inplace=True)
            dfTemp.rename(columns={"开盘": "open"}, inplace=True)
            dfTemp.rename(columns={"收盘": "close"}, inplace=True)
            dfTemp.rename(columns={"最高": "high"}, inplace=True)
            dfTemp.rename(columns={"最低": "low"}, inplace=True)
            dfTemp.rename(columns={"成交量": "vol"}, inplace=True)

            df = pd.DataFrame()
            df['quote_time'] = dfTemp['trade_date']
            df['open'] = dfTemp['open']
            df['high'] = dfTemp['high']
            df['low'] = dfTemp['low']
            df['close'] = dfTemp['close']
            df['volume'] = dfTemp['vol']
            
            #print(df)




        except Exception as e:
            print(e.args)
            pass

        ###########

        return df
        
    def akshareFundApi(self):
        df = {}
        try:
            #pro = ts.pro_api(self.tushareKey)
            # underlying = self.symbol.replace('~', '/').replace('$', ':').replace('.' + self.exchange, '')
            #if self.exchange == 'SSE':
            #    self.underlying_ex = self.underlying_ex.replace('.SS', '.SH')
            
            self.underlying_num = self.underlying_ex.replace('.SH', '').replace('.SZ', '').replace('.SZ', '')
            



            startDay = date.today() + timedelta(days=-1000)
            if self.freq == '1m':
                startDay = date.today() + timedelta(days=-15)
            startDay = format(startDay.strftime('%Y%m%d'))
            # print(LastWeek)
            toDay = date.today()
            toDay = format(toDay.strftime('%Y%m%d'))

            #print(self.underlying_num)
            #print(startDay)
            #print(toDay)
            
            #dfTemp = ak.stock_zh_a_hist(symbol=self.underlying_num, period="daily", start_date=startDay, end_date=toDay, adjust="")
            #ak.fund_etf_hist_sina(symbol="sz169103")
            #print(self.underlying)
            dfTemp = ak.fund_etf_hist_sina(symbol=self.underlying.lower())
            
            #dfTemp = ak.fund_etf_hist_em(symbol=self.underlying_num, period="daily", start_date=startDay, end_date=toDay, adjust="")
            
            if(len(dfTemp)<10):
                dfTemp = ak.fund_etf_hist_em(symbol=self.underlying_num, period="daily", start_date=startDay, end_date=toDay, adjust="")
            
            if(len(dfTemp)<10):
                dfTemp = ak.fund_lof_hist_em(symbol=self.underlying_num, period="daily", start_date=startDay, end_date=toDay, adjust="")
            
            #print(dfTemp)
#print(fund_etf_hist_em_df)

            
            dfTemp.rename(columns={"date": "trade_date"}, inplace=True)
            #dfTemp.rename(columns={"开盘": "open"}, inplace=True)
            #dfTemp.rename(columns={"收盘": "close"}, inplace=True)
            #dfTemp.rename(columns={"最高": "high"}, inplace=True)
            #dfTemp.rename(columns={"最低": "low"}, inplace=True)
            #dfTemp.rename(columns={"成交量": "vol"}, inplace=True)

            df = pd.DataFrame()
            df['quote_time'] = dfTemp['trade_date']
            df['open'] = dfTemp['open']
            df['high'] = dfTemp['high']
            df['low'] = dfTemp['low']
            df['close'] = dfTemp['close']
            df['volume'] = dfTemp['volume']
            
            #print(df)




        except Exception as e:
            print(e.args)
            pass

        ###########

        return df
        
    def baostockStockApi(self):
        df = {}
        try:

            if self.exchange == 'SSE':
                self.underlying_ex = self.underlying_ex.replace('.SS', '.SH')
                
            apiFreq = self.freq
            apiColumns = ''


            startDay = date.today() + timedelta(days=-1000)
            if self.freq == '1m':
                print('Min Period support than 5min')
            #elif self.freq == '5m':
            #    startDay = date.today() + timedelta(days=-30)
            elif self.freq == '1d':
                startDay = date.today() + timedelta(days=-30)
                apiFreq = 'd'
                apiColumns = 'date,open,high,low,close,volume'
            #elif self.freq == '5m':
            #    startDay = date.today() + timedelta(days=-30)
            elif self.freq == '5m':
                startDay = date.today() + timedelta(days=-30)
                apiFreq = '5'
                apiColumns = 'time,open,high,low,close,volume'
                
            startDay = format(startDay.strftime('%Y-%m-%d'))
            # print(LastWeek)
            toDay = date.today()
            toDay = format(toDay.strftime('%Y-%m-%d'))

            #### 登陆系统 ####
            lg = bs.login()
            # 显示登陆返回信息
            #print('login respond error_code:'+lg.error_code)
            #print('login respond  error_msg:'+lg.error_msg)
            
            #### 获取沪深A股历史K线数据 ####
            # 详细指标参数，参见“历史行情指标参数”章节；“分钟线”参数与“日线”参数不同。“分钟线”不包含指数。
            # 分钟线指标：date,time,code,open,high,low,close,volume,amount,adjustflag
            # 周月线指标：date,code,open,high,low,close,volume,amount,adjustflag,turn,pctChg
            rs = bs.query_history_k_data_plus(self.underlying_ex,apiColumns,
                start_date=startDay, end_date=toDay,
                frequency=apiFreq, adjustflag="3")

            #### 打印结果集 ####
            data_list  = []
            while (rs.error_code == '0') & rs.next():
                # 获取一条记录，将记录合并在一起
                data_list .append(rs.get_row_data())
            dfTemp = pd.DataFrame(data_list , columns=rs.fields)
            if self.freq == '5m':
                #datetime_obj = datetime.strptime(dfTemp['time'], "%Y%m%d%H%M%S%f")
                dfTemp['date'] = pd.to_datetime(dfTemp['time'], format='%Y%m%d%H%M%S%f')
            #print(dfTemp)

            
            #### 登出系统 ####
            bs.logout()


            df = pd.DataFrame()
            df['quote_time'] = dfTemp['date']
            df['open'] = dfTemp['open']
            df['high'] = dfTemp['high']
            df['low'] = dfTemp['low']
            df['close'] = dfTemp['close']
            df['volume'] = dfTemp['volume']
            
            #print(df)




        except Exception as e:
            print(e.args)
            pass

        ###########

        return df

    def tushareFundApi(self):
        df = {}
        try:
            pro = ts.pro_api(self.token)
            # underlying = self.symbol.replace('~', '/').replace('$', ':').replace('.' + self.exchange, '')
            if self.exchange == 'SSE':
                self.underlying_ex = self.underlying_ex.replace('.SS', '.SH')

            startDay = date.today() + timedelta(days=-1000)
            if self.freq == '1m':
                startDay = date.today() + timedelta(days=-15)
            startDay = format(startDay.strftime('%Y%m%d'))
            # print(LastWeek)
            toDay = date.today()
            toDay = format(toDay.strftime('%Y%m%d'))

            dfTemp = pro.fund_daily(**{
                "ts_code": self.underlying_ex, "trade_date": "", "start_date": startDay, "end_date": toDay,
                "offset": "",
                "limit": ""
            }, fields=[
                "ts_code", "trade_date", "open", "high", "low", "close", "pre_close", "change", "pct_chg", "vol",
                "amount"
            ])
            # print(dfTemp)

            df = pd.DataFrame()
            df['quote_time'] = dfTemp['trade_date']
            df['open'] = dfTemp['open']
            df['high'] = dfTemp['high']
            df['low'] = dfTemp['low']
            df['close'] = dfTemp['close']
            df['volume'] = dfTemp['vol']

        except Exception as e:
            print(e.args)
            pass

        ###########

        return df
    
    def tushareIndexApi(self):
        df = {}
        try:
            pro = ts.pro_api(self.token)
            # underlying = self.symbol.replace('~', '/').replace('$', ':').replace('.' + self.exchange, '')
            if self.exchange == 'SSE':
                self.underlying_ex = self.underlying_ex.replace('.SS', '.SH')

            startDay = date.today() + timedelta(days=-1000)
            if self.freq == '1m':
                startDay = date.today() + timedelta(days=-15)
            startDay = format(startDay.strftime('%Y%m%d'))
            # print(LastWeek)
            toDay = date.today()
            toDay = format(toDay.strftime('%Y%m%d'))

            # print(self.underlying_ex)
            # print(startDay)
            # print(toDay)
            dfTemp = pro.index_daily(**{
                "ts_code": self.underlying_ex, "trade_date": "", "start_date": startDay, "end_date": toDay, "offset": "", "limit": ""
            }, fields=[
                "ts_code", "trade_date", "open", "high", "low", "close", "pre_close", "change", "pct_chg", "vol", "amount"
            ])
            # print(dfTemp)

            df = pd.DataFrame()
            df['quote_time'] = dfTemp['trade_date']
            df['open'] = dfTemp['open']
            df['high'] = dfTemp['high']
            df['low'] = dfTemp['low']
            df['close'] = dfTemp['close']
            df['volume'] = dfTemp['vol']

        except Exception as e:
            print(e.args)
            pass

        ###########

        return df
    

    def tushareIndexStocksApi(self):
        df = {}
        try:
            pro = ts.pro_api(self.token)
            # underlying = self.symbol.replace('~', '/').replace('$', ':').replace('.' + self.exchange, '')
            if self.exchange == 'SSE':
                self.underlying_ex = self.underlying_ex.replace('.SS', '.SH')

            startDay = date.today() + timedelta(days=-1000)
            if self.freq == '1m':
                startDay = date.today() + timedelta(days=-15)
            startDay = format(startDay.strftime('%Y%m%d'))
            # print(LastWeek)
            toDay = date.today()
            toDay = format(toDay.strftime('%Y%m%d'))

            # print(self.underlying_ex)
            # print(startDay)
            # print(toDay)
            # dfTemp = pro.index_daily(**{
            #     "ts_code": self.underlying_ex, "trade_date": "", "start_date": startDay, "end_date": toDay, "offset": "", "limit": ""
            # }, fields=[
            #     "ts_code", "trade_date", "open", "high", "low", "close", "pre_close", "change", "pct_chg", "vol", "amount"
            # ])
            # print(dfTemp)

            dfTemp = pro.index_weight(**{
                "index_code": self.underlying_ex,"trade_date": "","start_date": "","end_date": "","ts_code": "","limit": self.limit,"offset": ""
            }, fields=[
                "index_code","con_code","trade_date","weight"
            ])

            df = pd.DataFrame()
            df['index'] = dfTemp['index_code']
            df['symbol'] = dfTemp['con_code']
            df['trade_date'] = dfTemp['trade_date']
            df['weight'] = dfTemp['weight']

        except Exception as e:
            print(e.args)
            pass

        ###########

        return df

    def ccxtApi(self):
        df = {}
        try:
            print('Pause')
            # # getExchange = tawCCXT(self.exchange)
            # # getExchange = byquant.getExchange(self.exchange)
            # getExchange = exchange.get(self.exchange)
            # getExchange.load_markets()

            # strFreq = self.freq
            # if strFreq == '1min':
            #     strFreq = '1m'
            # elif strFreq == 'H':
            #     strFreq = '1h'
            # elif strFreq == 'D':
            #     strFreq = '1d'
            # elif strFreq == 'M':
            #     strFreq = '1M'
            # elif strFreq == 'Y':
            #     strFreq = '1y'
            # #limit = 1000
            
            # #since_date = datetime.strptime(self.start, "%Y-%m-%d")
            # # 将 datetime 对象转换为毫秒级时间戳
            # #since_timestamp = int(since_date.timestamp() * 1000)

            # if getExchange.has['fetchOHLCV']:
            #     # time.sleep(getExchange.rateLimit / 1000)  # time.sleep wants seconds
            #     quotes = []
            #     df = {}
            #     # underlying = self.symbol.replace('~', '/').replace('$', ':').replace('.' + self.exchange, '')
            #     #ohlcvData = getExchange.fetchOHLCV(self.underlying, timeframe=strFreq, since =since_timestamp, limit=self.limit, params={})
            #     ohlcvData = getExchange.fetchOHLCV(self.underlying, timeframe=strFreq, limit=self.limit, params={})

            #     for ohlcv in ohlcvData:
            #         quote = {}
            #         quoteTime = time.localtime(ohlcv[0] / 1000)
            #         quote_time = time.strftime("%Y-%m-%d %H:%M:%S", quoteTime)
            #         quote['quote_time'] = quote_time
            #         quote['open'] = ohlcv[1]
            #         quote['high'] = ohlcv[2]
            #         quote['low'] = ohlcv[3]
            #         quote['close'] = ohlcv[4]
            #         quote['volume'] = ohlcv[5]
            #         quotes.append(quote)

            #     # df['open'] = df['ohlcv'][0]
            #     df = pd.DataFrame(quotes)





        except Exception as e:
            print(e.args)
            pass

        ###########

        return df

    def alpacaCryptoApi(self):
        df = {}
        try:
            # underlying = self.symbol.replace('~', '/').replace('$', ':').replace('.' + self.exchange.upper(), '')
            # print([freq])
            # toDay = date.today()
            # toDay = format(toDay.strftime('%Y-%m-%d'))
            client = CryptoHistoricalDataClient("Key", "KeyI")
            # strFreq = freq
            if self.freq == '1m':
                # strFreq = '1m'
                startTime = (date.today() + timedelta(days=-7)).strftime("%Y-%m-%d %H:%M:%S")
                request_params = CryptoBarsRequest(
                    symbol_or_symbols=[self.underlying],
                    timeframe=TimeFrame.Minute,
                    start=datetime.strptime(startTime, '%Y-%m-%d %H:%M:%S')
                )
            elif self.freq == '1h':
                startTime = (date.today() + timedelta(days=-90)).strftime("%Y-%m-%d %H:%M:%S")
                request_params = CryptoBarsRequest(
                    symbol_or_symbols=[self.underlying],
                    timeframe=TimeFrame.Hour,
                    start=datetime.strptime(startTime, '%Y-%m-%d %H:%M:%S')
                )
            elif self.freq == '1d':
                # strFreq = '1d'
                startTime = (date.today() + timedelta(days=-1000)).strftime("%Y-%m-%d")
                request_params = CryptoBarsRequest(
                    symbol_or_symbols=[self.underlying],
                    timeframe=TimeFrame.Day,
                    start=datetime.strptime(startTime, '%Y-%m-%d')
                )
            else:
                startTime = (date.today() + timedelta(days=-1000)).strftime("%Y-%m-%d")
                request_params = CryptoBarsRequest(
                    symbol_or_symbols=[self.underlying],
                    timeframe=TimeFrame.Day,
                    start=datetime.strptime(startTime, '%Y-%m-%d')
                )

            barsInfo = client.get_crypto_bars(request_params)
            barsData = barsInfo.data
            # print(type(barData))
            barsList = barsData[self.underlying]

            # print(barsList)
            barList = []
            for bars in barsList:
                barDict = dict(bars)
                barTemp = {}
                barTemp['quote_time'] = str(barDict['timestamp'])
                barTemp['open'] = float(barDict['open'])
                barTemp['high'] = str(barDict['high'])
                barTemp['low'] = float(barDict['low'])
                barTemp['close'] = float(barDict['close'])
                barTemp['volume'] = float(barDict['volume'])
                # barTemp['trade_count'] = float(barDict['trade_count'])
                barTemp['vwap'] = str(barDict['vwap'])

                # print(tickTemp)
                barList.append(barTemp)

            dfTemp = pd.DataFrame(barList)
            # dfTemp['symbol'] = symbol
            df = dfTemp.tail(1000)
            # print(df)





        except Exception as e:
            print(e.args)
            pass

        ###########

        return df

    def alpacaStockApi(self):
        df = {}
        try:
            # underlying = self.symbol.replace('~', '/').replace('$', ':').replace('.' + self.exchange.upper(), '')
            # print([freq])
            # toDay = date.today()
            # toDay = format(toDay.strftime('%Y-%m-%d'))
            client = StockHistoricalDataClient("KEY", "KEYI")
            # strFreq = freq
            if self.freq == '1m':
                # strFreq = '1m'
                startTime = (date.today() + timedelta(days=-7)).strftime("%Y-%m-%d %H:%M:%S")
                request_params = StockBarsRequest(
                    symbol_or_symbols=[self.underlying],
                    timeframe=TimeFrame.Minute,
                    start=datetime.strptime(startTime, '%Y-%m-%d %H:%M:%S')
                )
            elif self.freq == '1h':
                startTime = (date.today() + timedelta(days=-90)).strftime("%Y-%m-%d %H:%M:%S")
                request_params = StockBarsRequest(
                    symbol_or_symbols=[self.underlying],
                    timeframe=TimeFrame.Hour,
                    start=datetime.strptime(startTime, '%Y-%m-%d %H:%M:%S')
                )
            elif self.freq == '1d':
                # strFreq = '1d'
                startTime = (date.today() + timedelta(days=-1000)).strftime("%Y-%m-%d")
                request_params = StockBarsRequest(
                    symbol_or_symbols=[self.underlying],
                    timeframe=TimeFrame.Day,
                    start=datetime.strptime(startTime, '%Y-%m-%d')
                )
            else:
                startTime = (date.today() + timedelta(days=-1000)).strftime("%Y-%m-%d")
                request_params = StockBarsRequest(
                    symbol_or_symbols=[self.underlying],
                    timeframe=TimeFrame.Day,
                    start=datetime.strptime(startTime, '%Y-%m-%d')
                )

            barsInfo = client.get_stock_bars(request_params)
            barsData = barsInfo.data
            # print(type(barData))
            barsList = barsData[self.underlying]

            # print(barsList)
            barList = []
            for bars in barsList:
                barDict = dict(bars)
                barTemp = {}
                barTemp['quote_time'] = str(barDict['timestamp'])
                barTemp['open'] = float(barDict['open'])
                barTemp['high'] = str(barDict['high'])
                barTemp['low'] = float(barDict['low'])
                barTemp['close'] = float(barDict['close'])
                barTemp['volume'] = float(barDict['volume'])
                # barTemp['trade_count'] = float(barDict['trade_count'])
                barTemp['vwap'] = str(barDict['vwap'])

                # print(tickTemp)
                barList.append(barTemp)

            dfTemp = pd.DataFrame(barList)
            # dfTemp['symbol'] = symbol
            df = dfTemp.tail(1000)
            # print(df)





        except Exception as e:
            print(e.args)
            pass

        ###########

        return df

    def saveHDF(self, data):  # 将放弃
        result = False
        df = data
        try:

            if len(df) > 0:
                result = df
                df.fillna("0", inplace=True)
                df.sort_values(by="quote_time", ascending=False, inplace=True)

                filedir = self.MARKET_DATA_PATH + '%s' % (self.exchange)
                if not os.path.isdir(filedir):
                    os.makedirs(filedir)
                filepath = self.MARKET_DATA_PATH + '%s/%s.hdf' % (self.exchange, self.symbol)
                df.to_hdf(filepath, mode='a', key='quote_%s' % (self.freq), complevel=9, complib='blosc',
                          format='table')
                result = True



        except Exception as e:
            print(e.args)
            pass

        ###########

        return result

    def saveCSV(self, data):
        result = False
        df = data
        try:

            if len(df) > 0:
                #result = df
                #df.fillna("0", inplace=True)
                if self.ktype=='index':
                    df.sort_values(by="trade_date", ascending=True, inplace=True)
                else:
                    df.sort_values(by="quote_time", ascending=True, inplace=True)
                df.to_csv(self.filepath, index=False)
                """filepath = self.MARKET_DATA_PATH + '%s/%s.hdf' % (self.exchange, self.symbol)
                df.to_hdf(filepath, mode='a', key='quote_%s' % (self.freq), complevel=9, complib='blosc',
                          format='table')"""
                result = True



        except Exception as e:
            print(e.args)
            pass

        ###########

        return result

    def createSignal(self):
        result = tawSignal.autoStrategy(self.symbol, self.market, self.freq, self.limit, self.offset, self.cachetime)
        return result

    def updateQuote(self):
        result = self.createQuote()  ##暂定
        return result
    
    def updateIndexStocks(self):
        result = self.createIndexStocks()  ##暂定
        return result

    """def read(self):
        readHdf = pd.read_hdf(self.filepath, key='%s_%s' % (self.ktype, self.freq),mode='a')
        result = pd.DataFrame(readHdf)
        return result"""

    def readHDF(self):  # 将放弃
        readResult = pd.read_hdf(self.filepath, key='%s_%s' % (self.ktype, self.freq))
        self.result = pd.DataFrame(readResult)
        return self.result

    def readCSV(self):
        readResult = pd.read_csv(self.filepath)
        self.result = pd.DataFrame(readResult)
        return self.result

    def checkKey(self):
        result = 'no'
        if os.path.exists(self.filepath):
            keyName = '%s_%s' % (self.ktype, self.freq)
            getStore = pd.HDFStore(self.filepath, 'a')
            keyArr = getStore.keys()
            getStore.close()
            if keyName in keyArr:
                result = 'yes'
        return result

    def getSymbolInfo(self):
        result = {}
        result['market'] = 'CRYPTO'
        # try:
        #    result = marketModels.Underlying.objects.filter(symbol = self.symbol).values('market')
        # except Exception as e:
        #    print(e.args)
        #    pass
        return result







