# toolkitmad

Gemini RAG CLI for BMSCE Mobile Application Development lab programs.

## Install

```bash
pip install toolkitmad
```

## Setup

```bash
toolkitmad --set-key YOUR_GEMINI_API_KEY
```

## Usage

```bash
toolkitmad "give code for checkbox"
toolkitmad "how to use intents in android"
toolkitmad --sources "timepicker example"
```
