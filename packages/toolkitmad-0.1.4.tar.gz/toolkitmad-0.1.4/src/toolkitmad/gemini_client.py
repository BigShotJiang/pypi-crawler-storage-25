import sys

from google import genai

from .config import GEMINI_MODEL, SYSTEM_PROMPT, load_api_key


def ask_gemini(
    query: str,
    context: str,
    model: str = GEMINI_MODEL,
    stream: bool = True,
    chat_history: list[dict] | None = None,
) -> str:
    api_key = load_api_key()
    if not api_key:
        print(
            "Error: No Gemini API key found.\n"
            "Set it with: toolkitmad --set-key YOUR_KEY\n"
            "Or set the GEMINI_API_KEY environment variable.",
            file=sys.stderr,
        )
        sys.exit(1)

    client = genai.Client(api_key=api_key)

    # Build the prompt with optional chat history
    parts = []
    parts.append(f"### Lab Manual Context\n{context}")

    if chat_history:
        parts.append("### Previous Conversation")
        for turn in chat_history:
            parts.append(f"Student: {turn['query']}")
            parts.append(f"Tutor: {turn['response']}")

    parts.append(f"### Student Question\n{query}")
    prompt = "\n\n".join(parts)

    if stream:
        full = []
        for chunk in client.models.generate_content_stream(
            model=model,
            contents=prompt,
            config=genai.types.GenerateContentConfig(
                system_instruction=SYSTEM_PROMPT,
            ),
        ):
            text = chunk.text or ""
            print(text, end="", flush=True)
            full.append(text)
        print()
        return "".join(full)
    else:
        response = client.models.generate_content(
            model=model,
            contents=prompt,
            config=genai.types.GenerateContentConfig(
                system_instruction=SYSTEM_PROMPT,
            ),
        )
        result = response.text or ""
        print(result)
        return result
