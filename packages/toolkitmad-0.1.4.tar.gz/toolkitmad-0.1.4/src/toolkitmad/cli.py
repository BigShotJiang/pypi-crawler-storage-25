import argparse
import sys

from . import __version__


def main():
    parser = argparse.ArgumentParser(
        prog="toolkitmad",
        description="Gemini RAG CLI for BMSCE MAD lab programs",
    )
    parser.add_argument("query", nargs="?", help="Your question about a MAD lab program")
    parser.add_argument("--set-key", metavar="KEY", help="Save your Gemini API key")
    parser.add_argument("--sources", action="store_true", help="Show which Q&A entries were retrieved")
    parser.add_argument("--top", type=int, default=3, help="Number of entries to retrieve (default: 3)")
    parser.add_argument("--no-stream", action="store_true", help="Disable streaming output")
    parser.add_argument("--model", default=None, help="Override Gemini model name")
    parser.add_argument("--chat", action="store_true", help="Enable chat mode (remember previous Q&A for follow-ups)")
    parser.add_argument("--new-chat", action="store_true", help="Clear chat history and start a new conversation")
    parser.add_argument("--clear-history", action="store_true", help="Delete all chat history")
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    args = parser.parse_args()

    # Handle --set-key
    if args.set_key:
        from .config import save_api_key
        save_api_key(args.set_key)
        print("API key saved to ~/.toolkitmad/config.json")
        return

    # Handle --clear-history
    if args.clear_history:
        from .config import clear_chat_history
        clear_chat_history()
        print("Chat history cleared.")
        return

    # Handle --new-chat
    if args.new_chat:
        from .config import clear_chat_history
        clear_chat_history()
        print("Chat history cleared. Starting new conversation.")
        if not args.query:
            return

    if not args.query:
        parser.print_help()
        sys.exit(1)

    from .retriever import retrieve, format_context
    from .gemini_client import ask_gemini
    from .config import GEMINI_MODEL, load_chat_history, save_chat_history

    entries = retrieve(args.query, top_k=args.top)

    if args.sources:
        print("--- Retrieved sources ---")
        for entry in entries:
            print(f"  [{entry['id']}] {entry['title']}")
        print("-------------------------\n")

    context = format_context(entries)
    model = args.model or GEMINI_MODEL

    # Load chat history if --chat mode
    chat_history = None
    if args.chat:
        chat_history = load_chat_history()

    response = ask_gemini(
        query=args.query,
        context=context,
        model=model,
        stream=not args.no_stream,
        chat_history=chat_history,
    )

    # Save to chat history if --chat mode
    if args.chat:
        if chat_history is None:
            chat_history = []
        chat_history.append({"query": args.query, "response": response})
        # Keep only last 3 turns to limit token usage
        chat_history = chat_history[-3:]
        save_chat_history(chat_history)
