import json
import pickle
from pathlib import Path

import numpy as np

from .config import QA_BANK_PATH, EMBEDDINGS_PATH


def _load_index() -> tuple[list[dict], np.ndarray]:
    qa_bank = json.loads(QA_BANK_PATH.read_text(encoding="utf-8"))
    with open(EMBEDDINGS_PATH, "rb") as f:
        embeddings = pickle.load(f)
    return qa_bank, embeddings


def _cosine_sim(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    a_norm = a / np.linalg.norm(a)
    b_norm = b / np.linalg.norm(b, axis=1, keepdims=True)
    return b_norm @ a_norm


def retrieve(query: str, top_k: int = 3) -> list[dict]:
    from sentence_transformers import SentenceTransformer
    from .config import EMBED_MODEL

    qa_bank, embeddings = _load_index()
    model = SentenceTransformer(EMBED_MODEL)
    query_vec = model.encode(query)
    scores = _cosine_sim(query_vec, embeddings)
    top_indices = np.argsort(scores)[::-1][:top_k]
    return [qa_bank[i] for i in top_indices]


def format_context(entries: list[dict]) -> str:
    parts = []
    for entry in entries:
        part = f"## {entry['title']}\n"
        part += f"Theory: {entry['theory']}\n\n"
        part += f"```kotlin\n{entry['code_kotlin']}\n```\n\n"
        part += f"```xml\n{entry['xml_layout']}\n```\n"
        if entry.get("menu_xml"):
            part += f"\nMenu XML:\n```xml\n{entry['menu_xml']}\n```\n"
        if entry.get("manifest_snippet"):
            part += f"\nAndroidManifest addition:\n```xml\n{entry['manifest_snippet']}\n```\n"
        if entry.get("strings_xml"):
            part += f"\nstrings.xml:\n```xml\n{entry['strings_xml']}\n```\n"
        if entry.get("common_errors"):
            part += f"\nCommon errors: {entry['common_errors']}\n"
        parts.append(part)
    return "\n---\n".join(parts)
