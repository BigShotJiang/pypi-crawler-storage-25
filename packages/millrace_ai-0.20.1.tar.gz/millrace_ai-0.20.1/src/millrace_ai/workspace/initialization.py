"""Explicit workspace initialization and validation helpers."""

from __future__ import annotations

from pathlib import Path

from millrace_ai.workspace.asset_deployment import deploy_runtime_assets
from millrace_ai.workspace.baseline import build_baseline_manifest, write_baseline_manifest
from millrace_ai.workspace.bootstrap_files import default_file_payloads
from millrace_ai.workspace.paths import WorkspacePaths, workspace_paths

_RUNTIME_STATE_FILES = (
    "execution_status_file",
    "planning_status_file",
    "learning_status_file",
    "runtime_snapshot_file",
    "recovery_counters_file",
    "learning_events_file",
)
_BASELINE_PATHS = (
    "runtime_root",
    "state_dir",
    "tasks_queue_dir",
    "probes_queue_dir",
    "specs_queue_dir",
    "incidents_incoming_dir",
    "recon_packets_dir",
    "learning_requests_queue_dir",
    "entrypoints_dir",
    "skills_dir",
    "outline_file",
    "historylog_file",
    "baseline_manifest_file",
)


def initialize_workspace(
    target: WorkspacePaths | Path | str,
    *,
    assets_root: Path | str | None = None,
) -> WorkspacePaths:
    """Create the canonical workspace baseline."""

    paths = target if isinstance(target, WorkspacePaths) else workspace_paths(target)
    had_existing_runtime_state = _has_existing_runtime_state(paths)

    for directory in paths.directories():
        directory.mkdir(parents=True, exist_ok=True)

    defaults = default_file_payloads(paths)
    for file_path, payload in defaults.items():
        if not file_path.exists():
            file_path.parent.mkdir(parents=True, exist_ok=True)
            file_path.write_text(payload, encoding="utf-8")

    deploy_runtime_assets(paths, assets_root=assets_root)
    if not paths.baseline_manifest_file.exists():
        write_baseline_manifest(paths, build_baseline_manifest(paths, assets_root=assets_root))
    from millrace_ai.workspace.schema_epoch_marker import (
        workspace_schema_epoch_marker_path,
        write_workspace_schema_epoch_marker,
    )

    if not had_existing_runtime_state and not workspace_schema_epoch_marker_path(paths).exists():
        write_workspace_schema_epoch_marker(paths)
    return paths


def bootstrap_workspace(
    target: WorkspacePaths | Path | str,
    *,
    assets_root: Path | str | None = None,
) -> WorkspacePaths:
    """Compatibility alias for creating a canonical workspace baseline."""

    return initialize_workspace(target, assets_root=assets_root)


def require_initialized_workspace(target: WorkspacePaths | Path | str) -> WorkspacePaths:
    """Resolve a workspace and reject targets missing the canonical baseline."""

    paths = target if isinstance(target, WorkspacePaths) else workspace_paths(target)
    required_paths = tuple(getattr(paths, attribute_name) for attribute_name in _BASELINE_PATHS) + (
        paths.runtime_root / "millrace.toml",
    )
    missing = tuple(path for path in required_paths if not path.exists())
    if missing:
        raise ValueError(
            "workspace is not initialized: "
            f"{paths.root}. Run `millrace init --workspace {paths.root}` first."
        )
    return paths


def ensure_runtime_state_surfaces(target: WorkspacePaths | Path | str) -> WorkspacePaths:
    """Create missing runtime state files for an initialized workspace."""

    paths = require_initialized_workspace(target)
    defaults = default_file_payloads(paths)
    for attribute_name in _RUNTIME_STATE_FILES:
        file_path = getattr(paths, attribute_name)
        if file_path.exists():
            continue
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text(defaults[file_path], encoding="utf-8")
    return paths


def _has_existing_runtime_state(paths: WorkspacePaths) -> bool:
    if any(getattr(paths, attribute_name).exists() for attribute_name in _RUNTIME_STATE_FILES):
        return True
    return paths.state_dir.exists() and any(paths.state_dir.iterdir())


__all__ = [
    "bootstrap_workspace",
    "ensure_runtime_state_surfaces",
    "initialize_workspace",
    "require_initialized_workspace",
]
