"""Compiled-plan workflow-authority compatibility helpers."""

from __future__ import annotations

from millrace_ai.architecture import CompiledRunPlan

_REQUIRED_WORKFLOW_AUTHORITY_ASSET_FAMILIES = frozenset(
    {
        "artifact_contract",
        "request_context_profile",
    }
)


def has_required_workflow_authority(plan: CompiledRunPlan) -> bool:
    """Return whether a persisted plan carries v0.20 workflow authority data."""

    if not plan.artifact_contracts_by_id or not plan.artifact_contracts:
        return False

    asset_families = {ref.asset_family for ref in plan.resolved_assets}
    return _REQUIRED_WORKFLOW_AUTHORITY_ASSET_FAMILIES <= asset_families


__all__ = ["has_required_workflow_authority"]
