"""Materialized compiled plan contracts."""

from __future__ import annotations

from datetime import datetime
from typing import Literal

from pydantic import Field, field_validator, model_validator

from millrace_ai.contracts import (
    ExecutionCapabilityGrant,
    LearningTriggerRuleDefinition,
    Plane,
    PlaneConcurrencyPolicyDefinition,
    ResultClass,
)

from .loop_graphs import (
    GraphLoopCompletionBehaviorDefinition,
    GraphLoopCounterName,
    GraphLoopEdgeDefinition,
    GraphLoopEdgeKind,
    GraphLoopEntryDefinition,
    GraphLoopEntryKey,
    GraphLoopEntryKeyValue,
    GraphLoopTerminalStateDefinition,
    normalize_graph_loop_entry_key,
)
from .stage_kinds import ArchitectureContractModel
from .workflow_primitives import (
    ArtifactContractDefinition,
    LaneConflictPolicyDefinition,
    LifecycleMutationPlanDefinition,
    PlaneQueueClaimPolicyDefinition,
    RuntimeEffectHandlerDefinition,
    RuntimeEffectRuleDefinition,
    RuntimeFailurePolicyDefinition,
    TerminalActionDefinition,
    WorkflowPlaneSchedulerPolicyDefinition,
    WorkflowRecoveryPolicyDefinition,
    WorkItemDocumentAdapterDefinition,
    WorkItemFamilyDefinition,
    WorkspaceSchemaEpochDefinition,
)


class CompiledGraphEntryPlan(ArchitectureContractModel):
    entry_key: GraphLoopEntryKeyValue
    node_id: str
    stage_kind_id: str
    plane: Plane

    @field_validator("entry_key", mode="before")
    @classmethod
    def validate_entry_key(cls, value: object) -> GraphLoopEntryKeyValue:
        return normalize_graph_loop_entry_key(value)

    @field_validator("entry_key", mode="after")
    @classmethod
    def coerce_known_entry_key(cls, value: GraphLoopEntryKeyValue) -> GraphLoopEntryKeyValue:
        return normalize_graph_loop_entry_key(value)


class CompiledGraphCompletionEntryPlan(ArchitectureContractModel):
    entry_key: Literal[GraphLoopEntryKey.CLOSURE_TARGET] = GraphLoopEntryKey.CLOSURE_TARGET
    node_id: str
    stage_kind_id: str
    plane: Plane
    trigger: Literal["backlog_drained"]
    readiness_rule: Literal["no_open_lineage_work"]
    request_kind: Literal["closure_target"]
    target_selector: Literal["active_closure_target"]
    rubric_policy: Literal["reuse_or_create"]
    blocked_work_policy: Literal["suppress"]
    skip_if_already_closed: bool = True
    on_pass_terminal_state_id: str
    on_gap_terminal_state_id: str
    create_incident_on_gap: bool = False


class CompiledGraphTransitionPlan(ArchitectureContractModel):
    edge_id: str
    source_node_id: str
    outcome: str
    target_node_id: str | None = None
    terminal_state_id: str | None = None
    kind: GraphLoopEdgeKind = GraphLoopEdgeKind.NORMAL
    priority: int = 100
    max_attempts: int | None = None

    @model_validator(mode="after")
    def validate_target_shape(self) -> "CompiledGraphTransitionPlan":
        target_count = int(self.target_node_id is not None) + int(self.terminal_state_id is not None)
        if target_count != 1:
            raise ValueError(
                "compiled graph transition must target exactly one node or terminal_state_id"
            )
        return self


class CompiledGraphResumePolicyPlan(ArchitectureContractModel):
    policy_id: str
    source_node_id: str
    on_outcome: str
    default_target_node_id: str
    metadata_stage_keys: tuple[str, ...] = ()
    disallowed_target_node_ids: tuple[str, ...] = ()


class CompiledGraphThresholdPolicyPlan(ArchitectureContractModel):
    policy_id: str
    source_node_ids: tuple[str, ...] = Field(min_length=1)
    on_outcome: str
    counter_name: GraphLoopCounterName
    threshold: int = Field(ge=1)
    exhausted_target_node_id: str | None = None
    exhausted_terminal_state_id: str | None = None

    @model_validator(mode="after")
    def validate_target_shape(self) -> "CompiledGraphThresholdPolicyPlan":
        target_count = int(self.exhausted_target_node_id is not None) + int(
            self.exhausted_terminal_state_id is not None
        )
        if target_count != 1:
            raise ValueError(
                "compiled threshold policy must target exactly one exhausted node or terminal state"
            )
        return self


class MaterializedGraphNodePlan(ArchitectureContractModel):
    node_id: str
    stage_kind_id: str
    plane: Plane
    entrypoint_path: str
    entrypoint_contract_id: str | None = None
    running_status_marker: str
    allowed_result_classes_by_outcome: dict[str, tuple[ResultClass, ...]]
    declared_output_artifacts: tuple[str, ...] = ()
    allowed_work_item_families: tuple[str, ...] = ()
    required_skill_paths: tuple[str, ...] = ()
    attached_skill_additions: tuple[str, ...] = ()
    runner_name: str | None = None
    model_name: str | None = None
    thinking_level: str | None = None
    model_reasoning_effort: str | None = None
    timeout_seconds: int = 0
    execution_capability_grants: tuple[ExecutionCapabilityGrant, ...] = ()
    execution_capability_warnings: tuple[str, ...] = ()

    @model_validator(mode="after")
    def validate_timeout(self) -> "MaterializedGraphNodePlan":
        if self.timeout_seconds < 0:
            raise ValueError("timeout_seconds must be >= 0")
        return self


class FrozenGraphPlanePlan(ArchitectureContractModel):
    loop_id: str
    plane: Plane
    nodes: tuple[MaterializedGraphNodePlan, ...] = Field(min_length=1)
    entry_nodes: tuple[GraphLoopEntryDefinition, ...] = Field(min_length=1)
    transitions: tuple[GraphLoopEdgeDefinition, ...] = Field(min_length=1)
    compiled_entries: tuple[CompiledGraphEntryPlan, ...] = Field(min_length=1)
    compiled_completion_entry: CompiledGraphCompletionEntryPlan | None = None
    compiled_transitions: tuple[CompiledGraphTransitionPlan, ...] = Field(min_length=1)
    compiled_resume_policies: tuple[CompiledGraphResumePolicyPlan, ...] = ()
    compiled_threshold_policies: tuple[CompiledGraphThresholdPolicyPlan, ...] = ()
    terminal_states: tuple[GraphLoopTerminalStateDefinition, ...] = Field(min_length=1)
    completion_behavior: GraphLoopCompletionBehaviorDefinition | None = None
    execution_capability_summary: dict[str, int | dict[str, int]] = Field(default_factory=dict)

    @model_validator(mode="after")
    def validate_plane_alignment(self) -> "FrozenGraphPlanePlan":
        if any(node.plane is not self.plane for node in self.nodes):
            raise ValueError("all graph nodes must belong to graph plane")
        if any(entry.plane is not self.plane for entry in self.compiled_entries):
            raise ValueError("all compiled graph entries must belong to graph plane")
        if self.compiled_completion_entry is not None and self.compiled_completion_entry.plane is not self.plane:
            raise ValueError("compiled completion entry must belong to graph plane")
        if self.completion_behavior is None and self.compiled_completion_entry is not None:
            raise ValueError("compiled completion entry requires completion_behavior")
        if self.completion_behavior is not None:
            if self.compiled_completion_entry is None:
                raise ValueError("graphs with completion_behavior must define compiled completion entry")
            if self.compiled_completion_entry.node_id != self.completion_behavior.target_node_id:
                raise ValueError("compiled completion entry must target completion_behavior.target_node_id")
        return self


class CompileInputFingerprint(ArchitectureContractModel):
    mode_id: str
    config_fingerprint: str
    assets_fingerprint: str


class ResolvedAssetRef(ArchitectureContractModel):
    asset_family: str
    logical_id: str
    compile_time_path: str
    content_sha256: str


class CompiledRunPlan(ArchitectureContractModel):
    schema_version: Literal["1.0"] = "1.0"
    kind: Literal["compiled_run_plan"] = "compiled_run_plan"

    compiled_plan_id: str
    compile_input_fingerprint: CompileInputFingerprint
    mode_id: str
    loop_ids_by_plane: dict[Plane, str]
    execution_loop_id: str
    planning_loop_id: str
    learning_loop_id: str | None = None
    graphs_by_plane: dict[Plane, FrozenGraphPlanePlan]
    execution_graph: FrozenGraphPlanePlan
    planning_graph: FrozenGraphPlanePlan
    learning_graph: FrozenGraphPlanePlan | None = None
    concurrency_policy: PlaneConcurrencyPolicyDefinition | None = None
    learning_trigger_rules: tuple[LearningTriggerRuleDefinition, ...] = ()
    artifact_contracts_by_id: dict[str, ArtifactContractDefinition] = Field(default_factory=dict)
    artifact_contracts: tuple[ArtifactContractDefinition, ...] = ()
    work_item_families_by_id: dict[str, WorkItemFamilyDefinition] = Field(default_factory=dict)
    document_adapters_by_id: dict[str, WorkItemDocumentAdapterDefinition] = Field(default_factory=dict)
    queue_claim_policies_by_plane: dict[Plane, PlaneQueueClaimPolicyDefinition] = Field(default_factory=dict)
    terminal_actions_by_id: dict[str, TerminalActionDefinition] = Field(default_factory=dict)
    lifecycle_mutation_plans_by_id: dict[str, LifecycleMutationPlanDefinition] = Field(default_factory=dict)
    runtime_effect_handlers_by_id: dict[str, RuntimeEffectHandlerDefinition] = Field(default_factory=dict)
    workflow_recovery_policies_by_id: dict[str, WorkflowRecoveryPolicyDefinition] = Field(default_factory=dict)
    runtime_failure_policies_by_id: dict[str, RuntimeFailurePolicyDefinition] = Field(default_factory=dict)
    runtime_effect_rules: tuple[RuntimeEffectRuleDefinition, ...] = ()
    scheduler_policy: WorkflowPlaneSchedulerPolicyDefinition | None = None
    lane_conflict_policies_by_id: dict[str, LaneConflictPolicyDefinition] = Field(default_factory=dict)
    workspace_schema_epoch: WorkspaceSchemaEpochDefinition | None = None
    compiled_at: datetime
    resolved_assets: tuple[ResolvedAssetRef, ...] = ()
    source_refs: tuple[str, ...] = ()
    execution_capability_summary: dict[str, int | dict[str, int]] = Field(default_factory=dict)

    @model_validator(mode="after")
    def validate_graph_planes(self) -> "CompiledRunPlan":
        if self.loop_ids_by_plane.get(Plane.EXECUTION) != self.execution_loop_id:
            raise ValueError("loop_ids_by_plane execution id must match execution_loop_id")
        if self.loop_ids_by_plane.get(Plane.PLANNING) != self.planning_loop_id:
            raise ValueError("loop_ids_by_plane planning id must match planning_loop_id")
        if self.learning_loop_id is not None:
            if self.loop_ids_by_plane.get(Plane.LEARNING) != self.learning_loop_id:
                raise ValueError("loop_ids_by_plane learning id must match learning_loop_id")
        elif Plane.LEARNING in self.loop_ids_by_plane:
            raise ValueError("learning loop binding requires learning_loop_id")

        if self.execution_graph.plane is not Plane.EXECUTION:
            raise ValueError("execution_graph must declare plane=execution")
        if self.planning_graph.plane is not Plane.PLANNING:
            raise ValueError("planning_graph must declare plane=planning")
        if self.learning_graph is not None and self.learning_graph.plane is not Plane.LEARNING:
            raise ValueError("learning_graph must declare plane=learning")
        if self.execution_graph.loop_id != self.execution_loop_id:
            raise ValueError("execution_loop_id must match execution_graph.loop_id")
        if self.planning_graph.loop_id != self.planning_loop_id:
            raise ValueError("planning_loop_id must match planning_graph.loop_id")
        if self.learning_graph is not None and self.learning_graph.loop_id != self.learning_loop_id:
            raise ValueError("learning_loop_id must match learning_graph.loop_id")
        if self.graphs_by_plane.get(Plane.EXECUTION) != self.execution_graph:
            raise ValueError("graphs_by_plane execution graph must match execution_graph")
        if self.graphs_by_plane.get(Plane.PLANNING) != self.planning_graph:
            raise ValueError("graphs_by_plane planning graph must match planning_graph")
        if self.learning_graph is not None:
            if self.graphs_by_plane.get(Plane.LEARNING) != self.learning_graph:
                raise ValueError("graphs_by_plane learning graph must match learning_graph")
        elif Plane.LEARNING in self.graphs_by_plane:
            raise ValueError("learning graph binding requires learning_graph")
        if self.learning_trigger_rules and self.learning_graph is None:
            raise ValueError("learning_trigger_rules require learning_graph")
        self._validate_artifact_contract_surfaces()
        return self

    def _validate_artifact_contract_surfaces(self) -> None:
        if not self.artifact_contracts_by_id and not self.artifact_contracts:
            return

        tuple_contracts_by_id = {
            contract.artifact_id: contract
            for contract in self.artifact_contracts
        }
        if len(tuple_contracts_by_id) != len(self.artifact_contracts):
            raise ValueError("artifact_contracts contains duplicate artifact id")
        if set(self.artifact_contracts_by_id) != set(tuple_contracts_by_id):
            raise ValueError("artifact_contracts_by_id must match artifact_contracts")

        for artifact_id, contract in self.artifact_contracts_by_id.items():
            if contract != tuple_contracts_by_id[artifact_id]:
                raise ValueError("artifact_contracts_by_id must match artifact_contracts")


__all__ = [
    "CompiledGraphCompletionEntryPlan",
    "CompiledGraphEntryPlan",
    "CompiledGraphResumePolicyPlan",
    "CompiledGraphThresholdPolicyPlan",
    "CompiledGraphTransitionPlan",
    "CompileInputFingerprint",
    "CompiledRunPlan",
    "FrozenGraphPlanePlan",
    "MaterializedGraphNodePlan",
    "ResolvedAssetRef",
]
