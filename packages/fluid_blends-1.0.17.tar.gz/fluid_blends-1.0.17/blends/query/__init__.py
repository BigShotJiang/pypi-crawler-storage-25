from collections.abc import (
    Callable,
    Iterable,
    Iterator,
)
from itertools import (
    chain,
)
from typing import NamedTuple, TypeAlias

from blends.ast.node_attributes_types import AstNodeAttrs
from blends.edge_attributes_types import EdgeAttrs
from blends.models import (
    Graph,
    NId,
    SanitizationEvent,
    SyntaxGraph,
)
from blends.syntax.node_attributes_types import SyntaxNodeAttrs

NAttrs: TypeAlias = AstNodeAttrs | SyntaxNodeAttrs


def has_labels(n_attrs: NAttrs, **expected_attrs: str) -> bool:
    return all(
        n_attrs.get(expected_attr) == expected_attr_value
        for expected_attr, expected_attr_value in expected_attrs.items()
    )


def has_edge_labels(e_attrs: EdgeAttrs, **expected_attrs: str) -> bool:
    return all(
        e_attrs.get(expected_attr) == expected_attr_value
        for expected_attr, expected_attr_value in expected_attrs.items()
    )


def predicate_has_labels(**expected_attrs: str) -> Callable[[NAttrs], bool]:
    def predicate(n_attrs: NAttrs) -> bool:
        return has_labels(n_attrs, **expected_attrs)

    return predicate


def predicate_has_edge_labels(**expected_attrs: str) -> Callable[[EdgeAttrs], bool]:
    def predicate(e_attrs: EdgeAttrs) -> bool:
        return has_edge_labels(e_attrs, **expected_attrs)

    return predicate


def filter_nodes(
    graph: Graph,
    nodes: Iterable[NId],
    predicate: Callable[[NAttrs], bool],
) -> tuple[NId, ...]:
    result: tuple[NId, ...] = tuple(n_id for n_id in nodes if predicate(graph.nodes[n_id]))

    return result


def matching_nodes(
    graph: Graph, label_type: str | None = None, **expected_attrs: str
) -> tuple[NId, ...]:
    if label_type:
        candidates = graph.nodes_by_type.get(label_type, [])
        if expected_attrs:
            return filter_nodes(graph, candidates, predicate_has_labels(**expected_attrs))
        return tuple(candidates)
    return filter_nodes(graph, graph.nodes, predicate_has_labels(**expected_attrs))


def _edge_matches(
    graph: Graph,
    source: NId,
    target: NId,
    edge_keys: set[str],
    *,
    strict: bool,
    **edge_attrs: str,
) -> bool:
    if not has_edge_labels(graph[source][target], **edge_attrs):
        return False
    if strict:
        graph_edge_keys = set(graph[source][target].keys())
        difference = graph_edge_keys.difference(edge_keys)
        return not difference or difference == {"label_index"}
    return True


def adj_lazy(
    graph: Graph,
    n_id: NId,
    depth: int = 1,
    *,
    strict: bool = False,
    _processed_n_ids: set[NId] | None = None,
    **edge_attrs: str,
) -> Iterator[NId]:
    """Return adjacent nodes to `n_id`, following just edges with given attrs.

    - Parameter `depth` may be -1 to indicate infinite depth.
    - Parameter `strict` indicates that the edges must have only the indicated
      attributes

    - Search is done breadth first.
    - Nodes are returned ordered ascending by index on each level.

    This function must be used instead of graph.adj, because graph.adj
    becomes unstable (unordered) after mutating the graph, also this allow
    following just edges matching `edge_attrs`.
    """
    processed_n_ids: set[NId] = _processed_n_ids or set()
    if depth == 0 or n_id in processed_n_ids:
        return

    processed_n_ids.add(n_id)

    childs: list[NId] = sorted(graph.adj[n_id], key=int)
    edge_keys = set(edge_attrs.keys())
    matching_childs = [
        c_id
        for c_id in childs
        if _edge_matches(graph, n_id, c_id, edge_keys, strict=strict, **edge_attrs)
    ]

    yield from matching_childs

    if depth in {0, 1}:
        return

    for c_id in matching_childs:
        yield from adj_lazy(
            graph,
            c_id,
            depth=depth - 1,
            strict=strict,
            _processed_n_ids=processed_n_ids,
            **edge_attrs,
        )


def adj(
    graph: Graph,
    n_id: NId,
    depth: int = 1,
    *,
    strict: bool = False,
    _processed_n_ids: set[NId] | None = None,
    **edge_attrs: str,
) -> tuple[NId, ...]:
    return tuple(
        adj_lazy(
            graph,
            n_id,
            depth=depth,
            strict=strict,
            _processed_n_ids=_processed_n_ids,
            **edge_attrs,
        ),
    )


def adj_ast(
    graph: Graph,
    n_id: NId,
    depth: int = 1,
    *,
    strict: bool = False,
    **n_attrs: str,
) -> tuple[NId, ...]:
    return tuple(
        c_id
        for c_id in adj(graph, n_id, depth, strict=strict, label_ast="AST")
        if has_labels(graph.nodes[c_id], **n_attrs)
    )


def adj_cfg(
    graph: Graph,
    n_id: NId,
    depth: int = 1,
    *,
    strict: bool = False,
    **n_attrs: str,
) -> tuple[NId, ...]:
    return tuple(
        c_id
        for c_id in adj(graph, n_id, depth, strict=strict, label_cfg="CFG")
        if has_labels(graph.nodes[c_id], **n_attrs)
    )


def adj_cfg_lazy(
    graph: Graph,
    n_id: NId,
    depth: int = 1,
    *,
    strict: bool = False,
    **n_attrs: str,
) -> Iterator[NId]:
    yield from adj_lazy(
        graph,
        n_id,
        depth=depth,
        strict=strict,
        _processed_n_ids=set(),
        label_cfg="CFG",
        **n_attrs,
    )


def pred_lazy(
    graph: Graph,
    n_id: NId,
    depth: int = 1,
    _processed_n_ids: set[NId] | None = None,
    **edge_attrs: str,
) -> Iterator[NId]:
    """Obtain parent nodes.

    Same as `adj` but follow edges in the opposite direction
    """
    processed_n_ids: set[NId] = _processed_n_ids or set()
    if depth == 0 or n_id in processed_n_ids:
        return

    processed_n_ids.add(n_id)

    p_ids: list[NId] = sorted(graph.pred[n_id], key=int)
    matching_parents = [p_id for p_id in p_ids if has_edge_labels(graph[p_id][n_id], **edge_attrs)]

    yield from matching_parents

    if depth < 0 or depth > 1:
        for p_id in matching_parents:
            yield from pred_lazy(
                graph,
                p_id,
                depth=depth - 1,
                _processed_n_ids=processed_n_ids,
                **edge_attrs,
            )


def pred(
    graph: Graph,
    n_id: NId,
    depth: int = 1,
    _processed_n_ids: set[NId] | None = None,
    **edge_attrs: str,
) -> tuple[NId, ...]:
    return tuple(
        pred_lazy(
            graph,
            n_id,
            depth,
            _processed_n_ids=_processed_n_ids,
            **edge_attrs,
        ),
    )


def pred_ast(
    graph: Graph,
    n_id: NId,
    depth: int = 1,
    **edge_attrs: str,
) -> tuple[NId, ...]:
    return tuple(pred_ast_lazy(graph, n_id, depth, **edge_attrs))


def pred_ast_lazy(
    graph: Graph,
    n_id: NId,
    depth: int = 1,
    **edge_attrs: str,
) -> Iterator[NId]:
    yield from pred_lazy(
        graph,
        n_id,
        depth,
        _processed_n_ids=set(),
        label_ast="AST",
        **edge_attrs,
    )


def pred_cfg(
    graph: Graph,
    n_id: NId,
    depth: int = 1,
    **edge_attrs: str,
) -> tuple[NId, ...]:
    return tuple(pred_cfg_lazy(graph, n_id, depth, **edge_attrs))


def pred_cfg_lazy(
    graph: Graph,
    n_id: NId,
    depth: int = 1,
    **edge_attrs: str,
) -> Iterator[NId]:
    yield from pred_lazy(
        graph,
        n_id,
        depth,
        _processed_n_ids=set(),
        label_cfg="CFG",
        **edge_attrs,
    )


def match_ast(
    graph: Graph,
    n_id: NId,
    *label_type: str,
    depth: int = 1,
) -> dict[str, NId | None]:
    index: int = 0
    nodes: dict[str, NId | None] = dict.fromkeys(label_type)

    for c_id in adj_ast(graph, n_id, depth=depth):
        c_type = graph.nodes[c_id]["label_type"]
        if c_type in nodes and nodes[c_type] is None:
            nodes[c_type] = c_id
        else:
            nodes[f"__{index}__"] = c_id
            index += 1

    return nodes


def match_ast_d(graph: Graph, n_id: NId, label_type: str, depth: int = 1) -> NId | None:
    return match_ast(graph, n_id, label_type, depth=depth)[label_type]


def match_ast_group(
    graph: Graph,
    n_id: NId,
    *label_type: str,
    depth: int = 1,
) -> dict[str, list[NId]]:
    index: int = 0
    nodes: dict[str, list[NId]] = {label: [] for label in label_type}

    for c_id in adj_ast(graph, n_id, depth=depth):
        c_type = graph.nodes[c_id]["label_type"]
        if c_type in nodes:
            nodes[c_type].append(c_id)
        else:
            nodes[f"__{index}__"] = [
                c_id,
            ]
            index += 1

    return nodes


def match_ast_group_d(graph: Graph, n_id: NId, label_type: str, depth: int = 1) -> list[NId]:
    return match_ast_group(graph, n_id, label_type, depth=depth)[label_type]


def is_connected_to_cfg(graph: Graph, n_id: NId) -> bool:
    return bool(pred_cfg(graph, n_id) or adj_cfg(graph, n_id))


def lookup_first_cfg_parent(graph: Graph, n_id: NId) -> NId:
    # Lookup first parent who is connected to the CFG
    for p_id in chain([n_id], pred_ast_lazy(graph, n_id, depth=-1)):
        if is_connected_to_cfg(graph, p_id):
            return p_id
    # Base case, pass through
    return n_id


def _get_subgraph(
    graph: Graph,
    node_n_id_predicate: Callable[[NId], bool] = lambda _: True,
    edge_n_attrs_predicate: Callable[[EdgeAttrs], bool] = lambda _: True,
) -> Graph:
    copy: Graph = Graph()

    for n_a_id, n_b_id in graph.edges:
        edge_attrs = graph[n_a_id][n_b_id].copy()
        n_a_attrs = graph.nodes[n_a_id].copy()
        n_b_attrs = graph.nodes[n_b_id].copy()

        if (
            edge_n_attrs_predicate(edge_attrs)
            and node_n_id_predicate(n_a_id)
            and node_n_id_predicate(n_b_id)
        ):
            copy.add_node(n_a_id, **n_a_attrs)
            copy.add_node(n_b_id, **n_b_attrs)
            copy.add_edge(n_a_id, n_b_id, **edge_attrs)

    return copy


def copy_ast(graph: Graph) -> Graph:
    return _get_subgraph(
        graph=graph,
        edge_n_attrs_predicate=predicate_has_edge_labels(label_ast="AST"),
    )


def search_pred_until_type(
    graph: Graph,
    n_id: NId,
    targets: set[str],
    last_child: NId | None = None,
) -> tuple[NId, NId] | None:
    if not last_child:
        last_child = n_id
    if pred_c := pred_ast(graph, n_id):
        if graph.nodes[pred_c[0]]["label_type"] in targets:
            return (pred_c[0], last_child)
        return search_pred_until_type(graph, pred_c[0], targets, pred_c[0])
    return None


def get_nodes_by_path(
    graph: Graph,
    n_id: NId,
    *label_type_path: str,
) -> set[NId]:
    if not label_type_path:
        return set()
    if len(label_type_path) == 1:
        return set(adj_ast(graph, n_id, label_type=label_type_path[0]))

    result: set[NId] = set()
    for node in adj_ast(graph, n_id, label_type=label_type_path[0]):
        result.update(get_nodes_by_path(graph, node, *label_type_path[1:]))
    return result


def get_node_by_path(graph: Graph, n_id: NId, *label_type_path: str) -> NId | None:
    return next(iter(get_nodes_by_path(graph, n_id, *label_type_path)), None)


def nodes_by_type(graph: Graph) -> dict[str, list[NId]]:
    return graph.nodes_by_type


def get_args_n_ids(graph: Graph, n_id: NId) -> list[NId]:
    if (args_parent_n_id := graph.nodes[n_id].get("arguments_id")) is None:
        return []
    if not isinstance(args_parent_n_id, int):
        return []
    return [
        arg_id
        for arg_id in adj_ast(graph, args_parent_n_id)
        if graph.nodes[arg_id].get("label_type") != "Comment"
    ]


def get_n_arg(graph: Graph, n_id: NId | None, arg_idx: int) -> NId | None:
    if not n_id:
        return None

    for idx, arg_id in enumerate(get_args_n_ids(graph, n_id)):
        if idx == arg_idx:
            return arg_id
    return None


def _is_self_ref(graph: SyntaxGraph, def_nid: NId, lookup_nid: NId) -> bool:
    nodes = graph.nodes
    return (
        nodes[def_nid].get("value_id") == lookup_nid
        or nodes[def_nid].get("variable_id") == lookup_nid
    )


def _is_valid_def(graph: SyntaxGraph, def_nid: NId, lookup_nid: NId) -> bool:
    return not _is_self_ref(graph, def_nid, lookup_nid) and int(def_nid) < int(lookup_nid)


def _dedup_by_subpath(graph: SyntaxGraph, definitions: list[NId]) -> list[NId]:
    seen_subpaths: set[NId | None] = set()
    result: list[NId] = []
    for def_nid in definitions:
        subpath = graph.subpath_index.get(def_nid)
        if subpath not in seen_subpaths:
            seen_subpaths.add(subpath)
            result.append(def_nid)
    return result


def _find_defs_in_scope(
    graph: SyntaxGraph, symbol: str, scope: NId, lookup_nid: NId
) -> list[NId] | None:
    symbol_defs = graph.symbol_index.get(symbol, {})
    if def_nids := symbol_defs.get(scope):
        valid_defs = [def_nid for def_nid in def_nids if _is_valid_def(graph, def_nid, lookup_nid)]
        if valid_defs:
            return _dedup_by_subpath(graph, valid_defs)

    for compound_key, scope_defs in graph.symbol_index.items():
        if (
            "," in compound_key
            and symbol in compound_key.split(",")
            and (def_nids := scope_defs.get(scope))
        ):
            valid_defs = [
                def_nid for def_nid in def_nids if _is_valid_def(graph, def_nid, lookup_nid)
            ]
            if valid_defs:
                return _dedup_by_subpath(graph, valid_defs)

    return None


def resolve_symbol_all_scope_index(graph: SyntaxGraph, lookup_nid: NId) -> list[NId]:
    symbol = graph.nodes[lookup_nid].get("symbol")
    current_scope: NId | None = graph.nodes[lookup_nid].get("symbol_scope")
    if not symbol or current_scope is None:
        return []
    while current_scope is not None:
        if definitions := _find_defs_in_scope(graph, symbol, current_scope, lookup_nid):
            return definitions
        current_scope = graph.scope_parent.get(current_scope)
    return []


def _literal_binary_operation(graph: SyntaxGraph, n_id: NId, level: int) -> str | None:
    nodes = graph.nodes
    if left_n_id := nodes[n_id].get("left_id"):
        if nodes[left_n_id].get("label_type") == "Literal":
            return nodes[left_n_id].get("value")
        if nodes[left_n_id].get("label_type") == "BinaryOperation":
            return _literal_binary_operation(graph, left_n_id, level + 1)
    if (
        (right_n_id := nodes[n_id].get("right_id"))
        and level == 0
        and nodes[right_n_id].get("label_type") == "Literal"
    ):
        return nodes[right_n_id].get("value")
    return None


def _resolve_child_symbols(graph: SyntaxGraph, n_id: NId, depth: int) -> Iterator[str]:
    nodes = graph.nodes
    for child_id in match_ast_group_d(graph, n_id, "SymbolLookup", -1):
        if (parent_id := next(iter(pred_ast(graph, child_id)), None)) and (
            nodes[parent_id].get("label_type") == "ArgumentList"
        ):
            continue
        definitions = resolve_symbol_all_scope_index(graph, child_id)
        for def_nid in definitions:
            yield from _resolve_value(graph, def_nid, depth)


def _check_direct_string(graph: SyntaxGraph, n_id: NId) -> str | None:
    nodes = graph.nodes
    label_type = nodes[n_id].get("label_type")

    if (
        label_type == "Literal"
        and nodes[n_id].get("value_type") != "null"
        and len(adj_ast(graph, n_id)) == 0
    ):
        return nodes[n_id].get("value")

    if (obj_id := nodes[n_id].get("object_id")) and (nodes[obj_id].get("label_type") == "Literal"):
        return nodes[obj_id].get("value")

    if label_type == "BinaryOperation":
        return _literal_binary_operation(graph, n_id, 0)

    return None


def _resolve_value(graph: SyntaxGraph, n_id: NId, depth: int) -> Iterator[str]:
    value_id = graph.nodes[n_id].get("value_id")
    if not value_id:
        return
    yield from get_string_definitions_resolver(graph, value_id, _depth=depth)


# WIP: Only works when the ScopeIndex feature flag is active.
# Do not use in production methods until ScopeIndex is fully rolled out.
def get_string_definitions_resolver(
    graph: SyntaxGraph, n_id: NId | None, *, _depth: int = 0
) -> Iterator[str]:
    """Resolve all string literals a node can trace back to.

    Uses ScopeIndex for symbol resolution instead of CFG backward paths.
    Recurses through SymbolLookup chains up to max_resolver_depth.
    Yields all resolved string values across all definitions.
    """
    max_resolver_depth = 4
    if n_id is None or _depth > max_resolver_depth:
        return

    if (result := _check_direct_string(graph, n_id)) is not None:
        yield result
        return

    if graph.nodes[n_id].get("label_type") == "SymbolLookup":
        definitions = resolve_symbol_all_scope_index(graph, n_id)
        for def_nid in definitions:
            yield from _resolve_value(graph, def_nid, _depth + 1)
        return

    yield from _resolve_child_symbols(graph, n_id, _depth + 1)


def has_any_string_definition(graph: SyntaxGraph, n_id: NId | None) -> bool:
    return next(get_string_definitions_resolver(graph, n_id), None) is not None


def is_node_definition_unsafe_resolver(
    graph: SyntaxGraph,
    n_id: NId,
    node_dangerous_condition: Callable[[SyntaxGraph, NId], bool],
    *,
    evaluate_value_definition: bool = True,
) -> bool:
    if node_dangerous_condition(graph, n_id):
        return True

    if graph.nodes[n_id].get("label_type") != "SymbolLookup":
        return False

    definitions = resolve_symbol_all_scope_index(graph, n_id)

    for def_nid in definitions:
        if evaluate_value_definition:
            if (value_id := graph.nodes[def_nid].get("value_id")) and node_dangerous_condition(
                graph, value_id
            ):
                return True
        elif node_dangerous_condition(graph, def_nid):
            return True

    return False


class _SanitizationFilter(NamedTuple):
    usage_n_id: NId
    exclude_parent: NId | None = None
    definition_n_id: NId | None = None


def _get_var_name_for_index(graph: SyntaxGraph, n_id: NId) -> str | None:
    """Extract the variable name from a node for sanitization index lookup."""
    label_type = graph.nodes[n_id].get("label_type")
    if label_type == "SymbolLookup":
        symbol = graph.nodes[n_id].get("symbol")
        return str(symbol) if symbol else None
    if label_type == "MemberAccess":
        expression = graph.nodes[n_id].get("expression", "")
        member = graph.nodes[n_id].get("member", "")
        return f"{expression}.{member}" if expression and member else None
    if label_type == "MethodInvocation" and (args_id := graph.nodes[n_id].get("arguments_id")):
        for child_id in adj_ast(graph, args_id, label_type="MemberAccess"):
            expression = graph.nodes[child_id].get("expression", "")
            member = graph.nodes[child_id].get("member", "")
            if expression and member:
                return f"{expression}.{member}"
        for child_id in adj_ast(graph, args_id, label_type="SymbolLookup"):
            if symbol := graph.nodes[child_id].get("symbol"):
                return str(symbol)
    return None


def _get_node_scope(graph: SyntaxGraph, n_id: NId) -> NId | None:
    """Find the enclosing scope for a node."""
    if stored_scope := graph.nodes[n_id].get("symbol_scope"):
        return int(stored_scope)
    scope_label_types = {"File", "MethodDeclaration", "Class"}
    for parent_id in pred_ast(graph, n_id, depth=-1):
        if graph.nodes[parent_id].get("label_type") in scope_label_types:
            return parent_id
    return None


def _get_enclosing_event_parent(graph: SyntaxGraph, n_id: NId) -> NId | None:
    """Find the MethodInvocation or If node that directly contains n_id.

    This mirrors _get_path_after_current_method in the original is_sanitized:
    the node being checked is inside a sink (e.g. exec(var)), and that sink
    must not count as its own sanitizer.
    """
    for parent_id in pred_ast(graph, n_id, depth=-1):
        parent_type = graph.nodes[parent_id].get("label_type")
        if parent_type in {"MethodInvocation", "If"}:
            return parent_id
        if parent_type in {"File", "MethodDeclaration", "Class"}:
            break
    return None


def _get_nearest_definition(graph: SyntaxGraph, n_id: NId) -> NId | None:
    """Find the nearest definition of the variable at n_id using ScopeIndex.

    Uses resolve_symbol_all_scope_index and takes the max node ID (closest
    definition before usage). This avoids relying on list ordering which may
    not match source order for all languages.
    """
    if graph.nodes[n_id].get("label_type") == "SymbolLookup":
        all_defs = resolve_symbol_all_scope_index(graph, n_id)
        return max(all_defs) if all_defs else None
    return None


def _find_sanitization_events(
    graph: SyntaxGraph,
    var_name: str,
    scope: NId,
    bounds: _SanitizationFilter,
) -> list[SanitizationEvent]:
    """Find sanitization events for a symbol before usage, walking scope chain.

    Uses bounds.definition_n_id (if set) to only consider events after that
    definition (i.e. between the definition and the usage point).
    """
    lower_bound = bounds.definition_n_id if bounds.definition_n_id is not None else 0
    current_scope: NId | None = scope
    while current_scope is not None:
        if events := graph.sanitization_index.get(var_name, {}).get(current_scope):
            filtered = [
                event
                for event in events
                if event.node_id > lower_bound
                and event.node_id < bounds.usage_n_id
                and event.node_id != bounds.exclude_parent
            ]
            if filtered:
                return filtered
        current_scope = graph.scope_parent.get(current_scope)
    return []


def is_sanitized_by_index(graph: SyntaxGraph, n_id: NId) -> bool:
    """Check if variable at n_id has been sanitized, using pre-built index."""
    if not (var_name := _get_var_name_for_index(graph, n_id)):
        return False
    if (scope := _get_node_scope(graph, n_id)) is None:
        return False
    bounds = _SanitizationFilter(
        usage_n_id=n_id,
        exclude_parent=_get_enclosing_event_parent(graph, n_id),
        definition_n_id=_get_nearest_definition(graph, n_id),
    )
    return len(_find_sanitization_events(graph, var_name, scope, bounds)) > 0
