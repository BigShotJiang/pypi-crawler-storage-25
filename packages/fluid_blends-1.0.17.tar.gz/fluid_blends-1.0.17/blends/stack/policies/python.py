from __future__ import annotations

from typing import TYPE_CHECKING

from blends.stack.policies.base import ExportPolicy
from blends.stack.scope_types import ScopeType

if TYPE_CHECKING:
    from blends.models import NId, StackGraph, SyntaxGraph


class PythonExportPolicy(ExportPolicy):
    def is_scope_exported(
        self,
        _graph: SyntaxGraph,
        _node_id: NId,
        scope_type: str | None,
    ) -> bool:
        return scope_type == ScopeType.FILE.value

    def is_definition_exported(
        self,
        graph: SyntaxGraph,
        stack_graph: StackGraph | None,
        _node_id: NId,
        parent_scope_id: NId | None,
    ) -> bool:
        if parent_scope_id is None:
            return True
        sg_nodes = stack_graph.nodes if stack_graph is not None else graph.nodes
        parent_type = sg_nodes.get(parent_scope_id, {}).get("stack_graph_scope_type")
        return parent_type == ScopeType.FILE.value
