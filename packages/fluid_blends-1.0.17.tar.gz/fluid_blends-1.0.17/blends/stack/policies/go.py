from __future__ import annotations

from typing import TYPE_CHECKING

from blends.stack.policies.base import ExportPolicy
from blends.stack.scope_types import ScopeType

if TYPE_CHECKING:
    from blends.models import NId, StackGraph, SyntaxGraph


class GoExportPolicy(ExportPolicy):
    def is_scope_exported(
        self,
        _graph: SyntaxGraph,
        _node_id: NId,
        scope_type: str | None,
    ) -> bool:
        return scope_type == ScopeType.FILE.value

    def is_definition_exported(
        self,
        graph: SyntaxGraph,
        stack_graph: StackGraph | None,
        node_id: NId,
        parent_scope_id: NId | None,
    ) -> bool:
        sg_nodes = stack_graph.nodes if stack_graph is not None else graph.nodes
        if parent_scope_id is not None:
            scope_type = sg_nodes.get(parent_scope_id, {}).get("stack_graph_scope_type")
            if scope_type != ScopeType.FILE.value:
                return False
        symbol = sg_nodes.get(node_id, {}).get("stack_graph_symbol")
        if isinstance(symbol, str) and len(symbol) > 0:
            return bool(symbol[0].isupper())
        name = graph.nodes[node_id].get("name")
        if isinstance(name, str) and len(name) > 0:
            return bool(name[0].isupper())
        return False
