from typing import TypedDict


class StackNodeAttrs(TypedDict, total=False):
    stack_graph_import_module_stem: str
    stack_graph_import_relative_level: int
    stack_graph_import_source_symbol: str
    stack_graph_is_definition: bool
    stack_graph_is_exported: bool
    stack_graph_is_import_binding: bool
    stack_graph_is_reference: bool
    stack_graph_kind: str
    stack_graph_precedence: int
    stack_graph_scope: int | None
    stack_graph_scope_type: str
    stack_graph_symbol: str | None
    label_type: str
