from typing import Final

STACK_GRAPH_IS_DEFINITION: Final = "stack_graph_is_definition"
STACK_GRAPH_IS_EXPORTED: Final = "stack_graph_is_exported"
STACK_GRAPH_IS_IMPORT_BINDING: Final = "stack_graph_is_import_binding"
STACK_GRAPH_IMPORT_MODULE_STEM: Final = "stack_graph_import_module_stem"
STACK_GRAPH_IMPORT_RELATIVE_LEVEL: Final = "stack_graph_import_relative_level"
STACK_GRAPH_IMPORT_SOURCE_SYMBOL: Final = "stack_graph_import_source_symbol"
STACK_GRAPH_IS_REFERENCE: Final = "stack_graph_is_reference"
STACK_GRAPH_KIND: Final = "stack_graph_kind"
STACK_GRAPH_PRECEDENCE: Final = "stack_graph_precedence"
STACK_GRAPH_SCOPE: Final = "stack_graph_scope"
STACK_GRAPH_SCOPE_TYPE: Final = "stack_graph_scope_type"
STACK_GRAPH_SYMBOL: Final = "stack_graph_symbol"
