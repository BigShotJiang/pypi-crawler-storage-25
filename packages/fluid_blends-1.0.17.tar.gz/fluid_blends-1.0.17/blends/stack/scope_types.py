from enum import StrEnum


class ScopeType(StrEnum):
    FILE = "file"
    CLASS = "class"
    FUNCTION = "function"
    BLOCK = "block"
    NAMESPACE = "namespace"
