from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

from blends.stack.bridge_paths import collect_star_import_stems, expand_star_bridges
from blends.stack.criteria import (
    is_definition_endpoint,
    is_import_binding_endpoint,
    is_reference_endpoint,
)
from blends.stack.multi_file_stitcher import MultiFileForwardStitcher
from blends.stack.partial_path_db import PartialPathDb
from blends.stack.selection import edge_list_shadows
from blends.syntax.builders.module_path import _INDEX_STEMS

if TYPE_CHECKING:
    from blends.stack.forward_stitcher import ForwardStitcherConfig
    from blends.stack.partial_path import (
        FileHandle,
        PartialPath,
        PartialPathDatabase,
        PartialSymbolStack,
    )
    from blends.stack.selection import PartialPathEdge
    from blends.stack.view import StackGraphView


@dataclass(frozen=True, slots=True)
class MultiFileResolutionStats:
    phases_executed: int
    candidates_considered: int
    concatenations_succeeded: int
    complete_paths_found: int
    cancelled: bool
    cycle_guard_hits: int
    queue_pruned_count: int
    files_considered: int


@dataclass(frozen=True, slots=True)
class MultiFileResolutionRequest:
    file_handle: FileHandle
    ref_node_index: int
    config: ForwardStitcherConfig | None = None
    include_stats: bool = False


@dataclass(frozen=True, slots=True)
class _MultiFileDefinitionCandidate:
    definition_node_index: int
    file_handle: FileHandle
    edges: tuple[PartialPathEdge, ...]
    is_import_binding: bool


def _build_source_only_db(
    database: PartialPathDatabase,
    view: StackGraphView,
    source_fh: FileHandle,
) -> PartialPathDb:
    db = PartialPathDb(symbols=view.symbols)
    record = database.get_file(source_fh)
    if record is not None:
        db.add_file(record)
    return db


def _effective_module_stem(file_path: str) -> str:
    p = Path(file_path)
    return p.parent.name if p.stem in _INDEX_STEMS else p.stem


def _build_stem_index(
    database: PartialPathDatabase,
    views: dict[FileHandle, StackGraphView] | None = None,
) -> dict[str, FileHandle]:
    result: dict[str, FileHandle] = {}
    for fh in database.list_files():
        record = database.get_file(fh)
        if record is None:
            continue
        view = views.get(fh) if views is not None else None
        key = (
            view.module_path
            if view is not None and view.module_path
            else _effective_module_stem(record.file_path)
        )
        result[key] = fh
    return result


def _extract_module_path(
    symbol_stack: PartialSymbolStack,
    db: PartialPathDb,
) -> str | None:
    parts: list[str] = []
    expect_name = True
    for sym in symbol_stack.symbols:
        if sym.symbol_id >= len(db.symbols.id_to_symbol):
            break
        name = db.symbols.id_to_symbol[sym.symbol_id]
        if expect_name:
            if name == ".":
                break
            parts.append(name)
            expect_name = False
        else:
            if name != ".":
                break
            expect_name = True
    return ".".join(parts) if parts else None


def resolve_definitions_multi_file(
    view: StackGraphView,
    database: PartialPathDatabase,
    *,
    request: MultiFileResolutionRequest,
    views: dict[FileHandle, StackGraphView] | None = None,
) -> list[tuple[FileHandle, int]] | tuple[list[tuple[FileHandle, int]], MultiFileResolutionStats]:
    if not is_reference_endpoint(view, request.ref_node_index):
        return _empty_multi_result(include_stats=request.include_stats)

    if request.file_handle not in database.list_files():
        return _empty_multi_result(include_stats=request.include_stats)
    if not _ref_record_matches_view(view, request, database):
        return _empty_multi_result(include_stats=request.include_stats)

    db = _build_source_only_db(database, view, request.file_handle)
    all_views: dict[FileHandle, StackGraphView] = (
        views if views is not None else {request.file_handle: view}
    )
    stitcher = MultiFileForwardStitcher.from_references(
        view=view,
        file_handle=request.file_handle,
        db=db,
        reference_nodes=(request.ref_node_index,),
        config=request.config,
        views=all_views,
    )
    pairs, latest_stats, files_loaded = _run_resolution_multi_file(
        view, stitcher, database, all_views, db
    )
    return _finalize_multi_result(
        pairs, latest_stats, files_loaded, include_stats=request.include_stats
    )


def _empty_multi_result(
    *,
    include_stats: bool,
) -> list[tuple[FileHandle, int]] | tuple[list[tuple[FileHandle, int]], MultiFileResolutionStats]:
    if include_stats:
        return [], MultiFileResolutionStats(
            phases_executed=0,
            candidates_considered=0,
            concatenations_succeeded=0,
            complete_paths_found=0,
            cancelled=False,
            cycle_guard_hits=0,
            queue_pruned_count=0,
            files_considered=0,
        )
    return []


def _collect_multi_file_candidates(
    views: dict[FileHandle, StackGraphView],
    complete_paths: tuple[tuple[FileHandle, PartialPath], ...],
    ref_view: StackGraphView,
) -> list[_MultiFileDefinitionCandidate]:
    new_candidates: list[_MultiFileDefinitionCandidate] = []
    for def_fh, path in complete_paths:
        def_view = views.get(def_fh, ref_view)
        if not is_definition_endpoint(def_view, path.end_node_index):
            continue
        new_candidates.append(
            _MultiFileDefinitionCandidate(
                definition_node_index=path.end_node_index,
                file_handle=def_fh,
                edges=path.edges,
                is_import_binding=is_import_binding_endpoint(def_view, path.end_node_index),
            )
        )
    return new_candidates


def _multi_candidate_sort_key(c: _MultiFileDefinitionCandidate) -> tuple[FileHandle, int]:
    return (c.file_handle, c.definition_node_index)


def _prune_multi_shadowed(
    candidates: list[_MultiFileDefinitionCandidate],
) -> list[_MultiFileDefinitionCandidate]:
    kept: list[_MultiFileDefinitionCandidate] = []
    for candidate in sorted(candidates, key=_multi_candidate_sort_key):
        is_dominated = any(edge_list_shadows(k.edges, candidate.edges) for k in kept)
        if is_dominated:
            continue
        kept = [k for k in kept if not edge_list_shadows(candidate.edges, k.edges)]
        kept.append(candidate)
    return kept


def _sort_multi_deterministically(
    candidates: list[_MultiFileDefinitionCandidate],
) -> list[_MultiFileDefinitionCandidate]:
    def sort_key(
        candidate: _MultiFileDefinitionCandidate,
    ) -> tuple[tuple[int, ...], tuple[int, ...], int, int]:
        edge_sources = tuple(edge.source_node_index for edge in candidate.edges)
        edge_precedences = tuple(-edge.precedence for edge in candidate.edges)
        return (
            edge_sources,
            edge_precedences,
            candidate.file_handle,
            candidate.definition_node_index,
        )

    return sorted(candidates, key=sort_key)


def _select_multi_file_definitions(
    candidates: list[_MultiFileDefinitionCandidate],
) -> list[tuple[FileHandle, int]]:
    if not candidates:
        return []
    real = [c for c in candidates if not c.is_import_binding]
    pruned = _prune_multi_shadowed(real or candidates)
    ordered = _sort_multi_deterministically(pruned)
    seen: set[tuple[int, int]] = set()
    pairs: list[tuple[FileHandle, int]] = []
    for candidate in ordered:
        key = (candidate.file_handle, candidate.definition_node_index)
        if key in seen:
            continue
        seen.add(key)
        pairs.append(key)
    return pairs


def _inject_star_bridges(
    db: PartialPathDb,
    consumer_view: StackGraphView,
    consumer_fh: FileHandle,
    target_view: StackGraphView,
    star_node_index: int | None,
) -> None:
    if star_node_index is None:
        return
    for bridge in expand_star_bridges(consumer_view, star_node_index, target_view):
        db.add_bridge_path(consumer_fh, bridge)


def _apply_star_bridges(
    view: StackGraphView,
    stem_index: dict[str, FileHandle],
    all_views: dict[FileHandle, StackGraphView],
    db: PartialPathDb,
    consumer_fh: FileHandle,
) -> None:
    for stem, star_node in collect_star_import_stems(view).items():
        target_fh = stem_index.get(stem)
        if target_fh is None:
            continue
        fh_view = all_views.get(target_fh)
        if fh_view is not None:
            _inject_star_bridges(db, view, consumer_fh, fh_view, star_node)


def _run_resolution_multi_file(
    view: StackGraphView,
    stitcher: MultiFileForwardStitcher,
    database: PartialPathDatabase,
    all_views: dict[FileHandle, StackGraphView],
    db: PartialPathDb,
) -> tuple[list[tuple[FileHandle, int]], MultiFileResolutionStats | None, int]:
    candidates: list[_MultiFileDefinitionCandidate] = []
    loaded: set[FileHandle] = {stitcher.file_handle}
    stem_index = _build_stem_index(database, all_views)
    _apply_star_bridges(view, stem_index, all_views, db, stitcher.file_handle)
    result = None

    while not stitcher.is_complete():
        result = stitcher.process_next_phase()
        for _fh, sym_stack in result.load_requests.root_requests:
            if (stem := _extract_module_path(sym_stack, db)) is None:
                continue
            if (target_fh := stem_index.get(stem)) is None or target_fh in loaded:
                continue
            loaded.add(target_fh)
            if (rec := database.get_file(target_fh)) is not None:
                db.add_file(rec)
            if (fh_view := all_views.get(target_fh)) is not None:
                stitcher.views[target_fh] = fh_view
        candidates.extend(_collect_multi_file_candidates(all_views, result.complete_paths, view))

    pairs = _select_multi_file_definitions(candidates)
    if result is None:
        return pairs, None, len(loaded)
    latest_stats = MultiFileResolutionStats(
        phases_executed=result.stats.phases_executed,
        candidates_considered=result.stats.candidates_considered,
        concatenations_succeeded=result.stats.concatenations_succeeded,
        complete_paths_found=result.stats.complete_paths_found,
        cancelled=result.stats.cancelled,
        cycle_guard_hits=result.stats.cycle_guard_hits,
        queue_pruned_count=result.stats.queue_pruned_count,
        files_considered=len(loaded),
    )
    return pairs, latest_stats, len(loaded)


def _finalize_multi_result(
    pairs: list[tuple[FileHandle, int]],
    latest_stats: MultiFileResolutionStats | None,
    files_considered: int,
    *,
    include_stats: bool,
) -> list[tuple[FileHandle, int]] | tuple[list[tuple[FileHandle, int]], MultiFileResolutionStats]:
    if include_stats:
        if latest_stats is None:
            latest_stats = MultiFileResolutionStats(
                phases_executed=0,
                candidates_considered=0,
                concatenations_succeeded=0,
                complete_paths_found=0,
                cancelled=False,
                cycle_guard_hits=0,
                queue_pruned_count=0,
                files_considered=files_considered,
            )
        return pairs, latest_stats
    return pairs


def _ref_record_matches_view(
    view: StackGraphView,
    request: MultiFileResolutionRequest,
    database: PartialPathDatabase,
) -> bool:
    record = database.get_file(request.file_handle)
    if record is None:
        return False
    if record.file_path and view.file_path:
        return record.file_path == view.file_path
    return True
