from typing import TypedDict


class EdgeAttrs(TypedDict, total=False):
    label_ast: str
    label_cfg: str
    label_index: str
    precedence: int
