from blends.models import (
    NId,
)
from blends.query import (
    match_ast,
)
from blends.syntax.builders.method_declaration import (
    DirectChildren,
    build_method_declaration_node,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)


def reader(args: SyntaxGraphArgs) -> NId:
    n_attrs = args.ast_graph.nodes[args.n_id]
    block_id = n_attrs["label_field_body"]

    parameters_id = n_attrs["label_field_parameters"]
    include_params = "__0__" in match_ast(args.ast_graph, parameters_id, "(", ")")

    direct: DirectChildren = {"block_id": block_id}
    if include_params:
        direct["parameters_id"] = parameters_id

    return build_method_declaration_node(args, None, direct, {})
