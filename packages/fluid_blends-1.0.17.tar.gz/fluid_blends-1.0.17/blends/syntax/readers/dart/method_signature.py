from blends.models import (
    NId,
)
from blends.query import (
    adj_ast,
    match_ast,
    search_pred_until_type,
)
from blends.syntax.builders.method_declaration import (
    DirectChildren,
    build_method_declaration_node,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)


def reader(args: SyntaxGraphArgs) -> NId:
    graph = args.ast_graph
    childs = adj_ast(graph, args.n_id)
    if len(childs) == 1 and graph.nodes[childs[0]]["label_type"] == "function_signature":
        return args.generic(args.fork_n_id(childs[0]))

    body_parents = {
        "class_body",
        "extension_body",
    }
    m_name = None
    body_id = None

    parents = search_pred_until_type(graph, args.n_id, body_parents)
    if parents and (class_childs := list(adj_ast(graph, parents[0]))):
        al_list = match_ast(graph, args.n_id, "formal_parameter_list", "static")

        parameters_id = al_list.get("formal_parameter_list")
        body_id = class_childs[class_childs.index(parents[1]) + 1]

        direct: DirectChildren = {}
        if body_id:
            direct["block_id"] = body_id
        if parameters_id:
            direct["parameters_id"] = parameters_id

        return build_method_declaration_node(args, m_name, direct, {})

    return build_method_declaration_node(args, m_name, {}, {})
