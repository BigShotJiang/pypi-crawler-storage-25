from blends.models import (
    NId,
)
from blends.query import (
    match_ast,
)
from blends.syntax.builders.while_statement import (
    build_while_statement_node,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)


def reader(args: SyntaxGraphArgs) -> NId:
    graph = args.ast_graph
    n_attrs = graph.nodes[args.n_id]

    body_id = n_attrs["label_field_body"]
    if graph.nodes[body_id]["label_type"] == "expression_statement":
        inner = match_ast(graph, body_id).get("__0__")
        if inner is not None:
            body_id = inner
    if graph.nodes[body_id]["label_type"] == "parenthesized_expression":
        inner = match_ast(graph, body_id).get("__1__")
        if inner is not None:
            body_id = inner

    cond_id = n_attrs["label_field_condition"]
    if graph.nodes[cond_id]["label_type"] == "parenthesized_expression":
        inner = match_ast(graph, cond_id).get("__1__")
        if inner is not None:
            cond_id = inner

    return build_while_statement_node(args, body_id, cond_id)
