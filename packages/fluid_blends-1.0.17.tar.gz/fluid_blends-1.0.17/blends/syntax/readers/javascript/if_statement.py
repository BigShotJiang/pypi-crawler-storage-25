from blends.models import (
    NId,
)
from blends.query import (
    match_ast,
)
from blends.syntax.builders.if_statement import (
    build_if_node,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)


def reader(args: SyntaxGraphArgs) -> NId:
    graph = args.ast_graph
    n_attrs = graph.nodes[args.n_id]

    condition_id = n_attrs["label_field_condition"]
    if graph.nodes[condition_id]["label_type"] == "parenthesized_expression":
        inner = match_ast(graph, condition_id).get("__1__")
        if inner is not None:
            condition_id = inner

    true_id = n_attrs["label_field_consequence"]
    if graph.nodes[true_id]["label_type"] == "expression_statement":
        inner = match_ast(graph, true_id).get("__0__")
        if inner is not None:
            true_id = inner

    false_id = n_attrs.get("label_field_alternative")
    return build_if_node(args, condition_id, true_id, false_id)
