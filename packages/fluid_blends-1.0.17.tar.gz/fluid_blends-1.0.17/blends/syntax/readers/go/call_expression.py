from blends.models import (
    NId,
)
from blends.query import (
    match_ast,
)
from blends.syntax.builders.method_invocation import (
    DirectChildren,
    build_method_invocation_node,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)
from blends.utilities.text_nodes import (
    node_to_str,
)


def reader(args: SyntaxGraphArgs) -> NId:
    call_node = args.ast_graph.nodes[args.n_id]
    method_id = call_node["label_field_function"]
    expr = node_to_str(args.ast_graph, method_id)

    args_id = call_node["label_field_arguments"]
    include_args = "__0__" in match_ast(args.ast_graph, args_id, "(", ")")

    children: DirectChildren = {"expression_id": method_id}
    if include_args:
        children["arguments_id"] = args_id

    return build_method_invocation_node(args, expr, children)
