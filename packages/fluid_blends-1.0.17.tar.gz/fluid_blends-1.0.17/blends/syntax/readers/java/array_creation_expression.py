from blends.models import (
    NId,
)
from blends.query import (
    adj_ast,
    match_ast,
    match_ast_d,
)
from blends.syntax.builders.array_node import (
    build_array_node,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)


def reader(args: SyntaxGraphArgs) -> NId:
    graph = args.ast_graph
    label_value = graph.nodes[args.n_id].get("label_field_value")
    arr_value = label_value if label_value is not None else adj_ast(graph, args.n_id)[-1]

    if (
        (dim_expr := match_ast_d(graph, args.n_id, "dimensions_expr"))
        and (childs := match_ast(graph, dim_expr, "[", "]"))
        and (inner := childs.get("__0__")) is not None
    ):
        arr_value = inner

    return build_array_node(args, (arr_value,))
