from blends.models import (
    NId,
)
from blends.query import (
    match_ast,
)
from blends.syntax.builders.binary_operation import (
    build_binary_operation_node,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)


def reader(args: SyntaxGraphArgs) -> NId:
    graph = args.ast_graph
    left_id = args.ast_graph.nodes[args.n_id]["label_field_left"]
    if graph.nodes[left_id]["label_type"] == "parenthesized_expression":
        inner = match_ast(graph, left_id).get("__1__")
        if inner is not None:
            left_id = inner
    right_id = args.ast_graph.nodes[args.n_id]["label_field_right"]
    if graph.nodes[right_id]["label_type"] == "parenthesized_expression":
        inner = match_ast(graph, right_id).get("__1__")
        if inner is not None:
            right_id = inner
    operator_id = args.ast_graph.nodes[args.n_id]["label_field_operator"]
    operator = args.ast_graph.nodes[operator_id]["label_text"]
    return build_binary_operation_node(args, operator, left_id, right_id)
