from blends.models import (
    Graph,
    NId,
)
from blends.query import (
    adj_ast,
    match_ast_d,
)
from blends.syntax.builders.method_invocation import (
    DirectChildren,
    build_method_invocation_node,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)
from blends.utilities.text_nodes import (
    node_to_str,
)

SELECTORS_ONE_PART = 1
SELECTORS_TWO_PART = 2


def try_build_chained_invocation(
    args: SyntaxGraphArgs,
    graph: Graph,
    symbol: str,
    identifier_id: NId,
    selectors: list[NId],
) -> NId | None:
    if len(selectors) != SELECTORS_TWO_PART:
        return None
    uas = match_ast_d(graph, selectors[0], "unconditional_assignable_selector")
    arg_part = match_ast_d(graph, selectors[1], "argument_part")
    if uas and arg_part:
        expr_children = adj_ast(graph, uas)
        if expr_children:
            method_node = expr_children[1] if len(expr_children) > 1 else expr_children[0]
            expr = symbol + "." + node_to_str(graph, method_node)
            args_id = match_ast_d(graph, arg_part, "arguments")
            children: DirectChildren = {
                "object_id": identifier_id,
                "expression_id": method_node,
            }
            if args_id:
                children["arguments_id"] = args_id
            return build_method_invocation_node(args, expr, children)
    return None


def try_build_simple_invocation(
    args: SyntaxGraphArgs,
    graph: Graph,
    symbol: str,
    selectors: list[NId],
) -> NId | None:
    if len(selectors) != SELECTORS_ONE_PART:
        return None
    arg_part = match_ast_d(graph, selectors[0], "argument_part")
    if arg_part:
        args_id = match_ast_d(graph, arg_part, "arguments")
        children: DirectChildren = {}
        if args_id:
            children["arguments_id"] = args_id
        return build_method_invocation_node(args, symbol, children)
    return None
