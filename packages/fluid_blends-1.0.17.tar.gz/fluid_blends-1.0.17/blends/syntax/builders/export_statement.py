from collections.abc import Sequence

from blends.ctx import ctx
from blends.models import (
    NId,
)
from blends.syntax.builders.import_module import (
    build_import_module_node,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)


def build_export_statement_node(
    args: SyntaxGraphArgs,
    expression: str | None,
    exported_block: NId | None,
    reexport_specifiers: Sequence[tuple[NId, str, str | None, str]] = (),
) -> NId:
    args.syntax_graph.add_node(
        args.n_id,
        label_type="Export",
    )

    if expression:
        args.syntax_graph.update_node_attribute(args.n_id, "expression", expression)

    if exported_block:
        args.syntax_graph.update_node_attribute(args.n_id, "declaration_id", exported_block)
        args.syntax_graph.add_edge(
            args.n_id,
            args.generic(args.fork_n_id(exported_block)),
            label_ast="AST",
        )

    if reexport_specifiers and ctx.has_feature_flag("StackGraph"):
        for spec_n_id, expr, alias, module_path in reexport_specifiers:
            build_import_module_node(
                args.fork_n_id(spec_n_id),
                expression=expr,
                alias=alias,
                module_path=module_path,
            )

    return args.n_id
