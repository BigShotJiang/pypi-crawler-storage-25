from blends.models import (
    NId,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)


def build_if_node(
    args: SyntaxGraphArgs,
    condition_id: NId,
    true_id: NId | None = None,
    false_id: NId | None = None,
    initializer: NId | None = None,
) -> NId:
    args.syntax_graph.add_node(
        args.n_id,
        condition_id=condition_id,
        label_type="If",
    )

    sanitization_stack = args.metadata.get("sanitization_stack")
    stack_depth_before = len(sanitization_stack) if sanitization_stack is not None else 0
    if sanitization_stack is not None:
        sanitization_stack.append(("condition_pending", args.n_id))

    args.syntax_graph.add_edge(
        args.n_id,
        args.generic(args.fork_n_id(condition_id)),
        label_ast="AST",
    )

    if sanitization_stack is not None:
        while len(sanitization_stack) > stack_depth_before:
            sanitization_stack.pop()

    control_flow_stack = args.metadata.get("control_flow_stack", [])

    if true_id:
        args.syntax_graph.update_node_attribute(args.n_id, "true_id", true_id)
        control_flow_stack.append(args.n_id)
        args.syntax_graph.add_edge(
            args.n_id,
            args.generic(args.fork_n_id(true_id)),
            label_ast="AST",
        )
        control_flow_stack.pop()

    if false_id:
        args.syntax_graph.update_node_attribute(args.n_id, "false_id", false_id)
        control_flow_stack.append(false_id)
        args.syntax_graph.add_edge(
            args.n_id,
            args.generic(args.fork_n_id(false_id)),
            label_ast="AST",
        )
        control_flow_stack.pop()

    if initializer:
        args.syntax_graph.update_node_attribute(args.n_id, "initializer", initializer)
        args.syntax_graph.add_edge(
            args.n_id,
            args.generic(args.fork_n_id(initializer)),
            label_ast="AST",
        )

    return args.n_id
