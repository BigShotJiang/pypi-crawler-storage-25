from blends.models import (
    NId,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)


def build_do_statement_node(args: SyntaxGraphArgs, block: NId, conditional: NId) -> NId:
    args.syntax_graph.add_node(
        args.n_id,
        block_id=block,
        condition_id=conditional,
        label_type="DoStatement",
    )

    control_flow_stack = args.metadata.get("control_flow_stack", [])
    control_flow_stack.append(args.n_id)
    args.syntax_graph.add_edge(
        args.n_id,
        args.generic(args.fork_n_id(block)),
        label_ast="AST",
    )
    control_flow_stack.pop()

    args.syntax_graph.add_edge(
        args.n_id,
        args.generic(args.fork_n_id(conditional)),
        label_ast="AST",
    )

    return args.n_id
