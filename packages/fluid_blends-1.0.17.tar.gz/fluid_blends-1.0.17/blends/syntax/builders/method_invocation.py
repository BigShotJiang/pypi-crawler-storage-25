from typing import TypedDict, cast

from blends.models import (
    NId,
)
from blends.query import adj_ast
from blends.syntax.models import (
    SyntaxGraphArgs,
)


class DirectChildren(TypedDict, total=False):
    expression_id: NId
    arguments_id: NId
    object_id: NId
    block_id: NId


def _process_invocation_children(
    args: SyntaxGraphArgs,
    children: DirectChildren,
) -> None:
    for name_node, child_id in cast("dict[str, NId]", children).items():
        args.syntax_graph.update_node_attribute(args.n_id, name_node, child_id)
        args.syntax_graph.add_edge(
            args.n_id,
            args.generic(args.fork_n_id(child_id)),
            label_ast="AST",
        )


def _index_direct_arguments(args: SyntaxGraphArgs) -> None:
    arguments_id = args.syntax_graph.nodes[args.n_id].get("arguments_id")
    if (arguments_id is None) or not (scope_stack := args.metadata.get("scope_stack")):
        return

    scope = scope_stack[-1]
    for child_id in adj_ast(args.syntax_graph, arguments_id, depth=1):
        label_type = args.syntax_graph.nodes[child_id].get("label_type")
        if label_type == "SymbolLookup" and (
            symbol := args.syntax_graph.nodes[child_id].get("symbol")
        ):
            args.syntax_graph.register_sanitization(
                str(symbol),
                scope=scope,
                node_id=args.n_id,
                kind="method_arg",
            )
        elif (
            (label_type == "MemberAccess")
            and (expression := args.syntax_graph.nodes[child_id].get("expression", ""))
            and (member := args.syntax_graph.nodes[child_id].get("member", ""))
        ):
            args.syntax_graph.register_sanitization(
                f"{expression}.{member}",
                scope=scope,
                node_id=args.n_id,
                kind="method_arg",
            )
        elif (label_type == "NamedArgument") and (
            value_id := args.syntax_graph.nodes[child_id].get("value_id")
        ):
            value_node = args.syntax_graph.nodes[value_id]
            value_type = value_node.get("label_type")
            if value_type == "SymbolLookup" and (symbol := value_node.get("symbol")):
                args.syntax_graph.register_sanitization(
                    str(symbol),
                    scope=scope,
                    node_id=args.n_id,
                    kind="method_arg",
                )
            elif (
                value_type == "MemberAccess"
                and (expression := value_node.get("expression", ""))
                and (member := value_node.get("member", ""))
            ):
                args.syntax_graph.register_sanitization(
                    f"{expression}.{member}",
                    scope=scope,
                    node_id=args.n_id,
                    kind="method_arg",
                )


def build_method_invocation_node(
    args: SyntaxGraphArgs,
    expr: str,
    direct_children: DirectChildren,
    object_name: str | None = None,
) -> NId:
    args.syntax_graph.add_node(
        args.n_id,
        expression=expr,
        label_type="MethodInvocation",
    )
    if object_name:
        args.syntax_graph.update_node_attribute(args.n_id, "object", object_name)
    if scope_stack := args.metadata.get("scope_stack"):
        args.syntax_graph.update_node_attribute(args.n_id, "symbol_scope", scope_stack[-1])
    _process_invocation_children(args, direct_children)

    _index_direct_arguments(args)

    return args.n_id
