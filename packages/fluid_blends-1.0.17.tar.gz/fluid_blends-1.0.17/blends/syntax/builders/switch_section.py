from collections.abc import (
    Iterable,
)

from blends.models import (
    NId,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)


def build_switch_section_node(
    args: SyntaxGraphArgs,
    case_expr: str,
    execution_ids: Iterable[NId],
) -> NId:
    args.syntax_graph.add_node(
        args.n_id,
        case_expression=case_expr,
        label_type="SwitchSection",
    )

    control_flow_stack = args.metadata.get("control_flow_stack", [])
    control_flow_stack.append(args.n_id)
    for statement_id in execution_ids:
        args.syntax_graph.add_edge(
            args.n_id,
            args.generic(args.fork_n_id(statement_id)),
            label_ast="AST",
        )
    control_flow_stack.pop()

    return args.n_id
