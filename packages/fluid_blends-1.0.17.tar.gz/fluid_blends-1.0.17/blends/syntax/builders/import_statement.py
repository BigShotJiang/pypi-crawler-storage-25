from typing import TypedDict

from blends.ctx import ctx
from blends.models import (
    NId,
)
from blends.stack.edges import (
    Edge,
    add_edge,
)
from blends.stack.node_helpers import (
    import_binding_node_attributes,
)
from blends.syntax.builders.import_reference_chain import (
    build_import_reference_chain_to_root,
    normalize_module_path,
)
from blends.syntax.builders.utils import (
    get_next_binding_precedence,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)


class ImportElement(TypedDict, total=False):
    expression: str
    label_alias: str
    method_name: str
    corrected_n_id: NId


def _node_attrs(element: ImportElement) -> dict[str, str]:
    return {k: v for k, v in element.items() if k != "corrected_n_id"}  # type: ignore[misc]


def _bound_import_symbol(*, expression: str, alias: str | None) -> str:
    if isinstance(alias, str) and alias:
        return alias
    parts = expression.split(".")
    return parts[-1] if parts else expression


def _mark_import_as_definition(
    args: SyntaxGraphArgs, *, node_id: NId, expression: str, alias: str | None
) -> None:
    if not ctx.has_feature_flag("StackGraph"):
        return
    bound = _bound_import_symbol(expression=expression, alias=alias)
    if not bound:
        return
    precedence = get_next_binding_precedence(args)
    module_stem = normalize_module_path(expression)
    source_symbol = expression.rsplit(".", maxsplit=1)[-1] if alias else None
    import_attrs = import_binding_node_attributes(
        symbol=bound,
        precedence=precedence,
        import_module_stem=module_stem,
        import_source_symbol=source_symbol,
    )
    if args.stack_graph is not None:
        args.stack_graph.add_node(node_id, **import_attrs)
    scope_stack = args.metadata.setdefault("scope_stack", [])
    if scope_stack and (parent_scope := scope_stack[-1]):
        edge = Edge(source=parent_scope, sink=node_id, precedence=precedence)
        if args.stack_graph is not None:
            add_edge(args.stack_graph, edge)
    if args.stack_graph is not None:
        build_import_reference_chain_to_root(args, module_stem, node_id)


def build_import_statement_node(args: SyntaxGraphArgs, *imported_elements: ImportElement) -> NId:
    if len(imported_elements) == 1:
        element = imported_elements[0]
        args.syntax_graph.add_node(
            args.n_id,
            **_node_attrs(element),
            label_type="Import",
        )
        expression = element.get("expression", "")
        alias = element.get("label_alias")
        _mark_import_as_definition(args, node_id=args.n_id, expression=expression, alias=alias)
    else:
        args.syntax_graph.add_node(
            args.n_id,
            import_type="multiple_import",
            label_type="Import",
        )
        for element in imported_elements:
            corrected_n_id = element.get("corrected_n_id")
            if corrected_n_id:
                args.syntax_graph.add_node(
                    corrected_n_id, **_node_attrs(element), label_type="Import"
                )
                args.syntax_graph.add_edge(args.n_id, corrected_n_id, label_ast="AST")
                expression = element.get("expression", "")
                alias = element.get("label_alias")
                _mark_import_as_definition(
                    args,
                    node_id=corrected_n_id,
                    expression=expression,
                    alias=alias,
                )

    return args.n_id
