from typing import TypedDict, cast

from blends.ctx import ctx
from blends.models import (
    Language,
    NId,
)
from blends.stack.edges import (
    Edge,
    add_edge,
)
from blends.stack.node_helpers import (
    pop_scoped_symbol_node_attributes,
    scope_node_attributes,
)
from blends.stack.scope_types import ScopeType
from blends.syntax.builders.utils import (
    _record_subpath,
    get_next_binding_precedence,
    get_next_synthetic_node_id,
)
from blends.syntax.metadata.java import (
    add_node_range_to_method,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)


class DirectChildren(TypedDict, total=False):
    block_id: NId
    modifiers_id: NId
    parameters_id: NId


class ListChildren(TypedDict, total=False):
    modifiers_ids: list[NId]
    parameters_ids: list[NId]


def _add_child(args: SyntaxGraphArgs, name_node: str, child_id: NId) -> None:
    args.syntax_graph.update_node_attribute(args.n_id, name_node, child_id)
    args.syntax_graph.add_edge(
        args.n_id,
        args.generic(args.fork_n_id(child_id)),
        label_ast="AST",
    )


def _process_method_children(
    args: SyntaxGraphArgs,
    children: DirectChildren,
) -> None:
    children_dict = cast("dict[str, NId]", children)
    if "parameters_id" in children_dict:
        _add_child(args, "parameters_id", children_dict["parameters_id"])
    for name_node, child_id in children_dict.items():
        if name_node == "parameters_id":
            continue
        _add_child(args, name_node, child_id)


def _process_method_list_children(
    args: SyntaxGraphArgs,
    children: ListChildren,
) -> None:
    for n_ids in cast("dict[str, list[NId]]", children).values():
        for child_id in n_ids:
            args.syntax_graph.add_edge(
                args.n_id,
                args.generic(args.fork_n_id(child_id)),
                label_ast="AST",
            )


def _emit_named_method_definition(
    args: SyntaxGraphArgs, name: str, parent_scope: NId, precedence: int
) -> None:
    method_def_id = get_next_synthetic_node_id(args)
    def_stack_attrs = pop_scoped_symbol_node_attributes(symbol=name, precedence=precedence)
    if args.stack_graph is not None:
        args.stack_graph.add_node(method_def_id, **def_stack_attrs)
    edge_parent = Edge(source=parent_scope, sink=method_def_id, precedence=precedence)
    edge_def = Edge(source=method_def_id, sink=args.n_id, precedence=0)
    if args.stack_graph is not None:
        add_edge(args.stack_graph, edge_parent)
        add_edge(args.stack_graph, edge_def)
    ast_node = args.ast_graph.nodes.get(args.n_id, {})
    if (label_l := ast_node.get("label_l")) is not None and args.stack_graph is not None:
        args.stack_graph.update_node(
            method_def_id, {"label_l": label_l, "label_c": ast_node.get("label_c", "0")}
        )


def _setup_stack_graph_scope(args: SyntaxGraphArgs, name: str | None) -> None:
    scope_stack = args.metadata.setdefault("scope_stack", [])
    if name and scope_stack and (parent_scope := scope_stack[-1]):
        precedence = get_next_binding_precedence(args)
        _emit_named_method_definition(args, name, parent_scope, precedence)

    scope_stack_attrs = scope_node_attributes(is_exported=False, scope_type=ScopeType.FUNCTION)
    if args.stack_graph is not None:
        args.stack_graph.add_node(args.n_id, **scope_stack_attrs)
    if scope_stack:
        edge_scope = Edge(source=args.n_id, sink=scope_stack[-1], precedence=0)
        if args.stack_graph is not None:
            add_edge(args.stack_graph, edge_scope)
    scope_stack.append(args.n_id)


def _cleanup_stack_graph_scope(args: SyntaxGraphArgs) -> None:
    scope_stack = args.metadata.setdefault("scope_stack", [])
    if scope_stack and scope_stack[-1] == args.n_id:
        scope_stack.pop()


def _register_scope_index(args: SyntaxGraphArgs, name: str | None) -> None:
    scope_stack = args.metadata.setdefault("scope_stack", [])
    if scope_stack:
        parent_scope = scope_stack[-1]
        args.syntax_graph.scope_parent[args.n_id] = parent_scope
        if name:
            args.syntax_graph.symbol_index.setdefault(name, {}).setdefault(parent_scope, []).append(
                args.n_id
            )
            _record_subpath(args, args.n_id)


def _setup_scope_index(args: SyntaxGraphArgs, name: str | None) -> None:
    _register_scope_index(args, name)
    scope_stack = args.metadata.setdefault("scope_stack", [])
    scope_stack.append(args.n_id)


def _cleanup_scope_index(args: SyntaxGraphArgs) -> None:
    scope_stack = args.metadata.setdefault("scope_stack", [])
    if scope_stack and scope_stack[-1] == args.n_id:
        scope_stack.pop()


def build_method_declaration_node(
    args: SyntaxGraphArgs,
    name: str | None,
    direct_children: DirectChildren,
    list_children: ListChildren,
    access_modifiers: str | None = None,
) -> NId:
    args.syntax_graph.add_node(args.n_id, label_type="MethodDeclaration")
    if name:
        args.syntax_graph.update_node_attribute(args.n_id, "name", name)

    if access_modifiers:
        args.syntax_graph.update_node_attribute(args.n_id, "access_modifiers", access_modifiers)

    if ctx.has_feature_flag("StackGraph"):
        _register_scope_index(args, name)
        _setup_stack_graph_scope(args, name)
    else:
        _setup_scope_index(args, name)

    _process_method_children(args, direct_children)
    _process_method_list_children(args, list_children)

    if args.language == Language.JAVA and args.syntax_graph.nodes.get(0) and name:
        add_node_range_to_method(args, name)

    if ctx.has_feature_flag("StackGraph"):
        _cleanup_stack_graph_scope(args)
    else:
        _cleanup_scope_index(args)

    return args.n_id
