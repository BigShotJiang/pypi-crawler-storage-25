from blends.models import (
    NId,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)


def build_finally_clause_node(
    args: SyntaxGraphArgs,
    block_node: NId | None,
) -> NId:
    args.syntax_graph.add_node(
        args.n_id,
        label_type="FinallyClause",
    )

    control_flow_stack = args.metadata.get("control_flow_stack", [])
    control_flow_stack.append(args.n_id)

    if block_node:
        args.syntax_graph.update_node_attribute(args.n_id, "block_id", block_node)
        args.syntax_graph.add_edge(
            args.n_id,
            args.generic(args.fork_n_id(block_node)),
            label_ast="AST",
        )

    control_flow_stack.pop()

    return args.n_id
