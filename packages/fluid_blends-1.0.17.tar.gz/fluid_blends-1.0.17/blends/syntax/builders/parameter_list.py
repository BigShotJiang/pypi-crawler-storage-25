from collections.abc import (
    Iterable,
)

from blends.ctx import ctx
from blends.models import (
    NId,
)
from blends.syntax.builders.parameter import (
    build_parameter_node,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)


def build_parameter_list_node(args: SyntaxGraphArgs, c_ids: Iterable[NId]) -> NId:
    args.syntax_graph.add_node(
        args.n_id,
        label_type="ParameterList",
    )

    for c_id in c_ids:
        if (
            ctx.has_feature_flag("StackGraph")
            and args.ast_graph.nodes[c_id]["label_type"] == "identifier"
        ):
            child_id = build_parameter_node(
                args=args.fork_n_id(c_id),
                variable=args.ast_graph.nodes[c_id]["label_text"],
                variable_type=None,
                value_id=None,
            )
        else:
            child_id = args.generic(args.fork_n_id(c_id))
        args.syntax_graph.add_edge(args.n_id, child_id, label_ast="AST")

    return args.n_id
