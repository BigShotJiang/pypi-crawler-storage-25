from blends.models import (
    NId,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)


def build_else_clause_node(
    args: SyntaxGraphArgs,
    body_id: NId,
) -> NId:
    args.syntax_graph.add_node(
        args.n_id,
        block_id=body_id,
        label_type="ElseClause",
    )

    control_flow_stack = args.metadata.get("control_flow_stack", [])
    control_flow_stack.append(args.n_id)
    args.syntax_graph.add_edge(
        args.n_id,
        args.generic(args.fork_n_id(body_id)),
        label_ast="AST",
    )
    control_flow_stack.pop()

    return args.n_id
