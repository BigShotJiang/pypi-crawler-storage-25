import os
from itertools import product

from phylogenie.io import load_fasta
from phylogenie.msa import MSA

from bella_companion.backend.beast import submit_job
from bella_companion.eucovid.settings import (
    BEAST_CONFIGS_DIR,
    BELLA_CONFIGS,
    COUNTRIES,
    DATA_DIR,
    MSA_FILE,
    N_CASES,
    N_SEEDS,
)
from bella_companion.settings import settings


def _count_sequences_per_country(msa: MSA, country: str) -> int:
    return sum(1 for seq in msa if seq.id.split("|")[1] == country)


def run_eucovid():
    base_output_dir = settings.beast_output_dir / "eucovid"
    base_log_dir = settings.sbatch_log_dir / "eucovid"
    msa = load_fasta(MSA_FILE)

    for seed, (model, experiment, predictors) in product(
        range(1, N_SEEDS + 1),
        [
            ("BELLA", "flights_and_pop_size", ["flights", "pop_size"]),
            ("BELLA", "flights_per_capita", ["flights_per_capita"]),
            ("GLM", "flights_per_capita", ["flights_per_capita"]),
        ],
    ):
        output_dir = base_output_dir / experiment / model / str(seed)
        log_dir = base_log_dir / experiment / model / str(seed)
        data = {
            "msa_file": str(MSA_FILE),
            "predictorFiles": ",".join(
                [str(DATA_DIR / f"{predictor}.csv") for predictor in predictors]
            ),
            **BELLA_CONFIGS.get_beast_data(),
            "ReInitChinaAfterLockdown": "1.0",
            "ReInitFrance": "1.1",
            "ReInitGermany": "1.2",
            "ReInitItaly": "1.3",
            "ReInitOtherEU": "1.4",
            "ReInitChinaBeforeLockdown": "1.01",
            "mostRecentSamplingTime": "2020-03-08",
            "firstSampleDate": "2020-01-02",
        }
        for country, n_cases in zip(COUNTRIES, N_CASES):
            n_sequences = _count_sequences_per_country(msa, country)
            data[f"samplingProportion{country}LowerBound"] = n_sequences / n_cases / 10
            data[f"samplingProportion{country}UpperBound"] = n_sequences / n_cases
            data[f"samplingProportionInit{country}"] = n_sequences / n_cases / 5

        os.makedirs(output_dir, exist_ok=True)
        submit_job(
            data=data,
            prefix=f"{output_dir}{os.sep}",
            config_path=BEAST_CONFIGS_DIR / f"{model}.xml",
            log_dir=log_dir,
            time="240:00:00",
            cpus=128,
            mem_per_cpu=12000,
            seed=seed,
        )
