from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any

import httpx


@dataclass
class EvalResult:
    """Result of a flag evaluation."""

    key: str = ""
    value_type: str = ""
    value: Any = None
    reason: str = ""

    def bool(self) -> bool:
        """Return the value as a bool."""
        if self.value_type and self.value_type != "boolean":
            raise TypeError(f"flag '{self.key}' is type '{self.value_type}', not 'boolean'")
        if self.value is None:
            raise ValueError(f"flag '{self.key}' has no value (reason: {self.reason})")
        return bool(self.value)

    def string(self) -> str:
        """Return the value as a string."""
        if self.value_type and self.value_type != "string":
            raise TypeError(f"flag '{self.key}' is type '{self.value_type}', not 'string'")
        if self.value is None:
            raise ValueError(f"flag '{self.key}' has no value (reason: {self.reason})")
        return str(self.value)

    def integer(self) -> int:
        """Return the value as an int."""
        if self.value_type and self.value_type != "integer":
            raise TypeError(f"flag '{self.key}' is type '{self.value_type}', not 'integer'")
        if self.value is None:
            raise ValueError(f"flag '{self.key}' has no value (reason: {self.reason})")
        return int(self.value)

    def floating(self) -> float:
        """Return the value as a float."""
        if self.value_type and self.value_type != "float":
            raise TypeError(f"flag '{self.key}' is type '{self.value_type}', not 'float'")
        if self.value is None:
            raise ValueError(f"flag '{self.key}' has no value (reason: {self.reason})")
        return float(self.value)

    def json(self) -> Any:
        """Return the value as-is (already deserialized from JSON)."""
        if self.value_type and self.value_type != "json":
            raise TypeError(f"flag '{self.key}' is type '{self.value_type}', not 'json'")
        return self.value


@dataclass
class _CacheEntry:
    result: EvalResult
    at: float


@dataclass
class GateClient:
    """Gate feature flag SDK client with TTL-based caching.

    Usage::

        client = GateClient(
            service_url="https://gate-be-api-8c075fcded23.herokuapp.com",
            environment="production",
        )
        result = client.evaluate("dark_mode", {"plan": "pro"})
        if result.bool():
            ...
        client.close()

    Or as a context manager::

        with GateClient(service_url=..., environment="production") as client:
            result = client.evaluate("dark_mode")
    """

    service_url: str
    environment: str = ""
    ttl: int = 30
    timeout: float = 5.0
    _cache: dict[str, _CacheEntry] = field(default_factory=dict, repr=False)
    _client: httpx.Client | None = field(default=None, repr=False)

    def _http(self) -> httpx.Client:
        if self._client is None:
            self._client = httpx.Client(
                base_url=self.service_url.rstrip("/"),
                headers={"Content-Type": "application/json", "Accept": "application/json"},
                timeout=self.timeout,
            )
        return self._client

    def evaluate(self, key: str, variables: dict[str, Any] | None = None) -> EvalResult:
        """Evaluate a flag. Returns a cached result if within TTL."""
        now = time.monotonic()
        entry = self._cache.get(key)
        if entry is not None and (now - entry.at) < self.ttl:
            return entry.result

        result = self._fetch(key, variables)
        self._cache[key] = _CacheEntry(result=result, at=now)
        return result

    def _fetch(self, key: str, variables: dict[str, Any] | None = None) -> EvalResult:
        body: dict[str, Any] = {"key": key, "environment": self.environment}
        if variables:
            body["variables"] = variables

        resp = self._http().post("/evaluate", json=body)
        resp.raise_for_status()
        data = resp.json()

        return EvalResult(
            key=data.get("key", key),
            value_type=data.get("value_type") or "",
            value=data.get("value"),
            reason=data.get("reason", ""),
        )

    def close(self) -> None:
        """Close the underlying HTTP client."""
        if self._client is not None:
            self._client.close()
            self._client = None

    def __enter__(self) -> "GateClient":
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()
