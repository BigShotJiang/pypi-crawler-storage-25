"""Hub Gateway session worker (Phase 4.6).

The miner-agent's hub-aware loop. Polls the API every few seconds for
HubSessions waiting to be claimed (status='starting', machine.miner_id
== this agent's user_id), and for each one:

  1. Dial the broker with the session's tunnel_token, role="miner".
  2. Wait for the gateway peer's OPEN frame.
  3. Open a TCP connection to ``localhost:{endpoint.port}`` (Ollama on
     11434, ComfyUI on 8188, vLLM on 8000, etc).
  4. Bridge WS ↔ TCP bidirectionally — REUSES the existing
     ``port_forward.TunnelPortForwarder`` because the wire envelope
     (OPEN/OPEN_OK/DATA/HALF_CLOSE/CLOSE) is identical to the
     marketplace tunnel.
  5. On idle timeout / peer close / error → tear down + POST
     /v1/my-hub/sessions/{id}/close with a structured reason.

Key design decisions:

- **Polling, not broker push.** Agent already has a heartbeat WS to
  the broker for marketplace work, but adding hub-session push would
  require broker awareness of HubSession schemas. Polling is simpler
  and adds at most ~3s latency to the FIRST external request hitting
  hub.haon.run; subsequent requests on the same session piggyback the
  open tunnel.
- **Reuse over reinvention.** The hub data-plane is byte-identical to
  the marketplace data-plane on the wire. We dial a fresh BrokerClient
  per session (matching marketplace's _run_http_session pattern) and
  hand it to TunnelPortForwarder. Zero copy of frame-handling code.
- **No ACL on the agent side.** T10 + visibility ACL is enforced
  server-side at /sessions/open. By the time we're polling, the API
  has already vetted the caller. The agent just executes.
- **Bounded.** Per-session asyncio.Task tracked in a set; the worker
  cancels them all on shutdown. Polling skips sessions already being
  served (de-duped by session_id).

Errors: every catch is specific or `except Exception as e` with a
warning log + structured fields. The worker never raises out of
``run_forever`` — it logs and continues. A hung session can't take
down sibling sessions or the agent itself.
"""

from __future__ import annotations

import asyncio
import contextlib
import time
from dataclasses import dataclass, field
from typing import Any

import structlog

from haon_agent.api_client import ApiClient, ApiError
from haon_agent.broker_client import BrokerClient, FrameType
from haon_agent.port_forward import TunnelPortForwarder

log = structlog.get_logger("agent.hub")


# How often to poll /v1/my-hub/sessions/pending. 3 seconds = ~1.5s
# average latency for the first external request to hub.haon.run when
# no tunnel yet exists, balanced against API call volume.
_POLL_INTERVAL_SECONDS = 3.0

# Idle timeout: if no bytes flow on the tunnel for this many seconds,
# tear it down with reason='idle_timeout'. Hub workloads are HTTP/SSE,
# typically bursty — 60s is generous and lets large LLM streams finish
# without false-positive evictions.
_IDLE_TIMEOUT_SECONDS = 60.0

# Broker dial: exponential backoff on connection failure. After 5
# attempts (1s, 2s, 4s, 8s, 16s = ~30s total) we give up and call
# /close with reason='broker_unreachable'. The session stays 'starting'
# server-side and will be reaped by the API-side sweeper later.
_BROKER_DIAL_BACKOFF_SECONDS = (1.0, 2.0, 4.0, 8.0, 16.0)

# How long to wait for the gateway peer to send OPEN after we connect
# to the broker. The gateway should send OPEN immediately (it's already
# waiting on a paired session), so this is short.
_OPEN_WAIT_SECONDS = 10.0


@dataclass
class _ActiveSession:
    """In-memory tracking of one hub session being served by this
    agent. Stored in HubSessionWorker._active so the poll loop can
    skip already-claimed sessions and shutdown can cancel cleanly.
    """

    session_id: str
    task: asyncio.Task[None]
    started_at: float = field(default_factory=time.monotonic)


class HubSessionWorker:
    """Long-lived asyncio task: polls the API for pending hub sessions
    and serves each one with a dedicated broker dial + port-forwarder.

    Lifecycle:
      - ``await worker.run_forever()`` from the agent's run() loop.
      - ``worker.request_stop()`` from the agent's request_stop() —
        sets a stop flag; the loop exits next poll, in-flight sessions
        are cancelled and awaited briefly with CLOSE frames sent.

    Composes with the agent's marketplace heartbeat as a sibling task.
    Does NOT share state with marketplace work — the two flows are
    structurally separate (per the red-team audit's T1/T2 isolation
    requirement).
    """

    def __init__(self, *, api: ApiClient, machine_id: str | None = None) -> None:
        self._api = api
        # If pinned, only poll for sessions on this specific machine.
        # If None, the API filters by caller.id (all machines this
        # agent owns). Agents that pair multiple GPUs should leave None.
        self._machine_id = machine_id
        self._stop = asyncio.Event()
        self._active: dict[str, _ActiveSession] = {}
        # Per-session structlog context populated lazily; reset on close.
        self._session_logs: dict[str, structlog.stdlib.BoundLogger] = {}

    def request_stop(self) -> None:
        self._stop.set()

    async def run_forever(self) -> None:
        """Main poll loop. Yields to ``request_stop`` between polls."""
        log.info("hub.worker.starting", poll_interval=_POLL_INTERVAL_SECONDS)
        while not self._stop.is_set():
            try:
                await self._poll_once()
            except Exception as e:  # noqa: BLE001 — defensive
                log.warning("hub.poll.unexpected_error", error=str(e))
            try:
                await asyncio.wait_for(
                    self._stop.wait(), timeout=_POLL_INTERVAL_SECONDS
                )
            except asyncio.TimeoutError:
                pass
        log.info("hub.worker.stopping", active_count=len(self._active))
        await self._shutdown_active_sessions()
        log.info("hub.worker.stopped")

    async def _poll_once(self) -> None:
        """One iteration of the poll loop. Logs structured events,
        spawns one task per newly-discovered session."""
        # Reap finished tasks first so the active set reflects reality.
        for sid in list(self._active):
            if self._active[sid].task.done():
                self._active.pop(sid, None)
                self._session_logs.pop(sid, None)

        try:
            sessions = await self._api.list_pending_hub_sessions(
                machine_id=self._machine_id,
            )
        except ApiError as e:
            log.warning(
                "hub.poll.api_error",
                status=e.status_code,
                code=e.code,
            )
            return
        except Exception as e:  # noqa: BLE001
            log.warning("hub.poll.network_error", error=str(e))
            return

        if not sessions:
            log.debug("hub.poll.no_pending")
            return

        new_count = 0
        for s in sessions:
            sid = str(s.get("session_id") or "")
            if not sid or sid in self._active:
                continue
            new_count += 1
            log.info(
                "hub.session.received",
                session_id=sid,
                endpoint_id=str(s.get("endpoint_id") or ""),
                machine_id=str(s.get("machine_id") or ""),
                runtime=s.get("runtime"),
                port=s.get("port"),
            )
            task = asyncio.create_task(self._serve_session(s))
            self._active[sid] = _ActiveSession(session_id=sid, task=task)

        if new_count:
            log.info("hub.poll.found_pending", count=new_count)

    async def _serve_session(self, sess: dict[str, Any]) -> None:
        """Dial broker, accept OPEN, bridge to runtime, handle close.
        Catches every exception path and reports /close with structured
        reason. Never raises."""
        sid = str(sess["session_id"])
        endpoint_id = str(sess["endpoint_id"])
        machine_id = str(sess["machine_id"])
        runtime = str(sess.get("runtime") or "")
        port = int(sess["port"])
        tunnel_token = str(sess["tunnel_token"])
        broker_url = str(sess["broker_url"])

        slog = log.bind(
            session_id=sid,
            endpoint_id=endpoint_id,
            machine_id=machine_id,
            runtime=runtime,
            port=port,
        )
        self._session_logs[sid] = slog

        broker: BrokerClient | None = None
        forwarder: TunnelPortForwarder | None = None
        close_reason = "ok"

        try:
            # 1. CALL /start FIRST to get a fresh per-peer token.
            #    The token from /pending is the GATEWAY's token —
            #    consumed by the gateway's own broker dial (broker's
            #    `jti` replay-guard makes tokens single-use). The
            #    agent must use the SEPARATE miner-side token that
            #    /start mints. This mirrors the marketplace flow
            #    where each peer hits /start to claim their seat.
            try:
                start_resp = await self._api.start_hub_session(sid)
                # Use the miner-specific token returned by /start.
                miner_token = start_resp.get("tunnel_token") or tunnel_token
                slog.info("hub.session.start_confirmed")
            except ApiError as e:
                slog.warning(
                    "hub.session.start_confirm_failed",
                    status=e.status_code,
                    code=e.code,
                )
                miner_token = tunnel_token  # fallback to gateway token
            except Exception as e:  # noqa: BLE001
                slog.warning(
                    "hub.session.start_confirm_error", error=str(e)
                )
                miner_token = tunnel_token

            # 2. Dial broker with retry, using the miner token.
            broker = await self._dial_broker_with_retry(
                broker_url=broker_url,
                tunnel_token=miner_token,
                slog=slog,
            )
            if broker is None:
                close_reason = "broker_unreachable"
                return

            # 3. Bring up the port-forwarder. Same envelope as
            #    marketplace; the only thing the gateway speaks
            #    differently is that it dials with role="gateway"
            #    instead of role="worker", which the broker treats
            #    identically for our pair-up purposes.
            forwarder = TunnelPortForwarder(target_port=port)
            await forwarder.start(broker.send_data)

            # 4. Wait for PAIRED then pump events into the forwarder.
            #    PAIRED arrives once the gateway connects to the
            #    same session_id; if the broker times us out we give
            #    up cleanly.
            try:
                paired = await asyncio.wait_for(
                    broker.await_paired(timeout=_OPEN_WAIT_SECONDS),
                    timeout=_OPEN_WAIT_SECONDS,
                )
                slog.info(
                    "hub.session.tunnel.paired",
                    info=paired.json() if paired.payload else {},
                )
            except (asyncio.TimeoutError, RuntimeError) as e:
                slog.warning(
                    "hub.session.tunnel.pair_timeout",
                    error=str(e),
                )
                close_reason = "pair_timeout"
                return

            # 5. Bridge — pump every broker DATA into the forwarder
            #    until the broker disconnects or we hit idle timeout.
            close_reason = await self._pump_forever(
                broker=broker, forwarder=forwarder, slog=slog
            )

        except asyncio.CancelledError:
            slog.info("hub.session.tunnel.cancelled")
            close_reason = "agent_shutdown"
            raise
        except Exception as e:  # noqa: BLE001 — defensive
            slog.warning("hub.session.tunnel.error", error=str(e))
            close_reason = f"agent_error:{type(e).__name__}"
        finally:
            if forwarder is not None:
                with contextlib.suppress(Exception):
                    await forwarder.stop()
            if broker is not None:
                with contextlib.suppress(Exception):
                    await broker.close()
            with contextlib.suppress(Exception):
                await self._api.close_hub_session(sid, reason=close_reason)
                slog.info(
                    "hub.session.close_reported", reason=close_reason
                )
            slog.info("hub.session.tunnel.closed", reason=close_reason)

    async def _dial_broker_with_retry(
        self,
        *,
        broker_url: str,
        tunnel_token: str,
        slog: structlog.stdlib.BoundLogger,
    ) -> BrokerClient | None:
        """Try to connect with exponential backoff. Returns None
        on exhaustion (caller will close session with
        reason='broker_unreachable')."""
        for attempt, delay in enumerate(_BROKER_DIAL_BACKOFF_SECONDS, start=1):
            slog.info("hub.session.broker.dialing", attempt=attempt)
            broker = BrokerClient(broker_url, tunnel_token)
            try:
                await broker.connect()
                slog.info("hub.session.broker.connected", attempt=attempt)
                return broker
            except Exception as e:  # noqa: BLE001
                slog.warning(
                    "hub.session.broker.failed",
                    attempt=attempt,
                    error=str(e),
                    retrying_in=delay,
                )
                with contextlib.suppress(Exception):
                    await broker.close()
                if attempt >= len(_BROKER_DIAL_BACKOFF_SECONDS):
                    break
                try:
                    await asyncio.wait_for(self._stop.wait(), timeout=delay)
                    # Stop signaled mid-backoff — abort.
                    return None
                except asyncio.TimeoutError:
                    continue
        slog.error("hub.session.broker.exhausted")
        return None

    async def _pump_forever(
        self,
        *,
        broker: BrokerClient,
        forwarder: TunnelPortForwarder,
        slog: structlog.stdlib.BoundLogger,
    ) -> str:
        """Pump broker events into the forwarder until close. Returns
        the close-reason string (used for /close audit metadata).

        Idle-timeout: if no DATA seen for _IDLE_TIMEOUT_SECONDS,
        teardown with reason='idle_timeout'.
        """
        last_byte_time = time.monotonic()

        async def _idle_watchdog() -> str:
            while True:
                await asyncio.sleep(min(_IDLE_TIMEOUT_SECONDS, 5.0))
                if time.monotonic() - last_byte_time > _IDLE_TIMEOUT_SECONDS:
                    slog.info("hub.session.tunnel.idle_timeout")
                    return "idle_timeout"

        async def _events() -> str:
            nonlocal last_byte_time
            try:
                async for ev in broker.events():
                    if ev.type is FrameType.DATA:
                        last_byte_time = time.monotonic()
                        await forwarder.on_broker_data(ev.payload)
                    elif ev.type is FrameType.CLOSE:
                        slog.info("hub.session.tunnel.peer_closed")
                        return "peer_closed"
                    elif ev.type is FrameType.UNPAIRED:
                        slog.info("hub.session.tunnel.unpaired")
                        return "peer_unpaired"
                    # PAIRED / PING already handled (PAIRED via
                    # await_paired; PING is broker keep-alive only).
            except Exception as e:  # noqa: BLE001
                slog.warning("hub.session.tunnel.events_error", error=str(e))
                return f"events_error:{type(e).__name__}"
            slog.info("hub.session.tunnel.peer_eof")
            return "peer_eof"

        events_task = asyncio.create_task(_events())
        watchdog_task = asyncio.create_task(_idle_watchdog())
        done, pending = await asyncio.wait(
            {events_task, watchdog_task},
            return_when=asyncio.FIRST_COMPLETED,
        )
        # Cancel pending tasks; suppress CancelledError (BaseException,
        # not Exception — `contextlib.suppress(Exception)` would let
        # it propagate up and turn a clean events-task exit into a
        # spurious agent-shutdown reason).
        for t in pending:
            t.cancel()
            with contextlib.suppress(asyncio.CancelledError, Exception):
                await t
        # Whichever finished first carries the reason.
        winner = next(iter(done))
        try:
            return winner.result()
        except asyncio.CancelledError:
            return "cancelled"
        except Exception as e:  # noqa: BLE001
            return f"watchdog_error:{type(e).__name__}"

    async def _shutdown_active_sessions(self) -> None:
        """Cancel + await all active session tasks. Bounded wait so
        agent shutdown doesn't hang on a stuck CLOSE flush."""
        for active in list(self._active.values()):
            active.task.cancel()
        if self._active:
            try:
                await asyncio.wait_for(
                    asyncio.gather(
                        *(a.task for a in self._active.values()),
                        return_exceptions=True,
                    ),
                    timeout=5.0,
                )
            except asyncio.TimeoutError:
                log.warning(
                    "hub.worker.shutdown_timeout",
                    pending=len(self._active),
                )
        self._active.clear()
        self._session_logs.clear()
