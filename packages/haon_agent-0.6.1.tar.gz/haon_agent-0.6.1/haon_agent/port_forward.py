"""Miner-side TCP port-forward dispatcher.

Mirror of `apps/worker-client/haon_worker/local_proxy.py` on the agent.
Each incoming broker DATA frame carries a tunnel_frames envelope. We
parse the envelope and route to per-stream asyncio tasks that hold an
outbound TCP connection to 127.0.0.1:{target_port} (where the runtime
subprocess — Ollama / ComfyUI / vLLM / whatever — actually listens).

## Why this is a MODULE, not a Runtime

The existing `Runtime` Protocol (echo/ollama/comfyui) assumes raw-byte
pipe semantics (stdin/stdout shape). Port-forwarding speaks a DIFFERENT
language on the wire (tunnel_frames with multi-stream multiplex). If
we shoehorned it into the Runtime protocol every non-port-forward
runtime would need to understand framed bytes too.

Instead, the agent's `_run_session` decides BASED ON the runtime name
whether to hand the broker DATA frames to:

    (a) the legacy path: `await runtime.push(payload)` (echo etc)
        and `await broker.send_data(out)` for runtime output; or

    (b) the port-forward path: `await forwarder.on_broker_data(payload)`
        which parses the envelope and manages TCP pumps.

Runtimes that LISTEN ON A PORT (the HTTP-server class: ollama,
ollama_native, comfyui, vllm, tgi, custom_http) get path (b). The
agent uses a map keyed by runtime name to decide; see
`port_forward.RUNTIMES_WITH_PORT`.

## Security posture

The forwarder ONLY opens connections to `127.0.0.1`. Never an external
host, never another process's port outside the `ALLOWED_TARGET_PORTS`
allowlist. A worker sending OPEN(port=22) trying to reach our SSH is
refused with OPEN_RST. The allowlist is a per-runtime constant (the
port that runtime's server binds to).

Multiplex limit: 256 concurrent streams per session. Beyond that we
refuse with OPEN_RST — prevents a malicious worker from spawning
millions of sockets and OOM'ing the agent.
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from typing import Awaitable, Callable

import structlog

from haon_agent import tunnel_frames as tf


log = structlog.get_logger("agent.port_forward")


# Per-runtime default HTTP port. Matches the port each runtime's
# subprocess binds to. The agent passes one of these into the
# TunnelPortForwarder constructor based on the runtime the session is
# running. If the worker tries to open a different port, we refuse.
#
# ⚠️ MUST stay in sync with `_RUNTIME_DEFAULT_PORTS` in
# apps/worker-client/haon_worker/cli.py — both files declare the same
# table from different sides of the tunnel. Adding a new runtime
# here requires the matching entry there + an entry in the GUI's
# OLLAMA-or-other-LLM filter (apps/web-dashboard/public/haon_setup_gui.py).
RUNTIMES_WITH_PORT: dict[str, int] = {
    # ── LLM serving (text generation) — OpenAI-compat REST mostly ────
    "ollama": 11434,            # Ollama (Docker variant)
    "ollama_native": 11434,     # Ollama installed natively (MSI/.pkg/.deb)
    "lm_studio": 1234,          # LM Studio (lmstudio.ai) — boomer-friendly desktop, OpenAI API
    "llamacpp": 8080,           # llama.cpp `llama-server` — lightweight, popular
    "oobabooga": 5000,          # text-generation-webui (oobabooga) — community fav
    "koboldcpp": 5001,          # KoboldCpp — roleplay/storytelling
    "localai": 8080,            # LocalAI — drop-in OpenAI replacement (port 8080 same as llamacpp/custom_http; OK — only one runs at a time)
    "jan": 1337,                # Jan.ai desktop — alternative to LM Studio
    "gpt4all": 4891,            # GPT4All Desktop API
    "sglang": 30000,            # SGLang — modern fast inference server
    "aphrodite": 2242,          # Aphrodite Engine — vLLM fork for roleplay
    "hf_tgi": 80,               # HuggingFace Text Generation Inference
    "hf_vllm": 8000,            # vLLM (HuggingFace style)
    # ── Image generation ─────────────────────────────────────────────
    "comfyui": 8188,            # ComfyUI — node-based SD/Flux UI
    "a1111": 7860,              # AUTOMATIC1111 Stable Diffusion WebUI
    "forge": 7860,              # SD WebUI Forge — same default port as A1111
    "invokeai": 9090,           # InvokeAI — pro-grade SD UI
    "fooocus": 7865,            # Fooocus — simplified SDXL UI
    # ── Generic catch-all ────────────────────────────────────────────
    "custom_http": 8080,        # documented default; operator-overridable in future
}

# How many streams a single session can have OPEN at once. Typical HTTP
# workloads use 1-6 (browser HTTP/1.1 keep-alive). 256 is generous; any
# abuse pattern above that is either a bug or a DoS.
MAX_CONCURRENT_STREAMS = 256

# How long we wait for the outbound TCP connect() to the runtime to
# succeed before replying OPEN_RST. Runtimes like Ollama can take
# seconds on first start (model load). 5s is a balance.
_CONNECT_TIMEOUT_SECONDS = 5.0

# Red-team T1 fix — see apps/worker-client/.../local_proxy.py for
# rationale. 60 KB leaves headroom under aiortc's 64 KB SCTP
# max-message-size after tunnel_frames header overhead. Keeps both
# sides symmetric.
_READ_CHUNK_BYTES = 60 * 1024


def runtime_default_port(runtime_name: str) -> int | None:
    """Return the default HTTP port for a runtime, or None if this
    runtime doesn't have one (e.g. echo). Agent uses this to decide
    legacy-pipe vs port-forward mode."""
    return RUNTIMES_WITH_PORT.get(runtime_name)


@dataclass
class _Stream:
    stream_id: int
    reader: asyncio.StreamReader
    writer: asyncio.StreamWriter
    pump_to_broker: asyncio.Task[None] | None = None
    closed: bool = False


class TunnelPortForwarder:
    """Parses tunnel_frames from broker DATA, maintains per-stream TCP
    connections to 127.0.0.1:{runtime_port}, relays bytes both ways.

    Lifecycle:
      - `start(send_data)` must be called once before any `on_broker_data`.
        `send_data` is the agent's handle to push bytes back to the
        worker via the broker (typically `broker.send_data`).
      - `on_broker_data(payload)` feeds incoming broker DATA payloads
        (which are tunnel_frames envelopes). Non-blocking beyond the
        per-stream queue put.
      - `stop()` tears down all streams and the send handle.
    """

    def __init__(self, *, target_port: int, allowed_ports: set[int] | None = None):
        self._port = int(target_port)
        # `allowed_ports` narrows the set of ports the worker is
        # permitted to OPEN. Defaults to just the runtime's own port.
        self._allowed = allowed_ports if allowed_ports is not None else {self._port}
        self._send_data: Callable[[bytes], Awaitable[None]] | None = None
        self._streams: dict[int, _Stream] = {}
        self._stopped = False

    async def start(self, send_data: Callable[[bytes], Awaitable[None]]) -> None:
        self._send_data = send_data
        log.info(
            "port_forward_started",
            runtime_port=self._port,
            allowed_ports=sorted(self._allowed),
        )

    async def on_broker_data(self, payload: bytes) -> None:
        """Parse a tunnel_frames envelope and dispatch."""
        if self._stopped:
            return
        try:
            frame = tf.decode(payload)
        except ValueError as e:
            log.warning("port_forward_bad_frame", error=str(e))
            return

        op = frame.opcode
        if op is tf.Opcode.OPEN:
            try:
                target_port = tf.parse_open_payload(frame.payload)
            except ValueError as e:
                await self._send(tf.build_open_rst(frame.stream_id, f"bad OPEN: {e}"))
                return
            await self._handle_open(frame.stream_id, target_port)
            return
        if op is tf.Opcode.DATA:
            await self._handle_data(frame.stream_id, frame.payload)
            return
        if op is tf.Opcode.HALF_CLOSE:
            await self._handle_half_close(frame.stream_id)
            return
        if op in (tf.Opcode.CLOSE, tf.Opcode.ERROR):
            await self._close_stream(frame.stream_id)
            return
        # OPEN_OK / OPEN_RST: the agent doesn't send OPEN, so receiving
        # these means the other side is confused. Drop silently.

    async def stop(self) -> None:
        self._stopped = True
        for sid in list(self._streams):
            await self._close_stream(sid)
        self._streams.clear()

    # ── Frame handlers ──────────────────────────────────────────────────

    async def _handle_open(self, stream_id: int, target_port: int) -> None:
        if target_port not in self._allowed:
            await self._send(
                tf.build_open_rst(
                    stream_id,
                    f"port {target_port} not allowed for this session",
                )
            )
            log.warning(
                "port_forward_open_refused_port",
                stream_id=stream_id,
                port=target_port,
            )
            return

        if len(self._streams) >= MAX_CONCURRENT_STREAMS:
            await self._send(
                tf.build_open_rst(stream_id, "too many concurrent streams")
            )
            log.warning("port_forward_open_refused_too_many", stream_id=stream_id)
            return

        if stream_id in self._streams:
            await self._send(
                tf.build_open_rst(stream_id, "stream_id already in use")
            )
            return

        try:
            reader, writer = await asyncio.wait_for(
                asyncio.open_connection(host="127.0.0.1", port=target_port),
                timeout=_CONNECT_TIMEOUT_SECONDS,
            )
        except (ConnectionRefusedError, OSError) as e:
            # Most common cause: the runtime subprocess is still
            # starting up (Ollama loads models lazily). Worker will
            # retry.
            await self._send(
                tf.build_open_rst(stream_id, f"connect failed: {e!s}")
            )
            return
        except asyncio.TimeoutError:
            await self._send(
                tf.build_open_rst(stream_id, "connect timeout")
            )
            return
        except Exception as e:  # noqa: BLE001
            await self._send(
                tf.build_open_rst(stream_id, f"connect error: {e!r}")
            )
            return

        st = _Stream(stream_id=stream_id, reader=reader, writer=writer)
        self._streams[stream_id] = st
        await self._send(tf.build_open_ok(stream_id))

        # Start the runtime → broker pump. The broker → runtime side
        # is driven by on_broker_data events (inbound DATA frames).
        st.pump_to_broker = asyncio.create_task(self._pump_to_broker(st))

    async def _handle_data(self, stream_id: int, payload: bytes) -> None:
        st = self._streams.get(stream_id)
        if st is None or st.closed:
            return
        try:
            st.writer.write(payload)
            await st.writer.drain()
        except (ConnectionError, BrokenPipeError):
            await self._close_stream(stream_id)
        except Exception as e:  # noqa: BLE001
            log.warning(
                "port_forward_data_write_error", stream_id=stream_id, error=str(e)
            )
            await self._close_stream(stream_id)

    async def _handle_half_close(self, stream_id: int) -> None:
        st = self._streams.get(stream_id)
        if st is None or st.closed:
            return
        # Tell the runtime no more bytes are coming on this stream.
        # HTTP/1.1 upload completion relies on this signal.
        try:
            if st.writer.can_write_eof():
                st.writer.write_eof()
                await st.writer.drain()
        except Exception as e:  # noqa: BLE001
            log.debug(
                "port_forward_half_close_ignored", stream_id=stream_id, error=str(e)
            )

    async def _close_stream(self, stream_id: int) -> None:
        st = self._streams.pop(stream_id, None)
        if st is None or st.closed:
            return
        st.closed = True
        if st.pump_to_broker is not None and not st.pump_to_broker.done():
            st.pump_to_broker.cancel()
        try:
            st.writer.close()
            await asyncio.wait_for(st.writer.wait_closed(), timeout=1.0)
        except (asyncio.TimeoutError, Exception):  # noqa: BLE001
            pass

    # ── Pump tasks ──────────────────────────────────────────────────────

    async def _pump_to_broker(self, st: _Stream) -> None:
        """Read from runtime TCP → wrap in DATA envelope → broker."""
        try:
            while not st.closed:
                chunk = await st.reader.read(_READ_CHUNK_BYTES)
                if not chunk:
                    # Runtime closed the connection (HTTP response
                    # complete). Tell the worker.
                    try:
                        await self._send(tf.build_close(st.stream_id))
                    except Exception:  # noqa: BLE001
                        pass
                    return
                try:
                    await self._send(tf.build_data(st.stream_id, chunk))
                except Exception as e:  # noqa: BLE001
                    log.warning(
                        "port_forward_pump_send_error",
                        stream_id=st.stream_id,
                        error=str(e),
                    )
                    return
        except asyncio.CancelledError:
            raise
        except Exception as e:  # noqa: BLE001
            log.warning(
                "port_forward_pump_read_error",
                stream_id=st.stream_id,
                error=str(e),
            )
        finally:
            # Normalize teardown regardless of how the pump exited.
            await self._close_stream(st.stream_id)

    async def _send(self, payload: bytes) -> None:
        send = self._send_data
        if send is None:
            return
        try:
            await send(payload)
        except Exception as e:  # noqa: BLE001
            log.debug("port_forward_send_ignored", error=str(e))
