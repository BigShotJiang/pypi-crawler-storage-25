"""Sprint 1F.4 — agent-side runtime extensions for the BYOC Studio
flow (browser sharing + ADB Web).

Each runtime is an optional capability the agent can announce in the
hello frame's `runtime_kinds`. Adding a new kind here doesn't require
broker changes — the broker accepts any string matching its regex
(see services/tunnel-broker/app/byoc_metrics.py).

Submodules:
  - browser/ — Chrome launcher + CDP + screen capture + WebRTC peer
               (drives the "Compartilhar meu Chrome" flow on haonhub
               Studio)
  - adb/     — placeholder for ADB Web (Sprint 1F follow-up)

Runtime detection lives in haon_agent.byoc.capabilities; the modules
here expose primitives that the CLI commands + signaling glue wire
together.
"""
