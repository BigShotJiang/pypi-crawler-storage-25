"""BYOC `adb` runtime — thin ADB executor (Sprint 1G).

Activates the agent's `adb` slot as a THIN executor for web-driven ADB
control (BYOC model, mirroring the browser Studio): the agent executes
one primitive and returns the result/state. It NEVER decides anything —
all sequencing/heuristics live in the backend.
"""
