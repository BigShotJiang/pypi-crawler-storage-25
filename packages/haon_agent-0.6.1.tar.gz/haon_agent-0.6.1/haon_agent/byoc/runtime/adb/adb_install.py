"""Self-provisioning of the `adb` binary — Sprint 1G.1.

Makes the agent's adb slot plug-and-play: the user does NOT have to
install Android platform-tools or put adb on PATH. If no adb is found,
we download the official Google platform-tools for the current OS into
`~/.haon/platform-tools/` (once), and the resolver picks it up from
there.

Resolution order (see adb_exec.find_adb):
    explicit arg → HAON_ADB_PATH / HAON_ADB_BINARY env → config adb_path
    → ~/.haon/platform-tools (bundled/downloaded) → PATH → common dirs.

Integrity:
  - Download is over HTTPS from dl.google.com — TLS authenticates the
    origin (the same trust model that secures `pip install` itself and
    Android Studio's own SDK downloads).
  - SHA-256 is ALWAYS computed and logged. If an expected hash is pinned
    (HAON_ADB_PT_SHA256 env, or the _PT_SHA256 table), it is ENFORCED —
    a mismatch aborts. Operators/corporate can pin a hash they trust;
    out of the box we TLS-trust + log so a clean machine still works.
  - The extracted zip must contain a real adb executable, else abort.
"""

from __future__ import annotations

import asyncio
import hashlib
import os
import shutil
import stat
import sys
import tempfile
import zipfile
from pathlib import Path

import structlog


log = structlog.get_logger("agent.adb.install")

_PT_BASE = "https://dl.google.com/android/repository"
# Google maintains these stable "latest" URLs. Override per-OS via
# HAON_ADB_PT_URL for a corporate mirror.
_PT_FILES = {
    "windows": "platform-tools-latest-windows.zip",
    "darwin": "platform-tools-latest-darwin.zip",
    "linux": "platform-tools-latest-linux.zip",
}
# Optional pinned SHA-256 per OS — fill to ENFORCE at the code level.
# Empty = TLS-trust + log (operators can still pin via HAON_ADB_PT_SHA256).
_PT_SHA256: dict[str, str] = {
    "windows": "",
    "darwin": "",
    "linux": "",
}

_MAX_DOWNLOAD_BYTES = 200 * 1024 * 1024  # platform-tools is ~15-20MB; cap sane

# Process-wide guard so concurrent callers don't race a double download.
_provision_lock = asyncio.Lock()


def _haon_home() -> Path:
    return Path(os.environ.get("HAON_HOME") or (Path.home() / ".haon"))


def platform_tools_dir() -> Path:
    return _haon_home() / "platform-tools"


def _adb_filename() -> str:
    return "adb.exe" if sys.platform.startswith("win") else "adb"


def local_adb_path() -> str | None:
    """Path to an adb we've provisioned under ~/.haon, or None."""
    p = platform_tools_dir() / _adb_filename()
    return str(p) if p.exists() else None


def _os_key() -> str | None:
    if sys.platform.startswith("win"):
        return "windows"
    if sys.platform == "darwin":
        return "darwin"
    if sys.platform.startswith("linux"):
        return "linux"
    return None


def _download_url(os_key: str) -> str:
    override = os.environ.get("HAON_ADB_PT_URL")
    if override:
        return override
    return f"{_PT_BASE}/{_PT_FILES[os_key]}"


def _expected_sha256(os_key: str) -> str:
    return (os.environ.get("HAON_ADB_PT_SHA256") or _PT_SHA256.get(os_key, "")).strip().lower()


def autoprovision_enabled() -> bool:
    """Auto-download is on when the operator opted in via HAON_ADB_AUTO,
    or — by default — when the `[adb]` extra is installed (Pillow present
    is our proxy for "this host wants the adb runtime"). Set
    HAON_ADB_AUTO=0 to hard-disable."""
    env = os.environ.get("HAON_ADB_AUTO")
    if env is not None:
        return env.strip().lower() in ("1", "true", "yes", "on")
    try:
        import PIL  # noqa: F401 — the [adb] extra
        return True
    except ImportError:
        return False


async def ensure_platform_tools(*, timeout: float = 180.0,
                                force: bool = False) -> str:
    """Return a path to a usable adb, downloading platform-tools into
    ~/.haon if necessary. Raises on failure. Idempotent + concurrency-safe."""
    if not force:
        existing = local_adb_path()
        if existing:
            return existing
    async with _provision_lock:
        # Re-check inside the lock — another caller may have just done it.
        if not force:
            existing = local_adb_path()
            if existing:
                return existing
        os_key = _os_key()
        if os_key is None:
            raise RuntimeError(f"unsupported platform for adb auto-download: {sys.platform}")
        url = _download_url(os_key)
        log.info("adb_platform_tools_downloading", url=url, os=os_key)
        zip_bytes = await _download(url, timeout=timeout)
        sha = hashlib.sha256(zip_bytes).hexdigest()
        expected = _expected_sha256(os_key)
        if expected:
            if sha != expected:
                raise RuntimeError(
                    f"platform-tools SHA-256 mismatch: got {sha}, expected {expected}"
                )
            log.info("adb_platform_tools_sha256_verified", sha256=sha)
        else:
            # TLS-trusted (dl.google.com); log so it can be pinned later.
            log.info("adb_platform_tools_sha256_unpinned", sha256=sha,
                     hint="pin via HAON_ADB_PT_SHA256 to enforce")
        adb_path = await asyncio.to_thread(_extract_platform_tools, zip_bytes)
        log.info("adb_platform_tools_ready", adb_path=adb_path)
        return adb_path


async def _download(url: str, *, timeout: float) -> bytes:
    import httpx
    chunks: list[bytes] = []
    total = 0
    async with httpx.AsyncClient(timeout=timeout, follow_redirects=True) as client:
        async with client.stream("GET", url) as resp:
            resp.raise_for_status()
            async for chunk in resp.aiter_bytes():
                total += len(chunk)
                if total > _MAX_DOWNLOAD_BYTES:
                    raise RuntimeError("platform-tools download exceeded size cap")
                chunks.append(chunk)
    return b"".join(chunks)


def _extract_platform_tools(zip_bytes: bytes) -> str:
    """Extract the platform-tools/ dir from the zip into ~/.haon,
    atomically. The official zip has a top-level `platform-tools/`
    folder containing adb (+ its shared libs)."""
    home = _haon_home()
    home.mkdir(parents=True, exist_ok=True)
    dest = platform_tools_dir()
    tmp_root = Path(tempfile.mkdtemp(prefix="haon_pt_", dir=str(home)))
    try:
        import io
        with zipfile.ZipFile(io.BytesIO(zip_bytes)) as zf:
            # Zip-slip guard: refuse any member that escapes tmp_root.
            for name in zf.namelist():
                target = (tmp_root / name).resolve()
                if not str(target).startswith(str(tmp_root.resolve())):
                    raise RuntimeError(f"unsafe zip member: {name!r}")
            zf.extractall(tmp_root)
        extracted_pt = tmp_root / "platform-tools"
        if not extracted_pt.is_dir():
            raise RuntimeError("zip did not contain a platform-tools/ dir")
        adb_name = _adb_filename()
        if not (extracted_pt / adb_name).exists():
            raise RuntimeError(f"platform-tools missing {adb_name}")
        # Swap into place atomically-ish: remove old, move new.
        if dest.exists():
            shutil.rmtree(dest, ignore_errors=True)
        shutil.move(str(extracted_pt), str(dest))
    finally:
        shutil.rmtree(tmp_root, ignore_errors=True)
    adb_path = dest / _adb_filename()
    if not sys.platform.startswith("win"):
        # Ensure adb (+ helpers) are executable.
        for f in dest.iterdir():
            try:
                if f.is_file():
                    f.chmod(f.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
            except OSError:
                pass
    return str(adb_path)
