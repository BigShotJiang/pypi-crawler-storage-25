"""BYOC `adb` session orchestrator — Sprint 1G.

Mirrors BrowserSession's lifecycle contract (start/wait/close + session_id
+ _offer) so transport.py's session registry + drain logic work
unchanged. But instead of Chrome + WebRTC, it runs a simple request/
response RPC over the SAME broker signaling WSS the Studio uses:

    coworker ──{id, op, serial, args}──► broker ──► agent
    agent    ──{id, ok, result|error}──► broker ──► coworker

The agent NEVER decides anything — each frame is one primitive routed
to AdbExecutor; all sequencing/heuristics live in the backend.

(v1 = broker transport only. The ws://localhost path for a same-machine
browser is a separate follow-up component.)
"""

from __future__ import annotations

import asyncio
from typing import Any, Awaitable, Callable

import structlog

from haon_agent.byoc.runtime.adb.adb_exec import AdbError, AdbExecutor
from haon_agent.byoc.runtime.browser.signal_client import SignalClient


log = structlog.get_logger("agent.adb.session")

MainWSSFrameSender = Callable[[dict[str, Any]], Awaitable[None]]

# Ops the executor understands — used to recognise an RPC request frame
# (vs control frames like ping/bye).
_KNOWN_OPS = frozenset({
    "list_devices", "screencap", "ui_dump", "tap", "swipe", "text",
    "keyevent", "push", "pull", "shell",
})


class AdbSession:
    """One BYOC adb session. Same external shape as BrowserSession."""

    def __init__(
        self,
        offer: dict[str, Any],
        *,
        main_ws_send: MainWSSFrameSender,
        executor: AdbExecutor | None = None,
    ) -> None:
        self._offer = offer
        self._main_ws_send = main_ws_send
        self.session_id: str = offer.get("session_id") or "unknown"
        self._executor = executor or AdbExecutor()
        self._signal: SignalClient | None = None
        # Optional serial pin: if the offer scopes the grant to ONE device,
        # reject RPC for any other serial (multi-device slot isolation).
        self._allowed_serial: str | None = (
            offer.get("serial") or offer.get("resource_id") or None
        )
        # resource_id may legitimately be a non-serial label (e.g. "adb");
        # treat obviously-non-serial labels as "no pin".
        if self._allowed_serial in ("adb", "", None):
            self._allowed_serial = None
        self._done = asyncio.Event()
        self._closed = False
        self._close_lock = asyncio.Lock()

    # ── lifecycle ────────────────────────────────────────────────────
    async def start(self) -> None:
        signaling_url = self._offer["signaling_url"]
        session_token = self._offer["session_token"]
        self._signal = SignalClient(
            url=signaling_url,
            token=session_token,
            on_message=self._on_signal_message,
            on_close=self._on_signal_close,
        )
        await self._signal.connect()
        # Announce readiness so the coworker viewer can start sending RPC.
        await self._signal.send({"type": "ready", "role": "adb-agent"})
        log.info(
            "adb_session_ready",
            session_id=self.session_id,
            allowed_serial=self._allowed_serial,
            adb=bool(self._executor.adb_path),
        )

    async def wait(self) -> None:
        await self._done.wait()

    async def close(self) -> None:
        async with self._close_lock:
            if self._closed:
                return
            self._closed = True
        log.info("adb_session_closing", session_id=self.session_id)
        if self._signal is not None:
            try:
                await self._signal.close()
            except Exception:  # noqa: BLE001
                pass
        self._done.set()
        log.info("adb_session_closed", session_id=self.session_id)

    # ── signaling ────────────────────────────────────────────────────
    async def _on_signal_message(self, frame: dict[str, Any]) -> None:
        # Control frames first.
        ftype = frame.get("type") or frame.get("msg")
        if ftype == "ping":
            await self._safe_send({"type": "pong"})
            return
        if ftype == "bye":
            asyncio.create_task(self.close())
            return

        op = frame.get("op")
        if not isinstance(op, str):
            # Not an RPC request and not a control frame we handle.
            if ftype not in ("ready", "pong"):
                log.info("adb_session_unknown_frame", type=ftype)
            return

        req_id = frame.get("id")
        serial = frame.get("serial")
        args = frame.get("args") if isinstance(frame.get("args"), dict) else {}

        # Serial-pin enforcement (multi-device isolation).
        if (self._allowed_serial and serial
                and serial != self._allowed_serial):
            await self._respond(req_id, ok=False, code="serial_denied",
                                 message="serial not permitted for this grant")
            return

        try:
            result = await self._executor.execute(op, serial, args)
            await self._respond(req_id, ok=True, result=result)
        except AdbError as exc:
            log.info("adb_session_op_error", op=op, code=exc.code)
            await self._respond(req_id, ok=False, code=exc.code,
                                 message=exc.message)
        except Exception as exc:  # noqa: BLE001 — never kill the read loop
            log.exception("adb_session_op_crashed", op=op)
            await self._respond(req_id, ok=False, code="internal",
                                 message=str(exc)[:200])

    async def _respond(self, req_id: Any, *, ok: bool, result: Any = None,
                       code: str = "", message: str = "") -> None:
        frame: dict[str, Any] = {"id": req_id, "ok": ok}
        if ok:
            frame["result"] = result
        else:
            frame["error"] = {"code": code, "message": message}
        await self._safe_send(frame)

    async def _safe_send(self, frame: dict[str, Any]) -> None:
        if self._signal is None:
            return
        try:
            await self._signal.send(frame)
        except Exception:  # noqa: BLE001
            log.warning("adb_session_send_failed")

    async def _on_signal_close(self, reason: str) -> None:
        log.info("adb_session_signal_closed", reason=reason,
                 session_id=self.session_id)
        asyncio.create_task(self.close())
