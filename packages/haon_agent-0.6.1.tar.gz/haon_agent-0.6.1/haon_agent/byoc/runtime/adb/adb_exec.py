"""Thin ADB executor — Sprint 1G.

Ports ONLY the raw ADB primitives from ALGORTIMO_ADB/adb_device.py.
Deliberately drops ALL the automation/heuristic logic (identify_screen,
navigate_to, recover_to_screen, templates, legendas, timers) — the
agent executes one primitive and returns the result/state; the backend
owns every sequence and decision.

Primitives (request {id, op, serial, args} → response {id, ok, result|error}):
  list_devices · screencap · ui_dump · tap · swipe · text · keyevent ·
  push · pull · shell (read-only whitelist).

Security / robustness:
  - argv lists for subprocess (NO local shell) — no host-side injection.
  - device-shell args single-quote-escaped — no device-side injection.
  - shell{} is a READ-ONLY allowlist (getprop/dumpsys/pm list/settings
    get/wm size/echo/input) — never arbitrary commands.
  - push/pull paths validated against an allowlist of Android prefixes
    with no `..` traversal.
  - per-serial token-bucket rate limit on every primitive.
  - native adb (coexists with MTP, no re-enumeration).
"""

from __future__ import annotations

import asyncio
import base64
import os
import re
import shutil
import subprocess
import tempfile
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

import structlog


log = structlog.get_logger("agent.adb.exec")

# Windows: don't pop a console window for every adb invocation.
_NOWIN = getattr(subprocess, "CREATE_NO_WINDOW", 0)

# Android paths the backend may push to / pull from. Anything else (or
# any `..`) is rejected — anti-traversal.
_ALLOWED_DEVICE_PREFIXES = ("/sdcard/", "/storage/emulated/0/", "/data/local/tmp/")

# A device path token: absolute, no `..`, safe charset (no shell metas).
_DEVICE_PATH_RE = re.compile(r"^/[A-Za-z0-9_./@+-]+$")
# adb serials: usb serials, ip:port, emulator-NNNN.
_SERIAL_RE = re.compile(r"^[A-Za-z0-9_.:-]{1,128}$")
# Tokens that must never reach the device shell (injection / chaining).
_SHELL_META_RE = re.compile(r"[;&|<>(){}$`\n\r\"\\*?~!]")

# READ-ONLY shell allowlist. Value None = any args allowed; a set =
# the 2nd token (subcommand) must be in it; a callable = custom check
# returning (ok, reason).
_ShellRule = Any  # None | set[str] | Callable[[list[str]], tuple[bool, str]]


def _rule_wm(tokens: list[str]) -> tuple[bool, str]:
    # Only the READ forms: `wm size` / `wm density` with NO extra args
    # (an extra arg would SET the value).
    if len(tokens) == 2 and tokens[1] in ("size", "density"):
        return True, ""
    return False, "wm allows only read-only 'size'/'density' with no value"


def _rule_settings(tokens: list[str]) -> tuple[bool, str]:
    if len(tokens) >= 2 and tokens[1] in ("get", "list"):
        return True, ""
    return False, "settings allows only 'get'/'list'"


def _rule_pm(tokens: list[str]) -> tuple[bool, str]:
    if len(tokens) >= 2 and tokens[1] in ("list", "path", "dump"):
        return True, ""
    return False, "pm allows only read-only 'list'/'path'/'dump'"


_DEFAULT_SHELL_ALLOW: dict[str, _ShellRule] = {
    "getprop": None,
    "echo": None,
    "dumpsys": None,        # read-only inspection
    "wm": _rule_wm,
    "settings": _rule_settings,
    "pm": _rule_pm,
    # input is also exposed as dedicated primitives, but allow the safe
    # subcommands here too for convenience/parity.
    "input": {"tap", "swipe", "text", "keyevent", "roll",
              "draganddrop", "press"},
}


class AdbError(Exception):
    """Primitive failed. `code` is a short machine string for the wire."""

    def __init__(self, code: str, message: str = "") -> None:
        super().__init__(message or code)
        self.code = code
        self.message = message or code


@dataclass
class AdbResult:
    returncode: int
    stdout: bytes = b""
    stderr: bytes = b""

    @property
    def out_text(self) -> str:
        return self.stdout.decode("utf-8", "replace").strip()

    @property
    def err_text(self) -> str:
        return self.stderr.decode("utf-8", "replace").strip()


# Runner seam — tests inject a fake; production runs the real subprocess.
Runner = Callable[[list[str], int], AdbResult]


def _subprocess_runner(argv: list[str], timeout: int) -> AdbResult:
    try:
        p = subprocess.run(
            argv, capture_output=True, timeout=timeout, creationflags=_NOWIN,
        )
        return AdbResult(p.returncode, p.stdout or b"", p.stderr or b"")
    except subprocess.TimeoutExpired:
        return AdbResult(-1, b"", b"timeout")
    except FileNotFoundError:
        return AdbResult(-1, b"", b"adb binary not found")
    except Exception as exc:  # noqa: BLE001
        return AdbResult(-1, b"", str(exc).encode())


def _config_adb_path() -> str | None:
    """Optional `~/.haon/adb.json` → {"adb_path": "..."} for power-users
    / corporate who keep adb in a fixed non-PATH location."""
    import json
    home = os.environ.get("HAON_HOME") or str(Path.home() / ".haon")
    cfg = Path(home) / "adb.json"
    if not cfg.exists():
        return None
    try:
        data = json.loads(cfg.read_text(encoding="utf-8"))
        p = data.get("adb_path")
        return p if isinstance(p, str) and p else None
    except (OSError, ValueError, TypeError):
        return None


def find_adb(explicit: str | None = None) -> str | None:
    """Locate the adb binary. Resolution order (0.6.1 — self-sufficient):
      1. explicit arg
      2. env: HAON_ADB_PATH (preferred) / HAON_ADB_BINARY (legacy)
      3. config: ~/.haon/adb.json {"adb_path": ...}
      4. provisioned: ~/.haon/platform-tools/ (bundled or auto-downloaded)
      5. system PATH
      6. common platform-tools install locations
    Returns None if nothing resolves. NEVER triggers a download — that's
    ensure_platform_tools()'s job, kicked separately so detection stays
    light (it runs on every hello + caps-refresh tick)."""
    if explicit and Path(explicit).exists():
        return explicit
    for env in ("HAON_ADB_PATH", "HAON_ADB_BINARY"):
        v = os.environ.get(env)
        if v and Path(v).exists():
            return v
    cfg = _config_adb_path()
    if cfg and Path(cfg).exists():
        return cfg
    # Provisioned under ~/.haon (auto-download target).
    try:
        from haon_agent.byoc.runtime.adb.adb_install import local_adb_path
        provisioned = local_adb_path()
        if provisioned:
            return provisioned
    except Exception:  # noqa: BLE001 — install module optional
        pass
    found = shutil.which("adb")
    if found:
        return found
    home = Path.home()
    for cand in (
        home / "platform-tools" / "adb.exe",
        home / "adb_server" / "platform-tools" / "adb.exe",
        home / "platform-tools" / "adb",
        Path("/usr/local/bin/adb"),
        Path("/usr/bin/adb"),
    ):
        if cand.exists():
            return str(cand)
    return None


def _device_squote(s: str) -> str:
    """Single-quote a string for the DEVICE shell so metacharacters are
    inert (POSIX sh quoting: close, escaped-quote, reopen)."""
    return "'" + s.replace("'", "'\\''") + "'"


def _validate_serial(serial: str) -> None:
    if not isinstance(serial, str) or not _SERIAL_RE.match(serial):
        raise AdbError("bad_serial", f"invalid serial: {serial!r}")


def _validate_device_path(path: str) -> str:
    if not isinstance(path, str) or not _DEVICE_PATH_RE.match(path):
        raise AdbError("bad_path", f"invalid device path: {path!r}")
    if ".." in path.split("/"):
        raise AdbError("bad_path", "path traversal ('..') not allowed")
    if not path.startswith(_ALLOWED_DEVICE_PREFIXES):
        raise AdbError(
            "bad_path",
            f"path must be under one of {_ALLOWED_DEVICE_PREFIXES}",
        )
    return path


@dataclass
class AdbExecutor:
    """One executor per agent process — handles all serials. Stateless
    except for the per-serial rate-limit buckets."""

    adb_path: str | None = None
    runner: Runner = _subprocess_runner
    default_timeout: int = 15
    # Rate limit: token bucket per serial. Backend paces anyway; this is
    # a backstop so a runaway controller can't hammer the device/USB.
    max_ops_per_s: float = 20.0
    burst: float = 40.0
    screencap_max_dim: int = 1280   # downscale longest side (jpeg)
    screencap_quality: int = 60
    shell_allow: dict[str, _ShellRule] = field(
        default_factory=lambda: dict(_DEFAULT_SHELL_ALLOW)
    )

    _buckets: dict[str, tuple[float, float]] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.adb_path is None:
            self.adb_path = find_adb()

    # ── rate limit ───────────────────────────────────────────────────
    def _rate_check(self, serial: str) -> None:
        now = time.monotonic()
        tokens, last = self._buckets.get(serial, (self.burst, now))
        tokens = min(self.burst, tokens + (now - last) * self.max_ops_per_s)
        if tokens < 1.0:
            self._buckets[serial] = (tokens, now)
            raise AdbError("rate_limited", f"rate limit for {serial}")
        self._buckets[serial] = (tokens - 1.0, now)

    # ── low-level invoke (blocking; called via to_thread) ────────────
    def _invoke(self, args: list[str], *, serial: str | None,
                timeout: int | None = None) -> AdbResult:
        if not self.adb_path:
            raise AdbError("no_adb", "adb binary not found on this host")
        argv = [self.adb_path]
        if serial:
            argv += ["-s", serial]
        argv += args
        return self.runner(argv, timeout or self.default_timeout)

    # ── public async dispatch ────────────────────────────────────────
    async def execute(self, op: str, serial: str | None,
                      args: dict[str, Any]) -> Any:
        """Run one primitive, returning its result payload (JSON-able).
        Raises AdbError on any failure. The session wraps this into the
        {id, ok, result|error} envelope."""
        args = args or {}
        if op == "list_devices":
            return await asyncio.to_thread(self._list_devices)

        # All other ops require a valid serial + rate budget.
        if not serial:
            raise AdbError("bad_serial", f"op {op!r} requires a serial")
        _validate_serial(serial)
        self._rate_check(serial)

        handler = {
            "screencap": self._screencap,
            "ui_dump": self._ui_dump,
            "tap": self._tap,
            "swipe": self._swipe,
            "text": self._text,
            "keyevent": self._keyevent,
            "push": self._push,
            "pull": self._pull,
            "shell": self._shell,
        }.get(op)
        if handler is None:
            raise AdbError("unknown_op", f"unknown op: {op!r}")
        return await asyncio.to_thread(handler, serial, args)

    # ── primitives ───────────────────────────────────────────────────
    def _list_devices(self) -> dict[str, Any]:
        r = self._invoke(["devices"], serial=None, timeout=10)
        devices = []
        for line in r.out_text.splitlines():
            line = line.strip()
            if not line or line.startswith("List of devices"):
                continue
            parts = line.split("\t")
            if len(parts) == 2:
                devices.append({"serial": parts[0].strip(),
                                "state": parts[1].strip()})
        return {"devices": devices}

    def _screencap(self, serial: str, args: dict[str, Any]) -> dict[str, Any]:
        # exec-out streams the PNG to stdout — no temp file on the device.
        r = self._invoke(["exec-out", "screencap", "-p"], serial=serial,
                         timeout=20)
        if r.returncode != 0 or not r.stdout:
            raise AdbError("screencap_failed", r.err_text or "no image bytes")
        png = r.stdout
        quality = int(args.get("quality", self.screencap_quality))
        quality = max(1, min(100, quality))
        max_dim = int(args.get("max_dim", self.screencap_max_dim))
        img_bytes, fmt, w, h = _encode_screenshot(png, max_dim, quality)
        return {
            "format": fmt,
            "width": w,
            "height": h,
            "b64": base64.b64encode(img_bytes).decode("ascii"),
        }

    def _ui_dump(self, serial: str, args: dict[str, Any]) -> dict[str, Any]:
        # exec-out uiautomator dump --compressed /dev/tty streams the XML
        # to stdout (no /sdcard temp + pull round-trip).
        r = self._invoke(
            ["exec-out", "uiautomator", "dump", "/dev/tty"],
            serial=serial, timeout=20,
        )
        text = r.out_text
        # uiautomator prints a trailing "UI hierchary dumped to: ..." line
        # on some builds; strip anything after the closing </hierarchy>.
        end = text.rfind("</hierarchy>")
        if end != -1:
            text = text[: end + len("</hierarchy>")]
        if "<hierarchy" not in text:
            raise AdbError("ui_dump_failed", r.err_text or text[:120] or "no xml")
        return {"xml": text}

    def _tap(self, serial: str, args: dict[str, Any]) -> dict[str, Any]:
        x = _req_int(args, "x")
        y = _req_int(args, "y")
        self._invoke(["shell", "input", "tap", str(x), str(y)], serial=serial)
        return {"tapped": [x, y]}

    def _swipe(self, serial: str, args: dict[str, Any]) -> dict[str, Any]:
        x1 = _req_int(args, "x1")
        y1 = _req_int(args, "y1")
        x2 = _req_int(args, "x2")
        y2 = _req_int(args, "y2")
        dur = int(args.get("dur", args.get("duration", 300)))
        dur = max(1, min(60000, dur))
        self._invoke(
            ["shell", "input", "swipe", str(x1), str(y1), str(x2), str(y2),
             str(dur)],
            serial=serial,
        )
        return {"swiped": [x1, y1, x2, y2], "dur": dur}

    def _text(self, serial: str, args: dict[str, Any]) -> dict[str, Any]:
        s = args.get("s", args.get("text", ""))
        if not isinstance(s, str):
            raise AdbError("bad_args", "text 's' must be a string")
        if len(s) > 4096:
            raise AdbError("bad_args", "text too long (>4096)")
        # Android `input text` uses %s for space; single-quote the whole
        # device command so ;|&$` etc. can't break out of the arg.
        encoded = s.replace(" ", "%s")
        dev_cmd = "input text " + _device_squote(encoded)
        self._invoke(["shell", dev_cmd], serial=serial)
        return {"typed_len": len(s)}

    def _keyevent(self, serial: str, args: dict[str, Any]) -> dict[str, Any]:
        code = args.get("code")
        # Accept numeric keycode or a KEYCODE_* name (alnum + underscore).
        if isinstance(code, bool):
            raise AdbError("bad_args", "keyevent code invalid")
        if isinstance(code, int):
            code_s = str(code)
        elif isinstance(code, str) and re.fullmatch(r"[A-Z0-9_]{1,40}", code):
            code_s = code
        else:
            raise AdbError("bad_args", f"keyevent code invalid: {code!r}")
        self._invoke(["shell", "input", "keyevent", code_s], serial=serial)
        return {"keyevent": code_s}

    def _push(self, serial: str, args: dict[str, Any]) -> dict[str, Any]:
        dest = _validate_device_path(args.get("dest", ""))
        b64 = args.get("bytes", "")
        if not isinstance(b64, str):
            raise AdbError("bad_args", "push 'bytes' must be base64 string")
        try:
            data = base64.b64decode(b64, validate=True)
        except Exception:  # noqa: BLE001
            raise AdbError("bad_args", "push 'bytes' is not valid base64")
        if len(data) > 64 * 1024 * 1024:
            raise AdbError("too_large", "push payload >64MB")
        tmp = Path(tempfile.gettempdir()) / f"haon_adb_push_{os.getpid()}_{int(time.time()*1000)}"
        try:
            tmp.write_bytes(data)
            r = self._invoke(["push", str(tmp), dest], serial=serial, timeout=60)
            if r.returncode != 0:
                raise AdbError("push_failed", r.err_text or r.out_text)
        finally:
            tmp.unlink(missing_ok=True)
        return {"pushed": dest, "bytes": len(data)}

    def _pull(self, serial: str, args: dict[str, Any]) -> dict[str, Any]:
        src = _validate_device_path(args.get("src", ""))
        # exec-out cat streams the bytes to stdout (binary-safe, no temp).
        r = self._invoke(["exec-out", "cat", _device_squote(src)],
                         serial=serial, timeout=60)
        if r.returncode != 0:
            raise AdbError("pull_failed", r.err_text or "cat failed")
        data = r.stdout
        if len(data) > 64 * 1024 * 1024:
            raise AdbError("too_large", "pull payload >64MB")
        return {"src": src, "bytes": len(data),
                "b64": base64.b64encode(data).decode("ascii")}

    def _shell(self, serial: str, args: dict[str, Any]) -> dict[str, Any]:
        tokens = _shell_tokens(args.get("cmd"))
        self._validate_shell(tokens)
        # Rebuild the device command with each token single-quoted so the
        # device shell can't be tricked even though we validated.
        dev_cmd = " ".join(_device_squote(t) for t in tokens)
        r = self._invoke(["shell", dev_cmd], serial=serial,
                         timeout=int(args.get("timeout", self.default_timeout)))
        return {
            "returncode": r.returncode,
            "stdout": r.out_text[:200000],
            "stderr": r.err_text[:8000],
        }

    def _validate_shell(self, tokens: list[str]) -> None:
        if not tokens:
            raise AdbError("bad_args", "shell cmd is empty")
        for t in tokens:
            if _SHELL_META_RE.search(t):
                raise AdbError("shell_blocked",
                               f"token contains shell metacharacters: {t!r}")
        verb = tokens[0]
        if verb not in self.shell_allow:
            raise AdbError("shell_blocked",
                           f"command not in read-only allowlist: {verb!r}")
        rule = self.shell_allow[verb]
        if rule is None:
            return
        if isinstance(rule, set):
            if len(tokens) < 2 or tokens[1] not in rule:
                raise AdbError("shell_blocked",
                               f"{verb} subcommand not allowed")
            return
        if callable(rule):
            ok, reason = rule(tokens)
            if not ok:
                raise AdbError("shell_blocked", reason)


# ── helpers ──────────────────────────────────────────────────────────


def _req_int(args: dict[str, Any], key: str) -> int:
    v = args.get(key)
    if isinstance(v, bool) or not isinstance(v, (int, float)):
        raise AdbError("bad_args", f"missing/invalid int arg {key!r}")
    return int(v)


def _shell_tokens(cmd: Any) -> list[str]:
    """Normalise the shell cmd to a token list. Accepts a list of tokens
    (preferred) or a plain string (split on whitespace — rejected later
    if it contained metacharacters)."""
    if isinstance(cmd, list):
        if not all(isinstance(t, str) for t in cmd):
            raise AdbError("bad_args", "shell cmd list must be all strings")
        return [t for t in cmd if t != ""]
    if isinstance(cmd, str):
        return cmd.split()
    raise AdbError("bad_args", "shell cmd must be a string or list of strings")


def _encode_screenshot(png: bytes, max_dim: int,
                       quality: int) -> tuple[bytes, str, int, int]:
    """Downscale + JPEG-encode the PNG screencap. Falls back to the raw
    PNG (format='png') if Pillow isn't installed — install
    `haon-agent[adb]` for the smaller JPEG path."""
    import io
    try:
        from PIL import Image  # lazy — only adb screencap needs it
    except ImportError:
        # No Pillow — return PNG as-is. Dimensions unknown without a
        # decoder, so report 0 (backend can read the image header).
        log.info("adb_screencap_no_pillow_raw_png")
        return png, "png", 0, 0
    with Image.open(io.BytesIO(png)) as im:
        im = im.convert("RGB")
        w, h = im.size
        longest = max(w, h)
        if max_dim and longest > max_dim:
            scale = max_dim / longest
            w, h = int(w * scale), int(h * scale)
            im = im.resize((w, h), Image.LANCZOS)
        buf = io.BytesIO()
        im.save(buf, format="JPEG", quality=quality)
        return buf.getvalue(), "jpeg", w, h
