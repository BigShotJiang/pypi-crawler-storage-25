"""Sprint 1F.4 phase 2 — Layer 3 (partial) session monitor.

Reactive defense layer. While URL block (Layer 1) and `--app` mode
(Layer 0) PREVENT bad actions, this module DETECTS them when they
slip through and triggers disconnect + audit.

What this module tracks per Studio session:

  - idle_timer: reset on each input event from coworker. When it
    exceeds `idle_timeout_min`, the disconnect callback fires.
  - blocked_url_counter: incremented when CDP emits a navigation event
    to a blocklisted URL OR an off-allowlist host. When it exceeds
    `max_warnings_before_disconnect`, the disconnect callback fires.
  - rapid_click_counter: more than 5 blocked clicks in 10s → instant
    disconnect (Caio's spec).

Disconnect mechanics: this module owns the COUNTER + EMIT logic; the
actual WSS close + Chrome cleanup happen in the caller (phase 4
signaling glue holds the WebRTC peer + signaling WSS; it consumes the
on_disconnect callback we emit).

Audit emission: every counter increment + every disconnect emits via
the audit_emit callback (wired to runtime/browser/audit.py in phase 2
agent code; broker forwards to haonhub).
"""

from __future__ import annotations

import asyncio
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Deque


class DisconnectReason:
    IDLE_TIMEOUT = "idle_timeout"
    BLOCKED_URL_LIMIT = "blocked_url_limit"
    RAPID_BLOCKED_CLICKS = "rapid_blocked_clicks"
    EXTERNAL = "external"   # caller-initiated, e.g. owner force-end


# Callbacks the monitor invokes — type aliases for readability.
AuditEmitter = Callable[[str, dict[str, Any]], Awaitable[None]]
"""(event_type, event_data) → awaitable"""

DisconnectHandler = Callable[[str, dict[str, Any]], Awaitable[None]]
"""(reason, context) → awaitable. Caller closes WSS + Chrome."""


@dataclass
class SessionMonitor:
    """Per-session state + counters. One instance per active Studio
    session (multi-slot expansion will instantiate N of these).

    Lifecycle:
      - Caller creates with grant permissions + callbacks
      - Caller invokes record_input() / record_blocked_url() per event
      - Idle watchdog runs as a background task; caller starts it via
        await monitor.start()
      - Caller invokes shutdown() on session teardown (cancels watchdog)
    """

    session_id: str
    idle_timeout_seconds: int
    max_blocked_warnings: int
    audit_emit: AuditEmitter
    on_disconnect: DisconnectHandler

    # Rapid-blocked-click window (Caio's spec: >5 blocked in 10s)
    rapid_click_window_seconds: float = 10.0
    rapid_click_threshold: int = 5

    # Runtime state — NOT init params
    _last_input_at: float = field(default_factory=time.monotonic)
    _blocked_url_counter: int = 0
    _blocked_click_times: Deque[float] = field(default_factory=deque)
    _idle_watchdog_task: asyncio.Task | None = None
    _disconnected: bool = False

    async def start(self) -> None:
        """Start the idle watchdog. Idempotent — safe to call twice."""
        if self._idle_watchdog_task is not None and not self._idle_watchdog_task.done():
            return
        self._idle_watchdog_task = asyncio.create_task(
            self._idle_watchdog_loop(),
            name=f"studio-idle-{self.session_id}",
        )

    async def shutdown(self) -> None:
        """Cancel the watchdog. Call on session teardown."""
        if self._idle_watchdog_task is not None:
            self._idle_watchdog_task.cancel()
            try:
                await self._idle_watchdog_task
            except (asyncio.CancelledError, Exception):  # noqa: BLE001
                pass

    def record_input(self) -> None:
        """Caller invokes this on every coworker input event applied
        to Chrome. Resets the idle timer.

        Cheap (single attribute write) — fine to call from the
        hot input-replay path.
        """
        self._last_input_at = time.monotonic()

    async def record_blocked_url(self, url: str, *, attempt_kind: str = "navigation") -> None:
        """Caller invokes this when CDP reports a navigation/request
        to a blocklisted URL (or off-allowlist host).

        Side effects:
          1. Increment blocked_url_counter
          2. Emit audit event "blocked_action"
          3. If counter > max_blocked_warnings → trigger disconnect
        """
        if self._disconnected:
            return
        self._blocked_url_counter += 1
        # Also feed the rapid-click sliding window
        now = time.monotonic()
        self._blocked_click_times.append(now)
        # Trim old entries outside the rapid_click_window
        cutoff = now - self.rapid_click_window_seconds
        while self._blocked_click_times and self._blocked_click_times[0] < cutoff:
            self._blocked_click_times.popleft()

        try:
            await self.audit_emit(
                "blocked_action",
                {
                    "url": url,
                    "attempt_n": self._blocked_url_counter,
                    "attempt_kind": attempt_kind,
                },
            )
        except Exception:  # noqa: BLE001
            # Audit failures shouldn't block the security counter
            pass

        # Rapid-click → INSTANT disconnect (overrides max_warnings)
        if len(self._blocked_click_times) > self.rapid_click_threshold:
            await self._trigger_disconnect(
                DisconnectReason.RAPID_BLOCKED_CLICKS,
                {
                    "attempts_in_window": len(self._blocked_click_times),
                    "window_seconds": self.rapid_click_window_seconds,
                },
            )
            return

        # Counter overflow → graceful disconnect
        if self._blocked_url_counter > self.max_blocked_warnings:
            await self._trigger_disconnect(
                DisconnectReason.BLOCKED_URL_LIMIT,
                {
                    "attempt_n": self._blocked_url_counter,
                    "limit": self.max_blocked_warnings,
                },
            )

    async def force_disconnect(self, *, context: dict[str, Any] | None = None) -> None:
        """Caller-initiated disconnect (e.g. owner clicked "Force end"
        on haonhub UI, or session_token expired)."""
        await self._trigger_disconnect(
            DisconnectReason.EXTERNAL,
            context or {},
        )

    async def _trigger_disconnect(self, reason: str, context: dict[str, Any]) -> None:
        if self._disconnected:
            return
        self._disconnected = True
        # Emit final audit event BEFORE invoking on_disconnect so the
        # audit lands even if the WSS close cascade is slow.
        try:
            await self.audit_emit(
                "session_terminated_security" if reason != DisconnectReason.EXTERNAL else "session_terminated",
                {"reason": reason, **context},
            )
        except Exception:  # noqa: BLE001
            pass
        try:
            await self.on_disconnect(reason, context)
        except Exception:  # noqa: BLE001
            # Disconnect handler raising shouldn't bring down the monitor
            pass

    async def _idle_watchdog_loop(self) -> None:
        """Background task — wakes up periodically and checks last input.
        Sleep granularity is fine (5s); we don't need sub-second
        precision on the idle detection.
        """
        check_interval = max(5.0, self.idle_timeout_seconds / 6)
        try:
            while not self._disconnected:
                await asyncio.sleep(check_interval)
                if self._disconnected:
                    return
                elapsed = time.monotonic() - self._last_input_at
                if elapsed >= self.idle_timeout_seconds:
                    await self._trigger_disconnect(
                        DisconnectReason.IDLE_TIMEOUT,
                        {"idle_seconds": int(elapsed)},
                    )
                    return
        except asyncio.CancelledError:
            raise
        except Exception:  # noqa: BLE001 — watchdog must never bring down agent
            # Log via the audit channel — if even that fails, give up
            try:
                await self.audit_emit(
                    "monitor_watchdog_failure",
                    {"session_id": self.session_id},
                )
            except Exception:  # noqa: BLE001
                pass
