"""Sprint 1F.4 phase 2 — agent-side audit event emitter.

The agent emits audit events via its EXISTING /v1/byoc/connect WSS
(same channel as workflow dispatch / heartbeat). Broker receives
`{msg: "audit_event", ...}` frames in its read loop, forwards to
haonhub via HTTP POST.

Topology (Caio confirmed 2026-05-19):

  agent                  broker                       haonhub
   │                       │                            │
   │ {msg:audit_event,     │                            │
   │  session_id, type,    │                            │
   │  data, ts}            │                            │
   ├──────WSS────────────▶ │                            │
   │                       │ POST /api/studio/sessions/ │
   │                       │ <sid>/audit/broker         │
   │                       │ Bearer ${API_KEY}          │
   │                       ├─────HTTPS────────────────▶ │
   │                       │ {event_type, event_data,   │
   │                       │  source: "agent_via_broker"}
   │                       │                            │

Why not direct agent → haonhub HTTP:
  - Agent keyring stays minimal (only permanent_token)
  - Single shared secret (HAONRUN_API_KEY) already lives in broker env
  - Trust boundary: broker is the only haonhub-trusted upstream;
    compromised agent can't forge audit events directly (still has to
    convince the broker, which validates its WSS session)
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any, Awaitable, Callable


# Caller (CLI / runtime glue) provides this — a function that sends a
# JSON frame on the active /v1/byoc/connect WSS. Returns awaitable.
# Decoupling means audit.py doesn't need to know about transport.py
# internals.
FrameSender = Callable[[dict[str, Any]], Awaitable[None]]


@dataclass
class AuditEmitter:
    """Per-session emitter — caller passes the FrameSender + session_id
    so each session's audit events carry the right key.

    Best-effort: if the WSS is down, emit silently swallows + logs.
    Audit loss is acceptable; agent liveness isn't.
    """

    session_id: str
    send_frame: FrameSender

    async def emit(self, event_type: str, event_data: dict[str, Any]) -> None:
        """Send an audit event to the broker for relay to haonhub.

        `event_type` is one of (consistent with monitor.py + Caio's spec):
          - "blocked_action"           Layer 1 caught a URL hit
          - "warning"                  reserved for Layer 2 inject events
          - "session_terminated_security"  monitor disconnected for
                                           security threshold
          - "session_terminated"       graceful (idle / external / TTL)
          - "monitor_watchdog_failure" defensive: monitor task died

        `event_data` is a free-shape dict — haonhub stores verbatim in
        the studio_audit_log JSONB column. Common fields: url,
        attempt_n, reason, attempt_kind.

        Returns immediately on transport error — broker may be
        reconnecting, etc. The session monitor's counter side already
        accounts for the event.
        """
        frame = {
            "msg": "audit_event",
            "v": 1,
            "session_id": self.session_id,
            "event_type": event_type,
            "event_data": event_data,
            "ts": int(time.time()),
        }
        try:
            await self.send_frame(frame)
        except Exception:  # noqa: BLE001 — best-effort
            # Caller logged the transport error already; we just want
            # to never let an audit emit raise into the monitor.
            pass
