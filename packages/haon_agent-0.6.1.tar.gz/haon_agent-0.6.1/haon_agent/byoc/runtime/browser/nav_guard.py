"""Sprint 1F.8 — Layer 1.5 navigation enforcement (ST-01 teeth).

The url_guard (Layer 1, `Network.setBlockedURLs`) only enforces a
DENY list — it has no positive allowlist primitive, and the previous
design punted allowlist/initial-domain enforcement to "monitor.py"
which was never actually wired. This module closes that gap.

Mechanism: CDP `Fetch.requestPaused`. We `Fetch.enable` filtered to
**Document** requests at the Request stage — iframe document loads are
reported as "Document" too, so this catches top-level AND iframe
navigations while ordinary sub-resources (scripts, images, XHR) are
NOT paused and pay zero overhead (the network blocklist still covers
them). For every paused navigation we inspect the *full* URL and
decide:

  - scheme NOT in the allowed set (http/https/about/blob/data) → BLOCK.
    Kills file://, ftp://, view-source:, devtools:, chrome://,
    chrome-extension://, filesystem: — the local-file / internals
    exfil vectors.
  - matches a hard-block / per-grant blocklist pattern → BLOCK.
  - host not allowed (when can_navigate_outside_initial_domain is
    False, only the initial domain + url_allowlist hosts pass) → BLOCK.
  - otherwise → CONTINUE.

A blocked navigation calls `Fetch.failRequest(errorReason="Aborted")`
and fires the `on_blocked(url, kind)` callback — the session wires
that to `SessionMonitor.record_blocked_url`, which audits + escalates
(max_warnings → disconnect; rapid burst → instant disconnect).

Threat-model note: the coworker has NO local keyboard/mouse on the
owner's machine — they drive Chrome only through replayed CDP input.
So navigation only happens via in-page link clicks / JS / form submit,
all of which surface here as document requests. This makes Fetch
interception a comprehensive chokepoint for the remote renter.
"""

from __future__ import annotations

import fnmatch
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable
from urllib.parse import urlparse

import structlog

from haon_agent.byoc.runtime.browser.url_guard import (
    HARDCODED_HARD_BLOCK_URLS,
    host_of,
)


log = structlog.get_logger("agent.browser.nav_guard")


# Schemes a remote coworker is allowed to navigate the app window to.
# Everything else (file, ftp, view-source, devtools, chrome,
# chrome-extension, filesystem, ...) is blocked — those are local-file
# / browser-internals / source-disclosure vectors.
_ALLOWED_SCHEMES: frozenset[str] = frozenset({
    "http", "https", "about", "blob", "data",
})


# Callback fired on a blocked navigation: (url, kind) → awaitable.
# kind ∈ {"scheme", "blocklist", "off_allowlist"}. The session wires
# this to SessionMonitor.record_blocked_url.
OnBlocked = Callable[[str, str], Awaitable[None]]


@dataclass
class NavGuard:
    """Per-session navigation policy + Fetch interception loop.

    Build via `build_nav_guard(...)`. Call `await install(cdp)` after
    the page guards are armed but BEFORE the first real navigation, so
    the initial load is validated too (the initial host is in
    `allowed_hosts`, so it passes).
    """

    allowed_hosts: frozenset[str]
    allow_outside: bool
    blocklist_patterns: tuple[str, ...]
    on_blocked: OnBlocked | None = None
    session_id: str | None = None

    _listener: Any = field(default=None, init=False)

    async def install(self, cdp: Any) -> Any:
        """Enable Fetch interception on document navigations and start
        the background pause-handler loop. Returns the listener task so
        the caller can cancel it on teardown."""
        # resourceType MUST be a valid Network.ResourceType enum value.
        # "SubDocument" is NOT one (Chrome rejects it with CDP -32602) —
        # iframe document loads are reported as "Document" too, so the
        # single "Document" pattern intercepts top-level AND iframe
        # navigations with zero coverage loss.
        await cdp.send(
            "Fetch.enable",
            {
                "patterns": [
                    {"urlPattern": "*", "resourceType": "Document",
                     "requestStage": "Request"},
                ],
                "handleAuthRequests": False,
            },
            session_id=self.session_id,
        )
        import asyncio
        self._listener = asyncio.create_task(
            self._loop(cdp), name="nav-guard-fetch-loop"
        )
        log.info(
            "nav_guard_installed",
            allow_outside=self.allow_outside,
            allowed_hosts=sorted(self.allowed_hosts),
            session_id=self.session_id,
        )
        return self._listener

    async def _loop(self, cdp: Any) -> None:
        """Consume Fetch.requestPaused forever. EVERY paused request must
        be answered (continue/fail) or the page hangs — so the decision
        is wrapped to always emit exactly one response."""
        async for ev in cdp.events(
            "Fetch.requestPaused", session_id=self.session_id
        ):
            request_id = ev.get("requestId")
            if not request_id:
                continue
            url = (ev.get("request") or {}).get("url", "")
            kind = self._verdict(url)
            if kind is None:
                await self._continue(cdp, request_id)
            else:
                await self._fail(cdp, request_id)
                if self.on_blocked is not None:
                    try:
                        await self.on_blocked(url, kind)
                    except Exception:  # noqa: BLE001
                        log.exception("nav_guard_on_blocked_failed")
                log.info("nav_guard_blocked", url=url[:200], kind=kind)

    def _verdict(self, url: str) -> str | None:
        """Return a block-kind string if the URL must be blocked, else
        None (allow). Fail-safe: a missing/unparseable URL is blocked."""
        if not isinstance(url, str) or not url:
            return "scheme"
        try:
            scheme = (urlparse(url).scheme or "").lower()
        except (ValueError, AttributeError):
            return "scheme"
        # about:blank (and about:srcdoc for iframes) must pass — they're
        # our own blank window + benign iframe sources.
        if scheme and scheme not in _ALLOWED_SCHEMES:
            return "scheme"
        # Blocklist patterns (hard-block + per-grant) — glob match.
        low = url.lower()
        for pat in self.blocklist_patterns:
            if fnmatch.fnmatch(low, pat.lower()):
                return "blocklist"
        # Host allowlist (only enforced when navigation is restricted).
        if not self.allow_outside:
            host = host_of(url)
            # about:/blob:/data: have no host — allowed by scheme above.
            if host is not None and not self._host_allowed(host):
                return "off_allowlist"
        return None

    def _host_allowed(self, host: str) -> bool:
        host = host.lower()
        for allowed in self.allowed_hosts:
            if host == allowed or host.endswith("." + allowed):
                return True
        return False

    async def _continue(self, cdp: Any, request_id: str) -> None:
        try:
            await cdp.send(
                "Fetch.continueRequest",
                {"requestId": request_id},
                session_id=self.session_id,
            )
        except Exception:  # noqa: BLE001
            log.exception("nav_guard_continue_failed")

    async def _fail(self, cdp: Any, request_id: str) -> None:
        try:
            await cdp.send(
                "Fetch.failRequest",
                {"requestId": request_id, "errorReason": "Aborted"},
                session_id=self.session_id,
            )
        except Exception:  # noqa: BLE001
            log.exception("nav_guard_fail_failed")


def build_nav_guard(
    *,
    permissions: dict[str, Any],
    initial_url: str,
    on_blocked: OnBlocked | None = None,
    session_id: str | None = None,
) -> NavGuard:
    """Compose a NavGuard from session permissions + the initial URL.

    allowed_hosts = host(initial_url) + url_allowlist entries (each
    parsed as a bare host or a URL). allow_outside is driven by
    `can_navigate_outside_initial_domain`. The blocklist is the
    HARDCODED hard-block floor plus per-grant url_blocklist.
    """
    hosts: set[str] = set()
    init_host = host_of(initial_url)
    if init_host:
        hosts.add(init_host)
    for entry in permissions.get("url_allowlist") or []:
        if not isinstance(entry, str) or not entry.strip():
            continue
        # Accept either a bare host ("example.com") or a full URL.
        h = host_of(entry) if "/" in entry else entry.strip().lower()
        if h:
            hosts.add(h)

    extra_block = [
        e.strip() for e in (permissions.get("url_blocklist") or [])
        if isinstance(e, str) and e.strip()
    ]
    patterns = tuple(HARDCODED_HARD_BLOCK_URLS) + tuple(extra_block)

    return NavGuard(
        allowed_hosts=frozenset(hosts),
        allow_outside=bool(
            permissions.get("can_navigate_outside_initial_domain", False)
        ),
        blocklist_patterns=patterns,
        on_blocked=on_blocked,
        session_id=session_id,
    )
