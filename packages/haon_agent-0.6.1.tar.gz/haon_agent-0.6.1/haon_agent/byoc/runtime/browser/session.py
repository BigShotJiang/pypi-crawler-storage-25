"""Sprint 1F.4 phase 4 — BrowserSession orchestrator.

One BrowserSession per Studio session_offer received on the agent's
main /v1/byoc/connect WSS. Costuras tudo:

  1. parse permissions (HARDCODED-FALSE stripped)
  2. acquire the singleton browser slot (Sprint 1F.7) — the
     BrowserManager owns ONE dedicated Chrome per agent, reused across
     sessions; slot=1 serialises (single Gemini account)
  3. connect CDP + attach a page session to the app-window target
  4. apply url_guard (Layer 1)
  5. apply page_guard (Layer 2 JS/CSS inject)
  5.5 navigate the (about:blank) window to the resource URL — guards
      are armed first, so they catch the initial load
  6. start SessionMonitor (Layer 3 idle+counter)
  7. start BrowserWebRTCPeer
  8. open signaling WSS to broker
  9. drive SDP/ICE handshake offer→answer
  10. relay ICE candidates both directions
  11. on monitor disconnect / signaling close / WSS drop → release the
      slot (NOT kill Chrome — the manager's idle watchdog owns the
      process lifecycle) and tear down everything cleanly

Lifecycle:
    session = BrowserSession(offer, main_ws_send, resource_resolver)
    await session.start()       # raises on bring-up failure
    await session.wait()        # blocks until the session ends
    # (or explicit close)
    await session.close()       # idempotent
"""

from __future__ import annotations

import asyncio
import contextlib
import mimetypes
from dataclasses import asdict
from pathlib import Path
from typing import Any, Awaitable, Callable

import structlog

from haon_agent.byoc.runtime.browser import (
    nav_guard as _nav_guard,
    page_guard,
    permissions as _permissions,
    url_guard,
    webrtc_peer,
)
from haon_agent.byoc.runtime.browser.cdp import CDPClient
from haon_agent.byoc.runtime.browser.browser_manager import BrowserManager
from haon_agent.byoc.runtime.browser.download_capture import DownloadCapture
from haon_agent.byoc.runtime.browser.audit import AuditEmitter
from haon_agent.byoc.runtime.browser.monitor import (
    DisconnectReason,
    SessionMonitor,
)
from haon_agent.byoc.runtime.browser.signal_client import SignalClient


log = structlog.get_logger("agent.browser.session")


# Sender of frames over the agent's main /v1/byoc/connect WSS. Used
# for audit emission relay (broker forwards audit_event frames to
# haonhub /audit/broker).
MainWSSFrameSender = Callable[[dict[str, Any]], Awaitable[None]]

# Maps resource_id (from session_offer) → URL Chrome opens in --app
# mode. Caller (transport.py) supplies the resolver so the agent
# could swap implementations (static dict, lookup-from-disk, etc).
ResourceResolver = Callable[[str], str]


# Default mapping of resource_id → launchable URL. Phase 4 ships a
# fixed table for known providers; phase 5 can replace with a
# user-config file.
DEFAULT_RESOURCE_URL_MAP: dict[str, str] = {
    "gemini-ultra": "https://gemini.google.com/",
    "gemini": "https://gemini.google.com/",
    "chatgpt-pro": "https://chat.openai.com/",
    "chatgpt": "https://chat.openai.com/",
    "claude-pro": "https://claude.ai/",
    "claude": "https://claude.ai/",
    "veo": "https://gemini.google.com/",     # Veo lives inside Gemini today
    "kling": "https://klingai.com/",
}


def resolve_resource_url(resource_id: str) -> str:
    """Default resolver. Returns the mapped URL or — fallback — treats
    resource_id as a URL itself if it looks like one. Otherwise raises
    so the caller knows to abort the session.
    """
    if resource_id in DEFAULT_RESOURCE_URL_MAP:
        return DEFAULT_RESOURCE_URL_MAP[resource_id]
    if resource_id.startswith(("https://", "http://")):
        return resource_id
    raise ValueError(
        f"Unknown resource_id {resource_id!r} — no URL mapping. "
        "Add to DEFAULT_RESOURCE_URL_MAP or pass a full URL."
    )


class BrowserSession:
    """One Studio session lifecycle. Concurrency-safe within itself
    via the asyncio single-thread guarantee + the various subcomponent
    locks (CDP send, signal send, etc)."""

    def __init__(
        self,
        offer: dict[str, Any],
        *,
        main_ws_send: MainWSSFrameSender,
        resource_resolver: ResourceResolver | None = None,
    ) -> None:
        self._offer = offer
        self._main_ws_send = main_ws_send
        self._resolve = resource_resolver or resolve_resource_url
        self.session_id: str = offer.get("session_id") or "unknown"
        self._audit = AuditEmitter(
            session_id=self.session_id,
            send_frame=main_ws_send,
        )
        # Subcomponents — populated by start()
        self._cdp: Any = None          # CDP client (browser-level WS)
        self._cdp_session_id: str | None = None  # Page-level CDP session
        self._browser: BrowserManager | None = None  # singleton owner
        self._acquired: bool = False   # holds the slot=1 reservation
        self._start_url: str = ""
        self._downloads: DownloadCapture | None = None
        self._download_tasks: list[asyncio.Task] = []
        # transfer_id (sha256[:16]) → file Path, for deletion on file-ack.
        self._pending_transfers: dict[str, Path] = {}
        self._monitor: SessionMonitor | None = None
        self._peer: webrtc_peer.BrowserWebRTCPeer | None = None
        self._signal: SignalClient | None = None
        self._page_guard_listener: asyncio.Task | None = None
        self._nav_guard: _nav_guard.NavGuard | None = None
        self._nav_guard_listener: asyncio.Task | None = None
        self._target_watch_task: asyncio.Task | None = None
        # Lifecycle
        self._done = asyncio.Event()
        self._closed = False
        self._close_lock = asyncio.Lock()

    # ── Public API ──────────────────────────────────────────────────

    async def start(self) -> None:
        """Bring up the full session. Raises on any setup failure;
        caller (transport handler) should then call close() to clean
        up any partial state.
        """
        # Phase 1: parse permissions + bump audit for any HARDCODED
        # bypass attempts haonhub may have sent
        raw_perms = self._offer.get("permissions") or {}
        perms = _permissions.parse_permissions(
            raw_perms,
            on_locked_attempted=self._on_locked_perm_attempt,
        )
        perms_dict = asdict(perms)

        # Phase 2: acquire the singleton browser (Sprint 1F.7). The
        # BrowserManager owns ONE dedicated Chrome process per agent,
        # launched lazily (--app=about:blank, dynamic port, isolated
        # profile with the shared Gemini login). slot=1 — raises
        # BrowserBusyError if another session holds it. We get the
        # single app-window target showing about:blank; we navigate it
        # to the real URL AFTER guards are applied (Phase 5.5) so the
        # url/page guards catch the initial load.
        #
        # browser_mode (per grant/resource, 0.5.6): "app" → --app kiosk
        # window (no URL bar / tabs / menu — the locked "Gemini app"
        # experience); "chrome" → ordinary navigable Chrome (still gated
        # by nav_guard + url_guard). Unknown / absent → "app" (the safer,
        # more locked-down default). The manager relaunches if the live
        # process is in the other mode (safe under slot=1).
        start_url = self._resolve(self._offer.get("resource_id", ""))
        self._start_url = start_url
        browser_mode = str(self._offer.get("browser_mode") or "app").lower()
        app_mode = browser_mode != "chrome"
        self._browser = BrowserManager.instance()
        ws_url, target_id = await self._browser.acquire(
            start_url, app_mode=app_mode,
        )
        self._acquired = True
        log.info(
            "browser_session_mode",
            session_id=self.session_id,
            browser_mode=("chrome" if not app_mode else "app"),
        )
        log.info(
            "browser_session_acquired",
            session_id=self.session_id,
            target_id=target_id,
        )

        # Phase 3: connect this session's CDP to the shared browser WS.
        self._cdp = await CDPClient.connect(ws_url)
        log.info("browser_session_cdp_connected", session_id=self.session_id)

        # Phase 3.5: attach a page-level CDP session to the app-window
        # target the manager handed us. Network/Page/Input/DOM/Runtime
        # need a session context (flatten mode demuxes by sessionId).
        self._cdp_session_id = await self._cdp.attach_session(target_id)
        log.info(
            "browser_session_cdp_session_attached",
            session_id=self.session_id,
            cdp_session_id=self._cdp_session_id,
            target_id=target_id,
        )

        # Phase 4: apply url_guard (Layer 1)
        blocklist = url_guard.build_blocklist(
            extra_blocklist=perms.url_blocklist,
            allowlist=perms.url_allowlist,
        )
        await url_guard.apply_url_blocklist(
            self._cdp,
            blocklist=blocklist,
            session_id=self._cdp_session_id,
        )

        # Phase 5: apply page_guard (Layer 2 JS/CSS inject)
        self._page_guard_listener = await page_guard.apply_page_guards(
            self._cdp,
            permissions=perms_dict,
            on_audit_event=self._audit.emit,
            session_id=self._cdp_session_id,
        )

        # Phase 5.4: start the session monitor (Layer 3 idle + counter)
        # BEFORE nav_guard so blocked navigations have a live counter to
        # escalate against (max_warnings → disconnect). Idle watchdog
        # starting a touch early is harmless.
        self._monitor = SessionMonitor(
            session_id=self.session_id,
            idle_timeout_seconds=perms.idle_timeout_min * 60,
            max_blocked_warnings=perms.max_warnings_before_disconnect,
            audit_emit=self._audit.emit,
            on_disconnect=self._on_monitor_disconnect,
        )
        await self._monitor.start()

        # Phase 5.5: arm nav_guard (Layer 1.5, ST-01 teeth). Fetch
        # interception on document navigations validates every URL
        # against the scheme allowlist + blocklist patterns + host
        # allowlist (when can_navigate_outside_initial_domain is False).
        # Installed BEFORE the initial navigate so that load is checked
        # too (the initial host is allowed, so it passes).
        self._nav_guard = _nav_guard.build_nav_guard(
            permissions=perms_dict,
            initial_url=start_url,
            on_blocked=self._on_nav_blocked,
            session_id=self._cdp_session_id,
        )
        self._nav_guard_listener = await self._nav_guard.install(self._cdp)

        # Phase 5.55: watch for unexpected new page targets (popups /
        # target=_blank / ctrl-click). When can_open_new_tab is False we
        # close them immediately + audit. window.open is already JS-
        # blocked and Ctrl+T/N dropped at input_replay; this catches the
        # residual link-driven vectors that bypass both.
        self._target_watch_task = await self._install_target_watch(
            can_open_new_tab=bool(perms.can_open_new_tab),
        )

        # Phase 5.6: NOW navigate the (about:blank) app window to the
        # real session URL. Guards are already armed (Network blocklist
        # + page-guard addScriptToEvaluateOnNewDocument + nav_guard
        # Fetch interception), so they catch this initial load — better
        # than the old launch-with-url model where guards applied AFTER
        # the page had already loaded. Also gives each renter a fresh
        # page (UX hygiene the brief asked for).
        await self._cdp.send(
            "Page.navigate",
            {"url": start_url},
            session_id=self._cdp_session_id,
        )
        log.info(
            "browser_session_navigated",
            session_id=self.session_id,
            url=start_url,
        )

        # Phase 7: start WebRTC peer
        turn_servers = self._offer.get("turn_creds") or {}
        ice_servers: list[dict[str, Any]] = []
        urls = turn_servers.get("urls") or []
        if urls:
            ice_servers.append({
                "urls": urls,
                "username": turn_servers.get("username"),
                "credential": turn_servers.get("credential"),
            })
        # Phase 6.5: download capture (Sprint 1F.6). Route Chrome
        # downloads into a session-scoped folder so the file-transfer
        # layer can ship them to the coworker. Gated on can_download —
        # if not granted, behavior="deny" and nothing is captured.
        dl_dir = (
            Path.home()
            / ".haon"
            / "studio_downloads"
            / self.session_id
        )
        self._downloads = DownloadCapture(
            session_id=self.session_id,
            download_dir=dl_dir,
            can_download=bool(perms.can_download),
            on_complete=self._on_download_complete,
        )
        await self._downloads.install(self._cdp)
        if perms.can_download:
            # Browser.* events are browser-level — subscribe with no
            # session_id. Background tasks drain the event iterators.
            self._download_tasks.append(
                asyncio.create_task(
                    self._drain_download_events("Browser.downloadWillBegin"),
                    name="dl-will-begin",
                )
            )
            self._download_tasks.append(
                asyncio.create_task(
                    self._drain_download_events("Browser.downloadProgress"),
                    name="dl-progress",
                )
            )

        self._peer = webrtc_peer.BrowserWebRTCPeer(
            cdp=self._cdp,
            cdp_session_id=self._cdp_session_id,
            permissions=perms_dict,
            ice_servers=ice_servers,
            audit_emit=self._audit.emit,
            on_state_change=self._on_peer_state_change,
            on_file_ack=self._on_file_ack,
            on_input=self._on_input_activity,
        )
        await self._peer.start()

        # Hook ICE candidate generation → relay via signal WSS.
        # aiortc fires an `icecandidate` event-equivalent through the
        # RTCPC's onicecandidate setter (rare in aiortc; ICE info is
        # typically embedded in the SDP). For aiortc the default flow
        # is "ICE in SDP" — we don't usually trickle. Leaving the
        # trickle path explicit anyway in case future aiortc bumps
        # support it OR the coworker side trickles to us.

        # Phase 8: open signaling WSS
        signaling_url = self._offer["signaling_url"]
        session_token = self._offer["session_token"]
        self._signal = SignalClient(
            url=signaling_url,
            token=session_token,
            on_message=self._on_signal_message,
            on_close=self._on_signal_close,
        )
        await self._signal.connect()

        # Phase 9: agent is OFFERER per haonhub viewer wire (phase 4.5
        # alignment 2026-05-19). Coworker viewer waits for our offer
        # then sends answer. Generate + send offer NOW so handshake
        # starts immediately on coworker side opening the WSS.
        offer_sdp = await self._peer.create_offer()
        await self._signal.send({"type": "offer", "sdp": offer_sdp})
        log.info(
            "browser_session_offer_sent",
            session_id=self.session_id,
        )

        log.info(
            "browser_session_ready",
            session_id=self.session_id,
        )

    async def wait(self) -> None:
        """Block until the session ends (monitor disconnect, signaling
        WSS drop, or explicit close())."""
        await self._done.wait()

    # ── Download forwarding (Sprint 1F.6) ───────────────────────────

    async def _drain_download_events(self, method: str) -> None:
        """Background loop: route a Browser.download* event iterator to
        the DownloadCapture handler. Browser-level → no session_id."""
        if self._downloads is None:
            return
        try:
            async for ev in self._cdp.events(method):
                if method == "Browser.downloadWillBegin":
                    self._downloads.on_will_begin(ev)
                else:  # Browser.downloadProgress
                    await self._downloads.on_progress(ev)
        except Exception:  # noqa: BLE001
            log.exception("download_event_loop_failed", method=method)

    async def _on_download_complete(self, path: Path, name: str) -> None:
        """A download finished on disk → ship it to the coworker + audit.

        Stores transfer_id→path so the file-ack can delete it. The
        actual bytes go over the peer's 'file' DataChannel."""
        if self._peer is None:
            return
        mime, _ = mimetypes.guess_type(name)
        sha256 = await self._peer.send_file(
            path, name, mime or "application/octet-stream"
        )
        if sha256 is None:
            # Transfer failed / no file channel — leave for cleanup.
            return
        transfer_id = sha256[:16]
        self._pending_transfers[transfer_id] = path
        # ST-07 audit: forensic trail for marketplace disputes.
        try:
            size = path.stat().st_size
        except OSError:
            size = 0
        await self._audit.emit(
            "download",
            {
                "name": name,
                "size": size,
                "sha256": sha256,
                "transfer_id": transfer_id,
            },
        )

    async def _on_file_ack(self, transfer_id: str, ok: bool) -> None:
        """Viewer confirmed receipt → delete the file from owner's disk."""
        path = self._pending_transfers.pop(transfer_id, None)
        if path is not None and ok and self._downloads is not None:
            self._downloads.delete_file(path)
            log.info(
                "download_transfer_acked_deleted",
                session_id=self.session_id,
                transfer_id=transfer_id,
            )

    async def close(self) -> None:
        """Tear down the session. Idempotent — safe to call from
        multiple paths (monitor disconnect, signaling close, agent
        shutdown).
        """
        async with self._close_lock:
            if self._closed:
                return
            self._closed = True

        log.info("browser_session_closing", session_id=self.session_id)

        # Order matters minimally — signal close first so we don't
        # try to relay frames mid-teardown; monitor next to stop the
        # watchdog; peer; CDP; Chrome.
        await self._safe(self._signal_close())
        await self._safe(self._monitor_shutdown())
        await self._safe(self._peer_close())
        await self._safe(self._page_guard_cancel())
        await self._safe(self._nav_guard_cancel())
        await self._safe(self._target_watch_cancel())
        await self._safe(self._downloads_cleanup())
        await self._safe(self._cdp_close())
        await self._safe(self._browser_release())

        self._done.set()
        log.info("browser_session_closed", session_id=self.session_id)

    async def _downloads_cleanup(self) -> None:
        """Cancel download event loops + wipe the session download dir
        (watchdog: deletes any files not yet acked)."""
        for t in self._download_tasks:
            t.cancel()
        for t in self._download_tasks:
            with contextlib.suppress(asyncio.CancelledError, Exception):
                await t
        self._download_tasks.clear()
        if self._downloads is not None:
            self._downloads.cleanup()

    # ── Signal handlers ─────────────────────────────────────────────

    async def _on_signal_message(self, frame: dict[str, Any]) -> None:
        """Handle one frame received from broker (relayed from coworker).

        Wire alignment with haonhub viewer (phase 4.5, 2026-05-19):
          - Discriminator field is `type` (matches haonhub's
            studio-session.js + standard WebRTC RTCSessionDescription
            convention). Legacy `msg` accepted as fallback for
            forward-compat with any older callers.
          - Agent is OFFERER → coworker sends `answer`, not `offer`
          - Ping/pong heartbeat: coworker sends `{type:"ping"}` every
            ~25s; we respond `{type:"pong"}` so viewer doesn't think
            the connection is dead.
        """
        kind = frame.get("type") or frame.get("msg")
        if kind == "answer":
            sdp = frame.get("sdp")
            if not isinstance(sdp, str) or self._peer is None:
                log.warning("browser_session_answer_missing_sdp")
                return
            try:
                await self._peer.apply_remote_answer(sdp)
                log.info(
                    "browser_session_answer_applied",
                    session_id=self.session_id,
                )
            except Exception:  # noqa: BLE001
                log.exception("browser_session_answer_apply_failed")
            return
        if kind == "offer":
            # Legacy answerer path — accepted for symmetric negotiation
            # use cases (perfect negotiation, future flow changes).
            # Production wire today has agent as offerer.
            sdp = frame.get("sdp")
            if not isinstance(sdp, str) or self._peer is None:
                log.warning("browser_session_offer_missing_sdp")
                return
            answer_sdp = await self._peer.apply_remote_offer(sdp)
            await self._signal.send({"type": "answer", "sdp": answer_sdp})
            return
        if kind == "ice":
            candidate = frame.get("candidate")
            if not isinstance(candidate, dict) or self._peer is None:
                return
            try:
                await self._peer.add_ice_candidate(candidate)
            except Exception:  # noqa: BLE001
                log.exception("browser_session_ice_add_failed")
            return
        if kind == "ping":
            # Coworker heartbeat — respond so viewer keeps the WSS
            # alive. Best-effort; send may silently fail on a dying
            # signal channel, but the on_close path handles teardown.
            await self._signal.send({"type": "pong"})
            return
        if kind == "ready":
            # Coworker greeted us on connect. Optional ack.
            log.info(
                "browser_session_coworker_ready",
                session_id=self.session_id,
                role=frame.get("role"),
            )
            return
        if kind == "bye":
            log.info(
                "browser_session_bye_received",
                session_id=self.session_id,
                reason=frame.get("reason"),
            )
            asyncio.create_task(self.close(), name="session-close-on-bye")
            return
        # Unknown discriminator — log + drop. Broker is dumb pipe;
        # new msg types may come from haonhub-side viewer at any time.
        log.info(
            "browser_session_unknown_signal_kind",
            session_id=self.session_id,
            kind=kind,
        )

    async def _on_signal_close(self, reason: str) -> None:
        """Signal WSS dropped — tear down the whole session."""
        log.info(
            "browser_session_signal_closed",
            session_id=self.session_id,
            reason=reason,
        )
        asyncio.create_task(self.close(), name="session-close-on-signal-close")

    # ── Monitor handler ─────────────────────────────────────────────

    async def _on_monitor_disconnect(
        self,
        reason: str,
        context: dict[str, Any],
    ) -> None:
        """SessionMonitor exceeded a threshold (idle, blocked counter,
        rapid clicks) → close the session and signal bye to coworker."""
        log.warning(
            "browser_session_monitor_disconnect",
            session_id=self.session_id,
            reason=reason,
            context=context,
        )
        # Notify coworker (best-effort — signal may already be gone)
        if self._signal is not None and not self._closed:
            try:
                await self._signal.send({
                    "type": "bye",
                    "reason": reason,
                })
            except Exception:  # noqa: BLE001
                pass
        asyncio.create_task(self.close(), name="session-close-on-monitor")

    # ── Nav guard + input activity handlers (ST-01 teeth) ───────────

    async def _on_nav_blocked(self, url: str, kind: str) -> None:
        """nav_guard aborted a navigation. Feed the monitor so it audits
        + escalates (max_warnings → disconnect; rapid burst → instant).
        record_blocked_url owns the audit emit, so we don't double-emit
        here."""
        if self._monitor is not None:
            await self._monitor.record_blocked_url(url, attempt_kind=kind)

    def _on_input_activity(self) -> None:
        """Called by the WebRTC peer on every coworker input event that
        passes the rate-limiter. Resets the idle timer — without this
        the idle watchdog would fire at a fixed time from session start
        regardless of activity (the pre-0.5.4 dead-wire bug)."""
        if self._monitor is not None:
            self._monitor.record_input()

    async def _install_target_watch(
        self, *, can_open_new_tab: bool,
    ) -> asyncio.Task | None:
        """Discover + watch browser targets. When can_open_new_tab is
        False, auto-close any NEW page target (popup / target=_blank /
        ctrl-click) that isn't our session window, and feed the monitor.

        When can_open_new_tab is True we leave new targets alone (the
        grant permits them); guarding those is a future multi-target
        enhancement.
        """
        if can_open_new_tab:
            return None
        # Target.* is browser-level — no session_id. Enable discovery so
        # Target.targetCreated fires for popups.
        try:
            await self._cdp.send("Target.setDiscoverTargets", {"discover": True})
        except Exception:  # noqa: BLE001
            log.warning("browser_session_target_discover_failed",
                        session_id=self.session_id)
            return None
        return asyncio.create_task(
            self._target_watch_loop(), name="target-watch",
        )

    async def _target_watch_loop(self) -> None:
        """Close unexpected new page targets. Our session reuses ONE
        app-window target (handed over by BrowserManager) which has no
        opener; any page target WITH an openerId is a popup / new tab
        the renter spawned (window.open / target=_blank / ctrl-click)
        and shouldn't get when can_open_new_tab is False."""
        async for ev in self._cdp.events("Target.targetCreated"):
            info = ev.get("targetInfo") or {}
            if info.get("type") != "page" or not info.get("openerId"):
                continue
            target_id = info.get("targetId")
            if not target_id:
                continue
            try:
                await self._cdp.send("Target.closeTarget",
                                     {"targetId": target_id})
            except Exception:  # noqa: BLE001
                log.warning("browser_session_close_target_failed",
                            session_id=self.session_id, target_id=target_id)
            url = info.get("url", "")
            log.info("browser_session_blocked_new_target",
                     session_id=self.session_id, url=url[:200])
            if self._monitor is not None:
                with contextlib.suppress(Exception):
                    await self._monitor.record_blocked_url(
                        url or "about:blank", attempt_kind="new_tab",
                    )

    # ── WebRTC state handler ────────────────────────────────────────

    async def _on_peer_state_change(
        self,
        state: str,
        context: dict[str, Any],
    ) -> None:
        """RTCPeerConnection state changed. We care about 'failed' and
        'closed' for tear-down; other transitions are just logged via
        the peer's own audit emit path."""
        if state in ("failed", "closed"):
            log.info(
                "browser_session_peer_terminal",
                session_id=self.session_id,
                state=state,
            )
            asyncio.create_task(self.close(), name="session-close-on-peer-state")

    # ── Permissions bypass audit ────────────────────────────────────

    def _on_locked_perm_attempt(self, key: str) -> None:
        """Called by parse_permissions when haonhub sent a HARDCODED
        key with True value. We emit an audit event so haonhub UI
        misconfiguration surfaces."""
        # Fire-and-forget — parse_permissions is sync, the audit emit
        # is async. Schedule on the loop.
        try:
            asyncio.get_event_loop().create_task(
                self._audit.emit(
                    "blocked_action",
                    {
                        "kind": "permission_bypass_attempt",
                        "permission_key": key,
                    },
                ),
                name=f"audit-perm-bypass-{key}",
            )
        except RuntimeError:
            # No running loop yet (shouldn't happen in our flow since
            # start() runs inside the loop). Drop silently.
            pass

    # ── Teardown helpers ────────────────────────────────────────────

    async def _safe(self, awaitable: Any) -> None:
        try:
            await awaitable
        except Exception:  # noqa: BLE001
            log.exception("browser_session_teardown_step_failed")

    async def _signal_close(self) -> None:
        if self._signal is not None:
            await self._signal.close()

    async def _monitor_shutdown(self) -> None:
        if self._monitor is not None:
            await self._monitor.shutdown()

    async def _peer_close(self) -> None:
        if self._peer is not None:
            await self._peer.close()

    async def _page_guard_cancel(self) -> None:
        if self._page_guard_listener is not None:
            self._page_guard_listener.cancel()
            try:
                await self._page_guard_listener
            except (asyncio.CancelledError, Exception):  # noqa: BLE001
                pass

    async def _nav_guard_cancel(self) -> None:
        if self._nav_guard_listener is not None:
            self._nav_guard_listener.cancel()
            with contextlib.suppress(asyncio.CancelledError, Exception):
                await self._nav_guard_listener

    async def _target_watch_cancel(self) -> None:
        if self._target_watch_task is not None:
            self._target_watch_task.cancel()
            with contextlib.suppress(asyncio.CancelledError, Exception):
                await self._target_watch_task

    async def _cdp_close(self) -> None:
        if self._cdp is not None and hasattr(self._cdp, "close"):
            maybe_coro = self._cdp.close()
            if asyncio.iscoroutine(maybe_coro):
                await maybe_coro

    async def _browser_release(self) -> None:
        """Release the singleton browser slot (Sprint 1F.7). Does NOT
        kill the Chrome process — the BrowserManager idle watchdog owns
        process lifecycle. Navigates the shared window back to about:blank
        and frees the slot for the next session."""
        if self._acquired and self._browser is not None:
            self._acquired = False
            await self._browser.release()


# ── Module-level registry of active sessions ────────────────────────


class BrowserSessionRegistry:
    """Tracks active BrowserSessions across the agent process. Used by
    transport.py to clean up all sessions on agent shutdown OR main
    WSS reconnect (sessions tied to a specific WSS lifetime).

    Single-replica posture — one registry per agent process. The
    broker tracks multi-session counts independently via SISMEMBER
    on the agents set.
    """

    def __init__(self) -> None:
        self._by_session_id: dict[str, BrowserSession] = {}
        self._lock = asyncio.Lock()

    async def register(self, session: BrowserSession) -> None:
        async with self._lock:
            self._by_session_id[session.session_id] = session

    async def unregister(self, session_id: str) -> None:
        async with self._lock:
            self._by_session_id.pop(session_id, None)

    async def close_all(self) -> None:
        """Close every active session. Called on agent shutdown OR
        main WSS reconnect (existing sessions are dead anyway since
        the audit channel goes through main WSS)."""
        async with self._lock:
            sessions = list(self._by_session_id.values())
            self._by_session_id.clear()
        # Close concurrently with bounded wait
        if not sessions:
            return
        await asyncio.gather(
            *(s.close() for s in sessions),
            return_exceptions=True,
        )

    async def count(self) -> int:
        async with self._lock:
            return len(self._by_session_id)
