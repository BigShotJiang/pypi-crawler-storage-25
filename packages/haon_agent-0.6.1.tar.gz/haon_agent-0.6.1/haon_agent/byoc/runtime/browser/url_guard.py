"""Sprint 1F.4 phase 2 — Layer 1 URL blocklist via CDP.

Chrome DevTools Protocol's `Network.setBlockedURLs` accepts a list of
URL patterns (glob with `*` wildcard); network requests matching ANY
of them get failed at the network stack. This is fundamentally MORE
robust than JS-level blocking because:

  - JS in the page can't bypass it (the request never leaves)
  - Works for XHR/fetch + navigations + frames + scripts uniformly
  - No re-injection needed across navigations

Combined with Chrome `--app=<url>` (Layer 0 in launcher.py) and idle
+ counter monitoring (Layer 3 in monitor.py), this carries the bulk
of the Studio security story. Layer 2 (JS/CSS inject) lands in phase
2.5 as UX polish.

Hard-block defaults are HARDCODED constants in this module — they
apply to every session regardless of grant permissions. The per-grant
url_blocklist appends to these; url_allowlist (if non-empty) adds an
implicit deny-everything-else policy (via the inverse blocklist).
"""

from __future__ import annotations

import logging
from typing import Any
from urllib.parse import urlparse


log = logging.getLogger("agent.browser.url_guard")


# Patterns that are ALWAYS blocked across every Studio session. Chosen
# to cover the most-common owner-account-takeover vectors:
#
#   1. Google account management (signout / signout-and-pick / manage)
#   2. Chrome internals (chrome://settings, chrome://flags,
#      chrome://extensions, chrome://net-internals etc)
#   3. Provider-specific account/billing pages for the common Studio
#      use cases (Gemini, ChatGPT, Claude)
#
# Add new patterns here, not in per-grant config. Per-grant blocklist
# is operator-extensible; this list is the floor.
HARDCODED_HARD_BLOCK_URLS: tuple[str, ...] = (
    # Google account management
    "*accounts.google.com/signout*",
    "*accounts.google.com/Logout*",
    "*accounts.google.com/AccountChooser*",
    "*accounts.google.com/*usp=identity_action*",
    "*myaccount.google.com/*",
    "*security.google.com/*",
    "*passwords.google.com/*",
    "*takeout.google.com/*",
    "*support.google.com/accounts/answer/*",

    # Chrome internals — these MAY not actually fire as URL requests
    # (chrome:// is intercepted by browser itself, not a real network
    # request), but setting them defends against odd redirect chains
    "chrome://settings/*",
    "chrome://flags/*",
    "chrome://extensions/*",
    "chrome://history/*",
    "chrome://downloads/*",
    "chrome://bookmarks/*",
    "chrome://password-manager/*",
    "chrome://net-internals/*",
    "chrome://inspect/*",
    "chrome://policy/*",
    "chrome://serviceworker-internals/*",

    # OpenAI / ChatGPT account
    "*chat.openai.com/auth/logout*",
    "*chat.openai.com/api/auth/signout*",
    "*platform.openai.com/account/*",
    "*platform.openai.com/api-keys*",

    # Anthropic / Claude
    "*claude.ai/api/auth/signout*",
    "*claude.ai/account*",
    "*console.anthropic.com/settings/*",

    # Common "logout" patterns regardless of host (catch-all defense)
    "*/signout*",
    "*/logout*",
    "*/sign_out*",
    "*/log_out*",
    "*/account/manage*",
    "*/account/security*",
    "*/account/delete*",
)


def build_blocklist(
    *,
    extra_blocklist: list[str],
    allowlist: list[str],
    initial_domain: str | None = None,
) -> list[str]:
    """Compose the final blocklist passed to CDP Network.setBlockedURLs.

    Composition:
      1. HARDCODED_HARD_BLOCK_URLS (the floor — always present)
      2. extra_blocklist from per-grant permissions
      3. If allowlist is non-empty: build inverse patterns that block
         everything NOT matching the allowed domains. We approximate
         this with `*` + filter — CDP doesn't have a native allowlist
         primitive, so we transform.

    `initial_domain` is what the session opened on (e.g.
    "gemini.google.com"). When the grant doesn't allow navigation
    outside the initial domain, we add the inverse block: everything
    not under that host.

    Liberal-parse approach: garbage entries in extra_blocklist (non-
    string) are silently dropped + warning logged.
    """
    out: list[str] = list(HARDCODED_HARD_BLOCK_URLS)

    for entry in extra_blocklist:
        if isinstance(entry, str) and entry.strip():
            out.append(entry.strip())
        else:
            log.warning("url_guard_dropped_invalid_blocklist_entry: %r", entry)

    # Allowlist (positive list) approximation: if non-empty, we keep
    # navigation TO those domains free and explicitly block known
    # dangerous off-domain patterns. CDP's setBlockedURLs is deny-list-
    # only; we don't have a native allow-list primitive. The session
    # monitor (Layer 3) catches navigation events to non-allowlisted
    # hosts and counts them — that's where the allowlist is actually
    # enforced beyond just network-level blocks.
    #
    # We DO add explicit allows-passthrough comments for ops clarity,
    # though they're no-op CDP-wise.

    # Initial-domain restriction: if grant doesn't permit leaving, we
    # rely on monitor.py to detect navigation events (Layer 3) since
    # CDP can't express "block all hosts other than X" inline.

    return out


async def apply_url_blocklist(
    cdp: Any,
    *,
    blocklist: list[str],
    session_id: str | None = None,
) -> None:
    """Send CDP Network.enable + Network.setBlockedURLs.

    Idempotent — calling multiple times with the same blocklist is a
    no-op cost-wise (CDP just overwrites). Caller should reapply on
    Target.attachedToTarget if a new tab opens, BUT in `--app` mode
    new tabs shouldn't be possible so this is a defensive-in-depth
    concern for the few escape routes that remain.

    `session_id` MUST be provided for real Chrome connections.
    Network.* is a session-level domain — calling it without sessionId
    on a browser-level CDP socket returns -32601 (this exact bug bit
    0.5.1.1 prod; Phase 2 fix routes via Target.attachToTarget). The
    parameter is optional for backwards compat with mock CDP doubles
    used in unit tests.
    """
    # Network domain must be explicitly enabled before setBlockedURLs
    # is honored. enable() is idempotent.
    await cdp.send("Network.enable", session_id=session_id)
    await cdp.send(
        "Network.setBlockedURLs",
        {"urls": blocklist},
        session_id=session_id,
    )
    log.info(
        "url_guard_blocklist_applied",
        extra={"count": len(blocklist), "session_id": session_id},
    )


def host_of(url: str) -> str | None:
    """Extract the lowercase host from a URL, or None if unparseable.
    Used by monitor.py to decide whether a navigation event lands
    outside the initial domain."""
    try:
        parsed = urlparse(url)
        return parsed.hostname.lower() if parsed.hostname else None
    except (ValueError, AttributeError):
        return None
