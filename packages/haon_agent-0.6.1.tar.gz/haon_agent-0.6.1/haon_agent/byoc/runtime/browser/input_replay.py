"""Sprint 1F.4 phase 3 — apply coworker input events to Chrome via CDP.

The coworker's browser viewer captures mouse + keyboard events from
its `<video>` canvas, packages them as JSON, and sends over the
WebRTC DataChannel established with the agent. The agent's WebRTC
peer receives each message and calls `apply_input_event` here, which
translates to CDP Input.dispatch* calls.

Wire format (agreed contract with haonhub viewer):

    Mouse:
      { type: "mouse",
        action: "down" | "up" | "move" | "wheel",
        x: int, y: int,
        button: "left" | "right" | "middle" | "none",
        deltaX: int, deltaY: int      # only when action=wheel
      }

    Keyboard:
      { type: "key",
        action: "down" | "up",
        key: string,                  # e.g. "a", "Enter", "ArrowDown"
        code: string,                 # e.g. "KeyA", "Enter"
        modifiers: int                # bitmask: alt=1, ctrl=2, meta=4, shift=8
      }

Defense layer notes:
  - HARDCODED hotkeys (F12, Ctrl+T, Ctrl+W) are blocked at the JS
    layer (page_guard) IN THE PAGE — they never reach this dispatcher
    because the coworker's viewer JS would have to construct them
    fake-side AFTER receiving them, which it doesn't do
  - This module DOES validate the event SHAPE. Garbage events
    (missing fields, wrong types) are silently dropped + logged
  - Permissions check: when can_open_new_tab/can_download is False,
    we drop the corresponding hotkey events here too (belt+suspenders;
    page_guard JS already blocks but we defense-in-depth)
"""

from __future__ import annotations

from typing import Any

import structlog


log = structlog.get_logger("agent.browser.input_replay")


# CDP Input.dispatchMouseEvent button mapping. Coworker viewer sends
# lowercase strings; CDP wants exact casing.
_MOUSE_BUTTON_MAP = {
    "left": "left",
    "right": "right",
    "middle": "middle",
    "none": "none",
}

# CDP `buttons` bitmask (which buttons are held). left=1, right=2,
# middle=4. Sent on mousePressed so Chrome models the button state for
# the click gesture; mouseReleased reports 0 (button no longer held).
_MOUSE_BUTTON_BIT = {"left": 1, "right": 2, "middle": 4, "none": 0}

# DOM MouseEvent.button is NUMERIC: 0=left, 1=middle, 2=right.
_NUMERIC_BUTTON = {0: "left", 1: "middle", 2: "right"}


def _normalise_button(raw: Any) -> str:
    """Resolve a viewer-supplied button to a CDP button name, tolerating
    BOTH the string form ('left'/'right'/'middle'/'none') AND the numeric
    DOM encoding (0=left, 1=middle, 2=right).

    Why (0.5.10): the viewer was sending the raw DOM `event.button`
    (numeric 0 for a left click). The old string-only lookup turned 0
    into 'none', so CDP got `mousePressed button=none` → Chrome
    synthesised NO click. Hover (no button) and keyboard were unaffected,
    which is exactly why moving + typing worked but nothing was
    clickable.
    """
    if isinstance(raw, bool):  # bool is an int subclass — guard first
        return "none"
    if isinstance(raw, (int, float)):
        return _NUMERIC_BUTTON.get(int(raw), "none")
    if isinstance(raw, str):
        s = raw.strip().lower()
        if s in _MOUSE_BUTTON_MAP:
            return _MOUSE_BUTTON_MAP[s]
        if s.isdigit():
            return _NUMERIC_BUTTON.get(int(s), "none")
    return "none"

# Mouse action → CDP type
_MOUSE_ACTION_MAP = {
    "down": "mousePressed",
    "up": "mouseReleased",
    "move": "mouseMoved",
    "wheel": "mouseWheel",
}

# Keyboard action → CDP type.
_KEY_ACTION_MAP = {
    "down": "keyDown",
    "up": "keyUp",
}

# Windows virtual key codes for non-printable / special keys. CDP
# REQUIRES windowsVirtualKeyCode for these to actually function —
# without it, Backspace doesn't delete, Enter doesn't submit, arrows
# don't move (bug 2026-05-22: keyDown with only key/code was a no-op
# for special keys). Printable chars derive their vk from the char
# itself (uppercase ASCII) so they're not listed here.
_VK_CODES = {
    "Backspace": 8, "Tab": 9, "Enter": 13, "NumpadEnter": 13,
    "ShiftLeft": 16, "ShiftRight": 16, "ControlLeft": 17,
    "ControlRight": 17, "AltLeft": 18, "AltRight": 18,
    "Pause": 19, "CapsLock": 20, "Escape": 27, "Space": 32,
    "PageUp": 33, "PageDown": 34, "End": 35, "Home": 36,
    "ArrowLeft": 37, "ArrowUp": 38, "ArrowRight": 39, "ArrowDown": 40,
    "Insert": 45, "Delete": 46,
    "MetaLeft": 91, "MetaRight": 92,
    "F1": 112, "F2": 113, "F3": 114, "F4": 115, "F5": 116, "F6": 117,
    "F7": 118, "F8": 119, "F9": 120, "F10": 121, "F11": 122, "F12": 123,
}


def _virtual_key_code(key: str, code: str) -> int:
    """Resolve the Windows virtual key code CDP needs.

    Special keys come from _VK_CODES (by `code` then `key`). Printable
    single chars use the uppercase ASCII of the char (e.g. 'a'→65, the
    'A' keycode — the OS keymap, not the shifted char). Digits map to
    their ASCII. Returns 0 when unknown (CDP tolerates 0 for chars that
    don't need a synthetic key event)."""
    if code in _VK_CODES:
        return _VK_CODES[code]
    if key in _VK_CODES:
        return _VK_CODES[key]
    if len(key) == 1:
        ch = key.upper()
        if "A" <= ch <= "Z" or "0" <= ch <= "9":
            return ord(ch)
    return 0


async def apply_input_event(
    cdp: Any,
    event: dict[str, Any],
    *,
    can_open_new_tab: bool = False,
    can_download: bool = False,
    session_id: str | None = None,
) -> bool:
    """Translate one input event dict to a CDP Input.dispatch* call.

    Returns True if dispatched, False if dropped (invalid shape or
    permission denied). Caller may use the return value to count
    dropped events for audit / debug.

    Permissions enforced HERE in addition to page_guard JS:
      - Ctrl/Cmd+T → drop unless can_open_new_tab (belt+suspenders;
        page_guard.js already preventDefaults but defense-in-depth
        catches if JS was somehow bypassed)
      - Ctrl/Cmd+S, Ctrl/Cmd+P → drop unless can_download
      - F12, Ctrl+Shift+I → always drop (HARDCODED can_use_devtools=False)

    session_id MUST be provided for real Chrome (Input.* is session-
    level — Phase 2 fix 2026-05-22). Optional for unit-test doubles.

    Returns False on any failure — never raises, so a malicious
    payload from coworker DataChannel can't bring down the input task.
    """
    if not isinstance(event, dict):
        log.warning("input_replay_event_not_dict")
        return False

    etype = event.get("type")

    if etype == "mouse":
        return await _apply_mouse(cdp, event, session_id=session_id)
    if etype == "key":
        return await _apply_key(
            cdp,
            event,
            can_open_new_tab=can_open_new_tab,
            can_download=can_download,
            session_id=session_id,
        )
    log.info("input_replay_unknown_type", type=etype)
    return False


async def _apply_mouse(
    cdp: Any, event: dict[str, Any], *, session_id: str | None = None
) -> bool:
    action = event.get("action")
    cdp_type = _MOUSE_ACTION_MAP.get(action)
    if cdp_type is None:
        log.info("input_replay_unknown_mouse_action", action=action)
        return False

    x = event.get("x")
    y = event.get("y")
    if not isinstance(x, (int, float)) or not isinstance(y, (int, float)):
        log.info("input_replay_mouse_missing_coords")
        return False

    raw_button = event.get("button")
    button = _normalise_button(raw_button)
    is_click_edge = cdp_type in ("mousePressed", "mouseReleased")
    # A press/release with no resolvable button is meaningless — coerce
    # to left so a click still lands (covers a missing/'none'/unknown
    # button on a click edge). Right/middle still resolve via the map.
    if is_click_edge and button == "none":
        button = "left"
    # clickCount MUST be >= 1 on BOTH mousePressed AND mouseReleased for
    # Chrome to synthesise a click — with clickCount=0 on the release
    # (the pre-0.5.8 bug) the page saw a press + release but no click,
    # so buttons like Gemini's send arrow never fired. Moves/wheels stay
    # at 0 (no click semantics).
    params: dict[str, Any] = {
        "type": cdp_type,
        "x": int(x),
        "y": int(y),
        "button": button,
        "clickCount": (int(event.get("clickCount", 1)) or 1) if is_click_edge else 0,
        # `buttons` bitmask: the button is held during the press, released
        # by the up event.
        "buttons": _MOUSE_BUTTON_BIT.get(button, 0) if cdp_type == "mousePressed" else 0,
        # CDP modifier bitmask (Alt=1, Ctrl=2, Meta=4, Shift=8) so
        # ctrl/cmd/shift+click work. Defaults 0 when absent.
        "modifiers": int(event.get("modifiers", 0)),
    }
    # Wheel events need deltaX/deltaY in addition to the position
    if cdp_type == "mouseWheel":
        params["deltaX"] = int(event.get("deltaX", 0))
        params["deltaY"] = int(event.get("deltaY", 0))

    # Ground-truth diagnostic for click debugging — low frequency (only
    # press/release, never the mousemove flood). Shows what the viewer
    # sent (raw_button) vs what we dispatched (button/coords).
    if is_click_edge:
        log.info(
            "input_replay_mouse_click",
            cdp_type=cdp_type,
            raw_button=raw_button,
            button=button,
            x=int(x),
            y=int(y),
            click_count=params["clickCount"],
        )

    try:
        await cdp.send("Input.dispatchMouseEvent", params, session_id=session_id)
        return True
    except Exception:  # noqa: BLE001
        log.exception("input_replay_mouse_dispatch_failed")
        return False


async def _apply_key(
    cdp: Any,
    event: dict[str, Any],
    *,
    can_open_new_tab: bool,
    can_download: bool,
    session_id: str | None = None,
) -> bool:
    action = event.get("action")
    cdp_type = _KEY_ACTION_MAP.get(action)
    if cdp_type is None:
        log.info("input_replay_unknown_key_action", action=action)
        return False

    key = event.get("key")
    code = event.get("code")
    if not isinstance(key, str) or not isinstance(code, str):
        log.info("input_replay_key_missing_fields")
        return False
    modifiers = int(event.get("modifiers", 0))

    # Permissions enforcement at the dispatcher level (defense-in-depth
    # alongside page_guard.js). Coworker viewer SHOULDN'T send these
    # blocked combos, but if a malicious viewer does, we drop here.
    if _is_blocked_hotkey(
        key=key, code=code, modifiers=modifiers,
        can_open_new_tab=can_open_new_tab,
        can_download=can_download,
    ):
        log.info("input_replay_hotkey_blocked", key=key, code=code)
        return False

    # Printable single char (not "Enter"/"Shift"/"ArrowLeft"/...). For
    # these we set `text` on keyDown so Chrome INSERTS the character —
    # CDP's keyDown-with-text generates the keypress + char in one shot.
    #
    # IMPORTANT (bug 2026-05-22): do NOT also send a separate `char`
    # event. keyDown-with-text already inserts; an extra char event
    # double-types every key ("teste" → "tteessttee"). One event only.
    non_text_mods = modifiers & ~8  # mask Shift (8); keep Alt/Ctrl/Meta
    is_printable_char = len(key) == 1 and non_text_mods == 0
    text = ""
    if is_printable_char:
        text = event.get("text") or key

    vk = _virtual_key_code(key, code)
    params: dict[str, Any] = {
        "type": cdp_type,
        "key": key,
        "code": code,
        "modifiers": modifiers,
        "text": text,
        # Special keys (Backspace/Enter/arrows) are no-ops without the
        # virtual key code; printable chars get their ASCII keycode.
        "windowsVirtualKeyCode": vk,
        "nativeVirtualKeyCode": vk,
    }

    try:
        await cdp.send("Input.dispatchKeyEvent", params, session_id=session_id)
        return True
    except Exception:  # noqa: BLE001
        log.exception("input_replay_key_dispatch_failed")
        return False


def _is_blocked_hotkey(
    *,
    key: str,
    code: str,
    modifiers: int,
    can_open_new_tab: bool,
    can_download: bool,
) -> bool:
    """Return True if this key event matches a blocked combination.

    HARDCODED-blocked (regardless of permissions):
      F12, Ctrl+Shift+I/J/C (devtools), Ctrl+U (view-source),
      Ctrl+O (local file-open dialog), Ctrl+H (history),
      Ctrl+J (downloads page).
    Permission-gated:
      Ctrl+T/N (new tab/window) unless can_open_new_tab;
      Ctrl+S/P (save/print) unless can_download.

    This dispatcher is the REAL chokepoint for the remote renter — they
    have no local keyboard on the owner's machine, so every key arrives
    here via CDP. The page_guard JS keydown handler is defense-in-depth
    only (browser-level shortcuts ignore JS preventDefault).
    """
    # CDP modifier bitmask: alt=1, ctrl=2, meta=4 (Cmd on Mac), shift=8
    ctrl_or_meta = bool(modifiers & (2 | 4))
    shift = bool(modifiers & 8)

    # F12 — HARDCODED
    if key == "F12" or code == "F12":
        return True
    # Ctrl+Shift+I / J / C → DevTools (inspector) — HARDCODED. C is the
    # "inspect element" picker; I/J open the panel/console.
    if ctrl_or_meta and shift and code in ("KeyI", "KeyJ", "KeyC"):
        return True
    # Ctrl+U → view-source — HARDCODED
    if ctrl_or_meta and code == "KeyU":
        return True
    # Ctrl+O → local file-open dialog (lets the renter browse the
    # owner's filesystem) — HARDCODED, never allowed.
    if ctrl_or_meta and code == "KeyO":
        return True
    # Ctrl+H → browsing history (can_view_browser_history is a
    # HARDCODED-FALSE invariant) — block.
    if ctrl_or_meta and code == "KeyH":
        return True
    # Ctrl+J → downloads page (chrome://downloads, a chrome-internals
    # surface; can_access_chrome_internals is HARDCODED-FALSE) — block.
    if ctrl_or_meta and code == "KeyJ":
        return True
    # Permission-gated
    if not can_open_new_tab and ctrl_or_meta and code in ("KeyT", "KeyN"):
        return True
    if not can_download and ctrl_or_meta and code in ("KeyS", "KeyP"):
        return True
    return False
