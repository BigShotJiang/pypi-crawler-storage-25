"""Sprint 1F.4 phase 2.5 — Layer 2 in-page guard installer.

Companion to `page_guard_script.py` (which holds the JS bundle).
This module:

  1. Builds the JS bundle from current permissions
  2. Installs the agent→page communication channel via CDP
     Runtime.addBinding (the page's `window.haonAuditEmit` callable)
  3. Hooks Runtime.bindingCalled events → forwards to monitor.record_*
     or audit_emit
  4. Calls Page.addScriptToEvaluateOnNewDocument so the JS runs on
     EVERY new document (top-level navigation + iframes)
  5. Hooks Page.javascriptDialogOpening → auto-cancel (prevent
     alert/confirm/prompt from blocking the agent or showing to the
     coworker via screencast)

Idempotent: calling apply_page_guards twice on the same CDP client
re-applies the script (Chrome de-dupes silently if script with same
contents is added again).
"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, Awaitable, Callable

from haon_agent.byoc.runtime.browser.page_guard_script import (
    build_page_guard_script,
)


log = logging.getLogger("agent.browser.page_guard")


# Binding name the injected JS calls. The agent registers it via
# Runtime.addBinding; subsequent `window.haonAuditEmit(payload)`
# calls from the page surface as Runtime.bindingCalled events.
_BINDING_NAME = "haonAuditEmit"


async def apply_page_guards(
    cdp: Any,
    *,
    permissions: dict[str, Any],
    on_audit_event: Callable[[str, dict[str, Any]], Awaitable[None]],
    session_id: str | None = None,
) -> asyncio.Task:
    """Install the full Layer 2 page-guard stack.

    session_id MUST be provided for real Chrome (Runtime.*, Page.* are
    session-level — Phase 2 fix 2026-05-22). Optional for unit-test
    mock CDP doubles.

    Returns a background `asyncio.Task` that listens for
    Runtime.bindingCalled events and forwards to `on_audit_event`.
    Caller MUST cancel this task on session teardown (via
    .cancel() + await).

    Order matters:
      1. Runtime.enable + Page.enable (CDP domains we'll use)
      2. Runtime.addBinding(name=haonAuditEmit) — must be BEFORE
         the script runs, else page JS can't call it
      3. Page.addScriptToEvaluateOnNewDocument(source=<JS bundle>)
      4. Start binding listener (background task)
      5. Install Page.javascriptDialogOpening auto-cancel handler
         (also a background task — fires on each dialog open)
    """
    js_source = build_page_guard_script(permissions)

    # Enable required CDP domains. These are idempotent in CDP —
    # calling .enable repeatedly is a no-op past the first call.
    await cdp.send("Runtime.enable", session_id=session_id)
    await cdp.send("Page.enable", session_id=session_id)

    # Install the page→agent binding. After this, the injected JS
    # can call `window.haonAuditEmit(payloadString)`.
    await cdp.send(
        "Runtime.addBinding",
        {"name": _BINDING_NAME},
        session_id=session_id,
    )

    # Register the JS bundle as a "run before any other script in
    # every new document". Chrome 84+ keeps this across navigations
    # (top-level + same-origin/cross-origin frames).
    await cdp.send(
        "Page.addScriptToEvaluateOnNewDocument",
        {"source": js_source},
        session_id=session_id,
    )

    log.info(
        "page_guard_installed",
        extra={
            "permissions_summary": {
                "can_download": bool(permissions.get("can_download", False)),
                "can_open_new_tab": bool(permissions.get("can_open_new_tab", False)),
                "can_screen_record": bool(permissions.get("can_screen_record", False)),
            },
        },
    )

    # Background task: consume Runtime.bindingCalled events and
    # forward to the caller's audit emitter.
    listener_task = asyncio.create_task(
        _binding_listener_loop(
            cdp=cdp, on_audit_event=on_audit_event, session_id=session_id,
        ),
        name="page-guard-binding-listener",
    )

    # Background task: auto-cancel any JS dialogs (alert/confirm/
    # prompt/beforeunload) so a malicious page can't hang the
    # session or expose dialog UI to the coworker.
    asyncio.create_task(
        _dialog_canceller_loop(cdp=cdp, session_id=session_id),
        name="page-guard-dialog-canceller",
    )

    return listener_task


async def _binding_listener_loop(
    *,
    cdp: Any,
    on_audit_event: Callable[[str, dict[str, Any]], Awaitable[None]],
    session_id: str | None = None,
) -> None:
    """Receive Runtime.bindingCalled events forever.

    Each event has shape:
      { name: "haonAuditEmit", payload: "<json string>", executionContextId: ... }

    The injected JS always stringifies the payload (CDP bindings
    only accept string args), so we json-parse here.
    """
    async for ev in cdp.events("Runtime.bindingCalled", session_id=session_id):
        if ev.get("name") != _BINDING_NAME:
            continue
        raw = ev.get("payload")
        if not isinstance(raw, str):
            continue
        try:
            parsed = json.loads(raw)
        except (ValueError, TypeError):
            log.warning("page_guard_binding_payload_not_json", extra={"raw_head": raw[:200]})
            continue
        if not isinstance(parsed, dict):
            continue
        event_type = parsed.get("event_type")
        event_data = parsed.get("event_data") or {}
        if not isinstance(event_type, str) or not isinstance(event_data, dict):
            log.warning("page_guard_binding_payload_malformed")
            continue
        try:
            await on_audit_event(event_type, event_data)
        except Exception:  # noqa: BLE001 — audit callback failure mustn't kill listener
            log.exception("page_guard_audit_emit_failed")


async def _dialog_canceller_loop(*, cdp: Any, session_id: str | None = None) -> None:
    """Auto-cancel JS dialogs.

    Page.javascriptDialogOpening fires before the dialog renders;
    we respond with Page.handleJavaScriptDialog(accept=false). Net
    effect: alert/confirm/prompt return immediately as if user
    dismissed.
    """
    async for ev in cdp.events("Page.javascriptDialogOpening", session_id=session_id):
        try:
            await cdp.send(
                "Page.handleJavaScriptDialog",
                {"accept": False},
                session_id=session_id,
            )
        except Exception:  # noqa: BLE001
            log.exception("page_guard_dialog_cancel_failed")
