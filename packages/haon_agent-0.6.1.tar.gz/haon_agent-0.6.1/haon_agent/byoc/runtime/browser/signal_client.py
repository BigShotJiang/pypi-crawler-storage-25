"""Sprint 1F.4 phase 4 — agent-side signaling WSS client.

Connects to wss://broker.haon.run/v1/byoc/signal/<session_id> with
`Authorization: Bearer <session_token>` and relays JSON frames
between the agent's BrowserWebRTCPeer and the coworker's peer
(broker is dumb pipe).

Wire protocol (matches broker 1F.3 relay handler):
  agent ──► broker ──► coworker, and inverse, for these msg types:
    offer, answer, ice, ready, bye, session_request, session_approve,
    session_deny  (broker forwards all msg types verbatim)

Lifecycle:
    client = SignalClient(url, token, on_message, on_close)
    await client.connect()
    await client.send({"msg": "answer", "sdp": "..."})
    ...
    await client.close()

`on_message(frame: dict)` fires for each parsed JSON frame received
from the opposite peer. `on_close(reason: str)` fires when the WSS
closes (graceful or otherwise). Both are best-effort — exceptions
inside callbacks are caught + logged.
"""

from __future__ import annotations

import asyncio
import json
from typing import Any, Awaitable, Callable

import structlog


log = structlog.get_logger("agent.browser.signal_client")


FrameHandler = Callable[[dict[str, Any]], Awaitable[None]]
CloseHandler = Callable[[str], Awaitable[None]]


# Matches the broker's subprotocols list in main.py — the signaling
# endpoint shares the BYOC subprotocol family.
_SUBPROTOCOL = "byoc.haon.run.v1"


class SignalClient:
    """One signaling WSS connection per Studio session."""

    def __init__(
        self,
        *,
        url: str,
        token: str,
        on_message: FrameHandler,
        on_close: CloseHandler | None = None,
    ) -> None:
        self._url = url
        self._token = token
        self._on_message = on_message
        self._on_close = on_close
        self._ws: Any = None
        self._read_task: asyncio.Task | None = None
        self._closed = False
        # Per-connection send lock — websockets tolerates concurrent
        # writes on most versions but the lock is the defensive contract
        self._send_lock = asyncio.Lock()

    async def connect(self) -> None:
        """Open the WSS. Spawns the background read loop.

        Raises on connection failure — caller (BrowserSession) treats
        a connect failure as a session-fatal error and aborts the
        whole session.
        """
        # Lazy import — websockets is already a dep but keeping the
        # import local matches the codebase's lazy-import style
        from websockets.asyncio.client import connect as _ws_connect

        # Authorization header for the server-side path (Python agent).
        # Browsers use ?token= query string instead — they can't set
        # custom headers via the WebSocket API.
        headers = [("Authorization", f"Bearer {self._token}")]
        log.info("signal_client_connecting", url=self._url)
        self._ws = await _ws_connect(
            self._url,
            additional_headers=headers,
            subprotocols=[_SUBPROTOCOL],
        )
        log.info("signal_client_connected", url=self._url)
        self._read_task = asyncio.create_task(
            self._read_loop(),
            name="signal-client-read",
        )

    async def send(self, frame: dict[str, Any]) -> None:
        """Send a JSON frame to the broker for relay to opposite peer.

        Silently swallows ConnectionClosed — caller will be notified
        via on_close when the WSS officially drops.
        """
        if self._ws is None or self._closed:
            log.warning("signal_client_send_to_closed_ws")
            return
        from websockets.exceptions import ConnectionClosed

        async with self._send_lock:
            try:
                await self._ws.send(json.dumps(frame, ensure_ascii=False))
            except ConnectionClosed:
                log.info("signal_client_send_closed_mid_call")

    async def close(self, *, code: int = 1000, reason: str = "") -> None:
        """Graceful close. Idempotent."""
        if self._closed:
            return
        self._closed = True
        if self._read_task is not None and not self._read_task.done():
            self._read_task.cancel()
            try:
                await self._read_task
            except (asyncio.CancelledError, Exception):  # noqa: BLE001
                pass
        if self._ws is not None:
            try:
                await self._ws.close(code=code, reason=reason)
            except Exception:  # noqa: BLE001
                pass
        await self._fire_close("explicit_close")

    async def _read_loop(self) -> None:
        """Background task — read frames forever until WSS drops."""
        from websockets.exceptions import ConnectionClosed

        try:
            async for raw in self._ws:
                if isinstance(raw, bytes):
                    try:
                        raw = raw.decode("utf-8")
                    except UnicodeDecodeError:
                        log.warning("signal_client_frame_not_utf8")
                        continue
                try:
                    frame = json.loads(raw)
                except (ValueError, TypeError):
                    log.warning("signal_client_frame_not_json")
                    continue
                if not isinstance(frame, dict):
                    continue
                try:
                    await self._on_message(frame)
                except Exception:  # noqa: BLE001 — handler failure mustn't kill the loop
                    log.exception("signal_client_message_handler_failed")
        except ConnectionClosed as exc:
            log.info(
                "signal_client_ws_closed",
                code=getattr(exc, "code", None),
                reason=getattr(exc, "reason", None),
            )
            await self._fire_close("remote_closed")
        except asyncio.CancelledError:
            raise
        except Exception:  # noqa: BLE001
            log.exception("signal_client_read_loop_unexpected")
            await self._fire_close("error")

    async def _fire_close(self, reason: str) -> None:
        if self._on_close is None:
            return
        try:
            await self._on_close(reason)
        except Exception:  # noqa: BLE001
            log.exception("signal_client_close_handler_failed")
