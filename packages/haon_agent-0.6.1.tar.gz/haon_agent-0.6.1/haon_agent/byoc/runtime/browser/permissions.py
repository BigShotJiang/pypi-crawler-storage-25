"""Sprint 1F.4 phase 2 — Studio session permissions.

Permissions arrive in the session_offer frame the broker pushes to the
agent (1F.2 service.start_session populates from haonhub's POST body).
This module:

  1. Defines the SHAPE (Permissions dataclass)
  2. Defines the HARDCODED-FALSE invariants — keys that owner CANNOT
     grant even if they tried. Defense-by-design: the agent strips
     these from any incoming payload BEFORE applying.
  3. Parses + normalises wire payload → Permissions

The HARDCODED-FALSE set is the contract Caio agreed to 2026-05-19:

  can_modify_account            user can't change owner's account
  can_view_browser_history      coworker can't peek at owner's history
  can_access_chrome_internals   chrome://* family blocked at multiple layers
  can_use_devtools              F12 / Inspect element / etc
  can_end_session               only owner ends; coworker just disconnects
  can_screen_record             MediaRecorder + getDisplayMedia override
                                (enforcement in phase 2.5 JS inject; this
                                 phase records intent for audit log)

These are NOT permissions in the "owner can toggle on/off" sense —
they are agent-runtime INVARIANTS. The wire format may include them
(haonhub UI may set them to whatever), but the agent treats those
keys as locked to False. The audit log records any attempted bypass.

Configurable permissions (owner controls per-grant on haonhub UI):
  max_session_min, can_download, can_open_new_tab,
  can_navigate_outside_initial_domain, max_warnings_before_disconnect,
  idle_timeout_min, url_allowlist, url_blocklist
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


# Keys that the agent FORCES to False regardless of wire payload. If
# haonhub sends `can_modify_account: true`, we strip + log + treat as
# False. Owner cannot grant these even by direct API call.
HARDCODED_FALSE_KEYS: frozenset[str] = frozenset({
    "can_modify_account",
    "can_view_browser_history",
    "can_access_chrome_internals",
    "can_use_devtools",
    "can_end_session",
    "can_screen_record",
})


# Default values for the CONFIGURABLE permissions. Used when a key is
# absent from the wire payload. Owners who want stricter values set
# them per-grant on haonhub UI.
_CONFIGURABLE_DEFAULTS: dict[str, Any] = {
    "max_session_min": 60,
    "can_download": False,
    "can_open_new_tab": False,
    "can_navigate_outside_initial_domain": False,
    "max_warnings_before_disconnect": 3,
    "idle_timeout_min": 5,
    "url_allowlist": [],   # empty = no positive list, only blocklist applies
    "url_blocklist": [],   # extra entries beyond HARDCODED_HARD_BLOCK_URLS
}


@dataclass(frozen=True)
class Permissions:
    """Effective permissions for one Studio session.

    Reading order during enforcement:
      1. URL blocklist (Layer 1) — built from HARDCODED defaults +
         url_blocklist + (if url_allowlist non-empty) implicit
         deny-all-other-domains
      2. Session monitor (Layer 3 partial) — idle_timeout_min +
         max_warnings_before_disconnect drive the timer + counter
      3. JS injection (Layer 2 — phase 2.5) — reads can_download,
         can_open_new_tab, can_screen_record to know which JS APIs
         to override

    The HARDCODED-FALSE keys ARE present on the dataclass for explicit
    auditing — code that reads `perms.can_modify_account` gets a
    deterministic False, never the wire payload's claim.
    """

    # Configurable
    max_session_min: int = 60
    can_download: bool = False
    can_open_new_tab: bool = False
    can_navigate_outside_initial_domain: bool = False
    max_warnings_before_disconnect: int = 3
    idle_timeout_min: int = 5
    url_allowlist: list[str] = field(default_factory=list)
    url_blocklist: list[str] = field(default_factory=list)

    # Hardcoded — ALWAYS False, but exposed for explicit read sites
    can_modify_account: bool = False
    can_view_browser_history: bool = False
    can_access_chrome_internals: bool = False
    can_use_devtools: bool = False
    can_end_session: bool = False
    can_screen_record: bool = False


def parse_permissions(
    payload: Any,
    *,
    on_locked_attempted: Any = None,
) -> Permissions:
    """Convert a wire payload (dict) into a validated Permissions.

    Liberal-parse / restrictive-persist policy:
      - Wire is `dict` or rejected
      - Unknown keys are silently dropped (forward-compat with future
        Studio bumps that add permission fields)
      - HARDCODED keys are stripped regardless of value; if they were
        set to True, `on_locked_attempted(key)` callback fires so the
        audit log can record the bypass attempt
      - Configurable keys with wrong type fall back to default + log
      - Missing keys take defaults

    `on_locked_attempted` is optional — used by the session manager to
    emit an audit event when haonhub sends a payload trying to enable
    a hardcoded key (shouldn't happen if haonhub UI is correct, but
    defense-in-depth catches misconfiguration).
    """
    if not isinstance(payload, dict):
        # Empty payload → all defaults (safest assumption)
        return Permissions()

    kwargs: dict[str, Any] = {}

    # Configurable keys — type-check, fall back to default on mismatch
    for key, default in _CONFIGURABLE_DEFAULTS.items():
        if key in payload:
            value = payload[key]
            # List defaults MUST be filtered for string-only members,
            # not assigned verbatim. The naive `isinstance(value, list)`
            # check would let through `[42, None, "good.com"]` because
            # the OUTER container IS a list. Check list FIRST so the
            # filter runs.
            if isinstance(default, list):
                if isinstance(value, list):
                    kwargs[key] = [v for v in value if isinstance(v, str)]
                # else: silently default
            elif isinstance(value, type(default)):
                kwargs[key] = value
            # else: silently default (forward-compat)

    # HARDCODED keys — record bypass attempts then drop. Even if not
    # present in payload, we explicitly set False to override the
    # @dataclass default in case the dataclass shape ever drifts.
    for key in HARDCODED_FALSE_KEYS:
        if key in payload and payload[key] is True and callable(on_locked_attempted):
            try:
                on_locked_attempted(key)
            except Exception:  # noqa: BLE001 — callback must not fail parse
                pass
        kwargs[key] = False

    return Permissions(**kwargs)
