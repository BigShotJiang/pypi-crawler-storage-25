"""Sprint 1F.6 — Studio download capture (file exfil step A).

When the coworker clicks "download" in the remote Chrome, the file lands
on the OWNER's disk. This module routes those downloads into a
session-scoped folder and tracks completion so the file-transfer layer
(webrtc_peer 'file' channel) can ship the bytes back to the coworker.

CDP wiring:
  - Browser.setDownloadBehavior {behavior, downloadPath, eventsEnabled}
    behavior = "allowAndName" when can_download granted, else "deny".
    "allowAndName" saves each file as its GUID (no extension) under
    downloadPath — collision-free. We restore the real name from the
    downloadWillBegin event's suggestedFilename.
    NOTE: Browser.* is BROWSER-level CDP — sent WITHOUT session_id
    (unlike Network/Page/Input which need the page session).
  - Browser.downloadWillBegin {guid, url, suggestedFilename}
  - Browser.downloadProgress {guid, state, receivedBytes, totalBytes}
    state: "inProgress" | "completed" | "canceled"

Security (ST-01 teeth + ST-07):
  - can_download=False → behavior "deny", zero capture.
  - Filenames sanitised (no ../, no /, no absolute paths, no control
    chars) BEFORE they reach the wire or the disk-name mapping.
  - Per-session quota (default 2GB) — refuse beyond.
  - Caller (session) emits an audit event per completed download.
"""

from __future__ import annotations

import asyncio
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Awaitable, Callable

import structlog


log = structlog.get_logger("agent.browser.download_capture")

# Hard cap per session (bytes). Refuse downloads that would push the
# session's cumulative captured bytes past this.
DEFAULT_SESSION_QUOTA_BYTES = 2 * 1024 * 1024 * 1024  # 2 GB

_FILENAME_BAD = re.compile(r"[\x00-\x1f/\\]")  # control chars + path seps


def sanitise_filename(raw: str | None) -> str:
    """Strip anything dangerous from a suggested filename.

    Rejects path traversal (../, absolute paths, separators) and
    control chars. Falls back to 'download' when empty after cleaning.
    Caps length at 200 chars (leave room for filesystem limits).
    """
    if not raw:
        return "download"
    # Take only the basename — kills ../, /abs/path, C:\ etc.
    name = raw.replace("\\", "/").split("/")[-1]
    name = _FILENAME_BAD.sub("", name).strip()
    # Defang leading dots ("..", ".hidden" path tricks)
    name = name.lstrip(".") or "download"
    return name[:200]


@dataclass
class _Download:
    """One in-flight or completed download."""

    guid: str
    suggested_name: str
    url: str = ""
    state: str = "inProgress"  # inProgress | completed | canceled
    received: int = 0
    total: int = 0


# Callback fired when a download reaches "completed". Receives the
# session-scoped Path to the file + the sanitised name. The session
# wires this to the file-transfer layer.
OnCompleteCb = Callable[[Path, str], Awaitable[None]]


@dataclass
class DownloadCapture:
    """Per-session download manager. One instance per BrowserSession."""

    session_id: str
    download_dir: Path
    can_download: bool
    on_complete: OnCompleteCb | None = None
    quota_bytes: int = DEFAULT_SESSION_QUOTA_BYTES

    _by_guid: dict[str, _Download] = field(default_factory=dict)
    _captured_total: int = 0

    async def install(self, cdp: Any) -> None:
        """Configure Chrome download behaviour for this session.

        Browser-level command — NO session_id (see module docstring).
        """
        behavior = "allowAndName" if self.can_download else "deny"
        if self.can_download:
            self.download_dir.mkdir(parents=True, exist_ok=True)
        await cdp.send(
            "Browser.setDownloadBehavior",
            {
                "behavior": behavior,
                "downloadPath": str(self.download_dir),
                "eventsEnabled": True,
            },
        )
        log.info(
            "download_capture_installed",
            session_id=self.session_id,
            behavior=behavior,
            path=str(self.download_dir),
        )

    def on_will_begin(self, params: dict[str, Any]) -> None:
        """Handle Browser.downloadWillBegin — record guid→name."""
        guid = params.get("guid")
        if not guid:
            return
        name = sanitise_filename(params.get("suggestedFilename"))
        self._by_guid[guid] = _Download(
            guid=guid,
            suggested_name=name,
            url=str(params.get("url", ""))[:2048],
        )
        log.info(
            "download_will_begin",
            session_id=self.session_id,
            guid=guid,
            name=name,
        )

    async def on_progress(self, params: dict[str, Any]) -> None:
        """Handle Browser.downloadProgress — fire on_complete when done."""
        guid = params.get("guid")
        if not guid:
            return
        dl = self._by_guid.get(guid)
        if dl is None:
            # Progress for a download we never saw begin — synthesise a
            # minimal record so we don't drop the file silently.
            dl = _Download(guid=guid, suggested_name="download")
            self._by_guid[guid] = dl
        dl.state = str(params.get("state", dl.state))
        dl.received = int(params.get("receivedBytes", dl.received) or 0)
        dl.total = int(params.get("totalBytes", dl.total) or 0)

        if dl.state != "completed":
            return

        # Quota enforcement on completion (we know the real size now).
        if self._captured_total + dl.received > self.quota_bytes:
            log.warning(
                "download_quota_exceeded",
                session_id=self.session_id,
                guid=guid,
                captured_total=self._captured_total,
                this=dl.received,
                quota=self.quota_bytes,
            )
            # Delete the over-quota file; don't transfer.
            self._safe_unlink(self.download_dir / guid)
            return

        self._captured_total += dl.received
        file_path = self.download_dir / guid  # allowAndName saves as GUID
        log.info(
            "download_completed",
            session_id=self.session_id,
            guid=guid,
            name=dl.suggested_name,
            bytes=dl.received,
        )
        if self.on_complete is not None and file_path.exists():
            try:
                await self.on_complete(file_path, dl.suggested_name)
            except Exception:  # noqa: BLE001 — transfer failure mustn't kill the session
                log.exception("download_on_complete_failed", guid=guid)

    def cleanup(self) -> None:
        """Delete the whole session download dir. Idempotent. Called on
        session teardown (watchdog) and after each file-ack."""
        if not self.download_dir.exists():
            return
        for child in self.download_dir.iterdir():
            self._safe_unlink(child)
        try:
            self.download_dir.rmdir()
        except OSError:
            pass  # not empty / race — best-effort
        log.info("download_capture_cleaned", session_id=self.session_id)

    def delete_file(self, guid_or_path: str | Path) -> None:
        """Delete a single transferred file (post file-ack)."""
        p = (
            self.download_dir / guid_or_path
            if isinstance(guid_or_path, str)
            else guid_or_path
        )
        self._safe_unlink(p)

    @staticmethod
    def _safe_unlink(p: Path) -> None:
        try:
            if p.is_file():
                p.unlink()
        except OSError:
            pass
