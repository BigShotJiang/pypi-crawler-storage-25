"""Sprint 1F.4 phase 3 — Chrome screen capture via CDP Page.startScreencast.

CDP emits `Page.screencastFrame` events with base64-encoded JPEG payload
+ a sessionId we must ack via `Page.screencastFrameAck(sessionId=...)`.
Without acking, Chrome stops emitting after ~5 frames.

This module exposes a clean async iterator:

    async for frame_bytes, metadata in stream_screencast(cdp, ...):
        # frame_bytes is raw JPEG, metadata has width/height/offsetTop

Caller (webrtc_peer.py) feeds these into a VideoStreamTrack that
decodes JPEG → YUV frame for the WebRTC video track.

Performance notes:
  - Chrome rate-limits screencast to ~10-30 FPS based on system load
    + the everyNthFrame parameter
  - JPEG at quality=60 for 1280x720 is ~30-100KB per frame
  - Per-frame ack must complete before next frame is sent (CDP backs
    off if too many unacked). We ack from the same task that
    iterates, so the natural back-pressure of the consumer (WebRTC
    encoder) becomes Chrome's emit rate
"""

from __future__ import annotations

import asyncio
import base64
from dataclasses import dataclass
from typing import Any, AsyncIterator

import structlog


log = structlog.get_logger("agent.browser.screencast")


@dataclass(frozen=True)
class ScreencastMetadata:
    """Per-frame info CDP returns alongside the JPEG bytes."""

    offset_top: int      # Vertical offset of the page's visible area
    page_scale_factor: float  # Mostly 1.0 unless user zoomed
    device_width: int
    device_height: int
    scroll_offset_x: float
    scroll_offset_y: float
    timestamp: float     # Chrome's monotonic clock at capture


async def start_screencast(
    cdp: Any,
    *,
    format: str = "jpeg",
    quality: int = 60,
    max_width: int = 1280,
    max_height: int = 720,
    every_nth_frame: int = 1,
    session_id: str | None = None,
) -> None:
    """Send Page.startScreencast to begin emitting frames.

    Must be called after Page.enable. Caller is responsible for
    calling stop_screencast() on session teardown.

    `session_id` routes the CDP command to the page-level session
    attached via CDPClient.attach_session(). Required for real Chrome
    (Page.* is session-level). Phase 2 fix 2026-05-22.

    Defaults chosen for the Studio bring-up:
      format=jpeg: smaller payload than png
      quality=60: balance bandwidth vs. UX clarity
      1280x720: standard 720p for the screen-share aesthetic;
                Chrome scales the actual content to fit
      every_nth_frame=1: Chrome's natural rate (no skipping)
    """
    await cdp.send(
        "Page.startScreencast",
        {
            "format": format,
            "quality": quality,
            "maxWidth": max_width,
            "maxHeight": max_height,
            "everyNthFrame": every_nth_frame,
        },
        session_id=session_id,
    )
    log.info(
        "screencast_started",
        format=format,
        quality=quality,
        max_width=max_width,
        max_height=max_height,
        cdp_session_id=session_id,
    )


async def stop_screencast(cdp: Any, *, session_id: str | None = None) -> None:
    """Idempotent — Chrome accepts repeated stop calls without error."""
    try:
        await cdp.send("Page.stopScreencast", session_id=session_id)
    except Exception:  # noqa: BLE001
        log.exception("screencast_stop_failed")


def subscribe_frames(cdp: Any, *, session_id: str | None = None) -> Any:
    """Eagerly register the Page.screencastFrame subscriber queue.

    MUST be called BEFORE start_screencast() so the first frame Chrome
    emits is captured (and later acked) instead of dropped. Returns a
    queue to pass to iter_frames(). See the long note in
    CDPClient.subscribe() about the deadlock this prevents.
    """
    return cdp.subscribe("Page.screencastFrame", session_id=session_id)


async def iter_frames(
    cdp: Any,
    *,
    session_id: str | None = None,
    queue: Any = None,
) -> AsyncIterator[tuple[bytes, ScreencastMetadata]]:
    """Async iterator over screencast frames.

    Yields (jpeg_bytes, metadata) tuples. Caller MUST consume
    promptly — CDP back-pressures when ack lags, and slow consumers
    will drop Chrome's emit rate but won't crash.

    Each frame is ACK'd to CDP BEFORE yielding so Chrome keeps
    sending. If the consumer raises during processing, CDP has
    already been told "got it" — minor leak of "frames we said we
    processed but didn't" but Chrome doesn't care.

    `queue`: pass a queue from subscribe_frames() (called BEFORE
    start_screencast) to avoid the race where frames emitted during
    ICE negotiation are dropped before recv() starts pulling. If None,
    falls back to lazy cdp.events() subscription (only safe when the
    consumer is already pulling when screencast starts).

    NOTE: there are TWO different "sessionId" concepts here:
      - `session_id` parameter: our CDP page session (routes commands).
      - `frame_session_id`: Chrome's per-screencast-stream id that
        Page.screencastFrameAck requires in the params. Sent BY
        Chrome inside the event payload. Don't confuse them.

    Caller should `start_screencast(cdp)` AFTER subscribe_frames() and
    `stop_screencast(cdp)` after the iterator exits.
    """
    if queue is not None:
        event_source = _drain_queue(cdp, queue, session_id=session_id)
    else:
        event_source = cdp.events("Page.screencastFrame", session_id=session_id)

    async for ev in event_source:
        frame_session_id = ev.get("sessionId")
        data = ev.get("data")
        meta_raw = ev.get("metadata") or {}
        if frame_session_id is None or not isinstance(data, str):
            log.warning("screencast_frame_malformed")
            continue

        # Ack BEFORE yielding so Chrome's emit pipeline doesn't stall.
        # If ack fails we log + skip rather than break the iterator.
        try:
            await cdp.send(
                "Page.screencastFrameAck",
                {"sessionId": frame_session_id},
                session_id=session_id,
            )
        except Exception:  # noqa: BLE001
            log.warning("screencast_frame_ack_failed")
            continue

        try:
            jpeg_bytes = base64.b64decode(data)
        except (ValueError, TypeError):
            log.warning("screencast_frame_b64_decode_failed")
            continue

        metadata = ScreencastMetadata(
            offset_top=int(meta_raw.get("offsetTop", 0)),
            page_scale_factor=float(meta_raw.get("pageScaleFactor", 1.0)),
            device_width=int(meta_raw.get("deviceWidth", 0)),
            device_height=int(meta_raw.get("deviceHeight", 0)),
            scroll_offset_x=float(meta_raw.get("scrollOffsetX", 0.0)),
            scroll_offset_y=float(meta_raw.get("scrollOffsetY", 0.0)),
            timestamp=float(meta_raw.get("timestamp", 0.0)),
        )
        yield jpeg_bytes, metadata


async def _drain_queue(
    cdp: Any, queue: Any, *, session_id: str | None = None
) -> AsyncIterator[dict[str, Any]]:
    """Yield events from a pre-registered subscribe() queue until the
    CDP client closes (sentinel) or the iterator is cancelled.

    Mirrors CDPClient.events() semantics but over a queue that was
    registered EAGERLY (before start_screencast), so no frame is lost
    in the gap between start_screencast and the first recv() pull.
    """
    # Import the close sentinel lazily to avoid a hard module coupling.
    from haon_agent.byoc.runtime.browser.cdp import _SUBSCRIBER_CLOSE

    try:
        while True:
            item = await queue.get()
            if item is _SUBSCRIBER_CLOSE:
                return
            yield item
    finally:
        cdp.unsubscribe("Page.screencastFrame", queue, session_id=session_id)
