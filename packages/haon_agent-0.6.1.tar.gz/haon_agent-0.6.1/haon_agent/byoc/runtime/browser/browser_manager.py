"""Sprint 1F.7 — Singleton Chrome lifecycle manager.

Replaces the old "one fresh Chrome per session" model with ONE dedicated
Chrome process per agent, reused across sessions, with idle-driven
shutdown to free VRAM.

Why:
  - The old launcher hardcoded --remote-debugging-port=9222, so two
    Chromes could never coexist (collide on the port). browser:2 never
    actually worked concurrently.
  - Relaunching Chrome per session is slow (cold start) and wasteful.
  - VRAM/RAM: a Chrome left running idle holds GPU memory; the idle
    watchdog closes the whole process after N minutes of zero sessions.

Model (Option A — single Gemini account, decided 2026-05-22):
  - Lazy launch on first acquire(): `--app=about:blank`, DYNAMIC port
    (--remote-debugging-port=0), persistent isolated --user-data-dir
    (the dedicated profile where the owner's Gemini login lives — the
    DEFAULT browser context, so the login is shared across sessions).
  - slot=1 — one session at a time. The Gemini account is single, so
    two concurrent sessions would collide server-side regardless of
    browser isolation. Concurrency (browser:2) is a future multi-account
    feature → Option B (createBrowserContext + cookie-seed) plugs in
    behind `_context_mode` without a rewrite.
  - acquire(url): reuse the live process, hand the caller the single
    app-window target_id. Caller (BrowserSession) attaches its CDP
    session, applies guards, THEN navigates to `url` (guards active
    before the real page loads).
  - release(): navigate the window back to about:blank (clears the
    previous renter's view — UX hygiene) and arm the idle watchdog.
  - Idle watchdog: 0 active sessions for `idle_timeout_s` → Browser.close
    + kill the process. Next acquire() respawns.

NEVER attaches to the user's personal Chrome — the isolated
--user-data-dir guarantees a separate process tree (ST-01 leak guard).
"""

from __future__ import annotations

import asyncio
from typing import Any

import structlog

from haon_agent.byoc.runtime.browser import launcher
from haon_agent.byoc.runtime.browser.cdp import CDPClient


log = structlog.get_logger("agent.browser.manager")

# Dedicated profile name (under ~/.haon/browser_profiles/). The owner
# logs into Gemini ONCE here; the login persists in this profile's
# default context across sessions.
_SINGLETON_PROFILE = "haon-studio"
_BLANK = "about:blank"
_IDLE_TIMEOUT_S = 600  # 10 min of zero sessions → Browser.close


class BrowserBusyError(RuntimeError):
    """Raised when acquire() is called while a session already holds the
    single slot (slot=1)."""


class BrowserManager:
    """Process-global singleton. Use BrowserManager.instance()."""

    _instance: BrowserManager | None = None

    def __init__(self, *, idle_timeout_s: int = _IDLE_TIMEOUT_S) -> None:
        self._chrome: Any = None          # launcher.LaunchedChrome
        self._cdp: Any = None             # browser-level CDPClient
        self._target_id: str | None = None  # the single app-window target
        self._active = 0                  # active sessions (0 or 1)
        self._lock = asyncio.Lock()
        self._idle_task: asyncio.Task | None = None
        self._idle_timeout_s = idle_timeout_s
        # Swap point for Option B (multi-account, createBrowserContext).
        self._context_mode = "default"    # "default" | "isolated" (future)
        # Which launch mode the LIVE process was started in (None = no
        # process yet). app_mode=True → --app kiosk window (no URL bar /
        # tabs / menu); app_mode=False → ordinary navigable Chrome. A
        # session requesting a different mode forces a relaunch — safe
        # under slot=1 (never two concurrent sessions).
        self._launch_app_mode: bool | None = None

    @classmethod
    def instance(cls) -> BrowserManager:
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    @property
    def active_sessions(self) -> int:
        return self._active

    async def acquire(
        self, start_url: str, *, app_mode: bool = True,
    ) -> tuple[str, str]:
        """Reserve the browser for one session.

        Returns (devtools_ws_url, target_id). The caller connects its own
        CDP to the ws_url, attaches to target_id, applies guards, then
        navigates to start_url.

        `app_mode` selects the window flavour (browser_mode from the
        grant): True → --app kiosk (no URL bar / tabs / menu — the
        "Gemini app" experience); False → ordinary navigable Chrome
        (still gated by nav_guard + url_guard). If the live process was
        launched in the other mode, it's torn down and relaunched.

        Raises BrowserBusyError if a session already holds the slot.
        """
        async with self._lock:
            if self._active >= 1:
                raise BrowserBusyError(
                    "Studio browser slot busy (slot=1, single Gemini "
                    "account). Try again when the current session ends."
                )
            await self._ensure_chrome(app_mode=app_mode)
            self._active += 1
            self._cancel_idle()
            log.info(
                "browser_manager_acquired",
                target_id=self._target_id,
                active=self._active,
            )
            assert self._chrome is not None and self._target_id is not None
            return self._chrome.devtools_ws_url, self._target_id

    async def release(self) -> None:
        """Release the slot. Navigates the window back to about:blank to
        wipe the previous renter's view, then arms the idle watchdog."""
        async with self._lock:
            self._active = max(0, self._active - 1)
            # Clear the view (UX hygiene — next renter doesn't see the
            # last page until they navigate).
            if self._cdp is not None and self._target_id is not None:
                try:
                    sid = await self._cdp.attach_session(self._target_id)
                    await self._cdp.send(
                        "Page.navigate", {"url": _BLANK}, session_id=sid
                    )
                except Exception:  # noqa: BLE001
                    log.warning("browser_manager_blank_nav_failed")
            log.info("browser_manager_released", active=self._active)
            if self._active == 0:
                self._arm_idle()

    async def _ensure_chrome(self, *, app_mode: bool = True) -> None:
        """Lazy launch the singleton, or reuse the live process.

        Reuse requires BOTH a live process AND a matching launch mode —
        a session requesting the other browser_mode forces a relaunch
        (the --app vs ordinary-window distinction is a launch-time flag,
        so it can't be toggled on a running Chrome). slot=1 guarantees
        no concurrent session is using the process when we relaunch.
        """
        if (
            self._chrome is not None
            and self._is_alive()
            and self._launch_app_mode == app_mode
        ):
            return
        # Stale handle (process died) OR mode switch — clean up first.
        await self._teardown_process()
        self._chrome = await launcher.launch_chrome(
            _SINGLETON_PROFILE,
            debug_port=0,            # dynamic — kills the 9222 collision
            start_url=_BLANK,
            app_mode=app_mode,       # Layer 0 kiosk when True
            # Kill any orphaned Chrome holding the dedicated profile so
            # our launch isn't a no-op handoff (0.5.9). The singleton is
            # the sole legitimate owner of this profile.
            ensure_exclusive_profile=True,
        )
        self._launch_app_mode = app_mode
        self._cdp = await CDPClient.connect(self._chrome.devtools_ws_url)
        self._target_id = await self._find_page_target()
        log.info(
            "browser_manager_launched",
            target_id=self._target_id,
            app_mode=app_mode,
            ws=self._chrome.devtools_ws_url[:48],
        )

    async def _find_page_target(self) -> str:
        result = await self._cdp.send("Target.getTargets")
        for t in result.get("targetInfos", []) or []:
            if t.get("type") == "page":
                return t["targetId"]
        raise RuntimeError("singleton Chrome opened no page target")

    def _is_alive(self) -> bool:
        proc = getattr(self._chrome, "process", None)
        return proc is not None and proc.poll() is None

    def _cancel_idle(self) -> None:
        if self._idle_task is not None:
            self._idle_task.cancel()
            self._idle_task = None

    def _arm_idle(self) -> None:
        self._cancel_idle()
        self._idle_task = asyncio.create_task(
            self._idle_watchdog(), name="browser-idle-watchdog"
        )

    async def _idle_watchdog(self) -> None:
        try:
            await asyncio.sleep(self._idle_timeout_s)
        except asyncio.CancelledError:
            return
        async with self._lock:
            if self._active > 0:
                return  # a session arrived during the sleep
            log.info("browser_manager_idle_shutdown")
            await self._teardown_process()

    async def _teardown_process(self) -> None:
        """Close CDP + kill the Chrome process. Frees VRAM."""
        if self._cdp is not None:
            try:
                await self._cdp.send("Browser.close")
            except Exception:  # noqa: BLE001
                pass
            try:
                await self._cdp.close()
            except Exception:  # noqa: BLE001
                pass
            self._cdp = None
        proc = getattr(self._chrome, "process", None)
        if proc is not None and proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=5)
            except Exception:  # noqa: BLE001
                proc.kill()
        self._chrome = None
        self._target_id = None
        self._launch_app_mode = None
