"""Minimal Chrome DevTools Protocol client.

CDP is JSON-RPC over WebSocket. We implement only what the Studio flow
needs:

  - Send commands (Page.startScreencast, Input.dispatchKeyEvent,
    Browser.setDownloadBehavior, Network.setBlockedURLs)
  - Subscribe to events (Page.screencastFrame, Network.requestWillBeSent)
  - Multiplex multiple CDP sessions over one WebSocket via the
    flatten=true attach mode (one tab = one sessionId).

Why a custom client instead of pychrome / pyppeteer / playwright:

  - The agent install size matters (Caio's users install via pip).
    pychrome (~1k LoC, 5+ year stale) is acceptable but unmaintained;
    pyppeteer/playwright are massive (10-50MB+ each, bundles browser
    binaries we don't want)
  - We need ~6 specific CDP methods. A 200-LoC custom client is
    auditable, easy to debug under structlog logging, and uses the
    `websockets` lib we already depend on
  - CDP is a stable contract (Chrome 80+ has unchanged shape for what
    we use); maintenance cost is near zero

CDP target model (Phase 2 fix 2026-05-22 — was crashing in 0.5.1.1):

  Chrome exposes two CDP scopes over WebSocket:

  - **Browser-level** (ws://.../devtools/browser/<id>): supports
    Browser.*, Target.*, Storage.*, SystemInfo.*. Network/Page/Input/
    DOM/Runtime are NOT available here — calling them returns
    `-32601 method not found`.
  - **Session-level**: per-tab/per-page session, obtained via
    `Target.attachToTarget(targetId, flatten=true)`. Returns a
    sessionId. Subsequent commands must include `sessionId` in the
    envelope to route to the page's CDP target.

  CDPClient connects at browser-level. To do anything useful with the
  page (block URLs, inject scripts, screencast), call `attach_session()`
  on a target_id and pass the returned `session_id` to every send() /
  events() that targets a page-level domain. Browser-level commands
  (Target.*, Browser.*) leave `session_id=None`.

  Flatten mode multiplexes multiple sessions over the same WS — the
  server tags every event/response with `sessionId`. Our read loop
  demuxes into per-`(method, session_id)` subscriber queues.

Caveats:
  - One open WebSocket connection per CDPClient instance.
  - No retry/reconnect logic — Chrome restart = client recreate. The
    Studio session is short-lived (15min JWS TTL) so this is fine.
"""

from __future__ import annotations

import asyncio
import contextlib
import json
from dataclasses import dataclass, field
from typing import Any, AsyncIterator

import structlog
from websockets.asyncio.client import connect as ws_connect
from websockets.exceptions import ConnectionClosed


log = structlog.get_logger("agent.browser.cdp")


class CDPError(Exception):
    """Raised when Chrome returns {error: {code, message}} for a command."""

    def __init__(self, code: int, message: str) -> None:
        super().__init__(f"CDP error {code}: {message}")
        self.code = code
        self.message = message


@dataclass
class _PendingCall:
    """Tracks one in-flight command awaiting a response keyed by id."""

    future: asyncio.Future[dict[str, Any]] = field(
        default_factory=lambda: asyncio.get_event_loop().create_future()
    )


class CDPClient:
    """Async CDP client. Use as an async context manager:

        async with await CDPClient.connect(ws_url) as cdp:
            # Browser-level (no sessionId required):
            targets = await cdp.send("Target.getTargets")
            page = next(t for t in targets["targetInfos"] if t["type"] == "page")

            # Attach a session for page-level domains:
            sid = await cdp.attach_session(page["targetId"])

            # Session-level commands route via sessionId:
            await cdp.send("Network.enable", session_id=sid)
            await cdp.send("Page.enable",    session_id=sid)
            async for frame in cdp.events("Page.screencastFrame", session_id=sid):
                ...
    """

    def __init__(self, ws: Any) -> None:
        self._ws = ws
        self._next_id = 1
        self._pending: dict[int, _PendingCall] = {}
        # Event subscribers: (method, session_id) → list of asyncio.Queue.
        # session_id=None for browser-level events (Target.*, Browser.*).
        # Each iterator owns one queue; cleanup on iterator close.
        self._subscribers: dict[
            tuple[str, str | None], list[asyncio.Queue]
        ] = {}
        self._read_task: asyncio.Task | None = None
        self._closed = False

    @classmethod
    async def connect(cls, ws_url: str) -> CDPClient:
        """Open the CDP WebSocket. Caller is responsible for closing
        via the async context manager or .close()."""
        # CDP server doesn't speak subprotocols; pass none. Chrome
        # rejects large frames by default — bump max_size since
        # screencast frames can be ~200KB JPEG.
        ws = await ws_connect(
            ws_url,
            max_size=8 * 1024 * 1024,   # 8MB per frame ceiling
            ping_interval=20,
            ping_timeout=20,
        )
        client = cls(ws)
        client._read_task = asyncio.create_task(
            client._read_loop(),
            name="cdp-read-loop",
        )
        return client

    async def __aenter__(self) -> CDPClient:
        return self

    async def __aexit__(self, *_exc) -> None:
        await self.close()

    async def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        # Fail any pending calls so callers don't hang.
        for pending in list(self._pending.values()):
            if not pending.future.done():
                pending.future.set_exception(
                    CDPError(-1, "CDP client closed")
                )
        self._pending.clear()
        # Close all subscriber queues by sending a sentinel.
        for queues in self._subscribers.values():
            for q in queues:
                with contextlib.suppress(Exception):
                    q.put_nowait(_SUBSCRIBER_CLOSE)
        self._subscribers.clear()
        with contextlib.suppress(Exception):
            await self._ws.close()
        if self._read_task is not None:
            self._read_task.cancel()
            with contextlib.suppress(asyncio.CancelledError, Exception):
                await self._read_task

    async def send(
        self,
        method: str,
        params: dict[str, Any] | None = None,
        *,
        session_id: str | None = None,
    ) -> dict[str, Any]:
        """Send a CDP command and return the result. Raises CDPError if
        Chrome returns an error response.

        Methods are stable strings like "Page.enable", "Page.startScreencast",
        "Input.dispatchKeyEvent". See https://chromedevtools.github.io/devtools-protocol/
        for the full schema.

        session_id:
          - None for browser-level domains (Target.*, Browser.*,
            Storage.*, SystemInfo.*).
          - A sessionId returned by attach_session() for page-level
            domains (Network.*, Page.*, DOM.*, Input.*, Runtime.*).
            Sending a page-level method without session_id will get
            -32601 from Chrome.
        """
        if self._closed:
            raise CDPError(-1, "CDP client is closed")
        cmd_id = self._next_id
        self._next_id += 1
        envelope: dict[str, Any] = {"id": cmd_id, "method": method}
        if params:
            envelope["params"] = params
        if session_id is not None:
            envelope["sessionId"] = session_id
        pending = _PendingCall()
        self._pending[cmd_id] = pending
        try:
            await self._ws.send(json.dumps(envelope, separators=(",", ":")))
        except ConnectionClosed as exc:
            del self._pending[cmd_id]
            raise CDPError(-1, f"WebSocket closed during send: {exc}") from exc
        try:
            response = await pending.future
        finally:
            self._pending.pop(cmd_id, None)
        if "error" in response:
            err = response["error"]
            raise CDPError(
                int(err.get("code", -1)),
                str(err.get("message", "unknown")),
            )
        return response.get("result", {})

    async def attach_session(self, target_id: str) -> str:
        """Attach a CDP session to a target (tab/page) via flatten mode.

        Returns the sessionId you must pass to subsequent page-level
        send/events calls. The session is auto-detached on Chrome
        close or target close; we don't track per-session lifecycle
        explicitly because the BrowserSession owns the whole CDP
        client lifetime.

        flatten=true is required: without it, page-level commands
        return -32601 (method not found) because Chrome routes them
        to the browser-level handler which doesn't know Network/Page/
        Input/DOM/Runtime.
        """
        result = await self.send(
            "Target.attachToTarget",
            {"targetId": target_id, "flatten": True},
        )
        session_id = result.get("sessionId")
        if not session_id:
            raise CDPError(
                -1,
                f"Target.attachToTarget on {target_id!r} returned no sessionId",
            )
        log.info(
            "cdp_session_attached",
            target_id=target_id,
            session_id=session_id,
        )
        return session_id

    async def events(
        self,
        method: str,
        *,
        session_id: str | None = None,
    ) -> AsyncIterator[dict[str, Any]]:
        """Async iterator yielding event `params` dicts for the given
        method. Yields until the client is closed.

        session_id:
          - None for browser-level events.
          - A sessionId from attach_session() for page-level events
            (e.g. Page.frameNavigated, Network.requestWillBeSent).

        Use:
            async for ev in cdp.events("Page.screencastFrame", session_id=sid):
                process(ev)
        """
        queue = self.subscribe(method, session_id=session_id)
        try:
            while True:
                item = await queue.get()
                if item is _SUBSCRIBER_CLOSE:
                    return
                yield item
        finally:
            self.unsubscribe(method, queue, session_id=session_id)

    def subscribe(
        self,
        method: str,
        *,
        session_id: str | None = None,
    ) -> asyncio.Queue:
        """Eagerly register an event subscriber and return its queue.

        Unlike `events()` (a lazy async generator that only registers
        on first __anext__), this registers the queue IMMEDIATELY at
        call time. Critical for screencast: the consumer (aiortc recv)
        starts pulling only after ICE connects (~seconds later), but
        Chrome begins emitting Page.screencastFrame the instant
        Page.startScreencast returns. If no subscriber exists when the
        first frame lands, it's dropped AND never acked — Chrome then
        blocks waiting for the ack and the stream deadlocks (black
        screen, readyState=0). Subscribe BEFORE start_screencast so the
        first frame is queued + later acked.

        Caller MUST drain the queue and call unsubscribe() when done.
        A `_SUBSCRIBER_CLOSE` sentinel is enqueued on client close.
        """
        key = (method, session_id)
        queue: asyncio.Queue = asyncio.Queue()
        self._subscribers.setdefault(key, []).append(queue)
        return queue

    def unsubscribe(
        self,
        method: str,
        queue: asyncio.Queue,
        *,
        session_id: str | None = None,
    ) -> None:
        """De-register a queue obtained from subscribe()."""
        key = (method, session_id)
        queues = self._subscribers.get(key)
        if queues is not None and queue in queues:
            queues.remove(queue)

    async def _read_loop(self) -> None:
        """Demultiplex incoming messages into either a pending future
        (response) or subscriber queues (events). Exits on WS close.

        Flatten-mode envelopes include `sessionId` for session-level
        messages and omit it for browser-level. Event subscribers are
        keyed by (method, session_id) so a Page.frameNavigated event
        for session A doesn't leak to a subscriber on session B.
        """
        try:
            async for raw in self._ws:
                if isinstance(raw, bytes):
                    try:
                        raw = raw.decode("utf-8")
                    except UnicodeDecodeError:
                        log.warning("cdp_frame_not_utf8")
                        continue
                try:
                    msg = json.loads(raw)
                except json.JSONDecodeError:
                    log.warning("cdp_frame_not_json")
                    continue
                if not isinstance(msg, dict):
                    continue
                # Response to a command? id key present.
                if "id" in msg:
                    cmd_id = msg["id"]
                    pending = self._pending.get(cmd_id)
                    if pending is not None and not pending.future.done():
                        pending.future.set_result(msg)
                    continue
                # Event? method + params keys.
                method = msg.get("method")
                params = msg.get("params") or {}
                # sessionId tag (flatten mode); absent for browser-level.
                session_id = msg.get("sessionId")
                if isinstance(method, str):
                    key = (method, session_id)
                    queues = self._subscribers.get(key, [])
                    for q in queues:
                        # Drop if the iterator is too slow rather than
                        # blocking the read loop — events are
                        # best-effort by CDP convention.
                        with contextlib.suppress(asyncio.QueueFull):
                            q.put_nowait(params)
        except ConnectionClosed:
            pass
        finally:
            # Whatever the exit reason, fail pending calls + close
            # subscribers so callers unblock.
            for pending in self._pending.values():
                if not pending.future.done():
                    pending.future.set_exception(
                        CDPError(-1, "CDP read loop terminated")
                    )
            for queues in self._subscribers.values():
                for q in queues:
                    with contextlib.suppress(Exception):
                        q.put_nowait(_SUBSCRIBER_CLOSE)


# Sentinel object used to wake up `events()` iterators when the client
# closes. Comparing by identity (`is`) makes this immune to value
# collisions with real event payloads.
_SUBSCRIBER_CLOSE = object()
