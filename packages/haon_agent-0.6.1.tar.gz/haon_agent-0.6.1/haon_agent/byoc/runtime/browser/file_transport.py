"""Sprint 1F.6 — Studio file transfer (download exfil step B).

Ships a captured download from the owner's disk back to the coworker.
`FileTransport` is the swap point: DataChannel for the MVP (P2P, zero
infra), R2 presigned later for >100MB / async / scale — without
touching the capture or session code.

Wire protocol (DataChannelFileTransport ↔ haonhub viewer):
    1. file-start (JSON text): {id, name, size, mime}   name pre-sanitised
    2. N binary chunks of 16 KB on the 'file' channel (ordered:true)
    3. file-end (JSON text): {id, sha256}
    4. viewer verifies sha256 → auto-saves via <a download=name>
       → sends file-ack (JSON text): {id, ok:true}
    5. agent deletes the file on ack.

Backpressure: pause sending when channel.bufferedAmount > 8 MB, resume
on 'bufferedamountlow' (threshold ~1 MB). Without this, a large file
(50 MB video) overruns the SCTP send buffer and the channel stalls or
drops.
"""

from __future__ import annotations

import abc
import asyncio
import hashlib
import json
from pathlib import Path
from typing import Any

import structlog


log = structlog.get_logger("agent.browser.file_transport")

CHUNK_SIZE = 16 * 1024            # 16 KB per SCTP message (conservative)
BUFFER_HIGH = 8 * 1024 * 1024     # pause sending above 8 MB buffered
BUFFER_LOW = 1 * 1024 * 1024      # resume around 1 MB
MAX_FILE_BYTES = 500 * 1024 * 1024  # 500 MB hard cap per file


class FileTransport(abc.ABC):
    """Abstract file shipper. Implementations: DataChannel (now), R2
    presigned (future)."""

    @abc.abstractmethod
    async def send_file(self, path: Path, name: str, mime: str) -> str | None:
        """Ship `path` to the coworker as `name`. Returns the sha256 hex
        on success, None on failure. MUST NOT raise — log + return None."""
        raise NotImplementedError


def _sha256_file(path: Path) -> tuple[str, int]:
    """Stream the file once → (sha256 hex, size bytes)."""
    h = hashlib.sha256()
    size = 0
    with path.open("rb") as f:
        while True:
            block = f.read(CHUNK_SIZE)
            if not block:
                break
            h.update(block)
            size += len(block)
    return h.hexdigest(), size


class DataChannelFileTransport(FileTransport):
    """Sends files over an aiortc RTCDataChannel ('file', ordered=true).

    The channel is created by the viewer and handed to us by
    webrtc_peer when it opens. One transport per channel; serialises
    concurrent send_file calls with a lock so two downloads don't
    interleave chunks on the same channel.
    """

    def __init__(self, channel: Any) -> None:
        self._channel = channel
        self._send_lock = asyncio.Lock()
        self._drain_event = asyncio.Event()
        self._drain_event.set()
        # Wire backpressure: aiortc fires 'bufferedamountlow' when the
        # buffer drains below bufferedAmountLowThreshold.
        try:
            channel.bufferedAmountLowThreshold = BUFFER_LOW

            @channel.on("bufferedamountlow")
            def _on_low() -> None:
                self._drain_event.set()
        except Exception:  # noqa: BLE001 — older aiortc may lack the event
            log.warning("file_transport_no_bufferedamountlow")

    async def send_file(self, path: Path, name: str, mime: str) -> str | None:
        if not path.is_file():
            log.warning("file_transport_missing", path=str(path))
            return None
        async with self._send_lock:
            return await self._send_locked(path, name, mime)

    async def _send_locked(self, path: Path, name: str, mime: str) -> str | None:
        try:
            sha256, size = await asyncio.get_event_loop().run_in_executor(
                None, _sha256_file, path
            )
        except OSError:
            log.exception("file_transport_hash_failed", path=str(path))
            return None

        if size > MAX_FILE_BYTES:
            log.warning("file_transport_too_large", size=size, name=name)
            return None

        transfer_id = sha256[:16]
        self._send_json({
            "t": "file-start",
            "id": transfer_id,
            "name": name,
            "size": size,
            "mime": mime or "application/octet-stream",
        })

        sent = 0
        try:
            with path.open("rb") as f:
                while True:
                    chunk = f.read(CHUNK_SIZE)
                    if not chunk:
                        break
                    await self._await_drain()
                    self._channel.send(chunk)
                    sent += len(chunk)
        except Exception:  # noqa: BLE001
            log.exception("file_transport_send_failed", name=name, sent=sent)
            return None

        self._send_json({"t": "file-end", "id": transfer_id, "sha256": sha256})
        log.info(
            "file_transport_sent",
            name=name,
            size=size,
            sha256_head=sha256[:12],
        )
        return sha256

    async def _await_drain(self) -> None:
        """Block while the channel's send buffer is over the high mark."""
        try:
            buffered = getattr(self._channel, "bufferedAmount", 0)
        except Exception:  # noqa: BLE001
            buffered = 0
        if buffered > BUFFER_HIGH:
            self._drain_event.clear()
            # Wait for 'bufferedamountlow', with a timeout safety net so
            # a missing event can't deadlock the transfer forever.
            try:
                await asyncio.wait_for(self._drain_event.wait(), timeout=30)
            except asyncio.TimeoutError:
                log.warning("file_transport_drain_timeout")
                self._drain_event.set()

    def _send_json(self, obj: dict[str, Any]) -> None:
        self._channel.send(json.dumps(obj, separators=(",", ":")))
