"""Sprint 1F.4 phase 3 — aiortc VideoStreamTrack subclass.

Wraps a screencast.iter_frames() async iterator and feeds JPEG-decoded
frames into the aiortc VideoStreamTrack via the standard recv()
contract.

Per-frame pipeline:
  1. await frame_iter.__anext__()        → (jpeg_bytes, metadata)
  2. av.open(BytesIO(jpeg_bytes), format='mjpeg').decode(video=0)
     → av.VideoFrame in YUV420P
  3. set pts/time_base via next_timestamp()
  4. return — aiortc's encoder picks up from here

Performance note: JPEG decode + color convert is ~10-20ms per frame
at 1280x720 on a modern CPU. For 15-30 FPS the encode pipeline keeps
up; for higher FPS we'd need a faster source (raw screen capture via
mss/dxgi). MVP-acceptable for the Studio chatbot use case.

Lazy-imports aiortc/av so the module load cost doesn't hit users
without browser runtime.
"""

from __future__ import annotations

import asyncio
import contextlib
import io
from typing import Any, AsyncIterator

import structlog


log = structlog.get_logger("agent.browser.video_track")


# Cached real VideoStreamTrack subclass — built on first use so the
# heavy aiortc import doesn't hit every agent boot (only browser
# runtime needs it).
_real_track_cls: Any = None


def _build_real_track_cls() -> Any:
    """Define + cache the real aiortc-backed track subclass.

    Why a factory instead of a top-level
    `class ScreencastVideoTrack(VideoStreamTrack)`: aiortc is a heavy
    dependency (av/cffi/etc) we don't want to import on plain
    `haon-agent --help` runs. We build the subclass lazily the first
    time a Studio session needs a video track, then cache it.

    Why NOT the old `cls.__bases__ = ...` runtime hack (0.5.1.2 crash):
    aiortc.VideoStreamTrack is a C-backed type with a custom
    tp_dealloc. CPython forbids reassigning __bases__ when the
    deallocator differs from the original base (object) — raising
    `TypeError: __bases__ assignment: 'VideoStreamTrack' deallocator
    differs from 'object'`. Static inheritance via a real subclass
    sidesteps the whole problem.
    """
    global _real_track_cls
    if _real_track_cls is not None:
        return _real_track_cls

    from aiortc import VideoStreamTrack
    from aiortc.mediastreams import MediaStreamError

    class _ScreencastVideoTrack(VideoStreamTrack):
        """aiortc VideoStreamTrack fed by a screencast frame iterator."""

        kind = "video"

        def __init__(
            self, frame_iter: AsyncIterator[tuple[bytes, Any]]
        ) -> None:
            super().__init__()
            self._frame_iter = frame_iter
            self._stopped = False
            self._frame_count = 0
            # Latest frame's device dimensions (DIP/CSS px), read by the
            # input handler to denormalise viewer coords accurately. The
            # screencast frame represents these dims, so nx*device_width
            # maps 1:1 to the CDP mouse coordinate space.
            self.last_device_width: int | None = None
            self.last_device_height: int | None = None

        async def recv(self) -> Any:
            """aiortc calls this in the encoder loop to fetch frames.

            Returns an av.VideoFrame. Blocks (asynchronously) until the
            next screencast frame arrives. If the iterator ends, raises
            MediaStreamError which aiortc handles as track end.
            """
            if self._stopped:
                raise MediaStreamError("track stopped")

            if self._frame_count == 0:
                log.info("video_track_recv_first_call")

            try:
                jpeg_bytes, _meta = await self._frame_iter.__anext__()
            except StopAsyncIteration as exc:
                raise MediaStreamError(
                    "screencast iterator exhausted"
                ) from exc

            # Track the live frame dimensions for input coord mapping.
            if _meta is not None:
                dw = getattr(_meta, "device_width", 0)
                dh = getattr(_meta, "device_height", 0)
                if dw and dh:
                    self.last_device_width = int(dw)
                    self.last_device_height = int(dh)

            frame = await _decode_jpeg_to_frame(jpeg_bytes)
            pts, time_base = await self.next_timestamp()
            frame.pts = pts
            frame.time_base = time_base
            self._frame_count += 1
            if self._frame_count == 1:
                log.info(
                    "video_track_first_frame_emitted",
                    width=getattr(frame, "width", None),
                    height=getattr(frame, "height", None),
                )
            elif self._frame_count % 100 == 0:
                log.info("video_track_frames_emitted", count=self._frame_count)
            return frame

        def stop(self) -> None:
            """Mark stopped so the next recv() raises MediaStreamError,
            then defer to aiortc's stop() for the framework-level
            'ended' notification + cleanup. aiortc's stop() is benign
            to call even if the track never fully started."""
            self._stopped = True
            with contextlib.suppress(Exception):
                super().stop()

    _real_track_cls = _ScreencastVideoTrack
    return _real_track_cls


def ScreencastVideoTrack(
    frame_iter: AsyncIterator[tuple[bytes, Any]],
) -> Any:
    """Factory — returns an aiortc VideoStreamTrack fed by `frame_iter`.

    Kept as a callable with the original `ScreencastVideoTrack(iter)`
    signature so call sites (webrtc_peer.start) are unchanged. Builds
    (and caches) the real aiortc-backed subclass on first call.
    """
    cls = _build_real_track_cls()
    return cls(frame_iter)


async def _decode_jpeg_to_frame(jpeg_bytes: bytes) -> Any:
    """Decode raw JPEG bytes into an av.VideoFrame.

    Runs in a thread pool because PyAV decode is CPU-bound C code
    that blocks the asyncio event loop. For a 720p JPEG this is
    ~5-15ms; pushing to a thread keeps the WebRTC pipeline responsive.
    """
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, _decode_jpeg_sync, jpeg_bytes)


def _decode_jpeg_sync(jpeg_bytes: bytes) -> Any:
    """Sync JPEG → av.VideoFrame. Called from the executor pool."""
    import av
    buf = io.BytesIO(jpeg_bytes)
    container = av.open(buf, format="mjpeg")
    try:
        for frame in container.decode(video=0):
            # aiortc + most WebRTC encoders prefer YUV420P
            return frame.reformat(format="yuv420p")
    finally:
        container.close()
    # Shouldn't happen for a valid JPEG but defend against single-
    # frame containers that decode to nothing
    raise ValueError("JPEG decoded to zero frames")
