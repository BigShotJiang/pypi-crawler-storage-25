"""Chrome process launcher for the Studio browser runtime.

Cross-platform:
  - Windows: Program Files Chrome path (64-bit and 32-bit)
  - macOS:   /Applications/Google Chrome.app/Contents/MacOS/Google Chrome
  - Linux:   `google-chrome` / `google-chrome-stable` / `chromium` on PATH

Profile dir: `~/.haon/browser_profiles/<name>` — persistent across
launches so the user's logged-in session (Gemini Ultra cookies etc)
survives agent restarts. Profile is FRESH on first launch — Chrome
treats the empty dir as a new user, so there are no inherited cookies
from the OS user's main Chrome profile (matches Caio's "perfil virgem"
copy on the haonhub UI).

Debug port: hard-coded to 9222 for now. Multi-profile-concurrent
support (phase 5) will allocate dynamic ports per session.

Readiness check: Chrome takes 100ms-2s to be ready to accept CDP
connections. We poll the JSON endpoint at http://localhost:<port>/json/version
which returns once the DevTools server is up; the response contains
the `webSocketDebuggerUrl` we need for cdp.CDPClient.connect.
"""

from __future__ import annotations

import asyncio
import os
import shutil
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import httpx
import structlog


log = structlog.get_logger("agent.browser.launcher")


class ChromeNotFoundError(Exception):
    """Chrome binary not on PATH or in any of the known install dirs."""


class ChromeStartupError(Exception):
    """Chrome process spawned but DevTools endpoint never became ready."""


@dataclass(frozen=True)
class LaunchedChrome:
    """Result of a successful launch — has everything the CDP client +
    cleanup code need."""

    process: subprocess.Popen
    devtools_ws_url: str        # ws://localhost:<port>/devtools/browser/<id>
    profile_dir: Path
    debug_port: int


# ── Chrome binary discovery ─────────────────────────────────────────────


_WIN_CHROME_PATHS = (
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
)
_MAC_CHROME_PATHS = (
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
)
_LINUX_CHROME_CMDS = (
    "google-chrome",
    "google-chrome-stable",
    "chromium",
    "chromium-browser",
)


def find_chrome_binary() -> Path | None:
    """Return path to Chrome executable, or None if not found.

    Cross-platform discovery — tries:
      1. HAON_CHROME_BINARY env var (operator override)
      2. Platform-specific well-known install paths
      3. shutil.which() on common command names

    Returns None when nothing is found — caller decides whether to raise
    or use a fallback.
    """
    env_override = os.environ.get("HAON_CHROME_BINARY", "").strip()
    if env_override:
        p = Path(env_override)
        if p.is_file():
            return p
        log.warning(
            "browser_chrome_env_override_invalid",
            path=str(env_override),
        )

    if sys.platform == "win32":
        for raw in _WIN_CHROME_PATHS:
            p = Path(raw)
            if p.is_file():
                return p
    elif sys.platform == "darwin":
        for raw in _MAC_CHROME_PATHS:
            p = Path(raw)
            if p.is_file():
                return p
    else:  # linux + everything else
        for name in _LINUX_CHROME_CMDS:
            which = shutil.which(name)
            if which:
                return Path(which)
        # Also try snap path on ubuntu+ (snap chromium symlinks via PATH
        # but operator may have removed PATH override).
        snap_path = Path("/snap/bin/chromium")
        if snap_path.is_file():
            return snap_path

    return None


def has_chrome_installed() -> bool:
    """Light check used by capabilities.detect_runtime_kinds — does not
    actually spawn Chrome, just verifies a binary exists."""
    return find_chrome_binary() is not None


# ── Profile dir management ──────────────────────────────────────────────


def profile_dir_for(profile_name: str) -> Path:
    """Resolve `~/.haon/browser_profiles/<name>` and ensure it exists.

    Names are restricted to a safe charset to prevent path traversal —
    `gemini-ultra` is fine; `../../etc/shadow` is not. We don't try to
    sanitize-and-keep-going; bad names raise loudly.
    """
    if not profile_name or not profile_name.replace("-", "").replace("_", "").isalnum():
        raise ValueError(
            f"profile name {profile_name!r} must be alphanumeric "
            "(plus '-' and '_')"
        )
    home = Path.home()
    target = home / ".haon" / "browser_profiles" / profile_name
    target.mkdir(parents=True, exist_ok=True)
    return target


# ── Launch ──────────────────────────────────────────────────────────────


async def _wait_for_devtools(
    port: int,
    *,
    timeout_seconds: float = 30.0,
) -> str:
    """Poll http://localhost:<port>/json/version until Chrome answers.
    Returns the webSocketDebuggerUrl from the response.

    Why /json/version vs /json: /version is the BROWSER-level endpoint
    that exposes the top-level CDP target (browser-wide commands like
    Target.createTarget). The /json endpoint lists per-tab targets;
    we'll create our own tab via the browser-level CDP session.
    """
    url = f"http://127.0.0.1:{port}/json/version"
    deadline = asyncio.get_event_loop().time() + timeout_seconds
    last_err: Exception | None = None
    async with httpx.AsyncClient(timeout=2.0) as http:
        while asyncio.get_event_loop().time() < deadline:
            try:
                resp = await http.get(url)
                if resp.status_code == 200:
                    body = resp.json()
                    ws_url = body.get("webSocketDebuggerUrl")
                    if isinstance(ws_url, str) and ws_url.startswith("ws://"):
                        return ws_url
                    raise ChromeStartupError(
                        f"DevTools response missing webSocketDebuggerUrl: {body}"
                    )
            except (httpx.ConnectError, httpx.ReadError, httpx.TimeoutException) as exc:
                last_err = exc
            await asyncio.sleep(0.2)
    raise ChromeStartupError(
        f"Chrome DevTools never became ready on :{port} within "
        f"{timeout_seconds}s. Last error: {last_err}"
    )


def _devtools_port_file(profile_dir: Path) -> Path:
    return profile_dir / "DevToolsActivePort"


def kill_chrome_on_profile(profile_dir: Path) -> int:
    """Terminate any Chrome BROWSER process holding the given profile.

    Chrome enforces a single instance per --user-data-dir: launching a
    new chrome.exe against a profile another Chrome already owns makes
    the new process hand off to the existing one and EXIT immediately —
    without opening a debug port or writing DevToolsActivePort. That
    surfaces as "DevToolsActivePort not readable within 30s" on every
    connect when a previous session's Chrome leaked (e.g. the agent
    process died and orphaned its child Chrome).

    The Studio profile is isolated under ~/.haon/browser_profiles/<name>
    and is NEVER used by the user's personal Chrome, so this only ever
    kills our own leaked/orphaned instances — making the singleton
    launch exclusive. Returns the number of browser processes signalled.
    """
    try:
        import psutil
    except ImportError:  # pragma: no cover - psutil is a hard dep
        log.warning("browser_psutil_unavailable_skip_profile_kill")
        return 0

    target = str(profile_dir).replace("\\", "/").rstrip("/").lower()
    victims = []
    for proc in psutil.process_iter(["name", "cmdline"]):
        try:
            name = (proc.info.get("name") or "").lower()
            if "chrome" not in name and "chromium" not in name:
                continue
            cmdline = proc.info.get("cmdline") or []
            # Skip child processes (renderers/gpu/utility) — killing the
            # browser process cascades to them. They carry --type=.
            if any(isinstance(a, str) and a.startswith("--type=") for a in cmdline):
                continue
            for arg in cmdline:
                if not isinstance(arg, str) or not arg.startswith("--user-data-dir="):
                    continue
                val = arg.split("=", 1)[1].replace("\\", "/").rstrip("/").lower()
                if val == target:
                    victims.append(proc)
                    break
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            continue

    for p in victims:
        try:
            p.terminate()
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass
    if victims:
        _gone, alive = psutil.wait_procs(victims, timeout=5)
        for p in alive:
            try:
                p.kill()
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass
        log.info(
            "browser_killed_stale_chrome_on_profile",
            profile=str(profile_dir),
            count=len(victims),
        )
    return len(victims)


def _try_read_port(port_file: Path, after_mtime: float | None) -> int | None:
    """Return a valid port from the file, or None if absent/stale/bad."""
    try:
        if port_file.exists():
            if after_mtime is None or port_file.stat().st_mtime > after_mtime:
                first = port_file.read_text().splitlines()[0].strip()
                port = int(first)
                if port > 0:
                    return port
    except (OSError, ValueError, IndexError):
        return None
    return None


async def _read_devtools_active_port(
    profile_dir: Path,
    *,
    after_mtime: float | None = None,
    process: Any = None,
    timeout_seconds: float = 30.0,
) -> int:
    """Read the port Chrome chose under --remote-debugging-port=0.

    Chrome writes `<profile_dir>/DevToolsActivePort` shortly after
    launch: line 1 = port, line 2 = browser ws path. Poll until it
    appears + parses.

    STALE-FILE GUARD (0.5.7): with a PERSISTENT profile a crashed Chrome
    leaves an old DevToolsActivePort behind. If we read that stale value
    we'd wait on the wrong port forever (the new Chrome picked a
    different one). The caller deletes the file pre-launch; as a
    fallback when the unlink fails (file locked), pass `after_mtime` =
    the pre-launch mtime so we only accept a file the NEW process has
    (re)written.

    HANDOFF FAST-FAIL (0.5.9): if `process` is given and it has already
    exited while no port file appeared, Chrome handed off to an existing
    instance on this profile (single-instance behaviour) and won't ever
    write the file — fail immediately with a clear message instead of
    waiting the full timeout.
    """
    port_file = _devtools_port_file(profile_dir)
    deadline = asyncio.get_event_loop().time() + timeout_seconds
    while asyncio.get_event_loop().time() < deadline:
        port = _try_read_port(port_file, after_mtime)
        if port is not None:
            return port
        if process is not None and process.poll() is not None:
            # Chrome exited before writing the port. Last chance: it may
            # have written then forked-and-exited (rare on Windows).
            port = _try_read_port(port_file, after_mtime)
            if port is not None:
                return port
            raise ChromeStartupError(
                f"Chrome exited (code {process.returncode}) without writing "
                f"DevToolsActivePort in {profile_dir}. It likely handed off "
                f"to an existing Chrome holding this profile. Pass "
                f"ensure_exclusive_profile=True (singleton does) to clear it."
            )
        await asyncio.sleep(0.1)
    raise ChromeStartupError(
        f"DevToolsActivePort not readable in {profile_dir} within "
        f"{timeout_seconds}s (Chrome started but never wrote the port file)."
    )


def _build_chrome_args(
    *,
    chrome_path: Path,
    profile_dir: Path,
    debug_port: int,
    headless: bool = False,
    start_url: str | None = None,
    app_mode: bool = False,
) -> list[str]:
    """Construct argv for Chrome launch.

    Sprint 1F.4 phase 2 — Layer 0 of the Studio security stack lives
    HERE:

      `app_mode=True` + `start_url` → adds `--app=<url>` flag which
      REMOVES the URL bar, tabs, and menu (3-dots). This is THE single
      biggest defense against:
        - User typing chrome://settings into URL bar (URL bar gone)
        - Ctrl+T new tab (no tab management in --app mode)
        - DevTools via menu → More Tools (no menu)
        - "Manage account" via Chrome menu (no menu)

      Without app_mode the function falls back to opening start_url as
      a positional argument (normal Chrome window with full chrome UI).

    Kiosk-flavored flags added in phase 2:
      --disable-features=Translate,MediaRouter,TranslateUI
        Translate: avoid the Translate banner that may leak the
                   coworker session to Google's translation service +
                   adds a UI element we'd have to hide
        MediaRouter: chromecast discovery UI — irrelevant for Studio
                     and one more menu surface to police
      --disable-default-apps
        Avoid Chrome auto-installing/upgrading default apps mid-session

    The DevTools port stays available; --app does NOT close
    --remote-debugging-port so CDP still works. Tested via the phase
    2 smoke (manual).
    """
    args = [
        str(chrome_path),
        f"--user-data-dir={profile_dir}",
        f"--remote-debugging-port={debug_port}",
        "--no-first-run",
        "--no-default-browser-check",
        # Phase 2 kiosk-flavored hardening flags
        "--disable-features=Translate,MediaRouter,TranslateUI",
        "--disable-default-apps",
    ]
    if headless:
        args.append("--headless=new")
    if app_mode and start_url:
        # Layer 0 — Chrome opens this URL as a "Progressive Web App"
        # window: no URL bar, no tabs, no menu. Most casual-user
        # escape routes (typing URLs, Ctrl+T, menu→devtools) die here.
        args.append(f"--app={start_url}")
    elif start_url:
        # Fallback: open as positional URL in normal Chrome chrome.
        # Used for `browser launch` debug runs (operator wants full
        # Chrome UI for diagnostics).
        args.append(start_url)
    return args


async def launch_chrome(
    profile_name: str,
    *,
    debug_port: int = 9222,
    headless: bool = False,
    start_url: str | None = None,
    chrome_path: Path | None = None,
    app_mode: bool = False,
    ensure_exclusive_profile: bool = False,
) -> LaunchedChrome:
    """Spawn Chrome and wait until DevTools is ready.

    Raises:
      ChromeNotFoundError — no Chrome binary found
      ChromeStartupError  — Chrome process started but DevTools never came up

    Caller MUST eventually call .terminate() on the returned
    LaunchedChrome.process to clean up — the Chrome subprocess won't
    exit when the agent process does (POSIX would orphan it to PID 1).
    """
    if chrome_path is None:
        chrome_path = find_chrome_binary()
        if chrome_path is None:
            raise ChromeNotFoundError(
                "Chrome binary not found. Install Google Chrome or set "
                "HAON_CHROME_BINARY env var to its path."
            )

    profile_dir = profile_dir_for(profile_name)
    args = _build_chrome_args(
        chrome_path=chrome_path,
        profile_dir=profile_dir,
        debug_port=debug_port,
        headless=headless,
        start_url=start_url,
        app_mode=app_mode,
    )

    # EXCLUSIVE-PROFILE GUARD (0.5.9): Chrome enforces one instance per
    # --user-data-dir. If a previous session's Chrome leaked (agent died
    # and orphaned it), a new launch hands off to that instance and exits
    # WITHOUT writing DevToolsActivePort → "not readable within 30s" on
    # every connect. Kill any orphan holding the (dedicated, isolated)
    # profile first so our launch actually owns it. Safe — this profile
    # is never the user's personal Chrome.
    if ensure_exclusive_profile:
        try:
            kill_chrome_on_profile(profile_dir)
        except Exception:  # noqa: BLE001 - best-effort cleanup
            log.warning("browser_profile_exclusive_cleanup_failed",
                        profile=profile_name)

    log.info(
        "browser_chrome_launching",
        profile=profile_name,
        debug_port=debug_port,
        binary=str(chrome_path),
    )

    # subprocess.Popen rather than asyncio.create_subprocess_exec because
    # we want a real OS process that survives our event loop iteration
    # without being entangled in the loop. Stderr is captured to /dev/null;
    # Chrome chats a LOT and we don't care.
    # STALE-FILE GUARD (0.5.7): with --remote-debugging-port=0 + a
    # PERSISTENT profile, a previously-crashed Chrome leaves an old
    # DevToolsActivePort behind. Reading that stale port makes us wait on
    # the wrong port → ChromeStartupError, on EVERY launch after a crash.
    # Delete it BEFORE spawning so the readback can only see the value
    # the NEW process writes. If the unlink fails (locked), fall back to
    # an mtime guard so we still ignore the stale contents.
    prelaunch_mtime: float | None = None
    if debug_port == 0:
        port_file = _devtools_port_file(profile_dir)
        try:
            port_file.unlink()
        except FileNotFoundError:
            pass
        except OSError as exc:
            log.warning(
                "browser_devtools_port_unlink_failed",
                profile=profile_name,
                error=str(exc),
            )
            try:
                prelaunch_mtime = port_file.stat().st_mtime
            except OSError:
                prelaunch_mtime = None

    process = subprocess.Popen(
        args,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        stdin=subprocess.DEVNULL,
    )

    # Dynamic port (debug_port=0): Chrome picks a free port and writes it
    # to <profile_dir>/DevToolsActivePort (line 1). Read it back so the
    # singleton BrowserManager never collides on a hardcoded 9222 and can
    # run alongside the user's personal Chrome / a future 2nd context.
    effective_port = debug_port
    if debug_port == 0:
        try:
            effective_port = await _read_devtools_active_port(
                profile_dir, after_mtime=prelaunch_mtime, process=process,
            )
        except Exception:
            process.terminate()
            try:
                process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                process.kill()
            raise

    try:
        ws_url = await _wait_for_devtools(effective_port)
    except Exception:
        # If readiness check failed, kill the process we just spawned so
        # we don't leak a hung Chrome.
        process.terminate()
        try:
            process.wait(timeout=3)
        except subprocess.TimeoutExpired:
            process.kill()
        raise

    log.info(
        "browser_chrome_ready",
        profile=profile_name,
        debug_port=debug_port,
        devtools_ws_url=ws_url[:60] + "...",
    )

    return LaunchedChrome(
        process=process,
        devtools_ws_url=ws_url,
        profile_dir=profile_dir,
        debug_port=debug_port,
    )


def terminate_chrome(launched: LaunchedChrome, *, timeout_seconds: float = 5.0) -> None:
    """Graceful shutdown of a launched Chrome. Use after the session
    ends or on agent exit.

    Tries SIGTERM first (Chrome shuts down clean), escalates to SIGKILL
    after timeout. We swallow exceptions because cleanup must be
    best-effort — agent shutdown should never wedge on a stuck Chrome.
    """
    try:
        if launched.process.poll() is not None:
            return  # already exited
        launched.process.terminate()
        try:
            launched.process.wait(timeout=timeout_seconds)
        except subprocess.TimeoutExpired:
            log.warning(
                "browser_chrome_terminate_timeout",
                pid=launched.process.pid,
            )
            launched.process.kill()
            try:
                launched.process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                pass
    except Exception:  # noqa: BLE001 — cleanup is best-effort
        log.exception(
            "browser_chrome_terminate_failed",
            pid=getattr(launched.process, "pid", None),
        )
