"""Sprint 1F.4 phase 3 — WebRTC peer wiring (aiortc).

`BrowserWebRTCPeer` wraps an aiortc RTCPeerConnection with:
  - VideoStreamTrack consuming JPEG frames from screencast.iter_frames()
    (decoded via PyAV/av MJPEG codec → av.VideoFrame for the encoder)
  - DataChannel on label "input" that the coworker side opens; each
    message is a JSON input event dispatched via input_replay
  - State change listener that emits audit events on
    connectionstatechange (new, connecting, connected, disconnected,
    failed, closed) and iceconnectionstatechange

API (consumed by phase 4 signaling glue):

    peer = BrowserWebRTCPeer(cdp=cdp, permissions=perms,
                             ice_servers=stun_urls,
                             audit_emit=audit_cb,
                             on_state_change=disconnect_cb)
    await peer.start()                  # starts screencast + RTCPC
    answer_sdp = await peer.apply_remote_offer(offer_sdp)
    await peer.add_ice_candidate(candidate_dict)
    ...
    await peer.close()                  # stops screencast + closes pc

This module DOES NOT touch the signaling WSS — that lives in phase 4.
"""

from __future__ import annotations

import asyncio
import io
import json
import time
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable

import structlog

from haon_agent.byoc.runtime.browser import (
    input_replay,
    screencast as _screencast,
)
from haon_agent.byoc.runtime.browser.file_transport import (
    DataChannelFileTransport,
)


log = structlog.get_logger("agent.browser.webrtc_peer")


# Type aliases for callbacks the caller (signaling glue / session
# manager) provides.
AuditEmitter = Callable[[str, dict[str, Any]], Awaitable[None]]
StateChangeHandler = Callable[[str, dict[str, Any]], Awaitable[None]]


@dataclass
class _PeerState:
    """Mutable state grouped on a single object — easier than threading
    nullable instance attrs through every method."""

    pc: Any | None = None                # aiortc RTCPeerConnection
    video_track: Any | None = None       # ScreencastVideoTrack
    data_channel: Any | None = None      # aiortc RTCDataChannel (viewer 'input')
    bootstrap_channel: Any | None = None  # SCTP-glue channel (agent-created)
    file_channel: Any | None = None       # viewer 'file' channel (downloads)
    file_transport: Any | None = None     # DataChannelFileTransport
    screencast_task: asyncio.Task | None = None
    closed: bool = False


class BrowserWebRTCPeer:
    """One Studio session's WebRTC connection. Caller (phase 4 session
    manager) instantiates per session_offer + drives the signaling
    handshake.

    Permissions are passed in so input_replay can enforce them at the
    dispatcher level (defense-in-depth alongside the page_guard JS).
    """

    def __init__(
        self,
        *,
        cdp: Any,
        permissions: dict[str, Any],
        ice_servers: list[dict[str, Any]] | None = None,
        audit_emit: AuditEmitter | None = None,
        on_state_change: StateChangeHandler | None = None,
        cdp_session_id: str | None = None,
        on_file_ack: Callable[[str, bool], Awaitable[None]] | None = None,
        on_input: Callable[[], None] | None = None,
    ) -> None:
        self._cdp = cdp
        # Called when the viewer ACKs a received file: (transfer_id, ok).
        # Session wires this to DownloadCapture cleanup.
        self._on_file_ack = on_file_ack
        # Called (sync) on every rate-allowed coworker input event.
        # Session wires this to SessionMonitor.record_input so the idle
        # watchdog actually resets on activity (ST-01 / 0.5.4 fix).
        self._on_input = on_input
        # CDP page-level session attached by BrowserSession.start().
        # Required for Page.*/Input.* commands — Phase 2 fix 2026-05-22.
        self._cdp_session_id = cdp_session_id
        self._permissions = permissions
        self._ice_servers = ice_servers or [
            {"urls": ["stun:stun.cloudflare.com:3478"]},
        ]
        self._audit_emit = audit_emit
        self._on_state_change = on_state_change
        self._state = _PeerState()
        # Cache the input perms once — input_replay calls happen hot
        # path, no point re-reading every event
        self._can_open_new_tab = bool(
            permissions.get("can_open_new_tab", False)
        )
        self._can_download = bool(permissions.get("can_download", False))
        # Chrome visual viewport (CSS px), cached in start() — used to
        # denormalise the viewer's 0..1 input coordinates.
        self._viewport_w: float | None = None
        self._viewport_h: float | None = None
        # Input rate-limit state (NEW-CRIT-1).
        self._last_move_ts = 0.0
        self._bucket = 300.0          # token bucket: 300 events
        self._bucket_ts = time.monotonic()
        self._rate_warn_ts = 0.0

    # ── Public API ──────────────────────────────────────────────────

    async def start(self) -> None:
        """Initialise the RTCPeerConnection + video track + start the
        screencast pipeline. Idempotent within a session lifetime.
        """
        if self._state.pc is not None:
            return

        # Lazy import — aiortc + av are heavy; users without browser
        # runtime shouldn't pay the import cost at agent boot.
        from aiortc import RTCConfiguration, RTCIceServer, RTCPeerConnection

        rtc_ice_servers = [
            RTCIceServer(
                urls=server.get("urls", []),
                username=server.get("username"),
                credential=server.get("credential"),
            )
            for server in self._ice_servers
        ]
        config = RTCConfiguration(iceServers=rtc_ice_servers)
        pc = RTCPeerConnection(configuration=config)
        self._state.pc = pc

        # State change listeners — feed audit + on_state_change hook.
        @pc.on("connectionstatechange")
        async def _on_conn_state() -> None:
            state = pc.connectionState
            log.info(
                "webrtc_connection_state",
                state=state,
            )
            await self._emit_audit(
                "webrtc_state",
                {"kind": "connection", "state": state},
            )
            if self._on_state_change is not None:
                try:
                    await self._on_state_change(state, {"kind": "connection"})
                except Exception:  # noqa: BLE001
                    log.exception("webrtc_state_handler_failed")

        @pc.on("iceconnectionstatechange")
        async def _on_ice_state() -> None:
            state = pc.iceConnectionState
            log.info("webrtc_ice_state", state=state)
            await self._emit_audit(
                "webrtc_state",
                {"kind": "ice", "state": state},
            )

        # DataChannel input handler. The viewer (studio-session.js) may
        # send input events on EITHER:
        #   - a channel it creates (`createDataChannel('input')`), which
        #     fires this pc.on('datachannel') on our side, OR
        #   - the agent-created bootstrap channel '_haon_sctp' that it
        #     picked up via its own ondatachannel (observed in prod
        #     2026-05-22 — viewer captured the first channel it saw).
        # So we attach the SAME message handler to ANY incoming channel
        # AND to the bootstrap channel (below). _translate_input ignores
        # non-input payloads, so over-attaching is harmless.
        @pc.on("datachannel")
        def _on_datachannel(channel: Any) -> None:
            log.info("webrtc_datachannel_opened", label=channel.label)
            if channel.label == "file":
                # Dedicated reliable channel for download forwarding.
                # Viewer creates it ordered:true. We ship file bytes
                # here; viewer sends file-ack JSON back.
                self._setup_file_channel(channel)
            else:
                # input / bootstrap — over-attach is safe (non-input
                # payloads ignored by _translate_input).
                self._attach_input_handler(channel)

        # Add video track — uses screencast as source.
        from haon_agent.byoc.runtime.browser._video_track import (
            ScreencastVideoTrack,
        )
        # CRITICAL ordering (fix 2026-05-22, black-screen bug):
        # 1. Subscribe to Page.screencastFrame EAGERLY first. aiortc
        #    only starts pulling recv() after ICE connects (~6s later);
        #    if we start the screencast before a subscriber exists, the
        #    first frame is dropped + never acked, and Chrome blocks
        #    waiting for that ack → permanent black screen (readyState=0,
        #    zero inbound-rtp).
        # 2. THEN start the screencast so frames land in the queue.
        # 3. iter_frames drains that pre-registered queue + acks each.
        frame_queue = _screencast.subscribe_frames(
            self._cdp, session_id=self._cdp_session_id
        )
        await _screencast.start_screencast(
            self._cdp, session_id=self._cdp_session_id
        )
        frame_iter = _screencast.iter_frames(
            self._cdp,
            session_id=self._cdp_session_id,
            queue=frame_queue,
        )
        track = ScreencastVideoTrack(frame_iter)
        self._state.video_track = track
        pc.addTrack(track)

        # SCTP bootstrap (fix 2026-05-22, input DataChannel never opened):
        # The agent is the OFFERER. If the offer SDP has no m=application
        # section, the viewer's `pc.createDataChannel('input')` can never
        # negotiate — there's no SCTP transport, so the channel stays in
        # 'connecting' and the viewer logs "DataChannel FECHOU" without an
        # OPEN. Creating ANY datachannel here forces the m=application line
        # into the offer; the viewer's 'input' channel then opens in-band
        # over the same SCTP association and our pc.on('datachannel')
        # handler (below) fires for it. We don't send on the bootstrap
        # channel — it's pure SCTP glue.
        bootstrap = pc.createDataChannel("_haon_sctp")
        self._state.bootstrap_channel = bootstrap
        # Viewer may send input on the bootstrap channel (see note above).
        self._attach_input_handler(bootstrap)

        # Cache the Chrome visual viewport so we can denormalise the
        # viewer's 0..1 input coordinates into CSS pixels for CDP. Query
        # once at start; the --app window is fixed-size so it won't drift.
        try:
            metrics = await self._cdp.send(
                "Page.getLayoutMetrics", session_id=self._cdp_session_id
            )
            vp = metrics.get("cssVisualViewport") or metrics.get("cssLayoutViewport") or {}
            self._viewport_w = float(vp.get("clientWidth") or 0) or None
            self._viewport_h = float(vp.get("clientHeight") or 0) or None
            log.info(
                "webrtc_input_viewport_cached",
                width=self._viewport_w,
                height=self._viewport_h,
            )
        except Exception:  # noqa: BLE001
            self._viewport_w = None
            self._viewport_h = None
            log.warning("webrtc_input_viewport_query_failed")

        log.info("webrtc_peer_started")

    async def create_offer(self) -> str:
        """Agent is the offerer (Sprint 1F.4 phase 4.5 wire alignment
        with haonhub viewer — coworker side is answerer per Caio's
        studio-session.js).

        Agent has the video track (Chrome screencast); it's the
        natural side to drive the negotiation. Caller (signaling glue)
        sends the returned SDP via the signal WSS as
        `{type:"offer", sdp:...}` and awaits `{type:"answer", sdp}`
        before calling apply_remote_answer.
        """
        pc = self._require_pc()
        offer = await pc.createOffer()
        await pc.setLocalDescription(offer)
        return pc.localDescription.sdp

    async def apply_remote_answer(self, answer_sdp: str) -> None:
        """Caller feeds us the coworker's SDP answer (received via
        signal WSS). Once setRemoteDescription completes, the
        peer connection should converge to `connected` after ICE
        gathering — both sides have full SDP context.
        """
        from aiortc import RTCSessionDescription

        pc = self._require_pc()
        answer = RTCSessionDescription(sdp=answer_sdp, type="answer")
        await pc.setRemoteDescription(answer)

    async def apply_remote_offer(self, offer_sdp: str) -> str:
        """Legacy answerer-path. Kept for tests + potential perfect-
        negotiation use case where either side may offer. Today's
        production flow uses create_offer + apply_remote_answer.
        """
        from aiortc import RTCSessionDescription

        pc = self._require_pc()
        offer = RTCSessionDescription(sdp=offer_sdp, type="offer")
        await pc.setRemoteDescription(offer)
        answer = await pc.createAnswer()
        await pc.setLocalDescription(answer)
        return pc.localDescription.sdp

    async def add_ice_candidate(self, candidate_dict: dict[str, Any]) -> None:
        """Add a remote ICE candidate (arrived via signaling WSS).

        Shape per WebRTC spec: { candidate: "candidate:...", sdpMid:
        "0", sdpMLineIndex: 0 }. We accept either format and convert
        via aiortc's helper.
        """
        from aiortc.contrib.signaling import object_from_string
        from aiortc import RTCIceCandidate

        pc = self._require_pc()
        # aiortc's RTCIceCandidate takes the constituent fields; if
        # the caller already parsed the candidate-line we use it,
        # otherwise we let aiortc parse via the helper.
        if "candidate" in candidate_dict and isinstance(
            candidate_dict["candidate"], str
        ):
            # Parse the candidate string into an RTCIceCandidate
            from aiortc.sdp import candidate_from_sdp
            candidate = candidate_from_sdp(
                candidate_dict["candidate"].replace("candidate:", "", 1)
            )
            candidate.sdpMid = candidate_dict.get("sdpMid")
            candidate.sdpMLineIndex = candidate_dict.get("sdpMLineIndex")
            await pc.addIceCandidate(candidate)

    async def close(self) -> None:
        """Stop screencast + close RTCPC. Idempotent."""
        if self._state.closed:
            return
        self._state.closed = True
        try:
            if self._state.video_track is not None:
                self._state.video_track.stop()
        except Exception:  # noqa: BLE001
            pass
        try:
            await _screencast.stop_screencast(
                self._cdp, session_id=self._cdp_session_id
            )
        except Exception:  # noqa: BLE001
            pass
        if self._state.pc is not None:
            try:
                await self._state.pc.close()
            except Exception:  # noqa: BLE001
                pass

    # ── Internals ───────────────────────────────────────────────────

    def _require_pc(self) -> Any:
        if self._state.pc is None:
            raise RuntimeError("BrowserWebRTCPeer.start() must be called first")
        return self._state.pc

    def _attach_input_handler(self, channel: Any) -> None:
        """Wire a channel's 'message' event to the input dispatcher.

        Attached to BOTH the agent-created bootstrap channel and any
        viewer-created channel, because the viewer has been observed
        sending input on either one. Idempotent enough — aiortc allows
        multiple on('message') handlers but we only register one per
        channel object.
        """
        # Remember the most recently-opened channel for outbound (none
        # today, but useful for future agent→viewer messages).
        self._state.data_channel = channel

        @channel.on("message")
        async def _on_message(raw: Any) -> None:
            await self._handle_input_message(raw)

    def _setup_file_channel(self, channel: Any) -> None:
        """Wire the viewer-created 'file' channel: build the transport
        for outbound download bytes + listen for file-ack JSON."""
        self._state.file_channel = channel
        self._state.file_transport = DataChannelFileTransport(channel)
        log.info("webrtc_file_channel_ready")

        @channel.on("message")
        async def _on_file_msg(raw: Any) -> None:
            # The viewer only ever sends control JSON here (file-ack);
            # binary flows agent→viewer. Ignore anything non-JSON.
            if isinstance(raw, (bytes, bytearray)):
                return
            try:
                msg = json.loads(raw)
            except (ValueError, TypeError):
                return
            if not isinstance(msg, dict) or msg.get("t") != "file-ack":
                return
            transfer_id = msg.get("id")
            ok = bool(msg.get("ok"))
            log.info("webrtc_file_ack", transfer_id=transfer_id, ok=ok)
            if self._on_file_ack is not None and isinstance(transfer_id, str):
                try:
                    await self._on_file_ack(transfer_id, ok)
                except Exception:  # noqa: BLE001
                    log.exception("webrtc_file_ack_handler_failed")

    async def send_file(self, path: Any, name: str, mime: str) -> str | None:
        """Ship a captured download to the coworker via the file
        transport. Returns sha256 hex on success, None otherwise.

        No-op (returns None) if the viewer never opened a 'file'
        channel — the download stays on the owner's disk for cleanup.
        """
        transport = self._state.file_transport
        if transport is None:
            log.warning("webrtc_send_file_no_channel", name=name)
            return None
        return await transport.send_file(path, name, mime)

    async def _handle_input_message(self, raw: Any) -> None:
        """Parse one input event from the viewer DataChannel + dispatch
        via input_replay. Garbage payloads silently dropped.

        Wire format from haonhub studio-session.js (the answerer):
            { t: 'mousedown'|'mouseup'|'mousemove'|'wheel'|'keydown'|'keyup',
              x, y,                # normalised 0..1 relative to video
              button,              # 'left'|'right'|'middle'
              deltaX, deltaY,      # wheel only
              key, code,           # keyboard
              ctrl, alt, shift, meta }  # modifier booleans

        We translate that into the internal input_replay shape
        ({type, action, x(abs), y(abs), button, modifiers, ...}) and
        denormalise coordinates against the cached Chrome viewport.
        """
        if isinstance(raw, bytes):
            try:
                raw = raw.decode("utf-8")
            except UnicodeDecodeError:
                log.warning("webrtc_input_not_utf8")
                return
        try:
            msg = json.loads(raw)
        except (ValueError, TypeError):
            log.warning("webrtc_input_not_json")
            return
        if not isinstance(msg, dict):
            log.warning("webrtc_input_not_dict")
            return

        # NEW-CRIT-1: rate-limit. A malicious/buggy viewer can flood
        # thousands of events/s → each becomes a CDP dispatch → saturates
        # the owner's REAL hardware. Two layers:
        #   - mousemove coalescing: at most 1 move per 16ms (~60fps).
        #     Moves are the dominant flood vector and the latest position
        #     is all that matters.
        #   - token bucket on everything else: 300 events/s sustained.
        if not self._rate_allow(msg.get("t")):
            return

        # Idle-timer reset (ST-01 / 0.5.4): any rate-allowed input from
        # the coworker counts as activity — including blocked hotkeys,
        # which are still "the renter is here". record_input is sync +
        # cheap (single timestamp write).
        if self._on_input is not None:
            try:
                self._on_input()
            except Exception:  # noqa: BLE001
                log.exception("webrtc_on_input_hook_failed")

        # NEW-CRIT-3: audit discrete input (not every mousemove). Gives a
        # forensic trail for marketplace disputes. Skip moves (noise) +
        # never log key `text` (could be a password).
        self._maybe_audit_input(msg)

        event = self._translate_input(msg)
        if event is None:
            return

        await input_replay.apply_input_event(
            self._cdp,
            event,
            can_open_new_tab=self._can_open_new_tab,
            can_download=self._can_download,
            session_id=self._cdp_session_id,
        )

    def _rate_allow(self, t: Any) -> bool:
        """Return True if this event may proceed.

        CRITICAL events — mousedown/up + keydown/up — are NEVER throttled
        (0.5.8): dropping a click or keystroke breaks the session, and
        they're low-frequency by nature. Only the flood vectors are
        rate-limited: mousemove is coalesced to ~60fps, and mousemove/
        wheel share a 300/s token bucket as a backstop. Previously the
        bucket covered ALL events, so a mousemove burst could drain it
        and silently drop the user's mousedown/up → clicks vanished.
        """
        now = time.monotonic()
        if t in ("mousedown", "mouseup", "keydown", "keyup"):
            return True
        # mousemove coalescing
        if t == "mousemove":
            if now - self._last_move_ts < 0.016:
                return False
            self._last_move_ts = now
        # token bucket (300/s, burst 300) — non-critical events only
        elapsed = now - self._bucket_ts
        self._bucket_ts = now
        self._bucket = min(300.0, self._bucket + elapsed * 300.0)
        if self._bucket < 1.0:
            # Throttle the warning itself (once per second max).
            if now - self._rate_warn_ts > 1.0:
                self._rate_warn_ts = now
                log.warning("webrtc_input_rate_limited")
            return False
        self._bucket -= 1.0
        return True

    def _maybe_audit_input(self, msg: dict[str, Any]) -> None:
        """Emit an audit event for discrete input (clicks, keydown). Skips
        mousemove. Never logs key text (password safety)."""
        if self._audit_emit is None:
            return
        t = msg.get("t")
        if t in ("mousemove",):
            return
        data: dict[str, Any] = {"t": t}
        if t in ("mousedown", "mouseup", "wheel"):
            data["button"] = msg.get("button")
        elif t in ("keydown", "keyup"):
            # `code` is the physical key (KeyA), safe. `key` for a single
            # printable char could be password text → only log code +
            # whether modifiers were held, NOT the char itself.
            data["code"] = msg.get("code")
            data["mods"] = {
                k: bool(msg.get(k)) for k in ("ctrl", "alt", "shift", "meta")
                if msg.get(k)
            }
        # Fire-and-forget; never block input on audit.
        try:
            asyncio.create_task(self._emit_audit("studio_input", data))
        except Exception:  # noqa: BLE001
            pass

    def _translate_input(self, msg: dict[str, Any]) -> dict[str, Any] | None:
        """viewer wire format → input_replay internal format. Returns
        None if the message isn't a recognised input event."""
        t = msg.get("t")
        # CDP modifier bitmask: Alt=1, Ctrl=2, Meta/Cmd=4, Shift=8.
        modifiers = 0
        if msg.get("alt"):
            modifiers |= 1
        if msg.get("ctrl"):
            modifiers |= 2
        if msg.get("meta"):
            modifiers |= 4
        if msg.get("shift"):
            modifiers |= 8

        mouse_t = {
            "mousedown": "down",
            "mouseup": "up",
            "mousemove": "move",
            "wheel": "wheel",
        }
        key_t = {"keydown": "down", "keyup": "up"}

        if t in mouse_t:
            x, y = self._denormalise(msg.get("x"), msg.get("y"))
            if x is None or y is None:
                return None
            event: dict[str, Any] = {
                "type": "mouse",
                "action": mouse_t[t],
                "x": x,
                "y": y,
                "button": msg.get("button", "left" if t != "mousemove" else "none"),
                "clickCount": int(msg.get("clickCount", 1)),
                "modifiers": modifiers,
            }
            if t == "wheel":
                event["deltaX"] = int(msg.get("deltaX", 0))
                event["deltaY"] = int(msg.get("deltaY", 0))
            return event

        if t in key_t:
            return {
                "type": "key",
                "action": key_t[t],
                "key": msg.get("key", ""),
                "code": msg.get("code", ""),
                "text": msg.get("text", ""),
                "modifiers": modifiers,
            }

        log.info("webrtc_input_unknown_type", t=t)
        return None

    def _denormalise(
        self, nx: Any, ny: Any
    ) -> tuple[int | None, int | None]:
        """Map normalised 0..1 coords to CDP CSS pixels.

        Priority of coordinate space (most → least accurate):
          1. The LIVE screencast frame's device dimensions (the exact
             image the viewer normalised against). These are in DIP =
             CSS px, matching Input.dispatchMouseEvent's space 1:1.
          2. The viewport cached via Page.getLayoutMetrics at start().
          3. The 1280x720 screencast bounds fallback.

        Using the live frame dims fixes the click-precision drift
        (bug 2026-05-22: hovering 'Videos' selected 'Prioritizing' —
        the cached viewport didn't match the actual frame the viewer
        sees, especially for the narrow --app window)."""
        if not isinstance(nx, (int, float)) or not isinstance(ny, (int, float)):
            return None, None

        track = self._state.video_track
        w = (
            getattr(track, "last_device_width", None)
            or self._viewport_w
            or 1280.0
        )
        h = (
            getattr(track, "last_device_height", None)
            or self._viewport_h
            or 720.0
        )
        # Clamp to [0,1] defensively — a malicious viewer can't push
        # coords outside the page.
        cx = max(0.0, min(1.0, float(nx)))
        cy = max(0.0, min(1.0, float(ny)))
        return int(cx * w), int(cy * h)

    async def _emit_audit(self, event_type: str, event_data: dict[str, Any]) -> None:
        if self._audit_emit is None:
            return
        try:
            await self._audit_emit(event_type, event_data)
        except Exception:  # noqa: BLE001
            log.exception("webrtc_audit_emit_failed")
