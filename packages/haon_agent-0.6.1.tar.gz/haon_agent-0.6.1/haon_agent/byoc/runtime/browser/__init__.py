"""Browser runtime — owner shares a Chrome session via WebRTC.

Pipeline:
  1. launcher.launch_chrome(profile_dir) → spawns Chrome with persistent
     profile + remote-debugging-port=9222, blocks until DevTools HTTP
     endpoint is ready
  2. cdp.connect(ws_endpoint) → CDPClient with async send/event API
  3. screencast (phase 2) → CDP Page.startScreencast emits frames
  4. webrtc_peer (phase 3) → aiortc RTCPeerConnection consumes
     screencast frames as a VideoStreamTrack + receives coworker
     input via DataChannel
  5. input_replay (phase 2) → CDP Input.dispatchKeyEvent /
     dispatchMouseEvent applied to Chrome (with hotkey filter +
     URL blocklist enforced via Network.setBlockedURLs)
  6. signal_client (phase 4) → opens 2nd WSS to broker signaling URL,
     does SDP offer/answer + ICE trickle, hands the established
     RTCPeerConnection to step 4

This package is OPTIONAL — agents that only do BYOC workflow dispatch
(ollama, whisper, ffmpeg ops) don't need it. Importing this package
incurs the aiortc + av (PyAV) costs, so capabilities.detect_runtime_kinds
must NOT import here at agent boot time — only when `browser launch`
is actually invoked.
"""
