"""Agent-side pair-confirm flow.

User typed a 6-dig code from the haonhub UI into `haon-agent byoc pair`.
This module:

  1. Validates the code format (6 chars from the spec's base32-no-confusing
     alphabet).
  2. Generates a fresh Ed25519 keypair.
  3. Computes the hw fingerprint + hw_info report.
  4. POSTs `broker.haon.run/v1/byoc/pair-confirm` with everything.
  5. On 200, persists { permanent_token, agent_id, priv_pem, ... }
     in keyring.

Errors map to user-actionable click.ClickException raises so the CLI
exit codes line up with the spec's expectations:
  2 = format / arg validation
  3 = network / haonhub-side failure
  4 = code unknown/expired (PAIR_CODE_NOT_FOUND from API)
  5 = fingerprint reuse (409 from API)
"""

from __future__ import annotations

import re
from datetime import datetime, timezone

import click
import httpx
import structlog

from haon_agent.byoc import identity


log = structlog.get_logger("agent.byoc.pair")


# Spec section "Pairing code format": 6 chars from 32 unambiguous
# characters (no I/O/L/0/1). Validated CLIENT-side too so we never
# round-trip a clearly-wrong input.
_VALID_CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
_VALID_CHARS_RE = re.compile(f"^[{_VALID_CHARS}]{{6}}$")


def normalise_code(raw: str) -> str:
    """Strip whitespace + uppercase. Used at CLI entry to be friendly
    to copy-paste from the UI which renders as 'AbC234' or with
    trailing space."""
    return raw.strip().upper()


def validate_code(code: str) -> None:
    if not _VALID_CHARS_RE.match(code):
        raise click.ClickException(
            f"Pairing code must be exactly 6 chars from {_VALID_CHARS!r}. "
            f"Got {code!r}."
        )


async def confirm_pairing(
    *,
    api_base: str,
    pairing_code: str,
    agent_version: str,
    http_client: httpx.AsyncClient | None = None,
    force_rebind: bool = False,
) -> identity.PairedState:
    """Run the full pair-confirm round-trip + persist on success.

    Returns the new PairedState. Raises click.ClickException on any
    user-facing error.

    `force_rebind` (hotfix 0.5.1): when True, send the
    `X-Haon-Force-Rebind: 1` header. The API honors this header by
    soft-deleting any existing active pairing under the same
    (tenant_slug, agent_fingerprint, end_user_id) BEFORE attempting
    the INSERT. Use only when the user has confirmed (CLI prompted
    them OR they passed --force-rebind explicitly). Default False
    keeps the strict behavior — 409 if the fingerprint is reused.
    """
    validate_code(pairing_code)

    priv_pem, pub_b64 = identity.generate_agent_keypair()
    fingerprint = identity.compute_fingerprint()
    hw_info = identity.collect_hw_info(agent_version)

    body = {
        "pairing_code": pairing_code,
        "agent_pubkey": pub_b64,
        "agent_fingerprint": fingerprint,
        "hw_info": hw_info,
    }
    headers: dict[str, str] = {}
    if force_rebind:
        # Server-side hook: services/api/app/modules/byoc/service.py
        # consume_pending_and_register() checks for this header and
        # soft-deletes the existing active pairing before the new INSERT.
        headers["X-Haon-Force-Rebind"] = "1"

    url = f"{api_base.rstrip('/')}/v1/byoc/pair-confirm"

    owns_client = http_client is None
    if owns_client:
        http_client = httpx.AsyncClient(timeout=30.0)

    try:
        try:
            resp = await http_client.post(url, json=body, headers=headers)
        except httpx.TimeoutException as exc:
            raise click.ClickException(
                f"Timed out talking to {url}. Check your internet "
                "connection and try again."
            ) from exc
        except httpx.ConnectError as exc:
            raise click.ClickException(
                f"Could not reach {url}. Check your internet connection."
            ) from exc

        if resp.status_code == 200:
            data = resp.json()
            paired_state = identity.PairedState(
                agent_id=data["agent_id"],
                permanent_token=data["permanent_token"],
                paired_at_iso=datetime.now(tz=timezone.utc).isoformat(),
                agent_priv_pem=priv_pem,
                agent_pubkey_b64=pub_b64,
            )
            identity.store_paired(paired_state)
            return paired_state

        # Map API error codes to user-facing messages + distinct exit codes.
        try:
            err = resp.json()
            code = err.get("code", "")
            detail = err.get("message", err.get("detail", resp.text))
        except (ValueError, KeyError):
            code = ""
            detail = resp.text[:200]

        if resp.status_code == 404 or code == "PAIR_CODE_NOT_FOUND":
            exc = click.ClickException(
                "Pairing code unknown, already used, or expired. "
                "Generate a fresh code from haonhub and try again."
            )
            exc.exit_code = 4
            raise exc
        if resp.status_code == 409 or code == "PAIR_FINGERPRINT_REUSE":
            # Hotfix 0.5.1: surface the --force-rebind escape hatch in
            # the error so users in split-brain state (local config
            # empty but server still bound) have a clean recovery path.
            exc = click.ClickException(
                "This machine is already paired with the SaaS. Options:\n"
                "  1) `haon-agent byoc unpair` first, then re-pair.\n"
                "  2) `haon-agent byoc pair <code> --force-rebind` to "
                "overwrite the existing pairing (use when local config "
                "was deleted/lost — server still thinks paired)."
            )
            exc.exit_code = 5
            raise exc
        if resp.status_code == 422:
            exc = click.ClickException(
                f"Pair-confirm request rejected (validation): {detail}"
            )
            exc.exit_code = 2
            raise exc
        if resp.status_code >= 500 or 502 <= resp.status_code <= 504:
            exc = click.ClickException(
                f"Server error ({resp.status_code}). The pairing service "
                "is having trouble. Try again in a minute."
            )
            exc.exit_code = 3
            raise exc

        # Catch-all for unexpected statuses.
        exc = click.ClickException(
            f"Pair-confirm returned HTTP {resp.status_code}: {detail}"
        )
        exc.exit_code = 3
        raise exc

    finally:
        if owns_client:
            await http_client.aclose()
