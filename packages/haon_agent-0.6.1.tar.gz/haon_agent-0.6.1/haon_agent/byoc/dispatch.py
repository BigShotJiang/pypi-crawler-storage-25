"""Top-level entry point for BYOC frame dispatch.

The agent's transport layer (broker DATA frame OR WebRTC DataChannel,
depending on how haonhub.com routes) hands us a parsed JSON frame +
a way to send response frames back. This module:

  1. Validates the inbound envelope (wire.WorkflowEnvelope).
  2. Builds a per-session working directory under ~/haon/sessions/
     scoped so the file-touching op-runtimes can't escape.
  3. Calls workflow_dsl.parse() + workflow_dsl.execute().
  4. Forwards progress frames via the caller-supplied `send` callable.
  5. Returns the terminal done/error envelope (caller forwards too).

Deliberately library-shaped: no transport, no thread/process lifecycle,
no global state. The agent's main loop imports and calls this; a
test can call it with an in-memory `send` collector.

Why not wire directly into `haon_agent.agent._run_session`:

  - That function owns marketplace session lifecycle (worker pairing,
    USD-tick emission, broker keepalive, port-forward handoff). BYOC
    has none of those — paying user lives on haonhub.com, ticks are
    haonhub's billing concern, no worker pairing.
  - Mixing the two paths in one 1000-LoC function is the kind of
    mistake that takes 6 months to untangle. Better to keep the
    BYOC entry point self-contained and let the agent route to it
    when it sees a workflow envelope.

The actual agent.py wiring is a separate ~20-line PR (Round 7) so the
review surface for each concern is clean.
"""

from __future__ import annotations

import os
import shutil
import uuid
from pathlib import Path
from typing import Any, Awaitable, Callable

import structlog
from pydantic import ValidationError

from haon_agent.byoc import wire, workflow_dsl


log = structlog.get_logger("agent.byoc.dispatch")

SendCallable = Callable[[dict[str, Any]], Awaitable[None]]
"""Caller-supplied: `async def send(frame: dict) -> None`.

The dispatcher calls this for each progress frame and once at the end
with the terminal done/error frame. The caller is responsible for
serialising the dict to JSON (or whatever the transport expects) and
delivering it to haonhub.com.
"""


# ── Session-dir management ─────────────────────────────────────────────


def _sessions_root() -> Path:
    """Resolve ~/haon/sessions/. Per spec section 'Design Constraints':
        All file I/O scoped to ~/haon/sessions/<session_id>/

    Honored via the `HAON_SESSIONS_DIR` env override for tests +
    operator-managed deploy paths."""
    base = Path(
        os.environ.get(
            "HAON_SESSIONS_DIR",
            str(Path.home() / "haon" / "sessions"),
        )
    )
    base.mkdir(parents=True, exist_ok=True)
    return base


def _make_session_dir(session_id: uuid.UUID) -> Path:
    """Allocate a fresh per-session scratch dir. Caller is responsible
    for cleanup via `cleanup_session_dir()` at the end of dispatch."""
    d = _sessions_root() / str(session_id)
    d.mkdir(parents=True, exist_ok=True)
    return d


def cleanup_session_dir(session_id: uuid.UUID) -> None:
    """Remove the per-session scratch dir. Called by the agent after
    the workflow completes (success OR failure). Safe to call multiple
    times — uses `ignore_errors=True`.

    Surfaced as a public helper so callers in agent.py can sequence the
    cleanup after sending the terminal frame (otherwise file references
    in the output payload would dangle)."""
    d = _sessions_root() / str(session_id)
    if d.exists():
        shutil.rmtree(d, ignore_errors=True)


# ── Public entry point ─────────────────────────────────────────────────


async def handle_workflow_frame(
    frame: dict[str, Any],
    *,
    send: SendCallable,
) -> dict[str, Any]:
    """Run one BYOC workflow end-to-end and return the terminal envelope.

    Idempotent w.r.t. the file system: every workflow gets a fresh
    session dir at start, and the caller is expected to call
    `cleanup_session_dir(session_id)` after the terminal frame is on
    the wire (NOT here — the dispatcher returns the path-containing
    output dict and cleanup BEFORE sending would dangle references).

    The dispatcher CATCHES all exceptions and returns an error envelope.
    Never raises — the caller can `await send(result)` unconditionally.
    """
    # Phase 1: envelope shape check. Reject before allocating session dir.
    try:
        envelope = wire.WorkflowEnvelope.model_validate(frame)
    except ValidationError as exc:
        # We don't have a session_id from a malformed envelope — return
        # a synthetic UUID so the response is still well-formed.
        synth = uuid.uuid4()
        result = wire.error(
            session_id=synth,
            code="INVALID_INPUT",
            detail=f"workflow envelope rejected: {_summarise_pydantic(exc)}",
        )
        await send(result)
        return result

    session_id = envelope.session_id

    # Phase 2: parse the inner workflow body.
    try:
        wf = workflow_dsl.parse(envelope.workflow)
    except workflow_dsl.InvalidWorkflowError as exc:
        result = wire.error(
            session_id=session_id,
            code="INVALID_INPUT",
            detail=str(exc),
        )
        await send(result)
        return result

    # Phase 3: execute. Progress frames are forwarded via the caller's
    # send(); the final done/error envelope is forwarded once at the end.
    session_dir = _make_session_dir(session_id)
    log.info(
        "byoc_workflow_dispatch_start",
        session_id=str(session_id),
        runtime=wf.runtime,
        tool_id=wf.tool_id,
        step_count=len(wf.steps),
    )
    try:
        result = await workflow_dsl.execute(
            wf,
            session_id=session_id,
            session_dir=session_dir,
            on_progress=send,
        )
    except Exception as exc:  # noqa: BLE001 — must never leak out of dispatch
        log.exception(
            "byoc_workflow_unexpected_failure",
            session_id=str(session_id),
        )
        result = wire.error(
            session_id=session_id,
            code="AGENT_BUG",
            detail=f"{type(exc).__name__}: {exc}",
        )

    await send(result)
    log.info(
        "byoc_workflow_dispatch_end",
        session_id=str(session_id),
        terminal_msg=result["msg"],
    )
    return result


def _summarise_pydantic(exc: ValidationError) -> str:
    """Render a pydantic ValidationError into a single short string
    suitable for the wire `detail` field (2 KB cap)."""
    errors = exc.errors()
    parts = []
    for e in errors[:3]:  # cap at first 3 to stay well under 2 KB
        loc = ".".join(str(p) for p in e.get("loc", ()))
        msg = e.get("msg", "validation error")
        parts.append(f"{loc}: {msg}" if loc else msg)
    summary = "; ".join(parts)
    if len(errors) > 3:
        summary += f" (+{len(errors) - 3} more)"
    return summary


__all__ = [
    "SendCallable",
    "cleanup_session_dir",
    "handle_workflow_frame",
]
