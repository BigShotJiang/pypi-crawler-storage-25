"""BYOC (Bring Your Own Compute) — workflow-dispatch execution path.

Companion to `haon_agent.runtime/` (the P2P GPU marketplace's byte-pipe
runtime). Where `runtime/` opens a session-long bidirectional pipe and
shovels HTTP-over-WebRTC bytes to a Docker container, BYOC receives a
declarative workflow JSON from the SaaS-side dispatcher (haonhub.com)
and executes it as a sequence of one-shot ops against local services
(Ollama on 11434, ffmpeg CLI, faster-whisper Python lib).

Two products, two abstractions, one agent — see
docs/byoc/workflow-dsl-spec.md (gist d26ea943) and
docs/byoc/model-registry-spec.md (gist 4de87b30) for the protocol.

Public surface:

  - `byoc.wire`        Typed envelopes (workflow / progress / done / error)
  - `byoc.ops`         OpRuntime ABC + registry (ollama / whisper / ffmpeg)
  - `byoc.workflow_dsl` Parser + variable substitution + step executor
  - `byoc.model_sync`   R2 download + sha256 + Ed25519 manifest verify

The agent dispatch (`haon_agent.agent`) inspects each incoming control
frame; `{"msg":"workflow"}` routes here instead of through the byte-pipe
runtime. The two paths are independent — a session can only be ONE of
the two modes for its lifetime.
"""

from __future__ import annotations
