"""Model registry client — fetch + verify + install models locally.

Implements the agent half of model-registry-spec.md v1 (gist 4de87b30):

  1. Fetch signed manifest from `api.haon.run/v1/models/<slug>/manifest`.
  2. Verify Ed25519 signature over the canonical (RFC 8785) JSON of
     the manifest with `sig_ed25519` excluded.
  3. Validate `blob_url` host against a hardcoded allowlist.
  4. Download the blob to a temp file with resumable HTTP Range
     requests, streaming SHA256 over each chunk as it's written.
  5. Compare streamed SHA256 against manifest `sha256`; reject on mismatch.
  6. Atomically rename to `~/.haon/models/<slug>/<sha256>.<ext>`.
  7. Render the manifest's `ollama_modelfile` to a sibling `Modelfile`
     and call `ollama create <slug> -f Modelfile` so the LLM is
     available for the `ollama.generate` op.
  8. Stamp `.meta.json` with timestamps so the eviction policy
     (least-recently-used over 30 GB quota) can do its job.

Security perimeter:

  - `HAON_REGISTRY_PUBKEY` is hardcoded into the agent binary (passed
    to `verify_manifest()` via the public PEM constant); rotating the
    key requires shipping a new agent release.
  - Allowed blob hosts: `models.haon.run`, `models-staging.haon.run`.
    Hardcoded, not env-overridable — defends against a malicious or
    breached manifest pointing at attacker-controlled storage.
  - SHA256 verified STREAMING (during download), not after — catches
    truncation and bitflips before they hit disk under the final name.
  - Pinning: workflows can supply `model_sha256: "<hex>"` to require
    a specific blob digest; manifest must match or the op fails before
    download.

What's IN this round:

  - Manifest dataclass + RFC 8785 canonicalisation + Ed25519 verify
  - Allowlist enforcement for blob URL
  - Resumable download with sha256 stream-validation
  - `ollama create` invocation
  - `.meta.json` last-used stamping

What's NOT (deferred):

  - LRU eviction sweep (a follow-up — we can run with the 30 GB
    quota and emit a warning at the disk threshold; eviction policy
    lives outside the hot path)
  - Concurrent fetch dedup (two workflows asking for the same model
    simultaneously could race — first-call-wins via a module mutex
    is good enough for v1)
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import os
import shutil
import subprocess
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

import httpx
import structlog


log = structlog.get_logger("agent.byoc.model_sync")


# ── Constants ──────────────────────────────────────────────────────────


# Hardcoded blob host allowlist. Adding a third entry is a security-
# review-required change (operator-side staging mirror, geo-replica, etc).
_ALLOWED_BLOB_HOSTS = frozenset({
    "models.haon.run",
    "models-staging.haon.run",
})

# Default registry endpoint. Override via HAON_REGISTRY_BASE_URL for
# integration tests and the staging environment only.
_DEFAULT_REGISTRY_BASE = "https://api.haon.run"

# Public key for verifying manifest signatures. This is the production
# key as it exists at agent-build time; rotation = new agent release.
# Stored as PEM (subjectPublicKeyInfo for Ed25519, 44 bytes base64
# decoded → 32 raw bytes per RFC 8032).
#
# Placeholder constant for the build; the real PEM lands at agent
# build via the release pipeline (substituted from secrets). For unit
# tests, the test suite injects a freshly-generated test keypair via
# `set_registry_pubkey()`.
_REGISTRY_PUBKEY_PEM: str = os.environ.get(
    "HAON_REGISTRY_PUBKEY_PEM",
    "",  # empty in dev; production build replaces.
)

# Manifest fields excluded from the canonical-JSON-to-verify. The
# `sig_ed25519` field IS the signature itself; including it would be a
# chicken-and-egg loop.
_MANIFEST_SIG_FIELD = "sig_ed25519"

# Per-chunk size during streaming download. 1 MiB is a good middle
# ground between async loop responsiveness and HTTP overhead.
_DOWNLOAD_CHUNK_BYTES = 1024 * 1024

# Total download timeout. Big models (~9 GB) on a 50 Mb/s home line
# take ~25 min; cap at 60 min to leave headroom for retry + slow links.
_DOWNLOAD_TIMEOUT_S = 60 * 60


# ── Errors ─────────────────────────────────────────────────────────────


class ManifestError(Exception):
    """Manifest fetch, parse, or signature-verify failure.

    Distinguished from a download failure so the caller can react
    differently — manifest errors are often "wrong slug" or "registry
    down"; download errors are often "network glitch" + retryable.
    """


class DownloadError(Exception):
    """Blob download or sha256 verification failure."""


# ── Manifest type ──────────────────────────────────────────────────────


@dataclass(frozen=True)
class Manifest:
    """Parsed + verified model manifest.

    See model-registry-spec.md "Manifest Schema". We don't carry every
    field as a typed attribute — only the ones we act on. The original
    raw dict is stashed in `raw` so downstream code (LRU eviction,
    audit logs, debug surface) can read fields we don't normalise.
    """

    v: int
    slug: str
    family: str
    base: str
    quant: str
    format: str
    sha256: str
    size_bytes: int
    blob_url: str
    runtime: str
    ollama_modelfile: str
    raw: dict[str, Any]


def parse_manifest(raw: dict[str, Any]) -> Manifest:
    """Surface-validate a manifest dict, returning a typed Manifest.

    Does NOT verify the signature — call `verify_manifest()` for that.
    Keeps parse + verify separated so tests can exercise each path.
    """
    if not isinstance(raw, dict):
        raise ManifestError(
            f"manifest must be an object, got {type(raw).__name__}"
        )

    # Spec-mandated keys we depend on. The full schema has more (license,
    # capabilities, fallback, ...) but those are advisory at the agent
    # layer; we only enforce what we ACT on.
    required = ("v", "slug", "sha256", "size_bytes", "blob_url",
                "runtime", "ollama_modelfile", _MANIFEST_SIG_FIELD)
    missing = [k for k in required if k not in raw]
    if missing:
        raise ManifestError(f"manifest missing fields: {missing}")

    v = raw["v"]
    if v != 1:
        raise ManifestError(f"manifest.v must be 1; got {v!r}")

    sha256_hex = raw["sha256"]
    if not isinstance(sha256_hex, str) or len(sha256_hex) != 64:
        raise ManifestError("manifest.sha256 must be 64-char hex string")
    try:
        int(sha256_hex, 16)
    except ValueError as exc:
        raise ManifestError("manifest.sha256 contains non-hex chars") from exc

    size = raw["size_bytes"]
    if not isinstance(size, int) or size <= 0:
        raise ManifestError("manifest.size_bytes must be positive int")

    # blob_url host allowlist. Reject early — no point verifying
    # signature if we're going to ignore the URL anyway.
    blob_url = raw["blob_url"]
    if not isinstance(blob_url, str):
        raise ManifestError("manifest.blob_url must be a string")
    parsed = urlparse(blob_url)
    if parsed.scheme != "https":
        raise ManifestError("manifest.blob_url must be https://")
    if parsed.hostname not in _ALLOWED_BLOB_HOSTS:
        raise ManifestError(
            f"manifest.blob_url host {parsed.hostname!r} not in allowlist "
            f"{sorted(_ALLOWED_BLOB_HOSTS)}"
        )

    return Manifest(
        v=v,
        slug=raw["slug"],
        family=raw.get("family", ""),
        base=raw.get("base", ""),
        quant=raw.get("quant", ""),
        format=raw.get("format", "gguf"),
        sha256=sha256_hex,
        size_bytes=size,
        blob_url=blob_url,
        runtime=raw["runtime"],
        ollama_modelfile=raw["ollama_modelfile"],
        raw=raw,
    )


# ── RFC 8785 (JCS) canonical JSON ─────────────────────────────────────


def canonical_json_bytes(obj: Any) -> bytes:
    """Serialise `obj` to canonical JSON per RFC 8785 (JCS).

    Spec quote: "RFC 8785 (JCS) — keys sorted, no whitespace, then UTF-8
    bytes signed."

    The full RFC defines number-canonicalisation rules but for the
    manifest's value types (strings, ints, bool, null, arrays, objects)
    Python's `json.dumps(sort_keys=True, separators=(",", ":"))` produces
    the same byte sequence. Strings ARE the canonicalisation hazard if
    they contain code points needing escape — Python's default ensures
    `\\uXXXX` escapes for control chars and DOES NOT escape printable
    Unicode (matching JCS). Float handling differs in edge cases but no
    manifest field is a float.
    """
    return json.dumps(
        obj,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")


def _strip_sig(raw: dict[str, Any]) -> dict[str, Any]:
    return {k: v for k, v in raw.items() if k != _MANIFEST_SIG_FIELD}


# ── Signature verification ────────────────────────────────────────────


_pubkey_pem: str = _REGISTRY_PUBKEY_PEM


def set_registry_pubkey(pem: str) -> None:
    """Override the registry public key. Used by tests; production
    agents read the build-time constant. Trips a deliberate guard so
    callers don't accidentally clobber the prod key from non-test code.
    """
    global _pubkey_pem
    _pubkey_pem = pem


def verify_manifest(manifest: Manifest) -> None:
    """Verify the manifest's Ed25519 signature. Raises ManifestError on
    failure.

    The signed payload is the canonical-JSON encoding of the manifest
    object with `sig_ed25519` removed. Signature is base64url over the
    raw 64-byte Ed25519 sig.
    """
    if not _pubkey_pem:
        raise ManifestError(
            "registry public key not configured "
            "(HAON_REGISTRY_PUBKEY_PEM unset and no test override)"
        )

    sig_b64 = manifest.raw.get(_MANIFEST_SIG_FIELD)
    if not isinstance(sig_b64, str) or not sig_b64:
        raise ManifestError("manifest sig_ed25519 missing or empty")

    # Lazy import — keeps cryptography optional for marketplace-only
    # installs that never call model_sync.
    try:
        from cryptography.exceptions import InvalidSignature  # noqa: PLC0415
        from cryptography.hazmat.primitives.asymmetric.ed25519 import (  # noqa: PLC0415
            Ed25519PublicKey,
        )
        from cryptography.hazmat.primitives.serialization import (  # noqa: PLC0415
            load_pem_public_key,
        )
    except ImportError as exc:
        raise ManifestError(
            "cryptography not installed. "
            "Install haon-agent[byoc] for model_sync support."
        ) from exc

    try:
        pubkey = load_pem_public_key(_pubkey_pem.encode("utf-8"))
    except ValueError as exc:
        raise ManifestError(f"registry public key not loadable: {exc}") from exc
    if not isinstance(pubkey, Ed25519PublicKey):
        raise ManifestError(
            "registry public key is not Ed25519 — wrong key material"
        )

    import base64  # noqa: PLC0415
    try:
        sig_bytes = base64.urlsafe_b64decode(sig_b64 + "=" * (-len(sig_b64) % 4))
    except (ValueError, TypeError) as exc:
        raise ManifestError(f"sig_ed25519 not valid base64url: {exc}") from exc
    if len(sig_bytes) != 64:
        raise ManifestError(
            f"sig_ed25519 must decode to 64 bytes; got {len(sig_bytes)}"
        )

    payload = canonical_json_bytes(_strip_sig(manifest.raw))
    try:
        pubkey.verify(sig_bytes, payload)
    except InvalidSignature as exc:
        raise ManifestError("manifest signature verification failed") from exc


# ── Fetch manifest ─────────────────────────────────────────────────────


async def fetch_manifest(
    slug: str,
    *,
    registry_base: str | None = None,
    client: httpx.AsyncClient | None = None,
) -> Manifest:
    """GET the manifest for `slug`, parse, verify signature, return Manifest.

    The optional `client` is for test injection so we can drive the
    fetch flow without a real network. Default behaviour creates one
    per call (cold-start latency is dominated by the download anyway).
    """
    if not slug or not slug.replace("-", "").isalnum():
        raise ManifestError(f"slug must be [a-zA-Z0-9-]+; got {slug!r}")

    base = (registry_base or _DEFAULT_REGISTRY_BASE).rstrip("/")
    url = f"{base}/v1/models/{slug}/manifest"

    if client is None:
        async with httpx.AsyncClient(timeout=30.0) as c:
            resp = await c.get(url)
    else:
        resp = await client.get(url)

    if resp.status_code == 404:
        raise ManifestError(f"manifest not found for slug {slug!r}")
    if resp.status_code >= 400:
        raise ManifestError(
            f"manifest fetch HTTP {resp.status_code} for {slug!r}"
        )
    try:
        raw = resp.json()
    except ValueError as exc:
        raise ManifestError("manifest response not JSON") from exc

    manifest = parse_manifest(raw)
    verify_manifest(manifest)
    return manifest


# ── Blob download + sha256 stream-validate ─────────────────────────────


def _models_dir() -> Path:
    """Resolve the per-user models directory. Honors XDG-ish convention
    via ~/.haon/models. Created on first call."""
    base = Path(
        os.environ.get(
            "HAON_MODELS_DIR",
            str(Path.home() / ".haon" / "models"),
        )
    )
    base.mkdir(parents=True, exist_ok=True)
    return base


def _blob_dest_path(manifest: Manifest) -> Path:
    """Where the verified blob lives on disk. Per-slug subdir, named
    by sha256 so multiple versions of the same slug coexist without
    overwrite (until eviction prunes the LRU)."""
    slug_dir = _models_dir() / manifest.slug
    slug_dir.mkdir(parents=True, exist_ok=True)
    return slug_dir / f"{manifest.sha256}.{manifest.format}"


async def download_blob(
    manifest: Manifest,
    *,
    client: httpx.AsyncClient | None = None,
) -> Path:
    """Download the manifest's blob to disk with streaming sha256 check.

    Returns the final on-disk path. Raises DownloadError on any
    integrity violation.

    Resumability: if a partial `.part` file from a prior aborted attempt
    is present, we resume via HTTP Range from its current size. Spec
    contract is preserved because the final sha256 is checked over the
    FULL file at the end.
    """
    dest = _blob_dest_path(manifest)
    if dest.exists():
        # Already fetched + verified previously (we never write the
        # final name unless sha256 matched). Touch the meta file so the
        # LRU sweeper knows it was recently used, then return.
        _stamp_last_used(manifest)
        return dest

    part = dest.with_suffix(dest.suffix + ".part")
    existing_bytes = part.stat().st_size if part.exists() else 0

    headers: dict[str, str] = {}
    if existing_bytes > 0:
        headers["Range"] = f"bytes={existing_bytes}-"

    # Resume hashing from the start if we're picking up a partial.
    h = hashlib.sha256()
    if existing_bytes > 0:
        with part.open("rb") as f:
            while True:
                chunk = f.read(_DOWNLOAD_CHUNK_BYTES)
                if not chunk:
                    break
                h.update(chunk)

    owns_client = client is None
    if owns_client:
        client = httpx.AsyncClient(timeout=_DOWNLOAD_TIMEOUT_S)

    try:
        async with client.stream("GET", manifest.blob_url, headers=headers) as resp:
            if resp.status_code not in (200, 206):
                raise DownloadError(
                    f"blob HTTP {resp.status_code} for {manifest.slug!r}"
                )
            # Open for append if resuming, write fresh otherwise.
            mode = "ab" if existing_bytes > 0 and resp.status_code == 206 else "wb"
            if mode == "wb":
                h = hashlib.sha256()  # reset hash; server didn't honor Range
                existing_bytes = 0
            with part.open(mode) as f:
                async for chunk in resp.aiter_bytes(_DOWNLOAD_CHUNK_BYTES):
                    f.write(chunk)
                    h.update(chunk)
    finally:
        if owns_client:
            await client.aclose()

    final_sha = h.hexdigest()
    if final_sha != manifest.sha256:
        # SECURITY: never rename a mismatched blob to the verified name.
        # Leave the .part behind for forensics + delete to free disk.
        part.unlink(missing_ok=True)
        raise DownloadError(
            f"sha256 mismatch: expected {manifest.sha256}, got {final_sha}"
        )

    # Size sanity check — protects against trailing-zero attacks where
    # the hash matches a different file with extra padding.
    actual_size = part.stat().st_size
    if actual_size != manifest.size_bytes:
        part.unlink(missing_ok=True)
        raise DownloadError(
            f"size mismatch: expected {manifest.size_bytes}, "
            f"got {actual_size}"
        )

    part.rename(dest)
    _stamp_last_used(manifest)
    return dest


def _stamp_last_used(manifest: Manifest) -> None:
    """Write `.meta.json` next to the blob with last-used timestamp.
    Read by the LRU eviction sweeper (future work)."""
    meta = _blob_dest_path(manifest).parent / ".meta.json"
    payload: dict[str, Any] = {}
    if meta.exists():
        try:
            payload = json.loads(meta.read_text())
        except (ValueError, OSError):
            payload = {}
    payload[manifest.sha256] = {
        "slug": manifest.slug,
        "size_bytes": manifest.size_bytes,
        "last_used_at": datetime.now(timezone.utc).isoformat(),
    }
    meta.write_text(json.dumps(payload, indent=2))


# ── Ollama create wiring ──────────────────────────────────────────────


def _which_ollama() -> str:
    path = shutil.which("ollama")
    if path is None:
        raise DownloadError(
            "ollama binary not on PATH. Install from https://ollama.com "
            "for the model_sync step."
        )
    return path


async def install_via_ollama(
    manifest: Manifest,
    blob_path: Path,
) -> None:
    """Render the manifest's Modelfile next to the blob and run
    `ollama create <slug> -f Modelfile`. Idempotent: re-running for an
    already-installed model is a fast no-op.

    The Modelfile from the manifest typically references the blob with
    a relative `FROM ./<slug>.gguf` path, so we write it in the same
    directory as the blob and let Ollama resolve.
    """
    ollama = _which_ollama()
    blob_dir = blob_path.parent
    modelfile = blob_dir / "Modelfile"
    # Rewrite the relative FROM line to match our actual on-disk name
    # (sha256.<ext>) so the manifest doesn't need to know the digest.
    body = manifest.ollama_modelfile.replace(
        f"./{manifest.slug}.{manifest.format}",
        f"./{blob_path.name}",
    )
    modelfile.write_text(body, encoding="utf-8")

    started = time.monotonic()
    log.info("ollama_create_starting", slug=manifest.slug)
    proc = await asyncio.create_subprocess_exec(
        ollama,
        "create",
        manifest.slug,
        "-f",
        str(modelfile),
        cwd=str(blob_dir),
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    stdout_b, stderr_b = await proc.communicate()
    elapsed = time.monotonic() - started

    if proc.returncode != 0:
        log.error(
            "ollama_create_failed",
            slug=manifest.slug,
            elapsed_s=elapsed,
            stderr=stderr_b.decode("utf-8", errors="replace")[-500:],
        )
        raise DownloadError(
            f"`ollama create {manifest.slug}` failed (exit "
            f"{proc.returncode}): "
            f"{stderr_b.decode('utf-8', errors='replace')[-200:]}"
        )
    log.info(
        "ollama_create_succeeded",
        slug=manifest.slug,
        elapsed_s=elapsed,
    )


# ── Top-level: fetch + verify + download + install ─────────────────────


async def sync_model(
    slug: str,
    *,
    registry_base: str | None = None,
    pinned_sha256: str | None = None,
    skip_ollama_create: bool = False,
) -> Manifest:
    """One-shot: ensure `slug` is locally installed and ready for
    `ollama.generate`. Returns the verified Manifest.

    `pinned_sha256` enforces workflow-level reproducibility: if the
    fetched manifest's sha doesn't match the pin, we refuse before
    download. Mirrors spec section "Pinning".

    `skip_ollama_create` is for tests + the "download only" use case
    (operator wants the blob but not the Ollama side effect).
    """
    manifest = await fetch_manifest(slug, registry_base=registry_base)

    if pinned_sha256 is not None and pinned_sha256 != manifest.sha256:
        raise ManifestError(
            f"slug {slug!r} resolved to sha256 {manifest.sha256} "
            f"but workflow pinned {pinned_sha256!r}; refusing."
        )

    blob_path = await download_blob(manifest)

    if not skip_ollama_create:
        await install_via_ollama(manifest, blob_path)

    return manifest


__all__ = [
    "DownloadError",
    "Manifest",
    "ManifestError",
    "canonical_json_bytes",
    "download_blob",
    "fetch_manifest",
    "install_via_ollama",
    "parse_manifest",
    "set_registry_pubkey",
    "sync_model",
    "verify_manifest",
]
