"""Agent identity primitives for BYOC.

Three concerns:

  1. Ed25519 keypair — generated locally at pair-time. Private half
     STAYS on the user's machine (keyring); public half goes to the
     API in pair-confirm body so the broker can verify WSS handshake
     nonces against it later (round 5.5+).

  2. Hardware fingerprint — sha256 of platform-stable identifiers
     (machine-id where available, mac address, hostname). Sent in
     pair-confirm body so the API's partial-unique index can detect
     same-hw re-pair attempts (and surface a 409 if not unpaired
     first).

  3. Persisted state — { permanent_token, agent_id, paired_at,
     agent_priv_pem } stored in the OS keyring under service name
     'haon-agent-byoc'. Same library as the existing marketplace
     credential path so users get a familiar prompt on macOS / Win.

All operations are sync (keyring lib is sync; agent CLI uses click +
asyncio.run for the actual HTTP/WSS parts and reaches into this
module for setup/teardown).
"""

from __future__ import annotations

import base64
import hashlib
import json
import platform
import socket
import sys
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import keyring


# Keyring service name. Distinct from the marketplace agent's
# 'haon-agent' so the two products don't trample each other on the
# same machine.
KEYRING_SERVICE = "haon-agent-byoc"
# Single account name — we only persist ONE pairing per machine for
# now. Multi-tenant support on one box is a Sprint 2 concern (the
# spec doesn't gate it but the UX gets hairy fast).
KEYRING_ACCOUNT = "default"


@dataclass(frozen=True)
class PairedState:
    """In-memory representation of a successful pairing. Persisted as
    JSON in the keyring under (KEYRING_SERVICE, KEYRING_ACCOUNT)."""

    agent_id: str
    permanent_token: str
    paired_at_iso: str
    agent_priv_pem: str   # Ed25519 private key, PEM PKCS8
    agent_pubkey_b64: str # base64url-no-pad (44 chars), matches API schema

    def to_json(self) -> str:
        return json.dumps(
            {
                "agent_id": self.agent_id,
                "permanent_token": self.permanent_token,
                "paired_at_iso": self.paired_at_iso,
                "agent_priv_pem": self.agent_priv_pem,
                "agent_pubkey_b64": self.agent_pubkey_b64,
            }
        )

    @classmethod
    def from_json(cls, blob: str) -> "PairedState":
        data = json.loads(blob)
        return cls(
            agent_id=data["agent_id"],
            permanent_token=data["permanent_token"],
            paired_at_iso=data["paired_at_iso"],
            agent_priv_pem=data["agent_priv_pem"],
            agent_pubkey_b64=data["agent_pubkey_b64"],
        )


# ── Keypair generation ────────────────────────────────────────────────


def generate_agent_keypair() -> tuple[str, str]:
    """Generate a fresh Ed25519 keypair for this pairing.

    Returns:
      (priv_pem, pub_b64_44)
      - priv_pem: PKCS8 PEM string, stored encrypted in keyring
      - pub_b64_44: base64-url-no-padding of the 32-byte raw public key.
                   Exactly 44 chars (32 bytes → 43 chars + 1 pad-free
                   tail; Python's urlsafe_b64encode + rstrip equals 44).

    The pubkey form goes into the pair-confirm request body
    (PairConfirmRequest.agent_pubkey, validated 43-44 chars on the API
    side).
    """
    from cryptography.hazmat.primitives.asymmetric.ed25519 import (
        Ed25519PrivateKey,
    )
    from cryptography.hazmat.primitives.serialization import (
        Encoding, NoEncryption, PrivateFormat, PublicFormat,
    )

    priv = Ed25519PrivateKey.generate()
    priv_pem = priv.private_bytes(
        encoding=Encoding.PEM,
        format=PrivateFormat.PKCS8,
        encryption_algorithm=NoEncryption(),
    ).decode("ascii")
    pub_raw = priv.public_key().public_bytes(
        encoding=Encoding.Raw, format=PublicFormat.Raw,
    )
    pub_b64 = base64.urlsafe_b64encode(pub_raw).rstrip(b"=").decode("ascii")
    return priv_pem, pub_b64


# ── Hardware fingerprint ──────────────────────────────────────────────


def _machine_id_hint() -> str:
    """Read the OS-stable machine id if available. Falls back to
    empty string when none of the standard paths exist."""
    for p in ("/etc/machine-id", "/var/lib/dbus/machine-id"):
        try:
            return Path(p).read_text(encoding="ascii").strip()
        except (OSError, UnicodeDecodeError):
            continue
    # Windows: HKLM\Software\Microsoft\Cryptography\MachineGuid — not
    # universally accessible from Python without ctypes. Fingerprint
    # gracefully degrades to mac+hostname which is good enough for our
    # uniqueness needs (NOT used for crypto, just for "same machine
    # re-paired" detection).
    return ""


def _mac_address_hint() -> str:
    """48-bit MAC of one network interface as 12-hex string. uuid lib
    returns a 48-bit int; we always have at least one MAC unless the
    OS is bizarre."""
    try:
        return f"{uuid.getnode():012x}"
    except Exception:  # noqa: BLE001
        return ""


def compute_fingerprint() -> str:
    """sha256 hex of (machine_id ?? '') + ':' + mac + ':' + hostname.
    Returns lowercase 64-char hex. Stable across re-installs as long
    as the OS, hardware, and hostname don't change.
    """
    parts = [
        _machine_id_hint(),
        _mac_address_hint(),
        socket.gethostname().lower(),
    ]
    raw = ":".join(parts).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


# ── hw_info report ─────────────────────────────────────────────────────


def collect_hw_info(agent_version: str) -> dict[str, Any]:
    """Build the hw_info dict for the pair-confirm body. Free-shape per
    the API schema; we report a useful subset for the admin UI."""
    return {
        "os": f"{platform.system()} {platform.release()}".strip(),
        "cpu": platform.processor() or platform.machine() or "",
        "hostname": socket.gethostname(),
        "python_version": f"{sys.version_info.major}.{sys.version_info.minor}",
        "agent_version": agent_version,
    }


# ── Keyring persistence ───────────────────────────────────────────────


def store_paired(state: PairedState) -> None:
    """Persist a successful pairing in the OS keyring. Overwrites any
    prior pairing (single-pairing-per-machine convention)."""
    keyring.set_password(KEYRING_SERVICE, KEYRING_ACCOUNT, state.to_json())


def load_paired() -> PairedState | None:
    raw = keyring.get_password(KEYRING_SERVICE, KEYRING_ACCOUNT)
    if not raw:
        return None
    try:
        return PairedState.from_json(raw)
    except (ValueError, KeyError):
        # Corrupt blob — return None so caller treats as unpaired.
        return None


def clear_paired() -> None:
    """Remove the pairing from keyring. Idempotent: no entry → no-op."""
    try:
        keyring.delete_password(KEYRING_SERVICE, KEYRING_ACCOUNT)
    except keyring.errors.PasswordDeleteError:
        pass
