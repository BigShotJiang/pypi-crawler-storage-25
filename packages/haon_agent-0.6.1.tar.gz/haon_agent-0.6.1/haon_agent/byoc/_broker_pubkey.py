"""Bundled broker Ed25519 public key — verifier-side constant.

The matching private half is held ONLY by the haon-api service
(/opt/haon/secrets/byoc_broker_ed25519_private.pem on the production
VPS). This module exists so the agent can verify permanent_token JWS
blobs offline — no first-fetch, no TOFU, no pinned-hash fallback (per
Caio's 6-Q response #1, "zero fallback").

Rotation policy: shipping a new broker signing key requires:
  1. Generate new keypair on the API host.
  2. Update this constant + cut a new agent release.
  3. Operate both old + new keys on the API for the rotation overlap
     window (haon-api side supports verifying with N keys during overlap).
  4. Once all paired agents have updated, retire the old key.

DO NOT swap this constant out for first-fetch or TOFU patterns. Pairing
trust starts with the bundled key; if the wrong key ships, the user
gets a clean "kid mismatch" at WSS connect time and re-installs the
agent. That's the correct failure mode.

Bundled value as of 2026-05-17:
  kid (sha256(pub_raw)[:16]) = 2cfdf93dccef0757
"""

from __future__ import annotations


# 2026-05-17: initial BYOC broker signing key. Generated on the API
# host via `openssl genpkey -algorithm ED25519`. The corresponding
# private key lives in /opt/haon/secrets/byoc_broker_ed25519_private.pem
# (mode 600, haon:haon).
BROKER_PUBLIC_KEY_PEM: str = """\
-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEAQd3AHOVoOyAPQye0qq3VikPVUWPhzYsMqi55ETc41Vs=
-----END PUBLIC KEY-----
"""

# Cached kid for the bundled key. Computed at verify time from
# BROKER_PUBLIC_KEY_PEM; mirrored here so test fixtures can assert
# the constant without re-deriving (and so docs reference one place).
EXPECTED_KID: str = "2cfdf93dccef0757"
