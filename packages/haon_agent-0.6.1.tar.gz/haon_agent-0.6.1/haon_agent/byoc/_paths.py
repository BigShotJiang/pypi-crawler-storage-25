"""Session-scoped path helpers shared by file-handling op-runtimes.

The workflow-dsl spec mandates:

    All file I/O scoped to ~/haon/sessions/<session_id>/
    Agent rejects paths outside that scope.

This module centralises the resolve+validate logic so each file-touching
op-runtime (whisper, ffmpeg.*) doesn't reinvent it (with subtle bugs:
symlink-escape, `..` traversal, drive-letter swap on Windows).

Two-phase: (1) `resolve_under()` makes the user-supplied path absolute
and follows symlinks; (2) the caller compares against `ctx.session_dir`
(also resolved). If the resolved input is not a descendant of the resolved
session_dir, `EscapeError` is raised — and we deliberately re-raise as
`InvalidOpInput` at the op layer, mapping to wire code INVALID_INPUT.
"""

from __future__ import annotations

from pathlib import Path


class EscapeError(ValueError):
    """Raised when a user-supplied path resolves outside the session dir."""


def resolve_under(path_str: str, session_dir: Path) -> Path:
    """Return the resolved absolute path IFF it lives under `session_dir`.

    Resolves both sides via `Path.resolve(strict=False)` so symlinks are
    followed and `..` segments collapsed BEFORE the descendant check.
    `strict=False` because the path may not exist yet (e.g. an op
    declaring its output file) — we still want the scope check to fire.

    Windows note: `Path.resolve()` normalises case + drive letters, so
    `c:/Users/x/...` vs `C:\\Users\\X\\...` compare equal after resolve.
    """
    if not path_str:
        raise EscapeError("empty path")

    p = Path(path_str)
    # The spec rejects control chars implicitly via the 2KB string cap +
    # JSON parsing; we add a belt+suspenders check here for any literal
    # NUL byte that would surprise downstream subprocess args.
    if "\x00" in path_str:
        raise EscapeError("path contains NUL byte")

    resolved = p.resolve(strict=False)
    root = session_dir.resolve(strict=False)

    try:
        resolved.relative_to(root)
    except ValueError as exc:
        raise EscapeError(
            f"path {path_str!r} resolves outside session scope {str(root)!r}"
        ) from exc

    return resolved


def under_session(path: Path, session_dir: Path) -> Path:
    """Build a new path INSIDE the session dir (for op output files).

    Validates that the constructed path stays inside the session dir
    after join — defends against `path = "../../etc/passwd"` style
    injection when callers compose op-output names from user input.
    """
    target = (session_dir / path).resolve(strict=False)
    root = session_dir.resolve(strict=False)
    try:
        target.relative_to(root)
    except ValueError as exc:
        raise EscapeError(
            f"output path {str(path)!r} escapes session scope"
        ) from exc
    return target
