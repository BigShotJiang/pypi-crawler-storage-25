"""OpRuntime ABC + registry — the contract every BYOC op-runtime fulfils.

An op-runtime is a *stateless* executor for a single workflow step. Each
incoming workflow creates a fresh instance via `get_op(name)()`, calls
`await runtime.run(args, ctx)`, and discards it. The instance does NOT
persist between steps — keep heavy state (loaded models, ffmpeg child
procs, etc.) in module-level lazily-initialised singletons and protect
them with their own locks.

Why a class and not a plain async function:

  - Lets the runtime own a logger bound to its op name.
  - Lets the runtime declare per-op resource hints (e.g. estimated VRAM)
    that the executor can use for scheduling. Not used in Round 1 but
    we want the slot reserved.
  - Mirrors `runtime/base.py:Runtime` shape ergonomically so future
    refactors can hoist common bits if the two abstractions ever
    converge (they probably won't, but the symmetry is cheap).
"""

from __future__ import annotations

import abc
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Awaitable, Callable

import structlog

ProgressCallback = Callable[[float, str], Awaitable[None]]
"""Signature: `async def cb(pct: float, stage: str) -> None`.

Op-runtimes call this from inside `run()` to emit progress frames mid-
step. The executor wires it to `wire.progress(step_id=..., pct=..., stage=...)`
forwarded to the broker. Calling with pct=1.0 is allowed but the executor
emits the canonical "stage=done" frame at step exit anyway.
"""


@dataclass(frozen=True)
class OpContext:
    """Per-step context handed to `run()`.

    Carries the immutable session-scoped bits an op-runtime needs but
    shouldn't have to look up itself. The workflow executor constructs
    one per step and the op-runtime treats it read-only.

    `session_dir` is the spec-mandated scope for all file I/O — paths
    that escape this dir MUST be rejected by ops that take file
    arguments. See spec section "Design Constraints":
        > All file I/O scoped to ~/haon/sessions/<session_id>/
        > Agent rejects paths outside that scope
    """

    session_id: str
    session_dir: Path
    progress: ProgressCallback


class OpRuntime(abc.ABC):
    """Base class for every op listed in the spec's allowlist.

    Subclasses set `name` to the dotted op identifier ("ollama.generate",
    "ffmpeg.normalize_audio", ...) and implement `run(args, ctx)`. The
    base `__init__` binds a structlog logger so callers don't repeat
    boilerplate.
    """

    #: Dotted op identifier as it appears in workflow step `op:` field.
    #: Must be unique across all registered runtimes.
    name: str = ""

    def __init__(self) -> None:
        if not self.name:
            raise TypeError(
                f"{type(self).__name__} did not set `name`; "
                f"OpRuntime subclasses must declare their dotted op id."
            )
        self.log = structlog.get_logger(f"agent.byoc.op.{self.name}")

    @abc.abstractmethod
    async def run(self, args: dict[str, Any], ctx: OpContext) -> dict[str, Any]:
        """Execute one workflow step.

        `args` is the step's JSON minus the standard envelope keys (`id`,
        `op`, `on_error`); only op-specific fields remain. The DSL
        executor has already done variable substitution + size-cap checks
        before calling here.

        Returns a dict matching the op's documented output schema (see
        spec). The executor merges this into `steps.<id>` for downstream
        `{steps.<id>.<field>}` substitution and the final result frame.

        On failure:
          - Raise `InvalidOpInput` for caller error (bad args, file
            outside session_dir, missing required field).
          - Raise `RuntimeFailed` for upstream service error (ollama
            down, ffmpeg non-zero exit, model not found on disk).
          - Anything else propagates up as AGENT_BUG to the dispatcher,
            which is the right outcome — surprises should be loud.
        """
        raise NotImplementedError


# ── Errors ─────────────────────────────────────────────────────────────


class InvalidOpInput(ValueError):
    """Raised by `OpRuntime.run` when `args` violates the op's contract.

    Caught by the executor and mapped to wire error code INVALID_INPUT.
    The exception's __str__ is forwarded to the SaaS dispatcher
    verbatim — keep it user-facing and free of internal paths / PII.
    """


class RuntimeFailed(RuntimeError):
    """Raised by `OpRuntime.run` when the upstream tool failed.

    Mapped to wire code RUNTIME_FAILED. Examples: ollama HTTP 500,
    ffmpeg exit-code 1, faster-whisper raised a model-load error.
    """


# ── Registry ────────────────────────────────────────────────────────────


OpFactory = Callable[[], OpRuntime]


_REGISTRY: dict[str, OpFactory] = {}


def register(name: str, factory: OpFactory) -> None:
    """Register an op-runtime factory under its dotted name.

    Idempotent: re-registering the same name with the same factory is a
    no-op; replacing with a DIFFERENT factory raises. That keeps tests
    from silently shadowing prod runtimes.
    """
    existing = _REGISTRY.get(name)
    if existing is not None and existing is not factory:
        raise RuntimeError(
            f"op {name!r} already registered with a different factory "
            f"({existing!r} vs {factory!r}); refusing to clobber."
        )
    _REGISTRY[name] = factory


def get_op(name: str) -> OpRuntime:
    """Resolve op name → instance. Raises KeyError on unknown op.

    The executor catches KeyError and surfaces as MODEL_NOT_FOUND wire
    code — semantically the op isn't found, not the model, but the spec
    keeps the error set small and that's the closest match. (Future
    spec rev may add `OP_UNKNOWN`.)
    """
    if name not in _REGISTRY:
        raise KeyError(
            f"unknown op: {name!r} (registered: {sorted(_REGISTRY)})"
        )
    return _REGISTRY[name]()


def supported() -> list[str]:
    """Sorted list of currently-registered op names. Used by the agent's
    capabilities advertisement to the broker on session open."""
    return sorted(_REGISTRY)
