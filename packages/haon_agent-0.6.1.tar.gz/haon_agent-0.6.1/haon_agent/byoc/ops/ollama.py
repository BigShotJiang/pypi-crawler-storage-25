"""`ollama.generate` op-runtime — talks to the user's local Ollama daemon.

Spec args (workflow-dsl-spec v1, gist d26ea943):

    {
        "id": "gen",
        "op": "ollama.generate",
        "model": "haon-llm-14b" | "haon-llm-7b" | "haon-llm-3b",
        "system": "<string ≤ 8 KB>",
        "user":   "<string ≤ 32 KB>",
        "max_tokens": 4096,
        "temperature": 0.7,
        "json_mode": true | false,
        "stop": ["<seq>", ...]
    }

Output:

    { "text": "...", "tokens_in": int, "tokens_out": int,
      "model": "...", "elapsed_ms": int }

Wire: POST http://127.0.0.1:11434/api/chat with messages=[system,user],
options={temperature,num_predict,stop}, format="json" if json_mode, stream=False.
Same daemon as the marketplace's `runtime/ollama_native.py` (port 11434
fixed by upstream). The two runtimes coexist — different abstractions,
same backend. Model availability comes from a prior `model_sync.fetch()`
(Round 5); this op only generates against an already-loaded model.

Model name is forwarded VERBATIM to Ollama. We deliberately don't
hardcode the 3 haon-llm-* slugs here: the model registry can grow, and
adding a model shouldn't require an agent release. If the user's local
daemon doesn't know the slug yet, Ollama returns a 404 which we surface
as RUNTIME_FAILED with a hint to run model_sync.
"""

from __future__ import annotations

import time
from typing import Any

import httpx

from haon_agent.byoc.ops.base import (
    InvalidOpInput,
    OpContext,
    OpRuntime,
    RuntimeFailed,
    register,
)

# Mirror runtime/ollama_native.py constants — single source of truth would
# be nicer but cross-package import would also drag the byte-pipe DockerRuntime
# tree in, defeating the whole point of byoc/ as a separate concern.
OLLAMA_BASE_URL = "http://127.0.0.1:11434"
OLLAMA_CHAT_PATH = "/api/chat"

# Spec-imposed argument caps. Enforced before the HTTP call so an
# oversize prompt never hits the daemon (saves a round-trip + clearer
# error surface).
_SYSTEM_MAX_BYTES = 8 * 1024
_USER_MAX_BYTES = 32 * 1024
_STOP_MAX_ITEMS = 8                 # not in spec; reasonable cap to avoid abuse
_STOP_ITEM_MAX_BYTES = 256          # not in spec; same rationale

# Default request timeout. The workflow has its own session.timeout_ms,
# but each step needs its own ceiling so a hung step doesn't burn the
# whole budget. 120s = generous for 14B model + 4k tokens on a CPU
# fallback; faster GPUs finish well under this.
_DEFAULT_TIMEOUT_S = 120.0


class OllamaGenerateOp(OpRuntime):
    name = "ollama.generate"

    async def run(self, args: dict[str, Any], ctx: OpContext) -> dict[str, Any]:
        # ── Argument validation (do this before any network I/O) ─────
        model = args.get("model")
        if not isinstance(model, str) or not model:
            raise InvalidOpInput("ollama.generate: `model` (string) required.")

        system = args.get("system", "")
        if not isinstance(system, str):
            raise InvalidOpInput("ollama.generate: `system` must be a string.")
        if len(system.encode("utf-8")) > _SYSTEM_MAX_BYTES:
            raise InvalidOpInput(
                f"ollama.generate: `system` exceeds {_SYSTEM_MAX_BYTES} bytes."
            )

        user = args.get("user", "")
        if not isinstance(user, str):
            raise InvalidOpInput("ollama.generate: `user` must be a string.")
        if not user:
            # Empty user prompt is almost always a caller bug — refuse loudly
            # instead of letting Ollama return a confusing empty response.
            raise InvalidOpInput("ollama.generate: `user` cannot be empty.")
        if len(user.encode("utf-8")) > _USER_MAX_BYTES:
            raise InvalidOpInput(
                f"ollama.generate: `user` exceeds {_USER_MAX_BYTES} bytes."
            )

        max_tokens = args.get("max_tokens", 4096)
        if not isinstance(max_tokens, int) or max_tokens <= 0 or max_tokens > 32_768:
            raise InvalidOpInput(
                "ollama.generate: `max_tokens` must be int in (0, 32768]."
            )

        temperature = args.get("temperature", 0.7)
        if not isinstance(temperature, (int, float)) or not 0.0 <= float(temperature) <= 2.0:
            raise InvalidOpInput(
                "ollama.generate: `temperature` must be number in [0.0, 2.0]."
            )

        json_mode = bool(args.get("json_mode", False))

        stop_raw = args.get("stop")
        stop: list[str] = []
        if stop_raw is not None:
            if not isinstance(stop_raw, list) or not all(
                isinstance(s, str) for s in stop_raw
            ):
                raise InvalidOpInput(
                    "ollama.generate: `stop` must be list of strings."
                )
            if len(stop_raw) > _STOP_MAX_ITEMS:
                raise InvalidOpInput(
                    f"ollama.generate: `stop` exceeds {_STOP_MAX_ITEMS} items."
                )
            for s in stop_raw:
                if len(s.encode("utf-8")) > _STOP_ITEM_MAX_BYTES:
                    raise InvalidOpInput(
                        f"ollama.generate: `stop[]` item exceeds {_STOP_ITEM_MAX_BYTES} bytes."
                    )
            stop = stop_raw

        # ── Build request ────────────────────────────────────────────
        messages: list[dict[str, str]] = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": user})

        body: dict[str, Any] = {
            "model": model,
            "messages": messages,
            "stream": False,
            "options": {
                "temperature": float(temperature),
                # Ollama calls it num_predict; treat -1 as "use model default".
                "num_predict": max_tokens,
            },
        }
        if stop:
            body["options"]["stop"] = stop
        if json_mode:
            body["format"] = "json"

        await ctx.progress(0.05, "dispatching")

        # ── HTTP call ────────────────────────────────────────────────
        url = f"{OLLAMA_BASE_URL}{OLLAMA_CHAT_PATH}"
        started = time.monotonic()
        try:
            async with httpx.AsyncClient(timeout=_DEFAULT_TIMEOUT_S) as client:
                resp = await client.post(url, json=body)
        except httpx.ConnectError as exc:
            raise RuntimeFailed(
                "Ollama daemon not reachable at 127.0.0.1:11434. "
                "Install + start Ollama (https://ollama.com)."
            ) from exc
        except httpx.TimeoutException as exc:
            raise RuntimeFailed(
                f"Ollama did not respond within {_DEFAULT_TIMEOUT_S:.0f}s "
                "(model may be loading on first use)."
            ) from exc
        elapsed_ms = int((time.monotonic() - started) * 1000)

        if resp.status_code == 404:
            raise RuntimeFailed(
                f"Ollama: model {model!r} not loaded. "
                "Run model_sync first or `ollama pull` the slug manually."
            )
        if resp.status_code >= 400:
            # Avoid surfacing Ollama's raw JSON to the SaaS user — it
            # leaks daemon-version and sometimes paths. Keep generic.
            raise RuntimeFailed(
                f"Ollama returned HTTP {resp.status_code} for {model!r}."
            )

        try:
            data = resp.json()
        except ValueError as exc:
            raise RuntimeFailed("Ollama returned non-JSON response.") from exc

        # ── Shape output per spec ─────────────────────────────────────
        # Ollama /api/chat success body:
        #   { "model", "message": {"role": "assistant", "content": "..."},
        #     "prompt_eval_count", "eval_count", "done", ... }
        message = data.get("message") or {}
        text = message.get("content")
        if not isinstance(text, str):
            raise RuntimeFailed(
                "Ollama response missing message.content; daemon protocol drift?"
            )

        await ctx.progress(1.0, "done")

        return {
            "text": text,
            "tokens_in": int(data.get("prompt_eval_count", 0) or 0),
            "tokens_out": int(data.get("eval_count", 0) or 0),
            "model": str(data.get("model", model)),
            "elapsed_ms": elapsed_ms,
        }


register(OllamaGenerateOp.name, OllamaGenerateOp)
