"""`system.echo` — debug-only op-runtime.

Returns its `msg:` arg verbatim. Useful for:
  - smoke-testing the dispatcher end-to-end without provisioning real
    models (workflow `[ {op: "system.echo", msg: "hi"} ]` works on any
    box, including CI)
  - reproducing scheduler / variable-substitution / output-shaping bugs
    without runtime side effects

The spec marks this op "Debug only, disabled in production." We honour
that intent by self-disabling unless the agent boots with
`HAON_AGENT_ENABLE_DEBUG_OPS=true` in env. Without that flag, the op
is NOT registered, so `get_op("system.echo")` raises a clean unknown-op
KeyError and the dispatcher surfaces it as such — no chance a SaaS
workflow accidentally relies on echo and gets surprised when we ship.
"""

from __future__ import annotations

import os
from typing import Any

from haon_agent.byoc.ops.base import InvalidOpInput, OpContext, OpRuntime, register


class EchoOp(OpRuntime):
    name = "system.echo"

    async def run(self, args: dict[str, Any], ctx: OpContext) -> dict[str, Any]:
        msg = args.get("msg")
        if not isinstance(msg, str):
            raise InvalidOpInput(
                "system.echo requires `msg: <string>`; "
                f"got {type(msg).__name__}."
            )
        # Spec caps string fields at 2 KB. Reject rather than truncate —
        # truncation would hide caller bugs.
        if len(msg) > 2048:
            raise InvalidOpInput(
                f"system.echo `msg` exceeds 2 KB cap ({len(msg)} bytes)."
            )
        await ctx.progress(1.0, "done")
        return {"msg": msg}


def _enabled() -> bool:
    """Gate registration on `HAON_AGENT_ENABLE_DEBUG_OPS=true` env.

    Returning False prevents `register()` from being called, so
    `get_op("system.echo")` errors as unknown — exactly what we want
    in prod where this op should be invisible.
    """
    return os.environ.get("HAON_AGENT_ENABLE_DEBUG_OPS", "").lower() in (
        "1",
        "true",
        "yes",
        "on",
    )


if _enabled():
    register(EchoOp.name, EchoOp)
