"""BYOC op-runtime registry.

Each op-runtime module in this package self-registers via `register()`
at import time, mapping a string `op` name (e.g. `"ollama.generate"`,
`"ffmpeg.normalize_audio"`) to an `OpRuntime` class. The workflow
executor calls `get_op(name)()` to instantiate per-step.

Why a separate registry from `haon_agent.runtime/__init__.py`:

  The marketplace `Runtime` protocol is byte-pipe semantics
  (`start(on_output)` + `push(bytes)` + `stop()`) — a session-long
  bidirectional pipe. The BYOC op-runtime is one-shot request/response
  (`async run(args) -> dict`) and is composed inside a single workflow
  alongside other op-runtimes. The two abstractions don't share a base
  class, so mixing them in one registry would invite type errors at
  dispatch time. Two registries, two products, zero ambiguity.
"""

from __future__ import annotations

from haon_agent.byoc.ops.base import OpRuntime, get_op, register, supported

# Import the concrete op-runtimes to trigger their `register()` calls.
# Each module is responsible for catching missing-system-dep errors at
# import time and either degrading (lazy import) or refusing to register
# itself so `get_op()` raises a clean KeyError instead of crashing the
# whole agent on import.
#
# Round 1 added `system.echo` (env-gated); Round 2 added `ollama.generate`;
# Round 3 added `whisper.transcribe` plus four `ffmpeg.*` ops.
from haon_agent.byoc.ops import echo as _echo        # noqa: F401  (Round 1, env-gated)
from haon_agent.byoc.ops import ollama as _ollama    # noqa: F401  (Round 2)
from haon_agent.byoc.ops import whisper as _whisper  # noqa: F401  (Round 3)
from haon_agent.byoc.ops import ffmpeg as _ffmpeg    # noqa: F401  (Round 3)

__all__ = [
    "OpRuntime",
    "get_op",
    "register",
    "supported",
]
