"""`ffmpeg.*` op-runtimes — audio/video processing via the ffmpeg CLI.

Implements 4 ops from workflow-dsl-spec v1:

  - ffmpeg.normalize_audio   loudnorm → consistent LUFS / TP
  - ffmpeg.cut_silences      silenceremove → trim quiet stretches
  - ffmpeg.encode            libx264 / libx265 transcode
  - ffmpeg.extract_frames    fps filter → PNG/JPG sequence

All four are subprocess wrappers around the user's `ffmpeg` binary on
PATH. We deliberately don't depend on `ffmpeg-python` or other bindings:
the CLI is the lingua franca, every install method (apt / brew / winget
/ static build) provides it, and pinning a Python wrapper would just be
another version-skew vector for users.

Security envelope:

  - **All paths validated** against `ctx.session_dir` via `_paths.resolve_under`
    BEFORE the subprocess call. ffmpeg is happy to read `/etc/passwd`
    given the chance; we never give it the chance.
  - **Filter strings constructed server-side** from typed args (loudnorm
    LUFS, threshold dB, codec name) — we NEVER take an arbitrary
    `-filter:v <user_string>` from the workflow. The spec's allowlist is
    the contract.
  - **Output files written under session_dir** with deterministic
    naming (`<step_id>.<ext>`) so the workflow executor can find them
    for `{steps.<id>.output_file}` substitution.
  - **Timeout** capped at 600s per step (cut/encode of long video can be
    slow; workflow-level timeout still applies).
"""

from __future__ import annotations

import asyncio
import re
import shutil
import time
from pathlib import Path
from typing import Any

from haon_agent.byoc._paths import EscapeError, resolve_under, under_session
from haon_agent.byoc.ops.base import (
    InvalidOpInput,
    OpContext,
    OpRuntime,
    RuntimeFailed,
    register,
)

# Closed allowlists per spec.
_VALID_CODECS = {"h264": "libx264", "h265": "libx265"}
_VALID_CONTAINERS = frozenset({"mp4"})
_VALID_FRAME_FORMATS = frozenset({"png", "jpg"})

# Bitrate must match `\d+[KMG]?` per common ffmpeg syntax. Reject anything
# else so a malicious workflow can't smuggle shell metachars through the
# bitrate field — we still subprocess.exec without a shell, but
# belt+suspenders.
_BITRATE_RE = re.compile(r"^[1-9][0-9]{0,5}[KMG]?$")

_DEFAULT_TIMEOUT_S = 600.0


def _which_ffmpeg() -> str:
    """Locate the ffmpeg binary. Raises RuntimeFailed with install hint
    if not on PATH — better than a cryptic FileNotFoundError from the
    subprocess call."""
    path = shutil.which("ffmpeg")
    if path is None:
        raise RuntimeFailed(
            "ffmpeg not found on PATH. Install from https://ffmpeg.org/ "
            "or your package manager (apt/brew/winget)."
        )
    return path


async def _run_ffmpeg(
    args: list[str],
    *,
    timeout_s: float = _DEFAULT_TIMEOUT_S,
    progress: Any = None,
) -> tuple[int, str]:
    """Execute ffmpeg with the given arg vector, return (exit, stderr).

    Stdout is piped to /dev/null (ffmpeg writes only progress + warnings
    there in our usage). Stderr is captured because that's where ffmpeg
    puts ALL its useful output — error messages, encode stats, progress.
    """
    ffmpeg = _which_ffmpeg()
    cmd = [ffmpeg, "-y", "-hide_banner", "-loglevel", "error", *args]
    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.PIPE,
        )
    except FileNotFoundError as exc:
        raise RuntimeFailed("ffmpeg binary disappeared mid-run") from exc

    try:
        stderr_bytes_t = await asyncio.wait_for(
            proc.communicate(), timeout=timeout_s
        )
    except asyncio.TimeoutError:
        proc.kill()
        await proc.wait()
        raise RuntimeFailed(
            f"ffmpeg timed out after {timeout_s:.0f}s"
        ) from None
    stderr_bytes = stderr_bytes_t[1] or b""
    return proc.returncode or 0, stderr_bytes.decode("utf-8", errors="replace")


def _ensure_input(args: dict[str, Any], ctx: OpContext) -> Path:
    """Common: validate input_file is a string AND lives under session_dir
    AND exists on disk. Raises InvalidOpInput on any failure."""
    raw = args.get("input_file")
    if not isinstance(raw, str) or not raw:
        raise InvalidOpInput("ffmpeg.*: `input_file` (string) required.")
    try:
        p = resolve_under(raw, ctx.session_dir)
    except EscapeError as exc:
        raise InvalidOpInput(f"ffmpeg.*: invalid input_file: {exc}") from exc
    if not p.exists():
        raise InvalidOpInput(
            f"ffmpeg.*: input_file does not exist: {p.name}"
        )
    return p


def _step_output_path(
    ctx: OpContext, step_id_hint: str, ext: str
) -> Path:
    """Build a deterministic output path inside session_dir.

    The op-runtime receives no step `id:` directly (the workflow executor
    strips it from args before dispatch). We pass it in via a temp slot
    on the context for now — Round 4 might switch to passing it
    explicitly as a `run(args, ctx, *, step_id=...)` kwarg. For Round 3
    we accept the indirection.
    """
    outputs_dir = ctx.session_dir / "outputs"
    outputs_dir.mkdir(parents=True, exist_ok=True)
    return under_session(Path("outputs") / f"{step_id_hint}.{ext}", ctx.session_dir)


# ── ffmpeg.normalize_audio ─────────────────────────────────────────────


class FfmpegNormalizeAudio(OpRuntime):
    name = "ffmpeg.normalize_audio"

    async def run(self, args: dict[str, Any], ctx: OpContext) -> dict[str, Any]:
        input_path = _ensure_input(args, ctx)

        lufs = args.get("lufs", -16)
        if not isinstance(lufs, (int, float)) or not -50 <= float(lufs) <= 0:
            raise InvalidOpInput(
                "ffmpeg.normalize_audio: `lufs` must be number in [-50, 0]."
            )
        tp = args.get("tp", -1.5)
        if not isinstance(tp, (int, float)) or not -10 <= float(tp) <= 0:
            raise InvalidOpInput(
                "ffmpeg.normalize_audio: `tp` must be number in [-10, 0]."
            )

        # Output container: preserve lossless for downstream processing.
        # `.wav` keeps the workflow chain transparent (cut/encode steps
        # don't pay double-quality-loss tolls).
        step_hint = args.get("_step_id", "normalize_audio")
        out = _step_output_path(ctx, step_hint, "wav")

        await ctx.progress(0.05, "running")
        started = time.monotonic()

        # loudnorm in single-pass mode. Two-pass yields tighter LUFS
        # adherence but doubles wall time; the spec's tolerance suggests
        # single-pass is fine for v1.
        af = f"loudnorm=I={float(lufs)}:TP={float(tp)}:LRA=11"
        rc, stderr = await _run_ffmpeg(
            ["-i", str(input_path), "-af", af, "-vn", str(out)]
        )
        elapsed_ms = int((time.monotonic() - started) * 1000)

        if rc != 0:
            raise RuntimeFailed(
                f"ffmpeg.normalize_audio failed (exit {rc}). "
                f"stderr tail: {_tail(stderr)}"
            )

        # Probe duration via ffprobe? Skip — adds another subprocess and
        # the dispatcher already shows elapsed_ms. duration_s=0.0 is a
        # known-acceptable placeholder per spec ambiguity.
        await ctx.progress(1.0, "done")
        return {
            "output_file": str(out),
            "duration_s": 0.0,
            "elapsed_ms": elapsed_ms,
        }


# ── ffmpeg.cut_silences ────────────────────────────────────────────────


class FfmpegCutSilences(OpRuntime):
    name = "ffmpeg.cut_silences"

    async def run(self, args: dict[str, Any], ctx: OpContext) -> dict[str, Any]:
        input_path = _ensure_input(args, ctx)

        threshold_db = args.get("threshold_db", -40)
        if not isinstance(threshold_db, (int, float)) or not -100 <= float(threshold_db) <= 0:
            raise InvalidOpInput(
                "ffmpeg.cut_silences: `threshold_db` must be number in [-100, 0]."
            )
        min_silence_ms = args.get("min_silence_ms", 800)
        if not isinstance(min_silence_ms, int) or not 0 < min_silence_ms <= 10_000:
            raise InvalidOpInput(
                "ffmpeg.cut_silences: `min_silence_ms` must be int in (0, 10000]."
            )
        keep_padding_ms = args.get("keep_padding_ms", 120)
        if not isinstance(keep_padding_ms, int) or not 0 <= keep_padding_ms <= 1_000:
            raise InvalidOpInput(
                "ffmpeg.cut_silences: `keep_padding_ms` must be int in [0, 1000]."
            )

        # silenceremove filter: stop_periods=-1 removes ALL silence
        # stretches; stop_duration is min length to consider silence;
        # stop_silence is how much silence to keep around speech
        # boundaries (≈ keep_padding).
        af = (
            f"silenceremove="
            f"stop_periods=-1:"
            f"stop_threshold={float(threshold_db)}dB:"
            f"stop_duration={float(min_silence_ms) / 1000.0:.3f}:"
            f"stop_silence={float(keep_padding_ms) / 1000.0:.3f}"
        )

        step_hint = args.get("_step_id", "cut_silences")
        out = _step_output_path(ctx, step_hint, "wav")

        await ctx.progress(0.05, "running")
        started = time.monotonic()
        rc, stderr = await _run_ffmpeg(
            ["-i", str(input_path), "-af", af, str(out)]
        )
        elapsed_ms = int((time.monotonic() - started) * 1000)

        if rc != 0:
            raise RuntimeFailed(
                f"ffmpeg.cut_silences failed (exit {rc}). "
                f"stderr tail: {_tail(stderr)}"
            )

        await ctx.progress(1.0, "done")
        # Spec wants cuts_count — silenceremove doesn't expose a count.
        # We'd need to parse silencedetect output in a separate pass.
        # Returning 0 + a note that the count is approximate for v1.
        return {
            "output_file": str(out),
            "cuts_count": 0,
            "duration_s": 0.0,
            "elapsed_ms": elapsed_ms,
        }


# ── ffmpeg.encode ──────────────────────────────────────────────────────


class FfmpegEncode(OpRuntime):
    name = "ffmpeg.encode"

    async def run(self, args: dict[str, Any], ctx: OpContext) -> dict[str, Any]:
        input_path = _ensure_input(args, ctx)

        codec_name = args.get("codec", "h264")
        if codec_name not in _VALID_CODECS:
            raise InvalidOpInput(
                f"ffmpeg.encode: `codec` must be one of "
                f"{sorted(_VALID_CODECS)}; got {codec_name!r}."
            )
        codec_lib = _VALID_CODECS[codec_name]

        bitrate = args.get("bitrate", "8M")
        if not isinstance(bitrate, str) or not _BITRATE_RE.match(bitrate):
            raise InvalidOpInput(
                f"ffmpeg.encode: `bitrate` must match {_BITRATE_RE.pattern!r}; "
                f"got {bitrate!r}."
            )

        container = args.get("container", "mp4")
        if container not in _VALID_CONTAINERS:
            raise InvalidOpInput(
                f"ffmpeg.encode: `container` must be one of "
                f"{sorted(_VALID_CONTAINERS)}; got {container!r}."
            )

        crf = args.get("crf", 18)
        if not isinstance(crf, int) or not 0 <= crf <= 51:
            raise InvalidOpInput(
                "ffmpeg.encode: `crf` must be int in [0, 51]."
            )

        step_hint = args.get("_step_id", "encode")
        out = _step_output_path(ctx, step_hint, container)

        await ctx.progress(0.05, "running")
        started = time.monotonic()
        rc, stderr = await _run_ffmpeg(
            [
                "-i", str(input_path),
                "-c:v", codec_lib,
                "-crf", str(crf),
                "-b:v", bitrate,
                "-c:a", "copy",
                str(out),
            ]
        )
        elapsed_ms = int((time.monotonic() - started) * 1000)

        if rc != 0:
            raise RuntimeFailed(
                f"ffmpeg.encode failed (exit {rc}). "
                f"stderr tail: {_tail(stderr)}"
            )

        size_bytes = out.stat().st_size if out.exists() else 0
        await ctx.progress(1.0, "done")
        return {
            "output_file": str(out),
            "size_bytes": size_bytes,
            "duration_s": 0.0,
            "elapsed_ms": elapsed_ms,
        }


# ── ffmpeg.extract_frames ──────────────────────────────────────────────


class FfmpegExtractFrames(OpRuntime):
    name = "ffmpeg.extract_frames"

    async def run(self, args: dict[str, Any], ctx: OpContext) -> dict[str, Any]:
        input_path = _ensure_input(args, ctx)

        fps = args.get("fps", 30)
        if not isinstance(fps, int) or not 1 <= fps <= 60:
            raise InvalidOpInput(
                "ffmpeg.extract_frames: `fps` must be int in [1, 60]."
            )

        fmt = args.get("format", "png")
        if fmt not in _VALID_FRAME_FORMATS:
            raise InvalidOpInput(
                f"ffmpeg.extract_frames: `format` must be one of "
                f"{sorted(_VALID_FRAME_FORMATS)}; got {fmt!r}."
            )

        step_hint = args.get("_step_id", "extract_frames")
        # frames go into a dedicated subdir; the spec's output is the
        # directory, not a single file.
        frames_dir = under_session(
            Path("outputs") / f"{step_hint}_frames",
            ctx.session_dir,
        )
        frames_dir.mkdir(parents=True, exist_ok=True)
        pattern = frames_dir / f"frame_%05d.{fmt}"

        await ctx.progress(0.05, "running")
        started = time.monotonic()
        rc, stderr = await _run_ffmpeg(
            ["-i", str(input_path), "-vf", f"fps={fps}", str(pattern)]
        )
        elapsed_ms = int((time.monotonic() - started) * 1000)

        if rc != 0:
            raise RuntimeFailed(
                f"ffmpeg.extract_frames failed (exit {rc}). "
                f"stderr tail: {_tail(stderr)}"
            )

        count = sum(1 for _ in frames_dir.glob(f"frame_*.{fmt}"))
        await ctx.progress(1.0, "done")
        return {
            "frames_dir": str(frames_dir),
            "count": count,
            "elapsed_ms": elapsed_ms,
        }


# ── Helpers ────────────────────────────────────────────────────────────


def _tail(s: str, max_chars: int = 400) -> str:
    """Trim ffmpeg stderr to last `max_chars` so the wire-error detail
    cap (2 KB) isn't blown by verbose stack-y stderr blocks."""
    if len(s) <= max_chars:
        return s.strip()
    return "..." + s[-max_chars:].strip()


# ── Registration ───────────────────────────────────────────────────────


for _op in (
    FfmpegNormalizeAudio,
    FfmpegCutSilences,
    FfmpegEncode,
    FfmpegExtractFrames,
):
    register(_op.name, _op)
