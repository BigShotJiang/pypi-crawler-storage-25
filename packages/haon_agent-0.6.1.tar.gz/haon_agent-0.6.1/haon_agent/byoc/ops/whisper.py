"""`whisper.transcribe` op-runtime — speech-to-text via faster-whisper.

Spec args (workflow-dsl-spec v1):

    {
        "id": "tx",
        "op": "whisper.transcribe",
        "input_file": "{steps.upload.path}",
        "model": "tiny" | "base" | "small" | "medium",
        "language": "pt" | "en" | "auto",
        "vad": true | false
    }

Output:

    { "text": "...",
      "segments": [{"start": float, "end": float, "text": "..."}],
      "language": "pt",
      "elapsed_ms": int }

Library: faster-whisper (CTranslate2 backend, ships pre-built wheels on
the major platforms, ~5x faster than openai-whisper and supports VAD
natively via Silero). Lazy-imported inside run() so users without the
optional extra can still load the agent module without ImportError.

Model loading is expensive (~1-3GB to disk on first use, ~200ms-1s warm).
We keep a module-level singleton per (model_size, device) tuple. Eviction
is manual — the agent process typically loads the same model for its
lifetime. Multi-process workers each get their own cache; that's fine,
the OS page cache shares the model file anyway.

Note on the model catalogue: the spec's `model` field ("tiny"/"base"/
"small"/"medium") refers to faster-whisper's own size names, NOT the
haon-model-registry slugs (which are LLMs only — see model-registry-spec
section "Initial Catalog"). Whisper models come from HuggingFace via
faster-whisper itself; we don't proxy them through the registry.
"""

from __future__ import annotations

import asyncio
import time
from typing import Any

from haon_agent.byoc._paths import EscapeError, resolve_under
from haon_agent.byoc.ops.base import (
    InvalidOpInput,
    OpContext,
    OpRuntime,
    RuntimeFailed,
    register,
)

# ── Spec-closed allowlists ──────────────────────────────────────────────
#
# Model sizes per spec. We deliberately don't expose "large" / "large-v3"
# here — they need 10GB+ VRAM and are out of scope for the agent's
# default hardware tier. Adding them requires a spec rev anyway.
_VALID_MODELS = frozenset({"tiny", "base", "small", "medium"})
_VALID_LANGS = frozenset({"pt", "en", "auto"})

# Module-level model cache: { (model_size, device) -> WhisperModel }.
# Populated on first call; access guarded by an asyncio.Lock to prevent
# duplicate loads when two workflows fire concurrently against an
# uncached model.
_model_cache: dict[tuple[str, str], Any] = {}
_cache_lock = asyncio.Lock()


def _lazy_import_faster_whisper():  # type: ignore[no-untyped-def]
    """Import faster-whisper on demand.

    Raises RuntimeFailed (not bare ImportError) so the workflow executor
    can map it to the wire RUNTIME_FAILED code with a user-actionable
    install hint. Re-raising ImportError would route to AGENT_BUG, which
    is wrong — the bug is missing dependency, fixable by the user.
    """
    try:
        from faster_whisper import WhisperModel
    except ImportError as exc:
        raise RuntimeFailed(
            "faster-whisper not installed. Run "
            "`pip install haon-agent[whisper]` to enable transcription."
        ) from exc
    return WhisperModel


async def _get_model(model_size: str, device: str):  # type: ignore[no-untyped-def]
    """Load (or fetch from cache) a WhisperModel for the given size.

    First call for an uncached (size, device) downloads weights from HF
    Hub — can take a minute. We hold the lock for the full load so
    concurrent callers serialise on the first cold start, then all
    proceed against the shared cached instance.
    """
    key = (model_size, device)
    async with _cache_lock:
        if key not in _model_cache:
            WhisperModel = _lazy_import_faster_whisper()
            # `compute_type="auto"` lets CTranslate2 pick int8 on CPU,
            # float16 on GPU. Manual tuning is a Round-6 concern.
            _model_cache[key] = await asyncio.to_thread(
                WhisperModel, model_size, device=device, compute_type="auto"
            )
        return _model_cache[key]


def _detect_device() -> str:
    """Pick "cuda" if NVIDIA visible, else "auto" (faster-whisper picks CPU).

    Conservative: faster-whisper's own "auto" handles CPU fallback fine
    if CUDA isn't available. We only force "cuda" when we explicitly see
    NVIDIA so the failure mode is clear if CUDA setup is half-broken.
    """
    try:
        import torch  # noqa: PLC0415

        if torch.cuda.is_available():
            return "cuda"
    except ImportError:
        pass
    return "auto"


class WhisperTranscribeOp(OpRuntime):
    name = "whisper.transcribe"

    async def run(self, args: dict[str, Any], ctx: OpContext) -> dict[str, Any]:
        # ── Argument validation ──────────────────────────────────────
        input_file_raw = args.get("input_file")
        if not isinstance(input_file_raw, str) or not input_file_raw:
            raise InvalidOpInput(
                "whisper.transcribe: `input_file` (string) required."
            )
        try:
            input_path = resolve_under(input_file_raw, ctx.session_dir)
        except EscapeError as exc:
            raise InvalidOpInput(
                f"whisper.transcribe: invalid input_file path: {exc}"
            ) from exc
        if not input_path.exists():
            raise InvalidOpInput(
                f"whisper.transcribe: input_file does not exist: "
                f"{input_path.name}"
            )

        model = args.get("model", "small")
        if model not in _VALID_MODELS:
            raise InvalidOpInput(
                f"whisper.transcribe: `model` must be one of "
                f"{sorted(_VALID_MODELS)}; got {model!r}."
            )

        language = args.get("language", "auto")
        if language not in _VALID_LANGS:
            raise InvalidOpInput(
                f"whisper.transcribe: `language` must be one of "
                f"{sorted(_VALID_LANGS)}; got {language!r}."
            )

        vad = bool(args.get("vad", True))

        # ── Load model + transcribe ──────────────────────────────────
        await ctx.progress(0.05, "loading_model")
        device = _detect_device()
        m = await _get_model(model, device)

        await ctx.progress(0.10, "transcribing")
        # faster-whisper's transcribe is sync + CPU/GPU-bound; offload
        # to a worker thread so the asyncio event loop stays responsive
        # for the progress callback + parallel control frames.
        started = time.monotonic()

        def _do_transcribe():  # type: ignore[no-untyped-def]
            segments_iter, info = m.transcribe(
                str(input_path),
                language=None if language == "auto" else language,
                vad_filter=vad,
            )
            # Materialise immediately — the iterator is lazy, and we want
            # the elapsed_ms measurement to include actual inference work,
            # not just iterator setup.
            return list(segments_iter), info

        try:
            seg_list, info = await asyncio.to_thread(_do_transcribe)
        except Exception as exc:  # noqa: BLE001 — surface as RuntimeFailed
            # Catches model-load errors, audio-decode errors, OOM, etc.
            raise RuntimeFailed(
                f"whisper transcription failed: {type(exc).__name__}: {exc}"
            ) from exc
        elapsed_ms = int((time.monotonic() - started) * 1000)

        # ── Shape output per spec ─────────────────────────────────────
        # faster-whisper Segment fields: start, end, text, words, ...
        # The spec defines only start/end/text — strip the rest.
        segments_out = [
            {"start": float(s.start), "end": float(s.end), "text": s.text}
            for s in seg_list
        ]
        full_text = "".join(s["text"] for s in segments_out)

        await ctx.progress(1.0, "done")

        return {
            "text": full_text,
            "segments": segments_out,
            "language": info.language,
            "elapsed_ms": elapsed_ms,
        }


register(WhisperTranscribeOp.name, WhisperTranscribeOp)
