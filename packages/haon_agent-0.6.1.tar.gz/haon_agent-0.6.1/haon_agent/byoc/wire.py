"""Wire-protocol envelopes for BYOC dispatch.

Mirrors the four message shapes documented in workflow-dsl-spec v1
(gist d26ea943, section "Wire Protocol"):

  Browser → Agent:
    {"msg": "workflow", "v": 1, "workflow": {...}, "session_id": "<uuid>"}

  Agent → Broker:
    {"msg": "progress", "step_id": "norm", "pct": 0.45, "stage": "running"}
    {"msg": "done",     "session_id": "...", "output": <...>, "steps": {...},
                        "elapsed_ms": int}
    {"msg": "error",    "session_id": "...", "step_id": "<id or null>",
                        "code": "<enum>", "detail": "<human msg>"}

Pydantic models on the receive side validate strict shape — the dispatcher
in `agent.py` calls `WorkflowEnvelope.model_validate(frame)` and any
deviation surfaces as an InvalidWorkflowError that we surface back as an
INVALID_INPUT error envelope (never a 500 crash).

Outbound shapes are plain dicts produced via `progress() / done() /
error()` helpers; we keep them functional rather than pydantic because
they're write-side and never validated by us.

Note: the spec caps workflow JSON at 32 KB total, each step ≤ 4 KB, string
fields ≤ 2 KB. Those caps are enforced in `workflow_dsl.parse()`, not
here — wire.py only guarantees shape, not size.
"""

from __future__ import annotations

import uuid
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

# ── Error code enum ─────────────────────────────────────────────────────
#
# Closed set matching the spec. Adding a new code requires bumping the
# wire version and the haonhub dispatcher schema.
ErrorCode = Literal[
    "TIMEOUT",
    "MODEL_NOT_FOUND",
    "INVALID_INPUT",
    "RUNTIME_FAILED",
    "AGENT_BUG",
]


# ── Inbound: workflow envelope ──────────────────────────────────────────


class WorkflowEnvelope(BaseModel):
    """Outer frame for a workflow dispatch from the SaaS browser.

    Validates the envelope shape only. The inner `workflow` dict is
    forwarded to `workflow_dsl.parse()` which validates the DSL body
    (steps, ops, var-substitution syntax, etc.).
    """

    model_config = ConfigDict(extra="forbid")

    msg: Literal["workflow"]
    v: Literal[1] = Field(..., description="Wire-protocol major version.")
    session_id: uuid.UUID
    workflow: dict[str, Any]


# ── Outbound helpers (write-side; never validated by us) ────────────────


# Stage labels are open-ended on purpose — runtimes can use whatever
# string is meaningful (e.g. "downloading_model", "encoding", "running").
# The dispatcher renders them as opaque status text.
ProgressStage = str


def progress(
    *,
    step_id: str,
    pct: float,
    stage: ProgressStage = "running",
) -> dict[str, Any]:
    """Build a progress frame for a step.

    `pct` is clamped to [0.0, 1.0] — sending out-of-range would confuse
    the dispatcher's UI and we'd rather catch it here than mid-pipeline.
    """
    return {
        "msg": "progress",
        "step_id": step_id,
        "pct": max(0.0, min(1.0, pct)),
        "stage": stage,
    }


def done(
    *,
    session_id: uuid.UUID | str,
    output: Any,
    steps: dict[str, Any],
    elapsed_ms: int,
) -> dict[str, Any]:
    """Build the terminal success frame. `output` shape is OutputSpec-dependent
    (text|json|file|files); the executor in `workflow_dsl` is responsible
    for shaping it per the workflow's `output:` block before passing here.
    """
    return {
        "msg": "done",
        "session_id": str(session_id),
        "output": output,
        "steps": steps,
        "elapsed_ms": int(elapsed_ms),
    }


def error(
    *,
    session_id: uuid.UUID | str,
    code: ErrorCode,
    detail: str,
    step_id: str | None = None,
) -> dict[str, Any]:
    """Build the terminal error frame.

    Spec calls for "human msg, no stack trace" in `detail` — callers
    should strip Python tracebacks before passing here. The dispatcher
    surfaces this text to the SaaS user verbatim.
    """
    # Belt + suspenders: trim to the spec's 2 KB string-field cap so a
    # runaway error string never blows the broker frame budget.
    trimmed = detail if len(detail) <= 2048 else detail[:2045] + "..."
    return {
        "msg": "error",
        "session_id": str(session_id),
        "step_id": step_id,
        "code": code,
        "detail": trimmed,
    }
