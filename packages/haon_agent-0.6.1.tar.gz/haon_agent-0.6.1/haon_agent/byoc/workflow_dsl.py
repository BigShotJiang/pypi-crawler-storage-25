"""Workflow DSL parser + executor.

This module owns the top-level workflow lifecycle:

  1. `parse(raw_dict)`  →  validated, typed `Workflow` (rejects malformed
                           shapes, invalid op names, undefined refs,
                           cyclic fallbacks, oversize steps).
  2. `execute(workflow, *, session_id, session_dir, on_progress)`
                        →  iterates steps in order, substitutes variables,
                           dispatches to `byoc.ops`, handles `on_error`,
                           shapes final output per `OutputSpec`. Returns
                           a wire-ready done/error envelope dict.

Spec: workflow-dsl-spec.md v1 (gist d26ea943).

Design notes:

  - Parsing is pure (no I/O). Re-parsing the same dict twice yields the
    same `Workflow`. The execute() layer is the only one that touches
    the file system + network.

  - Step `id`s are validated unique at parse. References (`{steps.X.f}`)
    to forward / non-existent steps raise at parse, not at execute —
    catches typos before the user pays for inference.

  - Variable substitution rules follow the spec literally: reject `..`,
    `/`, control chars, or > 2 KB AFTER substitution. The strict
    interpretation will trip up file-path references (whisper input from
    `{steps.upload.path}`); when that comes up in real workflows we
    renegotiate with the spec maintainers rather than silently relax.

  - on_error: "fail" (default) | "skip" (set output to None, continue) |
    "fallback:<id>" (jump to that step, skipping intermediate ones).
    Fallback target must exist and come AFTER the current step —
    enforced at parse time.

  - Output shaping: text/json complete in Round 4; file/files return the
    path/dir verbatim and rely on Round 6 to actually stream bytes back
    over the DataChannel. The shape on the wire is the same, just the
    bytes pipe is missing until Round 6.
"""

from __future__ import annotations

import json
import re
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Awaitable, Callable, Literal

from haon_agent.byoc import wire
from haon_agent.byoc.ops import get_op, supported as supported_ops
from haon_agent.byoc.ops.base import (
    InvalidOpInput,
    OpContext,
    RuntimeFailed,
)


# ── Errors ──────────────────────────────────────────────────────────────


class InvalidWorkflowError(ValueError):
    """Raised by `parse()` and during variable-substitution at execute
    time when the workflow shape, references, or substituted values
    violate the spec. Mapped to wire INVALID_INPUT."""


# ── Parsed types ────────────────────────────────────────────────────────


# Spec-closed set. Adding a new runtime is a v2 wire bump.
_VALID_RUNTIMES = frozenset({"ollama", "ffmpeg", "whisper", "multi"})
_VALID_OUTPUT_TYPES = frozenset({"text", "json", "file", "files"})

# Spec size caps. We enforce per-step + per-substituted-value here;
# total workflow JSON size is the dispatcher's responsibility (it sees
# the raw bytes).
_STEP_JSON_MAX_BYTES = 4 * 1024
_SUBSTITUTED_VALUE_MAX_BYTES = 2 * 1024

# Step id format. Constrained to keep refs unambiguous and shell-safe
# (we never shell out using the id, but defence in depth).
_STEP_ID_RE = re.compile(r"^[a-zA-Z][a-zA-Z0-9_]{0,31}$")

# Op name format: dotted namespace.action. Enforced at parse so a typo
# like "ollama-generate" gets caught before runtime registry lookup.
_OP_NAME_RE = re.compile(r"^[a-z][a-z0-9_]*\.[a-z][a-z0-9_]*$")

# Variable reference syntax: `{namespace.path.field}`. Spec allows
# {inputs.X} and {steps.X.Y}. We compile permissively + validate the
# resolved path in _resolve_ref().
_VAR_RE = re.compile(r"\{([a-zA-Z][a-zA-Z0-9_.]*)\}")


@dataclass(frozen=True)
class Step:
    id: str
    op: str
    on_error: Literal["fail", "skip"] | tuple[Literal["fallback"], str]
    args: dict[str, Any]  # everything except id/op/on_error (with templates intact)


@dataclass(frozen=True)
class OutputSpec:
    type: Literal["text", "json", "file", "files"]
    template: str  # raw `{steps.X.Y}` reference; resolved at execute time
    filename: str | None = None
    json_schema: dict[str, Any] | None = None


@dataclass(frozen=True)
class Workflow:
    version: int
    runtime: str
    inputs: dict[str, Any]
    timeout_ms: int
    tool_id: str | None
    steps: list[Step]
    output: OutputSpec


# ── Parser ──────────────────────────────────────────────────────────────


def parse(raw: dict[str, Any]) -> Workflow:
    """Validate + normalise the workflow dict into a typed `Workflow`.

    Raises `InvalidWorkflowError` on any spec violation. Does not touch
    the file system or network — pure validation.
    """
    if not isinstance(raw, dict):
        raise InvalidWorkflowError(
            f"workflow must be an object, got {type(raw).__name__}."
        )

    # version: only v1 supported in this agent rev.
    version = raw.get("version")
    if version != 1:
        raise InvalidWorkflowError(
            f"workflow.version must be 1; got {version!r}."
        )

    # runtime tag (mostly advisory — execute() checks each step's op
    # against the registered allowlist anyway).
    runtime = raw.get("runtime")
    if runtime not in _VALID_RUNTIMES:
        raise InvalidWorkflowError(
            f"workflow.runtime must be one of {sorted(_VALID_RUNTIMES)}; "
            f"got {runtime!r}."
        )

    # session block (tool_id + timeout_ms). Both optional in the wire
    # shape but we apply defaults.
    session = raw.get("session", {})
    if not isinstance(session, dict):
        raise InvalidWorkflowError("workflow.session must be an object.")
    tool_id = session.get("tool_id")
    if tool_id is not None and not isinstance(tool_id, str):
        raise InvalidWorkflowError("session.tool_id must be a string.")
    timeout_ms = session.get("timeout_ms", 120_000)
    if not isinstance(timeout_ms, int) or not 1 <= timeout_ms <= 30 * 60 * 1000:
        raise InvalidWorkflowError(
            "session.timeout_ms must be int in [1, 1800000] (≤ 30min)."
        )

    # inputs: free-shape dict of literals. Type-check the container
    # only; each op-runtime validates the actual values it consumes.
    inputs = raw.get("inputs", {})
    if not isinstance(inputs, dict):
        raise InvalidWorkflowError("workflow.inputs must be an object.")

    # steps[]: ordered list of Step objects.
    steps_raw = raw.get("steps")
    if not isinstance(steps_raw, list) or not steps_raw:
        raise InvalidWorkflowError(
            "workflow.steps must be a non-empty array."
        )
    steps: list[Step] = []
    seen_ids: set[str] = set()
    registered_ops = set(supported_ops())
    for idx, step_raw in enumerate(steps_raw):
        step = _parse_step(step_raw, idx, seen_ids, registered_ops)
        steps.append(step)
        seen_ids.add(step.id)

    # Validate fallback targets exist + come after the source. Done in a
    # second pass so forward refs to later steps are legal.
    for src_idx, step in enumerate(steps):
        if isinstance(step.on_error, tuple) and step.on_error[0] == "fallback":
            target_id = step.on_error[1]
            target_idx = next(
                (i for i, s in enumerate(steps) if s.id == target_id),
                None,
            )
            if target_idx is None:
                raise InvalidWorkflowError(
                    f"step {step.id!r}: fallback target {target_id!r} "
                    f"does not exist."
                )
            if target_idx <= src_idx:
                raise InvalidWorkflowError(
                    f"step {step.id!r}: fallback target {target_id!r} "
                    f"must come AFTER this step."
                )

    # output spec
    output_raw = raw.get("output")
    if not isinstance(output_raw, dict):
        raise InvalidWorkflowError("workflow.output must be an object.")
    output = _parse_output(output_raw, seen_ids)

    return Workflow(
        version=version,
        runtime=runtime,
        inputs=inputs,
        timeout_ms=timeout_ms,
        tool_id=tool_id,
        steps=steps,
        output=output,
    )


def _parse_step(
    raw: Any,
    idx: int,
    seen_ids: set[str],
    registered_ops: set[str],
) -> Step:
    if not isinstance(raw, dict):
        raise InvalidWorkflowError(
            f"steps[{idx}]: must be an object, got {type(raw).__name__}."
        )

    # Per-step size cap (spec: 4 KB).
    try:
        size = len(json.dumps(raw).encode("utf-8"))
    except (TypeError, ValueError) as exc:
        raise InvalidWorkflowError(
            f"steps[{idx}]: not JSON-serialisable: {exc}"
        ) from exc
    if size > _STEP_JSON_MAX_BYTES:
        raise InvalidWorkflowError(
            f"steps[{idx}]: size {size} bytes exceeds 4 KB cap."
        )

    sid = raw.get("id")
    if not isinstance(sid, str) or not _STEP_ID_RE.match(sid):
        raise InvalidWorkflowError(
            f"steps[{idx}].id must match {_STEP_ID_RE.pattern!r}; got {sid!r}."
        )
    if sid in seen_ids:
        raise InvalidWorkflowError(
            f"steps[{idx}].id={sid!r} duplicates a prior step's id."
        )

    op_name = raw.get("op")
    if not isinstance(op_name, str) or not _OP_NAME_RE.match(op_name):
        raise InvalidWorkflowError(
            f"steps[{idx}].op must match {_OP_NAME_RE.pattern!r}; got {op_name!r}."
        )
    if op_name not in registered_ops:
        raise InvalidWorkflowError(
            f"steps[{idx}].op={op_name!r} not in registered ops "
            f"({sorted(registered_ops)})."
        )

    on_error_raw = raw.get("on_error", "fail")
    on_error: Literal["fail", "skip"] | tuple[Literal["fallback"], str]
    if on_error_raw == "fail" or on_error_raw == "skip":
        on_error = on_error_raw
    elif isinstance(on_error_raw, str) and on_error_raw.startswith("fallback:"):
        target = on_error_raw[len("fallback:"):]
        if not target or not _STEP_ID_RE.match(target):
            raise InvalidWorkflowError(
                f"steps[{idx}].on_error: malformed fallback target "
                f"{target!r}; must match step id format."
            )
        on_error = ("fallback", target)
    else:
        raise InvalidWorkflowError(
            f"steps[{idx}].on_error must be 'fail' | 'skip' | "
            f"'fallback:<id>'; got {on_error_raw!r}."
        )

    # Strip the envelope keys; everything else is op-args (templates
    # may still contain `{ref}` placeholders — resolution happens at
    # execute time).
    args = {k: v for k, v in raw.items() if k not in ("id", "op", "on_error")}

    return Step(id=sid, op=op_name, on_error=on_error, args=args)


def _parse_output(raw: dict[str, Any], known_step_ids: set[str]) -> OutputSpec:
    out_type = raw.get("type")
    if out_type not in _VALID_OUTPUT_TYPES:
        raise InvalidWorkflowError(
            f"output.type must be one of {sorted(_VALID_OUTPUT_TYPES)}; "
            f"got {out_type!r}."
        )
    template = raw.get("from")
    if not isinstance(template, str) or not template:
        raise InvalidWorkflowError("output.from must be a non-empty string.")
    # Lightweight check: any `{steps.X.Y}` refs in the template must
    # point at a defined step. (We don't pre-validate `{inputs.K}`
    # because inputs are free-shape.)
    for m in _VAR_RE.finditer(template):
        parts = m.group(1).split(".")
        if parts and parts[0] == "steps":
            if len(parts) < 3:
                raise InvalidWorkflowError(
                    f"output.from: malformed steps ref {m.group(0)!r}."
                )
            if parts[1] not in known_step_ids:
                raise InvalidWorkflowError(
                    f"output.from references unknown step {parts[1]!r}."
                )

    filename = raw.get("filename")
    if filename is not None and not isinstance(filename, str):
        raise InvalidWorkflowError("output.filename must be a string.")

    schema = raw.get("schema")
    if schema is not None and not isinstance(schema, dict):
        raise InvalidWorkflowError("output.schema must be an object.")

    return OutputSpec(
        type=out_type,
        template=template,
        filename=filename,
        json_schema=schema,
    )


# ── Variable substitution ──────────────────────────────────────────────


def _resolve_ref(
    ref_path: str,
    inputs: dict[str, Any],
    step_outputs: dict[str, dict[str, Any] | None],
) -> Any:
    """Resolve a single dotted reference. Caller is responsible for
    wrapping the result in str() / size + content checks."""
    parts = ref_path.split(".")
    if parts[0] == "inputs":
        if len(parts) != 2:
            raise InvalidWorkflowError(
                f"reference {ref_path!r}: inputs takes one component."
            )
        key = parts[1]
        if key not in inputs:
            raise InvalidWorkflowError(f"unknown input: {key!r}.")
        return inputs[key]
    if parts[0] == "steps":
        if len(parts) != 3:
            raise InvalidWorkflowError(
                f"reference {ref_path!r}: steps takes two components."
            )
        sid, field = parts[1], parts[2]
        if sid not in step_outputs:
            raise InvalidWorkflowError(
                f"reference to step {sid!r} that hasn't executed yet "
                "(forward refs disallowed)."
            )
        output = step_outputs[sid]
        if output is None:
            raise InvalidWorkflowError(
                f"step {sid!r} was skipped (output=null); cannot reference."
            )
        if field not in output:
            raise InvalidWorkflowError(
                f"step {sid!r} has no field {field!r} "
                f"(has: {sorted(output)})."
            )
        return output[field]
    raise InvalidWorkflowError(
        f"reference {ref_path!r}: namespace must be 'inputs' or 'steps'."
    )


def _substitute(
    value: Any,
    inputs: dict[str, Any],
    step_outputs: dict[str, dict[str, Any] | None],
) -> Any:
    """Recursively walk a value, replacing `{ref}` templates in strings.

    Non-string scalars + structures pass through unchanged (except dict
    values + list items are recursively substituted). The spec says
    "substitution is string-only" — we honour that: only strings get
    `{...}` templates resolved, everything else is verbatim.
    """
    if isinstance(value, str):
        return _substitute_string(value, inputs, step_outputs)
    if isinstance(value, dict):
        return {k: _substitute(v, inputs, step_outputs) for k, v in value.items()}
    if isinstance(value, list):
        return [_substitute(v, inputs, step_outputs) for v in value]
    return value


def _substitute_string(
    template: str,
    inputs: dict[str, Any],
    step_outputs: dict[str, dict[str, Any] | None],
) -> str:
    """Apply variable substitution to a single string. Enforces spec
    rules on the SUBSTITUTED VALUE: reject `..`, `/`, control chars,
    or values > 2 KB."""
    def _replace(m: re.Match[str]) -> str:
        path = m.group(1)
        v = _resolve_ref(path, inputs, step_outputs)
        if not isinstance(v, (str, int, float, bool)):
            raise InvalidWorkflowError(
                f"reference {path!r} resolves to non-primitive "
                f"{type(v).__name__}; only str/int/float/bool allowed."
            )
        s = str(v)
        if len(s.encode("utf-8")) > _SUBSTITUTED_VALUE_MAX_BYTES:
            raise InvalidWorkflowError(
                f"reference {path!r} resolved to {len(s)} bytes "
                f"(exceeds 2 KB cap)."
            )
        if ".." in s:
            raise InvalidWorkflowError(
                f"reference {path!r} contains '..' (path-traversal sentinel)."
            )
        if any(ord(c) < 0x20 for c in s):
            raise InvalidWorkflowError(
                f"reference {path!r} contains control character."
            )
        # Spec calls for rejecting '/' too. Strict interpretation —
        # path-like references will fail until either:
        #   (a) the workflow author bypasses substitution + uses
        #       literal absolute paths in `inputs:`, OR
        #   (b) we negotiate a spec relax for file refs.
        if "/" in s:
            raise InvalidWorkflowError(
                f"reference {path!r} contains '/' (forbidden in substituted "
                "values per spec). Use inputs literal instead."
            )
        return s

    return _VAR_RE.sub(_replace, template)


# ── Output shaping ─────────────────────────────────────────────────────


def _shape_output(
    output: OutputSpec,
    inputs: dict[str, Any],
    step_outputs: dict[str, dict[str, Any] | None],
) -> Any:
    """Build the workflow's terminal output payload per OutputSpec.

    For text/json the value is materialised here. For file/files we
    return the path/dir string verbatim — Round 6 (agent dispatch
    wiring) is responsible for streaming the actual bytes/zip over
    the DataChannel before the done frame fires.
    """
    raw_value = _substitute_string(output.template, inputs, step_outputs)

    if output.type == "text":
        return raw_value

    if output.type == "json":
        try:
            parsed = json.loads(raw_value)
        except json.JSONDecodeError as exc:
            raise RuntimeFailed(
                f"output.from did not yield valid JSON: {exc.msg}"
            ) from exc
        if output.json_schema is not None:
            _validate_json_schema(parsed, output.json_schema)
        return parsed

    if output.type in ("file", "files"):
        # Round 4 returns the path as-is; Round 6 streams.
        return {
            "type": output.type,
            "path": raw_value,
            "filename": output.filename,
        }

    raise InvalidWorkflowError(f"unknown output.type {output.type!r}")


def _validate_json_schema(payload: Any, schema: dict[str, Any]) -> None:
    """Optional JSON Schema validation. Lazy-imports `jsonschema` so
    workflows that don't use `output.schema` don't pull the dep."""
    try:
        import jsonschema  # type: ignore[import-untyped]  # noqa: PLC0415
    except ImportError as exc:  # pragma: no cover — install hint path
        raise RuntimeFailed(
            "output.schema validation requested but `jsonschema` not "
            "installed. Install haon-agent[jsonschema] or omit the "
            "schema field."
        ) from exc
    try:
        jsonschema.validate(instance=payload, schema=schema)
    except jsonschema.ValidationError as exc:
        raise RuntimeFailed(
            f"output failed JSON Schema validation: {exc.message}"
        ) from exc


# ── Executor ───────────────────────────────────────────────────────────


@dataclass
class _ExecutionState:
    """Mutable state threaded through step execution. Keeping it
    structured makes it easier to inspect from tests / debug than
    threading half a dozen positional args."""

    workflow: Workflow
    session_id: uuid.UUID
    session_dir: Path
    on_progress: Callable[[dict[str, Any]], Awaitable[None]]
    step_outputs: dict[str, dict[str, Any] | None] = field(default_factory=dict)


async def execute(
    workflow: Workflow,
    *,
    session_id: uuid.UUID,
    session_dir: Path,
    on_progress: Callable[[dict[str, Any]], Awaitable[None]],
) -> dict[str, Any]:
    """Run the workflow. Returns a wire-ready envelope (done or error).

    Never raises — every failure path is translated to an error
    envelope. The caller (agent dispatch) just forwards whatever this
    returns to the broker.
    """
    state = _ExecutionState(
        workflow=workflow,
        session_id=session_id,
        session_dir=session_dir,
        on_progress=on_progress,
    )
    wf_started = time.monotonic()

    # Step iteration with fallback-driven skipping. We index into the
    # step list manually because fallback jumps need to set the cursor.
    cursor = 0
    while cursor < len(workflow.steps):
        step = workflow.steps[cursor]
        try:
            output = await _execute_step(step, state)
        except InvalidWorkflowError as exc:
            return wire.error(
                session_id=session_id,
                step_id=step.id,
                code="INVALID_INPUT",
                detail=str(exc),
            )
        except InvalidOpInput as exc:
            return wire.error(
                session_id=session_id,
                step_id=step.id,
                code="INVALID_INPUT",
                detail=str(exc),
            )
        except RuntimeFailed as exc:
            handled = _handle_step_failure(step, workflow, exc)
            if handled == "fail":
                return wire.error(
                    session_id=session_id,
                    step_id=step.id,
                    code="RUNTIME_FAILED",
                    detail=str(exc),
                )
            if handled == "skip":
                state.step_outputs[step.id] = None
                cursor += 1
                continue
            # fallback:<id> → seek cursor to target index
            assert isinstance(step.on_error, tuple)
            target = step.on_error[1]
            cursor = next(i for i, s in enumerate(workflow.steps) if s.id == target)
            state.step_outputs[step.id] = None
            continue
        except KeyError as exc:
            # `get_op()` raises KeyError on unknown op. Parser should have
            # caught this — if it didn't, the registry changed between
            # parse and execute (e.g. an op was unregistered). Map to
            # MODEL_NOT_FOUND per spec error set.
            return wire.error(
                session_id=session_id,
                step_id=step.id,
                code="MODEL_NOT_FOUND",
                detail=str(exc),
            )
        except Exception as exc:  # noqa: BLE001 — wire as AGENT_BUG
            return wire.error(
                session_id=session_id,
                step_id=step.id,
                code="AGENT_BUG",
                detail=f"{type(exc).__name__}: {exc}",
            )

        state.step_outputs[step.id] = output
        cursor += 1

    # All steps complete — shape the final output.
    try:
        shaped = _shape_output(
            workflow.output, workflow.inputs, state.step_outputs
        )
    except InvalidWorkflowError as exc:
        return wire.error(
            session_id=session_id,
            code="INVALID_INPUT",
            detail=str(exc),
        )
    except RuntimeFailed as exc:
        return wire.error(
            session_id=session_id,
            code="RUNTIME_FAILED",
            detail=str(exc),
        )

    elapsed_ms = int((time.monotonic() - wf_started) * 1000)
    return wire.done(
        session_id=session_id,
        output=shaped,
        steps={k: v for k, v in state.step_outputs.items() if v is not None},
        elapsed_ms=elapsed_ms,
    )


async def _execute_step(
    step: Step,
    state: _ExecutionState,
) -> dict[str, Any]:
    """Run one step end-to-end: substitute → instantiate op → run."""
    # Resolve all template refs in args. Errors here are InvalidWorkflow
    # (caller maps to INVALID_INPUT).
    resolved_args = _substitute(
        step.args, state.workflow.inputs, state.step_outputs
    )
    # Pass step.id as `_step_id` so file-emitting ops can derive
    # deterministic output filenames. Underscore-prefixed so it never
    # shadows a real spec field.
    if isinstance(resolved_args, dict):
        resolved_args.setdefault("_step_id", step.id)

    op = get_op(step.op)

    # Per-step progress forwarder — the op's OpContext.progress callback
    # forwards into the workflow-level on_progress with step_id attached.
    async def _step_progress(pct: float, stage: str) -> None:
        await state.on_progress(
            wire.progress(step_id=step.id, pct=pct, stage=stage)
        )

    ctx = OpContext(
        session_id=str(state.session_id),
        session_dir=state.session_dir,
        progress=_step_progress,
    )
    return await op.run(resolved_args, ctx)


def _handle_step_failure(
    step: Step,
    workflow: Workflow,
    exc: RuntimeFailed,
) -> Literal["fail", "skip", "fallback"]:
    """Map step's on_error to the dispatcher's next action.

    Doesn't actually JUMP — the caller does the cursor manipulation —
    just returns the action token.
    """
    if step.on_error == "fail":
        return "fail"
    if step.on_error == "skip":
        return "skip"
    # tuple ("fallback", target_id)
    return "fallback"


__all__ = [
    "InvalidWorkflowError",
    "OutputSpec",
    "Step",
    "Workflow",
    "execute",
    "parse",
]
