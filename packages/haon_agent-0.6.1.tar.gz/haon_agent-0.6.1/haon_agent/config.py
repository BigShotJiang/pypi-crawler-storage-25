"""Agent configuration.

Config lives at `~/.haon/agent.toml`. The file is plain TOML so operators can
hand-edit. Secrets (API key, machine registration tokens) are stored
separately via `credentials` — never in this file.
"""

from __future__ import annotations

import logging
import os
import tomllib
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)


def _atomic_write_text(path: Path, data: str, mode: int) -> None:
    """Atomically write `data` to `path` with permission `mode`.

    Strategy: write to a sibling tempfile in the same directory, fsync it,
    then `os.replace(tmp, target)`. `os.replace` is atomic on both POSIX
    and Windows so a concurrent reader never sees a half-populated file.

    If the tempfile write or fsync raises, the original file is left
    untouched (no corruption). If `os.replace` itself raises, the tempfile
    is intentionally left in place at `{path}.tmp.{pid}` so the user can
    diagnose; we log that at WARN level.

    Directory fsync is done on POSIX to flush the rename to disk; on
    Windows `os.open(dir, O_RDONLY)` is not supported and is unnecessary
    — NTFS commits metadata for rename as part of the transaction.
    """
    tmp_path = path.with_name(f"{path.name}.tmp.{os.getpid()}")
    data_bytes = data.encode("utf-8")

    # Write + fsync the tempfile. If anything fails here, clean up the
    # tempfile and re-raise — the real file is still intact.
    try:
        fd = os.open(
            str(tmp_path),
            os.O_WRONLY | os.O_CREAT | os.O_TRUNC,
            mode,
        )
        try:
            os.write(fd, data_bytes)
            os.fsync(fd)
        finally:
            os.close(fd)
        # Ensure the permission bits stick (os.open honours umask on some
        # platforms; chmod makes it explicit).
        try:
            os.chmod(tmp_path, mode)
        except (PermissionError, NotImplementedError):
            pass
    except BaseException:
        try:
            if tmp_path.exists():
                tmp_path.unlink()
        except OSError:
            pass
        raise

    # Atomic swap. If this raises, we deliberately keep the tempfile so
    # the operator can recover the data.
    try:
        os.replace(tmp_path, path)
    except OSError:
        logger.warning(
            "atomic_write: os.replace failed; tempfile left at %s",
            tmp_path,
        )
        raise

    # On POSIX, fsync the parent directory so the rename is durable.
    if os.name == "posix":
        try:
            dir_fd = os.open(str(path.parent), os.O_RDONLY)
            try:
                os.fsync(dir_fd)
            finally:
                os.close(dir_fd)
        except OSError:
            # fsync of directory is best-effort; some filesystems reject.
            pass


DEFAULT_CONFIG_DIR = Path(
    os.environ.get("HAON_HOME") or Path.home() / ".haon"
)
DEFAULT_CONFIG_PATH = DEFAULT_CONFIG_DIR / "agent.toml"


@dataclass
class AgentConfig:
    # API + broker
    api_url: str = "https://api.haon.run"
    tunnel_broker_url: str | None = None  # filled by the API on session open

    # Machine identity
    machine_id: str | None = None
    machine_name: str | None = None
    hub_id: str | None = None

    # Behaviour
    heartbeat_interval_seconds: int = 15
    session_poll_interval_seconds: int = 5
    log_level: str = "info"

    # Pricing & advertise
    price_per_hour: str = "3.0000"
    min_session_minutes: int = 15
    supported_runtimes: list[str] = field(default_factory=lambda: ["echo"])

    # Runtime selection (Phase 10 ships only "echo").
    default_runtime: str = "echo"


def ensure_config_dir(path: Path = DEFAULT_CONFIG_DIR) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    # 0700 on POSIX; no-op on Windows.
    try:
        os.chmod(path, 0o700)
    except (PermissionError, NotImplementedError):
        pass
    return path


def load(path: Path = DEFAULT_CONFIG_PATH) -> AgentConfig:
    if not path.exists():
        return AgentConfig()
    raw = tomllib.loads(path.read_text(encoding="utf-8"))

    cfg = AgentConfig()
    agent = raw.get("agent", {})
    if "api_url" in agent:
        cfg.api_url = agent["api_url"]
    if "tunnel_broker_url" in agent:
        cfg.tunnel_broker_url = agent["tunnel_broker_url"]
    if "heartbeat_interval_seconds" in agent:
        cfg.heartbeat_interval_seconds = int(agent["heartbeat_interval_seconds"])
    if "session_poll_interval_seconds" in agent:
        cfg.session_poll_interval_seconds = int(agent["session_poll_interval_seconds"])
    if "log_level" in agent:
        cfg.log_level = agent["log_level"]

    machine = raw.get("machine", {})
    cfg.machine_id = machine.get("id") or cfg.machine_id
    cfg.machine_name = machine.get("name") or cfg.machine_name
    cfg.hub_id = machine.get("hub_id") or cfg.hub_id

    pricing = raw.get("pricing", {})
    if "price_per_hour" in pricing:
        cfg.price_per_hour = str(pricing["price_per_hour"])
    if "min_session_minutes" in pricing:
        cfg.min_session_minutes = int(pricing["min_session_minutes"])

    advertise = raw.get("advertise", {})
    if "supported_runtimes" in advertise:
        cfg.supported_runtimes = list(advertise["supported_runtimes"])

    runtime = raw.get("runtime", {})
    if "default" in runtime:
        cfg.default_runtime = str(runtime["default"])

    return cfg


def save(cfg: AgentConfig, path: Path = DEFAULT_CONFIG_PATH) -> None:
    """Serialize `cfg` to TOML at `path` with mode 0600.

    Writes atomically via `_atomic_write_text`: a sibling tempfile is
    fsync'd then renamed with `os.replace`. A SIGINT, OOM kill, or
    container restart mid-write cannot produce a half-populated config
    — the reader either sees the previous complete file or the new
    complete file.
    """
    ensure_config_dir(path.parent)

    def _toml_str(s: str) -> str:
        return '"' + s.replace("\\", "\\\\").replace('"', '\\"') + '"'

    lines: list[str] = ["[agent]"]
    lines.append(f"api_url = {_toml_str(cfg.api_url)}")
    if cfg.tunnel_broker_url:
        lines.append(f"tunnel_broker_url = {_toml_str(cfg.tunnel_broker_url)}")
    lines.append(f"heartbeat_interval_seconds = {cfg.heartbeat_interval_seconds}")
    lines.append(f"session_poll_interval_seconds = {cfg.session_poll_interval_seconds}")
    lines.append(f"log_level = {_toml_str(cfg.log_level)}")
    lines.append("")
    lines.append("[machine]")
    if cfg.machine_id:
        lines.append(f"id = {_toml_str(cfg.machine_id)}")
    if cfg.machine_name:
        lines.append(f"name = {_toml_str(cfg.machine_name)}")
    if cfg.hub_id:
        lines.append(f"hub_id = {_toml_str(cfg.hub_id)}")
    lines.append("")
    lines.append("[pricing]")
    lines.append(f"price_per_hour = {_toml_str(cfg.price_per_hour)}")
    lines.append(f"min_session_minutes = {cfg.min_session_minutes}")
    lines.append("")
    lines.append("[advertise]")
    runtimes = ", ".join(_toml_str(r) for r in cfg.supported_runtimes)
    lines.append(f"supported_runtimes = [{runtimes}]")
    lines.append("")
    lines.append("[runtime]")
    lines.append(f"default = {_toml_str(cfg.default_runtime)}")
    lines.append("")
    _atomic_write_text(path, "\n".join(lines), mode=0o600)
