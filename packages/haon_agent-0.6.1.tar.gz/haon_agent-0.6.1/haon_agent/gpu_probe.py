"""GPU capability detection for marketplace advertisement (Phase 27.0 / P1).

Probes the host for NVIDIA GPU capabilities and emits a JSONB-friendly
dict that matches the v1 schema accepted by `POST /v1/machines/{id}/heartbeat`
(see `services/api/app/schemas/machine.py:_validate_runtime_capabilities`).

The probe is **best-effort, no-fail**: a CPU-only miner, an AMD-GPU miner,
or a host where `nvidia-smi` exits non-zero gets back `{}`. The marketplace
filter `?capability=cuda` excludes empty caps cleanly, so the worst case
is "this miner doesn't appear in CUDA-filtered listings" — exactly the
intended behaviour.

Detection strategy:
  1. Try `pynvml` (Python NVIDIA bindings, ships in `nvidia-ml-py` if
     present). Richer + faster than subprocess. Optional dep.
  2. Fall back to subprocess `nvidia-smi --query-gpu=... --format=csv`.
     Already on every Linux/Windows NVIDIA driver install. Zero pip cost.
  3. If both fail (or no NVIDIA at all) → return `{}`.

Caching: the probe is meant to be called ONCE per agent process, at boot,
because the answer doesn't change without a driver upgrade or hardware
swap. The agent's heartbeat loop holds the cached result and only sends
on first heartbeat (or when the cache invalidates after a long gap).

Why not advertise on every heartbeat?
  - The payload is small (~500 bytes for a typical RTX 4090) but sending
    it every 30 s for hundreds of miners is bandwidth churn the API
    doesn't need.
  - Heartbeat semantics (`runtime_capabilities=None`) explicitly preserve
    cached server-side state — that's a feature, not a bug.

When SHOULD the agent re-send?
  - On agent restart (cache cleared, fresh detect).
  - After a runtime config reload (toml edit).
  - On detection of GPU hot-swap (Windows NVIDIA driver event — out of
    scope for v1; trigger via `haon-agent restart` for now).
"""

from __future__ import annotations

import asyncio
import logging
import re
import subprocess
from typing import Any

log = logging.getLogger(__name__)


# ── Public API ──────────────────────────────────────────────────────────


async def detect() -> dict[str, Any]:
    """Return a v1-schema runtime_capabilities dict, or `{}` if no NVIDIA.

    Async-friendly: subprocess work happens in a thread pool so we don't
    block the agent's heartbeat loop on a slow `nvidia-smi` call. Total
    timeout: ~3 seconds (each subprocess call gets 1s; pynvml probe is
    near-instant).
    """
    # Prefer pynvml when present — order of magnitude faster than the
    # subprocess fallback, and surfaces detail (compute capability) that
    # nvidia-smi only emits with newer drivers.
    pynvml_caps = await asyncio.to_thread(_probe_pynvml)
    if pynvml_caps:
        return pynvml_caps

    smi_caps = await asyncio.to_thread(_probe_nvidia_smi)
    if smi_caps:
        return smi_caps

    return {}


# ── pynvml path (preferred) ─────────────────────────────────────────────


def _probe_pynvml() -> dict[str, Any]:
    """Probe via the NVIDIA Management Library Python bindings.

    Returns `{}` on any failure — pynvml may not be installed, may fail
    to load on a non-NVIDIA host, or may raise on a driver mismatch.
    Whatever happens, fall through silently to the subprocess fallback.
    """
    try:
        import pynvml  # type: ignore[import-not-found]
    except ImportError:
        return {}

    try:
        pynvml.nvmlInit()
    except Exception:  # noqa: BLE001 — pynvml has its own exception class
        return {}

    try:
        try:
            count = int(pynvml.nvmlDeviceGetCount())
        except Exception:  # noqa: BLE001
            return {}
        if count <= 0:
            return {}

        try:
            driver_version = pynvml.nvmlSystemGetDriverVersion().decode("ascii", "ignore")
        except Exception:  # noqa: BLE001
            driver_version = ""

        try:
            cuda_runtime_version = pynvml.nvmlSystemGetCudaDriverVersion()
            cuda_major, cuda_minor = divmod(int(cuda_runtime_version), 1000)
            cuda_minor = (cuda_minor // 10)  # nvml encodes as e.g. 12040 → 12.4
            cuda_version = f"{cuda_major}.{cuda_minor}"
        except Exception:  # noqa: BLE001
            cuda_version = ""

        compute_caps: list[str] = []
        vram_gb_total = 0
        ecc_any = False
        nvlink_any = False

        for idx in range(count):
            try:
                handle = pynvml.nvmlDeviceGetHandleByIndex(idx)
            except Exception:  # noqa: BLE001
                continue
            try:
                major, minor = pynvml.nvmlDeviceGetCudaComputeCapability(handle)
                compute_caps.append(f"{int(major)}.{int(minor)}")
            except Exception:  # noqa: BLE001
                pass
            try:
                mem = pynvml.nvmlDeviceGetMemoryInfo(handle)
                vram_gb_total += int(mem.total // (1024**3))
            except Exception:  # noqa: BLE001
                pass
            try:
                # ECC mode current returns 0 (Disabled) or 1 (Enabled).
                ecc_current, _ecc_pending = pynvml.nvmlDeviceGetEccMode(handle)
                if int(ecc_current) == 1:
                    ecc_any = True
            except Exception:  # noqa: BLE001
                # Many consumer cards (RTX 30/40 GeForce) don't support
                # ECC at all — pynvml raises NVML_ERROR_NOT_SUPPORTED.
                pass
            try:
                # Probe link 0 — if it responds active, NVLink is wired up.
                state = pynvml.nvmlDeviceGetNvLinkState(handle, 0)
                if int(state) == 1:
                    nvlink_any = True
            except Exception:  # noqa: BLE001
                pass

        out = _build_caps(
            cuda_enabled=bool(compute_caps),
            cuda_version=cuda_version,
            compute_capabilities=compute_caps,
            vram_gb=vram_gb_total,
            ecc_memory=ecc_any,
            nvlink=nvlink_any,
            driver_version=driver_version,
            gpu_count=count,
        )
        log.info("gpu_probe_pynvml_success caps=%r", out)
        return out
    finally:
        try:
            pynvml.nvmlShutdown()
        except Exception:  # noqa: BLE001
            pass


# ── nvidia-smi subprocess fallback ──────────────────────────────────────


_VERSION_RE = re.compile(r"(\d+)\.(\d+)")


def _run_smi(args: list[str], timeout: float = 1.0) -> str:
    """Run `nvidia-smi <args>` with a short timeout. Returns stdout or ''."""
    try:
        result = subprocess.run(  # noqa: S603 — args fully controlled
            ["nvidia-smi", *args],
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        return ""
    if result.returncode != 0:
        return ""
    return result.stdout or ""


def _probe_nvidia_smi() -> dict[str, Any]:
    """Probe via subprocess `nvidia-smi`. Last-resort path.

    Slower than pynvml (~150-300 ms per call) but works on any host with
    a working NVIDIA driver — no extra Python dep.
    """
    # Per-GPU CSV: name, memory.total (MiB), compute_cap, driver_version, cuda_version
    csv_out = _run_smi([
        "--query-gpu=name,memory.total,compute_cap,driver_version",
        "--format=csv,noheader,nounits",
    ])
    if not csv_out.strip():
        return {}

    rows = [r.strip() for r in csv_out.strip().splitlines() if r.strip()]
    if not rows:
        return {}

    compute_caps: list[str] = []
    vram_gb_total = 0
    driver_version = ""

    for row in rows:
        parts = [p.strip() for p in row.split(",")]
        if len(parts) < 4:
            continue
        # Older nvidia-smi versions emit compute_cap as `8.9` and newer
        # drivers as `8.9` too — same shape, parse defensively.
        cap_match = _VERSION_RE.search(parts[2])
        if cap_match:
            compute_caps.append(f"{cap_match.group(1)}.{cap_match.group(2)}")
        # memory.total is MiB; round-down divide by 1024 for GiB.
        try:
            vram_mib = int(parts[1])
            vram_gb_total += vram_mib // 1024
        except ValueError:
            pass
        driver_version = driver_version or parts[3]

    if not compute_caps:
        return {}

    # CUDA driver version comes from a separate query on older drivers.
    cuda_out = _run_smi([
        "--query-gpu=cuda_version",
        "--format=csv,noheader,nounits",
    ])
    cuda_version = ""
    cuda_match = _VERSION_RE.search(cuda_out)
    if cuda_match:
        cuda_version = f"{cuda_match.group(1)}.{cuda_match.group(2)}"

    # ECC mode — best-effort. Consumer cards return "N/A" or fail.
    ecc_out = _run_smi([
        "--query-gpu=ecc.mode.current",
        "--format=csv,noheader,nounits",
    ])
    ecc_any = "enabled" in ecc_out.lower()

    # NVLink — `nvidia-smi nvlink --status` is the canonical query but
    # the output schema changes per driver; safest signal is non-empty
    # output that doesn't say "not supported".
    nvlink_out = _run_smi(["nvlink", "--status"], timeout=1.0)
    nvlink_any = bool(nvlink_out.strip()) and "not supported" not in nvlink_out.lower()

    out = _build_caps(
        cuda_enabled=True,
        cuda_version=cuda_version,
        compute_capabilities=compute_caps,
        vram_gb=vram_gb_total,
        ecc_memory=ecc_any,
        nvlink=nvlink_any,
        driver_version=driver_version,
        gpu_count=len(rows),
    )
    log.info("gpu_probe_nvidia_smi_success caps=%r", out)
    return out


# ── Output builder (shared) ─────────────────────────────────────────────


def _build_caps(
    *,
    cuda_enabled: bool,
    cuda_version: str,
    compute_capabilities: list[str],
    vram_gb: int,
    ecc_memory: bool,
    nvlink: bool,
    driver_version: str,
    gpu_count: int,
) -> dict[str, Any]:
    """Assemble a v1 schema dict. Matches `_RUNTIME_CAPABILITIES_V1_KEYS`
    on the API side — keep this in sync with
    `services/api/app/schemas/machine.py`.

    The `cuda` block carries enabled + version + (highest) compute_capability
    so a worker filtering by `?capability=cuda` gets a single match-key.
    The full list of per-GPU compute capabilities is also surfaced under
    `compute_capabilities` for richer client-side rendering.
    """
    # Prefer the highest compute capability for the cuda.compute_capability
    # field — this is what most workloads care about (FlashAttention 2
    # needs 8.0+, FA3 needs 9.0+). Compare numerically as `(major, minor)`
    # tuples, NOT lexicographically — string-compare breaks the moment
    # NVIDIA ships compute capability 10.x (Blackwell B100/B200) because
    # `"10.0" < "5.3"` lexicographically. tuples handle that correctly.
    def _cc_tuple(s: str) -> tuple[int, int]:
        # Defensive: caller is supposed to pass non-empty strings, but
        # `None` / unexpected payloads from third-party probes shouldn't
        # crash the agent. Catch any parse failure → (0, 0).
        try:
            major, _, minor = (s or "").partition(".")
            return (int(major or 0), int(minor or 0))
        except (AttributeError, TypeError, ValueError):
            return (0, 0)

    if compute_capabilities:
        highest_tuple = max(_cc_tuple(c) for c in compute_capabilities)
        highest_cap = f"{highest_tuple[0]}.{highest_tuple[1]}"
    else:
        highest_tuple = (0, 0)
        highest_cap = ""
    fp16_supported = highest_tuple >= (5, 3)
    bf16_supported = highest_tuple >= (8, 0)
    int8_supported = highest_tuple >= (6, 1)

    return {
        "schema_version": 1,
        "cuda": {
            "enabled": cuda_enabled,
            "version": cuda_version,
            "compute_capability": highest_cap,
        },
        "fp16": fp16_supported,
        "bf16": bf16_supported,
        "int8": int8_supported,
        "vram_gb": vram_gb,
        "ecc_memory": ecc_memory,
        "nvlink": nvlink,
        "driver_version": driver_version,
        "gpu_count": gpu_count,
        "compute_capabilities": compute_capabilities,
    }
