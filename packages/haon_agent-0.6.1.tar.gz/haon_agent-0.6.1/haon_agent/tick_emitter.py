"""Per-session background task that samples usage and POSTs ticks.

Spawned by the agent's `_run_session` right after the runtime starts. Stops
when the session ends. On transient API failures it logs and keeps trying —
missed ticks are fine (the backend already tolerates gaps in `tick_seq`) as
long as we don't double-post or rollback.
"""

from __future__ import annotations

import asyncio
from datetime import datetime, timezone
from typing import Any

import structlog

from haon_agent.api_client import ApiClient, ApiError
from haon_agent.broker_client import BrokerClient
from haon_agent.usage import Sample, SamplerBackend, SubprocessSamplerBackend, sample

log = structlog.get_logger("agent.ticks")


def _utcnow() -> datetime:
    return datetime.now(tz=timezone.utc)


class TickEmitter:
    """Drives the 10-second tick cadence for one session.

    Emits one `UsageTick` per interval via POST /v1/usage/ticks containing
    CPU/GPU/RAM/VRAM samples (from `docker stats` + `nvidia-smi`), bytes-
    in/out deltas (from `BrokerClient.bytes_sent`/`bytes_recv`), and a
    running cumulative `session_total_wh` floating-point accumulator.

    Cumulative-float note (re-audit, Informational): `_total_wh` is a
    Python float; at tick cadences over multi-hour sessions the running
    sum can drift ~1e-9 Wh per tick. Well below meter-grade. The dashboard
    rounds to 4 decimals; acceptable for billing precision.
    """

    def __init__(
        self,
        *,
        api: ApiClient,
        session_id: str,
        broker: BrokerClient,
        container_name: str | None,
        interval_seconds: int = 10,
        sampler: SamplerBackend | None = None,
    ) -> None:
        self._api = api
        self._session_id = session_id
        self._broker = broker
        self._container_name = container_name
        self._interval = interval_seconds
        self._sampler = sampler or SubprocessSamplerBackend()
        self._task: asyncio.Task[None] | None = None
        self._stop = asyncio.Event()
        self._tick_seq = 0
        self._last_bytes_sent = 0
        self._last_bytes_recv = 0
        # Running power totals for the session. `_total_wh` accumulates
        # instantaneous W × elapsed-seconds / 3600. `_peak_power_w` is the
        # max non-None sample we've seen; `_sum_power_w` / `_samples_with_power`
        # drive the average. Ticks that return None for `power_draw_w` (probe
        # failed) contribute zero Wh for that interval but don't corrupt the
        # average — we simply skip them.
        self._total_wh: float = 0.0
        self._peak_power_w: float = 0.0
        self._sum_power_w: float = 0.0
        self._samples_with_power: int = 0

    def start(self) -> None:
        if self._task is not None:
            return
        self._task = asyncio.create_task(self._run())

    async def stop(self) -> None:
        self._stop.set()
        if self._task is not None:
            try:
                await asyncio.wait_for(self._task, timeout=5)
            except asyncio.TimeoutError:
                self._task.cancel()
            self._task = None
        avg = (
            self._sum_power_w / self._samples_with_power
            if self._samples_with_power
            else 0.0
        )
        # Logged at INFO so a session post-mortem can recover the power
        # envelope without scraping individual ticks. API surfacing of these
        # totals is a follow-up PR.
        log.info(
            "session_closed",
            session_id=self._session_id,
            total_wh=round(self._total_wh, 3),
            avg_power_w=round(avg, 2),
            peak_power_w=round(self._peak_power_w, 2),
            power_samples=self._samples_with_power,
        )

    async def _run(self) -> None:
        while not self._stop.is_set():
            try:
                await asyncio.wait_for(
                    self._stop.wait(), timeout=self._interval
                )
                # If we were asked to stop, exit without emitting a partial tick.
                return
            except asyncio.TimeoutError:
                pass  # normal cadence

            await self._emit_one()

    async def _emit_one(self) -> None:
        smp: Sample
        if self._container_name is None:
            smp = Sample(
                cpu_percent=0.0,
                ram_mb=0,
                gpu_percent=0.0,
                vram_mb=0,
                power_draw_w=None,
            )
        else:
            try:
                smp = await sample(
                    container_name=self._container_name, backend=self._sampler
                )
            except Exception as e:  # noqa: BLE001
                log.warning("tick_sample_failed", error=str(e))
                smp = Sample(
                    cpu_percent=0.0,
                    ram_mb=0,
                    gpu_percent=0.0,
                    vram_mb=0,
                    power_draw_w=None,
                )

        bytes_sent = self._broker.bytes_sent
        bytes_recv = self._broker.bytes_recv
        delta_sent = max(0, bytes_sent - self._last_bytes_sent)
        delta_recv = max(0, bytes_recv - self._last_bytes_recv)
        self._last_bytes_sent = bytes_sent
        self._last_bytes_recv = bytes_recv

        # Fold the power draw into the running session totals. A None here
        # means the probe dropped this tick — don't poison the average, and
        # attribute zero Wh to the interval. Using the tick's own interval
        # (not wall-clock delta) keeps the accumulator deterministic under
        # test and consistent with how the backend validates `duration_seconds`.
        if smp.power_draw_w is not None:
            self._total_wh += smp.power_draw_w * self._interval / 3600.0
            self._sum_power_w += smp.power_draw_w
            self._samples_with_power += 1
            if smp.power_draw_w > self._peak_power_w:
                self._peak_power_w = smp.power_draw_w

        payload: dict[str, Any] = {
            "session_id": self._session_id,
            "tick_seq": self._tick_seq,
            "emitted_at": _utcnow().isoformat(),
            "duration_seconds": self._interval,
            "cpu_percent": smp.cpu_percent,
            "gpu_percent": smp.gpu_percent,
            "ram_mb": smp.ram_mb,
            "vram_mb": smp.vram_mb,
            "bytes_in": delta_recv,     # worker → miner
            "bytes_out": delta_sent,    # miner → worker
            # Live power draw (W) for this tick — None when no GPU or probe
            # failed. `session_total_wh` is the cumulative energy across the
            # session so far; the dashboard can compute profit-after-power
            # live without waiting for session close.
            "power_draw_w": smp.power_draw_w,
            "session_total_wh": round(self._total_wh, 4),
        }
        try:
            resp = await self._api.post_ticks([payload])
            results = resp.get("results") or []
            if results and not results[0].get("accepted"):
                reason = results[0].get("rejection_reason") or ""
                log.warning(
                    "tick_rejected",
                    tick_seq=self._tick_seq,
                    reason=reason,
                )
                # If the server says the session is gone (closed by worker,
                # sweeper kill, or heartbeat timeout), stop emitting —
                # otherwise the agent will POST a rejected tick every
                # interval until process restart, burning CPU + Redis +
                # log budget. The enclosing `_run_session` pipeline
                # detects termination via the broker CLOSE frame (or
                # UNPAIRED / ERROR / IDLE_TIMEOUT) so this is purely a
                # resource-conservation measure.
                if reason in (
                    "session_not_active",
                    "session_closed",
                    "session_not_found",
                ):
                    log.info(
                        "tick_emitter_self_stop",
                        reason=reason,
                        tick_seq=self._tick_seq,
                    )
                    self._stop.set()
                    return
            self._tick_seq += 1
        except ApiError as e:
            # 404 session-gone is terminal in the same way. Other ApiErrors
            # (5xx, rate-limit) are transient — log and retry next tick.
            if e.status_code == 404 or e.code in (
                "NOT_FOUND",
                "SESSION_NOT_FOUND",
                "SESSION_NOT_ACTIVE",
            ):
                log.info(
                    "tick_emitter_self_stop",
                    reason=f"api:{e.code}",
                    tick_seq=self._tick_seq,
                )
                self._stop.set()
                return
            log.warning("tick_post_failed", code=e.code, status=e.status_code)
        except Exception as e:  # noqa: BLE001
            log.exception("tick_post_unhandled", error=str(e))
