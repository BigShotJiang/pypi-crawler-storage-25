"""DockerClient abstraction.

Production talks to the `docker` CLI via `asyncio.create_subprocess_exec`.
Tests inject a `FakeDockerClient` that records intended operations and
mimics container lifecycle deterministically. Every test runs without a
Docker daemon present.

We deliberately avoid `docker-py` to:
- keep the dep graph minimal on miner machines;
- make the fake trivial (no need to mock an SDK surface);
- pass through CLI flags verbatim so operators can `docker inspect` and see
  exactly what we asked for.
"""

from __future__ import annotations

import asyncio
import os
import uuid
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Awaitable, Callable


@dataclass
class DockerRunSpec:
    """Everything docker needs to start a container. Kept flat for auditability."""

    image: str
    container_name: str
    cpus: str                              # "1.5"
    memory: str                            # "4g"
    pids_limit: int
    read_only: bool
    network: str                           # "none" | "bridge" | custom
    tmpfs: list[tuple[str, str]] = field(default_factory=list)  # (mountpoint, options)
    cap_drop: list[str] = field(default_factory=lambda: ["ALL"])
    cap_add: list[str] = field(default_factory=list)
    security_opts: list[str] = field(
        default_factory=lambda: ["no-new-privileges"]
    )
    user: str = "1000:1000"
    env: dict[str, str] = field(default_factory=dict)
    gpus: str | None = None                # "all" | "device=0" | None
    labels: dict[str, str] = field(default_factory=dict)
    command: list[str] = field(default_factory=list)
    # Phase 5 blindagem — explicitly forbid swap. Docker's default sets
    # memory-swap = 2 × memory, meaning the `--memory` cap can be
    # circumvented via swap. Setting this equal to `memory` (string-
    # equality, e.g. "2g") forbids swap entirely. None = inherit
    # Docker default (NOT what we want in production; only present
    # for backward-compat with old call sites that don't set it).
    memory_swap: str | None = None
    # Phase 5 blindagem — fork/socket-bomb caps. Without these a
    # privileged-but-cap-dropped process can still exhaust host file
    # descriptors or PIDs by forking inside its pids_limit. Tuple is
    # (soft, hard). None = leave at OS default (very high — bad).
    ulimit_nofile: tuple[int, int] | None = (1024, 2048)
    ulimit_nproc: tuple[int, int] | None = (512, 1024)


@dataclass
class DockerRunHandle:
    """Opaque handle returned by `run()`. Concrete impls subclass this."""

    container_name: str


class DockerClientError(Exception):
    """Raised when the underlying docker operation fails."""


class DockerClient(ABC):
    """Minimal async surface used by DockerRuntime."""

    @abstractmethod
    async def run(
        self,
        spec: DockerRunSpec,
        *,
        on_stdout: Callable[[bytes], Awaitable[None]],
        on_stderr: Callable[[bytes], Awaitable[None]] | None = None,
    ) -> DockerRunHandle: ...

    @abstractmethod
    async def write_stdin(self, handle: DockerRunHandle, data: bytes) -> None: ...

    @abstractmethod
    async def kill(
        self, handle: DockerRunHandle, signal: str = "SIGTERM", timeout: float = 10.0
    ) -> None: ...

    @abstractmethod
    async def remove(self, handle: DockerRunHandle) -> None: ...


# ── Real: subprocess against `docker` CLI ────────────────────────────────


@dataclass
class _SubprocessHandle(DockerRunHandle):
    process: asyncio.subprocess.Process
    stdout_task: asyncio.Task[None]
    stderr_task: asyncio.Task[None] | None


class SubprocessDockerClient(DockerClient):
    """Spawns a `docker run` subprocess per container."""

    def __init__(self, docker_binary: str = "docker") -> None:
        self._docker = docker_binary

    async def run(
        self,
        spec: DockerRunSpec,
        *,
        on_stdout: Callable[[bytes], Awaitable[None]],
        on_stderr: Callable[[bytes], Awaitable[None]] | None = None,
    ) -> DockerRunHandle:
        from haon_agent.runtime.sandbox import build_docker_args

        args = build_docker_args(spec)
        proc = await asyncio.create_subprocess_exec(
            self._docker,
            *args,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )

        async def _pump(
            stream: asyncio.StreamReader | None,
            cb: Callable[[bytes], Awaitable[None]] | None,
        ) -> None:
            if stream is None or cb is None:
                return
            while True:
                chunk = await stream.read(64 * 1024)
                if not chunk:
                    return
                await cb(chunk)

        stdout_task = asyncio.create_task(_pump(proc.stdout, on_stdout))
        stderr_task = (
            asyncio.create_task(_pump(proc.stderr, on_stderr))
            if on_stderr is not None
            else None
        )
        return _SubprocessHandle(
            container_name=spec.container_name,
            process=proc,
            stdout_task=stdout_task,
            stderr_task=stderr_task,
        )

    async def write_stdin(self, handle: DockerRunHandle, data: bytes) -> None:
        assert isinstance(handle, _SubprocessHandle)
        if handle.process.stdin is None or handle.process.stdin.is_closing():
            raise DockerClientError("container stdin closed")
        handle.process.stdin.write(data)
        try:
            await handle.process.stdin.drain()
        except (ConnectionResetError, BrokenPipeError) as e:
            raise DockerClientError("stdin broken") from e

    async def kill(
        self, handle: DockerRunHandle, signal: str = "SIGTERM", timeout: float = 10.0
    ) -> None:
        assert isinstance(handle, _SubprocessHandle)
        # Graceful: `docker kill --signal`.
        try:
            proc = await asyncio.create_subprocess_exec(
                self._docker, "kill", "--signal", signal, handle.container_name,
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.DEVNULL,
            )
            await asyncio.wait_for(proc.wait(), timeout=timeout)
        except (asyncio.TimeoutError, FileNotFoundError):
            pass
        # Force SIGKILL if still running.
        try:
            await asyncio.wait_for(handle.process.wait(), timeout=timeout)
        except asyncio.TimeoutError:
            try:
                proc = await asyncio.create_subprocess_exec(
                    self._docker, "kill", "--signal", "SIGKILL", handle.container_name,
                    stdout=asyncio.subprocess.DEVNULL,
                    stderr=asyncio.subprocess.DEVNULL,
                )
                await proc.wait()
            except FileNotFoundError:
                pass

    async def remove(self, handle: DockerRunHandle) -> None:
        assert isinstance(handle, _SubprocessHandle)
        # Wait briefly then `docker rm -f` as insurance.
        handle.stdout_task.cancel()
        if handle.stderr_task is not None:
            handle.stderr_task.cancel()
        try:
            proc = await asyncio.create_subprocess_exec(
                self._docker, "rm", "-f", handle.container_name,
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.DEVNULL,
            )
            await proc.wait()
        except FileNotFoundError:
            pass


# ── Fake for tests ───────────────────────────────────────────────────────


@dataclass
class FakeContainerRecord:
    spec: DockerRunSpec
    stdin_writes: list[bytes] = field(default_factory=list)
    killed: bool = False
    kill_signal: str | None = None
    removed: bool = False
    # Callback we call when the "container" emits stdout — tests drive this
    # directly via `fake.emit_output(handle, bytes)`.
    on_stdout: Callable[[bytes], Awaitable[None]] | None = None


@dataclass
class _FakeHandle(DockerRunHandle):
    record: FakeContainerRecord


class FakeDockerClient(DockerClient):
    """Deterministic, in-memory Docker stand-in."""

    def __init__(self) -> None:
        self.containers: dict[str, FakeContainerRecord] = {}

    async def run(
        self,
        spec: DockerRunSpec,
        *,
        on_stdout: Callable[[bytes], Awaitable[None]],
        on_stderr: Callable[[bytes], Awaitable[None]] | None = None,
    ) -> DockerRunHandle:
        rec = FakeContainerRecord(spec=spec, on_stdout=on_stdout)
        self.containers[spec.container_name] = rec
        return _FakeHandle(container_name=spec.container_name, record=rec)

    async def write_stdin(self, handle: DockerRunHandle, data: bytes) -> None:
        assert isinstance(handle, _FakeHandle)
        if handle.record.killed:
            raise DockerClientError("container killed")
        handle.record.stdin_writes.append(bytes(data))

    async def kill(
        self, handle: DockerRunHandle, signal: str = "SIGTERM", timeout: float = 10.0
    ) -> None:
        assert isinstance(handle, _FakeHandle)
        handle.record.killed = True
        handle.record.kill_signal = signal

    async def remove(self, handle: DockerRunHandle) -> None:
        assert isinstance(handle, _FakeHandle)
        handle.record.removed = True

    # ── Test helpers ────────────────────────────────────────────────────

    async def emit_output(self, handle: DockerRunHandle, data: bytes) -> None:
        """Simulate the container writing `data` to stdout."""
        assert isinstance(handle, _FakeHandle)
        if handle.record.on_stdout is not None:
            await handle.record.on_stdout(data)

    def record(self, container_name: str) -> FakeContainerRecord:
        return self.containers[container_name]


def new_container_name(prefix: str = "haon") -> str:
    return f"{prefix}-{uuid.uuid4().hex[:12]}"


def docker_available() -> bool:
    """Quick probe: is the docker CLI present and runnable?"""
    from shutil import which

    if which("docker") is None:
        return False
    # Caller may further check `docker info` when truly needed.
    return True
