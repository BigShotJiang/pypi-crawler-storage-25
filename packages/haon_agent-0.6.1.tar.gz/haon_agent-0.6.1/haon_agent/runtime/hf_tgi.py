"""HuggingFace via Text Generation Inference (TGI) — Phase 27 PREVIEW.

Sibling of hf_vllm.py; see docs/HUGGINGFACE_STRATEGY.md. TGI is HF's
own production inference server — the right choice for:
  - Models that HF publishes with TGI-specific optimisations (some
    Mistral / Qwen variants).
  - Tensor-parallel multi-GPU (TGI's sharding story is more battle-
    tested than vLLM's for the 70B tier).
  - Teams that want the HF-blessed path for reproducibility.

vLLM tends to win single-GPU throughput; TGI tends to win multi-GPU
orchestration. Scheduler lets the worker pick via `runtime_hint`
(`"auto"` defaults to vLLM for ≤34B, TGI for 70B+).

Same NotImplementedError posture as hf_vllm — lands the class, fails
loud at start() until Phase 27.1 plumbs model_id through session-open.
"""

from __future__ import annotations

import os
from typing import Awaitable, Callable

from haon_agent.runtime.base import register
from haon_agent.runtime.docker import DockerRuntime, RuntimeDefaults


class HfTgiRuntime(DockerRuntime):
    """TGI server loading any HF `model_id`.

    Image contract:
      - CLI arg `--model-id <hf_id>` — required.
      - ENV HUGGING_FACE_HUB_TOKEN=<token> for gated models.
      - Listens on 80/tcp inside the container (TGI's default; we do not
        override to match upstream docs & their OpenAPI spec).

    Exposes `/v1/chat/completions` (OpenAI-compat since TGI 2.0) so the
    transport layer is identical to vLLM — the tunnel-bridge doesn't
    need to know which engine it's talking to.
    """

    defaults = RuntimeDefaults(
        image="ghcr.io/huggingface/text-generation-inference",
        image_digest="",  # deploy-time pin; see hf_vllm.py note.
        # Command is filled by session-open once model_id arrives. Keeping
        # an empty list means the container won't start until that lands —
        # which is what we want during the preview window.
        command=[],
        env={
            "HUGGING_FACE_HUB_TOKEN": "",
            # TGI honours HF_HOME for cache location; aligning with the
            # tmpfs mount below keeps the weight-cache story consistent
            # with vLLM.
            "HF_HOME": "/root/.cache/huggingface",
            "PORT": "80",
        },
        cpus="4.0",
        memory="32g",
        pids_limit=512,
        requires_gpu=True,
        gpus="all",
        needs_network=True,
        tmpfs=[
            ("/tmp", "rw,noexec,nosuid,size=1g"),
            ("/root/.cache/huggingface", "rw,nosuid,size=60g"),
        ],
        extra_labels={
            "haon.runtime.kind": "llm",
            "haon.runtime.family": "hf",
            "haon.runtime.engine": "tgi",
        },
    )

    async def start(
        self, on_output: Callable[[bytes], Awaitable[None]]
    ) -> None:
        raise NotImplementedError(
            "hf-tgi runtime is Phase 27 preview; session-open does not yet "
            "thread model_id. Track: docs/HUGGINGFACE_STRATEGY.md Phase 27.1."
        )


if os.environ.get("HAON_ENABLE_HF") == "1":
    register("hf-tgi", HfTgiRuntime)
