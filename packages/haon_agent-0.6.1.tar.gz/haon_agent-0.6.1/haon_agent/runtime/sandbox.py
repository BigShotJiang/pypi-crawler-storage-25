"""Sandbox flag builder.

Takes a `DockerRunSpec` and produces the exact `docker run ...` argv list.

This module is the single authoritative source for what flags our sandboxes
carry. If you need to add or remove a hardening flag, do it here and update
`tests/unit/test_sandbox_args.py`.

Hardening posture (per docs/03-security-model.md § Sandbox):
- Non-root user (1000:1000)
- `--read-only` root filesystem
- Tmpfs-only writable mounts, scoped per job
- `--cap-drop=ALL`; additions only via allowlist
- `--security-opt=no-new-privileges`
- `--pids-limit` (default 256)
- `--network=none` unless the runtime declares `needs_network=True` and miner opts in
- No host paths mounted (GPU devices go through `--gpus`, not `-v`)
- No `--privileged`. Ever. (asserted by tests)
"""

from __future__ import annotations

from haon_agent.runtime.docker_client import DockerRunSpec


def build_docker_args(spec: DockerRunSpec) -> list[str]:
    """Translate a spec into `docker run` argv (without the leading `docker`).

    Order is stable — good for readability in `ps` / `docker inspect`.
    """
    args: list[str] = ["run", "--rm", "-i", "--name", spec.container_name]

    # Resource limits.
    args += ["--cpus", spec.cpus]
    args += ["--memory", spec.memory]
    # Phase 5 blindagem: forbid swap by setting memory-swap = memory
    # when the spec asks for it. Docker default = 2×memory, which
    # silently breaks the memory cap.
    if spec.memory_swap is not None:
        args += ["--memory-swap", spec.memory_swap]
    args += ["--pids-limit", str(spec.pids_limit)]
    # Phase 5 blindagem: ulimit caps prevent fork-bomb / socket-flood
    # within the pids_limit. soft:hard.
    if spec.ulimit_nofile is not None:
        soft, hard = spec.ulimit_nofile
        args += ["--ulimit", f"nofile={soft}:{hard}"]
    if spec.ulimit_nproc is not None:
        soft, hard = spec.ulimit_nproc
        args += ["--ulimit", f"nproc={soft}:{hard}"]

    # Filesystem.
    if spec.read_only:
        args += ["--read-only"]
    for mount, options in spec.tmpfs:
        args += ["--tmpfs", f"{mount}:{options}" if options else mount]

    # Network — default `none`.
    args += ["--network", spec.network]

    # Capabilities.
    for cap in spec.cap_drop:
        args += ["--cap-drop", cap]
    for cap in spec.cap_add:
        args += ["--cap-add", cap]

    # Security opts.
    for opt in spec.security_opts:
        args += ["--security-opt", opt]

    # User.
    args += ["--user", spec.user]

    # GPUs.
    if spec.gpus:
        args += ["--gpus", spec.gpus]

    # Env.
    for k, v in spec.env.items():
        args += ["--env", f"{k}={v}"]

    # Labels (auditing).
    for k, v in spec.labels.items():
        args += ["--label", f"{k}={v}"]

    # Image + command.
    args.append(spec.image)
    args += spec.command

    return args


def assert_safe(spec: DockerRunSpec) -> None:
    """Programmatic safety check — called by DockerRuntime at spawn time.

    Tests can also call this directly to verify invariants hold on any
    new runtime added to the catalog.
    """
    problems: list[str] = []
    if "ALL" not in spec.cap_drop:
        problems.append("cap_drop must include 'ALL'")
    if "no-new-privileges" not in spec.security_opts:
        problems.append("security_opts must include 'no-new-privileges'")
    if spec.user == "root" or spec.user.startswith("0:"):
        problems.append(f"user must be non-root (got {spec.user!r})")
    if spec.pids_limit > 1024:
        problems.append(
            f"pids_limit too high ({spec.pids_limit}); consider tightening"
        )
    if any(
        c.lower() in {"sys_admin", "net_admin", "sys_ptrace", "sys_module", "bpf"}
        for c in spec.cap_add
    ):
        problems.append(f"dangerous capability requested: {spec.cap_add}")
    if spec.network not in ("none", "bridge", "host") and not spec.network.startswith(
        "container:"
    ):
        # Custom networks are fine; `host` we reluctantly allow but flag.
        pass
    if spec.network == "host":
        problems.append("host networking is never allowed in the sandbox")
    if problems:
        raise AssertionError("Unsafe sandbox spec: " + "; ".join(problems))
