"""Native Ollama runtime — talks to a locally-installed Ollama server.

Unlike `runtime/ollama.py` (which launches the `ollama/ollama` Docker image
under `--gpus all`), this runtime forwards bytes straight to the user's
already-running Ollama process on http://127.0.0.1:11434. It unblocks the
common Windows case — Ollama ships as a native MSI installer, users rarely
have the WSL2 + Docker Desktop + NVIDIA Container Toolkit chain — at the
cost of sandboxing.

Trade-off vs the Docker runtime: NO sandbox. The worker runs against the
user's actual Ollama daemon, can see already-loaded models, and can POST
`/api/pull` to download arbitrary model weights onto the user's disk.
Acceptable for alpha (the miner explicitly opts in by listing
`ollama_native` in `supported_runtimes`); Phase 26 adds a model-pull
denylist + bandwidth accounting.

The 11434 port is Ollama's fixed default. Non-default ports are a Phase 26
concern — no env-var knobs here on purpose.
"""

from __future__ import annotations

from typing import Awaitable, Callable

import httpx
import structlog

from haon_agent.runtime.base import register

log = structlog.get_logger("agent.runtime.ollama_native")


OLLAMA_NATIVE_HOST = "127.0.0.1"
OLLAMA_NATIVE_PORT = 11434
OLLAMA_NATIVE_BASE_URL = f"http://{OLLAMA_NATIVE_HOST}:{OLLAMA_NATIVE_PORT}"
OLLAMA_TAGS_PATH = "/api/tags"
OLLAMA_VERSION_PATH = "/api/version"
OLLAMA_GENERATE_PATH = "/api/generate"

_PROBE_TIMEOUT_SECONDS = 2.0
_FORWARD_TIMEOUT_SECONDS = 300.0

# Phase 6 blindagem — minimum safe Ollama version. CVE-2024-37032
# ("Probllama" — path traversal → RCE) was patched in 0.1.34. Newer
# CVEs (CVE-2024-39720/39721/39722/45436) all patched by 0.1.34+.
# Bump as new advisories land.
#
# We use /api/version (200 since 0.1.34, 404 in earlier builds) as a
# zero-subprocess version probe. Even on Windows where the user
# installed Ollama via MSI without putting it on PATH, the local HTTP
# server at 11434 still answers, so this works without `ollama --version`.
MIN_SAFE_OLLAMA_VERSION = (0, 1, 34)

# Phase 10 blindagem — LLM safety bounds. Conservative caps that don't
# break the 99% workload (chat / single-turn / batch < 50MB), only
# defend against the runaway/exhaust-host case. Override via env if
# you genuinely need bigger.
MAX_RESPONSE_BYTES_PER_REQUEST = 50 * 1024 * 1024  # 50 MiB

# Heuristic prompt-injection signal patterns. Detect-only — false-positive
# rate is high enough that auto-block would shred legitimate prompts.
# We log the signal so an audit reader can spot patterns over time.
_PROMPT_INJECTION_SIGNALS = (
    r"ignore (all |previous |above |the )?(instructions?|prompts?|rules?)",
    r"(disregard|forget|override) (the |all |your )?(instructions?|system prompt)",
    r"you are now (a|an) ",
    r"developer mode",
    r"<\|im_start\|>system",  # ChatML role injection
    r"\[INST\]",               # Llama-style instruction injection
)


def _parse_version_triple(s: str) -> tuple[int, int, int] | None:
    """Parse `"0.1.34"` / `"0.3.12-rc1"` / etc to a comparable triple.

    Returns None if the leading three integers can't be extracted —
    caller decides what to do (we proceed with a warning today).
    """
    import re
    m = re.match(r"^v?(\d+)\.(\d+)\.(\d+)", s.strip())
    if not m:
        return None
    return (int(m.group(1)), int(m.group(2)), int(m.group(3)))


class RuntimeUnavailable(RuntimeError):
    """Raised when a runtime's prerequisite is missing at start() time.

    Distinct from a generic RuntimeError so callers (the agent main loop,
    the pair wizard) can surface a targeted message — e.g. "Ollama isn't
    running, launch it and re-run pair".
    """


class OllamaNativeRuntime:
    """Native Ollama runtime — no Docker, proxies to a local Ollama server.

    Runtime protocol semantics (matches `runtime/base.py`):
      - ``start(on_output)`` probes ``/api/tags`` on the local Ollama; raises
        :class:`RuntimeUnavailable` with a human-readable message if the
        server isn't reachable. Logs a clear warning about the lack of
        sandboxing — the miner opted in, but the security posture is
        meaningfully weaker than the Docker runtime.
      - ``push(data)`` forwards the raw bytes as the body of
        ``POST /api/generate`` on the local Ollama and streams the response
        bytes back to ``on_output``. The worker is expected to hand us the
        JSON body Ollama expects; we do not wrap/unwrap.
      - ``stop()`` is a no-op — we do not own the Ollama process; tearing
        it down would surprise the user whose other apps are using it.
    """

    name = "ollama_native"
    # Still requires a GPU on the host — Ollama's dispatcher decides
    # per-model whether to run on GPU or fall back to CPU, but the whole
    # reason a miner is advertising this runtime is GPU inference.
    requires_gpu = True
    # Explicit negative signal for the pair wizard / sandbox checks:
    # this runtime deliberately does not shell out to Docker.
    needs_docker = False

    def __init__(
        self,
        *,
        base_url: str = OLLAMA_NATIVE_BASE_URL,
        http_client: httpx.AsyncClient | None = None,
    ) -> None:
        # `base_url` is a test hook — in production it is always the
        # fixed 127.0.0.1:11434 constant. Not exposed as config.
        self._base_url = base_url.rstrip("/")
        self._http: httpx.AsyncClient | None = http_client
        self._owns_http = http_client is None
        self._on_output: Callable[[bytes], Awaitable[None]] | None = None
        self._started = False

    # ── Runtime protocol ────────────────────────────────────────────────

    async def start(
        self, on_output: Callable[[bytes], Awaitable[None]]
    ) -> None:
        if self._started:
            raise RuntimeError("ollama_native runtime already started")
        if self._http is None:
            self._http = httpx.AsyncClient(timeout=_FORWARD_TIMEOUT_SECONDS)

        tags_url = f"{self._base_url}{OLLAMA_TAGS_PATH}"
        try:
            resp = await self._http.get(tags_url, timeout=_PROBE_TIMEOUT_SECONDS)
        except httpx.HTTPError as exc:
            # Connection refused / DNS / timeout — anything that means "no
            # server there". Surface a message the miner can act on.
            await self._cleanup_http()
            raise RuntimeUnavailable(
                "Ollama native runtime selected but no Ollama server is "
                f"reachable at {self._base_url}. Install Ollama "
                "(https://ollama.com/download) and make sure it is running, "
                "then re-run the agent."
            ) from exc

        if resp.status_code != 200:
            await self._cleanup_http()
            raise RuntimeUnavailable(
                f"Ollama server at {self._base_url} returned HTTP "
                f"{resp.status_code} on {OLLAMA_TAGS_PATH}; expected 200. "
                "Is another process answering on that port?"
            )

        # Phase 6 blindagem — version gate against known CVEs.
        # Probe /api/version. Behaviour:
        #   - 200 with parseable version → compare against MIN_SAFE
        #   - 404 → server is older than 0.1.34 (the version that
        #     introduced /api/version AND fixed CVE-2024-37032 et al)
        #   - non-2xx other → treat as opaque older build, refuse
        # Refusing means raising RuntimeUnavailable so the agent
        # surfaces the upgrade-link message to the miner.
        await self._enforce_version_gate()

        # Empty `models` list is not a start-time failure — the user may
        # have Ollama running but haven't pulled any models yet, and the
        # worker might POST /api/pull as its first request. Just log.
        try:
            models = resp.json().get("models", []) or []
        except ValueError:
            models = []
        if not models:
            log.info(
                "ollama_native_no_models",
                hint=(
                    "Ollama is running but has no models installed. The "
                    "worker may pull one on first request (this can take a "
                    "while and uses miner disk + bandwidth)."
                ),
            )

        # Opt-in security posture warning. The miner knowingly advertised
        # this runtime; we still make the trade-off visible in the logs
        # so the alpha audit trail captures it.
        log.warning(
            "ollama_native_started_without_sandbox",
            base_url=self._base_url,
            model_count=len(models),
            note=(
                "Native runtime: no Docker sandbox. Worker shares the "
                "miner's Ollama daemon and may pull additional models."
            ),
        )

        self._on_output = on_output
        self._started = True

    async def push(self, data: bytes) -> None:
        if not self._started or self._http is None or self._on_output is None:
            raise RuntimeError("ollama_native runtime not started")

        # Phase 10 blindagem — observe the request for prompt-injection
        # signals before forwarding. Detect-only: we log signals but do
        # NOT modify or block the request. False-positive rate of these
        # heuristics is too high to auto-block a real workload.
        self._observe_request_for_injection(data)

        url = f"{self._base_url}{OLLAMA_GENERATE_PATH}"
        # Stream the response so the worker gets incremental tokens back
        # (Ollama emits newline-delimited JSON when `stream: true`). We
        # forward raw bytes — the worker is responsible for any parsing.
        # Phase 10 blindagem — bounded response size. A pathological
        # prompt could elicit a multi-GB response that exhausts the
        # miner's memory before the worker disconnects. Cap at the
        # MAX_RESPONSE_BYTES_PER_REQUEST budget; emit a structured log
        # and stop forwarding once exceeded.
        bytes_forwarded = 0
        truncated = False
        async with self._http.stream(
            "POST",
            url,
            content=data,
            headers={"content-type": "application/json"},
        ) as resp:
            async for chunk in resp.aiter_bytes():
                if not chunk:
                    continue
                if bytes_forwarded + len(chunk) > MAX_RESPONSE_BYTES_PER_REQUEST:
                    # Forward whatever fits in the remaining budget,
                    # then stop. Truncation is preferred over OOM.
                    remaining = MAX_RESPONSE_BYTES_PER_REQUEST - bytes_forwarded
                    if remaining > 0:
                        await self._on_output(chunk[:remaining])
                        bytes_forwarded += remaining
                    truncated = True
                    break
                await self._on_output(chunk)
                bytes_forwarded += len(chunk)
        if truncated:
            log.warning(
                "ollama_native_response_truncated",
                bytes_forwarded=bytes_forwarded,
                cap=MAX_RESPONSE_BYTES_PER_REQUEST,
            )

    def _observe_request_for_injection(self, data: bytes) -> None:
        """Best-effort heuristic — log if request body looks like a
        prompt-injection attempt. Never raises; never modifies the
        request. Designed to surface patterns to operators looking at
        audit_log over time, not to block individual requests."""
        try:
            import json
            import re
            payload = json.loads(data.decode("utf-8", errors="replace"))
        except (ValueError, UnicodeDecodeError):
            return
        # Ollama API: /api/generate carries `prompt`; /api/chat carries
        # `messages: [{role, content}]`. Probe both shapes.
        candidates: list[str] = []
        if isinstance(payload, dict):
            if isinstance(payload.get("prompt"), str):
                candidates.append(payload["prompt"])
            if isinstance(payload.get("system"), str):
                candidates.append(payload["system"])
            if isinstance(payload.get("messages"), list):
                for m in payload["messages"]:
                    if isinstance(m, dict) and isinstance(m.get("content"), str):
                        candidates.append(m["content"])
        if not candidates:
            return
        haystack = "\n".join(candidates).lower()
        # Compile once per call — could memoize but the call rate is
        # tunnel-bound (≤ N req/s per session), not hot loop.
        signals: list[str] = []
        for pattern in _PROMPT_INJECTION_SIGNALS:
            if re.search(pattern, haystack, flags=re.IGNORECASE):
                signals.append(pattern)
        if signals:
            log.info(
                "ollama_native_prompt_signal",
                signals=signals[:5],   # cap log size
                size=len(haystack),
                note="detect-only; not blocking",
            )

    async def stop(self) -> None:
        # We do not own the Ollama process — stop() must not kill it.
        self._started = False
        self._on_output = None
        await self._cleanup_http()

    # ── Internals ───────────────────────────────────────────────────────

    async def _enforce_version_gate(self) -> None:
        """Phase 6 blindagem — refuse to start against an Ollama with
        known CVEs. Uses /api/version (introduced in 0.1.34, the same
        release that fixed CVE-2024-37032). Earlier builds 404 here,
        which we treat as proof of vulnerable version.

        Override via env: HAON_ALLOW_UNSAFE_OLLAMA=1 — surfaces the
        version in a structured warning log but proceeds. Intended
        only for CI / testing setups where the miner has
        side-channel-mitigated the host.
        """
        import os
        version_url = f"{self._base_url}{OLLAMA_VERSION_PATH}"
        try:
            resp = await self._http.get(  # type: ignore[union-attr]
                version_url, timeout=_PROBE_TIMEOUT_SECONDS
            )
        except httpx.HTTPError as exc:
            # Connection issues here mean the tags probe got lucky and
            # the server died between calls — treat as unavailable.
            await self._cleanup_http()
            raise RuntimeUnavailable(
                f"Ollama version probe failed: {exc}. Re-run agent."
            ) from exc

        if resp.status_code == 404:
            msg = (
                "Ollama at {} does not expose /api/version → version is "
                "below 0.1.34. CVE-2024-37032 (Probllama, RCE), -39720, "
                "-39722, -45436 affect this build. Upgrade: "
                "https://ollama.com/download"
            ).format(self._base_url)
            if os.environ.get("HAON_ALLOW_UNSAFE_OLLAMA") == "1":
                log.warning(
                    "ollama_native_unsafe_override",
                    base_url=self._base_url,
                    note="HAON_ALLOW_UNSAFE_OLLAMA=1 — running against "
                         "known-vulnerable Ollama. Don't do this in prod.",
                )
                return
            await self._cleanup_http()
            raise RuntimeUnavailable(msg)

        if resp.status_code != 200:
            await self._cleanup_http()
            raise RuntimeUnavailable(
                f"Ollama /api/version returned HTTP {resp.status_code}. "
                "Cannot verify version safety. Upgrade Ollama."
            )

        # Parse "0.1.34" / "0.3.12" / similar.
        try:
            payload = resp.json() or {}
        except ValueError:
            payload = {}
        ver_str = str(payload.get("version") or "").strip()
        parsed = _parse_version_triple(ver_str)
        if parsed is None:
            log.warning(
                "ollama_native_unparseable_version",
                base_url=self._base_url,
                raw=ver_str[:64],
                note=(
                    "Could not parse version; proceeding because /api/version "
                    "responded 200 (so >= 0.1.34 floor is met). Worth "
                    "investigating if this fires on a published Ollama build."
                ),
            )
            return

        if parsed < MIN_SAFE_OLLAMA_VERSION:
            msg = (
                f"Ollama {ver_str} below minimum safe {MIN_SAFE_OLLAMA_VERSION}. "
                "Upgrade: https://ollama.com/download"
            )
            if os.environ.get("HAON_ALLOW_UNSAFE_OLLAMA") == "1":
                log.warning(
                    "ollama_native_unsafe_override",
                    version=ver_str,
                    min_safe=str(MIN_SAFE_OLLAMA_VERSION),
                )
                return
            await self._cleanup_http()
            raise RuntimeUnavailable(msg)

        log.info(
            "ollama_native_version_ok",
            version=ver_str,
            base_url=self._base_url,
        )

    async def _cleanup_http(self) -> None:
        if self._http is not None and self._owns_http:
            try:
                await self._http.aclose()
            except Exception:  # noqa: BLE001
                pass
        self._http = None

    async def health(self) -> bool:
        """Best-effort liveness probe. Never raises."""
        try:
            client = self._http or httpx.AsyncClient(timeout=_PROBE_TIMEOUT_SECONDS)
            try:
                resp = await client.get(
                    f"{self._base_url}{OLLAMA_TAGS_PATH}",
                    timeout=_PROBE_TIMEOUT_SECONDS,
                )
                return resp.status_code == 200
            finally:
                if self._http is None:
                    await client.aclose()
        except Exception:  # noqa: BLE001
            return False


register("ollama_native", OllamaNativeRuntime)
