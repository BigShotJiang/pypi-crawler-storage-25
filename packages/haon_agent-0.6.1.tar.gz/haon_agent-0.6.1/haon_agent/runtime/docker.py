"""Docker-backed Runtime base class.

Subclasses declare their image + command + resource defaults. The base class
builds the hardened `DockerRunSpec`, spawns the container, bridges stdin/stdout
to the agent's `push`/`on_output` hooks, and guarantees cleanup on teardown.
"""

from __future__ import annotations

import asyncio
import uuid
from dataclasses import dataclass, field
from typing import Awaitable, Callable, Iterable

import structlog

from haon_agent.runtime.docker_client import (
    DockerClient,
    DockerClientError,
    DockerRunHandle,
    DockerRunSpec,
    SubprocessDockerClient,
    new_container_name,
)
from haon_agent.runtime.sandbox import assert_safe

log = structlog.get_logger("agent.runtime.docker")


@dataclass
class RuntimeDefaults:
    """Per-runtime constants that become the Docker spec."""

    image: str
    image_digest: str                         # "sha256:abc..." pinning
    command: list[str] = field(default_factory=list)
    env: dict[str, str] = field(default_factory=dict)
    cpus: str = "1.0"
    memory: str = "2g"
    # Phase 5 blindagem: default forbids swap (memory_swap == memory).
    # Per-runtime override only if a workload genuinely needs swap (none
    # of the current echo/ollama/comfyui/vllm/tgi runtimes do).
    memory_swap: str | None = None
    pids_limit: int = 256
    requires_gpu: bool = False
    gpus: str | None = None
    needs_network: bool = False
    tmpfs: list[tuple[str, str]] = field(
        default_factory=lambda: [
            ("/tmp", "rw,noexec,nosuid,size=512m"),
            ("/run", "rw,noexec,nosuid,size=32m"),
        ]
    )
    extra_labels: dict[str, str] = field(default_factory=dict)


class DockerRuntime:
    """Base class that subclasses override by populating `defaults`."""

    defaults: RuntimeDefaults

    def __init__(
        self,
        *,
        client: DockerClient | None = None,
        timeout_seconds: int | None = None,
        session_id: str | None = None,
    ) -> None:
        self._client: DockerClient = client or SubprocessDockerClient()
        self._timeout_seconds = timeout_seconds
        self._session_id = session_id or uuid.uuid4().hex
        self._handle: DockerRunHandle | None = None
        self._timeout_task: asyncio.Task[None] | None = None
        self._stopped = False

    # ── Runtime protocol ────────────────────────────────────────────────

    async def start(
        self, on_output: Callable[[bytes], Awaitable[None]]
    ) -> None:
        if self._handle is not None:
            raise RuntimeError("runtime already started")
        spec = self._build_spec()
        assert_safe(spec)
        log.info(
            "runtime_starting",
            image=spec.image,
            container=spec.container_name,
            cpus=spec.cpus,
            memory=spec.memory,
            network=spec.network,
            gpus=spec.gpus,
        )
        self._handle = await self._client.run(
            spec,
            on_stdout=_chunked(on_output),
            on_stderr=_log_stderr,
        )
        if self._timeout_seconds is not None:
            self._timeout_task = asyncio.create_task(
                self._enforce_timeout(self._timeout_seconds)
            )

    async def push(self, data: bytes) -> None:
        if self._handle is None:
            raise RuntimeError("runtime not started")
        if self._stopped:
            raise RuntimeError("runtime stopped")
        await self._client.write_stdin(self._handle, data)

    async def stop(self) -> None:
        if self._stopped:
            return
        self._stopped = True
        if self._timeout_task is not None:
            self._timeout_task.cancel()
        if self._handle is None:
            return
        try:
            await self._client.kill(self._handle, signal="SIGTERM", timeout=10)
        except DockerClientError:
            pass
        try:
            await self._client.remove(self._handle)
        except DockerClientError:
            pass
        self._handle = None

    # ── Internals ───────────────────────────────────────────────────────

    def _build_spec(self) -> DockerRunSpec:
        d = self.defaults
        image_ref = (
            f"{d.image}@{d.image_digest}"
            if d.image_digest.startswith("sha256:")
            else d.image
        )
        labels = {
            "haon.session_id": self._session_id,
            "haon.runtime": type(self).__name__,
            **d.extra_labels,
        }
        # Default memory_swap = memory string-equality → forbids swap.
        # Per-runtime override only if explicitly set in defaults.
        memory_swap = d.memory_swap if d.memory_swap is not None else d.memory
        return DockerRunSpec(
            image=image_ref,
            container_name=new_container_name(
                prefix=f"haon-{type(self).__name__.lower()}"
            ),
            cpus=d.cpus,
            memory=d.memory,
            memory_swap=memory_swap,
            pids_limit=d.pids_limit,
            read_only=True,
            network="bridge" if d.needs_network else "none",
            tmpfs=list(d.tmpfs),
            cap_drop=["ALL"],
            cap_add=[],
            security_opts=["no-new-privileges"],
            user="1000:1000",
            env=dict(d.env),
            gpus=d.gpus if d.requires_gpu else None,
            labels=labels,
            command=list(d.command),
            # ulimits inherit DockerRunSpec defaults (1024:2048 nofile,
            # 512:1024 nproc) — no per-runtime override needed today.
        )

    async def _enforce_timeout(self, seconds: int) -> None:
        try:
            await asyncio.sleep(seconds)
        except asyncio.CancelledError:
            return
        if self._handle is not None and not self._stopped:
            log.warning(
                "runtime_timeout_firing",
                container=self._handle.container_name,
                timeout=seconds,
            )
            await self.stop()


def _chunked(
    cb: Callable[[bytes], Awaitable[None]], max_bytes: int = 1 * 1024 * 1024
) -> Callable[[bytes], Awaitable[None]]:
    """Split stdout bursts into ≤ max_bytes chunks to match tunnel frame limit."""

    async def _wrap(data: bytes) -> None:
        if len(data) <= max_bytes:
            await cb(data)
            return
        view = memoryview(data)
        for i in range(0, len(view), max_bytes):
            await cb(bytes(view[i : i + max_bytes]))

    return _wrap


async def _log_stderr(data: bytes) -> None:
    # Surface container stderr as structured log — never raise.
    try:
        text = data.decode("utf-8", errors="replace").rstrip()
        if text:
            log.warning("runtime_stderr", message=text[:2048])
    except Exception:  # noqa: BLE001
        pass
