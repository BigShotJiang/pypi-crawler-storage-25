"""Remote-desktop runtime — WebRTC-native (post-pivot, R2.v2).

STATUS: **bring-up mode** — the agent does not run a streamer itself
yet. During this phase, the streaming peer on the miner side is a
browser tab opened by the operator at:

    https://<HAON-frontend>/m/{session_id}#token={tunnel_token}

That page captures a canvas/webcam, opens an `RTCPeerConnection` as
the `miner` role, and talks to HAON's R1 signaling endpoints exactly
the way the worker's `/s/{session_id}` page does. Browser-to-browser
is enough to validate the full signaling + transport stack end-to-end
without depending on Selkies, GStreamer, NVENC, or aiortc.

The agent's job in bring-up mode is therefore minimal:
  - Accept the session (so heartbeat + billing flow work)
  - Open the broker channel (so receipts can ride it)
  - Block until the session is closed by the worker, the broker, or
    a stop signal — the actual media plane lives in the browser tabs

Real implementation tracks (these will replace this stub):
  - Track A: spawn Selkies-GStreamer subprocess (Linux miners)
  - Track B (R11): Go+Pion+CGO single-binary streamer (cross-platform)

See docs/R2_PIVOT_SELKIES.md for the full pivot rationale.
"""

from __future__ import annotations

import asyncio
from typing import Awaitable, Callable

import structlog

from haon_agent.runtime.base import register


log = structlog.get_logger("agent.runtime.remote_desktop")


class RemoteDesktopRuntime:
    """Bring-up mode: no-op start, blocks until stop()."""

    def __init__(self, session_id: str = "unknown") -> None:
        self._session_id = session_id
        self._on_output: Callable[[bytes], Awaitable[None]] | None = None
        self._stop_event = asyncio.Event()
        self._idle_task: asyncio.Task | None = None

    def set_session(self, session_id: str) -> None:
        self._session_id = session_id

    async def start(
        self, on_output: Callable[[bytes], Awaitable[None]]
    ) -> None:
        self._on_output = on_output
        log.info(
            "remote_desktop_bringup_mode_started",
            session_id=self._session_id,
            note=(
                "Agent runtime is a no-op. Open /m/{session_id} in a "
                "browser tab on the miner machine to provide the WebRTC "
                "peer. See docs/R2_PIVOT_SELKIES.md."
            ),
        )
        # Spawn an idle task so the runtime "occupies" the session — the
        # agent's session loop awaits on its own broker/tick layer; the
        # runtime just needs to not return immediately or it'll look
        # like an instant-finish runtime to upstream callers.
        self._idle_task = asyncio.create_task(self._stop_event.wait())

    async def push(self, data: bytes) -> None:
        # Bring-up mode ignores broker DATA frames — the browser /m/ tab
        # talks to the browser /s/ tab through the R1 signaling REST
        # endpoints + WebRTC P2P, not through the broker tunnel. When
        # Track A or Track B lands, this will route control frames into
        # the streamer.
        return

    async def stop(self) -> None:
        self._stop_event.set()
        if self._idle_task is not None and not self._idle_task.done():
            self._idle_task.cancel()
            try:
                await self._idle_task
            except (asyncio.CancelledError, Exception):  # noqa: BLE001
                pass
            self._idle_task = None
        log.info("remote_desktop_bringup_mode_stopped", session_id=self._session_id)


register("remote_desktop", RemoteDesktopRuntime)
