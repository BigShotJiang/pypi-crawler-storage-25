"""HuggingFace via vLLM — Phase 27.1 (model_id wired through session).

Worker passes `model_id` (e.g. "meta-llama/Llama-3.1-8B-Instruct") and
optionally `hf_token` via `runtime_options` at session-open. Agent
threads it through SessionHandoff → `set_options()` → `_build_spec()`
which injects MODEL + HUGGING_FACE_HUB_TOKEN env into the vLLM
container.

vLLM serves an OpenAI-compatible API on port 8000. Worker tunnels
local port (e.g. 22434) → miner port 8000 via the standard
TunnelTransport. Worker code that talks OpenAI/vLLM works unchanged
— same `base_url=http://localhost:22434/v1`.

## Boot semantics (red-team agreement: B — "miner eats boot")

`start()` spawns the container. `wait_ready()` blocks until vLLM
serves HTTP 200 on `/v1/models` (model load can take 60-300s for
the first run). The agent's `_run_http_session` calls `wait_ready()`
BEFORE starting the tick emitter, so billing only begins when the
worker can actually use the runtime. Cold-start cost is the miner's
to absorb — aligned incentive: warm cache = faster sessions = more
sessions billed = more revenue.

## What's still NOT done

- HF token is currently passed PLAINTEXT through the handoff JSON
  (signaling is HTTPS so server-trust suffices, but a malicious
  miner agent CAN read it). Phase 27.3 will encrypt the value
  E2E with the worker's pubkey.
- Cache eviction across sessions (Phase 27.2). Today, multi-model
  workers fill /root/.cache/huggingface up to the 60GB tmpfs cap
  per session and lose it on container destroy.
- Resource caps come from `defaults` not from worker request. A
  pleno BYOR model (custom CPU/memory/gpu_memory caps) is V2.

## Why Docker (not native pip install vllm)

vLLM officially supports Linux + CUDA only. Native `pip install vllm`
on Windows fails. Docker container with `vllm/vllm-openai` image
+ `--gpus all` (via nvidia-container-toolkit) works on:
  - Linux miners with nvidia driver + nvidia-container-toolkit
  - Windows miners with WSL2 + Docker Desktop + nvidia-container-toolkit
  - macOS: no CUDA support, runtime will refuse at registration
"""

from __future__ import annotations

import asyncio
import logging
import shutil
from typing import Awaitable, Callable

import httpx

from haon_agent.runtime.base import register
from haon_agent.runtime.docker import DockerRuntime, RuntimeDefaults

log = logging.getLogger(__name__)


# How long we'll wait for vLLM to serve /v1/models after `docker run`.
# Cold pull of a 7B model + load can hit 3-4 min on slower disks.
# Longer than this and we tear down — most likely the container OOMed
# or the model download stalled.
_BOOT_TIMEOUT_SECONDS = 360


class HfVllmRuntime(DockerRuntime):
    """vLLM OpenAI-compatible server loading any HF `model_id`.

    Worker controls model selection per-session via runtime_options:
        {"model_id": "meta-llama/Llama-3.1-8B-Instruct",
         "hf_token": "hf_xxx"  # optional, only for gated models
        }
    """

    defaults = RuntimeDefaults(
        image="vllm/vllm-openai:latest",
        # Production deploys MUST pin a digest. Empty = "use the tag",
        # which is fine for dev smoke tests but not for prod (the agent
        # config layer will refuse if HAON_REQUIRE_DIGEST=1).
        image_digest="",
        # vLLM's own entrypoint takes the model id as positional arg.
        # We override at start time once `set_options` populated it.
        command=[
            "--host", "0.0.0.0",
            "--port", "8000",
            # Disable trust_remote_code — refuses to load HF models that
            # ship arbitrary Python (RCE vector). Workers wanting custom
            # code should use custom_http (V2) where the sandbox is
            # explicit.
            "--trust-remote-code=false",
        ],
        env={
            # Model id injected per-session by _build_spec override.
            "MODEL": "",
            # HF token also per-session. Empty = anonymous (works for
            # public models only — gated models like Llama require a
            # token the worker accepted the license with).
            "HUGGING_FACE_HUB_TOKEN": "",
            # Disable HF telemetry pings — worker privacy.
            "HF_HUB_DISABLE_TELEMETRY": "1",
        },
        cpus="4.0",
        memory="32g",
        pids_limit=512,
        requires_gpu=True,
        gpus="all",
        # vLLM needs internet to pull weights from huggingface.co on
        # first boot. Once cached, subsequent runs work offline if
        # HF_HUB_OFFLINE=1 is set — but per-session by default we
        # allow network so the first boot succeeds.
        needs_network=True,
        tmpfs=[
            ("/tmp", "rw,noexec,nosuid,size=1g"),
            # HF cache — sized for one mid-tier model. A 70B model
            # exceeds this; Phase 27.2 adds host-mounted cache volume
            # with LRU eviction shared across sessions.
            ("/root/.cache/huggingface", "rw,nosuid,size=60g"),
        ],
        extra_labels={
            "haon.runtime.kind": "llm",
            "haon.runtime.family": "hf",
            "haon.runtime.engine": "vllm",
        },
    )

    def __init__(
        self,
        *,
        client=None,
        timeout_seconds: int | None = None,
        session_id: str | None = None,
    ) -> None:
        super().__init__(
            client=client,
            timeout_seconds=timeout_seconds,
            session_id=session_id,
        )
        self._model_id: str | None = None
        self._hf_token: str | None = None

    def set_options(self, options: dict) -> None:
        """Phase 27.1 — worker-supplied per-session config.

        Called by `_run_http_session` BEFORE `start()`. Validates
        model_id is present (vLLM CANNOT start without one) and
        captures the optional HF token.
        """
        model_id = (options or {}).get("model_id")
        if not model_id or not isinstance(model_id, str):
            raise ValueError(
                "hf_vllm runtime requires runtime_options.model_id "
                "(e.g. 'meta-llama/Llama-3.1-8B-Instruct'). Open the "
                "session with --model on the worker CLI."
            )
        # HF model id format: <user>/<repo>[:revision]
        # Quick sanity — keep loose (HF allows lots of chars), block
        # only obvious shell-injection / path traversal.
        if any(c in model_id for c in (";", "&", "|", "`", "$", "..")):
            raise ValueError(f"model_id has illegal characters: {model_id!r}")
        self._model_id = model_id
        self._hf_token = (options or {}).get("hf_token") or None

    def _build_spec(self):
        """Override base spec to inject MODEL + HF_TOKEN per session."""
        if not self._model_id:
            raise RuntimeError(
                "hf_vllm runtime: set_options() must be called before start()"
            )
        spec = super()._build_spec()
        # Mutate env in place + extend command with `--model <id>`.
        spec.env["MODEL"] = self._model_id
        if self._hf_token:
            spec.env["HUGGING_FACE_HUB_TOKEN"] = self._hf_token
        # Append the model id to the command (vLLM CLI takes it as the
        # first positional arg historically, but newer versions also
        # accept --model). Use --model for explicitness.
        spec.command = list(spec.command) + ["--model", self._model_id]
        return spec

    async def wait_ready(
        self,
        *,
        port: int = 8000,
        timeout: float = _BOOT_TIMEOUT_SECONDS,
    ) -> None:
        """Block until vLLM serves /v1/models. Called by the agent's
        _run_http_session BEFORE billing starts so the miner eats the
        cold-start cost.

        Raises TimeoutError on hard fail; caller treats as
        runtime-stop + session-failed.
        """
        deadline = asyncio.get_event_loop().time() + timeout
        async with httpx.AsyncClient(timeout=5.0) as client:
            while asyncio.get_event_loop().time() < deadline:
                try:
                    r = await client.get(f"http://127.0.0.1:{port}/v1/models")
                    if r.status_code == 200:
                        log.info(
                            "hf_vllm_ready model=%s elapsed=%.1fs",
                            self._model_id,
                            timeout - (deadline - asyncio.get_event_loop().time()),
                        )
                        return
                except Exception:
                    pass  # still booting — keep polling
                await asyncio.sleep(2.0)
        raise TimeoutError(
            f"hf_vllm did not respond within {timeout}s "
            f"(model={self._model_id!r}, possibly OOM, slow disk, or model "
            f"download stalled)"
        )


# Registration is unconditional — the runtime is published in the
# agent's `supported()` list so the marketplace knows it exists. The
# actual `docker run` happens at session time; if Docker isn't
# installed, that's a `docker not found` error from the runtime,
# not a registration problem. Operators who don't want to advertise
# vLLM can omit it from agent.toml `supported_runtimes`.
#
# Note the underscore form (`hf_vllm`, not `hf-vllm`) — keeps name
# consistent with port_forward.RUNTIMES_WITH_PORT and the wire
# protocol the worker uses (`--runtime hf_vllm`).
def _docker_available() -> bool:
    return shutil.which("docker") is not None


if _docker_available():
    register("hf_vllm", HfVllmRuntime)
else:
    log.info(
        "hf_vllm not registered: docker CLI not found on PATH "
        "(install Docker to offer this runtime)"
    )
