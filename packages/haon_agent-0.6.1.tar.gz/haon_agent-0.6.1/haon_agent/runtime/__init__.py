"""Runtime adapters.

Phase 10 shipped `echo` (in-process). Phase 11 adds Docker-based runtimes
`ollama`, `comfyui`, `custom-http`. All implement the same `Runtime`
Protocol and are looked up by name via `get_runtime(name)`.
"""

from haon_agent.runtime.base import Runtime, RuntimeFactory, get_runtime, supported
from haon_agent.runtime.echo import EchoRuntime

# Importing these modules triggers their `register()` calls on the registry.
from haon_agent.runtime import comfyui as _comfyui  # noqa: F401
from haon_agent.runtime import custom_http as _custom_http  # noqa: F401
from haon_agent.runtime import ollama as _ollama  # noqa: F401
from haon_agent.runtime import ollama_native as _ollama_native  # noqa: F401
# Phase 27.1 — HuggingFace runtimes self-gate on Docker availability:
#   - hf_vllm registers if `docker` CLI is on PATH (real impl, model_id
#     threaded through runtime_options at session-open).
#   - hf_tgi remains preview — same self-gate pattern.
# Operator who doesn't want to advertise these omits them from
# agent.toml `supported_runtimes`; the registration is just discovery.
from haon_agent.runtime import hf_tgi as _hf_tgi  # noqa: F401
from haon_agent.runtime import hf_vllm as _hf_vllm  # noqa: F401
# Phase R2 (pivoted 2026-04-23) — remote desktop via browser WebRTC.
# Registered under "remote_desktop" but raises at start() until the
# Selkies or Go+Pion streamer integration lands. See
# docs/R2_PIVOT_SELKIES.md. The registration keeps runtime discovery
# consistent; the stub prevents silent billing against a no-op session.
from haon_agent.runtime import remote_desktop as _remote_desktop  # noqa: F401
from haon_agent.runtime.comfyui import ComfyUIRuntime
from haon_agent.runtime.custom_http import CustomHttpRuntime
from haon_agent.runtime.docker import DockerRuntime, RuntimeDefaults
from haon_agent.runtime.ollama import OllamaRuntime
from haon_agent.runtime.ollama_native import OllamaNativeRuntime, RuntimeUnavailable
from haon_agent.runtime.remote_desktop import RemoteDesktopRuntime

__all__ = [
    "Runtime",
    "RuntimeFactory",
    "EchoRuntime",
    "DockerRuntime",
    "RuntimeDefaults",
    "OllamaRuntime",
    "OllamaNativeRuntime",
    "RuntimeUnavailable",
    "ComfyUIRuntime",
    "CustomHttpRuntime",
    "RemoteDesktopRuntime",
    "get_runtime",
    "supported",
]
