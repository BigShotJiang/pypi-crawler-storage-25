"""Abstract `TunnelTransport` protocol.

A transport delivers and receives opaque byte envelopes (our
`tunnel_frames` micro-protocol rides on top). Implementations:

  * `BrokerTransport` — WebSocket relay through the HAON broker.
    Every byte visible to the server. Universal reach (works through
    any NAT). Baseline at v0.4.0-broker-transport-validated.

  * `WebRTCTransport` — RTCPeerConnection + RTCDataChannel. P2P
    direct between worker and miner. Server sees only the ~10 KB of
    signaling SDP+ICE. Requires STUN + (sometimes) TURN for NAT
    traversal. Phase 26A Stage 2.

Selection is done by the caller (usually the `tunnel forward` CLI
flow) via `build_transport()`, which tries WebRTC first and falls
back to broker on failure.

Callers MUST NOT assume either transport's internals. They only use
the four methods below. That's the whole point of this abstraction.
"""

from __future__ import annotations

from enum import Enum
from typing import AsyncIterator, Protocol, runtime_checkable


class TransportVia(str, Enum):
    """Which wire path ended up carrying this session's bytes.

    Exposed so observability can tag metrics + the CLI can tell the
    user whether they're on the fast P2P path or the (always-works)
    broker relay fallback.
    """

    BROKER = "broker"
    WEBRTC_P2P = "webrtc-p2p"       # direct host/srflx candidates
    WEBRTC_TURN = "webrtc-turn"     # relayed via our Coturn


@runtime_checkable
class TunnelTransport(Protocol):
    """One duplex byte envelope stream between worker and miner."""

    @property
    def via(self) -> TransportVia:
        """Which wire path this transport ended up on. Useful for
        metrics + user-facing status (e.g. "Connected directly (P2P)"
        vs "Connected via HAON relay")."""
        ...

    async def connect(self) -> None:
        """Establish the transport. Raises on failure — callers wrap
        in build_transport() for fallback semantics."""
        ...

    async def send(self, frame: bytes) -> None:
        """Send one envelope. Order preserved per transport."""
        ...

    async def recv(self) -> AsyncIterator[bytes]:
        """Async iterator of incoming envelopes. Terminates when the
        transport closes cleanly; raises on hard failure."""
        ...

    async def close(self) -> None:
        """Tear down. Idempotent — safe to call twice."""
        ...
