"""Transport abstraction — agent-side mirror of worker-client's.

Same Protocol + same implementations (adapted to the agent's
BrokerClient). See `apps/worker-client/haon_worker/transport/` and
`docs/WEBRTC_TRANSPORT_MIGRATION.md`.
"""

from haon_agent.transport.base import TransportVia, TunnelTransport
from haon_agent.transport.broker import BrokerTransport
from haon_agent.transport.factory import build_transport
from haon_agent.transport.webrtc import WebRTCTransport

__all__ = [
    "TransportVia",
    "TunnelTransport",
    "BrokerTransport",
    "WebRTCTransport",
    "build_transport",
]
