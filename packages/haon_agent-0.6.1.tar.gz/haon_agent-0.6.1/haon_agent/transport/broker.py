"""Broker-relay transport — agent side.

Mirror of `apps/worker-client/haon_worker/transport/broker.py`, wraps
the agent's own `BrokerClient` (from `haon_agent.broker_client`). The
agent uses this same `TunnelTransport` Protocol so swapping in
`WebRTCTransport` later is a one-line config change in `agent.py`.

See `docs/WEBRTC_TRANSPORT_MIGRATION.md`.
"""

from __future__ import annotations

from typing import AsyncIterator

from haon_agent.broker_client import BrokerClient, FrameType
from haon_agent.transport.base import TransportVia


class BrokerTransport:
    """`TunnelTransport` over the agent's WebSocket broker client.

    Thin adapter: the broker client already has `connect()`, `send_data()`,
    `events()`, `close()` — this wrapper renames them and filters
    control frames so callers only see envelope bytes.
    """

    def __init__(self, *, broker_url: str, token: str) -> None:
        self._broker = BrokerClient(broker_url=broker_url, token=token)
        self._closed = False

    @property
    def via(self) -> TransportVia:
        return TransportVia.BROKER

    @property
    def client(self) -> BrokerClient:
        """Escape hatch for callers that need direct broker access
        (e.g. await_paired in agent startup, set_token for refresh)."""
        return self._broker

    # Pass-through byte counters so TickEmitter (observability) can
    # stay duck-typed over any `TunnelTransport`. BrokerClient already
    # tracks these for broker-path sessions.
    @property
    def bytes_sent(self) -> int:
        return getattr(self._broker, "bytes_sent", 0)

    @property
    def bytes_recv(self) -> int:
        return getattr(self._broker, "bytes_recv", 0)

    async def connect(self) -> None:
        await self._broker.connect()

    async def send(self, frame: bytes) -> None:
        await self._broker.send_data(frame)

    async def recv(self) -> AsyncIterator[bytes]:
        async for ev in self._broker.events():
            if self._closed:
                return
            if ev.type is FrameType.DATA:
                yield ev.payload
            elif ev.type in (FrameType.CLOSE, FrameType.UNPAIRED, FrameType.ERROR):
                return
            # Other frames (PING/PONG/PAIRED/STATS/REFRESH_TOKEN) are
            # transport-internal, consumed by broker client.

    async def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        await self._broker.close()
