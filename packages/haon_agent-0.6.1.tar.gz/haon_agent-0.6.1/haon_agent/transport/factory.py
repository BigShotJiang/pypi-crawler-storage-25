"""Transport factory with hybrid WebRTC→broker fallback.

`build_transport()` is the single entry point both the worker CLI and
the miner agent use to get a live `TunnelTransport`. It tries the
preferred path first and falls back to the broker relay if the
preferred path fails within a bounded timeout.

## Selection rules

  prefer="auto" (default)
    Try WebRTC first (P2P, no server in the data path). If the ICE /
    DataChannel handshake doesn't complete within `webrtc_timeout`
    seconds, tear down and connect via broker instead. Workers behind
    symmetric NAT without TURN will always land on broker — by design
    (25% of real-world NATs per our traffic model).

  prefer="webrtc"
    WebRTC only. Raises on failure. Useful for testing Stage 2 /
    debugging NAT traversal issues (never masks the real error).

  prefer="broker"
    Broker only. The v0.4.0 baseline — always works, server sees every
    byte. Useful as a kill-switch via `--via broker` or
    `HAON_TRANSPORT=broker`.

## Self-coordination between peers

Neither side "tells" the other which transport to use. The signaling
acts as the handshake:
  - Worker posts /rtc/offer immediately
  - Miner polls /rtc/state; if offer appears, it answers
  - If WebRTC completes for both sides, bytes flow P2P
  - If either side's WebRTC timeout fires, it closes the RTCPeer-
    Connection and opens the broker WebSocket. The other side will
    see its own WebRTC timeout fire (no matching answer / no data
    channel open) and also fall back. Both meet on the broker.

Worst-case latency under a failure: `webrtc_timeout` + broker connect
(~1s). With default 8s timeout that's ~9s before the tunnel is live —
acceptable for a cold-start session.

## Why a factory and not a constructor flag

Keeping the fallback logic separate from `WebRTCTransport` /
`BrokerTransport` means each class stays single-responsibility and
testable in isolation. The factory owns the orchestration, and
callers that specifically want one class (e.g. Stage 2 loopback
tests) can still instantiate it directly.
"""

from __future__ import annotations

import asyncio
import logging

from haon_agent.transport.base import TransportVia, TunnelTransport
from haon_agent.transport.broker import BrokerTransport
from haon_agent.transport.webrtc import WebRTCTransport

log = logging.getLogger(__name__)


# Default WebRTC connect budget before auto-fallback fires.
#
# Rough cost of the handshake over our REST signaling:
#   - worker POST /rtc/offer         ~200ms (staging round-trip)
#   - miner polls /rtc/state (1Hz)   ~0-1s
#   - miner POST /rtc/answer         ~200ms
#   - worker polls /rtc/state        ~0-1s
#   - ICE trickle exchange           ~1-2s
#   - ICE connectivity checks        ~1-3s
#   - DTLS + SCTP handshake          ~300-500ms
#
# Typical success: 4-7s. 95th percentile: ~10s on a slow corp network.
# 15s gives comfortable headroom; longer makes the fallback feel sluggish
# to the 25% of users on symmetric NAT who will ALWAYS time out.
DEFAULT_WEBRTC_TIMEOUT_SECONDS = 15.0


async def build_transport(
    *,
    api_url: str,
    session_id: str,
    tunnel_token: str,
    broker_url: str,
    role: str,
    prefer: str = "auto",
    webrtc_timeout: float = DEFAULT_WEBRTC_TIMEOUT_SECONDS,
) -> TunnelTransport:
    """Return a connected `TunnelTransport` according to `prefer`.

    Args:
      api_url, session_id, tunnel_token: fed to WebRTC signaling.
      broker_url, tunnel_token: fed to the broker relay fallback.
      role: 'worker' or 'miner' — WebRTC needs to know which peer role
        to advertise when POSTing to /rtc/offer|answer|ice-candidate.
      prefer: 'auto' | 'webrtc' | 'broker'.
      webrtc_timeout: how long to wait for DataChannel open before
        bailing. Applies only in auto/webrtc modes.

    Raises on final failure after any fallback attempt was exhausted.
    """
    prefer = prefer.lower()
    if prefer not in ("auto", "webrtc", "broker"):
        raise ValueError(
            f"prefer must be one of auto/webrtc/broker, got {prefer!r}"
        )

    if prefer == "broker":
        return await _connect_broker(broker_url, tunnel_token)

    # auto or webrtc — try WebRTC first.
    webrtc = WebRTCTransport(
        api_url=api_url,
        session_id=session_id,
        tunnel_token=tunnel_token,
        role=role,
    )
    try:
        # WebRTCTransport.connect() has its own internal timeout
        # (20s in the base class) but for the hybrid case we want a
        # tighter overall budget so the fallback feels snappy.
        await asyncio.wait_for(webrtc.connect(), timeout=webrtc_timeout)
        log.info(
            "build_transport_webrtc_connected role=%s via=%s",
            role,
            webrtc.via.value,
        )
        return webrtc
    except asyncio.TimeoutError:
        log.warning(
            "build_transport_webrtc_timeout role=%s after=%.1fs",
            role,
            webrtc_timeout,
        )
        try:
            await webrtc.close()
        except Exception:  # noqa: BLE001
            pass
        if prefer == "webrtc":
            raise TimeoutError(
                f"WebRTC handshake timed out after {webrtc_timeout}s "
                f"and prefer='webrtc' (no fallback allowed)"
            )
        # auto → fall through to broker
    except Exception as e:  # noqa: BLE001
        log.warning(
            "build_transport_webrtc_failed role=%s err=%r",
            role,
            e,
        )
        try:
            await webrtc.close()
        except Exception:  # noqa: BLE001
            pass
        if prefer == "webrtc":
            raise

    log.info("build_transport_falling_back_to_broker role=%s", role)
    return await _connect_broker(broker_url, tunnel_token)


async def _connect_broker(broker_url: str, tunnel_token: str) -> BrokerTransport:
    """Connect broker relay. Callers reach into `.client.await_paired()`
    themselves when they need pairing semantics (broker-specific)."""
    t = BrokerTransport(broker_url=broker_url, token=tunnel_token)
    await t.connect()
    return t
