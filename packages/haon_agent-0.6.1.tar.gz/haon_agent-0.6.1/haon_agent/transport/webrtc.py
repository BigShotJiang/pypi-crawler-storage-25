"""WebRTC DataChannel transport.

P2P path between worker and miner. Bytes never touch the HAON broker
once the connection is established — only the ~10 KB of SDP/ICE
signaling goes through our API (via R1 endpoints
`/v1/sessions/{id}/rtc/*` that were already in production for the
remote_desktop pivot).

## Roles

Symmetric with a flag:
  - `role="worker"` creates the offer + creates the DataChannel
  - `role="miner"` waits for the offer, sends the answer, receives
    the DataChannel via `on("datachannel")`

This module is shipped as a copy on both worker-client and
miner-agent (`apps/miner-agent/haon_agent/transport/webrtc.py` is
byte-identical except for the module docstring/imports). Two copies
is pragmatic — there is no shared python package between the two
apps today, and inventing one for 200 LoC isn't worth the churn.

## Signaling

REST polling rather than WebSocket push:
  - POST /rtc/offer + POST /rtc/answer for SDP
  - POST /rtc/ice-candidate (trickle) + GET /rtc/state?since=...
    for the other side's candidates (poll ~1s cadence)
  - POST /rtc/connected when the DataChannel fires `open`

Polling is slower than push (~1-2s extra handshake latency) but
reuses the already-audited R1 endpoints. If we later need push we
swap to WebSocket/SSE; the transport contract doesn't change.

## Connection states

The transport exposes three observable states through the
`TransportVia` enum:
  - WEBRTC_P2P   — direct host/srflx candidates (no TURN)
  - WEBRTC_TURN  — relayed via our Coturn (Stage 3)
  - BROKER       — never from this class; fallback uses BrokerTransport

The selected path is reported via the `via` property once the
DataChannel is open. Before that it stays `WEBRTC_P2P` tentatively
(we refine to `WEBRTC_TURN` if the chosen candidate pair is type=relay).

## Why a single "tunnel" DataChannel, not N streams

aiortc supports many channels per peer connection but our
`tunnel_frames` micro-protocol already multiplexes streams inside
a single envelope pipe. Keeping one channel matches the broker
path's wire shape, so the proxy dispatcher (local_proxy.py) stays
identical. Stage 2 keeps this invariant.

See `docs/WEBRTC_TRANSPORT_MIGRATION.md` for the full rationale.
"""

from __future__ import annotations

import asyncio
import logging
import re
from typing import AsyncIterator

import httpx
from aiortc import (
    RTCConfiguration,
    RTCDataChannel,
    RTCIceCandidate,
    RTCIceServer,
    RTCPeerConnection,
    RTCSessionDescription,
)
from aiortc.sdp import candidate_from_sdp

from haon_agent.transport.base import TransportVia

log = logging.getLogger(__name__)


# Red-team T5 fix — redact IP addresses in log lines.
#
# ICE candidate lines look like:
#   candidate:0 1 UDP 2130706431 192.168.1.10 54321 typ host
#   candidate:1 1 UDP 1694498815 203.0.113.45 54322 typ srflx raddr 203.0.113.45 rport 54322
# SDP blocks carry IP addresses in c= and o= lines:
#   o=- 0 0 IN IP4 192.168.1.10
#   c=IN IP4 192.168.1.10
# All of these are peer PII under LGPD. We strip them before logging so
# ICE handshake diagnostics still surface in Loki without leaking
# residential IPs to log aggregators.
_IPV4_RE = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")
_IPV6_RE = re.compile(
    r"\b(?:[0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{1,4}\b"
)


def _redact_peer_data(s: str) -> str:
    """Mask IPv4 + IPv6 addresses in a string with `[ip-redacted]`.

    Safe to apply liberally — non-IP numerics like ports, priority
    values, foundations are left alone because they don't match the
    full four-octet / colon-separated forms.
    """
    if not s:
        return s
    s = _IPV4_RE.sub("[ip-redacted]", s)
    s = _IPV6_RE.sub("[ip6-redacted]", s)
    return s


# Default ICE servers. Stage 3 replaces with /v1/sessions/{id}/ice-servers
# (which returns our Coturn with HMAC-bound time-limited creds).
_DEFAULT_STUN = [
    RTCIceServer(urls=["stun:stun.l.google.com:19302"]),
    RTCIceServer(urls=["stun:stun1.l.google.com:19302"]),
]

# How long we'll wait for the DataChannel to hit `open` after local
# description is set. Beyond this the transport raises and the caller
# (build_transport with hybrid fallback) falls back to broker.
_CONNECT_TIMEOUT_SECONDS = 20.0

# How often we poll /rtc/state for new candidates from the other peer.
# Lower is faster pairing; higher is less API load. 1s is a good
# balance for a flow that typically finishes in 5-10 polls.
_POLL_INTERVAL_SECONDS = 1.0


class WebRTCTransport:
    """`TunnelTransport` over an RTCDataChannel.

    Usage (worker side)::

        transport = WebRTCTransport(
            api_url="https://api.haon.run",
            session_id="...",
            tunnel_token="...",
            role="worker",
        )
        await transport.connect()  # offer, poll for answer, wait for open
        # ... use as any TunnelTransport ...
        await transport.close()

    Miner side is identical but `role="miner"`.
    """

    def __init__(
        self,
        *,
        api_url: str,
        session_id: str,
        tunnel_token: str,
        role: str,
        ice_servers: list[RTCIceServer] | None = None,
    ) -> None:
        if role not in ("worker", "miner"):
            raise ValueError(f"role must be 'worker' or 'miner', got {role!r}")
        self._api_url = api_url.rstrip("/")
        self._session_id = session_id
        self._tunnel_token = tunnel_token
        self._role = role
        self._ice_servers = list(ice_servers) if ice_servers is not None else list(_DEFAULT_STUN)

        self._pc: RTCPeerConnection | None = None
        self._dc: RTCDataChannel | None = None
        self._dc_open = asyncio.Event()
        self._inbox: asyncio.Queue[bytes | None] = asyncio.Queue(maxsize=256)
        self._poll_task: asyncio.Task[None] | None = None
        self._closed = False
        # Tracked so we can report whether the selected pair is
        # direct (host/srflx) vs relayed (TURN). Filled after
        # iceConnectionState hits 'connected'.
        self._via: TransportVia = TransportVia.WEBRTC_P2P
        # Client-side dedup of our own submitted candidates so we don't
        # POST the same one twice if the polling loop re-sees state.
        self._sent_local_candidates: set[str] = set()
        # Server-side candidates we've already fed into addIceCandidate.
        self._seen_remote_candidates: set[str] = set()
        # Shared HTTP client for signaling. httpx.AsyncClient is
        # pool-aware — one per transport instance is fine.
        self._http = httpx.AsyncClient(
            timeout=httpx.Timeout(10.0),
            headers={"Authorization": f"Bearer {self._tunnel_token}"},
        )
        # Observability counters. WebRTC has no built-in byte accounting
        # visible from the Python layer, so we tally around send/recv.
        self._bytes_sent = 0
        self._bytes_recv = 0

    # ── Public API (TunnelTransport Protocol) ────────────────────────

    @property
    def via(self) -> TransportVia:
        return self._via

    # Byte counters for observability (TickEmitter reads these to
    # advertise bandwidth usage). Kept in parity with BrokerTransport
    # so any consumer can stay duck-typed on TunnelTransport.
    @property
    def bytes_sent(self) -> int:
        return self._bytes_sent

    @property
    def bytes_recv(self) -> int:
        return self._bytes_recv

    async def connect(self) -> None:
        """Run the full WebRTC handshake to DataChannel open.

        Raises TimeoutError / httpx.HTTPError / aiortc errors if any
        step fails. Callers wrap this in `build_transport()` for the
        hybrid fallback to `BrokerTransport`.
        """
        cfg = RTCConfiguration(iceServers=self._ice_servers)
        pc = RTCPeerConnection(configuration=cfg)
        self._pc = pc

        @pc.on("icecandidate")
        async def _on_icecandidate(candidate):  # noqa: ANN001
            # aiortc fires this with `None` to signal gathering-complete;
            # we don't need to POST an end-of-candidates marker because
            # our /rtc/state has no equivalent — the peer just keeps
            # polling until iceConnectionState flips.
            if candidate is None:
                return
            try:
                sdp = candidate.to_sdp() if hasattr(candidate, "to_sdp") else str(candidate)
            except Exception:  # noqa: BLE001
                return
            if sdp in self._sent_local_candidates:
                return
            self._sent_local_candidates.add(sdp)
            try:
                await self._post_ice(sdp, candidate.sdpMid, candidate.sdpMLineIndex)
            except Exception as e:  # noqa: BLE001
                # T5 — httpx errors can echo request body (candidate SDP
                # = peer IPs) back via validation errors. Redact before
                # logging.
                log.warning(
                    "webrtc_ice_post_failed type=%s msg=%s",
                    type(e).__name__,
                    _redact_peer_data(str(e))[:200],
                )

        @pc.on("iceconnectionstatechange")
        async def _on_ice_state():
            state = pc.iceConnectionState
            log.info("webrtc_ice_state=%s role=%s", state, self._role)
            if state in ("failed", "closed"):
                # Wake up any consumers blocked on recv()
                await self._signal_close()

        if self._role == "worker":
            # Worker creates the DataChannel BEFORE the offer — SCTP
            # negotiation is part of the SDP, so the channel must exist
            # at SDP-generation time on the offerer's side.
            dc = pc.createDataChannel("tunnel", ordered=True)
            self._bind_datachannel(dc)
            offer = await pc.createOffer()
            await pc.setLocalDescription(offer)
            await self._post_offer(pc.localDescription.sdp)
            # Miner will see the offer, send its answer + ICE. Poll.
            answer = await self._wait_for_peer_sdp("answer")
            await pc.setRemoteDescription(
                RTCSessionDescription(sdp=answer, type="answer")
            )
        else:
            # Miner is the answerer. Wait for the offer first.
            @pc.on("datachannel")
            def _on_dc(channel):
                self._bind_datachannel(channel)

            offer = await self._wait_for_peer_sdp("offer")
            await pc.setRemoteDescription(
                RTCSessionDescription(sdp=offer, type="offer")
            )
            answer = await pc.createAnswer()
            await pc.setLocalDescription(answer)
            await self._post_answer(pc.localDescription.sdp)

        # Start polling the other peer's ICE candidates. The /rtc/state
        # endpoint returns all candidates (both roles); we pick the
        # ones that aren't ours + not already-fed.
        self._poll_task = asyncio.create_task(self._poll_remote_ice_loop())

        # Block until the datachannel is open (or timeout). Separate
        # from ICE connection state on purpose — SCTP handshake runs
        # on top of DTLS and takes an extra RTT.
        try:
            await asyncio.wait_for(
                self._dc_open.wait(), timeout=_CONNECT_TIMEOUT_SECONDS
            )
        except asyncio.TimeoutError as e:
            await self.close()
            raise TimeoutError(
                f"WebRTC DataChannel did not open within "
                f"{_CONNECT_TIMEOUT_SECONDS}s (role={self._role})"
            ) from e

        # Refine `via` based on the selected candidate pair. If we're
        # on a relay candidate, tag WEBRTC_TURN so metrics + UI show
        # which path the session actually rode.
        self._via = self._infer_via()

        # Dual-peer attestation — see services/api/app/modules/rtc/router.py
        # `mark_connected` docstring. Only after both roles POST does
        # the session's rtc state flip to 'connected'.
        try:
            await self._post_connected()
        except Exception as e:  # noqa: BLE001
            # Non-fatal: the session still works even if this attestation
            # POST fails (billing gates are server-side and will retry
            # through receipts). Logged for observability.
            log.warning("webrtc_connected_post_failed: %r", e)

        log.info(
            "webrtc_connected role=%s via=%s",
            self._role,
            self._via.value,
        )

    async def send(self, frame: bytes) -> None:
        if self._closed:
            raise RuntimeError("transport closed")
        dc = self._dc
        if dc is None or dc.readyState != "open":
            raise RuntimeError(f"datachannel not open (state={dc.readyState if dc else 'none'})")
        # aiortc send() accepts bytes or str; we always pass bytes.
        dc.send(frame)
        self._bytes_sent += len(frame)

    async def recv(self) -> AsyncIterator[bytes]:
        while True:
            item = await self._inbox.get()
            if item is None:
                # Sentinel — transport closed / peer hung up.
                return
            yield item

    async def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        await self._signal_close()
        if self._poll_task is not None and not self._poll_task.done():
            self._poll_task.cancel()
            try:
                await self._poll_task
            except (asyncio.CancelledError, Exception):  # noqa: BLE001
                pass
        if self._dc is not None:
            try:
                self._dc.close()
            except Exception:  # noqa: BLE001
                pass
        if self._pc is not None:
            try:
                await self._pc.close()
            except Exception:  # noqa: BLE001
                pass
        try:
            await self._http.aclose()
        except Exception:  # noqa: BLE001
            pass

    # ── DataChannel wiring ───────────────────────────────────────────

    def _bind_datachannel(self, dc: RTCDataChannel) -> None:
        """Hook the channel's events into our inbox + open signal.

        Called by both roles — the worker binds the channel it CREATED,
        the miner binds the one it RECEIVED via on("datachannel").

        Race-safe: on the answerer side, aiortc fires `on("datachannel")`
        only AFTER the SCTP association is already open, so by the time
        we register the `open` listener the event has already fired and
        we'd miss it forever. Mirror the current `readyState` into
        `_dc_open` explicitly to cover that case — if the channel is
        already open, the event is set immediately.
        """
        self._dc = dc

        @dc.on("open")
        def _on_open():
            log.info("webrtc_datachannel_open role=%s label=%s", self._role, dc.label)
            self._dc_open.set()

        @dc.on("message")
        def _on_message(data):
            # aiortc delivers bytes for binary messages, str for text.
            # Our tunnel_frames are always binary.
            if isinstance(data, str):
                data = data.encode("utf-8")
            self._bytes_recv += len(data)
            # Red-team T2 fix — DataChannel is ordered=True and our
            # tunnel_frames has no sequence number. Dropping a frame
            # mid-stream = silent TCP-stream corruption (HTTP body
            # truncation, LM Studio receives partial JSON, etc). A
            # corrupted stream is WORSE than a dead one: the consumer
            # has no way to detect the bad bytes. So: on overflow,
            # TEAR DOWN the transport. recv() consumer sees clean EOF,
            # local_proxy dispatcher fires CLOSE on every live stream,
            # HTTP clients see connection reset → retry. Correct over
            # forgiving.
            try:
                self._inbox.put_nowait(data)
            except asyncio.QueueFull:
                log.error(
                    "webrtc_inbox_full_teardown role=%s inbox_max=%d — "
                    "slow consumer; tearing down transport to avoid "
                    "silent stream corruption",
                    self._role,
                    self._inbox.maxsize,
                )
                # Schedule signal-close on the loop; we're in a sync
                # aiortc callback here so we can't `await`.
                loop = asyncio.get_event_loop()
                loop.call_soon_threadsafe(
                    lambda: asyncio.ensure_future(self._signal_close())
                )

        @dc.on("close")
        def _on_close():
            log.info("webrtc_datachannel_close role=%s", self._role)
            # Wake any consumer blocked on recv()
            try:
                self._inbox.put_nowait(None)
            except asyncio.QueueFull:
                pass

        # Cover the race described above. `readyState` is a plain
        # attribute, safe to read synchronously.
        if dc.readyState == "open":
            log.info(
                "webrtc_datachannel_already_open role=%s label=%s",
                self._role,
                dc.label,
            )
            self._dc_open.set()

    async def _signal_close(self) -> None:
        try:
            self._inbox.put_nowait(None)
        except asyncio.QueueFull:
            pass

    # ── Signaling (REST polling) ─────────────────────────────────────

    async def _post_offer(self, sdp: str) -> None:
        r = await self._http.post(
            f"{self._api_url}/v1/sessions/{self._session_id}/rtc/offer",
            json={"role": self._role, "sdp": sdp},
        )
        r.raise_for_status()

    async def _post_answer(self, sdp: str) -> None:
        r = await self._http.post(
            f"{self._api_url}/v1/sessions/{self._session_id}/rtc/answer",
            json={"role": self._role, "sdp": sdp},
        )
        r.raise_for_status()

    async def _post_ice(self, candidate: str, sdp_mid: str | None, sdp_m_line_index: int | None) -> None:
        r = await self._http.post(
            f"{self._api_url}/v1/sessions/{self._session_id}/rtc/ice-candidate",
            json={
                "role": self._role,
                "candidate": candidate,
                "sdp_mid": sdp_mid,
                "sdp_m_line_index": sdp_m_line_index,
            },
        )
        r.raise_for_status()

    async def _post_connected(self) -> None:
        r = await self._http.post(
            f"{self._api_url}/v1/sessions/{self._session_id}/rtc/connected",
            json={"role": self._role},
        )
        r.raise_for_status()

    async def _get_state(self) -> dict:
        r = await self._http.get(
            f"{self._api_url}/v1/sessions/{self._session_id}/rtc/state",
        )
        r.raise_for_status()
        return r.json()

    async def _wait_for_peer_sdp(self, kind: str) -> str:
        """Poll /rtc/state until the peer's offer/answer SDP is present.

        `kind` is 'offer' or 'answer'. Bounded by _CONNECT_TIMEOUT_SECONDS
        to prevent a stuck session from hanging the CLI forever.
        """
        key = f"{kind}_sdp"
        deadline = asyncio.get_event_loop().time() + _CONNECT_TIMEOUT_SECONDS
        while True:
            remaining = deadline - asyncio.get_event_loop().time()
            if remaining <= 0:
                raise TimeoutError(
                    f"timed out waiting for peer {kind} on session "
                    f"{self._session_id}"
                )
            try:
                state = await self._get_state()
            except httpx.HTTPError as e:
                log.warning("webrtc_state_poll_error: %r", e)
                await asyncio.sleep(_POLL_INTERVAL_SECONDS)
                continue
            sdp = state.get(key)
            if sdp:
                return sdp
            await asyncio.sleep(_POLL_INTERVAL_SECONDS)

    async def _poll_remote_ice_loop(self) -> None:
        """Background task: periodically fetch /rtc/state and feed the
        peer's new ICE candidates into our RTCPeerConnection.

        Cancellable. Exits cleanly when the transport closes.
        """
        try:
            while not self._closed:
                try:
                    state = await self._get_state()
                except httpx.HTTPError as e:
                    log.debug("webrtc_ice_poll_error: %r", e)
                    await asyncio.sleep(_POLL_INTERVAL_SECONDS)
                    continue
                for cand in state.get("ice_candidates", []) or []:
                    if cand.get("role") == self._role:
                        continue  # our own candidate
                    key = cand.get("candidate", "") or ""
                    if key in self._seen_remote_candidates:
                        continue
                    self._seen_remote_candidates.add(key)
                    try:
                        # aiortc's candidate_from_sdp expects the raw
                        # candidate line ("candidate:..." — without any
                        # "a=" prefix). The API stores them exactly as
                        # emitted by the browser/aiortc, so no trimming.
                        ice = candidate_from_sdp(key)
                        ice.sdpMid = cand.get("sdp_mid")
                        ice.sdpMLineIndex = cand.get("sdp_m_line_index")
                        if self._pc is not None:
                            await self._pc.addIceCandidate(ice)
                    except Exception as e:  # noqa: BLE001
                        # T5 — `key` holds the raw ICE candidate line
                        # which contains the peer's IP. Redact both it
                        # and the exception repr (aiortc errors often
                        # echo the offending candidate).
                        log.warning(
                            "webrtc_add_ice_failed candidate=%s err_type=%s err=%s",
                            _redact_peer_data(key)[:120],
                            type(e).__name__,
                            _redact_peer_data(str(e))[:200],
                        )
                # If we're past the handshake + connected, the browser/
                # other peer shouldn't keep sending new candidates — but
                # aiortc doesn't mind if polling continues until close.
                await asyncio.sleep(_POLL_INTERVAL_SECONDS)
        except asyncio.CancelledError:
            raise

    # ── Observability helper ─────────────────────────────────────────

    def _infer_via(self) -> TransportVia:
        """Return WEBRTC_TURN if the selected candidate pair uses relay,
        else WEBRTC_P2P. Best-effort — aiortc doesn't expose
        selectedCandidatePair cleanly on all versions, so we inspect
        the nominated pair via the internal ice transport if available.
        """
        pc = self._pc
        if pc is None:
            return TransportVia.WEBRTC_P2P
        try:
            # aiortc exposes the sctp transport → dtls → ice. We walk
            # to the ice transport and read its `_selected_candidate_pair`
            # which is an internal attribute in current aiortc but has
            # been stable across 1.5+.
            sctp = getattr(pc, "_sctp", None)
            if sctp is None:
                return TransportVia.WEBRTC_P2P
            dtls = getattr(sctp, "transport", None)
            if dtls is None:
                return TransportVia.WEBRTC_P2P
            ice = getattr(dtls, "transport", None)
            if ice is None:
                return TransportVia.WEBRTC_P2P
            # aioice's Connection has `selected_pair` or similar.
            ice_conn = getattr(ice, "_connection", None) or getattr(ice, "iceGatherer", None)
            pair = getattr(ice, "_selected_candidate_pair", None) or getattr(
                ice_conn, "_selected_pair", None
            )
            if pair is None:
                return TransportVia.WEBRTC_P2P
            local = getattr(pair, "local_candidate", None) or getattr(pair, "local", None)
            remote = getattr(pair, "remote_candidate", None) or getattr(pair, "remote", None)
            if local is not None and getattr(local, "type", "") == "relay":
                return TransportVia.WEBRTC_TURN
            if remote is not None and getattr(remote, "type", "") == "relay":
                return TransportVia.WEBRTC_TURN
            return TransportVia.WEBRTC_P2P
        except Exception:  # noqa: BLE001
            return TransportVia.WEBRTC_P2P
