"""The agent's main orchestrator loop.

    heartbeat (every N seconds)
      │
      ├── if heartbeat.session_accepted_ids non-empty:
      │     for each session_id:
      │       accept_session(session_id)
      │
      └── sleep(heartbeat_interval)

    accept_session(session_id):
      call POST /v1/sessions/{id}/start → handoff
      connect to broker with handoff.tunnel_token
      wait for PAIRED
      spawn runtime
      concurrently:
        - forward worker DATA frames to runtime.push
        - forward runtime output to broker.send_data
      on CLOSE / UNPAIRED / runtime stop: tear everything down, POST /close.

Recovery:
    If heartbeat fails we keep retrying with exponential backoff. If broker
    disconnects mid-session we close the session via API. No silent failures.
"""

from __future__ import annotations

import asyncio
import contextlib
from dataclasses import dataclass
from typing import Awaitable, Callable

import structlog

from haon_agent.api_client import ApiClient, ApiError, SessionHandoff
from haon_agent.broker_client import BrokerClient, FrameType
from haon_agent.config import AgentConfig
from haon_agent.hub import HubSessionWorker
from haon_agent.runtime import get_runtime
from haon_agent.runtime.base import Runtime

log = structlog.get_logger("agent")


@dataclass
class AgentDeps:
    api: ApiClient
    config: AgentConfig
    # Factory so tests can inject a fake BrokerClient.
    broker_factory: Callable[[str, str], BrokerClient] = lambda url, token: BrokerClient(url, token)
    # Runtime resolver (defaults to the module-level registry).
    runtime_factory: Callable[[str], Runtime] = get_runtime


class Agent:
    """Long-lived orchestrator spawned by `haon-agent run`.

    Owns:
      - the heartbeat loop (`_main_loop`) that tells the API "I'm alive"
        and collects session offers;
      - the per-session pipeline tasks (`_run_session`) that bridge broker
        DATA frames ↔ the runtime adapter.

    Concurrency: one outer asyncio task runs the heartbeat loop. Each
    accepted session spawns its own task stored in `_active_sessions`;
    shutdown (via `request_stop`) cancels them all and awaits cleanup.
    """
    def __init__(self, deps: AgentDeps) -> None:
        self._deps = deps
        self._running = False
        self._active_sessions: dict[str, asyncio.Task[None]] = {}
        # Phase 4.6 — hub-aware sibling worker. Polls
        # /v1/my-hub/sessions/pending every ~3s and serves each
        # claimed session in its own asyncio.Task. Created lazily in
        # `run()` so tests that build an Agent without hub support
        # (e.g. legacy unit tests of the marketplace path) don't pay
        # the polling cost.
        self._hub_worker: HubSessionWorker | None = None
        self._hub_task: asyncio.Task[None] | None = None
        # Cooldown table for sessions whose pipeline just failed. Prevents the
        # "heartbeat re-offer hot loop" bug: if server-side state has not yet
        # flipped the session out of `starting/active`, the next heartbeat
        # will re-include the same session_id in `session_accepted_ids` and
        # we would spawn another pipeline task that fails again in ~15s,
        # ad infinitum. The cooldown is a client-side brake — the server
        # sweeper will eventually reap the dead session and stop offering it.
        # Maps session_id → monotonic-time expiry; purged lazily in
        # _main_loop. Report: docs/CONCURRENCY_AUDIT.md S0-2.
        self._session_cooldown: dict[str, float] = {}
        self._stop_event = asyncio.Event()
        # R2 step 2: cached public IP for WebRTC/remote_desktop sessions.
        # Surfaced to the browser-side frontend as a srflx ICE candidate
        # hint when the Selkies/Go+Pion integration lands
        # (see docs/R2_PIVOT_SELKIES.md).
        #
        # MED-D6: previously discovered only once at startup. Consumer-
        # grade ISPs rotate DHCP leases on a ~24h cycle — a long-running
        # agent would then advertise an IP that no longer routes to it
        # and Moonlight clients couldn't reach the miner. Periodic
        # re-discovery in `_main_loop` keeps the cache fresh; 3 HTTPS
        # GETs every few hours is negligible traffic.
        self._public_ip: str | None = None
        self._public_ip_last_checked_mono: float = 0.0
        self._public_ip_refresh_interval_seconds: float = 6 * 3600.0
        # P1 — runtime_capabilities cache, populated by `_probe_gpu_once`
        # at agent start. None until probe completes; `{}` for hosts
        # without NVIDIA. The first successful heartbeat ships this
        # payload to the API and flips `_gpu_caps_sent`; subsequent
        # heartbeats omit the field (server preserves cached value when
        # `runtime_capabilities=None`). See docs/audits/2026-04-27 audit
        # plan and apps/miner-agent/haon_agent/gpu_probe.py.
        self._gpu_caps: dict | None = None
        self._gpu_caps_sent: bool = False

    async def run(self) -> None:
        """Drive the heartbeat loop until `request_stop` fires.

        Called from `haon-agent run` → `cli.run` → `asyncio.run(_main())`.
        Guarantees that on return, every in-flight session task has been
        cancelled and awaited (best-effort) so the next process start
        finds a clean slate.
        """
        self._running = True
        log.info("agent_starting", api_url=self._deps.config.api_url)

        # R2 pivot: remote_desktop auto-advertise is OFF until the
        # WebRTC streamer integration lands. Operators that want to run
        # the stub (e.g. to smoke-test the R1 signaling path) must set
        # remote_desktop explicitly in agent.toml's supported_runtimes.
        # See docs/R2_PIVOT_SELKIES.md.

        # Best-effort public IP discovery. Failure is non-fatal — most
        # runtimes don't need it, and the upcoming WebRTC streamer can
        # still pair via LAN ICE candidates for same-network workers.
        await self._refresh_public_ip()

        # P1 — GPU capability probe. One-shot at boot; result cached on
        # `self._gpu_caps` and shipped with the first heartbeat. Probe
        # is best-effort: CPU-only or non-NVIDIA hosts get `{}` and the
        # marketplace `?capability=cuda` filter excludes them naturally.
        try:
            from haon_agent.gpu_probe import detect as _probe_gpu
            self._gpu_caps = await _probe_gpu()
            log.info(
                "gpu_probe_complete",
                has_cuda=bool(self._gpu_caps.get("cuda", {}).get("enabled"))
                if self._gpu_caps else False,
                gpu_count=self._gpu_caps.get("gpu_count", 0) if self._gpu_caps else 0,
            )
        except Exception:  # noqa: BLE001
            log.exception("gpu_probe_raised_unexpected")
            self._gpu_caps = {}

        # Phase 4.6 — start hub-aware sibling worker before the main
        # marketplace loop. They run concurrently and share no state
        # (per the red-team T1/T2 isolation requirement). On shutdown
        # we stop the hub worker first, then cancel marketplace tasks.
        hub_disabled = bool(getattr(self._deps.config, "hub_disabled", False))
        if not hub_disabled:
            self._hub_worker = HubSessionWorker(api=self._deps.api)
            self._hub_task = asyncio.create_task(self._hub_worker.run_forever())
            log.info("hub_worker_started")

        try:
            await self._main_loop()
        finally:
            self._running = False
            # Stop hub worker first — it may have in-flight tunnels
            # that need to send CLOSE frames before we tear down.
            if self._hub_worker is not None:
                self._hub_worker.request_stop()
            if self._hub_task is not None:
                with contextlib.suppress(asyncio.CancelledError):
                    await asyncio.wait_for(self._hub_task, timeout=8.0)
            # Cancel any active session tasks.
            for sid, task in list(self._active_sessions.items()):
                log.info("session_task_cancelling", session_id=sid)
                task.cancel()
            for task in list(self._active_sessions.values()):
                with contextlib.suppress(asyncio.CancelledError):
                    await task
            log.info("agent_stopped")

    def request_stop(self) -> None:
        self._stop_event.set()

    async def _refresh_public_ip(self) -> None:
        """MED-D6: re-discover the agent's public IP. Called at startup
        and periodically from the main loop so consumer-ISP DHCP lease
        rotations don't leave stale ICE candidate hints on long-running
        agents. Swallows all errors — this is best-effort, most runtimes
        don't need it, and WebRTC has other discovery paths (STUN, LAN).
        """
        try:
            from haon_agent.net.public_ip import discover
            discovered = await discover()
            if discovered is not None:
                prev = self._public_ip
                self._public_ip = discovered.address
                self._public_ip_last_checked_mono = (
                    asyncio.get_event_loop().time()
                )
                if prev != discovered.address:
                    log.info(
                        "public_ip_discovered",
                        address=discovered.address,
                        is_v6=discovered.is_v6,
                        provider=discovered.provider,
                        previous=prev,
                    )
            else:
                log.warning("public_ip_discovery_failed_all_providers")
        except Exception:  # noqa: BLE001
            log.exception("public_ip_discovery_raised")

    async def _main_loop(self) -> None:
        """Heartbeat + session-offer pickup loop.

        Calls POST /v1/machines/{machine_id}/heartbeat every
        `heartbeat_interval_seconds`. The response carries any newly
        accepted session IDs the marketplace has attached to this machine;
        each one spawns a `_run_session` task.

        Backoff: transient errors (network, 5xx) exponentially back off
        up to 30s. ApiError logs a warning but does not back off — the
        API is reachable, just telling us no.
        """
        cfg = self._deps.config
        if not cfg.machine_id:
            raise RuntimeError("machine_id not configured; run `haon-agent register` first")

        # Reconcile the server-side machine row with the operator's
        # current agent.toml so marketplace listings reflect any runtime
        # added (or reordered) since last boot. Heartbeats don't carry
        # supported_runtimes, so without this step a toml edit has no
        # effect until the machine is re-registered from scratch.
        # Non-blocking — if the PATCH fails, fall through to the main
        # loop and keep heartbeating against the stale list.
        try:
            await self._deps.api.update_machine_runtimes(
                cfg.machine_id,
                list(cfg.supported_runtimes or []),
            )
            log.info(
                "machine_runtimes_reconciled",
                machine_id=cfg.machine_id,
                runtimes=list(cfg.supported_runtimes or []),
            )
        except Exception as e:  # noqa: BLE001
            # Capture the error message in the log line so it shows up
            # in the JSON stream (plain log.exception bury the cause in
            # a traceback that doesn't round-trip through structlog).
            log.warning(
                "machine_runtimes_reconcile_failed",
                error_type=type(e).__name__,
                error=str(e) or repr(e),
                machine_id=cfg.machine_id,
                hint=(
                    "if this says FORBIDDEN, your account role is 'worker' — "
                    "machines can only be PATCH'd by role=miner or admin. "
                    "Update the machine's supported_runtimes via the "
                    "admin-panel → Users → Credit/Edit flow, or ask an "
                    "admin to run: PATCH /v1/machines/{id} "
                    "{supported_runtimes: [...]}."
                ),
            )

        # Ensure an initial marketplace offer exists. Non-blocking: any
        # failure here must not prevent heartbeats. Runs once per process.
        await self._ensure_initial_offer()

        backoff = 1.0
        while not self._stop_event.is_set():
            # MED-D6: periodic public-IP refresh. No-op if the TTL
            # hasn't elapsed. Runs BEFORE heartbeat so if the miner's
            # upstream IP just rotated, the marketplace sees the new
            # address on the next advertised session.
            now_mono_ip = asyncio.get_event_loop().time()
            if (
                now_mono_ip - self._public_ip_last_checked_mono
                >= self._public_ip_refresh_interval_seconds
            ):
                await self._refresh_public_ip()

            try:
                # P1 — advertise capabilities on the FIRST successful
                # heartbeat only. Subsequent heartbeats omit the field
                # (None) so the server preserves cached state, saving
                # ~500 B per heartbeat across the fleet. Re-advertise
                # only happens on agent restart (cache reset to None).
                caps_payload = (
                    self._gpu_caps if not self._gpu_caps_sent else None
                )
                resp = await self._deps.api.heartbeat(
                    cfg.machine_id,
                    runtime_ready=True,
                    pending_sessions=len(self._active_sessions),
                    runtime_capabilities=caps_payload,
                )
                if caps_payload is not None:
                    self._gpu_caps_sent = True
                backoff = 1.0  # reset on success
                offered = resp.get("session_accepted_ids") or []
                now_mono = asyncio.get_event_loop().time()
                # Purge expired cooldown entries so a legit re-offer after a
                # long gap is honoured.
                self._session_cooldown = {
                    s: exp for s, exp in self._session_cooldown.items() if exp > now_mono
                }
                # H12: purge completed tasks ONCE per heartbeat, BEFORE we
                # decide which offers to accept. Was previously nested
                # inside the `for sid in offered` loop → O(len(offered) ×
                # len(active)) scan per heartbeat, and if no offers came
                # through it never ran at all (so a dead task lingered
                # and got counted in `pending_sessions`, confusing the
                # scheduler's capacity accounting).
                for done_sid in [
                    s for s, t in self._active_sessions.items() if t.done()
                ]:
                    self._active_sessions.pop(done_sid, None)

                for sid in offered:
                    if sid in self._active_sessions:
                        continue
                    cooldown_until = self._session_cooldown.get(sid)
                    if cooldown_until is not None and cooldown_until > now_mono:
                        # Recently failed — skip this heartbeat and log at
                        # debug (not warn) so we don't spam the journal.
                        log.debug(
                            "session_offer_skipped_cooldown",
                            session_id=sid,
                            retry_in_seconds=int(cooldown_until - now_mono),
                        )
                        continue
                    log.info("session_offered_received", session_id=sid)
                    task = asyncio.create_task(self._run_session(sid))
                    self._active_sessions[sid] = task
                    # Belt-and-suspenders: `_run_session` pops itself from
                    # the dict in its finally block. But if an unexpected
                    # refactor ever moves state outside finally, or the
                    # task is cancelled before reaching finally, the dict
                    # entry would leak. add_done_callback guarantees the
                    # entry is cleared regardless of how the task ends
                    # (normal return, exception, cancellation). Callback
                    # runs on the event loop thread — no lock needed.
                    task.add_done_callback(
                        lambda t, s=sid: self._active_sessions.pop(s, None)
                    )
            except ApiError as e:
                log.warning(
                    "heartbeat_failed",
                    code=e.code,
                    status_code=e.status_code,
                )
            except Exception as e:  # noqa: BLE001
                log.exception("heartbeat_unhandled_error", error=str(e))
                backoff = min(backoff * 2, 30.0)

            try:
                await asyncio.wait_for(
                    self._stop_event.wait(),
                    timeout=cfg.heartbeat_interval_seconds if backoff <= 1.0 else backoff,
                )
            except asyncio.TimeoutError:
                pass

    # ── Auto-offer bootstrap ────────────────────────────────────────────

    async def _ensure_initial_offer(self) -> None:
        """Create this machine's first marketplace offer if none exists.

        Non-technical miners otherwise have to hand-craft a POST request
        after pairing just to appear in the marketplace; this closes
        that gap. Runs exactly once per process (right before the
        heartbeat loop). Never raises: API failures are logged and we
        fall through so heartbeats still run.

        Emits one of:
          - `auto_offer_created` (INFO)    — a new offer was published.
          - `auto_offer_skipped` (DEBUG)   — machine already has offers.
          - `auto_offer_failed`  (WARN)    — list or create call failed.
          - `auto_offer_skipped_no_price` (WARN) — config missing price.
        """
        cfg = self._deps.config
        machine_id = cfg.machine_id
        assert machine_id is not None  # caller checks

        if not cfg.price_per_hour:
            log.warning(
                "auto_offer_skipped_no_price",
                reason="price_per_hour is empty; configure it before publishing",
            )
            return

        try:
            existing = await self._deps.api.list_my_offers(machine_id)
        except ApiError as e:
            log.warning(
                "auto_offer_failed",
                step="list",
                code=e.code,
                message=e.message,
            )
            return
        except Exception as e:  # noqa: BLE001
            log.warning(
                "auto_offer_failed",
                step="list",
                code="UNHANDLED",
                message=str(e),
            )
            return

        if existing:
            log.debug("auto_offer_skipped", existing_count=len(existing))
            return

        try:
            offer = await self._deps.api.create_offer(
                machine_id,
                price_per_hour=cfg.price_per_hour,
                min_session_minutes=cfg.min_session_minutes,
                max_session_hours=8,  # alpha default; see docs/alpha-user-guide.md §5
            )
        except ApiError as e:
            log.warning(
                "auto_offer_failed",
                step="create",
                code=e.code,
                message=e.message,
            )
            return
        except Exception as e:  # noqa: BLE001
            log.warning(
                "auto_offer_failed",
                step="create",
                code="UNHANDLED",
                message=str(e),
            )
            return

        log.info(
            "auto_offer_created",
            offer_id=offer.get("id"),
            price_per_hour=cfg.price_per_hour,
            runtimes=list(cfg.supported_runtimes),
        )

    # ── Per-session pipeline ────────────────────────────────────────────

    async def _run_session(self, session_id: str) -> None:
        """Run one session end-to-end: handoff → broker → runtime → tick loop.

        Sequence:
          1. POST /v1/sessions/{id}/start → `SessionHandoff` with tunnel creds.
          2. Resolve the Runtime via `runtime_factory(name)`.
          3. Connect BrokerClient; race `await_paired(15s)` with runtime start.
          4. Spawn TickEmitter (10s cadence, POST /v1/usage/ticks).
          5. Pump `broker.events()`:
               DATA     → `runtime.push(payload)`
               UNPAIRED → worker dropped → end session.
               CLOSE    → broker-initiated close.
               ERROR    → broker protocol error.
          6. Stop tick emitter, stop runtime, close broker, POST /close.

        Never raises: any exception logs + closes the session with
        reason="miner_closed".
        """
        try:
            handoff = await self._deps.api.start_session(session_id)
        except ApiError as e:
            # Without a cooldown this branch was a hot loop: the server
            # still has the session in `starting` state (we didn't close
            # it), so the next heartbeat re-offers the same session_id,
            # we retry start_session, it rejects again, repeat every
            # `heartbeat_interval_seconds`. Same brake as the pipeline-
            # error branch below.
            log.warning(
                "session_start_rejected",
                session_id=session_id,
                code=e.code,
            )
            self._session_cooldown[session_id] = (
                asyncio.get_event_loop().time() + 120.0
            )
            return

        runtime_name = handoff.runtime or self._deps.config.default_runtime
        try:
            runtime = self._deps.runtime_factory(runtime_name)
        except KeyError:
            # Runtime name this agent doesn't register (e.g. server thinks
            # we support 'comfyui' but this binary doesn't). We call
            # _safe_close to transition the server-side row to 'failed',
            # but if THAT request fails (transient network) the session
            # stays 'starting' and the next heartbeat re-offers it.
            # Cooldown protects against that hot loop too.
            log.warning(
                "runtime_unsupported",
                session_id=session_id,
                runtime=runtime_name,
            )
            await self._safe_close(session_id, reason="miner_closed")
            self._session_cooldown[session_id] = (
                asyncio.get_event_loop().time() + 120.0
            )
            return

        # Inject session_id into runtimes that need it. Only remote_desktop
        # has a set_session method today — others are stateless w.r.t.
        # session identity, so we just check duck-typed existence.
        if hasattr(runtime, "set_session"):
            try:
                runtime.set_session(session_id)  # type: ignore[attr-defined]
            except Exception:  # noqa: BLE001
                log.exception("runtime_set_session_failed")

        # Phase 26A / Stage 4 — transport selection.
        # HTTP runtimes (ollama, comfyui, vllm, tgi, custom_http) are
        # byte-relay workloads and benefit from the P2P WebRTC path.
        # Delegate to _run_http_session which uses `build_transport()`
        # (auto → WebRTC first, broker fallback on ICE failure).
        # Legacy runtimes (echo, remote_desktop) keep the broker-only
        # code path below untouched — they have broker-specific
        # semantics (PING keepalive for R1 signaling, raw-pipe push
        # for echo) that don't benefit from the abstraction.
        from haon_agent import port_forward as _pf_mod
        _is_http_runtime = _pf_mod.runtime_default_port(runtime_name) is not None
        if _is_http_runtime:
            await self._run_http_session(
                session_id=session_id,
                handoff=handoff,
                runtime=runtime,
                runtime_name=runtime_name,
            )
            return

        broker = self._deps.broker_factory(
            handoff.tunnel_broker_url, handoff.tunnel_token
        )
        close_reason = "miner_closed"
        tick_emitter = None
        paired_task: asyncio.Task | None = None
        broker_keepalive: asyncio.Task | None = None
        # Pre-declared so the outer `finally:` can safely reference it
        # even if runtime.start() raises before the port-forward setup
        # block below runs.
        _forwarder = None  # type: ignore[assignment]  # set below if HTTP runtime
        # R2 pivot bring-up mode: remote_desktop sessions pair P2P via R1
        # signaling (browser /s/[id] ↔ /m/[id]), NOT via the broker. The
        # worker peer never opens a broker socket, so await_paired() would
        # timeout at 15s and kill the session. Skip the pair-wait for this
        # runtime; the R1 signaling endpoints + receipts do the work.
        is_remote_desktop = runtime_name == "remote_desktop"
        try:
            await broker.connect()
            if not is_remote_desktop:
                # Wait for PAIRED — the worker-client opens the other side
                # of the tunnel. Only runtimes whose data-plane rides the
                # broker bytes (echo, ollama, comfyui, custom_http) need this.
                paired_task = asyncio.create_task(broker.await_paired(timeout=15))

            async def on_runtime_output(data: bytes) -> None:
                await broker.send_data(data)

            await runtime.start(on_runtime_output)
            if paired_task is not None:
                await paired_task

            # Phase 26A / AI marketplace pivot — port-forward mode.
            #
            # Runtimes that speak HTTP on a local port (ollama, comfyui,
            # vllm, tgi, custom_http...) route worker bytes through a
            # TCP multiplexer (see `haon_agent/port_forward.py`) instead
            # of the raw-pipe `runtime.push()` semantics used by `echo`
            # and `remote_desktop`. The multiplexer opens per-stream
            # TCP sockets to 127.0.0.1:{runtime_port} on demand so the
            # worker's local proxy (see `apps/worker-client/.../local_proxy.py`)
            # can forward *any* HTTP client — LM Studio, Jan, curl, the
            # OpenAI SDK — against the rented GPU.
            #
            # Legacy runtimes (runtime_name not in RUNTIMES_WITH_PORT)
            # keep the raw-pipe path below unchanged — this avoids any
            # regression in `echo` and the remote_desktop bring-up mode.
            from haon_agent import port_forward as _pf
            _rt_port = _pf.runtime_default_port(runtime_name)
            if _rt_port is not None:
                _forwarder = _pf.TunnelPortForwarder(target_port=_rt_port)
                await _forwarder.start(broker.send_data)
                log.info(
                    "session_port_forward_enabled",
                    session_id=session_id,
                    runtime=runtime_name,
                    runtime_port=_rt_port,
                )

            # R2.v2 bring-up mode: print the /m/ URL with the miner-role
            # tunnel token so the operator can open the miner peer in a
            # browser tab. /m/ requires role=miner (CRIT-8 dual-attest)
            # and the agent is the only place this token exists in the
            # whole system; without printing it, the operator can never
            # complete the browser↔browser handshake.
            if is_remote_desktop:
                # Derive the marketplace frontend host from the API URL.
                # api.haon.run → haon.run; localhost:8000 → localhost:3000.
                api_host = self._deps.config.api_url.replace(
                    "https://", ""
                ).replace("http://", "").rstrip("/")
                if api_host.startswith("api."):
                    front_host = "https://" + api_host[len("api."):]
                elif api_host.startswith("localhost") or api_host.startswith("127."):
                    front_host = "http://" + api_host.split(":")[0] + ":3000"
                else:
                    front_host = "https://" + api_host
                miner_url_full = (
                    f"{front_host}/m/{session_id}"
                    f"#token={handoff.tunnel_token}"
                )
                log.info(
                    "remote_desktop_miner_url_ready",
                    session_id=session_id,
                    miner_url=miner_url_full,
                    note=(
                        "Auto-opening in default browser. Session tokens "
                        "TTL 5 min — acting fast closes the copy-paste "
                        "race window that was producing "
                        "'Session token rejected (expired?)' on /m/."
                    ),
                )
                # Zero-friction bring-up: open the miner peer page
                # automatically. Non-fatal if webbrowser can't resolve a
                # browser (headless VM, misconfigured DISPLAY on Linux) —
                # operator still has the URL in the log above.
                try:
                    import webbrowser
                    webbrowser.open(miner_url_full, new=2)
                except Exception:  # noqa: BLE001
                    log.warning(
                        "remote_desktop_miner_autoopen_failed",
                        session_id=session_id,
                    )

            log.info(
                "session_paired_and_running",
                session_id=session_id,
                mode="r1-signaling" if is_remote_desktop else "broker-paired",
            )

            # Phase 12: start the tick emitter for this session.
            from haon_agent.tick_emitter import TickEmitter

            container_name = None
            handle = getattr(runtime, "_handle", None)
            if handle is not None:
                container_name = getattr(handle, "container_name", None)
            tick_emitter = TickEmitter(
                api=self._deps.api,
                session_id=session_id,
                broker=broker,
                container_name=container_name,
            )
            tick_emitter.start()

            # R2 pivot bring-up mode: browser peers P2P via R1 signaling
            # never hit the broker, so the broker's server-side
            # `idle_timeout_seconds` (120s) fires and closes the tunnel
            # with IDLE_TIMEOUT mid-session. Send a PING every 30s to
            # keep the tunnel alive. Cheap — one 1-byte frame.
            if is_remote_desktop:
                async def _broker_keepalive_loop() -> None:
                    # Broker's server-side `pre_pair_idle_timeout_seconds`
                    # is 10s — it fires BEFORE `idle_timeout_seconds` (120s)
                    # because remote_desktop sessions never reach PAIRED.
                    # So we need the first PING *immediately* (before 10s)
                    # and then every ~8s to stay under the pre-pair budget
                    # with headroom. Post-pair budget is 120s so 8s is
                    # still very cheap if the broker's pair flag ever flips.
                    try:
                        await asyncio.sleep(3)   # first ping well before pre-pair cutoff
                        while True:
                            try:
                                await broker.send_ping()
                            except Exception:  # noqa: BLE001
                                return  # broker gone — events loop surfaces close
                            await asyncio.sleep(8)
                    except asyncio.CancelledError:
                        return
                broker_keepalive = asyncio.create_task(_broker_keepalive_loop())

            async for ev in broker.events():
                if ev.type is FrameType.DATA:
                    if _forwarder is not None:
                        # HTTP-server runtime → dispatch through the
                        # multi-stream TCP forwarder (tunnel_frames).
                        await _forwarder.on_broker_data(ev.payload)
                    else:
                        # Legacy raw-pipe runtimes (echo, remote_desktop).
                        await runtime.push(ev.payload)
                elif ev.type is FrameType.UNPAIRED:
                    log.warning("session_unpaired", session_id=session_id)
                    # Worker dropped — Phase 10 treats it as session end.
                    # A reconnection-grace window can land later.
                    break
                elif ev.type is FrameType.CLOSE:
                    log.info(
                        "session_broker_closed",
                        session_id=session_id,
                        payload=ev.json(),
                    )
                    break
                elif ev.type is FrameType.ERROR:
                    log.error(
                        "session_broker_error",
                        session_id=session_id,
                        payload=ev.json(),
                    )
                    break
        except Exception as e:  # noqa: BLE001
            log.exception(
                "session_pipeline_error",
                session_id=session_id,
                error_type=type(e).__name__,
                error=str(e) or repr(e),
            )
            close_reason = "miner_closed"
            # Place this session under client-side cooldown so the next N
            # heartbeats don't re-spawn it. Horizon matches broker pairing
            # timeout (15s) × a few retries; the server sweeper will reap
            # the failed session well before this expires. Without this
            # brake a session that repeatedly fails (miner briefly offline,
            # bad runtime, etc.) floods the agent with pipeline_error.
            self._session_cooldown[session_id] = (
                asyncio.get_event_loop().time() + 120.0
            )
        finally:
            # Guard against paired_task orphan: if runtime.start raised
            # before we awaited paired_task, it's still running. Cancel
            # + drain so we don't leak the task past _run_session.
            if paired_task is not None and not paired_task.done():
                paired_task.cancel()
                try:
                    await paired_task
                except (asyncio.CancelledError, Exception):  # noqa: BLE001
                    pass
            # Same for the remote_desktop broker keepalive pinger.
            if broker_keepalive is not None and not broker_keepalive.done():
                broker_keepalive.cancel()
                try:
                    await broker_keepalive
                except (asyncio.CancelledError, Exception):  # noqa: BLE001
                    pass
            if tick_emitter is not None:
                try:
                    await tick_emitter.stop()
                except Exception:  # noqa: BLE001
                    pass
            # Phase 26A port-forward teardown — close any live streams
            # + cancel their pump tasks. Must happen BEFORE runtime.stop()
            # so the forwarder drops its socket handles before the
            # runtime's port goes away.
            if _forwarder is not None:
                try:
                    await _forwarder.stop()
                except Exception:  # noqa: BLE001
                    pass
            try:
                await runtime.stop()
            except Exception:  # noqa: BLE001
                pass
            await broker.close()
            await self._safe_close(session_id, reason=close_reason)
            self._active_sessions.pop(session_id, None)

    # ── HTTP-runtime session pipeline (Stage 4 — hybrid WebRTC/broker) ─

    async def _run_http_session(
        self,
        *,
        session_id: str,
        handoff: SessionHandoff,
        runtime: Runtime,
        runtime_name: str,
    ) -> None:
        """Port-forward pipeline for HTTP runtimes (ollama, comfyui, ...).

        Uses `build_transport()` which tries WebRTC P2P first and falls
        back to the broker relay on ICE failure. The `TunnelTransport`
        surface is all we need here — no pairing wait (transport is
        already paired when returned), no PING keepalive (WebRTC SCTP
        handles it, broker has its own), no event-type discrimination
        (`recv()` only yields envelope bytes and terminates cleanly
        on peer hangup).

        Parallel path to the legacy broker-only code path in
        `_run_session` above — we keep that code for echo and
        remote_desktop since those runtimes have broker-specific
        semantics (raw-pipe push / R1 signaling keepalive) that
        don't benefit from abstraction.
        """
        from haon_agent.transport import build_transport, TunnelTransport
        from haon_agent import port_forward as _pf
        from haon_agent.tick_emitter import TickEmitter

        rt_port = _pf.runtime_default_port(runtime_name)
        assert rt_port is not None, "caller must check HTTP runtime"

        # Env-var kill-switch lets the operator force broker-only (to
        # bisect WebRTC bugs) or webrtc-only (to verify P2P path).
        # Default auto = WebRTC with broker fallback.
        import os
        via_pref = os.environ.get("HAON_AGENT_TRANSPORT", "auto").lower()
        if via_pref not in ("auto", "webrtc", "broker"):
            log.warning(
                "agent_transport_env_invalid",
                value=via_pref,
                falling_back_to="auto",
            )
            via_pref = "auto"

        close_reason = "miner_closed"
        transport: TunnelTransport | None = None
        forwarder: _pf.TunnelPortForwarder | None = None
        tick_emitter: TickEmitter | None = None

        try:
            # Phase 27.1 — pass worker-supplied runtime_options to runtimes
            # that know how to consume them (hf_vllm reads model_id, future
            # custom_http reads image, etc). Optional duck-typed setter so
            # legacy runtimes (echo, ollama_native, comfyui) ignore.
            options = handoff.runtime_options or {}
            if options and hasattr(runtime, "set_options"):
                try:
                    runtime.set_options(options)  # type: ignore[attr-defined]
                except Exception as e:  # noqa: BLE001
                    log.warning(
                        "runtime_set_options_failed",
                        runtime=runtime_name,
                        error=str(e),
                    )

            # Runtime first — must be listening on rt_port before any
            # worker stream opens (otherwise connect() races the runtime
            # startup and we reply OPEN_RST to the first few streams).
            async def _noop_output(_data: bytes) -> None:
                # HTTP runtimes don't emit into the tunnel via this
                # callback — their output flows through TCP sockets
                # the forwarder opens on demand. The callback exists
                # only to satisfy Runtime.start() signature.
                return

            await runtime.start(_noop_output)

            # Phase 27.1 — runtimes that need cold-start (vLLM model
            # load, TGI weight download, ComfyUI VAE init) implement
            # `wait_ready()`. Block here so the tick emitter (billing
            # clock) only starts once the worker can ACTUALLY use the
            # runtime — miner eats the boot, aligned incentive (warm
            # cache = faster sessions = more revenue).
            if hasattr(runtime, "wait_ready"):
                try:
                    await runtime.wait_ready(port=rt_port)  # type: ignore[attr-defined]
                    log.info(
                        "runtime_wait_ready_ok",
                        session_id=session_id,
                        runtime=runtime_name,
                    )
                except Exception as e:  # noqa: BLE001
                    log.error(
                        "runtime_wait_ready_failed",
                        session_id=session_id,
                        runtime=runtime_name,
                        error=str(e),
                    )
                    raise  # propagates to outer try → cooldown + close

            transport = await build_transport(
                api_url=self._deps.config.api_url,
                session_id=session_id,
                tunnel_token=handoff.tunnel_token,
                broker_url=handoff.tunnel_broker_url,
                role="miner",
                prefer=via_pref,
            )
            log.info(
                "http_session_transport_ready",
                session_id=session_id,
                runtime=runtime_name,
                via=transport.via.value,
                pref=via_pref,
            )

            forwarder = _pf.TunnelPortForwarder(target_port=rt_port)
            await forwarder.start(transport.send)
            log.info(
                "http_session_port_forward_enabled",
                session_id=session_id,
                runtime=runtime_name,
                runtime_port=rt_port,
                via=transport.via.value,
            )

            # Tick emitter wants `bytes_sent` / `bytes_recv` on its
            # `broker` arg — both transports now expose those as
            # duck-typed properties so we can hand the transport
            # straight in.
            container_name = None
            handle = getattr(runtime, "_handle", None)
            if handle is not None:
                container_name = getattr(handle, "container_name", None)
            tick_emitter = TickEmitter(
                api=self._deps.api,
                session_id=session_id,
                broker=transport,  # type: ignore[arg-type]
                container_name=container_name,
            )
            tick_emitter.start()

            log.info(
                "http_session_paired_and_running",
                session_id=session_id,
                via=transport.via.value,
            )

            # Data-plane loop. `transport.recv()` yields only envelope
            # bytes (broker filter removes control frames; WebRTC
            # DataChannel only carries what we send). Loop terminates
            # when the transport closes (peer hangup, broker UNPAIRED,
            # WebRTC ICE failure, etc.) — at which point we unwind.
            async for payload in transport.recv():
                await forwarder.on_broker_data(payload)

            log.info("http_session_transport_closed", session_id=session_id)
        except Exception as e:  # noqa: BLE001
            log.exception(
                "http_session_pipeline_error",
                session_id=session_id,
                error_type=type(e).__name__,
                error=str(e) or repr(e),
            )
            # Same cooldown as the legacy path — protect against
            # re-offer hot loops when the server-side row is still
            # marked 'starting'.
            self._session_cooldown[session_id] = (
                asyncio.get_event_loop().time() + 120.0
            )
        finally:
            if tick_emitter is not None:
                try:
                    await tick_emitter.stop()
                except Exception:  # noqa: BLE001
                    pass
            if forwarder is not None:
                try:
                    await forwarder.stop()
                except Exception:  # noqa: BLE001
                    pass
            try:
                await runtime.stop()
            except Exception:  # noqa: BLE001
                pass
            if transport is not None:
                try:
                    await transport.close()
                except Exception:  # noqa: BLE001
                    pass
            await self._safe_close(session_id, reason=close_reason)
            self._active_sessions.pop(session_id, None)

    async def _safe_close(self, session_id: str, *, reason: str) -> None:
        try:
            await self._deps.api.close_session(session_id, reason=reason)
        except ApiError as e:
            log.warning(
                "session_close_failed", session_id=session_id, code=e.code
            )
        except Exception as e:  # noqa: BLE001
            log.warning(
                "session_close_unhandled", session_id=session_id, error=str(e)
            )
