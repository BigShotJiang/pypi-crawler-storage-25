"""Host hardware detection.

Intentionally conservative: if a probe fails, return neutral defaults rather
than crashing. The backend re-validates the claims against runtime metrics,
so lying here gains nothing.

Fake-hardware mode:
  Set HAON_FAKE_HARDWARE=1 (or pass --fake-hardware to the CLI) to bypass
  all probes and report a synthetic RTX 4090 rig. Intended for:
    - Phase 24 E2E testing on hosts without a real GPU
    - Developer dry-runs in Docker containers / CI
    - Staging smoke tests
  NEVER set this in production — the backend audit trail will flag a
  fingerprint that doesn't match runtime metrics, and Phase 20 alerts
  will fire.
"""

from __future__ import annotations

import hashlib
import os
import platform
import re
import shutil
import subprocess
import sys
import uuid
from dataclasses import dataclass, field

try:
    import psutil
    _HAS_PSUTIL = True
except ImportError:  # pragma: no cover
    _HAS_PSUTIL = False

try:
    import httpx
    _HAS_HTTPX = True
except ImportError:  # pragma: no cover
    _HAS_HTTPX = False


@dataclass
class OllamaNativeReport:
    """Result of probing a locally-installed Ollama server.

    Populated by :func:`_detect_ollama_native`. When ``running`` is False,
    ``models`` is always an empty list and ``port`` is the fixed default
    (11434) — the field exists so downstream code can display "Ollama not
    detected on port 11434" without special-casing None.
    """

    running: bool = False
    models: list[str] = field(default_factory=list)
    port: int = 11434


@dataclass
class HardwareReport:
    cpu_model: str
    cpu_cores: int
    ram_gb: int
    gpu_model: str | None = None
    gpu_vram_gb: int | None = None
    gpu_count: int = 0
    # Nameplate TDP (power.max_limit) of the primary GPU in whole watts, as
    # reported by `nvidia-smi`. Used by the dashboard to bound live power
    # readings and to estimate worst-case electricity cost per hour before a
    # session starts. `None` when no NVIDIA GPU is present or the probe fails.
    # TODO: add AMD ROCm (rocm-smi) + Apple Silicon (powermetrics) support.
    tdp_watts: int | None = None
    # Native (non-Docker) Ollama probe. Optional so older callers that
    # build a HardwareReport without this field still work; the detector
    # populates it when available. ``None`` means "not probed" (e.g.
    # HAON_FAKE_HARDWARE mode) — distinct from a populated report with
    # ``running=False`` which means "probed and nothing there".
    ollama_native: OllamaNativeReport | None = None
    os: str = field(default_factory=lambda: platform.platform())
    python: str = field(default_factory=lambda: sys.version.split()[0])

    def fingerprint(self) -> str:
        """Stable SHA-256 hex over the key identifying fields.

        Intentional: changing GPU count or RAM re-fingerprints. The MAC address
        is not included (Phase 6 `UNIQUE(miner_id, hardware_fingerprint)` scopes
        uniqueness to the miner already, and a MAC would leak network identity).
        """
        parts = [
            self.cpu_model,
            str(self.cpu_cores),
            str(self.ram_gb),
            self.gpu_model or "cpu-only",
            str(self.gpu_vram_gb or 0),
            str(self.gpu_count),
        ]
        return hashlib.sha256("|".join(parts).encode("utf-8")).hexdigest()


# ── CPU / RAM ────────────────────────────────────────────────────────────


def _cpu_model() -> str:
    """Best-effort CPU model string. Never raises."""
    try:
        # /proc/cpuinfo on Linux.
        with open("/proc/cpuinfo", encoding="utf-8") as f:
            for line in f:
                if line.startswith("model name"):
                    _, _, rest = line.partition(":")
                    return rest.strip()
    except (FileNotFoundError, PermissionError):
        pass
    # macOS.
    try:
        out = subprocess.check_output(
            ["sysctl", "-n", "machdep.cpu.brand_string"], text=True, timeout=2
        )
        return out.strip()
    except (FileNotFoundError, subprocess.SubprocessError, subprocess.TimeoutExpired):
        pass
    # Windows / fallback.
    return platform.processor() or platform.machine() or "Unknown CPU"


def _cpu_cores() -> int:
    if _HAS_PSUTIL:
        try:
            return psutil.cpu_count(logical=True) or 1
        except Exception:  # noqa: BLE001
            pass
    import os as _os

    return _os.cpu_count() or 1


def _ram_gb() -> int:
    if _HAS_PSUTIL:
        try:
            total = psutil.virtual_memory().total
            return max(1, round(total / (1024**3)))
        except Exception:  # noqa: BLE001
            pass
    # Fallback for tests: assume 1 GB to be safe.
    return 1


# ── GPU ──────────────────────────────────────────────────────────────────


_NVSMI_QUERY = "--query-gpu=name,memory.total,uuid,power.max_limit"
_NVSMI_FORMAT = "--format=csv,noheader,nounits"


def _detect_nvidia() -> tuple[str | None, int | None, int, int | None]:
    """Return (model, vram_gb, count, tdp_watts).

    Returns (None, None, 0, None) when no NVIDIA GPU is present or the probe
    fails. TDP is the nameplate `power.max_limit` of the primary GPU in whole
    watts; `None` when that field is absent (older drivers) or unparseable.
    """
    nvsmi = shutil.which("nvidia-smi")
    if nvsmi is None:
        return None, None, 0, None
    try:
        out = subprocess.check_output(
            [nvsmi, _NVSMI_QUERY, _NVSMI_FORMAT],
            text=True,
            timeout=5,
            stderr=subprocess.DEVNULL,
        )
    except (subprocess.SubprocessError, subprocess.TimeoutExpired, FileNotFoundError):
        return None, None, 0, None

    lines = [ln.strip() for ln in out.splitlines() if ln.strip()]
    if not lines:
        return None, None, 0, None

    model: str | None = None
    vram_mib_total = 0
    count = 0
    tdp_watts: int | None = None
    for line in lines:
        fields = [f.strip() for f in line.split(",")]
        if len(fields) < 2:
            continue
        name = fields[0]
        mem_raw = re.sub(r"[^0-9]", "", fields[1]) or "0"
        mem_mib = int(mem_raw)
        count += 1
        vram_mib_total = max(vram_mib_total, mem_mib)
        if model is None:
            model = name
        # power.max_limit is the 4th field when present. Some older drivers
        # report "[Not Supported]" or omit the column entirely — treat either
        # as "unknown" and keep going.
        if tdp_watts is None and len(fields) >= 4:
            try:
                tdp_watts = max(0, round(float(fields[3])))
            except ValueError:
                tdp_watts = None
    vram_gb = round(vram_mib_total / 1024) if vram_mib_total > 0 else None
    return model, vram_gb, count, tdp_watts


# ── Native Ollama probe ──────────────────────────────────────────────────

# Ollama's default port. Intentionally not configurable — a non-default
# deployment is a Phase 26 concern (see runtime/ollama_native.py).
_OLLAMA_NATIVE_PORT = 11434
_OLLAMA_NATIVE_URL = f"http://127.0.0.1:{_OLLAMA_NATIVE_PORT}/api/tags"
_OLLAMA_NATIVE_TIMEOUT_SECONDS = 2.0


def _detect_ollama_native() -> OllamaNativeReport:
    """Probe http://127.0.0.1:11434/api/tags for a native Ollama server.

    Blanket-catches any failure (httpx unavailable, connection refused,
    timeout, non-200, bad JSON) and returns ``running=False``. Never raises.
    """
    if not _HAS_HTTPX:  # pragma: no cover — httpx is a hard dep
        return OllamaNativeReport(running=False, models=[], port=_OLLAMA_NATIVE_PORT)
    try:
        resp = httpx.get(_OLLAMA_NATIVE_URL, timeout=_OLLAMA_NATIVE_TIMEOUT_SECONDS)
        if resp.status_code != 200:
            return OllamaNativeReport(
                running=False, models=[], port=_OLLAMA_NATIVE_PORT
            )
        payload = resp.json()
        raw_models = payload.get("models", []) or []
        # /api/tags returns entries shaped like {"name": "llama3:latest", ...}.
        # Degrade to str() for forward-compat if the schema shifts.
        models = [
            m.get("name", "") if isinstance(m, dict) else str(m)
            for m in raw_models
        ]
        models = [m for m in models if m]
        return OllamaNativeReport(
            running=True, models=models, port=_OLLAMA_NATIVE_PORT
        )
    except Exception:  # noqa: BLE001 — probe must never raise
        return OllamaNativeReport(
            running=False, models=[], port=_OLLAMA_NATIVE_PORT
        )


def suggested_supported_runtimes(report: HardwareReport) -> list[str]:
    """Runtimes the pair wizard could auto-advertise for this rig.

    Purely advisory — the config's explicit ``supported_runtimes`` list is
    still the source of truth for what the agent will actually accept. The
    pair wizard is expected to echo this suggestion to the user when it
    doesn't find a configured value.

    Current rules:
      - Docker-based ``ollama`` / ``comfyui`` whenever an NVIDIA GPU is
        visible (nvidia-smi-gated — the Docker runtime still requires
        the NVIDIA Container Toolkit, which we can't probe cleanly from
        here yet; Phase 26).
      - ``ollama_native`` when a local Ollama server is running AND an
        NVIDIA GPU is visible. The GPU check keeps us from advertising
        pure-CPU inference boxes, which the broker treats as a different
        market.
    """
    suggestions: list[str] = []
    has_gpu = report.gpu_count > 0
    if has_gpu:
        suggestions.extend(["ollama", "comfyui"])
    if (
        has_gpu
        and report.ollama_native is not None
        and report.ollama_native.running
    ):
        suggestions.append("ollama_native")
    # R2 pivot bring-up mode: remote_desktop is always offered. The
    # browser /m/{session_id} tab provides the actual WebRTC peer, so the
    # agent has no host capability requirement to advertise. When the
    # real streamer (Track A: Selkies / Track B: Go+Pion) lands, gate
    # this on a hardware encode probe (NVENC / VAAPI / VideoToolbox).
    suggestions.append("remote_desktop")
    return suggestions


_FAKE_HARDWARE_ENV = "HAON_FAKE_HARDWARE"


def _fake_report() -> HardwareReport:
    """Synthetic rig for dev/test. NOT for production."""
    return HardwareReport(
        cpu_model="FAKE CPU — HAON_FAKE_HARDWARE=1",
        cpu_cores=8,
        ram_gb=32,
        gpu_model="FAKE NVIDIA RTX 4090 (simulated)",
        gpu_vram_gb=24,
        gpu_count=1,
        # RTX 4090 reference-board TDP is 450 W. Baked in so the synthetic
        # report round-trips through downstream code that assumes `tdp_watts`
        # is populated whenever `gpu_count > 0`.
        tdp_watts=450,
    )


def detect(
    *,
    nvsmi_detector=_detect_nvidia,
    ollama_native_detector=None,
) -> HardwareReport:
    """Build a HardwareReport. Detectors swappable for tests.

    If HAON_FAKE_HARDWARE is set to a truthy value (`1`, `true`, `yes`),
    returns a synthetic report instead of probing the host. Used for Phase 24
    E2E tests on laptops without a real GPU. Fake mode also skips the
    native-Ollama probe — we don't want `haon-agent hardware` to make a
    network call when the caller has explicitly asked for offline mode.

    ``ollama_native_detector`` resolves to the module-level
    :func:`_detect_ollama_native` at call time (not at function-definition
    time) so the test conftest can monkeypatch the probe away.
    """
    if os.environ.get(_FAKE_HARDWARE_ENV, "").strip().lower() in ("1", "true", "yes", "y"):
        return _fake_report()
    if ollama_native_detector is None:
        ollama_native_detector = _detect_ollama_native
    result = nvsmi_detector()
    # Back-compat: tests (and any callers still on the 3-tuple shape) can pass
    # detectors that omit the TDP field — default it to None in that case.
    if len(result) == 4:
        gpu_model, gpu_vram_gb, gpu_count, tdp_watts = result
    else:
        gpu_model, gpu_vram_gb, gpu_count = result
        tdp_watts = None
    try:
        ollama_native = ollama_native_detector()
    except Exception:  # noqa: BLE001 — probe must never break detect()
        ollama_native = OllamaNativeReport(
            running=False, models=[], port=_OLLAMA_NATIVE_PORT
        )
    return HardwareReport(
        cpu_model=_cpu_model(),
        cpu_cores=_cpu_cores(),
        ram_gb=_ram_gb(),
        gpu_model=gpu_model,
        gpu_vram_gb=gpu_vram_gb,
        gpu_count=gpu_count,
        tdp_watts=tdp_watts,
        ollama_native=ollama_native,
    )
