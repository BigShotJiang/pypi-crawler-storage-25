"""Micro-protocol for multiplexed TCP-over-broker-DATA port forwarding.

This sits ON TOP of the broker's existing DATA frames. The broker treats
each frame as opaque bytes; we use the first byte as an opcode + next 4
bytes as a stream identifier + rest as payload. Multiple simultaneous
TCP connections between worker and miner are multiplexed on a single
broker socket using `stream_id`.

Not HTTP-aware. Not protocol-aware. Just a TCP pipe — exactly like SSH
`-L` port forwarding. This means ANY HTTP client on the worker side
(LM Studio, Jan, curl, LangChain, whatever) works against the miner's
runtime (Ollama, ComfyUI, vLLM, whatever) with zero modification to
either end.

## Wire format

```
 ┌─────────┬─────────────────────┬────────────────────────────────┐
 │ opcode  │   stream_id (uint32)│          payload bytes          │
 │ (1 byte)│     big-endian      │           (variable)            │
 └─────────┴─────────────────────┴────────────────────────────────┘
```

| Opcode | Name       | Payload                 | Who sends | Meaning |
|--------|------------|-------------------------|-----------|---------|
| 0x01   | OPEN       | target_port (uint16 BE) | worker    | "open TCP to 127.0.0.1:port on your side" |
| 0x02   | DATA       | arbitrary bytes         | both      | "write these bytes to the stream" |
| 0x03   | CLOSE      | —                       | both      | "close the stream cleanly" |
| 0x04   | HALF_CLOSE | —                       | both      | "I'm done sending; you can still send" |
| 0x05   | ERROR      | utf-8 message           | both      | "something went wrong; stream is gone" |
| 0x06   | OPEN_OK    | —                       | miner     | "OPEN succeeded; stream is live" |
| 0x07   | OPEN_RST   | utf-8 message           | miner     | "couldn't open (refused/timeout/etc)" |

stream_id 0 is reserved — never assigned to a real stream — so peers
can use it for future control-plane messages without colliding.

## Sizing

The broker's MAX_FRAME_BYTES is 1 MB. Our header is 5 bytes. So a single
DATA frame carries up to 1 MB − 5 = 1_048_571 bytes of payload. Senders
SHOULD chunk larger bodies into multiple DATA frames under the same
stream_id; receivers concat in order (the broker preserves WebSocket
message order per-peer).

## Fault model

* Broker drop (worker OR miner reconnects): ALL live streams die. The
  peer gets CLOSE events from its local socket side; upstream retry is
  the client's job (HTTP apps retry naturally, LM Studio will reconnect).
* Miner refuses to open (service down, wrong port): OPEN_RST, stream
  never becomes active.
* Peer sends bytes on an unknown stream_id: silently dropped. Prevents
  replay attacks from re-animating dead streams.
"""

from __future__ import annotations

import struct
from dataclasses import dataclass
from enum import IntEnum


class Opcode(IntEnum):
    OPEN = 0x01
    DATA = 0x02
    CLOSE = 0x03
    HALF_CLOSE = 0x04
    ERROR = 0x05
    OPEN_OK = 0x06
    OPEN_RST = 0x07


# Header: 1 byte opcode + 4 bytes big-endian stream_id.
_HEADER_FMT = ">BI"
HEADER_SIZE = struct.calcsize(_HEADER_FMT)  # == 5


@dataclass(frozen=True)
class Frame:
    """Parsed view of a tunnel frame. Immutable on purpose — these are
    messages, not buffers to mutate."""

    opcode: Opcode
    stream_id: int
    payload: bytes

    def encode(self) -> bytes:
        return struct.pack(_HEADER_FMT, int(self.opcode), self.stream_id) + self.payload


def decode(raw: bytes) -> Frame:
    """Parse a tunnel frame out of a broker DATA payload.

    Raises ValueError on malformed input (unknown opcode, truncated
    header). Caller should drop the frame + log; don't crash the
    session on a single bad frame.
    """
    if len(raw) < HEADER_SIZE:
        raise ValueError(f"tunnel frame too short: {len(raw)} bytes")
    op_byte, stream_id = struct.unpack(_HEADER_FMT, raw[:HEADER_SIZE])
    try:
        opcode = Opcode(op_byte)
    except ValueError as e:
        raise ValueError(f"unknown tunnel opcode: 0x{op_byte:02x}") from e
    return Frame(opcode=opcode, stream_id=stream_id, payload=raw[HEADER_SIZE:])


# ── Convenience constructors — let callers write intent, not bytes ──────


def build_open(stream_id: int, target_port: int) -> bytes:
    """Worker → miner: 'open a TCP connection to 127.0.0.1:port on your side
    and reply OPEN_OK (or OPEN_RST) with the same stream_id.'"""
    if not 0 < target_port < 65536:
        raise ValueError(f"target_port out of range: {target_port}")
    payload = struct.pack(">H", target_port)
    return Frame(Opcode.OPEN, stream_id, payload).encode()


def build_data(stream_id: int, payload: bytes) -> bytes:
    """Bidirectional: 'write these bytes to the stream's socket.'"""
    return Frame(Opcode.DATA, stream_id, payload).encode()


def build_close(stream_id: int) -> bytes:
    """Bidirectional: 'I'm done, tear down the stream.'"""
    return Frame(Opcode.CLOSE, stream_id, b"").encode()


def build_half_close(stream_id: int) -> bytes:
    """Bidirectional: 'I won't send more data; you can still send to me.'
    Mirrors TCP FIN — useful for HTTP/1.1 upload semantics."""
    return Frame(Opcode.HALF_CLOSE, stream_id, b"").encode()


def build_error(stream_id: int, msg: str) -> bytes:
    """Bidirectional: 'stream is dead, here's why (human-readable).'"""
    return Frame(Opcode.ERROR, stream_id, msg.encode("utf-8", errors="replace")).encode()


def build_open_ok(stream_id: int) -> bytes:
    """Miner → worker: 'OPEN succeeded; you can start sending DATA.'"""
    return Frame(Opcode.OPEN_OK, stream_id, b"").encode()


def build_open_rst(stream_id: int, msg: str) -> bytes:
    """Miner → worker: 'OPEN failed (port closed, conn refused, etc).'"""
    return Frame(
        Opcode.OPEN_RST, stream_id, msg.encode("utf-8", errors="replace")
    ).encode()


# ── OPEN payload helper ─────────────────────────────────────────────────


def parse_open_payload(payload: bytes) -> int:
    """Pull the target_port out of an OPEN frame's payload."""
    if len(payload) != 2:
        raise ValueError(f"OPEN payload must be 2 bytes; got {len(payload)}")
    return struct.unpack(">H", payload)[0]


# The broker caps each DATA frame at 1 MB; subtract our header.
# Callers doing large body uploads MUST chunk up front.
try:
    from haon_agent.broker_client import MAX_FRAME_BYTES as _BROKER_MAX
except ImportError:
    _BROKER_MAX = 1 * 1024 * 1024  # default if imported outside package
MAX_PAYLOAD_BYTES = _BROKER_MAX - HEADER_SIZE
