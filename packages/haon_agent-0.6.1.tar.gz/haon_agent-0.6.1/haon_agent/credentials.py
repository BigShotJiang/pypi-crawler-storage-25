"""API-key storage.

Primary: OS keychain via `keyring`. Fallback: `~/.haon/credentials.toml` with
mode 0600 (for systems where Secret Service is not installed — common in
headless Linux servers).

The raw key is held in memory only inside the running agent process; the
CLI stores and reads from keychain/file, never echoed.
"""

from __future__ import annotations

import os
import tomllib
from pathlib import Path

try:
    import keyring
    import keyring.errors as keyring_errors

    _HAS_KEYRING = True
except ImportError:  # pragma: no cover
    _HAS_KEYRING = False

from haon_agent.config import (
    DEFAULT_CONFIG_DIR,
    _atomic_write_text,
    ensure_config_dir,
)

SERVICE = "haon-agent"
USERNAME = "api_key"


def _fallback_path() -> Path:
    return DEFAULT_CONFIG_DIR / "credentials.toml"


def _keyring_available() -> bool:
    """Probe the keyring backend. Some installs have `keyring` but no backend."""
    if not _HAS_KEYRING:
        return False
    try:
        backend = keyring.get_keyring()
        # keyring.backends.fail.Keyring is the "no backend" sentinel.
        return "fail" not in backend.__class__.__module__
    except Exception:  # noqa: BLE001
        return False


def store(raw_key: str) -> None:
    if not raw_key.startswith("haon_"):
        raise ValueError("not a HAON API key")
    if _keyring_available():
        try:
            keyring.set_password(SERVICE, USERNAME, raw_key)
            return
        except keyring_errors.KeyringError:
            pass  # fall through to file
    ensure_config_dir(DEFAULT_CONFIG_DIR)
    path = _fallback_path()
    # Atomic: write sibling tempfile, fsync, os.replace. A crash mid-write
    # cannot corrupt an existing credentials file.
    _atomic_write_text(
        path,
        f'[credentials]\napi_key = "{raw_key}"\n',
        mode=0o600,
    )


def load() -> str | None:
    if _keyring_available():
        try:
            v = keyring.get_password(SERVICE, USERNAME)
            if v:
                return v
        except keyring_errors.KeyringError:
            pass
    path = _fallback_path()
    if not path.exists():
        return None
    # Refuse to read overly-permissive files on POSIX.
    try:
        st = path.stat()
        if os.name == "posix" and (st.st_mode & 0o077):
            raise PermissionError(
                f"{path} has permissive mode {oct(st.st_mode)}; refuse to load. "
                f"Run: chmod 600 {path}"
            )
    except FileNotFoundError:
        return None
    raw = tomllib.loads(path.read_text(encoding="utf-8"))
    return raw.get("credentials", {}).get("api_key")


def clear() -> None:
    if _keyring_available():
        try:
            keyring.delete_password(SERVICE, USERNAME)
        except keyring_errors.PasswordDeleteError:
            pass
        except keyring_errors.KeyringError:
            pass
    path = _fallback_path()
    if path.exists():
        path.unlink()
