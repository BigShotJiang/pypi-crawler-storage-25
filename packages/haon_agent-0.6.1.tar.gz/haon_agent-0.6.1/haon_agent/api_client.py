"""Thin HAON API client used by the agent.

One class, one responsibility per method. In tests we swap `httpx`'s transport
for an `ASGITransport` pointed at an in-process FastAPI app — no network, no
mocks.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import httpx


class ApiError(Exception):
    def __init__(self, status_code: int, code: str, message: str, details: dict | None = None) -> None:
        super().__init__(f"{code}: {message}")
        self.status_code = status_code
        self.code = code
        self.message = message
        self.details = details or {}


def _raise_for_error(r: httpx.Response) -> None:
    if r.is_success:
        return
    try:
        body = r.json()
        err = body.get("error", {})
        code = err.get("code", "UNKNOWN")
        message = err.get("message", r.text)
        details = err.get("details", {})
    except Exception:  # noqa: BLE001
        code = "HTTP_ERROR"
        message = r.text
        details = {}
    raise ApiError(r.status_code, code, message, details)


@dataclass
class SessionHandoff:
    """What the agent needs to actually run a session."""
    session_id: str
    worker_id: str
    machine_id: str
    runtime: str
    tunnel_broker_url: str
    tunnel_token: str
    expires_at: str
    # Phase 27.1 — runtime-specific knobs the worker chose at session-
    # open. Schema is per-runtime; the agent passes through to the
    # runtime constructor without inspecting the keys (runtime decides
    # which it understands and ignores the rest).
    runtime_options: dict | None = None


class ApiClient:
    """Token-auth HTTP client for the HAON API."""

    def __init__(
        self,
        base_url: str,
        api_key: str,
        *,
        transport: httpx.AsyncBaseTransport | None = None,
        timeout: float = 10.0,
    ) -> None:
        self._client = httpx.AsyncClient(
            base_url=base_url.rstrip("/"),
            transport=transport,
            timeout=timeout,
            headers={"X-API-Key": api_key, "User-Agent": "haon-agent/0.2"},
        )

    async def aclose(self) -> None:
        await self._client.aclose()

    async def __aenter__(self) -> "ApiClient":
        return self

    async def __aexit__(self, *_exc: Any) -> None:
        await self._client.aclose()

    # ── Machines ────────────────────────────────────────────────────────

    async def register_machine(
        self,
        *,
        hub_id: str,
        name: str,
        cpu_model: str,
        cpu_cores: int,
        ram_gb: int,
        gpu_model: str | None,
        gpu_vram_gb: int | None,
        gpu_count: int,
        supported_runtimes: list[str],
        hardware_fingerprint: str,
        hardware_signature: str | None = None,
    ) -> dict:
        payload = {
            "hub_id": hub_id,
            "name": name,
            "cpu_model": cpu_model,
            "cpu_cores": cpu_cores,
            "ram_gb": ram_gb,
            "gpu_count": gpu_count,
            "supported_runtimes": supported_runtimes,
            "hardware_fingerprint": hardware_fingerprint,
        }
        if gpu_model is not None:
            payload["gpu_model"] = gpu_model
        if gpu_vram_gb is not None:
            payload["gpu_vram_gb"] = gpu_vram_gb
        if hardware_signature is not None:
            payload["hardware_signature"] = hardware_signature

        # Agent needs a user JWT (not API key) to register a machine. In Phase 10
        # registration happens via `haon-agent register` which prompts for
        # email+password → JWT → register. The runtime agent uses API keys.
        # For now the method exists as a convenience; the CLI uses the login flow.
        r = await self._client.post("/v1/machines", json=payload)
        _raise_for_error(r)
        return r.json()

    async def update_machine_runtimes(
        self,
        machine_id: str,
        supported_runtimes: list[str],
    ) -> dict:
        """PATCH /v1/machines/{id}/runtimes — agent-scoped reconcile of
        the server's supported_runtimes with the operator's agent.toml.

        Regular PATCH /v1/machines/{id} requires a JWT with role=miner,
        which the agent doesn't hold (it only has an X-API-Key scoped
        to miner:agent). This narrower endpoint accepts the agent key
        and touches only supported_runtimes — name edits still require
        the full PATCH through a human-auth flow.
        """
        r = await self._client.patch(
            f"/v1/machines/{machine_id}/runtimes",
            json={"supported_runtimes": supported_runtimes},
        )
        _raise_for_error(r)
        return r.json()

    async def heartbeat(
        self,
        machine_id: str,
        *,
        runtime_ready: bool,
        cpu_percent: float | None = None,
        ram_used_mb: int | None = None,
        gpu_utilization_percent: list[float] | None = None,
        pending_sessions: int | None = None,
        runtime_capabilities: dict | None = None,
    ) -> dict:
        payload: dict = {"runtime_ready": runtime_ready}
        if cpu_percent is not None:
            payload["cpu_percent"] = cpu_percent
        if ram_used_mb is not None:
            payload["ram_used_mb"] = ram_used_mb
        if gpu_utilization_percent is not None:
            payload["gpu_utilization_percent"] = gpu_utilization_percent
        if pending_sessions is not None:
            payload["pending_sessions"] = pending_sessions
        # P1 — only send when the agent has fresh detection results that
        # haven't been pushed yet (caller manages this gate). Sending
        # `None` (the default) preserves cached server-side caps; sending
        # `{}` explicitly clears them (CPU-only or GPU probe failure).
        if runtime_capabilities is not None:
            payload["runtime_capabilities"] = runtime_capabilities
        r = await self._client.post(
            f"/v1/machines/{machine_id}/heartbeat", json=payload
        )
        _raise_for_error(r)
        return r.json()

    # ── Sessions ────────────────────────────────────────────────────────

    async def start_session(self, session_id: str) -> SessionHandoff:
        r = await self._client.post(f"/v1/sessions/{session_id}/start")
        _raise_for_error(r)
        body = r.json()
        sess = body["session"]
        return SessionHandoff(
            session_id=sess["id"],
            worker_id=sess["worker_id"],
            machine_id=sess["machine_id"],
            runtime=sess.get("runtime") or "",
            tunnel_broker_url=body["tunnel"]["broker_url"],
            tunnel_token=body["tunnel"]["token"],
            expires_at=body["tunnel"]["expires_at"],
            runtime_options=sess.get("runtime_options"),
        )

    # ── Offers ──────────────────────────────────────────────────────────

    async def list_my_offers(self, machine_id: str) -> list[dict]:
        """GET /v1/machines/{machine_id}/offers → list of offer dicts.

        Returns the raw JSON list the API emits. Any non-2xx response
        becomes an `ApiError` via `_raise_for_error`; callers that want
        to treat "missing" as "empty" must catch it explicitly.
        """
        r = await self._client.get(f"/v1/machines/{machine_id}/offers")
        _raise_for_error(r)
        body = r.json()
        # Accept either a bare list or a `{items: [...]}` envelope; the
        # agent only cares about presence/absence.
        if isinstance(body, list):
            return body
        if isinstance(body, dict) and isinstance(body.get("items"), list):
            return body["items"]
        return []

    async def create_offer(
        self,
        machine_id: str,
        *,
        price_per_hour: str,
        min_session_minutes: int,
        max_session_hours: int = 8,
    ) -> dict:
        """POST /v1/machines/{machine_id}/offers → the created offer."""
        payload = {
            "price_per_hour": price_per_hour,
            "min_session_minutes": min_session_minutes,
            "max_session_hours": max_session_hours,
        }
        r = await self._client.post(
            f"/v1/machines/{machine_id}/offers", json=payload
        )
        _raise_for_error(r)
        return r.json()

    async def close_session(self, session_id: str, reason: str = "miner_closed") -> dict:
        r = await self._client.post(
            f"/v1/sessions/{session_id}/close", json={"reason": reason}
        )
        _raise_for_error(r)
        return r.json()

    async def get_session(self, session_id: str) -> dict:
        r = await self._client.get(f"/v1/sessions/{session_id}")
        _raise_for_error(r)
        return r.json()

    # ── Usage ticks ─────────────────────────────────────────────────────

    async def post_ticks(self, ticks: list[dict]) -> dict:
        """Submit a batch (1..10) of UsageTick records."""
        r = await self._client.post("/v1/usage/ticks", json={"ticks": ticks})
        _raise_for_error(r)
        return r.json()

    # ── Hub Gateway (Phase 4.6) ─────────────────────────────────────────

    async def list_pending_hub_sessions(
        self, *, machine_id: str | None = None
    ) -> list[dict]:
        """GET /v1/my-hub/sessions/pending → list of pending hub
        sessions awaiting agent claim.

        Each row: ``{session_id, endpoint_id, machine_id, runtime, port,
        tunnel_token, broker_url, expires_at, started_at}``. The agent
        polls this every few seconds; for each row the agent dials the
        broker with ``tunnel_token`` and bridges WS↔TCP to
        ``localhost:{port}``.

        Returns ``[]`` on 404 (router unreachable on older API builds —
        agent should keep marketplace work flowing).
        """
        params = {"machine_id": machine_id} if machine_id else None
        try:
            r = await self._client.get(
                "/v1/my-hub/sessions/pending", params=params
            )
        except Exception:
            return []
        if r.status_code == 404:
            # Older API build, no hub support; treat as no pending work.
            return []
        _raise_for_error(r)
        body = r.json()
        return body.get("sessions", []) if isinstance(body, dict) else []

    async def start_hub_session(self, session_id: str) -> dict:
        """GET /v1/my-hub/sessions/{id}/start → confirms agent claim.

        Best-effort: the broker pair-up is the actual lock. We call
        this to advance ``status='starting' → 'active'`` on the API
        side so the audit trail and any operator dashboards are
        accurate. Failure to confirm doesn't block the tunnel.
        """
        r = await self._client.get(
            f"/v1/my-hub/sessions/{session_id}/start"
        )
        _raise_for_error(r)
        return r.json()

    async def close_hub_session(
        self, session_id: str, *, reason: str = "agent_closed"
    ) -> dict:
        """POST /v1/my-hub/sessions/{id}/close (idempotent)."""
        r = await self._client.post(
            f"/v1/my-hub/sessions/{session_id}/close",
            json={"reason": reason},
        )
        _raise_for_error(r)
        return r.json()
