"""Minimal UPnP IGD (Internet Gateway Device) client (R2.3).

Pure-Python, no external deps. Does just enough to:
  1. Discover the local UPnP IGD via SSDP M-SEARCH
  2. Fetch its device description XML
  3. Find the WANIPConnection / WANPPPConnection service
  4. SOAP AddPortMapping for each port we care about
  5. SOAP DeletePortMapping on session close

Why not `miniupnpc` or `upnpy`?
- miniupnpc: C extension → cross-compile pain for the PyInstaller bundle
- upnpy: unmaintained, last release 2021, has bugs on Python 3.12+
- Pure-Python version fits in ~300 LOC + we fully control behavior

## Scope of this implementation

- IPv4 only (IPv6 IGD is rare in home routers)
- Only AddPortMapping / DeletePortMapping (no GetExternalIPAddress —
  we use the HTTPS-echo helper in public_ip.py for that)
- No port renumbering — if a mapping exists for the same external
  port pointing at a different internal IP, we overwrite it
- Lease time defaults to 2h; renewal is the agent's job if needed

## Security note

UPnP is not authenticated. Any device on the LAN can add mappings.
We rely on the worker's trust of the miner (via HAON's signed
receipts) — UPnP is only here to reduce user-side config friction,
not as a security layer.
"""

from __future__ import annotations

import asyncio
import logging
import re
import socket
import struct
from dataclasses import dataclass
from urllib.parse import urlparse
from xml.etree import ElementTree as ET

import httpx


log = logging.getLogger("agent.net.upnp")


SSDP_MULTICAST_GROUP = "239.255.255.250"
SSDP_PORT = 1900
# We look for the router-side IGD specifically. The v1/v2 search targets
# catch most consumer routers from the last 15 years.
SSDP_SEARCH_TARGETS = [
    "urn:schemas-upnp-org:device:InternetGatewayDevice:1",
    "urn:schemas-upnp-org:device:InternetGatewayDevice:2",
]


# XML namespaces used by the UPnP spec. Every service description uses
# these exact strings; parsers must NOT substitute equivalents.
NS_DEVICE = "urn:schemas-upnp-org:device-1-0"
NS_WAN_IP = "urn:schemas-upnp-org:service:WANIPConnection:1"
NS_WAN_PPP = "urn:schemas-upnp-org:service:WANPPPConnection:1"


@dataclass(frozen=True)
class Gateway:
    """One discovered IGD with the control URL we need for AddPortMapping."""
    location: str          # http://192.168.1.1:49152/igd.xml
    control_url: str       # absolute URL for SOAP calls
    service_type: str      # WANIPConnection:1 or WANPPPConnection:1
    device_friendly_name: str


@dataclass(frozen=True)
class PortMapping:
    internal_port: int
    external_port: int
    protocol: str          # "TCP" or "UDP"
    description: str       # shows up in the router admin page


@dataclass
class UpnpResult:
    gateway: Gateway | None
    mapped: list[PortMapping]
    failed: list[tuple[PortMapping, str]]  # (mapping, error)


# ── SSDP discovery ──────────────────────────────────────────────────────────


async def discover(*, timeout_s: float = 3.0) -> Gateway | None:
    """Send SSDP M-SEARCH and return the first IGD that answers.

    Runs in a thread so it doesn't block the asyncio loop (stdlib's
    socket module is sync). Returns None on timeout — caller treats
    that as "no UPnP, advise manual port forwarding".
    """
    return await asyncio.to_thread(_discover_sync, timeout_s)


def _discover_sync(timeout_s: float) -> Gateway | None:
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
    sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 2)
    sock.settimeout(timeout_s)
    # Send one M-SEARCH per target; whichever router answers first wins.
    for st in SSDP_SEARCH_TARGETS:
        msg = (
            "M-SEARCH * HTTP/1.1\r\n"
            f"HOST: {SSDP_MULTICAST_GROUP}:{SSDP_PORT}\r\n"
            "MAN: \"ssdp:discover\"\r\n"
            "MX: 2\r\n"
            f"ST: {st}\r\n"
            "\r\n"
        )
        try:
            sock.sendto(msg.encode("ascii"), (SSDP_MULTICAST_GROUP, SSDP_PORT))
        except OSError as e:
            log.warning("ssdp_send_failed", exc_info=e)
            sock.close()
            return None

    location: str | None = None
    try:
        while True:
            data, _addr = sock.recvfrom(8192)
            text = data.decode("ascii", errors="replace")
            m = re.search(r"LOCATION:\s*(\S+)", text, re.IGNORECASE)
            if m:
                location = m.group(1).strip()
                break
    except socket.timeout:
        pass
    finally:
        sock.close()

    if not location:
        return None
    try:
        return _fetch_service(location)
    except Exception as e:  # noqa: BLE001
        log.warning("igd_description_fetch_failed", exc_info=e)
        return None


def _fetch_service(location: str) -> Gateway | None:
    """Download the IGD description XML and extract the WAN*Connection
    service's controlURL. Runs synchronously (called from a thread)."""
    # We use httpx sync client inside the thread — avoids an event
    # loop cross-thread for a one-shot HTTP GET.
    with httpx.Client(timeout=3.0) as client:
        r = client.get(location)
        if r.status_code != 200:
            return None
        xml_text = r.text

    root = ET.fromstring(xml_text)
    ns = {"d": NS_DEVICE}
    friendly_name_el = root.find(".//d:friendlyName", ns)
    friendly_name = friendly_name_el.text if friendly_name_el is not None else "IGD"

    # Walk services, pick the first WANIPConnection we find (IPv4).
    for service in root.iter("{%s}service" % NS_DEVICE):
        svc_type_el = service.find("d:serviceType", ns)
        ctrl_url_el = service.find("d:controlURL", ns)
        if svc_type_el is None or ctrl_url_el is None:
            continue
        svc_type = (svc_type_el.text or "").strip()
        ctrl = (ctrl_url_el.text or "").strip()
        if svc_type in (NS_WAN_IP, NS_WAN_PPP) and ctrl:
            base = urlparse(location)
            control_url = (
                ctrl if ctrl.startswith("http")
                else f"{base.scheme}://{base.netloc}{ctrl}"
            )
            return Gateway(
                location=location,
                control_url=control_url,
                service_type=svc_type,
                device_friendly_name=friendly_name or "IGD",
            )
    return None


# ── SOAP AddPortMapping / DeletePortMapping ─────────────────────────────────


def _local_ip_for(gateway_host: str) -> str:
    """Return the outbound-interface IP for reaching the gateway.

    We use the classic "connect UDP to the gateway, read back the
    socket's local_addr" trick. No packet is actually sent; the socket
    just binds a local interface.
    """
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect((gateway_host, 1))  # port doesn't matter
        return s.getsockname()[0]
    finally:
        s.close()


async def add_mapping(
    gateway: Gateway, mapping: PortMapping, lease_s: int = 7200
) -> None:
    """AddPortMapping SOAP call. Raises on non-200 or SOAP Fault.

    The internal_client is auto-detected from our outbound interface
    to the gateway. Lease time 0 = infinite but some routers reject it;
    2h is a safe default with renewal on the agent's side if sessions
    run longer.
    """
    host = urlparse(gateway.location).hostname or "192.168.1.1"
    internal_ip = _local_ip_for(host)

    body = _soap_envelope_add(mapping, gateway.service_type, internal_ip, lease_s)
    headers = {
        "Content-Type": 'text/xml; charset="utf-8"',
        "SOAPAction": f'"{gateway.service_type}#AddPortMapping"',
    }
    async with httpx.AsyncClient(timeout=6.0) as client:
        r = await client.post(gateway.control_url, content=body, headers=headers)
    if r.status_code != 200:
        raise RuntimeError(
            f"AddPortMapping returned {r.status_code}: {r.text[:200]}"
        )


async def delete_mapping(gateway: Gateway, mapping: PortMapping) -> None:
    body = _soap_envelope_delete(mapping, gateway.service_type)
    headers = {
        "Content-Type": 'text/xml; charset="utf-8"',
        "SOAPAction": f'"{gateway.service_type}#DeletePortMapping"',
    }
    async with httpx.AsyncClient(timeout=6.0) as client:
        r = await client.post(gateway.control_url, content=body, headers=headers)
    if r.status_code not in (200, 500):  # 500 = mapping didn't exist, ok
        raise RuntimeError(
            f"DeletePortMapping returned {r.status_code}: {r.text[:200]}"
        )


def _soap_envelope_add(
    m: PortMapping, service_type: str, internal_ip: str, lease_s: int
) -> bytes:
    """Build the AddPortMapping SOAP XML. Tight template — no XML lib
    needed since the shape is fixed."""
    xml = (
        '<?xml version="1.0"?>\n'
        '<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"'
        ' s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">'
        "<s:Body>"
        f'<u:AddPortMapping xmlns:u="{service_type}">'
        "<NewRemoteHost></NewRemoteHost>"
        f"<NewExternalPort>{m.external_port}</NewExternalPort>"
        f"<NewProtocol>{m.protocol}</NewProtocol>"
        f"<NewInternalPort>{m.internal_port}</NewInternalPort>"
        f"<NewInternalClient>{internal_ip}</NewInternalClient>"
        "<NewEnabled>1</NewEnabled>"
        f"<NewPortMappingDescription>{_xml_escape(m.description)}</NewPortMappingDescription>"
        f"<NewLeaseDuration>{lease_s}</NewLeaseDuration>"
        "</u:AddPortMapping>"
        "</s:Body>"
        "</s:Envelope>"
    )
    return xml.encode("utf-8")


def _soap_envelope_delete(m: PortMapping, service_type: str) -> bytes:
    xml = (
        '<?xml version="1.0"?>\n'
        '<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"'
        ' s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">'
        "<s:Body>"
        f'<u:DeletePortMapping xmlns:u="{service_type}">'
        "<NewRemoteHost></NewRemoteHost>"
        f"<NewExternalPort>{m.external_port}</NewExternalPort>"
        f"<NewProtocol>{m.protocol}</NewProtocol>"
        "</u:DeletePortMapping>"
        "</s:Body>"
        "</s:Envelope>"
    )
    return xml.encode("utf-8")


def _xml_escape(s: str) -> str:
    return (
        s.replace("&", "&amp;")
         .replace("<", "&lt;")
         .replace(">", "&gt;")
         .replace('"', "&quot;")
         .replace("'", "&apos;")
    )


# ── High-level facade ──────────────────────────────────────────────────────


async def try_map_sunshine_ports(
    description_prefix: str = "HAON",
    discovery_timeout_s: float = 3.0,
    lease_s: int = 7200,
) -> UpnpResult:
    """Discover IGD + map the 5 Sunshine TCP/UDP ports best-effort.

    Non-fatal on any failure — returns UpnpResult with partial mapped list
    + any failed entries. Caller surfaces the status to the worker so
    the user sees whether they can connect from WAN.
    """
    gw = await discover(timeout_s=discovery_timeout_s)
    if gw is None:
        return UpnpResult(gateway=None, mapped=[], failed=[])

    # Sunshine's standard ports. Each needs TCP + UDP depending on role.
    # Reference: https://docs.lizardbyte.dev/projects/sunshine/en/latest/about/advanced_usage.html#network
    targets = [
        # (port, protocol)
        (47984, "TCP"),  # HTTPS control
        (47989, "TCP"),  # HTTP control
        (47990, "TCP"),  # web UI (local only — skip WAN exposure)
        (47998, "UDP"),  # video
        (48000, "UDP"),  # control
        (48002, "UDP"),  # mic
        (48010, "TCP"),  # RTSP
    ]
    # Skip 47990 externally (web UI exposure = security risk).
    targets = [(p, pr) for (p, pr) in targets if p != 47990]

    mapped: list[PortMapping] = []
    failed: list[tuple[PortMapping, str]] = []
    for port, proto in targets:
        m = PortMapping(
            internal_port=port,
            external_port=port,
            protocol=proto,
            description=f"{description_prefix} Sunshine {port}/{proto}",
        )
        try:
            await add_mapping(gw, m, lease_s=lease_s)
            mapped.append(m)
        except Exception as e:  # noqa: BLE001
            failed.append((m, str(e)))

    return UpnpResult(gateway=gw, mapped=mapped, failed=failed)


async def cleanup_sunshine_ports(result: UpnpResult) -> None:
    """Best-effort delete of whatever we mapped. Called on session close."""
    if result.gateway is None:
        return
    for m in result.mapped:
        try:
            await delete_mapping(result.gateway, m)
        except Exception as e:  # noqa: BLE001
            log.warning("upnp_delete_failed", extra={"mapping": m, "error": str(e)})
