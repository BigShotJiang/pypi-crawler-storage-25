"""Platform-specific firewall advisory (R2.3).

Detects the firewall in use + tells the user what ports they need to
open if UPnP failed. Does NOT auto-modify rules:
  - Needs admin/root privileges → silent sudo is a bad idea
  - User-controlled security boundary → we refuse to touch it without
    consent
  - Sunshine's own installer already does the common case on Windows

Output is a dataclass the runtime surfaces to the worker via status
messages, so the worker's UI can render "port forwarding needed"
guidance if pairing fails.

## What each OS gets

- **Windows**: `netsh advfirewall firewall show` to detect existing
  rules; otherwise we log the exact netsh commands the user can run
  in an Admin PowerShell.
- **macOS**: default firewall is off; if enabled via System Settings,
  we log advisory. No auto-modify of pfctl.
- **Linux**: detect ufw / firewalld / iptables, print the command for
  whichever is in use. No `sudo` escalation attempted.
"""

from __future__ import annotations

import asyncio
import platform
import shutil
import subprocess
from dataclasses import dataclass
from typing import Literal


@dataclass(frozen=True)
class FirewallStatus:
    """What we know about the host's firewall for Sunshine ports."""
    kind: Literal["windows_defender", "ufw", "firewalld", "iptables", "pf", "unknown", "none"]
    active: bool
    advisory: str  # human-readable one-paragraph advice (may be empty)
    manual_commands: list[str]  # commands the user runs in an admin shell


SUNSHINE_PORTS = [
    # (port, proto, note)
    (47984, "TCP", "HTTPS control"),
    (47989, "TCP", "HTTP control"),
    (47998, "UDP", "video"),
    (48000, "UDP", "control"),
    (48002, "UDP", "mic"),
    (48010, "TCP", "RTSP"),
]


async def detect() -> FirewallStatus:
    """Inspect the local firewall + return status + manual-fix commands.

    Never raises — returns 'unknown'/empty on any detection failure.
    """
    system = platform.system()
    if system == "Windows":
        return await _detect_windows()
    if system == "Darwin":
        return await _detect_macos()
    if system == "Linux":
        return await _detect_linux()
    return FirewallStatus(
        kind="unknown", active=False,
        advisory=f"Unsupported OS: {system}. Ensure inbound is open on Sunshine ports.",
        manual_commands=[],
    )


# ── Windows ─────────────────────────────────────────────────────────────────


async def _detect_windows() -> FirewallStatus:
    """Windows Defender Firewall is effectively always-on in 10/11.
    Sunshine's installer usually registers allow rules — we don't check
    for those (needs admin) but we always return the manual commands
    as a fallback so the user has a clear path if pairing fails.
    """
    cmds = []
    for port, proto, note in SUNSHINE_PORTS:
        cmds.append(
            f'netsh advfirewall firewall add rule '
            f'name="HAON Sunshine {port}/{proto}" '
            f'dir=in action=allow protocol={proto} localport={port}'
        )
    return FirewallStatus(
        kind="windows_defender",
        active=True,
        advisory=(
            "Windows Defender Firewall is active. Sunshine's installer "
            "usually adds the needed rules — if pairing fails, open an "
            "Admin PowerShell and run the commands below."
        ),
        manual_commands=cmds,
    )


# ── macOS ───────────────────────────────────────────────────────────────────


async def _detect_macos() -> FirewallStatus:
    """macOS ships with pf + a user-facing firewall in System Settings.
    The user-facing one is off by default; pf is off unless explicitly
    enabled. If both are off, nothing to do. If on, the user has to
    add the rules via System Settings → Network → Firewall.
    """
    try:
        proc = await asyncio.create_subprocess_exec(
            "/usr/libexec/ApplicationFirewall/socketfilterfw", "--getglobalstate",
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.DEVNULL,
        )
        out, _ = await proc.communicate()
        active = b"enabled" in out.lower()
    except (FileNotFoundError, OSError):
        active = False
    advisory = (
        "macOS Application Firewall is enabled. Open System Settings → "
        "Network → Firewall → Options, add Sunshine (/Applications/"
        "Sunshine.app), and allow incoming connections."
    ) if active else (
        "macOS firewall is disabled — nothing to configure."
    )
    return FirewallStatus(
        kind="pf" if active else "none",
        active=active,
        advisory=advisory,
        manual_commands=[],
    )


# ── Linux ───────────────────────────────────────────────────────────────────


async def _detect_linux() -> FirewallStatus:
    """Detect ufw → firewalld → iptables in that order.

    ufw is on Ubuntu/Debian/Mint; firewalld is RHEL/Fedora/Alma; plain
    iptables is Arch/Gentoo/minimal. We run the status command with
    sudo-less -n so it either returns the state or fails silently.
    """
    # ufw
    if shutil.which("ufw"):
        try:
            proc = await asyncio.create_subprocess_exec(
                "ufw", "status",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            out, _ = await proc.communicate()
            active = b"Status: active" in out
            if active:
                cmds = [f"sudo ufw allow {p}/{pr.lower()}" for p, pr, _ in SUNSHINE_PORTS]
                return FirewallStatus(
                    kind="ufw", active=True,
                    advisory="ufw is active. Run the commands below with sudo.",
                    manual_commands=cmds,
                )
        except (FileNotFoundError, OSError, PermissionError):
            pass

    # firewalld
    if shutil.which("firewall-cmd"):
        try:
            proc = await asyncio.create_subprocess_exec(
                "firewall-cmd", "--state",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            out, _ = await proc.communicate()
            if b"running" in out:
                cmds = [
                    f"sudo firewall-cmd --permanent --add-port={p}/{pr.lower()}"
                    for p, pr, _ in SUNSHINE_PORTS
                ] + ["sudo firewall-cmd --reload"]
                return FirewallStatus(
                    kind="firewalld", active=True,
                    advisory="firewalld is running. Run the commands below with sudo.",
                    manual_commands=cmds,
                )
        except (FileNotFoundError, OSError, PermissionError):
            pass

    # iptables — just produce the commands; no easy way to tell if
    # rules are already there without parsing output.
    if shutil.which("iptables"):
        cmds = [
            f"sudo iptables -A INPUT -p {pr.lower()} --dport {p} -j ACCEPT"
            for p, pr, _ in SUNSHINE_PORTS
        ]
        return FirewallStatus(
            kind="iptables", active=True,
            advisory=(
                "Raw iptables detected. Add the rules below (you may also "
                "want to persist them via iptables-save)."
            ),
            manual_commands=cmds,
        )

    return FirewallStatus(
        kind="none", active=False,
        advisory="No Linux firewall detected — nothing to configure.",
        manual_commands=[],
    )
