"""Public IP discovery helpers.

Used by the remote_desktop runtime (R2) to tell the worker's Moonlight
client where to connect. The agent asks one of several public HTTPS
endpoints what the source IP of our request looked like — that's the
NAT-external address Moonlight needs to dial.

## Why not STUN?

STUN is the "right" tool here (it's designed for this), but the
HTTPS-echo approach has 3 advantages for our specific case:
  - no extra wire protocol or UDP socket surgery
  - HTTPS works behind corporate/coffee-shop proxies where UDP 3478 is blocked
  - multiple redundant providers are free + tiny

Future Phase 28 may add STUN for dual-stack / IPv6 coverage.

## Fallback list

Tried in order, first 200-response wins. All return plain text IP:
  1. api.ipify.org       (oldest + most reliable, no rate limit for low vol)
  2. icanhazip.com       (Cloudflare-backed)
  3. ifconfig.me         (Cloudflare-backed)
"""

from __future__ import annotations

import ipaddress
import logging
from dataclasses import dataclass

import httpx


log = logging.getLogger("agent.net.public_ip")


PROVIDERS = [
    "https://api.ipify.org",
    "https://icanhazip.com",
    "https://ifconfig.me/ip",
]


@dataclass(frozen=True)
class PublicIp:
    address: str  # dotted-quad IPv4 or colon-separated IPv6
    is_v6: bool
    provider: str


async def discover(*, timeout_s: float = 3.0) -> PublicIp | None:
    """Return the current public IP, or None if every provider fails.

    Callers should cache the result — this doesn't need to run on every
    session. Re-run once per agent start-up + maybe again if a session
    fails to pair (network changed underneath).
    """
    async with httpx.AsyncClient(timeout=timeout_s, follow_redirects=True) as client:
        for url in PROVIDERS:
            try:
                r = await client.get(url)
                if r.status_code != 200:
                    continue
                raw = r.text.strip()
                try:
                    parsed = ipaddress.ip_address(raw)
                except ValueError:
                    continue
                return PublicIp(
                    address=str(parsed),
                    is_v6=isinstance(parsed, ipaddress.IPv6Address),
                    provider=url,
                )
            except httpx.RequestError as e:
                log.warning("public_ip_provider_failed", extra={"url": url, "error": str(e)})
                continue
    return None
