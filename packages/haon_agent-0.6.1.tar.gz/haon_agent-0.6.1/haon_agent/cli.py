"""`haon-agent` CLI."""

from __future__ import annotations

import asyncio
import logging
import os
import sys
from getpass import getpass

import click
import httpx
import structlog

from haon_agent import __version__, config, credentials, hardware
from haon_agent.agent import Agent, AgentDeps
from haon_agent.api_client import ApiClient, ApiError


def _apply_fake_hardware(flag: bool) -> None:
    """If --fake-hardware was passed, set the env var hardware.detect reads.
    Safe to call multiple times (idempotent). Logged loudly so it never
    ships to prod by accident — operator sees it every single invocation."""
    if flag:
        os.environ["HAON_FAKE_HARDWARE"] = "1"
        click.echo(
            "⚠️  HAON_FAKE_HARDWARE=1 — reporting synthetic RTX 4090 to the backend. "
            "Dev/test only. Do NOT use in production.",
            err=True,
        )


def _configure_logging(level: str = "info") -> None:
    """Logging config — pretty colored console when attached to a TTY
    (operator sitting at a terminal); JSON otherwise (CI, docker
    compose logs, log-aggregation pipelines). Opt out of colors
    explicitly with HAON_LOG_FORMAT=json.

    Detection: sys.stderr.isatty() is the Unix-standard check, honored
    by Windows Terminal + PowerShell + modern cmd.exe via VT100.
    """
    force = os.environ.get("HAON_LOG_FORMAT", "").lower()
    pretty = force == "console" or (
        force != "json" and sys.stderr.isatty()
    )

    renderer: object
    if pretty:
        renderer = structlog.dev.ConsoleRenderer(
            colors=True,
            sort_keys=True,
            exception_formatter=structlog.dev.plain_traceback,
        )
    else:
        renderer = structlog.processors.JSONRenderer()

    structlog.configure(
        processors=[
            structlog.contextvars.merge_contextvars,
            structlog.processors.add_log_level,
            structlog.processors.TimeStamper(
                fmt="%H:%M:%S" if pretty else "iso",
                utc=True,
            ),
            renderer,
        ],
        wrapper_class=structlog.make_filtering_bound_logger(
            getattr(logging, level.upper(), logging.INFO)
        ),
        logger_factory=structlog.PrintLoggerFactory(file=sys.stderr),
    )


@click.group()
@click.version_option(__version__)
def cli() -> None:
    """HAON PowerHub miner agent."""


@cli.command()
@click.option("--api-url", default="https://api.haon.run", show_default=True)
def login(api_url: str) -> None:
    """Paste an API key created in the dashboard / via /v1/me/api-keys."""
    click.echo(f"API URL: {api_url}")
    raw = getpass("Paste your miner:agent API key: ").strip()
    if not raw.startswith("haon_"):
        click.echo("That does not look like a HAON API key.", err=True)
        raise SystemExit(2)
    credentials.store(raw)
    cfg = config.load()
    cfg.api_url = api_url
    config.save(cfg)
    click.echo("Stored. Run `haon-agent hardware` to see what will be registered.")


@cli.command()
@click.option(
    "--api-url",
    default="https://api.haon.run",
    show_default=True,
    help="HAON API base URL to pair against.",
)
@click.option(
    "--email",
    default=None,
    help="Skip the prompt and use this email.",
)
@click.option(
    "--password",
    default=None,
    help=(
        "Skip the prompt and use this password. Prefer interactive entry; "
        "passing --password puts the secret in shell history."
    ),
)
@click.option("--name", "machine_name", default=None, help="Machine name (default: hostname).")
@click.option("--price", "price_per_hour", default=None, help="Price per hour in USD (e.g. 0.40).")
@click.option("--hub-id", default=None, help="Pin to a specific hub UUID (skip interactive pick).")
@click.option(
    "--non-interactive",
    is_flag=True,
    default=False,
    help="Fail instead of prompting for missing values. Useful in installer scripts.",
)
def pair(
    api_url: str,
    email: str | None,
    password: str | None,
    machine_name: str | None,
    price_per_hour: str | None,
    hub_id: str | None,
    non_interactive: bool,
) -> None:
    """One-command pairing: login, register machine, mint API key, save config.

    This is the plug-and-play path for new miners. Prompts for email + password,
    discovers hubs, probes hardware, and writes everything to ~/.haon/.
    After it returns, `haon-agent run` works without flags.
    """
    from haon_agent.pair import PairError, run_pair

    try:
        run_pair(
            api_url=api_url,
            email=email,
            password=password,
            machine_name=machine_name,
            price_per_hour=price_per_hour,
            hub_id=hub_id,
            non_interactive=non_interactive,
        )
    except PairError as e:
        click.echo(f"\npair failed: {e}", err=True)
        raise SystemExit(2) from e
    except KeyboardInterrupt:
        click.echo("\naborted.", err=True)
        raise SystemExit(130) from None


@cli.command()
def logout() -> None:
    credentials.clear()
    click.echo("Credentials cleared.")


@cli.command()
@click.option(
    "--fake-hardware",
    is_flag=True,
    default=False,
    help="Dev/test: report a synthetic RTX 4090 rig without probing the host.",
)
def hardware_info(fake_hardware: bool) -> None:
    """Show detected hardware. No network calls."""
    _apply_fake_hardware(fake_hardware)
    report = hardware.detect()
    click.echo(f"CPU: {report.cpu_model} ({report.cpu_cores} cores)")
    click.echo(f"RAM: {report.ram_gb} GB")
    if report.gpu_count > 0:
        click.echo(
            f"GPU: {report.gpu_model} "
            f"({report.gpu_count}× @ {report.gpu_vram_gb} GB VRAM)"
        )
        if report.tdp_watts is not None:
            click.echo(f"TDP: {report.tdp_watts} W")
        else:
            click.echo("TDP: unknown (nvidia-smi did not report power.max_limit)")
    else:
        click.echo("GPU: none detected (CPU-only)")
    click.echo(f"Fingerprint: {report.fingerprint()[:16]}…")


cli.add_command(hardware_info, name="hardware")


@cli.command()
def status() -> None:
    """Show config + credential presence (never echoes the key itself)."""
    cfg = config.load()
    has_key = credentials.load() is not None
    click.echo(f"API URL: {cfg.api_url}")
    click.echo(f"Machine ID: {cfg.machine_id or '(not registered)'}")
    click.echo(f"Hub ID: {cfg.hub_id or '(not set)'}")
    click.echo(f"Runtimes: {', '.join(cfg.supported_runtimes)}")
    click.echo(f"Default runtime: {cfg.default_runtime}")
    click.echo(f"Credentials present: {'yes' if has_key else 'no'}")


@cli.command()
def diagnose() -> None:
    """Dump a redacted support bundle to stdout."""
    cfg = config.load()
    report = hardware.detect()
    has_key = credentials.load() is not None
    bundle = {
        "agent_version": __version__,
        "config": {
            "api_url": cfg.api_url,
            "machine_id": cfg.machine_id,
            "hub_id": cfg.hub_id,
            "runtimes": cfg.supported_runtimes,
        },
        "credentials_present": has_key,
        "hardware": {
            "cpu_model": report.cpu_model,
            "cpu_cores": report.cpu_cores,
            "ram_gb": report.ram_gb,
            "gpu_model": report.gpu_model,
            "gpu_vram_gb": report.gpu_vram_gb,
            "gpu_count": report.gpu_count,
            "tdp_watts": report.tdp_watts,
            "fingerprint": report.fingerprint(),
        },
    }
    import json

    click.echo(json.dumps(bundle, indent=2, default=str))


@cli.command()
@click.option("--machine-id", required=False)
@click.option(
    "--fake-hardware",
    is_flag=True,
    default=False,
    help="Dev/test: report a synthetic RTX 4090 rig instead of probing the host.",
)
def run(machine_id: str | None, fake_hardware: bool) -> None:
    """Start the agent loop: heartbeat + session accept."""
    _apply_fake_hardware(fake_hardware)
    cfg = config.load()
    if machine_id:
        cfg.machine_id = machine_id
        config.save(cfg)
    if not cfg.machine_id:
        click.echo(
            "No machine_id configured. Register your machine in the dashboard "
            "first, then run `haon-agent run --machine-id <uuid>`.",
            err=True,
        )
        raise SystemExit(2)

    key = credentials.load()
    if not key:
        click.echo("No credentials. Run `haon-agent login` first.", err=True)
        raise SystemExit(2)

    _configure_logging(cfg.log_level)

    async def _main() -> None:
        async with ApiClient(base_url=cfg.api_url, api_key=key) as api:
            agent = Agent(AgentDeps(api=api, config=cfg))
            try:
                await agent.run()
            except KeyboardInterrupt:
                agent.request_stop()

    try:
        asyncio.run(_main())
    except ApiError as e:
        click.echo(f"API error on startup: {e.code} — {e.message}", err=True)
        raise SystemExit(3) from None


# ── BYOC subgroup ──────────────────────────────────────────────────────
#
# Bring Your Own Compute (haonhub.com integration) is a parallel product
# to the marketplace flow above. Sprint 1B (PR #85) shipped the agent-
# side core — op-runtimes, workflow DSL parser+executor, model_sync,
# dispatch entry point — but NOT the pairing flow or the long-lived
# WSS transport that haonhub end-users will use. Sprint 1C will close
# that loop (see GitHub issue tracking it).
#
# Until 1C lands, the `byoc dispatch` subcommand below is the smoke-
# test entry point: operators / CI can hand the agent a workflow JSON
# file and exercise the full byoc pipeline (parse → execute → output
# shape) without standing up the WSS transport. Proves the core works
# in the agent's import context + gives a manual debugging knob.


@cli.group("byoc")
def byoc_group() -> None:
    """BYOC (haonhub.com) — workflow dispatch + model sync.

    These commands are smoke-test / debug entry points. The production
    BYOC flow (PAIR_INIT, permanent token, long-lived WSS to broker.haon.run)
    is tracked separately under Sprint 1C — not yet wired here.
    """


@byoc_group.command("dispatch")
@click.option(
    "--workflow-file",
    "workflow_file",
    type=click.Path(exists=True, dir_okay=False, readable=True),
    required=True,
    help="Path to a workflow JSON file (shape per workflow-dsl-spec v1).",
)
@click.option(
    "--session-id",
    default=None,
    help="Optional UUID for the session. Random if omitted.",
)
@click.option(
    "--keep-session-dir",
    is_flag=True,
    default=False,
    help="Don't clean up ~/haon/sessions/<id>/ after dispatch (useful for "
    "inspecting intermediate files in tests).",
)
def byoc_dispatch(
    workflow_file: str,
    session_id: str | None,
    keep_session_dir: bool,
) -> None:
    """Run a workflow JSON file end-to-end through the BYOC pipeline.

    Reads the file, wraps it in a wire.WorkflowEnvelope, dispatches via
    `byoc.dispatch.handle_workflow_frame`, and prints every frame
    emitted (progress + terminal) as JSON-per-line to stdout. Exit code:
    0 if terminal frame was "done"; 1 if it was "error".

    Example:
        $ cat > wf.json <<EOF
        {"version":1,"runtime":"multi","session":{},
         "inputs":{"q":"hello"},
         "steps":[{"id":"a","op":"ollama.generate","model":"haon-llm-3b",
                   "user":"{inputs.q}","max_tokens":50}],
         "output":{"type":"text","from":"{steps.a.text}"}}
        EOF
        $ haon-agent byoc dispatch --workflow-file wf.json
    """
    import json  # noqa: PLC0415 — local import keeps cli startup fast
    import uuid as _uuid  # noqa: PLC0415

    from haon_agent.byoc import dispatch as _byoc_dispatch  # noqa: PLC0415

    _configure_logging("info")

    try:
        with open(workflow_file, encoding="utf-8") as f:
            workflow = json.load(f)
    except json.JSONDecodeError as e:
        click.echo(f"workflow JSON parse error: {e}", err=True)
        raise SystemExit(2) from None

    sid = _uuid.UUID(session_id) if session_id else _uuid.uuid4()
    frame = {
        "msg": "workflow",
        "v": 1,
        "session_id": str(sid),
        "workflow": workflow,
    }

    # Collect frames as they're emitted; print one line of JSON per
    # frame to stdout so callers (tests, ops dashboards) can stream.
    async def _send(out_frame: dict[str, object]) -> None:
        click.echo(json.dumps(out_frame, ensure_ascii=False))

    async def _go() -> dict[str, object]:
        try:
            return await _byoc_dispatch.handle_workflow_frame(
                frame, send=_send
            )
        finally:
            if not keep_session_dir:
                _byoc_dispatch.cleanup_session_dir(sid)

    result = asyncio.run(_go())
    raise SystemExit(0 if result["msg"] == "done" else 1)


# ── Sprint 1C — pair / connect / status / unpair ────────────────────────


@byoc_group.command("pair")
@click.argument("pairing_code", type=str)
@click.option(
    "--api-base",
    default="https://broker.haon.run",
    show_default=True,
    help="API base URL. broker.haon.run path-routes /v1/byoc/* to the API.",
)
@click.option(
    "--force-rebind",
    is_flag=True,
    default=False,
    help=(
        "Overwrite an existing active pairing for this machine. Use when "
        "local config was deleted/lost and the server still thinks the "
        "fingerprint is paired (split-brain). The server soft-deletes the "
        "old pairing before INSERTing the new one. Audit-logged."
    ),
)
def byoc_pair(pairing_code: str, api_base: str, force_rebind: bool) -> None:
    """Confirm a haonhub pairing code: generate Ed25519 keypair, POST
    /v1/byoc/pair-confirm, persist permanent_token + agent_id in the
    OS keyring.

    Get the 6-digit code from your haonhub dashboard's pairing flow.

    Example:
        $ haon-agent byoc pair ABC234
        Paired as agent_<uuid>. You can now run `haon-agent byoc connect`
        to start receiving workflows from haonhub.

    Split-brain recovery (hotfix 0.5.1):
        $ haon-agent byoc pair ABC234 --force-rebind
    """
    from haon_agent.byoc import pair as _pair

    _configure_logging("info")
    code = _pair.normalise_code(pairing_code)

    async def _go():
        return await _pair.confirm_pairing(
            api_base=api_base,
            pairing_code=code,
            agent_version=__version__,
            force_rebind=force_rebind,
        )

    state = asyncio.run(_go())
    click.echo(f"Paired as {state.agent_id}")
    click.echo(f"Paired at: {state.paired_at_iso}")
    if force_rebind:
        click.echo(
            "(force-rebind used — any prior pairing for this fingerprint "
            "was soft-deleted on the server.)"
        )
    click.echo(
        "\nNext: run `haon-agent byoc connect` to start receiving "
        "workflows from haonhub."
    )


@byoc_group.command("doctor")
@click.option(
    "--api-base",
    default="https://broker.haon.run",
    show_default=True,
    help="API base URL for the broker ping + /v1/byoc/agent-self.",
)
@click.option(
    "--json",
    "as_json",
    is_flag=True,
    default=False,
    help="Emit structured JSON instead of pretty-printed bullets. "
    "For CI / scripts.",
)
def byoc_doctor(api_base: str, as_json: bool) -> None:
    """5-point health check for the BYOC pair → connect circuit.

    Checks (hotfix 0.5.1):
      a) Keyring present (local pairing creds exist)
      b) Broker reachable (TCP + TLS handshake at api_base)
      c) Server-side pairing healthy (GET /v1/byoc/agent-self matches
         local agent_id AND revoked=false)
      d) Ollama daemon up (GET http://127.0.0.1:11434/api/version)
      e) Ollama has ≥ 1 model loaded locally

    Exit 0 if every check passes, 1 otherwise. JSON mode emits a
    structured dict for CI parsing; default mode pretty-prints with
    ✓ / ✗ bullets so a human can scan in 1 second.
    """
    import json as _json

    from haon_agent.byoc import capabilities as _caps
    from haon_agent.byoc import identity as _id

    results: list[dict[str, object]] = []

    # (a) keyring
    state = _id.load_paired()
    if state is None:
        results.append({
            "id": "keyring",
            "ok": False,
            "detail": "No local pairing creds. Run `haon-agent byoc pair "
            "<code>` to bind this machine.",
        })
    else:
        results.append({
            "id": "keyring",
            "ok": True,
            "detail": f"Paired as {state.agent_id} since {state.paired_at_iso}",
        })

    # (b) broker reachable — quick HEAD on /health
    try:
        with httpx.Client(timeout=8.0) as client:
            resp = client.get(f"{api_base.rstrip('/')}/health")
        if resp.status_code == 200:
            results.append({
                "id": "broker_reachable",
                "ok": True,
                "detail": f"{api_base} /health → 200",
            })
        else:
            results.append({
                "id": "broker_reachable",
                "ok": False,
                "detail": f"{api_base} /health returned {resp.status_code}",
            })
    except Exception as exc:  # noqa: BLE001
        results.append({
            "id": "broker_reachable",
            "ok": False,
            "detail": f"{api_base} unreachable: {exc}",
        })

    # (c) server-side pairing — only if (a) passed
    if state is not None:
        try:
            with httpx.Client(timeout=8.0) as client:
                resp = client.get(
                    f"{api_base.rstrip('/')}/v1/byoc/agent-self",
                    headers={"Authorization": f"Bearer {state.permanent_token}"},
                )
            if resp.status_code == 200:
                data = resp.json()
                if data.get("revoked"):
                    results.append({
                        "id": "server_pairing",
                        "ok": False,
                        "detail": f"Server says REVOKED at "
                        f"{data.get('revoked_at')}. Re-pair from haonhub.",
                    })
                elif data.get("agent_id") != state.agent_id:
                    results.append({
                        "id": "server_pairing",
                        "ok": False,
                        "detail": f"Token resolves to {data.get('agent_id')} "
                        f"but local has {state.agent_id} — split-brain.",
                    })
                else:
                    results.append({
                        "id": "server_pairing",
                        "ok": True,
                        "detail": f"agent={data.get('agent_id')} "
                        f"tenant={data.get('tenant_slug')} "
                        f"end_user={data.get('end_user_id')}",
                    })
            elif resp.status_code == 401:
                results.append({
                    "id": "server_pairing",
                    "ok": False,
                    "detail": "Token rejected (401). Likely expired or "
                    "wrong broker signing key. Re-pair from haonhub.",
                })
            elif resp.status_code == 404:
                results.append({
                    "id": "server_pairing",
                    "ok": False,
                    "detail": "Token verifies but server has no row for "
                    "this agent. Likely a force-unpair or DB wipe. "
                    "Re-pair from haonhub.",
                })
            else:
                results.append({
                    "id": "server_pairing",
                    "ok": False,
                    "detail": f"agent-self returned {resp.status_code}",
                })
        except Exception as exc:  # noqa: BLE001
            results.append({
                "id": "server_pairing",
                "ok": False,
                "detail": f"agent-self call failed: {exc}",
            })
    else:
        results.append({
            "id": "server_pairing",
            "ok": False,
            "detail": "Skipped — no local creds to check against.",
        })

    # (d + e) Ollama
    ollama_info = _caps.probe_ollama()
    if ollama_info.get("daemon_running"):
        results.append({
            "id": "ollama_daemon",
            "ok": True,
            "detail": f"Ollama {ollama_info.get('version')} responding "
            f"on 127.0.0.1:11434",
        })
        models = ollama_info.get("models") or []
        if models:
            results.append({
                "id": "ollama_models",
                "ok": True,
                "detail": f"{len(models)} model(s) local: {', '.join(models[:5])}"
                + ("..." if len(models) > 5 else ""),
            })
        else:
            results.append({
                "id": "ollama_models",
                "ok": False,
                "detail": "Ollama up but no models pulled. Run "
                "`ollama pull qwen2.5:14b` (or your preferred model).",
            })
    else:
        if ollama_info.get("installed"):
            results.append({
                "id": "ollama_daemon",
                "ok": False,
                "detail": "Ollama installed but daemon not running. Start "
                "with `ollama serve` (or restart the Ollama desktop app).",
            })
        else:
            results.append({
                "id": "ollama_daemon",
                "ok": False,
                "detail": "Ollama not installed. Download from "
                "https://ollama.com/download",
            })
        results.append({
            "id": "ollama_models",
            "ok": False,
            "detail": "Skipped — daemon not up.",
        })

    if as_json:
        click.echo(_json.dumps({"checks": results, "ok": all(r["ok"] for r in results)}, indent=2))
    else:
        click.echo("haon-agent doctor:")
        for r in results:
            mark = click.style("✓", fg="green") if r["ok"] else click.style("✗", fg="red")
            click.echo(f"  {mark}  {r['id']}: {r['detail']}")
        click.echo()
        if all(r["ok"] for r in results):
            click.secho("All checks passed.", fg="green")
        else:
            fail_count = sum(1 for r in results if not r["ok"])
            click.secho(
                f"{fail_count} check(s) failed — see above for fix steps.",
                fg="red",
                err=True,
            )

    if not all(r["ok"] for r in results):
        raise SystemExit(1)


@byoc_group.command("start")
@click.argument("pairing_code", type=str)
@click.option(
    "--api-base",
    default="https://broker.haon.run",
    show_default=True,
    help="API base URL for the pair-confirm call.",
)
@click.option(
    "--ws-url",
    default="wss://broker.haon.run/v1/byoc/connect",
    show_default=True,
    help="Broker WSS endpoint for the connect loop.",
)
@click.option(
    "--yes",
    "yes_flag",
    is_flag=True,
    default=False,
    help="Auto-accept the force-rebind prompt if local creds are missing "
    "but the server already has this fingerprint bound. Useful for "
    "headless installers / CI.",
)
def byoc_start(
    pairing_code: str, api_base: str, ws_url: str, yes_flag: bool
) -> None:
    """One-shot pair + connect. The whole circuit in a single command.

    Flow (hotfix 0.5.1):
      1. Run pair-confirm with the 6-dig code.
      2. If server returns 409 PAIR_FINGERPRINT_REUSE AND local
         keyring is empty (classic split-brain), prompt the user to
         force-rebind (or auto-accept via --yes).
      3. On pair success → immediately enter the connect WSS loop.
      4. Ctrl+C clean exit.

    Single command replaces:
      $ haon-agent byoc pair ABC234
      $ haon-agent byoc connect

    Use this for first-time setup; for daemonized runs use
    `haon-agent service install` (autostart on logon).
    """
    from haon_agent.byoc import identity as _id
    from haon_agent.byoc import pair as _pair
    from haon_agent.byoc import transport as _tr

    _configure_logging("info")
    code = _pair.normalise_code(pairing_code)

    async def _pair_with_recovery(force_rebind: bool):
        return await _pair.confirm_pairing(
            api_base=api_base,
            pairing_code=code,
            agent_version=__version__,
            force_rebind=force_rebind,
        )

    # Phase 1 — first pair attempt (no force-rebind).
    try:
        state = asyncio.run(_pair_with_recovery(False))
    except click.ClickException as exc:
        # Split-brain detection: 409 with local config empty.
        if exc.exit_code == 5 and _id.load_paired() is None:
            click.echo(
                "Server says this machine is already paired, but local "
                "credentials are missing (split-brain state).",
                err=True,
            )
            if yes_flag:
                click.echo("--yes passed → force-rebind automatic.")
                proceed = True
            else:
                proceed = click.confirm(
                    "Force rebind? (will overwrite the prior pairing "
                    "on the server)",
                    default=False,
                )
            if not proceed:
                click.echo("Aborted. No pairing made.", err=True)
                raise SystemExit(5) from exc
            state = asyncio.run(_pair_with_recovery(True))
            click.echo("(force-rebind succeeded)")
        else:
            raise

    click.echo(f"Paired as {state.agent_id}")
    click.echo(f"Connecting to broker {ws_url}...")
    click.echo("(Press Ctrl+C to disconnect.)\n")

    # Phase 2 — immediately enter the connect loop with the fresh state.
    transport = _tr.Transport(
        broker_ws_url=ws_url,
        permanent_token=state.permanent_token,
    )

    async def _run():
        try:
            await transport.connect_forever()
        except KeyboardInterrupt:
            transport.request_stop()

    try:
        asyncio.run(_run())
    except KeyboardInterrupt:
        click.echo("\nDisconnected.", err=True)


@byoc_group.command("connect")
@click.option(
    "--ws-url",
    default="wss://broker.haon.run/v1/byoc/connect",
    show_default=True,
    help="Broker WSS endpoint. Override for staging / local broker.",
)
def byoc_connect(ws_url: str) -> None:
    """Open a long-lived WSS to the broker with the stored
    permanent_token. Reconnects automatically with exponential backoff
    on drops. Runs until Ctrl-C.
    """
    from haon_agent.byoc import identity as _id
    from haon_agent.byoc import transport as _tr

    _configure_logging("info")

    state = _id.load_paired()
    if state is None:
        click.echo(
            "Not paired. Run `haon-agent byoc pair <6-dig-code>` first.",
            err=True,
        )
        raise SystemExit(2)

    transport = _tr.Transport(
        broker_ws_url=ws_url,
        permanent_token=state.permanent_token,
    )

    async def _run():
        try:
            await transport.connect_forever()
        except KeyboardInterrupt:
            transport.request_stop()

    try:
        asyncio.run(_run())
    except KeyboardInterrupt:
        click.echo("\nDisconnected.", err=True)


@byoc_group.command("status")
def byoc_status() -> None:
    """Show the local BYOC pairing state. NEVER echoes the
    permanent_token plaintext; only redacted summary."""
    from haon_agent.byoc import identity as _id

    state = _id.load_paired()
    if state is None:
        click.echo("BYOC: not paired")
        click.echo("Run `haon-agent byoc pair <6-dig-code>` to pair.")
        return
    click.echo(f"BYOC: paired")
    click.echo(f"  agent_id     = {state.agent_id}")
    click.echo(f"  paired_at    = {state.paired_at_iso}")
    click.echo(f"  agent_pubkey = {state.agent_pubkey_b64[:8]}...{state.agent_pubkey_b64[-4:]}")
    # NEVER print state.permanent_token or state.agent_priv_pem. Last 4
    # of token only, for cross-referencing logs.
    tail = state.permanent_token.rsplit(".", 1)[-1][-8:]
    click.echo(f"  token (last8)= ...{tail}")

    # Sprint 1F.4 phase 5 — runtime kinds + slot capacity local view.
    # Computed from capabilities.py the same way the hello frame
    # advertises — useful for the operator to sanity-check what the
    # broker thinks this machine can do.
    try:
        from haon_agent.byoc import capabilities as _byoc_caps
        kinds = _byoc_caps.detect_runtime_kinds()
        slots = _byoc_caps.detect_slots()
        click.echo(f"  runtime_kinds= {', '.join(kinds) if kinds else '(none)'}")
        if slots:
            slot_str = ", ".join(f"{k}={v}" for k, v in sorted(slots.items()))
            click.echo(f"  slots        = {slot_str}")
    except Exception as e:  # noqa: BLE001
        click.echo(f"  capabilities = (detection failed: {e})", err=True)


@byoc_group.command("unpair")
@click.option(
    "--api-base",
    default="https://broker.haon.run",
    show_default=True,
    help="API base URL — used for the server-side revoke call.",
)
@click.option(
    "--yes",
    is_flag=True,
    default=False,
    help="Skip confirmation prompt.",
)
def byoc_unpair(api_base: str, yes: bool) -> None:
    """Revoke the local BYOC pairing. Removes the permanent_token from
    keyring + deletes the priv key. Server-side revocation (DELETE
    /v1/byoc/agents/{agent_id}) lands when the API endpoint exists
    (tracked in Issue #87 follow-up); until then this is local-only."""
    import httpx
    from haon_agent.byoc import identity as _id

    state = _id.load_paired()
    if state is None:
        click.echo("Nothing to do — no BYOC pairing on this machine.")
        return

    if not yes:
        if not click.confirm(
            f"This will revoke pairing for {state.agent_id}. Continue?",
            default=False,
        ):
            click.echo("Cancelled.")
            return

    # Best-effort server-side revoke. If the endpoint isn't deployed
    # yet, we still clear the local keyring — the agent is unusable
    # without the priv key anyway, and haonhub will reconcile from
    # heartbeat-lost webhook (server stops seeing this agent_id).
    url = f"{api_base.rstrip('/')}/v1/byoc/agents/{state.agent_id}"
    headers = {"Authorization": f"Bearer {state.permanent_token}"}

    async def _revoke():
        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                resp = await client.delete(url, headers=headers)
                return resp.status_code
        except (httpx.ConnectError, httpx.TimeoutException):
            return None

    status = asyncio.run(_revoke())
    if status == 200 or status == 204 or status == 404:
        click.echo(f"Server revoke: ok (HTTP {status})")
    elif status is None:
        click.echo(
            "Server revoke: network unreachable. Clearing local "
            "keyring anyway — server-side reconciles via heartbeat-lost.",
            err=True,
        )
    else:
        click.echo(
            f"Server revoke: HTTP {status} (clearing local anyway).", err=True
        )

    _id.clear_paired()
    click.echo("Local keyring cleared. Re-pair with `haon-agent byoc pair`.")


# ── Browser runtime (Sprint 1F.4 — Studio) ──────────────────────────────


@cli.group("service")
def service_group() -> None:
    """Manage the haon-agent OS auto-start service (hotfix 0.5.1).

    Windows: registers a Scheduled Task that fires on user logon. No
    UAC prompt — the schtasks /SC ONLOGON with default user context
    runs at LIMITED elevation but is enough for the BYOC WSS client
    (no port-bind needed). Logs land in
    `%USERPROFILE%\\.haon\\logs\\agent.log`.

    Linux/macOS: deferred to 0.5.2 (systemd user unit + launchd plist
    respectively). Current command stubs print a clear "not yet
    supported on this platform" message instead of failing silently.

    Subcommands:
      install   — create the OS-level scheduled task
      uninstall — remove it
      status    — show whether it's installed + last run state
    """


_SERVICE_TASK_NAME = "HAON-Agent"


def _service_is_windows() -> bool:
    import platform
    return platform.system() == "Windows"


def _service_haon_agent_exe() -> str:
    """Resolve the haon-agent entry point for the scheduled task.

    Returns the venv Scripts/haon-agent.exe when available
    (install-miner.ps1 path) OR the bare 'haon-agent' string for PATH
    lookup (PyInstaller standalone install). The scheduled task action
    just runs the resolved string as a command-line.
    """
    import os
    import shutil

    # Prefer the per-user venv install (matches install-miner.ps1
    # layout at %USERPROFILE%\.haon\venv\Scripts\haon-agent.exe).
    home = os.environ.get("USERPROFILE") or os.path.expanduser("~")
    venv_exe = os.path.join(home, ".haon", "venv", "Scripts", "haon-agent.exe")
    if os.path.isfile(venv_exe):
        return venv_exe
    # Fall back to PATH lookup.
    which = shutil.which("haon-agent") or shutil.which("haon-agent.exe")
    if which:
        return which
    # Last resort — bare name, schtasks will resolve via PATH at task run.
    return "haon-agent"


@service_group.command("install")
def service_install() -> None:
    """Register the haon-agent BYOC connect loop as a per-user
    auto-start task. Idempotent — re-running replaces the existing
    task without prompting (schtasks /F).

    Win: `schtasks /Create /TN HAON-Agent /SC ONLOGON /TR "<exe> byoc
    connect" /F`. No admin / UAC needed (user-scope task).
    """
    if not _service_is_windows():
        click.echo(
            "service install: only supported on Windows in 0.5.1. "
            "Linux (systemd --user) + macOS (launchd) coming in 0.5.2.",
            err=True,
        )
        raise SystemExit(2)

    import subprocess

    exe = _service_haon_agent_exe()
    tr = f'"{exe}" byoc connect'
    try:
        proc = subprocess.run(
            [
                "schtasks", "/Create",
                "/TN", _SERVICE_TASK_NAME,
                "/SC", "ONLOGON",
                "/TR", tr,
                "/RL", "LIMITED",
                "/F",
            ],
            capture_output=True,
            text=True,
            timeout=30,
        )
    except FileNotFoundError:
        click.echo("schtasks not found on PATH. Are you on Windows?", err=True)
        raise SystemExit(2) from None
    if proc.returncode != 0:
        click.echo(
            f"schtasks failed (exit {proc.returncode}):\n"
            f"  stdout: {proc.stdout.strip()}\n"
            f"  stderr: {proc.stderr.strip()}",
            err=True,
        )
        raise SystemExit(2)
    click.echo(f"Installed task '{_SERVICE_TASK_NAME}' (runs at logon).")
    click.echo(f"  Action: {tr}")
    click.echo(
        "Will start at next logon. To start immediately:\n"
        f"  schtasks /Run /TN {_SERVICE_TASK_NAME}"
    )


@service_group.command("uninstall")
def service_uninstall() -> None:
    """Remove the auto-start task. Idempotent — no-op if not installed."""
    if not _service_is_windows():
        click.echo(
            "service uninstall: only supported on Windows in 0.5.1.",
            err=True,
        )
        raise SystemExit(2)
    import subprocess

    try:
        proc = subprocess.run(
            ["schtasks", "/Delete", "/TN", _SERVICE_TASK_NAME, "/F"],
            capture_output=True,
            text=True,
            timeout=30,
        )
    except FileNotFoundError:
        click.echo("schtasks not found on PATH.", err=True)
        raise SystemExit(2) from None
    if proc.returncode != 0:
        # schtasks returns non-zero when the task didn't exist — surface
        # as a friendly "nothing to do" rather than an error.
        if "ERROR: The system cannot find" in (proc.stderr or "") or "ERROR:" in (proc.stderr or ""):
            click.echo(
                f"Task '{_SERVICE_TASK_NAME}' not installed. Nothing to do."
            )
            return
        click.echo(
            f"schtasks failed (exit {proc.returncode}):\n  {proc.stderr.strip()}",
            err=True,
        )
        raise SystemExit(2)
    click.echo(f"Removed task '{_SERVICE_TASK_NAME}'.")


@service_group.command("status")
def service_status() -> None:
    """Show whether the auto-start task is installed + its last run
    state.

    Win: parses `schtasks /Query /TN HAON-Agent /FO LIST /V`. Returns
    a human-readable bullet list. Exit 0 if installed (regardless of
    last run state); exit 1 if not installed.
    """
    if not _service_is_windows():
        click.echo(
            "service status: only supported on Windows in 0.5.1.",
            err=True,
        )
        raise SystemExit(2)
    import subprocess

    try:
        proc = subprocess.run(
            [
                "schtasks", "/Query",
                "/TN", _SERVICE_TASK_NAME,
                "/FO", "LIST", "/V",
            ],
            capture_output=True,
            text=True,
            timeout=30,
        )
    except FileNotFoundError:
        click.echo("schtasks not found on PATH.", err=True)
        raise SystemExit(2) from None
    if proc.returncode != 0:
        click.echo(f"Task '{_SERVICE_TASK_NAME}' is NOT installed.")
        click.echo("Run `haon-agent service install` to enable auto-start.")
        raise SystemExit(1)

    # Light parse — surface a few relevant LIST fields without
    # re-implementing the entire schtasks output schema.
    fields_of_interest = (
        "Status:", "Last Run Time:", "Last Result:", "Next Run Time:",
        "Run As User:", "Task To Run:",
    )
    click.echo(f"Task '{_SERVICE_TASK_NAME}' is installed:")
    for line in proc.stdout.splitlines():
        line_stripped = line.strip()
        if any(line_stripped.startswith(f) for f in fields_of_interest):
            click.echo(f"  {line_stripped}")


@cli.group("browser")
def browser_group() -> None:
    """Studio browser sharing — share a Chrome profile via WebRTC.

    The `launch` subcommand spawns a dedicated Chrome instance with a
    persistent profile (separate from your everyday Chrome), connects
    to the broker, and waits for coworker sessions initiated through
    haonhub.com.

    Profile is FRESH on first launch — Chrome treats the empty profile
    dir as a new user, so there are no inherited cookies/history from
    your main Chrome. After first login (e.g. into Gemini Ultra) the
    profile persists across `browser launch` invocations.
    """


@browser_group.command("launch")
@click.option(
    "--profile",
    "profile_name",
    required=True,
    help="Profile name (e.g. gemini-ultra). Stored at ~/.haon/browser_profiles/<name>.",
)
@click.option(
    "--debug-port",
    default=9222,
    show_default=True,
    type=int,
    help="Chrome DevTools port. Default is fine unless 9222 is in use.",
)
@click.option(
    "--start-url",
    default=None,
    help="Open this URL on launch (e.g. https://gemini.google.com).",
)
@click.option(
    "--headless",
    is_flag=True,
    default=False,
    help="Run Chrome headless. Default OFF — Studio is interactive.",
)
def browser_launch(
    profile_name: str,
    debug_port: int,
    start_url: str | None,
    headless: bool,
) -> None:
    """Launch Chrome + connect to broker for Studio coworker sessions.

    The first time you run this with a new profile name, Chrome opens
    a brand-new session — log into whatever premium tool you want to
    share (Gemini Ultra, Veo, ChatGPT Pro, etc). On subsequent runs,
    cookies persist so the session is already logged in.

    Example:
        $ haon-agent browser launch --profile gemini-ultra --start-url https://gemini.google.com

    Press Ctrl-C to stop the agent + close Chrome.
    """
    from haon_agent.byoc import identity as _byoc_identity
    from haon_agent.byoc.runtime.browser import launcher

    _configure_logging("info")

    # Verify BYOC pair state, NOT marketplace API key. `credentials.load()`
    # reads the legacy marketplace `haon_xxx` API key — completely
    # unrelated to BYOC pairing. The BYOC `permanent_token` lives in
    # the OS keyring under a different service name, accessed via
    # `byoc.identity.load_paired()`. Caught in phase-1 smoke
    # (2026-05-19): users saw spurious "Not paired" even after a
    # successful `byoc pair`.
    if _byoc_identity.load_paired() is None:
        click.echo(
            "Not paired. Run `haon-agent byoc pair <code>` first.", err=True
        )
        raise SystemExit(2)

    async def _run() -> None:
        # Phase 1 — just launch Chrome and wait. Subsequent phases will
        # wire this into the broker WSS + signaling + WebRTC encoder.
        try:
            launched = await launcher.launch_chrome(
                profile_name,
                debug_port=debug_port,
                headless=headless,
                start_url=start_url,
            )
        except launcher.ChromeNotFoundError as exc:
            click.echo(f"Chrome not found: {exc}", err=True)
            raise SystemExit(3) from None
        except launcher.ChromeStartupError as exc:
            click.echo(f"Chrome failed to start: {exc}", err=True)
            raise SystemExit(4) from None

        click.echo(
            f"Chrome ready — profile={profile_name}, port={debug_port}.\n"
            f"DevTools WS: {launched.devtools_ws_url[:60]}...\n"
            f"Phase 1: WebRTC streaming NOT yet wired. "
            "Phases 2-4 land in subsequent PRs.\n"
            "Press Ctrl-C to stop."
        )

        # Block until the user terminates OR Chrome dies. Phase 4 will
        # replace this with the actual signaling + WebRTC pipeline.
        try:
            while launched.process.poll() is None:
                await asyncio.sleep(1)
            click.echo("Chrome exited.", err=True)
        except KeyboardInterrupt:
            click.echo("\nStopping Chrome...", err=True)
        finally:
            launcher.terminate_chrome(launched)

    try:
        asyncio.run(_run())
    except KeyboardInterrupt:
        # asyncio.run already handles CancelledError; this catches the
        # Windows path where Ctrl-C arrives before _run() entered.
        pass


# ── PyInstaller entry point ─────────────────────────────────────────────
#
# When this module is bundled by PyInstaller via `pyinstaller -c
# haon_agent/cli.py`, the script is executed as `__main__` but
# PyInstaller doesn't auto-invoke the click group — only the
# decorators register on the cli object. Without this guard the
# bundled binary exits 0 silently because cli() is never called
# (caught at smoke 2026-05-17 on byoc-agent-v1.0.0-r6).
#
# When installed via `pip install -e .` the `[project.scripts]`
# entry point synthesises a wrapper that imports + calls cli(), so
# this guard is unused on the pip path. Keeping it here is harmless
# in that case (the import-as-module path never sets __name__ to
# "__main__").
if __name__ == "__main__":
    cli()
