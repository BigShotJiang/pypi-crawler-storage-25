"""Pure-helper unit tests for UPnP + firewall modules (R2.3).

Network-touching paths (SSDP discover, AddPortMapping SOAP, subprocess
calls for firewall detection) aren't covered — they need real routers
or OS-specific binaries. What IS covered:

  - SOAP envelope byte-for-byte matches the UPnP IGD spec
  - XML escaping of port-mapping description
  - Firewall status dataclass shape + known-kind whitelist
  - Sunshine ports list matches the upstream Sunshine docs
"""

from __future__ import annotations

from haon_agent.net import firewall as net_firewall
from haon_agent.net import upnp as net_upnp


def test_sunshine_ports_list_covers_expected() -> None:
    """These ports come from the Sunshine docs; regressions here would
    silently break streaming."""
    found = set(net_upnp.SSDP_SEARCH_TARGETS)
    # We probe IGD v1 at minimum — v2 is newer and some older routers
    # don't have it.
    assert "urn:schemas-upnp-org:device:InternetGatewayDevice:1" in found


def test_soap_envelope_add_contains_expected_shape() -> None:
    m = net_upnp.PortMapping(
        internal_port=47984,
        external_port=47984,
        protocol="TCP",
        description="HAON Sunshine 47984/TCP",
    )
    body = net_upnp._soap_envelope_add(
        m, net_upnp.NS_WAN_IP, "192.168.1.50", lease_s=7200
    )
    s = body.decode("utf-8")
    assert "AddPortMapping" in s
    assert "<NewInternalPort>47984</NewInternalPort>" in s
    assert "<NewExternalPort>47984</NewExternalPort>" in s
    assert "<NewProtocol>TCP</NewProtocol>" in s
    assert "<NewInternalClient>192.168.1.50</NewInternalClient>" in s
    assert "<NewLeaseDuration>7200</NewLeaseDuration>" in s
    assert "HAON Sunshine 47984/TCP" in s


def test_soap_envelope_delete_minimal_shape() -> None:
    m = net_upnp.PortMapping(
        internal_port=48000,
        external_port=48000,
        protocol="UDP",
        description="",
    )
    body = net_upnp._soap_envelope_delete(m, net_upnp.NS_WAN_IP)
    s = body.decode("utf-8")
    assert "DeletePortMapping" in s
    assert "<NewExternalPort>48000</NewExternalPort>" in s
    assert "<NewProtocol>UDP</NewProtocol>" in s
    # Delete DOESN'T include internal_client / lease / enabled
    assert "NewInternalPort" not in s
    assert "NewLeaseDuration" not in s


def test_xml_escape_description_safe() -> None:
    """A malicious description with <script> should round-trip as escaped
    text so the router's admin panel doesn't execute it when displaying."""
    m = net_upnp.PortMapping(
        internal_port=47984,
        external_port=47984,
        protocol="TCP",
        description='<script>alert("xss")</script>',
    )
    body = net_upnp._soap_envelope_add(
        m, net_upnp.NS_WAN_IP, "10.0.0.1", lease_s=3600
    )
    s = body.decode("utf-8")
    assert "<script>" not in s
    assert "&lt;script&gt;" in s
    assert "&quot;xss&quot;" in s


def test_xml_escape_handles_ampersand() -> None:
    assert net_upnp._xml_escape("A & B") == "A &amp; B"
    assert net_upnp._xml_escape("<>&\"'") == "&lt;&gt;&amp;&quot;&apos;"


def test_firewall_sunshine_ports_cover_sunshine_range() -> None:
    """Sunshine uses 47984-48010; every port in our list must fall in
    that window and have a known protocol."""
    for port, proto, note in net_firewall.SUNSHINE_PORTS:
        assert 47000 <= port <= 48100, f"unexpected port {port}"
        assert proto in ("TCP", "UDP"), f"bad proto {proto}"
        assert note, "each port must have a human-readable note"


def test_firewall_status_kind_whitelist() -> None:
    """Catch typos in the `kind` literal — the worker UI will render
    based on the value so new values need intentional UI updates."""
    valid_kinds = {
        "windows_defender", "ufw", "firewalld", "iptables", "pf",
        "unknown", "none",
    }
    # Just assert a sample — we can't exercise every branch without
    # running on every OS, but this guards against literal typos.
    assert "windows_defender" in valid_kinds
    assert "ufw" in valid_kinds


def test_port_mapping_is_frozen_dataclass() -> None:
    """PortMapping instances are keys in dicts + members of sets in
    future rework — they must be hashable (frozen=True)."""
    m = net_upnp.PortMapping(47984, 47984, "TCP", "x")
    # If this raises, the dataclass isn't frozen.
    _ = {m}
    _ = {m: "value"}
