# haon-agent

The miner-side agent for the **HAON PowerHub** distributed GPU marketplace.
Run this on a machine with a GPU, register with the marketplace, and
earn credit every time a worker rents your compute time.

- **Website**: <https://haon.run>
- **Quickstart**: <https://haon.run/docs/miner-install-quickstart.md>
- **Supported OS**: macOS, Linux, Windows 10+ (Python 3.11+)

---

## One-command install

### macOS / Linux
```bash
curl -sSL https://haon.run/install-miner.sh | bash
```

### Windows (PowerShell)
```powershell
iwr -useb https://haon.run/install-miner.ps1 | iex
```

Either one-liner installs this package into a per-user venv at
`~/.haon/venv` (no admin required), exposes the `haon-agent` CLI, and
launches the pairing wizard.

---

## Manual install (prefer the one-liner for non-developers)

```bash
pip install haon-agent
haon-agent pair         # email + password → marketplace registration
haon-agent run          # starts the agent, heartbeats begin
```

Configuration lands in `~/.haon/agent.toml`; the API key is stored in
your OS keyring (with a 0600 file fallback).

---

## What the agent does

- Probes your hardware (CPU / RAM / GPU via `nvidia-smi`).
- Registers the machine with the HAON API and mints a scoped API key.
- Holds a WebSocket to the HAON broker (outbound, NAT-friendly).
- When a worker opens a session against your machine, the agent pairs
  the tunnel + starts the requested runtime container (Ollama, ComfyUI,
  custom HTTP).
- Emits usage ticks every 10 seconds; the server turns ticks into
  earnings in your wallet.

Nothing the agent does touches ports on your side — all traffic is
outbound WebSocket over TLS to `broker.haon.run`. You can run it
behind NAT, corporate firewalls, or whatever.

---

## Supported runtimes (alpha)

| Runtime | Status | Notes |
|---|---|---|
| `echo` | ✅ Works everywhere | CPU-only smoke test |
| `ollama` | 🚧 Docker-based (today) / native (next) | LLM inference |
| `comfyui` | 🚧 Docker-based | Image / video diffusion |
| `custom_http` | 🚧 Docker-based | Bring your own HTTP server |

Docker-based runtimes require Docker Desktop (Windows/macOS) or
Docker Engine (Linux) + the NVIDIA Container Toolkit if you want GPU
passthrough. The pairing wizard does not yet auto-install Docker — do
that step yourself before running compute-heavy runtimes.

---

## Uninstall

Everything the installer writes lives under `~/.haon`:

```bash
haon-agent logout       # clears credentials from the keyring
rm -rf ~/.haon          # removes the venv + config
```

No registry edits on Windows, no systemd unit on Linux.

---

## Security + privacy posture

- All API traffic is TLS 1.2+. Self-signed certs are rejected.
- Refresh tokens are rotated on every use (single-use).
- The agent never executes arbitrary code from workers — runtimes are
  explicit runtime containers you opt into.
- No telemetry beyond the heartbeats + usage ticks that the marketplace
  needs for billing. Source is auditable — this package is published
  from the same git history as the server.

Report security issues to `alpha@haon.run`.

---

## License

MIT. See `LICENSE` in the source repository.
