def erfc(a):
    """
    The complex error function that is required for the determination of the excess ground attenuation.

    a : complex
        the independent variable to determine the complex error function value.

    returns : complex
        the value of the complex error function at a

    Remarks:
    2022-11-29 - FSM - Running the F-35 A data suggests that there may be instances where the calculation of P2 and
    Q2 may result in Infinite/NaN values
    """
    from numpy import sin, cos, pi, exp, isinf

    if isinstance(a, complex):
        x = a.real
        y = a.imag
        rho2 = a ** 2
        if x > 6.0 or y > 6.0:
            return complex(0, 1) * a * (0.5124242 / (rho2 - 0.2752551) + 0.05176536 / (rho2 - 2.724745))
        else:
            if x > 3.9 or y > 3.0:
                w = 0.4613135 / (rho2 - 0.1901635)
                w += (0.09999216 / (rho2 - 1.7844927))
                w += (0.002883894 / (rho2 - 5.5253437))
                w *= (complex(0, 1) * a)
                return w
            else:
                h = 0.8
                A = cos(2 * x * y)
                B = sin(2 * x * y)
                C = exp(-2 * y * pi / h) - cos(2 * x * pi / h)
                D = sin(2 * x * pi / h)
                P2 = 2.0 * exp(-(x * x + (2.0 * y * pi / h) - y * y)) * ((A * C - B * D) /
                                                                         (C * C + D * D))
                Q2 = 2.0 * exp(-(x * x + (2.0 * y * pi / h) - y * y)) * ((A * D + B * C) /
                                                                         (C * C + D * D))

                if isinf(P2) or isinf(Q2):
                    raise ValueError(
                        "There is an issue determining the correct values for the curve fit for the "
                        "complex error function"
                        )

                H = 0
                K = 0
                for n in range(1, 5):
                    H += (2.0 * y * h / pi) * (exp(-n * n * h * h) * (y * y + x * x + n * n * h * h)) / (
                            ((y * y - x * x + n * n * h * h) ** 2.0) + 4 * y * y * x * x)
                    K += (2.0 * x * h / pi) * (exp(-n * n * h * h) * (y * y + x * x - n * n * h * h)) / (
                            ((y * y - x * x + n * n * h * h) ** 2.0) + 4 * y * y * x * x)
                H += h * y / (pi * (y * y + x * x))
                K += h * x / (pi * (y * y + x * x))

                if y == pi / h:
                    H = H + 0.5 * P2
                    K = K - 0.5 * Q2
                elif y < (pi / h):
                    H = H + P2
                    K = K - Q2
                return complex(H, K)

def yml(l, m, polar, azimuthal):
    """
    Calculate the normalized spherical harmonics for the provided order (l) and power (m) at the provided angle set.
    This function was replaced with the scipy function for the calculation of the spherical harmonics.

    l : int
        the order of the series
    m : int
        the power of the series
    polar : double (units: radians)
        the polar angle of the spherical harmonics
    azimuthal : double (units: radians)
        the azimuthal angle of the spherical harmonics

    returns : complex
        the values of the spherical harmonics at these angles, order and power.

    20220329 - FSM - Refactored the calculation of the angles that are used within the determination of the
        spherical harmonic value
    """

    from scipy.special import sph_harm
    from batts_measurable_objects.measurables import Angle

    if isinstance(azimuthal, Angle):
        az_angle_radians = azimuthal.radians
    elif isinstance(azimuthal, tuple):
        if isinstance(azimuthal[0], Angle):
            az_angle_radians = azimuthal[0].radians
        else:
            az_angle_radians = azimuthal[0]
    else:
        az_angle_radians = azimuthal

    if isinstance(polar, Angle):
        pol_angle_radians = polar.radians
    elif isinstance(polar, tuple):
        if isinstance(polar[0], Angle):
            pol_angle_radians = polar[0].radians
        else:
            pol_angle_radians = polar[0]
    else:
        pol_angle_radians = polar
    return sph_harm(m, l, az_angle_radians, pol_angle_radians)