import numpy as np
from numpy import zeros, linalg, asarray, array

"""
The polyfit/polyval function implement a solution that relies on the singular value decomposition on the coefficient
matrix, which have caused issues on certain matricies that are close to a singular value (determinant close to zero).
These functions implement the least-squares regression to construct the coefficient matrix and determine the 
coefficients in a more direct and manual way.
"""


def regression(x, y, order):
    """
    Determine the polynomial regression for the set of data in x and y

    x : double, array-like
        the independent variables
    y : double, array-like
        the dependent variables
    order : int
        the maximum order of the polynomial

    returns : double, array-like
        The list of coefficients ordered from the smallest to largest magnitude of the polynomial coefficients, i.e.
        the c[0] coefficients corresponds with x**0 term.
    """

    z = zeros(shape=(order + 1, order + 1))

    #   Build the matrix that forms the L.H.S. of the matrix inversion equation

    for row in range(order + 1):
        for col in range(order + 1):
            for index in range(len(x)):
                val = x[index] ** (row + col)
                z[row, col] += val

    #   Form the vector that is the R.H.S. of the matrix inversion equation

    a = zeros((order + 1,))

    for row in range(order + 1):
        for index in range(len(y)):
            val = y[index] * x[index] ** row
            a[row] += val

    #   Compute the coefficients as the inversion of Z and multiplication with a

    c = linalg.inv(z).dot(a)

    return c


def polynomial_value(c, x):
    """
    Determine the value of hte polynomial curve fit based on the coefficients that were returned with the regression
    function

    c : double, array-like
        The collection of coefficients that were determined with regression
    x : double, possible array-like

    returns : double, possible array-like
        the values of the polynomial at the provided x values
    """
    c = asarray(c)
    c = c.flatten()

    if isinstance(x, float):
        y = 0

        for i in range(len(c)):
            y += c[i] * x ** i

        return y

    if isinstance(x, list):
        x = array(x)

    if isinstance(x, np.ndarray) or isinstance(x, list):
        y = zeros(x.shape)

        for j in range(len(x)):

            for i in range(len(c)):
                y[j] += c[i] * x[j] ** i

        return y
