import numpy as np
from scipy.special import erf, erfinv

"""
These classes and functions provide the ability to fit a variety of functions to the provided data. The ErfFitParameters
also provides the ability to invert the function and determine the x-value that produces a specific y-value. These 
classes map to the C# code, though the SciPy.optimize.curve_fit function can also produce the coefficients, these 
functions reproduce the coefficients in a manual way for the three functions implemented for the auditory detection.
"""


class ErfFitParameters:
    def __init__(self, a: float = 0, b: float = 0, c: float = 0, d: float = 0, n: int = 0, sigma: float = 0):
        self._amplitude = a
        self._horizontal_offset = b
        self._vertical_offset = d
        self._scale = c
        self._iteration_count = n
        self._uncertainty = sigma

    @property
    def amplitude(self):
        return self._amplitude

    @amplitude.setter
    def amplitude(self, value):
        self._amplitude = value

    @property
    def horizontal_offset(self):
        return self._horizontal_offset

    @horizontal_offset.setter
    def horizontal_offset(self, value):
        self._horizontal_offset = value

    @property
    def vertical_offset(self):
        return self._vertical_offset

    @vertical_offset.setter
    def vertical_offset(self, value):
        self._vertical_offset = value

    @property
    def scale(self):
        return self._scale

    @scale.setter
    def scale(self, value):
        self._scale = value

    @property
    def iteration_count(self):
        return self._iteration_count

    @iteration_count.setter
    def iteration_count(self, value):
        self._iteration_count = value

    @property
    def uncertainty(self):
        return self._uncertainty

    @uncertainty.setter
    def uncertainty(self, value):
        self._uncertainty = value

    def value(self, x):
        return self.amplitude * erf((x-self.horizontal_offset) / self.scale) + self.vertical_offset

    def value_inverted(self, y):
        return self.horizontal_offset + self.scale * erfinv((y-self.vertical_offset)/self.amplitude)


def erf_fit(x, y, init_amp=1, init_vertical_offset=0, init_horizontal_offset=0, scale=2.5, max_iterations=100,
            error_tolerance=1e-8):
    """
    Determine a least squares regression curve fit to the input arrays through an error function of the form:
    y = a * erf((x-b)/c)+d

    x : double, array-like
        the independent variable list
    y : double, array-like
        the dependent variable list
    init_amp : double
        the initial guess for the amplitude of the error function (a)
    init_vertical_offset : double
        the initial guess for the vertical offset of the error function (d)
    init_horizontal_offset : double
        the initial guess for the horizontal offset of the error function (b)
    scale : double
        the initial guess of the slope of scale of the error function (b)
    max_iterations : double or int
        the maximum number of iterations for the looping before the algorithm terminates
    error_tolerance : double
        the required minimum error prior to the termination of the algorithm

    returns : tuple
        the coefficients (a, b, c, d), iteration count, and error
    """

    if isinstance(x, list):
        x = np.array(x)
    if isinstance(y, list):
        y = np.array(y)

    #   Set the initial conditions for the least squares regression
    current_error = 1000
    n = 0
    a = init_amp
    b = init_horizontal_offset
    c = scale
    d = init_vertical_offset

    #   A collection of adjustments to be made to the coefficients.  This is the same size as the number of unknown
    #   coefficients.
    gradient = np.zeros(shape=(len(x), 4))

    #   The difference in actual function using the current coefficients and the curve fit
    residuals = [0 for num in x]

    #   The current evaluation of the error function at the given independent values using the previous coefficients
    current_approximation = [0 for num in x]

    #   Loop until we either meet the maximum number of iterations or the error between the current and previous
    #   approximations is less than the error_tolerance
    while n < max_iterations and current_error > error_tolerance:

        #   Fill the gradient and current approximation values
        gradient[:, 0] = erf((x - b) / c)
        gradient[:, 1] = -(2 * a * np.exp(-(x - b)**2.0 / c / c) / np.sqrt(np.pi) / c)
        gradient[:, 2] = -(2 * a * (x - b) * np.exp(-(x - b)**2.0 / c / c)) / np.sqrt(np.pi) / c / c
        gradient[:, 3] = 1.0
        current_approximation = a * erf((x - b) / c) + d
        residuals = y - current_approximation

        # These may need to be dot operators, not multiplication. Is it point wise?
        grad_mul = gradient.transpose().dot(gradient)
        inverse = np.linalg.inv(grad_mul)
        pseudo_inverse = inverse.dot(gradient.transpose())
        delta_coefficients = pseudo_inverse.dot(residuals)
        current_error = abs(max(delta_coefficients))

        #   Adjust the coefficients
        a += delta_coefficients[0]
        b += delta_coefficients[1]
        c += delta_coefficients[2]
        d += delta_coefficients[3]

        #   Update the iteration count
        n += 1

    return ErfFitParameters(a, b, c, d, n - 1, current_error)


def gaussian_fit(x, y, initial_variance=0.1, initial_center=1, initial_amp=100, error_tolerance=1e-6,
                    max_iterations=100):
    """
    Using the Newton approximation start with the initial guesses for the output parameters and use least-squares
    regression to fit the data provided in the input arrays with a normal distribution (Guassian function): i.e.
    y = a * np.exp(-((x-b)**2)/c)

    x : double, array-like
        The collection of independent variables values
    y : double, array-like
        The collection of dependent variable values
    initial_variance : double, default value=0.1
        The initial width of the normal distribution
    initial_center : double, default value=1
        The initial location of the center of the normal distribution
    initial_amp : double, default value=100
        The initial amplitude of the normal distribution
    error_tolerance : double, default value=0.75
        The minimum different between the variables that results in the termination of the fitting
    max_iterations : double, default value=100
        The maximum number of iterations prior to the termination of the fitting

    returns a, b, c, iteration count, error
    """
    import sklearn.metrics as metrics

    #   Ensure that we are using arrays rather than lists
    if isinstance(x, list):
        x = np.array(x)
    if isinstance(y, list):
        y = np.array(y)

    #   Initialize the variables
    current_error = 1000
    iteration_count = 0
    a = initial_amp
    b = initial_center
    c = initial_variance

    #   Setup the arrays and matrices that will hold the data
    gradient = np.zeros(shape=(len(x), 3))

    #   Loop until either the error or iteration termination condition is reached
    while current_error > error_tolerance and iteration_count < max_iterations:

        #   Loop through the elements of the input array and build up the objects
        gradient[:, 0] = np.exp(-(x - b)**2.0 / c)
        gradient[:, 1] = (2 * a * (x - b) / c) * np.exp(-(b - x)**2 / c)
        gradient[:, 2] = ((a * (b - x)**2.0) / (c**2.0)) * np.exp(-(b - x)**2.0 / c)
        current_y = a * np.exp(-(x - b)**2.0 / c)
        residuals = y - current_y

        #   Determine the adjustments to the coefficients
        pseudo_inverse = np.linalg.pinv(gradient)
        delta_coefficients = pseudo_inverse.dot(residuals)
        current_error = np.mean(abs(residuals))
        a += delta_coefficients[0]
        b += delta_coefficients[1]
        c += delta_coefficients[2]

        #   Increment the iteration count
        iteration_count += 1

    return a, b, c, (iteration_count - 1), current_error


def gaussian_fit_with_floor(x, y, initial_variance=0.1, initial_center=1, initial_amp=100, initial_floor=10,
                            error_tolerance=1e-6, max_iterations=100):
    """
    Using the Newton approximation start with the initial guesses for the output parameters and use least-squares
    regression to fit the data provided in the input arrays with a normal distribution (Guassian function): i.e.
    y = a * np.exp(-((x-b)**2)/c) + d

    x : double, array-like
        The collection of independent variables values
    y : double, array-like
        The collection of dependent variable values
    initial_variance : double, default value=0.1
        The initial width of the normal distribution
    initial_center : double, default value=1
        The initial location of the center of the normal distribution
    initial_amp : double, default value=100
        The initial amplitude of the normal distribution
    initial_floor : double, default value=10
        The initial floor of the normal distribution
    error_tolerance : double, default value=0.75
        The minimum different between the variables that results in the termination of the fitting
    max_iterations : double, default value=100
        The maximum number of iterations prior to the termination of the fitting

    returns a, b, c, d, iteration count, error
    """

    if isinstance(x, list):
        x = np.array(x)
    if isinstance(y, list):
        y = np.array(y)

    #   Setup the present variables
    current_error = 1000
    iteration_count = 0
    a = initial_amp
    b = initial_center
    c = initial_variance
    d = initial_floor

    #   Create the objects that will hold the information regarding the values during the regression
    gradient = np.zeros(shape=(len(x), 4))

    #   Loop until the terminating conditions are reached
    while current_error > error_tolerance and iteration_count < max_iterations:
        gradient[:, 0] = np.exp(-(x - b)**2.0 / c)
        gradient[:, 1] = (2 * a * (x - b) / c) * np.exp(-(b - x)**2.0 / c)
        gradient[:, 2] = ((a * (b - x)**2.0) / (c**2.0)) * np.exp(-(b - x)**2.0 / c)
        gradient[:, 3] = 1.0

        current_y = a * np.exp(-(x - b)**2.0 / c) + d
        residuals = y - current_y

        #   Invert the matrices for the determination of the adjustments for the coefficients.
        pseudo_inverse = np.linalg.inv(gradient.transpose().dot(gradient)).dot(gradient.transpose())
        delta_coefficients = pseudo_inverse.dot(residuals)
        current_error = np.mean(abs(residuals))
        a += delta_coefficients[0]
        b += delta_coefficients[1]
        c += delta_coefficients[2]
        d += delta_coefficients[3]

    return a, b, c, d, (iteration_count - 1), current_error
