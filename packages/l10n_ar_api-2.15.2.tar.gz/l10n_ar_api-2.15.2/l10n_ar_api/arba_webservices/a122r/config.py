BASE_URLS = {
    'test': 'https://app2.test.arba.gov.ar/a122rSrv/api',
    'prod': 'https://app.arba.gov.ar/a122rSrv/api',
}

TOKEN_URLS = {
    'test': 'https://idp.test.arba.gov.ar/realms/ARBA/protocol/openid-connect/token',
    'prod': 'https://idp.arba.gov.ar/realms/ARBA/protocol/openid-connect/token',
}

CLIENT_IDS = {
    'test': 'A122RServicios',
    'prod': 'A122RServicios',
}

CLIENT_SECRETS = {
    'test': '44cqahkhERKtkkDGmcqrPApCMtez3XxT',
    'prod': 'k1pwZG4GdRrK88KpMfK6ACqav1SNDiCa',
}

TIMEOUT = 30

ACTIVITIES = {
    '1': 'Empresas Constructoras',
    '6': 'Régimen General de Retenciones',
    '10': 'Actividad Agropecuaria',
    '13': 'Municipalidad',
    '14': 'Estado Nacional',
    '15': 'Estado Provincial',
    '16': 'Seguros',
    '17': 'Financieras/Bancos',
    '20': 'Instituto Prov. de Lotería y Casinos',
    '23': 'Honorarios',
}
