from pathlib import Path

import polars as pl

from polars_units._config import config
from polars_units.core._units import Unit
from polars_units.extension import Quantity

_LIB = Path(__file__).parent


@pl.api.register_expr_namespace("unit")
class UnitExprNamespace:
    """Namespace for unit-related expression methods."""

    def __init__(self, expr: pl.Expr):
        self._expr = expr

    def symbol(self) -> pl.Expr:
        """Extract the unit symbol from a Quantity extension type column."""
        return pl.plugins.register_plugin_function(
            plugin_path=_LIB,
            function_name="unit_symbol",
            args=self._expr,
            is_elementwise=True,
        )

    def to(self, target: str | Unit | Quantity):
        """Convert a column to another unit of the same dimension."""

        if isinstance(target, str):
            target = config.registry.get(target)
        elif isinstance(target, Quantity):
            target = target.unit

        return pl.plugins.register_plugin_function(
            plugin_path=_LIB,
            function_name="unit_convert",
            args=self._expr,
            kwargs={"target": target.serialize()},
            is_elementwise=True,
        )

    def add(self, other: pl.Expr) -> pl.Expr:
        """Add two quantity columns, converting the right operand to the left
        operand unit if necessary."""
        return pl.plugins.register_plugin_function(
            plugin_path=_LIB,
            function_name="unit_add",
            args=[self._expr, other],
            is_elementwise=True,
        )

    def sub(self, other: pl.Expr) -> pl.Expr:
        """Subtract two quantity columns, converting the right operand to the left
        operand unit if necessary."""
        return pl.plugins.register_plugin_function(
            plugin_path=_LIB,
            function_name="unit_sub",
            args=[self._expr, other],
            is_elementwise=True,
        )

    def mul(self, other: pl.Expr) -> pl.Expr:
        """Multiply two quantity columns."""
        return pl.plugins.register_plugin_function(
            plugin_path=_LIB,
            function_name="unit_mul",
            args=[self._expr, other],
            is_elementwise=True,
        )

    def div(self, other: pl.Expr) -> pl.Expr:
        """Divide two quantity columns."""
        return pl.plugins.register_plugin_function(
            plugin_path=_LIB,
            function_name="unit_div",
            args=[self._expr, other],
            is_elementwise=True,
        )


@pl.api.register_series_namespace("unit")
class UnitSeriesNamespace:
    """Namespace for unit-related series methods."""

    def __init__(self, series: pl.Series):
        self._series = series

    def _apply_expr(self, method: str, *args: pl.Series) -> pl.Series:
        """Apply an expression method to the series and return the result as a
        new series. It only works for methods that only take series as
        arguments (or no argument at all)."""
        args = [pl.lit(series) for series in args]
        result_expr = getattr(pl.lit(self._series).unit, method)(*args)
        return pl.select(result_expr).to_series()

    def symbol(self) -> pl.Series:
        return self._apply_expr("symbol")

    def to(self, target) -> pl.Series:
        return pl.select(pl.lit(self._series).unit.to(target)).to_series()

    def add(self, other: pl.Series) -> pl.Series:
        return self._apply_expr("add", other)

    def sub(self, other: pl.Series) -> pl.Series:
        return self._apply_expr("sub", other)

    def mul(self, other: pl.Series) -> pl.Series:
        return self._apply_expr("mul", other)

    def div(self, other: pl.Series) -> pl.Series:
        return self._apply_expr("div", other)
