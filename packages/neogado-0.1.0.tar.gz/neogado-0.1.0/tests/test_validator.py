from src.validator import validate_rules, validate_chapter_rules, validate_search_rules


def test_validate_rules_success():
    """测试有效的目录规则能否返回 True"""
    raw_html = """
    <html>
        <div id="title">斗破苍穹</div>
        <div id="author">天蚕土豆</div>
        <div id="list">
            <dd><a href="/1.html">第一章</a></dd>
            <dd><a href="/2.html">第二章</a></dd>
        </div>
    </html>
    """
    rules = {
        "bookName": "#title",
        "author": "#author",
        "chapterList": "#list > dd",
        "chapterName": "a",
        "chapterUrl": "a",
    }
    assert validate_rules(raw_html, rules) is True


def test_validate_rules_failure():
    """测试无效的目录规则返回 False"""
    raw_html = "<html><body>empty</body></html>"
    rules = {
        "bookName": "#title",
        "author": "#author",
        "chapterList": "#list > dd",
        "chapterName": "a",
        "chapterUrl": "a",
    }
    assert validate_rules(raw_html, rules) is False


def test_validate_chapter_rules_success():
    """测试有效的正文规则及物理/正则脱水能否返回 True"""
    raw_html = """
    <html>
        <h1 id="title">第一章 陨落的天才</h1>
        <div id="content">
            <div class="ad-inline">请收藏本站</div>
            斗之气，三段！
            <p>望着测验魔石碑上面闪亮得甚至有些刺眼的五个大字，少年面无表情。</p>
            <p>支持正版阅读：https://www.test.com</p>
        </div>
    </html>
    """
    rules = {
        "chapterTitle": "#title",
        "content": "#content",
        "junkSelectors": [".ad-inline"],
        "junkRegex": ["支持正版阅读：https://www\\.test\\.com"],
    }
    # 模拟日志输出避免污染控制台，直接获取结果
    assert validate_chapter_rules(raw_html, rules) is True


def test_validate_chapter_rules_failure():
    """测试过短的正文导致验证失败返回 False"""
    raw_html = """
    <html>
        <h1 id="title">第一章</h1>
        <div id="content">
            短内容。
        </div>
    </html>
    """
    rules = {
        "chapterTitle": "#title",
        "content": "#content",
    }
    assert validate_chapter_rules(raw_html, rules) is False


def test_validate_search_rules_success():
    """测试有效的搜索规则能否返回 True"""
    raw_html = """
    <html>
        <ul class="result-list">
            <li>
                <div class="name"><a href="/book/1">完美世界</a></div>
                <div class="author">天蚕土豆</div>
                <img class="cover" src="/cover1.jpg" />
            </li>
            <li>
                <div class="name"><a href="/book/2">大主宰</a></div>
                <div class="author">天蚕土豆</div>
                <img class="cover" src="/cover2.jpg" />
            </li>
        </ul>
    </html>
    """
    rules = {
        "bookList": ".result-list > li",
        "bookName": ".name a",
        "author": ".author",
        "detailUrl": ".name a",
        "coverUrl": "img.cover",
    }
    assert validate_search_rules(raw_html, rules) is True
