import pytest
from dotenv import load_dotenv
from src.rule_generator import ensure_site_rules

# 加载 .env 环境变量，确保测试时能读取到 OPENAI_API_KEY
load_dotenv(override=True)

@pytest.mark.asyncio
async def test_real_catalog_rule_generation():
    """
    真实网络与 AI 测试：
    测试能否从真实的目录页 URL 成功生成 catalogRule
    """
    url = "https://www.bqg104.cc/#/book/197794/"
    
    # 强制刷新，确保不使用本地缓存，走真实的抓取和 AI 生成流程
    schema = await ensure_site_rules(url, force_refresh=True)
    
    # 我们只关心规则有没有成功生成出来
    assert schema is not None, "Schema 不应为空"
    assert schema.catalogRule is not None, "应该包含 catalogRule 字段"
    assert schema.catalogRule.chapterList != "", "catalogRule 不应该是空"

@pytest.mark.asyncio
async def test_real_content_rule_generation():
    """
    真实网络与 AI 测试：
    测试能否从真实的正文页 URL 成功生成 contentRule
    """
    url = "https://www.bqg104.cc/#/book/197794/1.html"
    
    # 强制刷新，确保不使用本地缓存，走真实的抓取和 AI 生成流程
    schema = await ensure_site_rules(url, force_refresh=True)
    
    # 我们只关心规则有没有成功生成出来
    assert schema is not None, "Schema 不应为空"
    assert schema.contentRule is not None, "应该包含 contentRule 字段"
    assert schema.contentRule.content != "", "contentRule 不应该是空"
