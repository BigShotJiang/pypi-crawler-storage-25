from src.distiller import distill_html


def test_distill_html_removes_unwanted_tags():
    raw_html = """
    <html>
        <head>
            <script>alert('test');</script>
            <style>body { color: red; }</style>
            <link rel="stylesheet" href="style.css" />
        </head>
        <body>
            <div id="content" class="main-text">
                <p>Hello World</p>
                <iframe src="ads.html"></iframe>
            </div>
            <footer style="display: none;">Copyright</footer>
        </body>
    </html>
    """
    clean_html = distill_html(raw_html)

    # Assert unwanted tags are removed
    assert "<script" not in clean_html
    assert "<style" not in clean_html
    assert "<link" not in clean_html
    assert "<iframe" not in clean_html

    # Assert structural text is retained
    assert "Hello World" in clean_html
    # "footer" tags are stripped in our distiller, so Copyright won't be there
    assert "Copyright" not in clean_html


def test_distill_html_removes_unwanted_attributes():
    raw_html = """
    <html>
        <body>
            <div id="chapter" class="content-box" data-url="/next" onclick="alert(1)" style="color: red;">
                <a href="/chapter1" title="Chapter 1" aria-label="First Chapter">Chapter 1</a>
            </div>
        </body>
    </html>
    """
    clean_html = distill_html(raw_html)

    # Assert allowed attributes are retained
    assert 'id="chapter"' in clean_html
    assert 'class="content-box"' in clean_html
    assert 'href="/chapter1"' in clean_html

    # Assert unwanted attributes are removed
    assert "data-url" not in clean_html
    assert "onclick" not in clean_html
    assert "style" not in clean_html
    assert "title" not in clean_html
    assert "aria-label" not in clean_html
