import asyncio
import logging
import argparse
import os
from dotenv import load_dotenv

# 定义全局配置目录
APP_DIR = os.path.expanduser("~/.neogado")
os.makedirs(APP_DIR, exist_ok=True)
ENV_PATH = os.path.join(APP_DIR, ".env")

# 加载全局 .env 环境变量并覆盖系统原有同名变量
load_dotenv(dotenv_path=ENV_PATH, override=True)

from src.rule_generator import ensure_site_rules

# 配置基础日志格式
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)


async def process_url(url: str):
    site_schema = await ensure_site_rules(url)
    if site_schema:
        print("\n\n" + "*" * 20 + " 终极输出：NeoGado 书源规则文件 " + "*" * 20)
        print(site_schema.model_dump_json(indent=2, exclude_none=True))


def main():
    parser = argparse.ArgumentParser(
        description="NeoGado: AI 驱动的小说规则生成与智能自愈引擎"
    )
    parser.add_argument(
        "--url",
        type=str,
        help="要生成规则的小说网站任意 URL (AI 将自动识别页面类型)",
    )
    parser.add_argument(
        "--tui",
        action="store_true",
        help="启动 NeoGado 沉浸式阅读器 (TUI)",
    )

    args = parser.parse_args()

    if args.tui or not args.url:
        # 启动 Textual TUI 界面
        from src.tui import NeoGadoApp
        app = NeoGadoApp(initial_url=args.url)
        app.run()
    else:
        # 只跑解析引擎
        asyncio.run(process_url(args.url))


if __name__ == "__main__":
    main()
