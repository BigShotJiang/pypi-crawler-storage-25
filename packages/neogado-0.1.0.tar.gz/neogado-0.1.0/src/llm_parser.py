import os
import re
import json
import logging
from urllib.parse import urlparse
from openai import AsyncOpenAI
from pydantic import ValidationError
from typing import Optional, Dict, Any

from src.models import TocRule, ContentRule, BookListRule, BookInfoRule, SearchActionRule
from src.storage import get_rule_filepath, load_local_rules, save_local_rules

# URL模式缓存
_url_pattern_cache: Dict[str, Dict[str, str]] = {}
# 数字ID匹配正则
_ID_PATTERN = re.compile(r'\d+')

logger = logging.getLogger(__name__)

logger = logging.getLogger(__name__)


async def generate_site_entry_rules_with_ai(clean_html: str) -> Dict[str, Any]:
    """
    大模型提取首页入口规则 (AI Site Entry Extraction)
    提取分类导航链接 (exploreUrls) 和搜索框交互规则 (searchActionRule)
    """
    logger.info(f"正在请求大模型分析【首页】结构并提取导航与搜索规则... (HTML长度: {len(clean_html)})")

    model_name = os.getenv("OPENAI_MODEL_NAME", "gpt-4o-mini")

    prompt = f"""
你是一个专业的网页解析助手。以下是一个小说网站**首页**的 HTML 结构（已精简）：

```html
{clean_html}
```

请仔细分析这个结构，提取出以下两部分信息：
1. 网站的分类导航或排行榜链接（如玄幻、修仙、全本、排行等）。
2. 网站的搜索框和搜索按钮的 CSS 选择器（用于自动化测试工具 Playwright 模拟输入和点击）。

你需要返回一个标准的 JSON 格式：
{{
  "exploreUrls": [
    {{"name": "分类名称(如: 玄幻小说)", "url": "对应的 href 链接"}}
  ],
  "searchActionRule": {{
    "searchInput": "搜索输入框的 CSS 选择器（如 input#wd 或 .search-input）",
    "searchButton": "搜索按钮的 CSS 选择器（如 button#search_btn 或 .search-btn）"
  }}
}}
注意：如果找不到搜索框，searchActionRule 可以为 null。
"""
    try:
        async with AsyncOpenAI(api_key=os.getenv("OPENAI_API_KEY"), base_url=os.getenv("OPENAI_BASE_URL")) as client:
            response = await client.chat.completions.create(
                model=model_name,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.1,
                response_format={"type": "json_object"},
            )
            content = response.choices[0].message.content
            if content:
                return json.loads(content)
            return {}
    except Exception as e:
        logger.error(f"大模型提取首页入口规则失败: {e}")
        return {}


async def generate_toc_rules_with_ai(clean_html: str) -> Optional[TocRule]:
    """大模型提取目录页规则"""
    logger.info(f"正在请求大模型分析网页结构生成目录规则... (HTML长度: {len(clean_html)})")
    model_name = os.getenv("OPENAI_MODEL_NAME", "gpt-4o-mini")

    prompt = f"""
你是一个专业的网页解析助手。以下是一个小说**目录页**的 HTML 结构（已精简）：
```html
{clean_html}
```
请提取章节列表的 CSS 选择器。返回标准 JSON：
{{
  "chapterList": "获取所有章节列表项（每一个独立章节）的 CSS 选择器（注意：不要选择包裹容器本身，要选择里面的每一个独立章节节点，以便能够匹配出所有章节元素）",
  "chapterName": "在 chapterList 单个节点内部，获取章节名称的 CSS 选择器（如果是它本身则填空字符串）",
  "chapterUrl": "在 chapterList 单个节点内部，获取章节链接的 CSS 选择器（如果是它本身则填空字符串）"
}}
"""
    try:
        async with AsyncOpenAI(api_key=os.getenv("OPENAI_API_KEY"), base_url=os.getenv("OPENAI_BASE_URL")) as client:
            response = await client.chat.completions.create(
                model=model_name, messages=[{"role": "user", "content": prompt}],
                temperature=0.1, response_format={"type": "json_object"},
            )
            if response.choices[0].message.content:
                return TocRule.model_validate_json(response.choices[0].message.content)
    except Exception as e:
        logger.error(f"大模型提取目录规则失败: {e}")
    return None


async def generate_content_rules_with_ai(clean_html: str) -> Optional[ContentRule]:
    """大模型提取正文规则与净化规则"""
    logger.info(f"正在请求大模型分析【正文页】结构并生成正文及净化规则... (HTML长度: {len(clean_html)})")
    model_name = os.getenv("OPENAI_MODEL_NAME", "gpt-4o-mini")

    prompt = f"""
你是一个专业的网页解析助手。以下是一个小说**正文阅读页**的 HTML 结构（已精简）：
```html
{clean_html}
```
请提取正文内容的 CSS 选择器，并识别可能的广告。返回标准 JSON：
{{
  "chapterTitle": "获取当前章节标题的 CSS 选择器",
  "content": "获取正文内容包裹容器的 CSS 选择器",
  "junkSelectors": ["广告节点、推荐阅读等无关标签的 CSS 选择器列表"],
  "junkRegex": ["防盗版乱码、网址水印等干扰字符串的正则表达式列表"]
}}
"""
    try:
        async with AsyncOpenAI(api_key=os.getenv("OPENAI_API_KEY"), base_url=os.getenv("OPENAI_BASE_URL")) as client:
            response = await client.chat.completions.create(
                model=model_name, messages=[{"role": "user", "content": prompt}],
                temperature=0.1, response_format={"type": "json_object"},
            )
            if response.choices[0].message.content:
                return ContentRule.model_validate_json(response.choices[0].message.content)
    except Exception as e:
        logger.error(f"大模型提取正文规则失败: {e}")
    return None


async def generate_book_list_rules_with_ai(clean_html: str) -> Optional[BookListRule]:
    """大模型提取书籍列表规则 (适用于搜索结果、分类页、排行榜)"""
    logger.info(f"正在请求大模型分析【书籍列表页】结构并生成提取规则... (HTML长度: {len(clean_html)})")
    model_name = os.getenv("OPENAI_MODEL_NAME", "gpt-4o-mini")

    prompt = f"""
你是一个专业的网页解析助手。以下是一个小说**书籍列表页**（可能是搜索结果、排行榜或分类发现页）的 HTML 结构（已精简）：
```html
{clean_html}
```
请提取书籍列表及其子项的 CSS 选择器。返回标准 JSON：
{{
  "bookList": "获取书籍列表项（代表每一本书的块）的 CSS 选择器",
  "bookName": "在 bookList 内部，获取书名的 CSS 选择器",
  "author": "在 bookList 内部，获取作者的 CSS 选择器",
  "detailUrl": "在 bookList 内部，获取小说详情页/目录页链接的 CSS 选择器",
  "coverUrl": "在 bookList 内部，获取封面的 CSS 选择器（如果没有请留空）",
  "intro": "在 bookList 内部，获取小说简介的 CSS 选择器（如果没有请留空）"
}}
"""
    try:
        async with AsyncOpenAI(api_key=os.getenv("OPENAI_API_KEY"), base_url=os.getenv("OPENAI_BASE_URL")) as client:
            response = await client.chat.completions.create(
                model=model_name, messages=[{"role": "user", "content": prompt}],
                temperature=0.1, response_format={"type": "json_object"},
            )
            if response.choices[0].message.content:
                return BookListRule.model_validate_json(response.choices[0].message.content)
    except Exception as e:
        logger.error(f"大模型提取书籍列表规则失败: {e}")
    return None


async def generate_book_info_rules_with_ai(clean_html: str) -> Optional[BookInfoRule]:
    """大模型提取详情页规则"""
    logger.info(f"正在请求大模型分析【详情页】结构并生成提取规则... (HTML长度: {len(clean_html)})")
    model_name = os.getenv("OPENAI_MODEL_NAME", "gpt-4o-mini")

    prompt = f"""
你是一个专业的网页解析助手。以下是一个小说**详情页**的 HTML 结构（已精简）：
```html
{clean_html}
```
请提取相应的 CSS 选择器。返回标准 JSON：
{{
  "bookName": "获取书名的 CSS 选择器",
  "author": "获取作者的 CSS 选择器",
  "coverUrl": "获取封面的 CSS 选择器",
  "intro": "获取小说简介的 CSS 选择器",
  "lastChapter": "获取最新章节名的 CSS 选择器（如果没有请留空）",
  "catalogUrl": "获取前往『目录页』链接的 CSS 选择器（如果目录和详情在同一页，可以为空）"
}}
"""
    try:
        async with AsyncOpenAI(api_key=os.getenv("OPENAI_API_KEY"), base_url=os.getenv("OPENAI_BASE_URL")) as client:
            response = await client.chat.completions.create(
                model=model_name, messages=[{"role": "user", "content": prompt}],
                temperature=0.1, response_format={"type": "json_object"},
            )
            if response.choices[0].message.content:
                return BookInfoRule.model_validate_json(response.choices[0].message.content)
    except Exception as e:
        logger.error(f"大模型提取详情页规则失败: {e}")
    return None


def _get_url_pattern(url: str) -> str:
    """提取URL的通用模式，将数字ID替换为通配符"""
    parsed = urlparse(url)
    path = parsed.path
    # 替换所有数字为{id}
    pattern = _ID_PATTERN.sub('{id}', path)
    # 保留查询参数的键，值替换为通配符
    if parsed.query:
        query_params = []
        for param in parsed.query.split('&'):
            if '=' in param:
                key, _ = param.split('=', 1)
                query_params.append(f"{key}={{*}}")
            else:
                query_params.append(param)
        pattern += '?' + '&'.join(query_params)
    return pattern


def _load_pattern_cache(domain: str) -> Dict[str, str]:
    """加载指定域名的URL模式缓存"""
    if domain in _url_pattern_cache:
        return _url_pattern_cache[domain]

    # 从规则文件加载
    rule_filepath = get_rule_filepath(f"https://{domain}")
    if os.path.exists(rule_filepath):
        rules = load_local_rules(rule_filepath)
        patterns = rules.get('urlPatterns', {})
        _url_pattern_cache[domain] = patterns
        return patterns

    _url_pattern_cache[domain] = {}
    return {}


def _save_pattern_cache(domain: str, pattern: str, page_type: str) -> None:
    """保存URL模式到缓存和规则文件"""
    patterns = _load_pattern_cache(domain)
    if pattern not in patterns:
        patterns[pattern] = page_type
        _url_pattern_cache[domain] = patterns

        # 保存到规则文件
        rule_filepath = get_rule_filepath(f"https://{domain}")
        rules = {}
        if os.path.exists(rule_filepath):
            rules = load_local_rules(rule_filepath)

        rules['urlPatterns'] = patterns
        save_local_rules(rule_filepath, rules)
        logger.info(f"已保存URL模式 [{pattern}] -> [{page_type}] 到规则文件")


async def classify_page_with_ai(clean_html: str, url: str = "") -> str:
    """大模型智能路由分类器（带URL模式缓存）"""
    if url:
        parsed = urlparse(url)
        domain = parsed.netloc
        path = parsed.path

        # 首页特例
        if path in ("", "/"):
            logger.info(f"URL {url} 只有域名，作为首页特例，直接识别为: [HOME]")
            return "home"

        # 尝试从模式缓存匹配
        patterns = _load_pattern_cache(domain)
        if patterns:
            url_pattern = _get_url_pattern(url)
            if url_pattern in patterns:
                page_type = patterns[url_pattern]
                logger.info(f"URL模式匹配命中 [{url_pattern}] -> [{page_type.upper()}]，无需调用AI")
                return page_type

    logger.info("正在请求大模型识别网页类型...")
    model_name = os.getenv("OPENAI_MODEL_NAME", "gpt-4o-mini")

    prompt = f"""
请分析以下精简后的 HTML 结构，判断它属于小说网站的哪种核心页面类型。
选项如下：
- "toc": 目录页（包含大量指向各个章节的链接列表）但是不包含正文的 有正文和目录的当正文
- "content": 正文页/阅读页（包含某一章的大段纯文本小说内容）
- "bookList": 书籍列表页（搜索结果、排行榜、分类页，包含多本匹配的小说列表）
- "bookInfo": 小说详情页（单本小说的简介、封面、作者信息）
- "home": 网站首页（包含各种分类导航、搜索框、推荐榜单）
- "unknown": 无法识别

HTML 结构预览：
```html
{clean_html[:3000]}
```
请严格返回 JSON 格式：
{{
  "page_type": "填入上述选项对应的英文单词"
}}
"""
    try:
        async with AsyncOpenAI(api_key=os.getenv("OPENAI_API_KEY"), base_url=os.getenv("OPENAI_BASE_URL")) as client:
            response = await client.chat.completions.create(
                model=model_name, messages=[{"role": "user", "content": prompt}],
                temperature=0.1, response_format={"type": "json_object"},
            )
            if response.choices[0].message.content:
                result = json.loads(response.choices[0].message.content)
                page_type = result.get("page_type", "unknown")
                logger.info(f"大模型识别出当前页面类型为: [{page_type.upper()}]")

                # 保存URL模式到缓存
                if url and page_type != "unknown":
                    parsed = urlparse(url)
                    domain = parsed.netloc
                    url_pattern = _get_url_pattern(url)
                    _save_pattern_cache(domain, url_pattern, page_type)

                return page_type
    except Exception as e:
        logger.error(f"大模型分类页面失败: {e}")
    return "unknown"
