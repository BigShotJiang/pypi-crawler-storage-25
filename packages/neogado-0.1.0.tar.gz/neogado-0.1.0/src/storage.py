import json
import os
import logging
import sqlite3
from urllib.parse import urlparse
from dotenv import load_dotenv

# 定义全局应用数据目录 (例如: ~/.neogado)
APP_DIR = os.path.expanduser("~/.neogado")
os.makedirs(APP_DIR, exist_ok=True)

# 加载全局目录下的 .env 文件
env_path = os.path.join(APP_DIR, '.env')
if os.path.exists(env_path):
    load_dotenv(env_path, override=True)
else:
    # 兜底：尝试加载当前运行目录下的 .env
    load_dotenv(override=True)

# 配置全局日志，将日志写入到 ~/.neogado/neogado.log 文件中
# 使用 force=True 强制覆盖 Textual 或其他库可能已经设置的日志配置
logging.basicConfig(
    filename=os.path.join(APP_DIR, 'neogado.log'),
    filemode='a',
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO,
    force=True
)
logger = logging.getLogger(__name__)

# 数据库路径更新为全局目录下的 cache.db
DB_PATH = os.path.join(APP_DIR, "cache.db")

def init_db():
    """初始化 SQLite 缓存数据库"""
    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.cursor()
        # 目录缓存表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS cache_catalog (
                url TEXT PRIMARY KEY,
                data TEXT
            )
        ''')
        # 章节正文缓存表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS cache_chapter (
                url TEXT PRIMARY KEY,
                content TEXT
            )
        ''')
        # 书籍详情缓存表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS cache_book_info (
                url TEXT PRIMARY KEY,
                data TEXT
            )
        ''')
        # 历史记录表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS cache_history (
                url TEXT PRIMARY KEY,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        conn.commit()

# 模块加载时自动初始化数据库
init_db()

def get_rule_filepath(url: str) -> str:
    """根据 URL 获取对应的本地规则文件路径"""
    if not url:
        domain = "unknown_domain"
    else:
        domain = urlparse(url).netloc
        if domain.startswith("www."):
            domain = domain[4:]
    
    # 规则文件夹更新为全局目录下的 rules 文件夹
    rules_dir = os.path.join(APP_DIR, "rules")
    os.makedirs(rules_dir, exist_ok=True)
    
    return os.path.join(rules_dir, f"{domain}.json")


def load_local_rules(filepath: str) -> dict:
    """从本地加载已存在的规则"""
    if os.path.exists(filepath):
        try:
            with open(filepath, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            logger.warning(f"读取本地规则文件失败 {filepath}: {e}")
    return {}


def save_local_rules(filepath: str, rules: dict):
    """保存规则到本地"""
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(rules, f, ensure_ascii=False, indent=2)


def get_cached_catalog(url: str) -> list:
    """获取缓存的目录"""
    try:
        with sqlite3.connect(DB_PATH) as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT data FROM cache_catalog WHERE url = ?', (url,))
            row = cursor.fetchone()
            if row:
                return json.loads(row[0])
    except Exception as e:
        logger.warning(f"读取目录缓存失败: {e}")
    return None


def set_cached_catalog(url: str, data: list):
    """设置目录缓存"""
    try:
        with sqlite3.connect(DB_PATH) as conn:
            cursor = conn.cursor()
            cursor.execute(
                'REPLACE INTO cache_catalog (url, data) VALUES (?, ?)', 
                (url, json.dumps(data, ensure_ascii=False))
            )
            conn.commit()
    except Exception as e:
        logger.warning(f"写入目录缓存失败: {e}")


def get_cached_chapter(url: str) -> str:
    """获取缓存的章节正文"""
    try:
        with sqlite3.connect(DB_PATH) as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT content FROM cache_chapter WHERE url = ?', (url,))
            row = cursor.fetchone()
            if row:
                return row[0]
    except Exception as e:
        logger.warning(f"读取章节缓存失败: {e}")
    return None


def set_cached_chapter(url: str, content: str):
    """设置章节正文缓存"""
    try:
        with sqlite3.connect(DB_PATH) as conn:
            cursor = conn.cursor()
            cursor.execute(
                'REPLACE INTO cache_chapter (url, content) VALUES (?, ?)',
                (url, content)
            )
            conn.commit()
    except Exception as e:
        logger.warning(f"写入章节缓存失败: {e}")


def get_cached_book_info(url: str) -> dict:
    """获取缓存的书籍详情"""
    try:
        with sqlite3.connect(DB_PATH) as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT data FROM cache_book_info WHERE url = ?', (url,))
            row = cursor.fetchone()
            if row:
                return json.loads(row[0])
    except Exception as e:
        logger.warning(f"读取书籍详情缓存失败: {e}")
    return None


def set_cached_book_info(url: str, data: dict):
    """设置书籍详情缓存"""
    try:
        with sqlite3.connect(DB_PATH) as conn:
            cursor = conn.cursor()
            cursor.execute(
                'REPLACE INTO cache_book_info (url, data) VALUES (?, ?)',
                (url, json.dumps(data, ensure_ascii=False))
            )
            conn.commit()
    except Exception as e:
        logger.warning(f"写入书籍详情缓存失败: {e}")


def add_history(url: str):
    """添加历史记录"""
    try:
        with sqlite3.connect(DB_PATH) as conn:
            cursor = conn.cursor()
            cursor.execute(
                'REPLACE INTO cache_history (url, timestamp) VALUES (?, CURRENT_TIMESTAMP)', 
                (url,)
            )
            conn.commit()
    except Exception as e:
        logger.warning(f"写入历史记录失败: {e}")


def get_history(limit: int = 10) -> list:
    """获取历史记录列表"""
    try:
        with sqlite3.connect(DB_PATH) as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT url FROM cache_history ORDER BY timestamp DESC LIMIT ?', (limit,))
            return [row[0] for row in cursor.fetchall()]
    except Exception as e:
        logger.warning(f"读取历史记录失败: {e}")
    return []
