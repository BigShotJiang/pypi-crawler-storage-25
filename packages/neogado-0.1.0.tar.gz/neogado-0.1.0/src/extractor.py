import re
from typing import List, Dict, Optional
from bs4 import BeautifulSoup
import logging
from urllib.parse import urljoin

from src.models import TocRule, ContentRule, BookListRule, BookInfoRule

logger = logging.getLogger(__name__)


def extract_toc(html: str, rules: Optional[TocRule], base_url: str) -> List[Dict[str, str]]:
    """根据目录规则，从 HTML 中提取章节列表"""
    if not rules or not rules.chapterList:
        return []

    soup = BeautifulSoup(html, "html.parser")
    chapter_elements = soup.select(rules.chapterList)
    chapters = []

    for el in chapter_elements:
        name_selector = rules.chapterName
        url_selector = rules.chapterUrl

        name_el = el.select_one(name_selector) if name_selector else el
        url_el = el.select_one(url_selector) if url_selector else el

        name = name_el.get_text(strip=True) if name_el else ""
        href = url_el.get("href") if url_el else ""

        if name and href:
            full_url = urljoin(base_url, href)
            chapters.append({"name": name, "url": full_url})

    return chapters


def extract_content(html: str, rules: Optional[ContentRule]) -> str:
    """根据正文规则，从 HTML 中提取并脱水小说正文，输出为 Markdown 格式"""
    if not rules or not rules.content:
        return "❌ 提取规则缺失: content 节点为空。"

    soup = BeautifulSoup(html, "html.parser")
    content_el = soup.select_one(rules.content)
    
    if not content_el:
        return "❌ 无法根据规则找到正文内容，请检查规则或网页是否已变更。"

    if rules.junkSelectors:
        for js in rules.junkSelectors:
            if js:
                for junk_el in content_el.select(js):
                    junk_el.decompose()

    raw_text = content_el.get_text(separator="\n\n", strip=True)

    if rules.junkRegex:
        for regex_str in rules.junkRegex:
            if regex_str:
                try:
                    raw_text = re.sub(regex_str, "", raw_text, flags=re.IGNORECASE)
                except Exception as e:
                    logger.warning(f"正则净化失败: {regex_str}, 错误: {e}")

    clean_text = re.sub(r"\n{3,}", "\n\n", raw_text)
    return clean_text


def extract_book_list(html: str, rules: Optional[BookListRule], base_url: str) -> List[Dict[str, str]]:
    """根据列表规则，从 HTML 中提取书籍列表"""
    if not rules or not rules.bookList:
        return []

    soup = BeautifulSoup(html, "html.parser")
    book_elements = soup.select(rules.bookList)
    books = []

    for el in book_elements:
        name_el = el.select_one(rules.bookName) if rules.bookName else None
        author_el = el.select_one(rules.author) if rules.author else None
        url_el = el.select_one(rules.detailUrl) if rules.detailUrl else None
        intro_el = el.select_one(rules.intro) if rules.intro else None
        cover_el = el.select_one(rules.coverUrl) if rules.coverUrl else None

        name = name_el.get_text(strip=True) if name_el else "未知书名"
        author = author_el.get_text(strip=True) if author_el else "未知作者"
        intro = intro_el.get_text(strip=True) if intro_el else ""
        
        href = url_el.get("href") if url_el else ""
        full_url = urljoin(base_url, href) if href else ""
        
        cover = ""
        if cover_el:
            cover = cover_el.get("src") or cover_el.get("data-src") or ""
            if cover:
                cover = urljoin(base_url, cover)

        if name and full_url:
            books.append({
                "name": name,
                "author": author,
                "url": full_url,
                "intro": intro,
                "cover": cover
            })

    return books


def extract_book_info(html: str, rules: Optional[BookInfoRule], base_url: str) -> Dict[str, str]:
    """根据详情页规则，从 HTML 中提取单本书籍的详细信息"""
    if not rules:
        return {}

    soup = BeautifulSoup(html, "html.parser")
    
    book_name_el = soup.select_one(rules.bookName) if rules.bookName else None
    author_el = soup.select_one(rules.author) if rules.author else None
    cover_el = soup.select_one(rules.coverUrl) if rules.coverUrl else None
    intro_el = soup.select_one(rules.intro) if rules.intro else None
    last_chapter_el = soup.select_one(rules.lastChapter) if rules.lastChapter else None
    catalog_el = soup.select_one(rules.catalogUrl) if rules.catalogUrl else None

    book_name = book_name_el.get_text(strip=True) if book_name_el else "未知书名"
    author = author_el.get_text(strip=True) if author_el else "未知作者"
    intro = intro_el.get_text(strip=True) if intro_el else "暂无简介"
    last_chapter = last_chapter_el.get_text(strip=True) if last_chapter_el else ""

    cover = ""
    if cover_el:
        cover = cover_el.get("src") or cover_el.get("data-src") or ""
        if cover:
            cover = urljoin(base_url, cover)

    catalog_url = ""
    if catalog_el:
        href = catalog_el.get("href")
        if href:
            catalog_url = urljoin(base_url, href)

    return {
        "name": book_name,
        "author": author,
        "cover": cover,
        "intro": intro,
        "lastChapter": last_chapter,
        "catalogUrl": catalog_url or base_url  # 如果没有单独的目录链接，默认当前页就是目录页
    }
