import re
import json
import logging
from bs4 import BeautifulSoup

logger = logging.getLogger(__name__)


def validate_toc_rules(raw_html: str, rules: dict) -> bool:
    """验证目录规则"""
    if not rules:
        return False

    soup = BeautifulSoup(raw_html, "html.parser")
    chapter_list_selector = rules.get("chapterList", "")
    if not chapter_list_selector:
        return False

    chapter_elements = soup.select(chapter_list_selector)
    if not chapter_elements:
        return False

    valid_chapters = 0
    for el in chapter_elements[:5]:
        name_selector = rules.get("chapterName", "")
        url_selector = rules.get("chapterUrl", "")

        name_el = el.select_one(name_selector) if name_selector else el
        url_el = el.select_one(url_selector) if url_selector else el

        name = name_el.get_text(strip=True) if name_el else "未知名称"
        href = url_el.get("href") if url_el else "未知链接"

        if name != "未知名称" and href != "未知链接":
            valid_chapters += 1

    return valid_chapters > 0


def validate_content_rules(raw_html: str, rules: dict) -> bool:
    """验证正文规则"""
    if not rules:
        return False

    soup = BeautifulSoup(raw_html, "html.parser")
    content_selector = rules.get("content", "")
    if not content_selector:
        return False

    content_el = soup.select_one(content_selector)
    if not content_el:
        return False

    raw_text = content_el.get_text(separator="\n", strip=True)
    return len(raw_text) > 20


def validate_book_list_rules(raw_html: str, rules: dict) -> bool:
    """验证书籍列表规则"""
    if not rules:
        return False

    soup = BeautifulSoup(raw_html, "html.parser")
    book_list_selector = rules.get("bookList", "")
    if not book_list_selector:
        return False

    book_elements = soup.select(book_list_selector)
    if not book_elements:
        return False

    valid_books = 0
    for el in book_elements[:3]:
        name_selector = rules.get("bookName", "")
        url_selector = rules.get("detailUrl", "")

        name_el = el.select_one(name_selector) if name_selector else None
        url_el = el.select_one(url_selector) if url_selector else None

        name = name_el.get_text(strip=True) if name_el else "未知名称"
        href = url_el.get("href") if url_el else ""

        if name != "未知名称" and href:
            valid_books += 1

    return valid_books > 0


def validate_book_info_rules(raw_html: str, rules: dict) -> bool:
    """验证详情页规则"""
    if not rules:
        return False

    soup = BeautifulSoup(raw_html, "html.parser")
    book_name_selector = rules.get("bookName", "")
    book_name_el = soup.select_one(book_name_selector) if book_name_selector else None
    book_name = book_name_el.get_text(strip=True) if book_name_el else "未知名称"

    return book_name != "未知名称"
