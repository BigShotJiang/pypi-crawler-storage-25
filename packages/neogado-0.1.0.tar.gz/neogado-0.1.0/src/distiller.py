import logging
from bs4 import BeautifulSoup

logger = logging.getLogger(__name__)


def distill_html(raw_html: str, max_length: int = 20000) -> str:
    """
    第二步：核心脱水清洗 (Distillation)
    极大地压缩 HTML 体积，降低 Token 消耗，提高 AI 识别准确率。
    """
    if not raw_html:
        return ""

    logger.info("[2/4] 清洗并精简 HTML 结构...")
    soup = BeautifulSoup(raw_html, "html.parser")

    # 1. 暴力移除无用标签 (脚本、样式、广告 iframe、表单等)
    # 移除了对 img, header, footer 的过滤，以防丢失封面图和重要导航信息
    for tag in soup(
        [
            "script",
            "style",
            "link",
            "meta",
            "noscript",
            "svg",
            "iframe",
            "form",
        ]
    ):
        tag.decompose()

    # 2. 清洗保留标签的属性，只留对 CSS 选择器有用的 class, id, href，以及图片的 src, data-src, alt
    allowed_attrs = {"class", "id", "href", "src", "data-src", "alt"}
    for tag in soup.find_all(True):
        # 提取当前标签的所有属性名
        attrs = list(tag.attrs.keys())
        for attr in attrs:
            if attr not in allowed_attrs:
                del tag[attr]

    # 3. 移除多余空行，得到清理后的 HTML
    clean_html = str(soup)
    clean_html = "\n".join([line for line in clean_html.split("\n") if line.strip()])

    # 限制总长度，截取前部（因为小说目录和基础信息通常都在前半部分）
    return clean_html[:max_length]
