from pydantic import BaseModel, Field
from typing import List, Optional, Dict

class SearchActionRule(BaseModel):
    """搜索交互规则 (Playwright 驱动)"""
    searchInput: str = ""   # 搜索输入框的 CSS 选择器
    searchButton: str = ""  # 搜索按钮的 CSS 选择器

class BookListRule(BaseModel):
    """书籍列表解析规则 (适用于搜索结果、分类页、排行榜)"""
    bookList: str = ""      # 列表项的包裹器
    bookName: str = ""      # 书名
    author: str = ""        # 作者
    coverUrl: str = ""      # 封面
    intro: str = ""         # 简介
    detailUrl: str = ""     # 指向详情页(或目录页)的链接

class BookInfoRule(BaseModel):
    """书籍详情解析规则"""
    bookName: str = ""
    author: str = ""
    coverUrl: str = ""
    intro: str = ""
    lastChapter: str = ""   # 最新章节名(可选)
    catalogUrl: str = ""    # 指向目录页的链接 (如果和详情页是同一页则为空)

class TocRule(BaseModel):
    """目录解析规则"""
    chapterList: str = ""   # 章节列表包裹器
    chapterName: str = ""   # 章节名
    chapterUrl: str = ""    # 章节链接

class ContentRule(BaseModel):
    """正文解析规则"""
    chapterTitle: str = ""  # 章节标题
    content: str = ""       # 正文容器
    junkSelectors: List[str] = Field(default_factory=list) # 广告节点
    junkRegex: List[str] = Field(default_factory=list)     # 文本内水印正则

class SiteSchema(BaseModel):
    """顶级书源架构 (对标 Legado)"""
    sourceName: str = ""
    sourceUrl: str = ""
    
    # 动态入口配置
    searchActionRule: Optional[SearchActionRule] = None
    exploreUrls: List[Dict[str, str]] = Field(default_factory=list) # [{"name": "玄幻", "url": "/xuanhuan/"}]
    
    # 解析规则树
    ruleBookList: Optional[BookListRule] = None
    ruleBookInfo: Optional[BookInfoRule] = None
    ruleToc: Optional[TocRule] = None
    ruleContent: Optional[ContentRule] = None
