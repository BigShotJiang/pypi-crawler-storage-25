import logging
from urllib.parse import urlparse

from src.scraper import _fetch_with_playwright
from src.distiller import distill_html
from src.llm_parser import (
    generate_toc_rules_with_ai,
    generate_content_rules_with_ai,
    generate_book_list_rules_with_ai,
    generate_book_info_rules_with_ai,
    generate_site_entry_rules_with_ai,
    classify_page_with_ai,
)
from src.validator import (
    validate_toc_rules,
    validate_content_rules,
    validate_book_list_rules,
    validate_book_info_rules,
)
from src.storage import get_rule_filepath, load_local_rules, save_local_rules
from src.extractor import extract_toc
from src.models import SiteSchema, SearchActionRule

logger = logging.getLogger(__name__)

# 页面类型对应的生成器、验证器和模型字段映射表
PAGE_TYPE_HANDLERS = {
    "toc": (generate_toc_rules_with_ai, validate_toc_rules, "ruleToc"),
    "content": (generate_content_rules_with_ai, validate_content_rules, "ruleContent"),
    "bookList": (generate_book_list_rules_with_ai, validate_book_list_rules, "ruleBookList"),
    "bookInfo": (generate_book_info_rules_with_ai, validate_book_info_rules, "ruleBookInfo"),
}


async def ensure_site_rules(url: str, force_refresh: bool = False, expected_type: str = None) -> SiteSchema:
    """
    确保站点规则完整且有效（入口函数）。
    加载本地规则，触发链式探索与自愈，最后保存并返回最新规则。
    """
    if not url:
        logger.error("必须提供一个有效的小说网页 URL")
        return SiteSchema()

    rule_filepath = get_rule_filepath(url)
    
    if force_refresh:
        logger.info("收到强制刷新请求，清空当前站点的本地规则，准备重新生成...")
        site_schema = SiteSchema()
    else:
        raw_dict = load_local_rules(rule_filepath)
        site_schema = SiteSchema.model_validate(raw_dict) if raw_dict else SiteSchema()

    if not site_schema.sourceName:
        site_schema.sourceName = "AI 自愈测试书源"
    if not site_schema.sourceUrl:
        site_schema.sourceUrl = f"https://{urlparse(url).netloc}"

    logger.info("Starting NeoGado Rule Explorer & Healer")

    # 核心：链式探索与规则生成
    await _explore_page(url, site_schema, expected_type=expected_type)

    # 持久化存储更新后的规则 (排除 None 值)
    save_local_rules(rule_filepath, site_schema.model_dump(exclude_none=True))
    logger.info(f"最新规则已成功保存到 {rule_filepath}")
    
    return site_schema


async def _explore_page(url: str, site_schema: SiteSchema, visited: set = None, expected_type: str = None) -> bool:
    """
    页面探索与链式调用流程
    1. 抓取内容并分类
    2. 调用规则自愈逻辑
    3. 根据页面类型进行链式递归（如：目录页自动抓取第一章生成正文规则）
    """
    if visited is None:
        visited = set()
        
    if url in visited:
        return True
    visited.add(url)

    logger.info(f"[EXPLORER] 开始探索页面: {url}")
    raw_html = await _fetch_with_playwright(url)

    if not raw_html:
        logger.error("[EXPLORER] 无法获取页面内容。")
        return False

    clean_html = distill_html(raw_html)
    
    if expected_type:
        page_type = expected_type
        logger.info(f"[EXPLORER] 已明确指定页面类型为 [{page_type.upper()}]，跳过 AI 识别。")
    else:
        page_type = await classify_page_with_ai(clean_html, url)

    # 特殊处理首页：提取导航和搜索规则，并尝试提取列表规则
    if page_type == "home":
        logger.info("[HOME] 识别为首页，开始提取入口配置...")
        entry_data = await generate_site_entry_rules_with_ai(clean_html)
        
        if "exploreUrls" in entry_data and entry_data["exploreUrls"]:
            site_schema.exploreUrls = entry_data["exploreUrls"]
            logger.info(f"[HOME] 提取到 {len(site_schema.exploreUrls)} 个分类导航链接")
            
        if "searchActionRule" in entry_data and entry_data["searchActionRule"]:
            site_schema.searchActionRule = SearchActionRule(**entry_data["searchActionRule"])
            logger.info("[HOME] 提取到搜索交互规则")
            
        # 首页通常也包含推荐列表，尝试复用 bookList 逻辑提取
        page_type = "bookList"

    if page_type not in PAGE_TYPE_HANDLERS:
        logger.error(f"[EXPLORER] 无法处理该页面的具体类型: {page_type} ({url})")
        return False

    logger.info(f"[EXPLORER] 页面识别完成，移交至自愈管道: {page_type.upper()}")

    success = await _ensure_page_rules(
        url, page_type, site_schema, raw_html, clean_html
    )
    
    if not success:
        return False
        
    # 链式递归生成：详情页 -> 目录页
    if page_type == "bookInfo" and not site_schema.ruleToc:
        logger.info("[CHAIN] 详情规则已就绪，尝试在当前页面提取目录规则...")
        await _ensure_page_rules(url, "toc", site_schema, raw_html, clean_html)
        if site_schema.ruleToc:
            page_type = "toc"

    # 链式递归生成：目录页 -> 正文页
    if page_type == "toc" and not site_schema.ruleContent:
        logger.info("[CHAIN] 目录规则已就绪，尝试自动提取第一章链接以补全正文规则...")
        chapters = extract_toc(raw_html, site_schema.ruleToc, url)
        if chapters and len(chapters) > 0:
            next_url = chapters[0]["url"]
            logger.info(f"[CHAIN] 发现章节链接，跳转生成正文规则: {next_url}")
            await _explore_page(next_url, site_schema, visited)
        else:
            logger.warning("[CHAIN] 未能从目录中提取到有效章节链接，链式生成终止。")
            
    return True


async def _ensure_page_rules(
    url: str,
    page_type: str,
    site_schema: SiteSchema,
    raw_html: str,
    clean_html: str,
) -> bool:
    """
    规则验证与自愈生成逻辑
    1. 尝试使用已有规则验证（含动态渲染兜底）
    2. 若无效，触发 AI 重新生成并验证
    """
    logger.info(f"[{page_type.upper()}] 开始处理页面规则...")

    generator_func, validator_func, rule_attr = PAGE_TYPE_HANDLERS[page_type]
    current_rule = getattr(site_schema, rule_attr, None)
    is_valid = False

    def check_rules(html: str) -> bool:
        if not current_rule:
            return False
        return validator_func(html, current_rule.model_dump())

    # 1. 尝试验证现有规则
    if current_rule:
        logger.info(f"[{page_type.upper()}] 发现本地已有规则，尝试验证...")
        is_valid = check_rules(raw_html)

        # 动态渲染兜底策略
        if not is_valid and "Playwright" not in str(type(raw_html)):
            logger.warning(f"[{page_type.upper()}] 静态规则失效，尝试启动无头浏览器真机渲染兜底...")
            dynamic_html = await _fetch_with_playwright(url)
            if dynamic_html and check_rules(dynamic_html):
                logger.info(f"✅ [{page_type.upper()}] 真机渲染后验证通过！")
                return True
            elif dynamic_html:
                logger.warning(f"[{page_type.upper()}] 真机渲染后规则依然失效，准备重新生成。")
                raw_html = dynamic_html

    if is_valid:
        logger.info(f"✅ [{page_type.upper()}] 本地规则验证通过，无需重新生成。")
        return True

    # 2. 触发 AI 生成新规则
    logger.warning(f"⚠️ [{page_type.upper()}] 规则无效或不存在，触发 AI 重新生成...")
    new_rule = await generator_func(clean_html)
    
    if new_rule and validator_func(raw_html, new_rule.model_dump()):
        logger.info(f"🎉 [{page_type.upper()}] AI 新规则验证成功，更新规则库！")
        setattr(site_schema, rule_attr, new_rule)
        return True

    logger.error(f"❌ [{page_type.upper()}] AI 生成的新规则依然无效。")
    return False
