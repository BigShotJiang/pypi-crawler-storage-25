import re
import os
import logging
from urllib.parse import urljoin

# 引入 storage 以确保日志配置在程序最早期被初始化，防止被其他库覆盖
import src.storage
from src.storage import add_history, get_history

from textual import work
from textual.app import App, ComposeResult
from textual.screen import Screen
from textual.containers import Horizontal, VerticalScroll, Vertical
from textual.widgets import Header, Footer, Markdown, Tree, Label, Button, Input, ListView, ListItem, LoadingIndicator
from textual.binding import Binding

logger = logging.getLogger(__name__)

from src.scraper import get_toc, get_chapter_content, get_book_list, get_book_info, search_books, _fetch_with_playwright, login_to_site
from src.distiller import distill_html
from src.llm_parser import classify_page_with_ai
from src.rule_generator import ensure_site_rules


class StartScreen(Screen):
    """起始页：输入 URL 并智能路由"""
    
    BINDINGS = [
        Binding("ctrl+q", "quit", "退出"),
    ]
    
    def compose(self) -> ComposeResult:
        yield Header()
        yield Vertical(
            Label("🤖 欢迎使用 NeoGado AI 阅读器", classes="title"),
            Input(placeholder="请输入小说网站首页、目录页或正文页 URL...", id="url_input"),
            LoadingIndicator(id="loading", classes="-hidden"),
            Label("正在使用 AI 智能分析页面类型，请稍候...", id="loading_text", classes="-hidden"),
            Label("📜 历史记录", id="history_title"),
            ListView(id="history_list"),
            classes="start_container"
        )
        yield Footer()

    def on_mount(self):
        self.load_history()

    def on_screen_resume(self):
        self.load_history()

    def load_history(self):
        history_list = self.query_one("#history_list", ListView)
        history_list.clear()
        urls = get_history()
        if not urls:
            history_list.append(ListItem(Label("暂无历史记录"), disabled=True))
        else:
            for url in urls:
                item = ListItem(Label(url))
                item.hist_url = url
                history_list.append(item)

    async def on_input_submitted(self, event: Input.Submitted) -> None:
        url = event.value.strip()
        if url:
            # 基础校验，防止乱输入导致崩溃
            is_web = url.startswith("http://") or url.startswith("https://")
            is_local = os.path.exists(url)
            
            if not is_web and not is_local:
                self.app.notify("请输入有效的网址 (http://...) 或存在的本地文件路径", severity="error")
                logger.warning(f"用户输入了无效的路径: {url}")
                return
            logger.info(f"用户提交了 URL/路径: {url}")
            self.process_url(url)

    def on_list_view_selected(self, event: ListView.Selected):
        if event.list_view.id == "history_list":
            if hasattr(event.item, 'hist_url'):
                url = event.item.hist_url
                self.query_one("#url_input", Input).value = url
                self.process_url(url)

    @work(exclusive=True, thread=True)
    async def process_url(self, url: str):
        self.app.call_from_thread(self.query_one("#loading").remove_class, "-hidden")
        self.app.call_from_thread(self.query_one("#loading_text").remove_class, "-hidden")
        self.app.call_from_thread(self.query_one("#url_input").add_class, "-hidden")
        self.app.call_from_thread(self.query_one("#history_title").add_class, "-hidden")
        self.app.call_from_thread(self.query_one("#history_list").add_class, "-hidden")

        if os.path.exists(url) and not (url.startswith("http://") or url.startswith("https://")):
            add_history(url)
            self.app.call_from_thread(self.load_history)
            self.app.call_from_thread(self.route_page, url, "local")
            return

        # 抓取并分类
        logger.info(f"开始抓取页面: {url}")
        html = await _fetch_with_playwright(url)
        if not html:
            logger.error(f"无法访问该网页: {url}")
            self.app.call_from_thread(self.app.notify, "无法访问该网页，请检查链接是否正确", severity="error")
            self.app.call_from_thread(self.reset_ui)
            return

        # 成功抓取后加入历史记录
        add_history(url)
        self.app.call_from_thread(self.load_history)

        logger.info("页面抓取成功，开始精简 HTML")
        clean_html = distill_html(html)
        
        logger.info("开始使用 AI 分类页面类型")
        page_type = await classify_page_with_ai(clean_html, url)
        logger.info(f"页面分类结果: {page_type}")

        self.app.call_from_thread(self.route_page, url, page_type)

    def reset_ui(self):
        self.query_one("#loading").add_class("-hidden")
        self.query_one("#loading_text").add_class("-hidden")
        self.query_one("#url_input").remove_class("-hidden")
        self.query_one("#history_title").remove_class("-hidden")
        self.query_one("#history_list").remove_class("-hidden")

    def route_page(self, url: str, page_type: str):
        self.reset_ui()
        if page_type in ["home", "bookList", "search", "explore"]:
            logger.info("路由到书城/发现页 (BookStoreScreen)")
            self.app.push_screen(BookStoreScreen(url))
        elif page_type == "bookInfo" or page_type == "detail":
            logger.info("路由到详情页 (DetailScreen)")
            self.app.push_screen(DetailScreen(url))
        else:
            logger.info("路由到阅读页 (ReaderScreen)")
            self.app.push_screen(ReaderScreen(url))


class BookStoreScreen(Screen):
    """书城页：展示分类导航、搜索框和书籍列表"""
    
    BINDINGS = [Binding("escape", "app.pop_screen", "返回")]

    def __init__(self, url: str, **kwargs):
        super().__init__(**kwargs)
        self.base_url = url
        self.current_url = url

    def compose(self) -> ComposeResult:
        yield Header()
        with Horizontal(id="store_container"):
            with Vertical(id="store_sidebar"):
                yield Label("🧭 分类导航", classes="sidebar_title")
                yield ListView(id="nav_list")
            with Vertical(id="store_main"):
                with Horizontal(id="search_bar"):
                    yield Input(placeholder="输入关键字全站搜索...", id="search_input")
                    yield Button("搜索", id="search_btn", variant="primary")
                yield Label(f"当前位置: {self.current_url}", id="store_location")
                yield ListView(id="book_list")
        yield Footer()

    def on_mount(self):
        self.load_store_data()

    @work(exclusive=True, thread=True)
    async def load_store_data(self):
        self.app.call_from_thread(self.app.notify, "正在初始化书城数据...", severity="information")
        
        # 确保首页规则已加载，提取导航链接
        site_schema = await ensure_site_rules(self.base_url, expected_type="home")
        if site_schema and site_schema.exploreUrls:
            self.app.call_from_thread(self.populate_nav, site_schema.exploreUrls)
            
        # 加载初始书籍列表
        books = await get_book_list(self.current_url)
        self.app.call_from_thread(self.populate_books, books)

    def populate_nav(self, nav_items):
        nav_list = self.query_one("#nav_list", ListView)
        nav_list.clear()
        
        # 添加首页选项
        home_item = ListItem(Label("🏠 网站首页"))
        home_item.nav_url = self.base_url
        nav_list.append(home_item)
        
        for item in nav_items:
            li = ListItem(Label(f"📁 {item['name']}"))
            li.nav_url = item["url"]
            nav_list.append(li)

    def populate_books(self, books):
        book_list = self.query_one("#book_list", ListView)
        book_list.clear()
        if not books:
            book_list.append(ListItem(Label("未找到任何书籍，请检查规则或网页。")))
            return
            
        for i, book in enumerate(books):
            item = ListItem(
                Vertical(
                    Label(f"📖 {book.get('name', '未知')} (作者: {book.get('author', '未知')})", classes="book_name"),
                    Label(book.get('intro', ''), classes="book_intro"),
                )
            )
            item.book_url = book.get('url')
            book_list.append(item)

    async def on_button_pressed(self, event: Button.Pressed):
        if event.button.id == "search_btn":
            keyword = self.query_one("#search_input", Input).value.strip()
            if keyword:
                self.perform_search(keyword)

    async def on_input_submitted(self, event: Input.Submitted):
        if event.input.id == "search_input":
            keyword = event.value.strip()
            if keyword:
                self.perform_search(keyword)

    @work(exclusive=True, thread=True)
    async def perform_search(self, keyword: str):
        self.app.call_from_thread(self.app.notify, f"正在搜索: {keyword}...", severity="information")
        books = await search_books(self.base_url, keyword)
        self.app.call_from_thread(self.populate_books, books)
        self.app.call_from_thread(self.query_one("#store_location", Label).update, f"🔍 搜索结果: {keyword}")

    def on_list_view_selected(self, event: ListView.Selected):
        if event.list_view.id == "nav_list":
            if hasattr(event.item, 'nav_url'):
                full_url = urljoin(self.base_url, event.item.nav_url)
                self.current_url = full_url
                self.query_one("#store_location", Label).update(f"当前位置: {full_url}")
                self.load_category_books(full_url)
        elif event.list_view.id == "book_list":
            if hasattr(event.item, 'book_url') and event.item.book_url:
                logger.info(f"用户选择了书籍: {event.item.book_url}")
                self.app.push_screen(DetailScreen(event.item.book_url))

    @work(exclusive=True, thread=True)
    async def load_category_books(self, url: str):
        self.app.call_from_thread(self.app.notify, "正在加载分类数据...", severity="information")
        books = await get_book_list(url)
        self.app.call_from_thread(self.populate_books, books)


class DetailScreen(Screen):
    """详情页：展示单本书籍的详细信息和目录"""
    
    BINDINGS = [Binding("escape", "app.pop_screen", "返回")]

    def __init__(self, url: str, **kwargs):
        super().__init__(**kwargs)
        self.url = url
        self.book_info = {}

    def compose(self) -> ComposeResult:
        yield Header()
        with VerticalScroll(id="detail_container"):
            yield Label("正在加载书籍详情，请稍候...", id="detail_loading")
            with Vertical(id="detail_content", classes="-hidden"):
                yield Label("", id="detail_title", classes="detail_title")
                yield Label("", id="detail_author", classes="detail_author")
                yield Label("", id="detail_last_chapter", classes="detail_last_chapter")
                yield Label("📝 内容简介:", classes="detail_section_title")
                yield Markdown("", id="detail_intro")
                with Horizontal(id="detail_actions"):
                    yield Button("开始阅读", id="btn_read", variant="success")
                
                # 新增目录部分
                yield Label("📑 目录列表:", classes="detail_section_title")
                yield Label("正在加载目录...", id="detail_toc_loading")
                yield ListView(id="detail_toc_list", classes="-hidden")
        yield Footer()

    def on_mount(self):
        add_history(self.url)
        self.load_detail()

    @work(exclusive=True, thread=True)
    async def load_detail(self):
        logger.info(f"开始提取书籍详情: {self.url}")
        info = await get_book_info(self.url)
        self.app.call_from_thread(self.update_ui, info)

        # 详情加载完后，继续加载目录
        target_url = info.get("catalogUrl") or self.url
        toc = await get_toc(target_url)
        self.app.call_from_thread(self.update_toc_ui, toc)

    def update_ui(self, info):
        self.book_info = info
        self.query_one("#detail_loading").add_class("-hidden")
        content = self.query_one("#detail_content")
        content.remove_class("-hidden")
        
        if not info:
            self.query_one("#detail_title", Label).update("❌ 加载详情失败，请检查规则或网页。")
            return

        self.query_one("#detail_title", Label).update(f"📚 {info.get('name', '未知书名')}")
        self.query_one("#detail_author", Label).update(f"✍️ 作者: {info.get('author', '未知')}")
        self.query_one("#detail_last_chapter", Label).update(f"📌 最新章节: {info.get('lastChapter', '未知')}")
        self.query_one("#detail_intro", Markdown).update(info.get('intro', '暂无简介'))

    def update_toc_ui(self, toc):
        self.query_one("#detail_toc_loading").add_class("-hidden")
        toc_list = self.query_one("#detail_toc_list", ListView)
        toc_list.remove_class("-hidden")
        toc_list.clear()
        
        if not toc:
            toc_list.append(ListItem(Label("暂无目录数据"), disabled=True))
            return
            
        for i, chap in enumerate(toc):
            item = ListItem(Label(chap.get("name", f"第 {i+1} 章")))
            item.chap_index = i
            toc_list.append(item)

    def on_button_pressed(self, event: Button.Pressed):
        if event.button.id == "btn_read":
            target_url = self.book_info.get("catalogUrl") or self.url
            logger.info(f"跳转到阅读页: {target_url}")
            self.app.push_screen(ReaderScreen(target_url, start_index=0))

    def on_list_view_selected(self, event: ListView.Selected):
        if event.list_view.id == "detail_toc_list":
            if hasattr(event.item, 'chap_index'):
                target_url = self.book_info.get("catalogUrl") or self.url
                self.app.push_screen(ReaderScreen(target_url, start_index=event.item.chap_index))


class ReaderScreen(Screen):
    """阅读页：展示目录和正文"""
    
    BINDINGS = [
        Binding("escape", "app.pop_screen", "返回"),
        Binding("r", "force_refresh", "强制刷新"),
        Binding("R", "force_refresh_toc", "强制刷新目录"),
        Binding("d", "download_all", "下载全本(缓存)"),
        Binding("t", "toggle_toc", "显示/隐藏目录"),
        Binding("ctrl+b", "toggle_toc", "显示/隐藏目录", show=False),
        Binding("n", "next_chapter", "下一章"),
        Binding("p", "prev_chapter", "上一章"),
        Binding("j", "scroll_down", "向下滚动", show=False),
        Binding("k", "scroll_up", "向上滚动", show=False),
    ]

    def __init__(self, initial_url: str = None, start_index: int = 0, **kwargs):
        super().__init__(**kwargs)
        self.initial_path = initial_url
        self.chapters = []
        self.toc_data = []
        self.current_chapter_index = start_index
        self.is_online = False

    def compose(self) -> ComposeResult:
        yield Header()
        with Horizontal(id="main_container"):
            with Vertical(id="sidebar"):
                with Horizontal(id="sidebar_header"):
                    yield Button("[X]", id="close_sidebar", variant="error")
                yield Tree("小说目录", id="toc")
            with VerticalScroll(id="reader_container"):
                yield Markdown(id="reader")
        yield Footer()

    def on_mount(self) -> None:
        if self.initial_path:
            self._load_path(self.initial_path)

    def _load_path(self, path: str, force_refresh: bool = False) -> None:
        self.initial_path = path
        logger.info(f"准备加载路径/URL: {path}")
        add_history(path)
        if path.startswith("http://") or path.startswith("https://"):
            self.is_online = True
            self.load_novel_from_url(path, force_refresh=force_refresh)
        elif os.path.exists(path):
            self.is_online = False
            self.load_novel(path)
        else:
            logger.error(f"路径无效或文件不存在: {path}")
            self.show_error("路径无效或文件不存在")

    def show_error(self, message: str) -> None:
        self.chapters = [{"title": "错误", "content": f"# 错误\n\n{message}"}]
        self.toc_data = [{"title": "错误", "is_volume": False, "index": 0}]
        self.populate_toc()
        self.load_chapter(0)

    @work(exclusive=True, thread=True)
    async def load_novel_from_url(self, url: str, force_refresh: bool = False) -> None:
        msg = "# 正在智能解析目录，请稍候...\n\n(首次解析可能需要调用 AI 生成规则，耗时较长)"
        if force_refresh:
            msg = "# 正在强制刷新规则并重新解析目录，请稍候..."
            
        self.app.call_from_thread(self.query_one("#reader", Markdown).update, msg)
        
        logger.info(f"开始获取目录: {url}, force_refresh={force_refresh}")
        extracted_chapters = await get_toc(url, force_refresh=force_refresh)
        
        if not extracted_chapters:
            logger.error("目录提取失败")
            self.app.call_from_thread(self.show_error, "目录提取失败，请检查规则或页面结构")
            return
            
        logger.info(f"成功提取到 {len(extracted_chapters)} 章目录")
        self.chapters = extracted_chapters
        self.toc_data = []
        
        for i, chap in enumerate(self.chapters):
            self.toc_data.append({"title": chap["name"], "is_volume": False, "index": i})
            
        self.app.call_from_thread(self.populate_toc)
        self.app.call_from_thread(self.load_chapter, self.current_chapter_index)

    def load_novel(self, path: str) -> None:
        logger.info(f"开始加载本地小说: {path}")
        try:
            with open(path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            pattern = re.compile(r'(第[零一二三四五六七八九十百千万\d]+[卷部章][^\n]*)')
            parts = pattern.split(content)
            
            self.chapters = []
            self.toc_data = []
            current_volume = None
            
            if parts[0].strip():
                self.chapters.append({"title": "前言", "content": parts[0].strip()})
                self.toc_data.append({"title": "前言", "is_volume": False, "index": 0})
                
            for i in range(1, len(parts), 2):
                title = parts[i].strip()
                text = parts[i+1].strip() if i+1 < len(parts) else ""
                
                if '卷' in title or '部' in title:
                    current_volume = {"title": title, "is_volume": True, "chapters": []}
                    self.toc_data.append(current_volume)
                    if text:
                        idx = len(self.chapters)
                        self.chapters.append({"title": f"{title} - 引言", "content": f"# {title} - 引言\n\n{text}"})
                        current_volume["chapters"].append({"title": "引言", "index": idx})
                else:
                    idx = len(self.chapters)
                    self.chapters.append({"title": title, "content": f"# {title}\n\n{text}"})
                    chap_info = {"title": title, "index": idx}
                    
                    if current_volume is not None:
                        current_volume["chapters"].append(chap_info)
                    else:
                        self.toc_data.append({"title": title, "is_volume": False, "index": idx})
                
            if not self.chapters:
                self.chapters.append({"title": "全本内容", "content": content})
                self.toc_data.append({"title": "全本内容", "is_volume": False, "index": 0})
                
            logger.info(f"本地小说加载完成，共 {len(self.chapters)} 章")
            self.populate_toc()
            self.load_chapter(self.current_chapter_index)
        except Exception as e:
            logger.exception(f"无法读取文件: {e}")
            self.show_error(f"无法读取文件: {e}")

    def populate_toc(self) -> None:
        tree = self.query_one("#toc", Tree)
        tree.clear()
        tree.root.expand()
        
        for item in self.toc_data:
            if item.get("is_volume"):
                vol_node = tree.root.add(item["title"], expand=True)
                for chap in item["chapters"]:
                    vol_node.add_leaf(chap["title"], data=chap["index"])
            else:
                tree.root.add_leaf(item["title"], data=item["index"])

    def load_chapter(self, index: int) -> None:
        if 0 <= index < len(self.chapters):
            self.current_chapter_index = index
            logger.info(f"准备加载章节索引: {index}")
            
            if self.is_online:
                self.fetch_and_display_chapter(index)
            else:
                self._update_reader_ui(self.chapters[index]["content"], self.chapters[index]["title"])

    @work(exclusive=True, thread=True)
    async def fetch_and_display_chapter(self, index: int, force_refresh: bool = False) -> None:
        chapter = self.chapters[index]
        chapter_url = chapter.get("url")
        chapter_title = chapter.get("name", f"第 {index+1} 章")
        
        msg = f"# 正在加载: {chapter_title}..."
        if force_refresh:
            msg = f"# 正在强制刷新规则并加载: {chapter_title}..."
            
        self.app.call_from_thread(self.query_one("#reader", Markdown).update, msg)
        
        logger.info(f"开始获取章节内容: {chapter_title} ({chapter_url})")
        content_text = await get_chapter_content(chapter_url, force_refresh=force_refresh)
        
        md_content = f"# {chapter_title}\n\n{content_text}"
        self.app.call_from_thread(self._update_reader_ui, md_content, chapter_title)

    def _update_reader_ui(self, markdown_text: str, title: str) -> None:
        reader = self.query_one("#reader", Markdown)
        reader.update(markdown_text)
        
        container = self.query_one("#reader_container", VerticalScroll)
        container.scroll_home(animate=False)

    def on_tree_node_selected(self, event: Tree.NodeSelected) -> None:
        if event.node.data is not None:
            self.load_chapter(event.node.data)

    def on_button_pressed(self, event: Button.Pressed) -> None:
        # 处理侧边栏关闭按钮
        if event.button.id == "close_sidebar":
            self.action_toggle_toc()

    def action_force_refresh(self) -> None:
        if not self.is_online:
            return
        logger.info("触发强制刷新")

        focused = self.app.focused
        if focused and focused.id == "toc":
            logger.info("强制刷新目录")
            if self.initial_path:
                self.load_novel_from_url(self.initial_path, force_refresh=True)
            return

        if self.chapters and self.current_chapter_index < len(self.chapters):
            logger.info("强制刷新章节")
            self.fetch_and_display_chapter(self.current_chapter_index, force_refresh=True)
        elif self.initial_path:
            logger.info("强制刷新目录(默认)")
            self.load_novel_from_url(self.initial_path, force_refresh=True)

    def action_force_refresh_toc(self) -> None:
        if not self.is_online:
            return
        logger.info("强制刷新目录 (Shift+R)")
        if self.initial_path:
            self.load_novel_from_url(self.initial_path, force_refresh=True)

    def action_download_all(self) -> None:
        if not self.is_online or not self.chapters:
            self.notify("当前没有可下载的在线小说", severity="warning")
            return
        logger.info("触发下载全本")
        self.notify("开始后台下载全本，请稍候...", severity="information")
        self.download_all_chapters()

    @work(exclusive=True, thread=True)
    async def download_all_chapters(self) -> None:
        total = len(self.chapters)
        success = 0
        logger.info(f"开始后台下载全本，共 {total} 章")
        for i, chap in enumerate(self.chapters):
            url = chap.get("url")
            if not url:
                continue
            
            content = await get_chapter_content(url)
            if content and not content.startswith("❌"):
                success += 1
            
            if (i + 1) % 10 == 0 or i + 1 == total:
                logger.info(f"下载进度: {i + 1}/{total}")
                self.app.call_from_thread(
                    self.app.notify, 
                    f"下载进度: {i + 1}/{total}", 
                    severity="information"
                )
        
        logger.info(f"下载完成！共成功缓存 {success}/{total} 章。")
        self.app.call_from_thread(
            self.app.notify, 
            f"下载完成！共成功缓存 {success}/{total} 章。", 
            severity="information"
        )

    def action_toggle_toc(self) -> None:
        sidebar = self.query_one("#sidebar")
        if sidebar.has_class("-hidden"):
            sidebar.remove_class("-hidden")
        else:
            sidebar.add_class("-hidden")

    def action_next_chapter(self) -> None:
        if self.current_chapter_index < len(self.chapters) - 1:
            self.load_chapter(self.current_chapter_index + 1)

    def action_prev_chapter(self) -> None:
        if self.current_chapter_index > 0:
            self.load_chapter(self.current_chapter_index - 1)

    def action_scroll_down(self) -> None:
        container = self.query_one("#reader_container", VerticalScroll)
        container.scroll_down()

    def action_scroll_up(self) -> None:
        container = self.query_one("#reader_container", VerticalScroll)
        container.scroll_up()


class NeoGadoApp(App):
    """主程序入口"""

    CSS = """
    Screen {
        layout: vertical;
    }

    /* StartScreen CSS */
    StartScreen {
        align: center middle;
    }
    .start_container {
        width: 80%;
        max-width: 120;
        height: auto;
        padding: 2;
        border: solid $accent;
        background: $surface;
    }
    .title {
        text-align: center;
        margin-bottom: 2;
        text-style: bold;
    }
    #url_input {
        width: 100%;
        margin-bottom: 1;
    }
    .-hidden {
        display: none;
    }
    #loading_text {
        text-align: center;
        margin-top: 1;
        color: $text-muted;
    }
    #history_title {
        margin-top: 2;
        text-style: bold;
        color: $text-muted;
    }
    #history_list {
        height: auto;
        max-height: 10;
        margin-top: 1;
        border: solid $panel;
    }

    /* BookStoreScreen CSS */
    #store_container {
        height: 1fr;
        width: 100%;
    }
    #store_sidebar {
        width: 30;
        height: 100%;
        dock: left;
        border-right: solid $accent;
        background: $surface;
    }
    .sidebar_title {
        padding: 1;
        background: $primary;
        color: $text;
        text-style: bold;
        width: 100%;
        text-align: center;
    }
    #store_main {
        height: 100%;
        width: 1fr;
    }
    #search_bar {
        height: 3;
        width: 100%;
        margin: 1;
    }
    #search_input {
        width: 1fr;
    }
    #search_btn {
        width: 15;
        margin-left: 1;
    }
    #store_location {
        padding: 0 1;
        color: $text-muted;
        border-bottom: solid $panel;
    }
    .book_name {
        text-style: bold;
        color: $accent;
    }
    .book_intro {
        color: $text-muted;
        margin-left: 2;
    }
    ListItem {
        padding: 1;
        border-bottom: solid $panel;
    }

    /* DetailScreen CSS */
    #detail_container {
        padding: 2 4;
        height: 1fr;
        width: 100%;
        align: center top;
    }
    #detail_loading {
        text-align: center;
        margin-top: 2;
    }
    #detail_content {
        width: 80%;
        max-width: 120;
        height: auto; /* 允许内容撑开以实现全局滚动 */
        border: solid $accent;
        padding: 2;
        background: $surface;
    }
    .detail_title {
        text-style: bold;
        color: $primary;
        margin-bottom: 1;
    }
    .detail_author {
        color: $text-muted;
        margin-bottom: 1;
    }
    .detail_last_chapter {
        color: $warning;
        margin-bottom: 1;
    }
    .detail_section_title {
        text-style: bold;
        margin-top: 1;
        border-bottom: solid $panel;
    }
    #detail_intro {
        margin: 1 0 2 0;
    }
    #detail_actions {
        height: auto;
        margin: 1 0;
        align: left middle; /* 靠左对齐 */
    }
    #btn_read {
        width: auto; /* 按钮宽度自适应 */
        min-width: 16;
    }
    #detail_toc_loading {
        margin-top: 1;
        color: $text-muted;
    }
    #detail_toc_list {
        height: auto; /* 高度自适应，让外层 VerticalScroll 接管滚动 */
        margin-top: 1;
        border: solid $panel;
    }

    /* ReaderScreen CSS */
    #main_container {
        height: 1fr;
        width: 100%;
    }
    #sidebar {
        width: 30;
        height: 100%;
        dock: left;
        border-right: solid $accent;
        background: $surface;
        transition: width 300ms in_out_cubic;
        overflow-x: hidden;
    }
    #sidebar.-hidden {
        width: 0;
        border-right: none;
    }
    #sidebar_header {
        height: 3;
        align: right middle;
        padding: 0 1;
        border-bottom: solid $primary;
    }
    #close_sidebar {
        min-width: 5;
        height: 1;
        border: none;
    }
    #toc {
        height: 1fr;
        width: 100%;
    }
    #reader_container {
        height: 100%;
        width: 1fr;
        padding: 1 4;
        background: $background;
    }
    Markdown {
        margin: 1 2;
    }
    """

    BINDINGS = [
        Binding("ctrl+q", "quit", "退出"),
        Binding("ctrl+l", "login", "登录当前网站"),
    ]

    def get_current_url(self) -> str:
        """获取当前活动页面的URL"""
        screen = self.screen  # Textual 使用 self.screen 获取当前活动屏幕
        if not screen:
            return ""

        if hasattr(screen, 'base_url'):  # BookStoreScreen
            return screen.base_url
        elif hasattr(screen, 'url'):  # DetailScreen
            return screen.url
        elif hasattr(screen, 'initial_path'):  # ReaderScreen
            return screen.initial_path
        elif isinstance(screen, StartScreen):  # 起始页
            url_input = screen.query_one("#url_input", Input)
            return url_input.value.strip()

        return ""

    @work(exclusive=True)
    async def action_login(self) -> None:
        """登录当前网站"""
        current_url = self.get_current_url()
        if not current_url or not (current_url.startswith("http://") or current_url.startswith("https://")):
            self.notify("请先输入或导航到需要登录的网站URL", severity="warning")
            return

        self.notify("正在打开浏览器，请完成登录后关闭浏览器", severity="information")
        logger.info(f"触发登录: {current_url}")

        success = await login_to_site(current_url)
        if success:
            self.notify("登录成功！cookies已保存，后续请求将自动使用登录状态", severity="success")
        else:
            self.notify("登录失败，请重试", severity="error")

    def __init__(self, initial_url: str = None, **kwargs):
        super().__init__(**kwargs)
        self.initial_url = initial_url

    def on_mount(self):
        logger.info("NeoGadoApp 启动")
        start_screen = StartScreen()
        self.push_screen(start_screen)
        
        if self.initial_url:
            logger.info(f"使用初始 URL 启动: {self.initial_url}")
            start_screen.query_one("#url_input", Input).value = self.initial_url
            start_screen.process_url(self.initial_url)

if __name__ == "__main__":
    app = NeoGadoApp()
    app.run()
