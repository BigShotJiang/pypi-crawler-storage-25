import logging
import json
import os
import asyncio
import threading
from playwright.async_api import async_playwright, Browser, BrowserContext
from playwright_stealth import Stealth
from urllib.parse import urlparse

from src.extractor import extract_toc, extract_content, extract_book_list, extract_book_info
from src.storage import get_cached_catalog, set_cached_catalog, get_cached_chapter, set_cached_chapter, get_cached_book_info, set_cached_book_info

# 登录Cookie存储路径
COOKIE_STORAGE_PATH = os.path.join(os.path.expanduser("~"), ".neogado_cookies.json")

# 全局浏览器实例复用（暂时禁用，修复跨线程锁问题）
# _global_browser: Browser | None = None
# _global_playwright = None
# _browser_lock = threading.Lock()

# 浏览器配置
BROWSER_ARGS = [
    "--disable-blink-features=AutomationControlled",
    "--disable-infobars",
    "--no-sandbox",
    "--disable-dev-shm-usage",
    "--disable-gpu",
]
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

logger = logging.getLogger(__name__)


def _get_domain_from_url(url: str) -> str:
    """从URL提取域名作为cookie的key"""
    parsed = urlparse(url)
    return parsed.netloc


def _load_cookies(domain: str) -> list:
    """加载指定域名的cookies"""
    if not os.path.exists(COOKIE_STORAGE_PATH):
        return []
    try:
        with open(COOKIE_STORAGE_PATH, "r", encoding="utf-8") as f:
            all_cookies = json.load(f)
        return all_cookies.get(domain, [])
    except Exception as e:
        logger.warning(f"加载cookies失败: {e}")
        return []


def _save_cookies(domain: str, cookies: list) -> None:
    """保存指定域名的cookies"""
    all_cookies = {}
    if os.path.exists(COOKIE_STORAGE_PATH):
        try:
            with open(COOKIE_STORAGE_PATH, "r", encoding="utf-8") as f:
                all_cookies = json.load(f)
        except Exception as e:
            logger.warning(f"读取cookie存储失败: {e}")

    all_cookies[domain] = cookies
    try:
        with open(COOKIE_STORAGE_PATH, "w", encoding="utf-8") as f:
            json.dump(all_cookies, f, ensure_ascii=False, indent=2)
        logger.info(f"已保存 {len(cookies)} 个cookies到 {COOKIE_STORAGE_PATH}")
    except Exception as e:
        logger.error(f"保存cookies失败: {e}")


async def login_to_site(url: str) -> bool:
    """打开浏览器让用户手动登录网站，并保存登录后的cookies"""
    domain = _get_domain_from_url(url)
    logger.info(f"启动登录流程: {domain}")
    try:
        async with async_playwright() as p:
            browser = await p.chromium.launch(
                headless=False,  # 显示浏览器窗口让用户操作
                args=[
                    "--disable-blink-features=AutomationControlled",
                    "--disable-infobars",
                    "--start-maximized",
                ],
            )
            context = await browser.new_context(
                user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
                viewport={"width": 1920, "height": 1080},
                java_script_enabled=True,
            )
            page = await context.new_page()
            await Stealth().apply_stealth_async(page)

            await page.goto(url, wait_until="networkidle", timeout=30000)

            # 等待用户完成登录，直到用户手动关闭浏览器或页面
            logger.info("请在浏览器中完成登录操作，完成后关闭浏览器即可自动保存登录状态")
            await page.wait_for_event("close", timeout=0)  # 无限等待直到页面关闭

            # 保存cookies
            cookies = await context.cookies()
            _save_cookies(domain, cookies)

            await browser.close()
            return True
    except Exception as e:
        logger.error(f"登录流程失败: {e}")
        return False


async def _fetch_with_playwright(url: str, retry_count: int = 0) -> str:
    """使用浏览器引擎抓取页面 (支持动态渲染和绕过基础防爬)"""
    logger.info(f"启动 Playwright 抓取: {url} (尝试第 {retry_count + 1} 次)")
    domain = _get_domain_from_url(url)
    context: BrowserContext | None = None
    page = None
    browser = None
    playwright = None
    try:
        playwright = await async_playwright().start()
        browser = await playwright.chromium.launch(
            headless=True,
            args=BROWSER_ARGS,
        )

        # 加载已保存的cookies
        cookies = _load_cookies(domain)
        context = await browser.new_context(
            user_agent=USER_AGENT,
            viewport={"width": 1920, "height": 1080},
            java_script_enabled=True,
        )
        if cookies:
            logger.info(f"加载了 {len(cookies)} 个已保存的cookies")
            await context.add_cookies(cookies)

        page = await context.new_page()
        await Stealth().apply_stealth_async(page)

        # 拦截不必要的资源
        await page.route(
            "**/*",
            lambda route: (
                route.continue_()
                if route.request.resource_type in ["document", "script", "fetch", "xhr"]
                else route.abort()
            ),
        )

        # 优化等待策略
        try:
            await page.goto(url, wait_until="domcontentloaded", timeout=15000)
            # 动态等待网络空闲，最多2秒
            await page.wait_for_load_state("networkidle", timeout=2000)
        except Exception as e:
            logger.warning(f"页面加载超时，直接读取当前内容: {e}")

        html_content = await page.content()
        return html_content
    except Exception as e:
        logger.error(f"Playwright 抓取失败: {e} ({url})")
        # 失败重试最多1次
        if retry_count < 1:
            logger.info(f"准备重试抓取: {url}")
            return await _fetch_with_playwright(url, retry_count + 1)
        return ""
    finally:
        if page:
            await page.close()
        if context:
            await context.close()
        if browser:
            await browser.close()
        if playwright:
            await playwright.stop()


async def _search_with_playwright(url: str, keyword: str, search_input_sel: str, search_btn_sel: str, retry_count: int = 0) -> str:
    """使用 Playwright 模拟输入和点击进行搜索"""
    logger.info(f"启动 Playwright 模拟搜索: {url}, 关键词: {keyword} (尝试第 {retry_count + 1} 次)")
    domain = _get_domain_from_url(url)
    context: BrowserContext | None = None
    page = None
    browser = None
    playwright = None
    try:
        playwright = await async_playwright().start()
        browser = await playwright.chromium.launch(
            headless=True,
            args=BROWSER_ARGS,
        )

        # 加载已保存的cookies
        cookies = _load_cookies(domain)
        context = await browser.new_context(
            user_agent=USER_AGENT,
            viewport={"width": 1920, "height": 1080},
            java_script_enabled=True,
        )
        if cookies:
            logger.info(f"搜索时加载了 {len(cookies)} 个已保存的cookies")
            await context.add_cookies(cookies)

        page = await context.new_page()
        await Stealth().apply_stealth_async(page)

        # 拦截不必要的资源
        await page.route(
            "**/*",
            lambda route: (
                route.continue_()
                if route.request.resource_type in ["document", "script", "fetch", "xhr"]
                else route.abort()
            ),
        )

        # 优化等待策略
        try:
            await page.goto(url, wait_until="domcontentloaded", timeout=15000)
            await page.wait_for_load_state("networkidle", timeout=2000)
        except Exception as e:
            logger.warning(f"搜索页面加载超时，尝试继续操作: {e}")

        # 模拟输入和点击
        await page.fill(search_input_sel, keyword)
        await page.click(search_btn_sel)

        # 等待页面跳转或局部刷新
        try:
            await page.wait_for_load_state("networkidle", timeout=10000)
        except Exception as e:
            logger.warning(f"搜索结果加载超时，直接读取当前内容: {e}")

        html_content = await page.content()
        return html_content
    except Exception as e:
        logger.error(f"Playwright 搜索失败: {e} ({url})")
        # 失败重试最多1次
        if retry_count < 1:
            logger.info(f"准备重试搜索: {url}")
            return await _search_with_playwright(url, keyword, search_input_sel, search_btn_sel, retry_count + 1)
        return ""
    finally:
        if page:
            await page.close()
        if context:
            await context.close()
        if browser:
            await browser.close()
        if playwright:
            await playwright.stop()


async def fetch_novel_page(url: str) -> str:
    """第一步：抓取网页内容 (Fetch)"""
    logger.info(f"[1/4] 开始抓取网页内容: {url}")
    html = await _fetch_with_playwright(url)
    if html:
        logger.info("✅ 抓取成功！获取到了渲染后的页面内容。")
    else:
        logger.error(f"❌ 抓取失败！请检查目标 URL 是否有效或有反爬风控策略: {url}")
    return html


async def get_toc(url: str, force_refresh: bool = False) -> list:
    """获取小说目录"""
    if not force_refresh:
        cached_catalog = get_cached_catalog(url)
        if cached_catalog:
            logger.info(f"命中目录缓存: {url}")
            return cached_catalog

    from src.rule_generator import ensure_site_rules
    from src.storage import get_rule_filepath, load_local_rules
    from src.models import SiteSchema
    from src.validator import validate_toc_rules

    if not force_refresh:
        rule_filepath = get_rule_filepath(url)
        raw_dict = load_local_rules(rule_filepath)
        if raw_dict:
            site_schema = SiteSchema.model_validate(raw_dict)
            if site_schema.ruleToc:
                html = await _fetch_with_playwright(url)
                if html and validate_toc_rules(html, site_schema.ruleToc.model_dump()):
                    catalog = extract_toc(html, site_schema.ruleToc, url)
                    if catalog:
                        set_cached_catalog(url, catalog)
                        return catalog

    site_schema = await ensure_site_rules(url, force_refresh=force_refresh, expected_type="toc")
    if not site_schema or not site_schema.ruleToc:
        return []
        
    html = await _fetch_with_playwright(url)
    if not html:
        return []
        
    catalog = extract_toc(html, site_schema.ruleToc, url)
    if catalog:
        set_cached_catalog(url, catalog)
        
    return catalog


async def get_chapter_content(url: str, force_refresh: bool = False) -> str:
    """获取章节正文"""
    if not url:
        return "❌ 无效的章节链接"

    if not force_refresh:
        cached_content = get_cached_chapter(url)
        if cached_content:
            logger.info(f"命中章节缓存: {url}")
            return cached_content

    from src.rule_generator import ensure_site_rules
    from src.storage import get_rule_filepath, load_local_rules
    from src.models import SiteSchema
    from src.validator import validate_content_rules

    if not force_refresh:
        rule_filepath = get_rule_filepath(url)
        raw_dict = load_local_rules(rule_filepath)
        if raw_dict:
            site_schema = SiteSchema.model_validate(raw_dict)
            if site_schema.ruleContent:
                html = await _fetch_with_playwright(url)
                if html and validate_content_rules(html, site_schema.ruleContent.model_dump()):
                    content = extract_content(html, site_schema.ruleContent)
                    if content and not content.startswith("❌"):
                        set_cached_chapter(url, content)
                        return content

    site_schema = await ensure_site_rules(url, force_refresh=force_refresh, expected_type="content")
    if not site_schema or not site_schema.ruleContent:
        return "❌ 章节规则获取失败"
        
    html = await _fetch_with_playwright(url)
    if not html:
        return "❌ 章节内容获取失败"
        
    content = extract_content(html, site_schema.ruleContent)
    if content and not content.startswith("❌"):
        set_cached_chapter(url, content)
        
    return content


async def get_book_list(url: str, force_refresh: bool = False) -> list:
    """获取发现页/分类页的书籍列表"""
    from src.rule_generator import ensure_site_rules
    site_schema = await ensure_site_rules(url, force_refresh=force_refresh, expected_type="bookList")
    if not site_schema or not site_schema.ruleBookList:
        return []
        
    html = await _fetch_with_playwright(url)
    if not html:
        return []
        
    return extract_book_list(html, site_schema.ruleBookList, url)


async def get_book_info(url: str, force_refresh: bool = False) -> dict:
    """获取单本书籍的详情信息"""
    # 先检查缓存
    if not force_refresh:
        cached_info = get_cached_book_info(url)
        if cached_info:
            logger.info(f"命中书籍详情缓存: {url}")
            return cached_info

    from src.rule_generator import ensure_site_rules
    site_schema = await ensure_site_rules(url, force_refresh=force_refresh, expected_type="bookInfo")
    if not site_schema or not site_schema.ruleBookInfo:
        return {}

    html = await _fetch_with_playwright(url)
    if not html:
        return {}

    book_info = extract_book_info(html, site_schema.ruleBookInfo, url)
    if book_info:
        set_cached_book_info(url, book_info)

    return book_info


async def search_books(url: str, keyword: str, force_refresh: bool = False) -> list:
    """模拟搜索并获取结果列表"""
    from src.rule_generator import ensure_site_rules
    
    # 确保首页规则已加载（包含 searchActionRule）
    site_schema = await ensure_site_rules(url, force_refresh=force_refresh, expected_type="home")
    
    if not site_schema or not site_schema.searchActionRule or not site_schema.ruleBookList:
        logger.error("缺少搜索交互规则或列表解析规则，无法执行搜索")
        return []
        
    search_rule = site_schema.searchActionRule
    if not search_rule.searchInput or not search_rule.searchButton:
        logger.error("搜索交互规则不完整")
        return []
        
    html = await _search_with_playwright(url, keyword, search_rule.searchInput, search_rule.searchButton)
    if not html:
        return []
        
    return extract_book_list(html, site_schema.ruleBookList, url)
