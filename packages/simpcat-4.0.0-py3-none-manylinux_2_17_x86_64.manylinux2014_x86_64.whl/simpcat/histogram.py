"""Histogram — wraps histogram data for logging."""

from __future__ import annotations

import math
import numbers
from typing import Any

COMPACT_UINT32_MAX = 0xFFFFFFFF
COMPACT_FLOAT32_MAX = 3.4028234663852886e38


def _coerce_float32_edge(value: Any, index: int) -> float:
    if not isinstance(value, numbers.Real):
        raise ValueError(f"bin_edges[{index}] must be a finite Float32 value")
    edge = float(value)
    if not math.isfinite(edge) or abs(edge) > COMPACT_FLOAT32_MAX:
        raise ValueError(f"bin_edges[{index}] must be a finite Float32 value")
    return edge


def _coerce_uint32_count(value: Any, index: int) -> int:
    if isinstance(value, bool) or not isinstance(value, numbers.Integral):
        raise ValueError(f"counts[{index}] must be an integer in [0, {COMPACT_UINT32_MAX}]")
    count = int(value)
    if count < 0 or count > COMPACT_UINT32_MAX:
        raise ValueError(f"counts[{index}] must be an integer in [0, {COMPACT_UINT32_MAX}]")
    return count


class Histogram:
    """Wraps histogram data for logging. Compatible with wandb.Histogram."""

    MAX_BINS = 512

    def __init__(
        self,
        sequence: Any = None,
        np_histogram: tuple | None = None,
        num_bins: int = 64,
    ) -> None:
        if np_histogram is not None:
            counts, bin_edges = np_histogram
            self.counts = list(counts)
            self.bin_edges = list(bin_edges)
        elif sequence is not None:
            import numpy as np
            data = np.asarray(sequence, dtype=np.float64).ravel()
            num_bins = min(num_bins, self.MAX_BINS)
            counts, bin_edges = np.histogram(data, bins=num_bins)
            self.counts = counts.tolist()
            self.bin_edges = bin_edges.tolist()
        else:
            raise ValueError("Either sequence or np_histogram required")

        if len(self.bin_edges) != len(self.counts) + 1:
            raise ValueError(
                f"bin_edges length ({len(self.bin_edges)}) must be "
                f"counts length + 1 ({len(self.counts) + 1})"
            )

        self.bin_edges = [
            _coerce_float32_edge(edge, index)
            for index, edge in enumerate(self.bin_edges)
        ]
        self.counts = [
            _coerce_uint32_count(count, index)
            for index, count in enumerate(self.counts)
        ]
