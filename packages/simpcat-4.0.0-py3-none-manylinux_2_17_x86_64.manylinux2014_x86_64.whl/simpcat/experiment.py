"""Run — wandb-compatible run interface wrapping ReporterClient."""

from __future__ import annotations

import atexit
import datetime
import getpass
import hashlib
from importlib.metadata import PackageNotFoundError, version as package_version
import json
import math
import numbers
import os
import platform
import re
import secrets
import shlex
import subprocess
import sys
import threading
import time
import traceback
import weakref
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from simpcat._constants import (
    DEBUG_LOG,
    DIFF_FILE,
    ENV_RUN_DATA_DIR,
    ENV_HOST,
    ENV_INIT_TIMEOUT,
    ERRORS_LOG,
    FILES_DIR,
    INIT_STATUS_FILE,
    LOGS_DIR,
    MEDIA_DIR,
    METADATA_FILE,
    CONFIG_FILE,
    OUTPUT_LOG,
    ENV_LOCAL_DIR,
    RUN_STATE_FILE,
)
from simpcat.client import ReporterClient
from simpcat.histogram import Histogram
from simpcat.media import Audio, Image
from simpcat.sysmetrics import SystemMetricsCollector

RUN_ID_PATTERN = re.compile(r"[A-Za-z0-9._-]+")
SIMPCAT_DIR_NAME = "simpcat"
DEFAULT_SIMPCAT_DIR_NAME = ".simpcat"

VALID_FINISH_STATUSES = {"finished", "failed", "crashed", "killed"}
_ACTIVE_RUNS_LOCK = threading.Lock()
_ACTIVE_RUNS: dict[int, weakref.ReferenceType["Run"]] = {}
_ORIGINAL_SYS_EXCEPTHOOK: Any | None = None
_ORIGINAL_THREADING_EXCEPTHOOK: Any | None = None
DEFAULT_INIT_TIMEOUT_S = 60.0
REPORTER_SHUTDOWN_GRACE_TIMEOUT_S = 60.0
REPORTER_TERMINATE_TIMEOUT_S = 10.0
REPORTER_KILL_TIMEOUT_S = 5.0
COMPACT_UINT32_MAX = 0xFFFFFFFF
COMPACT_FLOAT32_MAX = 3.4028234663852886e38


class OfflineRunIdUnavailableError(RuntimeError):
    """Raised when an offline run does not have a canonical run ID yet."""


def _resolve_python_sdk_version() -> str:
    try:
        return package_version("simpcat")
    except PackageNotFoundError:
        return "0.0.0"


def _validate_finish_status(status: str) -> str:
    if status not in VALID_FINISH_STATUSES:
        allowed = ", ".join(sorted(VALID_FINISH_STATUSES))
        raise ValueError(f"Unsupported finish status '{status}'. Expected one of: {allowed}")
    return status


def _build_finish_stop(status: str, user_payload: Any | None = None) -> dict[str, Any]:
    status = _validate_finish_status(status)
    return {
        "kind": "finish",
        "at": int(time.time() * 1000),
        "payload": {
            "status": status,
            "userPayload": user_payload,
        },
    }


def _exception_type_name(exc_type: type[BaseException]) -> str:
    module = getattr(exc_type, "__module__", "builtins")
    qualname = getattr(exc_type, "__qualname__", exc_type.__name__)
    if module in {"builtins", "__main__"}:
        return qualname
    return f"{module}.{qualname}"


def _build_exception_stop(
    exc_type: type[BaseException],
    exc_val: BaseException | None,
    exc_tb: Any,
) -> dict[str, Any]:
    message = None
    if exc_val is not None:
        rendered = str(exc_val).strip()
        if rendered:
            message = rendered

    rendered_traceback = "".join(traceback.format_exception(exc_type, exc_val, exc_tb)).strip()
    return {
        "kind": "exception",
        "at": int(time.time() * 1000),
        "payload": {
            "type": _exception_type_name(exc_type),
            "message": message,
            "traceback": rendered_traceback or None,
        },
    }


def _build_stop_for_exception(
    exc_type: type[BaseException],
    exc_val: BaseException | None,
    exc_tb: Any,
) -> dict[str, Any]:
    if issubclass(exc_type, KeyboardInterrupt):
        return _build_finish_stop("killed")
    return _build_exception_stop(exc_type, exc_val, exc_tb)


def _cleanup_dead_active_runs() -> None:
    dead_ids = [run_id for run_id, ref in _ACTIVE_RUNS.items() if ref() is None]
    for run_id in dead_ids:
        _ACTIVE_RUNS.pop(run_id, None)


def _register_active_run(run: "Run") -> None:
    global _ORIGINAL_SYS_EXCEPTHOOK
    global _ORIGINAL_THREADING_EXCEPTHOOK
    with _ACTIVE_RUNS_LOCK:
        _cleanup_dead_active_runs()
        _ACTIVE_RUNS[id(run)] = weakref.ref(run)
        if len(_ACTIVE_RUNS) == 1:
            _ORIGINAL_SYS_EXCEPTHOOK = sys.excepthook
            _ORIGINAL_THREADING_EXCEPTHOOK = threading.excepthook
            sys.excepthook = _run_uncaught_exception_hook
            threading.excepthook = _run_uncaught_thread_exception_hook


def _unregister_active_run(run: "Run") -> None:
    global _ORIGINAL_SYS_EXCEPTHOOK
    global _ORIGINAL_THREADING_EXCEPTHOOK
    with _ACTIVE_RUNS_LOCK:
        _ACTIVE_RUNS.pop(id(run), None)
        _cleanup_dead_active_runs()
        if not _ACTIVE_RUNS:
            if sys.excepthook is _run_uncaught_exception_hook and _ORIGINAL_SYS_EXCEPTHOOK is not None:
                sys.excepthook = _ORIGINAL_SYS_EXCEPTHOOK
            if (
                threading.excepthook is _run_uncaught_thread_exception_hook
                and _ORIGINAL_THREADING_EXCEPTHOOK is not None
            ):
                threading.excepthook = _ORIGINAL_THREADING_EXCEPTHOOK
            _ORIGINAL_SYS_EXCEPTHOOK = None
            _ORIGINAL_THREADING_EXCEPTHOOK = None


def _run_uncaught_exception_hook(
    exc_type: type[BaseException],
    exc_val: BaseException | None,
    exc_tb: Any,
) -> None:
    with _ACTIVE_RUNS_LOCK:
        _cleanup_dead_active_runs()
        runs = [ref() for ref in _ACTIVE_RUNS.values()]
        original_hook = _ORIGINAL_SYS_EXCEPTHOOK or sys.__excepthook__

    for run in runs:
        if run is None:
            continue
        try:
            run._finish_for_exception(exc_type, exc_val, exc_tb)
        except BaseException:
            pass

    original_hook(exc_type, exc_val, exc_tb)


def _run_uncaught_thread_exception_hook(args: Any) -> None:
    exc_type = getattr(args, "exc_type", None)
    exc_val = getattr(args, "exc_value", None)
    exc_tb = getattr(args, "exc_traceback", None)

    with _ACTIVE_RUNS_LOCK:
        _cleanup_dead_active_runs()
        runs = [ref() for ref in _ACTIVE_RUNS.values()]
        original_hook = (
            _ORIGINAL_THREADING_EXCEPTHOOK
            or getattr(threading, "__excepthook__", None)
        )

    if exc_type is not None:
        for run in runs:
            if run is None:
                continue
            try:
                run._finish_for_exception(exc_type, exc_val, exc_tb)
            except BaseException:
                pass

    if original_hook is not None:
        original_hook(args)


def _read_json_file(path: Path) -> dict[str, Any] | None:
    """Read and parse a JSON file as a dict. Returns None on any error or non-object JSON."""
    try:
        data = json.loads(path.read_text())
        return data if isinstance(data, dict) else None
    except (json.JSONDecodeError, OSError):
        return None


def _write_json_file(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, sort_keys=True))


def _is_remote_uri(path: str) -> bool:
    return bool(re.match(r"^[A-Za-z][A-Za-z0-9+.-]*://", path))


def _join_uri(base: str, *parts: str) -> str:
    return "/".join([base.rstrip("/"), *(part.strip("/") for part in parts)])


def _read_json_ref(path: Path | str) -> dict[str, Any] | None:
    if isinstance(path, Path):
        return _read_json_file(path)

    try:
        import fsspec  # type: ignore[import-not-found]
    except ImportError as exc:
        raise RuntimeError(
            f"Remote simpcat dir {path!r} requires fsspec to read run state."
        ) from exc

    try:
        with fsspec.open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except FileNotFoundError:
        return None
    except Exception as exc:
        raise RuntimeError(f"Failed to read simpcat run state from {path!r}") from exc

    return data if isinstance(data, dict) else None


def _write_json_ref(path: Path | str, data: dict[str, Any]) -> None:
    if isinstance(path, Path):
        _write_json_file(path, data)
        return

    try:
        import fsspec  # type: ignore[import-not-found]
    except ImportError as exc:
        raise RuntimeError(
            f"Remote simpcat dir {path!r} requires fsspec to write run state."
        ) from exc

    with fsspec.open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, sort_keys=True)


def _valid_run_id(value: Any) -> str | None:
    return value if isinstance(value, str) and RUN_ID_PATTERN.fullmatch(value) else None


def _run_id_from_state(saved: dict[str, Any]) -> str | None:
    if saved.get("version") is not None:
        return _valid_run_id(saved.get("run_id"))
    return None


def _close_reporter_process(proc: Any) -> None:
    try:
        stdin = getattr(proc, "stdin", None)
        if stdin:
            stdin.close()
    except Exception:
        pass

    try:
        proc.wait(timeout=REPORTER_SHUTDOWN_GRACE_TIMEOUT_S)
        return
    except subprocess.TimeoutExpired:
        pass
    except Exception:
        return

    try:
        proc.terminate()
        proc.wait(timeout=REPORTER_TERMINATE_TIMEOUT_S)
        return
    except subprocess.TimeoutExpired:
        pass
    except Exception:
        return

    try:
        proc.kill()
        proc.wait(timeout=REPORTER_KILL_TIMEOUT_S)
    except Exception:
        pass


def _validate_metric_float32(value: float, label: str) -> float:
    if not math.isfinite(value) or abs(value) > COMPACT_FLOAT32_MAX:
        raise ValueError(
            f"{label} must be finite and representable as a Float32 metric value."
        )
    return value


def _coerce_metric_step(value: Any, label: str) -> int:
    if isinstance(value, bool) or not isinstance(value, numbers.Integral):
        raise ValueError(f"{label} must be an integer in [0, {COMPACT_UINT32_MAX}].")
    step = int(value)
    if step < 0:
        raise ValueError(f"{label} must be >= 0.")
    if step > COMPACT_UINT32_MAX:
        raise ValueError(f"{label} must be an integer in [0, {COMPACT_UINT32_MAX}].")
    return step


def _coerce_metric_scalar(value: Any) -> float | None:
    """Accept Python numerics plus scalar-like values such as numpy/tensor scalars."""
    if isinstance(value, numbers.Real):
        return _validate_metric_float32(float(value), "simpcat.log() scalar metric")

    item = getattr(value, "item", None)
    if callable(item):
        try:
            coerced = item()
        except (TypeError, ValueError, RuntimeError):
            return None
        if isinstance(coerced, numbers.Real):
            return _validate_metric_float32(float(coerced), "simpcat.log() scalar metric")

    return None


def _unsupported_log_value_message(key: str, value: Any) -> str:
    return (
        "simpcat.log() only accepts scalar metrics, Histogram, Audio, Image, "
        f"or lists of Audio/Image values. Key {key!r} received {type(value).__name__}."
    )


def _default_simpcat_base_dir() -> Path:
    try:
        return Path.cwd()
    except OSError:
        return Path.home()


def _find_simpcat_dir(base_dir: str | os.PathLike[str] | None = None) -> Path:
    """Find or create the local simpcat run-data directory.

    Explicit ``base_dir`` follows wandb-style ``dir`` semantics: simpcat stores
    local run state under ``<base_dir>/simpcat``. Without an explicit base, the
    legacy SIMPCAT_RUN_DATA_DIR override is honored as the exact run-data dir;
    otherwise the default is ``<cwd>/.simpcat``.
    """
    if base_dir is not None:
        p = Path(base_dir).expanduser() / SIMPCAT_DIR_NAME
        p.mkdir(parents=True, exist_ok=True)
        return p

    env_dir = os.environ.get(ENV_RUN_DATA_DIR)
    if env_dir:
        p = Path(env_dir).expanduser()
        p.mkdir(parents=True, exist_ok=True)
        return p

    simpcat_dir = _default_simpcat_base_dir() / DEFAULT_SIMPCAT_DIR_NAME
    simpcat_dir.mkdir(parents=True, exist_ok=True)
    return simpcat_dir


def _find_resume_simpcat_dir(base_dir: str | os.PathLike[str] | None = None) -> Path | None:
    """Find the local simpcat directory eligible for auto-resume state.

    Kept as a compatibility helper for tests and callers that inspect the
    storage location directly.
    """
    return _find_simpcat_dir(base_dir)


def _remote_local_simpcat_dir(save_dir: str) -> Path:
    root = os.environ.get(ENV_LOCAL_DIR)
    if root:
        base = Path(root).expanduser()
    else:
        base = _find_simpcat_dir()

    digest = hashlib.sha256(save_dir.encode("utf-8")).hexdigest()[:24]
    simpcat_dir = base / "remote" / digest
    simpcat_dir.mkdir(parents=True, exist_ok=True)
    return simpcat_dir


@dataclass(frozen=True)
class _RunStorage:
    local_simpcat_dir: Path
    run_state_path: Path | str


def _resolve_run_storage(
    save_dir: str | os.PathLike[str] | None,
) -> _RunStorage:
    if save_dir is None:
        simpcat_dir = _find_simpcat_dir()
        return _RunStorage(
            local_simpcat_dir=simpcat_dir,
            run_state_path=simpcat_dir / RUN_STATE_FILE,
        )

    save_dir_str = os.fspath(save_dir)
    if _is_remote_uri(save_dir_str):
        return _RunStorage(
            local_simpcat_dir=_remote_local_simpcat_dir(save_dir_str),
            run_state_path=_join_uri(save_dir_str, SIMPCAT_DIR_NAME, RUN_STATE_FILE),
        )

    simpcat_dir = _find_simpcat_dir(save_dir_str)
    return _RunStorage(
        local_simpcat_dir=simpcat_dir,
        run_state_path=simpcat_dir / RUN_STATE_FILE,
    )


def _create_run_dir(run_dir_suffix: str, simpcat_dir: Path | None = None) -> Path:
    """Create the run directory structure inside simpcat/."""
    if simpcat_dir is None:
        simpcat_dir = _find_simpcat_dir()
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir = simpcat_dir / f"run-{timestamp}-{run_dir_suffix}"

    run_dir.mkdir(parents=True, exist_ok=True)
    (run_dir / FILES_DIR).mkdir(exist_ok=True)
    (run_dir / LOGS_DIR).mkdir(exist_ok=True)
    (run_dir / MEDIA_DIR).mkdir(exist_ok=True)

    return run_dir


def _update_symlinks(simpcat_dir: Path, run_dir: Path) -> None:
    """Update latest-run and debug.log symlinks atomically."""
    latest_link = simpcat_dir / "latest-run"
    tmp_link = simpcat_dir / f".tmp-latest-{os.getpid()}"
    try:
        tmp_link.symlink_to(run_dir)
        os.replace(str(tmp_link), str(latest_link))
    except OSError:
        pass

    debug_link = simpcat_dir / DEBUG_LOG
    tmp_debug = simpcat_dir / f".tmp-debug-{os.getpid()}"
    try:
        tmp_debug.symlink_to(latest_link / LOGS_DIR / DEBUG_LOG)
        os.replace(str(tmp_debug), str(debug_link))
    except OSError:
        pass


def _collect_sys_info() -> dict[str, Any]:
    """Collect system metadata (hostname, OS, GPU, CPU, program, args, workdir)."""
    argv = list(sys.argv) if sys.argv else []
    try:
        workdir = str(Path.cwd())
    except OSError:
        workdir = ""
    info: dict[str, Any] = {
        "hostname": platform.node(),
        "os": platform.platform(),
        "python": platform.python_version(),
        "cpu_count": os.cpu_count(),
        "program": argv[0] if argv else "",
        "args": argv[1:] if len(argv) > 1 else [],
        "command": shlex.join(argv) if argv else "",
        "workdir": workdir,
    }

    try:
        info["username"] = getpass.getuser()
    except Exception:
        pass

    try:
        result = subprocess.run(
            ["nvidia-smi", "--query-gpu=name", "--format=csv,noheader"],
            capture_output=True, text=True, timeout=5,
        )
        if result.returncode == 0:
            gpus = result.stdout.strip().split("\n")
            info["gpu"] = gpus[0] if gpus else None
            info["gpu_count"] = len(gpus)
    except (subprocess.SubprocessError, FileNotFoundError, OSError):
        pass

    return info


def _write_metadata(
    run_dir: Path,
    run_id: str | None,
    run_name: str,
    project: str,
    reporter_pid: int,
    python_sdk_version: str,
) -> tuple[dict[str, Any], dict[str, Any] | None]:
    """Write simpcat-metadata.json with system and git info. Returns (sys_info, git_info)."""
    sys_info = _collect_sys_info()
    git_info: dict[str, Any] | None = None
    metadata: dict[str, Any] = {
        "run_name": run_name,
        "project": project,
        "reporter_pid": reporter_pid,
        "python_sdk_version": python_sdk_version,
        "generation": 0,
        "started_at": datetime.datetime.now().isoformat(),
        **sys_info,
    }
    if run_id is not None:
        metadata["run_id"] = run_id

    try:
        from simpcat.git_info import get_git_info
        git_info = get_git_info()
        if git_info:
            metadata["git"] = git_info
    except Exception:
        pass

    (run_dir / FILES_DIR / METADATA_FILE).write_text(
        json.dumps(metadata, indent=2)
    )
    return sys_info, git_info


def _write_git_diff(run_dir: Path) -> None:
    """Write git diff to files/diff.patch."""
    try:
        result = subprocess.run(
            ["git", "diff", "HEAD"], capture_output=True, text=True, timeout=10,
        )
        if result.returncode == 0 and result.stdout.strip():
            (run_dir / FILES_DIR / DIFF_FILE).write_text(result.stdout)
    except (subprocess.SubprocessError, FileNotFoundError, OSError):
        pass


class Config:
    """Dict-like config object that syncs updates to the reporter immediately.

    Supports both dict-style (config["lr"]) and attribute-style (config.lr)
    access for wandb compatibility. Every write immediately sends the full
    config to the reporter and writes config.json to the run directory.
    """

    def __init__(self, run: Run) -> None:
        object.__setattr__(self, "_run", run)
        object.__setattr__(self, "_data", {})

    def update(self, data: dict[str, Any]) -> None:
        self._data.update(data)
        if self._run._client is not None:
            self._run._client.send_config(self._data)
        self._run._write_config_file()

    def setdefaults(self, data: dict[str, Any]) -> None:
        """Set default values without overwriting existing keys. Matches wandb.config.setdefaults()."""
        changed = False
        for k, v in data.items():
            if k not in self._data:
                self._data[k] = v
                changed = True
        if changed:
            if self._run._client is not None:
                self._run._client.send_config(self._data)
            self._run._write_config_file()

    def keys(self) -> Any:
        """Return config keys."""
        return self._data.keys()

    def items(self) -> Any:
        """Return config key-value pairs."""
        return self._data.items()

    def get(self, key: str, default: Any = None) -> Any:
        """Get a value by key with an optional default."""
        return self._data.get(key, default)

    def __getitem__(self, key: str) -> Any:
        return self._data[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self._data[key] = value
        if self._run._client is not None:
            self._run._client.send_config(self._data)
        self._run._write_config_file()

    def __getattr__(self, key: str) -> Any:
        try:
            return self._data[key]
        except KeyError:
            raise AttributeError(f"Config has no attribute {key!r}")

    def __setattr__(self, key: str, value: Any) -> None:
        self._data[key] = value
        if self._run._client is not None:
            self._run._client.send_config(self._data)
        self._run._write_config_file()

    def __contains__(self, key: str) -> bool:
        return key in self._data

    def to_dict(self) -> dict[str, Any]:
        return dict(self._data)


class Summary:
    """Dict-like run summary object that syncs to the reporter.

    Tracks per-run aggregate values (e.g., best_val_loss). Matches wandb.summary.
    Accessible as run.summary or simpcat.summary. Supports both dict-style
    and attribute-style access, including deletion.
    """

    def __init__(self, run: Run) -> None:
        object.__setattr__(self, "_run", run)
        object.__setattr__(self, "_data", {})

    def update(self, data: dict[str, Any]) -> None:
        """Merge a dict into the summary."""
        self._data.update(data)
        if self._run._client is not None:
            self._run._client.send_summary(self._data)

    def keys(self) -> Any:
        """Return summary keys."""
        return self._data.keys()

    def items(self) -> Any:
        """Return summary key-value pairs."""
        return self._data.items()

    def get(self, key: str, default: Any = None) -> Any:
        """Get a value by key with an optional default."""
        return self._data.get(key, default)

    def __getitem__(self, key: str) -> Any:
        return self._data[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self._data[key] = value
        if self._run._client is not None:
            self._run._client.send_summary(self._data)

    def __getattr__(self, key: str) -> Any:
        try:
            return self._data[key]
        except KeyError:
            raise AttributeError(f"Summary has no attribute {key!r}")

    def __setattr__(self, key: str, value: Any) -> None:
        self._data[key] = value
        if self._run._client is not None:
            self._run._client.send_summary(self._data)

    def __delitem__(self, key: str) -> None:
        del self._data[key]
        if self._run._client is not None:
            self._run._client.send_summary(self._data)

    def __delattr__(self, key: str) -> None:
        try:
            del self._data[key]
        except KeyError:
            raise AttributeError(f"Summary has no attribute {key!r}")
        if self._run._client is not None:
            self._run._client.send_summary(self._data)

    def __contains__(self, key: str) -> bool:
        return key in self._data

    def to_dict(self) -> dict[str, Any]:
        return dict(self._data)


class Run:
    """Manages a single training run's connection to the simpcat reporter.

    Provides the core wandb.Run-like interface: log(), finish(), config,
    summary, context manager.

    Run identity is the canonical run ID. With default ``resume="auto"``
    semantics, SimpCat stores that ID in ``run.json`` under the run-data
    directory and reuses it for later runs that use the same directory. The
    default run-data directory is ``./.simpcat``; an explicit ``dir`` uses
    ``dir/simpcat``.
    """

    def __init__(
        self,
        project: str,
        name: str | None = None,
        config: dict[str, Any] | None = None,
        auto_expire_seconds: int | None = None,
        tags: dict[str, str] | None = None,
        notes: str | None = None,
        group: str | None = None,
        job_type: str | None = None,
        system_metrics: bool = True,
        system_metrics_interval: float = 15.0,
        capture_output: bool = False,
        resume: str | bool | None = None,
        dir: str | os.PathLike[str] | None = None,
        fork_from: str | None = None,
        fork_step: int | None = None,
    ) -> None:
        self._project = project
        self._name = name or f"run-{secrets.token_hex(4)}"
        self._auto_expire_seconds = auto_expire_seconds
        self._tags = tags or {}
        if "user" not in self._tags:
            try:
                self._tags["user"] = getpass.getuser()
            except Exception:
                pass
        self._notes = notes
        self._group = group
        self._job_type = job_type
        self._storage = _resolve_run_storage(dir)

        # Normalize resume mode: bool → string, validate
        if resume is True:
            self._resume: str | None = "allow"
        elif resume is False:
            self._resume = None
        elif resume is None:
            # Resume the run id recorded in the run-data dir unless the caller
            # explicitly opts out with resume=False.
            self._resume = "auto"
        elif isinstance(resume, str):
            valid_modes = ("must", "allow", "never", "auto")
            if resume not in valid_modes:
                raise ValueError(
                    f"Invalid resume mode {resume!r}. Must be one of: {', '.join(valid_modes)}"
                )
            self._resume = resume
        else:
            raise ValueError(f"Invalid resume type: {type(resume)}")

        self._run_id: str | None = None
        run_dir_suffix = secrets.token_urlsafe(8).replace("-", "_")

        # Forked runs are explicit fresh continuations, not resumptions.
        if resume is None and fork_from is not None:
            self._resume = None

        # Resume is scoped to the run-data dir. The run id is durable
        # experiment identity; the display name is not used for identity.
        saved = None
        saved_run_id = None
        if self._resume in {"auto", "allow", "must", "never"}:
            saved = _read_json_ref(self._storage.run_state_path)
            if saved is not None:
                saved_run_id = _run_id_from_state(saved)
                if saved_run_id is not None:
                    self._run_id = saved_run_id
        if self._resume == "auto":
            self._resume = "allow"
        if self._resume == "must" and saved_run_id is None:
            raise ValueError(
                f"resume='must' requires a valid {RUN_STATE_FILE} in the run-data directory"
            )
        if self._resume == "never" and saved_run_id is not None:
            raise ValueError(
                f"resume='never' refuses to overwrite existing {RUN_STATE_FILE} state"
            )

        self._resumed = False
        self._server_config: dict[str, Any] | None = None

        # fork_from uses the canonical Convex run document id so the backend
        # stores a real foreign-key-like reference.
        # Fork validation
        if fork_from is not None and fork_step is None:
            raise ValueError("fork_step is required when fork_from is set")
        if fork_step is not None and fork_from is None:
            raise ValueError("fork_from is required when fork_step is set")
        if fork_from is not None and self._resume is not None:
            raise ValueError("Cannot combine fork_from with resume=True")
        if fork_step is not None:
            fork_step = _coerce_metric_step(fork_step, "fork_step")

        self._fork_from = fork_from
        self._initial_step = fork_step

        self._client: ReporterClient | None = None
        self._current_step = fork_step if fork_step is not None else 0
        self._uncommitted: dict[str, Any] = {}
        self._uncommitted_step: int | None = None
        self._uncommitted_next_step: int | None = None
        self._metric_definitions: dict[str, dict[str, Any]] = {}
        self._lock = threading.Lock()
        self._finish_lock = threading.Lock()
        self._finished = False
        self._reporter_proc: Any = None
        self._error_watch_stop: threading.Event | None = None
        self._error_watcher: threading.Thread | None = None
        self._sysmetrics: SystemMetricsCollector | None = None
        self._capture: Any = None
        self._python_sdk_version = _resolve_python_sdk_version()
        self.config = Config(self)
        self.summary = Summary(self)

        # Create run directory structure
        self._run_dir = _create_run_dir(
            self._run_id or run_dir_suffix,
            self._storage.local_simpcat_dir,
        )
        self._media_dir = str(self._run_dir / MEDIA_DIR)

        # Update symlinks
        _update_symlinks(self._run_dir.parent, self._run_dir)

        # Spawn per-run reporter
        from simpcat.reporter import spawn_reporter
        self._reporter_proc, self._socket_path = spawn_reporter(
            self._run_dir, self._run_id
        )

        try:
            # Write metadata (needs reporter_pid) — also captures git info
            self._sys_info, git_info = _write_metadata(
                self._run_dir, self._run_id, self._name, self._project,
                self._reporter_proc.pid,
                self._python_sdk_version,
            )

            # Write git diff
            _write_git_diff(self._run_dir)

            # Connect client (eagerly — dynamic metric extension means no lazy init)
            self._client = ReporterClient(
                project=self._project,
                name=self._name,
                socket_path=self._socket_path,
                python_sdk_version=self._python_sdk_version,
                auto_expire_seconds=self._auto_expire_seconds,
                tags=self._tags,
                notes=self._notes,
                group=self._group,
                job_type=self._job_type,
                resume=self._resume,
                config=config,
                fork_from=self._fork_from,
                fork_step=self._initial_step,
                sys_info=self._sys_info,
                git_info=git_info,
            )

            # Wait for reporter to confirm init succeeded
            self._wait_for_init()
            self._write_run_state()

            # Start error log watcher thread
            self._error_watch_stop = threading.Event()
            self._error_watcher = threading.Thread(
                target=self._tail_error_log,
                daemon=True,
                name="simpcat-error-watcher",
            )
            self._error_watcher.start()

            # Build merged config: server config (resume base) → git → sys → user
            if self._server_config:
                self.config._data.update(self._server_config)

            if config:
                self.config._data.update(config)

            # Send a single merged config POST (init already bundled the user's
            # config atomically, but git info was added after init so we need
            # one POST with the full merged config).
            if self.config._data and self._client is not None:
                self._client.send_config(self.config._data)
                self._write_config_file()

            # Start system metrics collection
            if system_metrics:
                self._sysmetrics = SystemMetricsCollector(
                    self,
                    interval=system_metrics_interval,
                )

            # Console output capture
            if capture_output:
                try:
                    from simpcat.capture import OutputCapture
                    self._capture = OutputCapture(
                        self._run_dir / FILES_DIR / OUTPUT_LOG,
                    )
                    self._capture.start()
                except Exception:
                    pass

            # Print run URL for quick access (wandb-compatible)
            if auto_expire_seconds is None:
                print(f"simpcat: Run {self._name} - {self.url}")
        except Exception:
            self._cleanup_failed_init()
            raise

        _register_active_run(self)
        atexit.register(self.finish)

    @property
    def id(self) -> str:
        """Run ID."""
        if self._run_id is None:
            raise OfflineRunIdUnavailableError(
                "simpcat: offline run has no run_id until `simpcat sync`"
            )
        return self._run_id

    @property
    def name(self) -> str:
        """Display name. Writable — setting it updates the server."""
        return self._name

    @name.setter
    def name(self, value: str) -> None:
        self._name = value
        if self._client is not None:
            self._client.send_update({"name": value})

    @property
    def tags(self) -> dict[str, str]:
        """Tags dict. Writable — assign a dict to update."""
        return dict(self._tags)

    @tags.setter
    def tags(self, value: dict[str, str]) -> None:
        self._tags = dict(value)
        if self._client is not None:
            self._client.send_update({"tags": self._tags})

    @property
    def notes(self) -> str | None:
        """Free-text notes. Writable."""
        return self._notes

    @notes.setter
    def notes(self, value: str | None) -> None:
        self._notes = value
        if self._client is not None:
            self._client.send_update({"notes": value})

    @property
    def project(self) -> str:
        """Project name."""
        return self._project

    @property
    def group(self) -> str | None:
        """Group name."""
        return self._group

    @property
    def job_type(self) -> str | None:
        """Job type label."""
        return self._job_type

    @property
    def step(self) -> int:
        """Current global step counter."""
        return self._current_step

    @property
    def dir(self) -> str:
        """Path to the run directory."""
        return str(self._run_dir)

    @property
    def resumed(self) -> bool:
        """Whether this run was resumed from a previous run."""
        return self._resumed

    @property
    def url(self) -> str | None:
        """URL to the run page on the web UI."""
        if self._run_id is None:
            return None
        from simpcat._constants import DEFAULT_HOST
        host = os.environ.get(ENV_HOST, DEFAULT_HOST)
        if host.startswith("http://") or host.startswith("https://"):
            base = host.rstrip("/")
        elif host.startswith("localhost") or host.startswith("127.0.0.1") or host.startswith("[::1]"):
            base = f"http://{host}"
        else:
            base = f"https://{host}"
        return f"{base}/run/{self._run_id}"

    def _wait_for_init(self, timeout: float = DEFAULT_INIT_TIMEOUT_S) -> None:
        """Poll for reporter init status file. Raises on failure or timeout."""
        status_file = self._run_dir / INIT_STATUS_FILE
        env_timeout = os.environ.get(ENV_INIT_TIMEOUT)
        if env_timeout is not None:
            timeout = float(env_timeout)

        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if status_file.exists():
                result = _read_json_file(status_file)
                if result is not None:
                    if result.get("ok"):
                        run_id = _valid_run_id(result.get("run_id")) or _valid_run_id(
                            result.get("runId")
                        )
                        if run_id is not None:
                            self._run_id = run_id
                        # Restore state from resume data if present
                        if result.get("resumed"):
                            self._resumed = True
                            if "nextImplicitStep" in result:
                                self._current_step = _coerce_metric_step(
                                    int(result["nextImplicitStep"]),
                                    "nextImplicitStep",
                                )
                            elif "currentStep" in result:
                                self._current_step = _coerce_metric_step(
                                    int(result["currentStep"]),
                                    "currentStep",
                                )
                            if "metricNames" in result and result["metricNames"] and self._client is not None:
                                names = result["metricNames"]
                                self._client._metric_names = list(names)
                                self._client._name_to_idx = {n: i for i, n in enumerate(names)}
                            if "metricDefinitions" in result and result["metricDefinitions"]:
                                self._metric_definitions = result["metricDefinitions"]
                            if "config" in result and result["config"]:
                                self._server_config = result["config"]
                            if "summary" in result and result["summary"]:
                                for key, val in result["summary"].items():
                                    if isinstance(val, dict) and "last" in val:
                                        self.summary._data[key] = val["last"]
                                    elif isinstance(val, (int, float)):
                                        self.summary._data[key] = val
                        return
                    error = result.get("error", "unknown error")
                    raise RuntimeError(
                        f"simpcat: reporter failed to initialize run: {error}"
                    )
            time.sleep(0.1)

        raise RuntimeError(
            f"simpcat: reporter did not confirm init within {timeout}s — "
            f"check {self._run_dir / LOGS_DIR / DEBUG_LOG}"
        )

    def _write_run_state(self) -> None:
        if self._run_id is None:
            return
        _write_json_ref(
            self._storage.run_state_path,
            {
                "version": 1,
                "run_id": self._run_id,
                "project": self._project,
                "name": self._name,
            },
        )

    def _tail_error_log(self) -> None:
        """Background thread that tails errors.log and emits warnings."""
        import warnings
        errors_path = self._run_dir / LOGS_DIR / ERRORS_LOG
        pos = 0
        while not self._error_watch_stop.wait(timeout=1.0):
            try:
                if errors_path.exists():
                    with open(errors_path) as f:
                        f.seek(pos)
                        for line in f:
                            line = line.strip()
                            if line:
                                # Extract message after tab-separated timestamp
                                parts = line.split("\t", 1)
                                msg = parts[1] if len(parts) > 1 else line
                                warnings.warn(f"simpcat reporter: {msg}", stacklevel=1)
                        pos = f.tell()
            except OSError:
                pass

    def _record_sdk_diagnostic(
        self,
        code: str,
        message: str,
        details: dict[str, Any] | None = None,
    ) -> None:
        client = self._client
        if client is None:
            return
        try:
            client.send_diagnostic(
                severity="error",
                code=code,
                message=message,
                details=details,
            )
        except Exception:
            pass

    def _unsupported_log_value_error(self, key: str, value: Any) -> TypeError:
        message = _unsupported_log_value_message(key, value)
        self._record_sdk_diagnostic(
            "python_sdk.invalid_log_value",
            message,
            {
                "key": key,
                "value_type": type(value).__name__,
            },
        )
        return TypeError(message)

    def _write_config_file(self) -> None:
        """Write config.json to run dir."""
        try:
            config_path = self._run_dir / FILES_DIR / CONFIG_FILE
            config_path.write_text(json.dumps(self.config._data, indent=2, default=str))
        except OSError:
            pass

    def log(self, data: dict[str, Any], step: int | None = None, commit: bool | None = None) -> None:
        """Log metrics and/or media. Matches wandb.log() interface.

        Args:
            data: Dict of metric names to values (scalars, Audio, Image,
                or lists of media objects).
            step: Explicit step. If None, uses auto-incrementing counter.
            commit: Controls when metrics are flushed. None (default) means
                True when step is None, False when step is provided.
                True flushes all buffered and current metrics and advances
                the step counter. False buffers scalars until the next
                commit=True call. Media is sent immediately regardless.
        """
        if commit is None:
            commit = step is None
        with self._lock:
            if self._finished:
                message = "Cannot log to a finished simpcat run"
                raise RuntimeError(message)

            effective_step = (
                _coerce_metric_step(step, "step")
                if step is not None
                else _coerce_metric_step(self._current_step, "current step")
            )
            next_step = (
                _coerce_metric_step(self._current_step, "next step")
                if step is not None
                else _coerce_metric_step(self._current_step + 1, "next implicit step")
            )
            if not commit:
                normalized_entries: list[tuple[str, str, Any]] = []
                for key, value in data.items():
                    scalar = _coerce_metric_scalar(value)
                    if scalar is not None:
                        normalized_entries.append((key, "scalar", scalar))
                    elif isinstance(value, Histogram):
                        normalized_entries.append((key, "histogram", value))
                    elif isinstance(value, (Audio, Image)):
                        normalized_entries.append((key, "media", [(key, value)]))
                    elif isinstance(value, list):
                        media_items: list[tuple[str, Audio | Image]] = []
                        for i, item in enumerate(value):
                            item_key = f"{key}/{i}" if len(value) > 1 else key
                            if not isinstance(item, (Audio, Image)):
                                raise self._unsupported_log_value_error(item_key, item)
                            media_items.append((item_key, item))
                        normalized_entries.append((key, "media", media_items))
                    else:
                        raise self._unsupported_log_value_error(key, value)

                for key, kind, normalized in normalized_entries:
                    if kind == "scalar":
                        if self._uncommitted:
                            if (
                                self._uncommitted_step != effective_step
                                or self._uncommitted_next_step != next_step
                            ):
                                message = (
                                    "Cannot buffer scalars for multiple steps before commit"
                                )
                                self._record_sdk_diagnostic(
                                    "python_sdk.invalid_log_sequence",
                                    message,
                                    {
                                        "existing_step": self._uncommitted_step,
                                        "new_step": effective_step,
                                    },
                                )
                                raise ValueError(message)
                        else:
                            self._uncommitted_step = effective_step
                            self._uncommitted_next_step = next_step
                        self._uncommitted[key] = normalized
                    elif kind == "histogram":
                        if self._client is not None:
                            self._client.send_histogram(
                                effective_step,
                                key,
                                normalized,
                                next_step=self._current_step,
                            )
                    elif kind == "media":
                        media_files = [
                            self._stage_media(effective_step, item_key, item)
                            for item_key, item in normalized
                        ]
                        if media_files and self._client is not None:
                            self._client.send_media(
                                effective_step,
                                media_files,
                                next_step=self._current_step,
                            )
                return

            # commit=True: merge buffered data with current data
            merged = {**self._uncommitted, **data}
            buffered_step = self._uncommitted_step
            buffered_next_step = self._uncommitted_next_step

            if buffered_step is not None:
                if step is not None and step != buffered_step:
                    message = (
                        "Cannot flush buffered scalars with a different explicit step"
                    )
                    self._record_sdk_diagnostic(
                        "python_sdk.invalid_log_sequence",
                        message,
                        {
                            "buffered_step": buffered_step,
                            "flush_step": step,
                        },
                    )
                    raise ValueError(message)
                effective_step = buffered_step
                next_step = (
                    buffered_next_step
                    if buffered_next_step is not None
                    else next_step
                )
                effective_step = _coerce_metric_step(effective_step, "buffered step")
                next_step = _coerce_metric_step(next_step, "next step")

            normalized_entries: list[tuple[str, str, Any]] = []
            for key, value in merged.items():
                scalar = _coerce_metric_scalar(value)
                if scalar is not None:
                    normalized_entries.append((key, "scalar", scalar))
                elif isinstance(value, Histogram):
                    normalized_entries.append((key, "histogram", value))
                elif isinstance(value, Audio):
                    normalized_entries.append((key, "media", [(key, value)]))
                elif isinstance(value, Image):
                    normalized_entries.append((key, "media", [(key, value)]))
                elif isinstance(value, list):
                    media_items: list[tuple[str, Audio | Image]] = []
                    for i, item in enumerate(value):
                        item_key = f"{key}/{i}" if len(value) > 1 else key
                        if not isinstance(item, (Audio, Image)):
                            raise self._unsupported_log_value_error(item_key, item)
                        media_items.append((item_key, item))
                    normalized_entries.append((key, "media", media_items))
                else:
                    raise self._unsupported_log_value_error(key, value)

            scalars: dict[str, float] = {}
            histograms: list[tuple[str, Histogram]] = []
            media_files: list[dict[str, Any]] = []

            for key, kind, normalized in normalized_entries:
                if kind == "scalar":
                    scalars[key] = normalized
                elif kind == "histogram":
                    histograms.append((key, normalized))
                elif kind == "media":
                    for item_key, item in normalized:
                        media_files.append(self._stage_media(effective_step, item_key, item))

            self._uncommitted = {}
            self._uncommitted_step = None
            self._uncommitted_next_step = None

            if self._client is not None:
                for key, histogram in histograms:
                    self._client.send_histogram(
                        effective_step,
                        key,
                        histogram,
                        next_step=next_step,
                    )

            if scalars and self._client is not None:
                self._client.send_step(effective_step, scalars, next_step=next_step)

            if media_files and self._client is not None:
                self._client.send_media(effective_step, media_files, next_step=next_step)

            if step is None:
                self._current_step += 1

    def define_metric(self, name: str, step_metric: str | None = None, summary: str | None = None, **kwargs: Any) -> None:
        """Define metric metadata (custom x-axis, summary aggregation).

        Args:
            name: The metric name (e.g., "val_loss").
            step_metric: Another metric to use as x-axis (e.g., "epoch").
            summary: Aggregation type for run summary: "min", "max", "last", "mean", or "best" (resolves to min/max based on goal).
        """
        definition: dict[str, Any] = {}
        if step_metric is not None:
            definition["step_metric"] = step_metric
        if summary is not None:
            definition["summary"] = summary
        if not definition:
            return
        self._metric_definitions[name] = definition
        if self._client is not None:
            self._client.send_define_metric(name, definition)

    def _stage_media(self, step: int, key: str, media: Audio | Image) -> dict[str, Any]:
        """Write media to media dir and return file descriptor dict."""
        safe_key = key.replace("/", "__")
        if isinstance(media, Audio):
            filename = f"{step}_{safe_key}.{media.stage_extension()}"
            path = os.path.join(self._media_dir, filename)
            media.save(path)
            return {
                "path": path,
                "key": key,
                "media_type": "audio",
                "caption": media.caption,
                "sample_rate": media.sample_rate,
            }
        else:
            filename = f"{step}_{safe_key}.{media.stage_extension()}"
            path = os.path.join(self._media_dir, filename)
            media.save(path)
            return {
                "path": path,
                "key": key,
                "media_type": "image",
                "caption": media.caption,
            }

    def _cleanup_failed_init(self) -> None:
        if self._error_watch_stop is not None:
            self._error_watch_stop.set()

        if self._sysmetrics is not None:
            try:
                self._sysmetrics.stop()
            except Exception:
                pass
            self._sysmetrics = None

        if self._capture is not None:
            try:
                self._capture.stop()
            except Exception:
                pass
            self._capture = None

        client = self._client
        self._client = None
        if client is not None:
            try:
                client.close()
            except Exception:
                pass

        proc = self._reporter_proc
        self._reporter_proc = None
        if proc is not None:
            _close_reporter_process(proc)

    def _finish_with_stop(self, stop: dict[str, Any]) -> None:
        with self._finish_lock:
            if self._finished:
                return
            self._finished = True
        atexit.unregister(self.finish)
        _unregister_active_run(self)

        # Stop error watcher
        if self._error_watch_stop is not None:
            self._error_watch_stop.set()

        if self._sysmetrics is not None:
            self._sysmetrics.stop()
            self._sysmetrics = None
        if self._capture is not None:
            self._capture.stop()
            self._capture = None
        with self._lock:
            client = self._client
            self._client = None
            uncommitted = self._uncommitted
            self._uncommitted = {}
            buffered_step = self._uncommitted_step
            self._uncommitted_step = None
            buffered_next_step = self._uncommitted_next_step
            self._uncommitted_next_step = None
            step = self._current_step
        if client is not None:
            if uncommitted:
                flush_step = buffered_step if buffered_step is not None else step
                flush_next_step = (
                    buffered_next_step
                    if buffered_next_step is not None
                    else step + 1
                )
                client.send_step(flush_step, uncommitted, next_step=flush_next_step)
            client.send_stop(stop)
            client.close()
        # Close reporter stdin pipe to signal shutdown, then wait for clean exit
        if self._reporter_proc is not None:
            _close_reporter_process(self._reporter_proc)
            self._reporter_proc = None

    def _finish_for_exception(self, exc_type: type[BaseException], exc_val: Any, exc_tb: Any) -> None:
        self._finish_with_stop(_build_stop_for_exception(exc_type, exc_val, exc_tb))

    def finish(self, status: str = "finished", user_payload: Any | None = None) -> None:
        """Finish the run, flush remaining data, and shut down the reporter.

        Safe to call multiple times. Also registered with atexit so it runs
        automatically on process exit.

        Args:
            status: Final status label. Supported values: "finished", "failed", "crashed", or "killed".
            user_payload: Optional structured metadata attached to the stop event.
        """
        self._finish_with_stop(_build_finish_stop(status, user_payload))

    def __enter__(self) -> Run:
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        if exc_type is None:
            self.finish()
            return
        self._finish_for_exception(exc_type, exc_val, exc_tb)


class NoOpRun:
    """Drop-in replacement that does nothing. Used when mode='disabled'."""

    def __init__(self) -> None:
        self.config = _NoOpConfig()
        self.summary = _NoOpConfig()
        self._run_id = "noop"
        self._name = "noop"
        self._tags: dict[str, str] = {}
        self._notes: str | None = None
        self._current_step = 0
        self._resumed = False

    @property
    def id(self) -> str:
        return self._run_id

    @property
    def name(self) -> str:
        return self._name

    @name.setter
    def name(self, value: str) -> None:
        self._name = value

    @property
    def tags(self) -> dict[str, str]:
        return dict(self._tags)

    @tags.setter
    def tags(self, value: dict[str, str]) -> None:
        self._tags = dict(value)

    @property
    def notes(self) -> str | None:
        return self._notes

    @notes.setter
    def notes(self, value: str | None) -> None:
        self._notes = value

    @property
    def step(self) -> int:
        return self._current_step

    @property
    def resumed(self) -> bool:
        return self._resumed

    @property
    def project(self) -> str:
        return ""

    @property
    def url(self) -> str | None:
        return None

    def log(self, data: dict[str, Any], step: int | None = None, commit: bool | None = None) -> None:
        pass

    def define_metric(self, name: str, step_metric: str | None = None, **kwargs: Any) -> None:
        pass

    def finish(self, status: str = "finished", user_payload: Any | None = None) -> None:
        _validate_finish_status(status)
        return None

    def __enter__(self) -> NoOpRun:
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        pass


class _NoOpConfig:
    def update(self, data: dict[str, Any]) -> None:
        pass

    def __getitem__(self, key: str) -> Any:
        return None

    def __setitem__(self, key: str, value: Any) -> None:
        pass

    def __getattr__(self, key: str) -> Any:
        return None

    def __setattr__(self, key: str, value: Any) -> None:
        pass

    def __contains__(self, key: str) -> bool:
        return False

    def to_dict(self) -> dict[str, Any]:
        return {}
