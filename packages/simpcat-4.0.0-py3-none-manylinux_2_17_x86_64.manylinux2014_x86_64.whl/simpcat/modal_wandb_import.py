"""Modal executor app for control-plane-managed W&B import jobs."""

from __future__ import annotations

import json
import os
import subprocess
import sys
import urllib.error
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

try:  # pragma: no cover - exercised in deployment, not unit tests
    import modal
except ImportError:  # pragma: no cover - local tests don't require Modal
    modal = None  # type: ignore[assignment]

try:  # pragma: no cover - only available when modal extras installed
    import sentry_sdk
except ImportError:  # pragma: no cover - local tests don't require sentry
    sentry_sdk = None  # type: ignore[assignment]

MODAL_SECRET_NAME_ENV = "WANDB_IMPORT_MODAL_SECRET_NAME"
MODAL_APP_NAME_ENV = "MODAL_WANDB_IMPORT_APP_NAME"
MODAL_BINARY_PATH_ENV = "SIMPCAT_MODAL_BINARY_PATH"
DEFAULT_MODAL_SECRET_NAME = "simpcat-wandb-import-runtime"
DEFAULT_MODAL_APP_NAME = "simpcat-wandb-import"
REMOTE_SIMPCAT_DIR = "/opt/simpcat/bin"
REMOTE_SIMPCAT_BIN = f"{REMOTE_SIMPCAT_DIR}/simpcat"
IMPORT_TIMEOUT_SECONDS = 12 * 60 * 60
MODAL_APP_NAME = os.environ.get(
    MODAL_APP_NAME_ENV,
    DEFAULT_MODAL_APP_NAME,
)
MODAL_SECRET_NAME = os.environ.get(
    MODAL_SECRET_NAME_ENV,
    DEFAULT_MODAL_SECRET_NAME,
)
MODAL_FUNCTION_ENV = {
    MODAL_SECRET_NAME_ENV: MODAL_SECRET_NAME,
}


@dataclass(frozen=True)
class LaunchRequest:
    source: str
    job_id: str
    control_base_url: str
    executor_api_key: str


def _find_reporter_root(current: Path) -> Path:
    for candidate in current.parents:
        if (candidate / "Cargo.toml").exists():
            return candidate

    return current.parent


def _reporter_root() -> Path:
    env_root = os.environ.get("SIMPCAT_REPORTER_ROOT")
    if env_root:
        return Path(env_root)

    return _find_reporter_root(Path(__file__).resolve())


def _local_simpcat_binary() -> Path:
    env_path = os.environ.get(MODAL_BINARY_PATH_ENV)
    if env_path:
        path = Path(env_path)
    else:
        path = _reporter_root() / "target" / "release" / "simpcat"
    if not path.exists():
        raise FileNotFoundError(
            f"simpcat binary not found at {path}. "
            f"Build it first or set {MODAL_BINARY_PATH_ENV}.",
        )
    return path.resolve()


def parse_launch_request(payload: Mapping[str, Any]) -> LaunchRequest:
    if not isinstance(payload, Mapping):
        raise ValueError("JSON body must be an object")

    def require_string(key: str) -> str:
        value = payload.get(key)
        if not isinstance(value, str) or not value.strip():
            raise ValueError(f"{key} is required")
        return value.strip()

    source = require_string("source")
    if source != "wandb":
        raise ValueError("source must be 'wandb'")

    return LaunchRequest(
        source=source,
        job_id=require_string("job_id"),
        control_base_url=require_string("control_base_url").rstrip("/"),
        executor_api_key=require_string("executor_api_key"),
    )


def build_simpcat_command(request: LaunchRequest) -> list[str]:
    return [
        REMOTE_SIMPCAT_BIN,
        "import-job",
        "wandb",
        "--host",
        request.control_base_url,
        "--job-id",
        request.job_id,
    ]


def _cf_access_headers() -> dict[str, str]:
    headers: dict[str, str] = {}
    client_id = os.environ.get("CF_ACCESS_CLIENT_ID")
    client_secret = os.environ.get("CF_ACCESS_CLIENT_SECRET")
    if client_id:
        headers["CF-Access-Client-Id"] = client_id
    if client_secret:
        headers["CF-Access-Client-Secret"] = client_secret
    return headers


def _tail_output(text: str | None, max_lines: int = 50) -> str:
    if not text:
        return ""
    lines = text.strip().splitlines()
    if len(lines) > max_lines:
        return "\n".join(lines[-max_lines:])
    return "\n".join(lines)


def _format_http_error(exc: urllib.error.HTTPError) -> str:
    detail = f"HTTP {exc.code} {exc.reason}"
    body = ""
    try:
        body = exc.read().decode("utf-8", errors="replace").strip()
    except OSError:
        body = ""
    if body:
        detail += f": {body}"
    return detail


def report_import_failure(request: LaunchRequest, error: str) -> None:
    url = f"{request.control_base_url}/api/internal/wandb/import-job/fail"
    body = json.dumps({
        "job_id": request.job_id,
        "error": error,
    }).encode("utf-8")
    headers = {
        "Authorization": f"Bearer {request.executor_api_key}",
        "Content-Type": "application/json",
        **_cf_access_headers(),
    }
    http_request = urllib.request.Request(
        url,
        data=body,
        headers=headers,
        method="POST",
    )
    try:
        with urllib.request.urlopen(http_request, timeout=30):
            return
    except urllib.error.HTTPError as exc:
        detail = _format_http_error(exc)
        print(
            f"Failed to report import failure to control plane: {detail}",
            file=sys.stderr,
        )
        return
    except urllib.error.URLError as exc:
        print(f"Failed to report import failure to control plane: {exc}", file=sys.stderr)
        return


def _read_tail_from_file(path: Path, max_lines: int = 50) -> str:
    try:
        text = path.read_text(errors="replace")
        return _tail_output(text, max_lines)
    except OSError:
        return ""


def run_import_subprocess(request: LaunchRequest) -> None:
    command = build_simpcat_command(request)
    env = os.environ.copy()
    env.setdefault("SIMPCAT_LOG_FILTER", "info")
    env["SIMPCAT_IMPORT_EXECUTOR_API_KEY"] = request.executor_api_key

    import tempfile
    stdout_fd, stdout_name = tempfile.mkstemp(prefix="simpcat-exec-stdout-")
    stderr_fd, stderr_name = tempfile.mkstemp(prefix="simpcat-exec-stderr-")
    os.close(stdout_fd)
    os.close(stderr_fd)
    stdout_path = Path(stdout_name)
    stderr_path = Path(stderr_name)
    try:
        with open(stdout_path, "w") as stdout_f, open(stderr_path, "w") as stderr_f:
            subprocess.run(
                command,
                check=True,
                cwd=REMOTE_SIMPCAT_DIR,
                env=env,
                timeout=IMPORT_TIMEOUT_SECONDS,
                stdout=stdout_f,
                stderr=stderr_f,
            )
        # Print captured output so Modal still records it
        stdout_text = stdout_path.read_text(errors="replace")
        stderr_text = stderr_path.read_text(errors="replace")
        if stdout_text:
            print(stdout_text)
        if stderr_text:
            print(stderr_text, file=sys.stderr)
    except OSError as exc:
        error_msg = f"Failed to start executor: {exc}"
        report_import_failure(request, error_msg)
        if sentry_sdk is not None:
            sentry_sdk.capture_exception(exc)
        raise RuntimeError(error_msg) from exc
    except subprocess.TimeoutExpired as exc:
        tail = _read_tail_from_file(stderr_path) or _read_tail_from_file(stdout_path)
        error_msg = f"Executor timed out after {IMPORT_TIMEOUT_SECONDS}s"
        if tail:
            error_msg += f"\n\nLast output:\n{tail}"
        report_import_failure(request, error_msg)
        if sentry_sdk is not None:
            sentry_sdk.capture_exception(exc)
        raise RuntimeError(error_msg) from exc
    except subprocess.CalledProcessError as exc:
        tail = _read_tail_from_file(stderr_path) or _read_tail_from_file(stdout_path)
        error_msg = f"Executor exited with status {exc.returncode}"
        if tail:
            error_msg += f"\n\nLast output:\n{tail}"
        report_import_failure(request, error_msg)
        if sentry_sdk is not None:
            sentry_sdk.capture_exception(exc)
        raise
    finally:
        stdout_path.unlink(missing_ok=True)
        stderr_path.unlink(missing_ok=True)


def _modal_secrets() -> list[Any]:
    if modal is None:
        return []
    return [modal.Secret.from_name(MODAL_SECRET_NAME)]


def _build_modal_image() -> Any:
    assert modal is not None

    image = (
        modal.Image.debian_slim(python_version="3.12")
        .uv_pip_install("sentry-sdk>=2,<3")
    )
    if modal.is_local():
        image = (
            image
            .add_local_file(
                _local_simpcat_binary(),
                remote_path=REMOTE_SIMPCAT_BIN,
                copy=True,
            )
            .run_commands(f"mkdir -p {REMOTE_SIMPCAT_DIR} && chmod +x {REMOTE_SIMPCAT_BIN}")
        )
    return image


if modal is not None:  # pragma: no branch - guarded for local test environments
    app = modal.App(MODAL_APP_NAME)
    image = _build_modal_image()

    @app.function(
        image=image,
        timeout=IMPORT_TIMEOUT_SECONDS,
        cpu=2,
        memory=8192,
        env=MODAL_FUNCTION_ENV,
        secrets=_modal_secrets(),
    )
    def execute_wandb_import(payload: dict[str, str]) -> None:
        request = parse_launch_request(payload)
        dsn = os.environ.get("SENTRY_DSN")
        if sentry_sdk is not None and dsn:
            sentry_sdk.init(
                dsn=dsn,
                environment=os.environ.get("ENVIRONMENT", "unknown"),
                traces_sample_rate=0,
            )
            sentry_sdk.set_tag("source", "modal-executor")
            sentry_sdk.set_tag("job_id", request.job_id)
        run_import_subprocess(request)


    @app.local_entrypoint()
    def main() -> None:
        print(
            "Deploy with: "
            f"{MODAL_BINARY_PATH_ENV}=/path/to/simpcat "
            f"{MODAL_APP_NAME_ENV}={MODAL_APP_NAME!r} "
            "uv run --no-project --isolated --with 'modal>=1,<2' "
            "modal deploy reporter/python/simpcat/modal_wandb_import.py"
        )
