"""Centralized constants for the simpcat SDK."""

# Default server host
DEFAULT_HOST = "simpcat.ai"

# Directory names within a run directory
FILES_DIR = "files"
LOGS_DIR = "logs"
MEDIA_DIR = "media"

# File names
REPORTER_SOCKET = "reporter.sock"
SOCKET_PATH_FILE = "socket.path"
INIT_STATUS_FILE = "init.status"
METADATA_FILE = "simpcat-metadata.json"
CONFIG_FILE = "config.json"
DIFF_FILE = "diff.patch"
RUN_STATE_FILE = "run.json"
OUTPUT_LOG = "output.log"
DEBUG_LOG = "debug.log"
ERRORS_LOG = "errors.log"
REPORTER_STDERR_LOG = "reporter_stderr.log"

# Environment variable names
ENV_RUN_DATA_DIR = "SIMPCAT_RUN_DATA_DIR"
ENV_LOCAL_DIR = "SIMPCAT_LOCAL_DIR"
ENV_HOST = "SIMPCAT_HOST"
ENV_API_KEY = "SIMPCAT_API_KEY"
ENV_CONFIG = "SIMPCAT_CONFIG"
ENV_COMMAND = "SIMPCAT_COMMAND"
ENV_MODE = "SIMPCAT_MODE"
ENV_LOG_FILTER = "SIMPCAT_LOG_FILTER"
ENV_DEBUG = "SIMPCAT_DEBUG"
ENV_RESUME = "SIMPCAT_RESUME"
ENV_RUN_ID = "SIMPCAT_RUN_ID"
ENV_INIT_TIMEOUT = "SIMPCAT_INIT_TIMEOUT"
ENV_METRICS_URL = "SIMPCAT_METRICS_URL"
ENV_ASSETS_URL = "SIMPCAT_ASSETS_URL"
ENV_METADATA_URL = "SIMPCAT_METADATA_URL"
