"""SimpCatLogger — PyTorch Lightning Logger implementation."""

from __future__ import annotations

import os
from argparse import Namespace
from pathlib import Path
from typing import Any, Mapping

try:
    from lightning.pytorch.loggers import Logger
    from lightning.pytorch.utilities import rank_zero_only
except ImportError:
    raise ImportError(
        "lightning is required for SimpCatLogger. "
        "Install it with: pip install 'simpcat[lightning]'"
    )

from simpcat.experiment import Run, NoOpRun, OfflineRunIdUnavailableError

SUPPORTED_RUN_KWARGS = {
    "capture_output",
    "config",
    "fork_from",
    "fork_step",
    "group",
    "job_type",
    "notes",
    "resume",
    "system_metrics",
    "system_metrics_interval",
    "tags",
}


def _is_rank_zero() -> bool:
    """Check if current process is rank 0."""
    rank = os.environ.get("LOCAL_RANK", os.environ.get("RANK", "0"))
    return rank == "0"


class SimpCatLogger(Logger):
    """Lightning Logger that sends metrics to the simpcat reporter.

    Drop-in replacement for WandbLogger with compatible API surface.
    Accepts a pre-created Run via ``run=`` to share with simpcat.init().
    ``save_dir`` is equivalent to ``simpcat.init(dir=...)``: if provided,
    SimpCat stores run state under ``save_dir/simpcat``. If omitted, the
    default ``simpcat.init()`` run-data directory is used.
    ``id=`` is unsupported because SimpCat assigns run IDs.
    """

    def __init__(
        self,
        project: str | None = None,
        name: str | None = None,
        save_dir: str | os.PathLike[str] | None = None,
        mode: str | None = None,
        auto_expire_seconds: int | None = None,
        run: Run | NoOpRun | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__()
        dir_arg = kwargs.pop("dir", None)
        self._project = project
        self._name = name
        self._save_dir = save_dir if save_dir is not None else dir_arg
        self._auto_expire_seconds = auto_expire_seconds
        from simpcat._constants import ENV_MODE
        self._mode = mode or os.environ.get(ENV_MODE)
        self._run = run
        if "id" in kwargs:
            raise TypeError(
                "SimpCatLogger(id=...) is not supported. SimpCat assigns run IDs; "
                "resume uses run.json under save_dir."
            )
        self._run_kwargs = {
            key: value
            for key, value in kwargs.items()
            if key in SUPPORTED_RUN_KWARGS
        }

    @property
    def name(self) -> str:
        return self._project or "default"

    @property
    def version(self) -> str:
        run = self.experiment
        try:
            return run.id
        except OfflineRunIdUnavailableError:
            run_dir = getattr(run, "dir", None)
            if run_dir:
                return Path(os.fspath(run_dir)).name
            return "offline"

    @property
    def experiment(self) -> Run | NoOpRun:
        if self._run is None:
            if self._mode == "disabled" or not _is_rank_zero():
                self._run = NoOpRun()
            else:
                self._run = Run(
                    project=self._project or "default",
                    name=self._name,
                    dir=self._save_dir,
                    auto_expire_seconds=self._auto_expire_seconds,
                    **self._run_kwargs,
                )
        return self._run

    @rank_zero_only
    def log_hyperparams(self, params: dict[str, Any] | Namespace) -> None:
        if isinstance(params, Namespace):
            params = vars(params)
        self.experiment.config.update(params)

    @rank_zero_only
    def log_metrics(self, metrics: Mapping[str, float], step: int | None = None) -> None:
        self.experiment.log(dict(metrics), step=step, commit=True)

    @rank_zero_only
    def finalize(self, status: str) -> None:
        # Lightning calls logger.finalize("success") after standalone
        # validate/test phases too. Do not finish the simpcat run here, or a
        # validate-then-fit workflow will close the reporter before training.
        # Run.finish() is still called explicitly, by exception hooks, and by
        # the Run atexit handler.
        return None
