"""Spawn a per-run simpcat reporter process."""

from __future__ import annotations

import os
import shlex
import shutil
import subprocess
import time
import warnings
from pathlib import Path

from simpcat._constants import (
    DEFAULT_HOST,
    ENV_COMMAND,
    LOGS_DIR,
    REPORTER_SOCKET,
    REPORTER_STDERR_LOG,
    SOCKET_PATH_FILE,
    DEBUG_LOG,
)


def _find_reporter_cmd() -> list[str] | None:
    """Locate the simpcat command.

    SIMPCAT_COMMAND can be a multi-arg command like GIT_SSH_COMMAND, e.g.
    ``cargo run --manifest-path /path/to/Cargo.toml --release --``.
    It is split with ``shlex.split`` so quoting works as expected.
    """
    explicit = os.environ.get(ENV_COMMAND)
    if explicit:
        parts = shlex.split(explicit)
        return parts if parts else None

    on_path = shutil.which("simpcat")
    if on_path:
        return [on_path]

    return None


def spawn_reporter(run_dir: Path, run_id: str | None = None) -> tuple[subprocess.Popen, str]:
    """Spawn a per-run reporter process.

    Returns (process, socket_path).
    Raises RuntimeError on failure.
    """
    base_cmd = _find_reporter_cmd()
    if base_cmd is None:
        raise RuntimeError(
            "simpcat: 'simpcat' binary not found. "
            "Install it or set SIMPCAT_COMMAND=/path/to/simpcat."
        )

    cmd = [*base_cmd, "reporter", "--run-dir", str(run_dir)]
    if run_id is not None:
        cmd.extend(["--run-id", run_id])

    env = os.environ.copy()

    stderr_path = run_dir / LOGS_DIR / REPORTER_STDERR_LOG
    stderr_path.parent.mkdir(parents=True, exist_ok=True)
    stderr_file = open(stderr_path, "w")

    try:
        try:
            proc = subprocess.Popen(
                cmd,
                stdout=subprocess.DEVNULL,
                stderr=stderr_file,
                stdin=subprocess.PIPE,
                start_new_session=True,
                env=env,
            )
        except OSError as e:
            raise RuntimeError(f"simpcat: failed to start reporter: {e}") from e

        # Determine socket path: reporter.sock in run_dir, or read socket.path for fallback
        socket_path = str(run_dir / REPORTER_SOCKET)
        sp_file = run_dir / SOCKET_PATH_FILE
        debug_log = run_dir / LOGS_DIR / DEBUG_LOG

        # Wait for socket to appear (3s)
        deadline = time.monotonic() + 3.0
        while time.monotonic() < deadline:
            # Check if reporter wrote a fallback socket.path file
            if sp_file.exists():
                socket_path = sp_file.read_text().strip()

            if os.path.exists(socket_path):
                return (proc, socket_path)

            if proc.poll() is not None:
                stderr_output = stderr_path.read_text().strip()
                msg = f"simpcat: reporter exited immediately (code {proc.returncode})."
                if stderr_output:
                    msg += f"\n{stderr_output}"
                else:
                    msg += f"\nCheck {debug_log} for errors."
                raise RuntimeError(msg)

            time.sleep(0.05)

        # Kill the unresponsive process
        proc.kill()
        proc.wait()
        stderr_output = stderr_path.read_text().strip()
        msg = "simpcat: reporter started but socket not available after 3s."
        if stderr_output:
            msg += f"\n{stderr_output}"
        else:
            msg += f"\nCheck {debug_log} for errors."
        raise RuntimeError(msg)
    finally:
        stderr_file.close()
