"""Audio and Image media classes for simpcat."""

from __future__ import annotations

import os
import warnings
from pathlib import Path
from typing import Any

import numpy as np

_IMAGE_FILE_TYPES = {"png": "PNG", "jpg": "JPEG", "jpeg": "JPEG"}


def _coerce_path(value: object) -> str | None:
    if isinstance(value, (str, os.PathLike)):
        return os.fspath(value)
    return None


def _path_extension(path: str, default: str) -> str:
    suffix = Path(path).suffix.lower().lstrip(".")
    return suffix or default


def _normalize_image_file_type(file_type: str | None) -> str:
    normalized = (file_type or "png").lower()
    if normalized not in _IMAGE_FILE_TYPES:
        allowed = ", ".join(sorted(_IMAGE_FILE_TYPES))
        raise ValueError(f"Unsupported image file_type '{file_type}'. Expected one of: {allowed}")
    return normalized


def _normalize_ndarray_image(data: np.ndarray, normalize: bool) -> np.ndarray:
    if np.iscomplexobj(data):
        raise TypeError("Complex image arrays are not supported")

    if data.dtype.kind == "b":
        return data.astype(np.uint8) * 255

    if data.dtype.kind not in {"u", "i", "f"}:
        return data

    arr = np.asarray(data, dtype=np.float32)
    if not np.isfinite(arr).all():
        raise ValueError("Image numpy data must contain only finite values")

    min_value = float(arr.min())
    max_value = float(arr.max())

    if normalize:
        if min_value >= 0.0 and max_value <= 1.0:
            arr = arr * 255.0
        elif min_value >= -1.0 and max_value <= 1.0:
            arr = (arr + 1.0) * 127.5
        else:
            if min_value < 0.0 or max_value > 255.0:
                warnings.warn(
                    "Image data outside the [0, 255] range is clipped for wandb compatibility.",
                    stacklevel=3,
                )
            arr = np.clip(arr, 0.0, 255.0)
        return np.clip(arr, 0.0, 255.0).astype(np.uint8)

    if min_value < 0.0 or max_value > 255.0:
        raise ValueError(
            "Image numpy data with normalize=False must be within the [0, 255] range"
        )
    return arr.astype(np.uint8)


class Audio:
    """Wraps audio data for logging. Compatible with wandb.Audio interface."""

    def __init__(
        self,
        data_or_path: np.ndarray | str | os.PathLike[str],
        caption: str = "",
        sample_rate: int | None = None,
    ) -> None:
        path = _coerce_path(data_or_path)
        if path is not None:
            self._path = path
            self._data = None
        else:
            if sample_rate is None:
                raise TypeError("Audio numpy data requires an explicit sample_rate")
            self._path = None
            self._data = np.asarray(data_or_path, dtype=np.float32)
        self.caption = caption
        self.sample_rate = sample_rate

    def save(self, path: str) -> None:
        """Write audio data to a WAV file."""
        import soundfile as sf

        if self._data is not None:
            assert self.sample_rate is not None
            sf.write(path, self._data, self.sample_rate)
        elif self._path is not None:
            import shutil
            shutil.copy2(self._path, path)

    def stage_extension(self) -> str:
        if self._path is not None:
            return _path_extension(self._path, "wav")
        return "wav"


class Image:
    """Wraps image data for logging. Compatible with wandb.Image interface."""

    def __init__(
        self,
        data_or_path: np.ndarray | Any | str | os.PathLike[str],
        caption: str = "",
        file_type: str | None = None,
        normalize: bool = True,
    ) -> None:
        path = _coerce_path(data_or_path)
        self._file_type = _normalize_image_file_type(file_type)
        self._normalize = normalize
        if path is not None:
            self._path = path
            self._data = None
        elif isinstance(data_or_path, np.ndarray):
            self._data = data_or_path
            self._path = None
        else:
            # Assume PIL Image
            self._data = data_or_path
            self._path = None
        self.caption = caption

    def save(self, path: str) -> None:
        """Write image data to an image file."""
        if self._path is not None:
            import shutil
            shutil.copy2(self._path, path)
        elif isinstance(self._data, np.ndarray):
            from PIL import Image as PILImage
            arr = _normalize_ndarray_image(self._data, self._normalize)
            img = PILImage.fromarray(arr)
            img.save(path, format=_IMAGE_FILE_TYPES[self._file_type])
        else:
            # Assume PIL Image object
            self._data.save(path, format=_IMAGE_FILE_TYPES[self._file_type])

    def stage_extension(self) -> str:
        if self._path is not None:
            return _path_extension(self._path, self._file_type)
        return self._file_type
