"""ReporterClient — Unix stream socket IPC to simpcat reporter."""

from __future__ import annotations

import os
import socket
import struct
import threading
import time
import warnings
from typing import Any

import msgpack

from simpcat._constants import ENV_DEBUG

_SLOW_SEND_THRESHOLD_S = 0.1  # 100ms
_HEARTBEAT_INTERVAL_S = 10.0
_DEBUG = os.environ.get(ENV_DEBUG) is not None


class ReporterClient:
    """Sends length-prefixed msgpack messages to the simpcat reporter over a Unix stream socket.

    Methods never raise on the hot path and avoid blocking in practice (the reporter
    drains the socket continuously), but sendall() may block briefly under extreme
    backpressure.  If the reporter is unreachable, messages are silently dropped with
    periodic warnings.

    Wire format: 4-byte big-endian u32 length prefix + msgpack payload (same framing as WAL).

    Note: run_id is NOT included in messages — the per-run reporter knows its own run_id.
    """

    def __init__(
        self,
        project: str,
        name: str,
        socket_path: str,
        auto_expire_seconds: int | None = None,
        metric_names: list[str] | None = None,
        tags: dict[str, str] | None = None,
        notes: str | None = None,
        group: str | None = None,
        job_type: str | None = None,
        resume: str | None = None,
        config: dict[str, Any] | None = None,
        fork_from: str | None = None,
        fork_step: int | None = None,
        sys_info: dict[str, Any] | None = None,
        git_info: dict[str, Any] | None = None,
        python_sdk_version: str | None = None,
    ) -> None:
        self._addr = socket_path
        self._metric_names: list[str] = list(metric_names or [])
        self._name_to_idx: dict[str, int] = {n: i for i, n in enumerate(self._metric_names)}
        self._metrics_lock = threading.Lock()
        self._send_lock = threading.Lock()
        self._heartbeat_stop = threading.Event()
        self._heartbeat_thread: threading.Thread | None = None
        self._drop_count = 0
        self._dead = False

        self._sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self._sock.setblocking(True)
        try:
            self._sock.connect(self._addr)
        except OSError as e:
            self._dead = True
            warnings.warn(
                f"simpcat: failed to connect to reporter at {self._addr}: {e}",
                stacklevel=2,
            )

        init_msg: dict[str, Any] = {
            "type": "init",
            "version": 1,
            "project": project,
            "name": name,
            "metric_names": self._metric_names,
        }
        if python_sdk_version:
            init_msg["python_sdk_version"] = python_sdk_version
        if auto_expire_seconds is not None:
            init_msg["auto_expire_seconds"] = auto_expire_seconds
        if tags:
            init_msg["tags"] = tags
        if notes:
            init_msg["notes"] = notes
        if group:
            init_msg["group"] = group
        if job_type:
            init_msg["job_type"] = job_type
        if resume:
            init_msg["resume"] = resume
        if config:
            init_msg["config"] = config
        if fork_from:
            init_msg["fork_from"] = fork_from
        if fork_step is not None:
            init_msg["fork_step"] = fork_step
        if sys_info:
            init_msg["sys"] = sys_info
        if git_info:
            init_msg["git"] = git_info
        self._send(init_msg)
        if not self._dead:
            self._heartbeat_thread = threading.Thread(
                target=self._heartbeat_loop,
                name="simpcat-heartbeat",
                daemon=True,
            )
            self._heartbeat_thread.start()

    def send_step(
        self,
        step: int,
        metrics: dict[str, float],
        next_step: int | None = None,
    ) -> None:
        """Send a compact metric vector for one training step."""
        updated_names: list[str] | None = None

        with self._metrics_lock:
            new_keys = [k for k in metrics if k not in self._name_to_idx]
            if new_keys:
                for k in new_keys:
                    self._name_to_idx[k] = len(self._metric_names)
                    self._metric_names.append(k)
                updated_names = list(self._metric_names)

            values = [float('nan')] * len(self._metric_names)
            for name, val in metrics.items():
                values[self._name_to_idx[name]] = float(val)

        if updated_names is not None:
            self._send({
                "type": "metric_names",
                "metric_names": updated_names,
            })

        payload: dict[str, Any] = {
            "type": "m",
            "s": step,
            "t": time.time(),
            "v": values,
        }
        if next_step is not None:
            payload["ns"] = next_step
        self._send(payload)

    def send_config(self, data: dict[str, Any]) -> None:
        """Send hyperparameter config to reporter."""
        self._send({
            "type": "config",
            "data": data,
        })

    def send_heartbeat(self) -> None:
        """Notify reporter that the Python process is still alive."""
        self._send({
            "type": "heartbeat",
        })

    def send_stop(self, stop: dict[str, Any]) -> None:
        """Notify reporter that this run has an explicit stop event."""
        self._send({
            "type": "stop",
            "stop": stop,
        })

    def send_media(
        self,
        step: int,
        files: list[dict[str, Any]],
        next_step: int | None = None,
    ) -> None:
        """Notify reporter about staged media files."""
        payload: dict[str, Any] = {
            "type": "media",
            "step": step,
            "files": files,
        }
        if next_step is not None:
            payload["ns"] = next_step
        self._send(payload)

    def send_define_metric(self, name: str, definition: dict[str, Any]) -> None:
        """Send a metric definition to reporter."""
        self._send({
            "type": "define_metric",
            "name": name,
            "definition": definition,
        })

    def send_histogram(
        self,
        step: int,
        name: str,
        histogram: Any,
        next_step: int | None = None,
    ) -> None:
        """Send histogram data to reporter."""
        payload: dict[str, Any] = {
            "type": "histogram",
            "s": step,
            "t": time.time(),
            "n": name,
            "bin_edges": histogram.bin_edges,
            "counts": histogram.counts,
        }
        if next_step is not None:
            payload["ns"] = next_step
        self._send(payload)

    def send_update(self, fields: dict[str, Any]) -> None:
        """Send a run metadata update (name, tags, notes) to reporter."""
        self._send({
            "type": "update",
            "fields": fields,
        })

    def send_summary(self, data: dict[str, Any]) -> None:
        """Send run summary values to reporter."""
        self._send({
            "type": "summary",
            "data": data,
        })

    def send_diagnostic(
        self,
        *,
        severity: str,
        code: str,
        message: str,
        details: dict[str, Any] | None = None,
    ) -> None:
        """Send a structured SDK diagnostic to the reporter."""
        self._send({
            "type": "diagnostic",
            "source": "python_sdk",
            "severity": severity,
            "code": code,
            "message": message,
            "details": details or {},
        })

    def _send(self, msg: dict[str, Any]) -> None:
        if self._dead:
            return
        payload = msgpack.packb(msg, use_bin_type=True)
        frame = struct.pack(">I", len(payload)) + payload
        with self._send_lock:
            try:
                t0 = time.monotonic()
                self._sock.sendall(frame)
                elapsed = time.monotonic() - t0
                if elapsed > _SLOW_SEND_THRESHOLD_S:
                    warnings.warn(
                        f"simpcat: slow send ({elapsed * 1000:.0f}ms) — reporter may be overloaded",
                        stacklevel=3,
                    )
                if _DEBUG:
                    warnings.warn(
                        f"simpcat debug: send {len(payload)} bytes in {elapsed * 1000:.1f}ms",
                        stacklevel=3,
                    )
            except (BrokenPipeError, ConnectionResetError):
                self._dead = True
                warnings.warn(
                    "simpcat: reporter connection lost — run data may be incomplete",
                    stacklevel=3,
                )
            except OSError:
                self._drop_count += 1
                if self._drop_count == 1:
                    warnings.warn(
                        f"simpcat: send error to reporter at {self._addr}. "
                        "Messages will be dropped silently.",
                        stacklevel=3,
                    )
                elif self._drop_count % 1000 == 0:
                    warnings.warn(
                        f"simpcat: dropped {self._drop_count} messages",
                        stacklevel=3,
                    )

    def _heartbeat_loop(self) -> None:
        while not self._heartbeat_stop.wait(_HEARTBEAT_INTERVAL_S):
            if self._dead:
                return
            self.send_heartbeat()

    def close(self) -> None:
        self._heartbeat_stop.set()
        if self._heartbeat_thread is not None and self._heartbeat_thread.is_alive():
            self._heartbeat_thread.join(timeout=1.0)
        try:
            self._sock.close()
        except OSError:
            pass
