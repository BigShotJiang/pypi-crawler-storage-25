"""DQEngine — the single public entry point for the Data Quality framework.

Users instantiate ``DQEngine`` with a Spark session and catalog/schema
configuration, then call its methods to add rules, run checks, query
results, and access monitoring views.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from ntb_dq_framework.checks.accuracy import AccuracyCheck
from ntb_dq_framework.checks.completeness import CompletenessCheck
from ntb_dq_framework.checks.consistency import ConsistencyCheck
from ntb_dq_framework.checks.timeliness import TimelinessCheck
from ntb_dq_framework.checks.uniqueness import UniquenessCheck
from ntb_dq_framework.checks.validity import ValidityCheck
from ntb_dq_framework.models import RuleConfig, RunSummary
from ntb_dq_framework.result_writer import ResultWriter
from ntb_dq_framework.rule_manager import RuleManager
from ntb_dq_framework.run_executor import RunExecutor
from ntb_dq_framework.table_initializer import TableInitializer

if TYPE_CHECKING:
    from pyspark.sql import DataFrame


logger = logging.getLogger("ntb_dq_framework")


class DQEngine:
    """Public API for the Databricks Data Quality framework.

    Parameters
    ----------
    spark : SparkSession
        Active Spark session.
    catalog : str
        Unity Catalog name where Delta tables reside.
    schema : str
        Schema (database) name within the catalog.
    table_prefix : str
        Prefix prepended to each Delta table name (default ``"dq_"``).
    max_failed_samples : int
        Maximum number of failing rows stored per rule (default ``100``).
    """

    def __init__(
        self,
        spark,
        catalog: str,
        schema: str = 'data_quality',
        table_prefix: str = "dq_",
        max_failed_samples: int = 100,
    ) -> None:
        self.spark = spark
        self.catalog = catalog
        self.schema = schema
        self.table_prefix = table_prefix

        # Configure logging if no handlers exist yet
        if not logger.handlers:
            handler = logging.StreamHandler()
            handler.setFormatter(logging.Formatter(
                "%(asctime)s [%(levelname)s] %(message)s", datefmt="%H:%M:%S"
            ))
            logger.addHandler(handler)
            logger.setLevel(logging.INFO)

        logger.info("Initializing DQEngine (catalog=%s, schema=%s)", catalog, schema)

        # Initialize Delta tables
        initializer = TableInitializer(spark, catalog, schema, table_prefix)
        initializer.initialize()
        logger.info("Delta tables initialized")

        # Fully qualified table names
        self._registry_table = initializer.rule_registry_table
        self._run_log_table = initializer.run_log_table
        self._result_table = initializer.result_table
        self._failed_records_table = initializer.failed_records_table

        # Internal components
        self._rule_manager = RuleManager(spark, self._registry_table)
        self._result_writer = ResultWriter(
            spark,
            self._result_table,
            self._failed_records_table,
            self._run_log_table,
            max_failed_samples,
        )

        check_registry = {
            "Accuracy": AccuracyCheck(spark),
            "Completeness": CompletenessCheck(),
            "Consistency": ConsistencyCheck(spark),
            "Timeliness": TimelinessCheck(),
            "Validity": ValidityCheck(),
            "Uniqueness": UniquenessCheck(),
        }

        self._run_executor = RunExecutor(
            spark, self._rule_manager, self._result_writer, check_registry
        )

        # MonitoringViews is wired up when monitoring.py is implemented (task 10).
        # Import is deferred to avoid errors before that module exists.
        self._monitoring = None
        try:
            from ntb_dq_framework.monitoring import MonitoringViews

            self._monitoring = MonitoringViews(
                spark,
                self._run_log_table,
                self._result_table,
            )
        except ImportError:
            pass

    # ------------------------------------------------------------------
    # Rule management
    # ------------------------------------------------------------------

    def add_rule(
        self,
        rule_name: str,
        dimension: str,
        target_table: str,
        rule_type: str,
        rule_expression: str = "",
        target_column: str | None = None,
        parameters: dict | None = None,
        severity: str = "warning",
        owner: str = "",
    ) -> int:
        """Register a new rule and return the generated ``rule_id`` (auto-incremented).

        Parameters
        ----------
        severity : str
            One of ``"critical"`` or ``"warning"`` (default ``"warning"``).
            Rules with ``"critical"`` severity will raise ``DQRunError``
            after all results are persisted if the rule fails or errors.
            ``"warning"`` rules are recorded but do not block execution.

        Raises ``DQValidationError`` if *dimension* or *severity* is invalid.
        """
        config = RuleConfig(
            rule_id="",  # assigned by RuleManager
            rule_name=rule_name,
            dimension=dimension,
            target_table=target_table,
            rule_type=rule_type,
            rule_expression=rule_expression,
            target_column=target_column,
            parameters=parameters or {},
            severity=severity,
            owner=owner,
        )
        rule_id = self._rule_manager.add_rule(config)
        logger.info("Rule added: '%s' [%s] → %s (rule_id=%s)", rule_name, dimension, target_table, rule_id)
        return rule_id

    def deactivate_rule(self, rule_id: int) -> None:
        """Set ``is_active`` to false for the given *rule_id*."""
        self._rule_manager.deactivate_rule(rule_id)
        logger.info("Rule deactivated: %s", rule_id)

    # ------------------------------------------------------------------
    # Run execution
    # ------------------------------------------------------------------

    def run_checks(
        self,
        target_table: str,
        df: DataFrame | None = None,
    ) -> RunSummary:
        """Execute all active rules for *target_table* and return a ``RunSummary``.

        If *df* is ``None``, the table is read from the catalog automatically.
        """
        logger.info("Starting run_checks for '%s'", target_table)
        summary = self._run_executor.execute(target_table, df)

        return summary

    # ------------------------------------------------------------------
    # Result querying
    # ------------------------------------------------------------------

    def get_results(
        self,
        run_id: int | None = None,
        rule_id: int | None = None,
        dimension: str | None = None,
        target_table: str | None = None,
        date_range: tuple | None = None,
    ) -> DataFrame:
        """Query the Result Table with optional filters.

        Parameters
        ----------
        run_id : int, optional
            Filter by run ID.
        rule_id : int, optional
            Filter by rule ID.
        dimension : str, optional
            Filter by quality dimension.
        target_table : str, optional
            Filter by target table name.
        date_range : tuple of (start_date, end_date), optional
            Filter by ``run_date`` between *start_date* and *end_date* inclusive.

        Returns
        -------
        DataFrame
            Spark DataFrame of matching result rows.
        """
        query = f"SELECT * FROM {self._result_table} WHERE 1=1"

        if run_id is not None:
            query += f" AND run_id = {run_id}"
        if rule_id is not None:
            query += f" AND rule_id = {rule_id}"
        if dimension is not None:
            query += f" AND dimension = '{dimension}'"
        if target_table is not None:
            query += f" AND target_table = '{target_table}'"
        if date_range is not None:
            start_date, end_date = date_range
            if hasattr(start_date, "strftime"):
                start_date = start_date.strftime("%Y-%m-%d")
            if hasattr(end_date, "strftime"):
                end_date = end_date.strftime("%Y-%m-%d")
            query += f" AND run_date BETWEEN '{start_date}' AND '{end_date}'"

        return self.spark.sql(query)

    # ------------------------------------------------------------------
    # Monitoring views (delegated to MonitoringViews)
    # ------------------------------------------------------------------

    def daily_summary(self, run_date=None) -> DataFrame:
        """Aggregate Run Log data by run_date and target_table."""
        return self._monitoring.daily_summary(run_date)

    def dimension_summary(self, run_date=None) -> DataFrame:
        """Aggregate Result Table data by run_date, dimension, and target_table."""
        return self._monitoring.dimension_summary(run_date)

    def rule_trend(self, rule_id: str | None = None, days: int = 30) -> DataFrame:
        """Result Table data grouped by rule_id, rule_name, and run_date."""
        return self._monitoring.rule_trend(rule_id, days)

    def top_offenders(self, run_date=None, top_n: int = 10) -> DataFrame:
        """Top N rules with the lowest pass_rate for a given run_date."""
        return self._monitoring.top_offenders(run_date, top_n)
