"""Custom exceptions for the DQ framework."""


class DQFrameworkError(Exception):
    """Base exception for the DQ framework."""


class DQValidationError(ValueError):
    """Raised when rule parameters fail validation (invalid dimension, severity, etc.)."""


class DQInitializationError(RuntimeError):
    """Raised when Delta table creation or catalog access fails during init."""


class DQRunError(RuntimeError):
    """Raised when a DQ run fails to start (target table not found, etc.)."""
