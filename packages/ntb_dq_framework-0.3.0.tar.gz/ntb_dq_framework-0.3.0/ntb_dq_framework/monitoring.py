"""MonitoringViews — pre-aggregated monitoring queries over DQ Delta tables.

Provides methods that execute Spark SQL and return DataFrames for dashboard
consumption: daily_summary, dimension_summary, rule_trend, top_offenders.
"""

from __future__ import annotations

from datetime import date, timedelta
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pyspark.sql import DataFrame


class MonitoringViews:
    """Monitoring aggregation queries over Run Log and Result Table.

    Parameters
    ----------
    spark : SparkSession
        Active Spark session.
    run_log_table : str
        Fully qualified name of the Run Log Delta table.
    result_table : str
        Fully qualified name of the Result Table Delta table.
    """

    def __init__(self, spark, run_log_table: str, result_table: str) -> None:
        self.spark = spark
        self.run_log_table = run_log_table
        self.result_table = result_table

    def daily_summary(self, run_date=None) -> DataFrame:
        """Aggregate Run Log data by run_date and target_table.

        Parameters
        ----------
        run_date : str or date, optional
            Filter to a specific date. If ``None``, returns all dates.
        """
        where = "WHERE status = 'completed'"
        if run_date is not None:
            run_date = self._to_date_str(run_date)
            where += f" AND run_date = '{run_date}'"

        query = f"""
            SELECT
                run_date,
                target_table,
                COUNT(*)                            AS total_runs,
                SUM(total_rows_input)               AS total_rows_input,
                SUM(total_rows_passed)              AS total_rows_passed,
                SUM(total_rows_failed)              AS total_rows_failed,
                ROUND(SUM(total_rows_passed) * 1.0 / NULLIF(SUM(total_rows_input), 0), 4) AS overall_pass_rate
            FROM {self.run_log_table}
            {where}
            GROUP BY run_date, target_table
            ORDER BY run_date DESC, target_table
        """
        return self.spark.sql(query)

    def dimension_summary(self, run_date=None) -> DataFrame:
        """Aggregate Result Table data by run_date, dimension, and target_table.

        Parameters
        ----------
        run_date : str or date, optional
            Filter to a specific date. If ``None``, returns all dates.
        """
        where = "WHERE 1=1"
        if run_date is not None:
            run_date = self._to_date_str(run_date)
            where += f" AND run_date = '{run_date}'"

        query = f"""
            SELECT
                run_date,
                dimension,
                target_table,
                COUNT(*)                                        AS rules_evaluated,
                SUM(CASE WHEN status = 'pass' THEN 1 ELSE 0 END) AS rules_passed,
                SUM(CASE WHEN status = 'fail' THEN 1 ELSE 0 END) AS rules_failed,
                ROUND(AVG(pass_rate), 4)                        AS avg_pass_rate
            FROM {self.result_table}
            {where}
            GROUP BY run_date, dimension, target_table
            ORDER BY run_date DESC, dimension
        """
        return self.spark.sql(query)

    def rule_trend(self, rule_id: int | None = None, days: int = 30) -> DataFrame:
        """Result Table data grouped by rule_id, rule_name, and run_date.

        Parameters
        ----------
        rule_id : int, optional
            Filter to a specific rule. If ``None``, returns all rules.
        days : int
            Number of days to look back (default ``30``).
        """
        cutoff = (date.today() - timedelta(days=days)).isoformat()
        where = f"WHERE run_date >= '{cutoff}'"
        if rule_id is not None:
            where += f" AND rule_id = {rule_id}"

        query = f"""
            SELECT
                rule_id,
                rule_name,
                dimension,
                run_date,
                SUM(rows_evaluated)     AS rows_evaluated,
                SUM(rows_failed)        AS rows_failed,
                ROUND(AVG(pass_rate), 4) AS pass_rate
            FROM {self.result_table}
            {where}
            GROUP BY rule_id, rule_name, dimension, run_date
            ORDER BY rule_id, run_date
        """
        return self.spark.sql(query)

    def top_offenders(self, run_date=None, top_n: int = 10) -> DataFrame:
        """Top N rules with the lowest pass_rate for a given run_date.

        Parameters
        ----------
        run_date : str or date, optional
            Date to query. If ``None``, uses today's date.
        top_n : int
            Number of top offenders to return (default ``10``).
        """
        if run_date is None:
            run_date = date.today().isoformat()
        else:
            run_date = self._to_date_str(run_date)

        query = f"""
            SELECT
                rule_id,
                rule_name,
                dimension,
                target_table,
                target_column,
                pass_rate,
                rows_failed
            FROM {self.result_table}
            WHERE run_date = '{run_date}'
              AND status = 'fail'
            ORDER BY pass_rate ASC, rows_failed DESC
            LIMIT {top_n}
        """
        return self.spark.sql(query)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _to_date_str(d) -> str:
        """Convert a date-like value to an ISO date string."""
        if hasattr(d, "isoformat"):
            return d.isoformat()
        return str(d)
