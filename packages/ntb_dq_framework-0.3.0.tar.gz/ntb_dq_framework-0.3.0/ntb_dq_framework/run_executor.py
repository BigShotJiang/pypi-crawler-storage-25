"""Run executor for the DQ Framework.

Orchestrates a single DQ run: creates a Run Log entry, loads active rules
for a target table, dispatches each rule to the appropriate check executor,
collects results, and updates the Run Log on completion.
"""

from __future__ import annotations

import functools
import json
import logging
import time
from datetime import date, datetime
from typing import TYPE_CHECKING

from ntb_dq_framework.exceptions import DQRunError
from ntb_dq_framework.models import CheckResult, RunSummary

from pyspark.sql import DataFrame as SparkDataFrame

if TYPE_CHECKING:
    from pyspark.sql import DataFrame

    from ntb_dq_framework.checks.base import BaseCheck
    from ntb_dq_framework.result_writer import ResultWriter
    from ntb_dq_framework.rule_manager import RuleManager

logger = logging.getLogger("ntb_dq_framework")


class RunExecutor:
    """Orchestrates execution of all active DQ rules for a target table."""

    def __init__(
        self,
        spark,
        rule_manager: RuleManager,
        result_writer: ResultWriter,
        check_registry: dict[str, BaseCheck],
    ) -> None:
        self.spark = spark
        self.rule_manager = rule_manager
        self.result_writer = result_writer
        self.check_registry = check_registry

    def execute(
        self,
        target_table: str,
        df: DataFrame | None = None,
    ) -> RunSummary:
        """Execute all active rules for *target_table* and return a RunSummary."""

        now = datetime.now()
        run_date = now.date()

        # Write initial Run Log with status="running" and get auto-generated run_id
        run_id = self.result_writer.write_run_log(
            {
                "target_table": target_table,
                "run_start_time": now,
                "run_end_time": None,
                "total_rows_input": None,
                "total_rows_passed": None,
                "total_rows_failed": None,
                "status": "running",
                "run_date": run_date,
                "parameters": None,
            }
        )

        try:
            # Load DataFrame if not provided
            if df is None:
                try:
                    df = self.spark.table(target_table)
                except Exception as exc:
                    self.result_writer.update_run_log(
                        run_id,
                        {
                            "status": "failed",
                            "run_end_time": datetime.now(),
                            "parameters": json.dumps({"error": str(exc)}),
                        },
                    )
                    raise DQRunError(
                        f"Target table '{target_table}' not found: {exc}"
                    ) from exc

            # Cache the input DataFrame to avoid repeated reads from storage
            df.cache()
            try:
                total_rows_input = df.count()
                logger.info("Loaded DataFrame: %s rows", total_rows_input)

                rules = self.rule_manager.get_active_rules(target_table)
                logger.info(
                    "Found %d active rule(s) for '%s' | %d rows loaded",
                    len(rules), target_table, total_rows_input,
                )

                results: list[CheckResult] = []
                failed_dfs: list = []
                critical_failed_dfs: list = []
                has_non_error_result = False

                for idx, rule in enumerate(rules, 1):
                    logger.info(
                        "[%d/%d] Running: %s (%s / %s)",
                        idx, len(rules), rule.rule_name, rule.dimension, rule.rule_type,
                    )
                    try:
                        check = self.check_registry[rule.dimension]
                        start = time.time()
                        result = check.execute(df, rule, total_count=total_rows_input)
                        result.execution_time_ms = int((time.time() - start) * 1000)
                        result.run_id = run_id
                    except Exception as exc:
                        result = CheckResult(
                            rule_id=rule.rule_id,
                            run_id=run_id,
                            rows_evaluated=0,
                            rows_passed=0,
                            rows_failed=0,
                            pass_rate=1.0,
                            status="error",
                            extra_params={"error": str(exc)},
                        )

                    # Enrich extra_params for ResultWriter
                    result.extra_params.setdefault("rule_name", rule.rule_name)
                    result.extra_params.setdefault("dimension", rule.dimension)
                    result.extra_params.setdefault("target_table", target_table)
                    result.extra_params.setdefault("run_date", run_date)
                    result.extra_params.setdefault("severity", rule.severity)
                    if rule.target_column:
                        result.extra_params.setdefault("target_column", rule.target_column)

                    results.append(result)

                    # Persist result
                    result_id = self.result_writer.write_result(result)

                    # Persist failed records if any
                    # Critical rules: save ALL failed rows (uncapped) using full_failed_rows_df
                    # Warning rules: save capped sample (max_failed_samples)
                    is_critical = rule.severity == "critical"
                    failed_records_metadata = {
                        "result_id": result_id,
                        "run_id": run_id,
                        "rule_id": rule.rule_id,
                        "target_table": target_table,
                        "failure_reason": f"Rule '{rule.rule_name}' ({rule.rule_type}) failed",
                        "run_date": run_date,
                    }

                    if is_critical and result.full_failed_rows_df is not None:
                        self.result_writer.write_failed_records(
                            result.full_failed_rows_df,
                            failed_records_metadata,
                            uncapped=True,
                        )
                    elif result.failed_rows_df is not None:
                        self.result_writer.write_failed_records(
                            result.failed_rows_df,
                            failed_records_metadata,
                        )
                    elif result.failed_rows:
                        self.result_writer.write_failed_records(
                            result.failed_rows,
                            failed_records_metadata,
                            uncapped=is_critical,
                        )

                    # Collect failed DataFrames for union-based counting (skip error results)
                    if result.status != "error":
                        has_non_error_result = True
                        if result.full_failed_rows_df is not None:
                            failed_dfs.append(result.full_failed_rows_df)
                            if rule.severity == "critical":
                                critical_failed_dfs.append(result.full_failed_rows_df)
                        pct = (result.rows_passed / result.rows_evaluated * 100) if result.rows_evaluated else 100.0
                        logger.info(
                            "[%d/%d] Done: %s | pass_rate=%.1f%% | %dms",
                            idx, len(rules), result.status.upper(), pct, result.execution_time_ms,
                        )
                    else:
                        logger.warning(
                            "[%d/%d] Error: %s",
                            idx, len(rules), result.extra_params.get("error", "unknown"),
                        )

                # Compute run-level totals using union-based distinct counting.
                # Use unionByName so checks that reorder columns (e.g. duplicate_check's
                # join) don't cause a positional type mismatch during the union.
                def _union_by_name(a: SparkDataFrame, b: SparkDataFrame) -> SparkDataFrame:
                    return a.unionByName(b, allowMissingColumns=True)

                if failed_dfs:
                    total_rows_failed = functools.reduce(_union_by_name, failed_dfs).distinct().count()
                    total_rows_passed = total_rows_input - total_rows_failed
                elif has_non_error_result:
                    total_rows_failed = 0
                    total_rows_passed = total_rows_input
                else:
                    total_rows_failed = 0
                    total_rows_passed = 0

                # Build union of all failed rows from critical-severity rules
                if critical_failed_dfs:
                    critical_failed_rows_df = functools.reduce(
                        _union_by_name, critical_failed_dfs
                    ).distinct()
                else:
                    critical_failed_rows_df = None

                logger.info(
                    "Run complete | %d rules | passed=%d | failed=%d | run_id=%s",
                    len(rules), total_rows_passed, total_rows_failed, run_id,
                )

                # Update Run Log to completed
                self.result_writer.update_run_log(
                    run_id,
                    {
                        "status": "completed",
                        "run_end_time": datetime.now(),
                        "total_rows_input": total_rows_input,
                        "total_rows_passed": total_rows_passed,
                        "total_rows_failed": total_rows_failed,
                    },
                )

                return RunSummary(
                    run_id=run_id,
                    target_table=target_table,
                    total_rows_input=total_rows_input,
                    total_rows_passed=total_rows_passed,
                    total_rows_failed=total_rows_failed,
                    status="completed",
                    results=results,
                    critical_failed_rows_df=critical_failed_rows_df,
                )
            finally:
                df.unpersist()

        except DQRunError:
            raise
        except Exception as exc:
            self.result_writer.update_run_log(
                run_id,
                {
                    "status": "failed",
                    "run_end_time": datetime.now(),
                    "parameters": json.dumps({"error": str(exc)}),
                },
            )
            raise DQRunError(f"DQ run failed: {exc}") from exc
