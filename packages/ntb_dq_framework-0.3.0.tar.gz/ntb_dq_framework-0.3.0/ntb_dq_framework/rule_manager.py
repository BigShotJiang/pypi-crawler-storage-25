"""Rule manager for the DQ Framework.

Provides CRUD operations on the Rule Registry Delta table: adding rules,
querying active rules for a target table, and deactivating rules.
"""

from __future__ import annotations

import json
import logging

from ntb_dq_framework.exceptions import DQValidationError
from ntb_dq_framework.models import VALID_DIMENSIONS, VALID_SEVERITIES, RuleConfig
from ntb_dq_framework.sql_guard import validate_expression, validate_identifier, validate_table_name

logger = logging.getLogger("ntb_dq_framework")


class RuleManager:
    """Manages data quality rule definitions in the Rule Registry Delta table."""

    def __init__(self, spark, registry_table: str) -> None:
        self.spark = spark
        self.registry_table = registry_table

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def add_rule(self, rule_config: RuleConfig) -> str:
        """Validate, persist, and return the rule_id for a rule.

        Behaviour:
        - If an active rule with the same (rule_name, target_table,
          target_column) already exists **and** every other field matches
          → no-op, return the existing rule_id.
        - If an active rule with the same key exists but the config
          differs → deactivate the old rule, insert a new one.
        - Otherwise → insert a new rule.

        Raises:
            DQValidationError: If dimension or severity is invalid.
        """
        self._validate_dimension(rule_config.dimension)
        self._validate_severity(rule_config.severity)

        # --- SQL injection guard ---
        validate_identifier(rule_config.rule_name, "rule_name")
        validate_table_name(rule_config.target_table, "target_table")
        validate_identifier(rule_config.rule_type, "rule_type")
        validate_expression(rule_config.rule_expression, "rule_expression")
        validate_identifier(rule_config.owner, "owner")
        if rule_config.target_column:
            validate_identifier(rule_config.target_column, "target_column")

        # --- Check for existing active rule with same natural key ---
        existing = self._find_active_rule(
            rule_config.rule_name,
            rule_config.target_table,
            rule_config.target_column,
        )

        if existing is not None:
            if self._is_same_config(existing, rule_config):
                logger.info(
                    "Rule '%s' already exists with identical config (rule_id=%s), skipping",
                    rule_config.rule_name, existing.rule_id,
                )
                return existing.rule_id

            # Config changed — deactivate old rule
            logger.info(
                "Rule '%s' config changed, deactivating old rule_id=%s",
                rule_config.rule_name, existing.rule_id,
            )
            self.deactivate_rule(existing.rule_id)

        # --- Insert new rule ---
        params_json = json.dumps(rule_config.parameters) if rule_config.parameters else None
        target_column_sql = f"'{rule_config.target_column}'" if rule_config.target_column else "NULL"
        params_sql = f"'{params_json}'" if params_json else "NULL"

        # Escape single quotes in string values for SQL safety
        rule_name_escaped = rule_config.rule_name.replace("'", "\\'")
        target_table_escaped = rule_config.target_table.replace("'", "\\'")
        rule_type_escaped = rule_config.rule_type.replace("'", "\\'")
        rule_expression_escaped = rule_config.rule_expression.replace("\\", "\\\\").replace("'", "\\'")
        owner_escaped = rule_config.owner.replace("'", "\\'")

        sql = f"""
            INSERT INTO {self.registry_table}
            (rule_name, dimension, target_table, target_column,
             rule_type, rule_expression, parameters, severity, owner,
             is_active, created_at, updated_at)
            VALUES (
                '{rule_name_escaped}',
                '{rule_config.dimension}',
                '{target_table_escaped}',
                {target_column_sql},
                '{rule_type_escaped}',
                '{rule_expression_escaped}',
                {params_sql},
                '{rule_config.severity}',
                '{owner_escaped}',
                true,
                current_timestamp(),
                current_timestamp()
            )
        """
        self.spark.sql(sql)

        # Read back the auto-generated rule_id
        col_clause = (
            f"target_column = '{rule_config.target_column}'"
            if rule_config.target_column
            else "target_column IS NULL"
        )
        read_back_sql = f"""
            SELECT rule_id FROM {self.registry_table}
            WHERE rule_name = '{rule_name_escaped}'
              AND target_table = '{target_table_escaped}'
              AND {col_clause}
              AND is_active = true
            ORDER BY created_at DESC
            LIMIT 1
        """
        row = self.spark.sql(read_back_sql).collect()[0]
        rule_id = int(row.rule_id)
        rule_config.rule_id = rule_id
        return rule_id

    def get_active_rules(self, target_table: str) -> list[RuleConfig]:
        """Return all active rules for the given target table.

        Queries the Rule Registry for rows matching the target_table
        with is_active = true and returns them as RuleConfig instances.
        """
        target_table_escaped = target_table.replace("'", "\\'")
        sql = f"""
            SELECT rule_id, rule_name, dimension, target_table, target_column,
                   rule_type, rule_expression, parameters, severity, owner, is_active
            FROM {self.registry_table}
            WHERE target_table = '{target_table_escaped}' AND is_active = true
        """
        rows = self.spark.sql(sql).collect()

        rules: list[RuleConfig] = []
        for row in rows:
            params = json.loads(row.parameters) if row.parameters else {}
            rules.append(
                RuleConfig(
                    rule_id=int(row.rule_id),
                    rule_name=row.rule_name,
                    dimension=row.dimension,
                    target_table=row.target_table,
                    target_column=row.target_column,
                    rule_type=row.rule_type,
                    rule_expression=row.rule_expression,
                    parameters=params,
                    severity=row.severity,
                    owner=row.owner,
                    is_active=row.is_active,
                )
            )
        return rules

    def deactivate_rule(self, rule_id: int) -> None:
        """Set is_active to false and update updated_at for the given rule_id."""
        sql = f"""
            UPDATE {self.registry_table}
            SET is_active = false, updated_at = current_timestamp()
            WHERE rule_id = {rule_id}
        """
        self.spark.sql(sql)

    # ------------------------------------------------------------------
    # Private lookup / comparison helpers
    # ------------------------------------------------------------------

    def _find_active_rule(
        self, rule_name: str, target_table: str, target_column: str | None
    ) -> RuleConfig | None:
        """Return the active rule matching the natural key, or None."""
        rule_name_escaped = rule_name.replace("'", "\\'")
        target_table_escaped = target_table.replace("'", "\\'")

        col_clause = (
            f"target_column = '{target_column}'"
            if target_column
            else "target_column IS NULL"
        )

        sql = f"""
            SELECT rule_id, rule_name, dimension, target_table, target_column,
                   rule_type, rule_expression, parameters, severity, owner, is_active
            FROM {self.registry_table}
            WHERE rule_name = '{rule_name_escaped}'
              AND target_table = '{target_table_escaped}'
              AND {col_clause}
              AND is_active = true
            LIMIT 1
        """
        rows = self.spark.sql(sql).collect()
        if not rows:
            return None

        row = rows[0]
        return RuleConfig(
            rule_id=int(row.rule_id),
            rule_name=row.rule_name,
            dimension=row.dimension,
            target_table=row.target_table,
            target_column=row.target_column,
            rule_type=row.rule_type,
            rule_expression=row.rule_expression,
            parameters=json.loads(row.parameters) if row.parameters else {},
            severity=row.severity,
            owner=row.owner,
            is_active=row.is_active,
        )

    @staticmethod
    def _is_same_config(existing: RuleConfig, new: RuleConfig) -> bool:
        """Return True if all non-key fields match between existing and new."""
        return (
            existing.dimension == new.dimension
            and existing.rule_type == new.rule_type
            and existing.rule_expression == new.rule_expression
            and existing.parameters == new.parameters
            and existing.severity == new.severity
            and existing.owner == new.owner
        )

    # ------------------------------------------------------------------
    # Private validation helpers
    # ------------------------------------------------------------------

    def _validate_dimension(self, dimension: str) -> None:
        """Raise DQValidationError if dimension is not in VALID_DIMENSIONS."""
        if dimension not in VALID_DIMENSIONS:
            raise DQValidationError(
                f"Invalid dimension '{dimension}'. "
                f"Must be one of: {sorted(VALID_DIMENSIONS)}"
            )

    def _validate_severity(self, severity: str) -> None:
        """Raise DQValidationError if severity is not in VALID_SEVERITIES."""
        if severity not in VALID_SEVERITIES:
            raise DQValidationError(
                f"Invalid severity '{severity}'. "
                f"Must be one of: {sorted(VALID_SEVERITIES)}"
            )
