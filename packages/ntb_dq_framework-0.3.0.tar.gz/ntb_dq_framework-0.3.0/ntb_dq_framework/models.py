"""Data models for the DQ Framework.

Defines the core dataclasses (RuleConfig, CheckResult, RunSummary) and
module-level constants for valid enum values used throughout the framework.
"""

from __future__ import annotations

from dataclasses import dataclass, field

# ---------------------------------------------------------------------------
# Valid enum constants
# ---------------------------------------------------------------------------

VALID_DIMENSIONS: set[str] = {
    "Accuracy",
    "Completeness",
    "Consistency",
    "Timeliness",
    "Validity",
    "Uniqueness",
}

VALID_SEVERITIES: set[str] = {"critical", "warning"}

VALID_RUN_STATUSES: set[str] = {"running", "completed", "failed"}

VALID_RESULT_STATUSES: set[str] = {"pass", "fail", "error"}


# ---------------------------------------------------------------------------
# Dataclasses
# ---------------------------------------------------------------------------


@dataclass
class RuleConfig:
    """Configuration for a single data quality rule."""

    rule_id: int
    rule_name: str
    dimension: str  # Must be in VALID_DIMENSIONS
    target_table: str
    rule_type: str
    rule_expression: str = ""
    target_column: str | None = None
    parameters: dict = field(default_factory=dict)
    severity: str = "warning"  # Must be in VALID_SEVERITIES
    owner: str = ""
    is_active: bool = True


@dataclass
class CheckResult:
    """Result of evaluating a single rule against a dataset."""

    rule_id: int
    run_id: int
    rows_evaluated: int
    rows_passed: int
    rows_failed: int
    pass_rate: float
    status: str  # "pass", "fail", or "error"
    failed_rows: list[dict] = field(default_factory=list)
    execution_time_ms: int = 0
    extra_params: dict = field(default_factory=dict)
    failed_rows_df: object = None  # Optional Spark DataFrame of failed rows
    full_failed_rows_df: object = None  # Full (unlimited) failed DataFrame for union-based counting


@dataclass
class RunSummary:
    """Summary of a complete DQ run across all rules for a target table."""

    run_id: int
    target_table: str
    total_rows_input: int
    total_rows_passed: int
    total_rows_failed: int
    status: str  # "running", "completed", "failed"
    results: list[CheckResult] = field(default_factory=list)
    critical_failed_rows_df: object = None  # Union of all failed rows from critical-severity rules (full, uncapped)
