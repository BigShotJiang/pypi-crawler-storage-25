"""Timeliness dimension check executor.

Supports two rule types:
- **freshness_check** — computes the time difference between the current
  timestamp and the maximum value of a specified timestamp column, reporting
  the delay in hours.
- **sla_check** — compares the computed freshness delay against a configured
  SLA threshold (in hours) and reports failure when the delay exceeds it.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from pyspark.sql.functions import col, current_timestamp, max as spark_max

from ntb_dq_framework.checks.base import BaseCheck
from ntb_dq_framework.models import CheckResult, RuleConfig

if TYPE_CHECKING:
    from pyspark.sql import DataFrame


class TimelinessCheck(BaseCheck):
    """Check executor for the Timeliness dimension."""

    def execute(self, df: DataFrame, rule: RuleConfig, *, total_count: int | None = None) -> CheckResult:
        """Dispatch to the appropriate sub-check based on *rule.rule_type*."""
        dispatch = {
            "freshness_check": self._freshness_check,
            "sla_check": self._sla_check,
        }
        handler = dispatch.get(rule.rule_type)
        if handler is None:
            return CheckResult(
                rule_id=rule.rule_id,
                run_id="",
                rows_evaluated=0,
                rows_passed=0,
                rows_failed=0,
                pass_rate=1.0,
                status="error",
                extra_params={"error": f"Unknown rule_type: {rule.rule_type}"},
            )
        return handler(df, rule, total_count=total_count)

    # ------------------------------------------------------------------
    # Private sub-checks
    # ------------------------------------------------------------------

    def _freshness_check(self, df: DataFrame, rule: RuleConfig, *, total_count: int | None = None) -> CheckResult:
        """Compute (current_timestamp - max(timestamp_column)) in hours."""
        timestamp_column = rule.target_column or ""
        tc = total_count if total_count is not None else df.count()

        # Compute freshness delay in hours using Spark
        result_row = (
            df.select(
                (
                    (current_timestamp().cast("double") - spark_max(col(timestamp_column)).cast("double"))
                    / 3600.0
                ).alias("delay_hours")
            )
            .collect()[0]
        )
        delay_hours = float(result_row["delay_hours"]) if result_row["delay_hours"] is not None else 0.0

        # freshness_check always passes — it just records the delay
        return CheckResult(
            rule_id=rule.rule_id,
            run_id="",
            rows_evaluated=tc,
            rows_passed=tc,
            rows_failed=0,
            pass_rate=1.0,
            status="pass",
            extra_params={"freshness_delay_hours": delay_hours},
        )

    def _sla_check(self, df: DataFrame, rule: RuleConfig, *, total_count: int | None = None) -> CheckResult:
        """Compare freshness delay against SLA threshold, fail if exceeded."""
        params = rule.parameters or {}
        sla_threshold = float(params.get("sla_threshold_hours", 0))
        timestamp_column = rule.target_column or ""
        tc = total_count if total_count is not None else df.count()

        # Compute freshness delay in hours using Spark
        result_row = (
            df.select(
                (
                    (current_timestamp().cast("double") - spark_max(col(timestamp_column)).cast("double"))
                    / 3600.0
                ).alias("delay_hours")
            )
            .collect()[0]
        )
        delay_hours = float(result_row["delay_hours"]) if result_row["delay_hours"] is not None else 0.0

        is_breached = delay_hours > sla_threshold
        failed_count = tc if is_breached else 0
        passed_count = tc - failed_count
        pass_rate = (passed_count / tc) if tc > 0 else 1.0

        return CheckResult(
            rule_id=rule.rule_id,
            run_id="",
            rows_evaluated=tc,
            rows_passed=passed_count,
            rows_failed=failed_count,
            pass_rate=pass_rate,
            status="pass" if not is_breached else "fail",
            extra_params={
                "freshness_delay_hours": delay_hours,
                "sla_threshold_hours": sla_threshold,
            },
        )
