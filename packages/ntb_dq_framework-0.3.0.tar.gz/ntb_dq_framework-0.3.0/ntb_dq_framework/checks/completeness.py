"""Completeness dimension check executor.

Supports three rule types:
- **null_check** — counts rows where the target column is null or empty string.
- **missing_partition** — compares expected date partitions against actual
  distinct values and reports missing ones.
- **volume_check** — compares the current row count against a baseline
  threshold and reports when the count drops below a configured percentage.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from pyspark.sql import functions as F
from pyspark.sql.functions import col, lit

from ntb_dq_framework.checks.base import BaseCheck
from ntb_dq_framework.models import CheckResult, RuleConfig

if TYPE_CHECKING:
    from pyspark.sql import DataFrame


class CompletenessCheck(BaseCheck):
    """Check executor for the Completeness dimension."""

    def execute(self, df: DataFrame, rule: RuleConfig, *, total_count: int | None = None) -> CheckResult:
        """Dispatch to the appropriate sub-check based on *rule.rule_type*."""
        dispatch = {
            "null_check": self._null_check,
            "missing_partition": self._missing_partition,
            "volume_check": self._volume_check,
        }
        handler = dispatch.get(rule.rule_type)
        if handler is None:
            return CheckResult(
                rule_id=rule.rule_id,
                run_id="",
                rows_evaluated=0,
                rows_passed=0,
                rows_failed=0,
                pass_rate=1.0,
                status="error",
                extra_params={"error": f"Unknown rule_type: {rule.rule_type}"},
            )
        return handler(df, rule, total_count=total_count)

    # ------------------------------------------------------------------
    # Private sub-checks
    # ------------------------------------------------------------------

    def _null_check(self, df: DataFrame, rule: RuleConfig, *, total_count: int | None = None) -> CheckResult:
        """Count rows where *target_column* is null or empty string."""
        target_col = rule.target_column or ""
        fail_condition = col(target_col).isNull() | (col(target_col) == lit(""))

        if total_count is not None:
            # total_count already known — single aggregation for failed count only
            agg_result = df.agg(
                F.sum(F.when(fail_condition, 1).otherwise(0)).alias("failed")
            ).collect()[0]
            tc = total_count
            failed_count = int(agg_result["failed"]) if agg_result["failed"] is not None else 0
        else:
            # No pre-computed total — get both in a single pass
            agg_result = df.agg(
                F.count("*").alias("total"),
                F.sum(F.when(fail_condition, 1).otherwise(0)).alias("failed"),
            ).collect()[0]
            tc = int(agg_result["total"])
            failed_count = int(agg_result["failed"]) if agg_result["failed"] is not None else 0

        passed_count = tc - failed_count
        pass_rate = (passed_count / tc) if tc > 0 else 1.0

        # Keep the filter for collecting failed rows (but don't count separately)
        failed_df = df.filter(fail_condition)
        failed_rows_df = self._collect_failed_rows(failed_df, 100)

        return CheckResult(
            rule_id=rule.rule_id,
            run_id="",
            rows_evaluated=tc,
            rows_passed=passed_count,
            rows_failed=failed_count,
            pass_rate=pass_rate,
            status="pass" if failed_count == 0 else "fail",
            failed_rows=[],
            failed_rows_df=failed_rows_df,
            full_failed_rows_df=failed_df,
        )

    def _missing_partition(self, df: DataFrame, rule: RuleConfig, *, total_count: int | None = None) -> CheckResult:
        """Compare expected partitions against actual distinct values."""
        params = rule.parameters or {}
        expected_partitions = set(params.get("expected_partitions", []))
        partition_column = params.get("partition_column", rule.target_column or "")

        actual_rows = (
            df.select(col(partition_column))
            .distinct()
            .collect()
        )
        actual_partitions = {str(row[0]) for row in actual_rows}

        missing = expected_partitions - actual_partitions
        rows_evaluated = len(expected_partitions)
        rows_failed = len(missing)
        rows_passed = rows_evaluated - rows_failed
        pass_rate = (rows_passed / rows_evaluated) if rows_evaluated > 0 else 1.0

        return CheckResult(
            rule_id=rule.rule_id,
            run_id="",
            rows_evaluated=rows_evaluated,
            rows_passed=rows_passed,
            rows_failed=rows_failed,
            pass_rate=pass_rate,
            status="pass" if rows_failed == 0 else "fail",
            extra_params={"missing_partitions": sorted(missing)},
        )

    def _volume_check(self, df: DataFrame, rule: RuleConfig, *, total_count: int | None = None) -> CheckResult:
        """Check current row count against a baseline threshold."""
        params = rule.parameters or {}
        baseline = int(params.get("baseline", 0))
        threshold_pct = float(params.get("threshold_percentage", 100.0))

        current_count = total_count if total_count is not None else df.count()
        threshold_value = (threshold_pct / 100.0) * baseline
        is_below = current_count < threshold_value

        rows_failed = current_count if is_below else 0
        rows_passed = current_count - rows_failed
        pass_rate = (rows_passed / current_count) if current_count > 0 else 1.0

        return CheckResult(
            rule_id=rule.rule_id,
            run_id="",
            rows_evaluated=current_count,
            rows_passed=rows_passed,
            rows_failed=rows_failed,
            pass_rate=pass_rate,
            status="pass" if not is_below else "fail",
            extra_params={
                "baseline": baseline,
                "threshold_percentage": threshold_pct,
                "current_count": current_count,
            },
        )
