"""Base class for all data quality check executors."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

from ntb_dq_framework.models import CheckResult, RuleConfig

if TYPE_CHECKING:
    from pyspark.sql import DataFrame


class BaseCheck(ABC):
    """Abstract base for dimension-specific check executors.

    Subclasses implement ``execute`` which receives a Spark DataFrame and a
    ``RuleConfig`` and must return a ``CheckResult``.  Errors are caught by
    ``RunExecutor`` — implementations should *not* let exceptions propagate.
    """

    @abstractmethod
    def execute(self, df: DataFrame, rule: RuleConfig, *, total_count: int | None = None) -> CheckResult:
        """Run the check against *df* using *rule* configuration.

        Parameters
        ----------
        df : DataFrame
            The input Spark DataFrame to check.
        rule : RuleConfig
            The rule configuration for this check.
        total_count : int | None
            Pre-computed row count of *df*.  When provided the check should
            use this value instead of calling ``df.count()`` again.

        Must return a ``CheckResult``.  Must not raise — errors are caught
        by ``RunExecutor``.
        """

    def _collect_failed_rows(self, failed_df: DataFrame, limit: int) -> DataFrame:
        """Return up to *limit* rows from *failed_df* as a DataFrame (no collect)."""
        return failed_df.limit(limit)
