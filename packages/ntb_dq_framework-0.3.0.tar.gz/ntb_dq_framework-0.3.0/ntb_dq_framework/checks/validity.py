"""Validity dimension check executor.

Supports four rule types:
- **regex_check** — evaluates the target column against a regex pattern and
  reports rows that do not match.
- **allowed_values** — checks the target column against a list of allowed
  values and reports rows with values not in the list.
- **range_check** — checks the target column against configured min/max
  bounds and reports rows where the value falls outside the range.
- **type_check** — attempts to cast the target column to a specified data
  type and reports rows where the cast fails.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from pyspark.sql import functions as F
from pyspark.sql.functions import col

from ntb_dq_framework.checks.base import BaseCheck
from ntb_dq_framework.models import CheckResult, RuleConfig

if TYPE_CHECKING:
    from pyspark.sql import DataFrame


class ValidityCheck(BaseCheck):
    """Check executor for the Validity dimension."""

    def execute(self, df: DataFrame, rule: RuleConfig, *, total_count: int | None = None) -> CheckResult:
        """Dispatch to the appropriate sub-check based on *rule.rule_type*."""
        dispatch = {
            "regex_check": self._regex_check,
            "allowed_values": self._allowed_values,
            "range_check": self._range_check,
            "type_check": self._type_check,
        }
        handler = dispatch.get(rule.rule_type)
        if handler is None:
            return CheckResult(
                rule_id=rule.rule_id,
                run_id="",
                rows_evaluated=0,
                rows_passed=0,
                rows_failed=0,
                pass_rate=1.0,
                status="error",
                extra_params={"error": f"Unknown rule_type: {rule.rule_type}"},
            )
        return handler(df, rule, total_count=total_count)

    # ------------------------------------------------------------------
    # Private sub-checks
    # ------------------------------------------------------------------

    def _regex_check(self, df: DataFrame, rule: RuleConfig, *, total_count: int | None = None) -> CheckResult:
        """Report rows where *target_column* does not match the regex in *rule_expression*."""
        target_col = rule.target_column or ""
        # Cast to string so regex works on numeric columns (bigint, double, etc.)
        str_col = col(target_col).cast("string")
        # Exclude nulls — null handling belongs to Completeness (null_check)
        not_null = str_col.isNotNull()
        fail_condition = not_null & ~str_col.rlike(rule.rule_expression)

        # Evaluate only non-null rows so nulls don't inflate pass/fail counts
        df_non_null = df.filter(not_null)
        agg_result = df_non_null.agg(
            F.count("*").alias("total"),
            F.sum(F.when(~str_col.rlike(rule.rule_expression), 1).otherwise(0)).alias("failed"),
        ).collect()[0]
        tc = int(agg_result["total"])
        failed_count = int(agg_result["failed"]) if agg_result["failed"] is not None else 0

        passed_count = tc - failed_count
        pass_rate = (passed_count / tc) if tc > 0 else 1.0

        failed_df = df.filter(fail_condition)
        failed_rows_df = self._collect_failed_rows(failed_df, 100)

        return CheckResult(
            rule_id=rule.rule_id,
            run_id="",
            rows_evaluated=tc,
            rows_passed=passed_count,
            rows_failed=failed_count,
            pass_rate=pass_rate,
            status="pass" if failed_count == 0 else "fail",
            failed_rows=[],
            failed_rows_df=failed_rows_df,
            full_failed_rows_df=failed_df,
        )

    def _allowed_values(self, df: DataFrame, rule: RuleConfig, *, total_count: int | None = None) -> CheckResult:
        """Report rows where *target_column* is not in the allowed values list."""
        target_col = rule.target_column or ""
        params = rule.parameters or {}
        allowed = params.get("allowed_values", [])
        fail_condition = ~col(target_col).isin(allowed)

        if total_count is not None:
            agg_result = df.agg(
                F.sum(F.when(fail_condition, 1).otherwise(0)).alias("failed")
            ).collect()[0]
            tc = total_count
            failed_count = int(agg_result["failed"]) if agg_result["failed"] is not None else 0
        else:
            agg_result = df.agg(
                F.count("*").alias("total"),
                F.sum(F.when(fail_condition, 1).otherwise(0)).alias("failed"),
            ).collect()[0]
            tc = int(agg_result["total"])
            failed_count = int(agg_result["failed"]) if agg_result["failed"] is not None else 0

        passed_count = tc - failed_count
        pass_rate = (passed_count / tc) if tc > 0 else 1.0

        failed_df = df.filter(fail_condition)
        failed_rows_df = self._collect_failed_rows(failed_df, 100)

        return CheckResult(
            rule_id=rule.rule_id,
            run_id="",
            rows_evaluated=tc,
            rows_passed=passed_count,
            rows_failed=failed_count,
            pass_rate=pass_rate,
            status="pass" if failed_count == 0 else "fail",
            failed_rows=[],
            failed_rows_df=failed_rows_df,
            full_failed_rows_df=failed_df,
        )

    def _range_check(self, df: DataFrame, rule: RuleConfig, *, total_count: int | None = None) -> CheckResult:
        """Report rows where *target_column* falls outside min/max bounds."""
        target_col = rule.target_column or ""
        params = rule.parameters or {}
        min_val = params.get("min")
        max_val = params.get("max")
        fail_condition = (col(target_col) < min_val) | (col(target_col) > max_val)

        if total_count is not None:
            agg_result = df.agg(
                F.sum(F.when(fail_condition, 1).otherwise(0)).alias("failed")
            ).collect()[0]
            tc = total_count
            failed_count = int(agg_result["failed"]) if agg_result["failed"] is not None else 0
        else:
            agg_result = df.agg(
                F.count("*").alias("total"),
                F.sum(F.when(fail_condition, 1).otherwise(0)).alias("failed"),
            ).collect()[0]
            tc = int(agg_result["total"])
            failed_count = int(agg_result["failed"]) if agg_result["failed"] is not None else 0

        passed_count = tc - failed_count
        pass_rate = (passed_count / tc) if tc > 0 else 1.0

        failed_df = df.filter(fail_condition)
        failed_rows_df = self._collect_failed_rows(failed_df, 100)

        return CheckResult(
            rule_id=rule.rule_id,
            run_id="",
            rows_evaluated=tc,
            rows_passed=passed_count,
            rows_failed=failed_count,
            pass_rate=pass_rate,
            status="pass" if failed_count == 0 else "fail",
            failed_rows=[],
            failed_rows_df=failed_rows_df,
            full_failed_rows_df=failed_df,
        )

    def _type_check(self, df: DataFrame, rule: RuleConfig, *, total_count: int | None = None) -> CheckResult:
        """Report rows where *target_column* cannot be cast to the target type."""
        target_col = rule.target_column or ""
        params = rule.parameters or {}
        target_type = params.get("target_type", "string")
        fail_condition = col(target_col).cast(target_type).isNull() & col(target_col).isNotNull()

        if total_count is not None:
            agg_result = df.agg(
                F.sum(F.when(fail_condition, 1).otherwise(0)).alias("failed")
            ).collect()[0]
            tc = total_count
            failed_count = int(agg_result["failed"]) if agg_result["failed"] is not None else 0
        else:
            agg_result = df.agg(
                F.count("*").alias("total"),
                F.sum(F.when(fail_condition, 1).otherwise(0)).alias("failed"),
            ).collect()[0]
            tc = int(agg_result["total"])
            failed_count = int(agg_result["failed"]) if agg_result["failed"] is not None else 0

        passed_count = tc - failed_count
        pass_rate = (passed_count / tc) if tc > 0 else 1.0

        failed_df = df.filter(fail_condition)
        failed_rows_df = self._collect_failed_rows(failed_df, 100)

        return CheckResult(
            rule_id=rule.rule_id,
            run_id="",
            rows_evaluated=tc,
            rows_passed=passed_count,
            rows_failed=failed_count,
            pass_rate=pass_rate,
            status="pass" if failed_count == 0 else "fail",
            failed_rows=[],
            failed_rows_df=failed_rows_df,
            full_failed_rows_df=failed_df,
        )
