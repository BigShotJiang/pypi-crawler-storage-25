"""Uniqueness dimension check executor.

Supports one rule type:
- **duplicate_check** — groups the target DataFrame by specified key columns
  and identifies groups with a count greater than one as duplicates.  Reports
  the number of duplicate groups, excess rows, and collects all rows from
  duplicate groups (up to a sample limit) as failed rows.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from pyspark.sql import functions as F

from ntb_dq_framework.checks.base import BaseCheck
from ntb_dq_framework.models import CheckResult, RuleConfig

if TYPE_CHECKING:
    from pyspark.sql import DataFrame


class UniquenessCheck(BaseCheck):
    """Check executor for the Uniqueness dimension."""

    def execute(self, df: DataFrame, rule: RuleConfig, *, total_count: int | None = None) -> CheckResult:
        """Dispatch to the appropriate sub-check based on *rule.rule_type*."""
        dispatch = {
            "duplicate_check": self._duplicate_check,
        }
        handler = dispatch.get(rule.rule_type)
        if handler is None:
            return CheckResult(
                rule_id=rule.rule_id,
                run_id="",
                rows_evaluated=0,
                rows_passed=0,
                rows_failed=0,
                pass_rate=1.0,
                status="error",
                extra_params={"error": f"Unknown rule_type: {rule.rule_type}"},
            )
        return handler(df, rule, total_count=total_count)

    # ------------------------------------------------------------------
    # Private sub-checks
    # ------------------------------------------------------------------

    def _duplicate_check(self, df: DataFrame, rule: RuleConfig, *, total_count: int | None = None) -> CheckResult:
        """Group by key columns, identify groups with count > 1."""
        params = rule.parameters or {}
        key_columns: list[str] = params.get("key_columns", [])

        tc = total_count if total_count is not None else df.count()

        # Group by key columns and count occurrences
        grouped = df.groupBy(key_columns).agg(F.count("*").alias("_dq_count"))

        # Identify duplicate groups (count > 1)
        dup_groups_df = grouped.filter(F.col("_dq_count") > 1)

        duplicate_groups = dup_groups_df.count()
        # excess_rows = total rows in duplicate groups minus the group count
        # (i.e. how many extra rows beyond one per group)
        excess_rows_row = dup_groups_df.agg(
            F.sum("_dq_count").alias("total_dup_rows")
        ).collect()[0]
        total_dup_rows = int(excess_rows_row["total_dup_rows"]) if excess_rows_row["total_dup_rows"] is not None else 0
        excess_rows = total_dup_rows - duplicate_groups

        # rows_failed = total number of rows that belong to duplicate groups
        failed_count = total_dup_rows
        passed_count = tc - failed_count
        pass_rate = (passed_count / tc) if tc > 0 else 1.0

        # Collect all rows from duplicate groups (up to sample limit)
        # Join original df with duplicate keys to get the actual rows
        dup_keys_df = dup_groups_df.select(key_columns)
        failed_df = df.join(dup_keys_df, on=key_columns, how="inner")

        failed_rows_df = self._collect_failed_rows(failed_df, 100)

        return CheckResult(
            rule_id=rule.rule_id,
            run_id="",
            rows_evaluated=tc,
            rows_passed=passed_count,
            rows_failed=failed_count,
            pass_rate=pass_rate,
            status="pass" if failed_count == 0 else "fail",
            failed_rows=[],
            failed_rows_df=failed_rows_df,
            full_failed_rows_df=failed_df,
            extra_params={
                "duplicate_groups": duplicate_groups,
                "excess_rows": excess_rows,
            },
        )
