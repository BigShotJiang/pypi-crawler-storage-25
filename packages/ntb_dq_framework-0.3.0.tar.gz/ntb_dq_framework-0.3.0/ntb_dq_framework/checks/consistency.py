"""Consistency dimension check executor.

Supports three rule types:
- **referential_integrity** — left anti-joins the target DataFrame with a
  reference table on a key column and reports orphan rows.
- **cross_system_match** — joins the target DataFrame with a reference table
  on key columns and reports rows where compared columns differ.
- **business_rule** — evaluates a SQL boolean expression against the target
  DataFrame and reports rows where the expression is false.
"""

from __future__ import annotations

from functools import reduce
from typing import TYPE_CHECKING

from pyspark.sql import functions as F
from pyspark.sql.functions import col, expr

from ntb_dq_framework.checks.base import BaseCheck
from ntb_dq_framework.models import CheckResult, RuleConfig
from ntb_dq_framework.sql_guard import validate_column_names, validate_expression, validate_table_name

if TYPE_CHECKING:
    from pyspark.sql import DataFrame, SparkSession


class ConsistencyCheck(BaseCheck):
    """Check executor for the Consistency dimension."""

    def __init__(self, spark: SparkSession) -> None:
        self.spark = spark

    def execute(self, df: DataFrame, rule: RuleConfig, *, total_count: int | None = None) -> CheckResult:
        """Dispatch to the appropriate sub-check based on *rule.rule_type*."""
        dispatch = {
            "referential_integrity": self._referential_integrity,
            "cross_system_match": self._cross_system_match,
            "business_rule": self._business_rule,
        }
        handler = dispatch.get(rule.rule_type)
        if handler is None:
            return CheckResult(
                rule_id=rule.rule_id,
                run_id="",
                rows_evaluated=0,
                rows_passed=0,
                rows_failed=0,
                pass_rate=1.0,
                status="error",
                extra_params={"error": f"Unknown rule_type: {rule.rule_type}"},
            )
        return handler(df, rule, total_count=total_count)

    # ------------------------------------------------------------------
    # Private sub-checks
    # ------------------------------------------------------------------

    def _referential_integrity(self, df: DataFrame, rule: RuleConfig, *, total_count: int | None = None) -> CheckResult:
        """Left anti-join target with reference on key column, report orphans."""
        params = rule.parameters or {}
        reference_table = params.get("reference_table", "")
        target_key_column = params.get("target_key_column", rule.target_column or "")
        source_key_column = params.get("source_key_column", target_key_column)

        validate_table_name(reference_table, "reference_table")

        ref_df = self.spark.table(reference_table)
        tc = total_count if total_count is not None else df.count()

        failed_df = df.join(
            ref_df,
            df[target_key_column] == ref_df[source_key_column],
            "left_anti",
        )

        # Single-pass: count failed rows via aggregation instead of separate count
        failed_count = failed_df.count()
        passed_count = tc - failed_count
        pass_rate = (passed_count / tc) if tc > 0 else 1.0

        failed_rows_df = self._collect_failed_rows(failed_df, 100)

        return CheckResult(
            rule_id=rule.rule_id,
            run_id="",
            rows_evaluated=tc,
            rows_passed=passed_count,
            rows_failed=failed_count,
            pass_rate=pass_rate,
            status="pass" if failed_count == 0 else "fail",
            failed_rows=[],
            failed_rows_df=failed_rows_df,
            full_failed_rows_df=failed_df,
        )

    def _cross_system_match(self, df: DataFrame, rule: RuleConfig, *, total_count: int | None = None) -> CheckResult:
        """Join on key columns, report rows where compared columns differ."""
        params = rule.parameters or {}
        reference_table = params.get("reference_table", "")
        target_key_columns = params.get("target_key_columns", [])
        source_key_columns = params.get("source_key_columns", target_key_columns)
        target_comparison_columns = params.get("target_comparison_columns", [])
        source_comparison_columns = params.get(
            "source_comparison_columns", target_comparison_columns
        )

        validate_table_name(reference_table, "reference_table")
        validate_column_names(target_key_columns, "target_key_columns")
        validate_column_names(source_key_columns, "source_key_columns")
        validate_column_names(target_comparison_columns, "target_comparison_columns")
        validate_column_names(source_comparison_columns, "source_comparison_columns")

        ref_df = self.spark.table(reference_table)
        tc = total_count if total_count is not None else df.count()

        target_alias = df.alias("target")
        ref_alias = ref_df.alias("ref")

        join_cond = reduce(
            lambda a, b: a & b,
            [
                col(f"target.{t}") == col(f"ref.{s}")
                for t, s in zip(target_key_columns, source_key_columns)
            ],
        )
        joined = target_alias.join(ref_alias, join_cond, "inner")

        # Filter rows where any comparison column differs
        diff_cond = reduce(
            lambda a, b: a | b,
            [
                col(f"target.{t}") != col(f"ref.{s}")
                for t, s in zip(target_comparison_columns, source_comparison_columns)
            ],
        )

        # Single-pass aggregation on joined DataFrame for failed count
        agg_result = joined.agg(
            F.sum(F.when(diff_cond, 1).otherwise(0)).alias("failed")
        ).collect()[0]
        failed_count = int(agg_result["failed"]) if agg_result["failed"] is not None else 0

        passed_count = tc - failed_count
        pass_rate = (passed_count / tc) if tc > 0 else 1.0

        # Keep filter for collecting failed rows
        failed_df = joined.filter(diff_cond).select("target.*")
        failed_rows_df = self._collect_failed_rows(failed_df, 100)

        return CheckResult(
            rule_id=rule.rule_id,
            run_id="",
            rows_evaluated=tc,
            rows_passed=passed_count,
            rows_failed=failed_count,
            pass_rate=pass_rate,
            status="pass" if failed_count == 0 else "fail",
            failed_rows=[],
            failed_rows_df=failed_rows_df,
            full_failed_rows_df=failed_df,
        )

    def _business_rule(self, df: DataFrame, rule: RuleConfig, *, total_count: int | None = None) -> CheckResult:
        """Evaluate SQL expression, report rows where expression is false."""
        validate_expression(rule.rule_expression, "rule_expression")
        fail_condition = ~expr(rule.rule_expression)

        if total_count is not None:
            agg_result = df.agg(
                F.sum(F.when(fail_condition, 1).otherwise(0)).alias("failed")
            ).collect()[0]
            tc = total_count
            failed_count = int(agg_result["failed"]) if agg_result["failed"] is not None else 0
        else:
            agg_result = df.agg(
                F.count("*").alias("total"),
                F.sum(F.when(fail_condition, 1).otherwise(0)).alias("failed"),
            ).collect()[0]
            tc = int(agg_result["total"])
            failed_count = int(agg_result["failed"]) if agg_result["failed"] is not None else 0

        passed_count = tc - failed_count
        pass_rate = (passed_count / tc) if tc > 0 else 1.0

        # Keep the filter for collecting failed rows
        failed_df = df.filter(fail_condition)
        failed_rows_df = self._collect_failed_rows(failed_df, 100)

        return CheckResult(
            rule_id=rule.rule_id,
            run_id="",
            rows_evaluated=tc,
            rows_passed=passed_count,
            rows_failed=failed_count,
            pass_rate=pass_rate,
            status="pass" if failed_count == 0 else "fail",
            failed_rows=[],
            failed_rows_df=failed_rows_df,
            full_failed_rows_df=failed_df,
        )
