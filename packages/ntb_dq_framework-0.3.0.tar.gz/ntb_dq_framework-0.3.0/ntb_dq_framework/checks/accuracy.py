"""Accuracy dimension check executor.

Supports three rule types:
- **reference_match** — joins the target DataFrame with a reference table on
  a key column and reports rows where the comparison column differs.
- **tolerance_match** — joins the target DataFrame with a reference table and
  reports rows where the absolute difference exceeds a configured tolerance.
- **reconciliation** — computes aggregate values (sum/count) on the target
  and reference tables and reports the delta amount and delta percentage.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from pyspark.sql import functions as F
from pyspark.sql.functions import abs as spark_abs, col

from ntb_dq_framework.checks.base import BaseCheck
from ntb_dq_framework.models import CheckResult, RuleConfig
from ntb_dq_framework.sql_guard import validate_table_name

if TYPE_CHECKING:
    from pyspark.sql import DataFrame, SparkSession


class AccuracyCheck(BaseCheck):
    """Check executor for the Accuracy dimension."""

    def __init__(self, spark: SparkSession) -> None:
        self.spark = spark

    def execute(self, df: DataFrame, rule: RuleConfig, *, total_count: int | None = None) -> CheckResult:
        """Dispatch to the appropriate sub-check based on *rule.rule_type*."""
        dispatch = {
            "reference_match": self._reference_match,
            "tolerance_match": self._tolerance_match,
            "reconciliation": self._reconciliation,
        }
        handler = dispatch.get(rule.rule_type)
        if handler is None:
            return CheckResult(
                rule_id=rule.rule_id,
                run_id="",
                rows_evaluated=0,
                rows_passed=0,
                rows_failed=0,
                pass_rate=1.0,
                status="error",
                extra_params={"error": f"Unknown rule_type: {rule.rule_type}"},
            )
        return handler(df, rule, total_count=total_count)

    # ------------------------------------------------------------------
    # Private sub-checks
    # ------------------------------------------------------------------

    def _reference_match(self, df: DataFrame, rule: RuleConfig, *, total_count: int | None = None) -> CheckResult:
        """Join target with reference table on key and report mismatched rows."""
        params = rule.parameters or {}
        reference_table = params.get("reference_table", "")
        target_key_column = params.get("target_key_column", "")
        source_key_column = params.get("source_key_column", target_key_column)
        target_comparison_column = params.get(
            "target_comparison_column", rule.target_column or ""
        )
        source_comparison_column = params.get(
            "source_comparison_column", target_comparison_column
        )

        validate_table_name(reference_table, "reference_table")

        ref_df = self.spark.table(reference_table)
        tc = total_count if total_count is not None else df.count()

        target_alias = df.alias("target")
        ref_alias = ref_df.alias("ref")

        joined = target_alias.join(
            ref_alias,
            col(f"target.{target_key_column}") == col(f"ref.{source_key_column}"),
            "inner",
        )
        fail_condition = col(f"target.{target_comparison_column}") != col(
            f"ref.{source_comparison_column}"
        )

        # Single-pass aggregation on joined DataFrame for failed count
        agg_result = joined.agg(
            F.sum(F.when(fail_condition, 1).otherwise(0)).alias("failed")
        ).collect()[0]
        failed_count = int(agg_result["failed"]) if agg_result["failed"] is not None else 0

        passed_count = tc - failed_count
        pass_rate = (passed_count / tc) if tc > 0 else 1.0

        # Keep filter for collecting failed rows
        failed_df = joined.filter(fail_condition).select("target.*")
        failed_rows_df = self._collect_failed_rows(failed_df, 100)

        return CheckResult(
            rule_id=rule.rule_id,
            run_id="",
            rows_evaluated=tc,
            rows_passed=passed_count,
            rows_failed=failed_count,
            pass_rate=pass_rate,
            status="pass" if failed_count == 0 else "fail",
            failed_rows=[],
            failed_rows_df=failed_rows_df,
            full_failed_rows_df=failed_df,
        )

    def _tolerance_match(self, df: DataFrame, rule: RuleConfig, *, total_count: int | None = None) -> CheckResult:
        """Join target with reference and report rows exceeding tolerance."""
        params = rule.parameters or {}
        reference_table = params.get("reference_table", "")
        target_key_column = params.get("target_key_column", "")
        source_key_column = params.get("source_key_column", target_key_column)
        target_comparison_column = params.get(
            "target_comparison_column", rule.target_column or ""
        )
        source_comparison_column = params.get(
            "source_comparison_column", target_comparison_column
        )
        tolerance = float(params.get("tolerance", 0))

        validate_table_name(reference_table, "reference_table")

        ref_df = self.spark.table(reference_table)
        tc = total_count if total_count is not None else df.count()

        target_alias = df.alias("target")
        ref_alias = ref_df.alias("ref")

        joined = target_alias.join(
            ref_alias,
            col(f"target.{target_key_column}") == col(f"ref.{source_key_column}"),
            "inner",
        )
        fail_condition = (
            spark_abs(
                col(f"target.{target_comparison_column}")
                - col(f"ref.{source_comparison_column}")
            )
            > tolerance
        )

        # Single-pass aggregation on joined DataFrame for failed count
        agg_result = joined.agg(
            F.sum(F.when(fail_condition, 1).otherwise(0)).alias("failed")
        ).collect()[0]
        failed_count = int(agg_result["failed"]) if agg_result["failed"] is not None else 0

        passed_count = tc - failed_count
        pass_rate = (passed_count / tc) if tc > 0 else 1.0

        # Keep filter for collecting failed rows
        failed_df = joined.filter(fail_condition).select("target.*")
        failed_rows_df = self._collect_failed_rows(failed_df, 100)

        return CheckResult(
            rule_id=rule.rule_id,
            run_id="",
            rows_evaluated=tc,
            rows_passed=passed_count,
            rows_failed=failed_count,
            pass_rate=pass_rate,
            status="pass" if failed_count == 0 else "fail",
            failed_rows=[],
            failed_rows_df=failed_rows_df,
            full_failed_rows_df=failed_df,
        )

    def _reconciliation(self, df: DataFrame, rule: RuleConfig, *, total_count: int | None = None) -> CheckResult:
        """Compute aggregate on target and reference, report delta."""
        params = rule.parameters or {}
        reference_table = params.get("reference_table", "")
        aggregate_column = params.get("aggregate_column", rule.target_column or "")
        aggregate_function = params.get("aggregate_function", "sum")

        validate_table_name(reference_table, "reference_table")

        ref_df = self.spark.table(reference_table)
        tc = total_count if total_count is not None else df.count()

        if aggregate_function == "count":
            target_agg = float(df.count())
            ref_agg = float(ref_df.count())
        else:
            # Default to sum
            target_row = df.agg({aggregate_column: "sum"}).collect()[0]
            target_agg = float(target_row[0]) if target_row[0] is not None else 0.0
            ref_row = ref_df.agg({aggregate_column: "sum"}).collect()[0]
            ref_agg = float(ref_row[0]) if ref_row[0] is not None else 0.0

        delta_amount = target_agg - ref_agg
        delta_percentage = (delta_amount / ref_agg * 100.0) if ref_agg != 0 else 0.0

        failed_count = 1 if delta_amount != 0 else 0
        passed_count = tc - failed_count
        pass_rate = (passed_count / tc) if tc > 0 else 1.0

        return CheckResult(
            rule_id=rule.rule_id,
            run_id="",
            rows_evaluated=tc,
            rows_passed=passed_count,
            rows_failed=failed_count,
            pass_rate=pass_rate,
            status="pass" if failed_count == 0 else "fail",
            extra_params={
                "delta_amount": delta_amount,
                "delta_percentage": delta_percentage,
                "target_aggregate": target_agg,
                "reference_aggregate": ref_agg,
                "aggregate_function": aggregate_function,
            },
        )
