"""Data Quality framework for Databricks — rule-based checks across six dimensions with Delta table persistence."""

from ntb_dq_framework.engine import DQEngine

__all__ = ["DQEngine"]
