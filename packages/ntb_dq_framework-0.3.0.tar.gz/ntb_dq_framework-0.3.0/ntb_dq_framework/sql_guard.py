"""SQL injection guard for the DQ Framework.

Provides validation helpers that reject dangerous patterns in user-supplied
strings before they reach Spark SQL or ``expr()``.
"""

from __future__ import annotations

import re

from ntb_dq_framework.exceptions import DQValidationError

# ---------------------------------------------------------------------------
# Dangerous SQL pattern (case-insensitive)
# ---------------------------------------------------------------------------
# Matches standalone SQL keywords that should never appear in user-supplied
# strings — covers identifiers, expressions, and column names.
_DANGEROUS_SQL_PATTERN = re.compile(
    r"""
    (?:--|/\*|\*/)                          # SQL comments
    | \b(?:DROP|ALTER|CREATE|INSERT|UPDATE|DELETE|TRUNCATE|MERGE|GRANT|REVOKE)\b
    | \bINTO\s+(?:OUTFILE|DUMPFILE)\b
    | \bUNION\s+(?:ALL\s+)?SELECT\b
    | \bEXEC(?:UTE)?\s*\(
    | \bxp_\w+
    | \bsp_\w+
    """,
    re.IGNORECASE | re.VERBOSE,
)

# Table names must follow catalog.schema.table pattern (alphanumeric + underscores + dots)
_VALID_TABLE_NAME = re.compile(r"^[a-zA-Z0-9_]+(?:\.[a-zA-Z0-9_]+){0,2}$")


def validate_identifier(value: str, field_name: str) -> None:
    """Reject *value* if it contains dangerous SQL patterns.

    Used for rule_name, target_table, target_column, rule_type, owner.
    """
    if _DANGEROUS_SQL_PATTERN.search(value):
        raise DQValidationError(
            f"Potentially unsafe SQL detected in '{field_name}': {value!r}"
        )


def validate_table_name(value: str, field_name: str) -> None:
    """Reject *value* if it doesn't look like a valid table identifier."""
    if not value:
        raise DQValidationError(
            f"'{field_name}' is required but was empty or not provided."
        )
    if not _VALID_TABLE_NAME.match(value):
        raise DQValidationError(
            f"Invalid table name in '{field_name}': {value!r}. "
            "Expected format: catalog.schema.table (alphanumeric and underscores only)"
        )


def validate_expression(value: str, field_name: str) -> None:
    """Reject *value* if it contains DDL/DML or comment injection.

    Allows normal SQL boolean expressions (comparisons, AND/OR, functions)
    but blocks destructive statements.
    """
    if not value:
        return
    if _DANGEROUS_SQL_PATTERN.search(value):
        raise DQValidationError(
            f"Potentially unsafe SQL detected in '{field_name}': {value!r}. "
            "Only column comparisons and boolean expressions are allowed."
        )


def validate_column_names(columns: list[str], field_name: str) -> None:
    """Reject column names that contain dangerous SQL patterns."""
    for c in columns:
        if _DANGEROUS_SQL_PATTERN.search(c):
            raise DQValidationError(
                f"Potentially unsafe SQL detected in '{field_name}' column: {c!r}"
            )
