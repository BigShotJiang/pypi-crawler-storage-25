"""Result writer for the DQ Framework.

Persists run logs, per-rule check results, and sample failing records
to their respective Delta tables.
"""

from __future__ import annotations

from datetime import datetime

from ntb_dq_framework.models import CheckResult


class ResultWriter:
    """Writes DQ run metadata, check results, and failed records to Delta tables."""

    def __init__(
        self,
        spark,
        result_table: str,
        failed_records_table: str,
        run_log_table: str,
        max_failed_samples: int = 100,
    ) -> None:
        self.spark = spark
        self.result_table = result_table
        self.failed_records_table = failed_records_table
        self.run_log_table = run_log_table
        self.max_failed_samples = max_failed_samples

    # ------------------------------------------------------------------
    # Run Log operations
    # ------------------------------------------------------------------

    def write_run_log(self, run_log: dict) -> int:
        """Insert a new Run Log entry from the provided dict.

        Builds a single-row DataFrame and uses
        df.write.mode("append").saveAsTable() instead of raw SQL INSERT.
        Returns the auto-generated run_id.

        Expected keys: target_table, run_start_time,
        run_end_time, total_rows_input, total_rows_passed, total_rows_failed,
        status, run_date, parameters.
        """
        from pyspark.sql import Row
        from pyspark.sql.types import (
            DateType,
            LongType,
            StringType,
            StructField,
            StructType,
            TimestampType,
        )

        schema = StructType([
            StructField("target_table", StringType(), True),
            StructField("run_start_time", TimestampType(), True),
            StructField("run_end_time", TimestampType(), True),
            StructField("total_rows_input", LongType(), True),
            StructField("total_rows_passed", LongType(), True),
            StructField("total_rows_failed", LongType(), True),
            StructField("status", StringType(), True),
            StructField("run_date", DateType(), True),
            StructField("parameters", StringType(), True),
        ])

        row_data = Row(
            target_table=run_log.get("target_table", ""),
            run_start_time=run_log.get("run_start_time"),
            run_end_time=run_log.get("run_end_time"),
            total_rows_input=int(run_log["total_rows_input"]) if run_log.get("total_rows_input") is not None else None,
            total_rows_passed=int(run_log["total_rows_passed"]) if run_log.get("total_rows_passed") is not None else None,
            total_rows_failed=int(run_log["total_rows_failed"]) if run_log.get("total_rows_failed") is not None else None,
            status=run_log.get("status", "running"),
            run_date=run_log.get("run_date"),
            parameters=run_log.get("parameters"),
        )

        df = self.spark.createDataFrame([row_data], schema=schema)
        df.write.mode("append").saveAsTable(self.run_log_table)

        # Read back the auto-generated run_id
        read_back = self.spark.sql(
            f"SELECT run_id FROM {self.run_log_table} ORDER BY run_id DESC LIMIT 1"
        ).collect()[0]
        return int(read_back.run_id)


    def update_run_log(self, run_id: int, updates: dict) -> None:
        """Update an existing Run Log entry (status, end_time, totals, parameters)."""
        set_clauses: list[str] = []

        if "status" in updates:
            set_clauses.append(f"status = {self._sql_str(updates['status'])}")
        if "run_end_time" in updates:
            set_clauses.append(f"run_end_time = {self._sql_timestamp(updates['run_end_time'])}")
        if "total_rows_input" in updates:
            set_clauses.append(f"total_rows_input = {self._sql_bigint(updates['total_rows_input'])}")
        if "total_rows_passed" in updates:
            set_clauses.append(f"total_rows_passed = {self._sql_bigint(updates['total_rows_passed'])}")
        if "total_rows_failed" in updates:
            set_clauses.append(f"total_rows_failed = {self._sql_bigint(updates['total_rows_failed'])}")
        if "parameters" in updates:
            set_clauses.append(f"parameters = {self._sql_str(updates['parameters'])}")

        if not set_clauses:
            return

        sql = f"""
            UPDATE {self.run_log_table}
            SET {', '.join(set_clauses)}
            WHERE run_id = {run_id}
        """
        self.spark.sql(sql)

    # ------------------------------------------------------------------
    # Result Table operations
    # ------------------------------------------------------------------

    def write_result(self, result: CheckResult) -> int:
        """Write a CheckResult to the Result Table.

        Computes pass_rate and status, and inserts a row into the Result
        Table using a DataFrame-based insert. Returns the auto-generated
        result_id.
        """
        from pyspark.sql import Row
        from pyspark.sql.types import (
            DateType,
            DoubleType,
            IntegerType,
            LongType,
            StringType,
            StructField,
            StructType,
            TimestampType,
        )

        # Compute pass_rate: 1.0 when rows_evaluated is 0
        if result.rows_evaluated > 0:
            pass_rate = float(result.rows_passed / result.rows_evaluated)
        else:
            pass_rate = 1.0

        # Compute status: keep "error" if already set, otherwise pass/fail
        if result.status == "error":
            status = "error"
        elif result.rows_failed == 0:
            status = "pass"
        else:
            status = "fail"

        failure_sample_count = len(result.failed_rows)
        target_column = result.extra_params.get("target_column") if "target_column" in result.extra_params else None
        rule_name = result.extra_params.get("rule_name", "")
        dimension = result.extra_params.get("dimension", "")
        target_table = result.extra_params.get("target_table", "")
        run_date = result.extra_params.get("run_date")

        schema = StructType([
            StructField("run_id", LongType(), False),
            StructField("rule_id", LongType(), False),
            StructField("rule_name", StringType(), True),
            StructField("dimension", StringType(), True),
            StructField("target_table", StringType(), True),
            StructField("target_column", StringType(), True),
            StructField("rows_evaluated", LongType(), True),
            StructField("rows_passed", LongType(), True),
            StructField("rows_failed", LongType(), True),
            StructField("pass_rate", DoubleType(), True),
            StructField("status", StringType(), True),
            StructField("failure_sample_count", IntegerType(), True),
            StructField("execution_time_ms", LongType(), True),
            StructField("result_timestamp", TimestampType(), True),
            StructField("run_date", DateType(), True),
        ])

        row_data = Row(
            run_id=int(result.run_id),
            rule_id=int(result.rule_id),
            rule_name=rule_name,
            dimension=dimension,
            target_table=target_table,
            target_column=target_column,
            rows_evaluated=int(result.rows_evaluated),
            rows_passed=int(result.rows_passed),
            rows_failed=int(result.rows_failed),
            pass_rate=pass_rate,
            status=status,
            failure_sample_count=int(failure_sample_count),
            execution_time_ms=int(result.execution_time_ms),
            result_timestamp=datetime.now(),
            run_date=run_date,
        )

        df = self.spark.createDataFrame([row_data], schema=schema)
        df.write.mode("append").saveAsTable(self.result_table)

        # Read back the auto-generated result_id
        read_back = self.spark.sql(
            f"SELECT result_id FROM {self.result_table} ORDER BY result_id DESC LIMIT 1"
        ).collect()[0]
        return int(read_back.result_id)


    # ------------------------------------------------------------------
    # Failed Records operations
    # ------------------------------------------------------------------

    def write_failed_records(self, records, metadata: dict, uncapped: bool = False) -> None:
        """Write failing records to the Failed Records Table.

        Accepts either a PySpark DataFrame of failed rows or a list of dicts
        (for backward compatibility). Records are capped at max_failed_samples
        unless *uncapped* is True (used for critical-severity rules).

        When a DataFrame is provided, metadata columns are added via
        withColumn() and all records are written in a single batch using
        df.write.mode("append").saveAsTable().

        When a list of dicts is provided, it is converted to a DataFrame
        first and then follows the same batch write path.

        metadata should contain: result_id, run_id, rule_id, target_table,
        failure_reason, run_date.
        """
        from pyspark.sql import functions as F
        from pyspark.sql.types import StringType

        result_id = metadata.get("result_id", 0)
        run_id = metadata.get("run_id", 0)
        rule_id = metadata.get("rule_id", 0)
        target_table = metadata.get("target_table", "")
        failure_reason = metadata.get("failure_reason", "")
        run_date = metadata.get("run_date")

        if isinstance(records, list):
            if uncapped:
                capped = records
            else:
                capped = records[: self.max_failed_samples]
            if not capped:
                return
            failed_df = self.spark.createDataFrame(capped)
        else:
            # PySpark DataFrame (or Spark Connect DataFrame)
            if uncapped:
                failed_df = records
            else:
                failed_df = records.limit(self.max_failed_samples)

        # Serialize all original columns to a single JSON string
        failed_record_col = F.to_json(F.struct("*"))

        # Build the output DataFrame with metadata columns
        output_df = (
            failed_df
            .withColumn("result_id", F.lit(int(result_id)).cast("bigint"))
            .withColumn("run_id", F.lit(int(run_id)).cast("bigint"))
            .withColumn("rule_id", F.lit(int(rule_id)).cast("bigint"))
            .withColumn("target_table", F.lit(target_table).cast(StringType()))
            .withColumn("failed_record", failed_record_col)
            .withColumn("failure_reason", F.lit(failure_reason).cast(StringType()))
            .withColumn("run_date", F.lit(str(run_date)).cast("date") if run_date is not None else F.lit(None).cast("date"))
            .withColumn("recorded_at", F.current_timestamp())
            .select(
                "result_id", "run_id", "rule_id",
                "target_table", "failed_record", "failure_reason",
                "run_date", "recorded_at",
            )
        )

        output_df.write.mode("append").saveAsTable(self.failed_records_table)


    # ------------------------------------------------------------------
    # SQL value helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _sql_str(value) -> str:
        """Return a SQL-safe quoted string or NULL."""
        if value is None:
            return "NULL"
        escaped = str(value).replace("'", "\\'")
        return f"'{escaped}'"

    @staticmethod
    def _sql_timestamp(value) -> str:
        """Return a SQL TIMESTAMP literal or NULL."""
        if value is None:
            return "NULL"
        if isinstance(value, datetime):
            return f"TIMESTAMP '{value.strftime('%Y-%m-%d %H:%M:%S')}'"
        return f"TIMESTAMP '{value}'"

    @staticmethod
    def _sql_bigint(value) -> str:
        """Return a SQL BIGINT literal or NULL."""
        if value is None:
            return "NULL"
        return str(int(value))

    @staticmethod
    def _sql_date(value) -> str:
        """Return a SQL DATE literal or NULL."""
        if value is None:
            return "NULL"
        if hasattr(value, "strftime"):
            return f"DATE '{value.strftime('%Y-%m-%d')}'"
        return f"DATE '{value}'"
