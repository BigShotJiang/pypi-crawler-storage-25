# Databricks notebook source

# COMMAND ----------

# ============================================================
# DQ Framework — Example Template
# ============================================================
# Copy this notebook and replace the placeholder values
# (marked with <...>) with your actual catalog, schema,
# table, and column names.
#
# Dimensions : Accuracy, Completeness, Consistency,
#              Timeliness, Validity, Uniqueness
# Severities : "critical" (recorded), "warning" (logged only)
# ============================================================


# COMMAND ----------

from ntb_dq_framework import DQEngine

# 1. Initialize — point at your Unity Catalog location
engine = DQEngine(
    spark,
    catalog="<your_catalog>",
    schema="<your_schema>", # optional default is data_quality
)

TARGET_TABLE = "<your_catalog>.<your_schema>.<your_table>"


# COMMAND ----------

# ============================================================
# ACCURACY
# ============================================================

# reference_match — join with a reference table, report mismatched rows
engine.add_rule(
    rule_name="<descriptive_rule_name>",
    dimension="Accuracy",
    target_table=TARGET_TABLE,
    target_column="<column_to_compare>",
    rule_type="reference_match",
    parameters={
        "reference_table": "<catalog.schema.reference_table>",
        "target_key_column": "<target_join_key>",
        "source_key_column": "<source_join_key>",  # optional — defaults to target_key_column
        "target_comparison_column": "<target_column_to_compare>",
        "source_comparison_column": "<source_column_to_compare>",  # optional — defaults to target_comparison_column
    },
    severity="critical",
    owner="<team_or_owner>",
)

# tolerance_match — like reference_match but allows a numeric tolerance
engine.add_rule(
    rule_name="<descriptive_rule_name>",
    dimension="Accuracy",
    target_table=TARGET_TABLE,
    target_column="<numeric_column>",
    rule_type="tolerance_match",
    parameters={
        "reference_table": "<catalog.schema.reference_table>",
        "target_key_column": "<target_join_key>",
        "source_key_column": "<source_join_key>",  # optional — defaults to target_key_column
        "target_comparison_column": "<target_numeric_column>",
        "source_comparison_column": "<source_numeric_column>",  # optional — defaults to target_comparison_column
        "tolerance": 0.01,  # allowed absolute difference
    },
    severity="warning",
    owner="<team_or_owner>",
)

# reconciliation — compare aggregate values (sum/count) between tables
engine.add_rule(
    rule_name="<descriptive_rule_name>",
    dimension="Accuracy",
    target_table=TARGET_TABLE,
    target_column="<aggregate_column>",
    rule_type="reconciliation",
    parameters={
        "reference_table": "<catalog.schema.reference_table>",
        "aggregate_column": "<column_to_aggregate>",
        "aggregate_function": "sum",  # or "count"
    },
    severity="critical",
    owner="<team_or_owner>",
)


# COMMAND ----------

# ============================================================
# COMPLETENESS
# ============================================================

# null_check — count rows where column is null or empty
engine.add_rule(
    rule_name="<descriptive_rule_name>",
    dimension="Completeness",
    target_table=TARGET_TABLE,
    target_column="<column_to_check>",
    rule_type="null_check",
    severity="critical",
    owner="<team_or_owner>",
)

# missing_partition — compare expected date partitions vs actual
engine.add_rule(
    rule_name="<descriptive_rule_name>",
    dimension="Completeness",
    target_table=TARGET_TABLE,
    rule_type="missing_partition",
    parameters={
        "expected_partitions": ["2025-01-01", "2025-01-02", "2025-01-03"],
        "partition_column": "<date_partition_column>",
    },
    severity="warning",
    owner="<team_or_owner>",
)

# volume_check — row count against a baseline threshold
engine.add_rule(
    rule_name="<descriptive_rule_name>",
    dimension="Completeness",
    target_table=TARGET_TABLE,
    rule_type="volume_check",
    parameters={
        "baseline": 10000,              # expected minimum row count
        "threshold_percentage": 10,     # allowed % deviation below baseline
    },
    severity="critical",
    owner="<team_or_owner>",
)


# COMMAND ----------

# ============================================================
# CONSISTENCY
# ============================================================

# referential_integrity — left anti-join to find orphan rows
engine.add_rule(
    rule_name="<descriptive_rule_name>",
    dimension="Consistency",
    target_table=TARGET_TABLE,
    target_column="<foreign_key_column>",
    rule_type="referential_integrity",
    parameters={
        "reference_table": "<catalog.schema.parent_table>",
        "target_key_column": "<foreign_key_in_target>",
        "source_key_column": "<primary_key_in_reference>",  # optional — defaults to target_key_column
    },
    severity="critical",
    owner="<team_or_owner>",
)

# cross_system_match — join on keys, report rows where compared columns differ
engine.add_rule(
    rule_name="<descriptive_rule_name>",
    dimension="Consistency",
    target_table=TARGET_TABLE,
    rule_type="cross_system_match",
    parameters={
        "reference_table": "<catalog.schema.other_system_table>",
        "target_key_columns": ["<target_join_key_1>", "<target_join_key_2>"],
        "source_key_columns": ["<source_join_key_1>", "<source_join_key_2>"],  # optional — defaults to target_key_columns
        "target_comparison_columns": ["<target_col_a>", "<target_col_b>"],
        "source_comparison_columns": ["<source_col_a>", "<source_col_b>"],  # optional — defaults to target_comparison_columns
    },
    severity="warning",
    owner="<team_or_owner>",
)

# business_rule — SQL boolean expression; rows where it evaluates to false fail
engine.add_rule(
    rule_name="<descriptive_rule_name>",
    dimension="Consistency",
    target_table=TARGET_TABLE,
    rule_type="business_rule",
    rule_expression="<sql_boolean_expression>",  # e.g. "end_date >= start_date"
    severity="critical",
    owner="<team_or_owner>",
)


# COMMAND ----------

# ============================================================
# TIMELINESS
# ============================================================

# freshness_check — compute delay in hours since the latest timestamp value
engine.add_rule(
    rule_name="<descriptive_rule_name>",
    dimension="Timeliness",
    target_table=TARGET_TABLE,
    target_column="<timestamp_column>",
    rule_type="freshness_check",
    severity="warning",
    owner="<team_or_owner>",
)

# sla_check — fail when freshness delay exceeds a threshold
engine.add_rule(
    rule_name="<descriptive_rule_name>",
    dimension="Timeliness",
    target_table=TARGET_TABLE,
    target_column="<timestamp_column>",
    rule_type="sla_check",
    parameters={
        "sla_threshold_hours": 24,  # max acceptable delay in hours
    },
    severity="critical",
    owner="<team_or_owner>",
)


# COMMAND ----------

# ============================================================
# VALIDITY
# ============================================================

# regex_check — rows not matching a regex pattern
engine.add_rule(
    rule_name="<descriptive_rule_name>",
    dimension="Validity",
    target_table=TARGET_TABLE,
    target_column="<string_column>",
    rule_type="regex_check",
    rule_expression=r"<regex_pattern>",  # e.g. r"^[A-Z]{2}\d{6}$"
    severity="warning",
    owner="<team_or_owner>",
)

# allowed_values — rows with values not in an allowed list
engine.add_rule(
    rule_name="<descriptive_rule_name>",
    dimension="Validity",
    target_table=TARGET_TABLE,
    target_column="<categorical_column>",
    rule_type="allowed_values",
    parameters={
        "allowed_values": ["<value_1>", "<value_2>", "<value_3>"],
    },
    severity="critical",
    owner="<team_or_owner>",
)

# range_check — rows outside min/max bounds
engine.add_rule(
    rule_name="<descriptive_rule_name>",
    dimension="Validity",
    target_table=TARGET_TABLE,
    target_column="<numeric_column>",
    rule_type="range_check",
    parameters={
        "min": 0,
        "max": 100,
    },
    severity="warning",
    owner="<team_or_owner>",
)

# type_check — rows that can't be cast to a target type
engine.add_rule(
    rule_name="<descriptive_rule_name>",
    dimension="Validity",
    target_table=TARGET_TABLE,
    target_column="<column_to_cast>",
    rule_type="type_check",
    parameters={
        "target_type": "double",  # e.g. "int", "double", "date", "timestamp"
    },
    severity="critical",
    owner="<team_or_owner>",
)


# COMMAND ----------

# ============================================================
# UNIQUENESS
# ============================================================

# duplicate_check — group by key columns, identify duplicate groups
engine.add_rule(
    rule_name="<descriptive_rule_name>",
    dimension="Uniqueness",
    target_table=TARGET_TABLE,
    rule_type="duplicate_check",
    parameters={
        "key_columns": ["<unique_key_1>", "<unique_key_2>"],
    },
    severity="critical",
    owner="<team_or_owner>",
)


# COMMAND ----------

# ============================================================
# Run checks and view results
# ============================================================

summary = engine.run_checks(TARGET_TABLE)
print(f"Passed: {summary.total_rows_passed}, Failed: {summary.total_rows_failed}")

results_df = engine.get_results(run_id=summary.run_id)
results_df.show()

