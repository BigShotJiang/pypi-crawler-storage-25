from typing import Self

from pydantic import model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    # [INSERT: fields]

    app_name: str = "{{ cookiecutter.service_name }}"
    port: int = {{ cookiecutter.port }}
    has_structured_logging: bool = {{ "True" if cookiecutter.has_structured_logging else "False" }}
    include_actuator_endpoints: bool = False

    app_env: str = "development"
    enforce_strong_db_credentials: bool = False

    {%- if cookiecutter.has_database %}
    has_database: bool = True
    db_kind: str = "{{ cookiecutter.database }}"
    db_path: str = "./service.db"
    db_host: str = "localhost"
    db_port: int = {{ "3306" if cookiecutter.database == "maria" else "5432" }}
    db_user: str = "service_user"
    db_password: str = "change_me"
    db_name: str = "service_db"
    {%- else %}
    has_database: bool = False
    {%- endif %}

    {%- if cookiecutter.has_delegates %}
    has_delegates: bool = True
    upstreams: str = "{{ cookiecutter.upstreams }}"
    {%- else %}
    has_delegates: bool = False
    {%- endif %}

    {%- if cookiecutter.has_workers %}
    has_workers: bool = True
    worker_broker: str = "{{ cookiecutter.broker }}"
    {%- if cookiecutter.broker == "redis" %}
    worker_broker_url: str = "redis://localhost:6380/1"
    {%- else %}
    worker_broker_url: str = "amqp://service_rabbit:change_me@localhost:5672/"
    {%- endif %}
    {%- else %}
    has_workers: bool = False
    {%- endif %}

    {%- if cookiecutter.has_caching %}
    has_caching: bool = True
    cache_backend: str = "{{ cookiecutter.cache_backend }}"
    cache_url: str = "redis://localhost:6379/0"
    {%- else %}
    has_caching: bool = False
    {%- endif %}

    @model_validator(mode="after")
    def validate_db_credentials(self) -> Self:
        if not self.has_database:
            return self
        if self.db_kind == "sqlite":
            return self

        if not self.enforce_strong_db_credentials and self.app_env.lower() != "production":
            return self

        weak_values = {
            "",
            "{{cookiecutter.__service_name_snake}}",
            "sandbox",
            "service_user",
            "service_db",
            "change_me",
            "password",
            "root",
            "postgres",
        }
        if self.db_user.strip().lower() in weak_values:
            raise ValueError("DB_USER must be explicitly set to a non-default value")
        if self.db_password.strip().lower() in weak_values:
            raise ValueError("DB_PASSWORD must be explicitly set to a strong non-default value")
        if self.db_name.strip().lower() in weak_values:
            raise ValueError("DB_NAME must be explicitly set to a non-default value")

        return self


settings = Settings()
