"""Utilities shared across the `sup3r.models` module"""

import inspect
import logging
import os
import sys
import threading
from dataclasses import dataclass, replace
from typing import ClassVar, Optional

import numpy as np
import phygnn.layers.custom_layers as _phygnn_layers
import tensorflow as tf
from scipy.interpolate import RegularGridInterpolator

from sup3r.utilities.utilities import Timer

logger = logging.getLogger(__name__)


def get_sup3r_layers():
    """Get all classes from phygnn.layers.custom_layers whose names start
    with 'Sup3r'.

    Returns
    -------
    tuple
        Tuple of all Sup3r* layer classes from phygnn.layers.custom_layers.
    """
    return tuple(
        obj
        for name, obj in inspect.getmembers(_phygnn_layers, inspect.isclass)
        if name.startswith('Sup3r')
    )


SUP3R_LAYERS = get_sup3r_layers()


@dataclass
class TrainingConfig:
    """Shared training configuration for trainable sup3r models."""

    GAN_DEFAULTS: ClassVar[dict] = {
        'out_dir': './gan_{epoch}',
    }
    CONDITIONAL_DEFAULTS: ClassVar[dict] = {
        'out_dir': './condMom_{epoch}',
    }

    input_resolution: Optional[dict] = None
    n_epoch: Optional[int] = None
    weight_gen_advers: float = 0.001
    train_gen: bool = True
    train_disc: bool = True
    disc_loss_bounds: tuple = (0.45, 0.6)
    checkpoint_int: Optional[int] = None
    out_dir: Optional[str] = None
    early_stop_on: Optional[str] = None
    early_stop_threshold: float = 0.005
    early_stop_n_epoch: int = 5
    adaptive_update_bounds: tuple = (0.9, 0.99)
    adaptive_update_fraction: float = 0.0
    multi_gpu: bool = False
    log_tb: bool = False
    export_tb: bool = False

    def __post_init__(self):
        """Validate required training config fields."""
        missing = [
            field
            for field in ('input_resolution', 'out_dir')
            if getattr(self, field) is None
        ]
        if missing:
            msg = 'Missing required training config fields: {}'.format(
                ', '.join(missing)
            )
            logger.error(msg)
            raise ValueError(msg)

    @staticmethod
    def _normalize_kwargs(kwargs):
        """Normalize legacy train kwargs into TrainingConfig fields."""
        kwargs = dict(kwargs)
        if 'tensorboard_log' in kwargs:
            if 'log_tb' in kwargs:
                msg = 'Received both "tensorboard_log" and "log_tb".'
                logger.error(msg)
                raise ValueError(msg)
            kwargs['log_tb'] = kwargs.pop('tensorboard_log')
        return kwargs

    @classmethod
    def from_train_kwargs(cls, config=None, **kwargs):
        """Build a training config from an existing config and/or kwargs."""
        kwargs = cls._normalize_kwargs(kwargs)
        if config is None:
            return cls(**kwargs)
        if not isinstance(config, cls):
            msg = (
                f'config must be a {cls.__name__} instance, got {type(config)}'
            )
            logger.error(msg)
            raise TypeError(msg)
        return replace(config, **kwargs) if kwargs else config

    @classmethod
    def _with_profile_defaults(cls, config=None, defaults=None, **kwargs):
        """Build a config and fill unset fields from a default profile."""
        defaults = {} if defaults is None else defaults
        kwargs = cls._normalize_kwargs(kwargs)
        if config is None:
            merged = dict(defaults)
            merged.update(kwargs)
            return cls(**merged)
        if not isinstance(config, cls):
            msg = (
                f'config must be a {cls.__name__} instance, got '
                f'{type(config)}'
            )
            logger.error(msg)
            raise TypeError(msg)
        config = replace(config, **kwargs) if kwargs else config
        updates = {
            key: value
            for key, value in defaults.items()
            if getattr(config, key) is None
        }
        return replace(config, **updates) if updates else config

    @classmethod
    def for_gan(cls, config=None, **kwargs):
        """Build a GAN training config with GAN-specific defaults."""
        return cls._with_profile_defaults(
            config=config,
            defaults=cls.GAN_DEFAULTS,
            **kwargs,
        )

    @classmethod
    def for_conditional(cls, config=None, **kwargs):
        """Build a conditional-model training config with defaults."""
        return cls._with_profile_defaults(
            config=config,
            defaults=cls.CONDITIONAL_DEFAULTS,
            **kwargs,
        )


class TrainingSession:
    """Wrapper to gracefully exit batch handler thread during training, upon a
    keyboard interruption."""

    def __init__(self, batch_handler, model, config=None, **kwargs):
        """
        Parameters
        ----------
        batch_handler: BatchHandler
            Batch iterator
        model: Sup3rGan
            Gan model to run in new thread
        config : TrainingConfig | None
            Training configuration for model.train().
        **kwargs : dict
            Backwards-compatible keyword args for TrainingConfig.
        """
        self.batch_handler = batch_handler
        self.model = model
        self.config = TrainingConfig.from_train_kwargs(config=config, **kwargs)

    def run(self):
        """Wrap model.train()."""
        model_thread = threading.Thread(
            target=self.model.train,
            args=(self.batch_handler,),
            kwargs={'config': self.config},
        )
        try:
            logger.info(
                'Starting training session. Training for %s epochs',
                self.config.n_epoch,
            )
            model_thread.start()
        except KeyboardInterrupt:
            logger.info('Ending training session.')
            self.batch_handler.stop()
            model_thread.join()
            sys.exit()
        except Exception as e:
            logger.info('Ending training session. %s', e)
            self.batch_handler.stop()
            model_thread.join()
            sys.exit()

        model_thread.join()
        logger.info('Finished training')


class TensorboardMixIn:
    """MixIn class for tensorboard logging and profiling."""

    def __init__(self):
        self._tb_writer = None
        self._tb_log_dir = None
        self._total_batches = None
        self._history = None
        self.timer = Timer()

    @property
    def total_batches(self):
        """Record of total number of batches for logging."""
        if self._total_batches is None:
            if self._history is not None and 'total_batches' in self._history:
                self._total_batches = self._history['total_batches'].values[-1]
            else:
                self._total_batches = 0
        return self._total_batches

    @total_batches.setter
    def total_batches(self, value):
        """Set total number of batches."""
        self._total_batches = value

    def dict_to_tensorboard(self, entry):
        """Write data to tensorboard log file. This is usually a loss_details
        dictionary.

        Parameters
        ----------
        entry: dict
            Dictionary of values to write to tensorboard log file
        """
        with self._tb_writer.as_default():
            for name, value in entry.items():
                if isinstance(value, str):
                    tf.summary.text(name, value, self.total_batches)
                else:
                    tf.summary.scalar(name, value, self.total_batches)

    def profile_to_tensorboard(self, name, export_tb=True):
        """Write profile data to tensorboard log file.

        Parameters
        ----------
        name : str
            Tag name to use for profile info
        export_tb : bool
            Flag to enable/disable tensorboard profiling
        """
        if self._tb_writer is not None and export_tb:
            with self._tb_writer.as_default():
                tf.summary.trace_export(
                    name=name,
                    step=self.total_batches,
                    profiler_outdir=self._tb_log_dir,
                )

    def _init_tensorboard_writer(self, out_dir):
        """Initialize the ``tf.summary.SummaryWriter`` to use for writing
        tensorboard compatible log files.

        Parameters
        ----------
        out_dir : str
            Standard out_dir where model epochs are saved. e.g. './gan_{epoch}'
        """
        tb_log_pardir = os.path.abspath(os.path.join(out_dir, os.pardir))
        self._tb_log_dir = os.path.join(tb_log_pardir, 'logs')
        os.makedirs(self._tb_log_dir, exist_ok=True)
        self._tb_writer = tf.summary.create_file_writer(self._tb_log_dir)


def st_interp(low, s_enhance, t_enhance, t_centered=False):
    """Spatiotemporal bilinear interpolation for low resolution field on a
    regular grid. Used to provide baseline for comparison with gan output

    Parameters
    ----------
    low : ndarray
        Low resolution field to interpolate.
        (spatial_1, spatial_2, temporal)
    s_enhance : int
        Factor by which to enhance the spatial domain
    t_enhance : int
        Factor by which to enhance the temporal domain
    t_centered : bool
        Flag to switch time axis from time-beginning (Default, e.g.
        interpolate 00:00 01:00 to 00:00 00:30 01:00 01:30) to
        time-centered (e.g. interp 01:00 02:00 to 00:45 01:15 01:45 02:15)

    Returns
    -------
    ndarray
        Spatiotemporally interpolated low resolution output
    """
    assert len(low.shape) == 3, 'Input to st_interp must be 3D array'
    msg = 'Input to st_interp cannot include axes with length 1'
    assert not any(s <= 1 for s in low.shape), msg

    lr_y, lr_x, lr_t = low.shape
    hr_y, hr_x, hr_t = lr_y * s_enhance, lr_x * s_enhance, lr_t * t_enhance

    # assume outer bounds of mesh (0, 10) w/ points on inside of that range
    y = np.linspace(0, 10, lr_y, endpoint=False) + 5 / lr_y
    x = np.linspace(0, 10, lr_x, endpoint=False) + 5 / lr_x

    # remesh (0, 10) with high res spacing
    new_y = np.linspace(0, 10, hr_y, endpoint=False) + 5 / hr_y
    new_x = np.linspace(0, 10, hr_x, endpoint=False) + 5 / hr_x

    t = np.linspace(0, 10, lr_t, endpoint=False)
    new_t = np.linspace(0, 10, hr_t, endpoint=False)
    if t_centered:
        t += 5 / lr_t
        new_t += 5 / hr_t

    # set RegularGridInterpolator to do extrapolation
    interp = RegularGridInterpolator(
        (y, x, t), low, bounds_error=False, fill_value=None
    )

    # perform interp
    X, Y, T = np.meshgrid(new_x, new_y, new_t)
    return interp((Y, X, T))
