"""Interviews pane: DataTable of mock interviews with detail/feedback drill-down."""

from datetime import datetime, timezone

from textual import work
from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Vertical, VerticalScroll
from textual.widgets import DataTable, Static

from skilark_cli.tui.errors import friendly_error_message


def _format_when(scheduled_at: str, short: bool = False) -> str:
    """Convert a UTC ISO timestamp to local time with timezone abbreviation.

    Args:
        scheduled_at: RFC3339 string like "2026-04-03T14:00:00Z".
        short: If True, use compact format for the table column.

    Returns:
        "Apr 03 2:00 PM EDT" (short) or "Thu Apr 03, 2:00 PM EDT" (long).
    """
    if not scheduled_at:
        return "-"
    try:
        utc_dt = datetime.fromisoformat(scheduled_at.replace("Z", "+00:00"))
        local_dt = utc_dt.astimezone()
        tz_name = local_dt.strftime("%Z")
        if short:
            return local_dt.strftime("%b %d %I:%M %p").replace(" 0", " ") + f" {tz_name}"
        return local_dt.strftime("%a %b %d, %I:%M %p").replace(" 0", " ") + f" {tz_name}"
    except (ValueError, TypeError):
        return scheduled_at[:10]


def _status_label(status: str) -> str:
    """Return a Rich-markup-coloured status label."""
    styles: dict[str, str] = {
        "scheduled": "[cyan]scheduled[/cyan]",
        "in_progress": "[yellow]in_progress[/yellow]",
        "completed": "[green]completed[/green]",
        "cancelled": "[dim]cancelled[/dim]",
        "error": "[red]error[/red]",
    }
    return styles.get(status, status)


def _consolidate_transcript(transcript: list[dict]) -> list[tuple[str, str]]:
    """Merge consecutive turns from the same speaker into single utterances."""
    consolidated: list[tuple[str, str]] = []
    for turn in transcript:
        speaker = turn.get("speaker", "")
        text = turn.get("text", "")
        if consolidated and consolidated[-1][0] == speaker:
            consolidated[-1] = (speaker, consolidated[-1][1] + text)
        else:
            consolidated.append((speaker, text))
    return [(s, t.strip()) for s, t in consolidated if t.strip()]


def _render_detail_lines(
    interview: dict,
    feedback: dict | None,
    api_base_url: str = "",
    show_transcript: bool = False,
    show_feedback_detail: bool = False,
) -> list:
    """Build Rich-markup lines for the interview detail view.

    Returns a list of strings (and optionally a calendar-link tuple).
    """
    company = interview.get("company_slug", "") or "\u2014"
    status = interview.get("status", "")
    when = _format_when(interview.get("scheduled_at", ""))
    channel = interview.get("channel", "zoom")
    duration = interview.get("duration_minutes", 0)

    lines: list = [
        f"[dim]Date[/dim]      {when}",
        f"[dim]Status[/dim]    {_status_label(status)}",
        f"[dim]Company[/dim]   {company}",
        f"[dim]Channel[/dim]   {channel}  [dim]\u00b7[/dim]  {duration} min",
    ]

    # Meeting link or phone number
    meeting_link = interview.get("meeting_link")
    phone_number = interview.get("phone_number")
    if channel == "phone" and phone_number:
        lines.append(f"[dim]Phone[/dim]     {phone_number}")
    elif meeting_link:
        safe_link = meeting_link.replace("[", "\\[")
        lines.append(f"[dim]Join[/dim]      {safe_link}")

    # Calendar links — pass as tuple for OSC 8 hyperlink rendering
    calendar_token = interview.get("calendar_token")
    if calendar_token and status == "scheduled":
        if not api_base_url:
            from skilark_cli.config_store import DEFAULT_API_URL
            api_base_url = DEFAULT_API_URL
        base = api_base_url
        gcal = f"{base}/v1/interviews/calendar?token={calendar_token}&format=gcal"
        ics = f"{base}/v1/interviews/calendar?token={calendar_token}&format=ics"
        lines.append("")
        lines.append(("__cal__", gcal, ics))

    # --- Feedback summary (always visible for completed interviews) ---
    if feedback:
        lines.append("")
        lines.append("\u2500" * 40)
        score = feedback.get("overall_score")
        if score is not None:
            stars = "\u2605" * int(score) + "\u2606" * (5 - int(score))
            lines.append(f"[bold]Overall Score[/bold]  {score}/5  {stars}")
            lines.append("")

        summary = feedback.get("summary", "")
        if summary:
            lines.append(summary)
            lines.append("")

        highlights = feedback.get("highlights") or []
        for h in highlights:
            lines.append(f"  [cyan]\u2726[/cyan] {h}")
        if highlights:
            lines.append("")

    # --- Toggle hints ---
    transcript = interview.get("transcript") or []
    consolidated = _consolidate_transcript(transcript) if transcript else []
    hints: list[str] = []
    if feedback:
        tag = "[dim]d[/dim]" if not show_feedback_detail else "[bold]d[/bold]"
        hints.append(f"  \\[{tag}] Detailed feedback")
    if consolidated:
        tag = "[dim]c[/dim]" if not show_transcript else "[bold]c[/bold]"
        hints.append(f"  \\[{tag}] Transcript ({len(consolidated)} turns)")
    if hints:
        lines.append("  ".join(hints))

    # --- Detailed feedback (toggled with d) ---
    if feedback and show_feedback_detail:
        lines.append("")
        lines.append("\u2500" * 40)
        lines.append("[bold]Detailed Feedback[/bold]")
        lines.append("")
        lines.append(_render_feedback_detail(feedback))

    # --- Transcript (toggled with t) ---
    if consolidated and show_transcript:
        lines.append("")
        lines.append("\u2500" * 40)
        lines.append("[bold]Transcript[/bold]")
        lines.append("")
        for speaker, text in consolidated:
            if speaker in ("bot", "interviewer"):
                prefix = "[bold cyan]Bot[/bold cyan]"
            else:
                prefix = "[bold]You[/bold]"
            lines.append(f"  {prefix}  {text}")
            lines.append("")

    # --- No feedback yet ---
    if not feedback:
        if interview.get("has_feedback"):
            lines.append("\n[dim]Loading feedback...[/dim]")
        elif status == "completed":
            lines.append("\n[dim]Feedback not yet generated.[/dim]")

    return lines


def _render_feedback_detail(fb: dict) -> str:
    """Render strengths, improvements, and question breakdown."""
    lines: list[str] = []

    strengths = fb.get("strengths") or []
    if strengths:
        lines.append("[bold green]Strengths[/bold green]")
        for s in strengths:
            lines.append(f"  [green]+[/green] {s}")
        lines.append("")

    improvements = fb.get("improvements") or []
    if improvements:
        lines.append("[bold yellow]Areas for Improvement[/bold yellow]")
        for imp in improvements:
            lines.append(f"  [yellow]-[/yellow] {imp}")
        lines.append("")

    question_scores = fb.get("question_scores") or []
    if question_scores:
        lines.append("[bold]Question Breakdown[/bold]")
        for qs in question_scores:
            question = qs.get("question", "")
            q_score = qs.get("score")
            notes = qs.get("notes", "")
            score_str = f"  \\[{q_score}/5]" if q_score is not None else ""
            lines.append(f"  [dim]Q:[/dim] {question}{score_str}")
            if notes:
                lines.append(f"    [dim]{notes}[/dim]")

    return "\n".join(lines)


# Keep for backward compat with tests that import it
def _render_feedback(fb: dict) -> str:
    """Render feedback dict as Rich markup text for the detail view."""
    lines: list[str] = []

    score = fb.get("overall_score")
    if score is not None:
        stars = "\u2605" * int(score) + "\u2606" * (5 - int(score))
        lines.append(f"[bold]Overall Score:[/bold] {score}/5  {stars}")

    summary = fb.get("summary", "")
    if summary:
        lines.append(f"\n[bold]Summary[/bold]\n{summary}")

    highlights = fb.get("highlights") or []
    if highlights:
        lines.append("\n[bold]Highlights[/bold]")
        for h in highlights:
            lines.append(f"  [cyan]\u2726[/cyan] {h}")
        lines.append("")

    strengths = fb.get("strengths") or []
    if strengths:
        lines.append("\n[bold green]Strengths[/bold green]")
        for s in strengths:
            lines.append(f"  [green]+[/green] {s}")

    improvements = fb.get("improvements") or []
    if improvements:
        lines.append("\n[bold yellow]Areas for Improvement[/bold yellow]")
        for imp in improvements:
            lines.append(f"  [yellow]-[/yellow] {imp}")

    question_scores = fb.get("question_scores") or []
    if question_scores:
        lines.append("\n[bold]Question Breakdown[/bold]")
        for qs in question_scores:
            question = qs.get("question", "")
            q_score = qs.get("score")
            notes = qs.get("notes", "")
            score_str = f"  [{q_score}/5]" if q_score is not None else ""
            lines.append(f"  [dim]Q:[/dim] {question}{score_str}")
            if notes:
                lines.append(f"    [dim]{notes}[/dim]")

    return "\n".join(lines)


class InterviewsPane(Vertical):
    """Interviews list with detail/feedback drill-down."""

    BINDINGS = [
        Binding("n", "new_interview", "Book", show=True),
        Binding("r", "refresh", "Refresh", show=True),
        Binding("f", "view_feedback", "View Detail", show=False),
        Binding("b", "back", "Back", show=False),
        Binding("escape", "back", "Back", show=False),
        Binding("c", "toggle_transcript", "Conversation", show=False),
        Binding("d", "toggle_detail_feedback", "Details", show=False),
    ]

    def on_data_table_row_selected(self, event: DataTable.RowSelected) -> None:
        """Handle Enter/click on a row — drill into detail/feedback."""
        self.action_view_feedback()

    def __init__(self, client=None, **kwargs) -> None:
        super().__init__(**kwargs)
        self.client = client
        self._interviews: list[dict] = []
        self._view: str = "list"
        # Detail view state
        self._detail_interview: dict | None = None
        self._detail_feedback: dict | None = None
        self._show_transcript: bool = False
        self._show_feedback_detail: bool = False

    def compose(self) -> ComposeResult:
        yield Static("", id="interviews-header")
        yield DataTable(id="interviews-table")
        yield VerticalScroll(
            Static("", id="interview-detail"),
            id="interview-detail-scroll",
        )

    def on_mount(self) -> None:
        table = self.query_one("#interviews-table", DataTable)
        table.cursor_type = "row"
        table.add_columns("Role", "Type", "Company", "When", "Status", "Feedback")

        # Detail scroll is hidden until user drills in.
        self.query_one("#interview-detail-scroll", VerticalScroll).display = False

        self._load_interviews()

    def activate(self) -> None:
        """Called when tab becomes active — reload data and restore footer."""
        self._load_interviews()
        self._update_footer_bindings()

    # ------------------------------------------------------------------
    # Data loading
    # ------------------------------------------------------------------

    @work(thread=True, exit_on_error=False)
    def _load_interviews(self) -> None:
        if not self.client:
            self.app.call_from_thread(
                self._render_empty, "No API client configured."
            )
            return
        try:
            data = self.client.list_interviews()
        except Exception as exc:
            self.app.call_from_thread(
                self._render_empty, friendly_error_message(exc)
            )
            return
        interviews = data.get("interviews", [])
        self.app.call_from_thread(self._render_interviews, interviews)

    def _render_interviews(self, interviews: list[dict]) -> None:
        if not self.is_attached:
            return
        self._interviews = interviews
        self._show_list_view()

    @work(thread=True, exit_on_error=False)
    def _load_detail(self, interview_id: str) -> None:
        """Load interview detail + feedback in the background, then render."""
        try:
            interview = self.client.get_interview(interview_id)
        except Exception as exc:
            self.app.call_from_thread(
                self._render_detail_error, friendly_error_message(exc)
            )
            return

        try:
            list_entry = next(
                (iv for iv in self._interviews if iv["id"] == interview_id), None
            )
            has_feedback = (list_entry or {}).get("has_feedback", False)

            feedback: dict | None = None
            if has_feedback:
                try:
                    feedback = self.client.get_interview_feedback(interview_id)
                except Exception:
                    feedback = None

            interview["has_feedback"] = has_feedback
            self.app.call_from_thread(self._render_detail, interview, feedback)
        except Exception as exc:
            try:
                self.app.call_from_thread(
                    self._render_detail_error, friendly_error_message(exc)
                )
            except Exception:
                pass  # Avoid hang if error rendering itself fails

    # ------------------------------------------------------------------
    # Rendering
    # ------------------------------------------------------------------

    def _render_empty(self, message: str) -> None:
        if not self.is_attached:
            return
        self.query_one("#interviews-header", Static).update(
            f"[bold]Interviews[/bold]\n\n[dim]{message}[/dim]"
        )

    def _render_interviews_table(self) -> None:
        """Populate the DataTable from self._interviews."""
        header = self.query_one("#interviews-header", Static)
        if not self._interviews:
            header.update(
                "[bold]Interviews[/bold]\n\n"
                "[dim]No interviews scheduled. Press [bold]n[/bold] to book one.[/dim]"
            )
        else:
            count = len(self._interviews)
            header.update(
                f"[bold]Interviews[/bold]  "
                f"({count} interview{'s' if count != 1 else ''})"
            )

        table = self.query_one("#interviews-table", DataTable)
        table.clear()
        for iv in self._interviews:
            role = iv.get("role_title", "")
            iv_type = iv.get("interview_type", "")
            company = iv.get("company_slug", "") or "-"
            when = _format_when(iv.get("scheduled_at", ""), short=True)
            status = _status_label(iv.get("status", ""))
            feedback_flag = "[green]\u2713[/green]" if iv.get("has_feedback") else "-"
            table.add_row(
                role, iv_type, company, when, status, feedback_flag,
                key=iv["id"],
            )

    def _render_detail(self, interview: dict, feedback: dict | None) -> None:
        """Render the detail panel for a single interview."""
        if not self.is_attached:
            return

        # Cache for re-rendering on toggle
        self._detail_interview = interview
        self._detail_feedback = feedback

        self._refresh_detail_content()

    def _refresh_detail_content(self) -> None:
        """Re-render detail from cached data (called on toggle)."""
        interview = self._detail_interview
        feedback = self._detail_feedback
        if not interview or not self.is_attached:
            return

        from rich.text import Text as RichText

        api_base = str(self.client._http.base_url).rstrip("/") if self.client else ""
        lines = _render_detail_lines(
            interview, feedback, api_base_url=api_base,
            show_transcript=self._show_transcript,
            show_feedback_detail=self._show_feedback_detail,
        )

        # Separate calendar tuples from string lines
        parts: list[str] = []
        cal_entry = None
        for line in lines:
            if isinstance(line, tuple) and line[0] == "__cal__":
                cal_entry = line
            else:
                parts.append(line)
        markup_text = "\n".join(parts)

        detail = self.query_one("#interview-detail", Static)
        if cal_entry:
            _, gcal_url, ics_url = cal_entry
            content = RichText.from_markup(markup_text)
            content.append("\n  \U0001f4c5 ")
            gcal_link = RichText("Google Calendar")
            gcal_link.stylize(f"link {gcal_url}")
            content.append(gcal_link)
            content.append("  \u00b7  ")
            ics_link = RichText("Download .ics")
            ics_link.stylize(f"link {ics_url}")
            content.append(ics_link)
            content.append("\n")
            detail.update(content)
        else:
            detail.update(markup_text)

        role = interview.get("role_title", "")
        iv_type = interview.get("interview_type", "")
        header = self.query_one("#interviews-header", Static)
        header.update(
            f"[bold]{role}[/bold]  [dim]{iv_type}  \u00b7  press [bold]b[/bold] to go back[/dim]"
        )

        self._update_footer_bindings()

    def _render_detail_error(self, message: str) -> None:
        if not self.is_attached:
            return
        detail = self.query_one("#interview-detail", Static)
        detail.update(f"[red]{message}[/red]")

    # ------------------------------------------------------------------
    # View switching
    # ------------------------------------------------------------------

    def _show_list_view(self) -> None:
        self._view = "list"
        self._detail_interview = None
        self._detail_feedback = None
        self._show_transcript = False
        self._show_feedback_detail = False
        self._render_interviews_table()
        self.query_one("#interviews-table", DataTable).display = True
        self.query_one("#interview-detail-scroll", VerticalScroll).display = False
        self._update_footer_bindings()

    def _show_detail_view(self, interview_id: str) -> None:
        self._view = "detail"
        self._show_transcript = False
        self._show_feedback_detail = False
        self.query_one("#interviews-table", DataTable).display = False
        self.query_one("#interview-detail-scroll", VerticalScroll).display = True
        self.query_one("#interview-detail", Static).update("[dim]Loading...[/dim]")
        self._update_footer_bindings()
        self._load_detail(interview_id)

    def _update_footer_bindings(self) -> None:
        """Push view-aware bindings to the footer."""
        from skilark_cli.tui.app import FooterBar

        try:
            footer = self.app.query_one(FooterBar)
        except Exception:
            return

        if self._view == "list":
            bindings = [
                Binding("n", "new_interview", "Book", show=True),
                Binding("r", "refresh", "Refresh", show=True),
                Binding("f", "view_feedback", "View Detail", show=True),
            ]
        else:
            bindings = [
                Binding("b", "back", "Back", show=True),
                Binding("c", "toggle_transcript", "Conversation", show=True),
                Binding("d", "toggle_detail_feedback", "Details", show=True),
            ]
        footer.set_context_bindings(bindings)

    # ------------------------------------------------------------------
    # Actions
    # ------------------------------------------------------------------

    def action_refresh(self) -> None:
        """Reload the interviews list."""
        if self._view != "list":
            return
        self.query_one("#interviews-header", Static).update(
            "[bold]Interviews[/bold]\n\n[dim]Loading...[/dim]"
        )
        self._load_interviews()

    def action_view_feedback(self) -> None:
        """Drill into detail/feedback for the selected row."""
        if self._view != "list":
            return
        table = self.query_one("#interviews-table", DataTable)
        if table.cursor_row is None or not self._interviews:
            return
        try:
            row_key = table.coordinate_to_cell_key(table.cursor_coordinate).row_key
            interview_id = str(row_key.value)
        except Exception:
            idx = table.cursor_row
            if not (0 <= idx < len(self._interviews)):
                return
            interview_id = self._interviews[idx]["id"]

        self._show_detail_view(interview_id)

    def action_new_interview(self) -> None:
        """Open the booking modal."""
        if self._view != "list":
            return
        from skilark_cli.tui.screens.interview_book_modal import InterviewBookModal

        def _on_dismiss(result: bool | None) -> None:
            if result:
                self._load_interviews()

        self.app.push_screen(InterviewBookModal(client=self.client), _on_dismiss)

    def action_back(self) -> None:
        """Return from detail view to the list."""
        if self._view == "detail":
            self._show_list_view()

    def action_toggle_transcript(self) -> None:
        """Toggle transcript visibility in detail view."""
        if self._view != "detail" or not self._detail_interview:
            return
        self._show_transcript = not self._show_transcript
        self._refresh_detail_content()

    def action_toggle_detail_feedback(self) -> None:
        """Toggle detailed feedback (strengths/improvements) in detail view."""
        if self._view != "detail" or not self._detail_interview:
            return
        self._show_feedback_detail = not self._show_feedback_detail
        self._refresh_detail_content()
