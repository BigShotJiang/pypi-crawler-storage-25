def main():
    print("Hello from cofinal!")


if __name__ == "__main__":
    main()
