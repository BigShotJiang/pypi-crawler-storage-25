"""aidiff - Track which lines in your codebase were written by AI."""

__version__ = "0.1.0"
