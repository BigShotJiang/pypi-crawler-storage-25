"""Natural Payments SDK client."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ValidationError

from naturalpay._http import HTTPClient
from naturalpay._logging import get_logger
from naturalpay.exceptions import InvalidRequestError
from naturalpay.models import (
    AccountBalance,
    Agent,
    AgentDelegation,
    AgentDelegationListResponse,
    AgentListResponse,
    CustomerListResponse,
    Transaction,
    TransactionListResponse,
    TransactionTypeFilter,
    WithdrawResponse,
)

logger = get_logger(__name__)

# Regex for phone numbers: 10+ consecutive digits (US without formatting)
_PHONE_DIGITS_RE = __import__("re").compile(r"^\d{10,}$")
_PHONE_PLUS_RE = __import__("re").compile(r"^\+\d{7,}$")


def _validate_recipient(recipient: str) -> None:
    """Validate recipient format matches backend expectations.

    Caller must strip the value before passing it here.

    Accepted formats:
        - Party ID: starts with "pty_"
        - Email: contains "@"
        - Phone: starts with "+" followed by 7+ digits, or 10+ bare digits

    Raises:
        InvalidRequestError: If recipient format is unrecognized.
    """
    if not recipient:
        raise InvalidRequestError("recipient cannot be empty")
    if recipient.startswith("pty_"):
        return
    if "@" in recipient:
        return
    if _PHONE_PLUS_RE.match(recipient):
        return
    if _PHONE_DIGITS_RE.match(recipient):
        return
    raise InvalidRequestError(
        "Invalid recipient format. "
        "Expected: party ID (pty_*), email (contains @), or phone (+ prefix or 10+ digits)"
    )


def _validate_response[T: BaseModel](
    model: type[T],
    data: dict[str, Any],
    *,
    method: str,
    endpoint: str,
    unwrap: bool = True,
) -> T:
    """Validate an API response against a Pydantic model.

    Args:
        model: The Pydantic model class to validate against.
        data: The raw response dict from the API.
        method: HTTP method (for logging context).
        endpoint: API endpoint path (for logging context).
        unwrap: If True, unwrap JSON:API ``{"data": {...}}`` envelope first.
    """
    if unwrap:
        inner = data.get("data")
        if inner is not None:
            if isinstance(inner, dict):
                data = inner
            else:
                logger.warning(
                    "Unexpected response envelope: 'data' is %s, expected dict",
                    type(inner).__name__,
                    extra={"method": method, "endpoint": endpoint},
                )
    try:
        return model.model_validate(data)
    except ValidationError:
        logger.error(
            "Response validation failed for %s %s",
            method,
            endpoint,
            extra={"method": method, "endpoint": endpoint, "model": model.__name__},
        )
        raise


class PaymentsResource:
    """Payments API resource."""

    def __init__(self, http: HTTPClient):
        self._http = http

    async def create(
        self,
        *,
        agent_id: str | None = None,
        amount: int,
        customer_party_id: str,
        recipient: str,
        memo: str,
        idempotency_key: str,
        currency: str = "USD",
        instance_id: str | None = None,
    ) -> Transaction:
        """Create a payment.

        Args:
            agent_id: Agent ID (agt_xxx) for agent-initiated payments
            amount: Payment amount in minor units (cents). 5000 = $50.00
            customer_party_id: Customer party ID (pty_xxx) of the party making the payment
            recipient: Recipient email, phone number, or party ID (pty_xxx)
            memo: Payment memo/description
            idempotency_key: Idempotency key to prevent duplicate payments
            currency: Currency code (default: USD)
            instance_id: Agent session/conversation ID for observability

        Returns:
            Transaction object with transaction_id (txn_*), status, etc.
        """
        if not isinstance(amount, int) or amount <= 0:
            raise InvalidRequestError("amount must be a positive integer (minor units in cents)")

        recipient = recipient.strip()
        _validate_recipient(recipient)

        # Build JSON:API envelope payload
        attributes: dict[str, Any] = {
            "amount": amount,
            "currency": currency,
            "counterparty": recipient,
            "customerPartyId": customer_party_id,
            "description": memo,
        }

        payload: dict[str, Any] = {"data": {"attributes": attributes}}

        headers: dict[str, str] = {
            "Idempotency-Key": idempotency_key,
        }
        if agent_id:
            if not instance_id:
                raise InvalidRequestError("instance_id is required when agent_id is provided")
            headers["X-Agent-ID"] = agent_id
        if instance_id:
            headers["X-Instance-ID"] = instance_id

        data = await self._http.post("/payments", json=payload, headers=headers)
        return _validate_response(Transaction, data, method="POST", endpoint="/payments")


class AccountResource:
    """Account API resource (legacy, use WalletResource for new code)."""

    def __init__(self, http: HTTPClient):
        self._http = http

    async def balance(
        self,
        *,
        instance_id: str | None = None,
    ) -> AccountBalance:
        """Get current account balance.

        Args:
            instance_id: Agent session/conversation ID for observability

        Returns:
            AccountBalance with available, current, pending amounts
        """
        headers: dict[str, str] = {}
        if instance_id:
            headers["X-Instance-ID"] = instance_id
        data = await self._http.get(
            "/wallet/balance",
            headers=headers if headers else None,
        )
        return _validate_response(AccountBalance, data, method="GET", endpoint="/wallet/balance")


class WalletResource:
    """Wallet API resource for balance, transfers, deposits, and withdrawals."""

    def __init__(self, http: HTTPClient):
        self._http = http

    async def balance(
        self,
        *,
        customer_party_id: str | None = None,
        instance_id: str | None = None,
    ) -> AccountBalance:
        """Get current wallet balance.

        Args:
            customer_party_id: Customer party ID (pty_xxx) when acting on behalf of customer
            instance_id: Agent session/conversation ID for observability

        Returns:
            AccountBalance with available, current, pending amounts
        """
        headers: dict[str, str] = {}
        if instance_id:
            headers["X-Instance-ID"] = instance_id
        params: dict[str, Any] = {}
        if customer_party_id:
            params["partyId"] = customer_party_id
        data = await self._http.get(
            "/wallet/balance",
            params=params if params else None,
            headers=headers if headers else None,
        )
        return _validate_response(AccountBalance, data, method="GET", endpoint="/wallet/balance")

    async def withdraw(
        self,
        *,
        amount: int,
        external_funding_source_id: str,
        currency: str = "USD",
        description: str | None = None,
        idempotency_key: str,
    ) -> WithdrawResponse:
        """Initiate a withdrawal to a linked bank account.

        Args:
            amount: Withdrawal amount in minor units (cents). 5000 = $50.00
            external_funding_source_id: ID of the linked bank account (efs_xxx)
            currency: Currency code (default: USD)
            description: Optional description for the withdrawal
            idempotency_key: Required idempotency key to prevent duplicates

        Returns:
            WithdrawResponse with transfer status (may require KYC/MFA)
        """
        if not isinstance(amount, int) or amount <= 0:
            raise InvalidRequestError("amount must be a positive integer (minor units in cents)")

        attributes: dict[str, Any] = {
            "amount": amount,
            "currency": currency,
            "externalFundingSourceId": external_funding_source_id,
        }
        if description:
            attributes["description"] = description

        payload: dict[str, Any] = {"data": {"attributes": attributes}}

        headers = {"Idempotency-Key": idempotency_key}

        data = await self._http.post(
            "/wallet/withdraw",
            json=payload,
            headers=headers,
        )
        return _validate_response(
            WithdrawResponse, data, method="POST", endpoint="/wallet/withdraw"
        )


class TransactionsResource:
    """Transactions API resource.

    For full functionality with partner API keys, pass agent_id and
    customer_party_id to provide agent context.
    """

    def __init__(self, http: HTTPClient):
        self._http = http

    async def get(
        self,
        transaction_id: str,
        *,
        customer_party_id: str | None = None,
        instance_id: str | None = None,
    ) -> Transaction:
        """Get a transaction by ID.

        Args:
            transaction_id: Transaction ID (txn_xxx)
            customer_party_id: Customer party ID (pty_xxx) for delegated transaction lookup
            instance_id: Agent session/conversation ID for observability

        Returns:
            Transaction details
        """
        headers: dict[str, str] = {}
        if instance_id:
            headers["X-Instance-ID"] = instance_id
        params: dict[str, Any] = {}
        if customer_party_id:
            params["partyId"] = customer_party_id
        data = await self._http.get(
            f"/transactions/{transaction_id}",
            params=params if params else None,
            headers=headers if headers else None,
        )
        return _validate_response(
            Transaction, data, method="GET", endpoint=f"/transactions/{transaction_id}"
        )

    async def list(
        self,
        *,
        limit: int = 50,
        cursor: str | None = None,
        agent_id: str | None = None,
        transaction_type: TransactionTypeFilter | None = None,
        instance_id: str | None = None,
    ) -> TransactionListResponse:
        """List recent transactions.

        Args:
            limit: Maximum number of transactions (default: 50, max: 100)
            cursor: Cursor for pagination (use next_cursor from previous response)
            agent_id: Agent ID for agent-context authentication
            transaction_type: Filter by transaction type (payment, transfer, or all)
            instance_id: Agent session/conversation ID for observability

        Returns:
            TransactionListResponse with list of transactions and pagination info
        """
        params: dict[str, Any] = {"limit": limit}
        if cursor:
            params["cursor"] = cursor
        if transaction_type:
            params["type"] = transaction_type.value

        headers: dict[str, str] = {}
        if agent_id:
            if not instance_id:
                raise InvalidRequestError("instance_id is required when agent_id is provided")
            headers["X-Agent-ID"] = agent_id
        if instance_id:
            headers["X-Instance-ID"] = instance_id

        data = await self._http.get(
            "/transactions",
            params=params,
            headers=headers if headers else None,
        )
        return _validate_response(
            TransactionListResponse, data, method="GET", endpoint="/transactions", unwrap=False
        )


class AgentsResource:
    """Agents API resource for managing agents.

    Agents are software systems that can act on behalf of partners.
    """

    def __init__(self, http: HTTPClient):
        self._http = http

    async def list(
        self,
        *,
        status: str | None = None,
        limit: int = 50,
        cursor: str | None = None,
        instance_id: str | None = None,
    ) -> AgentListResponse:
        """List agents for the partner.

        Args:
            status: Filter by status (ACTIVE, REVOKED)
            limit: Maximum number of agents (default: 50, max: 100)
            cursor: Cursor for pagination (use next_cursor from previous response)
            instance_id: Agent session/conversation ID for observability

        Returns:
            AgentListResponse with list of agents and pagination info
        """
        params: dict[str, Any] = {"limit": limit}
        if status:
            params["status"] = status
        if cursor:
            params["cursor"] = cursor

        headers: dict[str, str] = {}
        if instance_id:
            headers["X-Instance-ID"] = instance_id

        data = await self._http.get("/agents", params=params, headers=headers if headers else None)
        return _validate_response(
            AgentListResponse, data, method="GET", endpoint="/agents", unwrap=False
        )

    async def get(
        self,
        agent_id: str,
        *,
        instance_id: str | None = None,
    ) -> Agent:
        """Get agent by ID.

        Args:
            agent_id: The agent ID to retrieve (agt_xxx)
            instance_id: Agent session/conversation ID for observability

        Returns:
            Agent details
        """
        headers: dict[str, str] = {}
        if instance_id:
            headers["X-Instance-ID"] = instance_id
        data = await self._http.get(
            f"/agents/{agent_id}",
            headers=headers if headers else None,
        )
        return _validate_response(Agent, data, method="GET", endpoint=f"/agents/{agent_id}")

    async def create(
        self,
        *,
        name: str,
        description: str | None = None,
        limits: dict[str, Any] | None = None,
        idempotency_key: str | None = None,
        instance_id: str | None = None,
    ) -> Agent:
        """Create a new agent.

        Party is derived from the authenticated user's context.

        Args:
            name: Human-readable name for the agent
            description: Optional description of the agent's purpose
            limits: Optional transaction limits (e.g. {"per_transaction": 100000})
            idempotency_key: Idempotency key to prevent duplicates
            instance_id: Agent session/conversation ID for observability

        Returns:
            Agent with created agent details
        """
        attributes: dict[str, Any] = {"name": name}
        if description:
            attributes["description"] = description
        if limits:
            attributes["limits"] = limits

        payload: dict[str, Any] = {"data": {"attributes": attributes}}

        headers: dict[str, str] = {}
        if idempotency_key:
            headers["Idempotency-Key"] = idempotency_key
        if instance_id:
            headers["X-Instance-ID"] = instance_id

        data = await self._http.post(
            "/agents",
            json=payload,
            headers=headers if headers else None,
        )
        return _validate_response(Agent, data, method="POST", endpoint="/agents")

    async def update(
        self,
        agent_id: str,
        *,
        name: str | None = None,
        description: str | None = None,
        status: str | None = None,
        idempotency_key: str | None = None,
        instance_id: str | None = None,
    ) -> Agent:
        """Update an existing agent.

        Args:
            agent_id: The agent ID to update (agt_xxx)
            name: Updated name for the agent
            description: Updated description
            status: Updated status (ACTIVE, REVOKED)
            idempotency_key: Idempotency key to prevent duplicates
            instance_id: Agent session/conversation ID for observability

        Returns:
            Agent with updated agent details
        """
        attributes: dict[str, Any] = {}
        if name is not None:
            attributes["name"] = name
        if description is not None:
            attributes["description"] = description
        if status is not None:
            attributes["status"] = status

        payload: dict[str, Any] = {"data": {"attributes": attributes}}

        headers: dict[str, str] = {}
        if idempotency_key:
            headers["Idempotency-Key"] = idempotency_key
        if instance_id:
            headers["X-Instance-ID"] = instance_id

        data = await self._http.put(
            f"/agents/{agent_id}",
            json=payload,
            headers=headers if headers else None,
        )
        return _validate_response(Agent, data, method="PUT", endpoint=f"/agents/{agent_id}")

    async def delete(
        self,
        agent_id: str,
        *,
        instance_id: str | None = None,
    ) -> None:
        """Delete an agent.

        Args:
            agent_id: The agent ID to delete (agt_xxx)
            instance_id: Agent session/conversation ID for observability
        """
        headers: dict[str, str] = {}
        if instance_id:
            headers["X-Instance-ID"] = instance_id
        await self._http.delete(
            f"/agents/{agent_id}",
            headers=headers if headers else None,
        )


class DelegationsResource:
    """Agent delegations API resource.

    Agent delegations represent trust relationships where a customer grants
    a partner's agent access to act on their behalf.
    """

    def __init__(self, http: HTTPClient):
        self._http = http

    async def list(
        self,
        *,
        delegation_id: str | None = None,
        agent_id: str | None = None,
        delegator_party_id: str | None = None,
        delegatee_party_id: str | None = None,
        include_revoked: bool = False,
        limit: int = 50,
        cursor: str | None = None,
        instance_id: str | None = None,
    ) -> AgentDelegationListResponse:
        """List agent delegations with optional filters.

        Args:
            delegation_id: Filter by parent delegation (dlg_xxx)
            agent_id: Filter by agent (agt_xxx)
            delegator_party_id: Filter by customer party granting access
            delegatee_party_id: Filter by partner party receiving access
            include_revoked: Include revoked delegations (default: False)
            limit: Maximum number of delegations (default: 50, max: 100)
            cursor: Cursor for pagination (use next_cursor from previous response)
            instance_id: Agent session/conversation ID for observability

        Returns:
            AgentDelegationListResponse with list of agent delegations and pagination info
        """
        params: dict[str, Any] = {"limit": limit}
        if delegation_id:
            params["delegationId"] = delegation_id
        if agent_id:
            params["agentId"] = agent_id
        if delegator_party_id:
            params["delegatorPartyId"] = delegator_party_id
        if delegatee_party_id:
            params["delegateePartyId"] = delegatee_party_id
        if include_revoked:
            params["includeRevoked"] = True
        if cursor:
            params["cursor"] = cursor

        headers: dict[str, str] = {}
        if instance_id:
            headers["X-Instance-ID"] = instance_id

        data = await self._http.get(
            "/agent-delegations", params=params, headers=headers if headers else None
        )
        return _validate_response(
            AgentDelegationListResponse,
            data,
            method="GET",
            endpoint="/agent-delegations",
            unwrap=False,
        )

    async def get(self, agent_delegation_id: str) -> AgentDelegation:
        """Get agent delegation by ID.

        Args:
            agent_delegation_id: The agent delegation handle (adl_xxx)

        Returns:
            AgentDelegation details
        """
        data = await self._http.get(f"/agent-delegations/{agent_delegation_id}")
        return _validate_response(
            AgentDelegation,
            data,
            method="GET",
            endpoint=f"/agent-delegations/{agent_delegation_id}",
        )


class CustomersResource:
    """Customers API resource for listing parties who delegated access.

    Returns parties that have delegated access to the caller, including
    both active delegations and pending invitations.
    """

    def __init__(self, http: HTTPClient):
        self._http = http

    async def list(
        self,
        *,
        limit: int = 50,
        cursor: str | None = None,
        instance_id: str | None = None,
    ) -> CustomerListResponse:
        """List customers who have delegated access to the partner.

        Args:
            limit: Maximum number of customers (default: 50, max: 100)
            cursor: Cursor for pagination (use next_cursor from previous response)
            instance_id: Agent session/conversation ID for observability

        Returns:
            CustomerListResponse with list of customers and pagination info
        """
        params: dict[str, Any] = {"limit": limit}
        if cursor:
            params["cursor"] = cursor

        headers: dict[str, str] = {}
        if instance_id:
            headers["X-Instance-ID"] = instance_id

        data = await self._http.get(
            "/customers",
            params=params,
            headers=headers if headers else None,
        )
        return _validate_response(
            CustomerListResponse,
            data,
            method="GET",
            endpoint="/customers",
            unwrap=False,
        )


class NaturalClient:
    """Natural Payments SDK client.

    Example:
        ```python
        from naturalpay import NaturalClient

        client = NaturalClient(api_key="sk_ntl_sandbox_xxx")

        # Create a payment
        payment = await client.payments.create(
            agent_id="agt_xxx",
            amount=5000,
            customer_party_id="pty_xxx",
            recipient="alice@example.com",
            memo="For consulting",
            idempotency_key="unique-key-for-this-payment",
        )

        # Check balance
        balance = await client.account.balance()
        ```
    """

    def __init__(
        self,
        api_key: str | None = None,
        *,
        base_url: str | None = None,
        timeout: float = 30.0,
    ):
        """Initialize the Natural client.

        Args:
            api_key: API key (defaults to NATURAL_API_KEY env var)
            base_url: API base URL (defaults to NATURAL_SERVER_URL env var)
            timeout: Request timeout in seconds (default: 30)
        """
        self._http = HTTPClient(api_key=api_key, base_url=base_url, timeout=timeout)

        self.payments = PaymentsResource(self._http)
        self.account = AccountResource(self._http)
        self.wallet = WalletResource(self._http)
        self.transactions = TransactionsResource(self._http)
        self.agents = AgentsResource(self._http)
        self.delegations = DelegationsResource(self._http)
        self.customers = CustomersResource(self._http)

    async def close(self) -> None:
        """Close the client and release resources."""
        await self._http.close()

    async def __aenter__(self) -> NaturalClient:
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()
