"""HTTP client wrapper for Natural Server API."""

from __future__ import annotations

import hashlib
import os
import time
from typing import Any

import httpx

from naturalpay._logging import get_logger, log_api_call, log_error
from naturalpay._tool_call_context import get_tool_call_header
from naturalpay._version import __version__
from naturalpay.exceptions import (
    AuthenticationError,
    InvalidRequestError,
    NaturalError,
    RateLimitError,
    ServerError,
)

logger = get_logger(__name__)

DEFAULT_BASE_URL = "https://api.natural.co"

# Legacy API prefix - kept for reference but no longer used
# Routes are now at the root (e.g., /wallet/balance, /payments/initiate)
DEFAULT_TIMEOUT = 30.0


class HTTPClient:
    """Async HTTP client for Natural Server API.

    Handles API key → JWT exchange and caching.
    """

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: float = DEFAULT_TIMEOUT,
    ):
        self.api_key = api_key or os.getenv("NATURAL_API_KEY")
        self.base_url = (base_url or os.getenv("NATURAL_SERVER_URL") or DEFAULT_BASE_URL).rstrip(
            "/"
        )
        self.timeout = timeout

        self._client: httpx.AsyncClient | None = None

        # JWT cache: {hashed_api_key: (jwt_token, expiry_timestamp)}
        self._jwt_cache: dict[str, tuple[str, float]] = {}

    def _get_client(self) -> httpx.AsyncClient:
        if self._client is None:
            self._client = httpx.AsyncClient(
                base_url=self.base_url,
                timeout=self.timeout,
                headers={
                    "User-Agent": f"naturalpay-python/{__version__}",
                },
            )
        return self._client

    async def close(self) -> None:
        """Close the HTTP client."""
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    async def __aenter__(self) -> HTTPClient:
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()

    def _cache_key(self, api_key: str) -> str:
        """Generate hashed cache key from API key."""
        return hashlib.sha256(api_key.encode()).hexdigest()[:16]

    def _evict_expired_cache_entries(self) -> None:
        """Remove expired JWT entries."""
        current_time = time.time()
        expired_keys = [k for k, (_, expiry) in self._jwt_cache.items() if current_time >= expiry]
        for key in expired_keys:
            del self._jwt_cache[key]

    async def _get_jwt(self, api_key: str) -> str:
        """Exchange API key for JWT token, with caching.

        If the token is already a JWT (not a sk_ntl_* API key), returns it directly.
        """
        # If already a JWT (not a sk_ntl_* key), use it directly
        if not api_key.startswith("sk_ntl_"):
            return api_key

        # Evict expired entries
        self._evict_expired_cache_entries()

        # Check cache
        cache_key = self._cache_key(api_key)
        if cache_key in self._jwt_cache:
            jwt, expiry = self._jwt_cache[cache_key]
            if time.time() < expiry:
                return jwt
            del self._jwt_cache[cache_key]

        # Exchange API key for JWT
        client = self._get_client()
        try:
            response = await client.post(
                "/auth/api/token",
                headers={"Authorization": f"Bearer {api_key}"},
            )
            response.raise_for_status()
            data = response.json()

            jwt = data["accessToken"]
            expires_in = data.get("expiresIn", 900)  # Default 15 minutes

            # Cache JWT (expire 30 seconds early for safety)
            expiry = time.time() + expires_in - 30
            self._jwt_cache[cache_key] = (jwt, expiry)

            return jwt

        except httpx.HTTPStatusError as e:
            auth_error = AuthenticationError(
                f"Authentication failed (status={e.response.status_code})"
            )
            log_error(
                logger,
                "JWT exchange failed",
                error=auth_error,
                status_code=e.response.status_code,
                path="/auth/api/token",
            )
            raise auth_error from e
        except httpx.RequestError as e:
            network_error = NaturalError(f"Network error during authentication: {e}")
            log_error(
                logger,
                "JWT exchange network error",
                error=network_error,
                path="/auth/api/token",
            )
            raise network_error from e

    async def _auth_headers(self) -> dict[str, str]:
        """Get authorization headers with JWT."""
        if not self.api_key:
            raise AuthenticationError()
        jwt = await self._get_jwt(self.api_key)
        return {"Authorization": f"Bearer {jwt}"}

    async def request(
        self,
        method: str,
        path: str,
        *,
        json: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Make an authenticated request to the Natural Server API."""
        client = self._get_client()

        request_headers = await self._auth_headers()
        tool_call_header = get_tool_call_header()
        if tool_call_header:
            request_headers["X-Tool-Call"] = tool_call_header
        if headers:
            request_headers.update(headers)

        logger.debug(
            f"API request: {method} {path}",
            extra={"method": method, "path": path, "has_body": json is not None},
        )

        start_time = time.time()
        try:
            response = await client.request(
                method,
                path,
                json=json,
                params=params,
                headers=request_headers,
            )
            duration_ms = (time.time() - start_time) * 1000
            result = self._handle_response(response, method, path, duration_ms)
            return result
        except httpx.RequestError as e:
            duration_ms = (time.time() - start_time) * 1000
            network_error = NaturalError(f"Network error: {e}")
            log_api_call(logger, method, path, duration_ms=duration_ms, error=network_error)
            raise network_error from e

    def _handle_response(
        self,
        response: httpx.Response,
        method: str = "?",
        path: str = "?",
        duration_ms: float | None = None,
    ) -> dict[str, Any]:
        """Handle API response and raise appropriate exceptions."""
        status_code = response.status_code

        if status_code == 401:
            auth_error = AuthenticationError()
            log_api_call(
                logger,
                method,
                path,
                status_code=status_code,
                duration_ms=duration_ms,
                error=auth_error,
            )
            raise auth_error

        if status_code == 429:
            retry_after = response.headers.get("Retry-After")
            rate_error = RateLimitError(retry_after=int(retry_after) if retry_after else None)
            logger.warning(
                f"Rate limited: {method} {path}",
                extra={
                    "method": method,
                    "path": path,
                    "status_code": status_code,
                    "retry_after": retry_after,
                    "duration_ms": round(duration_ms, 2) if duration_ms else None,
                },
            )
            raise rate_error

        if status_code >= 500:
            server_error = ServerError(f"Server error: {status_code}")
            log_api_call(
                logger,
                method,
                path,
                status_code=status_code,
                duration_ms=duration_ms,
                error=server_error,
            )
            raise server_error

        try:
            data = response.json()
        except Exception as e:
            if status_code >= 400:
                parse_error = NaturalError(
                    f"Request failed: {status_code}",
                    status_code=status_code,
                )
                log_api_call(
                    logger,
                    method,
                    path,
                    status_code=status_code,
                    duration_ms=duration_ms,
                    error=parse_error,
                )
                raise parse_error from e
            # Success but no JSON body
            log_api_call(logger, method, path, status_code=status_code, duration_ms=duration_ms)
            return {}

        if status_code >= 400:
            errors = data.get("errors", [])
            error_message = errors[0]["detail"] if errors else "Request failed"
            error_code = errors[0]["code"] if errors else "unknown_error"
            request_error = InvalidRequestError(
                f"{error_message} (status={status_code})", code=error_code
            )
            log_api_call(
                logger,
                method,
                path,
                status_code=status_code,
                duration_ms=duration_ms,
                error=request_error,
            )
            raise request_error

        # Success
        log_api_call(logger, method, path, status_code=status_code, duration_ms=duration_ms)
        return data

    async def get(
        self,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return await self.request("GET", path, params=params, headers=headers)

    async def post(
        self,
        path: str,
        *,
        json: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return await self.request("POST", path, json=json, headers=headers)

    async def put(
        self,
        path: str,
        *,
        json: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return await self.request("PUT", path, json=json, headers=headers)

    async def delete(
        self,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return await self.request("DELETE", path, params=params, headers=headers)
