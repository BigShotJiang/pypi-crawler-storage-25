"""Synchronous Natural Payments SDK client."""

from __future__ import annotations

import hashlib
import os
import time
from typing import Any

import httpx
from pydantic import BaseModel, ValidationError

from naturalpay._logging import get_logger, log_api_call, log_error
from naturalpay._tool_call_context import get_tool_call_header
from naturalpay._version import __version__
from naturalpay.client import _validate_recipient
from naturalpay.exceptions import (
    AuthenticationError,
    InvalidRequestError,
    NaturalError,
    RateLimitError,
    ServerError,
)
from naturalpay.models import (
    AccountBalance,
    Agent,
    AgentDelegation,
    AgentDelegationListResponse,
    AgentListResponse,
    CustomerListResponse,
    Transaction,
    TransactionListResponse,
    TransactionTypeFilter,
    WithdrawResponse,
)

logger = get_logger(__name__)

DEFAULT_BASE_URL = "https://api.natural.co"
DEFAULT_TIMEOUT = 30.0


def _validate_response[T: BaseModel](
    model: type[T],
    data: dict[str, Any],
    *,
    method: str,
    endpoint: str,
    unwrap: bool = True,
) -> T:
    """Validate an API response against a Pydantic model.

    Args:
        model: The Pydantic model class to validate against.
        data: The raw response dict from the API.
        method: HTTP method (for logging context).
        endpoint: API endpoint path (for logging context).
        unwrap: If True, unwrap JSON:API ``{"data": {...}}`` envelope first.
    """
    if unwrap:
        inner = data.get("data")
        if inner is not None:
            if isinstance(inner, dict):
                data = inner
            else:
                logger.warning(
                    "Unexpected response envelope: 'data' is %s, expected dict",
                    type(inner).__name__,
                    extra={"method": method, "endpoint": endpoint},
                )
    try:
        return model.model_validate(data)
    except ValidationError:
        logger.error(
            "Response validation failed for %s %s",
            method,
            endpoint,
            extra={"method": method, "endpoint": endpoint, "model": model.__name__},
        )
        raise


class SyncHTTPClient:
    """Synchronous HTTP client for Natural Server API."""

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: float = DEFAULT_TIMEOUT,
    ):
        self.api_key = api_key or os.getenv("NATURAL_API_KEY")
        self.base_url = (base_url or os.getenv("NATURAL_SERVER_URL") or DEFAULT_BASE_URL).rstrip(
            "/"
        )
        self.timeout = timeout

        self._client: httpx.Client | None = None
        self._jwt_cache: dict[str, tuple[str, float]] = {}

    def _get_client(self) -> httpx.Client:
        if self._client is None:
            self._client = httpx.Client(
                base_url=self.base_url,
                timeout=self.timeout,
                headers={"User-Agent": f"naturalpay-python/{__version__}"},
            )
        return self._client

    def close(self) -> None:
        """Close the HTTP client."""
        if self._client is not None:
            self._client.close()
            self._client = None

    def __enter__(self) -> SyncHTTPClient:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    def _cache_key(self, api_key: str) -> str:
        return hashlib.sha256(api_key.encode()).hexdigest()[:16]

    def _evict_expired_cache_entries(self) -> None:
        current_time = time.time()
        expired_keys = [k for k, (_, expiry) in self._jwt_cache.items() if current_time >= expiry]
        for key in expired_keys:
            del self._jwt_cache[key]

    def _get_jwt(self, api_key: str) -> str:
        """Exchange API key for JWT token, with caching."""
        if not api_key.startswith("sk_ntl_"):
            return api_key

        self._evict_expired_cache_entries()

        cache_key = self._cache_key(api_key)
        if cache_key in self._jwt_cache:
            jwt, expiry = self._jwt_cache[cache_key]
            if time.time() < expiry:
                return jwt
            del self._jwt_cache[cache_key]

        client = self._get_client()
        try:
            response = client.post(
                "/auth/api/token",
                headers={"Authorization": f"Bearer {api_key}"},
            )
            response.raise_for_status()
            data = response.json()

            jwt = data["accessToken"]
            expires_in = data.get("expiresIn", 900)
            expiry = time.time() + expires_in - 30
            self._jwt_cache[cache_key] = (jwt, expiry)

            return jwt

        except httpx.HTTPStatusError as e:
            auth_error = AuthenticationError(
                f"Authentication failed (status={e.response.status_code})"
            )
            log_error(
                logger,
                "JWT exchange failed",
                error=auth_error,
                status_code=e.response.status_code,
                path="/auth/api/token",
            )
            raise auth_error from e
        except httpx.RequestError as e:
            network_error = NaturalError(f"Network error during authentication: {e}")
            log_error(
                logger,
                "JWT exchange network error",
                error=network_error,
                path="/auth/api/token",
            )
            raise network_error from e

    def _auth_headers(self) -> dict[str, str]:
        if not self.api_key:
            raise AuthenticationError()
        jwt = self._get_jwt(self.api_key)
        return {"Authorization": f"Bearer {jwt}"}

    def request(
        self,
        method: str,
        path: str,
        *,
        json: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        client = self._get_client()

        request_headers = self._auth_headers()
        tool_call_header = get_tool_call_header()
        if tool_call_header:
            request_headers["X-Tool-Call"] = tool_call_header
        if headers:
            request_headers.update(headers)

        logger.debug(
            f"API request: {method} {path}",
            extra={"method": method, "path": path, "has_body": json is not None},
        )

        start_time = time.time()
        try:
            response = client.request(
                method,
                path,
                json=json,
                params=params,
                headers=request_headers,
            )
            duration_ms = (time.time() - start_time) * 1000
            return self._handle_response(response, method, path, duration_ms)
        except httpx.RequestError as e:
            duration_ms = (time.time() - start_time) * 1000
            network_error = NaturalError(f"Network error: {e}")
            log_api_call(logger, method, path, duration_ms=duration_ms, error=network_error)
            raise network_error from e

    def _handle_response(
        self,
        response: httpx.Response,
        method: str = "?",
        path: str = "?",
        duration_ms: float | None = None,
    ) -> dict[str, Any]:
        status_code = response.status_code

        if status_code == 401:
            auth_error = AuthenticationError()
            log_api_call(
                logger,
                method,
                path,
                status_code=status_code,
                duration_ms=duration_ms,
                error=auth_error,
            )
            raise auth_error

        if status_code == 429:
            retry_after = response.headers.get("Retry-After")
            rate_error = RateLimitError(retry_after=int(retry_after) if retry_after else None)
            logger.warning(
                f"Rate limited: {method} {path}",
                extra={
                    "method": method,
                    "path": path,
                    "status_code": status_code,
                    "retry_after": retry_after,
                    "duration_ms": round(duration_ms, 2) if duration_ms else None,
                },
            )
            raise rate_error

        if status_code >= 500:
            server_error = ServerError(f"Server error: {status_code}")
            log_api_call(
                logger,
                method,
                path,
                status_code=status_code,
                duration_ms=duration_ms,
                error=server_error,
            )
            raise server_error

        try:
            data = response.json()
        except Exception as e:
            if status_code >= 400:
                parse_error = NaturalError(
                    f"Request failed: {status_code}",
                    status_code=status_code,
                )
                log_api_call(
                    logger,
                    method,
                    path,
                    status_code=status_code,
                    duration_ms=duration_ms,
                    error=parse_error,
                )
                raise parse_error from e
            # Success but no JSON body
            log_api_call(logger, method, path, status_code=status_code, duration_ms=duration_ms)
            return {}

        if status_code >= 400:
            errors = data.get("errors", [])
            error_message = errors[0]["detail"] if errors else "Request failed"
            error_code = errors[0]["code"] if errors else "unknown_error"
            request_error = InvalidRequestError(
                f"{error_message} (status={status_code})", code=error_code
            )
            log_api_call(
                logger,
                method,
                path,
                status_code=status_code,
                duration_ms=duration_ms,
                error=request_error,
            )
            raise request_error

        # Success
        log_api_call(logger, method, path, status_code=status_code, duration_ms=duration_ms)
        return data

    def get(
        self,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return self.request("GET", path, params=params, headers=headers)

    def post(
        self,
        path: str,
        *,
        json: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return self.request("POST", path, json=json, headers=headers)

    def put(
        self,
        path: str,
        *,
        json: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return self.request("PUT", path, json=json, headers=headers)

    def delete(
        self,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return self.request("DELETE", path, params=params, headers=headers)


# --- Sync Resource Classes ---


class SyncPaymentsResource:
    """Synchronous Payments API resource."""

    def __init__(self, http: SyncHTTPClient):
        self._http = http

    def create(
        self,
        *,
        agent_id: str | None = None,
        amount: int,
        customer_party_id: str,
        recipient: str,
        memo: str,
        idempotency_key: str,
        currency: str = "USD",
        instance_id: str | None = None,
    ) -> Transaction:
        """Create a payment (synchronous).

        Args:
            agent_id: Agent ID (agt_xxx) for agent-initiated payments
            amount: Payment amount in minor units (cents). 5000 = $50.00
            customer_party_id: Customer party ID (pty_xxx) of the party making the payment
            recipient: Recipient email, phone number, or party ID (pty_xxx)
            memo: Payment memo/description
            idempotency_key: Idempotency key to prevent duplicate payments
            currency: Currency code (default: USD)
            instance_id: Agent session/conversation ID for observability

        Returns:
            Transaction object with transaction_id (txn_*), status, etc.
        """
        if not isinstance(amount, int) or amount <= 0:
            raise InvalidRequestError("amount must be a positive integer (minor units in cents)")

        recipient = recipient.strip()
        _validate_recipient(recipient)

        # Build JSON:API envelope payload
        attributes: dict[str, Any] = {
            "amount": amount,
            "currency": currency,
            "counterparty": recipient,
            "customerPartyId": customer_party_id,
            "description": memo,
        }

        payload: dict[str, Any] = {"data": {"attributes": attributes}}

        headers: dict[str, str] = {
            "Idempotency-Key": idempotency_key,
        }
        if agent_id:
            if not instance_id:
                raise InvalidRequestError("instance_id is required when agent_id is provided")
            headers["X-Agent-ID"] = agent_id
        if instance_id:
            headers["X-Instance-ID"] = instance_id

        data = self._http.post("/payments", json=payload, headers=headers)
        return _validate_response(Transaction, data, method="POST", endpoint="/payments")


class SyncAccountResource:
    """Synchronous Account API resource (legacy, use SyncWalletResource for new code)."""

    def __init__(self, http: SyncHTTPClient):
        self._http = http

    def balance(
        self,
        *,
        instance_id: str | None = None,
    ) -> AccountBalance:
        """Get current account balance (synchronous).

        Args:
            instance_id: Agent session/conversation ID for observability

        Returns:
            AccountBalance with available, current, pending amounts
        """
        headers: dict[str, str] = {}
        if instance_id:
            headers["X-Instance-ID"] = instance_id
        data = self._http.get(
            "/wallet/balance",
            headers=headers if headers else None,
        )
        return _validate_response(AccountBalance, data, method="GET", endpoint="/wallet/balance")


class SyncWalletResource:
    """Synchronous Wallet API resource."""

    def __init__(self, http: SyncHTTPClient):
        self._http = http

    def balance(
        self,
        *,
        customer_party_id: str | None = None,
        instance_id: str | None = None,
    ) -> AccountBalance:
        """Get current wallet balance (synchronous).

        Args:
            customer_party_id: Customer party ID (pty_xxx) when acting on behalf of customer
            instance_id: Agent session/conversation ID for observability

        Returns:
            AccountBalance with available, current, pending amounts
        """
        headers: dict[str, str] = {}
        if instance_id:
            headers["X-Instance-ID"] = instance_id
        params: dict[str, Any] = {}
        if customer_party_id:
            params["partyId"] = customer_party_id
        data = self._http.get(
            "/wallet/balance",
            params=params if params else None,
            headers=headers if headers else None,
        )
        return _validate_response(AccountBalance, data, method="GET", endpoint="/wallet/balance")

    def withdraw(
        self,
        *,
        amount: int,
        external_funding_source_id: str,
        currency: str = "USD",
        description: str | None = None,
        idempotency_key: str,
    ) -> WithdrawResponse:
        """Initiate a withdrawal to a linked bank account (synchronous).

        Args:
            amount: Withdrawal amount in minor units (cents). 5000 = $50.00
            external_funding_source_id: ID of the linked bank account (efs_xxx)
            currency: Currency code (default: USD)
            description: Optional description for the withdrawal
            idempotency_key: Required idempotency key to prevent duplicates

        Returns:
            WithdrawResponse with transfer status (may require KYC/MFA)
        """
        if not isinstance(amount, int) or amount <= 0:
            raise InvalidRequestError("amount must be a positive integer (minor units in cents)")

        attributes: dict[str, Any] = {
            "amount": amount,
            "currency": currency,
            "externalFundingSourceId": external_funding_source_id,
        }
        if description:
            attributes["description"] = description

        payload: dict[str, Any] = {"data": {"attributes": attributes}}

        headers = {"Idempotency-Key": idempotency_key}

        data = self._http.post(
            "/wallet/withdraw",
            json=payload,
            headers=headers,
        )
        return _validate_response(
            WithdrawResponse, data, method="POST", endpoint="/wallet/withdraw"
        )


class SyncTransactionsResource:
    """Synchronous Transactions API resource."""

    def __init__(self, http: SyncHTTPClient):
        self._http = http

    def get(
        self,
        transaction_id: str,
        *,
        customer_party_id: str | None = None,
        instance_id: str | None = None,
    ) -> Transaction:
        """Get a transaction by ID (synchronous).

        Args:
            transaction_id: Transaction ID (txn_xxx)
            customer_party_id: Customer party ID (pty_xxx) for delegated transaction lookup
            instance_id: Agent session/conversation ID for observability

        Returns:
            Transaction details
        """
        headers: dict[str, str] = {}
        if instance_id:
            headers["X-Instance-ID"] = instance_id
        params: dict[str, Any] = {}
        if customer_party_id:
            params["partyId"] = customer_party_id
        data = self._http.get(
            f"/transactions/{transaction_id}",
            params=params if params else None,
            headers=headers if headers else None,
        )
        return _validate_response(
            Transaction, data, method="GET", endpoint=f"/transactions/{transaction_id}"
        )

    def list(
        self,
        *,
        limit: int = 50,
        cursor: str | None = None,
        agent_id: str | None = None,
        transaction_type: TransactionTypeFilter | None = None,
        instance_id: str | None = None,
    ) -> TransactionListResponse:
        """List recent transactions (synchronous).

        Args:
            limit: Maximum number of transactions (default: 50, max: 100)
            cursor: Cursor for pagination (use next_cursor from previous response)
            agent_id: Agent ID for agent-context authentication
            transaction_type: Filter by transaction type (payment, transfer, or all)
            instance_id: Agent session/conversation ID for observability

        Returns:
            TransactionListResponse with list of transactions and pagination info
        """
        params: dict[str, Any] = {"limit": limit}
        if cursor:
            params["cursor"] = cursor
        if transaction_type:
            params["type"] = transaction_type.value

        headers: dict[str, str] = {}
        if agent_id:
            if not instance_id:
                raise InvalidRequestError("instance_id is required when agent_id is provided")
            headers["X-Agent-ID"] = agent_id
        if instance_id:
            headers["X-Instance-ID"] = instance_id

        data = self._http.get(
            "/transactions",
            params=params,
            headers=headers if headers else None,
        )
        return _validate_response(
            TransactionListResponse, data, method="GET", endpoint="/transactions", unwrap=False
        )


class SyncAgentsResource:
    """Synchronous Agents API resource."""

    def __init__(self, http: SyncHTTPClient):
        self._http = http

    def list(
        self,
        *,
        status: str | None = None,
        limit: int = 50,
        cursor: str | None = None,
        instance_id: str | None = None,
    ) -> AgentListResponse:
        """List agents for the partner (synchronous).

        Args:
            status: Filter by status (ACTIVE, REVOKED)
            limit: Maximum number of agents (default: 50, max: 100)
            cursor: Cursor for pagination (use next_cursor from previous response)
            instance_id: Agent session/conversation ID for observability

        Returns:
            AgentListResponse with list of agents and pagination info
        """
        params: dict[str, Any] = {"limit": limit}
        if status:
            params["status"] = status
        if cursor:
            params["cursor"] = cursor

        headers: dict[str, str] = {}
        if instance_id:
            headers["X-Instance-ID"] = instance_id

        data = self._http.get("/agents", params=params, headers=headers if headers else None)
        return _validate_response(
            AgentListResponse, data, method="GET", endpoint="/agents", unwrap=False
        )

    def get(
        self,
        agent_id: str,
        *,
        instance_id: str | None = None,
    ) -> Agent:
        """Get agent by ID (synchronous).

        Args:
            agent_id: The agent ID to retrieve (agt_xxx)
            instance_id: Agent session/conversation ID for observability

        Returns:
            Agent details
        """
        headers: dict[str, str] = {}
        if instance_id:
            headers["X-Instance-ID"] = instance_id
        data = self._http.get(
            f"/agents/{agent_id}",
            headers=headers if headers else None,
        )
        return _validate_response(Agent, data, method="GET", endpoint=f"/agents/{agent_id}")

    def create(
        self,
        *,
        name: str,
        description: str | None = None,
        limits: dict[str, Any] | None = None,
        idempotency_key: str | None = None,
        instance_id: str | None = None,
    ) -> Agent:
        """Create a new agent (synchronous).

        Party is derived from the authenticated user's context.

        Args:
            name: Human-readable name for the agent
            description: Optional description of the agent's purpose
            limits: Optional transaction limits (e.g. {"per_transaction": 100000})
            idempotency_key: Idempotency key to prevent duplicates
            instance_id: Agent session/conversation ID for observability

        Returns:
            Agent with created agent details
        """
        attributes: dict[str, Any] = {"name": name}
        if description:
            attributes["description"] = description
        if limits:
            attributes["limits"] = limits

        payload: dict[str, Any] = {"data": {"attributes": attributes}}

        headers: dict[str, str] = {}
        if idempotency_key:
            headers["Idempotency-Key"] = idempotency_key
        if instance_id:
            headers["X-Instance-ID"] = instance_id

        data = self._http.post(
            "/agents",
            json=payload,
            headers=headers if headers else None,
        )
        return _validate_response(Agent, data, method="POST", endpoint="/agents")

    def update(
        self,
        agent_id: str,
        *,
        name: str | None = None,
        description: str | None = None,
        status: str | None = None,
        idempotency_key: str | None = None,
        instance_id: str | None = None,
    ) -> Agent:
        """Update an existing agent (synchronous).

        Args:
            agent_id: The agent ID to update (agt_xxx)
            name: Updated name for the agent
            description: Updated description
            status: Updated status (ACTIVE, REVOKED)
            idempotency_key: Idempotency key to prevent duplicates
            instance_id: Agent session/conversation ID for observability

        Returns:
            Agent with updated agent details
        """
        attributes: dict[str, Any] = {}
        if name is not None:
            attributes["name"] = name
        if description is not None:
            attributes["description"] = description
        if status is not None:
            attributes["status"] = status

        payload: dict[str, Any] = {"data": {"attributes": attributes}}

        headers: dict[str, str] = {}
        if idempotency_key:
            headers["Idempotency-Key"] = idempotency_key
        if instance_id:
            headers["X-Instance-ID"] = instance_id

        data = self._http.put(
            f"/agents/{agent_id}",
            json=payload,
            headers=headers if headers else None,
        )
        return _validate_response(Agent, data, method="PUT", endpoint=f"/agents/{agent_id}")

    def delete(
        self,
        agent_id: str,
        *,
        instance_id: str | None = None,
    ) -> None:
        """Delete an agent (synchronous).

        Args:
            agent_id: The agent ID to delete (agt_xxx)
            instance_id: Agent session/conversation ID for observability
        """
        headers: dict[str, str] = {}
        if instance_id:
            headers["X-Instance-ID"] = instance_id
        self._http.delete(
            f"/agents/{agent_id}",
            headers=headers if headers else None,
        )


class SyncDelegationsResource:
    """Synchronous agent delegations API resource."""

    def __init__(self, http: SyncHTTPClient):
        self._http = http

    def list(
        self,
        *,
        delegation_id: str | None = None,
        agent_id: str | None = None,
        delegator_party_id: str | None = None,
        delegatee_party_id: str | None = None,
        include_revoked: bool = False,
        limit: int = 50,
        cursor: str | None = None,
        instance_id: str | None = None,
    ) -> AgentDelegationListResponse:
        """List agent delegations with optional filters (synchronous).

        Args:
            delegation_id: Filter by parent delegation (dlg_xxx)
            agent_id: Filter by agent (agt_xxx)
            delegator_party_id: Filter by customer party granting access
            delegatee_party_id: Filter by partner party receiving access
            include_revoked: Include revoked delegations (default: False)
            limit: Maximum number of delegations (default: 50, max: 100)
            cursor: Cursor for pagination (use next_cursor from previous response)
            instance_id: Agent session/conversation ID for observability

        Returns:
            AgentDelegationListResponse with list of agent delegations and pagination info
        """
        params: dict[str, Any] = {"limit": limit}
        if delegation_id:
            params["delegationId"] = delegation_id
        if agent_id:
            params["agentId"] = agent_id
        if delegator_party_id:
            params["delegatorPartyId"] = delegator_party_id
        if delegatee_party_id:
            params["delegateePartyId"] = delegatee_party_id
        if include_revoked:
            params["includeRevoked"] = True
        if cursor:
            params["cursor"] = cursor

        headers: dict[str, str] = {}
        if instance_id:
            headers["X-Instance-ID"] = instance_id

        data = self._http.get(
            "/agent-delegations", params=params, headers=headers if headers else None
        )
        return _validate_response(
            AgentDelegationListResponse,
            data,
            method="GET",
            endpoint="/agent-delegations",
            unwrap=False,
        )

    def get(self, agent_delegation_id: str) -> AgentDelegation:
        """Get agent delegation by ID (synchronous).

        Args:
            agent_delegation_id: The agent delegation handle (adl_xxx)

        Returns:
            AgentDelegation details
        """
        data = self._http.get(f"/agent-delegations/{agent_delegation_id}")
        return _validate_response(
            AgentDelegation,
            data,
            method="GET",
            endpoint=f"/agent-delegations/{agent_delegation_id}",
        )


class SyncCustomersResource:
    """Synchronous customers API resource."""

    def __init__(self, http: SyncHTTPClient):
        self._http = http

    def list(
        self,
        *,
        limit: int = 50,
        cursor: str | None = None,
        instance_id: str | None = None,
    ) -> CustomerListResponse:
        """List customers who have delegated access to the partner (synchronous).

        Args:
            limit: Maximum number of customers (default: 50, max: 100)
            cursor: Cursor for pagination (use next_cursor from previous response)
            instance_id: Agent session/conversation ID for observability

        Returns:
            CustomerListResponse with list of customers and pagination info
        """
        params: dict[str, Any] = {"limit": limit}
        if cursor:
            params["cursor"] = cursor

        headers: dict[str, str] = {}
        if instance_id:
            headers["X-Instance-ID"] = instance_id

        data = self._http.get(
            "/customers",
            params=params,
            headers=headers if headers else None,
        )
        return _validate_response(
            CustomerListResponse,
            data,
            method="GET",
            endpoint="/customers",
            unwrap=False,
        )


class NaturalClientSync:
    """Synchronous Natural Payments SDK client.

    Use this for non-async codebases. For async code, use NaturalClient instead.

    Example:
        ```python
        from naturalpay import NaturalClientSync

        client = NaturalClientSync(api_key="sk_ntl_sandbox_xxx")

        # Create a payment
        payment = client.payments.create(
            agent_id="agt_xxx",
            amount=5000,
            customer_party_id="pty_xxx",
            recipient="alice@example.com",
            memo="For consulting",
            idempotency_key="unique-key-for-this-payment",
        )

        # Check balance
        balance = client.account.balance()

        # Don't forget to close
        client.close()
        ```

    Or use as context manager:
        ```python
        with NaturalClientSync(api_key="sk_ntl_sandbox_xxx") as client:
            balance = client.account.balance()
        ```
    """

    def __init__(
        self,
        api_key: str | None = None,
        *,
        base_url: str | None = None,
        timeout: float = 30.0,
    ):
        """Initialize the synchronous Natural client.

        Args:
            api_key: API key (defaults to NATURAL_API_KEY env var)
            base_url: API base URL (defaults to NATURAL_SERVER_URL env var)
            timeout: Request timeout in seconds (default: 30)
        """
        self._http = SyncHTTPClient(api_key=api_key, base_url=base_url, timeout=timeout)

        self.payments = SyncPaymentsResource(self._http)
        self.account = SyncAccountResource(self._http)
        self.wallet = SyncWalletResource(self._http)
        self.transactions = SyncTransactionsResource(self._http)
        self.agents = SyncAgentsResource(self._http)
        self.delegations = SyncDelegationsResource(self._http)
        self.customers = SyncCustomersResource(self._http)

    def close(self) -> None:
        """Close the client and release resources."""
        self._http.close()

    def __enter__(self) -> NaturalClientSync:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()
