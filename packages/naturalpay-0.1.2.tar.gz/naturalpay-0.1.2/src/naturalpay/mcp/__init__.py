"""Natural Payments MCP proxy.

The MCP CLI (`naturalpay mcp serve`) proxies stdio to the hosted
Natural MCP server. See cli.py for the implementation.
"""

from naturalpay.mcp.cli import DEFAULT_MCP_URL

__all__ = ["DEFAULT_MCP_URL"]
