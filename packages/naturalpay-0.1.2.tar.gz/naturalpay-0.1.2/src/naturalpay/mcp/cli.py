"""Natural Payments MCP CLI — thin stdio-to-HTTP proxy."""

from __future__ import annotations

import argparse
import os
import sys

DEFAULT_MCP_URL = "https://mcp.natural.co"


def main() -> None:
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        prog="naturalpay",
        description="Natural Payments SDK",
    )
    subparsers = parser.add_subparsers(dest="command", help="Commands")

    # mcp subcommand
    mcp_parser = subparsers.add_parser("mcp", help="MCP server commands")
    mcp_subparsers = mcp_parser.add_subparsers(dest="mcp_command", help="MCP commands")

    # mcp serve
    serve_parser = mcp_subparsers.add_parser("serve", help="Start MCP proxy")
    serve_parser.add_argument(
        "--api-key",
        "-k",
        help="API key (defaults to NATURAL_API_KEY env var)",
    )
    serve_parser.add_argument(
        "--mcp-url",
        "-u",
        help="MCP server URL (defaults to NATURAL_MCP_URL env var)",
    )
    serve_parser.add_argument(
        "--log-level",
        "-l",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        default="INFO",
        help="Log level (default: INFO)",
    )
    serve_parser.add_argument(
        "--log-format",
        choices=["text", "json"],
        default="text",
        help="Log format (default: text)",
    )

    # version
    parser.add_argument(
        "--version",
        "-v",
        action="store_true",
        help="Show version",
    )

    args = parser.parse_args()

    if args.version:
        from naturalpay import __version__

        print(f"naturalpay {__version__}")
        return

    if args.command == "mcp":
        if args.mcp_command == "serve":
            from naturalpay._logging import configure_logging, get_logger

            configure_logging(
                level=args.log_level,
                json_format=args.log_format == "json",
            )
            logger = get_logger(__name__)

            url = args.mcp_url or os.environ.get("NATURAL_MCP_URL") or DEFAULT_MCP_URL
            api_key = args.api_key or os.environ.get("NATURAL_API_KEY")

            if not api_key:
                logger.error("No API key provided. Set NATURAL_API_KEY or use --api-key.")
                sys.exit(1)

            logger.info("Starting Natural Payments MCP proxy", extra={"url": url})

            try:
                from fastmcp import FastMCP
                from fastmcp.client.transports import StreamableHttpTransport

                transport = StreamableHttpTransport(
                    url,
                    headers={"Authorization": f"Bearer {api_key}"},
                )
                proxy = FastMCP.as_proxy(transport)
                proxy.run()
            except KeyboardInterrupt:
                logger.info("Proxy stopped by user")
                sys.exit(0)
            except Exception as e:
                logger.error(f"Proxy error: {e}", exc_info=True)
                sys.exit(1)
        else:
            mcp_parser.print_help()
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
