"""Tool call context for MCP server -> HTTP layer communication.

The MCP server sets tool call data (name + arguments) before invoking SDK
methods. The HTTP layer reads it and sends the X-Tool-Call header to the BFF
for audit/observability. Direct SDK users never interact with this module.
"""

from __future__ import annotations

import base64
import json
from contextvars import ContextVar
from datetime import UTC, datetime
from typing import Any

_tool_call_var: ContextVar[dict[str, Any] | None] = ContextVar("tool_call", default=None)


def set_tool_call(name: str, arguments: dict[str, Any]) -> None:
    """Set the current tool call context (called by MCP server before SDK calls)."""
    _tool_call_var.set(
        {
            "tool": name,
            "arguments": arguments,
            "timestamp": datetime.now(UTC).isoformat(),
        }
    )


def get_tool_call_header() -> str | None:
    """Get the base64-encoded X-Tool-Call header value, or None if not in MCP context."""
    tool_call = _tool_call_var.get()
    if tool_call is None:
        return None
    return base64.b64encode(json.dumps(tool_call).encode()).decode()


def clear_tool_call() -> None:
    """Clear the current tool call context."""
    _tool_call_var.set(None)
