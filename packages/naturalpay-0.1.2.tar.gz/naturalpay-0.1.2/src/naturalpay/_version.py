"""Single source of truth for the SDK version string."""

__version__ = "0.1.1"
