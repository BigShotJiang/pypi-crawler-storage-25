"""Natural Payments SDK - AI agent payment infrastructure.

https://natural.co
"""

from naturalpay._logging import (
    bind_context,
    clear_context,
    configure_logging,
    get_logger,
)
from naturalpay._sync_client import NaturalClientSync
from naturalpay._version import __version__ as __version__
from naturalpay.client import NaturalClient
from naturalpay.exceptions import (
    AuthenticationError,
    InsufficientFundsError,
    InvalidRequestError,
    NaturalError,
    PaymentError,
    RateLimitError,
    RecipientNotFoundError,
    ServerError,
)
from naturalpay.models import (
    AccountBalance,
    Agent,
    AgentCreateResponse,
    AgentDelegation,
    AgentDelegationListResponse,
    AgentListResponse,
    AgentUpdateResponse,
    Customer,
    CustomerListResponse,
    CustomerPartyInfo,
    Transaction,
    TransactionListResponse,
    TransactionTypeFilter,
    WithdrawResponse,
)

__all__ = [
    "__version__",
    # Logging
    "configure_logging",
    "get_logger",
    "bind_context",
    "clear_context",
    # Clients
    "NaturalClient",
    "NaturalClientSync",
    # Models
    "AccountBalance",
    "Transaction",
    "TransactionListResponse",
    "TransactionTypeFilter",
    # Wallet models
    "WithdrawResponse",
    # Agent models
    "Agent",
    "AgentCreateResponse",
    "AgentUpdateResponse",
    "AgentListResponse",
    # Agent delegation models
    "AgentDelegation",
    "AgentDelegationListResponse",
    # Customer models
    "Customer",
    "CustomerListResponse",
    "CustomerPartyInfo",
    # Exceptions
    "NaturalError",
    "AuthenticationError",
    "InvalidRequestError",
    "PaymentError",
    "InsufficientFundsError",
    "RecipientNotFoundError",
    "RateLimitError",
    "ServerError",
]
