"""Natural Payments SDK models."""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

from naturalpay._logging import get_logger

logger = get_logger(__name__)


def _to_camel(s: str) -> str:
    """Convert snake_case to camelCase."""
    parts = s.split("_")
    return parts[0] + "".join(p.capitalize() for p in parts[1:])


class _CamelModel(BaseModel):
    """Base model that accepts camelCase JSON keys and exposes snake_case Python attrs."""

    model_config = ConfigDict(alias_generator=_to_camel, populate_by_name=True)


class TransactionTypeFilter(str, Enum):
    """Filter for transaction types in list operations."""

    PAYMENT = "payment"
    TRANSFER = "transfer"
    ALL = "all"


class AmountInfo(_CamelModel):
    """Amount in minor units (cents)."""

    amount_minor: int


class BalanceBreakdown(_CamelModel):
    """Detailed balance breakdown."""

    operating_funded: AmountInfo
    operating_advanced: AmountInfo
    escrow_funded_settled: AmountInfo
    escrow_advanced: AmountInfo
    holds_outbound: AmountInfo


class AccountBalance(_CamelModel):
    """Wallet balance information from /api/wallet/balance."""

    wallet_id: str
    breakdown: BalanceBreakdown
    available: AmountInfo
    pending_claim_amount_minor: int | None = None
    pending_claim_count: int | None = None

    @model_validator(mode="before")
    @classmethod
    def unwrap_jsonapi(cls, data: dict) -> dict:
        """Unwrap JSON:API resource envelope if present."""
        if isinstance(data, dict) and data.get("type") == "walletBalance" and "attributes" in data:
            return {"walletId": data["id"], **data["attributes"]}
        return data

    @property
    def available_usd(self) -> float:
        """Get available USD balance as a float (dollars)."""
        return self.available.amount_minor / 100


class Transaction(_CamelModel):
    """Transaction record.

    Handles both flat and JSON:API resource responses from the transactions API.
    """

    transaction_id: str = Field(default="")
    status: str  # Pending, Processing, Completed, Failed (case-insensitive)
    amount: int
    currency: str = "USD"
    description: str | None = None
    memo: str | None = None
    created_at: datetime | str | None = None
    updated_at: datetime | str | None = None
    # JSON:API fields
    transaction_type: str | None = None  # payment | transfer
    category: str | None = None  # sent | received | deposit | withdrawal
    direction: str | None = None  # INBOUND | OUTBOUND
    is_delegated: bool = False
    customer_name: str | None = None
    customer_agent_id: str | None = None
    sender_name: str | None = None
    recipient_name: str | None = None
    source_party_id: str | None = None
    destination_party_id: str | None = None
    source_wallet_id: str | None = None
    destination_wallet_id: str | None = None
    claim_link: str | None = None  # Claim URL for provisional payments (only at creation)
    instance_id: str | None = None  # Internal instance ID (ins_xxx) assigned by server

    @model_validator(mode="before")
    @classmethod
    def normalize_fields(cls, data: dict) -> dict:
        """Normalize field names from API response.

        Handles both flat and JSON:API (public) envelopes.
        """
        if isinstance(data, dict):
            # Unwrap JSON:API resource envelope
            if data.get("type") == "transaction" and "attributes" in data:
                flat = {"transactionId": data["id"], **data["attributes"]}
                rels = data.get("relationships", {})
                # Transaction list uses sourceParty/destinationParty
                src = rels.get("sourceParty", {})
                if src and src.get("data"):
                    flat["sourcePartyId"] = src["data"].get("id")
                dst = rels.get("destinationParty", {})
                if dst and dst.get("data"):
                    flat["destinationPartyId"] = dst["data"].get("id")
                # Payment create uses customerParty/counterparty
                cust = rels.get("customerParty", {})
                if cust and cust.get("data"):
                    flat.setdefault("sourcePartyId", cust["data"].get("id"))
                cp = rels.get("counterparty", {})
                if cp and cp.get("data"):
                    flat.setdefault("destinationPartyId", cp["data"].get("id"))
                src_w = rels.get("sourceWallet", {})
                if src_w and src_w.get("data"):
                    flat["sourceWalletId"] = src_w["data"].get("id")
                dst_w = rels.get("destinationWallet", {})
                if dst_w and dst_w.get("data"):
                    flat["destinationWalletId"] = dst_w["data"].get("id")
                data = flat
            elif "id" in data and "transactionId" not in data:
                data["transactionId"] = data["id"]
        return data


class TransactionListResponse(_CamelModel):
    """Response for list transactions endpoint.

    Handles both flat and JSON:API list responses.
    """

    transactions: list[Transaction]
    has_more: bool
    next_cursor: str | None = None

    @model_validator(mode="before")
    @classmethod
    def unwrap_jsonapi(cls, data: dict) -> dict:
        """Unwrap JSON:API list response if present."""
        if isinstance(data, dict) and "data" in data and "meta" in data:
            pagination = data.get("meta", {}).get("pagination", {})
            return {
                "transactions": data["data"],
                "has_more": pagination.get("hasMore", False),
                "next_cursor": pagination.get("nextCursor"),
            }
        return data


class ParsedIntent(_CamelModel):
    """Parsed payment intent from natural language."""

    class Recipient(_CamelModel):
        email: str | None = None
        phone: str | None = None
        bank_token: str | None = None
        counterparty_id: str | None = None

    class BusinessContext(_CamelModel):
        memo: str | None = None

    recipient: Recipient
    amount: float | None = None
    currency: str = "USD"
    business_context: BusinessContext | None = None


# =============================================================================
# AGENT MODELS
# =============================================================================


class Agent(_CamelModel):
    """Agent entity.

    Handles both flat and JSON:API resource responses.
    Used for create, update, get, and list responses (server returns same structure).
    """

    agent_id: str = Field(default="")
    id: str = Field(default="")
    name: str
    description: str | None = None
    status: Literal["ACTIVE", "REVOKED"]
    party_id: str = Field(default="")
    created_at: datetime | str | None = None
    created_by: str | None = None
    updated_at: datetime | str | None = None
    updated_by: str | None = None

    @model_validator(mode="before")
    @classmethod
    def unwrap_jsonapi(cls, data: dict) -> dict:
        """Unwrap JSON:API resource envelope if present."""
        if isinstance(data, dict) and data.get("type") == "agent" and "attributes" in data:
            flat = {"agentId": data["id"], "id": data["id"], **data["attributes"]}
            rels = data.get("relationships", {})
            party_rel = rels.get("party", {})
            if party_rel and party_rel.get("data"):
                flat["partyId"] = party_rel["data"].get("id", "")
            else:
                logger.warning(
                    "Agent %s missing expected 'party' relationship",
                    data.get("id", "?"),
                )
                flat["partyId"] = ""
            return flat
        if isinstance(data, dict):
            if "agentId" in data and "id" not in data:
                data["id"] = data["agentId"]
            elif "id" in data and "agentId" not in data:
                data["agentId"] = data["id"]
        return data


# Backward-compatible aliases — server now returns full Agent resource for all operations
AgentCreateResponse = Agent
AgentUpdateResponse = Agent


class AgentListResponse(_CamelModel):
    """Response for list agents endpoint.

    Handles both flat and JSON:API list responses.
    """

    agents: list[Agent]
    has_more: bool
    next_cursor: str | None = None

    @model_validator(mode="before")
    @classmethod
    def unwrap_jsonapi(cls, data: dict) -> dict:
        """Unwrap JSON:API list response if present."""
        if isinstance(data, dict) and "data" in data and "meta" in data:
            pagination = data.get("meta", {}).get("pagination", {})
            return {
                "agents": data["data"],
                "has_more": pagination.get("hasMore", False),
                "next_cursor": pagination.get("nextCursor"),
            }
        return data


# =============================================================================
# AGENT DELEGATION MODELS
# =============================================================================


class AgentDelegation(_CamelModel):
    """Agent delegation entity.

    Handles JSON:API resource responses from /agent-delegations.
    """

    id: str
    agent_name: str | None = None
    agent_id: str = ""
    delegation_id: str = ""
    delegator_party_id: str | None = None
    delegatee_party_id: str | None = None
    delegator_party_name: str | None = None
    delegatee_party_name: str | None = None
    permissions: list[str]
    limits: dict[str, int] | None = None
    expires_at: datetime | str | None = None
    created_at: datetime | str
    created_by: str | None = None
    updated_at: datetime | str | None = None

    @model_validator(mode="before")
    @classmethod
    def unwrap_jsonapi(cls, data: dict) -> dict:
        """Unwrap JSON:API resource envelope if present."""
        if (
            isinstance(data, dict)
            and data.get("type") == "agentDelegation"
            and "attributes" in data
        ):
            flat = {"id": data["id"], **data["attributes"]}
            rels = data.get("relationships", {})
            delegation = rels.get("delegation", {})
            if delegation and delegation.get("data"):
                flat["delegationId"] = delegation["data"].get("id", "")
            agent = rels.get("agent", {})
            if agent and agent.get("data"):
                flat["agentId"] = agent["data"].get("id", "")
            delegator = rels.get("delegatorParty", {})
            if delegator and delegator.get("data"):
                flat["delegatorPartyId"] = delegator["data"].get("id", "")
            delegatee = rels.get("delegateeParty", {})
            if delegatee and delegatee.get("data"):
                flat["delegateePartyId"] = delegatee["data"].get("id", "")
            return flat
        return data


class AgentDelegationListResponse(_CamelModel):
    """Response for list agent delegations endpoint (cursor-based pagination)."""

    agent_delegations: list[AgentDelegation]
    has_more: bool
    next_cursor: str | None = None

    @model_validator(mode="before")
    @classmethod
    def unwrap_jsonapi(cls, data: dict) -> dict:
        """Unwrap JSON:API list response if present."""
        if isinstance(data, dict) and "data" in data and "meta" in data:
            pagination = data.get("meta", {}).get("pagination", {})
            return {
                "agentDelegations": data["data"],
                "has_more": pagination.get("hasMore", False),
                "next_cursor": pagination.get("nextCursor"),
            }
        return data


# =============================================================================
# CUSTOMER MODELS
# =============================================================================


class CustomerPartyInfo(BaseModel):
    """Customer party information."""

    id: str
    name: str
    email: str | None = None


class Customer(_CamelModel):
    """Customer from /customers.

    Represents a party that has delegated access to the caller.
    Handles both flat and JSON:API resource responses.
    """

    id: str
    type: str  # "party" or "delegationInvitation"
    party: CustomerPartyInfo | None = None
    email: str | None = None
    status: str
    permissions: list[str] = Field(default_factory=list)
    created_at: datetime | str
    wallet_available_minor: int | None = None
    wallet_available_dollars: str | None = None
    wallet_access: str  # "granted", "denied", "noWallet"

    @model_validator(mode="before")
    @classmethod
    def unwrap_jsonapi(cls, data: dict) -> dict:
        """Unwrap JSON:API resource envelope if present."""
        if isinstance(data, dict) and "attributes" in data and "type" in data:
            return {"id": data["id"], "type": data["type"], **data["attributes"]}
        return data


class CustomerListResponse(_CamelModel):
    """Paginated list of customers (cursor-based pagination).

    Handles both flat and JSON:API list responses.
    """

    items: list[Customer]
    has_more: bool
    next_cursor: str | None = None

    @model_validator(mode="before")
    @classmethod
    def unwrap_jsonapi(cls, data: dict) -> dict:
        """Unwrap JSON:API list response if present."""
        if isinstance(data, dict) and "data" in data and "meta" in data:
            pagination = data.get("meta", {}).get("pagination", {})
            return {
                "items": data["data"],
                "has_more": pagination.get("hasMore", False),
                "next_cursor": pagination.get("nextCursor"),
            }
        return data


# =============================================================================
# DEPOSIT/WITHDRAW MODELS
# =============================================================================


class WithdrawResponse(_CamelModel):
    """Response from withdrawal initiation.

    Handles both flat and JSON:API resource responses from the withdrawal endpoint.
    """

    transfer_id: str | None = None
    instruction_id: str | None = None
    status: str  # PROCESSING, KYC_REQUIRED, MFA_REQUIRED, FAILED
    amount: int
    currency: str = "USD"
    estimated_settlement: datetime | str | None = None
    # KYC fields
    kyc_required: bool = False
    kyc_status: str | None = None
    kyc_session_url: str | None = None
    # MFA fields
    mfa_required: bool = False
    mfa_challenge_id: str | None = None
    mfa_expires_at: datetime | str | None = None
    # Error fields
    error: str | None = None
    error_details: str | None = None

    @model_validator(mode="before")
    @classmethod
    def unwrap_jsonapi(cls, data: dict) -> dict:
        """Unwrap JSON:API resource envelope if present."""
        if isinstance(data, dict) and data.get("type") == "withdrawal" and "attributes" in data:
            flat = {"transferId": data["id"], **data["attributes"]}
            return flat
        return data
