# Changelog

All notable changes to `vcti-array-display` are documented here.

## [2.0.0] — 2026-04-17

### Removed (breaking)
- **`append_columns()`** — removed.  This method allocated a new joined
  array, violating ArrayDisplay's reference-only invariant.  For adding
  columns, join externally with ``vcti.nputils.join_struct_arrays`` or
  use ``vcti-fieldset`` for multi-array management without join cost.
- Dependency on ``vcti.nputils.join_struct_arrays`` dropped from
  ``array_display.py`` (``flatten_record_dtype`` still imported).

### Migration
```python
# Before (1.2 and earlier)
view = ArrayDisplay(arr)
view.append_columns(extra)
view.include_view_columns(['new_col'])

# After (1.3+)
from vcti.nputils import join_struct_arrays
combined = join_struct_arrays([arr, extra])
view = ArrayDisplay(combined)
view.include_view_columns(['new_col'])
```

## [1.2.0] — 2026-04-17

### Added
- **Plain 1-D and 2-D array support** — `ArrayDisplay` now accepts plain
  numpy arrays (not just structured).  Zero-copy internally via
  `np.ndarray.view()` — the same mechanism `flatten_dtype` uses in reverse.
  Structured input is unchanged.
- **`field_names` parameter** — explicit column names for plain 1-D/2-D
  input.  Defaults: 1-D → `["value"]`; 2-D → `["col_0", "col_1", ...]`.
- **`field_name_prefix` parameter** — customize the auto-generated prefix
  for plain 2-D input (default `"col"`).
- **`_normalization.py`** module — `to_structured_view()` helper.
- Tests for plain 1-D/2-D handling: auto-naming, explicit names, prefix
  override, wrong-length, duplicates, non-contiguous, higher-dim,
  memory sharing, composition with other pillars.
- README "Plain 1-D and 2-D Arrays" section; patterns.md recipes for
  2-D with named columns and 1-D single-column.
- Cost column in README API summary (Cheap / Moderate / Heavy).

### Changed
- Package tagline updated: "Presentation layer for NumPy arrays — structured,
  1-D, or 2-D."
- Troubleshooting entries replaced: old "Expected a structured array" FAQ
  is gone (no longer raised); added entries for "2-D must be C-contiguous"
  and "Plain arrays must have ndim 1 or 2".
- `set_array()` error type for unsupported input changed from `TypeError`
  to `ValueError` (for higher-dim or non-contiguous 2-D).

## [1.1.0] — 2026-03-29

### Fixed
- `column_list=[]` was treated as `None` (showed all columns instead of none).
- `set_view_columns()` now copies the input list defensively — external
  mutation of the passed list no longer corrupts internal state.
- `assert` statements replaced with proper `TypeError`/`ValueError` raises —
  safe under `python -O`.
- `pd.get_option("display.max_rows")` returning `0` no longer falls through
  to default.
- Stale zero-copy claims removed from README and performance guide (pandas
  copies structured arrays into DataFrames).

### Added
- **Read-only properties** — `view_columns`, `name_columns`, `field_components`
  return defensive copies / `MappingProxyType` to prevent accidental mutation.
- **`copy()`** — shallow copy with shared array and independent configuration.
- **`to_slice()` conflict detection** — raises `ValueError` when incompatible
  parameters are combined (e.g. `mask` with `head`/`tail`).
- **`ColumnExclusion`** exported from top-level `__init__.py` for typed
  consumer code.
- **`__repr__`** now shows active features: flattened field count and enum
  mapping count alongside rows/cols.
- **`extending.md`** — contributor guide for adding adapters, patterns, and
  integrating with vcti-array-tree (including ecosystem diagram).
- **`examples/full_pipeline.py`** — complete end-to-end script demonstrating
  all five pillars.
- **`array_display.pyi`** — type stub file for improved IDE support.
- **Sphinx `conf.py`** — enables doc builds with autodoc and MyST-Parser.
- **`MANIFEST.in`** — controls sdist contents, excludes tests/docs/.claude.
- **`tests/bench_array_display.py`** — performance regression benchmarks
  verifying O(displayed rows) on 10M-row arrays (marked `@pytest.mark.benchmark`).
- **Python 3.14** added to CI test matrix.
- Parametrized exclusion pattern tests.
- Tests for empty column list, to_slice conflicts, read-only properties, copy().
- Troubleshooting entries: empty `field_components`, enum debugging,
  `_column_aliases` tracking.
- Performance guide: O() complexity table and bounded-vs-full guidance.
- Source guide: `_column_aliases` lifecycle documentation with examples.
- Design guide: copy-vs-mutation guidance, strict slicing parameters.

### Changed
- `import_pandas()` return type narrowed from `Any` to `types.ModuleType`.
- `math.prod()` replaces manual loop in `_flattening.py`.
- `to_dataframe()` docstring no longer claims zero-copy.
- `CONTRIBUTING.md` includes `mypy` and `typecheck` dependency group.

### Removed
- Unused `conftest.py` fixtures (tests use inline helpers).

## [1.0.0] — 2026-03-28

### Added
- Initial release.
- **Column filtering** — `exclude_columns` with str, regex, or callable rules.
  Pre-built patterns: `FILLER_COLUMNS` (C++ alignment) and `LENGTH_COLUMNS`
  (internal string lengths).
- **Dtype flattening** — `flatten_dtype` expands vector/matrix fields.
  `component_names` and `set_component_names()` for custom suffixes.
  `field_components` tracks the grouping for consumer use.
- **Enum mapping** — `add_name_columns()` with lazy resolution on bounded slices.
- **Array slicing** — `to_slice()` returns index arrays (head, tail, mask, indices).
- **Adapters** — `to_table()` (pure numpy text table), `to_dataframe()`
  (pandas with `pd.Categorical`), `_repr_html_()` (Jupyter).
- Optional `pandas` dependency for DataFrame and Jupyter features.
- Structured array validation in `set_array()`.
