# Contributing to vcti-array-display

## Development Setup

```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -e ".[test,lint,typecheck]"
```

## Running Tests

```bash
pytest
```

Coverage is enforced at 95% via `pyproject.toml`.

## Type Checking

```bash
mypy src/
```

## Linting and Formatting

```bash
ruff check src/ tests/          # lint
ruff format --check src/ tests/ # format check
ruff check --fix src/ tests/    # auto-fix
ruff format src/ tests/         # apply formatting
```

## Project Layout

```
src/vcti/arraydisplay/   # Source code
tests/                 # Tests (test_<module>.py)
docs/                  # Documentation
```

## Architecture

The source code is organized around five pillars:

1. **Column filtering** — name, regex, and dtype-based exclusion
2. **Dtype flattening** — vector/matrix expansion with component tracking
3. **Enum mapping** — lazy integer-to-name resolution
4. **Array slicing** — lightweight index arrays for bounded access
5. **Adapters** — text table and pandas DataFrame rendering

See [docs/source-guide.md](docs/source-guide.md) for a detailed walkthrough.

## Guidelines

- Follow Google-style docstrings and PEP 585/604 type annotations.
- See [docs/design.md](docs/design.md) for design decisions and boundaries.
