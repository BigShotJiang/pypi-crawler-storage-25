# Security Policy

## Reporting a Vulnerability

If you discover a security vulnerability in any vcti package, please report
it responsibly using one of the following channels:

- **Public repositories:** Open an issue on the GitHub repository, or email
  security@vcollab.com if the vulnerability should not be disclosed publicly
  before a fix is available.
- **Private repositories:** Email security@vcollab.com directly.

Please include:

- Description of the vulnerability
- Steps to reproduce
- Affected versions
- Any potential impact assessment

## Scope

vcti-array-display is a pure data presentation library that operates on
in-memory NumPy arrays only. It does not handle network I/O, file I/O,
user authentication, or external service calls. Security concerns are
limited to:

- Processing untrusted structured array data (malformed dtypes)
- Memory safety when working with numpy array views
