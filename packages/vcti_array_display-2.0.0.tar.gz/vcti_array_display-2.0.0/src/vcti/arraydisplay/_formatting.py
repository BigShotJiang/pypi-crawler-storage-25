# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Value formatting and pandas import helpers for adapters."""

from __future__ import annotations

import types
from typing import Any

import numpy as np


def format_value(value: Any) -> str:
    """Format a single array value for text display.

    Handles floats (6 significant digits), integers, bytes, and strings.
    """
    if isinstance(value, (np.floating, float)):
        if np.isnan(value):
            return "NaN"
        return f"{value:.6g}"
    if isinstance(value, (np.integer, int)):
        return str(int(value))
    if isinstance(value, (bytes, np.bytes_)):
        return value.decode(errors="replace")
    return str(value)


def import_pandas() -> types.ModuleType:
    """Import pandas or raise a helpful error.

    Returns:
        The pandas module.

    Raises:
        ImportError: If pandas is not installed.
    """
    try:
        import pandas as pd
    except ImportError:
        raise ImportError(
            "pandas is required for this method. "
            "Install with: pip install vcti-array-display[pandas]"
        ) from None
    return pd
