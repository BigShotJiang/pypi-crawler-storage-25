# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Column exclusion rules and pre-built patterns.

Provides the generic exclusion mechanism used by ArrayDisplay to filter
columns by name, regex, or a callable predicate that receives both the
column name and its dtype.
"""

from __future__ import annotations

import re
from collections.abc import Callable, Sequence

import numpy as np

ColumnExclusion = str | re.Pattern[str] | Callable[[str, np.dtype], bool]
"""A single exclusion rule:

- ``str`` — exact column name match.
- ``re.Pattern`` — regex matched against the column name.
- ``callable(name: str, dtype: np.dtype) -> bool`` — predicate receiving
  the column name *and* its dtype, for filtering based on type, shape,
  or any combination.
"""

FILLER_COLUMNS: re.Pattern[str] = re.compile(r"^f\d+$")
"""Matches C++ memory-alignment filler fields by name (f0, f3, f123, …)."""

LENGTH_COLUMNS: re.Pattern[str] = re.compile(r"_len$")
"""Matches internal string-length columns by name (label_len, name_len, …)."""


def VOID_COLUMNS(name: str, dtype: np.dtype) -> bool:
    """Exclude all void-dtype fields (C++ alignment padding by dtype)."""
    return dtype.kind == "V"


def is_excluded(name: str, dtype: np.dtype, rules: Sequence[ColumnExclusion]) -> bool:
    """Test whether a column name/dtype matches any exclusion rule.

    Args:
        name: Column name to test.
        dtype: Column's dtype.
        rules: Sequence of exclusion rules.

    Returns:
        True if the column should be excluded.
    """
    for rule in rules:
        if isinstance(rule, str):
            if name == rule:
                return True
        elif isinstance(rule, re.Pattern):
            if rule.search(name) is not None:
                return True
        elif callable(rule):
            if rule(name, dtype):
                return True
    return False
