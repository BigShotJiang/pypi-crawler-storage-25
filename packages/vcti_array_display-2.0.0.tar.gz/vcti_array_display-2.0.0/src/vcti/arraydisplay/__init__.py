# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""vcti.arraydisplay — Presentation layer for NumPy structured arrays."""

from importlib.metadata import version

from ._exclusion import FILLER_COLUMNS, LENGTH_COLUMNS, VOID_COLUMNS, ColumnExclusion
from .array_display import ArrayDisplay

__version__ = version("vcti-array-display")

__all__ = [
    "__version__",
    "ArrayDisplay",
    "ColumnExclusion",
    "FILLER_COLUMNS",
    "LENGTH_COLUMNS",
    "VOID_COLUMNS",
]
