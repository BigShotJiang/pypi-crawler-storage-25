"""Type stubs for array_display module — improved IDE support."""

from collections.abc import Sequence
from types import MappingProxyType

import numpy as np
import pandas as pd

from ._exclusion import ColumnExclusion

class ArrayDisplay:
    array: np.ndarray | None
    original_dtype: np.dtype | None

    def __init__(
        self,
        src_obj: np.ndarray | None = ...,
        column_list: list[str] | None = ...,
        flatten_dtype: bool = ...,
        exclude_columns: Sequence[ColumnExclusion] | None = ...,
        component_names: dict[str, list[str]] | None = ...,
        field_names: list[str] | None = ...,
        field_name_prefix: str = ...,
    ) -> None: ...

    # Read-only properties
    @property
    def view_columns(self) -> list[str]: ...
    @property
    def name_columns(self) -> MappingProxyType[str, tuple[str, dict[int, str]]]: ...
    @property
    def field_components(self) -> MappingProxyType[str, list[str]]: ...

    # 1. Column filtering
    def set_view_columns(
        self,
        column_list: list[str] | None = ...,
        exclude_columns: Sequence[ColumnExclusion] | None = ...,
    ) -> None: ...
    def include_view_columns(self, column_list: list[str]) -> None: ...
    def exclude_view_columns(self, column_list: list[str]) -> None: ...
    def replace_view_columns(self, mapping: dict[str, str]) -> None: ...

    # 2. Dtype flattening
    def set_array(
        self,
        src_array: np.ndarray,
        column_list: list[str] | None = ...,
        flatten_dtype: bool = ...,
        exclude_columns: Sequence[ColumnExclusion] | None = ...,
        component_names: dict[str, list[str]] | None = ...,
        field_names: list[str] | None = ...,
        field_name_prefix: str = ...,
    ) -> None: ...
    def set_component_names(self, field: str, names: list[str]) -> None: ...

    # 3. Enum mapping
    def add_name_columns(self, name_columns: dict[str, tuple[str, dict[int, str]]]) -> None: ...

    # 4. Array slicing
    def to_slice(
        self,
        *,
        head: int | None = ...,
        tail: int | None = ...,
        mask: np.ndarray | None = ...,
        indices: np.ndarray | None = ...,
    ) -> np.ndarray: ...

    # 5. Adapters
    def to_table(
        self,
        *,
        head: int = ...,
        tail: int = ...,
        max_col_width: int = ...,
        indices: np.ndarray | None = ...,
    ) -> str: ...
    def to_dataframe(
        self,
        *,
        indices: np.ndarray | None = ...,
        head: int | None = ...,
        tail: int | None = ...,
        resolve_names: bool = ...,
    ) -> pd.DataFrame: ...
    def _repr_html_(self) -> str | None: ...

    # Misc
    def copy(self) -> ArrayDisplay: ...
    def __len__(self) -> int: ...
    def __repr__(self) -> str: ...
    def __str__(self) -> str: ...
