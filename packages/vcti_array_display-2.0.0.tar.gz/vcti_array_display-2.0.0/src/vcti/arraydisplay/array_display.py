# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""ArrayDisplay — presentation layer for NumPy structured arrays.

Provides five capabilities over raw structured arrays:

1. **Column filtering** — hide columns by name, regex, or predicate.
2. **Dtype flattening** — expand vector/matrix fields into scalar columns
   with user-controllable component names.
3. **Enum mapping** — lazily map integer ID columns to human-readable names.
4. **Array slicing** — create lightweight index arrays for bounded access.
5. **Adapters** — render as text table or pandas DataFrame on bounded slices.
"""

from __future__ import annotations

import copy
from collections.abc import Sequence
from types import MappingProxyType
from typing import Any

import numpy as np
from vcti.nputils import flatten_record_dtype

from ._exclusion import ColumnExclusion, is_excluded
from ._flattening import build_field_components
from ._formatting import format_value, import_pandas
from ._normalization import to_structured_view


class ArrayDisplay:
    """Presentation layer for NumPy structured arrays.

    Wraps a structured array reference (no copy) and records how it should
    be presented:

    1. **Column filtering** — ``exclude_columns`` hides fields by name,
       regex, or callable.  Pre-built patterns ``FILLER_COLUMNS`` and
       ``LENGTH_COLUMNS`` cover common C++ interop noise.
    2. **Dtype flattening** — ``flatten_dtype`` expands vector/matrix fields
       into scalar columns.  ``set_component_names()`` lets you replace
       the default numeric suffixes (``_0``, ``_1``) with meaningful labels
       (``_x``, ``_y``, ``_z``).
    3. **Enum mapping** — ``add_name_columns()`` stores a recipe mapping
       integer IDs to strings.  Resolution is lazy — applied only when
       a bounded slice is presented.
    4. **Array slicing** — ``to_slice()`` returns a lightweight index array
       for bounded access without copying the full data.
    5. **Adapters** — ``to_table()`` (pure numpy) and ``to_dataframe()``
       (optional pandas) render bounded slices with all mappings applied.

    Attributes:
        array: The underlying structured array (reference, not copy).
        original_dtype: Dtype before any flattening.
        view_columns: Ordered list of user-visible column names (read-only copy).
        name_columns: Enum mapping recipes (read-only view).
        field_components: Flattened field grouping (read-only view).
    """

    def __init__(
        self,
        src_obj: np.ndarray | None = None,
        column_list: list[str] | None = None,
        flatten_dtype: bool = False,
        exclude_columns: Sequence[ColumnExclusion] | None = None,
        component_names: dict[str, list[str]] | None = None,
        field_names: list[str] | None = None,
        field_name_prefix: str = "col",
    ) -> None:
        """Initialize an ArrayDisplay.

        Args:
            src_obj: NumPy array (structured, 1-D, or 2-D), or None for empty.
            column_list: Explicit columns to show.  If None, all columns
                minus those matching *exclude_columns*.
            flatten_dtype: Expand vector/matrix fields into scalar columns.
            exclude_columns: Rules for hiding columns — each element is a
                ``str`` (exact), ``re.Pattern`` (regex), or callable.
            component_names: Custom suffixes for flattened fields, e.g.
                ``{'position': ['x', 'y', 'z']}`` renames ``position_0``
                through ``position_2`` to ``position_x`` through ``position_z``.
                Only meaningful when *flatten_dtype* is True.
            field_names: Explicit field names for plain 1-D or 2-D input.
                Ignored for structured input.  For 1-D: must have length 1
                (default: ``["value"]``).  For 2-D ``(N, K)``: must have
                length K.
            field_name_prefix: Prefix for auto-generated field names on
                plain 2-D input (default ``"col"`` produces
                ``col_0, col_1, ...``).  Ignored when *field_names* is
                provided, for 1-D input, or for structured input.
        """
        self.array: np.ndarray | None = None
        self.original_dtype: np.dtype | None = None
        self._view_columns: list[str] = []
        self._name_columns: dict[str, tuple[str, dict[int, str]]] = {}
        self._field_components: dict[str, list[str]] = {}
        # Maps display names to actual dtype column names, used when
        # set_component_names() renames flattened columns.  Survives
        # multiple renames (e.g. x→lat) by always tracking back to
        # the original dtype column.
        self._column_aliases: dict[str, str] = {}

        if isinstance(src_obj, np.ndarray):
            self.set_array(
                src_obj,
                column_list,
                flatten_dtype,
                exclude_columns,
                component_names,
                field_names,
                field_name_prefix,
            )
        elif src_obj is not None:
            raise TypeError(f"Expected np.ndarray or None, got {type(src_obj).__name__}")

    # -- Read-only properties ---------------------------------------------------

    @property
    def view_columns(self) -> list[str]:
        """Ordered list of user-visible column names (defensive copy)."""
        return list(self._view_columns)

    @property
    def name_columns(self) -> MappingProxyType[str, tuple[str, dict[int, str]]]:
        """Enum mapping recipes ``{name: (id_col, {int: str})}`` (read-only view)."""
        return MappingProxyType(self._name_columns)

    @property
    def field_components(self) -> MappingProxyType[str, list[str]]:
        """Flattened field grouping ``{field: [col, ...]}`` (read-only view)."""
        return MappingProxyType(self._field_components)

    # -- 1. Column filtering ----------------------------------------------------

    def set_view_columns(
        self,
        column_list: list[str] | None = None,
        exclude_columns: Sequence[ColumnExclusion] | None = None,
    ) -> None:
        """Configure which columns are visible.

        Args:
            column_list: Explicit columns.  If None, use all array columns
                minus those matching *exclude_columns*.
            exclude_columns: Rules for hiding columns.
        """
        if self.array is None:
            self._view_columns = []
            return

        if column_list is not None:
            self._view_columns = list(column_list)
            return

        if self.array.dtype.names is None:
            raise TypeError("Array has no named fields")
        cols = list(self.array.dtype.names)

        if exclude_columns:
            dt = self.array.dtype
            cols = [c for c in cols if not is_excluded(c, dt[c], exclude_columns)]

        self._view_columns = cols

    def include_view_columns(self, column_list: list[str]) -> None:
        """Add columns to the current view."""
        self._view_columns.extend(column_list)

    def exclude_view_columns(self, column_list: list[str]) -> None:
        """Remove columns from the current view."""
        exclude = set(column_list)
        self._view_columns = [c for c in self._view_columns if c not in exclude]

    def replace_view_columns(self, mapping: dict[str, str]) -> None:
        """Replace column names in the view.

        Args:
            mapping: Dict mapping old_name -> new_name.
        """
        for i, col in enumerate(self._view_columns):
            if col in mapping:
                self._view_columns[i] = mapping[col]

    # -- 2. Dtype flattening ----------------------------------------------------

    def set_array(
        self,
        src_array: np.ndarray,
        column_list: list[str] | None = None,
        flatten_dtype: bool = False,
        exclude_columns: Sequence[ColumnExclusion] | None = None,
        component_names: dict[str, list[str]] | None = None,
        field_names: list[str] | None = None,
        field_name_prefix: str = "col",
    ) -> None:
        """Set or replace the internal array.

        Plain 1-D and 2-D arrays are reinterpreted as structured arrays via a
        zero-copy ``np.ndarray.view()``.  Structured arrays are used as-is.

        Args:
            src_array: NumPy array.  Structured, 1-D, or 2-D.
            column_list: Explicit columns to show.
            flatten_dtype: Expand vector/matrix fields into scalar columns.
            exclude_columns: Rules for hiding columns.
            component_names: Custom suffixes for flattened fields.
            field_names: Explicit field names for plain 1-D/2-D input.
            field_name_prefix: Prefix for auto-generated names on plain 2-D.

        Raises:
            TypeError: If *src_array* is not an ndarray.
            ValueError: If a plain array is non-contiguous, has ``ndim > 2``,
                or *field_names* is the wrong length / has duplicates.
        """
        normalized = to_structured_view(src_array, field_names, field_name_prefix)
        self.original_dtype = normalized.dtype
        self._field_components = {}
        self._name_columns = {}
        self._column_aliases = {}

        if flatten_dtype and normalized.ndim == 1:
            flattened_dt, _ = flatten_record_dtype(normalized.dtype)
            self.array = normalized.view(flattened_dt)
            self._field_components = build_field_components(normalized.dtype, flattened_dt)
        else:
            self.array = normalized

        self.set_view_columns(column_list, exclude_columns)

        if component_names:
            for field, names in component_names.items():
                self.set_component_names(field, names)

    def set_component_names(self, field: str, names: list[str]) -> None:
        """Rename flattened component columns for a multi-component field.

        After dtype flattening, a field like ``position(3,)`` becomes
        ``position_0, position_1, position_2``.  This method renames them
        to ``position_x, position_y, position_z`` (given ``names=['x','y','z']``).

        Args:
            field: Original field name (before flattening).
            names: New suffixes — one per component.

        Raises:
            ValueError: If *field* is not in ``field_components`` or the
                number of names doesn't match the component count.
        """
        if field not in self._field_components:
            raise ValueError(
                f"Field '{field}' has no flattened components. "
                f"Available: {list(self._field_components)}"
            )

        current = self._field_components[field]
        if len(names) != len(current):
            raise ValueError(
                f"Field '{field}' has {len(current)} components, got {len(names)} names"
            )

        rename = {}
        new_cols = []
        for old_col, suffix in zip(current, names):
            new_col = f"{field}_{suffix}"
            rename[old_col] = new_col
            new_cols.append(new_col)
            # Track the actual dtype column name for data access
            dtype_col = self._column_aliases.get(old_col, old_col)
            self._column_aliases[new_col] = dtype_col
            self._column_aliases.pop(old_col, None)

        self.replace_view_columns(rename)
        self._field_components[field] = new_cols

    # -- 3. Enum mapping --------------------------------------------------------

    def add_name_columns(self, name_columns: dict[str, tuple[str, dict[int, str]]]) -> None:
        """Register enum ID -> name mappings (lazy — resolved at presentation).

        Stores a recipe for each mapping.  The actual resolution happens
        only when ``to_table()`` or ``to_dataframe()`` processes a bounded
        slice.  Automatically replaces ID columns with name columns in
        ``view_columns``.

        Args:
            name_columns: ``{name_column: (id_column, {int: str})}``.

        Example:
            >>> view.add_name_columns({
            ...     'element_type_name': ('element_type', {1: 'QUAD', 2: 'HEX'}),
            ... })
        """
        self._name_columns.update(name_columns)
        replacement_map = {v[0]: k for k, v in name_columns.items()}
        self.replace_view_columns(replacement_map)

    def _resolve_column_values(self, col: str, indices: np.ndarray) -> np.ndarray:
        """Resolve column values for a bounded set of row indices.

        Regular columns return values directly.  Name columns map integer
        IDs to strings via the stored recipe.  Uses a plain list
        comprehension — faster than ``np.vectorize`` for the small slices
        that presentation methods operate on.
        """
        if self.array is None:
            raise ValueError("No array set")
        if col in self._name_columns:
            id_col, mapping = self._name_columns[col]
            id_values = self.array[id_col][indices]
            return np.array([mapping.get(int(x), str(x)) for x in id_values])
        dtype_col = self._column_aliases.get(col, col)
        return self.array[dtype_col][indices]

    # -- 4. Array slicing -------------------------------------------------------

    def to_slice(
        self,
        *,
        head: int | None = None,
        tail: int | None = None,
        mask: np.ndarray | None = None,
        indices: np.ndarray | None = None,
    ) -> np.ndarray:
        """Create an index array for bounded access.

        Returns a lightweight integer index array suitable for fancy
        indexing: ``view.array[view.to_slice(head=20)]``.

        Exactly one slicing strategy should be provided.  Priority when
        multiple are given: *indices* > *mask* > *head*/*tail*.

        Args:
            head: Number of rows from the start.
            tail: Number of rows from the end.
            mask: Boolean mask array.
            indices: Explicit integer index array (returned as-is).

        Returns:
            Integer index array (dtype ``np.intp``).

        Raises:
            ValueError: If no array is set, or if conflicting parameters
                are provided (e.g. *mask* with *head*/*tail*).
        """
        if self.array is None:
            raise ValueError("No array set")

        n = len(self.array)

        # Validate parameter combinations
        has_head_tail = head is not None or tail is not None
        if indices is not None and (mask is not None or has_head_tail):
            raise ValueError("Cannot combine 'indices' with other slicing parameters")
        if mask is not None and has_head_tail:
            raise ValueError("Cannot combine 'mask' with 'head'/'tail'")

        if indices is not None:
            return indices

        if mask is not None:
            return np.where(mask)[0]

        if head is not None and tail is not None:
            h = np.arange(min(head, n))
            t = np.arange(max(0, n - tail), n)
            return np.unique(np.concatenate([h, t]))

        if head is not None:
            return np.arange(min(head, n))

        if tail is not None:
            return np.arange(max(0, n - tail), n)

        return np.arange(n)

    # -- 5. Adapters ------------------------------------------------------------

    def to_table(
        self,
        *,
        head: int = 20,
        tail: int = 5,
        max_col_width: int = 30,
        indices: np.ndarray | None = None,
    ) -> str:
        """Render a text table from a bounded slice (pure numpy).

        Resolves enum name columns and formats the output as an aligned
        plain-text table.  Only the requested rows are processed.

        Args:
            head: Rows from the start (ignored if *indices* given).
            tail: Rows from the end (ignored if *indices* given).
            max_col_width: Maximum column display width in characters.
            indices: Explicit row indices (overrides head/tail).

        Returns:
            Formatted text table string.
        """
        if self.array is None or not self._view_columns:
            return repr(self)

        n = len(self.array)
        cols = self._view_columns

        # Determine row blocks and whether to show an ellipsis separator
        if indices is not None:
            blocks: list[np.ndarray | None] = [indices]
        elif n > head + tail:
            blocks = [
                np.arange(min(head, n)),
                None,  # ellipsis marker
                np.arange(max(0, n - tail), n),
            ]
        else:
            blocks = [np.arange(n)]

        # Resolve column values per block and convert to strings
        str_rows: list[list[str] | None] = []
        for block in blocks:
            if block is None:
                str_rows.append(None)
                continue
            col_values = {col: self._resolve_column_values(col, block) for col in cols}
            for i in range(len(block)):
                str_rows.append([format_value(col_values[col][i]) for col in cols])

        # Calculate column widths
        col_widths: list[int] = []
        for ci, col in enumerate(cols):
            max_val = max(
                (len(row[ci]) for row in str_rows if row is not None),
                default=0,
            )
            col_widths.append(min(max(len(col), max_val), max_col_width))

        # Determine numeric alignment per column
        dt = self.array.dtype
        dtype_names = set(dt.names or ())

        def _is_numeric(col: str) -> bool:
            if col in self._name_columns:
                return False
            actual = self._column_aliases.get(col, col)
            return actual in dtype_names and np.issubdtype(dt[actual], np.number)

        col_numeric = [_is_numeric(col) for col in cols]

        def fmt(val: str, ci: int) -> str:
            w = col_widths[ci]
            if len(val) > w:
                val = val[: w - 1] + "\u2026"
            return val.rjust(w) if col_numeric[ci] else val.ljust(w)

        sep = " | "
        lines: list[str] = []

        # Header
        lines.append(
            sep.join(col.ljust(col_widths[ci])[: col_widths[ci]] for ci, col in enumerate(cols))
        )
        lines.append("-+-".join("-" * w for w in col_widths))

        # Data rows
        for row in str_rows:
            if row is None:
                lines.append(sep.join("...".center(col_widths[ci]) for ci in range(len(cols))))
            else:
                lines.append(sep.join(fmt(row[ci], ci) for ci in range(len(cols))))

        lines.append(f"\n[{n} rows x {len(cols)} columns]")
        return "\n".join(lines)

    def to_dataframe(
        self,
        *,
        indices: np.ndarray | None = None,
        head: int | None = None,
        tail: int | None = None,
        resolve_names: bool = True,
    ) -> Any:
        """Convert a bounded slice to a pandas DataFrame.

        Enum name columns are materialized using ``pd.Categorical`` for
        memory efficiency.

        Args:
            indices: Explicit row indices.
            head: Rows from the start.
            tail: Rows from the end.
            resolve_names: If True, materialize enum name columns.
                If False, show raw ID columns instead.

        Returns:
            pandas DataFrame with the configured view columns.

        Raises:
            ImportError: If pandas is not installed.
        """
        pd = import_pandas()

        if self.array is None:
            return pd.DataFrame()

        if indices is None and (head is not None or tail is not None):
            indices = self.to_slice(head=head, tail=tail)

        arr = self.array if indices is None else self.array[indices]
        df = pd.DataFrame(arr)

        cols = self._view_columns

        # Rename aliased columns (from set_component_names) in the DataFrame
        if self._column_aliases:
            reverse = {v: k for k, v in self._column_aliases.items() if k in cols}
            if reverse:
                df = df.rename(columns=reverse)

        if resolve_names:
            for name_col, (id_col, mapping) in self._name_columns.items():
                if name_col in cols:
                    df[name_col] = pd.Categorical(df[id_col].map(mapping))
            return df[cols]

        # resolve_names=False: swap name columns back to source ID columns
        select = [self._name_columns[c][0] if c in self._name_columns else c for c in cols]
        return df[select]

    def _repr_html_(self) -> str | None:
        """Rich HTML display for Jupyter notebooks."""
        if self.array is None or not self._view_columns:
            return None

        try:
            pd = import_pandas()
        except ImportError:
            return f"<pre>{self.to_table()}</pre>"

        n = len(self.array)
        max_rows = pd.get_option("display.max_rows")
        if max_rows is None:
            max_rows = 60

        if n <= max_rows:
            df = self.to_dataframe()
        else:
            half = max_rows // 2
            head_df = self.to_dataframe(head=half)
            tail_df = self.to_dataframe(tail=half)
            ellipsis_data = {col: ["\u22ee"] for col in self._view_columns}
            ellipsis_df = pd.DataFrame(ellipsis_data)
            df = pd.concat([head_df, ellipsis_df, tail_df], ignore_index=True)

        html = df.to_html(index=False, na_rep="NaN")
        return f"{html}\n<p>{n} rows \u00d7 {len(self._view_columns)} columns</p>"

    # -- Misc -------------------------------------------------------------------

    def copy(self) -> ArrayDisplay:
        """Create a shallow copy of this ArrayDisplay.

        The underlying array is shared (not copied), but all configuration
        state (view columns, name columns, field components, aliases) is
        independently mutable.

        Returns:
            A new ArrayDisplay with the same array reference and a copy
            of all configuration state.
        """
        new = ArrayDisplay.__new__(ArrayDisplay)
        new.array = self.array
        new.original_dtype = self.original_dtype
        new._view_columns = list(self._view_columns)
        new._name_columns = copy.deepcopy(self._name_columns)
        new._field_components = copy.deepcopy(self._field_components)
        new._column_aliases = dict(self._column_aliases)
        return new

    def __len__(self) -> int:
        """Return the number of rows in the array (0 if no array set)."""
        if self.array is None:
            return 0
        return len(self.array)

    def __repr__(self) -> str:
        n_rows = len(self)
        n_cols = len(self._view_columns)
        parts = [f"rows={n_rows}", f"cols={n_cols}"]
        if self._field_components:
            parts.append(f"flattened={len(self._field_components)}")
        if self._name_columns:
            parts.append(f"enums={len(self._name_columns)}")
        return f"ArrayDisplay({', '.join(parts)})"

    def __str__(self) -> str:
        parts = ["ArrayDisplay:"]

        if self.array is not None:
            parts.append(f"  Shape: {self.array.shape}")
            parts.append(f"  Dtype: {self.array.dtype}")
            parts.append(f"  View columns ({len(self._view_columns)}):")
            for col in self._view_columns[:10]:
                parts.append(f"    - {col}")
            if len(self._view_columns) > 10:
                parts.append(f"    ... and {len(self._view_columns) - 10} more")
        else:
            parts.append("  Array: None")

        if self._field_components:
            parts.append(f"  Flattened fields: {len(self._field_components)}")
        if self._name_columns:
            parts.append(f"  Enum mappings: {len(self._name_columns)}")

        return "\n".join(parts)
