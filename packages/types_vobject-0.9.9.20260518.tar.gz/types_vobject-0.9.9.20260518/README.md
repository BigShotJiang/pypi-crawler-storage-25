## Typing stubs for vobject

This is a [type stub package](https://typing.python.org/en/latest/tutorials/external_libraries.html)
for the [`vobject`](https://github.com/py-vobject/vobject) package. It can be used by type checkers
to check code that uses `vobject`. This version of
`types-vobject` aims to provide accurate annotations for
`vobject~=0.9.9`.

This package is part of the [typeshed project](https://github.com/python/typeshed).
All fixes for types and metadata should be contributed there.
See [the README](https://github.com/python/typeshed/blob/main/README.md)
for more details. The source for this package can be found in the
[`stubs/vobject`](https://github.com/python/typeshed/tree/main/stubs/vobject)
directory.

This package was tested with the following type checkers:
* [mypy](https://github.com/python/mypy/) 2.1.0
* [pyright](https://github.com/microsoft/pyright) 1.1.409

It was generated from typeshed commit
[`3402466d17144ed7edfc92940c6973167ba285af`](https://github.com/python/typeshed/commit/3402466d17144ed7edfc92940c6973167ba285af).