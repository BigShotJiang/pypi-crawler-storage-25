# trustpact

Behavioral trust scanner for MCP servers and AI agents.

## Install

```bash
pip install trustpact
```

## Usage

```bash
# Scan a server from the Smithery registry
trustpact scan "slack"

# Scan a local server spec (JSON)
trustpact scan server.json

# JSON output for CI/CD integration
trustpact scan server.json --json

# Show AEGIS scoring methodology
trustpact info
```

## What It Does

TrustPact scans MCP server tool definitions for manipulation patterns and calculates a behavioral trust score using the AEGIS 5-dimensional model:

- **Trust Signals (35%)** — metadata, documentation, authentication
- **Manipulation Risk (25%)** — hidden instructions, poisoning patterns
- **Protection Level (15%)** — auth, scope, licensing
- **Vulnerability Index (15%)** — critical exposure surface
- **Context Modifier (10%)** — runtime context signals

### Attack Classes Detected

| Class | Description |
|-------|-------------|
| SIREN | Hidden instruction injection |
| PHANTOM | Identity spoofing |
| HYDRA | Coordinated Sybil attacks |
| MIRAGE | Capability misrepresentation |
| LEECH | Data/credential exfiltration |
| CHIMERA | Code injection, safety bypass |

### Trust Tiers

| Tier | Score | Meaning |
|------|-------|---------|
| SOVEREIGN | 95+ | Highest trust |
| SENTINEL | 85+ | Proven track record |
| MASTER | 65+ | Reliable |
| ADEPT | 40+ | Limited history |
| FELLOW | 0+ | New or unverified |

## License

Proprietary — ARQON GmbH (i.G.)

## Links

- [trustpact.ai](https://trustpact.ai)
- Patent Provisional 63/928,604
