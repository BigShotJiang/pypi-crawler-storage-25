"""
AEGIS Trust Scanner — core analysis engine.

Scans MCP server tool definitions and metadata for:
- Tool poisoning patterns (hidden instructions in descriptions)
- Schema manipulation (Full-Schema Poisoning)
- Capability misrepresentation (MIRAGE)
- Identity spoofing indicators (PHANTOM)
- Resource extraction patterns (LEECH)
- Sybil/coordination signals (HYDRA)
"""

from __future__ import annotations

import re
import json
from dataclasses import dataclass, field
from typing import Any


# ── Threat patterns ──────────────────────────────────────────

POISONING_PATTERNS = [
    # Hidden instructions in tool descriptions
    (r"(?i)ignore\s+(previous|prior|above|all)\s+(instructions?|prompts?|rules?)", "SIREN", "HIGH",
     "Hidden instruction override detected in tool description"),
    (r"(?i)you\s+(must|should|are required to)\s+", "SIREN", "MEDIUM",
     "Directive language in tool description — potential manipulation"),
    (r"(?i)do\s+not\s+(tell|inform|reveal|mention|disclose)", "SIREN", "HIGH",
     "Secrecy instruction detected — likely tool poisoning"),
    (r"(?i)system\s*prompt|system\s*message|<\s*system\s*>", "SIREN", "HIGH",
     "System prompt injection attempt in tool description"),
    (r"(?i)act\s+as\s+(if|though)?|pretend\s+(to\s+be|you)", "PHANTOM", "HIGH",
     "Identity manipulation — tool tries to alter agent persona"),
    (r"(?i)forward\s+.*(token|key|credential|password|secret)", "LEECH", "CRITICAL",
     "Credential exfiltration attempt detected"),
    (r"(?i)send\s+.*(data|info|content)\s+to\s+", "LEECH", "HIGH",
     "Data exfiltration pattern — tool may leak information"),
    (r"(?i)(http|https|ftp)://[^\s\"']+\.(ru|cn|tk|xyz)/", "LEECH", "MEDIUM",
     "Suspicious external URL in tool description"),
    (r"(?i)base64|eval\s*\(|exec\s*\(|__import__", "CHIMERA", "HIGH",
     "Code execution pattern in tool description"),
    (r"(?i)(override|bypass|disable)\s+(safety|security|filter|guard|restriction|protection|limit)", "CHIMERA", "CRITICAL",
     "Safety bypass attempt detected"),
]

SCHEMA_RISKS = [
    # Schema-level manipulation (Full-Schema Poisoning)
    # Note: only match param NAMES that are inherently sensitive, not benign names
    # that happen to contain substrings like "token" (e.g. pageToken, nextToken)
    (r"(?i)^(password|api_?key|secret_?key|credential|private_?key|access_?token|auth_?token|bearer_?token)$", "LEECH", "HIGH",
     "Tool parameter requests sensitive credentials"),
    (r"(?i)^(webhook_?url|callback_?url|redirect_?uri|notify_?url|exfil)$", "LEECH", "MEDIUM",
     "Tool accepts external callback URL — potential data exfiltration channel"),
    (r"(?i)^(shell_?command|exec_?command|eval_?code|run_?script|execute|shell|eval_?expr)$", "CHIMERA", "HIGH",
     "Tool parameter suggests arbitrary code execution"),
]

METADATA_RISKS = [
    # Server-level signals
    ("no_readme", "MIRAGE", "LOW", "No README or documentation — reduced transparency"),
    ("no_license", "MIRAGE", "LOW", "No license specified — unclear usage terms"),
    ("no_auth", "LEECH", "LOW", "No authentication required — open access server"),
    ("excessive_tools", "MIRAGE", "MEDIUM", "Unusually high number of tools — possible capability inflation"),
    ("stale_repo", "MIRAGE", "LOW", "Repository not updated in 90+ days"),
]


@dataclass
class Finding:
    """A single security finding from the scan."""
    attack_class: str  # SIREN, PHANTOM, HYDRA, MIRAGE, LEECH, CHIMERA
    severity: str      # CRITICAL, HIGH, MEDIUM, LOW
    message: str
    location: str = ""  # where in the server spec this was found
    pattern: str = ""   # the matched pattern


@dataclass
class DimensionScores:
    """AEGIS 5-dimensional trust breakdown."""
    trust_signals: float = 50.0
    manipulation_risk: float = 0.0   # 0 = no risk, 100 = extreme risk
    protection_level: float = 50.0
    vulnerability_index: float = 50.0  # 0 = not vulnerable, 100 = very vulnerable
    context_modifier: float = 0.0      # -10 to +10


@dataclass
class ScanResult:
    """Complete scan result for an MCP server or agent."""
    target: str
    trust_score: float = 50.0
    trust_tier: str = "FELLOW"
    dimensions: DimensionScores = field(default_factory=DimensionScores)
    findings: list[Finding] = field(default_factory=list)
    tools_scanned: int = 0
    recommendation: str = "UNKNOWN"
    scan_source: str = "static_analysis"

    @property
    def critical_count(self) -> int:
        return sum(1 for f in self.findings if f.severity == "CRITICAL")

    @property
    def high_count(self) -> int:
        return sum(1 for f in self.findings if f.severity == "HIGH")


def _score_to_tier(score: float) -> str:
    if score >= 95:
        return "SOVEREIGN"
    if score >= 85:
        return "SENTINEL"
    if score >= 65:
        return "MASTER"
    if score >= 40:
        return "ADEPT"
    return "FELLOW"


def scan_tool_descriptions(tools: list[dict[str, Any]]) -> list[Finding]:
    """Scan tool descriptions for poisoning patterns."""
    findings = []
    for tool in tools:
        name = tool.get("name", "unknown")
        desc = tool.get("description", "")

        for pattern, attack_class, severity, message in POISONING_PATTERNS:
            if re.search(pattern, desc):
                findings.append(Finding(
                    attack_class=attack_class,
                    severity=severity,
                    message=message,
                    location=f"tool:{name}/description",
                    pattern=pattern,
                ))

        # Check input schema for sensitive parameter names
        # Match against param name only (not description) to avoid false positives
        schema = tool.get("inputSchema", tool.get("input_schema", {}))
        props = schema.get("properties", {})
        for param_name, param_def in props.items():
            for pattern, attack_class, severity, message in SCHEMA_RISKS:
                if re.search(pattern, param_name):
                    findings.append(Finding(
                        attack_class=attack_class,
                        severity=severity,
                        message=message,
                        location=f"tool:{name}/param:{param_name}",
                        pattern=pattern,
                    ))

            # Also check param descriptions for HIGH-confidence poisoning only
            # Param descriptions are less exploitable than tool descriptions,
            # so only flag the most dangerous patterns (instruction override, secrecy, exfil)
            param_desc = param_def.get("description", "")
            if param_desc:
                PARAM_DESC_PATTERNS = [
                    POISONING_PATTERNS[0],  # ignore previous instructions
                    POISONING_PATTERNS[2],  # do not tell/reveal
                    POISONING_PATTERNS[3],  # system prompt injection
                    POISONING_PATTERNS[5],  # forward credentials
                    POISONING_PATTERNS[6],  # send data to
                ]
                for pattern, attack_class, severity, msg in PARAM_DESC_PATTERNS:
                    if re.search(pattern, param_desc):
                        findings.append(Finding(
                            attack_class=attack_class,
                            severity=severity,
                            message=f"Param description: {msg}",
                            location=f"tool:{name}/param:{param_name}",
                            pattern=pattern,
                        ))

    return findings


def scan_metadata(metadata: dict[str, Any]) -> list[Finding]:
    """Scan server metadata for risk signals."""
    findings = []

    if not metadata.get("readme") and not metadata.get("description"):
        findings.append(Finding("MIRAGE", "LOW",
            "No README or documentation — reduced transparency",
            location="server/metadata"))

    if not metadata.get("license"):
        findings.append(Finding("MIRAGE", "LOW",
            "No license specified — unclear usage terms",
            location="server/metadata"))

    tool_count = metadata.get("tool_count", 0)
    if tool_count > 25:
        findings.append(Finding("MIRAGE", "MEDIUM",
            f"Unusually high number of tools ({tool_count}) — possible capability inflation",
            location="server/metadata"))

    if not metadata.get("authentication"):
        findings.append(Finding("LEECH", "LOW",
            "No authentication documented",
            location="server/metadata"))

    return findings


def calculate_score(findings: list[Finding], tools: list[dict], metadata: dict) -> ScanResult:
    """Calculate AEGIS trust score from scan findings."""

    # Start with base scores
    dims = DimensionScores()

    # ── Trust Signals (35%) ──
    # Based on metadata quality
    # When source is a registry, some fields may simply not be exposed
    # Treat missing-but-not-applicable fields as neutral
    source = metadata.get("source", "")
    is_registry = source in ("smithery", "mcp.run")

    has_readme = bool(metadata.get("readme") or metadata.get("description"))
    has_license = bool(metadata.get("license"))
    has_repo = bool(metadata.get("repository"))
    has_auth = bool(metadata.get("authentication"))

    signal_score = 30.0  # base
    if has_readme:
        signal_score += 20
    if has_license:
        signal_score += 15
    elif is_registry:
        signal_score += 8  # neutral — registry doesn't expose this
    if has_repo:
        signal_score += 20
    if has_auth:
        signal_score += 15
    elif is_registry:
        signal_score += 8  # neutral — registry doesn't expose this
    dims.trust_signals = min(100, signal_score)

    # ── Manipulation Risk (25%) ──
    severity_weights = {"CRITICAL": 30, "HIGH": 15, "MEDIUM": 5, "LOW": 2}
    risk_score = 0
    for f in findings:
        risk_score += severity_weights.get(f.severity, 0)
    dims.manipulation_risk = min(100, risk_score)

    # ── Protection Level (15%) ──
    protection = 40.0  # base
    if has_auth:
        protection += 30
    tool_count = len(tools)
    if 1 <= tool_count <= 15:
        protection += 20  # reasonable scope
    if has_license:
        protection += 10
    dims.protection_level = min(100, protection)

    # ── Vulnerability Index (15%) ──
    vuln = 20.0  # base vulnerability
    critical_findings = sum(1 for f in findings if f.severity == "CRITICAL")
    high_findings = sum(1 for f in findings if f.severity == "HIGH")
    vuln += critical_findings * 25
    vuln += high_findings * 10
    if not has_auth:
        vuln += 10
    dims.vulnerability_index = min(100, vuln)

    # ── Context Modifier (10%) ──
    dims.context_modifier = 0  # neutral for static analysis

    # ── Overall Score ──
    # Higher trust_signals and protection = better
    # Higher manipulation_risk and vulnerability = worse
    overall = (
        dims.trust_signals * 0.35
        + (100 - dims.manipulation_risk) * 0.25
        + dims.protection_level * 0.15
        + (100 - dims.vulnerability_index) * 0.15
        + (50 + dims.context_modifier * 5) * 0.10
    )
    overall = max(0, min(100, overall))

    tier = _score_to_tier(overall)

    # Recommendation
    if overall >= 70 and critical_findings == 0:
        recommendation = "SAFE"
    elif overall >= 40 and critical_findings == 0:
        recommendation = "CAUTION"
    else:
        recommendation = "AVOID"

    return ScanResult(
        target=metadata.get("name", "unknown"),
        trust_score=round(overall, 1),
        trust_tier=tier,
        dimensions=dims,
        findings=findings,
        tools_scanned=len(tools),
        recommendation=recommendation,
    )


def scan_server(tools: list[dict[str, Any]], metadata: dict[str, Any]) -> ScanResult:
    """Full scan pipeline: analyze tools + metadata, calculate score."""
    findings = []
    findings.extend(scan_tool_descriptions(tools))
    findings.extend(scan_metadata(metadata))
    return calculate_score(findings, tools, metadata)
