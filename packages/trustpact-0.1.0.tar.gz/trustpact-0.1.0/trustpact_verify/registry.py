"""
MCP Registry fetcher — pull server specs from public registries.

Supports:
- Local JSON spec files
- mcp.run package registry (public API)
- Smithery registry (smithery.ai)
- Raw GitHub manifest files
"""

from __future__ import annotations

import json
import re
from typing import Any

import httpx

TIMEOUT = 15.0

# ── Registry endpoints ─────────────────────────────────────────

MCP_RUN_API = "https://registry.mcp.run/packages"
SMITHERY_API = "https://registry.smithery.ai/servers"


def fetch_server_spec(name_or_url: str) -> dict[str, Any] | None:
    """
    Fetch an MCP server spec by name or URL.

    Tries in order:
    1. Direct URL (if it looks like a URL)
    2. Smithery registry
    3. mcp.run registry
    """
    if name_or_url.startswith("http://") or name_or_url.startswith("https://"):
        return _fetch_url(name_or_url)

    # Try Smithery first (has richer tool definitions)
    spec = _fetch_smithery(name_or_url)
    if spec:
        return spec

    # Try mcp.run
    spec = _fetch_mcp_run(name_or_url)
    if spec:
        return spec

    return None


def _fetch_url(url: str) -> dict[str, Any] | None:
    """Fetch a spec from a direct URL."""
    try:
        resp = httpx.get(url, timeout=TIMEOUT, follow_redirects=True)
        resp.raise_for_status()
        return resp.json()
    except Exception:
        return None


def _fetch_smithery(name: str) -> dict[str, Any] | None:
    """
    Fetch from Smithery registry.
    API: GET /servers?q=<name>
    """
    try:
        resp = httpx.get(
            SMITHERY_API,
            params={"q": name, "pageSize": 5},
            timeout=TIMEOUT,
            follow_redirects=True,
        )
        resp.raise_for_status()
        data = resp.json()

        servers = data.get("servers", data) if isinstance(data, dict) else data
        if not isinstance(servers, list) or not servers:
            return None

        # Find exact or best match
        server = None
        for s in servers:
            s_name = s.get("qualifiedName", s.get("name", ""))
            if s_name.lower() == name.lower() or name.lower() in s_name.lower():
                server = s
                break
        if not server:
            server = servers[0]

        # Normalize to our format
        tools = server.get("tools", [])
        metadata = {
            "name": server.get("qualifiedName", server.get("name", name)),
            "description": server.get("description", ""),
            "repository": server.get("homepage", server.get("repository", "")),
            "license": server.get("license", ""),
            "tool_count": len(tools),
            "source": "smithery",
        }

        # If tools aren't inline, try fetching detail endpoint
        if not tools:
            detail = _fetch_smithery_detail(server.get("qualifiedName", name))
            if detail:
                tools = detail.get("tools", [])
                metadata["tool_count"] = len(tools)

        return {"tools": tools, "metadata": metadata}

    except Exception:
        return None


def _fetch_smithery_detail(qualified_name: str) -> dict | None:
    """Fetch detailed server info from Smithery."""
    try:
        resp = httpx.get(
            f"{SMITHERY_API}/{qualified_name}",
            timeout=TIMEOUT,
            follow_redirects=True,
        )
        resp.raise_for_status()
        return resp.json()
    except Exception:
        return None


def _fetch_mcp_run(name: str) -> dict[str, Any] | None:
    """
    Fetch from mcp.run registry.
    """
    try:
        resp = httpx.get(
            MCP_RUN_API,
            params={"q": name},
            timeout=TIMEOUT,
            follow_redirects=True,
        )
        resp.raise_for_status()
        data = resp.json()

        packages = data if isinstance(data, list) else data.get("packages", [])
        if not packages:
            return None

        # Best match
        pkg = None
        for p in packages:
            p_name = p.get("name", "")
            if p_name.lower() == name.lower() or name.lower() in p_name.lower():
                pkg = p
                break
        if not pkg:
            pkg = packages[0]

        tools = pkg.get("tools", [])
        metadata = {
            "name": pkg.get("name", name),
            "description": pkg.get("description", ""),
            "repository": pkg.get("repository", pkg.get("homepage", "")),
            "license": pkg.get("license", ""),
            "tool_count": len(tools),
            "source": "mcp.run",
        }

        return {"tools": tools, "metadata": metadata}

    except Exception:
        return None


def search_registry(query: str, limit: int = 20) -> list[dict[str, Any]]:
    """
    Search registries and return a list of server summaries.
    """
    results = []

    # Smithery
    try:
        resp = httpx.get(
            SMITHERY_API,
            params={"q": query, "pageSize": min(limit, 50)},
            timeout=TIMEOUT,
            follow_redirects=True,
        )
        resp.raise_for_status()
        data = resp.json()
        servers = data.get("servers", data) if isinstance(data, dict) else data
        if isinstance(servers, list):
            for s in servers[:limit]:
                results.append({
                    "name": s.get("qualifiedName", s.get("name", "?")),
                    "description": s.get("description", "")[:100],
                    "tools": len(s.get("tools", [])),
                    "source": "smithery",
                })
    except Exception:
        pass

    return results[:limit]
