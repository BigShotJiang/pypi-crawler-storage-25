"""TrustPact — Behavioral trust scanner for MCP servers and AI agents."""

__version__ = "0.1.0"
