"""
trustpact verify — CLI entry point.

Usage:
    trustpact scan <name_or_url>    Scan an MCP server for trust issues
    trustpact info                  Show AEGIS scoring methodology
    trustpact version               Show version
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich import box

from trustpact_verify import __version__
from trustpact_verify.scanner import (
    scan_server,
    scan_tool_descriptions,
    scan_metadata,
    ScanResult,
    Finding,
)

console = Console()


# ── Colours & symbols ──────────────────────────────────────────

TIER_STYLES = {
    "SOVEREIGN": ("bold bright_green", "★★★★★"),
    "SENTINEL":  ("bold green",        "★★★★☆"),
    "MASTER":    ("bold yellow",       "★★★☆☆"),
    "ADEPT":     ("bold bright_red",   "★★☆☆☆"),
    "FELLOW":    ("bold red",          "★☆☆☆☆"),
}

SEVERITY_STYLES = {
    "CRITICAL": "bold white on red",
    "HIGH":     "bold red",
    "MEDIUM":   "yellow",
    "LOW":      "dim",
}

REC_STYLES = {
    "SAFE":    ("bold bright_green", "✓ SAFE — Low risk, reasonable to use"),
    "CAUTION": ("bold yellow",       "⚠ CAUTION — Review findings before use"),
    "AVOID":   ("bold red",          "✗ AVOID — Significant trust concerns"),
}


def _render_header():
    console.print()
    console.print(
        Panel(
            "[bold bright_cyan]TrustPact[/] verify  ·  AEGIS Trust Scanner",
            subtitle=f"v{__version__}",
            style="bright_cyan",
            width=64,
        )
    )


def _render_score(result: ScanResult):
    """Render the trust score gauge."""
    tier_style, stars = TIER_STYLES.get(result.trust_tier, ("white", "?"))

    score_text = Text()
    score_text.append(f"  Trust Score: ", style="bold")
    score_text.append(f"{result.trust_score:.1f}", style=tier_style)
    score_text.append(f" / 100", style="dim")
    score_text.append(f"  {stars}", style=tier_style)
    console.print(score_text)

    tier_text = Text()
    tier_text.append(f"  Trust Tier:  ", style="bold")
    tier_text.append(result.trust_tier, style=tier_style)
    console.print(tier_text)
    console.print()


def _render_dimensions(result: ScanResult):
    """Render the 5-dimensional breakdown."""
    dims = result.dimensions
    table = Table(
        title="AEGIS Dimensions",
        box=box.ROUNDED,
        title_style="bold bright_cyan",
        width=64,
    )
    table.add_column("Dimension", style="bold", width=22)
    table.add_column("Value", justify="right", width=10)
    table.add_column("Bar", width=26)

    rows = [
        ("Trust Signals",      dims.trust_signals,       False),
        ("Manipulation Risk",  dims.manipulation_risk,   True),
        ("Protection Level",   dims.protection_level,    False),
        ("Vulnerability Index", dims.vulnerability_index, True),
        ("Context Modifier",   dims.context_modifier,    None),
    ]

    for name, value, invert in rows:
        if invert is None:
            # context modifier is -10 to +10
            bar = f"{'▓' * max(0, int(value + 10))}{'░' * max(0, 20 - int(value + 10))}"
            style = "yellow" if abs(value) < 3 else ("green" if value > 0 else "red")
            table.add_row(name, f"{value:+.1f}", Text(bar, style=style))
        else:
            filled = int(value / 5)  # 0-20 blocks
            bar = "▓" * filled + "░" * (20 - filled)
            if invert:
                style = "bright_green" if value < 30 else ("yellow" if value < 60 else "red")
            else:
                style = "red" if value < 30 else ("yellow" if value < 60 else "bright_green")
            table.add_row(name, f"{value:.1f}", Text(bar, style=style))

    console.print(table)


def _render_findings(findings: list[Finding]):
    """Render findings table."""
    if not findings:
        console.print("  [bright_green]No issues detected.[/]")
        console.print()
        return

    table = Table(
        title=f"Findings ({len(findings)})",
        box=box.ROUNDED,
        title_style="bold yellow",
        width=80,
        show_lines=True,
    )
    table.add_column("Sev", width=8, justify="center")
    table.add_column("Class", width=9)
    table.add_column("Message", width=42)
    table.add_column("Location", width=16, style="dim")

    # Sort: CRITICAL first, then HIGH, MEDIUM, LOW
    severity_order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}
    sorted_findings = sorted(findings, key=lambda f: severity_order.get(f.severity, 9))

    for f in sorted_findings:
        sev_style = SEVERITY_STYLES.get(f.severity, "white")
        table.add_row(
            Text(f.severity, style=sev_style),
            Text(f.attack_class, style="bold"),
            f.message,
            f.location[:16] if f.location else "",
        )

    console.print(table)


def _render_recommendation(result: ScanResult):
    """Render the final recommendation."""
    rec_style, rec_text = REC_STYLES.get(
        result.recommendation, ("white", "? UNKNOWN")
    )
    console.print(
        Panel(
            f"[{rec_style}]{rec_text}[/]",
            title="Recommendation",
            style=rec_style.split()[0] if " " in rec_style else rec_style,
            width=64,
        )
    )

    # Summary line
    console.print(
        f"  [dim]Scanned {result.tools_scanned} tool(s) · "
        f"{result.critical_count} critical · {result.high_count} high · "
        f"Source: {result.scan_source}[/]"
    )
    console.print()


def render_scan_result(result: ScanResult):
    """Full formatted output for a scan result."""
    _render_header()
    console.print(f"  [bold]Target:[/] {result.target}")
    console.print()
    _render_score(result)
    _render_dimensions(result)
    console.print()
    _render_findings(result.findings)
    console.print()
    _render_recommendation(result)


# ── Commands ───────────────────────────────────────────────────

def cmd_scan(args):
    """Scan a server from a JSON spec file or registry name."""
    target = args.target

    # Try as local JSON file first
    path = Path(target)
    if path.exists() and path.suffix == ".json":
        try:
            data = json.loads(path.read_text())
        except json.JSONDecodeError as e:
            console.print(f"[red]Error parsing {target}: {e}[/]")
            sys.exit(1)

        tools = data.get("tools", [])
        metadata = data.get("metadata", data.get("server", {}))
        if not metadata.get("name"):
            metadata["name"] = path.stem

        result = scan_server(tools, metadata)
        if args.json_output:
            _output_json(result)
        else:
            render_scan_result(result)
        return

    # Try fetching from MCP registry
    try:
        from trustpact_verify.registry import fetch_server_spec
        console.print(f"  [dim]Fetching server spec for '{target}' from registry...[/]")
        spec = fetch_server_spec(target)
        if spec is None:
            console.print(f"[red]Server '{target}' not found in registry.[/]")
            console.print("[dim]Try: trustpact scan <path-to-spec.json>[/]")
            sys.exit(1)

        tools = spec.get("tools", [])
        metadata = spec.get("metadata", {})
        metadata["name"] = metadata.get("name", target)

        result = scan_server(tools, metadata)
        if args.json_output:
            _output_json(result)
        else:
            render_scan_result(result)
    except ImportError:
        console.print(f"[yellow]Registry module not available.[/]")
        console.print(f"[dim]Provide a local JSON spec: trustpact scan server.json[/]")
        sys.exit(1)
    except Exception as e:
        console.print(f"[red]Error fetching '{target}': {e}[/]")
        sys.exit(1)


def cmd_scan_json(args):
    """Scan from piped JSON input (stdin)."""
    try:
        data = json.load(sys.stdin)
    except json.JSONDecodeError as e:
        console.print(f"[red]Invalid JSON input: {e}[/]")
        sys.exit(1)

    tools = data.get("tools", [])
    metadata = data.get("metadata", data.get("server", {}))
    if not metadata.get("name"):
        metadata["name"] = "stdin"

    result = scan_server(tools, metadata)

    if args.json_output:
        _output_json(result)
    else:
        render_scan_result(result)


def _output_json(result: ScanResult):
    """Output scan result as JSON."""
    output = {
        "target": result.target,
        "trust_score": result.trust_score,
        "trust_tier": result.trust_tier,
        "recommendation": result.recommendation,
        "dimensions": {
            "trust_signals": result.dimensions.trust_signals,
            "manipulation_risk": result.dimensions.manipulation_risk,
            "protection_level": result.dimensions.protection_level,
            "vulnerability_index": result.dimensions.vulnerability_index,
            "context_modifier": result.dimensions.context_modifier,
        },
        "findings": [
            {
                "severity": f.severity,
                "attack_class": f.attack_class,
                "message": f.message,
                "location": f.location,
            }
            for f in result.findings
        ],
        "tools_scanned": result.tools_scanned,
        "scan_source": result.scan_source,
    }
    print(json.dumps(output, indent=2))


def cmd_info(_args):
    """Show AEGIS scoring info."""
    _render_header()

    console.print()
    console.print("  [bold]AEGIS Trust Scoring[/] — 5-dimensional behavioral trust assessment")
    console.print()

    # Tier table
    table = Table(title="Trust Tiers", box=box.ROUNDED, width=60)
    table.add_column("Tier", width=12)
    table.add_column("Score", width=8, justify="center")
    table.add_column("Meaning", width=35)

    tiers = [
        ("SOVEREIGN", "95+", "Highest trust. Fully certified."),
        ("SENTINEL",  "85+", "Proven track record."),
        ("MASTER",    "65+", "Reliable with strong history."),
        ("ADEPT",     "40+", "Functional, limited history."),
        ("FELLOW",    "0+",  "New or unverified."),
    ]
    for tier, score, meaning in tiers:
        style, stars = TIER_STYLES[tier]
        table.add_row(Text(f"{stars} {tier}", style=style), score, meaning)
    console.print(table)

    console.print()
    console.print("  [bold]Dimensions:[/]")
    console.print("    Trust Signals (35%)       — metadata, docs, auth")
    console.print("    Manipulation Risk (25%)   — poisoning patterns detected")
    console.print("    Protection Level (15%)    — auth, scope, licensing")
    console.print("    Vulnerability Index (15%) — critical exposure surface")
    console.print("    Context Modifier (10%)    — runtime context signals")
    console.print()

    console.print("  [bold]Attack Classes:[/]")
    classes = [
        ("SIREN",   "Emotional manipulation / hidden instructions"),
        ("PHANTOM", "Identity spoofing"),
        ("HYDRA",   "Coordinated Sybil attacks"),
        ("MIRAGE",  "Capability misrepresentation"),
        ("LEECH",   "Resource / data extraction"),
        ("CHIMERA", "Context-shifting / code injection"),
    ]
    for cls, desc in classes:
        console.print(f"    [bold]{cls:8s}[/] {desc}")
    console.print()

    console.print("  [dim]trustpact.ai · AEGIS Trust Standard · Patent Provisional 63/928,604[/]")
    console.print()


def cmd_version(_args):
    print(f"trustpact {__version__}")


# ── Main ───────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        prog="trustpact",
        description="TrustPact — Behavioral trust scanner for MCP servers",
    )
    sub = parser.add_subparsers(dest="command")

    # scan
    p_scan = sub.add_parser("scan", help="Scan an MCP server spec")
    p_scan.add_argument("target", help="JSON spec file path or registry server name")
    p_scan.add_argument("--json", dest="json_output", action="store_true",
                        help="Output results as JSON")

    # scan-stdin (for piping)
    p_stdin = sub.add_parser("scan-stdin", help="Scan from piped JSON on stdin")
    p_stdin.add_argument("--json", dest="json_output", action="store_true")

    # info
    sub.add_parser("info", help="Show AEGIS scoring methodology")

    # version
    sub.add_parser("version", help="Show version")

    args = parser.parse_args()

    commands = {
        "scan": cmd_scan,
        "scan-stdin": cmd_scan_json,
        "info": cmd_info,
        "version": cmd_version,
    }

    if args.command not in commands:
        parser.print_help()
        sys.exit(0)

    commands[args.command](args)


if __name__ == "__main__":
    main()
