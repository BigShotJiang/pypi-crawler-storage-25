import os
import shutil
import sys
from pathlib import Path

# By default use the `example` directory that contains this package.
# This avoids hardcoding user-specific paths and ensures the package copies
# the example folder located next to the `dajanga2` package.
DEFAULT_EXAMPLE = Path(__file__).resolve().parent.parent


def copy_merge(src: Path, dst: Path, overwrite: bool = True):
    src = Path(src)
    dst = Path(dst)
    if not src.exists():
        raise FileNotFoundError(f"Source not found: {src}")

    for root, dirs, files in os.walk(src):
        rel = Path(root).relative_to(src)
        target_dir = dst.joinpath(rel)
        target_dir.mkdir(parents=True, exist_ok=True)
        for d in dirs:
            (target_dir / d).mkdir(parents=True, exist_ok=True)
        for f in files:
            sfile = Path(root) / f
            tfile = target_dir / f
            if tfile.exists() and overwrite:
                if tfile.is_dir():
                    shutil.rmtree(tfile)
                else:
                    tfile.unlink()
            shutil.copy2(sfile, tfile)


def main(argv=None):
    argv = argv or sys.argv[1:]
    # Allow override via envvar or CLI arg
    src = os.environ.get("DAJANGA_EXAMPLE_PATH", DEFAULT_EXAMPLE)
    if len(argv) >= 1:
        src = argv[0]

    src_path = Path(src).resolve()
    dst_path = Path(os.getcwd()).resolve()

    print(f"Source: {src_path}")
    print(f"Destination: {dst_path}")

    try:
        copy_merge(src_path, dst_path, overwrite=True)
    except Exception as e:
        print(f"Error copying example site: {e}", file=sys.stderr)
        return 2

    print("Example site copied successfully.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
