# {{ cookiecutter.project_name }} — Documentation

This project follows the **mgf-common golden-standard layout**
(formalized in `mgf-common` v0.25.0):

- `audience/` — reading lists by persona (navigation only).
- `standards/` — project-specific exceptions to the canonical
  `mgf-common` standards corpus. The default is **inherit**;
  document only the deltas in `standards/PROJECT_OVERLAY.md`.
- `recipes/` — project-specific how-to.
- `reference/` — project-specific API reference.
- `design/` — project design papers / ADRs.
- `qa/` — test coverage map.
- `release/` — release engineering runbook.

## Audience routing

| If you are… | Read |
|---|---|
| Evaluating {{ cookiecutter.project_name }} | [`audience/shoppers.md`](audience/shoppers.md) |
| Building with it | [`audience/users.md`](audience/users.md) |
| Contributing | [`audience/developers.md`](audience/developers.md) |
| QA / test engineer | [`audience/qa.md`](audience/qa.md) |
| Cutting releases | [`audience/release.md`](audience/release.md) |
| Doing security review | [`audience/security.md`](audience/security.md) |
| AI agent | [`audience/ai-agents.md`](audience/ai-agents.md) |

## Inheriting from mgf-common

Engineering rules (TS-* / EH-* / CF-* / LG-* / SC-* / AP-* /
DP-* / REL-* / WF-*) are inherited from `mgf-common`'s
`docs/standards/`. Read them via:

```bash
mgf-common standards <topic>
```

…or directly at the
[mgf-common repository](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/).

This project's project-specific exceptions live in
[`standards/PROJECT_OVERLAY.md`](standards/PROJECT_OVERLAY.md).
The default if it's empty: full inheritance.

## Per-release migration

Each release ships a cutover guide at `docs/cutover/v<X.Y.Z>.md`
following the
[REL-09](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/RELEASING.md)
pattern. Last 3 minor versions live; older versions in
`cutover/archive/`.

## Why this layout

See `mgf-common`'s
[v0.25.0 cutover guide](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/cutover/v0.25.0.md)
for the design rationale + the full audience-routing rationale.
