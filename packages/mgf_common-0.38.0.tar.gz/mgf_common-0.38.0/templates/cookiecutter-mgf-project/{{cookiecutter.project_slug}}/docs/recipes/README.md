# {{ cookiecutter.project_name }} — recipes

(Fill in project-specific recipes as the project grows. The
canonical pattern lives in mgf-common's
[`docs/recipes/`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/recipes/).)
