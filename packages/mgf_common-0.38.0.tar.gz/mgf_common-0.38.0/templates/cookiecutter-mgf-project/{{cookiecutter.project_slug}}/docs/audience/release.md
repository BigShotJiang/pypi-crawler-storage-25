# {{ cookiecutter.project_name }} — For release engineers

> **Who you are.** Cutting releases of {{ cookiecutter.project_name }}.

(Fill in: project-specific release runbook. The general flow
inherits from mgf-common's REL-* rules.)

For the canonical pattern, see
[mgf-common's release page](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/audience/release.md).
