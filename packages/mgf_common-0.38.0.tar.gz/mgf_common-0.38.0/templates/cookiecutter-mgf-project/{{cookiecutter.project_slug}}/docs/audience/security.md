# {{ cookiecutter.project_name }} — For security reviewers

> **Who you are.** Auditing {{ cookiecutter.project_name }}.

(Fill in: threat surfaces specific to this project. SC-* rules
inherited; project-specific deltas in
[`../standards/PROJECT_OVERLAY.md`](../standards/PROJECT_OVERLAY.md).)

For the canonical pattern, see
[mgf-common's security page](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/audience/security.md).
