# {{ cookiecutter.project_name }} — For QA / test engineers

> **Who you are.** Running, analysing, or extending the test
> suite.

(Fill in. The four-layer pyramid is inherited from mgf-common's
TS-19/20/21; coverage map at [`../qa/coverage.md`](../qa/coverage.md).)

For the canonical pattern, see
[mgf-common's qa page](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/audience/qa.md).
