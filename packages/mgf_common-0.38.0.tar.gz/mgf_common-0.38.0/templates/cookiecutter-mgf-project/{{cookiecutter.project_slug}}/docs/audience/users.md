# {{ cookiecutter.project_name }} — For users

> **Who you are.** You're building with {{ cookiecutter.project_name }}.

(Fill in: tutorial → recipes → reference → troubleshooting →
upgrades.)

For the canonical pattern, see
[mgf-common's users page](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/audience/users.md).
