# `docs/ops/` — operations recipes

**Per `DOC-02`** (additional bucket beyond the canonical six):
this directory holds **operations-side** documentation —
benchmarks, runbooks, performance numbers, the data an
operator (or maintainer at release time) needs that doesn't
fit reference / recipes / standards.

## What goes here

- **Benchmarks log** — release-over-release microbench numbers
  per the `DOCUMENTATION.md` §9.2 shape. Append a new dated
  section per release; never edit historical entries.
- **Runbooks** (future) — incident-response procedures linked
  from `event` names per the `EVENTS.md` "what to do" column.
- **Performance baselines** — the absolute numbers
  `PERFORMANCE_AND_CAPACITY.md` PC-05 baseline test pins.

## What does NOT go here

- **Consumer-facing how-tos** → `docs/recipes/`. An "ops"
  recipe in this bucket is for the *maintainer / SRE*
  operating mgf-common itself, not for consumers running their
  app on top.
- **Engineering rules** → `docs/standards/`. The rule "every
  budget needs a benchmark" lives in `TESTING.md` §8; the
  benchmark numbers themselves live here.

## Index

| File | One-line description |
|---|---|
| `benchmarks.md` | Microbench numbers from `mgf-common bench`, per release. Append-only history. |
