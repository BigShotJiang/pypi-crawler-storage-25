# Cutover guide archive

Older cutover guides — historical record, not active migration
guidance. Per the **last-3-minor-versions live** policy
(formalized in v0.25.0), guides ≥ 3 minor versions behind the
current release move here.

The current live cutover guides live one directory up at
[`docs/cutover/`](../).

## Archive contents

| Release | Closures | Cutover guide |
|---|---|---|
| v0.18.0 | HTTP-01, CONFIG-01, LOG-01, LOG-02, PAPER-21, ASPIRE-02 | [`v0.18.0.md`](v0.18.0.md) |
| v0.19.0 | PAPER-22, PAPER-23, PAPER-24, BOOTSTRAP-01 | [`v0.19.0.md`](v0.19.0.md) |
| v0.20.0 | PAPER-25, ASPIRE-03, ASPIRE-04 | [`v0.20.0.md`](v0.20.0.md) |
| v0.21.0 | (feature addition: `mgf.common.process`) | [`v0.21.0.md`](v0.21.0.md) |

Older releases (v0.13.0–v0.17.x) predate the cutover-guide
pattern (REL-09 was codified in v0.17.x). Their migration
content lives in [`../../../CHANGELOG.md`](../../../CHANGELOG.md)
entries.

## Archived guides are read-only

Once a guide is archived, its content reflects the state-of-
the-world at release time. Path references inside an archived
guide may point at locations that have moved (e.g., the v0.25.0
docs reorg). The active migration record is the v0.25.0
cutover guide's path-mapping table; archived guides preserve
the original wording for historical accuracy.
