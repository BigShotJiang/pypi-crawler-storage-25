# Cross-project notification — Standards v2.8

> **Audience:** every Magogi project maintainer + every AI agent
> driving a consumer-side session.
> **TL;DR:** three new disciplines added to `DOCUMENTATION.md`,
> ships in mgf-common 0.35.0:
>
> 1. **FEEDBACK.md is now universal-five** (DOC-01 amendment +
>    new DOC-13 + FB-01..FB-04). Every project — cornerstone,
>    sibling, consumer — ships its own. Sibling-scoped, no
>    inheritance escape.
> 2. **`MGF_ADOPTION.md` MUST exist** for every consumer (new
>    DOC-14 + ADP-01..ADP-04). Federation siblings exempt per
>    ADP-04 carve-out.
> 3. **`MGF_STANDARDS_CONFORMANCE.md` MUST exist** for every
>    project that adopts the standards (new DOC-15 +
>    CFM-01..CFM-04) — consumers AND siblings.

---

## What changed

### Bundle 1 — FEEDBACK discipline (DOC-13 + FB-01..04)

- **DOC-01 amendment**: `FEEDBACK.md` promoted from
  library-only-MUST to **universal-five MUST**. The new
  universal five: `README.md`, `LICENSE`, `CHANGELOG.md`,
  `SECURITY.md`, **`FEEDBACK.md`**.
- **DOC-13**: FEEDBACK is sibling-scoped. A sibling-specific
  paper goes in the sibling's own FEEDBACK.md; federation-wide
  papers go in mgf-common/FEEDBACK.md. Misfiled papers get
  MOVED with a redirect stub.
- **FB-01..FB-04**: numbering local-per-repo; mandatory
  metadata fields (Status / Submitter / Submitted /
  Severity / Shipped-in); consumer filing discipline (the
  inthewords PAPER-36..42 misfile was the prompt).

### Bundle 2 — Adoption-tracker discipline (DOC-14 + ADP-01..04)

- **DOC-14**: every consumer project (depending on mgf-common
  or any sibling) MUST maintain `MGF_ADOPTION.md`.
- **ADP-01**: location is `docs/inprogress/MGF_ADOPTION.md`
  (recommended) or `docs/MGF_ADOPTION.md` (alternate).
- **ADP-02**: required sections (at-a-glance, strategic
  context, phase status, pin-bump history, FEEDBACK rounds,
  cross-references).
- **ADP-03**: update cadence — on every pin bump + every
  closed FEEDBACK paper.
- **ADP-04**: federation-sibling carve-out — siblings exempt
  (federation_roadmap + CHANGELOG cover their adoption story).

### Bundle 3 — Conformance-tracker discipline (DOC-15 + CFM-01..04)

- **DOC-15**: every project adopting mgf-common's standards
  MUST maintain `MGF_STANDARDS_CONFORMANCE.md` — applies to
  BOTH consumers and federation siblings.
- **CFM-01**: location is `docs/inprogress/MGF_STANDARDS_CONFORMANCE.md`.
- **CFM-02**: conformance levels L1 / L2 / L3 — declared in
  README; level definitions are at the top of the standards
  README.
- **CFM-03**: per-rule status markers (✅ / 🚫 / ⏳ / N/A);
  re-audit on every standards bump.
- **CFM-04**: decline-with-rationale per
  [principles/non-adoption-is-valid.md](../standards/principles/non-adoption-is-valid.md);
  "we just don't want to" is NOT acceptable — file a paper
  instead.

### Templates landed in `docs/recipes/`

Fork-and-fill templates for all three:

- [`docs/recipes/feedback-md-template.md`](../recipes/feedback-md-template.md)
- [`docs/recipes/mgf-adoption-md-template.md`](../recipes/mgf-adoption-md-template.md)
- [`docs/recipes/mgf-standards-conformance-md-template.md`](../recipes/mgf-standards-conformance-md-template.md)

### `mgf-common catch-up` auto-block extended

The auto-block in every consumer's `docs/CLAUDE.md` (managed by
`mgf-common catch-up --apply`) now carries THREE explicit
BEGIN/END marker pairs — one per discipline:

- `<!-- BEGIN mgf-common: feedback-discipline -->`
- `<!-- BEGIN mgf-common: adoption-discipline -->`
- `<!-- BEGIN mgf-common: conformance-discipline -->`

AI agents in consumer sessions see these reminders on every
session start. Maintainer no longer has to remind each
session — the discipline is encoded in-tree.

---

## Who this applies to

| Project shape | FEEDBACK.md | MGF_ADOPTION.md | MGF_STANDARDS_CONFORMANCE.md |
|---|---|---|---|
| **Cornerstone library** (`mgf-common`) | ✓ has it | N/A (it IS the library) | N/A (it IS the source of standards) |
| **Federation sibling** (`mgf-fastapi`, `mgf-http`, `mgf-sqlalchemy`, `mgf-alembic`, `mgf-django`, `mgf-apiprobe`, `mgf-website-template`) | ✓ NEW — created 2026-05-18 | ✗ ADP-04 carve-out | ✓ NEW — created 2026-05-18 (initial L2 audit) |
| **Consumer application** (VManager, PlasmaMapper, inthewords, iosRecovery, magogi-website, any future) | ✓ MUST exist (may redirect upstream for trivial cases) | ✓ MUST exist | ✓ MUST exist |

---

## Per-project action lists

### Cornerstone (mgf-common)

Already done as part of the 2026-05-18 v2.8 standards bump:
- DOC-01 amendment + DOC-13/14/15 + FB-01..04 + ADP-01..04 +
  CFM-01..04 in `docs/standards/DOCUMENTATION.md`.
- 3 templates in `docs/recipes/`.
- catch-up auto-block extended with 3 new BEGIN/END markers
  + unit test pinning them.
- 6 misfiled papers (PAPER-36/37/39/40/41/42) moved to
  appropriate sibling FEEDBACK.md with redirect stubs.

### Federation siblings

Already done as part of the 2026-05-18 bump:
- 7 sibling `FEEDBACK.md` files created (2 with content
  from misfiled papers, 5 empty-yet scaffolds).
- 7 sibling `docs/inprogress/MGF_STANDARDS_CONFORMANCE.md`
  files created (initial L2 audit; depth pass on first
  standards-bump trigger).

Per-sibling: when releasing the next minor, ensure these new
files ride along.

### Consumer applications (VManager, PlasmaMapper, inthewords, iosRecovery)

You receive the v2.8 disciplines on your NEXT
`mgf-common catch-up --apply` run. Specifically:

1. **`FEEDBACK.md`** — if you don't have one, create from
   [template](../recipes/feedback-md-template.md).
2. **`MGF_ADOPTION.md`** — if you don't have one, create at
   `docs/inprogress/MGF_ADOPTION.md` from
   [template](../recipes/mgf-adoption-md-template.md).
   - **inthewords** already has `docs/MGF_COMMON_ADOPTION.md`
     — keep the existing path or migrate to the recommended
     `docs/inprogress/MGF_ADOPTION.md` location.
   - **PlasmaMapper** already has
     `docs/inprogress/MGF_ADOPTION.md` — done; just ensure
     section structure matches ADP-02.
   - **VManager** + **iosRecovery** — create new file from
     template.
3. **`MGF_STANDARDS_CONFORMANCE.md`** — if you don't have one,
   create from
   [template](../recipes/mgf-standards-conformance-md-template.md).
   - **PlasmaMapper** already has this.
   - Others — create.

Update README to:
- Add a line declaring conformance level (L1 / L2 / L3 per
  CFM-02).
- Link to both trackers.

---

## Why this bump matters

The v2.8 bump closes a real misfile class. On 2026-05-17,
inthewords filed 10 PAPER entries in mgf-common's FEEDBACK.md
— but 6 of them were sibling-specific (4 against mgf-apiprobe,
2 against mgf-http). The federation had NO mechanism to
prevent this misfile:

- mgf-common's FEEDBACK was the only FEEDBACK file in the
  federation (siblings had none).
- The standards didn't say "sibling-scoped" — they said
  "MUST exist for siblings unless inherited."
- The catch-up auto-block in consumer `docs/CLAUDE.md` didn't
  distinguish where-to-file-what.

v2.8 fixes all three:
- Every sibling now has its own FEEDBACK.md.
- DOC-13 explicitly requires sibling-scoping.
- The auto-block carries an explicit feedback-discipline
  section telling consumers WHERE to file.

The same structural lesson applies to MGF_ADOPTION + MGF_STANDARDS_CONFORMANCE
— PlasmaMapper and inthewords ALREADY maintain these (and the
discipline pays dividends for both projects). Codifying the
shape means future consumers ramp on the same pattern instead
of inventing each time.

---

## Cross-references

- [pre_release_check.md](pre_release_check.md) — v1.0
  readiness audit (2026-05-17).
- [pre_release_additions.md](pre_release_additions.md) —
  evidence-backed feature roadmap (2026-05-17).
- [release_waves_plan.md](release_waves_plan.md) — execution
  plan; this notification is the deliverable of Phase A.
- Standards source-of-truth:
  [`docs/standards/DOCUMENTATION.md`](../standards/DOCUMENTATION.md).
