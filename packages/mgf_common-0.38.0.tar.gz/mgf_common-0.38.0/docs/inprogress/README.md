# `docs/inprogress/` — the maintainer's workspace

**Per `DOC-02` + `DOC-11`:** this directory is the **workspace**
where the maintainer's internal-posture docs live while they're
active. It is **not a graveyard** — closed trackers SHOULD move
to `docs/archive/<year>/` within one release cycle.

## What goes here

- **Living priority trackers** (per `DOC-06`): one per concern
  area (`RELIABILITY_AND_ACCURACY.md`, `SECURITY_HARDENING.md`,
  `PERFORMANCE_AND_CAPACITY.md`). Each follows the §1..§6
  canonical shape; each work unit carries verified `file:line`
  evidence and a falsifiable concrete output.
- **Long-horizon planning docs** (per `DOC-06`'s carve-out):
  `strategic_review.md`, `federation_roadmap.md`. These are
  *not* trackers (no per-item closure) — they're roadmaps that
  inform tracker scope.
- **One-shot audit passes** (e.g., `coverage.md`). These have
  a finite scope; when complete they move to archive.
- **One-shot rollout / notification docs** (`V2_*_NOTIFICATION.md`).
  Cross-project announcements for a standards bump. They land
  here while the rollout is in-flight; once sent + acknowledged
  by consumers they move to `docs/archive/<year>/`.

## What does NOT go here

- **Consumer-reported papercuts** → `FEEDBACK.md` (per `DOC-10`).
  Consumer's experience is the source of truth; this directory
  is the maintainer's internal queue.
- **Per-release breaking-change guides** → `docs/cutover/`.
- **Permanent rules / standards** → `docs/standards/`.
- **Per-component user guides** → `docs/reference/`.

## Promotion / demotion mechanics

| Transition | Trigger |
|---|---|
| **Open → Closed** | All items in §2 priority table flipped to ✅, OR the rest formally deferred to a next-pass tracker |
| **Closed → Archived** | One release cycle after closure (per `DOC-11`); move file to `docs/archive/<year>/<original-name>.md` |
| **In-progress → Reformatted as tracker** | Strategic / roadmap doc has matured enough that items are now narrow + falsifiable; rename + reshape into the canonical tracker form |

## Index (current)

| File | Status | What |
|---|---|---|
| `RELIABILITY_AND_ACCURACY.md` | active (P0+P1 ✅; P2 ⏳ deferred) | RA-* items: atomic-write hygiene, concurrency, rollback semantics, cross-platform paths |
| `SECURITY_HARDENING.md` | active (all 8 ✅; eligible for archive next cycle) | SH-* items: redaction coverage, vault crypto, codemod safety, supply-chain hygiene |
| `PERFORMANCE_AND_CAPACITY.md` | active (P0+P1 ⏳ open) | PC-* items: import-time, sustained throughput, large-payload scaling, memory baseline |
| `strategic_review.md` | active (long-horizon) | Senior-TC-level review of trajectory; not a tracker — informs tracker scope |
| `federation_roadmap.md` | active (long-horizon) | Sibling-extraction plan (ASPIRE-06 + onward) |
| `coverage.md` | active (one-shot audit) | Test-coverage walk |
| `V2_6_NOTIFICATION.md` | one-shot rollout (in-flight) | Cross-project notification: project-shape taxonomy + LICENSE in DOC-01 |
| `V2_7_NOTIFICATION.md` | one-shot rollout (in-flight) | Cross-project notification: `DEPLOYMENT.md` cloud-deployment standard |

## Archived

Closed trackers move to [`docs/archive/<year>/`](../archive/)
per **DOC-11**. See [`docs/archive/2026/README.md`](../archive/2026/README.md)
for the full archive index.
