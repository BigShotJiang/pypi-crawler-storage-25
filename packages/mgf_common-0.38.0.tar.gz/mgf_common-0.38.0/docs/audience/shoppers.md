# For shoppers — evaluating mgf-common

> **Who you are.** You're trying to decide whether to adopt
> `mgf-common` (or pick something else). You want a fast,
> honest read on scope, fit, alternatives, and risks — not a
> 300-page tutorial.

## In 60 seconds

`mgf-common` is the cornerstone Python library for the Magogi
ecosystem. It bundles cross-project infrastructure that every
real Python application re-derives: typed exceptions, layered
configuration (kwargs > env > .env > YAML > defaults),
structured logging + OpenTelemetry, crash reporting, vault
abstraction, process management, FastAPI/Django/alembic
adapters, and a small CLI toolkit.

Stable on PyPI as `mgf-common` since v0.13.0; current major
release `v0.24.0`. Three real consumers in production:
**VManager** (Qt desktop, libvirt VM toolkit), **inthewords**
(Django web), **PlasmaMapper** (FastAPI scientific platform).

## Scope statement (the canonical short form)

> [`docs/standards/SCOPE.md`](../standards/SCOPE.md) is the
> authoritative scope document. The two-paragraph short form:

`mgf-common` covers cross-project **infrastructure** —
behaviours every Python service-or-app writes once and
copy-pastes thereafter. It does NOT cover domain logic,
framework-specific glue beyond the shipped adapters, or
production daemon supervision.

Out of scope (deliberately):

- Restart-on-crash supervision (use systemd / supervisord).
- Multi-service declarative orchestration (use docker-compose).
- Domain-specific framework adapters beyond fastapi / django /
  alembic / db (consumers add their own).
- Anything requiring a hard dep on a third-party SaaS.

## Decision tree — is mgf-common a fit?

```
  ↓ Are you writing Python ≥ 3.11?
  └─ No → not a fit (we don't support older Pythons)

  ↓ Will you have ≥1 of: typed exceptions, structured logs,
    OpenTelemetry, crash reports, vault, process orchestration,
    FastAPI/Django integration?
  └─ No → standard library is enough

  ↓ Are you OK depending on pydantic v2 + pydantic-settings?
  └─ No → not a fit (pydantic-settings is the load-bearing config
          primitive; rewriting it is out-of-scope)

  ↓ Do you need shell-string subprocess (run("foo | bar"))?
  └─ Yes → mgf.common.process is list-only by construction;
          either use raw subprocess for that case OR pass
          ["/bin/sh", "-c", "foo | bar"] explicitly

  ↓ Do you need restart-on-crash supervision?
  └─ Yes → mgf-common is out-of-scope; use systemd / supervisord

  ↓ Otherwise → adopt; start with the tutorial.
```

## Conformance levels (L0/L1/L2)

`mgf-common` gates conformance per
[`docs/standards/README.md`](../standards/README.md):

- **L0 Bootstrap** — basic logging, exceptions, env-driven config.
- **L1 Production-Ready** — typed exception hierarchy, JSON-capable
  structured logs, schema'd config, top-level error handlers,
  local crash reporter.
- **L2 Observability-Native** — L1 + OpenTelemetry traces / metrics
  + optional Sentry / GlitchTip + log redaction + remote shipping.

`mgf-common` itself ships at L2. Every consumer that depends
on it is L1 by default and reaches L2 by enabling
`mgf-common[observability]`.

## Comparing alternatives

| Need | mgf-common | The alternatives |
|---|---|---|
| Subprocess + timeout + redaction + logging | [`mgf.common.process.run`](../recipes/process-management.md) | `subprocess.run` (no redaction, no log streaming); `plumbum` (heavier; different ergonomics); `sh` (Pythonic shell wrapper, different security model) |
| Long-lived service orchestration (test fixtures, demo runners) | [`mgf.common.process.Service`](../recipes/process-management.md) | bash + traps; `pytest-services`; `testcontainers` (heavier; container-only) |
| Layered config (kwargs > env > .env > YAML > defaults) | [`BaseAppSettings`](../reference/config.md) | `pydantic-settings` directly (mgf wraps it with conventions); `dynaconf` (different design philosophy) |
| Typed exception hierarchy + translation seams | [`mgf.common.exceptions`](../reference/exceptions.md) | hand-rolled; `result` libraries (different shape) |
| Cross-project standards corpus | [`docs/standards/`](../standards/) | none — most projects re-derive |

## Consumers using it today

| Consumer | Shape | Adoption depth | Notes |
|---|---|---|---|
| **VManager** | Qt desktop, libvirt | L2 (full) | Reference consumer; co-designed |
| **inthewords** | Django web | L2 (full) | The canonical web consumer; drove BOOTSTRAP-01, LOG-01, CONFIG-01 |
| **PlasmaMapper** | FastAPI scientific | L1 (small-consumer scope discipline) | Selectively adopted per [`non-adoption-is-valid`](../standards/principles/non-adoption-is-valid.md) |

## When to NOT adopt

The principle [`non-adoption-is-valid.md`](../standards/principles/non-adoption-is-valid.md)
codifies this. Concretely, you should NOT adopt if:

- Your project is < 200 LOC (the standards' overhead exceeds
  the value).
- You're stuck on Python < 3.11.
- You're allergic to pydantic v2.
- Your deployment couples you to a JSON wire shape that
  diverges from `mgf.common.observability.JsonFormatter` AND
  you don't want to opt into LG-06's cloud-native carve-out.

These are real, honest reasons. **Documented non-adoption
preserves L1/L2 conformance** when the rationale is recorded
(per the named principle).

## What ships in the wheel

| Surface | Names | Stability |
|---|---|---|
| `mgf.common.*` (top-level) | 193 names across 20 modules | All experimental per [AP-11](../standards/API_DESIGN.md) (0.x window) |
| Standards corpus | 11 topic docs + per-kind subtrees | Versioned with the wheel; `mgf-common standards <topic>` reads them |
| 17 recipes | One per integration shape | Stable when listed in [`recipes/`](../recipes/) |
| Tutorials | Zero → working app | [`docs/tutorial.md`](../tutorial.md) |

## Read next

If this looks like a fit:

1. [`docs/tutorial.md`](../tutorial.md) — zero → working app in ~30 minutes.
2. [`docs/audience/users.md`](users.md) — the post-adoption reading list.
3. [`docs/standards/README.md`](../standards/README.md) — the bar your project commits to at L1/L2.

If it doesn't:

- [`docs/standards/SCOPE.md`](../standards/SCOPE.md) reads honestly about what we don't try to be.
- [`docs/standards/principles/non-adoption-is-valid.md`](../standards/principles/non-adoption-is-valid.md) is the principled exit.
