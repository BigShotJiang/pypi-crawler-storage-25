# `docs/internal/` — maintainer-only recipes

**Per `DOC-02`:** this directory holds docs that consumers
don't read but maintainers (and AI agents acting as
maintainers) do. Internal recipes, audit-trail docs, processes
that aren't part of the public-facing standard set.

## What goes here

- **Maintainer recipes** that don't fit `docs/recipes/` (those
  are consumer-facing). Example: `lift_checklist.md` — the
  8-step recipe for lifting a component from a consumer
  codebase into mgf-common.
- **Coverage / audit summaries** that aren't living trackers
  but are useful reference snapshots. Example: `TEST_COVERAGE.md`.
- **Process documentation** — how to run a release, how to
  triage a security report. (Note: release-engineering rules
  themselves go in `docs/standards/RELEASING.md`; the
  *process narrative* can live here.)

## What does NOT go here

- **Consumer-facing recipes** → `docs/recipes/` (those are
  task-shaped how-tos written for downstream consumers).
- **Living priority trackers** → `docs/inprogress/`.
- **Permanent rules / standards** → `docs/standards/`.
- **Architecture rationale** → `docs/design/`.

## Audience signal

If the doc starts with *"Audience: maintainer / AI agent acting
as maintainer"* — it belongs here.
If it starts with *"Audience: consumer building on mgf-common"*
— it belongs in `docs/reference/` or `docs/recipes/`.

## Index

| File | One-line description |
|---|---|
| `lift_checklist.md` | The 8-step recipe for lifting a component from a consumer codebase into `mgf-common` (or a sibling package). Cross-referenced from `SCOPE.md` §3 promotion criteria |
| `TEST_COVERAGE.md` | Snapshot summary of test coverage across the codebase. Updated at MAJOR boundaries; not a living tracker |
