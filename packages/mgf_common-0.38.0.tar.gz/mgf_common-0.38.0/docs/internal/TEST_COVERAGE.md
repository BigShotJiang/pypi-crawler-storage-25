# TEST_COVERAGE.md — moved (twice)

> **First move (v0.25.0):** to ``docs/qa/coverage.md`` as part
> of the docs reorg (audience-routing layer + flat-content
> directories).
>
> **Second move (2026-05-12):** to
> [`docs/inprogress/coverage.md`](../inprogress/coverage.md) so
> in-flight tracking documents live together under
> ``docs/inprogress/`` alongside `RELIABILITY_AND_ACCURACY.md`,
> `strategic_review.md`, and `federation_roadmap.md`.

The content is identical; only the path changed. This stub
remains for one more MINOR cycle to catch consumers still
pointing at the old path; remove in v0.35.0.

See [`docs/cutover/v0.25.0.md`](../cutover/v0.25.0.md) for the
v0.25.0 path-mapping table.
