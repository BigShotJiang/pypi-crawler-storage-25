# `docs/release/` — release-flow operational docs

**Per `DOC-02`** (additional bucket beyond the canonical six):
this directory holds **release-flow specifics** that operate
ALONGSIDE the rules in `docs/standards/RELEASING.md` — the
CI config narrative, the platform-specific setup steps, the
"how to actually push the tag" walkthrough.

## What goes here

- **CI flow narrative** — `ci.md`: the per-step explanation of
  `.woodpecker.yml`, which secrets need to be configured on
  the platform side, how to wire Trusted Publisher OIDC if/
  when it lands for Codeberg.
- **Platform-specific setup notes** that don't fit `docs/
  standards/RELEASING.md` (which is cross-platform).
- **Release-day runbooks** — the literal commands an operator
  runs to cut a release, with cross-references to the REL-*
  rules each step enforces.

## What does NOT go here

- **The release-engineering MUSTs** → `docs/standards/RELEASING.md`
  (REL-01..REL-09 + per-section rationale).
- **CI YAML patterns themselves** → `docs/standards/WORKFLOWS_PATTERNS.md`
  (paste-ready recipes).
- **CHANGELOG content** → root `CHANGELOG.md`.
- **Per-release breaking-change guides** → `docs/cutover/`.

## Audience signal

This directory's audience is the **operator cutting a release**
— maintainer or AI agent acting as maintainer. The docs assume
familiarity with the `docs/standards/RELEASING.md` rules; they
operationalise those rules for the specific platform mgf-common
ships on (Codeberg + Woodpecker today).

## Index

| File | One-line description |
|---|---|
| `ci.md` | Narrative walkthrough of `.woodpecker.yml` — what each step does, which REL-* / WF-* rule it implements, what to check if it breaks. |
