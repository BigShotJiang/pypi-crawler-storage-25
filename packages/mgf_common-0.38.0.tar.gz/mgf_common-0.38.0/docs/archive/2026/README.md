# `docs/archive/2026/` — archived workspace docs

**Per `DOC-11`:** this directory holds living-tracker docs and
one-shot audits that have been **fully closed** and have sat
for at least one release cycle without movement. They live
here to keep `docs/inprogress/` focused on **active**
maintainer work without losing the historical record of how
the library got to where it is.

Each file moved here SHOULD:

- Have a `✅ closed <date>` header line.
- Carry a §6 (or equivalent) summary explaining what shipped
  from it.
- Cross-link the commit SHAs that closed its items where
  available.

## Index

| File | Closed | Summary |
|---|---|---|
| [`STANDARDS_AUDIT_2026-05-15.md`](STANDARDS_AUDIT_2026-05-15.md) | 2026-05-15 | Pass A — *"Does the library follow the standards?"* — walked all 14 standards docs; 5 docs got fixes, 9 were clean. Findings rolled into `docs/STANDARDS_COMPLIANCE.md`. |
| [`STANDARDS_AUDIT_2026-05-15B.md`](STANDARDS_AUDIT_2026-05-15B.md) | 2026-05-15 | Pass B — *"Do the standards earn their weight?"* — sharpened-lens review; cut 115 lines (3 docs of consumer-specific gap-closure-plan bloat) + 5 wording / markdown fixes. Rules cut: 0; rules merged: 0 (the 148-MUST set all earned its place). |

## How to add a doc here

The mechanics live in `docs/inprogress/README.md` —
"Promotion / demotion mechanics" table.

The shape is:

1. Confirm closure (all items ✅ OR formally deferred to a
   next-pass tracker).
2. Update the tracker's status header line.
3. `git mv docs/inprogress/<name>.md docs/archive/<year>/<name>.md`
4. Add a row above to this README.
5. Remove the row from `docs/inprogress/README.md` index.
6. Commit + push.
