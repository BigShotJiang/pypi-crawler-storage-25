# Template — `MGF_STANDARDS_CONFORMANCE.md` for a Magogi project

> **What this is.** Fork-and-fill template for the
> `MGF_STANDARDS_CONFORMANCE.md` tracker every project ships
> per **DOC-15** + **CFM-01..04**.
> **Audience.** Maintainers of consumer applications AND
> federation siblings — both adopt mgf-common's standards and
> need a conformance ledger.
> **Reference shape.**
> [PlasmaMapper/docs/inprogress/MGF_STANDARDS_CONFORMANCE.md](https://codeberg.org/magogi-admin/PlasmaMapper/src/branch/main/docs/inprogress/MGF_STANDARDS_CONFORMANCE.md).

---

## How to use this template

1. **Copy** the block below into your repo as
   `docs/inprogress/MGF_STANDARDS_CONFORMANCE.md` (recommended
   per CFM-01).
2. **Declare your conformance level** in §1 (L1 / L2 / L3 — see
   below). Match the same declaration in your README.
3. **Initial audit**: walk each standard's rule list (see
   [docs/standards/](../standards/)). For each rule, set one of:
   ✅ conformant / 🚫 declined-with-rationale / ⏳ in-progress
   / N/A.
4. **Update cadence**: on every standards bump (v2.6 → v2.7 →
   v2.8 → ...) AND on every PR that changes code touching a
   conformance rule.

---

## Conformance levels (CFM-02)

| Level | What's covered | Typical adopters |
|---|---|---|
| **L1 — Minimal** | universal-five docs + EH-* (errors) + DP-* core (1-4, 13) | Tiny CLI / scratch project |
| **L2 — Observability-Native** | L1 + LG-* (logging) + OP-* (operability) + SC-* (security) + CF-* (config) | Production services + federation siblings |
| **L3 — Full** | every standard at full strength, including TS-* (testing) + AP-* (API) | Cornerstone library + flagship consumers |

(Read [`docs/standards/README.md`](../standards/README.md) for
the canonical level definitions.)

---

## Template — copy from below

```markdown
# Magogi Foundation Standards — Conformance Tracker (<PROJECT-NAME>)

> **Status.** v0.1 — initial audit. Last updated YYYY-MM-DD.
> **Scope.** <PROJECT-NAME>'s conformance to the standards at
> [`mgf-common/docs/standards/`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/)
> (audit date YYYY-MM-DD).
> **Audience.** Maintainer-tomorrow, AI coding agents, future
> contributors / hires.
> **Cross-references.**
> [README.md](../../README.md) (declared level),
> [`MGF_ADOPTION.md`](MGF_ADOPTION.md) (adoption tracker —
> different concern from this conformance audit).

---

## §1 You are here

<PROJECT-NAME> declares **L<1/2/3> — <level-name>** in
[README.md](../../README.md) and pins
`mgf-common>=0.X,<0.Y` + sibling federation deps.

**Audit method:** (describe how the audit was done — parallel
reads of N enforcement-heavy standards, plus a survey of M
procedural/meta standards.)

**Counts (YYYY-MM-DD):**

| Priority | Count | Effort | Status |
|---|---|---|---|
| P0 — conformance gap with real exposure | N | est | N ✅ / N ⏳ |
| P1 — quality-of-life gaps | N | est | N ✅ / N ⏳ |
| P2 — Phase-2+ or declined per non-adoption | N | — | ⏳ noted |
| ✅ structurally conformant | ~N rules | — | already met |

**Effort calibration:** S ≤ 1 day, M ≈ 2–4 days, L ≈ 1
session-week.

**Headline:** (one-line summary — green / yellow / red.)

---

## §2 Per-standard audit

### §2.1 DP — DESIGN_PRINCIPLES (rules DP-01..DP-13)

| Rule | Status | Notes |
|---|---|---|
| DP-01 layering | ✅ / 🚫 / ⏳ / N/A | (one-line; if 🚫 then rationale required per CFM-04) |
| DP-02 ... | ... | ... |
| ... | ... | ... |

### §2.2 EH — ERROR_HANDLING (rules EH-01..EH-N)

| Rule | Status | Notes |
|---|---|---|
| EH-01 typed-exception hierarchy | ✅ | ... |
| ... | ... | ... |

### §2.3 LG — LOGGING (rules LG-01..LG-N)
### §2.4 SC — SECURITY_STANDARD (rules SC-01..SC-N)
### §2.5 CF — CONFIGURATION (rules CF-01..CF-N)
### §2.6 OP — OPERABILITY (rules OP-01..OP-N)
### §2.7 AP — API_DESIGN (rules AP-01..AP-N)
### §2.8 TS — TESTING (rules TS-01..TS-N)
### §2.9 DOC — DOCUMENTATION (rules DOC-01..DOC-15)
### §2.10 REL — RELEASING (rules REL-01..REL-N)
### §2.11 SCOPE — SCOPE (rules SP-01..SP-N)
### §2.12 DEP — DEPLOYMENT (rules DEP-01..DEP-N — v2.7+)

(Skip groups that don't apply to your project shape — e.g.,
DEP-* doesn't apply to libraries; mark them N/A in §1's counts.)

---

## §3 Decline-with-rationale ledger (CFM-04)

Each 🚫 from §2 listed here with the rationale per
[principles/non-adoption-is-valid.md](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/principles/non-adoption-is-valid.md):

- **<RULE-NN> declined** — (paragraph rationale; reference any
  consumer-side ADR / paper).

---

## §4 Audit log

(One row per audit pass. Drift over time is the signal.)

| Date | Auditor | Trigger | Findings |
|---|---|---|---|
| YYYY-MM-DD | <name> | initial audit | N ✅ · N 🚫 · N ⏳ |
| YYYY-MM-DD | <name> | v2.8 standards bump | (delta) |

---

## §5 Cross-references

- [mgf-common/docs/standards/](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/)
  — the standards source-of-truth.
- [`MGF_ADOPTION.md`](MGF_ADOPTION.md) — adoption tracker
  (when did we land which mgf-common version).
- [mgf-common/docs/standards/principles/non-adoption-is-valid.md](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/principles/non-adoption-is-valid.md)
  — ASPIRE-04 / CFM-04 documented-non-adoption principle.
```

---

## Status markers (CFM-03)

| Marker | Meaning |
|---|---|
| ✅ | Conformant. Implementation present + tested + documented per the rule. |
| 🚫 | Declined-with-rationale. The rule does NOT apply OR was deliberately not adopted. Rationale REQUIRED per CFM-04. |
| ⏳ | In-progress. Adoption planned; gap documented; ETA optional. |
| N/A | Rule doesn't apply to this project's shape (e.g., DEP-* for libraries; CF-* for Django web apps under the v2.6 carve-out). |

---

## When to update

- **Every standards bump** in mgf-common — re-audit anything
  whose rule text changed.
- **Every PR** that changes code touching a conformance rule
  (e.g., changing logging shape touches LG-*).
- **Every quarter** as a sanity sweep regardless of changes
  (drift over time is the signal).
