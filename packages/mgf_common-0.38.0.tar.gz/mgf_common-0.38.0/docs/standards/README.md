# Engineering Standards — Master Index

> **Audience:** Human engineers AND AI coding agents.
> **Reference implementation:** [`mgf-common`](../../README.md) — every standard in this folder is grounded in code that ships in this repository.
> **Reference consumers:** independent projects exercise the standards in real code today — see [`docs/reference-consumers/`](../reference-consumers/) for the per-consumer shape profiles (one per known consumer, covering the desktop/Qt, Django/web, and FastAPI/SaaS shapes).
>
> **Standards stay consumer-neutral.** Per-consumer evidence — what each project does in full, organised by concern — lives in [`docs/reference-consumers/`](../reference-consumers/) and may evolve independently of the standards themselves. Closes [FEEDBACK PAPER-06](../../FEEDBACK.md) (the partial v0.18.0 fix stripped the most rot-prone line-range citations; the full restructure into `docs/reference-consumers/` shipped in v0.32.0).

---

## Why this folder exists

This folder is the **single source of truth** for the cross-cutting engineering standards used by the owner across all desktop and mobile application projects.

The standards do three things at once:

1. **Define the bar.** What "world-class" means for error handling, logging, configuration, and component design — independent of any one project.
2. **Document the reference implementation.** What `mgf.common` ships *today*, with concrete file:line citations so you can read the code, not just the description.
3. **Provide drop-in templates.** Every topic doc ships paste-able skeletons (typed, mypy-strict-clean, no surprises) that a new project can lift directly. For most components the recommended action is now "depend on `mgf-common`" rather than "copy the template" — copy is the fallback when you genuinely need a divergent shape.

If you are **starting a new desktop / mobile / CLI project**, this folder is your starting point. Read the standards, then add `mgf-common` to your dependencies. If you are **extending an existing consumer**, the standards are the bar — do not regress a feature below what they prescribe.

---

## How to navigate this folder

```
docs/standards/
├── README.md ← you are here (master index, conformance keywords, glossary)
├── DESIGN_PRINCIPLES.md ← layering, separation of concerns, replaceability, testability,
│ security/reliability/performance as first-class concerns,
│ async/concurrency rules, time + resource management
├── ERROR_HANDLING.md ← typed exception hierarchy, translation seams, top-level handlers
│ (CLI / sys.excepthook / threading / asyncio / Qt), GUI worker
│ error pipeline, crash reporter, async error paths,
│ user-facing error message style guide
├── LOGGING.md ← stdlib + JSON formatter, hierarchical logger naming, levels,
│ OpenTelemetry trace correlation, redaction, sinks (console +
│ rotating file + optional OTLP / syslog / HTTP), GUI log viewer,
│ log volume control (rate-limit / sample / dedup),
│ async-context propagation via contextvars
├── CONFIGURATION.md ← pydantic-settings, precedence (CLI > env > file > defaults),
│ schema versioning + migrations, atomic writes, lazy path
│ expansion, secrets→vault separation, discriminated unions,
│ environment-tier layering, field aliases for safe renames
├── SECURITY_STANDARD.md ← cross-project security standard: secrets management, subprocess
│ security, deserialization safety, file-system security, crypto
│ choices, network security (TLS / pinning / timeouts), input
│ validation, logging hygiene, dependency security, vulnerability
│ response, threat-model template, mechanical enforcement matrix
├── TESTING.md ← cross-project testing standard: test layout, fixture hierarchy,
│ mock-provider pattern, property tests (Hypothesis), GUI testing
│ (pytest-qt), async testing (pytest-asyncio), performance
│ benchmarks, coverage, test isolation, smoke tests, security pins
├── API_DESIGN.md ← cross-project API-design standard: __all__ discipline, semver
│ rigor, deprecation cycle, type stability + py.typed, stability
│ tiers (experimental/stable/deprecated), PUBLIC_API.md contract,
│ CHANGELOG migration recipes, backward-compat shim discipline
├── RELEASING.md ← cross-project release-engineering standard: PyPI-is-the-contract,
│ tag discipline, version-bump flow, token storage (~/.pypirc + Trusted
│ Publisher), local-dist hygiene, recovery from a botched upload
├── WORKFLOWS.md ← cross-project CI standard: WF-01..WF-12 rules covering
│ four-gate baseline, tag-driven publish, secret-store discipline,
│ tag-version coherence, pre-publish smoke, post-publish verify
├── WORKFLOWS_PATTERNS.md ← paste-ready Woodpecker snippets implementing every
│ WF-* rule; canonical full-pipeline recipe at the bottom
├── SCOPE.md ← cross-project scope policy: IN scope / OUT of scope (with cited
│ ecosystem alternatives) / Adjacent (with promotion criteria);
│ the "scope creep" review question every new-module PR must answer
├── DOCUMENTATION.md ← cross-project documentation standard: the seven-doc root
│ contract + the six-bucket docs/ hierarchy + the priority-tracker
│ shape + the CLAUDE.md format + cutover guides + FEEDBACK lifecycle
│ + CHANGELOG discipline + doc:code drift detection + AI-agent
│ navigability rules
├── OPERABILITY.md ← cross-project operability standard: rich version visibility,
│ self-diagnostic `doctor`, URL resolution, headline-facts honesty,
│ config introspection, log access, diagnostic bundle, bounded state
│ growth (universal) + production safety guards, versioned rollback,
│ alerts-reach-humans, real-target restore drill (service-only)
├── DEPLOYMENT.md ← cross-project deployment standard for web-service consumer
│ applications: Infrastructure-as-Code, Configuration-as-Code,
│ immutable artefacts, secrets management, reversible deploys,
│ the `deploy/` directory shape, end-to-end observability,
│ DNS + TLS as infra, first-production-cut runbook,
│ multi-environment discipline (cloud-agnostic; Infomaniak = main platform)
└── COMMON_COMPONENTS.md ← catalogue of currently-supported common components, where they
                               live in mgf.common, and how to plug them into a new project
```

---

## Suggested reading order

| If you are… | Read in this order |
|---|---|
| **Starting a new project from scratch** | `DESIGN_PRINCIPLES.md` → `SECURITY_STANDARD.md` Rules box → `CONFIGURATION.md` → `ERROR_HANDLING.md` → `LOGGING.md` → `TESTING.md` Rules box → `API_DESIGN.md` Rules box (if publishing a library) → `COMMON_COMPONENTS.md` §"How to bootstrap". Then add `mgf-common` to your dependencies. |
| **Publishing a library** | `API_DESIGN.md` Rules box + §1 mental model + §3 stability tiers + §10 CHANGELOG contract — then walk the AP-* matrix against your repo |
| **Cutting a release** | `RELEASING.md` Rules box (REL-01..REL-08) + §2 release flow — print the §2 checklist for the actual upload session |
| **Setting up CI for a new project** | `WORKFLOWS.md` Rules box (WF-01..WF-12) + `WORKFLOWS_PATTERNS.md` §8 (canonical full pipeline) — copy the recipe, parameterise, commit |
| **Extending an existing consumer** | The relevant topic doc → `COMMON_COMPONENTS.md` → the cited code in `src/mgf/common/` (or in the consumer's own `src/`) |
| **Reviewing a PR for compliance** | `DESIGN_PRINCIPLES.md` (rules) → topic docs (specifics) — every PR claim must map to a MUST/SHOULD here. The §"Self-review checklist" at the bottom of each doc is the PR author's contract. |
| **An AI agent given a vague task** | `README.md` (this file) → `DESIGN_PRINCIPLES.md` → only the topic doc the task touches. The "Rules box" at the top of each topic doc is agent-readable. The mechanical-enforcement matrix at the bottom of each doc tells the agent which rules are CI-enforceable vs review-only. |
| **Auditing security posture** | `SECURITY_STANDARD.md` Rules box + §15 mechanical-enforcement matrix → §12 threat-model template → walk the SC-01..SC-18 list against the project |
| **Setting up a new test suite** | `TESTING.md` Rules box → §3 fixture patterns → §11 isolation → §10 security pins. Then write the first failing test. |
| **Just looking up a fact** | Use the COMMON_COMPONENTS.md table of contents — it indexes every component by name and points at code |
| **Setting up the docs system for a new project** | `DOCUMENTATION.md` Rules box (DOC-01..DOC-12) + §2 hierarchy + §13 self-review checklist. Then ship the seven root-level docs and the six-bucket `docs/` skeleton before the first PR. |
| **Making a service / app actually runnable in production** | `OPERABILITY.md` Rules box (OP-01..OP-12) + §5 self-review checklist. The 8 universal rules (OP-01..OP-08) apply to every project with a CLI / GUI; the 4 service-only rules (OP-09..OP-12) apply when a real deployment + alerting story exists. |
| **Deploying a web service to the cloud** | `DEPLOYMENT.md` Rules box (DEP-01..DEP-11) + §3 canonical `deploy/` directory shape + §7 self-review checklist. Cloud-agnostic; §8.1 covers Infomaniak (Magogi foundation's main platform); §8.3 covers AWS / Azure / GCP shape translations; §8.4 covers managed-platform shapes (Fly.io / Render / Heroku). The reference framework is [`django-infomaniak-deploy`](https://codeberg.org/magogi-admin/django-infomaniak-deploy). |

---

## Conformance keywords

These docs use [RFC 2119](https://www.rfc-editor.org/rfc/rfc2119) keywords throughout. Every rule is tagged. Treat them as load-bearing — violations should be caught in code review.

| Keyword | Meaning |
|---|---|
| **MUST** / **MUST NOT** | Absolute requirement. A violation is a bug. Tooling (lint, mypy, tests) MUST enforce where mechanically possible. |
| **SHOULD** / **SHOULD NOT** | Strong recommendation. A deviation requires written justification in code or PR description. |
| **MAY** | Optional. Use your judgment. |

Every topic doc opens with a **Rules box** — a one-page summary of every MUST/SHOULD in that document. Skim that first; the body of the doc is rationale and templates.

---

## Conformance levels for projects

Not every project needs every standard at full strength on day one. Three published levels:

| Level | What you commit to | Typical use |
|---|---|---|
| **L0 — Bootstrap** | Hierarchical logging, base exception class, env-var-driven config (no schema). MUST NOT log secrets. MUST NOT swallow exceptions silently. | Spike, prototype, throwaway tool |
| **L1 — Production-Ready** | Full typed exception hierarchy, JSON-capable structured logging with correlation IDs, `pydantic-settings` config with schema versioning, top-level error handlers wired (CLI + GUI/threading/asyncio as applicable), local crash reporter writing JSON. | Any tool a real user will run |
| **L2 — Observability-Native (Tier C)** | Everything in L1 + OpenTelemetry traces/metrics/logs wired (OTLP exporter, off by default but flip-able via env), optional Sentry/GlitchTip handler, log redaction on by default, GUI log viewer dialog, remote log shipping handler available. | Any tool that runs unattended, in production, on a user's machine, or as a service |

**`mgf-common` ships at L2** — every consumer that depends on it is L1 by default and reaches L2 by enabling the `[observability]` extra and calling `mgf.common.observability.setup_otel()`.

When you start a new project, declare its target level in its top-level README (e.g., "Conformance: L1 per `mgf-common/docs/standards/`"). This sets the bar for code review.

**Documented non-adoption preserves conformance.** A project at L1 / L2 may consciously decline a specific primitive when adopting it would conflict with a deployment-coupled, policy-specific, or framework-architectural constraint — provided the rationale is recorded (ADR, tracker entry, or `FEEDBACK.md` paper). See [`principles/non-adoption-is-valid.md`](principles/non-adoption-is-valid.md) for the named principle, the three components (conscious decline / documented rationale / feedback if generalizable), and the worked examples (LOG-01, BOOTSTRAP-01, "small consumer" scope discipline). This is the framing behind every shipped carve-out.

**Per-kind subtrees.** For consumers building **web applications and APIs** (Django / FastAPI / Flask / Pyramid), see [`web/README.md`](web/README.md) — the web-domain narrative wrapper that says "for a web consumer, here's how the canonical rules land + which carve-outs apply." The canonical topic docs remain authoritative; the subtree is the discoverable front door for web-shaped consumers.

---

## The component catalogue (one-line summary)

The full list lives in [`COMMON_COMPONENTS.md`](COMMON_COMPONENTS.md). The TL;DR:

| Component | Status in `mgf.common` today | Where it lives | Standard doc |
|---|---|---|---|
| **Exception hierarchy + base class** | ✅ Strong (L1) | `src/mgf/common/exceptions/` (`AppError` base + 7 categories + 7 generic concretes) | [`ERROR_HANDLING.md`](ERROR_HANDLING.md) |
| **Typed application config** | ✅ Strong (L1) | `src/mgf/common/config/` (`BaseAppSettings` + `make_settings_config` + `load_settings`) | [`CONFIGURATION.md`](CONFIGURATION.md) |
| **Logging** | ✅ Strong (L1) | `src/mgf/common/observability/logging_setup.py` + `json_formatter.py` + `text_formatter.py` | [`LOGGING.md`](LOGGING.md) |
| **GUI worker pattern** | 🟡 Documented; concrete code is per-consumer | per-project template | [`DESIGN_PRINCIPLES.md`](DESIGN_PRINCIPLES.md) §"GUI threading" |
| **Provider abstraction (replaceability)** | 🟡 Documented; per-project ABCs in consumers | per-project template | [`DESIGN_PRINCIPLES.md`](DESIGN_PRINCIPLES.md) §"Replaceability" |
| **Crash reporter (local + remote)** | ✅ Strong (L1; remote sinks via `[observability]` extra) | `src/mgf/common/observability/crash_reporter.py` | [`ERROR_HANDLING.md`](ERROR_HANDLING.md) §"Crash reporter" |
| **Excepthooks (sys + threading)** | ✅ Strong (L1) | `src/mgf/common/observability/excepthook.py` + `threading_excepthook.py` | [`ERROR_HANDLING.md`](ERROR_HANDLING.md) §"Top-level handlers" |
| **OpenTelemetry tracing** | ✅ Strong (L2 via `[observability]` extra) | `src/mgf/common/observability/otel_setup.py` | [`LOGGING.md`](LOGGING.md) §"Correlation" |
| **Sensitive-field redaction** | ✅ Strong (L1) | `src/mgf/common/observability/redaction.py` (Bearer/JWT/PEM + named-key policy) | [`LOGGING.md`](LOGGING.md) §"Redaction" |
| **Log viewer dialog (GUI)** | 🟡 Documented; concrete code is per-consumer | per-project template (`LOGGING.md` §9.1) | [`LOGGING.md`](LOGGING.md) §"GUI log viewer" |

Each topic doc ends with a **"How to consume from your project"** section — the concrete `mgf.common.*` symbols to import and the entry-point wiring required (e.g., `mgf.common.bootstrap(app_name=...)`).

---

## How AI agents should use this folder

If you are an AI coding agent:

1. **Before writing or editing code in any of these areas** — error handling, logging, config, threading/worker — read the corresponding topic doc.
2. **The Rules box at the top of each doc is your contract.** Every MUST is non-negotiable.
3. **Templates are paste-able.** When asked to "add logging" or "add a config field," you SHOULD lift the template and adapt it, not invent a new shape.
4. **When the task hints at a gap** ("add crash reporting", "make logs work with Loki", "wire tracing"), depend on `mgf-common`'s shipped implementation rather than inventing a new shape. The reference implementation paths live in `COMMON_COMPONENTS.md` (catalogue) and the per-topic doc's "AS-IS in mgf-common" section.
5. **If a new pattern emerges** that the standard doesn't cover, propose an addition to the standard *before* applying it. Standards diverge fast if every project invents its own conventions.
6. **A consumer project's `docs/claude/CLAUDE.md`** is the *project-specific* lookup (what's been built, what's broken, gotchas). The `mgf-common/docs/standards/` folder is the *cross-project* standard. They complement each other.

---

## How humans should use this folder

For new projects:
1. Add `mgf-common` to your dependencies. The full L1 surface (exception base, config loader, logging stack, crash reporter, excepthooks) lands in one import.
2. Add `mgf-common[observability]` if you want L2 (OpenTelemetry traces + Sentry-style remote crash sink).
3. Call `mgf.common.bootstrap(app_name=..., app_version=...)` once in every entry point — wires identity + logging + OTel + excepthooks in a single transactional call.
4. Subclass `mgf.common.exceptions.AppError` for your project's domain exceptions, and `mgf.common.config.BaseAppSettings` (via `settings_config(env_prefix="YOURAPP_")`) for your typed config.
5. Write your first feature *only* after the bootstrap files are in place.
6. Declare your conformance level in your README (e.g., `"Conformance: L1 per mgf-common/docs/standards/"`).

For an existing consumer:
1. Use the standards as the bar for every PR. When a PR touches one of the catalogued components, the relevant topic doc's MUSTs apply.
2. Track gap-closure work as roadmap items, not ad-hoc commits — each gap is a discrete, reviewable change.
3. When `mgf-common` adds a new component or relaxes/tightens a rule, bump the consumer's `mgf-common` pin in the same PR that updates the consuming code.

---

## Versioning

The standards version (top of this file) bumps when:

- **MAJOR** — A MUST is added, removed, or relaxed (existing code in any project may be non-compliant).
- **MINOR** — A SHOULD or template changes (existing code stays compliant; new code SHOULD adopt).
- **PATCH** — Wording, examples, or AS-IS code references updated.

Each topic doc carries its own version line in its header. The master `README.md` version is the maximum of all topic doc versions.

---

## Glossary

| Term | Definition |
|---|---|
| **Cornerstone (this project)** | The reference implementation pattern — `mgf-common` is the cornerstone library; consumer projects depend on `mgf-common` and inherit the standards. |
| **Lingua franca** | A small set of frozen domain types (e.g., `VMHandle`) passed between modules so APIs are not stringly-typed. See `DESIGN_PRINCIPLES.md`. |
| **Provider / driver / adapter** | An abstract base class isolating a third-party dependency (libvirt, a database, a cloud SDK) so the rest of the codebase is testable and replaceable. |
| **Translation seam** | The single place where a third-party exception is converted to a typed application exception. See `ERROR_HANDLING.md`. |
| **Top-level handler** | The outermost catch in each entry point (CLI `main`, `sys.excepthook`, `threading.excepthook`, asyncio loop handler, Qt event loop) that converts an unhandled exception into a clean exit / dialog / log entry. |
| **Correlation ID / trace ID** | An identifier propagated across log records so a single user action can be reconstructed end-to-end. In Tier C, this is the OpenTelemetry trace ID. |
| **Sink** | A destination a log record is written to (console, rotating file, OTLP exporter, syslog, etc.). |
| **Lift-and-shift** | Copying a template from a standard into a new project verbatim or with mechanical edits (rename the package, swap the brand). With `mgf-common`, lift-and-shift is the FALLBACK — preferred path is "depend on `mgf-common`". |
| **Gap-closure** | A planned, file-specific change list to bring a consumer project from its current state to the L2 standard. Lives at the bottom of each topic doc when relevant. |

---

## Index of MUSTs

A flat, sortable list of every absolute requirement across the standards. Use this as a code-review checklist or as input to a linter rule when you write one.

> **Maintenance discipline (DOC-04 same-commit shape):** when a Rules box in any topic doc changes (new MUST added, existing MUST text revised, MUST removed), this index MUST be updated IN THE SAME COMMIT. The duplication is intentional — the topic doc's Rules box is the body's quick reference; this index is the cross-doc grep target — but the drift surface is real. Treat the index like CHANGELOG.md: same-commit update or the change is incomplete. Last refreshed in the 2026-05-15 standards audit (filled gaps for WF / REL / DOC / TS-19+ / LG-15+; fixed LG-11 promotion + LG-06 v0.18 revision + AP-12 typo).

| ID | Source | Rule |
|---|---|---|
| DP-01 | DESIGN_PRINCIPLES | Layering MUST be enforced: UI layers MUST NOT be imported by core; core MUST NOT import third-party SDKs that have a provider in front of them. |
| DP-02 | DESIGN_PRINCIPLES | Every third-party dependency that owns I/O (DB, hypervisor, cloud, ML model, OS process) MUST sit behind an ABC with at least one production and one mock implementation. |
| DP-03 | DESIGN_PRINCIPLES | Domain types passed between modules MUST be frozen dataclasses (or pydantic models with `frozen=True`); never bare strings or dicts. |
| DP-04 | DESIGN_PRINCIPLES | Every public function MUST have a type-annotated signature. mypy --strict MUST pass on `src/`. |
| DP-05 | DESIGN_PRINCIPLES | Tests MUST mirror `src/` structure 1:1 and MUST run without any production credentials, network calls, or third-party daemons. |
| DP-06 | DESIGN_PRINCIPLES | Security, reliability, performance, and error reporting are first-class concerns; every PR description MUST address all four when touching new surface. |
| DP-07 | DESIGN_PRINCIPLES | Rich inline documentation: every public class/function MUST have a docstring explaining intent and invariants. |
| DP-08 | DESIGN_PRINCIPLES | Code SHOULD be replaceable; for each major component the doc near it MUST describe the swap recipe. |
| DP-09 | DESIGN_PRINCIPLES | Cancellation MUST be explicit. Long-running ops take an explicit `CancellationToken`-like parameter; never a thread-global. |
| DP-10 | DESIGN_PRINCIPLES | No silent fallbacks. If a fallback path exists, the active backend MUST be queryable and SHOULD be logged at startup. |
| EH-01 | ERROR_HANDLING | Every exception raised by application code MUST be a subclass of the application's base error class. |
| EH-02 | ERROR_HANDLING | Third-party exceptions MUST be translated to typed application exceptions at the boundary that owns the third-party call (provider, shell wrapper, HTTP client). |
| EH-03 | ERROR_HANDLING | When re-raising a translated exception, the original cause MUST be chained via `raise NewError(...) from original`. |
| EH-04 | ERROR_HANDLING | Every entry point MUST install a top-level handler: CLI `main`, `sys.excepthook`, `threading.excepthook`, `asyncio.get_event_loop().set_exception_handler`, and Qt's `qInstallMessageHandler` + `sys.excepthook` integration when GUI is present. |
| EH-05 | ERROR_HANDLING | Unhandled exceptions MUST produce a local crash report (JSON file under the application's state dir) AND, if remote reporting is enabled, MUST be forwarded to the configured remote sink. |
| EH-06 | ERROR_HANDLING | GUI workers MUST catch every exception (typed AND untyped), forward via signal, and never crash the worker thread silently. |
| EH-07 | ERROR_HANDLING | `except Exception:` (without re-raise or typed translation) MUST NOT appear except in: (a) cleanup paths inside `finally:` / `contextlib.suppress(...)`, (b) "best-effort observer" loops that log + continue and document the invariant. |
| EH-08 | ERROR_HANDLING | Every typed exception MUST carry machine-readable fields as constructor args (e.g., `CommandError.argv`, `SchemaValidationError.errors`), not just a formatted message string. |
| EH-09 | ERROR_HANDLING | User-facing error messages MUST end in an actionable next step where possible; the hint MUST be pinned by a substring test (see §14.7). |
| EH-10 | ERROR_HANDLING | Best-effort observer code (hook executors, scheduler tick loops, alert evaluators, libvirt event callbacks) MUST follow the never-raises invariant. |
| LG-01 | LOGGING | Every module MUST acquire its logger via `logging.getLogger(__name__)` (or the equivalent canonical name); no bare `logging.info(...)`. |
| LG-02 | LOGGING | The application MUST configure logging in exactly one place (per entry point) and MUST emit JSON when stdout is not a TTY (so log aggregators can parse it). |
| LG-03 | LOGGING | Every log record MUST carry the OpenTelemetry trace_id and span_id when a span is active (added automatically by the standard formatter). |
| LG-04 | LOGGING | Sensitive fields (passwords, tokens, private keys, session cookies) MUST be redacted by the formatter before any sink sees them. The redaction set MUST be configurable. |
| LG-05 | LOGGING | Error-level logs MUST include the exception via `LOG.exception(...)` or `exc_info=True` — never just the stringified exception in the message. |
| LG-06 | LOGGING | Logs MUST reach an aggregator the operator can search — a rotating local file (desktop / single-server), the process's stdout/stderr (cloud-native; the runtime captures), or a remote sink (OTLP / syslog / HTTP, opt-in). A "console only, no aggregation" production config is non-compliant. (Revised v0.18.0 closing FEEDBACK LOG-01.) |
| LG-07 | LOGGING | GUI applications MUST ship a log-viewer dialog that reads the rotating file sink (so users can view logs without a terminal). |
| LG-08 | LOGGING | Log messages MUST use lazy %-style formatting (`LOG.info("processing %s", x)`), NOT f-strings. |
| LG-09 | LOGGING | Structured fields MUST be passed via `extra={...}`, NOT concatenated into the message. |
| LG-10 | LOGGING | Headless services MUST configure logging at their entry point with `JournalHandler` (Linux) / equivalent OS sink in addition to the file sink. |
| LG-11 | LOGGING | Operation start/end MUST be logged with a stable `operation` name field at INFO for any function ≥100 ms OR any function that crosses a process / network / storage boundary, so flows are reconstructable from logs alone (without needing the trace backend up). Short pure-Python helpers are exempt. (Promoted SHOULD → MUST in v2.4.) |
| LG-12 | LOGGING | Log emission MUST be cheap (≤100 µs per record). Heavy formatting / IO MUST happen in the handler, not the call site. |
| CF-01 | CONFIGURATION | Application configuration MUST live in a single typed object (`pydantic-settings.BaseSettings` subclass). No module reads the config file or env vars directly. |
| CF-02 | CONFIGURATION | Precedence MUST be, top-to-bottom: CLI flags → environment variables → `.env` file → on-disk config file → typed defaults in code. |
| CF-03 | CONFIGURATION | The config schema MUST carry a version field. Loading a higher version than known MUST fail loud. Loading a lower version MUST run a migration chain. |
| CF-04 | CONFIGURATION | Writes MUST be atomic (temp file + rename) with mode 0o600. Path expansion MUST happen lazily (not at module import). |
| CF-05 | CONFIGURATION | Secrets MUST NOT live in the config file. They live in a vault (system keyring or encrypted file) accessed through a separate `Vault` interface. |
| CF-06 | CONFIGURATION | Loading an unknown key from the config file MUST raise (typo protection). Missing keys MUST fall back to typed defaults silently. |
| CF-07 | CONFIGURATION | Sub-config files (hooks, schedules, alerts, profiles, lab specs) MUST follow the same shape: typed model + atomic write + version field + unknown-key rejection. |
| CF-08 | CONFIGURATION | The `Settings` object MUST be loaded once at the entry point and passed down by constructor injection. Module-global singletons are forbidden. |
| CF-09 | CONFIGURATION | A `--config <path>` CLI flag MUST always exist. The default path MUST honour XDG / OS conventions. |
| CF-10 | CONFIGURATION | Tests MUST construct `Settings` with explicit values (no env-var leakage). |
| CF-11 | CONFIGURATION | Renaming a config field MUST NOT break existing on-disk configs — use `Field(validation_alias=AliasChoices(...))` and rewrite-on-next-save. |
| CF-12 | CONFIGURATION | Mutually-exclusive backend variants MUST be modelled as a discriminated union with a `kind` discriminator field. |
| DP-11 | DESIGN_PRINCIPLES | Async tasks MUST have an owner. Bare `asyncio.create_task(...)` without retention is a defect. |
| DP-12 | DESIGN_PRINCIPLES | Time MUST be UTC at every boundary. `datetime.now()` is forbidden; use `datetime.now(UTC)`. Naive datetimes MUST NOT cross any module boundary. |
| DP-13 | DESIGN_PRINCIPLES | Every owned external resource MUST be released deterministically via context manager or `try / finally`. GC-based cleanup is a defect. |
| LG-13 | LOGGING | High-frequency log sites MUST use rate-limiting, sampling, dedup, or be re-classified as metrics. |
| LG-14 | LOGGING | Custom correlation context MUST propagate via `contextvars.ContextVar`, not thread-local storage. |
| SC-01 | SECURITY_STANDARD | Secrets MUST live in a Vault, never in config / env files / source / logs / crash reports. |
| SC-02 | SECURITY_STANDARD | Subprocess invocation MUST use `argv` lists with `shell=False`. |
| SC-03 | SECURITY_STANDARD | YAML/JSON loading from any external source MUST use `yaml.safe_load` / `json.loads`. `pickle` is forbidden for IPC / persistence / untrusted data. |
| SC-04 | SECURITY_STANDARD | Files with private data MUST be written with mode `0o600` and atomically. |
| SC-05 | SECURITY_STANDARD | Cryptographic primitives MUST come from `cryptography` (or stdlib `hashlib`/`hmac`/`secrets`). No DIY crypto. |
| SC-06 | SECURITY_STANDARD | TLS verification MUST be enabled on every outbound connection. |
| SC-07 | SECURITY_STANDARD | Every external request MUST carry a finite timeout. |
| SC-08 | SECURITY_STANDARD | Untrusted input MUST be validated at the boundary (typed, range-checked, length-bounded, allow-listed). |
| SC-09 | SECURITY_STANDARD | Sensitive fields MUST be redacted by the formatter before any log sink sees them. |
| SC-10 | SECURITY_STANDARD | Dependencies MUST be pinned via lockfile + scanned for CVEs in CI. |
| SC-11 | SECURITY_STANDARD | Tracebacks / exception messages / crash reports MUST NOT leak secret material. |
| SC-12 | SECURITY_STANDARD | A `SECURITY.md` MUST exist at the repository root with vulnerability-reporting policy. |
| SC-13 | SECURITY_STANDARD | Cryptographic keys at rest MUST be derived from a passphrase via KDF or held in the system keyring. Never embedded in source. |
| SC-14 | SECURITY_STANDARD | Authentication failures MUST NOT enumerate. Repeated failures MUST be rate-limited. |
| SC-15 | SECURITY_STANDARD | Filesystem operations MUST validate against directory traversal via `Path.resolve()` + `is_relative_to()`. |
| SC-16 | SECURITY_STANDARD | Privileged operations MUST be confined to a narrow, audited surface, documented per call site. |
| SC-17 | SECURITY_STANDARD | Security-relevant actions MUST emit an `audit=true` structured log record. |
| SC-18 | SECURITY_STANDARD | Releases MUST be reproducible from source. |
| TS-01 | TESTING | `tests/` MUST mirror `src/` 1:1. CI MUST lint that no source file lacks a mirror. |
| TS-02 | TESTING | The unit suite MUST run with no production credentials, no network, and no real third-party daemon. |
| TS-03 | TESTING | Every test MUST run in isolation. Process-global state MUST be saved + restored via fixtures. |
| TS-04 | TESTING | `filterwarnings = ["error"]` MUST be set in `pyproject.toml`. |
| TS-05 | TESTING | `--strict-markers` and `--strict-config` MUST be set. |
| TS-06 | TESTING | Coverage gate ≥80% project-wide; ≥90% on changed lines in a PR. |
| TS-07 | TESTING | Every typed exception MUST have a unit test asserting message format + field values. |
| TS-08 | TESTING | Every translation seam MUST have tests for success + each typed translation + the catch-all. |
| TS-09 | TESTING | Every "best-effort observer" MUST have a test that injects a raising observer and asserts the loop continues. |
| TS-10 | TESTING | Every security-relevant rule MUST be pinned by a test where mechanically possible. |
| TS-11 | TESTING | GUI workers MUST have tests for the success path AND the untyped-exception path. |
| TS-12 | TESTING | Async code MUST be tested with `pytest-asyncio` (or `anyio` plugin). |
| TS-13 | TESTING | Property tests (Hypothesis) MUST cover any code that round-trips data. |
| TS-14 | TESTING | Performance budgets MUST be pinned by a benchmark in the unit suite. |
| TS-15 | TESTING | Smoke tests against real backends MUST be opt-in (separate marker, separate CI job) and read-only by default. |
| TS-16 | TESTING | Every test failure message MUST be self-explanatory. |
| TS-17 | TESTING | Test fixtures MUST be discoverable via the conftest hierarchy, never imported across test packages. |
| TS-18 | TESTING | Slow tests (>1 s) MUST be marked `@pytest.mark.slow` and excluded from the default `pytest` invocation. |
| EH-11 | ERROR_HANDLING | Retries MUST use exponential backoff with full jitter and a finite cap. Linear / immediate retry forbidden. |
| EH-12 | ERROR_HANDLING | Operations against external systems with multi-attempt cost MUST be idempotent. |
| EH-13 | ERROR_HANDLING | A circuit breaker MUST guard any external call that, when failing, can amplify load on the upstream. |
| AP-01 | API_DESIGN | The public API surface MUST be enumerated explicitly via `__all__` at every package and module boundary. |
| AP-02 | API_DESIGN | Every public name MUST have a docstring stating intent, invariants, and at least one usage example. |
| AP-03 | API_DESIGN | The package MUST follow Semantic Versioning. Public-API breaks happen ONLY in MAJOR (or in MINOR pre-1.0). |
| AP-04 | API_DESIGN | Deprecation cycle MUST be: announce → still works (≥1 MINOR) → removed; deprecated names emit `DeprecationWarning`. |
| AP-05 | API_DESIGN | Public function signatures MUST be stable. New parameters MUST be keyword-only with defaults. |
| AP-06 | API_DESIGN | Return types MUST NOT narrow in non-MAJOR releases. |
| AP-07 | API_DESIGN | Exceptions raised by public functions are part of the public API; MUST be documented and from the typed hierarchy. |
| AP-08 | API_DESIGN | Public modules MUST use `from __future__ import annotations`; runtime-unused imports go in `if TYPE_CHECKING:`. |
| AP-09 | API_DESIGN | A PEP 561 `py.typed` marker MUST exist for any package that ships type annotations. |
| AP-10 | API_DESIGN | A `PUBLIC_API.md` MUST list every public name with its stability tier. |
| AP-11 | API_DESIGN | Stability tiers MUST be declared per public name: `experimental` / `stable` / `deprecated`. |
| AP-12 | API_DESIGN | Breaking changes MUST be documented with the four-part migration recipe (symptom / before / after / why). |
| AP-13 | API_DESIGN | A `__version__` attribute MUST be present on every distribution package, in sync with `pyproject.toml`. |
| AP-14 | API_DESIGN | Internal modules MUST NOT be imported by consumers. Single-underscore module names are private. |
| AP-15 | API_DESIGN | Backward-compatibility shims MUST emit `DeprecationWarning` AND log at INFO once per process. |
| SP-01 | SCOPE | The library MUST publish an explicit IN-scope list. Without it, "scope creep" arguments collapse into taste arguments. |
| SP-02 | SCOPE | The library MUST publish an explicit OUT-of-scope list with reasoning + cited ecosystem alternative per entry. |
| SP-03 | SCOPE | Every PR adding a new module or top-level function MUST justify against §1 (IN) or §3 (Adjacent). PRs whose answer is "OUT" are rejected. |
| SP-04 | SCOPE | Adjacent-scope items MUST require a documented consumer-demand signal before promotion to IN. |
| SP-05 | SCOPE | The OUT-of-scope list MUST cite the ecosystem alternative for every cut. |
| SP-06 | SCOPE | Scope policy MUST be revisited on every MAJOR release; items move between IN / Adjacent / OUT as the ecosystem and consumer demand shift. |
| LG-15 | LOGGING | Every INFO+ record at a notable lifecycle / security / boundary event MUST carry a stable `event` field in `<subject>.<action>` form (e.g. `vault.read`, `bootstrap.replace`). Event names are public-API-stable; document in `docs/reference/EVENTS.md`; rename only via deprecation cycle. See LOGGING §4.5. |
| LG-16 | LOGGING | Every WARNING and ERROR record MUST answer three questions: WHAT (past-tense declarative message), WHY (structured `extra={}` fields, never concatenated), HOW (actionable hint when remediation is known — message-suffix or `hint` field). See LOGGING §4.6. |
| LG-17 | LOGGING | Every ERROR record SHOULD carry a stable `fingerprint` field so observability tools group occurrences of the same logical failure. Default: exception type FQN (formatter-computed). Override via `fingerprint` extra when args are part of identity. See LOGGING §4.7. |
| TS-19 | TESTING | Test layer markers MUST be registered in `pyproject.toml` under `[tool.pytest.ini_options].markers`. Combined with `--strict-markers`, prevents silent typos. Canonical four: `smoke` / `e2e` / `integration` / `slow`. |
| TS-20 | TESTING | Tests MUST be partitioned across four canonical directories: `tests/unit/` (default), `tests/integration/`, `tests/e2e/`, `tests/smoke/`. Each non-unit directory's tests SHOULD apply the matching marker via top-level `pytestmark`. |
| TS-21 | TESTING | Every published library MUST have a smoke layer (`tests/smoke/`) running in <100 ms total: package imports, every `__all__` name reachable, shortest happy path of every public entry function works. |
| WF-01 | WORKFLOWS | Every project MUST have CI that runs on every push to a long-lived branch and every pull request. No "ship from local laptop" paths. |
| WF-02 | WORKFLOWS | The four green gates (lint / typecheck / test / import-linter) MUST be CI-enforced and MUST block merge on red. |
| WF-03 | WORKFLOWS | A library that publishes to PyPI MUST have a tag-driven publish workflow. Pushing `v<X.Y.Z>` is the trigger; non-tag pushes MUST NOT publish. |
| WF-04 | WORKFLOWS | Publish credentials MUST be stored in the CI platform's secret store, scoped per-project, and (where supported) restricted to tag-event runs only. |
| WF-05 | WORKFLOWS | The publish workflow MUST verify tag-version coherence before uploading. Tag name MUST match `pyproject.toml::version` AND `__version__`; mismatch aborts. |
| WF-06 | WORKFLOWS | The wheel uploaded to PyPI MUST be the one built in the CI run that's about to publish. Never re-use a wheel built earlier. |
| WF-07 | WORKFLOWS | Pre-publish smoke MUST install the freshly-built wheel into an ephemeral venv and import the top-level package + `__version__`. |
| WF-08 | WORKFLOWS | Post-publish verification MUST confirm the artifact appeared on PyPI with the expected version + SHA256 within a polling window. |
| WF-09 | WORKFLOWS | Workflow files MUST pin every external dependency to a specific version (interpreter image, plugin actions, base images by digest where supported). |
| WF-10 | WORKFLOWS | Independent CI steps MUST run in parallel. Sequential ordering is reserved for genuine dependencies; matrix axes MUST fan out. |
| WF-11 | WORKFLOWS | A CI run MUST be reproducible from its inputs alone. No env vars outside what the workflow declares; no host state; no implicit network beyond pinned. |
| WF-12 | WORKFLOWS | Every CI step MUST surface its exit code, the exact command that ran, and enough log context on failure. Silent failures / `\|\| true` swallowing are forbidden. |
| REL-01 | RELEASING | Every PyPI release MUST have a corresponding annotated git tag `v<version>` on the exact commit that built the published wheel. |
| REL-02 | RELEASING | A version string MUST NOT be reused across different wheel contents. Once `0.X.Y` is published, the local `dist/` artifact for that version is read-only. |
| REL-03 | RELEASING | `PUBLIC_API.md` and `PUBLIC_API.json` reflect master HEAD, not the published surface. They MAY be ahead of PyPI during a release window. |
| REL-04 | RELEASING | PyPI tokens MUST NOT be passed via chat, shell history, or env vars in unmanaged sessions. Local: `~/.pypirc` chmod 600. CI: Trusted Publisher OIDC. |
| REL-05 | RELEASING | Releases are one-shot and irreversible. Once `twine upload` succeeds, the published version is frozen forever. Bug fixes ship as new releases. |
| REL-06 | RELEASING | The release flow is strictly ordered: bump version → regen PUBLIC_API.json → build → tests green → twine check → commit → tag → push → upload. Do not invert. |
| REL-07 | RELEASING | A release commit MUST close every FEEDBACK entry it ships: flip status to `✅ SHIPPED` with a one-paragraph retrospective. |
| REL-08 | RELEASING | Pre-release smoke MUST exercise the actually-built wheel: `pip install dist/<package>-<version>-*.whl` into an ephemeral venv + import every public top-level name. |
| REL-09 | RELEASING | Every FEEDBACK entry flipped to `✅ SHIPPED` / `DEFERRED` / `❌ REJECTED` MUST produce a consumer-facing notification message (CHANGELOG migration content as source). |
| DOC-01 | DOCUMENTATION | Every project MUST ship the root-level docs applicable to its shape (cornerstone / federation sibling / consumer application — see DOCUMENTATION.md §2.0). Universal four for ALL shapes: `README.md`, `LICENSE`, `CHANGELOG.md`, `SECURITY.md`. Library-only adds `PUBLIC_API.md`, `STARTHERE.md`, `CONTRIBUTING.md`, `FEEDBACK.md`. |
| DOC-02 | DOCUMENTATION | Every project MUST organise non-root docs into the six-bucket hierarchy applicable to its shape: `docs/standards/` / `reference/` / `inprogress/` / `claude/` / `cutover/` / `recipes/`. Non-cornerstone projects' `docs/standards/` MUST NOT duplicate cornerstone content (pointer-only README, or project-specific extensions). Additional buckets allowed with a one-paragraph charter. |
| DOC-03 | DOCUMENTATION | Every long-lived bucket MUST have its own `README.md` charter ("what goes here, what doesn't, when to add / remove"). |
| DOC-04 | DOCUMENTATION | Every public-API change MUST land with a `CHANGELOG.md` entry IN THE SAME COMMIT. Breaking entries MUST link the `docs/cutover/v<X.Y.Z>.md` and the FEEDBACK entry. |
| DOC-05 | DOCUMENTATION | Every breaking change MUST ship a `docs/cutover/v<X.Y.Z>.md` guide with the four mandatory sections (symbol table / codemod recipe / manual paths / FEEDBACK back-link). |
| DOC-06 | DOCUMENTATION | Living priority trackers MUST follow the standard shape (priority table → first wave → §4 work units → §5 closed items). Every work unit MUST carry verified `file:line` evidence AND a falsifiable concrete output. |
| DOC-07 | DOCUMENTATION | Every project MUST ship `docs/claude/CLAUDE.md` in dense-lookup format — facts, file:line citations, pre-approvals — NOT human prose. |
| DOC-08 | DOCUMENTATION | `PUBLIC_API.md` MUST track `__all__` (AP-10). Companion `PUBLIC_API.json` MUST be generated from `__all__` and pinned in CI. Two pins: human-doc + machine-companion drift. |
| DOC-09 | DOCUMENTATION | Docs that name code (paths, line numbers, functions, env vars) MUST be drift-detected — either a CI lint that verifies the name exists, or a doc-comment back-reference, or both. |
| DOC-10 | DOCUMENTATION | `FEEDBACK.md` is the consumer-facing flow; `docs/inprogress/*.md` is internal posture. No cross-contamination. |
| DOC-11 | DOCUMENTATION | `docs/inprogress/` is a workspace, not a graveyard. Completed trackers SHOULD move to `docs/archive/<year>/` within one release cycle. |
| DOC-12 | DOCUMENTATION | Docs MUST be navigable by AI agents: relative links, `file:line` citation format, hierarchical `## §N` headings, no marketing prose. |
| OP-01 | OPERABILITY | The app MUST report its rich version on demand — package version + git commit SHA + active environment + key deps (Python, mgf-common, framework). CLI: `--version` rich output. Service: `/version` endpoint. |
| OP-02 | OPERABILITY | Every project MUST ship a `doctor` self-diagnostic command that probes the app's OWN state (config, persistent stores, key invariants) — distinct from any host-doctor. Output is a pass/fail checklist with `file:line` pointers on failures. |
| OP-03 | OPERABILITY | Project URLs (`Homepage` / `Documentation` / `Issues` in pyproject; URLs in `--help` / CLI errors / GUI menus) MUST resolve. CI MUST verify (HTTP-HEAD lint or no-placeholder grep). |
| OP-04 | OPERABILITY | Headline facts in `README.md` / `STARTHERE.md` / front-matter MUST match reality — phase markers, test counts, source-file counts, dep version pins, ADR statuses. The mental-model anchor for newcomers + AI agents. |
| OP-05 | OPERABILITY | Active configuration MUST be inspectable from a running app, secrets redacted per LG-04. CLI: `<app> explain` (or equivalent). Service: admin `/config` endpoint OR runtime snapshot. |
| OP-06 | OPERABILITY | Recent logs MUST be accessible without source-tree knowledge — `<app> logs` CLI, GUI Help → View Logs (LG-07), or documented aggregator URL. Path-knowledge requirement is a defect. |
| OP-07 | OPERABILITY | Every project MUST ship a `bundle` / diagnostic-tarball command producing a single attachable artefact: redacted config + last N log lines + crash reports + doctor output + system info. |
| OP-08 | OPERABILITY | State directories (crash reports, logs, ephemeral caches) MUST have bounded growth — size cap, age cap, or generational rotation. Default: 100 crash reports OR 7 days; logs 10 MB × 5 generations. |
| OP-09 | OPERABILITY | (service) Production safety guards MUST refuse dev-shaped values — mock backends, debug flags, dev tokens, sample data. `validate_production()` fails fast before listening. |
| OP-10 | OPERABILITY | (service) Every deployable artefact MUST carry a stable version tag (`image: <project>:latest` forbidden). Rollback procedure documented + exercised at least once. |
| OP-11 | OPERABILITY | (service) Every alert MUST reach a human AND link to a runbook (`annotations.runbook_url`). No business-hours gates on production-critical alerts. Paging path tested with a synthetic alert before go-live. |
| OP-12 | OPERABILITY | (service) Backup + restore MUST be exercised end-to-end against the real target (S3 / R2 / GCS production credentials), not just a CI mock. Quarterly drill recorded. |
| DEP-01 | DEPLOYMENT | (service) Cloud infrastructure (VM, network, LB, bucket, security group, DNS record, certificate) MUST be Infrastructure-as-Code. Manual console clicks are a defect. |
| DEP-02 | DEPLOYMENT | (service) VM / container state MUST be Configuration-as-Code (Ansible / Chef / Salt / cloud-init / Dockerfile). No `ssh && apt install`. |
| DEP-03 | DEPLOYMENT | (service) Release artefacts MUST be immutable per release — same git SHA produces byte-identical bytes. Dependencies locked at build time; no `pip install --upgrade` at deploy time. |
| DEP-04 | DEPLOYMENT | (service) Production secrets MUST live outside the repo, encrypted at rest. Acceptable: Ansible Vault, sealed secrets, cloud KMS / Secrets Manager, HashiCorp Vault. Per SC-01. |
| DEP-05 | DEPLOYMENT | (service) Deploy / backup / restore / rollback scripts MUST take an environment argument (prod / staging / dev) and MUST refuse bare invocation. Idempotent. |
| DEP-06 | DEPLOYMENT | (service) Deploys MUST be reversible with a documented rollback runbook ≤5 minutes from decision to restored state. Drill-tested on staging. Per OP-10. |
| DEP-07 | DEPLOYMENT | (service) The `deploy/` directory MUST follow the canonical shape: README + IaC sub-dir + config-management sub-dir + scripts/ + monitoring/ + docs/ (with phases + runbook + SLO). See DEPLOYMENT.md §3. |
| DEP-08 | DEPLOYMENT | (service) Production MUST be observable end-to-end: metrics, logs, traces flow to a queryable sink; SLI/SLO contract committed in `deploy/docs/slo.md`; alerts route to a human + link a runbook per OP-11. |
| DEP-09 | DEPLOYMENT | (service) DNS records MUST be in IaC OR a committed external-manager record list. TLS certificates MUST auto-renew (Let's Encrypt / cloud-managed). Certificate-expiry monitoring required. |
| DEP-10 | DEPLOYMENT | (service) A `deploy/docs/first-production-cut.md` runbook MUST document the green-field provisioning sequence end-to-end. Exercised at least once before go-live. |
| DEP-11 | DEPLOYMENT | (service) Every web-service consumer MUST be deployable to ≥2 environments (prod + at minimum one of staging / dev) from the same IaC + config-management code, parameterised by an environment file. |

---

## What's new in v2.7

The v2.6 → v2.7 bump introduces one new freestanding document:

- [`DEPLOYMENT.md`](DEPLOYMENT.md) — eleven MUSTs
  (DEP-01..DEP-11) defining the cross-project deployment
  standard for **stateful web-service consumer
  applications** (Django, FastAPI, Flask, async workers,
  scheduled jobs).

The rules cover **what must be true** regardless of cloud:

- Infrastructure-as-Code for every cloud resource (DEP-01).
- Configuration-as-Code for every VM-side state change (DEP-02).
- Immutable release artefacts; dependencies locked at build
  time (DEP-03).
- Secrets out of the repo, encrypted at rest (DEP-04).
- Environment-explicit deploy commands; no bare
  invocation (DEP-05).
- Reversible deploys with a documented ≤5-minute rollback
  runbook (DEP-06).
- The canonical `deploy/` directory shape with IaC + config
  + scripts + monitoring + docs (DEP-07).
- End-to-end observability with a committed SLO file +
  burn-rate alerts + runbook-linked alerts (DEP-08).
- DNS in IaC OR committed record list; TLS auto-renewal
  (DEP-09).
- A `first-production-cut.md` runbook covering green-field
  provisioning, exercised before go-live (DEP-10).
- Deployable to ≥2 environments from the same code
  (DEP-11).

The standard is **cloud-agnostic**: the rules describe
WHAT must be true, the HOW is tool-agnostic (Terraform /
Pulumi / OpenTofu / CDK for IaC; Ansible / Chef / Salt /
cloud-init for config). Reference tools are recommended,
not mandated.

**Infomaniak focus.** The Magogi foundation's main
platform is Infomaniak Public Cloud (Swiss-hosted,
OpenStack-based). §8.1 covers the Infomaniak service
catalogue + reference architecture + gaps-and-workarounds
(no managed PostgreSQL → self-hosted on a VM; no first-party
CDN → Cloudflare in front of Object Storage; no managed
Redis → self-hosted). §8.3 covers AWS / Azure / GCP shape-
translation pointers. §8.4 covers managed-platform
shapes (Fly.io / Render / Heroku) where some rules
collapse because the platform owns the VM.

**Static sites.** A thin sub-section (§8.2) covers the
static-site shape (Object Storage + CDN + DNS, no VM,
no `ansible/`); rules subset is DEP-01, 03, 04, 05, 06,
07 (simplified), 09, 10, 11.

**Reference implementations.**

- [`django-infomaniak-deploy`](https://codeberg.org/magogi-admin/django-infomaniak-deploy)
  — reusable framework. Clone-as-starting-point for a new
  Django/FastAPI consumer; produces the canonical §3
  shape via `setup.sh`.
- [`inthewords/deploy`](https://codeberg.org/magogi-admin/inthewords/src/branch/main/deploy)
  — first end-to-end consumer. Implements the full DEP-*
  matrix on Infomaniak; ships the `CLOUD_vs_LOCAL.md`
  pattern for the dev↔prod component reference.

**Relation to OPERABILITY.md.** DEP-* covers infra +
CI/CD ("how do you get bits onto servers"); OP-* covers
runtime ops ("how do you run them once they're there").
The two cross-link at the natural seams: DEP-06 ↔ OP-10
(reversible deploys); DEP-08 ↔ OP-11 (alerts route to
humans); the backup-restore drill belongs to OP-12 (DEP-*
just makes sure the deploy creates the backup target).
No content moves; the boundary is clean.

The v2.7 bump is a MINOR (eleven new MUSTs in one new
doc; no removals; no existing rule changes). Existing
consumer applications that already follow the
`inthewords/deploy` shape are immediately compliant.
Apps deploying to AWS / Azure / GCP / Fly.io / Render
apply the same rules with the shape-translation pointers
in §8.

---

## What's new in v2.8

The v2.7 → v2.8 bump introduces three new discipline bundles in
[`DOCUMENTATION.md`](DOCUMENTATION.md), driven by the inthewords
2026-05-17 starter-Suite adoption sweep where 6 of 10 filed
papers landed in the wrong FEEDBACK target:

- **DOC-01 amendment**: `FEEDBACK.md` is now the universal-five
  root doc. No more inheritance escape. Every project ships its
  own — sibling, consumer, cornerstone.
- **DOC-13 + FB-01..FB-04** (FEEDBACK discipline): repo-scoped
  feedback files; local-per-repo PAPER-NN numbering; mandatory
  metadata table fields; consumer filing discipline.
- **DOC-14 + ADP-01..ADP-04** (Adoption-tracker discipline):
  every consumer project MUST maintain `MGF_ADOPTION.md` at
  `docs/inprogress/MGF_ADOPTION.md`. Reference shapes:
  [PlasmaMapper](https://codeberg.org/magogi-admin/PlasmaMapper/src/branch/main/docs/inprogress/MGF_ADOPTION.md),
  [inthewords](https://codeberg.org/magogi-admin/inthewords/src/branch/main/docs/MGF_COMMON_ADOPTION.md).
  Federation siblings exempt per ADP-04 carve-out.
- **DOC-15 + CFM-01..CFM-04** (Conformance-tracker discipline):
  every project that adopts the standards (consumers AND
  federation siblings) MUST maintain
  `MGF_STANDARDS_CONFORMANCE.md`. Declared conformance level
  (L1 / L2 / L3) per CFM-02. Per-rule status markers
  (✅ / 🚫 / ⏳ / N/A) per CFM-03. Decline-with-rationale per
  CFM-04. Reference shape:
  [PlasmaMapper](https://codeberg.org/magogi-admin/PlasmaMapper/src/branch/main/docs/inprogress/MGF_STANDARDS_CONFORMANCE.md).

Three new templates land in
[`docs/recipes/`](../recipes/) — fork-and-fill scaffolds:

- [`feedback-md-template.md`](../recipes/feedback-md-template.md)
- [`mgf-adoption-md-template.md`](../recipes/mgf-adoption-md-template.md)
- [`mgf-standards-conformance-md-template.md`](../recipes/mgf-standards-conformance-md-template.md)

The `mgf-common catch-up` auto-block in every consumer's
`docs/CLAUDE.md` now carries **three explicit BEGIN/END
discipline sections** (feedback / adoption / conformance) so AI
agents in consumer sessions see the discipline on every session
start. Consumers receive these on their next `catch-up --apply`
run.

The v2.8 bump is a MINOR (eleven new MUSTs across one
amendment + three new rules + nine new sub-rules; no
removals; no existing rule changes beyond the DOC-01
amendment). Existing consumers that already maintain
adoption + conformance trackers (PlasmaMapper, inthewords)
are structurally compliant — just align section headings to
the templates if needed. New consumers ramp on the templates
from day one.

Full notification at
[`docs/inprogress/V2_8_NOTIFICATION.md`](../inprogress/V2_8_NOTIFICATION.md).

---

## What's new in v2.6

The v2.5 → v2.6 bump sharpens **DOC-01 + DOC-02** with a
**project-shape taxonomy** ([`DOCUMENTATION.md`](DOCUMENTATION.md) §2.0).

Three shapes exist in the MGF foundation, and the doc
requirements differ per shape:

| Shape | Distinguishing feature |
|---|---|
| **Cornerstone library** (e.g., `mgf-common`) | Sets the standards. Full eight-doc root + full six-bucket hierarchy. |
| **Federation sibling** (e.g., `mgf-django`, `mgf-fastapi`, `mgf-http`, `mgf-sqlalchemy`, `mgf-alembic`, `mgf-apiprobe`) | Small focused library. Inherits standards from the cornerstone. Universal four + `PUBLIC_API.md`. `docs/{cutover,recipes,claude}/` + a pointer-only `docs/standards/README.md`. |
| **Consumer application** (desktop / web / SaaS apps) | End-user application. Universal four (LICENSE if open-source, CHANGELOG if released). No `PUBLIC_API.md`. `docs/{inprogress,claude}/` + a pointer-only or extension-only `docs/standards/`. May add `docs/{design,adrs,runbooks}/`. |

Key changes:

- **`LICENSE` added to the universal-four** root docs. Every
  project distributed to others MUST ship a license file.
- **Per-shape applicability matrices** for both root docs
  (§2.0.1) and the `docs/` buckets (§2.0.2). A federation
  sibling no longer "fails DOC-01" by not shipping
  `FEEDBACK.md` if its only consumer is the cornerstone's
  test suite.
- **Minimum-set templates per shape** (§2.0.3) — the
  copy-pasteable starting point for a new project.
- **The `docs/standards/` pointer-only pattern** (§2.0.4) —
  non-cornerstone projects MUST NOT duplicate cornerstone
  content. The folder either holds a single pointer-README
  or holds project-specific extensions (e.g., a multi-tenant
  SaaS's `MULTI_TENANCY.md`, a frontend app's `FRONTEND.md`).
  The "NOT a duplicate" framing in the first paragraph
  prevents the freeze-in-time drift pattern.

The v2.6 bump is a MINOR (one new MUST — LICENSE — and one
clarification of DOC-01/DOC-02's scope per shape). Existing
projects that already ship `LICENSE` (the libraries do; check
the apps) are immediately compliant.

The shape declaration MUST appear in each project's `README.md`
front-matter or first paragraph (e.g., "Federation sibling of
`mgf-common`; depends on `mgf-common>=0.33,<0.34`"). A single
line tells a contributor or AI agent which rules to apply.

---

## What's new in v2.5

The v2.4 → v2.5 bump introduces one new freestanding document:

- [`OPERABILITY.md`](OPERABILITY.md) — twelve MUSTs
  (OP-01..OP-12) defining the cross-project operability
  standard. Eight universal rules (OP-01..OP-08) apply to
  every project with a UI / CLI / user-facing entry point
  (rich `--version`, self-diagnostic `doctor`, URL resolution,
  headline-facts honesty, config introspection, log access,
  diagnostic bundle, bounded state growth). Four service-only
  rules (OP-09..OP-12) apply when a real deployment +
  alerting story exists (production safety guards, versioned
  rollback, alerts-reach-humans + runbook-per-alert,
  real-target backup-restore drill).

Distilled from two real OPERABILITY trackers — one for a
web / SaaS service (46 items across alerting / deploy / DR /
docs / AI ops) and one for a desktop / CLI app (16 items
across bug-report routing / self-diagnostic / SOPs / schema
migration). The shared discipline became the standard; the
project-specific items stayed in the per-project trackers.

The framing: **operability is the orthogonal fourth concern
to reliability + security + performance — "can the human
actually run it?"** Not "in theory with a debugger"; in
practice, at 02:00, with a worried user waiting.

The v2.5 bump is a MINOR (twelve new MUSTs in one new doc;
no removals). Existing consumer code stays compliant; new
projects (or existing ones at their next operability pass)
clear the OP-01..OP-12 bar.

Every OP-* rule has a mechanical check OR a clear review-
level discipline (§6 mechanical enforcement matrix). No rule
is purely aspirational. The "applies to" column carries the
service-vs-universal split so neither web nor desktop
projects carry irrelevant burden.

---

## What's new in v2.4

The v2.3 → v2.4 bump sharpens [`LOGGING.md`](LOGGING.md) along
the **content-discipline axis** — three new MUSTs, one
promotion, and one new reference doc that make log streams
genuinely operable instead of merely structured.

Born from the maintainer's framing: *"logging is the glass that
lets me, others, and AI agents see inside running code. Rich
messages that say what happened, why it happened, and how to
address it. If we have a solid design, then we can meet this
logging requirement."*

**New MUSTs (and one promotion) in `LOGGING.md`:**

- **LG-15** — Stable event names. Every INFO+ record at a
  notable lifecycle / security / boundary event MUST carry an
  `event` field in `<subject>.<action>` form (e.g.
  `vault.read`, `bootstrap.replace`,
  `bootstrap.runtime_snapshot_failed`). Names are
  public-API-stable identifiers; rename only via deprecation
  cycle. Naming contract spelled out in §4.5 (the subject is a
  noun, the action MAY be dotted for granularity, lower-case
  throughout). Both the MUST surface (which categories of
  events DO get a name) and the carve-outs (routine INFO,
  per-record progress, free-form errors without alert
  consumers) are codified.
- **LG-16** — Message-content discipline (what / why / how).
  Every WARNING+ERROR record MUST answer three questions:
  **WHAT** (past-tense declarative message), **WHY**
  (structured `extra={}` fields — never concatenated into
  the message), **HOW** (an actionable hint when remediation
  is known — either appended to the message per EH-09 style or
  in a `hint` field). The discipline test for code review:
  *"Read the log line — can someone who has never seen the
  code (a) name what failed, (b) name why, (c) take a useful
  next step — without opening the source?"* If yes to all
  three, ship; if no to any, rewrite.
- **LG-17** — Error fingerprinting. ERROR records SHOULD carry
  a stable `fingerprint` field so observability tools (Sentry,
  Datadog, OTLP-APM) group occurrences of the same logical
  failure together. Default fingerprint is the exception's
  fully-qualified type name (formatter-computed when
  `exc_info` is set); override via the `fingerprint` extra
  field when args ARE part of identity (rate-limit-per-endpoint,
  per-tenant resource errors). SHOULD not MUST because not
  every consumer ships to a grouping backend — but the cost is
  small and the gain when a consumer DOES is large.
- **LG-11** (existing) — Promoted from SHOULD to MUST. Every
  operation ≥100 ms OR crossing a process / network / storage
  boundary MUST log a stable `operation` field at start AND
  end. The rationale: an OTel backend is not always available;
  logs MUST stand on their own. Short pure-Python helpers are
  exempt.

**New document:**

- [`docs/reference/EVENTS.md`](../reference/EVENTS.md) — the
  per-project event registry that LG-15 mandates. Seeded with
  mgf-common's 8 actual events (3 lifecycle, 3 security
  audit, 3 defense-in-depth) in the canonical row shape:
  Level / Audit / Required fields / Optional fields /
  Emitted-by-file:line / "what it means" / "what to do".
  Cross-links the closures that produced the events
  (RA-06 / RA-07 / RA-22 + the SC-11 crash-redaction layer).
  Consumers ship their own
  per-project `EVENTS.md` in the same shape — the standard is
  the format; the file in each repo is the catalogue.

**No removals.** Every v2.3 MUST still holds. Existing consumer
code passes every previous rule; new logging code (or existing
code at its next observability pass) clears the LG-11 / 15 / 16
bar. LG-17 is opt-in until a grouping backend is in scope.

**The four-piece gold-standard logging contract:**

| Piece | Rule | What it gives the operator |
|---|---|---|
| Trace identifiers | LG-11 (operation), LG-15 (event) | "find every X across users / time" via one log query |
| Content quality | LG-16 (what / why / how) | An ERROR an operator can act on without reading the source |
| Grouping | LG-17 (fingerprint) | One Sentry issue per root cause, not one per parameter |
| Registry | EVENTS.md + LG-15 contract | A stable vocabulary — event names treated as public API |

Each addition cross-references the others; the four together
turn log records from observations *about* the system into
**components of operating** the system.

---

## What's new in v2.3

The v2.2 → v2.3 bump introduces one new freestanding document
that codifies a previously-implicit cross-cutting concern:

- [`DOCUMENTATION.md`](DOCUMENTATION.md) — twelve MUSTs
  (DOC-01..DOC-12) defining the cross-project documentation
  standard. The seven mandatory root-level docs, the
  six-bucket `docs/` hierarchy, the priority-tracker shape
  (the META pattern shared by RELIABILITY_AND_ACCURACY +
  SECURITY_HARDENING + PERFORMANCE_AND_CAPACITY), the
  `CLAUDE.md` AI-agent format, the cutover-guide shape, the
  FEEDBACK.md lifecycle, the CHANGELOG-in-commit discipline,
  doc:code drift detection, AI-agent navigability rules.
  Born from the realisation that every consumer reinvents
  the docs hierarchy from scratch — codifying the shape ends
  the reinvention.

The v2.3 bump is a MINOR (twelve new MUSTs in one new doc;
no removals from existing docs) per the versioning policy.
Existing consumer code stays compliant; new projects (or
existing ones at their next docs pass) clear the DOC-01..
DOC-12 bar.

The DOC-* rules cross-link existing rules they operationalise:
DOC-04 cross-refs Keep-a-Changelog; DOC-05 cross-refs REL-07
and REL-09 (FEEDBACK→SHIPPED + notification message);
DOC-06 cross-refs the three living trackers in
`docs/inprogress/`; DOC-07 cross-refs `claude_common.md` (the
machine-level layer); DOC-08 cross-refs AP-10 + AP-13;
DOC-12 cross-refs the v2.2 "AI agents are first-class readers"
discipline.

---

## What's new in v2.2

The v2.1 → v2.2 bump is a MINOR — no removals; new patterns
codified across nine existing topic docs, driven by mgf-common's
closure of the `RELIABILITY_AND_ACCURACY.md` + `SECURITY_HARDENING.md`
trackers and the seeding of `PERFORMANCE_AND_CAPACITY.md`. Each
addition surfaces a pattern that mgf-common implemented and verified
in code; the standards now reflect the actual contracts rather than
the v0.1 sketches that preceded them.

**New patterns codified (cross-doc):**

- **Atomic-write helper as a first-class shipped component**
  (`COMMON_COMPONENTS.md` §17; `CONFIGURATION.md` §9 cross-refs).
  Three historically-divergent in-tree implementations of the
  temp + fsync + rename pattern collapsed into one shared
  helper (`mgf.common._io.atomic_write`). Closed by RA-01.
- **Crash-reporter defense-in-depth chain**
  (`SECURITY_STANDARD.md` §9.2; `ERROR_HANDLING.md` §6.3). Three
  hardening layers on top of the v0.1 EH-05 template: bounded
  `repr()` on exception args (type allowlist — custom classes
  lose state-bearing reprs), redactor pass before egress (per
  **SC-11**), and a fail-safe minimal payload when the redactor
  itself raises. Now reflected as MUSTs.
- **Redactor worst-case bounds** (`SECURITY_STANDARD.md` §9.1;
  `LOGGING.md` §6.2 template; `COMMON_COMPONENTS.md` §14).
  Depth-cap (`_MAX_REDACT_DEPTH = 64`) + cycle guard
  (`id()`-keyed `seen` set with `try / finally` discard) so a
  pathological payload cannot raise `RecursionError` mid-scrub.
  The v0.1 template was missing this; the hardened shape is
  the standard.
- **Best-effort in committed-state regions**
  (`ERROR_HANDLING.md` §7; `DESIGN_PRINCIPLES.md` §1.5
  Reliability). When a helper is called from a path that has
  already committed externally-visible state (e.g.,
  `bootstrap()` has set the global), a raise becomes an
  audit-logged WARNING — not a propagating exception that
  leaves the caller in an inconsistent state. Generalises
  EH-10 from fan-out loops to one-shot helpers. Closed by
  RA-22.
- **Perf-pin discipline beyond LG-12**
  (`LOGGING.md` §13; `TESTING.md` §8.4 + §8.5;
  `DESIGN_PRINCIPLES.md` §6). Per-call hot paths carry
  explicit budgets under a `perf` pytest marker (nightly
  sweep, NOT per-PR, so noise doesn't desensitise the team).
  Generous budgets ("current × 2-3") catch order-of-magnitude
  drift, not noise. Closed by RA-11; codified now as a SHOULD
  for any library shipping infrastructure to every consumer.
- **Pattern-coverage property tests** (`TESTING.md` §5.5). For
  scanners that check a NAMED CLASS of inputs (redactor token
  shapes, parser protocol versions, validator allowed
  identifiers), pin "for every valid sample of the class, the
  scanner catches it" via Hypothesis. Closed by RA-12.
- **Failure-injection tests** (`TESTING.md` §11.5). When a
  defensive handler catches + cleans up + re-raises, the
  CLEANUP step itself MUST have a test that injects a raise
  there. Closed by RA-02; generalises TS-09's
  raising-observer-tests-the-loop pattern.
- **Cross-platform path composition** (`CONFIGURATION.md` §10).
  Helpers building app-state paths route through
  `mgf.common.config._paths.platform_dir` (Linux XDG / macOS
  `~/Library/Application Support` / Windows
  `%LOCALAPPDATA%`) rather than hardcoding `~/.local/state`.
  Closed by RA-29.

**New patterns codified (CI):**

- **Extended-gate trio in `WORKFLOWS.md` §2.4** —
  `vuln-scan` (`pip-audit`, SC-10), `secret-scan` (`gitleaks`,
  SC-01), and `sbom` (`cyclonedx-py`, SC-18) as named gates
  above the four-gate baseline. Paste-ready
  Woodpecker recipes in `WORKFLOWS_PATTERNS.md` §5.1 + §5.2.
  The release flow's `publish` step depends on all three.
- **`<APP>_CRASH_SINK` env-var trust documented**
  (`SECURITY_STANDARD.md` §8.5 + crash-reporter reference
  doc). Env vars are a trusted input from the process owner;
  side-effect URLs sourced from env vars inherit that trust.
  Operators who can't trust their environment configure crash
  sinks via typed `MgfSettings` instead of env vars.

**New documents:**

- [`docs/inprogress/RELIABILITY_AND_ACCURACY.md`](../inprogress/RELIABILITY_AND_ACCURACY.md),
  [`docs/inprogress/SECURITY_HARDENING.md`](../inprogress/SECURITY_HARDENING.md),
  [`docs/inprogress/PERFORMANCE_AND_CAPACITY.md`](../inprogress/PERFORMANCE_AND_CAPACITY.md)
  — three living priority trackers for the library's own
  internal posture, complementing the consumer-facing
  `FEEDBACK.md`. Priority table → first wave → work units
  with verified `file:line` evidence → §5 closed items with
  commit SHAs. The format is reusable by any project; the
  trackers themselves are mgf-common-specific. `SCOPE.md` §1
  now lists the tracker discipline as an IN-scope library
  offering.
- **New shipped component:** atomic-write helper catalogued at
  `COMMON_COMPONENTS.md` §17.

**No removals.** Every v2.1 MUST still holds. Existing consumer
code stays compliant. The v2.2 additions are MUSTs in two
places (the crash-redaction / depth-cap / bounded-repr chain in
`SECURITY_STANDARD.md` §9, the atomic-write fsync MUST in
`CONFIGURATION.md` §9) and
SHOULDs in the rest; consumers that want to claim L2 conformance
SHOULD adopt the new patterns at their next reliability /
security pass.

---

## What's new in v2.1

The v2.0 → v2.1 bump introduces a single new freestanding document
that codifies what was previously a one-off section in the
-redesign doc:

- [`SCOPE.md`](SCOPE.md) — six MUSTs (SP-01..SP-06) defining the
  scope policy a "cornerstone" library must publish: explicit IN
  list, explicit OUT-of-scope list with cited alternatives,
  Adjacent list with promotion criteria, the per-PR scope-review
  question, and the every-MAJOR revisit cadence. Lifted from
  `docs/CLOSED_BOX_REDESIGN.md` §8 into the standards folder so
  it lives alongside the rest of the cross-project rules.

The v2.1 bump is a MINOR (six new MUSTs, no removals) per the
versioning policy below — existing consumer code stays compliant;
new modules added to `mgf-common` (or any project that follows
this standard) MUST clear the SP-03 review question.

## What's new in v2.0

The v1.x → v2.0 bump is driven by the introduction of two new
topic docs and the addition of new MUSTs across existing docs.
Existing code in any project MAY be non-compliant against the new
MUSTs — the version policy (below) requires a MAJOR bump for that
case.

**New documents:**

- [`SECURITY_STANDARD.md`](SECURITY_STANDARD.md) — eighteen security MUSTs
  (SC-01..SC-18), threat-model template, mechanical-enforcement
  matrix, repository-root SECURITY.md template.
- [`TESTING.md`](TESTING.md) — eighteen testing MUSTs
  (TS-01..TS-18), consolidated fixture patterns, async / GUI /
  property-test patterns, performance benchmark shape.
- [`API_DESIGN.md`](API_DESIGN.md) — fifteen API-design MUSTs
  (AP-01..AP-15), `__all__` discipline, semver rigor, deprecation
  cycle, type stability, stability tiers (experimental / stable /
  deprecated), `PUBLIC_API.md` contract, CHANGELOG migration
  recipes, backward-compat shim discipline. Addresses the
  [`FEEDBACK.md`](../../FEEDBACK.md) 🔴 Blocker
  ("no PUBLIC_API.md").

**New MUSTs in existing documents:**

- `DESIGN_PRINCIPLES.md` — DP-11 (async task ownership), DP-12
  (UTC time), DP-13 (resource release).
- `ERROR_HANDLING.md` — EH-11 (retry with exponential backoff +
  jitter), EH-12 (idempotency), EH-13 (circuit breaker).
- `LOGGING.md` — LG-13 (volume control), LG-14 (contextvars-based
  correlation).
- `CONFIGURATION.md` — CF-11 (renames-without-breaks), CF-12
  (discriminated unions for backends).

**Substantial new sections:**

- `DESIGN_PRINCIPLES.md` §11 (async/concurrency), §12 (time + dates),
  §13 (resource management), §14 (mechanical enforcement matrix).
- `ERROR_HANDLING.md` §13 (async error handling: gather discipline,
  TaskGroup, ExceptionGroup, contextvars correlation), §14 (error
  message style guide: tone, structure, identifier formatting,
  pinning the actionable-hint suffix), §15 (resilience patterns:
  retry with exponential backoff + jitter, circuit breaker,
  bulkhead, timeout cascades, idempotency).
- `LOGGING.md` §17 (rate-limit / sample / dedup), §18
  (contextvars-based correlation across `await` points).
- `CONFIGURATION.md` §16 (discriminated unions), §17 (env-tier
  layering: dev / staging / prod), §18 (field aliases for
  renames-without-breaks).
- `COMMON_COMPONENTS.md` §15 (Security infrastructure), §16 (Test
  infrastructure).

**Migration for existing consumers:**

A consumer at v1.2 compliance needs a multi-round audit across
SC-* and TS-* to reach v2.0:

1. **Audit** the SC-* matrix against the codebase (single Explore
   agent run).
2. **Adopt** the mechanical checks: `gitleaks` pre-commit,
   `pip-audit` CI step, ruff `DTZ` rules, ruff `RUF006`.
3. **Add** `tests/unit/security/` with the SC-* pin tests.
4. **Add** the repository-root `SECURITY.md` template.
5. **Audit** the TS-* matrix; close gaps.
6. **Update** `docs/STANDARDS_COMPLIANCE.md` with rows for every
   new MUST.

The estimated cost (per the cornerstone-rhythm pattern in
`COMMON_COMPONENTS.md` §"Maintaining compliance over time") is
3–4 audit→close rounds; each round is one session.

---

## Cross-references

- `mgf-common` package documentation: [`../../README.md`](../../README.md)
- Extraction history (Round 5 archive): [`../internal/EXTRACTION_HISTORY.md`](../design/extraction_history.md)
- Per-release notes: [`../../CHANGELOG.md`](../../CHANGELOG.md)
- Release-engineering discipline: [`RELEASING.md`](RELEASING.md)
- Per-consumer profiles: [`docs/reference-consumers/`](../reference-consumers/)

---

*This is a living document. When a consumer surfaces a missing standard or `mgf.common` ships a new component, update the relevant topic doc and the catalogue table above.*
