"""RA-11: per-surface perf pins beyond LG-12.

LG-12 (``test_logging_perf.py``) pins per-record logging below
100 µs. That's one hot path. The library has at least four more
surfaces where a silent perf regression would compound across the
federation:

  1. ``bootstrap()`` — cold-start cost paid on every CLI
     invocation.
  2. ``Redactor.redact_string`` — runs on every captured
     subprocess line and (transitively, via :meth:`Redactor.redact`)
     every log record's extras.
  3. ``JsonFormatter.format`` — same multiplier as redaction;
     runs on every log record under the production sink.
  4. ``current_context()`` — claimed in ``PUBLIC_API.md`` to be
     ~30 ns; not previously pinned.

Each test:
  - Warms the path with 100 reps so the first-call import / JIT
    cost is paid before the measurement window.
  - Runs N reps; computes a per-call cost.
  - Asserts against a generous budget (current measurement x 2-3)
    so CI noise doesn't false-positive.

Marker: ``perf`` (added in ``pyproject.toml``). The default
``pytest`` invocation does NOT run these — they're for the
nightly sweep (``pytest -m perf``). Same shape as LG-12's pin: a
budget breach is the signal that the surface regressed; the test
itself diagnoses where the regression landed via stderr.
"""

from __future__ import annotations

import logging
import tempfile
import time
from typing import TYPE_CHECKING

import pytest

import mgf.common
from mgf.common import _identity, current_context
from mgf.common.observability.json_formatter import JsonFormatter
from mgf.common.observability.redaction import Redactor

if TYPE_CHECKING:
    from pathlib import Path

# All perf tests carry the ``perf`` marker. Run them via
# ``pytest -m perf``; the default invocation skips them.
pytestmark = pytest.mark.perf


# Budgets are generous — current measurement x 2-3 — so CI noise
# (cold caches, GC pauses, container throttling) doesn't trip
# false positives. The point is to catch GROSS regressions
# (an order of magnitude) and silent creeping drift across
# releases. Tighten when measurements stabilise.
_CURRENT_CONTEXT_BUDGET_NS = 500.0  # measured ~170 ns
_REDACTOR_REDACT_STRING_BUDGET_US = 5.0  # measured ~1.5 µs
_JSON_FORMATTER_BUDGET_US = 30.0  # measured ~10 µs
_BOOTSTRAP_BUDGET_MS = 5.0  # measured ~1.2 ms

# PC-03: scaling pins for the Redactor. Linear scaling is the
# invariant; the ratios catch a refactor that lands an O(n²)
# shape (e.g. a nested pattern-list scan inside `_walk`). The
# absolute 1000-key budget catches the case where the per-key
# cost balloons even at linear scaling.
_REDACTOR_DICT_SCALING_RATIO_BUDGET = 12.0  # 10x linear + 20% slack
_REDACTOR_STRING_SCALING_RATIO_BUDGET = 15.0
_REDACTOR_1000_KEY_DICT_BUDGET_MS = 5.0  # measured ~0.7 ms


class TestCurrentContextPerf:
    """RA-11: ``current_context()`` is on the hot path of every
    observability call site that reads identity (`app_name()`
    chains through it). Pin the 30 ns claim from PUBLIC_API.md
    against drift."""

    def test_current_context_under_budget(self) -> None:
        # Establish a known context so the contextvar lookup hits
        # the fast path (not the unconfigured-warning fallback).
        _identity._set_identity("perf-bench", "0.0.0")

        # Warm-up.
        for _ in range(100):
            current_context()

        n = 100_000
        start = time.perf_counter()
        for _ in range(n):
            current_context()
        elapsed = time.perf_counter() - start
        per_call_ns = (elapsed / n) * 1_000_000_000

        assert per_call_ns < _CURRENT_CONTEXT_BUDGET_NS, (
            f"RA-11: current_context() budget breach: "
            f"{per_call_ns:.1f} ns/call (budget "
            f"{_CURRENT_CONTEXT_BUDGET_NS:.0f} ns). Investigate "
            f"the contextvar-vs-global resolution at "
            f"src/mgf/common/_lifecycle.py::current_context."
        )


class TestRedactorPerf:
    """RA-11: ``Redactor.redact_string`` runs on every captured
    line. A regression here is paid per-line in subprocess output."""

    def test_redact_string_under_budget(self) -> None:
        r = Redactor.default()
        # Sample chosen to exercise the BUILTIN value patterns:
        # contains a Bearer prefix that the redactor catches plus
        # neutral text the redactor scans-but-doesn't-match.
        sample = (
            "Authorization: Bearer abcdef1234567890abcdef1234567890 "
            "and some normal text after the secret"
        )

        # Warm-up.
        for _ in range(100):
            r.redact_string(sample)

        n = 50_000
        start = time.perf_counter()
        for _ in range(n):
            r.redact_string(sample)
        elapsed = time.perf_counter() - start
        per_call_us = (elapsed / n) * 1_000_000

        assert per_call_us < _REDACTOR_REDACT_STRING_BUDGET_US, (
            f"RA-11: Redactor.redact_string budget breach: "
            f"{per_call_us:.2f} µs/call (budget "
            f"{_REDACTOR_REDACT_STRING_BUDGET_US:.0f} µs). "
            f"Common cause: a new BUILTIN regex with bad worst-case "
            f"backtracking. Check the patterns in "
            f"src/mgf/common/observability/redaction.py."
        )

    def test_redactor_scales_linearly_in_dict_size(self) -> None:
        """PC-03: ``Redactor.redact`` cost grows linearly in dict
        size — a refactor that lands an O(n²) shape (e.g. a nested
        pattern-list scan inside ``_walk``) would fail this.

        Compares 100-key vs 1000-key dicts; asserts the 1000-key
        cost is < 12x the 100-key cost (linear + 20 % slack;
        quadratic would be ~100x)."""

        def _measure(n_keys: int) -> float:
            r = Redactor.default()
            payload = {
                f"key_{i}": f"Bearer abcdef1234567890abcdef1234567890_{i}"
                for i in range(n_keys)
            }
            # Warm.
            for _ in range(10):
                d = dict(payload)
                r.redact(d)
            n = 50
            t0 = time.perf_counter()
            for _ in range(n):
                d = dict(payload)
                r.redact(d)
            return (time.perf_counter() - t0) / n

        small = _measure(100)
        big = _measure(1000)
        ratio = big / small

        assert ratio < _REDACTOR_DICT_SCALING_RATIO_BUDGET, (
            f"PC-03: Redactor scaling-in-dict-size budget breach: "
            f"1000-key cost is {ratio:.1f}x the 100-key cost "
            f"(budget {_REDACTOR_DICT_SCALING_RATIO_BUDGET:.0f}x). "
            f"Expected ~10x for linear scaling. >50x suggests "
            f"O(n²) crept into `_walk` — common cause is a per-key "
            f"loop over the pattern set inside the value-pattern "
            f"matcher. Investigate "
            f"src/mgf/common/observability/redaction.py::Redactor._walk."
        )

    def test_redactor_scales_linearly_in_string_length(self) -> None:
        """PC-03: ``Redactor.redact_string`` cost grows linearly in
        the string length. A backtracking-regex regression in a
        BUILTIN pattern would surface here as super-linear scaling
        on long inputs — the per-call gate above (5 µs on a 60-byte
        string) wouldn't catch it.

        Compares 10 KB vs 100 KB strings; asserts the 100K cost is
        < 15x the 10K cost (linear + 50 % slack)."""

        r = Redactor.default()

        def _measure(n_bytes: int) -> float:
            # Mix a real Bearer token (the redactor catches) with
            # neutral payload (the redactor scans-and-misses).
            sample = (
                "Bearer abcdef1234567890abcdef1234567890 "
                + ("x" * (n_bytes - 50))
                + " trailing text"
            )
            for _ in range(10):
                r.redact_string(sample)
            n = 500
            t0 = time.perf_counter()
            for _ in range(n):
                r.redact_string(sample)
            return (time.perf_counter() - t0) / n

        small = _measure(10_000)
        big = _measure(100_000)
        ratio = big / small

        assert ratio < _REDACTOR_STRING_SCALING_RATIO_BUDGET, (
            f"PC-03: Redactor scaling-in-string-length budget breach: "
            f"100KB cost is {ratio:.1f}x the 10KB cost (budget "
            f"{_REDACTOR_STRING_SCALING_RATIO_BUDGET:.0f}x). Expected "
            f"~10x for linear scaling. A backtracking regex in the "
            f"BUILTIN pattern set is the canonical cause — check "
            f"_BUILTIN_VALUE_PATTERNS in "
            f"src/mgf/common/observability/redaction.py for new "
            f"patterns with nested quantifiers or unbounded "
            f"alternation."
        )

    def test_redactor_large_dict_under_budget(self) -> None:
        """PC-03: absolute budget for the 1000-key case. The scaling
        ratios catch shape regressions; this catches the per-key
        cost ballooning even at linear scaling (e.g. a new per-key
        allocation in `_walk` that lifts the constant factor)."""
        r = Redactor.default()
        payload = {
            f"key_{i}": f"Bearer abcdef1234567890abcdef1234567890_{i}"
            for i in range(1000)
        }
        # Warm.
        for _ in range(10):
            d = dict(payload)
            r.redact(d)
        n = 50
        t0 = time.perf_counter()
        for _ in range(n):
            d = dict(payload)
            r.redact(d)
        per_call_ms = (time.perf_counter() - t0) / n * 1000

        assert per_call_ms < _REDACTOR_1000_KEY_DICT_BUDGET_MS, (
            f"PC-03: Redactor.redact on 1000-key dict budget breach: "
            f"{per_call_ms:.2f} ms/call (budget "
            f"{_REDACTOR_1000_KEY_DICT_BUDGET_MS:.0f} ms). Linear "
            f"scaling but the constant factor doubled — look for "
            f"new allocations inside _walk or a new per-key dispatch "
            f"step in the value-pattern matcher."
        )


class TestJsonFormatterPerf:
    """RA-11: ``JsonFormatter.format`` runs on every record
    under the production logging sink. Compounds per-record."""

    def test_json_formatter_under_budget(self) -> None:
        formatter = JsonFormatter(redactor=Redactor.default())
        rec = logging.LogRecord(
            name="perf.bench",
            level=logging.INFO,
            pathname="/perf.py",
            lineno=1,
            msg="hello %s",
            args=("world",),
            exc_info=None,
        )

        # Warm-up.
        for _ in range(100):
            formatter.format(rec)

        n = 50_000
        start = time.perf_counter()
        for _ in range(n):
            formatter.format(rec)
        elapsed = time.perf_counter() - start
        per_call_us = (elapsed / n) * 1_000_000

        assert per_call_us < _JSON_FORMATTER_BUDGET_US, (
            f"RA-11: JsonFormatter.format budget breach: "
            f"{per_call_us:.2f} µs/call (budget "
            f"{_JSON_FORMATTER_BUDGET_US:.0f} µs). Investigate "
            f"per-record allocations or new OTel-context lookups."
        )


class TestAsyncHandlerEmitPerf:
    """PC-10: ``AsyncJsonHandler.emit`` must stay meaningfully faster
    than a sync formatter+sink chain. The whole reason
    ``AsyncJsonHandler`` exists is to push formatter cost off the
    calling thread; a regression that takes a lock or runs the
    formatter on the calling thread would silently re-introduce the
    sync cost.

    The pin asserts two things:
      - Absolute: per-emit cost < 18 µs (bench shows ~6 µs;
        ~3x slack matches the generous-budget philosophy).
      - Ratio: async per-emit cost < 0.5 x sync per-emit cost,
        so the test ALSO catches the regression-together case where
        the sync chain happens to slow down too.
    """

    # Per-emit budget for AsyncJsonHandler.emit (queue put + record
    # prep, NOT formatter). Local: ~6 µs; budget 18 µs.
    _ASYNC_EMIT_BUDGET_US = 18.0

    # Ratio budget: async must be at least 2x faster than the
    # equivalent sync chain (formatter + sink emit on the calling
    # thread). Local: ~2.6x; this asserts the design property, not
    # an arbitrary speedup number.
    _ASYNC_VS_SYNC_RATIO_MAX = 0.5

    _ITERATIONS = 5000

    def test_async_emit_under_budget_and_faster_than_sync(self) -> None:
        import logging

        from mgf.common.observability.async_handler import AsyncJsonHandler

        # Build a record once; we measure the emit path, not record
        # construction. Each iteration re-uses this record (same
        # contract as production: a logger.info(...) call builds a
        # record then calls handler.emit(record) once).
        record = logging.LogRecord(
            name="pc10.bench",
            level=logging.INFO,
            pathname=__file__,
            lineno=1,
            msg="pc-10 perf pin",
            args=(),
            exc_info=None,
        )

        class _FormattingSink(logging.Handler):
            """Calls self.format(record) then discards — measures
            the formatter+emit chain WITHOUT disk I/O. This is what
            a sync caller pays per record."""

            def emit(self, record: logging.LogRecord) -> None:
                # Force format on the calling thread.
                self.format(record)

        class _NullSink(logging.Handler):
            """Drains records without doing I/O. Used as the
            AsyncJsonHandler target — the drain thread runs the
            formatter, this just absorbs the drained record."""

            def emit(self, record: logging.LogRecord) -> None:
                self.format(record)

        # ---- Sync path: format on the calling thread, then emit.
        sync_sink = _FormattingSink()
        sync_sink.setFormatter(
            JsonFormatter(redactor=Redactor.default()),
        )

        sync_start = time.perf_counter()
        for _ in range(self._ITERATIONS):
            sync_sink.handle(record)
        sync_total_s = time.perf_counter() - sync_start
        sync_per_emit_us = (sync_total_s / self._ITERATIONS) * 1e6

        # ---- Async path: queue-put on the calling thread, drain
        # thread handles the formatter.
        async_target = _NullSink()
        async_target.setFormatter(
            JsonFormatter(redactor=Redactor.default()),
        )
        handler = AsyncJsonHandler(
            target=async_target, max_queue_size=self._ITERATIONS * 2,
        )

        try:
            async_start = time.perf_counter()
            for _ in range(self._ITERATIONS):
                handler.emit(record)
            async_total_s = time.perf_counter() - async_start
            async_per_emit_us = (async_total_s / self._ITERATIONS) * 1e6
        finally:
            handler.close()

        # Absolute budget check.
        assert async_per_emit_us < self._ASYNC_EMIT_BUDGET_US, (
            f"PC-10: AsyncJsonHandler.emit took "
            f"{async_per_emit_us:.2f} µs/emit (budget "
            f"{self._ASYNC_EMIT_BUDGET_US:.1f} µs). A regression that "
            f"takes a lock or runs the formatter on the calling thread "
            f"would push this over budget. Investigate "
            f"src/mgf/common/observability/async_handler.py::emit."
        )

        # Ratio check: async must be meaningfully faster than sync.
        ratio = async_per_emit_us / sync_per_emit_us
        assert ratio < self._ASYNC_VS_SYNC_RATIO_MAX, (
            f"PC-10: async/sync ratio is {ratio:.2f} "
            f"(sync {sync_per_emit_us:.2f} µs/emit, async "
            f"{async_per_emit_us:.2f} µs/emit, budget ratio < "
            f"{self._ASYNC_VS_SYNC_RATIO_MAX}). The async handler "
            f"exists to be meaningfully faster than the sync chain; "
            f"this regression means BOTH paths got slower together "
            f"(absolute budget can mask this) OR the async path "
            f"is doing sync work."
        )


class TestOperationSpanNoOpPerf:
    """PC-07: ``operation_span`` no-op cost (OTel disabled).

    Most consumers run with OpenTelemetry DISABLED in dev / CI.
    They pay the no-op-span cost on every ``with operation_span(...):``
    invocation — the import, the contextmanager protocol, and the
    fallback ``yield``.

    bench measures the ENABLED cost (~3.8 µs). This pin measures the
    DISABLED cost so consumers can see what they pay when they don't
    use OTel — and so a regression that drags real work into the
    disabled path gets caught.
    """

    # No-op cost budget. With OTel uninstalled or `setup_otel` never
    # called, the helper should be near-free — a contextmanager
    # enter/exit + a try/except import lookup. Local: ~1-2 µs.
    # Budget: 10 µs (5x slack; CI variance + slower hardware).
    _NOOP_SPAN_BUDGET_US = 10.0

    _ITERATIONS = 1000

    def test_operation_span_noop_cost_is_bounded(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path,
    ) -> None:
        from mgf.common.observability.otel_setup import operation_span

        # Bootstrap for the test so the helper can call
        # current_context() without raising UnconfiguredWarning.
        # We do NOT call setup_otel, so the span path falls into the
        # no-op branch — which is exactly what PC-07 wants to measure.
        monkeypatch.setenv("XDG_STATE_HOME", str(tmp_path))
        ctx = mgf.common.bootstrap(app_name="pc07-bench", app_version="0.0.0")
        try:
            start = time.perf_counter()
            for _ in range(self._ITERATIONS):
                with operation_span("pc07.bench", attr="x"):
                    pass
            elapsed_s = time.perf_counter() - start
        finally:
            ctx.shutdown()
        per_call_us = (elapsed_s / self._ITERATIONS) * 1e6

        assert per_call_us < self._NOOP_SPAN_BUDGET_US, (
            f"PC-07: operation_span no-op cost is {per_call_us:.2f} µs "
            f"(budget {self._NOOP_SPAN_BUDGET_US:.1f} µs). A regression "
            f"that does real work in the disabled path (eager import, "
            f"attribute encoding, etc.) would push this over. "
            f"Investigate src/mgf/common/observability/otel_setup.py::"
            f"operation_span."
        )


class TestBootstrapPerf:
    """RA-11: ``bootstrap()`` is the cold-start cost paid on
    every CLI invocation of every consumer. Budget keeps it
    snappy for short-lived commands (``mgf-common explain``,
    quick scripts)."""

    def test_bootstrap_under_budget(self, monkeypatch: pytest.MonkeyPatch) -> None:
        # Each iteration uses a fresh tmp dir so XDG_STATE_HOME
        # doesn't leak between iterations.
        durations: list[float] = []
        for _ in range(5):
            with tempfile.TemporaryDirectory() as tmp:
                monkeypatch.setenv("XDG_STATE_HOME", tmp)
                start = time.perf_counter()
                ctx = mgf.common.bootstrap(
                    app_name="perf-bench", app_version="0.0.0",
                )
                elapsed = time.perf_counter() - start
                ctx.shutdown()
                durations.append(elapsed * 1000)

        # Use median to drop the single-iteration outlier; budget
        # checks against the median, not the worst case.
        median_ms = sorted(durations)[len(durations) // 2]

        assert median_ms < _BOOTSTRAP_BUDGET_MS, (
            f"RA-11: bootstrap() budget breach: "
            f"median {median_ms:.2f} ms over {len(durations)} runs "
            f"(budget {_BOOTSTRAP_BUDGET_MS:.0f} ms). "
            f"All measurements: "
            f"{[round(d, 2) for d in durations]}. Investigate the "
            f"wiring sequence at src/mgf/common/_lifecycle.py::"
            f"_bootstrap_inner."
        )
