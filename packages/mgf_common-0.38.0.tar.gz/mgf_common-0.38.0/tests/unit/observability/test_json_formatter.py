"""Unit tests for :mod:`mgf.common.observability.json_formatter`.

Verifies the JSON shape (every documented top-level key present),
extras are promoted, exceptions are formatted, redaction runs, and
OpenTelemetry trace context is attached when a span is active (and
absent when no span / no SDK).
"""

from __future__ import annotations

import json
import logging
from typing import Any

from mgf.common.observability.json_formatter import JsonFormatter
from mgf.common.observability.redaction import REDACTED_PLACEHOLDER, Redactor


def _make_record(
    *,
    name: str = "mgf.test",
    level: int = logging.INFO,
    msg: str = "hello",
    extra: dict[str, Any] | None = None,
    exc_info: object = None,
) -> logging.LogRecord:
    record = logging.LogRecord(
        name=name,
        level=level,
        pathname="test.py",
        lineno=42,
        msg=msg,
        args=None,
        exc_info=exc_info,  # type: ignore[arg-type]
        func="test_func",
    )
    if extra:
        for k, v in extra.items():
            setattr(record, k, v)
    return record


# ---------------------------------------------------------------------------
# Shape
# ---------------------------------------------------------------------------


def test_record_shape_has_documented_top_level_keys() -> None:
    fmt = JsonFormatter(redactor=Redactor.default())
    record = _make_record(msg="started")
    out = json.loads(fmt.format(record))
    assert set(out.keys()) >= {
        "ts",
        "level",
        "logger",
        "msg",
        "module",
        "func",
        "line",
        "thread",
        "process",
    }
    assert out["msg"] == "started"
    assert out["level"] == "INFO"
    assert out["logger"] == "mgf.test"


def test_extras_are_promoted_to_top_level_keys() -> None:
    fmt = JsonFormatter(redactor=Redactor.default())
    record = _make_record(extra={"vm_name": "prod-1", "duration_ms": 142})
    out = json.loads(fmt.format(record))
    assert out["vm_name"] == "prod-1"
    assert out["duration_ms"] == 142


def test_redaction_runs_on_extras() -> None:
    fmt = JsonFormatter(redactor=Redactor.default())
    record = _make_record(extra={"password": "supersecret", "user": "alice"})
    out = json.loads(fmt.format(record))
    assert out["password"] == REDACTED_PLACEHOLDER
    assert out["user"] == "alice"


def test_one_record_is_one_line() -> None:
    fmt = JsonFormatter(redactor=Redactor.default())
    record = _make_record(extra={"vm_name": "x", "msg_count": 5})
    line = fmt.format(record)
    assert "\n" not in line


# ---------------------------------------------------------------------------
# Exception formatting
# ---------------------------------------------------------------------------


def test_exc_info_is_attached_as_exception_field() -> None:
    fmt = JsonFormatter(redactor=Redactor.default())
    try:
        raise RuntimeError("boom")
    except RuntimeError:
        import sys

        record = _make_record(level=logging.ERROR, msg="fail", exc_info=sys.exc_info())
    out = json.loads(fmt.format(record))
    assert "exception" in out
    assert "RuntimeError" in out["exception"]
    assert "boom" in out["exception"]


# ---------------------------------------------------------------------------
# OpenTelemetry trace context
# ---------------------------------------------------------------------------


def test_no_otel_no_trace_keys_in_record() -> None:
    """Without an active span (or SDK), trace keys are absent."""
    fmt = JsonFormatter(redactor=Redactor.default())
    record = _make_record(msg="no span")
    out = json.loads(fmt.format(record))
    # Either OTel is not installed at all (keys absent) OR OTel is
    # installed but no active span (keys absent because span is the
    # invalid no-op span). Either way, no trace_id / span_id present.
    assert "trace_id" not in out
    assert "span_id" not in out


# ---------------------------------------------------------------------------
# RA-20 — Dynamic _RESERVED_RECORD_ATTRS derivation
# ---------------------------------------------------------------------------


class TestRA20DynamicReservedAttrs:
    """RA-20: ``_RESERVED_RECORD_ATTRS`` is derived at module-load
    time from a probe ``LogRecord``, not hardcoded.

    Why: hardcoding risked Python 3.13+ adding a new ``LogRecord``
    attribute (the way 3.12 added ``taskName``) and that attribute
    polluting every consumer's JSON schema as a spurious top-level
    field — silently — until someone shipped a patch. The dynamic
    derivation captures whatever the current interpreter provides.
    """

    def test_derived_set_covers_every_logrecord_init_attr(self) -> None:
        """The probe's ``__dict__`` keys MUST all be in the
        reserved set — that's the whole point. If
        ``LogRecord.__init__`` added a new attribute, the test
        would fail loudly and force a refresh."""
        import logging as _logging

        from mgf.common.observability.json_formatter import (
            _RESERVED_RECORD_ATTRS,
        )

        probe = _logging.LogRecord(
            name="probe",
            level=_logging.INFO,
            pathname="<probe>",
            lineno=0,
            msg="probe",
            args=None,
            exc_info=None,
        )
        missing = set(probe.__dict__.keys()) - _RESERVED_RECORD_ATTRS
        assert missing == set(), (
            f"RA-20: probe LogRecord has attributes the reserved set "
            f"does not cover: {missing}. The derivation in "
            f"_derive_reserved_record_attrs() should already include "
            f"them — investigate the import-time invocation."
        )

    def test_derived_set_includes_formatter_added_attrs(self) -> None:
        """``message`` and ``asctime`` are populated by
        ``Formatter.format`` / ``LogRecord.getMessage``, not by
        ``__init__``, so they don't show up in the probe's
        ``__dict__``. The derivation explicitly unions them in;
        pin that union here so a refactor doesn't drop them."""
        from mgf.common.observability.json_formatter import (
            _RESERVED_RECORD_ATTRS,
        )

        assert "message" in _RESERVED_RECORD_ATTRS
        assert "asctime" in _RESERVED_RECORD_ATTRS

    def test_no_spurious_top_level_keys_on_plain_record(self) -> None:
        """The user-facing guarantee in JSON-output terms: a record
        with no ``extra={...}`` MUST produce only the documented
        top-level keys. If a future Python adds a new ``LogRecord``
        attribute that the dynamic derivation missed, that attribute
        would surface here as a spurious top-level field — exactly
        the failure mode this test exists to catch."""
        fmt = JsonFormatter(redactor=Redactor.default())
        record = _make_record(msg="hi")
        out = json.loads(fmt.format(record))
        documented = {
            "ts", "level", "logger", "msg", "module", "func",
            "line", "thread", "process",
        }
        allowed = documented | {"exception", "stack", "trace_id", "span_id"}
        spurious = set(out.keys()) - allowed
        assert spurious == set(), (
            f"RA-20: JsonFormatter produced unexpected top-level keys "
            f"on a record with no extras: {spurious}. Usually means "
            f"a LogRecord attribute was added in a Python upgrade and "
            f"the reserved-set derivation missed it — investigate "
            f"_derive_reserved_record_attrs() in json_formatter.py."
        )

    def test_explicit_extras_still_promote(self) -> None:
        """Sanity: the dynamic derivation must NOT over-reserve.
        Genuine extras (passed via ``extra={...}``) must still land
        as top-level JSON keys; otherwise the formatter is broken."""
        fmt = JsonFormatter(redactor=Redactor.default())
        record = _make_record(msg="hi")
        # Simulate ``logger.info("hi", extra={"request_id": "abc"})``.
        record.request_id = "abc"  # type: ignore[attr-defined]
        out = json.loads(fmt.format(record))
        assert out["request_id"] == "abc"
