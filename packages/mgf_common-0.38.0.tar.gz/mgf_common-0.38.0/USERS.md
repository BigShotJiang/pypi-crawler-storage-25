# USERS — who depends on mgf-common

> **Purpose:** mgf-common's user roll. Every consumer project and federation
> sibling that imports `mgf.common.*` is listed here. Knowing who uses each
> library makes deprecation, breaking-change, and feature-prioritisation
> decisions tractable.
>
> **Maintained by:** the mgf-common owner (Bassam).
> **Pairs with:** [`FEEDBACK.md`](FEEDBACK.md) (what users tell us),
> [`PUBLIC_API.md`](PUBLIC_API.md) (what we tell users).
> **Per standard DOC-16** (v2.9): every `mgf-*` library MUST maintain a
> `USERS.md` at repo root.

Last verified: 2026-05-18 (post-Wave-3 import grep across all four
local consumer projects + six local siblings).

---

## §1 Consumer projects (external users)

These are end-applications that depend on mgf-common.

| Project           | Location                                     | Import sites | Status                         | Primary surfaces used                                              |
|-------------------|----------------------------------------------|-------------:|--------------------------------|--------------------------------------------------------------------|
| **VManager**      | `/home/bassam/PycharmProjects/VManager`      | 38           | Active — mature, Qt6 desktop   | `bootstrap` / `setup_logging` / `process` / `vault` / `progress`   |
| **PlasmaMapper**  | `/home/bassam/PycharmProjects/PlasmaMapper`  | 25           | Active — multi-tenant FastAPI SaaS, heaviest adopter | `bootstrap` / `BaseAppSettings` / `db` / `observability` / `registry` |
| **iosRecovery**   | `/home/bassam/PycharmProjects/iosRecovery`   | 16           | Greenfield — CLI canary, pre-1.0 | `bootstrap` / `cli` / `process` / `progress`                       |
| **inthewords**    | `/home/bassam/PycharmProjects/inthewords`    | 12           | Behind — pinned to 0.31 (catch-up needed) | `bootstrap` / `observability` / `settings`                         |

**Reading the table.** "Heaviest adopter" + "mature" + "greenfield" status
labels reflect adoption depth (number of mgf-common surfaces in use), not
project size. The "import sites" count is a proxy for coupling — a change to
a low-coupling consumer is cheaper than to a high-coupling one.

**Consumer-side trackers.** Each consumer maintains its own adoption +
conformance tracker per standard DOC-14 / DOC-15:

- VManager: `docs/MGF_COMMON_ADOPTION.md` (status TBC — verify next session).
- PlasmaMapper: `docs/inprogress/MGF_ADOPTION.md` + `docs/inprogress/MGF_STANDARDS_CONFORMANCE.md`.
- inthewords: `docs/MGF_COMMON_ADOPTION.md`.
- iosRecovery: pre-code, no tracker yet — will land with the first code commit.

---

## §2 Federation siblings (`mgf-*` libraries)

mgf-common is the federation foundation. These are the siblings that depend
on it (directly imported from their `src/`):

| Sibling          | Import sites | Surfaces used                                          | Codeberg                                          |
|------------------|-------------:|--------------------------------------------------------|---------------------------------------------------|
| **mgf-fastapi**  | 14           | `bootstrap` / `observability` / `exceptions` / `settings` | https://codeberg.org/Bassam_AlSanie/mgf-fastapi |
| **mgf-django**   | 7            | `bootstrap` / `observability` / `exceptions`            | https://codeberg.org/Bassam_AlSanie/mgf-django   |
| **mgf-apiprobe** | 6            | `bootstrap` / `exceptions` / `observability`            | https://codeberg.org/Bassam_AlSanie/mgf-apiprobe |
| **mgf-http**     | 4            | `bootstrap` / `exceptions`                              | https://codeberg.org/Bassam_AlSanie/mgf-http     |

**Not currently importing mgf-common at runtime** (still depend on it via
pyproject pins for tests + bootstrap):

- **mgf-alembic** — wraps Alembic without needing the common runtime path;
  consumers bootstrap before invoking alembic.
- **mgf-sqlalchemy** — wraps SQLAlchemy; same pattern as above.
- **mgf-website-template** — Sphinx + theme; not a Python runtime library
  (it's a `cookiecutter` template).
- **mgf-usb** — pre-implementation scaffold (v0.0.0, design lock only).
  Will import `mgf.common.observability` + `mgf.common.exceptions` once
  v0.1.0 ships the first real surface. Planned consumers: VManager (USB
  passthrough into KVM guests) + iosRecovery (USB enumeration + DFU
  detection). See [mgf-usb/USERS.md](https://codeberg.org/magogi-admin/mgf-usb/src/branch/main/USERS.md).

These are still federation members; they just don't import `mgf.common.*`
from their own source.

---

## §3 What a "user" change MUST trigger

When a user is added, removed, or changes adoption depth:

1. Update this table.
2. Confirm the user's tracker (`MGF_COMMON_ADOPTION.md` or `MGF_ADOPTION.md`)
   exists and is current.
3. If the user is on a stale mgf-common minor (e.g., inthewords on 0.31 when
   HEAD is 0.37), open a FEEDBACK paper proposing the catch-up.

When mgf-common ships a breaking change (post-1.0):

1. Walk this table top-to-bottom. For each user, verify the breaking change
   is accounted for in their tracker.
2. If a user is not yet on the new MINOR, they get the deprecation cycle
   spelled out in the CHANGELOG.

---

## §4 How this list is maintained

This file is **the consumer + sibling ground truth** for mgf-common.
It is updated:

- On every MINOR release of mgf-common (verify import counts haven't shifted
  unexpectedly).
- When a new consumer adopts mgf-common (added to §1).
- When a consumer migrates off mgf-common (struck from §1 with date).
- When a new sibling is created (added to §2).

The methodology is reproducible:

```sh
for proj in VManager inthewords PlasmaMapper iosRecovery; do
  grep -rE "(from|import) +mgf\.common" "/home/bassam/PycharmProjects/$proj" \
    --include='*.py' | wc -l
done
```

The same shape runs across siblings — see the `import-survey` block in the
Wave 4 quality-gate sweep (`docs/inprogress/v1_0_quality_gates.md`).
