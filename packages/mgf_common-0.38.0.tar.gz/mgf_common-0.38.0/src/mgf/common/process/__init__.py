"""``mgf.common.process`` — unified subprocess + service lifecycle.

The structured replacement for raw ``subprocess.run`` and ad-hoc
"launch this dev server, wait for the port, run my smoke test, kill
it" bash. Two top-level shapes:

  - :func:`run` — one-shot subprocess wrapper with timeout, redaction,
    OTel-correlated log streaming, and structured :class:`ProcessResult`.
  - :class:`Service` — long-lived process with a readiness predicate +
    clean shutdown. Use as a context manager.

See :doc:`docs/recipes/process-management` for worked examples
and the design rationale.

Stability tier: **experimental** until two consumers exercise it
(per AP-11). Promoted to stable in a subsequent minor.

POSIX-first. Windows is best-effort: import doesn't break, but
``process_group=True`` is silently downgraded to per-PID kill, and
signal-cascade semantics differ (Windows lacks ``setsid`` / ``killpg``).
Document the asymmetry in caller-side notes if your project targets
both platforms.

By design this module does NOT cover:

  - Restart-on-crash supervision (use systemd / supervisord).
  - Restart policies + backoff machinery.
  - Multi-service dependency ordering / declarative compose-style
    orchestration. Compose multiple :class:`Service` context
    managers via :class:`contextlib.ExitStack` instead.
  - Async API. A future ``mgf.common.process._aio`` will land when
    a consumer concretely needs it.
  - Shell-string commands. Lists only — eliminates command-injection
    by construction. Pass ``["/bin/sh", "-c", "..."]`` explicitly if
    you need shell expansion, accepting the surface that comes with
    it.
"""

from __future__ import annotations

from mgf.common.process._readiness import (
    AllOf,
    AnyOf,
    CallableReady,
    HttpReady,
    LogLineReady,
    PortReady,
    ReadinessProbe,
)
from mgf.common.process._run import ProcessResult, run
from mgf.common.process._service import Service

__all__ = [
    "AllOf",
    "AnyOf",
    "CallableReady",
    "HttpReady",
    "LogLineReady",
    "PortReady",
    "ProcessResult",
    "ReadinessProbe",
    "Service",
    "run",
]
