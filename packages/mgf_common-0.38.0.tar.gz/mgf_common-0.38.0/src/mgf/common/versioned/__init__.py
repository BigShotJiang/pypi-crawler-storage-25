"""``mgf.common.versioned`` — versioned-file store primitive.

See: ``docs/recipes/versioned.md``.

A small, focused primitive for the satellite-config pattern: small
typed documents on disk (hooks files, schedules, alert specs,
profiles) with their own ``version: int`` field, unknown-key
rejection, optional migration callback, and atomic writes.

Distinct from :class:`mgf.common.config.BaseAppSettings` (which
covers the **single** top-level app-settings root with
env / dotenv / pyproject layering). Use :class:`BaseAppSettings` for
the one settings root your app loads at startup; use
:class:`VersionedFileStore` for the satellite documents around it.

Public surface::

    from mgf.common.versioned import VersionedFileStore, MigrateFn

That's the entire module. The closed-box rule applies — never import
from ``mgf.common.versioned._store``.
"""

from __future__ import annotations

from mgf.common.versioned._store import MigrateFn, VersionedFileStore

__all__ = ["MigrateFn", "VersionedFileStore"]
