"""``mgf.common.pytest_plugin`` — pytest fixtures for testing apps that use mgf-common.

Auto-registered via the ``pytest11`` entry point in ``pyproject.toml``.
After installing ``mgf-common`` (any extra) **from PyPI**, every pytest
run sees the fixtures below without further configuration. Disable
per-test with ``-p no:mgf_common``.

Editable-install caveat (PAPER-23)
----------------------------------

When mgf-common is consumed as an editable install via
``[tool.uv.sources]`` (or any tool that wires the source tree into a
sibling project without writing the dist-info ``entry_points.txt``),
the ``pytest11`` registration is silently skipped — pytest reads
entry points from installed dist-info, and ``uv sync`` against an
editable source target does not currently emit that file for sibling
projects. The fixtures still exist; they're just not auto-loaded.

Two ways to opt in explicitly when this happens:

  1. **Recommended** — add ``pytest_plugins`` to your project's
     ``tests/conftest.py``::

         pytest_plugins = ["mgf.common.pytest_plugin"]

     Pytest discovers this at collection start and loads the plugin
     before fixtures are resolved. Survives ``uv sync`` re-runs and is
     more discoverable than the entry-point form (a reader of conftest
     can see the dependency at a glance).

  2. **One-shot** — ``pytest -p mgf.common.pytest_plugin`` per
     invocation. Useful for ad-hoc verification that the plugin is on
     PYTHONPATH at all.

PyPI-installed consumers do NOT need either — the entry point fires
during ``pip install`` / ``uv pip install`` and pytest finds the
plugin automatically.

Fixtures
========

Function-scoped:

  - :func:`mgf_settings` — a fresh ``MgfSettings.testing()`` instance.
  - :func:`mgf_context` — a fresh ``AppContext`` from
    ``bootstrap_for_test``. Auto-shuts-down at test end.
  - :func:`mgf_context_with_capture` — like :func:`mgf_context` but
    with ``capture_logs=True, capture_spans=True``. Span capture
    requires :func:`mgf_otel_provider` to be active (depend on it
    explicitly, or run in the default session config below).
  - :func:`redaction_recorder` — wraps the live :class:`Redactor`
    so tests can assert what got redacted.

Session-scoped:

  - :func:`mgf_otel_provider` — installs an SDK ``TracerProvider``
    once per session. OTel's ``set_tracer_provider`` is one-shot per
    process; this fixture claims the slot for the whole test run.
    Skipped if the ``[observability]`` extra is not installed.

Why this exists
===============

The strategic review showed that every consumer reinvents test-fixture
boilerplate. The audit (v0.5 Phase A) flagged ``bootstrap_for_test`` as
unused by every consumer — not because they don't want it, but because
nobody wires the fixture themselves. Auto-registering through the
plugin closes that gap.

Tests of this module use pytest's ``pytester`` fixture to exercise
the plugin in a sub-pytest session, isolating from the live test run.

See also
========

- ``docs/recipes/testing.md`` — full walk-through.
- :func:`mgf.common.bootstrap_for_test` — the underlying helper.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import pytest

from mgf.common._test_helpers import bootstrap_for_test
from mgf.common.observability import redaction
from mgf.common.settings import MgfSettings

if TYPE_CHECKING:
    from collections.abc import Iterator

    from mgf.common._lifecycle import AppContext


# ---------------------------------------------------------------------------
# Function-scoped fixtures.
# ---------------------------------------------------------------------------


@pytest.fixture
def mgf_settings() -> MgfSettings:
    """Return a fresh :class:`MgfSettings.testing` instance for one test.

    The testing preset disables OTel auto-init, sets log level to
    WARNING, and turns off TTY-detection (deterministic regardless of
    the test runner's stdout state).
    """
    return MgfSettings.testing()


@pytest.fixture
def mgf_context(mgf_settings: MgfSettings) -> Iterator[AppContext]:
    """Yield a bootstrapped :class:`AppContext` for one test.

    The context is fully wired: identity is set, structured logging is
    active at WARNING level, the crash reporter is installed, OTel is
    disabled. ``ctx.shutdown()`` runs LIFO rollback when the test ends.

    Use this instead of calling :func:`mgf.common.bootstrap` directly
    in tests — the rollback semantics protect against state bleed
    between tests.
    """
    with bootstrap_for_test(settings=mgf_settings) as ctx:
        yield ctx


@pytest.fixture
def mgf_context_with_capture(
    mgf_settings: MgfSettings,
    mgf_otel_provider: None,
) -> Iterator[AppContext]:
    """Yield an :class:`AppContext` with log + span capture enabled.

    Tests then read ``ctx.captured_logs`` (list of ``LogRecord``) and
    ``ctx.captured_spans`` (list of OTel span proxies). Useful for
    asserting on observability output without parsing real exporter
    payloads.

    Depends on :func:`mgf_otel_provider` (session-scoped) for the
    span side. If the ``[observability]`` extra isn't installed, the
    OTel-side fixture skips and span capture won't work — log capture
    still works.
    """
    with bootstrap_for_test(
        settings=mgf_settings,
        capture_logs=True,
        capture_spans=True,
    ) as ctx:
        yield ctx


@pytest.fixture
def redaction_recorder(
    monkeypatch: pytest.MonkeyPatch,
) -> Iterator[list[dict[str, Any]]]:
    """Record every :meth:`Redactor.redact` call's pre/post payload.

    Yields a list that grows as the active redactor processes payloads.
    Each entry is ``{"input_keys": [...], "output_keys": [...],
    "input_size": int, "output_size": int}``. Useful for asserting
    that a specific Authorization header was redacted in a test that
    exercises the HTTP / log path.

    Implementation: monkeypatches :meth:`Redactor.redact` to record +
    delegate. Restored at fixture teardown.
    """
    records: list[dict[str, Any]] = []
    original = redaction.Redactor.redact

    def _recording_redact(self: redaction.Redactor, payload: dict[str, Any]) -> None:
        before_keys = list(payload.keys())
        before_size = len(payload)
        original(self, payload)
        after_keys = list(payload.keys())
        records.append(
            {
                "input_keys": before_keys,
                "output_keys": after_keys,
                "input_size": before_size,
                "output_size": len(payload),
            }
        )

    monkeypatch.setattr(redaction.Redactor, "redact", _recording_redact)
    yield records
    # monkeypatch teardown restores the original automatically.


# ---------------------------------------------------------------------------
# Session-scoped fixtures.
# ---------------------------------------------------------------------------


@pytest.fixture(scope="session")
def mgf_otel_provider() -> Iterator[None]:
    """Install an SDK :class:`TracerProvider` once per test session.

    OTel's ``trace.set_tracer_provider`` is **one-shot per process** —
    once set, every subsequent call is a silent no-op. Tests that need
    span capture MUST share a single provider for the whole session;
    this fixture is the canonical place to claim that slot.

    Skipped if the ``[observability]`` extra (`opentelemetry-sdk`) is
    not installed. Tests depending on this fixture will be skipped
    (with a useful reason); they SHOULD use :func:`mgf_context_with_capture`
    rather than depend on this directly.

    Yields ``None`` — the provider is read via
    ``opentelemetry.trace.get_tracer_provider()``.

    Cleanup: NONE. The provider remains for the rest of the session;
    OTel offers no public reset API. This is documented determinism
    leak the strategic review flagged (self-review §1) — the v0.5
    plan accepts the limitation rather than reach into OTel internals.
    """
    try:
        from opentelemetry import trace
        from opentelemetry.sdk.trace import TracerProvider
    except ImportError:
        pytest.skip("mgf-common[observability] not installed; OTel fixtures unavailable")

    # If a provider is already active (e.g., the consumer's own
    # session-scoped fixture beat us to it), defer to it.
    current = trace.get_tracer_provider()
    if isinstance(current, TracerProvider):
        yield
        return

    provider = TracerProvider()
    trace.set_tracer_provider(provider)
    yield
    # No teardown — see docstring.


# ---------------------------------------------------------------------------
# caplog convenience helper.
# ---------------------------------------------------------------------------


def decode_json_logs(caplog: pytest.LogCaptureFixture) -> list[dict[str, Any]]:
    """Return JSON-decoded records from pytest's ``caplog``.

    For tests using ``MgfSettings.testing()`` with
    ``log_format=LogFormat.JSON``, every captured ``LogRecord``'s
    formatted message is a JSON string. This helper decodes the
    records that ARE JSON and silently skips the others.

    Returns a fresh list on each call; safe to call multiple times in
    a single test.

    Not a fixture — the dependence on ``caplog`` plus pytest's
    yield-then-populate ordering makes the fixture form awkward.
    Call directly::

        def test_something(caplog: pytest.LogCaptureFixture) -> None:
            ... # do work
            decoded = decode_json_logs(caplog)
            assert decoded[0]["level"] == "WARNING"
    """
    import json

    decoded: list[dict[str, Any]] = []
    for record in caplog.records:
        try:
            decoded.append(json.loads(record.getMessage()))
        except (ValueError, TypeError):
            continue
    return decoded


__all__ = [
    "decode_json_logs",
    "mgf_context",
    "mgf_context_with_capture",
    "mgf_otel_provider",
    "mgf_settings",
    "redaction_recorder",
]
