"""JSON formatter — one JSON object per line, OTel-aware, redacted.

This is the formatter every aggregator (Loki / ELK / Splunk / Datadog
/ Cloudwatch / journald with ``--output=json``) understands out of the
box. Every record carries the OpenTelemetry ``trace_id`` and ``span_id``
when a span is active (rule LG-03). Sensitive fields are scrubbed by
the configured :class:`Redactor` before serialization (rule LG-04).

See ``docs/standards/LOGGING.md`` §5.3.

Pure stdlib + optional OTel — no other mgf.common imports beyond
the type-checking-only ``Redactor`` reference.
"""

from __future__ import annotations

import json
import logging
import time
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from mgf.common.observability.redaction import Redactor

def _derive_reserved_record_attrs() -> frozenset[str]:
    """RA-20: capture the stdlib ``LogRecord`` attribute set for THIS
    Python interpreter.

    Anything in a record's ``__dict__`` that isn't one of these is
    treated as a custom field (came from ``extra={...}``) and promoted
    to a top-level JSON key. Hardcoding the set risked Python 3.13+
    adding a new attribute (the way 3.12 added ``taskName``) and that
    attribute polluting every consumer's JSON schema as a spurious
    top-level field — silently — until someone noticed and shipped a
    patch.

    The derivation:

    1. Construct a probe :class:`logging.LogRecord` and read its
       ``__dict__`` keys — that captures every attribute set in
       ``LogRecord.__init__`` on this interpreter (including any
       future addition).
    2. Union in ``message`` and ``asctime``: those are populated by
       :meth:`logging.Formatter.format` / :meth:`LogRecord.getMessage`,
       not by ``LogRecord.__init__``, so they don't appear in the
       probe's ``__dict__`` — but they ARE stdlib-populated and MUST
       be reserved (otherwise an ``extra={"message": ...}`` would
       collide with the canonical key).

    Module-load time evaluation is intentional: zero runtime cost on
    the per-record path; one probe allocation at import.
    """
    probe = logging.LogRecord(
        name="probe",
        level=logging.INFO,
        pathname="<probe>",
        lineno=0,
        msg="probe",
        args=None,
        exc_info=None,
    )
    base = set(probe.__dict__.keys())
    base |= {"message", "asctime"}
    return frozenset(base)


# Standard ``LogRecord`` attributes — anything else in the record's
# ``__dict__`` is treated as a custom field (came from ``extra={...}``)
# and promoted to a top-level JSON key. Derived from a probe at
# module-load time so future Python versions adding new attributes
# (the way 3.12 added ``taskName``) don't pollute the JSON schema.
_RESERVED_RECORD_ATTRS: frozenset[str] = _derive_reserved_record_attrs()


class JsonFormatter(logging.Formatter):
    """Format log records as one JSON object per line.

    Output schema (top-level keys; never rename without a MAJOR bump):
      - ``ts``       — ISO-8601 UTC timestamp with millisecond precision
      - ``level``    — DEBUG / INFO / WARNING / ERROR / CRITICAL
      - ``logger``   — logger name (e.g., ``vmanager.gui.dashboard``)
      - ``msg``      — the formatted message
      - ``module``   — Python module the call was from
      - ``func``     — function name
      - ``line``     — source line number
      - ``thread``   — thread name (e.g., ``MainThread``)
      - ``process``  — process id
      - ``trace_id`` — OpenTelemetry trace id (when a span is active)
      - ``span_id``  — OpenTelemetry span id (when a span is active)
      - ``exception`` — formatted traceback (when ``exc_info`` is set)
      - ``stack``    — formatted call stack (when ``stack_info`` is set)
      - ``<extras>`` — every non-reserved key on the record (came from
                       ``extra={...}``) promoted to a top-level key

    Extras whose key collides with a reserved name are silently
    dropped (their values would be confusing) — callers who want to
    emit a field named ``msg`` MUST rename it.
    """

    def __init__(self, *, redactor: Redactor) -> None:
        super().__init__()
        self._redactor = redactor

    @property
    def redactor(self) -> Redactor:
        """The :class:`Redactor` this formatter applies before emit.

        Public, stable accessor (v0.23.0). Used by
        :func:`mgf.common.process._streamer.get_active_redactor` to
        discover the bootstrap-wired redactor without depending on
        the private ``_redactor`` attribute name.
        """
        return self._redactor

    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, Any] = {
            "ts": _iso_utc(record.created),
            "level": record.levelname,
            "logger": record.name,
            "msg": record.getMessage(),
            "module": record.module,
            "func": record.funcName,
            "line": record.lineno,
            "thread": record.threadName,
            "process": record.process,
        }

        # Promote extras (anything passed via `extra={...}`).
        for key, value in record.__dict__.items():
            if key in _RESERVED_RECORD_ATTRS or key.startswith("_"):
                continue
            payload[key] = value

        # OpenTelemetry trace context (rule LG-03). Lazy: when OTel is
        # not installed or no span is active, the keys are simply absent.
        _add_otel_context(payload)

        if record.exc_info:
            payload["exception"] = self.formatException(record.exc_info)
        if record.stack_info:
            payload["stack"] = self.formatStack(record.stack_info)

        # Redact (rule LG-04) — must happen AFTER extras are merged so
        # secrets passed via ``extra={"password": ...}`` are scrubbed.
        self._redactor.redact(payload)

        return json.dumps(payload, default=_json_default, ensure_ascii=False)


def _iso_utc(epoch: float) -> str:
    """Format a Unix epoch as ISO-8601 UTC with millisecond precision."""
    base = time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(epoch))
    millis = int((epoch - int(epoch)) * 1000)
    return f"{base}.{millis:03d}Z"


def _json_default(obj: Any) -> Any:
    """Best-effort JSON encoder for non-JSON-native types.

    ``bytes`` decoded as UTF-8 (replacement on bad sequences). Anything
    else falls back to ``repr`` so the record still serializes.
    """
    if isinstance(obj, bytes):
        return obj.decode("utf-8", errors="replace")
    return repr(obj)


def _add_otel_context(payload: dict[str, Any]) -> None:
    """Attach ``trace_id`` and ``span_id`` when an OTel span is active.

    Lazy import so the formatter works in installs without the OTel
    extra. When no span is active or OTel is uninitialised, the
    no-op ``InvalidSpan`` is returned and the keys are not added.
    """
    try:
        # ``opentelemetry.trace`` is the documented public surface for
        # ``get_current_span``. The pyproject mypy override flags the
        # whole package as missing-imports for installs without the
        # ``[observability]`` extra; with the extra installed mypy
        # gets stricter stubs but still does not surface
        # ``get_current_span`` as a top-level attribute reliably
        # across SDK versions. ``getattr`` keeps both paths working.
        from opentelemetry import trace
    except ImportError:
        return
    get_current_span = getattr(trace, "get_current_span", None)
    if get_current_span is None:
        return
    span = get_current_span()
    ctx = span.get_span_context() if span is not None else None
    if ctx is not None and ctx.is_valid:
        payload["trace_id"] = format(ctx.trace_id, "032x")
        payload["span_id"] = format(ctx.span_id, "016x")


__all__ = ["JsonFormatter"]
