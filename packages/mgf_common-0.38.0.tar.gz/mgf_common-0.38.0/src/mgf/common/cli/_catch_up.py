"""``mgf-common catch-up`` — audit + update an existing project against current standards.

Closes the v0.11.0 deliverable: existing projects (VManager,
inthewords, future adopters) need an audit-and-update flow, not
the create-from-scratch shape ``init-project`` ships. ``catch-up``:

  - Reads the project's pyproject.toml + docs/CLAUDE.md +
    .claude/settings.json + (optionally) src/.
  - Compares against the current init-project templates +
    standards.
  - Prints a drift report (✅ / ⚠️ / 🔴 per row).
  - With ``--apply``, performs ONLY safe mechanical updates:
    creates missing files, refreshes the auto-managed CLAUDE.md
    block (between BEGIN/END markers), backs up originals.
    Pyproject snippets and v0.1-pattern migrations are surfaced
    as suggestions, not auto-modified — too easy to clobber
    project-specific config.

Read-only by default. ``--apply`` is the explicit opt-in.
"""

from __future__ import annotations

import ast
import re
import sys
import time
from pathlib import Path
from typing import TYPE_CHECKING, Literal

from mgf.common.cli._init_project import (
    CLAUDE_MD_BEGIN_MARKER,
    CLAUDE_MD_END_MARKER,
    _render_claude_md,
    _render_claude_settings,
)

if TYPE_CHECKING:
    import argparse
    from collections.abc import Callable


_Severity = Literal["ok", "warn", "fail", "info"]
_SEVERITY_ICON: dict[_Severity, str] = {
    "ok": "✅",
    "warn": "⚠️ ",
    "fail": "🔴",
    "info": "ℹ️ ",  # noqa: RUF001 — INFORMATION SOURCE is intentional
}


class _Finding:
    """One row in the audit report."""

    __slots__ = ("detail", "fix", "severity", "title")

    def __init__(
        self,
        severity: _Severity,
        title: str,
        detail: str,
        fix: Callable[[Path], str] | None = None,
    ) -> None:
        self.severity = severity
        self.title = title
        self.detail = detail
        self.fix = fix


def add_catch_up_args(parser: argparse.ArgumentParser) -> None:
    """Register the ``catch-up`` subcommand's arguments."""
    parser.add_argument(
        "--path",
        type=Path,
        default=Path.cwd(),
        help=(
            "Target project root (default: current working directory). "
            "Must contain a pyproject.toml or be the root of a project "
            "that depends on mgf-common."
        ),
    )
    parser.add_argument(
        "--apply",
        action="store_true",
        help=(
            "Apply mechanical fixes (create missing CLAUDE.md / "
            ".claude/settings.json; refresh CLAUDE.md auto-block "
            "between BEGIN/END markers). Originals are backed up to "
            "<file>.bak.<timestamp>. Read-only without this flag."
        ),
    )
    parser.add_argument(
        "--name",
        help=(
            "Project name (used when CLAUDE.md is missing entirely "
            "and we need to render a fresh one). Defaults to the "
            "project's name from pyproject.toml."
        ),
    )
    parser.add_argument(
        "--kind",
        choices=("cli", "fastapi", "django", "library", "service"),
        help=(
            "Project kind (used when CLAUDE.md is missing entirely). "
            "Defaults to 'library' if it can't be guessed."
        ),
    )


def run_catch_up(args: argparse.Namespace) -> int:
    """Run the audit, optionally apply fixes."""
    target_dir = args.path.resolve()
    if not target_dir.is_dir():
        print(
            f"error: target path {target_dir} is not a directory.",
            file=sys.stderr,
        )
        return 1

    project_name, project_kind = _resolve_project_identity(target_dir, args)

    findings: list[_Finding] = []
    findings.append(_check_pyproject_pin(target_dir))
    findings.append(_check_four_gates(target_dir))
    findings.append(_check_claude_md(target_dir, project_name, project_kind))
    findings.append(_check_claude_settings(target_dir, project_kind))
    findings.append(_check_v01_patterns(target_dir))
    findings.append(_check_closed_box_leaks(target_dir))
    findings.append(_check_federation_contract(target_dir, project_name))

    _print_report(findings, target_dir, project_name, project_kind)

    if not args.apply:
        # Read-only mode. Done.
        return _exit_code_for(findings)

    # --apply mode: run any fixes that are safe + automatic.
    print()
    print("Applying mechanical fixes …")
    # PAPER-44: snapshot existing `.bak.<unix-timestamp>` files
    # BEFORE the apply loop so we can identify (and clean up)
    # only the backups WE wrote, not pre-existing ones.
    baks_before = _scan_timestamp_backups(target_dir)

    applied = 0
    for finding in findings:
        if finding.fix is None:
            continue
        result = finding.fix(target_dir)
        print(f"  {_SEVERITY_ICON['info']} {finding.title}: {result}")
        applied += 1
    if applied == 0:
        print("  (nothing to apply — everything mechanical is already current.)")
        return _exit_code_for(findings)

    # PAPER-44: auto-clean .bak.<unix-timestamp> backups on
    # verified success. Re-run the same checks; if no finding
    # carries a `fix` (i.e., the mechanical issues are now
    # resolved), the safety-net backups served their purpose and
    # can be removed. If verification fails, retain the backups
    # and tell the consumer where they are.
    new_baks = _scan_timestamp_backups(target_dir) - baks_before
    verify_findings = [
        _check_pyproject_pin(target_dir),
        _check_four_gates(target_dir),
        _check_claude_md(target_dir, project_name, project_kind),
        _check_claude_settings(target_dir, project_kind),
        _check_v01_patterns(target_dir),
        _check_closed_box_leaks(target_dir),
        _check_federation_contract(target_dir, project_name),
    ]
    verify_clean = all(f.fix is None for f in verify_findings)

    print()
    print(f"Applied {applied} mechanical fix(es).")
    if new_baks and verify_clean:
        cleaned = 0
        for bak in sorted(new_baks):
            try:
                bak.unlink()
                cleaned += 1
            except OSError as exc:
                print(f"  warning: failed to clean {bak.name}: {exc}", file=sys.stderr)
        print(
            f"Verified clean — cleaned up {cleaned} backup file"
            f"{'s' if cleaned != 1 else ''} (.bak.<timestamp>)."
        )
    elif new_baks:
        print(
            f"Retained {len(new_baks)} backup file"
            f"{'s' if len(new_baks) != 1 else ''} — re-audit is not yet "
            f"clean. Inspect:"
        )
        for bak in sorted(new_baks):
            print(f"    {bak.relative_to(target_dir)}")
        print(
            "Re-run `mgf-common catch-up` after addressing the "
            "remaining findings; the next clean run will sweep the "
            "backups."
        )
    print(
        "Tip: add `**/*.bak.[0-9]*` to your `.gitignore` so future "
        "catch-up backups can't be accidentally committed."
    )

    return _exit_code_for(verify_findings)


def _scan_timestamp_backups(target_dir: Path) -> set[Path]:
    """Return the set of ``.bak.<unix-timestamp>`` files under ``target_dir``.

    Used by ``--apply`` (PAPER-44) to identify which backups were
    written by the current run vs pre-existing ones. The unix-
    timestamp suffix pattern is specific enough that it won't match
    consumer-authored ``.bak`` files (which typically have no suffix
    or a human-readable one like ``.bak-2024-01-15``).

    Skips ``_AUDIT_SKIP_DIRS`` so the scan stays bounded — same
    discipline as the audit walks elsewhere in this module.
    """
    out: set[Path] = set()
    if not target_dir.is_dir():
        return out
    for path in target_dir.rglob("*.bak.*"):
        if any(part in _AUDIT_SKIP_DIRS for part in path.parts):
            continue
        # `Path("foo.toml.bak.1747000000").suffix` is ".1747000000".
        # If the suffix is all digits after the leading dot, it
        # matches the catch-up backup naming convention.
        if path.suffix.lstrip(".").isdigit():
            out.add(path)
    return out


# ---------------------------------------------------------------------------
# Identity resolution.
# ---------------------------------------------------------------------------


def _resolve_project_identity(
    target_dir: Path,
    args: argparse.Namespace,
) -> tuple[str, str]:
    """Resolve project name + kind from CLI args + pyproject.toml.

    v0.17.2+: kind detection is heuristic when not given on the
    CLI. Closes PAPER-13 (no pyproject case) + PAPER-17 (with
    pyproject case). Returns one of the existing init-project
    template kinds: ``cli``, ``fastapi``, ``django``, ``library``,
    ``service``. Default fall-through is ``library`` when no
    framework / scripts / Django-marker is found.
    """
    name = args.name
    kind = args.kind

    if name is None:
        name = _read_pyproject_name(target_dir) or target_dir.name
    if kind is None:
        kind = _detect_kind(target_dir)

    return name, kind


def _detect_kind(target_dir: Path) -> str:
    """Heuristic kind detection. Returns one of cli / fastapi /
    django / library / service. Closes PAPER-13 + PAPER-17.

    Resolution ladder, most-specific first:

      1. ``pyproject.toml`` deps + scripts (PAPER-17). Reads
         ``[project] dependencies`` and ``[project.scripts]``;
         framework markers in deps → ``fastapi`` / ``django``;
         non-empty scripts without framework → ``cli``;
         otherwise → ``library``.
      2. No-pyproject markers (PAPER-13). ``manage.py`` at the
         project root → ``django``. Other no-pyproject project
         shapes fall through to ``library`` (the default).
    """
    pp_kind = _detect_kind_from_pyproject(target_dir)
    if pp_kind is not None:
        return pp_kind
    np_kind = _detect_kind_no_pyproject(target_dir)
    if np_kind is not None:
        return np_kind
    return "library"


def _detect_kind_from_pyproject(target_dir: Path) -> str | None:
    """PAPER-17: parse pyproject.toml deps + scripts to detect kind.

    Returns ``None`` when there's no pyproject.toml — the caller
    falls through to the no-pyproject heuristic.
    """
    pp = target_dir / "pyproject.toml"
    if not pp.is_file():
        return None
    try:
        text = pp.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return None

    # Cheap line-grep: pyproject can't be parsed without tomllib /
    # tomli, and we want to stay stdlib-only on 3.11+. The heuristic
    # is forgiving — match the canonical declaration shape.
    deps_block = _extract_block(text, "dependencies")
    scripts_block = _extract_block(text, "[project.scripts]")

    deps_lower = deps_block.lower() if deps_block else ""

    # Framework markers (most-specific first).
    if re.search(r'["\']fastapi(?:\[|>=|<|=|~|"|\')', deps_lower):
        return "fastapi"
    if re.search(r'["\']django(?:\[|>=|<|=|~|"|\')', deps_lower):
        return "django"
    if re.search(r'["\']flask(?:\[|>=|<|=|~|"|\')', deps_lower):
        # No 'flask' in init-project's _KINDS today; closest match
        # is 'service' (generic web/service shape).
        return "service"

    # CLI shape — has console scripts, no web framework above.
    if scripts_block and "=" in scripts_block:
        return "cli"

    # No framework, no scripts → real library.
    return "library"


def _extract_block(text: str, marker: str) -> str | None:
    """Pull the ``[project] dependencies = [ ... ]`` array text or a
    section block following ``[project.scripts]``. Returns None when
    the marker isn't found. Cheap; doesn't validate TOML structure
    beyond what the heuristic needs."""
    if marker == "dependencies":
        # `dependencies = [ ... ]` — multiline array.
        m = re.search(r"^\s*dependencies\s*=\s*\[", text, re.MULTILINE)
        if m is None:
            return None
        # Find the matching closing bracket. Naive but fine for our
        # use — pyproject deps don't nest arrays.
        start = m.end()
        depth = 1
        i = start
        while i < len(text) and depth > 0:
            if text[i] == "[":
                depth += 1
            elif text[i] == "]":
                depth -= 1
            i += 1
        return text[start:i]
    # Section header marker like "[project.scripts]" — return the body
    # until the next section header.
    idx = text.find(marker)
    if idx == -1:
        return None
    body_start = text.find("\n", idx) + 1
    next_section = re.search(r"^\s*\[", text[body_start:], re.MULTILINE)
    body_end = body_start + next_section.start() if next_section else len(text)
    return text[body_start:body_end]


def _detect_kind_no_pyproject(target_dir: Path) -> str | None:
    """PAPER-13: detect kind when pyproject.toml is absent.

    ``manage.py`` at the project root → ``django`` (Django's
    canonical project layout marker). Other no-pyproject shapes
    return None (let the caller fall through to ``library``).
    """
    if (target_dir / "manage.py").is_file():
        return "django"
    return None


def _has_pip_tools_layout(target_dir: Path) -> bool:
    """PAPER-15: detect a pip-tools-style requirements layout.

    True if ``requirements/`` exists with at least one ``.txt`` /
    ``.lock`` inside, OR if a top-level ``requirements.txt`` /
    ``requirements.lock`` exists. v0.32.0 onwards, detection drives
    the full pin + four-gate audit via ``_check_pin_in_requirements``
    and ``_check_four_gates_standalone``.
    """
    req_dir = target_dir / "requirements"
    if req_dir.is_dir() and any(
        p.is_file() and p.suffix in (".txt", ".lock") for p in req_dir.iterdir()
    ):
        return True
    return (target_dir / "requirements.txt").is_file() or (
        target_dir / "requirements.lock"
    ).is_file()


def _read_pyproject_name(target_dir: Path) -> str | None:
    """Pull `[project] name = "..."` from pyproject.toml."""
    pyproject = target_dir / "pyproject.toml"
    if not pyproject.is_file():
        return None
    try:
        text = pyproject.read_text(encoding="utf-8")
    except OSError:
        return None
    match = re.search(
        r'^\s*name\s*=\s*"([^"]+)"',
        text,
        re.MULTILINE,
    )
    return match.group(1) if match else None


# ---------------------------------------------------------------------------
# Individual audit checks. Each returns one _Finding.
# ---------------------------------------------------------------------------


def _is_editable_install() -> bool:
    """Return True if the running mgf-common is installed editable.

    Editable installs (``pip install -e ../mgf_common``,
    ``[tool.uv.sources]`` workspace pins) can run AHEAD of the
    latest PyPI-published version. Auto-rewriting a consumer's pin
    against an editable install produces a pin that no plain-PyPI
    resolver can satisfy (closes PAPER-20).

    Detection uses ``importlib.metadata.distribution(...).read_text(
    "direct_url.json")`` — the marker PEP 660 editable installers
    write to dist-info. Any ``"dir_info": {"editable": true}`` flag
    in the JSON means we're running from an editable.
    """
    import importlib.metadata
    import json
    try:
        dist = importlib.metadata.distribution("mgf-common")
    except importlib.metadata.PackageNotFoundError:
        return False
    try:
        raw = dist.read_text("direct_url.json")
    except (OSError, FileNotFoundError):
        return False
    if raw is None:
        return False
    try:
        payload = json.loads(raw)
    except json.JSONDecodeError:
        return False
    return bool(payload.get("dir_info", {}).get("editable"))


def _check_pyproject_pin(target_dir: Path) -> _Finding:
    """Is the mgf-common pin in the project's manifest current?

    Despite the name (kept stable for the historical test surface),
    this dispatches across the dep-manifest types this audit recognises:

      - ``pyproject.toml`` (PEP 621)
      - pip-tools layout (``requirements/*.txt`` + ``requirements.txt``
        at root) — PAPER-15 full support, v0.32.0

    v0.12.0+: when the pin's upper bound excludes the running
    mgf-common version (i.e., pin is stale), the finding gets a
    ``fix=`` callable that ``--apply`` can invoke to rewrite the
    line to a current 2-minor window (``>=<current>,<<major>.<minor+2>``).
    Conservative: only rewrites lines whose shape we fully understand.

    v0.17.1+: when the running mgf-common is an editable install
    (`pip install -e ../mgf_common`), the auto-rewrite is REFUSED
    — editable installs can be ahead of PyPI, and rewriting a
    consumer's pin to ``>=<editable_version>`` produces a pin no
    plain-PyPI resolver can satisfy. The audit row still surfaces
    the staleness; the consumer rewrites the pin by hand against
    `pip index versions mgf-common`. Closes PAPER-20.

    v0.32.0+: when no ``pyproject.toml`` is present, a pip-tools
    ``requirements/*.{txt,lock}`` layout is audited as a first-class
    manifest. The pin is read from (in order) ``requirements/base.txt``,
    ``requirements/main.txt``, ``requirements/runtime.txt``, or the
    flat ``requirements.txt`` at the project root. Staleness +
    auto-rewrite + editable-install guard all apply uniformly. Closes
    PAPER-15 (the partial v0.17.2 message-only treatment is replaced
    with a real audit row).
    """
    pyproject = target_dir / "pyproject.toml"
    if not pyproject.is_file():
        # PAPER-15 (v0.32.0): full pip-tools manifest audit.
        if _has_pip_tools_layout(target_dir):
            return _check_pin_in_requirements(target_dir)
        return _Finding(
            "warn",
            "pyproject.toml — mgf-common pin",
            "no pyproject.toml found; standards adoption usually needs one.",
        )

    try:
        text = pyproject.read_text(encoding="utf-8")
    except OSError as exc:
        return _Finding(
            "fail",
            "pyproject.toml — mgf-common pin",
            f"could not read pyproject.toml: {exc}",
        )

    pin_match = re.search(
        r'"(mgf-common(?:\[[^\]]+\])?)\s*([^"]*)"',
        text,
    )
    if pin_match is None:
        return _Finding(
            "warn",
            "pyproject.toml — mgf-common pin",
            "no `mgf-common` dep found. Add it to "
            "`[project] dependencies`. See `mgf-common standards "
            "components` for the canonical pin shape.",
        )

    from mgf.common import __version__ as current

    pin_extras_part = pin_match.group(1)  # e.g., "mgf-common" or "mgf-common[fastapi]"
    pin_constraint = pin_match.group(2).strip(", ")
    if not pin_constraint:
        return _Finding(
            "info",
            "pyproject.toml — mgf-common pin",
            f"unpinned dep on `mgf-common`. Suggest pinning to "
            f"`>={current},<{_next_major(current)}`.",
        )

    # Determine if the pin is stale: does the upper bound exclude
    # the running mgf-common version?
    is_stale = _pin_is_stale(pin_constraint, current)
    if not is_stale:
        return _Finding(
            "ok",
            "pyproject.toml — mgf-common pin",
            f"declared (constraint: `{pin_constraint}`; current "
            f"mgf-common: `{current}`). Pin window includes "
            f"current; nothing to do.",
        )

    new_constraint = f">={current},<{_next_major(current)}"

    if _is_editable_install():
        # Editable installs can run ahead of PyPI; refusing the
        # auto-rewrite avoids producing a pin no plain-PyPI
        # resolver can satisfy. Per PAPER-20.
        return _Finding(
            "warn",
            "pyproject.toml — mgf-common pin",
            f"STALE: declared `{pin_constraint}` but current "
            f"(editable-install) mgf-common is `{current}`. "
            f"NOT auto-rewriting — editable installs can be "
            f"AHEAD of PyPI, and rewriting to "
            f"`>={current},<{_next_major(current)}` would "
            f"produce a pin no plain-PyPI resolver can satisfy. "
            f"Verify the latest PyPI-published window with "
            f"`pip index versions mgf-common` and bump the pin "
            f"by hand to that window.",
        )

    return _Finding(
        "warn",
        "pyproject.toml — mgf-common pin",
        f"STALE: declared `{pin_constraint}` but current "
        f"mgf-common is `{current}` — the upper bound excludes it. "
        f"Suggest bumping to `{new_constraint}` (2-minor window). "
        f"Run with --apply to rewrite the line; backup written.",
        fix=lambda root: _apply_bump_pin(
            root,
            extras_part=pin_extras_part,
            old_constraint=pin_constraint,
            new_constraint=new_constraint,
        ),
    )


def _pin_is_stale(constraint: str, current_version: str) -> bool:
    """Return True if ``current_version`` is excluded by the pin's upper bound.

    Parses the constraint string (PEP 440-ish, comma-separated). Recognises
    ``<X.Y[.Z]`` upper bounds (the canonical shape mgf-common projects
    use). Anything else (no upper bound, unparseable, or non-`<` bound)
    returns False — better to under-flag than to rewrite blindly.
    """
    upper_match = re.search(r"<\s*([0-9]+)\.([0-9]+)(?:\.([0-9]+))?", constraint)
    if upper_match is None:
        return False  # No `<X.Y` upper bound — can't reason; trust the user.

    upper_major = int(upper_match.group(1))
    upper_minor = int(upper_match.group(2))
    upper_patch = int(upper_match.group(3)) if upper_match.group(3) else 0

    cur_parts = current_version.split(".")
    if len(cur_parts) < 2:
        return False
    try:
        cur_major = int(cur_parts[0])
        cur_minor = int(cur_parts[1])
        cur_patch = int(cur_parts[2]) if len(cur_parts) >= 3 else 0
    except ValueError:
        return False

    # Strict-less than comparison: stale iff (cur_major, cur_minor, cur_patch)
    # >= upper bound.
    return (cur_major, cur_minor, cur_patch) >= (upper_major, upper_minor, upper_patch)


def _apply_bump_pin(
    target_dir: Path,
    *,
    extras_part: str,
    old_constraint: str,
    new_constraint: str,
) -> str:
    """Rewrite the mgf-common pin line in pyproject.toml.

    Conservative: targets ONLY the specific
    ``"mgf-common[…]<old_constraint>"`` substring, leaves the rest of
    the file untouched. Writes a backup before modifying.
    """
    pyproject = target_dir / "pyproject.toml"
    original = pyproject.read_text(encoding="utf-8")

    # Build the exact substring to find (so we don't accidentally
    # rewrite mentions of mgf-common in comments / urls).
    old_pin_str = f'"{extras_part}{old_constraint}"'
    # Some projects write "mgf-common>=0.1.0,<0.2" with no space; some
    # might have spaces. Try the exact form first.
    if old_pin_str not in original:
        # The match-group may have captured a slightly different form
        # (with spaces stripped vs preserved). Re-derive from the file.
        regex = re.compile(
            r'"(' + re.escape(extras_part) + r')\s*([^"]*)"',
        )
        match = regex.search(original)
        if match is None:
            return "could not locate the mgf-common pin line; manual edit required."
        old_pin_str = match.group(0)

    new_pin_str = f'"{extras_part}{new_constraint}"'
    rewritten = original.replace(old_pin_str, new_pin_str, 1)

    if rewritten == original:
        return "could not locate the mgf-common pin line; manual edit required."

    backup = pyproject.with_suffix(f".toml.bak.{int(time.time())}")
    backup.write_text(original, encoding="utf-8")
    # SH-04: atomic write of the consumer's pyproject.toml. The
    # backup-first ordering means a crash mid-write is already
    # recoverable, but the helper exists; use it for consistency
    # and so the consumer never sees a truncated pyproject.toml
    # window. Preserve the original mode (default 0o644 if stat
    # fails — pyproject.toml is normally world-readable).
    try:
        original_mode = pyproject.stat().st_mode & 0o777
    except OSError:
        original_mode = 0o644
    from mgf.common._io import atomic_write

    atomic_write(pyproject, rewritten, mode=original_mode)

    return f"bumped pin to `{new_constraint}` in {pyproject} (backup: {backup.name})"


def _check_four_gates(target_dir: Path) -> _Finding:
    """Are the four gates configured in the project's manifest?

    Despite the name (kept stable for the historical test surface),
    this dispatches across manifest types:

      - ``pyproject.toml`` — uses ``tomllib`` (stdlib in 3.11+) to
        parse the relevant ``[tool.*]`` tables.
      - pip-tools layout (PAPER-15, v0.32.0) — reads the four gates
        from standalone config files: ``pytest.ini`` / ``setup.cfg``
        for pytest, ``ruff.toml`` / ``.ruff.toml`` for ruff,
        ``mypy.ini`` / ``.mypy.ini`` / ``setup.cfg`` for mypy,
        ``.coveragerc`` / ``coverage.ini`` for coverage.

    Either path produces the same ``_Finding`` shape; consumers
    don't need to know which manifest type drove the answer.
    """
    import tomllib

    pyproject = target_dir / "pyproject.toml"
    if not pyproject.is_file():
        # PAPER-15 (v0.32.0): full pip-tools four-gate audit.
        if _has_pip_tools_layout(target_dir):
            return _check_four_gates_standalone(target_dir)
        return _Finding(
            "warn",
            "pyproject.toml — four gates",
            "no pyproject.toml; cannot check gate config.",
        )
    try:
        with pyproject.open("rb") as fh:
            data = tomllib.load(fh)
    except (OSError, tomllib.TOMLDecodeError) as exc:
        return _Finding(
            "fail",
            "pyproject.toml — four gates",
            f"could not parse pyproject.toml: {exc}",
        )

    tool = data.get("tool", {})
    missing: list[str] = []

    # Ruff: presence of the table is enough; specific rule selection
    # is consumer-customisable.
    if "ruff" not in tool:
        missing.append("[tool.ruff]")

    # mypy: requires the table AND `strict = true` (per DP-04).
    mypy_cfg = tool.get("mypy", {})
    if not mypy_cfg or mypy_cfg.get("strict") is not True:
        missing.append("[tool.mypy] with strict = true")

    # pytest: requires the table AND filterwarnings contains "error"
    # (per TS-04). Accepts both the single-line and multi-line array
    # forms — they produce the same parsed list.
    pytest_cfg = tool.get("pytest", {}).get("ini_options", {})
    fw = pytest_cfg.get("filterwarnings", [])
    if not pytest_cfg or "error" not in fw:
        missing.append("[tool.pytest.ini_options] with filterwarnings = ['error']")

    # coverage: any of the coverage tables (run / report / paths) is
    # acceptable as a signal that coverage is configured. fail_under
    # specifically is in [tool.coverage.report].
    coverage_cfg = tool.get("coverage", {})
    if not coverage_cfg:
        missing.append("[tool.coverage.report] with fail_under")

    if not missing:
        return _Finding(
            "ok",
            "pyproject.toml — four gates",
            "ruff / mypy strict / pytest filterwarnings=error / "
            "coverage threshold all configured.",
        )

    return _Finding(
        "warn",
        "pyproject.toml — four gates",
        "missing or partial: "
        + "; ".join(missing)
        + ". Run `mgf-common init-project --kind <kind> --dry-run "
        "--path <tmp>` to print a fresh four-gate snippet, or paste "
        "from the recipe at `mgf-common standards components`.",
    )


# ---------------------------------------------------------------------------
# PAPER-15: pip-tools manifest audit (v0.32.0)
# ---------------------------------------------------------------------------
#
# When a project declares deps via the pip-tools layout
# (``requirements/{base,dev,prod}.{txt,lock}`` + standalone gate
# config files), the pyproject-only audit can't reach them. These
# helpers give the same audit experience for those projects:
#
#   - pin reading + staleness + auto-rewrite from
#     ``requirements/base.txt`` (or main.txt / runtime.txt / flat
#     requirements.txt fallbacks)
#   - four-gate audit from standalone ``pytest.ini`` /
#     ``setup.cfg`` / ``ruff.toml`` / ``mypy.ini`` / ``.coveragerc``
#
# The findings produced match the pyproject path's shape so
# downstream rendering and the ``--apply`` runner don't care which
# manifest type drove the row.


# Probed in declared order. base.txt is the pip-tools convention for
# runtime deps; main / runtime are commonly-seen synonyms; flat
# requirements.txt is the legacy / simple-project shape.
_REQUIREMENTS_PIN_CANDIDATES = (
    ("requirements", "base.txt"),
    ("requirements", "main.txt"),
    ("requirements", "runtime.txt"),
    ("requirements.txt",),
)


def _check_pin_in_requirements(target_dir: Path) -> _Finding:
    """Read + audit the mgf-common pin from a pip-tools requirements file.

    Probes the candidate files in order; the first one containing a
    ``mgf-common`` line wins. Staleness detection + auto-rewrite +
    editable-install guard are identical to the pyproject path so the
    audit experience is uniform across manifest types.
    """
    pin_file: Path | None = None
    pin_line: str | None = None
    extras_part: str | None = None
    constraint: str | None = None

    for candidate_parts in _REQUIREMENTS_PIN_CANDIDATES:
        candidate = target_dir.joinpath(*candidate_parts)
        if not candidate.is_file():
            continue
        try:
            text = candidate.read_text(encoding="utf-8")
        except OSError:
            continue
        # Match `mgf-common[extra]>=X,<Y` at the start of a line.
        # `[ \t]*` (not `\s*`) constrains the gap to within the same
        # line — otherwise `\s*` would consume the newline and the
        # following `[^\s#]*` would slurp the NEXT line's content
        # into the constraint. Stops at whitespace or `#`; doesn't
        # capture `-r base.txt` shaped references.
        match = re.search(
            r"^(mgf-common(?:\[[^\]]+\])?)[ \t]*([^\s#]*)",
            text,
            re.MULTILINE,
        )
        if match is not None:
            pin_file = candidate
            pin_line = match.group(0)
            extras_part = match.group(1)
            constraint = match.group(2).strip(", ")
            break

    if pin_file is None or extras_part is None or pin_line is None:
        return _Finding(
            "warn",
            "requirements/* — mgf-common pin",
            "pip-tools layout detected but no `mgf-common` dep found. "
            "Add an `mgf-common>=X,<Y` line to "
            "`requirements/base.txt` (or your runtime manifest). See "
            "`mgf-common standards components` for the canonical pin shape.",
        )
    # All three are now narrowed to non-None — mypy follows the guard.

    from mgf.common import __version__ as current

    rel_path = pin_file.relative_to(target_dir)

    if not constraint:
        return _Finding(
            "info",
            "requirements/* — mgf-common pin",
            f"unpinned dep on `mgf-common` in `{rel_path}`. Suggest "
            f"pinning to `>={current},<{_next_major(current)}`.",
        )

    is_stale = _pin_is_stale(constraint, current)
    if not is_stale:
        return _Finding(
            "ok",
            "requirements/* — mgf-common pin",
            f"declared in `{rel_path}` (constraint: `{constraint}`; "
            f"current mgf-common: `{current}`). Pin window includes "
            f"current; nothing to do.",
        )

    new_constraint = f">={current},<{_next_major(current)}"

    if _is_editable_install():
        # Same editable-install guard as the pyproject path. PAPER-20.
        return _Finding(
            "warn",
            "requirements/* — mgf-common pin",
            f"STALE: declared `{constraint}` in `{rel_path}` but "
            f"current (editable-install) mgf-common is `{current}`. "
            f"NOT auto-rewriting — editable installs can be AHEAD of "
            f"PyPI, and rewriting to `>={current},<{_next_major(current)}` "
            f"would produce a pin no plain-PyPI resolver can satisfy. "
            f"Verify the latest PyPI-published window with "
            f"`pip index versions mgf-common` and bump the pin "
            f"by hand to that window.",
        )

    # Bind the file + line + new-constraint into a named closure
    # rather than a lambda — keeps mypy happy under strict mode
    # (lambdas with default-arg captures can't be inferred) and reads
    # more clearly at the call site.
    captured_pin_file = pin_file
    captured_pin_line = pin_line
    captured_new_constraint = new_constraint

    def _fix(_root: Path) -> str:
        return _apply_bump_pin_in_requirements(
            captured_pin_file,
            captured_pin_line,
            captured_new_constraint,
        )

    return _Finding(
        "warn",
        "requirements/* — mgf-common pin",
        f"STALE: declared `{constraint}` in `{rel_path}` but current "
        f"mgf-common is `{current}` — the upper bound excludes it. "
        f"Suggest bumping to `{new_constraint}` (2-minor window). "
        f"Run with --apply to rewrite the line; backup written.",
        fix=_fix,
    )


def _apply_bump_pin_in_requirements(
    pin_file: Path,
    old_pin_line: str,
    new_constraint: str,
) -> str:
    """Rewrite the mgf-common pin line in a pip-tools requirements file.

    Mirrors :func:`_apply_bump_pin` for pyproject: writes a backup,
    targets exactly the matched substring, leaves comments / other
    deps untouched.
    """
    original = pin_file.read_text(encoding="utf-8")

    # Reconstruct the new line by replacing the old constraint portion
    # in-place — keeps the extras part (``mgf-common[fastapi]``) and
    # any inline comment after the constraint untouched. Same
    # `[ \t]*` constraint as the reader so the rewriter doesn't span
    # newlines on a `mgf-common\nother-dep` shaped line.
    match = re.match(
        r"^(mgf-common(?:\[[^\]]+\])?)[ \t]*([^\s#]*)",
        old_pin_line,
    )
    if match is None:
        return "could not locate the mgf-common pin line; manual edit required."
    new_pin_line = f"{match.group(1)}{new_constraint}"

    rewritten = original.replace(old_pin_line, new_pin_line, 1)
    if rewritten == original:
        return "could not locate the mgf-common pin line; manual edit required."

    backup = pin_file.with_suffix(f"{pin_file.suffix}.bak.{int(time.time())}")
    backup.write_text(original, encoding="utf-8")
    # SH-04: atomic write — same shape as _apply_bump_pin above.
    try:
        original_mode = pin_file.stat().st_mode & 0o777
    except OSError:
        original_mode = 0o644
    from mgf.common._io import atomic_write

    atomic_write(pin_file, rewritten, mode=original_mode)

    return f"bumped pin to `{new_constraint}` in {pin_file} (backup: {backup.name})"


def _check_four_gates_standalone(target_dir: Path) -> _Finding:
    """Four-gate audit for pip-tools projects (standalone config files).

    Each gate has a list of recognised config-file locations; presence
    of any one with the required setting is enough. The "required
    setting" criteria mirror the pyproject path:

      - ``ruff``: presence of a ruff config file at all.
      - ``mypy``: presence + ``strict = True``.
      - ``pytest``: presence + ``filterwarnings`` includes ``error``.
      - ``coverage``: presence of any coverage config.
    """
    missing: list[str] = []

    if not _has_ruff_config_standalone(target_dir):
        missing.append("ruff.toml (or .ruff.toml)")

    if not _has_strict_mypy_standalone(target_dir):
        missing.append("mypy.ini (or setup.cfg [mypy]) with strict = True")

    if not _has_pytest_filterwarnings_error_standalone(target_dir):
        missing.append(
            "pytest.ini (or setup.cfg [tool:pytest]) with filterwarnings = error"
        )

    if not _has_coverage_config_standalone(target_dir):
        missing.append(".coveragerc (or coverage.ini)")

    if not missing:
        return _Finding(
            "ok",
            "requirements/* — four gates",
            "ruff / mypy strict / pytest filterwarnings=error / "
            "coverage config all present in standalone files.",
        )

    return _Finding(
        "warn",
        "requirements/* — four gates",
        "missing or partial: "
        + "; ".join(missing)
        + ". Either add standalone config files for the missing "
        "gates, or migrate the gates to a single pyproject.toml "
        "(`[tool.ruff]` / `[tool.mypy]` / `[tool.pytest.ini_options]` "
        "/ `[tool.coverage.report]`) — both layouts are recognised "
        "by this audit.",
    )


def _has_ruff_config_standalone(target_dir: Path) -> bool:
    """ruff reads ``ruff.toml`` or ``.ruff.toml`` if no pyproject section."""
    return (target_dir / "ruff.toml").is_file() or (target_dir / ".ruff.toml").is_file()


def _has_strict_mypy_standalone(target_dir: Path) -> bool:
    """mypy `strict = True` in mypy.ini / .mypy.ini / setup.cfg [mypy]."""
    for name in ("mypy.ini", ".mypy.ini"):
        path = target_dir / name
        if path.is_file() and _ini_has_strict_mypy(path, section="mypy"):
            return True
    # setup.cfg's [mypy] section is also a recognised location.
    setup_cfg = target_dir / "setup.cfg"
    return setup_cfg.is_file() and _ini_has_strict_mypy(setup_cfg, section="mypy")


def _ini_has_strict_mypy(path: Path, section: str) -> bool:
    """Return True if the named INI ``section`` has ``strict = True``."""
    import configparser

    parser = configparser.ConfigParser()
    try:
        parser.read(path, encoding="utf-8")
    except (OSError, configparser.Error):
        return False
    if section not in parser:
        return False
    strict_value = parser[section].get("strict", "").strip().lower()
    return strict_value in ("true", "1", "yes", "on")


def _has_pytest_filterwarnings_error_standalone(target_dir: Path) -> bool:
    """pytest's filterwarnings=error in pytest.ini / setup.cfg / tox.ini.

    The pytest config supports both formats:
      - INI: ``filterwarnings = error`` (or a list across lines)
      - TOML: ``filterwarnings = ["error", ...]`` (handled by the
        pyproject path, not here)

    We accept any line in the section that contains ``error`` as a
    value — pytest's matcher is itself substring-y.
    """
    candidates = [
        (target_dir / "pytest.ini", "pytest"),
        (target_dir / "setup.cfg", "tool:pytest"),
        (target_dir / "tox.ini", "pytest"),
    ]
    for path, section in candidates:
        if not path.is_file():
            continue
        if _ini_filterwarnings_has_error(path, section):
            return True
    return False


def _ini_filterwarnings_has_error(path: Path, section: str) -> bool:
    """Return True if the named INI ``section`` has ``filterwarnings``
    that includes the ``error`` action."""
    import configparser

    parser = configparser.ConfigParser()
    try:
        parser.read(path, encoding="utf-8")
    except (OSError, configparser.Error):
        return False
    if section not in parser:
        return False
    raw = parser[section].get("filterwarnings", "")
    # The value can be a single line (`error`) or multi-line (one
    # filter per line). pytest matches any line where the action is
    # `error` (possibly followed by `:` and a more specific filter).
    # The variable is called `action` (not `token`) so ruff's S105
    # "possible hardcoded password" rule doesn't false-positive on
    # the `action == "error"` comparison.
    for line in raw.splitlines():
        action = line.strip().split(":", 1)[0].strip().lower()
        if action == "error":
            return True
    return False


def _has_coverage_config_standalone(target_dir: Path) -> bool:
    """coverage.py reads ``.coveragerc`` or ``coverage.ini`` by default."""
    return (target_dir / ".coveragerc").is_file() or (
        target_dir / "coverage.ini"
    ).is_file()


def _check_claude_md(
    target_dir: Path,
    project_name: str,
    project_kind: str,
) -> _Finding:
    """Does docs/CLAUDE.md exist + does it have the auto-managed block?"""
    claude_md = target_dir / "docs" / "CLAUDE.md"
    if not claude_md.is_file():
        return _Finding(
            "fail",
            "docs/CLAUDE.md",
            "missing. Claude won't auto-load any standards on session "
            "start — manual prompting required for every task. "
            "Run with --apply to create a fresh CLAUDE.md from the "
            "current template.",
            fix=lambda root: _apply_create_claude_md(
                root,
                project_name,
                project_kind,
            ),
        )

    try:
        content = claude_md.read_text(encoding="utf-8")
    except OSError as exc:
        return _Finding(
            "fail",
            "docs/CLAUDE.md",
            f"could not read: {exc}",
        )

    has_begin = CLAUDE_MD_BEGIN_MARKER in content
    has_end = CLAUDE_MD_END_MARKER in content

    if not has_begin or not has_end:
        # PAPER-16: catch-up --apply auto-inserts the BEGIN/END
        # markers + auto-block at the top of the existing CLAUDE.md
        # (with backup), rather than forcing the consumer to choose
        # between init-project --force (which clobbers project-
        # specific content) and manual marker insertion (which is
        # undocumented).
        return _Finding(
            "warn",
            "docs/CLAUDE.md",
            "exists but lacks BEGIN/END auto-managed markers — "
            "either pre-v0.11 init-project output or hand-written. "
            "Run with --apply to bootstrap the markers + auto-block "
            "at the top of the existing file (your project-specific "
            "content stays below the END marker; original is backed "
            "up to .bak.<timestamp>). Closes PAPER-16.",
            fix=lambda root: _apply_bootstrap_claude_md_markers(
                root, project_name, project_kind,
            ),
        )

    # Compute the current expected auto-block; compare to existing.
    expected = _render_claude_md(project_name, project_kind)
    expected_block = _extract_auto_block(expected)
    actual_block = _extract_auto_block(content)

    if expected_block == actual_block:
        return _Finding(
            "ok",
            "docs/CLAUDE.md",
            "exists with current auto-managed block. "
            "Project-specific lookup preserved.",
        )

    return _Finding(
        "warn",
        "docs/CLAUDE.md",
        "exists with auto-block markers, but the auto-block content "
        "is stale relative to the current template (rules may have "
        "been added / wording changed in newer mgf-common). Run with "
        "--apply to refresh just the auto-block.",
        fix=lambda root: _apply_refresh_claude_md(
            root,
            project_name,
            project_kind,
        ),
    )


def _check_claude_settings(
    target_dir: Path,
    project_kind: str,
) -> _Finding:
    """Does .claude/settings.json exist?"""
    settings = target_dir / ".claude" / "settings.json"
    if not settings.is_file():
        return _Finding(
            "warn",
            ".claude/settings.json",
            "missing. Without it, Claude prompts for every Bash "
            "command — friction in normal dev. Run with --apply to "
            "create one with safe defaults for this project kind.",
            fix=lambda root: _apply_create_claude_settings(root, project_kind),
        )
    return _Finding(
        "ok",
        ".claude/settings.json",
        "exists. (catch-up doesn't audit allow-list contents — "
        "your team customizes them.)",
    )


def _check_v01_patterns(target_dir: Path) -> _Finding:
    """Grep src/ for v0.1-pattern usages that should migrate to bootstrap()."""
    src = target_dir / "src"
    if not src.is_dir():
        # Try the project root as a fallback.
        src = target_dir

    patterns: list[tuple[str, str]] = [
        ("mgf.common.configure(", "→ `with mgf.common.bootstrap(...)` (v0.3+)"),
        ("make_settings_config(", "→ `settings_config(...)` (v0.3+)"),
        ("setup_logging(", "→ folded into `bootstrap()` (v0.3+)"),
        ("setup_otel(", "→ folded into `bootstrap()` (v0.3+)"),
        ("install_excepthook(", "→ folded into `bootstrap()` (v0.3+)"),
        ("install_threading_excepthook(", "→ folded into `bootstrap()` (v0.3+)"),
    ]

    findings: list[str] = []
    for needle, suggestion in patterns:
        count = _count_matches(src, needle)
        if count > 0:
            findings.append(f"`{needle}` x {count}: {suggestion}")

    if not findings:
        return _Finding(
            "ok",
            "v0.1-pattern usage",
            "no legacy `configure() / setup_logging() / "
            "install_excepthook()` calls found.",
        )

    return _Finding(
        "warn",
        "v0.1-pattern usage",
        "legacy v0.1 call sites found: "
        + "; ".join(findings)
        + ". These still work via deprecation cycle, but the "
        "v0.3+ `bootstrap()` shape is the canonical replacement. "
        "Migration is NOT mechanical (the call shape changes from "
        "5 separate calls to 1 context manager); catch-up will not "
        "auto-modify. See `mgf-common standards design` for the "
        "bootstrap() pattern.",
    )


def _count_matches(root: Path, needle: str) -> int:
    """Count how many times ``needle`` appears across .py files under ``root``.

    Skips standard cache / build / vendor / venv directories per
    ``_AUDIT_SKIP_DIRS`` (closes PAPER-14 — without the skip, the
    audit walked into ``.venv/`` and counted mgf-common's own
    deprecated shim definitions as user-source v0.1 call sites,
    producing dozens of false positives on adopter projects).
    """
    if not root.is_dir():
        return 0
    total = 0
    for path in root.rglob("*.py"):
        if any(part in _AUDIT_SKIP_DIRS for part in path.parts):
            continue
        try:
            text = path.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        total += text.count(needle)
    return total


# ---------------------------------------------------------------------------
# Closed-box leak detection (rule AP-14 / DP-13). Closes FEEDBACK PAPER-08.
# ---------------------------------------------------------------------------

# Skip these directory names anywhere in a .py file's path during
# any consumer-source audit walk. Tests are intentionally exempt:
# ``tests/unit/_internal_test_helpers/`` style imports are legitimate
# consumer-side per the PAPER-08 spec. ``.venv/`` exemption is what
# closed PAPER-14 (audit was walking installed mgf-common's own
# deprecated shim definitions and counting them as user-source v0.1
# call sites).
_AUDIT_SKIP_DIRS: frozenset[str] = frozenset({
    "tests", "test", ".venv", "venv", "__pycache__",
    "node_modules", "dist", "build", ".tox", ".pytest_cache",
    ".mypy_cache", ".ruff_cache",
})

# Backward-compat alias for the original PAPER-08 name. New code uses
# _AUDIT_SKIP_DIRS.
_LEAK_SKIP_DIRS = _AUDIT_SKIP_DIRS

# Map known private symbols to their public-API replacement so the
# audit row can name the fix, not just the violation. Extend as new
# private→public promotions happen.
_PRIVATE_TO_PUBLIC: dict[str, str] = {
    "_default_log_path": "mgf.common.observability.default_log_path  (since v0.13.0)",
    "_crash_dir": "mgf.common.observability.default_crash_dir  (since v0.13.0)",
}


def _is_private_module(module: str) -> bool:
    """True when any path segment after ``mgf.common`` starts with ``_``.

    Catches:
      - ``mgf.common._x``                — module itself private
      - ``mgf.common.observability._helpers`` — nested private module
      - ``mgf.common.X.Y._z``            — deeply nested

    Excludes ``__init__`` / ``__main__`` style dunders (those aren't
    "private" in the closed-box sense).
    """
    if not module.startswith("mgf.common"):
        return False
    parts = module.split(".")
    # Skip "mgf", "common" — only the post-prefix segments can be private.
    return any(p.startswith("_") and not p.startswith("__") for p in parts[2:])


def _check_closed_box_leaks(target_dir: Path) -> _Finding:
    """AST-walk consumer src/ for imports of mgf.common's private surface.

    Closes FEEDBACK PAPER-08. Pairs with ``tests/public_surface/
    test_no_private_imports.py`` (the upstream-side AST pin); this
    is the consumer-side runtime check, surfaced as a catch-up
    audit row so consumers don't have to copy the test.

    Three leak shapes detected:
      1. ``from mgf.common._x import Y``     — module itself private
      2. ``from mgf.common.X import _y``     — public module, private name
      3. ``import mgf.common._x``            — direct private-module import

    The consumer's ``tests/`` directory is NOT walked: legitimate
    test-helper imports inside ``tests/unit/_internal_test_helpers/``
    style directories aren't violations of the closed-box rule.
    """
    src = target_dir / "src"
    if not src.is_dir():
        # Match ``_check_v01_patterns`` — fall back to project root.
        src = target_dir

    leaks: list[str] = []

    for path in src.rglob("*.py"):
        if any(part in _LEAK_SKIP_DIRS for part in path.parts):
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue
        try:
            tree = ast.parse(text, filename=str(path))
        except SyntaxError:
            # Malformed source — skip rather than abort the whole audit.
            continue

        try:
            rel = path.relative_to(target_dir).as_posix()
        except ValueError:
            rel = path.as_posix()

        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom):
                if not node.module or not node.module.startswith("mgf.common"):
                    continue
                if _is_private_module(node.module):
                    # Case 1: from mgf.common._x import ...
                    name_list = ", ".join(a.name for a in node.names)
                    leaks.append(
                        f"{rel}:{node.lineno}: "
                        f"from {node.module} import {name_list}",
                    )
                    continue
                # Case 2: from mgf.common.X import _private
                for alias in node.names:
                    if alias.name.startswith("_") and not alias.name.startswith("__"):
                        suggestion = _PRIVATE_TO_PUBLIC.get(
                            alias.name,
                            "use the public alternative from `mgf-common standards api`",
                        )
                        leaks.append(
                            f"{rel}:{node.lineno}: "
                            f"from {node.module} import {alias.name} → {suggestion}",
                        )
            elif isinstance(node, ast.Import):
                # Case 3: import mgf.common._x
                for alias in node.names:
                    if _is_private_module(alias.name):
                        leaks.append(f"{rel}:{node.lineno}: import {alias.name}")

    if not leaks:
        return _Finding(
            "ok",
            "closed-box leaks (private mgf.common imports)",
            "no `mgf.common._*` or `mgf.common.X._private` imports "
            "found in src/.",
        )

    leaks.sort()
    shown = leaks[:8]
    extra = len(leaks) - len(shown)
    body = "; ".join(shown)
    if extra > 0:
        body += f"; … and {extra} more"

    return _Finding(
        "warn",
        "closed-box leaks (private mgf.common imports)",
        f"private mgf.common imports found ({len(leaks)} site(s)): "
        f"{body}. Closed-box rule (AP-14 / DP-13): consumers MUST NOT "
        "import `mgf.common._*` modules or names starting with `_` "
        "from public modules — the private surface MAY change in any "
        "release. Replace with the public equivalent (printed inline "
        "above when known).",
    )


# ---------------------------------------------------------------------------
# Apply functions. Called only when --apply is passed.
# ---------------------------------------------------------------------------


def _apply_create_claude_md(
    target_dir: Path,
    project_name: str,
    project_kind: str,
) -> str:
    """Create a fresh CLAUDE.md."""
    path = target_dir / "docs" / "CLAUDE.md"
    path.parent.mkdir(parents=True, exist_ok=True)
    # SH-04: atomic write — this is a CREATE (no original to
    # preserve mode for); use the typical doc default 0o644.
    from mgf.common._io import atomic_write

    atomic_write(
        path, _render_claude_md(project_name, project_kind), mode=0o644,
    )
    return f"created {path}"


def _apply_refresh_claude_md(
    target_dir: Path,
    project_name: str,
    project_kind: str,
) -> str:
    """Refresh just the auto-managed block of an existing CLAUDE.md."""
    path = target_dir / "docs" / "CLAUDE.md"
    original = path.read_text(encoding="utf-8")

    # Backup before modifying.
    backup = path.with_suffix(f".md.bak.{int(time.time())}")
    backup.write_text(original, encoding="utf-8")

    new_full = _render_claude_md(project_name, project_kind)
    new_auto_block = _extract_auto_block(new_full)

    # Splice: keep everything BEFORE the BEGIN marker + the new
    # auto-block + everything AFTER the END marker.
    refreshed = _splice_auto_block(original, new_auto_block)
    # SH-04: atomic write. Preserve the original mode in case the
    # consumer chmod'd their CLAUDE.md.
    try:
        original_mode = path.stat().st_mode & 0o777
    except OSError:
        original_mode = 0o644
    from mgf.common._io import atomic_write

    atomic_write(path, refreshed, mode=original_mode)
    return f"refreshed auto-block in {path} (backup: {backup.name})"


def _apply_bootstrap_claude_md_markers(
    target_dir: Path,
    project_name: str,
    project_kind: str,
) -> str:
    """PAPER-16: bootstrap BEGIN/END markers + auto-block into an
    existing CLAUDE.md that lacks them.

    Reads the existing file, backs it up to ``.bak.<timestamp>``,
    writes a new file with:

      1. The auto-managed BEGIN marker.
      2. The current standards auto-block content.
      3. The auto-managed END marker.
      4. A blank separator line.
      5. The original CLAUDE.md content, verbatim.

    The consumer ends up with the auto-block at the top + their
    existing content below the END marker — exactly the shape
    ``init-project`` produces on a greenfield run, but
    non-destructively. Subsequent ``catch-up --apply`` invocations
    can refresh the auto-block in place via
    :func:`_apply_refresh_claude_md` (the markers are now present).
    """
    path = target_dir / "docs" / "CLAUDE.md"
    original = path.read_text(encoding="utf-8")

    # Backup before modifying. Suffix matches _apply_refresh_claude_md
    # so the backup naming is consistent across catch-up apply paths.
    backup = path.with_suffix(f".md.bak.{int(time.time())}")
    backup.write_text(original, encoding="utf-8")

    # Render a fresh full template; extract just the auto-block
    # (including its BEGIN/END markers) — that's what we prepend.
    fresh_template = _render_claude_md(project_name, project_kind)
    auto_block_with_markers = _extract_full_auto_block(fresh_template)
    if not auto_block_with_markers:
        # Defensive: if the template's structure changes such that
        # we can't extract the marker block, fall back to the full
        # template (project content prepended below).
        auto_block_with_markers = fresh_template.rstrip() + "\n"

    new_content = auto_block_with_markers.rstrip() + "\n\n" + original
    # SH-04: atomic write, preserve mode.
    try:
        original_mode = path.stat().st_mode & 0o777
    except OSError:
        original_mode = 0o644
    from mgf.common._io import atomic_write

    atomic_write(path, new_content, mode=original_mode)
    return (
        f"bootstrapped BEGIN/END markers + auto-block at top of "
        f"{path} (backup: {backup.name}). Project-specific content "
        f"preserved below the END marker."
    )


def _extract_full_auto_block(content: str) -> str:
    """Return the BEGIN..END marker block (markers included). Used
    by :func:`_apply_bootstrap_claude_md_markers` to lift the
    auto-block out of a freshly-rendered template and prepend it
    onto an existing CLAUDE.md."""
    begin_idx = content.find(CLAUDE_MD_BEGIN_MARKER)
    end_idx = content.find(CLAUDE_MD_END_MARKER)
    if begin_idx == -1 or end_idx == -1 or end_idx < begin_idx:
        return ""
    end_line_end = content.find("\n", end_idx)
    if end_line_end == -1:
        end_line_end = len(content)
    return content[begin_idx : end_line_end + 1]


def _apply_create_claude_settings(target_dir: Path, project_kind: str) -> str:
    """Create a fresh .claude/settings.json."""
    path = target_dir / ".claude" / "settings.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(_render_claude_settings(project_kind), encoding="utf-8")
    return f"created {path}"


# ---------------------------------------------------------------------------
# Auto-block extraction + splicing.
# ---------------------------------------------------------------------------


def _extract_auto_block(content: str) -> str:
    """Return the substring between BEGIN and END markers (markers excluded)."""
    begin_idx = content.find(CLAUDE_MD_BEGIN_MARKER)
    end_idx = content.find(CLAUDE_MD_END_MARKER)
    if begin_idx == -1 or end_idx == -1 or end_idx < begin_idx:
        return ""
    # Slice from end-of-BEGIN-marker-line to start-of-END-marker-line.
    begin_line_end = content.find("\n", begin_idx)
    if begin_line_end == -1:
        return ""
    return content[begin_line_end + 1 : end_idx]


def _splice_auto_block(original: str, new_block: str) -> str:
    """Replace original's auto-block with new_block (keep markers + outside)."""
    begin_idx = original.find(CLAUDE_MD_BEGIN_MARKER)
    end_idx = original.find(CLAUDE_MD_END_MARKER)
    if begin_idx == -1 or end_idx == -1 or end_idx < begin_idx:
        # Shouldn't be called when markers are missing, but be safe.
        return original

    # Find the end of the BEGIN marker's line (so we keep the marker
    # itself but replace everything below it up to the END marker).
    begin_line_end = original.find("\n", begin_idx)
    return original[: begin_line_end + 1] + new_block + original[end_idx:]


# ---------------------------------------------------------------------------
# Reporting.
# ---------------------------------------------------------------------------


def _check_federation_contract(target_dir: Path, project_name: str) -> _Finding:
    """DOC-17 — verify the FEDERATION.md contract artifacts exist.

    Required for every consumer + sibling:
      - universal-5 root files (README, LICENSE, CHANGELOG, SECURITY, FEEDBACK)
      - MGF_STANDARDS_CONFORMANCE.md under docs/inprogress/ or docs/

    Required for consumer applications only (ADP-04 carves siblings out):
      - MGF_ADOPTION.md (or MGF_COMMON_ADOPTION.md) under docs/inprogress/ or docs/

    Required for federation siblings only (mgf-* package name):
      - USERS.md at repo root (DOC-16)
    """
    is_sibling = project_name.startswith(("mgf-", "mgf_"))

    missing: list[str] = []

    # Universal-5 (DOC-01, FB-01). LICENSE has no extension in this repo;
    # accept LICENSE, LICENSE.md, or LICENSE.txt.
    for required in ("README.md", "CHANGELOG.md", "SECURITY.md", "FEEDBACK.md"):
        if not (target_dir / required).is_file():
            missing.append(required)
    license_candidates = (target_dir / name for name in ("LICENSE", "LICENSE.md", "LICENSE.txt"))
    if not any(p.is_file() for p in license_candidates):
        missing.append("LICENSE")

    # DOC-15 conformance tracker (both kinds).
    conformance_candidates = (
        target_dir / "docs" / "inprogress" / "MGF_STANDARDS_CONFORMANCE.md",
        target_dir / "docs" / "MGF_STANDARDS_CONFORMANCE.md",
    )
    if not any(p.is_file() for p in conformance_candidates):
        missing.append("docs/inprogress/MGF_STANDARDS_CONFORMANCE.md (DOC-15)")

    # DOC-14 adoption tracker (consumers only — ADP-04 carve-out).
    if not is_sibling:
        adoption_candidates = (
            target_dir / "docs" / "inprogress" / "MGF_ADOPTION.md",
            target_dir / "docs" / "MGF_ADOPTION.md",
            target_dir / "docs" / "inprogress" / "MGF_COMMON_ADOPTION.md",
            target_dir / "docs" / "MGF_COMMON_ADOPTION.md",
        )
        if not any(p.is_file() for p in adoption_candidates):
            missing.append("docs/inprogress/MGF_ADOPTION.md (DOC-14)")

    # DOC-16 user roll (siblings only).
    if is_sibling and not (target_dir / "USERS.md").is_file():
        missing.append("USERS.md (DOC-16)")

    if not missing:
        return _Finding(
            "ok",
            "Federation contract (DOC-17 / FEDERATION.md)",
            "All required artifacts present.",
        )

    role = "federation sibling" if is_sibling else "consumer application"
    detail_lines = [
        f"Missing required artifact(s) for this {role}:",
        *(f"  - {m}" for m in missing),
        "",
        "See FEDERATION.md §3 for the full contract:",
        "  https://codeberg.org/magogi-admin/mgf_common/src/branch/main/FEDERATION.md",
        "Templates for trackers: mgf-common/docs/recipes/",
    ]
    return _Finding(
        "fail",
        "Federation contract (DOC-17 / FEDERATION.md)",
        "\n".join(detail_lines),
    )


def _print_report(
    findings: list[_Finding],
    target_dir: Path,
    project_name: str,
    project_kind: str,
) -> None:
    """Print the audit report."""
    from mgf.common import __version__

    print(
        f"mgf-common catch-up — auditing {target_dir}",
    )
    print(
        f"  Project:        {project_name} (kind: {project_kind})",
    )
    print(
        f"  mgf-common:     {__version__}",
    )
    print()
    print("Drift report:")
    print()
    for finding in findings:
        icon = _SEVERITY_ICON[finding.severity]
        print(f"  {icon} {finding.title}")
        # Indent the detail.
        for line in finding.detail.splitlines() or [""]:
            print(f"      {line}")
        print()

    fixable = sum(1 for f in findings if f.fix is not None)
    if fixable > 0:
        print(
            f"{fixable} finding(s) have mechanical fixes. "
            f"Re-run with `--apply` to apply (originals backed up).",
        )


def _exit_code_for(findings: list[_Finding]) -> int:
    """Exit non-zero if anything failed; warnings are zero (advisory)."""
    if any(f.severity == "fail" for f in findings):
        return 1
    return 0


def _next_major(version: str) -> str:
    """Return ``X.<Y+1>`` for an ``X.Y[.Z]`` version (rough upper bound)."""
    parts = version.split(".")
    if len(parts) < 2:
        return version
    try:
        major = int(parts[0])
        minor = int(parts[1])
    except ValueError:
        return version
    return f"{major}.{minor + 1}"


__all__ = ["add_catch_up_args", "run_catch_up"]
