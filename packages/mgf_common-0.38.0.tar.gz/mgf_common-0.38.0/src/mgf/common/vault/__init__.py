"""``mgf.common.vault`` — credential storage backends.

See: ``docs/reference/vault.md``.

Closes FEEDBACK §3.2. Phase 5 of the v0.3 closed-box reshape.

Three built-in backends, each implementing
:class:`mgf.common.typing.VaultProtocol`:

  - :class:`EnvVault` — stdlib-only; reads / writes
    ``<prefix><KEY>`` env vars. The right backend for CI /
    containerised deployments where the orchestrator injects
    secrets at process-start time. Works WITHOUT the optional
    ``[vault]`` extra installed.

  - :class:`KeyringVault` — system credential store via the
    third-party :mod:`keyring` library (libsecret / Keychain /
    Credential Manager). Requires ``mgf-common[vault]``. The
    desktop default — secrets persist across runs without the
    consumer managing a passphrase.

  - :class:`EncryptedFileVault` — Fernet (AES-128 + HMAC-SHA256)
    encrypted JSON-on-disk; PBKDF2-HMAC-SHA256 with 600 000
    iterations (OWASP 2023 baseline per rule SC-05). Requires
    ``mgf-common[vault]``. The fallback for headless Linux /
    embedded CI where no keyring daemon runs.

Custom backends — third-party stores (HashiCorp Vault, AWS
Secrets Manager) — are added via the registry::

    from mgf.common.vault import register_vault_backend

    @register_vault_backend("hashicorp")
    def make_vault(config):
        ...

The built-in backends are pre-registered at import time:
``"env"`` / ``"keyring"`` / ``"file"``.

Audit logging: every backend emits an ``audit=true`` log record
on ``get`` / ``set`` / ``delete`` per rule SC-17. The KEY is
logged; the VALUE is not.

Closed-box property: consumers DO NOT import :mod:`keyring`,
:mod:`cryptography`, or any backend-specific module directly —
they pass a ``VaultProtocol`` everywhere. Switching backends is
a single line at bootstrap.
"""

from __future__ import annotations

import warnings
from typing import TYPE_CHECKING, Any

from mgf.common._warnings import MgfDeprecationWarning
from mgf.common.vault._configs import (
    BuiltinVaultBackendConfig,
    EncryptedFileVaultConfig,
    EnvVaultConfig,
    KeyringVaultConfig,
)
from mgf.common.vault._env_vault import EnvVault
from mgf.common.vault._registry import (
    VaultBackendFactory,
    register_vault_backend,
    unregister_vault_backend,
)

if TYPE_CHECKING:
    from mgf.common.typing import VaultProtocol


# ---------------------------------------------------------------------------
# Lazy re-exports of the [vault]-extra backends
# ---------------------------------------------------------------------------
#
# KeyringVault + EncryptedFileVault import the optional
# :mod:`keyring` / :mod:`cryptography` libraries lazily — they
# raise :class:`mgf.common.exceptions.VaultError` (chained from
# the original ImportError) only when CONSTRUCTED without the
# extra installed. Importing the symbol is always safe; just
# don't instantiate without the extra.

from mgf.common.vault._file_vault import EncryptedFileVault
from mgf.common.vault._keyring_vault import KeyringVault

# ---------------------------------------------------------------------------
# Built-in backend pre-registration
# ---------------------------------------------------------------------------
#
# These three names are always available in the registry so
# downstream consumers (and the future ``open_vault(settings)``
# helper) can construct a backend by name without forking on
# the built-in vs. consumer-registered path.


_BUILTIN_TYPED_CONFIG_NAMES: dict[str, str] = {
    "env": "EnvVaultConfig",
    "keyring": "KeyringVaultConfig",
    "file": "EncryptedFileVaultConfig",
}


def _warn_legacy_dict(backend_name: str) -> None:
    """Emit ``MgfDeprecationWarning`` for the legacy dict-shape config.

    Typed configs (:class:`EnvVaultConfig` / :class:`KeyringVaultConfig` /
    :class:`EncryptedFileVaultConfig`) are the recommended shape for
    built-in backends. The dict shape still works for backward compat.
    Custom backends (registered via :func:`register_vault_backend` with
    a non-built-in name) DO NOT trigger this warning — dict is the
    supported shape for them until the registry grows config-model
    registration.
    """
    typed_name = _BUILTIN_TYPED_CONFIG_NAMES[backend_name]
    warnings.warn(
        f"VaultSettings.config as a bare dict is deprecated for the "
        f"built-in {backend_name!r} backend; use the typed "
        f"{typed_name} from mgf.common.vault.",
        MgfDeprecationWarning,
        stacklevel=3,
    )


@register_vault_backend("env")
def _make_env_vault(config: EnvVaultConfig | dict[str, Any]) -> VaultProtocol:
    """Built-in env-var backend factory. Pre-registered.

    Accepts either:
      - :class:`EnvVaultConfig` (v0.4+, recommended) — typed; pydantic
        enforces the shape at construction.
      - ``dict[str, Any]`` (v0.3 legacy) — emits
        :class:`MgfDeprecationWarning`; recognised keys: ``prefix``
        (str, default ``"MGF_VAULT_"``).
    """
    if isinstance(config, EnvVaultConfig):
        return EnvVault(prefix=config.prefix)
    _warn_legacy_dict("env")
    return EnvVault(prefix=config.get("prefix", "MGF_VAULT_"))


@register_vault_backend("keyring")
def _make_keyring_vault(
    config: KeyringVaultConfig | dict[str, Any],
) -> VaultProtocol:
    """Built-in system-keyring backend factory. Pre-registered.

    Accepts either:
      - :class:`KeyringVaultConfig` (v0.4+, recommended).
      - ``dict[str, Any]`` (v0.3 legacy) — emits
        :class:`MgfDeprecationWarning`; recognised keys: ``service``
        (str, default ``"mgf-common"``).

    Requires the ``[vault]`` extra; raises
    :class:`mgf.common.exceptions.VaultError` on construction
    if the extra is not installed.
    """
    if isinstance(config, KeyringVaultConfig):
        return KeyringVault(service=config.service)
    _warn_legacy_dict("keyring")
    return KeyringVault(service=config.get("service", "mgf-common"))


@register_vault_backend("file")
def _make_file_vault(
    config: EncryptedFileVaultConfig | dict[str, Any],
) -> VaultProtocol:
    """Built-in encrypted-file backend factory. Pre-registered.

    Accepts either:
      - :class:`EncryptedFileVaultConfig` (v0.4+, recommended) —
        ``path`` and ``passphrase`` are required pydantic fields,
        so missing-arg failure is at construction time, not at
        factory-call time.
      - ``dict[str, Any]`` (v0.3 legacy) — emits
        :class:`MgfDeprecationWarning`; required keys: ``path``
        (Path / str), ``passphrase`` (str). Missing key raises
        :class:`mgf.common.exceptions.VaultError`.

    Requires the ``[vault]`` extra; raises
    :class:`mgf.common.exceptions.VaultError` on construction
    if the extra is not installed.
    """
    if isinstance(config, EncryptedFileVaultConfig):
        return EncryptedFileVault(config.path, passphrase=config.passphrase)
    _warn_legacy_dict("file")
    from pathlib import Path

    from mgf.common.exceptions import VaultError

    path = config.get("path")
    passphrase = config.get("passphrase")
    if path is None or passphrase is None:
        raise VaultError(
            "file vault factory requires both 'path' and 'passphrase' "
            "in the config dict"
        )
    return EncryptedFileVault(Path(path), passphrase=passphrase)


__all__ = [
    "BuiltinVaultBackendConfig",
    "EncryptedFileVault",
    "EncryptedFileVaultConfig",
    "EnvVault",
    "EnvVaultConfig",
    "KeyringVault",
    "KeyringVaultConfig",
    "VaultBackendFactory",
    "register_vault_backend",
    "unregister_vault_backend",
]
