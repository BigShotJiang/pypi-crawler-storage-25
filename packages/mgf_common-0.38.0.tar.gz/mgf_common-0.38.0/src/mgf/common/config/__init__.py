"""Reusable config infrastructure — base settings + loader + paths.

See: ``docs/reference/config.md``. The library's own settings root
(:class:`mgf.common.settings.MgfSettings`) is in
``docs/reference/settings.md``.

Each consumer project subclasses :class:`BaseAppSettings` to declare
its own typed fields. The v0.3 closed-box shape uses the
subclass-kwarg pattern (closes FEEDBACK API-06)::

    from mgf.common.config import BaseAppSettings, Field, model_validator

    class AppConfig(BaseAppSettings, env_prefix="MYAPP_"):
        backend_uri: str = Field(default="qemu:///system")
        timeout_seconds: int = Field(default=30, ge=1)

        @model_validator(mode="after")
        def _validate_consistency(self) -> "AppConfig":
            ...
            return self

The package surface:

  * :class:`BaseAppSettings` — pydantic-settings base with layered
    sources, YAML file override, version-check validator,
    subclass-kwarg shape via ``__init_subclass__``.
  * :func:`load_settings` / :func:`save_settings` — typed loader
    with optional migration callback + atomic writer.
  * :func:`platform_dir` / :func:`default_config_path` — cross-OS
    directory helpers honouring ``XDG_*`` env vars.
  * :func:`expand_path` — reusable validator helper for ``~`` and
    ``$VARS`` expansion on Path-typed fields.
  * **Pydantic re-exports** (closes CB-04 — consumers don't
    ``import pydantic`` for normal use): :class:`BaseModel`,
    :class:`ConfigDict`, :func:`Field`, :class:`AliasChoices`,
    :func:`field_validator`, :func:`model_validator`,
    :class:`ValidationError`.
  * :func:`settings_config` — canonical baseline-builder. (The
    legacy `make_settings_config` alias was removed in v0.33 per
    its AP-12 cycle.)

See ``docs/standards/CONFIGURATION.md`` for the standards-level
design + ``docs/CLOSED_BOX_REDESIGN.md`` §4.2 for the v0.3
closed-box rationale.
"""

from __future__ import annotations

from mgf.common.config._loader import load_settings, save_settings
from mgf.common.config._paths import (
    PathKind,
    default_config_path,
    expand_path,
    platform_dir,
)
from mgf.common.config._reexports import (
    AliasChoices,
    BaseModel,
    ConfigDict,
    Field,
    ValidationError,
    field_validator,
    model_validator,
)
from mgf.common.config._settings import (
    BaseAppSettings,
    settings_config,
)

__all__ = [
    "AliasChoices",
    "BaseAppSettings",
    "BaseModel",
    "ConfigDict",
    "Field",
    "PathKind",
    "ValidationError",
    "default_config_path",
    "expand_path",
    "field_validator",
    "load_settings",
    "model_validator",
    "platform_dir",
    "save_settings",
    "settings_config",
]
