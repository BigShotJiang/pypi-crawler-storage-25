# FEDERATION — the Magogi federation contract

> **One sentence:** if you depend on `mgf-common` (or any `mgf-*` sibling),
> read this page once; it tells you everything you owe the federation
> in exchange for what the federation gives you.
>
> **Audience:** every consumer project (CLI tool, FastAPI service, Django
> app, library) AND every federation sibling. Humans + AI agents.
> **Status:** v1.0 of this contract. Bumped alongside the standards corpus.
> **Authority:** mgf-common owns this file. Other repos link here; they
> do **not** maintain their own copy.

---

## §1 What is the Magogi Foundation?

The **Magogi Foundation** is a family of Python projects that share one
engineering bar — typed exceptions, structured logging + OTel, layered
configuration, four-gate CI (ruff + mypy --strict + pytest + coverage),
crash reporting, vault, the AP/EH/LG/CF/SC/TS/DP rule discipline, and a
single feedback channel.

The foundation is split into three concentric rings:

  1. **The cornerstone** — `mgf-common`. The library AND the source of
     truth for standards, recipes, references, and the federation
     contract (this file).
  2. **The siblings** — every `mgf-*` package. They depend on
     `mgf-common`, conform to its standards, and add domain-specific
     surfaces (HTTP, SQLAlchemy, Alembic, FastAPI, Django, apiprobe,
     website-template). See [`USERS.md`](USERS.md) §2 for the roster.
  3. **The consumers** — your project. End applications that adopt
     `mgf-common` and one or more siblings to get the federation's
     quality bar without rewriting it.

**Why this file exists.** Without a canonical contract, every new
project re-discovers what the federation expects from scratch, and
the maintainer has to remember to mention it. This file is the
single answer to "what do I owe by depending on mgf-common?"

---

## §2 The contract — what you owe

By depending on `mgf-common` (any version), your project commits to:

1. **Maintain the required docs layout** (see §3).
2. **Self-declare a standards-conformance level** (see §4).
3. **Prefer federation libraries over external alternatives** where
   one exists (see §5).
4. **Catch up with federation releases** on a known cadence (see §6).
5. **Use the federation feedback channel** for friction reports (see §7).

These are MUST-level commitments. The maintainer enforces them via
`mgf-common catch-up` (a CLI command that audits your project — see §6).

In exchange, the federation gives you:

- A 200+ public-name typed standard library you don't have to build.
- 13+ recipe documents covering common patterns.
- The four-gate CI shape pre-baked.
- A unified feedback channel (PAPERs at `mgf-common/FEEDBACK.md` for
  cross-cutting issues; sibling-scoped at the sibling repo).
- Coordinated release cadence + breaking-change deprecation cycles.

---

## §3 Required docs layout

Every consumer + sibling project MUST ship the **universal five** at
repo root (DOC-01, FB-01):

| File              | Purpose                                                    | Rule       |
|-------------------|------------------------------------------------------------|------------|
| `README.md`       | Project overview, audience routing, first-run instructions | DOC-01     |
| `LICENSE`         | License declaration                                        | DOC-01     |
| `CHANGELOG.md`    | Per-release notes (Keep-a-Changelog shape)                 | DOC-01     |
| `SECURITY.md`     | Vulnerability-report channel                               | DOC-01 / SC-12 |
| `FEEDBACK.md`     | Repo-scoped consumer feedback queue                        | DOC-01 / DOC-13 / FB-01..04 |

**Plus the federation trackers** (depending on your role):

| File                            | Required for                  | Purpose                                | Rule  |
|---------------------------------|-------------------------------|----------------------------------------|-------|
| `docs/inprogress/MGF_ADOPTION.md` | Consumer applications only (ADP-04 carves siblings out) | "I depend on mgf-* — here's how, where, and what phase I'm at." | DOC-14 / ADP-01..04 |
| `docs/inprogress/MGF_STANDARDS_CONFORMANCE.md` | **Both** consumers and siblings | "I declare conformance level L1/L2/L3 and audit each rule ✅/🚫/⏳/N/A." | DOC-15 / CFM-01..04 |
| `USERS.md` (repo root)           | Federation siblings only (mgf-* libraries) | "Who depends on me?" — inverse of MGF_ADOPTION.md | DOC-16 |

Templates live in [`docs/recipes/`](docs/recipes/):

- `mgf-adoption-md-template.md`
- `mgf-standards-conformance-md-template.md`

The reference shape for sibling `USERS.md` is [this repo's `USERS.md`](USERS.md).

**For AI agents** working in your project: `docs/CLAUDE.md` SHOULD exist
with an auto-managed federation-discipline block (created and refreshed
by `mgf-common catch-up`). The block embeds DOC-13/14/15/16 + FB-04 +
this file's pointer so agents file feedback against the right repo
without you having to remember.

---

## §4 Required standards conformance

The standards corpus lives at [`docs/standards/`](docs/standards/) (v2.10
at time of writing). It contains:

| Standard         | Rules                  | What it covers                                  |
|------------------|------------------------|-------------------------------------------------|
| AP — API surface | AP-01..AP-12           | Public API stability tiers, deprecation cycle   |
| CF — Config      | CF-01..CF-N            | Layered config loader, env-var precedence       |
| CFM — Conformance| CFM-01..CFM-04         | The self-declaration discipline                 |
| DEP — Deps       | DEP-01..DEP-N          | Pin discipline, transitive caps                 |
| DOC — Docs       | DOC-01..DOC-17         | This contract + the docs layout above           |
| DP — Design      | DP-01..DP-13           | Design principles (timezone-aware, deterministic release, …) |
| EH — Errors      | EH-01..EH-N            | Typed exception hierarchy                       |
| FB — Feedback    | FB-01..FB-04           | Feedback-discipline rules                       |
| LG — Logging     | LG-01..LG-N            | Structured logging, redaction, audit emission   |
| REL — Release    | REL-01..REL-06         | Build-test-tag-push-upload order                |
| SC — Security    | SC-01..SC-17           | Atomic writes, secret redaction, audit trails   |
| TS — Tests       | TS-01..TS-N            | Test discipline, four-gate CI                   |

Run `mgf-common standards --list` to print them all. Run `mgf-common
standards <name>` to print one (e.g., `mgf-common standards LOGGING`).

**Your `MGF_STANDARDS_CONFORMANCE.md` declares your level:**

- **L1 — Lite.** You conform to the spirit of the standards but apply
  them on a best-effort basis. Suitable for greenfield experiments.
- **L2 — Standard.** You conform to all MUST rules. Per-rule audit ✅
  required. **This is the default for federation siblings + production
  consumers.**
- **L3 — Strict.** You conform to all MUST + SHOULD rules. Run-time
  enforcement (audit-logs, redaction) is wired up. Suitable for
  high-stakes services.

A `🚫 Declined-with-rationale` row is acceptable per CFM-04 if the
rule's premise doesn't fit your project shape — but the rationale
must be written down, not just felt.

---

## §5 Federation-first principle

When you need a capability and a federation library provides it,
**use the federation library**. Don't pull in a competing third-party
package just because it's familiar.

| You need…                       | Use…                                                               |
|---------------------------------|--------------------------------------------------------------------|
| Identity + logging + crash + OTel bootstrap | `mgf.common.bootstrap()`                                            |
| Layered config (kwargs > env > .env > YAML > defaults) | `mgf.common.config.BaseAppSettings`                                  |
| Vault-backed secrets             | `mgf.common.vault`                                                  |
| Structured logging               | `mgf.common.observability.setup_logging`                            |
| HTTP client (incl. resumable download) | `mgf-http` (sibling)                                                |
| SQLAlchemy session + audit-trail + UUID v7 | `mgf-sqlalchemy` (sibling)                                          |
| Alembic helpers + drift detector | `mgf-alembic` (sibling)                                             |
| FastAPI middleware (rate-limit, webhook audit, security headers) | `mgf-fastapi` (sibling)                                              |
| Django middleware (throttle)     | `mgf-django` (sibling)                                              |
| External API verification        | `mgf-apiprobe` (sibling)                                            |
| Docs site scaffold (cookiecutter)| `mgf-website-template` (sibling)                                    |
| USB enumeration / classification / libvirt passthrough (Linux) | `mgf-usb` (sibling, v0.0.0 — pre-implementation; v0.1.0 ships first surface) |
| Feature flags                    | `mgf.common.flags` (since v0.35.0)                                  |
| Scheduler                        | `mgf.common.schedule` (since v0.35.0)                               |
| Plugin auto-discovery            | `mgf.common.plugins` (since v0.36.0)                                |
| Doctor / health-report bundles   | `mgf.common.doctor` / `mgf.common.health` (since v0.36.0 / v0.37.0) |
| Idempotency-key store            | `mgf.common.idempotency` (since v0.37.0)                            |
| Rate-limit / token-bucket primitive | `mgf.common.rate_limit` (since v0.37.0)                              |
| LRU + TTL cache                  | `mgf.common.cache` (since v0.37.0)                                  |

**When to deviate.** If a federation library doesn't fit your need
(missing feature, performance gap, API mismatch), **file a paper at
the appropriate repo's `FEEDBACK.md` BEFORE adopting an alternative**.
That paper is how the federation learns; your `MGF_STANDARDS_CONFORMANCE.md`
can carry a `🚫 Declined: see PAPER-NN` row pointing at it.

---

## §6 Catch-up cadence + the tool

The federation moves. You need a mechanical way to stay current
without reading 7 CHANGELOGs every Monday.

**The command:**

```sh
mgf-common catch-up               # read-only audit (default)
mgf-common catch-up --apply       # apply mechanical fixes
mgf-common catch-up --path PATH   # target a project other than cwd
```

**What it audits:**

1. `pyproject.toml` pin freshness — flags stale `mgf-common` pin
   relative to the installed version.
2. Four-gate CI presence (ruff, mypy --strict, pytest, coverage).
3. `docs/CLAUDE.md` existence + auto-block freshness.
4. `.claude/settings.json` permission shape.
5. v0.1-pattern leaks (legacy import paths).
6. Closed-box leaks (private `_*` imports across module boundaries).
7. **Federation contract** (DOC-17, this file). Required artifacts:
   universal-5 + MGF_ADOPTION.md (consumers) + MGF_STANDARDS_CONFORMANCE.md
   (everyone) + USERS.md (siblings). **Missing required artifacts cause
   a non-zero exit code** — wire `mgf-common catch-up` into your CI
   pipeline if you want enforcement.

**Cadence.**

| Trigger                                        | Action                                                |
|------------------------------------------------|-------------------------------------------------------|
| Every mgf-common MINOR release                 | Run `mgf-common catch-up`; pick up new auto-block.    |
| Quarterly                                      | Run regardless; standards drift is silent.            |
| Before any major refactor in your project      | Run; confirm your foundation is current.              |
| In CI on every PR (recommended for L2/L3)      | Run `mgf-common catch-up`; fail the build on non-zero exit.    |

---

## §7 Feedback discipline

The federation has **one** feedback flow, repo-scoped per DOC-13 / FB-01..04.

| Friction type                                              | File at…                                              |
|------------------------------------------------------------|-------------------------------------------------------|
| Touches one sibling's public API or behavior               | That sibling's repo `FEEDBACK.md`                     |
| Cross-sibling pattern, standards proposal, new rule        | [`mgf-common/FEEDBACK.md`](FEEDBACK.md)                |
| Touches `mgf-common` library code directly                 | [`mgf-common/FEEDBACK.md`](FEEDBACK.md)                |

**The shape.** Every PAPER has:

- `PAPER-NN` numeric ID (monotonic per repo).
- Title.
- Severity: 🔴 Blocker / 🟡 Sharp edge / 🟢 Nice-to-have / 💭 Idea.
- Body: what hurts, why it hurts, what you'd want.

The full template + cadence is at `mgf-common feedback` (the CLI) or
in [`FEEDBACK.md`](FEEDBACK.md) (the live channel).

**For AI agents.** The auto-block in your `docs/CLAUDE.md` (managed
by `mgf-common catch-up`) reminds Claude where to file what. You don't
need to.

---

## §8 Onboarding flows

### §8.1 You're starting a NEW project

```sh
mkdir my-new-app && cd my-new-app && git init
mgf-common init-project --name my-new-app --kind <cli|fastapi|django|library|service>
# Paste the printed pyproject snippet into pyproject.toml
uv sync && uv run ruff check && uv run mypy --strict src/ && uv run pytest
```

What landed:
- `docs/CLAUDE.md` with the federation auto-block.
- `.claude/settings.json` with safe Claude permission defaults.
- Pyproject snippet pinning mgf-common + the four gates.

**Next:** create your `FEEDBACK.md`, `MGF_ADOPTION.md`, and
`MGF_STANDARDS_CONFORMANCE.md` from the templates in
[`docs/recipes/`](docs/recipes/). Then run `mgf-common catch-up` to
verify the contract.

### §8.2 You're an EXISTING project adopting mgf-common

```sh
cd my-existing-app
# Add mgf-common>=<latest>,<<next-major> to pyproject.toml.
uv sync
mgf-common catch-up                # audits drift
mgf-common catch-up --apply        # creates docs/CLAUDE.md + .claude/settings.json
```

Then hand-create:
- `FEEDBACK.md` (if not already present).
- `docs/inprogress/MGF_ADOPTION.md` (from the template).
- `docs/inprogress/MGF_STANDARDS_CONFORMANCE.md` (from the template).

Re-run `mgf-common catch-up` — should be clean.

### §8.3 You're a FEDERATION SIBLING (mgf-* library)

You're held to the same contract PLUS:

- `USERS.md` (DOC-16) at repo root.
- Per-MINOR import-survey to keep `USERS.md` factual.
- No `MGF_ADOPTION.md` (ADP-04 carve-out — your adoption is documented
  in the federation roadmap).
- Test in your own `.venv`; pin `mgf-common>=X.Y,<X.(Y+1)` for the
  current cycle.

---

## §9 Cheat sheet (the whole contract on one screen)

| Thing            | Where it lives                                                  | Rule       |
|------------------|-----------------------------------------------------------------|------------|
| README.md        | repo root                                                       | DOC-01     |
| LICENSE          | repo root                                                       | DOC-01     |
| CHANGELOG.md     | repo root                                                       | DOC-01     |
| SECURITY.md      | repo root                                                       | DOC-01 / SC-12 |
| FEEDBACK.md      | repo root, repo-scoped                                          | DOC-13 / FB-01..04 |
| MGF_ADOPTION.md  | `docs/inprogress/` (consumer apps)                              | DOC-14 / ADP-01..04 |
| MGF_STANDARDS_CONFORMANCE.md | `docs/inprogress/`                                  | DOC-15 / CFM-01..04 |
| USERS.md         | repo root (mgf-* siblings only)                                 | DOC-16     |
| docs/CLAUDE.md   | with auto-managed federation block                              | DOC-07     |
| `mgf-common catch-up` | quarterly + every MINOR + CI                              | DOC-17 (this file) |
| `mgf-common init-project` | new-project scaffold                                    | —          |
| `mgf-common feedback` | print FEEDBACK.md flow + template                          | —          |
| `mgf-common standards [name]` | print standards doc(s)                              | —          |
| Standards corpus | [`docs/standards/`](docs/standards/)                            | DP-* etc.  |
| Templates        | [`docs/recipes/`](docs/recipes/)                                | —          |
| Federation roster| [`USERS.md`](USERS.md) §2 (mgf-common) + per-sibling USERS.md   | DOC-16     |

---

## §10 How this document is maintained

- mgf-common owns this file. Edits land here first; siblings and
  consumers link to it.
- Every standards bump (v2.10 → v2.11 → …) MUST review this file
  for drift; if a new DOC / FB / ADP / CFM rule changes the contract,
  this file updates in the same commit.
- Every change to `mgf-common catch-up`'s audit checks MUST update
  §6 to match.
- Major federation events (new sibling, new tracker requirement,
  changed catch-up cadence) belong here.

If you're reading this in a sibling or consumer project: you're reading
a link. The authoritative copy is at
[`mgf-common/FEDERATION.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/FEDERATION.md).
