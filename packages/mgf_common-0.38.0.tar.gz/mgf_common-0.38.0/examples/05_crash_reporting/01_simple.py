"""Layer 1 — Catch an exception, write a crash report, see the file path.

The minimum viable use of report_now: in any except block, call
report_now(exc, source=...) and you get a JSON file under the
app's state directory with a structured report.
"""

from __future__ import annotations

import os
import tempfile

import mgf.common
from mgf.common.observability import report_now


def main() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        # Crash reports land under <state>/crashes/.
        os.environ["XDG_STATE_HOME"] = tmp

        with mgf.common.bootstrap(
            app_name="example-simple-crash", app_version="0.1.0",
        ):
            try:
                raise RuntimeError("something unexpected")
            except RuntimeError as e:
                path = report_now(e, source="demo")
                print(f"crash report written to: {path}")
                print(f"file exists: {path.exists()}")


if __name__ == "__main__":
    main()
