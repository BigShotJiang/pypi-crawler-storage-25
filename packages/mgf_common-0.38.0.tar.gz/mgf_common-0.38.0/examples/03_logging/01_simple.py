"""Layer 1 — bootstrap() + emit one record.

The minimum viable use of mgf.common for logging: one
``bootstrap()`` call sets identity, wires the rotating file +
console handlers, and applies the JSON formatter. Output goes
to stderr in text form (TTY default).
"""

from __future__ import annotations

import logging
import os
import tempfile
from pathlib import Path

import mgf.common
from mgf.common.settings import LoggingSettings, MgfSettings


def main() -> None:
    # Isolate state dir so the default rotating file lands in a tmp dir.
    with tempfile.TemporaryDirectory() as tmp:
        os.environ["XDG_STATE_HOME"] = tmp

        # bootstrap() wires identity + logging + OTel + crash
        # reporter + excepthooks in one call. Log paths, env-var
        # prefixes, and OTel service name all derive from app_name.
        with mgf.common.bootstrap(
            app_name="example-simple-log",
            app_version="0.1.0",
            settings=MgfSettings(
                logging=LoggingSettings(level="INFO", file=Path(tmp) / "demo.log"),
            ),
        ):
            # Per-module logger via __name__ (rule LG-01).
            LOG = logging.getLogger(__name__)
            LOG.info("hello from mgf-common logging")


if __name__ == "__main__":
    main()
