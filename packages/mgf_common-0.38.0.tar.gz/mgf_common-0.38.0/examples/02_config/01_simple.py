"""Layer 1 — Subclass BaseAppSettings, instantiate with defaults.

The minimum viable typed config: one subclass, one field, the
canonical model_config helper.
"""

from __future__ import annotations

from mgf.common.config import BaseAppSettings, settings_config


class Settings(BaseAppSettings):
    # IMPORTANT: subclasses MUST set model_config via the helper.
    # The naive `**BaseAppSettings.model_config` spread does NOT
    # work — pydantic-settings raises TypeError on duplicate keys.
    model_config = settings_config(env_prefix="MYAPP_")

    backend_uri: str = "qemu:///system"


def main() -> None:
    s = Settings()
    print(f"backend_uri = {s.backend_uri!r}")
    print(f"version = {s.version}")


if __name__ == "__main__":
    main()
