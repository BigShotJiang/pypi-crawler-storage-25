"""Layer 1 — setup_otel + operation_span as a no-op-safe context manager.

The minimum viable OTel surface: setup_otel() is idempotent and
no-op when no OTLP endpoint is configured; operation_span() is
safe to use unconditionally — it yields without opening a real
span when OTel is disabled.

To see real spans, install the [observability] extra and set
``OTEL_EXPORTER_OTLP_ENDPOINT=https://your-collector/v1/traces``.
"""

from __future__ import annotations

import os
import tempfile

import mgf.common
from mgf.common.observability import operation_span


def main() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        os.environ["XDG_STATE_HOME"] = tmp

        # bootstrap() wires OTel setup (no-op when no OTLP endpoint).
        with mgf.common.bootstrap(
            app_name="example-simple-otel", app_version="0.1.0",
        ):
            # Safe to wrap any operation; the context manager works
            # whether OTel is configured or not.
            with operation_span("demo.greet", subject="world"):
                print("hello from inside an operation_span")


if __name__ == "__main__":
    main()
