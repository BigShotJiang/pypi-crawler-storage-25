# FEEDBACK.md — Consumer feedback & open roadmap

> **Living document.** Design conversations between
> `mgf-common` maintainers and library consumers.
>
> **Format.** Each entry is a uniform block: identifier, status
> badge, severity, structured frontmatter, then prose. The format
> is optimised for both human readers and AI agents — every entry
> has the same shape, every status field is grep-able.
>
> **Bar.** Industry-standard. The shape any serious Python
> service / desktop / mobile project reaches for by default.

---

## §1. Process

### 1.1 Submission

A consumer adds an entry by opening a PR that edits this file.
Every entry MUST follow the **§1.4 entry template** below — the
uniform shape is what makes the document machine-actionable.

The `mgf-common feedback` CLI prints the submission flow + the
entry template ready to paste. Run it from any project that
depends on mgf-common.

### 1.2 Severity

| Level | Meaning | SLA |
|---|---|---|
| 🔴 **Blocker** | Getting it wrong requires a breaking change to fix later. MUST be decided before locking the public surface. | Triaged within the release cycle it lands in; decision recorded inline. |
| 🟡 **High** | Significant quality-of-life issue. Painful to live with, additive to add later. | Addressed as a minor / patch; no release gate. |
| 🟢 **Nice-to-have** | Real value, not urgent. | Picked up when a maintainer has capacity or a second consumer asks. |
| 💭 **Aspirational** | "Long-term where should this go" input. Not actionable today. | Kept for roadmap reviews; drives major-version planning. |

### 1.3 Status lifecycle

```
OPEN → ACCEPTED → SCHEDULED → SHIPPED
       ↓
       REJECTED   (with rationale)
       DEFERRED   (agreed in principle, not scheduled)
```

- **OPEN** — submitted, not yet triaged.
- **ACCEPTED** — maintainers agree; not yet scheduled.
- **SCHEDULED** — assigned a release.
- **SHIPPED** — landed; entry's status changes inline with a
  one-line retrospective. (We don't keep a parallel "shipped
  audit" section — the CHANGELOG carries the audit trail.)
- **REJECTED** — kept (not deleted) so future consumers don't
  re-raise.
- **DEFERRED** — agreed in principle, picked up at next roadmap
  review.

**On every status flip out of `OPEN`** (to SHIPPED, DEFERRED,
or REJECTED), the maintainer drafts a short consumer-facing
notification paragraph and routes it back to whoever filed the
entry. Per [`docs/standards/RELEASING.md`](docs/standards/RELEASING.md#7-consumer-notification-on-closure-rule-rel-09)
**REL-09**: the CHANGELOG carries the migration content; the
notification is the *delivery mechanism* that tells the
consumer their entry was addressed and what to do about it.
Without REL-09, the close-loop is silent and consumers
re-discover the resolution by accident.

### 1.4 Entry template — every new entry MUST follow this shape

```markdown
### `<AREA>-<NN>` — One-line title

| Field | Value |
|---|---|
| Status | OPEN / ACCEPTED / SCHEDULED / SHIPPED / REJECTED / DEFERRED |
| Severity | 🔴 / 🟡 / 🟢 / 💭 |
| Submitter | <Project> (commit `<sha>` if applicable) |
| Submitted | YYYY-MM-DD |
| Decision | pending / accepted / rejected (one line) |
| Decided on | YYYY-MM-DD or `—` |
| Scheduled for | release tag or `—` |
| Shipped in | commit SHA + release tag, or `—` |

**Concern.** What's wrong or missing. One paragraph.

**Why it matters.** Why this affects real consumers. One paragraph.

**Concrete evidence.** File paths, line numbers, or call counts
where the pain is observable in real code today. Optional for
💭 aspirational entries; expected for 🟡 High and above. A
submission that says "consumers do X" without naming the call
sites takes longer to triage and is harder to size.

**Suggested shape.** Concrete proposal — code snippet, prose, or
both. Not required to be the final answer; required to be a
starting point.

If the design has a real choice between approaches (e.g., enum
field vs typed-subclass tree; sync vs async; bundled vs
split), prefer **Approach A vs Approach B** framing with your
recommendation. Naming both alternatives speeds triage by giving
the maintainer something to evaluate against — a single
proposal can only be accepted or rejected, but two proposals
invite a comparative decision. PAPER-11 is the canonical
example.

**Decision rationale.** Filled when triaged. Why accepted /
rejected / deferred / scheduled.

**Retrospective.** Filled when shipped. Did the suggested shape
survive contact with implementation? What changed and why?
```

The frontmatter table is the single source of truth for status.
Prose comes after.

### 1.5 Ground rules

- **API stability is best-effort during the 0.x window.** Pinning
  to a minor (e.g., `>=0.X,<0.Y`) opts the consumer in to a
  predictable change cadence; pinning broadly opts in to faster
  iteration. Aggressive 🔴 Blocker resolution is the point of
  the early window.
- **A "co-developed" consumer carries less signal than a remote
  one.** A concern raised independently by a consumer with no
  prior coordination is a stronger lift signal than the same
  concern surfaced by the maintainer's primary consumer. Filter
  accordingly.
- **Don't optimise for `mgf-common` developers.** Every design
  trade-off favours the consumer. A feature that saves the
  library author an hour but costs every consumer a day of
  integration pain is a net loss.

---

## §2. Open feedback (active)

Sorted by area, then ID. To add a new entry, copy §1.4's template
verbatim and fill it in.

### 🟡 Papercuts

#### `PAPER-03` — Observability shim pattern is load-bearing but undocumented

| Field | Value |
|---|---|
| Status | ✅ SHIPPED |
| Severity | 🟡 High (doc, not code) |
| Submitter | Reference consumer |
| Submitted | 2026-04-23 |
| Decision | accept (recipe form rather than standards-doc section) |
| Decided on | 2026-05-01 |
| Scheduled for | shipped in-tree |
| Shipped in | `docs/recipes/observability_shim.md` (in-tree) + cross-link from `05_observability.md` |

**Concern.** A consumer can layer a project-local
`<project>/observability/__init__.py` re-export shim over
`mgf.common.observability` to layer in its own redactor /
formatter / handler extensions without forking `mgf.common`.
This pattern is valuable but nowhere documented as recommended
practice.

**Why it matters.** A future consumer evaluating the
architecture will either (a) miss the pattern entirely and
either fork or live with limited extensibility, or (b) discover
it by reading another consumer's source — neither is the right
onboarding shape for an industry-standard library.

**Suggested shape.** Add a section to
`docs/standards/COMMON_COMPONENTS.md` or a new
`docs/patterns/shim-layering.md` explaining: (a) why a consumer
might want a shim even without legacy call sites, (b) the
`import-linter` contract that keeps the shim from re-entangling,
(c) how to layer consumer-specific redactor extensions on top.

**Resolution.** Shipped as a recipe at
`docs/recipes/observability_shim.md` rather than a
standards-doc section: the standards docs declare MUSTs and
SHOULDs, while this is a recommended pattern (a recipe). The
recipe covers: why a shim is valuable for extensibility (not
just back-compat), the closed-box rule that applies inside the
shim, a layered example (custom redactor + custom log handler +
wrapper around `operation_span`), an `import-linter` contract
for the consumer side, and when NOT to use the shim.
Cross-linked from `docs/reference/observability.md` "Related
docs".

---

#### `PAPER-04` — Schema-versioning patterns are not reusable

| Field | Value |
|---|---|
| Status | ✅ SHIPPED |
| Severity | 🟡 High |
| Submitter | Reference consumer |
| Submitted | 2026-04-23 |
| Decision | accept (suggested shape verbatim) |
| Decided on | 2026-05-01 |
| Scheduled for | shipped in-tree |
| Shipped in | `mgf.common.versioned.VersionedFileStore[T]` + `MigrateFn` (in-tree) |

**Concern.** Every sub-config file in a real consumer (hooks,
schedules, alerts, lab specs, profiles) implements the same
shape: `version: int` + unknown-key rejection + migration
callback + atomic write. The code is duplicated across many
modules because `mgf.common.config.BaseAppSettings` covers only
the top-level config file, not satellite files.

**Why it matters.** Real code duplication cost (~600 LOC in
the reference consumer alone); will replicate in every consumer.
Each instance also drifts subtly (slightly different error
wording, slightly different migration shape) — exactly the
bit-rot the standards exist to prevent.

**Resolution.** Ships as `mgf.common.versioned`, a new public
subpackage. Two public names:

- `VersionedFileStore[T]` — the generic. Constructor takes the
  pydantic schema (must set `extra="forbid"`), the
  `current_version`, an optional `migrate=` callback, and an
  optional `version_field=` (default `"version"`; the consumer
  uses both `version` and `schema_version`). Format auto-detects
  from the path suffix (`.yaml` / `.yml` / `.json`); override via
  `file_format=`. `load()` validates, routes through migrate,
  returns `T`. `save()` stamps `version_field=current_version`
  and writes atomically (temp + fsync + rename, mode 0o600).
  Errors land as `AppConfigError` with PEP 678 notes naming the
  path + offending key.
- `MigrateFn` — the type alias for the migration callback:
  `Callable[[Mapping[str, Any], int], Mapping[str, Any]]`.

Recipe at `docs/recipes/versioned.md`. Pinned by 28 unit
tests + 5 user-perspective tests + the `PUBLIC_API.md` /
`PUBLIC_API.json` contract.

---

#### `PAPER-06` — `docs/standards/` cites the reference consumer with file:line

| Field | Value |
|---|---|
| Status | ✅ SHIPPED (full restructure; partial caveat banner generalised) |
| Severity | 🟡 High (doc refactor) |
| Submitter | Reference consumer |
| Submitted | 2026-04-23 |
| Decision | accept partial 2026-04-30; full restructure 2026-05-10 (unblocked by ASPIRE-02's "second consumer arrived" event) |
| Decided on | 2026-04-30 / 2026-05-10 |
| Scheduled for | partial: 0.18.0; full: 0.32.0 |
| Shipped in | **v0.18.0 (partial):** line ranges stripped from 12 citations across 6 docs; caveat banner in `docs/standards/README.md`. **v0.32.0 (full):** new `docs/reference-consumers/` folder with an index + three per-consumer profile files (`VManager.md`, `inthewords.md`, `PlasmaMapper.md`). Each profile documents the consumer's project type + shape-at-a-glance + pattern-by-pattern evidence + known non-adoptions + the friction it surfaced as papers. `docs/standards/README.md`'s caveat banner generalises from "reference consumer = VManager" to "three reference consumers; see `reference-consumers/`". The standards docs themselves stay consumer-neutral; inline mentions of consumer names that survive the restructure are evidence-grounding (one clause, no file:line) rather than "AS-IS in X" paragraphs. |

**Retrospective.** The full restructure was held until a second
consumer arrived (per the partial's "deferred" note) — ASPIRE-02 in
v0.18.0 marked that gate met (inthewords), and PlasmaMapper made it
three. With three independent shapes documented side-by-side
(desktop / Django / FastAPI-SaaS), the "the standards are
consumer-shaped" perception risk is closed structurally — no one
reading the standards docs will mistake them for descriptions of
one project's habits when the per-consumer evidence is in a
clearly-labelled separate folder.

The profile shape settled on a consistent outline: project type →
shape-at-a-glance table → pattern-by-pattern evidence (config,
logging, errors, subprocess, etc.) → known non-adoptions with
rationale → friction-surfaced-as-papers list. New consumers slot in
by mirroring that outline; the index README.md documents the
"wait for evidence; mirror the structure; cross-reference from
standards; add a row" intake flow.

Inline mentions of consumer names in `docs/standards/*.md`
intentionally stayed in place — they're one-clause evidence
groundings ("VManager's `Service` lifecycle uses this pattern"),
not the heavy "AS-IS in <consumer>" paragraphs the paper targeted.
Removing every inline mention would have hollowed out the standards'
"grounded in real code" stance; keeping them while moving the
detailed shape into `reference-consumers/` is the right partition.

The `docs/reference-consumers/` folder is also the natural home
for future consumer profiles (`mgf-apiprobe` if its shape diverges
enough; whatever Magogi-foundation marketing-site stands up via
mgf-website-template at the language boundary — though THAT will
probably profile differently per ASPIRE-05). The folder's README
documents the intake flow explicitly so adding a fourth or fifth
profile doesn't require re-litigating the structure.

**Concern.** Some topic docs have "AS-IS in <consumer>"
paragraphs citing specific file:line locations. These rot as the
consumer evolves. When a second consumer arrives, these
paragraphs become confusing ("wait, is that the reference
example or an accident?").

**Why it matters.** The standards docs are the public face of
the project. Consumer-specific examples cluttering the
cross-project standard creates a perception that the standards
are consumer-shaped rather than industry-shaped — which
undermines the cornerstone-library positioning.

**Suggested shape (partial done).** Highest-rot-risk component
closed: 12 `*.py:NN-MM` line-range citations across
`COMMON_COMPONENTS.md`, `LOGGING.md`, `CONFIGURATION.md`,
`DESIGN_PRINCIPLES.md`, and `ERROR_HANDLING.md` replaced with
file/function references that don't drift on every refactor. A
caveat banner in `docs/standards/README.md` warns readers that
consumer-specific examples are illustrative.

**Full restructure (still open).** Move consumer-specific
paragraphs into a dedicated `docs/reference-consumer/`
subfolder. When a second consumer arrives, generalise to
`docs/reference-consumers/Project1.md` /
`docs/reference-consumers/Project2.md`. Standards stay
consumer-neutral.

---

#### `PAPER-07` — Default-path helpers (`_default_log_path`, `_crash_dir`) are private but consumers need them

| Field | Value |
|---|---|
| Status | ✅ SHIPPED |
| Severity | 🟡 High |
| Submitter | Maintainer audit (VManager integration walk, 2026-05-01) |
| Submitted | 2026-05-01 |
| Decision | accept (suggested shape verbatim) |
| Decided on | 2026-05-02 |
| Scheduled for | 0.13.0 |
| Shipped in | `mgf.common.observability.{default_log_path, default_crash_dir, default_state_dir}` (v0.13.0); underscore-prefixed names retained as deprecated aliases that emit `MgfDeprecationWarning` for one cycle |

**Concern.** Consumers writing observability-adjacent UI (a log
viewer dialog, a crash-report browser, a "show me where my
state lives" diagnostic) need to know the on-disk paths the
library writes to. Today these paths are computed by private
helpers in `mgf.common.observability`:

- `mgf.common.observability.logging_setup._default_log_path()`
  — resolves `<state>/<app>/logs/<app>.log`.
- `mgf.common.observability.crash_reporter._crash_dir()` —
  resolves `<state>/<app>/crashes/`.

The reference consumer has already had to reach into the
private surface — `vmanager/gui/windows/main_window.py:254`
imports `_default_log_path` directly — which is a real
closed-box leak the consumer had no public alternative for.

**Why it matters.** Closed-box discipline is load-bearing for
`mgf-common`'s positioning. Every consumer that needs to
surface "where do my logs live?" in their UI is going to hit
this gap. The library can either (a) keep both paths private
and force every consumer to reach into the private surface
(the worst outcome — silent erosion of the closed-box
property) or (b) promote them now while the surface is still
small.

**Suggested shape.** Promote both helpers to public, ideally
in a small dedicated module so future path helpers have a
home::

    # mgf/common/observability/paths.py — new public module
    from pathlib import Path

    def default_log_path() -> Path: ...
    def default_crash_dir() -> Path: ...
    def default_state_dir() -> Path: ...   # the parent of both

Re-export from `mgf.common.observability.__all__`. Keep the
underscore-prefixed names as deprecated aliases for one cycle
so consumers reaching into the private surface get a
deprecation warning rather than a silent break.

Pin via the existing AP-10 sync test + a public-surface test
in `tests/public_surface/test_observability_as_user.py`.

---

#### `PAPER-08` — `mgf-common catch-up` should detect closed-box leaks (private imports from `mgf.common._*`)

| Field | Value |
|---|---|
| Status | ✅ SHIPPED |
| Severity | 🟢 Nice-to-have |
| Submitter | Maintainer audit (VManager integration walk, 2026-05-01) |
| Submitted | 2026-05-01 |
| Decision | accept (suggested shape verbatim) |
| Decided on | 2026-05-05 |
| Scheduled for | 0.17.0 |
| Shipped in | `_check_closed_box_leaks` audit row in `src/mgf/common/cli/_catch_up.py` (v0.17.0). AST-walks the consumer's `src/` (skipping `tests/`, `.venv/`, `__pycache__/`, etc.); flags three leak shapes — private module import (`from mgf.common._x import …`), private name from public module (`from mgf.common.X import _y`), and direct private-module import (`import mgf.common._x`). Known private→public promotions (`_default_log_path` → `default_log_path`; `_crash_dir` → `default_crash_dir`) named inline in the warning so the audit row tells the consumer not just "stop" but "do this instead." |

**Retrospective.** Implemented per the suggested shape. The
`_is_private_module` predicate generalised the rule to any
private-segment-after-`mgf.common`, catching the
`mgf.common.observability._helpers` class of leak that a
naive `startswith("mgf.common._")` check would miss. The
`_PRIVATE_TO_PUBLIC` mapping table is the right home for
private→public migration hints — extend it whenever a future
PAPER-07-shaped promotion happens. 11 unit tests pin every
leak shape + the skip-dirs invariant.

**Concern.** `mgf-common catch-up` audits four-gate config,
pin staleness, CLAUDE.md presence, and v0.1-pattern call
sites. It does NOT audit consumer source for closed-box leaks
(`from mgf.common._x import _y` or `from mgf.common.X import
_private`). The reference consumer had one such leak that the
audit didn't surface (`_default_log_path` import in
VManager's main window) — `tests/public_surface/`'s
`test_no_private_imports.py` AST pin is exactly the right
shape, but lives in `mgf-common`'s test suite, so the
discipline isn't enforced consumer-side unless the consumer
copies it.

**Why it matters.** The closed-box rule is harder to enforce
when consumers can write `from mgf.common._foo import _bar`
and silently get away with it until the next refactor breaks
their import. Surfacing this in `catch-up` makes the rule
discoverable as part of the standard "is my project up to
spec?" workflow, rather than something the consumer has to
remember to write a test for.

**Suggested shape.** Extend `_check_legacy_patterns` (or add a
new `_check_closed_box_leaks` audit row) that AST-walks every
`*.py` under `src/` and emits a warning for each
`mgf.common._*` import or `mgf.common.X._private`
import-from. Output format same as the existing
"v0.1-pattern usage" row — list the offending paths and a
one-line suggestion. Caveat: the audit MUST NOT walk into the
consumer's own `tests/` directory, since
`tests/unit/_internal_test_helpers/` style imports are
legitimate consumer-side.

This is also the right shape to surface FEEDBACK PAPER-07 —
the audit would name the private import and PAPER-07 (when
shipped) would direct the consumer to the public alternative.

---

#### `PAPER-09` — `VersionedFileStore[T]` rejects missing-version files unconditionally; consumers with pre-versioning legacy YAMLs cannot adopt it

| Field | Value |
|---|---|
| Status | ✅ SHIPPED |
| Severity | 🟡 High |
| Submitter | VManager (Phase MGF-3 catch-up walk, 2026-05-02) |
| Submitted | 2026-05-02 |
| Decision | accept (suggested shape verbatim — single boolean) |
| Decided on | 2026-05-02 |
| Scheduled for | 0.14.0 |
| Shipped in | `VersionedFileStore[T](..., tolerate_missing_version=False)` (v0.14.0); default keeps strict-by-default; opt-in logs one WARNING via `mgf.common.versioned` and treats missing as `current_version` (skipping migrate, since there is no version to migrate from); files where the field is *present but not an int* still raise — that's a corruption signal, not a legacy file |

**Concern.** `VersionedFileStore[T].load()` raises
`AppConfigError` when the on-disk file is missing the typed
version field. That's the right default for fresh consumers, but
it locks out consumers with **pre-versioning legacy files** —
files written before the consumer adopted CF-07's `version:`
discipline, which exist in user state directories on machines
that have been running the consumer across multiple releases.

VManager's `vmanager.profiles.profile.VMProfile.from_dict` ships
a deliberate grace path: a missing `version:` is logged at
WARNING and treated as `version: 1`. The next save rewrites the
file with `version:` at the top. This is what every test in
`tests/unit/test_profiles.py::TestVMProfileVersioning` pins —
specifically `test_load_accepts_missing_version_with_warning`.
Five satellite stores in VManager migrated to
`VersionedFileStore[T]` cleanly during Phase MGF-3 of
`docs/MGF_COMMON_CATCHUP.md`; the sixth (profiles) had to be
skipped because the grace path can't go through VFS. The bespoke
manual-JSON-parse + version-handling code in `profile.py` stays.

**Why it matters.** Every long-lived consumer that adds CF-07
versioning AFTER a public release of the file format hits this.
The "I added `version: <N>` to a file format that didn't have it
before; I want users' existing files to keep loading" pattern is
exactly what VFS should make easy, and it's where every consumer
will hit the same wall the moment they adopt
`VersionedFileStore[T]` for a pre-existing file. PAPER-04's
"replicates in every consumer" reasoning applies again here.

**Suggested shape.** Add an explicit opt-in flag — name it
something like `tolerate_missing_version=False` — that, when
set, treats a missing version field as the constructor's
`current_version` (with a single WARNING log via `mgf.common`'s
own logger, not raised as an error). The consumer's migrate
callback still runs against any other version, so consumers
that mix "missing means current" with real migrations
work cleanly.

```python
store = VersionedFileStore(
    path,
    schema=ProfileFile,
    current_version=2,
    migrate=migrate,           # v1 → v2
    tolerate_missing_version=True,  # missing → v2 with WARNING
)
```

The default stays `False` — fresh consumers benefit from the
strict-by-default behaviour. The flag is the explicit
opt-in for consumers that need the grace mode.

Alternative shape: a richer `MissingVersionPolicy` enum
(`reject` / `treat_as_current` / `treat_as_v1`) if the maintainer
wants more flexibility. The simple boolean is probably enough —
"treat as current with WARNING" is the only sane non-reject
behaviour, since the only thing pre-versioning files were
(implicitly) was "the version that was current when I was
written," which becomes "the current version" once they're
loaded by a binary that knows about versioning.

---

#### `PAPER-10` — No entry-point-driven auto-discovery for observability / vault plug-ins

| Field | Value |
|---|---|
| Status | DEFERRED |
| Severity | 🟢 Nice-to-have |
| Submitter | VManager (Round 2 audit walk, 2026-05-02) |
| Submitted | 2026-05-02 |
| Decision | defer until first plugin-framework consumer files concrete pain |
| Decided on | 2026-05-02 |
| Scheduled for | — |
| Shipped in | — |

**Decision rationale.** VManager themselves admit they don't
need this today (single-tenant, no extensions registered yet).
The `[project.entry-points.*]` shape is well-understood from
pytest / pluggy / flake8, but the *grouping* and the
*lifecycle* (when in `bootstrap()` to walk; what counts as a
plugin failure) are calls that benefit hugely from a real
consumer constraining them.

Strategic-review P1 (commit `f3e5845`) is exactly this point:
"Get a second, independent consumer." The second consumer's
plugin needs are the gate for designing the entry-point seam.
Pre-designing risks calcifying wrong: a seam that goes
un-stress-tested for two years lands in v1.0 with whatever
shape we guessed today, and consumers route around it instead
of using it.

The shipping-early argument ("zero downstream registrations to
migrate") is real but weaker. The existing explicit-call API
is already additive-compatible with any future entry-point
walk; consumers that adopt entry points don't have to rewrite
their existing wiring. So the cost of waiting is small.

**Reopen criteria.** PAPER-10 is gated on the same evidence as
Strategic-Review **Priority 1** —
[*Get a second, independent consumer*](docs/inprogress/strategic_review.md#priority-1--get-a-second-independent-consumer).
The two are the same problem from different angles: P1 asks
"who else uses this library and what shape did their adoption
take?", PAPER-10 asks "what does that adoption shape demand of
the extension surface?". The answer to either lands evidence
for both.

Reopen with any of:

  1. A plugin-framework consumer (multi-tenancy §S1 scenario)
     files concrete pain from the explicit-call shape.
  2. A second independent consumer lands and reports their
     extension-wiring story — pain *or non-pain* both count
     as evidence (non-pain may mean explicit-call is fine and
     PAPER-10 stays deferred for longer).
  3. An in-tree consumer (`example_app/`, `mgf-apiprobe`,
     future siblings) ships a pip-installable extension that
     would benefit from auto-discovery.

Whichever channel surfaces P1's signal surfaces PAPER-10's
signal too; no separate watch is needed.

**Concern.** `mgf.common.observability` exposes five explicit
registries — `register_log_handler`,
`register_redaction_pattern_group`, `register_span_processor`,
`register_crash_sink` — and `mgf.common.vault` adds a sixth via
`register_vault_backend`. All six require the consumer to
**import the plugin module + call the registration function**
somewhere that executes BEFORE `bootstrap()` claims its wiring
slot. Miss the import (e.g., the plugin lives in a sibling
package the host doesn't know about) and the registration never
happens; miss the timing (call after bootstrap) and the wiring
silently ignores the late entry.

The contrast: `mgf.common.pytest_plugin` declares itself in
`pyproject.toml::[project.entry-points.pytest11]` and pytest
auto-discovers it. Zero consumer-side import; the plugin "just
appears." Every other observability extension point is the
opposite shape — explicit-import, explicit-call, explicit-order.

**Why it matters.** The strategic review's Priority 1 ("second,
independent consumer") leans heavily on the multi-tenancy story
documented in `docs/design/multi_tenancy.md` §S1 — plug-in
frameworks hosting child packages with their own identity and
extensions. That scenario implies third-party plug-ins ship
their own redactor / handler / span-processor. Today every such
plug-in has to convince the host to import it and call its
register hook in the right place. With Python entry points, the
plug-in declares itself; `bootstrap()` walks the entry-point
groups during wiring and the plug-in's hook runs at the right
moment with no host-side change.

VManager itself doesn't have this need today (single-tenant, no
extensions registered yet — Round 2's `R2-MGF-PROGRESS` migration
is purely a re-export shim). The audit raised the gap because
VManager's recipe-driven shim layering pattern, when applied at
scale by a plug-in framework consumer, would surface this
friction immediately. Better to design the discovery seam now —
when there are zero downstream registrations to migrate — than
after a plug-in ecosystem has accreted around the explicit-call
shape.

**Suggested shape.** Define entry-point groups, one per
registry:

```toml
# Consumer's pyproject.toml — say, "vmanager-spice-redactor"
[project.entry-points."mgf.common.observability.redaction_pattern_groups"]
spice = "vmanager_spice_redactor:register"

[project.entry-points."mgf.common.observability.log_handlers"]
audit_kafka = "vmanager_audit:register_kafka_handler"

[project.entry-points."mgf.common.vault.backends"]
hashicorp = "vmanager_vault_hashicorp:register"
```

Each entry's value is a `module:callable` reference; the
callable takes no arguments and returns nothing — it just calls
the existing `register_*` API the way a manual import would. The
group's namespace mirrors the registry name so the contract is
discoverable by reading the `[project.entry-points]` block of any
plug-in package without consulting upstream docs.

`bootstrap()` walks every group via
`importlib.metadata.entry_points()` after wiring identity but
before wiring the registries that consume registered plugins.
Plug-ins that fail to load (`ImportError`, `register()` raises)
emit a single `MgfPluginLoadError` warning and proceed — the
same "best-effort observer" shape (rule **EH-10**) every other
observer in the library follows, so a broken third-party plugin
doesn't break the host's bootstrap.

The existing explicit-call API stays — entry-point discovery is
strictly additive. Consumers that prefer explicit wiring (the
"closed-box" mode) can pass `bootstrap(plugins="off")` (or set
`MgfSettings(plugins="off")`) to skip the entry-point walk
entirely.

The pattern matches what `setuptools` / `pytest` / `flake8` /
`pluggy`-based frameworks have used for a decade; consumers
already understand it and shipping tooling (uv, build, pip)
already supports declaring entry points. Cost on the upstream
side: ~50 lines of entry-point walking + tests.

---

#### `PAPER-11` — Consumers translating `VersionedFileStore[T]` errors string-match on private message markers; typed `error_kind` (or subclasses) would close the contract gap

| Field | Value |
|---|---|
| Status | ✅ SHIPPED |
| Severity | 🟡 High |
| Submitter | VManager (Phase MGF-3 catch-up walk, 2026-05-02) |
| Submitted | 2026-05-02 |
| Decision | accept (Approach A — `AppConfigErrorKind` enum field) |
| Decided on | 2026-05-02 |
| Scheduled for | 0.15.0 |
| Shipped in | `mgf.common.exceptions.AppConfigErrorKind` (StrEnum) + `AppConfigError.kind: AppConfigErrorKind \| None = None` (v0.15.0). Every load-path raise in `mgf.common.versioned._store` sets `kind` (FILE_NOT_FOUND, IO_READ_FAILED, JSON_PARSE_FAILURE, YAML_PARSE_FAILURE, NON_DICT_ROOT, MISSING_VERSION, UNSUPPORTED_VERSION, MIGRATE_FAILED, SCHEMA_VALIDATION). Save-path raises don't yet opt in — flag a follow-up if a consumer hits pain there. |

**Retrospective.** Implemented Approach A verbatim. Added two
kinds VManager's enum didn't list — `FILE_NOT_FOUND` and
`IO_READ_FAILED` — to cover ALL the load-path raise sites; if
consumers translate VFS errors and a raise site has `kind=None`,
they're forced back to message inspection for that site, which
defeats the whole purpose. Dropped vmanager's `NO_MIGRATE` (it
overlapped 1:1 with `UNSUPPORTED_VERSION` in the actual code).
Backward-compatible: every existing `except AppConfigError:`
clause keeps catching unchanged; consumers that don't
read `e.kind` see no change.

**Concern.** `VersionedFileStore[T].load()` raises a single
exception class (`AppConfigError`) for at least five distinct
failure modes:

1. JSON / YAML parse failure (the on-disk bytes are not valid).
2. Top-level non-dict (`raw` is a string / list / number).
3. Missing typed `version` field
   (when `tolerate_missing_version=False`).
4. On-disk version differs from `current_version` and no
   `migrate` callback is registered.
5. Pydantic schema-validation failure (missing required field,
   wrong type, value outside constraint).

Each case carries a distinguishable error **message** (literal
strings like `"is malformed (json)"`,
`"must be a mapping at the root"`,
`"is missing a typed 'version' field"`,
`"has version=N"`, `"failed schema validation"`). The exception
**class** is the same in every case.

Consumers that want to translate these to project-flavoured
wording — because their CLI or their tests pin specific error
text the consumer's API has historically promised — currently
have to **string-match on the private message format**. The
markers live in `mgf/common/versioned/_store.py` and have no
documented stability contract.

**Why it matters.** During Phase MGF-3 of VManager's catch-up
walk, three migrations needed this translation pattern:

- `src/vmanager/forensics/capture/filesystem.py::load_baseline`
- `src/vmanager/forensics/manifest.py::load_manifest`
- `src/vmanager/security/isolation/baseline.py::load_baseline`

Each ended up writing a discriminator like:

```python
except AppConfigError as e:
    raw = str(e).lower()
    if "is malformed (json)" in raw:
        msg = f"... is unreadable: {e}"
    elif "must be a mapping at the root" in raw:
        msg = f"... is not a JSON object"
    elif "has version=" in raw or "is missing a typed" in raw:
        msg = f"... has unsupported schema_version"
    else:
        # catch-all for schema-validation failures
        msg = f"... is malformed: {e}"
    raise OperationError(msg) from e
```

Three modules × ~four branches each = twelve string-match call
sites that silently break the moment upstream rewords any of
the markers (e.g., "is malformed" → "could not parse"; "has
version=" → "version mismatch on disk:"). The break is
**invisible** in CI — the consumer's tests pass with the legacy
wording in the catch-all branch, the legacy `match=` regexes in
the consumer's tests still match the catch-all message, and
nothing fires until a user hits the specific error path in
production.

Across N consumers each doing K translations, the multiplier is
N × K silently-fragile call sites. The same scaling argument
that drove PAPER-04 (VFS itself was the "every consumer ships
the same shape" pattern) applies here: **every consumer doing
error translation duplicates this discrimination, and every one
of them is fragile on the same upstream reword**.

**Suggested shape.** Either of two approaches; both surface a
typed contract consumers can switch on without string matching.

**Approach A — `error_kind` field on `AppConfigError`.**

```python
from enum import StrEnum

class AppConfigErrorKind(StrEnum):
    JSON_PARSE_FAILURE = "json_parse_failure"
    YAML_PARSE_FAILURE = "yaml_parse_failure"
    NON_DICT_ROOT       = "non_dict_root"
    MISSING_VERSION     = "missing_version"
    UNSUPPORTED_VERSION = "unsupported_version"
    SCHEMA_VALIDATION   = "schema_validation"
    MIGRATE_FAILED      = "migrate_failed"
    NO_MIGRATE          = "no_migrate"

class AppConfigError(AppError):
    kind: AppConfigErrorKind | None = None  # None = legacy/general
    # ... existing fields ...
```

Each `raise` site in `_store.py` sets `exc.kind = AppConfigErrorKind.X`.
Consumers translate with:

```python
except AppConfigError as e:
    match e.kind:
        case AppConfigErrorKind.JSON_PARSE_FAILURE | AppConfigErrorKind.YAML_PARSE_FAILURE:
            raise OperationError("... is unreadable") from e
        case AppConfigErrorKind.UNSUPPORTED_VERSION | AppConfigErrorKind.MISSING_VERSION:
            raise OperationError("... has unsupported schema_version") from e
        case _:
            raise OperationError(f"... is malformed: {e}") from e
```

**Approach B — typed subclasses.**

```python
class MalformedDocumentError(AppConfigError):
    """JSON / YAML parse failure."""
class NonDictRootError(AppConfigError):
    """Top-level value is not a mapping."""
class MissingVersionFieldError(AppConfigError):
    """version field absent or wrong type."""
class UnsupportedVersionError(AppConfigError):
    """on-disk version != current_version and no migrate."""
class StoreSchemaValidationError(AppConfigError):
    """Pydantic field validation failed."""
```

Consumers translate with:

```python
except MalformedDocumentError:
    raise OperationError("... is unreadable") from e
except UnsupportedVersionError:
    raise OperationError("... has unsupported schema_version") from e
except AppConfigError as e:
    raise OperationError(f"... is malformed: {e}") from e
```

Both approaches preserve the existing `AppConfigError` parent
type — every existing `except AppConfigError:` clause keeps
catching the new typed children. Backward-compatible.

**Recommend Approach A** (the enum field). Smaller diff
upstream, no new public class names, easier for consumers to
exhaustively check via Python 3.10+ structural pattern matching,
and the enum doubles as a stable string contract for any
non-Python consumer that ends up reading the JSON crash report
output.

The same argument generalises to other rich-error sites in
`mgf-common` (e.g., `EH-02` translation seams, `BootstrapError`
which today carries `failed_step: str`): typed kinds beat
prose, especially when consumers translate. PAPER-11 is just
the first instance the reference consumer hit hard enough to
file.

---

#### `PAPER-12` — `PUBLIC_API.md` and recipes drift ahead of the published wheel; consumers reading from a local checkout cannot tell what's actually shipped

| Field | Value |
|---|---|
| Status | ✅ SHIPPED |
| Severity | 🟢 Nice-to-have |
| Submitter | VManager (Phase MGF-3 catch-up walk, 2026-05-02) |
| Submitted | 2026-05-02 |
| Decision | accept (banner-form fix; CI-from-tag deferred) |
| Decided on | 2026-05-02 |
| Scheduled for | docs-only (no version bump) |
| Shipped in | banner at the top of `PUBLIC_API.md` directing readers to `pip show mgf-common` + `PUBLIC_API.json`'s `__version__` field for the actually-installed surface; the heavier "publish docs from release tags" alternative is deferred until CI lands (per the strategic-review P2 priority) |

**Concern.** During Phase MGF-3 of VManager's catch-up the
consumer read `mgf_common/PUBLIC_API.md` and
`docs/recipes/versioned.md` from the maintainer's master
checkout, which described `VersionedFileStore[T]` as available
in 0.12.0. The published wheel did not yet ship the module —
master was at 0.13.0-dev. Two rounds of confusion followed
(working assumption: VFS is shipped; reality: not yet). The
same desync recurred for PAPER-07's `default_log_path`.

**Why it matters.** Any consumer who reads the docs from a
local mgf-common checkout (the recommended workflow per
`CLAUDE.md`'s "Round 5 critical facts") will hit the same trap
whenever the maintainer is between a feature merge and a
release. The signal "this is in the docs" reads as "this is
shipped" — which it isn't, until the next `twine upload`. The
same confusion bit the maintainer's own session on 2026-05-02
when responding to the catch-up status — see the local-dist
vs PyPI mismatch resolved in commit `5bef66f`'s lead-up.

**Suggested shape.** A small banner or version stamp at the
top of `PUBLIC_API.md` (and the recipe docs) that says
"documents v...-dev — features marked NEW since the last
release tag are unreleased; consult `pip install
mgf-common==<published>` for the actual surface." Or: tag
releases on master and have CI publish `PUBLIC_API.md` from the
tag, not the tip. Either way, the desync gap closes.

---

#### `PAPER-13` — `mgf-common catch-up` misdetects framework apps as `kind: library` when no `pyproject.toml` exists

| Field | Value |
|---|---|
| Status | ✅ SHIPPED |
| Severity | 🟡 High |
| Submitter | inthewords (Phase 0 discovery, 2026-05-05) |
| Submitted | 2026-05-05 |
| Decision | accept (heuristic ladder per the suggested shape) |
| Decided on | 2026-05-05 |
| Scheduled for | 0.17.2 |
| Shipped in | `_detect_kind_no_pyproject` in `src/mgf/common/cli/_catch_up.py` — `manage.py` at the project root → `django`. Wired into `_resolve_project_identity` so `--kind` defaults pick up the heuristic instead of always returning `library`. Pairs with PAPER-17 (the with-pyproject case) for full kind-detection coverage. |

**Retrospective.** Implemented per the suggested shape, conservatively. Only the `manage.py → django` mapping ships in 0.17.2 — that's the consumer evidence the filing brought. Future no-pyproject framework markers (Flask `app.py`, Rails-equivalent layouts) ship when a real consumer files concrete pain. Premature heuristics on speculative project shapes calcify wrong; this one was easy to defend.

**Concern.** `mgf-common catch-up` v0.16.0 reports
`Project: inthewords (kind: library)` on a Django web
application. The detection appears to fall back to `library` when
`pyproject.toml` is absent. The kind drives downstream scaffolding
suggestions (`.claude/settings.json` defaults, the BEGIN/END
auto-block content, what counts as the "right" four-gate config),
so a wrong kind cascades into wrong recommendations.

**Why it matters.** As the second independent consumer (and the
first web/framework consumer) we're the first to surface this —
VManager has a `pyproject.toml` so it never hits the fall-back.
Every future Django, FastAPI, Flask, or Rails-equivalent
consumer that relies on `requirements/*.txt` plus
`manage.py` / `wsgi.py` / `asgi.py` will be misclassified.
Once the misclassification ships in their `.claude/settings.json`
defaults, fixing it is a manual editing exercise; doing it
right at first detection is one extra heuristic upstream.

**Concrete evidence.** Run on `inthewords` working tree at
`/home/bassam/PycharmProjects/inthewords` (commit `b9fecfa`,
2026-05-05):

```
$ mgf-common catch-up
mgf-common catch-up — auditing /home/bassam/PycharmProjects/inthewords
  Project:        inthewords (kind: library)
  mgf-common:     0.16.0
```

Markers that should have flipped detection to a framework kind:

- `manage.py` at repo root (Django CLI entry point).
- `apps/` flat package tree with sub-packages following Django's
  `AppConfig` pattern (e.g. `apps/core/apps.py::CoreConfig`).
- `config/asgi.py`, `config/wsgi.py`, `config/urls.py`,
  `config/settings/{base,dev,local,prod}.py` — Django's standard
  config layout.
- `requirements/{base,dev,prod}.{txt,lock}` declaring `Django`
  as a runtime dep.
- No `src/` layout, no `setup.py`, no `pyproject.toml` — none of
  the library-shape indicators.

**Suggested shape.** Extend `_detect_project_kind` with a small
heuristic ladder, ordered most-specific first:

```python
def detect_kind(root: Path) -> str:
    # Framework consumers.
    if (root / "manage.py").exists():
        if (root / "config" / "asgi.py").exists() or \
           (root / "config" / "wsgi.py").exists():
            return "django-app"
        return "django-cli"  # rare but possible
    if (root / "main.py").exists() and _imports_fastapi(root):
        return "fastapi-app"
    if (root / "Gemfile").exists() and (root / "config.ru").exists():
        return "rails-app"

    # Library / CLI / desktop default ladder (existing logic).
    if (root / "pyproject.toml").exists():
        return "library"  # current default
    return "unknown"
```

The existing `kind: library` default stays for legitimate library
projects without `pyproject.toml` (rare but possible). A new
`kind: unknown` fallback would be honest about "I don't know
what shape this is" — better than guessing wrong silently.

The `.claude/settings.json` and CLAUDE.md auto-block templates
become per-kind: `templates/django-app/.claude.settings.json`,
`templates/library/.claude.settings.json`, etc. catch-up picks
the right template at scaffolding time.

This is also the precondition for HTTP-01 / CONFIG-01 / LOG-01
below — once the audit knows it's looking at a Django app, it
can apply framework-aware rules instead of CLI/desktop-shaped
ones.

---

#### `PAPER-14` — `mgf-common catch-up` v0.1-pattern audit produces false positives by grepping `.md` files

| Field | Value |
|---|---|
| Status | ✅ SHIPPED |
| Severity | 🟡 High |
| Submitter | inthewords (Phase 0 discovery, 2026-05-05) |
| Submitted | 2026-05-05 |
| Decision | accept (real bug — different root cause than the filing identified) |
| Decided on | 2026-05-05 |
| Scheduled for | 0.17.1 |
| Shipped in | `_count_matches` in `src/mgf/common/cli/_catch_up.py` now skips `_AUDIT_SKIP_DIRS` (`tests/`, `.venv/`, `__pycache__/`, etc.) — same skip-dirs as `_check_closed_box_leaks`. Closes the false-positive class. |

**Retrospective.** The filing's hypothesis ("audit greps `.md`
files") was incorrect — `_count_matches` already filtered to
`*.py` via `rglob`. The actual bug was that `_check_v01_patterns`
falls back to the project root when `<target>/src/` is absent
(typical for Django shape projects), and the project root
includes `.venv/` where mgf-common's OWN deprecated shim
definitions live (e.g., `def setup_logging(...):` in
`mgf/common/observability/logging_setup.py`). Walking into
`.venv` counted those library-internal definitions as
user-source v0.1 call sites. Fix: apply the same
`_AUDIT_SKIP_DIRS` filter that `_check_closed_box_leaks`
already uses (also renamed `_LEAK_SKIP_DIRS` → `_AUDIT_SKIP_DIRS`
since the skip-list serves multiple audits, with a backward-compat
alias kept in place).

**Concern.** The v0.1-pattern audit row reports legacy call
sites by counting raw substring matches without filtering to
`.py` files. It hits Markdown documentation that mentions the
pattern names. On a project with zero actual mgf-common imports
but a tracking doc that names the patterns for documentation
purposes, the audit reports dozens of "legacy v0.1 call sites
found" — every one of them a false positive.

**Why it matters.** Adoption-time trust in catch-up's output is
load-bearing. A new consumer sees "18 `setup_logging(` call
sites found" and either (a) spends time hunting for them only
to discover they're all in their own `MGF_COMMON_ADOPTION.md`
tracking doc, or (b) starts a migration that doesn't actually
need to happen. Both erode confidence in the rest of the
audit's findings.

The brief expressly recommends consumers write a tracking doc
that names the v0.1 patterns ("Migrate by hand to `with
mgf.common.bootstrap(...) as ctx:`"). The very act of following
that recommendation triggers the false-positive.

**Concrete evidence.** On the `inthewords` working tree
(2026-05-05), `grep -rn` for the audited patterns across the
entire repo (excluding `.venv`) returns hits only from one
file: `docs/MGF_COMMON_ADOPTION.md` — the tracking doc opened
to plan the adoption. Counts of each pattern in that doc:

| Pattern | Hits in doc | catch-up reported |
|---|---|---|
| `mgf.common.configure(` | 1 | 4 |
| `make_settings_config(` | 0 | 5 |
| `setup_logging(` | 1 | 18 |
| `setup_otel(` | 0 | 4 |
| `install_excepthook(` | 1 | 4 |
| `install_threading_excepthook(` | 0 | 2 |

Project source has zero hits for any pattern (`grep -rn ...
--include="*.py"` returns no rows outside `.venv`). The `.venv`
itself (where `mgf-common 0.16.0` is installed) also has zero
hits for the patterns in the bundled module source.

The reported counts (4 / 5 / 18 / 4 / 4 / 2 = 37 total) appear
to over-count even relative to the doc's text — possibly a
secondary count bug (each instance of `(` counted, or each
comma-separated example, etc.) but the larger point stands:
a single documentation file produces 37 spurious "call site"
findings.

**Suggested shape.**

**Approach A — file-extension allow-list.** Restrict the audit
walk to `.py` files only. Markdown, RST, plain text, and other
documentation formats stay untouched. Smallest diff; matches the
conceptual scope ("legacy CALL SITES").

**Approach B — directory exclusion list.** Add a default-skip
list (`docs/`, `_build/`, `site/`, `*.md`, `*.rst`, `*.txt`)
plus a project-level `.mgf-commonignore` (gitignore-style) for
project-specific exclusions.

**Approach C — both.** Default to `.py`-only; make the
extension set configurable for projects that legitimately have
v0.1 patterns in non-Python files (rare but possible — a `.pyi`
stub, a Cython `.pyx` file, etc.).

**Recommend Approach A.** Smallest diff, matches the audit's
actual purpose. Approach C is over-engineering until a real
non-`.py` consumer file shows up. Approach B is reasonable but
the extension filter is more precise than a directory list (a
directory list misses `*.md` files at the repo root, like a
`README.md` that happens to mention an mgf-common API).

The `closed-box-leak` audit (PAPER-08, shipped) likely already
filters to `.py` — confirm and apply the same scope to the
v0.1-pattern row.

---

#### `PAPER-15` — `mgf-common catch-up` doesn't recognize pip-tools `requirements/*.{txt,lock}` layouts

| Field | Value |
|---|---|
| Status | ✅ SHIPPED (full audit; partial info-level workaround replaced) |
| Severity | 🟡 High |
| Submitter | inthewords (Phase 0 discovery, 2026-05-05) |
| Submitted | 2026-05-05 |
| Decision | accept partial v0.17.2 (improved warning); full audit v0.32.0 (first v0.32+ stabilization-window release) |
| Decided on | 2026-05-05 / 2026-05-10 |
| Scheduled for | 0.17.2 (partial); 0.32.0 (full) |
| Shipped in | **v0.17.2 (partial):** `_has_pip_tools_layout` + tailored info-level message ("workaround: add a minimal pyproject.toml"). **v0.32.0 (full):** `_check_pin_in_requirements` reads the pin from `requirements/base.txt` (fallbacks: `main.txt` / `runtime.txt` / flat `requirements.txt`) and applies staleness + auto-rewrite + editable-install guard uniformly with the pyproject path. `_check_four_gates_standalone` reads the four gates from `ruff.toml` / `.ruff.toml`, `mypy.ini` / `.mypy.ini` / `setup.cfg [mypy]` (strict=True), `pytest.ini` / `setup.cfg [tool:pytest]` / `tox.ini [pytest]` (filterwarnings=error, single- + multi-line forms), `.coveragerc` / `coverage.ini`. The historical `_check_pyproject_pin` / `_check_four_gates` entry-point names are kept; they dispatch internally based on `_has_pip_tools_layout`. Audit rows for pip-tools projects are titled `requirements/* — mgf-common pin` / `… four gates`. 17 new unit tests under `tests/unit/cli/test_catch_up.py`. Cutover guide: [`docs/cutover/v0.32.0.md`](docs/cutover/v0.32.0.md). |

**Retrospective.** The full ask landed almost exactly as suggested
in the filing — manifest detection ladder (pyproject → pip-tools
requirements → flat requirements.txt → no manifest), pin reading
from `requirements/base.txt` with synonym fallbacks, four-gate
audit from standalone config files. Staleness detection +
auto-rewrite + the PAPER-20 editable-install guard all inherit
from the pyproject path uniformly, so a pip-tools project gets the
same audit experience as a pyproject one. The audit row labels
changed from `pyproject.toml — …` to `requirements/* — …` for
pip-tools projects, which closes the cosmetic "the row title
talks about a file that doesn't exist" papercut the v0.17.2
partial inherited.

One bug surfaced during implementation: the original regex
`^(mgf-common(?:\[[^\]]+\])?)\s*([^\s#]*)` used `\s*` for the gap
between the package name and the constraint. `\s*` consumes
newlines, so a bare `mgf-common\nrequests>=2.31\n` line read the
second line's content as the constraint string. Replaced with
`[ \t]*` (same-line whitespace only); applied to both the reader
and the rewriter. The bug existed but was unreachable in the
pyproject path (which uses TOML parsing, not regex), so no
back-port to earlier releases is needed.

The four-gate standalone audit covers the cross-product of
{ruff, mypy, pytest, coverage} × {single-file config, setup.cfg-
embedded section, tox.ini-embedded section} that pip-tools
projects naturally use. The configparser library does the parsing
in every case, so multi-line INI continuation values (pytest's
`filterwarnings = \n    error \n    ignore::DeprecationWarning`)
work without extra effort. mypy's `strict = True` is checked for
truthiness (also accepts `true` / `1` / `yes` / `on`).

This is the **first v0.32+ stabilization-window release** — per
the federation roadmap, v0.32+ adds no new mgf-common public
surface, but behaviour fixes to existing tooling like catch-up
land cleanly. The mgf-fastapi v0.3 release (PAPER-29) sits
alongside as the first sibling new-surface release under the
independent-semver rule.

**Retrospective.** The full ask — read the pin from `requirements/base.txt`, read four-gate config from standalone `pytest.ini` / `ruff.toml` / `mypy.ini` — is a substantial code addition (~150-200 LOC + tests + a manifest-abstraction layer). Deferring until either (a) inthewords reports the partial fix isn't enough, or (b) a second pip-tools-layout consumer surfaces. The partial fix turns the audit's behaviour from "silently invisible" to "explicitly tells you what to do" — which closes the adoption-time confusion the filing surfaced. Full support tracked as a follow-up papercut.

**Concern.** `mgf-common catch-up` reports `no pyproject.toml
found; standards adoption usually needs one.` and `no
pyproject.toml; cannot check gate config.` on projects that
declare dependencies via the pip-tools layout —
`requirements/{base,dev,prod}.{txt,lock}`. This pattern is
common in Django shops, in projects that pre-date PEP 621
adoption, and in any project where the runtime/dev/prod split
is meaningful enough to warrant separate manifest files.

The catch-up tool can audit neither the `mgf-common` pin nor
the four-gate config when the manifest is `requirements/*.txt`
— two of the six audit rows go un-checkable.

**Why it matters.** The pip-tools pattern is well-established
(`pip-compile` ships in `pip-tools` 7.x; the lock file format is
deterministic and widely understood). A project using it is not
mis-shaped — it just declares its deps differently than a
PEP 621 `pyproject.toml`. Refusing to audit such projects, or
silently skipping the four-gate row, locks them out of catch-up's
value before any standards adoption can begin.

The natural workaround ("create a minimal `pyproject.toml`")
is fine but undocumented and undiscoverable. A consumer who
runs catch-up, sees "no pyproject.toml found", and concludes
"the tool doesn't support my project shape" walks away.

**Concrete evidence.** The `inthewords` working tree
(2026-05-05) declares deps as:

```
requirements/
├── base.txt        (44 lines, runtime deps with semver-major pins)
├── base.lock       (pip-compile output, fully resolved)
├── dev.txt         (24 lines, -r base.txt + dev tools)
├── dev.lock        (pip-compile output)
├── prod.txt        (-r base.txt + prod-only deps)
└── prod.lock       (pip-compile output)
```

Driven by `OPS-01: pip-compile to generate reproducible .lock
files` (recorded in `apps/core/management/commands/seed_data.py`
header and `requirements/dev.txt:8`).

CI installs from the lockfile (`.gitea/workflows/ci.yml:94`):

```yaml
- name: Install dependencies (from lockfile)
  run: |
    pip install --upgrade pip
    pip install -r requirements/dev.lock
```

No `pyproject.toml`, no `setup.py`, no `setup.cfg`. The project
is L1-ready in spirit but invisible to catch-up's pyproject-
oriented audit rows.

**Suggested shape.** Extend the manifest detection to a small
ladder, ordered by precedence:

```python
def find_dep_manifest(root: Path) -> DepManifest:
    if (root / "pyproject.toml").exists():
        return PyprojectManifest(...)
    req_dir = root / "requirements"
    if req_dir.is_dir():
        files = list(req_dir.glob("*.txt"))
        if files:
            return RequirementsManifest(req_dir, files)
    if (root / "requirements.txt").exists():  # flat layout
        return RequirementsManifest(root, [root / "requirements.txt"])
    return None  # no recognized manifest; skip pin/gate audit rows
```

The pin audit reads the `mgf-common>=0.X,<0.Y` line from
`requirements/base.txt` (or wherever it lives) just like it
reads the `[project] dependencies = [...]` block from
pyproject. Four-gate audit reads `pytest.ini`, `ruff.toml`,
`mypy.ini`, and a coverage config from the standalone files
that pip-tools projects naturally use (none of those four are
pyproject-only).

If a feature truly requires PEP 621 metadata (e.g., entry-points
discovery for PAPER-10's plugin walk), document it as such; the
generic four-gate audit doesn't have that requirement.

The "create a minimal pyproject.toml" workaround can be
documented in the catch-up output itself when no manifest is
recognized — "no recognized manifest found. mgf-common supports:
pyproject.toml, requirements/*.txt, requirements.txt at root.
Create one of these to enable pin and four-gate auditing."

---

#### `HTTP-01` — `EH-*` exception category taxonomy doesn't fit HTTP-domain consumers

| Field | Value |
|---|---|
| Status | ✅ SHIPPED |
| Severity | 🟡 High |
| Submitter | inthewords (Phase 0 discovery, 2026-05-05) |
| Submitted | 2026-05-05 |
| Decision | accept (Approach A — `HttpError` as eighth category, with concrete leaves) |
| Decided on | 2026-05-06 |
| Scheduled for | 0.18.0 |
| Shipped in | `mgf.common.exceptions.HttpError` + `HttpClientError` (4xx) + `HttpServerError` (5xx) + 9 concrete leaves (`HttpBadRequest` 400, `HttpUnauthorized` 401, `HttpForbidden` 403, `HttpNotFound` 404, `HttpConflict` 409, `HttpGone` 410, `HttpUnprocessable` 422, `HttpInternalServerError` 500, `HttpServiceUnavailable` 503) — 12 new public names. Each carries `http_status: int` as a class attribute for framework integration. All names ship at stability tier `experimental` per AP-11. Migration guide in [`docs/cutover/archive/v0.18.0.md`](docs/cutover/archive/v0.18.0.md#http-01--httperror-category). |

**Retrospective.** Implemented Approach A from the filing,
verbatim. The category-catch property holds at three levels —
`except HttpError:` / `except HttpClientError:` (4xx) /
`except HttpServerError:` (5xx) — which the test suite pins.
Consumer subclassing pattern (`RoomNotFoundError(HttpNotFound)`
inherits `http_status=404` automatically) is the headline
ergonomic; framework integration (Django middleware, FastAPI
exception handler) reads `exc.http_status` for response mapping.
Distinct from `ResourceNotFoundError` (provider-domain) by
deliberate non-inheritance — both subclass `AppError`, neither
subclasses the other. Test count grew from 16 to 29 in
`tests/public_surface/test_exceptions_as_user.py`.

**Concern.** `docs/standards/ERROR_HANDLING.md` §2.1 prescribes
seven category bases for typed exceptions: `ConfigError`,
`ProviderError`, `OperationError`, `GuestError`,
`SchedulerError`, `VaultError`, `EnvironmentError`. The category
layer is load-bearing for the standard's "shallow but typed by
category" design — it's how consumers can `catch X` for a
whole class of failures without naming every concrete subclass.

For systems-management domain (VM lifecycle, scheduler, vault,
guest agents) this taxonomy is well-shaped — VManager's source
maps cleanly onto it. For HTTP-domain consumers (web apps,
APIs, services), it doesn't map at all. Web apps' natural
exception taxonomy is HTTP-status-coded:

| Web exception | HTTP status | mgf-common category |
|---|---|---|
| `AuthenticationRequiredError` | 401 | none of the seven |
| `PermissionDeniedError` | 403 | none of the seven |
| `NotFoundError` | 404 | not `ResourceNotFoundError` (that's provider-domain) |
| `ConflictError` | 409 | none of the seven |
| `RoomArchivedError` | 410 (Gone) | none of the seven |
| `ValidationError` | 400 | not `SchemaValidationError` (that's config-domain) |
| `ServiceUnavailableError` | 503 | none of the seven |

A web consumer who follows EH-* literally must either (a) map
every exception to the closest mgf category by stretch (likely
`OperationError` for everything, defeating the category-catch
property), (b) skip the category layer and subclass `AppError`
directly (defeating EH-*'s prescribed shape), or (c) propose a
new category — which is what this entry does.

**Why it matters.** Every web/API consumer hits this on day
one. The reference consumer's standards docs implicitly
encode "consumer = systems-management library", which the
strategic-review priority 1 (second consumer) is supposed to
correct. We're the first web consumer; if HTTP-* isn't a
recognised category now, every future web consumer faces the
same "skip the layer or stretch the names" choice.

The `inthewords` central interfaces program (Phase 8D, lint-
enforced via `apps/core/tests/test_central_interfaces.py`) has
9 concrete exception classes, all subclassing a project
`AppError` base. Each carries an `http_status` class attribute
(`apps/core/exceptions.py:265-323`). They form a perfectly
valid hierarchy on their own; the question is how to compose
them with mgf-common's category layer when we adopt.

**Concrete evidence.** Project hierarchy at
`apps/core/exceptions.py` (`inthewords` repo, commit `b9fecfa`):

```
AppError                             (line 126; http_status=400 default)
├── NotFoundError                    (line 265; http_status=404)
│   ├── RoomNotFoundError            (line 295; http_status=404)
│   ├── RoomArchivedError            (line 301; http_status=410)
│   └── MessageNotFoundError         (line 313; http_status=404)
├── PermissionDeniedError            (line 271; http_status=403)
│   ├── AuthenticationRequiredError  (line 277; http_status=401)
│   └── MembershipRequiredError      (line 307; http_status=403)
├── ValidationError                  (line 283; http_status=400)
├── ConflictError                    (line 289; http_status=409)
└── ServiceUnavailableError          (line 319; http_status=503)
```

Project HTTP integration (`apps/core/exception_handlers.py`)
maps `exc.http_status` to the response status code via DRF and
Django middleware. This is the canonical web-app shape — it's
what every Django, FastAPI, and Starlette consumer will end up
with.

**Suggested shape.**

**Approach A — Add `HttpError` as an eighth category.**

```python
# In mgf.common.exceptions:
class HttpError(AppError):
    """Base for web/API exceptions carrying an HTTP status code."""
    http_status: int = 500   # subclasses override

class HttpClientError(HttpError):
    """4xx — request was bad."""

class HttpServerError(HttpError):
    """5xx — server failed to fulfill a valid request."""

# Optionally, common 4xx/5xx leaves:
class HttpUnauthorized(HttpClientError):     http_status = 401
class HttpForbidden(HttpClientError):        http_status = 403
class HttpNotFound(HttpClientError):         http_status = 404
class HttpConflict(HttpClientError):         http_status = 409
class HttpGone(HttpClientError):             http_status = 410
class HttpUnprocessable(HttpClientError):    http_status = 422
class HttpServiceUnavailable(HttpServerError): http_status = 503
```

Web-app consumers subclass these for project-specific cases
(`RoomNotFoundError(HttpNotFound)`, etc.) and get the
category-catch property: `except HttpClientError:` catches
every 4xx, `except HttpServerError:` catches every 5xx, `except
HttpError:` catches both.

**Approach B — Bless "skip categories, subclass `AppError`
directly" for web consumers.**

The standards explicitly state that web/HTTP-domain consumers
MAY subclass `AppError` directly without going through a
category layer, citing HTTP-status-driven exception taxonomies
as a recognised exception. The category-catch property is
documented as N/A for web consumers; HTTP middleware fills the
"catch by category" role via status-code routing instead.

**Recommend Approach A.** Smaller standards-doc change, larger
upstream-code change. The HTTP categories generalise to every
future web consumer (FastAPI, Starlette, Flask, aiohttp); the
in-tree leaves can be adopted or extended by each consumer.
Backward-compatible: existing consumers don't subclass
`HttpError` and don't see any change.

Approach B is the lower-cost answer if HTTP-domain consumers
turn out to be a minority of the consumer set, but it forces
every web consumer to re-litigate the same "should we use
mgf-common's categories?" decision. Approach A makes the
answer "yes — these ones" and ends the conversation.

A standards-doc section on "EH-* for web consumers" would help
either way (a single Markdown page in
`docs/standards/web/ERROR_HANDLING.md` or a sub-section in the
existing doc).

---

#### `CONFIG-01` — `CF-*` config standard is structurally incompatible with framework-native settings (Django, Rails-equivalent)

| Field | Value |
|---|---|
| Status | ✅ SHIPPED |
| Severity | 🟡 High |
| Submitter | inthewords (Phase 0 discovery, 2026-05-05) |
| Submitted | 2026-05-05 |
| Decision | accept (Approach A — framework-native carve-out section + per-rule applicability) |
| Decided on | 2026-05-06 |
| Scheduled for | 0.18.0 |
| Shipped in | `docs/standards/CONFIGURATION.md` gains §0a "Framework-native config (Django, Rails-equivalent)" with a per-rule applicability table (CF-01/04/08/09 are N/A; CF-02/05/10/12 still apply; CF-03/06/07/11 are N/A under framework-native) + an explicit "carve-out isn't an exemption from discipline" sub-section + the `inthewords` worked example. The Rules box itself gains an `Applies to` column (`all` vs `consumer-owned-config`) so the scope is machine-readable. Migration guide in [`docs/cutover/archive/v0.18.0.md`](docs/cutover/archive/v0.18.0.md#config-01--framework-native-config-carve-out). |

**Retrospective.** Implemented Approach A from the filing.
Approach B (move framework-native to a separate
`FRAMEWORK_CONFIG.md`) deferred — the carve-out shape kept the
canonical doc as the single source of truth. The new "carve-out
isn't an exemption from discipline" sub-section is a
maintainer-side addition emphasising that lint enforcement
(env-var-reads-only-in-settings.py-style tests) and CF-05
(secrets in vault) MUST still hold under framework-native. The
worked example uses `inthewords`'s actual config layout; future
Django consumers can copy verbatim. Rails / Flask carve-outs
land via `FRAMEWORK-NN` papers when those consumers file
specific friction.

**Concern.** Several CF-* MUSTs in
`docs/standards/CONFIGURATION.md` directly contradict the
canonical Django (and broadly framework-native) settings
pattern. A Django consumer cannot simultaneously be CF-*
compliant and use `from django.conf import settings`.

Specific contradictions:

| Rule | Mandate | Django pattern |
|---|---|---|
| **CF-01** | "No module reads the config file or env vars directly." | `config/settings/*.py` reads env vars via `python-decouple` / `os.environ` directly. The Django settings module IS the place where env vars are consumed. |
| **CF-08** | "Module-global singletons are forbidden. The Settings object MUST be loaded once at the entry point and passed down by constructor injection." | `from django.conf import settings; settings.X` is a module-global singleton lookup. It IS the canonical Django access pattern. Removing it would mean rewriting tens of thousands of call sites across every Django project on the planet. |
| **CF-09** | "A `--config <path>` CLI flag MUST always exist." | Django uses `DJANGO_SETTINGS_MODULE` env var to point at a Python module, not a config file path. ASGI/WSGI processes don't take CLI args at all. |
| **CF-04** | "Writes to the on-disk config file MUST be atomic (temp file + rename). Mode MUST be `0o600`." | Django settings are version-controlled Python code, deployed via Ansible/Terraform/Docker. There is no runtime write of "the config file." |

CF-02 (precedence: CLI → env → .env → config file → typed
defaults), CF-05 (secrets in vault not config), CF-06 (unknown
keys raise), CF-07 (sub-config files same shape), CF-10 (tests
construct Settings explicitly), CF-11 (rename via alias) all
apply or have natural Django equivalents. The mismatch is
specifically with CF-01, CF-04, CF-08, CF-09 — the four MUSTs
that encode the "consumer-owned, on-disk YAML, CLI-loadable"
shape.

**Why it matters.** Adoption requires either (a) declaring
CF-* not applicable for Django settings (which the standards
don't currently bless), (b) abandoning Django's settings
pattern and rewriting the consumer (impractical), or (c)
filing this entry. Without a clear blessed answer, every
Django/framework consumer re-litigates the same decision and
files variants of this same friction.

The strategic-review priority 1 ("second, independent
consumer") is the right context for this — VManager has its
own `AppConfig` Pydantic class that maps to CF-* cleanly
because VManager OWNS its config schema. Django consumers
delegate config ownership to the framework. That's a structural
distinction worth naming.

**Concrete evidence.** `inthewords` config layout:

- `config/settings/base.py` — env-var-driven base settings,
  ~400 lines, reads env via `python-decouple==3.*`
  (`requirements/base.txt:5`).
- `config/settings/{dev,local,prod}.py` — overlays on `base.py`
  via `from .base import *`.
- `manage.py:12` — `os.environ.setdefault('DJANGO_SETTINGS_MODULE',
  'config.settings.dev')`.
- `apps/core/tests/test_central_interfaces.py::TestEnvVarsOnlyInSettings`
  — lint test that BANS `os.environ.get(`, `os.environ[`, and
  `decouple.config(` anywhere in `apps/`. Settings reads happen
  ONLY in `config/settings/`, and access is via `from
  django.conf import settings`. This lint encodes the project's
  Phase 8D centralisation rule (`docs/CLAUDE.md` "Central
  interfaces" table). It directly enforces what CF-08 forbids.

The project test suite has 950 Python tests; converting every
`settings.X` access to constructor-injected DI would touch
hundreds of files and yield no behavioural improvement
(Django's settings are already a typed-by-convention module).

**Suggested shape.**

**Approach A — Add a "framework-native config" carve-out
section to CF-*.** A new sub-section
`docs/standards/CONFIGURATION.md` §X — "Framework-native
config (Django, Rails, …)" — that explicitly exempts CF-01,
CF-04, CF-08, CF-09 for consumers whose framework owns the
config schema. The remaining CF-* MUSTs (precedence ordering,
secrets→vault, schema versioning, unknown-key reject, etc.)
still apply where they make sense.

**Approach B — Scope CF-* to "applications that own their
config schema".** Re-frame the standard as the "consumer-owned
config" standard; framework-native settings are not in scope.
A separate `docs/standards/FRAMEWORK_CONFIG.md` covers the
Django/Rails case (precedence, secrets, env-var conventions,
unknown-key handling). The two coexist.

**Recommend Approach A.** Smaller change; keeps CF-* as the
canonical document; adds framework-native as a recognised
variant. Clear "L0 / L1 / L2" gating per CF rule with
framework-native exemption notes preserves the conformance
ladder.

Either approach must clarify which CF-* rules apply where.
Today the implicit answer is "all of them, somehow" — which
gates real Django consumer adoption.

A worked example for `inthewords` — under either approach —
would close the gap concretely:

```
inthewords adopts CF-* like this:
  CF-01 — N/A (Django-owned). Env-var reads happen ONLY in
          config/settings/*.py; lint-enforced via
          TestEnvVarsOnlyInSettings.
  CF-02 — APPLIES. Order is: env > .env > settings.py defaults.
  CF-03 — N/A (Django settings have no schema_version field;
          settings ARE Python code).
  CF-04 — N/A (settings are deployed code, not runtime data).
  CF-05 — APPLIES. Secrets in Ansible Vault (prod) / .env (dev),
          never in settings.py.
  CF-06 — N/A (Django attribute access on missing key already
          raises AttributeError).
  CF-07 — Project chooses; inthewords keeps tools/lib/test_config.py
          on the typed-config pattern (CF-* compliant) for the
          test harness.
  CF-08 — N/A (Django mandates module-global access).
  CF-09 — N/A (DJANGO_SETTINGS_MODULE env var replaces it).
  CF-10 — APPLIES. pytest fixtures construct Settings with
          explicit overrides; env leaks banned by conftest.
  CF-11 — N/A (settings rename is a code refactor, not data
          migration).
  CF-12 — APPLIES where relevant (e.g., CACHE_BACKEND alternatives).
```

---

#### `LOG-01` — `LG-06` rotating-file sink mandate doesn't fit cloud-native stdout-only logging

| Field | Value |
|---|---|
| Status | ✅ SHIPPED |
| Severity | 🟡 High |
| Submitter | inthewords (Phase 0 discovery, 2026-05-05) |
| Submitted | 2026-05-05 |
| Decision | accept (parameterised LG-06 + new recipe) |
| Decided on | 2026-05-06 |
| Scheduled for | 0.18.0 |
| Shipped in | `docs/standards/LOGGING.md` LG-06 revised to parameterise on deployment topology — rotating local file (desktop/single-server, no platform aggregator) OR process stdout/stderr (cloud-native/container; runtime captures + forwards) OR remote sink (OTLP/syslog/HTTP, opt-in). "Console only, no aggregation" is non-compliant in production regardless of branch. New recipe at [`docs/recipes/cloud-native-logging.md`](docs/recipes/cloud-native-logging.md) covers stdout-only `MgfSettings`, JSON formatter choice, structured-log invariants, and the deployment-time check. Migration guide in [`docs/cutover/archive/v0.18.0.md`](docs/cutover/archive/v0.18.0.md#log-01--cloud-native-logging-recognised). |

**Retrospective.** Implemented per the suggested shape. LG-06's
new wording explicitly recognises three first-class topologies
(file, stdout-aggregator, remote-sink) instead of the original
file-mandate + opt-in-others framing. The desktop / single-server
branch keeps the rotating-file prescription verbatim (no
regression for VManager-shape consumers). The cloud-native
branch is what `inthewords` and `PlasmaMapper` ship; the
recipe walks `inthewords`'s actual deployment topology
(Daphne → systemd journal → Promtail → Grafana Cloud) as the
worked example. Crash-report shipping flagged inline as the
remaining ephemeral-filesystem concern; recipe points at the
existing OTLP/HTTP sinks for that.

**Concern.** `LG-06` mandates "A rotating file sink MUST be
configured by default (under `<state>/logs/`). Console MUST
also receive logs. Remote sinks (OTLP, syslog, HTTP) MUST be
opt-in via env / config." This encodes the desktop-/server-app
shape where the operator runs the binary and tails a file on
disk.

The 12-factor / cloud-native pattern does the opposite:
**logs are an event stream written to stdout/stderr, the
runtime/platform handles aggregation**. Container orchestrators
(Kubernetes, Docker Compose, Heroku, Cloud Run, Fly.io) capture
stdout/stderr and forward to the platform's log aggregator.
Writing to a rotating file inside the container is an
anti-pattern — the file rotates against an ephemeral filesystem
that vanishes when the container restarts.

**Why it matters.** Every cloud-native consumer hits this on
day one. The honest answer for a Django app deployed via
container is "stdout goes to Grafana Cloud / Datadog / CloudWatch
via the platform; no file sink is needed or wanted." The LG-06
mandate either forces the consumer to configure a rotating file
sink they don't need (and that points at an ephemeral mount),
or to declare "we don't follow LG-06" — which the standards
don't currently bless as a recognised pattern.

This is parallel to CONFIG-01: LG-* encodes the desktop/server
shape; cloud-native is a recognised industry pattern that
deserves explicit treatment.

**Concrete evidence.** `inthewords` is deployed on Infomaniak
Public Cloud (3 VMs behind a load balancer). The deploy is
documented in `deploy/docs/first-production-cut.md` (Phase 8A
runbook) and `docs/DESIGN.md`'s "Hosting" section.

The production logging setup (per project memory and
`config/settings/prod.py`):

- Application processes (Django ASGI via Daphne, Celery workers)
  log to stdout in JSON format via `apps.core.logging.JsonFormatter`.
- The Infomaniak VM's systemd journal captures stdout.
- Grafana Cloud reads from journal via Promtail agents.
- Zero file sinks. No `<state>/logs/` directory exists. No
  rotation is configured because there's no file to rotate.

Setting up a rotating file sink in this topology would write to
the VM's local disk (ephemeral on cloud images), bypass the
journal, and force Grafana Cloud to read from two separate
sources. Net regression for compliance with LG-06.

**Suggested shape.** Add a sub-section to
`docs/standards/LOGGING.md` that explicitly recognises the
cloud-native shape. The mandate is restated as a contract
parameterised by deployment topology:

> **LG-06 (revised).** Logs MUST reach an aggregator the
> operator can search. The aggregator MAY be:
> - A rotating local file (desktop / single-server). Required
>   when no platform aggregator is available.
> - The process's stdout/stderr (cloud-native / container).
>   Required when the platform aggregator captures container
>   output (12-factor §XI).
> - A remote sink (OTLP / syslog / HTTP). Required when the
>   service explicitly opts in.
> A "console only, no aggregation" configuration is
> non-compliant in production.

The "rotating file" branch keeps the existing prescription verbatim
for desktop/server consumers. The "stdout" branch acknowledges
the cloud-native pattern as a first-class option. The "remote
sink" branch is unchanged.

A worked example for cloud-native consumers in
`docs/recipes/cloud-native-logging.md` would close the gap
concretely — covering: stdout-only configuration, JSON formatter
choice, structured-log-line invariants the platform aggregator
needs, and the deployment-time check ("the platform IS my
rotating file sink").

LG-07 (GUI log-viewer dialog) is a separate scope question
filed as LOG-02.

---

#### `LOG-02` — `LG-07` GUI log-viewer dialog mandate is N/A for web apps and headless services

| Field | Value |
|---|---|
| Status | ✅ SHIPPED |
| Severity | 🟢 Nice-to-have |
| Submitter | inthewords (Phase 0 discovery, 2026-05-05) |
| Submitted | 2026-05-05 |
| Decision | accept (per-rule applicability + per-kind compliance matrix) |
| Decided on | 2026-05-06 |
| Scheduled for | 0.18.0 |
| Shipped in | `docs/standards/LOGGING.md` Rules box gains an `Applies to` column with values from `{all, gui-app, service, fastapi, django, cli, library}`. LG-07 is now annotated `applies_to: gui-app`. Per-kind compliance matrix added at the top of the Rules box section listing which LG-* rules apply to which detected kinds. `mgf-common catch-up`'s future linter passes can filter by detected kind so non-applicable rules don't surface. Same pattern shipped on CF-* (closes CONFIG-01) and is recommended for the other standards docs as a follow-up. Migration guide in [`docs/cutover/archive/v0.18.0.md`](docs/cutover/archive/v0.18.0.md#log-02--applicability-scope-on-lg--rules). |

**Retrospective.** The smaller of the two LOG-* fixes (severity
🟢) but conceptually the bigger one — establishes the
"applies_to" pattern that ASPIRE-02's "explicit kind-aware
standards" prescription depends on. Same shape now ships on
CF-* (CONFIG-01 carve-out). Rolling out applies-to to EH-*,
DP-*, AP-* is a follow-up paper if a future consumer hits
specific friction; today the LG-* and CF-* coverage is enough
because those were the rules with concrete cross-kind
mismatches.

**Concern.** `LG-07` mandates "GUI apps MUST ship a log-viewer
dialog that reads the rotating file sink so users can view logs
without a terminal." This rule is scoped to GUI apps in its own
text, but the standards-doc structure presents LG-07 next to
LG-01 through LG-14 as if it applied to every consumer.

For web apps, headless services, batch jobs, and CLI tools, LG-07
is N/A — there is no "GUI" in the desktop sense, and log access
happens via the platform aggregator (Grafana, Datadog) or
operator tooling (`journalctl`, `kubectl logs`).

**Why it matters.** Low severity by itself — every consumer can
read "GUI apps MUST" and conclude "this doesn't apply to me."
But adoption tooling (catch-up, future linters) shouldn't ding
non-GUI consumers for not having a log-viewer dialog. The rule's
applicability scope should be machine-readable, not just inferred
from prose.

**Concrete evidence.** `inthewords` is a web application —
Django + Channels + Celery + Postgres + Redis. There is no
desktop client, no Qt/Tk GUI, no mobile shell. The browser-side
HTML+HTMX+Alpine UI does not host a log-viewer; logs live in
Grafana Cloud per LOG-01's evidence.

**Suggested shape.** Two small fixes:

1. Add an explicit "Applicability" sub-row or scope field to
   each LG-* rule. For LG-07: `applies_to: ["gui-app"]`. For
   LG-06 (post-revision per LOG-01): `applies_to: ["all"]`.
   The applicability scope becomes part of the rule's
   machine-readable contract — consumers and audits can both
   filter by their kind.

2. Add a "Per-kind compliance matrix" table at the top of
   `docs/standards/LOGGING.md` listing which rules apply to
   which kinds. Same pattern for the other standards docs as
   their kind-applicability becomes clear.

This unblocks PAPER-13's scaffolding (different kinds get
different audit scope) and complements CONFIG-01's
framework-native carve-out (CF-* rules also need scoped
applicability).

---

#### `PAPER-16` — `mgf-common catch-up --apply` cannot bootstrap BEGIN/END markers into an existing `docs/CLAUDE.md` without clobber risk

| Field | Value |
|---|---|
| Status | ✅ SHIPPED |
| Severity | 🟡 High |
| Submitter | inthewords (Phase 1 scaffolding, 2026-05-05; maintainer pre-confirmed acceptance during relay) |
| Submitted | 2026-05-05 |
| Decision | accept (Approach A — auto-insert with backup) |
| Decided on | 2026-05-05 |
| Scheduled for | 0.17.2 |
| Shipped in | `_apply_bootstrap_claude_md_markers` in `src/mgf/common/cli/_catch_up.py` reads the existing CLAUDE.md, backs it up to `.bak.<timestamp>`, writes a new file with BEGIN/END markers + auto-block at the top + the original content verbatim below the END marker. `_check_claude_md`'s no-markers branch attaches this as the fix-callable, so `catch-up --apply` no longer requires the destructive `init-project --force` workaround. |

**Retrospective.** Implemented Approach A from the filing, verbatim. Subsequent `catch-up --apply` invocations now refresh the auto-block in place via the existing `_apply_refresh_claude_md` (markers are present after bootstrap). The new helper extracts the auto-block-with-markers from a freshly-rendered template via a sibling extractor (`_extract_full_auto_block`) — slightly different from the existing `_extract_auto_block` (which strips markers); both live alongside.

**Concern.** v0.16.0 catch-up's audit row for `docs/CLAUDE.md`
detects the missing BEGIN/END auto-managed markers and stops:

```
⚠️  docs/CLAUDE.md
    exists but lacks BEGIN/END auto-managed markers — either
    pre-v0.11 init-project output or hand-written. catch-up
    cannot refresh the auto-block in place. Either re-run
    `mgf-common init-project --force` (clobbers your
    project-specific lookup section — back it up first), or
    manually add the BEGIN/END markers around the standards
    section.
```

The two documented options are asymmetric:

- `init-project --force` does the right scaffold but clobbers
  every line of project-specific CLAUDE.md content. For any
  project that has invested in CLAUDE.md as a load-bearing
  reference doc (Phase 8D centralisation rules, standing
  instructions, phase-critical-facts, etc.), this destroys
  hours-to-days of work in one command flag.
- Manual marker insertion works but is undocumented as a
  recommended path. The consumer has to know (a) what the
  marker syntax looks like, (b) where in the file the markers
  should go, (c) what content the auto-block will eventually
  contain (otherwise the manual stub may conflict). All three
  are discoverable only by reading another consumer's
  CLAUDE.md or running `init-project` against a scratch
  directory to inspect the template output.

**Why it matters.** Every consumer arriving with an existing
CLAUDE.md (whether hand-written or pre-v0.11 init-project
output) hits this. The clobber risk is one --force flag away
from destruction; the manual workaround is undocumented.
Closing this gap is small upstream code (auto-insert markers
at the top of the file, back up the original) and removes a
real adoption-time hazard.

This is the scaffolding equivalent of REL-02's "version reuse
forbidden" rule for releases: a destructive operation must not
be the documented path when a non-destructive one is one
heuristic away.

**Concrete evidence.** `inthewords/docs/CLAUDE.md` is 1100
lines of project-owned content:

- Standing instructions (~60 lines)
- Documentation directory layout (~40 lines)
- Central interfaces table (~80 lines)
- Logging + error-handling canonical pattern (~100 lines)
- Phase-N critical facts sections (~600 lines)
- Misc invariants, gotchas, fixed-bug notes (~220 lines)

`init-project --force` would replace all 1100 lines with the
template output. The project's manual workaround during Phase
1 (this filing) is to insert BEGIN/END marker stubs at the top
of the file, above the `# InTheWords — Claude Reference`
heading, then let the next `catch-up --apply` populate the
auto-block. The workaround works but is fragile — a new
consumer reading the v0.16.0 audit message lands on the
clobber path because that's the documented option that doesn't
require manual editing.

**Suggested shape.**

**Approach A (recommended) — auto-insert markers with backup.**

`catch-up --apply` detects the marker absence, reads the
existing CLAUDE.md, writes a new file with:

1. The auto-managed BEGIN marker.
2. The current standards auto-block content.
3. The auto-managed END marker.
4. The original CLAUDE.md content, verbatim.

The original file is backed up to `docs/CLAUDE.md.bak.<timestamp>`
before the rewrite, matching the pattern catch-up already uses
for `.claude/settings.json` and other in-tree files. The
consumer ends up with the auto-block at top + their existing
content below the END marker — exactly what `init-project`
would produce on a greenfield run, but non-destructively.

**Approach B — `--init-markers` flag.**

A new explicit flag on catch-up (or a sibling subcommand) that
performs Approach A's transform only when invoked explicitly.
Default behaviour stays the v0.16.0 "stop and warn" shape; the
flag is the consumer's opt-in.

**Recommend Approach A.** The auto-block is a contract artifact
(the standards-doc lookup that AI agents and humans rely on),
not optional flair. A consumer who runs `catch-up --apply`
expects scaffolding to land; stopping with a warn-then-skip on
the most-critical scaffolding artifact is the wrong default.
Backup-and-rewrite is non-destructive in the same shape catch-up
already uses elsewhere — consistent UX.

Approach B is the safer fallback if the maintainer wants to
preserve the v0.16.0 behaviour as default for some reason
(e.g., projects that genuinely don't want CLAUDE.md modified).
The cost is one more thing to discover.

**Decision rationale.** Pending formal triage; maintainer
pre-confirmed acceptance and Approach A choice during relay
on 2026-05-05.

**Retrospective.** (Filled when shipped.)

---

#### `VAULT-01` — Vault registry should accept `config_model=` for typed custom backends

| Field | Value |
|---|---|
| Status | ✅ SHIPPED |
| Severity | 🟡 High |
| Submitter | Maintainer dogfood |
| Submitted | 2026-04-28 |
| Decision | accept (suggested shape verbatim) |
| Decided on | 2026-05-01 |
| Scheduled for | shipped in-tree |
| Shipped in | `register_vault_backend(name, *, config_model=None)` + a `model_validator` on `VaultSettings` that coerces dicts → typed model when registered (in-tree) |

**Concern.** The three built-in vault backends
(`EnvVaultConfig` / `KeyringVaultConfig` /
`EncryptedFileVaultConfig`) ship typed configs via the
discriminated union `BuiltinVaultBackendConfig`. Custom
backends (HashiCorp Vault, AWS Secrets Manager, …) still use
`dict[str, Any]` — the closed-box leak is half-closed.
Consumer code shipping a custom backend writes stringly-typed
config dicts that the IDE / mypy / pydantic won't validate.

**Why it matters.** The whole point of typed configs was to
close the "consumers spelunk source to know what keys each
backend wants" gap. Custom backends still spelunk. Real
third-party stores (HashiCorp / AWS) are exactly where the
typed-config win matters most.

**Suggested shape.** Extend `register_vault_backend` to
optionally accept a `config_model` parameter; the registry
stores the mapping. `VaultSettings.config` then validates
against the registered model when the active `backend` matches:

```python
from mgf.common.vault import register_vault_backend
from mgf.common.config import BaseModel, ConfigDict

class HashicorpVaultConfig(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    backend_type: Literal["hashicorp"] = "hashicorp"
    url: str
    token: str
    mount: str = "secret"

@register_vault_backend("hashicorp", config_model=HashicorpVaultConfig)
def make_hashicorp_vault(config: HashicorpVaultConfig) -> VaultProtocol:
    ...
```

`MgfSettings(backend="hashicorp", config=...)` then accepts the
typed config; `BuiltinVaultBackendConfig` becomes a
dynamically-resolved discriminated union from the registry.

**Resolution.** Ships as additive surface:

- `register_vault_backend(name, *, config_model=None)` — the new
  `config_model=` kwarg accepts a `BaseModel` subclass. The
  registry stores `(factory, config_model)` pairs internally.
- `VaultSettings` gets a `model_validator(mode="after")` that
  consults the registry: when the active `backend` has a
  registered `config_model`, an incoming dict is validated and
  replaced with the typed instance; an already-typed instance
  passes through; a wrong typed instance raises with a clear
  error; an unregistered backend leaves the dict untouched
  (factories registered without a model own their own validation).
- Built-in backends (`env` / `keyring` / `file`) keep their
  existing isinstance dispatch + deprecation warning for
  backward compat — the change is purely additive for custom
  backends.

Recipe section in `docs/reference/vault.md` ("Custom backend with
a typed config — recommended"). Pinned by 8 unit tests + 1
public-surface test.

---

#### `PAPER-17` — `mgf-common catch-up` kind detection mis-classifies FastAPI projects that DO have a `pyproject.toml` as `kind: library`

| Field | Value |
|---|---|
| Status | ✅ SHIPPED |
| Severity | 🟡 High |
| Submitter | PlasmaMapper (Phase 1 catch-up adoption, 2026-05-05) |
| Submitted | 2026-05-05 |
| Decision | accept (Approach A — heuristic from pyproject deps + scripts) |
| Decided on | 2026-05-05 |
| Scheduled for | 0.17.2 |
| Shipped in | `_detect_kind_from_pyproject` in `src/mgf/common/cli/_catch_up.py`: parses `[project] dependencies` + `[project.scripts]` from pyproject.toml. Framework markers in deps → `fastapi` / `django` / `service` (Flask). Non-empty scripts without framework → `cli`. No deps + no scripts → `library`. Uses existing `_KINDS` set from `init-project` (no new template kinds added). Pairs with PAPER-13 (no-pyproject case) for full coverage. |

**Retrospective.** Implemented Approach A from the filing. Approach B (explicit `[tool.mgf]` declaration) deferred — the heuristic covers the canonical shapes today; explicit-override gates can land when a consumer files a real misclassification (e.g., a project that vendors FastAPI internally). Tomllib/tomli not used to stay stdlib-only on 3.11 baseline; line-grep heuristic is forgiving and matches canonical declaration shapes. Substring edge case (`flask-restful` matching `flask`) flagged in the test as acceptable until a real consumer surfaces concrete pain — premature regex-tightening on speculative cases calcifies wrong.

**Concern.** Extends [PAPER-13](#paper-13). PAPER-13 framed the
`kind: library` mis-classification as a fall-back triggered when
`pyproject.toml` is absent (Django consumer `inthewords` has
`requirements/*.txt` only). PlasmaMapper has a
`pyproject.toml`, declares `fastapi`, `uvicorn`, `sqlalchemy`,
`alembic`, `arq` as runtime deps, and ships three FastAPI/asyncio
entry-point console scripts (`plasma-api`, `plasma-ingest`,
`plasma-worker`) — and `catch-up` still reports
`kind: library`. So the mis-classification is broader than the
"no pyproject.toml" framing in PAPER-13: even when the modern
library-shape indicator is present, the heuristic's fall-back to
`library` fires unless something stronger flips it.

**Why it matters.** The inheritance: `kind` drives the auto-block
content of `docs/CLAUDE.md`, the `.claude/settings.json` defaults,
and (per PAPER-13's resolution sketch) per-kind templates. A
FastAPI consumer mis-classified as `library` ends up with a
CLAUDE.md auto-block that uses library-shaped phrasing
("`do NOT call bootstrap() here`") despite the consumer being a
fully-host-shaped service whose entry-points DO call
`bootstrap()`. Worked-around in
`PlasmaMapper/docs/CLAUDE.md` by overriding the kind in the
project-specific section below the END marker — but that override
is fragile (the BEGIN/END auto-block still claims `library`).

**Concrete evidence.** PlasmaMapper @ `main` / commit `dc8257f`,
mgf-common 0.17.0 (sibling editable install):

```
$ mgf-common catch-up
mgf-common catch-up — auditing /home/bassam/PycharmProjects/PlasmaMapper
  Project:        plasmamapper (kind: library)
  mgf-common:     0.17.0
```

Markers that should have flipped detection to a FastAPI/web kind:

- `pyproject.toml::project.dependencies` includes `fastapi>=0.115`,
  `uvicorn[standard]>=0.30`, `sqlalchemy[asyncio]>=2.0.30`,
  `asyncpg>=0.30`, `alembic>=1.13`, `arq>=0.26`, plus the OTel
  FastAPI / SQLAlchemy / Redis / asyncpg instrumentations.
- `pyproject.toml::project.scripts` declares four console scripts
  (`plasma-api`, `plasma-ingest`, `plasma-worker`, `plasma-cli`)
  pointing at `<package>.<entry>.__main__:main` — application
  entry points, not library exports.
- `src/plasmamapper/api/__main__.py` imports `uvicorn`, calls
  `uvicorn.run(app, ...)`, and brackets it with
  `mgf.common.bootstrap(...)` / `ctx.shutdown()` — host shape, not
  library shape.
- `alembic/` directory + `alembic.ini` + an existing migration
  in `alembic/versions/` — application data layer, not library.
- `docker-compose.dev.yml` for Postgres + Redis + Tempo — service,
  not library.
- `.woodpecker.yml` CI describing `lint / type / test / migrate`
  jobs against Postgres + Redis service containers — service.

**Suggested shape.** Strengthen the heuristic ladder PAPER-13
proposed by checking `pyproject.toml` content (not just presence)
when the file exists:

```python
def detect_kind(root: Path) -> str:
    pp = root / "pyproject.toml"
    if pp.exists():
        deps = _parse_runtime_deps(pp)  # dependencies + optional-deps
        scripts = _parse_console_scripts(pp)  # project.scripts

        # Framework markers (most-specific first).
        if {"fastapi", "starlette"} & deps:
            return "fastapi-app"
        if "django" in deps:
            return "django-app"
        if "flask" in deps:
            return "flask-app"

        # CLI shape — has console scripts, no web framework.
        if scripts:
            return "cli"

        # Default: real library.
        return "library"

    # No pyproject.toml — falls through to PAPER-13's heuristic
    # (manage.py / main.py / Gemfile detection).
    return _detect_kind_no_pyproject(root)
```

Approach A (proposed above): infer from `pyproject.toml` runtime
deps + `project.scripts`. Cheap parse; no AST walk; no false
positives for libraries that import FastAPI as a test dependency
only (since we read `dependencies`, not `optional-dependencies`).

Approach B: a `kind = "fastapi-app"` field consumers declare
explicitly in `[tool.mgf]` or `[tool.mgf-common]` of
`pyproject.toml`. Honest, zero heuristic drift, but gates correct
classification on consumer-provided data — a forgotten declaration
puts the consumer back in the wrong template silently.

**Recommended:** Approach A as default (heuristic), Approach B as
override for projects whose dep tree doesn't reveal the shape
(e.g., a project that vendors FastAPI internally). PAPER-13's
`kind: unknown` fallback still applies for cases where neither
heuristic nor declaration resolves.

---

#### `PAPER-18` — `mgf-common doctor` first-line summary reports a stale hard-coded version, not the imported package's `__version__`

| Field | Value |
|---|---|
| Status | ✅ SHIPPED |
| Severity | 🟢 Nice-to-have |
| Submitter | PlasmaMapper (Phase 1 catch-up adoption, 2026-05-05) |
| Submitted | 2026-05-05 |
| Decision | accept (suggested shape verbatim) |
| Decided on | 2026-05-05 |
| Scheduled for | 0.17.1 |
| Shipped in | `_check_install` in `src/mgf/common/cli/_doctor.py` reads `from mgf.common import __version__` directly instead of `importlib.metadata.version("mgf-common")`. The metadata-version path goes stale during editable-install dev workflows; reading `__version__` from the imported package always reflects the live source tree (per AP-13's pyproject↔__version__ sync rule). |

**Retrospective.** Implemented per the suggested shape. The
existing `importlib.metadata.PackageNotFoundError` fallback was
replaced with an `ImportError` fallback — if `import mgf.common`
fails, the CLI hasn't loaded anyway, but the defensive path
matches the existing error-message style.

**Concern.** `mgf-common doctor` v0.17.0 (sibling editable install)
prints a first line claiming `mgf-common v0.4.0 installed at
(namespace)`. The actual installed version is 0.17.0
(`python -c "import mgf.common; print(mgf.common.__version__)"`
prints `0.17.0`). The number in the doctor banner is decoupled
from the imported package's `__version__` — most likely a
hard-coded string that wasn't bumped during the tree of releases
between 0.4.x and 0.17.x.

**Why it matters.** `doctor` is the diagnostic CLI's "is the
install healthy" surface — the FIRST thing a new adopter runs
after `pip install` to confirm wiring. A stale version on the
first line erodes trust before the rest of the (correct, useful)
output lands. It also actively confuses adopters who paste
`doctor` output into a feedback channel: maintainer reads
"v0.4.0 installed" and starts diagnosing a four-major-versions-old
install instead of the actual one.

**Concrete evidence.** Run on PlasmaMapper @ `main` / commit
`dc8257f`, mgf-common 0.17.0 (sibling editable install,
`pip show mgf-common` confirms `Version: 0.17.0`):

```
$ mgf-common doctor
✓ mgf-common v0.4.0 installed at (namespace)
✓ py.typed marker present (downstream mypy --strict OK)
✓ [observability] extra installed (opentelemetry, sentry_sdk available)
...

$ python -c "import mgf.common; print(mgf.common.__version__)"
0.17.0
```

The offending logic is in the doctor subcommand's banner code; if
the source layout is unchanged from `mgf.common.cli._doctor`,
search for the literal string `"v0.4.0"`.

**Suggested shape.** Read `__version__` from the imported package
at call time, not from a constant in the doctor module:

```python
# mgf/common/cli/_doctor.py — current (presumed):
print(f"✓ mgf-common v0.4.0 installed at {install_path}")

# Fix:
from mgf.common import __version__
print(f"✓ mgf-common v{__version__} installed at {install_path}")
```

If the existing literal isn't a banner string but a "minimum
recognised wheel" sentinel (i.e., used elsewhere as a guard), the
right fix is to source `__version__` for the user-facing banner
and keep the sentinel for whatever logic needed it — they're
separate concerns that drifted into one variable.

**Decision rationale.** *(Filled when triaged.)*

**Retrospective.** *(Filled when shipped.)*

---

#### `PAPER-19` — `mgf-common explain` emits `UnconfiguredWarning` on stderr because the CLI dispatcher hasn't called `bootstrap()`

| Field | Value |
|---|---|
| Status | ✅ SHIPPED |
| Severity | 🟢 Nice-to-have |
| Submitter | PlasmaMapper (Phase 1 catch-up adoption, 2026-05-05) |
| Submitted | 2026-05-05 |
| Decision | accept (Approach A spirit; lighter implementation via `_set_identity`) |
| Decided on | 2026-05-05 |
| Scheduled for | 0.17.1 |
| Shipped in | `main()` in `src/mgf/common/cli/_mgfcli.py` calls `_set_identity("mgf-common-cli", __version__)` before dispatch. Subcommands that read `app_name()` / `app_version()` get the right values; `UnconfiguredWarning` doesn't fire (the warning chain checks `_CONFIGURED` which `_set_identity` flips to `True`); `vunknown` placeholder banners never appear. |

**Retrospective.** Diverged from the filing's Approach A
(`bootstrap_for_test`) on a real concern surfaced during
implementation: `bootstrap_for_test` wires the rotating-file
log handler, which writes to
`~/.local/state/mgf-common-cli/logs/...` on every CLI
invocation. That's the wrong shape for a diagnostic CLI —
side effects on the user's filesystem from `mgf-common
explain` / `doctor` / `standards` would be a different
papercut filed against us next round. Lighter alternative:
`_set_identity` sets the identity globals + flips
`_CONFIGURED=True`, suppressing the warning chain in both
`mgf.common._identity.app_name` and
`mgf.common.current_context` (both gate on the same flag).
No bootstrap, no logging wiring, no filesystem side effects.
Same observable outcome the filing wanted; honest mechanism.

This also surfaced an upstream issue: `MgfSettings` has no
field to disable file logging entirely. Worth filing as a
follow-up if a future consumer hits it (the diagnostic-CLI
shape is the canonical "I want identity + warnings off, no
observability wiring" use case).

**Concern.** `mgf-common explain` (and likely sibling subcommands
that read `MgfSettings` or call `current_context()`) prints
`UnconfiguredWarning: ... called before bootstrap()` on stderr
before producing its output. The warning is the library-correct
behaviour for *consumer code* that reads identity before
bootstrap — but the diagnostic CLI is itself the host running the
read, and it has no consumer to alert.

**Why it matters.** Adopters running `mgf-common explain` to
introspect their settings see a stderr warning that suggests
their install is mis-wired. The fix the warning suggests
(`call mgf.common.bootstrap(app_name=..., app_version=...)`) is
nonsense in the CLI context — they're not the consumer; they're
diagnosing the consumer. The warning is noise on the diagnostic
path, and it's the CLI's responsibility to silence it.

**Concrete evidence.** Run on PlasmaMapper @ `main` / commit
`dc8257f`, mgf-common 0.17.0:

```
$ mgf-common explain 2>&1 | head -3
/home/bassam/PycharmProjects/mgf_common/src/mgf/common/_identity.py:169: \
UnconfiguredWarning: mgf.common.current_context() called before bootstrap() \
— returning None. Downstream `if ctx := current_context():` patterns will \
silently no-op. Call mgf.common.bootstrap(app_name=..., app_version=...) \
at startup, or use mgf.common.bootstrap_for_test() in test fixtures.
  ctx = current_context()
mgf-common v0.17.0  active configuration for app vunknown
```

The trailing banner `for app vunknown` is the second symptom: the
CLI couldn't resolve identity (because no bootstrap), and printed
the placeholder. Two papercuts surfaced by the same root cause.

**Suggested shape.**

**Approach A (recommended) — self-bootstrap in the CLI dispatcher.**
The CLI is itself a host process; it should bootstrap before the
subcommand dispatch runs. The cleanest shape is
`bootstrap_for_test()` in the dispatcher's setup hook:

```python
# mgf/common/cli/__main__.py (or wherever dispatch lives):
def main(argv: list[str] | None = None) -> int:
    # Self-bootstrap so subcommands can read identity / settings
    # without firing UnconfiguredWarning. The CLI is its own host.
    with bootstrap_for_test(app_name="mgf-common-cli",
                            app_version=__version__) as _ctx:
        return _dispatch(argv)
```

Side benefit: the `vunknown` placeholder in the explain banner
disappears, replaced by `mgf-common v0.17.0  active configuration
for mgf-common-cli v0.17.0` — accurate.

**Approach B — suppress the warning category for CLI runs.**
`warnings.filterwarnings("ignore", category=UnconfiguredWarning)`
at CLI startup. Mechanically simpler, but addresses the symptom
not the cause: subcommands like `explain` still see "no active
context" and print `vunknown`, which is its own confusion.

**Recommended: Approach A.** Self-bootstrapping is the honest
fix; the warning never fires; the explain banner gains real
identity; consumers learn by example what the CLI is doing.

**Decision rationale.** *(Filled when triaged.)*

**Retrospective.** *(Filled when shipped.)*

---

#### `PAPER-20` — `mgf-common catch-up --apply` rewrites pyproject pin to a window around the *installed* version, not the latest *PyPI-published* version

| Field | Value |
|---|---|
| Status | ✅ SHIPPED |
| Severity | 🟡 High |
| Submitter | PlasmaMapper (Phase 1 catch-up adoption, 2026-05-05) |
| Submitted | 2026-05-05 |
| Decision | accept (Approach A — refuse rewrite for editable installs) |
| Decided on | 2026-05-05 |
| Scheduled for | 0.17.1 |
| Shipped in | `_is_editable_install()` predicate (reads `direct_url.json` from the dist-info per PEP 660) + guard in `_check_pyproject_pin` that refuses the auto-rewrite when the running mgf-common is editable. The audit row still surfaces staleness; the consumer rewrites the pin by hand against `pip index versions mgf-common`. |

**Retrospective.** Implemented Approach A from the filing.
Approach B (network fetch from PyPI's JSON API) is the
nice-to-have evolution; deferred until a consumer surfaces
real friction with the by-hand walkback. Approach C (opt-in
`--apply-pin` flag) wasn't needed once Approach A's refusal
shape works — the audit row still tells the consumer the pin
is stale, just doesn't auto-rewrite. The pre-existing
`test_apply_bumps_stale_pin` and `test_stale_pin_warns_with_fix`
unit tests now monkeypatch `_is_editable_install → False`
to preserve coverage of the PyPI-install path; a new
`TestEditableInstallPinGuard` class covers the editable-refusal
path.

**Concern.** `catch-up --apply`'s pin-rewrite uses
`mgf.common.__version__` of the **installed** wheel as the basis
for the new pin window. When a consumer dev/CI environment uses
`[tool.uv.sources]` (or `pip install -e ../mgf_common`) for
maintainer-side dogfooding, the installed version is the
sibling-source `__version__` — which can be ahead of the latest
PyPI-published version. The auto-rewrite then produces a pin no
plain-PyPI consumer can install.

**Why it matters.** PlasmaMapper hit this on 2026-05-05:
sibling-installed mgf-common 0.17.0; latest PyPI-published 0.16.0
(v0.16.1 + v0.17.0 are git-tagged but Codeberg-Woodpecker access
was pending so neither has hit PyPI). `catch-up --apply` rewrote
`pyproject.toml::project.dependencies` from `>=0.3,<0.4` →
`>=0.17.0,<0.18`. CI without the sibling override
(`pip install plasmamapper` from a fresh resolver) would fail
because `0.17.0` doesn't exist on PyPI. The walk-back is manual:
edit the pin to `>=0.16,<0.17` after `--apply` already wrote
`>=0.17.0,<0.18`. Adopters who don't notice ship a broken pin.

This is the consumer-side mirror of [PAPER-12](#paper-12) (docs
drift ahead of published wheel): catch-up's pin auto-rewrite has
no PyPI-publish awareness either.

**Concrete evidence.** PlasmaMapper @ `main` / commit `dc8257f`,
sibling editable install (`pip show mgf-common` → `Version: 0.17.0`,
`Location: ../mgf_common/src` — editable). Run captured 2026-05-05:

```
$ mgf-common catch-up
  ⚠️  pyproject.toml — mgf-common pin
      STALE: declared `>=0.3,<0.4` but current mgf-common is `0.17.0` —
      the upper bound excludes it. Suggest bumping to
      `>=0.17.0,<0.18` (2-minor window). Run with --apply to rewrite
      the line; backup written.

$ mgf-common catch-up --apply
  ℹ️  pyproject.toml — mgf-common pin: bumped pin to `>=0.17.0,<0.18`
      in /home/bassam/PycharmProjects/PlasmaMapper/pyproject.toml
      (backup: pyproject.toml.bak.1778035312)

$ pip index versions mgf-common  # PyPI-only resolver
mgf-common (0.16.0)
Available versions: 0.16.0, 0.13.0, 0.12.0, 0.11.3, 0.11.1, 0.4.2, 0.4.1, 0.4.0, 0.3.0, 0.1.0
```

Manual walk-back applied: pin reverted to `>=0.16,<0.17` to match
the PyPI-installable window. PlasmaMapper's
`docs/MGF_ADOPTION.md` §3 documents the override.

**Suggested shape.**

**Approach A — detect editable installs and refuse the auto-rewrite.**
catch-up consults `importlib.metadata.distribution("mgf-common")`
to check whether the install is `editable`. When `True`, the audit
prints the same ⚠️ row but suggests `mgf-common feedback` /
`mgf-common --consult-pypi-window` rather than auto-rewriting.

```python
def _suggest_pin(installed_version: str) -> str:
    is_editable = _is_editable_install("mgf-common")
    if is_editable:
        return (
            f"installed (editable) is {installed_version}; "
            f"NOT auto-rewriting pin — editable installs can run "
            f"ahead of PyPI. Verify the published-PyPI window with "
            f"`pip index versions mgf-common` and update the pin "
            f"by hand (or pass --consult-pypi-window for a network "
            f"resolution)."
        )
    return f"bump to >={installed_version},<{next_minor}"
```

**Approach B — query PyPI for the latest published version.**
catch-up consults
`https://pypi.org/pypi/mgf-common/json` (one HTTP GET, can be
cached) to find the latest published version, and bases the pin
on `min(installed, latest_pypi)`. When the two diverge, the audit
prints both with a hint. Network-dependent; an offline run falls
through to Approach A.

**Approach C (additive) — opt-in only.** Don't auto-rewrite
without an explicit `--apply-pin` flag. The mechanical fixes
(create CLAUDE.md, create .claude/settings.json) stay
auto-applied; the pin rewrite alone gates on the extra flag. This
is the least magical option; consumers walk in knowing the pin
won't change unless they ask.

**Recommended:** Approach A as default (zero network, zero
surprises) + Approach C (opt-in only) on top. Approach B is a
nice-to-have for environments with network. The `catch-up --apply`
output should explicitly list which pin it would have written and
where to verify the published-PyPI window.

This change also obviates the need for the per-consumer comment
block PlasmaMapper now carries above the pin
(`# Pin policy: latest installable on PyPI is 0.16.0; ...`) which
exists only to explain why dev/CI sibling-installed 0.17.0 is OK
despite the apparent pin mismatch.

**Decision rationale.** *(Filled when triaged.)*

**Retrospective.** *(Filled when shipped.)*

---

#### `PAPER-21` — `docs/CLAUDE.md` auto-block's FastAPI quick-start teaches a closed-box leak (`from mgf.common._lifecycle import bootstrap`)

| Field | Value |
|---|---|
| Status | ✅ SHIPPED |
| Severity | 🔴 Blocker |
| Submitter | PlasmaMapper (Round 1 closure verification, 2026-05-05) |
| Submitted | 2026-05-05 |
| Decision | accept (Approach A — one-line template fix + regression guard) |
| Decided on | 2026-05-06 |
| Scheduled for | 0.18.0 |
| Shipped in | One-line fix in `_QUICK_START_BLOCKS["fastapi"]` in `src/mgf/common/cli/_init_project.py` (`from mgf.common._lifecycle import bootstrap` → `from mgf.common import bootstrap`). Plus a regression-guard test class `TestQuickStartBlocksNoClosedBoxLeaks` in `tests/unit/cli/test_init_project.py` that walks every kind template's rendered output through the same `_is_private_module` predicate the catch-up audit uses for consumer src/ — covers all five `_KINDS` (cli / fastapi / django / library / service) plus a PAPER-21-specific assertion pinning the canonical public-import form. Migration guide in [`docs/cutover/archive/v0.18.0.md`](docs/cutover/archive/v0.18.0.md#paper-21--fastapi-template-closed-box-leak-fix). |

**Retrospective.** Approach A from the filing, verbatim. The
audit-and-template asymmetry — the same tool that flags
private-imports in consumer src/ was teaching them in the
auto-block — was the worst-case shape PlasmaMapper called out;
the regression-guard test ensures it can't recur on any
existing kind or any future one. The audit reuses
`_is_private_module` (the predicate already live in
`_check_closed_box_leaks`) for ground truth — no second
mechanism to drift. Approach B (post-process catch-up's
template rendering through the audit at runtime) is
defense-in-depth and remains useful for project-scaffolding
flows other than init-project; deferred until a consumer
hits friction outside the init-project path.

**Concern.** The new `kind: fastapi` template that ships in v0.17.2
(closes PAPER-17, thank you) writes a "Quick start" code block into
the auto-managed section of `docs/CLAUDE.md` whose imports include:

```python
from mgf.common._lifecycle import bootstrap
```

`mgf.common._lifecycle` is a private module (single-leading-underscore
per AP-14). The public name is `mgf.common.bootstrap` — already in
`mgf.common.__all__` (line 50 of `src/mgf/common/__init__.py` on
master). The template is teaching new consumers to import from the
private path, directly contradicting the rule the catch-up audit
already enforces in its closed-box-leak row.

**Why it matters.** This is the worst-case failure mode for an
auto-managed CLAUDE.md block: the same tool that **audits** for
closed-box leaks (`mgf-common catch-up` ✅ closed-box leaks row, shipped
in commit `8cf5ecc` closing PAPER-08) is also **writing** them into
the consumer's session-loaded reference doc. Every Claude session in
a freshly-scaffolded fastapi project starts with the wrong import
pattern in context. Consumers who copy-paste the example into `src/`
will then trip the closed-box-leak audit on their next catch-up run —
audit failing on the very pattern the audit's auto-block taught.

This is also a 🔴 because:
- Severity scales with the number of consumers running catch-up. The
  fastapi-kind template just shipped; every new fastapi consumer
  inherits the leak from session 1.
- Fix is one-line in the template (the import path); zero risk to
  existing call sites.
- The issue is invisible to non-AI-agent reviewers: the `_lifecycle`
  prefix looks like just a sub-module path unless the reader knows
  the closed-box convention.

**Concrete evidence.** PlasmaMapper @ commit `0e5117d` after running
`mgf-common catch-up --apply` against sibling-installed v0.17.2:

```
$ head -185 docs/CLAUDE.md | tail -25
## Quick start — bootstrapping this project

This project depends on `mgf-common`. The canonical entry point
is `mgf.common.bootstrap()`:

\`\`\`python
# src/plasmamapper/app.py
from contextlib import asynccontextmanager
from fastapi import FastAPI
from mgf.common._lifecycle import bootstrap            # ← LEAK
from mgf.common.fastapi import (
    ExceptionTranslationMiddleware,
    RequestIdMiddleware,
)

@asynccontextmanager
async def lifespan(app: FastAPI):
    with bootstrap(app_name="plasmamapper", app_version="0.1.0"):
        yield

app = FastAPI(lifespan=lifespan)
app.add_middleware(ExceptionTranslationMiddleware)
app.add_middleware(RequestIdMiddleware)
\`\`\`
```

The prose immediately above the snippet says "The canonical entry
point is `mgf.common.bootstrap()`" — which is correct — and then the
code block imports from the private module. The two contradict each
other.

Verification of the public name:

```
$ python -c "from mgf.common import bootstrap; print(bootstrap.__module__)"
mgf.common._lifecycle           # actual implementation lives in _lifecycle

$ grep -n "\"bootstrap\"" src/mgf/common/__init__.py
50:    "bootstrap",                # listed in __all__ — public
```

The right import is `from mgf.common import bootstrap`. The
implementation can stay in `_lifecycle`; that's an internal detail
the public re-export exists to hide.

**Suggested shape.** One-line fix in the fastapi-kind template
(`templates/fastapi/CLAUDE.md.j2` or wherever the auto-block source
lives):

```diff
- from mgf.common._lifecycle import bootstrap
+ from mgf.common import bootstrap
```

The same audit applies to every other kind template (`library`,
`cli`, `django`, `flask`) — recommend a one-pass grep over all
template snippets for `from mgf.common\._` imports as a regression
check during template authoring. The closed-box-leak audit's regex
in `_check_closed_box_leaks` is the right ground truth; reuse it
against the rendered templates as a unit test.

**Approach A (one-line fix).** Edit each kind template; pin a unit
test that lints rendered templates with the closed-box-leak audit's
regex. Recommended.

**Approach B (template lint as part of catch-up).** When catch-up
writes a template into a consumer project, post-process the rendered
output through the closed-box-leak audit's regex; fail loudly if
any private import slipped through. Defense in depth — useful as a
safety net even after Approach A lands. Not strictly necessary but
cheap.

**Decision rationale.** *(Filled when triaged.)*

**Retrospective.** *(Filled when shipped.)*

---

#### `PAPER-22` — `mgf.common.alembic.configure_env` does not accept `include_object=` filter, blocking PostGIS / Timescale autogenerate hygiene

| Field | Value |
|---|---|
| Status | ✅ SHIPPED |
| Severity | 🟢 Nice-to-have |
| Submitter | PlasmaMapper (Phase B0 web-adapter trial, 2026-05-05) |
| Submitted | 2026-05-05 |
| Decision | accept (Approach A — additive `include_object=` + `include_schemas=` kwargs) |
| Decided on | 2026-05-07 |
| Scheduled for | v0.19.0 |
| Shipped in | v0.19.0 — `mgf.common.alembic.configure_env` now accepts two keyword-only parameters that pass straight through to `alembic.context.configure(...)`: `include_object: Callable[..., bool] \| None = None` (filter callable) and `include_schemas: bool = False`. Defaults match alembic's own defaults — no behaviour change for current users. Migration guide in [`docs/cutover/archive/v0.19.0.md`](docs/cutover/archive/v0.19.0.md#paper-22--alembic-include_object-pass-through). |

**Concern.** :func:`mgf.common.alembic.configure_env` (v0.18.0) accepts
``database_url`` / ``target_metadata`` / ``compare_type`` /
``compare_server_default`` / ``naming_convention``. It does NOT accept
``include_object=`` — the alembic ``EnvironmentContext.configure`` knob
that lets a project skip specific objects from autogenerate.

**Why it matters.** Postgres extensions install their own internal
tables that consumers don't own and don't want autogenerate to revision.
The canonical case is **PostGIS** — installing the extension creates
``spatial_ref_sys`` (and a small handful of others). Without
``include_object``, every ``alembic revision --autogenerate`` after
PostGIS installation produces a phantom drop migration for these
tables. Same problem applies to TimescaleDB's ``_timescaledb_internal``
schema, pgvector's housekeeping, and any extension that introspects
as plain SQL objects.

PlasmaMapper is the first web consumer to surface this. Our prior
hand-rolled ``alembic/env.py`` had:

```python
include_object=lambda obj, name, type_, reflected, compare_to: (
    not (type_ == "table" and name in {"spatial_ref_sys"})
),
```

The configure_env adapter swap (B0 trial, ~95→25 lines, real win)
loses this filter. We mitigated by documenting the gap inline — the
project disables autogenerate per ADR for migration safety, so we
don't trip the bug today, but any consumer who DOES use autogenerate
+ extensions will trip on the first ``alembic revision``.

**Concrete evidence.** Sibling-installed mgf-common 0.18.0;
PlasmaMapper @ commit `2956724` after Phase B0 swap:

```
$ python -c "
import inspect
from mgf.common.alembic import configure_env
print(list(inspect.signature(configure_env).parameters))
"
['database_url', 'target_metadata', 'compare_type', 'compare_server_default', 'naming_convention']
```

PlasmaMapper's pre-swap env.py (now in git history) carried the
filter callable; the post-swap env.py at
[`alembic/env.py`](https://codeberg.org/magogi-products/PlasmaMapper/src/branch/main/alembic/env.py)
documents the gap inline.

**Suggested shape.** Add ``include_object=`` (and the closely-related
``include_schemas=``) as keyword-only parameters that pass through to
``EnvironmentContext.configure``. Default ``None`` for both — alembic
treats ``None`` as "include everything", matching today's adapter
behaviour for non-extension users:

```diff
 def configure_env(
     *,
     database_url: str,
     target_metadata: Any,
     compare_type: bool = True,
     compare_server_default: bool = True,
     naming_convention: dict[str, str] | None = None,
+    include_object: Callable[..., bool] | None = None,
+    include_schemas: bool = False,
 ) -> None:
```

The public surface grows two names; internal wiring is a one-line
plumb-through to ``context.configure(include_object=include_object,
include_schemas=include_schemas, ...)``.

**Approach A (recommended) — pass-through kwargs.** As above. Smallest
surface; matches alembic's own naming; consumers who don't use
extensions stay zero-config.

**Approach B — typed extension-skip helper.** Ship an
``mgf.common.alembic.skip_extension_tables(*, postgis=False,
timescaledb=False, pgvector=False)`` that returns the right
``include_object`` callable. Higher-level convenience but pre-commits
to a list of supported extensions; first non-listed extension brings
the consumer back to Approach A anyway.

**Recommended:** Approach A as the primitive; Approach B can be
layered on later as a typed convenience that calls into Approach A.
Approach A is what unblocks PlasmaMapper today.

**Cost if deferred past v1.0.** Adding kwargs is additive — safe in any
release. Deferring past v1.0 just means consumers continue to either
(a) rewrite env.py to bypass configure_env when they need autogen
filtering — exactly the boilerplate the adapter exists to absorb, or
(b) disable autogenerate entirely (PlasmaMapper's current stance) and
hand-write every migration.

**Decision rationale.** Approach A (pass-through kwargs) — smallest
surface, matches alembic's own naming, consumers without extensions
stay zero-config. Approach B (typed extension-skip helper) deferred:
pre-commits to a list of supported extensions, and the first
non-listed extension brings the consumer back to Approach A anyway.

**Retrospective.** Approach A from the filing, verbatim. PostGIS /
TimescaleDB / pgvector consumers can plug their existing
`include_object` callable directly into `configure_env` without
rewriting the env.py around it. PlasmaMapper's pre-swap callable
(`spatial_ref_sys` skip) was the canonical use case driving the
design; if/when they flip autogenerate back on after their
migration-safety ADR review, it plumbs through unchanged. Strictly
additive with safe defaults — no migration burden for consumers
who don't use extensions.

| Field | Value |
|---|---|
| Status | ✅ SHIPPED |
| Severity | 🟢 Nice-to-have |
| Submitter | PlasmaMapper (Phase B0 web-adapter trial, 2026-05-05) |
| Submitted | 2026-05-05 |
| Decision | accept (Approach A — document editable-install caveat in plugin docstring + standards) |
| Decided on | 2026-05-07 |
| Scheduled for | v0.19.0 |
| Shipped in | v0.19.0 — documentation-only. Editable-install caveat added to the `mgf.common.pytest_plugin` docstring + [`docs/recipes/testing.md`](docs/recipes/testing.md). Opt-in form: `pytest_plugins = ["mgf.common.pytest_plugin"]` in consumer `tests/conftest.py`. PyPI-installed consumers are unaffected — the entry point fires during `pip install` / `uv pip install`. Migration guide in [`docs/cutover/archive/v0.19.0.md`](docs/cutover/archive/v0.19.0.md#paper-23--pytest_plugin-editable-install-caveat-documented). |

**Concern.** :mod:`mgf.common.pytest_plugin`'s docstring claims
"Auto-registered via the ``pytest11`` entry point in ``pyproject.toml``.
After installing ``mgf-common`` (any extra), every pytest run sees the
fixtures below without further configuration." In a sibling editable
install via ``[tool.uv.sources]``, this isn't happening — the plugin
isn't auto-loaded, and the documented "no configuration needed"
contract breaks.

**Why it matters.** The strategic-review framing for the plugin (per
the docstring's "Why this exists" section) was: every consumer
reinvents test-fixture boilerplate; auto-registering closes that gap.
When the auto-registration silently fails in editable installs, the
gap reopens for exactly the consumers who are most likely to be
testing against sibling-source — early adopters and the maintainer's
own dogfooding workflow.

**Concrete evidence.** PlasmaMapper @ commit `2956724`, sibling
editable install of mgf-common 0.18.0:

```
$ python -c "from importlib.metadata import entry_points; \
print([e.name for e in entry_points(group='pytest11')])"
['anyio', 'pytest_cov', 'asyncio', 'hypothesispytest']
# Note: no 'mgf_common'

$ pytest --fixtures | grep -B1 mgf_
# (no output — fixtures not registered)

$ pytest -p mgf.common.pytest_plugin --fixtures | grep mgf_
mgf_settings -- ../mgf_common/src/mgf/common/pytest_plugin.py:71
mgf_context -- ../mgf_common/src/mgf/common/pytest_plugin.py:82
mgf_context_with_capture -- ../mgf_common/src/mgf/common/pytest_plugin.py:98
redaction_recorder -- ../mgf_common/src/mgf/common/pytest_plugin.py:123
mgf_otel_provider -- ../mgf_common/src/mgf/common/pytest_plugin.py:165
# ✅ explicit -p loads the plugin and fixtures register correctly
```

The entry point IS declared correctly in
``mgf_common/pyproject.toml`` (``[project.entry-points."pytest11"]
mgf_common = "mgf.common.pytest_plugin"``); the issue is that
``uv sync`` against a ``[tool.uv.sources]`` editable target does not
write the dist-info ``entry_points.txt`` that pytest's plugin
discovery walks at startup.

PlasmaMapper worked around this by adding
``pytest_plugins = ["mgf.common.pytest_plugin"]`` to its
``tests/conftest.py`` — which has the side-effect of being more
discoverable (a reader of conftest sees the dependency explicitly)
but contradicts the "no configuration needed" promise the plugin's
docstring makes.

**Suggested shape.**

**Approach A — document the workaround.** Add a one-paragraph note to
the plugin docstring (and ``mgf-common standards testing``) explaining
that editable installs may need
``pytest_plugins = ["mgf.common.pytest_plugin"]`` in the consumer's
``conftest.py``. Cheap; preserves the "auto-registered on PyPI
install" property; honest about the editable-install caveat.

**Approach B — make pytest discovery resilient.** Investigate why
``uv sync`` skips writing ``entry_points.txt`` for editable installs;
either upstream a fix to ``uv``, or document a ``uv sync --reinstall``
workflow that re-registers entry points. Out of scope for mgf-common,
but worth flagging because the same issue affects every consumer
trying to dogfood sibling-source.

**Approach C — don't rely on entry points.** Drop the ``pytest11``
entry-point declaration; instead document
``pytest_plugins = ["mgf.common.pytest_plugin"]`` as the canonical
opt-in shape. Loses the auto-registration convenience for PyPI
installs but eliminates the silent-failure mode.

**Recommended:** Approach A (document) immediately; Approach B
investigation as follow-up to know whether this is a uv bug or
expected behaviour. Approach C is too aggressive — the auto-loading
on PyPI install IS the right ergonomics for production consumers.

**Decision rationale.** Approach A (document the workaround). The
"auto-registered on PyPI install" property holds for production
consumers — that's the contract worth preserving. The editable-install
silent-failure mode is upstream behaviour (`uv sync` against
`[tool.uv.sources]` editable targets does not write the dist-info
`entry_points.txt`); a one-paragraph docstring note + the canonical
opt-in shape closes the discoverability gap without destabilising
the entry-point ergonomics. Approach C (drop the entry point
entirely) was rejected as too aggressive.

**Retrospective.** Approach A from the filing. PlasmaMapper's
existing `pytest_plugins = ["mgf.common.pytest_plugin"]` workaround
in `tests/conftest.py` is now the documented opt-in for editable
installs — the docstring + testing recipe match what they did. No
code change. Approach B (upstream investigation into uv's editable
`entry_points.txt` behaviour) deferred until a maintainer has
capacity; the workaround is durable and more discoverable than the
entry-point form anyway (a reader of conftest sees the dependency
at a glance).

| Field | Value |
|---|---|
| Status | ✅ SHIPPED |
| Severity | 🟡 High |
| Submitter | PlasmaMapper (v0.18.0 cutover-guide read, 2026-05-05) |
| Submitted | 2026-05-05 |
| Decision | accept (Approach A — auto-read `http_status` as fallback after status_map miss) |
| Decided on | 2026-05-07 |
| Scheduled for | v0.19.0 |
| Shipped in | v0.19.0 — `mgf.common.fastapi.ExceptionTranslationMiddleware._lookup_status` now resolves in this order: (1) `status_map` entries for any non-`AppError` ancestor (the explicit override seam — `AppError` itself deferred because it acts as a catch-all and would mask the class-declared status), (2) class-declared `HttpError.http_status` (HTTP-01 leaves self-describe), (3) `status_map[AppError]` catch-all (default 500). Backward compatible — explicit `status_map` entries still win. Migration guide in [`docs/cutover/archive/v0.19.0.md`](docs/cutover/archive/v0.19.0.md#paper-24--exceptiontranslationmiddleware-reads-http_status). |

**Concern.** v0.18.0 shipped HTTP-01 (`HttpError` + 9 status-bearing
concretes; each carries `http_status: int` as a class attribute) AND
ships `mgf.common.fastapi.ExceptionTranslationMiddleware` (with a
``status_map: dict[type[AppError], int]`` for translation). The two
adapters don't compose: `_lookup_status` walks the MRO looking for
``status_map`` entries only, ignoring `http_status` even when the
exception's class declares it.

The result: even after fully adopting HTTP-01 leaves
(`MyDomainError(HttpNotFound)`), a consumer still has to register
each leaf in ``status_map`` for the middleware to find the 404 — the
information is already on the class, redundantly written into the map.

**Why it matters.** This is the missing keystone in the v0.18.0
architectural batch. HTTP-01 invented `http_status` precisely to make
HTTP-shaped exceptions self-describing; the middleware predates HTTP-01
and doesn't know to look. With auto-read, a project's `status_map`
shrinks to only legacy non-HttpError exceptions; a project that fully
adopts HttpError leaves needs no status_map at all.

This is also the only friction PlasmaMapper found in v0.18.0 worth
acting on. PlasmaMapper's exception hierarchy is small (two tenant
errors today), so we'd happily rebase on `HttpNotFound` if the
middleware composed — but as long as the status_map is mandatory,
rebasing buys us nothing over today's explicit map.

**Concrete evidence.**
`/home/bassam/PycharmProjects/mgf_common/src/mgf/common/fastapi/_exceptions.py:145-158`
(at `mgf-common@6bf3a1e`):

```python
def _lookup_status(self, exc_type: type[AppError]) -> int:
    """Return the status for ``exc_type`` walking MRO until a hit.

    Default to 500 if nothing matches (shouldn't happen — AppError
    is the catch-all in DEFAULT_STATUS_MAP).
    """
    for ancestor in exc_type.__mro__:
        if not isinstance(ancestor, type):
            continue
        if not issubclass(ancestor, AppError):
            continue
        if ancestor in self._status_map:
            return self._status_map[ancestor]
    return 500
```

No `getattr(exc_type, 'http_status', None)` check anywhere. Verified
also via grep: `http_status` does not appear in
`mgf/common/fastapi/_exceptions.py`.

PlasmaMapper's current `status_map` (in
`src/plasmamapper/api/app.py`) extends `DEFAULT_STATUS_MAP` for the
two tenant exceptions:

```python
_PLASMA_STATUS_MAP = {
    **DEFAULT_STATUS_MAP,
    TenantNotFoundError: 404,        # PM-MT-12
    CrossTenantAccessError: 404,     # PM-MT-07 — not 403
}
```

If we rebased `TenantNotFoundError(HttpNotFound, TenantError)`, the
`http_status = 404` would be on the class — but the middleware would
still look only at `_PLASMA_STATUS_MAP` to find it, so the entry
would have to stay. No simplification gained.

**Suggested shape.**

**Approach A — auto-read `http_status` as a fall-back when status_map
misses.** Smallest surface change. ``_lookup_status`` walks the
status_map first (preserving status_map's "I want to override the
default for this type" behaviour); on a miss, checks
``getattr(exc_type, 'http_status', None)``; falls back to 500 if
neither resolves.

```diff
 def _lookup_status(self, exc_type: type[AppError]) -> int:
     for ancestor in exc_type.__mro__:
         if not isinstance(ancestor, type):
             continue
         if not issubclass(ancestor, AppError):
             continue
         if ancestor in self._status_map:
             return self._status_map[ancestor]
+    # No status_map hit. Fall back to the exception's self-declared
+    # http_status if it has one (HTTP-01 leaves carry it as a class
+    # attribute). Default 500 if nothing resolves.
+    declared = getattr(exc_type, "http_status", None)
+    if isinstance(declared, int):
+        return declared
     return 500
```

Backward-compatible (status_map still wins); HTTP-01 leaves work
without registration; legacy non-HttpError types continue to require
status_map entries as today.

**Approach B — auto-read FIRST, status_map as override.** Reverse the
priority: prefer the class-declared `http_status`; let status_map
override only when the consumer explicitly wants different behaviour.
Cleaner mental model ("the exception knows its status; the map is for
exceptions") but breaks the current contract (consumers who set a
status_map entry today and ALSO have `http_status` on the class get
different behaviour after the change).

**Recommended:** Approach A. Status_map's role as an "override here"
mechanism stays; HTTP-01 leaves get the free compose; no consumer
breaks.

**Cost if deferred past v1.0.** `http_status` becomes vestigial — the
attribute exists but the middleware that's most consumers' translation
seam can't see it. Downstream consumers will quietly migrate
HttpError-rooted exceptions BACK to bespoke `AppError`-rooted ones
because the rebase loses status_map entries without saving any
translation logic. The HTTP-01 adoption story collapses.

**Decision rationale.** Approach A (auto-read `http_status` as fallback
after status_map miss). Status_map's role as an "override here"
mechanism is preserved; HTTP-01 leaves get the free compose; no
existing consumer breaks. Approach B (auto-read FIRST, status_map as
override) was rejected because it changes behaviour for any consumer
who already has both a `status_map` entry AND `http_status` on the
class.

**Retrospective.** Approach A from the filing, verbatim. The keystone
fix: HTTP-01 invented `http_status` to make HTTP-shaped exceptions
self-describing, but v0.18.0 didn't wire the middleware to read it.
v0.19.0 closes the same-release-introduced regression in the
next-release window — the cutover-guide pattern caught it on
PlasmaMapper's first read-through of v0.18.0, before any production
consumer hit the silent rebase-buys-nothing failure mode. The pattern
is paying for itself. Consumers rooting domain exceptions in
`HttpError` subclasses can now drop redundant `status_map` entries;
PlasmaMapper's `_PLASMA_STATUS_MAP` for `TenantNotFoundError` /
`CrossTenantAccessError` is the canonical first-beneficiary case.

| Field | Value |
|---|---|
| Status | ✅ SHIPPED |
| Severity | 🟡 High |
| Submitter | inthewords (Phase 3 adoption walk, 2026-05-07) |
| Submitted | 2026-05-07 |
| Decision | accept (Approach A — both fixes additive: `MgfSettings` `.env` prefix filter + `bootstrap(setup_logging=...)` flag) |
| Decided on | 2026-05-07 |
| Scheduled for | v0.19.0 |
| Shipped in | v0.19.0 — two additive changes. **(1)** `mgf.common.config.settings_config()` now defaults `dotenv_filtering="match_prefix"` — `BaseAppSettings` subclasses with a non-empty `env_prefix` silently ignore unprefixed `.env` keys instead of routing them to `extra="forbid"` and raising `ValidationError`. Behaviour change for `extra="allow"` subclasses that relied on the legacy permissive dotenv: pass `dotenv_filtering=None` in `model_config` to restore the old shape. **(2)** `bootstrap()` grows a keyword-only `setup_logging: bool = True` parameter; when `False`, the StreamHandler + RotatingFileHandler install + per-component `level_overrides` are skipped. Identity, OTel, excepthooks, AppContext registration, and the bootstrap-log buffer replay still happen. Default `True` preserves v0.18 behaviour. Permanent recipe (post-v0.20.0): [`docs/recipes/framework-owned-logging.md`](docs/recipes/framework-owned-logging.md). Migration guide in [`docs/cutover/archive/v0.19.0.md`](docs/cutover/archive/v0.19.0.md#bootstrap-01--django-adoption-blocker). |

**Concern.** Two concrete blockers prevent inthewords (and any
Django web app) from adopting `mgf.common.bootstrap()` as the
canonical wiring entry point. Both surface immediately on a
clean adoption attempt.

**(1) `MgfSettings()` reads the project's `.env` file via
pydantic-settings and rejects every Django-side env var as
`extra=forbid`** — even though `MgfSettings.model_config`
correctly sets `env_prefix="MGF_"`. The prefix governs
*environment variable* lookups (so `MGF_LOGGING__LEVEL` →
`logging.level`) but does NOT filter the `.env` file's keys.
pydantic-settings reads every key in `.env` and tries to map
them to MgfSettings fields, failing with:

```
pydantic_core._pydantic_core.ValidationError: 13 validation errors
for MgfSettings
secret_key
  Extra inputs are not permitted [type=extra_forbidden,
  input_value='dev-test-secret-key-not-for-production-use-only']
allowed_hosts
  Extra inputs are not permitted [type=extra_forbidden,
  input_value='localhost,127.0.0.1']
db_name
  Extra inputs are not permitted [type=extra_forbidden,
  input_value='inthewords']
... (10 more)
```

The Django `.env` legitimately holds `SECRET_KEY`, `DB_NAME`,
`DB_USER`, `REDIS_HOST`, `CELERY_BROKER_URL`, etc. — Django's
own settings module reads them. There's nothing wrong with the
project's `.env`. `MgfSettings` is wrong to treat unprefixed
keys as extras when its own config says `env_prefix="MGF_"`.

Workaround: `MgfSettings(_env_file=None)` skips .env loading
entirely. But that defeats the purpose of pydantic-settings's
.env support for any consumer that DOES want to put
`MGF_OTEL__ENABLED=true` in their .env file.

**(2) `bootstrap()` unconditionally installs `StreamHandler` +
`RotatingFileHandler` on the root logger.** Verified
empirically:

```python
import logging, mgf.common
from mgf.common.settings import MgfSettings

# Even with explicit settings, no observability features:
settings = MgfSettings(_env_file=None)  # bypass issue (1)
ctx = mgf.common.bootstrap(
    app_name='inthewords',
    app_version='0.0.0',
    settings=settings,
)
print([h.__class__.__name__ for h in logging.getLogger().handlers])
# ['StreamHandler', 'RotatingFileHandler']
```

There's no `setup_logging=False` flag on `bootstrap()`. The
`bootstrap()` signature (v0.18.0) is just
`(app_name, app_version, *, settings)`. The internal
`mgf.common.observability.setup_logging` is called
unconditionally and installs handlers regardless of settings
values.

For Django apps:
- Django's `LOGGING` dictConfig (in `config/settings/*.py`)
  already configures the project's logging stack at
  settings-module-load time.
- `bootstrap()` runs LATER, in
  `apps/core/apps.py::CoreConfig.ready()` (the natural Django
  seam), and adds two more root handlers.
- Result: every log line is emitted twice (once by Django's
  configured handler, once by mgf's installed handler) AND
  the duplicate uses mgf's `JsonFormatter`, which has the
  deployment-coupled-incompatible JSON shape inthewords
  documented in Phase 5 (per LOG-01 cloud-native carve-out
  — `{ts, level, logger, msg, +flat extras}` vs the project's
  `{timestamp, level, logger, message, extra: {...}}`).

The handlers also include `RotatingFileHandler` writing to a
file under `<state>/<app>/logs/<app>.log` — which on a
cloud-native container is an ephemeral path that vanishes on
restart. Same anti-pattern LOG-01 closed.

**Why it matters.** The strategic-review priority 1
("get a second consumer") explicitly invited
non-pain reports. Phase 3 of the inthewords adoption walk
ran into pain. Both blockers are concrete, reproducible, and
the workarounds for one don't help the other.

The two issues compose: even if (1) is worked around,
(2) still blocks adoption because the unconditional handler
install conflicts with Django's LOGGING dictConfig AND with
the LOG-01 carve-out the project explicitly took. Fixing
either one alone doesn't unblock; both need addressing.

The pattern generalises beyond Django. Any Python application
framework that owns its own logging stack (Flask via
`app.logger`, FastAPI via uvicorn's logging, Pyramid, etc.)
will hit issue (2). Issue (1) generalises to any consumer
whose `.env` is shared with another tool that uses
pydantic-settings (Pydantic-based APIs, SQLAlchemy with
pydantic-validated config, etc.).

**Concrete evidence.** inthewords has 1140 tests in CI and a
production deployment story (Infomaniak Public Cloud →
Grafana Cloud log aggregation). The Phase 5 LOG-01 carve-out
is in the standards now (v0.18.0). The project's logging
config:

- `config/settings/dev.py` — DevFormatter for TTY readability
- `config/settings/prod.py` — `apps.core.logging.JsonFormatter`
  to stdout for Grafana Cloud
- Five `TestJsonShapeContract` regression tests pin the wire
  format (added in commit `955ba30`).

`bootstrap()` adopting AS-IS would break the Grafana parsers
on the next deploy.

**Suggested shape.**

**Approach A (recommended) — both fixes are additive flags
on bootstrap() / MgfSettings.**

1. `MgfSettings.model_config` should respect `env_prefix` for
   .env file scanning too. Concretely: when reading `.env`,
   pydantic-settings (or the MgfSettings construction layer)
   should silently skip keys that don't start with `MGF_`. The
   prefix is the consumer's contract — it tells mgf-common
   "anything not MGF_-prefixed is not yours". Implementation:
   subclass pydantic-settings's source loader, OR use the
   `env_ignore_empty` / `env_nested_delimiter` machinery to
   ignore-but-don't-fail on unprefixed keys.

2. `bootstrap()` grows a `setup_logging: bool = True`
   keyword-only argument. When `False`, the internal
   `observability.setup_logging()` call is skipped. The
   AppContext registration and identity wiring still happen
   (those are the value-add for Django consumers without
   OTel). The function shape becomes:

   ```python
   def bootstrap(
       app_name: str | None = None,
       app_version: str | None = None,
       *,
       settings: MgfSettings | None = None,
       setup_logging: bool = True,   # NEW
   ) -> AppContext:
       ...
       if setup_logging:
           _setup_logging(...)
       # rest of bootstrap unchanged
   ```

   Django consumers call `bootstrap(setup_logging=False)`
   from `CoreConfig.ready()`; their existing LOGGING
   dictConfig stays authoritative.

**Approach B — a separate `mgf.common.bootstrap_minimal()`
entry point.**

A second function that does identity registration + AppContext
without ever touching observability. For consumers who own
their stack and want only the cross-consumer-uniform
identity layer.

```python
def bootstrap_minimal(
    app_name: str | None = None,
    app_version: str | None = None,
) -> AppContext:
    """Like bootstrap() but installs no logging handlers, no
    OTel, no excepthook. For framework consumers (Django,
    FastAPI, Flask, …) that own their observability stack."""
```

**Recommend Approach A.** Single bootstrap() entry point,
opt-out flag is more discoverable than a sibling function.
Doesn't fragment the API surface. The .env-prefix fix is
strictly additive (today's behavior is buggy from the
consumer's perspective; respecting `env_prefix` matches user
expectation).

Approach B is the easier ship if the maintainer wants a
quicker close — adds ~30 lines and doesn't risk breaking
existing consumers' bootstrap call shape.

**Cross-references.**
- inthewords Phase 5 (LOG-01 carve-out, deployment-coupled
  JSON shape rationale): commit `955ba30` in inthewords;
  cutover guide §LOG-01.
- inthewords Phase 3 closeout (this filing's trigger):
  `docs/MGF_COMMON_ADOPTION.md` decisions log entry
  2026-05-07.
- Adjacent: CONFIG-01's framework-native carve-out shipped
  in v0.18.0 acknowledged that Django's `from django.conf
  import settings` is first-class compliant. BOOTSTRAP-01
  extends that recognition to the bootstrap entry point —
  framework-native consumers shouldn't have to fight the
  bootstrap call to opt out of pieces their framework
  already owns.

**Decision rationale.** Approach A — both fixes are additive flags
with safe defaults. Single bootstrap() entry point with an opt-out
flag is more discoverable than a sibling `bootstrap_minimal()`
function (Approach B) and doesn't fragment the API surface. The
`.env`-prefix fix is strictly additive: today's behaviour was buggy
from the consumer's perspective; respecting `env_prefix` matches
user expectation and unblocks every consumer with a multi-tool
`.env`.

**Retrospective.** Approach A from the filing, verbatim. inthewords
Phase 3 unblocked. The pattern generalises beyond Django — Flask
(`app.logger`), FastAPI/uvicorn, Pyramid, aiohttp all use the same
`setup_logging=False` opt-out for framework-owned logging, and
PAPER-25 promotes the worked example to a permanent recipe in
v0.20.0. The `dotenv_filtering="match_prefix"` default benefits
every `BaseAppSettings` subclass with a non-empty `env_prefix`;
consumers with single-tenant `.env` are unaffected. Two structural
blockers closed in one release; the BOOTSTRAP area opens for future
framework-fit work.

---

#### `PAPER-25` — Promote `bootstrap(setup_logging=False)` to a permanent recipe (`docs/recipes/framework-owned-logging.md`)

| Field | Value |
|---|---|
| Status | ✅ SHIPPED |
| Severity | 🟢 Nice-to-have |
| Submitter | inthewords (golden-example pass, 2026-05-07) |
| Submitted | 2026-05-07 |
| Decision | accept (promote BOOTSTRAP-01 cutover-guide content to a permanent recipe with Django + FastAPI + Flask sections) |
| Decided on | 2026-05-07 |
| Scheduled for | v0.20.0 |
| Shipped in | v0.20.0 — permanent recipe at [`docs/recipes/framework-owned-logging.md`](docs/recipes/framework-owned-logging.md) (originally landed at `docs/public/recipes/framework-owned-logging.md`; v0.25.0 doc-restructure flattened to current path). Sections: *When to use* (four "yes if" triggers + three "no if" cases); *What `setup_logging=False` preserves* (table comparing the two paths across nine wiring steps); *Django (`AppConfig.ready()`)*; *FastAPI (lifespan context manager)*; *Flask (app factory)*; *What you give up* (three explicit trade-offs); *Cross-references* to BOOTSTRAP-01 + the v0.19.0 cutover guide + the web subtree. Migration guide in [`docs/cutover/archive/v0.20.0.md`](docs/cutover/archive/v0.20.0.md#paper-25--framework-owned-logging-recipe). |

**Concern.** BOOTSTRAP-01's cutover-guide entry (v0.19.0
§BOOTSTRAP-01) is the canonical pattern for any framework
consumer that owns its own logging stack. It applies to
Django (inthewords' use case), FastAPI behind uvicorn (which
configures uvicorn-logging), Flask (`app.logger`), Pyramid,
aiohttp, etc. Currently the pattern lives only in the
v0.19.0 cutover guide — a per-release document.

Cutover guides are **time-bounded** by design (REL-09): they
narrate one release's migration story. The
`setup_logging=False` pattern is **permanent reference**:
every future framework consumer needs the same shape on day
one of their adoption.

**Why it matters.** A FastAPI consumer adopting mgf-common
six months from now will read v0.19.0's cutover guide if
they think to look there, but they more naturally look in
`docs/standards/` or `docs/recipes/`. The
v0.19.0-specific framing ("here's what changed in this
release") doesn't read as "here's the canonical way to wire
bootstrap on a framework consumer."

Promoting to a recipe at
`docs/recipes/framework-owned-logging.md` is a **30-minute
move** of the existing cutover-guide content with framework-
parameterised examples added (Django shown today; FastAPI
+ Flask added).

**Concrete evidence.** inthewords' working bootstrap
adoption is 12 lines in `apps/core/apps.py::CoreConfig.ready()`:

```python
def ready(self) -> None:
    if self._mgf_ctx is None:
        from mgf.common import bootstrap
        from mgf.common.settings import MgfSettings
        self._mgf_ctx = bootstrap(
            app_name='inthewords',
            app_version='0.0.0',
            settings=MgfSettings(),
            setup_logging=False,  # Django owns LOGGING
        )
```

The same shape for FastAPI:

```python
# app/main.py — FastAPI lifespan integration
from contextlib import asynccontextmanager
from fastapi import FastAPI
from mgf.common import bootstrap
from mgf.common.settings import MgfSettings


@asynccontextmanager
async def lifespan(app: FastAPI):
    ctx = bootstrap(
        app_name='myapp',
        app_version=__version__,
        settings=MgfSettings(),
        setup_logging=False,  # uvicorn / project-side logging owns it
    )
    yield
    ctx.shutdown()


app = FastAPI(lifespan=lifespan)
```

For Flask:

```python
# app/__init__.py
from mgf.common import bootstrap
from mgf.common.settings import MgfSettings


def create_app():
    app = Flask(__name__)
    # ... configure_logging(app) etc.
    app._mgf_ctx = bootstrap(
        app_name='myapp',
        app_version=app.config['VERSION'],
        settings=MgfSettings(),
        setup_logging=False,  # Flask's app.logger / dictConfig owns it
    )
    return app
```

The recipe consolidates: the call shape, the placement
across frameworks (Django ready() / FastAPI lifespan / Flask
factory), the rationale (why owned-logging consumers should
opt out), and the OTel-on-day-one note (`setup_logging=False`
preserves OTel auto-init; only logging-handler installation
is skipped).

**Suggested shape.** A single ~80-line markdown file at
`docs/recipes/framework-owned-logging.md`. Sections:

```
# Framework-owned logging — bootstrap(setup_logging=False)

## When to use this pattern
## What setup_logging=False preserves
## Django (AppConfig.ready)
## FastAPI (lifespan context manager)
## Flask (app factory)
## What you give up
## Cross-references (BOOTSTRAP-01, the v0.19.0 cutover guide,
   inthewords' ADR-006)
```

The Django + FastAPI + Flask sections are each ~10-15 lines
of code + 2-3 lines of prose. The "What setup_logging=False
preserves" section is the load-bearing piece — it explicitly
says "identity, OTel auto-init, excepthooks, AppContext
registration are all still wired." Disambiguates from
"setup_logging=False = no observability at all."

**Relationship to ASPIRE-03.** ASPIRE-03 proposes a broader
`docs/standards/web/` subtree where this recipe would live
as `web/bootstrap-framework.md`. PAPER-25 is the **smaller
companion**: even if ASPIRE-03 doesn't ship (or ships
gradually), this one recipe is worth promoting first because
every framework consumer hits it. Triage the two
independently — PAPER-25 is one short PR; ASPIRE-03 is a
multi-PR restructure.

**Cross-references.**
- BOOTSTRAP-01 (shipped in v0.19.0) — the upstream change.
- v0.19.0 cutover guide §BOOTSTRAP-01 §"Combined Django
  adoption" — content to lift verbatim into the recipe's
  Django section.
- inthewords ADR-006:
  `inthewords/docs/adrs/ADR-006-bootstrap-setup-logging-false.md`
  — the per-decision record with full rationale.
- ASPIRE-03 — the broader subtree proposal this is a
  companion to.

**Decision rationale.** Accept and ship in v0.20.0. Cutover guides
are time-bounded by REL-09; framework-owned logging is durable.
Every future framework consumer needs the same shape on day one of
their adoption. Original-path note: PAPER-25 suggested
`docs/recipes/framework-owned-logging.md`; the v0.20.0 ship used
the existing convention `docs/public/recipes/`, and the v0.25.0
doc-restructure later flattened it back to `docs/recipes/`. End
state matches the filing's suggested path.

**Retrospective.** BOOTSTRAP-01's cutover-guide content promoted
to permanent reference at the canonical recipe path. The "What
`setup_logging=False` preserves" table is the load-bearing piece —
it disambiguates the flag from "no observability at all" by listing
the nine wiring steps that still happen (identity, OTel, excepthooks,
AppContext, buffer replay) versus the two that don't (handler
install, level overrides). The recipe is now the canonical pointer
for any FastAPI / Django / Flask / Pyramid consumer adopting
mgf-common — they read this file, not the v0.19.0 cutover guide.

---

#### `PAPER-26` — `mgf.common.fastapi.webhooks.HmacWebhookVerifier` — generic Svix-shaped HMAC verification primitive

| Field | Value |
|---|---|
| Status | ✅ SHIPPED |
| Severity | 🟡 |
| Submitter | PlasmaMapper (commit `45dbb25`) |
| Submitted | 2026-05-08 |
| Decision | accept (Svix-only at v1; transport-agnostic core + FastAPI request adapter; `HmacVerificationError(HttpUnauthorized)` single-inherit; force-lowercase header lookup; replay-cache hook deferred) |
| Decided on | 2026-05-08 |
| Scheduled for | v0.26.0 |
| Shipped in | v0.26.0 — new subpackage `mgf.common.fastapi.webhooks` with four public names: `WebhookHeaderSchema` (frozen dataclass; case-folds header names), `SVIX_SCHEMA` (Svix preset; used verbatim by Clerk), `HmacWebhookVerifier` (transport-agnostic core; thread-safe; verifies HMAC-SHA256 with replay window + multi-version sigs + constant-time compare), `verify_request` (async FastAPI Request adapter). New public exception `mgf.common.exceptions.HmacVerificationError(HttpUnauthorized)` — PAPER-24's `http_status` resolution maps to 401 without a `status_map` entry. Permanent recipe at [`docs/recipes/webhooks.md`](docs/recipes/webhooks.md). Migration guide in [`docs/cutover/v0.26.0.md`](docs/cutover/v0.26.0.md#paper-26--hmac-webhook-verifier). 25 tests across every failure mode (missing header, unparseable timestamp, replay window in both directions, tampered body, wrong secret, wrong/no prefix, multi-version sig key rotation, case-insensitive headers, custom schema, custom signature prefix) plus integration through `ExceptionTranslationMiddleware`. |

**Concern.** Every web consumer of mgf-common ends up writing the same HMAC
webhook verification dance — Svix-style: read `<id-header>`, `<ts-header>`,
`<sig-header>`, validate the timestamp against a 5-minute replay window,
compute `HMAC-SHA256(<id>.<ts>.<body>)` with the shared secret, base64 it,
and `hmac.compare_digest` against a space-separated list of versions. PlasmaMapper
ships this code **twice** in Phase 3 (in `MockAuthProvider` for tests and in
`ClerkAuthProvider` for production), at ~50 LOC each. The two are structurally
identical and stay in sync only by review discipline. Stripe, Clerk, Slack,
GitHub, Linear, and Resend all use Svix-flavoured signing schemes (the header
names differ but the algorithm is one of three patterns); a generic verifier
under `mgf.common.fastapi.webhooks` would absorb the duplication for every
consumer.

**Why it matters.** This is the second-most-load-bearing security boundary in a
SaaS app (after session JWT verification). Subtle bugs — missing timestamp
check, non-constant-time comparison, accepting a stale signature, decoding the
body before verifying — all show up in real-world incident reports. Concentrating
the implementation in mgf-common with a single test surface is exactly the
mgf-common DP-02-shaped risk-reduction this library was built for. PlasmaMapper
is the first web-shaped consumer to hit this; subsequent web consumers (per
ASPIRE-02 / ASPIRE-03) will hit it too. Filing now so the abstraction lands
before three consumers diverge on header conventions.

**Suggested shape.**

```python
# mgf.common.fastapi.webhooks
from typing import Protocol

class WebhookHeaderSchema(Protocol):
    """How a provider names the three Svix-style headers."""
    id_header: str        # e.g., "svix-id" / "stripe-event-id" / "x-github-delivery"
    timestamp_header: str # e.g., "svix-timestamp" / "stripe-signature" (mixed)
    signature_header: str # e.g., "svix-signature" / "x-hub-signature-256"

SVIX_SCHEMA = WebhookHeaderSchema(
    id_header="svix-id",
    timestamp_header="svix-timestamp",
    signature_header="svix-signature",
)
# Plus presets: STRIPE_SCHEMA, GITHUB_SCHEMA, ...

class HmacWebhookVerifier:
    def __init__(
        self,
        *,
        secret: bytes,
        schema: WebhookHeaderSchema = SVIX_SCHEMA,
        replay_window_seconds: int = 5 * 60,
        signature_prefix: str = "v1,",  # Svix's "v1,"; Stripe uses "v1="
    ) -> None: ...

    def verify(
        self,
        headers: Mapping[str, str],
        body: bytes,
    ) -> tuple[str, int]:
        """Return (event_id, timestamp). Raise HmacVerificationError on
        any failure (missing header / stale ts / wrong sig / unparseable
        ts).
        """
```

The error type lives in `mgf.common.exceptions` as a new
`HmacVerificationError(HttpUnauthorized, OperationError)` so consumers
inherit the 401 mapping via PAPER-24's `http_status` resolution.

The verifier is intentionally **transport-agnostic** — it takes a
`Mapping[str, str]` and `bytes`, not a FastAPI `Request`. A thin
adapter `mgf.common.fastapi.webhooks.verify_request(req, verifier)`
lifts a FastAPI request into the verifier's input shape.

**Cost if deferred past v1.0.** Every web consumer of mgf-common
re-implements this. Fix-by-fix divergence is the failure mode (one
consumer notices the timestamp window is too tight, fixes locally;
the other two consumers stay buggy). The "obvious" workaround
(`svix` Python SDK) brings in a 200 KB dep tree; for projects already
running mgf-common's tight closed-box discipline, that's a
non-trivial cost.

**Decision rationale.** Approach A from the filing, with five
clarifications applied during implementation:

1. **Svix-only at v1.** Stripe / GitHub / Slack use related-but-distinct
   shapes (combined headers, hex encoding, alternate prefixes); shipping
   one schema today means one design we can stand behind. Adding presets
   waits for second-consumer signal.
2. **`HmacVerificationError(HttpUnauthorized)` single-inherit** — matches
   existing leaf conventions (`HttpNotFound` etc.). Multi-inherit
   `(HttpUnauthorized, OperationError)` from the filing was rejected;
   simpler MRO; HTTP-01 still gives 401.
3. **Frozen `@dataclass(frozen=True, slots=True)`** for `WebhookHeaderSchema`,
   not the `Protocol` shape from the filing's pseudocode (Protocols
   can't be instantiated).
4. **Force-lowercase header lookup** internally — verifier normalises
   both schema names and input header keys. Caller has one less footgun.
5. **Replay-cache hook deferred** to a future paper. Stripe recommends
   rejecting same-event-id within the replay window as defense beyond
   the timestamp check, but adding a pluggable storage interface is its
   own design space — file when a consumer asks.

**Retrospective.** Approach A landed verbatim with the five
clarifications above. The transport-agnostic core (header `Mapping[str, str]`
+ body `bytes`) tested cleanly without FastAPI, then the request adapter
lifted it without re-implementing the verification logic. PlasmaMapper's
`MockAuthProvider` + `ClerkAuthProvider` deduplicate to one verifier
construction + one `verify(...)` call; ~80 LOC removed across both files.
The HTTP-01 + PAPER-24 composition (HmacVerificationError → HttpUnauthorized
→ 401 via `http_status` resolution) is the canonical example of why the
v0.18 + v0.19 architectural batches paid for themselves — adding a new
401-shaped exception touches no middleware, no `status_map`, no consumer
config. 25 tests cover every failure mode plus the FastAPI integration
path; constant-time comparison is exercised structurally (multi-version
sig key rotation tests verify the loop, not the timing). Stripe / GitHub /
Slack presets remain follow-up paper candidates; same with the replay-cache
hook.

---

#### `PAPER-27` — `mgf.common.fastapi.security.IpAllowlist` dependency

| Field | Value |
|---|---|
| Status | ✅ SHIPPED |
| Severity | 🟢 |
| Submitter | PlasmaMapper (commit `45dbb25`) |
| Submitted | 2026-05-08 |
| Decision | accept (Approach A — coupled-to-FastAPI dependency form; CIDR list at construction time; explicit `trust_proxy=False` default; loopback CIDRs as default `cidrs=`; misconfig fails fast at construction) |
| Decided on | 2026-05-08 |
| Scheduled for | v0.27.0 |
| Shipped in | v0.27.0 — new module `mgf.common.fastapi.security` with two public names: `IpAllowlist` (FastAPI dependency; CIDR allowlist; IPv4 + IPv6 dual-stack; cross-version deliberately rejected; raises `HttpForbidden` on miss; HTTP-01 + PAPER-24 give 401 401 — actually 403 — automatically), and `LOOPBACK_CIDRS` (the default `cidrs=` value, `("127.0.0.0/8", "::1/128")` so tests work out-of-the-box). The `trust_proxy: bool = False` default concentrates the canonical proxy-trust footgun: honouring `X-Forwarded-For` requires explicit opt-in once a forwarded-headers middleware is in place. Misconfigured CIDRs fail at construction time, not first request. Migration guide in [`docs/cutover/v0.27.0.md`](docs/cutover/v0.27.0.md#paper-27--ipallowlist). 16 tests including IPv4/IPv6 match, cross-version deny, proxy-trust on/off, missing client IP, unparseable IP, multi-XFF chain, exception mapping through `ExceptionTranslationMiddleware`. |

**Concern.** PlasmaMapper's Phase-3 admin surface
(`POST /admin/trackers`) gates on a CIDR allowlist while SaaS auth is
not yet wired. The dependency at
`src/plasmamapper/api/security/admin_ip.py` does the obvious things —
parse CIDR strings, compare `request.client.host`, version-match v4 vs
v6, log + 403 on mismatch. This pattern recurs in every web app with
ops-only / staging-only endpoints; promoting it to mgf-common saves ~80
LOC per consumer and concentrates the proxy-trust gotcha in one place.

**Why it matters.** The proxy-trust footgun is real — the dependency
must explicitly NOT honour `X-Forwarded-For` unless the consumer has
configured a forwarded-headers middleware. A library-side helper can
make that decision once with a clearly-named knob (`trust_proxy=False`
default) instead of every consumer re-rediscovering. Plus, IPv6 dual-
stack matching and graceful degradation on a missing `request.client`
are easy to get wrong in single-paragraph re-implementations.

**Suggested shape.**

```python
# mgf.common.fastapi.security
class IpAllowlist:
    def __init__(
        self,
        cidrs: Iterable[str],
        *,
        trust_proxy: bool = False,
    ) -> None: ...

    def __call__(self, request: Request) -> None:
        """FastAPI dependency form. Raises HttpForbidden on miss."""
```

Defaults: loopback (127.0.0.1/32 + ::1/128) so tests work
out-of-the-box; `trust_proxy=False` so the deploy hardening is the
explicit decision.

**Cost if deferred past v1.0.** Low — every consumer can ship their
own. The ergonomic argument is "it's the same code in every consumer"
and the security argument is "concentrate the proxy-trust footgun."
Both real but not blocker-shaped.

**Decision rationale.** Approach A from the filing — FastAPI-coupled
dependency form (single class, `__call__(request)`); CIDR list at
construction time (not per-request settings reload); `trust_proxy=False`
default with explicit opt-in for XFF reading. Pure-logic-core +
framework-adapter split (the alternate shape) was rejected for v0.27 —
no second framework consumer has signalled the need; Django/Flask
parallel-port primitives can be filed as follow-up papers.

**Retrospective.** Approach A landed cleanly. The `Request` import is
intentionally NOT inside `TYPE_CHECKING` (with `# noqa: TC002`) because
FastAPI evaluates dependency annotations at registration time via
`get_type_hints` — moving it would crash dep wiring at app-startup
time. PlasmaMapper's `src/plasmamapper/api/security/admin_ip.py` (~70
LOC including the `lru_cache` parsing, IPv4/v6 version-match,
graceful no-client-IP degradation, and `HttpForbidden` raise)
deletes; the consumer instantiates `IpAllowlist(cidrs=settings...)`
once at app-startup time and references via `Depends(gate)`. The
HTTP-01 + PAPER-24 composition gives the 403 response shape
automatically. Runtime-mutable allowlists (settings reload) and
non-XFF forwarded-header schemes (`Forwarded:`, `X-Real-IP`) are
documented as v0.28+ candidates.

---

#### `PAPER-28` — `mgf.common.fastapi.testing.run_test_app` — context-manager test API server

| Field | Value |
|---|---|
| Status | ✅ SHIPPED |
| Severity | 🟢 |
| Submitter | PlasmaMapper (commit `45dbb25`) |
| Submitted | 2026-05-08 |
| Decision | accept (Approach A — async context manager; standalone uvicorn wrapper; surfaces startup exceptions; clean shutdown with CancelledError suppression) |
| Decided on | 2026-05-08 |
| Scheduled for | v0.27.0 |
| Shipped in | v0.27.0 — new module `mgf.common.fastapi.testing` with one public name: `run_test_app(app, *, port=None, host="127.0.0.1", log_level="warning", startup_timeout_seconds=5.0) -> AsyncIterator[str]`. Async context manager — yields the base URL (`http://<host>:<port>`); tears down cleanly on context exit including under exception. `port=None` picks a free ephemeral port. Surfaces server-startup exceptions immediately instead of timing out silently (the load-bearing test-DX fix). Raises `TimeoutError` if uvicorn doesn't reach `server.started` within `startup_timeout_seconds`. `CancelledError` from the serve task is suppressed on clean shutdown. The `[fastapi-test]` extra grew `uvicorn>=0.30`. Migration guide in [`docs/cutover/v0.27.0.md`](docs/cutover/v0.27.0.md#paper-28--run_test_app). 8 tests including reachable-base-URL, route-serves-correctly, parallel-free-ports, explicit-port, clean-shutdown-releases-port, exception-still-shuts-down, startup-timeout. |

**Concern.** Per ADR-013 (UX testing strategy), PlasmaMapper's
Playwright golden-paths run against a real FastAPI app on a free
port, not against MSW mocks — closer to production fidelity, lets
the OpenAPI contract bite, plays nicely with cross-context
propagation tests (operator + driver in parallel browser
contexts). The implementation at
`tests/ux/fixtures/api_server.py` is ~120 LOC of `uvicorn.Server`
+ `asyncio.create_task` + free-port discovery + start/stop
choreography. The pattern is **identical** for any FastAPI app:
build the app, pick a port, await `server.started`, yield URL,
shut down on context exit. A library-side helper would let a
consumer write:

```python
async with mgf.common.fastapi.testing.run_test_app(create_app(settings)) as url:
    ...
```

instead of re-implementing the dance.

**Why it matters.** The free-port-discovery + uvicorn lifecycle is
fiddly enough that small bugs (race on `server.started`,
`asyncio.CancelledError` not suppressed on stop, port grabbed but
leaked on test failure) recur per consumer. Centralising it gives
all web consumers a tested baseline for Playwright integration —
which ADR-013 documents as the canonical UX testing pattern across
the mgf-common ecosystem.

**Suggested shape.**

```python
# mgf.common.fastapi.testing
@asynccontextmanager
async def run_test_app(
    app: FastAPI,
    *,
    port: int | None = None,    # None = pick free port
    host: str = "127.0.0.1",
    log_level: str = "warning",
    startup_timeout_seconds: float = 5.0,
) -> AsyncIterator[str]:
    """Start uvicorn for ``app`` on a free port; yield the base URL.

    Tears down cleanly on context exit, including on test exception.
    """
```

The seeding part is consumer-specific (per-app fixture data) and
stays in consumer code — only the server lifecycle moves into
mgf-common.

**Cost if deferred past v1.0.** Low. Each consumer can ship their
own ~120 LOC. The argument is convergence + fewer
"why does my Playwright run flake" investigations.

**Decision rationale.** Approach A — async context manager wrapping
uvicorn directly (not wrapping `mgf.common.process.Service`). Service
launches subprocesses; uvicorn-as-library runs in-process by design,
which is what tests need (faster, simpler teardown, shared module
state with the test code). Standalone wrapper keeps the dependency
graph minimal — pulls only `uvicorn` (already a transitive dep of
`fastapi[standard]` for any consumer running uvicorn in production).

**Retrospective.** Approach A landed verbatim with one DX-load-bearing
addition: the helper polls for `server.started` and ALSO checks if the
serve task has crashed (port collision, lifespan handler failure)
during the wait window. Without the crash check, a startup failure
manifests as a silent `TimeoutError` after the full timeout — nearly
impossible to debug on CI flakes. With the check, the underlying
exception surfaces immediately. The exception-still-shuts-down test
is the load-bearing safety property: if a test inside the context
raises, the `finally` branch still drains the serve task, so the bound
port is reusable immediately. PlasmaMapper's `tests/ux/fixtures/api_server.py`
(~120 LOC) deletes; the seed step (test-DB-specific) stays consumer-
side. Sync-context support and multi-app orchestration are documented
as v0.28+ candidates.

---

#### `PAPER-29` — `mgf.common.fastapi.security.BearerSession` — auth-provider-backed session FastAPI dependency

| Field | Value |
|---|---|
| Status | ✅ SHIPPED |
| Severity | 🟡 |
| Submitter | PlasmaMapper (Phase 3 Task 6) |
| Submitted | 2026-05-08 |
| Decision | accept (suggested shape verbatim, modulo factory naming + Protocol covariance) |
| Decided on | 2026-05-10 |
| Scheduled for | mgf-fastapi 0.3.0 |
| Shipped in | `mgf.fastapi.security.bearer_session(verifier_attr, *, cookie_name=None)` factory + `mgf.fastapi.security.AuthVerifier[P]` Protocol — see `mgf-fastapi` repo (mgf-common is in its v0.32+ stabilization window so the addition lands in the sibling, exercising the federation's independent-semver decision). Tests: `tests/unit/test_security.py::TestBearerSession*` (14 new tests covering happy path, failure modes, cookie fallback, custom `verifier_attr`). Pin bumped to `mgf-common>=0.31,<0.32`. Cutover guide: [`mgf-fastapi/docs/cutover/v0.3.0.md`](https://codeberg.org/magogi-admin/mgf-fastapi/src/branch/main/docs/cutover/v0.3.0.md).

**Retrospective.** Shipped close to the suggested shape: a factory
returning a FastAPI dependency, an `AuthVerifier` Protocol (covariant
in the principal type so consumer subclassing of principals
composes), case-insensitive scheme matching per RFC 7235, optional
cookie fallback for browser clients with header precedence. The
factory keeps the principal type as `Any` in its return annotation —
Python typing can't carry the principal across the `Depends(...)`
boundary — and consumers recover precise typing via
`Annotated[MyPrincipal, Depends(bearer_session())]`, which is the
idiomatic FastAPI pattern anyway.

Two design refinements at implementation time:

1. Verifier-missing returns `HttpUnauthorized("authentication not
   configured")` to the caller (not a 500), with the deployment
   misconfiguration loud in `LOG.error`. Surfacing "your verifier is
   missing" to an unauthenticated caller would leak deployment
   detail; surfacing it to ops is the right move.

2. Verifier raising `HttpUnauthorized` directly passes through
   unchanged (preserving the verifier's own message), but any other
   exception gets translated to `HttpUnauthorized("invalid or
   expired session")` with the original cause chained via
   `__cause__`. This gives consumers a clean two-tier failure path:
   "I have something specific to tell the client" vs. "translate
   anything I throw to a 401".

The "Bonus surface" mentioned in the filing (`AuthProvider` Protocol
under `mgf.common.providers.auth` combining `verify_session` +
`verify_webhook`) stays a future consideration — both halves shipped
independently (PAPER-26 webhooks v0.26.0, PAPER-29 sessions v0.3.0
of mgf-fastapi); whether to bind them into a single mgf-common
Protocol is a separate filing if and when a third use case
surfaces.

**Concern.** Every authenticated FastAPI route in a SaaS app needs the
same dependency: read the ``Authorization: Bearer <token>`` header,
strip the prefix, hand the bare token to an auth-provider abstraction
that returns the typed session principal, and translate any failure
into ``HttpUnauthorized``. PlasmaMapper ships this in
``src/plasmamapper/api/security/session.py`` (~30 LOC + a small test).
Every other web consumer of mgf-common will reproduce the same shape;
the only variable is the ``AuthProvider`` Protocol shape — itself a
candidate for promotion (see "Bonus surface" below).

**Why it matters.** "Bearer header → typed session" is the gate every
authenticated route runs through. It's small per consumer, but the
patterns differ subtly: some consumers honour cookies alongside
bearers, some require a tenant-membership claim alongside the
principal, some return ``None`` for anonymous + others raise.
Codifying a small protocol-friendly default in mgf-common gives
every web consumer the same shape, gives an obvious place to
document the proxy-trust caveat (the same one that bites PAPER-27's
``IpAllowlist``), and concentrates the constant-time-comparison +
header-parsing edges in one tested module.

**Suggested shape.**

```python
# mgf.common.fastapi.security
from typing import Awaitable, Callable, Protocol, TypeVar

P = TypeVar("P")  # consumer's principal type (e.g., SessionPrincipal)

class AuthVerifier(Protocol[P]):
    async def verify_session(self, token: str) -> P: ...

def bearer_session(
    verifier_attr: str = "auth_provider",
    *,
    cookie_name: str | None = None,  # None = bearer-only
) -> Callable[..., Awaitable[P]]:
    """Build a FastAPI dependency that resolves the session principal.

    The returned function reads the ``AuthVerifier`` from
    ``request.app.state.<verifier_attr>``; tests swap providers by
    mutating ``app.state``. ``cookie_name`` (when set) makes the
    dep also accept a session cookie for browser clients.
    """
```

Failure path raises ``HttpUnauthorized`` (already in
``mgf.common.exceptions``) so the FastAPI middleware translates to
401 via the PAPER-24 ``http_status`` resolution path — no per-consumer
``status_map`` extension required.

**Bonus surface — lower-leverage, mention only.** PlasmaMapper's
``AuthProvider`` Protocol (per ADR-004) has two methods
(``verify_session`` + ``verify_webhook``) lining up cleanly with
PAPER-26's webhook verifier. If both PAPER-26 and PAPER-29 land,
codifying ``AuthProvider`` as a small Protocol under
``mgf.common.providers.auth`` (no concrete; consumers implement
their own Clerk/Authentik/etc.) becomes attractive. Filing as a
future consideration; not blocking PAPER-29.

**Cost if deferred past v1.0.** Low. Each web consumer ships their
own ~30-LOC dep. Argument: convergence + canonical place for the
proxy-trust caveat + canonical place for the cookie-vs-bearer
choice + tested constant-time-compare on token equality.

**Decision rationale.** *(Filled when triaged.)*

**Retrospective.** *(Filled when shipped.)*

---

#### `PAPER-31` — Conformance-audit pattern: separate "N/A" from "🚫 declined-with-rationale"

| Field | Value |
|---|---|
| Status | OPEN |
| Severity | 🟡 High (audit clarity) |
| Submitter | PlasmaMapper (commit `<this commit>`) |
| Submitted | 2026-05-15 |
| Decision | pending |
| Decided on | — |
| Scheduled for | — |
| Shipped in | — |

**Concern.** Doing a per-rule conformance audit against the
16 standards produces three legitimate non-✅ outcomes that today
share one flag:

1. **N/A** — the rule's scope doesn't apply (e.g., GUI rules for a
   backend-only service, PyPI-release rules for a consumer-app).
   The consumer never *could* conform; the rule just isn't theirs.
2. **🚫 declined-with-rationale** per `principles/non-adoption-is-valid.md`
   — the rule *could* apply but the consumer consciously declines
   (e.g., the web carve-out's "config from env-only, no `--config`
   flag" against CF-09). The consumer's choice carries a documented
   rationale and is a real decision.
3. **⏳ no-surface-yet** — the rule applies but there's nothing to
   audit because the feature hasn't shipped (e.g., AP-04
   deprecation cycle when no deprecations exist).

A first-pass audit reaches for 🚫 for all three because the
`non-adoption-is-valid.md` principle is the only "I'm not
following this and that's fine" framing in the standards corpus.
That conflation hides signal: a 🚫 against CF-09 (web carve-out)
is a real design choice the next consumer should know about; a
🚫 against EH-06 (GUI worker rule for a backend service) is just
"wrong project shape." Surfacing both as 🚫 means a reviewer can't
tell which 🚫 rows need a rationale doc and which don't.

**Why it matters.** Standards-conformance audits are exactly the
exercise the standards corpus is meant to support — and the
audit's signal is most useful when it distinguishes "design
choice" from "scope mismatch." The PlasmaMapper audit pass
filed today (`docs/inprogress/MGF_STANDARDS_CONFORMANCE.md`)
hit this immediately: the first agent run flagged 9 rows as 🚫
which on review-pass split into 6 N/A + 3 actual declines. That's
a 2:1 noise ratio in the "declined" signal — meaningful enough
to warrant naming the distinction upstream.

**Concrete evidence.**

- `principles/non-adoption-is-valid.md` is the only "I'm not
  following this rule" framing in `docs/standards/`. The README's
  conformance-level table doesn't enumerate other non-✅ outcomes.
- The PlasmaMapper audit (`docs/inprogress/MGF_STANDARDS_CONFORMANCE.md`
  §2) shows the three categories side-by-side: e.g., **EH-06**
  (GUI workers) = N/A vs **AP-12** (CHANGELOG for PyPI) = 🚫
  declined-with-rationale vs **CF-11** (field-rename alias) = ⏳
  no-surface-yet. Each row's text makes the category clear; the
  status flag alone does not.
- The non-adoption-is-valid principle's worked examples
  (LOG-01, BOOTSTRAP-01, "small consumer" scope discipline) are
  all category-2 (conscious decline) cases — none of them are
  category-1 (rule doesn't apply at all) or category-3 (no
  surface yet). The principle's name is accurate but the framing
  doesn't acknowledge the other two outcomes.

**Suggested shape.**

**Approach A (lightweight, doc-only):** add a short addition to
`principles/non-adoption-is-valid.md` (or a new sibling
`principles/audit-outcomes.md`) that names the three categories
explicitly + recommends three different flags for audit work:

```
- ✅ conformant
- ❌ violation
- ⚪ partial
- 🚫 declined-with-rationale       — rule applies; we choose not to follow it
- N/A                                — rule scope does not apply to this project
- ⏳ no-surface-yet                 — rule applies but the feature it gates hasn't shipped
```

**Approach B (opinionated, slightly heavier):** ship an
`audit-template.md` (or a `mgf-common audit-template` CLI
sub-command) that emits the rule list with placeholder rows in
each of the four non-✅ flags pre-filled. A consumer fills the
status + evidence; the standardised vocabulary stays consistent
across consumers. This is a generalisation of the "living
priority tracker" shape PlasmaMapper uses across its 5+ trackers.

**Recommendation:** Approach A. The standards corpus is already
prose-heavy; adding a flag taxonomy doesn't need tooling.
Approach B is a 💭 follow-up if multiple consumers ship audits.

**Decision rationale.** *(Filled when triaged.)*

**Retrospective.** *(Filled when shipped.)*

---

#### `PAPER-32` — Web-shape carve-outs should cross-reference from each affected rule

| Field | Value |
|---|---|
| Status | OPEN |
| Severity | 🟡 High (consumer-time waste at audit) |
| Submitter | PlasmaMapper (commit `<this commit>`) |
| Submitted | 2026-05-15 |
| Decision | pending |
| Decided on | — |
| Scheduled for | — |
| Shipped in | — |

**Concern.** `web/README.md` carries a narrative wrapper that names
specific carve-outs for FastAPI / Django / Flask consumers — e.g.,
CF-09's `--config` flag and OS-aware default path is declined
because web services consume config from env, not CLI flags;
LG-10's JournalHandler is declined because container orchestration
captures stdout; LG-06's file-rotation branch is replaced by
stdout-only. These are real, load-bearing decisions.

**The problem is one-way discoverability.** A consumer auditing
CF-09 reads the rule text in `CONFIGURATION.md`, finds nothing
about a web-shape exemption, and has to either:
- read `web/README.md` cover-to-cover hoping it covers CF-09, or
- file the rule as ❌ and rediscover the carve-out in PR review.

The standards corpus's master index (`README.md`) does point at
`web/README.md` near the top, but the per-rule reading path
doesn't reach the carve-out. Consumers don't read the standards
corpus end-to-end before each audit — they search for the rule
they're checking.

**Why it matters.** Every web-shape consumer hits this. The
PlasmaMapper audit's review pass had to manually walk
`web/README.md` to confirm which 🚫 rows had a real upstream
carve-out vs. which were just "rule doesn't apply" — the rule
text itself didn't say.

**Concrete evidence.**

- `CONFIGURATION.md` CF-09 (`--config` flag): no inline reference
  to the web carve-out that declines it for services.
- `LOGGING.md` LG-10 (JournalHandler): no inline reference to the
  web carve-out that declines it for container orchestration.
- `LOGGING.md` LG-06 (rotating file → aggregator): the rule text
  presents this as "logs reach an aggregator (file / stdout /
  remote)" but the web carve-out has a stronger preference for
  stdout-only that doesn't surface in the rule.
- `web/README.md` references these carve-outs collectively but
  doesn't make it easy to round-trip from a rule ID to "is there
  a web-shape note?"

**Suggested shape.**

Add a `**Web-shape note.**` paragraph inline at each affected
rule pointing at `web/README.md` §<anchor>. Example for CF-09:

```markdown
**CF-09 — `--config` flag + OS-aware default path**

[…existing rule text…]

**Web-shape note.** Web services consume config from environment
variables + an optional `.env` file at the project root; they do
NOT take a `--config` CLI flag. Declined per
[`web/README.md` §Framework-native config](web/README.md#framework-native-config).
```

This is one paragraph per affected rule (CF-09, LG-06, LG-10,
maybe AP-12 for non-PyPI consumer apps). The maintainer carries
the cross-link burden so every consumer doesn't.

**Decision rationale.** *(Filled when triaged.)*

**Retrospective.** *(Filled when shipped.)*

---

#### `PAPER-33` — `BaseAppSettings.version: int = 1` auto-provision is invisible to CF-03 audits

| Field | Value |
|---|---|
| Status | OPEN |
| Severity | 🟢 Nice-to-have (one-line doc cross-link) |
| Submitter | PlasmaMapper (commit `<this commit>`) |
| Submitted | 2026-05-15 |
| Decision | pending |
| Decided on | — |
| Scheduled for | — |
| Shipped in | — |

**Concern.** `CONFIGURATION.md` rule CF-03 says "Settings schema
MUST carry a `version: int` field with a documented migration
chain." A consumer using `BaseAppSettings` already conforms —
`mgf_common/src/mgf/common/config/_settings.py:121` declares
`version: int = 1` automatically — but the rule text and the
mgf-common consumer-facing docs don't say so. A consumer auditing
CF-03 has to either grep mgf-common source or file CF-03 as
"⏳ unclear" until they check.

The PlasmaMapper audit's first pass hit this exactly: the
agent flagged CF-03 as ⏳ unclear ("PlasmaSettings has no version
field visible in code"). The review pass had to grep
`mgf_common/src/mgf/common/config/_settings.py` to confirm
`BaseAppSettings.version: int = 1` is inherited.

**Why it matters.** Every consumer of `BaseAppSettings` (which is
every L1+ project per the standards) hits this. The rule is
genuinely conformant-for-free; making that invisible costs each
consumer one grep at audit time.

**Concrete evidence.**

- `mgf_common/src/mgf/common/config/_settings.py:121`:
  `version: int = 1` declared on `BaseAppSettings`.
- `CONFIGURATION.md` CF-03 (the rule): no cross-link to the
  auto-provision.
- `docs/recipes/` (or wherever the BaseAppSettings recipe lives):
  no callout that subclassing BaseAppSettings gets CF-03 for
  free.

**Suggested shape.**

One line added to CF-03's rule text:

```markdown
**Auto-provision note.** Subclassing
`mgf.common.config.BaseAppSettings` provides `version: int = 1`
automatically — your `Settings` class inherits CF-03 conformance
without further work. Override the default + drive the migration
chain when the schema evolves past v1.
```

Same pattern would also help CF-06 (`extra="forbid"` is
auto-provisioned via the base's `model_config`), CF-02 (the
precedence layering is `pydantic-settings`-mediated and
inherited), and CF-08 (the "loaded once at entry point" pattern
is what `mgf.common.bootstrap()` implements). One audit-pass-
visible callout per rule.

**Decision rationale.** *(Filled when triaged.)*

**Retrospective.** *(Filled when shipped.)*

---

#### `PAPER-34` — `scan-deps` recipe candidate for `COMMON_COMPONENTS.md`

| Field | Value |
|---|---|
| Status | OPEN |
| Severity | 🟢 Nice-to-have (lift pattern) |
| Submitter | PlasmaMapper (commit `<this commit>`) |
| Submitted | 2026-05-15 |
| Decision | pending |
| Decided on | — |
| Scheduled for | — |
| Shipped in | — |

**Concern.** `COMMON_COMPONENTS.md` catalogues the cornerstone
primitives — bootstrap, observability, vault, exceptions, settings,
fastapi adapters. It does NOT catalogue a recommended **dependency-
vulnerability-scanning recipe** (pip-audit + npm/pnpm audit) even
though every L1+ consumer needs one, and the CI shape is small +
near-identical across consumers.

PlasmaMapper just shipped SH-25 (commit `849d867`,
docs/inprogress/SECURITY_HARDENING.md §SH-25) with:

- A `pip-audit` CI step running via `uv tool run --from pip-audit`
  against `uv export --format requirements-txt --no-dev
  --no-hashes --no-sources` (CI-shape export).
- A `.pip-audit-ignore` file shape (one PYSEC-/GHSA-ID per line,
  date + rationale comments) for triaging accepted advisories.
- A `pnpm audit --audit-level=high` step for the frontend.

The gate caught two real CVEs on the very PR that introduced it
(urllib3 2.6.3 → 2.7.0, devalue 5.8.0 → 5.8.1), which is the
proof-of-value the audit standard explicitly asks for.

**Why it matters.** Every consumer reinvents this. The
PlasmaMapper SECURITY_HARDENING audit promoted R-17 (P2,
dependency-vulnerability gate) to SH-25 (P1) precisely because
the solo-dev / hand-managed shape is where this fails first. A
recipe in `COMMON_COMPONENTS.md` (or a sibling
`docs/recipes/scan-deps.md`) would let the next consumer skip
the design step and ship the CI gate directly.

**Concrete evidence.**

- `.woodpecker.yml` (PlasmaMapper, post-`849d867`): `pip-audit`
  step (lines for the new step) + `frontend-audit` step.
- `.pip-audit-ignore` (PlasmaMapper, post-`849d867`): the
  triage-file shape.
- `docs/inprogress/SECURITY_HARDENING.md` §SH-25 closure entry:
  the "caught 2 real CVEs on the very PR that introduced the
  gate" retrospective.

**Suggested shape.**

A new section under `docs/recipes/` or an entry in
`COMMON_COMPONENTS.md` §"CI gates" naming `scan-deps` as a
recommended recipe, with:

```
- Tool choice: pip-audit (Python) + pnpm/npm audit (frontend).
- Run shape: against the lock export, not the active env
  (handles the editable-sibling case + matches CI's
  --no-sources install path).
- Triage file: <project>/.pip-audit-ignore — one ID per line,
  inline date + rationale comments.
- Severity gate: --audit-level=high for the frontend (lower
  thresholds drown in transitive dev-tool noise); --strict for
  pip-audit (any CVE fails, ignore-file is the escape).
- The ignore-file becomes the audit trail; empty file = strict
  mode.
```

If the recipe ships, PlasmaMapper's SH-25 closure entry should
be cross-referenced as the reference implementation (per
PAPER-06's spirit).

**Decision rationale.** *(Filled when triaged.)*

**Retrospective.** *(Filled when shipped.)*

---

#### `PAPER-35` — Federation-aligned releases lack an aggregated consumer cutover guide

| Field | Value |
|---|---|
| Status | OPEN |
| Severity | 🟢 Nice-to-have |
| Submitter | PlasmaMapper (commit `<this commit>`) |
| Submitted | 2026-05-18 |
| Decision | pending |
| Decided on | — |
| Scheduled for | — |
| Shipped in | — |

**Concern.** mgf-common 0.34.0 is a "federation-alignment" release —
the headline change is the v2.6 + v2.7 standards shape, and the
companion sibling releases (mgf-fastapi 0.4.0, mgf-sqlalchemy 0.2.0,
mgf-alembic 0.3.0) carry the same alignment pin-walked into each
sibling's own minor. A consumer that depends on N federation packages
has to read **N CHANGELOGs in sequence** to learn what each pin walk
actually requires of them — there is no single "if you're a consumer
of the federation, here's the coordinated v0.34 pin set + the deltas
that affect you" cutover doc.

The mgf-common 0.34.0 release notes mention the sibling pin shift
("the sibling-pin update ships in each sibling's next release") but
the message is forward-looking; the aggregate is only knowable AFTER
the siblings ship their cycle. By design DOC-05 only requires a
`docs/cutover/v<X.Y.Z>.md` for breaking minors — 0.34.0 was internal-
only, so no cutover was written.

**Why it matters.** Every consumer that uses ≥2 federation siblings
hits this. The friction scales with sibling count: a 1-sibling
consumer reads 2 CHANGELOGs; a 4-sibling consumer (PlasmaMapper's
shape — mgf-common + mgf-fastapi + mgf-sqlalchemy + mgf-alembic)
reads 4 sibling CHANGELOGs + the mgf-common one, and has to walk
4 separate `pyproject.toml` pin lines forward in lockstep. The
4 pin-walks are themselves trivial; the cost is the *triage* —
"which of these is breaking, which is docs-only, which adds new
behaviour I want to opt into?". An aggregated guide collapses
that triage to a single read.

**Concrete evidence.**

PlasmaMapper, 2026-05-18, walking through the v0.34 alignment:

- `pyproject.toml`: 4 pin lines walked
  (`mgf-common>=0.33,<0.34 → >=0.34,<0.35`,
   `mgf-fastapi[sqlalchemy]>=0.3,<0.4 → >=0.4,<0.5`,
   `mgf-sqlalchemy>=0.1,<0.2 → >=0.2,<0.3`,
   `mgf-alembic>=0.1,<0.2 → >=0.3,<0.4`).
- 4 sibling CHANGELOG reads needed to classify each:
  - mgf-common 0.34.0 — internal-only (perf gates + standards docs).
  - mgf-fastapi 0.4.0 — docs-only (SECURITY.md + docs/claude/CLAUDE.md
    + docs/standards/README.md stub).
  - mgf-sqlalchemy 0.2.0 — docs-only (same shape).
  - mgf-alembic 0.3.0 — two new OPTIONAL kwargs (`is_async`,
    `transaction_per_migration`); RA-01 raises on running-loop.
- 4 separate commits landed in `PlasmaMapper@<this branch>` (one per
  pin walk) to keep bisection clean. Useful in retrospect; the
  triage cost was front-loaded.

**Suggested shape.**

When a federation-alignment cycle ships (every time mgf-common
crosses a minor that triggers `>=X,<Y` pin walks in 2+ siblings),
also ship a **single coordinated cutover** at one of these paths:

```
mgf-common/docs/cutover/federation-v<X.Y>.md   # OR
mgf-common/docs/release/federation-alignment-v<X.Y>.md
```

Suggested table-shape:

| Package | Pin (was) | Pin (now) | Consumer code-change required? |
|---|---|---|---|
| mgf-common | `>=0.33,<0.34` | `>=0.34,<0.35` | No — internal-only |
| mgf-fastapi | `>=0.3,<0.4` | `>=0.4,<0.5` | No — docs-only |
| mgf-sqlalchemy | `>=0.1,<0.2` | `>=0.2,<0.3` | No — docs-only |
| mgf-alembic | `>=0.2,<0.3` | `>=0.3,<0.4` | No — defaults preserved; opt in to new kwargs |

Plus a short "what's actually new for consumers" prose block (the
v2.7 DEPLOYMENT.md adoption surface, the perf-gate test additions,
etc.) so the *user-visible* delta is in one place.

This is **Approach A** (single aggregated cutover, owned by the
mgf-common release engineer). Approach B (each sibling's cutover
cross-references the federation-cycle aggregate) is also workable
but doubles the doc surface.

**Decision rationale.** *(Filled when triaged.)*

**Retrospective.** *(Filled when shipped.)*

---

#### `PAPER-36` — MOVED to `mgf-http`

| Field | Value |
|---|---|
| Status | MOVED |
| Moved on | 2026-05-18 |
| Moved to | [mgf-http/FEEDBACK.md §PAPER-01](https://codeberg.org/magogi-admin/mgf-http/src/branch/main/FEEDBACK.md#paper-01) |
| Why | Sibling-scoped feedback per DOC-13 — sibling-specific papers live in the sibling's own FEEDBACK.md. |

Original title: *Streaming + body cap absent from `AsyncHttpClient.request()`*

The full original entry — concern, evidence, suggested
shape, decision rationale, retrospective — is preserved
at the new location. This stub stays here as a redirect
so the federation-wide paper number remains searchable.

---


#### `PAPER-37` — MOVED to `mgf-http`

| Field | Value |
|---|---|
| Status | MOVED |
| Moved on | 2026-05-18 |
| Moved to | [mgf-http/FEEDBACK.md §PAPER-02](https://codeberg.org/magogi-admin/mgf-http/src/branch/main/FEEDBACK.md#paper-02) |
| Why | Sibling-scoped feedback per DOC-13 — sibling-specific papers live in the sibling's own FEEDBACK.md. |

Original title: *SSRF-safe redirect-walk recipe missing from `docs/recipes/http.md`*

The full original entry — concern, evidence, suggested
shape, decision rationale, retrospective — is preserved
at the new location. This stub stays here as a redirect
so the federation-wide paper number remains searchable.

---

#### `PAPER-38` — Federation-wide README pin-window staleness; mgf-common is the natural template owner

| Field | Value |
|---|---|
| Status | ✅ SHIPPED |
| Severity | 🟢 Nice-to-have |
| Submitter | inthewords (commit [`f190f61`](https://codeberg.org/magogi-admin/inthewords/commit/f190f61)) |
| Submitted | 2026-05-18 |
| Decision | accept Approach A (drop literal version + link to PyPI) |
| Decided on | 2026-05-18 |
| Scheduled for | applied immediately across the six federation siblings |
| Shipped in | six sibling commits: mgf-http [`dac9085`](https://codeberg.org/magogi-admin/mgf-http/commit/dac9085) · mgf-apiprobe [`f3adbb2`](https://codeberg.org/magogi-admin/mgf_apiprobe/commit/f3adbb2) · mgf-alembic [`5410615`](https://codeberg.org/magogi-admin/mgf-alembic/commit/5410615) · mgf-sqlalchemy [`1ec927e`](https://codeberg.org/magogi-admin/mgf-sqlalchemy/commit/1ec927e) · mgf-fastapi [`d14a833`](https://codeberg.org/magogi-admin/mgf-fastapi/commit/d14a833) · mgf-django [`0922fb8`](https://codeberg.org/magogi-admin/mgf-django/commit/0922fb8) |

**Concern.** Multiple sibling READMEs declare a pin window that
disagrees with the actually-published wheel's `pyproject.toml`
metadata. Concretely:

- **mgf-http 0.3.0** `README.md:7` says
  `mgf-common>=0.33,<0.34`; the wheel says `>=0.34,<0.35`.
- **mgf-apiprobe 0.4.0** `README.md:6` says the same stale
  range; the wheel says `>=0.34,<0.35`.

This is a federation-wide template-hygiene issue. mgf-common is
the natural owner since the sibling READMEs likely derive from
a shared cookiecutter / `mgf-website-template`-style template
(per ASPIRE-06's federation discipline).

**Why it matters.** First-pass consumers reading the README
form an incorrect view of the dependency window. The inthewords
sibling-adoption assessment (`docs/MGF_SIBLING_ASSESSMENT.md`)
initially flagged mgf-apiprobe as "would need an mgf-apiprobe
release targeting 0.34 before we can pull it in" based on the
README. A pip dry-run later showed the wheel was already
compatible. Time lost: small but recurring on every catch-up
cycle.

**Concrete evidence.** Both READMEs above, plus the dry-run
output:

```
$ pip install 'mgf-http' --dry-run
Requirement already satisfied: mgf-common<0.35,>=0.34 ... (from mgf-http) (0.34.0)
```

**Suggested shape.** Two options.

**Approach A — kill the explicit version in the README and
link to PyPI.** Replace the "depends on `mgf-common>=X,<Y`" line
with "see [PyPI metadata](...)" so the version is sourced from
the wheel by definition. Lowest-effort and impossible to drift.

**Approach B — template the README from `pyproject.toml`** at
build time. A docs-build step that reads the dep window and
substitutes it into a README placeholder. More machinery but
keeps the README self-contained.

**Recommendation.** A. The README's job is to orient new
readers; PyPI is the source of truth for pin windows, and one
hop to confirm is fine. B is correct but heavy for the value.

**Decision rationale.** *(Filled when triaged.)*

**Retrospective.** *(Filled when shipped.)*

---

#### `PAPER-39` — MOVED to `mgf-apiprobe`

| Field | Value |
|---|---|
| Status | MOVED |
| Moved on | 2026-05-18 |
| Moved to | [mgf-apiprobe/FEEDBACK.md §PAPER-01](https://codeberg.org/magogi-admin/mgf-apiprobe/src/branch/main/FEEDBACK.md#paper-01) |
| Why | Sibling-scoped feedback per DOC-13 — sibling-specific papers live in the sibling's own FEEDBACK.md. |

Original title: *No way to thread response data from one probe into another (auth or otherwise)*

The full original entry — concern, evidence, suggested
shape, decision rationale, retrospective — is preserved
at the new location. This stub stays here as a redirect
so the federation-wide paper number remains searchable.

---

#### `PAPER-40` — MOVED to `mgf-apiprobe`

| Field | Value |
|---|---|
| Status | MOVED |
| Moved on | 2026-05-18 |
| Moved to | [mgf-apiprobe/FEEDBACK.md §PAPER-02](https://codeberg.org/magogi-admin/mgf-apiprobe/src/branch/main/FEEDBACK.md#paper-02) |
| Why | Sibling-scoped feedback per DOC-13 — sibling-specific papers live in the sibling's own FEEDBACK.md. |

Original title: *`BearerAuth` hardcodes the "Bearer" scheme; DRF and others need "Token" / custom*

The full original entry — concern, evidence, suggested
shape, decision rationale, retrospective — is preserved
at the new location. This stub stays here as a redirect
so the federation-wide paper number remains searchable.

---

#### `PAPER-41` — MOVED to `mgf-apiprobe`

| Field | Value |
|---|---|
| Status | MOVED |
| Moved on | 2026-05-18 |
| Moved to | [mgf-apiprobe/FEEDBACK.md §PAPER-03](https://codeberg.org/magogi-admin/mgf-apiprobe/src/branch/main/FEEDBACK.md#paper-03) |
| Why | Sibling-scoped feedback per DOC-13 — sibling-specific papers live in the sibling's own FEEDBACK.md. |

Original title: *Default checks fire on inapplicable responses (e.g., `MissingHsts` on non-HTTPS)*

The full original entry — concern, evidence, suggested
shape, decision rationale, retrospective — is preserved
at the new location. This stub stays here as a redirect
so the federation-wide paper number remains searchable.

---

#### `PAPER-42` — MOVED to `mgf-apiprobe`

| Field | Value |
|---|---|
| Status | MOVED |
| Moved on | 2026-05-18 |
| Moved to | [mgf-apiprobe/FEEDBACK.md §PAPER-04](https://codeberg.org/magogi-admin/mgf-apiprobe/src/branch/main/FEEDBACK.md#paper-04) |
| Why | Sibling-scoped feedback per DOC-13 — sibling-specific papers live in the sibling's own FEEDBACK.md. |

Original title: *`Probe.id()` is mandatory for readable reports but not surfaced as such*

The full original entry — concern, evidence, suggested
shape, decision rationale, retrospective — is preserved
at the new location. This stub stays here as a redirect
so the federation-wide paper number remains searchable.

---

#### `PAPER-43` — `mgf-common migrate` ships codemod rules for v0.33 AP-12 removals but doesn't register them for cross-version invocation

| Field | Value |
|---|---|
| Status | ✅ SHIPPED |
| Severity | 🟡 High |
| Submitter | inthewords (commit [`754ceda`](https://codeberg.org/magogi-admin/inthewords/commit/754ceda)) |
| Submitted | 2026-05-18 |
| Decision | accept (Approach A — register the existing rules) |
| Decided on | 2026-05-18 |
| Scheduled for | mgf-common next minor |
| Shipped in | commit [`be55ac1`](https://codeberg.org/magogi-admin/mgf_common/commit/be55ac1) |

**Concern.** The v0.33.0 cutover guide (`docs/cutover/v0.33.0.md`)
documents two codemod rules for the AP-12 deprecation removals:
`make_settings_config → settings_config` and `EnvironmentError →
HostEnvironmentError` (gated on `mgf.common.exceptions` import).
It instructs consumers to "run `mgf-common migrate` from the
project root."

The installed `mgf-common==0.33.0` CLI does not actually
register these rules for cross-version invocation. A
`mgf-common migrate 0.32 0.33 . --dry-run` returns:

```
✗ unsupported migration: 0.32 → 0.33
Supported migrations:
  0.1 → 0.3
```

Only the historical `0.1 → 0.3` migration is registered. The
v0.33 codemod rules exist in the codebase per the cutover guide
but aren't wired to the CLI's version-pair dispatcher.

**Why it matters.** A consumer following the cutover guide
literally to handle the AP-12 removals gets the "unsupported
migration" error and falls back to a manual grep + edit pass.
The cutover guide's claim ("the codemod ships in `mgf-common
migrate`") doesn't match what's installable today. For
inthewords specifically this didn't block anything (we
pre-verified by grep that none of the three removed names were
used in our code), but the doc / behaviour mismatch will trip a
consumer who actually has matching call sites.

**Concrete evidence.** Reproducer against installed
`mgf-common==0.33.0`:

```
$ .venv/bin/mgf-common migrate 0.32 0.33 . --dry-run
✗ unsupported migration: 0.32 → 0.33
Supported migrations:
  0.1 → 0.3
```

The v0.33.0 cutover guide bundled in the v0.34 sdist at
`docs/cutover/v0.33.0.md:33` shows the instruction the consumer
follows.

**Suggested shape.** Two parts.

**Approach A — register the rules.** Wire the v0.33 codemod
rules (`make_settings_config → settings_config` and
`EnvironmentError → HostEnvironmentError`) into the CLI's
version-pair dispatcher so `mgf-common migrate 0.32 0.33 .`
actually runs them. Same shape as the existing `0.1 → 0.3`
registration.

**Approach B — clarify the cutover guide if A is hard.** If
the rules deliberately ship as standalone scripts or as a
library API rather than CLI-dispatched, update the cutover
guide to reflect the actual invocation shape (e.g., "run
`python -m mgf.common.cli._migrate_v033 --apply`" or "import
the rule directly"). The current wording assumes the version-
pair dispatcher works.

**Recommendation.** A. The CLI's version-pair shape is the
documented entry point; consumers shouldn't have to reach into
implementation details to apply a documented codemod.

**Decision rationale.** Accept Approach A as recommended. The
fix is a one-line registry addition: the
`_RULES_0_1_TO_0_3` tuple (the identifier-anchored renames
originally shipped for the v0.1 closed-box redesign) is exactly
what v0.33 needs. The rules are idempotent — they look for old
names that wouldn't be present in already-migrated source — so
registering the same tuple under `("0.32", "0.33")` is safe
for every consumer regardless of which migration path they took
to v0.33.

**Retrospective.** Shipped exactly as the submitter suggested.
The change is two lines of net code: one new tuple entry in
`_MIGRATIONS` and one block-comment explaining the rule reuse.
Module docstring + CHANGELOG entry round it out. Test coverage
landed alongside: five new tests in
`tests/unit/test_phase7_migrate.py::TestPaper43V032ToV033Migration`
cover rename on the new pair, idempotency after a historical
v0.1 → v0.3 codemod run, dry-run threading, and per-rule
import-gate semantics. The existing
`test_unsupported_migration_returns_config_error` was
strengthened to assert both version pairs appear in the
"Supported migrations:" listing, so the dispatch table can't
silently regress in either direction. 1282 tests pass overall.

---

#### `PAPER-44` — `mgf-common catch-up --apply` leaves `.bak.<timestamp>` files with no documented cleanup

| Field | Value |
|---|---|
| Status | ✅ SHIPPED |
| Severity | 🟢 Nice-to-have |
| Submitter | inthewords (commit [`76ced0c`](https://codeberg.org/magogi-admin/inthewords/commit/76ced0c)) |
| Submitted | 2026-05-18 |
| Decision | accept (Approach A — auto-clean on verified-clean re-audit; plus the `.gitignore` snippet hint from the submitter's recommendation footnote) |
| Decided on | 2026-05-18 |
| Scheduled for | mgf-common next minor |
| Shipped in | mgf-common commit [`4ee7539`](https://codeberg.org/magogi-admin/mgf_common/commit/4ee7539) |

**Concern.** When `mgf-common catch-up --apply` rewrites a
file (e.g., refreshes the auto-managed block in
`docs/CLAUDE.md`), it writes a `<file>.bak.<unix-timestamp>`
alongside the modified file. The CLI does not delete the backup
after success, surface a guidance message about cleanup, or
provide a `--no-backup` / `--cleanup` flag. The consumer has to
remember to clean these up before committing.

**Why it matters.** A consumer running `catch-up --apply` as
part of a routine mgf-common bump (the documented adoption
walk) will accidentally `git add docs/CLAUDE.md.bak.<ts>` if
they `git add -A`. inthewords' v0.32 bump commit message
(`76ced0c`) explicitly notes manually removing the backup.
Repeat for every catch-up cycle — small but recurring per-bump
friction.

**Concrete evidence.** inthewords commit
[`76ced0c`](https://codeberg.org/magogi-admin/inthewords/commit/76ced0c)
WHAT-CHANGED block:

> `docs/CLAUDE.md` auto-managed block refreshed by `mgf-common
> catch-up --apply`. ... [implied cleanup of `.bak.<ts>` file].

The reproducer:

```
$ .venv/bin/mgf-common catch-up --apply
...
Applying mechanical fixes …
  ℹ️  docs/CLAUDE.md: refreshed auto-block ... (backup:
  CLAUDE.md.bak.1779089558)

Applied 1 mechanical fix(es). Re-run `mgf-common catch-up` to
verify, or check the .bak.* backups if anything looks wrong.

$ ls docs/*.bak.*    # still there after the run
docs/CLAUDE.md.bak.1779089558
```

**Suggested shape.** Three options, increasing in
configurability.

**Approach A — auto-clean on verified success.** After
`--apply` writes the new file AND the re-audit reports clean,
delete the `.bak.<ts>`. If audit still flags issues, keep the
backup. Zero new flags; consumer doesn't think about it.

**Approach B — explicit `--keep-backup` / `--no-backup`
flags.** Default behaviour matches A; flags let consumers
override for paranoia or git-friendliness.

**Approach C — write backups to a `.bak/` subdir** or system
temp dir instead of alongside the source. Less likely to be
caught by `git add -A`. Combine with B for flexibility.

**Recommendation.** A + a `.gitignore` snippet in the
catch-up output's final message ("Add `**/*.bak.*` to your
`.gitignore` to avoid accidentally committing future
backups."). Lowest friction for the routine adoption walk;
preserves safety net for the rare actual-revert case.

**Decision rationale.** *(Filled when triaged.)*

**Retrospective.** *(Filled when shipped.)*

---

### 💭 Aspirational

#### `ASPIRE-01` — "Multi-consumer process" as an explicit design choice

| Field | Value |
|---|---|
| Status | ✅ SHIPPED |
| Severity | 💭 Aspirational |
| Submitter | Reference consumer |
| Submitted | 2026-04-23 |
| Decision | accept (position paper at suggested path) |
| Decided on | 2026-05-01 |
| Scheduled for | shipped in-tree |
| Shipped in | `docs/design/multi_tenancy.md` (in-tree) + cross-link from `01_lifecycle.md` |

**Concern.** The hybrid module-global + opt-in `AppContext`
shape covers most "library-in-library" / multi-consumer
scenarios via PEP 567 contextvar isolation. But the design
question of whether mgf-common explicitly supports or
explicitly forbids multi-tenancy is worth a position paper —
silence is the worst option, since consumers who hit
ambiguity discover it via pain.

**Why it matters.** Decide whether `mgf-common` explicitly
supports or explicitly forbids multi-tenancy as part of the
public-API contract. The current shape supports it implicitly
(scoped `AppContext` context manager), but the contract isn't
documented as a stable promise.

**Suggested shape.** A `docs/design/multi_tenancy.md` walkthrough
that documents the supported scenarios:

  - Library plug-in with its own identity
  - Monorepo tests importing multiple consumer projects
  - Long-running services embedding consumer sub-components

…plus the unsupported ones (e.g., per-request identity in a
single-process server — that's what request-id contextvars are
for, not full identity isolation).

**Resolution.** Shipped as
[`docs/design/multi_tenancy.md`](docs/design/multi_tenancy.md):
a position paper that commits the project to a specific shape.
The supported scenarios match the suggested list (S1 plug-in
framework, S2 monorepo tests, S3 long-running services with
finite tenants). The unsupported anti-pattern is named
explicitly: per-request identity in a single-process server —
with reasons (cardinality, crash-dir scatter, OTel
service.name semantics) and the right alternative
(`request_id` contextvar via the
fastapi/django middleware that already ships). The contract
table at the end is part of the public-API promise.

---

#### `ASPIRE-02` — Web/Django consumer joins; standards encode CLI/desktop assumptions that need framework-native carve-outs

| Field | Value |
|---|---|
| Status | ✅ SHIPPED |
| Severity | 💭 Aspirational |
| Submitter | inthewords (Phase 0 discovery, 2026-05-05) |
| Submitted | 2026-05-05 |
| Decision | accept (record arrival + close P1 + supply PAPER-10 evidence + unblock PAPER-06) |
| Decided on | 2026-05-06 |
| Scheduled for | 0.18.0 |
| Shipped in | (1) [`docs/inprogress/strategic_review.md`](docs/inprogress/strategic_review.md#priority-1--get-a-second-independent-consumer) Priority 1 marked **✅ ACHIEVED** (2026-05-05). (2) [PAPER-10](#paper-10--no-entry-point-driven-auto-discovery-for-observability--vault-plug-ins) inherits this evidence: criterion 2 ("second consumer reports extension-wiring story") is satisfied with non-pain — `inthewords` reports they don't need entry-point auto-discovery; Django's `app.ready()` is the equivalent dispatch mechanism. PAPER-10 stays DEFERRED. (3) [PAPER-06](#paper-06--docsstandards-cites-the-reference-consumer-with-fileline) is now unblocked for the full restructure into per-consumer reference docs; tracked as a follow-up paper. (4) Per-rule applicability pattern shipped on LG-* (LOG-02) and CF-* (CONFIG-01); generalisation to EH-/DP-/AP- deferred until a future consumer surfaces specific friction. Migration guide in [`docs/cutover/archive/v0.18.0.md`](docs/cutover/archive/v0.18.0.md#aspire-02--second-consumer-arrival-acknowledged). |

**Retrospective.** Two real second-consumer arrivals (`inthewords`
+ `PlasmaMapper`) within hours of each other turned out to be
the inflection point for several deferred items. The closure
shape mirrors what ASPIRE-02's filing prescribed: explicit kind-
aware standards (LG-* + CF-* applies_to columns; per-kind
compliance matrices), consumer-shape acknowledgement (carve-out
sections), reference-consumer restructure unblock (PAPER-06
follow-up). Strategic-review's investment in waiting for the
second consumer paid back across six papers in this release.
The "non-pain counts as evidence" framing from PAPER-10's
deferral note proved load-bearing — `inthewords`'s report that
explicit-call extension-wiring works fine for them is the
strongest signal we'll get without a plugin-framework consumer.

**Concern.** This entry serves three purposes:

1. **Records the second consumer's arrival** — closing the
   strategic-review **Priority 1** gate
   ([*Get a second, independent consumer*](docs/inprogress/strategic_review.md#priority-1--get-a-second-independent-consumer)).
2. **Unblocks PAPER-06's full restructure** — the doc tree's
   "AS-IS in <consumer>" paragraphs can now be generalised to
   `docs/reference-consumers/Project1.md` (VManager) +
   `docs/reference-consumers/Project2.md` (inthewords).
3. **Reports PAPER-10's reopen evidence (criterion 2)** —
   "A second independent consumer lands and reports their
   extension-wiring story." See *Extension wiring* below.

The substantive observation: walking the standards docs end-to-
end, the prescriptive shape is **CLI- or desktop-app-centric**.
VManager is a libvirt VM-management toolkit with CLI + GUI entry
points, on-disk YAML config, vault-stored credentials, and PyPI
distribution. Many of the documented MUSTs encode that shape.
This is hard to see from inside the reference consumer.

A web/Django consumer reveals the assumptions:

- **CF-08** forbids module-global singletons — Django's
  `from django.conf import settings` IS one. (CONFIG-01.)
- **CF-09** mandates a `--config <path>` CLI flag — irrelevant
  to ASGI/WSGI processes. (CONFIG-01.)
- **LG-06** mandates a rotating file sink — anti-pattern in
  cloud-native containers. (LOG-01.)
- **LG-07** mandates a GUI log-viewer dialog — N/A to headless
  services. (LOG-02.)
- **EH-* category taxonomy** is systems-management-domain;
  HTTP-domain consumers have no natural home in the seven
  categories. (HTTP-01.)
- **DP-01 5-layer architectural map** (CLI/GUI →
  orchestration → services → foundation → platform) doesn't
  fit Django web apps (3-layer: views → services → models).
- **REL-* releasing standard** assumes PyPI publishing —
  inthewords is deployed via Ansible, not published.
- **catch-up tooling** assumes `pyproject.toml` and a `library`
  default kind (PAPER-13, PAPER-15).

None of these are blockers — every one has a workaround
(declare N/A, write a carve-out, write a custom shim). But
**every web consumer hits the same set on day one**. The
cumulative cost of "every web consumer re-litigates which
MUSTs apply" is the actual friction; specific instances are
filed as the seven companion entries above (PAPER-13/14/15,
HTTP-01, CONFIG-01, LOG-01, LOG-02).

**Why it matters.** The cornerstone-library positioning leans
on universality. "Industry-standard Python infrastructure
library" implies it works for the dominant Python application
shapes — and the dominant shape on the server side is web/API,
not VM management. The standards being shaped for VManager's
domain (a small but valuable niche) without acknowledging that
shape risks two outcomes:

- Web consumers adopt selectively (Logging + Errors + Catch-up
  tooling), skip the rest, and the library becomes a "logging
  + errors helper" by reputation rather than a cornerstone.
- Web consumers don't adopt at all because the path from
  "we have a Django app" to "we are L1 compliant" isn't
  documented — and the reference-consumer structure makes it
  look like the path doesn't exist.

The high-leverage fix is **explicit kind-aware standards**:
`docs/standards/django/` (or generally `web/`) as a sibling to
the existing CLI/desktop-shaped doc tree. Shared rules stay in
the canonical doc; framework-specific carve-outs and worked
examples live in the per-kind tree.

**Concrete evidence — extension wiring story (PAPER-10
criterion 2).** inthewords does NOT need entry-point auto-
discovery for plugins today. The application is single-tenant
in the multi_tenancy.md sense (one Django process per
container, one consumer identity, no plugin framework on top).

If we adopt mgf-common's observability extension points, the
shape will be:

- One bootstrap call site in `apps/core/apps.py::CoreConfig.ready()`
  (Django's per-process startup hook).
- Any redactor / log-handler / span-processor extensions
  registered explicitly via the documented `register_*` APIs
  in the same `ready()` block.
- Zero entry-point discovery needed. Django app readiness IS
  the equivalent dispatch mechanism.

**Conclusion: non-pain.** PAPER-10's deferral remains correct
for this consumer. We do not file pain against the explicit-
call shape. PAPER-10 may stay deferred until a different
consumer (plugin framework, multi-tenant host) files concrete
need.

**Concrete evidence — adoption surface.** inthewords
(`/home/bassam/PycharmProjects/inthewords`, commit `b9fecfa`,
2026-05-05):

- Django 5.1 / Python 3.12.
- `apps/` flat package tree, 6 sub-apps:
  `core, accounts, rooms, messaging, notifications, api`.
- Already-built central interfaces (Phase 8D, completed):
  - `apps.core.logging.get_logger` + `sanitize_extra` +
    `DevFormatter` + `JsonFormatter` (`apps/core/logging.py`,
    291 LOC).
  - `apps.core.exceptions.AppError` + 9 concrete subclasses
    + `ErrorDetail` + `ErrorCode` + `ErrorLevel`
    (`apps/core/exceptions.py`, 324 LOC).
  - `apps.core.exception_handlers.app_error_drf_handler` +
    `apps.core.middleware.AppErrorMiddleware`.
  - Lint tests in `apps/core/tests/test_central_interfaces.py`
    enforce that no production module bypasses these.
- 950 Python tests + 196 UI tests + 14 smoke tests, all
  green.
- Adoption plan documented in `docs/MGF_COMMON_ADOPTION.md` —
  six phases (discovery → scaffolding → four-gates → bootstrap
  → exceptions migration → logging migration → close-out).
  Phase 0 (discovery) is what surfaced this entry's findings.

The unique value of inthewords as a consumer is exactly this:
we already built parallel implementations of mgf-common's
`AppError` and `get_logger` independently before mgf-common
existed. The migration story is "what happens when a project
that already has the pattern adopts the cornerstone library?"
— not the greenfield wiring VManager went through.

**Suggested shape.**

The seven companion entries (PAPER-13, PAPER-14, PAPER-15,
HTTP-01, CONFIG-01, LOG-01, LOG-02) carry concrete shape
proposals for each specific friction. This entry's suggested
shape is the **structural** answer:

**Approach A — Per-kind standards subtree.**

```
docs/standards/
├── README.md                  # explains kinds + applicability
├── DESIGN_PRINCIPLES.md       # canonical (mostly kind-agnostic)
├── ERROR_HANDLING.md          # canonical + per-kind carve-outs
├── LOGGING.md                 # canonical + per-kind carve-outs
├── CONFIGURATION.md           # canonical + per-kind carve-outs
├── (others)
├── django/                    # NEW: Django-specific extensions
│   ├── README.md
│   ├── ERROR_HANDLING.md      # HTTP categories, DRF integration
│   ├── LOGGING.md             # cloud-native + Channels
│   ├── CONFIGURATION.md       # framework-native settings
│   └── BOOTSTRAP.md           # AppConfig.ready() pattern
├── fastapi/                   # NEW: FastAPI-specific (future)
└── desktop/                   # NEW: VManager-shaped (current default)
```

Each per-kind doc references the canonical rules and adds the
framework's deviations. The canonical docs grow a small
"Applicability" section listing kinds and per-kind exemptions.

**Approach B — Inline carve-out sections in each canonical
doc.**

Each canonical standards doc grows a `## §N — <Topic> for
framework consumers` section that lists the per-kind carve-
outs inline. Less file proliferation; harder to navigate when
a consumer wants the full Django picture.

**Recommend Approach A** for long-term clarity once the
per-kind set has 2+ entries. **Short-term:** Approach B is
fine for inthewords's adoption (one consumer, one carve-out
set per topic). The structural decision can defer until a
third consumer of a different kind shows up.

A standards-doc README change naming the supported kinds —
even just listing them as "the four shapes mgf-common
recognises today: cli, desktop-gui, library-only,
django-app" — is a 30-line edit that immediately reduces
the consumer-side decision burden.

**Decision rationale.** (Filled when triaged.)

**Retrospective.** (Filled when shipped.)

---

#### `ASPIRE-03` — `docs/standards/web/` subtree: distill the two web consumers' adoption walks into a permanent reference

| Field | Value |
|---|---|
| Status | ✅ SHIPPED (incremental — README; per-recipe promotion ongoing) |
| Severity | 💭 Aspirational |
| Submitter | inthewords (golden-example pass, 2026-05-07) |
| Submitted | 2026-05-07 |
| Decision | accept (Approach A — incremental: ship `docs/standards/web/README.md` navigation page first; per-recipe promotion trickles) |
| Decided on | 2026-05-07 |
| Scheduled for | v0.20.0 (README); per-recipe promotion follows |
| Shipped in | v0.20.0 — front-door navigation page at [`docs/standards/web/README.md`](docs/standards/web/README.md). Sections: *Why a per-kind subtree* (friction story + carve-out summary); *Read-in-order for a new web consumer* (7-step path: master index → CONFIGURATION §0a → framework-owned-logging → cloud-native-logging → ERROR_HANDLING with HTTP-01 → framework recipes → non-adoption principle); *Recipes index* (cross-cutting; web-domain) with canonical paths + paper closures; *Per-rule applicability for web consumers* (topic-doc-by-topic-doc summary of what applies / what's N/A or carved-out); *Promotion roadmap* (incremental checklist). Cross-link from `docs/standards/README.md` "Per-kind subtrees" pointer. Migration guide in [`docs/cutover/archive/v0.20.0.md`](docs/cutover/archive/v0.20.0.md#aspire-03--web-standards-subtree). **Per-recipe promotion roadmap** (each box is one future small PR): [x] `web/README.md` (v0.20.0) · [x] `docs/recipes/framework-owned-logging.md` (PAPER-25, v0.20.0) · [ ] `web/http-exceptions.md` (promote PAPER-24 cutover-guide content + `recipes/http.md` consumer-pattern) · [ ] `web/framework-config.md` (promote `CONFIGURATION.md` §0a inthewords worked example) · [ ] `web/stub-gaps.md` (django-stubs/DRF/Channels/Celery workaround library — contingent on inthewords' upstream contribution) · [ ] `web/adoption-walk.md` (canonical onboarding narrative). |

**Concern.** ASPIRE-02 (closed in v0.18.0) committed to
"per-kind standards" as the structural answer to the
framework-fit gap. The web carve-outs that shipped in
v0.18.0 (CONFIG-01, LOG-01, LOG-02, HTTP-01) live as
sub-sections inside the existing topic docs
(`CONFIGURATION.md`, `LOGGING.md`, `ERROR_HANDLING.md`).

After two web consumers (inthewords + PlasmaMapper) and
three release rounds (v0.17 / v0.18 / v0.19), there's enough
crystallised content to justify a **dedicated `docs/standards/web/`
subtree** as the permanent home for web-domain conventions.
The cutover guides have been carrying this content on a
per-release basis; promoting the durable parts to a standards
subtree closes the "where do I look first" gap for any new
web consumer.

**Why it matters.** A FastAPI / Django / Flask consumer
landing on mgf-common today reads `docs/standards/`'s 11
topic docs and has to mentally filter "which of these MUSTs
apply to my framework's shape?". The framework-native
carve-outs are scattered across CONFIGURATION.md §0a,
LOGGING.md §LG-06 cloud-native branch, etc. — discoverable
only by reading every doc.

A `docs/standards/web/` subtree gives the new consumer a
single front door that says "here are the web-specific
conventions, recipes, and caveats." The existing topic docs
stay authoritative for cross-domain MUSTs; the web subtree
is the **narrative wrapper** that says "for a web consumer,
read these in order."

**Concrete evidence.** Three release rounds of consumer
adoption surfaced repeatable patterns that are NOT in the
canonical topic docs but ARE durable across web consumers:

- **The `bootstrap(setup_logging=False)` pattern** (Django
  AppConfig.ready() seam, FastAPI lifespan, Flask
  before_first_request) — currently lives in v0.19.0
  cutover guide §BOOTSTRAP-01. Cutover guides are
  per-release; the pattern is permanent.
- **The django-stubs / DRF / Channels / Celery workaround
  library** — inthewords distilled 10 reusable patterns at
  `docs/standards/web/mypy-stubs-workarounds.md` (in our
  repo). FastAPI hits parallel gaps; the library
  generalises if promoted to mgf-common's standards tree.
- **The framework-native config worked example** (which
  CF-* rules apply, which are N/A, with rationale per
  rule) — currently in CONFIGURATION.md §0a as an
  inthewords-specific example.
- **The cloud-native logging recipe** (stdout-only, JSON
  shape stability, deployment-coupled parser
  considerations) — currently in
  `docs/recipes/cloud-native-logging.md` (Phase 5
  / LOG-01 closure). Belongs in the web subtree as the
  canonical reference.
- **The HTTP exception category-catch property** with
  `ExceptionTranslationMiddleware` integration (PAPER-24's
  closure) — FastAPI-specific, currently in cutover-guide
  §PAPER-24.
- **HttpError consumer pattern** — class declarations,
  multi-inheritance for Django (per inthewords' ADR-003),
  status_map vs http_status semantics (per PAPER-24's
  resolution).

Each of these is a **recipe**, not a MUST. The standards
docs mostly carry MUSTs. Recipes belong in
`docs/recipes/` today; the per-kind structuring is the
proposal.

**Suggested shape.**

```
docs/standards/
├── README.md                    # adds a "Per-kind subtrees" §
├── DESIGN_PRINCIPLES.md         # canonical
├── ERROR_HANDLING.md            # canonical (HTTP-01 sub-section stays)
├── LOGGING.md                   # canonical (LG-06 cloud-native branch stays)
├── CONFIGURATION.md             # canonical (§0a framework-native stays)
├── ... (other topic docs)
├── web/                         # NEW: web-domain subtree
│   ├── README.md                # narrative front-door
│   ├── http-exceptions.md       # HTTP-01 hierarchy + PAPER-24
│   │                            # middleware integration + consumer
│   │                            # patterns (Django multi-inherit,
│   │                            # FastAPI subclass)
│   ├── framework-config.md      # CF-* applicability matrix +
│   │                            # the inthewords worked example
│   │                            # (currently in CONFIGURATION.md §0a)
│   ├── cloud-native-logging.md  # LG-06 stdout-only branch + JSON
│   │                            # shape stability + deployment-coupled
│   │                            # parsers (currently the Phase 5 /
│   │                            # LOG-01 closure recipe)
│   ├── bootstrap-framework.md   # BOOTSTRAP-01 setup_logging=False
│   │                            # for Django/FastAPI/Flask/Pyramid
│   │                            # (currently in v0.19.0 cutover guide)
│   ├── stub-gaps.md             # the django-stubs/DRF/Channels/
│   │                            # Celery workaround library (10
│   │                            # patterns from inthewords' Phase
│   │                            # 2.5; FastAPI-specific extensions
│   │                            # added as PlasmaMapper hits them)
│   └── adoption-walk.md         # the canonical onboarding for a
│                                # net-new web consumer — read in
│                                # this order, hit these gates
└── desktop/                     # NEW: VManager-shaped (Qt + libvirt)
    └── ...                      # parallel structure for desktop
                                 # consumers; populated as VManager's
                                 # learnings crystallize
```

**Recipe vs standards distinction.** Standards docs declare
MUSTs/SHOULDs. The web subtree is mostly recipes —
"here's how a Django consumer wires X, here's why."
Following the existing `docs/recipes/` pattern. The subtree
groups them by audience (web consumers) rather than by
topic.

**Recommend Approach A (incremental) — start with
`docs/standards/web/README.md` as a navigation page**
listing the cross-cutting recipes (currently scattered) +
a short narrative for new web consumers. Promote each
recipe from cutover-guide / cross-doc-section into a
standalone file as the maintainer's editing time allows.
The README can ship in one short PR; the per-recipe
promotions trickle in over subsequent releases.

Approach B (big-bang) is the same end-state shipped in
one large PR. Higher review friction; same outcome.

**Cross-references.**
- ASPIRE-02 (shipped v0.18.0): the carve-out approach this
  builds on. The "per-kind standards subtree" idea was
  Approach A in ASPIRE-02's suggested shape but didn't
  ship in v0.18.0 — only the carve-out sections inside
  existing topic docs did. ASPIRE-03 is the follow-on.
- inthewords' `docs/standards/web/mypy-stubs-workarounds.md`
  — the worked example of one such recipe. Drop-in source
  if mgf-common wants to adopt it under the proposed
  subtree.
- BOOTSTRAP-01 cutover-guide §BOOTSTRAP-01 — content for
  `web/bootstrap-framework.md`.
- PAPER-24 cutover-guide §PAPER-24 — content for
  `web/http-exceptions.md`'s middleware-composition section.

**Decision rationale.** Approach A (incremental). Approach B
(big-bang) is the same end-state shipped in one large PR — higher
review friction, same outcome. Incremental landing is also a
release-engineering experiment: v0.20.0 ships the front door;
per-recipe promotion lands as small PRs over subsequent releases,
tracked through this entry's Retrospective field. If the pattern
works, future structural ASPIRE entries can follow the same shape
(incremental landing with named milestones rather than one-shot
delivery).

**Retrospective.** v0.20.0 closes the structural commitment from
ASPIRE-02 — the "per-kind standards subtrees" idea was Approach A
in ASPIRE-02's suggested shape but didn't ship in v0.18.0; only
the carve-out sections inside existing topic docs did. ASPIRE-03 is
the follow-on. After two web consumers (inthewords + PlasmaMapper)
and three release rounds (v0.17 / v0.18 / v0.19), there was enough
crystallised content to justify the dedicated subtree. The README
shipped + PAPER-25's recipe shipped in the same release; per-recipe
promotion is named explicitly so consumers can see what's coming.
Status remains "shipped (incremental)" rather than fully closed
because the promotion roadmap has open boxes — each future small
PR ticks one box; this entry stays in this state until all are
checked.

---

#### `ASPIRE-04` — Codify "documented non-adoption" as a first-class consumer outcome (Magogi-foundation principle)

| Field | Value |
|---|---|
| Status | ✅ SHIPPED |
| Severity | 💭 Aspirational |
| Submitter | inthewords (golden-example pass, 2026-05-07) |
| Submitted | 2026-05-07 |
| Decision | accept (standalone principle doc at `docs/standards/principles/non-adoption-is-valid.md` + cross-link from `docs/standards/README.md`) |
| Decided on | 2026-05-07 |
| Scheduled for | v0.20.0 |
| Shipped in | v0.20.0 — standalone principle doc at [`docs/standards/principles/non-adoption-is-valid.md`](docs/standards/principles/non-adoption-is-valid.md). Sections: *What this principle says* (core statement + three-outcome adoption framework: Adopted / Adopted with carve-out / Declined); *Three components* (conscious decline, documented rationale, feedback if generalizable); *When to non-adopt* (five concrete triggers — deployment-coupled contract, policy, framework architecture, consumer scale, cost vs alternative); *When NOT to non-adopt* (negative-space callout — six patterns that look like non-adoption but are cover for laziness, indefinite deferral, or refactor avoidance); *Worked examples* (inthewords' LOG-01 / BOOTSTRAP-01 pre-v0.19.0 + PlasmaMapper's "small consumer" scope discipline); *How to file the rationale* (project-side ADR, tracker entry, `FEEDBACK.md` paper — by durability; ADR template included). Cross-link from [`docs/standards/README.md`](docs/standards/README.md) "Documented non-adoption preserves conformance" paragraph. Migration guide in [`docs/cutover/archive/v0.20.0.md`](docs/cutover/archive/v0.20.0.md#aspire-04--documented-non-adoption-principle). |

**Concern.** Through the inthewords adoption walk, **two
phases ended in "documented non-adoption"** (Phase 5 logging
and Phase 3 bootstrap pre-v0.19.0):

- Phase 5 — `mgf.common.observability.JsonFormatter` /
  `Redactor` not adopted because the JSON wire shape is
  deployment-coupled (Grafana Cloud parsers depend on the
  project shape) and the redaction key set differs by
  policy (`token` exclusion per project G13-02).
- Phase 3 — `mgf.common.bootstrap()` pre-v0.19.0 not
  adoptable due to `.env` clash + unconditional
  logging-handler install. (BOOTSTRAP-01 closed this in
  v0.19.0; we then DID adopt with `setup_logging=False`.)

In both cases the right answer was a **deliberate
non-adoption with documented rationale**, not a forced
adoption. Both gave mgf-common evidence — Phase 5 produced
the LOG-01 cloud-native carve-out; Phase 3 produced
BOOTSTRAP-01.

The pattern is repeatable. Any consumer encountering a
mgf-common feature whose default behavior conflicts with a
deployment-coupled or policy-specific constraint may
correctly conclude "I'm not adopting this part" — and
**document why**. PlasmaMapper hit similar shape with
PAPER-22 / PAPER-23 (their alembic and pytest-plugin
non-adoptions or workarounds).

**Why it matters.** Without a codified principle,
contributors (especially newer ones) feel pressure to adopt
every standards-bar primitive — even when the local context
makes adoption a *regression*. The strategic-review priority
1 framing ("non-pain reads count as evidence too") hinted at
this in passing. Promoting it to a **named principle** that
new consumers can reference makes the decision-making
explicit:

> **Documented non-adoption** is a first-class outcome of
> standards conformance work. A consumer that consciously
> declines a primitive AND records the rationale — in an
> ADR, a tracker entry, or a feedback paper — is **more**
> conformant than a consumer that adopts blindly and breaks
> a deployment constraint.

The principle has three components:

1. **Conscious decline.** Not "we forgot to adopt" or "we'll
   get to it" — an explicit decision after empirical or
   architectural review.
2. **Documented rationale.** A pointer (ADR, tracker doc,
   feedback paper) that captures the *why* so future
   contributors don't re-litigate.
3. **Feedback if generalizable.** If the rationale points
   at a gap mgf-common could close (like LOG-01 / BOOTSTRAP-01),
   the consumer files a feedback paper. The non-adoption
   becomes a *contribution*.

**Why it matters specifically for mgf-common.** The
"cornerstone library" framing requires consumers across
multiple framework shapes (CLI, GUI, web Django, web
FastAPI, scientific). Some primitives that are right for
one shape are wrong for another — that's the legitimate
domain of carve-outs (CONFIG-01, LOG-01, BOOTSTRAP-01 all
landed because of this). A principle that names "documented
non-adoption is the right outcome when adoption would harm
your context" gives consumers cover to make the call AND
nudges them to file the carve-out so future consumers don't
re-derive.

**Concrete evidence — inthewords' two non-adoptions:**

- ADR-004 (logging non-adoption):
  `inthewords/docs/adrs/ADR-004-logging-non-adoption.md`
  documents the LOG-01 carve-out with empirical evidence
  (the JSON-shape divergence table) and 5 regression tests
  pinning the decision.
- ADR-006 + Phase 3 first closeout: documented non-adoption
  before v0.19.0; flipped to adopted-with-flag after
  BOOTSTRAP-01 shipped. The PROCESS showed both states are
  valid at different times.

**Concrete evidence — PlasmaMapper:**

- PAPER-22 (alembic `include_object` pass-through): they
  filed because their PostGIS context needed it; the
  workaround until then was documented non-adoption of
  alembic autogenerate.
- The "small consumer" framing in PlasmaMapper's
  `MGF_ADOPTION.md` §1: explicitly declines big-consumer
  surface (`VersionedFileStore[T]`, vault backends, async
  logging) — non-adoption is the framing the project leads
  with.

**Suggested shape.**

A new doc at
`docs/standards/principles/non-adoption-is-valid.md` (~150
lines). Sections:

```
# Documented non-adoption — a first-class outcome

## What this principle says
## Three components: conscious decline, rationale, feedback
## When to non-adopt
## When NOT to non-adopt (don't use this as cover for laziness)
## Worked examples (inthewords Phase 5, PlasmaMapper "small consumer")
## How to file the rationale (ADR, tracker entry, feedback paper)
## Cross-references (LOG-01, BOOTSTRAP-01, ASPIRE-02)
```

Plus a one-line cross-reference from
`docs/standards/README.md`'s "Conformance levels" section:
"Documented non-adoption (per
`principles/non-adoption-is-valid.md`) preserves L0/L1/L2
status when the rationale is recorded."

**Alternative shape.** Inline as a new section in
`docs/standards/README.md` rather than a standalone file.
Lower visibility but no fragmentation. Recommend the
standalone file because the principle is meaty enough (the
"when NOT to non-adopt" section especially) to deserve its
own page.

**Cross-references.**
- LOG-01 (shipped v0.18.0) — the cloud-native carve-out
  that emerged from inthewords' Phase 5 documented
  non-adoption.
- BOOTSTRAP-01 (shipped v0.19.0) — both fixes emerged
  from inthewords' Phase 3 documented non-adoption.
- ASPIRE-02 (shipped v0.18.0) — the strategic-review
  priority 1 framing that "non-pain reading is also
  evidence."
- inthewords' ADR-004 + ADR-006 — the worked examples.
- PlasmaMapper's `MGF_ADOPTION.md` §1 "small consumer"
  scope discipline.

**Decision rationale.** Standalone file (recommended in the filing)
rather than inline in `docs/standards/README.md`. The principle is
meaty enough (the "When NOT to non-adopt" negative-space section
especially) to deserve its own page; inline would dilute both the
principle and the README. The principle is also positioned to be
referenced from sibling Magogi packages (mgf-apiprobe and future
mgf-* libraries) — having its own URL makes that cross-link cheap.

**Retrospective.** The framing behind every shipped carve-out
(LOG-01, CONFIG-01, BOOTSTRAP-01) was implicit until v0.20.0 named
it. Naming gives newer contributors cover to decline a primitive
when adoption would harm their context, AND nudges them to file
the rationale upstream so the carve-out can be generalised. The
"Magogi-foundation" framing means the principle is not mgf-common-
specific; it applies to every shared library the Magogi ecosystem
produces. inthewords' ADR-004 + ADR-006 + PlasmaMapper's "small
consumer" scope discipline are cited as worked examples — credit
lives in the doc's §"Worked examples". The doc is the structural
home for any future "documented non-adoption" filing.

---

#### `ASPIRE-05` — `mgf-common` as cross-language engineering-process source-of-truth

| Field | Value |
|---|---|
| Status | OPEN |
| Severity | 💭 Aspirational |
| Submitter | Maintainer (federation-shape design conversation, 2026-05-08) |
| Submitted | 2026-05-08 |
| Decision | pending |
| Decided on | — |
| Scheduled for | post-v1.0 (long-horizon) |
| Shipped in | — |

**Concern.** `mgf-common` today has two stated identities: (a) a
Python infrastructure library, (b) the standards source-of-truth
for the Magogi engineering discipline (`docs/standards/`). These
are bundled by accident of history — the standards were colocated
with the Python library that exemplifies them.

If the Magogi ecosystem grows a non-Python project (e.g.,
`mgf-website-template` — Astro/TypeScript per PAPER-30 below), the
standards source-of-truth role MUST extend beyond Python while the
library role does not. The two responsibilities pull apart.

**Why it matters.** The first non-Python Magogi project will reveal
this seam. Decisions to make:

1. Does the standards repo split from the Python library? (e.g.
   `mgf-standards/` repo holds `docs/standards/`; `mgf-common/`
   holds the Python implementation.)
2. Or does `mgf-common` keep both roles, with non-Python projects
   referencing standards by URL into mgf-common's repo?
3. Or does `mgf-common` get language-aware tooling — e.g.
   `init-project --kind website` scaffolds an Astro project with
   a CLAUDE.md that inlines the language-agnostic Magogi rules?

**Concrete evidence.** The `--kind website` design conversation
(2026-05-08) produced PAPER-30 (cookiecutter sibling repo for
Astro marketing sites). That sibling will need to reference the
language-agnostic subset of `docs/standards/`: DESIGN_PRINCIPLES,
SECURITY_STANDARD §subsets, parts of TESTING and API_DESIGN.
The Python-specific subset (CONFIGURATION pydantic-settings,
LOGGING stdlib + JSON formatter, ERROR_HANDLING typed exception
hierarchy) doesn't apply.

**Suggested shape.** Defer the structural decision until two or
more Magogi non-Python projects exist (the "second-consumer
arrival" promotion bar). Until then:

- mgf-common keeps both roles as today.
- Non-Python siblings reference `docs/standards/` by URL.
- The cross-cuts (DESIGN_PRINCIPLES, SECURITY_STANDARD applicable
  subsets) are not duplicated; the non-Python sibling's CLAUDE.md
  links to mgf-common's URLs.

When a second non-Python sibling exists, revisit:

- Option A — Split standards out: `mgf-standards/` is a separate
  repo; `mgf-common/` becomes a pure Python library that
  references the standards repo. Cleanest but largest move.
- Option B — Standards stay in mgf-common; mgf-common gets
  language-aware `init-project` for non-Python kinds. Standards
  repo keeps both roles but acknowledges them.
- Option C — Per-language standards subtrees in mgf-common:
  `docs/standards/python/`, `docs/standards/typescript/`, etc.
  Heaviest documentation overhead.

Recommended at decision time: Option A if the non-Python population
is large (3+); Option B if it's small (1-2).

**Cost if deferred past v1.0.** Low. v1.0 locks the Python public
API surface, not the standards-repo structure. The standards can
move OR stay; both options remain open.

**Cross-references.**
- `docs/design/federation.md` — the federation pattern (Python siblings).
- `docs/inprogress/federation_roadmap.md` — the v0.28 → v1.0 split plan
  (Python-only at this stage).
- PAPER-30 (mgf-website-template) — the first non-Python Magogi
  sibling and the trigger for re-evaluating ASPIRE-05.
- ASPIRE-06 — the v0.28-→-v1.0 federation split that this builds on.

**Decision rationale.** *(Filled when triaged.)*

**Retrospective.** *(Filled when shipped.)*

---

#### `ASPIRE-06` — Federated package architecture: extract framework adapters into sibling packages by v1.0

| Field | Value |
|---|---|
| Status | ACCEPTED (staged across v0.28 — v0.31; lock at v1.0) |
| Severity | 💭 Aspirational |
| Submitter | Maintainer (federation-shape design conversation, 2026-05-08) |
| Submitted | 2026-05-08 |
| Decision | accept (per-minor extractions: mgf-fastapi v0.28, mgf-http v0.29, mgf-sqlalchemy + mgf-alembic v0.30, mgf-django v0.31; lock surface at v1.0; standards stay in mgf-common; sibling-domain concrete exceptions move with their sibling; tight-coupling-runs-adapter→core; consumers (PlasmaMapper / inthewords) face one rename per release) |
| Decided on | 2026-05-08 |
| Scheduled for | v0.28 / v0.29 / v0.30 / v0.31 / v1.0 |
| Shipped in | v0.28.0 (mgf-fastapi 0.1.0 — 2026-05-08), v0.29.0 (mgf-http 0.1.0 — 2026-05-09), v0.30.0 (mgf-sqlalchemy 0.1.0 + mgf-alembic 0.1.0 + mgf-fastapi 0.2.0 — 2026-05-10), v0.31.0 (mgf-django 0.1.0 — 2026-05-10). All four framework-adapter extractions shipped; v0.32+ stabilization window opens before v1.0 lock. |

**Concern.** `mgf-common` today contains both pure-Python core
infrastructure (AppError + bootstrap + observability + config +
settings + providers + process + cli + vault + versioned + etc.)
AND framework-specific adapters (`mgf.common.fastapi`,
`mgf.common.django`, `mgf.common.http`, `mgf.common.db`,
`mgf.common.alembic`). The two shapes have diverged enough that
co-locating them creates friction:

- **Surface size.** v0.26 + v0.27 added 7 new public names — all
  under `mgf.common.fastapi.*`. The web-stack surface is growing
  faster than the core.
- **Versioning collision.** A `HttpError` change in core requires
  a mgf-common minor; an `IpAllowlist` knob change ALSO requires
  a mgf-common minor. They don't evolve at the same rate but they
  ship at the same cadence.
- **Mental-model breadth.** A new consumer reading `mgf.common.*`
  reads through 15+ submodules; reducing to ~10 pure-Python
  submodules with clearly-separate framework-adapter siblings
  shrinks the cognitive load.
- **Closed-box hygiene.** Today the `[fastapi]`, `[django]`,
  `[http]`, `[db]`, `[alembic]` extras are the ONLY barrier
  between a CLI consumer and the framework deps. A sibling-
  package boundary makes the boundary harder.

The apiprobe split set the pattern (FEEDBACK §federation in
`docs/design/federation.md`). ASPIRE-06 extends it.

**Why it matters.** The 0.x window is the design window. Locking
the federated surface at v1.0 means doing the split BEFORE v1.0,
which means doing it in the late-0.x release sequence
(v0.28-v0.31). Doing it after v1.0 means breaking the v1.0
contract — much higher cost.

**Concrete evidence.** PAPER-26 + PAPER-27 + PAPER-28 (shipped in
v0.26 + v0.27) are the three most recent additions; they're all
under `mgf.common.fastapi.*`; they're 4 modules and ~1500 LOC of
test + impl combined. Every one of those is FastAPI-coupled,
imports nothing from a hypothetical `mgf-django` sibling, and is
the natural seed of `mgf-fastapi`.

**Suggested shape.** Per-minor extractions, one sibling per
release, in order of risk:

| Release | Extracts | Why this order |
|---|---|---|
| v0.28 | `mgf-fastapi` (incl. webhooks/security/testing + framework-domain concrete exceptions like `HmacVerificationError`) | Most-recently-shipped surface; freshest; touches PlasmaMapper most |
| v0.29 | `mgf-http` (`AsyncHttpClient`, `RetryPolicy`) | Single-purpose; clean boundary |
| v0.30 | `mgf-sqlalchemy` + `mgf-alembic` | Pair — alembic depends on sqlalchemy |
| v0.31 | `mgf-django` | Touches inthewords; isolated scope |
| v0.32+ | Stabilization, deprecation cleanup | Final polish before v1.0 |
| v1.0 | Lock the federated surface | Promote `experimental` → `stable` |

**Concrete decisions locked at decision time:**

1. **mgf-common stays the federation leaf.** Every sibling depends
   ON it; nothing depends BACK on a sibling. Per
   `docs/design/federation.md`.
2. **Hierarchy roots + status leaves stay in mgf-common.exceptions.**
   `AppError`, `HttpError`, `HttpClientError`, `HttpServerError`,
   and the generic status-code leaves (`HttpUnauthorized`,
   `HttpForbidden`, `HttpNotFound`, etc.) stay in mgf-common.
3. **Sibling-domain concrete leaves move with their sibling.**
   `HmacVerificationError` (currently in mgf-common.exceptions)
   moves to mgf-fastapi at v0.28. Same pattern for any other
   framework-domain concretes added later.
4. **Standards docs (`docs/standards/`) stay in mgf-common.** Source
   of truth for the federation; cross-cuts every sibling.
5. **Recipes split with their package.** Framework-specific
   recipes (`fastapi.md`, `webhooks.md`, `django.md`, `http.md`,
   `db.md`, `alembic.md`) move to their respective siblings.
   Cross-framework recipes (`framework-owned-logging.md`,
   `cloud-native-logging.md`) stay in mgf-common's `docs/recipes/`.
6. **`mgf-common init-project` stays in mgf-common.** Templates
   live in `mgf-common/templates/<kind>/` and pull in sibling
   deps via `pyproject` snippets. Init-project is the
   federation-orchestrator role.
7. **Each sibling has its own Codeberg repo, PyPI package,
   versioning, CHANGELOG, FEEDBACK, cutover guides, CI.**
   Independent semver per sibling.
8. **Per-minor staging.** Big-bang reorg rejected — incremental
   extraction validates the sibling-creation flow per piece and
   reduces cross-package mistake risk.

**Cost if deferred past v1.0.** Very high. v1.0 locks the public
surface; reorganizing afterwards either breaks the v1.0 contract
or requires v2.0 within 6-12 months.

**Cross-references.**
- `docs/design/federation.md` — the federation pattern (Python
  siblings).
- `docs/inprogress/federation_roadmap.md` — the **load-bearing
  tracking document** for this work (per-sibling specs, quality
  gates, decisions log, open questions, future improvements).
- ASPIRE-05 — long-horizon cross-language extension.
- PAPER-30 — first concrete non-Python sibling (`mgf-website-template`).

**Decision rationale.** Approved 2026-05-08. The maintainer
explicitly authorized "don't worry about current consumers below
v1.0" — consumers are co-designers; v0.x has the freedom v1.0
won't. Per-minor staging chosen over big-bang for validation.
Tight-coupling-runs-adapter→core (mgf-common changes drag every
sibling) accepted as the cost of clean separation.

**Retrospective.** *(Filled when v1.0 ships and the federated
shape locks.)*

---

#### `PAPER-30` — `mgf-website-template` cookiecutter sibling repo for Magogi marketing sites

| Field | Value |
|---|---|
| Status | ✅ SHIPPED — template + first consumer site both on Codeberg (2026-05-10 / 2026-05-11); deploy-verification step is consumer-side ops work, not a paper-closure blocker |
| Severity | 🟢 Nice-to-have |
| Submitter | Maintainer (Magogi-foundation-site design conversation, 2026-05-08) |
| Submitted | 2026-05-08 |
| Decision | Adopted |
| Decided on | 2026-05-10 |
| Scheduled for | sibling repo bootstrap (not a mgf-common release) |
| Shipped in | **Template:** `codeberg.org/magogi-admin/mgf-website-template` (root commit 2026-05-10). **First consumer:** `codeberg.org/magogi-admin/magogi-foundation` (root commit `14e17d8`, 2026-05-11) — the Magogi-foundation marketing site, generated from the template, smoke-tested (npm install + type-check 0/0/0 + build 4 pages + sitemap). |

**Concern.** Magogi has a recurring class of "marketing /
showcase web site" projects (foundation site, future product
landing pages, sub-org sites). Each is:

- Pure content delivery (vision, goals, products)
- Visual-heavy (images, GIFs, videos)
- One small interactive piece — contact form
- No API, no data store, no auth
- SEO + performance matter
- Often EN-only initially; some may go i18n later

Python is the wrong tool for this class. Static-site generators
(Astro / Hugo / Eleventy) win on every meaningful axis (cost,
edge-CDN latency, image pipeline, deploys, spam handling).

**Why it matters.** Without a template, every new Magogi
marketing site reinvents the structure (CI / deploy / form
handler / image pipeline / CLAUDE.md content). With a template,
they all start identical and converge organically.

**Concrete evidence.** The Magogi foundation site (first
instance) is being built now. With Infomaniak as the committed
host (Web Hosting product supports static deploy via SSH/SFTP/Git)
and EN-only locked, the stack is: Astro + Cloudflare-or-similar
for forms (or Infomaniak's own form-to-email if they grow one)
+ Infomaniak Web Hosting + GitHub/GitLab CI deploy.

**Suggested shape.** A separate Codeberg repo
`codeberg.org/magogi-admin/mgf-website-template`:

- **NOT** a `mgf-common` `--kind` (mgf-common stays Python-only).
- **NOT** a Python package (consumer doesn't `pip install` it).
- A cookiecutter-style template repo: clone, run `cookiecutter`
  or just `git clone + edit`, get an Astro project ready to
  deploy.

Contents:

```
mgf-website-template/
├── README.md                 # how to clone + customize
├── cookiecutter.json         # variables (project_name, primary_color, etc.)
├── {{cookiecutter.project_slug}}/
│   ├── astro.config.ts       # Astro config
│   ├── package.json
│   ├── src/
│   │   ├── components/       # hero, products-grid, contact-form, etc.
│   │   ├── layouts/
│   │   └── pages/
│   ├── public/               # images, robots.txt, sitemap.xml
│   ├── docs/CLAUDE.md        # references mgf-common standards by URL
│   ├── .github/workflows/    # build + deploy to Infomaniak via SFTP
│   └── README.md
└── LICENSE
```

The `CLAUDE.md` in the generated project references the
language-agnostic subset of `docs/standards/` in mgf-common (per
ASPIRE-05 — it's the first test of cross-language standards
travel).

**Cost if deferred past v1.0.** Negligible. mgf-website-template
is independent of mgf-common's versioning. It can land any time.

**Cross-references.**
- ASPIRE-05 — cross-language standards source-of-truth (long-
  horizon; mgf-website-template is the first non-Python project
  exercising the question).
- ASPIRE-06 — federated package architecture (Python siblings;
  mgf-website-template sits parallel as a non-Python template).
- `docs/design/federation.md` — the federation pattern.

**Decision rationale.** Adopted as proposed on 2026-05-10. The
template ships as a separate Codeberg repo, not absorbed into
`mgf-common`. Reasons:

- Mirrors the **`mgf-apiprobe` sibling pattern** — a domain-specific
  helper that earns its own repo because it cuts across consumers.
- The Magogi-foundation marketing site is concrete (in flight); the
  template formalises the shape so future Magogi marketing sites
  inherit it rather than reinvent it.
- It exercises **ASPIRE-05** in production: the generated project's
  `docs/CLAUDE.md` references the language-agnostic subset of
  `docs/standards/` by URL, so the standards travel into a non-Python
  project without `mgf-common` ever being installed there.
- Independent versioning: the template iterates on its own cadence;
  template improvements don't drag a `mgf-common` release.

**Forms strategy refinement (2026-05-10).** During the implementation
session, the open question "Cloudflare Workers vs Infomaniak's own
form-to-email" was resolved in favour of **Cloudflare Workers +
Turnstile + Resend**:

- Host-agnostic — survives moving off Infomaniak; the Worker pattern
  works regardless of where `dist/` is served.
- One Worker pattern serves N Magogi sites with per-site `[vars]`
  config (federation-aligned: share infrastructure across siblings).
- Turnstile is currently best-in-class invisible CAPTCHA; significantly
  better spam handling than Infomaniak's bare form-to-email would
  provide.
- Free tier (100k req/day Workers, generous Turnstile, free Resend
  tier) covers any realistic marketing-site volume.
- Cost: one extra account (Cloudflare) + one email-sending API key —
  small one-time setup that pays back across every future site.

**Retrospective (partial — 2026-05-10).** Local scaffold complete:

- Repo at `~/PycharmProjects/mgf_website_template/` (Codeberg slug:
  `mgf-website-template` per the hyphen convention for new federation
  siblings).
- Cookiecutter variables: `project_name`, `project_slug`,
  `project_description`, `domain`, `primary_color`, `contact_email`,
  `codeberg_namespace`, `infomaniak_remote_path`,
  `turnstile_site_key`. `project_slug` auto-derives from
  `project_name`; `contact_email` auto-derives from `domain`.
- Generated project shape: Astro 5 + TypeScript site (`src/` → `dist/`,
  4 pages: index/about/products/contact) + Cloudflare Worker
  (`worker/`, Turnstile + Resend) + GitHub Actions workflow that
  parallel-deploys static site (Infomaniak SFTP) + Worker (Cloudflare
  via official `wrangler-action`).
- Cross-language standards reference at `{{slug}}/docs/CLAUDE.md` —
  cites the language-agnostic mgf-common standards subset
  (`DESIGN_PRINCIPLES`, `SECURITY_STANDARD`, `SCOPE`, process-only
  bits of `RELEASING`, the `web/` subtree); explicitly skips Python-
  shaped standards (`ERROR_HANDLING`, `LOGGING`, `CONFIGURATION`,
  `TESTING`, `COMMON_COMPONENTS`).
- **Smoke test passed** (2026-05-10): `cookiecutter --no-input` →
  `npm install` → `npm run check` (0 errors) → `npm run build` (4
  pages + sitemap to `dist/`) → worker `tsc --noEmit` (clean). All on
  default cookiecutter inputs (`Magogi Foundation` / `magogi-foundation`).

**Implementation notes worth keeping.**

1. **Astro / Jinja2 brace conflict.** Astro's
   `prop={{ key: "value" }}` (object-literal-in-attribute) collides
   with Jinja2's `{{ var }}` syntax during cookiecutter rendering and
   throws `expected token 'end of print statement', got ':'`. Fix:
   bind the object to a `const` in the component frontmatter and
   reference it as a single-brace expression in the markup
   (`prop={obj}`). Caught at the smoke-test step on `index.astro:15`.
2. **GitHub Actions `${{ secrets.X }}` vs Jinja2.** Cookiecutter's
   Jinja2 evaluator parses `{{ ... }}` regardless of the leading `$`,
   so `${{ secrets.INFOMANIAK_SSH_KEY }}` raises an undefined-variable
   error. Fix: list `.github/workflows/deploy.yml` in the
   `_copy_without_render` array in `cookiecutter.json` and source all
   per-project values from CI secrets (so the workflow needs no
   substitution). Cleaner than scattering `{% raw %}` blocks.
3. **Worker secret hygiene.** `TURNSTILE_SECRET_KEY` and
   `RESEND_API_KEY` are pushed via the official `cloudflare/wrangler-action@v3`'s
   `secrets:` input on each deploy; the public Turnstile *site* key
   is intentionally in `wrangler.toml [vars]`. The CLAUDE.md spells
   out the closed-box rule.

**Close-out (2026-05-11).**

- [x] Push `mgf_website_template/` to `codeberg.org/magogi-admin/mgf-website-template`. Root commit landed 2026-05-10 (`8c9b456`).
- [x] Generate the Magogi-foundation site from the template; commit `14e17d8` on `codeberg.org/magogi-admin/magogi-foundation` (2026-05-11). Smoke test passes: `npm install` (361 packages) → `npm run check` (13 files / 0 errors / 0 warnings / 0 hints) → `npm run build` (4 pages + sitemap-index.xml).
- [x] No friction surfaced during generation. The template's cookiecutter inputs handle Magogi defaults cleanly (project_name → slug → contact_email → infomaniak_remote_path all derive sensibly from `domain="magogi.org"`).

**Out of scope for the paper close-out** (consumer-side ops work, not template/library work — friction in any of these would file as a new paper, not reopen this one):

- Wiring the eight CI secrets in the foundation-site Codeberg repo (`INFOMANIAK_SSH_KEY/HOST/USER/PATH`, `CLOUDFLARE_API_TOKEN/ACCOUNT_ID`, `TURNSTILE_SECRET_KEY/SITE_KEY`, `RESEND_API_KEY`, `CONTACT_FORM_ENDPOINT`).
- DNS A-record for `magogi.org` → Infomaniak Web Hosting target.
- Replacing placeholder body text + sample products with real Magogi content.
- First deploy (CI workflow runs on push to `main` once secrets are in place); end-to-end round-trip verification of the contact form (Turnstile + Resend).

**Retrospective (closing).** The template held up under its first real use. The cookiecutter input shape produced reasonable defaults from a single domain choice (`magogi.org`); no friction surfaced that warranted a template patch or a follow-up paper. The mgf-website-template repo gets to stay at v0.1 / unreleased — no tag, no PyPI (non-Python by design). Future Magogi marketing sites (product landing pages, sub-org sites) generate from the same template; if any of them surface friction, they file new papers.

This was also the first end-to-end exercise of ASPIRE-05 (cross-language standards travel via URL reference): the generated `docs/CLAUDE.md` cites mgf-common's standards by https URL without mgf-common ever being installed. That path now has a concrete consumer.

---

## §3. Multi-tenancy decision (design rationale)

The hardest unresolved design question, captured here in full so
the trade-offs survive even if the related entries above don't.

**Option A — "One app per process, explicit."**
- Pro: simple, fast (no contextvar lookup), matches 95% of real use.
- Con: forecloses on library-in-library architectures forever.

**Option B — Per-consumer `AppContext` (full contextvar).**
- Pro: supports every use case.
- Con: every observability function pays a contextvar lookup;
  surface-area doubles (every API needs a sibling that takes a
  context arg).

**Option C — Hybrid (the shipped shape).**
- Module-level globals for the default; `AppContext` as opt-in
  override. Observability resolves via the active context if any,
  else the global.
- Pro: zero overhead for the 95% case; extension available for
  the 5%.
- Con: two paths to reason about (acceptable: the second path is
  documented as a power-user escape hatch).

The Option C shape is what `mgf.common.bootstrap()` +
`AppContext` currently implement. PEP 567 contextvar semantics
give correct async-task isolation + thread isolation without
per-call plumbing. The `current_context()` fast path is a
single ContextVar.get() call (~30 ns).

---

## §4. Reviewer's meta-feedback

Unvarnished personal view from the maintainer + co-design partner.
Take or leave. No frontmatter — these aren't actionable items,
they're trajectory observations.

1. **`mgf-common` is more ambitious than its size suggests.**
   Small today; ambition (industry-standard Python infrastructure
   library) is enormous. Every decision should be made with
   "what would I do if this had 100 consumers" in mind.

2. **The reference-consumer model is a double-edged sword.**
   A co-designed reference consumer gives `mgf-common` a starting
   advantage but biases every decision toward "this works for
   <that consumer>". A second consumer's audit will surface
   assumptions the first can't see. **Recommendation:** even a
   single-file utility that uses `mgf.common.config` only would
   surface assumptions; recruit one early.

3. **The standards docs are heroic and 100% aimed at humans.**
   The "Rules box" pattern is great. But industry-standard also
   means machine-readable: the MUST/SHOULD/MAY set should be
   extractable as a JSON schema so a consumer's CI can run
   `mgf-common-lint` for a structured pass/fail report.

4. **The release flow is a latent risk.** Manual `uv publish`
   from a token file works fine for now. For an industry-standard
   library, plan the path to GPG-signed releases + SLSA provenance
   + a release branch requiring second-maintainer sign-off. Not
   urgent, but plan.

5. **The "cornerstone rhythm" — one shared library + many
   consumers — is the highest-leverage pattern in the project.**
   It captures something most libraries never articulate. Real
   audience is library AUTHORS, not consumers. Consider a separate
   `docs/for-library-authors/` track or a blog post to bootstrap
   the community.

---

## §5. How consumers submit feedback

Any project that depends on `mgf-common` — co-developed sibling,
external adopter, internal team project, hobby user — uses this
file to surface concerns. The submission flow is the same
regardless of relationship to the maintainers.

### Quick-start

```bash
# In a project that has mgf-common installed:
mgf-common feedback              # how to submit + severity guide
mgf-common feedback --template   # the entry template, ready to paste
mgf-common feedback --url        # this file's URL on codeberg
```

### Submission steps

1. **Read §1.4 (entry template) + §1.2 (severity).** The
   uniform shape is what makes the document machine-actionable.
   Don't deviate — the audit trail depends on it.
2. **Pick a fresh ID.** Format `<AREA>-<NN>` where `AREA` is a
   capitalised domain prefix (e.g., `API`, `HTTP`, `DB`,
   `CONFIG`, `SEC`, `TEST`, `VAULT`, `SSH`) and `NN` is a
   2-digit sequence within that area.
3. **Add the entry under §2** (open feedback). §2 is for "this
   is wrong / missing / painful." Roadmap-shaped requests —
   "this whole module would be useful" — also live in §2;
   severity tells you how urgent.
4. **Open a PR.** Two paths depending on access:
   - **Co-developer / sibling-project author**: PR directly
     against `mgf-common`'s `master`.
   - **External consumer (no PR access yet)**: open the
     codeberg PR from a fork. If you can't fork or PR
     (corporate firewall, etc.), open an issue at
     `https://codeberg.org/magogi-admin/mgf_common/issues` with
     "FEEDBACK:" prefix and paste the entry — a maintainer will
     mirror it into FEEDBACK.md and reference your issue.
5. **Triage** happens in the PR thread. The decision (accepted
   / rejected / deferred / scheduled) lands in the entry's
   `Decision` field. The maintainer drives this; submitters
   don't need to push.
6. **When shipped**, the entry's status changes to SHIPPED with
   a one-line retrospective on what was implemented + any
   shape changes. The CHANGELOG carries the full release-level
   detail.
7. **Rejected entries stay in the file** with rationale —
   recording "we considered this and said no, because…" is
   higher-leverage than recording only what shipped.

### What makes a great submission

- **Specific call site or example.** "I tried `MgfSettings(...)`
  with `extra_keys=['foo']` and got a confusing error" beats
  "settings are awkward."
- **Severity self-assessment.** Be honest. A 🔴 means "if we
  lock the API with this, fixing it is breaking later." Most
  things are 🟡 or 🟢; reserve 🔴 for genuine API-shape
  concerns.
- **Suggested shape, even if rough.** A wrong starting point is
  more useful than no starting point. The maintainer can refine.
- **One concern per entry.** Don't bundle. If you have three
  separate sharp edges, file three entries — they'll be triaged
  on different cadences.

### Don't worry about

- **Whether your concern is "important enough."** File it. The
  triage will sort severity. False-negative (concern missed) is
  more expensive than false-positive (entry triaged + closed
  quickly).
- **Whether the maintainer will be annoyed.** This file IS the
  design conversation.
- **Picking the perfect ID.** Maintainers will renumber if
  there's a clash. Get the entry in.

---

## §6. Cross-references

- Engineering standards: [`docs/standards/`](docs/standards/) (8 topic docs).
- Public-API contract: [`PUBLIC_API.md`](PUBLIC_API.md) (the AP-10 contract).
- Vulnerability-reporting policy: [`SECURITY.md`](SECURITY.md) (the SC-12 contract).
- Maintainer's dense-lookup doc: [`docs/claude/CLAUDE.md`](docs/claude/CLAUDE.md).
- Onboarding entry point: [`STARTHERE.md`](STARTHERE.md).
