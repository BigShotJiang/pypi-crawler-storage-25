# Changelog

All notable changes to `mgf-common` are documented here.

The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/);
the project follows [SemVer](https://semver.org/spec/v2.0.0.html). Per
the 0.x window ([SemVer 0.x](https://semver.org/#spec-item-4) and rule
**AP-03**), MINOR releases MAY break the public API. Pin tightly:

```toml
mgf-common = ">=0.X.0,<0.Y"   # one minor at a time
```

Each release section cross-references the [`FEEDBACK.md`](FEEDBACK.md)
entry and (where applicable) the consumer-side migration recipe. The
release-engineering discipline that produces this changelog is in
[`docs/standards/RELEASING.md`](docs/standards/RELEASING.md).

---

## [Unreleased]

(no entries)

---

## [0.38.0] — 2026-05-18

**Federation contract — the canonical adoption page.** No source-code
changes to the cornerstone library surface; this MINOR is documentation
infrastructure + one new tooling check. Drop-in upgrade from 0.37.0.

### Added

- **`FEDERATION.md`** at repo root (DOC-17, standards v2.10) — the
  single canonical contract every consumer + sibling reads to align
  with the federation. Ten sections covering: what the foundation is,
  what depending on mgf-common commits you to, required docs layout,
  L1/L2/L3 conformance levels, federation-first principle (use mgf-*
  before reaching for alternatives), catch-up cadence, feedback
  discipline, onboarding flows, and a one-screen cheat sheet.
  Authoritative copy lives only here; siblings + consumers link to it.

- **`USERS.md`** at repo root (DOC-16, standards v2.9) — answers
  "who depends on mgf-common?" Lists four consumer projects with
  import-site counts + every federation sibling.

- **DOC-16 standard** (v2.9) — formalises the per-sibling `USERS.md`
  user-roll requirement; inverse of DOC-14 (consumer-side
  `MGF_ADOPTION.md`).

- **DOC-17 standard** (v2.10) — formalises `FEDERATION.md` as the
  canonical contract; siblings + consumers MUST NOT maintain their
  own copy; drift between the file and the rule set is a defect.

- **`mgf-common catch-up` contract enforcement** — new
  `_check_federation_contract` audit step verifies every required
  artifact: universal-5, DOC-15 conformance tracker (everyone),
  DOC-14 adoption tracker (consumers only — ADP-04 carve-out),
  DOC-16 USERS.md (siblings only — detected by `mgf-` / `mgf_`
  package name prefix). Missing required artifacts cause non-zero
  exit so the audit can gate CI. Accepts `MGF_COMMON_ADOPTION.md`
  legacy alias and `LICENSE.md` / `LICENSE.txt` variants. **9 new
  unit tests.**

### Changed

- **`docs/standards/DOCUMENTATION.md`** bumped from v2.8 to v2.10 in
  two steps (DOC-16 + DOC-17). No existing rules modified.
- **README.md** + **STARTHERE.md** carry callouts pointing at
  FEDERATION.md as the canonical contract.

### Federation rollout (companion commits in sibling repos)

Every `mgf-*` sibling ships a repo-local `USERS.md` grounded in a
fresh grep import-site survey. Six code-siblings additionally gained
`STARTHERE.md` + `CONTRIBUTING.md` (DOC-01 sibling MUSTs). The new
`mgf-usb` (v0.0.0 design-lock scaffold) was registered in mgf-common's
USERS.md §2 + FEDERATION.md §5 federation-first table.

### Wave-4 maintainer review docs

Three docs land in `docs/inprogress/` to set up the v1.0 maintainer
review (NO v1.0 cut performed): `v1_0_stability_audit.md`,
`v1_0_quality_gates.md`, `v1_0_handoff.md`. Three blockers identified
for v1.0: Q-2 (N818 rename decision), Q-4 (PyPI backlog drain), Q-11
(promotion sign-off).

### Federation test sweep (release verification)

1596 passed, 0 failed (1587 from 0.37.0 baseline + 9 new tests).
No regressions; no API breakage; no public name removed.

### Pin recommendation

```toml
mgf-common = ">=0.38.0,<0.39"
```

---

## [0.37.0] — 2026-05-18

PyPI: <https://pypi.org/project/mgf-common/0.37.0/> · Tag: `v0.37.0`

> **Wave 3 — second-tier federation primitives.** Four new
> modules ship as a single MINOR. All `experimental` tier per
> AP-11. Drop-in upgrade from 0.36.0 — purely additive.

### Added — `mgf.common.rate_limit` (C-2)

Wave 3 formalisation of the TokenBucket shape that
mgf-fastapi 0.6.0 + mgf-django 0.4.0 both ship locally. Both
siblings rebase on this module in their next minor.

Two public names: **`Bucket`** (Protocol), **`TokenBucket`**
(stdlib-only in-process implementation). Future
Redis-backed impls satisfy the Protocol for multi-replica
deployments. 10 unit tests pin algorithmic correctness +
per-key isolation + reset ergonomics + Protocol conformance.

### Added — `mgf.common.idempotency` (C-3)

The retry-safe POST primitive. Closes the "double-charged
retry" footgun class. Pairs with future middleware in
mgf-fastapi v0.7+ + mgf-django v0.5+.

Four public names: **`IdempotencyStore`** (Protocol),
**`IdempotencyRecord`** (frozen dataclass — get-return shape),
**`InMemoryIdempotencyStore`** (default backend, 24h TTL per
Stripe convention), **`IdempotencyKeyConflictError`** (raised on
same-key-different-body — Stripe convention). 11 unit tests
cover hit / miss / overwrite / TTL eviction / conflict
detection / lifecycle.

### Added — `mgf.common.health` (C-4)

Liveness + readiness + aggregation. Standardises the shape
every web consumer hand-rolls; framework siblings wire the
routes (mgf-fastapi `HealthRouter` v0.7+; mgf-django
`health_view` v0.5+).

Seven public names: **`HealthStatus`** literal,
**`ComponentCheck`** Protocol, **`ComponentResult`** frozen
dataclass, **`LivenessCheck`** + **`ReadinessCheck`** subclass
markers (for `/healthz` vs `/readyz` routing), **`HealthReport`**
+ **`HealthRegistry`**. Worst-case aggregation
(`unhealthy` ≻ `degraded` ≻ `ok`). Auto-populates latency.
Catches per-check exceptions + reports as `unhealthy`. 17 unit
tests pin Protocol conformance, aggregation rules,
liveness/readiness routing, exception-as-unhealthy, JSON shape.

### Added — `mgf.common.cache` (C-5)

Five-method Cache Protocol + stdlib-only LRU+TTL default +
NullCache. Lets consumers start on the in-process default and
swap to Redis later without touching call sites.

Four public names: **`Cache`** (Protocol),
**`CacheMiss`** sentinel (distinguishable from cached
`None`; falsy under `bool()`), **`LRUCache`** (thread-safe
`OrderedDict`-backed; per-entry or default TTL; lazy eviction
on access), **`NullCache`** (no-op — disable caching toggle).
19 unit tests pin basic CRUD, LRU eviction order, TTL
expiry, per-set-overrides-default, no-TTL-no-expiry,
get-bumps-to-MRU, Protocol conformance, CacheMiss sentinel
semantics.

### Notes for consumers

- **Drop-in upgrade from 0.36.0** — purely additive
  (`experimental` tier).
- **Sibling rebase**: mgf-fastapi + mgf-django will adopt
  `mgf.common.rate_limit.TokenBucket` in their next MINOR
  (replacing the sibling-local duplicate). Middleware shells
  stay framework-specific.
- **Multi-replica deployments**: Redis-backed implementations
  of `Bucket` + `IdempotencyStore` + `Cache` ship under each
  consumer's own tree (or as a future `mgf-common-redis`
  sibling). The Protocol surface is the contract.

### Verification

- pytest tests/: 1587 passed (1530 from 0.36.0 + 57 new
  across the four modules).
- mypy --strict: clean on all new modules.
- ruff: clean.

---

## [0.36.0] — 2026-05-18

PyPI: <https://pypi.org/project/mgf-common/0.36.0/> · Tag: `v0.36.0`

> **Wave 1 completion** — two more experimental-tier modules
> ship: plugin auto-discovery (closes PAPER-10, deferred since
> April 2026) and the doctor-bundle primitive (promotes the
> existing `mgf-common doctor` CLI command's logic into a
> reusable scaffold for VManager + iosRecovery).

### Added — `mgf.common.plugins` (C-NEW-2 / PAPER-10 closure)

The federation finally has the 2nd-consumer evidence needed to
ship plugin auto-discovery: PlasmaMapper's `TelematicsProvider`
plugin shape (Teltonika first; Queclink + Ruptela queued for
Phase 8). Federation rule: 2-consumer signal = primitive.

Three public names (all `experimental` tier):

- **`PluginRecord(name, obj, distribution, version)`** — frozen
  dataclass for a successfully-loaded plugin entry.
- **`PluginRejection(name, distribution, reason, detail)`** —
  frozen dataclass for an entry that was found but NOT loaded
  (load failure OR non-conformant). Only surfaces with
  `return_rejections=True`.
- **`discover(group, *, required=None, return_rejections=False)`** —
  wraps `importlib.metadata.entry_points` with Protocol filtering
  + audit emission. Load failures + non-conformant entries are
  SKIPPED with WARN logs (`event="mgf.plugin_rejected"`); one
  bad plugin can't crash the host startup (closed-box
  discipline). Audit-emission per call
  (`event="mgf.plugin_discovery"`, `audit=True`).

9 new unit tests pin the contract (happy paths, load failures,
non-conformance, audit emission).

### Added — `mgf.common.doctor` (C-NEW-3 / doctor-bundle primitive)

Promotes the existing `mgf-common doctor` CLI command's report-
rendering logic into a reusable primitive. Two-consumer pattern
(VManager `doctor bundle` + iosRecovery planned `figrecovery
doctor bundle`). Text + JSON renderers; atomic 0o600 file write
per SC-13.

Three public names (all `experimental` tier):

- **`ReportStatus`** — `Literal["ok", "warn", "fail"]`. The
  section-status taxonomy. JSON-stable.
- **`ReportSection(name, status, details={})`** — frozen
  dataclass — one section. `details` is `Mapping[str, Any]`;
  sensitive values MUST be pre-redacted (the bundle does NOT
  scrub automatically — that would mask consumer bugs).
- **`DoctorBundle(app_name, app_version, when=now)`** —
  composable bundle. `add_section(section)` appends or replaces
  by name. `overall_status` aggregates worst. `render_text()`
  for human report; `render_json()` for SIEM ingest;
  `write_to(path, *, format="text"|"json")` atomic-write with
  0o600 mode.

18 new unit tests pin the contract (composition + idempotent
add + status aggregation + text render + JSON render + 0o600
write + atomic overwrite + missing-parent rejection + unknown-
format rejection).

### Notes for consumers

- **Drop-in upgrade from 0.35.0** — both modules are purely
  additive (`experimental` tier per AP-11).
- **PlasmaMapper**: ready to adopt `mgf.common.plugins` for
  `TelematicsProvider` discovery (replaces ~30 LOC of
  hand-rolled entry-point loop).
- **VManager + iosRecovery**: can wire `DoctorBundle` for
  their doctor-bundle outputs.

### Verification

- pytest tests/: 1530 passed (1503 from 0.35.0 + 27 new).
- mypy --strict: clean on new modules.
- ruff: clean.

---

## [0.35.0] — 2026-05-18

PyPI: <https://pypi.org/project/mgf-common/0.35.0/> · Tag: `v0.35.0`

> **Wave 1 federation primitives + v2.8 standards bump + two
> closed inthewords-filed papers.** Two new modules ship at
> `experimental` tier (AP-11), plus the v2.8 standards-discipline
> rollout, plus PAPER-43 / PAPER-44 closures from inthewords'
> catch-up walk. Drop-in upgrade — no public API removals or
> renames.

### Added — `mgf.common.flags` (C-1 feature-flag primitive)

The federation-wide standardisation of the env-var-feature-gate
pattern every consumer was rolling its own version of (see
`docs/inprogress/pre_release_additions.md` §5, C-1 row —
universal-need; replaces ~80 LOC per consumer).

Six public names (all `experimental` tier):

- **`FeatureFlag`** — `@runtime_checkable` Protocol. One method:
  `is_enabled(name, *, default, context)`. Backends wire it.
- **`EnvVarFlags()`** — default backend. Reads
  `MGF_FLAG_<UPPER_NAME>` env vars per call (always-fresh).
  Truthy values: `1` / `true` / `yes` / `on` / `enabled`. Falsy:
  `0` / `false` / `no` / `off` / `disabled` / empty. Invalid
  values WARN + return the call-site default (deny-by-default).
- **`StaticFlags(initial=None)`** — in-memory backend for tests.
  `.set(name, value)` / `.unset(name)` for fixture ergonomics.
- **`configure_flags(impl)`** — install a backend process-wide.
  Emits structured INFO with `event="mgf.flag_backend_configured"`
  + `audit=True` per LG-04 + SC-17.
- **`get_flags()`** — return the installed backend (test
  fixture convenience).
- **`is_enabled(name, *, default, context)`** — module-level
  convenience. Delegates to the installed backend. Hot-path
  cheap; does NOT audit per-call.

34 new unit tests pin the contract.

### Added — `mgf.common.schedule` (C-NEW-1 scheduler protocol)

The federation-wide standardisation of cron-shape input that
three real consumers (VManager `croniter`, iosRecovery systemd
timer, PlasmaMapper `arq` cron) each handle differently. Three-
consumer signal — the strongest evidence the federation has
collected for any single primitive. **Stdlib-only by design**.

Five public names (all `experimental` tier):

- **`CronExpression`** + **`CronExpression.parse(expr)`** — full
  POSIX-cron 5-field parser + the canonical aliases (`@yearly` /
  `@monthly` / `@weekly` / `@daily` / `@midnight` / `@hourly`).
  Supports `*`, `N`, `N-M`, `*/N`, `N-M/N`, comma-lists. Frozen
  dataclass; safe to share across threads. Does NOT support
  `L` / `W` / `#` / day-name / month-name aliases (deferred to
  v1.1+ if a consumer needs them).
- **`CronExpression.matches(ts)`** + **`CronExpression.next_fire(*, after)`** —
  membership + iteration helpers. Both require tz-aware
  datetimes (per DP-12).
- **`Scheduler`** — `@runtime_checkable` Protocol with `schedule`
  + `tick` methods. Backends decide the execution model.
- **`ScheduledTask`** — frozen dataclass returned by `schedule`.
- **`InProcessScheduler()`** — tick-driven default. Idempotent
  registration (re-scheduling same `name` replaces). Catches
  exceptions in fired tasks (logs with
  `event="mgf.schedule.task_raised"`; never raises out of
  `tick`). Sub-minute tick-calls safe — each task fires at
  most once per minute. NOT suitable for multi-replica without
  an external lock.

49 new unit tests pin the parser + scheduler contract.

### Added — standards v2.8 (DOC-13 + DOC-14 + DOC-15 bundles)

Full details in
[`docs/inprogress/V2_8_NOTIFICATION.md`](docs/inprogress/V2_8_NOTIFICATION.md).

- **DOC-01 amended**: `FEEDBACK.md` becomes the universal-five
  root doc. Every project ships its own — no inheritance
  escape.
- **DOC-13 + FB-01..FB-04** — FEEDBACK discipline. Repo-scoped;
  local-per-repo PAPER-NN numbering; mandatory metadata fields.
- **DOC-14 + ADP-01..ADP-04** — adoption-tracker discipline.
  Every consumer MUST maintain `MGF_ADOPTION.md`. Federation
  siblings exempt per ADP-04.
- **DOC-15 + CFM-01..CFM-04** — conformance-tracker discipline.
  Every project that adopts standards (consumer OR sibling)
  MUST maintain `MGF_STANDARDS_CONFORMANCE.md`. Declared
  level (L1 / L2 / L3 per CFM-02). Per-rule status markers
  per CFM-03. Decline-with-rationale per CFM-04.

Three new fork-and-fill templates in `docs/recipes/`:
`feedback-md-template.md`, `mgf-adoption-md-template.md`,
`mgf-standards-conformance-md-template.md`.

### Added — `mgf-common catch-up` auto-block extended

The `_init_project.py` template's "Reporting feedback" section
renamed to "Federation-discipline reminders" and split into
THREE explicit BEGIN/END marker pairs (one per discipline):

- `<!-- BEGIN mgf-common: feedback-discipline -->`
- `<!-- BEGIN mgf-common: adoption-discipline -->`
- `<!-- BEGIN mgf-common: conformance-discipline -->`

Consumers receive these on their next `mgf-common catch-up --apply`
run. AI agents in consumer sessions see all three on every
session start. New test
`test_v28_three_discipline_blocks_present` pins all six
markers + the rule cross-references + the template paths.

### Changed — `mgf-common catch-up --apply` auto-cleans `.bak.<timestamp>` files on verified success

Closes [PAPER-44](FEEDBACK.md) filed by inthewords during its
mgf-common v0.31 → v0.32 catch-up walk.

`--apply` writes a `<file>.bak.<unix-timestamp>` next to each
rewritten file as a safety net. The previous behaviour was to
leave those backups in place and print a "check the .bak.*
backups if anything looks wrong" hint — but on a happy-path
run the safety net never served its purpose, and consumers
running `git add -A` after a catch-up bump risked accidentally
committing the backup files.

New behaviour: after the apply loop completes, the catch-up
runner re-executes the six audit checks. If the re-audit
reports no remaining mechanical findings, the `.bak.<timestamp>`
files written by THIS run are deleted (pre-existing backups
with the same shape are left untouched — only the diff is
swept). If the re-audit still has fixable findings, the
backups are retained with their paths printed for inspection.

Either way, a `.gitignore` tip prints recommending
`**/*.bak.[0-9]*` so future catch-up backups can't be
accidentally committed even on the retain path.

3 new unit tests in `tests/unit/cli/test_catch_up.py`:
`test_apply_refreshes_claude_md_and_auto_cleans_backup` (the
auto-clean happy path), `test_apply_does_not_clean_pre_existing_backups`
(diff-based cleanup must not touch pre-existing backups from
older catch-up runs or other tools). One existing test
(`test_apply_creates_backup_for_refreshed_claude_md`) renamed
+ assertion inverted to reflect the new behaviour; its
underlying invariant (the rewrite happens) is preserved.

---

### Fixed — `mgf-common migrate` v0.32 → v0.33 codemod registration

Closes [PAPER-43](FEEDBACK.md) filed by inthewords during its
v0.32 → v0.33 catch-up walk.

The v0.33.0 cutover guide
(`docs/cutover/archive/v0.33.0.md`) documents `mgf-common migrate`
as the codemod path for the two AP-12 deprecation removals
(`EnvironmentError` → `HostEnvironmentError`,
`make_settings_config` → `settings_config`). The rules existed in
`src/mgf/common/cli/_migrate.py` as `_RULES_0_1_TO_0_3` —
identifier-anchored renames that don't care which release cycle
removed the alias — but the version-pair dispatch table only
registered `("0.1", "0.3")`. A consumer running
`mgf-common migrate 0.32 0.33 .` got `✗ unsupported migration`
and fell back to a manual grep + edit pass.

Fix: register `("0.32", "0.33")` in `_MIGRATIONS` pointing at
the same rules tuple. The codemod is idempotent — a consumer
who ran the v0.1 → v0.3 codemod historically sees a no-op on
re-run for v0.32 → v0.33; a consumer catching up directly from
pre-v0.3 to v0.33+ gets the renames applied for the first time.

Five new tests in `tests/unit/test_phase7_migrate.py` under
`TestPaper43V032ToV033Migration` (rename on the new pair,
idempotency after v0.1 → v0.3, dry-run threading, per-rule
import-gate semantics, plus a strengthened existing test
asserting both pairs appear in the "Supported migrations:"
listing).

### Changed — FEEDBACK.md cleanup

Six misfiled inthewords-filed papers (PAPER-36, 37, 39, 40, 41,
42) replaced with redirect stubs; full content moved to
mgf-http + mgf-apiprobe FEEDBACK files with local-per-repo
renumbering. See v2.8 standards bump for the structural rule
(DOC-13) that prevents the next misfile.

### Notes for consumers

- **Existing consumers (VManager, PlasmaMapper, inthewords,
  iosRecovery)**: receive the v2.8 auto-block on next
  `mgf-common catch-up --apply` run. If you don't have
  `MGF_ADOPTION.md` + `MGF_STANDARDS_CONFORMANCE.md` yet,
  create from the new templates in `docs/recipes/`.
- **Sibling pin bump**: existing siblings still on
  `mgf-common>=0.34,<0.35` need to widen to `>=0.35,<0.36` in
  their next release. Transitive consumer impact is zero —
  v0.35.0 is purely additive (new module names; no
  behavioural changes to existing surface).

### Verification

- pytest tests/: 1505+ passed (1413 from 0.34.0 + 34 flags +
  49 schedule + 7 misc new tests + the catch-up + migrate
  PAPER-43/44 closures).
- mypy --strict: clean on new modules.
- ruff: clean.

---

## [0.34.0] — 2026-05-17

PyPI: <https://pypi.org/project/mgf-common/0.34.0/> · Tag: `v0.34.0`

> **Internal-only release.** No public API additions / removals /
> renames since 0.33.0. Consumers can upgrade without code changes;
> the existing `mgf-common>=0.33,<0.34` pin in sibling pyprojects
> should be widened to `>=0.34,<0.35` (the sibling-pin update ships
> in each sibling's next release).

### Added — regression-protection tests

P1 perf gates (close the "fast-on-paper, slow-in-prod" risk class):

- **PC-02** — sustained-throughput gate
  (`tests/unit/test_sustained_throughput.py`). 50 000 paced records
  through `AsyncJsonHandler` over ~5 s asserts zero drops, drain-
  completion < 1 s, RSS growth < 5 MB.
- **PC-03** — `Redactor` large-payload scaling (3 new tests in
  `test_perf_pins.py`'s `TestRedactorPerf`). Pins linear scaling in
  dict size + string length; catches O(n²) regressions.
- **PC-04** — `report_now()` end-to-end latency
  (`test_crash_reporter.py`). Median < 10 ms / p99 < 25 ms across
  100 calls with realistic cause chain.
- **PC-05** — bootstrapped-process memory baseline
  (`tests/unit/test_memory_footprint.py`). Subprocess RSS after
  `bootstrap` + 10 000 log records + 10 `report_now()` < 80 MB.

P2 perf + security gates:

- **PC-07** — `operation_span` no-op cost pin (~1-2 µs; budget 10 µs).
- **PC-09** — PBKDF2 iteration **floor** test. Asserts
  `_DEFAULT_KDF_ITERATIONS >= 600_000` (OWASP 2023 baseline / SC-05)
  AND the first vault `set()` with default iterations takes ≥ 50 ms.
  A fast KDF is the suspicious signal here.
- **PC-10** — `AsyncJsonHandler.emit` perf pin + **ratio** gate.
  Absolute < 18 µs; async/sync ratio < 0.5 (catches the
  regress-together case the absolute budget can mask).

### Changed — internal-only

- **Standards v2.6** — project-shape taxonomy added to
  `docs/standards/DOCUMENTATION.md` (DOC-01 / §2.0). `LICENSE` is
  now a MUST in the universal-four root docs. Federation siblings
  declare their shape in README (rolled out across all 7 siblings
  in their respective v0.x.y release cycles).
- **Standards v2.7** — new
  [`docs/standards/DEPLOYMENT.md`](docs/standards/DEPLOYMENT.md)
  (DEP-01..DEP-11). Applies to stateful web-service consumers
  (NOT to federation siblings, which ship to PyPI). Cloud-agnostic;
  Infomaniak is the foundation's reference platform.
- **Closed-by-docs:** RA-19 + RA-21 (lifecycle / span-processor
  documentation).
- **Internal cleanup:** removed VManager / PlasmaMapper project-name
  leakage across all 14 standards documents. Standards now read
  generically; per-consumer cross-references live in
  `docs/cutover/<version>.md` and `docs/reference-consumers/`.
- **STANDARDS_AUDIT trackers archived** under `docs/archive/2026/`
  per **DOC-11** (the audit closed clean; archive instead of leaving
  closed-out trackers in `docs/inprogress/`).

### Fixed

- Four feedback papers from the PlasmaMapper audit pass
  (PAPER-31..34); shipped as standards / docs refinements with no
  consumer-visible code change.

### Notes for consumers

- **Sibling pin bump:** the existing `mgf-common>=0.33,<0.34` pin
  must move to `>=0.34,<0.35`. Each sibling will ship that pin
  update shortly after this release.
- **No codemod needed** — no public-API renames or removals.
- **`mgf-common migrate`** is unchanged.

---

## [0.33.0] — 2026-05-11

PyPI: <https://pypi.org/project/mgf-common/0.33.0/> · Tag: `v0.33.0`

> **Breaking minor — AP-12 deprecation removals.** Three deprecated
> aliases reach end-of-cycle and are removed. Each had at least one
> MINOR release with `MgfDeprecationWarning` per rule AP-12; consumers
> who heeded the warnings need no code changes. The companion
> `mgf-common migrate` codemod still applies the safe renames for
> consumers catching up.

### Removed (breaking)

- **`mgf.common.configure(app_name, app_version)`** — superseded by
  `mgf.common.bootstrap(app_name=..., app_version=...)`, which wires
  identity + logging + OTel + crash hooks transactionally with LIFO
  rollback. `configure()` only set identity, leaving the consumer to
  call `setup_logging` / `setup_otel` / `install_excepthook` manually.
  Tests and scripts that just need identity isolation may use the
  internal `mgf.common._identity._set_identity(...)` helper, or
  prefer `mgf.common.bootstrap_for_test(...)`.
- **`mgf.common.config.make_settings_config(...)`** — renamed to
  `mgf.common.config.settings_config(...)`. Pure rename; same return
  type, same behaviour. Codemod rule `make_settings_config →
  settings_config` ships in `mgf-common migrate` for mechanical
  fixes.
- **`mgf.common.exceptions.EnvironmentError`** — the deprecated
  alias that shadowed Python's built-in `EnvironmentError` (= `OSError`)
  is removed. Use `mgf.common.exceptions.HostEnvironmentError` for
  host pre-flight failures. Codemod rule `EnvironmentError →
  HostEnvironmentError` (gated on `mgf.common.exceptions` import)
  ships in `mgf-common migrate`.

### Migration

- Most consumers: run `mgf-common migrate` from the project root.
  The codemod handles the two pure renames mechanically. `configure()`
  → `bootstrap()` is NOT codemodded — it benefits from human review
  per case (rule §1 of `docs/MIGRATION_0.1_TO_0.3.md`).
- See [`docs/cutover/v0.33.0.md`](docs/cutover/v0.33.0.md) for the
  worked migration recipe.

### Internals

- Examples under `examples/` updated to the `bootstrap()` shape so
  every layered demo reflects the post-removal canonical surface.
- Test suite reshaped: tests that need only identity isolation now
  call the private `_set_identity()` helper; tests that exercise
  the full wiring stack use `bootstrap_for_test()`.

---

## [0.32.3] — 2026-05-11

PyPI: <https://pypi.org/project/mgf-common/0.32.3/> · Tag: `v0.32.3`

> **Doc-only patch release — omnibus stable walk.** Fifth and largest
> experimental → stable walk in the v0.32+ chapter, covering the
> remaining submodule surfaces with multi-cycle / multi-consumer
> evidence (observability, process, progress, vault, versioned, cli,
> typing, providers) plus a re-evaluation of two v0.32.2-held items.
> 69 names promoted. No runtime change.

### Public-API stability tiers — fifth walk

**By module:**

| Module | Names promoted |
|---|---|
| `mgf.common.exceptions` (process-launch + held re-evaluation) | `ProcessError`, `ProcessTimeout`, `ProcessNonZeroExit`, `ProcessSignaled`, `ServiceNotReady`, `GuestUnreachableError`, `GuestCommandError` (7) |
| `mgf.common.settings` (held re-evaluation) | `VaultSettings` (1) |
| `mgf.common.observability` | `setup_logging`, `setup_otel`, `operation_span`, `report_now`, `install_excepthook`, `install_threading_excepthook`, `Redactor`, `DEFAULT_REDACTION_KEYS`, `LogFormat`, `default_log_path`, `default_crash_dir`, `default_state_dir`, `get_logger`, `JsonFormatter` (14) |
| `mgf.common.typing` | `CancellationProtocol`, `ReporterProtocol`, `LogSinkProtocol`, `VaultProtocol` (4) |
| `mgf.common.progress` | `CancellationToken`, `ProgressReporter`, `NullReporter`, `RecordingReporter` (4) |
| `mgf.common.progress.asyncio` | `AsyncCancellationToken` (1) |
| `mgf.common.vault` | `EnvVault`, `KeyringVault`, `EncryptedFileVault`, `EnvVaultConfig`, `KeyringVaultConfig`, `EncryptedFileVaultConfig` (6) |
| `mgf.common.versioned` | `VersionedFileStore`, `MigrateFn` (2) |
| `mgf.common.cli` | `EXIT_SUCCESS`, `EXIT_CONFIG_ERROR`, `EXIT_OPERATION_ERROR`, `EXIT_GUEST_ERROR`, `EXIT_ENVIRONMENT_ERROR`, `EXIT_PROVIDER_ERROR`, `EXIT_VAULT_ERROR`, `EXIT_UNKNOWN`, `run_and_translate`, `translate_exceptions`, `main_entry`, `field_provenance`, `env_vars_known_to_mgf`, `FieldSource`, `SourceKind` (15) |
| `mgf.common.process` | `run`, `ProcessResult`, `Service`, `Service.start/stop` (row), `Service.wait`, `Service.is_running/pid/returncode` (row), `ReadinessProbe`, `PortReady`, `HttpReady`, `LogLineReady`, `CallableReady`, `AllOf`, `AnyOf` (13) |
| `mgf.common.providers` | `ProviderABC`, `translate_at_seam` (2) |

**Total in this walk: 69 names** (the per-table arithmetic comes
to 69; PUBLIC_API.md's promoted-row count matches exactly).

### Criteria satisfied (per name)

- **observability** core (14): every consumer wires `bootstrap()`
  which calls into these; `setup_logging` / `setup_otel` /
  `report_now` / `Redactor` shape has been stable since v0.10ish.
  The default-path helpers (`default_log_path` /
  `default_crash_dir` / `default_state_dir`) closed PAPER-07 in
  v0.13.0 and have been unchanged since.
- **typing protocols** (4): all four are stable contracts
  consumers implement (VManager's GUI for `LogSinkProtocol`,
  every consumer's vault for `VaultProtocol`, every CLI for
  `CancellationProtocol`/`ReporterProtocol`).
- **progress** (5): `CancellationToken` + the reporter shape have
  been in use since v0.10; `AsyncCancellationToken` is the
  asyncio sibling; both have stable shape.
- **vault** (6): concrete backends + typed configs. Shape has
  been stable since the typed-config landing (which closed the
  config-leak per PAPER-12).
- **versioned** (2): `VersionedFileStore[T]` is used by VManager
  for every per-VM config file + by inthewords for hook specs;
  shape unchanged since v0.13.
- **cli** (15): exit codes are stable since v0.10 and the
  translator family + provenance helpers are equally settled.
- **process** (13): `run` / `Service` / `ReadinessProbe` family
  is VManager's bread-and-butter; the readiness probes
  (`PortReady`, `HttpReady`, `LogLineReady`, `CallableReady`,
  `AllOf`, `AnyOf`) have been shipping since v0.22.
- **providers** (2): `ProviderABC` + `translate_at_seam` is the
  DP-02 seam pattern documented in the standards docs; shape
  has been stable since v0.10.

### Re-evaluation of v0.32.2-held items

- **`GuestUnreachableError` + `GuestCommandError`**: held in v0.32.2
  because they're VManager-only at the moment. On reconsideration,
  the shape is stable (bare subclasses inheriting from
  `GuestError`), and any future Guest-shaped consumer would
  receive them at the right tier without a tier bump. Promoted.
- **`VaultSettings`**: held in v0.32.2 because the typed/untyped
  config split looked unfinished. On reconsideration, the
  field-wrapper itself (`backend: str` + `config: dict | typed`)
  is stable; what's still settling is the *typed-union variant*
  (`BuiltinVaultBackendConfig`) which stays experimental. The
  wrapper promotes; the typed union holds one more cycle.

### Explicitly NOT promoted (still held)

- **OpenTelemetry re-exports** (`Span`, `SpanContext`, `SpanKind`,
  `SpanStatus`, `StatusCode`) + the span-helper wrappers
  (`get_current_span`, `set_attribute`, `add_event`, `set_status`)
  — held as a coherent block; the re-export contract has its own
  questions (what happens if OTel SDK changes shape?). Walk together
  later.
- **Registry-based extension API** — `register_crash_sink` /
  `register_log_handler` / `register_span_processor` /
  `register_redaction_pattern_group` / `register_vault_backend` /
  `register_cli_subcommand` plus factory type aliases
  (`CrashSink`, `LogHandlerFactory`, `PatternGroupFactory`,
  `SpanProcessorFactory`, `VaultBackendFactory`) and
  `RedactionGroup` enum. Held: PAPER-10 (entry-point auto-discovery,
  currently DEFERRED) may reshape this surface.
- **Subcommand registry** (`register_cli_subcommand`, `subcommand`,
  `unregister_cli_subcommand`, `CliSubcommand`, `build_cli`,
  `dispatch`) — recent addition; held one more minor for evidence.
- **Generic registry primitive** (`Registry`, `make_registry`) —
  future-use only; held until a real internal use case migrates to it.
- **`BuiltinVaultBackendConfig`** — discriminated-union helper;
  paired with the typed-config promotion above but a half-step
  newer in shape.
- **`AsyncJsonHandler`** — recent addition; held one more minor for
  evidence.
- **`HostEnvironmentError`** — `EnvironmentError` deprecated alias
  still in play. AP-12 cycle finishes in v0.33.
- **`make_settings_config`** — already `deprecated` tier; removal
  scheduled for v0.33.
- **`configure`** — already `deprecated` tier; removal scheduled
  for v0.33.

### Promotion tally after v0.32.3

  v0.32.0:  12 names  (core foundation + 6 category bases)
  v0.32.1:  19 names  (HTTP-01 hierarchy + MgfSettings family)
  v0.32.2:  11 names  (concrete exception leaves + small helpers)
  v0.32.3:  69 names  (omnibus walk across remaining surfaces)
  -------
  Total:   111 stable / 97 experimental

The stable surface now exceeds the experimental surface — a
qualitative milestone in the v0.32+ stabilization chapter.
Remaining experimental falls into three buckets: extension API
(needs PAPER-10 resolution), OpenTelemetry re-exports (coherent
block), and recent additions (need one more minor of evidence).

### Federation note

mgf-common is in its v0.32+ stabilization window — no new public
surface, only tier flips. Patch number is now at v0.32.3; this is
the fifth doc-only patch in the chapter. v0.33 is the natural
landing for the AP-12 deprecation removals (`configure`,
`make_settings_config`, `EnvironmentError` alias) — that's a MINOR
release because the removals are breaking by semver.

---

## [0.32.2] — 2026-05-11

PyPI: <https://pypi.org/project/mgf-common/0.32.2/> · Tag: `v0.32.2`

> **Doc-only patch release.** Fourth experimental → stable walk:
> 11 names across the concrete-exception-leaves layer + two small
> helpers. No runtime change.

### Public-API stability tiers — fourth walk (11 names)

Continuing the v0.32+ stabilization-window walk. This pass moves
beyond the category bases (locked in v0.32.0/v0.32.1) into the
concrete leaves that consumers raise and catch directly.

**Promoted to `stable` (v0.32.2):**

| Module | Names |
|---|---|
| `mgf.common` | `UnconfiguredWarning`, `bootstrap_for_test`, `add_help_note` |
| `mgf.common.exceptions` | `SchemaValidationError`, `AppConfigError`, `AppConfigErrorKind`, `CommandError`, `ResourceNotFoundError`, `ResourceAlreadyExistsError`, `BootstrapError`, `CancellationError` |

Criteria:

- All eight concrete exception leaves have been raised by mgf-common
  itself for 12+ minor cycles. Consumer `except` clauses depend on
  them.
- `AppConfigErrorKind` is the StrEnum whose string values were
  pinned in PAPER-11 as machine-readable; locking the enum is the
  natural follow-on.
- `BootstrapError`'s `.failed_step` attribute is the transactional-
  bootstrap diagnostic contract — already documented in
  `docs/standards/ERROR_HANDLING.md`.
- `CancellationError` subclasses `OperationError` so existing
  category-catch clauses already handle it; the rename / addition
  shape has been stable through 10+ minor cycles.
- `UnconfiguredWarning` is the warning every test suite catches /
  asserts against when running tests without `bootstrap()`.
- `bootstrap_for_test` is in every consumer's test setup.
- `add_help_note` is a small PEP 678 helper with no shape questions.

### Explicitly NOT promoted (still held)

- `GuestUnreachableError` + `GuestCommandError` — concrete leaves
  in the `GuestError` category. Used heavily by VManager but no
  cross-consumer evidence yet (inthewords / PlasmaMapper don't
  raise them). The category base `GuestError` is stable (v0.32.0);
  the concretes can wait.
- `HostEnvironmentError` — still has the deprecated
  `EnvironmentError` alias in play. Wait one more minor per AP-12.
- `VaultSettings` + `BuiltinVaultBackendConfig` + the typed vault
  config union — still split between untyped `dict` and discriminated
  union; the consolidation isn't done.
- `register_crash_sink` / `register_log_handler` /
  `register_span_processor` / `register_redaction_pattern_group` +
  the `LogHandlerFactory` / `SpanProcessorFactory` type aliases —
  extension API still evolving; PAPER-10 (entry-point auto-discovery)
  is deferred and may reshape this.
- Everything in `mgf.common.cli`, `mgf.common.process`,
  `mgf.common.versioned`, `mgf.common.vault`, `mgf.common.progress`,
  `mgf.common.observability` — deserves dedicated walks once
  another minor cycle of evidence accumulates.

### Promotion tally after v0.32.2

  v0.32.0 promoted: 12 (core foundation + 6 category bases)
  v0.32.1 promoted: 19 (HTTP-01 hierarchy + MgfSettings family)
  v0.32.2 promoted: 11 (concrete exception leaves + 3 small helpers)
  --------
  Total stable:     42
  Remaining experimental: 166

### Federation note

mgf-common is in its v0.32+ stabilization window — no new public
surface, only tier flips. Three sequential patch releases (0.32.0,
0.32.1, 0.32.2) on the same day reflects the accumulated incubation
depth of the existing surface; the v0.32+ chapter is about closing
the gap between "could be stable" and "is stable" before v1.0 lock.

---

## [0.32.1] — 2026-05-11

PyPI: <https://pypi.org/project/mgf-common/0.32.1/> · Tag: `v0.32.1`

> **Doc-only patch release.** No runtime change. Two more stable-tier
> walks landed: the HTTP-01 web-exception hierarchy (12 names) and
> the `MgfSettings` configuration family (7 names). Plus a small
> internal cleanup (ruff SIM warnings in `_catch_up.py`) that
> predates the v0.32+ stabilization window.

### Public-API stability tiers — second + third walks (19 names)

Per the v0.32+ stabilization roadmap, walking public names that
have survived multiple minor releases AND have multi-consumer use
from `experimental` to `stable`. Two batches in this patch:

**HTTP-01 hierarchy (12 names)** — promoted to `stable` (v0.32.1):

| Module | Names |
|---|---|
| `mgf.common.exceptions` | `HttpError`, `HttpClientError`, `HttpServerError`, `HttpBadRequest`, `HttpUnauthorized`, `HttpForbidden`, `HttpNotFound`, `HttpConflict`, `HttpGone`, `HttpUnprocessable`, `HttpInternalServerError`, `HttpServiceUnavailable` |

Shipped in v0.18.0 (HTTP-01 filing); 14 minor cycles of incubation;
used by mgf-fastapi's `ExceptionTranslationMiddleware`,
PlasmaMapper's domain exceptions (subclass HTTP-01 leaves directly),
inthewords' DRF integration, and mgf-fastapi v0.3's `bearer_session`
(which raises `HttpUnauthorized`). The three-level category-catch
property (`except HttpError:` / `except HttpClientError:` /
`except HttpServerError:`) and the `http_status: int` class
attribute contract are now locked.

**`MgfSettings` family (7 names)** — promoted to `stable` (v0.32.1):

| Module | Names |
|---|---|
| `mgf.common.config` | `BaseAppSettings`, `settings_config` |
| `mgf.common.settings` | `MgfSettings`, `LoggingSettings`, `OtelSettings`, `CrashSettings`, `RedactionSettings` |

`MgfSettings` is the typed root every consumer instantiates;
`BaseAppSettings` is the base every consumer's own settings class
inherits from. The four promoted sub-settings dataclasses
(`LoggingSettings`, `OtelSettings`, `CrashSettings`,
`RedactionSettings`) have had stable shapes for 12+ minor cycles.

### Explicitly NOT promoted in this round (hold for next walk)

- `VaultSettings` + `BuiltinVaultBackendConfig` + the typed vault
  config union — discriminated-union shape is more recent; the
  pattern itself is fine but consumers have less exposure to it.
- `bootstrap_for_test`, `add_help_note` — test/helper shape;
  smaller exposure surface.
- `UnconfiguredWarning`, `HostEnvironmentError` — deprecation /
  rename cycles still in play; wait one more minor per AP-12.
- Concrete exception leaves (`SchemaValidationError`,
  `AppConfigError`, `CommandError`, etc.) — used but more granular;
  one more cycle for shape evidence.
- Extension API (`register_crash_sink`, `register_log_handler`,
  `register_span_processor`, `register_redaction_pattern_group`,
  the factory type aliases) — recent additions; the registry shape
  is still evolving.
- Everything in `mgf.common.cli`, `mgf.common.process`,
  `mgf.common.versioned`, `mgf.common.vault`, `mgf.common.progress`,
  `mgf.common.observability` — deserves dedicated walks once
  another minor cycle of evidence accumulates.

### Other changes

- **chore(catch-up):** cleared two pre-existing ruff SIM warnings
  in `src/mgf/common/cli/_catch_up.py` (`_has_pip_tools_layout` +
  `_is_private_module`). Also refreshed the stale "deferred
  follow-up" line in `_has_pip_tools_layout`'s docstring that
  PAPER-15 v0.32.0 invalidated. No behaviour change.

### Promotion tally after v0.32.1

  v0.32.0 promoted: 12 (mgf.common + exception category bases)
  v0.32.1 promoted: 19 (HTTP-01 hierarchy + MgfSettings family)
  --------
  Total stable:    31
  Remaining experimental: 177

### Federation note

mgf-common is in its v0.32+ stabilization window — no new public
surface, only tier flips + behaviour fixes to existing tooling.
This patch is doc-only on the runtime side; consumers can `pip
install --upgrade mgf-common` to refresh their installed
`PUBLIC_API.md` view of the tier landscape, but no runtime
behaviour changes.

---

## [0.32.0] — 2026-05-10

PyPI: <https://pypi.org/project/mgf-common/0.32.0/> · Tag: `v0.32.0`

> **First v0.32+ stabilization-window release.** Per the federation
> roadmap, v0.32+ adds NO new mgf-common public surface — this release
> closes FEEDBACK [PAPER-15](FEEDBACK.md) by extending the existing
> `mgf-common catch-up` audit to recognise pip-tools-shaped projects
> as first-class manifests. Cutover guide:
> [`docs/cutover/v0.32.0.md`](docs/cutover/v0.32.0.md).

### Changed — `mgf-common catch-up`

- **Pip-tools manifest audit (PAPER-15).** Projects that declare deps
  via `requirements/*.{txt,lock}` (no `pyproject.toml`) are now
  audited as first-class manifests, not skipped with an info-level
  workaround note. The pin row reads `mgf-common` from
  `requirements/base.txt` (with fallbacks: `main.txt`, `runtime.txt`,
  then flat `requirements.txt` at the project root). Staleness +
  auto-rewrite + editable-install guard all apply uniformly with
  the pyproject path; backups land in the same file's directory.
- **Four-gate audit reads standalone configs.** For pip-tools
  projects, the four gates are read from standalone config files:
  - **ruff**: `ruff.toml` or `.ruff.toml`
  - **mypy**: `mypy.ini` / `.mypy.ini` (or `setup.cfg [mypy]`) with
    `strict = True`
  - **pytest**: `pytest.ini` / `setup.cfg [tool:pytest]` / `tox.ini
    [pytest]` with `filterwarnings = error` (single-line or
    multi-line forms both accepted)
  - **coverage**: `.coveragerc` or `coverage.ini`
- **Audit row labels.** Pip-tools projects see audit rows titled
  `requirements/* — mgf-common pin` and `requirements/* — four gates`
  (was `pyproject.toml — …` before, even though they couldn't
  actually be audited).

### Migration

No migration needed for pyproject-based projects; the pyproject path
is unchanged. Pip-tools projects that previously saw the
"deferred follow-up" info message now see real audit rows — re-run
`mgf-common catch-up` to see them.

### Engineering

- New `_check_pin_in_requirements`, `_check_four_gates_standalone`,
  and four small `_has_*_standalone` helpers in
  `src/mgf/common/cli/_catch_up.py`. The historical
  `_check_pyproject_pin` / `_check_four_gates` names are preserved
  as the public entry points (they dispatch internally) so the
  existing import surface holds.
- 17 new unit tests under `tests/unit/cli/test_catch_up.py`:
  `TestPipToolsPinCheck` (9 tests) and `TestPipToolsFourGates`
  (8 tests). The historical TestPipToolsLayoutDetection retains the
  layout-detection unit tests + the "no-manifest" warning case; the
  old "v0.17.2 info-level workaround" tests are removed since the
  workaround is no longer the answer.

### Federation note

mgf-common is in its v0.32+ stabilization window — no new mgf-common
public surface. The change is internal to the catch-up CLI's behaviour
and visible only to consumers running `mgf-common catch-up`. Sibling
public surface additions (e.g. mgf-fastapi v0.3's `bearer_session`,
PAPER-29) happen in the siblings under their independent semver.

### Public-API stability tiers — first experimental → stable walk

Per the federation roadmap, v0.32+ stabilization includes promoting
public names that have survived multiple minor releases AND have
real consumer use from `experimental` to `stable`. This release ships
the **first such walk**, deliberately conservative: only the load-
bearing foundation surface that every consumer touches.

**Promoted to `stable` (12 names):**

| Module | Names |
|---|---|
| `mgf.common` | `bootstrap`, `current_context`, `AppContext`, `app_name`, `app_version` |
| `mgf.common.exceptions` | `AppError`, `ConfigError`, `ProviderError`, `OperationError`, `GuestError`, `VaultError`, `SchedulerError` |

These names have existed in their current shape since v0.13.0 or
earlier (12+ minor cycles of incubation) and form the contract every
mgf-common consumer (VManager, inthewords, PlasmaMapper, every sibling
package) builds against. `AppError` and its seven category bases are
the typed-exception hierarchy roots that every consumer's `except`
clauses depend on — locking them down now (with `AP-12` deprecation
discipline applying to any future removal) is a v1.0-readiness move.

**Explicitly NOT promoted in this pass** (held experimental for at
least one more minor):

- The HTTP-01 hierarchy (`HttpError`, `HttpClientError`,
  `HttpServerError`, and the per-status leaves like `HttpUnauthorized`):
  added in v0.18.0; multi-consumer use is real but young. Promotion
  candidate for v0.33 or v0.34.
- Concrete exception leaves (`SchemaValidationError`, `AppConfigError`,
  `CommandError`, `ResourceNotFoundError`, `ResourceAlreadyExistsError`,
  `BootstrapError`, `CancellationError`, `GuestUnreachableError`,
  `GuestCommandError`): used but more granular; one more cycle for
  shape evidence.
- `HostEnvironmentError`: recent rename from `EnvironmentError`; the
  deprecated alias is still in play. Wait one cycle.
- `MgfSettings` family (`MgfSettings`, `BaseAppSettings`,
  `settings_config`, the sub-settings dataclasses): large surface area
  that deserves its own dedicated walk.
- `bootstrap_for_test`, `add_help_note`, `UnconfiguredWarning`: recent
  additions that haven't accumulated cross-consumer evidence yet.
- Everything in newer submodules (`db`, `alembic`, `django` — now
  parallel siblings; the mgf-common-side aliases are deprecation shims
  where any remain).
- `configure` stays `deprecated` (PAPER-25 migration to `bootstrap`).
- `EnvironmentError` (the legacy shadowing-builtin alias) stays
  `experimental` — it's path-to-removal, not path-to-stable.

### `PUBLIC_API.md` rendering

The new stable rows are rendered as `**stable** (v0.32.0)` so the
release in which each name was promoted is searchable from the
contract document.

### Reference-consumer profiles — PAPER-06 full restructure

Per [FEEDBACK PAPER-06](FEEDBACK.md), consumer-specific evidence
moves out of `docs/standards/*.md` into a new
[`docs/reference-consumers/`](docs/reference-consumers/) folder.
Three profile files ship with this release:

- [`VManager.md`](docs/reference-consumers/VManager.md) — desktop /
  Qt VM-management; the original reference consumer.
- [`inthewords.md`](docs/reference-consumers/inthewords.md) — Django
  web app; closed strategic-review Priority 1 (second consumer).
- [`PlasmaMapper.md`](docs/reference-consumers/PlasmaMapper.md) —
  FastAPI SaaS; the trigger for PAPER-26/27/28/29.

Each profile documents the consumer's project type, shape-at-a-
glance, pattern-by-pattern evidence, known non-adoptions, and the
friction it surfaced as papers. The folder's
[`README.md`](docs/reference-consumers/README.md) documents the
intake flow for a fourth or fifth profile.

`docs/standards/README.md`'s caveat banner generalises from
"reference consumer = VManager" to "three reference consumers; see
reference-consumers/". Inline consumer mentions in the standards
docs themselves stay (they're one-clause evidence groundings, not
the heavy "AS-IS in X" paragraphs the paper targeted) — the full
restructure preserves "grounded in real code" while moving the
detailed shape next door.

---

## [0.31.0] — 2026-05-10

PyPI: <https://pypi.org/project/mgf-common/0.31.0/> · Tag: `v0.31.0`

> **Cutover guide:** [`docs/cutover/v0.31.0.md`](docs/cutover/v0.31.0.md)
> — fourth and final framework-adapter sibling extraction per
> [ASPIRE-06](FEEDBACK.md). The entire `mgf.common.django`
> subpackage moves to a new sibling distribution **`mgf-django`**
> (import path `mgf.django`). 🔴 **breaking** for any consumer
> importing from `mgf.common.django.*` or installing the
> `mgf-common[django]` extra; the migration is a rename + dependency
> swap PLUS a Django app-label rename (`"mgf_common"` →
> `"mgf_django"`).
>
> After this release, mgf-common settles into its v1.0 target
> shape: pure-Python infrastructure + standards source-of-truth.
> The v0.32+ stabilization window opens.

### Removed (BREAKING)

- **`mgf.common.django.*`** — every name (`MgfCommonConfig`,
  `MgfRequestIdMiddleware`, `MgfContextMiddleware`,
  `JsonFormatter`, `DjangoSettingsBridge`) moves to `mgf.django.*`
  in the new **`mgf-django`** sibling distribution.
- **`[django]` and `[django-test]` extras** in `mgf-common` are
  deleted. Consumers install `mgf-django` directly.
- **App label `"mgf_common"` → `"mgf_django"`** — the
  `MgfCommonConfig.label` rebrands at the sibling rename. Consumer
  config hardcoding `"mgf_common"` (typically
  `apps.get_app_config("mgf_common")` or migration table-prefix
  configs) MUST update.

### Migration

| Was | Now |
|---|---|
| `from mgf.common.django import …` | `from mgf.django import …` |
| `INSTALLED_APPS = [..., "mgf.common.django"]` | `INSTALLED_APPS = [..., "mgf.django"]` |
| `MIDDLEWARE = ["mgf.common.django.MgfRequestIdMiddleware", ...]` | `MIDDLEWARE = ["mgf.django.MgfRequestIdMiddleware", ...]` |
| `LOGGING = {"formatters": {"json": {"()": "mgf.common.django.JsonFormatter"}}}` | `LOGGING = {"formatters": {"json": {"()": "mgf.django.JsonFormatter"}}}` |
| `apps.get_app_config("mgf_common")` | `apps.get_app_config("mgf_django")` |
| `pip install 'mgf-common[django]'` | `pip install mgf-django` |

The new `mgf-django` sibling pins to `mgf-common>=0.31,<0.32`. The
v0.31 cutover guide details the dependency-pin and import-rewrite
steps per consumer (only inthewords is affected; their live config
doesn't actually use mgf.common.django so they only bump the
pin — doc cosmetics included).

### Engineering

- 18 unit tests removed from mgf-common (the `tests/unit/django/`
  suite moved to `mgf-django/tests/unit/`).
- PUBLIC_API.json: modules 16 → 15, names 175 → 170.
- `_init_project.py` scaffold: `[django]` kind now emits
  `mgf-common + mgf-django` (no more `mgf-common[django]`); pin
  floors bump from `>=0.30,<0.31` to `>=0.31,<0.32` across all
  five kinds.
- Version bump: 0.30.0 → 0.31.0. Parallel bumps in pyproject.toml
  + `src/mgf/common/__init__.py` keep the AP-13 version-sync test
  green.
- Federation milestone: this is the FOURTH and FINAL framework-
  adapter extraction (mgf-fastapi v0.28, mgf-http v0.29,
  mgf-sqlalchemy + mgf-alembic + mgf-fastapi v0.2 v0.30,
  mgf-django v0.31). mgf-common is now the federation leaf with
  pure-Python infrastructure only.

### Documentation

- `docs/cutover/v0.31.0.md` — full migration map.
- `docs/recipes/django.md` removed from mgf-common; the canonical
  recipe now lives at `mgf-django/docs/recipes/django.md`.
- `docs/release/federation_roadmap.md` retrospective row filled
  for v0.31.0; v1.0 target architecture table now reflects the
  fully-extracted shape.
- `docs/standards/web/README.md`, `docs/qa/coverage.md`,
  `docs/recipes/README.md`, `docs/reference/README.md` updated.

---

## [0.30.0] — 2026-05-10

PyPI: <https://pypi.org/project/mgf-common/0.30.0/> · Tag: `v0.30.0`

> **Cutover guide:** [`docs/cutover/v0.30.0.md`](docs/cutover/v0.30.0.md)
> — third federation extraction per [ASPIRE-06](FEEDBACK.md). The
> entire `mgf.common.db` and `mgf.common.alembic` subpackages move to
> two new sibling distributions **`mgf-sqlalchemy`** (import path
> `mgf.sqlalchemy`) and **`mgf-alembic`** (import path
> `mgf.alembic`), plus the FastAPI-shaped session/lifespan helpers
> migrate to **`mgf-fastapi`** v0.2.0 as `mgf.fastapi.db`. 🔴
> **breaking** for any consumer importing from `mgf.common.db.*` or
> `mgf.common.alembic.*` or installing the `[db]`/`[db-test]`/
> `[alembic]`/`[alembic-test]` extras.

### Removed (BREAKING)

- **`mgf.common.db.*`** — every name. The pure-SQLAlchemy helpers
  (`create_engine`, `create_sessionmaker`, `tenant_session`) move to
  `mgf.sqlalchemy.*` in the new **`mgf-sqlalchemy`** sibling. The
  FastAPI-shaped helpers (`get_session`, `setup_db`) move to
  `mgf.fastapi.db.*` in **`mgf-fastapi`** v0.2.0 (gated behind the
  new `mgf-fastapi[sqlalchemy]` extra). Splitting by shape keeps
  mgf-sqlalchemy framework-agnostic per the federation roadmap.
- **`mgf.common.alembic.*`** — `configure_env` (with its PAPER-22
  `include_object` / `include_schemas` knobs) moves to
  `mgf.alembic.*` in the new **`mgf-alembic`** sibling.
- **`[db]`, `[db-test]`, `[alembic]`, `[alembic-test]` extras** in
  `mgf-common` are deleted. Consumers install
  `mgf-sqlalchemy[test]` / `mgf-alembic[test]` directly, plus
  `mgf-fastapi[sqlalchemy]` for the request-scoped helpers.

### Migration

| Was | Now |
|---|---|
| `from mgf.common.db import create_engine` | `from mgf.sqlalchemy import create_engine` |
| `from mgf.common.db import create_sessionmaker` | `from mgf.sqlalchemy import create_sessionmaker` |
| `from mgf.common.db import tenant_session` | `from mgf.sqlalchemy import tenant_session` |
| `from mgf.common.db import get_session` | `from mgf.fastapi.db import get_session` |
| `from mgf.common.db import setup_db` | `from mgf.fastapi.db import setup_db` |
| `from mgf.common.alembic import configure_env` | `from mgf.alembic import configure_env` |
| `pip install 'mgf-common[db]'` | `pip install mgf-sqlalchemy` |
| `pip install 'mgf-common[db-test]'` | `pip install 'mgf-sqlalchemy[test]'` |
| `pip install 'mgf-common[alembic]'` | `pip install mgf-alembic` |
| `pip install 'mgf-common[alembic-test]'` | `pip install 'mgf-alembic[test]'` |

The three new sibling pieces pin to `mgf-common>=0.30,<0.31`. The
v0.30 cutover guide details the dependency-pin and import-rewrite
steps per consumer.

### Engineering

- 26 unit tests removed from mgf-common (the `tests/unit/db/` +
  `tests/unit/alembic/` suites moved to the new siblings:
  `mgf-sqlalchemy/tests/unit/` carries 13, `mgf-alembic/tests/unit/`
  carries 16, and `mgf-fastapi/tests/unit/test_db.py` carries 6 from
  the FastAPI-shape coverage).
- PUBLIC_API.json: modules 18 → 16, names 181 → 175 (`mgf.common.db`
  + `mgf.common.alembic` removed).
- `_init_project.py` scaffold: `[fastapi]` kind now emits
  `mgf-fastapi[sqlalchemy] + mgf-sqlalchemy + mgf-alembic +
  mgf-http`; pin floors bump from `>=0.29,<0.30` to `>=0.30,<0.31`.
- Version bump: 0.29.0 → 0.30.0. Parallel bumps in pyproject.toml +
  `src/mgf/common/__init__.py` keep the AP-13 version-sync test
  green.

### Documentation

- `docs/cutover/v0.30.0.md` — full migration map with sed-friendly
  rewrites for the import + extra changes.
- `docs/recipes/db.md` and `docs/recipes/alembic.md` removed from
  mgf-common; the canonical recipes now live at
  `mgf-sqlalchemy/docs/recipes/sqlalchemy.md` and
  `mgf-alembic/docs/recipes/alembic.md`.
- `docs/release/federation_roadmap.md` retrospective row filled for
  v0.30.0.

---

## [0.29.0] — 2026-05-09

PyPI: <https://pypi.org/project/mgf-common/0.29.0/> · Tag: `v0.29.0`

> **Cutover guide:** [`docs/cutover/v0.29.0.md`](docs/cutover/v0.29.0.md)
> — second federation extraction per [ASPIRE-06](FEEDBACK.md). The
> entire `mgf.common.http` subpackage moves to a new sibling
> distribution **`mgf-http`** (import path `mgf.http`). 🔴
> **breaking** for any consumer importing from `mgf.common.http.*`
> or installing the `mgf-common[http]` extra; the migration is a
> rename + dependency swap PLUS one renamed class
> (`HttpClientError` → `HttpTransportError`).

### Removed (BREAKING)

- **`mgf.common.http.*`** — every name (`AsyncHttpClient`,
  `RetryPolicy`, the transport-failure `HttpClientError`) moves
  to `mgf.http.*` in the new **`mgf-http`** sibling distribution.
- **`[http]` and `[http-test]` extras** in `mgf-common` are
  deleted. Consumers install `mgf-http` (or `mgf-http[test]`)
  directly.

### Renamed (BREAKING — sibling-side)

- **`HttpClientError` → `HttpTransportError`** — the
  transport-failure leaf renames at the cutover to disambiguate
  from `mgf.common.exceptions.HttpClientError` (the HTTP-01
  4xx-class hierarchy parent, which **stays in mgf-common**
  unchanged). Renaming was deferred until the extraction since
  fixing the collision in mgf-common alone would have churned
  every consumer twice. Now both classes have unambiguous names:
  - `mgf.common.exceptions.HttpClientError` (status-class
    hierarchy parent, 4xx-class) — **kept**.
  - `mgf.http.exceptions.HttpTransportError` (transport-layer
    failure leaf) — **renamed**.

### Migration

| Was | Now |
|---|---|
| `from mgf.common.http import AsyncHttpClient` | `from mgf.http import AsyncHttpClient` |
| `from mgf.common.http import RetryPolicy` | `from mgf.http import RetryPolicy` |
| `from mgf.common.http import HttpClientError` | `from mgf.http import HttpTransportError` |
| `pip install 'mgf-common[http]'` | `pip install mgf-http` |
| `pip install 'mgf-common[http-test]'` | `pip install 'mgf-http[test]'` |

The new `mgf-http` sibling pins to `mgf-common>=0.29,<0.30`. The
v0.29 cutover guide details the dependency-pin and import-rewrite
steps per consumer (PlasmaMapper + mgf-apiprobe migrate; VManager
+ inthewords have no http surface and need only the
`mgf-common = ">=0.29,<0.30"` pin bump).

### Documentation

- **`docs/cutover/v0.29.0.md`** (new) — full rename map +
  sed-friendly mechanical rewrite for the
  `HttpClientError` → `HttpTransportError` rename + per-consumer
  migration notes.
- **`docs/recipes/http.md`** — moved to `mgf-http/docs/recipes/`
  per **D5**. The mgf-common recipes README keeps the entry as a
  `(sibling)` pointer.
- **`docs/recipes/README.md`**, **`docs/reference/README.md`**,
  **`docs/reference/full_app.md`**, **`docs/recipes/{db,
  notebook,multi_tenant_settings,providers}.md`**,
  **`docs/audience/security.md`**, **`docs/qa/coverage.md`**,
  **`docs/internal/lift_checklist.md`** — cross-references
  rewritten to point at the new `mgf.http` sibling import path
  and to use the renamed `HttpTransportError` class.

### Engineering

- **`tools/generate_public_api_json.py`** — `PUBLIC_MODULES` no
  longer includes `mgf.common.http`. PUBLIC_API.json regenerated.
- **`src/mgf/common/cli/_init_project.py`** — scaffolded
  pyproject snippet emits sibling deps (`mgf-fastapi`,
  `mgf-http`) instead of the legacy `mgf-common[fastapi,http]`
  extras shape. Per-kind dep lists updated for the two
  extractions to date; pin bumped from the stale `0.9.0,<0.10`
  to `0.29,<0.30`. EH-11 retry-policy reference points at
  `mgf.http.RetryPolicy` (sibling) instead of the deleted
  `mgf.common.http.RetryPolicy`.
- **`tests/unit/cli/test_init_project.py`** — `test_pin_includes_extras_for_kind`
  renamed to `test_pin_includes_siblings_for_kind` and rewritten
  to assert the new sibling-dep emission. Negative assertions
  enforce that `mgf-common[fastapi,...]` / `mgf-common[http,...]`
  do NOT reappear (regression guard for the federation rule).

### Engineering note — what changed internally

Two non-breaking improvements landed during the v0.29 extraction:

1. **Closed-box leak fix.** `mgf.common.http._client` previously
   reached into `mgf.common._identity._APP_NAME` /
   `_APP_VERSION` to compute the User-Agent — a private import
   from another module within the same distribution, but still
   a closed-box-rule violation. The sibling now uses the public
   `mgf.common.app_name()` / `mgf.common.app_version()` accessors.
   Behaviour is identical.
2. **User-Agent attribution.** The library suffix in the
   User-Agent header changed from `mgf-common/<libver>` to
   `mgf-http/<libver>`. Accurate now that `AsyncHttpClient`
   ships from the sibling. Consumers that match on
   `mgf-common/<libver>` for HTTP traffic specifically should
   update to `mgf-http/<libver>`.

---

## [0.28.0] — 2026-05-08

PyPI: <https://pypi.org/project/mgf-common/0.28.0/> · Tag: `v0.28.0`

> **Cutover guide:** [`docs/cutover/v0.28.0.md`](docs/cutover/v0.28.0.md)
> — first federation extraction per [ASPIRE-06](FEEDBACK.md). The
> entire `mgf.common.fastapi` subpackage moves to a new sibling
> distribution **`mgf-fastapi`** (import path `mgf.fastapi`). This
> is a 🔴 **breaking** ship for any consumer importing from
> `mgf.common.fastapi.*` or the `mgf-common[fastapi]` extra; the
> migration is a rename + dependency swap (no code-shape changes).

### Removed (BREAKING)

- **`mgf.common.fastapi.*`** — every name (`setup_lifespan`,
  `RequestIdMiddleware`, `ExceptionTranslationMiddleware`,
  `current_request_id`, `REQUEST_ID_HEADER`, `DEFAULT_STATUS_MAP`,
  `get_app_context`, `get_settings`, `get_request_id`,
  `IpAllowlist`, `LOOPBACK_CIDRS`, `run_test_app`,
  `HmacWebhookVerifier`, `verify_request`, `WebhookHeaderSchema`,
  `SVIX_SCHEMA`) moves to `mgf.fastapi.*` in the new
  **`mgf-fastapi`** sibling distribution.
- **`mgf.common.exceptions.HmacVerificationError`** — moves to
  `mgf.fastapi.exceptions` per **D3** (sibling-domain concretes
  travel with their sibling). HTTP-01 hierarchy roots
  (`HttpUnauthorized`, `HttpForbidden`, …) stay in `mgf-common`.
- **`[fastapi]` and `[fastapi-test]` extras** in `mgf-common` are
  deleted. Consumers install `mgf-fastapi` (or
  `mgf-fastapi[testing]`) directly.

### Migration

| Was | Now |
|---|---|
| `from mgf.common.fastapi import X` | `from mgf.fastapi import X` |
| `from mgf.common.fastapi.webhooks import …` | `from mgf.fastapi.webhooks import …` |
| `from mgf.common.fastapi.security import IpAllowlist` | `from mgf.fastapi.security import IpAllowlist` |
| `from mgf.common.fastapi.testing import run_test_app` | `from mgf.fastapi.testing import run_test_app` |
| `from mgf.common.exceptions import HmacVerificationError` | `from mgf.fastapi.exceptions import HmacVerificationError` |
| `pip install 'mgf-common[fastapi]'` | `pip install mgf-fastapi` |
| `pip install 'mgf-common[fastapi-test]'` | `pip install 'mgf-fastapi[testing]'` |

The new `mgf-fastapi` sibling pins to `mgf-common>=0.28,<0.29`. The
v0.28 cutover guide details the dependency-pin and import-rename
steps per consumer (PlasmaMapper is the migration consumer; VManager
+ inthewords have no FastAPI surface and need only the
`mgf-common = ">=0.28,<0.29"` pin bump).

### Documentation / design

- **`docs/release/federation_roadmap.md`** (new) — load-bearing
  tracking document for the v0.28 → v1.0 federation split. Per-
  sibling specs, quality gates, locked decisions (D1–D15), open
  questions, future improvements, retrospective log. The single
  source of truth for the staged extraction plan; FEEDBACK papers
  cross-reference here.
- **`FEEDBACK.md ASPIRE-06`** — federated package architecture
  approved 2026-05-08. v0.28 extracts `mgf-fastapi`; v0.29 extracts
  `mgf-http`; v0.30 extracts `mgf-sqlalchemy` + `mgf-alembic`; v0.31
  extracts `mgf-django`; v1.0 locks the federated surface. Sibling-
  domain concrete exceptions (`HmacVerificationError` etc.) move with
  their sibling; HTTP-01 hierarchy roots stay in mgf-common.
- **`FEEDBACK.md ASPIRE-05`** (filed) — long-horizon: mgf-common as
  cross-language engineering-process source-of-truth. Triggered by
  PAPER-30 (first non-Python sibling). Decision deferred until 2+
  non-Python Magogi projects exist.
- **`FEEDBACK.md PAPER-30`** (filed) — `mgf-website-template`
  cookiecutter sibling repo for Magogi marketing sites (Astro +
  Infomaniak deploy). Parallel to the Python-sibling federation, not
  in the dependency graph.
- **`FEEDBACK.md ASPIRE-04`** — restored missing `#### ASPIRE-04`
  heading dropped accidentally in commit `3c12f21`. The entry's body
  was always there; the heading was lost in a copy-edit.
- **`docs/recipes/{fastapi,webhooks}.md`** moved to
  `mgf-fastapi/docs/recipes/`. `docs/recipes/README.md`,
  `docs/standards/web/README.md`, `docs/reference/README.md`,
  `docs/reference/full_app.md`, `docs/recipes/{db,django,http,
  providers,framework-owned-logging}.md`, and
  `docs/design/multi_tenancy.md` updated to reference the new
  sibling import path.
- **`docs/internal/lift_checklist.md`** — adapter-vs-sibling
  guidance updated: framework-shaped adapters now ship as siblings
  by default (the v0.28 federation decision). Stateless,
  primitive-reusing adapters (`mgf.common.{db,http,alembic}`,
  `mgf.common.django` until extracted) remain extras.

### Engineering

- **`tests/unit/django/conftest.py`** — adds a package-scoped
  finalizer that closes Django's open `_BOOTSTRAP_STACK` at the end
  of the django package's tests. Without this, identity (`_APP_NAME =
  "test-app"`) leaked into later test files (the fastapi tests
  previously masked the leak by re-bootstrapping with their own
  identity in their lifespan tests; with those tests gone, the leak
  surfaced as crash-reporter / excepthook failures).
- **`tools/generate_public_api_json.py`** — `PUBLIC_MODULES` no
  longer includes `mgf.common.fastapi.*`. Module count: 23 → 19;
  total names: 201 → 184.

### Engineering note — first federation extraction

v0.28.0 is the **first execution** of the federation split per
ASPIRE-06. The shape this extraction proves out is the template for
v0.29 (`mgf-http`), v0.30 (`mgf-sqlalchemy`, `mgf-alembic`), and
v0.31 (`mgf-django`):

- Federation leaf (`mgf-common`) deletes the subpackage entirely
  in the same release that the sibling ships v0.1.0 — no
  deprecation cycle, no `.fastapi` stub re-exporting from
  `mgf.fastapi`. The 0.x window discipline absorbs the breakage.
- Sibling-domain concrete exceptions move with their sibling per
  **D3**; the HTTP-01 hierarchy roots (`HttpUnauthorized`,
  `HttpForbidden`, etc.) stay in `mgf-common`.
- Framework-specific recipes (`fastapi.md`, `webhooks.md`) move
  with their sibling per **D5**; cross-cutting standards
  (`docs/standards/web/`) stay in `mgf-common` per **D4**.

---

## [0.27.0] — 2026-05-08

PyPI: <https://pypi.org/project/mgf-common/0.27.0/> · Tag: `v0.27.0`

> **Cutover guide:** [`docs/cutover/v0.27.0.md`](docs/cutover/v0.27.0.md)
> — closes [PAPER-27](FEEDBACK.md) (`IpAllowlist` FastAPI dependency)
> + [PAPER-28](FEEDBACK.md) (`run_test_app` async context manager).
> Same-day batch follow-up to v0.26.0; both 🟢 nice-to-haves filed
> by PlasmaMapper in the same Phase-3 paper batch.

### Added

- **`mgf.common.fastapi.security.IpAllowlist`** (closes
  [PAPER-27](FEEDBACK.md)) — FastAPI dependency that 403s requests
  whose client IP isn't in a configured CIDR allowlist. Concentrates
  the **proxy-trust footgun** in one knob (`trust_proxy: bool = False`
  default — explicit deploy decision required to honour
  `X-Forwarded-For`). IPv4 + IPv6 dual-stack with cross-version
  matches deliberately rejected. Raises `HttpForbidden` (HTTP-01
  leaf, 403 via PAPER-24's `http_status` resolution). Default
  `cidrs=LOOPBACK_CIDRS` so tests work out-of-the-box; consumers
  override for production. Misconfigured CIDRs raise at
  construction, not first request.
- **`mgf.common.fastapi.testing.run_test_app`** (closes
  [PAPER-28](FEEDBACK.md)) — async context manager that starts
  uvicorn for a `FastAPI` app on a free port and yields the base
  URL. Replaces ~120 LOC per consumer (free-port discovery +
  race-free `server.started` await + clean-shutdown choreography
  with `CancelledError` suppression). Surfaces server-startup
  exceptions instead of timing out silently. `TimeoutError` if the
  app's lifespan blocks beyond `startup_timeout_seconds` (default
  5 s).

### Changed

- **`pyproject.toml [project.optional-dependencies] fastapi-test`**
  — adds `uvicorn>=0.30` for `run_test_app`. Existing consumers of
  the `[fastapi-test]` extra automatically pick it up on next
  `uv sync`.

### Engineering

- 24 new tests across `tests/unit/fastapi/test_security.py` (16) +
  `tests/unit/fastapi/test_testing.py` (8). Total suite: 1495
  passing.
- Both helpers follow the v0.26.0 webhooks pattern: closed-box
  module under `mgf.common.fastapi.*`, explicit `from
  mgf.common.fastapi.security import …` (not re-exported at the
  top of `mgf.common.fastapi`). Encourages discoverable
  consumer code.
- The `Request` import in `security.py` is intentionally NOT
  inside `TYPE_CHECKING` — FastAPI's dependency wiring evaluates
  the parameter's annotation at registration time via
  `get_type_hints`, so the name MUST be importable at runtime.
  `# noqa: TC002` makes the intent explicit.

---

## [0.26.0] — 2026-05-08

PyPI: <https://pypi.org/project/mgf-common/0.26.0/> · Tag: `v0.26.0`

> **Cutover guide:** [`docs/cutover/v0.26.0.md`](docs/cutover/v0.26.0.md)
> — closes [PAPER-26](FEEDBACK.md): generic Svix-shape HMAC webhook
> verification primitive. Plus the v0.25.0-deferred recipe index.

### Added

- **`mgf.common.fastapi.webhooks`** (closes [PAPER-26](FEEDBACK.md))
  — Svix-shape HMAC webhook verification. Pulls the per-consumer
  verification dance (read `<id>` / `<ts>` / `<sig>` headers,
  validate replay window, compute `HMAC-SHA256(<id>.<ts>.<body>)`,
  base64-encode, constant-time-compare against multi-version
  signature header) into one tested primitive. Public surface:
  `WebhookHeaderSchema` (frozen dataclass; case-folds header
  names), `SVIX_SCHEMA` (Svix preset; used verbatim by Clerk),
  `HmacWebhookVerifier` (transport-agnostic core; thread-safe;
  `verify(headers, body) -> (event_id, ts)`), `verify_request`
  (async FastAPI request adapter). The verifier is intentionally
  transport-agnostic so it tests cleanly without FastAPI and
  composes from non-FastAPI code paths (CLI, batch jobs).
- **`mgf.common.exceptions.HmacVerificationError`** — new HTTP-01
  leaf inheriting `HttpUnauthorized` so PAPER-24's `http_status`
  resolution maps it to 401 in
  `ExceptionTranslationMiddleware` without an explicit
  `status_map` entry.
- **`docs/recipes/webhooks.md`** — full walkthrough including
  the consumer pattern for replacing per-provider verifiers,
  key rotation, and custom schemas.
- **`docs/recipes/README.md`** — canonical recipe index (v0.25.0
  truth-source-consolidation deliverable). Kind-organised section
  + A–Z lookup table with per-recipe paper closures + brief recipe
  / standard / reference disambiguation. `docs/audience/users.md`
  now points at the README as the complete index; the audience
  page remains the adoption-order reading list.

### Engineering

- 25 new tests in `tests/unit/fastapi/test_webhooks.py` covering
  every failure mode (missing header, unparseable timestamp, replay
  window in both directions, tampered body, wrong secret, wrong
  prefix, no prefix, multi-version-sig key rotation, case-
  insensitive header lookup, custom schema, custom signature
  prefix) plus the FastAPI request-adapter integration path
  through `ExceptionTranslationMiddleware`. Total suite: 1471
  passing.
- Stripe / GitHub / Slack signing schemes are deliberately NOT
  shipped at v0.26 — their conventions differ enough (combined
  headers, hex encoding, alternate prefixes) that one
  `WebhookHeaderSchema` doesn't fit. Adding presets is tracked
  for follow-up papers when a second consumer surfaces friction.

---

## [0.25.0] — 2026-05-07

PyPI: <https://pypi.org/project/mgf-common/0.25.0/> · Tag: `v0.25.0`

> **Cutover guide:** [`docs/cutover/v0.25.0.md`](docs/cutover/v0.25.0.md)
> — **documentation restructure**. Audience-routing front
> door + flat-content directories + cutover archive policy.
> **No Python-surface change. No behaviour change.**
> 100% documentation reorganisation.

### Added

- **`docs/audience/` — 8 new files** (master `README.md` + 7
  reading lists for `shoppers / users / developers / qa /
  release / security / ai-agents`). Each ~80–150 lines, pure
  navigation, no duplicated content. The new front door for
  every kind of reader.
- **`docs/README.md`** — the documentation index that routes
  to audience pages OR content directories by kind.
- **Top-level `README.md`** — rewritten as audience router
  (~100 lines, mostly links). Replaces the previous 374-line
  verbose form.
- **Cookiecutter template `docs/` overlay** — new project
  scaffolding now ships the same audience-routing layer +
  `standards/PROJECT_OVERLAY.md` for project-specific rule
  exceptions + `qa/coverage.md` skeleton. Sibling Magogi
  libraries inherit the layout via the cookiecutter.

### Changed (file moves; `git mv` preserved history)

| Old path | New path | Why |
|---|---|---|
| `docs/public/recipes/*` | `docs/recipes/*` | Drop `/public/` intermediate; flatter |
| `docs/public/01_lifecycle.md`, `02_..10_*.md` | `docs/reference/lifecycle.md`, `exceptions.md`, etc. | Semantic names instead of numbered prefixes |
| `docs/public/library_common.md` | `docs/reference/README.md` | "reference" is the right word |
| `docs/public/tutorial.md` | `docs/tutorial.md` | One file, no `/public/` wrapper |
| `docs/public/multi_tenancy.md` | `docs/design/multi_tenancy.md` | Design paper, not how-to |
| `docs/public/federation.md` | `docs/design/federation.md` | Same |
| `docs/internal/ARCHITECTURE.md` | `docs/design/architecture.md` | Promoted to public |
| `docs/internal/STRATEGIC_REVIEW.md` | `docs/design/strategic_review.md` | Same |
| `docs/internal/EXTRACTION_HISTORY.md` | `docs/design/extraction_history.md` | Same |
| `docs/internal/TEST_COVERAGE.md` | `docs/qa/coverage.md` | New `qa/` directory |
| `docs/internal/CI_STARTHERE.md` | `docs/release/ci.md` | New `release/` directory |
| `docs/internal/BENCHMARKS.md` | `docs/ops/benchmarks.md` | New `ops/` directory |
| `docs/internal/LIFT_CHECKLIST.md` | `docs/internal/lift_checklist.md` | Stays internal; lowercase |
| `docs/cutover/v0.18.0–v0.21.0.md` | `docs/cutover/archive/v*.md` | Last-3-minor-versions live policy |

### Truth-source consolidation

| Topic | Old (multi-source) | New canonical |
|---|---|---|
| What's tested | `tests/` + `internal/TEST_COVERAGE.md` + `TESTING.md §13.10` | `docs/qa/coverage.md` (narrative); other paths now point here |
| Recipe index | recipes scattered + per-module READMEs | `docs/recipes/README.md` (planned for v0.26+) |
| Per-release migration | `CHANGELOG.md` + `cutover/*` overlap | CHANGELOG = canonical short; cutover = canonical long; cross-linked |

### Deferred to v0.26+

- **Splitting `PUBLIC_API.md`** into per-module
  `docs/reference/<module>.md` files auto-generated from
  docstrings. The split was scoped out of v0.25 to keep this
  release purely structural.
- **Auto-generation of `docs/qa/coverage.md`** from `pytest --co`
  output.

### Engineering

- **Backwards-compat stub:** `docs/internal/TEST_COVERAGE.md`
  ships as a 1-line redirect to `docs/qa/coverage.md` for
  this release; removed in v0.26.
- **179 broken links found** by an ad-hoc link checker, fixed
  in batched sed/Python passes; final state: 0 broken links
  in non-archive content (modulo placeholder example syntax
  in `tools/docs_explorer/README.md`).
- **All 1445 tests pass unchanged** — the docs restructure
  doesn't touch any code surface.
- **Wheel content unchanged.** Only `docs/standards/` ships
  via `[tool.hatch.build.targets.wheel.force-include]`; no
  `docs/standards/*` files moved, so the wheel data is
  identical except for the version bump.

### Why this round

After 12 releases (v0.13 → v0.24), the docs accumulated
multiple truth-sources, fuzzy `public`/`internal` boundaries,
and no audience-routing front door. With three real consumers
in production and the cookiecutter template extending to
sibling Magogi libraries, a clean restructure was overdue.
The shape (audience-as-navigation + flat-content) is now the
**golden-standard layout** that sibling libraries inherit.

The full design rationale + question/answer log lives in the
[v0.25.0 cutover guide](docs/cutover/v0.25.0.md).

---

## [0.24.0] — 2026-05-07

PyPI: <https://pypi.org/project/mgf-common/0.24.0/> · Tag: `v0.24.0`

> **Cutover guide:** [`docs/cutover/v0.24.0.md`](docs/cutover/v0.24.0.md)
> — codify the four-layer test pyramid as a standard so other
> projects adopt the same shape. **Documentation-only release;
> zero Python-surface change.**

### Added

- **Three new TS-* rules in `docs/standards/TESTING.md`:**
  - **TS-19** — test layer markers MUST be registered in
    `pyproject.toml::[tool.pytest.ini_options].markers`. Combined
    with `--strict-markers` (TS-05) this prevents silent typos.
  - **TS-20** — tests MUST be partitioned across
    `tests/unit/` (mirrors `src/`), `tests/integration/`
    (cross-module), `tests/e2e/` (full bootstrap-to-output),
    `tests/smoke/` (post-install sanity).
  - **TS-21** — every published library MUST have a smoke
    layer in `tests/smoke/` running in <100 ms total. CLI/desktop
    apps without a wheel surface MAY skip.
- **`docs/standards/TESTING.md` §13 — the operational layer-marker
  pattern.** New section codifying the four-layer pyramid as a
  standard: directory shape, marker registration, runtime
  budgets, the smoke-layer minimum-viable shape, the e2e
  bootstrap-fixture pattern, the integration cross-module
  pattern, and a decision tree for "which layer for a new
  test?". Section §13.10 includes mgf-common's own per-layer
  counts as a reference.
- **`docs/qa/coverage.md`** — reference document
  showing what mgf-common tests at each layer plus per-module
  coverage breakdown plus coverage gaps as a roadmap. Consumer
  projects can copy the shape for their own
  `docs/qa/coverage.md`.
- **Section renumbering in `TESTING.md`:** new §13 "Layer
  markers" pushes the original §13–§17 to §14–§18 (Anti-patterns,
  Self-review, Mechanical enforcement, AS-IS, Cross-references).

### Engineering

- v0.24.0 is the **second docs-only release** for `mgf-common`
  (after v0.20.0). The pattern: when a feature shape stabilises
  and proves itself across multiple polish rounds (here:
  v0.21 → v0.22 → v0.23 for `mgf.common.process`), the next
  step is **codifying the pattern as a standard so other
  projects adopt the same shape**. This is the load-bearing
  part of the "cornerstone library" framing — the standards
  drive consistency across the ecosystem, not just the wheel.

---

## [0.23.0] — 2026-05-07

PyPI: <https://pypi.org/project/mgf-common/0.23.0/> · Tag: `v0.23.0`

> **Cutover guide:** [`docs/cutover/v0.23.0.md`](docs/cutover/v0.23.0.md)
> — second `mgf.common.process` polish round. Quality + comprehensive
> test layer expansion. **No behaviour breaks** for v0.22.0 consumers;
> existing `run()` / `Service` / readiness predicates / Process*
> exceptions all unchanged.

### Added

- **Public `redactor` property on `JsonFormatter` and `TextFormatter`.**
  Replaces the fragile private-attribute introspection that
  `mgf.common.process._streamer.get_active_redactor` was doing
  (the `formatter._redactor` lookup). The private attribute stays
  as a back-compat alias; new callers should use the public property.
- **`Service.__repr__`** for debugging. Shape:
  `Service(name='<n>', command=[...], status=<state>, pid=<pid|->)`
  where status is `not-started` / `running` / `exited(<rc>)`.
- **Best-effort OTel span wrapping** for `run()` and
  `Service.start()`. When `mgf.common.bootstrap()` is active AND
  the OpenTelemetry SDK is installed, each launch opens an
  `operation_span("process.run.<name>")` / `operation_span(
  "service.start.<name>")` with `command_id` as a span attribute.
  Failed launches (`ProcessTimeout` / `ServiceNotReady`) are
  recorded on the span. **Gated on bootstrap state** — when no
  `AppContext` is active, the call short-circuits to
  `contextlib.nullcontext()`, avoiding the `UnconfiguredWarning`
  the unguarded `operation_span` would emit (since it reads
  `app_name()` to name the tracer). Test suites with
  `filterwarnings = error` continue to work.
- **Tuple commands accepted** — `run(("echo", "hi"))` works
  alongside `run(["echo", "hi"])`. UX paper-cut for tests/scripts
  that build command tuples. Internal validation (`_validate_command`)
  normalizes to `list[str]` so the downstream `Popen` always sees
  a list and the `ProcessResult.command` field is always a list.
- **Pytest layer markers** (`smoke`, `e2e`, `integration`)
  registered in `pyproject.toml`. Run a layer in isolation with
  `pytest -m smoke` etc.

### Test coverage expansion

- **Smoke tier** (`tests/smoke/`) — 7 tests, < 100 ms total. Minimal
  post-install sanity (imports, exception MRO, `run()` happy path,
  Service no-launch-on-init, tuple acceptance, shell-string
  rejection).
- **End-to-end tier** (`tests/e2e/`) — 8 tests:
  - **Redaction E2E** (5 tests) — bootstrap + `run()` + child
    emitting a Bearer token → assert scrubbed in BOTH captured
    `stdout` and the streamed log record. Includes `redact=False`
    opt-out, `redact=True` requires-bootstrap raise, no-bootstrap
    silent-no-redaction.
  - **Correlation E2E** (3 tests) — `command_id` consistency
    across captured records, distinct ids across concurrent
    `run()` calls in threads, Service lifecycle records share
    the same id with the streamer's records.
- **Integration tier** (`tests/integration/process/`) — 5 tests:
  - **Multi-service via `ExitStack`** (2 tests) — declared-order
    start, LIFO teardown, no-leak when the dependent's start
    fails.
  - **Concurrent `run()`** (3 tests) — 16 parallel calls produce
    16 distinct `command_id`s, captured stdout is per-call
    isolated, log records don't cross processes.
- **Unit tier additions** (`tests/unit/process/test_polish_v023.py`) —
  9 tests: restart-after-failure pattern, OTel span gating
  (no `UnconfiguredWarning` without bootstrap; nullcontext path
  vs real-span path), public-redactor property on both
  formatters, `Service.__repr__` shape across lifecycle states.

**75 → 104 tests in the process subtree (+29)**. Full repo:
1416 → 1445 (+29). Zero regressions.

### Changed (internal — no surface impact)

- **`get_active_redactor()`** prefers the new public `redactor`
  property; falls back to `_redactor` for older formatters
  (back-compat).
- **Extracted `_validate_command(command)`** helper from
  duplicated validation code in `run()` and `Service.__init__`.
  Single source of truth for "list-or-tuple of strings, non-empty,
  no shell strings."

### Engineering

- **Stability tier:** every name in `mgf.common.process` stays
  at `experimental` per AP-11. Promotion still requires one full
  MINOR cycle without a 🔴 Blocker filed.
- **Test pyramid is now well-formed:** unit (84 process module
  tests) → integration (5) → e2e (8) → smoke (7). Each layer
  catches a different class of failure; the layer markers
  encourage the right CI shape (smoke pre-flight, full suite on
  PR, e2e on nightly).

---

## [0.22.0] — 2026-05-07

PyPI: <https://pypi.org/project/mgf-common/0.22.0/> · Tag: `v0.22.0`

> **Cutover guide:** [`docs/cutover/v0.22.0.md`](docs/cutover/v0.22.0.md)
> — `mgf.common.process` polish round. Reliability fixes + simplicity
> + one small additive method. **No behaviour breaks** for v0.21.0
> consumers; existing `run()` / `Service` / readiness predicates
> continue to work unchanged.

### Fixed

- **`Service.start()` early-exit detection.** Pre-fix: a child that
  crashed during startup (typo in command, missing dependency,
  segfault) caused `start()` to burn the full readiness `timeout_s`
  before raising a useless "probe X did not resolve" error. Post-fix:
  `start()` polls `proc.poll()` alongside the readiness probe and
  raises `ServiceNotReady` immediately when the child has exited
  before becoming ready. The returncode + stderr tail land in
  `last_error` for diagnosis. **Resolution time: from full timeout
  (e.g., 30s) to ~250ms** for the failure case.
- **Thread-safe `LogLineReady` snapshot.** Pre-fix: under high-volume
  child stdout (≥ thousands of lines per second), `LogLineReady`
  iterating its capture deque could race the streamer thread's
  `append`, raising `RuntimeError: deque mutated during iteration`.
  Post-fix: snapshots use `list(deque)` — atomic against the
  appending thread under CPython's GIL. Pinned by a 2000-line +
  1ms-poll-interval stress test.
- **Setup-failure rollback.** Pre-fix: any failure between `Popen`
  and the readiness-resolved log line could leak the launched
  process. Post-fix: `Service.start()` wraps streamer init +
  readiness wait in a `try/except BaseException` that calls the
  full teardown path before re-raising. The "no leaked process on
  failure" contract now covers every code path, including
  `KeyboardInterrupt`.

### Added

- **`Service.wait(timeout=None) -> int | None`** — block until the
  child exits naturally OR `timeout` elapses. Returns the
  `returncode` on natural exit, `None` on timeout (process still
  running). The escape hatch from `with Service(...)` for "start
  this service, let it run until it crashes or completes naturally"
  — without `wait()`, the only escape was `stop()`, which kills
  the child even if it was about to exit cleanly.

### Changed (internal — no surface impact)

- **Extracted `_streamer.resolve_redactor()` and `make_streamers()`
  helpers.** Deduplicates the parallel logic between
  `mgf.common.process.run()` and `Service.start()`. Both consumers
  now resolve redaction + create streamers through one call site
  each. ~30 LOC removed.
- **`_LineSnapshot` class → closure.** The single-method
  callable wrapper became a closure (3 lines vs 25). Behaviour
  identical; mutation surface smaller.
- **Tightened `get_active_redactor()`.** Single pass over
  `logging.root.handlers`; removed the try/except chain around the
  `_GLOBAL_CONTEXT` import path that was hiding logic — formatter
  introspection IS the discovery path; the AppContext walk added
  no value.
- **Replaced bespoke `_suppress_close_errors` class with stdlib
  `contextlib.suppress(Exception)`.** Three lines deleted; behaviour
  identical.
- **Dropped unused `Service._recent_lines` deque** (leftover from
  an earlier design that pre-dated the `_StreamCapture.snapshot`
  approach).

### Engineering

- **+11 new tests in `tests/unit/process/test_polish.py`** covering:
  early-exit detection (3 tests — fast resolution, stderr-tail
  diagnostics, normal-timeout still works), thread-race resilience
  under load (1 stress test), no-leak rollback regression
  (1 test), `Service.wait()` (3 tests — natural exit, timeout,
  before-start), shared helper sanity (3 tests). All v0.21.0
  tests continue to pass unchanged.
- **64 → 75 process tests; 1405 → 1416 total. Zero regressions.**
- **Stability tier:** every name in `mgf.common.process` stays at
  `experimental` per AP-11. The polish round does not promote;
  promotion still requires one full MINOR cycle without a 🔴
  Blocker filed.

---

## [0.21.0] — 2026-05-07

PyPI: <https://pypi.org/project/mgf-common/0.21.0/> · Tag: `v0.21.0`

> **Cutover guide:** [`docs/cutover/archive/v0.21.0.md`](docs/cutover/archive/v0.21.0.md)
> — process management. New top-level surface
> `mgf.common.process` for unified subprocess + service-lifecycle
> orchestration in tools, scripts, and tests.

### Added

- **`mgf.common.process` package** (10 names; all `experimental`
  per AP-11) — unified subprocess + service-lifecycle orchestration:
  - **`run(command, *, ...)` → `ProcessResult`** — one-shot
    subprocess wrapper. List-only command (eliminates command-
    injection at the API surface), structured result with
    `command_id` correlation, timeout-with-grace SIGTERM→SIGKILL
    escalation, redaction-aware line-by-line log streaming
    through `mgf.process.<name>` (stdout=INFO, stderr=WARNING),
    POSIX process-group cascade by default. Default `check=True`
    raises typed errors on non-zero / signal exit.
  - **`Service(command, *, ready, ...)`** — long-lived process
    with a readiness predicate + clean shutdown. Context-manager
    protocol; `start()` blocks until ready or raises
    `ServiceNotReady`. **No leaked process on failure** — service
    is fully torn down before the readiness exception is raised.
    Idempotent `start()` / `stop()`.
  - **Readiness predicates** — `PortReady(host, port)`,
    `HttpReady(url, expected_status=200)`, `LogLineReady(pattern,
    stream)`, `CallableReady(predicate)`, `AllOf([...])`,
    `AnyOf([...])`. `ReadinessProbe` Protocol for custom
    predicates. `LogLineReady` peeks into `Service`'s captured
    line history (last 1000 per stream).
  - **POSIX-first.** `process_group=True` (default) launches in a
    new session group via `start_new_session=True`; SIGTERM
    cascades via `os.killpg`. Windows is best-effort — silent
    downgrade to per-PID kill; signal-cascade semantics differ.
- **`mgf.common.exceptions` Process-launch category** — 5 new
  names, all subclasses of `OperationError` so existing
  EH-04-shaped CLI top-level handlers catch them unchanged:
  - `ProcessError` (base) — carries `.command` + `.command_id`.
  - `ProcessTimeout` — carries `.timeout`.
  - `ProcessNonZeroExit` — carries `.returncode` + `.stderr_tail`
    (last 10 lines of stderr for diagnostics).
  - `ProcessSignaled` — POSIX-only; carries `.signal`.
  - `ServiceNotReady` — carries `.probe_description`,
    `.timeout`, `.last_error`.

### Changed

- **`mgf.common.exceptions.__all__`** grew from 31 → 36 names.
  Additive — every existing import keeps working.

### Documentation

- **`docs/recipes/process-management.md`** (~370 lines) —
  comprehensive recipe covering `run()` patterns (timeout,
  redaction, log correlation, env_extra, capture-output),
  `Service` patterns (Postgres-for-test with composite
  PortReady+LogLineReady, Uvicorn smoke, multi-service via
  `ExitStack`, custom readiness via `CallableReady`,
  composite-`AnyOf` for platform-dependent ready signals),
  failure modes, testing notes, cross-references, and
  out-of-scope reminders.
- **`PUBLIC_API.md`** — new `mgf.common.process` section
  (10 names) + 5 new ProcessError leaves in the exceptions
  table. Total surface: 178 → 193 names.

### Engineering

- **65 new tests** in `tests/unit/process/` covering:
  - `test_errors.py` — taxonomy + attribute pinning.
  - `test_run.py` — basic run, error paths, log streaming
    (per-line records, level mapping, command_id/pid extras),
    name option, duration accuracy.
  - `test_readiness.py` — every predicate (PortReady,
    HttpReady, LogLineReady, CallableReady, AllOf, AnyOf) +
    composite short-circuit + `wait_for_ready` semantics.
  - `test_service.py` — context-manager + explicit start/stop
    + idempotency + readiness-failure with no-leak guarantee
    + LogLineReady stdout/stderr matching + composite probes
    + property accessors. Uses Python one-liner subprocesses as
    "services" — zero external dependencies.
- **Stability tier:** every name ships `experimental` per AP-11.
  Promotion to `stable` after one full MINOR cycle without a 🔴
  Blocker filed against any name (rule AP-11). Two consumers
  exercising real workloads is the practical bar.
- **Out of scope (deliberate):** restart-on-crash supervision
  (use systemd / supervisord), backoff machinery, multi-service
  declarative orchestration (compose `Service` context managers
  via `ExitStack`), shell-string commands (lists only —
  command-injection-safe by construction), async API
  (`mgf.common.process._aio` deferred to future when a consumer
  needs it).

---

## [0.20.0] — 2026-05-07

PyPI: <https://pypi.org/project/mgf-common/0.20.0/> · Tag: `v0.20.0`

> **Cutover guide:** [`docs/cutover/archive/v0.20.0.md`](docs/cutover/archive/v0.20.0.md)
> — documentation polish release. Three closures, all docs-only:
> framework-owned-logging recipe, `docs/standards/web/` subtree
> opening, and the documented-non-adoption principle.

**Code change:** none. `__version__` bumps from 0.19.0 → 0.20.0
to ship the new docs through the wheel's `_standards/` data
(per `[tool.hatch.build.targets.wheel.force-include]`). Standards
docs reach consumers via `mgf-common standards <topic>` so the
new paths need to land in a real release.

### Documentation

- **`docs/recipes/framework-owned-logging.md`** (closes
  [PAPER-25](FEEDBACK.md)) — promotes the
  `bootstrap(setup_logging=False)` pattern from v0.19.0's
  cutover guide to a permanent recipe with Django + FastAPI +
  Flask sections, a what-`setup_logging=False`-preserves table,
  and an explicit "what you give up" list. Cutover guides are
  time-bounded; framework-owned logging is the durable shape
  every web/API consumer needs on day one.
- **`docs/standards/web/README.md`** (closes
  [ASPIRE-03](FEEDBACK.md), Approach A — incremental) — opens
  the web-domain narrative subtree as a navigation page. Lists
  the cross-cutting recipes (currently scattered across
  cutover guides + `docs/recipes/`) and gives a
  read-in-order narrative for a new web consumer. Per-recipe
  promotion (cloud-native logging, framework config, http
  exceptions, bootstrap, stub-gaps, adoption-walk) trickles in
  over subsequent releases — each as one focused PR.
- **`docs/standards/principles/non-adoption-is-valid.md`**
  (closes [ASPIRE-04](FEEDBACK.md), "Magogi-foundation
  principle") — codifies "documented non-adoption is a
  first-class outcome of standards conformance." The framing
  behind every shipped carve-out (LOG-01, CONFIG-01,
  BOOTSTRAP-01); naming it gives newer contributors cover to
  decline a primitive when adoption would harm their context,
  AND nudges them to file the rationale upstream so the
  carve-out can be generalised. Three components: conscious
  decline, documented rationale, feedback if generalizable.
  Plus three worked examples (inthewords' LOG-01 / BOOTSTRAP-01
  pre-v0.19.0; PlasmaMapper's "small consumer" scope
  discipline).
- **`docs/standards/README.md`** — Conformance section grew a
  "Documented non-adoption preserves conformance" paragraph
  pointing at the new principle doc; "Per-kind subtrees"
  pointer to `web/README.md` added.

### Engineering

- The "incremental Approach A" structuring for ASPIRE-03 means
  v0.20.0 ships the front door; per-recipe promotion lands as
  small PRs across subsequent releases, tracked in ASPIRE-03's
  Retrospective field. This is the first release that uses an
  explicit promotion-roadmap checklist as a release artifact.
- v0.20.0 is the first **docs-only** release for `mgf-common`.
  It tests the release pipeline's tolerance for zero
  Python-surface-change releases.

---

## [0.19.0] — 2026-05-07

PyPI: <https://pypi.org/project/mgf-common/0.19.0/> · Tag: `v0.19.0`

> **Cutover guide:** [`docs/cutover/archive/v0.19.0.md`](docs/cutover/archive/v0.19.0.md)
> — composition + framework-native batch. Closes the v0.18.0
> HTTP-01 keystone (PAPER-24) and the Django adoption blocker
> (BOOTSTRAP-01).

### Fixed

- **`ExceptionTranslationMiddleware` now reads `HttpError.http_status`**
  (closes [PAPER-24](FEEDBACK.md)) — the v0.18.0 architectural
  batch shipped HTTP-01 (`HttpError` + 9 status-bearing concretes,
  each with `http_status: int` class attribute) AND the FastAPI
  middleware, but they didn't compose: a consumer rooting a domain
  exception in `HttpNotFound` still had to register every leaf in
  `status_map` for the middleware to find the 404. Resolution
  order is now: `status_map` (non-`AppError` ancestors) →
  class-declared `http_status` → `status_map[AppError]` catch-all
  → 500. Backward compatible — explicit `status_map` entries still
  win as the override seam. Regression introduced in v0.18.0;
  unblocks PlasmaMapper's `TenantNotFoundError(HttpNotFound)`
  rebase.

### Added

- **`bootstrap(setup_logging=True)` keyword-only flag** (closes
  [BOOTSTRAP-01](FEEDBACK.md) — Django adoption blocker, part 2)
  — when `False`, the StreamHandler + RotatingFileHandler install
  + per-component `level_overrides` are skipped. Identity, OTel,
  excepthooks, AppContext registration, and the bootstrap-log
  buffer replay still happen. For consumers whose framework owns
  the logging stack: Django (`LOGGING` dictConfig), FastAPI/
  uvicorn, Flask (`app.logger`), Pyramid. Default `True`
  preserves v0.18 behaviour for every existing consumer.
- **`mgf.common.alembic.configure_env` accepts `include_object=`
  + `include_schemas=`** (closes [PAPER-22](FEEDBACK.md)) —
  pass-through to `alembic.context.configure(...)`. Unblocks
  PostGIS / TimescaleDB / pgvector consumers who need to filter
  extension-owned tables (`spatial_ref_sys`,
  `_timescaledb_internal`, …) from `alembic revision
  --autogenerate`. Defaults `None` / `False` match alembic's own
  defaults — no behaviour change for current users.

### Changed

- **`settings_config()` defaults `dotenv_filtering="match_prefix"`**
  (closes [BOOTSTRAP-01](FEEDBACK.md) — Django adoption blocker,
  part 1) — `BaseAppSettings` subclasses now silently ignore
  `.env` keys that don't match their `env_prefix`, instead of
  routing them to `extra="forbid"` and raising `ValidationError`.
  This lets a `.env` be shared between mgf-common (`MGF_*`) and
  the consumer's framework (Django `SECRET_KEY`/`DB_*`,
  SQLAlchemy `DATABASE_URL`, Celery `CELERY_BROKER_URL`, …).
  **Behaviour change for consumers with `extra="allow"`** that
  were relying on the legacy permissive dotenv source to surface
  unprefixed keys onto the model — pass `dotenv_filtering=None`
  in your `model_config` override to restore the old behaviour.
  Every other `extra` mode is unaffected (`forbid` was raising
  before, `ignore` was already silent).

### Documentation

- **Editable-install caveat for `pytest_plugin`** (closes
  [PAPER-23](FEEDBACK.md)) — note added to
  `mgf.common.pytest_plugin` docstring + `docs/recipes/
  testing.md` explaining that `uv sync` against a sibling editable
  source target does not write the dist-info `entry_points.txt`,
  so the `pytest11` auto-registration is silently skipped. Opt
  in via `pytest_plugins = ["mgf.common.pytest_plugin"]` in
  consumer `tests/conftest.py`. PyPI-installed consumers are
  unaffected — the entry point fires during `pip install` /
  `uv pip install`.

### Engineering

- 4 new entries triaged + closed in one batch (PAPER-22, PAPER-23,
  PAPER-24, BOOTSTRAP-01); two from PlasmaMapper, one composite
  from inthewords. v0.19.0 is the first release that closed a
  same-release-introduced regression (PAPER-24 was a v0.18.0
  miss).

---

## [0.18.0] — 2026-05-06

PyPI: <https://pypi.org/project/mgf-common/0.18.0/> · Tag: `v0.18.0`

> **Cutover guide:** [`docs/cutover/archive/v0.18.0.md`](docs/cutover/archive/v0.18.0.md)
> — first release using the cutover-guide pattern (REL-09
> delivery mechanism). Read it for migration instructions per
> closed entry.

### Added

- **`HttpError` category in `mgf.common.exceptions`** (closes
  [HTTP-01](FEEDBACK.md)) — eighth category in the typed-
  exception taxonomy. `HttpError` base + `HttpClientError`
  (4xx) + `HttpServerError` (5xx) + nine concrete leaves
  (`HttpBadRequest` 400, `HttpUnauthorized` 401, `HttpForbidden`
  403, `HttpNotFound` 404, `HttpConflict` 409, `HttpGone` 410,
  `HttpUnprocessable` 422, `HttpInternalServerError` 500,
  `HttpServiceUnavailable` 503). Each carries `http_status: int`
  as a class attribute. 12 new names in
  `mgf.common.exceptions.__all__`, all stability tier
  `experimental`. Distinct from `ResourceNotFoundError`
  (provider-domain) by deliberate non-inheritance.
- **Framework-native config carve-out in `CONFIGURATION.md`
  §0a** (closes [CONFIG-01](FEEDBACK.md)) — explicit
  recognition that Django (and Rails-equivalent) consumers
  can't simultaneously be CF-* compliant and use
  `from django.conf import settings`. CF-01 / CF-04 / CF-08 /
  CF-09 declared N/A under framework-native; CF-02 / CF-05 /
  CF-10 / CF-12 still apply with framework-native mechanics.
  Worked example for `inthewords` (Django) included.
- **Per-rule applicability column on standards docs** (closes
  [LOG-02](FEEDBACK.md), [CONFIG-01](FEEDBACK.md)) — `Applies
  to` column on every LG-* and CF-* rule with values from
  `{all, gui-app, service, fastapi, django, cli, library,
  consumer-owned-config}`. Per-kind compliance matrix added at
  the top of `LOGGING.md`'s Rules box. `mgf-common catch-up`
  and future audit tooling filter by detected kind so
  non-applicable rules don't surface as violations.
- **Cloud-native logging recipe** (closes
  [LOG-01](FEEDBACK.md)) — new doc at
  `docs/recipes/cloud-native-logging.md` walks the
  stdout-only `MgfSettings` shape, the JSON-formatter choice,
  the deployment-time check ("the platform IS my rotating
  file sink"), and the `inthewords` worked example
  (Daphne → systemd journal → Promtail → Grafana Cloud).
- **Cutover-guide pattern** (maintainer-initiated process
  improvement) — new directory `docs/cutover/` with one
  file per release that closes ≥1 FEEDBACK entry. The first
  cutover guide is `docs/cutover/archive/v0.18.0.md` (this release's
  artifact). `RELEASING.md` §7.0 + REL-09 updated to make
  cutover guides the canonical migration source; per-PAPER
  notification paragraphs become pointers into them.

### Changed

- **LG-06 wording** (closes [LOG-01](FEEDBACK.md)) — revised
  to parameterise on deployment topology. Three first-class
  branches: rotating local file (desktop / single-server),
  process stdout/stderr (cloud-native / container), or remote
  sink (OTLP / syslog / HTTP webhook). "Console only, no
  aggregation" is non-compliant in production regardless of
  branch. The desktop branch's prescription is unchanged
  (no regression for VManager-shape consumers).
- **`STRATEGIC_REVIEW.md` Priority 1 marked ✅ ACHIEVED**
  (closes [ASPIRE-02](FEEDBACK.md)) — `inthewords` and
  `PlasmaMapper` arrived as the second + third independent
  consumers. PAPER-06 (reference-consumer restructure)
  unblocks for follow-up. PAPER-10 (entry-point auto-discovery)
  receives "non-pain" evidence: `inthewords` reports they
  don't need entry-point discovery; PAPER-10 stays DEFERRED.

### Fixed

- **FastAPI kind template's quick-start no longer imports
  from a private module** (closes [PAPER-21](FEEDBACK.md)) —
  one-line fix: `from mgf.common._lifecycle import bootstrap`
  → `from mgf.common import bootstrap`. The same audit that
  flags private imports on consumer src/ now also lints every
  rendered kind-template (cli / fastapi / django / library /
  service) via the new `TestQuickStartBlocksNoClosedBoxLeaks`
  regression guard. Audit-and-template asymmetry can't recur.

### Migration

See [`docs/cutover/archive/v0.18.0.md`](docs/cutover/archive/v0.18.0.md) — one
§ per closed entry with concrete steps. Headlines:

- **Pin bump:** `mgf-common = ">=0.18,<0.19"`.
- **HTTP consumers:** lift exception hierarchies onto the new
  `HttpError` category (Approach A). Existing project-level
  `AppError` shims keep working unchanged; the migration is
  structural and lands when you're ready.
- **Django consumers:** re-read `CONFIGURATION.md` §0a; declare
  CF-* applicability per the worked example.
- **Cloud-native consumers:** read the new
  `cloud-native-logging.md` recipe.
- **FastAPI consumers scaffolded against 0.17.2:** re-run
  `mgf-common catch-up --apply` to refresh the auto-block; if
  you copy-pasted the v0.17.2 quick-start, replace the
  private-module import.

---

## [0.17.2] — 2026-05-05

PyPI: <https://pypi.org/project/mgf-common/0.17.2/> · Tag: `v0.17.2`

### Added

- **`mgf-common catch-up` kind detection** (closes
  [PAPER-13](FEEDBACK.md) + [PAPER-17](FEEDBACK.md)).
  `_resolve_project_identity` now infers `--kind` heuristically
  when not supplied:
  - **With `pyproject.toml`:** parse `[project] dependencies`
    + `[project.scripts]`. `fastapi` → `fastapi`; `django` →
    `django`; `flask` → `service` (closest existing template
    kind); non-empty scripts without framework → `cli`;
    otherwise → `library`.
  - **Without `pyproject.toml`:** `manage.py` at root → `django`
    (Django's canonical layout marker). Other no-pyproject
    shapes fall through to `library`.
  - Default still `library` when no marker fires.
- **`mgf-common catch-up --apply` bootstraps `docs/CLAUDE.md`
  BEGIN/END markers** when the file exists but lacks them
  (closes [PAPER-16](FEEDBACK.md)). `_apply_bootstrap_claude_md_markers`
  reads the existing CLAUDE.md, backs it up to
  `.bak.<timestamp>`, writes a new file with the auto-block
  at the top + the original content verbatim below. The
  destructive `init-project --force` workaround is no longer
  the documented path; `catch-up --apply` is non-destructive.

### Changed

- **`mgf-common catch-up` pin audit emits a tailored info-level
  message for pip-tools layouts** (partial close of
  [PAPER-15](FEEDBACK.md)). When `pyproject.toml` is absent
  but `requirements/*.{txt,lock}` or a top-level
  `requirements.txt` is present, the audit acknowledges the
  layout and recommends the minimal-pyproject.toml workaround
  inline. Full pip-tools-manifest support (reading the pin
  from `requirements/base.txt`, four-gate audit from standalone
  config files) is deferred to a follow-up PAPER.

### Migration

None — every change is additive to existing CLI behaviour. No
public-Python-surface change. Re-run `mgf-common catch-up`
after upgrading to see the kind detection in action; existing
`--kind`-on-the-CLI invocations still take precedence over the
heuristic.

---

## [0.17.1] — 2026-05-05

PyPI: <https://pypi.org/project/mgf-common/0.17.1/> · Tag: `v0.17.1`

### Fixed

- **`mgf-common catch-up` v0.1-pattern audit no longer walks
  `.venv/`** (closes [PAPER-14](FEEDBACK.md)). The audit's
  `_count_matches` walk now applies the same skip-dirs filter
  (`tests/`, `.venv/`, `__pycache__/`, `.pytest_cache/`,
  `.mypy_cache/`, `.ruff_cache/`, etc.) that the closed-box-leak
  audit already used. Without the filter, audits on Django-shape
  projects (no `src/`) walked into `.venv/` and counted
  mgf-common's own deprecated shim definitions as user-source
  v0.1 call sites — dozens of false positives.
- **`mgf-common doctor` first-line banner reflects the imported
  package's `__version__`** (closes [PAPER-18](FEEDBACK.md)),
  not `importlib.metadata.version()`. The metadata path goes
  stale during editable-install dev workflows; reading
  `__version__` from the imported package always matches the
  live source tree per AP-13's sync rule.
- **`mgf-common <subcommand>` no longer emits
  `UnconfiguredWarning`** (closes [PAPER-19](FEEDBACK.md)). The
  CLI's `main()` calls `_set_identity("mgf-common-cli",
  __version__)` before dispatch, so subcommands that read
  identity (`explain`, `doctor`, future settings-aware
  surfaces) get the right values without firing the
  warning chain or printing `vunknown` placeholders. Lighter
  than the filing's suggested `bootstrap_for_test` because
  diagnostic CLIs MUST stay filesystem-side-effect-free.
- **`mgf-common catch-up --apply` no longer rewrites the
  pyproject pin against an editable install** (closes
  [PAPER-20](FEEDBACK.md)). Editable installs (e.g., `pip
  install -e ../mgf_common`, `[tool.uv.sources]` overrides) can
  run AHEAD of the latest PyPI-published version; rewriting a
  consumer's pin to the editable `__version__` produced an
  unsatisfiable pin on plain-PyPI resolvers. The audit row
  still surfaces staleness; the consumer bumps the pin by hand
  against `pip index versions mgf-common`.

### Migration

None — every change is a fix-in-place to existing CLI
behaviour. Re-run `mgf-common catch-up` after upgrading; you
may see fewer false positives on the v0.1-pattern row, a
correct version string on `doctor`'s banner, and clean stderr
on `explain`. Editable-install consumers see the audit warn
without auto-rewriting the pin.

---

## [0.17.0] — 2026-05-05

PyPI: <https://pypi.org/project/mgf-common/0.17.0/> · Tag: `v0.17.0`

### Added

- **`mgf-common catch-up` closed-box-leak audit** — a new audit
  row that AST-walks the consumer's `src/` and flags imports of
  `mgf-common`'s private surface. Closes [PAPER-08](FEEDBACK.md).

  Three leak shapes detected:

  1. `from mgf.common._x import …`     — module itself private
  2. `from mgf.common.X import _y`     — public module, private name
  3. `import mgf.common._x`            — direct private-module import

  The consumer's `tests/` directory is exempt (legitimate
  test-helper imports inside `_internal_test_helpers/` style
  directories aren't violations). Caches and vendored
  directories (`.venv/`, `__pycache__/`, `.pytest_cache/`,
  `.mypy_cache/`, `.ruff_cache/`, `node_modules/`, `dist/`,
  `build/`, `.tox/`) are skipped.

  Known private→public migrations are named inline in the
  warning so the audit doesn't just say "stop" — it says "do
  this instead." Today's mapping:

  | Private | Public (since) |
  |---|---|
  | `_default_log_path` | `mgf.common.observability.default_log_path` (v0.13.0) |
  | `_crash_dir` | `mgf.common.observability.default_crash_dir` (v0.13.0) |

  Extend `_PRIVATE_TO_PUBLIC` in `_catch_up.py` whenever a
  future PAPER-07-shaped private→public promotion happens.

### Migration

Consumers running `mgf-common catch-up` after upgrading will
see one new audit row. If you have any closed-box leaks in
your `src/` (you might — VManager had one until v0.13.0),
they surface now with the file:line and the suggested public
replacement. Like the existing `v0.1-pattern usage` row, the
fix is structural — `catch-up --apply` does NOT auto-rewrite
import statements; the consumer migrates by hand.

---

## [0.16.0] — 2026-05-02

PyPI: <https://pypi.org/project/mgf-common/0.16.0/> · Tag: `v0.16.0`

### Changed

- **Renamed** `docs/standards/SECURITY.md` →
  `docs/standards/SECURITY_STANDARD.md` to remove the
  duplicate-name collision with the repository-root
  `SECURITY.md` (vulnerability-reporting policy). The two files
  serve genuinely different purposes — SC-12 mandates the root
  policy file; the engineering standard now has a name that
  reflects what it is. The wheel's bundled-data path changes
  in lockstep: `mgf/common/_standards/SECURITY.md` →
  `mgf/common/_standards/SECURITY_STANDARD.md`.

### Migration

The CLI alias `security` keeps working unchanged — typing
`mgf-common standards security` still resolves to the engineering
standard. Both lower- (`security`) and upper-case (`SECURITY`)
inputs route through the alias map to the new canonical filename.

If your tooling parses `mgf-common standards --paths security`
output, the printed path now ends in `SECURITY_STANDARD.md`
rather than `SECURITY.md`. Update any consumer scripts that
hard-coded the old filename.

```bash
# Before — outputs .../SECURITY.md
$ mgf-common standards --paths security

# After (0.16+) — outputs .../SECURITY_STANDARD.md
$ mgf-common standards --paths security
```

The `mgf-common standards security` (no `--paths`) print-content
behaviour is unchanged.

---

## [0.15.0] — 2026-05-02

PyPI: <https://pypi.org/project/mgf-common/0.15.0/> · Tag: `v0.15.0` · SHA256 (wheel): `ad14d4ed17ca…`

### Added

- **`mgf.common.exceptions.AppConfigErrorKind`** — `StrEnum`
  discriminator for `AppConfigError` failure modes. Members:
  `FILE_NOT_FOUND`, `IO_READ_FAILED`, `JSON_PARSE_FAILURE`,
  `YAML_PARSE_FAILURE`, `NON_DICT_ROOT`, `MISSING_VERSION`,
  `UNSUPPORTED_VERSION`, `MIGRATE_FAILED`, `SCHEMA_VALIDATION`.
  String values are stable contract — usable as a machine-readable
  kind in serialised crash reports.
- **`AppConfigError.kind: AppConfigErrorKind | None`** — class-level
  attribute (default `None`). Every load-path raise in
  `mgf.common.versioned._store` now sets `kind`. Consumers stop
  string-matching on private message markers and discriminate via
  `match e.kind:`. Closes [PAPER-11](FEEDBACK.md).

### Migration

For consumers translating `AppConfigError` to project-flavoured
wording — replace string-match discriminators with
pattern-matching on `kind`:

```python
# Before — fragile to upstream rewording
except AppConfigError as e:
    raw = str(e).lower()
    if "is malformed (json)" in raw:
        raise OperationError("... is unreadable") from e
    elif "has version=" in raw or "is missing a typed" in raw:
        raise OperationError("... has unsupported schema_version") from e
    else:
        raise OperationError(f"... is malformed: {e}") from e

# After — typed, exhaustive, stable
except AppConfigError as e:
    match e.kind:
        case AppConfigErrorKind.JSON_PARSE_FAILURE | AppConfigErrorKind.YAML_PARSE_FAILURE:
            raise OperationError("... is unreadable") from e
        case AppConfigErrorKind.UNSUPPORTED_VERSION | AppConfigErrorKind.MISSING_VERSION:
            raise OperationError("... has unsupported schema_version") from e
        case _:
            raise OperationError(f"... is malformed: {e}") from e
```

Backward-compatible: every existing `except AppConfigError:` clause
keeps catching unchanged. Save-path raises don't yet opt in — file a
`PAPER-NN` if you hit pain there.

---

## [0.14.0] — 2026-05-02

PyPI: <https://pypi.org/project/mgf-common/0.14.0/> · Tag: `v0.14.0` · SHA256 (wheel): `5c172712f454…`

### Added

- **`VersionedFileStore[T](..., tolerate_missing_version=False)`** —
  new constructor flag. Default `False` keeps today's
  strict-by-default contract: missing `version:` field raises
  `AppConfigError`. `True` opts in to a grace mode for consumers
  with **pre-versioning legacy files**: a missing field logs one
  `WARNING` via the `mgf.common.versioned` logger and is treated as
  `current_version` (the migrate callback is NOT called — there is
  no version to migrate from). The next `save()` stamps the file,
  so the warning fires at most once per file. Files where the field
  is *present but not an int* still raise (corruption signal, not
  a legacy file). Closes [PAPER-09](FEEDBACK.md).

### Migration

Consumers with bespoke "missing means current" handling for
pre-versioning YAML/JSON satellite files can replace it with the
opt-in flag:

```python
store = VersionedFileStore(
    path,
    schema=ProfileFile,
    current_version=2,
    migrate=migrate,
    tolerate_missing_version=True,   # missing → v2 with WARNING
)
```

The grace-mode warning from `mgf.common.versioned` replaces any
hand-rolled warning the consumer was emitting.

---

## [0.13.0] — 2026-05-02

PyPI: <https://pypi.org/project/mgf-common/0.13.0/> · Tag: `v0.13.0` · SHA256 (wheel): `02d8ed8bc4b1…`

### Added

- **`mgf.common.observability.default_log_path`** — public helper
  that resolves to `<state>/<app>/logs/<app>.log`, where
  `<state>` honours `XDG_STATE_HOME` and falls back to
  `~/.local/state`. This is where `setup_logging` writes when
  called without an explicit `log_file=`. Surface in your UI for
  "where do my logs live?" diagnostics.
- **`mgf.common.observability.default_crash_dir`** — public helper
  resolving to `<state>/<app>/crashes/`. Where `report_now` writes
  serialised crash reports.
- **`mgf.common.observability.default_state_dir`** — public helper
  resolving to `<state>/<app>/`, the parent of both. The directory
  is NOT created — callers `mkdir` themselves if needed.

All three are lazy (resolve at call time, rule **CF-04**); per-test
isolation when monkeypatching `HOME` / `XDG_STATE_HOME` keeps
working. Closes [PAPER-07](FEEDBACK.md).

### Deprecated

- **`mgf.common.observability.logging_setup._default_log_path`** —
  was a closed-box leak (consumers had no public alternative). Now
  a deprecated shim that delegates to `default_log_path` and emits
  `MgfDeprecationWarning`. Removed in a future release.
- **`mgf.common.observability.crash_reporter._crash_dir`** — same
  shape; deprecated shim delegating to `default_crash_dir`.

### Migration

```python
# Before — reaching into the private surface (closed-box leak)
from mgf.common.observability.logging_setup import _default_log_path
from mgf.common.observability.crash_reporter import _crash_dir

# After — public API
from mgf.common.observability import default_log_path, default_crash_dir
```

The underscored names continue to work for one cycle but emit
`MgfDeprecationWarning` per call.

---

## Pre-`0.13.0`

Earlier releases (`0.1.0`, `0.3.0`, `0.4.0`, `0.4.1`, `0.4.2`,
`0.11.1`, `0.11.3`, `0.12.0`) were cut before this CHANGELOG was
introduced. The audit trail is in `git log` and the
[PyPI release pages](https://pypi.org/project/mgf-common/#history).

Notable ones (most relevant for consumers upgrading):

- **`0.12.0`** (2026-05-01) — final release before the CHANGELOG.
  Public surface that ships in this release matches the wheel on
  PyPI (`pip show mgf-common` against an installed `0.12.0`); note
  that **`mgf.common.versioned`** was added to master *after* the
  `0.12.0` PyPI cut — consumers reading `PUBLIC_API.md` from a
  master checkout may see entries that 0.12.0 doesn't ship. (This
  asymmetry is the root cause of [PAPER-12](FEEDBACK.md); the
  `PUBLIC_API.md` banner and the doc at
  [`docs/standards/RELEASING.md`](docs/standards/RELEASING.md)
  prevent its recurrence going forward.)

[Unreleased]: https://codeberg.org/magogi-admin/mgf_common/compare/v0.18.0...HEAD
[0.18.0]: https://codeberg.org/magogi-admin/mgf_common/releases/tag/v0.18.0
[0.17.2]: https://codeberg.org/magogi-admin/mgf_common/releases/tag/v0.17.2
[0.17.1]: https://codeberg.org/magogi-admin/mgf_common/releases/tag/v0.17.1
[0.17.0]: https://codeberg.org/magogi-admin/mgf_common/releases/tag/v0.17.0
[0.16.0]: https://codeberg.org/magogi-admin/mgf_common/releases/tag/v0.16.0
[0.15.0]: https://codeberg.org/magogi-admin/mgf_common/releases/tag/v0.15.0
[0.14.0]: https://codeberg.org/magogi-admin/mgf_common/releases/tag/v0.14.0
[0.13.0]: https://codeberg.org/magogi-admin/mgf_common/releases/tag/v0.13.0
