# Markdown to HTML compiler

![](https://github.com/brycekage/Markdown-Compiler/workflows/doctests/badge.svg)&nbsp;
![](https://github.com/brycekage/Markdown-Compiler/workflows/flake8/badge.svg)&nbsp;
![](https://github.com/brycekage/Markdown-Compiler/workflows/command_line/badge.svg)&nbsp;

A simple project for converting markdown files to HTML.

Basic usage:
```
$ markdown-compiler example/README.md
```

<img src='example/img/SS_MD12.png' width=300px>

Fancy CSS formatting can be included with the flag `--add_css`:
```
$ markdown-compiler example/README.md --add_css
```

<img src='example/img/SS_MD2.png' width=300px>
