from datetime import datetime
from pydantic import BeforeValidator, PlainSerializer
from typing import List, Annotated

from cidc_api.models.pydantic.base import Base
from cidc_api.models.types import TrialOrganization, TrialFundingAgency, AssayType, AgeGroup, PrimaryPurposeType


class Trial(Base):
    __data_category__ = "trial"
    __cardinality__ = None

    # A broad textual description of the primary endpoint(s) of the trial.
    primary_endpoint: str | None = None

    # The version number of the Master Appendix A used for the clinical trial.
    master_aa_version: int | None = None

    # The identifiable class of the study participant based upon their age.
    age_group: Annotated[List[AgeGroup], BeforeValidator(Base.to_list), PlainSerializer(Base.from_list)]

    # Clinical and/or molecular characteristics of the cancer(s) in the study population.
    study_population: str | None = None

    # The type of clinical trial conducted
    trial_type: str | None = None

    # The official day that study activity began
    # CDE: https://cadsr.cancer.gov/onedata/dmdirect/NIH/NCI/CO/CDEDD?filter=CDEDD.ITEM_ID=16333702%20and%20ver_nr=1
    dates_of_conduct_start: datetime

    # The official day that study activity ended
    # CDE: https://cadsr.cancer.gov/onedata/dmdirect/NIH/NCI/CO/CDEDD?filter=CDEDD.ITEM_ID=16333703%20and%20ver_nr=1
    dates_of_conduct_end: datetime | None = None

    # A classification of the study based upon the primary intent of the study's activities.
    # CDE: https://cadsr.cancer.gov/onedata/dmdirect/NIH/NCI/CO/CDEDD?filter=CDEDD.ITEM_ID=11160683%20and%20ver_nr=1
    primary_purpose_type: PrimaryPurposeType

    # The dbgap study accession number associated with the trial.
    dbgap_study_accession: str
