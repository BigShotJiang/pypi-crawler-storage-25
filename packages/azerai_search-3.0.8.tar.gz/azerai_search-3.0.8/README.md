# 🔍 AzerAI Search Plugin

**AzerAI** - Azərbaycan dilində qabaqcıl səsli AI asistenti üçün veb axtarış plugini.

## Xüsusiyyətlər

- 🔍 **Veb axtarışı** - Yandex ilə veb axtarışı
- 📰 **Son 10 nəticə** - Son 10 nəticəni göstərir
- 📊 **Nəticə formatı** - Səliqəli nəticə formatı
- 🎵 **Arxa plan musiqisi** - Əməliyyat zamanı musiqi
- 🎤 **Mikrofon kontrolü** - Əməliyyat zamanı danışığı bloklayır
- 🌐 **Azərbaycan dili** - Azərbaycan dilində axtarış
- 🔄 **Avtomatik qurulum** - Əgər Playwright brauzerləri qurulmayıbsa, ilk axtarış zamanı avtomatik olaraq qurulacaq. Qurulma tamamlanana qədər gözləyin.

## Quraşdırma

```bash
pip install AzerAI-Search
```

## İstifadə

Plugin avtomatik olaraq AzerAI tərəfindən aşkar edilir.

### Əmrlər

- `"Azərbaycan haqqında axtar"` - Veb axtarışı
- `"Son xəbərləri göstər"` - Xəbər axtarışı
- `"Python haqqında məlumat tap"` - Məlumat axtarışı
- `"İnternetsiz axtar"` - Müxtəlif nəticə tipi

## Fayl struktur

```
azerai_search/
├── plugins/
│   └── search/
│       ├── __init__.py
│       ├── main.py
│       ├── info.py
│       └── prompts.py
└── __init__.py
```

## Xüsusiyyətlər

### 🔍 **Veb Axtarışı**
- Yandex axtarış motoru
- Son 10 nəticəyə qədər
- Başlıq, təsvir və URL
- Azərbaycan dilində nəticələr

### 🎵 **Arxa Plan Musiqisi**
- Axtarış zamanı avtomatik musiqi
- 8 saniyəlik döngü
- Mikrofonu avtomatik bloklayır

### 📊 **Nəticə Formatı**
- Nəticə sayı
- Axtarış vaxtı
- Formatlanmış çıxış
- Linklər və təsvirlər

## Asılılıqlar

- `livekit-agents` - AI agent framework
- `requests` - HTTP sorğuları
- `beautifulsoup4` - HTML parsing
- `sounddevice` - Audio çalma
- `scipy` - Audio işləmə
- `playwright` - Veb avtomatlaşdırma

## 📄 Lisenziya

Bu layihə MIT Lisenziyası ilə lisenziyalaşdırılıb - [LICENSE](https://github.com/AzStudioDev/AzerAI-Search/blob/main/LICENSE) faylına baxın.

## 📞 Əlaqə

- **Müəllif:** AzStudio Dev
- **Email:** info.azstudiodev@gmail.com
- **GitHub:** https://github.com/AzStudioDev/AzerAI-Search
- **PyPI:** https://pypi.org/project/AzerAI-Search/

---

**🇦🇿 Azərbaycanın ilk tam plugin ekosistemli AI asistentinin Search plugini!** 🚀
