"""
AzerAI Search Plugin - Plugin package
"""
