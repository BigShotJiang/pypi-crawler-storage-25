"""
AzerAI Search Plugin - Veb axtarış plugini

Plugin əsaslı, çoxdilli AI asistenti üçün veb axtarış modulu.
"""

__version__ = "3.0.8"
__author__ = "AzStudio Dev"
__email__ = "info.azstudiodev@gmail.com"

from .plugins.search.main import yandex_search

__all__ = [
    "yandex_search"
]
