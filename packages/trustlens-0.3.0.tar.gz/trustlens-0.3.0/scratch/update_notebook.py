import json
import os

notebook_path = 'examples/trustlens_demo.ipynb'
with open(notebook_path, 'r') as f:
    nb = json.load(f)

new_cells = [
    {
        "cell_type": "markdown",
        "metadata": {},
        "source": [
            "## 7. Latent Space & Representation Analysis\n",
            "TrustLens can visualize how well your model separates different classes in its latent embedding space. This is critical for understanding if the model has learned robust features or if classes are overlapping dangerously.\n",
            "\n",
            "Supported methods include:\n",
            "- **UMAP**: Best for preserving local and global structure (requires `umap-learn`).\n",
            "- **t-SNE**: Traditional manifold visualization.\n",
            "- **PCA**: Linear projection (always available).\n",
            "\n",
            "If the required library (like `umap-learn`) is not installed, TrustLens **gracefully falls back** to the next best available method."
        ]
    },
    {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": [
            "# To visualize embeddings, we pass them to the analyze function.\n",
            "# For this demo, we'll treat the raw features as 'embeddings'.\n",
            "embeddings = X_val \n",
            "\n",
            "# Run a focused representation analysis\n",
            "report_rep = analyze(\n",
            "    model=model,\n",
            "    X=X_val,\n",
            "    y_true=y_val,\n",
            "    embeddings=embeddings,\n",
            "    modules=[\"representation\"]\n",
            ")\n",
            "\n",
            "# Visualize the 2D projection\n",
            "# If UMAP is installed, it will be used by default. \n",
            "# Here we explicitly use PCA for deterministic results in the demo.\n",
            "report_rep.plot_embedding_2d(method=\"pca\", show=True)"
        ]
    }
]

# Find where to insert. We'll insert after "## 6. Fairness Visualization" code cell.
target_header = "## 6. Fairness Visualization"
insert_index = -1

for i, cell in enumerate(nb['cells']):
    if cell['cell_type'] == 'markdown' and any(target_header in s for s in cell['source']):
        # Found the header, now skip the following code cell
        if i + 1 < len(nb['cells']):
            insert_index = i + 2
        break

if insert_index != -1:
    # Insert new cells
    nb['cells'][insert_index:insert_index] = new_cells
    
    # Also fix the duplicate "## 7." headers that were there before
    for cell in nb['cells']:
        if cell['cell_type'] == 'markdown':
            if any("## 7. Sub-Score Details" in s for s in cell['source']):
                cell['source'] = [s.replace("## 7.", "## 8.") for s in cell['source']]
            if any("## 7. Persisting Reports" in s for s in cell['source']):
                cell['source'] = [s.replace("## 7.", "## 9.") for s in cell['source']]

    with open(notebook_path, 'w') as f:
        json.dump(nb, f, indent=1)
    print(f"Successfully updated {notebook_path}")
else:
    print("Could not find insertion point")
