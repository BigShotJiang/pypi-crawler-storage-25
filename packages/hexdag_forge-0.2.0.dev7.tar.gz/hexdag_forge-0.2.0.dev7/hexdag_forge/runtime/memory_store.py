"""In-memory implementation of SupportsEntityStore.

No external dependencies — useful for testing, demos, and quick iteration.
"""

from __future__ import annotations

import uuid
from typing import Any


class InMemoryEntityStore:
    """Dict-backed entity store for testing and demos.

    Data is lost when the process exits. Each entity type is stored in
    a separate dict keyed by entity ID.
    """

    def __init__(self) -> None:
        self._data: dict[str, dict[str, dict[str, Any]]] = {}

    async def create(
        self, entity_type: str, data: dict[str, Any], initial_state: str
    ) -> dict[str, Any]:
        """Create a new entity with a generated UUID."""
        store = self._data.setdefault(entity_type, {})
        entity_id = str(uuid.uuid4())
        record = {"id": entity_id, "status": initial_state, **data}
        store[entity_id] = record
        return dict(record)

    async def get(self, entity_type: str, entity_id: str) -> dict[str, Any]:
        """Retrieve an entity by ID. Raises KeyError if not found."""
        store = self._data.get(entity_type, {})
        if entity_id not in store:
            msg = f"{entity_type} with id {entity_id!r} not found"
            raise KeyError(msg)
        return dict(store[entity_id])

    async def list_all(
        self,
        entity_type: str,
        status: str | None = None,
        limit: int = 50,
    ) -> list[dict[str, Any]]:
        """List entities, optionally filtered by status."""
        store = self._data.get(entity_type, {})
        records = list(store.values())
        if status is not None:
            records = [r for r in records if r.get("status") == status]
        return [dict(r) for r in records[:limit]]

    async def update(
        self, entity_type: str, entity_id: str, data: dict[str, Any]
    ) -> dict[str, Any]:
        """Update fields on an existing entity."""
        store = self._data.get(entity_type, {})
        if entity_id not in store:
            msg = f"{entity_type} with id {entity_id!r} not found"
            raise KeyError(msg)
        store[entity_id].update(data)
        return dict(store[entity_id])

    async def delete(self, entity_type: str, entity_id: str) -> dict[str, Any]:
        """Delete an entity. Raises KeyError if not found."""
        store = self._data.get(entity_type, {})
        if entity_id not in store:
            msg = f"{entity_type} with id {entity_id!r} not found"
            raise KeyError(msg)
        record = store.pop(entity_id)
        return {"deleted": True, "id": entity_id, "entity_type": entity_type, **record}

    async def transition(
        self,
        entity_type: str,
        entity_id: str,
        to_state: str,
        reason: str = "",
    ) -> dict[str, Any]:
        """Transition an entity to a new state."""
        store = self._data.get(entity_type, {})
        if entity_id not in store:
            msg = f"{entity_type} with id {entity_id!r} not found"
            raise KeyError(msg)
        record = store[entity_id]
        from_state = record["status"]
        record["status"] = to_state
        return {
            "id": entity_id,
            "entity_type": entity_type,
            "from_state": from_state,
            "to_state": to_state,
            "reason": reason,
            **record,
        }
