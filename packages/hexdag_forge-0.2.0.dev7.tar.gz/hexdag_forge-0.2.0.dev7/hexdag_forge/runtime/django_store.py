"""Django ORM implementation of SupportsEntityStore.

Uses ``django.apps.registry.apps.get_model()`` for dynamic model lookup,
matching forge's pattern where entity names map directly to Django model names.

Requires Django to be installed and configured (``DJANGO_SETTINGS_MODULE``).
"""

from __future__ import annotations

from typing import Any


class DjangoEntityStore:
    """Django ORM adapter for forge-generated entity models.

    Parameters
    ----------
    app_label:
        The Django app label (e.g. ``"freight_brokerage"``).
        Must match the app_label used by forge during generation.
    """

    def __init__(self, app_label: str) -> None:
        self._app_label = app_label

    def _get_model(self, entity_type: str) -> Any:
        """Resolve a Django model class from entity_type name."""
        from django.apps import apps  # type: ignore[import-not-found]  # noqa: PLC0415

        return apps.get_model(self._app_label, entity_type)

    @staticmethod
    def _to_dict(obj: Any) -> dict[str, Any]:
        """Convert a Django model instance to a dict."""
        from django.forms.models import (
            model_to_dict,  # type: ignore[import-not-found]  # noqa: PLC0415
        )

        d: dict[str, Any] = model_to_dict(obj)
        d["id"] = str(obj.pk)
        return d

    async def create(
        self, entity_type: str, data: dict[str, Any], initial_state: str
    ) -> dict[str, Any]:
        """Create a new entity record via Django ORM."""
        from asgiref.sync import sync_to_async  # type: ignore[import-not-found]  # noqa: PLC0415

        model = self._get_model(entity_type)
        obj = await sync_to_async(model.objects.create)(**data, status=initial_state)
        return self._to_dict(obj)

    async def get(self, entity_type: str, entity_id: str) -> dict[str, Any]:
        """Retrieve a single entity by primary key."""
        from asgiref.sync import sync_to_async  # type: ignore[import-not-found]  # noqa: PLC0415

        model = self._get_model(entity_type)
        obj = await sync_to_async(model.objects.get)(pk=entity_id)
        return self._to_dict(obj)

    async def list_all(
        self,
        entity_type: str,
        status: str | None = None,
        limit: int = 50,
    ) -> list[dict[str, Any]]:
        """List entities, optionally filtered by status field."""
        from asgiref.sync import sync_to_async  # type: ignore[import-not-found]  # noqa: PLC0415

        model = self._get_model(entity_type)
        qs = model.objects.all()
        if status is not None:
            qs = qs.filter(status=status)
        qs = qs[:limit]
        objects = await sync_to_async(list)(qs)
        return [self._to_dict(obj) for obj in objects]

    async def update(
        self, entity_type: str, entity_id: str, data: dict[str, Any]
    ) -> dict[str, Any]:
        """Update fields on an existing entity."""
        from asgiref.sync import sync_to_async  # type: ignore[import-not-found]  # noqa: PLC0415

        model = self._get_model(entity_type)
        obj = await sync_to_async(model.objects.get)(pk=entity_id)
        for key, value in data.items():
            setattr(obj, key, value)
        await sync_to_async(obj.save)()
        return self._to_dict(obj)

    async def delete(self, entity_type: str, entity_id: str) -> dict[str, Any]:
        """Delete an entity by primary key."""
        from asgiref.sync import sync_to_async  # type: ignore[import-not-found]  # noqa: PLC0415

        model = self._get_model(entity_type)
        obj = await sync_to_async(model.objects.get)(pk=entity_id)
        result = self._to_dict(obj)
        await sync_to_async(obj.delete)()
        return {"deleted": True, **result}

    async def transition(
        self,
        entity_type: str,
        entity_id: str,
        to_state: str,
        reason: str = "",
    ) -> dict[str, Any]:
        """Transition an entity to a new state by updating the status field."""
        from asgiref.sync import sync_to_async  # type: ignore[import-not-found]  # noqa: PLC0415

        model = self._get_model(entity_type)
        obj = await sync_to_async(model.objects.get)(pk=entity_id)
        from_state = obj.status
        obj.status = to_state
        await sync_to_async(obj.save)(update_fields=["status"])
        return {
            "id": str(obj.pk),
            "entity_type": entity_type,
            "from_state": from_state,
            "to_state": to_state,
            "reason": reason,
            "status": to_state,
        }
