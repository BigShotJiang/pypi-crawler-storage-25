"""SupportsEntityStore — port protocol for forge-generated services.

Forge-generated services call ``self._db.create()``, ``.get()``,
``.list_all()``, ``.update()``, ``.delete()``, and ``.transition()``.
This protocol formalises that interface so adapters can be swapped
(Django ORM, in-memory, SQLAlchemy, etc.).
"""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class SupportsEntityStore(Protocol):
    """CRUD + state-transition storage for forge-generated entities."""

    async def create(
        self, entity_type: str, data: dict[str, Any], initial_state: str
    ) -> dict[str, Any]:
        """Create a new entity record.

        Returns:
            Dict with at least ``id`` and ``status`` keys.
        """
        ...

    async def get(self, entity_type: str, entity_id: str) -> dict[str, Any]:
        """Retrieve a single entity by ID."""
        ...

    async def list_all(
        self,
        entity_type: str,
        status: str | None = None,
        limit: int = 50,
    ) -> list[dict[str, Any]]:
        """List entities, optionally filtered by status."""
        ...

    async def update(
        self, entity_type: str, entity_id: str, data: dict[str, Any]
    ) -> dict[str, Any]:
        """Update fields on an existing entity."""
        ...

    async def delete(self, entity_type: str, entity_id: str) -> dict[str, Any]:
        """Delete an entity. Returns metadata about the deletion."""
        ...

    async def transition(
        self,
        entity_type: str,
        entity_id: str,
        to_state: str,
        reason: str = "",
    ) -> dict[str, Any]:
        """Transition an entity to a new state."""
        ...
