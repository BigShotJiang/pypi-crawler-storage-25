"""Runtime adapters for forge-generated systems."""
