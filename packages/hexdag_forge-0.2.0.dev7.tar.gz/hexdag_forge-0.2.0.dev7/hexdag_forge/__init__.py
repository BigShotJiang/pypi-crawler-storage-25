"""hexdag-forge — Build operational systems from prompts."""

__version__ = "0.1.0"
