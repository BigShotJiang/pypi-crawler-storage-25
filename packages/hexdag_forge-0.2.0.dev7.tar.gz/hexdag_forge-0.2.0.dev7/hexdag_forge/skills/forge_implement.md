---
name: forge:implement
description: Implement a service stub method with business logic
---

Fill in NotImplementedError stubs in generated services with actual business logic.

## Steps

1. Call `forge_list_stubs` to see all stubs that need implementation
   - Shows: service name, method name, docstring with expected behavior

2. If the user specifies which stub, proceed. Otherwise ask them to pick one.

3. Call `forge_get_profile` to understand the entity fields, states, and relationships — this provides context for writing the implementation.

4. Write the implementation code:
   - The code should replace the `raise NotImplementedError(...)` line
   - Keep the same indentation level (8 spaces)
   - Use `self._db` for database operations
   - Return a dict with the result

5. Call `forge_implement_stub` with the service name, method name, and implementation code.

6. Call `forge_validate` to verify the implementation has valid syntax.

## Example

For a stub like `negotiate_rate_with_carrier`:
```python
        # Compare offered rate vs target
        load = await self._db.get("load", load_id)
        target = load.get("target_rate", 0)
        offered = kwargs.get("offered_rate", 0)
        if offered <= target:
            return {"action": "accept", "rate": offered}
        counter = target * 1.05
        return {"action": "counter", "counter_rate": counter}
```
