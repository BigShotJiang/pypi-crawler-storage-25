---
name: forge
description: Generate an operational system from a business description
---

Generate a complete operational system (pipelines, services, Django models, state machines) from the user's business description.

## Steps

1. Call `forge_profile_schema` to get the exact BusinessProfile JSON schema.

2. Analyze the user's business description and build a complete BusinessProfile JSON:
   - Extract entities (the nouns: orders, customers, shipments, etc.)
   - For each entity define: fields (with types), states (lifecycle), transitions, relationships
   - Entity names must be snake_case Python identifiers
   - Every entity needs at least 2 states and a valid initial_state
   - Transitions must only reference declared states
   - Add workflows: domain-specific business logic that goes beyond CRUD
   - Show the profile to the user and ask for confirmation before generating

3. Call `forge_generate` with the validated profile JSON and an output directory.
   - This also creates an initial Django migration (`0001_auto.py`)

4. Show the user a summary of what was generated:
   - Entity names, their fields and states
   - Generated pipeline files
   - Generated service files (CRUD methods + domain stubs)
   - Initial migration file

5. Ask if the user wants to refine:
   - If yes, call `forge_get_profile` to load the current profile
   - Modify the JSON with the user's changes
   - Call `forge_migrate` with the updated profile (this diffs and generates a new migration)
   - Show what changed and the migration that was produced

6. List stubs that need implementation:
   - Call `forge_list_stubs` to show NotImplementedError methods
   - Ask if the user wants to implement any of them

7. Validate the output:
   - Call `forge_validate` to check all files are valid

## Field Types

str, int, float, Decimal, bool, datetime, date, text, email, url, json

## Relationship Kinds

belongs_to, has_many, has_one

## Notes

- The generated system includes: system.yaml, YAML pipelines, Python services, Django models, state machines, migrations
- Services have `@tool`/`@step` decorated CRUD methods (fully implemented) and domain-specific stubs (NotImplementedError)
- The system.yaml uses hexDAG's `kind: System` with LifecycleRunner (state machine driven)
- profile.json is saved in the output directory for future refinement
- Use `forge_generate` for new systems, `forge_migrate` for updates to existing systems
