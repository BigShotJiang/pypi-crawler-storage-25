---
name: forge:entity
description: Add or modify an entity type in a generated forge system
---

Add or modify entities in a previously generated system. Uses `forge_migrate` to diff profiles and generate Django migrations automatically.

## Adding an entity

1. Call `forge_get_profile` to load the current BusinessProfile from the output directory
2. Call `forge_profile_schema` if you need to check the exact field/entity schema
3. Build the new EntitySpec from the user's description (name, fields, states, transitions, relationships)
4. Add it to the profile's entities list
5. Call `forge_migrate` with the updated profile JSON — this diffs, regenerates, and writes a migration
6. Show the user the migration that was generated (CreateModel with all fields)

## Modifying an entity

1. Call `forge_get_profile` to load the current profile
2. Modify the entity in the JSON with the user's requested changes
3. Call `forge_migrate` with the updated profile — migration captures field/state changes (AddField, AlterField, etc.)

## Removing an entity

1. Call `forge_get_profile` to load the current profile
2. Remove the entity from the entities list
3. Remove any relationships that reference the removed entity
4. Call `forge_migrate` with the updated profile — migration includes DeleteModel

## Notes

- Entity names must be valid Python identifiers (snake_case)
- Every entity needs at least 2 states and a valid initial_state
- Transitions must only reference declared states
- Relationships use: belongs_to, has_many, has_one
- `forge_migrate` preserves migration history — each change gets its own migration file
- Regeneration overwrites all code files — any manual edits to services will be lost
