---
name: forge:test
description: Validate and test a generated forge system
---

Validate generated files and check consistency.

## Steps

1. Call `forge_validate` with the output directory
   - Checks: required files exist, Python syntax valid, profile.json valid, YAML files present

2. If there are errors, show them and suggest fixes.

3. For deeper testing:
   - Read the generated pipeline YAML files and check they reference valid services
   - Read the system.yaml and verify state machines and processes are consistent
   - Check that all entity states referenced in transitions are declared

## Notes

- `forge_validate` does not execute pipelines — it only checks file structure and syntax
- For runtime testing, the user needs to install the generated system and run it with hexDAG
