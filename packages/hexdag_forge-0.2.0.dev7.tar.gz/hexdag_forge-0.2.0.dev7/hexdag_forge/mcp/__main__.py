"""Entry point for running the forge MCP server via `python -m hexdag_forge.mcp`."""

from hexdag_forge.mcp.server import mcp

mcp.run(transport="stdio")
