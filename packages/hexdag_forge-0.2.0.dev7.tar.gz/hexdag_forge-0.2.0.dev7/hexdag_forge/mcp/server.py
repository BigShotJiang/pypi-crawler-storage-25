"""MCP server for hexdag-forge.

Exposes forge tools via FastMCP so Claude Code can generate
and manage operational systems.

Usage:
    hexdag-forge mcp serve              # stdio (for Claude Code)
    hexdag-forge mcp serve --transport sse --port 3001
"""

from __future__ import annotations

import json
from pathlib import Path

from mcp.server.fastmcp import FastMCP

from hexdag_forge.domain.business_profile import BusinessProfile
from hexdag_forge.generator.assembler import assemble, validate_system

mcp = FastMCP(
    "hexdag-forge",
    instructions="Generate operational systems (ERP/TMS/CRM) from business descriptions. "
    "Use forge_profile_schema to get the BusinessProfile JSON schema, "
    "build the profile JSON yourself, then call forge_generate to create the system. "
    "Use forge_migrate to update an existing system (diffs profiles and generates "
    "Django migrations). Use forge_get_profile to inspect, forge_list_stubs to find "
    "methods that need implementation.",
)


@mcp.tool()
async def forge_profile_schema() -> str:
    """Get the JSON schema for BusinessProfile.

    Returns the full Pydantic JSON schema describing entities, fields,
    states, transitions, and relationships. Use this to understand the
    exact structure needed for forge_generate.
    """
    return json.dumps(BusinessProfile.model_json_schema(), indent=2)


@mcp.tool()
async def forge_generate(profile_json: str, output_dir: str = "./generated") -> str:
    """Generate a complete operational system from a BusinessProfile JSON.

    Analyze the user's business description yourself, build a BusinessProfile
    JSON (see forge_profile_schema for the schema), and pass it here.

    Creates YAML pipelines, Python services, Django models, state machines,
    and a kind: System manifest in the output directory.
    """
    profile = BusinessProfile.model_validate_json(profile_json)
    result = assemble(profile, Path(output_dir))

    return json.dumps(
        {
            "output_dir": str(output_dir),
            "business_name": result.profile.business_name,
            "entities": [
                {
                    "name": e.name,
                    "display_name": e.display_name,
                    "fields": len(e.fields),
                    "states": e.states,
                }
                for e in result.profile.entities
            ],
            "pipelines": list(result.pipelines.keys()),
            "base_services": list(result.base_services.keys()),
            "services": list(result.services.keys()),
        },
        indent=2,
    )


@mcp.tool()
async def forge_validate(output_dir: str) -> str:
    """Validate all generated files in a directory.

    Checks: required files exist, Python syntax valid, profile.json valid.
    """
    errors = validate_system(Path(output_dir))
    return json.dumps({"valid": len(errors) == 0, "errors": errors}, indent=2)


@mcp.tool()
async def forge_migrate(new_profile_json: str, output_dir: str = "./generated") -> str:
    """Update an existing system with a new profile and generate a Django migration.

    Reads the current profile.json from output_dir, diffs it against the new
    profile, regenerates all files, and writes a Django migration file for the
    schema changes. Use this instead of forge_generate when modifying an
    existing system.
    """
    from hexdag_forge.generator.diff import diff_profiles
    from hexdag_forge.generator.migration_generator import generate_migration

    output = Path(output_dir)
    profile_path = output / "profile.json"
    if not profile_path.exists():
        return json.dumps({"error": f"No profile.json in {output_dir} — use forge_generate first"})

    old_profile = BusinessProfile.model_validate_json(profile_path.read_text())
    new_profile = BusinessProfile.model_validate_json(new_profile_json)

    # Diff before regenerating
    diff = diff_profiles(old_profile, new_profile)
    migrations_dir = output / new_profile.app_label / "migrations"
    migrations_dir.mkdir(parents=True, exist_ok=True)

    migration_info: dict[str, object] = {"migration": None, "operations": 0}
    if diff.has_changes:
        result = generate_migration(old_profile, new_profile, migrations_dir)
        if result is not None:
            filename, content = result
            (migrations_dir / filename).write_text(content)
            migration_info = {"migration": filename, "operations": content.count("migrations.")}

    # Detect user files that will be preserved (not overwritten)
    services_dir = output / "services"
    pipelines_dir = output / "pipelines"
    preserved: list[str] = []
    for entity in new_profile.entities:
        svc_path = services_dir / f"{entity.name}_service.py"
        if svc_path.exists():
            preserved.append(f"services/{entity.name}_service.py")
        pipe_path = pipelines_dir / f"{entity.name}_lifecycle.yaml"
        if pipe_path.exists():
            preserved.append(f"pipelines/{entity.name}_lifecycle.yaml")
    chat_pipe = pipelines_dir / "chat_agent.yaml"
    if chat_pipe.exists():
        preserved.append("pipelines/chat_agent.yaml")
    settings_path = output / "settings.py"
    if settings_path.exists():
        preserved.append("settings.py")

    # Regenerate all files with new profile
    gen_result = assemble(new_profile, output, skip_migration=True)

    return json.dumps(
        {
            "output_dir": str(output_dir),
            "migration": migration_info,
            "entities": [e.name for e in gen_result.profile.entities],
            "user_files_preserved": preserved,
            "diff": {
                "entities_added": [
                    ec.entity.name for ec in diff.entity_changes if ec.change_type == "add"
                ],
                "entities_removed": [
                    ec.entity.name for ec in diff.entity_changes if ec.change_type == "remove"
                ],
                "fields_changed": len(diff.field_changes),
                "relationships_changed": len(diff.relationship_changes),
                "states_changed": len(diff.state_changes),
            },
        },
        indent=2,
    )


@mcp.tool()
async def forge_get_profile(output_dir: str) -> str:
    """Read the BusinessProfile from a previously generated system.

    Returns the full profile: entities with fields, states, transitions,
    and relationships. Use this to inspect or modify an existing system.
    """
    profile_path = Path(output_dir) / "profile.json"
    if not profile_path.exists():
        return json.dumps({"error": f"No profile.json found in {output_dir}"})

    profile = BusinessProfile.model_validate_json(profile_path.read_text())
    return json.dumps(profile.model_dump(), indent=2, default=str)


@mcp.tool()
async def forge_list_stubs(output_dir: str) -> str:
    """List all NotImplementedError stubs in generated base services.

    Shows methods that need actual business logic implementation.
    Stubs live in services/_base/ and should be overridden in the
    user service file (services/{name}_service.py).
    """
    import ast

    stubs: list[dict[str, str]] = []
    base_dir = Path(output_dir) / "services" / "_base"
    if not base_dir.exists():
        return json.dumps([])

    for py_file in base_dir.glob("*.py"):
        if py_file.name == "__init__.py":
            continue
        tree = ast.parse(py_file.read_text())
        for node in ast.walk(tree):
            if isinstance(node, ast.AsyncFunctionDef):
                for stmt in ast.walk(node):
                    if isinstance(stmt, ast.Raise) and isinstance(stmt.exc, ast.Call):
                        func = stmt.exc.func
                        if isinstance(func, ast.Name) and func.id == "NotImplementedError":
                            stubs.append({
                                "service": py_file.stem,
                                "method": node.name,
                                "file": str(py_file.relative_to(output_dir)),
                                "docstring": ast.get_docstring(node) or "",
                            })

    return json.dumps(stubs, indent=2)


@mcp.tool()
async def forge_implement_stub(
    output_dir: str,
    service_name: str,
    method_name: str,
    implementation: str,
) -> str:
    """Implement a stub method in the user service file.

    Reads the stub signature from services/_base/ and writes the
    override into the user's service file (services/{name}_service.py).
    The implementation should be the full method body lines
    (properly indented with 8 spaces).
    """
    import ast
    import re

    # Verify the stub exists in the base service
    base_path = Path(output_dir) / "services" / "_base" / f"{service_name}.py"
    if not base_path.exists():
        return json.dumps({"error": f"Base service file not found: _base/{service_name}.py"})

    base_source = base_path.read_text()
    pattern = rf"raise NotImplementedError\([^)]*{re.escape(method_name)}[^)]*\)"
    if not re.search(pattern, base_source):
        return json.dumps({"error": f"Stub for {method_name} not found in base service"})

    # Extract the full method definition (decorators + signature + docstring)
    # from the base file so we can create a proper override
    base_tree = ast.parse(base_source)
    method_node = None
    for node in ast.walk(base_tree):
        if isinstance(node, ast.AsyncFunctionDef) and node.name == method_name:
            method_node = node
            break

    if method_node is None:
        return json.dumps({"error": f"Method {method_name} not found in base service"})

    # Get the method signature line from base source
    base_lines = base_source.splitlines()
    # Find the 'async def' line
    sig_line = base_lines[method_node.lineno - 1]

    # Build the override method for the user file
    override_lines = [
        f"    {sig_line.strip()}",
        f"        {implementation.strip()}",
    ]
    override_block = "\n".join(override_lines) + "\n"

    # Write into the user service file
    user_path = Path(output_dir) / "services" / f"{service_name}.py"
    if not user_path.exists():
        return json.dumps({"error": f"User service file not found: {service_name}.py"})

    source = user_path.read_text()

    # If the class body is just 'pass', replace it
    new_source = re.sub(
        r"^(    pass\s*)$",
        override_block,
        source,
        count=1,
        flags=re.MULTILINE,
    )

    # If 'pass' wasn't found (already has methods), append before the end
    if new_source == source:
        # Append the method at the end of the file
        new_source = source.rstrip() + "\n\n" + override_block

    try:
        ast.parse(new_source)
    except SyntaxError as e:
        return json.dumps({"error": f"Syntax error in implementation: {e}"})

    user_path.write_text(new_source)
    return json.dumps({"success": True, "file": str(user_path)})


def run_server(transport: str = "stdio", port: int = 3001) -> None:
    """Start the MCP server."""
    if transport == "stdio":
        mcp.run(transport="stdio")
    elif transport == "sse":
        mcp.run(
            transport="sse",
            sse_params={"host": "0.0.0.0", "port": port},  # nosec B104
        )
    else:
        mcp.run(transport=transport)
