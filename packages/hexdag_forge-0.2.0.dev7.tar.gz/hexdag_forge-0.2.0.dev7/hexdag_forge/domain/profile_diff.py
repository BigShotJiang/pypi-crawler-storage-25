"""Domain models for profile diffing — captures schema changes between two BusinessProfiles."""

from __future__ import annotations

from pydantic import BaseModel

from hexdag_forge.domain.business_profile import (  # noqa: TC001
    EntitySpec,
    FieldSpec,
    RelationshipSpec,
)


class FieldChange(BaseModel):
    """A single field-level change within an entity."""

    entity_name: str
    field_name: str
    change_type: str  # "add" | "remove" | "alter_type" | "alter_options"
    old_field: FieldSpec | None = None
    new_field: FieldSpec | None = None


class RelationshipChange(BaseModel):
    """A relationship added or removed."""

    entity_name: str
    field_name: str
    change_type: str  # "add" | "remove"
    old_rel: RelationshipSpec | None = None
    new_rel: RelationshipSpec | None = None


class StateChange(BaseModel):
    """Change in an entity's status choices or initial state."""

    entity_name: str
    old_states: list[str]
    new_states: list[str]
    old_initial: str
    new_initial: str


class EntityChange(BaseModel):
    """An entire entity added or removed."""

    change_type: str  # "add" | "remove"
    entity: EntitySpec


class ProfileDiff(BaseModel):
    """Complete diff between two BusinessProfile versions."""

    entity_changes: list[EntityChange] = []
    field_changes: list[FieldChange] = []
    relationship_changes: list[RelationshipChange] = []
    state_changes: list[StateChange] = []

    @property
    def has_changes(self) -> bool:
        """Return True if any schema changes were detected."""
        return bool(
            self.entity_changes
            or self.field_changes
            or self.relationship_changes
            or self.state_changes
        )
