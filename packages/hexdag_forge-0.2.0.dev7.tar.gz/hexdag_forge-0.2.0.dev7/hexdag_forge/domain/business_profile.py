"""Domain models for business profiles and entity specifications."""

from __future__ import annotations

import re
from typing import Any

from pydantic import BaseModel, field_validator, model_validator


class FieldSpec(BaseModel):
    """Specification for a single field on an entity."""

    name: str
    type: str = "str"
    required: bool = True
    default: Any = None
    description: str = ""

    @field_validator("name")
    @classmethod
    def validate_name(cls, v: str) -> str:
        if not v.isidentifier():
            msg = f"Field name must be a valid Python identifier, got: {v!r}"
            raise ValueError(msg)
        return v


class RelationshipSpec(BaseModel):
    """Specification for a relationship between entities."""

    target: str
    kind: str = "belongs_to"
    field_name: str
    description: str = ""

    @field_validator("kind")
    @classmethod
    def validate_kind(cls, v: str) -> str:
        valid = {"belongs_to", "has_many", "has_one"}
        if v not in valid:
            msg = f"Relationship kind must be one of {valid}, got: {v!r}"
            raise ValueError(msg)
        return v


class EntitySpec(BaseModel):
    """Specification for an entity type in the generated system."""

    name: str
    display_name: str
    fields: list[FieldSpec]
    relationships: list[RelationshipSpec] = []
    states: list[str]
    initial_state: str
    transitions: dict[str, list[str]]
    description: str = ""
    module: str = ""

    @field_validator("name")
    @classmethod
    def validate_name(cls, v: str) -> str:
        if not v.isidentifier():
            msg = f"Entity name must be a valid Python identifier, got: {v!r}"
            raise ValueError(msg)
        return v

    @field_validator("initial_state")
    @classmethod
    def validate_initial_state(cls, v: str, info: Any) -> str:
        states = info.data.get("states", [])
        if states and v not in states:
            msg = f"Initial state {v!r} must be one of the declared states: {states}"
            raise ValueError(msg)
        return v

    @field_validator("transitions")
    @classmethod
    def validate_transitions(cls, v: dict[str, list[str]], info: Any) -> dict[str, list[str]]:
        states = set(info.data.get("states", []))
        if not states:
            return v
        for from_state, to_states in v.items():
            if from_state not in states:
                msg = f"Transition source state {from_state!r} not in declared states"
                raise ValueError(msg)
            for to_state in to_states:
                if to_state not in states:
                    msg = f"Transition target state {to_state!r} not in declared states"
                    raise ValueError(msg)
        return v


class BusinessProfile(BaseModel):
    """Complete business profile extracted from a natural language description."""

    business_name: str
    business_type: str
    description: str
    entities: list[EntitySpec]
    workflows: list[str] = []
    modules: list[str] = []
    app_label: str = ""
    output_module: str = ""

    @model_validator(mode="before")
    @classmethod
    def derive_app_label(cls, data: Any) -> Any:
        """Derive app_label from business_name if not provided."""
        if isinstance(data, dict) and not data.get("app_label"):
            name = data.get("business_name", "app")
            # "Freight Brokerage" → "freight_brokerage"
            label = re.sub(r"[^a-zA-Z0-9]+", "_", name).strip("_").lower()
            data["app_label"] = label
        return data

    @field_validator("app_label")
    @classmethod
    def validate_app_label(cls, v: str) -> str:
        """Ensure app_label is a valid lowercase Python identifier."""
        if not v.isidentifier():
            msg = f"app_label must be a valid Python identifier, got: {v!r}"
            raise ValueError(msg)
        if v != v.lower():
            msg = f"app_label must be lowercase, got: {v!r}"
            raise ValueError(msg)
        return v
