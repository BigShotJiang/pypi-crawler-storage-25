"""Enums for hexdag-forge domain models."""

from __future__ import annotations

from enum import StrEnum


class FieldType(StrEnum):
    """Supported field types for entity fields."""

    STR = "str"
    INT = "int"
    FLOAT = "float"
    DECIMAL = "Decimal"
    BOOL = "bool"
    DATETIME = "datetime"
    DATE = "date"
    TEXT = "text"
    EMAIL = "email"
    URL = "url"
    JSON = "json"


class RelationshipKind(StrEnum):
    """Types of entity relationships."""

    BELONGS_TO = "belongs_to"
    HAS_MANY = "has_many"
    HAS_ONE = "has_one"
