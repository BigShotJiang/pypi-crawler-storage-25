"""Centralized FieldSpec → Django field mapping.

Must match the field type mapping in ``django_model.py.j2`` exactly.
Used by both the model template (future) and the migration generator.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from hexdag_forge.domain.business_profile import FieldSpec


def django_field_class(field: FieldSpec) -> str:
    """Return the Django field class for a FieldSpec (e.g. ``models.CharField``)."""
    type_map: dict[str, str] = {
        "str": "models.CharField",
        "text": "models.TextField",
        "int": "models.IntegerField",
        "float": "models.FloatField",
        "Decimal": "models.DecimalField",
        "bool": "models.BooleanField",
        "datetime": "models.DateTimeField",
        "date": "models.DateField",
        "email": "models.EmailField",
        "url": "models.URLField",
        "json": "models.JSONField",
    }
    return type_map.get(field.type, "models.CharField")


def django_field_kwargs(field: FieldSpec) -> str:
    """Return rendered kwargs string for a Django field declaration.

    Produces output like ``max_length=255, blank=True, null=True``.
    Must match the logic in ``django_model.py.j2``.
    """
    parts: list[str] = []

    # Type-specific kwargs
    if field.type in ("str", "") or field.type not in _KNOWN_TYPES:
        parts.append("max_length=255")
    elif field.type == "Decimal":
        parts.append("max_digits=12")
        parts.append("decimal_places=2")
    elif field.type == "bool":
        default = field.default if field.default is not None else False
        parts.append(f"default={default}")
    elif field.type == "json":
        parts.append("default=dict")

    # Optional field kwargs
    if not field.required and field.type != "bool":
        if field.type in ("str", "text", "email", "url") or field.type not in _KNOWN_TYPES:
            parts.append("blank=True")
            parts.append("null=True")
        else:
            parts.append("null=True")
            parts.append("blank=True")

    # Explicit default (non-bool, non-json)
    if field.default is not None and field.type not in ("bool", "json"):
        if isinstance(field.default, str):
            parts.append(f'default="{field.default}"')
        else:
            parts.append(f"default={field.default}")

    return ", ".join(parts)


def django_fk_kwargs(entity_name: str, target: str) -> str:
    """Return rendered kwargs for a ForeignKey field."""
    target_model = target.capitalize()
    return (
        f'"{target_model}", on_delete=models.SET_NULL, '
        f'null=True, blank=True, related_name="{entity_name}_set"'
    )


_KNOWN_TYPES = frozenset({
    "str",
    "text",
    "int",
    "float",
    "Decimal",
    "bool",
    "datetime",
    "date",
    "email",
    "url",
    "json",
})
