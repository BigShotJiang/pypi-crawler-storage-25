"""Generate kind: System YAML manifest from a BusinessProfile."""

from __future__ import annotations

from typing import TYPE_CHECKING

from hexdag_forge.generator.entity_generator import generate_terminal_states_map
from hexdag_forge.generator.template_engine import render_template

if TYPE_CHECKING:
    from hexdag_forge.domain.business_profile import BusinessProfile


def generate_system(profile: BusinessProfile, *, output_module: str = "generated") -> str:
    """Generate the kind: System YAML manifest.

    Uses LifecycleRunner (because state_machines is declared).
    Each entity state maps to a process pipeline via on_enter.

    Args:
        profile: The business profile.
        output_module: Python module name for the generated output directory.
            Used to build absolute import paths for services.
    """
    terminal_states = generate_terminal_states_map(profile)
    return render_template(
        "system.yaml.j2",
        profile=profile,
        terminal_states=terminal_states,
        output_module=output_module,
    )
