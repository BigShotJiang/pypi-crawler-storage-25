"""Generate StateMachineConfig definitions from a BusinessProfile."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from hexdag_forge.domain.business_profile import BusinessProfile, EntitySpec


def detect_terminal_states(entity: EntitySpec) -> list[str]:
    """Detect terminal states — states with no outgoing transitions."""
    return [s for s in entity.states if s not in entity.transitions or not entity.transitions[s]]


def generate_terminal_states_map(profile: BusinessProfile) -> dict[str, list[str]]:
    """Return {entity_name: [terminal_states]} for all entities."""
    return {entity.name: detect_terminal_states(entity) for entity in profile.entities}
