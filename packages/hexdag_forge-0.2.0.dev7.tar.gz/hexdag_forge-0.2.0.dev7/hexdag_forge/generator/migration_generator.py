"""Migration generator — produces Django migration files from profile diffs."""

from __future__ import annotations

import re
from pathlib import Path  # noqa: TC003 — needed at runtime for function params
from typing import TYPE_CHECKING

from hexdag_forge.generator.diff import diff_profiles
from hexdag_forge.generator.field_mapping import (
    django_field_class,
    django_field_kwargs,
    django_fk_kwargs,
)
from hexdag_forge.generator.template_engine import render_template

if TYPE_CHECKING:
    from hexdag_forge.domain.business_profile import BusinessProfile
    from hexdag_forge.domain.profile_diff import (
        EntityChange,
        FieldChange,
        ProfileDiff,
        RelationshipChange,
        StateChange,
    )


def generate_migration(
    old_profile: BusinessProfile,
    new_profile: BusinessProfile,
    migrations_dir: Path,
) -> tuple[str, str] | None:
    """Generate a Django migration file from the diff between two profiles.

    Args:
        old_profile: The previous BusinessProfile (or empty for initial).
        new_profile: The new BusinessProfile.
        migrations_dir: Directory containing existing migrations.

    Returns:
        ``(filename, content)`` or ``None`` if no schema changes detected.
    """
    app_label = new_profile.app_label
    diff = diff_profiles(old_profile, new_profile)
    if not diff.has_changes:
        return None

    number = _next_migration_number(migrations_dir)
    dependency = _latest_migration_name(migrations_dir)
    operations = _build_operations(diff)

    # Include chat infrastructure models in the initial migration
    if number == 1:
        operations.extend(_chat_model_operations(app_label))

    has_fk = any("ForeignKey" in op for op in operations)

    migration_name = f"{number:04d}_auto"
    filename = f"{migration_name}.py"

    content = render_template(
        "django_migration.py.j2",
        migration_name=migration_name,
        app_label=app_label,
        dependency=dependency,
        operations=operations,
        has_fk=has_fk,
    )

    return filename, content


def _next_migration_number(migrations_dir: Path) -> int:
    """Determine the next migration number by scanning existing files."""
    if not migrations_dir.exists():
        return 1
    numbers = []
    for f in migrations_dir.glob("*.py"):
        if f.name == "__init__.py":
            continue
        match = re.match(r"(\d+)", f.name)
        if match:
            numbers.append(int(match.group(1)))
    return max(numbers, default=0) + 1


def _latest_migration_name(migrations_dir: Path) -> str | None:
    """Return the name of the latest existing migration (without .py)."""
    if not migrations_dir.exists():
        return None
    files = sorted(
        (f for f in migrations_dir.glob("*.py") if f.name != "__init__.py"),
        key=lambda f: f.name,
    )
    if not files:
        return None
    return files[-1].stem


def _build_operations(diff: ProfileDiff) -> list[str]:
    """Build a list of rendered Django migration operation strings."""
    ops: list[str] = []

    # CreateModel first
    ops.extend(_render_create_model(ec) for ec in diff.entity_changes if ec.change_type == "add")
    # Field additions
    ops.extend(
        _render_add_field(fc)
        for fc in diff.field_changes
        if fc.change_type == "add" and fc.new_field is not None
    )
    # Relationship additions
    ops.extend(
        _render_add_relationship(rc)
        for rc in diff.relationship_changes
        if rc.change_type == "add" and rc.new_rel is not None
    )
    # Field alterations
    ops.extend(
        _render_alter_field(fc)
        for fc in diff.field_changes
        if fc.change_type in ("alter_type", "alter_options") and fc.new_field is not None
    )
    # State changes
    ops.extend(_render_alter_states(sc) for sc in diff.state_changes)
    # Relationship removals
    ops.extend(
        _render_remove_field(rc.entity_name, rc.field_name)
        for rc in diff.relationship_changes
        if rc.change_type == "remove"
    )
    # Field removals
    ops.extend(
        _render_remove_field(fc.entity_name, fc.field_name)
        for fc in diff.field_changes
        if fc.change_type == "remove"
    )
    # DeleteModel last
    ops.extend(_render_delete_model(ec) for ec in diff.entity_changes if ec.change_type == "remove")
    return ops


def _render_create_model(ec: EntityChange) -> str:
    """Render a migrations.CreateModel operation."""
    entity = ec.entity
    field_lines = [
        '("id", models.BigAutoField(auto_created=True, primary_key=True, '
        'serialize=False, verbose_name="ID"))',
    ]

    for field in entity.fields:
        cls = django_field_class(field)
        kwargs = django_field_kwargs(field)
        kwarg_str = f"({kwargs})" if kwargs else "()"
        field_lines.append(f'("{field.name}", {cls}{kwarg_str})')

    for rel in entity.relationships:
        if rel.kind == "belongs_to":
            fk_kwargs = django_fk_kwargs(entity.name, rel.target)
            field_lines.append(f'("{rel.field_name}", models.ForeignKey({fk_kwargs}))')

    choices = ", ".join(f'("{s}", "{s}")' for s in entity.states)
    field_lines.append(
        f'("status", models.CharField(max_length=50, '
        f'choices=[{choices}], default="{entity.initial_state}"))'
    )
    field_lines.append('("created_at", models.DateTimeField(auto_now_add=True))')
    field_lines.append('("updated_at", models.DateTimeField(auto_now=True))')

    fields_str = ",\n                ".join(field_lines)
    model_name = entity.name.capitalize()
    return (
        f"migrations.CreateModel(\n"
        f'            name="{model_name}",\n'
        f"            fields=[\n"
        f"                {fields_str},\n"
        f"            ],\n"
        f'            options={{"ordering": ["-updated_at"]}},\n'
        f"        )"
    )


def _render_delete_model(ec: EntityChange) -> str:
    """Render a migrations.DeleteModel operation."""
    return f'migrations.DeleteModel(name="{ec.entity.name.capitalize()}")'


def _render_add_field(fc: FieldChange) -> str:
    """Render a migrations.AddField operation."""
    field = fc.new_field
    cls = django_field_class(field)
    kwargs = django_field_kwargs(field)
    kwarg_str = f"({kwargs})" if kwargs else "()"
    return (
        f"migrations.AddField(\n"
        f'            model_name="{fc.entity_name}",\n'
        f'            name="{fc.field_name}",\n'
        f"            field={cls}{kwarg_str},\n"
        f"        )"
    )


def _render_alter_field(fc: FieldChange) -> str:
    """Render a migrations.AlterField operation."""
    field = fc.new_field
    cls = django_field_class(field)
    kwargs = django_field_kwargs(field)
    kwarg_str = f"({kwargs})" if kwargs else "()"
    return (
        f"migrations.AlterField(\n"
        f'            model_name="{fc.entity_name}",\n'
        f'            name="{fc.field_name}",\n'
        f"            field={cls}{kwarg_str},\n"
        f"        )"
    )


def _render_add_relationship(rc: RelationshipChange) -> str:
    """Render a migrations.AddField for a ForeignKey."""
    rel = rc.new_rel
    fk_kwargs = django_fk_kwargs(rc.entity_name, rel.target)
    return (
        f"migrations.AddField(\n"
        f'            model_name="{rc.entity_name}",\n'
        f'            name="{rc.field_name}",\n'
        f"            field=models.ForeignKey({fk_kwargs}),\n"
        f"        )"
    )


def _render_remove_field(entity_name: str, field_name: str) -> str:
    """Render a migrations.RemoveField operation."""
    return (
        f"migrations.RemoveField(\n"
        f'            model_name="{entity_name}",\n'
        f'            name="{field_name}",\n'
        f"        )"
    )


def _render_alter_states(sc: StateChange) -> str:
    """Render a migrations.AlterField for the status CharField."""
    choices = ", ".join(f'("{s}", "{s}")' for s in sc.new_states)
    return (
        f"migrations.AlterField(\n"
        f'            model_name="{sc.entity_name}",\n'
        f'            name="status",\n'
        f"            field=models.CharField(\n"
        f"                max_length=50,\n"
        f"                choices=[{choices}],\n"
        f'                default="{sc.new_initial}",\n'
        f"            ),\n"
        f"        )"
    )


def _chat_model_operations(app_label: str) -> list[str]:
    """CreateModel operations for the built-in Conversation and Message models."""
    return [
        (
            "migrations.CreateModel(\n"
            '            name="Conversation",\n'
            "            fields=[\n"
            '                ("id", models.BigAutoField(auto_created=True, primary_key=True, '
            'serialize=False, verbose_name="ID")),\n'
            '                ("user", models.ForeignKey('
            "on_delete=django.db.models.deletion.CASCADE, "
            'related_name="conversations", to="auth.user")),\n'
            '                ("title", models.CharField('
            'default="New Conversation", max_length=255)),\n'
            '                ("created_at", models.DateTimeField(auto_now_add=True)),\n'
            '                ("updated_at", models.DateTimeField(auto_now=True)),\n'
            "            ],\n"
            '            options={"ordering": ["-updated_at"]},\n'
            "        )"
        ),
        (
            "migrations.CreateModel(\n"
            '            name="Message",\n'
            "            fields=[\n"
            '                ("id", models.BigAutoField(auto_created=True, primary_key=True, '
            'serialize=False, verbose_name="ID")),\n'
            '                ("conversation", models.ForeignKey('
            "on_delete=django.db.models.deletion.CASCADE, "
            f'related_name="messages", to="{app_label}.Conversation")),\n'
            '                ("sender", models.CharField('
            'choices=[("user", "User"), ("system", "System")], max_length=10)),\n'
            '                ("content", models.TextField()),\n'
            '                ("created_at", models.DateTimeField(auto_now_add=True)),\n'
            "            ],\n"
            '            options={"ordering": ["created_at"]},\n'
            "        )"
        ),
    ]
