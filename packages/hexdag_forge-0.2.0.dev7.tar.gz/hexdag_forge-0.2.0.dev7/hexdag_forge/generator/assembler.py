"""Assembler — orchestrates all generators and writes output files.

This is the main entry point for code generation. It takes a BusinessProfile
(from LLM analysis or manual construction) and produces a complete runnable
system in the output directory.
"""

from __future__ import annotations

import json
from pathlib import Path

from hexdag_forge.domain.business_profile import BusinessProfile
from hexdag_forge.domain.generated_system import GeneratedSystem
from hexdag_forge.generator.django_generator import generate_django
from hexdag_forge.generator.pipeline_generator import generate_pipelines
from hexdag_forge.generator.service_generator import generate_services
from hexdag_forge.generator.system_generator import generate_system


def _derive_output_module(output_dir: Path) -> str:
    """Derive a Python module name from the output directory.

    ``Path("./generated")`` → ``"generated"``
    ``Path("/home/user/my_app")`` → ``"my_app"``
    """
    name = output_dir.resolve().name
    # Sanitise to valid Python identifier
    import re

    name = re.sub(r"[^a-zA-Z0-9_]", "_", name).strip("_").lower()
    return name or "generated"


def assemble(
    profile: BusinessProfile,
    output_dir: Path,
    *,
    skip_migration: bool = False,
) -> GeneratedSystem:
    """Generate all files from a BusinessProfile and write to output_dir.

    Args:
        profile: The business profile to generate from.
        output_dir: Directory to write generated files to.
        skip_migration: If True, skip migration generation (used when the
            caller has already generated the migration, e.g. ``forge_migrate``).

    Returns:
        GeneratedSystem with metadata about what was generated.
    """
    output_dir.mkdir(parents=True, exist_ok=True)
    output_module = profile.output_module or _derive_output_module(output_dir)

    # Generate all artifacts
    pipelines = generate_pipelines(profile)
    base_services, user_services = generate_services(profile)
    system_yaml = generate_system(profile, output_module=output_module)
    django_files = generate_django(profile)

    # Write pipelines (two-layer: _base/ always overwritten, user copy created once)
    pipelines_dir = output_dir / "pipelines"
    pipelines_dir.mkdir(exist_ok=True)
    base_pipelines_dir = pipelines_dir / "_base"
    base_pipelines_dir.mkdir(exist_ok=True)
    for filename, content in pipelines.items():
        (base_pipelines_dir / filename).write_text(content)
        user_path = pipelines_dir / filename
        if not user_path.exists():
            user_path.write_text(content)

    # Write services (two-layer: _base/ always overwritten, user files created once)
    services_dir = output_dir / "services"
    services_dir.mkdir(exist_ok=True)
    (services_dir / "__init__.py").write_text("")
    base_svc_dir = services_dir / "_base"
    base_svc_dir.mkdir(exist_ok=True)
    (base_svc_dir / "__init__.py").write_text("")
    for filename, content in base_services.items():
        (base_svc_dir / filename).write_text(content)
    for filename, content in user_services.items():
        user_path = services_dir / filename
        if not user_path.exists():
            user_path.write_text(content)

    # Write system manifest
    (output_dir / "system.yaml").write_text(system_yaml)

    # Django files that are user-owned (created once, never overwritten).
    # These import from auto-generated base files that ARE always overwritten.
    _USER_OWNED_DJANGO = {"settings.py"}

    # Write Django files
    for rel_path, content in django_files.items():
        file_path = output_dir / rel_path
        file_path.parent.mkdir(parents=True, exist_ok=True)
        if rel_path in _USER_OWNED_DJANGO and file_path.exists():
            continue  # Preserve user customizations
        file_path.write_text(content)

    # Write app __init__.py
    app_dir = output_dir / profile.app_label
    app_dir.mkdir(parents=True, exist_ok=True)
    (app_dir / "__init__.py").write_text("")

    # Write migrations dir + initial migration
    migrations_dir = app_dir / "migrations"
    migrations_dir.mkdir(exist_ok=True)
    (migrations_dir / "__init__.py").write_text("")

    if not skip_migration:
        from hexdag_forge.generator.migration_generator import generate_migration

        # Use existing profile.json (from a previous run) as the old state so
        # that diff_profiles produces incremental operations (AddField, etc.)
        # instead of CreateModel for every entity.  On the first run the file
        # does not exist yet, so we fall back to an empty profile.
        profile_path = output_dir / "profile.json"
        if profile_path.exists():
            old_profile = BusinessProfile.model_validate_json(profile_path.read_text())
        else:
            old_profile = BusinessProfile(
                business_name=profile.business_name,
                business_type=profile.business_type,
                description=profile.description,
                entities=[],
                app_label=profile.app_label,
            )

        result = generate_migration(old_profile, profile, migrations_dir)
        if result is not None:
            filename, migration_content = result
            (migrations_dir / filename).write_text(migration_content)

    # Write profile.json for refinement
    (output_dir / "profile.json").write_text(profile.model_dump_json(indent=2))

    return GeneratedSystem(
        profile=profile,
        pipelines=pipelines,
        base_services=base_services,
        services=user_services,
        models_source={
            f"{profile.app_label}/models.py": django_files[f"{profile.app_label}/models.py"]
        },
        state_machines={e.name: e.transitions for e in profile.entities},
        system_yaml=system_yaml,
    )


def validate_system(output_dir: Path) -> list[str]:
    """Validate all generated files in an output directory.

    Returns:
        List of error messages. Empty list means valid.
    """
    errors: list[str] = []
    output_dir = Path(output_dir)

    # Check required files exist
    required = [
        "system.yaml",
        "profile.json",
        "settings_base.py",
        "settings.py",
        "manage.py",
        "views.py",
        "forms.py",
    ]
    errors.extend(f"Missing required file: {f}" for f in required if not (output_dir / f).exists())

    # Check pipelines directory
    pipelines_dir = output_dir / "pipelines"
    if not pipelines_dir.exists():
        errors.append("Missing pipelines/ directory")
    elif not list(pipelines_dir.glob("*.yaml")):
        errors.append("No YAML files in pipelines/")

    # Check services directory
    services_dir = output_dir / "services"
    if not services_dir.exists():
        errors.append("Missing services/ directory")
    elif not list(services_dir.glob("*.py")):
        errors.append("No Python files in services/")

    # Validate Python syntax
    for py_file in output_dir.rglob("*.py"):
        try:
            import ast

            ast.parse(py_file.read_text())
        except SyntaxError as e:
            errors.append(f"Syntax error in {py_file.relative_to(output_dir)}: {e}")

    # Validate profile.json
    profile_path = output_dir / "profile.json"
    if profile_path.exists():
        try:
            profile_data = json.loads(profile_path.read_text())
            BusinessProfile.model_validate(profile_data)
        except Exception as e:
            errors.append(f"Invalid profile.json: {e}")

    return errors
