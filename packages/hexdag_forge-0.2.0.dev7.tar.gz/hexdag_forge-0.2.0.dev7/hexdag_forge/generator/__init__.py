"""hexdag-forge generator engine — transforms BusinessProfile into runnable code."""
