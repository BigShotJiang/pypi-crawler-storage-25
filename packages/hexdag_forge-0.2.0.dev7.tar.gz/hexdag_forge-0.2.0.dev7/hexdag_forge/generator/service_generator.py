"""Generate Python service files from a BusinessProfile."""

from __future__ import annotations

from typing import TYPE_CHECKING

from hexdag_forge.generator.template_engine import render_template

if TYPE_CHECKING:
    from hexdag_forge.domain.business_profile import BusinessProfile


def generate_services(
    profile: BusinessProfile,
) -> tuple[dict[str, str], dict[str, str]]:
    """Generate base + user service files per entity.

    Base services (always regenerated) contain CRUD methods and domain stubs.
    User services (created once, never overwritten) extend the base class
    and are where custom domain logic lives.

    Returns:
        Tuple of (base_services, user_services) dicts of filename -> source.
    """
    base_services: dict[str, str] = {}
    user_services: dict[str, str] = {}

    # Associate workflows with entities by keyword matching
    entity_workflows = _match_workflows_to_entities(profile)

    for entity in profile.entities:
        filename = f"{entity.name}_service.py"
        workflows = entity_workflows.get(entity.name, [])
        base_services[filename] = render_template(
            "service_base.py.j2", entity=entity, workflows=workflows
        )
        user_services[filename] = render_template("service_user.py.j2", entity=entity)

    return base_services, user_services


def _match_workflows_to_entities(profile: BusinessProfile) -> dict[str, list[str]]:
    """Simple keyword matching: assign workflows to entities they mention."""
    result: dict[str, list[str]] = {e.name: [] for e in profile.entities}

    for workflow in profile.workflows:
        workflow_lower = workflow.lower()
        matched = False
        for entity in profile.entities:
            if (
                entity.name.lower() in workflow_lower
                or entity.display_name.lower() in workflow_lower
            ):
                result[entity.name].append(workflow)
                matched = True
        # If no entity matched, assign to first entity as a catch-all
        if not matched and profile.entities:
            result[profile.entities[0].name].append(workflow)

    return result
