"""Profile diffing engine — compares two BusinessProfiles and produces a ProfileDiff."""

from __future__ import annotations

from typing import TYPE_CHECKING

from hexdag_forge.domain.profile_diff import (
    EntityChange,
    FieldChange,
    ProfileDiff,
    RelationshipChange,
    StateChange,
)

if TYPE_CHECKING:
    from hexdag_forge.domain.business_profile import BusinessProfile, EntitySpec


def diff_profiles(old: BusinessProfile, new: BusinessProfile) -> ProfileDiff:
    """Compare two BusinessProfiles and return a structured diff.

    Entity matching is by ``name`` (the Python identifier).
    Field matching is by ``field.name``. Relationship matching by ``field_name``.
    Renames are treated as remove + add.
    """
    old_entities = {e.name: e for e in old.entities}
    new_entities = {e.name: e for e in new.entities}

    # Added / removed entities
    entity_changes = [
        EntityChange(change_type="add", entity=new_entities[n])
        for n in new_entities
        if n not in old_entities
    ] + [
        EntityChange(change_type="remove", entity=old_entities[n])
        for n in old_entities
        if n not in new_entities
    ]

    # Compare internals for entities present in both
    field_changes: list[FieldChange] = []
    relationship_changes: list[RelationshipChange] = []
    state_changes: list[StateChange] = []

    for name in old_entities:
        if name in new_entities:
            old_e = old_entities[name]
            new_e = new_entities[name]
            field_changes.extend(_diff_fields(name, old_e, new_e))
            relationship_changes.extend(_diff_relationships(name, old_e, new_e))
            sc = _diff_states(name, old_e, new_e)
            if sc is not None:
                state_changes.append(sc)

    return ProfileDiff(
        entity_changes=entity_changes,
        field_changes=field_changes,
        relationship_changes=relationship_changes,
        state_changes=state_changes,
    )


def _diff_fields(entity_name: str, old: EntitySpec, new: EntitySpec) -> list[FieldChange]:
    """Compare fields between two versions of the same entity."""
    old_fields = {f.name: f for f in old.fields}
    new_fields = {f.name: f for f in new.fields}
    changes: list[FieldChange] = []

    for fname in new_fields:
        if fname not in old_fields:
            changes.append(
                FieldChange(
                    entity_name=entity_name,
                    field_name=fname,
                    change_type="add",
                    new_field=new_fields[fname],
                )
            )
        else:
            old_f = old_fields[fname]
            new_f = new_fields[fname]
            if old_f.type != new_f.type:
                changes.append(
                    FieldChange(
                        entity_name=entity_name,
                        field_name=fname,
                        change_type="alter_type",
                        old_field=old_f,
                        new_field=new_f,
                    )
                )
            elif old_f.required != new_f.required or old_f.default != new_f.default:
                changes.append(
                    FieldChange(
                        entity_name=entity_name,
                        field_name=fname,
                        change_type="alter_options",
                        old_field=old_f,
                        new_field=new_f,
                    )
                )

    changes.extend(
        FieldChange(
            entity_name=entity_name,
            field_name=fname,
            change_type="remove",
            old_field=old_fields[fname],
        )
        for fname in old_fields
        if fname not in new_fields
    )

    return changes


def _diff_relationships(
    entity_name: str,
    old: EntitySpec,
    new: EntitySpec,
) -> list[RelationshipChange]:
    """Compare relationships between two versions of the same entity."""
    old_rels = {r.field_name: r for r in old.relationships}
    new_rels = {r.field_name: r for r in new.relationships}

    return [
        RelationshipChange(
            entity_name=entity_name,
            field_name=fname,
            change_type="add",
            new_rel=new_rels[fname],
        )
        for fname in new_rels
        if fname not in old_rels
    ] + [
        RelationshipChange(
            entity_name=entity_name,
            field_name=fname,
            change_type="remove",
            old_rel=old_rels[fname],
        )
        for fname in old_rels
        if fname not in new_rels
    ]


def _diff_states(entity_name: str, old: EntitySpec, new: EntitySpec) -> StateChange | None:
    """Compare states and initial_state between two versions of the same entity."""
    if old.states == new.states and old.initial_state == new.initial_state:
        return None
    return StateChange(
        entity_name=entity_name,
        old_states=old.states,
        new_states=new.states,
        old_initial=old.initial_state,
        new_initial=new.initial_state,
    )
