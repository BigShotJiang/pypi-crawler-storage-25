"""Jinja2 template rendering engine for code generation."""

from __future__ import annotations

from pathlib import Path  # noqa: TC003
from typing import TYPE_CHECKING

from jinja2 import Environment, FileSystemLoader

if TYPE_CHECKING:
    from hexdag_forge.domain.business_profile import BusinessProfile, EntitySpec

_TEMPLATE_DIR = Path(__file__).parent.parent / "templates"


# ── Jinja2 filters ──────────────────────────────────────────


def _to_pascal(value: str) -> str:
    """Convert snake_case to PascalCase: ``freight_brokerage`` → ``FreightBrokerage``."""
    return "".join(word.capitalize() for word in value.split("_"))


def _humanize(value: str) -> str:
    """Convert snake_case to human-readable: ``company_name`` → ``Company Name``."""
    return value.replace("_", " ").title()


def _status_color(state: str) -> str:
    """Map a state name to a CSS badge color class using naming heuristics."""
    s = state.upper()
    # Exact matches
    _GREEN = {
        "COMPLETED",
        "DELIVERED",
        "DONE",
        "APPROVED",
        "ACTIVE",
        "PAID",
        "RESOLVED",
        "AVAILABLE",
        "PICKED_UP",
    }
    _RED = {
        "CANCELLED",
        "REJECTED",
        "FAILED",
        "SUSPENDED",
        "BLOCKED",
        "EXPIRED",
        "DELETED",
        "TERMINATED",
        "VOID",
        "RETIRED",
        "CLOSED",
    }
    _BLUE = {
        "DISPATCHED",
        "SENT",
        "ONBOARDING",
        "CONFIRMED",
        "ASSIGNED",
    }
    _PURPLE = {
        "IN_TRANSIT",
        "IN_PROGRESS",
        "PROCESSING",
        "ON_TRIP",
        "IN_USE",
        "COVERED",
    }
    _YELLOW = {
        "SUSPENDED",
        "MAINTENANCE",
        "INVOICED",
        "OVERDUE",
        "OFF_DUTY",
    }
    _GRAY = {
        "DRAFT",
        "PENDING",
        "NEW",
        "POSTED",
        "PROSPECT",
        "CREATED",
        "QUEUED",
    }

    if s in _GREEN:
        return "badge-green"
    if s in _RED:
        return "badge-red"
    if s in _PURPLE:
        return "badge-purple"
    if s in _YELLOW:
        return "badge-yellow"
    if s in _BLUE:
        return "badge-blue"
    if s in _GRAY:
        return "badge-gray"

    # Keyword heuristic fallback
    if any(kw in s for kw in ("COMPLET", "DELIVER", "DONE", "APPROV", "ACTIV", "AVAIL", "PAID")):
        return "badge-green"
    if any(kw in s for kw in ("CANCEL", "REJECT", "FAIL", "TERMINAT", "VOID", "RETIR", "CLOSE")):
        return "badge-red"
    if any(kw in s for kw in ("TRANSIT", "TRIP", "PROGRESS", "PROCESS", "USE")):
        return "badge-purple"
    if any(kw in s for kw in ("SUSPEND", "MAINT", "OVERDUE")):
        return "badge-yellow"
    if any(kw in s for kw in ("DISPATCH", "SENT", "ONBOARD", "REVIEW")):
        return "badge-blue"
    return "badge-gray"


def _transition_color(state: str) -> str:
    """Map a target state to a button CSS class for transition buttons."""
    color = _status_color(state)
    return {
        "badge-green": "btn-success",
        "badge-red": "btn-danger",
        "badge-purple": "btn-primary",
        "badge-blue": "btn-primary",
        "badge-yellow": "btn-warning",
        "badge-gray": "btn-outline",
    }.get(color, "btn-outline")


# ── Context builders ────────────────────────────────────────


def build_badge_map(profile: BusinessProfile) -> dict[str, str]:
    """Build a {state_name: badge_class} map for all states across all entities."""
    result: dict[str, str] = {}
    for entity in profile.entities:
        for state in entity.states:
            result[state] = _status_color(state)
    return result


def build_list_columns(entity: EntitySpec) -> list[object]:
    """Select fields suitable for list table display (skip text/json, cap at 5)."""
    return [f for f in entity.fields if f.type not in ("text", "json")][:5]


def build_fk_fields(entity: EntitySpec) -> list[object]:
    """Return belongs_to relationship specs for select_related."""
    return [r for r in entity.relationships if r.kind == "belongs_to"]


# ── Environments ────────────────────────────────────────────


def _register_filters(env: Environment) -> None:
    """Register all custom filters on a Jinja2 environment."""
    env.filters["to_pascal"] = _to_pascal
    env.filters["humanize"] = _humanize
    env.filters["status_color"] = _status_color
    env.filters["transition_color"] = _transition_color


def create_env() -> Environment:
    """Create a Jinja2 environment configured for Python code generation."""
    env = Environment(  # nosec B701 — code generation templates, not HTML
        loader=FileSystemLoader(str(_TEMPLATE_DIR)),
        keep_trailing_newline=True,
        trim_blocks=True,
        lstrip_blocks=True,
        autoescape=False,
    )
    _register_filters(env)
    return env


def create_html_env() -> Environment:
    """Create a Jinja2 environment for templates that OUTPUT Django template syntax.

    Uses alternate delimiters to avoid collision with Django's ``{% %}`` and ``{{ }}``.
    Jinja2 generation uses ``[% %]`` and ``[[ ]]``, Django tags pass through untouched.
    """
    env = Environment(  # nosec B701 — code generation templates, not HTML
        loader=FileSystemLoader(str(_TEMPLATE_DIR)),
        keep_trailing_newline=True,
        trim_blocks=True,
        lstrip_blocks=True,
        autoescape=False,
        block_start_string="[%",
        block_end_string="%]",
        variable_start_string="[[",
        variable_end_string="]]",
        comment_start_string="[#",
        comment_end_string="#]",
    )
    _register_filters(env)
    return env


def render_template(template_name: str, **context: object) -> str:
    """Render a Jinja2 template with the given context (standard delimiters)."""
    env = create_env()
    template = env.get_template(template_name)
    return template.render(**context)


def render_html_template(template_name: str, **context: object) -> str:
    """Render a Jinja2 template that outputs Django template syntax (alt delimiters)."""
    env = create_html_env()
    template = env.get_template(template_name)
    return template.render(**context)
