"""Generate Django project files from a BusinessProfile."""

from __future__ import annotations

from typing import TYPE_CHECKING

from hexdag_forge.generator.template_engine import (
    build_badge_map,
    build_fk_fields,
    build_list_columns,
    render_html_template,
    render_template,
)

if TYPE_CHECKING:
    from hexdag_forge.domain.business_profile import BusinessProfile


def generate_django(profile: BusinessProfile) -> dict[str, str]:
    """Generate Django models, views, forms, templates, and project config.

    Returns:
        Dict of relative path -> file content.
    """
    app = profile.app_label
    badge_colors = build_badge_map(profile)
    files: dict[str, str] = {}

    # Pre-compute per-entity context
    list_columns_map = {e.name: build_list_columns(e) for e in profile.entities}
    fk_fields_map = {e.name: build_fk_fields(e) for e in profile.entities}

    # ── Python files (standard Jinja2 delimiters) ──────────
    files[f"{app}/models.py"] = render_template("django_model.py.j2", profile=profile)
    files[f"{app}/apps.py"] = render_template("django_apps.py.j2", profile=profile)
    files[f"{app}/admin.py"] = render_template("django_admin.py.j2", profile=profile)
    files["settings_base.py"] = render_template("django_settings_base.py.j2", profile=profile)
    files["settings.py"] = render_template("django_settings.py.j2", profile=profile)
    files["urls.py"] = render_template("django_urls.py.j2", profile=profile)
    files["manage.py"] = render_template("django_manage.py.j2", profile=profile)
    files["state_machines.py"] = render_template("state_machines.py.j2", profile=profile)
    files["views.py"] = render_template("django_views.py.j2", profile=profile)
    files["forms.py"] = render_template("django_forms.py.j2", profile=profile)
    files["chat_agent.py"] = render_template("django_chat_agent.py.j2", profile=profile)

    # Templatetags
    files[f"{app}/templatetags/__init__.py"] = ""
    files[f"{app}/templatetags/{app}_tags.py"] = render_template(
        "django_templatetags.py.j2", profile=profile, badge_colors=badge_colors
    )

    # ── HTML templates (alt delimiters — outputs Django template syntax) ──
    files["templates/base.html"] = render_html_template("django_base.html.j2", profile=profile)

    # Dashboard
    files["templates/dashboard/index.html"] = render_html_template(
        "django_dashboard.html.j2",
        profile=profile,
        list_columns=list_columns_map,
    )

    # Auth
    files["templates/registration/login.html"] = render_html_template(
        "django_login.html.j2", profile=profile
    )
    files["templates/registration/register.html"] = render_html_template(
        "django_register.html.j2", profile=profile
    )
    files["templates/registration/logged_out.html"] = render_html_template(
        "django_logged_out.html.j2", profile=profile
    )

    # Per-entity CRUD templates
    for entity in profile.entities:
        prefix = f"templates/{entity.name}"
        list_cols = list_columns_map[entity.name]
        fk_flds = fk_fields_map[entity.name]
        ctx = {
            "entity": entity,
            "profile": profile,
            "list_columns": list_cols,
            "fk_fields": fk_flds,
        }
        files[f"{prefix}/list.html"] = render_html_template("django_entity_list.html.j2", **ctx)
        files[f"{prefix}/_list_rows.html"] = render_html_template(
            "django_entity_list_partial.html.j2", **ctx
        )
        files[f"{prefix}/detail.html"] = render_html_template("django_entity_detail.html.j2", **ctx)
        files[f"{prefix}/_detail_content.html"] = render_html_template(
            "django_entity_detail_partial.html.j2", **ctx
        )
        files[f"{prefix}/form.html"] = render_html_template("django_entity_form.html.j2", **ctx)
        files[f"{prefix}/_form_modal.html"] = render_html_template(
            "django_entity_form_modal.html.j2", **ctx
        )
        files[f"{prefix}/confirm_delete.html"] = render_html_template(
            "django_entity_confirm_delete.html.j2", **ctx
        )

    # Chat
    files["templates/chat/chat.html"] = render_html_template("django_chat.html.j2", profile=profile)
    files["templates/chat/conversations.html"] = render_html_template(
        "django_chat_conversations.html.j2", profile=profile
    )
    files["templates/chat/_messages.html"] = render_html_template(
        "django_chat_messages_partial.html.j2", profile=profile
    )

    return files
