"""Tests for the assembler — end-to-end generation."""

import ast
import json
from pathlib import Path

from hexdag_forge.domain.business_profile import (
    BusinessProfile,
    EntitySpec,
    FieldSpec,
    RelationshipSpec,
)
from hexdag_forge.generator.assembler import assemble, validate_system


def _freight_profile() -> BusinessProfile:
    return BusinessProfile(
        business_name="Test Freight",
        business_type="freight_brokerage",
        description="A freight brokerage",
        entities=[
            EntitySpec(
                name="load",
                display_name="Load",
                description="Freight load",
                fields=[
                    FieldSpec(name="origin", type="str", required=True),
                    FieldSpec(name="destination", type="str", required=True),
                    FieldSpec(name="weight", type="float", required=True),
                    FieldSpec(name="rate", type="Decimal", required=False),
                ],
                relationships=[
                    RelationshipSpec(target="carrier", kind="belongs_to", field_name="carrier_id"),
                ],
                states=["POSTED", "COVERED", "IN_TRANSIT", "DELIVERED", "CLOSED"],
                initial_state="POSTED",
                transitions={
                    "POSTED": ["COVERED"],
                    "COVERED": ["IN_TRANSIT"],
                    "IN_TRANSIT": ["DELIVERED"],
                    "DELIVERED": ["CLOSED"],
                },
            ),
            EntitySpec(
                name="carrier",
                display_name="Carrier",
                fields=[
                    FieldSpec(name="name", type="str", required=True),
                    FieldSpec(name="mc_number", type="str", required=True),
                    FieldSpec(name="score", type="float", required=False),
                ],
                states=["PENDING", "ACTIVE", "SUSPENDED"],
                initial_state="PENDING",
                transitions={
                    "PENDING": ["ACTIVE"],
                    "ACTIVE": ["SUSPENDED"],
                    "SUSPENDED": ["ACTIVE"],
                },
            ),
        ],
        workflows=["negotiate rate with carrier"],
        modules=["logistics"],
    )


# app_label derived from "Test Freight" → "test_freight"
_APP = "test_freight"


class TestAssemble:
    def test_creates_output_directory(self, tmp_path: Path):
        output = tmp_path / "output"
        assemble(_freight_profile(), output)
        assert output.exists()

    def test_generates_system_yaml(self, tmp_path: Path):
        assemble(_freight_profile(), tmp_path)
        system_yaml = tmp_path / "system.yaml"
        assert system_yaml.exists()
        content = system_yaml.read_text()
        assert "kind: System" in content
        assert "state_machines:" in content
        assert "load:" in content
        assert "carrier:" in content

    def test_generates_pipelines(self, tmp_path: Path):
        assemble(_freight_profile(), tmp_path)
        # User copies in pipelines/
        pipelines = list((tmp_path / "pipelines").glob("*.yaml"))
        assert len(pipelines) == 3  # 2 entity lifecycles + chat_agent
        names = {p.name for p in pipelines}
        assert "load_lifecycle.yaml" in names
        assert "carrier_lifecycle.yaml" in names
        assert "chat_agent.yaml" in names
        # Base copies in pipelines/_base/
        base_pipelines = list((tmp_path / "pipelines" / "_base").glob("*.yaml"))
        assert len(base_pipelines) == 3

    def test_generates_services(self, tmp_path: Path):
        assemble(_freight_profile(), tmp_path)
        services_dir = tmp_path / "services"
        # User service files
        user_files = [f for f in services_dir.glob("*.py") if f.name != "__init__.py"]
        assert len(user_files) == 2
        names = {s.name for s in user_files}
        assert "load_service.py" in names
        assert "carrier_service.py" in names
        # Services dir is a proper Python package
        assert (services_dir / "__init__.py").exists()
        # Base service files in _base/
        base_dir = services_dir / "_base"
        assert base_dir.is_dir()
        assert (base_dir / "__init__.py").exists()
        base_files = [f for f in base_dir.glob("*.py") if f.name != "__init__.py"]
        assert len(base_files) == 2

    def test_services_have_valid_python(self, tmp_path: Path):
        assemble(_freight_profile(), tmp_path)
        for py_file in (tmp_path / "services").rglob("*.py"):
            ast.parse(py_file.read_text())  # Should not raise

    def test_generates_django_models(self, tmp_path: Path):
        assemble(_freight_profile(), tmp_path)
        models_file = tmp_path / _APP / "models.py"
        assert models_file.exists()
        content = models_file.read_text()
        assert "class Load(models.Model):" in content
        assert "class Carrier(models.Model):" in content
        assert "origin = models.CharField" in content
        assert "carrier_id = models.ForeignKey" in content
        # Chat models
        assert "class Conversation(models.Model):" in content
        assert "class Message(models.Model):" in content

    def test_generates_manage_py(self, tmp_path: Path):
        assemble(_freight_profile(), tmp_path)
        manage = tmp_path / "manage.py"
        assert manage.exists()
        ast.parse(manage.read_text())

    def test_generates_profile_json(self, tmp_path: Path):
        assemble(_freight_profile(), tmp_path)
        profile = tmp_path / "profile.json"
        assert profile.exists()
        data = json.loads(profile.read_text())
        assert data["business_name"] == "Test Freight"
        assert data["app_label"] == "test_freight"
        assert len(data["entities"]) == 2

    def test_generates_state_machines(self, tmp_path: Path):
        assemble(_freight_profile(), tmp_path)
        sm = tmp_path / "state_machines.py"
        assert sm.exists()
        content = sm.read_text()
        assert "LOAD_STATE_MACHINE" in content
        assert "CARRIER_STATE_MACHINE" in content

    def test_base_services_contain_stubs(self, tmp_path: Path):
        assemble(_freight_profile(), tmp_path)
        base_carrier = (tmp_path / "services" / "_base" / "carrier_service.py").read_text()
        assert "NotImplementedError" in base_carrier
        assert "negotiate_rate_with_carrier" in base_carrier

    def test_user_services_extend_base(self, tmp_path: Path):
        assemble(_freight_profile(), tmp_path)
        user_load = (tmp_path / "services" / "load_service.py").read_text()
        assert "LoadServiceBase" in user_load
        assert "from ._base.load_service import LoadServiceBase" in user_load
        assert "class LoadService(LoadServiceBase):" in user_load

    def test_optional_fields_before_required_produce_valid_python(self, tmp_path: Path):
        """Optional fields before required fields must not break Python syntax."""
        profile = BusinessProfile(
            business_name="Test",
            business_type="general",
            description="test",
            entities=[
                EntitySpec(
                    name="item",
                    display_name="Item",
                    fields=[
                        FieldSpec(name="notes", type="text", required=False),
                        FieldSpec(name="name", type="str", required=True),
                        FieldSpec(name="priority", type="int", required=True),
                    ],
                    states=["DRAFT", "DONE"],
                    initial_state="DRAFT",
                    transitions={"DRAFT": ["DONE"]},
                )
            ],
        )
        assemble(profile, tmp_path)
        # Base service has the CRUD methods with field signatures
        base_src = (tmp_path / "services" / "_base" / "item_service.py").read_text()
        ast.parse(base_src)  # Must not raise SyntaxError
        create_line = next(line for line in base_src.splitlines() if "def create_item" in line)
        name_pos = create_line.index("name:")
        notes_pos = create_line.index("notes:")
        assert name_pos < notes_pos, "Required params must come before optional"

    def test_returns_generated_system(self, tmp_path: Path):
        result = assemble(_freight_profile(), tmp_path)
        assert result.profile.business_name == "Test Freight"
        assert len(result.pipelines) == 3  # 2 entity lifecycles + chat_agent
        assert len(result.base_services) == 2
        assert len(result.services) == 2
        assert result.system_yaml != ""

    def test_generates_views_and_forms(self, tmp_path: Path):
        assemble(_freight_profile(), tmp_path)
        assert (tmp_path / "views.py").exists()
        assert (tmp_path / "forms.py").exists()
        ast.parse((tmp_path / "views.py").read_text())
        ast.parse((tmp_path / "forms.py").read_text())

    def test_generates_html_templates(self, tmp_path: Path):
        assemble(_freight_profile(), tmp_path)
        assert (tmp_path / "templates" / "base.html").exists()
        assert (tmp_path / "templates" / "registration" / "login.html").exists()
        assert (tmp_path / "templates" / "load" / "list.html").exists()
        assert (tmp_path / "templates" / "load" / "detail.html").exists()
        assert (tmp_path / "templates" / "chat" / "chat.html").exists()

    def test_app_label_in_settings_base(self, tmp_path: Path):
        assemble(_freight_profile(), tmp_path)
        settings_base = (tmp_path / "settings_base.py").read_text()
        assert '"test_freight"' in settings_base

    def test_settings_imports_from_base(self, tmp_path: Path):
        assemble(_freight_profile(), tmp_path)
        settings = (tmp_path / "settings.py").read_text()
        assert "from settings_base import" in settings

    def test_generates_migrations(self, tmp_path: Path):
        assemble(_freight_profile(), tmp_path)
        migrations_dir = tmp_path / _APP / "migrations"
        assert migrations_dir.is_dir()
        assert (migrations_dir / "__init__.py").exists()
        migrations = list(migrations_dir.glob("0001_*.py"))
        assert len(migrations) == 1

    def test_system_yaml_has_ports(self, tmp_path: Path):
        assemble(_freight_profile(), tmp_path)
        content = (tmp_path / "system.yaml").read_text()
        assert "ports:" in content
        assert "entity_store:" in content
        assert "hexdag_forge.runtime.django_store.DjangoEntityStore" in content
        assert "app_label:" in content

    def test_system_yaml_services_reference_entity_store(self, tmp_path: Path):
        assemble(_freight_profile(), tmp_path)
        content = (tmp_path / "system.yaml").read_text()
        assert 'db: "entity_store"' in content

    def test_system_yaml_service_paths_contain_output_module(self, tmp_path: Path):
        output = tmp_path / "my_app"
        assemble(_freight_profile(), output)
        content = (output / "system.yaml").read_text()
        # Service class paths should be absolute: output_module.services.entity_service.Class
        assert "my_app.services.load_service.LoadService" in content
        assert "my_app.services.carrier_service.CarrierService" in content

    def test_pipeline_uses_lifecycle_input(self, tmp_path: Path):
        assemble(_freight_profile(), tmp_path)
        content = (tmp_path / "pipelines" / "load_lifecycle.yaml").read_text()
        # Should reference $input.entity_id (from lifecycle runner), not $input.load_id
        assert "$input.entity_id" in content
        assert "$input.to_state" in content
        assert "$input.reason" in content

    def test_pipeline_references_system_service(self, tmp_path: Path):
        assemble(_freight_profile(), tmp_path)
        content = (tmp_path / "pipelines" / "load_lifecycle.yaml").read_text()
        # Pipeline should reference load_svc (matching system.yaml service name)
        assert "load_svc" in content

    def test_output_module_override(self, tmp_path: Path):
        profile = _freight_profile()
        profile = profile.model_copy(update={"output_module": "custom_module"})
        assemble(profile, tmp_path)
        content = (tmp_path / "system.yaml").read_text()
        assert "custom_module.services.load_service.LoadService" in content


class TestTwoLayerPreservation:
    """Verify that user files are never overwritten on regeneration."""

    def test_user_service_survives_regeneration(self, tmp_path: Path):
        """User service file must not be overwritten on second assemble()."""
        assemble(_freight_profile(), tmp_path)

        # Simulate user editing the service file
        user_svc = tmp_path / "services" / "load_service.py"
        user_svc.write_text(
            user_svc.read_text().replace(
                "    pass",
                "    async def my_custom_method(self) -> dict:\n        return {'custom': True}\n",
            )
        )

        # Regenerate — user file should survive
        assemble(_freight_profile(), tmp_path)

        content = user_svc.read_text()
        assert "my_custom_method" in content
        assert "pass" not in content

    def test_base_service_always_overwritten(self, tmp_path: Path):
        """Base service must be regenerated even if modified."""
        assemble(_freight_profile(), tmp_path)

        base_svc = tmp_path / "services" / "_base" / "load_service.py"
        base_svc.write_text("# corrupted")

        assemble(_freight_profile(), tmp_path)

        content = base_svc.read_text()
        assert "LoadServiceBase" in content
        assert "corrupted" not in content

    def test_user_pipeline_survives_regeneration(self, tmp_path: Path):
        """User pipeline YAML must not be overwritten on second assemble()."""
        assemble(_freight_profile(), tmp_path)

        user_pipe = tmp_path / "pipelines" / "load_lifecycle.yaml"
        user_pipe.write_text("# my custom pipeline\n" + user_pipe.read_text())

        assemble(_freight_profile(), tmp_path)

        content = user_pipe.read_text()
        assert content.startswith("# my custom pipeline")

    def test_base_pipeline_always_overwritten(self, tmp_path: Path):
        """Base pipeline must be regenerated even if modified."""
        assemble(_freight_profile(), tmp_path)

        base_pipe = tmp_path / "pipelines" / "_base" / "load_lifecycle.yaml"
        base_pipe.write_text("# corrupted")

        assemble(_freight_profile(), tmp_path)

        content = base_pipe.read_text()
        assert "corrupted" not in content
        assert "kind:" in content

    def test_settings_survives_regeneration(self, tmp_path: Path):
        """User's settings.py must not be overwritten; settings_base.py must be."""
        assemble(_freight_profile(), tmp_path)

        # Simulate user adding dotenv config
        settings = tmp_path / "settings.py"
        settings.write_text(settings.read_text() + "\n# My custom dotenv patch\nimport environ\n")

        assemble(_freight_profile(), tmp_path)

        content = settings.read_text()
        assert "My custom dotenv patch" in content
        assert "import environ" in content

        # But settings_base.py should always be fresh
        base_content = (tmp_path / "settings_base.py").read_text()
        assert "INSTALLED_APPS" in base_content

    def test_new_entity_creates_both_layers(self, tmp_path: Path):
        """Adding a new entity should create both base and user service files."""
        profile_v1 = BusinessProfile(
            business_name="Test",
            business_type="general",
            description="test",
            entities=[
                EntitySpec(
                    name="order",
                    display_name="Order",
                    fields=[FieldSpec(name="total", type="Decimal")],
                    states=["DRAFT", "DONE"],
                    initial_state="DRAFT",
                    transitions={"DRAFT": ["DONE"]},
                ),
            ],
        )
        assemble(profile_v1, tmp_path)

        # Add a new entity
        profile_v2 = BusinessProfile(
            business_name="Test",
            business_type="general",
            description="test",
            entities=[
                EntitySpec(
                    name="order",
                    display_name="Order",
                    fields=[FieldSpec(name="total", type="Decimal")],
                    states=["DRAFT", "DONE"],
                    initial_state="DRAFT",
                    transitions={"DRAFT": ["DONE"]},
                ),
                EntitySpec(
                    name="customer",
                    display_name="Customer",
                    fields=[FieldSpec(name="name", type="str")],
                    states=["ACTIVE", "INACTIVE"],
                    initial_state="ACTIVE",
                    transitions={"ACTIVE": ["INACTIVE"]},
                ),
            ],
        )
        assemble(profile_v2, tmp_path)

        # New entity should have both base and user files
        assert (tmp_path / "services" / "_base" / "customer_service.py").exists()
        assert (tmp_path / "services" / "customer_service.py").exists()
        user_content = (tmp_path / "services" / "customer_service.py").read_text()
        assert "CustomerServiceBase" in user_content

        # Old entity's user file should still be untouched
        assert (tmp_path / "services" / "order_service.py").exists()


class TestIncrementalMigration:
    """Verify that calling assemble() twice produces incremental migrations."""

    def test_add_field_produces_add_field_not_create_model(self, tmp_path: Path):
        """After initial generation, adding a field should produce AddField."""
        profile_v1 = BusinessProfile(
            business_name="Test",
            business_type="general",
            description="test",
            entities=[
                EntitySpec(
                    name="order",
                    display_name="Order",
                    fields=[FieldSpec(name="total", type="Decimal")],
                    states=["DRAFT", "CONFIRMED"],
                    initial_state="DRAFT",
                    transitions={"DRAFT": ["CONFIRMED"]},
                ),
            ],
        )
        assemble(profile_v1, tmp_path)

        migrations_dir = tmp_path / "test" / "migrations"
        assert len(list(migrations_dir.glob("0001_*.py"))) == 1

        # Add a field
        profile_v2 = BusinessProfile(
            business_name="Test",
            business_type="general",
            description="test",
            entities=[
                EntitySpec(
                    name="order",
                    display_name="Order",
                    fields=[
                        FieldSpec(name="total", type="Decimal"),
                        FieldSpec(name="notes", type="text", required=False),
                    ],
                    states=["DRAFT", "CONFIRMED"],
                    initial_state="DRAFT",
                    transitions={"DRAFT": ["CONFIRMED"]},
                ),
            ],
        )
        assemble(profile_v2, tmp_path)

        migration_0002 = list(migrations_dir.glob("0002_*.py"))
        assert len(migration_0002) == 1
        content = migration_0002[0].read_text()
        assert "AddField" in content
        assert "CreateModel" not in content
        assert '"notes"' in content
        ast.parse(content)

    def test_no_changes_produces_no_second_migration(self, tmp_path: Path):
        """Identical second call should not create a second migration."""
        profile = BusinessProfile(
            business_name="Test",
            business_type="general",
            description="test",
            entities=[
                EntitySpec(
                    name="order",
                    display_name="Order",
                    fields=[FieldSpec(name="total", type="Decimal")],
                    states=["DRAFT", "CONFIRMED"],
                    initial_state="DRAFT",
                    transitions={"DRAFT": ["CONFIRMED"]},
                ),
            ],
        )
        assemble(profile, tmp_path)
        assemble(profile, tmp_path)

        migrations_dir = tmp_path / "test" / "migrations"
        all_migrations = [f for f in migrations_dir.glob("*.py") if f.name != "__init__.py"]
        assert len(all_migrations) == 1

    def test_skip_migration_flag(self, tmp_path: Path):
        """skip_migration=True should skip migration generation entirely."""
        profile = BusinessProfile(
            business_name="Test",
            business_type="general",
            description="test",
            entities=[
                EntitySpec(
                    name="order",
                    display_name="Order",
                    fields=[FieldSpec(name="total", type="Decimal")],
                    states=["DRAFT", "CONFIRMED"],
                    initial_state="DRAFT",
                    transitions={"DRAFT": ["CONFIRMED"]},
                ),
            ],
        )
        assemble(profile, tmp_path, skip_migration=True)

        migrations_dir = tmp_path / "test" / "migrations"
        all_migrations = [f for f in migrations_dir.glob("*.py") if f.name != "__init__.py"]
        assert len(all_migrations) == 0

    def test_add_entity_creates_only_new_model(self, tmp_path: Path):
        """Adding a new entity should CreateModel only for the new one."""
        profile_v1 = BusinessProfile(
            business_name="Test",
            business_type="general",
            description="test",
            entities=[
                EntitySpec(
                    name="order",
                    display_name="Order",
                    fields=[FieldSpec(name="total", type="Decimal")],
                    states=["DRAFT", "DONE"],
                    initial_state="DRAFT",
                    transitions={"DRAFT": ["DONE"]},
                ),
            ],
        )
        assemble(profile_v1, tmp_path)

        profile_v2 = BusinessProfile(
            business_name="Test",
            business_type="general",
            description="test",
            entities=[
                EntitySpec(
                    name="order",
                    display_name="Order",
                    fields=[FieldSpec(name="total", type="Decimal")],
                    states=["DRAFT", "DONE"],
                    initial_state="DRAFT",
                    transitions={"DRAFT": ["DONE"]},
                ),
                EntitySpec(
                    name="customer",
                    display_name="Customer",
                    fields=[FieldSpec(name="name", type="str")],
                    states=["ACTIVE", "INACTIVE"],
                    initial_state="ACTIVE",
                    transitions={"ACTIVE": ["INACTIVE"]},
                ),
            ],
        )
        assemble(profile_v2, tmp_path)

        migrations_dir = tmp_path / "test" / "migrations"
        migration_0002 = list(migrations_dir.glob("0002_*.py"))
        assert len(migration_0002) == 1
        content = migration_0002[0].read_text()
        assert "CreateModel" in content
        assert "Customer" in content
        assert content.count("CreateModel") == 1
        ast.parse(content)


class TestValidateSystem:
    def test_valid_system(self, tmp_path: Path):
        assemble(_freight_profile(), tmp_path)
        errors = validate_system(tmp_path)
        assert errors == []

    def test_missing_files(self, tmp_path: Path):
        errors = validate_system(tmp_path)
        assert len(errors) > 0
        assert any("Missing" in e for e in errors)

    def test_invalid_python_detected(self, tmp_path: Path):
        assemble(_freight_profile(), tmp_path)
        # Corrupt a Python file
        (tmp_path / "services" / "load_service.py").write_text("def broken(:\n")
        errors = validate_system(tmp_path)
        assert any("Syntax error" in e for e in errors)
