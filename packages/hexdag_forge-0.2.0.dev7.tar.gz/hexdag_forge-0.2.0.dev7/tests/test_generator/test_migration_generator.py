"""Tests for the migration generator."""

import ast
from pathlib import Path

from hexdag_forge.domain.business_profile import (
    BusinessProfile,
    EntitySpec,
    FieldSpec,
    RelationshipSpec,
)
from hexdag_forge.generator.assembler import assemble
from hexdag_forge.generator.migration_generator import generate_migration


def _entity(**overrides) -> EntitySpec:
    defaults = {
        "name": "order",
        "display_name": "Order",
        "fields": [FieldSpec(name="total", type="Decimal")],
        "states": ["DRAFT", "CONFIRMED", "COMPLETED"],
        "initial_state": "DRAFT",
        "transitions": {"DRAFT": ["CONFIRMED"], "CONFIRMED": ["COMPLETED"]},
    }
    defaults.update(overrides)
    return EntitySpec(**defaults)


def _profile(*entities: EntitySpec) -> BusinessProfile:
    return BusinessProfile(
        business_name="Test",
        business_type="general",
        description="test",
        entities=list(entities),
    )


_EMPTY = _profile()


class TestGenerateMigration:
    def test_initial_migration(self, tmp_path: Path):
        result = generate_migration(_EMPTY, _profile(_entity()), tmp_path)
        assert result is not None
        filename, content = result
        assert filename == "0001_auto.py"
        assert "CreateModel" in content
        assert "Order" in content

    def test_migration_valid_python(self, tmp_path: Path):
        result = generate_migration(_EMPTY, _profile(_entity()), tmp_path)
        assert result is not None
        _, content = result
        ast.parse(content)  # Must not raise

    def test_migration_counter_increments(self, tmp_path: Path):
        (tmp_path / "__init__.py").write_text("")
        (tmp_path / "0001_auto.py").write_text("# existing migration")

        result = generate_migration(_EMPTY, _profile(_entity()), tmp_path)
        assert result is not None
        filename, _ = result
        assert filename == "0002_auto.py"

    def test_no_migration_when_no_changes(self, tmp_path: Path):
        profile = _profile(_entity())
        result = generate_migration(profile, profile, tmp_path)
        assert result is None

    def test_add_field_produces_add_field(self, tmp_path: Path):
        old = _profile(_entity(fields=[FieldSpec(name="total", type="Decimal")]))
        new = _profile(
            _entity(
                fields=[
                    FieldSpec(name="total", type="Decimal"),
                    FieldSpec(name="notes", type="text", required=False),
                ]
            )
        )
        result = generate_migration(old, new, tmp_path)
        assert result is not None
        _, content = result
        assert "AddField" in content
        assert '"notes"' in content
        ast.parse(content)

    def test_remove_entity_produces_delete_model(self, tmp_path: Path):
        old = _profile(_entity(), _entity(name="customer", display_name="Customer"))
        new = _profile(_entity())
        result = generate_migration(old, new, tmp_path)
        assert result is not None
        _, content = result
        assert "DeleteModel" in content
        assert '"Customer"' in content
        ast.parse(content)

    def test_alter_states_produces_alter_field(self, tmp_path: Path):
        old = _profile(
            _entity(
                states=["DRAFT", "DONE"],
                initial_state="DRAFT",
                transitions={"DRAFT": ["DONE"]},
            )
        )
        new = _profile(
            _entity(
                states=["DRAFT", "REVIEW", "DONE"],
                initial_state="DRAFT",
                transitions={"DRAFT": ["REVIEW"], "REVIEW": ["DONE"]},
            )
        )
        result = generate_migration(old, new, tmp_path)
        assert result is not None
        _, content = result
        assert "AlterField" in content
        assert '"status"' in content
        assert "REVIEW" in content
        ast.parse(content)

    def test_add_relationship_produces_foreign_key(self, tmp_path: Path):
        old = _profile(_entity(relationships=[]))
        new = _profile(
            _entity(
                relationships=[
                    RelationshipSpec(target="customer", kind="belongs_to", field_name="customer_id")
                ]
            )
        )
        result = generate_migration(old, new, tmp_path)
        assert result is not None
        _, content = result
        assert "ForeignKey" in content
        assert '"customer_id"' in content
        ast.parse(content)

    def test_create_model_includes_all_fields(self, tmp_path: Path):
        entity = _entity(
            fields=[
                FieldSpec(name="name", type="str"),
                FieldSpec(name="amount", type="Decimal"),
                FieldSpec(name="notes", type="text", required=False),
            ]
        )
        result = generate_migration(_EMPTY, _profile(entity), tmp_path)
        assert result is not None
        _, content = result
        assert '"name"' in content
        assert '"amount"' in content
        assert '"notes"' in content
        assert "CharField" in content
        assert "DecimalField" in content
        assert "TextField" in content

    def test_dependency_references_previous(self, tmp_path: Path):
        (tmp_path / "__init__.py").write_text("")
        (tmp_path / "0001_auto.py").write_text("# initial")

        result = generate_migration(
            _profile(_entity()),
            _profile(
                _entity(
                    fields=[
                        FieldSpec(name="total", type="Decimal"),
                        FieldSpec(name="extra", type="str"),
                    ]
                )
            ),
            tmp_path,
        )
        assert result is not None
        _, content = result
        assert "0001_auto" in content  # dependency


class TestAssemblerInitialMigration:
    def test_assemble_creates_migrations_dir(self, tmp_path: Path):
        assemble(_profile(_entity()), tmp_path)
        assert (tmp_path / "test" / "migrations").is_dir()
        assert (tmp_path / "test" / "migrations" / "__init__.py").exists()

    def test_assemble_creates_initial_migration(self, tmp_path: Path):
        assemble(_profile(_entity()), tmp_path)
        migrations = list((tmp_path / "test" / "migrations").glob("0001_*.py"))
        assert len(migrations) == 1
        content = migrations[0].read_text()
        assert "CreateModel" in content
        ast.parse(content)
