"""Tests for the profile diff engine."""

from hexdag_forge.domain.business_profile import (
    BusinessProfile,
    EntitySpec,
    FieldSpec,
    RelationshipSpec,
)
from hexdag_forge.generator.diff import diff_profiles


def _entity(**overrides) -> EntitySpec:
    defaults = {
        "name": "order",
        "display_name": "Order",
        "fields": [FieldSpec(name="total", type="Decimal")],
        "states": ["DRAFT", "CONFIRMED", "COMPLETED"],
        "initial_state": "DRAFT",
        "transitions": {"DRAFT": ["CONFIRMED"], "CONFIRMED": ["COMPLETED"]},
    }
    defaults.update(overrides)
    return EntitySpec(**defaults)


def _profile(*entities: EntitySpec) -> BusinessProfile:
    return BusinessProfile(
        business_name="Test",
        business_type="general",
        description="test",
        entities=list(entities),
    )


class TestEntityChanges:
    def test_add_entity(self):
        old = _profile(_entity())
        new = _profile(_entity(), _entity(name="customer", display_name="Customer"))
        diff = diff_profiles(old, new)

        assert len(diff.entity_changes) == 1
        assert diff.entity_changes[0].change_type == "add"
        assert diff.entity_changes[0].entity.name == "customer"
        assert diff.has_changes

    def test_remove_entity(self):
        old = _profile(_entity(), _entity(name="customer", display_name="Customer"))
        new = _profile(_entity())
        diff = diff_profiles(old, new)

        assert len(diff.entity_changes) == 1
        assert diff.entity_changes[0].change_type == "remove"
        assert diff.entity_changes[0].entity.name == "customer"

    def test_no_entity_changes(self):
        profile = _profile(_entity())
        diff = diff_profiles(profile, profile)
        assert len(diff.entity_changes) == 0


class TestFieldChanges:
    def test_add_field(self):
        old = _profile(_entity(fields=[FieldSpec(name="total", type="Decimal")]))
        new = _profile(
            _entity(
                fields=[
                    FieldSpec(name="total", type="Decimal"),
                    FieldSpec(name="notes", type="text", required=False),
                ]
            )
        )
        diff = diff_profiles(old, new)

        assert len(diff.field_changes) == 1
        fc = diff.field_changes[0]
        assert fc.change_type == "add"
        assert fc.field_name == "notes"
        assert fc.entity_name == "order"

    def test_remove_field(self):
        old = _profile(
            _entity(
                fields=[
                    FieldSpec(name="total", type="Decimal"),
                    FieldSpec(name="notes", type="text"),
                ]
            )
        )
        new = _profile(_entity(fields=[FieldSpec(name="total", type="Decimal")]))
        diff = diff_profiles(old, new)

        assert len(diff.field_changes) == 1
        assert diff.field_changes[0].change_type == "remove"
        assert diff.field_changes[0].field_name == "notes"

    def test_change_field_type(self):
        old = _profile(_entity(fields=[FieldSpec(name="total", type="float")]))
        new = _profile(_entity(fields=[FieldSpec(name="total", type="Decimal")]))
        diff = diff_profiles(old, new)

        assert len(diff.field_changes) == 1
        fc = diff.field_changes[0]
        assert fc.change_type == "alter_type"
        assert fc.old_field.type == "float"
        assert fc.new_field.type == "Decimal"

    def test_change_field_options(self):
        old = _profile(_entity(fields=[FieldSpec(name="total", type="Decimal", required=True)]))
        new = _profile(_entity(fields=[FieldSpec(name="total", type="Decimal", required=False)]))
        diff = diff_profiles(old, new)

        assert len(diff.field_changes) == 1
        assert diff.field_changes[0].change_type == "alter_options"

    def test_no_field_changes(self):
        profile = _profile(_entity())
        diff = diff_profiles(profile, profile)
        assert len(diff.field_changes) == 0


class TestRelationshipChanges:
    def test_add_relationship(self):
        old = _profile(_entity(relationships=[]))
        new = _profile(
            _entity(
                relationships=[
                    RelationshipSpec(target="customer", kind="belongs_to", field_name="customer_id")
                ]
            )
        )
        diff = diff_profiles(old, new)

        assert len(diff.relationship_changes) == 1
        rc = diff.relationship_changes[0]
        assert rc.change_type == "add"
        assert rc.field_name == "customer_id"

    def test_remove_relationship(self):
        old = _profile(
            _entity(
                relationships=[
                    RelationshipSpec(target="customer", kind="belongs_to", field_name="customer_id")
                ]
            )
        )
        new = _profile(_entity(relationships=[]))
        diff = diff_profiles(old, new)

        assert len(diff.relationship_changes) == 1
        assert diff.relationship_changes[0].change_type == "remove"


class TestStateChanges:
    def test_change_states(self):
        old = _profile(
            _entity(
                states=["DRAFT", "DONE"],
                initial_state="DRAFT",
                transitions={"DRAFT": ["DONE"]},
            )
        )
        new = _profile(
            _entity(
                states=["DRAFT", "REVIEW", "DONE"],
                initial_state="DRAFT",
                transitions={"DRAFT": ["REVIEW"], "REVIEW": ["DONE"]},
            )
        )
        diff = diff_profiles(old, new)

        assert len(diff.state_changes) == 1
        sc = diff.state_changes[0]
        assert sc.old_states == ["DRAFT", "DONE"]
        assert sc.new_states == ["DRAFT", "REVIEW", "DONE"]

    def test_change_initial_state(self):
        old = _profile(_entity(initial_state="DRAFT"))
        new = _profile(_entity(initial_state="CONFIRMED"))
        diff = diff_profiles(old, new)

        assert len(diff.state_changes) == 1
        assert diff.state_changes[0].old_initial == "DRAFT"
        assert diff.state_changes[0].new_initial == "CONFIRMED"

    def test_no_state_changes(self):
        profile = _profile(_entity())
        diff = diff_profiles(profile, profile)
        assert len(diff.state_changes) == 0


class TestNoChanges:
    def test_identical_profiles(self):
        profile = _profile(_entity())
        diff = diff_profiles(profile, profile)
        assert not diff.has_changes

    def test_empty_profiles(self):
        old = _profile()
        new = _profile()
        diff = diff_profiles(old, new)
        assert not diff.has_changes
