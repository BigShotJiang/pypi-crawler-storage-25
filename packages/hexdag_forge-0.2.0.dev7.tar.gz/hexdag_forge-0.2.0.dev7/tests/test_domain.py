"""Tests for domain models."""

import pytest

from hexdag_forge.domain.business_profile import (
    BusinessProfile,
    EntitySpec,
    FieldSpec,
    RelationshipSpec,
)
from hexdag_forge.domain.generated_system import GeneratedSystem


def _make_entity(**overrides):
    defaults = {
        "name": "order",
        "display_name": "Order",
        "fields": [FieldSpec(name="total", type="Decimal")],
        "states": ["DRAFT", "CONFIRMED", "COMPLETED"],
        "initial_state": "DRAFT",
        "transitions": {"DRAFT": ["CONFIRMED"], "CONFIRMED": ["COMPLETED"]},
    }
    defaults.update(overrides)
    return EntitySpec(**defaults)


class TestFieldSpec:
    def test_valid_field(self):
        f = FieldSpec(name="price", type="Decimal", required=True)
        assert f.name == "price"

    def test_invalid_field_name(self):
        with pytest.raises(ValueError, match="valid Python identifier"):
            FieldSpec(name="invalid-name", type="str")

    def test_optional_field(self):
        f = FieldSpec(name="notes", type="text", required=False, default=None)
        assert f.required is False
        assert f.default is None


class TestRelationshipSpec:
    def test_valid_relationship(self):
        r = RelationshipSpec(target="carrier", kind="belongs_to", field_name="carrier_id")
        assert r.kind == "belongs_to"

    def test_invalid_kind(self):
        with pytest.raises(ValueError, match="Relationship kind"):
            RelationshipSpec(target="x", kind="invalid", field_name="x_id")


class TestEntitySpec:
    def test_valid_entity(self):
        e = _make_entity()
        assert e.name == "order"
        assert e.initial_state == "DRAFT"

    def test_invalid_entity_name(self):
        with pytest.raises(ValueError, match="valid Python identifier"):
            _make_entity(name="bad-name")

    def test_initial_state_not_in_states(self):
        with pytest.raises(ValueError, match="must be one of the declared states"):
            _make_entity(initial_state="NONEXISTENT")

    def test_transition_source_not_in_states(self):
        with pytest.raises(ValueError, match="source state"):
            _make_entity(transitions={"INVALID": ["DRAFT"]})

    def test_transition_target_not_in_states(self):
        with pytest.raises(ValueError, match="target state"):
            _make_entity(transitions={"DRAFT": ["INVALID"]})

    def test_relationships(self):
        e = _make_entity(
            relationships=[
                RelationshipSpec(target="customer", kind="belongs_to", field_name="customer_id")
            ]
        )
        assert len(e.relationships) == 1
        assert e.relationships[0].target == "customer"


class TestBusinessProfile:
    def test_valid_profile(self):
        p = BusinessProfile(
            business_name="Test",
            business_type="general",
            description="A test business",
            entities=[_make_entity()],
        )
        assert p.business_name == "Test"
        assert len(p.entities) == 1

    def test_empty_entities(self):
        p = BusinessProfile(
            business_name="Empty",
            business_type="general",
            description="No entities",
            entities=[],
        )
        assert len(p.entities) == 0

    def test_app_label_derived_from_name(self):
        p = BusinessProfile(
            business_name="Freight Brokerage",
            business_type="general",
            description="test",
            entities=[],
        )
        assert p.app_label == "freight_brokerage"

    def test_app_label_explicit_override(self):
        p = BusinessProfile(
            business_name="Test",
            business_type="general",
            description="test",
            entities=[],
            app_label="myapp",
        )
        assert p.app_label == "myapp"

    def test_app_label_must_be_lowercase(self):
        with pytest.raises(ValueError, match="lowercase"):
            BusinessProfile(
                business_name="Test",
                business_type="general",
                description="test",
                entities=[],
                app_label="MyApp",
            )

    def test_app_label_must_be_identifier(self):
        with pytest.raises(ValueError, match="valid Python identifier"):
            BusinessProfile(
                business_name="Test",
                business_type="general",
                description="test",
                entities=[],
                app_label="my-app",
            )

    def test_app_label_special_chars_stripped(self):
        p = BusinessProfile(
            business_name="Bob's Pizza & Wings!",
            business_type="general",
            description="test",
            entities=[],
        )
        assert p.app_label == "bob_s_pizza_wings"


class TestGeneratedSystem:
    def test_generated_system(self):
        profile = BusinessProfile(
            business_name="Test",
            business_type="general",
            description="test",
            entities=[_make_entity()],
        )
        gs = GeneratedSystem(profile=profile, system_yaml="kind: System")
        assert gs.system_yaml == "kind: System"
        assert gs.profile.business_name == "Test"
