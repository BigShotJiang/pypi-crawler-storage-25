"""Tests for InMemoryEntityStore."""

import pytest

from hexdag_forge.runtime.memory_store import InMemoryEntityStore


@pytest.fixture
def store() -> InMemoryEntityStore:
    return InMemoryEntityStore()


class TestCreate:
    async def test_returns_record_with_id_and_status(self, store: InMemoryEntityStore):
        record = await store.create("load", {"origin": "NYC", "destination": "LA"}, "POSTED")
        assert "id" in record
        assert record["status"] == "POSTED"
        assert record["origin"] == "NYC"

    async def test_generates_unique_ids(self, store: InMemoryEntityStore):
        r1 = await store.create("load", {}, "POSTED")
        r2 = await store.create("load", {}, "POSTED")
        assert r1["id"] != r2["id"]

    async def test_separate_entity_types(self, store: InMemoryEntityStore):
        await store.create("load", {"x": 1}, "POSTED")
        await store.create("carrier", {"y": 2}, "PENDING")
        loads = await store.list_all("load")
        carriers = await store.list_all("carrier")
        assert len(loads) == 1
        assert len(carriers) == 1


class TestGet:
    async def test_retrieves_existing_record(self, store: InMemoryEntityStore):
        created = await store.create("load", {"origin": "NYC"}, "POSTED")
        fetched = await store.get("load", created["id"])
        assert fetched["origin"] == "NYC"
        assert fetched["id"] == created["id"]

    async def test_raises_key_error_for_missing(self, store: InMemoryEntityStore):
        with pytest.raises(KeyError, match="not found"):
            await store.get("load", "nonexistent")

    async def test_returns_copy(self, store: InMemoryEntityStore):
        created = await store.create("load", {"origin": "NYC"}, "POSTED")
        fetched = await store.get("load", created["id"])
        fetched["origin"] = "MUTATED"
        refetched = await store.get("load", created["id"])
        assert refetched["origin"] == "NYC"


class TestListAll:
    async def test_lists_all_entities(self, store: InMemoryEntityStore):
        await store.create("load", {}, "POSTED")
        await store.create("load", {}, "COVERED")
        results = await store.list_all("load")
        assert len(results) == 2

    async def test_filters_by_status(self, store: InMemoryEntityStore):
        await store.create("load", {}, "POSTED")
        await store.create("load", {}, "COVERED")
        await store.create("load", {}, "POSTED")
        results = await store.list_all("load", status="POSTED")
        assert len(results) == 2
        assert all(r["status"] == "POSTED" for r in results)

    async def test_respects_limit(self, store: InMemoryEntityStore):
        for _ in range(10):
            await store.create("load", {}, "POSTED")
        results = await store.list_all("load", limit=3)
        assert len(results) == 3

    async def test_empty_entity_type(self, store: InMemoryEntityStore):
        results = await store.list_all("nonexistent")
        assert results == []


class TestUpdate:
    async def test_updates_fields(self, store: InMemoryEntityStore):
        created = await store.create("load", {"origin": "NYC", "weight": 100}, "POSTED")
        updated = await store.update("load", created["id"], {"weight": 200})
        assert updated["weight"] == 200
        assert updated["origin"] == "NYC"

    async def test_raises_for_missing(self, store: InMemoryEntityStore):
        with pytest.raises(KeyError, match="not found"):
            await store.update("load", "nonexistent", {"x": 1})


class TestDelete:
    async def test_deletes_record(self, store: InMemoryEntityStore):
        created = await store.create("load", {}, "POSTED")
        result = await store.delete("load", created["id"])
        assert result["deleted"] is True
        with pytest.raises(KeyError):
            await store.get("load", created["id"])

    async def test_raises_for_missing(self, store: InMemoryEntityStore):
        with pytest.raises(KeyError, match="not found"):
            await store.delete("load", "nonexistent")


class TestTransition:
    async def test_transitions_state(self, store: InMemoryEntityStore):
        created = await store.create("load", {}, "POSTED")
        result = await store.transition("load", created["id"], "COVERED", reason="matched")
        assert result["from_state"] == "POSTED"
        assert result["to_state"] == "COVERED"
        assert result["reason"] == "matched"
        assert result["status"] == "COVERED"

    async def test_persists_transition(self, store: InMemoryEntityStore):
        created = await store.create("load", {}, "POSTED")
        await store.transition("load", created["id"], "COVERED")
        fetched = await store.get("load", created["id"])
        assert fetched["status"] == "COVERED"

    async def test_raises_for_missing(self, store: InMemoryEntityStore):
        with pytest.raises(KeyError, match="not found"):
            await store.transition("load", "nonexistent", "COVERED")


class TestProtocolCompliance:
    def test_implements_supports_entity_store(self):
        from hexdag_forge.runtime.entity_store import SupportsEntityStore

        store = InMemoryEntityStore()
        assert isinstance(store, SupportsEntityStore)
