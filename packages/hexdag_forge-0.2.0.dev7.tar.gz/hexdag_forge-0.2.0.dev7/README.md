# hexDAG Forge

**Generate operational systems from prompts.** Describe your business, get a complete system with YAML pipelines, Python services, Django models, state machines, and auto-migrations.

## How it works

1. You describe your business to Claude Code (via `/forge` or the MCP server)
2. Claude analyzes the description and builds a `BusinessProfile` JSON (entities, fields, states, transitions, relationships)
3. Forge generates the complete system from that profile
4. When you change the ontology, `forge_migrate` diffs the profiles and generates Django migrations automatically

## Output

```
./generated/
├── system.yaml              # kind: System manifest (LifecycleRunner)
├── profile.json              # BusinessProfile (source of truth)
├── settings.py / manage.py   # Django project scaffold
├── admin.py / urls.py        # Django admin auto-registration
├── models/
│   └── models.py             # Django ORM models with fields + state choices
├── migrations/
│   └── 0001_auto.py          # Initial Django migration (auto-generated)
├── state_machines.py         # StateMachineConfig definitions
├── pipelines/
│   ├── load_lifecycle.yaml   # hexDAG pipeline per entity
│   └── carrier_lifecycle.yaml
└── services/
    ├── load_service.py       # @tool/@step CRUD (implemented) + domain stubs
    └── carrier_service.py
```

## What it generates

- **YAML Pipelines** -- entity lifecycle workflows using hexDAG nodes
- **Python Services** -- `@tool`/`@step` CRUD methods (implemented) + domain-specific stubs (`NotImplementedError`) for the builder agent to fill
- **Django Models** -- ORM models with fields, relationships, state choices
- **System Manifest** -- `kind: System` with state machines, `on_enter` process mappings, terminal states
- **State Machines** -- `StateMachineConfig` definitions with validated transitions
- **Django Migrations** -- auto-generated from profile diffs (CreateModel, AddField, AlterField, etc.)

## MCP + Claude Code

```bash
pip install hexdag-forge
hexdag-forge mcp serve
```

### Skills

- `/forge "I run a freight brokerage"` -- generate a new system
- `/forge:entity "add Carrier with mc_number, score"` -- add/modify entity (with automigration)
- `/forge:implement "fill in negotiate_rate"` -- implement a service stub
- `/forge:test` -- validate generated files

### MCP Tools

| Tool | Description |
|------|-------------|
| `forge_profile_schema` | Get the BusinessProfile JSON schema |
| `forge_generate` | Generate a new system from a BusinessProfile JSON |
| `forge_migrate` | Update an existing system -- diffs profiles, regenerates, writes migration |
| `forge_get_profile` | Read the profile from a generated system |
| `forge_validate` | Validate generated files (syntax, structure) |
| `forge_list_stubs` | List NotImplementedError methods in services |
| `forge_implement_stub` | Replace a stub with implementation code |

## CLI

```bash
# Generate from a profile JSON file
hexdag-forge generate profile.json --output ./my-erp/

# Validate generated files
hexdag-forge validate ./my-erp/

# Start MCP server for Claude Code
hexdag-forge mcp serve
```

## Automigration

When you modify the ontology (add entities, change fields, rename states), forge automatically generates Django migration files:

```
# Initial generation creates 0001_auto.py with CreateModel for each entity
/forge "freight brokerage with loads and carriers"
→ migrations/0001_auto.py (CreateModel: Load, Carrier)

# Adding a field via /forge:entity creates 0002_auto.py
/forge:entity "add weight_limit field to carrier"
→ migrations/0002_auto.py (AddField: carrier.weight_limit)

# Changing states creates another migration
/forge:entity "add SUSPENDED state to carrier"
→ migrations/0003_auto.py (AlterField: carrier.status choices)
```

Supported operations: `CreateModel`, `DeleteModel`, `AddField`, `RemoveField`, `AlterField` (type changes, option changes, state changes), `ForeignKey` additions/removals.

## License

[Business Source License 1.1](LICENSE) — free for non-production use (development, testing, evaluation, education, personal projects). Production use in commercial products or services requires a [commercial license](mailto:developers@omniviser.ai). On **May 24, 2029**, the license converts to Apache 2.0.
