## New module: raggit/middleware/

### Design principles
- Middleware orchestrates modules — monitor, cache, graph (future)
- Each module defines its own minimal ABC — only what it needs
- SQLiteStore is the reference implementation — ships with Raggit
- Users can implement their own stores or use future built-ins
- Monitor and Cache never know if they share a DB or not
- Store handles all clustering logic — Monitor only calls log()

---

### File structure
raggit/
└── middleware/
    ├── __init__.py
    ├── middleware.py
    ├── models.py
    ├── monitor/
    │   ├── __init__.py
    │   └── monitor.py
    ├── cache/
    │   ├── __init__.py
    │   └── cache.py
    ├── graph/
    │   └── __init__.py      # placeholder, empty
    └── stores/
        ├── __init__.py
        ├── base.py           # MonitorStore ABC + CacheStore ABC
        └── sqlite.py         # SQLiteStore — reference implementation

---

### models.py

```python
from __future__ import annotations
import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field


class Cluster(BaseModel):
    cluster_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    representative_query: str
    representative_vec: List[float]
    count: int = 0
    created_at: datetime = Field(default_factory=datetime.now)
    last_seen: datetime = Field(default_factory=datetime.now)


class Event(BaseModel):
    event_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    cluster_id: str
    query_text: str
    latency_ms: Optional[float] = None
    timestamp: datetime = Field(default_factory=datetime.now)
    cache_hit: bool = False
    extra: Dict[str, Any] = {}
```

Note: cached_response, cache_approved_at, cache_approved_by removed from Cluster.
Cache is a separate concern handled by CacheStore.

---

### stores/base.py — ABCs

```python
class MonitorStore(ABC):
    """
    Contract for monitor persistence.
    Implement this to use any backend or clustering strategy.
    All clustering logic lives here — Monitor just calls log().
    """

    @abstractmethod
    def log(
        self,
        query: str,
        vec: List[float],
        latency_ms: float,
        threshold: float,
        cache_hit: bool = False,
        **kwargs  # stored in Event.extra
    ) -> None:
        """
        Handle everything:
        1. Find similar cluster above threshold (or create new one)
        2. Update cluster metadata (count, last_seen)
        3. Log event
        Store decides clustering strategy — single vector, border vectors, etc.
        """
        ...

    @abstractmethod
    def get_clusters(
        self,
        top: Optional[int] = None,
        since: Optional[datetime] = None,
        last_seen_before: Optional[datetime] = None,
    ) -> List[Cluster]: ...

    @abstractmethod
    def stats(self) -> dict:
        """
        Returns at minimum:
        {
            "total_events": int,
            "unique_clusters": int,
            "top_clusters": List[Cluster],
        }
        """
        ...


class CacheStore(ABC):
    """
    Contract for cache persistence.
    Implement this to use any backend (SQLite, Redis, Postgres, etc).
    """

    @abstractmethod
    def get(self, vec: List[float], threshold: float) -> Optional[str]:
        """
        Find cached response for similar vector above threshold.
        Returns response string or None.
        Store decides similarity strategy.
        """
        ...

    @abstractmethod
    def set(
        self,
        cluster_id: str,
        response: str,
        approved_by: str = "llm"
    ) -> None:
        """Store cached response for cluster_id."""
        ...
```

---

### stores/sqlite.py — SQLiteStore

Reference implementation. Implements both MonitorStore and CacheStore.
Single SQLite file, three tables.
Creates tables automatically on __init__.

```python
class SQLiteStore(MonitorStore, CacheStore):
    """
    Reference implementation using SQLite.
    Good for local development and small production deployments.
    
    For production at scale, implement MonitorStore and/or CacheStore
    with your preferred backend (Postgres, MongoDB, Redis, etc).
    """

    def __init__(self, path: str = ".raggit/middleware.db"):
        """Creates .raggit/ directory and tables if not exist."""
        self.path = path
        self._init_db()

    def _init_db(self) -> None:
        """
        CREATE TABLE IF NOT EXISTS clusters (
            cluster_id TEXT PRIMARY KEY,
            representative_vec TEXT NOT NULL,  -- JSON array
            representative_query TEXT NOT NULL,
            count INTEGER DEFAULT 0,
            created_at TEXT NOT NULL,
            last_seen TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS events (
            event_id TEXT PRIMARY KEY,
            cluster_id TEXT NOT NULL,
            query_text TEXT NOT NULL,
            latency_ms REAL,
            timestamp TEXT NOT NULL,
            cache_hit INTEGER DEFAULT 0,
            extra TEXT DEFAULT '{}',
            FOREIGN KEY (cluster_id) REFERENCES clusters(cluster_id)
        );

        CREATE TABLE IF NOT EXISTS cache (
            cluster_id TEXT PRIMARY KEY,
            response TEXT NOT NULL,
            approved_by TEXT NOT NULL,
            approved_at TEXT NOT NULL,
            FOREIGN KEY (cluster_id) REFERENCES clusters(cluster_id)
        );
        """
        ...

    # MonitorStore
    def log(self, query, vec, latency_ms, threshold, cache_hit=False, **kwargs) -> None:
        """
        1. Load all clusters, compute cosine similarity for each
           Use Metrics.cosine_similarity from raggit.metrics
        2. If similar cluster found (>= threshold):
           - update count + last_seen
        3. If not found:
           - create new Cluster with cluster_id = uuid4()
           - INSERT into clusters table
           - INSERT vector as json.dumps(vec)
        4. INSERT event into events table
           extra = json.dumps(kwargs)
        """
        ...

    def get_clusters(self, top=None, since=None, last_seen_before=None) -> List[Cluster]:
        """
        SELECT all from clusters.
        Apply filters:
        - since: created_at >= since
        - last_seen_before: last_seen <= last_seen_before
        Sort by count DESC.
        Apply top limit if provided.
        """
        ...

    def stats(self) -> dict:
        """
        total_events: SELECT COUNT(*) FROM events
        unique_clusters: SELECT COUNT(*) FROM clusters
        top_clusters: get_clusters(top=5)
        """
        ...

    # CacheStore
    def get(self, vec: List[float], threshold: float) -> Optional[str]:
        """
        1. Load all clusters
        2. Find most similar cluster above threshold
        3. If found → SELECT response FROM cache WHERE cluster_id = ?
        4. Return response or None
        """
        ...

    def set(self, cluster_id, response, approved_by="llm") -> None:
        """
        INSERT OR REPLACE INTO cache (cluster_id, response, approved_by, approved_at)
        """
        ...
```

---

### monitor/monitor.py

```python
class Monitor:
    def __init__(
        self,
        store: MonitorStore,
        embedder: Callable[[str], List[float]],
        cluster_threshold: float = 0.92,
    ):
        self.store = store
        self.embedder = embedder
        self.cluster_threshold = cluster_threshold

    def log(
        self,
        query: str,
        latency_ms: float,
        cache_hit: bool = False,
        **kwargs
    ) -> None:
        """
        Embed query, delegate everything to store.
        Monitor has no clustering logic.
        """
        vec = self.embedder(query)
        self.store.log(
            query=query,
            vec=vec,
            latency_ms=latency_ms,
            threshold=self.cluster_threshold,
            cache_hit=cache_hit,
            **kwargs
        )

    def clusters(
        self,
        top: Optional[int] = None,
        since: Optional[datetime] = None,
        last_seen_before: Optional[datetime] = None,
    ) -> List[Cluster]:
        return self.store.get_clusters(
            top=top,
            since=since,
            last_seen_before=last_seen_before,
        )

    def stats(self) -> dict:
        return self.store.stats()
```

---

### cache/cache.py

```python
class SemanticCache:
    def __init__(
        self,
        store: CacheStore,
        embedder: Callable[[str], List[float]],
        threshold: float = 0.95,
    ):
        self.store = store
        self.embedder = embedder
        self.threshold = threshold

    def get(self, query: str) -> Optional[str]:
        """Embed query, delegate to store."""
        vec = self.embedder(query)
        return self.store.get(vec, self.threshold)

    def set(
        self,
        cluster_id: str,
        response: str,
        approved_by: str = "llm"
    ) -> None:
        self.store.set(cluster_id, response, approved_by)
```

---

### middleware/middleware.py

```python
class Middleware:
    def __init__(
        self,
        monitor: Optional[Monitor] = None,
        cache: Optional[SemanticCache] = None,
    ):
        self.monitor = monitor
        self.cache = cache

    def track(self, fn: Callable) -> Callable:
        """
        Use functools.wraps.
        First positional arg of fn must be query: str.

        Order:
        1. If cache active:
           cached = cache.get(query)
           If cached:
             If monitor active → monitor.log(query, latency_ms=0, cache_hit=True)
             return cached
        2. start = time.time()
        3. result = fn(query, *args, **kwargs)
        4. latency_ms = (time.time() - start) * 1000
        5. If monitor active → monitor.log(query, latency_ms, cache_hit=False)
        6. return result
        """
        ...

    def approve_cache(
        self,
        cluster_id: str,
        response: str,
        approved_by: str = "human"
    ) -> None:
        """
        Delegates to cache.set().
        Raises RuntimeError if no cache configured.
        """
        if self.cache is None:
            raise RuntimeError("No cache configured in Middleware.")
        self.cache.set(cluster_id, response, approved_by)
```

---

### __init__.py exports

```python
# raggit/middleware/__init__.py
from raggit.middleware.middleware import Middleware
from raggit.middleware.monitor.monitor import Monitor
from raggit.middleware.cache.cache import SemanticCache
from raggit.middleware.stores.base import MonitorStore, CacheStore
from raggit.middleware.stores.sqlite import SQLiteStore
from raggit.middleware.models import Cluster, Event

# raggit/middleware/monitor/__init__.py
from raggit.middleware.monitor.monitor import Monitor

# raggit/middleware/cache/__init__.py
from raggit.middleware.cache.cache import SemanticCache

# raggit/middleware/stores/__init__.py
from raggit.middleware.stores.base import MonitorStore, CacheStore
from raggit.middleware.stores.sqlite import SQLiteStore
```

---

### Usage example

```python
from raggit.middleware import Middleware, Monitor, SemanticCache, SQLiteStore

store = SQLiteStore(".raggit/middleware.db")
embedder = lambda t: model.encode(t).tolist()

# Same store for both — they don't know they share it
monitor = Monitor(store=store, embedder=embedder, cluster_threshold=0.92)
cache = SemanticCache(store=store, embedder=embedder, threshold=0.95)

mw = Middleware(monitor=monitor, cache=cache)

@mw.track
def answer(query: str) -> str:
    docs = retriever.search(query)
    return llm.generate(query, docs)

# Normal usage
response = answer("how do I reset my password?")

# Stats
print(monitor.stats())
print(monitor.clusters(top=10))

# Approve cache
mw.approve_cache(
    cluster_id="abc-123",
    response="To reset your password...",
    approved_by="human"
)
```

---

### Notes for Claude Code
- Use Metrics.cosine_similarity from raggit.metrics — never reimplement
- SQLite is Python stdlib — no extra dependencies
- functools.wraps on all decorators
- Monitor has zero clustering logic — all in store.log()
- Cache has zero similarity logic — all in store.get()
- SQLiteStore creates .raggit/ directory if not exists
- Vectors stored as json.dumps() in TEXT column
- extra field in events stored as json.dumps(kwargs)
- graph/__init__.py is empty placeholder