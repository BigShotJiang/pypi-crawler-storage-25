# EKS Cluster for GPU workload management

# EKS Cluster Service Role
resource "aws_iam_role" "eks_cluster_role" {
  name = "${local.workspace_prefix}-eks-cluster-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Action = "sts:AssumeRole"
        Effect = "Allow"
        Principal = {
          Service = "eks.amazonaws.com"
        }
      }
    ]
  })

  tags = {
    Name        = "${var.prefix}-eks-cluster-role"
    Environment = local.current_config.environment
  }
}

resource "aws_iam_role_policy_attachment" "eks_cluster_AmazonEKSClusterPolicy" {
  policy_arn = "arn:aws:iam::aws:policy/AmazonEKSClusterPolicy"
  role       = aws_iam_role.eks_cluster_role.name
}

# EKS Node Group Role
resource "aws_iam_role" "eks_node_role" {
  name = "${local.workspace_prefix}-eks-node-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Action = "sts:AssumeRole"
        Effect = "Allow"
        Principal = {
          Service = "ec2.amazonaws.com"
        }
      }
    ]
  })

  tags = {
    Name        = "${var.prefix}-eks-node-role"
    Environment = local.current_config.environment
  }
}

resource "aws_iam_role_policy_attachment" "eks_node_AmazonEKSWorkerNodePolicy" {
  policy_arn = "arn:aws:iam::aws:policy/AmazonEKSWorkerNodePolicy"
  role       = aws_iam_role.eks_node_role.name
}

resource "aws_iam_role_policy_attachment" "eks_node_AmazonEKS_CNI_Policy" {
  policy_arn = "arn:aws:iam::aws:policy/AmazonEKS_CNI_Policy"
  role       = aws_iam_role.eks_node_role.name
}

resource "aws_iam_role_policy_attachment" "eks_node_AmazonEC2ContainerRegistryReadOnly" {
  policy_arn = "arn:aws:iam::aws:policy/AmazonEC2ContainerRegistryReadOnly"
  role       = aws_iam_role.eks_node_role.name
}

resource "aws_iam_role_policy_attachment" "eks_node_AmazonEBSCSIDriverPolicy" {
  policy_arn = "arn:aws:iam::aws:policy/service-role/AmazonEBSCSIDriverPolicy"
  role       = aws_iam_role.eks_node_role.name
}

# Add Bedrock permissions to node role for Claude Code access
resource "aws_iam_role_policy" "eks_node_bedrock_policy" {
  name = "${local.workspace_prefix}-eks-node-bedrock-policy"
  role = aws_iam_role.eks_node_role.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = [
          "bedrock:InvokeModel",
          "bedrock:InvokeModelWithResponseStream",
          "bedrock:ListInferenceProfiles",
          "bedrock:GetInferenceProfile",
          "bedrock:ListFoundationModels",
          "bedrock-mantle:*"
        ]
        Resource = "*"
      },
      {
        Effect = "Allow"
        Action = [
          "aws-marketplace:ViewSubscriptions",
          "aws-marketplace:Subscribe"
        ]
        Resource = "*"
      }
    ]
  })
}

# EKS Cluster
resource "aws_eks_cluster" "gpu_dev_cluster" {
  name     = "${var.prefix}-cluster"
  role_arn = aws_iam_role.eks_cluster_role.arn

  vpc_config {
    subnet_ids = concat([
      aws_subnet.gpu_dev_subnet.id,
      aws_subnet.gpu_dev_subnet_secondary.id,
      aws_subnet.gpu_dev_private_subnet.id,
      aws_subnet.gpu_dev_private_subnet_secondary.id
      ],
      length(aws_subnet.gpu_dev_subnet_tertiary) > 0 ? [aws_subnet.gpu_dev_subnet_tertiary[0].id] : [],
    length(aws_subnet.gpu_dev_private_subnet_tertiary) > 0 ? [aws_subnet.gpu_dev_private_subnet_tertiary[0].id] : [])
    security_group_ids      = [aws_security_group.eks_control_plane_sg.id]
    endpoint_private_access = true
    endpoint_public_access  = true
  }

  depends_on = [
    aws_iam_role_policy_attachment.eks_cluster_AmazonEKSClusterPolicy,
  ]

  tags = {
    Name        = "${var.prefix}-cluster"
    Environment = local.current_config.environment
  }
}

# VPC CNI Addon - Required for pod networking
resource "aws_eks_addon" "vpc_cni" {
  cluster_name = aws_eks_cluster.gpu_dev_cluster.name
  addon_name   = "vpc-cni"

  depends_on = [aws_eks_cluster.gpu_dev_cluster]

  tags = {
    Name        = "${var.prefix}-vpc-cni"
    Environment = local.current_config.environment
  }
}

# EBS CSI Driver Addon - Required for persistent EBS volumes
resource "aws_eks_addon" "ebs_csi_driver" {
  cluster_name = aws_eks_cluster.gpu_dev_cluster.name
  addon_name   = "aws-ebs-csi-driver"

  depends_on = [aws_eks_cluster.gpu_dev_cluster]

  tags = {
    Name        = "${var.prefix}-ebs-csi-driver"
    Environment = local.current_config.environment
  }
}

locals {
  # Architecture to AMI mapping
  architecture_ami_map = {
    "x86_64" = data.aws_ami.eks_gpu_ami_x86_64.id
    "arm64"  = data.aws_ami.eks_gpu_ami_arm64.id
  }

  # Subnet maps: public (for single-EFA instances) and private (for multi-EFA instances)
  public_subnet_map = {
    "primary"   = aws_subnet.gpu_dev_subnet.id
    "secondary" = aws_subnet.gpu_dev_subnet_secondary.id
    "tertiary"  = length(aws_subnet.gpu_dev_subnet_tertiary) > 0 ? aws_subnet.gpu_dev_subnet_tertiary[0].id : aws_subnet.gpu_dev_subnet.id
  }
  private_subnet_map = {
    "primary"   = aws_subnet.gpu_dev_private_subnet.id
    "secondary" = aws_subnet.gpu_dev_private_subnet_secondary.id
    "tertiary"  = length(aws_subnet.gpu_dev_private_subnet_tertiary) > 0 ? aws_subnet.gpu_dev_private_subnet_tertiary[0].id : aws_subnet.gpu_dev_private_subnet.id
  }

  # Map internal Terraform GPU types to user-facing Kubernetes GPU types
  # This allows multiple AZ node groups to share the same user-facing GPU type
  # nsight variants map to base type so users see them as regular GPU nodes
  gpu_type_kubernetes_labels = {
    "t4"       = "t4"
    "t4-az2"   = "t4" # Both t4 and t4-az2 should be labeled as "t4" in Kubernetes
    "l4"       = "l4"
    "a10g"       = "a10g"
    "rtxpro6000" = "rtxpro6000"
    "h100"     = "h100"
    "h200"     = "h200"
    "b200"     = "b200"
    "a100"     = "a100"
    "cpu-arm"  = "cpu-arm"
    "cpu-x86"  = "cpu-x86"
    "t4-small" = "t4-small"
  }

  # Flatten capacity reservations to create multiple ASGs when needed
  # Each CR entry must have a stable 'key' field so removing entries doesn't shift other ASG keys.
  gpu_capacity_reservations = flatten([
    for gpu_type, gpu_config in local.current_config.supported_gpu_types : try(gpu_config.virtual, false) ? [] : [
      for cr_index, cr_config in try(local.capacity_reservations[terraform.workspace][gpu_type], [null]) : {
        gpu_type                = gpu_type
        gpu_config              = gpu_config
        capacity_reservation_id = cr_config != null ? cr_config.id : null
        asg_key                 = cr_config != null ? "${gpu_type}-${cr_config.key}" : gpu_type
        # Use manual instance count from capacity reservation config, fallback to GPU config default
        instance_count = cr_config != null ? cr_config.instance_count : gpu_config.instance_count
        # Resolve which AZ bucket this ASG belongs to: CR-specific → GPU type → default "primary"
        subnet_az = (
          cr_config != null && cr_config.id != null
          ? lookup(local.capacity_reservation_azs[terraform.workspace], cr_config.id, local.gpu_subnet_assignments[terraform.workspace][gpu_type])
          : local.gpu_subnet_assignments[terraform.workspace][gpu_type]
        )
        # Per-CR override for efa_network_cards (e.g. p5en.48xlarge caps at 16 vs p5e at 32)
        efa_network_cards = cr_config != null ? try(cr_config.efa_network_cards, gpu_config.efa_network_cards) : gpu_config.efa_network_cards
        # Optional MIG profile (e.g. "all-balanced", "all-1g.10gb"). When set, user-data labels the node so nvidia-mig-manager partitions the GPUs.
        # Default to "" (not null) — null breaks templatefile() string interpolation downstream.
        mig_profile = cr_config != null ? try(cr_config.mig_profile, "") : ""
        # Multi-EFA instances (>1 network card) must use private subnets (no public IP in launch template)
        use_private_subnet = (cr_config != null ? try(cr_config.efa_network_cards, try(gpu_config.efa_network_cards, 0)) : try(gpu_config.efa_network_cards, 0)) > 1
      }
    ]
  ])

  # Convert to map for for_each
  gpu_asg_configs = {
    for item in local.gpu_capacity_reservations : item.asg_key => item
  }
}

# Auto Scaling Groups - one per GPU type + capacity reservation combination
resource "aws_autoscaling_group" "gpu_dev_nodes" {
  for_each = local.gpu_asg_configs

  name = "${var.prefix}-gpu-nodes-${each.key}"
  # Multi-EFA instances use private subnets (NAT GW for internet), others use public
  vpc_zone_identifier = [
    each.value.use_private_subnet
    ? local.private_subnet_map[each.value.subnet_az]
    : local.public_subnet_map[each.value.subnet_az]
  ]
  target_group_arns         = []
  health_check_type         = "EC2"
  health_check_grace_period = 300

  # Use dynamic instance count from capacity reservation
  min_size         = each.value.instance_count
  max_size         = each.value.instance_count
  desired_capacity = each.value.instance_count

  # Don't wait for instances to become healthy - prevents Terraform failures when AWS can't place instances
  wait_for_capacity_timeout = "0"

  # Use mixed instances policy for multiple instance types (like H200)
  # But NOT when using capacity reservations (AWS doesn't allow mixed instances with CR)
  dynamic "mixed_instances_policy" {
    for_each = each.value.gpu_config.instance_types != null && each.value.capacity_reservation_id == null ? [1] : []
    content {
      launch_template {
        launch_template_specification {
          launch_template_id = aws_launch_template.gpu_dev_launch_template[each.key].id
          version            = "$Latest"
        }

        # Allow both p5e.48xlarge and p5en.48xlarge for H200
        dynamic "override" {
          for_each = each.value.gpu_config.instance_types
          content {
            instance_type = override.value
          }
        }
      }
    }
  }

  # Use single launch template for single instance types OR when using capacity reservations
  # (capacity reservations don't support mixed instances policy)
  dynamic "launch_template" {
    for_each = each.value.gpu_config.instance_types == null || each.value.capacity_reservation_id != null ? [1] : []
    content {
      id      = aws_launch_template.gpu_dev_launch_template[each.key].id
      version = "$Latest"
    }
  }

  # Fast instance replacement
  instance_refresh {
    strategy = "Rolling"
    preferences {
      min_healthy_percentage = 0 # Replace all at once for speed
    }
  }

  tag {
    key                 = "Name"
    value               = "${var.prefix}-gpu-node-${each.key}"
    propagate_at_launch = true
  }

  tag {
    key                 = "kubernetes.io/cluster/${aws_eks_cluster.gpu_dev_cluster.name}"
    value               = "owned"
    propagate_at_launch = true
  }

  tag {
    key                 = "Environment"
    value               = local.current_config.environment
    propagate_at_launch = true
  }

  tag {
    key                 = "GpuType"
    value               = each.value.gpu_type
    propagate_at_launch = true
  }

  tag {
    key                 = "CapacityReservation"
    value               = each.value.capacity_reservation_id != null ? each.value.capacity_reservation_id : "none"
    propagate_at_launch = true
  }
}


# Launch templates - one per GPU type + capacity reservation combination
resource "aws_launch_template" "gpu_dev_launch_template" {
  for_each = local.gpu_asg_configs

  name_prefix = "${var.prefix}-gpu-${each.key}-"
  image_id    = local.architecture_ami_map[try(each.value.gpu_config.architecture, "x86_64")]
  key_name    = var.key_pair_name

  # Set instance_type if not using mixed instances policy OR if using capacity reservations
  # (capacity reservations require single instance type in launch template)
  instance_type = each.value.gpu_config.instance_types == null || each.value.capacity_reservation_id != null ? each.value.gpu_config.instance_type : null

  iam_instance_profile {
    name = aws_iam_instance_profile.eks_node_instance_profile.name
  }

  # Block device mapping for 4TB root volume (Amazon Linux 2023 uses /dev/xvda as root)
  block_device_mappings {
    device_name = "/dev/xvda"
    ebs {
      volume_size           = 4096 # 4TB
      volume_type           = "gp3"
      delete_on_termination = true
      encrypted             = true
    }
  }

  # Only use placement group if specified
  # NOTE: This is key for instances where we are using capacity blocks / reservations
  dynamic "placement" {
    for_each = each.value.gpu_config.use_placement_group ? [1] : []
    content {
      group_name = aws_placement_group.gpu_dev_pg[each.value.gpu_type].name
    }
  }

  # Single-EFA instances: public subnet with public IP (standard networking)
  dynamic "network_interfaces" {
    for_each = !each.value.use_private_subnet ? [0] : []
    content {
      device_index                = 0
      associate_public_ip_address = true
      security_groups             = [aws_security_group.gpu_dev_sg.id]
      subnet_id                   = each.value.gpu_config.use_placement_group ? null : local.public_subnet_map[each.value.subnet_az]
      interface_type              = try(each.value.efa_network_cards, 0) > 0 ? "efa" : "interface"
      delete_on_termination       = true
    }
  }

  # Multi-EFA instances: private subnet, no public IP, card 0 = EFA (IP + RDMA)
  dynamic "network_interfaces" {
    for_each = each.value.use_private_subnet ? [0] : []
    content {
      device_index                = 0
      associate_public_ip_address = false
      security_groups             = [aws_security_group.gpu_dev_sg.id]
      subnet_id                   = each.value.gpu_config.use_placement_group ? null : local.private_subnet_map[each.value.subnet_az]
      interface_type              = "efa"
      network_card_index          = 0
      delete_on_termination       = true
    }
  }

  # Multi-EFA: cards 1..N-1 = efa-only (RDMA only, no IP)
  # Each network card supports 2 device indices (0 and 1); device_index must be 0
  # since this is the only interface on each card
  dynamic "network_interfaces" {
    for_each = each.value.use_private_subnet ? range(1, try(each.value.efa_network_cards, 1)) : []
    content {
      device_index          = 0
      interface_type        = "efa-only"
      network_card_index    = network_interfaces.value
      security_groups       = [aws_security_group.gpu_dev_sg.id]
      delete_on_termination = true
    }
  }

  # Conditionally add instance_market_options for capacity block instances (only when capacity reservation exists)
  dynamic "instance_market_options" {
    for_each = each.value.capacity_reservation_id != null ? [1] : []
    content {
      market_type = "capacity-block"
    }
  }

  # Add capacity reservation specification for instances that have reservations configured
  dynamic "capacity_reservation_specification" {
    for_each = each.value.capacity_reservation_id != null ? [1] : []
    content {
      capacity_reservation_preference = "capacity-reservations-only"
      capacity_reservation_target {
        capacity_reservation_id = each.value.capacity_reservation_id
      }
    }
  }

  user_data = base64encode(templatefile("${path.module}/templates/al2023-user-data.sh", {
    cluster_name        = aws_eks_cluster.gpu_dev_cluster.name
    cluster_endpoint    = aws_eks_cluster.gpu_dev_cluster.endpoint
    cluster_ca          = aws_eks_cluster.gpu_dev_cluster.certificate_authority[0].data
    cluster_cidr        = var.vpc_cidr
    region              = local.current_config.aws_region
    gpu_type            = local.gpu_type_kubernetes_labels[each.value.gpu_type]
    profiling_dedicated = try(each.value.gpu_config.profiling_dedicated, false)
    mig_profile         = each.value.mig_profile != null ? each.value.mig_profile : ""
    container_image     = local.latest_image_uri
  }))

  tag_specifications {
    resource_type = "instance"
    tags = {
      Name                = "${var.prefix}-gpu-instance-${each.key}"
      Environment         = local.current_config.environment
      GpuType             = each.value.gpu_type
      CapacityReservation = each.value.capacity_reservation_id != null ? each.value.capacity_reservation_id : "none"
    }
  }

  tags = {
    Name                = "${var.prefix}-gpu-launch-template-${each.key}"
    Environment         = local.current_config.environment
    GpuType             = each.value.gpu_type
    CapacityReservation = each.value.capacity_reservation_id != null ? each.value.capacity_reservation_id : "none"
  }
}

# IAM Instance Profile for GPU nodes
resource "aws_iam_instance_profile" "eks_node_instance_profile" {
  name = "${local.workspace_prefix}-eks-node-instance-profile"
  role = aws_iam_role.eks_node_role.name

  tags = {
    Name        = "${var.prefix}-eks-node-instance-profile"
    Environment = local.current_config.environment
  }
}


# Using only Auto Scaling Groups for GPU nodes

# Get the latest EKS-optimized AL2023 GPU AMI for x86_64
data "aws_ami" "eks_gpu_ami_x86_64" {
  most_recent = true
  owners      = ["amazon"]

  filter {
    name   = "name"
    values = ["amazon-eks-node-al2023-x86_64-standard-1.33-*"]
  }

  filter {
    name   = "architecture"
    values = ["x86_64"]
  }
}

# Get the latest EKS-optimized AL2023 GPU AMI for ARM64
data "aws_ami" "eks_gpu_ami_arm64" {
  most_recent = true
  owners      = ["amazon"]

  filter {
    name   = "name"
    values = ["amazon-eks-node-al2023-arm64-standard-1.33-*"]
  }

  filter {
    name   = "architecture"
    values = ["arm64"]
  }
}

# Deep Learning Base AMI for high-end GPU instances (H100, H200, B200) - has proper IPv6 networking
data "aws_ami" "deep_learning_gpu_ami" {
  most_recent = true
  owners      = ["amazon"]

  filter {
    name   = "name"
    values = ["Deep Learning Base OSS Nvidia Driver GPU AMI (Ubuntu 24.04) *"]
  }
  filter {
    name   = "virtualization-type"
    values = ["hvm"]
  }
  filter {
    name   = "root-device-type"
    values = ["ebs"]
  }
  filter {
    name   = "state"
    values = ["available"]
  }
}

# CPU Launch template and Auto Scaling Group (consistent with GPU nodes)
resource "aws_launch_template" "cpu_launch_template" {
  name_prefix   = "${var.prefix}-cpu-"
  image_id      = data.aws_ami.eks_gpu_ami_x86_64.id
  key_name      = var.key_pair_name
  instance_type = "c5.4xlarge"

  vpc_security_group_ids = [aws_security_group.gpu_dev_sg.id]

  # Block device mapping for 4TB root volume (Amazon Linux 2023 uses /dev/xvda as root)
  block_device_mappings {
    device_name = "/dev/xvda"
    ebs {
      volume_size           = 4096 # 4TB
      volume_type           = "gp3"
      delete_on_termination = true
      encrypted             = true
    }
  }

  iam_instance_profile {
    name = aws_iam_instance_profile.eks_node_instance_profile.name
  }

  user_data = base64encode(templatefile("${path.module}/templates/al2023-cpu-user-data.sh", {
    cluster_name     = aws_eks_cluster.gpu_dev_cluster.name
    cluster_endpoint = aws_eks_cluster.gpu_dev_cluster.endpoint
    cluster_ca       = aws_eks_cluster.gpu_dev_cluster.certificate_authority[0].data
    cluster_cidr     = var.vpc_cidr
    region           = local.current_config.aws_region
    gpu_type         = "cpu"
  }))

  tag_specifications {
    resource_type = "instance"
    tags = {
      Name        = "${var.prefix}-cpu-mgmt-node"
      Environment = local.current_config.environment
      NodeType    = "cpu-management"
    }
  }

  tags = {
    Name        = "${var.prefix}-cpu-launch-template"
    Environment = local.current_config.environment
  }
}

resource "aws_autoscaling_group" "cpu_nodes" {
  name                      = "${var.prefix}-cpu-nodes"
  vpc_zone_identifier       = [aws_subnet.gpu_dev_subnet.id, aws_subnet.gpu_dev_subnet_secondary.id]
  target_group_arns         = []
  health_check_type         = "EC2"
  health_check_grace_period = 300

  min_size         = 1
  max_size         = 4
  desired_capacity = 2

  launch_template {
    id      = aws_launch_template.cpu_launch_template.id
    version = "$Latest"
  }

  # Fast instance replacement
  instance_refresh {
    strategy = "Rolling"
    preferences {
      min_healthy_percentage = 0
    }
  }

  tag {
    key                 = "Name"
    value               = "${var.prefix}-cpu-mgmt-node"
    propagate_at_launch = true
  }

  tag {
    key                 = "kubernetes.io/cluster/${aws_eks_cluster.gpu_dev_cluster.name}"
    value               = "owned"
    propagate_at_launch = true
  }

  tag {
    key                 = "Environment"
    value               = local.current_config.environment
    propagate_at_launch = true
  }

  tag {
    key                 = "NodeType"
    value               = "cpu-management"
    propagate_at_launch = true
  }
}
