from imagcon_mcp.main import main as _cli_main


def main() -> None:
    _cli_main()


if __name__ == "__main__":
    main()
