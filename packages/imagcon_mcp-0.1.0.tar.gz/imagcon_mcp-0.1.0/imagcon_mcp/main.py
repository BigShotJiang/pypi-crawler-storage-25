from __future__ import annotations

import argparse
import os
import sys

from imagcon_mcp.client import API_KEYS_URL, ImagconClient
from imagcon_mcp.server import mcp, set_client


def _resolve_api_key(cli_key: str | None) -> str:
    key = (cli_key or os.environ.get("IMAGCON_API_KEY") or "").strip()
    if not key:
        print(
            "Missing Imagcon API key. Set IMAGCON_API_KEY or pass --api-key.\n"
            f"Create a key at {API_KEYS_URL}",
            file=sys.stderr,
        )
        raise SystemExit(2)
    if not key.startswith("ic_live_"):
        print(
            "Invalid API key format. Imagcon keys start with ic_live_.\n"
            f"See {API_KEYS_URL}",
            file=sys.stderr,
        )
        raise SystemExit(2)
    return key


def main() -> None:
    parser = argparse.ArgumentParser(prog="imagcon-mcp")
    parser.add_argument(
        "--api-key",
        dest="api_key",
        default=None,
        help="Imagcon API key (overrides IMAGCON_API_KEY)",
    )
    args, remaining = parser.parse_known_args()
    sys.argv = [sys.argv[0], *remaining]
    api_key = _resolve_api_key(args.api_key)
    client = ImagconClient(api_key)
    set_client(client)
    try:
        mcp.run()
    finally:
        client.close()
