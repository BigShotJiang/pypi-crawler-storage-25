from __future__ import annotations

import io
import zipfile
from pathlib import Path
from typing import Any

import httpx

BASE_URL = "https://imagcon.app"
API_KEYS_URL = "https://imagcon.app/api-keys"


class ImagconAPIError(RuntimeError):
    pass


class ImagconClient:
    def __init__(self, api_key: str, timeout: float = 300.0) -> None:
        self._client = httpx.Client(
            base_url=BASE_URL,
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=timeout,
        )

    def close(self) -> None:
        self._client.close()

    def _request_error_message(self, response: httpx.Response) -> str:
        if response.status_code in (401, 403):
            return (
                f"Imagcon API returned {response.status_code}. "
                f"Check your API key at {API_KEYS_URL}"
            )
        body = response.text[:500]
        return f"Imagcon API error {response.status_code}: {body}"

    def generate_image(self, description: str) -> dict[str, Any]:
        try:
            r = self._client.post(
                "/routes/image_generator/generate-image",
                json={
                    "description": description,
                    "aspect_ratio": "1:1",
                    "number_of_images": 1,
                },
            )
        except httpx.RequestError as e:
            raise ImagconAPIError(f"Network error calling Imagcon: {e}") from e
        if r.status_code >= 400:
            raise ImagconAPIError(self._request_error_message(r))
        return r.json()

    def generate_pwa_icons(self, image_key: str) -> dict[str, Any]:
        try:
            r = self._client.post(
                "/routes/image_generator/generate-pwa-icons",
                json={"image_key": image_key},
            )
        except httpx.RequestError as e:
            raise ImagconAPIError(f"Network error calling Imagcon: {e}") from e
        if r.status_code >= 400:
            raise ImagconAPIError(self._request_error_message(r))
        return r.json()

    def save_pwa_icon_set(
        self,
        set_name: str,
        original_image_key: str,
        icons: list[dict[str, Any]],
        prompt: str | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "set_name": set_name,
            "original_image_key": original_image_key,
            "icons": icons,
            "request_for_gallery": False,
        }
        if prompt is not None:
            body["prompt"] = prompt
        try:
            r = self._client.post(
                "/routes/pwa_gallery/save-pwa-icon-set",
                json=body,
            )
        except httpx.RequestError as e:
            raise ImagconAPIError(f"Network error calling Imagcon: {e}") from e
        if r.status_code >= 400:
            raise ImagconAPIError(self._request_error_message(r))
        return r.json()

    def download_pwa_icon_set_zip(self, set_id: str) -> bytes:
        try:
            r = self._client.get(f"/routes/pwa_gallery/download-pwa-icon-set/{set_id}")
        except httpx.RequestError as e:
            raise ImagconAPIError(f"Network error calling Imagcon: {e}") from e
        if r.status_code >= 400:
            raise ImagconAPIError(self._request_error_message(r))
        return r.content

    def get_credit_balance(self) -> dict[str, Any]:
        try:
            r = self._client.get("/routes/credits/balance")
        except httpx.RequestError as e:
            raise ImagconAPIError(f"Network error calling Imagcon: {e}") from e
        if r.status_code >= 400:
            raise ImagconAPIError(self._request_error_message(r))
        return r.json()

    @staticmethod
    def extract_zip_to_dir(zip_bytes: bytes, output_dir: Path) -> None:
        output_dir.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(io.BytesIO(zip_bytes)) as zf:
            zf.extractall(output_dir)
