from __future__ import annotations

from pathlib import Path
from typing import Any

from mcp.server.fastmcp import FastMCP

from imagcon_mcp.client import ImagconClient

mcp = FastMCP("imagcon")

_client: ImagconClient | None = None


def set_client(client: ImagconClient) -> None:
    global _client
    _client = client


def _require_client() -> ImagconClient:
    if _client is None:
        raise RuntimeError("Imagcon client is not configured.")
    return _client


def _set_name_from_description(description: str) -> str:
    d = description.strip()
    if not d:
        return "PWA icon set"
    if len(d) > 100:
        return d[:99] + "…"
    return d


def _icons_for_save(raw: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [
        {"size": ic["size"], "image_key": ic.get("image_key") or ic["key"]}
        for ic in raw
    ]


@mcp.tool()
def generate_pwa_icons(description: str, output_dir: str = "./public/icons") -> str:
    client = _require_client()
    out = Path(output_dir)
    gen = client.generate_image(description)
    image_key = gen["image_key"]
    pwa = client.generate_pwa_icons(image_key)
    raw_icons: list[dict[str, Any]] = pwa["icons"]
    icons_payload = _icons_for_save(raw_icons)
    save = client.save_pwa_icon_set(
        set_name=_set_name_from_description(description),
        original_image_key=image_key,
        icons=icons_payload,
        prompt=description,
    )
    set_id = save["set_id"]
    zip_bytes = client.download_pwa_icon_set_zip(set_id)
    ImagconClient.extract_zip_to_dir(zip_bytes, out)
    icon_count = len(raw_icons)
    return (
        f"Generated {icon_count} icons in {out.resolve()}. manifest.json included."
    )


@mcp.tool()
def get_credit_balance() -> str:
    client = _require_client()
    data = client.get_credit_balance()
    remaining = data["remaining_credits"]
    return f"You have {remaining} credits remaining."
