# imagcon-mcp

Python MCP server that wraps the [Imagcon](https://imagcon.app) API so assistants can generate PWA icon sets (many sizes, maskable assets, and `manifest.json`) without opening the site.

## Requirements

- Python 3.11+
- An Imagcon API key starting with `ic_live_` from [imagcon.app/api-keys](https://imagcon.app/api-keys)

## Install and run locally

```bash
pip install .
imagcon-mcp
# or
python -m imagcon_mcp
```

Set `IMAGCON_API_KEY` or pass `--api-key` (see below).

## Claude Code / Cursor (uvx)

With the key in the environment:

```bash
claude mcp add imagcon -- uvx imagcon-mcp
```

Or pass the key on the command line:

```bash
claude mcp add imagcon -- uvx imagcon-mcp --api-key ic_live_...
```

Ensure `IMAGCON_API_KEY` is set in the MCP process environment if you do not use `--api-key`.

## Tools

- **`generate_pwa_icons`** — Full flow: generate source image, resize to all PWA sizes, save the set, download the ZIP, extract to `output_dir` (default `./public/icons`).
- **`get_credit_balance`** — Returns remaining Imagcon credits.

Each successful `generate_pwa_icons` run uses credits on your Imagcon account.

## Configuration

| Source | Variable / flag |
|--------|------------------|
| Environment | `IMAGCON_API_KEY` |
| CLI | `--api-key` (overrides the env var) |

If the key is missing, the process exits with an error pointing to [imagcon.app/api-keys](https://imagcon.app/api-keys).

## API base URL

All requests go to `https://imagcon.app` (no other base URL is supported).
