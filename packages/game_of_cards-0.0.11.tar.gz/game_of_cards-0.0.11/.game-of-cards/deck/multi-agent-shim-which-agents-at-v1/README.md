---
title: multi-agent-shim-which-agents-at-v1
summary: "Spec-Kit's `--integration <agent>` flag is the niche-standard pattern for multi-agent shim install — the same `init` populates per-agent shim directories selectively. GoC needs `goc install --agents` with the v1 runtime set kept intentionally small: Claude and Codex are in scope, OpenCLAW is deferred until a downstream repo needs it. OpenCode remains a separate free path because it natively reads `.claude/skills/`."
status: done
stage: null
contribution: medium
created: 2026-05-03
closed_at: 2026-05-04
human_gate: none
advances:
  - ship-game-of-cards-as-cross-agent-cli
advanced_by:
  - install-claude-harness
  - install-codex-harness
tags: [story, infra]
definition_of_done: |
  - [x] Decision recorded: v1 agent set is Claude + Codex; OpenCLAW is deferred until a downstream repo needs it
  - [x] `goc install --agents <list>` flag implemented; `goc install` with no flag defaults to `claude` (or whatever the v1 default decision says)
  - [x] For each v1 agent, a `templates/agents/<agent>/` directory exists with the shim files for that agent's convention (e.g., `.cursor/rules/goc.mdc`, `.codex/...`, `.github/copilot-instructions.md`)
  - [x] Per-agent shim content is generated, not duplicated — the slash-command surface and skill descriptions come from a shared source; only the *file format and path convention* differs per agent
  - [x] Documentation: README on the new repo lists supported agents at v1, with a clear "to add agent X, file an issue / PR template Y" section for community extension
  - [x] OpenCode mentioned explicitly as free (reads `.claude/skills/` natively); hooks-not-supported caveat documented
---

# Multi-agent shim — which agents at v1?

## Decision

*Resolved 2026-05-03:* Claude + extension hook

*Reasoning:* shipping fast on Claude+AGENTS.md covers six agents indirectly, and community PRs grow per-agent shims post-v1 the way Spec-Kit's integrations grew

*Updated 2026-05-04:* OpenCLAW is deferred. OpenCLAW installation is not needed
in this repo; keep it out of v1 unless a downstream repo creates a concrete
need for OpenCLAW-native GoC guidance.
## Recommendation (for the human deciding)

**Option C** unless there's a specific Cursor/Codex user lined up to need v1. The scope-vs-reach tradeoff strongly favors shipping fast on Claude + AGENTS.md (which already covers the six-agent set indirectly), with a documented extension path. Spec-Kit's growth from 3 → 30+ agents happened post-v1 via PRs, not in the launch sprint.

The argument for Option B is real if Zauberzeug has a concrete cross-agent use case (e.g., "we want to use GoC on the labkit project where the team uses Cursor"). Otherwise it's premature.

## What

After the decision lands:

1. **Implement `goc install --agents`** — Click multi-value flag, default from a config constant, validates against the registered agent shim directories.
2. **Per-agent shim templates** in `templates/agents/<agent>/`. For each agent at v1, author the shim files matching that agent's convention.
3. **Shared shim content** — slash-command descriptions, skill summaries — comes from a single source-of-truth YAML or JSON in `templates/`, then per-agent renderers convert to that agent's format.
4. **README on the new repo** lists supported agents with a contribution guide for adding new ones.

## Cross-references

- Parent epic: `ship-game-of-cards-as-cross-agent-cli`
- Sibling install card: `install-command-scaffolds-repo` (consumes per-agent shim templates)
- Sibling AGENTS.md card: `write-agentsmd-alongside-claudemd` (covers the agent-agnostic guidance regardless of which agents have shims)
- Harness split: `install-claude-harness`, `install-codex-harness`; `install-openclaw-harness` is deferred
- Prior art: Spec-Kit `--integration <agent>` (`docs/reference/integrations.md` in github/spec-kit)
- OpenCode skill compat: sst/opencode reads `.claude/skills/` natively → free, no shim needed
