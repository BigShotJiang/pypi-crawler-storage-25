# import-mend

Detect and repair broken Python imports after refactoring — with zero runtime cost.

## What it does

After a codebase refactoring (manual or autonomous), module paths shift. Every file that
imported moved symbols now references a path that no longer exists. `import-mend` fixes
this retroactively:

1. **Inventories** symbols before and after using git history + AST (no code executed)
2. **Detects** moves, renames, splits, and merges in the migration map
3. **Rewrites** all broken imports in-place using `libcst` (format-preserving)
4. **Verifies** every import via filesystem + AST checks (zero runtime loading)

## Installation

```bash
pip install import-mend
```

## Usage

```bash
# Full pipeline: fix then verify
python -m import_mend run

# Fix broken imports only
python -m import_mend fix

# Verify imports only (CI gate)
python -m import_mend check

# With options
python -m import_mend run \
  --source-dirs src lib \
  --git-ref HEAD~3 \
  --format json \
  --log-level DEBUG
```

## Programmatic API

```python
from import_mend import fix, check, run

# Full pipeline
result = run(root="/path/to/project", source_dirs=["src"], git_ref="HEAD~1")

# Fix only
fix_results = fix(root=".", git_ref="abc123")

# Check only
errors = check(root=".", encapsulation_check=True)
```

## Configuration

Add to `pyproject.toml`:

```toml
[tool.import_mend]
source_dirs = ["src", "lib"]
exclude_patterns = [".venv", "__pycache__", "node_modules"]
git_ref = "HEAD"
encapsulation_check = true
output_format = "human"   # or "json"
log_level = "INFO"        # or "DEBUG", "ERROR"
check_stubs = true        # .pyi stub fallback
check_getattr = true      # __getattr__ suppression
```

## Design

- **Deterministic-first:** AST-based analysis handles the common case. LLM integration
  for residuals is out of scope — the structured error list is the handoff contract.
- **Zero runtime cost:** The checker never loads a module. Safe in any environment.
- **Generic:** Works on any Python project with git. No project-specific config required.
- **Single dependency:** Only `libcst` beyond the standard library.

## License

MIT
