"""Pytest configuration for import_mend tests.

The package is installed in development mode (pip install -e .) so
``import import_mend`` resolves via the installed src/import_mend/.
No sys.path manipulation required.
"""
