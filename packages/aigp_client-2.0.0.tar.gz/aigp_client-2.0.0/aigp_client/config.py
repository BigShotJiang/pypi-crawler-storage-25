"""Client configuration — provider selection and initialization."""

from __future__ import annotations

from dataclasses import dataclass, field

from .providers.model import create as create_model, ModelProviderBase
from .providers.transport import HttpxTransportProvider, TransportProviderBase
from .providers.consent import PassthroughConsentHelper, ConsentHelperBase


@dataclass
class ClientConfig:
    """Configuration for the AIGP governance client.

    Example:
        config = ClientConfig(
            gov_url="https://gov.example.com",
            app_id="MY_APP",
            hmac_secret="...",
            model={"provider": "bedrock", "region": "us-east-1"},
        )
        components = config.build()
    """
    gov_url: str = ""
    app_id: str = ""
    hmac_secret: str = ""
    mode: str = "REPORT"
    model: dict = field(default_factory=lambda: {"provider": "bedrock", "region": "us-east-1"})
    transport: dict = field(default_factory=lambda: {"timeout": 5.0})
    consent_tier: str = "STANDARD"

    def build(self) -> "ClientComponents":
        """Build all client components from config."""
        # Model provider
        model_cfg = dict(self.model)
        model_provider_name = model_cfg.pop("provider", "bedrock")
        model_provider = create_model(model_provider_name, **model_cfg)

        # Transport
        transport = HttpxTransportProvider(base_url=self.gov_url, **self.transport)

        # Consent
        consent = PassthroughConsentHelper()

        return ClientComponents(
            model=model_provider, transport=transport, consent=consent,
            gov_url=self.gov_url, app_id=self.app_id,
            hmac_secret=self.hmac_secret, mode=self.mode,
        )


@dataclass
class ClientComponents:
    """Fully initialized client components."""
    model: ModelProviderBase
    transport: TransportProviderBase
    consent: ConsentHelperBase
    gov_url: str
    app_id: str
    hmac_secret: str
    mode: str
