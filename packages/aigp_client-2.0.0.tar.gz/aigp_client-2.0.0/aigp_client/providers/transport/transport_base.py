"""Transport provider base — abstract interface for AIGP protocol communication."""

from __future__ import annotations

from abc import ABC, abstractmethod


class TransportProviderBase(ABC):
    """Abstract transport for communicating with the governance authority."""

    @abstractmethod
    async def post(self, path: str, body: bytes, headers: dict) -> dict:
        """Send a POST request. Returns response dict."""
        ...

    @abstractmethod
    async def get(self, path: str, headers: dict) -> dict:
        """Send a GET request. Returns response dict."""
        ...

    @abstractmethod
    async def close(self) -> None:
        """Clean up resources."""
        ...
