"""HTTPX transport provider — default HTTP transport."""

from __future__ import annotations

import httpx

from ..transport_base import TransportProviderBase


class HttpxTransportProvider(TransportProviderBase):
    """HTTPX-based transport. Default for all AIGP communication."""

    def __init__(self, base_url: str, timeout: float = 5.0, **kwargs):
        self._base_url = base_url.rstrip("/")
        self._client = httpx.AsyncClient(timeout=timeout)

    async def post(self, path: str, body: bytes, headers: dict) -> dict:
        resp = await self._client.post(
            f"{self._base_url}{path}", content=body,
            headers={**headers, "Content-Type": "application/json"},
        )
        return resp.json() if resp.status_code < 400 else {"error": resp.text, "status_code": resp.status_code}

    async def get(self, path: str, headers: dict) -> dict:
        resp = await self._client.get(f"{self._base_url}{path}", headers=headers)
        return resp.json() if resp.status_code < 400 else {"error": resp.text, "status_code": resp.status_code}

    async def close(self) -> None:
        await self._client.aclose()
