"""Model provider base — abstract interface for AI model invocation."""

from __future__ import annotations

from abc import ABC, abstractmethod


class ModelProviderBase(ABC):
    """Abstract interface for invoking AI models.

    Implementations: bedrock, azure_openai, vertex.
    """

    @abstractmethod
    async def invoke(self, model_id: str, messages: list[dict], system_prompt: str = "",
                     max_tokens: int = 4096, temperature: float = 0.7, **kwargs) -> dict:
        """Invoke a model. Returns provider-native response dict."""
        ...

    @abstractmethod
    async def invoke_text(self, model_id: str, prompt: str, system_prompt: str = "", **kwargs) -> str:
        """Convenience: invoke and return just the text response."""
        ...

    @abstractmethod
    async def retrieve(self, kb_id: str, query: str, num_results: int = 5, **kwargs) -> list[dict]:
        """Retrieve from a knowledge base."""
        ...

    @abstractmethod
    async def retrieve_and_generate(self, kb_id: str, query: str, model_arn: str, **kwargs) -> str:
        """RAG: retrieve + generate."""
        ...

    @abstractmethod
    async def close(self) -> None:
        """Clean up resources."""
        ...
