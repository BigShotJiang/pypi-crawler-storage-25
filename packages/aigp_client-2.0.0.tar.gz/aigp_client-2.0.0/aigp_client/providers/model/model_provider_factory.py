"""Model provider factory."""

from __future__ import annotations

from .model_provider_base import ModelProviderBase

_REGISTRY: dict[str, type[ModelProviderBase]] = {}


def register(name: str):
    def wrapper(cls: type[ModelProviderBase]):
        _REGISTRY[name] = cls
        return cls
    return wrapper


def create(provider_name: str, **config) -> ModelProviderBase:
    if provider_name not in _REGISTRY:
        raise ValueError(f"Unknown model provider: {provider_name}. Available: {list(_REGISTRY.keys())}")
    return _REGISTRY[provider_name](**config)


def available() -> list[str]:
    return list(_REGISTRY.keys())
