"""Bedrock model provider — AWS Bedrock Converse + KB APIs."""

from __future__ import annotations

import asyncio
import time

from ..model_provider_base import ModelProviderBase
from ..model_provider_factory import register


@register("bedrock")
class BedrockModelProvider(ModelProviderBase):
    """AWS Bedrock implementation via Converse API + Knowledge Bases."""

    def __init__(self, region: str = "us-east-1", **kwargs):
        self._region = region
        self._clients: dict[str, object] = {}
        self._agent_clients: dict[str, object] = {}

    def _get_client(self, region: str | None = None):
        r = region or self._region
        if r not in self._clients:
            import boto3
            self._clients[r] = boto3.client("bedrock-runtime", region_name=r)
        return self._clients[r]

    def _get_agent_client(self, region: str | None = None):
        r = region or self._region
        if r not in self._agent_clients:
            import boto3
            self._agent_clients[r] = boto3.client("bedrock-agent-runtime", region_name=r)
        return self._agent_clients[r]

    async def invoke(self, model_id: str, messages: list[dict], system_prompt: str = "",
                     max_tokens: int = 4096, temperature: float = 0.7, **kwargs) -> dict:
        client = self._get_client(kwargs.get("region"))
        call_kwargs = {
            "modelId": model_id, "messages": messages,
            "inferenceConfig": {"maxTokens": max_tokens, "temperature": temperature},
        }
        if system_prompt:
            call_kwargs["system"] = [{"text": system_prompt}]
        return await asyncio.to_thread(client.converse, **call_kwargs)

    async def invoke_text(self, model_id: str, prompt: str, system_prompt: str = "", **kwargs) -> str:
        messages = [{"role": "user", "content": [{"text": prompt}]}]
        resp = await self.invoke(model_id, messages, system_prompt=system_prompt, **kwargs)
        return resp.get("output", {}).get("message", {}).get("content", [{}])[0].get("text", "")

    async def retrieve(self, kb_id: str, query: str, num_results: int = 5, **kwargs) -> list[dict]:
        client = self._get_agent_client(kwargs.get("region"))
        resp = await asyncio.to_thread(
            client.retrieve,
            knowledgeBaseId=kb_id,
            retrievalQuery={"text": query},
            retrievalConfiguration={"vectorSearchConfiguration": {"numberOfResults": num_results}},
        )
        return resp.get("retrievalResults", [])

    async def retrieve_and_generate(self, kb_id: str, query: str, model_arn: str, **kwargs) -> str:
        client = self._get_agent_client(kwargs.get("region"))
        resp = await asyncio.to_thread(
            client.retrieve_and_generate,
            input={"text": query},
            retrieveAndGenerateConfiguration={
                "type": "KNOWLEDGE_BASE",
                "knowledgeBaseConfiguration": {"knowledgeBaseId": kb_id, "modelArn": model_arn},
            },
        )
        return resp.get("output", {}).get("text", "")

    async def close(self) -> None:
        self._clients.clear()
        self._agent_clients.clear()
