"""Consent helper base — client-side PII tokenization before model invocation."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field


@dataclass
class TokenMap:
    """Maps tokens to original values for de-tokenization."""
    mappings: dict[str, str] = field(default_factory=dict)
    key_id: str = ""


class ConsentHelperBase(ABC):
    """Abstract consent helper for client-side processing.

    Pre-processes prompts (tokenize PII) before sending to model.
    Post-processes responses (de-tokenize) before returning to user.
    """

    @abstractmethod
    async def pre_process(self, text: str, tier: str) -> tuple[str, TokenMap]:
        """Tokenize PII in text based on consent tier. Returns (processed, map)."""
        ...

    @abstractmethod
    async def post_process(self, text: str, token_map: TokenMap) -> str:
        """De-tokenize response text using the token map."""
        ...
