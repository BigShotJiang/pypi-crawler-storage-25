"""Default consent helper — delegates to server-side consent engine."""

from ..consent_helper_base import ConsentHelperBase, TokenMap


class PassthroughConsentHelper(ConsentHelperBase):
    """No-op consent helper for STANDARD/FULL tiers. Passes text unchanged."""

    async def pre_process(self, text: str, tier: str) -> tuple[str, TokenMap]:
        return text, TokenMap()

    async def post_process(self, text: str, token_map: TokenMap) -> str:
        return text
