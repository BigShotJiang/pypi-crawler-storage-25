"""AIGP Client — Universal AI Governance Protocol client package.

Usage (original — still works):
    from aigp_client import AigpClient
    client = AigpClient(gov_url="...", app_id="...", hmac_secret="...", mode="REPORT")
    text = await client.invoke_text("model-id", "Hello", use_case="chat")

Usage (new — config-driven with providers):
    from aigp_client import ClientConfig
    config = ClientConfig(gov_url="...", app_id="...", hmac_secret="...", model={"provider": "bedrock", "region": "us-east-1"})
    components = config.build()
"""

__version__ = "2.0.0"

# Backward compat
from .client import AigpClient, GovernanceDecision

# Provider-based (new)
from .config import ClientConfig, ClientComponents
from .providers.model import ModelProviderBase
from .providers.transport import TransportProviderBase
from .providers.consent import ConsentHelperBase, TokenMap

__all__ = [
    "AigpClient", "GovernanceDecision",
    "ClientConfig", "ClientComponents",
    "ModelProviderBase", "TransportProviderBase",
    "ConsentHelperBase", "TokenMap",
]
