# onebot-protocol

OneBot 通信协议，定义消息收发的公共数据结构。基于`OneBot 11`标准，使用 Pydantic 提供类型安全的模型定义。

## 特性

- 完整的消息段（Message Segment）类型：文本、提及、图片、语音、视频、文件、位置、回复等
- 支持 discriminated union，根据 `type` 字段自动解析消息类型

## 支持的消息类型

| 类型 | 说明 |
|------|------|
| `text` | 纯文本 |
| `mention` | @某人 |
| `mention_all` | @所有人 |
| `image` | 图片 |
| `voice` | 语音 |
| `audio` | 音频 |
| `video` | 视频 |
| `file` | 文件 |
| `location` | 位置 |
| `reply` | 回复 |