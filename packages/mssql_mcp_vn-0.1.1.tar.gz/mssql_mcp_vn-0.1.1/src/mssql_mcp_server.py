#!/usr/bin/env python3
"""
MCP Server for MSSQL.

Provides tools to interact with MSSQL databases, including executing queries,
listing databases, listing tables, and describing table schema.
"""

import os
import json
from typing import Optional, List, Dict, Any
import aioodbc
from pydantic import BaseModel, Field, ConfigDict
from pydantic_settings import BaseSettings
from mcp.server.fastmcp import FastMCP

# Initialize the MCP server
mcp = FastMCP("mssql_mcp")

class Settings(BaseSettings):
    MSSQL_SERVER: str = Field(default="")
    MSSQL_USER: str = Field(default="")
    MSSQL_PASSWORD: str = Field(default="")
    MSSQL_PORT: int = Field(default=1433)
    MSSQL_DRIVER: str = Field(default="ODBC Driver 17 for SQL Server")
    
    model_config = ConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

settings = Settings()

def get_connection_string(database_name: str = "master") -> str:
    """Generate the connection string for a specific database."""
    if not settings.MSSQL_SERVER:
        raise ValueError("MSSQL_SERVER environment variable is not set")
        
    return (
        f"DRIVER={{{settings.MSSQL_DRIVER}}};"
        f"SERVER={settings.MSSQL_SERVER},{settings.MSSQL_PORT};"
        f"DATABASE={database_name};"
        f"UID={settings.MSSQL_USER};"
        f"PWD={settings.MSSQL_PASSWORD};"
        "TrustServerCertificate=yes;"
    )

class ExecuteQueryInput(BaseModel):
    """Input model for execute query operations."""
    model_config = ConfigDict(str_strip_whitespace=True)
    
    database_name: str = Field(..., description="Name of the target database")
    query: str = Field(..., description="SQL SELECT query to execute (read-only operations only)")
    limit: Optional[int] = Field(default=100, description="Maximum number of rows to return", ge=1, le=1000)

class ListTablesInput(BaseModel):
    """Input model for list tables operations."""
    model_config = ConfigDict(str_strip_whitespace=True)
    
    database_name: str = Field(..., description="Name of the target database")
    schema_name: Optional[str] = Field(default="dbo", description="Schema name to filter tables")

class DescribeTableInput(BaseModel):
    """Input model for describe table operations."""
    model_config = ConfigDict(str_strip_whitespace=True)
    
    database_name: str = Field(..., description="Name of the target database")
    table_name: str = Field(..., description="Name of the table to describe")
    schema_name: Optional[str] = Field(default="dbo", description="Schema name")

@mcp.tool(
    name="mssql_list_databases",
    annotations={
        "title": "List Databases", 
        "readOnlyHint": True, 
        "destructiveHint": False,
        "idempotentHint": True
    }
)
async def mssql_list_databases() -> str:
    """Get a list of all online databases available on the SQL Server.
            
    Returns:
        str: JSON-formatted response with the list of databases.
    """
    query = "SELECT name, state_desc FROM sys.databases WHERE state_desc = 'ONLINE' ORDER BY name"
    try:
        async with aioodbc.connect(dsn=get_connection_string("master")) as conn:
            async with conn.cursor() as cur:
                await cur.execute(query)
                rows = await cur.fetchall()
                
                databases = [row[0] for row in rows]
                return json.dumps({"count": len(databases), "databases": databases}, indent=2)
    except Exception as e:
        return f"Error listing databases: {str(e)}"

@mcp.tool(
    name="mssql_execute_query",
    annotations={
        "title": "Execute Read-Only Query", 
        "readOnlyHint": True, 
        "destructiveHint": False,
        "idempotentHint": True
    }
)
async def mssql_execute_query(params: ExecuteQueryInput) -> str:
    """Execute a read-only SELECT query against the database.
    
    Args:
        params (ExecuteQueryInput): Validated input parameters.
            
    Returns:
        str: JSON-formatted response with query results.
    """
    if not params.query.strip().upper().startswith(("SELECT", "WITH", "EXEC", "SHOW")):
        return "Error: Only read-only operations (SELECT, WITH, etc.) are allowed for safety."
        
    try:
        async with aioodbc.connect(dsn=get_connection_string(params.database_name)) as conn:
            async with conn.cursor() as cur:
                # Basic safety check
                if any(kw in params.query.upper() for kw in ["DROP ", "DELETE ", "UPDATE ", "INSERT ", "ALTER ", "TRUNCATE "]):
                    return "Error: Detected potentially destructive keywords in query."
                    
                await cur.execute(params.query)
                
                # Fetch headers
                columns = [column[0] for column in cur.description] if cur.description else []
                
                if not columns:
                    return json.dumps({"message": "Query executed successfully, no data returned."})
                
                # Fetch rows
                rows = await cur.fetchmany(params.limit)
                
                result = []
                for row in rows:
                    result.append(dict(zip(columns, [str(val) if val is not None else None for val in row])))
                    
                return json.dumps({"count": len(result), "columns": columns, "data": result}, indent=2)
    except Exception as e:
        return f"Error executing query: {str(e)}"

@mcp.tool(
    name="mssql_list_tables",
    annotations={
        "title": "List Tables", 
        "readOnlyHint": True, 
        "destructiveHint": False,
        "idempotentHint": True
    }
)
async def mssql_list_tables(params: ListTablesInput) -> str:
    """List all tables in the specified database and schema.
    
    Args:
        params (ListTablesInput): Validated input parameters.
            
    Returns:
        str: JSON-formatted response listing tables.
    """
    query = """
    SELECT TABLE_SCHEMA, TABLE_NAME, TABLE_TYPE
    FROM INFORMATION_SCHEMA.TABLES
    WHERE TABLE_SCHEMA = ?
    ORDER BY TABLE_NAME
    """
    try:
        async with aioodbc.connect(dsn=get_connection_string(params.database_name)) as conn:
            async with conn.cursor() as cur:
                await cur.execute(query, (params.schema_name,))
                rows = await cur.fetchall()
                
                result = []
                for row in rows:
                    result.append({
                        "schema": row[0],
                        "name": row[1],
                        "type": row[2]
                    })
                    
                return json.dumps({"tables": result}, indent=2)
    except Exception as e:
        return f"Error listing tables: {str(e)}"

@mcp.tool(
    name="mssql_describe_table",
    annotations={
        "title": "Describe Table", 
        "readOnlyHint": True, 
        "destructiveHint": False,
        "idempotentHint": True
    }
)
async def mssql_describe_table(params: DescribeTableInput) -> str:
    """Get detailed schema information for a specific table.
    
    Args:
        params (DescribeTableInput): Validated input parameters.
            
    Returns:
        str: JSON-formatted response with column metadata.
    """
    query = """
    SELECT 
        c.COLUMN_NAME, 
        c.DATA_TYPE, 
        c.CHARACTER_MAXIMUM_LENGTH, 
        c.IS_NULLABLE,
        c.COLUMN_DEFAULT
    FROM INFORMATION_SCHEMA.COLUMNS c
    WHERE c.TABLE_SCHEMA = ? AND c.TABLE_NAME = ?
    ORDER BY c.ORDINAL_POSITION
    """
    try:
        async with aioodbc.connect(dsn=get_connection_string(params.database_name)) as conn:
            async with conn.cursor() as cur:
                await cur.execute(query, (params.schema_name, params.table_name))
                rows = await cur.fetchall()
                
                if not rows:
                    return f"Error: Table '{params.schema_name}.{params.table_name}' not found or has no columns in database '{params.database_name}'."
                
                columns = []
                for row in rows:
                    columns.append({
                        "name": row[0],
                        "type": row[1],
                        "max_length": row[2],
                        "is_nullable": row[3],
                        "default": row[4]
                    })
                    
                return json.dumps({
                    "database": params.database_name,
                    "table": f"{params.schema_name}.{params.table_name}",
                    "columns": columns
                }, indent=2)
    except Exception as e:
        return f"Error describing table: {str(e)}"

def main():
    transport = os.environ.get("MCP_TRANSPORT", "stdio")
    port = int(os.environ.get("MCP_PORT", "8003"))
    if transport == "streamable_http":
        mcp.run(transport="streamable_http", port=port)
    else:
        mcp.run()

if __name__ == "__main__":
    main()
