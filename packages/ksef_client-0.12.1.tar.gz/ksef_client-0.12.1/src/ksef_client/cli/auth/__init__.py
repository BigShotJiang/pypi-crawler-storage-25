"""Authentication helpers for CLI."""
