"""Configuration utilities for CLI."""
