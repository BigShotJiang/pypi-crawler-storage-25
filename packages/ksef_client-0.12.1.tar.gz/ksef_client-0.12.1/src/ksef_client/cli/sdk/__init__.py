"""SDK adapters for CLI."""
