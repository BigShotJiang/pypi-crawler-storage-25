import base64
import unittest
from datetime import date
from unittest.mock import patch

from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec, padding, utils

from ksef_client.config import KsefClientOptions, KsefEnvironment
from ksef_client.services.verification_link import (
    VerificationLinkService,
    _decode_base64_or_url,
    _sign_path,
)
from ksef_client.utils.base64url import b64url_decode
from tests.helpers import generate_ec_cert, generate_ed25519_key_pem, generate_rsa_cert


class VerificationLinkTests(unittest.TestCase):
    ENCRYPTED_KEY_PASSWORD = "secret-password"

    def _extract_signed_path(self, url: str) -> tuple[bytes, bytes]:
        path_without_scheme = url.replace("https://", "").replace("http://", "")
        path_to_sign, signature_segment = path_without_scheme.rsplit("/", 1)
        return path_to_sign.encode("utf-8"), b64url_decode(signature_segment)

    def test_decode_base64_or_url(self):
        payload = b"data"
        b64 = base64.b64encode(payload).decode("ascii")
        b64url = base64.urlsafe_b64encode(payload).rstrip(b"=").decode("ascii")
        self.assertEqual(_decode_base64_or_url(b64), payload)
        self.assertEqual(_decode_base64_or_url(b64url), payload)
        with patch("ksef_client.services.verification_link.b64decode", side_effect=ValueError):
            self.assertEqual(_decode_base64_or_url(b64url), payload)

    def test_invoice_verification_url(self):
        options = KsefClientOptions(base_url=KsefEnvironment.TEST.value)
        service = VerificationLinkService(options)
        url = service.build_invoice_verification_url("123", "01-01-2024", "YQ==")
        self.assertIn("/invoice/123/01-01-2024/", url)
        url_date = service.build_invoice_verification_url("123", date(2024, 1, 1), "YQ==")
        self.assertIn("/invoice/123/01-01-2024/", url_date)

    def test_certificate_verification_url_rsa(self):
        options = KsefClientOptions(base_url=KsefEnvironment.TEST.value)
        service = VerificationLinkService(options)
        rsa_cert = generate_rsa_cert()
        url = service.build_certificate_verification_url(
            seller_nip="123",
            context_identifier_type="nip",
            context_identifier_value="123",
            certificate_serial="1",
            invoice_hash="YQ==",
            signing_certificate_pem=rsa_cert.certificate_pem,
            private_key_pem=rsa_cert.private_key_pem,
            signature_format="p1363",
        )
        self.assertIn("/certificate/", url)
        path_to_sign, signature = self._extract_signed_path(url)
        rsa_cert.private_key.public_key().verify(
            signature,
            path_to_sign,
            padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=32),
            hashes.SHA256(),
        )

    def test_certificate_verification_url_rsa_accepts_password_as_str(self):
        options = KsefClientOptions(base_url=KsefEnvironment.TEST.value)
        service = VerificationLinkService(options)
        rsa_cert = generate_rsa_cert(private_key_password=self.ENCRYPTED_KEY_PASSWORD)
        url = service.build_certificate_verification_url(
            seller_nip="123",
            context_identifier_type="nip",
            context_identifier_value="123",
            certificate_serial="1",
            invoice_hash="YQ==",
            signing_certificate_pem=rsa_cert.certificate_pem,
            private_key_pem=rsa_cert.private_key_pem,
            private_key_password=self.ENCRYPTED_KEY_PASSWORD,
            signature_format="p1363",
        )
        self.assertIn("/certificate/", url)
        path_to_sign, signature = self._extract_signed_path(url)
        rsa_cert.private_key.public_key().verify(
            signature,
            path_to_sign,
            padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=32),
            hashes.SHA256(),
        )

    def test_certificate_verification_url_rsa_accepts_password_as_bytes(self):
        options = KsefClientOptions(base_url=KsefEnvironment.TEST.value)
        service = VerificationLinkService(options)
        rsa_cert = generate_rsa_cert(private_key_password=self.ENCRYPTED_KEY_PASSWORD)
        url = service.build_certificate_verification_url(
            seller_nip="123",
            context_identifier_type="nip",
            context_identifier_value="123",
            certificate_serial="1",
            invoice_hash="YQ==",
            signing_certificate_pem=rsa_cert.certificate_pem,
            private_key_pem=rsa_cert.private_key_pem,
            private_key_password=self.ENCRYPTED_KEY_PASSWORD.encode("utf-8"),
            signature_format="p1363",
        )
        self.assertIn("/certificate/", url)
        path_to_sign, signature = self._extract_signed_path(url)
        rsa_cert.private_key.public_key().verify(
            signature,
            path_to_sign,
            padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=32),
            hashes.SHA256(),
        )

    def test_sign_path_errors(self):
        with self.assertRaises(ValueError):
            _sign_path("path", None, None, "p1363")

        ed_key = generate_ed25519_key_pem()
        with self.assertRaises(ValueError):
            _sign_path("path", None, ed_key, "p1363")

        rsa_cert = generate_rsa_cert()
        with self.assertRaises(ValueError):
            _sign_path("path", rsa_cert.certificate_pem, ed_key, "p1363")

    def test_sign_path_error_for_encrypted_key_without_password(self):
        rsa_cert = generate_rsa_cert(private_key_password=self.ENCRYPTED_KEY_PASSWORD)
        with self.assertRaisesRegex(ValueError, "provide `private_key_password`"):
            _sign_path("path", None, rsa_cert.private_key_pem, "p1363")

    def test_sign_path_error_for_encrypted_key_with_wrong_password(self):
        rsa_cert = generate_rsa_cert(private_key_password=self.ENCRYPTED_KEY_PASSWORD)
        with self.assertRaisesRegex(ValueError, "`private_key_password` is incorrect"):
            _sign_path(
                "path",
                None,
                rsa_cert.private_key_pem,
                "p1363",
                private_key_password="wrong-password",
            )

    def test_sign_path_error_when_password_is_given_for_unencrypted_key(self):
        rsa_cert = generate_rsa_cert()
        with self.assertRaisesRegex(ValueError, "Omit `private_key_password`"):
            _sign_path(
                "path",
                None,
                rsa_cert.private_key_pem,
                "p1363",
                private_key_password="unused-password",
            )

    def test_sign_path_error_for_invalid_private_key_format(self):
        with self.assertRaisesRegex(
            ValueError, "Unsupported private key format, encryption, or type"
        ):
            _sign_path("path", None, "not-a-private-key", "p1363")

    def test_sign_path_error_for_unknown_type_error_from_private_key_loader(self):
        with patch(
            "ksef_client.services.verification_link.load_private_key",
            side_effect=TypeError("unexpected private key loader failure"),
        ), self.assertRaisesRegex(ValueError, "Invalid private key password configuration"):
            _sign_path("path", None, "ignored-private-key", "p1363")

    def test_sign_path_ec_der_signature_is_verifiable(self):
        ec_cert = generate_ec_cert()
        signature = _sign_path("path", None, ec_cert.private_key_pem, "der")
        ec_cert.private_key.public_key().verify(signature, b"path", ec.ECDSA(hashes.SHA256()))

    def test_certificate_verification_url_ec_default_p1363_signature_is_verifiable(self):
        options = KsefClientOptions(base_url=KsefEnvironment.TEST.value)
        service = VerificationLinkService(options)
        ec_cert = generate_ec_cert()
        url = service.build_certificate_verification_url(
            seller_nip="123",
            context_identifier_type="nip",
            context_identifier_value="123",
            certificate_serial="1",
            invoice_hash="YQ==",
            signing_certificate_pem=ec_cert.certificate_pem,
            private_key_pem=ec_cert.private_key_pem,
        )

        path_to_sign, signature = self._extract_signed_path(url)
        size = ec_cert.private_key.key_size // 8
        self.assertEqual(len(signature), size * 2)
        r = int.from_bytes(signature[:size], "big")
        s = int.from_bytes(signature[size:], "big")
        signature_der = utils.encode_dss_signature(r, s)
        ec_cert.private_key.public_key().verify(
            signature_der,
            path_to_sign,
            ec.ECDSA(hashes.SHA256()),
        )


if __name__ == "__main__":
    unittest.main()
