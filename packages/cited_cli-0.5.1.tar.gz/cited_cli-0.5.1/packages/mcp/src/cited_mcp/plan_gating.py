"""Per-plan tool gating for the Cited MCP server.

Defines which tools are available at each subscription tier and provides
helpers to filter the tool list and return upgrade messages.

Plan tiers (from backend SubscriptionTierEnum):
  - free      (legacy, deprecated)
  - growth    (entry tier)
  - scale     (mid tier)
  - pro       (top tier)
  - enterprise (legacy, deprecated — treated as pro)
"""
from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger("cited_mcp.plan_gating")

# ---------------------------------------------------------------------------
# Tool tier mapping
# ---------------------------------------------------------------------------
# Tools not listed here are available to ALL tiers (including free/growth).

# Tools restricted to scale+ tier
_SCALE_TOOLS: set[str] = {
    "create_business",
    "update_business",
    "delete_business",
    "create_audit_template",
    "update_audit_template",
    "delete_audit_template",
    "start_solution",
    "start_solutions_batch",
    "get_solution_status",
    "get_solution_result",
    "list_solutions",
    "get_audit_question_detail",
    "export_audit",
    "cancel_job",
    "get_action_plan",
    "get_quick_wins",
    "mark_action_done",
    "dismiss_action",
    "get_action_progress",
    "set_profile_competitors",
    "create_persona",
    "update_persona",
    "delete_persona",
    "create_product",
    "update_product",
    "delete_product",
    "create_buyer_intent",
    "update_buyer_intent",
    "delete_buyer_intent",
    "recompute_health_scores",
    "refresh_business_overview",
}

# Tools restricted to pro+ tier
_PRO_TOOLS: set[str] = {
    "get_usage_stats",
    "get_business_facts",
    "get_business_claims",
    "get_competitive_comparison",
    "get_semantic_health",
    "buyer_fit_query",
    "get_business_hq",
    "get_agent_brief",
    "get_analytics_trends",
    "get_analytics_dashboard",
    "compare_audits",
}

# Tier hierarchy (higher index = more access)
_TIER_RANK: dict[str, int] = {
    "free": 0,
    "growth": 1,
    "scale": 2,
    "pro": 3,
    "enterprise": 3,  # legacy — same as pro
}

# Minimum tier required for each gated tool
_TOOL_MIN_TIER: dict[str, str] = {}
for _tool in _SCALE_TOOLS:
    _TOOL_MIN_TIER[_tool] = "scale"
for _tool in _PRO_TOOLS:
    _TOOL_MIN_TIER[_tool] = "pro"


def get_tier_rank(tier: str | None) -> int:
    """Return the numeric rank for a tier name."""
    if not tier:
        return 0
    return _TIER_RANK.get(tier.lower(), 0)


def is_tool_allowed(tool_name: str, user_tier: str | None) -> bool:
    """Check if a tool is available for the given subscription tier."""
    min_tier = _TOOL_MIN_TIER.get(tool_name)
    if min_tier is None:
        return True  # Tool is available to all tiers
    return get_tier_rank(user_tier) >= get_tier_rank(min_tier)


def required_tier_for_tool(tool_name: str) -> str | None:
    """Return the minimum tier required for a tool, or None if unrestricted."""
    return _TOOL_MIN_TIER.get(tool_name)


_PLAN_PRICING: dict[str, int] = {
    "free": 0,
    "growth": 39,
    "scale": 99,
    "pro": 299,
}


def upgrade_message(tool_name: str, current_tier: str | None) -> dict[str, Any]:
    """Return a structured error message for a gated tool.

    Includes both the user's current price and the required tier's price so
    agents can present an unambiguous upgrade ask without guessing the tier
    hierarchy. ``upgrade_direction`` is always ``"tier-up"`` here — the
    function is only called when the user's tier is below the tool's
    minimum.
    """
    min_tier = _TOOL_MIN_TIER.get(tool_name, "growth")
    upgrade_price = _PLAN_PRICING.get(min_tier)
    current = (current_tier or "free").lower()
    current_price = _PLAN_PRICING.get(current, 0)
    return {
        "error": True,
        "payment_required": True,
        "message": (
            f"The '{tool_name}' tool requires the {min_tier.title()} plan "
            f"(${upgrade_price}/mo) — upgrade from your current "
            f"{current.title()} plan (${current_price}/mo)."
        ),
        "upgrade_url": "https://app.youcited.com/settings/billing",
        "hint": (
            f"Call upgrade_plan(target_tier='{min_tier}') to upgrade, "
            f"or visit https://app.youcited.com/settings/billing"
        ),
        "upgrade_tier": min_tier,
        "upgrade_price_usd": upgrade_price,
        "upgrade_direction": "tier-up",
        "required_tier": min_tier,
        "current_tier": current,
        "current_price_usd": current_price,
    }


# ---------------------------------------------------------------------------
# Tools available per tier (for documentation / tool list filtering)
# ---------------------------------------------------------------------------

# All base tools (available to every tier including free/growth)
_BASE_TOOLS: set[str] = {
    "ping",
    "check_auth_status",
    "login",
    "logout",
    "get_pricing",
    "upgrade_plan",
    "whats_new",
    "list_businesses",
    "get_business",
    "crawl_business",
    "get_health_scores",
    "list_profile_competitors",
    "list_personas",
    "list_products",
    "list_buyer_intents",
    "list_audit_templates",
    "get_audit_template",
    "start_audit",
    "get_audit_status",
    "get_audit_result",
    "list_audits",
    "start_recommendation",
    "get_recommendation_status",
    "get_recommendation_result",
    "get_recommendation_insights",
    "get_recommendation_insight_detail",
    "list_recommendations",
    "get_recommendation_check_status",
    "validate_recommendation",
    "get_recommendation_validation_latest",
    "get_job_status",
}

# Verify all registered tools are accounted for in the tier sets.
# This is checked by the drift detection test in test_plan_gating.py.


def tools_for_tier(tier: str | None) -> set[str]:
    """Return the set of tool names available for a given tier."""
    rank = get_tier_rank(tier)
    tools = set(_BASE_TOOLS)
    if rank >= get_tier_rank("scale"):
        tools |= _SCALE_TOOLS
    if rank >= get_tier_rank("pro"):
        tools |= _PRO_TOOLS
    return tools


def tools_unlocked_between(old_tier: str | None, new_tier: str | None) -> set[str]:
    """Return tool names available at new_tier that weren't available at old_tier.

    Used by `upgrade_plan` to populate the `tools_unlocked` field in its
    response. When old_tier == new_tier (or new_tier is lower), returns an
    empty set.
    """
    if get_tier_rank(new_tier) <= get_tier_rank(old_tier):
        return set()
    return tools_for_tier(new_tier) - tools_for_tier(old_tier)
