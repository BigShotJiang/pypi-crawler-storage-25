from __future__ import annotations

import logging
import os
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

import jwt
from mcp.server.auth.middleware.auth_context import get_access_token
from mcp.server.auth.provider import construct_redirect_uri
from mcp.server.auth.settings import AuthSettings, ClientRegistrationOptions, RevocationOptions
from mcp.server.fastmcp import FastMCP
from mcp.server.transport_security import TransportSecuritySettings
from starlette.requests import Request
from starlette.responses import JSONResponse, RedirectResponse, Response
from starlette.types import ASGIApp, Message, Receive, Scope, Send

from cited_core.api.client import CitedClient
from cited_mcp.auth_provider import CitedAccessToken, CitedOAuthProvider
from cited_mcp.context import CitedContext

logger = logging.getLogger(__name__)


class _PatchRegistrationMiddleware:
    """ASGI middleware that patches and validates OAuth client registrations.

    1. Adds "refresh_token" to grant_types (MCP SDK v1.27 requires both
       authorization_code and refresh_token, but Custom Connectors only send one).
    2. Validates redirect_uris against the allowlist — rejects registrations
       that would redirect tokens to untrusted domains.
    """

    def __init__(self, app: ASGIApp) -> None:
        self.app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http" or scope["path"] != "/register":
            await self.app(scope, receive, send)
            return

        import json as _json

        from cited_mcp.auth_provider import _ALLOWED_REDIRECT_PREFIXES

        body_parts: list[bytes] = []
        patched = False

        async def patching_receive() -> Message:
            nonlocal patched
            message = await receive()
            if message["type"] == "http.request" and not patched:
                raw = message.get("body", b"")
                body_parts.append(raw)
                if message.get("more_body", False):
                    return message
                full_body = b"".join(body_parts)
                try:
                    data = _json.loads(full_body)

                    # Validate redirect URIs against allowlist
                    for uri in data.get("redirect_uris", []):
                        if not any(
                            uri.startswith(prefix)
                            for prefix in _ALLOWED_REDIRECT_PREFIXES
                        ):
                            logger.warning(
                                "Registration rejected: disallowed redirect_uri %s",
                                uri,
                            )
                            # Return a 400 error directly
                            error_body = _json.dumps({
                                "error": "invalid_redirect_uri",
                                "error_description": (
                                    f"Redirect URI '{uri}' is not allowed. "
                                    "Only localhost and approved domains are accepted."
                                ),
                            }).encode()
                            await send({
                                "type": "http.response.start",
                                "status": 400,
                                "headers": [
                                    [b"content-type", b"application/json"],
                                ],
                            })
                            await send({
                                "type": "http.response.body",
                                "body": error_body,
                            })
                            # Don't forward to the app
                            patched = True
                            return {"type": "http.request", "body": b"", "more_body": False}

                    # Patch grant_types
                    grant_types = data.get("grant_types", [])
                    if "refresh_token" not in grant_types:
                        data["grant_types"] = list(grant_types) + ["refresh_token"]
                    full_body = _json.dumps(data).encode()
                except (ValueError, KeyError):
                    pass
                patched = True
                message = {**message, "body": full_body}
            return message

        await self.app(scope, patching_receive, send)


_OAUTH_EVENT_PATHS = frozenset(
    {"/register", "/authorize", "/token", "/revoke", "/oauth/callback"}
)


def _format_kv(value: object) -> str:
    """Format a value for the structured oauth-event log line.

    Quotes if the value contains spaces, equals signs, or quotes; renders
    None / empty as a bare empty pair so grep can still match the key.
    """
    if value is None or value == "":
        return '""'
    s = value if isinstance(value, str) else str(value)
    if any(c in s for c in ' "='):
        return '"' + s.replace('"', '\\"') + '"'
    return s


class _OAuthEventLogMiddleware:
    """ASGI middleware that emits structured ``[oauth-event]`` log lines for
    every request hitting an OAuth-protocol endpoint.

    Purpose: counting OAuth dances vs. background protocol probes. The
    standard uvicorn access log shows individual lines for /authorize,
    /token, etc., but they're interleaved with everything else and have no
    consistent prefix — hard to grep, hard to count. This middleware emits
    one extra line per OAuth-endpoint hit, prefixed ``[oauth-event]``, with
    the salient fields broken out:

      [oauth-event] event=oauth.authorize method=GET ip=10.0.0.187
                    ua="claude-desktop/1.x" redirect_uri="https://claude.ai/..."
                    scope=cited response_type=code status=302

    Tokens, full client_ids (themselves JWTs), and JWT states are NOT
    logged. We log presence (``has_token=true``) and short prefixes only.
    """

    def __init__(self, app: ASGIApp) -> None:
        self.app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http" or scope["path"] not in _OAUTH_EVENT_PATHS:
            await self.app(scope, receive, send)
            return

        path = scope["path"]
        method = scope["method"]
        client = scope.get("client") or ("?", 0)
        ip = client[0] if client else "?"

        headers = {k: v for k, v in scope.get("headers", [])}
        ua = headers.get(b"user-agent", b"").decode("latin-1", errors="replace")[:60]

        from urllib.parse import parse_qs

        query_string = scope.get("query_string", b"").decode("latin-1", errors="replace")
        params = parse_qs(query_string)

        def _first(name: str) -> str:
            return str(params.get(name, [""])[0])

        event_name = "oauth." + path.lstrip("/").replace("/", "_")
        fields: list[tuple[str, object]] = [
            ("event", event_name),
            ("method", method),
            ("ip", ip),
            ("ua", ua),
        ]

        if path == "/authorize":
            fields.extend([
                ("client_id_prefix", _first("client_id")[:12]),
                ("redirect_uri", _first("redirect_uri")),
                ("response_type", _first("response_type")),
                ("scope", _first("scope")),
                ("resource", _first("resource")),
            ])
        elif path == "/oauth/callback":
            fields.extend([
                ("has_token", "true" if _first("token") else "false"),
                ("has_state", "true" if _first("state") else "false"),
            ])

        captured_status: dict[str, int] = {"status": 0}

        async def status_capturing_send(message: Message) -> None:
            if message["type"] == "http.response.start":
                captured_status["status"] = int(message.get("status", 0))
            await send(message)

        try:
            await self.app(scope, receive, status_capturing_send)
        finally:
            fields.append(("status", captured_status["status"]))
            kv = " ".join(f"{k}={_format_kv(v)}" for k, v in fields)
            logger.info("[oauth-event] %s", kv)


class _RequestContextMiddleware:
    """ASGI middleware that captures the request's source IP and User-Agent
    into contextvars consumed by the tool-call decorator.

    Why: ``tool_call`` log lines previously carried no source-identifying
    metadata beyond the (possibly absent) decoded user JWT. When a probe
    came in with a non-standard token — logged as user=``unknown`` — there
    was no way to trace the source. Threading an HTTP request object
    through every tool function is invasive; contextvars stay scoped to
    the request's async task without touching tool signatures.

    For stdio transport this middleware is not in the chain, so the
    contextvars stay None and the log fields render as null.

    We prefer the leftmost value of ``X-Forwarded-For`` when present
    because the ALB inserts the original client IP there and the immediate
    ``scope["client"]`` is the ALB's internal address. Trusting X-F-F is
    only safe behind a known proxy — which is the deploy topology here.
    """

    def __init__(self, app: ASGIApp) -> None:
        self.app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        from cited_mcp.tools._helpers import _request_ip, _request_ua

        headers = {k: v for k, v in scope.get("headers", [])}
        xff = headers.get(b"x-forwarded-for", b"").decode("latin-1", errors="replace")
        if xff:
            ip: str | None = xff.split(",")[0].strip() or None
        else:
            client = scope.get("client") or ("?", 0)
            ip = client[0] if client and client[0] != "?" else None

        ua_bytes = headers.get(b"user-agent", b"")
        ua = ua_bytes.decode("latin-1", errors="replace")[:120] if ua_bytes else None

        token_ip = _request_ip.set(ip)
        token_ua = _request_ua.set(ua)
        try:
            await self.app(scope, receive, send)
        finally:
            _request_ip.reset(token_ip)
            _request_ua.reset(token_ua)


@asynccontextmanager
async def cited_remote_lifespan(server: FastMCP) -> AsyncIterator[CitedContext]:
    """Lifespan for the remote MCP server.

    Unlike the stdio lifespan, the remote server doesn't have a pre-configured
    token. The per-user JWT comes from the OAuth access token at request time
    via get_access_token(). The lifespan provides a base context with no token.
    """
    api_url = os.environ.get("CITED_API_URL", "https://api.youcited.com")
    env = os.environ.get("CITED_ENV", "prod")

    client = CitedClient(base_url=api_url, token=None)
    try:
        yield CitedContext(client=client, env=env, api_url=api_url)
    finally:
        client.close()


def get_user_client(api_url: str) -> CitedClient | None:
    """Create a CitedClient using the authenticated user's JWT from OAuth context.

    Tools can call this to get a client authenticated as the current user.
    """
    access_token = get_access_token()
    if not access_token or not isinstance(access_token, CitedAccessToken):
        return None
    return CitedClient(base_url=api_url, token=access_token.user_jwt)


def create_remote_server() -> FastMCP:
    """Create and configure the remote MCP server with OAuth auth."""
    import cited_mcp.server as server_module

    backend_url = os.environ.get("CITED_API_URL", "https://api.youcited.com")
    mcp_url = os.environ.get("MCP_URL", "https://mcp.youcited.com")
    jwt_secret = os.environ["JWT_SECRET"]
    host = os.environ.get("HOST", "0.0.0.0")
    port = int(os.environ.get("PORT", "8080"))

    auth_provider = CitedOAuthProvider(
        backend_url=backend_url,
        mcp_url=mcp_url,
        jwt_secret=jwt_secret,
    )

    remote_mcp = FastMCP(
        "cited",
        instructions="Cited GEO platform — audit, optimize, and monitor AI search presence",
        host=host,
        port=port,
        stateless_http=True,
        transport_security=TransportSecuritySettings(
            allowed_origins=[
                "https://claude.ai",
                "https://api.anthropic.com",
                mcp_url,
            ],
            allowed_hosts=[
                "mcp.youcited.com",
                "mcpdev.youcited.com",
                "localhost",
                "127.0.0.1",
            ],
        ),
        lifespan=cited_remote_lifespan,
        auth_server_provider=auth_provider,
        auth=AuthSettings(
            issuer_url=mcp_url,  # type: ignore[arg-type]
            resource_server_url=mcp_url,  # type: ignore[arg-type]
            client_registration_options=ClientRegistrationOptions(
                enabled=True,
                valid_scopes=["cited"],
                default_scopes=["cited"],
            ),
            revocation_options=RevocationOptions(enabled=True),
        ),
    )

    # Set the module-level mcp instance so tool modules register on it
    server_module.mcp = remote_mcp

    # Register the OAuth callback route (handles redirect from backend)
    @remote_mcp.custom_route("/oauth/callback", methods=["GET"])  # type: ignore[untyped-decorator]
    async def oauth_callback(request: Request) -> Response:
        """Handle callback from the Cited backend after user authentication."""
        user_token = request.query_params.get("token")
        state_jwt = request.query_params.get("state")

        if not user_token or not state_jwt:
            return JSONResponse(
                {"error": "Missing token or state parameter"},
                status_code=400,
            )

        # Validate user_token is a well-formed, non-expired JWT from the backend.
        # We can't verify the signature (different secret), but we can reject
        # malformed tokens, expired tokens, and tokens missing required claims.
        try:
            user_claims = jwt.decode(
                user_token,
                options={"verify_signature": False, "verify_exp": True},
            )
            if "sub" not in user_claims or "email" not in user_claims:
                return JSONResponse(
                    {"error": "Invalid user token: missing required claims"},
                    status_code=400,
                )
        except jwt.ExpiredSignatureError:
            return JSONResponse(
                {"error": "User token has expired. Please log in again."},
                status_code=400,
            )
        except jwt.InvalidTokenError:
            return JSONResponse(
                {"error": "Invalid user token format."},
                status_code=400,
            )

        try:
            state = jwt.decode(state_jwt, jwt_secret, algorithms=["HS256"])
        except jwt.ExpiredSignatureError:
            return JSONResponse(
                {"error": "Authorization state expired. Please try again."},
                status_code=400,
            )
        except jwt.InvalidTokenError:
            return JSONResponse(
                {"error": "Invalid authorization state."},
                status_code=400,
            )

        # Generate a stateless auth code (signed JWT) so it survives
        # container restarts and deploy rollovers.
        code = auth_provider.store_auth_code(
            code="",  # ignored — store_auth_code generates a JWT
            user_jwt=user_token,
            client_id=state["client_id"],
            code_challenge=state["code_challenge"],
            redirect_uri=state["redirect_uri"],
            redirect_uri_provided_explicitly=state.get(
                "redirect_uri_provided_explicitly", True
            ),
            scopes=state.get("scopes", []),
            resource=state.get("resource"),
        )

        # Redirect to Claude Desktop's redirect URI with the auth code
        redirect_uri = construct_redirect_uri(
            state["redirect_uri"],
            code=code,
            state=state.get("original_state"),
        )
        return RedirectResponse(url=redirect_uri, status_code=302)

    @remote_mcp.custom_route("/health", methods=["GET"])  # type: ignore[untyped-decorator]
    async def health_check(request: Request) -> Response:
        return JSONResponse({"status": "ok"})

    @remote_mcp.custom_route("/robots.txt", methods=["GET"])  # type: ignore[untyped-decorator]
    async def robots_txt(request: Request) -> Response:
        return Response(
            content=(
                "User-agent: *\n"
                "Disallow: /oauth/\n"
                "Allow: /health\n"
                "Allow: /robots.txt\n"
            ),
            media_type="text/plain",
        )

    # Now import tools — they'll register on remote_mcp via server_module.mcp
    server_module.register_tools()
    # Replace FastMCP's default ToolManager with our subclass for structured
    # tool_unavailable responses (see cited_mcp.tool_manager). Must run AFTER
    # register_tools so the new manager inherits the registered tool set.
    from cited_mcp.tool_manager import install as _install_tool_manager
    _install_tool_manager(remote_mcp)
    server_module.cache_tool_surface(remote_mcp)

    return remote_mcp


def run_remote_server() -> None:
    """Start the remote MCP server with Streamable HTTP transport and OAuth."""
    import uvicorn

    if "JWT_SECRET" not in os.environ:
        raise SystemExit("JWT_SECRET environment variable is required")
    server = create_remote_server()

    # Wrap the Starlette app with the registration-patching middleware
    # so Custom Connectors that omit refresh_token in grant_types still work.
    # Keep streamable HTTP in SSE mode (the FastMCP default; do NOT enable
    # is_json_response). SSE-mode responses stream JSON-RPC messages over the
    # body so tool handlers can deliver notifications/tools/list_changed via
    # `await ctx.session.send_tool_list_changed()` even with stateless_http=True.
    starlette_app = server.streamable_http_app()
    # Order: oauth-event log on the OUTSIDE of the registration patcher so
    # patcher-rejected /register calls (400 invalid_redirect_uri) still
    # produce an event line. RequestContextMiddleware sits innermost so
    # its contextvars (ip, user_agent) are set in the same task that
    # dispatches the tool call.
    patched_app = _OAuthEventLogMiddleware(
        _PatchRegistrationMiddleware(
            _RequestContextMiddleware(starlette_app)
        )
    )

    config = uvicorn.Config(
        patched_app,
        host=server.settings.host,
        port=server.settings.port,
        log_level=server.settings.log_level.lower(),
    )
    uvicorn_server = uvicorn.Server(config)

    import anyio
    anyio.run(uvicorn_server.serve)


if __name__ == "__main__":
    run_remote_server()
