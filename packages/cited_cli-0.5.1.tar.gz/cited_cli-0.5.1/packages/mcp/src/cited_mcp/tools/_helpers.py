from __future__ import annotations

import contextlib
import contextvars
import functools
import hashlib
import json
import logging
import os
import time
import uuid
from collections import deque
from collections.abc import Awaitable, Callable
from typing import Any

import httpx
import jwt as pyjwt
from mcp.server.fastmcp import Context

from cited_core.api.client import CitedClient
from cited_core.errors import CitedAPIError
from cited_mcp.context import CitedContext

logger = logging.getLogger("cited_mcp.usage")

# ---------------------------------------------------------------------------
# Per-request forensic context (set by remote.py _RequestContextMiddleware).
#
# These let tool_call log lines carry the request's source IP and User-Agent
# without threading an HTTP request object through every tool function. For
# stdio transport (no HTTP) they remain None and are emitted as null in logs.
# ---------------------------------------------------------------------------
_request_ip: contextvars.ContextVar[str | None] = contextvars.ContextVar(
    "cited_mcp_request_ip", default=None
)
_request_ua: contextvars.ContextVar[str | None] = contextvars.ContextVar(
    "cited_mcp_request_ua", default=None
)

# ---------------------------------------------------------------------------
# Response size guardrails
# ---------------------------------------------------------------------------

_MAX_RESPONSE_BYTES = 50_000  # ~16k tokens, safe for all MCP hosts


def _truncate_response(data: Any, max_bytes: int = _MAX_RESPONSE_BYTES) -> Any:
    """Truncate a tool response if its JSON serialisation exceeds *max_bytes*.

    For dict responses: repeatedly halves the longest top-level list until the
    payload fits.  For list responses: slices the list to fit.  Adds metadata
    fields so the caller knows data was trimmed.
    """
    raw = json.dumps(data, default=str)
    if len(raw.encode()) <= max_bytes:
        return data

    if isinstance(data, list):
        total = len(data)
        while len(json.dumps(data, default=str).encode()) > max_bytes and len(data) > 1:
            data = data[: len(data) // 2]
        return {
            "data": data,
            "_truncated": True,
            "_total_count": total,
            "_hint": f"Showing {len(data)} of {total} items. Use limit/offset for pagination.",
        }

    if isinstance(data, dict):
        # Find list-valued fields and iteratively shrink the longest
        list_fields = {k: v for k, v in data.items() if isinstance(v, list) and len(v) > 0}
        truncated_fields: list[str] = []
        attempts = 0
        while (
            len(json.dumps(data, default=str).encode()) > max_bytes
            and list_fields
            and attempts < 20
        ):
            longest_key = max(list_fields, key=lambda k: len(list_fields[k]))
            original_len = len(list_fields[longest_key])
            new_len = max(1, original_len // 2)
            data[longest_key] = list_fields[longest_key][:new_len]
            list_fields[longest_key] = data[longest_key]
            if longest_key not in truncated_fields:
                truncated_fields.append(longest_key)
            if new_len <= 1:
                del list_fields[longest_key]
            attempts += 1
        if truncated_fields:
            data["_truncated"] = True
            data["_truncated_fields"] = truncated_fields
        return data

    return data


# ---------------------------------------------------------------------------
# Per-user rate limiting
# ---------------------------------------------------------------------------

_RATE_LIMIT = int(os.environ.get("CITED_RATE_LIMIT", "60"))
_RATE_WINDOW = 60  # seconds
_rate_limits: dict[str, deque[float]] = {}


def _check_rate_limit(user: str) -> dict[str, Any] | None:
    """Return an error dict if *user* has exceeded the rate limit, else None."""
    if _RATE_LIMIT <= 0:
        return None
    now = time.monotonic()
    window = _rate_limits.setdefault(user, deque())
    # Evict expired entries
    while window and now - window[0] >= _RATE_WINDOW:
        window.popleft()
    if len(window) >= _RATE_LIMIT:
        retry_after = int(_RATE_WINDOW - (now - window[0])) + 1
        return {
            "error": True,
            "message": "Rate limited. Please wait before making more requests.",
            "retry_after_seconds": retry_after,
        }
    window.append(now)
    return None


def _get_ctx(ctx: Context[Any, CitedContext, Any]) -> CitedContext:
    """Extract CitedContext from MCP lifespan context.

    For remote transport (OAuth), replaces the lifespan client with a per-request
    client that carries the authenticated user's JWT.
    Also checks for a pending login that may have completed in the background.
    """
    lc: CitedContext = ctx.request_context.lifespan_context

    # Check if a pending login flow completed (non-blocking)
    if not lc.client.token:
        try:
            from cited_mcp.tools.auth import _check_pending_login

            _check_pending_login(lc)
        except ImportError:
            pass

    # If lifespan client already has a token (stdio transport), return as-is
    if lc.client.token:
        return lc

    # Remote transport: try to get user JWT from OAuth access token
    try:
        from mcp.server.auth.middleware.auth_context import get_access_token

        from cited_mcp.auth_provider import CitedAccessToken

        access_token = get_access_token()
        if access_token and isinstance(access_token, CitedAccessToken):
            user_client = CitedClient(
                base_url=lc.api_url,
                token=access_token.user_jwt,
            )
            return CitedContext(
                client=user_client,
                env=lc.env,
                api_url=lc.api_url,
                default_business_id=lc.default_business_id,
            )
    except ImportError:
        pass

    return lc


def _auth_check(cited_ctx: CitedContext) -> dict[str, Any] | None:
    """Return error dict if not authenticated, else None."""
    if cited_ctx.client.token is None:
        return {
            "error": True,
            "message": "Not authenticated. Use the 'login' tool or set CITED_TOKEN env var.",
        }
    return None


def _resolve_business_id(cited_ctx: CitedContext, business_id: str | None) -> str | None:
    """Return *business_id* if provided, else the session default."""
    return business_id or cited_ctx.default_business_id


_ERROR_HINTS: list[tuple[int, str | None, str]] = [
    (
        403,
        "plan",
        "This account's plan may not allow this operation. "
        "Check plan limits with 'check_auth_status'. "
        "Consider upgrading at https://app.youcited.com/settings/billing, "
        "or use 'logout' then 'login' to switch to a different account.",
    ),
    (
        403,
        None,
        "This action is not allowed. Check your plan limits with 'check_auth_status', "
        "or use 'logout' then 'login' to switch accounts.",
    ),
    (
        422,
        None,
        "The request was rejected due to validation errors. "
        "Check that all fields meet requirements (e.g., website must be a real "
        "DNS-resolvable domain, description must be at least ~50 characters).",
    ),
    (
        401,
        None,
        "Authentication has expired or is invalid. "
        "Use 'login' with force=True to re-authenticate, "
        "or 'logout' then 'login' to switch accounts.",
    ),
    (
        429,
        None,
        "Rate limited. Wait a moment before retrying this request.",
    ),
]


def _resolve_token(
    ctx: Context[Any, CitedContext, Any],
) -> str | None:
    """Extract the user JWT from either stdio or remote transport."""
    lc: CitedContext = ctx.request_context.lifespan_context
    if lc.client.token:
        return lc.client.token
    try:
        from mcp.server.auth.middleware.auth_context import get_access_token

        from cited_mcp.auth_provider import CitedAccessToken

        access_token = get_access_token()
        if access_token and isinstance(access_token, CitedAccessToken):
            return access_token.user_jwt
    except ImportError:
        pass
    return None


def _rate_limit_key(token: str | None) -> str:
    """Derive a tamper-proof rate-limit key from the raw token."""
    if not token:
        return "anonymous"
    return hashlib.sha256(token.encode()).hexdigest()[:16]


def _extract_user(token: str | None) -> str:
    """Decode user email from a JWT without verifying signature (for logging only)."""
    if not token:
        return "anonymous"
    try:
        payload = pyjwt.decode(token, options={"verify_signature": False})
        return str(payload.get("email") or payload.get("sub") or "unknown")
    except Exception:
        return "unknown"


def _extract_client_id_from_oauth() -> str | None:
    """Return the OAuth client_id from the current access token, truncated.

    The MCP server's client_id is itself a signed JWT (RFC 7591 dynamic
    registration encoded into the id), so we truncate to a 12-char prefix
    sufficient to group connector traffic without bloating log lines.

    Returns None for stdio transport (no OAuth context), or whenever the
    access-token contextvar is unset.

    Note: this used to decode the user_jwt looking for client_id/aud/azp
    claims, but backend session JWTs do not carry OAuth-client identity —
    so the field was always empty in production logs. This implementation
    reads from the OAuth access token instead.
    """
    try:
        from mcp.server.auth.middleware.auth_context import get_access_token
    except ImportError:
        return None
    try:
        access_token = get_access_token()
    except Exception:
        return None
    if not access_token:
        return None
    cid = getattr(access_token, "client_id", None)
    if not cid:
        return None
    return str(cid)[:12]


def _extract_auth_kind(
    ctx: Context[Any, CitedContext, Any], token: str | None
) -> str:
    """Categorize the auth path for forensic logging.

    Returns one of:
      - ``anonymous`` — no token, no agent key
      - ``agent_key`` — CitedClient has agent_api_key set (stdio mode)
      - ``oauth_email`` — OAuth flow, user_jwt has email claim
      - ``oauth_no_email`` — OAuth flow, user_jwt decoded but no email
      - ``oauth_malformed`` — OAuth flow, user_jwt couldn't be decoded
      - ``stdio_email`` — stdio mode, token is a JWT with email claim
      - ``stdio_no_email`` — stdio mode, token decoded but no email
      - ``stdio_malformed`` — stdio mode, token isn't a parseable JWT

    Lets us tell apart the practical cases — including the case where
    ``_extract_user`` returns ``"unknown"`` because the token was not a
    JWT at all versus because the JWT had no email/sub claim. Without
    this, the ``<unknown>`` bucket in usage reports is unactionable.
    """
    try:
        lc = ctx.request_context.lifespan_context
        if getattr(lc.client, "agent_api_key", None):
            return "agent_key"
    except Exception:
        pass

    method = "stdio"
    try:
        from mcp.server.auth.middleware.auth_context import get_access_token

        if get_access_token() is not None:
            method = "oauth"
    except Exception:
        pass

    if not token:
        return "anonymous" if method == "stdio" else "oauth_no_token"

    try:
        payload = pyjwt.decode(token, options={"verify_signature": False})
    except Exception:
        return f"{method}_malformed"

    if payload.get("email"):
        return f"{method}_email"
    return f"{method}_no_email"


# ---------------------------------------------------------------------------
# Build identity — stamped into every tool_call line for log correlation.
# Computed once at module import: cheap, deterministic, survives the request.
# ---------------------------------------------------------------------------

_BUILD_IDENTITY: dict[str, str] = {}


def _get_build_identity() -> dict[str, str]:
    """Return cached server_version, tools_fingerprint, deployment_id.

    Lazy + memoised because compute_tools_fingerprint walks the live server's
    tool registry — fine to do once but expensive per request.
    """
    if _BUILD_IDENTITY:
        return _BUILD_IDENTITY
    try:
        from cited_mcp import __version__ as ver
        from cited_mcp.server import compute_tools_fingerprint
        from cited_mcp.server import mcp as live_mcp

        _BUILD_IDENTITY["server_version"] = ver
        _BUILD_IDENTITY["tools_fingerprint"] = compute_tools_fingerprint(live_mcp)
    except Exception:
        # Don't crash logging if the import fails — emit blanks instead.
        _BUILD_IDENTITY["server_version"] = "unknown"
        _BUILD_IDENTITY["tools_fingerprint"] = "unknown"
    _BUILD_IDENTITY["deployment_id"] = os.environ.get("CITED_DEPLOYMENT_ID", "local")
    return _BUILD_IDENTITY


# ---------------------------------------------------------------------------
# Resource ID extraction for tool_call logs.
#
# We log obvious-shaped IDs (business_id, audit_id, job_id, source_id, etc.)
# so customer-support and abuse-investigation flows can correlate user
# activity with platform records. We deliberately do NOT log free-text
# content (audit descriptions, buyer profiles, etc.) — those can contain
# sensitive material.
# ---------------------------------------------------------------------------

# Tool kwargs that name a resource we want to log. Match against suffixes:
# *_id and *_type are the conventions across the surface.
_RESOURCE_KEYS = {
    "business_id",
    "audit_id",
    "baseline_id",
    "job_id",
    "recommendation_job_id",
    "audit_job_id",
    "named_audit_id",
    "template_id",
    "solution_id",
    "recommendation_id",
    "source_id",
    "source_type",
    "action_id",
    "check_id",
    "question_id",
}

# Maximum length of a logged ID value — avoids the case where a tool author
# accidentally maps a long string into one of these key names.
_MAX_RESOURCE_VALUE_LEN = 80


def _extract_resource_ids(kwargs: dict[str, Any]) -> dict[str, str]:
    """Pull ID-shaped kwargs into a flat dict, redacting anything else."""
    out: dict[str, str] = {}
    for key, val in kwargs.items():
        if key not in _RESOURCE_KEYS:
            continue
        if val is None:
            continue
        s = str(val)
        if len(s) > _MAX_RESOURCE_VALUE_LEN:
            continue
        out[key] = s
    return out


# ---------------------------------------------------------------------------
# Per-user tier cache (avoids /auth/me call on every tool invocation)
# ---------------------------------------------------------------------------

_TIER_CACHE_TTL = 300  # 5 minutes
_tier_cache: dict[str, tuple[str, float]] = {}  # rl_key -> (tier, expires_at)


def _get_user_tier(cited_ctx: CitedContext, cache_key: str) -> str | None:
    """Return the user's subscription tier, using a short-lived cache.

    Falls back to None (treated as free) if the API call fails.
    """
    now = time.monotonic()
    cached = _tier_cache.get(cache_key)
    if cached and now < cached[1]:
        return cached[0]

    try:
        user = cited_ctx.client.get("/auth/me")
        tier = str(user.get("subscription_tier") or "free")
        _tier_cache[cache_key] = (tier, now + _TIER_CACHE_TTL)
        return tier
    except Exception:
        # If /auth/me fails, use cached value (even if stale) or default to None
        if cached:
            return cached[0]
        return None


def log_tool_call(
    func: Callable[..., Awaitable[Any]],
) -> Callable[..., Awaitable[Any]]:
    """Decorator: rate-limits, logs, and catches transport errors per tool call."""

    @functools.wraps(func)
    async def wrapper(
        ctx: Context[Any, CitedContext, Any],
        *args: Any,
        **kwargs: Any,
    ) -> Any:
        tool_name = func.__name__
        token = _resolve_token(ctx)
        rl_key = _rate_limit_key(token)
        user = _extract_user(token)
        auth_kind = _extract_auth_kind(ctx, token)
        client_id = _extract_client_id_from_oauth()
        request_id = uuid.uuid4().hex[:12]
        start = time.monotonic()
        build = _get_build_identity()
        resources = _extract_resource_ids(kwargs)
        # Header-propagation context — set inside the try block below so that
        # _get_ctx failures still flow through structured error handling.
        cited_ctx_for_header: CitedContext | None = None

        def _log(event: str, **extra: Any) -> None:
            payload: dict[str, Any] = {
                "event": event,
                "request_id": request_id,
                "tool": tool_name,
                "user": user,
                "auth_kind": auth_kind,
                "client_id": client_id,
                "ip": _request_ip.get(),
                "user_agent": _request_ua.get(),
                "server_version": build["server_version"],
                "tools_fingerprint": build["tools_fingerprint"],
                "deployment_id": build["deployment_id"],
            }
            if resources:
                payload["resources"] = resources
            payload.update(extra)
            # CodeQL flags this as clear-text logging of sensitive data because
            # `user` is sourced from a JWT email claim. This is by design —
            # operator usage reports (scripts/mcp_usage_report.py) attribute
            # tool calls to users by email, which is necessary for forensics
            # and abuse investigation. Logs flow to a private CloudWatch group
            # with restricted IAM access. Email is not transmitted anywhere
            # else from this line. If we later move to hashed identifiers,
            # the suppression can be removed.
            logger.info(json.dumps(payload, default=str))  # noqa: E501 lgtm[py/clear-text-logging-sensitive-data]

        # Rate limit check
        if rl_err := _check_rate_limit(rl_key):
            _log("rate_limited")
            rl_err["_request_id"] = request_id
            return rl_err

        try:
            # Propagate request_id to the cited backend for end-to-end traces.
            cited_ctx_for_header = _get_ctx(ctx)
            cited_ctx_for_header.client.set_request_id(request_id)

            # Plan gating check (skip for auth tools — must always be accessible)
            from cited_mcp.plan_gating import is_tool_allowed, upgrade_message

            _AUTH_TOOLS = {
                "ping",
                "check_auth_status",
                "login",
                "logout",
                "get_pricing",
                "upgrade_plan",
            }
            if tool_name not in _AUTH_TOOLS and token:
                cited_ctx = _get_ctx(ctx)
                if cited_ctx.client.token:
                    user_tier = _get_user_tier(cited_ctx, rl_key)
                    if not is_tool_allowed(tool_name, user_tier):
                        gate_err = upgrade_message(tool_name, user_tier)
                        gate_err["_request_id"] = request_id
                        _log(
                            "plan_gated",
                            current_tier=user_tier,
                            required_tier=gate_err["required_tier"],
                        )
                        return gate_err

            result = await func(ctx, *args, **kwargs)
            duration_ms = int((time.monotonic() - start) * 1000)
            is_error = isinstance(result, dict) and result.get("error") is True
            extra: dict[str, Any] = {
                "duration_ms": duration_ms,
                "success": not is_error,
            }
            if is_error and isinstance(result, dict):
                # Pull through the typed error fields the tools already emit
                # so failures are categorisable in the dashboard without
                # re-grepping raw error messages.
                if et := result.get("error_type"):
                    extra["error_type"] = et
                if sc := result.get("status_code"):
                    extra["status_code"] = sc
                if pr := result.get("payment_required"):
                    extra["payment_required"] = pr
            _log("tool_call", **extra)
            # Inject request_id into response
            if isinstance(result, dict):
                result["_request_id"] = request_id
            elif isinstance(result, list):
                result = {
                    "data": result,
                    "_request_id": request_id,
                }
            return result

        except httpx.TimeoutException:
            duration_ms = int((time.monotonic() - start) * 1000)
            _log("tool_call", duration_ms=duration_ms, success=False, error_type="timeout")
            return {
                "error": True,
                "error_type": "upstream_timeout",
                "message": (
                    "The request timed out. The Cited API may be "
                    "temporarily slow — please try again in a moment."
                ),
                "retriable": True,
                "_request_id": request_id,
            }

        except httpx.ConnectError:
            duration_ms = int((time.monotonic() - start) * 1000)
            _log("tool_call", duration_ms=duration_ms, success=False, error_type="connection_error")
            return {
                "error": True,
                "error_type": "connection_error",
                "message": (
                    "Could not connect to the Cited API. "
                    "The service may be temporarily unavailable."
                ),
                "retriable": True,
                "_request_id": request_id,
            }

        except Exception as exc:
            duration_ms = int((time.monotonic() - start) * 1000)
            _log(
                "tool_call",
                duration_ms=duration_ms,
                success=False,
                error_type=type(exc).__name__,
            )
            return {
                "error": True,
                "error_type": type(exc).__name__,
                "message": (
                    "An unexpected error occurred. This is usually transient — please retry."
                ),
                "retriable": True,
                "_request_id": request_id,
            }
        finally:
            # Clear the request_id header so the next caller's tool_call
            # doesn't accidentally inherit this one's correlation id.
            if cited_ctx_for_header is not None:
                with contextlib.suppress(Exception):
                    cited_ctx_for_header.client.set_request_id(None)

    return wrapper


def _api_error_response(e: CitedAPIError) -> dict[str, Any]:
    """Convert CitedAPIError to a structured error dict with actionable hints."""
    response: dict[str, Any] = {
        "error": True,
        "status_code": e.status_code,
        "message": e.message,
    }

    for code, substring, hint in _ERROR_HINTS:
        if e.status_code == code and (
            substring is None or (e.message and substring.lower() in e.message.lower())
        ):
            response["hint"] = hint
            break

    return response
