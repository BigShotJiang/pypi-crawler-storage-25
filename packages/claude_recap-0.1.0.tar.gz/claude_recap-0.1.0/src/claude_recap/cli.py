"""CLI interface for Claude Recap."""

from __future__ import annotations

import sys
from datetime import date
from pathlib import Path
from typing import Optional

import click
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from claude_recap import __version__
from claude_recap.analyzer import ConversationAnalyzer
from claude_recap.parser import ClaudeHistoryParser
from claude_recap.reporter import Period, Purpose

console = Console()


def _load_sessions(claude_dir: Optional[str] = None, max_sessions: int = 0):
    try:
        parser = ClaudeHistoryParser(Path(claude_dir) if claude_dir else None)
    except FileNotFoundError as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)

    with console.status("[bold]Scanning conversations..."):
        sessions = parser.parse_all_sessions(max_sessions=max_sessions)

    if not sessions:
        console.print("[yellow]No conversation sessions found.[/yellow]")
        sys.exit(0)

    return sessions


@click.group(invoke_without_command=True)
@click.option("--version", is_flag=True, help="Show version.")
@click.pass_context
def main(ctx, version):
    """Claude Recap — Recapture what you built with Claude."""
    if version:
        console.print(f"claude-recap v{__version__}")
        return
    if ctx.invoked_subcommand is None:
        ctx.invoke(stats)


@main.command()
@click.option("--dir", "claude_dir", default=None, help="Path to Claude data directory.")
def stats(claude_dir):
    """Show a quick overview of your Claude usage."""
    sessions = _load_sessions(claude_dir)
    analyzer = ConversationAnalyzer(sessions)
    s = analyzer.overall_stats()

    console.print()
    console.print(Panel.fit(
        f"[bold]Claude Recap[/bold] v{__version__}",
        subtitle=f"{s.first_date} \u2192 {s.last_date}" if s.first_date else "",
    ))

    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column(style="bold")
    table.add_column(style="cyan", justify="right")
    table.add_row("Sessions", str(s.total_sessions))
    table.add_row("Messages", str(s.total_messages))
    table.add_row("Active Days", str(s.active_days))
    table.add_row("Projects", str(s.total_projects))
    console.print(table)
    console.print()

    if s.projects:
        console.print("[bold]Top Projects[/bold]")
        for proj, count in s.projects.most_common(8):
            bar = "\u2588" * min(count * 2, 30)
            console.print(f"  {proj:<30} [cyan]{bar}[/cyan] {count}")
        console.print()

    if s.tools_used:
        console.print("[bold]Top Tools[/bold]")
        for tool, count in s.tools_used.most_common(10):
            console.print(f"  [dim]{tool:<20}[/dim] {count}x")
        console.print()

    console.print("[dim]Try: claude-recap serve  \u2502  claude-recap report --period weekly[/dim]")


@main.command()
@click.option("--period", "-p", type=click.Choice(["daily", "weekly", "monthly", "yearly"]), default="weekly")
@click.option("--purpose", type=click.Choice(["general", "academic", "job_search", "work_report"]), default="general")
@click.option("--format", "-f", "fmt", type=click.Choice(["html", "markdown", "json"]), default="html")
@click.option("--output", "-o", "output_path", default=None, help="Output file path.")
@click.option("--from", "from_date", default=None, help="Start date (YYYY-MM-DD).")
@click.option("--to", "to_date", default=None, help="End date (YYYY-MM-DD).")
@click.option("--dir", "claude_dir", default=None, help="Path to Claude data directory.")
@click.option("--open", "open_browser", is_flag=True, help="Open HTML in browser.")
@click.option("--ai", "use_ai", is_flag=True, help="Use Claude API for AI-powered summaries.")
def report(period, purpose, fmt, output_path, from_date, to_date, claude_dir, open_browser, use_ai):
    """Generate a report of your Claude conversations."""
    from claude_recap.reporter import generate_report_data, render_html_report, render_markdown_report, render_json_report

    sessions = _load_sessions(claude_dir)
    analyzer = ConversationAnalyzer(sessions)

    start = date.fromisoformat(from_date) if from_date else None
    end = date.fromisoformat(to_date) if to_date else None
    if start or end:
        analyzer = analyzer.filter_by_date_range(start, end)

    # AI summarization
    ai_summary = None
    period_summaries = None
    if use_ai:
        from claude_recap.summarizer import Summarizer
        summarizer = Summarizer()
        if not summarizer.available:
            console.print("[yellow]AI summary requires:[/yellow] pip install claude-recap[ai] and ANTHROPIC_API_KEY")
            console.print("[dim]Falling back to standard report...[/dim]")
        else:
            with console.status("[bold]Generating AI summary..."):
                ai_summary = summarizer.summarize_overall(analyzer.sessions, purpose=purpose)

    with console.status("[bold]Generating report..."):
        data = generate_report_data(
            analyzer, Period(period), Purpose(purpose),
            ai_summary=ai_summary,
            period_summaries_with_ai=period_summaries,
        )

        if fmt == "html":
            content = render_html_report(data)
        elif fmt == "markdown":
            content = render_markdown_report(data)
        else:
            content = render_json_report(data)

    if output_path:
        out = Path(output_path)
    elif fmt == "html":
        out = Path(f"claude-recap-{period}-{date.today().isoformat()}.html")
    else:
        click.echo(content)
        return

    out.write_text(content, encoding="utf-8")
    console.print(f"[green]Report saved:[/green] {out.absolute()}")

    if open_browser and fmt == "html":
        import webbrowser
        webbrowser.open(f"file://{out.absolute()}")


@main.command()
@click.option("--port", "-p", default=6275, help="Port number.")
@click.option("--dir", "claude_dir", default=None, help="Path to Claude data directory.")
@click.option("--no-open", is_flag=True, help="Don't open browser.")
def serve(port, claude_dir, no_open):
    """Start a local dashboard server."""
    from claude_recap.server import start_server

    sessions = _load_sessions(claude_dir)
    server, url = start_server(sessions, port=port, open_browser=not no_open)

    console.print()
    console.print(Panel.fit(
        f"[bold green]Dashboard running at[/bold green] [link={url}]{url}[/link]",
        subtitle="Press Ctrl+C to stop",
    ))

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        console.print("\n[dim]Server stopped.[/dim]")
        server.shutdown()


@main.command()
@click.option("--dir", "claude_dir", default=None, help="Path to Claude data directory.")
@click.option("--output", "-o", "output_path", default=None, help="Output file path.")
@click.option("--no-open", is_flag=True, help="Don't open browser.")
def dashboard(claude_dir, output_path, no_open):
    """Generate a static dashboard HTML file."""
    from claude_recap.server import build_static_dashboard

    sessions = _load_sessions(claude_dir)

    with console.status("[bold]Building dashboard..."):
        html = build_static_dashboard(sessions)

    out = Path(output_path) if output_path else Path(f"claude-recap-dashboard-{date.today().isoformat()}.html")
    out.write_text(html, encoding="utf-8")
    console.print(f"[green]Dashboard saved:[/green] {out.absolute()}")

    if not no_open:
        import webbrowser
        webbrowser.open(f"file://{out.absolute()}")


@main.command()
@click.option("--period", "-p", type=click.Choice(["daily", "weekly", "monthly"]), default="weekly")
@click.option("--dir", "claude_dir", default=None, help="Path to Claude data directory.")
@click.option("--output-dir", "-o", default="./reports", help="Directory for reports.")
def schedule(period, claude_dir, output_dir):
    """Show instructions for scheduling automatic reports."""
    import platform

    out = Path(output_dir).absolute()
    cmd = f"claude-recap report --period {period} --format html --output {out}/claude-recap-$(date +%Y-%m-%d).html"
    if claude_dir:
        cmd += f" --dir {claude_dir}"

    console.print()
    console.print(Panel.fit("[bold]Schedule Automatic Reports[/bold]"))
    console.print()

    if platform.system() in ("Darwin", "Linux"):
        cron_map = {"daily": "0 9 * * *", "weekly": "0 9 * * 1", "monthly": "0 9 1 * *"}
        label_map = {"daily": "daily at 9:00 AM", "weekly": "every Monday at 9:00 AM", "monthly": "1st of each month at 9:00 AM"}
        console.print(f"  # Run {label_map[period]}")
        console.print(f"  [cyan]crontab -e[/cyan]")
        console.print(f"  [green]{cron_map[period]} {cmd}[/green]")
    else:
        console.print(f"  [cyan]schtasks /create /tn \"ClaudeRecap\" /tr \"{cmd}\" /sc {period.upper()} /st 09:00[/cyan]")

    console.print()
    console.print(f"[dim]Reports saved to: {out}[/dim]")
