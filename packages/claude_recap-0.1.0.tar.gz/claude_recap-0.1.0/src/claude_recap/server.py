"""Local HTTP server for the Claude Recap dashboard."""

from __future__ import annotations

import json
import webbrowser
from http.server import HTTPServer, SimpleHTTPRequestHandler
from typing import Optional
from urllib.parse import parse_qs, urlparse

from claude_recap.analyzer import ConversationAnalyzer
from claude_recap.parser import Session
from claude_recap.reporter import Purpose, Period, generate_report_data, render_html_report, TEMPLATE_DIR


def _session_to_dict(s: Session) -> dict:
    tools = set()
    for m in s.messages:
        tools.update(m.tools_used)
    return {
        "session_id": s.session_id,
        "project": s.project,
        "project_display": s.project_display,
        "summary": s.summary,
        "start_time": s.start_time.isoformat() if s.start_time else None,
        "end_time": s.end_time.isoformat() if s.end_time else None,
        "message_count": len(s.messages),
        "tools": sorted(tools),
    }


def _build_dashboard_data(sessions: list[Session], serve_mode: bool = True) -> dict:
    analyzer = ConversationAnalyzer(sessions)
    stats = analyzer.overall_stats()
    return {
        "_serve_mode": serve_mode,
        "stats": {
            "total_sessions": stats.total_sessions,
            "total_messages": stats.total_messages,
            "user_messages": stats.user_messages,
            "assistant_messages": stats.assistant_messages,
            "active_days": stats.active_days,
            "total_projects": stats.total_projects,
            "first_date": stats.first_date.isoformat() if stats.first_date else None,
            "last_date": stats.last_date.isoformat() if stats.last_date else None,
            "daily_activity": stats.daily_activity,
            "projects": dict(stats.projects.most_common(50)),
            "tools_used": dict(stats.tools_used.most_common(50)),
        },
        "sessions": [_session_to_dict(s) for s in sessions],
    }


def build_static_dashboard(sessions: list[Session]) -> str:
    data = _build_dashboard_data(sessions, serve_mode=False)
    template = (TEMPLATE_DIR / "dashboard.html").read_text(encoding="utf-8")
    return template.replace("__DASHBOARD_DATA__", json.dumps(data, ensure_ascii=False))


class DashboardHandler(SimpleHTTPRequestHandler):
    sessions: list[Session] = []
    _cache: Optional[str] = None

    def log_message(self, format, *args):
        pass

    def do_GET(self):
        parsed = urlparse(self.path)
        routes = {
            "/": self._serve_dashboard,
            "": self._serve_dashboard,
            "/api/stats": self._serve_stats,
            "/api/sessions": self._serve_sessions,
            "/api/export": lambda: self._serve_export(parsed.query),
            "/api/summarize": lambda: self._serve_ai_summary(parsed.query),
        }
        handler = routes.get(parsed.path)
        if handler:
            handler()
        else:
            self.send_error(404)

    def _serve_dashboard(self):
        if DashboardHandler._cache is None:
            data = _build_dashboard_data(DashboardHandler.sessions)
            template = (TEMPLATE_DIR / "dashboard.html").read_text(encoding="utf-8")
            DashboardHandler._cache = template.replace(
                "__DASHBOARD_DATA__", json.dumps(data, ensure_ascii=False)
            )
        self._send_html(DashboardHandler._cache)

    def _serve_stats(self):
        analyzer = ConversationAnalyzer(DashboardHandler.sessions)
        stats = analyzer.overall_stats()
        self._send_json({"total_sessions": stats.total_sessions, "total_messages": stats.total_messages})

    def _serve_sessions(self):
        self._send_json([_session_to_dict(s) for s in DashboardHandler.sessions])

    def _serve_export(self, qs: str):
        params = parse_qs(qs)
        period = params.get("period", ["weekly"])[0]
        purpose = params.get("purpose", ["general"])[0]
        analyzer = ConversationAnalyzer(DashboardHandler.sessions)
        data = generate_report_data(analyzer, Period(period), Purpose(purpose))
        self._send_html(render_html_report(data))

    def _serve_ai_summary(self, qs: str):
        params = parse_qs(qs)
        purpose = params.get("purpose", ["general"])[0]
        try:
            from claude_recap.summarizer import Summarizer
            s = Summarizer()
            if not s.available:
                self._send_json({"error": "ANTHROPIC_API_KEY not set or anthropic not installed"})
                return
            summary = s.summarize_overall(DashboardHandler.sessions, purpose=purpose)
            self._send_json({"summary": summary})
        except Exception as e:
            self._send_json({"error": str(e)})

    def _send_html(self, html: str):
        content = html.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(content)))
        self.end_headers()
        self.wfile.write(content)

    def _send_json(self, obj):
        content = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(content)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(content)


def start_server(sessions: list[Session], port: int = 6275, open_browser: bool = True):
    DashboardHandler.sessions = sessions
    DashboardHandler._cache = None
    server = HTTPServer(("127.0.0.1", port), DashboardHandler)
    url = f"http://127.0.0.1:{port}"
    if open_browser:
        webbrowser.open(url)
    return server, url
