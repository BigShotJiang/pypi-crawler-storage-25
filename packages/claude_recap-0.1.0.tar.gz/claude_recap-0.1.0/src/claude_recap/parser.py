"""Parse Claude Code conversation data from ~/.claude/ directory."""

from __future__ import annotations

import json
import os
import platform
import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional


@dataclass
class Message:
    role: str
    content: str
    timestamp: Optional[datetime] = None
    tools_used: list[str] = field(default_factory=list)


@dataclass
class Session:
    session_id: str
    project: str
    project_display: str
    messages: list[Message] = field(default_factory=list)
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
    summary: str = ""


@dataclass
class HistoryEntry:
    display: str
    timestamp: datetime
    project: str
    session_id: str


_TAG_RE = re.compile(r"<[^>]+>")


def find_claude_dir() -> Path:
    """Locate the Claude data directory across platforms."""
    env_dir = os.environ.get("CLAUDE_HISTORY_DIR")
    if env_dir:
        p = Path(env_dir)
        if p.exists():
            return p

    home = Path.home()
    candidates = [home / ".claude"]

    if platform.system() == "Windows":
        for var in ("LOCALAPPDATA", "APPDATA"):
            val = os.environ.get(var, "")
            if val:
                candidates.insert(0, Path(val) / "claude")

    for c in candidates:
        if c.exists():
            return c

    raise FileNotFoundError(
        "Could not find Claude data directory. "
        "Set CLAUDE_HISTORY_DIR environment variable to specify the path."
    )


def _ts_to_dt(ts_ms: int | float) -> datetime:
    return datetime.fromtimestamp(ts_ms / 1000, tz=timezone.utc)


def _project_display_name(project_path: str) -> str:
    name = project_path.replace("-", "/").strip("/")
    parts = [p for p in name.split("/") if p and p.lower() not in ("users", "home")]
    if len(parts) >= 2:
        return "/".join(parts[-2:])
    return parts[-1] if parts else project_path


def _extract_text(content) -> str:
    if isinstance(content, str):
        return content.strip()
    if isinstance(content, list):
        texts = []
        for block in content:
            if isinstance(block, dict) and block.get("type") == "text":
                texts.append(block.get("text", ""))
            elif isinstance(block, str):
                texts.append(block)
        return "\n".join(texts).strip()
    return ""


def _extract_tools(content) -> list[str]:
    if not isinstance(content, list):
        return []
    return [b["name"] for b in content if isinstance(b, dict) and b.get("type") == "tool_use" and b.get("name")]


class ClaudeHistoryParser:
    def __init__(self, claude_dir: Optional[Path] = None):
        self.claude_dir = claude_dir or find_claude_dir()
        self.projects_dir = self.claude_dir / "projects"

    def parse_history(self) -> list[HistoryEntry]:
        history_file = self.claude_dir / "history.jsonl"
        if not history_file.exists():
            return []
        entries = []
        for line in history_file.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                data = json.loads(line)
                entries.append(HistoryEntry(
                    display=data.get("display", ""),
                    timestamp=_ts_to_dt(data["timestamp"]),
                    project=data.get("project", ""),
                    session_id=data.get("sessionId", ""),
                ))
            except (json.JSONDecodeError, KeyError):
                continue
        return entries

    def _find_session_files(self) -> list[tuple[str, Path]]:
        if not self.projects_dir.exists():
            return []
        results = []
        for project_dir in self.projects_dir.iterdir():
            if not project_dir.is_dir() or project_dir.name.startswith("."):
                continue
            for f in project_dir.iterdir():
                if f.suffix == ".jsonl" and f.is_file():
                    results.append((project_dir.name, f))
        return results

    def parse_session(self, project_name: str, session_path: Path) -> Optional[Session]:
        session = Session(
            session_id=session_path.stem,
            project=project_name,
            project_display=_project_display_name(project_name),
        )
        try:
            text = session_path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            return None

        first_user_msg = None
        for line in text.splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                data = json.loads(line)
            except json.JSONDecodeError:
                continue

            if data.get("type") == "file-history-snapshot" or data.get("isMeta"):
                continue
            message_data = data.get("message")
            if not message_data:
                continue
            role = message_data.get("role", "")
            if role not in ("user", "assistant"):
                continue

            text_content = _TAG_RE.sub("", _extract_text(message_data.get("content", ""))).strip()
            tools = _extract_tools(message_data.get("content", ""))

            if not text_content and not tools:
                continue

            timestamp = None
            ts_val = data.get("timestamp")
            if ts_val:
                try:
                    timestamp = _ts_to_dt(ts_val) if isinstance(ts_val, (int, float)) else datetime.fromisoformat(ts_val.replace("Z", "+00:00"))
                except (ValueError, TypeError, OSError):
                    pass

            session.messages.append(Message(role=role, content=text_content, timestamp=timestamp, tools_used=tools))
            if role == "user" and first_user_msg is None and text_content:
                first_user_msg = text_content

        if not session.messages:
            return None
        session.summary = (first_user_msg or "")[:200]
        timestamps = [m.timestamp for m in session.messages if m.timestamp]
        if timestamps:
            session.start_time = min(timestamps)
            session.end_time = max(timestamps)
        return session

    def parse_all_sessions(self, max_sessions: int = 0) -> list[Session]:
        files = self._find_session_files()
        files.sort(key=lambda x: x[1].stat().st_mtime, reverse=True)
        if max_sessions > 0:
            files = files[:max_sessions]
        sessions = [s for pn, p in files if (s := self.parse_session(pn, p))]
        sessions.sort(key=lambda s: s.start_time or datetime.min.replace(tzinfo=timezone.utc))
        return sessions
