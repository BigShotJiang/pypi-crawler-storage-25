"""AI-powered summarization using the Claude API.

Requires: pip install claude-recap[ai]
Uses ANTHROPIC_API_KEY from environment.
"""

from __future__ import annotations

import json
import os
from typing import Optional

from claude_recap.parser import Session

PURPOSE_PROMPTS = {
    "general": (
        "Provide a clear, concise summary of the user's AI-assisted development activities. "
        "Highlight key accomplishments, projects worked on, and notable patterns."
    ),
    "academic": (
        "Summarize from an academic/research perspective. Focus on research activities, "
        "experiments conducted, methods explored, datasets used, and scientific progress. "
        "Use formal but accessible language suitable for a research log or progress report."
    ),
    "job_search": (
        "Summarize to highlight professional skills and achievements. Focus on technologies used, "
        "complex problems solved, tools mastered, and quantifiable output. "
        "Frame as accomplishments suitable for a resume or interview discussion."
    ),
    "work_report": (
        "Summarize as a work progress report. Focus on deliverables completed, projects advanced, "
        "bugs fixed, features implemented, and productivity metrics. "
        "Use clear, professional language suitable for a manager or stakeholder update."
    ),
}


def _condense_sessions(sessions: list[Session]) -> list[dict]:
    """Condense sessions into a compact format for the API prompt."""
    condensed = []
    for s in sessions:
        tools = set()
        user_topics = []
        for m in s.messages:
            tools.update(m.tools_used)
            if m.role == "user" and m.content:
                user_topics.append(m.content[:150])

        condensed.append({
            "project": s.project_display,
            "date": s.start_time.strftime("%Y-%m-%d") if s.start_time else "unknown",
            "messages": len(s.messages),
            "tools": sorted(tools)[:10],
            "topics": user_topics[:5],
        })
    return condensed


class Summarizer:
    """Generate AI-powered summaries using the Claude API."""

    def __init__(self, api_key: Optional[str] = None, model: str = "claude-sonnet-4-20250514"):
        self.api_key = api_key or os.environ.get("ANTHROPIC_API_KEY")
        self.model = model
        self._client = None

    @property
    def available(self) -> bool:
        if not self.api_key:
            return False
        try:
            import anthropic  # noqa: F401
            return True
        except ImportError:
            return False

    def _get_client(self):
        if self._client is None:
            import anthropic
            self._client = anthropic.Anthropic(api_key=self.api_key)
        return self._client

    def summarize_sessions(
        self,
        sessions: list[Session],
        period_label: str = "",
        purpose: str = "general",
    ) -> Optional[str]:
        """Generate an AI summary for a set of sessions.

        Returns None if API is unavailable or fails.
        """
        if not self.available or not sessions:
            return None

        condensed = _condense_sessions(sessions)
        purpose_instruction = PURPOSE_PROMPTS.get(purpose, PURPOSE_PROMPTS["general"])

        prompt = (
            f"Analyze these AI-assisted development sessions"
            f"{f' from {period_label}' if period_label else ''} "
            f"and write a summary.\n\n"
            f"Goal: {purpose_instruction}\n\n"
            f"Sessions:\n{json.dumps(condensed, indent=2, ensure_ascii=False)}\n\n"
            f"Write a concise summary (3-5 short paragraphs, no markdown headers). "
            f"Use specific details. Match the language of the session topics "
            f"(Chinese topics → Chinese summary, English → English)."
        )

        try:
            client = self._get_client()
            response = client.messages.create(
                model=self.model,
                max_tokens=1024,
                messages=[{"role": "user", "content": prompt}],
            )
            return response.content[0].text
        except Exception:
            return None

    def summarize_overall(
        self,
        sessions: list[Session],
        purpose: str = "general",
    ) -> Optional[str]:
        """Generate an overall AI summary across all sessions."""
        return self.summarize_sessions(sessions, "the entire period", purpose)
