from __future__ import annotations

from typer.testing import CliRunner

from projectmem.cli import app


def test_init_creates_projectmem_files(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    runner = CliRunner()

    result = runner.invoke(app, ["init"], catch_exceptions=False)

    assert result.exit_code == 0
    assert (tmp_path / ".projectmem").is_dir()
    assert (tmp_path / ".projectmem" / "summary.md").is_file()
    assert (tmp_path / ".projectmem" / "events.jsonl").is_file()
    assert (tmp_path / ".projectmem" / "issues").is_dir()
    assert (tmp_path / ".projectmem" / "config.toml").is_file()
    assert ".projectmem/events.jsonl" in (tmp_path / ".gitignore").read_text(
        encoding="utf-8"
    )
