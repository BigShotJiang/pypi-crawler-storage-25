from __future__ import annotations

from typer.testing import CliRunner

from projectmem.cli import app


def test_summary_and_issue_file_are_regenerated(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    runner = CliRunner()

    runner.invoke(app, ["init"], catch_exceptions=False)
    runner.invoke(app, ["log", "login redirect loop"], catch_exceptions=False)
    runner.invoke(
        app,
        ["attempt", "changed redirect in auth/redirect.py:88", "--worked"],
        catch_exceptions=False,
    )
    runner.invoke(
        app,
        ["fix", "fixed redirect guard in auth/redirect.py:88"],
        catch_exceptions=False,
    )
    runner.invoke(
        app,
        ["decision", "Keep redirect handling in one middleware"],
        catch_exceptions=False,
    )

    summary = (tmp_path / ".projectmem" / "summary.md").read_text(encoding="utf-8")
    issue_files = list((tmp_path / ".projectmem" / "issues").glob("0001-*.md"))

    assert "# projectmem" in summary
    assert "[DONE] #0001 login redirect loop" in summary
    assert "fixed redirect guard in auth/redirect.py:88" in summary
    assert "Keep redirect handling in one middleware" in summary
    assert "`auth/redirect.py:88`" in summary
    assert len(issue_files) == 1
    assert "login redirect loop" in issue_files[0].read_text(encoding="utf-8")
