from __future__ import annotations

import json

from typer.testing import CliRunner

from projectmem.cli import app


def test_log_attempt_and_fix_write_events(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    runner = CliRunner()

    runner.invoke(app, ["init"], catch_exceptions=False)
    runner.invoke(app, ["log", "auth tokens expire too early"], catch_exceptions=False)
    runner.invoke(
        app,
        ["attempt", "changed JWT_EXPIRY in config.py", "--failed"],
        catch_exceptions=False,
    )
    runner.invoke(
        app,
        ["fix", "changed TOKEN_TTL in auth/middleware.py:42"],
        catch_exceptions=False,
    )

    lines = (tmp_path / ".projectmem" / "events.jsonl").read_text(
        encoding="utf-8"
    ).splitlines()
    events = [json.loads(line) for line in lines]

    assert [event["type"] for event in events] == ["issue", "attempt", "fix"]
    assert all(event["issue_id"] == "0001" for event in events)
    assert events[1]["outcome"] == "failed"


def test_attempt_without_open_issue_fails(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    runner = CliRunner()
    runner.invoke(app, ["init"], catch_exceptions=False)

    result = runner.invoke(app, ["attempt", "try something"])

    assert result.exit_code == 1
    assert result.exception is not None
    assert "No open issue found" in str(result.exception)
