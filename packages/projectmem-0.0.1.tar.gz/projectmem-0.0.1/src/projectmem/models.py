from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Any
from uuid import uuid4


VALID_EVENT_TYPES = {
    "issue",
    "hypothesis",
    "attempt",
    "fix",
    "decision",
    "note",
}

VALID_OUTCOMES = {"worked", "failed", "partial"}


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace(
        "+00:00", "Z"
    )


@dataclass
class Event:
    type: str
    summary: str
    id: str = field(default_factory=lambda: f"evt_{uuid4().hex[:20]}")
    timestamp: str = field(default_factory=utc_now_iso)
    issue_id: str | None = None
    outcome: str | None = None
    files: list[str] = field(default_factory=list)
    command: str | None = None
    notes: str | None = None
    git_commit: str | None = None

    def __post_init__(self) -> None:
        if self.type not in VALID_EVENT_TYPES:
            raise ValueError(f"Unsupported event type: {self.type}")
        if self.outcome is not None and self.outcome not in VALID_OUTCOMES:
            raise ValueError(f"Unsupported outcome: {self.outcome}")
        self.summary = self.summary.strip()
        if not self.summary:
            raise ValueError("Event summary cannot be empty")

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        return {key: value for key, value in data.items() if value not in (None, [])}

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Event":
        return cls(
            id=data.get("id") or f"evt_{uuid4().hex[:20]}",
            timestamp=data.get("timestamp") or utc_now_iso(),
            type=data["type"],
            issue_id=data.get("issue_id"),
            summary=data["summary"],
            outcome=data.get("outcome"),
            files=list(data.get("files") or []),
            command=data.get("command"),
            notes=data.get("notes"),
            git_commit=data.get("git_commit"),
        )
