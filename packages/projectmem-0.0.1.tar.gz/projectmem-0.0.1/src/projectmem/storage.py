from __future__ import annotations

import json
import subprocess
from pathlib import Path

from projectmem.models import Event

MEM_DIR = ".projectmem"
SUMMARY_FILE = "summary.md"
EVENTS_FILE = "events.jsonl"
CONFIG_FILE = "config.toml"
ISSUES_DIR = "issues"


class ProjectMemError(RuntimeError):
    pass


def mem_path(root: Path | None = None) -> Path:
    return (root or Path.cwd()) / MEM_DIR


def require_mem_dir(root: Path | None = None) -> Path:
    path = mem_path(root)
    if not path.exists():
        raise ProjectMemError("No .projectmem directory found. Run `projectmem init`.")
    return path


def events_path(root: Path | None = None) -> Path:
    return require_mem_dir(root) / EVENTS_FILE


def summary_path(root: Path | None = None) -> Path:
    return require_mem_dir(root) / SUMMARY_FILE


def issues_dir(root: Path | None = None) -> Path:
    return require_mem_dir(root) / ISSUES_DIR


def initialize(root: Path | None = None) -> Path:
    root_path = root or Path.cwd()
    project_dir = mem_path(root_path)
    project_dir.mkdir(exist_ok=True)
    (project_dir / ISSUES_DIR).mkdir(exist_ok=True)
    (project_dir / EVENTS_FILE).touch(exist_ok=True)

    config = project_dir / CONFIG_FILE
    if not config.exists():
        config.write_text(
            'summary_size_limit_kb = 20\nrecent_days = 30\nproject_description = ""\n',
            encoding="utf-8",
        )

    summary = project_dir / SUMMARY_FILE
    if not summary.exists():
        summary.write_text(
            "# projectmem\n\n"
            "_Last updated: never_\n\n"
            "## What this project is\n"
            "Not described yet.\n",
            encoding="utf-8",
        )

    ensure_gitignore_entry(root_path)
    return project_dir


def ensure_gitignore_entry(root: Path) -> None:
    gitignore = root / ".gitignore"
    entry = f"{MEM_DIR}/{EVENTS_FILE}"
    if gitignore.exists():
        lines = gitignore.read_text(encoding="utf-8").splitlines()
        if entry in lines:
            return
        prefix = "" if not lines or lines[-1] == "" else "\n"
        gitignore.write_text(
            gitignore.read_text(encoding="utf-8") + f"{prefix}{entry}\n",
            encoding="utf-8",
        )
    else:
        gitignore.write_text(f"{entry}\n", encoding="utf-8")


def read_events(root: Path | None = None) -> list[Event]:
    path = events_path(root)
    events: list[Event] = []
    for line_number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        try:
            events.append(Event.from_dict(json.loads(line)))
        except (json.JSONDecodeError, KeyError, ValueError) as exc:
            raise ProjectMemError(f"Invalid event at {path}:{line_number}: {exc}") from exc
    return events


def append_event(event: Event, root: Path | None = None) -> Event:
    path = events_path(root)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(event.to_dict(), sort_keys=True) + "\n")
    return event


def next_issue_id(events: list[Event]) -> str:
    issue_ids = [
        int(event.issue_id)
        for event in events
        if event.type == "issue" and event.issue_id and event.issue_id.isdigit()
    ]
    return f"{(max(issue_ids) if issue_ids else 0) + 1:04d}"


def current_issue_id(events: list[Event]) -> str | None:
    closed = {event.issue_id for event in events if event.type == "fix" and event.issue_id}
    for event in reversed(events):
        if event.type == "issue" and event.issue_id not in closed:
            return event.issue_id
    return None


def get_git_commit(root: Path | None = None) -> str | None:
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--short", "HEAD"],
            cwd=root or Path.cwd(),
            check=True,
            capture_output=True,
            text=True,
        )
    except (OSError, subprocess.CalledProcessError):
        return None
    commit = result.stdout.strip()
    return commit or None
