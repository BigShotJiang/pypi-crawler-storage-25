"""Local-first memory for repos."""

__version__ = "0.0.1"
