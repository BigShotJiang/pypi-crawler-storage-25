from __future__ import annotations

from projectmem.models import Event
from projectmem.storage import read_events


def search_events(query: str) -> list[Event]:
    needle = query.casefold()
    return [
        event
        for event in read_events()
        if needle in event.summary.casefold()
        or (event.notes and needle in event.notes.casefold())
        or any(needle in file_path.casefold() for file_path in event.files)
    ]
