from __future__ import annotations

import re
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

from projectmem.models import Event
from projectmem.storage import issues_dir, read_events, summary_path


def regenerate_summary(root: Path | None = None) -> Path:
    events = read_events(root)
    content = build_summary(events, root or Path.cwd())
    path = summary_path(root)
    path.write_text(content, encoding="utf-8")
    write_issue_files(events, root)
    return path


def build_summary(events: list[Event], root: Path) -> str:
    project_name = root.name
    now = datetime.now(timezone.utc).date().isoformat()
    issues = group_issue_events(events)
    decisions = [event for event in events if event.type == "decision"]
    notes = [event for event in events if event.type == "note"]

    lines = [
        f"# projectmem — {project_name}",
        "",
        f"_Last updated: {now}_",
        "",
        "## What this project is",
        "Not described yet.",
        "",
        "## Recent issues",
    ]

    if not issues:
        lines.append("- No issues logged yet.")
    else:
        for issue_id, issue_events in sorted(issues.items(), reverse=True):
            issue = next(event for event in issue_events if event.type == "issue")
            fix = next((event for event in reversed(issue_events) if event.type == "fix"), None)
            status = "fixed" if fix else "open"
            marker = "DONE" if fix else "OPEN"
            outcome = f" -> {fix.summary}" if fix else ""
            lines.append(f"- [{marker}] #{issue_id} {issue.summary}{outcome} ({status})")
            lessons = [
                event.summary
                for event in issue_events
                if event.type == "attempt" and event.outcome == "failed"
            ]
            for lesson in lessons[-2:]:
                lines.append(f"  - Failed attempt: {lesson}")

    lines.extend(["", "## Decisions"])
    if decisions:
        for event in decisions:
            lines.append(f"- {event.summary}")
    else:
        lines.append("- No decisions logged yet.")

    lines.extend(["", "## Notes"])
    if notes:
        for event in notes[-10:]:
            lines.append(f"- {event.summary}")
    else:
        lines.append("- No notes logged yet.")

    lines.extend(["", "## Key files"])
    key_files = collect_files(events)
    if key_files:
        for file_path in key_files[:20]:
            lines.append(f"- `{file_path}`")
    else:
        lines.append("- No key files logged yet.")

    lines.extend(["", "## Open questions"])
    lines.append("- None logged yet.")
    lines.append("")
    return "\n".join(lines)


def group_issue_events(events: list[Event]) -> dict[str, list[Event]]:
    issues: dict[str, list[Event]] = defaultdict(list)
    for event in events:
        if event.issue_id:
            issues[event.issue_id].append(event)
    return dict(issues)


def collect_files(events: list[Event]) -> list[str]:
    seen: set[str] = set()
    files: list[str] = []
    for event in events:
        for explicit in event.files:
            if explicit not in seen:
                seen.add(explicit)
                files.append(explicit)
        for inferred in infer_file_mentions(event.summary):
            if inferred not in seen:
                seen.add(inferred)
                files.append(inferred)
    return files


def infer_file_mentions(text: str) -> list[str]:
    pattern = r"(?<![\w/.-])[\w./-]+\.[A-Za-z0-9]+(?::\d+)?"
    return re.findall(pattern, text)


def write_issue_files(events: list[Event], root: Path | None = None) -> None:
    for issue_id, issue_events in group_issue_events(events).items():
        issue = next((event for event in issue_events if event.type == "issue"), None)
        if issue is None:
            continue
        slug = slugify(issue.summary)
        path = issues_dir(root) / f"{issue_id}-{slug}.md"
        lines = [f"# #{issue_id} {issue.summary}", ""]
        for event in issue_events:
            detail = f"- {event.timestamp} `{event.type}`: {event.summary}"
            if event.outcome:
                detail += f" ({event.outcome})"
            lines.append(detail)
        lines.append("")
        path.write_text("\n".join(lines), encoding="utf-8")


def slugify(text: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")
    return (slug or "issue")[:48].strip("-") or "issue"
