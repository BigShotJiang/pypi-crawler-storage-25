from __future__ import annotations

import typer

from projectmem.commands import attempt as attempt_command
from projectmem.commands import decision as decision_command
from projectmem.commands import fix as fix_command
from projectmem.commands import init as init_command
from projectmem.commands import log as log_command
from projectmem.commands import note as note_command
from projectmem.commands import regenerate as regenerate_command
from projectmem.commands import search as search_command
from projectmem.commands import show as show_command
from projectmem.storage import ProjectMemError

app = typer.Typer(
    help="Local-first memory for repos.",
    no_args_is_help=True,
    add_completion=False,
)


@app.callback()
def callback() -> None:
    """Capture issues, attempts, fixes, decisions, and notes for this repo."""


@app.command()
def init() -> None:
    """Create .projectmem/ in the current repo."""
    init_command.run()


@app.command()
def log(text: str) -> None:
    """Start a new issue."""
    log_command.run(text)


@app.command()
def attempt(
    text: str,
    worked: bool = typer.Option(False, "--worked", help="Mark the attempt as worked."),
    failed: bool = typer.Option(False, "--failed", help="Mark the attempt as failed."),
    partial: bool = typer.Option(False, "--partial", help="Mark the attempt as partial."),
) -> None:
    """Record an attempt on the current issue."""
    attempt_command.run(text, worked=worked, failed=failed, partial=partial)


@app.command()
def fix(text: str) -> None:
    """Record a fix and close the current issue."""
    fix_command.run(text)


@app.command()
def decision(text: str) -> None:
    """Record a decision."""
    decision_command.run(text)


@app.command()
def note(text: str) -> None:
    """Record a free-form note."""
    note_command.run(text)


@app.command()
def show() -> None:
    """Print the current summary.md."""
    show_command.run()


@app.command()
def search(query: str) -> None:
    """Plain-text search across events."""
    search_command.run(query)


@app.command()
def regenerate() -> None:
    """Rebuild summary.md from events.jsonl."""
    regenerate_command.run()


def main() -> None:
    try:
        app()
    except ProjectMemError as exc:
        typer.echo(f"Error: {exc}", err=True)
        raise typer.Exit(1) from exc


if __name__ == "__main__":
    main()
