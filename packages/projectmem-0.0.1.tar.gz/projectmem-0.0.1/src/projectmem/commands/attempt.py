from __future__ import annotations

import typer

from projectmem.models import Event
from projectmem.storage import (
    ProjectMemError,
    append_event,
    current_issue_id,
    get_git_commit,
    read_events,
)
from projectmem.summary import regenerate_summary


def run(text: str, *, worked: bool, failed: bool, partial: bool) -> None:
    selected = [name for name, flag in [
        ("worked", worked),
        ("failed", failed),
        ("partial", partial),
    ] if flag]
    if len(selected) > 1:
        raise ProjectMemError("Use only one of --worked, --failed, or --partial.")

    events = read_events()
    issue_id = current_issue_id(events)
    if issue_id is None:
        raise ProjectMemError("No open issue found. Run `pm log <text>` first.")

    outcome = selected[0] if selected else "partial"
    append_event(
        Event(
            type="attempt",
            issue_id=issue_id,
            summary=text,
            outcome=outcome,
            git_commit=get_git_commit(),
        )
    )
    regenerate_summary()
    typer.echo(f"Recorded {outcome} attempt on #{issue_id}")
