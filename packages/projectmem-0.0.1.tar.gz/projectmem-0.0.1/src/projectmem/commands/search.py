from __future__ import annotations

import typer

from projectmem.search import search_events


def run(query: str) -> None:
    matches = search_events(query)
    if not matches:
        typer.echo("No matches.")
        return

    for event in matches:
        issue = f" #{event.issue_id}" if event.issue_id else ""
        outcome = f" ({event.outcome})" if event.outcome else ""
        typer.echo(f"{event.timestamp} {event.type}{issue}{outcome}: {event.summary}")
