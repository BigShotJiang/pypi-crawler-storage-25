from __future__ import annotations

import typer

from projectmem.models import Event
from projectmem.storage import append_event, get_git_commit, next_issue_id, read_events
from projectmem.summary import regenerate_summary


def run(text: str) -> None:
    events = read_events()
    issue_id = next_issue_id(events)
    event = Event(
        type="issue",
        issue_id=issue_id,
        summary=text,
        git_commit=get_git_commit(),
    )
    append_event(event)
    regenerate_summary()
    typer.echo(f"Logged issue #{issue_id}")
