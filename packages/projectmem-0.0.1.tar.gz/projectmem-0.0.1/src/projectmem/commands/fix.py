from __future__ import annotations

import typer

from projectmem.models import Event
from projectmem.storage import (
    ProjectMemError,
    append_event,
    current_issue_id,
    get_git_commit,
    read_events,
)
from projectmem.summary import regenerate_summary


def run(text: str) -> None:
    events = read_events()
    issue_id = current_issue_id(events)
    if issue_id is None:
        raise ProjectMemError("No open issue found. Run `pm log <text>` first.")

    append_event(
        Event(
            type="fix",
            issue_id=issue_id,
            summary=text,
            git_commit=get_git_commit(),
        )
    )
    regenerate_summary()
    typer.echo(f"Fixed issue #{issue_id}")
