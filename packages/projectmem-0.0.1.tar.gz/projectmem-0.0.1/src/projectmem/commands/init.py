from __future__ import annotations

import typer

from projectmem.storage import initialize


def run() -> None:
    path = initialize()
    typer.echo(f"Initialized {path}")
