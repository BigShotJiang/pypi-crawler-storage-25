from __future__ import annotations

import typer

from projectmem.models import Event
from projectmem.storage import append_event, get_git_commit
from projectmem.summary import regenerate_summary


def run(text: str) -> None:
    append_event(Event(type="note", summary=text, git_commit=get_git_commit()))
    regenerate_summary()
    typer.echo("Recorded note")
