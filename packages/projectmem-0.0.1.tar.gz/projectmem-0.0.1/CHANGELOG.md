# Changelog

## 0.0.1

- Initial local MVP scaffold.
