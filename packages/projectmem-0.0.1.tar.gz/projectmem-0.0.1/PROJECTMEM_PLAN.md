# projectmem — Planning Document

A small, local-first Python package that gives every repo a memory.
Captures issues, attempts, fixes, and decisions so you (and any AI tool)
can quickly understand what's going on in a project — without re-reading
every file or repeating past mistakes.

> **Package name (PyPI):** `projectmem` — _confirmed available on PyPI, TestPyPI, and GitHub as of planning_
> **Folder created in each repo:** `.projectmem/`
> **CLI command:** `projectmem` (with optional short alias `pm`)
>
> One name everywhere. No mental translation needed.

---

## 1. Motivation

When you work across many repos, context evaporates fast.

- You fix a bug on Tuesday, forget the cause by Friday.
- An AI assistant scans your whole repo every session, burning tokens to rebuild context it had yesterday.
- A junior teammate opens the repo and has no idea why a function is the way it is.
- The same bug pattern hits in repo #3 that you already solved in repo #7 — but the knowledge is gone.

The reason this keeps happening: **the most valuable knowledge is generated outside commits.** It lives in terminal sessions, AI chats, scratch notes, and your head. Git captures *what* changed; it doesn't capture *what was tried, what failed, and why the fix works.*

`projectmem` is a logbook for the messy middle of development. It saves a small, structured memory per repo (in `.projectmem/`) that humans and AI tools can both read.

---

## 2. What we're trying to solve

A specific, narrow problem:

1. **Context loss between sessions** — you forget what you did last week.
2. **AI tools waste tokens re-deriving context** — every new session starts from zero.
3. **Failed attempts disappear** — you (or the AI) try the same broken approach again.
4. **Onboarding is painful** — juniors and collaborators have no map of past decisions.
5. **Cross-repo knowledge is lost** — solutions in one repo don't help in another.

Out of scope (deliberately):

- Replacing git, issue trackers, or documentation.
- Cloud sync, team collaboration features, or auth.
- Generic AI memory (mem0, Letta already do that).
- Indexing the current state of code (Cursor, Aider already do that).

We are building a **local-first, append-only logbook of decisions and attempts**, nothing more.

---

## 3. What already exists (and the gap)

| Tool | What it does | What it misses |
|---|---|---|
| Anthropic prompt caching | Caches prefixes within a session | No cross-session, no semantic |
| `CLAUDE.md` / Cursor rules | Manual context file | Manual; no event capture |
| mem0, Letta, Zep | Generic agent memory | Not code-aware; weak on failures |
| Aider repo-map, Serena | Indexes current code | Doesn't capture *why* or *what failed* |
| Git history | What changed | Not why, not what was tried |

**The gap:** no tool combines *auto-capturable + AI-tool-agnostic + repo-scoped + captures negative knowledge (failures and dead ends)*. That's the wedge.

---

## 4. Naming decision

Documented here so future-you remembers why.

### Names considered and rejected

| Name | Why rejected |
|---|---|
| `project-brain` | Already taken on PyPI |
| `project-memory` | Already taken on PyPI |
| `brainy` | Available, friendly, but less descriptive |
| `devbrain` | Strong candidate, kept as fallback |
| `cortex` | Distinctive but veers into general-AI territory |

### Final choice: `projectmem`

- ✅ Available on PyPI
- ✅ Available on TestPyPI
- ✅ Available on GitHub
- ✅ Clear meaning: "project memory"
- ✅ Searchable
- ✅ No legal or trademark concerns

### Consistency principle

**One name everywhere.** Same word for the package, the folder, and the CLI. This avoids the three-name confusion that almost crept in earlier (different names for package vs. folder vs. command).

| Layer | Name |
|---|---|
| **Package (PyPI)** | `projectmem` |
| **Folder (per repo)** | `.projectmem/` |
| **CLI command** | `projectmem` (short alias: `pm`) |

`pip install projectmem` → run `projectmem init` → creates `.projectmem/`. No translation.

The short alias `pm` is registered as a second entry point so daily use stays fast: `pm log "..."`, `pm fix "..."`. Use whichever feels natural.

---

## 5. Core principles

These are the rules. If a feature violates one, it doesn't go in.

1. **Local-first.** No network calls, no cloud, no telemetry. Ever.
2. **Useful without AI.** A developer with no AI tools should still benefit. AI integration is a bonus, not a requirement.
3. **AI-tool-agnostic.** Claude Code, Cursor, Codex, future tools — all read the same folder. No vendor lock-in.
4. **Human-readable storage.** Markdown and JSONL only. Anyone can `cat` the files and understand them.
5. **Small surface area.** A handful of CLI commands. No plugin system in v1.
6. **Append-only raw log, compressed summary.** Raw history grows; summary stays small.
7. **Token-efficient by design.** A compact `summary.md` (target: under 20 KB) so AI tools can read the whole thing cheaply.
8. **One name.** Package, folder, CLI — all `projectmem`. Consistency over cleverness.

---

## 6. How it works (user perspective)

### One-time install

```bash
pip install projectmem
```

This puts the `projectmem` command (and `pm` alias) on your PATH. It does **not** create folders anywhere on install — that's an antipattern.

### Per-repo setup

```bash
cd ~/code/my-project
projectmem init
```

Creates a `.projectmem/` folder in the current repo. Run this once per repo. You have 10 repos? Run it 10 times.

### Daily use

Using the short alias for less typing:

```bash
# Start tracking a new issue
pm log "auth tokens expire after 1h instead of 24h"

# Record an attempt
pm attempt "bumped JWT_EXPIRY in config.py" --failed
pm attempt "found hardcoded TTL in middleware" --worked

# Record the fix
pm fix "changed TOKEN_TTL in auth/middleware.py:42"

# View the current memory
pm show

# Search past issues
pm search "token"
```

### What AI tools see

Any AI tool — Claude Code, Cursor, Codex, an LLM you wrote yourself — can read `.projectmem/summary.md` to get instant context. No integration required. It's just a Markdown file in the repo.

---

## 7. Folder structure (per-repo)

```
your-repo/
├── .projectmem/
│   ├── summary.md           # AI + human readable. The compressed memory. Commit this.
│   ├── events.jsonl         # Raw append-only log. Usually gitignored.
│   ├── issues/
│   │   ├── 0001-auth-expiry.md      # Per-issue files for deeper context
│   │   └── 0002-import-loop.md
│   └── config.toml          # Repo-specific settings
├── .gitignore               # projectmem init appends .projectmem/events.jsonl here
└── ... (your code)
```

### What each file is for

- **`summary.md`** — the compact, AI-readable memory. Auto-regenerated from events. Includes: project purpose (1 line), recent issues + outcomes, known gotchas, key files. Target size: under 20 KB so it fits cheaply in any context window.
- **`events.jsonl`** — the raw log. One JSON object per line. Append-only. Source of truth. Big over time.
- **`issues/NNNN-slug.md`** — when an issue gets too big for the summary, it gets its own file with full attempt history.
- **`config.toml`** — repo-specific knobs (summary size limit, what to ignore, etc.).

### What gets committed

- ✅ `summary.md` and `issues/` — shareable team knowledge
- ❌ `events.jsonl` — raw log, gitignored by default (can be opted in)
- ✅ `config.toml`

---

## 8. Event schema (what we actually capture)

Each line in `events.jsonl` is one event. Common fields:

```json
{
  "id": "evt_01HQ...",
  "timestamp": "2026-05-09T18:42:11Z",
  "type": "attempt",
  "issue_id": "0001",
  "summary": "bumped JWT_EXPIRY in config.py",
  "outcome": "failed",
  "files": ["config.py"],
  "command": null,
  "notes": "Didn't help — TTL was being overridden elsewhere",
  "git_commit": "a1b2c3d"
}
```

### Event types

| Type | Meaning |
|---|---|
| `issue` | A new problem to solve |
| `hypothesis` | A guess about the cause |
| `attempt` | Something tried; has `outcome: worked / failed / partial` |
| `fix` | The thing that resolved the issue |
| `decision` | An architectural choice with reasoning |
| `note` | Free-form observation |

### Why this schema

It mirrors how debugging actually happens: *issue → guess → try → fail → try → fix*. Capturing each step (especially the failed attempts) is what makes this different from a wiki or a CHANGELOG.

---

## 9. CLI commands (v1 surface)

Keep it small. These are the only commands for v1. Both `projectmem` and `pm` invoke them.

| Command | What it does |
|---|---|
| `projectmem init` | Create `.projectmem/` in the current repo |
| `pm log <text>` | Start a new issue |
| `pm attempt <text> [--worked\|--failed\|--partial]` | Record an attempt on the current issue |
| `pm fix <text>` | Record a fix; closes the current issue |
| `pm decision <text>` | Record a decision (independent of any issue) |
| `pm note <text>` | Free-form note |
| `pm show` | Print the current `summary.md` |
| `pm search <query>` | Plain-text search across events |
| `pm regenerate` | Rebuild `summary.md` from `events.jsonl` |

That's it. No flags ecosystem, no plugins, no daemons.

---

## 10. The summarization step

This is the part that matters most for token efficiency. It's also the hardest.

**The rule:** `summary.md` is a *derived view*, not a primary store. It's regenerated from `events.jsonl` whenever you run `pm fix`, `pm regenerate`, or hit a size threshold.

### What the summary contains

```markdown
# projectmem — my-project

_Last updated: 2026-05-09_

## What this project is
One-line description.

## Recent issues (last 30 days)
- ✅ #0003 Login redirect loop → fixed in `auth/redirect.py:88`
- ❌ #0002 Slow startup → still open
- ✅ #0001 Token expiry → fixed in `auth/middleware.py:42`

## Known gotchas
- The `EventBus` initializer must run before `AuthService` or tokens fail silently.
- `npm run build` requires Node 20+, not 18.

## Key files
- `auth/middleware.py` — JWT validation, TTL config
- `core/eventbus.py` — initialization-order sensitive

## Open questions
- Why does the test suite hang on CI but not locally?
```

### Compression strategy (v1, kept simple)

- Keep last 30 days of issues in full.
- Older issues: collapse to one-line outcomes.
- Failed attempts: keep only the *lesson*, not every step.
- Decisions: always keep, they don't expire.
- Hard cap: if `summary.md` exceeds ~20 KB, archive oldest content into a dated file.

For v1, summarization is template-based (no LLM call). Optional LLM-powered summarization can come in v2 as an opt-in flag.

---

## 11. Token efficiency claim

This is the headline benefit. Be honest about when it holds.

**Cost model:**

- Without `projectmem`: AI scans 50–200 KB of files per session to rebuild context.
- With `projectmem`: AI reads `summary.md` (~20 KB), pulls in issue files only when needed.

**Net result:**
- Designed well → significantly fewer tokens, especially across sessions.
- Designed badly (raw transcripts, duplicate entries, no compression) → *more* tokens.

**Honest caveats:**
- Anthropic's prompt caching already handles intra-session reuse. The win here is *cross-session and cross-repo*.
- Token savings are real but not the only motivation — human memory is the bigger win.

---

## 12. Tech stack

Boring is good. Pick boring.

| Concern | Choice | Why |
|---|---|---|
| Language | Python 3.10+ | Already what you're targeting; ubiquitous |
| CLI framework | `typer` | Cleaner than `click` for small tools |
| Storage (v1) | JSONL + Markdown files | Greppable, debuggable, no migration pain |
| Storage (v2 if needed) | SQLite | Only if querying gets slow |
| Config | `tomllib` (stdlib in 3.11+) | Zero dependencies |
| Build backend | `hatchling` | Modern, simple |
| Test framework | `pytest` | Standard |
| Lint/format | `ruff` | Fast, one tool for both |

No: Poetry, Pydantic, FastAPI, async, embeddings, vector DBs. Add later only if needed.

---

## 13. Repo layout

```
projectmem/
├── pyproject.toml
├── README.md
├── LICENSE                  # MIT
├── CHANGELOG.md
├── src/
│   └── projectmem/
│       ├── __init__.py
│       ├── cli.py           # typer app, command registration
│       ├── storage.py       # read/write events.jsonl
│       ├── summary.py       # regenerate summary.md
│       ├── search.py        # plain-text search
│       ├── models.py        # event dataclasses
│       └── commands/
│           ├── __init__.py
│           ├── init.py
│           ├── log.py
│           ├── attempt.py
│           ├── fix.py
│           ├── decision.py
│           ├── note.py
│           ├── show.py
│           ├── search.py
│           └── regenerate.py
├── tests/
│   ├── test_init.py
│   ├── test_log.py
│   ├── test_attempt.py
│   ├── test_summary.py
│   └── fixtures/
└── docs/
    ├── getting-started.md
    └── ai-integration.md
```

### `pyproject.toml` essentials

```toml
[project]
name = "projectmem"
version = "0.0.1"          # stub release for name-claiming
description = "Local-first memory for repos. Captures issues, attempts, fixes, and decisions."
authors = [{ name = "Your Name" }]
readme = "README.md"
license = { text = "MIT" }
requires-python = ">=3.10"
dependencies = [
  "typer>=0.12",
]

[project.scripts]
projectmem = "projectmem.cli:main"
pm = "projectmem.cli:main"

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"
```

After install, both `projectmem` and `pm` are on the user's PATH. Same command, two names — long for clarity, short for daily use.

---

## 14. Name-claiming workflow (DO THIS FIRST)

Before writing any real code, lock the name on PyPI, TestPyPI, and GitHub. The name is reserved by uploading any package with that name — it doesn't have to be functional yet.

### Why claim before coding

- PyPI and TestPyPI are **separate registries** with **separate name pools**. A name being free on one doesn't mean it's free on the other.
- Once someone else uploads `projectmem`, the name is gone forever. You'd be forced to rename mid-project.
- The cost to claim now: ~30 minutes. The cost to rename later: hours of search-and-replace plus user confusion.

### Step-by-step

**1. Create accounts** (separate accounts on each, can use the same email):
- PyPI: https://pypi.org/account/register/
- TestPyPI: https://test.pypi.org/account/register/
- GitHub: already have an account; just need to create the repo.

**2. Enable 2FA** on PyPI and TestPyPI (PyPI requires it). Use an authenticator app.

**3. Generate API tokens** under Account Settings → API tokens on each. Save in a password manager. You'll use these for upload, not your password.

**4. Build a stub package** — minimal `pyproject.toml` and an empty `__init__.py`. Use version `0.0.1` (NOT `0.1.0` — save that for the real first release).

The stub's package description should explicitly say:
> "Placeholder — under development. First real release coming soon."

**5. Upload to TestPyPI first:**
```bash
python -m pip install --upgrade build twine
python -m build
python -m twine upload --repository testpypi dist/*
```
Verify at `https://test.pypi.org/project/projectmem/`.

**6. Upload the same stub to real PyPI:**
```bash
python -m twine upload dist/*
```
Verify at `https://pypi.org/project/projectmem/`.

**7. Create the GitHub repo** at `github.com/<you>/projectmem`. Even with just a README pointing to "under development." That reserves the namespace.

### Important gotchas

- **PyPI versions are permanent.** Once you upload `0.0.1`, you cannot re-upload `0.0.1` even if it's broken. You must increment to `0.0.2`. This is why the stub burns `0.0.1` cheaply and the real first release is `0.1.0`.
- **Don't put real logic in the stub.** It just exists to claim the name. Real development happens in your local prototype until Phase 1.
- **Mark the stub clearly as a placeholder** in both the PyPI description and the GitHub README, so nobody accidentally `pip install`s it expecting features.

---

## 15. Development plan (MVP roadmap)

### Phase 0 — Personal prototype (weekend, this week)

Goal: have something *you use yourself*. No publishing, no users.

- [ ] Name claimed on PyPI, TestPyPI, GitHub (Section 14)
- [ ] `pip install -e .` works locally
- [ ] `projectmem init` creates `.projectmem/` with skeleton files
- [ ] `pm log`, `pm attempt`, `pm fix` write to `events.jsonl`
- [ ] `pm show` prints a minimal `summary.md`
- [ ] Use it in 2–3 of your own repos for a week

**Stop here and evaluate.** Did you actually reach for it? Did `pm show` ever help you remember something? If no — the idea didn't survive contact with reality, and that's the cheapest possible time to learn it.

### Phase 1 — Public v0.1 (week 2–3, if Phase 0 worked)

- [ ] Tests covering the core commands
- [ ] README with motivation, install, and examples
- [ ] `pm search` (plain-text grep over events)
- [ ] `pm regenerate` to rebuild summary
- [ ] Compression rules (30-day window, oldest-archive)
- [ ] Replace the `0.0.1` stub on TestPyPI with a real `0.1.0` release
- [ ] Push the same `0.1.0` to real PyPI

### Phase 2 — v0.2 (when v0.1 has real users or your own use stabilizes)

- [ ] Per-issue files in `issues/`
- [ ] Auto-detect git commit hashes for events
- [ ] Optional `--ai-summary` flag (calls user's local LLM if configured)
- [ ] Open issues on `mem0`, `basic-memory` etc. proposing integration

### Phase 3 — v0.3+ (only if there's demand)

- [ ] MCP server wrapper so Claude Code / Cursor can call `projectmem` natively
- [ ] `pm export` for cross-repo aggregation
- [ ] Optional embeddings-based search (opt-in)

**Resist** adding Phase 3 features before Phase 1 has real usage. That's where most projects die.

---

## 16. Risks and how to handle them

| Risk | Mitigation |
|---|---|
| Nobody uses it but you | That's fine. You're user #1. If it helps you across your 10 repos, it's a win. |
| The summary becomes a noisy junk drawer | Strict size cap; aggressive compression of old entries; review every release. |
| Stale entries mislead the AI | Tie events to git commit hashes; flag entries when referenced files change a lot. |
| Scope creep into "AI memory framework" | Re-read the principles. v1 is a logbook. Period. |
| An existing tool already does this | Spend a day searching PyPI, GitHub, and Hacker News before publishing. If something is 80% of this, contribute there instead of competing. |
| Privacy concerns (sensitive code in events) | Local-first. No telemetry. Loud documentation that `events.jsonl` is gitignored. |
| `pm` alias clashes with another tool | Document the long form `projectmem` as the canonical name; if `pm` is taken on a user's system, the long form still works. |

---

## 17. Success criteria

How do you know it worked?

**Phase 0 success (the only one that matters at first):**
- You used it on your own repos for two weeks without being prompted.
- At least once, `pm show` reminded you of something you'd forgotten.
- At least once, you avoided repeating a failed attempt because it was logged.

**Phase 1 success:**
- 10+ stars on GitHub from people who aren't you.
- 1+ issue or PR from an outside contributor.
- One real user describes it as "useful" in their own words.

**Phase 2+ success:**
- Adoption by other developers in similar situations (solo, multi-repo).
- AI tools natively reading `.projectmem/summary.md` because it's just there.

**The honest test:** if after a month you're not opening `.projectmem/summary.md` yourself, the tool isn't working. No amount of features will fix that.

---

## 18. Next concrete steps

In strict order. Don't skip ahead.

1. **Today:** Claim `projectmem` on PyPI, TestPyPI, and GitHub (Section 14). Upload the `0.0.1` stub.
2. **This evening:** Set up the local repo. Get `projectmem init` working.
3. **Tomorrow:** Implement `log`, `attempt`, `fix`, `show`. Use it on one of your repos.
4. **End of week 1:** Use it on 2–3 repos. Note where it feels clunky.
5. **End of week 2:** Decide. Keep going / pivot / drop.
6. **If keep going:** clean up, write README, replace stub with real `0.1.0` on TestPyPI then PyPI.
7. **If pivot:** the feedback from real use will tell you what to change.
8. **If drop:** you've spent a weekend, learned something, and built nothing wasted.

The whole point of this plan is that step 1 is small enough to do today. Everything else is conditional on the previous step being useful.

---

## Appendix A — Example session

```bash
$ pip install projectmem
$ cd ~/code/payments-api
$ projectmem init
✓ Created .projectmem/
✓ Added .projectmem/events.jsonl to .gitignore

$ pm log "webhook signatures failing intermittently"
✓ Issue #0001 logged

$ pm attempt "checked HMAC algorithm — sha256, correct" --failed
$ pm attempt "noticed signatures fail only on retries" --partial
$ pm attempt "found timestamp tolerance was 5s, retries take 8s" --worked
$ pm fix "bumped tolerance to 30s in webhooks/verify.py:23"

$ pm show
# projectmem — payments-api

## Recent issues
- ✅ #0001 Webhook signatures failing intermittently
  - Cause: 5s timestamp tolerance, retries took 8s
  - Fix: bumped tolerance to 30s in webhooks/verify.py:23

## Known gotchas
- (none yet)
```

A week later, in another repo, you hit a similar issue. `pm search "webhook signature"` across your repos (a v2 feature) surfaces the old fix. You don't re-debug for two hours.

That's the win.

---

## Appendix B — One-line README intro

When writing the README, lead with this:

> **`projectmem`** is a local-first memory for your repos. `pip install projectmem`, run `projectmem init`, and a `.projectmem/` folder starts capturing what you've tried, what failed, and what worked. Any AI tool can read it. So can you, six months later.

Same word for everything. That's the consistency win.
