# AI integration

`projectmem` does not need a vendor-specific integration. Point an AI tool at:

```text
.projectmem/summary.md
```

That file is a compact, derived view of the repo memory. For deeper context,
open the matching issue file under:

```text
.projectmem/issues/
```

The raw append-only log lives at `.projectmem/events.jsonl` and is ignored by
Git by default.
