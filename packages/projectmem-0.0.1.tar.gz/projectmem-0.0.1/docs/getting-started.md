# Getting started

Install the local development build:

```bash
python -m pip install -e ".[dev]"
```

Initialize a repo:

```bash
projectmem init
```

Use the short alias for daily logging:

```bash
pm log "import loop after moving settings"
pm attempt "moved import into function" --worked
pm fix "lazy-loaded settings in app/config.py"
pm show
```
