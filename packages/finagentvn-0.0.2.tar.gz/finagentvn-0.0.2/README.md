# VNSFintech

`VNSFintech` là thư viện Python cung cấp dữ liệu và công cụ hỗ trợ tài chính cho các nhà đầu tư và phân tích thị trường chứng khoán.

## Cài đặt

Cài đặt thư viện mới:

```bash
pip install VNSFintech
```

Cập nhật phiên bản mới:

```bash
pip install --upgrade VNSFintech
```

## Sử dụng

```python
from VNSFintech import *
```

---

# Hướng dẫn sử dụng
Thư viện `VNSFintech` được chia làm các mảng chính:

_ stock: dữ liệu về cổ phiếu được niêm yết trên các sàn giao dịch chứng khoán Việt Nam.

_ exchange: dữ liệu về các sàn giao dịch chứng khoán Việt Nam.

_ indice: dữ liệu về các chỉ số chứng khoán.

_ fund: dữ liệu về chứng chỉ quỹ trên các sàn giao dịch chứng khoán Việt Nam.

_ macro_economic: dữ liệu về các chỉ số kinh tế vĩ mô của Việt Nam.

_ other: dữ liệu về các chỉ số khác vd: vàng, dầu thô,...


---
# **stock** : Cổ phiếu Việt Nam
Dữ liệu về cổ phiếu được chia ra làm 4 mục: thị trường, tài chính, cổ đông, tin tức - sự kiện.
---

## **market** : Dữ liệu thị trường
---

### 1. Thông tin mã cổ phiếu:

Cung cấp thông tin về cổ phiếu thuộc sàn giao dịch nào, tên và ngành của cổ phiếu đó.

`stock_info(exchange=None)`

Cách gọi hàm sử dụng:
```python
cp = stock(symbol='ACB')
df = cp.stock_info()
```
hoặc gọi nhanh: 

```python
df = stock.get_stock_info(symbol='ACB')
```

---

### 2. Lịch sử ohlcv:

Cung cấp dữ liệu lịch sử theo ngày hoặc theo phút của giá đóng cửa, giá mở của, giá cao nhất, giá thấp nhất và khối lượng giao dịch của cổ phiếu đó.

`history(interval, start, end)`

`interval`:
- `'minutes'`
- `'hours'`
- `'days'`
- `'months'`

Cách gọi hàm sử dụng:
```python
cp = stock(symbol='ACB')
df = cp.history(interval='days', start='2020-01-01', end='2023-01-01')
```
hoặc gọi nhanh: 

```python
df = stock.get_history(symbol='ACB', interval='days', start='2020-01-01', end='2023-01-01')
```

---

### 3. Lịch sử khớp lệnh:
#### Danh sách lịch sử khớp lệnh:

Cung cấp danh sách lịch sử các lệnh giao dịch đã khớp tính theo từng lệnh của cổ phiếu.

`intraday()`

Cách gọi hàm sử dụng:

```python
cp = stock(symbol='ACB')
df = cp.intraday()
```
hoặc gọi nhanh: 

```python
df = stock.get_intraday(symbol='ACB')
```

#### Phân loại khớp lệnh theo nhà đầu tư:

Cung cấp danh sách lịch sử khớp lệnh tính theo nhà đầu tư và phân loại khớp lệnh thành 3 loại: Cá mập, Sói già, và Cừu non.

`intraday_order()`

Cách gọi hàm sử dụng:

```python
cp = stock(symbol='ACB')
df = cp.intraday_order()
```

hoặc gọi nhanh:

```python
df = stock.get_intraday_order(symbol='ACB')
```

---

### 4. Thông tin giá cổ phiếu:
#### Danh sách giá cổ phiếu:

Cung cấp lịch sử dữ liệu chi tiết về giá và khối lượng giao dịch của cổ phiếu theo ngày, tháng, quý, năm.

`price_history(interval, start=None, end=None)`

`interval`:
- `'days'` : start = 2023-01-01 ; end = 2026-12-31
- `'months'` : start = 2023-01 ; end = 2026-12
- `'quarters'` : start = 2023 ; end = 2026
- `'years'` : start = 2023 ; end = 2026

Cách gọi hàm sử dụng:

```python
cp = stock(symbol='ACB')
df = cp.price_history(interval='days', start='2020-01-01', end='2023-01-01')
```

hoặc gọi nhanh:

```python
df = stock.get_price_history(symbol='ACB', interval='days', start='2020-01-01', end='2023-01-01')
```

#### Tổng hợp giá cổ phiếu: 

Cung cấp dữ liệu tổng đến hiện tại và trung bình theo ngày, tháng, quý, năm.

`price_history_summary(interval)`

`interval`:
- `'days'`
- `'months'`
- `'quarters'`
- `'years'`

Cách gọi hàm sử dụng:

```python
cp = stock(symbol='ACB')
df = cp.price_history_summary(interval='days')
```

hoặc gọi nhanh:

```python
df = stock.get_price_history_summary(symbol='ACB', interval='days')
```

---

### 5. Nước ngoài:
#### Lịch sử giao dịch nước ngoài:

Cung cấp dữ liệu giao dịch với nước ngoài của cổ phiếu.

`foreign_history(interval, start=None, end=None)` 

`interval`:
- `'days'` : start = 2023-01-01 ; end = 2026-12-31
- `'months'` : start = 2023-01 ; end = 2026-12
- `'quarters'` : start = 2023 ; end = 2026
- `'years'` : start = 2023 ; end = 2026

Cách gọi hàm sử dụng:

```python
cp = stock(symbol='ACB')
df = cp.foreign_history(interval='days', start='2020-01-01', end='2023-01-01')
```

hoặc gọi nhanh:

```python
df = stock.get_foreign_history(symbol='ACB', interval='days', start='2020-01-01', end='2023-01-01')
```

#### Tổng hợp giao dịch nước ngoài: 

Cung cấp dữ liệu tổng đến hiện tại và trung bình theo ngày, tháng, quý, năm.

`foreign_history_summary(interval)`

`interval`:
- `'days'`
- `'months'`
- `'quarters'`
- `'years'`

Cách gọi hàm sử dụng:

```python
cp = stock(symbol='ACB')
df = cp.foreign_history_summary(interval='days')
```

hoặc gọi nhanh:

```python
df = stock.get_foreign_history_summary(symbol='ACB', interval='days')
```

---

### 6. Tự doanh
#### Lịch sử giao dịch tự doanh:

Cung cấp dữ liệu giao dịch tự doanh của cổ phiếu.

`proprietary_history(interval, start=None, end=None)`

`interval`:
- `'days'` : start = 2023-01-01 ; end = 2026-12-31
- `'months'` : start = 2023-01 ; end = 2026-12
- `'quarters'` : start = 2023 ; end = 2026
- `'years'` : start = 2023 ; end = 2026

Cách gọi hàm sử dụng:

```python
cp = stock(symbol='ACB')
df = cp.proprietary_history(interval='days', start='2020-01-01', end='2023-01-01')
```

hoặc gọi nhanh:

```python
df = stock.get_proprietary_history(symbol='ACB', interval='days', start='2020-01-01', end='2023-01-01')
```

#### Tổng hợp giao dịch tự doanh: 

Cung cấp dữ liệu tổng đến hiện tại và trung bình theo ngày, tháng, quý, năm.

`proprietary_history_summary(interval)`

`interval`:
- `'days'`
- `'months'`
- `'quarters'`
- `'years'`

Cách gọi hàm sử dụng:

```python
cp = stock(symbol='ACB')
df = cp.proprietary_history_summary(interval='days')
```

hoặc gọi nhanh:

```python
df = stock.get_proprietary_history_summary(symbol='ACB', interval='days')
```

---

### 7. Cung cầu

Cung cấp dữ liệu đặt mua, đặt bán, các giao dịch mua bán chưa khớp.

`demand_history(interval, start, end)`

`interval`:
- `'days'` : start = 2023-01-01 ; end = 2026-12-31
- `'months'` : start = 2023-01 ; end = 2026-12
- `'quarters'` : start = 2023 ; end = 2026
- `'years'` : start = 2023 ; end = 2026

Cách gọi hàm sử dụng:

```python
cp = stock(symbol='ACB')
df = cp.demand_history(interval='days', start='2020-01-01', end='2023-01-01')
```

hoặc gọi nhanh:

```python
df = stock.get_demand_history(symbol='ACB', interval='days', start='2020-01-01', end='2023-01-01')
```

---

## **financial** : Dữ liệu tài chính
---
### 1. Chỉ số tài chính:
`finance_ratio(interval)`

`interval`:
- `'quarters'`
- `'years'`

Cách gọi hàm sử dụng:

```python
cp = stock(symbol='ACB')
df = cp.finance_ratio(interval='years')
```

hoặc gọi nhanh:

```python
df = stock.get_finance_ratio(symbol='ACB', interval='years')
```
---

### 2. Bảng cân đối kế toán:
`balance_sheet(interval)`
 
`interval`:
- `'quarters'`
- `'years'`

Cách gọi hàm sử dụng:

```python
cp = stock(symbol='ACB')
df = cp.balance_sheet(interval='years')
```

hoặc gọi nhanh:

```python
df = stock.get_balance_sheet(symbol='ACB', interval='years')
```
---

### 3. Kết quả kinh doanh:
`income_statement(interval)`

`interval`:
- `'quarters'`
- `'years'`

Cách gọi hàm sử dụng:

```python
cp = stock(symbol='ACB')
df = cp.income_statement(interval='years')
```

hoặc gọi nhanh:

```python
df = stock.get_income_statement(symbol='ACB', interval='years')
```
---

### 4. Báo cáo lưu chuyển tiền tệ:
`cash_flow(interval)`

`interval`:
- `'quarters'`
- `'years'`

Cách gọi hàm sử dụng:

```python
cp = stock(symbol='ACB')
df = cp.cash_flow(interval='years')
```

hoặc gọi nhanh:

```python
df = stock.get_cash_flow(symbol='ACB', interval='years')
```
---

## **shareholder** : Dữ liệu cổ đông
---
### 1. Thông tin cổ đông:

Cung cấp danh sách các cổ đông, chức vụ, số lượng cổ phiếu sở hữu,...

`shareholders_info()`

Cách gọi hàm sử dụng:

```python
cp = stock(symbol='ACB')
df = cp.shareholders_info()
```

hoặc gọi nhanh:

```python
df = stock.get_shareholders_info(symbol='ACB')
```
---

### 2. Cấu trúc cổ đông:

Cung cấp dữ liệu số lượng cổ phiếu phát hành và số lượng cổ phiếu các bên nắm giữ.

`shareholders_structure()`

Cách gọi hàm sử dụng:

```python
cp = stock(symbol='ACB')
df = cp.shareholders_structure()
```

hoặc gọi nhanh:

```python
df = stock.get_shareholders_structure(symbol='ACB')
```
---

### 3. Các công ty liên quan:

Cung cấp dữ liệu về các công ty con và công ty liên kết cũng như tỷ lệ nắm giữ của cổ phiếu đó.

`shareholders_relationship()`

Cách gọi hàm sử dụng:

```python
cp = stock(symbol='ACB')
df = cp.shareholders_relationship()
```

hoặc gọi nhanh:

```python
df = stock.get_shareholders_relationship(symbol='ACB')
```
---

### 4. Giao dịch nội bộ:

Cung cấp dữ liệu về các giao dịch cổ phiếu có liên quan đến nội bộ công ty.

`insider_trans()`

Cách gọi hàm sử dụng:

```python
cp = stock(symbol='ACB')
df = cp.insider_trans()
```

hoặc gọi nhanh:

```python
df = stock.get_insider_trans(symbol='ACB')
```

---

## **event** : Dữ liệu tin tức & sự kiện
---

### 1. Tin tức:

Cung cấp dữ liệu tin tức liên quan đến cổ phiếu.

`news()`

Cách gọi hàm sử dụng:

```python
cp = stock(symbol='ACB')
df = cp.news()
```

hoặc gọi nhanh:

```python
df = stock.get_news(symbol='ACB')
```
---

### 2. Cổ tức:

Cung cấp dữ liệu về cổ tức, lịch trả cổ tức, ... của cổ phiếu.

`dividend()` 

Cách gọi hàm sử dụng:

```python
cp = stock(symbol='ACB')
df = cp.dividend()
```

hoặc gọi nhanh:

```python
df = stock.get_dividend(symbol='ACB')
```
---

### 3. Họp HDQT:

Cung cấp thông tin về lịch tổ chức ĐHĐCĐ thường niên.

`general_meeting()` 

Cách gọi hàm sử dụng:

```python
cp = stock(symbol='ACB')
df = cp.general_meeting()
```

hoặc gọi nhanh:

```python
df = stock.get_general_meeting(symbol='ACB')
```
---

### 4. Sự kiện khác:

Cung cấp thông tin niêm yết và các sự kiện khác của cổ phiếu.

`other_event()`

Cách gọi hàm sử dụng:

```python
cp = stock(symbol='ACB')
df = cp.other_event()
```

hoặc gọi nhanh:

```python
df = stock.get_other_event(symbol='ACB')
```
---

# **exchange** : Sàn chứng khoán Việt Nam
---

### Danh sách top cổ phiếu tăng/giảm:

`get_top_stock(exchange, up_down)`

`exchange`:
- `'HOSE'`
- `'HNX'`
- `'UPCOM'`

`up_down`:
- `'up'`
- `'down'`

Cách gọi hàm sử dụng:

```python
ex = exchange(exchange='HOSE')
df = ex.top_stock(up_down='up')
```

hoặc gọi nhanh:
```python
df = exchange.get_top_stock(exchange='HOSE', up_down='up')
```
---

# **indice** : chỉ số chứng khoán Việt Nam
---
### Dữ liệu chỉ số chứng khoán Việt Nam:

`overview_market(start, end)`

`indice`:
- `'VNINDEX'`
- `'VN30'`
- `'HNXINDEX'`
- `'UPINDEX'`

Cách gọi hàm sử dụng:

```python
ind = indice(indice='VNINDEX')
df = ind.overview_market(start='2024-01-01', end='2025-01-01')
```

hoặc gọi nhanh:

```python
df = indice.get_overview_market(indice='VNINDEX', start='2024-01-01', end='2025-01-01')
```

---

# **fund** : chứng chỉ quỹ
---

### 1. Danh sách các chứng chỉ quỹ:

`fund_listing()`

Cách gọi hàm sử dụng:
```python
df = fund.fund_listing()
```
---

### 2. Tăng trưởng tài sản ròng (NAV) của quỹ:

`nav_history(start=None, end=None)`

`fund`:
- `'BMFF'`
- `'87'`

Xem ở fund_listing()

Cách gọi hàm sử dụng:

```python
f = fund(fund='BMFF')
df = f.nav_history(start='2020-01-01', end='2023-01-01')
```

hoặc gọi nhanh:

```python
df = fund.get_nav_history(fund='BMFF', start='2020-01-01', end='2023-01-01')
```

---

### 3. Danh mục đầu tư lớn:
`top_holding()`

`fund`:
- `'BMFF'`
- `'87'`

Xem ở fund_listing()

Cách gọi hàm sử dụng:

```python
f = fund(fund='BMFF')
df = f.top_holding()
```

hoặc gọi nhanh:

```python
df = fund.get_top_holding(fund='BMFF')
```
---

### 4. Phân bổ quỹ theo tài sản nắm giữ:
`asset_holding()`

`fund`:
- `'BMFF'`
- `'87'`

Xem ở fund_listing()

Cách gọi hàm sử dụng:

```python
f = fund(fund='BMFF')
df = f.asset_holding()
```

hoặc gọi nhanh:

```python
df = fund.get_asset_holding(fund='BMFF')
```
---

### 5. Phân bổ quỹ theo ngành:
`industries_holding()`

`fund`:
- `'BMFF'`
- `'87'`

Xem ở fund_listing()

Cách gọi hàm sử dụng:

```python
f = fund(fund='BMFF')
df = f.industries_holding()
```

hoặc gọi nhanh:
```python
df = fund.get_industries_holding(fund='BMFF')
```

---

# **macro_economic**: Chỉ số kinh tế vĩ mô Việt Nam
---

`general(interval, start, end)`

`interval`:
- `'days'` : start = 2023-01-01 ; end = 2026-12-31
- `'months'` : start = 2023-01 ; end = 2026-12
- `'quarters'` : start = 2023 ; end = 2026
- `'years'` : start = 2023 ; end = 2026

`indicator`:
- `'GDP'`, `'CPI'`, ...
- hoặc ID: `43`, `52`, ...

### Danh sách chỉ số vĩ mô

| ID | Indicator                | Symbol  | interval                     |
|----|--------------------------|---------|--------------------------|
| 43 | GDP                      | GDP     | quarters , years         |
| 52 | CPI                      | CPI     | months , years           |
| 46 | Sản xuất công nghiệp     | IIP     | months , years           |
| 47 | Bán lẻ                   | RET     | months , quarters , years|
| 48 | Xuất nhập khẩu           | TRADE   | months , years           |
| 50 | FDI                      | FDI     | months , years           |
| 51 | Tín dụng                 | CREDIT  | months , years           |
| 53 | Tỷ giá                   | FX      | days , years             |
| 55 | Dân số và lao động       | LABOR   | years                    |


Cách gọi hàm sử dụng:
Dùng id:

```python
m = macro_economic(indicator=51)
df = m.general(interval='years', start='2021', end='2024')
```

Hoặc dùng tên chỉ số:

```python
m = macro_economic(indicator='Tín dụng')
df = m.general(interval='years', start='2021', end='2024')
```

Hoặc dùng symbol:

```python
m = macro_economic(indicator='CREDIT')  # Tín dụng
df = m.general(interval='years', start='2021', end='2024')
```

hoặc gọi nhanh:

```python
df = macro_economic.get_general(indicator='GDP', interval='years', start='2021', end='2024')
df = macro_economic.get_general(indicator=43, interval='quarters', start='2020', end='2023')
df = macro_economic.get_general(indicator='CREDIT', interval='quarters', start='2020', end='2023')
```
---

# **other** : các chỉ số khác
---
### Dữ liệu các chỉ số khác:

`exchange_other()`

Cách gọi hàm sử dụng:

```python
df = other.exchange_other()
```

---


## Giấy phép

Thư viện này được phát hành theo giấy phép MIT. Vui lòng xem tệp LICENSE để biết thêm chi tiết.