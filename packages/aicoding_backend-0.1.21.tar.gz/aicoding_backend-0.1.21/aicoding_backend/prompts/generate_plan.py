"""
generate_plan prompt 生成器
generate_plan prompt generator
负责拼装实现方案工具返回的执行提示
Responsible for assembling the execution prompt returned by generate_plan
"""

from dataclasses import dataclass
from pathlib import Path
from typing import Mapping, Optional

from aicoding_backend.utils.file_reader import read_file
from aicoding_backend.utils.loader import load_prompt
from aicoding_backend.utils.template import generate_prompt


@dataclass
class GeneratePlanPromptParams:
    """
    generate_plan prompt 参数类
    generate_plan prompt parameters class
    """
    requirement_text: str
    output_dir: str = ".joycode/docs"


async def get_generate_plan_prompt(
    params: Optional[GeneratePlanPromptParams] = None
) -> str:
    """
    获取 generate_plan 的完整 prompt
    Get the complete prompt for generate_plan

    Args:
        params: prompt 参数 / prompt parameters

    Returns:
        str: 生成的 prompt / generated prompt
    """
    if isinstance(params, Mapping):
        params = GeneratePlanPromptParams(**params)
    params = params or GeneratePlanPromptParams(requirement_text="")

    template_path = Path(__file__).with_name("plan_base.md")
    template_content = await read_file(template_path)
    template_content = load_prompt(template_content, "GENERATE_PLAN_TEMPLATE")

    prompt_template = """
## 用户需求

{requirement_text}

---

## 执行指南

{template_content}

---

【强制执行要求】
1. **分析需求**
   - 按照 Role、Workflow 和 Constraints 深度分析需求。
   - 仅检索并阅读与当前需求直接相关的代码、规则文件和文档，禁止脱离代码事实进行猜测。

2. **生成结构紧凑的实施方案**
   - 严格按照模板生成 Markdown 文档，内容要聚焦实施，不输出冗长的原理解释。
   - 避免单独生成“验证标准”章节，请将测试与验证动作合并到执行计划最后阶段，避免重复。
   - 文件路径不确定时，必须显式标注“建议路径（待确认）”。

3. **保存方案（核心目标）**
   - 从需求中提取简洁的功能名作为文件名，命名格式建议为 `<需求简述>_plan.md`。
   - 必须将完整方案保存到 `{output_dir}/<需求简述>_plan.md`。

4. **执行顺序**
   - 分析需求 -> 检索相关上下文 -> 生成方案 -> 保存文件。

**[AI Agent Action]**编辑完方案文档后，请呼叫「log_report」工具进行本次工具使用记录上报，本次记录使用的工具为generate_plan。
"""

    return generate_prompt(
        prompt_template,
        {
            "requirement_text": params.requirement_text.strip(),
            "template_content": template_content,
            "output_dir": params.output_dir,
        },
    )
