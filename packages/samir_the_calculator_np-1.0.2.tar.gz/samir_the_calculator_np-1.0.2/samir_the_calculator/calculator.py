"""
Main calculator module with all mathematical operations.
"""

import math
from typing import Union, List, Tuple


class Calculator:
    """
    A simple calculator class that performs basic and advanced mathematical operations.
    """

    def __init__(self):
        """Initialize the calculator with an empty history."""
        self.history: List[Tuple[str, Union[int, float]]] = []

    def add(self, a: Union[int, float], b: Union[int, float]) -> Union[int, float]:
        """
        Add two numbers.

        Args:
            a: First number
            b: Second number

        Returns:
            Sum of a and b
        """
        result = a + b
        self.history.append((f"{a} + {b}", result))
        return result

    def subtract(self, a: Union[int, float], b: Union[int, float]) -> Union[int, float]:
        """
        Subtract b from a.

        Args:
            a: First number
            b: Second number

        Returns:
            Difference of a and b
        """
        result = a - b
        self.history.append((f"{a} - {b}", result))
        return result

    def multiply(self, a: Union[int, float], b: Union[int, float]) -> Union[int, float]:
        """
        Multiply two numbers.

        Args:
            a: First number
            b: Second number

        Returns:
            Product of a and b
        """
        result = a * b
        self.history.append((f"{a} * {b}", result))
        return result

    def divide(self, a: Union[int, float], b: Union[int, float]) -> float:
        """
        Divide a by b.

        Args:
            a: Dividend
            b: Divisor

        Returns:
            Quotient of a and b

        Raises:
            ValueError: If b is zero
        """
        if b == 0:
            raise ValueError("Cannot divide by zero!")
        result = a / b
        self.history.append((f"{a} / {b}", result))
        return result

    def power(self, base: Union[int, float], exponent: Union[int, float]) -> Union[int, float]:
        """
        Raise base to the power of exponent.

        Args:
            base: Base number
            exponent: Exponent

        Returns:
            base raised to the power of exponent
        """
        result = base ** exponent
        self.history.append((f"{base} ^ {exponent}", result))
        return result

    def square_root(self, a: Union[int, float]) -> float:
        """
        Calculate the square root of a number.

        Args:
            a: Number to find square root of

        Returns:
            Square root of a

        Raises:
            ValueError: If a is negative
        """
        if a < 0:
            raise ValueError("Cannot calculate square root of negative number!")
        result = math.sqrt(a)
        self.history.append((f"√{a}", result))
        return result

    def percentage(self, value: Union[int, float], percent: Union[int, float]) -> float:
        """
        Calculate the percentage of a number.

        Args:
            value: The base value
            percent: The percentage to calculate

        Returns:
            The percentage of the value
        """
        result = (value * percent) / 100
        self.history.append((f"{percent}% of {value}", result))
        return result

    def absolute(self, a: Union[int, float]) -> Union[int, float]:
        """
        Get the absolute value of a number.

        Args:
            a: Number to get absolute value of

        Returns:
            Absolute value of a
        """
        result = abs(a)
        self.history.append((f"|{a}|", result))
        return result

    def get_history(self) -> List[Tuple[str, Union[int, float]]]:
        """
        Get the calculation history.

        Returns:
            List of tuples containing (operation, result)
        """
        return self.history

    def clear_history(self) -> None:
        """Clear the calculation history."""
        self.history.clear()

    def print_history(self) -> None:
        """Print the calculation history in a formatted way."""
        if not self.history:
            print("No calculations yet.")
            return

        print("\n" + "=" * 50)
        print("CALCULATION HISTORY")
        print("=" * 50)
        for i, (operation, result) in enumerate(self.history, 1):
            print(f"{i}. {operation} = {result}")
        print("=" * 50 + "\n")
