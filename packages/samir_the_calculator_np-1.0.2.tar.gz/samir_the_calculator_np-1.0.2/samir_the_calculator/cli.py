from .calculator import Calculator

def main():
    calc = Calculator()
    print("=" * 50)
    print("      Welcome to Samir's Calculator!")
    print("=" * 50)
    print("Operations: +  -  *  /  **  sqrt  %  abs  history  quit")
    print()

    while True:
        op = input("Enter operation: ").strip().lower()

        if op == 'quit':
            print("Goodbye!")
            break

        elif op == 'history':
            calc.print_history()

        elif op == 'sqrt':
            try:
                a = float(input("Enter number: "))
                print(f"  Result: {calc.square_root(a)}\n")
            except ValueError as e:
                print(f"  Error: {e}\n")

        elif op == 'abs':
            try:
                a = float(input("Enter number: "))
                print(f"  Result: {calc.absolute(a)}\n")
            except ValueError as e:
                print(f"  Error: {e}\n")

        elif op == '%':
            try:
                value = float(input("Enter base value: "))
                percent = float(input("Enter percentage: "))
                print(f"  Result: {calc.percentage(value, percent)}\n")
            except ValueError as e:
                print(f"  Error: {e}\n")

        elif op in ['+', '-', '*', '/', '**']:
            try:
                a = float(input("Enter first number: "))
                b = float(input("Enter second number: "))
                ops = {
                    '+':  calc.add,
                    '-':  calc.subtract,
                    '*':  calc.multiply,
                    '/':  calc.divide,
                    '**': calc.power,
                }
                print(f"  Result: {ops[op](a, b)}\n")
            except ValueError as e:
                print(f"  Error: {e}\n")

        else:
            print("  Unknown operation. Try again.\n")

if __name__ == "__main__":
    main()