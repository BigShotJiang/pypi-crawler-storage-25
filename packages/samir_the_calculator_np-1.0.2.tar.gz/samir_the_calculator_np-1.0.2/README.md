# Samir's Calculator

A fully functional calculator by Samir Neupane with history tracking.

## Installation

pip install samir_the_calculator

## Python Usage

from samir_the_calculator import Calculator

calc = Calculator()
print(calc.add(5, 3))           # 8
print(calc.subtract(10, 4))     # 6
print(calc.multiply(3, 7))      # 21
print(calc.divide(20, 4))       # 5.0
print(calc.power(2, 8))         # 256
print(calc.square_root(81))     # 9.0
print(calc.percentage(200, 15)) # 30.0
print(calc.absolute(-42))       # 42
calc.print_history()            # shows all past operations

## Command Line

samir_calc