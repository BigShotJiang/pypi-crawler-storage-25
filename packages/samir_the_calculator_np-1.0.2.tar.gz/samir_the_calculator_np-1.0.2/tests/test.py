from samir_the_calculator import Calculator

calc = Calculator() 
print(calc.add(5, 3)) 
print(calc.subtract(10, 4)) 
print(calc.multiply(3, 7)) 
print(calc.divide(20, 4)) 
print(calc.power(2, 8)) 
print(calc.square_root(81)) 
print(calc.percentage(200, 15)) 
print(calc.absolute(-42)) 
calc.print_history() 
