"""Tests for the CryptoLogo Python client."""

from __future__ import annotations

import pytest

from cryptologo import CryptoLogo
from cryptologo.client import CryptoLogoError
from cryptologo.types import ALLOWED_SIZES, ALL_FORMATS, ICO_SIZES, Coin


class TestCoin:
    def test_from_dict(self) -> None:
        data = {
            "name": "Bitcoin",
            "ticker": "BTC",
            "slug": "bitcoin-btc",
            "has_png": True,
            "has_svg": True,
            "search_terms": ["\ube44\ud2b8\ucf54\uc778"],
            "market_cap_rank": 1,
        }
        coin = Coin.from_dict(data)
        assert coin.name == "Bitcoin"
        assert coin.ticker == "BTC"
        assert coin.slug == "bitcoin-btc"
        assert coin.has_png is True
        assert coin.has_svg is True
        assert coin.market_cap_rank == 1

    def test_from_dict_minimal(self) -> None:
        coin = Coin.from_dict({"name": "Test", "ticker": "TST", "slug": "test-tst"})
        assert coin.has_png is False
        assert coin.market_cap_rank is None


class TestCryptoLogoClient:
    def test_default_base_url(self) -> None:
        client = CryptoLogo()
        assert client.base_url == "https://crypto-logo.com"

    def test_custom_base_url(self) -> None:
        client = CryptoLogo(base_url="http://localhost:8002/")
        assert client.base_url == "http://localhost:8002"

    def test_get_logo_url_svg(self) -> None:
        client = CryptoLogo()
        url = client.get_logo_url("bitcoin-btc", "svg")
        assert url == "https://crypto-logo.com/api/logo/bitcoin-btc.svg"

    def test_get_logo_url_png_with_size(self) -> None:
        client = CryptoLogo()
        url = client.get_logo_url("bitcoin-btc", "png", width=256, height=256)
        assert url == "https://crypto-logo.com/api/logo/bitcoin-btc.png?w=256&h=256"

    def test_get_logo_url_with_bg(self) -> None:
        client = CryptoLogo()
        url = client.get_logo_url("bitcoin-btc", "png", width=1200, height=630, bg="FFFFFF")
        assert "bg=FFFFFF" in url

    def test_get_cdn_url_png(self) -> None:
        client = CryptoLogo()
        url = client.get_cdn_url("bitcoin-btc", "png", 128)
        assert url == "https://cdn.crypto-logo.com/logos/bitcoin-btc/128x128/transparent.png"

    def test_get_cdn_url_svg(self) -> None:
        client = CryptoLogo()
        url = client.get_cdn_url("bitcoin-btc", "svg")
        assert url == "https://cdn.crypto-logo.com/logos/bitcoin-btc/vector.svg"

    def test_invalid_format(self) -> None:
        client = CryptoLogo()
        with pytest.raises(ValueError, match="Unsupported format"):
            client.get_logo("bitcoin-btc", "bmp")

    def test_raster_requires_width(self) -> None:
        client = CryptoLogo()
        with pytest.raises(ValueError, match="Width is required"):
            client.get_logo("bitcoin-btc", "png")


class TestConstants:
    def test_all_formats(self) -> None:
        assert "svg" in ALL_FORMATS
        assert "png" in ALL_FORMATS
        assert "webp" in ALL_FORMATS

    def test_allowed_sizes(self) -> None:
        assert 128 in ALLOWED_SIZES
        assert 512 in ALLOWED_SIZES
        assert 2000 in ALLOWED_SIZES

    def test_ico_sizes(self) -> None:
        assert 32 in ICO_SIZES
        assert 256 in ICO_SIZES
