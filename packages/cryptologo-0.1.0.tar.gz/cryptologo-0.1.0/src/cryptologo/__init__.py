"""cryptologo — Python client for crypto-logo.com cryptocurrency logo API.

Fetch, download, and generate URLs for 413+ cryptocurrency logos in SVG, PNG,
WebP, JPEG, and ICO formats. Zero dependencies (stdlib urllib only).

Usage::

    from cryptologo import CryptoLogo

    client = CryptoLogo()
    coins = client.list_coins()
    logo_bytes = client.get_logo("bitcoin-btc", "svg")
    client.download_logo("ethereum-eth", "png", "eth-logo.png", width=512)
"""

from cryptologo.client import CryptoLogo
from cryptologo.types import Coin

__all__ = ["CryptoLogo", "Coin"]
__version__ = "0.1.0"
