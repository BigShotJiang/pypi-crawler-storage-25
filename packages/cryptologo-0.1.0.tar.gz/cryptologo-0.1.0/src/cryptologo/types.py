"""Type definitions for the CryptoLogo API client."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class Coin:
    """A cryptocurrency coin with logo availability metadata.

    Attributes:
        name: Display name (e.g., "Bitcoin").
        ticker: Trading symbol (e.g., "BTC").
        slug: URL-safe identifier (e.g., "bitcoin-btc").
        has_png: Whether a PNG logo is available.
        has_svg: Whether an SVG logo is available.
        search_terms: Localized names for search (Korean, Japanese, etc.).
        market_cap_rank: CoinGecko market cap ranking (None if unranked).
    """

    name: str
    ticker: str
    slug: str
    has_png: bool = False
    has_svg: bool = False
    search_terms: list[str] = field(default_factory=list)
    market_cap_rank: int | None = None

    @classmethod
    def from_dict(cls, data: dict[str, object]) -> Coin:
        """Create a Coin from the API JSON response dict."""
        return cls(
            name=str(data.get("name", "")),
            ticker=str(data.get("ticker", "")),
            slug=str(data.get("slug", "")),
            has_png=bool(data.get("has_png", False)),
            has_svg=bool(data.get("has_svg", False)),
            search_terms=list(data.get("search_terms", [])),  # type: ignore[arg-type]
            market_cap_rank=data.get("market_cap_rank") if data.get("market_cap_rank") is not None else None,  # type: ignore[arg-type]
        )


# Supported raster formats for logo downloads
RASTER_FORMATS = ("png", "webp", "jpeg", "ico")

# Supported vector formats
VECTOR_FORMATS = ("svg",)

# All supported formats
ALL_FORMATS = RASTER_FORMATS + VECTOR_FORMATS

# Standard logo sizes (square, in pixels)
ALLOWED_SIZES = (16, 32, 48, 64, 96, 120, 128, 200, 256, 400, 512, 1024, 2000)

# ICO-specific sizes
ICO_SIZES = (16, 32, 48, 64, 128, 256)
