"""CryptoLogo API client — zero dependencies (stdlib urllib only)."""

from __future__ import annotations

import json
import urllib.request
from pathlib import Path
from typing import Any

from cryptologo.types import ALL_FORMATS, ALLOWED_SIZES, ICO_SIZES, Coin


class CryptoLogoError(Exception):
    """Base exception for CryptoLogo client errors."""


class NotFoundError(CryptoLogoError):
    """Raised when a coin or logo is not found (HTTP 404)."""


class CryptoLogo:
    """Client for the crypto-logo.com API.

    Provides methods to list coins, fetch logos, generate logo URLs,
    and download logo files. No API key required.

    Args:
        base_url: API base URL. Defaults to ``https://crypto-logo.com``.
        timeout: Request timeout in seconds. Defaults to 30.

    Example::

        client = CryptoLogo()

        # List all coins
        coins = client.list_coins()
        for coin in coins[:5]:
            print(f"{coin.name} ({coin.ticker}) — rank #{coin.market_cap_rank}")

        # Get logo bytes
        svg_data = client.get_logo("bitcoin-btc", "svg")

        # Download to file
        client.download_logo("ethereum-eth", "png", "eth.png", width=256)
    """

    def __init__(
        self,
        base_url: str = "https://crypto-logo.com",
        timeout: int = 30,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    def list_coins(self) -> list[Coin]:
        """Fetch all active coins from the API.

        Returns:
            List of Coin objects sorted by market cap rank.

        Example::

            coins = client.list_coins()
            bitcoin = next(c for c in coins if c.ticker == "BTC")
            print(f"{bitcoin.name}: rank #{bitcoin.market_cap_rank}")
        """
        data = self._get_json("/api/coins.json")
        if not isinstance(data, list):
            raise CryptoLogoError("Unexpected response format")
        return [Coin.from_dict(item) for item in data]

    def get_logo(
        self,
        slug: str,
        fmt: str = "svg",
        *,
        width: int | None = None,
        height: int | None = None,
        bg: str | None = None,
    ) -> bytes:
        """Fetch logo image bytes from the API.

        Args:
            slug: Coin slug (e.g., "bitcoin-btc").
            fmt: Image format — "svg", "png", "webp", "jpeg", or "ico".
            width: Output width in pixels (required for raster formats).
            height: Output height in pixels (defaults to width for square).
            bg: Background hex color without # (e.g., "FFFFFF").

        Returns:
            Raw image bytes.

        Raises:
            NotFoundError: If the coin or requested derivative is not found.
            ValueError: If the format or size is invalid.

        Example::

            # SVG (no size needed)
            svg = client.get_logo("bitcoin-btc", "svg")

            # PNG at 256x256
            png = client.get_logo("bitcoin-btc", "png", width=256)

            # OG image with white background
            og = client.get_logo("bitcoin-btc", "png", width=1200, height=630, bg="FFFFFF")
        """
        fmt = fmt.lower()
        if fmt not in ALL_FORMATS:
            raise ValueError(f"Unsupported format: {fmt}. Use one of: {', '.join(ALL_FORMATS)}")

        if fmt != "svg" and width is None:
            raise ValueError("Width is required for raster formats. Use one of: " + ", ".join(str(s) for s in ALLOWED_SIZES))

        if fmt == "ico" and width is not None and width not in ICO_SIZES:
            raise ValueError(f"ICO size must be one of: {', '.join(str(s) for s in ICO_SIZES)}")

        if fmt != "svg" and width is not None and height is None:
            height = width

        url = self.get_logo_url(slug, fmt, width=width, height=height, bg=bg)
        return self._get_bytes(url)

    def get_logo_url(
        self,
        slug: str,
        fmt: str = "svg",
        *,
        width: int | None = None,
        height: int | None = None,
        bg: str | None = None,
    ) -> str:
        """Build the API URL for a logo.

        Args:
            slug: Coin slug (e.g., "bitcoin-btc").
            fmt: Image format.
            width: Output width in pixels.
            height: Output height in pixels.
            bg: Background hex color without #.

        Returns:
            Full API URL string.

        Example::

            url = client.get_logo_url("bitcoin-btc", "png", width=512)
            # https://crypto-logo.com/api/logo/bitcoin-btc.png?w=512&h=512
        """
        url = f"{self.base_url}/api/logo/{slug}.{fmt}"
        params: list[str] = []
        if width is not None:
            params.append(f"w={width}")
        if height is not None:
            params.append(f"h={height}")
        if bg:
            params.append(f"bg={bg}")
        if params:
            url += "?" + "&".join(params)
        return url

    def get_cdn_url(
        self,
        slug: str,
        fmt: str = "png",
        width: int = 128,
        *,
        cdn_domain: str = "cdn.crypto-logo.com",
    ) -> str:
        """Build a CDN URL for direct image embedding (faster than API).

        The CDN serves pre-generated derivatives without going through Django.
        Use this for ``<img>`` tags and other display contexts.

        Args:
            slug: Coin slug.
            fmt: Image format ("png", "webp", "jpeg", "svg").
            width: Square size in pixels.
            cdn_domain: CDN hostname.

        Returns:
            CDN URL string.

        Example::

            url = client.get_cdn_url("bitcoin-btc", "webp", 128)
            # https://cdn.crypto-logo.com/logos/bitcoin-btc/128x128/transparent.webp
        """
        if fmt == "svg":
            return f"https://{cdn_domain}/logos/{slug}/vector.svg"
        return f"https://{cdn_domain}/logos/{slug}/{width}x{width}/transparent.{fmt}"

    def download_logo(
        self,
        slug: str,
        fmt: str = "svg",
        dest: str | Path | None = None,
        *,
        width: int | None = None,
        height: int | None = None,
        bg: str | None = None,
    ) -> Path:
        """Download a logo to a local file.

        Args:
            slug: Coin slug (e.g., "bitcoin-btc").
            fmt: Image format.
            dest: Destination file path. Auto-generated if None.
            width: Output width in pixels.
            height: Output height in pixels.
            bg: Background hex color without #.

        Returns:
            Path to the downloaded file.

        Example::

            path = client.download_logo("bitcoin-btc", "svg")
            print(f"Saved to {path}")  # bitcoin-btc.svg

            path = client.download_logo("ethereum-eth", "png", width=512)
            print(f"Saved to {path}")  # ethereum-eth-512x512.png
        """
        data = self.get_logo(slug, fmt, width=width, height=height, bg=bg)

        if dest is None:
            if fmt == "svg":
                dest = Path(f"{slug}.svg")
            elif width and height and width != height:
                dest = Path(f"{slug}-{width}x{height}.{fmt}")
            elif width:
                dest = Path(f"{slug}-{width}x{width}.{fmt}")
            else:
                dest = Path(f"{slug}.{fmt}")
        else:
            dest = Path(dest)

        dest.write_bytes(data)
        return dest

    def get_asset(self, file_path: str) -> bytes:
        """Fetch an asset file (variant or historical logo).

        Args:
            file_path: Relative path within assets/ (e.g., "versions/bitcoin-btc-full.svg").

        Returns:
            Raw file bytes.

        Example::

            # Get a logo variant
            data = client.get_asset("versions/bitcoin-btc-full.svg")

            # Get a historical logo
            data = client.get_asset("history/bitcoin-btc-2009.png")
        """
        url = f"{self.base_url}/api/asset/{file_path}"
        return self._get_bytes(url)

    # -- internal helpers --

    def _get_json(self, path: str) -> Any:
        """GET JSON from relative path."""
        url = f"{self.base_url}{path}" if path.startswith("/") else path
        req = urllib.request.Request(url, headers={"Accept": "application/json", "User-Agent": "cryptologo-python/0.1.0"})
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                return json.loads(resp.read().decode())
        except urllib.error.HTTPError as e:
            if e.code == 404:
                raise NotFoundError(f"Not found: {url}") from None
            raise CryptoLogoError(f"HTTP {e.code}: {url}") from e

    def _get_bytes(self, url: str) -> bytes:
        """GET binary data from full or relative URL."""
        if url.startswith("/"):
            url = f"{self.base_url}{url}"
        req = urllib.request.Request(url, headers={"User-Agent": "cryptologo-python/0.1.0"})
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                return resp.read()  # type: ignore[no-any-return]
        except urllib.error.HTTPError as e:
            if e.code == 404:
                raise NotFoundError(f"Not found: {url}") from None
            raise CryptoLogoError(f"HTTP {e.code}: {url}") from e


__all__ = ["CryptoLogo", "CryptoLogoError", "NotFoundError"]
