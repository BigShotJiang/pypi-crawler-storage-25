#!/usr/bin/env python
"""
Unit tests for MediCafe.cloud_readiness.
Tests evidence selection, run_phase_f_manual, run_phase_f_manual_for_run_id, is_pipeline_running.
"""
from __future__ import print_function

import json
import os
import sqlite3
import sys
import tempfile
import time
import unittest

try:
    from unittest.mock import patch, MagicMock
except ImportError:
    from mock import patch, MagicMock  # pyright: ignore[reportMissingModuleSource]

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)


def _make_lab():
    """Create temp lab dir with reports."""
    lab_root = tempfile.mkdtemp()
    reports_dir = os.path.join(lab_root, 'reports')
    os.makedirs(reports_dir, exist_ok=True)
    return lab_root, reports_dir




class TestLabRootResolution(unittest.TestCase):
    """resolve_lab_root and invalid-root diagnostics."""

    def test_resolve_lab_root_strips_wrapping_quotes(self):
        from MediCafe.cloud_readiness import resolve_lab_root
        with patch.dict('os.environ', {'MEDICAFE_LAB_DIR': '"./lab"'}, clear=False):
            got = resolve_lab_root('/repo')
        self.assertEqual(got, os.path.abspath('./lab'))

    def test_resolve_lab_root_quoted_empty_falls_back_to_repo_lab(self):
        """Quoted empty MEDICAFE_LAB_DIR (e.g. "") must fall back to repo_root/lab, not cwd."""
        from MediCafe.cloud_readiness import resolve_lab_root
        with patch.dict('os.environ', {'MEDICAFE_LAB_DIR': '""'}, clear=False):
            got = resolve_lab_root('/repo')
        self.assertEqual(got, os.path.join('/repo', 'lab'))
        with patch.dict('os.environ', {'MEDICAFE_LAB_DIR': "''"}, clear=False):
            got = resolve_lab_root('/repo')
        self.assertEqual(got, os.path.join('/repo', 'lab'))

    def test_resolve_lab_root_quoted_empty_never_uses_cwd(self):
        from MediCafe.cloud_readiness import resolve_lab_root
        orig = os.getcwd()
        temp = tempfile.mkdtemp()
        try:
            os.chdir(temp)
            with patch.dict('os.environ', {'MEDICAFE_LAB_DIR': '""'}, clear=False):
                got = resolve_lab_root('/repo')
            self.assertEqual(got, os.path.join('/repo', 'lab'))
            self.assertNotEqual(got, os.path.abspath(''))
        finally:
            os.chdir(orig)
            import shutil
            shutil.rmtree(temp, ignore_errors=True)

    def test_resolve_lab_root_auto_heals_malformed_windows_prefix(self):
        from MediCafe.cloud_readiness import resolve_lab_root
        bad = 'C: C:\\Python34\\Lib\\site-packages\\lab'
        with patch.dict('os.environ', {'MEDICAFE_LAB_DIR': bad}, clear=False):
            got = resolve_lab_root('/repo')
        self.assertEqual(got, os.path.normpath('C:\\Python34\\Lib\\site-packages\\lab'))

    def test_resolve_lab_root_keeps_windows_absolute_path(self):
        from MediCafe.cloud_readiness import resolve_lab_root
        with patch.dict('os.environ', {'MEDICAFE_LAB_DIR': 'C:/Python34/Lib/site-packages/lab'}, clear=False):
            got = resolve_lab_root('/repo')
        self.assertEqual(got, os.path.normpath('C:/Python34/Lib/site-packages/lab'))

    def test_resolve_lab_root_site_packages_auto_appends_lab(self):
        from MediCafe.cloud_readiness import resolve_lab_root
        with patch.dict('os.environ', {'MEDICAFE_LAB_DIR': 'C:/Python34/Lib/site-packages'}, clear=False):
            got = resolve_lab_root('/repo')
        self.assertEqual(got, os.path.normpath('C:/Python34/Lib/site-packages/lab'))

    def test_resolve_lab_root_windows_backslash_medicafe_auto_appends_lab(self):
        from MediCafe.cloud_readiness import resolve_lab_root
        with patch.dict('os.environ', {'MEDICAFE_LAB_DIR': r'C:\Python34\Lib\site-packages\MediCafe'}, clear=False):
            got = resolve_lab_root('/repo')
        self.assertEqual(got, os.path.normpath(r'C:\Python34\Lib\site-packages\MediCafe/lab'))

    def test_resolve_lab_root_medicafe_site_packages_auto_appends_lab(self):
        from MediCafe.cloud_readiness import resolve_lab_root
        with patch.dict('os.environ', {'MEDICAFE_LAB_DIR': 'C:/Python34/Lib/site-packages/MediCafe'}, clear=False):
            got = resolve_lab_root('/repo')
        self.assertEqual(got, os.path.normpath('C:/Python34/Lib/site-packages/MediCafe/lab'))

    def test_invalid_lab_root_message_includes_env_details(self):
        from MediCafe.cloud_readiness import _collect_health_diagnostics
        with patch.dict('os.environ', {'MEDICAFE_LAB_DIR': '"C:/missing/lab"'}, clear=False):
            diagnostics = _collect_health_diagnostics('C:/missing/lab', auto_resolve=True)
        issue = diagnostics['issues'][0]
        self.assertEqual(issue['code'], 'LAB_ROOT_NOT_FOUND')
        self.assertIn('MEDICAFE_LAB_DIR(raw)', issue['message'])

class TestCollectHealthDiagnostics(unittest.TestCase):
    """_collect_health_diagnostics state-file handling."""

    def test_seeds_missing_diagnostics_state_when_auto_resolve_enabled(self):
        from MediCafe.cloud_readiness import _collect_health_diagnostics
        lab_root, _ = _make_lab()
        try:
            state_path = os.path.join(lab_root, 'diagnostics_state.json')
            self.assertFalse(os.path.exists(state_path))
            diagnostics = _collect_health_diagnostics(lab_root, auto_resolve=True)
            self.assertEqual(diagnostics['severity'], 'warn')
            issue_codes = [i.get('code') for i in diagnostics['issues']]
            self.assertNotIn('DIAGNOSTICS_STATE_MISSING', issue_codes)
            self.assertTrue(os.path.exists(state_path))
            self.assertTrue(any('Seeded missing diagnostics_state.json' in msg for msg in diagnostics['auto_resolved']))
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_reports_missing_diagnostics_state_when_auto_resolve_disabled(self):
        from MediCafe.cloud_readiness import _collect_health_diagnostics
        lab_root, _ = _make_lab()
        try:
            diagnostics = _collect_health_diagnostics(lab_root, auto_resolve=False)
            self.assertEqual(diagnostics['severity'], 'warn')
            self.assertEqual(len(diagnostics['issues']), 1)
            self.assertEqual(diagnostics['issues'][0]['code'], 'DIAGNOSTICS_STATE_MISSING')
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_phase_not_run_checks_use_v2_phase_run_ids(self):
        from MediCafe.cloud_readiness import _collect_health_diagnostics
        lab_root, _ = _make_lab()
        try:
            state_path = os.path.join(lab_root, 'diagnostics_state.json')
            with open(state_path, 'w', encoding='utf-8') as f:
                json.dump({
                    'last_shadow_pipeline_phase_run_ids': {
                        'B': '20260218-010000-11111111',
                        'C': '20260218-010001-22222222',
                        'D': '20260218-010002-33333333',
                        'E': '20260218-010003-44444444',
                    },
                    'last_shadow_pipeline_run_id': '20260218-010010-55555555',
                }, f, indent=2)
            diagnostics = _collect_health_diagnostics(lab_root, auto_resolve=True)
            issue_codes = [i.get('code') for i in diagnostics.get('issues', [])]
            self.assertNotIn('PHASE_B_NOT_RUN', issue_codes)
            self.assertNotIn('PHASE_C_NOT_RUN', issue_codes)
            self.assertNotIn('PHASE_D_NOT_RUN', issue_codes)
            self.assertNotIn('PHASE_E_NOT_RUN', issue_codes)
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_phase_not_run_checks_skip_pending_transitional_phases(self):
        from MediCafe.cloud_readiness import _collect_health_diagnostics
        lab_root, _ = _make_lab()
        try:
            state_path = os.path.join(lab_root, 'diagnostics_state.json')
            with open(state_path, 'w', encoding='utf-8') as f:
                json.dump({
                    'pipeline_state': 'running',
                    'active_phase': 'C',
                    'active_run_id': '20260218-010010-55555555',
                    'last_shadow_pipeline_run_id': '20260218-010010-55555555',
                    'last_shadow_pipeline_phase_run_ids': {
                        'B': '20260218-010000-11111111',
                    },
                }, f, indent=2)
            diagnostics = _collect_health_diagnostics(lab_root, auto_resolve=True)
            issue_codes = [i.get('code') for i in diagnostics.get('issues', [])]
            self.assertNotIn('PHASE_C_NOT_RUN', issue_codes)
            self.assertNotIn('PHASE_D_NOT_RUN', issue_codes)
            self.assertNotIn('PHASE_E_NOT_RUN', issue_codes)
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_phase_d_invalid_external_id_skips_surface_elevated(self):
        from MediCafe.cloud_readiness import _collect_health_diagnostics
        lab_root, _ = _make_lab()
        try:
            state_path = os.path.join(lab_root, 'diagnostics_state.json')
            with open(state_path, 'w', encoding='utf-8') as f:
                json.dump({
                    'last_shadow_pipeline_phase_run_ids': {
                        'B': 'x', 'C': 'x', 'D': 'x', 'E': 'x',
                    },
                    'last_phase_d_pass_count': 10,
                    'last_phase_d_constraint_skip_counts': {'patient_invalid_external_id': 3},
                }, f)
            diagnostics = _collect_health_diagnostics(lab_root, auto_resolve=True)
            codes = [i.get('code') for i in diagnostics.get('issues', [])]
            self.assertIn('PHASE_D_INVALID_EXTERNAL_ID_ELEVATED', codes)
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_phase_d_invalid_external_id_skips_surface_low_ratio(self):
        from MediCafe.cloud_readiness import _collect_health_diagnostics
        lab_root, _ = _make_lab()
        try:
            state_path = os.path.join(lab_root, 'diagnostics_state.json')
            with open(state_path, 'w', encoding='utf-8') as f:
                json.dump({
                    'last_shadow_pipeline_phase_run_ids': {
                        'B': 'x', 'C': 'x', 'D': 'x', 'E': 'x',
                    },
                    'last_phase_d_pass_count': 1000,
                    'last_phase_d_constraint_skip_counts': {'patient_invalid_external_id': 1},
                }, f)
            diagnostics = _collect_health_diagnostics(lab_root, auto_resolve=True)
            codes = [i.get('code') for i in diagnostics.get('issues', [])]
            self.assertIn('PHASE_D_INVALID_EXTERNAL_ID_SKIPS_PRESENT', codes)
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)


class TestFindLatestRunIdByPrefix(unittest.TestCase):
    """_find_latest_run_id_by_prefix and _select_latest_evidence_files."""

    def test_single_run_returns_run_id(self):
        from MediCafe.cloud_readiness import _find_latest_run_id_by_prefix
        lab_root, reports_dir = _make_lab()
        try:
            rid = '20250216-120000-abc12345'
            path = os.path.join(reports_dir, 'artifact_discovery_summary_{0}.json'.format(rid))
            with open(path, 'w') as f:
                f.write('{}')
            run_id, p = _find_latest_run_id_by_prefix(reports_dir, 'artifact_discovery_summary_', ('.json', '.txt'))
            self.assertEqual(run_id, rid)
            self.assertEqual(p, path)
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_multi_run_picks_latest_by_mtime(self):
        from MediCafe.cloud_readiness import _find_latest_run_id_by_prefix
        lab_root, reports_dir = _make_lab()
        try:
            r1 = os.path.join(reports_dir, 'artifact_discovery_summary_20250216-120000-aaa11111.json')
            r2 = os.path.join(reports_dir, 'artifact_discovery_summary_20250216-120500-bbb22222.json')
            with open(r1, 'w') as f:
                f.write('{}')
            with open(r2, 'w') as f:
                f.write('{}')
            os.utime(r1, (1000, 1000))
            os.utime(r2, (2000, 2000))
            run_id, p = _find_latest_run_id_by_prefix(reports_dir, 'artifact_discovery_summary_', ('.json', '.txt'))
            self.assertEqual(run_id, '20250216-120500-bbb22222')
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_empty_dir_returns_none(self):
        from MediCafe.cloud_readiness import _find_latest_run_id_by_prefix
        lab_root, reports_dir = _make_lab()
        try:
            run_id, p = _find_latest_run_id_by_prefix(reports_dir, 'artifact_discovery_summary_', ('.json', '.txt'))
            self.assertIsNone(run_id)
            self.assertIsNone(p)
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)


class TestSelectLatestEvidenceFiles(unittest.TestCase):
    """_select_latest_evidence_files."""

    def test_single_file(self):
        from MediCafe.cloud_readiness import _select_latest_evidence_files
        lab_root, reports_dir = _make_lab()
        try:
            rid = '20250216-120000-abc12345'
            with open(os.path.join(reports_dir, 'artifact_discovery_summary_{0}.json'.format(rid)), 'w') as f:
                f.write('{}')
            files = _select_latest_evidence_files(lab_root, [('artifact_discovery_summary_', None)])
            self.assertEqual(len(files), 1)
            self.assertIn('artifact_discovery_summary_{0}.json'.format(rid), files[0][0])
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_both_formats_attached(self):
        from MediCafe.cloud_readiness import _select_latest_evidence_files
        lab_root, reports_dir = _make_lab()
        try:
            rid = '20250216-120000-abc12345'
            with open(os.path.join(reports_dir, 'artifact_discovery_summary_{0}.json'.format(rid)), 'w') as f:
                f.write('{}')
            with open(os.path.join(reports_dir, 'artifact_discovery_summary_{0}.txt'.format(rid)), 'w') as f:
                f.write('txt')
            files = _select_latest_evidence_files(lab_root, [('artifact_discovery_summary_', None)])
            basenames = [f[0] for f in files]
            # One canonical file per logical group (.json vs .txt); avoid duplicate attachments.
            self.assertEqual(len(basenames), 1)
            self.assertIn(
                basenames[0],
                (
                    'artifact_discovery_summary_{0}.json'.format(rid),
                    'artifact_discovery_summary_{0}.txt'.format(rid),
                ),
            )
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_companion_same_run(self):
        from MediCafe.cloud_readiness import _select_latest_evidence_files
        lab_root, reports_dir = _make_lab()
        try:
            rid = '20250216-120000-abc12345'
            with open(os.path.join(reports_dir, 'ingest_write_summary_{0}.json'.format(rid)), 'w') as f:
                f.write('{}')
            with open(os.path.join(reports_dir, 'ingest_write_anomalies_{0}.jsonl'.format(rid)), 'w') as f:
                f.write('[]')
            files = _select_latest_evidence_files(lab_root, [
                ('ingest_write_summary_', None),
                ('ingest_write_anomalies_', '.jsonl'),
            ])
            basenames = [f[0] for f in files]
            self.assertIn('ingest_write_summary_{0}.json'.format(rid), basenames)
            self.assertIn('ingest_write_anomalies_{0}.jsonl'.format(rid), basenames)
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_companion_missing(self):
        from MediCafe.cloud_readiness import _select_latest_evidence_files
        lab_root, reports_dir = _make_lab()
        try:
            rid = '20250216-120000-abc12345'
            with open(os.path.join(reports_dir, 'ingest_write_summary_{0}.json'.format(rid)), 'w') as f:
                f.write('{}')
            files = _select_latest_evidence_files(lab_root, [
                ('ingest_write_summary_', None),
                ('ingest_write_anomalies_', '.jsonl'),
            ])
            basenames = [f[0] for f in files]
            self.assertIn('ingest_write_summary_{0}.json'.format(rid), basenames)
            self.assertFalse(any('ingest_write_anomalies_' in b for b in basenames))
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)


class TestRunPhaseFManual(unittest.TestCase):
    """run_phase_f_manual and run_phase_f_manual_for_run_id."""

    def test_run_phase_f_manual_no_pipeline_run_id(self):
        from MediCafe.cloud_readiness import run_phase_f_manual
        with patch('MediCafe.cloud_readiness.subprocess.Popen') as mock_popen:
            with patch('MediCafe.cloud_readiness.ensure_lab_ready', return_value=(True, '', None)) as mock_ready:
                with patch('MediCafe.cloud_readiness.is_pipeline_running', return_value=False):
                    with patch('os.path.exists', return_value=True):
                        ok, msg, running = run_phase_f_manual('/repo', '/py', {})
            self.assertTrue(ok)
            mock_ready.assert_called_once()
            mock_popen.assert_called_once()
            call_args = mock_popen.call_args[0][0]
            self.assertNotIn('--pipeline-run-id', call_args)

    def test_run_phase_f_manual_blocks_when_bootstrap_not_ready(self):
        from MediCafe.cloud_readiness import run_phase_f_manual
        with patch('MediCafe.cloud_readiness.ensure_lab_ready', return_value=(False, 'bootstrap failed', None)):
            with patch('MediCafe.cloud_readiness.subprocess.Popen') as mock_popen:
                with patch('os.path.exists', return_value=True):
                    ok, msg, running = run_phase_f_manual('/repo', '/py', {})
        self.assertFalse(ok)
        self.assertIn('bootstrap failed', msg)
        self.assertIsNone(running)
        mock_popen.assert_not_called()

    def test_run_phase_f_manual_for_run_id_passes_exact_run_id(self):
        from MediCafe.cloud_readiness import run_phase_f_manual_for_run_id
        with patch('MediCafe.cloud_readiness.subprocess.Popen') as mock_popen:
            with patch('MediCafe.cloud_readiness.ensure_lab_ready', return_value=(True, '', None)) as mock_ready:
                with patch('MediCafe.cloud_readiness.resolve_lab_root', return_value='/lab'):
                    with patch('os.path.exists', return_value=True):
                        ok, msg, _ = run_phase_f_manual_for_run_id('/repo', '/py', {}, '20250216-120000-abc12345')
            self.assertTrue(ok)
            mock_ready.assert_called_once()
            mock_popen.assert_called_once()
            call_args = mock_popen.call_args[0][0]
            self.assertIn('--pipeline-run-id', call_args)
            idx = call_args.index('--pipeline-run-id')
            self.assertEqual(call_args[idx + 1], '20250216-120000-abc12345')



    def test_run_phase_f_manual_uses_resolved_script_root(self):
        from MediCafe.cloud_readiness import run_phase_f_manual
        repo = tempfile.mkdtemp()
        try:
            nested_repo = os.path.join(repo, 'MediCafe')
            os.makedirs(nested_repo, exist_ok=True)
            script_dir = os.path.join(repo, 'scripts', 'unified_model')
            os.makedirs(script_dir, exist_ok=True)
            with open(os.path.join(script_dir, 'package_shadow_run_report.py'), 'w', encoding='utf-8') as f:
                f.write('# stub\n')
            with patch('MediCafe.cloud_readiness.subprocess.Popen') as mock_popen:
                with patch('MediCafe.cloud_readiness.ensure_lab_ready', return_value=(True, '', None)):
                    with patch('MediCafe.cloud_readiness.is_pipeline_running', return_value=False):
                        ok, msg, _ = run_phase_f_manual(nested_repo, '/py', {})
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            _, kwargs = mock_popen.call_args
            self.assertEqual(kwargs.get('cwd'), repo)
        finally:
            import shutil
            shutil.rmtree(repo, ignore_errors=True)

    def test_run_phase_f_manual_missing_reports_checked_paths(self):
        from MediCafe.cloud_readiness import run_phase_f_manual
        fake_path = '/repo/scripts/unified_model/package_shadow_run_report.py'
        fake_checks = [{'script_path': fake_path}]
        with patch('MediCafe.cloud_readiness.shadow_orchestrator._find_unified_model_script', return_value=('/repo', fake_path, fake_checks)):
            ok, msg, _ = run_phase_f_manual('/repo', '/py', {})
        self.assertFalse(ok)
        self.assertIn('package_shadow_run_report.py not found. checked:', msg)



    def test_run_phase_b_manual_missing_reports_checked_paths(self):
        from MediCafe.cloud_readiness import run_phase_b_manual
        fake_path = '/repo/scripts/unified_model/discover_artifacts.py'
        fake_checks = [{'script_path': fake_path}]
        with patch('MediCafe.cloud_readiness.shadow_orchestrator._find_unified_model_script', return_value=('/repo', fake_path, fake_checks)):
            ok, msg, _ = run_phase_b_manual('/repo', '/py', {})
        self.assertFalse(ok)
        self.assertIn('discover_artifacts.py not found. checked:', msg)

    def test_run_phase_d_manual_missing_reports_checked_paths(self):
        from MediCafe.cloud_readiness import run_phase_d_manual
        fake_path = '/repo/scripts/unified_model/run_qa_canonical.py'
        fake_checks = [{'script_path': fake_path}]
        with patch('MediCafe.cloud_readiness.shadow_orchestrator._find_unified_model_script', return_value=('/repo', fake_path, fake_checks)):
            ok, msg, _ = run_phase_d_manual('/repo', '/py', {})
        self.assertFalse(ok)
        self.assertIn('run_qa_canonical.py not found. checked:', msg)

    def test_run_phase_b_manual_uses_resolved_script_root(self):
        from MediCafe.cloud_readiness import run_phase_b_manual
        repo = tempfile.mkdtemp()
        try:
            nested_repo = os.path.join(repo, 'MediCafe')
            os.makedirs(nested_repo, exist_ok=True)
            script_dir = os.path.join(repo, 'scripts', 'unified_model')
            os.makedirs(script_dir, exist_ok=True)
            with open(os.path.join(script_dir, 'discover_artifacts.py'), 'w', encoding='utf-8') as f:
                f.write('# stub\n')
            with patch('MediCafe.cloud_readiness.subprocess.Popen') as mock_popen:
                ok, msg, _ = run_phase_b_manual(nested_repo, '/py', {})
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            _, kwargs = mock_popen.call_args
            self.assertEqual(kwargs.get('cwd'), repo)
        finally:
            import shutil
            shutil.rmtree(repo, ignore_errors=True)

    def test_find_unified_model_script_uses_package_repo_root_fallback(self):
        from MediCafe import shadow_orchestrator
        repo = tempfile.mkdtemp()
        try:
            package_dir = os.path.join(repo, 'MediCafe')
            script_dir = os.path.join(repo, 'scripts', 'unified_model')
            os.makedirs(package_dir, exist_ok=True)
            os.makedirs(script_dir, exist_ok=True)
            script_path = os.path.join(script_dir, 'bootstrap_lab.py')
            with open(script_path, 'w', encoding='utf-8') as f:
                f.write('# stub\n')
            fake_module_path = os.path.join(package_dir, 'shadow_orchestrator.py')
            with patch.object(shadow_orchestrator, '__file__', fake_module_path):
                resolved_root, resolved_script, checks = shadow_orchestrator._find_unified_model_script(
                    '/bad/repo',
                    'bootstrap_lab.py',
                    python_exe='/py',
                )
            self.assertEqual(resolved_root, repo)
            self.assertEqual(resolved_script, script_path)
            self.assertIn(repo, [c.get('candidate_repo_root') for c in checks])
        finally:
            import shutil
            shutil.rmtree(repo, ignore_errors=True)

class TestIsPipelineRunning(unittest.TestCase):
    """is_pipeline_running."""

    def test_lock_absent_returns_false(self):
        from MediCafe.cloud_readiness import is_pipeline_running
        lab_root = tempfile.mkdtemp()
        try:
            self.assertFalse(is_pipeline_running(lab_root))
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_lock_present_pid_dead_returns_false(self):
        from MediCafe.cloud_readiness import is_pipeline_running
        lab_root = tempfile.mkdtemp()
        try:
            lock_path = os.path.join(lab_root, 'shadow_pipeline.lock')
            with open(lock_path, 'w') as f:
                f.write('pid=99999999\nheartbeat_at_utc=2025-02-16T12:00:00Z\n')
            result = is_pipeline_running(lab_root)
            self.assertFalse(result)
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)


class TestSendPhaseEvidenceGating(unittest.TestCase):
    """_send_phase_evidence requires at least one phase artifact."""

    def test_send_phase_evidence_requires_phase_artifact(self):
        from MediCafe.cloud_readiness import _send_phase_evidence
        lab_root, reports_dir = _make_lab()
        try:
            with open(os.path.join(lab_root, 'diagnostics_state.json'), 'w') as f:
                json.dump({}, f)
            with open(os.path.join(lab_root, 'run_cursor.json'), 'w') as f:
                json.dump({}, f)
            with patch('MediCafe.cloud_readiness.collect_support_bundle') as mock_collect:
                ok, msg, _ = _send_phase_evidence(
                    lab_root,
                    [('artifact_discovery_summary_', None)],
                    'phase_b_evidence',
                    'No discovery summaries.',
                )
            self.assertFalse(ok)
            self.assertEqual(msg, 'No discovery summaries.')
            mock_collect.assert_not_called()
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_send_phase_evidence_reports_dir_unreadable_returns_error(self):
        from MediCafe.cloud_readiness import _send_phase_evidence
        lab_root, reports_dir = _make_lab()
        try:
            real_listdir = os.listdir

            def _listdir_side_effect(path):
                if path == reports_dir:
                    raise OSError('denied')
                return real_listdir(path)

            with patch('MediCafe.cloud_readiness.os.listdir', side_effect=_listdir_side_effect):
                with patch('MediCafe.cloud_readiness.collect_support_bundle') as mock_collect:
                    ok, msg, _ = _send_phase_evidence(
                        lab_root,
                        [('artifact_discovery_summary_', None)],
                        'phase_b_evidence',
                        'No discovery summaries.',
                    )
            self.assertFalse(ok)
            self.assertIn('Unable to read reports directory', msg)
            mock_collect.assert_not_called()
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)


class TestSendPhaseEvidenceContextFiles(unittest.TestCase):
    """_send_phase_evidence includes context files."""

    def test_includes_context_files_when_present(self):
        from MediCafe.cloud_readiness import _select_latest_evidence_files, _send_phase_evidence
        lab_root, reports_dir = _make_lab()
        try:
            rid = '20250216-120000-abc12345'
            with open(os.path.join(reports_dir, 'artifact_discovery_summary_{0}.json'.format(rid)), 'w') as f:
                f.write('{}')
            with open(os.path.join(lab_root, 'diagnostics_state.json'), 'w') as f:
                json.dump({'last_shadow_pipeline_run_id': rid}, f)
            with open(os.path.join(lab_root, 'run_cursor.json'), 'w') as f:
                json.dump({}, f)
            with patch('MediCafe.cloud_readiness.collect_support_bundle') as mock_collect:
                with patch('MediCafe.cloud_readiness.submit_support_bundle_email', return_value=True):
                    mock_collect.return_value = '/tmp/bundle.zip'
                    ok, msg, _ = _send_phase_evidence(
                        lab_root,
                        [('artifact_discovery_summary_', None)],
                        'phase_b_evidence',
                        'No discovery summaries.',
                    )
            self.assertTrue(ok)
            extra_files = mock_collect.call_args[1]['extra_files']
            basenames = [f[0] for f in extra_files]
            self.assertIn('diagnostics_state.json', basenames)
            self.assertIn('run_cursor.json', basenames)
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_send_phase_evidence_uses_interactive_reauth_mode(self):
        from MediCafe.cloud_readiness import _send_phase_evidence
        lab_root, reports_dir = _make_lab()
        try:
            rid = '20250216-120000-abc12345'
            with open(os.path.join(reports_dir, 'artifact_discovery_summary_{0}.json'.format(rid)), 'w') as f:
                f.write('{}')
            with patch('MediCafe.cloud_readiness.collect_support_bundle', return_value='/tmp/bundle.zip'):
                with patch('MediCafe.cloud_readiness.submit_support_bundle_email', return_value=False) as mock_submit:
                    ok, msg, _ = _send_phase_evidence(
                        lab_root,
                        [('artifact_discovery_summary_', None)],
                        'phase_b_evidence',
                        'No discovery summaries.',
                    )
            self.assertFalse(ok)
            self.assertTrue(mock_submit.called)
            self.assertEqual(mock_submit.call_args[1].get('skip_interactive_reauth'), False)
            self.assertIn('Report queued or failed', msg)
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_send_phase_evidence_prefers_newest_phase_artifact_mtime_over_diagnostics_lineage(self):
        from MediCafe.cloud_readiness import _send_phase_evidence
        lab_root, reports_dir = _make_lab()
        try:
            rid_old = '20250216-120000-old12345'
            rid_new = '20250216-120100-new12345'
            old_path = os.path.join(reports_dir, 'artifact_discovery_summary_{0}.json'.format(rid_old))
            new_path = os.path.join(reports_dir, 'artifact_discovery_summary_{0}.json'.format(rid_new))
            with open(old_path, 'w') as f:
                f.write('{}')
            with open(new_path, 'w') as f:
                f.write('{}')
            old = time.time() - 120
            new = time.time() - 10
            os.utime(old_path, (old, old))
            os.utime(new_path, (new, new))
            with open(os.path.join(lab_root, 'diagnostics_state.json'), 'w') as f:
                json.dump({'last_shadow_pipeline_run_id': rid_old}, f)
            with patch('MediCafe.cloud_readiness.collect_support_bundle', return_value='/tmp/bundle.zip') as mock_collect:
                with patch('MediCafe.cloud_readiness.submit_support_bundle_email', return_value=True):
                    ok, msg, _ = _send_phase_evidence(
                        lab_root,
                        [('artifact_discovery_summary_', None)],
                        'phase_b_evidence',
                        'No discovery summaries.',
                    )
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            extra_files = mock_collect.call_args[1]['extra_files']
            basenames = [item[0] for item in extra_files]
            self.assertIn('artifact_discovery_summary_{0}.json'.format(rid_new), basenames)
            self.assertNotIn('artifact_discovery_summary_{0}.json'.format(rid_old), basenames)
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)


class TestSendPhaseFEvidenceMismatchFallback(unittest.TestCase):
    """send_phase_f_evidence mismatch-only fallback."""

    def test_send_phase_f_evidence_mismatch_only_fallback(self):
        from MediCafe.cloud_readiness import send_phase_f_evidence
        temp_repo = tempfile.mkdtemp()
        lab_root = os.path.join(temp_repo, 'lab')
        reports_dir = os.path.join(lab_root, 'reports')
        os.makedirs(reports_dir, exist_ok=True)
        try:
            rid = '20250216-120000-abc12345'
            mismatch_path = os.path.join(reports_dir, 'phase_f_mismatch_{0}.txt'.format(rid))
            with open(mismatch_path, 'w') as f:
                f.write('PHASE_F_RUN_ID_MISMATCH\n')
            with open(os.path.join(lab_root, 'diagnostics_state.json'), 'w') as f:
                json.dump({'last_shadow_pipeline_run_id': rid}, f)
            with patch('MediCafe.cloud_readiness.collect_support_bundle') as mock_collect:
                with patch('MediCafe.cloud_readiness.submit_support_bundle_email', return_value=True):
                    with patch('MediCafe.cloud_readiness._submit_bundle_with_delivery_diagnostics', return_value=(True, '', {})):
                        mock_collect.return_value = '/tmp/bundle.zip'
                        ok, msg, _ = send_phase_f_evidence(temp_repo)
            self.assertTrue(ok)
            extra_meta = mock_collect.call_args[1].get('extra_meta', {})
            self.assertEqual(extra_meta.get('run_id'), rid)
            self.assertEqual(extra_meta.get('send_source'), 'manual_phase_f_evidence')
            extra_files = mock_collect.call_args[1]['extra_files']
            basenames = [f[0] for f in extra_files]
            self.assertIn('phase_f_mismatch_{0}.txt'.format(rid), basenames)
            self.assertIn('diagnostics_state.json', basenames)
        finally:
            import shutil
            shutil.rmtree(temp_repo, ignore_errors=True)

    def test_send_phase_f_evidence_reports_dir_unreadable_returns_error(self):
        from MediCafe.cloud_readiness import send_phase_f_evidence
        temp_repo = tempfile.mkdtemp()
        lab_root = os.path.join(temp_repo, 'lab')
        reports_dir = os.path.join(lab_root, 'reports')
        os.makedirs(reports_dir, exist_ok=True)
        try:
            real_listdir = os.listdir

            def _listdir_side_effect(path):
                if path == reports_dir:
                    raise OSError('denied')
                return real_listdir(path)

            with patch('MediCafe.cloud_readiness.os.listdir', side_effect=_listdir_side_effect):
                with patch('MediCafe.cloud_readiness.collect_support_bundle') as mock_collect:
                    with patch('MediCafe.cloud_readiness.submit_support_bundle_email', return_value=True):
                        ok, msg, _ = send_phase_f_evidence(temp_repo)
            self.assertFalse(ok)
            self.assertIn('Unable to read reports directory', msg)
            mock_collect.assert_not_called()
        finally:
            import shutil
            shutil.rmtree(temp_repo, ignore_errors=True)


class TestEnsureLabReady(unittest.TestCase):
    """ensure_lab_ready gate before Cloud Readiness UI."""

    def test_skips_when_lab_exists_with_core_artifacts(self):
        from MediCafe.cloud_readiness import ensure_lab_ready
        lab_root, _ = _make_lab()
        try:
            with open(os.path.join(lab_root, 'unified_model_xp.db'), 'wb') as f:
                f.write(b'')
            with open(os.path.join(lab_root, 'run_cursor.json'), 'w') as f:
                f.write('{}')
            env_flag = lambda name, default: True if name == 'MEDICAFE_PHASE_A_AUTO_VALIDATE' else default
            with patch('MediCafe.cloud_readiness.resolve_lab_root', return_value=lab_root):
                with patch('MediCafe.cloud_readiness.subprocess.call') as mock_call:
                    ok, msg, _ = ensure_lab_ready('/repo', '/py', {}, env_flag)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            mock_call.assert_not_called()
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_bootstraps_when_lab_missing(self):
        from MediCafe import cloud_readiness as cr
        nonexistent_lab = os.path.join(tempfile.gettempdir(), 'medicafe_test_nonexistent_lab_12345')
        env_flag = lambda name, default: True if name == 'MEDICAFE_PHASE_A_AUTO_VALIDATE' else default
        baseline_result = {
            "status": "STARTED_NEW",
            "error_code": "",
            "message": "",
            "payload": {},
        }
        pipeline_result = {
            "status": "STARTED_NEW",
            "error_code": "",
            "message": "Initialization in progress.",
            "payload": {},
        }
        with patch('MediCafe.cloud_readiness.resolve_lab_root', return_value=nonexistent_lab):
            with patch('MediCafe.cloud_readiness._probe_lab_root', return_value={'is_dir': False, 'has_core_artifacts': False, 'pipeline_running': False}):
                with patch('MediCafe.cloud_readiness._lab_has_core_artifacts', return_value=False):
                    with patch('MediCafe.cloud_readiness.shadow_orchestrator.start_or_attach_shadow_pipeline') as mock_start:
                        mock_start.side_effect = [baseline_result, pipeline_result]
                        ok, msg, _ = cr.ensure_lab_ready('/repo', '/py', {}, env_flag)
        self.assertTrue(ok)
        self.assertEqual(msg, 'Initialization in progress.')
        self.assertEqual(mock_start.call_count, 2)

    def test_missing_lab_transitions_from_baseline_to_pipeline_start_attach(self):
        from MediCafe import cloud_readiness as cr
        nonexistent_lab = os.path.join(tempfile.gettempdir(), 'medicafe_test_nonexistent_lab_transition')
        env_flag = lambda name, default: True if name == 'MEDICAFE_PHASE_A_AUTO_VALIDATE' else default
        baseline_result = {
            "status": "STARTED_NEW",
            "error_code": "",
            "message": "",
            "payload": {},
        }
        pipeline_result = {
            "status": "STARTED_NEW",
            "error_code": "",
            "message": "Initialization in progress.",
            "payload": {},
        }
        with patch('MediCafe.cloud_readiness.resolve_lab_root', return_value=nonexistent_lab):
            with patch('MediCafe.cloud_readiness._probe_lab_root', return_value={'is_dir': False, 'has_core_artifacts': False, 'pipeline_running': False}):
                with patch('MediCafe.cloud_readiness._lab_has_core_artifacts', return_value=False):
                    with patch('MediCafe.cloud_readiness.shadow_orchestrator.start_or_attach_shadow_pipeline') as mock_start:
                        mock_start.side_effect = [baseline_result, pipeline_result]
                        ok, msg, _ = cr.ensure_lab_ready('/repo', '/py', {}, env_flag)
        self.assertTrue(ok)
        self.assertEqual(msg, 'Initialization in progress.')
        self.assertEqual(mock_start.call_count, 2)
        self.assertEqual(mock_start.call_args_list[0][1]['action_id'], cr.shadow_orchestrator.ACTION_ENSURE_PHASE_A_ONLY)
        self.assertEqual(mock_start.call_args_list[1][1]['action_id'], cr.shadow_orchestrator.ACTION_MANUAL_FULL_PIPELINE)

    def test_skips_auto_full_pipeline_when_recent_success_in_diagnostics(self):
        """Cloud Readiness opt-in: skip follow-up pipeline when diagnostics + Phase F JSONs match."""
        from MediCafe import cloud_readiness as cr
        lab = tempfile.mkdtemp()
        rid = '20260330-111009-662e67f1'
        try:
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports, exist_ok=True)
            diag_path = os.path.join(lab, 'diagnostics_state.json')
            with open(diag_path, 'w', encoding='utf-8') as f:
                f.write(
                    '{{"last_shadow_pipeline_ok": true, '
                    '"last_shadow_pipeline_finished_at_utc": "2026-03-30T11:11:30Z", '
                    '"last_shadow_pipeline_run_id": "{0}"}}'.format(rid)
                )
            for name in (
                'shadow_run_report_{0}.json'.format(rid),
                'shadow_evidence_index_{0}.json'.format(rid),
            ):
                with open(os.path.join(reports, name), 'w', encoding='utf-8') as jf:
                    jf.write('{}')
            env_flag = lambda name, default: True if name == 'MEDICAFE_PHASE_A_AUTO_VALIDATE' else default
            baseline_result = {
                'status': 'STARTED_NEW',
                'error_code': '',
                'message': '',
                'payload': {},
            }
            with patch('MediCafe.cloud_readiness.resolve_lab_root', return_value=lab):
                with patch('MediCafe.cloud_readiness._probe_lab_root', return_value={'is_dir': True, 'has_core_artifacts': False, 'pipeline_running': False}):
                    with patch('MediCafe.cloud_readiness._lab_has_core_artifacts', return_value=False):
                        with patch(
                            'MediCafe.cloud_readiness.shadow_orchestrator.start_or_attach_shadow_pipeline',
                            return_value=baseline_result,
                        ) as mock_start:
                            with patch('MediCafe.cloud_readiness.time.time', return_value=1774869150):
                                ok, msg, _ = cr.ensure_lab_ready(
                                    '/repo', '/py', {}, env_flag, skip_recent_success_autopipeline=True)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            mock_start.assert_called_once()
            self.assertEqual(mock_start.call_args[1]['action_id'], cr.shadow_orchestrator.ACTION_ENSURE_PHASE_A_ONLY)
        finally:
            import shutil
            shutil.rmtree(lab, ignore_errors=True)

    def test_default_does_not_skip_auto_full_pipeline_with_recent_success_diagnostics(self):
        """Manual Phase F paths use default ensure_lab_ready; still escalate to full pipeline when baseline needed."""
        from MediCafe import cloud_readiness as cr
        lab = tempfile.mkdtemp()
        rid = '20260330-111009-662e67f1'
        try:
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports, exist_ok=True)
            diag_path = os.path.join(lab, 'diagnostics_state.json')
            with open(diag_path, 'w', encoding='utf-8') as f:
                f.write(
                    '{{"last_shadow_pipeline_ok": true, '
                    '"last_shadow_pipeline_finished_at_utc": "2026-03-30T11:11:30Z", '
                    '"last_shadow_pipeline_run_id": "{0}"}}'.format(rid)
                )
            for name in (
                'shadow_run_report_{0}.json'.format(rid),
                'shadow_evidence_index_{0}.json'.format(rid),
            ):
                with open(os.path.join(reports, name), 'w', encoding='utf-8') as jf:
                    jf.write('{}')
            env_flag = lambda name, default: True if name == 'MEDICAFE_PHASE_A_AUTO_VALIDATE' else default
            baseline_result = {
                'status': 'STARTED_NEW',
                'error_code': '',
                'message': '',
                'payload': {},
            }
            pipeline_result = {
                'status': 'STARTED_NEW',
                'error_code': '',
                'message': 'Initialization in progress.',
                'payload': {},
            }
            with patch('MediCafe.cloud_readiness.resolve_lab_root', return_value=lab):
                with patch('MediCafe.cloud_readiness._probe_lab_root', return_value={'is_dir': True, 'has_core_artifacts': False, 'pipeline_running': False}):
                    with patch('MediCafe.cloud_readiness._lab_has_core_artifacts', return_value=False):
                        with patch(
                            'MediCafe.cloud_readiness.shadow_orchestrator.start_or_attach_shadow_pipeline',
                        ) as mock_start:
                            mock_start.side_effect = [baseline_result, pipeline_result]
                            with patch('MediCafe.cloud_readiness.time.time', return_value=1774869150):
                                ok, msg, _ = cr.ensure_lab_ready('/repo', '/py', {}, env_flag)
            self.assertTrue(ok)
            self.assertEqual(msg, 'Initialization in progress.')
            self.assertEqual(mock_start.call_count, 2)
            self.assertEqual(mock_start.call_args_list[1][1]['action_id'], cr.shadow_orchestrator.ACTION_MANUAL_FULL_PIPELINE)
        finally:
            import shutil
            shutil.rmtree(lab, ignore_errors=True)

    def test_opt_in_does_not_skip_when_phase_f_json_missing(self):
        """Opt-in without both report+index JSON for run_id still runs follow-up full pipeline."""
        from MediCafe import cloud_readiness as cr
        lab = tempfile.mkdtemp()
        rid = '20260330-111009-662e67f1'
        try:
            os.makedirs(os.path.join(lab, 'reports'), exist_ok=True)
            diag_path = os.path.join(lab, 'diagnostics_state.json')
            with open(diag_path, 'w', encoding='utf-8') as f:
                f.write(
                    '{{"last_shadow_pipeline_ok": true, '
                    '"last_shadow_pipeline_finished_at_utc": "2026-03-30T11:11:30Z", '
                    '"last_shadow_pipeline_run_id": "{0}"}}'.format(rid)
                )
            with open(os.path.join(lab, 'reports', 'shadow_run_report_{0}.json'.format(rid)), 'w', encoding='utf-8') as jf:
                jf.write('{}')
            env_flag = lambda name, default: True if name == 'MEDICAFE_PHASE_A_AUTO_VALIDATE' else default
            baseline_result = {
                'status': 'STARTED_NEW',
                'error_code': '',
                'message': '',
                'payload': {},
            }
            pipeline_result = {
                'status': 'STARTED_NEW',
                'error_code': '',
                'message': 'Initialization in progress.',
                'payload': {},
            }
            with patch('MediCafe.cloud_readiness.resolve_lab_root', return_value=lab):
                with patch('MediCafe.cloud_readiness._probe_lab_root', return_value={'is_dir': True, 'has_core_artifacts': False, 'pipeline_running': False}):
                    with patch('MediCafe.cloud_readiness._lab_has_core_artifacts', return_value=False):
                        with patch(
                            'MediCafe.cloud_readiness.shadow_orchestrator.start_or_attach_shadow_pipeline',
                        ) as mock_start:
                            mock_start.side_effect = [baseline_result, pipeline_result]
                            with patch('MediCafe.cloud_readiness.time.time', return_value=1774869150):
                                ok, msg, _ = cr.ensure_lab_ready(
                                    '/repo', '/py', {}, env_flag, skip_recent_success_autopipeline=True)
            self.assertTrue(ok)
            self.assertEqual(msg, 'Initialization in progress.')
            self.assertEqual(mock_start.call_count, 2)
            self.assertEqual(mock_start.call_args_list[1][1]['action_id'], cr.shadow_orchestrator.ACTION_MANUAL_FULL_PIPELINE)
        finally:
            import shutil
            shutil.rmtree(lab, ignore_errors=True)

    def test_skips_when_pipeline_running(self):
        from MediCafe.cloud_readiness import ensure_lab_ready
        nonexistent_lab = os.path.join(tempfile.gettempdir(), 'medicafe_test_nonexistent_lab_67890')
        env_flag = lambda name, default: True if name == 'MEDICAFE_PHASE_A_AUTO_VALIDATE' else default
        with patch('MediCafe.cloud_readiness.resolve_lab_root', return_value=nonexistent_lab):
            with patch('MediCafe.cloud_readiness.os.path.isdir') as mock_isdir:
                mock_isdir.return_value = False
                with patch('MediCafe.cloud_readiness.is_pipeline_running', return_value=True):
                    with patch('MediCafe.cloud_readiness.subprocess.call') as mock_call:
                        ok, msg, _ = ensure_lab_ready('/repo', '/py', {}, env_flag)
        self.assertTrue(ok)
        self.assertEqual(msg, 'Initialization in progress.')
        mock_call.assert_not_called()

    def test_respects_phase_a_auto_disabled(self):
        from MediCafe.cloud_readiness import ensure_lab_ready
        nonexistent_lab = os.path.join(tempfile.gettempdir(), 'medicafe_test_nonexistent_lab_11111')
        env_flag = lambda name, default: False if name == 'MEDICAFE_PHASE_A_AUTO_VALIDATE' else default
        with patch('MediCafe.cloud_readiness.resolve_lab_root', return_value=nonexistent_lab):
            with patch('MediCafe.cloud_readiness.os.path.isdir', return_value=False):
                with patch('MediCafe.cloud_readiness.is_pipeline_running', return_value=False):
                    with patch('MediCafe.cloud_readiness.subprocess.call') as mock_call:
                        ok, msg, _ = ensure_lab_ready('/repo', '/py', {}, env_flag)
        self.assertFalse(ok)
        self.assertIn('FAILED_POLICY_PHASE_A_DISABLED', msg)
        mock_call.assert_not_called()

    def test_recheck_soft_success_when_core_artifacts_exist_after_nonzero_exit(self):
        from MediCafe import cloud_readiness as cr
        ensure_lab_ready = cr.ensure_lab_ready
        nonexistent_first = os.path.join(tempfile.gettempdir(), 'medicafe_test_nonexistent_first')
        env_flag = lambda name, default: True if name == 'MEDICAFE_PHASE_A_AUTO_VALIDATE' else default
        with patch('MediCafe.cloud_readiness.resolve_lab_root', return_value=nonexistent_first):
            with patch('MediCafe.cloud_readiness.os.path.isdir', return_value=False):
                with patch('MediCafe.cloud_readiness.is_pipeline_running', return_value=False):
                    with patch('MediCafe.cloud_readiness._lab_has_core_artifacts', return_value=True):
                        baseline_result = {
                            "status": cr.shadow_orchestrator.STATUS_READY_NOOP,
                            "error_code": cr.shadow_orchestrator.ERROR_READY_NOOP,
                            "message": "",
                            "payload": {},
                        }
                        with patch(
                            'MediCafe.cloud_readiness.shadow_orchestrator.start_or_attach_shadow_pipeline',
                            return_value=baseline_result
                        ) as mock_start:
                            with patch('MediCafe.cloud_readiness.os.path.exists', return_value=True):
                                ok, msg, _ = ensure_lab_ready('/repo', '/py', {}, env_flag)
        self.assertTrue(ok)
        self.assertEqual(msg, '')
        mock_start.assert_called_once()
        self.assertEqual(mock_start.call_args[1]['action_id'], cr.shadow_orchestrator.ACTION_ENSURE_PHASE_A_ONLY)

    def test_runs_bootstrap_when_lab_exists_but_no_core_artifacts(self):
        """Lab dir exists (e.g. partial bootstrap) but no db/cursor; must run bootstrap."""
        from MediCafe.cloud_readiness import ensure_lab_ready
        lab_root = tempfile.mkdtemp()
        try:
            os.makedirs(os.path.join(lab_root, 'reports'), exist_ok=True)
            env_flag = lambda name, default: True if name == 'MEDICAFE_PHASE_A_AUTO_VALIDATE' else default
            with patch('MediCafe.cloud_readiness.resolve_lab_root', return_value=lab_root):
                with patch('MediCafe.cloud_readiness.is_pipeline_running', return_value=False):
                    with patch('MediCafe.cloud_readiness.subprocess.call', return_value=1) as mock_call:
                        with patch('MediCafe.cloud_readiness.os.path.exists', return_value=True):
                            ok, msg, _ = ensure_lab_ready('/repo', '/py', {}, env_flag)
            self.assertFalse(ok)
            self.assertIn('Phase A bootstrap exited with code 1', msg)
            mock_call.assert_called_once()
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_empty_lab_root_returns_error(self):
        from MediCafe.cloud_readiness import ensure_lab_ready
        env_flag = lambda name, default: True
        with patch('MediCafe.cloud_readiness.resolve_lab_root', return_value=''):
            ok, msg, _ = ensure_lab_ready('/repo', '/py', {}, env_flag)
        self.assertFalse(ok)
        self.assertIn('Lab root could not be resolved', msg)

    def test_falls_back_to_repo_lab_when_resolved_lab_missing(self):
        from MediCafe.cloud_readiness import ensure_lab_ready
        temp_repo = tempfile.mkdtemp()
        try:
            fallback_lab = os.path.join(temp_repo, 'lab')
            os.makedirs(fallback_lab, exist_ok=True)
            with open(os.path.join(fallback_lab, 'unified_model_xp.db'), 'wb') as f:
                f.write(b'')
            with open(os.path.join(fallback_lab, 'run_cursor.json'), 'w') as f:
                f.write('{}')
            missing_lab = os.path.join(temp_repo, 'missing_lab')
            env_flag = lambda name, default: True if name == 'MEDICAFE_PHASE_A_AUTO_VALIDATE' else default
            with patch.dict('os.environ', {'MEDICAFE_LAB_DIR': missing_lab}, clear=False):
                with patch('MediCafe.cloud_readiness.resolve_lab_root', return_value=missing_lab):
                    ok, msg, _ = ensure_lab_ready(temp_repo, '/py', {}, env_flag)
                self.assertEqual(os.environ.get('MEDICAFE_LAB_DIR'), fallback_lab)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
        finally:
            import shutil
            shutil.rmtree(temp_repo, ignore_errors=True)

    def test_persists_fallback_lab_root_before_reporting_ready(self):
        """When MEDICAFE_LAB_DIR points to missing dir but repo_root/lab has artifacts,
        persist fallback to os.environ so downstream resolve_lab_root uses correct path."""
        from MediCafe.cloud_readiness import ensure_lab_ready, resolve_lab_root
        temp_repo = tempfile.mkdtemp()
        try:
            fallback_lab = os.path.join(temp_repo, 'lab')
            os.makedirs(fallback_lab, exist_ok=True)
            with open(os.path.join(fallback_lab, 'unified_model_xp.db'), 'wb') as f:
                f.write(b'')
            with open(os.path.join(fallback_lab, 'run_cursor.json'), 'w') as f:
                f.write('{}')
            missing_lab = os.path.join(temp_repo, 'missing_lab')
            env_flag = lambda name, default: True if name == 'MEDICAFE_PHASE_A_AUTO_VALIDATE' else default
            with patch.dict('os.environ', {'MEDICAFE_LAB_DIR': missing_lab}, clear=False):
                with patch('MediCafe.cloud_readiness.resolve_lab_root', return_value=missing_lab):
                    with patch('MediCafe.cloud_readiness.subprocess.call') as mock_call:
                        ok, msg, _ = ensure_lab_ready(temp_repo, '/py', {}, env_flag)
                self.assertTrue(ok)
                mock_call.assert_not_called()
                self.assertEqual(os.environ.get('MEDICAFE_LAB_DIR'), fallback_lab)
        finally:
            import shutil
            shutil.rmtree(temp_repo, ignore_errors=True)

    def test_nonzero_exit_writes_bootstrap_diag_hint(self):
        from MediCafe.cloud_readiness import ensure_lab_ready
        temp_repo = tempfile.mkdtemp()
        try:
            lab_root = os.path.join(temp_repo, 'lab')
            os.makedirs(lab_root, exist_ok=True)
            env_flag = lambda name, default: True if name == 'MEDICAFE_PHASE_A_AUTO_VALIDATE' else default
            with patch('MediCafe.cloud_readiness.resolve_lab_root', return_value=lab_root):
                with patch('MediCafe.cloud_readiness.is_pipeline_running', return_value=False):
                    with patch('MediCafe.cloud_readiness.subprocess.call', return_value=2):
                        with patch('MediCafe.cloud_readiness.os.path.exists', return_value=True):
                            ok, msg, _ = ensure_lab_ready(temp_repo, '/py', {}, env_flag)
            self.assertFalse(ok)
            self.assertIn('Phase A bootstrap exited with code 2', msg)
            self.assertIn('diagnostics:', msg)
        finally:
            import shutil
            shutil.rmtree(temp_repo, ignore_errors=True)

    def test_missing_bootstrap_script_returns_coded_message(self):
        from MediCafe.cloud_readiness import ensure_lab_ready
        lab_root = tempfile.mkdtemp()
        try:
            env_flag = lambda name, default: True if name == 'MEDICAFE_PHASE_A_AUTO_VALIDATE' else default
            with patch('MediCafe.cloud_readiness.resolve_lab_root', return_value=lab_root):
                with patch('MediCafe.cloud_readiness.is_pipeline_running', return_value=False):
                    with patch('MediCafe.cloud_readiness.os.path.exists', return_value=False):
                        ok, msg, _ = ensure_lab_ready('/repo', '/py', {}, env_flag)
            self.assertFalse(ok)
            self.assertIn('BOOTSTRAP_SCRIPT_MISSING', msg)
            self.assertIn('bootstrap_lab.py not found', msg)
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_bootstrap_keyboard_interrupt_returns_coded_message(self):
        from MediCafe.cloud_readiness import ensure_lab_ready
        lab_root = tempfile.mkdtemp()
        try:
            env_flag = lambda name, default: True if name == 'MEDICAFE_PHASE_A_AUTO_VALIDATE' else default
            with patch('MediCafe.cloud_readiness.resolve_lab_root', return_value=lab_root):
                with patch('MediCafe.cloud_readiness.is_pipeline_running', return_value=False):
                    with patch('MediCafe.cloud_readiness._lab_has_core_artifacts', return_value=False):
                        with patch('MediCafe.cloud_readiness.subprocess.call', side_effect=KeyboardInterrupt):
                            with patch('MediCafe.cloud_readiness.os.path.exists', return_value=True):
                                ok, msg, _ = ensure_lab_ready('/repo', '/py', {}, env_flag)
            self.assertFalse(ok)
            self.assertIn('PIPELINE_INTERRUPTED_CONTROL_EVENT', msg)
            self.assertIn('control event', msg)
            self.assertIn('diagnostics:', msg)
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_orchestrator_failure_triggers_auto_report_submission(self):
        from MediCafe import cloud_readiness as cr
        lab_root = tempfile.mkdtemp()
        try:
            env_flag = lambda name, default: True if name == 'MEDICAFE_PHASE_A_AUTO_VALIDATE' else default
            baseline_failed = {
                'status': cr.shadow_orchestrator.STATUS_FAILED,
                'error_code': 'PIPELINE_SCRIPT_MISSING',
                'message': 'PIPELINE_SCRIPT_MISSING: run_shadow_pipeline.py not found',
                'diagnostic_path': os.path.join(lab_root, 'reports', 'diag.json'),
            }
            with patch('MediCafe.cloud_readiness.resolve_lab_root', return_value=lab_root):
                with patch('MediCafe.cloud_readiness._probe_lab_root', return_value={'is_dir': True, 'has_core_artifacts': False, 'pipeline_running': False}):
                    with patch('MediCafe.cloud_readiness._lab_has_core_artifacts', return_value=False):
                        with patch('MediCafe.cloud_readiness.shadow_orchestrator.start_or_attach_shadow_pipeline', return_value=baseline_failed):
                            with patch('MediCafe.cloud_readiness._maybe_send_orchestrator_failure_report', return_value=True) as mock_auto:
                                ok, msg, _ = cr.ensure_lab_ready('/repo', '/py', {}, env_flag)
            self.assertFalse(ok)
            self.assertIn('PIPELINE_SCRIPT_MISSING', msg)
            mock_auto.assert_called_once()
            self.assertEqual(mock_auto.call_args[1].get('trigger'), 'ensure_lab_ready_baseline')
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)


class TestRunPhaseFManualForRunIdEmptyGuard(unittest.TestCase):
    """run_phase_f_manual_for_run_id empty run_id guard."""

    def test_empty_run_id_returns_error_no_spawn(self):
        from MediCafe.cloud_readiness import run_phase_f_manual_for_run_id
        with patch('MediCafe.cloud_readiness.subprocess.Popen') as mock_popen:
            with patch('os.path.exists', return_value=True):
                ok, msg, _ = run_phase_f_manual_for_run_id('/repo', '/py', {}, '')
            self.assertFalse(ok)
            self.assertIn('run_id', msg)
            mock_popen.assert_not_called()

    def test_whitespace_run_id_returns_error_no_spawn(self):
        from MediCafe.cloud_readiness import run_phase_f_manual_for_run_id
        with patch('MediCafe.cloud_readiness.subprocess.Popen') as mock_popen:
            with patch('os.path.exists', return_value=True):
                ok, msg, _ = run_phase_f_manual_for_run_id('/repo', '/py', {}, '   ')
            self.assertFalse(ok)
            self.assertIn('run_id', msg)
            mock_popen.assert_not_called()


class TestRunShadowPipelineAutoReport(unittest.TestCase):
    def test_manual_pipeline_failure_triggers_auto_report_submission(self):
        from MediCafe import cloud_readiness as cr
        failed = {
            'status': cr.shadow_orchestrator.STATUS_FAILED,
            'error_code': 'PIPELINE_SCRIPT_MISSING',
            'message': 'PIPELINE_SCRIPT_MISSING: run_shadow_pipeline.py not found',
            'payload': {},
        }
        with patch('MediCafe.cloud_readiness.shadow_orchestrator.start_or_attach_shadow_pipeline', return_value=failed):
            with patch('MediCafe.cloud_readiness.resolve_lab_root', return_value='/repo/lab'):
                with patch('MediCafe.cloud_readiness._maybe_send_orchestrator_failure_report', return_value=True) as mock_auto:
                    ok, msg, _ = cr.run_shadow_pipeline('/repo', '/py', {})
        self.assertFalse(ok)
        self.assertIn('PIPELINE_SCRIPT_MISSING', msg)
        mock_auto.assert_called_once()
        self.assertEqual(mock_auto.call_args[1].get('trigger'), 'run_shadow_pipeline_manual')


class TestMigrationHealthAuditWiring(unittest.TestCase):
    """run/open helpers for unified migration-health audit."""

    def test_run_migration_health_audit_passes_default_stage(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            scripts_dir = os.path.join(repo, 'scripts', 'unified_model')
            os.makedirs(scripts_dir)
            script_path = os.path.join(scripts_dir, 'audit_migration_health.py')
            with open(script_path, 'w', encoding='utf-8') as f:
                f.write('# stub')

            payload = {
                'overall': {'status': 'pass', 'score': 100, 'exit_code': 0},
                'surfaces': {'xp_local': {'metrics': []}},
            }
            popen_mock = MagicMock()
            popen_mock.communicate.return_value = (json.dumps(payload).encode('utf-8'), b'')
            popen_mock.returncode = 0

            with patch.object(cr, 'resolve_lab_root', return_value=os.path.join(repo, 'lab')):
                with patch.object(cr.subprocess, 'Popen', return_value=popen_mock) as mock_popen:
                    ok, _msg, _data = cr.run_migration_health_audit(
                        repo, sys.executable, {}, scope='both', write_report=False
                    )
            self.assertTrue(ok)
            cmd = mock_popen.call_args[0][0]
            self.assertIn('--migration-stage', cmd)
            idx = cmd.index('--migration-stage')
            self.assertEqual(cmd[idx + 1], 'xp_validation')

    def test_run_migration_health_audit_parses_payload_and_hints(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            scripts_dir = os.path.join(repo, 'scripts', 'unified_model')
            os.makedirs(scripts_dir)
            script_path = os.path.join(scripts_dir, 'audit_migration_health.py')
            with open(script_path, 'w', encoding='utf-8') as f:
                f.write('# stub')

            payload = {
                'overall': {'status': 'warn', 'score': 70, 'exit_code': 0},
                'surfaces': {
                    'xp_local': {'metrics': [
                        {'key': 'xp.phase_d_reject_ratio', 'status': 'warn', 'value': 0.22},
                        {'key': 'xp.phase_e_projection_coverage', 'status': 'pass', 'value': 1.0},
                        {'key': 'xp.phase_e_contract_parity', 'status': 'pass', 'value': 'pass'},
                        {'key': 'xp.post_medisoft_status', 'status': 'warn', 'value': 'blocked', 'detail': 'blocked_stage=qa'},
                        {'key': 'xp.phase_b_dat_candidates_seen_count', 'status': 'pass', 'value': 1},
                        {'key': 'xp.phase_b_dat_manifest_rows_count', 'status': 'pass', 'value': 0},
                        {'key': 'xp.phase_b_dat_configured_root_missing_count', 'status': 'pass', 'value': 1},
                        {'key': 'xp.phase_b_dat_fallback_root_count', 'status': 'pass', 'value': 1},
                        {'key': 'xp.phase_b_dat_existing_empty_root_count', 'status': 'pass', 'value': 1},
                        {'key': 'xp.phase_b_dat_selection_mode', 'status': 'pass', 'value': 'fallback'},
                        {'key': 'xp.phase_b_dat_selected_root_source_id', 'status': 'pass', 'value': 'dat_fallback'},
                        {'key': 'xp.phase_b_dat_effective_root_source_id', 'status': 'pass', 'value': 'dat_fallback'},
                        {'key': 'xp.phase_d_dat_selected_count', 'status': 'pass', 'value': 1},
                        {'key': 'xp.phase_d_dat_qa_pass_count', 'status': 'pass', 'value': 0},
                        {'key': 'xp.phase_d_dat_qa_reject_count', 'status': 'pass', 'value': 1},
                        {'key': 'xp.phase_d_dat_canonical_record_count', 'status': 'pass', 'value': 0},
                        {'key': 'xp.phase_d_csv_docx_join_summary', 'status': 'warn', 'value': 'tracked', 'detail': 'matched=4,csv_only=1,docx_only=2,ambiguous=1,negotiation=multiple_candidates_shared_join_key_no_deterministic_docx_winner,default=suppress_docx_enrichment_keep_csv_row,log=qa_planning_telemetry_log#17(run_id=r1)'},
                    ]},
                    'cloud': {'metrics': [
                        {'key': 'cloud.unacked_queue_count', 'status': 'warn', 'value': 35},
                    ]},
                },
                'degradations': [],
            }
            popen_mock = MagicMock()
            popen_mock.communicate.return_value = (json.dumps(payload).encode('utf-8'), b'')
            popen_mock.returncode = 0

            with patch.object(cr, 'resolve_lab_root', return_value=os.path.join(repo, 'lab')):
                with patch.object(cr.subprocess, 'Popen', return_value=popen_mock):
                    ok, msg, data = cr.run_migration_health_audit(repo, sys.executable, {}, scope='both', write_report=False)

            self.assertTrue(ok)
            self.assertIn('status=warn', msg)
            assert isinstance(data, dict)
            self.assertTrue(any('QA reject ratio' in h for h in data.get('hints', [])))
            self.assertTrue(any('Post-MediSoft path' in h for h in data.get('hints', [])))
            self.assertTrue(any('XP DAT Phase D' in h for h in data.get('hints', [])))
            self.assertTrue(any('CSV+DOCX join' in h for h in data.get('hints', [])))

    def test_deduplicate_audit_hint_lines(self):
        from MediCafe.cloud_readiness import _deduplicate_audit_hint_lines
        self.assertEqual(
            _deduplicate_audit_hint_lines(['a', '  a  ', 'b', 'a', 'c']),
            ['a', 'b', 'c'],
        )
        self.assertEqual(_deduplicate_audit_hint_lines([]), [])

    def test_audit_hint_lines_include_stage_aware_cloud_note(self):
        from MediCafe import cloud_readiness as cr
        payload = {
            'migration_stage': 'xp_validation',
            'overall': {'status': 'warn', 'score': 38, 'exit_code': 0},
            'gating': {'included_surfaces': ['xp_local'], 'excluded_surfaces': ['cloud']},
            'surfaces': {
                'xp_local': {'metrics': [
                    {'key': 'xp.phase_e_projection_coverage', 'status': 'pass', 'value': 'not_applicable'},
                    {'key': 'xp.cursor_state_run_alignment', 'status': 'warn', 'value': 2},
                    {'key': 'xp.post_medisoft_status', 'status': 'warn', 'value': 'blocked', 'detail': 'blocked_stage=missing_root,selection_mode=fallback,selected_root_source_id=dat_fallback,effective_root_source_id=dat_fallback'},
                    {'key': 'xp.phase_b_dat_candidates_seen_count', 'status': 'pass', 'value': 2},
                    {'key': 'xp.phase_b_dat_manifest_rows_count', 'status': 'pass', 'value': 0},
                    {'key': 'xp.phase_b_dat_configured_root_missing_count', 'status': 'pass', 'value': 1},
                    {'key': 'xp.phase_b_dat_fallback_root_count', 'status': 'pass', 'value': 1},
                    {'key': 'xp.phase_b_dat_existing_empty_root_count', 'status': 'pass', 'value': 1},
                    {'key': 'xp.phase_b_dat_selection_mode', 'status': 'pass', 'value': 'fallback'},
                    {'key': 'xp.phase_b_dat_selected_root_source_id', 'status': 'pass', 'value': 'dat_fallback'},
                    {'key': 'xp.phase_b_dat_effective_root_source_id', 'status': 'pass', 'value': 'dat_fallback'},
                    {'key': 'xp.phase_d_dat_selected_count', 'status': 'pass', 'value': 1},
                    {'key': 'xp.phase_d_dat_qa_pass_count', 'status': 'pass', 'value': 0},
                    {'key': 'xp.phase_d_dat_qa_reject_count', 'status': 'pass', 'value': 1},
                    {'key': 'xp.phase_d_dat_canonical_record_count', 'status': 'pass', 'value': 0},
                    {'key': 'xp.phase_d_csv_docx_join_summary', 'status': 'warn', 'value': 'tracked', 'detail': 'matched=4,csv_only=1,docx_only=2,ambiguous=1,negotiation=multiple_candidates_shared_join_key_no_deterministic_docx_winner,default=suppress_docx_enrichment_keep_csv_row,log=qa_planning_telemetry_log#17(run_id=r1)'},
                ]},
                'cloud': {'metrics': []},
            },
            'degradations': [{'surface': 'cloud', 'reason': 'project_id_missing'}],
        }
        hints = cr._audit_hint_lines_from_payload(payload)
        joined = '\n'.join(hints)
        self.assertIn('Migration stage: xp_validation', joined)
        self.assertIn('Cloud surface is informational-only', joined)
        self.assertIn('XP projection coverage: not_applicable', joined)
        self.assertIn('Post-MediSoft path: blocked', joined)
        self.assertIn('XP DAT discovery: candidates=2, manifest_rows=0', joined)
        self.assertIn('selected_root=dat_fallback', joined)
        self.assertIn('effective_root=dat_fallback', joined)
        self.assertIn('XP DAT Phase D: selected=1, qa_pass=0, qa_reject=1, canonical=0', joined)
        self.assertIn('XP upstream CSV+DOCX join: matched=4,csv_only=1,docx_only=2,ambiguous=1,negotiation=multiple_candidates_shared_join_key_no_deterministic_docx_winner,default=suppress_docx_enrichment_keep_csv_row,log=qa_planning_telemetry_log#17(run_id=r1)', joined)
        self.assertIn('qa_planning_telemetry_log#17(run_id=r1)', joined)
        self.assertIn('XP cursor/state run alignment: 2 (warn)', joined)
        self.assertIn('Cloud degradation reasons: project_id_missing', joined)
        self.assertIn('Runbook: docs/runbooks/Cloud_Readiness_Cloud_Degraded_Validation.md', joined)

    def test_open_latest_migration_health_report_prefers_latest(self):
        from MediCafe.cloud_readiness import open_latest_migration_health_report
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            p1 = os.path.join(reports, 'audit_migration_health_summary_20260101-000000-aaaa1111.txt')
            p2 = os.path.join(reports, 'audit_migration_health_summary_20260101-000500-bbbb2222.txt')
            with open(p1, 'w', encoding='utf-8') as f:
                f.write('one')
            with open(p2, 'w', encoding='utf-8') as f:
                f.write('two')
            os.utime(p1, (1000, 1000))
            os.utime(p2, (2000, 2000))
            with patch.dict('os.environ', {'MEDICAFE_LAB_DIR': lab}, clear=False):
                ok, msg, path = open_latest_migration_health_report(repo)
            self.assertTrue(ok)
            assert isinstance(path, str)
            self.assertTrue(path.endswith('bbbb2222.txt'))


class TestReportDeliveryStatusViewer(unittest.TestCase):
    def test_open_report_delivery_status_writes_snapshot(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            queue1 = os.path.join(repo, 'q1.zip')
            queue2 = os.path.join(repo, 'q2.zip')
            with open(queue1, 'w', encoding='utf-8') as f:
                f.write('x')
            with open(queue2, 'w', encoding='utf-8') as f:
                f.write('y')
            os.utime(queue1, (1000, 1000))
            os.utime(queue2, (2000, 2000))

            health_state = os.path.join(lab, cr._HEALTH_ALERT_STATE_FILENAME)
            with open(health_state, 'w', encoding='utf-8') as f:
                json.dump({'last_issue_key': 'A', 'last_sent_epoch': 123}, f)
            orch_state = os.path.join(lab, cr._ORCHESTRATOR_ALERT_STATE_FILENAME)
            with open(orch_state, 'w', encoding='utf-8') as f:
                json.dump({'last_issue_key': 'B', 'last_attempt_epoch': 456, 'last_attempt_ok': False}, f)

            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                with patch.object(cr, '_collect_delivery_diagnostics', return_value={
                    'token_available': False,
                    'recipient_count': 0,
                    'queued_bundle_count': 2,
                    'queued_bundle_paths': [queue1, queue2],
                }):
                    ok, msg, path = cr.open_report_delivery_status(repo)

            self.assertTrue(ok)
            self.assertEqual(msg, '')
            self.assertIsInstance(path, str)
            assert isinstance(path, str)
            self.assertTrue(os.path.exists(path))
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('Report Delivery Status', text)
            self.assertIn('token_available=False', text)
            self.assertIn('recipient_count=0', text)
            self.assertIn('queued_bundle_count=2', text)
            self.assertIn('Cloud health auto-report', text)
            self.assertIn('Orchestrator auto-report', text)
            self.assertIn('Remediation Playbook', text)
            self.assertIn('Actions:', text)


class TestSystemHealthPackWiring(unittest.TestCase):
    def test_run_system_health_triage_returns_hints_and_artifacts(self):
        from MediCafe import cloud_readiness as cr
        with patch.object(cr, 'run_migration_health_audit', return_value=(
            True,
            'Audit completed with status=warn, score=80, exit_code=0',
            {'hints': ['h1']},
        )):
            with patch.object(cr, 'open_latest_system_health_pack', return_value=(
                True,
                '',
                '/repo/lab/reports/system_health_pack_latest.txt',
            )):
                with patch.object(cr, 'open_latest_migration_health_report', return_value=(
                    True,
                    '',
                    '/repo/lab/reports/audit_migration_health_summary_latest.txt',
                )):
                    ok, msg, data = cr.run_system_health_triage(
                        '/repo',
                        '/py',
                        {},
                        lambda name, default: default,
                        scope='both',
                        cloud_required=False,
                    )
        self.assertTrue(ok)
        self.assertIn('System health triage', msg)
        self.assertTrue(isinstance(data, dict))
        self.assertEqual(data.get('hints'), ['h1'])
        self.assertTrue('/repo/lab/reports/system_health_pack_latest.txt' in data.get('artifacts', []))
        self.assertTrue('/repo/lab/reports/audit_migration_health_summary_latest.txt' in data.get('artifacts', []))
        self.assertTrue(isinstance(data.get('runbook', {}), dict))
        self.assertTrue(isinstance(data.get('runbook_lines', []), list))
        self.assertIn('decision', data.get('runbook', {}))

    def test_send_latest_system_health_pack_includes_pack_and_delivery(self):
        from MediCafe import cloud_readiness as cr
        artifacts = {
            'delivery_status_path': '/lab/reports/report_delivery_status.txt',
            'consolidated_path': '/lab/reports/consolidated_health_snapshot.txt',
            'audit_summary_txt': '/lab/reports/audit_migration_health_summary_latest.txt',
            'audit_summary_json': '/lab/reports/audit_migration_health_summary_latest.json',
            'audit_metrics_json': '/lab/reports/audit_migration_health_metrics_latest.json',
            'phase_f_mismatch_path': '/lab/reports/phase_f_mismatch_latest.txt',
        }
        with patch.object(cr, 'resolve_lab_root', return_value='/lab'):
            with patch.object(cr, '_reports_dir_access_error', return_value=None):
                with patch.object(cr, 'open_latest_system_health_pack', return_value=(
                    True,
                    '',
                    '/lab/reports/system_health_pack_latest.txt',
                )):
                    with patch.object(cr, '_collect_system_health_artifacts', return_value=artifacts):
                        with patch.object(cr, '_select_latest_evidence_files', return_value=[
                            ('shadow_run_report_latest.txt', '/lab/reports/shadow_run_report_latest.txt'),
                        ]):
                            with patch.object(cr, '_collect_delivery_diagnostics', return_value={}):
                                with patch.object(cr, 'collect_support_bundle', return_value='/tmp/bundle.zip') as mock_collect:
                                    with patch.object(cr, '_submit_bundle_with_delivery_diagnostics', return_value=(True, '', {})):
                                        with patch('MediCafe.cloud_readiness.os.path.isfile', return_value=True):
                                            ok, msg, data = cr.send_latest_system_health_pack(
                                                '/repo',
                                                lambda name, default: default,
                                            )
        self.assertTrue(ok)
        self.assertEqual(msg, '')
        self.assertEqual(data.get('delivery_status_path'), '/lab/reports/report_delivery_status.txt')
        meta = mock_collect.call_args[1].get('extra_meta', {})
        self.assertTrue(meta.get('system_health_pack'))
        self.assertEqual(meta.get('send_source'), 'manual_system_health_pack')
        extra_files = mock_collect.call_args[1].get('extra_files', [])
        basenames = [item[0] for item in extra_files]
        self.assertIn('system_health_pack_latest.txt', basenames)
        self.assertIn('report_delivery_status.txt', basenames)
        self.assertTrue(isinstance(data.get('pre_send_runbook_lines', []), list))
        self.assertTrue(len(data.get('pre_send_runbook_lines', [])) > 0)

    def test_send_latest_system_health_pack_includes_current_run_companions_and_lock_diag(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            current_run_id = 'rid-current'
            pack_path = os.path.join(reports, 'system_health_pack_latest.txt')
            with open(pack_path, 'w', encoding='utf-8') as f:
                f.write('pack')
            with open(os.path.join(reports, 'consolidated_health_snapshot.txt'), 'w', encoding='utf-8') as f:
                f.write('consolidated')
            with open(os.path.join(reports, 'audit_migration_health_summary_latest.txt'), 'w', encoding='utf-8') as f:
                f.write('summary txt')
            with open(os.path.join(reports, 'audit_migration_health_summary_latest.json'), 'w', encoding='utf-8') as f:
                f.write('{}')
            with open(os.path.join(reports, 'audit_migration_health_metrics_latest.json'), 'w', encoding='utf-8') as f:
                f.write('{}')
            with open(os.path.join(reports, 'report_delivery_status.txt'), 'w', encoding='utf-8') as f:
                f.write('delivery')
            older_shadow = os.path.join(reports, 'shadow_run_report_latest.txt')
            with open(older_shadow, 'w', encoding='utf-8') as f:
                f.write('older')
            lock_diag = os.path.join(reports, 'phase_f_lock_diag_{0}_20260323T143753Z.json'.format(current_run_id))
            with open(lock_diag, 'w', encoding='utf-8') as f:
                json.dump({'reason': 'acquire_system_exit'}, f)
            diagnostics_state_path = os.path.join(lab, 'diagnostics_state.json')
            with open(diagnostics_state_path, 'w', encoding='utf-8') as f:
                json.dump({
                    'last_shadow_pipeline_run_id': current_run_id,
                    'last_phase_f_lock_diag_path': lock_diag,
                }, f)
            current_files = []
            for name in (
                    'artifact_discovery_summary_BRID.json',
                    'ingest_write_summary_CRID.json',
                    'qa_canonical_summary_DRID.json',
                    'projection_parity_summary_ERID.json',
                    'shadow_run_report_{0}.json'.format(current_run_id),
                    'shadow_evidence_index_{0}.json'.format(current_run_id)):
                path_current = os.path.join(reports, name)
                with open(path_current, 'w', encoding='utf-8') as f:
                    f.write('{}')
                current_files.append(path_current)
            run_cursor = os.path.join(lab, 'run_cursor.json')
            with open(run_cursor, 'w', encoding='utf-8') as f:
                f.write('{}')
            artifacts = {
                'delivery_status_path': os.path.join(reports, 'report_delivery_status.txt'),
                'consolidated_path': os.path.join(reports, 'consolidated_health_snapshot.txt'),
                'audit_summary_txt': os.path.join(reports, 'audit_migration_health_summary_latest.txt'),
                'audit_summary_json': os.path.join(reports, 'audit_migration_health_summary_latest.json'),
                'audit_metrics_json': os.path.join(reports, 'audit_migration_health_metrics_latest.json'),
                'phase_f_mismatch_path': '',
            }
            snapshot = {
                'artifact_files': current_files,
                'context_files': [diagnostics_state_path, run_cursor],
            }
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                with patch.object(cr, '_reports_dir_access_error', return_value=None):
                    with patch.object(cr, 'open_latest_system_health_pack', return_value=(True, '', pack_path)):
                        with patch.object(cr, '_collect_system_health_artifacts', return_value=artifacts):
                            with patch.object(cr, '_select_latest_evidence_files', return_value=[
                                ('shadow_run_report_latest.txt', older_shadow),
                            ]):
                                with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                                    with patch.object(cr, '_collect_delivery_diagnostics', return_value={}):
                                        with patch.object(cr, 'collect_support_bundle', return_value='/tmp/bundle.zip') as mock_collect:
                                            with patch.object(cr, '_submit_bundle_with_delivery_diagnostics', return_value=(True, '', {})):
                                                ok, msg, data = cr.send_latest_system_health_pack(
                                                    repo,
                                                    lambda name, default: default,
                                                )
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            extra_files = mock_collect.call_args[1].get('extra_files', [])
            basenames = [item[0] for item in extra_files]
            self.assertIn(os.path.basename(lock_diag), basenames)
            self.assertIn('artifact_discovery_summary_BRID.json', basenames)
            self.assertIn('ingest_write_summary_CRID.json', basenames)
            self.assertIn('qa_canonical_summary_DRID.json', basenames)
            self.assertIn('projection_parity_summary_ERID.json', basenames)
            self.assertIn('shadow_run_report_{0}.json'.format(current_run_id), basenames)
            self.assertIn('shadow_evidence_index_{0}.json'.format(current_run_id), basenames)
            self.assertTrue(isinstance(data.get('pre_send_runbook_lines', []), list))

    def test_collect_system_health_artifacts_prefers_diagnostics_anchored_phase_f_files(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            rid_current = 'rid-current'
            rid_stale = 'rid-stale'
            stale_report = os.path.join(reports, 'shadow_run_report_{0}.json'.format(rid_stale))
            stale_index = os.path.join(reports, 'shadow_evidence_index_{0}.json'.format(rid_stale))
            stale_mismatch = os.path.join(reports, 'phase_f_mismatch_{0}.txt'.format(rid_stale))
            current_report = os.path.join(reports, 'shadow_run_report_{0}.json'.format(rid_current))
            current_index = os.path.join(reports, 'shadow_evidence_index_{0}.json'.format(rid_current))
            current_mismatch = os.path.join(reports, 'phase_f_mismatch_{0}.txt'.format(rid_current))
            for path in (stale_report, stale_index, stale_mismatch, current_report, current_index, current_mismatch):
                with open(path, 'w', encoding='utf-8') as f:
                    f.write('{}' if path.endswith('.json') else 'mismatch')
            newer = time.time() + 120
            for path in (stale_report, stale_index, stale_mismatch):
                os.utime(path, (newer, newer))
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'pipeline_state': 'completed',
                    'active_run_id': '',
                    'last_shadow_pipeline_run_id': rid_current,
                }, f)
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                with patch.object(cr, 'open_consolidated_health_report', return_value=(True, '', '')):
                    artifacts = cr._collect_system_health_artifacts(
                        repo,
                        lambda _name, default: default,
                        include_delivery_status=False,
                    )
            self.assertEqual(artifacts.get('shadow_report_path'), current_report)
            self.assertEqual(artifacts.get('shadow_index_path'), current_index)
            self.assertEqual(artifacts.get('phase_f_mismatch_path'), current_mismatch)

    def test_open_latest_system_health_pack_includes_runbook_section(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            json_dir = os.path.join(repo, 'json')
            os.makedirs(reports)
            os.makedirs(json_dir)
            with open(os.path.join(json_dir, 'config.json'), 'w', encoding='utf-8') as f:
                json.dump(
                    {
                        'MediLink_Config': {
                            'fixedWidthSlices': {
                                'service_slices': {
                                    'DATE1': [0, 10],
                                    'DOS': [10, 20],
                                    'CPT': [20, 25],
                                }
                            }
                        }
                    },
                    f,
                )
            with open(os.path.join(json_dir, 'crosswalk.json'), 'w', encoding='utf-8') as f:
                json.dump(
                    {
                        'mains_mapping': {
                            'slices': {
                                'DATE1': [0, 10],
                                'PROC': [10, 15],
                            }
                        }
                    },
                    f,
                )
            with open(os.path.join(reports, 'audit_migration_health_summary_latest.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'overall': {'status': 'warn'},
                    'generated_at_utc': '2026-02-19T00:00:00Z',
                    'degradations': [{'surface': 'cloud', 'reason': 'firestore_unavailable'}],
                }, f)
            with open(os.path.join(reports, 'audit_migration_health_summary_latest.txt'), 'w', encoding='utf-8') as f:
                f.write('summary')
            shadow_json = os.path.join(reports, 'shadow_run_report_rid-b.json')
            with open(shadow_json, 'w', encoding='utf-8') as f:
                json.dump({
                    'machine_hostname': 'XP-CLIENT-01',
                    'machine_app_version': '0.260326.1',
                    'machine_python_version': '3.4.4',
                    'machine_platform': 'Windows-XP',
                    'machine_test_mode': False,
                }, f)
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump(
                    {
                        'pipeline_state': 'running',
                        'active_run_id': 'rid-a',
                        'last_shadow_pipeline_run_id': 'rid-b',
                        'last_discovery_dat_telemetry': {
                            'dat_manifest_rows_count': 389,
                            'dat_configured_root_missing_count': 1,
                            'dat_selected_root_source_id': 'dat_cfg_1',
                            'dat_selection_mode': 'configured',
                        },
                        'last_phase_d_dat_telemetry': {
                            'dat_selected_count': 389,
                            'dat_qa_pass_count': 0,
                            'dat_qa_reject_count': 389,
                            'dat_canonical_record_count': 0,
                            'dat_field_presence_by_alias': {
                                'records_seen': 389,
                                'PATID': 382,
                                'patient_id': 0,
                                'DOS': 0,
                                'DATE1': 9,
                                'date_of_service': 0,
                                'PAYERID': 370,
                                'INSID': 12,
                                'payer_id': 0,
                            },
                            'dat_qa_reject_counts_by_reason': {
                                'QA_DAT_DATE_OF_SERVICE_MISSING': 370,
                                'QA_ARTIFACT_CLASS_REQUIRED_FIELDS': 12,
                                'QA_DAT_PATIENT_ANCHOR_MISSING': 7,
                            },
                        },
                    },
                    f,
                )
            with patch.object(cr, '_collect_system_health_artifacts', return_value={
                'lab_root': lab,
                'reports_dir': reports,
                'consolidated_ok': True,
                'consolidated_message': '',
                'consolidated_path': '',
                'audit_summary_txt': os.path.join(reports, 'audit_migration_health_summary_latest.txt'),
                'audit_summary_json': os.path.join(reports, 'audit_migration_health_summary_latest.json'),
                'audit_metrics_json': '',
                'shadow_report_path': shadow_json,
                'shadow_index_path': '',
                'phase_f_mismatch_path': '',
                'delivery_status_path': '',
            }):
                with patch.object(cr, 'get_health_lines', return_value=['health-line']):
                    ok, msg, path = cr.open_latest_system_health_pack(
                        repo, lambda name, default: default, include_delivery_status=False)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            assert isinstance(path, str)
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('machine_fingerprint=host:XP-CLIENT-01, app_version:0.260326.1, python:3.4.4, platform:Windows-XP, test_mode:False', text)
            self.assertIn('pack_anchor_run_id=rid-b', text)
            self.assertIn('pack_scope=mixed_scope', text)
            self.assertIn('Anchored completed-run snapshot:', text)
            self.assertIn('System Health Runbook:', text)
            self.assertIn('Data plane snapshot (cumulative lab state):', text)
            self.assertIn('Note: phase detail rows B..E reflect per-run summary counts from the live diagnostics state file', text)
            self.assertIn('run_alignment=active_differs_from_last', text)
            self.assertIn('cloud_degraded_mode=True', text)
            self.assertIn('cloud_degradation_reasons=firestore_unavailable', text)
            self.assertIn('dat_focus_snapshot=selected:389, qa_pass:0, qa_reject:389, canonical:0, pass_rate:0.000', text)
            self.assertIn(
                'dat_discovery_snapshot=manifest_rows:389, selected_root:dat_cfg_1, selection_mode:configured, missing_configured_roots:1',
                text,
            )
            self.assertIn(
                'dat_parser_slice_snapshot=config_service(DOS:True,DATE1:True,count:3), crosswalk_mains(DOS:False,DATE1:True,count:2)',
                text,
            )
            self.assertIn(
                'dat_alias_presence=records:389, PATID:382, patient_id:0, DOS:0, DATE1:9, date_of_service:0, PAYERID:370, INSID:12, payer_id:0',
                text,
            )
            self.assertIn('dat_reject_mix_top=QA_DAT_DATE_OF_SERVICE_MISSING:370(0.951)', text)
            self.assertIn('next_health_focus=dat_qa_full_block', text)
            self.assertIn(
                'next_health_target=drive dat_qa_pass_count>0 and dat_canonical_record_count>0 for the next run',
                text,
            )
            self.assertIn('dat_failure_mode_hypothesis=date_alias_or_slice_mismatch_high', text)
            self.assertIn(
                'next_health_target=confirm alias presence trends vs reject mix (DOS/DATE1, PATID/patient_id, PAYERID/INSID)',
                text,
            )
            self.assertIn(
                'Track dat_focus_snapshot and dat_reject_mix_top deltas across consecutive health packs.',
                text,
            )
            self.assertIn('Open cloud degraded validation runbook: docs/runbooks/Cloud_Readiness_Cloud_Degraded_Validation.md', text)
            self.assertIn('Check (firestore_unavailable):', text)

    def test_open_latest_system_health_pack_includes_phase_f_lock_context(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            audit_json = os.path.join(reports, 'audit_migration_health_summary_latest.json')
            with open(audit_json, 'w', encoding='utf-8') as f:
                json.dump({'overall': {'status': 'fail'}, 'generated_at_utc': '2026-02-19T00:00:00Z'}, f)
            audit_txt = os.path.join(reports, 'audit_migration_health_summary_latest.txt')
            with open(audit_txt, 'w', encoding='utf-8') as f:
                f.write('summary')
            lock_diag = os.path.join(reports, 'phase_f_lock_diag_rid-lock_20260323T143753Z.json')
            with open(lock_diag, 'w', encoding='utf-8') as f:
                json.dump({
                    'reason': 'acquire_system_exit',
                    'lock_owner_running': True,
                    'lock_heartbeat_stale': False,
                    'lock_pid': '4321',
                }, f)
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'pipeline_state': 'failed',
                    'last_shadow_pipeline_run_id': 'rid-lock',
                    'last_shadow_pipeline_error_code': 'PHASE_F_LOCK_FAIL',
                    'last_phase_f_lock_diag_path': lock_diag,
                }, f)
            with patch.object(cr, '_collect_system_health_artifacts', return_value={
                'lab_root': lab,
                'reports_dir': reports,
                'consolidated_ok': True,
                'consolidated_message': '',
                'consolidated_path': '',
                'audit_summary_txt': audit_txt,
                'audit_summary_json': audit_json,
                'audit_metrics_json': '',
                'shadow_report_path': '',
                'shadow_index_path': '',
                'phase_f_mismatch_path': '',
                'delivery_status_path': '',
            }):
                with patch.object(cr, 'get_health_lines', return_value=['health-line']):
                    ok, msg, pack_path = cr.open_latest_system_health_pack(
                        repo, lambda name, default: default, include_delivery_status=False)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            with open(pack_path, 'r', encoding='utf-8') as f:
                report_text = f.read()
            self.assertIn('Phase F lock context: reason=acquire_system_exit, owner_running=True, heartbeat_stale=False, pid=4321, diag=phase_f_lock_diag_rid-lock_20260323T143753Z.json', report_text)

    def test_open_latest_system_health_pack_uses_repo_json_when_lab_is_external(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            with tempfile.TemporaryDirectory() as external_lab:
                reports = os.path.join(external_lab, 'reports')
                json_dir = os.path.join(repo, 'json')
                os.makedirs(reports)
                os.makedirs(json_dir)
                with open(os.path.join(json_dir, 'config.json'), 'w', encoding='utf-8') as f:
                    json.dump(
                        {
                            'MediLink_Config': {
                                'fixedWidthSlices': {
                                    'service_slices': {
                                        'DATE1': [0, 10],
                                        'DOS': [10, 20],
                                    }
                                }
                            }
                        },
                        f,
                    )
                with open(os.path.join(json_dir, 'crosswalk.json'), 'w', encoding='utf-8') as f:
                    json.dump(
                        {
                            'mains_mapping': {
                                'slices': {
                                    'DATE1': [0, 10],
                                }
                            }
                        },
                        f,
                    )
                with open(os.path.join(reports, 'audit_migration_health_summary_latest.json'), 'w', encoding='utf-8') as f:
                    json.dump(
                        {
                            'overall': {'status': 'warn'},
                            'generated_at_utc': '2026-02-19T00:00:00Z',
                        },
                        f,
                    )
                with open(os.path.join(reports, 'audit_migration_health_summary_latest.txt'), 'w', encoding='utf-8') as f:
                    f.write('summary')
                with open(os.path.join(external_lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                    json.dump(
                        {
                            'last_phase_d_dat_telemetry': {
                                'dat_selected_count': 10,
                                'dat_qa_pass_count': 0,
                                'dat_qa_reject_count': 10,
                                'dat_canonical_record_count': 0,
                                'dat_qa_reject_counts_by_reason': {
                                    'QA_DAT_DATE_OF_SERVICE_MISSING': 10,
                                },
                            },
                        },
                        f,
                    )
                with patch.object(cr, '_collect_system_health_artifacts', return_value={
                    'lab_root': external_lab,
                    'reports_dir': reports,
                    'consolidated_ok': True,
                    'consolidated_message': '',
                    'consolidated_path': '',
                    'audit_summary_txt': os.path.join(reports, 'audit_migration_health_summary_latest.txt'),
                    'audit_summary_json': os.path.join(reports, 'audit_migration_health_summary_latest.json'),
                    'audit_metrics_json': '',
                    'shadow_report_path': '',
                    'shadow_index_path': '',
                    'phase_f_mismatch_path': '',
                    'delivery_status_path': '',
                }):
                    with patch.object(cr, 'get_health_lines', return_value=['health-line']):
                        ok, msg, path = cr.open_latest_system_health_pack(
                            repo, lambda name, default: default, include_delivery_status=False)
                self.assertTrue(ok)
                self.assertEqual(msg, '')
                with open(path, 'r', encoding='utf-8') as f:
                    text = f.read()
                self.assertIn(
                    'dat_parser_slice_snapshot=config_service(DOS:True,DATE1:True,count:2), crosswalk_mains(DOS:False,DATE1:True,count:1)',
                    text,
                )

    def test_open_latest_system_health_pack_includes_db_enrichment_overview(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            helper = TestGuidedPatientCompletenessRunbook()
            db_path = helper._seed_lab_db(lab)
            conn = sqlite3.connect(db_path)
            conn.execute("PRAGMA foreign_keys = ON")
            conn.execute(
                "UPDATE extracted_canonical_record SET canonical_json = ? WHERE canonical_record_id = 1",
                ('{"Patient ID":"22222","Surgery Date":"02/19/2026"}',)
            )
            conn.execute(
                "UPDATE extracted_canonical_record SET canonical_json = ? WHERE canonical_record_id = 2",
                ('{"Patient ID":"33333","Surgery Date":"02/20/2026"}',)
            )
            conn.execute(
                "INSERT INTO ingest_artifact "
                "(artifact_id, ingest_key, source_system, source_type, source_ref, payload_json, ingest_status) "
                "VALUES (4, 'k4', 'xp_local', 'docx', 's4', '{}', 'projected')"
            )
            conn.execute(
                "INSERT INTO extracted_canonical_record "
                "(canonical_record_id, artifact_id, canonical_type, canonical_key, extractor_version, canonical_json, provenance_json) "
                "VALUES (4, 4, 'docx_schedule', 'sched-1', 'canon_v1', '{\"patient_id\":\"22222\",\"schedule_key\":\"2026-02-19\"}', '{\"patient_id\":\"22222\",\"schedule_key\":\"2026-02-19\"}')"
            )
            conn.commit()
            conn.close()
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({'pipeline_state': 'completed', 'active_run_id': '', 'last_shadow_pipeline_run_id': 'rid-x'}, f)
            with patch.object(cr, '_collect_system_health_artifacts', return_value={
                'lab_root': lab,
                'reports_dir': reports,
                'consolidated_ok': True,
                'consolidated_message': '',
                'consolidated_path': '',
                'audit_summary_txt': '',
                'audit_summary_json': '',
                'audit_metrics_json': '',
                'shadow_report_path': '',
                'shadow_index_path': '',
                'phase_f_mismatch_path': '',
                'delivery_status_path': '',
            }):
                with patch.object(cr, 'get_health_lines', return_value=['health-line']):
                    ok, msg, path = cr.open_latest_system_health_pack(
                        repo, lambda name, default: default, include_delivery_status=False)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            assert isinstance(path, str)
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('DB enrichment overview (cumulative lab state):', text)
            self.assertIn('intake_sources=csv:3, docx:1', text)
            self.assertIn('upstream_csv_docx_join=csv_rows=2, csv_keys=2, docx_rows=1, docx_keys=1, overlap_keys=1, csv_only_keys=1, docx_only_keys=0, historical_duplicate_keys=0, csv_missing_join_key=0', text)
            self.assertIn('relational_depth=patient_count=3, coverage_count=1, encounter_count=1, claim_count=1, claim_line_count=1', text)

    def test_open_latest_system_health_pack_includes_recent_run_actuals(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            runs = [
                {
                    'run_id': 'rid-new',
                    'generated_at_utc': '2026-02-20T01:00:00Z',
                    'pipeline_ok': True,
                    'failed_phase': '',
                    'error_code': '',
                    'post_medisoft_status': 'exercised',
                    'post_medisoft_blocked_stage': '',
                    'phase_b_dat_manifest_rows_count': 7,
                    'phase_d_dat_selected_count': 7,
                    'phase_d_dat_qa_pass_count': 7,
                    'phase_d_dat_qa_reject_count': 0,
                    'phase_d_dat_canonical_record_count': 7,
                    'mtime': 200,
                },
                {
                    'run_id': 'rid-old',
                    'generated_at_utc': '2026-02-19T01:00:00Z',
                    'pipeline_ok': False,
                    'failed_phase': 'D',
                    'error_code': 'QA_DAT',
                    'post_medisoft_status': 'blocked',
                    'post_medisoft_blocked_stage': 'qa',
                    'phase_b_dat_manifest_rows_count': 5,
                    'phase_d_dat_selected_count': 5,
                    'phase_d_dat_qa_pass_count': 3,
                    'phase_d_dat_qa_reject_count': 2,
                    'phase_d_dat_canonical_record_count': 3,
                    'mtime': 100,
                },
            ]
            for item in runs:
                path = os.path.join(reports, 'shadow_run_report_{0}.json'.format(item['run_id']))
                with open(path, 'w', encoding='utf-8') as f:
                    json.dump({
                        'run_id': item['run_id'],
                        'generated_at_utc': item['generated_at_utc'],
                        'pipeline_ok': item['pipeline_ok'],
                        'failed_phase': item['failed_phase'],
                        'error_code': item['error_code'],
                        'post_medisoft_status': item['post_medisoft_status'],
                        'post_medisoft_blocked_stage': item['post_medisoft_blocked_stage'],
                        'phase_b_dat_manifest_rows_count': item['phase_b_dat_manifest_rows_count'],
                        'phase_d_dat_selected_count': item['phase_d_dat_selected_count'],
                        'phase_d_dat_qa_pass_count': item['phase_d_dat_qa_pass_count'],
                        'phase_d_dat_qa_reject_count': item['phase_d_dat_qa_reject_count'],
                        'phase_d_dat_canonical_record_count': item['phase_d_dat_canonical_record_count'],
                    }, f)
                os.utime(path, (item['mtime'], item['mtime']))
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({'pipeline_state': 'completed', 'active_run_id': '', 'last_shadow_pipeline_run_id': 'rid-new'}, f)
            with patch.object(cr, '_collect_system_health_artifacts', return_value={
                'lab_root': lab,
                'reports_dir': reports,
                'consolidated_ok': True,
                'consolidated_message': '',
                'consolidated_path': '',
                'audit_summary_txt': '',
                'audit_summary_json': '',
                'audit_metrics_json': '',
                'shadow_report_path': os.path.join(reports, 'shadow_run_report_rid-new.json'),
                'shadow_index_path': '',
                'phase_f_mismatch_path': '',
                'delivery_status_path': '',
            }):
                with patch.object(cr, 'get_health_lines', return_value=['health-line']):
                    ok, msg, path = cr.open_latest_system_health_pack(
                        repo, lambda name, default: default, include_delivery_status=False)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            assert isinstance(path, str)
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('Recent run actuals:', text)
            self.assertIn('rid-new: pipeline=ok, post_medisoft=exercised, manifest_rows=7, selected=7, qa_pass=7, qa_reject=0, canonical=7', text)
            self.assertIn('rid-old: pipeline=fail:D:QA_DAT, post_medisoft=blocked(qa), manifest_rows=5, selected=5, qa_pass=3, qa_reject=2, canonical=3', text)
            self.assertIn('delta_vs_previous=pipeline:fail:D:QA_DAT->ok, post_medisoft:blocked(qa)->exercised, manifest_rows:+2, selected:+2, qa_pass:+4, qa_reject:-2, canonical:+4', text)
            self.assertNotIn('regression_hints=', text)

    def test_open_latest_system_health_pack_includes_recent_run_regression_hints(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            runs = [
                {
                    'run_id': 'rid-new',
                    'generated_at_utc': '2026-02-20T01:00:00Z',
                    'pipeline_ok': True,
                    'failed_phase': '',
                    'error_code': '',
                    'post_medisoft_status': 'blocked',
                    'post_medisoft_blocked_stage': 'qa',
                    'phase_b_dat_manifest_rows_count': 2,
                    'phase_d_dat_selected_count': 2,
                    'phase_d_dat_qa_pass_count': 1,
                    'phase_d_dat_qa_reject_count': 1,
                    'phase_d_dat_canonical_record_count': 1,
                    'phase_d_dat_v2_inserted_total': 1,
                    'mtime': 200,
                },
                {
                    'run_id': 'rid-old',
                    'generated_at_utc': '2026-02-19T01:00:00Z',
                    'pipeline_ok': True,
                    'failed_phase': '',
                    'error_code': '',
                    'post_medisoft_status': 'exercised',
                    'post_medisoft_blocked_stage': '',
                    'phase_b_dat_manifest_rows_count': 6,
                    'phase_d_dat_selected_count': 6,
                    'phase_d_dat_qa_pass_count': 6,
                    'phase_d_dat_qa_reject_count': 0,
                    'phase_d_dat_canonical_record_count': 6,
                    'phase_d_dat_v2_inserted_total': 6,
                    'mtime': 100,
                },
            ]
            for item in runs:
                path = os.path.join(reports, 'shadow_run_report_{0}.json'.format(item['run_id']))
                with open(path, 'w', encoding='utf-8') as f:
                    json.dump({
                        'run_id': item['run_id'],
                        'generated_at_utc': item['generated_at_utc'],
                        'pipeline_ok': item['pipeline_ok'],
                        'failed_phase': item['failed_phase'],
                        'error_code': item['error_code'],
                        'post_medisoft_status': item['post_medisoft_status'],
                        'post_medisoft_blocked_stage': item['post_medisoft_blocked_stage'],
                        'phase_b_dat_manifest_rows_count': item['phase_b_dat_manifest_rows_count'],
                        'phase_d_dat_selected_count': item['phase_d_dat_selected_count'],
                        'phase_d_dat_qa_pass_count': item['phase_d_dat_qa_pass_count'],
                        'phase_d_dat_qa_reject_count': item['phase_d_dat_qa_reject_count'],
                        'phase_d_dat_canonical_record_count': item['phase_d_dat_canonical_record_count'],
                        'phase_d_dat_v2_inserted_total': item['phase_d_dat_v2_inserted_total'],
                    }, f)
                os.utime(path, (item['mtime'], item['mtime']))
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({'pipeline_state': 'completed', 'active_run_id': '', 'last_shadow_pipeline_run_id': 'rid-new'}, f)
            with patch.object(cr, '_collect_system_health_artifacts', return_value={
                'lab_root': lab,
                'reports_dir': reports,
                'consolidated_ok': True,
                'consolidated_message': '',
                'consolidated_path': '',
                'audit_summary_txt': '',
                'audit_summary_json': '',
                'audit_metrics_json': '',
                'shadow_report_path': os.path.join(reports, 'shadow_run_report_rid-new.json'),
                'shadow_index_path': '',
                'phase_f_mismatch_path': '',
                'delivery_status_path': '',
            }):
                with patch.object(cr, 'get_health_lines', return_value=['health-line']):
                    ok, msg, path = cr.open_latest_system_health_pack(
                        repo, lambda name, default: default, include_delivery_status=False)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            assert isinstance(path, str)
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('regression_hints=post_medisoft_regressed:exercised->blocked(qa)', text)
            self.assertIn('manifest_rows_drop:6->2', text)
            self.assertIn('selected_drop:6->2', text)
            self.assertIn('qa_pass_drop:6->1', text)
            self.assertIn('canonical_drop:6->1', text)
            self.assertIn('v2_inserted_drop:6->1', text)

    def test_open_latest_system_health_pack_flags_stale_audit_against_current_run(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            rid_current = 'rid-current'
            rid_old = 'rid-old'
            with open(os.path.join(reports, 'shadow_run_report_{0}.json'.format(rid_current)), 'w', encoding='utf-8') as f:
                json.dump({
                    'run_id': rid_current,
                    'generated_at_utc': '2026-02-20T01:00:00Z',
                    'pipeline_ok': True,
                    'failed_phase': '',
                    'error_code': '',
                    'post_medisoft_status': 'blocked',
                    'post_medisoft_blocked_stage': 'qa',
                    'phase_b_dat_manifest_rows_count': 3,
                    'phase_d_dat_selected_count': 3,
                    'phase_d_dat_qa_pass_count': 0,
                    'phase_d_dat_qa_reject_count': 3,
                    'phase_d_dat_canonical_record_count': 0,
                }, f)
            with open(os.path.join(reports, 'shadow_run_report_{0}.json'.format(rid_old)), 'w', encoding='utf-8') as f:
                json.dump({
                    'run_id': rid_old,
                    'generated_at_utc': '2026-02-19T01:00:00Z',
                    'pipeline_ok': True,
                    'failed_phase': '',
                    'error_code': '',
                    'post_medisoft_status': 'not_exercised',
                    'post_medisoft_blocked_stage': '',
                    'phase_b_dat_manifest_rows_count': 0,
                    'phase_d_dat_selected_count': 0,
                    'phase_d_dat_qa_pass_count': 0,
                    'phase_d_dat_qa_reject_count': 0,
                    'phase_d_dat_canonical_record_count': 0,
                }, f)
            with open(os.path.join(reports, 'audit_migration_health_summary_latest.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'generated_at_utc': '2026-02-19T00:00:00Z',
                    'overall': {'status': 'warn'},
                    'surfaces': {
                        'xp_local': {
                            'run_ids': {'shadow': rid_old},
                            'metrics': [
                                {'key': 'xp.post_medisoft_status', 'status': 'pass', 'value': 'not_exercised'},
                            ],
                        },
                    },
                }, f)
            with open(os.path.join(reports, 'audit_migration_health_summary_latest.txt'), 'w', encoding='utf-8') as f:
                f.write('summary')
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'pipeline_state': 'completed',
                    'active_run_id': '',
                    'last_shadow_pipeline_run_id': rid_current,
                    'last_phase_f_at_utc': '2026-02-20T01:01:00Z',
                    'last_discovery_dat_telemetry': {
                        'dat_manifest_rows_count': 3,
                    },
                    'last_phase_d_dat_telemetry': {
                        'dat_selected_count': 3,
                        'dat_qa_pass_count': 0,
                        'dat_qa_reject_count': 3,
                        'dat_canonical_record_count': 0,
                        'post_medisoft_blocked_stage': 'qa',
                    },
                }, f)
            with patch.object(cr, '_collect_system_health_artifacts', return_value={
                'lab_root': lab,
                'reports_dir': reports,
                'consolidated_ok': True,
                'consolidated_message': '',
                'consolidated_path': '',
                'audit_summary_txt': os.path.join(reports, 'audit_migration_health_summary_latest.txt'),
                'audit_summary_json': os.path.join(reports, 'audit_migration_health_summary_latest.json'),
                'audit_metrics_json': '',
                'shadow_report_path': os.path.join(reports, 'shadow_run_report_{0}.txt'.format(rid_old)),
                'shadow_index_path': '',
                'phase_f_mismatch_path': '',
                'delivery_status_path': '',
            }):
                with patch.object(cr, 'get_health_lines', return_value=['health-line']):
                    ok, msg, path = cr.open_latest_system_health_pack(
                        repo, lambda name, default: default, include_delivery_status=False)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            assert isinstance(path, str)
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('pack_anchor_run_id=rid-current', text)
            self.assertIn('Anchored completed-run snapshot:', text)
            self.assertIn('note: audit summary shadow_run_id=rid-old is older than current state last_shadow_pipeline_run_id=rid-current', text)
            self.assertIn('current state: post_medisoft=blocked(qa), manifest_rows=3, selected=3, qa_pass=0, qa_reject=3, canonical=0', text)
            self.assertIn('note: latest shadow_run_report pointer run_id=rid-old lags current state last_shadow_pipeline_run_id=rid-current', text)
            self.assertIn('rid-current: pipeline=ok, post_medisoft=blocked(qa), manifest_rows=3, selected=3, qa_pass=0, qa_reject=3, canonical=0', text)
            self.assertIn('audit hints suppressed because audit summary is older than current completed-run evidence.', text)


    def test_open_latest_system_health_pack_stale_audit_uses_phase_d_block_when_manifest_present(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            rid_current = 'rid-current'
            rid_old = 'rid-old'
            with open(os.path.join(reports, 'shadow_run_report_{0}.json'.format(rid_current)), 'w', encoding='utf-8') as f:
                json.dump({
                    'run_id': rid_current,
                    'generated_at_utc': '2026-02-20T01:00:00Z',
                    'pipeline_ok': True,
                    'failed_phase': '',
                    'error_code': '',
                    'post_medisoft_status': 'blocked',
                    'post_medisoft_blocked_stage': 'phase_d',
                    'phase_b_dat_manifest_rows_count': 3,
                    'phase_d_dat_selected_count': 0,
                    'phase_d_dat_qa_pass_count': 0,
                    'phase_d_dat_qa_reject_count': 0,
                    'phase_d_dat_canonical_record_count': 0,
                }, f)
            with open(os.path.join(reports, 'shadow_run_report_{0}.json'.format(rid_old)), 'w', encoding='utf-8') as f:
                json.dump({
                    'run_id': rid_old,
                    'generated_at_utc': '2026-02-19T01:00:00Z',
                    'pipeline_ok': True,
                    'failed_phase': '',
                    'error_code': '',
                    'post_medisoft_status': 'not_exercised',
                    'post_medisoft_blocked_stage': '',
                    'phase_b_dat_manifest_rows_count': 0,
                    'phase_d_dat_selected_count': 0,
                    'phase_d_dat_qa_pass_count': 0,
                    'phase_d_dat_qa_reject_count': 0,
                    'phase_d_dat_canonical_record_count': 0,
                }, f)
            with open(os.path.join(reports, 'audit_migration_health_summary_latest.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'generated_at_utc': '2026-02-19T00:00:00Z',
                    'overall': {'status': 'warn'},
                    'surfaces': {
                        'xp_local': {
                            'run_ids': {'shadow': rid_old},
                            'metrics': [
                                {'key': 'xp.post_medisoft_status', 'status': 'pass', 'value': 'not_exercised'},
                            ],
                        },
                    },
                }, f)
            with open(os.path.join(reports, 'audit_migration_health_summary_latest.txt'), 'w', encoding='utf-8') as f:
                f.write('summary')
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'pipeline_state': 'completed',
                    'active_run_id': '',
                    'last_shadow_pipeline_run_id': rid_current,
                    'last_phase_f_at_utc': '2026-02-20T01:01:00Z',
                    'last_discovery_dat_telemetry': {
                        'dat_manifest_rows_count': 3,
                    },
                    'last_phase_d_dat_telemetry': {
                        'dat_selected_count': 0,
                        'dat_qa_pass_count': 0,
                        'dat_qa_reject_count': 0,
                        'dat_canonical_record_count': 0,
                    },
                }, f)
            with patch.object(cr, '_collect_system_health_artifacts', return_value={
                'lab_root': lab,
                'reports_dir': reports,
                'consolidated_ok': True,
                'consolidated_message': '',
                'consolidated_path': '',
                'audit_summary_txt': os.path.join(reports, 'audit_migration_health_summary_latest.txt'),
                'audit_summary_json': os.path.join(reports, 'audit_migration_health_summary_latest.json'),
                'audit_metrics_json': '',
                'shadow_report_path': os.path.join(reports, 'shadow_run_report_{0}.txt'.format(rid_old)),
                'shadow_index_path': '',
                'phase_f_mismatch_path': '',
                'delivery_status_path': '',
            }):
                with patch.object(cr, 'get_health_lines', return_value=['health-line']):
                    ok, msg, path = cr.open_latest_system_health_pack(
                        repo, lambda name, default: default, include_delivery_status=False)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            assert isinstance(path, str)
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('current state: post_medisoft=blocked(phase_d), manifest_rows=3, selected=0, qa_pass=0, qa_reject=0, canonical=0', text)


    def test_open_latest_system_health_pack_runbook_uses_live_lock_transition_state(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            with open(os.path.join(reports, 'audit_migration_health_summary_latest.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'overall': {'status': 'pass'},
                    'generated_at_utc': '2026-02-20T00:00:00Z',
                }, f)
            with open(os.path.join(reports, 'audit_migration_health_summary_latest.txt'), 'w', encoding='utf-8') as f:
                f.write('summary')
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'pipeline_state': 'completed',
                    'active_run_id': '',
                    'last_shadow_pipeline_run_id': 'rid-last-completed',
                }, f)
            with open(os.path.join(lab, 'shadow_pipeline.lock'), 'w', encoding='utf-8') as f:
                f.write('heartbeat_at_utc=2026-02-20T00:01:00Z\n')
            with patch.object(cr, '_collect_system_health_artifacts', return_value={
                'lab_root': lab,
                'reports_dir': reports,
                'consolidated_ok': True,
                'consolidated_message': '',
                'consolidated_path': '',
                'audit_summary_txt': os.path.join(reports, 'audit_migration_health_summary_latest.txt'),
                'audit_summary_json': os.path.join(reports, 'audit_migration_health_summary_latest.json'),
                'audit_metrics_json': '',
                'shadow_report_path': '',
                'shadow_index_path': '',
                'phase_f_mismatch_path': '',
                'delivery_status_path': '',
            }):
                with patch.object(cr, 'get_health_lines', return_value=['health-line', 'Note: shadow_pipeline.lock is present; pipeline activity may still be in progress.']):
                    ok, msg, path = cr.open_latest_system_health_pack(
                        repo, lambda name, default: default, include_delivery_status=False)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            assert isinstance(path, str)
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('pipeline_state=running', text)
            self.assertIn('run_alignment=transition_in_progress', text)
            self.assertIn('Shadow pipeline activity is still in progress; wait for completion then refresh pack.', text)
            self.assertNotIn('pipeline_state=completed', text)
            self.assertNotIn('Pack is fresh and aligned; proceed with routine verification and evidence send if needed.', text)

    def test_open_latest_system_health_pack_prefers_anchor_dat_detail_over_live_state(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            shadow_json = os.path.join(reports, 'shadow_run_report_rid-b.json')
            with open(shadow_json, 'w', encoding='utf-8') as f:
                json.dump({
                    'run_id': 'rid-b',
                    'generated_at_utc': '2026-03-30T01:00:00Z',
                    'pipeline_ok': True,
                    'failed_phase': '',
                    'error_code': '',
                    'post_medisoft_status': 'blocked',
                    'post_medisoft_blocked_stage': 'qa',
                    'phase_b_dat_manifest_rows_count': 10,
                    'phase_b_dat_selection_mode': 'configured',
                    'phase_b_dat_selected_root_source_id': 'dat_cfg_1',
                    'phase_d_dat_selected_count': 10,
                    'phase_d_dat_qa_pass_count': 2,
                    'phase_d_dat_qa_reject_count': 8,
                    'phase_d_dat_qa_reject_counts_by_reason': {'QA_DAT_DATE_OF_SERVICE_MISSING': 8},
                    'phase_d_dat_field_presence_by_alias': {'records_seen': 10, 'PATID': 10, 'patient_id': 0, 'DOS': 0, 'DATE1': 10, 'date_of_service': 0, 'PAYERID': 0, 'INSID': 10, 'payer_id': 0},
                    'phase_d_dat_parse_diagnostics': {'tuple_parse_failure_count': 1, 'first_failure_class': 'ValueError'},
                    'phase_d_dat_file_prefix_counts': {'Z': 10},
                    'phase_d_dat_reject_file_prefix_counts': {'ZM': 8},
                    'phase_d_dat_canonical_record_count': 2,
                    'phase_d_entity_scope': 'v2',
                }, f)
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'pipeline_state': 'running',
                    'active_run_id': 'rid-live',
                    'last_shadow_pipeline_run_id': 'rid-b',
                    'last_discovery_dat_telemetry': {
                        'dat_manifest_rows_count': 99,
                        'dat_configured_root_missing_count': 0,
                        'dat_selected_root_source_id': 'live_cfg',
                        'dat_selection_mode': 'configured',
                    },
                    'last_phase_d_dat_telemetry': {
                        'dat_selected_count': 99,
                        'dat_qa_pass_count': 0,
                        'dat_qa_reject_count': 99,
                        'dat_canonical_record_count': 0,
                        'dat_field_presence_by_alias': {'records_seen': 99, 'PATID': 1, 'patient_id': 0, 'DOS': 0, 'DATE1': 0, 'date_of_service': 0, 'PAYERID': 0, 'INSID': 0, 'payer_id': 0},
                        'dat_qa_reject_counts_by_reason': {'QA_DAT_PATIENT_ANCHOR_MISSING': 99},
                        'dat_parse_diagnostics': {'tuple_parse_failure_count': 0, 'first_failure_class': ''},
                        'dat_file_prefix_counts': {'LIVE': 99},
                        'dat_reject_file_prefix_counts': {'LIVE': 99},
                    },
                }, f)
            with patch.object(cr, '_collect_system_health_artifacts', return_value={
                'lab_root': lab,
                'reports_dir': reports,
                'consolidated_ok': True,
                'consolidated_message': '',
                'consolidated_path': '',
                'audit_summary_txt': '',
                'audit_summary_json': '',
                'audit_metrics_json': '',
                'shadow_report_path': shadow_json,
                'shadow_index_path': '',
                'phase_f_mismatch_path': '',
                'delivery_status_path': '',
            }):
                with patch.object(cr, 'get_health_lines', return_value=['health-line']):
                    ok, msg, path = cr.open_latest_system_health_pack(
                        repo, lambda name, default: default, include_delivery_status=False)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            assert isinstance(path, str)
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('dat_alias_presence=records:10, PATID:10, patient_id:0, DOS:0, DATE1:10, date_of_service:0, PAYERID:0, INSID:10, payer_id:0', text)
            self.assertIn('dat_reject_mix_top=QA_DAT_DATE_OF_SERVICE_MISSING:8(1.000)', text)
            self.assertIn('dat_parse_exceptions=count:1, first:ValueError', text)
            self.assertIn('dat_file_prefix_mix=Z:10', text)
            self.assertNotIn('dat_file_prefix_mix=LIVE:99', text)

    def test_open_latest_system_health_pack_marks_pending_current_run_when_phase_f_json_missing(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'pipeline_state': 'completed',
                    'active_run_id': '',
                    'last_shadow_pipeline_run_id': 'rid-pending',
                }, f)
            with patch.object(cr, '_collect_system_health_artifacts', return_value={
                'lab_root': lab,
                'reports_dir': reports,
                'consolidated_ok': True,
                'consolidated_message': '',
                'consolidated_path': '',
                'audit_summary_txt': '',
                'audit_summary_json': '',
                'audit_metrics_json': '',
                'shadow_report_path': '',
                'shadow_index_path': '',
                'phase_f_mismatch_path': '',
                'delivery_status_path': '',
            }):
                with patch.object(cr, 'get_health_lines', return_value=['health-line']):
                    ok, msg, path = cr.open_latest_system_health_pack(
                        repo, lambda name, default: default, include_delivery_status=False)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            assert isinstance(path, str)
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('current_run=rid-pending: pending shadow_run_report JSON finalization', text)
            self.assertNotIn('none (no shadow_run_report_*.json payloads found)', text)



class TestRunCentricArtifactTools(unittest.TestCase):
    def test_open_latest_artifact_triage_pack_writes_latest_file(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            rid = '20260219-064740-157a78b1'
            for name, body in (
                ('artifact_discovery_summary_{0}.json'.format(rid), '{}'),
                ('ingest_write_summary_{0}.json'.format(rid), '{}'),
                ('qa_canonical_summary_{0}.json'.format(rid), '{}'),
                ('projection_parity_summary_{0}.json'.format(rid), '{}'),
                ('shadow_run_report_{0}.txt'.format(rid), 'ok'),
            ):
                with open(os.path.join(reports, name), 'w', encoding='utf-8') as f:
                    f.write(body)
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, path = cr.open_latest_artifact_triage_pack(repo)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            assert isinstance(path, str)
            self.assertTrue(os.path.exists(path))
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('Artifact Triage Pack', text)
            self.assertIn(rid, text)
            self.assertIn('bundle_scope_note=', text)
            self.assertIn('Runbook Interpretation:', text)
            self.assertIn('Consequential Diagnostics:', text)
            self.assertIn('What To Do Now:', text)

    def test_open_latest_artifact_triage_pack_incomplete_contains_actionable_runbook(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            rid = '20260219-071129-5d5c869f'
            with open(os.path.join(reports, 'ingest_write_summary_{0}.json'.format(rid)), 'w', encoding='utf-8') as f:
                f.write('{}')
            with open(os.path.join(reports, 'ingest_write_anomalies_{0}.jsonl'.format(rid)), 'w', encoding='utf-8') as f:
                f.write('[]')
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'pipeline_state': 'idle',
                    'active_run_id': '',
                    'last_shadow_pipeline_run_id': rid,
                    'last_error_code': 'PHASE_F_NOT_RUN',
                }, f)
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, path = cr.open_latest_artifact_triage_pack(repo)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            assert isinstance(path, str)
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('classification=INCOMPLETE', text)
            self.assertIn('Trigger full shadow pipeline (A->F)', text)
            self.assertIn('run_id_alignment=last_completed', text)
            self.assertIn('last_error_code=PHASE_F_NOT_RUN', text)

    def test_complete_artifacts_coherence_blocked_triage_and_index_align(self):
        """Failed/misaligned diagnostics => REVIEW_REQUIRED triage and cautious index (no optimistic handoff)."""
        from MediCafe import cloud_readiness as cr
        from MediCafe import cloud_readiness_artifact_tools as art
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            rid = '20260220-012634-daeb6154'
            other = '20260326-171733-607409d9'
            for name, body in (
                ('artifact_discovery_summary_{0}.json'.format(rid), '{}'),
                ('ingest_write_summary_{0}.json'.format(rid), '{}'),
                ('qa_canonical_summary_{0}.json'.format(rid), '{}'),
                ('projection_parity_summary_{0}.json'.format(rid), '{}'),
                ('shadow_run_report_{0}.txt'.format(rid), 'ok'),
            ):
                with open(os.path.join(reports, name), 'w', encoding='utf-8') as f:
                    f.write(body)
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'pipeline_state': 'failed',
                    'active_run_id': '',
                    'last_shadow_pipeline_run_id': other,
                    'last_error_code': 'PHASE_F_LOCK_FAIL',
                }, f)
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, snapshot = cr._build_run_artifact_snapshot(repo, run_id='')
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            triage_path = art.write_artifact_triage_pack(snapshot, latest_alias=False)
            index_path = art.write_run_artifact_index(snapshot, latest_alias=False)
            with open(triage_path, 'r', encoding='utf-8') as f:
                triage = f.read()
            with open(index_path, 'r', encoding='utf-8') as f:
                index = f.read()
            self.assertIn('classification=REVIEW_REQUIRED', triage)
            self.assertNotIn('classification=READY', triage)
            self.assertIn('bundle_scope_note=', triage)
            self.assertNotIn('This run has required artifacts across B..F', index)
            self.assertIn('lab diagnostics show pipeline failure or run misalignment', index)

    def test_lineage_contradiction_marks_bundle_review_required(self):
        from MediCafe import cloud_readiness_artifact_tools as art
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            anchor = '20260330-232228-c66fa6a1'
            phase_c_expected = '20260330-232310-dc3c07d5'
            phase_c_stale = '20260330-151330-34e4afb4'
            phase_d_run = '20260330-232319-8a25eb37'
            phase_e_run = '20260330-232320-f360d9bb'
            d_path = os.path.join(reports, 'qa_canonical_summary_{0}.json'.format(phase_d_run))
            shadow_path = os.path.join(reports, 'shadow_run_report_{0}.json'.format(anchor))
            with open(d_path, 'w', encoding='utf-8') as f:
                json.dump({
                    'run_id': phase_d_run,
                    'phase_c_summary_run_id_used_for_zero_selection': phase_c_stale,
                    'phase_c_context_mismatch_warning': 'run_cursor.last_phase_c_run_id={0} vs resolved_phase_c={1}'.format(phase_c_expected, phase_c_stale),
                }, f)
            with open(shadow_path, 'w', encoding='utf-8') as f:
                json.dump({
                    'run_id': anchor,
                    'phase_run_ids': {'C': phase_c_expected, 'D': phase_d_run, 'E': phase_e_run},
                }, f)
            snapshot = {
                'repo_root': repo,
                'lab_root': lab,
                'reports_dir': reports,
                'run_id': anchor,
                'pipeline_run_id': anchor,
                'phase_rows': [
                    {'code': 'B', 'name': 'B', 'status': 'complete', 'resolved_run_id': anchor, 'files': [], 'required_missing': []},
                    {'code': 'C', 'name': 'C', 'status': 'complete', 'resolved_run_id': phase_c_expected, 'files': [], 'required_missing': []},
                    {'code': 'D', 'name': 'D', 'status': 'complete', 'resolved_run_id': phase_d_run, 'files': [d_path], 'required_missing': []},
                    {'code': 'E', 'name': 'E', 'status': 'complete', 'resolved_run_id': phase_e_run, 'files': [], 'required_missing': []},
                    {'code': 'F', 'name': 'F', 'status': 'complete', 'resolved_run_id': anchor, 'files': [shadow_path], 'required_missing': []},
                ],
                'artifact_files': [],
                'context_files': [],
                'missing_required': [],
                'diagnostics_state': {},
                'nearest_complete_run_id': '',
                'recent_run_ids': [],
                'pipeline_running': False,
                'phase_run_ids': {'C': phase_c_expected, 'D': phase_d_run, 'E': phase_e_run, 'F': anchor},
                'resolution_decision': 'pipeline_phase_map',
                'resolution_confidence': 'high',
                'resolution_reason': 'phase map from anchored shadow payload',
                'resolution_notes': [],
            }
            snapshot['lineage_issues'] = art._collect_snapshot_lineage_issues(snapshot)
            triage_path = art.write_artifact_triage_pack(snapshot, latest_alias=False)
            index_path = art.write_run_artifact_index(snapshot, latest_alias=False)
            with open(triage_path, 'r', encoding='utf-8') as f:
                triage = f.read()
            with open(index_path, 'r', encoding='utf-8') as f:
                index = f.read()
            self.assertTrue(art.artifact_snapshot_coherence_blocked(snapshot))
            self.assertIn('classification=REVIEW_REQUIRED', triage)
            self.assertIn('phase_d_zero_selection_phase_c_run_id_mismatch', triage)
            self.assertIn('lineage_issue_count=', triage)
            self.assertIn('anchored phase lineage is contradictory', index)
            self.assertIn('cross-run contaminated', index)

    def test_latest_snapshot_prefers_diagnostics_run_over_optional_file_mtime(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            rid_current = '20260329-171213-current'
            rid_stale = '20260329-171213-stale'
            for name in (
                    'artifact_discovery_summary_{0}.json'.format(rid_current),
                    'ingest_write_summary_{0}.json'.format(rid_current),
                    'qa_canonical_summary_{0}.json'.format(rid_current),
                    'projection_parity_summary_{0}.json'.format(rid_current),
                    'shadow_run_report_{0}.json'.format(rid_current)):
                with open(os.path.join(reports, name), 'w', encoding='utf-8') as f:
                    f.write('{}')
            stale_optional = os.path.join(reports, 'shadow_evidence_index_{0}.json'.format(rid_stale))
            with open(stale_optional, 'w', encoding='utf-8') as f:
                f.write('{}')
            newer = time.time() + 60
            os.utime(stale_optional, (newer, newer))
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'pipeline_state': 'completed',
                    'active_run_id': '',
                    'last_shadow_pipeline_run_id': rid_current,
                }, f)
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, snapshot = cr._build_run_artifact_snapshot(repo, run_id='')
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            self.assertEqual(snapshot.get('run_id'), rid_current)
            self.assertNotEqual(snapshot.get('run_id'), rid_stale)

    def test_snapshot_prefers_single_canonical_summary_variant(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            rid = '20260329-171213-canonical'
            for prefix in (
                    'ingest_write_summary_',
                    'qa_canonical_summary_',
                    'projection_parity_summary_',
                    'shadow_run_report_'):
                with open(os.path.join(reports, '{0}{1}.json'.format(prefix, rid)), 'w', encoding='utf-8') as f:
                    f.write('{}')
            summary_txt = os.path.join(reports, 'artifact_discovery_summary_{0}.txt'.format(rid))
            summary_json = os.path.join(reports, 'artifact_discovery_summary_{0}.json'.format(rid))
            with open(summary_txt, 'w', encoding='utf-8') as f:
                f.write('older')
            with open(summary_json, 'w', encoding='utf-8') as f:
                f.write('{}')
            old = time.time() - 120
            new = time.time() - 30
            os.utime(summary_txt, (old, old))
            os.utime(summary_json, (new, new))
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'pipeline_state': 'completed',
                    'active_run_id': '',
                    'last_shadow_pipeline_run_id': rid,
                }, f)
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, snapshot = cr._build_run_artifact_snapshot(repo, run_id='')
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            discovery_rows = [row for row in snapshot.get('phase_rows', []) if row.get('code') == 'B']
            self.assertEqual(len(discovery_rows), 1)
            self.assertEqual(discovery_rows[0].get('files'), [summary_json])
            self.assertNotIn(summary_txt, snapshot.get('artifact_files', []))

    def test_open_run_artifact_index_for_run_id_requires_existing_run_artifacts(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, path = cr.open_run_artifact_index_for_run_id(repo, '20260219-000000-deadbeef')
            self.assertFalse(ok)
            self.assertIn('No artifacts found', msg)
            self.assertIsNone(path)

    def test_open_latest_run_artifact_index_passes_recommended_action(self):
        """Direct index openers should receive the same recommendation block as triage/bundle paths."""
        from MediCafe import cloud_readiness as cr

        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            snap = {
                'repo_root': repo,
                'lab_root': lab,
                'reports_dir': os.path.join(lab, 'reports'),
                'run_id': '20260330-120000-idxlatest01',
            }
            fake_rec = {
                'recommended_action_kind': 'historical_phase_d_reprocess',
                'historical_reprocess_preview_path': os.path.join(lab, 'reports', 'phase_d_historical_reprocess_preview_latest.txt'),
            }
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snap)):
                with patch.object(cr, '_recommended_action_for_snapshot', return_value=fake_rec) as mock_rec:
                    with patch.object(cr, '_write_run_artifact_index', return_value=os.path.join(repo, 'index.txt')) as mock_w:
                        ok, msg, path = cr.open_latest_run_artifact_index(repo)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            mock_rec.assert_called_once_with(snap)
            mock_w.assert_called_once()
            self.assertEqual(mock_w.call_args[1].get('recommended_action'), fake_rec)
            self.assertTrue(mock_w.call_args[1].get('latest_alias'))

    def test_open_run_artifact_index_for_run_id_passes_recommended_action(self):
        from MediCafe import cloud_readiness as cr

        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            rid = '20260330-120000-idxexplicit01'
            snap = {
                'repo_root': repo,
                'lab_root': lab,
                'reports_dir': os.path.join(lab, 'reports'),
                'run_id': rid,
            }
            fake_rec = {'recommended_action_kind': 'send_bundle', 'milestone_verdict': 'Not advanced'}
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snap)):
                with patch.object(cr, '_recommended_action_for_snapshot', return_value=fake_rec) as mock_rec:
                    with patch.object(cr, '_write_run_artifact_index', return_value=os.path.join(repo, 'index_run.txt')) as mock_w:
                        ok, msg, path = cr.open_run_artifact_index_for_run_id(repo, rid)
            self.assertTrue(ok)
            mock_rec.assert_called_once_with(snap)
            mock_w.assert_called_once()
            self.assertEqual(mock_w.call_args[1].get('recommended_action'), fake_rec)
            self.assertFalse(mock_w.call_args[1].get('latest_alias'))

    def test_recommended_action_for_snapshot_passes_snapshot_run_id_as_anchor(self):
        """Milestone lane must use snapshot run_id so evidence_coherence matches the opened run."""
        from MediCafe import cloud_readiness as cr

        snap = {
            'repo_root': '/tmp/repo',
            'lab_root': '/tmp/repo/lab',
            'run_id': 'opened-run-anchor-1',
            'reports_dir': '/tmp/repo/lab/reports',
        }
        with patch.object(cr, 'compute_operator_support_send_recommendation_core', return_value={}) as mock_core:
            cr._recommended_action_for_snapshot(snap)
        mock_core.assert_called_once()
        self.assertEqual(mock_core.call_args[1].get('recommendation_anchor_run_id'), 'opened-run-anchor-1')
        self.assertEqual(mock_core.call_args[1].get('recommendation_live_run_id'), 'opened-run-anchor-1')

    def test_open_run_artifact_index_for_pipeline_run_uses_phase_map(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            rid_f = '20260219-153853-fae6fbd9'
            rid_b = '20260219-153857-8110f389'
            rid_c = '20260219-153910-eb915f3c'
            rid_d = '20260219-153914-ec72027e'
            rid_e = '20260219-153915-4dc5298f'

            for name, body in (
                ('artifact_discovery_summary_{0}.json'.format(rid_b), '{}'),
                ('ingest_write_summary_{0}.json'.format(rid_c), '{}'),
                ('qa_canonical_summary_{0}.json'.format(rid_d), '{}'),
                ('projection_parity_summary_{0}.json'.format(rid_e), '{}'),
                ('shadow_run_report_{0}.txt'.format(rid_f), 'ok'),
            ):
                with open(os.path.join(reports, name), 'w', encoding='utf-8') as f:
                    f.write(body)

            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'pipeline_state': 'completed',
                    'active_run_id': '',
                    'last_shadow_pipeline_run_id': rid_f,
                    'last_shadow_pipeline_phase_run_ids': {
                        'B': rid_b,
                        'C': rid_c,
                        'D': rid_d,
                        'E': rid_e,
                    },
                }, f)

            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, path = cr.open_run_artifact_index_for_run_id(repo, rid_f)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            assert isinstance(path, str)
            self.assertTrue(os.path.exists(path))
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('resolution_decision=pipeline_phase_map', text)
            self.assertIn('phase_run_ids=B:{0},C:{1},D:{2},E:{3},F:{4}'.format(rid_b, rid_c, rid_d, rid_e, rid_f), text)
            self.assertIn('[B] Discovery status=COMPLETE resolved_run_id={0}'.format(rid_b), text)
            self.assertIn('[E] Projection status=COMPLETE resolved_run_id={0}'.format(rid_e), text)

    def test_open_run_artifact_index_for_pipeline_run_falls_back_when_map_stale(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            rid_f = '20260219-153853-fae6fbd9'

            for name, body in (
                ('artifact_discovery_summary_{0}.json'.format(rid_f), '{}'),
                ('ingest_write_summary_{0}.json'.format(rid_f), '{}'),
                ('qa_canonical_summary_{0}.json'.format(rid_f), '{}'),
                ('projection_parity_summary_{0}.json'.format(rid_f), '{}'),
                ('shadow_run_report_{0}.txt'.format(rid_f), 'ok'),
            ):
                with open(os.path.join(reports, name), 'w', encoding='utf-8') as f:
                    f.write(body)

            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'pipeline_state': 'completed',
                    'active_run_id': '',
                    'last_shadow_pipeline_run_id': rid_f,
                    'last_shadow_pipeline_phase_run_ids': {
                        'B': '20260219-bad-b',
                        'C': '20260219-bad-c',
                        'D': '20260219-bad-d',
                        'E': '20260219-bad-e',
                    },
                }, f)

            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, path = cr.open_run_artifact_index_for_run_id(repo, rid_f)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            assert isinstance(path, str)
            self.assertTrue(os.path.exists(path))
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('resolution_decision=single_token', text)
            self.assertIn('resolution_reason=phase_map_state_file_drift_fallback_single_token', text)
            self.assertIn('[B] Discovery status=COMPLETE resolved_run_id={0}'.format(rid_f), text)

    def test_open_run_artifact_index_ignores_unanchored_state_phase_map(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            rid_f = '20260219-153853-fae6fbd9'
            rid_b = '20260219-153857-8110f389'
            rid_c = '20260219-153910-eb915f3c'
            rid_d = '20260219-153914-ec72027e'
            rid_e = '20260219-153915-4dc5298f'

            for name, body in (
                ('artifact_discovery_summary_{0}.json'.format(rid_b), '{}'),
                ('ingest_write_summary_{0}.json'.format(rid_c), '{}'),
                ('qa_canonical_summary_{0}.json'.format(rid_d), '{}'),
                ('projection_parity_summary_{0}.json'.format(rid_e), '{}'),
                ('shadow_run_report_{0}.json'.format(rid_f), json.dumps({'source_summary_paths': []})),
                ('shadow_run_report_{0}.txt'.format(rid_f), 'ok'),
            ):
                with open(os.path.join(reports, name), 'w', encoding='utf-8') as f:
                    f.write(body)

            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'pipeline_state': 'completed',
                    'active_run_id': '',
                    'last_shadow_pipeline_run_id': '20260219-other-root-ffffffff',
                    'last_shadow_pipeline_phase_run_ids': {
                        'B': rid_b,
                        'C': rid_c,
                        'D': rid_d,
                        'E': rid_e,
                    },
                }, f)

            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, path = cr.open_run_artifact_index_for_run_id(repo, rid_f)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            assert isinstance(path, str)
            self.assertTrue(os.path.exists(path))
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('resolution_decision=single_token', text)
            self.assertIn('resolution_reason=state_phase_map_unanchored_fallback_single_token', text)
            self.assertIn('[B] Discovery status=MISSING resolved_run_id={0}'.format(rid_f), text)

    def test_open_run_artifact_index_prefers_shadow_lineage_when_state_conflicts(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            rid_f = '20260219-153853-fae6fbd9'
            rid_b_old = '20260219-153857-oldb'
            rid_c_old = '20260219-153910-oldc'
            rid_d_old = '20260219-153914-oldd'
            rid_e_old = '20260219-153915-olde'
            rid_b_new = '20260219-153857-newb'
            rid_c_new = '20260219-153910-newc'
            rid_d_new = '20260219-153914-newd'
            rid_e_new = '20260219-153915-newe'

            shadow_paths = [
                os.path.join(reports, 'artifact_discovery_summary_{0}.json'.format(rid_b_old)),
                os.path.join(reports, 'ingest_write_summary_{0}.json'.format(rid_c_old)),
                os.path.join(reports, 'qa_canonical_summary_{0}.json'.format(rid_d_old)),
                os.path.join(reports, 'projection_parity_summary_{0}.json'.format(rid_e_old)),
            ]
            with open(os.path.join(reports, 'shadow_run_report_{0}.json'.format(rid_f)), 'w', encoding='utf-8') as f:
                json.dump({'source_summary_paths': shadow_paths}, f)
            with open(os.path.join(reports, 'shadow_run_report_{0}.txt'.format(rid_f)), 'w', encoding='utf-8') as f:
                f.write('ok')

            with open(os.path.join(reports, 'artifact_discovery_summary_{0}.json'.format(rid_b_old)), 'w', encoding='utf-8') as f:
                f.write('{}')

            for rid, prefix in (
                (rid_b_new, 'artifact_discovery_summary_'),
                (rid_c_new, 'ingest_write_summary_'),
                (rid_d_new, 'qa_canonical_summary_'),
                (rid_e_new, 'projection_parity_summary_'),
            ):
                with open(os.path.join(reports, '{0}{1}.json'.format(prefix, rid)), 'w', encoding='utf-8') as f:
                    f.write('{}')

            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'pipeline_state': 'completed',
                    'active_run_id': '',
                    'last_shadow_pipeline_run_id': rid_f,
                    'last_shadow_pipeline_phase_run_ids': {
                        'B': rid_b_new,
                        'C': rid_c_new,
                        'D': rid_d_new,
                        'E': rid_e_new,
                    },
                }, f)

            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, path = cr.open_run_artifact_index_for_run_id(repo, rid_f)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            assert isinstance(path, str)
            self.assertTrue(os.path.exists(path))
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('resolution_decision=single_token', text)
            self.assertIn('[B] Discovery status=MISSING resolved_run_id={0}'.format(rid_f), text)

    def test_send_latest_run_evidence_bundle_includes_run_id_meta(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            rid = '20260219-064740-157a78b1'
            with open(os.path.join(reports, 'artifact_discovery_summary_{0}.json'.format(rid)), 'w', encoding='utf-8') as f:
                f.write('{}')
            with open(os.path.join(reports, 'ingest_write_summary_{0}.json'.format(rid)), 'w', encoding='utf-8') as f:
                f.write('{}')
            with open(os.path.join(reports, 'qa_canonical_summary_{0}.json'.format(rid)), 'w', encoding='utf-8') as f:
                f.write('{}')
            with open(os.path.join(reports, 'projection_parity_summary_{0}.json'.format(rid)), 'w', encoding='utf-8') as f:
                f.write('{}')
            with open(os.path.join(reports, 'shadow_run_report_{0}.txt'.format(rid)), 'w', encoding='utf-8') as f:
                f.write('ok')
            delivery_path = os.path.join(reports, 'report_delivery_status.txt')
            with open(delivery_path, 'w', encoding='utf-8') as f:
                f.write('delivery')

            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                with patch.object(cr, 'open_report_delivery_status', return_value=(True, '', delivery_path)):
                    with patch.object(cr, '_collect_delivery_diagnostics', return_value={}):
                        with patch.object(cr, 'collect_support_bundle', return_value='/tmp/run_bundle.zip') as mock_collect:
                            with patch.object(cr, '_submit_bundle_with_delivery_diagnostics', return_value=(True, '', {})):
                                ok, msg, data = cr.send_latest_run_evidence_bundle(repo)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            assert isinstance(data, dict)
            self.assertEqual(data.get('run_id'), rid)
            meta = mock_collect.call_args[1].get('extra_meta', {})
            self.assertEqual(meta.get('artifact_run_id'), rid)
            self.assertEqual(meta.get('send_source'), 'manual_run_evidence_bundle')
            self.assertTrue(meta.get('run_evidence_bundle'))
            self.assertEqual(meta.get('diagnostics_state_scope'), 'lab_root_current')
            self.assertEqual(meta.get('run_cursor_scope'), 'lab_root_current')
            self.assertEqual(meta.get('log_tail_scope'), 'latest_application_log')
            basenames = [x[0] for x in mock_collect.call_args[1].get('extra_files', [])]
            self.assertTrue(any(name.startswith('artifact_triage_pack_') for name in basenames))
            self.assertTrue(any(name.startswith('run_artifact_index_') for name in basenames))
            self.assertTrue(isinstance(data.get('runbook_lines', []), list))
            self.assertTrue(len(data.get('runbook_lines', [])) > 0)

    def test_send_latest_run_evidence_bundle_review_dat_qa_full_block_uses_anchor_snapshot(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            anchor = '20260329-171213-1ccb1c51'
            latest_other = '20260331-999999-otheriddd'
            for rid in (anchor, latest_other):
                for name_tmpl, body in (
                    ('artifact_discovery_summary_{0}.json', '{}'),
                    ('ingest_write_summary_{0}.json', '{}'),
                    ('qa_canonical_summary_{0}.json', '{}'),
                    ('projection_parity_summary_{0}.json', '{}'),
                ):
                    with open(os.path.join(reports, name_tmpl.format(rid)), 'w', encoding='utf-8') as f:
                        f.write(body)
                with open(os.path.join(reports, 'shadow_run_report_{0}.txt'.format(rid)), 'w', encoding='utf-8') as f:
                    f.write('ok')
            delivery_path = os.path.join(reports, 'report_delivery_status.txt')
            with open(delivery_path, 'w', encoding='utf-8') as f:
                f.write('delivery')
            qa_path = os.path.join(reports, 'qa_canonical_summary_{0}.json'.format(anchor))

            def snap_side_effect(r, run_id=''):
                rid = str(run_id or '').strip()
                if not rid:
                    return (True, '', {
                        'run_id': latest_other,
                        'lab_root': lab,
                        'reports_dir': reports,
                        'repo_root': r,
                        'artifact_files': [],
                        'context_files': [],
                    })
                if rid == anchor:
                    return (True, '', {
                        'run_id': anchor,
                        'lab_root': lab,
                        'reports_dir': reports,
                        'repo_root': r,
                        'artifact_files': [
                            os.path.join(reports, 'artifact_discovery_summary_{0}.json'.format(anchor)),
                            os.path.join(reports, 'qa_canonical_summary_{0}.json'.format(anchor)),
                        ],
                        'context_files': [],
                    })
                return (False, 'missing', {})

            rec_qa = {
                'recommended_action_kind': 'review_dat_qa_full_block',
                'recommended_report_kind': 'artifact_triage_pack',
                'recommendation_anchor_run_id': anchor,
                'action_preview': {
                    'anchor_run_id': anchor,
                    'phase_d_summary_path': qa_path,
                    'qa_reject_samples_path': '',
                    'shadow_run_report_path': os.path.join(reports, 'shadow_run_report_{0}.json'.format(anchor)),
                },
            }

            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                with patch.object(cr, 'open_report_delivery_status', return_value=(True, '', delivery_path)):
                    with patch.object(cr, '_collect_delivery_diagnostics', return_value={}):
                        with patch.object(cr, '_build_run_artifact_snapshot', side_effect=snap_side_effect):
                            with patch.object(cr, 'compute_operator_support_send_recommendation_core', return_value=rec_qa):
                                with patch.object(cr, '_collect_run_evidence_context_attachment', return_value=('', None)):
                                    with patch.object(cr, 'collect_support_bundle', return_value='/tmp/run_bundle.zip') as mock_collect:
                                        with patch.object(cr, '_submit_bundle_with_delivery_diagnostics', return_value=(True, '', {})):
                                            ok, msg, data = cr.send_latest_run_evidence_bundle(repo)
            self.assertTrue(ok)
            meta = mock_collect.call_args[1].get('extra_meta', {})
            self.assertEqual(meta.get('artifact_run_id'), anchor)
            self.assertEqual((data or {}).get('run_id'), anchor)

    def test_send_latest_run_evidence_bundle_runbook_when_coherence_blocked(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            rid = '20260219-064740-157a78b1'
            for name, body in (
                ('artifact_discovery_summary_{0}.json'.format(rid), '{}'),
                ('ingest_write_summary_{0}.json'.format(rid), '{}'),
                ('qa_canonical_summary_{0}.json'.format(rid), '{}'),
                ('projection_parity_summary_{0}.json'.format(rid), '{}'),
                ('shadow_run_report_{0}.txt'.format(rid), 'ok'),
            ):
                with open(os.path.join(reports, name), 'w', encoding='utf-8') as f:
                    f.write(body)
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'pipeline_state': 'failed',
                    'active_run_id': '',
                    'last_shadow_pipeline_run_id': '20260326-171733-other',
                    'last_error_code': 'PHASE_F_LOCK_FAIL',
                }, f)
            delivery_path = os.path.join(reports, 'report_delivery_status.txt')
            with open(delivery_path, 'w', encoding='utf-8') as f:
                f.write('delivery')
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                with patch.object(cr, 'open_report_delivery_status', return_value=(True, '', delivery_path)):
                    with patch.object(cr, '_collect_delivery_diagnostics', return_value={}):
                        with patch.object(cr, 'collect_support_bundle', return_value='/tmp/run_bundle.zip'):
                            with patch.object(cr, '_submit_bundle_with_delivery_diagnostics', return_value=(True, '', {})):
                                ok, msg, data = cr.send_latest_run_evidence_bundle(repo)
            self.assertTrue(ok)
            assert isinstance(data, dict)
            bq = data.get('bundle_quality') or {}
            self.assertEqual(bq.get('recommendation'), 'review_lab_state')
            lines = data.get('runbook_lines') or []
            self.assertTrue(any('Lab diagnostics conflict' in ln for ln in lines))

    def test_artifact_bundle_quality_coherence_blocked_incomplete_prefers_nearest_complete(self):
        """LOW + nearest_complete wins over review_lab_state when diagnostics are incoherent."""
        from MediCafe import cloud_readiness_artifact_tools as art

        def _row(st):
            return {
                'code': 'B',
                'name': 'Phase',
                'status': st,
                'resolved_run_id': '-',
                'files': [],
                'required_missing': [],
            }

        rows = [_row('complete'), _row('missing'), _row('missing'), _row('missing'), _row('missing')]
        snap = {
            'run_id': '20260220-curr',
            'nearest_complete_run_id': '20260220-nearest',
            'phase_rows': rows,
            'diagnostics_state': {
                'pipeline_state': 'failed',
                'active_run_id': '',
                'last_shadow_pipeline_run_id': '20260326-other',
            },
        }
        bq = art.artifact_bundle_quality(snap)
        self.assertEqual(bq.get('recommendation'), 'prefer_nearest_complete')
        self.assertEqual(bq.get('missing'), 4)

    def test_preferred_when_stable_coherence_blocked_incomplete_nearest_diagnostics_note(self):
        from MediCafe import cloud_readiness as cr
        from MediCafe import cloud_readiness_artifact_tools as art

        rows = []
        for i, st in enumerate(['complete', 'missing', 'missing', 'missing', 'missing']):
            rows.append({
                'code': 'BCDEF'[i] if i < 5 else 'B',
                'name': 'Phase',
                'status': st,
                'resolved_run_id': '-',
                'files': [],
                'required_missing': [],
            })
        snap = {
            'run_id': '20260220-curr',
            'nearest_complete_run_id': '20260220-nearest',
            'phase_rows': rows,
            'diagnostics_state': {
                'pipeline_state': 'failed',
                'active_run_id': '',
                'last_shadow_pipeline_run_id': '20260326-other',
            },
        }
        self.assertTrue(art.artifact_snapshot_coherence_blocked(snap))
        why = []
        pref = cr._preferred_when_stable_from_snapshot(True, snap, '', '20260220-nearest', why)
        self.assertEqual(pref, 'system_health')
        joined = ' '.join(why)
        self.assertIn('LOW', joined)
        self.assertIn('Lab diagnostics still conflict', joined)
        self.assertNotIn('Run-evidence files are complete', joined)

    def test_review_lab_state_missing_phases_without_nearest_message(self):
        """review_lab_state must not claim B..F complete when phases are missing."""
        from MediCafe import cloud_readiness as cr

        rows = []
        for i, st in enumerate(['complete', 'missing', 'missing', 'missing', 'missing']):
            rows.append({
                'code': 'BCDEF'[i],
                'name': 'Phase',
                'status': st,
                'resolved_run_id': '-',
                'files': [],
                'required_missing': [],
            })
        snap = {
            'run_id': '20260220-curr',
            'nearest_complete_run_id': '',
            'phase_rows': rows,
            'diagnostics_state': {
                'pipeline_state': 'failed',
                'active_run_id': '',
                'last_shadow_pipeline_run_id': '20260220-curr',
            },
        }
        bq = cr._artifact_bundle_quality(snap)
        self.assertEqual(bq.get('recommendation'), 'review_lab_state')
        why = []
        cr._preferred_when_stable_from_snapshot(True, snap, '', '', why)
        joined = ' '.join(why)
        self.assertIn('phase coverage is incomplete', joined)
        self.assertNotIn('Run-evidence files are complete', joined)

    def test_send_latest_run_evidence_bundle_runbook_incomplete_coherence_dual_hints(self):
        from MediCafe import cloud_readiness as cr

        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            rows = []
            codes = ('B', 'C', 'D', 'E', 'F')
            for i, st in enumerate(['complete', 'missing', 'missing', 'missing', 'missing']):
                rows.append({
                    'code': codes[i],
                    'name': 'Phase',
                    'status': st,
                    'resolved_run_id': '-',
                    'files': [],
                    'required_missing': [],
                })
            snap = {
                'lab_root': lab,
                'reports_dir': reports,
                'run_id': '20260219-partial',
                'pipeline_run_id': '20260219-partial',
                'phase_rows': rows,
                'artifact_files': [],
                'context_files': [],
                'missing_required': [],
                'diagnostics_state': {
                    'pipeline_state': 'failed',
                    'active_run_id': '',
                    'last_shadow_pipeline_run_id': '20260326-other',
                },
                'nearest_complete_run_id': '20260218-full',
                'recent_run_ids': [],
                'pipeline_running': False,
                'phase_run_ids': {},
                'resolution_decision': 'single_token',
                'resolution_confidence': 'unknown',
                'resolution_reason': '',
                'resolution_notes': [],
            }
            delivery_path = os.path.join(reports, 'report_delivery_status.txt')
            with open(delivery_path, 'w', encoding='utf-8') as f:
                f.write('delivery')
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snap)):
                with patch.object(cr, 'open_report_delivery_status', return_value=(True, '', delivery_path)):
                    with patch.object(cr, '_collect_delivery_diagnostics', return_value={}):
                        with patch.object(cr, 'collect_support_bundle', return_value='/tmp/run_bundle.zip'):
                            with patch.object(cr, '_submit_bundle_with_delivery_diagnostics', return_value=(True, '', {})):
                                ok, msg, data = cr.send_latest_run_evidence_bundle(repo)
            self.assertTrue(ok)
            assert isinstance(data, dict)
            bq = data.get('bundle_quality') or {}
            self.assertEqual(bq.get('recommendation'), 'prefer_nearest_complete')
            lines = data.get('runbook_lines') or []
            self.assertTrue(any('nearest complete run_id=' in ln for ln in lines))
            self.assertTrue(any('Lab diagnostics still conflict' in ln for ln in lines))


class TestGuidedPatientCompletenessRunbook(unittest.TestCase):
    def _seed_lab_db(self, lab_root):
        db_path = os.path.join(lab_root, 'unified_model_xp.db')
        schema_path = os.path.join(_PROJECT_ROOT, 'sql', 'unified_relational_model_v1.sql')
        with open(schema_path, 'r', encoding='utf-8') as f:
            schema_sql = f.read()
        conn = sqlite3.connect(db_path)
        conn.execute("PRAGMA foreign_keys = ON")
        conn.executescript(schema_sql)

        conn.execute(
            "INSERT INTO ingest_artifact "
            "(artifact_id, ingest_key, source_system, source_type, source_ref, payload_json, ingest_status) "
            "VALUES (1, 'k1', 'xp_local', 'csv', 's1', '{}', 'projected')"
        )
        conn.execute(
            "INSERT INTO ingest_artifact "
            "(artifact_id, ingest_key, source_system, source_type, source_ref, payload_json, ingest_status) "
            "VALUES (2, 'k2', 'xp_local', 'csv', 's2', '{}', 'qa_failed')"
        )
        conn.execute(
            "INSERT INTO ingest_artifact "
            "(artifact_id, ingest_key, source_system, source_type, source_ref, payload_json, ingest_status) "
            "VALUES (3, 'k3', 'xp_local', 'csv', 's3', '{}', 'ingested')"
        )

        conn.execute(
            "INSERT INTO patient (patient_id, patient_key, external_patient_id, full_name, birth_date, source_system) "
            "VALUES (1, 'pk-risk', '11111', '', '', 'xp_local')"
        )
        conn.execute(
            "INSERT INTO patient (patient_id, patient_key, external_patient_id, full_name, birth_date, source_system) "
            "VALUES (2, 'pk-good', '22222', 'Baseline Patient', '1980-01-01', 'xp_local')"
        )
        conn.execute(
            "INSERT INTO patient (patient_id, patient_key, external_patient_id, full_name, birth_date, source_system) "
            "VALUES (3, 'pk-reject', '33333', 'Reject Patient', '1990-02-02', 'xp_local')"
        )
        conn.execute(
            "INSERT INTO payer (payer_id, payer_key, payer_external_id, payer_name, endpoint_name) "
            "VALUES (1, 'payer-1', 'P1', 'Payer One', 'endpoint')"
        )
        conn.execute(
            "INSERT INTO insurance_plan (plan_id, plan_key, payer_id, medisoft_insurance_ids_json) "
            "VALUES (1, 'plan-1', 1, '[]')"
        )
        conn.execute(
            "INSERT INTO coverage (coverage_id, coverage_key, patient_id, plan_id, active_flag) "
            "VALUES (1, 'cov-good', 2, 1, 1)"
        )
        conn.execute(
            "INSERT INTO encounter (encounter_id, encounter_key, patient_id, date_of_service, source_artifact_id) "
            "VALUES (1, 'enc-good', 2, '2026-02-19', 1)"
        )
        conn.execute(
            "INSERT INTO claim (claim_id, claim_key, encounter_id, payer_id, claim_number, source_artifact_id) "
            "VALUES (1, 'claim-good', 1, 1, 'CLM-222', 1)"
        )
        conn.execute(
            "INSERT INTO claim_line (claim_line_id, claim_line_key, claim_id, line_number) "
            "VALUES (1, 'line-good', 1, 1)"
        )
        conn.execute(
            "INSERT INTO extracted_canonical_record "
            "(canonical_record_id, artifact_id, canonical_type, canonical_key, extractor_version, canonical_json, provenance_json) "
            "VALUES (1, 1, 'patient_csv_row', 'pk-good', 'canon_v1', '{}', '{}')"
        )
        conn.execute(
            "INSERT INTO projection_result "
            "(projection_id, canonical_record_id, projection_type, projection_version, projection_status, projected_json) "
            "VALUES (1, 1, 'patient_v1', 'v1', 'success', '{\"external_patient_id\":\"22222\"}')"
        )
        conn.execute(
            "INSERT INTO extracted_canonical_record "
            "(canonical_record_id, artifact_id, canonical_type, canonical_key, extractor_version, canonical_json, provenance_json) "
            "VALUES (2, 2, 'patient_csv_row', 'pk-reject', 'canon_v1', '{}', '{}')"
        )
        conn.execute(
            "INSERT INTO projection_result "
            "(projection_id, canonical_record_id, projection_type, projection_version, projection_status, projected_json) "
            "VALUES (2, 2, 'patient_v1', 'v1', 'rejected', '{\"reject_reason\":\"missing_required_fields\"}')"
        )
        conn.execute(
            "INSERT INTO qa_result "
            "(qa_result_id, artifact_id, qa_stage, qa_version, status, reject_code, reject_reason, deterministic_key) "
            "VALUES (1, 2, 'phase_d', 'v1', 'reject', 'QA_REQUIRED', 'missing patient id', 'd1')"
        )
        conn.execute(
            "INSERT INTO replay_queue (replay_id, artifact_id, reason_code, status, attempt_count) "
            "VALUES (1, 2, 'QA_REQUIRED', 'pending', 0)"
        )
        conn.commit()
        conn.close()
        return db_path

    def test_get_guided_patient_completeness_options_returns_enriched_letters(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            db_path = self._seed_lab_db(lab)
            conn = sqlite3.connect(db_path)
            conn.execute("PRAGMA foreign_keys = ON")
            conn.execute(
                "UPDATE extracted_canonical_record SET canonical_json = ? WHERE canonical_record_id = 1",
                ('{"Patient ID":"22222","Surgery Date":"02/19/2026"}',)
            )
            conn.execute(
                "UPDATE extracted_canonical_record SET canonical_json = ? WHERE canonical_record_id = 2",
                ('{"Patient ID":"33333","Surgery Date":"02/20/2026"}',)
            )
            conn.execute(
                "INSERT INTO ingest_artifact "
                "(artifact_id, ingest_key, source_system, source_type, source_ref, payload_json, ingest_status) "
                "VALUES (4, 'k4', 'xp_local', 'docx', 's4', '{}', 'projected')"
            )
            conn.execute(
                "INSERT INTO extracted_canonical_record "
                "(canonical_record_id, artifact_id, canonical_type, canonical_key, extractor_version, canonical_json, provenance_json) "
                "VALUES (4, 4, 'docx_schedule', 'sched-1', 'canon_v1', '{\"patient_id\":\"22222\",\"schedule_key\":\"2026-02-19\"}', '{\"patient_id\":\"22222\",\"schedule_key\":\"2026-02-19\"}')"
            )
            conn.commit()
            conn.close()
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({'pipeline_state': 'idle', 'last_shadow_pipeline_run_id': '20260219-071129-5d5c869f'}, f)
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, data = cr.get_guided_patient_completeness_options(repo)
            self.assertTrue(ok)
            self.assertIn('options ready', msg.lower())
            assert isinstance(data, dict)
            options = data.get('options', [])
            codes = [x.get('code') for x in options]
            self.assertIn('A', codes)
            self.assertIn('D', codes)
            self.assertIn('B', codes)
            self.assertTrue(any(str(x.get('display_id')) == '33333' for x in options if x.get('code') == 'B'))
            self.assertTrue(isinstance(data.get('runbook_lines', []), list))
            self.assertTrue(any('data_plane_status=' in line for line in data.get('runbook_lines', [])))

    def test_get_guided_patient_completeness_options_no_patient_rows_returns_guidance(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            db_path = os.path.join(lab, 'unified_model_xp.db')
            conn = sqlite3.connect(db_path)
            conn.close()
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'pipeline_state': 'completed',
                    'active_run_id': '',
                    'last_shadow_pipeline_run_id': '20260219-071129-5d5c869f',
                }, f)
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, data = cr.get_guided_patient_completeness_options(repo)
            self.assertFalse(ok)
            self.assertIn('data-state', msg.lower())
            assert isinstance(data, dict)
            self.assertEqual(data.get('condition'), 'no_patient_rows')
            self.assertEqual(data.get('options', []), [])
            runbook_lines = data.get('runbook_lines', [])
            self.assertTrue(any('patient_count=0' in line for line in runbook_lines))
            self.assertTrue(any('qa_reject_count=' in line for line in runbook_lines))
            self.assertTrue(any('replay_pending_count=' in line for line in runbook_lines))
            self.assertTrue(any('projection_success_count=' in line for line in runbook_lines))
            self.assertTrue(any('last_shadow_pipeline_run_id=20260219-071129-5d5c869f' in line for line in runbook_lines))
            self.assertTrue(any(str(line).strip() == 'What To Do Now:' for line in runbook_lines))
            self.assertTrue(any(str(line).strip().startswith('1) ') for line in runbook_lines))
            actions = data.get('actions', [])
            self.assertTrue(isinstance(actions, list))
            self.assertTrue(len(actions) >= 2)
            self.assertTrue(any('investigate' in a.lower() for a in actions))

    def test_open_guided_patient_completeness_runbook_writes_report(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            self._seed_lab_db(lab)
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({'pipeline_state': 'idle', 'last_shadow_pipeline_run_id': '20260219-071129-5d5c869f'}, f)
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, path = cr.open_guided_patient_completeness_runbook(repo, 'B')
            self.assertTrue(ok)
            self.assertIn('verdict=', msg)
            assert isinstance(path, str)
            self.assertTrue(os.path.exists(path))
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('Patient Completeness Runbook', text)
            self.assertIn('Runbook Interpretation:', text)
            self.assertIn('What To Do Now:', text)
            self.assertIn('Artifact pointers:', text)

    def test_open_guided_patient_completeness_runbook_prefers_dat_qa_action_when_latest_run_blocked(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            self._seed_lab_db(lab)
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'pipeline_state': 'completed',
                    'last_shadow_pipeline_run_id': '20260323-013957-de087671',
                    'last_phase_d_dat_telemetry': {
                        'dat_selected_count': 3,
                        'dat_qa_reject_count': 3,
                        'post_medisoft_blocked_stage': 'qa',
                    },
                }, f)
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, path = cr.open_guided_patient_completeness_runbook(repo, 'A')
            self.assertTrue(ok)
            assert isinstance(path, str)
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('Inspect latest DAT QA rejects in qa_reject_samples; latest run is blocked at Phase D QA (selected=3, qa_reject=3).', text)
            self.assertNotIn('Re-run Phase C ingest or full A->F pipeline to populate missing encounter/claim chain.', text)

    def test_patient_flow_reference_options_preserve_chain_fields(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            self._seed_lab_db(lab)
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({'pipeline_state': 'idle', 'last_shadow_pipeline_run_id': '20260219-071129-5d5c869f'}, f)
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, data = cr.get_patient_flow_reference_options(repo, limit=10)
            self.assertTrue(ok)
            assert isinstance(data, dict)
            options = data.get('options', [])
            self.assertTrue(len(options) > 0)
            first = options[0]
            self.assertIn('claim_count', first)
            self.assertIn('canonical_count', first)
            self.assertIn('full_name', first)

    def test_find_patient_option_by_reference_prefers_external_id_over_numeric_patient_id(self):
        from MediCafe import cloud_readiness_patient_tools as pt
        rows = [
            {'patient_id': 33333, 'patient_key': 'pk-a', 'external_patient_id': '55555'},
            {'patient_id': 42, 'patient_key': 'pk-b', 'external_patient_id': '33333'},
        ]
        picked = pt.find_patient_option_by_reference(rows, '33333')
        assert isinstance(picked, dict)
        self.assertEqual(picked.get('patient_id'), 42)

    def test_get_patient_flow_reference_options_autopopulates_refs(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            self._seed_lab_db(lab)
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({'pipeline_state': 'idle', 'last_shadow_pipeline_run_id': '20260219-071129-5d5c869f'}, f)
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, data = cr.get_patient_flow_reference_options(repo, limit=10)
            self.assertTrue(ok)
            self.assertIn('options ready', msg.lower())
            assert isinstance(data, dict)
            options = data.get('options', [])
            self.assertTrue(len(options) > 0)
            self.assertTrue(any(str(x.get('patient_ref')) == '33333' for x in options))

    def test_open_patient_flow_runbook_by_external_patient_id_writes_report(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            self._seed_lab_db(lab)
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({'pipeline_state': 'idle', 'last_shadow_pipeline_run_id': '20260219-071129-5d5c869f'}, f)
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, path = cr.open_patient_flow_runbook(repo, '33333')
            self.assertTrue(ok)
            self.assertIn('Patient flow runbook generated', msg)
            assert isinstance(path, str)
            self.assertTrue(os.path.exists(path))
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('Data View Samples (first 3 rows per table):', text)
            self.assertIn(' - patient:', text)
            self.assertIn(' - claim:', text)
            self.assertIn(' - qa_result:', text)

    def test_open_patient_flow_runbook_unknown_patient_returns_not_found(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            self._seed_lab_db(lab)
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({'pipeline_state': 'idle', 'last_shadow_pipeline_run_id': '20260219-071129-5d5c869f'}, f)
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, path = cr.open_patient_flow_runbook(repo, 'does-not-exist')
            self.assertFalse(ok)
            self.assertIn('not found', msg.lower())
            self.assertIsNone(path)

    def test_open_data_plane_audit_report_writes_readable_snapshot(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            db_path = self._seed_lab_db(lab)
            conn = sqlite3.connect(db_path)
            conn.execute("PRAGMA foreign_keys = ON")
            conn.execute(
                "UPDATE extracted_canonical_record SET canonical_json = ? WHERE canonical_record_id = 1",
                ('{"Patient ID":"22222","Surgery Date":"02/19/2026"}',)
            )
            conn.execute(
                "UPDATE extracted_canonical_record SET canonical_json = ? WHERE canonical_record_id = 2",
                ('{"Patient ID":"33333","Surgery Date":"02/20/2026"}',)
            )
            conn.execute(
                "INSERT INTO ingest_artifact "
                "(artifact_id, ingest_key, source_system, source_type, source_ref, payload_json, ingest_status) "
                "VALUES (4, 'k4', 'xp_local', 'docx', 's4', '{}', 'projected')"
            )
            conn.execute(
                "INSERT INTO extracted_canonical_record "
                "(canonical_record_id, artifact_id, canonical_type, canonical_key, extractor_version, canonical_json, provenance_json) "
                "VALUES (4, 4, 'docx_schedule', 'sched-1', 'canon_v1', '{\"patient_id\":\"22222\",\"schedule_key\":\"2026-02-19\"}', '{\"patient_id\":\"22222\",\"schedule_key\":\"2026-02-19\"}')"
            )
            conn.commit()
            conn.close()
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({'pipeline_state': 'idle', 'last_shadow_pipeline_run_id': '20260219-071129-5d5c869f'}, f)
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, path = cr.open_data_plane_audit_report(repo, report_type='overview', limit=20)
            self.assertTrue(ok)
            self.assertIn('report generated', msg.lower())
            assert isinstance(path, str)
            self.assertTrue(os.path.exists(path))
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('DB Data Audit Report', text)
            self.assertIn('Data Plane Summary:', text)
            self.assertIn('DB Enrichment Overview:', text)
            self.assertIn('active backlog only', text)
            self.assertIn('Table row counts:', text)
            self.assertIn('intake_sources=csv:3, docx:1', text)
            self.assertIn('upstream_csv_docx_join=csv_rows=2, csv_keys=2, docx_rows=1, docx_keys=1, overlap_keys=1, csv_only_keys=1, docx_only_keys=0, historical_duplicate_keys=0, csv_missing_join_key=0', text)
            self.assertIn('join_scope_note=overlap/csv_only/docx_only describe deduped cumulative unique join keys; historical_duplicate_pressure captures repeated-key pressure across stored DB history and is not unresolved ambiguity by itself', text)
            self.assertIn('relational_depth=patient_count=3, coverage_count=1, encounter_count=1, claim_count=1, claim_line_count=1', text)
            self.assertIn('Patient sample rows:', text)
            self.assertIn('created_at is DB row creation timestamp', text)
            self.assertIn('33333', text)

    def test_open_data_plane_audit_report_includes_historical_duplicate_examples(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            db_path = self._seed_lab_db(lab)
            conn = sqlite3.connect(db_path)
            conn.execute("PRAGMA foreign_keys = ON")
            conn.execute(
                "UPDATE ingest_artifact SET source_type = 'file_csv' WHERE artifact_id IN (1,2,3)"
            )
            conn.execute(
                "UPDATE extracted_canonical_record SET canonical_json = ? WHERE canonical_record_id = 1",
                ('{"Patient ID":"22222","Surgery Date":"02/19/2026"}',)
            )
            conn.execute(
                "UPDATE extracted_canonical_record SET canonical_json = ? WHERE canonical_record_id = 2",
                ('{"Patient ID":"22222","Surgery Date":"02/19/2026"}',)
            )
            conn.execute(
                "INSERT INTO ingest_artifact "
                "(artifact_id, ingest_key, source_system, source_type, source_ref, payload_json, ingest_status) "
                "VALUES (4, 'k4', 'xp_local', 'file_docx', 's4', '{}', 'projected')"
            )
            conn.execute(
                "INSERT INTO ingest_artifact "
                "(artifact_id, ingest_key, source_system, source_type, source_ref, payload_json, ingest_status) "
                "VALUES (5, 'k5', 'xp_local', 'file_docx', 's5', '{}', 'projected')"
            )
            conn.execute(
                "INSERT INTO extracted_canonical_record "
                "(canonical_record_id, artifact_id, canonical_type, canonical_key, extractor_version, canonical_json, provenance_json) "
                "VALUES (4, 4, 'docx_schedule', 'sched-1', 'canon_v1', '{\"patient_id\":\"22222\",\"schedule_key\":\"2026-02-19\"}', '{\"patient_id\":\"22222\",\"schedule_key\":\"2026-02-19\"}')"
            )
            conn.execute(
                "INSERT INTO extracted_canonical_record "
                "(canonical_record_id, artifact_id, canonical_type, canonical_key, extractor_version, canonical_json, provenance_json) "
                "VALUES (5, 5, 'docx_schedule', 'sched-2', 'canon_v1', '{\"patient_id\":\"22222\",\"schedule_key\":\"2026-02-19\"}', '{\"patient_id\":\"22222\",\"schedule_key\":\"2026-02-19\"}')"
            )
            conn.commit()
            conn.close()
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({'pipeline_state': 'idle', 'last_shadow_pipeline_run_id': '20260219-071129-5d5c869f'}, f)
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, path = cr.open_data_plane_audit_report(repo, report_type='overview', limit=20)
            self.assertTrue(ok)
            self.assertIn('report generated', msg.lower())
            assert isinstance(path, str)
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('historical_duplicate_breakdown=both_sources=1, csv_only=0, docx_only=0', text)
            self.assertIn('historical_duplicate_examples=22222|02-19-2026(csv=2,docx=2)', text)

    def test_collect_db_enrichment_summary_distinguishes_overlap_from_historical_duplicates(self):
        from MediCafe import cloud_readiness_patient_tools as pt
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab, 'reports'))
            db_path = self._seed_lab_db(lab)
            conn = sqlite3.connect(db_path)
            conn.execute("PRAGMA foreign_keys = ON")
            conn.execute(
                "UPDATE ingest_artifact SET source_type = 'file_csv' WHERE artifact_id IN (1,2,3)"
            )
            conn.execute(
                "UPDATE extracted_canonical_record SET canonical_json = ? WHERE canonical_record_id = 1",
                ('{"Patient ID":"22222","Surgery Date":"02/19/2026"}',)
            )
            conn.execute(
                "UPDATE extracted_canonical_record SET canonical_json = ? WHERE canonical_record_id = 2",
                ('{"Patient ID":"22222","Surgery Date":"02/19/2026"}',)
            )
            conn.execute(
                "INSERT INTO ingest_artifact "
                "(artifact_id, ingest_key, source_system, source_type, source_ref, payload_json, ingest_status) "
                "VALUES (4, 'k4', 'xp_local', 'file_docx', 's4', '{}', 'projected')"
            )
            conn.execute(
                "INSERT INTO ingest_artifact "
                "(artifact_id, ingest_key, source_system, source_type, source_ref, payload_json, ingest_status) "
                "VALUES (5, 'k5', 'xp_local', 'file_docx', 's5', '{}', 'projected')"
            )
            conn.execute(
                "INSERT INTO extracted_canonical_record "
                "(canonical_record_id, artifact_id, canonical_type, canonical_key, extractor_version, canonical_json, provenance_json) "
                "VALUES (4, 4, 'docx_schedule', 'sched-1', 'canon_v1', '{\"patient_id\":\"22222\",\"schedule_key\":\"2026-02-19\"}', '{\"patient_id\":\"22222\",\"schedule_key\":\"2026-02-19\"}')"
            )
            conn.execute(
                "INSERT INTO extracted_canonical_record "
                "(canonical_record_id, artifact_id, canonical_type, canonical_key, extractor_version, canonical_json, provenance_json) "
                "VALUES (5, 5, 'docx_schedule', 'sched-2', 'canon_v1', '{\"patient_id\":\"22222\",\"schedule_key\":\"2026-02-19\"}', '{\"patient_id\":\"22222\",\"schedule_key\":\"2026-02-19\"}')"
            )
            conn.commit()
            conn.close()
            summary = pt.collect_db_enrichment_summary(lab)
            self.assertTrue(summary.get('ok'))
            self.assertEqual(summary.get('ingest_source_type_counts', {}).get('csv'), 3)
            self.assertEqual(summary.get('ingest_source_type_counts', {}).get('docx'), 2)
            join = summary.get('csv_docx_join', {})
            self.assertEqual(join.get('csv_candidate_count'), 2)
            self.assertEqual(join.get('docx_candidate_count'), 2)
            self.assertEqual(join.get('overlap_join_key_count'), 1)
            self.assertEqual(join.get('csv_only_join_key_count'), 0)
            self.assertEqual(join.get('docx_only_join_key_count'), 0)
            self.assertEqual(join.get('historical_duplicate_key_count'), 1)
            self.assertEqual(join.get('ambiguous_count'), 0)
            examples = join.get('historical_duplicate_examples', [])
            self.assertEqual(len(examples), 1)
            self.assertEqual(examples[0].get('join_key'), '22222|02-19-2026')
            self.assertEqual(examples[0].get('csv_count'), 2)
            self.assertEqual(examples[0].get('docx_count'), 2)

    def test_open_latest_data_plane_audit_report_returns_latest_file(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            self._seed_lab_db(lab)
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({'pipeline_state': 'idle', 'last_shadow_pipeline_run_id': '20260219-071129-5d5c869f'}, f)
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok_gen, _, path_gen = cr.open_data_plane_audit_report(repo, report_type='overview', limit=10)
                ok_latest, msg_latest, path_latest = cr.open_latest_data_plane_audit_report(repo, report_type='overview')
            self.assertTrue(ok_gen)
            self.assertTrue(path_gen and os.path.exists(path_gen))
            self.assertTrue(ok_latest)
            self.assertEqual(msg_latest, '')
            assert isinstance(path_latest, str)
            self.assertTrue(os.path.exists(path_latest))
            self.assertTrue(os.path.basename(path_latest).startswith('db_data_audit_overview_'))

    def test_open_data_plane_audit_report_uses_version_scoped_quality_counters(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            db_path = self._seed_lab_db(lab)

            conn = sqlite3.connect(db_path)
            conn.execute("PRAGMA foreign_keys = ON")
            conn.execute(
                "INSERT INTO qa_result "
                "(qa_result_id, artifact_id, qa_stage, qa_version, status, reject_code, reject_reason, deterministic_key) "
                "VALUES (2, 2, 'phase_d', 'qa_v2', 'reject', 'QA_REQUIRED', 'missing patient id', 'd2')"
            )
            conn.execute(
                "INSERT INTO projection_result "
                "(projection_id, canonical_record_id, projection_type, projection_version, projection_status, projected_json) "
                "VALUES (3, 1, 'patient_v1', 'proj_v2', 'success', '{\"external_patient_id\":\"22222\"}')"
            )
            conn.execute(
                "INSERT INTO projection_result "
                "(projection_id, canonical_record_id, projection_type, projection_version, projection_status, projected_json) "
                "VALUES (4, 2, 'patient_v1', 'proj_v2', 'rejected', '{\"reject_reason\":\"missing_required_fields\"}')"
            )
            conn.commit()
            conn.close()

            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'pipeline_state': 'idle',
                    'last_shadow_pipeline_run_id': '20260219-071129-5d5c869f',
                    'last_qa_policy_version': 'qa_v2',
                    'last_projection_version': 'proj_v2',
                }, f)
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, path = cr.open_data_plane_audit_report(repo, report_type='overview', limit=20)
            self.assertTrue(ok)
            self.assertIn('report generated', msg.lower())
            assert isinstance(path, str)
            self.assertTrue(os.path.exists(path))
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('qa_reject_count=1 (qa_version=qa_v2, raw=2)', text)
            self.assertIn('projection_success_count=1 (projection_version=proj_v2, raw=2)', text)
            self.assertIn('projection_reject_count=1 (projection_version=proj_v2, raw=2)', text)

    def test_get_patient_flow_reference_options_collapses_to_latest_identity_row(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            db_path = self._seed_lab_db(lab)

            conn = sqlite3.connect(db_path)
            conn.execute("PRAGMA foreign_keys = ON")
            conn.execute(
                "INSERT INTO patient "
                "(patient_id, patient_key, external_patient_id, full_name, birth_date, source_system) "
                "VALUES (4, 'pk-risk-v2', '11111', 'Updated Risk Patient', '1971-01-01', 'xp_local')"
            )
            conn.execute(
                "INSERT INTO extracted_canonical_record "
                "(canonical_record_id, artifact_id, canonical_type, canonical_key, extractor_version, canonical_json, provenance_json) "
                "VALUES (3, 3, 'patient_csv_row', 'pk-risk-v2', 'canon_v1', '{}', '{}')"
            )
            conn.execute(
                "INSERT INTO projection_result "
                "(projection_id, canonical_record_id, projection_type, projection_version, projection_status, projected_json) "
                "VALUES (3, 3, 'patient_v1', 'proj_v2', 'success', '{\"external_patient_id\":\"11111\"}')"
            )
            conn.commit()
            conn.close()

            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'pipeline_state': 'idle',
                    'last_shadow_pipeline_run_id': '20260219-071129-5d5c869f',
                    'last_projection_version': 'proj_v2',
                }, f)
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, data = cr.get_patient_flow_reference_options(repo, limit=20)
            self.assertTrue(ok)
            self.assertIn('options ready', msg.lower())
            assert isinstance(data, dict)
            options = data.get('options', [])
            matches = [x for x in options if str(x.get('patient_ref', '')) == '11111']
            self.assertEqual(len(matches), 1)
            self.assertEqual(matches[0].get('full_name'), 'Updated Risk Patient')



class TestConsolidatedHealthPhaseFAppendix(unittest.TestCase):
    def test_phase_f_fail_uses_stub_not_stale_latest(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            old_txt = os.path.join(reports, 'shadow_run_report_oldrun.txt')
            with open(old_txt, 'w', encoding='utf-8') as f:
                f.write('Shadow Run Report (Phase F)\nrun_id: oldrun\npipeline_ok: True\n')
            diag = os.path.join(lab, 'diagnostics_state.json')
            with open(diag, 'w', encoding='utf-8') as f:
                json.dump({
                    'last_shadow_pipeline_run_id': 'newrun',
                    'last_shadow_pipeline_failed_phase': 'F',
                    'last_shadow_pipeline_error_code': 'PHASE_F_LOCK_FAIL',
                    'last_phase_f_lock_diag_path': 'phase_f_lock_diag_new.json',
                }, f)

            def env_flag(_n, default):
                return default

            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                with patch.object(cr, 'get_health_lines', return_value=['snapshot-line']):
                    ok, msg, path = cr.open_consolidated_health_report(repo, env_flag)
            self.assertTrue(ok)
            assert isinstance(path, str)
            with open(path, 'r', encoding='utf-8') as f:
                body = f.read()
            self.assertIn('No shadow_run_report_newrun.txt', body)
            self.assertNotIn('pipeline_ok: True', body)

    def test_prefers_shadow_report_for_expected_run_id(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            rid = 'expected-rid-1'
            path_txt = os.path.join(reports, 'shadow_run_report_{0}.txt'.format(rid))
            with open(path_txt, 'w', encoding='utf-8') as f:
                f.write('Shadow Run Report (Phase F)\nrun_id: {0}\nok\n'.format(rid))
            diag = os.path.join(lab, 'diagnostics_state.json')
            with open(diag, 'w', encoding='utf-8') as f:
                json.dump({'last_shadow_pipeline_run_id': rid}, f)

            def env_flag(_n, default):
                return default

            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                with patch.object(cr, 'get_health_lines', return_value=['h']):
                    ok, _, out = cr.open_consolidated_health_report(repo, env_flag)
            self.assertTrue(ok)
            assert isinstance(out, str)
            with open(out, 'r', encoding='utf-8') as f:
                body = f.read()
            self.assertIn('expected-rid-1', body)
            self.assertNotIn('WARNING:', body)

    def test_fallback_appendix_uses_latest_txt_when_json_is_newer(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            txt_path = os.path.join(reports, 'shadow_run_report_oldrid.txt')
            with open(txt_path, 'w', encoding='utf-8') as f:
                f.write(
                    'Shadow Run Report (Phase F)\nrun_id: oldrid\n'
                    'UNIQUE_TXT_APPENDIX_MARKER\n'
                )
            json_path = os.path.join(reports, 'shadow_run_report_newrid.json')
            with open(json_path, 'w', encoding='utf-8') as f:
                f.write('{}')
            old = time.time() - 100
            os.utime(txt_path, (old, old))
            new = time.time() + 10
            os.utime(json_path, (new, new))
            diag = os.path.join(lab, 'diagnostics_state.json')
            with open(diag, 'w', encoding='utf-8') as f:
                json.dump({}, f)

            def env_flag(_n, default):
                return default

            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                with patch.object(cr, 'get_health_lines', return_value=['snapshot']):
                    ok, _, out = cr.open_consolidated_health_report(repo, env_flag)
            self.assertTrue(ok)
            assert isinstance(out, str)
            with open(out, 'r', encoding='utf-8') as f:
                body = f.read()
            self.assertIn('Phase F detailed report', body)
            self.assertIn('UNIQUE_TXT_APPENDIX_MARKER', body)




class TestOperatorSupportRecommendation(unittest.TestCase):
    def _write_json(self, path, data):
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(data, f)
        return path

    def _snapshot_with_phase_payloads(self, reports_dir, run_id, shadow_payload, phase_c_payload, phase_d_payload):
        shadow_path = self._write_json(
            os.path.join(reports_dir, 'shadow_run_report_{0}.json'.format(run_id)),
            shadow_payload,
        )
        phase_c_path = self._write_json(
            os.path.join(reports_dir, 'ingest_write_summary_{0}.json'.format(run_id)),
            phase_c_payload,
        )
        phase_d_path = self._write_json(
            os.path.join(reports_dir, 'qa_canonical_summary_{0}.json'.format(run_id)),
            phase_d_payload,
        )
        rows = []
        for code in ('B', 'C', 'D', 'E', 'F'):
            row = {
                'code': code,
                'name': code,
                'status': 'complete',
                'resolved_run_id': run_id,
                'files': [],
                'required_missing': [],
            }
            if code == 'C':
                row['files'] = [phase_c_path]
            elif code == 'D':
                row['files'] = [phase_d_path]
            elif code == 'F':
                row['files'] = [shadow_path]
            rows.append(row)
        return {
            'lab_root': os.path.dirname(reports_dir),
            'reports_dir': reports_dir,
            'run_id': run_id,
            'nearest_complete_run_id': '',
            'phase_rows': rows,
            'diagnostics_state': {},
        }

    def test_compute_operator_support_send_recommendation_prefers_historical_reprocess_for_duplicate_only_dat(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            reports = os.path.join(repo, 'lab', 'reports')
            os.makedirs(reports)
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                '20260329-171213-1ccb1c51',
                {
                    'phase_c_inserted_count': 0,
                    'phase_c_skipped_count': 763,
                    'phase_d_rows_selected': 0,
                    'phase_d_pass_count': 0,
                    'phase_d_reject_count': 0,
                    'phase_d_qa_policy_version': 'qa_v2',
                },
                {'rows_inserted': 0, 'rows_skipped_duplicate': 763},
                {'rows_selected': 0, 'qa_pass_count': 0, 'qa_reject_count': 0, 'qa_policy_version': 'qa_v2'},
            )
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_artifact_bundle_quality', return_value={'recommendation': 'send_current_run', 'score': 80, 'label': 'HIGH'}):
                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                        with patch.object(cr, 'is_pipeline_running', return_value=False):
                            with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', return_value={
                                'ok': True,
                                'qa_version': 'qa_v2',
                                'targeted_artifact_classes': ['dat'],
                                'reject_counts_by_class': {'dat': 389},
                                'pending_replay_counts_by_class': {'dat': 389},
                            }):
                                rec = cr.compute_operator_support_send_recommendation(repo)
        self.assertEqual(rec.get('recommended_action_kind'), 'historical_phase_d_reprocess')
        self.assertEqual(rec.get('best_now_action_kind'), 'historical_phase_d_reprocess')
        self.assertEqual(rec.get('recommended_artifact_classes'), ['dat'])
        self.assertEqual(rec.get('recommended_report_kind'), 'artifact_triage_pack')
        self.assertIn('re-evaluate historical Phase D rejects', rec.get('summary_line', ''))
        self.assertIn('Phase B DAT manifest did not indicate discovered DAT rows', rec.get('dat_smoke_not_triggered_reason', ''))

    def test_anchored_duplicate_only_historical_recommendation_with_lineage_skew_issue(self):
        """
        Real anchored XP runs: Phase D zero-selection may reference a different Phase C run id than
        shadow phase_run_ids, producing lineage_issues. That must not downgrade to send_bundle when
        duplicate-only + historical rejects still warrant historical_phase_d_reprocess.
        """
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            run_id = '20260331-005932-ba25d2aa'
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                run_id,
                {
                    'phase_c_inserted_count': 0,
                    'phase_c_skipped_count': 763,
                    'phase_d_rows_selected': 0,
                    'phase_d_pass_count': 0,
                    'phase_d_reject_count': 0,
                    'phase_d_qa_policy_version': 'qa_v2',
                },
                {'rows_inserted': 0, 'rows_skipped_duplicate': 763},
                {'rows_selected': 0, 'qa_pass_count': 0, 'qa_reject_count': 0, 'qa_policy_version': 'qa_v2'},
            )
            snapshot['lineage_issues'] = [
                'phase_d_zero_selection_phase_c_run_id_mismatch expected_phase_c=a resolved_phase_c=b',
            ]
            snapshot['diagnostics_state'] = {
                'pipeline_state': 'completed',
                'last_shadow_pipeline_run_id': run_id,
                'active_run_id': '',
            }

            def fake_build(_repo_root, run_id='', **_kwargs):
                return True, '', dict(snapshot)

            with patch.object(cr, '_build_run_artifact_snapshot', side_effect=fake_build):
                with patch.object(cr, '_collect_system_health_artifacts', return_value={
                    'lab_root': lab,
                    'reports_dir': reports,
                    'repo_root': repo,
                    'shadow_report_path': '',
                }):
                    with patch.object(cr, '_build_system_health_pack_context', return_value={
                        'pack_scope': 'completed_run',
                        'anchor_run_id': run_id,
                    }):
                        with patch.object(cr, '_artifact_bundle_quality', return_value={
                            'recommendation': 'send_current_run',
                            'score': 80,
                            'label': 'HIGH',
                        }):
                            with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                                with patch.object(cr, 'is_pipeline_running', return_value=False):
                                    with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', return_value={
                                        'ok': True,
                                        'qa_version': 'qa_v2',
                                        'targeted_artifact_classes': ['dat'],
                                        'reject_counts_by_class': {'dat': 389},
                                        'pending_replay_counts_by_class': {'dat': 389},
                                    }):
                                        rec = cr.compute_operator_support_send_recommendation(repo)
        self.assertEqual(rec.get('recommended_action_kind'), 'historical_phase_d_reprocess')
        self.assertEqual(rec.get('recommendation_source_scope'), 'anchored_completed_run')
        self.assertEqual(str(rec.get('recommendation_anchor_run_id', '')), run_id)

    def test_compute_operator_support_send_recommendation_prefers_dat_smoke_before_historical_reprocess(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            reports = os.path.join(repo, 'lab', 'reports')
            os.makedirs(reports)
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                '20260329-171213-1ccb1c51',
                {
                    'run_id': '20260329-171213-1ccb1c51',
                    'phase_b_dat_manifest_rows_count': 7,
                    'phase_c_inserted_count': 0,
                    'phase_c_skipped_count': 763,
                    'phase_d_rows_selected': 0,
                    'phase_d_pass_count': 0,
                    'phase_d_reject_count': 0,
                    'phase_d_dat_selected_count': 0,
                    'post_medisoft_blocked_stage': '',
                    'pipeline_ok': True,
                },
                {'rows_inserted': 0, 'rows_skipped_duplicate': 763},
                {'run_id': '20260329-171213-1ccb1c51', 'dat_telemetry': {'dat_selected_count': 0}},
            )
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_artifact_bundle_quality', return_value={'recommendation': 'send_current_run', 'score': 80, 'label': 'HIGH'}):
                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                        with patch.object(cr, 'is_pipeline_running', return_value=False):
                            with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', return_value={
                                'ok': True,
                                'qa_version': 'qa_v2',
                                'targeted_artifact_classes': ['dat'],
                                'reject_counts_by_class': {'dat': 389},
                                'pending_replay_counts_by_class': {'dat': 389},
                            }):
                                rec = cr.compute_operator_support_send_recommendation(repo)
        self.assertEqual(rec.get('recommended_action_kind'), 'phase_d_dat_smoke')
        self.assertEqual(rec.get('best_now_action_kind'), 'phase_d_dat_smoke')
        self.assertEqual(rec.get('follow_on_action_kind'), 'historical_phase_d_reprocess')
        self.assertTrue(rec.get('historical_reprocess_available'))
        self.assertTrue(rec.get('dat_smoke_available'))
        self.assertIn('Follow-on after DAT smoke', ' '.join(rec.get('action_reason_lines', [])))

    def test_compute_operator_support_send_recommendation_waits_for_stable_when_pipeline_active(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            reports = os.path.join(repo, 'lab', 'reports')
            os.makedirs(reports)
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                '20260329-171213-1ccb1c51',
                {
                    'phase_c_inserted_count': 0,
                    'phase_c_skipped_count': 10,
                    'phase_d_rows_selected': 0,
                    'phase_d_pass_count': 0,
                    'phase_d_reject_count': 0,
                    'phase_d_qa_policy_version': 'qa_v2',
                },
                {'rows_inserted': 0, 'rows_skipped_duplicate': 10},
                {'rows_selected': 0, 'qa_pass_count': 0, 'qa_reject_count': 0, 'qa_policy_version': 'qa_v2'},
            )
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_artifact_bundle_quality', return_value={'recommendation': 'send_current_run', 'score': 80, 'label': 'HIGH'}):
                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                        with patch.object(cr, 'is_pipeline_running', return_value=True):
                            with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', return_value={
                                'ok': True,
                                'qa_version': 'qa_v2',
                                'targeted_artifact_classes': ['dat'],
                                'reject_counts_by_class': {'dat': 10},
                                'pending_replay_counts_by_class': {'dat': 10},
                            }):
                                rec = cr.compute_operator_support_send_recommendation(repo)
        self.assertEqual(rec.get('recommended_action_kind'), 'historical_phase_d_reprocess')
        self.assertEqual(rec.get('best_now_action_kind'), 'wait_for_stable')

    def test_compute_operator_support_send_recommendation_targets_only_affected_classes(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            reports = os.path.join(repo, 'lab', 'reports')
            os.makedirs(reports)
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                '20260329-171213-1ccb1c51',
                {
                    'phase_c_inserted_count': 0,
                    'phase_c_skipped_count': 12,
                    'phase_d_rows_selected': 0,
                    'phase_d_pass_count': 0,
                    'phase_d_reject_count': 0,
                    'phase_d_qa_policy_version': 'qa_v2',
                },
                {'rows_inserted': 0, 'rows_skipped_duplicate': 12},
                {'rows_selected': 0, 'qa_pass_count': 0, 'qa_reject_count': 0, 'qa_policy_version': 'qa_v2'},
            )
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_artifact_bundle_quality', return_value={'recommendation': 'send_current_run', 'score': 80, 'label': 'HIGH'}):
                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                        with patch.object(cr, 'is_pipeline_running', return_value=False):
                            with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', return_value={
                                'ok': True,
                                'qa_version': 'qa_v2',
                                'targeted_artifact_classes': ['csv', 'docx'],
                                'reject_counts_by_class': {'csv': 7, 'docx': 5},
                                'pending_replay_counts_by_class': {'csv': 7, 'docx': 5},
                            }):
                                rec = cr.compute_operator_support_send_recommendation(repo)
        self.assertEqual(rec.get('recommended_artifact_classes'), ['csv', 'docx'])

    def test_compute_operator_support_send_recommendation_stays_on_send_bundle_without_historical_rejects(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            reports = os.path.join(repo, 'lab', 'reports')
            os.makedirs(reports)
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                '20260329-171213-1ccb1c51',
                {
                    'phase_c_inserted_count': 0,
                    'phase_c_skipped_count': 3,
                    'phase_d_rows_selected': 0,
                    'phase_d_pass_count': 0,
                    'phase_d_reject_count': 0,
                    'phase_d_qa_policy_version': 'qa_v2',
                },
                {'rows_inserted': 0, 'rows_skipped_duplicate': 3},
                {'rows_selected': 0, 'qa_pass_count': 0, 'qa_reject_count': 0, 'qa_policy_version': 'qa_v2'},
            )
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_artifact_bundle_quality', return_value={'recommendation': 'send_current_run', 'score': 80, 'label': 'HIGH'}):
                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                        with patch.object(cr, 'is_pipeline_running', return_value=False):
                            with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', return_value={
                                'ok': True,
                                'qa_version': 'qa_v2',
                                'targeted_artifact_classes': [],
                                'reject_counts_by_class': {},
                                'pending_replay_counts_by_class': {},
                            }):
                                rec = cr.compute_operator_support_send_recommendation(repo)
        self.assertEqual(rec.get('recommended_action_kind'), 'send_bundle')
        self.assertEqual(rec.get('best_now_action_kind'), 'send_bundle')

    def test_compute_operator_support_send_recommendation_recommends_phase_d_dat_smoke_when_anchored_not_advanced(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                '20260329-171213-1ccb1c51',
                {
                    'run_id': '20260329-171213-1ccb1c51',
                    'phase_b_dat_manifest_rows_count': 7,
                    'phase_c_inserted_count': 4,
                    'phase_c_skipped_count': 1,
                    'phase_d_dat_selected_count': 0,
                    'post_medisoft_blocked_stage': '',
                    'pipeline_ok': True,
                },
                {'rows_inserted': 4, 'rows_skipped_duplicate': 1},
                {'run_id': '20260329-171213-1ccb1c51', 'dat_telemetry': {'dat_selected_count': 0}},
            )
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_artifact_bundle_quality', return_value={'recommendation': 'send_current_run', 'score': 80, 'label': 'HIGH'}):
                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                        with patch.object(cr, 'is_pipeline_running', return_value=False):
                            with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', return_value={
                                'ok': True,
                                'qa_version': 'qa_v2',
                                'targeted_artifact_classes': [],
                                'reject_counts_by_class': {},
                                'pending_replay_counts_by_class': {},
                            }):
                                rec = cr.compute_operator_support_send_recommendation(repo)
        self.assertEqual(rec.get('recommended_action_kind'), 'phase_d_dat_smoke')
        self.assertEqual(rec.get('preferred_when_stable_action_kind'), 'phase_d_dat_smoke')
        self.assertEqual(rec.get('best_now_action_kind'), 'phase_d_dat_smoke')
        self.assertEqual(rec.get('strict_milestone_verdict'), 'Not advanced')
        self.assertEqual(rec.get('action_preview', {}).get('anchor_run_id'), '20260329-171213-1ccb1c51')

    def test_compute_operator_support_send_recommendation_does_not_recommend_dat_smoke_for_truthful_dat_lane_block(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            reports = os.path.join(repo, 'lab', 'reports')
            os.makedirs(reports)
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                '20260329-171213-1ccb1c51',
                {
                    'run_id': '20260329-171213-1ccb1c51',
                    'phase_b_dat_manifest_rows_count': 7,
                    'phase_c_inserted_count': 5,
                    'phase_c_skipped_count': 1,
                    'phase_d_dat_selected_count': 6,
                    'phase_d_dat_qa_pass_count': 0,
                    'phase_d_dat_qa_reject_count': 6,
                    'post_medisoft_blocked_stage': 'phase_d',
                    'pipeline_ok': True,
                },
                {'rows_inserted': 5, 'rows_skipped_duplicate': 1},
                {'run_id': '20260329-171213-1ccb1c51', 'dat_telemetry': {'dat_selected_count': 6, 'dat_qa_pass_count': 0, 'dat_qa_reject_count': 6}},
            )
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_artifact_bundle_quality', return_value={'recommendation': 'send_current_run', 'score': 80, 'label': 'HIGH'}):
                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                        with patch.object(cr, 'is_pipeline_running', return_value=False):
                            with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', return_value={
                                'ok': True,
                                'qa_version': 'qa_v2',
                                'targeted_artifact_classes': [],
                                'reject_counts_by_class': {},
                                'pending_replay_counts_by_class': {},
                            }):
                                rec = cr.compute_operator_support_send_recommendation(repo)
        self.assertEqual(rec.get('recommended_action_kind'), 'review_dat_qa_full_block')
        self.assertEqual(rec.get('best_now_action_kind'), 'review_dat_qa_full_block')
        self.assertIn('review DAT QA full-block evidence', rec.get('summary_line', ''))
        preview = rec.get('action_preview', {}) if isinstance(rec.get('action_preview', {}), dict) else {}
        self.assertEqual(preview.get('dat_selected_count'), 6)
        self.assertEqual(preview.get('dat_qa_reject_count'), 6)
        self.assertEqual(preview.get('dat_canonical_record_count'), 0)

    def test_compute_operator_support_send_recommendation_uses_completed_smoke_for_truthful_dat_lane_block(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            smoke_reports = os.path.join(repo, 'phase_d_dat_smoke_lab', 'reports')
            os.makedirs(reports)
            os.makedirs(smoke_reports)
            run_id = '20260329-171213-1ccb1c51'
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                run_id,
                {
                    'run_id': run_id,
                    'phase_b_dat_manifest_rows_count': 390,
                    'phase_c_inserted_count': 390,
                    'phase_c_skipped_count': 0,
                    'phase_d_dat_selected_count': 0,
                    'phase_d_dat_qa_pass_count': 0,
                    'phase_d_dat_qa_reject_count': 0,
                    'post_medisoft_blocked_stage': '',
                    'pipeline_ok': True,
                },
                {'rows_inserted': 390, 'rows_skipped_duplicate': 0},
                {'run_id': run_id, 'dat_telemetry': {'dat_selected_count': 0, 'dat_qa_pass_count': 0, 'dat_qa_reject_count': 0}},
            )
            smoke_txt = os.path.join(smoke_reports, 'phase_d_dat_smoke_report_{0}.txt'.format(run_id))
            smoke_json = os.path.join(smoke_reports, 'phase_d_dat_smoke_report_{0}.json'.format(run_id))
            with open(smoke_txt, 'w', encoding='utf-8') as f:
                f.write('assessment: dat_selected_qa_blocked\n')
            with open(smoke_json, 'w', encoding='utf-8') as f:
                json.dump({
                    'anchor_run_id': run_id,
                    'assessment': 'dat_selected_qa_blocked',
                    'strict_milestone_verdict': 'Partially advanced',
                    'dat_funnel': {
                        'dat_selected_count': 390,
                        'dat_qa_pass_count': 0,
                        'dat_qa_reject_count': 390,
                        'dat_canonical_record_count': 0,
                        'post_medisoft_blocked_stage': 'qa',
                    },
                }, f)
            with open(os.path.join(lab, 'phase_d_dat_smoke_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'last_requested_anchor_run_id': run_id,
                    'last_requested_context_run_id': run_id,
                    'last_remediation_issue_code': 'PHASE_D_DAT_QA_FULL_BLOCK',
                    'last_status': 'completed',
                    'last_report_path': smoke_txt,
                    'last_assessment': 'dat_selected_qa_blocked',
                    'cooldown_until_utc': '2999-01-01T00:00:00Z',
                }, f)
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_artifact_bundle_quality', return_value={'recommendation': 'send_current_run', 'score': 80, 'label': 'HIGH'}):
                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                        with patch.object(cr, 'is_pipeline_running', return_value=False):
                            with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', return_value={
                                'ok': True,
                                'qa_version': 'qa_v2',
                                'targeted_artifact_classes': [],
                                'reject_counts_by_class': {},
                                'pending_replay_counts_by_class': {},
                            }):
                                rec = cr.compute_operator_support_send_recommendation(repo)
        self.assertEqual(rec.get('recommended_action_kind'), 'review_dat_qa_full_block')
        self.assertEqual(rec.get('dat_smoke_last_assessment'), 'dat_selected_qa_blocked')
        self.assertEqual(rec.get('action_preview', {}).get('smoke_assessment'), 'dat_selected_qa_blocked')
        self.assertEqual(rec.get('action_preview', {}).get('dat_selected_count'), 390)
        self.assertIn('Partially advanced', rec.get('why_summary', '') + ' ' + ' '.join(rec.get('action_reason_lines', [])))
        prev = rec.get('action_preview', {}) if isinstance(rec.get('action_preview', {}), dict) else {}
        self.assertTrue(prev.get('smoke_source_accepted'))
        self.assertEqual(prev.get('anchored_diagnosis_source'), 'smoke_corroborated')

    def test_compute_operator_support_send_recommendation_qa_full_block_ignores_mismatched_smoke_counters(self):
        """Smoke dat_funnel must not override anchored counts when smoke anchor != anchored run."""
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            smoke_reports = os.path.join(repo, 'phase_d_dat_smoke_lab', 'reports')
            os.makedirs(reports)
            os.makedirs(smoke_reports)
            run_id = '20260329-171213-1ccb1c51'
            other_anchor = '20260331-022246-3b508c10'
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                run_id,
                {
                    'run_id': run_id,
                    'phase_b_dat_manifest_rows_count': 7,
                    'phase_c_inserted_count': 5,
                    'phase_c_skipped_count': 1,
                    'phase_d_dat_selected_count': 6,
                    'phase_d_dat_qa_pass_count': 0,
                    'phase_d_dat_qa_reject_count': 6,
                    'post_medisoft_blocked_stage': 'phase_d',
                    'pipeline_ok': True,
                },
                {'rows_inserted': 5, 'rows_skipped_duplicate': 1},
                {'run_id': run_id, 'dat_telemetry': {
                    'dat_selected_count': 6, 'dat_qa_pass_count': 0, 'dat_qa_reject_count': 6,
                }},
            )
            smoke_txt = os.path.join(smoke_reports, 'phase_d_dat_smoke_report_{0}.txt'.format(other_anchor))
            smoke_json = os.path.join(smoke_reports, 'phase_d_dat_smoke_report_{0}.json'.format(other_anchor))
            with open(smoke_txt, 'w', encoding='utf-8') as f:
                f.write('assessment: dat_selected_qa_blocked\n')
            with open(smoke_json, 'w', encoding='utf-8') as f:
                json.dump({
                    'anchor_run_id': other_anchor,
                    'assessment': 'dat_selected_qa_blocked',
                    'dat_funnel': {
                        'dat_selected_count': 999,
                        'dat_qa_pass_count': 0,
                        'dat_qa_reject_count': 999,
                        'dat_canonical_record_count': 0,
                    },
                }, f)
            with open(os.path.join(lab, 'phase_d_dat_smoke_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'last_status': 'completed',
                    'last_report_path': smoke_txt,
                    'last_assessment': 'dat_selected_qa_blocked',
                }, f)
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_artifact_bundle_quality', return_value={'recommendation': 'send_current_run', 'score': 80, 'label': 'HIGH'}):
                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                        with patch.object(cr, 'is_pipeline_running', return_value=False):
                            with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', return_value={
                                'ok': True,
                                'qa_version': 'qa_v2',
                                'targeted_artifact_classes': [],
                                'reject_counts_by_class': {},
                                'pending_replay_counts_by_class': {},
                            }):
                                rec = cr.compute_operator_support_send_recommendation(repo)
        self.assertEqual(rec.get('recommended_action_kind'), 'review_dat_qa_full_block')
        prev = rec.get('action_preview', {}) if isinstance(rec.get('action_preview', {}), dict) else {}
        self.assertEqual(prev.get('dat_selected_count'), 6)
        self.assertEqual(prev.get('dat_qa_reject_count'), 6)
        self.assertNotEqual(prev.get('dat_selected_count'), 999)
        self.assertTrue(prev.get('ignored_smoke_mismatch'))
        self.assertFalse(prev.get('smoke_source_accepted'))
        self.assertEqual(prev.get('anchored_diagnosis_source'), 'anchored_phase_d_shadow')
        reason_blob = ' '.join(rec.get('action_reason_lines', []))
        self.assertIn('ignore mismatched smoke on disk', reason_blob)
        self.assertNotIn('matching smoke report', reason_blob)

    def test_compute_operator_support_send_recommendation_suppresses_dat_smoke_when_same_target_in_cooldown(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            state_path = os.path.join(lab, 'phase_d_dat_smoke_state.json')
            with open(state_path, 'w', encoding='utf-8') as f:
                json.dump({
                    'last_requested_anchor_run_id': '20260329-171213-1ccb1c51',
                    'last_requested_context_run_id': '20260329-171213-1ccb1c51',
                    'last_remediation_issue_code': '',
                    'last_status': 'completed',
                    'cooldown_until_utc': '2999-01-01T00:00:00Z',
                }, f)
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                '20260329-171213-1ccb1c51',
                {
                    'run_id': '20260329-171213-1ccb1c51',
                    'phase_b_dat_manifest_rows_count': 7,
                    'phase_c_inserted_count': 4,
                    'phase_c_skipped_count': 1,
                    'phase_d_dat_selected_count': 0,
                    'post_medisoft_blocked_stage': '',
                    'pipeline_ok': True,
                },
                {'rows_inserted': 4, 'rows_skipped_duplicate': 1},
                {'run_id': '20260329-171213-1ccb1c51', 'dat_telemetry': {'dat_selected_count': 0}},
            )
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_artifact_bundle_quality', return_value={'recommendation': 'send_current_run', 'score': 80, 'label': 'HIGH'}):
                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                        with patch.object(cr, 'is_pipeline_running', return_value=False):
                            with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', return_value={
                                'ok': True,
                                'qa_version': 'qa_v2',
                                'targeted_artifact_classes': [],
                                'reject_counts_by_class': {},
                                'pending_replay_counts_by_class': {},
                            }):
                                rec = cr.compute_operator_support_send_recommendation(repo)
        self.assertNotEqual(rec.get('recommended_action_kind'), 'phase_d_dat_smoke')
        self.assertIn('cooldown', str(rec.get('dat_smoke_not_triggered_reason', '')).lower())

    def test_compute_operator_support_send_recommendation_marks_reply_required_for_qa_drop_issue(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            with open(os.path.join(lab, 'cloud_health_alert_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'last_issue_key': 'PHASE_D_INVALID_EXTERNAL_ID_SKIPS_PRESENT:Phase D skipped 13 patient upsert(s).',
                    'last_sent_epoch': 1774577782,
                }, f)
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                '20260329-171213-1ccb1c51',
                {
                    'phase_c_inserted_count': 0,
                    'phase_c_skipped_count': 3,
                    'phase_d_rows_selected': 0,
                    'phase_d_pass_count': 0,
                    'phase_d_reject_count': 0,
                    'phase_d_qa_policy_version': 'qa_v2',
                },
                {'rows_inserted': 0, 'rows_skipped_duplicate': 3},
                {'rows_selected': 0, 'qa_pass_count': 0, 'qa_reject_count': 0, 'qa_policy_version': 'qa_v2'},
            )
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_artifact_bundle_quality', return_value={'recommendation': 'send_current_run', 'score': 80, 'label': 'HIGH'}):
                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                        with patch.object(cr, 'is_pipeline_running', return_value=False):
                            with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', return_value={
                                'ok': True,
                                'qa_version': 'qa_v2',
                                'targeted_artifact_classes': [],
                                'reject_counts_by_class': {},
                                'pending_replay_counts_by_class': {},
                            }):
                                rec = cr.compute_operator_support_send_recommendation(repo)
        self.assertTrue(rec.get('reply_required_for_unblock'))
        self.assertEqual(rec.get('reply_required_issue_code'), 'PHASE_D_INVALID_EXTERNAL_ID_SKIPS_PRESENT')
        self.assertIn('Reply required to unblock QA drop spike follow-up', '\n'.join(rec.get('action_reason_lines', [])))

    def test_compute_operator_support_send_recommendation_does_not_override_non_qa_alert_with_telemetry_fallback(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            with open(os.path.join(lab, 'cloud_health_alert_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'last_issue_key': 'PHASE_F_LOCK_FAIL:Phase F lock acquisition failed.',
                    'last_sent_epoch': 1774577782,
                }, f)
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'pipeline_state': 'completed',
                    'active_run_id': '',
                    'last_shadow_pipeline_run_id': '20260329-171213-1ccb1c51',
                    'last_discovery_dat_telemetry': {'dat_manifest_rows_count': 3},
                    'last_phase_d_dat_telemetry': {
                        'dat_selected_count': 0,
                        'post_medisoft_exercised': False,
                        'post_medisoft_blocked_stage': 'phase_d',
                    },
                }, f)
            with open(os.path.join(reports, 'shadow_run_report_20260329-171213-1ccb1c51.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'post_medisoft_status': 'blocked',
                    'post_medisoft_blocked_stage': 'phase_d',
                    'phase_b_dat_manifest_rows_count': 3,
                    'phase_d_dat_selected_count': 0,
                }, f)
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                '20260329-171213-1ccb1c51',
                {
                    'phase_c_inserted_count': 0,
                    'phase_c_skipped_count': 3,
                    'phase_d_rows_selected': 0,
                    'phase_d_pass_count': 0,
                    'phase_d_reject_count': 0,
                    'phase_d_qa_policy_version': 'qa_v2',
                },
                {'rows_inserted': 0, 'rows_skipped_duplicate': 3},
                {'rows_selected': 0, 'qa_pass_count': 0, 'qa_reject_count': 0, 'qa_policy_version': 'qa_v2'},
            )
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_artifact_bundle_quality', return_value={'recommendation': 'send_current_run', 'score': 80, 'label': 'HIGH'}):
                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                        with patch.object(cr, 'is_pipeline_running', return_value=False):
                            with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', return_value={
                                'ok': True,
                                'qa_version': 'qa_v2',
                                'targeted_artifact_classes': [],
                                'reject_counts_by_class': {},
                                'pending_replay_counts_by_class': {},
                            }):
                                rec = cr.compute_operator_support_send_recommendation(repo)
        self.assertFalse(rec.get('reply_required_for_unblock'))
        self.assertEqual(rec.get('reply_required_issue_code'), '')


class TestPhaseDHistoricalReprocessWrappers(unittest.TestCase):
    def test_run_phase_d_manual_sets_artifact_class_filter_env(self):
        from MediCafe import cloud_readiness as cr
        with patch.object(cr, '_resolve_unified_model_script', return_value=(True, '', '/repo', '/repo/run_qa_canonical.py', [])):
            with patch.object(cr, 'resolve_lab_root', return_value='/repo/lab'):
                with patch.object(cr.subprocess, 'Popen') as mock_popen:
                    ok, msg, _ = cr.run_phase_d_manual('/repo', '/py', {}, artifact_classes=['dat', 'csv'])
        self.assertTrue(ok)
        self.assertEqual(msg, '')
        proc_env = mock_popen.call_args[1].get('env', {})
        self.assertEqual(proc_env.get('MEDICAFE_LAB_DIR'), '/repo/lab')
        self.assertEqual(proc_env.get('MEDICAFE_PHASE_D_ARTIFACT_CLASSES'), 'dat,csv')

    def test_run_historical_phase_d_reprocess_resets_then_launches_filtered_phase_d(self):
        from MediCafe import cloud_readiness as cr
        payload = {
            'ok': True,
            'targeted_artifact_classes': ['dat'],
            'execution_report_path': '/repo/lab/reports/phase_d_historical_reprocess_execution_latest.txt',
        }
        with patch.object(cr, '_execute_historical_phase_d_reprocess_impl', return_value=payload):
            with patch.object(cr, 'resolve_lab_root', return_value='/repo/lab'):
                with patch.object(cr, 'run_phase_d_manual', return_value=(True, '', None)) as mock_run:
                    ok, msg, data = cr.run_historical_phase_d_reprocess('/repo', '/py', {}, artifact_classes=['dat'])
        self.assertTrue(ok)
        self.assertIn('Historical Phase D re-evaluation started', msg)
        self.assertEqual(data.get('execution_report_path'), payload['execution_report_path'])
        mock_run.assert_called_once_with('/repo', '/py', {}, artifact_classes=['dat'])


class TestEmbeddedRecommendationReporting(unittest.TestCase):
    def test_format_recommended_action_lines_includes_reply_required_fields(self):
        from MediCafe import cloud_readiness_artifact_tools as tools
        lines = tools.format_recommended_action_lines({
            'recommended_action_kind': 'send_bundle',
            'reply_required_for_unblock': True,
            'reply_required_issue_code': 'PHASE_D_INVALID_EXTERNAL_ID_SKIPS_PRESENT',
            'reply_required_issue_key': 'PHASE_D_INVALID_EXTERNAL_ID_SKIPS_PRESENT:example',
        })
        body = '\n'.join(lines)
        self.assertIn('reply_required_for_unblock=True', body)
        self.assertIn('reply_required_issue_code=PHASE_D_INVALID_EXTERNAL_ID_SKIPS_PRESENT', body)
        self.assertIn('reply_required_issue_key=PHASE_D_INVALID_EXTERNAL_ID_SKIPS_PRESENT:example', body)

    def test_format_recommended_action_lines_milestone_and_operator_lanes(self):
        from MediCafe import cloud_readiness_artifact_tools as tools
        lines = tools.format_recommended_action_lines({
            'recommended_action_kind': 'send_bundle',
            'milestone_verdict': 'Not advanced',
            'milestone_reason': 'dat_lane_not_exercised',
            'anchored_milestone_run_id': 'anchor-rid',
            'live_operator_unblock': {
                'reply_required': True,
                'reply_required_issue_code': 'PHASE_D_INVALID_EXTERNAL_ID_SKIPS_PRESENT',
                'reply_required_issue_key': 'PHASE_D_INVALID_EXTERNAL_ID_SKIPS_PRESENT:example',
            },
        })
        body = '\n'.join(lines)
        self.assertIn('Milestone verdict (anchored shadow payload):', body)
        self.assertIn('milestone_verdict=Not advanced', body)
        self.assertIn('Operator unblock (live alert / diagnostics):', body)
        self.assertIn('reply_required_issue_key=PHASE_D_INVALID_EXTERNAL_ID_SKIPS_PRESENT:example', body)

    def test_format_recommended_action_lines_auto_ack_syncs_live_unblock_reply_required(self):
        from MediCafe import cloud_readiness_artifact_tools as tools
        lines = tools.format_recommended_action_lines({
            'recommended_action_kind': 'send_bundle',
            'reply_required_for_unblock': False,
            'reply_required_issue_code': '',
            'reply_required_issue_key': '',
            'live_operator_unblock': {
                'reply_required': True,
                'reply_required_issue_code': 'PHASE_D_INVALID_EXTERNAL_ID_SKIPS_PRESENT',
                'reply_required_issue_key': 'PHASE_D_INVALID_EXTERNAL_ID_SKIPS_PRESENT:auto-ack',
            },
        })
        body = '\n'.join(lines)
        self.assertIn('Operator unblock (live alert / diagnostics):', body)
        self.assertIn(' - reply_required=False', body)
        self.assertNotIn('reply_required_for_unblock=True', body)
        self.assertIn('reply_required_issue_code=PHASE_D_INVALID_EXTERNAL_ID_SKIPS_PRESENT', body)
        self.assertIn('reply_required_issue_key=PHASE_D_INVALID_EXTERNAL_ID_SKIPS_PRESENT:auto-ack', body)

    def test_format_recommended_action_lines_includes_qa_full_block_provenance(self):
        from MediCafe import cloud_readiness_artifact_tools as tools
        lines = tools.format_recommended_action_lines({
            'recommended_action_kind': 'review_dat_qa_full_block',
            'recommended_report_kind': 'artifact_triage_pack',
            'recommendation_anchor_run_id': '20260329-171213-1ccb1c51',
            'action_preview': {
                'anchor_run_id': '20260329-171213-1ccb1c51',
                'anchored_diagnosis_source': 'anchored_phase_d_shadow',
                'smoke_source_accepted': False,
                'ignored_smoke_mismatch': True,
                'smoke_anchor_run_id': 'other-anchor',
                'source_mismatch_note': 'Smoke on disk is not used for displayed counters.',
            },
            'live_operator_unblock': {'reply_required': False},
        })
        body = '\n'.join(lines)
        self.assertIn('QA full-block review provenance:', body)
        self.assertIn('anchored_diagnosis_source=anchored_phase_d_shadow', body)
        self.assertIn('smoke_source_accepted=False', body)
        self.assertIn('ignored_smoke_mismatch=True', body)
        self.assertIn('smoke_anchor_run_id=other-anchor', body)
        self.assertIn('source_mismatch_note=', body)

    def test_open_latest_artifact_triage_pack_embeds_recommended_action_block(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            snapshot = {
                'repo_root': repo,
                'lab_root': lab,
                'reports_dir': reports,
                'run_id': '20260329-171213-1ccb1c51',
                'pipeline_run_id': '20260329-171213-1ccb1c51',
                'phase_rows': [
                    {'code': code, 'name': code, 'status': 'complete', 'resolved_run_id': '20260329-171213-1ccb1c51', 'files': [], 'required_missing': []}
                    for code in ('B', 'C', 'D', 'E', 'F')
                ],
                'artifact_files': [],
                'context_files': [],
                'missing_required': [],
                'diagnostics_state': {},
                'nearest_complete_run_id': '',
                'recent_run_ids': [],
                'pipeline_running': False,
                'phase_run_ids': {},
                'resolution_decision': 'single_token',
                'resolution_confidence': 'high',
                'resolution_reason': '',
                'resolution_notes': [],
            }
            recommendation = {
                'recommended_action_kind': 'historical_phase_d_reprocess',
                'preferred_when_stable_action_kind': 'historical_phase_d_reprocess',
                'best_now_action_kind': 'historical_phase_d_reprocess',
                'recommended_report_kind': 'artifact_triage_pack',
                'recommended_artifact_classes': ['dat'],
                'action_requires_confirmation': True,
                'action_preview': {'latest_phase_c_inserted_count': 0, 'latest_phase_c_skipped_count': 10, 'latest_phase_d_rows_selected': 0, 'latest_phase_d_pass_count': 0, 'latest_phase_d_reject_count': 0, 'historical_reject_counts_by_class': {'dat': 10}},
                'action_reason_lines': ['Historical DAT rejects still exist.'],
            }
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, 'compute_operator_support_send_recommendation_core', return_value=recommendation):
                    ok, msg, path = cr.open_latest_artifact_triage_pack(repo)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            with open(path, 'r', encoding='utf-8') as f:
                body = f.read()
            self.assertIn('recommended_action_kind=historical_phase_d_reprocess', body)
            self.assertIn('historical_reject_counts_by_class=dat:10', body)

    def test_open_latest_system_health_pack_embeds_recommended_action_block(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            recommendation = {
                'recommended_action_kind': 'historical_phase_d_reprocess',
                'preferred_when_stable_action_kind': 'historical_phase_d_reprocess',
                'best_now_action_kind': 'historical_phase_d_reprocess',
                'recommended_report_kind': 'artifact_triage_pack',
                'recommended_artifact_classes': ['dat'],
                'action_requires_confirmation': True,
                'action_preview': {'latest_phase_c_inserted_count': 0, 'latest_phase_c_skipped_count': 10, 'latest_phase_d_rows_selected': 0, 'latest_phase_d_pass_count': 0, 'latest_phase_d_reject_count': 0, 'historical_reject_counts_by_class': {'dat': 10}},
                'action_reason_lines': ['Historical DAT rejects still exist.'],
            }
            with patch.object(cr, '_collect_system_health_artifacts', return_value={
                'repo_root': repo,
                'lab_root': lab,
                'reports_dir': reports,
                'consolidated_path': '',
                'audit_summary_txt': '',
                'audit_summary_json': '',
                'audit_metrics_json': '',
                'shadow_report_path': '',
                'shadow_index_path': '',
                'phase_f_mismatch_path': '',
                'delivery_status_path': '',
                'consolidated_message': '',
                'consolidated_ok': True,
            }):
                with patch.object(cr, '_build_system_health_pack_context', return_value={
                    'anchor_run_id': '20260329-171213-1ccb1c51',
                    'pack_scope': 'completed_run',
                    'active_run_id': '',
                    'expected_shadow_run_id': '20260329-171213-1ccb1c51',
                    'anchor_state': {},
                    'anchor_report_path': '',
                }):
                    with patch.object(cr, 'get_health_lines', return_value=['health ok']):
                        with patch.object(cr, '_build_system_health_alignment_notes', return_value={'notes': [], 'audit_stale': False, 'expected_shadow_run_id': '20260329-171213-1ccb1c51'}):
                            with patch.object(cr, '_build_anchor_run_snapshot_lines', return_value=['Anchored completed-run snapshot:']):
                                with patch.object(cr, '_build_recent_shadow_run_actual_lines', return_value=['Recent shadow runs:']):
                                    with patch.object(cr, '_collect_data_plane_snapshot', return_value={'ok': False, 'error': 'no db'}):
                                        with patch.object(cr, '_build_db_enrichment_overview_lines', return_value=[]):
                                            with patch.object(cr, '_build_system_health_pack_runbook', return_value=['What To Do Now:', ' 1) test']):
                                                with patch.object(cr, 'compute_operator_support_send_recommendation_core', return_value=recommendation):
                                                    ok, msg, path = cr.open_latest_system_health_pack(repo, lambda _n, default: default)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            with open(path, 'r', encoding='utf-8') as f:
                body = f.read()
            self.assertIn('recommended_action_kind=historical_phase_d_reprocess', body)
            self.assertIn('historical_reject_counts_by_class=dat:10', body)

    def test_send_latest_run_evidence_bundle_attaches_context_note_and_reprocess_reports(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            triage_path = os.path.join(reports, 'artifact_triage_pack_20260329-171213-1ccb1c51.txt')
            index_path = os.path.join(reports, 'run_artifact_index_20260329-171213-1ccb1c51.txt')
            delivery_path = os.path.join(reports, 'report_delivery_status.txt')
            context_note = os.path.join(reports, 'run_evidence_context_note_20260329-171213-1ccb1c51.txt')
            preview_path = os.path.join(reports, 'phase_d_historical_reprocess_preview_latest.txt')
            execution_path = os.path.join(reports, 'phase_d_historical_reprocess_execution_latest.txt')
            rid = '20260329-171213-1ccb1c51'
            hdr = (
                'Historical Phase D Re-Evaluation Preview\n'
                'generated_at_utc=test\n'
                'remediation_context_run_id={0}\n'.format(rid))
            with open(preview_path, 'w', encoding='utf-8') as f:
                f.write(hdr)
            with open(execution_path, 'w', encoding='utf-8') as f:
                f.write(hdr.replace('Preview', 'Execution'))
            for path in (triage_path, index_path, delivery_path, context_note):
                with open(path, 'w', encoding='utf-8') as f:
                    f.write('x')
            snapshot = {
                'repo_root': repo,
                'lab_root': lab,
                'reports_dir': reports,
                'run_id': '20260329-171213-1ccb1c51',
                'nearest_complete_run_id': '',
                'artifact_files': [],
                'context_files': [],
                'phase_rows': [],
            }
            recommendation = {
                'recommended_action_kind': 'historical_phase_d_reprocess',
                'recommended_report_kind': 'artifact_triage_pack',
                'recommended_artifact_classes': ['dat'],
                'action_requires_confirmation': True,
                'action_preview': {'historical_reject_counts_by_class': {'dat': 10}},
                'action_reason_lines': ['Historical DAT rejects still exist.'],
            }
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_select_evaluation_snapshot_for_recommendation', return_value=(
                        True, '', snapshot, {'live_run_id': snapshot['run_id'], 'live_run_status': 'completed'})):
                    with patch.object(cr, 'compute_operator_support_send_recommendation_core', return_value=recommendation):
                        with patch.object(cr, '_artifact_bundle_quality', return_value={'score': 80, 'label': 'HIGH', 'complete': 5, 'partial': 0, 'missing': 0, 'recommendation': 'send_current_run'}):
                            with patch.object(cr, '_write_artifact_triage_pack', return_value=triage_path):
                                with patch.object(cr, '_write_run_artifact_index', return_value=index_path):
                                    with patch.object(cr, 'open_report_delivery_status', return_value=(True, '', delivery_path)):
                                        with patch.object(cr, '_collect_run_evidence_context_attachment', return_value=(context_note, {'pack_scope': 'mixed_scope', 'anchor_run_id': 'other'})):
                                            with patch.object(cr, '_collect_delivery_diagnostics', return_value={}):
                                                with patch.object(cr, 'collect_support_bundle', return_value='/tmp/run_bundle.zip') as mock_collect:
                                                    with patch.object(cr, '_submit_bundle_with_delivery_diagnostics', return_value=(True, '', {})):
                                                        ok, msg, data = cr.send_latest_run_evidence_bundle(repo)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            basenames = [item[0] for item in mock_collect.call_args[1].get('extra_files', [])]
            self.assertIn(os.path.basename(context_note), basenames)
            self.assertIn(os.path.basename(preview_path), basenames)
            self.assertIn(os.path.basename(execution_path), basenames)
            self.assertEqual(data.get('context_attachment_path'), context_note)

    def test_send_latest_run_evidence_bundle_attaches_dat_smoke_artifacts_and_note(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            smoke_lab = os.path.join(repo, 'phase_d_dat_smoke_lab')
            smoke_reports = os.path.join(smoke_lab, 'reports')
            os.makedirs(reports)
            os.makedirs(smoke_reports)
            triage_path = os.path.join(reports, 'artifact_triage_pack_20260329-171213-1ccb1c51.txt')
            index_path = os.path.join(reports, 'run_artifact_index_20260329-171213-1ccb1c51.txt')
            delivery_path = os.path.join(reports, 'report_delivery_status.txt')
            context_note = os.path.join(reports, 'run_evidence_context_note_20260329-171213-1ccb1c51.txt')
            for path in (triage_path, index_path, delivery_path, context_note):
                with open(path, 'w', encoding='utf-8') as f:
                    f.write('x')
            smoke_run = '20260330-000001-smoke'
            smoke_report_txt = os.path.join(smoke_reports, 'phase_d_dat_smoke_report_{0}.txt'.format(smoke_run))
            smoke_report_json = os.path.join(smoke_reports, 'phase_d_dat_smoke_report_{0}.json'.format(smoke_run))
            smoke_shadow_json = os.path.join(smoke_reports, 'shadow_run_report_{0}.json'.format(smoke_run))
            smoke_shadow_txt = os.path.join(smoke_reports, 'shadow_run_report_{0}.txt'.format(smoke_run))
            with open(smoke_report_txt, 'w', encoding='utf-8') as f:
                f.write('smoke txt\n')
            with open(smoke_report_json, 'w', encoding='utf-8') as f:
                json.dump({'anchor_run_id': smoke_run, 'assessment': 'dat_discovered_not_ingested'}, f)
            with open(smoke_shadow_json, 'w', encoding='utf-8') as f:
                json.dump({'run_id': smoke_run}, f)
            with open(smoke_shadow_txt, 'w', encoding='utf-8') as f:
                f.write('shadow txt\n')
            state_path = cr.phase_d_dat_smoke_state_path(repo)
            state_parent = os.path.dirname(state_path)
            if state_parent and not os.path.isdir(state_parent):
                os.makedirs(state_parent)
            with open(state_path, 'w', encoding='utf-8') as f:
                json.dump({
                    'last_requested_anchor_run_id': '20260329-171213-1ccb1c51',
                    'last_requested_context_run_id': '20260329-171213-1ccb1c51',
                    'last_remediation_issue_code': '',
                    'last_status': 'completed',
                    'last_report_path': smoke_report_txt,
                    'last_assessment': 'dat_discovered_not_ingested',
                    'cooldown_until_utc': '2999-01-01T00:00:00Z',
                }, f)
            snapshot = {
                'repo_root': repo,
                'lab_root': lab,
                'reports_dir': reports,
                'run_id': '20260329-171213-1ccb1c51',
                'nearest_complete_run_id': '',
                'artifact_files': [],
                'context_files': [],
                'phase_rows': [],
            }
            recommendation = {
                'recommended_action_kind': 'phase_d_dat_smoke',
                'recommended_report_kind': 'artifact_triage_pack',
                'recommended_artifact_classes': ['dat'],
                'action_requires_confirmation': False,
                'dat_smoke_evaluated': True,
                'dat_smoke_available': True,
                'recommendation_anchor_run_id': '20260329-171213-1ccb1c51',
                'action_preview': {
                    'anchor_run_id': '20260329-171213-1ccb1c51',
                    'phase_d_context_run_id': '20260329-171213-1ccb1c51',
                    'smoke_lab_root': smoke_lab,
                    'smoke_reports_dir': smoke_reports,
                    'expected_report_path': os.path.join(smoke_reports, 'phase_d_dat_smoke_report_<smoke_pipeline_run_id>.txt'),
                    'reference_phase_d_summary_path': os.path.join(reports, 'qa_canonical_summary_20260329-171213-1ccb1c51.json'),
                },
            }
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_select_evaluation_snapshot_for_recommendation', return_value=(
                        True, '', snapshot, {'live_run_id': snapshot['run_id'], 'live_run_status': 'completed'})):
                    with patch.object(cr, 'compute_operator_support_send_recommendation_core', return_value=recommendation):
                        with patch.object(cr, '_artifact_bundle_quality', return_value={'score': 80, 'label': 'HIGH', 'complete': 5, 'partial': 0, 'missing': 0, 'recommendation': 'send_current_run'}):
                            with patch.object(cr, '_write_artifact_triage_pack', return_value=triage_path):
                                with patch.object(cr, '_write_run_artifact_index', return_value=index_path):
                                    with patch.object(cr, 'open_report_delivery_status', return_value=(True, '', delivery_path)):
                                        with patch.object(cr, '_collect_run_evidence_context_attachment', return_value=(context_note, {'pack_scope': 'mixed_scope', 'anchor_run_id': 'other'})):
                                            with patch.object(cr, '_collect_delivery_diagnostics', return_value={}):
                                                with patch.object(cr, 'collect_support_bundle', return_value='/tmp/run_bundle_smoke.zip') as mock_collect:
                                                    with patch.object(cr, '_submit_bundle_with_delivery_diagnostics', return_value=(True, '', {})):
                                                        ok, msg, _data = cr.send_latest_run_evidence_bundle(repo)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            basenames = [item[0] for item in mock_collect.call_args[1].get('extra_files', [])]
            self.assertIn('phase_d_dat_smoke_state.json', basenames)
            self.assertIn(os.path.basename(smoke_report_txt), basenames)
            self.assertIn(os.path.basename(smoke_report_json), basenames)
            self.assertIn(os.path.basename(smoke_shadow_json), basenames)
            self.assertIn(os.path.basename(smoke_shadow_txt), basenames)
            self.assertIn('run_evidence_dat_smoke_note_20260329-171213-1ccb1c51.txt', basenames)

    def test_send_latest_run_evidence_bundle_omits_phase_d_reprocess_when_not_historical_action(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            triage_path = os.path.join(reports, 'artifact_triage_pack_20260329-171213-1ccb1c51.txt')
            index_path = os.path.join(reports, 'run_artifact_index_20260329-171213-1ccb1c51.txt')
            delivery_path = os.path.join(reports, 'report_delivery_status.txt')
            context_note = os.path.join(reports, 'run_evidence_context_note_20260329-171213-1ccb1c51.txt')
            preview_path = os.path.join(reports, 'phase_d_historical_reprocess_preview_latest.txt')
            execution_path = os.path.join(reports, 'phase_d_historical_reprocess_execution_latest.txt')
            for path in (triage_path, index_path, delivery_path, context_note, preview_path, execution_path):
                with open(path, 'w', encoding='utf-8') as f:
                    f.write('stale\n')
            snapshot = {
                'repo_root': repo,
                'lab_root': lab,
                'reports_dir': reports,
                'run_id': '20260329-171213-1ccb1c51',
                'nearest_complete_run_id': '',
                'artifact_files': [],
                'context_files': [],
                'phase_rows': [],
            }
            recommendation = {
                'recommended_action_kind': 'send_bundle',
                'recommended_report_kind': 'artifact_triage_pack',
            }
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_select_evaluation_snapshot_for_recommendation', return_value=(
                        True, '', snapshot, {'live_run_id': snapshot['run_id'], 'live_run_status': 'completed'})):
                    with patch.object(cr, 'compute_operator_support_send_recommendation_core', return_value=recommendation):
                        with patch.object(cr, '_artifact_bundle_quality', return_value={'score': 80, 'label': 'HIGH', 'complete': 5, 'partial': 0, 'missing': 0, 'recommendation': 'send_current_run'}):
                            with patch.object(cr, '_write_artifact_triage_pack', return_value=triage_path):
                                with patch.object(cr, '_write_run_artifact_index', return_value=index_path):
                                    with patch.object(cr, 'open_report_delivery_status', return_value=(True, '', delivery_path)):
                                        with patch.object(cr, '_collect_run_evidence_context_attachment', return_value=('', {})):
                                            with patch.object(cr, '_collect_delivery_diagnostics', return_value={}):
                                                with patch.object(cr, 'collect_support_bundle', return_value='/tmp/run_bundle2.zip') as mock_collect:
                                                    with patch.object(cr, '_submit_bundle_with_delivery_diagnostics', return_value=(True, '', {})):
                                                        ok, msg, _data = cr.send_latest_run_evidence_bundle(repo)
            self.assertTrue(ok)
            basenames = [item[0] for item in mock_collect.call_args[1].get('extra_files', [])]
            self.assertNotIn('phase_d_historical_reprocess_preview_latest.txt', basenames)
            self.assertNotIn('phase_d_historical_reprocess_execution_latest.txt', basenames)


class TestRecommendationAndBundleEdgeCases(unittest.TestCase):
    """Paths that exercise pack context, interrupt attachment rules, and Phase D dedupe."""

    def test_phase_d_dat_smoke_paths_qa_full_block_mismatch_emits_note_only(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            smoke_reports = os.path.join(repo, 'phase_d_dat_smoke_lab', 'reports')
            os.makedirs(reports)
            os.makedirs(smoke_reports)
            reviewed = '20260329-171213-1ccb1c51'
            other = '20260331-022246-3b508c10'
            smoke_txt = os.path.join(smoke_reports, 'phase_d_dat_smoke_report_{0}.txt'.format(other))
            smoke_json = os.path.join(smoke_reports, 'phase_d_dat_smoke_report_{0}.json'.format(other))
            with open(smoke_txt, 'w', encoding='utf-8') as f:
                f.write('x')
            with open(smoke_json, 'w', encoding='utf-8') as f:
                json.dump({'anchor_run_id': other, 'assessment': 'dat_selected_qa_blocked'}, f)
            state_path = os.path.join(lab, 'phase_d_dat_smoke_state.json')
            with open(state_path, 'w', encoding='utf-8') as f:
                json.dump({
                    'last_status': 'completed',
                    'last_report_path': smoke_txt,
                    'last_assessment': 'dat_selected_qa_blocked',
                }, f)
            rec = {
                'recommended_action_kind': 'review_dat_qa_full_block',
                'recommendation_anchor_run_id': reviewed,
                'action_preview': {'anchor_run_id': reviewed},
            }
            paths = cr._phase_d_dat_smoke_report_paths_for_run_evidence(repo, lab, rec, reviewed)
            self.assertTrue(any('run_evidence_smoke_anchor_mismatch_' in os.path.basename(p) for p in paths))
            self.assertFalse(any(os.path.basename(p).startswith('phase_d_dat_smoke_report') for p in paths))
            note_path = next(p for p in paths if 'run_evidence_smoke_anchor_mismatch_' in os.path.basename(p))
            with open(note_path, 'r', encoding='utf-8') as f:
                body = f.read()
            self.assertIn('smoke_state_last_status=completed', body)
            self.assertIn('smoke_state_last_assessment=dat_selected_qa_blocked', body)
            self.assertIn('smoke_report_anchor_mismatch', body)

    def test_phase_d_dat_smoke_paths_qa_full_block_missing_report_still_emits_note(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            reviewed = '20260329-171213-1ccb1c51'
            state_path = os.path.join(lab, 'phase_d_dat_smoke_state.json')
            with open(state_path, 'w', encoding='utf-8') as f:
                json.dump({
                    'last_status': 'completed',
                    'last_report_path': '',
                    'last_assessment': 'dat_selected_qa_blocked',
                }, f)
            rec = {
                'recommended_action_kind': 'review_dat_qa_full_block',
                'recommendation_anchor_run_id': reviewed,
                'action_preview': {'anchor_run_id': reviewed},
            }
            paths = cr._phase_d_dat_smoke_report_paths_for_run_evidence(repo, lab, rec, reviewed)
            self.assertEqual(len(paths), 1)
            note_path = paths[0]
            self.assertIn('run_evidence_smoke_anchor_mismatch_', os.path.basename(note_path))
            with open(note_path, 'r', encoding='utf-8') as f:
                body = f.read()
            self.assertIn('last_report_path=-', body)
            self.assertIn('state_last_report_path_missing', body)
            self.assertIn('smoke_report_anchor_run_id_missing', body)

    def test_phase_d_reprocess_paths_for_run_evidence_skips_metadata_mismatch(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as lab:
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            prev = os.path.join(reports, 'phase_d_historical_reprocess_preview_latest.txt')
            exe = os.path.join(reports, 'phase_d_historical_reprocess_execution_latest.txt')
            for p in (prev, exe):
                with open(p, 'w', encoding='utf-8') as f:
                    f.write('Historical Phase D Re-Evaluation\n')
                    f.write('remediation_context_run_id=wrong-run\n')
            rec = {
                'recommended_action_kind': 'historical_phase_d_reprocess',
                'recommendation_anchor_run_id': 'anchor-z',
            }
            paths = cr._phase_d_reprocess_report_paths_for_run_evidence(lab, rec, 'bundle-b')
            self.assertEqual(paths, [])

    def test_phase_d_reprocess_paths_legacy_without_metadata_returns_empty(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as lab:
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            for name in (
                    'phase_d_historical_reprocess_preview_latest.txt',
                    'phase_d_historical_reprocess_execution_latest.txt'):
                with open(os.path.join(reports, name), 'w', encoding='utf-8') as f:
                    f.write('legacy pre-upgrade body\n')
            rec = {
                'recommended_action_kind': 'historical_phase_d_reprocess',
                'recommendation_anchor_run_id': 'anchor-z',
            }
            paths = cr._phase_d_reprocess_report_paths_for_run_evidence(lab, rec, 'bundle-b')
            self.assertEqual(paths, [])

    def test_phase_d_reprocess_paths_preview_only_missing_execution_returns_empty(self):
        """Preview-only historical reprocess report is surfaced elsewhere, not in run-evidence ZIP rules."""
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as lab:
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            prev = os.path.join(reports, 'phase_d_historical_reprocess_preview_latest.txt')
            with open(prev, 'w', encoding='utf-8') as f:
                f.write('Historical Phase D Re-Evaluation Preview\nremediation_context_run_id=anchor-z\n')
            rec = {
                'recommended_action_kind': 'historical_phase_d_reprocess',
                'recommendation_anchor_run_id': 'anchor-z',
                'historical_reprocess_preview_path': prev,
            }
            paths = cr._phase_d_reprocess_report_paths_for_run_evidence(lab, rec, 'anchor-z')
            self.assertEqual(paths, [])

    def test_phase_d_reprocess_paths_attaches_when_preview_execution_agree_and_match_bundle(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as lab:
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            rid = 'bundle-match-1'
            prev = os.path.join(reports, 'phase_d_historical_reprocess_preview_latest.txt')
            exe = os.path.join(reports, 'phase_d_historical_reprocess_execution_latest.txt')
            for p in (prev, exe):
                with open(p, 'w', encoding='utf-8') as f:
                    f.write('Historical Phase D\nremediation_context_run_id={0}\n'.format(rid))
            rec = {'recommended_action_kind': 'historical_phase_d_reprocess'}
            paths = cr._phase_d_reprocess_report_paths_for_run_evidence(lab, rec, rid)
            self.assertEqual(len(paths), 2)
            self.assertIn(prev, paths)
            self.assertIn(exe, paths)

    def test_latest_interrupt_report_paths_filters_mismatched_bundle_run_id(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as lab:
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            jpath = os.path.join(reports, 'shadow_pipeline_interrupt_latest.json')
            with open(jpath, 'w', encoding='utf-8') as f:
                f.write(json.dumps({'run_id': 'run-a'}))
            tpath = os.path.join(reports, 'shadow_pipeline_interrupt_latest.txt')
            with open(tpath, 'w', encoding='utf-8') as f:
                f.write('interrupt txt')
            self.assertEqual(len(cr._latest_interrupt_report_paths(lab, bundle_run_id='run-b')), 0)
            self.assertEqual(len(cr._latest_interrupt_report_paths(lab, bundle_run_id='run-a')), 2)
            self.assertEqual(len(cr._latest_interrupt_report_paths(lab)), 2)

    def test_collect_phase_d_reject_snapshot_dedupes_artifact_ids_across_qa_versions(self):
        from scripts.unified_model.phase_d_historical_reprocess import collect_phase_d_reject_snapshot
        with tempfile.TemporaryDirectory() as lab:
            db_path = os.path.join(lab, 'unified_model_xp.db')
            conn = sqlite3.connect(db_path)
            conn.execute(
                'CREATE TABLE ingest_artifact (artifact_id INTEGER PRIMARY KEY, source_type TEXT, payload_json TEXT)')
            conn.execute(
                'CREATE TABLE qa_result (artifact_id INTEGER, qa_stage TEXT, qa_version TEXT, status TEXT)')
            conn.execute('CREATE TABLE replay_queue (artifact_id INTEGER, status TEXT)')
            conn.execute('INSERT INTO ingest_artifact VALUES (1, "file_dat", "{}")')
            conn.execute('INSERT INTO qa_result VALUES (1, "phase_d", "qa_v1", "reject")')
            conn.execute('INSERT INTO qa_result VALUES (1, "phase_d", "qa_v2", "reject")')
            conn.commit()
            conn.close()
            snap = collect_phase_d_reject_snapshot(lab, qa_version=None)
            self.assertTrue(snap.get('ok'))
            self.assertEqual(snap.get('targeted_artifact_count'), 1)
            self.assertEqual(snap.get('targeted_artifact_ids'), [1])
            self.assertEqual(snap.get('reject_counts_by_class', {}).get('dat'), 2)

    def test_compute_operator_support_send_recommendation_invokes_selector_with_pack_context(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab, 'reports'))
            with patch.object(cr, '_collect_system_health_artifacts', return_value={
                'lab_root': lab,
                'reports_dir': os.path.join(lab, 'reports'),
                'shadow_report_path': '',
            }):
                with patch.object(cr, '_build_system_health_pack_context', return_value={
                    'pack_scope': 'mixed_scope',
                    'anchor_run_id': 'anchor-rid',
                }):
                    with patch.object(cr, '_select_evaluation_snapshot_for_recommendation') as mock_sel:
                        mock_sel.return_value = (
                            True,
                            '',
                            {'run_id': 'anchor-rid', 'diagnostics_state': {}, 'lab_root': lab},
                            {
                                'live_run_id': 'live-rid',
                                'recommendation_source_scope': 'anchored_completed_run',
                                'recommendation_anchor_run_id': 'anchor-rid',
                                'fallback_note': '',
                                'newer_live_context_note': '',
                            },
                        )
                        with patch.object(cr, 'compute_operator_support_send_recommendation_core') as mock_core:
                            mock_core.return_value = {'summary_line': 'ok'}
                            cr.compute_operator_support_send_recommendation(repo)
        mock_sel.assert_called_once()
        self.assertEqual(mock_core.call_args[0][1].get('run_id'), 'anchor-rid')
        kwargs = mock_core.call_args[1]
        self.assertEqual(kwargs.get('recommendation_source_scope'), 'anchored_completed_run')
        self.assertEqual(kwargs.get('recommendation_anchor_run_id'), 'anchor-rid')
        self.assertEqual(kwargs.get('recommendation_live_run_id'), 'live-rid')

    def test_select_evaluation_snapshot_live_run_id_prefers_diagnostics_over_artifact_snapshot(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            state_path = os.path.join(lab, 'diagnostics_state.json')
            with open(state_path, 'w', encoding='utf-8') as f:
                f.write(json.dumps({'active_run_id': 'run-a', 'last_shadow_pipeline_run_id': ''}))
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', {'run_id': 'run-b'})):
                with patch.object(cr, 'is_pipeline_running', return_value=False):
                    ok, _msg, _snap, meta = cr._select_evaluation_snapshot_for_recommendation(repo, {})
            self.assertEqual(meta.get('live_run_id'), 'run-a')

    def test_relax_anchor_clears_coherence_block_for_conflicting_live_diagnostics(self):
        from MediCafe import cloud_readiness as cr
        from MediCafe import cloud_readiness_artifact_tools as art
        anchor_id = '20260329-171213-1ccb1c51'
        anchor_snap = {
            'run_id': anchor_id,
            'diagnostics_state': {
                'pipeline_state': 'failed',
                'active_run_id': 'other-run',
                'last_shadow_pipeline_run_id': 'zzz',
            },
        }
        self.assertTrue(art.artifact_snapshot_coherence_blocked(anchor_snap))
        relaxed = cr._relax_snapshot_diagnostics_for_anchor_evaluation(anchor_snap, anchor_id)
        self.assertFalse(art.artifact_snapshot_coherence_blocked(relaxed))

    def test_relax_anchor_clears_lineage_issues_for_handoff_coherence(self):
        """Zero-selection / phase_run_id skew surfaces as lineage_issues; anchor eval must ignore it."""
        from MediCafe import cloud_readiness as cr
        from MediCafe import cloud_readiness_artifact_tools as art
        anchor_id = '20260331-005932-ba25d2aa'
        anchor_snap = {
            'run_id': anchor_id,
            'diagnostics_state': {},
            'lineage_issues': [
                'phase_d_zero_selection_phase_c_run_id_mismatch expected_phase_c=old resolved_phase_c=new',
            ],
        }
        self.assertTrue(art.artifact_snapshot_coherence_blocked(anchor_snap))
        relaxed = cr._relax_snapshot_diagnostics_for_anchor_evaluation(anchor_snap, anchor_id)
        self.assertFalse(art.artifact_snapshot_coherence_blocked(relaxed))
        self.assertEqual(relaxed.get('lineage_issues'), [])

    def test_select_evaluation_snapshot_returns_relaxed_anchor_for_mixed_scope(self):
        from MediCafe import cloud_readiness as cr
        anchor_id = '20260329-171213-1ccb1c51'
        anchor_snap_raw = {
            'run_id': anchor_id,
            'lab_root': '/tmp',
            'diagnostics_state': {
                'pipeline_state': 'failed',
                'active_run_id': 'other',
                'last_shadow_pipeline_run_id': 'zzz',
            },
        }
        latest = {'run_id': 'older-artifact-run', 'diagnostics_state': {}}

        def fake_build(repo_root, run_id=''):
            rid = str(run_id or '').strip()
            if rid == anchor_id:
                return True, '', dict(anchor_snap_raw)
            return True, '', dict(latest)

        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab, 'reports'))
            with patch.object(cr, '_build_run_artifact_snapshot', side_effect=fake_build):
                with patch.object(cr, 'is_pipeline_running', return_value=False):
                    ok, msg, snap, meta = cr._select_evaluation_snapshot_for_recommendation(
                        repo,
                        {'pack_scope': 'mixed_scope', 'anchor_run_id': anchor_id},
                    )
        self.assertTrue(ok)
        self.assertEqual(meta.get('recommendation_source_scope'), 'anchored_completed_run')
        self.assertEqual(snap.get('run_id'), anchor_id)
        self.assertEqual(str(snap.get('diagnostics_state', {}).get('pipeline_state')), 'completed')

    def test_run_phase_d_dat_smoke_returns_already_running_before_spawn(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            script_root = os.path.join(repo, 'scripts')
            script_path = os.path.join(script_root, 'run_phase_d_dat_smoke.py')
            os.makedirs(script_root)
            with open(script_path, 'w', encoding='utf-8') as f:
                f.write('# stub\n')
            with patch.object(
                    cr,
                    '_resolve_unified_model_script',
                    return_value=(True, '', script_root, script_path, None)):
                with patch.object(cr, 'is_pipeline_running', return_value=True):
                    with patch.object(cr.subprocess, 'Popen') as mock_popen:
                        ok, msg, meta = cr.run_phase_d_dat_smoke(repo, sys.executable, {})
        self.assertFalse(ok)
        self.assertIn('already running', msg.lower())
        self.assertTrue(bool((meta or {}).get('already_running')))
        mock_popen.assert_not_called()

    def test_run_phase_d_dat_smoke_spawn_failure_transitions_to_failed_without_cooldown(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            script_root = os.path.join(repo, 'scripts')
            script_path = os.path.join(script_root, 'run_phase_d_dat_smoke.py')
            os.makedirs(script_root)
            with open(script_path, 'w', encoding='utf-8') as f:
                f.write('# stub\n')

            state_path = cr.phase_d_dat_smoke_state_path(repo)
            parent = os.path.dirname(state_path)
            if parent and not os.path.isdir(parent):
                os.makedirs(parent)
            with open(state_path, 'w', encoding='utf-8') as f:
                json.dump({
                    'last_requested_anchor_run_id': 'old-anchor',
                    'last_requested_context_run_id': 'old-context',
                    'last_remediation_issue_code': 'OLD_ISSUE',
                    'last_status': 'completed',
                    'cooldown_until_utc': '2999-01-01T00:00:00Z',
                }, f)

            with patch.object(
                    cr,
                    '_resolve_unified_model_script',
                    return_value=(True, '', script_root, script_path, None)):
                with patch.object(cr, 'is_pipeline_running', return_value=False):
                    with patch.object(cr.subprocess, 'Popen', side_effect=RuntimeError('spawn failed')):
                        ok, msg, _meta = cr.run_phase_d_dat_smoke(
                            repo,
                            sys.executable,
                            {},
                            recommendation_anchor_run_id='anchor-new',
                            recommendation_context_run_id='ctx-new',
                            recommendation_issue_code='ISSUE_NEW',
                        )

            self.assertFalse(ok)
            self.assertIn('spawn failed', msg.lower())
            state = cr.read_phase_d_dat_smoke_state(repo)
            self.assertEqual(state.get('last_requested_anchor_run_id'), 'anchor-new')
            self.assertEqual(state.get('last_requested_context_run_id'), 'ctx-new')
            self.assertEqual(state.get('last_remediation_issue_code'), 'ISSUE_NEW')
            self.assertEqual(str(state.get('last_status', '')).lower(), 'failed')
            self.assertEqual(state.get('last_assessment'), 'spawn_failed')
            self.assertEqual(state.get('cooldown_until_utc'), '')
            self.assertTrue(bool(state.get('last_finished_at_utc')))
            self.assertFalse(
                cr._phase_d_dat_smoke_state_suppressed(state, 'anchor-new', 'ctx-new', 'ISSUE_NEW')
            )


class TestPhaseDRemediationOperatorSurfaces(unittest.TestCase):
    """phase_d_remediation formatting and recommendation merge; keeps operator surfaces aligned with phase_d_remediation.py."""

    def test_format_phase_d_remediation_surfaces_emits_stable_tokens(self):
        from MediCafe.cloud_readiness_artifact_tools import format_phase_d_remediation_surfaces
        rem = {
            'verification_target': 'phase_d_constraint_skips',
            'verification_scope': 'global_phase_d',
            'milestone_exit_ready': False,
            'issue_code': 'PHASE_D_INVALID_EXTERNAL_ID_SPIKE',
            'status': 'active',
            'context_run_id': 'run-x',
        }
        lines = format_phase_d_remediation_surfaces(rem)
        joined = '\n'.join(lines)
        self.assertIn('phase_d_remediation: verification_target=phase_d_constraint_skips', joined)
        self.assertIn('phase_d_remediation: verification_scope=global_phase_d', joined)
        self.assertIn('phase_d_remediation: milestone_exit_ready=False', joined)
        self.assertIn('phase_d_remediation: issue_code=', joined)
        self.assertIn('phase_d_remediation glossary:', joined)

    def test_compute_operator_support_send_recommendation_core_merges_phase_d_remediation(self):
        from MediCafe import cloud_readiness as cr
        from MediCafe.cloud_readiness_artifact_tools import format_phase_d_remediation_surfaces
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            os.makedirs(lab)
            rem = {
                'version': 1,
                'issue_code': 'PHASE_D_INVALID_EXTERNAL_ID_SPIKE',
                'status': 'active',
                'context_run_id': 'rid-1',
                'verification_target': 'phase_d_constraint_skips',
                'verification_scope': 'global_phase_d',
                'milestone_exit_ready': False,
            }
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                f.write(json.dumps({'phase_d_remediation': rem}))
            # Positional order: repo_root, evaluation_snapshot, ok_snap, snap_msg, pipeline_running, ...
            out = cr.compute_operator_support_send_recommendation_core(
                repo,
                {'run_id': 'rid-1', 'nearest_complete_run_id': ''},
                ok_snap=False,
                snap_msg='no snapshot',
                pipeline_running=False,
            )
        self.assertEqual(out.get('phase_d_remediation'), rem)
        self.assertFalse(out.get('pipeline_running'))
        self.assertEqual(out.get('pipeline_label'), 'idle')
        expected_extra = format_phase_d_remediation_surfaces(rem)
        why = out.get('why_lines') or []
        for line in expected_extra:
            self.assertIn(line, why)

    def test_build_patient_trace_decision_surfaces_phase_d_remediation_keys(self):
        from MediCafe.cloud_readiness_patient_tools import build_patient_trace_decision
        selected = {
            'missing_fields': [],
            'reason': 'test',
            'claim_count': 1,
            'canonical_count': 1,
            'projection_reject_count': 0,
        }
        trace = {'rows': {'qa_result': [], 'replay_queue': []}}
        pdr = {
            'issue_code': 'PHASE_D_DAT_QA_FULL_BLOCK',
            'status': 'active',
            'context_run_id': 'anchor-rid',
            'verification_target': 'phase_d_dat_lane',
            'verification_scope': 'dat_lane_only',
            'milestone_exit_ready': None,
        }
        diag_state = {'phase_d_remediation': pdr}
        result = build_patient_trace_decision(selected, trace, diag_state)
        d = result.get('diagnostics') if isinstance(result.get('diagnostics'), dict) else {}
        self.assertEqual(d.get('phase_d_remediation_issue_code'), 'PHASE_D_DAT_QA_FULL_BLOCK')
        self.assertEqual(d.get('phase_d_remediation_status'), 'active')
        self.assertEqual(d.get('phase_d_remediation_context_run_id'), 'anchor-rid')
        self.assertEqual(d.get('phase_d_remediation_verification_target'), 'phase_d_dat_lane')
        self.assertEqual(d.get('phase_d_remediation_verification_scope'), 'dat_lane_only')
        self.assertIsNone(d.get('phase_d_remediation_milestone_exit_ready'))


# cloud_readiness_health.py does not yet surface phase_d_remediation; extend test_cloud_readiness_health.py when it does.

if __name__ == '__main__':
    unittest.main()
