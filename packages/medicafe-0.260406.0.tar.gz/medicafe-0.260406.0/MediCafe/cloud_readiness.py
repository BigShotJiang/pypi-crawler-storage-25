#!/usr/bin/env python
# pyright: reportArgumentType=false, reportOptionalMemberAccess=false
"""
Cloud Readiness Pipeline service module.

Service-only: no UI. Launcher delegates phase actions here.
Returns (ok, message, data); no exceptions to caller.
Python 3.4 compatible.
"""
from __future__ import print_function

import json
import os
import re
import calendar
import sqlite3
import subprocess
import sys
import time
from MediCafe import shadow_orchestrator
from MediCafe import cloud_readiness_artifact_tools as _artifact_tools
from MediCafe import cloud_readiness_patient_tools as _patient_tools
from MediCafe import cloud_readiness_runbooks as _runbook_tools

try:
    from MediCafe.MediLink_ConfigLoader import log as mc_log
except Exception:
    mc_log = None

try:
    from MediCafe.cloud_readiness_health import build_cloud_health_lines
except Exception:
    build_cloud_health_lines = None

try:
    from MediCafe.error_reporter import (
        collect_support_bundle,
        submit_support_bundle_email,
        get_error_reporting_delivery_readiness,
    )
except Exception:
    collect_support_bundle = None
    submit_support_bundle_email = None
    get_error_reporting_delivery_readiness = None

try:
    from scripts.unified_model.phase_d_historical_reprocess import (
        collect_phase_d_reject_snapshot as _collect_phase_d_reject_snapshot_impl,
        execute_historical_phase_d_reprocess as _execute_historical_phase_d_reprocess_impl,
        normalize_artifact_classes as _normalize_phase_d_reprocess_classes_impl,
        preview_historical_phase_d_reprocess as _preview_historical_phase_d_reprocess_impl,
    )
except Exception:
    try:
        from phase_d_historical_reprocess import (
            collect_phase_d_reject_snapshot as _collect_phase_d_reject_snapshot_impl,
            execute_historical_phase_d_reprocess as _execute_historical_phase_d_reprocess_impl,
            normalize_artifact_classes as _normalize_phase_d_reprocess_classes_impl,
            preview_historical_phase_d_reprocess as _preview_historical_phase_d_reprocess_impl,
        )
    except Exception:
        _collect_phase_d_reject_snapshot_impl = None
        _execute_historical_phase_d_reprocess_impl = None
        _normalize_phase_d_reprocess_classes_impl = None
        _preview_historical_phase_d_reprocess_impl = None

try:
    from scripts.unified_model.phase_d_backlog_signals import (
        historical_reprocess_numeric_predicates as _historical_reprocess_numeric_predicates,
    )
except Exception:
    try:
        from phase_d_backlog_signals import (
            historical_reprocess_numeric_predicates as _historical_reprocess_numeric_predicates,
        )
    except Exception:
        _historical_reprocess_numeric_predicates = None

# Avoid `from subprocess import DEVNULL` + reassignment: typeshed marks DEVNULL as Final.
_subprocess_devnull = getattr(subprocess, 'DEVNULL', None)
if _subprocess_devnull is not None:
    DEVNULL = _subprocess_devnull
else:
    DEVNULL = open(os.devnull, 'wb')

# KEEP IN SYNC WITH scripts/unified_model/shadow_run_actuals.SHADOW_ACTUAL_INT_FIELDS (parity tests).
_SHADOW_ACTUAL_INT_FIELDS_FALLBACK = (
    "phase_b_dat_manifest_rows_count",
    "phase_d_dat_selected_count",
    "phase_d_dat_qa_pass_count",
    "phase_d_dat_qa_reject_count",
    "phase_d_dat_canonical_record_count",
    "phase_d_dat_v2_payload_attempted_total",
    "phase_d_dat_v2_inserted_total",
    "phase_d_dat_v2_skipped_total",
    "phase_d_dat_v2_constraint_failed_total",
)
try:
    from scripts.unified_model.shadow_run_actuals import (
        SHADOW_ACTUAL_FIELDS_VERSION,
        SHADOW_ACTUAL_INT_FIELDS,
        normalize_shadow_actual as _normalize_shadow_actual_impl,
    )
except Exception:
    try:
        import shadow_run_actuals as _shadow_run_actuals_mod
        SHADOW_ACTUAL_FIELDS_VERSION = getattr(_shadow_run_actuals_mod, "SHADOW_ACTUAL_FIELDS_VERSION", 1)
        SHADOW_ACTUAL_INT_FIELDS = getattr(
            _shadow_run_actuals_mod, "SHADOW_ACTUAL_INT_FIELDS", _SHADOW_ACTUAL_INT_FIELDS_FALLBACK
        )
        _normalize_shadow_actual_impl = _shadow_run_actuals_mod.normalize_shadow_actual
    except Exception:
        SHADOW_ACTUAL_FIELDS_VERSION = 1
        SHADOW_ACTUAL_INT_FIELDS = _SHADOW_ACTUAL_INT_FIELDS_FALLBACK
        _normalize_shadow_actual_impl = None


_HEALTH_TRACKER_FILENAME = 'cloud_health_tracker.json'
_HEALTH_ALERT_STATE_FILENAME = 'cloud_health_alert_state.json'
_ORCHESTRATOR_ALERT_STATE_FILENAME = 'orchestrator_failure_alert_state.json'
_ORCHESTRATOR_ALERT_DEDUP_WINDOW_SEC = 10 * 60
_WARN_ESCALATION_MIN_COUNT = 3
_WARN_ESCALATION_MIN_AGE_SEC = 120
_ALERT_DEDUP_WINDOW_SEC = 6 * 60 * 60
# Bootstrap-only warn codes: expected before any pipeline run; do not escalate to incident alerts.
_WARN_NON_ESCALATING_CODES = frozenset([
    'DIAGNOSTICS_STATE_MISSING',
    'PHASE_B_NOT_RUN', 'PHASE_C_NOT_RUN', 'PHASE_D_NOT_RUN',
    'PHASE_E_NOT_RUN', 'PHASE_F_NOT_RUN',
])
_PHASE_ORDER = {'A': 1, 'B': 2, 'C': 3, 'D': 4, 'E': 5, 'F': 6}
# Keep aligned with scripts/unified_model/unified_rollout_policy.py (D-032).
# TODO(theme5): If policy constants change, update this value or refactor shared import; grep TODO(theme5).
_PHASE_D_INVALID_EXTERNAL_ID_RATIO_PASS_MAX = 0.02


def _seed_diagnostics_state_if_missing(state_path):
    """Best-effort bootstrap of diagnostics_state.json when absent."""
    if not state_path or os.path.exists(state_path):
        return False
    now_utc = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
    seed = {
        'version': 2,
        'updated_at_utc': now_utc,
        'last_phase_a_run_id': '',
        'last_phase_a_ok': None,
        'last_schema_sha256': '',
        'last_discovery_ok': None,
        'last_phase_c_ok': None,
        'last_phase_d_ok': None,
        'last_phase_e_ok': None,
        'last_shadow_pipeline_ok': None,
        'pipeline_state': 'idle',
        'active_run_id': '',
        'active_phase': '',
        'last_error_code': '',
        'started_at_utc': now_utc,
        'heartbeat_at_utc': None,
        'finished_at_utc': None,
    }
    return _save_json_dict(state_path, seed)


def _tail_parts_cross_platform(path_value):
    """Return (tail, parent_tail) while treating "\\" and "/" as path separators."""
    normalized = str(path_value or '').replace('\\', '/')
    parts = [p for p in normalized.split('/') if p]
    tail = parts[-1].lower() if parts else ''
    parent_tail = parts[-2].lower() if len(parts) >= 2 else ''
    return tail, parent_tail


def _log_health(level, message):
    """Best-effort logger for cloud readiness diagnostics."""
    try:
        if mc_log is not None:
            mc_log(message, level=level)
            return
    except Exception:
        pass
    try:
        print('{0}: {1}'.format(level, message))
    except Exception:
        pass


def _load_json_dict(path):
    if not path or not os.path.exists(path):
        return {}
    try:
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        if isinstance(data, dict):
            return data
    except (IOError, OSError, ValueError):
        pass
    return {}


def _save_json_dict(path, data):
    try:
        parent = os.path.dirname(path)
        if parent and not os.path.exists(parent):
            os.makedirs(parent)
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, sort_keys=True)
        return True
    except Exception:
        return False


def _collect_delivery_diagnostics():
    """Best-effort sender readiness snapshot for support-bundle telemetry."""
    diagnostics = {'token_available': None, 'recipient_count': None}
    if get_error_reporting_delivery_readiness is None:
        diagnostics['helper_unavailable'] = True
        return diagnostics
    try:
        shared = get_error_reporting_delivery_readiness(
            quiet_token=True,
            include_queue_paths=True,
        )
        if isinstance(shared, dict):
            diagnostics.update(shared)
    except Exception as e:
        diagnostics['helper_error'] = str(e)
    return diagnostics


def _emit_progress(progress_callback, stage_label):
    """Best-effort coarse status update for long-running cloud-readiness actions."""
    if not callable(progress_callback):
        return
    try:
        progress_callback(str(stage_label or '').strip())
    except Exception:
        pass


def _format_epoch_utc(epoch_value):
    try:
        if epoch_value is None:
            return ''
        return time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(int(epoch_value)))
    except Exception:
        return ''


def _parse_iso_utc_epoch(text_value):
    """Best-effort parse for %Y-%m-%dT%H:%M:%SZ timestamps."""
    try:
        text = str(text_value or '').strip()
        if not text:
            return None
        return int(calendar.timegm(time.strptime(text, '%Y-%m-%dT%H:%M:%SZ')))
    except Exception:
        return None


def _collect_failed_or_warned_signals(audit_payload):
    return _runbook_tools.collect_failed_or_warned_signals(audit_payload)


def _build_system_health_triage_runbook(audit_ok, audit_data, pack_ok, pack_path, report_path):
    return _runbook_tools.build_system_health_triage_runbook(
        audit_ok,
        audit_data,
        pack_ok,
        pack_path,
        report_path,
        collect_failed_or_warned_signals_fn=_collect_failed_or_warned_signals,
    )


def _build_system_health_pack_runbook(lab_root, audit_payload, artifacts, state_override=None, pack_scope='', anchor_run_id=''):
    return _runbook_tools.build_system_health_pack_runbook(
        lab_root,
        audit_payload,
        artifacts,
        parse_iso_utc_epoch_fn=_parse_iso_utc_epoch,
        load_json_dict_fn=_load_json_dict,
        state_override=state_override,
        pack_scope=pack_scope,
        anchor_run_id=anchor_run_id,
    )


def _build_delivery_runbook_lines(delivery_diag, orchestrator_error_code=None):
    return _runbook_tools.build_delivery_runbook_lines(
        delivery_diag,
        orchestrator_error_code=orchestrator_error_code,
    )


def _safe_json_loads(value, default=None):
    return _patient_tools.safe_json_loads(value, default=default)


def _safe_int(value, fallback=0):
    return _patient_tools.safe_int(value, fallback=fallback)


def _slug_token(value, fallback='unknown'):
    return _patient_tools.slug_token(value, fallback=fallback)


def _collect_data_plane_snapshot(lab_root):
    return _patient_tools.collect_data_plane_snapshot(
        lab_root,
        safe_int_fn=_safe_int,
    )


def _collect_db_enrichment_summary(lab_root):
    return _patient_tools.collect_db_enrichment_summary(
        lab_root,
        safe_int_fn=_safe_int,
    )


def _sorted_count_items(counts, preferred_keys=None):
    counts = counts if isinstance(counts, dict) else {}
    preferred = preferred_keys or []
    items = []
    seen = set()
    for key in preferred:
        if key in counts and key not in seen:
            items.append((key, _safe_int(counts.get(key), 0)))
            seen.add(key)
    remainder = []
    for key, value in counts.items():
        if key in seen:
            continue
        remainder.append((str(key), _safe_int(value, 0)))
    remainder = sorted(remainder, key=lambda item: (-_safe_int(item[1], 0), str(item[0])))
    items.extend(remainder)
    return items


def _format_count_map(counts, preferred_keys=None, limit=None):
    items = _sorted_count_items(counts, preferred_keys=preferred_keys)
    if limit is not None:
        items = items[:max(0, _safe_int(limit, 0))]
    if not items:
        return 'none'
    return ', '.join('{0}:{1}'.format(key, value) for key, value in items)


def _build_db_enrichment_overview_lines(lab_root, snapshot=None, compact=False):
    title = 'DB enrichment overview (cumulative lab state):' if compact else 'DB Enrichment Overview:'
    lines = [title]
    snap = snapshot if isinstance(snapshot, dict) else _collect_data_plane_snapshot(lab_root)
    if not snap.get('ok'):
        lines.append(' - unavailable ({0})'.format(snap.get('error') or 'db snapshot unavailable'))
        return lines
    summary = _collect_db_enrichment_summary(lab_root)
    if not summary.get('ok'):
        lines.append(' - unavailable ({0})'.format(summary.get('error') or 'db enrichment summary unavailable'))
        return lines

    counts = snap.get('counts', {}) if isinstance(snap.get('counts', {}), dict) else {}
    patient_rows = _safe_int(counts.get('patient'), 0)
    patient_count = _safe_int(
        snap.get('patient_count_effective'),
        _safe_int(snap.get('patient_latest_identity_count'), patient_rows))
    qa_pass = _safe_int(
        snap.get('qa_pass_count_effective'),
        _safe_int(snap.get('qa_pass_count'), 0))
    qa_reject = _safe_int(
        snap.get('qa_reject_count_effective'),
        _safe_int(snap.get('qa_reject_count'), 0))
    projection_success = _safe_int(
        snap.get('projection_success_count_effective'),
        _safe_int(snap.get('projection_success_count'), 0))
    projection_reject = _safe_int(
        snap.get('projection_reject_count_effective'),
        _safe_int(snap.get('projection_reject_count'), 0))
    replay_pending = _safe_int(snap.get('replay_pending_count'), 0)

    ingest_counts = summary.get('ingest_source_type_counts', {}) if isinstance(summary.get('ingest_source_type_counts', {}), dict) else {}
    canonical_counts = summary.get('canonical_type_counts', {}) if isinstance(summary.get('canonical_type_counts', {}), dict) else {}
    join = summary.get('csv_docx_join', {}) if isinstance(summary.get('csv_docx_join', {}), dict) else {}
    csv_rows = _safe_int(join.get('csv_candidate_count'), 0)
    csv_unique_keys = _safe_int(join.get('csv_join_key_count'), 0)
    docx_rows = _safe_int(join.get('docx_candidate_count'), 0)
    docx_unique_keys = _safe_int(join.get('docx_join_key_count'), 0)
    overlap_keys = _safe_int(join.get('overlap_join_key_count'), _safe_int(join.get('matched_count'), 0))
    csv_only_keys = _safe_int(join.get('csv_only_join_key_count'), _safe_int(join.get('csv_only_count'), 0))
    docx_only_keys = _safe_int(join.get('docx_only_join_key_count'), _safe_int(join.get('docx_only_count'), 0))
    historical_duplicate_keys = _safe_int(join.get('historical_duplicate_key_count'), 0)
    csv_missing_join_key_rows = _safe_int(join.get('csv_no_join_key_count'), 0)
    duplicate_breakdown = join.get('historical_duplicate_breakdown', {}) if isinstance(join.get('historical_duplicate_breakdown', {}), dict) else {}
    scope_note = str(join.get('scope_note', '') or '').strip()
    if not scope_note:
        scope_note = 'overlap/csv_only/docx_only use unique cumulative join keys; historical_duplicate_keys reflects repeated keys across stored DB history and is not unresolved ambiguity by itself'

    lines.append(' - intake_sources={0}'.format(
        _format_count_map(ingest_counts, preferred_keys=['csv', 'docx', 'dat', '837', 'receipt'])
    ))
    if not compact:
        lines.append(' - canonical_types={0}'.format(
            _format_count_map(
                canonical_counts,
                preferred_keys=['patient_csv_row', 'docx_schedule', 'dat_record', 'x12_member', 'remittance_row']
            )
        ))
    lines.append(
        ' - upstream_csv_docx_join=csv_rows={0}, csv_keys={1}, docx_rows={2}, docx_keys={3}, overlap_keys={4}, csv_only_keys={5}, docx_only_keys={6}, historical_duplicate_keys={7}, csv_missing_join_key={8}'.format(
            csv_rows,
            csv_unique_keys,
            docx_rows,
            docx_unique_keys,
            overlap_keys,
            csv_only_keys,
            docx_only_keys,
            historical_duplicate_keys,
            csv_missing_join_key_rows,
        )
    )
    lines.append(
        ' - upstream_csv_docx_unique_key_outcomes=overlap_keys={0}, csv_only_keys={1}, docx_only_keys={2}'.format(
            overlap_keys,
            csv_only_keys,
            docx_only_keys,
        )
    )
    lines.append(
        ' - upstream_csv_docx_volume=csv_rows={0}, csv_unique_keys={1}, docx_rows={2}, docx_unique_keys={3}, csv_missing_join_key_rows={4}'.format(
            csv_rows,
            csv_unique_keys,
            docx_rows,
            docx_unique_keys,
            csv_missing_join_key_rows,
        )
    )
    lines.append(
        ' - upstream_csv_docx_historical_duplicate_pressure=duplicate_keys={0}, both_sources={1}, csv_only={2}, docx_only={3}'.format(
            historical_duplicate_keys,
            _safe_int(duplicate_breakdown.get('both_sources'), 0),
            _safe_int(duplicate_breakdown.get('csv_only'), 0),
            _safe_int(duplicate_breakdown.get('docx_only'), 0),
        )
    )
    lines.append(' - join_scope_note={0}'.format(scope_note))
    if compact:
        lines.append(' - join_scope_note_phase_d=check latest Phase D run telemetry for unresolved ambiguity; this cumulative block reports historical duplicate pressure separately')
    else:
        lines.append(' - join_scope_note_phase_d=latest Phase D run telemetry, not cumulative DB history, is the source of truth for unresolved ambiguity')
    if not compact and sum(_safe_int(v, 0) for v in duplicate_breakdown.values()) > 0:
        lines.append(
            ' - historical_duplicate_breakdown=both_sources={0}, csv_only={1}, docx_only={2}'.format(
                _safe_int(duplicate_breakdown.get('both_sources'), 0),
                _safe_int(duplicate_breakdown.get('csv_only'), 0),
                _safe_int(duplicate_breakdown.get('docx_only'), 0),
            )
        )
        duplicate_examples = join.get('historical_duplicate_examples', []) if isinstance(join.get('historical_duplicate_examples', []), list) else []
        formatted_examples = []
        for item in duplicate_examples[:5]:
            if not isinstance(item, dict):
                continue
            formatted_examples.append(
                '{0}(csv={1},docx={2})'.format(
                    str(item.get('join_key', '') or '').strip() or '-',
                    _safe_int(item.get('csv_count'), 0),
                    _safe_int(item.get('docx_count'), 0),
                )
            )
        if formatted_examples:
            lines.append(' - historical_duplicate_examples={0}'.format(' | '.join(formatted_examples)))
    reason_counts = join.get('csv_no_join_key_reason_counts', {}) if isinstance(join.get('csv_no_join_key_reason_counts', {}), dict) else {}
    if not compact and sum(_safe_int(v, 0) for v in reason_counts.values()) > 0:
        lines.append(' - csv_missing_join_key_reasons={0}'.format(
            _format_count_map(reason_counts, preferred_keys=['missing_patient_id', 'missing_surgery_date', 'other'])
        ))
    lines.append(
        ' - relational_depth=patient_count={0}, coverage_count={1}, encounter_count={2}, claim_count={3}, claim_line_count={4}'.format(
            patient_count,
            _safe_int(counts.get('coverage'), 0),
            _safe_int(counts.get('encounter'), 0),
            _safe_int(counts.get('claim'), 0),
            _safe_int(counts.get('claim_line'), 0),
        )
    )
    lines.append(
        ' - forward_motion=qa_pass={0}, qa_reject={1}, projection_success={2}, projection_reject={3}, replay_pending={4}'.format(
            qa_pass,
            qa_reject,
            projection_success,
            projection_reject,
            replay_pending,
        )
    )

    interpretation = []
    if sum(_safe_int(v, 0) for v in ingest_counts.values()) > 0 or sum(_safe_int(v, 0) for v in canonical_counts.values()) > 0:
        interpretation.append('upstream_evidence_present')
    if (_safe_int(join.get('csv_candidate_count'), 0) > 0
            or _safe_int(join.get('docx_candidate_count'), 0) > 0
            or _safe_int(join.get('overlap_join_key_count'), _safe_int(join.get('matched_count'), 0)) > 0):
        interpretation.append('upstream_enrichment_accumulating')
    if (_safe_int(counts.get('coverage'), 0) <= 0
            and _safe_int(counts.get('encounter'), 0) <= 0
            and _safe_int(counts.get('claim'), 0) <= 0
            and _safe_int(counts.get('claim_line'), 0) <= 0):
        interpretation.append('relational_chain_still_shallow')
    else:
        interpretation.append('relational_chain_materialized')
    if qa_reject > 0 or replay_pending > 0:
        interpretation.append('quality_backlog_present')
    else:
        interpretation.append('quality_backlog_clear')
    lines.append(' - interpretation={0}'.format('; '.join(interpretation) if interpretation else 'unknown'))
    return lines


def _score_patient_chain_row(row):
    return _patient_tools.score_patient_chain_row(row, safe_int_fn=_safe_int)


def _collect_patient_chain_rows(
        conn,
        limit=200,
        projection_version_scope=None,
        collapse_latest_by_identity=True):
    return _patient_tools.collect_patient_chain_rows(
        conn,
        limit=limit,
        safe_int_fn=_safe_int,
        score_patient_chain_row_fn=_score_patient_chain_row,
        projection_version_scope=projection_version_scope,
        collapse_latest_by_identity=collapse_latest_by_identity,
    )


def _patient_display_id(row):
    return _patient_tools.patient_display_id(row)


def _build_guided_patient_options(rows, diagnostics_state):
    return _patient_tools.build_guided_patient_options(
        rows,
        diagnostics_state,
        safe_int_fn=_safe_int,
        patient_display_id_fn=_patient_display_id,
    )


def _find_patient_option_by_reference(rows, patient_ref):
    return _patient_tools.find_patient_option_by_reference(
        rows,
        patient_ref,
        safe_int_fn=_safe_int,
    )


def _build_guided_options_runbook_lines(snapshot, options):
    return _patient_tools.build_guided_options_runbook_lines(snapshot, options)


def _build_patient_reference_options(rows, limit=25):
    return _patient_tools.build_patient_reference_options(
        rows,
        limit=limit,
        safe_int_fn=_safe_int,
        patient_display_id_fn=_patient_display_id,
    )


def _build_no_patient_guidance_payload(snapshot, diagnostics_state, lab_root, db_path):
    """Build actionable runbook payload when guided patient rows are unavailable."""
    snap = snapshot if isinstance(snapshot, dict) else {}
    state = diagnostics_state if isinstance(diagnostics_state, dict) else {}
    counts = snap.get('counts', {}) if isinstance(snap.get('counts', {}), dict) else {}
    patient_rows = _safe_int(counts.get('patient'), 0)
    patient_count = _safe_int(
        snap.get('patient_count_effective'),
        _safe_int(snap.get('patient_latest_identity_count'), patient_rows))
    qa_reject_count = _safe_int(
        snap.get('qa_reject_count_effective'),
        _safe_int(snap.get('qa_reject_count'), 0))
    replay_pending_count = _safe_int(snap.get('replay_pending_count'), 0)
    projection_success_count = _safe_int(
        snap.get('projection_success_count_effective'),
        _safe_int(snap.get('projection_success_count'), 0))
    qa_scope = str(snap.get('qa_scope_version', '') or '').strip()
    projection_scope = str(snap.get('projection_scope_version', '') or '').strip()
    active_run_id = str(state.get('active_run_id', '') or '').strip()
    last_run_id = str(state.get('last_shadow_pipeline_run_id', '') or '').strip()
    pipeline_state = str(state.get('pipeline_state', '') or '').strip().lower() or 'unknown'

    runbook_lines = [
        'Guided Patient Completeness Runbook:',
        ' - condition=no_patient_rows',
        ' - data_plane_status={0}'.format(snap.get('status', 'unknown')),
        ' - patient_count={0}{1}'.format(
            patient_count,
            ' (raw_patient_rows={0})'.format(patient_rows) if patient_rows != patient_count else ''),
        ' - qa_reject_count={0}'.format(qa_reject_count),
        ' - replay_pending_count={0}'.format(replay_pending_count),
        ' - projection_success_count={0}'.format(projection_success_count),
        ' - quality_scope=qa_version:{0}, projection_version:{1}'.format(
            qa_scope or '-',
            projection_scope or '-'),
        ' - pipeline_state={0}'.format(pipeline_state),
        ' - active_run_id={0}'.format(active_run_id or '-'),
        ' - last_shadow_pipeline_run_id={0}'.format(last_run_id or '-'),
    ]

    actions = []
    actions.append(
        'No patient rows are currently materialized in the local XP DB. This is a data-state condition, not a launcher failure.'
    )
    if qa_reject_count > 0 or replay_pending_count > 0:
        actions.append(
            'Review QA rejects/replay queue first (qa_reject_count={0}, replay_pending_count={1}) and clear pending replay items.'.format(
                qa_reject_count, replay_pending_count
            )
        )
    if projection_success_count <= 0:
        actions.append(
            'Inspect latest Phase E projection/parity outputs for zero patient projections before rerunning guided completeness.'
        )
    if active_run_id:
        actions.append(
            'Pipeline is active (run_id={0}); wait for completion, then reopen Guided Patient Completeness Runbook.'.format(
                active_run_id
            )
        )
    elif last_run_id:
        actions.append(
            'Inspect run-scoped evidence for run_id={0} via Cloud Phase Artifact Tools (A/B), then re-run full shadow pipeline (A->F) if still empty.'.format(
                last_run_id
            )
        )
    else:
        actions.append(
            'No prior pipeline run ID is recorded; trigger full shadow pipeline (A->F), then reopen Guided Patient Completeness Runbook.'
        )
    actions.append(
        'Re-open Cloud Readiness -> 2) Investigate patient / data -> 1) Guided completeness after data-state changes.'
    )
    action_lines = ['What To Do Now:']
    step = 1
    for item in actions:
        action_lines.append(' {0}) {1}'.format(step, item))
        step += 1
    runbook_lines.extend(action_lines)

    return {
        'condition': 'no_patient_rows',
        'lab_root': lab_root,
        'db_path': db_path,
        'snapshot': snap,
        'diagnostics_state': state,
        'options': [],
        'runbook_lines': runbook_lines,
        'actions': actions,
    }


def get_guided_patient_completeness_options(repo_root):
    """Return enriched letter options for patient completeness runbook flow."""
    lab_root = resolve_lab_root(repo_root)
    reports_err = _reports_dir_access_error(lab_root)
    if reports_err:
        return (False, reports_err, None)
    snapshot = _collect_data_plane_snapshot(lab_root)
    if not snapshot.get('ok'):
        return (False, snapshot.get('error') or 'Unable to read lab DB.', None)
    diagnostics_state = _load_json_dict(os.path.join(lab_root, 'diagnostics_state.json'))
    projection_version_scope = str(diagnostics_state.get('last_projection_version', '') or '').strip()
    db_path = snapshot.get('db_path')
    rows = []
    conn = None
    try:
        conn = sqlite3.connect(db_path)
        conn.execute("PRAGMA foreign_keys = ON")
        rows = _collect_patient_chain_rows(
            conn,
            limit=250,
            projection_version_scope=projection_version_scope,
        )
    except Exception as e:
        return (False, 'DB query failed: {0}'.format(e), None)
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass
    if not rows:
        guidance = _build_no_patient_guidance_payload(snapshot, diagnostics_state, lab_root, db_path)
        return (
            False,
            'Guided patient completeness unavailable due to current data-state (0 patient rows). '
            'Launcher is healthy; review runbook actions below.',
            guidance,
        )
    options = _build_guided_patient_options(rows, diagnostics_state)
    runbook_lines = _build_guided_options_runbook_lines(snapshot, options)
    return (True, 'Guided patient completeness options ready.', {
        'lab_root': lab_root,
        'db_path': db_path,
        'snapshot': snapshot,
        'options': options,
        'runbook_lines': runbook_lines,
    })




def get_patient_flow_reference_options(repo_root, limit=25):
    """Return auto-populated patient reference options for flow runbook selection."""
    lab_root = resolve_lab_root(repo_root)
    reports_err = _reports_dir_access_error(lab_root)
    if reports_err:
        return (False, reports_err, None)
    snapshot = _collect_data_plane_snapshot(lab_root)
    if not snapshot.get('ok'):
        return (False, snapshot.get('error') or 'Unable to read lab DB.', None)
    diagnostics_state = _load_json_dict(os.path.join(lab_root, 'diagnostics_state.json'))
    projection_version_scope = str(diagnostics_state.get('last_projection_version', '') or '').strip()
    db_path = snapshot.get('db_path')
    rows = []
    conn = None
    try:
        conn = sqlite3.connect(db_path)
        conn.execute("PRAGMA foreign_keys = ON")
        rows = _collect_patient_chain_rows(
            conn,
            limit=max(25, _safe_int(limit, 25)),
            projection_version_scope=projection_version_scope,
        )
    except Exception as e:
        return (False, 'DB query failed: {0}'.format(e), None)
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass

    if not rows:
        guidance = _build_no_patient_guidance_payload(snapshot, diagnostics_state, lab_root, db_path)
        return (
            False,
            'Patient flow options unavailable due to current data-state (0 patient rows).',
            guidance,
        )

    options = _build_patient_reference_options(rows, limit=_safe_int(limit, 25))
    return (True, 'Patient flow reference options ready.', {
        'lab_root': lab_root,
        'db_path': db_path,
        'snapshot': snapshot,
        'options': options,
    })


def _query_rows_for_ids(conn, sql_prefix, ids, sql_suffix='', max_rows=120):
    return _patient_tools.query_rows_for_ids(
        conn,
        sql_prefix,
        ids,
        sql_suffix=sql_suffix,
        max_rows=max_rows,
        safe_int_fn=_safe_int,
    )


def _build_patient_trace_payload(conn, reports_dir, selected):
    return _patient_tools.build_patient_trace_payload(
        conn,
        reports_dir,
        selected,
        find_latest_by_prefix_fn=_find_latest_by_prefix,
        safe_int_fn=_safe_int,
        safe_json_loads_fn=_safe_json_loads,
        query_rows_for_ids_fn=_query_rows_for_ids,
    )


def _build_patient_trace_decision(selected, trace, diagnostics_state):
    return _patient_tools.build_patient_trace_decision(
        selected,
        trace,
        diagnostics_state,
        safe_int_fn=_safe_int,
    )


def _write_patient_trace_runbook_report(reports_dir, payload):
    return _patient_tools.write_patient_trace_runbook_report(
        reports_dir,
        payload,
        safe_int_fn=_safe_int,
        slug_token_fn=_slug_token,
    )


def open_guided_patient_completeness_runbook(repo_root, option_code):
    """Generate one patient completeness runbook report from lettered enriched options."""
    code = str(option_code or '').strip().upper()
    if not code:
        return (False, 'Option code is required.', None)
    ok, msg, data = get_guided_patient_completeness_options(repo_root)
    if not ok:
        return (False, msg, None)
    options = data.get('options', []) if isinstance(data, dict) else []
    selected = None
    for item in options:
        if str(item.get('code', '')).upper() == code:
            selected = item
            break
    if not isinstance(selected, dict):
        valid = ','.join([str(x.get('code', '')).upper() for x in options]) or '(none)'
        return (False, 'Invalid option code: {0}. valid={1}'.format(code, valid), None)

    lab_root = data.get('lab_root') if isinstance(data, dict) else resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    db_path = data.get('db_path') if isinstance(data, dict) else os.path.join(lab_root, 'unified_model_xp.db')
    diagnostics_state = _load_json_dict(os.path.join(lab_root, 'diagnostics_state.json'))
    snapshot = data.get('snapshot', {}) if isinstance(data, dict) else {}

    conn = None
    try:
        conn = sqlite3.connect(db_path)
        conn.execute("PRAGMA foreign_keys = ON")
        trace = _build_patient_trace_payload(conn, reports_dir, selected)
    except Exception as e:
        return (False, 'Unable to build patient trace: {0}'.format(e), None)
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass

    decision = _build_patient_trace_decision(selected, trace, diagnostics_state)
    payload = {
        'generated_at_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        'selected': selected,
        'snapshot': snapshot,
        'artifact_ids': trace.get('artifact_ids', []),
        'artifact_pointers': trace.get('artifact_pointers', {}),
        'rows': trace.get('rows', {}),
        'decision': decision,
    }
    try:
        path_txt, _ = _write_patient_trace_runbook_report(reports_dir, payload)
    except Exception as e:
        return (False, 'Failed to write patient runbook report: {0}'.format(e), None)
    msg_out = 'Patient completeness runbook generated. verdict={0} patient={1}'.format(
        decision.get('verdict', 'UNKNOWN'),
        selected.get('display_id', selected.get('patient_key', '')),
    )
    return (True, msg_out, path_txt)


def open_patient_flow_runbook(repo_root, patient_ref):
    """Generate a patient flow runbook for an explicit patient reference."""
    ref = str(patient_ref or '').strip()
    if not ref:
        return (False, 'Patient reference is required (patient_id/external_patient_id/patient_key).', None)
    ok, msg, data = get_patient_flow_reference_options(repo_root, limit=250)
    if not ok or not isinstance(data, dict):
        return (False, msg or 'Patient flow unavailable.', None)

    options = data.get('options', []) if isinstance(data.get('options', []), list) else []
    selected = _find_patient_option_by_reference(options, ref)
    if not isinstance(selected, dict):
        return (
            False,
            'Patient reference not found in available patient options: {0}. '
            'Open patient flow options (menu option 5) to pick an auto-populated reference.'.format(ref),
            None,
        )

    lab_root = data.get('lab_root') if isinstance(data, dict) else resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    db_path = data.get('db_path') if isinstance(data, dict) else os.path.join(lab_root, 'unified_model_xp.db')
    diagnostics_state = _load_json_dict(os.path.join(lab_root, 'diagnostics_state.json'))
    snapshot = data.get('snapshot', {}) if isinstance(data, dict) else {}

    conn = None
    try:
        conn = sqlite3.connect(db_path)
        conn.execute("PRAGMA foreign_keys = ON")
        trace = _build_patient_trace_payload(conn, reports_dir, selected)
    except Exception as e:
        return (False, 'Unable to build patient flow trace: {0}'.format(e), None)
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass

    decision = _build_patient_trace_decision(selected, trace, diagnostics_state)
    payload = {
        'generated_at_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        'selected': selected,
        'snapshot': snapshot,
        'artifact_ids': trace.get('artifact_ids', []),
        'artifact_pointers': trace.get('artifact_pointers', {}),
        'rows': trace.get('rows', {}),
        'decision': decision,
    }
    try:
        path_txt, _ = _write_patient_trace_runbook_report(reports_dir, payload)
    except Exception as e:
        return (False, 'Failed to write patient flow runbook report: {0}'.format(e), None)
    msg_out = 'Patient flow runbook generated. verdict={0} patient={1}'.format(
        decision.get('verdict', 'UNKNOWN'),
        selected.get('display_id', selected.get('patient_key', '')),
    )
    return (True, msg_out, path_txt)


def _normalize_data_plane_report_type(report_type):
    """Normalize report type aliases for data-plane audit reports."""
    key = str(report_type or 'overview').strip().lower()
    aliases = {
        'overview': 'overview',
        'summary': 'overview',
        'recent': 'recent',
        'recent_patients': 'recent',
        'high_risk': 'high_risk',
        'high-risk': 'high_risk',
        'risky': 'high_risk',
        'risk': 'high_risk',
    }
    return aliases.get(key, 'overview')


def _summarize_patient_chain_rows(rows):
    """Return aggregate counts for a list of scored patient-chain rows."""
    items = rows if isinstance(rows, list) else []
    out = {
        'rows': len(items),
        'risk_high': 0,
        'risk_medium': 0,
        'risk_low': 0,
        'missing_any': 0,
        'projection_reject_any': 0,
        'with_coverage': 0,
        'with_encounter': 0,
        'with_claim': 0,
        'with_claim_line': 0,
    }
    for row in items:
        risk = str(row.get('risk_label', '') or '').strip().upper()
        if risk == 'HIGH':
            out['risk_high'] += 1
        elif risk == 'MEDIUM':
            out['risk_medium'] += 1
        else:
            out['risk_low'] += 1
        if _safe_int(row.get('missing_count'), 0) > 0:
            out['missing_any'] += 1
        if _safe_int(row.get('projection_reject_count'), 0) > 0:
            out['projection_reject_any'] += 1
        if _safe_int(row.get('coverage_count'), 0) > 0:
            out['with_coverage'] += 1
        if _safe_int(row.get('encounter_count'), 0) > 0:
            out['with_encounter'] += 1
        if _safe_int(row.get('claim_count'), 0) > 0:
            out['with_claim'] += 1
        if _safe_int(row.get('claim_line_count'), 0) > 0:
            out['with_claim_line'] += 1
    return out


def _write_data_plane_audit_report(reports_dir, payload, report_type):
    """Write data-plane audit report text/json and latest aliases."""
    report_key = _normalize_data_plane_report_type(report_type)
    stamp = time.strftime('%Y%m%d-%H%M%S', time.gmtime())
    base = 'db_data_audit_{0}_{1}'.format(report_key, stamp)
    txt_path = os.path.join(reports_dir, base + '.txt')
    json_path = os.path.join(reports_dir, base + '.json')
    latest_txt = os.path.join(reports_dir, 'db_data_audit_{0}_latest.txt'.format(report_key))
    latest_json = os.path.join(reports_dir, 'db_data_audit_{0}_latest.json'.format(report_key))

    snap = payload.get('snapshot', {}) if isinstance(payload.get('snapshot', {}), dict) else {}
    counts = snap.get('counts', {}) if isinstance(snap.get('counts', {}), dict) else {}
    rows = payload.get('sample_rows', []) if isinstance(payload.get('sample_rows', []), list) else []
    summary_all = payload.get('summary_all_rows', {}) if isinstance(payload.get('summary_all_rows', {}), dict) else {}
    summary_sample = payload.get('summary_sample_rows', {}) if isinstance(payload.get('summary_sample_rows', {}), dict) else {}

    db_path = str(payload.get('db_path', '') or '')
    db_size = ''
    db_mtime = ''
    try:
        if db_path and os.path.exists(db_path):
            db_size = str(os.path.getsize(db_path))
            db_mtime = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(os.path.getmtime(db_path)))
    except Exception:
        pass

    lines = []
    lines.append('DB Data Audit Report')
    lines.append('generated_at_utc={0}'.format(time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())))
    lines.append('report_type={0}'.format(report_key))
    lines.append('selection_rule={0}'.format(payload.get('selection_rule', 'recent_created_at')))
    lines.append('lab_root={0}'.format(payload.get('lab_root', '(unset)')))
    lines.append('db_path={0}'.format(db_path or '(unset)'))
    lines.append('db_file_size_bytes={0}'.format(db_size or '-'))
    lines.append('db_last_modified_utc={0}'.format(db_mtime or '-'))
    lines.append('')
    lines.append('Data Plane Summary:')
    if snap.get('ok'):
        patient_rows = _safe_int(counts.get('patient'), 0)
        patient_count = _safe_int(
            snap.get('patient_count_effective'),
            _safe_int(snap.get('patient_latest_identity_count'), patient_rows))
        qa_reject_raw = _safe_int(snap.get('qa_reject_count'), 0)
        qa_reject_count = _safe_int(snap.get('qa_reject_count_effective'), qa_reject_raw)
        projection_success_raw = _safe_int(snap.get('projection_success_count'), 0)
        projection_success_count = _safe_int(
            snap.get('projection_success_count_effective'),
            projection_success_raw)
        projection_reject_raw = _safe_int(snap.get('projection_reject_count'), 0)
        projection_reject_count = _safe_int(
            snap.get('projection_reject_count_effective'),
            projection_reject_raw)
        qa_scope = str(snap.get('qa_scope_version', '') or '').strip()
        projection_scope = str(snap.get('projection_scope_version', '') or '').strip()
        lines.append(' - db_status={0}'.format(snap.get('status', 'unknown')))
        if patient_rows != patient_count:
            lines.append(
                ' - patient_count={0} (latest identity rows; raw_patient_rows={1})'.format(
                    patient_count,
                    patient_rows))
        else:
            lines.append(' - patient_count={0}'.format(patient_count))
        if qa_scope:
            lines.append(
                ' - qa_reject_count={0} (qa_version={1}, raw={2})'.format(
                    qa_reject_count,
                    qa_scope,
                    qa_reject_raw))
        else:
            lines.append(' - qa_reject_count={0}'.format(qa_reject_count))
        lines.append(
            ' - replay_pending_count={0} (active backlog only)'.format(
                _safe_int(snap.get('replay_pending_count'), 0)
            )
        )
        if projection_scope:
            lines.append(
                ' - projection_success_count={0} (projection_version={1}, raw={2})'.format(
                    projection_success_count,
                    projection_scope,
                    projection_success_raw))
            lines.append(
                ' - projection_reject_count={0} (projection_version={1}, raw={2})'.format(
                    projection_reject_count,
                    projection_scope,
                    projection_reject_raw))
        else:
            lines.append(' - projection_success_count={0}'.format(projection_success_count))
            lines.append(' - projection_reject_count={0}'.format(projection_reject_count))
        lines.append(' - orphan_claim_lines={0}'.format(_safe_int(snap.get('orphan_claim_lines'), 0)))
    else:
        lines.append(' - db_status=FAIL ({0})'.format(snap.get('error', 'unknown')))
    lines.append('')
    lines.extend(_build_db_enrichment_overview_lines(payload.get('lab_root'), snapshot=snap, compact=False))
    lines.append('')
    lines.append('Table row counts:')
    for key in (
            'patient',
            'coverage',
            'encounter',
            'claim',
            'claim_line',
            'extracted_canonical_record',
            'projection_result',
            'qa_result',
            'replay_queue',
            'ingest_artifact'):
        lines.append(' - {0}={1}'.format(key, _safe_int(counts.get(key), 0)))
    lines.append('')
    lines.append('Patient chain summary (scanned rows):')
    lines.append(' - scanned_rows={0}'.format(_safe_int(summary_all.get('rows'), 0)))
    lines.append(' - risk_high={0}, risk_medium={1}, risk_low={2}'.format(
        _safe_int(summary_all.get('risk_high'), 0),
        _safe_int(summary_all.get('risk_medium'), 0),
        _safe_int(summary_all.get('risk_low'), 0),
    ))
    lines.append(' - missing_any={0}, projection_reject_any={1}'.format(
        _safe_int(summary_all.get('missing_any'), 0),
        _safe_int(summary_all.get('projection_reject_any'), 0),
    ))
    lines.append(' - with_coverage={0}, with_encounter={1}, with_claim={2}, with_claim_line={3}'.format(
        _safe_int(summary_all.get('with_coverage'), 0),
        _safe_int(summary_all.get('with_encounter'), 0),
        _safe_int(summary_all.get('with_claim'), 0),
        _safe_int(summary_all.get('with_claim_line'), 0),
    ))
    lines.append('')
    lines.append('Patient sample summary (rendered rows):')
    lines.append(' - sample_rows={0}'.format(_safe_int(summary_sample.get('rows'), 0)))
    lines.append(' - risk_high={0}, risk_medium={1}, risk_low={2}'.format(
        _safe_int(summary_sample.get('risk_high'), 0),
        _safe_int(summary_sample.get('risk_medium'), 0),
        _safe_int(summary_sample.get('risk_low'), 0),
    ))
    lines.append(' - missing_any={0}, projection_reject_any={1}'.format(
        _safe_int(summary_sample.get('missing_any'), 0),
        _safe_int(summary_sample.get('projection_reject_any'), 0),
    ))
    lines.append('')
    lines.append('Patient sample rows:')
    lines.append('Columns: patient_ref | risk | missing | cov/enc/claim/line | proj_ok/rej | full_name | birth_date | created_at')
    lines.append('Note: created_at is DB row creation timestamp (not date of service).')
    if not rows:
        lines.append(' (no rows selected)')
    else:
        row_idx = 1
        for row in rows:
            display_id = _patient_display_id(row)
            patient_ref = str(row.get('external_patient_id') or row.get('patient_key') or row.get('patient_id') or '-')
            full_name = str(row.get('full_name', '') or '').strip() or '-'
            if len(full_name) > 36:
                full_name = full_name[:33] + '...'
            birth_date = str(row.get('birth_date', '') or '').strip() or '-'
            created_at = str(row.get('created_at', '') or '').strip() or '-'
            risk_label = str(row.get('risk_label', 'UNKNOWN') or 'UNKNOWN')
            missing_count = _safe_int(row.get('missing_count'), 0)
            line = (
                ' {0:>3}) {1} ({2}) | risk={3} | missing={4} | '
                'cov/enc/claim/line={5}/{6}/{7}/{8} | proj_ok/rej={9}/{10} | '
                'name={11} | dob={12} | created={13}'
            ).format(
                row_idx,
                patient_ref,
                display_id,
                risk_label,
                missing_count,
                _safe_int(row.get('coverage_count'), 0),
                _safe_int(row.get('encounter_count'), 0),
                _safe_int(row.get('claim_count'), 0),
                _safe_int(row.get('claim_line_count'), 0),
                _safe_int(row.get('projection_success_count'), 0),
                _safe_int(row.get('projection_reject_count'), 0),
                full_name,
                birth_date,
                created_at,
            )
            lines.append(line)
            reason = str(row.get('reason', '') or '').strip()
            if reason:
                lines.append('       why={0}'.format(reason))
            row_idx += 1

    with open(txt_path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines) + '\n')
    with open(json_path, 'w', encoding='utf-8') as f:
        json.dump(payload, f, indent=2, sort_keys=True)
    try:
        with open(latest_txt, 'w', encoding='utf-8') as f:
            f.write('\n'.join(lines) + '\n')
        with open(latest_json, 'w', encoding='utf-8') as f:
            json.dump(payload, f, indent=2, sort_keys=True)
    except Exception:
        pass
    return txt_path, json_path


def generate_data_plane_audit_report(repo_root, report_type='overview', limit=40):
    """
    Generate DB audit report with table counts and patient-level chain sample.
    report_type: overview | recent | high_risk.
    Returns (ok, msg, data) with txt/json report paths on success.
    """
    report_key = _normalize_data_plane_report_type(report_type)
    lab_root = resolve_lab_root(repo_root)
    reports_err = _reports_dir_access_error(lab_root)
    if reports_err:
        return (False, reports_err, None)

    reports_dir = os.path.join(lab_root, 'reports')
    if reports_dir and not os.path.exists(reports_dir):
        try:
            os.makedirs(reports_dir, exist_ok=True)
        except Exception as e:
            return (False, 'Unable to create reports directory: {0}'.format(e), None)

    snapshot = _collect_data_plane_snapshot(lab_root)
    if not snapshot.get('ok'):
        return (False, snapshot.get('error') or 'Unable to read lab DB.', {
            'snapshot': snapshot,
            'report_type': report_key,
        })

    base_limit = max(5, min(250, _safe_int(limit, 40)))
    scan_limit = max(base_limit, 250)
    db_path = snapshot.get('db_path')
    diagnostics_state = _load_json_dict(os.path.join(lab_root, 'diagnostics_state.json'))
    projection_version_scope = str(diagnostics_state.get('last_projection_version', '') or '').strip()
    rows = []
    conn = None
    try:
        conn = sqlite3.connect(db_path)
        conn.execute("PRAGMA foreign_keys = ON")
        rows = _collect_patient_chain_rows(
            conn,
            limit=scan_limit,
            projection_version_scope=projection_version_scope,
        )
    except Exception as e:
        return (False, 'DB query failed: {0}'.format(e), None)
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass

    reason_by_patient_id = {}
    try:
        option_rows = _build_guided_patient_options(rows, diagnostics_state)
        for opt in option_rows:
            pid = _safe_int(opt.get('patient_id'), 0)
            if pid > 0 and pid not in reason_by_patient_id:
                reason_by_patient_id[pid] = str(opt.get('reason', '') or '').strip()
    except Exception:
        reason_by_patient_id = {}

    for row in rows:
        pid = _safe_int(row.get('patient_id'), 0)
        row['reason'] = reason_by_patient_id.get(pid, '')

    selection_rule = 'recent_created_at'
    sample_rows = list(rows[:base_limit])
    if report_key == 'high_risk':
        sample_rows = [
            r for r in rows
            if (_safe_int(r.get('missing_count'), 0) > 0
                or _safe_int(r.get('projection_reject_count'), 0) > 0
                or _safe_int(r.get('risk_score'), 0) >= 35)
        ]
        sample_rows = sorted(
            sample_rows,
            key=lambda r: (
                _safe_int(r.get('risk_score'), 0),
                _safe_int(r.get('missing_count'), 0),
                _safe_int(r.get('projection_reject_count'), 0),
                _safe_int(r.get('patient_id'), 0),
            ),
            reverse=True,
        )
        if not sample_rows:
            sample_rows = list(rows[:base_limit])
            selection_rule = 'high_risk_first_fallback_recent'
        else:
            selection_rule = 'high_risk_first'
        sample_rows = sample_rows[:base_limit]
    elif report_key == 'overview':
        selection_rule = 'hybrid_top_risk_plus_recent'
        ranked_rows = sorted(
            rows,
            key=lambda r: (
                _safe_int(r.get('risk_score'), 0),
                _safe_int(r.get('missing_count'), 0),
                _safe_int(r.get('projection_reject_count'), 0),
                _safe_int(r.get('patient_id'), 0),
            ),
            reverse=True,
        )
        sample_rows = []
        seen_ids = set()
        risk_pick = min(max(6, int(base_limit / 2)), base_limit)
        for row in ranked_rows:
            pid = _safe_int(row.get('patient_id'), 0)
            if pid in seen_ids:
                continue
            sample_rows.append(row)
            if pid > 0:
                seen_ids.add(pid)
            if len(sample_rows) >= risk_pick:
                break
        for row in rows:
            if len(sample_rows) >= base_limit:
                break
            pid = _safe_int(row.get('patient_id'), 0)
            if pid > 0 and pid in seen_ids:
                continue
            sample_rows.append(row)
            if pid > 0:
                seen_ids.add(pid)

    payload = {
        'generated_at_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        'report_type': report_key,
        'selection_rule': selection_rule,
        'limit': base_limit,
        'lab_root': lab_root,
        'db_path': db_path,
        'snapshot': snapshot,
        'scanned_patient_row_count': len(rows),
        'sample_rows': sample_rows,
        'summary_all_rows': _summarize_patient_chain_rows(rows),
        'summary_sample_rows': _summarize_patient_chain_rows(sample_rows),
    }
    try:
        txt_path, json_path = _write_data_plane_audit_report(reports_dir, payload, report_key)
    except Exception as e:
        return (False, 'Failed to write DB data audit report: {0}'.format(e), None)
    msg_out = (
        'DB data audit report generated. type={0} sample_rows={1} scanned_rows={2}'.format(
            report_key,
            len(sample_rows),
            len(rows),
        )
    )
    return (True, msg_out, {
        'report_type': report_key,
        'txt_path': txt_path,
        'json_path': json_path,
        'sample_rows': len(sample_rows),
        'scanned_rows': len(rows),
        'selection_rule': selection_rule,
    })


def open_data_plane_audit_report(repo_root, report_type='overview', limit=40):
    """Generate and return path to a fresh DB data audit report text file."""
    ok, msg, data = generate_data_plane_audit_report(
        repo_root,
        report_type=report_type,
        limit=limit,
    )
    if not ok:
        return (False, msg, None)
    path = data.get('txt_path') if isinstance(data, dict) else None
    return (True, msg, path)


def open_latest_data_plane_audit_report(repo_root, report_type='overview'):
    """Open latest previously generated DB data audit report for a report type."""
    report_key = _normalize_data_plane_report_type(report_type)
    lab_root = resolve_lab_root(repo_root)
    reports_err = _reports_dir_access_error(lab_root)
    if reports_err:
        return (False, reports_err, None)
    reports_dir = os.path.join(lab_root, 'reports')
    path, msg = _find_latest_by_prefix(
        reports_dir,
        'db_data_audit_{0}_'.format(report_key),
        ('.txt',),
    )
    if path:
        return (True, '', path)
    if msg:
        return (False, msg, None)
    return (
        False,
        'No DB data audit report found for type={0}. Generate one from DB inspection tools first.'.format(report_key),
        None,
    )


def get_report_delivery_status_lines(lab_root):
    """
    Build compact delivery-status lines for operator triage.
    Includes sender readiness, queue snapshot, and last auto-report attempts.
    """
    lines = []
    stamp = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
    lines.append('Report Delivery Status')
    lines.append('generated_at_utc={0}'.format(stamp))
    lines.append('lab_root={0}'.format(lab_root or '(unset)'))
    lines.append('')

    delivery = _collect_delivery_diagnostics()
    lines.append('Sender readiness:')
    lines.append(' - token_available={0}'.format(delivery.get('token_available')))
    lines.append(' - recipient_count={0}'.format(delivery.get('recipient_count')))
    lines.append(' - queued_bundle_count={0}'.format(delivery.get('queued_bundle_count', '?')))
    if delivery.get('config_probe_error'):
        lines.append(' - config_probe_error={0}'.format(delivery.get('config_probe_error')))
    if delivery.get('token_probe_error'):
        lines.append(' - token_probe_error={0}'.format(delivery.get('token_probe_error')))
    if delivery.get('queue_probe_error'):
        lines.append(' - queue_probe_error={0}'.format(delivery.get('queue_probe_error')))
    lines.append('')

    lines.append('Queued bundles (up to 5 newest):')
    queued = delivery.get('queued_bundle_paths', [])
    if not isinstance(queued, list):
        queued = []
    try:
        queued = sorted(queued, key=lambda p: os.path.getmtime(p), reverse=True)
    except Exception:
        try:
            queued = sorted(queued, reverse=True)
        except Exception:
            pass
    if queued:
        for path in queued[:5]:
            try:
                age_sec = int(max(0, time.time() - os.path.getmtime(path)))
            except Exception:
                age_sec = None
            if age_sec is None:
                lines.append(' - {0}'.format(path))
            else:
                lines.append(' - {0} (age_sec={1})'.format(path, age_sec))
        if len(queued) > 5:
            lines.append(' - ... {0} more'.format(len(queued) - 5))
    else:
        lines.append(' - none')
    lines.append('')

    def _append_alert_state(label, path):
        state = _load_json_dict(path)
        lines.append('{0}:'.format(label))
        if not state:
            lines.append(' - none')
            return
        for key in (
            'last_attempt_ok',
            'last_error_code',
            'last_trigger',
            'last_issue_key',
            'last_sent_epoch',
            'last_attempt_epoch',
        ):
            if key in state:
                val = state.get(key)
                if key.endswith('_epoch'):
                    utc_val = _format_epoch_utc(val)
                    if utc_val:
                        lines.append(' - {0}={1} ({2})'.format(key, val, utc_val))
                        continue
                lines.append(' - {0}={1}'.format(key, val))
        diag = state.get('last_delivery_diag', {})
        if isinstance(diag, dict):
            if 'token_available' in diag:
                lines.append(' - delivery.token_available={0}'.format(diag.get('token_available')))
            if 'recipient_count' in diag:
                lines.append(' - delivery.recipient_count={0}'.format(diag.get('recipient_count')))
            if 'queued_bundle_count' in diag:
                lines.append(' - delivery.queued_bundle_count={0}'.format(diag.get('queued_bundle_count')))

    _append_alert_state('Cloud health auto-report', os.path.join(lab_root or '.', _HEALTH_ALERT_STATE_FILENAME))
    lines.append('')
    orch_path = os.path.join(lab_root or '.', _ORCHESTRATOR_ALERT_STATE_FILENAME)
    _append_alert_state('Orchestrator auto-report', orch_path)
    orch_state = _load_json_dict(orch_path)
    if isinstance(orch_state, dict) and orch_state.get('last_error_code'):
        lines.append(
            ' - interpret_last_attempt_ok=Failure-report email delivery only (orchestration already failed).'
        )
        lines.append(
            ' - last_bundle_send_ok={0}'.format(orch_state.get('last_bundle_send_ok', orch_state.get('last_attempt_ok')))
        )
    lines.append('')
    orch_ec = orch_state.get('last_error_code') if isinstance(orch_state, dict) else None
    lines.append('Remediation Playbook:')
    for line in _build_delivery_runbook_lines(delivery, orchestrator_error_code=orch_ec):
        lines.append(line)
    return lines


def _format_delivery_failure_message(delivery_diag):
    reason = 'email submission failed'
    recipient_count = delivery_diag.get('recipient_count')
    token_available = delivery_diag.get('token_available')
    if isinstance(recipient_count, int) and recipient_count <= 0:
        reason = 'no valid recipients configured'
    elif token_available is False:
        reason = 'gmail token unavailable'
    msg = 'Report queued or failed ({0}).'.format(reason)
    queued_count = delivery_diag.get('queued_bundle_count')
    if isinstance(queued_count, int):
        msg += ' queued_bundle_count={0}.'.format(queued_count)
    return msg


def _submit_bundle_with_delivery_diagnostics(zip_path, allow_interactive_reauth, progress_callback=None):
    """Send bundle and return (ok, msg, delivery_diag)."""
    if submit_support_bundle_email is None:
        return (False, 'Support bundle tools unavailable.', {})
    _emit_progress(progress_callback, 'checking delivery diagnostics')
    delivery_diag = _collect_delivery_diagnostics()
    delivery_diag['allow_interactive_reauth'] = bool(allow_interactive_reauth)
    try:
        _emit_progress(progress_callback, 'sending email to support')
        ok = submit_support_bundle_email(
            zip_path=zip_path,
            include_traceback=False,
            skip_interactive_reauth=not allow_interactive_reauth,
            progress_callback=progress_callback,
        )
    except Exception as e:
        ok = False
        delivery_diag['send_exception'] = str(e)
    if ok:
        # Empty msg: callers print kind-specific success (avoid duplicate generic line).
        return (True, '', delivery_diag)
    refreshed_diag = _collect_delivery_diagnostics()
    for key, value in refreshed_diag.items():
        delivery_diag[key] = value
    return (False, _format_delivery_failure_message(delivery_diag), delivery_diag)


def _maybe_send_orchestrator_failure_report(repo_root, lab_root, orchestration_result, trigger):
    """Best-effort auto-report for typed orchestrator failures (non-interactive)."""
    if collect_support_bundle is None or submit_support_bundle_email is None:
        return False
    if not isinstance(orchestration_result, dict):
        return False
    if orchestration_result.get('status') != shadow_orchestrator.STATUS_FAILED:
        return False

    error_code = str(orchestration_result.get('error_code', '') or '').strip() or 'UNKNOWN_ORCHESTRATOR_FAILURE'
    message = str(orchestration_result.get('message', '') or '').strip()
    payload = orchestration_result.get('payload', {}) if isinstance(orchestration_result.get('payload', {}), dict) else {}
    diagnostic_path = str(orchestration_result.get('diagnostic_path', '') or '').strip()
    report_path = str(orchestration_result.get('report_path', '') or '').strip()

    alert_root = lab_root if lab_root and str(lab_root).strip() else os.path.join(repo_root or os.getcwd(), 'lab')
    alert_state_path = os.path.join(alert_root, _ORCHESTRATOR_ALERT_STATE_FILENAME)
    issue_key = '{0}|{1}|{2}'.format(error_code, message, diagnostic_path)
    now_epoch = int(time.time())
    try:
        alert_state = _load_json_dict(alert_state_path)
        last_key = str(alert_state.get('last_issue_key', '') or '')
        last_epoch = int(alert_state.get('last_attempt_epoch', 0) or 0)
        if last_key == issue_key and (now_epoch - last_epoch) < _ORCHESTRATOR_ALERT_DEDUP_WINDOW_SEC:
            return False
    except Exception:
        pass

    extra_files = [('orchestrator_result.json', orchestration_result)]
    if payload:
        extra_files.append(('orchestrator_payload.json', payload))
    for candidate in (diagnostic_path, report_path):
        if candidate and os.path.isfile(candidate):
            extra_files.append((os.path.basename(candidate), candidate))
    for ctx_name in ('diagnostics_state.json', 'run_cursor.json', _HEALTH_TRACKER_FILENAME):
        ctx_path = os.path.join(alert_root, ctx_name)
        if os.path.isfile(ctx_path):
            extra_files.append((ctx_name, ctx_path))

    extra_meta = {
        'orchestrator_failure_auto_report': True,
        'orchestrator_trigger': trigger,
        'error_code': error_code,
        'error_summary': message or error_code,
        'repo_root': repo_root,
        'lab_root': alert_root,
    }
    try:
        zip_path = collect_support_bundle(
            include_traceback=False,
            extra_meta=extra_meta,
            extra_files=extra_files,
        )
        if not zip_path:
            return False
        ok, msg, delivery_diag = _submit_bundle_with_delivery_diagnostics(
            zip_path=zip_path,
            allow_interactive_reauth=False,
        )
        state_payload = {
            'last_issue_key': issue_key,
            'last_attempt_epoch': now_epoch,
            'last_attempt_ok': bool(ok),
            'last_bundle_send_ok': bool(ok),
            'last_error_code': error_code,
            'last_trigger': trigger,
        }
        if isinstance(delivery_diag, dict):
            state_payload['last_delivery_diag'] = delivery_diag
        _save_json_dict(alert_state_path, state_payload)
        if not ok:
            _log_health('WARNING', 'Auto-report failed for {0}: {1}'.format(error_code, msg))
        return ok
    except Exception as e:
        _log_health('ERROR', 'Auto-report exception for {0}: {1}'.format(error_code, e))
        return False


def _collect_health_diagnostics(lab_root, auto_resolve=True):
    """Collect cloud readiness diagnostics and small auto-resolve actions."""
    diagnostics = {
        'severity': 'ok',
        'issues': [],
        'auto_resolved': [],
    }

    def _add_issue(severity, code, message):
        diagnostics['issues'].append({
            'severity': severity,
            'code': code,
            'message': message,
        })
        if severity == 'fail':
            diagnostics['severity'] = 'fail'
        elif severity == 'warn' and diagnostics['severity'] == 'ok':
            diagnostics['severity'] = 'warn'

    if not lab_root:
        _add_issue('fail', 'LAB_ROOT_MISSING', 'Lab root is empty and cannot be evaluated.')
        return diagnostics
    if not os.path.isdir(lab_root):
        _add_issue('fail', 'LAB_ROOT_NOT_FOUND', _describe_lab_root_issue(lab_root))
        return diagnostics

    reports_dir = os.path.join(lab_root, 'reports')
    if not os.path.exists(reports_dir) and auto_resolve:
        try:
            os.makedirs(reports_dir)
            diagnostics['auto_resolved'].append('Created missing reports directory: {0}'.format(reports_dir))
        except (IOError, OSError) as e:
            _add_issue('warn', 'REPORTS_DIR_CREATE_FAILED', 'Failed to create reports directory: {0}'.format(e))

    lock_path = os.path.join(lab_root, 'shadow_pipeline.lock')
    if os.path.exists(lock_path):
        running = is_pipeline_running(lab_root)
        if not running and auto_resolve:
            try:
                os.remove(lock_path)
                diagnostics['auto_resolved'].append('Removed stale pipeline lock: {0}'.format(lock_path))
            except (IOError, OSError) as e:
                _add_issue('warn', 'STALE_LOCK_REMOVE_FAILED', 'Failed to remove stale lock: {0}'.format(e))

    state_path = os.path.join(lab_root, 'diagnostics_state.json')
    if not os.path.exists(state_path):
        if auto_resolve and _seed_diagnostics_state_if_missing(state_path):
            diagnostics['auto_resolved'].append('Seeded missing diagnostics_state.json: {0}'.format(state_path))
        else:
            _add_issue('warn', 'DIAGNOSTICS_STATE_MISSING', 'diagnostics_state.json was not found: {0}'.format(state_path))
            return diagnostics
    try:
        with open(state_path, 'r', encoding='utf-8') as f:
            state = json.load(f)
    except (IOError, OSError) as e:
        _add_issue('fail', 'DIAGNOSTICS_STATE_READ_FAILED', 'Could not read diagnostics_state.json: {0}'.format(e))
        return diagnostics
    except ValueError as e:
        _add_issue('fail', 'DIAGNOSTICS_STATE_INVALID_JSON', 'diagnostics_state.json has invalid JSON: {0}'.format(e))
        return diagnostics
    if not isinstance(state, dict):
        _add_issue('fail', 'DIAGNOSTICS_STATE_INVALID_TYPE', 'diagnostics_state.json root must be an object/dict.')
        return diagnostics

    phase_specs = [
        ('B', 'last_phase_b_run_id', 'last_discovery_ok', 'last_discovery_error_code'),
        ('C', 'last_phase_c_run_id', 'last_phase_c_ok', 'last_phase_c_error_code'),
        ('D', 'last_phase_d_run_id', 'last_phase_d_ok', 'last_phase_d_error_code'),
        ('E', 'last_phase_e_run_id', 'last_phase_e_ok', 'last_phase_e_error_code'),
        ('F', 'last_shadow_pipeline_run_id', 'last_shadow_pipeline_ok', 'last_shadow_pipeline_error_code'),
    ]
    lifecycle_state = str(state.get('pipeline_state', '') or '').strip().lower()
    active_phase = str(state.get('active_phase', '') or '').strip().upper()
    phase_run_ids = state.get('last_shadow_pipeline_phase_run_ids', {})
    if not isinstance(phase_run_ids, dict):
        phase_run_ids = {}
    for phase, run_key, ok_key, err_key in phase_specs:
        run_id = ''
        if phase in ('B', 'C', 'D', 'E'):
            run_id = str(phase_run_ids.get(phase, '') or '').strip()
        if not run_id:
            run_id = str(state.get(run_key, '') or '').strip()
        ok_value = state.get(ok_key, None)
        err_value = str(state.get(err_key, '') or '').strip()
        pending_write = (
            lifecycle_state in ('bootstrapping', 'running')
            and not run_id
            and ok_value is None
            and not err_value
            and bool(active_phase)
            and _PHASE_ORDER.get(phase, 99) >= _PHASE_ORDER.get(active_phase, 0)
        )
        if not run_id and ok_value is None:
            if pending_write:
                continue
            _add_issue('warn', 'PHASE_{0}_NOT_RUN'.format(phase),
                       'Phase {0} has no run id and no completion state.'.format(phase))
        elif ok_value is False and not err_value:
            _add_issue('warn', 'PHASE_{0}_ERROR_CODE_MISSING'.format(phase),
                       'Phase {0} failed with no error code.'.format(phase))

    skip_counts = state.get('last_phase_d_constraint_skip_counts')
    if isinstance(skip_counts, dict):
        inv = int(skip_counts.get('patient_invalid_external_id', 0) or 0)
        if inv > 0:
            passes = int(state.get('last_phase_d_pass_count', 0) or 0)
            denom = max(passes, 1)
            ratio = float(inv) / float(denom)
            tmpl = (
                'Phase D skipped {0} patient upsert(s) (external patient ID not ^[0-9]{{5}}$). '
                'Approx. ratio vs qa_pass_count={1}: {2:.4f}. See rule_decision_log and latest qa_canonical_summary.'
            )
            msg = tmpl.format(inv, denom, ratio)
            if ratio > _PHASE_D_INVALID_EXTERNAL_ID_RATIO_PASS_MAX:
                _add_issue('warn', 'PHASE_D_INVALID_EXTERNAL_ID_ELEVATED', msg)
            else:
                _add_issue('warn', 'PHASE_D_INVALID_EXTERNAL_ID_SKIPS_PRESENT', msg)
    return diagnostics


def _update_health_issue_tracker(lab_root, diagnostics, now_epoch=None):
    """Track intermittent/repeated issues across checks and identify escalation candidates."""
    now_epoch = int(now_epoch or time.time())
    # TODO(agent-followup): Consider a bounded "recent history" ring-buffer per issue code
    # so we can include cadence details (e.g., bursty vs steady failures) in support bundles
    # without growing this tracker file indefinitely over long-lived installations.
    tracker_path = os.path.join(lab_root or '.', _HEALTH_TRACKER_FILENAME)
    tracker = _load_json_dict(tracker_path)
    issues = tracker.get('issues', {}) if isinstance(tracker.get('issues', {}), dict) else {}
    current_keys = []
    escalated_codes = []

    for issue in diagnostics.get('issues', []):
        code = str(issue.get('code', '') or '').strip()
        severity = str(issue.get('severity', 'warn') or 'warn').strip().lower()
        if not code:
            continue
        current_keys.append(code)
        rec = issues.get(code, {}) if isinstance(issues.get(code, {}), dict) else {}
        count = int(rec.get('count', 0) or 0) + 1
        first_seen = int(rec.get('first_seen_epoch', now_epoch) or now_epoch)
        rec.update({
            'severity': severity,
            'count': count,
            'first_seen_epoch': first_seen,
            'last_seen_epoch': now_epoch,
            'message': issue.get('message', ''),
        })
        issues[code] = rec
        age = now_epoch - first_seen
        if severity == 'fail':
            escalated_codes.append(code)
        elif (severity == 'warn' and code not in _WARN_NON_ESCALATING_CODES
              and count >= _WARN_ESCALATION_MIN_COUNT and age >= _WARN_ESCALATION_MIN_AGE_SEC):
            escalated_codes.append(code)

    resolved = []
    for code in list(issues.keys()):
        if code not in current_keys:
            rec = issues.get(code, {})
            if isinstance(rec, dict):
                resolved.append(code)
            issues.pop(code, None)

    tracker['issues'] = issues
    tracker['last_updated_epoch'] = now_epoch
    _save_json_dict(tracker_path, tracker)
    return {
        'tracker_path': tracker_path,
        'escalated_codes': sorted(set(escalated_codes)),
        'resolved_codes': sorted(set(resolved)),
    }


def _maybe_send_cloud_health_failure_report(lab_root, diagnostics, tracker_info):
    """Send deduplicated support bundle for fail or sustained warn diagnostics."""
    if collect_support_bundle is None or submit_support_bundle_email is None:
        return False
    # TODO(agent-followup): If lab_root is empty/invalid, skip persistence and surface an
    # explicit diagnostic for this pathing condition instead of falling back to cwd ('.').
    # That hardening would prevent accidental artifact writes outside expected lab scope.
    escalated_codes = tracker_info.get('escalated_codes', []) if isinstance(tracker_info, dict) else []
    if not escalated_codes:
        return False
    issues = diagnostics.get('issues', []) if isinstance(diagnostics, dict) else []
    issue_key = '|'.join(['{0}:{1}'.format(i.get('code', ''), i.get('message', '')) for i in issues if i.get('code') in escalated_codes])
    if not issue_key:
        return False

    alert_state_path = os.path.join(lab_root or '.', _HEALTH_ALERT_STATE_FILENAME)
    now_epoch = int(time.time())
    alert_state = _load_json_dict(alert_state_path)
    last_key = alert_state.get('last_issue_key')
    last_epoch = int(alert_state.get('last_sent_epoch', 0) or 0)
    if last_key == issue_key and (now_epoch - last_epoch) < _ALERT_DEDUP_WINDOW_SEC:
        return False

    try:
        delivery_preflight = _collect_delivery_diagnostics()
        extra_files = [('cloud_health_diagnostics.json', diagnostics)]
        for name in (_HEALTH_TRACKER_FILENAME, 'diagnostics_state.json', 'run_cursor.json'):
            p = os.path.join(lab_root, name)
            if os.path.isfile(p):
                extra_files.append((name, p))
        zip_path = collect_support_bundle(
            include_traceback=False,
            extra_meta={
                'cloud_health_failure': True,
                'escalated_codes': escalated_codes,
                'lab_root': lab_root,
                'email_delivery_preflight': delivery_preflight,
            },
            extra_files=extra_files,
        )
        if not zip_path:
            return False
        ok, msg, _ = _submit_bundle_with_delivery_diagnostics(
            zip_path=zip_path,
            allow_interactive_reauth=False,
        )
        if not ok:
            _log_health('WARNING', 'Cloud health report submission fallback: {0}'.format(msg))
            return False
        _save_json_dict(alert_state_path, {'last_issue_key': issue_key, 'last_sent_epoch': now_epoch})
        return True
    except Exception as e:
        _log_health('ERROR', 'Cloud health report send failed: {0}'.format(e))
        return False


def resolve_lab_root(repo_root):
    """Resolve lab root: MEDICAFE_LAB_DIR > repo_root/lab."""
    env_lab = os.environ.get('MEDICAFE_LAB_DIR', '').strip()
    if env_lab:
        # Accept quoted values from .bat/.ini wrappers and expand shell vars.
        if len(env_lab) >= 2 and env_lab[0] == env_lab[-1] and env_lab[0] in ('"', "'"):
            env_lab = env_lab[1:-1]
        env_lab = os.path.expandvars(os.path.expanduser(env_lab))
        # Auto-heal malformed Windows bootstrap values like:
        #   "C: C:\\Python34\\Lib\\site-packages\\lab"
        # Keep only the real absolute drive path fragment.
        malformed_prefix = re.match(r'^([A-Za-z]:)\s+([A-Za-z]:[\\/].+)$', env_lab)
        if malformed_prefix:
            env_lab = malformed_prefix.group(2)

        # Auto-heal common XP launcher drift where MEDICAFE_LAB_DIR points to
        # site-packages (or site-packages\MediCafe) instead of a dedicated
        # lab root directory.
        env_lab_norm = os.path.normpath(env_lab)
        env_lab_tail, env_lab_parent_tail = _tail_parts_cross_platform(env_lab_norm)
        if env_lab_tail in ('site-packages', 'medicafe') and (
                env_lab_tail == 'site-packages' or env_lab_parent_tail == 'site-packages'):
            env_lab = os.path.join(env_lab_norm, 'lab')

        # If a Windows absolute drive path is provided, do not run posix abspath
        # on it (would incorrectly prefix cwd when tests run on non-Windows hosts).
        if re.match(r'^[A-Za-z]:[\\/]', env_lab):
            return os.path.normpath(env_lab)

        # Re-check after unquoting/expansion: empty value must fall back to repo_root/lab
        # (os.path.abspath('') resolves to cwd, which would mask bad config and corrupt placement)
        if env_lab and env_lab.strip():
            return os.path.abspath(env_lab)
    return os.path.join(repo_root, 'lab')


def _describe_lab_root_issue(lab_root):
    """Return a richer LAB_ROOT_NOT_FOUND explanation to speed operator triage."""
    parts = ['Lab root does not exist: {0}'.format(lab_root)]
    env_raw = os.environ.get('MEDICAFE_LAB_DIR', '')
    if env_raw:
        parts.append('MEDICAFE_LAB_DIR(raw)={0!r}'.format(env_raw))
    try:
        normalized = os.path.abspath(os.path.expandvars(os.path.expanduser(str(lab_root))))
        if normalized != lab_root:
            parts.append('normalized={0}'.format(normalized))
    except Exception:
        pass
    try:
        parent = os.path.dirname(lab_root)
        if parent:
            parts.append('parent_exists={0}'.format(os.path.isdir(parent)))
            parts.append('parent_writable={0}'.format(os.access(parent, os.W_OK)))
    except Exception:
        pass
    return ' | '.join(parts)


def _lab_has_core_artifacts(lab_root):
    """True if lab has db and cursor (bootstrap completed successfully)."""
    if not lab_root:
        return False
    db = os.path.join(lab_root, 'unified_model_xp.db')
    cursor = os.path.join(lab_root, 'run_cursor.json')
    return os.path.isfile(db) and os.path.isfile(cursor)


def _write_bootstrap_diag(repo_root, lab_root, reason, extra=None):
    """Best-effort write of opportunistic bootstrap diagnostics for in-situ triage."""
    try:
        fallback_lab = os.path.join(repo_root, 'lab')
        base_lab = lab_root if lab_root and str(lab_root).strip() else fallback_lab
        reports_dir = os.path.join(base_lab, 'reports')
        if not os.path.isdir(reports_dir):
            os.makedirs(reports_dir)
        stamp = time.strftime('%Y%m%dT%H%M%SZ', time.gmtime())
        unique = '{0}-{1}-{2}'.format(stamp, os.getpid(), int((time.time() % 1) * 1000))
        path = os.path.join(reports_dir, 'bootstrap_autofix_diag_{0}.json'.format(unique))
        payload = {
            'reason': reason,
            'lab_root': lab_root,
            'repo_root': repo_root,
            'medicafe_lab_dir_raw': os.environ.get('MEDICAFE_LAB_DIR', ''),
            'timestamp_utc': stamp,
        }
        if isinstance(extra, dict):
            payload.update(extra)
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return path
    except Exception:
        return None


def _probe_lab_root(path):
    """Collect lightweight filesystem/pipeline facts for bootstrap diagnostics."""
    probe = {
        'path': path,
        'exists': False,
        'is_dir': False,
        'parent': None,
        'parent_exists': False,
        'parent_writable': False,
        'has_core_artifacts': False,
        'pipeline_running': False,
    }
    try:
        if not path:
            return probe
        probe['exists'] = os.path.exists(path)
        probe['is_dir'] = os.path.isdir(path)
        parent = os.path.dirname(path)
        probe['parent'] = parent
        if parent:
            probe['parent_exists'] = os.path.isdir(parent)
            probe['parent_writable'] = os.access(parent, os.W_OK)
        if probe['is_dir']:
            probe['has_core_artifacts'] = _lab_has_core_artifacts(path)
        probe['pipeline_running'] = is_pipeline_running(path)
    except Exception:
        pass
    return probe


def _bootstrap_fail_message(code, message, diag_path=None):
    """Standardized bootstrap failure message with code and optional diag path."""
    msg = '{0}: {1}'.format(code, message)
    if diag_path:
        msg = '{0} (diagnostics: {1})'.format(msg, diag_path)
    return msg


def _bootstrap_creationflags():
    """Windows-only process-group mitigation for bootstrap child."""
    if os.name == 'nt':
        return getattr(subprocess, 'CREATE_NEW_PROCESS_GROUP', 0)
    return 0


def _orchestrator_ops():
    return {
        "resolve_lab_root": resolve_lab_root,
        "lab_has_core_artifacts": _lab_has_core_artifacts,
        "write_bootstrap_diag": _write_bootstrap_diag,
        "bootstrap_fail_message": _bootstrap_fail_message,
        "devnull": DEVNULL,
    }


def _coerce_orchestrator_result_to_legacy(result, default_running_message='Initialization in progress.'):
    status = (result or {}).get("status", "")
    code = (result or {}).get("error_code", "")
    msg = (result or {}).get("message", "") or ""
    payload = result or {}
    if status == shadow_orchestrator.STATUS_FAILED:
        return (False, msg or code or "Coordinator failed.", payload)
    if status == shadow_orchestrator.STATUS_ALREADY_RUNNING:
        return (True, default_running_message, payload)
    if code == shadow_orchestrator.ERROR_READY_NOOP:
        return (True, "", payload)
    return (True, msg, payload)


def _lab_root_has_recent_successful_shadow_pipeline_within_cooldown(lab_root, env):
    """True if diagnostics_state shows a completed successful pipeline within startup autorun cooldown."""
    state = _load_json_dict(os.path.join(lab_root or '', 'diagnostics_state.json'))
    if state.get('last_shadow_pipeline_ok') is not True:
        return False
    run_id = str(state.get('last_shadow_pipeline_run_id', '') or '').strip()
    if not run_id:
        return False
    cooldown = shadow_orchestrator._startup_autorun_cooldown_seconds(env or {})
    if cooldown <= 0:
        return False
    finished_at = state.get('last_shadow_pipeline_finished_at_utc', '')
    finished_epoch = shadow_orchestrator._parse_iso_utc_to_epoch(finished_at)
    if finished_epoch is None:
        return False
    age = int(time.time() - finished_epoch)
    if age < 0:
        return False
    return age < cooldown


def _lab_has_shadow_phase_f_artifacts_for_run_id(lab_root, run_id):
    """True if Phase F report and evidence index JSON exist for run_id under lab/reports."""
    rid = str(run_id or '').strip()
    if not rid:
        return False
    try:
        reports = os.path.join(lab_root or '', 'reports')
        report_json = os.path.join(reports, 'shadow_run_report_{0}.json'.format(rid))
        index_json = os.path.join(reports, 'shadow_evidence_index_{0}.json'.format(rid))
        return os.path.isfile(report_json) and os.path.isfile(index_json)
    except Exception:
        return False


def _should_skip_followup_full_pipeline_after_baseline(lab_root, env, allow_skip):
    """
    Cloud Readiness entry only: skip automatic MANUAL_FULL_PIPELINE after Phase A when
    diagnostics show a recent successful run and on-disk Phase F artifacts match that run_id.
    """
    if not allow_skip:
        return False
    if not _lab_root_has_recent_successful_shadow_pipeline_within_cooldown(lab_root, env):
        return False
    state = _load_json_dict(os.path.join(lab_root or '', 'diagnostics_state.json'))
    run_id = str(state.get('last_shadow_pipeline_run_id', '') or '').strip()
    return _lab_has_shadow_phase_f_artifacts_for_run_id(lab_root, run_id)


def ensure_lab_ready(repo_root, python_exe, env, env_flag_fn, skip_recent_success_autopipeline=False):
    """
    Gate before Cloud Readiness UI: ensure lab exists or run Phase A bootstrap.
    Returns (ok, message, None). Avoids concurrent Phase A (lock rejection) by
    checking pipeline running and respecting MEDICAFE_PHASE_A_AUTO_VALIDATE.
    When skip_recent_success_autopipeline is True (Cloud Readiness menu entry only), may skip
    automatic full pipeline after baseline if diagnostics and Phase F artifacts are coherent.
    """
    lab_root = resolve_lab_root(repo_root)
    if not lab_root or not str(lab_root).strip():
        diag_path = _write_bootstrap_diag(repo_root, lab_root, 'LAB_ROOT_EMPTY', {
            'flow_stage': 'resolve_lab_root',
        })
        return (False, _bootstrap_fail_message('LAB_ROOT_EMPTY', 'Lab root could not be resolved', diag_path), None)
    candidate_roots = [lab_root]
    default_lab = os.path.join(repo_root, 'lab')
    if default_lab not in candidate_roots:
        candidate_roots.append(default_lab)
    selected_root = lab_root
    selected_from_fallback = False
    for idx, candidate in enumerate(candidate_roots):
        probe = _probe_lab_root(candidate)
        if probe.get('is_dir') and probe.get('has_core_artifacts'):
            if candidate != lab_root:
                os.environ['MEDICAFE_LAB_DIR'] = candidate
            return (True, '', None)
        if probe.get('pipeline_running'):
            if candidate != lab_root:
                os.environ['MEDICAFE_LAB_DIR'] = candidate
            return (True, 'Initialization in progress.', None)
        if probe.get('is_dir'):
            selected_root = candidate
            selected_from_fallback = (idx > 0)
            break
    if selected_from_fallback and selected_root:
        os.environ['MEDICAFE_LAB_DIR'] = selected_root
    env_with_root = dict(env or {})
    env_with_root['MEDICAFE_LAB_DIR'] = selected_root
    baseline_needed = not _lab_has_core_artifacts(selected_root)
    try:
        baseline_result = shadow_orchestrator.start_or_attach_shadow_pipeline(
            action_id=shadow_orchestrator.ACTION_ENSURE_PHASE_A_ONLY,
            entrypoint=shadow_orchestrator.ENTRYPOINT_MENU,
            repo_root=repo_root,
            python_exe=python_exe,
            env=env_with_root,
            env_flag_fn=env_flag_fn,
            ops=_orchestrator_ops(),
        )
        ok, msg, payload = _coerce_orchestrator_result_to_legacy(baseline_result)
        if not ok:
            _maybe_send_orchestrator_failure_report(
                repo_root=repo_root,
                lab_root=selected_root,
                orchestration_result=baseline_result,
                trigger='ensure_lab_ready_baseline',
            )
            return (ok, msg, payload)

        # When baseline had to be reconciled, continue into full pipeline start-or-attach
        # so users are not stranded at B-F "not_run" after lab regeneration/degradation repair.
        if baseline_needed and _should_skip_followup_full_pipeline_after_baseline(
            selected_root, env_with_root, skip_recent_success_autopipeline
        ):
            if ok and (baseline_result.get('error_code') == shadow_orchestrator.ERROR_READY_NOOP or not msg):
                msg = ''
            return (ok, msg, payload)

        if baseline_needed:
            pipeline_result = shadow_orchestrator.start_or_attach_shadow_pipeline(
                action_id=shadow_orchestrator.ACTION_MANUAL_FULL_PIPELINE,
                entrypoint=shadow_orchestrator.ENTRYPOINT_MENU,
                repo_root=repo_root,
                python_exe=python_exe,
                env=env_with_root,
                env_flag_fn=env_flag_fn,
                ops=_orchestrator_ops(),
            )
            ok, msg, payload = _coerce_orchestrator_result_to_legacy(
                pipeline_result, default_running_message='Initialization in progress.'
            )
            if not ok:
                _maybe_send_orchestrator_failure_report(
                    repo_root=repo_root,
                    lab_root=selected_root,
                    orchestration_result=pipeline_result,
                    trigger='ensure_lab_ready_pipeline',
                )
            return (ok, msg, payload)

        if ok and (baseline_result.get("error_code") == shadow_orchestrator.ERROR_READY_NOOP or not msg):
            msg = ''
        return (ok, msg, payload)
    except Exception as e:
        diag_path = _write_bootstrap_diag(repo_root, lab_root, 'BOOTSTRAP_EXCEPTION', {
            'flow_stage': 'bootstrap_execute',
            'exception': str(e),
            'python_exe': python_exe,
            'target_folder': env.get('target_folder', ''),
            'source_folder': env.get('source_folder', ''),
        })
        return (False, _bootstrap_fail_message('BOOTSTRAP_EXCEPTION', str(e), diag_path), None)


def is_pipeline_running(lab_root):
    """Check if shadow pipeline is running. Returns bool. Exception-safe."""
    try:
        from MediCafe.cloud_readiness_health import is_pipeline_running as _health_check
        return _health_check(lab_root)
    except Exception:
        return False


def check_pipeline_running_for_action(repo_root, action_name):
    """Returns (is_running, warning_msg). warning_msg set when is_running."""
    lab_root = resolve_lab_root(repo_root)
    running = is_pipeline_running(lab_root)
    msg = 'Note: Pipeline is running. {0} may reflect stale data.'.format(action_name) if running else None
    return (running, msg)


def _default_env_flag(_name, default=False):
    return default


_OPERATOR_DEFERRED_SEND_FILENAME = 'operator_deferred_support_send.json'
_OPERATOR_DEFERRED_DAT_SMOKE_FILENAME = 'operator_deferred_phase_d_dat_smoke.json'
_PHASE_D_DAT_SMOKE_STATE_FILENAME = 'phase_d_dat_smoke_state.json'
_PHASE_D_DAT_SMOKE_DEFAULT_COOLDOWN_SEC = 30 * 60


def _normalize_phase_d_reprocess_classes(raw):
    if _normalize_phase_d_reprocess_classes_impl is not None:
        try:
            return _normalize_phase_d_reprocess_classes_impl(raw)
        except Exception:
            pass
    classes = []
    seen = set()
    if raw is None:
        raw_parts = []
    elif isinstance(raw, str):
        raw_parts = raw.split(',')
    else:
        try:
            raw_parts = list(raw)
        except Exception:
            raw_parts = [raw]
    for value in raw_parts:
        key = str(value or '').strip().lower()
        if not key or key in seen or key not in ('csv', 'dat', 'docx'):
            continue
        seen.add(key)
        classes.append(key)
    return classes


def operator_deferred_support_send_path(repo_root):
    """Path for one-shot deferred recommendation intent (under lab reports/)."""
    lab_root = resolve_lab_root(repo_root)
    return os.path.join(lab_root, 'reports', _OPERATOR_DEFERRED_SEND_FILENAME)


def _normalize_operator_deferred_support_send(data):
    payload = data if isinstance(data, dict) else {}
    primary_send = str(payload.get('primary_send', '') or '').strip()
    if primary_send not in ('run_evidence', 'system_health'):
        primary_send = 'system_health'
    action_kind = str(payload.get('action_kind', '') or 'send_bundle').strip()
    if action_kind not in ('send_bundle', 'historical_phase_d_reprocess', 'phase_d_dat_smoke', 'review_dat_qa_full_block'):
        action_kind = 'send_bundle'
    report_kind = str(payload.get('recommended_report_kind', '') or '').strip()
    if report_kind not in ('artifact_triage_pack', 'system_health_pack'):
        report_kind = ''
    return {
        'primary_send': primary_send,
        'action_kind': action_kind,
        'recommended_report_kind': report_kind,
        'artifact_classes': _normalize_phase_d_reprocess_classes(payload.get('artifact_classes', [])),
        'reason': str(payload.get('reason', '') or '')[:500],
        'created_at_utc': str(payload.get('created_at_utc', '') or ''),
    }


def write_operator_deferred_support_send(repo_root, primary_send, reason='', action_kind='send_bundle', artifact_classes=None, recommended_report_kind=''):
    """
    Persist a deferred recommended action. The launcher recomputes the current
    recommendation after the lab settles before executing anything.
    """
    path = operator_deferred_support_send_path(repo_root)
    try:
        parent = os.path.dirname(path)
        if parent and not os.path.isdir(parent):
            os.makedirs(parent)
        payload = _normalize_operator_deferred_support_send({
            'primary_send': primary_send,
            'action_kind': action_kind,
            'artifact_classes': artifact_classes,
            'recommended_report_kind': recommended_report_kind,
            'reason': reason,
            'created_at_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        })
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return True
    except Exception:
        return False


def read_operator_deferred_support_send(repo_root):
    try:
        path = operator_deferred_support_send_path(repo_root)
        if not os.path.isfile(path):
            return None
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        if not isinstance(data, dict):
            return None
        return _normalize_operator_deferred_support_send(data)
    except Exception:
        return None


def clear_operator_deferred_support_send(repo_root):
    try:
        path = operator_deferred_support_send_path(repo_root)
        if os.path.isfile(path):
            os.remove(path)
        return True
    except Exception:
        return False


def phase_d_dat_smoke_state_path(repo_root):
    lab_root = resolve_lab_root(repo_root)
    return os.path.join(lab_root, _PHASE_D_DAT_SMOKE_STATE_FILENAME)


def _normalize_phase_d_dat_smoke_state(data):
    payload = data if isinstance(data, dict) else {}
    out = {
        'last_requested_anchor_run_id': str(payload.get('last_requested_anchor_run_id', '') or '').strip(),
        'last_requested_context_run_id': str(payload.get('last_requested_context_run_id', '') or '').strip(),
        'last_remediation_issue_code': str(payload.get('last_remediation_issue_code', '') or '').strip(),
        'last_started_at_utc': str(payload.get('last_started_at_utc', '') or '').strip(),
        'last_finished_at_utc': str(payload.get('last_finished_at_utc', '') or '').strip(),
        'last_status': str(payload.get('last_status', '') or '').strip(),
        'last_report_path': str(payload.get('last_report_path', '') or '').strip(),
        'last_assessment': str(payload.get('last_assessment', '') or '').strip(),
        'cooldown_until_utc': str(payload.get('cooldown_until_utc', '') or '').strip(),
    }
    return out


def read_phase_d_dat_smoke_state(repo_root):
    try:
        path = phase_d_dat_smoke_state_path(repo_root)
        if not os.path.isfile(path):
            return _normalize_phase_d_dat_smoke_state({})
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return _normalize_phase_d_dat_smoke_state(data)
    except Exception:
        return _normalize_phase_d_dat_smoke_state({})


def write_phase_d_dat_smoke_state(repo_root, data):
    path = phase_d_dat_smoke_state_path(repo_root)
    try:
        parent = os.path.dirname(path)
        if parent and not os.path.isdir(parent):
            os.makedirs(parent)
        payload = _normalize_phase_d_dat_smoke_state(data)
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return True
    except Exception:
        return False


def update_phase_d_dat_smoke_state(
        repo_root,
        anchor_run_id='',
        context_run_id='',
        issue_code='',
        started_at_utc='',
        finished_at_utc='',
        status='',
        report_path='',
        assessment='',
        cooldown_until_utc=''):
    """
    Merge-update phase_d_dat_smoke_state.json keys. Empty arguments keep current values.
    """
    state = read_phase_d_dat_smoke_state(repo_root)
    if anchor_run_id is not None and str(anchor_run_id or '').strip():
        state['last_requested_anchor_run_id'] = str(anchor_run_id or '').strip()
    if context_run_id is not None and str(context_run_id or '').strip():
        state['last_requested_context_run_id'] = str(context_run_id or '').strip()
    if issue_code is not None and str(issue_code or '').strip():
        state['last_remediation_issue_code'] = str(issue_code or '').strip()
    if started_at_utc is not None and str(started_at_utc or '').strip():
        state['last_started_at_utc'] = str(started_at_utc or '').strip()
    if finished_at_utc is not None and str(finished_at_utc or '').strip():
        state['last_finished_at_utc'] = str(finished_at_utc or '').strip()
    if status is not None and str(status or '').strip():
        state['last_status'] = str(status or '').strip()
    if report_path is not None and str(report_path or '').strip():
        state['last_report_path'] = str(report_path or '').strip()
    if assessment is not None and str(assessment or '').strip():
        state['last_assessment'] = str(assessment or '').strip()
    if cooldown_until_utc is not None and str(cooldown_until_utc or '').strip():
        state['cooldown_until_utc'] = str(cooldown_until_utc or '').strip()
    return write_phase_d_dat_smoke_state(repo_root, state)


def operator_deferred_phase_d_dat_smoke_path(repo_root):
    lab_root = resolve_lab_root(repo_root)
    return os.path.join(lab_root, 'reports', _OPERATOR_DEFERRED_DAT_SMOKE_FILENAME)


def _normalize_operator_deferred_phase_d_dat_smoke(data):
    payload = data if isinstance(data, dict) else {}
    return {
        'anchor_run_id': str(payload.get('anchor_run_id', '') or '').strip(),
        'context_run_id': str(payload.get('context_run_id', '') or '').strip(),
        'issue_code': str(payload.get('issue_code', '') or '').strip(),
        'reference_phase_d_summary_path': str(payload.get('reference_phase_d_summary_path', '') or '').strip(),
        'reason': str(payload.get('reason', '') or '')[:500],
        'created_at_utc': str(payload.get('created_at_utc', '') or '').strip(),
    }


def write_operator_deferred_phase_d_dat_smoke(
        repo_root,
        anchor_run_id,
        context_run_id,
        issue_code='',
        reference_phase_d_summary_path='',
        reason=''):
    path = operator_deferred_phase_d_dat_smoke_path(repo_root)
    try:
        parent = os.path.dirname(path)
        if parent and not os.path.isdir(parent):
            os.makedirs(parent)
        payload = _normalize_operator_deferred_phase_d_dat_smoke({
            'anchor_run_id': anchor_run_id,
            'context_run_id': context_run_id,
            'issue_code': issue_code,
            'reference_phase_d_summary_path': reference_phase_d_summary_path,
            'reason': reason,
            'created_at_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        })
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return True
    except Exception:
        return False


def read_operator_deferred_phase_d_dat_smoke(repo_root):
    try:
        path = operator_deferred_phase_d_dat_smoke_path(repo_root)
        if not os.path.isfile(path):
            return None
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        if not isinstance(data, dict):
            return None
        return _normalize_operator_deferred_phase_d_dat_smoke(data)
    except Exception:
        return None


def clear_operator_deferred_phase_d_dat_smoke(repo_root):
    try:
        path = operator_deferred_phase_d_dat_smoke_path(repo_root)
        if os.path.isfile(path):
            os.remove(path)
        return True
    except Exception:
        return False


def _phase_d_dat_smoke_target_tuple(anchor_run_id, context_run_id, issue_code):
    return (
        str(anchor_run_id or '').strip(),
        str(context_run_id or '').strip(),
        str(issue_code or '').strip(),
    )


def _phase_d_dat_smoke_state_suppressed(state, anchor_run_id, context_run_id, issue_code):
    st = state if isinstance(state, dict) else {}
    target = _phase_d_dat_smoke_target_tuple(anchor_run_id, context_run_id, issue_code)
    last = _phase_d_dat_smoke_target_tuple(
        st.get('last_requested_anchor_run_id', ''),
        st.get('last_requested_context_run_id', ''),
        st.get('last_remediation_issue_code', ''),
    )
    if not target[0] or not target[1]:
        return False
    if target != last:
        return False
    status = str(st.get('last_status', '') or '').strip().lower()
    if status in ('running', 'started'):
        return True
    cooldown_until = str(st.get('cooldown_until_utc', '') or '').strip()
    if cooldown_until:
        try:
            until_epoch = _parse_iso_utc_epoch(cooldown_until)
            if until_epoch and until_epoch > time.time():
                return True
        except Exception:
            pass
    return False


def _phase_d_dat_smoke_reference_summary_for_anchor(repo_root, anchor_run_id):
    """Resolve anchored main-lab Phase D summary JSON; no latest-by-prefix fallback."""
    anchor = str(anchor_run_id or '').strip()
    if not anchor:
        return ''
    lab_root = resolve_lab_root(repo_root)
    path = os.path.join(lab_root, 'reports', 'qa_canonical_summary_{0}.json'.format(anchor))
    if os.path.isfile(path):
        return path
    return ''


def _phase_d_dat_smoke_context_run_id(phase_d_payload, anchor_run_id):
    phase_d_payload = phase_d_payload if isinstance(phase_d_payload, dict) else {}
    rid = str(phase_d_payload.get('run_id', '') or '').strip()
    if rid:
        return rid
    return str(anchor_run_id or '').strip()

def _preferred_when_stable_from_snapshot(ok_snap, snap, snap_msg, nearest_complete, artifact_why_lines):
    """
    Artifact-only preference (ignores pipeline). Mutates artifact_why_lines with quality/snapshot reasons.
    Returns preferred_when_stable: run_evidence | system_health.
    """
    if not ok_snap:
        artifact_why_lines.append(
            'Latest run evidence snapshot is not available; a system-health pack gives broader lab context.')
        if snap_msg:
            artifact_why_lines.append('Detail: {0}'.format(str(snap_msg)[:240]))
        return 'system_health'

    bundle_quality = _artifact_bundle_quality(snap)
    score = int(bundle_quality.get('score', 0))
    label = str(bundle_quality.get('label', '') or '')
    rec = str(bundle_quality.get('recommendation', '') or '')

    if rec == 'review_lab_state':
        miss = int(bundle_quality.get('missing', 0) or 0)
        if miss > 0:
            msg = (
                'Lab diagnostics (pipeline state / run alignment) are not coherent with this run_id; '
                'phase coverage is incomplete (missing phases). Prefer System Health Pack or fix diagnostics before handoff.')
            if nearest_complete:
                msg += ' Latest complete run_id={0} may be more representative.'.format(nearest_complete)
            artifact_why_lines.append(msg)
        else:
            artifact_why_lines.append(
                'Run-evidence files are complete but lab diagnostics (pipeline state / run alignment) are not coherent; '
                'prefer System Health Pack or resolve diagnostics before treating the bundle as handoff-ready.')
        return 'system_health'
    if rec == 'prefer_nearest_complete' and label == 'LOW' and nearest_complete:
        artifact_why_lines.append(
            'Run-evidence quality is LOW; latest complete run_id={0} may be more representative.'.format(
                nearest_complete))
        if _artifact_tools.artifact_snapshot_coherence_blocked(snap):
            artifact_why_lines.append(
                'Lab diagnostics still conflict with a clean handoff; review diagnostics_state before treating evidence as coherent.')
        return 'system_health'
    if score < 45:
        artifact_why_lines.append(
            'Run-evidence quality score is low ({0}); system-health pack adds migration audit and alignment.'.format(
                score))
        return 'system_health'
    artifact_why_lines.append(
        'Run-evidence quality {0} (score {1}); sending the coherent B..F bundle is appropriate.'.format(
            label, score))
    return 'run_evidence'


def _snapshot_phase_json_path(snapshot, phase_code, prefix=''):
    rows = snapshot.get('phase_rows', []) if isinstance(snapshot.get('phase_rows', []), list) else []
    for row in rows:
        if str(row.get('code', '') or '').strip().upper() != str(phase_code or '').strip().upper():
            continue
        files = row.get('files', []) if isinstance(row.get('files', []), list) else []
        for path in files:
            base = os.path.basename(str(path or ''))
            if prefix and not base.startswith(prefix):
                continue
            if base.lower().endswith('.json'):
                return path
    return ''



def _load_phase_summary_from_snapshot(snapshot, phase_code, prefix=''):
    path = _snapshot_phase_json_path(snapshot, phase_code, prefix=prefix)
    return (_load_json_dict(path), path)



def _int_or_zero(value):
    try:
        return int(value or 0)
    except Exception:
        return 0



def _relax_snapshot_diagnostics_for_anchor_evaluation(snapshot, anchor_run_id):
    """
    Shallow-adjust diagnostics_state so coherence checks evaluate the anchored run_id against
    a synthetic last-completed handoff, ignoring live lab drift (failed newer attempt, etc.).

    Also clears snapshot lineage_issues for this evaluation-only view. Zero-selection Phase D
    summaries often record a different phase_c_summary_run_id_used_for_zero_selection than the
    shadow phase_run_ids.C line — that is expected for historical-backlog / duplicate-dominant
    runs but would otherwise keep artifact_snapshot_coherence_blocked true and suppress
    historical_phase_d_reprocess in favor of send_bundle.
    """
    if not isinstance(snapshot, dict):
        return snapshot
    anchor_run_id = str(anchor_run_id or '').strip()
    rid = str(snapshot.get('run_id', '') or '').strip()
    if not anchor_run_id or rid != anchor_run_id:
        return snapshot
    out = dict(snapshot)
    ds = snapshot.get('diagnostics_state')
    ds = dict(ds) if isinstance(ds, dict) else {}
    ds['last_shadow_pipeline_run_id'] = anchor_run_id
    ds['active_run_id'] = ''
    ps = str(ds.get('pipeline_state', '') or '').strip().lower()
    if ps in ('failed', 'running', 'bootstrapping'):
        ds['pipeline_state'] = 'completed'
    out['diagnostics_state'] = ds
    out['lineage_issues'] = []
    return out


def _derive_live_run_id_for_recommendation(state, latest_snapshot):
    """Prefer diagnostics active/last pipeline run id; fall back to latest artifact snapshot run_id."""
    state = state if isinstance(state, dict) else {}
    latest = latest_snapshot if isinstance(latest_snapshot, dict) else {}
    active = str(state.get('active_run_id', '') or '').strip()
    if active:
        return active
    last = str(state.get('last_shadow_pipeline_run_id', '') or '').strip()
    if last:
        return last
    return str(latest.get('run_id', '') or '').strip()


def _derive_live_pipeline_status(state, pipeline_running):
    """Map diagnostics state to recommendation_live_run_status."""
    state = state if isinstance(state, dict) else {}
    if pipeline_running:
        return 'running'
    ps = str(state.get('pipeline_state', '') or '').strip().lower()
    if ps in ('bootstrapping', 'running'):
        return 'running'
    ok = state.get('last_shadow_pipeline_ok')
    if ok is True:
        return 'completed'
    if ok is False:
        return 'failed'
    return 'pending'


def _select_evaluation_snapshot_for_recommendation(repo_root, pack_context):
    """
    Choose artifact snapshot used for bundle quality + historical reprocess.
    Returns (ok, msg, snapshot, meta) where meta includes provenance hints.
    """
    lab_root = resolve_lab_root(repo_root)
    pipeline_running = is_pipeline_running(lab_root)
    state_path = os.path.join(lab_root, 'diagnostics_state.json')
    state = _load_json_dict(state_path)
    ok_l, msg_l, latest = _build_run_artifact_snapshot(repo_root, run_id='')
    if not isinstance(latest, dict):
        latest = {}
    live_id = _derive_live_run_id_for_recommendation(state, latest)
    artifact_latest_run_id = str(latest.get('run_id', '') or '').strip()
    live_status = _derive_live_pipeline_status(state, pipeline_running)
    meta = {
        'pipeline_running': pipeline_running,
        'live_run_id': live_id,
        'live_run_status': live_status,
        'recommendation_source_scope': 'latest_live_snapshot',
        'recommendation_anchor_run_id': '',
        'fallback_note': '',
        'newer_live_context_note': '',
    }
    if not pack_context or not isinstance(pack_context, dict):
        return ok_l, msg_l, latest, meta
    pack_scope = str(pack_context.get('pack_scope', '') or '')
    anchor_id = str(pack_context.get('anchor_run_id', '') or '').strip()
    if pack_scope not in ('completed_run', 'mixed_scope') or not anchor_id:
        return ok_l, msg_l, latest, meta
    ok_a, msg_a, anchor_snap = _build_run_artifact_snapshot(repo_root, run_id=anchor_id)
    if not ok_a or not isinstance(anchor_snap, dict):
        meta['fallback_note'] = (
            'Anchored completed-run snapshot unavailable ({0}); using latest artifact snapshot for recommendation.'
        ).format(msg_a or 'missing')
        return ok_l, msg_l, latest, meta
    anchor_eval = _relax_snapshot_diagnostics_for_anchor_evaluation(anchor_snap, anchor_id)
    if _artifact_tools.artifact_snapshot_coherence_blocked(anchor_eval):
        meta['fallback_note'] = (
            'Anchored completed-run snapshot is blocked for handoff-style evaluation; using latest artifact snapshot for recommendation.'
        )
        return ok_l, msg_l, latest, meta
    meta['recommendation_source_scope'] = 'anchored_completed_run'
    meta['recommendation_anchor_run_id'] = anchor_id
    if live_id and anchor_id and live_id != anchor_id:
        note_rid = live_id
        if artifact_latest_run_id and artifact_latest_run_id != live_id:
            note_rid = '{0} (latest artifacts run_id={1})'.format(live_id, artifact_latest_run_id)
        meta['newer_live_context_note'] = (
            'Live pipeline run_id={0} (status={1}); remediation evaluation uses anchored completed run_id={2}.'
        ).format(note_rid, live_status, anchor_id)
    elif live_status in ('failed', 'running', 'pending'):
        meta['newer_live_context_note'] = (
            'Live pipeline status={0}; remediation evaluation uses anchored completed run_id={1}.'
        ).format(live_status, anchor_id)
    return True, '', anchor_eval, meta


def _build_historical_phase_d_reprocess_recommendation(repo_root, snapshot, bundle_quality, pipeline_running):
    """
    Returns (candidate_dict_or_none, skip_reason_str).
    skip_reason is non-empty when evaluation ran but did not recommend historical reprocess.
    """
    if not isinstance(snapshot, dict):
        return None, ''
    if not isinstance(bundle_quality, dict):
        return None, ''
    if _artifact_tools.artifact_snapshot_coherence_blocked(snapshot):
        return None, 'historical reprocess not triggered: anchored or evaluated snapshot is not coherent enough (lab state conflicts with a clean handoff).'
    if _collect_phase_d_reject_snapshot_impl is None:
        return None, ''

    shadow_payload, _shadow_path = _load_phase_summary_from_snapshot(snapshot, 'F', prefix='shadow_run_report_')
    phase_c_payload, _phase_c_path = _load_phase_summary_from_snapshot(snapshot, 'C', prefix='ingest_write_summary_')
    phase_d_payload, _phase_d_path = _load_phase_summary_from_snapshot(snapshot, 'D', prefix='qa_canonical_summary_')

    latest_phase_c_inserted = _int_or_zero(shadow_payload.get('phase_c_inserted_count'))
    if latest_phase_c_inserted <= 0:
        latest_phase_c_inserted = _int_or_zero(phase_c_payload.get('rows_inserted'))
    latest_phase_c_skipped = _int_or_zero(shadow_payload.get('phase_c_skipped_count'))
    if latest_phase_c_skipped <= 0:
        latest_phase_c_skipped = _int_or_zero(phase_c_payload.get('rows_skipped_duplicate'))
    latest_phase_d_rows_selected = None
    if 'phase_d_rows_selected' in shadow_payload:
        latest_phase_d_rows_selected = _int_or_zero(shadow_payload.get('phase_d_rows_selected'))
    elif 'rows_selected' in phase_d_payload:
        latest_phase_d_rows_selected = _int_or_zero(phase_d_payload.get('rows_selected'))
    latest_phase_d_pass = _int_or_zero(shadow_payload.get('phase_d_pass_count'))
    if latest_phase_d_pass <= 0:
        latest_phase_d_pass = _int_or_zero(phase_d_payload.get('qa_pass_count'))
    latest_phase_d_reject = _int_or_zero(shadow_payload.get('phase_d_reject_count'))
    if latest_phase_d_reject <= 0:
        latest_phase_d_reject = _int_or_zero(phase_d_payload.get('qa_reject_count'))
    qa_policy_version = str(shadow_payload.get('phase_d_qa_policy_version', '') or phase_d_payload.get('qa_policy_version', '') or '').strip()

    if _historical_reprocess_numeric_predicates is not None:
        duplicate_dominant, no_new_phase_d_movement = _historical_reprocess_numeric_predicates(
            shadow_payload, phase_c_payload, phase_d_payload)
    else:
        duplicate_dominant = latest_phase_c_skipped > 0 and latest_phase_c_skipped >= max(1, latest_phase_c_inserted)
        if latest_phase_d_rows_selected is not None:
            no_new_phase_d_movement = (latest_phase_d_rows_selected == 0)
        else:
            no_new_phase_d_movement = (
                latest_phase_d_pass == 0 and latest_phase_d_reject == 0 and latest_phase_c_skipped > 0
            )
    if not duplicate_dominant:
        return None, 'historical reprocess not triggered: Phase C is not duplicate-dominant for this evaluated run.'
    if not no_new_phase_d_movement:
        return None, 'historical reprocess not triggered: Phase D shows new pass/reject movement or row selection for this evaluated run.'

    lab_root = str(snapshot.get('lab_root', '') or resolve_lab_root(repo_root)).strip()
    reject_snapshot = _collect_phase_d_reject_snapshot_impl(lab_root, artifact_classes=None, qa_version=None)
    if not isinstance(reject_snapshot, dict) or not reject_snapshot.get('ok'):
        return None, 'historical reprocess not triggered: could not read Phase D reject snapshot from the lab database.'
    target_classes = _normalize_phase_d_reprocess_classes(reject_snapshot.get('targeted_artifact_classes', []))
    if not target_classes:
        return None, 'historical reprocess not triggered: no Phase D rejects remain for dat/csv/docx in the evaluated scope.'

    reject_counts = reject_snapshot.get('reject_counts_by_class', {}) if isinstance(reject_snapshot.get('reject_counts_by_class', {}), dict) else {}
    pending_counts = reject_snapshot.get('pending_replay_counts_by_class', {}) if isinstance(reject_snapshot.get('pending_replay_counts_by_class', {}), dict) else {}
    filtered_reject_counts = {}
    filtered_pending_counts = {}
    for artifact_class in target_classes:
        filtered_reject_counts[artifact_class] = _int_or_zero(reject_counts.get(artifact_class))
        filtered_pending_counts[artifact_class] = _int_or_zero(pending_counts.get(artifact_class))

    reason_lines = []
    reason_lines.append(
        'Latest Phase C inserted {0} rows and skipped {1} duplicates; this run is re-reading historical artifacts rather than introducing new ones.'.format(
            latest_phase_c_inserted,
            latest_phase_c_skipped,
        )
    )
    if latest_phase_d_rows_selected is not None:
        reason_lines.append(
            'Latest Phase D selected {0} rows for the current QA version, so rerunning D alone will not revisit the historical rejects.'.format(
                latest_phase_d_rows_selected,
            )
        )
    else:
        reason_lines.append(
            'Latest Phase D shows no new pass/reject movement while Phase C is duplicate-dominant, which is consistent with already-evaluated historical artifacts.'
        )
    tqv = reject_snapshot.get('targeted_qa_versions', [])
    if not isinstance(tqv, list):
        tqv = []
    tqv_s = ', '.join([str(x) for x in tqv if str(x or '').strip()]) or 'unknown'
    reason_lines.append(
        'Phase D rejects still exist for {0} (qa_version scope includes: {1}).'.format(
            ', '.join(target_classes),
            tqv_s,
        )
    )

    h_by_ver = reject_snapshot.get('historical_reject_counts_by_version', {})
    if not isinstance(h_by_ver, dict):
        h_by_ver = {}

    preview = {
        'qa_policy_version': qa_policy_version or str(reject_snapshot.get('qa_version', '') or ''),
        'targeted_qa_versions': tqv,
        'latest_phase_c_inserted_count': latest_phase_c_inserted,
        'latest_phase_c_skipped_count': latest_phase_c_skipped,
        'latest_phase_d_rows_selected': _int_or_zero(latest_phase_d_rows_selected),
        'latest_phase_d_pass_count': latest_phase_d_pass,
        'latest_phase_d_reject_count': latest_phase_d_reject,
        'historical_reject_counts_by_class': filtered_reject_counts,
        'historical_reject_counts_by_version': dict(h_by_ver),
        'pending_replay_counts_by_class': filtered_pending_counts,
    }

    best_now_action_kind = 'historical_phase_d_reprocess'
    if pipeline_running:
        best_now_action_kind = 'wait_for_stable'

    preview_path = ''
    preview_fn = None
    try:
        from scripts.unified_model.phase_d_historical_reprocess import preview_historical_phase_d_reprocess
        preview_fn = preview_historical_phase_d_reprocess
    except Exception:
        try:
            from phase_d_historical_reprocess import preview_historical_phase_d_reprocess
            preview_fn = preview_historical_phase_d_reprocess
        except Exception:
            preview_fn = None
    anchor_rid = str(shadow_payload.get('run_id') or snapshot.get('run_id') or '').strip()
    if preview_fn:
        try:
            prv = preview_fn(lab_root, remediation_context_run_id=anchor_rid or None)
            if isinstance(prv, dict):
                preview_path = str(prv.get('report_path') or '')
        except Exception:
            preview_path = ''

    return ({
        'recommended_action_kind': 'historical_phase_d_reprocess',
        'preferred_when_stable_action_kind': 'historical_phase_d_reprocess',
        'best_now_action_kind': best_now_action_kind,
        'recommended_report_kind': 'artifact_triage_pack',
        'recommended_artifact_classes': target_classes,
        'action_requires_confirmation': True,
        'action_preview': preview,
        'action_reason_lines': reason_lines,
        'historical_reprocess_preview_path': preview_path,
    }, '')


def _build_phase_d_dat_smoke_recommendation(repo_root, snapshot, pipeline_running):
    """
    Returns (candidate_dict_or_none, skip_reason_str).
    Recommendation is anchored-first and pure (no subprocess side effects).
    """
    if not isinstance(snapshot, dict):
        return None, ''
    if _artifact_tools.artifact_snapshot_coherence_blocked(snapshot):
        return None, 'DAT smoke not triggered: anchored or evaluated snapshot is not coherent enough for recommendation.'

    lab_root = str(snapshot.get('lab_root', '') or resolve_lab_root(repo_root)).strip()
    diagnostics_state = _load_json_dict(os.path.join(lab_root or '.', 'diagnostics_state.json'))
    if not isinstance(diagnostics_state, dict):
        diagnostics_state = {}
    remediation = diagnostics_state.get('phase_d_remediation') if isinstance(diagnostics_state.get('phase_d_remediation'), dict) else {}
    issue_code = str(remediation.get('issue_code', '') or '').strip()

    shadow_payload, shadow_path = _load_phase_summary_from_snapshot(snapshot, 'F', prefix='shadow_run_report_')
    phase_d_payload, _phase_d_path = _load_phase_summary_from_snapshot(snapshot, 'D', prefix='qa_canonical_summary_')
    if not isinstance(shadow_payload, dict):
        shadow_payload = {}
    if not isinstance(phase_d_payload, dict):
        phase_d_payload = {}

    anchor_run_id = str(shadow_payload.get('run_id') or snapshot.get('run_id') or '').strip()
    context_run_id = _phase_d_dat_smoke_context_run_id(phase_d_payload, anchor_run_id)

    discovery = diagnostics_state.get('last_discovery_dat_telemetry', {})
    if not isinstance(discovery, dict):
        discovery = {}
    phase_d_diag = diagnostics_state.get('last_phase_d_dat_telemetry', {})
    if not isinstance(phase_d_diag, dict):
        phase_d_diag = {}
    phase_d_telemetry = phase_d_payload.get('dat_telemetry') if isinstance(phase_d_payload.get('dat_telemetry'), dict) else {}

    manifest_rows = None
    if 'phase_b_dat_manifest_rows_count' in shadow_payload:
        manifest_rows = _safe_int(shadow_payload.get('phase_b_dat_manifest_rows_count'), 0)
    elif str(shadow_path or '').strip():
        manifest_rows = _safe_int(shadow_payload.get('phase_b_dat_manifest_rows_count'), 0)
    else:
        manifest_rows = _safe_int(discovery.get('dat_manifest_rows_count'), 0)
    if manifest_rows <= 0:
        return None, 'DAT smoke not triggered: Phase B DAT manifest did not indicate discovered DAT rows for the anchored run.'

    selected_source = None
    dat_selected = None
    if 'phase_d_dat_selected_count' in shadow_payload:
        selected_source = 'shadow'
        dat_selected = _safe_int(shadow_payload.get('phase_d_dat_selected_count'), 0)
    elif 'dat_selected_count' in phase_d_telemetry:
        selected_source = 'phase_d_summary'
        dat_selected = _safe_int(phase_d_telemetry.get('dat_selected_count'), 0)
    elif 'phase_d_dat_selected_count' in phase_d_payload:
        selected_source = 'phase_d_summary'
        dat_selected = _safe_int(phase_d_payload.get('phase_d_dat_selected_count'), 0)
    else:
        selected_source = 'diagnostics'
        dat_selected = _safe_int(phase_d_diag.get('dat_selected_count'), 0)
    if dat_selected != 0:
        return None, 'DAT smoke not triggered: anchored Phase D already selected DAT rows (dat_selected_count={0}).'.format(dat_selected)

    blocked_stage = ''
    if 'post_medisoft_blocked_stage' in shadow_payload:
        blocked_stage = str(shadow_payload.get('post_medisoft_blocked_stage', '') or '').strip().lower()
    elif 'post_medisoft_blocked_stage' in phase_d_telemetry:
        blocked_stage = str(phase_d_telemetry.get('post_medisoft_blocked_stage', '') or '').strip().lower()
    elif 'post_medisoft_blocked_stage' in phase_d_payload:
        blocked_stage = str(phase_d_payload.get('post_medisoft_blocked_stage', '') or '').strip().lower()
    else:
        blocked_stage = str(phase_d_diag.get('post_medisoft_blocked_stage', '') or '').strip().lower()
    if blocked_stage not in ('', 'not_exercised'):
        return None, 'DAT smoke not triggered: post_medisoft_blocked_stage={0} indicates the lane was already exercised.'.format(blocked_stage)

    # Exclusion: truthful DAT QA full block already present in anchored telemetry.
    qa_pass = None
    qa_reject = None
    if 'phase_d_dat_qa_pass_count' in shadow_payload:
        qa_pass = _safe_int(shadow_payload.get('phase_d_dat_qa_pass_count'), 0)
    elif 'dat_qa_pass_count' in phase_d_telemetry:
        qa_pass = _safe_int(phase_d_telemetry.get('dat_qa_pass_count'), 0)
    elif 'phase_d_dat_qa_pass_count' in phase_d_payload:
        qa_pass = _safe_int(phase_d_payload.get('phase_d_dat_qa_pass_count'), 0)
    else:
        qa_pass = _safe_int(phase_d_diag.get('dat_qa_pass_count'), 0)
    if 'phase_d_dat_qa_reject_count' in shadow_payload:
        qa_reject = _safe_int(shadow_payload.get('phase_d_dat_qa_reject_count'), 0)
    elif 'dat_qa_reject_count' in phase_d_telemetry:
        qa_reject = _safe_int(phase_d_telemetry.get('dat_qa_reject_count'), 0)
    elif 'phase_d_dat_qa_reject_count' in phase_d_payload:
        qa_reject = _safe_int(phase_d_payload.get('phase_d_dat_qa_reject_count'), 0)
    else:
        qa_reject = _safe_int(phase_d_diag.get('dat_qa_reject_count'), 0)

    telemetry_indicates_dat_qa_full_block = None
    derive_strict_milestone_verdict = None
    strict_gate_from_shadow_payload = None
    strict_gate_for_missing_shadow_report = None
    VERDICT_NOT_ADVANCED = 'Not advanced'
    try:
        from scripts.unified_model.phase_d_milestone_gate import (
            VERDICT_NOT_ADVANCED as _VERDICT_NOT_ADVANCED,
            derive_strict_milestone_verdict as _derive_strict_milestone_verdict,
            strict_gate_for_missing_shadow_report as _strict_gate_for_missing_shadow_report,
            strict_gate_from_shadow_payload as _strict_gate_from_shadow_payload,
            telemetry_indicates_dat_qa_full_block as _telemetry_indicates_dat_qa_full_block,
        )
        VERDICT_NOT_ADVANCED = _VERDICT_NOT_ADVANCED
        derive_strict_milestone_verdict = _derive_strict_milestone_verdict
        strict_gate_for_missing_shadow_report = _strict_gate_for_missing_shadow_report
        strict_gate_from_shadow_payload = _strict_gate_from_shadow_payload
        telemetry_indicates_dat_qa_full_block = _telemetry_indicates_dat_qa_full_block
    except Exception:
        try:
            from phase_d_milestone_gate import (
                VERDICT_NOT_ADVANCED as _VERDICT_NOT_ADVANCED,
                derive_strict_milestone_verdict as _derive_strict_milestone_verdict,
                strict_gate_for_missing_shadow_report as _strict_gate_for_missing_shadow_report,
                strict_gate_from_shadow_payload as _strict_gate_from_shadow_payload,
                telemetry_indicates_dat_qa_full_block as _telemetry_indicates_dat_qa_full_block,
            )
            VERDICT_NOT_ADVANCED = _VERDICT_NOT_ADVANCED
            derive_strict_milestone_verdict = _derive_strict_milestone_verdict
            strict_gate_for_missing_shadow_report = _strict_gate_for_missing_shadow_report
            strict_gate_from_shadow_payload = _strict_gate_from_shadow_payload
            telemetry_indicates_dat_qa_full_block = _telemetry_indicates_dat_qa_full_block
        except Exception:
            pass

    if telemetry_indicates_dat_qa_full_block:
        if telemetry_indicates_dat_qa_full_block({
                'dat_selected_count': dat_selected,
                'dat_qa_pass_count': qa_pass,
                'dat_qa_reject_count': qa_reject,
        }):
            return None, 'DAT smoke not triggered: anchored run already shows a truthful DAT QA full-block signal.'

    strict_milestone_verdict = ''
    if derive_strict_milestone_verdict and strict_gate_from_shadow_payload and strict_gate_for_missing_shadow_report:
        try:
            if str(shadow_path or '').strip():
                strict_gate = strict_gate_from_shadow_payload(
                    shadow_payload, lab_root=lab_root, run_id=anchor_run_id or None)
            else:
                strict_gate = strict_gate_for_missing_shadow_report()
            strict_milestone_verdict = str(
                derive_strict_milestone_verdict(strict_gate, phase_d_payload if isinstance(phase_d_payload, dict) else {})
                or ''
            ).strip()
        except Exception:
            strict_milestone_verdict = ''
    if strict_milestone_verdict != VERDICT_NOT_ADVANCED:
        lbl = strict_milestone_verdict or '(unknown)'
        return None, 'DAT smoke not triggered: strict milestone verdict is {0}, not Not advanced.'.format(lbl)

    state = read_phase_d_dat_smoke_state(repo_root)
    if _phase_d_dat_smoke_state_suppressed(state, anchor_run_id, context_run_id, issue_code):
        return None, 'DAT smoke not triggered: same anchor/context/issue is in cooldown or already running.'

    reference_phase_d_summary_path = _phase_d_dat_smoke_reference_summary_for_anchor(repo_root, anchor_run_id)
    smoke_lab_root = os.path.join(repo_root, 'phase_d_dat_smoke_lab')
    expected_report_path = os.path.join(
        smoke_lab_root,
        'reports',
        'phase_d_dat_smoke_report_<smoke_pipeline_run_id>.txt',
    )
    preview = {
        'anchor_run_id': anchor_run_id,
        'phase_d_context_run_id': context_run_id,
        'remediation_issue_code': issue_code,
        'smoke_lab_root': smoke_lab_root,
        'expected_report_path': expected_report_path,
        'reference_phase_d_summary_path': reference_phase_d_summary_path,
        'smoke_reports_dir': os.path.join(smoke_lab_root, 'reports'),
        'dat_manifest_rows_count': int(manifest_rows or 0),
        'phase_d_dat_selected_count': int(dat_selected or 0),
        'post_medisoft_blocked_stage': blocked_stage,
        'strict_milestone_verdict': strict_milestone_verdict or VERDICT_NOT_ADVANCED,
        'dat_selected_source': selected_source,
    }
    reason_lines = [
        'Anchored Phase B discovered DAT rows (phase_b_dat_manifest_rows_count={0}).'.format(int(manifest_rows or 0)),
        'Anchored Phase D did not exercise DAT lane (phase_d_dat_selected_count=0).',
        'post_medisoft_blocked_stage={0}; DAT lane remains not exercised.'.format(blocked_stage or 'not_exercised'),
        'Strict milestone verdict remains {0}.'.format(strict_milestone_verdict or VERDICT_NOT_ADVANCED),
    ]
    if reference_phase_d_summary_path:
        reason_lines.append(
            'Smoke will compare against anchored main-lab Phase D summary: {0}.'.format(reference_phase_d_summary_path)
        )
    else:
        reason_lines.append(
            'Anchored main-lab Phase D summary JSON is missing; smoke will still run but reference diff is unavailable.'
        )
    best_now_action_kind = 'phase_d_dat_smoke'
    if pipeline_running:
        best_now_action_kind = 'wait_for_stable'
    return ({
        'recommended_action_kind': 'phase_d_dat_smoke',
        'preferred_when_stable_action_kind': 'phase_d_dat_smoke',
        'best_now_action_kind': best_now_action_kind,
        'recommended_report_kind': 'artifact_triage_pack',
        'recommended_artifact_classes': ['dat'],
        'action_requires_confirmation': False,
        'action_preview': preview,
        'action_reason_lines': reason_lines,
    }, '')


def _adjacent_json_path_for_text_report(path):
    text_path = str(path or '').strip()
    if not text_path:
        return ''
    root, ext = os.path.splitext(text_path)
    if ext.lower() != '.txt':
        return ''
    candidate = root + '.json'
    if os.path.isfile(candidate):
        return candidate
    return ''


def _dat_smoke_report_payload_from_state(smoke_state):
    state = smoke_state if isinstance(smoke_state, dict) else {}
    report_path = str(state.get('last_report_path', '') or '').strip()
    json_path = _adjacent_json_path_for_text_report(report_path)
    if not json_path:
        return {}
    payload = _load_json_dict(json_path)
    return payload if isinstance(payload, dict) else {}


def _safe_json_pair_path(reports_dir, prefix, run_id, suffix):
    reports_dir = str(reports_dir or '').strip()
    run_id = str(run_id or '').strip()
    if not reports_dir or not run_id:
        return ''
    path = os.path.join(reports_dir, '{0}{1}{2}'.format(prefix, run_id, suffix))
    if os.path.isfile(path):
        return path
    return ''


def _dat_metric_from_sources(
        shadow_payload, phase_d_payload, phase_d_telemetry, smoke_df,
        shadow_key, summary_key, smoke_counters_allowed=False):
    """
    Resolve a single DAT metric. Smoke funnel counters may override anchored Phase D only when
    smoke_counters_allowed is True (completed smoke, dat_selected_qa_blocked, same anchor as review).
    Otherwise anchored phase_d_telemetry / phase_d_payload / shadow_payload are display truth.
    """
    sources = []
    if smoke_counters_allowed and isinstance(smoke_df, dict):
        sources.append(smoke_df)
    sources.extend([phase_d_telemetry, phase_d_payload])
    for source in sources:
        if isinstance(source, dict) and summary_key in source:
            return _safe_int(source.get(summary_key), 0)
    if isinstance(shadow_payload, dict) and shadow_key in shadow_payload:
        return _safe_int(shadow_payload.get(shadow_key), 0)
    return None


def _build_phase_d_dat_qa_full_block_recommendation(repo_root, snapshot, smoke_state, pipeline_running):
    """
    Returns (candidate_dict_or_none, skip_reason_str).
    A truthful DAT-lane full block means smoke already exercised the lane; the next operator action
    is to review anchored QA evidence, not to suggest smoke or historical backlog replay.
    """
    if not isinstance(snapshot, dict):
        return None, ''
    if _artifact_tools.artifact_snapshot_coherence_blocked(snapshot):
        return None, 'DAT QA full-block review not triggered: anchored or evaluated snapshot is not coherent enough for recommendation.'

    smoke_state = smoke_state if isinstance(smoke_state, dict) else {}
    lab_root = str(snapshot.get('lab_root', '') or resolve_lab_root(repo_root)).strip()
    reports_dir = os.path.join(lab_root, 'reports')

    diagnostics_state = _load_json_dict(os.path.join(lab_root or '.', 'diagnostics_state.json'))
    if not isinstance(diagnostics_state, dict):
        diagnostics_state = {}
    remediation = diagnostics_state.get('phase_d_remediation') if isinstance(diagnostics_state.get('phase_d_remediation'), dict) else {}
    issue_code = str(remediation.get('issue_code', '') or '').strip()

    shadow_payload, shadow_path = _load_phase_summary_from_snapshot(snapshot, 'F', prefix='shadow_run_report_')
    phase_d_payload, phase_d_path = _load_phase_summary_from_snapshot(snapshot, 'D', prefix='qa_canonical_summary_')
    if not isinstance(shadow_payload, dict):
        shadow_payload = {}
    if not isinstance(phase_d_payload, dict):
        phase_d_payload = {}
    phase_d_telemetry = phase_d_payload.get('dat_telemetry') if isinstance(phase_d_payload.get('dat_telemetry'), dict) else {}

    anchor_run_id = str(shadow_payload.get('run_id') or snapshot.get('run_id') or '').strip()
    smoke_report = _dat_smoke_report_payload_from_state(smoke_state)
    smoke_df = smoke_report.get('dat_funnel') if isinstance(smoke_report.get('dat_funnel'), dict) else {}
    smoke_anchor_run_id = str(smoke_report.get('anchor_run_id', '') or '').strip()
    smoke_assessment = str(smoke_state.get('last_assessment', '') or smoke_report.get('assessment', '') or '').strip()
    smoke_status = str(smoke_state.get('last_status', '') or '').strip().lower()

    smoke_counters_allowed = (
        smoke_status == 'completed'
        and smoke_assessment == 'dat_selected_qa_blocked'
        and bool(anchor_run_id)
        and bool(smoke_anchor_run_id)
        and smoke_anchor_run_id == anchor_run_id
    )
    has_smoke_artifact = bool(smoke_report) or bool(str(smoke_state.get('last_report_path', '') or '').strip())
    ignored_smoke_mismatch = bool(has_smoke_artifact) and not smoke_counters_allowed
    source_mismatch_note = ''
    if ignored_smoke_mismatch:
        source_mismatch_note = (
            'Smoke on disk is not used for displayed counters: require completed smoke, '
            'assessment=dat_selected_qa_blocked, and smoke anchor_run_id matching anchored run_id={0} '
            '(smoke anchor_run_id={1}). Counts below are anchored Phase D / shadow only.'
        ).format(anchor_run_id or '-', smoke_anchor_run_id or '-')
    anchored_diagnosis_source = 'smoke_corroborated' if smoke_counters_allowed else 'anchored_phase_d_shadow'

    selected = _dat_metric_from_sources(
        shadow_payload, phase_d_payload, phase_d_telemetry, smoke_df,
        'phase_d_dat_selected_count', 'dat_selected_count', smoke_counters_allowed=smoke_counters_allowed)
    qa_pass = _dat_metric_from_sources(
        shadow_payload, phase_d_payload, phase_d_telemetry, smoke_df,
        'phase_d_dat_qa_pass_count', 'dat_qa_pass_count', smoke_counters_allowed=smoke_counters_allowed)
    qa_reject = _dat_metric_from_sources(
        shadow_payload, phase_d_payload, phase_d_telemetry, smoke_df,
        'phase_d_dat_qa_reject_count', 'dat_qa_reject_count', smoke_counters_allowed=smoke_counters_allowed)
    canonical = _dat_metric_from_sources(
        shadow_payload, phase_d_payload, phase_d_telemetry, smoke_df,
        'phase_d_dat_canonical_record_count', 'dat_canonical_record_count', smoke_counters_allowed=smoke_counters_allowed)
    blocked_stage = str(phase_d_telemetry.get('post_medisoft_blocked_stage', '') or '').strip().lower()
    strict_verdict = ''
    if smoke_report:
        strict_verdict = str(smoke_report.get('strict_milestone_verdict', '') or '').strip()
        if not blocked_stage:
            blocked_stage = str(smoke_df.get('post_medisoft_blocked_stage', '') or '').strip().lower()
    if selected is None:
        selected = 0
    if qa_pass is None:
        qa_pass = 0
    if qa_reject is None:
        qa_reject = 0
    if canonical is None:
        canonical = 0
    if not blocked_stage:
        blocked_stage = str(shadow_payload.get('post_medisoft_blocked_stage', '') or '').strip().lower()

    telemetry_full_block = False
    try:
        from scripts.unified_model.phase_d_milestone_gate import telemetry_indicates_dat_qa_full_block
        telemetry_full_block = bool(telemetry_indicates_dat_qa_full_block({
            'dat_selected_count': selected,
            'dat_qa_pass_count': qa_pass,
            'dat_qa_reject_count': qa_reject,
        }))
    except Exception:
        telemetry_full_block = bool(selected > 0 and qa_pass == 0 and qa_reject > 0)

    smoke_proves_full_block = smoke_counters_allowed
    if issue_code != 'PHASE_D_DAT_QA_FULL_BLOCK' and not telemetry_full_block and not smoke_proves_full_block:
        return None, 'DAT QA full-block review not triggered: anchored telemetry does not show a truthful DAT full-block state.'

    target_run_id = str(anchor_run_id or snapshot.get('run_id') or '').strip()
    if not target_run_id:
        return None, 'DAT QA full-block review not triggered: anchored run_id is unavailable.'

    qa_summary_path = str(phase_d_path or _safe_json_pair_path(reports_dir, 'qa_canonical_summary_', target_run_id, '.json') or '').strip()
    reject_samples_path = _safe_json_pair_path(reports_dir, 'qa_reject_samples_', target_run_id, '.jsonl')
    shadow_report_path = str(shadow_path or _safe_json_pair_path(reports_dir, 'shadow_run_report_', target_run_id, '.json') or '').strip()
    smoke_report_path = str(smoke_state.get('last_report_path', '') or '').strip()
    smoke_report_json_path = _adjacent_json_path_for_text_report(smoke_report_path)

    reason_lines = []
    if smoke_proves_full_block:
        reason_lines.append(
            'Completed DAT smoke for anchor run_id={0} shows dat_selected_qa_blocked; the lane is exercised and failing at QA rather than selection.'.format(
                smoke_anchor_run_id or target_run_id
            )
        )
    else:
        reason_lines.append(
            'Anchored Phase D telemetry shows DAT rows were selected but fully QA-blocked; the lane is exercised and failing at QA rather than selection.'
        )
    if source_mismatch_note:
        reason_lines.append(source_mismatch_note)
    reason_lines.append(
        'DAT movement: selected={0}, qa_pass={1}, qa_reject={2}, canonical={3}.'.format(
            int(selected or 0), int(qa_pass or 0), int(qa_reject or 0), int(canonical or 0)
        )
    )
    if blocked_stage:
        reason_lines.append('post_medisoft_blocked_stage={0}.'.format(blocked_stage))
    if strict_verdict:
        reason_lines.append('Smoke strict milestone verdict={0}.'.format(strict_verdict))
    if smoke_counters_allowed:
        reason_lines.append(
            'Next useful step is to review anchored QA evidence (summary + reject samples + matching smoke report), not rerun smoke or historical backlog replay.'
        )
    elif ignored_smoke_mismatch:
        reason_lines.append(
            'Next useful step is to review anchored QA evidence (summary + reject samples + shadow report); ignore mismatched smoke on disk for this review.'
        )
    else:
        reason_lines.append(
            'Next useful step is to review anchored QA evidence (summary + reject samples + shadow report), not rerun smoke or historical backlog replay.'
        )

    preview = {
        'anchor_run_id': target_run_id,
        'smoke_anchor_run_id': smoke_anchor_run_id,
        'phase_d_context_run_id': _phase_d_dat_smoke_context_run_id(phase_d_payload, target_run_id),
        'remediation_issue_code': issue_code or 'PHASE_D_DAT_QA_FULL_BLOCK',
        'phase_d_summary_path': qa_summary_path,
        'qa_reject_samples_path': reject_samples_path,
        'shadow_run_report_path': shadow_report_path,
        'smoke_report_path': smoke_report_path,
        'smoke_report_json_path': smoke_report_json_path,
        'smoke_assessment': smoke_assessment or 'dat_selected_qa_blocked',
        'strict_milestone_verdict': strict_verdict,
        'dat_selected_count': int(selected or 0),
        'dat_qa_pass_count': int(qa_pass or 0),
        'dat_qa_reject_count': int(qa_reject or 0),
        'dat_canonical_record_count': int(canonical or 0),
        'anchored_diagnosis_source': anchored_diagnosis_source,
        'smoke_source_accepted': bool(smoke_counters_allowed),
        'ignored_smoke_mismatch': bool(ignored_smoke_mismatch),
        'source_mismatch_note': source_mismatch_note,
    }
    best_now_action_kind = 'review_dat_qa_full_block'
    if pipeline_running:
        best_now_action_kind = 'wait_for_stable'
    return ({
        'recommended_action_kind': 'review_dat_qa_full_block',
        'preferred_when_stable_action_kind': 'review_dat_qa_full_block',
        'best_now_action_kind': best_now_action_kind,
        'recommended_report_kind': 'artifact_triage_pack',
        'recommended_artifact_classes': ['dat'],
        'action_requires_confirmation': False,
        'action_preview': preview,
        'action_reason_lines': reason_lines,
    }, '')


def _qa_drop_spike_reply_context(lab_root):
    """
    Best-effort context for unresolved QA-drop style cloud alerts.
    Prefer explicit alert-state issue keys, then infer from live/anchored
    Phase F + diagnostics telemetry when the control-plane signal is absent.
    Returns {'reply_required': bool, 'issue_key': str, 'issue_code': str}.
    """
    reply_codes = (
        'PHASE_D_INVALID_EXTERNAL_ID_SKIPS_PRESENT',
        'PHASE_D_INVALID_EXTERNAL_ID_ELEVATED',
    )
    state_path = os.path.join(lab_root or '.', _HEALTH_ALERT_STATE_FILENAME)
    state = _load_json_dict(state_path)
    if isinstance(state, dict):
        issue_key = str(state.get('last_issue_key', '') or '').strip()
        issue_code = issue_key.split(':', 1)[0].strip() if issue_key else ''
        if issue_code in reply_codes:
            return {
                'reply_required': True,
                'issue_key': issue_key,
                'issue_code': issue_code,
            }
        if issue_key:
            return {
                'reply_required': False,
                'issue_key': issue_key,
                'issue_code': issue_code,
            }

    diagnostics_state = _load_json_dict(os.path.join(lab_root or '.', 'diagnostics_state.json'))
    if not isinstance(diagnostics_state, dict):
        diagnostics_state = {}
    discovery = diagnostics_state.get('last_discovery_dat_telemetry', {})
    if not isinstance(discovery, dict):
        discovery = {}
    phase_d = diagnostics_state.get('last_phase_d_dat_telemetry', {})
    if not isinstance(phase_d, dict):
        phase_d = {}

    manifest_rows = _safe_int(discovery.get('dat_manifest_rows_count'), 0)
    dat_selected = _safe_int(phase_d.get('dat_selected_count'), 0)
    blocked_stage = str(phase_d.get('post_medisoft_blocked_stage', '') or '').strip().lower()
    post_medisoft_status = 'exercised' if phase_d.get('post_medisoft_exercised') else 'not_exercised'

    report_run_id = str(diagnostics_state.get('last_shadow_pipeline_run_id', '') or '').strip()
    if report_run_id:
        shadow_payload = _load_json_dict(
            os.path.join(lab_root or '.', 'reports', 'shadow_run_report_{0}.json'.format(report_run_id))
        )
        if isinstance(shadow_payload, dict):
            if 'phase_b_dat_manifest_rows_count' in shadow_payload:
                manifest_rows = _safe_int(shadow_payload.get('phase_b_dat_manifest_rows_count'), manifest_rows)
            if 'phase_d_dat_selected_count' in shadow_payload:
                dat_selected = _safe_int(shadow_payload.get('phase_d_dat_selected_count'), dat_selected)
            payload_stage = str(shadow_payload.get('post_medisoft_blocked_stage', '') or '').strip().lower()
            if payload_stage:
                blocked_stage = payload_stage
            payload_status = str(shadow_payload.get('post_medisoft_status', '') or '').strip().lower()
            if payload_status:
                post_medisoft_status = payload_status

    if post_medisoft_status == 'blocked' and blocked_stage == 'phase_d' and manifest_rows > 0 and dat_selected == 0:
        issue_code = 'QA_DROP_SPIKE_REPLY_REQUIRED'
        return {
            'reply_required': True,
            'issue_key': issue_code,
            'issue_code': issue_code,
        }

    return {'reply_required': False, 'issue_key': '', 'issue_code': ''}



def compute_operator_support_send_recommendation_core(
        repo_root,
        evaluation_snapshot,
        ok_snap,
        snap_msg,
        pipeline_running,
        recommendation_source_scope='latest_live_snapshot',
        recommendation_anchor_run_id='',
        recommendation_live_run_id='',
        recommendation_live_run_status='',
        provenance_extra_lines=None):
    """
    Shared recommendation computation for an explicit artifact evaluation snapshot + live context.
    """
    lab_root = resolve_lab_root(repo_root)
    pipeline_label = 'running' if pipeline_running else 'idle'
    phase_f_lines = _build_phase_f_lock_context_lines(lab_root)
    phase_f_lock_note = phase_f_lines[0] if phase_f_lines else ''

    snap = evaluation_snapshot if isinstance(evaluation_snapshot, dict) else {}
    nearest_complete = str(snap.get('nearest_complete_run_id', '') or '').strip()
    eval_run_id = str(snap.get('run_id', '') or '').strip()
    artifact_why = []
    preferred_when_stable = _preferred_when_stable_from_snapshot(
        ok_snap, snap, snap_msg, nearest_complete, artifact_why)

    why_lines = []
    if eval_run_id:
        why_lines.append('Evaluated artifact run_id={0}.'.format(eval_run_id))
    why_lines.extend(artifact_why)
    if pipeline_running:
        why_lines.append('Shadow pipeline is running; bundle contents may still be changing.')
    if phase_f_lock_note:
        why_lines.append(phase_f_lock_note)
    if isinstance(provenance_extra_lines, list):
        for line in provenance_extra_lines:
            msg = str(line or '').strip()
            if msg:
                why_lines.append(msg)

    if preferred_when_stable == 'run_evidence' and pipeline_running:
        best_now_send = 'system_health'
    else:
        best_now_send = preferred_when_stable

    if pipeline_running and preferred_when_stable == 'run_evidence':
        why_summary = (
            'Pipeline is still active; a broad System Health Pack is safer now; '
            'send run evidence after the pipeline idles.')
    elif pipeline_running:
        why_summary = 'Pipeline is still active; waiting does not change the recommended bundle type.'
    elif preferred_when_stable == 'run_evidence':
        why_summary = 'Run evidence quality supports sending the coherent B..F bundle.'
    else:
        why_summary = 'Use System Health Pack for broad lab context and migration audit.'

    summary_map = {
        'run_evidence': 'Recommended: send latest run evidence bundle (phases B..F).',
        'system_health': 'Recommended: send latest System Health Pack.',
    }
    summary_line = summary_map.get(preferred_when_stable, summary_map['system_health'])

    bundle_quality = None
    if ok_snap:
        bundle_quality = _artifact_bundle_quality(snap)

    action_payload = {
        'recommended_action_kind': 'send_bundle',
        'preferred_when_stable_action_kind': 'send_bundle',
        'best_now_action_kind': 'send_bundle',
        'recommended_report_kind': 'system_health_pack' if best_now_send == 'system_health' else 'artifact_triage_pack',
        'recommended_artifact_classes': [],
        'action_requires_confirmation': False,
        'action_preview': {},
        'action_reason_lines': [],
        'recommendation_source_scope': str(recommendation_source_scope or 'latest_live_snapshot'),
        'recommendation_anchor_run_id': str(recommendation_anchor_run_id or '').strip(),
        'recommendation_live_run_id': str(recommendation_live_run_id or '').strip(),
        'recommendation_live_run_status': str(recommendation_live_run_status or '').strip(),
        'historical_reprocess_evaluated': False,
        'historical_reprocess_available': False,
        'historical_reprocess_not_triggered_reason': '',
        'dat_smoke_evaluated': False,
        'dat_smoke_available': False,
        'dat_smoke_not_triggered_reason': '',
        'dat_smoke_state_path': '',
        'dat_smoke_last_status': '',
        'dat_smoke_last_report_path': '',
        'dat_smoke_last_assessment': '',
        'dat_smoke_cooldown_until_utc': '',
        'dat_smoke_deferred_path': '',
        'dat_smoke_deferred_reason': '',
        'dat_smoke_deferred_anchor_run_id': '',
        'dat_smoke_deferred_context_run_id': '',
        'dat_smoke_deferred_issue_code': '',
        'follow_on_action_kind': '',
        'follow_on_report_kind': '',
        'follow_on_artifact_classes': [],
        'follow_on_requires_confirmation': False,
        'follow_on_summary_line': '',
        'reply_required_for_unblock': False,
        'reply_required_issue_code': '',
        'reply_required_issue_key': '',
    }

    hist_candidate, hist_skip = _build_historical_phase_d_reprocess_recommendation(
        repo_root, snap, bundle_quality, pipeline_running)
    dat_candidate, dat_skip = _build_phase_d_dat_smoke_recommendation(
        repo_root, snap, pipeline_running
    )
    action_payload['historical_reprocess_evaluated'] = bool(hist_candidate) or bool(str(hist_skip or '').strip())
    action_payload['historical_reprocess_available'] = bool(hist_candidate)
    action_payload['historical_reprocess_not_triggered_reason'] = str(hist_skip or '')
    action_payload['dat_smoke_evaluated'] = bool(dat_candidate) or bool(str(dat_skip or '').strip())
    action_payload['dat_smoke_available'] = bool(dat_candidate)
    action_payload['dat_smoke_not_triggered_reason'] = str(dat_skip or '')

    try:
        smoke_state = read_phase_d_dat_smoke_state(repo_root)
    except Exception:
        smoke_state = {}
    if not isinstance(smoke_state, dict):
        smoke_state = {}
    action_payload['dat_smoke_state_path'] = phase_d_dat_smoke_state_path(repo_root)
    action_payload['dat_smoke_last_status'] = str(smoke_state.get('last_status', '') or '').strip()
    action_payload['dat_smoke_last_report_path'] = str(smoke_state.get('last_report_path', '') or '').strip()
    action_payload['dat_smoke_last_assessment'] = str(smoke_state.get('last_assessment', '') or '').strip()
    action_payload['dat_smoke_cooldown_until_utc'] = str(smoke_state.get('cooldown_until_utc', '') or '').strip()

    qa_full_block_candidate, qa_full_block_skip = _build_phase_d_dat_qa_full_block_recommendation(
        repo_root, snap, smoke_state, pipeline_running)
    action_payload['dat_qa_full_block_evaluated'] = bool(qa_full_block_candidate) or bool(str(qa_full_block_skip or '').strip())
    action_payload['dat_qa_full_block_available'] = bool(qa_full_block_candidate)
    action_payload['dat_qa_full_block_not_triggered_reason'] = str(qa_full_block_skip or '')

    try:
        deferred_smoke = read_operator_deferred_phase_d_dat_smoke(repo_root)
    except Exception:
        deferred_smoke = None
    if not isinstance(deferred_smoke, dict):
        deferred_smoke = {}
    if deferred_smoke:
        action_payload['dat_smoke_deferred_path'] = operator_deferred_phase_d_dat_smoke_path(repo_root)
        action_payload['dat_smoke_deferred_reason'] = str(deferred_smoke.get('reason', '') or '').strip()
        action_payload['dat_smoke_deferred_anchor_run_id'] = str(deferred_smoke.get('anchor_run_id', '') or '').strip()
        action_payload['dat_smoke_deferred_context_run_id'] = str(deferred_smoke.get('context_run_id', '') or '').strip()
        action_payload['dat_smoke_deferred_issue_code'] = str(deferred_smoke.get('issue_code', '') or '').strip()

    reply_ctx = _qa_drop_spike_reply_context(lab_root)
    action_payload['live_operator_unblock'] = {
        'reply_required': bool(reply_ctx.get('reply_required')),
        'reply_required_issue_key': str(reply_ctx.get('issue_key', '') or ''),
        'reply_required_issue_code': str(reply_ctx.get('issue_code', '') or ''),
    }
    reply_append = []
    if reply_ctx.get('reply_required'):
        action_payload['reply_required_for_unblock'] = True
        action_payload['reply_required_issue_code'] = str(reply_ctx.get('issue_code', '') or '')
        action_payload['reply_required_issue_key'] = str(reply_ctx.get('issue_key', '') or '')
        reply_append.append(
            'Reply required to unblock QA drop spike follow-up: acknowledge {0} and include remediation status in the support send.'.format(
                action_payload['reply_required_issue_code']
            )
        )

    chosen_candidate = None
    chosen_mode = ''
    if qa_full_block_candidate:
        chosen_candidate = qa_full_block_candidate
        chosen_mode = 'dat_qa_full_block'
    elif dat_candidate:
        chosen_candidate = dat_candidate
        chosen_mode = 'dat_smoke'
        if hist_candidate:
            hist_classes = hist_candidate.get('recommended_artifact_classes', []) if isinstance(hist_candidate.get('recommended_artifact_classes', []), list) else []
            hist_label = ', '.join([str(item) for item in hist_classes if str(item or '').strip()]) or 'historical artifacts'
            action_payload['follow_on_action_kind'] = str(hist_candidate.get('recommended_action_kind', '') or 'historical_phase_d_reprocess')
            action_payload['follow_on_report_kind'] = str(hist_candidate.get('recommended_report_kind', '') or 'artifact_triage_pack')
            action_payload['follow_on_artifact_classes'] = hist_classes
            action_payload['follow_on_requires_confirmation'] = bool(hist_candidate.get('action_requires_confirmation'))
            action_payload['follow_on_summary_line'] = 'Follow-on after DAT smoke: re-evaluate historical Phase D rejects for {0}.'.format(hist_label)
    elif hist_candidate:
        chosen_candidate = hist_candidate
        chosen_mode = 'historical'

    if chosen_candidate:
        action_payload.update(chosen_candidate)
        base_reason_lines = list(chosen_candidate.get('action_reason_lines') or [])
        follow_on_summary = str(action_payload.get('follow_on_summary_line', '') or '').strip()
        if follow_on_summary:
            base_reason_lines.append(follow_on_summary)
        action_payload['action_reason_lines'] = base_reason_lines + reply_append
        why_lines.extend(base_reason_lines)
        if chosen_mode == 'dat_smoke':
            if pipeline_running:
                why_summary = 'Pipeline is still active; queue DAT smoke and auto-run it when pipeline is idle.'
                summary_line = 'Recommended after stable: run Phase D DAT smoke for anchored DAT-lane verification.'
            else:
                why_summary = 'Anchored run indicates DAT discovery but no truthful DAT-lane exercise; run DAT smoke for focused verification.'
                summary_line = 'Recommended: run Phase D DAT smoke for anchored DAT-lane verification.'
        elif chosen_mode == 'dat_qa_full_block':
            if pipeline_running:
                why_summary = 'Pipeline is still active; wait for idle, then review the anchored DAT QA full-block evidence.'
                summary_line = 'Recommended after stable: review DAT QA full-block evidence for the anchored run.'
            else:
                why_summary = 'DAT smoke or anchored telemetry shows the DAT lane is exercised and fully QA-blocked; review the QA evidence before choosing what to send.'
                summary_line = 'Recommended: review DAT QA full-block evidence for the anchored run.'
        else:
            classes = chosen_candidate.get('recommended_artifact_classes', []) if isinstance(chosen_candidate.get('recommended_artifact_classes', []), list) else []
            class_label = ', '.join([str(item) for item in classes if str(item or '').strip()]) or 'historical artifacts'
            if pipeline_running:
                why_summary = 'Pipeline is still active; wait for idle, then re-evaluate historical Phase D rejects under the current QA logic.'
                summary_line = 'Recommended after stable: re-evaluate historical Phase D rejects for {0}.'.format(class_label)
            else:
                why_summary = 'The evaluated run is duplicate-dominant and Phase D is not selecting historical rejects; re-evaluate those rejects under current QA logic.'
                summary_line = 'Recommended: re-evaluate historical Phase D rejects for {0}.'.format(class_label)
    elif reply_append:
        action_payload['action_reason_lines'] = reply_append

    milestone_verdict = ''
    milestone_reason = ''
    anchored_milestone_run_id = str(recommendation_anchor_run_id or '').strip()
    shadow_milestone, shadow_path = _load_phase_summary_from_snapshot(snap, 'F', prefix='shadow_run_report_')
    d_summary_for_milestone, _d_path_milestone = _load_phase_summary_from_snapshot(
        snap, 'D', prefix='qa_canonical_summary_'
    )
    if not isinstance(shadow_milestone, dict):
        shadow_milestone = {}
    if not isinstance(d_summary_for_milestone, dict):
        d_summary_for_milestone = {}
    shadow_missing = not str(shadow_path or '').strip()

    derive_verdict = None
    strict_gate_for_missing = None
    strict_gate_from_payload = None
    verdict_milestone_ready = None
    try:
        from scripts.unified_model.phase_d_milestone_gate import (
            VERDICT_MILESTONE_READY,
            derive_strict_milestone_verdict,
            strict_gate_for_missing_shadow_report,
            strict_gate_from_shadow_payload,
        )
        derive_verdict = derive_strict_milestone_verdict
        strict_gate_for_missing = strict_gate_for_missing_shadow_report
        strict_gate_from_payload = strict_gate_from_shadow_payload
        verdict_milestone_ready = VERDICT_MILESTONE_READY
    except Exception:
        try:
            from phase_d_milestone_gate import (
                VERDICT_MILESTONE_READY,
                derive_strict_milestone_verdict,
                strict_gate_for_missing_shadow_report,
                strict_gate_from_shadow_payload,
            )
            derive_verdict = derive_strict_milestone_verdict
            strict_gate_for_missing = strict_gate_for_missing_shadow_report
            strict_gate_from_payload = strict_gate_from_shadow_payload
            verdict_milestone_ready = VERDICT_MILESTONE_READY
        except Exception:
            pass

    if derive_verdict and strict_gate_for_missing and strict_gate_from_payload and verdict_milestone_ready is not None:
        try:
            if shadow_missing:
                strict_gate = strict_gate_for_missing()
            else:
                sp = dict(shadow_milestone) if isinstance(shadow_milestone, dict) else {}
                strict_gate = strict_gate_from_payload(
                    sp, lab_root=lab_root, run_id=anchored_milestone_run_id or None
                )
            milestone_verdict = derive_verdict(strict_gate, d_summary_for_milestone)
            if milestone_verdict == verdict_milestone_ready:
                milestone_reason = 'milestone criteria met for DAT lane'
            else:
                reasons = list(strict_gate.get('reasons') or [])
                detail = str(strict_gate.get('detail') or '')
                milestone_reason = '; '.join(reasons) if reasons else detail
        except Exception:
            milestone_verdict = ''
            milestone_reason = ''
    action_payload['milestone_verdict'] = milestone_verdict
    action_payload['strict_milestone_verdict'] = milestone_verdict
    action_payload['milestone_reason'] = milestone_reason
    action_payload['anchored_milestone_run_id'] = anchored_milestone_run_id

    out = {
        'primary_send': preferred_when_stable,
        'preferred_when_stable': preferred_when_stable,
        'best_now_send': best_now_send,
        'summary_line': summary_line,
        'why_lines': why_lines,
        'why_summary': why_summary,
        'pipeline_label': pipeline_label,
        'pipeline_running': pipeline_running,
        'phase_f_lock_note': phase_f_lock_note,
        'bundle_quality': bundle_quality,
        'nearest_complete_run_id': nearest_complete,
        'run_id': eval_run_id,
    }
    out.update(action_payload)
    # Phase D resolver classification is anchored on completed-run telemetry mirrored in diagnostics;
    # cloud_health_alert_state is delivery-dedupe only and must not override issue_code here.
    try:
        diag = _load_json_dict(os.path.join(lab_root, 'diagnostics_state.json'))
        rem = diag.get('phase_d_remediation') if isinstance(diag.get('phase_d_remediation'), dict) else {}
        if rem:
            out['phase_d_remediation'] = rem
            why_lines.extend(_artifact_tools.format_phase_d_remediation_surfaces(rem))
            out['why_lines'] = why_lines
    except Exception:
        pass
    return out


def compute_operator_support_send_recommendation(repo_root, env_flag_fn=None):
    """
    Operator UX: view model for the next recommended action plus bundle choice.
    Returns legacy send fields for compatibility and richer action fields for embedded remediation flows.
    Uses the same anchored evaluation snapshot selection as System Health Pack / triage when resolvable.
    """
    lab_root = resolve_lab_root(repo_root)
    pipeline_running = is_pipeline_running(lab_root)
    state = _load_json_dict(os.path.join(lab_root, 'diagnostics_state.json'))
    env_fn = env_flag_fn if env_flag_fn is not None else _default_env_flag
    pack_context = {}
    try:
        artifacts = _collect_system_health_artifacts(repo_root, env_fn, include_delivery_status=False)
        if isinstance(artifacts, dict):
            artifacts['repo_root'] = repo_root
        reports_dir = artifacts.get('reports_dir', os.path.join(lab_root, 'reports'))
        pack_context = _build_system_health_pack_context(lab_root, reports_dir, artifacts)
    except Exception:
        pack_context = {}
    try:
        ok_sel, msg_sel, eval_snap, rec_meta = _select_evaluation_snapshot_for_recommendation(
            repo_root, pack_context)
    except Exception:
        ok_sel, msg_sel, eval_snap, rec_meta = False, '', {}, {}
    if not isinstance(eval_snap, dict):
        eval_snap = {}
    if not isinstance(rec_meta, dict):
        rec_meta = {}
    live_status = _derive_live_pipeline_status(state, pipeline_running)
    live_id = str(rec_meta.get('live_run_id', '') or '').strip()
    prov = []
    fn = rec_meta.get('fallback_note')
    if fn:
        prov.append(fn)
    nn = rec_meta.get('newer_live_context_note')
    if nn:
        prov.append(nn)
    return compute_operator_support_send_recommendation_core(
        repo_root,
        eval_snap,
        ok_sel,
        msg_sel,
        pipeline_running,
        recommendation_source_scope=str(rec_meta.get('recommendation_source_scope', '') or 'latest_live_snapshot'),
        recommendation_anchor_run_id=str(rec_meta.get('recommendation_anchor_run_id', '') or ''),
        recommendation_live_run_id=live_id,
        recommendation_live_run_status=live_status,
        provenance_extra_lines=prov or None,
    )


def run_pipeline(repo_root, python_exe, env, env_flag_fn):
    """
    When shadow_auto=1: spawn run_shadow_pipeline.py (non-blocking).
    When shadow_auto=0: Phase A blocks (subprocess.call), then B/C/D spawn via Popen.
    Env from os.environ.copy() + overlay MEDICAFE_LAB_DIR, target_folder, source_folder.
    """
    try:
        orchestration = shadow_orchestrator.start_or_attach_shadow_pipeline(
            action_id=shadow_orchestrator.ACTION_STARTUP,
            entrypoint=shadow_orchestrator.ENTRYPOINT_STARTUP,
            repo_root=repo_root,
            python_exe=python_exe,
            env=env,
            env_flag_fn=env_flag_fn,
            ops=_orchestrator_ops(),
        )
        ok, msg, data = _coerce_orchestrator_result_to_legacy(orchestration)
        if not ok:
            _maybe_send_orchestrator_failure_report(
                repo_root=repo_root,
                lab_root=resolve_lab_root(repo_root),
                orchestration_result=orchestration,
                trigger='run_pipeline_startup',
            )
        return (ok, msg, data)
    except Exception as e:
        return (False, str(e), None)


def _find_latest_run_id_by_prefix(reports_dir, prefix, suffix_choices):
    """
    Find latest file by prefix (mtime). Parse run_id from filename.
    Returns (run_id, path) or (None, None).
    Filename pattern: {prefix}{run_id}.{ext}
    """
    if not reports_dir or not os.path.exists(reports_dir):
        return (None, None)
    try:
        items = os.listdir(reports_dir)
    except (IOError, OSError):
        return (None, None)
    candidates = []
    prefix_len = len(prefix)
    for item in items:
        if not item.startswith(prefix):
            continue
        for suf in suffix_choices:
            if item.endswith(suf):
                path = os.path.join(reports_dir, item)
                if os.path.isfile(path):
                    rest = item[prefix_len:]
                    if '.' in rest:
                        run_id = rest.rsplit('.', 1)[0]
                    else:
                        run_id = rest
                    if run_id and len(run_id) >= 17 and '-' in run_id:
                        candidates.append((run_id, path))
                break
    if not candidates:
        return (None, None)
    try:
        return max(candidates, key=lambda x: os.path.getmtime(x[1]))
    except (IOError, OSError, ValueError):
        return (None, None)


def _preferred_evidence_run_id(lab_root, reports_dir):
    state = _load_json_dict(os.path.join(lab_root or '.', 'diagnostics_state.json'))
    if not isinstance(state, dict):
        state = {}
    pipeline_running = is_pipeline_running(lab_root)
    try:
        return _artifact_tools.prefer_diagnostics_run_id(
            reports_dir,
            state,
            pipeline_running,
            run_has_required_artifacts_fn=_run_has_required_artifacts,
        )
    except Exception:
        return ''


def _reports_dir_access_error(lab_root):
    """Return readable error string when reports dir exists but is unreadable; else None."""
    reports_dir = os.path.join(lab_root, 'reports')
    if not reports_dir or not os.path.exists(reports_dir):
        return None
    try:
        os.listdir(reports_dir)
    except (IOError, OSError) as e:
        return 'Unable to read reports directory: {0}'.format(e)
    return None


def _select_latest_evidence_files(lab_root, prefix_specs, prefer_diagnostics_lineage=False):
    """
    Select latest coherent run's evidence files per prefix_specs.
    prefix_specs: [(prefix, suffix), ...] where suffix is None for (.txt, .json) or e.g. '.jsonl'.
    Returns [(basename, fullpath), ...].
    """
    reports_dir = os.path.join(lab_root, 'reports')
    if not reports_dir or not os.path.exists(reports_dir):
        return []
    if not prefix_specs:
        return []
    primary_prefix, primary_suffix = prefix_specs[0]
    suffix_choices = ('.txt', '.json') if primary_suffix is None else (primary_suffix,)
    run_id = ''
    if prefer_diagnostics_lineage:
        run_id = _preferred_evidence_run_id(lab_root, reports_dir)
    if run_id:
        candidate_path = ''
        for suffix in suffix_choices:
            path = os.path.join(reports_dir, '{0}{1}{2}'.format(primary_prefix, run_id, suffix))
            if os.path.isfile(path):
                candidate_path = path
                break
        if not candidate_path:
            run_id = ''
    if not run_id:
        run_id, _ = _find_latest_run_id_by_prefix(reports_dir, primary_prefix, suffix_choices)
    if not run_id:
        return []
    extra_files = []
    seen = set()
    for prefix, suffix in prefix_specs:
        if suffix is None:
            group = {'prefix': prefix, 'suffixes': ('.json', '.txt')}
            for path in _collect_group_paths_for_run(reports_dir, run_id, group):
                basename = os.path.basename(path)
                if basename not in seen:
                    extra_files.append((basename, path))
                    seen.add(basename)
        else:
            basename = prefix + run_id + suffix
            path = os.path.join(reports_dir, basename)
            if os.path.isfile(path) and basename not in seen:
                extra_files.append((basename, path))
                seen.add(basename)
    return extra_files


def _find_latest_by_prefix(reports_dir, prefix, suffix_choices):
    """Find latest file by prefix. Returns (path, None) or (None, message)."""
    if not reports_dir or not os.path.exists(reports_dir):
        return (None, 'No reports directory: {0}'.format(reports_dir))
    try:
        items = os.listdir(reports_dir)
    except (IOError, OSError) as e:
        return (None, 'Unable to read reports directory: {0}'.format(e))
    candidates = []
    for item in items:
        if item.startswith(prefix):
            for suf in suffix_choices:
                if item.endswith(suf):
                    path = os.path.join(reports_dir, item)
                    if os.path.isfile(path):
                        candidates.append(path)
                    break
    if not candidates:
        return (None, None)
    try:
        return (max(candidates, key=os.path.getmtime), None)
    except (IOError, OSError, ValueError):
        return (None, 'Unable to resolve latest report file.')


def _shadow_run_report_run_id_from_path(path):
    """Extract shadow pipeline run_id from a shadow_run_report path."""
    if not path:
        return ''
    base = os.path.basename(str(path))
    if not base.startswith('shadow_run_report_'):
        return ''
    tail = base[len('shadow_run_report_'):]
    for suffix in ('.json', '.txt'):
        if tail.endswith(suffix):
            return tail[:-len(suffix)]
    return ''


def open_phase_b_summary(repo_root):
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    path, msg = _find_latest_by_prefix(reports_dir, 'artifact_discovery_summary_', ('.txt', '.json'))
    if path:
        return (True, '', path)
    if msg:
        return (False, msg, None)
    return (False, 'No artifact discovery summaries found.', None)


def open_manifest_location(repo_root):
    """Return manifest file path for explorer /select. Launcher opens explorer, not viewer."""
    lab_root = resolve_lab_root(repo_root)
    cursor_path = os.path.join(lab_root, 'run_cursor.json')
    manifest_path = None
    if os.path.exists(cursor_path):
        try:
            with open(cursor_path, 'r', encoding='utf-8') as f:
                cursor = json.load(f)
            manifest_path = cursor.get('last_manifest_path')
        except (IOError, OSError, ValueError):
            pass
    if not manifest_path or not os.path.exists(manifest_path):
        reports_dir = os.path.join(lab_root, 'reports')
        if os.path.exists(reports_dir):
            try:
                report_items = os.listdir(reports_dir)
            except (IOError, OSError) as e:
                return (False, 'Unable to read reports directory: {0}'.format(e), None)
            manifests = [
                os.path.join(reports_dir, x) for x in report_items
                if x.startswith('artifact_manifest_') and x.endswith('.jsonl')
                and os.path.isfile(os.path.join(reports_dir, x))
            ]
            if manifests:
                try:
                    manifest_path = max(manifests, key=os.path.getmtime)
                except (IOError, OSError, ValueError):
                    return (False, 'Unable to resolve latest manifest file.', None)
    if manifest_path and os.path.exists(manifest_path):
        return (True, '', manifest_path)
    return (False, 'No manifest found. Run discovery from Cloud Readiness first.', None)


def _resolve_unified_model_script(repo_root, python_exe, script_name):
    script_repo_root, script_path, script_checks = shadow_orchestrator._find_unified_model_script(
        repo_root, script_name, python_exe=python_exe
    )
    if os.path.exists(script_path):
        return (True, '', script_repo_root, script_path, script_checks)
    checked_paths = [c.get('script_path', '') for c in script_checks if c.get('script_path')]
    detail = ', '.join(checked_paths) if checked_paths else script_path
    msg = '{0} not found. checked: {1}'.format(script_name, detail)
    _log_health('WARNING', 'Cloud Readiness script resolution failure: {0}'.format(msg))
    return (False, msg, script_repo_root, script_path, script_checks)


def run_phase_b_manual(repo_root, python_exe, env):
    ok_script, script_msg, script_repo_root, script, _ = _resolve_unified_model_script(
        repo_root, python_exe, 'discover_artifacts.py'
    )
    if not ok_script:
        return (False, script_msg, None)
    try:
        lab_root = resolve_lab_root(repo_root)
        proc_env = os.environ.copy()
        proc_env['MEDICAFE_LAB_DIR'] = lab_root
        proc_env['target_folder'] = env.get('target_folder', '')
        proc_env['source_folder'] = env.get('source_folder', '')
        subprocess.Popen([python_exe, script], cwd=script_repo_root, env=proc_env)
        return (True, '', None)
    except Exception as e:
        return (False, str(e), None)


def _send_phase_evidence(lab_root, prefix_specs, extra_meta_key, no_attach_msg):
    """
    Send latest coherent run's evidence. prefix_specs: [(prefix, suffix), ...].
    Requires at least one phase artifact; context files are additive only.
    """
    if collect_support_bundle is None or submit_support_bundle_email is None:
        return (False, 'Support bundle tools unavailable.', None)
    reports_err = _reports_dir_access_error(lab_root)
    if reports_err:
        return (False, reports_err, None)
    phase_files = _select_latest_evidence_files(
        lab_root,
        prefix_specs,
        prefer_diagnostics_lineage=False,
    )
    if not phase_files:
        return (False, no_attach_msg, None)
    extra_files = list(phase_files)
    for ctx_name in ('diagnostics_state.json', 'run_cursor.json'):
        ctx_path = os.path.join(lab_root, ctx_name)
        if os.path.isfile(ctx_path):
            extra_files.append((ctx_name, ctx_path))
    try:
        delivery_preflight = _collect_delivery_diagnostics()
        zip_path = collect_support_bundle(
            include_traceback=False,
            extra_meta={
                extra_meta_key: True,
                'send_source': 'manual_{0}'.format(extra_meta_key),
                'lab_root': lab_root,
                'email_delivery_preflight': delivery_preflight,
            },
            extra_files=extra_files,
        )
        if not zip_path:
            return (False, 'Failed to create support bundle.', None)
        ok, msg, _ = _submit_bundle_with_delivery_diagnostics(
            zip_path=zip_path,
            allow_interactive_reauth=True,
        )
        return (ok, msg, None)
    except Exception as e:
        return (False, 'Error: {0}'.format(e), None)


def send_phase_b_evidence(repo_root):
    lab_root = resolve_lab_root(repo_root)
    return _send_phase_evidence(
        lab_root,
        [('artifact_discovery_summary_', None)],
        'phase_b_evidence',
        'No discovery summaries to attach.',
    )


def open_phase_c_summary(repo_root):
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    path, msg = _find_latest_by_prefix(reports_dir, 'ingest_write_summary_', ('.txt', '.json'))
    if path:
        return (True, '', path)
    if msg:
        return (False, msg, None)
    return (False, 'No Phase C ingest summaries found.', None)


def run_phase_c_manual(repo_root, python_exe, env):
    ok_script, script_msg, script_repo_root, script, _ = _resolve_unified_model_script(
        repo_root, python_exe, 'ingest_from_manifest.py'
    )
    if not ok_script:
        return (False, script_msg, None)
    try:
        lab_root = resolve_lab_root(repo_root)
        proc_env = os.environ.copy()
        proc_env['MEDICAFE_LAB_DIR'] = lab_root
        subprocess.Popen([python_exe, script], cwd=script_repo_root, env=proc_env)
        return (True, '', None)
    except Exception as e:
        return (False, str(e), None)


def send_phase_c_evidence(repo_root):
    lab_root = resolve_lab_root(repo_root)
    return _send_phase_evidence(
        lab_root,
        [('ingest_write_summary_', None), ('ingest_write_anomalies_', '.jsonl')],
        'phase_c_evidence',
        'No Phase C summaries or anomalies to attach.',
    )


def open_phase_d_summary(repo_root):
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    path, msg = _find_latest_by_prefix(reports_dir, 'qa_canonical_summary_', ('.txt', '.json'))
    if path:
        return (True, '', path)
    if msg:
        return (False, msg, None)
    return (False, 'No Phase D summaries found.', None)


def open_phase_d_reject_sample(repo_root):
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    path, msg = _find_latest_by_prefix(reports_dir, 'qa_reject_samples_', ('.jsonl',))
    if path:
        return (True, '', path)
    if msg:
        return (False, msg, None)
    return (False, 'No Phase D reject sample files found.', None)


def run_phase_d_manual(repo_root, python_exe, env, artifact_classes=None):
    ok_script, script_msg, script_repo_root, script, _ = _resolve_unified_model_script(
        repo_root, python_exe, 'run_qa_canonical.py'
    )
    if not ok_script:
        return (False, script_msg, None)
    try:
        lab_root = resolve_lab_root(repo_root)
        proc_env = os.environ.copy()
        proc_env['MEDICAFE_LAB_DIR'] = lab_root
        classes = _normalize_phase_d_reprocess_classes(artifact_classes)
        if classes:
            proc_env['MEDICAFE_PHASE_D_ARTIFACT_CLASSES'] = ','.join(classes)
        subprocess.Popen([python_exe, script], cwd=script_repo_root, env=proc_env)
        return (True, '', None)
    except Exception as e:
        return (False, str(e), None)


def run_phase_d_dat_smoke(
        repo_root,
        python_exe,
        env,
        reference_phase_d_summary_path=None,
        recommendation_anchor_run_id='',
        recommendation_context_run_id='',
        recommendation_issue_code=''):
    """
    Run scripts/unified_model/run_phase_d_dat_smoke.py against repo_root/phase_d_dat_smoke_lab (background).
    Diagnostic only; does not close QA milestone. Reports: reports/phase_d_dat_smoke_report_<anchor>.txt

    Returns (ok, message, meta).
    """
    ok_script, script_msg, script_repo_root, script, _ = _resolve_unified_model_script(
        repo_root, python_exe, 'run_phase_d_dat_smoke.py'
    )
    if not ok_script:
        return (False, script_msg, None)
    requested_anchor = ''
    requested_context = ''
    requested_issue = ''
    try:
        smoke_lab = os.path.join(repo_root, 'phase_d_dat_smoke_lab')
        if is_pipeline_running(smoke_lab):
            return (False, 'DAT smoke already running for phase_d_dat_smoke_lab.', {'already_running': True})
        requested_anchor = str(recommendation_anchor_run_id or '').strip()
        requested_context = str(recommendation_context_run_id or '').strip()
        requested_issue = str(recommendation_issue_code or '').strip()
        now_utc = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
        update_phase_d_dat_smoke_state(
            repo_root,
            anchor_run_id=requested_anchor,
            context_run_id=requested_context,
            issue_code=requested_issue,
            started_at_utc=now_utc,
            status='started',
        )
        state_path = phase_d_dat_smoke_state_path(repo_root)
        proc_env = os.environ.copy()
        if env:
            proc_env.update(env)
        proc_env['MEDICAFE_LAB_DIR'] = smoke_lab
        args = [python_exe, script, '--lab-dir', smoke_lab, '--state-path', state_path]
        ref_path = str(reference_phase_d_summary_path or '').strip()
        if ref_path:
            args.extend(['--reference-phase-d-summary', ref_path])
        if requested_anchor:
            args.extend(['--requested-anchor-run-id', requested_anchor])
        if requested_context:
            args.extend(['--requested-context-run-id', requested_context])
        if requested_issue:
            args.extend(['--requested-issue-code', requested_issue])
        subprocess.Popen(
            args,
            cwd=script_repo_root,
            env=proc_env,
        )
        return (True, '', {
            'async_launch': True,
            'reference_phase_d_summary_path': ref_path,
            'requested_anchor_run_id': requested_anchor,
            'requested_context_run_id': requested_context,
            'requested_issue_code': requested_issue,
        })
    except Exception as e:
        try:
            now_utc = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
            st = read_phase_d_dat_smoke_state(repo_root)
            st['last_requested_anchor_run_id'] = str(requested_anchor or '').strip()
            st['last_requested_context_run_id'] = str(requested_context or '').strip()
            st['last_remediation_issue_code'] = str(requested_issue or '').strip()
            st['last_finished_at_utc'] = now_utc
            st['last_status'] = 'failed'
            st['last_report_path'] = ''
            st['last_assessment'] = 'spawn_failed'
            st['cooldown_until_utc'] = ''
            write_phase_d_dat_smoke_state(repo_root, st)
        except Exception:
            pass
        return (False, str(e), None)


def preview_historical_phase_d_reprocess(repo_root, artifact_classes=None, remediation_context_run_id=None):
    if _preview_historical_phase_d_reprocess_impl is None:
        return (False, 'Historical Phase D re-evaluation helper unavailable.', None)
    lab_root = resolve_lab_root(repo_root)
    data = _preview_historical_phase_d_reprocess_impl(
        lab_root,
        artifact_classes=artifact_classes,
        remediation_context_run_id=remediation_context_run_id,
    )
    ok = bool(isinstance(data, dict) and data.get('ok'))
    msg = '' if ok else str((data or {}).get('error', '') or 'Unable to build historical Phase D re-evaluation preview.')
    return (ok, msg, data)



def run_historical_phase_d_reprocess(repo_root, python_exe, env, artifact_classes=None, remediation_context_run_id=None):
    if _execute_historical_phase_d_reprocess_impl is None:
        return (False, 'Historical Phase D re-evaluation helper unavailable.', None)
    lab_root = resolve_lab_root(repo_root)
    data = _execute_historical_phase_d_reprocess_impl(
        lab_root,
        artifact_classes=artifact_classes,
        remediation_context_run_id=remediation_context_run_id,
    )
    if not isinstance(data, dict) or not data.get('ok'):
        msg = str((data or {}).get('error', '') or 'Unable to reset historical Phase D reject state.')
        return (False, msg, data)
    classes = _normalize_phase_d_reprocess_classes(data.get('targeted_artifact_classes', []))
    ok_run, msg_run, _ = run_phase_d_manual(repo_root, python_exe, env, artifact_classes=classes)
    if not ok_run:
        data['phase_d_launch_error'] = msg_run
        return (
            False,
            'Historical Phase D reject state was reset, but the filtered Phase D rerun could not be started: {0}'.format(msg_run),
            data,
        )
    msg = 'Historical Phase D re-evaluation started for {0}. Return to 1) Follow recommendation after the rerun settles.'.format(
        ', '.join(classes) or 'the targeted classes'
    )
    return (True, msg, data)


def send_phase_d_evidence(repo_root):
    lab_root = resolve_lab_root(repo_root)
    return _send_phase_evidence(
        lab_root,
        [('qa_canonical_summary_', None), ('qa_reject_samples_', '.jsonl')],
        'phase_d_evidence',
        'No Phase D summaries or reject samples to attach.',
    )


def open_phase_e_summary(repo_root):
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    path, msg = _find_latest_by_prefix(reports_dir, 'projection_parity_summary_', ('.txt', '.json'))
    if path:
        return (True, '', path)
    if msg:
        return (False, msg, None)
    return (False, 'No Phase E summaries found.', None)


def open_phase_e_deviation_samples(repo_root):
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    path, msg = _find_latest_by_prefix(reports_dir, 'projection_deviation_samples_', ('.jsonl',))
    if path:
        return (True, '', path)
    if msg:
        return (False, msg, None)
    return (False, 'No Phase E deviation sample files found.', None)


def run_phase_e_manual(repo_root, python_exe, env):
    ok_script, script_msg, script_repo_root, script, _ = _resolve_unified_model_script(
        repo_root, python_exe, 'run_projection_parity.py'
    )
    if not ok_script:
        return (False, script_msg, None)
    try:
        lab_root = resolve_lab_root(repo_root)
        proc_env = os.environ.copy()
        proc_env['MEDICAFE_LAB_DIR'] = lab_root
        subprocess.Popen([python_exe, script], cwd=script_repo_root, env=proc_env)
        return (True, '', None)
    except Exception as e:
        return (False, str(e), None)


def send_phase_e_evidence(repo_root):
    lab_root = resolve_lab_root(repo_root)
    return _send_phase_evidence(
        lab_root,
        [('projection_parity_summary_', None), ('projection_deviation_samples_', '.jsonl')],
        'phase_e_evidence',
        'No Phase E summaries or deviation samples to attach.',
    )


def run_shadow_pipeline(repo_root, python_exe, env):
    try:
        def _env_flag(name, default):
            raw = env.get(name)
            if raw is None:
                raw = os.environ.get(name)
            if raw is None:
                return default
            return str(raw).strip().lower() in ('1', 'true', 'yes', 'on', 'y')

        orchestration = shadow_orchestrator.start_or_attach_shadow_pipeline(
            action_id=shadow_orchestrator.ACTION_MANUAL_FULL_PIPELINE,
            entrypoint=shadow_orchestrator.ENTRYPOINT_MANUAL,
            repo_root=repo_root,
            python_exe=python_exe,
            env=env,
            env_flag_fn=_env_flag,
            ops=_orchestrator_ops(),
        )
        ok, msg, data = _coerce_orchestrator_result_to_legacy(orchestration)
        if not ok:
            _maybe_send_orchestrator_failure_report(
                repo_root=repo_root,
                lab_root=resolve_lab_root(repo_root),
                orchestration_result=orchestration,
                trigger='run_shadow_pipeline_manual',
            )
        return (ok, msg, data)
    except Exception as e:
        return (False, str(e), None)


def open_phase_f_shadow_report(repo_root):
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    path, msg = _find_latest_by_prefix(reports_dir, 'shadow_run_report_', ('.txt', '.json'))
    if path:
        return (True, '', path)
    if msg:
        return (False, msg, None)
    return (False, 'No Shadow Health reports found yet.', None)


def open_phase_f_evidence_index(repo_root):
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    path, msg = _find_latest_by_prefix(reports_dir, 'shadow_evidence_index_', ('.json',))
    if path:
        return (True, '', path)
    if msg:
        return (False, msg, None)
    return (False, 'No Phase F evidence indexes found.', None)


def run_phase_f_manual(repo_root, python_exe, env, pipeline_running=None):
    """
    Rebuild Phase F (latest-at-execution). Does not pass --pipeline-run-id.
    Returns (ok, msg, pipeline_running).
    """
    ok_script, script_msg, script_repo_root, script, _ = _resolve_unified_model_script(
        repo_root, python_exe, 'package_shadow_run_report.py'
    )
    if not ok_script:
        return (False, script_msg, None)
    try:
        def _env_flag(name, default):
            raw = env.get(name)
            if raw is None:
                raw = os.environ.get(name)
            if raw is None:
                return default
            return str(raw).strip().lower() in ('1', 'true', 'yes', 'on', 'y')

        ready_ok, ready_msg, _ = ensure_lab_ready(repo_root, python_exe, env, _env_flag)
        if not ready_ok:
            return (False, ready_msg or 'Phase A bootstrap failed.', None)

        lab_root = resolve_lab_root(repo_root)
        if pipeline_running is None:
            pipeline_running = is_pipeline_running(lab_root)
        proc_env = os.environ.copy()
        proc_env['MEDICAFE_LAB_DIR'] = lab_root
        cmd = [python_exe, script, '--auto-report', '0']
        subprocess.Popen(cmd, cwd=script_repo_root, env=proc_env, stdout=DEVNULL)
        return (True, '', pipeline_running)
    except Exception as e:
        return (False, str(e), None)


def run_phase_f_manual_for_run_id(repo_root, python_exe, env, run_id):
    """
    Rebuild Phase F for explicit run_id (strict). Always passes --pipeline-run-id.
    Does NOT read state. Returns (ok, msg, None).
    """
    ok_script, script_msg, script_repo_root, script, _ = _resolve_unified_model_script(
        repo_root, python_exe, 'package_shadow_run_report.py'
    )
    if not ok_script:
        return (False, script_msg, None)
    run_id = (run_id or '').strip()
    if not run_id:
        return (False, 'run_id is required.', None)
    try:
        def _env_flag(name, default):
            raw = env.get(name)
            if raw is None:
                raw = os.environ.get(name)
            if raw is None:
                return default
            return str(raw).strip().lower() in ('1', 'true', 'yes', 'on', 'y')

        ready_ok, ready_msg, _ = ensure_lab_ready(repo_root, python_exe, env, _env_flag)
        if not ready_ok:
            return (False, ready_msg or 'Phase A bootstrap failed.', None)

        lab_root = resolve_lab_root(repo_root)
        proc_env = os.environ.copy()
        proc_env['MEDICAFE_LAB_DIR'] = lab_root
        cmd = [python_exe, script, '--pipeline-run-id', run_id, '--auto-report', '0']
        subprocess.Popen(cmd, cwd=script_repo_root, env=proc_env, stdout=DEVNULL)
        return (True, '', None)
    except Exception as e:
        return (False, str(e), None)


def send_phase_f_evidence(repo_root):
    lab_root = resolve_lab_root(repo_root)
    no_attach_msg = 'No Shadow Health report/evidence files found to attach.'
    if collect_support_bundle is None or submit_support_bundle_email is None:
        return (False, 'Support bundle tools unavailable.', None)
    reports_err = _reports_dir_access_error(lab_root)
    if reports_err:
        return (False, reports_err, None)
    phase_files = _select_latest_evidence_files(lab_root, [
        ('shadow_run_report_', None),
        ('shadow_evidence_index_', '.json'),
        ('phase_f_mismatch_', '.txt'),
    ])
    if not phase_files:
        reports_dir = os.path.join(lab_root, 'reports')
        mismatch_path, _ = _find_latest_by_prefix(reports_dir, 'phase_f_mismatch_', ('.txt',))
        if mismatch_path:
            basename = os.path.basename(mismatch_path)
            phase_files = [(basename, mismatch_path)]
    if not phase_files:
        return (False, no_attach_msg, None)
    extra_files = list(phase_files)
    send_run_id = ''
    for _basename, _fullpath in phase_files:
        if str(_basename).startswith('shadow_run_report_'):
            send_run_id = _shadow_run_report_run_id_from_path(_fullpath)
            if send_run_id:
                break
    if not send_run_id:
        try:
            state = _load_json_dict(os.path.join(lab_root, 'diagnostics_state.json'))
            send_run_id = str(state.get('last_shadow_pipeline_run_id', '') or '').strip()
        except Exception:
            send_run_id = ''
    for ctx_name in ('diagnostics_state.json', 'run_cursor.json'):
        ctx_path = os.path.join(lab_root, ctx_name)
        if os.path.isfile(ctx_path):
            extra_files.append((ctx_name, ctx_path))
    try:
        delivery_preflight = _collect_delivery_diagnostics()
        zip_path = collect_support_bundle(
            include_traceback=False,
            extra_meta={
                'phase_f_evidence': True,
                'run_id': send_run_id,
                'send_source': 'manual_phase_f_evidence',
                'lab_root': lab_root,
                'email_delivery_preflight': delivery_preflight,
            },
            extra_files=extra_files,
        )
        if not zip_path:
            return (False, 'Failed to create support bundle.', None)
        ok, msg, _ = _submit_bundle_with_delivery_diagnostics(
            zip_path=zip_path,
            allow_interactive_reauth=True,
        )
        return (ok, msg, None)
    except Exception as e:
        return (False, 'Error: {0}'.format(e), None)


def open_report_delivery_status(repo_root):
    """
    Write and return a compact delivery-status snapshot for support bundle sends.
    Returns (ok, message, path).
    """
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    try:
        if reports_dir and not os.path.exists(reports_dir):
            os.makedirs(reports_dir, exist_ok=True)
        path = os.path.join(reports_dir, 'report_delivery_status.txt')
        lines = get_report_delivery_status_lines(lab_root)
        with open(path, 'w', encoding='utf-8') as f:
            f.write('\n'.join(lines) + '\n')
        return (True, '', path)
    except Exception as e:
        return (False, str(e), None)


def _parse_shadow_run_id_from_report_text(text):
    """Best-effort run_id from shadow_run_report*.txt body."""
    for line in (text or '').splitlines()[:48]:
        line = line.strip()
        if line.startswith('run_id:'):
            return line.split(':', 1)[1].strip()
    return ''


def _append_phase_f_report_appendix(content, reports_dir, lab_root):
    """Attach shadow_run_report for the current pipeline run_id when possible; avoid silent stale green."""
    state = _load_json_dict(os.path.join(lab_root, 'diagnostics_state.json'))
    expected_rid = str(state.get('last_shadow_pipeline_run_id', '') or '').strip()
    if not expected_rid:
        expected_rid = str(state.get('active_run_id', '') or '').strip()
    lock_diag = str(state.get('last_phase_f_lock_diag_path', '') or '').strip()
    failed_phase = str(state.get('last_shadow_pipeline_failed_phase', '') or '').strip().upper()
    err_code = str(state.get('last_shadow_pipeline_error_code', '') or '')
    phase_f_failed = failed_phase == 'F' or 'PHASE_F' in err_code

    def append_section(title, body):
        content[0] += '\n--- {0} ---\n'.format(title)
        content[0] += body

    preferred = ''
    if expected_rid:
        candidate = os.path.join(reports_dir, 'shadow_run_report_{0}.txt'.format(expected_rid))
        if os.path.isfile(candidate):
            preferred = candidate
    if preferred:
        try:
            with open(preferred, 'r', encoding='utf-8') as f:
                append_section('Phase F detailed report', f.read())
        except (IOError, OSError):
            pass
        return

    if expected_rid and phase_f_failed:
        stub = (
            'No shadow_run_report_{0}.txt found (Phase F likely failed before packaging). '.format(expected_rid)
        )
        if lock_diag:
            stub += 'Lock/evidence: {0}\n'.format(os.path.basename(lock_diag))
        else:
            stub += 'See diagnostics_state.json for Phase F error fields.\n'
        append_section('Phase F detailed report', stub)
        return

    # Latest .txt only; a single max(mtime) across .txt and .json drops the appendix when JSON is newer.
    shadow_path, _ = _find_latest_by_prefix(reports_dir, 'shadow_run_report_', ('.txt',))
    if shadow_path:
        try:
            with open(shadow_path, 'r', encoding='utf-8') as f:
                shadow_content = f.read()
            parsed_rid = _parse_shadow_run_id_from_report_text(shadow_content)
            banner = ''
            if expected_rid and parsed_rid and parsed_rid != expected_rid:
                banner = (
                    'WARNING: This appendix file is for run_id={0}; current pipeline context run_id={1}.\n\n'.format(
                        parsed_rid, expected_rid,
                    )
                )
            append_section('Phase F detailed report', banner + shadow_content)
        except (IOError, OSError):
            pass


def open_consolidated_health_report(repo_root, env_flag_fn):
    """
    Generate and return path to consolidated health report (all phases B-F).
    Writes Pipeline Health Snapshot to lab/reports/consolidated_health_snapshot.txt,
    appending shadow_run_report for the current run when possible.
    Returns (ok, message, path).
    """
    lab_root = resolve_lab_root(repo_root)
    lines = get_health_lines(lab_root, env_flag_fn)
    reports_dir = os.path.join(lab_root, 'reports')
    try:
        if reports_dir and not os.path.exists(reports_dir):
            os.makedirs(reports_dir, exist_ok=True)
        path = os.path.join(reports_dir, 'consolidated_health_snapshot.txt')
        content_holder = ['\n'.join(lines) + '\n']
        _append_phase_f_report_appendix(content_holder, reports_dir, lab_root)
        with open(path, 'w', encoding='utf-8') as f:
            f.write(content_holder[0])
        return (True, '', path)
    except Exception as e:
        return (False, str(e), None)


def _audit_script_path(repo_root, python_exe=None):
    ok_script, script_msg, script_repo_root, script_path, script_checks = _resolve_unified_model_script(
        repo_root, python_exe, 'audit_migration_health.py'
    )
    return {
        'ok': ok_script,
        'message': script_msg,
        'cwd': script_repo_root,
        'path': script_path,
        'checks': script_checks,
    }


def _extract_json_object_from_text(raw_text):
    """Best-effort JSON object extraction from mixed stdout text."""
    text = str(raw_text or '').strip()
    if not text:
        return {}
    # Fast path: entire payload is JSON.
    try:
        obj = json.loads(text)
        if isinstance(obj, dict):
            return obj
    except ValueError:
        pass
    # Fallback: parse line-by-line and return first JSON object line.
    for line in text.splitlines():
        line = line.strip()
        if not line or not line.startswith('{'):
            continue
        try:
            obj = json.loads(line)
            if isinstance(obj, dict):
                return obj
        except ValueError:
            continue
    return {}


def _deduplicate_audit_hint_lines(hints):
    """Drop duplicate hint lines (normalized by stripped text), preserve first occurrence order."""
    seen = set()
    deduped = []
    for line in hints:
        if not isinstance(line, str):
            continue
        key = line.strip()
        if not key or key in seen:
            continue
        seen.add(key)
        deduped.append(line)
    return deduped


def _audit_hint_lines_from_payload(payload):
    """Return compact operator hints from audit payload."""
    hints = []
    if not isinstance(payload, dict):
        return hints
    stage = str(payload.get('migration_stage', '') or '').strip().lower()
    overall = payload.get('overall', {}) if isinstance(payload.get('overall', {}), dict) else {}
    status = str(overall.get('status', '') or '').lower()
    score = overall.get('score', '?')
    exit_code = overall.get('exit_code', '?')
    hints.append('Migration audit: status={0}, score={1}, exit_code={2}'.format(status or 'unknown', score, exit_code))
    if stage:
        hints.append('Migration stage: {0}'.format(stage))
    gating = payload.get('gating', {}) if isinstance(payload.get('gating', {}), dict) else {}
    excluded = gating.get('excluded_surfaces', []) if isinstance(gating.get('excluded_surfaces', []), list) else []
    if 'cloud' in excluded:
        hints.append('Cloud surface is informational-only for this migration stage.')

    surfaces = payload.get('surfaces', {}) if isinstance(payload.get('surfaces', {}), dict) else {}
    xp = surfaces.get('xp_local', {}) if isinstance(surfaces.get('xp_local', {}), dict) else {}
    cloud = surfaces.get('cloud', {}) if isinstance(surfaces.get('cloud', {}), dict) else {}

    def _metric(surface, key):
        metrics = surface.get('metrics', []) if isinstance(surface.get('metrics', []), list) else []
        for m in metrics:
            if isinstance(m, dict) and m.get('key') == key:
                return m
        return {}

    # XP fidelity hints (manual validation cues)
    qa_ratio = _metric(xp, 'xp.phase_d_reject_ratio')
    if qa_ratio:
        val = qa_ratio.get('value')
        st = qa_ratio.get('status')
        hints.append('XP QA reject ratio: {0} ({1})'.format(val, st))
        if st in ('warn', 'fail'):
            hints.append('Hint: review latest qa_reject_samples_*.jsonl for unresolved QA rejects.')

    inv_ratio = _metric(xp, 'xp.phase_d_invalid_external_id_skip_ratio')
    if inv_ratio:
        val = inv_ratio.get('value')
        st = inv_ratio.get('status')
        hints.append('XP invalid external patient ID skip ratio: {0} ({1})'.format(val, st))
        if st in ('warn', 'fail'):
            hints.append('Hint: review rule_decision_log constraint_fail PATIENT_EXTERNAL_ID_INVALID_FORMAT and source demographics.')

    ent_scope = _metric(xp, 'xp.phase_d_entity_scope')
    if ent_scope:
        hints.append('XP Phase D entity scope: {0} ({1})'.format(
            ent_scope.get('value'), ent_scope.get('detail') or ''))

    post_medisoft = _metric(xp, 'xp.post_medisoft_status')
    if post_medisoft:
        val = str(post_medisoft.get('value', '') or '').strip().lower() or 'unknown'
        detail = str(post_medisoft.get('detail', '') or '').strip()
        if detail:
            hints.append('Post-MediSoft path: {0} ({1})'.format(val, detail))
        else:
            hints.append('Post-MediSoft path: {0}'.format(val))
        if val != 'exercised':
            hints.append('Hint: latest run did not fully exercise the DAT/post-MediSoft handoff.')

    dat_candidates = _metric(xp, 'xp.phase_b_dat_candidates_seen_count')
    dat_manifest = _metric(xp, 'xp.phase_b_dat_manifest_rows_count')
    dat_missing = _metric(xp, 'xp.phase_b_dat_configured_root_missing_count')
    dat_fallback = _metric(xp, 'xp.phase_b_dat_fallback_root_count')
    dat_empty = _metric(xp, 'xp.phase_b_dat_existing_empty_root_count')
    dat_selection = _metric(xp, 'xp.phase_b_dat_selection_mode')
    dat_selected_root = _metric(xp, 'xp.phase_b_dat_selected_root_source_id')
    dat_effective_root = _metric(xp, 'xp.phase_b_dat_effective_root_source_id')
    if dat_candidates or dat_manifest or dat_missing or dat_fallback or dat_empty or dat_selection or dat_selected_root or dat_effective_root:
        hints.append('XP DAT discovery: candidates={0}, manifest_rows={1}, missing_roots={2}, fallback_roots={3}, empty_roots={4}, selection={5}, selected_root={6}, effective_root={7}'.format(
            dat_candidates.get('value', 0) if dat_candidates else 0,
            dat_manifest.get('value', 0) if dat_manifest else 0,
            dat_missing.get('value', 0) if dat_missing else 0,
            dat_fallback.get('value', 0) if dat_fallback else 0,
            dat_empty.get('value', 0) if dat_empty else 0,
            dat_selection.get('value', '') if dat_selection else '',
            dat_selected_root.get('value', '') if dat_selected_root else '',
            dat_effective_root.get('value', '') if dat_effective_root else '',
        ))

    dat_selected = _metric(xp, 'xp.phase_d_dat_selected_count')
    dat_qa_pass = _metric(xp, 'xp.phase_d_dat_qa_pass_count')
    dat_qa_reject = _metric(xp, 'xp.phase_d_dat_qa_reject_count')
    dat_canonical = _metric(xp, 'xp.phase_d_dat_canonical_record_count')
    if dat_selected or dat_qa_pass or dat_qa_reject or dat_canonical:
        hints.append('XP DAT Phase D: selected={0}, qa_pass={1}, qa_reject={2}, canonical={3}'.format(
            dat_selected.get('value', 0) if dat_selected else 0,
            dat_qa_pass.get('value', 0) if dat_qa_pass else 0,
            dat_qa_reject.get('value', 0) if dat_qa_reject else 0,
            dat_canonical.get('value', 0) if dat_canonical else 0,
        ))

    csv_docx_join = _metric(xp, 'xp.phase_d_csv_docx_join_summary')
    if csv_docx_join and csv_docx_join.get('value') == 'tracked':
        detail = str(csv_docx_join.get('detail', '') or '').strip()
        if detail:
            hints.append('XP upstream CSV+DOCX join: {0}'.format(detail))

    projection_cov = _metric(xp, 'xp.phase_e_projection_coverage')
    if projection_cov:
        st = projection_cov.get('status')
        cov_val = projection_cov.get('value')
        if str(cov_val).lower() == 'not_applicable':
            hints.append('XP projection coverage: not_applicable (eligible_count=0)')
        else:
            hints.append('XP projection coverage: {0} ({1})'.format(cov_val, st))
        if st == 'fail':
            hints.append('Hint: potential projection drop/defer risk; inspect projection_deviation_samples_*.jsonl.')

    alignment = _metric(xp, 'xp.cursor_state_run_alignment')
    if alignment:
        st = alignment.get('status')
        align_val = alignment.get('value')
        align_detail = str(alignment.get('detail', '') or '').strip()
        if align_detail:
            hints.append('XP cursor/state run alignment: {0} ({1}; {2})'.format(align_val, st, align_detail))
        else:
            hints.append('XP cursor/state run alignment: {0} ({1})'.format(align_val, st))
        if st in ('warn', 'fail'):
            hints.append('Hint: reconcile diagnostics_state and run_cursor run IDs after standalone phase reruns.')

    parity = _metric(xp, 'xp.phase_e_contract_parity')
    if parity and str(parity.get('value', '')).lower() == 'fail':
        hints.append('Hint: contract parity failed; treat as potential data-fidelity blocker before cutover.')

    # Cloud fidelity hints
    unacked = _metric(cloud, 'cloud.unacked_queue_count')
    oldest = _metric(cloud, 'cloud.oldest_unacked_age_minutes')
    if unacked:
        hints.append('Cloud backlog: unacked={0} ({1})'.format(unacked.get('value'), unacked.get('status')))
    if oldest:
        hints.append('Cloud oldest unacked age (min): {0} ({1})'.format(oldest.get('value'), oldest.get('status')))

    unknown_codes = _metric(cloud, 'cloud.unknown_reject_code_count_cohort')
    if unknown_codes and int(unknown_codes.get('value') or 0) > 0:
        hints.append('Hint: unknown reject codes in shadow cohort; validate reject taxonomy before migration decisions.')

    machine_missing = _metric(cloud, 'cloud.machine_id_missing_count')
    if machine_missing and int(machine_missing.get('value') or 0) > 0:
        hints.append('Hint: missing machine_id records may indicate routing/data-loss risk.')

    degradations = payload.get('degradations', []) if isinstance(payload.get('degradations', []), list) else []
    cloud_degradations = [d for d in degradations if isinstance(d, dict) and d.get('surface') == 'cloud']
    if cloud_degradations:
        reasons = []
        for item in cloud_degradations:
            reason = str(item.get('reason', '') or '').strip()
            if reason:
                reasons.append(reason)
        if reasons:
            hints.append('Cloud degradation reasons: {0}'.format(','.join(reasons)))
        runbook_path = getattr(
            _runbook_tools,
            'CLOUD_DEGRADED_VALIDATION_RUNBOOK',
            'docs/runbooks/Cloud_Readiness_Cloud_Degraded_Validation.md',
        )
        hints.append('Runbook: {0}'.format(runbook_path))
        if stage == 'xp_validation':
            hints.append('Note: degraded collection mode active for deferred cloud scope; complete manual checks before dual-run/cutover.')
        else:
            hints.append('Note: degraded collection mode active; complete manual checks before GO decisions.')

    _REGRESSION_HINT_FINDING_CODES = frozenset((
        'XP_POST_MEDISOFT_BLOCKED',
        'XP_DAT_REGRESSION_NO_BASELINE',
        'XP_DAT_REGRESSION_QA_ALIGNMENT',
        'XP_DAT_REGRESSION_POST_MEDISOFT',
    ))
    reg_added = 0
    xp_findings = xp.get('findings', []) if isinstance(xp.get('findings', []), list) else []
    for f in xp_findings:
        if not isinstance(f, dict):
            continue
        if f.get('severity') not in ('warn', 'fail'):
            continue
        code = str(f.get('code') or '')
        if code in _REGRESSION_HINT_FINDING_CODES:
            hints.append('{0}: {1}'.format(code, f.get('message') or ''))
            reg_added += 1
    xp_metrics = xp.get('metrics', []) if isinstance(xp.get('metrics', []), list) else []
    for m in xp_metrics:
        if not isinstance(m, dict):
            continue
        mk = str(m.get('key') or '')
        if not (mk.startswith('xp.dat_regression.') or mk.startswith('xp.dat_v2.')):
            continue
        if m.get('status') not in ('warn', 'fail'):
            continue
        line = '{0}: {1} ({2})'.format(mk, m.get('value'), m.get('status'))
        det = str(m.get('detail') or '').strip()
        if det:
            line = '{0} {1}'.format(line, det)
        if len(line) > 200:
            line = line[:197] + '...'
        hints.append(line)
        reg_added += 1
    if status in ('warn', 'fail') and reg_added == 0:
        hints.append(
            'Migration audit: see full JSON for xp.dat_regression.* / xp.dat_v2.* metrics and findings.'
        )

    return _deduplicate_audit_hint_lines(hints)


def _shadow_run_actual_from_payload(payload, path=''):
    """Normalize one shadow_run_report JSON payload into recent-run actual fields."""
    if not isinstance(payload, dict):
        return {}
    if _normalize_shadow_actual_impl is not None:
        norm = _normalize_shadow_actual_impl(payload, path, _safe_int)
        if norm and norm.get('run_id'):
            out = {
                'run_id': norm.get('run_id', ''),
                'generated_at_utc': norm.get('generated_at_utc', ''),
                'pipeline_status': norm.get('pipeline_status', 'unknown'),
                'post_medisoft_label': norm.get('post_medisoft_label', 'unknown'),
            }
            for k in SHADOW_ACTUAL_INT_FIELDS:
                out[k] = _safe_int(norm.get(k), 0)
            return out
    run_id = str(payload.get('run_id', '') or '').strip()
    if not run_id:
        run_id = _shadow_run_report_run_id_from_path(path)
    if not run_id:
        return {}
    pipeline_ok = bool(payload.get('pipeline_ok'))
    failed_phase = str(payload.get('failed_phase', '') or '').strip()
    error_code = str(payload.get('error_code', '') or '').strip()
    if pipeline_ok:
        pipeline_status = 'ok'
    elif failed_phase and error_code:
        pipeline_status = 'fail:{0}:{1}'.format(failed_phase, error_code)
    elif failed_phase:
        pipeline_status = 'fail:{0}'.format(failed_phase)
    elif error_code:
        pipeline_status = 'fail:{0}'.format(error_code)
    else:
        pipeline_status = 'fail'

    post_medisoft_status = str(payload.get('post_medisoft_status', '') or '').strip().lower() or 'unknown'
    blocked_stage = str(payload.get('post_medisoft_blocked_stage', '') or '').strip().lower()
    if blocked_stage:
        post_medisoft_label = '{0}({1})'.format(post_medisoft_status, blocked_stage)
    else:
        post_medisoft_label = post_medisoft_status

    out = {
        'run_id': run_id,
        'generated_at_utc': str(payload.get('generated_at_utc', '') or '').strip(),
        'pipeline_status': pipeline_status,
        'post_medisoft_label': post_medisoft_label,
    }
    for k in SHADOW_ACTUAL_INT_FIELDS:
        out[k] = _safe_int(payload.get(k), 0)
    return out


def _collect_recent_shadow_run_actuals(reports_dir, limit=3):
    """Return latest shadow_run_report JSON actuals for compact trend summaries."""
    try:
        max_items = int(limit)
    except (TypeError, ValueError):
        max_items = 3
    if max_items <= 0:
        return []
    if not reports_dir or not os.path.isdir(reports_dir):
        return []
    try:
        items = os.listdir(reports_dir)
    except (IOError, OSError):
        return []

    candidates = []
    for item in items:
        if not (item.startswith('shadow_run_report_') and item.endswith('.json')):
            continue
        path = os.path.join(reports_dir, item)
        if not os.path.isfile(path):
            continue
        try:
            mtime = os.path.getmtime(path)
        except (IOError, OSError, ValueError):
            mtime = 0
        candidates.append((mtime, path))
    candidates.sort(key=lambda entry: (entry[0], entry[1]), reverse=True)

    actuals = []
    for _, path in candidates[:max_items]:
        item = _shadow_run_actual_from_payload(_load_json_dict(path), path)
        if item:
            actuals.append(item)
    return actuals


def _derive_current_state_post_medisoft_summary(state):
    """Return compact live DAT/post-MediSoft summary from diagnostics state."""
    if _patient_tools:
        return _patient_tools.derive_post_medisoft_summary(state, _safe_int)
    return {
        'status': 'not_exercised',
        'blocked_stage': '',
        'label': 'not_exercised',
        'manifest_rows': 0,
        'selected': 0,
        'qa_pass': 0,
        'qa_reject': 0,
        'canonical': 0,
    }


def _audit_shadow_run_id(payload):
    """Return shadow pipeline run_id recorded by the audit payload."""
    surfaces = payload.get('surfaces', {}) if isinstance(payload.get('surfaces', {}), dict) else {}
    xp = surfaces.get('xp_local', {}) if isinstance(surfaces.get('xp_local', {}), dict) else {}
    run_ids = xp.get('run_ids', {}) if isinstance(xp.get('run_ids', {}), dict) else {}
    return str(run_ids.get('shadow', '') or '').strip()


def _load_shadow_report_payload(shadow_report_path):
    """Return parsed shadow_run_report JSON payload and resolved JSON path when available."""
    path = str(shadow_report_path or '').strip()
    if not path:
        return ({}, '')
    candidates = []
    if path.lower().endswith('.txt'):
        candidates.append(path[:-4] + '.json')
    elif path.lower().endswith('.json'):
        candidates.append(path)
    if path not in candidates:
        candidates.append(path)
    seen = set()
    for candidate in candidates:
        key = os.path.normcase(os.path.abspath(candidate)) if candidate else candidate
        if key in seen:
            continue
        seen.add(key)
        data = _load_json_dict(candidate)
        if data:
            return (data, candidate)
    return ({}, '')


def _shadow_report_has_summary_fields(payload):
    if not isinstance(payload, dict):
        return False
    for key in (
            'pipeline_ok', 'failed_phase', 'error_code', 'post_medisoft_status',
            'phase_b_dat_manifest_rows_count', 'phase_d_dat_selected_count',
            'phase_d_dat_qa_reject_count', 'phase_d_dat_qa_pass_count',
            'phase_d_dat_canonical_record_count'):
        if key in payload:
            return True
    return False


def _select_system_health_anchor_report_path(reports_dir, artifacts, expected_run_id=''):
    """Resolve the completed-run shadow_run_report JSON that should anchor the pack."""
    if expected_run_id:
        expected_json = os.path.join(reports_dir or '.', 'shadow_run_report_{0}.json'.format(expected_run_id))
        if os.path.isfile(expected_json):
            return expected_json
    selected_path = str((artifacts or {}).get('shadow_report_path', '') or '').strip()
    if selected_path.lower().endswith('.txt'):
        candidate = selected_path[:-4] + '.json'
        if os.path.isfile(candidate):
            return candidate
    if selected_path.lower().endswith('.json') and os.path.isfile(selected_path):
        return selected_path
    return ''


def _merge_state_overrides(base_state, overrides):
    merged = dict(base_state or {})
    if not isinstance(overrides, dict):
        return merged
    replace_keys = ('last_discovery_dat_telemetry', 'last_phase_d_dat_telemetry')
    for key, value in overrides.items():
        if key in replace_keys and isinstance(value, dict):
            merged[key] = dict(value)
        elif isinstance(value, dict) and isinstance(merged.get(key), dict):
            current = dict(merged.get(key) or {})
            current.update(value)
            merged[key] = current
        else:
            merged[key] = value
    return merged


def _shadow_report_state_overrides(payload):
    """Map anchored shadow_run_report summary fields into state-style DAT telemetry keys."""
    if not _shadow_report_has_summary_fields(payload):
        return {}
    discovery = {}
    phase_d = {}
    for src, dst in (
            ('phase_b_dat_manifest_rows_count', 'dat_manifest_rows_count'),
            ('phase_b_dat_configured_root_missing_count', 'dat_configured_root_missing_count'),
            ('phase_b_dat_fallback_root_count', 'dat_fallback_root_count'),
            ('phase_b_dat_existing_empty_root_count', 'dat_existing_empty_root_count'),
            ('phase_b_dat_selection_mode', 'dat_selection_mode'),
            ('phase_b_dat_selected_root_source_id', 'dat_selected_root_source_id'),
            ('phase_b_dat_effective_root_source_id', 'dat_effective_root_source_id'),
            ('phase_b_dat_root_yield_counts_by_source', 'dat_root_yield_counts_by_source'),
            ('phase_b_dat_yielding_root_source_ids', 'dat_yielding_root_source_ids')):
        if src in payload:
            discovery[dst] = payload.get(src)
    for src, dst in (
            ('phase_d_dat_selected_count', 'dat_selected_count'),
            ('phase_d_dat_qa_pass_count', 'dat_qa_pass_count'),
            ('phase_d_dat_qa_reject_count', 'dat_qa_reject_count'),
            ('phase_d_dat_qa_reject_counts_by_reason', 'dat_qa_reject_counts_by_reason'),
            ('phase_d_dat_field_presence_by_alias', 'dat_field_presence_by_alias'),
            ('phase_d_dat_canonical_record_count', 'dat_canonical_record_count'),
            ('phase_d_entity_scope', 'phase_d_entity_scope'),
            ('phase_d_dat_parse_diagnostics', 'dat_parse_diagnostics'),
            ('phase_d_dat_file_prefix_counts', 'dat_file_prefix_counts'),
            ('phase_d_dat_reject_file_prefix_counts', 'dat_reject_file_prefix_counts')):
        if src in payload:
            phase_d[dst] = payload.get(src)
    if 'post_medisoft_status' in payload:
        phase_d['post_medisoft_exercised'] = str(payload.get('post_medisoft_status', '') or '').strip().lower() == 'exercised'
    if 'post_medisoft_blocked_stage' in payload:
        phase_d['post_medisoft_blocked_stage'] = payload.get('post_medisoft_blocked_stage')

    overrides = {}
    if discovery:
        overrides['last_discovery_dat_telemetry'] = discovery
    if phase_d:
        overrides['last_phase_d_dat_telemetry'] = phase_d
    run_id = str(payload.get('run_id', '') or '').strip()
    if run_id:
        overrides['last_shadow_pipeline_run_id'] = run_id
    return overrides


def _build_system_health_pack_context(lab_root, reports_dir, artifacts):
    """Resolve completed-run anchor context while preserving live diagnostics for alignment notes."""
    state = _load_json_dict(os.path.join(lab_root or '.', 'diagnostics_state.json'))
    expected_run_id = str(state.get('last_shadow_pipeline_run_id', '') or '').strip()
    active_run_id = str(state.get('active_run_id', '') or '').strip()
    anchor_report_path = _select_system_health_anchor_report_path(
        reports_dir,
        artifacts,
        expected_run_id=expected_run_id,
    )
    anchor_payload, resolved_anchor_path = _load_shadow_report_payload(anchor_report_path or (artifacts or {}).get('shadow_report_path'))
    anchor_path = resolved_anchor_path or anchor_report_path
    anchor_run_id = str(anchor_payload.get('run_id', '') or '').strip()
    if not anchor_run_id:
        anchor_run_id = _shadow_run_report_run_id_from_path(anchor_path or (artifacts or {}).get('shadow_report_path'))
    if not anchor_run_id and expected_run_id:
        anchor_run_id = expected_run_id
    pack_scope = 'unknown'
    if anchor_run_id:
        pack_scope = 'completed_run'
        if active_run_id and active_run_id != anchor_run_id:
            pack_scope = 'mixed_scope'
    elif active_run_id:
        pack_scope = 'live_current_state'
    anchor_state = _merge_state_overrides(state, _shadow_report_state_overrides(anchor_payload))
    anchor_actual = {}
    if _shadow_report_has_summary_fields(anchor_payload):
        anchor_actual = _shadow_run_actual_from_payload(anchor_payload, anchor_path)
    return {
        'state': state,
        'expected_shadow_run_id': expected_run_id,
        'active_run_id': active_run_id,
        'anchor_run_id': anchor_run_id,
        'anchor_report_path': anchor_path,
        'anchor_shadow_report_payload': anchor_payload,
        'anchor_state': anchor_state,
        'anchor_actual': anchor_actual,
        'pack_scope': pack_scope,
        'selected_shadow_run_id': _shadow_run_report_run_id_from_path((artifacts or {}).get('shadow_report_path')),
    }


def _build_anchor_run_snapshot_lines(pack_context):
    """Build explicit completed-run snapshot lines for mixed-scope health packs."""
    ctx = pack_context if isinstance(pack_context, dict) else {}
    lines = ['Anchored completed-run snapshot:']
    anchor_run_id = str(ctx.get('anchor_run_id', '') or '').strip()
    payload = ctx.get('anchor_shadow_report_payload', {}) if isinstance(ctx.get('anchor_shadow_report_payload', {}), dict) else {}
    actual = ctx.get('anchor_actual', {}) if isinstance(ctx.get('anchor_actual', {}), dict) else {}
    if not anchor_run_id:
        lines.append(' - none (no completed-run shadow_run_report JSON resolved)')
        return lines
    if actual:
        lines.append(
            ' - {0}: pipeline={1}, post_medisoft={2}, manifest_rows={3}, selected={4}, qa_pass={5}, qa_reject={6}, canonical={7}'.format(
                actual.get('run_id', anchor_run_id),
                actual.get('pipeline_status', 'unknown'),
                actual.get('post_medisoft_label', 'unknown'),
                actual.get('phase_b_dat_manifest_rows_count', 0),
                actual.get('phase_d_dat_selected_count', 0),
                actual.get('phase_d_dat_qa_pass_count', 0),
                actual.get('phase_d_dat_qa_reject_count', 0),
                actual.get('phase_d_dat_canonical_record_count', 0),
            )
        )
    elif ctx.get('anchor_report_path'):
        lines.append(' - run_id={0} (shadow_run_report JSON lacks summary fields)'.format(anchor_run_id))
    else:
        lines.append(' - run_id={0} (shadow_run_report JSON pending or missing)'.format(anchor_run_id))
    selection_mode = str(payload.get('phase_b_dat_selection_mode', '') or '').strip()
    selected_root = str(payload.get('phase_b_dat_selected_root_source_id', '') or '').strip()
    effective_root = str(payload.get('phase_b_dat_effective_root_source_id', '') or '').strip()
    missing_roots = _safe_int(payload.get('phase_b_dat_configured_root_missing_count'), 0)
    empty_roots = _safe_int(payload.get('phase_b_dat_existing_empty_root_count'), 0)
    fallback_roots = _safe_int(payload.get('phase_b_dat_fallback_root_count'), 0)
    if selection_mode or selected_root or effective_root or missing_roots or empty_roots or fallback_roots:
        lines.append(
            ' - dat_roots=selection:{0}, selected_root:{1}, effective_root:{2}, missing_roots:{3}, empty_roots:{4}, fallback_roots:{5}'.format(
                selection_mode or '-',
                selected_root or '-',
                effective_root or '-',
                missing_roots,
                empty_roots,
                fallback_roots,
            )
        )
    yield_counts = payload.get('phase_b_dat_root_yield_counts_by_source', {}) if isinstance(payload.get('phase_b_dat_root_yield_counts_by_source', {}), dict) else {}
    if yield_counts:
        lines.append(' - dat_root_yield_counts={0}'.format(_format_count_map(yield_counts)))
    return lines


def _should_show_latest_live_pipeline_attempt(pack_context):
    ctx = pack_context if isinstance(pack_context, dict) else {}
    state = ctx.get('state') if isinstance(ctx.get('state'), dict) else {}
    anchor = str(ctx.get('anchor_run_id', '') or '').strip()
    last_completed = str(state.get('last_shadow_pipeline_run_id', '') or '').strip()
    active = str(state.get('active_run_id', '') or '').strip()
    live_rid = active or last_completed
    outcome = str(state.get('last_shadow_pipeline_outcome', '') or '').strip().lower()
    if outcome == 'interrupted':
        return True
    if anchor and live_rid and anchor != live_rid:
        return True
    return False


def _build_latest_live_pipeline_attempt_lines(pack_context):
    """Compact live attempt context: interruption codes and anchor mismatch."""
    ctx = pack_context if isinstance(pack_context, dict) else {}
    state = ctx.get('state') if isinstance(ctx.get('state'), dict) else {}
    anchor = str(ctx.get('anchor_run_id', '') or '').strip()
    last_completed = str(state.get('last_shadow_pipeline_run_id', '') or '').strip()
    active = str(state.get('active_run_id', '') or '').strip()
    live_rid = active or last_completed
    outcome = str(state.get('last_shadow_pipeline_outcome', '') or '').strip().lower()
    failed_phase = str(state.get('last_shadow_pipeline_failed_phase', '') or '').strip()
    err = str(state.get('last_shadow_pipeline_error_code', '') or state.get('last_error_code', '') or '').strip()
    hex_c = str(state.get('last_shadow_pipeline_interrupt_code_hex', '') or '').strip()
    src = str(state.get('last_shadow_pipeline_interrupt_source', '') or '').strip()
    lines = ['Latest live pipeline attempt:']
    lines.append(' - run_id={0}'.format(live_rid or '-'))
    lines.append(' - outcome={0}'.format(outcome or '-'))
    if outcome == 'interrupted':
        lines.append(' - interrupted_phase={0}'.format(failed_phase or '-'))
        lines.append(' - interrupt_code={0}'.format(err or '-'))
        if hex_c:
            lines.append(' - interrupt_code_hex={0}'.format(hex_c))
        if src:
            lines.append(' - interrupt_source={0}'.format(src))
    elif failed_phase:
        lines.append(' - failed_phase={0}'.format(failed_phase))
    if err and outcome != 'interrupted':
        lines.append(' - error_code={0}'.format(err))
    guard = str(state.get('last_shadow_pipeline_interrupt_guard_note', '') or '').strip()
    if guard:
        lines.append(' - guard_note={0}'.format(guard))
    if anchor and live_rid and anchor != live_rid:
        lines.append(' - note: differs_from_anchor_run_id={0}'.format(anchor))
    return lines


def _build_system_health_alignment_notes(lab_root, reports_dir, artifacts, audit_payload):
    """Detect mixed-snapshot conditions between diagnostics state, audit, and Phase F artifacts."""
    state = _load_json_dict(os.path.join(lab_root or '.', 'diagnostics_state.json'))
    expected_run_id = str(state.get('last_shadow_pipeline_run_id', '') or '').strip()
    if not expected_run_id:
        return {'expected_shadow_run_id': '', 'notes': []}

    audit_shadow_run_id = _audit_shadow_run_id(audit_payload) if isinstance(audit_payload, dict) else ''
    selected_shadow_run_id = _shadow_run_report_run_id_from_path(artifacts.get('shadow_report_path'))
    audit_generated_epoch = _parse_iso_utc_epoch(
        audit_payload.get('generated_at_utc', '') if isinstance(audit_payload, dict) else '')
    last_phase_f_epoch = _parse_iso_utc_epoch(state.get('last_phase_f_at_utc', ''))

    notes = []
    audit_stale = False
    if audit_shadow_run_id and audit_shadow_run_id != expected_run_id:
        audit_stale = True
    elif expected_run_id and audit_generated_epoch and last_phase_f_epoch and audit_generated_epoch < last_phase_f_epoch:
        audit_stale = True
    if audit_stale:
        notes.append(
            'note: audit summary shadow_run_id={0} is older than current state last_shadow_pipeline_run_id={1}'.format(
                audit_shadow_run_id or '-', expected_run_id))
        current = _derive_current_state_post_medisoft_summary(state)
        notes.append(
            'current state: post_medisoft={0}, manifest_rows={1}, selected={2}, qa_pass={3}, qa_reject={4}, canonical={5}'.format(
                current.get('label', 'unknown'),
                current.get('manifest_rows', 0),
                current.get('selected', 0),
                current.get('qa_pass', 0),
                current.get('qa_reject', 0),
                current.get('canonical', 0),
            ))
        notes.append('hint: rerun System Health Triage after Phase F packaging settles for aligned audit hints.')

    if selected_shadow_run_id and selected_shadow_run_id != expected_run_id:
        notes.append(
            'note: latest shadow_run_report pointer run_id={0} lags current state last_shadow_pipeline_run_id={1}'.format(
                selected_shadow_run_id, expected_run_id))

    return {
        'expected_shadow_run_id': expected_run_id,
        'notes': notes,
        'audit_stale': audit_stale,
    }


def _build_recent_shadow_run_actual_lines(reports_dir, limit=3, expected_run_id=''):
    """Build compact recent-run DAT/post-MediSoft actuals lines for health packs."""
    actuals = _collect_recent_shadow_run_actuals(reports_dir, limit=limit)
    lines = ['Recent run actuals:']
    pending_line = ''

    if expected_run_id and not any(str(item.get('run_id', '') or '').strip() == expected_run_id for item in actuals):
        expected_json = os.path.join(reports_dir or '.', 'shadow_run_report_{0}.json'.format(expected_run_id))
        if os.path.isfile(expected_json):
            expected_item = _shadow_run_actual_from_payload(_load_json_dict(expected_json), expected_json)
            if expected_item:
                actuals = [expected_item] + [
                    item for item in actuals if str(item.get('run_id', '') or '').strip() != expected_run_id
                ]
                actuals = actuals[:max(_safe_int(limit, 3), 1)]
        else:
            pending_line = ' - current_run={0}: pending shadow_run_report JSON finalization'.format(expected_run_id)

    if pending_line:
        lines.append(pending_line)
    if not actuals:
        if not pending_line:
            lines.append(' - none (no shadow_run_report_*.json payloads found)')
        return lines

    for item in actuals:
        suffix = ''
        if item.get('generated_at_utc'):
            suffix = ', generated_at_utc={0}'.format(item.get('generated_at_utc'))
        v2_sk = _safe_int(item.get('phase_d_dat_v2_skipped_total'), 0)
        v2_cf = _safe_int(item.get('phase_d_dat_v2_constraint_failed_total'), 0)
        v2_ins = _safe_int(item.get('phase_d_dat_v2_inserted_total'), 0)
        if v2_sk or v2_cf or v2_ins:
            suffix += ', v2_ins={0},v2_sk={1},v2_cf={2}'.format(v2_ins, v2_sk, v2_cf)
        lines.append(
            ' - {0}: pipeline={1}, post_medisoft={2}, manifest_rows={3}, selected={4}, qa_pass={5}, qa_reject={6}, canonical={7}{8}'.format(
                item.get('run_id', '?'),
                item.get('pipeline_status', 'unknown'),
                item.get('post_medisoft_label', 'unknown'),
                item.get('phase_b_dat_manifest_rows_count', 0),
                item.get('phase_d_dat_selected_count', 0),
                item.get('phase_d_dat_qa_pass_count', 0),
                item.get('phase_d_dat_qa_reject_count', 0),
                item.get('phase_d_dat_canonical_record_count', 0),
                suffix,
            )
        )

    if len(actuals) >= 2:
        latest = actuals[0]
        previous = actuals[1]
        delta_parts = []
        if latest.get('pipeline_status') != previous.get('pipeline_status'):
            delta_parts.append('pipeline:{0}->{1}'.format(
                previous.get('pipeline_status', 'unknown'),
                latest.get('pipeline_status', 'unknown'),
            ))
        if latest.get('post_medisoft_label') != previous.get('post_medisoft_label'):
            delta_parts.append('post_medisoft:{0}->{1}'.format(
                previous.get('post_medisoft_label', 'unknown'),
                latest.get('post_medisoft_label', 'unknown'),
            ))
        for label, key in (
            ('manifest_rows', 'phase_b_dat_manifest_rows_count'),
            ('selected', 'phase_d_dat_selected_count'),
            ('qa_pass', 'phase_d_dat_qa_pass_count'),
            ('qa_reject', 'phase_d_dat_qa_reject_count'),
            ('canonical', 'phase_d_dat_canonical_record_count'),
            ('v2_attempted', 'phase_d_dat_v2_payload_attempted_total'),
            ('v2_inserted', 'phase_d_dat_v2_inserted_total'),
            ('v2_skipped', 'phase_d_dat_v2_skipped_total'),
            ('v2_constraint', 'phase_d_dat_v2_constraint_failed_total'),
        ):
            delta = _safe_int(latest.get(key), 0) - _safe_int(previous.get(key), 0)
            if delta:
                delta_parts.append('{0}:{1:+d}'.format(label, delta))
        lines.append(' - delta_vs_previous={0}'.format(', '.join(delta_parts) if delta_parts else 'no_change'))
        regression_hints = _build_recent_run_regression_hints(latest, previous)
        if regression_hints:
            lines.append(' - regression_hints={0}'.format(', '.join(regression_hints)))
    return lines


def _build_recent_run_regression_hints(latest, previous):
    """Return compact regression hints for latest-vs-previous run actuals."""
    hints = []
    latest_label = str((latest or {}).get('post_medisoft_label', '') or '').strip().lower()
    prev_label = str((previous or {}).get('post_medisoft_label', '') or '').strip().lower()
    if prev_label == 'exercised' and latest_label != 'exercised':
        hints.append('post_medisoft_regressed:{0}->{1}'.format(prev_label, latest_label or 'unknown'))

    for label, key in (
        ('manifest_rows_drop', 'phase_b_dat_manifest_rows_count'),
        ('selected_drop', 'phase_d_dat_selected_count'),
        ('qa_pass_drop', 'phase_d_dat_qa_pass_count'),
        ('canonical_drop', 'phase_d_dat_canonical_record_count'),
        ('v2_inserted_drop', 'phase_d_dat_v2_inserted_total'),
    ):
        latest_val = _safe_int((latest or {}).get(key), 0)
        prev_val = _safe_int((previous or {}).get(key), 0)
        if prev_val > latest_val:
            hints.append('{0}:{1}->{2}'.format(label, prev_val, latest_val))
    return hints


def run_migration_health_audit(
        repo_root,
        python_exe,
        env,
        scope='both',
        write_report=False,
        cloud_required=False,
        migration_stage='xp_validation'):
    """Run audit_migration_health synchronously and return parsed summary payload.

    Returns (ok, msg, data) where data includes parsed payload + operator hints.
    """
    script_info = _audit_script_path(repo_root, python_exe=python_exe)
    if not script_info.get('ok'):
        return (False, script_info.get('message') or 'audit_migration_health.py not found.', None)
    script = script_info.get('path')
    try:
        lab_root = resolve_lab_root(repo_root)
        proc_env = os.environ.copy()
        proc_env['MEDICAFE_LAB_DIR'] = lab_root
        if env and isinstance(env, dict):
            for k in ('GOOGLE_CLOUD_PROJECT', 'MEDICAFE_HEALTH_URL'):
                if env.get(k):
                    proc_env[k] = str(env.get(k))

        stage = str(migration_stage or 'xp_validation').strip().lower() or 'xp_validation'
        cmd = [
            python_exe,
            script,
            '--scope',
            scope,
            '--migration-stage',
            stage,
            '--json',
            '--no-text',
            '--output-mode',
            'write' if write_report else 'stdout',
        ]
        if cloud_required:
            cmd.append('--cloud-required')
        p = subprocess.Popen(cmd, cwd=script_info.get('cwd') or repo_root, env=proc_env, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        out_b, err_b = p.communicate()
        out = out_b.decode('utf-8', 'replace') if hasattr(out_b, 'decode') else str(out_b)
        err = err_b.decode('utf-8', 'replace') if hasattr(err_b, 'decode') else str(err_b)
        payload = _extract_json_object_from_text(out)
        if not payload:
            return (False, 'Audit did not return parseable JSON. {0}'.format(err.strip() or 'No stderr.'), None)
        hints = _audit_hint_lines_from_payload(payload)
        data = {'payload': payload, 'hints': hints, 'stdout': out, 'stderr': err, 'returncode': int(p.returncode)}
        msg = 'Audit completed with status={0}, score={1}, exit_code={2}'.format(
            payload.get('overall', {}).get('status', '?'),
            payload.get('overall', {}).get('score', '?'),
            payload.get('overall', {}).get('exit_code', p.returncode),
        )
        return (True, msg, data)
    except Exception as e:
        return (False, str(e), None)


def open_latest_migration_health_report(repo_root):
    """Open latest audit_migration_health summary report (txt preferred, then json)."""
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    path, msg = _find_latest_by_prefix(reports_dir, 'audit_migration_health_summary_', ('.txt', '.json'))
    if path:
        return (True, '', path)
    if msg:
        return (False, msg, None)
    return (False, 'No migration health audit summaries found. Run an audit first.', None)


def _add_unique_file(extra_files, seen, path, alias=None):
    """Append existing file path once to support-bundle file list."""
    if not path or not os.path.isfile(path):
        return
    try:
        norm = os.path.normcase(os.path.abspath(path))
    except Exception:
        norm = str(path)
    if norm in seen:
        return
    seen.add(norm)
    extra_files.append((alias or os.path.basename(path), path))


def _collect_system_health_artifacts(repo_root, env_flag_fn, include_delivery_status=False):
    """Resolve latest system-health artifact paths; refresh consolidated snapshot first."""
    lab_root = resolve_lab_root(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    if reports_dir and not os.path.exists(reports_dir):
        os.makedirs(reports_dir, exist_ok=True)

    consolidated_ok, consolidated_msg, consolidated_path = open_consolidated_health_report(
        repo_root, env_flag_fn)
    if not consolidated_ok:
        consolidated_path = ''

    audit_summary_txt, _ = _find_latest_by_prefix(
        reports_dir, 'audit_migration_health_summary_', ('.txt',))
    audit_summary_json, _ = _find_latest_by_prefix(
        reports_dir, 'audit_migration_health_summary_', ('.json',))
    audit_metrics_json, _ = _find_latest_by_prefix(
        reports_dir, 'audit_migration_health_metrics_', ('.json',))
    preferred_run_id = _preferred_evidence_run_id(lab_root, reports_dir)
    shadow_report_path = ''
    shadow_index_path = ''
    phase_f_mismatch_path = ''
    if preferred_run_id:
        for suffix in ('.json', '.txt'):
            candidate = os.path.join(reports_dir, 'shadow_run_report_{0}{1}'.format(preferred_run_id, suffix))
            if os.path.isfile(candidate):
                shadow_report_path = candidate
                break
        candidate = os.path.join(reports_dir, 'shadow_evidence_index_{0}.json'.format(preferred_run_id))
        if os.path.isfile(candidate):
            shadow_index_path = candidate
        candidate = os.path.join(reports_dir, 'phase_f_mismatch_{0}.txt'.format(preferred_run_id))
        if os.path.isfile(candidate):
            phase_f_mismatch_path = candidate
    if not shadow_report_path:
        shadow_report_path, _ = _find_latest_by_prefix(
            reports_dir, 'shadow_run_report_', ('.txt', '.json'))
    if not shadow_index_path:
        shadow_index_path, _ = _find_latest_by_prefix(
            reports_dir, 'shadow_evidence_index_', ('.json',))
    if not phase_f_mismatch_path:
        phase_f_mismatch_path, _ = _find_latest_by_prefix(
            reports_dir, 'phase_f_mismatch_', ('.txt',))

    delivery_status_path = os.path.join(reports_dir, 'report_delivery_status.txt')
    if include_delivery_status:
        delivery_ok, _, delivery_path = open_report_delivery_status(repo_root)
        if delivery_ok and delivery_path:
            delivery_status_path = delivery_path
    if not os.path.isfile(delivery_status_path):
        delivery_status_path = ''

    return {
        'lab_root': lab_root,
        'reports_dir': reports_dir,
        'consolidated_ok': bool(consolidated_ok),
        'consolidated_message': consolidated_msg or '',
        'consolidated_path': consolidated_path or '',
        'audit_summary_txt': audit_summary_txt or '',
        'audit_summary_json': audit_summary_json or '',
        'audit_metrics_json': audit_metrics_json or '',
        'shadow_report_path': shadow_report_path or '',
        'shadow_index_path': shadow_index_path or '',
        'phase_f_mismatch_path': phase_f_mismatch_path or '',
        'delivery_status_path': delivery_status_path or '',
    }


def _collect_current_state_bundle_companion_files(repo_root, lab_root):
    """Return current-run companion artifacts referenced by diagnostics state."""
    state = _load_json_dict(os.path.join(lab_root or '.', 'diagnostics_state.json'))
    current_run_id = str(state.get('last_shadow_pipeline_run_id', '') or '').strip()
    files = []
    seen = set()
    if current_run_id:
        try:
            ok, _msg, snapshot = _build_run_artifact_snapshot(repo_root, run_id=current_run_id)
        except Exception:
            ok, snapshot = False, None
        if ok and isinstance(snapshot, dict):
            for path in snapshot.get('artifact_files', []):
                _append_unique_path(files, seen, path)
            for path in snapshot.get('context_files', []):
                _append_unique_path(files, seen, path)
    lock_diag_path = str(state.get('last_phase_f_lock_diag_path', '') or '').strip()
    if lock_diag_path:
        _append_unique_path(files, seen, lock_diag_path)
    return files



def _build_phase_f_lock_context_lines(lab_root):
    """Return compact inline lock context when the latest Phase F failed on lock acquisition."""
    state = _load_json_dict(os.path.join(lab_root or '.', 'diagnostics_state.json'))
    error_code = str(
        state.get('last_shadow_pipeline_error_code', '') or state.get('last_error_code', '') or ''
    ).strip().upper()
    if error_code != 'PHASE_F_LOCK_FAIL':
        return []

    diag_path = str(state.get('last_phase_f_lock_diag_path', '') or '').strip()
    diag_exists = bool(diag_path and os.path.isfile(diag_path))
    diag = _load_json_dict(diag_path) if diag_exists else {}
    parts = []
    reason = str(diag.get('reason', '') or '').strip()
    if reason:
        parts.append('reason={0}'.format(reason))
    if 'lock_owner_running' in diag:
        parts.append('owner_running={0}'.format(bool(diag.get('lock_owner_running'))))
    if 'lock_heartbeat_stale' in diag:
        parts.append('heartbeat_stale={0}'.format(bool(diag.get('lock_heartbeat_stale'))))
    pid = str(diag.get('lock_pid', '') or '').strip()
    if pid:
        parts.append('pid={0}'.format(pid))
    if not parts:
        detail = str(state.get('last_error_detail', '') or '').strip()
        if detail:
            parts.append('detail={0}'.format(detail))
    if diag_path:
        label = os.path.basename(diag_path)
        if not diag_exists:
            label += ' (missing)'
        parts.append('diag={0}'.format(label))
    return ['Phase F lock context: {0}'.format(', '.join(parts) if parts else 'diagnostics unavailable')]


def _load_shadow_report_machine_context(shadow_report_path):
    """Return machine/runtime fingerprint from latest shadow_run_report JSON when available."""
    path = str(shadow_report_path or '').strip()
    if not path:
        return {}
    candidate_paths = [path]
    if path.lower().endswith('.txt'):
        candidate_paths.insert(0, path[:-4] + '.json')
    for candidate in candidate_paths:
        data = _load_json_dict(candidate)
        if not data:
            continue
        out = {}
        for key in (
                'machine_hostname',
                'machine_app_version',
                'machine_python_version',
                'machine_platform',
                'machine_test_mode'):
            if key in data:
                out[key] = data.get(key)
        if out:
            return out
    return {}


def open_latest_system_health_pack(repo_root, env_flag_fn, include_delivery_status=False, progress_callback=None):
    """
    Build and return latest combined system-health pack text snapshot.
    Includes current pipeline health, latest migration-audit hints, and artifact pointers.
    """
    try:
        _emit_progress(progress_callback, 'locating latest artifacts')
        artifacts = _collect_system_health_artifacts(
            repo_root, env_flag_fn, include_delivery_status=include_delivery_status)
        if isinstance(artifacts, dict):
            artifacts['repo_root'] = repo_root
        lab_root = artifacts.get('lab_root')
        reports_dir = artifacts.get('reports_dir')
        pack_context = _build_system_health_pack_context(lab_root, reports_dir, artifacts)

        _emit_progress(progress_callback, 'reading health snapshot')
        health_lines = get_health_lines(lab_root, env_flag_fn)
        hints = []
        audit_payload = _load_json_dict(artifacts.get('audit_summary_json'))
        if audit_payload:
            hints = _audit_hint_lines_from_payload(audit_payload)
        alignment = _build_system_health_alignment_notes(lab_root, reports_dir, artifacts, audit_payload)

        lines = []
        lines.append('System Health Pack')
        lines.append('generated_at_utc={0}'.format(time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())))
        lines.append('lab_root={0}'.format(lab_root or '(unset)'))
        lines.append('pack_anchor_run_id={0}'.format(pack_context.get('anchor_run_id', '') or '-'))
        lines.append('pack_scope={0}'.format(pack_context.get('pack_scope', '') or 'unknown'))
        if pack_context.get('active_run_id'):
            lines.append('pack_live_active_run_id={0}'.format(pack_context.get('active_run_id')))
        if pack_context.get('expected_shadow_run_id'):
            lines.append('pack_last_completed_run_id={0}'.format(pack_context.get('expected_shadow_run_id')))
        machine_ctx = _load_shadow_report_machine_context(pack_context.get('anchor_report_path') or artifacts.get('shadow_report_path'))
        if machine_ctx:
            lines.append(
                'machine_fingerprint=host:{0}, app_version:{1}, python:{2}, platform:{3}, test_mode:{4}'.format(
                    machine_ctx.get('machine_hostname', '') or '-',
                    machine_ctx.get('machine_app_version', '') or '-',
                    machine_ctx.get('machine_python_version', '') or '-',
                    machine_ctx.get('machine_platform', '') or '-',
                    machine_ctx.get('machine_test_mode', 'unknown') if machine_ctx.get('machine_test_mode') is not None else 'unknown',
                )
            )
        lines.append('')
        lines.append('Latest artifacts:')
        lines.append(' - consolidated_snapshot={0}'.format(artifacts.get('consolidated_path') or '(missing)'))
        lines.append(' - migration_audit_summary_txt={0}'.format(artifacts.get('audit_summary_txt') or '(missing)'))
        lines.append(' - migration_audit_summary_json={0}'.format(artifacts.get('audit_summary_json') or '(missing)'))
        lines.append(' - migration_audit_metrics_json={0}'.format(artifacts.get('audit_metrics_json') or '(missing)'))
        lines.append(' - shadow_run_report={0}'.format(artifacts.get('shadow_report_path') or '(missing)'))
        lines.append(' - shadow_evidence_index={0}'.format(artifacts.get('shadow_index_path') or '(missing)'))
        lines.append(' - phase_f_mismatch={0}'.format(artifacts.get('phase_f_mismatch_path') or '(missing)'))
        if artifacts.get('delivery_status_path'):
            lines.append(' - report_delivery_status={0}'.format(artifacts.get('delivery_status_path')))
        if artifacts.get('consolidated_message') and not artifacts.get('consolidated_ok'):
            lines.append(' - consolidated_snapshot_refresh_error={0}'.format(artifacts.get('consolidated_message')))

        lines.append('')
        lines.extend(_build_anchor_run_snapshot_lines(pack_context))

        if _should_show_latest_live_pipeline_attempt(pack_context):
            lines.append('')
            lines.extend(_build_latest_live_pipeline_attempt_lines(pack_context))

        lines.append('')
        scope = pack_context.get('pack_scope', '') or ''
        state_for_pack = pack_context.get('state') if isinstance(pack_context.get('state'), dict) else {}
        interrupted_pack = str(state_for_pack.get('last_shadow_pipeline_outcome', '') or '').strip().lower() == 'interrupted'
        mixed_or_interrupt = scope == 'mixed_scope' or interrupted_pack
        if mixed_or_interrupt:
            lines.append('Latest completed phase summaries (from live diagnostics state):')
        elif scope == 'live_current_state':
            lines.append('Pipeline health snapshot (live current state):')
        else:
            lines.append('Pipeline health snapshot:')
        lines.extend(health_lines or [])
        lines.append('Note: phase detail rows B..E reflect per-run summary counts from the live diagnostics state file; the data plane section below is cumulative lab state.')
        if scope == 'mixed_scope':
            lines.append(
                'Note: when a newer live run differs from the anchored completed run, B..E rows above still describe the last completed phase telemetry captured in diagnostics; '
                'the anchored completed-run block above is the authoritative run-scoped evidence for the anchor run_id.'
            )
        if interrupted_pack:
            lines.append(
                'Note: the pipeline ended in an interruption; a newer live run may have ended before fresh per-phase summaries were written. Use the anchored completed-run block and Latest live pipeline attempt section for interpretation.'
            )

        lines.append('')
        lines.append('Migration audit quick hints:')
        for note in alignment.get('notes', []):
            lines.append(' - {0}'.format(note))
        for note in _build_phase_f_lock_context_lines(lab_root):
            lines.append(' - {0}'.format(note))
        if alignment.get('audit_stale'):
            lines.append(' - audit hints suppressed because audit summary is older than current completed-run evidence.')
        elif hints:
            for hint in hints:
                lines.append(' - {0}'.format(hint))
        else:
            lines.append(' - none (run migration health audit to populate hints)')
        lines.append('')
        lines.extend(_build_recent_shadow_run_actual_lines(
            reports_dir,
            limit=4,
            expected_run_id=alignment.get('expected_shadow_run_id', ''),
        ))
        recommendation = {}
        try:
            ok_ev, msg_ev, eval_snap, rec_meta = _select_evaluation_snapshot_for_recommendation(repo_root, pack_context)
            prov = []
            if isinstance(rec_meta, dict):
                if rec_meta.get('fallback_note'):
                    prov.append(rec_meta.get('fallback_note'))
                if rec_meta.get('newer_live_context_note'):
                    prov.append(rec_meta.get('newer_live_context_note'))
                pr = rec_meta.get('pipeline_running')
                if pr is None:
                    pr = is_pipeline_running(lab_root)
            else:
                pr = is_pipeline_running(lab_root)
                rec_meta = {}
            recommendation = compute_operator_support_send_recommendation_core(
                repo_root,
                eval_snap,
                ok_ev,
                msg_ev,
                pr,
                recommendation_source_scope=str(rec_meta.get('recommendation_source_scope', '') or 'latest_live_snapshot'),
                recommendation_anchor_run_id=str(rec_meta.get('recommendation_anchor_run_id', '') or ''),
                recommendation_live_run_id=str(rec_meta.get('live_run_id', '') or ''),
                recommendation_live_run_status=str(rec_meta.get('live_run_status', '') or ''),
                provenance_extra_lines=prov,
            )
            if not isinstance(recommendation, dict):
                recommendation = {}
        except Exception:
            recommendation = {}
        rec_lines = _artifact_tools.format_recommended_action_lines(recommendation)
        if rec_lines:
            lines.append('')
            lines.extend(rec_lines)
        lines.append('')
        _emit_progress(progress_callback, 'sampling DB state')
        snap = _collect_data_plane_snapshot(lab_root)
        lines.extend(_build_db_enrichment_overview_lines(lab_root, snapshot=snap, compact=True))
        lines.append('')
        lines.append('Data plane snapshot (cumulative lab state):')
        if snap.get('ok'):
            patient_rows = _safe_int(snap.get('counts', {}).get('patient'), 0)
            patient_count = _safe_int(
                snap.get('patient_count_effective'),
                _safe_int(snap.get('patient_latest_identity_count'), patient_rows))
            qa_reject = _safe_int(
                snap.get('qa_reject_count_effective'),
                _safe_int(snap.get('qa_reject_count'), 0))
            projection_success = _safe_int(
                snap.get('projection_success_count_effective'),
                _safe_int(snap.get('projection_success_count'), 0))
            projection_reject = _safe_int(
                snap.get('projection_reject_count_effective'),
                _safe_int(snap.get('projection_reject_count'), 0))
            qa_scope = str(snap.get('qa_scope_version', '') or '').strip()
            projection_scope = str(snap.get('projection_scope_version', '') or '').strip()
            lines.append(' - db_status={0}'.format(snap.get('status', 'unknown')))
            lines.append(' - patient_count={0}'.format(patient_count))
            if patient_rows != patient_count:
                lines.append(' - patient_rows_raw={0}'.format(patient_rows))
            lines.append(' - qa_reject_count={0}'.format(qa_reject))
            lines.append(' - replay_pending_count={0}'.format(snap.get('replay_pending_count', 0)))
            lines.append(' - projection_success_count={0}'.format(projection_success))
            lines.append(' - projection_reject_count={0}'.format(projection_reject))
            if qa_scope or projection_scope:
                lines.append(
                    ' - quality_scope=qa_version:{0}, projection_version:{1}'.format(
                        qa_scope or '-',
                        projection_scope or '-'))
            lines.append(' - orphan_claim_lines={0}'.format(snap.get('orphan_claim_lines', 0)))
            opt_preview = []
            conn = None
            try:
                conn = sqlite3.connect(snap.get('db_path', ''))
                conn.execute("PRAGMA foreign_keys = ON")
                rows = _collect_patient_chain_rows(
                    conn,
                    limit=120,
                    projection_version_scope=projection_scope,
                )
                opts = _build_guided_patient_options(
                    rows,
                    _load_json_dict(os.path.join(lab_root or '.', 'diagnostics_state.json')),
                )
                for item in opts[:3]:
                    opt_preview.append(
                        '{0}:{1}(risk={2},missing={3})'.format(
                            item.get('code', '?'),
                            item.get('display_id', '-'),
                            item.get('risk_label', 'UNKNOWN'),
                            item.get('missing_count', 0),
                        )
                    )
            except Exception:
                pass
            finally:
                if conn is not None:
                    try:
                        conn.close()
                    except Exception:
                        pass
            if opt_preview:
                lines.append(' - guided_patient_options={0}'.format('; '.join(opt_preview)))
            else:
                lines.append(' - guided_patient_options=none')
        else:
            lines.append(' - db_status=FAIL ({0})'.format(snap.get('error', 'unknown')))
        lines.append('')
        for line in _build_system_health_pack_runbook(
                lab_root,
                audit_payload,
                artifacts,
                state_override=pack_context.get('anchor_state'),
                pack_scope=pack_context.get('pack_scope', ''),
                anchor_run_id=pack_context.get('anchor_run_id', '')):
            lines.append(line)

        path = os.path.join(reports_dir, 'system_health_pack_latest.txt')
        _emit_progress(progress_callback, 'writing pack file')
        with open(path, 'w', encoding='utf-8') as f:
            f.write('\n'.join(lines) + '\n')
        return (True, '', path)
    except Exception as e:
        return (False, str(e), None)


def run_system_health_triage(
        repo_root,
        python_exe,
        env,
        env_flag_fn,
        scope='both',
        cloud_required=False,
        migration_stage='xp_validation'):
    """
    Run migration audit and refresh latest system-health pack in one action.
    Returns (ok, msg, data) where data has hints and generated artifact paths.
    """
    audit_ok, audit_msg, audit_data = run_migration_health_audit(
        repo_root,
        python_exe,
        env,
        scope=scope,
        write_report=True,
        cloud_required=cloud_required,
        migration_stage=migration_stage,
    )
    pack_ok, pack_msg, pack_path = open_latest_system_health_pack(
        repo_root, env_flag_fn, include_delivery_status=False)

    hints = []
    if isinstance(audit_data, dict):
        hints = audit_data.get('hints', []) if isinstance(audit_data.get('hints', []), list) else []

    artifacts = []
    if pack_path:
        artifacts.append(pack_path)
    report_ok, _, report_path = open_latest_migration_health_report(repo_root)
    if report_ok and report_path:
        artifacts.append(report_path)

    overall_ok = bool(audit_ok and pack_ok)
    status_label = 'completed' if overall_ok else 'completed with issues'
    msg_parts = ['System health triage {0}.'.format(status_label)]
    if audit_msg:
        msg_parts.append(audit_msg)
    if pack_msg and not pack_ok:
        msg_parts.append(pack_msg)
    runbook = _build_system_health_triage_runbook(
        audit_ok=audit_ok,
        audit_data=audit_data if isinstance(audit_data, dict) else {},
        pack_ok=pack_ok,
        pack_path=pack_path,
        report_path=report_path if report_ok else '',
    )
    msg_parts.append('decision={0}'.format(runbook.get('decision', 'NO_GO')))
    if runbook.get('top_blocker'):
        msg_parts.append('blocker={0}'.format(runbook.get('top_blocker')))
    msg = ' '.join(msg_parts)
    return (overall_ok, msg, {
        'hints': hints,
        'artifacts': artifacts,
        'audit_ok': bool(audit_ok),
        'pack_ok': bool(pack_ok),
        'runbook': runbook,
        'runbook_lines': runbook.get('lines', []),
    })


def send_latest_system_health_pack(repo_root, env_flag_fn, progress_callback=None):
    """
    Send latest consolidated system-health pack and related artifacts.
    On send failure, caller can open returned delivery_status_path for diagnostics.
    """
    lab_root = resolve_lab_root(repo_root)
    delivery_path = ''
    _emit_progress(progress_callback, 'checking delivery preflight')
    preflight_diag = _collect_delivery_diagnostics()
    preflight_runbook = _build_delivery_runbook_lines(preflight_diag)
    if collect_support_bundle is None or submit_support_bundle_email is None:
        return (False, 'Support bundle tools unavailable.', {
            'delivery_status_path': delivery_path,
            'pre_send_runbook_lines': preflight_runbook,
            'delivery_diag': preflight_diag,
        })

    reports_err = _reports_dir_access_error(lab_root)
    if reports_err:
        return (False, reports_err, {
            'delivery_status_path': delivery_path,
            'pre_send_runbook_lines': preflight_runbook,
            'delivery_diag': preflight_diag,
        })

    _emit_progress(progress_callback, 'building system health pack')
    ok_pack, msg_pack, pack_path = open_latest_system_health_pack(
        repo_root, env_flag_fn, include_delivery_status=True, progress_callback=progress_callback)
    if not ok_pack:
        return (False, msg_pack or 'Unable to build system health pack.', {
            'delivery_status_path': delivery_path,
            'pre_send_runbook_lines': preflight_runbook,
            'delivery_diag': preflight_diag,
        })

    _emit_progress(progress_callback, 'collecting attachments')
    artifacts = _collect_system_health_artifacts(
        repo_root, env_flag_fn, include_delivery_status=True)
    delivery_path = artifacts.get('delivery_status_path') or ''

    extra_files = []
    seen = set()
    _add_unique_file(extra_files, seen, pack_path, alias='system_health_pack_latest.txt')
    _add_unique_file(extra_files, seen, artifacts.get('consolidated_path'))
    _add_unique_file(extra_files, seen, artifacts.get('audit_summary_txt'))
    _add_unique_file(extra_files, seen, artifacts.get('audit_summary_json'))
    _add_unique_file(extra_files, seen, artifacts.get('audit_metrics_json'))
    _add_unique_file(extra_files, seen, artifacts.get('delivery_status_path'))

    phase_files = _select_latest_evidence_files(lab_root, [
        ('shadow_run_report_', None),
        ('shadow_evidence_index_', '.json'),
        ('phase_f_mismatch_', '.txt'),
    ])
    if not phase_files and artifacts.get('phase_f_mismatch_path'):
        phase_files = [(os.path.basename(artifacts.get('phase_f_mismatch_path')), artifacts.get('phase_f_mismatch_path'))]
    for basename, fullpath in phase_files:
        _add_unique_file(extra_files, seen, fullpath, alias=basename)

    for path in _latest_interrupt_report_paths(lab_root):
        _add_unique_file(extra_files, seen, path, alias=os.path.basename(path))

    for fullpath in _collect_current_state_bundle_companion_files(repo_root, lab_root):
        _add_unique_file(extra_files, seen, fullpath)

    for ctx_name in ('diagnostics_state.json', 'run_cursor.json'):
        _add_unique_file(extra_files, seen, os.path.join(lab_root, ctx_name), alias=ctx_name)

    if not extra_files:
        return (False, 'No system health artifacts found to attach.', {
            'delivery_status_path': delivery_path,
            'pre_send_runbook_lines': preflight_runbook,
            'delivery_diag': preflight_diag,
        })

    try:
        _emit_progress(progress_callback, 'creating zip bundle')
        zip_path = collect_support_bundle(
            include_traceback=False,
            extra_meta={
                'system_health_pack': True,
                'send_source': 'manual_system_health_pack',
                'lab_root': lab_root,
                'email_delivery_preflight': preflight_diag,
            },
            extra_files=extra_files,
            progress_callback=progress_callback,
        )
        if not zip_path:
            return (False, 'Failed to create support bundle.', {
                'delivery_status_path': delivery_path,
                'pre_send_runbook_lines': preflight_runbook,
                'delivery_diag': preflight_diag,
            })
        ok_send, msg_send, _ = _submit_bundle_with_delivery_diagnostics(
            zip_path=zip_path,
            allow_interactive_reauth=True,
            progress_callback=progress_callback,
        )
        return (ok_send, msg_send, {
            'delivery_status_path': delivery_path,
            'pre_send_runbook_lines': preflight_runbook,
            'delivery_diag': preflight_diag,
        })
    except Exception as e:
        return (False, 'Error: {0}'.format(e), {
            'delivery_status_path': delivery_path,
            'pre_send_runbook_lines': preflight_runbook,
            'delivery_diag': preflight_diag,
        })


_ARTIFACT_PHASE_LAYOUT = _artifact_tools.ARTIFACT_PHASE_LAYOUT


def _append_unique_path(paths, seen, path):
    return _artifact_tools.append_unique_path(paths, seen, path)


def _safe_run_token(run_id):
    return _artifact_tools.safe_run_token(run_id)


def _collect_group_paths_for_run(reports_dir, run_id, group):
    return _artifact_tools.collect_group_paths_for_run(reports_dir, run_id, group)


def _collect_artifact_run_candidates(reports_dir):
    return _artifact_tools.collect_artifact_run_candidates(
        reports_dir,
        artifact_phase_layout=_ARTIFACT_PHASE_LAYOUT,
    )


def _recent_artifact_run_ids(reports_dir, limit=20):
    return _artifact_tools.recent_artifact_run_ids(
        reports_dir,
        limit=limit,
        collect_artifact_run_candidates_fn=_collect_artifact_run_candidates,
    )


def _run_has_required_artifacts(reports_dir, run_id):
    return _artifact_tools.run_has_required_artifacts(
        reports_dir,
        run_id,
        artifact_phase_layout=_ARTIFACT_PHASE_LAYOUT,
        collect_group_paths_for_run_fn=_collect_group_paths_for_run,
    )


def _find_latest_complete_artifact_run_id(reports_dir, exclude_run_id=''):
    return _artifact_tools.find_latest_complete_artifact_run_id(
        reports_dir,
        exclude_run_id=exclude_run_id,
        recent_artifact_run_ids_fn=_recent_artifact_run_ids,
        run_has_required_artifacts_fn=_run_has_required_artifacts,
    )


def _find_latest_artifact_run_id(reports_dir):
    return _artifact_tools.find_latest_artifact_run_id(
        reports_dir,
        collect_artifact_run_candidates_fn=_collect_artifact_run_candidates,
    )


def _build_run_artifact_snapshot(repo_root, run_id=''):
    return _artifact_tools.build_run_artifact_snapshot(
        repo_root,
        run_id=run_id,
        resolve_lab_root_fn=resolve_lab_root,
        reports_dir_access_error_fn=_reports_dir_access_error,
        find_latest_artifact_run_id_fn=_find_latest_artifact_run_id,
        load_json_dict_fn=_load_json_dict,
        find_latest_complete_artifact_run_id_fn=_find_latest_complete_artifact_run_id,
        recent_artifact_run_ids_fn=_recent_artifact_run_ids,
        is_pipeline_running_fn=is_pipeline_running,
        artifact_phase_layout=_ARTIFACT_PHASE_LAYOUT,
        collect_group_paths_for_run_fn=_collect_group_paths_for_run,
        append_unique_path_fn=_append_unique_path,
    )


def _recommended_action_for_snapshot(snapshot):
    """
    Operator recommendation for a run evidence snapshot (triage, run artifact index).
    Anchor the evaluated run_id so milestone_verdict / evidence_coherence match the opened snapshot,
    not an unanchored summary.
    """
    rec = None
    repo_root = str((snapshot or {}).get('repo_root', '') or '').strip()
    if repo_root:
        try:
            lab_root = str((snapshot or {}).get('lab_root', '') or '').strip() or resolve_lab_root(repo_root)
            pipeline_running = is_pipeline_running(lab_root)
            state = _load_json_dict(os.path.join(lab_root, 'diagnostics_state.json'))
            live_id = str((snapshot or {}).get('run_id', '') or '').strip()
            live_status = _derive_live_pipeline_status(state, pipeline_running)
            eval_snap = snapshot if isinstance(snapshot, dict) else {}
            if live_id:
                eval_snap = _relax_snapshot_diagnostics_for_anchor_evaluation(eval_snap, live_id)
            rec = compute_operator_support_send_recommendation_core(
                repo_root,
                eval_snap,
                True,
                '',
                pipeline_running,
                recommendation_source_scope='latest_live_snapshot',
                recommendation_anchor_run_id=live_id,
                recommendation_live_run_id=live_id,
                recommendation_live_run_status=live_status,
            )
        except Exception:
            rec = None
    return rec


def _write_run_artifact_index(snapshot, latest_alias=False, recommended_action=None):
    return _artifact_tools.write_run_artifact_index(
        snapshot, latest_alias=latest_alias, recommended_action=recommended_action)


def _write_artifact_triage_pack(snapshot, latest_alias=False, recommended_action=None):
    rec = recommended_action if recommended_action is not None else _recommended_action_for_snapshot(snapshot)
    return _artifact_tools.write_artifact_triage_pack(snapshot, latest_alias=latest_alias, recommended_action=rec)


def _artifact_bundle_quality(snapshot):
    return _artifact_tools.artifact_bundle_quality(snapshot)


def _build_run_id_diagnostics(snapshot, requested_run_id):
    return _artifact_tools.build_run_id_diagnostics(snapshot, requested_run_id)


def open_latest_artifact_triage_pack(repo_root, progress_callback=None):
    """Generate and return triage pack for latest run-scoped artifact set."""
    _emit_progress(progress_callback, 'building run evidence snapshot')
    ok, msg, snapshot = _build_run_artifact_snapshot(repo_root, run_id='')
    if not ok:
        return (False, msg, None)
    try:
        path = _write_artifact_triage_pack(snapshot, latest_alias=True)
        return (True, '', path)
    except Exception as e:
        return (False, str(e), None)


def open_latest_run_artifact_index(repo_root, progress_callback=None):
    """Generate and return run artifact index for latest run-scoped artifact set."""
    _emit_progress(progress_callback, 'building run evidence snapshot')
    ok, msg, snapshot = _build_run_artifact_snapshot(repo_root, run_id='')
    if not ok:
        return (False, msg, None)
    try:
        rec = _recommended_action_for_snapshot(snapshot)
        path = _write_run_artifact_index(snapshot, latest_alias=True, recommended_action=rec)
        return (True, '', path)
    except Exception as e:
        return (False, str(e), None)


def open_run_artifact_index_for_run_id(repo_root, run_id):
    """Generate and return run artifact index for explicit run_id."""
    run_id = str(run_id or '').strip()
    if not run_id:
        return (False, 'Run ID is required.', None)
    ok, msg, snapshot = _build_run_artifact_snapshot(repo_root, run_id=run_id)
    if not ok:
        lab_root = resolve_lab_root(repo_root)
        reports_dir = os.path.join(lab_root, 'reports')
        diag_snapshot = {
            'recent_run_ids': _recent_artifact_run_ids(reports_dir, limit=12),
            'nearest_complete_run_id': _find_latest_complete_artifact_run_id(reports_dir, exclude_run_id=''),
            'diagnostics_state': _load_json_dict(os.path.join(lab_root, 'diagnostics_state.json')),
        }
        diag_msg = _build_run_id_diagnostics(diag_snapshot, run_id)
        full_msg = '{0} {1}'.format(msg, diag_msg).strip()
        return (False, full_msg, None)
    try:
        rec = _recommended_action_for_snapshot(snapshot)
        path = _write_run_artifact_index(snapshot, latest_alias=False, recommended_action=rec)
        return (True, '', path)
    except Exception as e:
        return (False, str(e), None)


def _latest_phase_d_reprocess_report_paths(lab_root):
    reports_dir = os.path.join(str(lab_root or ''), 'reports')
    paths = []
    for name in (
            'phase_d_historical_reprocess_preview_latest.txt',
            'phase_d_historical_reprocess_execution_latest.txt'):
        path = os.path.join(reports_dir, name)
        if os.path.isfile(path):
            paths.append(path)
    return paths


def _parse_remediation_context_run_id_from_phase_d_report(path):
    """Return remediation_context_run_id= value from report header, or ''."""
    if not path or not os.path.isfile(path):
        return ''
    try:
        with open(path, 'r', encoding='utf-8') as f:
            for _ in range(64):
                line = f.readline()
                if not line:
                    break
                s = str(line or '').strip()
                if s.startswith('remediation_context_run_id='):
                    return s.split('=', 1)[1].strip()
    except (IOError, OSError, UnicodeError):
        pass
    return ''


def _phase_d_reprocess_report_paths_for_run_evidence(lab_root, recommendation, bundle_run_id):
    """
    Attach Phase D historical reprocess preview/execution *_latest.txt only when the embedded
    recommendation calls for historical reprocess, both files exist, they agree on the same
    non-empty remediation_context_run_id= line, and that id matches bundle_run_id or
    recommendation_anchor_run_id. Reports without the line (pre-upgrade aliases) are never attached.
    """
    rec = recommendation if isinstance(recommendation, dict) else {}
    if str(rec.get('recommended_action_kind') or '').strip() != 'historical_phase_d_reprocess':
        return []
    reports_dir = os.path.join(str(lab_root or ''), 'reports')
    preview_path = os.path.join(reports_dir, 'phase_d_historical_reprocess_preview_latest.txt')
    exec_path = os.path.join(reports_dir, 'phase_d_historical_reprocess_execution_latest.txt')
    if not (os.path.isfile(preview_path) and os.path.isfile(exec_path)):
        return []
    rid_p = _parse_remediation_context_run_id_from_phase_d_report(preview_path)
    rid_e = _parse_remediation_context_run_id_from_phase_d_report(exec_path)
    if not rid_p or not rid_e or rid_p != rid_e:
        return []
    bundle = str(bundle_run_id or '').strip()
    anchor = str(rec.get('recommendation_anchor_run_id') or '').strip()
    if (bundle and rid_p == bundle) or (anchor and rid_p == anchor):
        return [preview_path, exec_path]
    return []


def _latest_interrupt_report_paths(lab_root, bundle_run_id=None):
    """
    Latest interrupt alias files under lab/reports.
    When bundle_run_id is set (run evidence), only include them if JSON embeds the same run_id.
    """
    reports_dir = os.path.join(str(lab_root or ''), 'reports')
    jpath = os.path.join(reports_dir, 'shadow_pipeline_interrupt_latest.json')
    tpath = os.path.join(reports_dir, 'shadow_pipeline_interrupt_latest.txt')
    br = str(bundle_run_id or '').strip()
    if br:
        if not os.path.isfile(jpath):
            return []
        data = _load_json_dict(jpath)
        emb = str(data.get('run_id', '') or '').strip()
        if not emb or emb != br:
            return []
    paths = []
    for path in (jpath, tpath):
        if os.path.isfile(path):
            paths.append(path)
    return paths



def _write_run_evidence_dat_smoke_note(repo_root, reports_dir, bundle_run_id, recommendation, smoke_state, deferred_smoke, attached_paths):
    token = _artifact_tools.safe_run_token(bundle_run_id)
    path = os.path.join(reports_dir, 'run_evidence_dat_smoke_note_{0}.txt'.format(token))
    rec = recommendation if isinstance(recommendation, dict) else {}
    preview = rec.get('action_preview') if isinstance(rec.get('action_preview'), dict) else {}
    state = smoke_state if isinstance(smoke_state, dict) else {}
    deferred = deferred_smoke if isinstance(deferred_smoke, dict) else {}
    lines = [
        'Run Evidence DAT Smoke Note',
        'generated_at_utc={0}'.format(time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())),
        'bundle_run_id={0}'.format(bundle_run_id or '-'),
        'recommended_action_kind={0}'.format(str(rec.get('recommended_action_kind', '') or 'send_bundle')),
        'dat_smoke_evaluated={0}'.format(bool(rec.get('dat_smoke_evaluated'))),
        'dat_smoke_available={0}'.format(bool(rec.get('dat_smoke_available'))),
        'dat_smoke_not_triggered_reason={0}'.format(str(rec.get('dat_smoke_not_triggered_reason', '') or '-') or '-'),
        'follow_on_action_kind={0}'.format(str(rec.get('follow_on_action_kind', '') or '-')),
        'target_anchor_run_id={0}'.format(str(preview.get('anchor_run_id', '') or rec.get('recommendation_anchor_run_id', '') or bundle_run_id or '-')),
        'target_context_run_id={0}'.format(str(preview.get('phase_d_context_run_id', '') or '-')),
        'smoke_reports_dir={0}'.format(str(preview.get('smoke_reports_dir', '') or os.path.join(str(preview.get('smoke_lab_root', '') or ''), 'reports') or '-')),
        'expected_report_path={0}'.format(str(preview.get('expected_report_path', '') or '-')),
        'reference_phase_d_summary_path={0}'.format(str(preview.get('reference_phase_d_summary_path', '') or '-')),
        'state_path={0}'.format(phase_d_dat_smoke_state_path(repo_root) if repo_root else '-'),
        'state_last_status={0}'.format(str(state.get('last_status', '') or '-')),
        'state_last_report_path={0}'.format(str(state.get('last_report_path', '') or '-')),
        'state_last_assessment={0}'.format(str(state.get('last_assessment', '') or '-')),
        'state_cooldown_until_utc={0}'.format(str(state.get('cooldown_until_utc', '') or '-')),
        'deferred_path={0}'.format(operator_deferred_phase_d_dat_smoke_path(repo_root) if deferred and repo_root else '-'),
        'deferred_anchor_run_id={0}'.format(str(deferred.get('anchor_run_id', '') or '-')),
        'deferred_context_run_id={0}'.format(str(deferred.get('context_run_id', '') or '-')),
        'deferred_issue_code={0}'.format(str(deferred.get('issue_code', '') or '-')),
        'deferred_reason={0}'.format(str(deferred.get('reason', '') or '-') or '-'),
        'attached_smoke_artifact_count={0}'.format(len(attached_paths or [])),
    ]
    for item in attached_paths or []:
        lines.append('attached_smoke_artifact={0}'.format(item))
    with open(path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines) + '\n')
    return path



def _write_run_evidence_smoke_anchor_mismatch_note(
        repo_root,
        reports_dir,
        bundle_run_id,
        reviewed_anchor,
        smoke_anchor,
        last_report_path,
        smoke_status='',
        smoke_assessment='',
        detail=''):
    token = _artifact_tools.safe_run_token(bundle_run_id)
    path = os.path.join(reports_dir, 'run_evidence_smoke_anchor_mismatch_{0}.txt'.format(token))
    lines = [
        'Run Evidence Smoke Anchor Mismatch',
        'generated_at_utc={0}'.format(time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())),
        'bundle_run_id={0}'.format(bundle_run_id or '-'),
        'reviewed_anchor_run_id={0}'.format(reviewed_anchor or '-'),
        'smoke_report_anchor_run_id={0}'.format(smoke_anchor or '-'),
        'last_report_path={0}'.format(last_report_path or '-'),
        'smoke_state_last_status={0}'.format(str(smoke_status or '').strip() or '-'),
        'smoke_state_last_assessment={0}'.format(str(smoke_assessment or '').strip() or '-'),
    ]
    detail = str(detail or '').strip()
    if detail:
        lines.append('detail={0}'.format(detail))
    lines.append(
        'note=Smoke artifacts were not attached because the smoke report does not match the reviewed anchor. '
        'Use the anchored qa_canonical_summary and shadow_run_report for the reviewed run.'
    )
    try:
        with open(path, 'w', encoding='utf-8') as f:
            f.write('\n'.join(lines) + '\n')
        return path
    except (IOError, OSError):
        return ''


def _phase_d_dat_smoke_report_paths_for_run_evidence(repo_root, lab_root, recommendation, bundle_run_id):
    rec = recommendation if isinstance(recommendation, dict) else {}
    reports_dir = os.path.join(str(lab_root or ''), 'reports')
    if not reports_dir:
        return []
    preview = rec.get('action_preview') if isinstance(rec.get('action_preview'), dict) else {}
    bundle = str(bundle_run_id or '').strip()
    target_anchor = str(preview.get('anchor_run_id', '') or rec.get('recommendation_anchor_run_id', '') or bundle).strip()
    rec_kind = str(rec.get('recommended_action_kind', '') or '').strip()
    smoke_lab_root = str(preview.get('smoke_lab_root', '') or os.path.join(repo_root, 'phase_d_dat_smoke_lab')).strip()
    smoke_reports_dir = str(preview.get('smoke_reports_dir', '') or os.path.join(smoke_lab_root, 'reports')).strip()
    state = read_phase_d_dat_smoke_state(repo_root)
    if not isinstance(state, dict):
        state = {}
    deferred = read_operator_deferred_phase_d_dat_smoke(repo_root)
    if not isinstance(deferred, dict):
        deferred = {}
    paths = []
    seen = set()

    def _remember(path_value):
        path_value = str(path_value or '').strip()
        if not path_value or not os.path.isfile(path_value) or path_value in seen:
            return
        seen.add(path_value)
        paths.append(path_value)

    # Strict same-anchor smoke packaging for QA full-block review: no out-of-scope persuasive smoke files.
    if rec_kind == 'review_dat_qa_full_block':
        reviewed = str(rec.get('recommendation_anchor_run_id') or preview.get('anchor_run_id') or bundle).strip()
        last_report_path = str(state.get('last_report_path', '') or '').strip()
        report_json_path = ''
        smoke_payload = {}
        smoke_status = str(state.get('last_status', '') or '').strip().lower()
        smoke_assessment = str(state.get('last_assessment', '') or '').strip()
        if last_report_path and os.path.isfile(last_report_path):
            root, ext = os.path.splitext(last_report_path)
            if ext.lower() == '.json':
                report_json_path = last_report_path
            else:
                report_json_path = root + '.json'
        if report_json_path and os.path.isfile(report_json_path):
            smoke_payload = _load_json_dict(report_json_path)
        smoke_anchor = str((smoke_payload or {}).get('anchor_run_id', '') or '').strip()
        smoke_ok = (
            reviewed
            and smoke_anchor
            and smoke_anchor == reviewed
            and smoke_status == 'completed'
            and str(smoke_assessment or (smoke_payload or {}).get('assessment', '') or '').strip() == 'dat_selected_qa_blocked'
        )
        if not smoke_ok:
            smoke_assessment_effective = str(smoke_assessment or (smoke_payload or {}).get('assessment', '') or '').strip()
            mismatch_reasons = []
            if not reviewed:
                mismatch_reasons.append('reviewed_anchor_run_id_missing')
            if not last_report_path:
                mismatch_reasons.append('state_last_report_path_missing')
            elif not os.path.isfile(last_report_path):
                mismatch_reasons.append('state_last_report_path_not_found')
            if last_report_path and not report_json_path:
                mismatch_reasons.append('smoke_report_json_path_missing')
            elif report_json_path and not os.path.isfile(report_json_path):
                mismatch_reasons.append('smoke_report_json_not_found')
            if smoke_status != 'completed':
                mismatch_reasons.append('state_last_status={0}'.format(smoke_status or '-'))
            if smoke_assessment_effective != 'dat_selected_qa_blocked':
                mismatch_reasons.append('smoke_assessment={0}'.format(smoke_assessment_effective or '-'))
            if not smoke_anchor:
                mismatch_reasons.append('smoke_report_anchor_run_id_missing')
            elif reviewed and smoke_anchor != reviewed:
                mismatch_reasons.append(
                    'smoke_report_anchor_mismatch reviewed={0} smoke={1}'.format(reviewed, smoke_anchor)
                )
            mm = _write_run_evidence_smoke_anchor_mismatch_note(
                repo_root,
                reports_dir,
                bundle,
                reviewed,
                smoke_anchor,
                last_report_path,
                smoke_status=smoke_status,
                smoke_assessment=smoke_assessment_effective,
                detail='; '.join(mismatch_reasons) or 'smoke_not_accepted_for_review_dat_qa_full_block',
            )
            if mm:
                _remember(mm)
            return paths

        state_path = phase_d_dat_smoke_state_path(repo_root)
        if os.path.isfile(state_path):
            _remember(state_path)
        if last_report_path and os.path.isfile(last_report_path):
            _remember(last_report_path)
            root, ext = os.path.splitext(last_report_path)
            sibling = root + ('.json' if ext.lower() == '.txt' else '.txt')
            _remember(sibling)
        if smoke_reports_dir and smoke_anchor:
            sp_run = str((smoke_payload or {}).get('smoke_pipeline_run_id') or (smoke_payload or {}).get('run_id') or '').strip()
            for rid in (sp_run, smoke_anchor):
                if not rid:
                    continue
                for suffix in ('.json', '.txt'):
                    p = os.path.join(smoke_reports_dir, 'phase_d_dat_smoke_report_{0}{1}'.format(rid, suffix))
                    _remember(p)
        if reports_dir and os.path.isdir(reports_dir):
            note_path = _write_run_evidence_dat_smoke_note(repo_root, reports_dir, bundle, rec, state, deferred, paths)
            _remember(note_path)
        return paths

    state_path = phase_d_dat_smoke_state_path(repo_root)
    if os.path.isfile(state_path):
        if str(rec.get('recommended_action_kind', '') or '').strip() == 'phase_d_dat_smoke' or bool(rec.get('dat_smoke_evaluated')) or str(rec.get('dat_smoke_not_triggered_reason', '') or '').strip() or str(state.get('last_status', '') or '').strip():
            _remember(state_path)

    deferred_path = operator_deferred_phase_d_dat_smoke_path(repo_root)
    if deferred and os.path.isfile(deferred_path):
        deferred_anchor = str(deferred.get('anchor_run_id', '') or '').strip()
        if not deferred_anchor or deferred_anchor == bundle or (target_anchor and deferred_anchor == target_anchor):
            _remember(deferred_path)

    if target_anchor and smoke_reports_dir:
        for suffix in ('.json', '.txt'):
            _remember(os.path.join(smoke_reports_dir, 'phase_d_dat_smoke_report_{0}{1}'.format(target_anchor, suffix)))
            _remember(os.path.join(smoke_reports_dir, 'shadow_run_report_{0}{1}'.format(target_anchor, suffix)))

    last_report_path = str(state.get('last_report_path', '') or '').strip()
    report_json_path = ''
    if last_report_path and os.path.isfile(last_report_path):
        _remember(last_report_path)
        root, ext = os.path.splitext(last_report_path)
        sibling = root + ('.json' if ext.lower() == '.txt' else '.txt')
        _remember(sibling)
        if ext.lower() == '.json':
            report_json_path = last_report_path
        else:
            report_json_path = root + '.json'
    if report_json_path and os.path.isfile(report_json_path):
        report_payload = _load_json_dict(report_json_path)
        smoke_anchor = str(report_payload.get('anchor_run_id', '') or '').strip()
        if smoke_anchor and smoke_reports_dir:
            for suffix in ('.json', '.txt'):
                _remember(os.path.join(smoke_reports_dir, 'phase_d_dat_smoke_report_{0}{1}'.format(smoke_anchor, suffix)))
                _remember(os.path.join(smoke_reports_dir, 'shadow_run_report_{0}{1}'.format(smoke_anchor, suffix)))

    should_note = bool(
        str(rec.get('recommended_action_kind', '') or '').strip() == 'phase_d_dat_smoke'
        or bool(rec.get('dat_smoke_evaluated'))
        or str(rec.get('dat_smoke_not_triggered_reason', '') or '').strip()
        or str(state.get('last_status', '') or '').strip()
        or deferred
    )
    if should_note and reports_dir and os.path.isdir(reports_dir):
        note_path = _write_run_evidence_dat_smoke_note(repo_root, reports_dir, bundle, rec, state, deferred, paths)
        _remember(note_path)
    return paths



def _write_run_evidence_context_note(reports_dir, bundle_run_id, pack_context, pack_path, pack_error=''):
    token = _artifact_tools.safe_run_token(bundle_run_id)
    path = os.path.join(reports_dir, 'run_evidence_context_note_{0}.txt'.format(token))
    lines = [
        'Run Evidence Context Note',
        'generated_at_utc={0}'.format(time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())),
        'bundle_run_id={0}'.format(bundle_run_id or '-'),
        'context_pack_path={0}'.format(pack_path or '(missing)'),
    ]
    if pack_error:
        lines.append('context_pack_error={0}'.format(pack_error))
    if isinstance(pack_context, dict):
        lines.append('context_pack_anchor_run_id={0}'.format(str(pack_context.get('anchor_run_id', '') or '-')))
        lines.append('context_pack_scope={0}'.format(str(pack_context.get('pack_scope', '') or 'unknown')))
        st = pack_context.get('state') if isinstance(pack_context.get('state'), dict) else {}
        anchor = str(pack_context.get('anchor_run_id', '') or '').strip()
        br = str(bundle_run_id or '').strip()
        if anchor and br and anchor != br:
            lines.append(
                'context_note=Recommendation and evidence may use anchored completed run_id={0}; bundle_run_id={1} differs.'
                .format(anchor, br))
            lines.append(
                'note=No matching anchored System Health Pack was attached because the latest health pack does not anchor to this run_id.'
            )
        if str(st.get('last_shadow_pipeline_outcome', '') or '').strip().lower() == 'interrupted':
            lines.append(
                'live_interruption=last pipeline outcome was interrupted; see shadow_pipeline_interrupt_latest.* under lab/reports if attached.'
            )
    else:
        lines.append('note=No matching anchored System Health Pack was attached because the latest health pack does not anchor to this run_id.')
    with open(path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines) + '\n')
    return path


def _collect_run_evidence_context_attachment(repo_root, snapshot, progress_callback=None):
    reports_dir = str((snapshot or {}).get('reports_dir', '') or '').strip()
    run_id = str((snapshot or {}).get('run_id', '') or '').strip()
    if not reports_dir or not run_id:
        return ('', None)
    pack_path = ''
    pack_error = ''
    try:
        _emit_progress(progress_callback, 'building anchored context pack')
        ok_pack, msg_pack, pack_path = open_latest_system_health_pack(
            repo_root,
            _default_env_flag,
            include_delivery_status=False,
            progress_callback=None,
        )
        if not ok_pack:
            pack_error = msg_pack or 'Unable to build System Health Pack.'
    except Exception as exc:
        pack_error = str(exc)
        pack_path = ''
    artifacts = _collect_system_health_artifacts(repo_root, _default_env_flag, include_delivery_status=False)
    if isinstance(artifacts, dict):
        artifacts['repo_root'] = repo_root
    pack_context = _build_system_health_pack_context(
        str((snapshot or {}).get('lab_root', '') or '').strip(),
        reports_dir,
        artifacts if isinstance(artifacts, dict) else {},
    )
    anchor_run_id = str((pack_context or {}).get('anchor_run_id', '') or '').strip()
    if pack_path and anchor_run_id and anchor_run_id == run_id:
        return (pack_path, pack_context)
    note_path = _write_run_evidence_context_note(reports_dir, run_id, pack_context, pack_path, pack_error=pack_error)
    return (note_path, pack_context)


def _write_run_evidence_anchor_resolution_note(repo_root, lab_root, anchor_run_id, error_detail):
    """Plain-text note when anchored run evidence snapshot cannot be built (fail-closed lineage)."""
    reports_dir = os.path.join(str(lab_root or ''), 'reports')
    if not reports_dir or not os.path.isdir(reports_dir):
        try:
            os.makedirs(reports_dir)
        except (OSError, IOError):
            return ''
    token = _artifact_tools.safe_run_token(anchor_run_id)
    path = os.path.join(reports_dir, 'run_evidence_anchor_resolution_failed_{0}.txt'.format(token))
    lines = [
        'Run Evidence Anchor Resolution Failed',
        'generated_at_utc={0}'.format(time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())),
        'requested_anchor_run_id={0}'.format(anchor_run_id or '-'),
        'detail={0}'.format(str(error_detail or '').strip() or '-'),
        'note=review_dat_qa_full_block bundles require a coherent artifact snapshot for this anchor; latest snapshot was not used as a fallback.',
    ]
    try:
        with open(path, 'w', encoding='utf-8') as f:
            f.write('\n'.join(lines) + '\n')
        return path
    except (IOError, OSError):
        return ''


def _review_dat_qa_full_block_forced_attachment_paths(recommendation):
    """Explicit QA paths from action_preview when present on disk."""
    rec = recommendation if isinstance(recommendation, dict) else {}
    preview = rec.get('action_preview') if isinstance(rec.get('action_preview'), dict) else {}
    out = []
    for key in ('phase_d_summary_path', 'qa_reject_samples_path', 'shadow_run_report_path'):
        p = str(preview.get(key) or '').strip()
        if p and os.path.isfile(p):
            out.append(p)
    return out


def send_latest_run_evidence_bundle(repo_root, progress_callback=None):
    """Send latest coherent run-scoped evidence bundle across phases B..F."""
    if collect_support_bundle is None or submit_support_bundle_email is None:
        return (False, 'Support bundle tools unavailable.', None)

    _emit_progress(progress_callback, 'building run evidence snapshot')
    ok, msg, snapshot = _build_run_artifact_snapshot(repo_root, run_id='')
    if not ok:
        return (False, msg, None)

    recommendation = {}
    try:
        lab_root_ev = str((snapshot or {}).get('lab_root', '') or '').strip() or resolve_lab_root(repo_root)
        reports_dir_ev = str((snapshot or {}).get('reports_dir', '') or '').strip()
        artifacts_ev = _collect_system_health_artifacts(repo_root, _default_env_flag, include_delivery_status=False)
        if isinstance(artifacts_ev, dict):
            artifacts_ev['repo_root'] = repo_root
        pack_ctx_ev = _build_system_health_pack_context(lab_root_ev, reports_dir_ev, artifacts_ev if isinstance(artifacts_ev, dict) else {})
        ok_ev, msg_ev, eval_snap, rec_meta = _select_evaluation_snapshot_for_recommendation(repo_root, pack_ctx_ev)
        prov = []
        if isinstance(rec_meta, dict):
            if rec_meta.get('fallback_note'):
                prov.append(rec_meta.get('fallback_note'))
            if rec_meta.get('newer_live_context_note'):
                prov.append(rec_meta.get('newer_live_context_note'))
            pr_ev = rec_meta.get('pipeline_running')
            if pr_ev is None:
                pr_ev = is_pipeline_running(lab_root_ev)
        else:
            pr_ev = is_pipeline_running(lab_root_ev)
            rec_meta = {}
        recommendation = compute_operator_support_send_recommendation_core(
            repo_root,
            eval_snap,
            ok_ev,
            msg_ev,
            pr_ev,
            recommendation_source_scope=str(rec_meta.get('recommendation_source_scope', '') or 'latest_live_snapshot'),
            recommendation_anchor_run_id=str(rec_meta.get('recommendation_anchor_run_id', '') or ''),
            recommendation_live_run_id=str(rec_meta.get('live_run_id', '') or ''),
            recommendation_live_run_status=str(rec_meta.get('live_run_status', '') or ''),
            provenance_extra_lines=prov,
        )
        if not isinstance(recommendation, dict):
            recommendation = {}
    except Exception:
        recommendation = {}

    rec_kind = str(recommendation.get('recommended_action_kind') or '').strip()
    preview_rb = recommendation.get('action_preview') if isinstance(recommendation.get('action_preview'), dict) else {}
    anchor_for_bundle = str(recommendation.get('recommendation_anchor_run_id') or preview_rb.get('anchor_run_id') or '').strip()
    if rec_kind == 'review_dat_qa_full_block':
        if not anchor_for_bundle:
            return (False, 'Run evidence bundle requires recommendation_anchor_run_id for review_dat_qa_full_block; anchor is missing.', None)
        lab_root_try = str((snapshot or {}).get('lab_root', '') or '').strip() or resolve_lab_root(repo_root)
        ok_anchor, msg_anchor, snapshot_anchor = _build_run_artifact_snapshot(repo_root, run_id=anchor_for_bundle)
        if not ok_anchor or not isinstance(snapshot_anchor, dict):
            note_path = _write_run_evidence_anchor_resolution_note(repo_root, lab_root_try, anchor_for_bundle, msg_anchor)
            err = 'Cannot resolve anchored run evidence snapshot for run_id={0}: {1}'.format(anchor_for_bundle, msg_anchor or 'unknown')
            meta = {'anchor_run_id': anchor_for_bundle, 'lineage_note_path': note_path or ''}
            return (False, err, meta)
        snapshot = snapshot_anchor

    quality = _artifact_bundle_quality(snapshot)
    runbook_lines = [
        'Run-evidence bundle quality: score={0} label={1}'.format(
            quality.get('score'), quality.get('label')),
        'Phase coverage: complete={0} partial={1} missing={2}'.format(
            quality.get('complete'), quality.get('partial'), quality.get('missing')),
        'Recommendation: {0}'.format(quality.get('recommendation')),
    ]
    if quality.get('recommendation') == 'prefer_nearest_complete' and snapshot.get('nearest_complete_run_id'):
        runbook_lines.append('Consider inspecting/sending nearest complete run_id={0}.'.format(
            snapshot.get('nearest_complete_run_id')))
        if _artifact_tools.artifact_snapshot_coherence_blocked(snapshot):
            runbook_lines.append(
                'Lab diagnostics still conflict with a clean run handoff; see triage pack and diagnostics before escalating.')
    if quality.get('recommendation') == 'review_lab_state':
        runbook_lines.append(
            'Lab diagnostics conflict with a clean run handoff; see triage pack classification and diagnostics before escalating.')
    action_lines = _artifact_tools.format_recommended_action_lines(
        recommendation,
        title='Recommended next action:',
    )
    if action_lines:
        runbook_lines.extend(action_lines)
    if rec_kind == 'review_dat_qa_full_block':
        runbook_lines.append(
            'Bundle scope: anchored run_id={0} (review_dat_qa_full_block; not latest snapshot default).'.format(
                str(snapshot.get('run_id', '') or anchor_for_bundle or '')))
        rp = preview_rb.get('qa_reject_samples_path') if isinstance(preview_rb, dict) else None
        rp = str(rp or '').strip()
        if rp and not os.path.isfile(rp):
            runbook_lines.append(
                'QA full-block: qa_reject_samples not found on disk at expected path ({0}); attach when available.'.format(rp))

    lab_root = snapshot.get('lab_root', '')
    try:
        _emit_progress(progress_callback, 'writing run evidence reports')
        triage_path = _write_artifact_triage_pack(snapshot, latest_alias=False, recommended_action=recommendation)
        index_path = _write_run_artifact_index(snapshot, latest_alias=False, recommended_action=recommendation)
    except Exception as e:
        return (False, str(e), None)

    delivery_path = ''
    delivery_ok, _, delivery_candidate = open_report_delivery_status(repo_root)
    if delivery_ok and delivery_candidate:
        delivery_path = delivery_candidate

    _emit_progress(progress_callback, 'collecting attachments')
    context_attachment_path, context_pack = _collect_run_evidence_context_attachment(
        repo_root,
        snapshot,
        progress_callback=progress_callback,
    )

    extra_files = []
    seen = set()
    _add_unique_file(extra_files, seen, triage_path)
    _add_unique_file(extra_files, seen, index_path)
    _add_unique_file(extra_files, seen, delivery_path)
    if context_attachment_path:
        _add_unique_file(extra_files, seen, context_attachment_path, alias=os.path.basename(context_attachment_path))
    bundle_scope_id = str(snapshot.get('run_id', '') or '')
    for path in _phase_d_dat_smoke_report_paths_for_run_evidence(
            repo_root, lab_root, recommendation, bundle_scope_id):
        _add_unique_file(extra_files, seen, path, alias=os.path.basename(path))
    if rec_kind == 'review_dat_qa_full_block':
        for path in _review_dat_qa_full_block_forced_attachment_paths(recommendation):
            _add_unique_file(extra_files, seen, path, alias=os.path.basename(path))
    for path in _phase_d_reprocess_report_paths_for_run_evidence(
            lab_root, recommendation, str(snapshot.get('run_id', '') or '')):
        _add_unique_file(extra_files, seen, path, alias=os.path.basename(path))
    for path in _latest_interrupt_report_paths(lab_root, bundle_run_id=str(snapshot.get('run_id', '') or '')):
        _add_unique_file(extra_files, seen, path, alias=os.path.basename(path))
    for path in snapshot.get('artifact_files', []):
        _add_unique_file(extra_files, seen, path)
    for path in snapshot.get('context_files', []):
        _add_unique_file(extra_files, seen, path)

    if not extra_files:
        return (False, 'No run artifacts found to attach.', None)

    try:
        delivery_preflight = _collect_delivery_diagnostics()
        _emit_progress(progress_callback, 'creating zip bundle')
        zip_path = collect_support_bundle(
            include_traceback=False,
            extra_meta={
                'run_evidence_bundle': True,
                'artifact_run_id': snapshot.get('run_id', ''),
                'send_source': 'manual_run_evidence_bundle',
                'lab_root': lab_root,
                'email_delivery_preflight': delivery_preflight,
                'diagnostics_state_scope': 'lab_root_current',
                'run_cursor_scope': 'lab_root_current',
                'log_tail_scope': 'latest_application_log',
                'recommended_action_kind': str(recommendation.get('recommended_action_kind', '') or 'send_bundle'),
                'recommended_report_kind': str(recommendation.get('recommended_report_kind', '') or ''),
                'context_pack_scope': str((context_pack or {}).get('pack_scope', '') or ''),
                'context_pack_anchor_run_id': str((context_pack or {}).get('anchor_run_id', '') or ''),
            },
            extra_files=extra_files,
            progress_callback=progress_callback,
        )
        if not zip_path:
            return (False, 'Failed to create support bundle.', {
                'run_id': snapshot.get('run_id', ''),
                'bundle_quality': quality,
                'runbook_lines': runbook_lines,
                'delivery_status_path': delivery_path,
                'context_attachment_path': context_attachment_path,
            })
        ok_send, msg_send, _ = _submit_bundle_with_delivery_diagnostics(
            zip_path=zip_path,
            allow_interactive_reauth=True,
            progress_callback=progress_callback,
        )
        return (ok_send, msg_send, {
            'run_id': snapshot.get('run_id', ''),
            'triage_path': triage_path,
            'index_path': index_path,
            'delivery_status_path': delivery_path,
            'bundle_quality': quality,
            'runbook_lines': runbook_lines,
            'context_attachment_path': context_attachment_path,
            'recommended_action_kind': str(recommendation.get('recommended_action_kind', '') or 'send_bundle'),
        })
    except Exception as e:
        return (False, 'Error: {0}'.format(e), {
            'run_id': snapshot.get('run_id', ''),
            'bundle_quality': quality,
            'runbook_lines': runbook_lines,
            'delivery_status_path': delivery_path,
            'context_attachment_path': context_attachment_path,
            'recommended_action_kind': str(recommendation.get('recommended_action_kind', '') or 'send_bundle'),
        })


def _has_invalid_lab_root(diagnostics):
    """True if diagnostics indicate lab root is missing or not found (read-only path)."""
    codes = {str(i.get('code', '') or '').strip() for i in diagnostics.get('issues', [])}
    return bool(codes & {'LAB_ROOT_MISSING', 'LAB_ROOT_NOT_FOUND'})


def get_health_lines(lab_root, env_flag_fn):
    """Return list of health lines. Uses build_cloud_health_lines or diagnostics_state fallback."""
    diagnostics = _collect_health_diagnostics(lab_root, auto_resolve=True)
    # TODO(agent-followup): Add lightweight log-throttling keyed by diagnostic signature so
    # repeated menu refreshes do not spam identical WARNING/ERROR lines in operator logs.
    if _has_invalid_lab_root(diagnostics):
        tracker_info = {'escalated_codes': [], 'resolved_codes': []}
    else:
        tracker_info = _update_health_issue_tracker(lab_root, diagnostics)

    for issue in diagnostics.get('issues', []):
        level = 'ERROR' if str(issue.get('severity', '')).lower() == 'fail' else 'WARNING'
        _log_health(level, 'Cloud readiness diagnostics [{0}] count-tracked: {1}'.format(
            issue.get('code', 'UNKNOWN_ISSUE'), issue.get('message', '')))
    for resolved_code in tracker_info.get('resolved_codes', []):
        _log_health('INFO', 'Cloud readiness diagnostics resolved: {0}'.format(resolved_code))
    for fix in diagnostics.get('auto_resolved', []):
        _log_health('INFO', 'Cloud readiness auto-resolve: {0}'.format(fix))

    if tracker_info.get('escalated_codes'):
        _log_health('WARNING', 'Cloud readiness escalation triggered for: {0}'.format(
            ', '.join(tracker_info.get('escalated_codes', []))))
        if _maybe_send_cloud_health_failure_report(lab_root, diagnostics, tracker_info):
            _log_health('WARNING', 'Cloud readiness escalation report submitted (or queued).')

    diagnostics_lines = []
    if diagnostics.get('issues'):
        diagnostics_lines.append('-' * 80)
        diagnostics_lines.append('Diagnostics Summary:')
        for issue in diagnostics.get('issues', []):
            diagnostics_lines.append(' - [{0}] {1}: {2}'.format(
                str(issue.get('severity', 'warn')).upper(),
                issue.get('code', 'UNKNOWN_ISSUE'),
                issue.get('message', ''),
            ))
    if diagnostics.get('auto_resolved'):
        diagnostics_lines.append('Auto-resolved:')
        for fix in diagnostics.get('auto_resolved', []):
            diagnostics_lines.append(' - {0}'.format(fix))
    if tracker_info.get('escalated_codes'):
        diagnostics_lines.append('Escalated diagnostics: {0}'.format(', '.join(tracker_info.get('escalated_codes', []))))

    if build_cloud_health_lines:
        try:
            lines = build_cloud_health_lines(
                lab_root,
                auto_pipeline=env_flag_fn('MEDICAFE_SHADOW_AUTO_PIPELINE', True),
                auto_health=env_flag_fn('MEDICAFE_SHADOW_SEND_HEALTH', True),
            )
            if diagnostics_lines:
                lines.extend(diagnostics_lines)
            return lines
        except Exception as e:
            _log_health('ERROR', 'build_cloud_health_lines failed; using fallback: {0}'.format(e))
    state_path = os.path.join(lab_root, 'diagnostics_state.json')
    if not os.path.exists(state_path):
        auto_pipeline = env_flag_fn('MEDICAFE_SHADOW_AUTO_PIPELINE', True)
        auto_health = env_flag_fn('MEDICAFE_SHADOW_SEND_HEALTH', True)
        lines = [
            'No diagnostics state found yet: {0}'.format(state_path),
            'Automation: pipeline_auto={0}, health_telemetry_auto={1}'.format(
                auto_pipeline, auto_health),
        ]
        if diagnostics_lines:
            lines.extend(diagnostics_lines)
        return lines
    try:
        with open(state_path, 'r', encoding='utf-8') as f:
            state = json.load(f)
        rid = state.get('last_shadow_pipeline_run_id', '')
        ok = state.get('last_shadow_pipeline_ok', False)
        failed = state.get('last_shadow_pipeline_failed_phase', '')
        parity = state.get('last_contract_parity_status', '')
        auto_pipeline = env_flag_fn('MEDICAFE_SHADOW_AUTO_PIPELINE', True)
        auto_health = env_flag_fn('MEDICAFE_SHADOW_SEND_HEALTH', True)
        lines = [
            'Last run: {0}, ok={1}, failed_phase={2}, parity={3}'.format(
                rid or '(none)', ok, failed or '-', parity or '-'),
            'Automation: pipeline_auto={0}, health_telemetry_auto={1}'.format(
                auto_pipeline, auto_health),
        ]
        if diagnostics_lines:
            lines.extend(diagnostics_lines)
        return lines
    except (IOError, OSError, ValueError) as e:
        _log_health('ERROR', 'Fallback diagnostics_state parse failed: {0}'.format(e))
        return diagnostics_lines
