from enum import Enum


class ErrorCode(Enum):
    """Error codes for the log clustering script."""

    NO_ERROR = 0
    NO_LOG_FILES = -1
    INVALID_TREE_DEPTH = -2
    INVALID_REGEX = -3
    FILE_NOT_FOUND = -4
    IO_ERROR = -5
    TIME_PATTERN_ERROR = -6
