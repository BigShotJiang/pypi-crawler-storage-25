# longwei

[![Docs](https://img.shields.io/badge/docs-latest-blue)](https://marvinsmastodontools.codeberg.page/longwei/latest/ "Latest documentation")
[![Repo](https://img.shields.io/badge/repo-Codeberg.org-blue)](https://codeberg.org/MarvinsMastodonTools/longwei "Repo at Codeberg.org")
[![CI](https://ci.codeberg.org/api/badges/MarvinsMastodonTools/longwei/status.svg)](https://ci.codeberg.org/MarvinsMastodonTools/longwei "CI / Woodpecker")
[![Downloads](https://pepy.tech/badge/longwei)](https://pepy.tech/project/longwei "Download count")
[![uv_secure](https://img.shields.io/badge/uv--secure-checked-green)](https://docs.astral.sh/uv/guides/audit/ "Checked with uv-secure")
[![gitleaks](https://img.shields.io/badge/gitleaks-checked-green)](https://github.com/gitleaks/gitleaks "Checked with gitleaks")
[![pysentry](https://img.shields.io/badge/pysentry-checked-green)](https://github.com/astral-sh/pysentry "Checked with pysentry")
[![complexipy](https://img.shields.io/badge/complexipy-checked-green.svg)](https://github.com/rohaquinlop/complexipy "Checked with complexipy")
[![Codestyle](https://img.shields.io/badge/code%20style-ruff-000000.svg)](https://github.com/astral-sh/ruff "Code style: ruff")
[![Version](https://img.shields.io/pypi/pyversions/longwei)](https://pypi.org/project/longwei "PyPI – Python Version")
[![Wheel](https://img.shields.io/pypi/wheel/longwei)](https://pypi.org/project/longwei "PyPI – Wheel")
[![License: AGPL-3.0-or-later](https://img.shields.io/badge/License-AGPL--3.0--or--later-blue.svg)](https://spdx.org/licenses/AGPL-3.0-or-later.html "AGPL 3 or later")

Longwei is a minimal Python implementation of the ActivityPub client REST API used by [Mastodon](https://joinmastodon.org/), [Pleroma](https://pleroma.social/), and [GotoSocial](https://gotosocial.org/). This implementation makes use of asyncio where appropriate. It is intended to be used as a library by other applications. No standalone functionality is provided.

So far Longwei only implements the ActivityPub API calls I need for my other projects [Fedinesia](https://codeberg.org/MarvinsMastodonTools/fedinesia), [Feed2Fedi](https://codeberg.org/marvinsmastodontools/feed2fedi), [FenLiu and Zhongli](https://codeberg.org/marvinsmastodontools/dujiangyan).

**DO NOT** expect a full or complete implementation of all [ActivityPub API](https://activitypub.rocks/) functionality.

## Quick start

```bash
pip install longwei
```

```python
import asyncio
import httpx
from longwei import APClient

async def main():
    async with httpx.AsyncClient() as client:
        ap = await APClient.create(
            instance="mastodon.social",
            client=client,
            access_token="your_token",
        )
        status = await ap.post_status("Hello, fediverse!")
        print(status.url)

asyncio.run(main())
```

## API References

- [Mastodon API](https://docs.joinmastodon.org/api/)
- [Pleroma API](https://api.pleroma.social)
- [GotoSocial API](https://docs.gotosocial.org/en/stable/api/swagger/)

## Status

longwei is a fork of `minimal_activitypub`. The main breaking change from that package is the
class rename: `ActivityPub` → `APClient`. See the [Upgrading guide](https://marvinsmastodontools.codeberg.page/longwei/latest/upgrading/) for migration instructions.

It is **not** a drop-in replacement. See the upgrading guide for migration instructions.

## Contributing

Issues and pull requests are welcome.

longwei is using [pre-commit](https://pre-commit.com/) for code quality checks and [uv](https://docs.astral.sh/uv/) for dependency management. Please install and use both pre-commit and uv if you'd like to contribute.

## Documentation

The live documentation is at **https://marvinsmastodontools.codeberg.page/longwei/latest/**

Built with [MkDocs](https://www.mkdocs.org/) and the [Material theme](https://squidfunk.github.io/mkdocs-material/). To build and serve locally:

```bash
uv sync --group docs
mkdocs serve
```

## Development

This project uses [uv](https://docs.astral.sh/uv/) for dependency management and virtual environments. To set up the development environment:

```bash
# Create and activate virtual environment
uv venv
source .venv/bin/activate

# Install all dependencies including development and documentation groups
uv sync --all-groups

# Run tests
uv run nox
```

For more details on the development workflow, check the `noxfile.py` and `.woodpecker/` configuration files.

## Licensing

longwei is licenced with the [GNU Affero General Public License v3.0](http://www.gnu.org/licenses/agpl-3.0.html)

## Supporting longwei

There are a number of ways you can support longwei:

- Create an issue with problems or ideas you have with/for longwei
- You can [buy me a coffee](https://www.buymeacoffee.com/marvin8).
- You can send me small change in Monero to the address below:

### Monero donation address
`8ADQkCya3orL178dADn4bnKuF1JuVGEG97HPRgmXgmZ2cZFSkWU9M2v7BssEGeTRNN2V5p6bSyHa83nrdu1XffDX3cnjKVu`
