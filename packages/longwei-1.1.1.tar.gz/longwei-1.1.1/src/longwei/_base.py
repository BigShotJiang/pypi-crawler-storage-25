"""Internal base definitions shared across mixin modules.

This module exists to break the circular import that would arise if mixins
imported directly from the ``longwei`` package: package-level constants live
here so that ``__init__.py`` can import both this module and the mixins
without a cycle.
"""

import sys
from importlib.metadata import version
from typing import Final

__display_name__: Final[str] = "Longwei"
__version__: Final[str] = version("longwei")

USER_AGENT: Final[str] = f"{__display_name__}_v{__version__}_Python_{sys.version.split()[0]}"
