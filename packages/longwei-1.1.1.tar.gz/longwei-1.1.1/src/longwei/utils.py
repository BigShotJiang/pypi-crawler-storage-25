"""Utility functions for longwei."""

import logging
from datetime import UTC
from datetime import datetime
from json import JSONDecodeError

from httpx import HTTPError
from httpx import Response

from longwei import __display_name__
from longwei.constants import RESPONSE_TEXT_MAX_LENGTH
from longwei.constants import STATUS_BAD_REQUEST
from longwei.constants import STATUS_CONFLICT
from longwei.constants import STATUS_FORBIDDEN
from longwei.constants import STATUS_GONE
from longwei.constants import STATUS_INTERNAL_SERVER_ERROR
from longwei.constants import STATUS_NOT_FOUND
from longwei.constants import STATUS_TOO_MANY_REQUESTS
from longwei.constants import STATUS_UNAUTHORIZED
from longwei.constants import STATUS_UNPROCESSABLE_ENTITY
from longwei.exceptions import ClientError
from longwei.exceptions import ConflictError
from longwei.exceptions import ForbiddenError
from longwei.exceptions import GoneError
from longwei.exceptions import NotFoundError
from longwei.exceptions import RatelimitError
from longwei.exceptions import ServerError
from longwei.exceptions import UnauthorizedError
from longwei.exceptions import UnprocessedError

logger = logging.getLogger(__display_name__)


def parse_rate_limit_reset(time_value: str | None) -> datetime | None:
    """Determine date and time when rate limit will be reset.

    :param time_value: The rate limit reset header value (Unix timestamp or ISO 8601 string)
    :return: A datetime representing the reset time, or None if unparseable
    """
    if not time_value:
        return None
    try:
        timestamp = int(time_value)
        return datetime.fromtimestamp(timestamp, UTC)
    except (ValueError, TypeError):
        pass
    try:
        return datetime.fromisoformat(time_value)
    except (ValueError, TypeError):
        pass
    return None


async def _determine_error_message(response: Response) -> str:
    """Extract error message from response JSON, falling back to response text.

    :param response: The HTTP response
    :return: The error message as a string
    """
    error_message = "Exception has occurred"
    try:
        content = response.json()
        error_message = content["error"]
    except (HTTPError, KeyError, JSONDecodeError, ValueError):
        try:
            error_message = response.text
        except (HTTPError, LookupError) as lookup_error:
            logger.debug(
                "_determine_error_message - Error when determining response.text = %s",
                lookup_error,
            )
    logger.debug("_determine_error_message - error_message = %s", error_message)
    return error_message


def _get_response_text(response: Response) -> str | None:
    """Return the response body text, truncated to RESPONSE_TEXT_MAX_LENGTH characters.

    :param response: The HTTP response
    :return: Truncated response text, or None if the body is unreadable
    """
    try:
        raw = response.text
        if len(raw) > RESPONSE_TEXT_MAX_LENGTH:
            return raw[:RESPONSE_TEXT_MAX_LENGTH] + "..."
        return raw
    except (HTTPError, LookupError):
        return None


async def _check_exception(response: Response) -> None:
    """Raise an appropriate exception based on HTTP response status code.

    :param response: The HTTP response to check
    """
    logger.debug("_check_exception - response.headers = %s", response.headers)
    logger.debug("_check_exception - response.status_code = %s", response.status_code)

    if response.status_code < STATUS_BAD_REQUEST:
        return

    error_message = await _determine_error_message(response)
    endpoint = str(response.url)
    method = response.request.method
    request_id = response.headers.get("x-request-id")
    response_text = _get_response_text(response)

    ctx = {"endpoint": endpoint, "method": method, "request_id": request_id, "response_text": response_text}

    if response.status_code == STATUS_UNAUTHORIZED:
        raise UnauthorizedError(response.status_code, response.reason_phrase, error_message, **ctx)
    if response.status_code == STATUS_FORBIDDEN:
        raise ForbiddenError(response.status_code, response.reason_phrase, error_message, **ctx)
    if response.status_code == STATUS_NOT_FOUND:
        raise NotFoundError(response.status_code, response.reason_phrase, error_message, **ctx)
    if response.status_code == STATUS_CONFLICT:
        raise ConflictError(response.status_code, response.reason_phrase, error_message, **ctx)
    if response.status_code == STATUS_GONE:
        raise GoneError(response.status_code, response.reason_phrase, error_message, **ctx)
    if response.status_code == STATUS_UNPROCESSABLE_ENTITY:
        raise UnprocessedError(response.status_code, response.reason_phrase, error_message, **ctx)
    if response.status_code == STATUS_TOO_MANY_REQUESTS:
        reset_header = response.headers.get("X-RateLimit-Reset")
        parsed_reset = parse_rate_limit_reset(reset_header)
        rl_reset = parsed_reset if parsed_reset else None
        rl_limit_raw = response.headers.get("X-RateLimit-Limit")
        rl_limit = int(rl_limit_raw) if rl_limit_raw else None
        raise RatelimitError(
            response.status_code,
            response.reason_phrase,
            error_message,
            ratelimit_reset=rl_reset,
            ratelimit_limit=rl_limit,
            **ctx,
        )
    if response.status_code < STATUS_INTERNAL_SERVER_ERROR:
        raise ClientError(response.status_code, response.reason_phrase, error_message, **ctx)

    raise ServerError(response.status_code, response.reason_phrase, error_message, **ctx)
