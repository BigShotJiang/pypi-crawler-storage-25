"""Credentials mixin: verify_credentials, determine_instance_type, _set_instance_parameters."""

import json
import logging
from typing import Any

from httpx import HTTPError

from longwei._base import __display_name__
from longwei.constants import INSTANCE_TYPE_PLEROMA
from longwei.constants import MAX_ATTACHMENTS_PLEROMA
from longwei.exceptions import NetworkError
from longwei.models import Account
from longwei.types import APClientClass
from longwei.utils import _check_exception

logger = logging.getLogger(__display_name__)


class _CredentialsMixin:
    """Mixin providing credential verification and instance type detection."""

    async def verify_credentials(self: APClientClass) -> Account:
        """Verify the credentials of the user.

        :returns: The account information for the authenticated user.

        Note:
            Implements ``GET /api/v1/accounts/verify_credentials``
            (Mastodon, Pleroma, GotoSocial).

        """
        url = f"{self.instance}/api/v1/accounts/verify_credentials"
        logger.debug("APClient.verify_credentials() - url=%s", url)
        try:
            response = await self.client.get(url=url, headers=self.headers, timeout=self.timeout)
            logger.debug(
                "APClient.verify_credentials - response: \n%s",
                response,
            )
            self._update_ratelimit(response.headers)
            await _check_exception(response=response)
            self._parse_next_prev(links=response.headers.get("Link"))
            account = Account.model_validate(response.json())
        except HTTPError as error:
            raise NetworkError from error

        return account

    async def determine_instance_type(self: APClientClass) -> None:
        """Check if the instance is a Pleroma instance or not.

        Probes ``/api/v2/instance`` first (Mastodon 3.5.5+, GotoSocial). Falls back to
        ``/api/v1/instance`` when the v2 endpoint returns a non-success status (Pleroma,
        older Mastodon).

        Note:
            Implements ``GET /api/v2/instance`` with fallback to ``GET /api/v1/instance``.

        """
        instance = self.instance
        if "http" not in self.instance:
            instance = f"https://{self.instance}"

        try:
            response_v2 = await self.client.get(url=f"{instance}/api/v2/instance", timeout=self.timeout)
            if response_v2.is_success:
                self.instance = instance
                response_dict_v2 = response_v2.json()
                logger.debug(
                    "APClient.determine_instance_type -> v2 response.dict:\n%s",
                    json.dumps(response_dict_v2, indent=4),
                )
                self._set_instance_parameters_v2(response_dict_v2)
                logger.debug("APClient.determine_instance_type() -> v2, instance_type=%s", self.instance_type)
                return

            response = await self.client.get(url=f"{instance}/api/v1/instance", timeout=self.timeout)
            await _check_exception(response=response)
            response_dict = response.json()
        except HTTPError as error:
            raise NetworkError from error

        logger.debug(
            "APClient.determine_instance_type -> v1 response.dict:\n%s",
            json.dumps(response_dict, indent=4),
        )
        self.instance = instance
        self._set_instance_parameters(response_dict)
        logger.debug("APClient.determine_instance_type() -> v1, instance_type=%s", self.instance_type)

    def _set_instance_parameters_v2(self, response_dict: dict[str, Any]) -> None:
        """Set instance parameters from the /api/v2/instance response dict.

        :param response_dict: Dictionary returned by call to .../api/v2/instance
        """
        version = response_dict.get("version", "")
        if INSTANCE_TYPE_PLEROMA in version:
            self.instance_type = INSTANCE_TYPE_PLEROMA
            self.max_attachments = MAX_ATTACHMENTS_PLEROMA

        config = response_dict.get("configuration", {})
        if max_status_len := config.get("statuses", {}).get("max_characters"):
            self.max_status_len = max_status_len
        if max_attachments := config.get("statuses", {}).get("max_media_attachments"):
            self.max_attachments = max_attachments
        if max_att_size := config.get("media_attachments", {}).get("image_size_limit"):
            self.max_att_size = max_att_size
        if mime_types := config.get("media_attachments", {}).get("supported_mime_types"):
            self.supported_mime_types = mime_types

    def _set_instance_parameters(self, response_dict: dict[str, Any]) -> None:
        """Set instance parameters from the /api/v1/instance response dict.

        :param response_dict: Dictionary returned by call to .../api/v1/instance
        """
        version = response_dict.get("version", "")
        if INSTANCE_TYPE_PLEROMA in version:
            self.instance_type = INSTANCE_TYPE_PLEROMA
            self.max_attachments = MAX_ATTACHMENTS_PLEROMA

        instance_config = response_dict.get("configuration", {})

        if (max_status_len := instance_config.get("statuses", {}).get("max_characters")) or (
            max_status_len := response_dict.get("max_characters")
        ):
            self.max_status_len = max_status_len

        if (max_attachments := instance_config.get("statuses", {}).get("max_media_attachments")) or (
            max_attachments := response_dict.get("max_media_attachments")
        ):
            self.max_attachments = max_attachments

        if max_att_size := instance_config.get("media_attachments", {}).get("image_size_limit"):
            self.max_att_size = max_att_size

        if mime_types := instance_config.get("media_attachments", {}).get("supported_mime_types"):
            self.supported_mime_types = mime_types
