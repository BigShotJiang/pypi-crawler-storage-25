"""Statuses mixin: post, delete, reblog, undo_reblog, undo_favourite, post_media, search."""

import asyncio
import json
import logging
import random
import uuid
from datetime import UTC
from datetime import datetime
from typing import IO

from httpx import HTTPError

from longwei._base import __display_name__
from longwei.constants import INSTANCE_TYPE_PLEROMA
from longwei.constants import MEDIA_POLL_INTERVAL
from longwei.constants import MEDIA_POLL_TIMEOUT
from longwei.constants import STATUS_ACCEPTED
from longwei.constants import STATUS_NOT_FOUND
from longwei.enums import SearchType
from longwei.enums import Visibility
from longwei.exceptions import NetworkError
from longwei.exceptions import ServerError
from longwei.models import MediaAttachment
from longwei.models import SearchResults
from longwei.models import Status
from longwei.types import APClientClass
from longwei.utils import _check_exception

logger = logging.getLogger(__display_name__)


def _add_poll_data(
    data: dict[str, str | list[str]],
    options: list[str],
    expires_in: int | None,
    multiple: bool,
    hide_totals: bool,
) -> None:
    data["poll[options][]"] = options
    if expires_in is not None:
        data["poll[expires_in]"] = str(expires_in)
    if multiple:
        data["poll[multiple]"] = "true"
    if hide_totals:
        data["poll[hide_totals]"] = "true"


class _StatusesMixin:
    """Mixin providing status, media, and search methods."""

    async def delete_status(self: APClientClass, status: str | Status, delete_only_one: bool = False) -> Status:
        """Delete a status.

        :param status: The ID of the status you want to delete or a dict containing the status details
        :param delete_only_one: Set this to True if this delete is the only one. Set it to False if this delete is part
            of a batch of deletes. With this set to False it will introduce a random wait of up to 3 seconds.
            This hopefully should help with instance saturation.
            Defaults to False

        :returns: Status that has just been deleted

        Note:
            Implements ``DELETE /api/v1/statuses/:id``
            (Mastodon, Pleroma, GotoSocial).
            On Pleroma, if the status is reblogged or favourited, ``undo_reblog()``
            or ``undo_favourite()`` is called first automatically.

        """
        if not delete_only_one:
            # add random delay of up to 3 seconds in case we are deleting many
            # statuses in a batch
            sleep_for = random.SystemRandom().random() * 3
            logger.debug(
                "APClient.delete_status - status_id = %s - sleep_for = %s",
                status if isinstance(status, str) else status.id,
                sleep_for,
            )
            await asyncio.sleep(delay=sleep_for)

        if isinstance(status, str):
            status_id = status
        elif isinstance(status, Status):
            status_id = status.id
            if self.instance_type == INSTANCE_TYPE_PLEROMA and status.reblogged:
                undo_reblog_response = await self.undo_reblog(status=status)
                return undo_reblog_response
            if self.instance_type == INSTANCE_TYPE_PLEROMA and status.favourited:
                undo_favourite_response = await self.undo_favourite(status=status)
                return undo_favourite_response

        await self._pre_call_checks()

        url = f"{self.instance}/api/v1/statuses/{status_id}"
        try:
            response = await self.client.delete(url=url, headers=self.headers, timeout=self.timeout)
            self._update_ratelimit(response.headers)
            await _check_exception(response=response)
            self._parse_next_prev(links=response.headers.get("Link"))
            result = Status.model_validate(response.json())
        except HTTPError as error:
            raise NetworkError from error

        logger.debug(
            "APClient.delete_status -> result:\n%s",
            json.dumps(result.model_dump(), indent=4),
        )
        return result

    async def undo_reblog(self: APClientClass, status: str | Status) -> Status:
        """Remove a reblog.

        :param status: The ID of the status you want to delete or a dict containing the status details

        :returns: The response from the server.

        Note:
            Implements ``POST /api/v1/statuses/:id/unreblog``
            (Mastodon, Pleroma, GotoSocial).

        """
        logger.debug(
            "APClient.undo_reblog(status=%s",
            status,
        )

        if isinstance(status, str):
            status_id = status
        elif isinstance(status, Status):
            status_id = status.reblog.id if status.reblog else status.id

        await self._pre_call_checks()
        url = f"{self.instance}/api/v1/statuses/{status_id}/unreblog"
        try:
            response = await self.client.post(url=url, headers=self.headers, timeout=self.timeout)
            self._update_ratelimit(response.headers)
            await _check_exception(response=response)
            self._parse_next_prev(links=response.headers.get("Link"))
            result = Status.model_validate(response.json())
        except HTTPError as error:
            raise NetworkError from error

        logger.debug(
            "APClient.undo_reblog -> result:\n%s",
            json.dumps(result.model_dump(), indent=4),
        )
        return result

    async def reblog(self: APClientClass, status_id: str, visibility: Visibility | None = None) -> Status:
        """Reblog a status.

        :param status_id: The ID of the status you want to reblog.
        :param visibility: Override the visibility of the reblog. One of ``public``, ``unlisted``,
            or ``private``. Defaults to the account's default visibility when omitted.

        :returns: The reblogged status.

        Note:
            Implements ``POST /api/v1/statuses/:id/reblog``
            (Mastodon, Pleroma, GotoSocial).

        """
        logger.debug(
            "APClient.reblog(status_id=%s, visibility=%s)",
            status_id,
            visibility,
        )

        await self._pre_call_checks()
        url = f"{self.instance}/api/v1/statuses/{status_id}/reblog"
        data: dict[str, str] = {}
        if visibility is not None:
            data["visibility"] = visibility.value
        try:
            response = await self.client.post(
                url=url,
                headers=self.headers,
                data=data or None,
                timeout=self.timeout,
            )
            self._update_ratelimit(response.headers)
            await _check_exception(response=response)
            self._parse_next_prev(links=response.headers.get("Link"))
            result = Status.model_validate(response.json())
        except HTTPError as error:
            raise NetworkError from error

        logger.debug(
            "APClient.reblog -> result:\n%s",
            json.dumps(result.model_dump(), indent=4),
        )
        return result

    async def undo_favourite(
        self: APClientClass,
        status: str | Status,
    ) -> Status:
        """Remove a favourite.

        :param status: The ID of the status you want to delete or a dict containing the status details

        :returns: The Status that has just been un-favourited.

        Note:
            Implements ``POST /api/v1/statuses/:id/unfavourite``
            (Mastodon, Pleroma, GotoSocial).

        """
        logger.debug(
            "APClient.undo_favourite(status=%s)",
            status,
        )

        if isinstance(status, str):
            status_id = status
        elif isinstance(status, Status):
            status_id = status.id

        await self._pre_call_checks()
        url = f"{self.instance}/api/v1/statuses/{status_id}/unfavourite"
        try:
            response = await self.client.post(url=url, headers=self.headers, timeout=self.timeout)
            self._update_ratelimit(response.headers)
            await _check_exception(response=response)
            self._parse_next_prev(links=response.headers.get("Link"))
            result = Status.model_validate(response.json())
        except HTTPError as error:
            raise NetworkError from error

        logger.debug(
            "APClient.undo_favourite -> result:\n%s",
            json.dumps(result.model_dump(), indent=4),
        )
        return result

    async def post_status(  # noqa: PLR0913
        self: APClientClass,
        status: str,
        visibility: Visibility = Visibility.PUBLIC,
        media_ids: list[str] | None = None,
        sensitive: bool = False,
        spoiler_text: str | None = None,
        scheduled_at: datetime | None = None,
        in_reply_to_id: str | None = None,
        language: str | None = None,
        poll_options: list[str] | None = None,
        poll_expires_in: int | None = None,
        poll_multiple: bool = False,
        poll_hide_totals: bool = False,
    ) -> Status:
        """Post a status to the fediverse.

        :param status: The text to be posted on the timeline.
        :param visibility: Visibility of the posted status. Enumerable one of `public`, `unlisted`,
            `private`, or `direct`. Defaults to `public`
        :param media_ids: list of ids for media (pictures, videos, etc) to be attached to this post.
            Can be `None` if no media is to be attached. Defaults to `None`
        :param sensitive: Set to true the post is of a sensitive nature and should be marked as such.
            For example overly political or explicit material is often marked as sensitive.
            Applies particularly to attached media. Defaults to `False`
        :param spoiler_text: Text to be shown as a warning or subject before the actual content.
            Statuses are generally collapsed behind this field. Defaults to `None`
        :param scheduled_at: Date and time at which this status should be posted. This is for scheduling
            statuses. This datetime needs to be at least 5 minutes in the future.
            If no timezone is included "UTC" is assumed.
        :param in_reply_to_id: ID of the status being replied to.
        :param language: ISO 639-1 language code for the status (e.g. ``"en"``).
        :param poll_options: List of answer strings for an attached poll (at least 2).
            Mutually exclusive with ``media_ids``.
        :param poll_expires_in: Duration in seconds before the poll closes. Required when
            ``poll_options`` is given.
        :param poll_multiple: Allow voters to select multiple options. Defaults to `False`.
        :param poll_hide_totals: Hide vote counts until the poll ends. Defaults to `False`.

        :return: The status just posted.

        Note:
            Implements ``POST /api/v1/statuses`` (Mastodon, Pleroma, GotoSocial).

        """
        logger.debug(
            "APClient.post_status(status=%s, visibility=%s, media_ids=%s, "
            "sensitive=%s, spoiler_text=%s, scheduled_at=%s, in_reply_to_id=%s, language=%s)",
            status,
            visibility,
            media_ids,
            sensitive,
            spoiler_text,
            scheduled_at,
            in_reply_to_id,
            language,
        )
        await self._pre_call_checks()

        url = f"{self.instance}/api/v1/statuses"
        headers = self.headers.copy()
        headers.append(("Idempotency-Key", uuid.uuid4().hex))

        logger.debug("APClient.post_status(...) - using URL=%s", url)

        data: dict[str, str | list[str]] = {
            "status": status,
            "visibility": visibility.value,
        }
        if sensitive:
            data["sensitive"] = "true"
        if media_ids:
            data["media_ids[]"] = media_ids
        if spoiler_text:
            data["spoiler_text"] = spoiler_text
        if scheduled_at:
            if not scheduled_at.tzinfo:
                scheduled_at = scheduled_at.replace(tzinfo=UTC)
            data["scheduled_at"] = scheduled_at.isoformat()
        if in_reply_to_id:
            data["in_reply_to_id"] = in_reply_to_id
        if language:
            data["language"] = language
        if poll_options:
            _add_poll_data(data, poll_options, poll_expires_in, poll_multiple, poll_hide_totals)

        logger.debug("data=%s", data)

        try:
            response = await self.client.post(
                url=url,
                headers=headers,
                data=data,
                timeout=self.timeout,
            )
            self._update_ratelimit(headers=response.headers)
            await _check_exception(response=response)
            result = Status.model_validate(response.json())
            logger.debug("APClient.post_status - request:\n%s", response.request)
        except HTTPError as error:
            raise NetworkError from error

        logger.debug(
            "APClient.post_status -> result:\n%s",
            json.dumps(result.model_dump(), indent=4),
        )
        return result

    async def _poll_media_attachment(self: APClientClass, media_id: str) -> MediaAttachment:
        """Poll ``GET /api/v1/media/:id`` until the attachment is ready.

        :param media_id: The ID returned by the async v2 upload.
        :returns: A fully-processed :class:`MediaAttachment` (``url`` is populated).
        :raises ServerError: If the attachment is not ready within ``MEDIA_POLL_TIMEOUT`` seconds.
        :raises NetworkError: On transport-level failure during polling.
        """
        url = f"{self.instance}/api/v1/media/{media_id}"
        attempts = int(MEDIA_POLL_TIMEOUT / MEDIA_POLL_INTERVAL)
        for _ in range(attempts):
            await asyncio.sleep(MEDIA_POLL_INTERVAL)
            try:
                response = await self.client.get(url, headers=self.headers, timeout=self.timeout)
            except HTTPError as error:
                raise NetworkError from error
            attachment = MediaAttachment.model_validate(response.json())
            if attachment.url is not None:
                return attachment
        raise ServerError(message=f"Media {media_id} not ready after {MEDIA_POLL_TIMEOUT}s")

    async def post_media(
        self: APClientClass,
        file: IO[bytes],
        mime_type: str,
        description: str | None = None,
        focus: tuple[float, float] | None = None,
    ) -> MediaAttachment:
        """Post a media file (image or video).

        :param file: The file to be uploaded
        :param mime_type: Mime type
        :param description: A plain-text description of the media, for accessibility purposes
        :param focus: Two floating points (x,y), comma-delimited, ranging from -1.0 to 1.0
            (see "Focal points <https://docs.joinmastodon.org/methods/statuses/media/#focal-points>"_)

        :returns: A fully-processed :class:`MediaAttachment` (``url`` is always populated).

        Note:
            Attempts ``POST /api/v2/media`` first (Mastodon 3.1.3+, async upload support).
            Falls back to ``POST /api/v1/media`` on 404. If the server responds with
            HTTP 202 (processing), polls ``GET /api/v1/media/:id`` until the attachment
            is ready before returning.

        """
        logger.debug(
            "APClient.post_media(file=..., mime_type=%s, description=%s, focus=%s)",
            mime_type,
            description,
            focus,
        )

        await self._pre_call_checks()

        upload_file = {"file": (uuid.uuid4().hex, file, mime_type)}
        data: dict[str, str] = {}
        if description:
            data["description"] = description
        if focus and len(focus) >= 2:
            data["focus"] = f"{focus[0]},{focus[1]}"

        try:
            response = await self.client.post(
                url=f"{self.instance}/api/v2/media",
                headers=self.headers,
                data=data,
                files=upload_file,
                timeout=self.timeout,
            )
            self._update_ratelimit(headers=response.headers)

            if response.status_code == STATUS_NOT_FOUND:
                # v2 not supported — fall back to v1
                response = await self.client.post(
                    url=f"{self.instance}/api/v1/media",
                    headers=self.headers,
                    data=data,
                    files=upload_file,
                    timeout=self.timeout,
                )
                self._update_ratelimit(headers=response.headers)

            await _check_exception(response=response)

            if response.status_code == STATUS_ACCEPTED:
                result = await self._poll_media_attachment(response.json()["id"])
            else:
                result = MediaAttachment.model_validate(response.json())

            logger.debug("APClient.post_media - request:\n%s", response.request)
        except HTTPError as error:
            raise NetworkError from error

        logger.debug(
            "APClient.post_media -> result:\n%s",
            json.dumps(result.model_dump(), indent=4),
        )
        return result

    async def search(  # noqa PLR0913
        self: APClientClass,
        query: str,
        query_type: SearchType,
        resolve: bool = True,
        following: bool = False,
        account_id: str | None = None,
        exclude_unreviewed: bool = False,
        max_id: str | None = None,
        min_id: str | None = None,
        limit: int | None = None,
        offset: int | None = None,
    ) -> SearchResults:
        """Search for accounts, statuses and hashtags.

        :param query: The search query.
        :param query_type: Specify whether to search for only accounts, hashtags, statuses.
            Use SearchType enum for this.
        :param resolve: Only relevant if type includes accounts. If true and (a) the search query is for a remote
            account (e.g., someaccount@someother.server) and (b) the local server does not know about the account,
            WebFinger is used to try and resolve the account at some other.server. This provides the best recall at
            higher latency. If false only accounts the server knows about are returned. Defaults to True.
        :param following: Only include accounts that the user is following? Defaults to False.
        :param account_id: If provided, will only return statuses authored by this account.
        :param exclude_unreviewed: Filter out unreviewed tags? Defaults to False. Use True when trying to find
            trending tags.
        :param max_id: All results returned will be lesser than this ID. In effect, sets an upper bound on results.
        :param min_id: Returns results immediately newer than this ID. In effect, sets a cursor at this ID and paginates
        :param limit: Maximum number of results to return, per type. Mastodon servers default this to 20 results per
            category. Max 40 results per category.
        :param offset: Skip the first n results.

        Note:
            Attempts ``GET /api/v2/search`` first (Mastodon, GotoSocial). Falls back to
            ``GET /api/v1/search`` on 404 (Pleroma and other v1-only instances). On v1
            fallback only ``q``, ``type``, ``resolve``, and ``limit`` are sent; the
            remaining params are silently dropped as they are not part of the v1 spec.

        """
        params: dict[str, int | str | bool] = {
            "q": query,
            "type": query_type.value,
            "resolve": resolve,
        }
        if following:
            params["following"] = following
        if account_id:
            params["account_id"] = account_id
        if exclude_unreviewed:
            params["exclude_unreviewed"] = exclude_unreviewed
        if max_id:
            params["max_id"] = max_id
        if min_id:
            params["min_id"] = min_id
        if limit:
            params["limit"] = limit
        if offset:
            params["offset"] = offset
        logger.debug("Params=%s", params)
        try:
            response = await self.client.get(
                url=f"{self.instance}/api/v2/search",
                headers=self.headers,
                params=params,
                timeout=self.timeout,
            )
            self._update_ratelimit(headers=response.headers)

            if response.status_code == STATUS_NOT_FOUND:
                # v2 not supported — fall back to v1 with supported params only
                v1_params = {k: v for k, v in params.items() if k in {"q", "type", "resolve", "limit"}}
                response = await self.client.get(
                    url=f"{self.instance}/api/v1/search",
                    headers=self.headers,
                    params=v1_params,
                    timeout=self.timeout,
                )
                self._update_ratelimit(headers=response.headers)

            await _check_exception(response=response)
            result = SearchResults.model_validate(response.json())
        except HTTPError as error:
            raise NetworkError from error

        logger.debug("APClient.search -> result:\n%s", json.dumps(result.model_dump(), indent=4))

        return result
