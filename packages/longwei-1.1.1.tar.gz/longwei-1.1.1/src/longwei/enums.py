"""Public enum types for longwei consumers."""

from enum import Enum


class Visibility(str, Enum):
    """Enumerating possible Visibility values for statuses."""

    PUBLIC = "public"
    UNLISTED = "unlisted"
    PRIVATE = "private"
    DIRECT = "direct"


class SearchType(str, Enum):
    """Enumerating possible type values for status searches."""

    ACCOUNTS = "accounts"
    HASHTAGS = "hashtags"
    STATUSES = "statuses"
