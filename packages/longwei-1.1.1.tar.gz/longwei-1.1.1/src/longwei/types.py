"""Type definitions for longwei."""

from typing import TypeVar

from longwei.models import Status

APClientClass = TypeVar("APClientClass", bound="APClient")  # noqa: F821  # ty: ignore[unresolved-reference]

__all__ = ["APClientClass", "Status"]
