"""Package 'longwei' level definitions."""

import logging
from datetime import UTC
from datetime import datetime

from httpx import AsyncClient

from longwei._base import USER_AGENT
from longwei._base import __display_name__
from longwei._base import __version__
from longwei._mixin_auth import _AuthMixin
from longwei._mixin_credentials import _CredentialsMixin
from longwei._mixin_request_helpers import _RequestHelpersMixin
from longwei._mixin_statuses import _StatusesMixin
from longwei._mixin_timelines import _TimelinesMixin
from longwei.constants import INSTANCE_TYPE_MASTODON
from longwei.constants import INSTANCE_TYPE_PLEROMA
from longwei.constants import MAX_ATTACHMENTS_MASTODON
from longwei.enums import SearchType
from longwei.enums import Visibility
from longwei.exceptions import ActivityPubError
from longwei.exceptions import ApiError
from longwei.exceptions import ClientError
from longwei.exceptions import ConflictError
from longwei.exceptions import ForbiddenError
from longwei.exceptions import GoneError
from longwei.exceptions import NetworkError
from longwei.exceptions import NotFoundError
from longwei.exceptions import RatelimitError
from longwei.exceptions import ServerError
from longwei.exceptions import UnauthorizedError
from longwei.exceptions import UnprocessedError
from longwei.models import Account
from longwei.models import SearchResults
from longwei.types import APClientClass
from longwei.types import Status

logger = logging.getLogger(__display_name__)


class APClient(_RequestHelpersMixin, _CredentialsMixin, _TimelinesMixin, _StatusesMixin, _AuthMixin):
    """Simplifies interacting with an ActivityPub server / instance.

    This is a minimal implementation only implementing methods needed
    for the function of MastodonAmnesia
    """

    def __init__(
        self: APClientClass,
        instance: str,
        client: AsyncClient,
        access_token: str | None = None,
        timeout: int | None = None,
    ) -> None:
        """Initialise APClient instance with reasonable default values.

        :param instance: domain name or url to instance to connect to
        :param client: httpx AsyncClient to use for communicating with instance
        :param access_token: authentication token
        :param timeout: Optional number of seconds to wait for a response from the instance server.
            Defaults to None which equates to 120 seconds / 2 minutes timeout

        """
        self.instance = instance.rstrip("/")
        self.headers: list[tuple[str, str]] = []
        if access_token:
            self.headers.append(("Authorization", f"Bearer {access_token}"))
        self.client = client
        self.pagination: dict[str, dict[str, str | None]] = {
            "next": {"max_id": None, "min_id": None},
            "prev": {"max_id": None, "min_id": None},
        }
        self.timeout = timeout if timeout else 120
        self.instance_type = INSTANCE_TYPE_MASTODON  # default until determined otherwise with determine_instance_type()
        self.max_attachments = MAX_ATTACHMENTS_MASTODON
        self.max_att_size = 10000000
        self.supported_mime_types: list[str] = []
        self.max_status_len = 500
        self.ratelimit_limit = 300
        self.ratelimit_remaining = 300
        self.ratelimit_reset = datetime.now(UTC)
        logger.debug(
            "APClient(instance=%s, client=%s, access_token=<redacted>)",
            instance,
            client,
        )
        logger.debug("APClient() ... version=%s", __version__)

    @classmethod
    async def create(
        cls,
        instance: str,
        client: AsyncClient,
        access_token: str | None = None,
        timeout: int | None = None,
    ) -> "APClient":
        """Create and initialise an APClient instance, auto-detecting the instance type.

        This is the recommended entry point. Unlike direct instantiation, this factory
        automatically calls :meth:`determine_instance_type` to configure server-specific
        parameters (instance type, max status length, attachment limits, MIME types).

        :param instance: domain name or url to instance to connect to
        :param client: httpx AsyncClient to use for communicating with instance
        :param access_token: authentication token
        :param timeout: optional seconds to wait for a response (default: 120)
        :returns: Fully initialised :class:`APClient` instance
        :raises NetworkError: if the instance cannot be reached during type detection
        """
        ap = cls(instance=instance, client=client, access_token=access_token, timeout=timeout)
        await ap.determine_instance_type()
        return ap


__all__ = [  # noqa: RUF022
    "Account",
    "APClient",
    "APClientClass",
    "ActivityPubError",
    "ApiError",
    "ClientError",
    "ConflictError",
    "__display_name__",
    "ForbiddenError",
    "GoneError",
    "INSTANCE_TYPE_MASTODON",
    "INSTANCE_TYPE_PLEROMA",
    "NetworkError",
    "NotFoundError",
    "RatelimitError",
    "SearchResults",
    "SearchType",
    "ServerError",
    "Status",
    "UnauthorizedError",
    "UnprocessedError",
    "USER_AGENT",
    "__version__",
    "Visibility",
]
