"""Data models for longwei."""

from __future__ import annotations

from pydantic import BaseModel
from pydantic import ConfigDict


class Emoji(BaseModel):
    """A custom emoji used in statuses or account display names.

    :param shortcode: The shortcode of the emoji, e.g. ``blobcat``.
    :param url: URL to the full emoji image.
    :param static_url: URL to a static version of the emoji (no animation).
    :param visible_in_picker: Whether to show this emoji in the emoji picker.
    """

    model_config = ConfigDict(extra="allow")

    shortcode: str | None = None
    url: str | None = None
    static_url: str | None = None
    visible_in_picker: bool | None = None


class Field(BaseModel):
    """A profile field (name/value pair) on an account.

    :param name: The field label.
    :param value: The field content (may be HTML).
    :param verified_at: ISO 8601 timestamp if the URL was verified, else ``None``.
    """

    model_config = ConfigDict(extra="allow")

    name: str | None = None
    value: str | None = None
    verified_at: str | None = None


class Account(BaseModel):
    """An account (user profile) on an ActivityPub-compatible server.

    :param id: The account ID.
    :param username: The account username (local part only).
    :param acct: ``username@domain`` for remote accounts, ``username`` for local.
    :param display_name: The display name.
    :param note: The account bio (may be HTML).
    :param url: URL of the account's profile page.
    :param avatar: URL of the avatar image.
    :param avatar_static: URL of a static (non-animated) avatar.
    :param header: URL of the header image.
    :param header_static: URL of a static (non-animated) header.
    :param locked: Whether the account requires follow approval.
    :param bot: Whether the account is a bot.
    :param created_at: ISO 8601 timestamp of account creation.
    :param note: Profile bio (HTML).
    :param followers_count: Number of followers.
    :param following_count: Number of accounts followed.
    :param statuses_count: Number of statuses posted.
    :param last_status_at: Date of most recent status.
    :param emojis: Custom emojis used in display name or bio.
    :param fields: Profile metadata fields.
    """

    model_config = ConfigDict(extra="allow")

    id: str | None = None
    username: str | None = None
    acct: str | None = None
    display_name: str | None = None
    note: str | None = None
    url: str | None = None
    avatar: str | None = None
    avatar_static: str | None = None
    header: str | None = None
    header_static: str | None = None
    locked: bool | None = None
    bot: bool | None = None
    created_at: str | None = None
    followers_count: int | None = None
    following_count: int | None = None
    statuses_count: int | None = None
    last_status_at: str | None = None
    emojis: list[Emoji] | None = None
    fields: list[Field] | None = None


class Mention(BaseModel):
    """A mention of a user within a status.

    :param id: The account ID of the mentioned user.
    :param username: The username of the mentioned user.
    :param acct: The webfinger ``acct:`` of the mentioned user.
    :param url: The profile URL of the mentioned user.
    """

    model_config = ConfigDict(extra="allow")

    id: str | None = None
    username: str | None = None
    acct: str | None = None
    url: str | None = None


class Tag(BaseModel):
    """A hashtag used in a status.

    :param name: The hashtag text (without the leading ``#``).
    :param url: URL of the tag's timeline page.
    """

    model_config = ConfigDict(extra="allow")

    name: str | None = None
    url: str | None = None


class Application(BaseModel):
    """The application that created a status.

    :param name: The application name.
    :param website: The application website URL.
    """

    model_config = ConfigDict(extra="allow")

    name: str | None = None
    website: str | None = None


class MediaAttachment(BaseModel):
    """A media file attached to a status.

    :param id: The attachment ID.
    :param type: Media type: ``image``, ``video``, ``gifv``, ``audio``, ``unknown``.
    :param url: URL of the media file.
    :param preview_url: URL of a preview/thumbnail.
    :param remote_url: URL of the original remote media (for remote statuses).
    :param description: Alt-text description.
    :param blurhash: BlurHash string for placeholder display.
    """

    model_config = ConfigDict(extra="allow")

    id: str | None = None
    type: str | None = None
    url: str | None = None
    preview_url: str | None = None
    remote_url: str | None = None
    description: str | None = None
    blurhash: str | None = None


class Card(BaseModel):
    """A rich-preview card for a link in a status.

    :param url: The URL of the linked resource.
    :param title: The title of the linked page.
    :param description: A description of the linked page.
    :param type: Card type: ``link``, ``photo``, ``video``, ``rich``.
    :param author_name: Author of the linked page.
    :param provider_name: The provider of the linked page.
    :param html: Embed HTML for ``video`` and ``rich`` card types.
    :param width: Width of the embed (pixels).
    :param height: Height of the embed (pixels).
    :param image: Preview thumbnail URL.
    """

    model_config = ConfigDict(extra="allow")

    url: str | None = None
    title: str | None = None
    description: str | None = None
    type: str | None = None
    author_name: str | None = None
    author_url: str | None = None
    provider_name: str | None = None
    provider_url: str | None = None
    html: str | None = None
    width: int | None = None
    height: int | None = None
    image: str | None = None


class PollOption(BaseModel):
    """A single option in a poll.

    :param title: The option text.
    :param votes_count: Number of votes for this option (``None`` if results are hidden).
    """

    model_config = ConfigDict(extra="allow")

    title: str | None = None
    votes_count: int | None = None


class Poll(BaseModel):
    """A poll attached to a status.

    :param id: The poll ID.
    :param expires_at: ISO 8601 timestamp when the poll closes.
    :param expired: Whether the poll has already closed.
    :param multiple: Whether multiple choices are allowed.
    :param votes_count: Total number of votes cast.
    :param voters_count: Total number of unique accounts that voted.
    :param options: The list of poll options.
    :param voted: Whether the current user has voted.
    """

    model_config = ConfigDict(extra="allow")

    id: str | None = None
    expires_at: str | None = None
    expired: bool | None = None
    multiple: bool | None = None
    votes_count: int | None = None
    voters_count: int | None = None
    options: list[PollOption] = []
    voted: bool | None = None


class Status(BaseModel):
    """A status (post/toot) returned by an ActivityPub-compatible server.

    ``id`` is the only field that is consistently present across all server
    implementations (Mastodon, Pleroma, GotoSocial). All other fields
    use ``None`` as the default because server implementations vary — use
    ``is not None`` guards before accessing optional fields.

    :param id: The status ID.
    :param created_at: ISO 8601 creation timestamp (format varies by server).
    :param in_reply_to_id: ID of the status being replied to.
    :param in_reply_to_account_id: ID of the account being replied to.
    :param sensitive: Whether the content is marked sensitive.
    :param spoiler_text: Content warning text (shown before expanding).
    :param visibility: Visibility level: ``public``, ``unlisted``, ``private``, ``direct``.
    :param language: ISO 639-1 language code.
    :param uri: Canonical URI of the status.
    :param url: URL of the status's HTML page.
    :param replies_count: Number of replies.
    :param reblogs_count: Number of reblogs/boosts.
    :param favourites_count: Number of favourites/likes.
    :param favourited: Whether the current user has favourited this status.
    :param reblogged: Whether the current user has reblogged this status.
    :param muted: Whether the current user has muted this status's conversation.
    :param bookmarked: Whether the current user has bookmarked this status.
    :param pinned: Whether this status is pinned to the account profile.
    :param text: Plain-text source of the status (when available).
    :param content: HTML body of the status.
    :param reblog: The original status if this is a reblog/boost.
    :param application: The application that posted this status.
    :param account: The account that posted this status.
    :param media_attachments: Media files attached to this status.
    :param mentions: Accounts mentioned in this status.
    :param tags: Hashtags in this status.
    :param emojis: Custom emojis used in this status.
    :param card: Link preview card.
    :param poll: Attached poll.
    """

    model_config = ConfigDict(extra="allow")

    id: str | None = None
    created_at: str | None = None
    in_reply_to_id: str | None = None
    in_reply_to_account_id: str | None = None
    sensitive: bool | None = None
    spoiler_text: str | None = None
    visibility: str | None = None
    language: str | None = None
    uri: str | None = None
    url: str | None = None
    replies_count: int | None = None
    reblogs_count: int | None = None
    favourites_count: int | None = None
    favourited: bool | None = None
    reblogged: bool | None = None
    muted: bool | None = None
    bookmarked: bool | None = None
    pinned: bool | None = None
    text: str | None = None
    content: str | None = None
    reblog: Status | None = None
    application: Application | None = None
    account: Account | None = None
    media_attachments: list[MediaAttachment] | None = None
    mentions: list[Mention] | None = None
    tags: list[Tag] | None = None
    emojis: list[Emoji] | None = None
    card: Card | None = None
    poll: Poll | None = None


Status.model_rebuild()


class SearchResults(BaseModel):
    """Results from a search query.

    :param accounts: Matching accounts.
    :param statuses: Matching statuses.
    :param hashtags: Matching hashtags.
    """

    model_config = ConfigDict(extra="allow")

    accounts: list[Account] = []
    statuses: list[Status] = []
    hashtags: list[Tag] = []
