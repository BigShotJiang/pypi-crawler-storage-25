"""Exception hierarchy for longwei."""

from datetime import UTC
from datetime import datetime


class ActivityPubError(Exception):
    """Base class for all mastodon exceptions."""

    def __init__(  # noqa: PLR0913
        self,
        status_code: int | None = None,
        reason_phrase: str | None = None,
        message: str | None = None,
        *,
        endpoint: str | None = None,
        method: str | None = None,
        request_id: str | None = None,
        response_text: str | None = None,
    ) -> None:
        """Initialise with optional context for debugging.

        :param status_code: HTTP status code (e.g. 401)
        :param reason_phrase: HTTP reason phrase (e.g. "Unauthorized")
        :param message: Human-readable error message extracted from the API response
        :param endpoint: URL that was requested (includes query parameters)
        :param method: HTTP method used (e.g. "GET", "POST")
        :param request_id: Server-assigned request ID from ``X-Request-Id`` response header, if present
        :param response_text: Raw response body, truncated to 500 characters. Request body
            parameters are intentionally not captured to avoid logging sensitive content
            (access tokens, user-authored text, etc.).
        """
        self.status_code = status_code
        self.reason_phrase = reason_phrase
        self.message = message
        self.endpoint = endpoint
        self.method = method
        self.request_id = request_id
        self.response_text = response_text
        self.occurred_at: datetime = datetime.now(UTC)
        parts = []
        if status_code is not None:
            parts.append(str(status_code))
        if reason_phrase:
            parts.append(reason_phrase)
        if endpoint:
            parts.append(f"at {endpoint}")
        if message:
            parts.append(f"\u2014 {message}")
        super().__init__(" ".join(parts) if parts else "")


class NetworkError(ActivityPubError):
    """`NetworkError` is a subclass of `ActivityPubError` that is raised when
    there is a network error.
    """

    pass


class ApiError(ActivityPubError):
    """`ApiError` is a subclass of `ActivityPubError` that is raised when there
    is an API error.
    """

    pass


class ClientError(ActivityPubError):
    """`ClientError` is a subclass of `ActivityPubError` that is raised when
    there is a client error.
    """

    pass


class UnauthorizedError(ClientError):
    """`UnauthorizedError` is a subclass of `ClientError` that is raised when
    the user represented by the auth_token is not authorized to perform a
    certain action.
    """

    pass


class ForbiddenError(ClientError):
    """`ForbiddenError` is a subclass of `ClientError` that is raised when the
    user represented by the auth_token is forbidden to perform a certain
    action.
    """

    pass


class NotFoundError(ClientError):
    """`NotFoundError` is a subclass of `ClientError` that is raised when an
    object for an action cannot be found.
    """

    pass


class ConflictError(ClientError):
    """`ConflictError` is a subclass of `ClientError` that is raised when there
    is a conflict with performing an action.
    """

    pass


class GoneError(ClientError):
    """`GoneError` is a subclass of `ClientError` that is raised when an object
    for an action has gone / been deleted.
    """

    pass


class UnprocessedError(ClientError):
    """`UnprocessedError` is a subclass of `ClientError` that is raised when an
    action cannot be processed.
    """

    pass


class RatelimitError(ClientError):
    """`RatelimitError` is a subclass of `ClientError` that is raised when
    we've reached a limit of number of actions performed quickly.
    """

    def __init__(  # noqa: PLR0913
        self,
        status_code: int | None = None,
        reason_phrase: str | None = None,
        message: str | None = None,
        *,
        ratelimit_reset: datetime | None = None,
        ratelimit_limit: int | None = None,
        endpoint: str | None = None,
        method: str | None = None,
        request_id: str | None = None,
        response_text: str | None = None,
    ) -> None:
        """Initialise with optional rate-limit context in addition to base error context.

        :param status_code: HTTP status code (always 429 for this exception)
        :param reason_phrase: HTTP reason phrase
        :param message: Human-readable error message
        :param ratelimit_reset: Datetime when the rate limit window resets
        :param ratelimit_limit: Total requests allowed per rate-limit window
        :param endpoint: URL that was requested
        :param method: HTTP method used
        :param request_id: Server-assigned request ID from ``X-Request-Id`` header
        :param response_text: Raw response body, truncated to 500 characters
        """
        super().__init__(
            status_code,
            reason_phrase,
            message,
            endpoint=endpoint,
            method=method,
            request_id=request_id,
            response_text=response_text,
        )
        self.ratelimit_reset = ratelimit_reset
        self.ratelimit_limit = ratelimit_limit


class ServerError(ActivityPubError):
    """`ServerError` is a subclass of `ActivityPubError` that is raised when
    the server / instance encountered an error.
    """

    pass
