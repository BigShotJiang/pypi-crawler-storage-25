from datetime import datetime
from functools import cached_property
from typing import Literal, NamedTuple
from uuid import uuid4

from pydantic import BaseModel, Field, computed_field, model_validator

TCloningTrigger = Literal[
    "clone_with_warp_scheduler",
    "clone_no_special_network",
    "root_activation",
    "upload_git_root_file_mutation",
    "add_git_root_mutation",
    "migration",
    "update_git_root_mutation",
    "execute_machine_flow",
    "sync_git_root_mutation",
    "update_group_mutation",
    "update_group_managed_mutation",
    "reattack",
    "clone_roots_that_have_not_cloned",
    "re_queue_reattacks_scheduler",
]


class StateMachine(NamedTuple):
    arn: str
    name: str
    creation_date: datetime


class StateMachineCloningInput(BaseModel):
    model_config = {"extra": "forbid"}
    group_name: str = Field(..., serialization_alias="groupName")
    network_name: str | None = Field(default=None, serialization_alias="networkName")
    roots: list[str] = Field(..., serialization_alias="roots")
    user_email: str = Field(..., serialization_alias="userEmail")
    trigger: TCloningTrigger = Field(serialization_alias="trigger")
    execute_sifts: bool = Field(..., serialization_alias="executeSifts")

    @computed_field(alias="configId")  # type: ignore[prop-decorator]
    @cached_property
    def config_id(self) -> str:
        return str(uuid4().time)

    def get_machine_name(self) -> str:
        return f"{self.group_name}_{self.trigger}-{self.config_id}"


class StateMachineExecuteScannerInput(BaseModel):
    model_config = {"extra": "forbid"}
    config_id: str = Field(
        default_factory=lambda: str(uuid4().time), serialization_alias="configId"
    )
    group_name: str = Field(..., serialization_alias="groupName")
    image_refs: list[str] | None = Field(default=None, serialization_alias="imageRefs")
    job_definition: str = Field(..., serialization_alias="jobDefinition")
    job_queue: str = Field(..., serialization_alias="jobQueue")
    job_origin: str = Field(..., serialization_alias="jobOrigin", exclude=True)
    network_name: str | None = Field(default=None, serialization_alias="networkName")
    roots: list[str] = Field(..., min_length=1, serialization_alias="roots")
    scanner_name: str = Field(..., serialization_alias="scannerName")
    user_email: str = Field(..., serialization_alias="userEmail")

    def get_machine_name(self) -> str:
        return f"{self.group_name}_{self.job_origin}_{self.scanner_name}_{self.config_id}"


class StateMachineExecuteSiftsInput(BaseModel):
    model_config = {"extra": "forbid"}
    config_id: str = Field(
        default_factory=lambda: str(uuid4().time), serialization_alias="configId"
    )
    group_name: str = Field(..., serialization_alias="groupName")
    root_nickname: str = Field(..., serialization_alias="rootNickname")
    trigger: TCloningTrigger = Field(..., serialization_alias="trigger")
    user_email: str = Field(..., serialization_alias="userEmail")

    def get_machine_name(self) -> str:
        return f"{self.group_name}_{self.trigger}_execute_sifts_{self.config_id}"


class StateMachineRequestSbomMailInput(BaseModel):
    model_config = {"extra": "forbid"}
    config_id: str = Field(
        default_factory=lambda: str(uuid4().time), serialization_alias="configId"
    )
    group_name: str = Field(..., serialization_alias="groupName")
    roots: list[str] = Field(default_factory=list, serialization_alias="roots")
    roots_notification_ids: list[str] = Field(
        default_factory=list, serialization_alias="rootsNotificationIds"
    )
    images: list[str] = Field(default_factory=list, serialization_alias="images")
    images_notification_ids: list[str] = Field(
        default_factory=list, serialization_alias="imagesNotificationIds"
    )
    user_email: str = Field(..., serialization_alias="userEmail")
    sbom_format: str = Field(..., serialization_alias="sbomFormat")

    @model_validator(mode="after")
    def validate_fields(self) -> "StateMachineRequestSbomMailInput":
        if not self.roots and not self.images:
            msg = "At least one root or image must be provided"
            raise ValueError(msg)
        if len(self.roots) != len(self.roots_notification_ids):
            msg = "roots_notification_ids must have the same length as roots"
            raise ValueError(msg)
        if len(self.images) != len(self.images_notification_ids):
            msg = "images_notification_ids must have the same length as images"
            raise ValueError(msg)
        return self

    def get_machine_name(self) -> str:
        return f"{self.group_name}_request_sbom_mail_{self.config_id}"
