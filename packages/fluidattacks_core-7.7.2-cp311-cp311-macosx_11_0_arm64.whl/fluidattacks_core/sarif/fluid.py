"""Fluid Attacks typed SARIF 2.1.0 report models.

A strictly typed subset of the SARIF 2.1.0 schema covering only the fields
that Fluid Attacks scanners produce. Designed to parse
the same JSON as sarif.SarifLog, but with explicit types replacing PropertyBag
model_extra access.

Container models (runs, results, locations) use extra="ignore" so that valid
SARIF files with additional standard fields continue to parse. Property models
(FluidResultProperties, FluidRuleProperties, FluidWebResponseProperties,
ScaProperties) use extra="forbid" to enforce the exact shape of Fluid-specific
data.
"""

from enum import StrEnum
from typing import Literal

from pydantic import AnyUrl, BaseModel, ConfigDict, Field, model_validator

from fluidattacks_core.sarif import Level, SarifLog


class FluidVulnerabilityType(StrEnum):
    LINES = "LINES"
    INPUTS = "INPUTS"
    PORTS = "PORTS"


class FluidTechnique(StrEnum):
    SAST = "SAST"
    SCA = "SCA"
    DAST = "DAST"
    CSPM = "CSPM"
    MAST = "MAST"
    SS = "SS"


# Property models — extra="forbid" to catch unknown Fluid-specific fields


class ScaSeverityCves(BaseModel):
    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    critical: list[str] | None = None
    high: list[str] | None = None
    medium: list[str] | None = None
    low: list[str] | None = None
    total: int


class ScaResidualCves(BaseModel):
    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    remedied: ScaSeverityCves | None = None
    maintained: ScaSeverityCves | None = None
    introduced: ScaSeverityCves | None = None


class ScaFixMetadata(BaseModel):
    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    fix_version: str
    upgrade_type: str
    breaking_change: bool
    residual_cves: ScaResidualCves | None = None


class ScaFixMetadataFull(BaseModel):
    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    closest_min_fix: ScaFixMetadata | None = None
    top_parents: list[str] | None = None
    closest_safe_fix: ScaFixMetadata | None = None
    closest_complete_fix: ScaFixMetadata | None = None


class ScaProperties(BaseModel):
    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    package: str
    vulnerable_version: str
    advisory_id: str
    epss: float | str | None = None
    scope: str | None = None
    is_reachable: bool = False
    package_manager: str | None = None
    ecosystem: str | None = None
    dependency_type: str | None = None
    reachability_status: str | None = None
    fix_metadata_new: ScaFixMetadataFull | None = None
    kev_catalog: bool = False


class FluidResultProperties(BaseModel):
    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    auto_approve: bool = False
    vulnerability_type: FluidVulnerabilityType
    technique: FluidTechnique
    source_method: str
    method_developer: str = ""
    cwe_ids: list[str] | None = None
    cvss_v4: str
    cvss_v4_score: float | None = None
    cvss_v4_severity: str | None = None
    sca: ScaProperties | None = None
    has_redirect: bool = False
    original_url: str | None = None
    environment_id: str | None = None
    missing_dependency: str | None = None


class FluidRuleProperties(BaseModel):
    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    auto_approve: bool = False


class FluidCspmErrorMethods(BaseModel):
    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    aws: list[str] = Field(default_factory=list)
    aws_detailed_errors: dict[str, dict[str, list[str]]] = Field(default_factory=dict)


class FluidWebResponseProperties(BaseModel):
    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    url: str | None = None
    ssl_status: bool | None = None
    error_methods: FluidCspmErrorMethods | None = None


# Container models — extra="ignore" to accept broader SARIF output


class FluidMessage(BaseModel):
    model_config = ConfigDict(extra="ignore", populate_by_name=True)

    text: str | None = None


class FluidArtifactContent(BaseModel):
    model_config = ConfigDict(extra="ignore", populate_by_name=True)

    text: str


class FluidArtifactLocation(BaseModel):
    model_config = ConfigDict(extra="ignore", populate_by_name=True)

    uri: str


class FluidRegion(BaseModel):
    model_config = ConfigDict(extra="ignore", populate_by_name=True)

    start_line: int | None = Field(default=None, alias="startLine")
    snippet: FluidArtifactContent | None = None
    message: FluidMessage | None = None


class FluidPhysicalLocation(BaseModel):
    model_config = ConfigDict(extra="ignore", populate_by_name=True)

    artifact_location: FluidArtifactLocation = Field(alias="artifactLocation")
    region: FluidRegion | None = None


class FluidLocation(BaseModel):
    model_config = ConfigDict(extra="ignore", populate_by_name=True)

    physical_location: FluidPhysicalLocation = Field(alias="physicalLocation")


class FluidToolComponentRef(BaseModel):
    model_config = ConfigDict(extra="ignore", populate_by_name=True)

    name: str


class FluidTaxon(BaseModel):
    model_config = ConfigDict(extra="ignore", populate_by_name=True)

    id: str
    tool_component: FluidToolComponentRef | None = Field(default=None, alias="toolComponent")


class FluidResult(BaseModel):
    model_config = ConfigDict(extra="ignore", populate_by_name=True)

    rule_id: str = Field(alias="ruleId")
    level: Level
    message: FluidMessage
    locations: list[FluidLocation]
    fingerprints: dict[str, str]
    taxa: list[FluidTaxon] | None = None
    properties: FluidResultProperties


class FluidMultiformatMessageString(BaseModel):
    model_config = ConfigDict(extra="ignore", populate_by_name=True)

    text: str
    markdown: str | None = None


class FluidRule(BaseModel):
    model_config = ConfigDict(extra="ignore", populate_by_name=True)

    id: str
    name: str
    full_description: FluidMultiformatMessageString | None = Field(
        default=None, alias="fullDescription"
    )
    help_uri: AnyUrl | None = Field(default=None, alias="helpUri")
    help: FluidMultiformatMessageString | None = None
    properties: FluidRuleProperties | None = None


class FluidDriver(BaseModel):
    model_config = ConfigDict(extra="ignore", populate_by_name=True)

    name: str
    version: str
    semantic_version: str | None = Field(default=None, alias="semanticVersion")
    rules: list[FluidRule] = Field(default_factory=list)


class FluidTool(BaseModel):
    model_config = ConfigDict(extra="ignore", populate_by_name=True)

    driver: FluidDriver


class FluidVersionControlProvenance(BaseModel):
    model_config = ConfigDict(extra="ignore", populate_by_name=True)

    repository_uri: str = Field(alias="repositoryUri")
    revision_id: str = Field(alias="revisionId")
    branch: str | None = None


class FluidOriginalUriBaseId(BaseModel):
    model_config = ConfigDict(extra="ignore", populate_by_name=True)

    uri: str


class FluidWebResponse(BaseModel):
    model_config = ConfigDict(extra="ignore", populate_by_name=True)

    status_code: int | None = Field(default=None, alias="statusCode")
    properties: FluidWebResponseProperties | None = None


class FluidRun(BaseModel):
    model_config = ConfigDict(extra="ignore", populate_by_name=True)

    tool: FluidTool
    version_control_provenance: list[FluidVersionControlProvenance] | None = Field(
        default=None, alias="versionControlProvenance"
    )
    original_uri_base_ids: dict[str, FluidOriginalUriBaseId] | None = Field(
        default=None, alias="originalUriBaseIds"
    )
    results: list[FluidResult] = Field(default_factory=list)
    web_responses: list[FluidWebResponse] | None = Field(default=None, alias="webResponses")


class FluidSarifReport(BaseModel):
    """Typed representation of a Fluid Attacks SARIF 2.1.0 report.

    Parses the same JSON produced by Fluid Attacks scanners. Use
    model_validate_json() or model_validate() to construct from raw SARIF.

    The before-validator ensures every instance also satisfies the full
    SARIF 2.1.0 schema (sarif.SarifLog) before Fluid-specific typing is
    applied.
    """

    model_config = ConfigDict(extra="ignore", populate_by_name=True)

    schema_url: str | None = Field(default=None, alias="$schema")
    version: Literal["2.1.0"]
    runs: list[FluidRun]

    @model_validator(mode="before")
    @classmethod
    def _ensure_sarif_compliance(cls, data: object) -> object:
        SarifLog.model_validate(data)
        return data
