import polars as pl

lf: pl.LazyFrame = None
# {{paste:begin}}

# {{paste:DIAG_initial_sorting_all}}

# {{paste:DIAG_stats}}

"""
Converts into counts
"""
lf = lf.with_columns(
    (
        pl.col("TDiag") + pl.int_range(1, pl.len() + 1).over("TDiag").cast(pl.String)
    ).over("case:PNR")
)

lf = lf.with_columns(
    pl.when(pl.col("TDiag").str.starts_with("CANCER"))
    .then(
        pl.when(pl.col("TDiag").str.extract(r"(\d+)$").cast(pl.Int32) > 3)
        .then(pl.lit("CANCER3+"))
        .otherwise(pl.col("TDiag"))
    )
    .when(pl.col("TDiag").str.starts_with("CARDIOVASCULAR"))
    .then(
        pl.when(pl.col("TDiag").str.extract(r"(\d+)$").cast(pl.Int32) > 3)
        .then(pl.lit("CARDIOVASCULAR3+"))
        .otherwise(pl.col("TDiag"))
    )
    .when(pl.col("TDiag").str.starts_with("MUSCULOSKELETAL"))
    .then(
        pl.when(pl.col("TDiag").str.extract(r"(\d+)$").cast(pl.Int32) > 2)
        .then(pl.lit("MUSCULOSKELETAL2+"))
        .otherwise(pl.col("TDiag"))
    )
    .otherwise(pl.col("TDiag"))
    .alias("TDiag")
)

# {{paste:burst}}

"""
Filter events
"""
allowed_events = ["MUSCULOSKELETAL", "CARDIOVASCULAR", "CANCER", "Death"]
pattern = "^" + "|".join(allowed_events)
lf_allowed = lf.filter(
    (pl.col("TDiag").str.contains(pattern) & ~pl.col("TDiag").str.contains("SENSORY")) # An activity is called `MUSCULOSKELETAL, SENSORY ORGANS` and we want to exclude it
    .all()
    .over("case:PNR")
)
lf_strict = lf_allowed.filter(
    pl.all_horizontal(
        [
            pl.col("TDiag").str.contains(ev).any().over("case:PNR")
            for ev in allowed_events[:-1]
        ]
    )
)

df, df_allowed, df_strict = pl.collect_all([lf, lf_allowed, lf_strict])

"""
Stats
"""
def print_stats(df: pl.DataFrame, print_all=False):
    total_cases = df["case:PNR"].n_unique()

    stats = (
        df.group_by("TDiag")
        .agg((pl.len() / total_cases).alias("stat"))
        .sort("stat", descending=True)
    )

    print(f"{'-' * 10} All events {'-' * 10}")
    for row in stats.iter_rows(named=True):
        print(f"{row['TDiag']:.<18}: {row['stat']:.2%}")

    if print_all:
        print(f"{'-' * 10} Only allowed events {'-' * 10}")
        for row in stats.iter_rows(named=True):
            if any(row["TDiag"].startswith(event) for event in allowed_events):
                print(f"{row['TDiag']:.<18}: {row['stat']:.2%}")


print("DF")
print_stats(df, True)
print("\nDF Allowed")
print_stats(df_allowed)
print("\nDF Strict")
print_stats(df_strict)
