"""ODIN transform verbs."""
