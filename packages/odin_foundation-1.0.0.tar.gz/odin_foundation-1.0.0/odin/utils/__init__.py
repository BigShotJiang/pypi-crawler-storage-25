"""ODIN utility modules."""
