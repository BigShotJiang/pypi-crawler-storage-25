from setuptools import setup, find_packages

setup(
    name="fastapi_auth_project",
    version="0.1",
    packages=find_packages(),
    install_requires=["fastapi>=0.121.2"]
)