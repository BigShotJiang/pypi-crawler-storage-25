from __future__ import annotations

import asyncio
from datetime import datetime
from typing import Any, Optional

from .models import Message, MessageRole, Session


class SessionManager:
    """内存会话管理器，不做持久化。"""

    def __init__(self):
        self._sessions: dict[str, Session] = {}
        self._queues: dict[str, asyncio.Queue[Message]] = {}
        self._ws_clients: set[Any] = set()

    # ── 会话 CRUD ──────────────────────────────

    def get_or_create(self, session_id: str) -> Session:
        if session_id not in self._sessions:
            self._sessions[session_id] = Session(id=session_id)
            self._queues[session_id] = asyncio.Queue()
        return self._sessions[session_id]

    def list_sessions(self) -> list[Session]:
        return sorted(
            self._sessions.values(),
            key=lambda s: s.updated_at,
            reverse=True,
        )

    def rename_session(self, session_id: str, title: str):
        if session_id in self._sessions:
            self._sessions[session_id].title = title

    def delete_session(self, session_id: str):
        self._sessions.pop(session_id, None)
        self._queues.pop(session_id, None)

    def delete_message(self, session_id: str, message_id: str) -> bool:
        session = self._sessions.get(session_id)
        if not session:
            return False
        before = len(session.messages)
        session.messages = [m for m in session.messages if m.id != message_id]
        if len(session.messages) < before:
            session.updated_at = datetime.now().isoformat()
            return True
        return False

    # ── 消息 ───────────────────────────────────

    MAX_HISTORY = 3

    async def push_user_message(
        self, session_id: str, content: str, images: list[str] | None = None
    ) -> Message:
        session = self.get_or_create(session_id)
        msg = Message(role=MessageRole.USER, content=content, images=images or [])
        session.messages.append(msg)
        self._trim(session)
        session.updated_at = datetime.now().isoformat()
        await self._queues[session_id].put(msg)
        return msg

    def add_assistant_message(self, session_id: str, content: str) -> Message:
        session = self.get_or_create(session_id)
        msg = Message(role=MessageRole.ASSISTANT, content=content)
        session.messages.append(msg)
        self._trim(session)
        session.updated_at = datetime.now().isoformat()
        return msg

    @staticmethod
    def _trim(session: Session):
        if len(session.messages) > SessionManager.MAX_HISTORY:
            session.messages = session.messages[-SessionManager.MAX_HISTORY:]

    async def wait_for_message(
        self, session_id: str, timeout: float = 60.0
    ) -> Optional[Message]:
        self.get_or_create(session_id)
        try:
            return await asyncio.wait_for(
                self._queues[session_id].get(), timeout=timeout
            )
        except asyncio.TimeoutError:
            return None

    # ── WebSocket 管理 ─────────────────────────

    def register_ws(self, ws: Any):
        self._ws_clients.add(ws)

    def unregister_ws(self, ws: Any):
        self._ws_clients.discard(ws)

    async def broadcast(self, data: dict):
        dead: list[Any] = []
        for ws in self._ws_clients:
            try:
                await ws.send_json(data)
            except Exception:
                dead.append(ws)
        for ws in dead:
            self._ws_clients.discard(ws)
