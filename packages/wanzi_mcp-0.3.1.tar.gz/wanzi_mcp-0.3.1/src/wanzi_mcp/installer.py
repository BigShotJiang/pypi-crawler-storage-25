"""一键写入 Cursor 全局 mcp.json，注册丸子 MCP。"""

from __future__ import annotations

import json
from pathlib import Path


def install_to_cursor(port: int = 8765):
    mcp_json = Path.home() / ".cursor" / "mcp.json"
    mcp_json.parent.mkdir(parents=True, exist_ok=True)

    config: dict = {}
    if mcp_json.exists():
        try:
            config = json.loads(mcp_json.read_text("utf-8"))
        except Exception:
            pass

    servers = config.setdefault("mcpServers", {})
    servers["wanzi-mcp"] = {"url": f"http://localhost:{port}/sse"}

    mcp_json.write_text(json.dumps(config, indent=2, ensure_ascii=False), "utf-8")
    print(f"[OK] written to {mcp_json}")
    print(f"  SSE: http://localhost:{port}/sse")
