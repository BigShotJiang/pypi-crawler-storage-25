from __future__ import annotations

import base64
import contextvars
import json
import tempfile
import uuid as _uuid
from pathlib import Path

from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.routing import Mount, Route, WebSocketRoute
from starlette.staticfiles import StaticFiles
from starlette.websockets import WebSocket, WebSocketDisconnect

from mcp.server import Server
from mcp.server.sse import SseServerTransport
import mcp.types as types

from .session import SessionManager

manager = SessionManager()

_UPLOAD_DIR = Path(tempfile.gettempdir()) / "wanzi-mcp-uploads"
_UPLOAD_DIR.mkdir(exist_ok=True)

_MIME_MAP = {
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".gif": "image/gif",
    ".webp": "image/webp",
    ".bmp": "image/bmp",
}

_sse_session_id: contextvars.ContextVar[str] = contextvars.ContextVar(
    "sse_session_id", default="default"
)
_active_sse_connections: set[str] = set()
_sse_sessions: dict[str, set[str]] = {}

# ── MCP Server ──────────────────────────────────
mcp_server = Server("wanzi-mcp")
sse_transport = SseServerTransport("/messages/")

_CHECK_DESC = (
    "[丸子 MCP] 获取用户通过 GUI 发送的消息。本工具会阻塞直到用户发送消息，无需设置超时。"
    "每次收到用户消息并处理完毕后，必须立即再次调用本工具等待下一条消息。"
    "reply 参数用于向用户反馈：把你要对用户说的话、要问的问题、任务进展等写在 reply 里，"
    "用户会在 GUI 窗口看到。每次调用都应通过 reply 给出有意义的回复，不要留空。"
    "返回 JSON 含 session_id，后续每次调用必须传回同一个 session_id。"
)


@mcp_server.list_tools()
async def handle_list_tools():
    return [
        types.Tool(
            name="check_messages",
            description=_CHECK_DESC,
            inputSchema={
                "type": "object",
                "properties": {
                    "session_id": {
                        "type": "string",
                        "description": "会话 ID，首次不传由系统分配，后续必须传回",
                    },
                    "reply": {
                        "type": "string",
                        "description": "向用户反馈：要说的话、要问的问题、进展等",
                    },
                },
            },
        ),
        types.Tool(
            name="send_message",
            description="主动推送消息到 GUI 窗口（单向推送，不等回复）。需传入 session_id。",
            inputSchema={
                "type": "object",
                "properties": {
                    "session_id": {"type": "string", "description": "会话 ID"},
                    "content": {"type": "string", "description": "消息内容"},
                },
                "required": ["content"],
            },
        ),
        types.Tool(
            name="ask_question",
            description="向用户提问并等待回答。问题会显示在 GUI 窗口，用户回答后返回。需传入 session_id。",
            inputSchema={
                "type": "object",
                "properties": {
                    "session_id": {"type": "string", "description": "会话 ID"},
                    "question": {"type": "string", "description": "要问用户的问题"},
                },
                "required": ["question"],
            },
        ),
    ]


async def _ensure_session(sid: str):
    """首次调用时才创建会话并通知 GUI。"""
    is_new = sid not in manager._sessions
    session = manager.get_or_create(sid)
    if is_new:
        await manager.broadcast(
            {"type": "session_created", "session": session.to_summary()}
        )
        connect_msg = manager.add_assistant_message(sid, "🔗 Cursor 会话已连接")
        await manager.broadcast(
            {
                "type": "assistant_message",
                "session_id": sid,
                "message": connect_msg.to_dict(),
            }
        )
    return session


@mcp_server.call_tool()
async def handle_call_tool(name: str, arguments: dict):
    if name == "check_messages":
        sid = arguments.get("session_id") or _uuid.uuid4().hex[:8]
        reply = arguments.get("reply")
        conn_id = _sse_session_id.get()
        _sse_sessions.setdefault(conn_id, set()).add(sid)

        await _ensure_session(sid)

        if reply:
            msg = manager.add_assistant_message(sid, reply)
            await manager.broadcast(
                {
                    "type": "assistant_message",
                    "session_id": sid,
                    "message": msg.to_dict(),
                }
            )

        await manager.broadcast({"type": "session_waiting", "session_id": sid})
        user_msg = None
        while user_msg is None:
            if sid not in manager._sessions:
                return [types.TextContent(type="text", text=json.dumps(
                    {"session_id": sid, "content": "会话已被用户关闭。"},
                    ensure_ascii=False,
                ))]
            user_msg = await manager.wait_for_message(sid)

        result = {"session_id": sid, "content": user_msg.content or ""}
        parts: list = [types.TextContent(type="text", text=json.dumps(result, ensure_ascii=False))]
        for img_url in user_msg.images:
            img_data = _read_upload_as_base64(img_url)
            if img_data:
                parts.append(types.ImageContent(
                    type="image",
                    data=img_data["data"],
                    mimeType=img_data["mime"],
                ))
        return parts

    if name == "send_message":
        sid = arguments.get("session_id") or _uuid.uuid4().hex[:8]
        content = arguments["content"]
        conn_id = _sse_session_id.get()
        _sse_sessions.setdefault(conn_id, set()).add(sid)
        await _ensure_session(sid)
        msg = manager.add_assistant_message(sid, content)
        await manager.broadcast(
            {
                "type": "assistant_message",
                "session_id": sid,
                "message": msg.to_dict(),
            }
        )
        return [types.TextContent(type="text", text=json.dumps({"session_id": sid, "sent": True}, ensure_ascii=False))]

    if name == "ask_question":
        sid = arguments.get("session_id") or _uuid.uuid4().hex[:8]
        question = arguments["question"]
        conn_id = _sse_session_id.get()
        _sse_sessions.setdefault(conn_id, set()).add(sid)
        await _ensure_session(sid)
        msg = manager.add_assistant_message(sid, question)
        await manager.broadcast(
            {
                "type": "assistant_message",
                "session_id": sid,
                "message": msg.to_dict(),
            }
        )
        await manager.broadcast({"type": "session_waiting", "session_id": sid})
        answer = None
        while answer is None:
            if sid not in manager._sessions:
                return [types.TextContent(type="text", text=json.dumps(
                    {"session_id": sid, "content": "会话已被用户关闭。"},
                    ensure_ascii=False,
                ))]
            answer = await manager.wait_for_message(sid)

        result = {"session_id": sid, "content": answer.content or ""}
        parts: list = [types.TextContent(type="text", text=json.dumps(result, ensure_ascii=False))]
        for img_url in answer.images:
            img_data = _read_upload_as_base64(img_url)
            if img_data:
                parts.append(types.ImageContent(
                    type="image",
                    data=img_data["data"],
                    mimeType=img_data["mime"],
                ))
        return parts

    raise ValueError(f"Unknown tool: {name}")


# ── SSE endpoint ────────────────────────────────
async def handle_sse(request):
    sid = _uuid.uuid4().hex[:8]
    _sse_session_id.set(sid)
    _active_sse_connections.add(sid)

    try:
        async with sse_transport.connect_sse(
            request.scope, request.receive, request._send
        ) as streams:
            await mcp_server.run(
                streams[0],
                streams[1],
                mcp_server.create_initialization_options(),
            )
    finally:
        _active_sse_connections.discard(sid)
        for s_id in _sse_sessions.pop(sid, set()):
            if s_id in manager._sessions:
                disc_msg = manager.add_assistant_message(s_id, "⚠️ Cursor 会话已断开")
                await manager.broadcast(
                    {
                        "type": "assistant_message",
                        "session_id": s_id,
                        "message": disc_msg.to_dict(),
                    }
                )


# ── WebSocket endpoint ─────────────────────────
async def handle_ws(ws: WebSocket):
    await ws.accept()
    manager.register_ws(ws)
    try:
        while True:
            data = await ws.receive_json()
            action = data.get("type")

            if action == "send_message":
                sid = data["session_id"]
                content = data.get("content", "")
                images = data.get("images", [])
                msg = await manager.push_user_message(sid, content, images)
                await manager.broadcast(
                    {
                        "type": "user_message",
                        "session_id": sid,
                        "message": msg.to_dict(),
                    }
                )

            elif action == "list_sessions":
                await ws.send_json(
                    {
                        "type": "session_list",
                        "sessions": [
                            s.to_summary() for s in manager.list_sessions()
                        ],
                    }
                )

            elif action == "get_session":
                sid = data["session_id"]
                session = manager.get_or_create(sid)
                await ws.send_json(
                    {"type": "session_detail", "session": session.to_dict()}
                )

            elif action == "create_session":
                sid = data.get("session_id") or _uuid.uuid4().hex[:8]
                title = data.get("title", "新会话")
                session = manager.get_or_create(sid)
                session.title = title
                await manager.broadcast(
                    {"type": "session_created", "session": session.to_summary()}
                )

            elif action == "rename_session":
                manager.rename_session(data["session_id"], data["title"])
                await manager.broadcast(
                    {
                        "type": "session_renamed",
                        "session_id": data["session_id"],
                        "title": data["title"],
                    }
                )

            elif action == "delete_session":
                manager.delete_session(data["session_id"])
                await manager.broadcast(
                    {"type": "session_deleted", "session_id": data["session_id"]}
                )

            elif action == "delete_message":
                sid = data["session_id"]
                mid = data["message_id"]
                if manager.delete_message(sid, mid):
                    await manager.broadcast(
                        {
                            "type": "message_deleted",
                            "session_id": sid,
                            "message_id": mid,
                        }
                    )
    except WebSocketDisconnect:
        pass
    finally:
        manager.unregister_ws(ws)


# ── 图片上传 ────────────────────────────────────
def _read_upload_as_base64(img_url: str) -> dict | None:
    filename = img_url.split("/")[-1]
    path = _UPLOAD_DIR / filename
    if not path.exists():
        return None
    suffix = path.suffix.lower()
    mime = _MIME_MAP.get(suffix, "image/png")
    return {"data": base64.b64encode(path.read_bytes()).decode(), "mime": mime}


async def handle_upload(request: Request):
    form = await request.form()
    file = form.get("file")
    if file is None:
        return JSONResponse({"ok": False, "message": "no file"}, status_code=400)

    ext = Path(file.filename).suffix.lower() if file.filename else ".png"
    if ext not in _MIME_MAP:
        return JSONResponse({"ok": False, "message": "不支持的图片格式"}, status_code=400)

    name = _uuid.uuid4().hex[:12] + ext
    dest = _UPLOAD_DIR / name
    dest.write_bytes(await file.read())

    url = f"/uploads/{name}"
    return JSONResponse({"ok": True, "url": url})


# ── REST: 服务状态 ──────────────────────────────
async def handle_status(request: Request):
    return JSONResponse({
        "ok": True,
        "sse_connections": len(_active_sse_connections),
        "ws_connections": len(manager._ws_clients),
        "sessions": len(manager._sessions),
    })


# ── REST: 安装到 Cursor ─────────────────────────
async def handle_install(request: Request):
    from .installer import install_to_cursor

    port = request.query_params.get("port", "8765")
    try:
        install_to_cursor(int(port))
        return JSONResponse({"ok": True, "message": "已写入 ~/.cursor/mcp.json"})
    except Exception as e:
        return JSONResponse({"ok": False, "message": str(e)}, status_code=500)


# ── Build ASGI app ──────────────────────────────
_STATIC_DIR = Path(__file__).parent / "gui" / "static"


def create_app() -> Starlette:
    return Starlette(
        routes=[
            Route("/sse", handle_sse),
            Route("/api/status", handle_status),
            Route("/api/install", handle_install, methods=["POST"]),
            Route("/api/upload", handle_upload, methods=["POST"]),
            Mount("/messages", app=sse_transport.handle_post_message),
            Mount("/uploads", app=StaticFiles(directory=str(_UPLOAD_DIR))),
            WebSocketRoute("/ws", handle_ws),
            Mount(
                "/",
                app=StaticFiles(directory=str(_STATIC_DIR), html=True),
            ),
        ],
    )


app = create_app()
