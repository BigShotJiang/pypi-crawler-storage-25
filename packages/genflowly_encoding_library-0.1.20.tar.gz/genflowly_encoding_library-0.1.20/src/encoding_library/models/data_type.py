from enum import Enum

class DataType(Enum):
    EMAIL = "EMAIL"
    NOTE = "NOTE"
