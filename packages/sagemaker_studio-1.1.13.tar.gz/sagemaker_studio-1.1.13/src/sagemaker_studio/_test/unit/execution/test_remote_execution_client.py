import unittest
from datetime import datetime, timezone
from unittest.mock import Mock, patch

from botocore.exceptions import ClientError

from sagemaker_studio.execution.remote_execution_client import (
    DEFAULT_IMAGE_VERSION,
    DEFAULT_INSTANCE_TYPE,
    FALLBACK_INSTANCE_TYPE,
    RemoteExecutionClient,
)
from sagemaker_studio.models.execution import (
    ConflictError,
    ExecutionConfig,
    InternalServerError,
    ValidationError,
)


class TestRemoteExecutionClient(unittest.TestCase):

    @patch.object(RemoteExecutionClient, "_RemoteExecutionClient__set_default_tooling_environment")
    @patch.object(RemoteExecutionClient, "_RemoteExecutionClient__set_sagemaker_environment")
    @patch.object(RemoteExecutionClient, "_RemoteExecutionClient__set_sagemaker_client")
    @patch.object(RemoteExecutionClient, "_RemoteExecutionClient__set_ec2client")
    @patch.object(RemoteExecutionClient, "_RemoteExecutionClient__set_ssmclient")
    @patch.object(RemoteExecutionClient, "_RemoteExecutionClient__set_stack")
    def setUp(
        self,
        mock_set_stack,
        mock_set_ssmclient,
        mock_set_ec2client,
        mock_set_sagemaker_client,
        mock_set_sagemaker_environment,
        mock_set_default_tooling_environment,
    ):
        # setup datazone api mock
        self.datazone_api = Mock()
        self.datazone_api.get_environment_credentials.return_value = self._default_env_creds()
        # setup project api mock
        self.project_api = Mock()
        project_api_instance = self.project_api.return_value
        project_api_instance.get_project_sagemaker_environment.return_value = (
            self._default_sage_maker_environment_summary()
        )
        self.base_session = Mock()
        self.sagemaker_client = Mock()
        self.base_session.client.return_value = self.sagemaker_client
        self.execution_config = ExecutionConfig()
        self.execution_config.domain_identifier = "domain_123"
        self.execution_config.project_identifier = "project_123"
        self.execution_config.datazone_environment_id = "environment_123"
        self.remote_client = RemoteExecutionClient(
            self.datazone_api, self.project_api, self.execution_config
        )

    def _default_env_creds(self):
        return {
            "accessKeyId": "123",
            "expiration": "1970",
            "secretAccessKey": "456",
            "sessionToken": "789",
        }

    def _default_sage_maker_environment_summary(self):
        return {
            "awsAccountId": "1234567890",
            "awsAccountRegion": "us-east-1",
            "domainId": "domain_123",
            "environmentBlueprintId": "bogus_env_blueprint_id",
            "environmentProfileId": "bogus_env_profile_id",
            "id": "bogus_env_id",
            "name": "bogus_env_name",
            "projectId": "project_123",
            "provider": "Amazon SageMaker",
            "provisionedResources": [
                {
                    "name": "s3BucketPath",
                    "provider": "Amazon SageMaker",
                    "type": "string",
                    "value": "bogus_s3_bucket_path",
                },
                {
                    "name": "kmsKeyArn",
                    "provider": "Amazon SageMaker",
                    "type": "string",
                    "value": "bogus_project_kms_key_arn",
                },
                {
                    "name": "otherProvisionedResource",
                    "provider": "Amazon SageMaker",
                    "type": "string",
                    "value": "bogus_provisioned_resource_value",
                },
            ],
            "status": "ACTIVE",
        }

    def test_execution_client_api_fails_no_domain_identifier(self):
        execution_config = ExecutionConfig()
        execution_config.project_identifier = "project_123"
        with self.assertRaises(InternalServerError):
            remote_client = RemoteExecutionClient(
                self.datazone_api, self.project_api, execution_config
            )
            remote_client.list_executions()

    def test_execution_client_api_fails_no_project_identifier(self):
        execution_config = ExecutionConfig()
        execution_config.domain_identifier = "domain_123"
        with self.assertRaises(InternalServerError):
            remote_client = RemoteExecutionClient(
                self.datazone_api, self.project_api, execution_config
            )
            remote_client.list_executions()

    def test_validate_execution_name(self):
        # valid name can have 26 chars maximum
        RemoteExecutionClient.validate_execution_name("a-valid-name-with-26-chars")

        invalid_names = ["-startswithspecialchar", "_startswithspecialchar", "b" * 27, ""]
        for name in invalid_names:
            with self.assertRaises(ValidationError) as ve:
                RemoteExecutionClient.validate_execution_name(name)
            self.assertEqual(
                str(ve.exception),
                f"Execution name {name} does not match required pattern '^[a-zA-Z0-9]([-a-zA-Z0-9]){0, 25}$'",
            )

    def test_validate_input_config(self):
        with self.assertRaises(ValidationError) as ve:
            RemoteExecutionClient.validate_input_config({})
        self.assertEqual(str(ve.exception), "InputConfig is required for remote execution")

        with self.assertRaises(ValidationError) as ve:
            RemoteExecutionClient.validate_input_config({"notebook_config": {}})
        self.assertEqual(
            str(ve.exception),
            "'inputPath' in InputConfig notebookConfig is required for remote execution",
        )

        # valid input confg must have input_path in notebook_config
        RemoteExecutionClient.validate_input_config(
            {"notebook_config": {"input_path": "s3://bucket/key"}}
        )
        # input config can also have input_parameters
        RemoteExecutionClient.validate_input_config(
            {
                "notebook_config": {
                    "input_path": "s3://bucket/key",
                    "input_parameters": {str(i): str(i) for i in range(100)},
                }
            }
        )
        with self.assertRaises(ValidationError) as ve:
            RemoteExecutionClient.validate_input_config(
                {
                    "notebook_config": {
                        "input_path": "s3://bucket/key",
                        "input_parameters": {str(i): str(i) for i in range(101)},
                    }
                }
            )
        self.assertEqual(
            str(ve.exception),
            "inputParameters in InputConfig notebookConfig cannot have more than 100 entries",
        )
        RemoteExecutionClient.validate_input_config(
            {
                "notebook_config": {
                    "input_path": "s3://bucket/key",
                    "input_parameters": {"n" * 256: "n"},
                }
            }
        )
        with self.assertRaises(ValidationError) as ve:
            RemoteExecutionClient.validate_input_config(
                {
                    "notebook_config": {
                        "input_path": "s3://bucket/key",
                        "input_parameters": {"n" * 257: "n"},
                    }
                }
            )
        self.assertEqual(
            str(ve.exception), "The input parameters key length cannot exceed 256 characters."
        )
        RemoteExecutionClient.validate_input_config(
            {
                "notebook_config": {
                    "input_path": "s3://bucket/key",
                    "input_parameters": {"n": "n" * 2500},
                }
            }
        )
        with self.assertRaises(ValidationError) as ve:
            RemoteExecutionClient.validate_input_config(
                {
                    "notebook_config": {
                        "input_path": "s3://bucket/key",
                        "input_parameters": {"n": "n" * 2501},
                    }
                }
            )
        self.assertEqual(
            str(ve.exception), "The input parameters value length cannot exceed 2500 characters."
        )

    def test_validate_image_version(self):
        # Test valid versions
        self.assertTrue(RemoteExecutionClient.validate_image_version("2.6"))
        self.assertTrue(RemoteExecutionClient.validate_image_version("2.6.1"))
        self.assertTrue(RemoteExecutionClient.validate_image_version("2.7"))
        self.assertTrue(RemoteExecutionClient.validate_image_version("2.8"))
        self.assertTrue(RemoteExecutionClient.validate_image_version("2.8.1"))
        self.assertTrue(RemoteExecutionClient.validate_image_version("2.9.1"))
        self.assertTrue(RemoteExecutionClient.validate_image_version("2.10"))
        self.assertTrue(RemoteExecutionClient.validate_image_version("2.11.0"))
        self.assertTrue(RemoteExecutionClient.validate_image_version("2"))
        self.assertTrue(RemoteExecutionClient.validate_image_version("3.0.0"))
        self.assertTrue(RemoteExecutionClient.validate_image_version("3.0"))
        self.assertTrue(RemoteExecutionClient.validate_image_version("3"))

        self.assertFalse(RemoteExecutionClient.validate_image_version("2.2.0"))
        self.assertFalse(RemoteExecutionClient.validate_image_version("2.2"))
        self.assertFalse(RemoteExecutionClient.validate_image_version("1.0"))
        self.assertFalse(RemoteExecutionClient.validate_image_version("2.0.1"))
        self.assertFalse(RemoteExecutionClient.validate_image_version("2.1"))
        self.assertFalse(RemoteExecutionClient.validate_image_version("4.0"))

        self.assertTrue(RemoteExecutionClient.validate_image_version("latest"))

    # Test list_executions
    def test_list_executions(self):
        mock_sagemaker_client = Mock()
        self.remote_client.sagemaker_client = mock_sagemaker_client
        self.remote_client.ec2_client = self.remote_client.ssm_client = Mock()
        self.remote_client.security_group = self.remote_client.subnets = (
            self.remote_client.user_role_arn
        ) = self.remote_client.kms_key_identifier = Mock()

        mock_sagemaker_client.search.return_value = {
            "Results": [
                {
                    "TrainingJob": {
                        "TrainingJobName": "job-1",
                        "TrainingJobStatus": "Completed",
                        "TrainingStartTime": datetime(2024, 8, 8, 10, 0, 0, tzinfo=timezone.utc),
                        "TrainingEndTime": datetime(2024, 8, 8, 11, 0, 0, tzinfo=timezone.utc),
                        "Tags": [
                            {"Key": "sagemaker-notebook-execution", "Value": "TRUE"},
                            {"Key": "sagemaker-notebook-name", "Value": "test.ipynb"},
                            {"Key": "AmazonDataZoneDomain", "Value": "domain_123"},
                            {"Key": "AmazonDataZoneProject", "Value": "project_123"},
                            {"Key": "AmazonDataZoneEnvironment", "Value": "environment_123"},
                        ],
                    }
                },
                {
                    "TrainingJob": {
                        "TrainingJobName": "job-2",
                        "TrainingJobStatus": "Completed",
                        "TrainingStartTime": datetime(2024, 8, 9, 10, 0, 0, tzinfo=timezone.utc),
                        "TrainingEndTime": datetime(2024, 8, 9, 11, 0, 0, tzinfo=timezone.utc),
                        "Tags": [
                            {"Key": "sagemaker-notebook-execution", "Value": "TRUE"},
                            {"Key": "sagemaker-notebook-name", "Value": "test.ipynb"},
                            {"Key": "AmazonDataZoneDomain", "Value": "domain_123"},
                            {"Key": "AmazonDataZoneProject", "Value": "project_123"},
                        ],
                    }
                },
            ],
            "NextToken": "token",
        }

        # test list_executions
        response = self.remote_client.list_executions()
        executions = response.get("executions")
        self.assertEqual(len(executions), 2)  # type: ignore
        self.assertEqual(executions[0].get("id"), "job-1")  # type: ignore
        self.assertEqual(executions[0].get("name"), "job-1")  # type: ignore
        self.assertEqual(executions[0].get("status"), "COMPLETED")  # type: ignore
        self.assertEqual(executions[0].get("start_time"), 1723111200000)  # type: ignore
        self.assertEqual(executions[0].get("end_time"), 1723114800000)  # type: ignore

        # Verify that search was called with the correct parameters
        mock_sagemaker_client.search.assert_called_once()

    def test_stop_execution_failed_status(self):
        # Arrange
        mock_sagemaker_client = Mock()
        self.remote_client.sagemaker_client = mock_sagemaker_client
        self.remote_client.security_group = self.remote_client.subnets = (
            self.remote_client.user_role_arn
        ) = self.remote_client.kms_key_identifier = Mock()
        self.remote_client.ec2_client = self.remote_client.ssm_client = Mock()
        client_error = ClientError(
            error_response={
                "Error": {
                    "Code": "ValidationException",
                    "Message": "The request was rejected because the training job is in status Failed",
                },
                "ResponseMetadata": {
                    "RequestId": "1234567890ABCDEF",
                    "HostId": "host-id-1-A2Z",
                    "HTTPStatusCode": 400,
                    "HTTPHeaders": {
                        "x-amzn-requestid": "1234567890ABCDEF",
                        "content-type": "application/x-amz-json-1.1",
                        "content-length": "123",
                        "date": "Wed, 01 Jan 2023 12:00:00 GMT",
                    },
                    "RetryAttempts": 0,
                },
            },
            operation_name="StopTrainingJob",
        )
        mock_sagemaker_client.stop_training_job.side_effect = client_error

        # Act and Assert
        with self.assertRaises(ConflictError) as context:
            self.remote_client.stop_execution(execution_id="test_job_id")

        self.assertEqual(
            str(context.exception),
            "Execution with id test_job_id is in Failed status and cannot be Stopped",
        )

        mock_sagemaker_client.stop_training_job.assert_called_once_with(
            TrainingJobName="test_job_id"
        )

    @patch("uuid.uuid4")
    def test_start_execution_happy_path(self, mock_uuid):
        # Arrange
        mock_uuid.return_value = "1234-5678-9012-3456"

        mock_sagemaker_client = Mock()
        mock_sagemaker_client.create_training_job.return_value = {
            "TrainingJobArn": "arn:aws:sagemaker:us-west-2:123456123456:training-job/test-job-1234-5678-9012-3456"
        }

        self.remote_client.sagemaker_client = mock_sagemaker_client
        self.remote_client.kms_key_identifier = (
            "arn:aws:kms:us-west-2:123456123456:key/1234abcd-12ab-34cd-56ef-1234567890ab"
        )
        self.remote_client.user_role_arn = "arn:aws:iam::123456123456:role/SageMakerRole"
        self.remote_client.default_tooling_environment = {
            "awsAccountId": "123456123456",
            "awsAccountRegion": "us-west-2",
            "id": "env-12345",
            "name": "Default Environment",
            "provisionedResources": [
                {"name": "VpcId", "value": "vpc-12345678"},
                {"name": "SubnetIds", "value": "subnet-12345678,subnet-87654321"},
                {"name": "SecurityGroupId", "value": "sg-12345678"},
                {"name": "s3BucketPath", "value": "s3://my-bucket/my-project/"},
                {"name": "codeRepositoryName", "value": "my-code-repository"},
            ],
        }
        self.remote_client._utils = Mock()
        self.remote_client._utils._get_project_s3_path.return_value = "s3://my-bucket/my-project/"

        self.remote_client.domain_identifier = "domain-123"
        self.remote_client.project_identifier = "project-456"
        self.remote_client.datazone_endpoint = "https://bogus_endpoint.example.com/"
        self.remote_client.datazone_domain_region = "us-west-2"
        self.remote_client.project_s3_path = "s3://my-bucket/my-project/"
        self.remote_client.security_group = "sg-12345678"
        self.remote_client.subnets = ["subnet-12345678"]

        ecr_uri = (
            "123456123456.dkr.ecr.us-west-2.amazonaws.com/sagemaker-distribution-prod:3.0.0-cpu"
        )
        input = {"path": "s3://my-bucket/my-project/workflows/project-files", "file": "test.ipynb"}
        output = {"path": "s3://my-bucket/my-project/workflows/output", "file": "_test.ipynb"}

        mock_ec2_client = Mock()
        mock_ec2_client.describe_instance_types.return_value = {
            "InstanceTypes": [
                {
                    "InstanceType": "t2.micro",
                    "VCpuInfo": {"DefaultVCpus": 1},
                    "MemoryInfo": {"SizeInMiB": 1024},
                    # ... other details
                },
            ]
        }
        self.remote_client.ec2_client = mock_ec2_client

        mock_ssm_client = Mock()
        mock_ssm_client.get_parameter.return_value = {"Parameter": {"Value": "123456123456"}}
        self.remote_client.ssm_client = mock_ssm_client

        # Act
        result = self.remote_client.start_execution(
            execution_name="test-job",
            compute={
                "instance_type": "ml.m5.large",
                "volume_size_in_gb": 50,
                "image_details": {
                    "image_name": "sagemaker-distribution-prod",
                    "image_version": "3.0.0",
                },
            },
            input_config={"notebook_config": {"input_path": "src/test.ipynb"}},
            termination_condition={"max_runtime_in_seconds": 3600},
            output_config={"notebook_config": {"input_path": "src/test.ipynb"}},
            tags={"a": "b"},
        )

        # Assert
        mock_sagemaker_client.create_training_job.assert_called_once()
        call_args = mock_sagemaker_client.create_training_job.call_args[1]

        self.assertEqual(call_args["TrainingJobName"], "test-job-1234-5678-9012-3456")
        self.assertEqual(call_args["AlgorithmSpecification"]["TrainingImage"], ecr_uri)
        self.assertEqual(call_args["RoleArn"], self.remote_client.user_role_arn)
        self.assertEqual(call_args["OutputDataConfig"]["S3OutputPath"], output["path"])
        self.assertEqual(
            call_args["OutputDataConfig"]["KmsKeyId"], self.remote_client.kms_key_identifier
        )
        self.assertEqual(call_args["ResourceConfig"]["InstanceType"], "ml.m5.large")
        self.assertEqual(call_args["ResourceConfig"]["VolumeSizeInGB"], 50)
        self.assertEqual(
            call_args["ResourceConfig"]["VolumeKmsKeyId"], self.remote_client.kms_key_identifier
        )
        self.assertEqual(
            call_args["InputDataConfig"][0]["DataSource"]["S3DataSource"]["S3Uri"], input["path"]
        )
        self.assertEqual(call_args["HyperParameters"], {})
        self.assertEqual(call_args["StoppingCondition"]["MaxRuntimeInSeconds"], 3600)
        self.assertEqual(call_args["Environment"]["SM_INPUT_NOTEBOOK_NAME"], input["file"])
        self.assertEqual(call_args["Environment"]["SM_OUTPUT_NOTEBOOK_NAME"], output["file"])
        self.assertEqual(
            call_args["VpcConfig"]["SecurityGroupIds"], [self.remote_client.security_group]
        )
        self.assertEqual(call_args["VpcConfig"]["Subnets"], self.remote_client.subnets)

        self.assertEqual(result["execution_id"], "test-job-1234-5678-9012-3456")

    @patch("uuid.uuid4")
    def test_start_execution_no_compute_uses_fallback_when_m6i_unavailable(self, mock_uuid):
        """Test that start_execution uses fallback logic when no compute is provided and m6i is unavailable"""
        # Arrange
        mock_uuid.return_value = "1234-5678-9012-3456"

        mock_sagemaker_client = Mock()
        mock_sagemaker_client.create_training_job.return_value = {
            "TrainingJobArn": "arn:aws:sagemaker:us-west-2:123456123456:training-job/test-job-1234-5678-9012-3456"
        }
        self.remote_client.sagemaker_client = mock_sagemaker_client
        self.remote_client.kms_key_identifier = (
            "arn:aws:kms:us-west-2:123456123456:key/1234abcd-12ab-34cd-56ef-1234567890ab"
        )
        self.remote_client.user_role_arn = "arn:aws:iam::123456123456:role/SageMakerRole"
        self.remote_client.default_tooling_environment = {
            "awsAccountId": "123456123456",
            "awsAccountRegion": "us-west-2",
            "id": "env-12345",
            "name": "Default Environment",
            "provisionedResources": [
                {"name": "VpcId", "value": "vpc-12345678"},
                {"name": "SubnetIds", "value": "subnet-12345678,subnet-87654321"},
                {"name": "SecurityGroupId", "value": "sg-12345678"},
                {"name": "s3BucketPath", "value": "s3://my-bucket/my-project/"},
                {"name": "codeRepositoryName", "value": "my-code-repository"},
            ],
        }
        self.remote_client._utils = Mock()
        self.remote_client._utils._get_project_s3_path.return_value = "s3://my-bucket/my-project/"
        self.remote_client.domain_identifier = "domain-123"
        self.remote_client.project_identifier = "project-456"
        self.remote_client.datazone_endpoint = "https://bogus_endpoint.example.com/"
        self.remote_client.datazone_domain_region = "us-west-2"
        self.remote_client.project_s3_path = "s3://my-bucket/my-project/"
        self.remote_client.security_group = "sg-12345678"
        self.remote_client.subnets = ["subnet-12345678"]

        # Mock EC2 client to simulate m6i not available, but m5 available
        mock_ec2_client = Mock()
        # First call (preferred) returns empty, second call (fallback) returns available
        mock_ec2_client.describe_instance_types.side_effect = [
            {"InstanceTypes": []},  # m6i.xlarge not available
            {
                "InstanceTypes": [
                    {
                        "InstanceType": "m5.xlarge",
                        "VCpuInfo": {"DefaultVCpus": 4},
                        "MemoryInfo": {"SizeInMiB": 16384},
                    }
                ]
            },  # m5.xlarge available
        ]
        self.remote_client.ec2_client = mock_ec2_client

        mock_ssm_client = Mock()
        mock_ssm_client.get_parameter.return_value = {"Parameter": {"Value": "123456123456"}}
        self.remote_client.ssm_client = mock_ssm_client

        # Act - No compute provided, should trigger fallback logic
        result = self.remote_client.start_execution(
            execution_name="test-job",
            input_config={"notebook_config": {"input_path": "src/test.ipynb"}},
        )

        # Assert
        mock_sagemaker_client.create_training_job.assert_called_once()
        call_args = mock_sagemaker_client.create_training_job.call_args[1]

        # Verify that the fallback instance type was used
        self.assertEqual(call_args["ResourceConfig"]["InstanceType"], FALLBACK_INSTANCE_TYPE)

        # Verify that the fallback logic was called twice (once for preferred, once for fallback)
        self.assertEqual(mock_ec2_client.describe_instance_types.call_count, 2)

        self.assertEqual(result["execution_id"], "test-job-1234-5678-9012-3456")

    @patch("uuid.uuid4")
    def test_start_execution_with_compute_skips_fallback_logic(self, mock_uuid):
        """Test that start_execution does not use fallback logic when compute is explicitly provided"""
        # Arrange
        mock_uuid.return_value = "1234-5678-9012-3456"

        mock_sagemaker_client = Mock()
        mock_sagemaker_client.create_training_job.return_value = {
            "TrainingJobArn": "arn:aws:sagemaker:us-west-2:123456123456:training-job/test-job-1234-5678-9012-3456"
        }
        self.remote_client.sagemaker_client = mock_sagemaker_client
        self.remote_client.kms_key_identifier = (
            "arn:aws:kms:us-west-2:123456123456:key/1234abcd-12ab-34cd-56ef-1234567890ab"
        )
        self.remote_client.user_role_arn = "arn:aws:iam::123456123456:role/SageMakerRole"
        self.remote_client.default_tooling_environment = {
            "awsAccountId": "123456123456",
            "awsAccountRegion": "us-west-2",
            "id": "env-12345",
            "name": "Default Environment",
            "provisionedResources": [
                {"name": "VpcId", "value": "vpc-12345678"},
                {"name": "SubnetIds", "value": "subnet-12345678,subnet-87654321"},
                {"name": "SecurityGroupId", "value": "sg-12345678"},
                {"name": "s3BucketPath", "value": "s3://my-bucket/my-project/"},
                {"name": "codeRepositoryName", "value": "my-code-repository"},
            ],
        }
        self.remote_client._utils = Mock()
        self.remote_client._utils._get_project_s3_path.return_value = "s3://my-bucket/my-project/"
        self.remote_client.domain_identifier = "domain-123"
        self.remote_client.project_identifier = "project-456"
        self.remote_client.datazone_endpoint = "https://bogus_endpoint.example.com/"
        self.remote_client.datazone_domain_region = "us-west-2"
        self.remote_client.project_s3_path = "s3://my-bucket/my-project/"
        self.remote_client.security_group = "sg-12345678"
        self.remote_client.subnets = ["subnet-12345678"]

        # Mock EC2 client - this should NOT be called for instance type offerings
        mock_ec2_client = Mock()
        mock_ec2_client.describe_instance_types.return_value = {
            "InstanceTypes": [
                {
                    "InstanceType": "g4dn.xlarge",
                    "VCpuInfo": {"DefaultVCpus": 4},
                    "MemoryInfo": {"SizeInMiB": 16384},
                    "GpuInfo": {"Gpus": [{"Name": "T4", "Manufacturer": "NVIDIA", "Count": 1}]},
                },
            ]
        }
        self.remote_client.ec2_client = mock_ec2_client

        mock_ssm_client = Mock()
        mock_ssm_client.get_parameter.return_value = {"Parameter": {"Value": "123456123456"}}
        self.remote_client.ssm_client = mock_ssm_client

        # Act - Compute explicitly provided, should NOT trigger fallback logic
        result = self.remote_client.start_execution(
            execution_name="test-job",
            compute={"instance_type": "ml.g4dn.xlarge"},  # Explicitly provided
            input_config={"notebook_config": {"input_path": "src/test.ipynb"}},
        )

        # Assert
        mock_sagemaker_client.create_training_job.assert_called_once()
        call_args = mock_sagemaker_client.create_training_job.call_args[1]

        # Verify that the explicitly provided instance type was used
        self.assertEqual(call_args["ResourceConfig"]["InstanceType"], "ml.g4dn.xlarge")
        self.assertEqual(result["execution_id"], "test-job-1234-5678-9012-3456")

        # Verify that the fallback logic was NOT called (describe_instance_type_offerings should not be called)
        mock_ec2_client.describe_instance_type_offerings.assert_not_called()
        # But describe_instance_types should be called for GPU detection
        mock_ec2_client.describe_instance_types.assert_called_once()

    def test_get_available_instance_type_preferred_available(self):
        """Test that preferred instance type is returned when available"""
        # Arrange
        mock_ec2_client = Mock()
        mock_ec2_client.describe_instance_types.return_value = {
            "InstanceTypes": [
                {
                    "InstanceType": "m6i.xlarge",
                    "VCpuInfo": {"DefaultVCpus": 4},
                    "MemoryInfo": {"SizeInMiB": 16384},
                },
            ]
        }
        self.remote_client.ec2_client = mock_ec2_client

        # Act
        result = self.remote_client._RemoteExecutionClient__get_available_instance_type_with_info(
            "ml.m6i.xlarge"
        )

        # Assert
        self.assertEqual(result["instance_type"], "ml.m6i.xlarge")
        self.assertEqual(result["has_gpu"], False)
        mock_ec2_client.describe_instance_types.assert_called_once_with(
            InstanceTypes=["m6i.xlarge"]
        )

    def test_get_available_instance_type_fallback_to_m5(self):
        """Test that fallback instance type is returned when preferred is not available"""
        # Arrange
        mock_ec2_client = Mock()
        # First call (preferred) returns empty, second call (fallback) returns available
        mock_ec2_client.describe_instance_types.side_effect = [
            {"InstanceTypes": []},  # m6i.xlarge not available
            {
                "InstanceTypes": [
                    {
                        "InstanceType": "m5.xlarge",
                        "VCpuInfo": {"DefaultVCpus": 4},
                        "MemoryInfo": {"SizeInMiB": 16384},
                    }
                ]
            },  # m5.xlarge available
        ]
        self.remote_client.ec2_client = mock_ec2_client

        # Act
        result = self.remote_client._RemoteExecutionClient__get_available_instance_type_with_info(
            "ml.m6i.xlarge"
        )

        # Assert
        self.assertEqual(result["instance_type"], FALLBACK_INSTANCE_TYPE)
        self.assertEqual(result["has_gpu"], False)
        self.assertEqual(mock_ec2_client.describe_instance_types.call_count, 2)

        # Verify first call for preferred instance type
        first_call = mock_ec2_client.describe_instance_types.call_args_list[0]
        self.assertEqual(first_call[1]["InstanceTypes"], ["m6i.xlarge"])

        # Verify second call for fallback instance type
        second_call = mock_ec2_client.describe_instance_types.call_args_list[1]
        self.assertEqual(second_call[1]["InstanceTypes"], ["m5.xlarge"])

    def test_get_available_instance_type_both_unavailable(self):
        """Test that ValidationError is raised when both preferred and fallback are unavailable"""
        # Arrange
        mock_ec2_client = Mock()
        # Both calls return empty (neither available)
        mock_ec2_client.describe_instance_types.return_value = {"InstanceTypes": []}
        self.remote_client.ec2_client = mock_ec2_client

        # Act & Assert
        with self.assertRaises(ValidationError) as context:
            self.remote_client._RemoteExecutionClient__get_available_instance_type_with_info(
                "ml.m6i.xlarge"
            )

        self.assertIn("Neither the preferred instance type", str(context.exception))
        self.assertEqual(mock_ec2_client.describe_instance_types.call_count, 2)

    def test_get_available_instance_type_ec2_client_error(self):
        """Test that ValidationError is raised when EC2 client throws an error"""
        # Arrange
        mock_ec2_client = Mock()
        mock_ec2_client.describe_instance_types.side_effect = ClientError(
            error_response={
                "Error": {
                    "Code": "UnauthorizedOperation",
                    "Message": "You are not authorized to perform this operation.",
                }
            },
            operation_name="DescribeInstanceTypes",
        )
        self.remote_client.ec2_client = mock_ec2_client

        # Act & Assert
        with self.assertRaises(ValidationError) as context:
            self.remote_client._RemoteExecutionClient__get_available_instance_type_with_info(
                "ml.m6i.xlarge"
            )

        self.assertIn("Neither the preferred instance type", str(context.exception))

    def test_get_available_instance_type_handles_ml_prefix(self):
        """Test that method correctly handles ml. prefix in instance type"""
        # Arrange
        mock_ec2_client = Mock()
        mock_ec2_client.describe_instance_types.return_value = {
            "InstanceTypes": [
                {
                    "InstanceType": "m6i.xlarge",
                    "VCpuInfo": {"DefaultVCpus": 4},
                    "MemoryInfo": {"SizeInMiB": 16384},
                }
            ]
        }
        self.remote_client.ec2_client = mock_ec2_client

        # Act
        result = self.remote_client._RemoteExecutionClient__get_available_instance_type_with_info(
            "ml.m6i.xlarge"
        )

        # Assert
        self.assertEqual(result["instance_type"], "ml.m6i.xlarge")
        self.assertEqual(result["has_gpu"], False)
        # Verify that the EC2 API was called with the instance type without ml. prefix
        mock_ec2_client.describe_instance_types.assert_called_once_with(
            InstanceTypes=["m6i.xlarge"]  # ml. prefix removed
        )

    def test_validate_domain_id(self):
        """Test domain ID validation."""
        # Valid cases
        valid_ids = ["dzd-123456", "dzd_test123", "dzd-abc_def-123"]
        for domain_id in valid_ids:
            RemoteExecutionClient.validate_domain_id(domain_id)  # Should not raise

        # Invalid cases - only test cases that will actually raise ValidationError
        invalid_cases = [
            ("", "Domain ID cannot be empty"),
            ("domain-123", "Invalid domain ID format"),  # Missing dzd prefix
            ("dzd-", "Invalid domain ID format"),  # Too short
            ("dzd-" + "a" * 37, "Invalid domain ID format"),  # Too long
        ]

        for domain_id, expected_msg in invalid_cases:
            with self.assertRaises(ValidationError) as context:
                RemoteExecutionClient.validate_domain_id(domain_id)
            self.assertIn(expected_msg, str(context.exception))

    def test_validate_project_id(self):
        """Test project ID validation."""
        # Valid cases
        valid_ids = ["a", "project123", "test-project_123", "a" * 36]
        for project_id in valid_ids:
            RemoteExecutionClient.validate_project_id(project_id)  # Should not raise

        # Invalid cases - only test cases that will actually raise ValidationError
        invalid_cases = [
            ("", "Project ID cannot be empty"),
            ("a" * 37, "Invalid project ID"),  # Too long
            ("project with spaces", "Invalid project ID"),  # Spaces
            ("project@special", "Invalid project ID"),  # Special chars
        ]

        for project_id, expected_msg in invalid_cases:
            with self.assertRaises(ValidationError) as context:
                RemoteExecutionClient.validate_project_id(project_id)
            self.assertIn(expected_msg, str(context.exception))

    def test_validate_domain_region(self):
        """Test domain region validation."""
        # Valid cases
        valid_regions = ["us-east-1", "eu-west-2", "ap-southeast-1", "us-gov-east-1", "cn-north-1"]
        for region in valid_regions:
            RemoteExecutionClient.validate_domain_region(region)  # Should not raise

        # Invalid cases - only test cases that will actually raise ValidationError
        invalid_cases = [
            ("", "Domain region cannot be empty"),
            ("invalid-region", "Invalid AWS region format"),
            ("us-east", "Invalid AWS region format"),  # Missing number
            ("xyz-west-1", "Invalid AWS region format"),  # Invalid prefix
        ]

        for region, expected_msg in invalid_cases:
            with self.assertRaises(ValidationError) as context:
                RemoteExecutionClient.validate_domain_region(region)
            self.assertIn(expected_msg, str(context.exception))

    @patch("uuid.uuid4")
    def test_start_execution_with_latest_image_version_cpu(self, mock_uuid):
        """Test that 'latest' image version correctly constructs ECR URI with CPU variant"""
        # Arrange
        mock_uuid.return_value = "1234-5678-9012-3456"

        mock_sagemaker_client = Mock()
        mock_sagemaker_client.create_training_job.return_value = {
            "TrainingJobArn": "arn:aws:sagemaker:us-west-2:123456123456:training-job/test-job-1234-5678-9012-3456"
        }
        self.remote_client.sagemaker_client = mock_sagemaker_client
        self.remote_client.kms_key_identifier = (
            "arn:aws:kms:us-west-2:123456123456:key/1234abcd-12ab-34cd-56ef-1234567890ab"
        )
        self.remote_client.user_role_arn = "arn:aws:iam::123456123456:role/SageMakerRole"
        self.remote_client.default_tooling_environment = {
            "awsAccountId": "123456123456",
            "awsAccountRegion": "us-west-2",
            "id": "env-12345",
            "name": "Default Environment",
            "provisionedResources": [
                {"name": "VpcId", "value": "vpc-12345678"},
                {"name": "SubnetIds", "value": "subnet-12345678,subnet-87654321"},
                {"name": "SecurityGroupId", "value": "sg-12345678"},
                {"name": "s3BucketPath", "value": "s3://my-bucket/my-project/"},
                {"name": "codeRepositoryName", "value": "my-code-repository"},
            ],
        }
        self.remote_client._utils = Mock()
        self.remote_client._utils._get_project_s3_path.return_value = "s3://my-bucket/my-project/"
        self.remote_client.domain_identifier = "domain-123"
        self.remote_client.project_identifier = "project-456"
        self.remote_client.datazone_endpoint = "https://bogus_endpoint.example.com/"
        self.remote_client.datazone_domain_region = "us-west-2"
        self.remote_client.project_s3_path = "s3://my-bucket/my-project/"
        self.remote_client.security_group = "sg-12345678"
        self.remote_client.subnets = ["subnet-12345678"]

        # Mock EC2 client to return CPU instance (no GPU info)
        mock_ec2_client = Mock()
        mock_ec2_client.describe_instance_types.return_value = {
            "InstanceTypes": [
                {
                    "InstanceType": "m5.large",
                    "VCpuInfo": {"DefaultVCpus": 2},
                    "MemoryInfo": {"SizeInMiB": 8192},
                    # No GpuInfo - this is a CPU instance
                },
            ]
        }
        self.remote_client.ec2_client = mock_ec2_client

        mock_ssm_client = Mock()
        mock_ssm_client.get_parameter.return_value = {"Parameter": {"Value": "123456123456"}}
        self.remote_client.ssm_client = mock_ssm_client

        # Act
        result = self.remote_client.start_execution(
            execution_name="test-job",
            compute={
                "instance_type": "ml.m5.large",
                "image_details": {
                    "image_name": "sagemaker-distribution-prod",
                    "image_version": "latest",
                },
            },
            input_config={"notebook_config": {"input_path": "src/test.ipynb"}},
        )

        # Assert
        mock_sagemaker_client.create_training_job.assert_called_once()
        call_args = mock_sagemaker_client.create_training_job.call_args[1]

        # Verify that the ECR URI uses latest-cpu
        expected_ecr_uri = (
            "123456123456.dkr.ecr.us-west-2.amazonaws.com/sagemaker-distribution-prod:latest-cpu"
        )
        self.assertEqual(call_args["AlgorithmSpecification"]["TrainingImage"], expected_ecr_uri)
        self.assertEqual(result["execution_id"], "test-job-1234-5678-9012-3456")

    @patch("uuid.uuid4")
    def test_start_execution_uses_latest_by_default(self, mock_uuid):
        """Test that when no image version is specified, it defaults to 'latest'"""
        # Arrange
        mock_uuid.return_value = "1234-5678-9012-3456"

        mock_sagemaker_client = Mock()
        mock_sagemaker_client.create_training_job.return_value = {
            "TrainingJobArn": "arn:aws:sagemaker:us-west-2:123456123456:training-job/test-job-1234-5678-9012-3456"
        }
        self.remote_client.sagemaker_client = mock_sagemaker_client
        self.remote_client.kms_key_identifier = (
            "arn:aws:kms:us-west-2:123456123456:key/1234abcd-12ab-34cd-56ef-1234567890ab"
        )
        self.remote_client.user_role_arn = "arn:aws:iam::123456123456:role/SageMakerRole"
        self.remote_client.default_tooling_environment = {
            "awsAccountId": "123456123456",
            "awsAccountRegion": "us-west-2",
            "id": "env-12345",
            "name": "Default Environment",
            "provisionedResources": [
                {"name": "VpcId", "value": "vpc-12345678"},
                {"name": "SubnetIds", "value": "subnet-12345678,subnet-87654321"},
                {"name": "SecurityGroupId", "value": "sg-12345678"},
                {"name": "s3BucketPath", "value": "s3://my-bucket/my-project/"},
                {"name": "codeRepositoryName", "value": "my-code-repository"},
            ],
        }
        self.remote_client._utils = Mock()
        self.remote_client._utils._get_project_s3_path.return_value = "s3://my-bucket/my-project/"
        self.remote_client.domain_identifier = "domain-123"
        self.remote_client.project_identifier = "project-456"
        self.remote_client.datazone_endpoint = "https://bogus_endpoint.example.com/"
        self.remote_client.datazone_domain_region = "us-west-2"
        self.remote_client.project_s3_path = "s3://my-bucket/my-project/"
        self.remote_client.security_group = "sg-12345678"
        self.remote_client.subnets = ["subnet-12345678"]

        # Mock EC2 client to return CPU instance
        mock_ec2_client = Mock()
        mock_ec2_client.describe_instance_types.return_value = {
            "InstanceTypes": [
                {
                    "InstanceType": "m5.large",
                    "VCpuInfo": {"DefaultVCpus": 2},
                    "MemoryInfo": {"SizeInMiB": 8192},
                    # No GpuInfo - this is a CPU instance
                },
            ]
        }
        self.remote_client.ec2_client = mock_ec2_client

        mock_ssm_client = Mock()
        mock_ssm_client.get_parameter.return_value = {"Parameter": {"Value": "123456123456"}}
        self.remote_client.ssm_client = mock_ssm_client

        # Act - No image_details provided, should use defaults
        result = self.remote_client.start_execution(
            execution_name="test-job",
            compute={"instance_type": "ml.m5.large"},
            input_config={"notebook_config": {"input_path": "src/test.ipynb"}},
        )

        # Assert
        mock_sagemaker_client.create_training_job.assert_called_once()
        call_args = mock_sagemaker_client.create_training_job.call_args[1]

        # Verify that the ECR URI uses latest-cpu by default
        expected_ecr_uri = (
            "123456123456.dkr.ecr.us-west-2.amazonaws.com/sagemaker-distribution-prod:latest-cpu"
        )
        self.assertEqual(call_args["AlgorithmSpecification"]["TrainingImage"], expected_ecr_uri)
        self.assertEqual(result["execution_id"], "test-job-1234-5678-9012-3456")

    @patch("uuid.uuid4")
    def test_start_execution_with_minimum_input_fields_provided(self, mock_uuid):
        # Arrange
        mock_uuid.return_value = "1234-5678-9012-3456"

        mock_sagemaker_client = Mock()
        mock_sagemaker_client.create_training_job.return_value = {
            "TrainingJobArn": "arn:aws:sagemaker:us-west-2:123456123456:training-job/test-job-1234-5678-9012-3456"
        }
        self.remote_client.sagemaker_client = mock_sagemaker_client
        self.remote_client.kms_key_identifier = (
            "arn:aws:kms:us-west-2:123456123456:key/1234abcd-12ab-34cd-56ef-1234567890ab"
        )
        self.remote_client.user_role_arn = "arn:aws:iam::123456123456:role/SageMakerRole"
        self.remote_client.default_tooling_environment = {
            "awsAccountId": "123456123456",
            "awsAccountRegion": "us-west-2",
            "id": "env-12345",
            "name": "Default Environment",
            "provisionedResources": [
                {"name": "VpcId", "value": "vpc-12345678"},
                {"name": "SubnetIds", "value": "subnet-12345678,subnet-87654321"},
                {"name": "SecurityGroupId", "value": "sg-12345678"},
                {"name": "s3BucketPath", "value": "s3://my-bucket/my-project/"},
                {"name": "codeRepositoryName", "value": "my-code-repository"},
            ],
        }
        self.remote_client._utils = Mock()
        self.remote_client._utils._get_project_s3_path.return_value = "s3://my-bucket/my-project/"
        self.remote_client.domain_identifier = "domain-123"
        self.remote_client.project_identifier = "project-456"
        self.remote_client.datazone_endpoint = "https://bogus_endpoint.example.com/"
        self.remote_client.datazone_domain_region = "us-west-2"
        self.remote_client.project_s3_path = "s3://my-bucket/my-project/"
        self.remote_client.security_group = "sg-12345678"
        self.remote_client.subnets = ["subnet-12345678"]

        input = {"path": "s3://my-bucket/my-project/workflows/project-files", "file": "test.ipynb"}
        output = {"path": "s3://my-bucket/my-project/workflows/output", "file": "_test.ipynb"}

        mock_ec2_client = Mock()
        # Mock the fallback logic - m6i.xlarge is available
        mock_ec2_client.describe_instance_types.return_value = {
            "InstanceTypes": [
                {
                    "InstanceType": "m6i.xlarge",
                    "VCpuInfo": {"DefaultVCpus": 4},
                    "MemoryInfo": {"SizeInMiB": 16384},
                },
            ]
        }
        self.remote_client.ec2_client = mock_ec2_client

        mock_ssm_client = Mock()
        mock_ssm_client.get_parameter.return_value = {"Parameter": {"Value": "123456123456"}}
        self.remote_client.ssm_client = mock_ssm_client

        # Act
        result = self.remote_client.start_execution(
            execution_name="test-job",
            input_config={"notebook_config": {"input_path": "src/test.ipynb"}},
        )

        # Assert
        mock_sagemaker_client.create_training_job.assert_called_once()
        call_args = mock_sagemaker_client.create_training_job.call_args[1]

        self.assertEqual(call_args["TrainingJobName"], "test-job-1234-5678-9012-3456")
        default_ecr_uri = f"123456123456.dkr.ecr.us-west-2.amazonaws.com/sagemaker-distribution-prod:{DEFAULT_IMAGE_VERSION}-cpu"
        self.assertEqual(call_args["AlgorithmSpecification"]["TrainingImage"], default_ecr_uri)
        self.assertEqual(call_args["RoleArn"], self.remote_client.user_role_arn)
        self.assertEqual(call_args["OutputDataConfig"]["S3OutputPath"], output["path"])
        self.assertEqual(
            call_args["OutputDataConfig"]["KmsKeyId"], self.remote_client.kms_key_identifier
        )
        self.assertEqual(call_args["ResourceConfig"]["InstanceType"], DEFAULT_INSTANCE_TYPE)
        self.assertEqual(call_args["ResourceConfig"]["VolumeSizeInGB"], 30)
        self.assertEqual(
            call_args["ResourceConfig"]["VolumeKmsKeyId"], self.remote_client.kms_key_identifier
        )
        self.assertEqual(
            call_args["InputDataConfig"][0]["DataSource"]["S3DataSource"]["S3Uri"], input["path"]
        )
        self.assertEqual(call_args["HyperParameters"], {})
        self.assertEqual(call_args["StoppingCondition"]["MaxRuntimeInSeconds"], 86400)
        self.assertEqual(call_args["Environment"]["SM_INPUT_NOTEBOOK_NAME"], input["file"])
        self.assertEqual(call_args["Environment"]["SM_OUTPUT_NOTEBOOK_NAME"], output["file"])
        self.assertEqual(
            call_args["VpcConfig"]["SecurityGroupIds"], [self.remote_client.security_group]
        )
        self.assertEqual(call_args["VpcConfig"]["Subnets"], self.remote_client.subnets)

        self.assertEqual(result["execution_id"], "test-job-1234-5678-9012-3456")

    @patch("sagemaker_studio.execution.remote_execution_client.uuid")
    def test_start_execution_input_path_git_project_nested_path(self, mock_uuid):
        """Verify that for a git project with a nested input path like 'src/subdir/notebook.ipynb',
        the input S3Uri points to the project-files root and the file includes the subdirectory."""
        # Arrange
        mock_uuid.return_value = "1234-5678-9012-3456"

        mock_sagemaker_client = Mock()
        mock_sagemaker_client.create_training_job.return_value = {
            "TrainingJobArn": "arn:aws:sagemaker:us-west-2:123456123456:training-job/test-job-1234-5678-9012-3456"
        }
        self.remote_client.sagemaker_client = mock_sagemaker_client
        self.remote_client.kms_key_identifier = (
            "arn:aws:kms:us-west-2:123456123456:key/1234abcd-12ab-34cd-56ef-1234567890ab"
        )
        self.remote_client.user_role_arn = "arn:aws:iam::123456123456:role/SageMakerRole"
        self.remote_client.default_tooling_environment = {
            "awsAccountId": "123456123456",
            "awsAccountRegion": "us-west-2",
            "id": "env-12345",
            "name": "Default Environment",
            "provisionedResources": [
                {"name": "VpcId", "value": "vpc-12345678"},
                {"name": "SubnetIds", "value": "subnet-12345678,subnet-87654321"},
                {"name": "SecurityGroupId", "value": "sg-12345678"},
                {"name": "s3BucketPath", "value": "s3://my-bucket/my-project/"},
                {"name": "codeRepositoryName", "value": "my-code-repository"},
            ],
        }
        self.remote_client._utils = Mock()
        self.remote_client._utils._get_project_s3_path.return_value = "s3://my-bucket/my-project/"
        self.remote_client.domain_identifier = "domain-123"
        self.remote_client.project_identifier = "project-456"
        self.remote_client.datazone_endpoint = "https://bogus_endpoint.example.com/"
        self.remote_client.datazone_domain_region = "us-west-2"
        self.remote_client.project_s3_path = "s3://my-bucket/my-project/"
        self.remote_client.security_group = "sg-12345678"
        self.remote_client.subnets = ["subnet-12345678"]

        mock_ec2_client = Mock()
        mock_ec2_client.describe_instance_types.return_value = {
            "InstanceTypes": [
                {
                    "InstanceType": "m6i.xlarge",
                    "VCpuInfo": {"DefaultVCpus": 4},
                    "MemoryInfo": {"SizeInMiB": 16384},
                }
            ]
        }
        self.remote_client.ec2_client = mock_ec2_client

        mock_ssm_client = Mock()
        mock_ssm_client.get_parameter.return_value = {"Parameter": {"Value": "123456123456"}}
        self.remote_client.ssm_client = mock_ssm_client

        # Act
        self.remote_client.start_execution(
            execution_name="test-job",
            input_config={"notebook_config": {"input_path": "src/subdir/notebook.ipynb"}},
        )

        # Assert
        call_args = mock_sagemaker_client.create_training_job.call_args[1]

        # The input S3Uri should point to the project-files root, not include the subdirectory
        self.assertEqual(
            call_args["InputDataConfig"][0]["DataSource"]["S3DataSource"]["S3Uri"],
            "s3://my-bucket/my-project/workflows/project-files",
        )
        # The file should include the subdirectory relative path
        self.assertEqual(
            call_args["Environment"]["SM_INPUT_NOTEBOOK_NAME"], "subdir/notebook.ipynb"
        )
        self.assertEqual(call_args["Environment"]["SM_OUTPUT_NOTEBOOK_NAME"], "_notebook.ipynb")

    @patch("sagemaker_studio.execution.remote_execution_client.uuid")
    def test_start_execution_input_path_s3_project(self, mock_uuid):
        """Verify that for a non-git (S3) project with input path 'shared/test.ipynb',
        the input S3Uri points to the shared root and the file is the relative path."""
        # Arrange
        mock_uuid.return_value = "1234-5678-9012-3456"

        mock_sagemaker_client = Mock()
        mock_sagemaker_client.create_training_job.return_value = {
            "TrainingJobArn": "arn:aws:sagemaker:us-west-2:123456123456:training-job/test-job-1234-5678-9012-3456"
        }
        self.remote_client.sagemaker_client = mock_sagemaker_client
        self.remote_client.kms_key_identifier = (
            "arn:aws:kms:us-west-2:123456123456:key/1234abcd-12ab-34cd-56ef-1234567890ab"
        )
        self.remote_client.user_role_arn = "arn:aws:iam::123456123456:role/SageMakerRole"
        # No codeRepositoryName or gitConnectionArn → S3 project
        self.remote_client.default_tooling_environment = {
            "awsAccountId": "123456123456",
            "awsAccountRegion": "us-west-2",
            "id": "env-12345",
            "name": "Default Environment",
            "provisionedResources": [
                {"name": "VpcId", "value": "vpc-12345678"},
                {"name": "SubnetIds", "value": "subnet-12345678,subnet-87654321"},
                {"name": "SecurityGroupId", "value": "sg-12345678"},
                {"name": "s3BucketPath", "value": "s3://my-bucket/my-project/"},
            ],
        }
        self.remote_client._utils = Mock()
        self.remote_client._utils._get_project_s3_path.return_value = "s3://my-bucket/my-project/"
        self.remote_client.domain_identifier = "domain-123"
        self.remote_client.project_identifier = "project-456"
        self.remote_client.datazone_endpoint = "https://bogus_endpoint.example.com/"
        self.remote_client.datazone_domain_region = "us-west-2"
        self.remote_client.project_s3_path = "s3://my-bucket/my-project/"
        self.remote_client.security_group = "sg-12345678"
        self.remote_client.subnets = ["subnet-12345678"]

        mock_ec2_client = Mock()
        mock_ec2_client.describe_instance_types.return_value = {
            "InstanceTypes": [
                {
                    "InstanceType": "m6i.xlarge",
                    "VCpuInfo": {"DefaultVCpus": 4},
                    "MemoryInfo": {"SizeInMiB": 16384},
                }
            ]
        }
        self.remote_client.ec2_client = mock_ec2_client

        mock_ssm_client = Mock()
        mock_ssm_client.get_parameter.return_value = {"Parameter": {"Value": "123456123456"}}
        self.remote_client.ssm_client = mock_ssm_client

        # Act
        self.remote_client.start_execution(
            execution_name="test-job",
            input_config={"notebook_config": {"input_path": "shared/test.ipynb"}},
        )

        # Assert
        call_args = mock_sagemaker_client.create_training_job.call_args[1]

        # For S3 projects, the input S3Uri should point to the project root
        # (pack_s3_path_for_input_file produces "s3://my-bucket/my-project/test.ipynb" for S3 projects,
        # and stripping the relative path "test.ipynb" leaves the project root)
        self.assertEqual(
            call_args["InputDataConfig"][0]["DataSource"]["S3DataSource"]["S3Uri"],
            "s3://my-bucket/my-project",
        )
        # The file should be just the filename with shared/ stripped
        self.assertEqual(call_args["Environment"]["SM_INPUT_NOTEBOOK_NAME"], "test.ipynb")

    @patch("sagemaker_studio.execution.remote_execution_client.uuid")
    def test_start_execution_input_path_s3_project_nested_path(self, mock_uuid):
        """Verify that for a non-git (S3) project with a nested input path like 'shared/subdir/nb.ipynb',
        the input S3Uri points to the shared root and the file includes the subdirectory."""
        # Arrange
        mock_uuid.return_value = "1234-5678-9012-3456"

        mock_sagemaker_client = Mock()
        mock_sagemaker_client.create_training_job.return_value = {
            "TrainingJobArn": "arn:aws:sagemaker:us-west-2:123456123456:training-job/test-job-1234-5678-9012-3456"
        }
        self.remote_client.sagemaker_client = mock_sagemaker_client
        self.remote_client.kms_key_identifier = (
            "arn:aws:kms:us-west-2:123456123456:key/1234abcd-12ab-34cd-56ef-1234567890ab"
        )
        self.remote_client.user_role_arn = "arn:aws:iam::123456123456:role/SageMakerRole"
        self.remote_client.default_tooling_environment = {
            "awsAccountId": "123456123456",
            "awsAccountRegion": "us-west-2",
            "id": "env-12345",
            "name": "Default Environment",
            "provisionedResources": [
                {"name": "VpcId", "value": "vpc-12345678"},
                {"name": "SubnetIds", "value": "subnet-12345678,subnet-87654321"},
                {"name": "SecurityGroupId", "value": "sg-12345678"},
                {"name": "s3BucketPath", "value": "s3://my-bucket/my-project/"},
            ],
        }
        self.remote_client._utils = Mock()
        self.remote_client._utils._get_project_s3_path.return_value = "s3://my-bucket/my-project/"
        self.remote_client.domain_identifier = "domain-123"
        self.remote_client.project_identifier = "project-456"
        self.remote_client.datazone_endpoint = "https://bogus_endpoint.example.com/"
        self.remote_client.datazone_domain_region = "us-west-2"
        self.remote_client.project_s3_path = "s3://my-bucket/my-project/"
        self.remote_client.security_group = "sg-12345678"
        self.remote_client.subnets = ["subnet-12345678"]

        mock_ec2_client = Mock()
        mock_ec2_client.describe_instance_types.return_value = {
            "InstanceTypes": [
                {
                    "InstanceType": "m6i.xlarge",
                    "VCpuInfo": {"DefaultVCpus": 4},
                    "MemoryInfo": {"SizeInMiB": 16384},
                }
            ]
        }
        self.remote_client.ec2_client = mock_ec2_client

        mock_ssm_client = Mock()
        mock_ssm_client.get_parameter.return_value = {"Parameter": {"Value": "123456123456"}}
        self.remote_client.ssm_client = mock_ssm_client

        # Act
        self.remote_client.start_execution(
            execution_name="test-job",
            input_config={"notebook_config": {"input_path": "shared/subdir/nb.ipynb"}},
        )

        # Assert
        call_args = mock_sagemaker_client.create_training_job.call_args[1]

        # For S3 projects with nested paths, S3Uri should point to the project root
        self.assertEqual(
            call_args["InputDataConfig"][0]["DataSource"]["S3DataSource"]["S3Uri"],
            "s3://my-bucket/my-project",
        )
        # The file should include the subdirectory relative path
        self.assertEqual(call_args["Environment"]["SM_INPUT_NOTEBOOK_NAME"], "subdir/nb.ipynb")
        self.assertEqual(call_args["Environment"]["SM_OUTPUT_NOTEBOOK_NAME"], "_nb.ipynb")
