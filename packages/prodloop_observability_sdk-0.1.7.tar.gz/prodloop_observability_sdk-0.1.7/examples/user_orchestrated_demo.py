"""User-orchestrated example using the Prodloop SDK and Vertex AI Gemini.

Use this when your local process should run the bot model with your own Vertex
credentials. Prodloop runs the tester and grader, while this script sends only
bot replies and local bot latency back to Prodloop.
"""
import os
from datetime import datetime
from pathlib import Path
from typing import Any, Mapping, Sequence

from prodloop import EvaluationParameter, ProdloopClient, SimulationMode, plugins



def _log(message: str) -> None:
    print(f"[{datetime.now().strftime('%H:%M:%S')}] {message}", flush=True)


def _ms(value: Any) -> str:
    if value is None:
        return "pending"
    try:
        return f"{float(value):.2f}ms"
    except (TypeError, ValueError):
        return str(value)


def _load_env_for_demo() -> None:
    # Loading .env is optional. Users can also export these variables directly.
    try:
        from dotenv import load_dotenv
    except Exception:
        return
    load_dotenv(override=False)
    credentials_path = os.getenv("GOOGLE_APPLICATION_CREDENTIALS", "").strip()
    if credentials_path and not os.path.isabs(credentials_path):
        # Let users set GOOGLE_APPLICATION_CREDENTIALS=./service-account.json
        # relative to the folder where they run this script.
        candidate = Path.cwd() / credentials_path
        if candidate.exists():
            os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = str(candidate)


_LOCAL_BOT_HANDLER: plugins.LiteLLMBot | None = None
_TURN_COUNTER = 0


def _get_or_create_local_bot_handler() -> plugins.LiteLLMBot:
    global _LOCAL_BOT_HANDLER
    if _LOCAL_BOT_HANDLER is None:
        _load_env_for_demo()
        model = os.getenv("USER_ORCH_LITELLM_MODEL") or "vertex_ai/gemini-2.5-pro"
        # LiteLLMBot is a callable used by the SDK loop. It runs locally with
        # the user's Vertex credentials; Prodloop never receives those creds.
        _LOCAL_BOT_HANDLER = plugins.LiteLLMBot(
            model=model,
            system_prompt=(
                "You are a concise food delivery support assistant under test. "
                "Do not invent details not present in the chat context."
            ),
            endpoint={
                "vertex_project": os.getenv("VERTEX_PROJECT"),
                "vertex_location": os.getenv("VERTEX_LOCATION", "global"),
            },
            options={"temperature": 0.2, "max_tokens": 256},
        )
    return _LOCAL_BOT_HANDLER


def real_bot_turn_handler(
    tester_message: str,
    transcript: Sequence[Mapping[str, Any]],
) -> Mapping[str, Any]:
    global _TURN_COUNTER
    _TURN_COUNTER += 1
    _log(f"[turn {_TURN_COUNTER}] tester: {tester_message}")

    handler = _get_or_create_local_bot_handler()
    result = handler(tester_message, transcript)
    text = str(result["response"]).strip()
    llm_processing_latency_ms = float(result["llm_processing_latency_ms"])
    _log(f"[turn {_TURN_COUNTER}] bot: {text}")
    _log(f"[turn {_TURN_COUNTER}] bot_llm_processing_latency={_ms(llm_processing_latency_ms)}")
    return result


def _print_stop_reason(final_response: Mapping[str, Any]) -> None:
    final_result = final_response.get("final_result")
    if not isinstance(final_result, Mapping):
        return
    stop_reason = final_result.get("stop_reason")
    stop_message = final_result.get("stop_message")
    if stop_reason:
        print(f"stop_reason: {stop_reason}", flush=True)
    if stop_message:
        print(f"stop_message: {stop_message}", flush=True)


def _print_prompt_patch_suggestions(final_response: Mapping[str, Any]) -> None:
    final_result = final_response.get("final_result")
    if not isinstance(final_result, Mapping):
        return
    parameter_results = final_result.get("parameter_results")
    if not isinstance(parameter_results, list):
        return

    printed_any = False
    for item in parameter_results:
        if not isinstance(item, Mapping):
            continue
        if bool(item.get("passed")):
            continue
        patch_location = str(item.get("prompt_patch_location") or "").strip()
        patch_lines = item.get("prompt_patch_lines") or []
        if not isinstance(patch_lines, list):
            patch_lines = []
        if not patch_location and not patch_lines:
            continue
        if not printed_any:
            print("\nPrompt patch suggestions:", flush=True)
            printed_any = True
        parameter_name = str(item.get("parameter") or "unknown_parameter")
        print(f"- parameter: {parameter_name}", flush=True)
        if patch_location:
            print(f"  add_at: {patch_location}", flush=True)
        if patch_lines:
            print("  lines_to_add:", flush=True)
            for line in patch_lines:
                line_text = str(line).strip()
                if line_text:
                    print(f"    - {line_text}", flush=True)


def main() -> None:
    _load_env_for_demo()
    global _TURN_COUNTER
    _TURN_COUNTER = 0

    api_key = os.getenv("PRODLOOP_API_KEY")
    if not api_key:
        raise RuntimeError("Set PRODLOOP_API_KEY before running this demo.")

    client = ProdloopClient(api_key=api_key, timeout_seconds=1800)
    prompt = (
        "You are a concise food delivery support assistant. "
        "Answer only from available conversation context."
    )
    max_turns = 10
    _log("Starting user_orchestrated simulation...")
    # Start the simulation first so the chat_id is visible before bot turns are submitted.
    current_response = client._post_json(
        "/simulate/start",
        {
            "simulation_mode": SimulationMode.USER_ORCHESTRATED.value,
            "prompt": prompt,
            "parameters": [EvaluationParameter.HALLUCINATION.value],
            "max_turns": max_turns,
            "adaptive_max_conversations": 50,
            "scenario": (
                "A customer reports delayed delivery and then asks about a possible extra charge."
            ),
        },
        None,
    )
    chat_id = str(current_response.get("chat_id") or "")
    _log(f"chat_id: {chat_id}")
    _log(f"status: {current_response.get('status')}")

    while current_response.get("status") != "completed":
        tester_message = str(current_response.get("tester_message") or "").strip()
        if not tester_message:
            raise RuntimeError("Backend response missing tester_message.")
        transcript = current_response.get("transcript") or []
        if not isinstance(transcript, list):
            raise RuntimeError("Backend transcript must be a list.")

        handler_output = real_bot_turn_handler(tester_message, transcript)
        # Only the bot reply and measured local bot latency are sent to Prodloop.
        # Provider credentials stay in this process.
        current_response = client._post_json(
            "/simulate/turn",
            {
                "chat_id": chat_id,
                "bot_response": str(handler_output["response"]).strip(),
                "bot_response_latency_ms": handler_output["llm_processing_latency_ms"],
            },
            None,
        )
        progress = current_response.get("progress") or {}
        _log(
            f"submitted turn={_TURN_COUNTER} status={current_response.get('status')} "
            f"chat_id={chat_id} "
            f"phase={progress.get('current_phase')} "
            f"activity={progress.get('latest_activity')} "
            f"conversation={progress.get('current_conversation')}/"
            f"{progress.get('max_conversations')} "
            f"turns_completed={progress.get('turns_completed')}/"
            f"{progress.get('max_total_turns')} "
            f"eta={progress.get('estimated_completion')}"
        )

    final_response = current_response
    _log("User orchestrated simulation completed")
    _log(f"chat_id: {final_response.get('chat_id')}")
    _log(f"status: {final_response.get('status')}")
    turns = final_response.get("turns") or []
    if isinstance(turns, list):
        for turn in turns:
            if not isinstance(turn, Mapping):
                continue
            turn_number = int(turn.get("turn_index", 0)) + 1
            turn_id = str(turn.get("turn_id") or f"turn_{turn_number}")
            timing = turn.get("timing") or {}
            if not isinstance(timing, Mapping):
                timing = {}
            tester_ms = timing.get("tester_llm_processing_latency_ms") or timing.get(
                "tester_generation_latency_ms"
            )
            bot_ms = timing.get("bot_llm_processing_latency_ms") or timing.get(
                "bot_response_latency_ms"
            )
            grade_ms = timing.get("tester_grading_llm_processing_latency_ms")
            _log(
                f"[turn {turn_number} | {turn_id}] "
                f"tester={_ms(tester_ms)} bot={_ms(bot_ms)} grader={_ms(grade_ms)}"
            )
    _log("final response:")
    print(final_response, flush=True)
    _print_stop_reason(final_response)
    _print_prompt_patch_suggestions(final_response)


if __name__ == "__main__":
    main()
