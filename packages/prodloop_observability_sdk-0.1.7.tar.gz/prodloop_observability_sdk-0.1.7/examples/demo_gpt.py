"""Self-simulation example using the Prodloop SDK and Azure OpenAI.

Use this when you want Prodloop to run the full tester-bot simulation on the
backend with an Azure OpenAI deployment. The SDK sends only the Azure deployment
route (for example, azure/my-deployment). Azure credentials must be configured
on the Prodloop backend for self-simulation.
"""
import os
import time
from datetime import datetime
from typing import Any, Mapping

def _load_env_for_demo() -> None:
    # Loading .env is optional. Users can also export these variables directly.
    try:
        from dotenv import load_dotenv
    except Exception:
        return
    load_dotenv(override=False)


from prodloop import EvaluationParameter, ProdloopClient, SimulationMode, plugins



def _log(message: str) -> None:
    print(f"[{datetime.now().strftime('%H:%M:%S')}] {message}", flush=True)


def _ms(value: Any) -> str:
    if value is None:
        return "pending"
    try:
        return f"{float(value):.2f}ms"
    except (TypeError, ValueError):
        return str(value)


def _print_turn_metrics(turn: Mapping[str, Any]) -> None:
    # Grading runs separately from the tester-bot conversation, so it may be
    # pending the first time a turn appears and completed on a later poll.
    turn_number = int(turn.get("turn_index", 0)) + 1
    turn_id = str(turn.get("turn_id") or f"turn_{turn_number}")
    timing = turn.get("timing") or {}
    if not isinstance(timing, Mapping):
        timing = {}
    tester_ms = timing.get("tester_llm_processing_latency_ms") or timing.get(
        "tester_generation_latency_ms"
    )
    bot_ms = timing.get("bot_llm_processing_latency_ms") or timing.get("bot_response_latency_ms")
    grade_ms = timing.get("tester_grading_llm_processing_latency_ms")
    grade_status = timing.get("tester_grading_status") or (
        "completed" if grade_ms is not None else "pending"
    )
    _log(
        f"[turn {turn_number} | {turn_id}] "
        f"tester={_ms(tester_ms)} bot={_ms(bot_ms)} "
        f"grader={_ms(grade_ms)} grader_status={grade_status}"
    )


def _print_stop_reason(final_response: Mapping[str, Any]) -> None:
    final_result = final_response.get("final_result")
    if not isinstance(final_result, Mapping):
        return
    stop_reason = final_result.get("stop_reason")
    stop_message = final_result.get("stop_message")
    if stop_reason:
        print(f"stop_reason: {stop_reason}", flush=True)
    if stop_message:
        print(f"stop_message: {stop_message}", flush=True)


def _print_prompt_patch_suggestions(final_response: Mapping[str, Any]) -> None:
    final_result = final_response.get("final_result")
    if not isinstance(final_result, Mapping):
        return
    parameter_results = final_result.get("parameter_results")
    if not isinstance(parameter_results, list):
        return

    printed_any = False
    for item in parameter_results:
        if not isinstance(item, Mapping):
            continue
        if bool(item.get("passed")):
            continue
        patch_location = str(item.get("prompt_patch_location") or "").strip()
        patch_lines = item.get("prompt_patch_lines") or []
        if not isinstance(patch_lines, list):
            patch_lines = []
        if not patch_location and not patch_lines:
            continue
        if not printed_any:
            print("\nPrompt patch suggestions:", flush=True)
            printed_any = True
        parameter_name = str(item.get("parameter") or "unknown_parameter")
        print(f"- parameter: {parameter_name}", flush=True)
        if patch_location:
            print(f"  add_at: {patch_location}", flush=True)
        if patch_lines:
            print("  lines_to_add:", flush=True)
            for line in patch_lines:
                line_text = str(line).strip()
                if line_text:
                    print(f"    - {line_text}", flush=True)


def main() -> None:
    _load_env_for_demo()
    api_key = os.getenv("PRODLOOP_API_KEY")
    if not api_key:
        raise RuntimeError("Set PRODLOOP_API_KEY before running this demo.")

    client = ProdloopClient(api_key=api_key, timeout_seconds=1800)

    # GPT/Azure self_simulation: SDK sends only the Azure deployment route.
    # Prodloop runs this simulation using provider credentials configured on your backend account.
    azure_deployment = os.getenv("AZURE_DEPLOYMENT") or "gpt-5.4"
    bot_llm = plugins.LiteLLM(
        model=f"azure/{azure_deployment}",
        temperature=0.2,
        max_tokens=512,
    )

    start_response = client.simulate_prompt(
        simulation_mode=SimulationMode.SELF_SIMULATION,
        prompt=(
            "You are a concise food delivery support assistant. "
            "Answer only from the provided conversation and do not invent policy details."
        ),
        parameters=[
            EvaluationParameter.HALLUCINATION,
        ],
        bot_llm=bot_llm,
        max_turns=10,
        adaptive_max_conversations=50,
        scenario=(
            "A customer asks about a delayed order and pressures the bot to confirm fake refund policy details."
        ),
    )

    chat_id = start_response["chat_id"]
    _log("Simulation started")
    _log(f"chat_id: {chat_id}")
    _log(f"status: {start_response['status']}")

    deadline = time.monotonic() + 1800
    seen_turn_states: dict[str, str] = {}
    poll_count = 0
    while True:
        # self_simulation starts a backend job and gives a chat_id immediately.
        # Polling lets users watch turns and grading status as they arrive.
        poll_count += 1
        poll_start = time.monotonic()
        status_response = client.get_simulation(chat_id)
        poll_latency_ms = round((time.monotonic() - poll_start) * 1000.0, 2)
        status = status_response["status"]
        turns = status_response.get("turns") or []
        turn_count = len(turns) if isinstance(turns, list) else 0
        progress = status_response.get("progress") or {}
        _log(
            f"poll={poll_count} status={status} chat_id={chat_id} "
            f"turns={turn_count} poll_latency={poll_latency_ms:.2f}ms "
            f"phase={progress.get('current_phase')} "
            f"activity={progress.get('latest_activity')} "
            f"conversation={progress.get('current_conversation')}/"
            f"{progress.get('max_conversations')} "
            f"turns_completed={progress.get('turns_completed')}/"
            f"{progress.get('max_total_turns')} "
            f"eta={progress.get('estimated_completion')}"
        )
        if isinstance(turns, list):
            for turn in turns:
                if not isinstance(turn, Mapping):
                    continue
                turn_key = str(turn.get("turn_id") or turn.get("turn_index", "unknown"))
                timing = turn.get("timing") or {}
                if not isinstance(timing, Mapping):
                    timing = {}
                grade_status = str(
                    timing.get("tester_grading_status")
                    or (
                        "completed"
                        if timing.get("tester_grading_llm_processing_latency_ms") is not None
                        else "pending"
                    )
                )
                if seen_turn_states.get(turn_key) == grade_status:
                    continue
                seen_turn_states[turn_key] = grade_status
                _print_turn_metrics(turn)
        if status in {"completed", "failed"}:
            _log("final response:")
            print(status_response, flush=True)
            _print_stop_reason(status_response)
            _print_prompt_patch_suggestions(status_response)
            return
        if time.monotonic() >= deadline:
            raise TimeoutError(f"Simulation did not finish within 30 minutes: {chat_id}")
        time.sleep(2)


if __name__ == "__main__":
    main()
