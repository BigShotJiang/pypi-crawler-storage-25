# Examples

## Basic Evaluation

```python
from prodloop import ProdloopClient, EvaluationParameter

client = ProdloopClient(api_key="sk_live_...")

result = client.evaluate_call(
    audio_file_path="sample_call.mp3",
    parameters=[EvaluationParameter.E2E_RESPONSE_TIME, EvaluationParameter.HALLUCINATION],
    thresholds={"e2e_response_time_max_ms": 800},
)

print(result)
```

## With Extraction Variables

```python
from prodloop import ProdloopClient, EvaluationParameter

client = ProdloopClient(api_key="sk_live_...")

result = client.evaluate_call(
    audio_file_path="sample_call.mp3",
    parameters=[EvaluationParameter.EXTRACTION_VARIABLES],
    extraction_schema={
        "customer_name": "string",
        "budget_mentioned": "int",
    },
    bot_captured_variables={
        "customer_name": "ram",
        "budget_mentioned": 12000,
    },
)

print(result)
```

`result` includes:

- `extraction_variables` (model extracted values)
- `extraction_validation` (match/mismatch summary vs `bot_captured_variables`)


## Self Simulation

```python
import os
import time
from prodloop import EvaluationParameter, ProdloopClient, SimulationMode, plugins

client = ProdloopClient(api_key=os.environ["PRODLOOP_API_KEY"])

start = client.simulate_prompt(
    simulation_mode=SimulationMode.SELF_SIMULATION,
    prompt="You are a concise support bot. Do not invent policy details.",
    parameters=[EvaluationParameter.HALLUCINATION],
    bot_llm=plugins.LiteLLM(
        model="vertex_ai/gemini-2.5-pro",
        temperature=0.2,
        max_tokens=512,
    ),
    max_turns=10,
    adaptive_max_conversations=50,
)

chat_id = start["chat_id"]
while True:
    result = client.get_simulation(chat_id)
    if result["status"] in {"completed", "failed"}:
        print(result)
        break
    time.sleep(2)
```

## User Orchestrated Simulation

```python
import os
from prodloop import EvaluationParameter, ProdloopClient, SimulationMode, plugins

bot = plugins.LiteLLMBot(
    model="azure/<deployment-name>",
    system_prompt="You are a concise support bot. Do not invent policy details.",
    options={"temperature": 0.2, "max_tokens": 256},
)

client = ProdloopClient(api_key=os.environ["PRODLOOP_API_KEY"])

result = client.simulate_prompt(
    simulation_mode=SimulationMode.USER_ORCHESTRATED,
    prompt="You are a concise support bot. Do not invent policy details.",
    parameters=[EvaluationParameter.HALLUCINATION],
    max_turns=10,
    adaptive_max_conversations=50,
    bot_turn_handler=bot,
)

print(result)
```

In this mode, set local credentials for the selected supported route. Use Vertex ADC/project/location for `vertex_ai/...`, or Azure endpoint/API version/API key for `azure/...`.


## Discover Simulation Parameters

```python
from prodloop import ProdloopClient

client = ProdloopClient(api_key="sk_live_...")
params = client.get_simulation_parameters()
print([item["key"] for item in params["parameters"]])
```

Use one returned key per simulation request.

`turn_by_turn_latency` is also included in every simulation final result automatically, so users do not need a separate request just to see per-turn bot latency.

## Full Runnable Examples

The repository includes copy-pasteable examples in `examples/`. These are embedded below so the documentation stays in sync with the runnable files.

### Environment Template

```bash
--8<-- "examples/.env.example"
```

### Vertex AI Self Simulation

```python
--8<-- "examples/demo.py"
```

### Azure OpenAI Self Simulation

```python
--8<-- "examples/demo_gpt.py"
```

### Vertex AI User Orchestrated Simulation

```python
--8<-- "examples/user_orchestrated_demo.py"
```

### Azure OpenAI User Orchestrated Simulation

```python
--8<-- "examples/user_orchestrated_demo_gpt.py"
```
