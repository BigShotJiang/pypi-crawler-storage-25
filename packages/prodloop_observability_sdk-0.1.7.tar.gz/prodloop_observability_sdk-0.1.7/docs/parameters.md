# Parameters

Supported evaluation parameters:

- `e2e_response_time`
- `turn_by_turn_latency`
- `pause_profile`
- `audio_artifacts`
- `hallucination`
- `extraction_variables`
- `interruption_behavior`

Use enum constants from `EvaluationParameter`:

```python
from prodloop import EvaluationParameter

params = [
    EvaluationParameter.E2E_RESPONSE_TIME,
    EvaluationParameter.PAUSE_PROFILE,
    EvaluationParameter.HALLUCINATION,
]
```

## What each parameter means

- `e2e_response_time`: average latency (ms) between one speech segment ending and the next one starting.
- `turn_by_turn_latency`: per-gap latency values as `turn_index` + `latency_ms`.
- `pause_profile`: deterministic pause aggregate (`pause_count`, `total_pause_time_ms`, `longest_pause_ms`).
- `audio_artifacts`: deterministic signal quality indicators (`clipping_ratio`, `dc_offset`, risk flags).
- `hallucination`: whether the bot introduced fabricated/incorrect content.
- `extraction_variables`: extracts requested structured fields.
- `interruption_behavior`: whether interruptions were handled gracefully.

Deterministic today:
- `e2e_response_time`
- `turn_by_turn_latency`
- `pause_profile`
- `audio_artifacts`

## Extraction Variables

If you include `extraction_variables`, pass both:

- `extraction_schema` (what fields to extract)
- `bot_captured_variables` (what your bot captured for validation)

```python
extraction_schema = {
    "customer_name": "string",
    "budget_mentioned": "int",
}

bot_captured_variables = {
    "customer_name": "ram",
    "budget_mentioned": 12000,
}
```
