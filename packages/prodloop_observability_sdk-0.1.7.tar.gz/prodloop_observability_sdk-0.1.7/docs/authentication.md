# Authentication

The SDK uses your Prodloop API key for authentication automatically.

Initialize with your key:

```python
ProdloopClient(api_key="sk_live_...")
```

## Environment variable pattern

```bash
export PRODLOOP_API_KEY="sk_live_..."
```

```python
import os
from prodloop import ProdloopClient

client = ProdloopClient(api_key=os.environ["PRODLOOP_API_KEY"])
```


## Bot Provider Credentials

Prodloop API authentication is separate from bot provider credentials.

For `self_simulation`, bot provider credentials live on the Prodloop backend. Your SDK code sends only the model route and options.

For `user_orchestrated`, bot provider credentials stay in your local environment because your process runs the bot. Currently document-supported local bot routes are Vertex AI (`vertex_ai/...`) and Azure OpenAI (`azure/...`). Configure Vertex ADC/service-account variables or Azure endpoint/API version/API key locally. Do not send these credentials to Prodloop.
