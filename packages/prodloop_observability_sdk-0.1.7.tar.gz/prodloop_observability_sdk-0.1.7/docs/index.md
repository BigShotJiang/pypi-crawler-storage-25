# Prodloop Observability SDK

Use the Prodloop SDK to programmatically evaluate AI voice bot calls from Python.

## What you can do

- send call recordings for evaluation
- choose exactly which metrics to compute
- pass thresholds and extraction schema
- receive structured JSON responses
- simulate prompt-only tester/bot conversations
- run backend-owned self simulation or local user-orchestrated simulation

## Install

```bash
pip install prodloop-observability-sdk
```

## Quickstart

```python
from prodloop import ProdloopClient, EvaluationParameter

client = ProdloopClient(api_key="sk_live_...")

result = client.evaluate_call(
    audio_file_path="call.mp3",
    parameters=[
        EvaluationParameter.E2E_RESPONSE_TIME,
        EvaluationParameter.HALLUCINATION,
    ],
    thresholds={"e2e_response_time_max_ms": 800},
)

print(result)
```


## Prompt Simulation

Prompt simulation lets you test a bot prompt without audio. Use `plugins.LiteLLM` to select any LiteLLM model route and choose one simulation parameter per request.

- `self_simulation`: Prodloop backend runs the tester and bot with backend-owned provider credentials.
- `user_orchestrated`: your local SDK process runs the bot with your credentials; Prodloop only receives bot replies and timing.

See [Examples](examples.md) for full code.
