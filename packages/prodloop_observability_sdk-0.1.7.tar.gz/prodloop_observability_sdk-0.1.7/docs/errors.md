# Errors

The SDK raises typed exceptions:

- `ValidationError` for invalid client-side inputs
- `APIError` for backend/API failures

## ValidationError examples

- missing API key
- unsupported parameter
- missing audio file
- requesting `extraction_variables` without `extraction_schema`
- requesting `extraction_variables` without `bot_captured_variables`
- `bot_captured_variables` missing keys present in `extraction_schema`

## APIError examples

- unauthorized (`401`)
- malformed request (`400`)
- internal server error (`500`)

`APIError` includes:

- `status_code`
- `message`


## Simulation Errors

Common simulation errors:

- `BOT_PROVIDER_NOT_CONFIGURED`: selected `self_simulation` model route is not configured on the backend. Configure provider credentials on the backend or use `user_orchestrated`.
- `BOT_LLM_REQUEST_FAILED`: provider request failed. The backend returns a safe user-facing error and does not expose provider error details.
- `BAD_SIMULATION_REQUEST`: invalid simulation request, such as missing `bot_llm`, missing prompt, unsupported parameter, or more than one parameter.

For failed simulation parameters, check `final_result.parameter_results[*].prompt_patch_lines` and `prompt_patch_location` for suggested prompt changes.
