# Visual Overview

This page shows only the SDK function contract: what you pass and what you get back.

## Function Call

```mermaid
graph LR
    A[Your Script] --> B[evaluate_call]
    B --> C[JSON Response]
```

## Function Signature

```python
evaluate_call(
    audio_file_path: str,
    parameters: list[EvaluationParameter | str],
    thresholds: dict | None = None,
    extraction_schema: dict | None = None,
    bot_captured_variables: dict | None = None,
    timeout_seconds: int | None = None,
) -> dict
```

## Request Payload (conceptual)

You provide:

```json
{
  "audio_file_path": "sample_call.mp3",
  "parameters": ["e2e_response_time", "hallucination"],
  "thresholds": {"e2e_response_time_max_ms": 800},
  "extraction_schema": {"customer_name": "string"},
  "bot_captured_variables": {"customer_name": "ram"}
}
```

## Response Payload (example)

`evaluate_call(...)` returns:

```json
{
  "extraction_variables": {
    "customer_name": "ram"
  },
  "extraction_validation": {
    "total_fields": 1,
    "matched_fields": 1,
    "all_matched": true,
    "mismatched_fields": [],
    "field_results": {
      "customer_name": {
        "expected": "ram",
        "actual": "ram",
        "matched": true
      }
    }
  }
}
```

## Error Responses (SDK)

Possible exceptions:

- `ValidationError` for invalid input usage
- `APIError` for request failures or server-side failures

## Minimal Example

```python
from prodloop import ProdloopClient, EvaluationParameter

client = ProdloopClient(api_key="sk_live_...")

result = client.evaluate_call(
    audio_file_path="sample_call.mp3",
    parameters=[EvaluationParameter.E2E_RESPONSE_TIME, EvaluationParameter.HALLUCINATION],
    thresholds={"e2e_response_time_max_ms": 800},
)

print(result)
```
