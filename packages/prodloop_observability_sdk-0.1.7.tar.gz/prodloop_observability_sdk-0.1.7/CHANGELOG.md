# Changelog

## Unreleased

- Added `pause_profile` and `audio_artifacts` as supported evaluation parameters.
- Aligned SDK, backend, demo, and eval judge parameter registries for the expanded set.
- Added deterministic audio-metric documentation for parameter-level usage clarity.

## 0.1.4

- Added required `input_prompt` for hallucination evaluations.
- Enforced hallucination input validation for consistent prompt-grounded checks.

## 0.1.3

- Removed `base_url` from `ProdloopClient` constructor so endpoint configuration stays internal.
- Updated demo scripts to use the simplified constructor without endpoint overrides.

## 0.1.2

- Updated package metadata to use the live docs URL.
- Removed local docs-serve instructions from package README.

## 0.1.1

- Removed misleading `Local Demo` section from package README on PyPI.
- Clarified package-facing documentation for installed users.

## 0.1.0

- Initial SDK release
- `ProdloopClient` with `evaluate_call(...)`
- typed parameters via `EvaluationParameter`
- validation and typed exceptions
- demo usage script
