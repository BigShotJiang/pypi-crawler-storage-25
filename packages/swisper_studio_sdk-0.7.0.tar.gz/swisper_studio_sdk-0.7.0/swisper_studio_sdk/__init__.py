"""
SwisperStudio SDK

Simple integration for tracing Swisper LangGraph applications.

v0.6.1 - Typed Interface + Deprecation Warnings:
- Added interface.py with typed exports (PEP 561 compliant)
- Added py.typed marker for type checking support
- Deprecated functions now emit DeprecationWarning
- All public types exported from _types.py

v0.6.0 - Zero-config agent tracing with auto_trace():
- ONE-LINE initialization via auto_trace()
- Automatic LangGraph StateGraph patching
- Environment-based configuration

v0.5.3 - LLM TELEMETRY FIX (Critical):
- FIXED: LLM observations now correctly show as GENERATION (not SPAN)
- FIXED: obs_id context propagation issue with LangGraph orchestration

v0.5.1 - ROBUST FAILURE HANDLING:
- SDK NEVER blocks or crashes Swisper, even if:
  - Redis is misconfigured
  - Redis is unreachable
  - SwisperStudio is down
  - Any timeout occurs
- All operations have timeouts (default 3s)
- Graceful degradation - tracing silently disabled on failure

Usage:
    from swisper_studio_sdk import auto_trace
    
    # ONE-LINE initialization (reads from environment)
    status = await auto_trace()
    
    # Or manual initialization
    from swisper_studio_sdk import safe_initialize
    
    await safe_initialize(
        redis_url="redis://redis:6379",
        project_id="your-project-id"
    )
"""

# Define version BEFORE imports to avoid circular dependency
__version__ = "0.6.6"

import asyncio
import logging
import os
from typing import Dict, Optional

logger = logging.getLogger(__name__)

# ============================================================================
# CRITICAL DESIGN PRINCIPLE:
# The SDK must NEVER block or crash Swisper, even if:
# - Redis is misconfigured
# - Redis is unreachable
# - SwisperStudio is down
# - Any timeout occurs
#
# All SDK operations fail silently and gracefully.
# ============================================================================

# =============================================================================
# PUBLIC INTERFACE IMPORTS
# =============================================================================

# Types (for type checking)
from ._types import (
    InitializationStatus,
    AutoTraceStatus,
    TracingConfig,
    ObservationType,
)

# Core functions from interface module
from .interface import (
    # Zero-config initialization
    auto_trace,
    
    # Manual initialization
    safe_initialize,
    initialize_redis_publisher,
    close_redis_publisher,
    disable_tracing,
    
    # Graph tracing
    create_traced_graph,
    traced,
    
    # LangGraph patching
    patch_langgraph,
    unpatch_langgraph,
    set_trace_name,
    
    # Wrappers
    wrap_llm_adapter,
    wrap_tools,
    
    # Status checks
    is_sdk_available,
    is_tracing_initialized,
    
    # Constants
    DEFAULT_TIMEOUT,
)

# Deprecated function (emits warning when used)
from ._deprecated import initialize_tracing


# =============================================================================
# BACKWARD COMPATIBILITY - Keep old function signatures working
# =============================================================================

# These are now re-exported from interface.py, but we keep them here
# for any code that might be doing introspection on __init__.py


# =============================================================================
# __all__ - Explicit public API
# =============================================================================

__all__ = [
    # Types
    "InitializationStatus",
    "AutoTraceStatus", 
    "TracingConfig",
    "ObservationType",
    
    # v0.6.0: Zero-config initialization
    "auto_trace",
    "patch_langgraph",
    "unpatch_langgraph",
    "set_trace_name",
    
    # Core functions
    "traced",
    "create_traced_graph",
    
    # Initialization (RECOMMENDED: use safe_initialize)
    "safe_initialize",
    "initialize_redis_publisher",
    "close_redis_publisher",
    "disable_tracing",
    
    # Status checks
    "is_sdk_available",
    "is_tracing_initialized",
    
    # Wrappers
    "wrap_llm_adapter",
    "wrap_tools",
    
    # Constants
    "DEFAULT_TIMEOUT",
    
    # Deprecated (kept for backwards compatibility)
    "initialize_tracing",
]
