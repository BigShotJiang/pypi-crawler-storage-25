"""
Deprecated functions - kept for backward compatibility.

These functions are deprecated and will be removed in a future version.
They emit DeprecationWarning when used.

Reference: docs/plans/plan_technical_cleanup_v1.md (Phase P1)
"""

import warnings
from typing import Optional


def initialize_tracing(
    api_key: str,
    api_url: str = "https://swisperstudio.local/api/v1",
    project_id: Optional[str] = None,
) -> None:
    """
    DEPRECATED: Initialize HTTP-based tracing.
    
    Use safe_initialize() with Redis instead:
    
        # Old (deprecated):
        initialize_tracing(api_key="...", api_url="...")
        
        # New (recommended):
        await safe_initialize(
            redis_url="redis://redis:6379",
            project_id="your-project-id"
        )
    
    Args:
        api_key: API key (no longer used)
        api_url: API URL (no longer used)
        project_id: Project ID (use safe_initialize instead)
    
    Raises:
        DeprecationWarning
    """
    warnings.warn(
        "initialize_tracing() is deprecated. Use safe_initialize() with Redis instead. "
        "See https://github.com/Fintama/swisper_studio/tree/main/sdk for migration guide.",
        DeprecationWarning,
        stacklevel=2,
    )
    # Import and call the actual implementation for backward compatibility
    from .tracing.client import initialize_tracing as _init_tracing
    return _init_tracing(api_key=api_key, api_url=api_url, project_id=project_id)
