"""
Context management for tracing.

Uses contextvars to track current trace, observation, run, and agent identity.
Supports nested observations (parent-child relationships).
"""

from contextvars import ContextVar
from typing import Optional

_current_trace_id: ContextVar[Optional[str]] = ContextVar('trace_id', default=None)
_current_observation_id: ContextVar[Optional[str]] = ContextVar('observation_id', default=None)
_current_run_id: ContextVar[Optional[str]] = ContextVar('run_id', default=None)
_current_agent_name: ContextVar[Optional[str]] = ContextVar('agent_name', default=None)


def get_current_trace() -> Optional[str]:
    """Get current trace ID from context."""
    return _current_trace_id.get()


def set_current_trace(trace_id: Optional[str]) -> None:
    """Set current trace ID."""
    _current_trace_id.set(trace_id)


def get_current_observation() -> Optional[str]:
    """Get current observation ID (for nesting)."""
    return _current_observation_id.get()


def set_current_observation(obs_id: Optional[str], token=None):
    """Set current observation ID."""
    if token:
        _current_observation_id.reset(token)
    else:
        return _current_observation_id.set(obs_id)


def get_current_run_id() -> Optional[str]:
    """Get current run_id (unique per graph invocation)."""
    return _current_run_id.get()


def set_current_run_id(run_id: Optional[str]) -> None:
    """Set current run_id."""
    _current_run_id.set(run_id)


def get_current_agent_name() -> Optional[str]:
    """Get current agent name (Config Service agent_id for identity resolution)."""
    return _current_agent_name.get()


def set_current_agent_name(agent_name: Optional[str]) -> None:
    """Set current agent name."""
    _current_agent_name.set(agent_name)

