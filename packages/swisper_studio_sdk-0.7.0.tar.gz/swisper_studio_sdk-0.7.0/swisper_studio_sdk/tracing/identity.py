"""
Node identity resolution for trace enrichment.

Resolves LangGraph node names to Config Service coordinates
(agent_id, node_id, prompt_name) by reading from the in-process
ConfigServiceClient cache. Never blocks, never raises.

Spec: FEAT_003 Section 5.2
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Optional

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class NodeIdentity:
    """Authoritative Config Service coordinates for a traced node."""

    config_agent_id: Optional[str] = None
    config_node_id: Optional[str] = None
    prompt_name: Optional[str] = None
    prompt_version: Optional[int] = None
    model_name: Optional[str] = None


_EMPTY_IDENTITY = NodeIdentity()


def _get_config_client():
    """Get the shared ConfigServiceClient singleton (if available).

    Returns None if the swisper_config_service_sdk is not installed
    or the client has not been initialized (e.g., Studio SDK used
    standalone without the Swisper agent).
    """
    try:
        from swisper_config_service_sdk.client import _shared_client
        return _shared_client
    except ImportError:
        return None
    except Exception:
        return None


def resolve_node_identity(
    node_name: str,
    agent_name: Optional[str] = None,
) -> NodeIdentity:
    """Resolve a LangGraph node to its Config Service identity.

    Uses the ConfigServiceClient's in-process cache (synchronous reads,
    no network calls). Returns empty NodeIdentity on any failure.

    Args:
        node_name: The LangGraph node name (from add_node / @traced).
        agent_name: The agent name (from graph_wrapper trace_name).

    Returns:
        NodeIdentity with Config Service coordinates, or all-None fields
        if the Config Service SDK is unavailable or the node is not found.
    """
    if not agent_name:
        return _EMPTY_IDENTITY

    client = _get_config_client()
    if client is None:
        return _EMPTY_IDENTITY

    try:
        return _resolve_from_client(client, node_name, agent_name)
    except Exception as e:
        logger.debug(
            "Identity resolution failed for %s/%s: %s",
            agent_name, node_name, e,
        )
        return _EMPTY_IDENTITY


def _resolve_from_client(client, node_name: str, agent_name: str) -> NodeIdentity:
    """Resolve identity using the ConfigServiceClient's cached data."""
    prompt_id = client.get_override_prompt_id(
        agent_id=agent_name, node_id=node_name,
    )

    prompt_name: Optional[str] = None
    prompt_version: Optional[int] = None

    if prompt_id is not None:
        prompt_item = client.get_cached_prompt_by_id(prompt_id)
        if prompt_item is not None:
            prompt_name = prompt_item.name
            prompt_version = prompt_item.version

    blob = client.get_override_blob(agent_id=agent_name, node_id=node_name)
    model_name = blob.get("model") if blob else None

    return NodeIdentity(
        config_agent_id=agent_name,
        config_node_id=node_name,
        prompt_name=prompt_name,
        prompt_version=prompt_version,
        model_name=model_name,
    )
