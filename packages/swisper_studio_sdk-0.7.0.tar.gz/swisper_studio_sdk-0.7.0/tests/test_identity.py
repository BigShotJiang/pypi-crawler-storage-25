"""
Tests for NodeIdentity resolution (FEAT_003).

Tests the BUSINESS OUTCOMES:
1. When Config Service SDK is available, identity resolution returns
   correct coordinates (agent_id, node_id, prompt_name, model_name)
2. When Config Service SDK is unavailable, identity resolution returns
   empty (never crashes, never blocks)
3. When a node has no override in Config Service, returns empty

Mock boundary: ConfigServiceClient singleton (swisper_config_service_sdk).
NOT mocking: the resolve_node_identity function itself — we test its
real behavior with a mocked external dependency.

Spec: FEAT_003 Section 5.2, Requirements M1, M2, M8
"""

import pytest
from unittest.mock import MagicMock, patch
from dataclasses import dataclass

from swisper_studio_sdk.tracing.identity import (
    resolve_node_identity,
    NodeIdentity,
)


@dataclass
class FakePromptItem:
    """Minimal mock of swisper_config_service_sdk.client.PromptItem."""
    id: int
    name: str
    version: int
    content: str = ""


def _make_mock_client(
    *,
    prompt_id: int | None = None,
    prompt_item: FakePromptItem | None = None,
    override_blob: dict | None = None,
):
    """Build a mock ConfigServiceClient with the given cached data."""
    client = MagicMock()
    client.get_override_prompt_id.return_value = prompt_id
    client.get_cached_prompt_by_id.return_value = prompt_item
    client.get_override_blob.return_value = override_blob
    return client


# ============================================================================
# GOLDEN PATH: Config Service available, node has override + prompt
# Business value: SDK emits correct Config Service coordinates
# ============================================================================


class TestResolveNodeIdentityGoldenPath:

    def test_resolves_full_identity_when_override_exists(self):
        """
        Given: Config Service has override (global_supervisor, intent_classification)
               linked to prompt_id=112, prompt name "supervisor.intent-classification.intent-classification"
        When:  resolve_node_identity("intent_classification", "global_supervisor")
        Then:  returns NodeIdentity with all fields populated
        """
        prompt = FakePromptItem(
            id=112,
            name="supervisor.intent-classification.intent-classification",
            version=2,
        )
        client = _make_mock_client(
            prompt_id=112,
            prompt_item=prompt,
            override_blob={"model": "gemini-2.5-flash-lite", "temperature": "0.2"},
        )

        with patch("swisper_studio_sdk.tracing.identity._get_config_client", return_value=client):
            result = resolve_node_identity("intent_classification", "global_supervisor")

        assert result.config_agent_id == "global_supervisor"
        assert result.config_node_id == "intent_classification"
        assert result.prompt_name == "supervisor.intent-classification.intent-classification"
        assert result.prompt_version == 2
        assert result.model_name == "gemini-2.5-flash-lite"

    def test_resolves_without_prompt_when_no_prompt_linked(self):
        """
        Override exists but has no prompt_id (prompt not yet linked).
        Should still return agent/node coordinates + model name.
        """
        client = _make_mock_client(
            prompt_id=None,
            override_blob={"model": "gpt-4-turbo"},
        )

        with patch("swisper_studio_sdk.tracing.identity._get_config_client", return_value=client):
            result = resolve_node_identity("some_node", "my_agent")

        assert result.config_agent_id == "my_agent"
        assert result.config_node_id == "some_node"
        assert result.prompt_name is None
        assert result.prompt_version is None
        assert result.model_name == "gpt-4-turbo"


# ============================================================================
# FAILURE MODES: Config Service SDK unavailable
# Business value: Agent NEVER crashes, identity silently empty
# ============================================================================


class TestResolveNodeIdentityGracefulDegradation:

    def test_returns_empty_when_config_sdk_not_installed(self):
        """
        swisper_config_service_sdk is not installed (Studio SDK used standalone).
        resolve_node_identity must return empty, not raise ImportError.
        """
        with patch("swisper_studio_sdk.tracing.identity._get_config_client", return_value=None):
            result = resolve_node_identity("intent_classification", "global_supervisor")

        assert result == NodeIdentity()

    def test_returns_empty_when_agent_name_is_none(self):
        """Agent name not available (ContextVar not set). Returns empty."""
        result = resolve_node_identity("some_node", None)
        assert result == NodeIdentity()

    def test_returns_empty_when_client_raises(self):
        """Config Service client throws an exception. Returns empty, doesn't crash."""
        client = MagicMock()
        client.get_override_prompt_id.side_effect = RuntimeError("connection lost")

        with patch("swisper_studio_sdk.tracing.identity._get_config_client", return_value=client):
            result = resolve_node_identity("intent_classification", "global_supervisor")

        assert result == NodeIdentity()

    def test_returns_empty_when_no_override_exists(self):
        """Node has no override in Config Service (new node, not yet configured)."""
        client = _make_mock_client(prompt_id=None, override_blob=None)

        with patch("swisper_studio_sdk.tracing.identity._get_config_client", return_value=client):
            result = resolve_node_identity("brand_new_node", "global_supervisor")

        assert result.config_agent_id == "global_supervisor"
        assert result.config_node_id == "brand_new_node"
        assert result.prompt_name is None
        assert result.model_name is None


# ============================================================================
# INVOCATION STATUS: Store/retrieve for HITL vs new-turn discrimination
# Business value: correct run_id assignment across conversation turns
# ============================================================================


class TestInvocationStatus:

    @pytest.mark.asyncio
    async def test_store_and_retrieve_completed_status(self):
        """
        After graph completes normally, invocation_status = "completed".
        Next invocation should see this and generate a NEW run_id.
        """
        import json
        mock_redis = MagicMock()
        stored = {}

        async def mock_setex(key, ttl, value):
            stored[key] = value

        async def mock_get(key):
            return stored.get(key)

        mock_redis.setex = mock_setex
        mock_redis.get = mock_get

        with patch("swisper_studio_sdk.tracing.redis_publisher._redis_client", mock_redis), \
             patch("swisper_studio_sdk.tracing.redis_publisher._project_id", "proj-1"):

            from swisper_studio_sdk.tracing.redis_publisher import (
                store_invocation_status,
                get_invocation_status,
            )

            await store_invocation_status("thread-1", "run-aaa", "completed")
            status, run_id = await get_invocation_status("thread-1")

            assert status == "completed"
            assert run_id == "run-aaa"

    @pytest.mark.asyncio
    async def test_store_and_retrieve_interrupted_status(self):
        """
        After graph is interrupted (HITL), invocation_status = "interrupted".
        Next invocation should reuse the same run_id.
        """
        import json
        mock_redis = MagicMock()
        stored = {}

        async def mock_setex(key, ttl, value):
            stored[key] = value

        async def mock_get(key):
            return stored.get(key)

        mock_redis.setex = mock_setex
        mock_redis.get = mock_get

        with patch("swisper_studio_sdk.tracing.redis_publisher._redis_client", mock_redis), \
             patch("swisper_studio_sdk.tracing.redis_publisher._project_id", "proj-1"):

            from swisper_studio_sdk.tracing.redis_publisher import (
                store_invocation_status,
                get_invocation_status,
            )

            await store_invocation_status("thread-1", "run-bbb", "interrupted")
            status, run_id = await get_invocation_status("thread-1")

            assert status == "interrupted"
            assert run_id == "run-bbb"

    @pytest.mark.asyncio
    async def test_returns_none_when_no_status_stored(self):
        """No prior invocation for this thread. Both values are None."""
        mock_redis = MagicMock()

        async def mock_get(key):
            return None

        mock_redis.get = mock_get

        with patch("swisper_studio_sdk.tracing.redis_publisher._redis_client", mock_redis), \
             patch("swisper_studio_sdk.tracing.redis_publisher._project_id", "proj-1"):

            from swisper_studio_sdk.tracing.redis_publisher import get_invocation_status

            status, run_id = await get_invocation_status("thread-new")

            assert status is None
            assert run_id is None

    @pytest.mark.asyncio
    async def test_returns_none_when_redis_unavailable(self):
        """Redis client is None. Returns (None, None), doesn't crash."""
        with patch("swisper_studio_sdk.tracing.redis_publisher._redis_client", None):
            from swisper_studio_sdk.tracing.redis_publisher import get_invocation_status

            status, run_id = await get_invocation_status("thread-1")
            assert status is None
            assert run_id is None
