import base64

def parse_parts(parts, data_summary):
    """Recursively parses multipart message components."""
    if not parts:
        return
    for part in parts:
        mime_type = part.get('mimeType')
        body = part.get('body', {})
        if mime_type and "image" in mime_type:
            data_summary['has_images'] = True
        if mime_type == 'text/plain' and 'data' in body:
            try:
                decoded_data = base64.urlsafe_b64decode(body['data']).decode('utf-8', errors='ignore')
                data_summary['body'] += decoded_data
            except Exception:
                pass
        if 'parts' in part:
            parse_parts(part['parts'], data_summary)

def get_deep_message(service, msg_id):
    """Retrieves and standardizes full message details."""
    try:
        msg = service.users().messages().get(userId='me', id=msg_id, format='full').execute()
        payload = msg.get('payload', {})
        headers = {h['name']: h['value'] for h in payload.get('headers', [])}
        
        data_summary = {'body': "", 'has_images': False}
        if 'parts' in payload:
            parse_parts(payload['parts'], data_summary)
        elif 'body' in payload and 'data' in payload['body']:
            try:
                data_summary['body'] = base64.urlsafe_b64decode(payload['body']['data']).decode('utf-8', errors='ignore')
            except Exception:
                pass

        return {
            "id": msg_id,
            "thread_id": msg.get('threadId'),
            "envelope": {
                "from": headers.get('From'),
                "subject": headers.get('Subject'),
                "date": headers.get('Date'),
            },
            "flags": {
                "unread": "UNREAD" in msg.get('labelIds', []),
                "has_attachments": data_summary['has_images'],
                "priority_hint": "IMPORTANT" in msg.get('labelIds', [])
            },
            "content": {
                "snippet": msg.get('snippet'),
                "body": data_summary['body'].strip()
            }
        }
    except Exception:
        return None
