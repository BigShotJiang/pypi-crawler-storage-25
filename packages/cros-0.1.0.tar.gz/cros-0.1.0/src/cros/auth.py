import os.path
import sys
from rich.panel import Panel
from rich.status import Status
from rich.console import Console
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build

console = Console()
SCOPES = ['https://www.googleapis.com/auth/gmail.readonly']

# Paths for sensitive data
TOKEN_PATH = '.cros_token.json'
KEYS_PATH = 'credentials.json'

def get_service():
    """
    Authenticates the user and initializes the Gmail API service.
    
    Returns:
        tuple: (service, auth_status)
    """
    if not os.path.exists(KEYS_PATH):
        console.print(Panel(
            f"[bold red]CRITICAL ERROR: MISSING CREDENTIALS[/bold red]\n\n"
            f"The file [bold yellow]{KEYS_PATH}[/bold yellow] was not found in your current directory.\n\n"
            f"[white]Please follow the setup guide in the README to obtain your credentials from "
            f"the Google Cloud Console and place the file here.[/white]",
            title="CROS Setup Error",
            border_style="red",
            expand=False
        ))
        sys.exit(1)

    creds = None
    auth_status = 'EXISTING'
    
    if os.path.exists(TOKEN_PATH):
        creds = Credentials.from_authorized_user_file(TOKEN_PATH, SCOPES)
    
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            auth_status = 'REFRESHED'
            try:
                with Status("[bold yellow]Refreshing access token...", spinner="dots"):
                    creds.refresh(Request())
            except Exception:
                auth_status = 'NEW'
        
        if not creds or not creds.valid:
            auth_status = 'NEW'
            console.print(Panel.fit(
                "[bold #FFC107]CROS Authentication[/bold #FFC107]\n"
                "Please complete the sign-in in your browser.",
                border_style="#FFC107"
            ))
            
            flow = InstalledAppFlow.from_client_secrets_file(KEYS_PATH, SCOPES)
            creds = flow.run_local_server(port=0, success_message="Authentication Successful!")
            
        with open(TOKEN_PATH, 'w') as token_file:
            token_file.write(creds.to_json())

    service = build('gmail', 'v1', credentials=creds)
    return service, auth_status
