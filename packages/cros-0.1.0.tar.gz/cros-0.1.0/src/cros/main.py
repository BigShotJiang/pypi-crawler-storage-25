import json
import sys
import argparse
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn
from rich.prompt import Prompt

from .auth import get_service
from .schema import create_schema_object
from .fetcher import get_deep_message

console = Console()
VERSION = "0.1.0"

def run_fetcher(service=None):
    """Main entry point for the CROS CLI."""
    parser = argparse.ArgumentParser(description="CROS: Cyber Review & Orchestration System")
    parser.add_argument('--version', action='version', version=f'CROS {VERSION}')
    
    if len(sys.argv) > 1 and sys.argv[1] == '--version':
        print(f"CROS {VERSION}")
        return

    try:
        if not service:
            service, status = get_service()
        
        console.print(Panel(
            f"[bold magenta]CROS - Cyber Review & Orchestration System[/bold magenta] [dim]v{VERSION}[/dim]", 
            border_style="magenta"
        ))
        
        console.print("[magenta][1][/magenta] Today\n[magenta][2][/magenta] This Week\n[magenta][3][/magenta] Unread Only")
        
        choice = Prompt.ask("[bold blue]Select scope[/bold blue]", choices=["1", "2", "3"], show_choices=False)
        
        query_map = {"1": "newer_than:1d", "2": "newer_than:7d", "3": "is:unread newer_than:7d"}
        query = query_map[choice]

        with console.status("[bold red]Contacting Gmail API...", spinner_style="red"):
            results = service.users().messages().list(userId='me', q=query).execute()
            messages = results.get('messages', [])

        if not messages:
            console.print("[bold #FFC107]⚠ No messages matched your criteria.[/bold #FFC107]")
            return

        output_data = create_schema_object()
        
        with Progress(
            SpinnerColumn(style="light"),
            TextColumn("[dim]{task.description}"),
            BarColumn(bar_width=40, style="red", complete_style="green", finished_style="green"),
            TaskProgressColumn(style="red"),
            console=console
        ) as progress:
            fetch_task = progress.add_task(f"Siphoning {len(messages)} mails...", total=len(messages))
            
            for m_ref in messages:
                try:
                    email_obj = get_deep_message(service, m_ref['id'])
                    if email_obj:
                        output_data["emails"].append(email_obj)
                        progress.update(fetch_task, advance=1, description=f"[gray]Reading: {email_obj['envelope']['subject'][:25]}...")
                    else:
                        progress.update(fetch_task, advance=1, description="[red]Skipped corrupted mail")
                except Exception:
                    progress.update(fetch_task, advance=1, description="[red]Processing Error")

        export_path = 'cros_inbox.json'
        with open(export_path, 'w') as f:
            json.dump(output_data, f, indent=2)
        
        console.print(f"\n[bold green]✔ DEPLOYMENT READY:[/bold green] {len(output_data['emails'])} emails formatted in [bold]{export_path}[/bold]")

    except KeyboardInterrupt:
        console.print("\n[bold #FFC107]✖ Exiting CROS...[/bold #FFC107]")
        sys.exit(0)
    except Exception as e:
        console.print(f"\n[bold red]FATAL ERROR:[/bold red] {e}")
        sys.exit(1)

if __name__ == '__main__':
    run_fetcher()
