from datetime import datetime

def create_schema_object():
    """
    Initializes a standardized schema object for CROS.
    
    Returns:
        dict: Standardized "Golden Format" object.
    """
    return {
        "metadata": {
            "cros_version": "0.1.0",
            "fetch_timestamp": datetime.now().isoformat(),
        },
        "emails": []
    }
