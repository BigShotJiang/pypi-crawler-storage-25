# CROS: Cyber Review & Orchestration System

[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-magenta.svg)](https://opensource.org/licenses/MIT)
[![Gmail API](https://img.shields.io/badge/API-Gmail-red.svg)](https://developers.google.com/gmail/api)

**CROS** is a high-performance orchestration layer designed to protect and analyze your inbox through multi-agent intelligence. It siphons, standardizes, and prepares email data for deep LLM consumption, ensuring that critical communications are parsed with surgical precision for priority-based mail organization and visualization.

---

## Project Structure

```text
cros/
├── pyproject.toml        # Packaging definition
├── src/
│   └── cros/             # Source code
│       ├── auth.py       # Authentication & Security
│       ├── fetcher.py    # Gmail Parsing Logic
│       ├── schema.py     # Data Standardization
│       └── main.py       # CLI Entry Point
├── credentials.json      # (Private) Your Google API Keys
├── .cros_token.json      # (Private) Your Session Token
├── credentials.sample.json # Template for API Keys
└── .cros_token.sample.json # Template for Session Token
```

---

## Getting Started

### 1. Provision Credentials
1. Create a project in the [Google Cloud Console](https://console.cloud.google.com/).
2. Enable the **Gmail API**.
3. Create **OAuth 2.0 Desktop App** credentials.
4. Download the JSON, rename it to `credentials.json`, and place it in the root folder.
*   *Refer to `credentials.sample.json` for the expected format.*

### 2. Installation
```bash
pip install -e .
```

### 3. Usage
Run the global command from any directory:
```bash
cros
```
Or check the version:
```bash
cros --version
```

---

## Security & Git
This project is configured to ignore your real sensitive files (`credentials.json` and `.cros_token.json`) to prevent accidental leaks. Always use the `.sample.json` files for sharing templates.

---

## License
This project is licensed under the MIT License.
