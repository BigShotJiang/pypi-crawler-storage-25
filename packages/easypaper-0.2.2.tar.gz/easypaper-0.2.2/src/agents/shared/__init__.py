# Shared utilities for agents
