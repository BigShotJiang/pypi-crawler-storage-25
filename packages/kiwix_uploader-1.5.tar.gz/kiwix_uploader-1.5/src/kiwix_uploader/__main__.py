from kiwix_uploader.entrypoint import main

if __name__ == "__main__":
    main()
