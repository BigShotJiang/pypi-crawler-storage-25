from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin
from django.http import HttpResponse
from django.urls import reverse_lazy
from django.views import View
from django.views.generic.detail import DetailView
from django.views.generic.edit import CreateView

from .forms import GoodForm
from .models import Widget


def healthy(request):
    return HttpResponse("ok")


def boom(request):
    raise RuntimeError("intentional 500 for the URL smoke check")


def needs_login(request):
    if not request.user.is_authenticated:
        return HttpResponse(status=302)
    return HttpResponse("ok")


def unguarded_view(request):
    """FBV with no auth decorator — views check must flag this."""
    return HttpResponse("public by accident")


@login_required
def guarded_fbv(request):
    """FBV protected by @login_required — views check must NOT flag."""
    return HttpResponse("ok")


class GuardedCBV(LoginRequiredMixin, View):
    """CBV with LoginRequiredMixin — views check must NOT flag."""

    def get(self, request):
        return HttpResponse("ok")


class UnguardedCBV(View):
    """CBV with no guard — views check must flag."""

    def get(self, request):
        return HttpResponse("public by accident")


class WidgetDetailView(DetailView):
    """DetailView with <int:pk> — fixture for the URL kwargs generator."""

    model = Widget
    template_name = "widget_form.html"


class WidgetCreateView(CreateView):
    """Healthy CBV — post_smoke should NOT flag it."""

    model = Widget
    form_class = GoodForm
    template_name = "widget_form.html"
    success_url = "/healthy/"


class BadSaveCreateView(CreateView):
    """CBV whose save() crashes — post_smoke must flag it as critical."""

    model = Widget
    form_class = GoodForm
    template_name = "widget_form.html"
    success_url = "/healthy/"

    def form_valid(self, form):
        # Mimics the hikimatech bug: the view itself is fine but a call
        # downstream (post_save signal, related create, …) raises.
        raise RuntimeError("intentional failure inside form_valid")
