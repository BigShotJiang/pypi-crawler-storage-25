"""Regression tests for the post_smoke check.

The scenario the hikimatech bug (a post_save signal raising IntegrityError
on ``/fr/mandats/nouveau/``) is exactly ``BadSaveCreateView`` below: the
view itself answers 200 on GET, renders the form, parses the POST, reaches
``form_valid`` — and only then crashes. A GET-only check doesn't see it.
"""

import pytest

from django_doctor import Severity
from django_doctor.checks.post_smoke import PostSmokeCheck
from django_doctor.registry import Project


pytestmark = pytest.mark.django_db


def _run():
    return list(PostSmokeCheck().run(Project()))


def test_healthy_create_view_is_not_flagged():
    findings = _run()
    assert not any(
        "WidgetCreateView" in f.location and f.severity >= Severity.ERROR
        for f in findings
    ), "Healthy CreateView should not surface a critical finding"


def test_bad_save_view_is_flagged_critical():
    """post_smoke must catch the same class of bug as the hikimatech 500."""
    findings = _run()
    matching = [f for f in findings if "BadSaveCreateView" in f.location]
    assert matching, "BadSaveCreateView should have been flagged"
    assert matching[0].severity is Severity.CRITICAL
    assert "intentional failure" in matching[0].message.lower() or (
        "http 5" in matching[0].message.lower()
    )
