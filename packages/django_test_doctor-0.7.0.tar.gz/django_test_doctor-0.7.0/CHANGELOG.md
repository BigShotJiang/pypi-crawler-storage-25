# Changelog

All notable changes to django-test-doctor are documented here. The project follows
[Semantic Versioning](https://semver.org/).

## [0.7.0] — 2026-04-20

New check born directly from a production incident: altiusone hikimatech
was hitting HTTP 500 on every `POST /mandats/nouveau/` because `Mandat.save()`
did `int(last.numero.split('-')[-1])` without a try/except, and a legacy
row with numero `MAN-2026-CIB` (imported from another system) crashed
with `ValueError: invalid literal for int() with base 10: 'CIB'`. Three
other models had the same pattern (Facture, DeclarationTVA,
DeclarationFiscale). A static check would have caught all four before
deploy — here it is.

### Added

- **autogen** — new check. AST-scans every first-party model's `save()` /
  `clean()` / `full_clean()` for calls shaped like `int(<x>.split(<sep>)[<i>])`
  or `int(<x>.rsplit(<sep>)[<i>])` and flags each one whose surrounding
  code does **not** catch `ValueError` / `TypeError` / `IndexError` /
  `AttributeError` / bare `Exception`. Static only — runs in `--quick`
  mode.

### Tests

- 3 new regression tests (`test_autogen_check.py`) + fixtures
  `UnsafeAutoNumero` (flagged) and `SafeAutoNumero` (try/except → not
  flagged). Total 55 tests.

### Docs

- New `checks/autogen.md` with the motivating altiusone/hikimatech story,
  two recommended fixes (regex filter vs. try/except), and scope notes.

## [0.6.0] — 2026-04-20

Two new checks, an HTML reporter, diff-aware filtering, and the URL kwargs
fixture that unlocks the `urls` and `post_smoke` checks on detail/edit routes.

### Added

- **templates** — new check. Walks every first-party template and flags
  `{% url 'name' %}` references whose name isn't registered in the
  resolver, `{% static 'path' %}` references whose path no staticfiles
  finder resolves, and `TemplateSyntaxError` at load time. Catches the
  class of bug where a rename misses a template and `NoReverseMatch` only
  surfaces in prod when a user hits the page.
- **views** — new check. Flags first-party views that appear to be public
  by accident — no `LoginRequiredMixin` / `PermissionRequiredMixin` /
  `UserPassesTestMixin` in the CBV MRO, no `@login_required` /
  `@permission_required` decorator on the FBV, no DRF
  `permission_classes = [IsAuthenticated, ...]`. Whitelist legitimate
  public endpoints (login, signup, health) under
  `[tool.django-doctor.views].public`; defaults already cover the common
  ones.
- **HTML reporter** — `--html <path>` writes a standalone self-contained
  HTML page (inline CSS, no JS dependencies, collapsible per-check
  sections) suitable for CI artifacts and email.
- **`--diff <ref>`** — only show findings whose `location` touches a file
  changed since `<ref>`. Combines committed changes, unstaged modifications,
  and untracked files. Findings with no resolvable file path (e.g. URL
  names) are kept visible — we'd rather over-report than silently drop.
- **URL kwargs fixture** — `make_url_kwargs(route, view_cls)` generates
  kwargs for `<int:pk>` / `<uuid:id>` / `<slug:slug>` converters. For
  model-backed CBVs (`DetailView`, `UpdateView`, …) it picks `qs.first()`
  or creates a minimal row; elsewhere it falls back to a typed literal.
  The `urls` and `post_smoke` checks now probe detail and edit URLs that
  used to be skipped.

### Tests

- 22 new regression tests across `test_templates_check.py`,
  `test_views_check.py`, `test_html_reporter.py`,
  `test_url_kwargs_fixture.py`, and `test_diff_mode.py`. Total 52 tests.
- New sample-app fixtures: guarded / unguarded FBVs and CBVs, a
  `WidgetDetailView` for URL-kwarg generation, broken and valid `.html`
  templates for the template checker.
- `django.contrib.staticfiles` is now in the test `INSTALLED_APPS` so the
  staticfiles resolver is correctly wired for the templates test.

## [0.5.1] — 2026-04-20

### Docs

- README.md intro now surfaces the docs site URL directly so PyPI visitors
  see the link on the landing page without scrolling to the sidebar.

## [0.5.0] — 2026-04-20

### Added

- **forms_meta** — new check. Statically analyzes every first-party
  `ModelForm`'s `clean()` / `clean_<field>()` methods via `ast` and flags
  every `cleaned_data[<key>]` assignment where `<key>` is a NOT-NULL model
  column, absent from `Meta.fields`, not declared on the form, and the form
  has no `save()` override. This is exactly the shape of the
  `OperationTVAForm.montant_ttc` bug that motivated the check: Django
  silently drops orphan `cleaned_data` keys, the next `.save()` raises
  `IntegrityError` on a NOT NULL column.

### Tests

- 3 new regression tests (`test_forms_meta_check.py`) + fixtures
  `OrphanCleanedDataForm` (flagged) and `OrphanCleanedDataWithSaveOverrideForm`
  (not flagged). Total 30 tests.

### Docs

- README.md refreshed — ten layers table, motivating bug examples (forms /
  post_smoke / forms_meta), expanded configuration reference, `make_form_fixture`
  helper documented.
- `pyproject.toml` `description` updated to advertise the new POST smoke +
  orphan `cleaned_data` checks.

## [0.4.0] — 2026-04-20

Closes the `urls`-check gap. A user reported a real-world HTTP 500 on
`/fr/mandats/nouveau/` (a `post_save` signal crashing with `IntegrityError`)
that slipped past the full 0.3.0 audit, because `urls` only probes GET.

### Added

- **post_smoke** — new check. Discovers every `CreateView` / `UpdateView` in
  the URL resolver, auto-generates a minimal valid POST payload from
  `form_class` (or `model + fields`), submits it as a superuser, and fails
  critical on any HTTP 5xx. Each POST runs inside `transaction.atomic()` +
  `savepoint_rollback`, so the database is **not** mutated even when the
  view reaches `.save()`.
- **`django_doctor.fixtures`** — public helper `make_form_fixture(form_cls)`
  that returns a minimal dict of form-ready values for every required
  field. Supports `CharField`, `IntegerField`, `DecimalField`,
  `BooleanField`, `DateField`, `DateTimeField`, `EmailField`, `URLField`,
  `ChoiceField` (skips the empty option), `ModelChoiceField` (picks
  `qs.first()`), `ModelMultipleChoiceField`, typed choice fields, multiple
  choices. Returns `_SKIP` for fields it can't fill (files, images,
  querysets with no rows) and the check reports a partial fixture.

### Tests

- 2 new regression tests (`test_post_smoke_check.py`) + `BadSaveCreateView`
  fixture reproducing exactly the hikimatech scenario. Total 27 tests.

### Notes on scope

Requires a writable dev/test database. Wraps every probe in a savepoint
that's always rolled back, so it's safe to run against a dev snapshot of
production — but **do not** run against live production.

## [0.3.0] — 2026-04-20

### Added

- **drf** — new check: iterates every `Serializer` / `ModelSerializer` in
  first-party apps and:
  - blank-instantiates each one (same signal as the `forms` check, but for
    the API layer) — catches serializers whose `__init__` crashes;
  - validates that every entry in `Meta.fields` either maps to a real field
    on `Meta.model` or is declared on the serializer class — catches typos
    that DRF only raises at render time;
  - downgrades "missing required kwargs" to INFO, consistent with the `forms`
    check behaviour.
  Skipped silently if `djangorestframework` is not installed.

### Fixed

- **urls** — the Django test client ships requests with `Host: testserver`,
  which a typical production `ALLOWED_HOSTS` rejects. The check now wraps
  its probes in `override_settings(ALLOWED_HOSTS=[..., "testserver", "*"])`
  so every URL is reachable regardless of the deployed host config.

### Tests

- 3 new tests (`test_drf_check.py`) + sample DRF fixtures. Total 25 tests.

## [0.2.2] — 2026-04-20

Correctness pass — the 0.2.1 `migrations` check produced drift findings
(`AlterField`, `AlterModelOptions`) that `./manage.py makemigrations --check
--dry-run` did not. Reimplementing `MigrationAutodetector` in-house diverged
from the official command's verdict, which is the ground truth users compare
against.

### Fixed

- **migrations** — now delegates to `call_command("makemigrations",
  dry_run=True, check_changes=False)` and parses its stdout for
  `"Migrations for 'app':"` lines. Byte-for-byte parity with the CLI verdict.
  No more phantom drift on apps whose migrations are fully up to date.
- **forms** — dedupe: a form reachable through multiple app walks (re-exports,
  shared `__init__` shims) was probed N times, producing N duplicate findings.
  Now probed once.

### Tests

- 2 new tests: `test_form_is_not_double_reported`,
  `test_drift_detection_matches_makemigrations_verdict`. Total 22 tests.

## [0.2.1] — 2026-04-20

Noise reduction pass — surfaced by running 0.2.0 against a real Django project
(altiusone, 16 apps, ~150 forms, heavy use of modeltranslation) where the
`forms` and `migrations` checks emitted ~30 actionable-looking findings that
were in fact structural, not bugs.

### Fixed

- **forms** — a form whose `__init__` requires extra arguments (Django's
  `SetPasswordForm` needs `user=`, `AuthenticationForm` needs `request=`,
  user-defined variants with required kwargs) is now surfaced as **INFO** with
  rule `forms.blank_init.needs_args` instead of **ERROR**. Real `__init__`
  bugs (AttributeError on `field.choices`, NameError, …) still surface as
  ERROR. This removes the CI block without losing coverage.
- **migrations** — by default, only first-party apps (outside site-packages)
  are inspected for drift. Contrib apps (`auth`, `admin`, `contenttypes`,
  `sessions`, …) and third-party packages are skipped because the user can't
  fix drift there anyway. Override via `[tool.django-doctor.migrations]
  include_third_party = true`. Extra explicit skips via `skip_apps = [...]`.

### Tests

- 4 new regression tests: missing-args form → INFO (not ERROR), first-party
  detection correctness, contrib apps never leak into migrations findings.
  Total 20 tests, all green.

## [0.2.0] — 2026-04-20

**Renamed** — distribution moves from `django-doctor` to `django-test-doctor`
(the former name is taken on PyPI). The importable Python module stays
`django_doctor`, so existing code keeps working after `pip install django-test-doctor`.

### Added

- **admin** — walks `admin.site._registry` and flags `list_display`,
  `list_filter`, `search_fields` and `ordering` entries that do not resolve
  to a real field or callable on the model or ModelAdmin. Catches the typo
  class of bug that silently breaks admin list pages until someone opens them.
- **models** — flags every first-party, non-abstract model that:
  - has no custom `__str__` (defaults to ugly generic repr in admin/shell/logs);
  - has no `Meta.ordering` (pagination becomes order-dependent);
  - declares `on_delete=SET_NULL` on a FK whose column is `NOT NULL`
    (silent `IntegrityError` waiting for the first parent deletion).
- **security** — runs Django's deployment check tag + flags weak
  `SECRET_KEY` substrings (`django-insecure`, `changeme`, `secret`, …),
  short keys (< 32 chars), `DEBUG=True`, and empty `ALLOWED_HOSTS` in production.

### Tests

- 11 new regression tests across `admin`, `models`, and `security`. Total now
  16 tests, all green.

## [0.1.0] — Unreleased

Initial alpha (internal — never published to PyPI under the old name). Four
layers shipped:

- **system** — wraps Django's built-in `check` framework with rich output.
- **urls** — crawls `urlpatterns`, probes each URL as `anonymous / authenticated /
  staff / superuser`, fails on 5xx. Skips URLs that need kwargs for now
  (fixtures layer lands in 0.3).
- **forms** — instantiates every `Form` / `ModelForm` blank and with `data={}`.
  Catches the `CharField.choices` family of `__init__` bugs that motivated
  the package.
- **migrations** — detects unapplied migrations and model changes without a
  matching migration file.

Infrastructure:

- Plugin registry via the `django_doctor.checks` entry point group — any
  PyPI package can contribute checks.
- Config loaded from the host project's `pyproject.toml` under
  `[tool.django-doctor]`.
- Rich terminal reporter. JSON exporter included.
- `./manage.py doctor` management command with `--section`, `--quick`, `--ci`,
  `--json` flags.

## Roadmap

- **0.7**: `i18n` (untranslated msgid, stale .mo vs .po), `static`
  (collectstatic dry-run drift), `--fix` (auto-rewrites for mechanical
  findings), `--watch`, incremental cache keyed by `git diff` between runs.
