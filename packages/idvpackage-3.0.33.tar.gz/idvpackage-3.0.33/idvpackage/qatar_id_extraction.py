

import logging
import time
import json
from typing import Literal
from openai import OpenAI
from pydantic import BaseModel, Field


logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(filename)s:%(lineno)d - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S',
    force=True
)





ON_SCREEN_VS_PHYSICAL_PROMPT = """

ROUTINE: Determine Whether Image is On-Screen or a Physical Card

OVERVIEW:
Use a hierarchy-based approach. Prioritize exclusive on-screen indicators first.
Do not classify as physical based on weak or shared indicators such as minor perspective distortion or slight lighting variation.

--------------------------------------------------

STEP 1 — Detect Exclusive On-Screen Indicators (High Priority)

Examine the image for indicators strongly associated with photographed digital displays, including:

1A i: **If ANY moiré patterns or pixel grid artifacts are visible**:
→ IMMEDIATELY classify as: screen
→ STOP. Do not evaluate physical indicators. Proceed to STEP 3.

1A ii: **If ANY signs of LCD Backlight are visible**:
→ IMMEDIATELY classify as: screen
→ STOP. Do not evaluate physical indicators. Proceed to STEP 3.


1B: OTHERWISE, analyze for the following indicators:
- **moiré patterns or pixel grid artifacts are visible
- ** Subpixel structure or vertical scan lines
- ** Uniform LCD/LED backlight glow
- ** Screen refresh artifacts
- ** Visible device bezels or monitor frame
- ** UI overlays (status bar, battery, time, app UI, cursor)
- ** Glass reflections consistent with flat displays
- ** Perfect edge-to-edge digital framing with no measurable depth
- ** A shadow only counts as a physical indicator if it is cast onto a visible environmental surface (table, fabric, hand, etc.) with measurable depth separation.
- ** A uniform gray gradient background without surface texture is NOT environmental context.
- ** Rounded corners and drop shadows embedded in the graphic design do NOT indicate physical depth.


If ANY of the above indicators are clearly present:
→ Classify the image as: screen
→ STOP. Do not continue to physical-card analysis. Proceed to STEP 3.

--------------------------------------------------

STEP 2 — Detect Strong Physical-Card Indicators

Only evaluate this step if NO strong on-screen indicators were detected.

Look for TRUE physical depth evidence, including:

- ** Clearly visible card thickness or layered edge
- ** Card casting a shadow onto a real surface
- ** Surface texture (matte grain, gloss highlights, wear marks, scratches)
- ** Environmental background (table, hand holding card, fabric, etc.)
- ** Depth-of-field blur separating card from background
- ** Slight corner bending, warping, or physical imperfections
- ** Uneven lighting across the card consistent with a 3D object

**IMPORTANT**:
The following do NOT count as strong physical indicators:
- ** Slight perspective skew
- ** Minor lighting variation
- ** Camera softness
- ** Dark background without visible surface
- ** Cropping shadows
- ** General evidence that the image was photographed
- **Textured backgrounds that could be digital wallpaper (fabric, wood grain, etc.) 
  WITHOUT visible depth separation or card-to-surface interaction**


If TWO OR MORE strong physical indicators are clearly present:
→ Classify the image as: physical
→ STOP. Proceed to STEP 3.

--------------------------------------------------

STEP 3 — Conflict Resolution

If both screen and physical indicators appear:

- ** If moiré, pixel grid artifacts, or LCD backlight glow are present → classify as: screen
- ** If visible card thickness AND environmental surface interaction are present → classify as: physical
- ** If uncertainty remains → default to: screen

--------------------------------------------------

FINAL OUTPUT:

If On-Screen Digital Image:
return the word "screen" only.

If Physical Card:
return the word "physical" only.


"""

PROMPT_FRONT = """
You are an expert identity document parser.

You are given OCR output from the **front side** of a Qatar National ID card or Residency Permit,
along with extracted words and their confidence scores (0.0 to 1.0).

**OCR Text**
{extracted_text}

**OCR Words with Confidence Scores**
{word_conf_dict2}

---

## CARD LAYOUT — READ THIS FIRST

Two front-side card types exist. Both use a **two-column bilingual layout**:

**Residency Permit front:**
- **LEFT column**: `ID.No:`, `D.O.B.:`, `Expiry:`, `Nationality:`, `Occupation:`, `Name:`
- **RIGHT column**: `الرقم الشخصي`, `تاريخ الميلاد`, `الصلاحية`, `الجنسية`, `المهنة`, `الاسم`
- **Header (top-left)**: `State of Qatar` + `Residency Permit` / **Header (top-right)**: `دولة قطر` + `رخصة إقامة`

**National ID front:**
- **LEFT column**: `ID.No:`, `D.O.B.:`, `Nationality:`, `Date of expiry:`, `Name:`  ← note "Date of expiry" label; **NO Occupation field**
- **RIGHT column**: `الرقم الشخصي`, `تاريخ الميلاد`, `الجنسية`, `الصلاحية`, `الاسم`
- **Header (top-left)**: `State of Qatar` + `ID. Card` / **Header (top-right)**: `دولة قطر` + `بطاقة إثبات شخصية`

The OCR engine reads the card row-by-row across both columns. OCR text sequence does NOT guarantee English and Arabic labels appear as neat pairs — Arabic header text may appear interleaved with English field labels.

**CRITICAL CONSEQUENCE:** The token(s) immediately after `Occupation:` in the OCR sequence MAY be Arabic header words (`دولة قطر`, `رخصة إقامة`) due to this layout — these are NEVER the occupation value.

---

## ⚠️ CRITICAL: ZERO TOLERANCE FOR HALLUCINATION ⚠️

**YOU MUST ONLY USE EXACT WORDS FROM THE "OCR Words with Confidence Scores" SECTION ABOVE.**

**EXCEPTION — Translation only:** `occupation_en` is a **plain string** (NOT a FieldResult object) generated as the QNOC standard English job title of the Arabic value in `occupation_ar`. This is EXPLICITLY PERMITTED. `nationality_iso` is a **plain string** ISO 3166-1 alpha-3 code derived from `nationality.value`. This is also EXPLICITLY PERMITTED. All other fields must use exact OCR words only.

- DO NOT reconstruct partial words (e.g., "AKISTAN" + "Nationali" ≠ "PAKISTAN")
- DO NOT infer missing characters or complete incomplete words
- DO NOT use domain knowledge to "fix" OCR errors
- If a word is fragmented, truncated, or incomplete → treat as UNREADABLE

**EMPTY INPUT SAFETY RULE (MUST):**
- If OCR text is empty AND OCR words/confidence dictionary is empty → return all fields as empty, `is_blurred=true`, `blurriness_level="high"`, `blurriness_reason="No OCR content extracted"`

**FORBIDDEN INFERENCE EXAMPLES:**
- OCR has "AKISTAN" → DO NOT infer "PAKISTAN"
- OCR has "Nationali" → DO NOT infer "Nationality"
- OCR has "15:47" + "88" → DO NOT infer "15/07/1988"
- OCR sequence has `Occupation:` then `دولة قطر` → DO NOT use `دولة قطر` as occupation; return value: ""
- OCR sequence has `Date of expiry:` then `ID. Card` → DO NOT use `ID. Card` as expiry; return value: ""

---

## ⚠️ ALL FIELDS ARE CRITICAL ⚠️
- FieldResult fields: id_number, dob, expiry_date, name, name_ar, first_name, last_name, nationality, occupation_ar
- Plain string: occupation_en (derived translation — no FieldResult wrapper)
- **English fields** (id_number, dob, expiry_date, name, first_name, last_name, nationality): key_conf ≥ 0.70 and value_conf ≥ 0.85
- **Arabic fields** (name_ar, occupation_ar): key_conf ≥ 0.50 and value_conf ≥ 0.60

---

## RULES — follow exactly

### 1. Field Keys
Do NOT rename, abbreviate, add or remove any key:
  id_number | dob | expiry_date | name | name_ar | first_name | last_name
  nationality | occupation_ar
  occupation_en | nationality_iso (plain strings — NOT FieldResult)
  card_type | header_verified | is_blurred | blurriness_level | blurriness_reason

### 2. Per-Field Object Structure

**HARD GATING RULE (MUST FOLLOW):**
- A field can be extracted ONLY if its own key label token is present in OCR words.
- Do NOT extract from standalone/unlabeled values.
- **VALUE SOURCE RULE:** For each field, the value must come from the tokens that the OCR places immediately after that field's key label. Do NOT use tokens that belong to a different label's row.
- **FORBIDDEN VALUE WORDS:** `State of Qatar`, `Residency Permit`, `ID. Card`, `ID Card`, `دولة قطر`, `رخصة إقامة`, `رخصة`, `إقامة`, `بطاقة إثبات شخصية`, `بطاقة` are header words and MUST NEVER be returned as any field value. If the only tokens after a label are these words → return value: "".
- If key label is missing for a field:
    - set `value` to ""
    - set `key_conf` to `0.0`
    - set `value_conf` to `0.0`
    - set `blurry` to `false`
    - set `reason` to ""
- Never assign non-zero `key_conf` when key label token is absent.

For EVERY data field return an object with exactly these sub-keys:
  - `value`      : extracted string; empty string "" if not found or any token conf < 0.5
  - `key_conf`   : **MINIMUM** confidence across ALL present label tokens for this field
                   (when both English and Arabic labels present: key_conf = min of both)
                   ignore any ":" token; round to 4 decimal places
  - `value_conf` : avg confidence of the value tokens; ignore ":" tokens; round to 4 decimal places
  - `blurry`     : use the threshold that matches the field type:
                   **English fields** (id_number, dob, expiry_date, name, first_name, last_name, nationality): true if key_conf < 0.70 OR value_conf < 0.85
                   **Arabic fields** (name_ar, occupation_ar): true if key_conf < 0.50 OR value_conf < 0.60
  - `reason`     : state the failing threshold with actual value, e.g. "key_conf 0.65 < 0.70" or "value_conf 0.55 < 0.60"; else ""

### 3. Field-by-Field Extraction Rules

**`card_type`** (plain string, NOT FieldResult):
- "residency_permit" if `Residency Permit` or `رخصة إقامة` appears in OCR
- "national_id" if `ID. Card` or `ID Card` or `بطاقة إثبات شخصية` appears in OCR (with no residency permit words); OR if `State of Qatar` / `دولة قطر` appears with no residency permit words and no occupation labels
- "unknown" if neither

**`id_number`**:
- Key label: `ID.No` (English, left column) OR `الرقم الشخصي` (Arabic, right column)
- Value: numeric digits exactly as printed
- key_conf = min of all present label token confs

**`dob`**:
- Key label: `D.O.B` / `D.O.B.` / `DOB` (English) OR `تاريخ الميلاد` (Arabic)
- Value: date in DD/MM/YYYY only; if OCR value exists but is NOT in DD/MM/YYYY format → value: "", blurry: true, reason: "invalid date format"

**`expiry_date`**:
- Key label: `Expiry` OR `Date of expiry` (English — both appear depending on card type) OR `الصلاحية` (Arabic)
- Value: date in DD/MM/YYYY only; if OCR value exists but is NOT in DD/MM/YYYY format → value: "", blurry: true, reason: "invalid date format"

**`nationality`**:
- Key label: `Nationality` (English) OR `الجنسية` (Arabic)
- Value: ALWAYS Latin characters — the English nationality word as printed (e.g., THAILAND, PHILIPPINE, INDIAN)
- The Arabic script nationality (e.g., تایلاند) appears in OCR near `الجنسية` but is NOT returned as the value
- If only Arabic script found after both labels → return value: ""
- key_conf = min("Nationality" conf, "الجنسية" conf) if both present

**`nationality_iso`** (plain string — NOT a FieldResult object):
- ISO 3166-1 alpha-3 code derived from `nationality.value` (e.g., INDIAN → IND, PHILIPPINE → PHL, THAI → THA, PAKISTANI → PAK, NEPALI → NPL, EGYPTIAN → EGY)
- ⚠ EXPLICIT EXCEPTION: you MAY generate this from your knowledge of ISO codes
- "" if nationality.value is ""

**`occupation_ar`**:
- ⚠ **National ID has NO occupation field — if card_type is "national_id" → value: "", key_conf: 0.0, value_conf: 0.0, blurry: false, reason: ""**
- Key label: **USE `المهنة` (Arabic label) as the primary value source**
- The Arabic occupation value appears in the OCR AFTER the `المهنة` token — extract that Arabic text
- The English `Occupation:` label confirms the field exists but its adjacent OCR tokens may be corrupted by the two-column layout (header words) — do NOT use tokens after `Occupation:` as the value
- If `المهنة` is absent → set all to empty/0.0/false
- ⚠ FORBIDDEN: any header words (دولة قطر, رخصة إقامة, etc.) as value
- key_conf = min("Occupation" conf, "المهنة" conf) — if both present use the lower one
- value_conf = avg of the Arabic occupation value tokens following `المهنة`
- ⚠ **LOWER THRESHOLD:** blurry = true if key_conf < 0.50 OR value_conf < 0.60 (not the standard 0.70/0.85)
- reason: "key_conf X < 0.50" or "value_conf X < 0.60" if blurry; else ""

**`occupation_en`** (plain string — NOT a FieldResult object):
- ⚠ **National ID has NO occupation field — if card_type is "national_id" → ""**
- Translate `occupation_ar.value` to standard QNOC English job title
- ⚠ EXPLICIT EXCEPTION: you MAY generate this translation
- ⚠ DO NOT phonetically romanize — use actual English job title (e.g., معرضة → Exhibitor/Promoter, مهندس → Engineer)
- ⚠ If occupation_ar.value is "" → ""
- Return ONLY the translated string, NOT an object with value/key_conf/value_conf/blurry/reason

**`name_ar`**:
- Key label: `الاسم` OR `الإسم` (both spellings appear on cards)
- Value: full Arabic name as printed after the label
- ⚠ **LOWER THRESHOLD:** blurry = true if key_conf < 0.50 OR value_conf < 0.60 (not the standard 0.70/0.85)
- reason: "key_conf X < 0.50" or "value_conf X < 0.60" if blurry; else ""

**`name`**:
- Key label: `Name`
- Value: full English name as printed after the label

**`first_name`**: first word of `name.value` (no separate card label)
**`last_name`**: last word of `name.value` (no separate card label)

**`header_verified`** (boolean) — True ONLY if ALL required header words AND field labels for the detected card type are present in OCR:

  FOR **residency_permit** — ALL of the following must be present:
    **Header words:**
    1. `State of Qatar` OR `State Of Qatar`
    2. AND `Residency Permit`
    3. AND `دولة قطر`
    4. AND `رخصة إقامة`
    **English field labels:**
    5. AND `ID.No` OR `ID. No`
    6. AND `D.O.B` OR `D.O.B.` OR `DOB`
    7. AND `Expiry`
    8. AND `Nationality`
    9. AND `Occupation`
    10. AND `Name`
    **Arabic field labels:**
    11. AND `الرقم الشخصي`
    12. AND `تاريخ الميلاد`
    13. AND `الصلاحية`
    14. AND `الجنسية`
    15. AND `المهنة`
    16. AND `الاسم` OR `الإسم`

  FOR **national_id** — ALL of the following must be present:
    **Header words:**
    1. `State of Qatar` OR `State Of Qatar`
    2. AND `ID. Card` OR `ID Card`
    3. AND `دولة قطر`
    4. AND `بطاقة إثبات شخصية`
    **English field labels:**
    5. AND `ID.No` OR `ID. No`
    6. AND `D.O.B` OR `D.O.B.` OR `DOB`
    7. AND `Nationality`
    8. AND `Date of expiry`
    9. AND `Name`
    **Arabic field labels:**
    10. AND `الرقم الشخصي`
    11. AND `تاريخ الميلاد`
    12. AND `الجنسية`
    13. AND `الصلاحية`
    14. AND `الاسم` OR `الإسم`

  FOR **unknown** — header_verified MUST be false.

### 4. Date Format Validation — DD/MM/YYYY (STRICT)
- The required pattern is: exactly 2-digit day, `/`, 2-digit month, `/`, 4-digit year — nothing more, nothing less
- ✅ VALID examples (do NOT flag these): `14/12/1991`, `01/08/2023`, `18/02/2035`, `03/06/2026`
- ❌ INVALID examples (flag these): `3/06/2026` (single-digit day — missing leading zero), `15/10/23` (2-digit year), `15.10.2026` (dot separator), `2026/06/03` (wrong order)
- **A date with two-digit day, two-digit month, and four-digit year separated by `/` is ALWAYS valid — do NOT flag it.**
- If OCR contains a date value that does NOT match the pattern above:
  → set value: ""
  → set blurry: true
  → set reason: "invalid date format (got: <original OCR token>)"
- If no date token is found at all → value: "", blurry determined by confidence thresholds only

### 5. Overall Blurriness Assessment

**Step A — Empty-field check (run FIRST):**
- **residency_permit**: count these 7 fields: id_number, dob, expiry_date, name, name_ar, nationality, occupation_ar
  (occupation_en is a derived plain string — do NOT count it)
  - If 4 or more empty → is_blurred: true, blurriness_level: "high", blurriness_reason: "Most fields are empty — document unreadable or OCR failed" — STOP
- **national_id**: count these 6 fields: id_number, dob, expiry_date, name, name_ar, nationality
  (occupation_ar and occupation_en are ALWAYS empty on national_id — do NOT count them)
  - If 4 or more empty → is_blurred: true, blurriness_level: "high", blurriness_reason: "Most fields are empty — document unreadable or OCR failed" — STOP
- **unknown**: count these 6 fields: id_number, dob, expiry_date, name, name_ar, nationality
  - If 4 or more empty → is_blurred: true, blurriness_level: "high", blurriness_reason: "Most fields are empty — document unreadable or OCR failed" — STOP

**Step B — Blurry-field count:**
- `"none"`: 0 blurry → is_blurred: false, blurriness_reason: ""
- `"low"`: 1 blurry → is_blurred: true
- `"medium"`: 2–3 blurry → is_blurred: true
- `"high"`: 4+ blurry → is_blurred: true
- blurriness_reason: comma-separated field names where blurry is true

Return ONLY a valid JSON object. No extra text, no markdown, no code fences.
"""

PROMPT_BACK = """
You are an expert identity document parser specialising in Qatar Residency Permits and National ID cards.

You are given OCR output from the **back side** of a Qatar card,
along with extracted words and their confidence scores (0.0 to 1.0).

**OCR Text**
{extracted_text}

**OCR Words with Confidence Scores**
{word_conf_dict2}

---

## CARD LAYOUT — READ THIS FIRST

Two back-side card types exist. Both use a **two-column bilingual layout**:

**Residency Permit back:**
- LEFT column (English labels + values): `Passport Number:`, `Passport Expiry:`, `Residency Type:`, `Employer:`, `Serial No:`
- RIGHT column (Arabic labels + values): `رقم جواز السفر:`, `تاريخ انتهاءالجواز:`, `نوع الرخصة:`, `المستقدم:`, `الرقم المسلسل:`
- BOTTOM: Arabic `مدير عام الإدارة العامة للجوازات` + English `General Director of the General Directorate of Passports` + `Holder's signature`

**National ID back:**
- LEFT column: `Serial No:`
- RIGHT column: `الرقم المسلسل:`, `العنوان:` (address)
- BOTTOM: Arabic `مدير إدارة الجنسية و وثائق السفر` + `Authority's signature` (left) + `توقيع حامل البطاقة` + `Holder's signature` (right)

The OCR reads row-by-row across both columns. English and Arabic tokens for the SAME field appear in the OCR near each other but not always adjacent.

---

## ⚠️ CRITICAL: ZERO TOLERANCE FOR HALLUCINATION ⚠️

**YOU MUST ONLY USE EXACT WORDS FROM THE "OCR Words with Confidence Scores" SECTION ABOVE.**

**EXCEPTIONS — Translation fields (EXPLICITLY PERMITTED):**
- `employer_en`: translate `employer_ar.value` to meaningful English — you MAY generate this
- `residency_type_en`: translate `residency_type_ar.value` to English — you MAY generate this
- `address_en`: translate `address_ar.value` to English — you MAY generate this
All other fields must use exact OCR words only.

**EMPTY INPUT SAFETY RULE:**
- If OCR text and word dictionary are both empty → all fields empty, card_type: "unknown", back_header_verified: false, is_blurred: true, blurriness_level: "high", blurriness_reason: "No OCR content extracted"

---

## RULES — follow exactly

### 1. Field Keys
Do NOT rename, abbreviate, add or remove any key:
    card_type
    passport_number | passport_expiry | serial_number
    residency_type_ar | employer_ar | address_ar
    residency_type_en | employer_en | address_en | employer | residency_type | address
    (residency_type_en, employer_en, address_en, employer, residency_type, address are plain strings — NOT FieldResult objects)
    back_header_verified | is_blurred | blurriness_level | blurriness_reason

### 2. Per-Field Object Structure

**HARD GATING RULE (MUST FOLLOW):**
- A field can be extracted ONLY if its own key label token is present in OCR words.
- Do NOT extract from standalone/unlabeled values.
- **FORBIDDEN VALUE WORDS:** `State of Qatar`, `Residency Permit`, `دولة قطر`, `رخصة إقامة`, `رخصة`, `إقامة` MUST NEVER be a field value. If the only available tokens are these → return value: "".
- If key label is missing for a field: value: "", key_conf: 0.0, value_conf: 0.0, blurry: false, reason: ""
- Never assign non-zero key_conf when key label token is absent.

For EVERY FieldResult field return an object with exactly these sub-keys:
  - `value`      : extracted string; "" if not found or any token conf < 0.5
  - `key_conf`   : **MINIMUM** confidence across ALL present label tokens for this field
                   (when English + Arabic label both present: key_conf = min of both)
                   ignore ":" tokens; round to 4 decimal places
  - `value_conf` : avg confidence of value tokens; ignore ":"; round to 4 decimal places
  - `blurry`     : use the threshold that matches the field type:
                   **English fields** (passport_number, passport_expiry, serial_number): true if key_conf < 0.70 OR value_conf < 0.85
                   **Arabic fields** (residency_type_ar, employer_ar, address_ar): true if key_conf < 0.50 OR value_conf < 0.60
  - `reason`     : state the failing threshold with actual value, e.g. "key_conf 0.65 < 0.70" or "value_conf 0.55 < 0.60"; else ""

### 3. Card Type Detection (run FIRST)

**`card_type`** (plain string, NOT FieldResult):
- **"residency_permit"**: OCR contains `Passport Number` or `رقم جواز السفر` or `Passport Expiry` or `تاريخ انتهاءالجواز`
- **"national_id"**: OCR contains `العنوان` and NO passport fields
- **"unknown"**: neither detected

### 4. Field-by-Field Extraction Rules

**`passport_number`** (⚠ always empty for national_id):
- Key label: `Passport Number` (English) OR `رقم جواز السفر` (Arabic)
- Value: alphanumeric exactly as printed (e.g., I495320)
- key_conf = min of all present label confs

**`passport_expiry`** (⚠ always empty for national_id):
- Key label: `Passport Expiry` (English) OR `تاريخ انتهاءالجواز` (Arabic, note: may appear as one token without space)
- Value: date in DD/MM/YYYY only; if OCR value exists but is NOT in DD/MM/YYYY format → value: "", blurry: true, reason: "invalid date format"
- key_conf = min of all present label confs

**`serial_number`** (present on both card types):
- Key label: `Serial No` (English) OR `الرقم المسلسل` (Arabic)
- Value: exactly as printed, preserve all letters and digits (e.g., 4364590A4820247E)
- key_conf = min of all present label confs

**`residency_type_ar`** (⚠ always empty for national_id):
- Key label: `Residency Type` (English) OR `نوع الرخصة` (Arabic)
- Value: Arabic residency type word(s) exactly as printed (e.g., عمل)
- key_conf = min of all present label confs
- ⚠ **ARABIC FIELD THRESHOLD:** blurry = true if key_conf < 0.50 OR value_conf < 0.60
- reason: "key_conf X < 0.50" or "value_conf X < 0.60" if blurry; else ""

**`employer_ar`** (⚠ always empty for national_id):
- Key label: `Employer` (English) OR `المستقدم` (Arabic)
- Value: Arabic employer name exactly as printed
- key_conf = min of all present label confs
- ⚠ **ARABIC FIELD THRESHOLD:** blurry = true if key_conf < 0.50 OR value_conf < 0.60
- reason: "key_conf X < 0.50" or "value_conf X < 0.60" if blurry; else ""

**`address_ar`** (⚠ always empty for residency_permit):
- Key label: `العنوان` (Arabic only field, national_id back only)
- Value: Arabic address exactly as printed
- ⚠ **ARABIC FIELD THRESHOLD:** blurry = true if key_conf < 0.50 OR value_conf < 0.60
- reason: "key_conf X < 0.50" or "value_conf X < 0.60" if blurry; else ""

**Plain strings (NOT FieldResult — return as bare strings, not objects):**
⚠ EXPLICIT EXCEPTION — you MAY generate the translations below
- `residency_type_en`= translate residency_type_ar.value to English (e.g., عمل → Work); "" if residency_type_ar.value is ""
- `employer_en`      = translate employer_ar.value to meaningful English; "" if employer_ar.value is ""
- `address_en`       = translate address_ar.value to English; "" if address_ar.value is ""

**`back_header_verified`** (boolean) — True ONLY if ALL conditions met:

  FOR **residency_permit** — ALL of the following must be present in OCR:
    1. Arabic "مدير عام الإدارة العامة للجوازات" OR English "General Director of the General Directorate of Passports"
    2. AND "Holder's signature"
    3. AND at least one of: "Passport Number" or "رقم جواز السفر" or "Passport Expiry"

  FOR **national_id** — ALL of the following must be present in OCR:
    1. Arabic "مدير إدارة الجنسية و وثائق السفر" OR "Authority's signature"
    2. AND "Holder's signature" OR "توقيع حامل البطاقة"
    3. AND "العنوان" (address field) is visible

  FOR **unknown** — back_header_verified MUST be false.

### 5. Date Format Validation — DD/MM/YYYY (STRICT)
- The required pattern is: exactly 2-digit day, `/`, 2-digit month, `/`, 4-digit year — nothing more, nothing less
- ✅ VALID examples (do NOT flag these): `14/12/1991`, `01/08/2023`, `18/02/2035`, `03/06/2026`
- ❌ INVALID examples (flag these): `3/06/2026` , `05/1/2025` (single-digit day — missing leading zero), `15/10/23` (2-digit year), `15.10.2026` (dot separator)
- Future years are valid (e.g., 18/02/2035) — do NOT mark as format error
- **A date with two-digit day, two-digit month, and four-digit year separated by `/` is ALWAYS valid — do NOT flag it.**
- If OCR contains a date value that does NOT match the pattern above:
  → set value: ""
  → set blurry: true
  → set reason: "invalid date format (got: <original OCR token>)"
- If no date token is found at all → value: "", blurry determined by confidence thresholds only

### 6. Overall Blurriness Assessment

**Step A — Empty-field check (run FIRST):**
- **residency_permit**: count these 5 fields: passport_number, passport_expiry, serial_number, employer_ar, residency_type_ar
  - If 3 or more empty → is_blurred: true, blurriness_level: "high", blurriness_reason: "Most fields are empty — document unreadable or OCR failed" — STOP
- **national_id**: count these 2 fields: serial_number, address_ar
  - If both empty → is_blurred: true, blurriness_level: "high", blurriness_reason: "Most fields are empty — document unreadable or OCR failed" — STOP

**Step B — Blurry-field count (only if Step A did not trigger):**
- residency_permit required: passport_number, passport_expiry, serial_number, residency_type_ar, employer_ar
- national_id required: serial_number, address_ar
- Missing field with no key+value evidence = not present (not blurry)
- `"none"`: 0 blurry → is_blurred: false, blurriness_reason: ""
- `"low"`: 1 blurry → is_blurred: true
- `"medium"`: 2–3 blurry → is_blurred: true
- `"high"`: 4+ blurry → is_blurred: true
- blurriness_reason: comma-separated field names where blurry is true

Return ONLY a valid JSON object. No extra text, no markdown, no code fences.
"""

class FieldResult(BaseModel):
    """Per-field extraction result with key and value confidence scores."""
    value: str = Field(default="", description="Extracted value; empty string if not found or any token conf < 0.5")
    key_conf: float = Field(default=0.0, description="Avg confidence of the label/key tokens for this field")
    value_conf: float = Field(default=0.0, description="Avg confidence of the value tokens for this field")
    blurry: bool = Field(default=False, description="True if key_conf or value_conf falls below the threshold defined for this field")
    reason: str = Field(default="", description="Concise explanation if blurry is True (cite which conf was low); else empty string")


class QatarFront(BaseModel):
    id_number:     FieldResult = Field(..., description="ID number (11 digits) | blurry threshold: key_conf < 0.70 OR value_conf < 0.85")
    dob:           FieldResult = Field(..., description="Date of birth in DD/MM/YYYY format | blurry threshold: key_conf < 0.70 OR value_conf < 0.85")
    expiry_date:   FieldResult = Field(..., description="Date of expiry in DD/MM/YYYY format | blurry threshold: key_conf < 0.70 OR value_conf < 0.85")
    name:          FieldResult = Field(..., description="Full name in English as printed | blurry threshold: key_conf < 0.70 OR value_conf < 0.85")
    name_ar:       FieldResult = Field(..., description="Full name in Arabic as printed | blurry threshold: key_conf < 0.50 OR value_conf < 0.60")
    first_name:    FieldResult = Field(..., description="First name (first word of English name) | blurry threshold: key_conf < 0.70 OR value_conf < 0.85")
    last_name:     FieldResult = Field(..., description="Last name (last word of English name) | blurry threshold: key_conf < 0.70 OR value_conf < 0.85")
    nationality:   FieldResult = Field(..., description="Nationality as printed on card, e.g., PHILIPPINE, INDIAN, PAKISTANI | blurry threshold: key_conf < 0.70 OR value_conf < 0.85")
    nationality_iso: str        = Field(default="", description="ISO 3166-1 alpha-3 code derived from nationality.value (e.g., INDIAN → IND, PHILIPPINE → PHL); empty if nationality is empty")
    occupation_ar: FieldResult = Field(..., description="Occupation in Arabic as written; empty if card_type is national_id | blurry threshold: key_conf < 0.50 OR value_conf < 0.60")
    occupation_en: str         = Field(default="", description="Occupation translated to English QNOC standard job titles; plain string, empty if card_type is national_id or occupation_ar is empty")
    card_type:     Literal["national_id", "residency_permit", "unknown"] = Field(
        ..., description="Card classification: national_id, residency_permit, or unknown"
    )
    header_verified: bool = Field(
        ...,
        description=(
            "True ONLY if ALL required header words AND field labels are present for the detected card type. "
            "residency_permit: headers ('State of Qatar' AND 'Residency Permit' AND 'دولة قطر' AND 'رخصة إقامة') "
            "AND field labels ('ID.No' AND 'D.O.B' AND 'Expiry' AND 'Nationality' AND 'Occupation' AND 'Name' AND 'الرقم الشخصي' AND 'تاريخ الميلاد' AND 'الصلاحية' AND 'الجنسية' AND 'المهنة' AND 'الاسم'). "
            "national_id: headers ('State of Qatar' AND 'ID. Card' AND 'دولة قطر' AND 'بطاقة إثبات شخصية') "
            "AND field labels ('ID.No' AND 'D.O.B' AND 'Nationality' AND 'Date of expiry' AND 'Name' AND 'الرقم الشخصي' AND 'تاريخ الميلاد' AND 'الجنسية' AND 'الصلاحية' AND 'الاسم'). "
            "False if card_type is unknown or any required word/label is missing."
        )
    )
    is_blurred: bool = Field(..., description="True if ANY field is blurry (blurriness_level is low, medium, or high)")
    blurriness_level: Literal["none", "low", "medium", "high"] = Field(
        ..., description="Overall assessed blurriness level based on all OCR confidence scores"
    )
    blurriness_reason: str = Field(
        default="",
        description="Comma-separated list of field names where blurry is true; empty string if blurriness_level is 'none'"
    )


class QatarBack(BaseModel):
    card_type: Literal["national_id", "residency_permit", "unknown"] = Field(
        ..., description="'residency_permit' for Residency Permit back, 'national_id' for Qatar National ID back, 'unknown' if neither"
    )
    passport_number:    FieldResult = Field(..., description="Passport number (alphanumeric); always empty FieldResult for national_id | blurry threshold: key_conf < 0.70 OR value_conf < 0.85")
    passport_expiry:    FieldResult = Field(..., description="Passport expiry in DD/MM/YYYY; always empty FieldResult for national_id | blurry threshold: key_conf < 0.70 OR value_conf < 0.85")
    serial_number:      FieldResult = Field(..., description="Serial number preserving all letters/digits (e.g., 4364590A4820247E); present on both card types | blurry threshold: key_conf < 0.70 OR value_conf < 0.85")
    residency_type_ar:  FieldResult = Field(..., description="Residency type in Arabic (e.g., عمل); always empty FieldResult for national_id | blurry threshold: key_conf < 0.50 OR value_conf < 0.60")
    residency_type_en:  str         = Field(default="", description="Residency type translated to English (e.g., Work); plain string, empty for national_id")
    employer_ar:        FieldResult = Field(..., description="Employer name in Arabic exactly as printed; always empty FieldResult for national_id | blurry threshold: key_conf < 0.50 OR value_conf < 0.60")
    employer_en:        str         = Field(default="", description="Employer name translated to meaningful English; plain string, empty for national_id")
    address_ar:         FieldResult = Field(..., description="Arabic address from العنوان field; always empty FieldResult for residency_permit | blurry threshold: key_conf < 0.50 OR value_conf < 0.60")
    address_en:         str         = Field(default="", description="Address translated to English; plain string, empty for residency_permit")
    # employer:           str = Field(default="", description="Plain string copy of employer_ar.value")
    # residency_type:     str = Field(default="", description="Plain string copy of residency_type_ar.value")
    # address:            str = Field(default="", description="Plain string copy of address_ar.value")
    back_header_verified: bool = Field(
        ...,
        description=(
            "True ONLY if ALL conditions met for detected card type. "
            "residency_permit: 1) 'مدير عام الإدارة العامة للجوازات' OR 'General Director of the General Directorate of Passports' OR 'General Director of Nationality Borders & Expatriates Affairs' AND "
            "2) 'Holder\'s signature' AND "
            "3) at least one of 'Passport Number' or 'رقم جواز السفر' or 'Passport Expiry'. "
            "national_id: 1) 'مدير إدارة الجنسية و وثائق السفر' OR 'Authority\'s signature' AND "
            "2) 'Holder\'s signature' OR 'توقيع حامل البطاقة' AND "
            "3) 'العنوان' field visible. "
            "False if card_type is unknown or conditions not fully satisfied."
        )
    )
    is_blurred: bool = Field(..., description="True if ANY field is blurry (blurriness_level is low, medium, or high)")
    blurriness_level: Literal["none", "low", "medium", "high"] = Field(
        ..., description="Assessed blurriness level for detected back card type fields"
    )
    blurriness_reason: str = Field(
        default="",
        description="Comma-separated field names where blurry is true; empty string if blurriness_level is 'none'"
    )


def process_image(side):
    """Return the Pydantic response model and prompt string for the given card side."""
    if side == "front":
        prompt = PROMPT_FRONT
        model = QatarFront
    elif side == "back":
        prompt = PROMPT_BACK
        model = QatarBack
    else:
        raise ValueError("Invalid document side. Use 'front' or 'back'.")
    return model, prompt

def extract_word_confidence_scores(response):
    """
    Walk the Google Vision full_text_annotation tree and build a flat
    {word: confidence} dict from the OCR response.

    Duplicate words are disambiguated by appending a counter suffix
    (e.g. "Name", "Name_1") so every word retains its own confidence score.
    """
    logging.info("Extracting confidence scores for WORDS from OCR response")
    conf_dict = {}
    if getattr(response, "full_text_annotation", None):
        for page in response.full_text_annotation.pages:
            for block in page.blocks:
                for paragraph in block.paragraphs:
                    for word in paragraph.words:
                        # Reconstruct the word string from its individual symbol objects
                        word_text = "".join([symbol.text for symbol in word.symbols])
                        key = word_text
                        count = 1
                        # Ensure unique keys for repeated words
                        while key in conf_dict:
                            key = f"{word_text}_{count}"
                            count += 1
                        conf_dict[key] = word.confidence
    return conf_dict


def format_word_conf_for_prompt(word_conf_dict: dict) -> str:
    """
    Format the word-confidence dict into a human-readable string that is
    injected directly into the LLM prompt.

    Each line shows a token and its OCR confidence score.  A summary line
    appended at the end gives the model a quick overview of overall OCR quality.
    """
    lines = [f"{word}  (conf: {conf:.4f})" for word, conf in word_conf_dict.items()]
    if word_conf_dict:
        scores = list(word_conf_dict.values())
        avg = sum(scores) / len(scores)
        # Count tokens below the 0.5 threshold — these will be treated as unreadable
        low_count = sum(1 for s in scores if s < 0.5)
        low_pct = (low_count / len(scores)) * 100
        lines.append(
            f"\n[Summary] Total tokens: {len(scores)} | "
            f"Avg confidence: {avg:.4f} | "
            f"Low-conf tokens (<0.5): {low_count} ({low_pct:.1f}%)"
        )
    return "\n".join(lines)


def get_openai_response(prompt: str, model_type, full_text: str, word_conf_dict: dict, genai_key: str):
    """
    Send the filled prompt to OpenAI and parse the response into the given
    Pydantic model (QatarFront or QatarBack).

    Retries up to 3 times with a 2-second delay on failure.
    Returns the parsed Pydantic object, or None if all attempts fail.
    """
    # Inject OCR text and word-confidence table into the prompt template
    filled_prompt = prompt.format(
        extracted_text=full_text,
        word_conf_dict2=format_word_conf_for_prompt(word_conf_dict),
    )
    for attempt in range(3):
        try:
            client = OpenAI(api_key=genai_key)
            response = client.responses.parse(
                model="gpt-4.1-mini",
                input=[
                    {"role": "system", "content": "You are an expert at extracting information from identity documents."},
                    {"role": "user", "content": filled_prompt},
                ],
                # Enforce structured output by passing the Pydantic schema
                text_format=model_type,
            )
            return response.output_parsed
        except Exception as e:
            logging.warning(f"[ERROR] Attempt {attempt + 1} failed: {str(e)}")
            time.sleep(2)
    return None


def get_response_from_openai_qat(full_text: str, word_conf_dict: dict, openai_key: str, side: str = "front"):
    """
    Main entry point.
    Accepts:
      - full_text:      raw OCR text string from Google Vision
      - word_conf_dict: {word: confidence} dict from extract_confidence_scores()
      - openai_key:     OpenAI API key
      - side:           'front' or 'back' (default: 'front')
    Returns extracted fields as a dict.
    """
    logging.info(f"Processing Qatar NID '{side}' side | tokens={len(word_conf_dict)} | text_len={len(full_text)}")

    try:
        model, prompt = process_image(side)
        logging.info(f"Using model: {model.__name__}")
    except ValueError as ve:
        logging.error(f"Invalid side: {ve}")
        return {"error": str(ve)}

    try:
        response = get_openai_response(prompt, model, full_text, word_conf_dict, openai_key)
    except Exception as e:
        logging.error(f"OpenAI request failed: {e}")
        return {"error": "OpenAI request failed"}

    if response is None:
        return {"error": "All retry attempts failed"}

    # Per-field blurry thresholds: (key_conf_min, value_conf_min)
    # English fields need higher confidence; Arabic fields use relaxed thresholds
    _FRONT_THRESHOLDS = {
        "id_number":    (0.70, 0.85),
        "dob":          (0.70, 0.85),
        "expiry_date":  (0.70, 0.85),
        "name":         (0.70, 0.85),
        "first_name":   (0.70, 0.85),
        "last_name":    (0.70, 0.85),
        "nationality":  (0.70, 0.85),
        "name_ar":      (0.50, 0.60),
        "occupation_ar":(0.50, 0.60),
    }
    _BACK_THRESHOLDS = {
        "passport_number":   (0.70, 0.85),
        "passport_expiry":   (0.70, 0.85),
        "serial_number":     (0.70, 0.85),
        "residency_type_ar": (0.50, 0.60),
        "employer_ar":       (0.50, 0.60),
        "address_ar":        (0.50, 0.60),
    }
    # Select the threshold set that matches the side being processed
    thresholds = _FRONT_THRESHOLDS if side == "front" else _BACK_THRESHOLDS

    logging.info("--- Post-processing: per-field blur re-evaluation ---")
    for field_name, (kmin, vmin) in thresholds.items():
        field = getattr(response, field_name, None)
        if field is None or not isinstance(field, FieldResult):
            continue
        # Re-evaluate blurry from actual numeric values — LLM math is unreliable
        if field.value == "" and field.key_conf == 0.0 and field.value_conf == 0.0:
            # Label absent — keep blurry: false as intended
            field.blurry = False
            field.reason = ""
            logging.info("  [%s] label absent — blurry=False (skipped)", field_name)
        elif field.blurry and "invalid date format" in field.reason:
            # Date format error — keep as-is
            logging.info("  [%s] invalid date format — blurry=True kept as-is | reason: %s", field_name, field.reason)
        else:
            key_fail   = field.key_conf   < kmin
            value_fail = field.value_conf < vmin
            field.blurry = key_fail or value_fail
            if key_fail and value_fail:
                field.reason = f"key_conf {field.key_conf} < {kmin} and value_conf {field.value_conf} < {vmin}"
            elif key_fail:
                field.reason = f"key_conf {field.key_conf} < {kmin}"
            elif value_fail:
                field.reason = f"value_conf {field.value_conf} < {vmin}"
            else:
                field.reason = ""
            logging.info(
                "  [%s] key_conf=%.4f (min=%.2f) | value_conf=%.4f (min=%.2f) | blurry=%s%s",
                field_name, field.key_conf, kmin, field.value_conf, vmin,
                field.blurry, f" | reason: {field.reason}" if field.reason else "",
            )

    # Post-process: recompute blurriness summary from corrected per-field blurry flags.
    # The LLM's own is_blurred / blurriness_level / blurriness_reason are discarded and
    # replaced entirely by deterministic logic based on the per-field blurry flags above.
    logging.info("--- Post-processing: blurriness summary ---")
    card_type = getattr(response, "card_type", "unknown")

    logging.info("  card_type=%s | side=%s", card_type, side)

    if side == "front":
        if card_type == "residency_permit":
            # occupation_ar is meaningful only on residency permits, so include it in the empty-field check
            step_a_fields = ["id_number", "dob", "expiry_date", "name", "name_ar", "nationality", "occupation_ar"]
            step_a_threshold = 4
        elif card_type == 'national_id':  # national_id  — occupation fields are always empty, exclude them
            step_a_fields = ["id_number", "dob", "expiry_date", "name", "name_ar", "nationality"]
            step_a_threshold = 4
        else:  # dont process further if unknown, as the field set is unclear and we dont want to risk false positives — just mark as blurred
            response.is_blurred = True
            response.blurriness_level = "high"
            response.blurriness_reason = "Unknown card type — cannot reliably assess blurriness"
            logging.info("  Unknown card type on front side → marked as high blur | reason: %s", response.blurriness_reason)
            # For unknown front-side card types, skip both Step A and Step B checks.
            step_a_fields = []
            step_a_threshold = 0
            step_b_fields = []  # skip step B since we already marked as blurred

        # Step B checks all FieldResult fields that have defined thresholds
        if card_type != "unknown":
            step_b_fields = list(_FRONT_THRESHOLDS.keys())
    else:  # back
        if card_type == "residency_permit":
            step_a_fields = ["passport_number", "passport_expiry", "serial_number", "employer_ar", "residency_type_ar"]
            step_a_threshold = 3
            step_b_fields = ["passport_number", "passport_expiry", "serial_number", "residency_type_ar", "employer_ar"]
        elif card_type == 'national_id':  # national_id or unknown — only two meaningful fields on the back
            step_a_fields = ["serial_number", "address_ar"]
            step_a_threshold = 2
            step_b_fields = ["serial_number", "address_ar"]
        
        else:
            response.is_blurred = True
            response.blurriness_level = "high"
            response.blurriness_reason = "Unknown card type — cannot reliably assess blurriness"
            logging.info("  Unknown card type on back side → marked as high blur | reason: %s", response.blurriness_reason)
            step_b_fields = []  # skip step B since we already marked as blurred

    # Step A: if too many core fields are empty, the image is almost certainly unreadable
    empty_count = sum(
        1 for f in step_a_fields
        if isinstance(getattr(response, f, None), FieldResult) and getattr(response, f).value == ""
    )
    logging.info("  Step A — empty field count: %d / %d (threshold: %d)", empty_count, len(step_a_fields), step_a_threshold)

    if empty_count >= step_a_threshold:
        # Too many empty fields — mark the whole document as high-blur regardless of individual flags
        response.is_blurred = True
        response.blurriness_level = "high"
        response.blurriness_reason = "Most fields are empty — document unreadable or OCR failed"
        logging.info("  Step A triggered → is_blurred=True | level=high | reason: %s", response.blurriness_reason)
    else:
        # Step B: count how many fields the per-field re-evaluation marked as blurry
        blurry_fields = [
            f for f in step_b_fields
            if isinstance(getattr(response, f, None), FieldResult) and getattr(response, f).blurry
        ]
        count = len(blurry_fields)
        logging.info("  Step B — blurry fields (%d): %s", count, blurry_fields if blurry_fields else "none")
        if count == 0:
            response.is_blurred = False
            response.blurriness_level = "none"
            response.blurriness_reason = ""
        elif count == 1:
            response.is_blurred = True
            response.blurriness_level = "low"
            response.blurriness_reason = ", ".join(blurry_fields)
        elif count <= 3:
            response.is_blurred = True
            response.blurriness_level = "medium"
            response.blurriness_reason = ", ".join(blurry_fields)
        else:  # 4 or more blurry fields
            response.is_blurred = True
            response.blurriness_level = "high"
            response.blurriness_reason = ", ".join(blurry_fields)
        logging.info(
            "  Summary → is_blurred=%s | level=%s | reason: %s",
            response.is_blurred, response.blurriness_level, response.blurriness_reason or "none",
        )

    # Convert the Pydantic model to a plain dict for the caller
    response_data = vars(response)

    def _serialise(obj):
        """Fallback serialiser: convert Pydantic models and other objects to dicts/strings."""
        if hasattr(obj, "__dict__"):
            return obj.__dict__
        return str(obj)

    logging.info(
        "OpenAI response (with per-field blur assessment):\n%s",
        json.dumps(response_data, default=_serialise, ensure_ascii=False, indent=2),
    )
    return response_data


def is_physical_card(base64_image, genai_key):
    """
    Determine whether the provided image shows a physical card or a card displayed on a screen.

    Sends the base64-encoded image to OpenAI together with the
    ON_SCREEN_VS_PHYSICAL_PROMPT and expects a one-word reply: "physical" or "screen".

    Args:
        base64_image: Base64-encoded PNG/JPEG string of the card image.
        genai_key:    OpenAI API key.

    Returns:
        True  — image is a physical card (or the call failed; defaults to physical).
        False — image is an on-screen display.
    """
    try:
        client = OpenAI(api_key=genai_key)
        response = client.chat.completions.create(
            model="gpt-5.2",
            max_completion_tokens=10,  # Only "physical" or "screen" expected
            temperature=1,
            messages=[
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": ON_SCREEN_VS_PHYSICAL_PROMPT},
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:image/png;base64,{base64_image}",
                                "detail": "high"  # Request high-detail analysis for artifact detection
                            },
                        },
                    ],
                }
            ]
        )
        # Normalise to lowercase and strip whitespace before comparing
        decision = response.choices[0].message.content.lower().strip()

        if decision == 'screen':
            return False
        # Any response other than "screen" (including "physical" or unexpected) is treated as physical
        return True

    except Exception as e:
        logging.warning(f"is_physical_card: exception during OpenAI call — defaulting to True (physical): {e}")
        return True