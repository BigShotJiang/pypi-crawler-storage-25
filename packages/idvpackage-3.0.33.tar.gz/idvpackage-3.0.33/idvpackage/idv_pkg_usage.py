import json
import logging
import time
import uuid
from datetime import datetime

import requests
from bson import ObjectId
from fastapi import HTTPException

from idvpackage import ocr

from ..cloud.minio.adapter import minio_adapter
from ..core import config
from ..core.config import Collections
from ..database.mongo import MongoDB
from ..schema.document import DocumentResponse
from ..schema.report import Report
from ..util.file_name_gen import file_name_generator

logging.basicConfig(level=logging.INFO)


class ProcessIdv:
    def __init__(self, database: MongoDB, parent_database: MongoDB, applicant_id: str):
        self.database = database
        self.parent_database = parent_database
        st = time.time()
        self.idv_obj = ocr.IdentityVerification(
            credentials_string=config.GOOGLE_API_CREDS,
            api_key=config.GOOGLE_API_KEY,
            genai_key=config.GEN_AI_KEY,
        )
        logging.info(
            f"Total time for ocr.IdentityVerification step: {time.time() - st} seconds"
        )
        self.applicant_id = applicant_id
        self.document_file_ids = []
        self.video_file_ids = []

    def get_latest_step_tracker(self, projection=False):
        latest_step_tracker = None
        applicant = self.database.read_one(
            config.Collections.APPLICANTS,
            {"applicant_id": self.applicant_id},
        )

        latest_step_tracker_id = applicant.get("latest_step_tracker_id")

        if not latest_step_tracker_id:
            latest_step_tracker = self.database.read_one(
                config.Collections.STEP_TRACKER,
                {"applicant_id": self.applicant_id, "status": "steps_completed"},
                projection={"_id": 1},
                sort=[("created_at", -1)],
            )
            if not latest_step_tracker:
                raise HTTPException(
                    status_code=400, detail="No IDV session found with Completed Steps"
                )

            latest_step_tracker_id = latest_step_tracker.get("_id")

        query = {"_id": ObjectId(latest_step_tracker_id)}

        read_kwargs = {}
        if projection:
            read_kwargs.update({"projection": {"flow_id": 1}})
        start_time = time.time()
        latest_step_tracker = self.database.read_one(
            config.Collections.STEP_TRACKER, query, **read_kwargs
        )
        end_time = time.time()
        logging.info(f"Time taken to  get_latest_step_tracker : {end_time - start_time}")

        if not latest_step_tracker:
            raise HTTPException(
                status_code=400, detail="No IDV session found with Completed Steps"
            )
        return latest_step_tracker

    def check_document_quality(self, document):
        res = None
        start_time = time.time()
        try:
            res = self.idv_obj.check_document_quality(document)
            logging.info(
                f"--------------------Document Quality Response-----------{res}-------"
            )
        except Exception as e:
            logging.info(f"Error in check_document_quality: {e}")
        end_time = time.time()
        print(
            f"Time taken inside check_document_quality function: {end_time - start_time}"
        )
        return res

    def extract_document_info(
        self, type, side, document, country, nationality=None, step_data=None
    ):
        logging.info(
            f"--------------------Extracting Data-----------{type}-------{side}-------{country}-------{nationality}"
        )
        res = None
        start_time = time.time()
        try:
            res = self.idv_obj.extract_document_info(
                document, side, type, country, nationality, step_data
            )
            logging.info(f"--------------------Extracted Data-----------{res}-------")
        except Exception as e:
            logging.info(f"Error in extract_document_info: {e}")
        end_time = time.time()
        print(
            f"Time taken inside extract_document_info function: {end_time - start_time}"
        )
        return res

    def get_file_and_link_check(self, files, check_id):
        video_data = None
        for file_id in files:
            file = self.database.read_one(
                config.Collections.DOCUMENTS, {"document_id": file_id}
            )
            if file["file_type"].lower().startswith("video"):
                self.video_file_ids.append(file_id)
                object_name = file["file_name"]
                video_data = minio_adapter.get_object(object_name)
            else:
                self.document_file_ids.append(file_id)

            self.database.update_one_document(
                config.Collections.DOCUMENTS,
                {"document_id": file_id},
                {"$set": {"check_id": check_id}},
            )

        return video_data

    def get_backid_data(self, files):
        backid_data = None
        try:
            for file_id in files:
                file = self.database.read_one(
                    config.Collections.DOCUMENTS, {"document_id": file_id}
                )
                if (
                    file["file_type"].lower().startswith("image")
                    and file["side"] == "back"
                ):
                    object_name = file["file_name"]
                    logging.info(f"Back ID Object name : {object_name}")
                    backid_data = minio_adapter.get_object(object_name)
        except Exception as e:
            logging.info(f"Error in getting backid data: {e}")
        return backid_data

    def insert_report_data(self, report_data, check_id):
        report_id = str(uuid.uuid4())
        documents = []
        breakdown_data = report_data.get("breakdown")
        if report_data:
            if report_data.get("name") == "document":
                documents = [{"id": id_str} for id_str in self.document_file_ids]
            elif report_data.get("name") == "facial_similarity_video":
                documents = [{"id": id_str} for id_str in self.video_file_ids]

            report = Report(
                breakdown=breakdown_data,
                check_id=check_id,
                applicant_id=self.applicant_id,
                created_at=str(datetime.utcnow()),
                documents=documents,
                href=f"api/v1.0/reports/{str(uuid.uuid4())}",
                report_id=report_id,
                name=report_data.get("name"),
                type=report_data.get("type", ""),
                result=report_data.get("result"),
                status=report_data.get("status"),
                sub_result=report_data.get("sub_result"),
                properties=report_data.get("properties"),
            )

        report_dict = report.dict()

        #         # Insert the new report into the reports collection
        self.database.insert_one(Collections.REPORTS, report_dict)
        return report_id

    def notify_webhook(self, applicant_id, check_id):
        webhook_entry, webhook_url, webhook_config = self.get_webhook_auth(
            "check.completed"
        )
        webhook_payload = {
            "payload": {
                "resource_type": "check",
                "action": "check.completed",
                "object": {
                    "id": check_id,
                    "status": "complete",
                    "completed_at_iso8601": str(datetime.utcnow()),
                    "href": "/api/v1/idv/checks/" + check_id + "/",
                },
            }
        }

        custom_headers = None
        username = None
        password = None

        if webhook_config.get("username") and webhook_config.get("password"):
            username = webhook_config.get("username")
            password = webhook_config.get("password")
        elif webhook_config:
            custom_headers = webhook_config

        # print the webhook payload & other details for debugging
        print(f"Webhook URL: {webhook_url}")
        print(f"Webhook Payload: {webhook_payload}")
        print(f"Webhook Auth: {webhook_config}")
        if username and password:
            success, message, retries = self.send_authenticated_request(
                webhook_url, webhook_payload, username=username, password=password
            )
        elif custom_headers:
            success, message, retries = self.send_authenticated_request(
                webhook_url, webhook_payload, custom_headers=custom_headers
            )

        webhook_event_data = {
            "webhook_id": webhook_entry["_id"],
            "url": webhook_url,
            "payload": webhook_payload,
            "try_count": retries,
            "created_at": str(datetime.utcnow()),
            "success": success,
        }

        self.database.insert_one(config.Collections.WEBHOOK_EVENTS, webhook_event_data)

        if success:
            # update the check obj with webhook id
            update_query = {"$set": {"webhook_ids": str(webhook_entry["_id"])}}
            self.database.update_one_document(
                config.Collections.CHECKS, {"check_id": check_id}, update_query
            )

            print(message)
        else:
            print(f"Request failed: {message}")

    def update_check(self, check_id, report_ids):
        check = self.database.read_one(config.Collections.CHECKS, {"check_id": check_id})
        if not check:
            print("Check not found")
            return
        update_query = {"$set": {"report_ids": report_ids, "status": "completed"}}

        self.database.update_one_document(
            config.Collections.CHECKS, {"check_id": check_id}, update_query
        )

    def process_id_video(self, applicant_id, report_names, check_id, notify_webhook=True):
        document_report = None
        video_report = None
        facial_authentication = False
        facial_auth_data = {}
        data = {}
        step_data_json = None
        if len(report_names) == 1 and report_names[0] == "facial_similarity_video":
            facial_authentication = True
        latest_step_tracker = self.get_latest_step_tracker()
        flow = self.parent_database.read_one(
            config.Collections.FLOWS, {"_id": latest_step_tracker["flow_id"]}
        )
        country = flow.get("country")
        tenant_id = flow.get("tenant_id")
        print(f"Tenant ID: {tenant_id}")

        if latest_step_tracker:
            extracted_data = None
            files = []
            if latest_step_tracker:
                step_tracker_steps = latest_step_tracker["tracking_records"]
                for step in step_tracker_steps:
                    if step.get("document_id"):
                        files.append(step["document_id"])
                video_data = self.get_file_and_link_check(files, check_id)
                if len(latest_step_tracker["step_data"]) == 0:
                    try:
                        logging.info("Getting step data json from minio")
                        # get the stepdata json from minio and pass it to the ocr extraction function., refere to this step_data_object_name = f"{tracker_id}_step_data.json step_data_json = json.dumps(extracted_results)
                        step_data_object_name = (
                            f"{latest_step_tracker['_id']}_step_data.json"
                        )
                        step_data_json = minio_adapter.get_object(step_data_object_name)
                        if step_data_json:
                            logging.info("Step data json fetched successfully")
                            step_data_json = step_data_json.decode("utf-8")
                    except Exception as e:
                        logging.info(f"Error in getting step_data_json: {e}")
                    data = json.loads(step_data_json)
                else:
                    data = latest_step_tracker["step_data"]

            if facial_authentication:
                facial_auth_data["latest_selfie"] = data["selfie"]
                query = {"applicant_id": applicant_id, "status": "report_gen_completed"}
                sort_key = [("created_at", -1)]
                latest_report_session_tracker = self.database.read_one(
                    config.Collections.STEP_TRACKER,
                    query,
                    projection={"_id": 1},
                    sort=sort_key,
                )
                # check if the latest report session step data is available in minio cloud
                if latest_report_session_tracker:
                    latest_report_session_tracker_id = latest_report_session_tracker.get(
                        "_id"
                    )
                    query = {"_id": ObjectId(latest_report_session_tracker_id)}
                    latest_report_session = self.database.read_one(
                        config.Collections.STEP_TRACKER, query
                    )
                    if len(latest_report_session["step_data"]) == 0:
                        step_data_object_name = (
                            f"{latest_report_session['_id']}_step_data.json"
                        )
                        step_data_json = minio_adapter.get_object(step_data_object_name)
                        if step_data_json:
                            step_data_json = step_data_json.decode("utf-8")
                            step_data_json = json.loads(step_data_json)
                    else:
                        step_data_json = latest_report_session["step_data"]

                    facial_auth_data["initial_selfie"] = step_data_json["selfie"]
            else:
                applicant_data = self.database.read_one(
                    config.Collections.APPLICANTS, {"applicant_id": applicant_id}
                )
                if applicant_data:
                    data.update(
                        {
                            "manual_input": {
                                "first_name": applicant_data.get("first_name"),
                                "last_name": applicant_data.get("last_name"),
                                "dob": applicant_data.get("dob") or "1990-01-01",
                                "gender": "",
                            }
                        }
                    )
            try:
                start_time = time.time()
                logging.info(f"Start time for ocr extraction: {start_time}")
                if not facial_authentication:
                    logging.info(
                        "-----------------------Generating report for document and video-----------------------"
                    )
                    if country == "QAT":
                        backid_data = self.get_backid_data(files)
                        document_report, video_report = self.idv_obj.extract_ocr_info(
                            data, video_data, country, report_names, backid_data
                        )
                    else:
                        document_report, video_report = self.idv_obj.extract_ocr_info(
                            data, video_data, country, report_names
                        )
                else:
                    logging.info(
                        "------------------Generating facial auth report-------------------------"
                    )
                    video_report = self.idv_obj.generate_facial_report_portal(
                        facial_auth_data, video_data
                    )
                logging.info(f"Time taken for ocr extraction: {time.time() - start_time}")
                logging.info(f"Document Report: {document_report}")
                logging.info(f"Video Report: {video_report}")
                # insert report data
                report_ids = []
                for report_name in report_names:
                    if report_name == "document" and document_report:
                        doc_report_id = self.insert_report_data(document_report, check_id)
                        report_ids.append(doc_report_id)
                    elif report_name == "facial_similarity_video" and video_report:
                        facial_report_id = self.insert_report_data(video_report, check_id)
                        report_ids.append(facial_report_id)

                update_query = {
                    "$set": {
                        "status": "report_gen_completed"
                        if not facial_authentication
                        else "report_gen_completed_face_auth",
                        "check_id": check_id,
                    }
                }

                # Find the document by its ObjectId and update it
                self.database.update_one_document(
                    config.Collections.STEP_TRACKER,
                    {"_id": ObjectId(latest_step_tracker["_id"])},
                    update_query,
                )

                # update the check obj with report ids and status
                self.update_check(check_id, report_ids)

                # notify the client when the process is completed.
                if notify_webhook:
                    self.notify_webhook(applicant_id, check_id)
                return True
            except Exception as e:
                logging.info(f"Error in process_id_video: {e}")
                return False

    def get_webhook_auth(self, event):
        webhook_entry = self.database.read_one(
            config.Collections.WEBHOOKS, {"events": event}
        )

        if webhook_entry:
            webhook_url = webhook_entry["url"]
            # Get the webhook config from the entry
            webhook_configs = webhook_entry.get("config")
            if webhook_configs:
                for webhook_config in webhook_configs:
                    if webhook_config.get("basic_auth"):
                        return (
                            webhook_entry,
                            webhook_url,
                            webhook_config.get("basic_auth"),
                        )

                    elif webhook_config.get("custom_headers"):
                        custom_headers = webhook_config.get("custom_headers")
                        token_auth_headers = {
                            custom_headers["header_name"]: custom_headers["header_value"]
                        }
                        return webhook_entry, webhook_url, token_auth_headers

            else:
                # No valid auth method found
                return None

    def send_authenticated_request(
        self,
        webhook_url,
        webhook_payload,
        username=None,
        password=None,
        custom_headers=None,
    ):
        max_retries = 5
        retry_interval = 3
        for retry in range(max_retries):
            try:
                # Create a session for making the request
                with requests.Session() as session:
                    if username and password:
                        # Authenticate with username and password
                        session.auth = (username, password)

                    if custom_headers:
                        # Set custom headers
                        session.headers.update(custom_headers)

                    # Set content type as JSON
                    session.headers["Content-Type"] = "application/json"

                    # Make a POST request to the webhook URL with the payload
                    response = session.post(webhook_url, json=webhook_payload)

                    # Check the response status code
                    if response.status_code == 200:
                        # Request was successful
                        return True, "Request was successful", retry
                    else:
                        # Request failed, log the status code and response content
                        error_message = f"Request failed with status code: {response.status_code}, Response: {response.text}"

                # If it reaches this point, the request failed
                if retry < max_retries - 1:
                    print(f"Retrying in {retry_interval} seconds...")
                    time.sleep(retry_interval)
            except Exception as e:
                # Handle any exceptions here, you can log or raise them if needed
                print(f"Webhook request failed with exception: {e}")

        # If all retries fail, return failure status
        return False, "Maximum retry attempts reached", max_retries

    def upload_document_cloud(self, file, file_content, document_data):
        object_name = file_name_generator(self.applicant_id, file.filename)

        # Upload the file to Minio
        document_obj = minio_adapter.put_object(object_name, file_content)

        if document_obj:
            print({"message": "File uploaded successfully"})
        else:
            print({"message": "File upload failed"})
            return {"message": "File upload failed"}

        document_id = str(uuid.uuid4())
        # Populate the DocumentResponse instance
        document_data = DocumentResponse(
            document_id=document_id,
            etag=document_obj.etag,
            bucket_name=document_obj.bucket_name,
            applicant_id=self.applicant_id,
            created_at=str(datetime.now()),
            file_name=document_obj.object_name,
            file_type=file.content_type,
            file_size=len(file_content),
            type=document_data.type,
            side=document_data.side,
            issuing_country=document_data.country,  # Assuming you want to populate issuing_country with country
            href=f"/documents/{str(document_id)}",  # Assuming a URL structure for accessing documents
            download_href=f"/documents/{str(document_id)}/download",  # Assuming a URL structure for downloading documents
        )

        document_data_dict = document_data.dict()
        # Insert the new check into MongoDB
        self.database.insert_one(config.Collections.DOCUMENTS, document_data_dict)
