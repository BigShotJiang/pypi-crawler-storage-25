from datetime import datetime
import re
import cv2
import numpy as np
from google.cloud import vision_v1
from idvpackage.constants import *
import pkg_resources
import base64
from rapidfuzz import fuzz
import logging
from datetime import datetime

logging.basicConfig(level=logging.INFO)

def create_final_result(dictionary):
    result = ""
    for key, value in dictionary.items():
        if isinstance(value, dict):
            sub_result = create_final_result(value)
            if sub_result == 'consider':
                return 'consider'
            elif sub_result == 'clear':
                result = 'clear'
        elif value in ['clear', 'consider', ""]:
            if value == 'consider':
                return 'consider'
            elif result != 'clear':
                result = value
    return result

def create_sub_result(document_report):
    sub_result = 'clear'

    digital_document = document_report["breakdown"]["image_integrity"]["breakdown"]["conclusive_document_quality"]["properties"].get("digital_document")
    corner_removed = document_report["breakdown"]["image_integrity"]["breakdown"]["conclusive_document_quality"]["properties"].get("corner_removed")
    watermarks_digital_text_overlay = document_report["breakdown"]["image_integrity"]["breakdown"]["conclusive_document_quality"]["properties"].get("watermarks_digital_text_overlay")
    obscured_security_features = document_report["breakdown"]["image_integrity"]["breakdown"]["conclusive_document_quality"]["properties"].get("obscured_security_features")
    screenshot = document_report["breakdown"]["visual_authenticity"]["breakdown"]["original_document_present"]["properties"].get("screenshot")
    document_on_printed_paper = document_report["breakdown"]["visual_authenticity"]["breakdown"]["original_document_present"]["properties"].get("document_on_printed_paper")
    photo_of_screen = document_report["breakdown"]["visual_authenticity"]["breakdown"]["original_document_present"]["properties"].get("photo_of_screen")
    scan = document_report["breakdown"]["visual_authenticity"]["breakdown"]["original_document_present"]["properties"].get("scan")

    consider_caution_count = sum(value == 'consider' for value in [digital_document, corner_removed, watermarks_digital_text_overlay, obscured_security_features, screenshot, document_on_printed_paper, photo_of_screen, scan])
    
    data_consistency = document_report["breakdown"]["data_consistency"]["result"]
    data_comparison = document_report["breakdown"]["data_comparison"]["result"]

    if data_consistency == 'consider' or data_comparison == 'consider':
        sub_result = 'caution'

    if consider_caution_count > 2:
        sub_result = 'suspected'

    return sub_result

def mark_clear(data, keys):
    if isinstance(data, dict):
        for key, value in list(data.items()):
            if key in keys:
                data[key] = mark_nested_result(value, 'clear')
            else:
                data[key] = mark_clear(value, keys)
        return data
    elif isinstance(data, list):
        return [mark_clear(item, keys) for item in data]
    else:
        return data

def mark_nested_result(data, value):
    if isinstance(data, dict):
        if 'result' in data:
            data['result'] = value
        for key, val in data.items():
            if key != 'result':
                data[key] = mark_nested_result(val, value)
        return data
    elif isinstance(data, list):
        return [mark_nested_result(item, value) for item in data]
    else:
        return data
    

def parse_date(date_str: str, fmt: str = "%d/%m/%Y"):
    """Safely parse a date string and return a datetime object or None."""
    if not date_str:
        return None
    date_str = date_str.replace(".", "/").replace("-", "/")  # unify separators
    try:
        return datetime.strptime(date_str, fmt)
    except Exception as e:
        logging.exception(f"Failed to parse date: {date_str}, Error: {e}")
        return None

def validation_checks_passport(data: dict,  id_number_type: str, country: str):
    """
    Perform validation checks for passport-related fields such as:
    - DOB match between OCR and MRZ
    - ID number consistency
    - Expiry and Issue date validations
    - Gender consistency
    """
    # Initialize validation_range with default value
    validation_range = range(1823, 1829)  # Default: 6 years +/- 2 days

    if country == 'SDN':
        validation_range = range(3648, 3654)  # 10 years +/- 2 days for Sudanese passports

    elif country == 'LBN':
        validation_range = list(range(1823, 1828)) + list(range(3648, 3654))  # 5 years +/- 2 days for Lebanon passports

    elif country == 'JOR':
        validation_range = range(1823, 1828)  # 5 years (1825) +/- 2 days for Jordan passports

    elif country == 'IRQ': #range is 8 years , in days
        validation_range = range(2920, 2928)  # 8 years  Iraq passports

    elif country == 'PSE':
        validation_range = range(1823, 1828)  # 5 years +/- 2 days for Palestinian passports
    
    elif country == 'SYR':
        validation_range = [days for years in [2, 3, 6] for days in range(years * 365 - 2, years * 365 + 3)]

    logging.info(f"Performing validation checks for country: {country} and validation_range: {validation_range}")
    
    dob = normalize_date_generic(data.get("dob"))
    dob_mrz = normalize_date_generic(data.get("dob_mrz"))
      

    expiry_date = parse_date(data.get("expiry_date"))
    expiry_date_mrz = parse_date(data.get("expiry_date_mrz"))

    issue_date = parse_date(data.get("issue_date"))
    logging.info(f"Extracted Issue Date: {issue_date}") 
    id_number = data.get(id_number_type)
    id_number_mrz_str = f"{id_number_type}_mrz"
    id_number_mrz = data.get(id_number_mrz_str, "")

    gender = data.get("gender", "")
    gender_mrz = data.get("gender_mrz", "")
    if gender:
        gender = gender[0].upper()
    if gender_mrz:
        gender_mrz = gender_mrz[0].upper()
    logging.info(f"Extracted Data for Validation - DOB: {dob}, DOB MRZ: {dob_mrz}, Expiry Date: {expiry_date}, Expiry Date MRZ: {expiry_date_mrz}, Issue Date: {issue_date}, ID Number: {id_number}, ID Number MRZ: {id_number_mrz}, Gender: {gender}, Gender MRZ: {gender_mrz}")
    # --- Initialize Flags ---
    is_id_number_same_mrz = False
    is_expiry_date_same_mrz = False
    valid_id_duration = False
    valid_id_duration_mrz = False
    is_gender_mrz_match = False
    is_national_number_mrz_match=False

    # --- ID Number Validation ---
    logging.info(f"Comparing ID Number: data field {id_number} vs MRZ {id_number_mrz}")

    if id_number and id_number_mrz:
        is_id_number_same_mrz = (id_number == id_number_mrz)

    # --- Expiry Date Match (OCR vs MRZ) ---
    logging.info(f"Comparing Expiry Date: data field {expiry_date} vs MRZ {expiry_date_mrz}")
    if expiry_date and expiry_date_mrz:
        is_expiry_date_same_mrz = (expiry_date == expiry_date_mrz)

    # --- Issue vs Expiry Duration (MRZ) ---
    if issue_date and expiry_date_mrz:
        try:
            diff_days_mrz = (expiry_date_mrz - issue_date).days
            logging.info(
                f"[MRZ Duration Check] Issue: {issue_date}, "
                f"Expiry MRZ: {expiry_date_mrz}, Days: {diff_days_mrz}"
            )
            valid_id_duration_mrz = diff_days_mrz in validation_range
        except Exception as e:
            logging.exception(f"Failed to compute MRZ issue-expiry duration: {e}")

    # --- Issue vs Expiry Duration (OCR) ---
    if issue_date and expiry_date:
        try:
            diff_days = (expiry_date - issue_date).days
            logging.info(
                f"[OCR Duration Check] Issue: {issue_date}, "
                f"Expiry: {expiry_date}, Days: {diff_days}"
            )
            valid_id_duration = diff_days in validation_range
        except Exception as e:
            logging.exception(f"Failed to compute OCR issue-expiry duration: {e}")

    # --- Gender Match ---
    if gender and gender_mrz:
        logging.info(f"Comparing Gender: data field {gender} vs MRZ {gender_mrz}")
        is_gender_mrz_match = (gender.lower() == gender_mrz.lower())

    if country == 'SYR':
        logging.info(f"Comparing National Number: data field {data.get('national_number')} vs MRZ {data.get('national_number_mrz')}")   
        is_national_number_mrz_match = (data.get('national_number') == data.get('national_number_mrz'))

        return {
            "is_dob_match_mrz": dob == dob_mrz,
            f"is_{id_number_type}_match_mrz": is_id_number_same_mrz,
            "is_expiry_date_match_mrz": is_expiry_date_same_mrz,
            "is_valid_id_duration": valid_id_duration,
            "is_valid_id_duration_mrz": valid_id_duration_mrz,
            "is_gender_mrz_match": is_gender_mrz_match,
            "is_national_number_mrz_match": is_national_number_mrz_match
        }

    return {
        "is_dob_match_mrz": dob == dob_mrz,
        f"is_{id_number_type}_match_mrz": is_id_number_same_mrz,
        "is_expiry_date_match_mrz": is_expiry_date_same_mrz,
        "is_valid_id_duration": valid_id_duration,
        "is_valid_id_duration_mrz": valid_id_duration_mrz,
        "is_gender_mrz_match": is_gender_mrz_match,
    }

def age_validation(dob, age_threshold=18):
    age_val = {
        "breakdown": {
            "minimum_accepted_age": {
            "properties": {},
            "result": ""
            }
        },
        "result": ""
        }
        
    dob = get_dates_to_generic_format(dob)
    try:
        dob_date = datetime.strptime(dob, "%d/%m/%Y")
    except:
        try:
            dob_date = datetime.strptime(dob, "%Y-%m-%d")
        except:
            dob_date = ''

    if dob_date:
        current_date = datetime.now()

        age = current_date.year - dob_date.year - ((current_date.month, current_date.day) < (dob_date.month, dob_date.day))

        if age>=age_threshold:
            age_val["breakdown"]["minimum_accepted_age"]["result"] = "clear"
            age_val["result"] = "clear"
        else:
            age_val["breakdown"]["minimum_accepted_age"]["result"] = "consider"
            age_val["result"] = "consider"
    else:
        age_val["breakdown"]["minimum_accepted_age"]["result"] = "consider"
        age_val["result"] = "consider"

    return age_val
    
def created_at():
    current_datetime = datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')

    return current_datetime

def is_valid_and_not_expired(expiry_date, country):
    if country == 'LBN':    
        return 'clear'
        
    try:
        parsed_date = datetime.strptime(expiry_date, "%d/%m/%Y")
        current_date = datetime.now()
        
        if parsed_date < current_date:
            return 'consider'
        return 'clear'
    
    except:
        try:
            parsed_date = datetime.strptime(expiry_date, "%Y-%m-%d")
            current_date = datetime.now()
            
            if parsed_date < current_date:
                return 'consider'
            return 'clear'

        except:
            return 'consider'

def normalize_gender(gender: str):
    if not gender:
        return None

    gender = gender.strip().lower()

    if gender in {"m", "male"}:
        return "Male"

    if gender in {"f", "female"}:
        return "Female"

    return None

def normalize_mrz_date(mrz_date, out_format="%Y-%m-%d"):
    """
    MRZ date format: YYMMDD
    """
    if not mrz_date or len(mrz_date) != 6:
        return None

    try:
        yy = int(mrz_date[0:2])
        mm = int(mrz_date[2:4])
        dd = int(mrz_date[4:6])

        # Century inference
        
        year = 2000 + yy

        dt = datetime(year, mm, dd)
        return dt.strftime(out_format)

    except Exception as e:
        logging.info(f"Failed to parse MRZ date {mrz_date}: {e}")
        return None
    
def normalize_date_generic(date_str, out_format="%Y-%m-%d"):
    date_str = date_str.replace(".", "/").replace("-", "/")  # unify separators
    logging.info(f"Normalizing date: {date_str}")
    formats = [
        "%Y/%m/%d",
        "%d/%m/%Y",
        "%m/%d/%Y",
        "%Y-%m-%d",
        "%d-%m-%Y",
        "%m-%d-%Y",
    ]

    for fmt in formats:
        try:
            logging.info(f"Trying to parse date: {date_str} with format: {fmt}")
            dt = datetime.strptime(date_str, fmt)
            return dt.strftime(out_format)
        except ValueError:
            pass
    logging.info(f"Unable to parse date: {date_str}")
    return None

def document_on_printed_paper(image, block_size=11, c_value=2, texture_threshold=0.4, contour_area_threshold=5000):
    image_gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    image_thresh = cv2.adaptiveThreshold(image_gray, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY, block_size, c_value)
    image_contours, _ = cv2.findContours(image_thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    
    # Filter out small noise contours
    image_paper_edges = [contour for contour in image_contours if cv2.contourArea(contour) > contour_area_threshold]

    # Calculate the percentage of paper texture in the image
    texture_ratio = len(image_paper_edges) / max(len(image_contours), 1)

    # Determine if the image contains a printed paper texture
    if texture_ratio >= texture_threshold:
        return 'consider'
    else:
        return 'clear'

def perform_feature_matching(image, template_image_path):
    template_image = cv2.imread(template_image_path, cv2.IMREAD_COLOR)

    sift = cv2.SIFT_create()

    kp1, des1 = sift.detectAndCompute(template_image, None)
    kp2, des2 = sift.detectAndCompute(image, None)

    if len(kp1) == 0 or len(kp2) == 0:
        return 0.0 
    
    bf = cv2.BFMatcher()
    matches = bf.knnMatch(des1, des2, k=2)

    good_matches = []
    for m, n in matches:
        if m.distance < 0.75 * n.distance:
            good_matches.append(m)

    similarity_score = len(good_matches) / len(kp1)

    return similarity_score

def extract_time_values(text_annotations):
    time_values = []
    for annotation in text_annotations:
        text = annotation.description
        time_matches = re.findall(r'\d{1,2}:\d{2}', text)
        time_values.extend(time_matches)
    return time_values

def detect_screenshot(client, image):
    icons = 0
    battery_value_and_time = 0

    similarity_threshold = 0.45

    for filename in pkg_resources.resource_listdir('idvpackage', 'icons'):
        if filename.endswith('.png'):
            icon_path = pkg_resources.resource_filename('idvpackage', f'icons/{filename}')
            image_data = np.frombuffer(base64.b64decode(image), dtype=np.uint8)

            front_similarity_score = perform_feature_matching(image_data, icon_path)
            if front_similarity_score >= similarity_threshold:
                icons+=1

    image_data = vision_v1.Image(content=base64.b64decode(image))

    image_response = client.text_detection(image=image_data)

    image_text_annotations = image_response.text_annotations

    image_time_values = extract_time_values(image_text_annotations)

    if image_time_values:
        battery_value_and_time+=1

    if icons or battery_value_and_time:
        return 'consider'
    else:
        return 'clear'

def detect_photo_on_screen(client, image):
    flag = 'clear'

    image_data = vision_v1.Image(content=base64.b64decode(image))
    image_response = client.label_detection(image=image_data)
    image_labels = image_response.label_annotations

    confidence_threshold = 0.58  
    # 'display device'
    keywords = ['mobile phone', 'mobile device', 'portable communications device', 'communication device', 'smartphone', 'cell phone', 'touchscreen', 'laptop', 'notebook', 'computer', 'screen', 'gadget']

    for label in image_labels:
        description = label.description.lower()
        confidence = label.score
        if confidence >= confidence_threshold:
            match = any(fuzz.ratio(description, keyword.lower()) >= 90 for keyword in keywords)
            if match:
                return 'consider'

    return flag

def fuzzy_match_fields(field1, field2, threshold=55):
    similarity = fuzz.partial_ratio(field1, field2)
    # print(f"similarity: {similarity}")
    return similarity >= threshold

def compare_dates(date_str1, date_str2):
    date_format = "%d/%m/%Y"
    date1 = datetime.strptime(date_str1, date_format)
    date2 = datetime.strptime(date_str2, date_format)

    if date1 == date2:
        return True
    else:
        return False

def standardize_gender(gender):
    if gender == 'male' or gender == 'm':
        return 'Male'

    elif gender == 'female' or gender == 'f':
        return 'Female'

## for data comparison, accept data from dev and match with data extracted from id
def data_comparison_check(data, country):
    data_comparison = DATA_COMPARISON
    data_comparison = mark_clear(data_comparison, ['breakdown', 'result'])

    user_data = data.get('manual_input', '')

    if user_data and country not in ['IRQ', 'LBN', 'SDN', 'SYR', 'JOR', 'PSE', 'UAE']:
        if user_data.get('dob', '') and data.get('dob', ''):
            if compare_dates(get_dates_to_generic_format(data.get('dob', '')), get_dates_to_generic_format(user_data.get('dob', ''))):
                data_comparison['breakdown']['date_of_birth']['result'] = 'clear'
            else:
                data_comparison['breakdown']['date_of_birth']['result'] = 'consider'
        
        if user_data.get('gender', '') and data.get('gender', ''):    
            user_gender = standardize_gender(user_data.get('gender', '').lower())
            id_gender = standardize_gender(data.get('gender', '').lower())

            if user_gender == id_gender:
                data_comparison['breakdown']['gender']['result'] = 'clear'
            else:
                data_comparison['breakdown']['gender']['result'] = 'consider'
    
        if country == 'IRQ':
            if data.get('doc_type') == 'national_identity_card':
                name_parts = data.get('name_en', '').split()
                if len(name_parts) >= 1:
                    first_name = name_parts[0]
                    last_name = name_parts[-1]
                else:
                    first_name, last_name = '',''

            elif data.get('doc_type') == 'passport':
                first_name = data.get('full_name', '').split()[0]
                last_name = data.get('last_name', '')

            else:
                name_parts = data.get('full_name', '').split()
                if len(name_parts) >= 1:
                    first_name = name_parts[0]
                    last_name = name_parts[-1]
                else:
                    first_name, last_name = '',''

        elif country == 'LBN':
            if data.get('doc_type') == 'passport':
                first_name = data.get('first_name', '')
                last_name = data.get('last_name', '')
            else:
                first_name = data.get('first_name_en', '')
                last_name = data.get('last_name_en', '')

        else:
            first_name = data.get('first_name', '')
            last_name = data.get('last_name', '')

        if user_data.get('first_name', ''):
            if fuzzy_match_fields(first_name.lower(), user_data.get('first_name', '').lower()):
                data_comparison['breakdown']['first_name']['result'] = 'clear'
            else:
                data_comparison['breakdown']['first_name']['result'] = 'consider'

        if user_data.get('last_name', ''):
            if fuzzy_match_fields(last_name.lower().replace('-', '').replace('_', ''), user_data.get('last_name', '').lower().replace('-', '').replace('_', '')):
                data_comparison['breakdown']['last_name']['result'] = 'clear'
            else:
                data_comparison['breakdown']['last_name']['result'] = 'consider'
        
        if country == 'QAT':
            data_comparison['breakdown']['date_of_birth']['result'] = 'clear'
            data_comparison['breakdown']['gender']['result'] = 'clear'
            data_comparison['breakdown']['first_name']['result'] = 'clear'
            data_comparison['breakdown']['last_name']['result'] = 'clear'

    ## set default to avoid any problems of cache
    data_comparison['result'] = 'clear'

    result = create_final_result(data_comparison)    
    data_comparison['result'] = result

    logging.info(f"\n\n---------------------------- DATA COMPARISON: {data_comparison}")

    return data_comparison

def data_consistency_check(data, front_id_text, back_id_text, country, back_img):
    data_consistency = DATA_CONSISTENCY
    data_consistency = mark_clear(data_consistency, ['breakdown', 'result'])

    if country == 'UAE' and data.get('uae_pass_data'):
        return data_consistency

    passport_data = data.get('passport')
    if passport_data:
        if not data.get('dob') == passport_data.get('passport_date_of_birth'):
            data_consistency['breakdown']['date_of_birth']['result'] = 'consider'
        
        if not fuzzy_match_fields(data.get('first_name').lower(),passport_data.get('passport_given_name').lower()):
            data_consistency['breakdown']['first_name']['result'] = 'consider'
        
        if not fuzzy_match_fields(data.get('gender').lower(),passport_data.get('passport_gender').lower()):
            data_consistency['breakdown']['gender']['result'] = 'consider'

        if not fuzzy_match_fields(data.get('last_name').lower(),passport_data.get('passport_surname').lower()):
            data_consistency['breakdown']['last_name']['result'] = 'consider'

    if country == 'UAE':
        
        data_consistency['breakdown']['document_type']['result'] = 'clear'
        if data.get('id_number', '') and data.get('id_number_mrz', ''):
            if data.get('id_number', '') != data.get('id_number_mrz', ''):
                data_consistency['breakdown']['multiple_data_sources_present']['result'] = 'consider'
    
    if country == 'IRQ':
        data_consistency['breakdown']['document_type']['result'] = 'clear'

        if data.get('doc_type') == 'national_identity_card':
            front_id_number = data.get('id_number', '')
            back_id_number = data.get('id_number_mrz', '')
            
            logging.info(f'Front ID Number: {front_id_number}')
            logging.info(f'Back ID Number: {back_id_number}')

            if front_id_number and back_id_number:
                if front_id_number != back_id_number:
                    data_consistency['breakdown']['multiple_data_sources_present']['result'] = 'consider'

    if country == 'QAT':
        data_consistency['breakdown']['gender']['result'] = 'clear'
        data_consistency['breakdown']['last_name']['result'] = 'clear'
        data_consistency['breakdown']['first_name']['result'] = 'clear'
        data_consistency['breakdown']['nationality']['result'] = 'clear'
        data_consistency['breakdown']['date_of_birth']['result'] = 'clear'
        data_consistency['breakdown']['document_type']['result'] = 'clear'
        data_consistency['breakdown']['date_of_expiry']['result'] = 'clear'
        data_consistency['breakdown']['issuing_country']['result'] = 'clear'
        data_consistency['breakdown']['document_numbers']['result'] = 'clear'
        data_consistency['breakdown']['multiple_data_sources_present']['result'] = 'clear'

        # Future Expiry Duration Check (5 yrs / 10 yrs from today)
        expiry_date = data.get('expiry_date', '')
        card_type = data.get('card_type', '')
        if expiry_date and card_type:
            try:
                exp_dt = datetime.strptime(expiry_date, "%d/%m/%Y")
                today = datetime.today()
                diff_days = (exp_dt - today).days
                logging.info(
                    f"[QAT data_consistency] Checking future expiry duration: card_type={card_type}, "
                    f"expiry_date={expiry_date}, days_until_expiry={diff_days}"
                )
                # Using 366 days/yr to safely account for leap years
                if card_type == "national_id" and diff_days > (10 * 366):
                    data_consistency['breakdown']['date_of_expiry']['result'] = 'consider'
                    logging.info(f"[QAT data_consistency] FAIL: National ID expiry ({expiry_date}) exceeds 10 years from today.")
                elif card_type == "residency_permit" and diff_days > (5 * 366):
                    data_consistency['breakdown']['date_of_expiry']['result'] = 'consider'
                    logging.info(f"[QAT data_consistency] FAIL: Residency Permit expiry ({expiry_date}) exceeds 5 years from today.")
                else:
                    logging.info(f"[QAT data_consistency] PASS future expiry duration check")
            except Exception as e:
                logging.info(f"[QAT data_consistency] Error checking future expiry duration: {e}")

        # DOB year match + Century rule + Nationality code checks
        dob = data.get('dob', '')
        id_number_check = data.get('id_number', '')
        if dob and id_number_check and len(id_number_check) >= 6:
            # DOB year match: last 2 digits of DOB year must equal id_number[1:3]
            try:
                dob_year_suffix = dob[8:10]  # last 2 digits of year from DD/MM/YYYY
                logging.info(
                    f"[QAT data_consistency] Checking DOB year match: "
                    f"dob_year_suffix={dob_year_suffix} vs id_number[1:3]={id_number_check[1:3]}"
                )
                if dob_year_suffix != id_number_check[1:3]:
                    data_consistency['breakdown']['date_of_birth']['result'] = 'consider'
                    logging.info(
                        f"[QAT data_consistency] FAIL DOB year mismatch: "
                        f"id_number[1:3]={id_number_check[1:3]} != dob_year_suffix={dob_year_suffix}"
                    )
                else:
                    logging.info(f"[QAT data_consistency] PASS DOB year match: {dob_year_suffix} == {id_number_check[1:3]}")
            except Exception as e:
                logging.info(f"[QAT data_consistency] Error in DOB year match check: {e}")

            # Century rule: first digit of ID determines century of birth year
            try:
                first_digit = id_number_check[0]
                dob_year = int(dob[6:10])
                logging.info(
                    f"[QAT data_consistency] Checking century rule: "
                    f"id_number[0]={first_digit}, dob_year={dob_year} "
                    f"(expected: 2\u21921900-1999, 3\u21922000-2099)"
                )
                if first_digit == "2" and not (1900 <= dob_year <= 1999):
                    data_consistency['breakdown']['date_of_birth']['result'] = 'consider'
                    logging.info(f"[QAT data_consistency] FAIL century rule: first_digit=2 but dob_year={dob_year} not in 1900-1999")
                elif first_digit == "3" and not (2000 <= dob_year <= 2099):
                    data_consistency['breakdown']['date_of_birth']['result'] = 'consider'
                    logging.info(f"[QAT data_consistency] FAIL century rule: first_digit=3 but dob_year={dob_year} not in 2000-2099")
                else:
                    logging.info(f"[QAT data_consistency] PASS century rule: id_number[0]={first_digit}, dob_year={dob_year}")
            except Exception as e:
                logging.info(f"[QAT data_consistency] Error in century rule check: {e}")

            # Nationality code: id_number[3:6] must be a valid code in nationality.py mapping
            try:
                from idvpackage.nationality import nationality_mapping
                numeric_code_str = id_number_check[3:6]
                logging.info(
                    f"[QAT data_consistency] Checking nationality code: "
                    f"id_number[3:6]={numeric_code_str} vs nationality_mapping"
                )
                if numeric_code_str not in nationality_mapping:
                    data_consistency['breakdown']['nationality']['result'] = 'consider'
                    logging.info(f"[QAT data_consistency] FAIL nationality code: {numeric_code_str} not in mapping")
                else:
                    logging.info(f"[QAT data_consistency] PASS nationality code: id_number[3:6]={numeric_code_str} is valid")
            except Exception as e:
                logging.info(f"[QAT data_consistency] Error in nationality code check: {e}")

        id_number = data.get('id_number', '')
        serial_number = data.get('serial_number', '')

        logging.info(f'ID Number: {id_number}')
        logging.info(f'Serial Number: {serial_number}')
        
        
        id_number_from_sr_no = ""

        id_number_from_sr_no = serial_number[-11:]

        logging.info(f'ID Number from front: {id_number}')
        logging.info(f'ID Number from back serial number: {id_number_from_sr_no}')

        if id_number == id_number_from_sr_no:
            logging.info(f'ID numbers match from front and back')
            data_consistency['breakdown']['multiple_data_sources_present']['result'] = 'clear'
        else:
            logging.info(f'Matching face from front and back')
            ## match faces from front and back
            from idvpackage.common import load_and_process_image_deepface, extract_face_and_compute_similarity
            front_face_locations, front_face_encodings = data.get('front_face_locations', []), data.get('front_face_encodings', [])
            
            try:
                back_base64_encoded = base64.b64encode(back_img).decode("utf-8")
                back_face_locations, back_face_encodings = load_and_process_image_deepface(back_base64_encoded)
                similarity = extract_face_and_compute_similarity(front_face_locations, front_face_encodings, back_face_locations, back_face_encodings)
                logging.info(f'Similarity - front back: {similarity}')
            except Exception as e:
                logging.error(f'Error: {e}')
                similarity = 0.0
                
            face_match = True if similarity >= 0.65 else False

            if face_match:
                data_consistency['breakdown']['multiple_data_sources_present']['result'] = 'clear'
            else:
                data_consistency['breakdown']['multiple_data_sources_present']['result'] = 'consider'

            
        

    if country in ['LBN', 'SDN', 'SYR', 'JOR', 'PSE']:
        data_consistency['breakdown']['document_type']['result'] = 'clear'

    data_consistency['result'] = 'clear'
    result = create_final_result(data_consistency)    
    data_consistency['result'] = result

    if country == 'QAT' and data_consistency['breakdown']['multiple_data_sources_present']['result'] != 'consider':
        data_consistency['result'] = 'clear'
    
    logging.info(f"---------------------------- DATA CONSISTENCY: {data_consistency}")

    return data_consistency

def normalize_name_parts(name_parts):
    cleaned = []
    for part in name_parts:
        # split on any non-letter characters #use . as well
        tokens = re.split(r'[^A-Za-z]+', part)
        cleaned.extend(token for token in tokens if token)
    return cleaned

def get_name_match_mrz(data, doc_type):
    from rapidfuzz import fuzz

    nationality = data.get('nationality', '')
    country = data.get('country', '')

    # --- Extract name_mrz ---
    name_mrz = []
    if doc_type != 'passport' and (nationality == 'SDN' or country == 'UAE'):
        for word in data.get("mrz3", "").split("<"):
            if word and word.isalpha():
                name_mrz.append(word)

    elif doc_type == 'passport' and (nationality in ['SDN', 'LBN', 'JOR', 'IRQ', 'PSE', 'SYR'] or country == 'IRQ'):
        mrz1 = data.get('mrz1', '')
        logging.info(f"MRZ1 extracted: {mrz1}")
        if mrz1:
            mrz1 = mrz1[5:]  # skip leading 'P' + country code (e.g. 'PSYR')
            logging.info(f"Processed MRZ1: {mrz1}")
            for word in mrz1.split("<"):
                if word and word.isalpha():
                    name_mrz.append(word)

    # --- Extract name from document fields ---
    name_field_map = {
        'SDN': lambda dat: dat.get('full_name_generic', ''),
        'LBN': lambda dat: dat.get('last_name', '') + ' ' + dat.get('first_name', ''),
        'JOR': lambda dat: dat.get('name', ''),
        'PSE': lambda dat: dat.get('full_name_openai', ''),
        'SYR': lambda dat: dat.get('full_name', ''),
    }

    if nationality in name_field_map:
        name = name_field_map[nationality](data)
    elif country == 'IRQ':
        name = data.get('full_name', '')
    elif country == 'UAE':
        name = data.get('name', '')
    else:
        logging.warning(f"No name extraction rule for nationality={nationality!r}, country={country!r}")
        return False, ''

    logging.info(f"Name extracted from ID: {name!r}, name_mrz: {name_mrz}")

    # --- Guard: nothing to compare ---
    if not name or not name_mrz:
        logging.warning(f"Name or MRZ name is empty — skipping comparison. name={name!r}, name_mrz={name_mrz}")
        return False, ' '.join(name_mrz)

    try:
        name_parts = normalize_name_parts(name.split(' '))
        name_mrz_parts = normalize_name_parts(name_mrz)
        logging.info(f"Name parts after removing special chars - Card: {name_parts}, MRZ: {name_mrz_parts}")

        # Use the shorter list as the reference — each token finds its best match
        # in the longer list, so extra tokens on either side don't cause false mismatches
        shorter = name_parts if len(name_parts) <= len(name_mrz_parts) else name_mrz_parts
        longer  = name_mrz_parts if len(name_parts) <= len(name_mrz_parts) else name_parts
        logging.info(f"Shorter list: {shorter}, Longer list: {longer}")

        count = 0
        for token in shorter:
            best_ratio = max(
                (fuzz.ratio(token.lower(), candidate.lower()) for candidate in longer),
                default=0,
            )
            logging.info(f"Token: {token!r}, best match ratio in longer list: {best_ratio}")
            if best_ratio < 70:
                count += 1

        flag = count < 2
        logging.info(f"Total non-matching name parts: {count}, Final flag: {flag}, Name from MRZ: {' '.join(name_mrz_parts)}")
        return flag, ' '.join(name_mrz_parts)

    except Exception as e:
        logging.error(f"Error comparing name against MRZ: {e}")
        return False, ' '.join(name_mrz)

def is_age_18_above(dob_str):
    """Check if the person is 18 or older as of today"""
    date_formats = ["%Y-%m-%d", "%d.%m.%Y", "%Y/%m/%d", "%d/%m/%Y", "%d-%m-%Y"]

    for fmt in date_formats:
        try:
            dob = datetime.strptime(dob_str, fmt)
            today = datetime.today()
            logging.info(f"Date of Birth: {dob}, Today's date: {today}")
            age = today.year - dob.year - ((today.month, today.day) < (dob.month, dob.day))
            return age >= 18
        except ValueError:
            continue

    # If we get here, none of the formats matched
    logging.warning(f"Could not parse date: {dob_str}")
    return False

def is_expired_id(expiry_date):
    """
    Checks if an ID is expired.

    Parameters:
    expiry_date (str): Expiry date in 'YYYY-MM-DD', 'DD.MM.YYYY', or 'YYYY/MM/DD' format.

    Returns:
    bool: True if the passport is expired, False otherwise.
    """
    date_formats = ["%Y-%m-%d", "%d.%m.%Y", "%Y/%m/%d", "%d/%m/%Y", "%d-%m-%Y"]

    for fmt in date_formats:
        try:
            expiry = datetime.strptime(expiry_date, fmt).date()
            today = datetime.today().date()

            logging.info(f"Expiry date: {expiry}, Today's date: {today}")
            return expiry < today
        except ValueError:
            continue

    return True  # If no format matches, assume expired (or invalid date)

def get_dates_to_generic_format(date):
    formats = ["%d/%m/%Y", "%Y/%m/%d", "%Y-%m-%d", "%d-%m-%Y"]
    for fmt in formats:
        try:
            return datetime.strptime(date, fmt).strftime("%d/%m/%Y")
        except ValueError:
            continue
    return date

def onfido_date_format(date):
    logging.info(f"Original date: {date}")
    formats = ["%d/%m/%Y", "%Y/%m/%d"]
    for fmt in formats:
        try:
            logging.info(f"Trying format: {fmt}")
            return datetime.strptime(date, fmt).strftime("%Y-%m-%d")
        except ValueError:
            continue
    return date

def data_validation_check(data, country):
    data_validation = DATA_VALIDATION
    data_validation = mark_clear(data_validation, ['breakdown', 'result'])

    try:
        dob = data.get('dob')
        dob = get_dates_to_generic_format(dob)
        parsed_date = datetime.strptime(dob, "%d/%m/%Y")
        data_validation["breakdown"]['date_of_birth']["result"] = 'clear'
    except:
        try:
            dob = data.get('dob')
            parsed_date = datetime.strptime(dob, "%Y-%m-%d")
            data_validation["breakdown"]['date_of_birth']["result"] = 'clear'
        except:
            data_validation["breakdown"]['date_of_birth']["result"] = 'consider'

    try:
        doe = data.get('expiry_date')
        doe = get_dates_to_generic_format(doe)
        parsed_date = datetime.strptime(doe, "%d/%m/%Y")
        data_validation["breakdown"]['expiry_date']["result"] = 'clear'
    except:
        try:
            doe = data.get('expiry_date')
            parsed_date = datetime.strptime(doe, "%Y-%m-%d")
            data_validation["breakdown"]['expiry_date']["result"] = 'clear'
        except:
            data_validation["breakdown"]['expiry_date']["result"] = 'consider'

    gender = data.get('gender', '')
    
    if gender.isalpha() and (gender.lower()=='male' or gender.lower()=='female' or gender.lower()=='m' or gender.lower()=='f'):
        data_validation["breakdown"]['gender']["result"] = 'clear'
    else:
        data_validation["breakdown"]['gender']["result"] = 'consider'
    
    if country == 'LBN' and data.get('doc_type') == 'national_identity_card':
        data_validation["breakdown"]['expiry_date']["result"] = 'clear'
        data_validation['breakdown']['valid_nationality']["result"] = 'clear'
        data_validation['breakdown']['document_expiration']["result"] = 'clear'
    else:
        data_validation['breakdown']['valid_nationality']["result"] = data.get('valid_nationality')

    if country in ['SDN', 'SYR', 'JOR', 'PSE']:
        data_validation['breakdown']['valid_nationality']["result"] = data.get('valid_nationality')
        data_validation["breakdown"]['document_numbers']["result"] = 'clear'

    if country == 'UAE' or country == 'IRQ':
        if data.get('doc_type') == 'national_identity_card':
            doc_no = data.get('card_number', '')
            if len(doc_no)==9:
                data_validation["breakdown"]['document_numbers']["result"] = 'clear'
            else:
                data_validation["breakdown"]['document_numbers']["result"] = 'consider'
        else:
            data_validation["breakdown"]['document_numbers']["result"] = 'clear'

    doe = data.get('expiry_date', '')
    expiry_result = is_valid_and_not_expired(get_dates_to_generic_format(doe), country)
    data_validation['breakdown']['document_expiration']["result"] = expiry_result

    mrz = data.get('mrz', '')
    mrz1 = data.get('mrz1', '')
    mrz2 = data.get('mrz2', '')
    mrz3 = data.get('mrz3', '')

    logging.info(f"\n\n---------------- MRZ DATA: mrz: {mrz}, mrz1: {mrz1}, mrz2: {mrz2}, mrz3: {mrz3}")
    if data.get('doc_type') == 'passport':
        if mrz and mrz1 and mrz2:
            data_validation["breakdown"]['mrz']["result"] = 'clear'
        else:
            data_validation["breakdown"]['mrz']["result"] = 'consider'
    else:
        if not data.get('uae_pass_data', ''):
            if len(mrz) == 1 and mrz1 and mrz2 and mrz3:
                data_validation["breakdown"]['mrz']["result"] = 'clear'
            else:
                data_validation["breakdown"]['mrz']["result"] = 'consider'
        else:
            data_validation["breakdown"]['mrz']["result"] = 'clear'

    if country == 'LBN' and data.get('doc_type') == 'national_identity_card':
        doc_no = data.get('id_number', '')
        if len(doc_no)>=10 and len(doc_no)<13:
            data_validation["breakdown"]['document_numbers']["result"] = 'clear'
        else:
            data_validation["breakdown"]['document_numbers']["result"] = 'consider'
        
        data_validation["breakdown"]['mrz']["result"] = 'clear'

    if country == 'QAT':
        data_validation["breakdown"]['document_numbers']["result"] = 'clear'
        data_validation["breakdown"]['gender']["result"] = 'clear'
        data_validation["breakdown"]['mrz']["result"] = 'clear'
        data_validation["breakdown"]['document_expiration']["result"] = 'clear'
        data_validation['breakdown']['valid_nationality']["result"] = 'clear'
        data_validation["breakdown"]['date_of_birth']["result"] = 'clear'
        data_validation["breakdown"]['expiry_date']["result"] = 'clear'

    if country == 'IRQ' and data.get('doc_type') == 'national_identity_card' and not data.get('card_number'):
        doc_no = data.get('card_number', '')
        if len(doc_no)==9:
            data_validation["breakdown"]['document_numbers']["result"] = 'clear'
        else:
            data_validation["breakdown"]['document_numbers']["result"] = 'consider'

    logging.info(f"\n\n------------------------- DATA VAL: {data_validation}")
    
    ## set default to avoid any problems of cache
    data_validation['result'] = 'clear'

    logging.info(f"Country specific data validation checks started for country and doc: {country}")

    if country == 'SDN' and data.get('doc_type','') == "passport":

        logging.info(f"SDN Passport data validation check started")

        logging.info(f"SDN Passport date of birth comparison between dob: {data.get('dob','')} and dob_mrz: {data.get('dob_mrz','')}")
        if data.get('dob','') == data.get('dob_mrz',''):
            data_validation['breakdown']['date_of_birth']['result'] = 'clear'
        else:
            data_validation['breakdown']['date_of_birth']['result'] = 'consider'

        logging.info(f"SDN Passport date of expiry comparison between expiry_date: {data.get('expiry_date','')} and expiry_date_mrz: {data.get('expiry_date_mrz','')}")

        if data.get('expiry_date','') == data.get('expiry_date_mrz',''):
            data_validation['breakdown']['expiry_date']['result'] = 'clear'
        else:
            data_validation['breakdown']['expiry_date']['result'] = 'consider'

    result = create_final_result(data_validation)
    data_validation['result'] = result

    
    return data_validation

## pending
def image_integrity_check(data, front_id_text, back_id_text, coloured, blurred, glare, missing_fields, country):
    image_integrity = IMAGE_INTEGRITY
    image_integrity = mark_clear(image_integrity, ['breakdown', 'result'])


    image_integrity['breakdown']['colour_picture']['result'] = coloured
    image_integrity['breakdown']['conclusive_document_quality']['properties']['corner_removed'] = is_valid_and_not_expired(get_dates_to_generic_format(data.get('expiry_date', '')), country)
    image_integrity['breakdown']['conclusive_document_quality']['properties']['abnormal_document_features'] = blurred
    image_integrity['breakdown']['image_quality']['properties']['blurred_photo'] = blurred
    image_integrity['breakdown']['image_quality']['properties']['covered_photo'] = missing_fields
    image_integrity['breakdown']['image_quality']['properties']['cut_off_document'] = missing_fields
    image_integrity['breakdown']['image_quality']['properties']['glare_on_photo'] = glare
    image_integrity['breakdown']['image_quality']['properties']['other_photo_issue'] =  missing_fields
    
    ## set default to avoid any problems of cache
    image_integrity['breakdown']['image_quality']['result'] = 'clear'

    image_quality_result = create_final_result(image_integrity['breakdown']['image_quality'])
    image_integrity['breakdown']['image_quality']['result'] = image_quality_result

    f_result = True
    front_doc_on_pp = data.get('front_doc_on_pp')

    if country == 'UAE' and not data.get('uae_pass_data', ''):
        logging.info(f"UAE Image integrity check for ID card or passport {back_id_text}")
        b_result = True
        logging.info(f"UAE back id result: {b_result}")

        if back_id_text and b_result:
            image_integrity['breakdown']['conclusive_document_quality']['properties']['missing_back'] = 'clear'
        else:
            image_integrity['breakdown']['conclusive_document_quality']['properties']['missing_back'] = 'consider'

        if f_result and b_result:
            image_integrity['breakdown']['supported_document']['result'] = 'clear'
        else:
            image_integrity['breakdown']['supported_document']['result'] = 'consider'

    if country == 'IRQ' and data.get('doc_type') == 'national_identity_card':
        image_integrity['breakdown']['conclusive_document_quality']['properties']['missing_back'] = 'clear'
        image_integrity['breakdown']['supported_document']['result'] = 'clear'
        
    elif country == 'IRQ' and data.get('doc_type') == 'passport':
        image_integrity['breakdown']['conclusive_document_quality']['properties']['missing_back'] = 'clear'
        if 'passport' and ('iraq' or 'republic of iraq') in data.get('passport_data').lower():
            image_integrity['breakdown']['supported_document']['result'] = 'clear'

    if country == 'LBN' and data.get('doc_type') == 'national_identity_card':
        image_integrity['breakdown']['conclusive_document_quality']['properties']['missing_back'] = 'clear'
        image_integrity['breakdown']['supported_document']['result'] = 'clear'


    elif country == 'LBN' and data.get('doc_type') == 'passport':
        image_integrity['breakdown']['conclusive_document_quality']['properties']['missing_back'] = 'clear'
        if 'passport' and ('lebanon' or 'republic of lebanon') in data.get('passport_data').lower():
            image_integrity['breakdown']['supported_document']['result'] = 'clear'

    image_integrity['breakdown']['conclusive_document_quality']['properties']['watermarks_digital_text_overlay'] = data.get('front_logo_result')
   
    if country == 'QAT':
        image_integrity['breakdown']['image_quality']['properties']['blurred_photo'] = 'clear'
        image_integrity['breakdown']['image_quality']['properties']['covered_photo'] = 'clear'
        image_integrity['breakdown']['image_quality']['properties']['cut_off_document'] = 'clear'
        image_integrity['breakdown']['image_quality']['properties']['glare_on_photo'] = 'clear'
        image_integrity['breakdown']['image_quality']['properties']['other_photo_issue'] =  'clear'

        image_integrity['breakdown']['colour_picture']['result'] = 'clear'

        image_integrity['breakdown']['supported_document']['result'] = 'clear'

        image_integrity['breakdown']['conclusive_document_quality']['properties']['watermarks_digital_text_overlay'] = 'clear'
        image_integrity['breakdown']['conclusive_document_quality']['properties']['missing_back'] = 'clear'
        image_integrity['breakdown']['conclusive_document_quality']['properties']['corner_removed'] = 'clear'
        image_integrity['breakdown']['conclusive_document_quality']['properties']['abnormal_document_features'] = 'clear'
        
        logging.info(f'front_photo_on_screen_result: {data.get("front_photo_on_screen_result")}, back_photo_on_screen_result: {data.get("back_photo_on_screen_result")}')
        
        if data.get('front_photo_on_screen_result') == 'consider' or data.get('back_photo_on_screen_result') == 'consider':
            image_integrity['breakdown']['conclusive_document_quality']['properties']['digital_document'] = 'consider'
        else:
            image_integrity['breakdown']['conclusive_document_quality']['properties']['digital_document'] = 'clear'
            
        image_integrity['breakdown']['conclusive_document_quality']['properties']['punctured_document'] = 'clear'
        image_integrity['breakdown']['conclusive_document_quality']['properties']['obscured_data_points'] = 'clear'
        image_integrity['breakdown']['conclusive_document_quality']['properties']['obscured_security_features'] = 'clear'

    image_quality_result = create_final_result(image_integrity['breakdown']['image_quality'])
    conclusive_document_quality_result = create_final_result(image_integrity['breakdown']['conclusive_document_quality'])

    ## set default to avoid any problems of cache
    # image_integrity['breakdown']['conclusive_document_quality']["result"] = 'clear'

    image_integrity['breakdown']['conclusive_document_quality']["result"] = conclusive_document_quality_result

    
    back_doc_on_pp = data.get('doc_on_pp')
    if front_doc_on_pp == 'consider' or back_doc_on_pp == 'consider':
        image_integrity['breakdown']['conclusive_document_quality']['properties']['digital_document'] = 'consider'

    if  country == 'IRQ' or country == 'LBN':
        image_integrity['breakdown']['conclusive_document_quality']['properties']['digital_document'] = 'clear'

       

    if country in ['SDN', 'SYR', 'JOR', 'PSE']:
        image_integrity['breakdown']['supported_document']['result'] = 'clear'
        image_integrity['breakdown']['conclusive_document_quality']['properties']['missing_back'] = 'clear'
        image_integrity['breakdown']['image_quality']['properties']['cut_off_document'] = 'clear'
        image_integrity['breakdown']['image_quality']['properties']['other_photo_issue'] =  'clear'
        image_integrity['breakdown']['image_quality']['properties']['blurred_photo'] = blurred
        image_integrity['breakdown']['conclusive_document_quality']['properties']['digital_document'] = 'clear'

    # Recompute all sub-results from the final state of their properties,
    # so any late mutations (e.g. doc_on_pp, country overrides) are reflected.
    image_integrity['breakdown']['image_quality']['result'] = create_final_result(image_integrity['breakdown']['image_quality'])
    image_integrity['breakdown']['conclusive_document_quality']['result'] = create_final_result(image_integrity['breakdown']['conclusive_document_quality'])

    # Roll up to the top-level result — 'consider' if any breakdown sub-result is 'consider'
    image_integrity['result'] = create_final_result(image_integrity['breakdown'])

    logging.info(
        f"Image integrity sub-results — image_quality: {image_integrity['breakdown']['image_quality']['result']}, "
        f"conclusive_document_quality: {image_integrity['breakdown']['conclusive_document_quality']['result']}, "
        f"supported_document: {image_integrity['breakdown']['supported_document']['result']}, "
        f"colour_picture: {image_integrity['breakdown']['colour_picture']['result']} "
        f"→ overall result: {image_integrity['result']}"
    )

    # IRQ has no image integrity attributes extracted, bypass the result
    if country == 'IRQ':
        image_integrity['result'] = 'clear'

    logging.info(f"---------------------------- IMAGE INTEGRITY: {image_integrity}")

    return image_integrity

def visual_authenticity_check(data, front_id_text, back_id_text, selfie, facial_similarity, face_match_threshold, country):
    visual_authenticity = VISUAL_AUTHENTICITY
    visual_authenticity = mark_clear(visual_authenticity, ['breakdown', 'result'])

    if np.any(selfie):
        ## if facial similarity is matching the threshold or even if facial similarity comes above 40 then we say face was detected - approach can be changed
        logging.info(f'Facial similarity: {facial_similarity}, Threshold: {face_match_threshold}\n')
        if facial_similarity >= face_match_threshold:
            visual_authenticity['breakdown']['face_detection'] = 'clear'
            visual_authenticity['breakdown']['security_features'] = 'clear'
        else:
            visual_authenticity['breakdown']['face_detection'] = 'consider'
            visual_authenticity['breakdown']['security_features'] = 'consider'
    else:
        visual_authenticity['breakdown']['face_detection'] = ''
        visual_authenticity['breakdown']['security_features'] = ''
    
    front_doc_on_pp = data.get('front_doc_on_pp')
    front_screenshot = data.get('front_screenshot_result')
    front_photo_on_screen_result = data.get('front_photo_on_screen_result')

    if country != 'SAU':
        back_screenshot = data.get('screenshot_result')
        if front_screenshot == 'consider' or back_screenshot == 'consider':
            visual_authenticity['breakdown']['original_document_present']['properties']['screenshot'] = 'consider'

        back_photo_on_screen_result = data.get('photo_on_screen_result')
        if front_photo_on_screen_result == 'consider' or back_photo_on_screen_result == 'consider':
            visual_authenticity['breakdown']['original_document_present']['properties']['photo_of_screen'] = 'consider'

    if country == 'UAE' and not data.get('uae_pass_data', ''):
        visual_authenticity['breakdown']['original_document_present']['properties']['scan'] = 'clear'
        visual_authenticity['breakdown']['face_detection'] = 'clear'
        visual_authenticity['breakdown']['security_features'] = 'clear'
       
    if country == 'IRQ':
        if data.get('doc_type') == 'passport':
            visual_authenticity['breakdown']['original_document_present']['properties']['scan'] = 'clear'
        else:
            visual_authenticity['breakdown']['original_document_present']['properties']['scan'] = 'clear'
            visual_authenticity['breakdown']['template']['result'] = data.get('front_template_result')
            visual_authenticity['breakdown']['digital_tampering']['result'] = data.get('tampering_result')
            
    if country == 'LBN':
        visual_authenticity['breakdown']['original_document_present']['properties']['scan'] = 'clear'
        visual_authenticity['breakdown']['original_document_present']['properties']['screenshot'] = 'clear'
        visual_authenticity['breakdown']['digital_tampering']['result'] = 'clear'
        visual_authenticity['breakdown']['template']['result'] = 'clear'

    if country == 'QAT':
        visual_authenticity['breakdown']['original_document_present']['properties']['scan'] = 'clear'
        visual_authenticity['breakdown']['original_document_present']['properties']['screenshot'] = 'clear'
        if data.get('back_photo_on_screen_result') == 'consider' or data.get('front_photo_on_screen_result') == 'consider':
            visual_authenticity['breakdown']['original_document_present']['properties']['photo_of_screen'] = 'consider'
        else:
            visual_authenticity['breakdown']['original_document_present']['properties']['photo_of_screen'] = 'clear'
        visual_authenticity['breakdown']['original_document_present']['properties']['document_on_printed_paper'] = 'clear'
        visual_authenticity['breakdown']['digital_tampering']['result'] = 'clear'
        visual_authenticity['breakdown']['template']['result'] = 'clear'

    if country in ['SDN', 'SYR', 'JOR', 'PSE']:
        visual_authenticity['breakdown']['original_document_present']['properties']['scan'] = 'clear'
        visual_authenticity['breakdown']['original_document_present']['properties']['screenshot'] = 'clear'
        visual_authenticity['breakdown']['digital_tampering']['result'] = 'clear'
        visual_authenticity['breakdown']['template']['result'] = 'clear'

    original_document_present_result  = create_final_result(visual_authenticity['breakdown']['original_document_present'])
    visual_authenticity['breakdown']['original_document_present']['result'] = original_document_present_result

    ## set default to avoid any problems of cache
    visual_authenticity['result'] = 'clear'
    final_result = create_final_result(visual_authenticity)
    visual_authenticity['result'] = final_result

    back_doc_on_pp = data.get('doc_on_pp')
    if front_doc_on_pp == 'consider' or back_doc_on_pp == 'consider':
        visual_authenticity['breakdown']['original_document_present']['properties']['document_on_printed_paper'] = 'consider'

    # if country == 'QAT':
    #     visual_authenticity['breakdown']['original_document_present']['result'] = 'clear'
    #     visual_authenticity['breakdown']['original_document_present']['properties']['document_on_printed_paper'] = 'clear'
    #     visual_authenticity['result'] = 'clear'

    logging.info(f"---------------------------- VISUAL AUTHENTICITY: {visual_authenticity}")
    return visual_authenticity

def main_details(data, country):
    main_properties = {}
    import json
    main_properties['document_numbers']= []

    # remove "selfie" from data keys list for logging
    try:
        # Add handling for UAE Pass data
        uae_pass_data = data.get('uae_pass_data', {})
        if uae_pass_data and country == 'UAE':
            # Handle Emirates ID data
            if uae_pass_data.get('IDN'):
                id_data_t = {
                    "type": "type",
                    "value": "personal_number"
                }
                id_data_v = {
                    "type": "value",
                    "value": uae_pass_data['IDN']
                }
                main_properties['document_numbers'].append(id_data_t)
                main_properties['document_numbers'].append(id_data_v)
                main_properties['id_number'] = uae_pass_data['IDN']

            # Handle name fields
            if uae_pass_data.get('nameEn'):
                name_parts = uae_pass_data['nameEn'].split()
                # print(f"NAME PARTS: {name_parts}")
                if len(name_parts) >= 1:
                    main_properties['first_name'] = name_parts[0]
                    main_properties['last_name'] = name_parts[-1] if len(name_parts) > 1 else ''
                main_properties['name'] = uae_pass_data['nameEn']
                main_properties['name_ar'] = uae_pass_data.get('nameAr', '')

            # Handle other Emirates ID fields
            if uae_pass_data.get('nationalityEn'):
                main_properties['nationality'] = uae_pass_data['nationalityEn']
                main_properties['nationality_ar'] = uae_pass_data.get('nationalityAr', '')
                main_properties['nationality_code'] = uae_pass_data.get('nationalityCode', '')

            if uae_pass_data.get('genderEn'):
                main_properties['gender'] = uae_pass_data['genderEn']
                main_properties['gender_code'] = uae_pass_data.get('genderCode', '')

            if uae_pass_data.get('DateOfBirth'):
                main_properties['date_of_birth'] = onfido_date_format(get_dates_to_generic_format(uae_pass_data['DateOfBirth']))

            if uae_pass_data.get('expiryDate'):
                main_properties['date_of_expiry'] = onfido_date_format(get_dates_to_generic_format(uae_pass_data['expiryDate']))

            # Handle Resident Visa data
            if uae_pass_data.get('fileNumber'):
                file_number_t = {
                    "type": "type",
                    "value": "file_number"
                }
                file_number_v = {
                    "type": "value",
                    "value": str(uae_pass_data['fileNumber'])
                }
                main_properties['document_numbers'].append(file_number_t)
                main_properties['document_numbers'].append(file_number_v)
                main_properties['file_number'] = str(uae_pass_data['fileNumber'])

            if uae_pass_data.get('passportNumber'):
                passport_data_t = {
                    "type": "type",
                    "value": "passport_number"
                }
                passport_data_v = {
                    "type": "value",
                    "value": uae_pass_data['passportNumber']
                }
                main_properties['document_numbers'].append(passport_data_t)
                main_properties['document_numbers'].append(passport_data_v)
                main_properties['passport_number'] = uae_pass_data['passportNumber']

            # Additional Visa fields
            if uae_pass_data.get('professionEn'):
                main_properties['occupation'] = uae_pass_data['professionEn']
                main_properties['occupation_ar'] = uae_pass_data.get('professionAr', '')
                main_properties['profession_code'] = uae_pass_data.get('professionCode', '')

            if uae_pass_data.get('sponsorEn'):
                main_properties['family_sponsor'] = uae_pass_data['sponsorEn']
                main_properties['sponsor_ar'] = uae_pass_data.get('sponsorAr', '')
                main_properties['sponsor_number'] = uae_pass_data.get('sponsorNo', '')

            if uae_pass_data.get('issuePlaceEn'):
                main_properties['issuing_place'] = uae_pass_data['issuePlaceEn']
                main_properties['issuing_place_ar'] = uae_pass_data.get('issuePlaceAr', '')

            if uae_pass_data.get('dateOfIssue'):
                main_properties['issue_date'] = onfido_date_format(get_dates_to_generic_format(uae_pass_data['dateOfIssue']))

            # Additional fields
            main_properties['accompanied_by'] = uae_pass_data.get('AccompaniedBy', '')
            main_properties['document_type_code'] = uae_pass_data.get('documentTypeCode', '')
            main_properties['document_name_en'] = uae_pass_data.get('nameOfDocEn', '')
            main_properties['document_name_ar'] = uae_pass_data.get('nameOfDocAr', '')

            # Set document type based on available data
            if uae_pass_data.get('nameOfDocEn'):
                main_properties['document_type'] = uae_pass_data['nameOfDocEn'].lower().replace(' ', '_')
            else:
                main_properties['document_type'] = 'national_identity_card'

            return main_properties

        dob = get_dates_to_generic_format(data.get('dob'))
        doe = get_dates_to_generic_format(data.get('expiry_date', ''))
        main_properties['date_of_birth'] = onfido_date_format(dob)
        main_properties['date_of_expiry'] = onfido_date_format(doe)

        if data.get('card_number'):
            card_data_t = {
            "type": "type",
            "value": "document_number"
            }

            card_data_v = {
                "type": "value",
                "value": data['card_number']
            }

            main_properties['document_numbers'].append(card_data_t)
            main_properties['document_numbers'].append(card_data_v)

        if data.get('id_number'):
            id_data_t = {
                        "type": "type",
                        "value": "personal_number"
                    }
            id_data_v = {
                        "type": "value",
                        "value": data['id_number']
                    }
                
            main_properties['document_numbers'].append(id_data_t) 
            main_properties['document_numbers'].append(id_data_v)

        elif data.get('passport_number', None):
            id_data_t = {
                "type": "type",
                "value": "personal_number"
            }
            id_data_v = {
                "type": "value",
                "value": data['passport_number']
            }

            main_properties['document_numbers'].append(id_data_t)
            main_properties['document_numbers'].append(id_data_v)


        else:
            id_data_t = {
                        "type": "type",
                        "value": "personal_number"
                    }
            id_data_v = {
                        "type": "value",
                        "value": ""
                    }
                
            main_properties['document_numbers'].append(id_data_t) 
            main_properties['document_numbers'].append(id_data_v)

        if country == 'JOR':
            id_data_t = {
                "type": "type",
                "value": "personal_number"
            }
            id_data_v = {
                "type": "value",
                "value": data.get('passport_number','')
            }

            main_properties['document_numbers'].append(id_data_t)
            main_properties['document_numbers'].append(id_data_v)

      

        keys = ['name', 'first_name', 'gender', 'issuing_place', 'last_name', 'nationality', 'issuing_country', 'occupation', 'employer', 'family_sponsor']

        main_properties['document_type'] = data.get('doc_type', '')
        main_properties['mrz_line1'] = data.get('mrz1', '')
        main_properties['mrz_line2'] = data.get('mrz2', '')
        main_properties['mrz_line3'] = data.get('mrz3', '')

        for key in keys:
            main_properties[key] = data.get(key, '')
        
        logging.info(f"Extracted main properties before country specific adjustments: {country}")
        if country in ['IRQ', 'LBN', 'QAT', 'SDN', 'SYR', 'JOR', 'PSE', 'UAE']:

            if country == 'UAE':
                main_prop_data = {}
                if data.get('doc_type') == 'national_identity_card':
                    keys = ['dob_mrz', 'expiry_date_mrz', 'id_number_mrz', 'name_mrz', 'card_number_mrz','is_name_match_mrz',
                            'id_number_front_back_mrz_match','card_number_back_mrz_match','dob_mrz_match','expiry_date_mrz_match','gender_mrz_match','name_mrz_match'
                            ]
                    keys_to_remove = []
            if country == 'IRQ':
                main_prop_data = {}
                if data.get('doc_type') == 'passport':
                    logging.info(f"Extracting main details for IRQ passport")
                    keys_to_remove = ['issuing_place', 'occupation', 'employer', 'mrz_line3', 'family_sponsor', 'issuing_authority_en', 'place_of_birth_en', 'gender_ar', 'name_en', 'name', 'first_name']
                    keys = ['full_name', 'id_number', 'mrz', 'issue_date','issuing_authority', 'mother_name', 'place_of_birth', 'mother_first_name', 'mother_first_name_en', 'mother_last_name',
                             'mother_last_name_en','expiry_date_mrz','dob_mrz', 'gender_mrz','id_number_mrz','name_mrz','is_name_match_mrz',
                            'is_dob_match_mrz', 'is_id_number_match_mrz','is_expiry_date_match_mrz','is_valid_id_duration','is_valid_id_duration_mrz','is_gender_mrz_match']
                else:
                    keys_to_remove = ['occupation', 'employer', 'family_sponsor', 'issuing_place']
                    keys = ['name_en', 'name', 'first_name', 'father_name', 'third_name', 'mother_first_name', 'mother_last_name', 
                            'last_name', 'first_name_en', 'father_name_en', 'last_name_en', 'third_name_en', 'mother_first_name_en',
                            'mother_last_name_en', 'issuing_authority', 'nationality', 'gender', 'issuing_country', 'gender_ar', 'mrz',
                            'place_of_birth', 'issuing_authority_en', 'place_of_birth_en', "issue_date", "id_number", "card_number", 'family_number', 'family_number_en',
                            'card_number_mrz', 'id_number_mrz', 'valid_id_duration_mrz', 'dob_back_and_mrz_match', 'exp_date_back_and_mrz_match', 'gender_front_and_back_match', 'id_number_front_back_match']

            if country == 'LBN':
                main_prop_data = {}
                keys_to_remove = ['name', 'issuing_place', 'occupation', 'employer', 'mrz_line3', 'family_sponsor']
                if data.get('doc_type') == 'passport':
                    keys = ['first_name', 'first_name_en','father_name', 'father_name_en','mother_name', 'mother_first_name','mother_last_name','mother_name_en', 'mother_first_name_en', 'mother_last_name_en', 'last_name', 'id_number', 'issue_date', 'mrz', 'issuing_country', 'registry_place_and_number', 
                            'place_of_birth', 'nationality','id_number_mrz','name_mrz', 'dob_mrz', 'expiry_date_mrz',
                            'is_dob_match_mrz','is_id_number_match_mrz','is_expiry_date_match_mrz','is_valid_id_duration','is_valid_id_duration_mrz','is_name_match_mrz']
                else:
                    # keys = ['father_name', 'last_name', 'name_en', 'first_name_en', 'fathers_name_en', 'last_name_en', 'gender_ar', 'place_of_birth', 'issue_date', 'issue_date_ar', 'card_number_ar', 'id_number_ar']
                    keys = ['name', 'name_en', 'first_name', 'father_name', 'last_name', 'first_name_en', 'father_name_en', 'last_name_en', 
                            'mother_name_en','mother_name','mother_first_name','mother_last_name','mother_first_name_en','mother_last_name_en','gender_ar', 'place_of_birth', 'place_of_birth_en', 'issue_date', 'issue_date_ar', 'card_number_ar', 'id_number_ar', 
                            'issuing_country', 'nationality']
                    keys_to_remove = ['issuing_place', 'mrz_line1', 'mrz_line2', 'mrz_line3', 'family_sponsor', 'nationality', 'occupation', 'employer']

            if country == 'QAT':
                main_prop_data = {}
                keys_to_remove = ['gender', 'issuing_place', 'mrz_line1', 'mrz_line2', 'mrz_line3', 'name_en', 'family_sponsor']
                keys = ['passport_number', 'name_ar', 'passport_expiry', 'occupation', 'employer', 'employer_en', 'occupation_en',"serial_number", "address_ar","address_en"]
            
            if country == 'SDN':
                main_prop_data = {}
                keys_to_remove = ['name', 'issuing_place', 'employer','mrz_line3', 'family_sponsor', 'first_name', 'last_name', 'father_name', 'mother_name']
                if data.get('doc_type') == 'passport':

                    keys = ['full_name_generic', 'name_ar', 'first_name', 'last_name', 'middle_name', 'first_name_ar', 'last_name_ar', 'middle_name_ar',
                            'issuance_date', 'gender', 'place_of_birth', 'place_of_issue',  'national_number', 'issue_date', 'mrz', 'nationality', 'issuing_country',
                            'passport_number_mrz','name_mrz', 'dob_mrz', 'expiry_date_mrz','gender_mrz',
                            'is_valid_id_duration','is_valid_id_duration_mrz','is_passport_number_match_mrz','is_dob_match_mrz','is_gender_mrz_match','is_name_match_mrz']
                else:
                    # keys = ['father_name', 'last_name', 'name_en', 'first_name_en', 'fathers_name_en', 'last_name_en', 'gender_ar', 'place_of_birth', 'issue_date', 'issue_date_ar', 'card_number_ar', 'id_number_ar']
                    keys = ['full_name_generic', 'name', 'name_ar', 'nationality', 'gender', 'place_of_birth', 'place_of_birth_en', 'id_number', 'issuance_date',
                            'first_name_ar','last_name_ar','middle_name_ar','occupation', 'occupation_en', 'occupation_ar','issue_date', 'first_name', 'middle_name', 'last_name',
                              'issuing_country','expiry_date_mrz','date_of_birth_mrz', 'gender_mrz','valid_id_duration','valid_id_duration_mrz',
                            'is_expiry_date_same_mrz', 'is_dob_front_back_mrz_match','is_dob_front_back_match','name_mrz','is_name_match_mrz','is_gender_mrz_match']

                    keys_to_remove = ['issuing_place', 'family_sponsor', 'employer', 'first_name', 'last_name', 'father_name', 'mother_name', 'place_of_issue']

            if country == 'JOR':
                main_prop_data = {}
                keys_to_remove = ['name', 'occupation', 'employer', 'mrz_line3', 'family_sponsor']
                if data.get('doc_type') == 'passport':
                    keys = ['full_name', 'first_name', 'last_name', 'father_name', 'mother_name', 'place_of_birth', 'dob', 'issuing_date', 'nationality', 'gender', 'place_of_issue',
                             'passport_national_number', 'mrz1', 'mrz2', 'mrz', 'issuing_country',
                             'passport_number_mrz','name_mrz', 'dob_mrz', 'expiry_date_mrz','gender_mrz',
                            'is_valid_id_duration','is_valid_id_duration_mrz','is_passport_number_match_mrz','is_dob_match_mrz','is_gender_mrz_match','is_name_match_mrz']

            if country == 'SYR':
                main_prop_data = {}
                keys_to_remove = ['name', 'issuing_place', 'occupation', 'employer', 'mrz_line3', 'family_sponsor', 'issuing_country']
                if data.get('doc_type') == 'passport':
                    keys = ['full_name', 'first_name', 'last_name', 'father_name', 'mother_name', 'place_of_birth', 'place_of_issue', 'dob', 'nationality', 'gender', 'passport_number', 'issue_number', 
                            'issuing_date', 'national_number', 'mrz1', 'mrz2', 'mrz', 'issuing_country',
                             'passport_number_mrz','name_mrz', 'dob_mrz', 'expiry_date_mrz','gender_mrz',
                            'is_valid_id_duration','is_valid_id_duration_mrz','is_passport_number_match_mrz','is_dob_match_mrz','is_gender_mrz_match','is_name_match_mrz','is_national_number_mrz_match']


            if country == 'PSE':
                main_prop_data = {}
                keys_to_remove = ['name', 'issuing_place', 'occupation', 'employer', 'mrz_line3', 'family_sponsor']
                if data.get('doc_type') == 'passport':
                    keys = ['full_name', 'first_name', 'last_name', 'mother_name', 'place_of_birth', 'dob', 'issuing_date', 'nationality', 'gender',
                            'place_of_issue', 'passport_number', 'id_number', 'mrz1', 'mrz2', 'mrz', 'issuing_country',
                             'passport_number_mrz','name_mrz', 'dob_mrz', 'expiry_date_mrz','gender_mrz',
                            'is_valid_id_duration','is_valid_id_duration_mrz','is_passport_number_match_mrz','is_dob_match_mrz','is_gender_mrz_match','is_name_match_mrz']

            for key in keys:
                main_prop_data[key] =  data.get(key, '')

            logging.info(f"Main properties before removal: {main_prop_data.keys()}")
            if keys_to_remove:
                for key in keys_to_remove:
                    if key in main_properties:
                        del main_properties[key]

            main_properties.update(main_prop_data)

            if main_properties.get('issue_date', ''):
                main_properties['issue_date'] = onfido_date_format(get_dates_to_generic_format(main_properties['issue_date']))


            if not data.get('card_number') and data.get('card_number_front'):
                card_data_t = {
                "type": "type",
                "value": "document_number"
                }

                card_data_v = {
                    "type": "value",
                    "value": data['card_number_front']
                }

                main_properties['document_numbers'].append(card_data_t)
                main_properties['document_numbers'].append(card_data_v)

            if not data.get('id_number') and data.get('id_number_front'):
                id_data_t = {
                            "type": "type",
                            "value": "personal_number"
                        }
                id_data_v = {
                            "type": "value",
                            "value": data['id_number_front']
                        }
                    
                main_properties['document_numbers'].append(id_data_t) 
                main_properties['document_numbers'].append(id_data_v) 

            if country == 'IRQ' and data.get('id_number', '') and data.get('id_number_front', ''):
                if len(data['id_number']) < len(data['id_number_front']):
                    main_properties['document_numbers'][3]['value'] = data['id_number_front']
                    main_properties['id_number'] = data['id_number_front']

            
            return main_properties

    except Exception as e:
        logging.error(f"Error extracting main details: {e}")
        return main_properties

    return main_properties    


def form_final_data_document_report(data, front_id_text, back_id_text, country, coloured, selfie, facial_similarity, blurred, glare, missing_fields, face_match_threshold, back_img):
    try:
        if data.get('uae_pass_data', ''):
            dob = data.get('uae_pass_data', '').get('DateOfBirth', '')
        else:
            dob = data.get('dob', '')

        document_report = {
            "_id": "",
            "breakdown": {
                "age_validation": age_validation(dob),
                "compromised_document": {
                    "result": "clear"
                    },
                "data_comparison": data_comparison_check(data, country),
                "data_consistency": data_consistency_check(data, front_id_text, back_id_text, country, back_img),
                "data_validation": data_validation_check(data, country),
                "image_integrity": image_integrity_check(data, front_id_text, back_id_text, coloured, blurred, glare, missing_fields, country),
                "issuing_authority": {
                "breakdown": {
                    "nfc_active_authentication": {
                    "properties": {}
                    },
                    "nfc_passive_authentication": {
                    "properties": {}
                    }
                }
                },
                "police_record": {},
                "visual_authenticity": visual_authenticity_check(data, front_id_text, back_id_text, selfie, facial_similarity, face_match_threshold, country)
            },
            "check_id": "", 
            "created_at": created_at(),
            "documents": [
                {
                "id": ""
                },
                {
                "id": ""
                }
            ],
            "href": "",
            "name": "document",
            "properties": main_details(data, country),
            "result": "",
            "status": "complete",
            "sub_result": ""
        }
        
        final_result = create_final_result(document_report)
        document_report['result'] = final_result

        sub_result = create_sub_result(document_report)
        document_report['sub_result'] = sub_result

        #For ATA Testing phase
        if country == 'UAE':

            if document_report['breakdown']['data_consistency']['breakdown']['multiple_data_sources_present']['result'] == 'consider':
                document_report['result'] = 'consider'
                document_report['sub_result'] = 'caution'
            else:
                keys_to_mark = ['original_document_present','conclusive_document_quality','image_quality','data_consistency', 'data_comparison', 'image_integrity', 'data_validation', 'visual_authenticity']
                document_report = mark_clear(document_report, keys_to_mark)
                document_report['result'] = 'clear'
                document_report['sub_result'] = 'clear'

        # if country == 'QAT' and(document_report['breakdown']['visual_authenticity']['result'] == 'clear' and document_report['breakdown']['visual_authenticity']['breakdown']['face_detection'] == 'clear' and document_report['breakdown']['data_consistency']['breakdown']['multiple_data_sources_present']['result'] == 'clear'):
        #     keys_to_mark = ['data_consistency', 'data_comparison', 'image_integrity', 'data_validation', 'visual_authenticity']
        #     document_report = mark_clear(document_report, keys_to_mark)
        #     document_report['result'] = 'clear'

        if country == 'IRQ' and data.get('nfc_data', ''):
            document_report["type"] = "NFC"
        else:
            document_report["type"] = "OCR"

        return document_report
    
    except Exception as e:
        print(f"\n--------------Error occurred while forming Document Report: {str(e)}")
        raise Exception("Error occurred while creating document_report")
        # return {}

def form_final_facial_similarity_report(data, selfie, facial_similarity, liveness_result, face_match_threshold, country):
    try:
        facial_report = FACIAL_REPORT
        facial_report = mark_clear(facial_report, ['breakdown'])

        facial_report['created_at'] = created_at()

        facial_report['breakdown']['face_comparison']['breakdown']['face_match']['properties']['score'] = facial_similarity

        if not np.any(selfie):
            facial_report['breakdown']['face_comparison']['breakdown']['face_match']['result'] = ''
            facial_report['breakdown']['face_comparison']['result'] = ''
            facial_report['breakdown']['image_integrity']['breakdown']['face_detected']['result'] = ''
            facial_report['breakdown']['image_integrity']['breakdown']['source_integrity']['result'] = ''

        if np.any(selfie) and facial_similarity > face_match_threshold:
            facial_report['breakdown']['face_comparison']['breakdown']['face_match']['result'] = 'clear'
            facial_report['breakdown']['face_comparison']['result'] = 'clear'
            facial_report['breakdown']['image_integrity']['breakdown']['face_detected']['result'] = 'clear'
        elif facial_similarity != 0 and facial_similarity <= face_match_threshold:
            facial_report['breakdown']['face_comparison']['breakdown']['face_match']['result']  = 'consider'
            facial_report['breakdown']['face_comparison']['result'] = 'consider'
            facial_report['breakdown']['image_integrity']['breakdown']['face_detected']['result'] = 'clear'
        else:
            facial_report['breakdown']['face_comparison']['breakdown']['face_match']['result']  = 'consider'
            facial_report['breakdown']['face_comparison']['result'] = 'consider'
            facial_report['breakdown']['image_integrity']['breakdown']['face_detected']['result'] = 'consider'

        front_photo_on_screen_result = data.get('front_photo_on_screen_result')

        if country == 'UAE':
            photo_on_screen_result = data.get('photo_on_screen_result')
            if front_photo_on_screen_result == 'consider' or photo_on_screen_result == 'consider':
                facial_report['breakdown']['image_integrity']['breakdown']['source_integrity']['result'] = 'consider'

        if country == 'SAU':
            facial_report['breakdown']['image_integrity']['breakdown']['source_integrity']['result'] = front_photo_on_screen_result

        facial_report['breakdown']['visual_authenticity']['breakdown']['spoofing_detection']['properties']['score'] = round(1-facial_similarity,2)

        facial_report['breakdown']['visual_authenticity']['breakdown']['liveness_detected']['result'] = 'clear'
        facial_report['breakdown']['visual_authenticity']['breakdown']['spoofing_detection']['result'] = 'clear'
        facial_report['breakdown']['visual_authenticity']['result'] = 'clear'

        if liveness_result == 'consider':
            facial_report['breakdown']['visual_authenticity']['breakdown']['liveness_detected']['result'] = 'consider'
            facial_report['breakdown']['visual_authenticity']['breakdown']['spoofing_detection']['result'] = 'consider'
            facial_report['breakdown']['visual_authenticity']['result'] = 'consider'
        elif liveness_result == 'clear' and facial_similarity <= face_match_threshold:
            facial_report['breakdown']['visual_authenticity']['breakdown']['spoofing_detection']['result'] = 'consider'
            facial_report['breakdown']['visual_authenticity']['result'] = 'consider'
        elif liveness_result == None:
            facial_report['breakdown']['visual_authenticity']['breakdown']['liveness_detected']['result'] = ''
            facial_report['breakdown']['visual_authenticity']['breakdown']['spoofing_detection']['properties']['score'] = ''
            facial_report['breakdown']['visual_authenticity']['breakdown']['spoofing_detection']['result'] = ''

        visual_authenticity_final_result = create_final_result(facial_report['breakdown']['visual_authenticity'])
        facial_report['breakdown']['visual_authenticity']['result'] = visual_authenticity_final_result

        image_integrity_final_result = create_final_result(facial_report['breakdown']['image_integrity'])
        facial_report['breakdown']['image_integrity']['result'] = image_integrity_final_result

        complete_final_result = create_final_result(facial_report['breakdown'])
        facial_report['result'] = complete_final_result
        facial_report['sub_result'] = complete_final_result

        return facial_report

    except Exception as e:
        print(f"\n--------------Error occurred while forming Facial Report: {str(e)}")
        raise Exception("Error occurred while creating facial_report")
